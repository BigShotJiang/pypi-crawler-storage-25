"""CLI commands for data cleanup operations in RegScale."""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Tuple

import click

from regscale.core.app.api import Api
from regscale.models.app_models.click import regscale_ssp_id
from regscale.models.regscale_models.asset import Asset
from regscale.models.regscale_models.issue import Issue
from regscale.models.regscale_models.scan_history import ScanHistory
from regscale.models.regscale_models.vulnerability import Vulnerability
from regscale.models.regscale_models.vulnerability_mapping import VulnerabilityMapping

logger = logging.getLogger("regscale")

MAX_WORKERS = 5
PAGE_SIZE = 500

_MODULE_CHOICES = click.Choice(["securityplans", "components"], case_sensitive=False)


def _module_label(module: str, parent_id: int) -> str:
    """Return a human-readable label like 'SSP 6' or 'component 81'."""
    prefix = "SSP" if module == "securityplans" else "component"
    return f"{prefix} {parent_id}"


def _delete_items_with_progress(
    items: List,
    item_type: str,
    dry_run: bool = False,
) -> Tuple[int, int]:
    """
    Delete items with progress feedback.

    :param List items: List of items to delete
    :param str item_type: Type of items for display purposes
    :param bool dry_run: If True, only preview deletions
    :return: Tuple of (deleted_count, failed_count)
    :rtype: Tuple[int, int]
    """
    if not items:
        click.echo(f"No {item_type} found to delete.")
        return 0, 0

    click.echo(f"Found {len(items)} {item_type}(s)")

    if dry_run:
        click.echo(f"[DRY RUN] Would delete {len(items)} {item_type}(s):")
        for item in items[:10]:
            item_id = getattr(item, "id", "unknown")
            item_title = getattr(item, "title", getattr(item, "name", getattr(item, "plugInName", str(item_id))))
            click.echo(f"  - {item_type} #{item_id}: {item_title}")
        if len(items) > 10:
            click.echo(f"  ... and {len(items) - 10} more")
        return len(items), 0

    deleted_count = 0
    failed_count = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(item.delete): item for item in items}

        with click.progressbar(
            length=len(items),
            label=f"Deleting {item_type}s",
            show_pos=True,
        ) as bar:
            for future in as_completed(futures):
                item = futures[future]
                try:
                    if future.result():
                        deleted_count += 1
                    else:
                        failed_count += 1
                        logger.warning("Failed to delete %s ID %s", item_type, getattr(item, "id", "unknown"))
                except Exception as e:
                    failed_count += 1
                    logger.error("Error deleting %s ID %s: %s", item_type, getattr(item, "id", "unknown"), str(e))
                bar.update(1)

    return deleted_count, failed_count


def _fetch_issues(parent_id: int, module: str, status: Optional[str] = None) -> List[Issue]:
    """
    Fetch all issues for the given parent via GraphQL, auto-paginated via pageInfo.

    :param int parent_id: Parent record ID
    :param str module: Parent module (securityplans or components)
    :param Optional[str] status: Optional status filter
    :return: List of Issue objects
    :rtype: List[Issue]
    """
    api = Api()
    status_filter = f', status: {{ eq: "{status}" }}' if status else ""
    query = f"""
        query {{
            issues(
                take: {PAGE_SIZE},
                where: {{
                    parentModule: {{ eq: "{module}" }},
                    parentId: {{ eq: {parent_id} }}
                    {status_filter}
                }}
            ) {{
                items {{
                    id
                    title
                }}
                pageInfo {{ hasNextPage }}
            }}
        }}
    """
    response = api.graph(query=query)
    items = response.get("issues", {}).get("items", [])
    logger.info("Fetched %d issues for %s %s", len(items), module, parent_id)
    return [Issue(**item) for item in items]


def _fetch_assets(parent_id: int, module: str) -> List[Asset]:
    """
    Fetch all assets for the given parent via GraphQL, auto-paginated via pageInfo.

    :param int parent_id: Parent record ID
    :param str module: Parent module (securityplans or components)
    :return: List of Asset objects
    :rtype: List[Asset]
    """
    api = Api()
    query = f"""
        query {{
            assets(
                take: {PAGE_SIZE},
                where: {{
                    parentModule: {{ eq: "{module}" }},
                    parentId: {{ eq: {parent_id} }}
                }}
            ) {{
                items {{
                    id
                    name
                }}
                pageInfo {{ hasNextPage }}
            }}
        }}
    """
    response = api.graph(query=query)
    items = response.get("assets", {}).get("items", [])
    logger.info("Fetched %d assets for %s %s", len(items), module, parent_id)
    return [Asset(**item) for item in items]


def _fetch_vulnerabilities(parent_id: int, module: str) -> List[Vulnerability]:
    """
    Fetch all vulnerabilities for the given parent via GraphQL, auto-paginated via pageInfo.

    Runs two queries (via scans and directly linked) to capture all vulnerabilities,
    deduplicating by ID.

    :param int parent_id: Parent record ID
    :param str module: Parent module (securityplans or components)
    :return: Deduplicated list of Vulnerability objects
    :rtype: List[Vulnerability]
    """
    api = Api()
    all_vulnerabilities: List[Vulnerability] = []
    seen_ids: set = set()

    via_scan_query = f"""
        query {{
            vulnerabilities(
                take: {PAGE_SIZE},
                where: {{ scan: {{ parentModule: {{ eq: "{module}" }}, parentId: {{ eq: {parent_id} }} }} }}
            ) {{
                items {{ id scanId }}
                pageInfo {{ hasNextPage }}
            }}
        }}
    """
    direct_query = f"""
        query {{
            vulnerabilities(
                take: {PAGE_SIZE},
                where: {{ parentModule: {{ eq: "{module}" }}, parentId: {{ eq: {parent_id} }} }}
            ) {{
                items {{ id scanId }}
                pageInfo {{ hasNextPage }}
            }}
        }}
    """

    for query in (via_scan_query, direct_query):
        response = api.graph(query=query)
        for item in response.get("vulnerabilities", {}).get("items", []):
            if item["id"] not in seen_ids:
                all_vulnerabilities.append(Vulnerability(**item))
                seen_ids.add(item["id"])

    logger.info("Total unique vulnerabilities for %s %s: %d", module, parent_id, len(all_vulnerabilities))
    return all_vulnerabilities


def _fetch_scan_history_by_ids(scan_ids: List[int]) -> List[ScanHistory]:
    """
    Fetch scan history records by their IDs via GraphQL.

    :param List[int] scan_ids: List of scan IDs to fetch
    :return: List of ScanHistory objects
    :rtype: List[ScanHistory]
    """
    if not scan_ids:
        return []

    api = Api()
    all_scans: List[ScanHistory] = []
    logger.info("Fetching %d scan history records by ID", len(scan_ids))

    for scan_id in scan_ids:
        query = f"""
            query {{
                scanHistories(
                    take: 1,
                    where: {{ id: {{ eq: {scan_id} }} }}
                ) {{
                    items {{
                        id
                        scanningTool
                        parentId
                        parentModule
                    }}
                }}
            }}
        """
        try:
            response = api.graph(query=query)
            for item in response.get("scanHistories", {}).get("items", []):
                all_scans.append(ScanHistory(**item))
        except Exception as e:
            logger.error("Error fetching scan history ID %s: %s", scan_id, str(e))

    logger.info("Retrieved %d scan history records", len(all_scans))
    return all_scans


def _delete_vulnerability_mappings_for_vulnerabilities(
    vulnerabilities: List[Vulnerability],
    dry_run: bool = False,
) -> Tuple[int, int]:
    """
    Delete vulnerability mappings for the given vulnerabilities.

    :param List[Vulnerability] vulnerabilities: List of vulnerabilities
    :param bool dry_run: If True, only preview deletions
    :return: Tuple of (deleted_count, failed_count)
    :rtype: Tuple[int, int]
    """
    if not vulnerabilities:
        return 0, 0

    click.echo("Fetching vulnerability mappings...")
    all_mappings = []

    with click.progressbar(vulnerabilities, label="Finding mappings", show_pos=True) as bar:
        for vuln in bar:
            try:
                mappings = VulnerabilityMapping.find_by_vulnerability(vulnerability_id=vuln.id, status="all")
                all_mappings.extend(mappings)
            except Exception as e:
                logger.warning("Error fetching mappings for vulnerability %s: %s", vuln.id, str(e))

    if all_mappings:
        click.echo(f"Found {len(all_mappings)} vulnerability mapping(s) to delete")
        return _delete_items_with_progress(all_mappings, "vulnerability mapping", dry_run)

    click.echo("No vulnerability mappings found")
    return 0, 0


def _run_vulnerability_dry_run(
    vulnerabilities: List[Vulnerability],
    scans_to_delete: List[ScanHistory],
    include_mappings: bool,
    include_scans: bool,
) -> None:
    """
    Run dry-run preview for vulnerability deletion.

    :param List[Vulnerability] vulnerabilities: Vulnerabilities to preview
    :param List[ScanHistory] scans_to_delete: Scan history records to preview
    :param bool include_mappings: Whether mappings would be deleted
    :param bool include_scans: Whether scans would be deleted
    """
    click.echo(click.style("\n[DRY RUN MODE]", fg="cyan"))
    if include_mappings:
        _delete_vulnerability_mappings_for_vulnerabilities(vulnerabilities, dry_run=True)
    _delete_items_with_progress(vulnerabilities, "vulnerability", dry_run=True)
    if include_scans and scans_to_delete:
        _delete_items_with_progress(scans_to_delete, "scan history", dry_run=True)


def _execute_vulnerability_cleanup(
    vulnerabilities: List[Vulnerability],
    scans_to_delete: List[ScanHistory],
    include_mappings: bool,
    include_scans: bool,
) -> Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int]]:
    """
    Execute the vulnerability cleanup deletion steps.

    :param List[Vulnerability] vulnerabilities: Vulnerabilities to delete
    :param List[ScanHistory] scans_to_delete: Scan history records to delete
    :param bool include_mappings: Whether to delete mappings
    :param bool include_scans: Whether to delete scans
    :return: Tuple of (mappings_result, vulns_result, scans_result) where each is (deleted, failed)
    :rtype: Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int]]
    """
    step_num = 1
    mappings_deleted, mappings_failed = 0, 0
    scans_deleted, scans_failed = 0, 0

    if include_mappings:
        click.echo(f"\nStep {step_num}: Deleting vulnerability mappings...")
        mappings_deleted, mappings_failed = _delete_vulnerability_mappings_for_vulnerabilities(
            vulnerabilities, dry_run=False
        )
        step_num += 1

    click.echo(f"\nStep {step_num}: Deleting vulnerabilities...")
    vulns_deleted, vulns_failed = _delete_items_with_progress(vulnerabilities, "vulnerability", dry_run=False)
    step_num += 1

    if include_scans and scans_to_delete:
        click.echo(f"\nStep {step_num}: Deleting scan history records...")
        scans_deleted, scans_failed = _delete_items_with_progress(scans_to_delete, "scan history", dry_run=False)

    return (mappings_deleted, mappings_failed), (vulns_deleted, vulns_failed), (scans_deleted, scans_failed)


def _confirm_vulnerability_deletion(
    vulnerabilities: List[Vulnerability],
    scans_to_delete: List[ScanHistory],
    include_mappings: bool,
    include_scans: bool,
    force: bool,
    label: str,
) -> bool:
    """
    Prompt user for confirmation before deleting vulnerabilities.

    :param List[Vulnerability] vulnerabilities: Vulnerabilities to delete
    :param List[ScanHistory] scans_to_delete: Scan history records to delete
    :param bool include_mappings: Whether mappings will be deleted
    :param bool include_scans: Whether scans will be deleted
    :param bool force: Skip confirmation if True
    :param str label: Display label for the parent (e.g. 'SSP 6')
    :return: True if user confirmed or force is True
    :rtype: bool
    """
    if force:
        return True

    extras = []
    if include_mappings:
        extras.append("mappings")
    if include_scans and scans_to_delete:
        extras.append(f"{len(scans_to_delete)} scan history record(s)")
    extras_msg = f" and their associated {', '.join(extras)}" if extras else ""

    if not click.confirm(
        f"\nAre you sure you want to delete {len(vulnerabilities)} vulnerability(ies){extras_msg} from {label}?",
        default=False,
    ):
        click.echo("Operation cancelled.")
        return False

    return True


def _print_cleanup_summary(
    vulns_result: Tuple[int, int],
    mappings_result: Tuple[int, int],
    scans_result: Tuple[int, int],
    include_mappings: bool,
    has_scans: bool,
) -> None:
    """
    Print the cleanup summary.

    :param Tuple[int, int] vulns_result: (deleted, failed) for vulnerabilities
    :param Tuple[int, int] mappings_result: (deleted, failed) for mappings
    :param Tuple[int, int] scans_result: (deleted, failed) for scans
    :param bool include_mappings: Whether mappings were included
    :param bool has_scans: Whether scans were included
    """
    click.echo("\n" + "=" * 50)
    click.echo("Cleanup Summary:")
    click.echo(f"  Vulnerabilities: {vulns_result[0]} deleted, {vulns_result[1]} failed")
    if include_mappings:
        click.echo(f"  Mappings: {mappings_result[0]} deleted, {mappings_result[1]} failed")
    if has_scans:
        click.echo(f"  Scan History: {scans_result[0]} deleted, {scans_result[1]} failed")

    total_failed = vulns_result[1] + mappings_result[1] + scans_result[1]
    if total_failed == 0:
        click.echo(click.style("\nCleanup completed successfully!", fg="green"))
    else:
        click.echo(click.style("\nCleanup completed with some failures. Check logs for details.", fg="yellow"))


@click.command(name="delete_issues")
@regscale_ssp_id()
@click.option(
    "--module",
    "-m",
    type=_MODULE_CHOICES,
    default="securityplans",
    show_default=True,
    help="Parent module type to delete issues from.",
)
@click.option(
    "--status",
    type=str,
    default=None,
    help="Filter by issue status (e.g., 'Open', 'Closed'). If not specified, all issues are deleted.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview what would be deleted without actually deleting.",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
def delete_issues(
    regscale_ssp_id: int,
    module: str,
    status: Optional[str],
    dry_run: bool,
    force: bool,
) -> None:
    """
    Delete all issues from an SSP or component.

    Fetches all issues for the specified parent and deletes them. Use --dry-run to
    preview without making changes. Use -m/--module to target a specific module type.

    Examples:

        regscale cleanup delete_issues -id 123

        regscale cleanup delete_issues -id 123 -m components

        regscale cleanup delete_issues -id 123 --status Closed

        regscale cleanup delete_issues -id 123 --dry-run

        regscale cleanup delete_issues -id 123 --force
    """
    label = _module_label(module, regscale_ssp_id)
    try:
        click.echo(f"Fetching issues for {label}...")
        issues = _fetch_issues(parent_id=regscale_ssp_id, module=module, status=status)

        if not issues:
            click.echo(click.style(f"No issues found for {label}.", fg="yellow"))
            return

        status_msg = f" with status '{status}'" if status else ""
        click.echo(f"Found {len(issues)} issue(s){status_msg} for {label}")

        if dry_run:
            click.echo(click.style("\n[DRY RUN MODE]", fg="cyan"))
            _delete_items_with_progress(issues, "issue", dry_run=True)
            return

        if not force and not click.confirm(
            f"\nAre you sure you want to delete {len(issues)} issue(s) from {label}?",
            default=False,
        ):
            click.echo("Operation cancelled.")
            return

        deleted_count, failed_count = _delete_items_with_progress(issues, "issue", dry_run=False)

        click.echo("")
        if failed_count == 0:
            click.echo(click.style(f"Successfully deleted {deleted_count} issue(s) from {label}", fg="green"))
        else:
            click.echo(click.style(f"Deleted {deleted_count} issue(s), {failed_count} failed", fg="yellow"))

    except Exception as e:
        logger.error("Error during issue cleanup: %s", str(e))
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort()


@click.command(name="delete_assets")
@regscale_ssp_id()
@click.option(
    "--module",
    "-m",
    type=_MODULE_CHOICES,
    default="securityplans",
    show_default=True,
    help="Parent module type to delete assets from.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview what would be deleted without actually deleting.",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
def delete_assets(
    regscale_ssp_id: int,
    module: str,
    dry_run: bool,
    force: bool,
) -> None:
    """
    Delete all assets from an SSP or component.

    Fetches all assets for the specified parent and deletes them. Use --dry-run to
    preview without making changes. Use -m/--module to target a specific module type.

    Examples:

        regscale cleanup delete_assets -id 123

        regscale cleanup delete_assets -id 123 -m components

        regscale cleanup delete_assets -id 123 --dry-run

        regscale cleanup delete_assets -id 123 --force
    """
    label = _module_label(module, regscale_ssp_id)
    try:
        click.echo(f"Fetching assets for {label}...")
        assets = _fetch_assets(parent_id=regscale_ssp_id, module=module)

        if not assets:
            click.echo(click.style(f"No assets found for {label}.", fg="yellow"))
            return

        click.echo(f"Found {len(assets)} asset(s) for {label}")

        if dry_run:
            click.echo(click.style("\n[DRY RUN MODE]", fg="cyan"))
            _delete_items_with_progress(assets, "asset", dry_run=True)
            return

        if not force and not click.confirm(
            f"\nAre you sure you want to delete {len(assets)} asset(s) from {label}?",
            default=False,
        ):
            click.echo("Operation cancelled.")
            return

        deleted_count, failed_count = _delete_items_with_progress(assets, "asset", dry_run=False)

        click.echo("")
        if failed_count == 0:
            click.echo(click.style(f"Successfully deleted {deleted_count} asset(s) from {label}", fg="green"))
        else:
            click.echo(click.style(f"Deleted {deleted_count} asset(s), {failed_count} failed", fg="yellow"))

    except Exception as e:
        logger.error("Error during asset cleanup: %s", str(e))
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort()


@click.command(name="delete_vulnerabilities")
@regscale_ssp_id()
@click.option(
    "--module",
    "-m",
    type=_MODULE_CHOICES,
    default="securityplans",
    show_default=True,
    help="Parent module type to delete vulnerabilities from.",
)
@click.option(
    "--include-mappings/--no-mappings",
    default=True,
    help="Also delete vulnerability mappings (default: True).",
)
@click.option(
    "--include-scans/--no-scans",
    default=True,
    help="Also delete associated scan history records (default: True).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview what would be deleted without actually deleting.",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
def delete_vulnerabilities(
    regscale_ssp_id: int,
    module: str,
    include_mappings: bool,
    include_scans: bool,
    dry_run: bool,
    force: bool,
) -> None:
    """
    Delete all vulnerabilities from an SSP or component.

    Fetches all vulnerabilities (via scans and directly linked) for the specified parent
    and deletes them. By default also deletes associated mappings and scan history records.

    Use --dry-run to preview without making changes.
    Use --no-mappings to skip deleting vulnerability mappings.
    Use --no-scans to skip deleting scan history records.
    Use -m/--module to target a specific module type.

    Examples:

        regscale cleanup delete_vulnerabilities -id 123

        regscale cleanup delete_vulnerabilities -id 123 -m components

        regscale cleanup delete_vulnerabilities -id 123 --dry-run

        regscale cleanup delete_vulnerabilities -id 123 --no-mappings

        regscale cleanup delete_vulnerabilities -id 123 --no-scans

        regscale cleanup delete_vulnerabilities -id 123 --force
    """
    label = _module_label(module, regscale_ssp_id)
    try:
        click.echo(f"Fetching vulnerabilities for {label}...")
        vulnerabilities = _fetch_vulnerabilities(parent_id=regscale_ssp_id, module=module)

        if not vulnerabilities:
            click.echo(click.style(f"No vulnerabilities found for {label}.", fg="yellow"))
            return

        click.echo(f"Found {len(vulnerabilities)} vulnerability(ies) for {label}")

        scan_ids = list({v.scanId for v in vulnerabilities if v.scanId is not None})
        scans_to_delete: List[ScanHistory] = []

        if include_scans and scan_ids:
            click.echo(f"Found {len(scan_ids)} unique scan history record(s) linked to vulnerabilities")
            scans_to_delete = _fetch_scan_history_by_ids(scan_ids)

        if dry_run:
            _run_vulnerability_dry_run(vulnerabilities, scans_to_delete, include_mappings, include_scans)
            return

        if not _confirm_vulnerability_deletion(
            vulnerabilities, scans_to_delete, include_mappings, include_scans, force, label
        ):
            return

        mappings_result, vulns_result, scans_result = _execute_vulnerability_cleanup(
            vulnerabilities, scans_to_delete, include_mappings, include_scans
        )

        _print_cleanup_summary(vulns_result, mappings_result, scans_result, include_mappings, bool(scans_to_delete))

    except Exception as e:
        logger.error("Error during vulnerability cleanup: %s", str(e))
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort()
