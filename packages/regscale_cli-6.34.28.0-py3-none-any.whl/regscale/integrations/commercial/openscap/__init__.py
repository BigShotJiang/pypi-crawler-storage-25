#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenSCAP integration package.

Provides ingestion of OpenSCAP scan artifacts (ARF, XCCDF, CSV) into RegScale
as assets, findings, and compliance assessments.
"""
