#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CSV parser for OpenSCAP CSV export files.

Reads CSV files line-by-line using csv.DictReader (no full-file read).
Normalises column name variants before building ScapCsvRow models.
"""

import csv
import logging
from pathlib import Path
from typing import Generator

from regscale.models.integration_models.openscap import ScapAsset, ScapCsvRow, ScapRuleResult

logger = logging.getLogger("regscale")


def _csv_row_to_rule_result(row: ScapCsvRow) -> ScapRuleResult:
    """Convert a ScapCsvRow to a ScapRuleResult for unified processing.

    :param ScapCsvRow row: Parsed CSV row
    :return: Equivalent ScapRuleResult
    :rtype: ScapRuleResult
    """
    refs = [r.strip() for r in row.references.replace("|", ",").split(",") if r.strip()]
    return ScapRuleResult.model_construct(
        rule_id=row.rule_id,
        result=row.result.lower(),
        severity=row.severity.lower() or "unknown",
        rule_title=row.title,
        description=row.description,
        fix_text="",
        idents=[],
        references=refs,
        asset_fqdn=row.asset_identifier,
        asset_ip="",
        check_content_ref="",
    )


class CsvParser:
    """Streaming parser for OpenSCAP CSV export files.

    Reads rows one at a time using csv.DictReader. Column names are normalised
    (lowercase, spaces replaced with underscores) before mapping to ScapCsvRow fields.

    :param Path file_path: Path to the CSV file
    """

    def __init__(self, file_path: Path) -> None:
        """Initialise the CSV parser for the given file.

        :param Path file_path: Path to CSV file
        """
        self.file_path = Path(file_path)

    def stream_rows(self) -> Generator[ScapCsvRow, None, None]:
        """Yield ScapCsvRow objects for each valid data row in the CSV.

        Rows missing required fields (rule_id, result) are silently skipped.

        :yield: ScapCsvRow instances
        :rtype: Generator[ScapCsvRow, None, None]
        """
        with open(self.file_path, encoding="utf-8", newline="") as fh:
            reader = csv.DictReader(fh)
            for raw_row in reader:
                row = ScapCsvRow.from_csv_row(raw_row)
                if row is not None:
                    yield row

    def stream_results(self) -> Generator[ScapRuleResult, None, None]:
        """Yield ScapRuleResult objects converted from CSV rows.

        Provides a unified interface matching ArfParser and XccdfParser.

        :yield: ScapRuleResult instances
        :rtype: Generator[ScapRuleResult, None, None]
        """
        for row in self.stream_rows():
            yield _csv_row_to_rule_result(row)

    def stream_assets(self) -> Generator[ScapAsset, None, None]:
        """Yield synthetic ScapAssets built from unique CSV Asset column values.

        OpenSCAP CSV exports don't carry structured asset metadata, but the
        Asset column lets us create minimal stub assets so that vulnerability
        records can be linked to them in RegScale.

        :yield: ScapAsset instances
        :rtype: Generator[ScapAsset, None, None]
        """
        seen: set = set()
        for row in self.stream_rows():
            identifier = row.asset_identifier.strip()
            if not identifier or identifier in seen:
                continue
            seen.add(identifier)
            yield ScapAsset.model_construct(fqdn=identifier)
