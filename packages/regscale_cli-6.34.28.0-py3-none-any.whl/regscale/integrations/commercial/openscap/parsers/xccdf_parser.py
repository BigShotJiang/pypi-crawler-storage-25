#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""XCCDF results streaming parser for OpenSCAP.

Handles standalone xccdf:TestResult XML files (produced by oscap xccdf eval --results).
These lack ARF wrapper elements and asset metadata, so stream_assets() always yields nothing.

XXE hardening: all iterparse calls pass ``resolve_entities=False`` to prevent
XML External Entity (XXE) injection from untrusted scan files.
"""

import logging
from pathlib import Path
from typing import Generator

import lxml.etree as et

from regscale.integrations.commercial.openscap.parsers.arf_parser import (
    TAG_ASSET,
    _build_rule_meta,
    _detect_xccdf_namespace,
    _parse_rule_result,
    _tag_constants,
)
from regscale.models.integration_models.openscap import ScapAsset, ScapRuleResult

logger = logging.getLogger("regscale")


class XccdfParser:
    """Streaming parser for standalone XCCDF results XML files.

    Produces the same ScapRuleResult objects as ArfParser but has no asset metadata.
    stream_assets() always yields nothing.

    :param Path file_path: Path to the XCCDF results XML file
    """

    def __init__(self, file_path: Path) -> None:
        """Initialise the XCCDF parser for the given file.

        :param Path file_path: Path to XCCDF results XML file
        """
        self.file_path = Path(file_path)
        self._xccdf_ns = _detect_xccdf_namespace(self.file_path)
        self._tag_rule, self._tag_rule_result = _tag_constants(self._xccdf_ns)
        self._rule_meta = {}
        self._meta_built = False

    def _ensure_meta(self) -> None:
        """Build rule metadata on first access (lazy).

        :return: None
        :rtype: None
        """
        if not self._meta_built:
            self._rule_meta = _build_rule_meta(self.file_path, self._tag_rule, self._xccdf_ns)
            self._meta_built = True

    def _parse_target(self) -> tuple:
        """Extract (fqdn, ip) from the first xccdf:TestResult/target(-address).

        :return: Tuple of (target_fqdn, target_ip), either may be empty.
        :rtype: tuple
        """
        tag_target = f"{{{self._xccdf_ns}}}target"
        tag_target_address = f"{{{self._xccdf_ns}}}target-address"
        context = et.iterparse(
            str(self.file_path),
            events=("end",),
            tag=[tag_target, tag_target_address],
            recover=True,
            resolve_entities=False,
        )
        fqdn = ip = ""
        for _event, elem in context:
            if elem.tag == tag_target and not fqdn and elem.text:
                fqdn = elem.text.strip()
            elif elem.tag == tag_target_address and not ip and elem.text:
                ip = elem.text.strip()
            elem.clear()
            while elem.getprevious() is not None:
                del elem.getparent()[0]
            if fqdn and ip:
                break
        del context
        return fqdn, ip

    def stream_results(self) -> Generator[ScapRuleResult, None, None]:
        """Yield ScapRuleResult objects for each rule-result in the XCCDF file.

        Standalone XCCDF files have no ARF asset block, but they do carry
        ``<xccdf:target>`` and ``<xccdf:target-address>`` inside TestResult.
        We read those once up front so every rule-result carries the target
        FQDN / IP, enabling vulnerability-to-asset mapping downstream.

        :yield: ScapRuleResult instances
        :rtype: Generator[ScapRuleResult, None, None]
        """
        self._ensure_meta()
        target_fqdn, target_ip = self._parse_target()
        context = et.iterparse(
            str(self.file_path),
            events=("end",),
            tag=[self._tag_rule_result, TAG_ASSET],
            recover=True,
            resolve_entities=False,
        )
        for _event, elem in context:
            if elem.tag == self._tag_rule_result:
                result = _parse_rule_result(elem, self._rule_meta, self._xccdf_ns, None)
                elem.clear()
                while elem.getprevious() is not None:
                    del elem.getparent()[0]
                if result is not None:
                    if target_fqdn and not result.asset_fqdn:
                        result.asset_fqdn = target_fqdn
                    if target_ip and not result.asset_ip:
                        result.asset_ip = target_ip
                    yield result
            else:
                elem.clear()
                while elem.getprevious() is not None:
                    del elem.getparent()[0]
        del context

    def stream_assets(self) -> Generator[ScapAsset, None, None]:
        """Yield a single synthetic asset built from xccdf:target, or nothing.

        Standalone XCCDF files carry target metadata on the TestResult element;
        we expose it as a single ScapAsset so that findings in the same file
        can be linked back to an asset record during RegScale ingest.

        :yield: ScapAsset instances (zero or one)
        :rtype: Generator[ScapAsset, None, None]
        """
        fqdn, ip = self._parse_target()
        if not fqdn and not ip:
            return
        yield ScapAsset.model_construct(fqdn=fqdn, ipv4=ip)
