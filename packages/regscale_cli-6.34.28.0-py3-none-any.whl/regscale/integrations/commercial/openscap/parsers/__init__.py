#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenSCAP parsers package.

Provides streaming parsers for ARF, XCCDF, and CSV OpenSCAP scan artifacts.
"""
