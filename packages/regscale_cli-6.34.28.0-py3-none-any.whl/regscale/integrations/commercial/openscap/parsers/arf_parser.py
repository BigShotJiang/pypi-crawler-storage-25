#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ARF (Asset Reporting Format) streaming parser for OpenSCAP.

Uses lxml.etree.iterparse with explicit elem.clear() calls for bounded memory.
Performs a two-phase traversal:
  Phase 1 — build rule metadata dict (ScapRuleMeta) from xccdf:Rule elements.
  Phase 2 — stream rule-results and assets using the metadata dict.

XXE hardening: all iterparse calls pass ``resolve_entities=False`` to prevent
XML External Entity (XXE) injection from untrusted scan files.  This is the
approach recommended by the lxml project and endorsed by defusedxml's own docs
as the correct way to harden lxml without sacrificing streaming performance.
"""

import gc
import logging
from pathlib import Path
from typing import Dict, Generator, List

import lxml.etree as et

from regscale.models.integration_models.openscap import ScapAsset, ScapRuleMeta, ScapRuleResult

logger = logging.getLogger("regscale")

# ---------------------------------------------------------------------------
# Namespace constants — XCCDF 1.2 (default) and XCCDF 1.1 (legacy)
# ---------------------------------------------------------------------------
_XCCDF_12_NS = "http://checklists.nist.gov/xccdf/1.2"
_XCCDF_11_NS = "http://checklists.nist.gov/xccdf/1.1"
_ARF_NS = "http://scap.nist.gov/schema/asset-reporting-format/1.1"
_AI_NS = "http://scap.nist.gov/schema/asset-identification/1.1"

# Default (XCCDF 1.2) tag constants
TAG_RULE_RESULT_12 = f"{{{_XCCDF_12_NS}}}rule-result"
TAG_BENCHMARK_12 = f"{{{_XCCDF_12_NS}}}Benchmark"
TAG_RULE_12 = f"{{{_XCCDF_12_NS}}}Rule"

# XCCDF 1.1 tag constants
TAG_RULE_RESULT_11 = f"{{{_XCCDF_11_NS}}}rule-result"
TAG_BENCHMARK_11 = f"{{{_XCCDF_11_NS}}}Benchmark"
TAG_RULE_11 = f"{{{_XCCDF_11_NS}}}Rule"

TAG_ASSET = f"{{{_ARF_NS}}}asset"
TAG_COMPUTING_DEV = f"{{{_AI_NS}}}computing-device"

# Rule count threshold above which gc.collect() is called after Phase 1
_GC_RULE_THRESHOLD = 10_000


def _detect_xccdf_namespace(file_path: Path) -> str:
    """Detect whether the file uses XCCDF 1.1 or 1.2 namespace.

    Reads only the first root event to avoid loading the full tree.

    :param Path file_path: Path to the XML file
    :return: XCCDF namespace URI string
    :rtype: str
    """
    result = _XCCDF_12_NS
    context = et.iterparse(str(file_path), events=("start",), recover=True, resolve_entities=False)
    for _event, elem in context:
        ns = elem.nsmap.get("xccdf") or elem.nsmap.get(None) or ""
        if _XCCDF_11_NS in ns or str(elem.tag).startswith(f"{{{_XCCDF_11_NS}}}"):
            result = _XCCDF_11_NS
        break
    del context
    return result


def _tag_constants(xccdf_ns: str) -> tuple:
    """Return (TAG_RULE, TAG_RULE_RESULT) for the given XCCDF namespace.

    :param str xccdf_ns: XCCDF namespace URI
    :return: Tuple of (rule_tag, rule_result_tag) strings
    :rtype: tuple
    """
    if xccdf_ns == _XCCDF_11_NS:
        return TAG_RULE_11, TAG_RULE_RESULT_11
    return TAG_RULE_12, TAG_RULE_RESULT_12


def _extract_text(elem: et._Element, local_name: str, ns: str) -> str:
    """Return stripped text of first matching child element or empty string.

    :param et._Element elem: Parent element
    :param str local_name: Local tag name without namespace
    :param str ns: Namespace URI
    :return: Text content or empty string
    :rtype: str
    """
    child = elem.find(f"{{{ns}}}{local_name}")
    if child is not None and child.text:
        return child.text.strip()
    return ""


def _extract_description_text(elem: et._Element, ns: str) -> str:
    """Extract description text, stripping XHTML markup.

    :param et._Element elem: Parent element containing description
    :param str ns: XCCDF namespace URI
    :return: Plain text description
    :rtype: str
    """
    desc_elem = elem.find(f"{{{ns}}}description")
    if desc_elem is None:
        return ""
    try:
        parts = [desc_elem.text or ""]
        for child in desc_elem:
            parts.append(child.text or "")
            parts.append(child.tail or "")
        return " ".join(p.strip() for p in parts if p.strip())
    except Exception:  # pragma: no cover — defensive fallback; lxml C types rarely raise here
        return (desc_elem.text or "").strip()


def _extract_fix_text(elem: et._Element, ns: str) -> str:
    """Extract fix/fixtext content from a rule element.

    :param et._Element elem: Rule element
    :param str ns: XCCDF namespace URI
    :return: Fix text content
    :rtype: str
    """
    for tag in (f"{{{ns}}}fixtext", f"{{{ns}}}fix"):
        fix = elem.find(tag)
        if fix is not None and fix.text:
            return fix.text.strip()
    return ""


def _extract_idents(elem: et._Element, ns: str) -> List[str]:
    """Extract all xccdf:ident values from a Rule or rule-result element.

    :param et._Element elem: Element to search
    :param str ns: XCCDF namespace URI
    :return: List of identifier strings
    :rtype: List[str]
    """
    return [ident.text.strip() for ident in elem.findall(f"{{{ns}}}ident") if ident.text and ident.text.strip()]


def _extract_references(elem: et._Element, ns: str) -> List[str]:
    """Extract xccdf:reference text values from a Rule element.

    :param et._Element elem: Rule element
    :param str ns: XCCDF namespace URI
    :return: Deduplicated list of reference strings
    :rtype: List[str]
    """
    seen: set = set()
    refs: List[str] = []
    for ref in elem.findall(f"{{{ns}}}reference"):
        text = (ref.text or "").strip()
        if text and text not in seen:
            seen.add(text)
            refs.append(text)
    return refs


def _build_rule_meta(file_path: Path, tag_rule: str, xccdf_ns: str) -> Dict[str, ScapRuleMeta]:
    """Phase 1: Stream all xccdf:Rule end events and build a metadata dict.

    Memory is bounded: each element is cleared after processing.

    :param Path file_path: Path to ARF or XCCDF XML file
    :param str tag_rule: Fully-qualified Rule tag name
    :param str xccdf_ns: XCCDF namespace URI
    :return: Dict mapping rule_id to ScapRuleMeta
    :rtype: Dict[str, ScapRuleMeta]
    """
    rule_meta: Dict[str, ScapRuleMeta] = {}
    context = et.iterparse(str(file_path), events=("end",), tag=tag_rule, recover=True, resolve_entities=False)
    for _event, elem in context:
        rule_id = (elem.get("id") or "").strip()
        if not rule_id:
            elem.clear()
            while elem.getprevious() is not None:  # pragma: no cover
                del elem.getparent()[0]  # pragma: no cover
            continue
        severity = (elem.get("severity") or "unknown").lower()
        title = _extract_text(elem, "title", xccdf_ns)
        description = _extract_description_text(elem, xccdf_ns)
        fix_text = _extract_fix_text(elem, xccdf_ns)
        idents = _extract_idents(elem, xccdf_ns)
        references = _extract_references(elem, xccdf_ns)
        check_ref = ""
        check_elem = elem.find(f"{{{xccdf_ns}}}check")
        if check_elem is not None:
            cr = check_elem.find(f"{{{xccdf_ns}}}check-content-ref")
            if cr is not None:
                check_ref = (cr.get("href") or "").strip()
        rule_meta[rule_id] = ScapRuleMeta.model_construct(
            rule_id=rule_id,
            title=title,
            severity=severity,
            description=description,
            fix_text=fix_text,
            idents=idents,
            references=references,
            check_content_ref=check_ref,
        )
        elem.clear()
        while elem.getprevious() is not None:  # pragma: no cover
            del elem.getparent()[0]  # pragma: no cover
    del context
    if len(rule_meta) > _GC_RULE_THRESHOLD:
        gc.collect()
    return rule_meta


def _parse_rule_result(
    elem: et._Element, rule_meta: Dict[str, ScapRuleMeta], xccdf_ns: str, asset: "ScapAsset | None"
) -> "ScapRuleResult | None":
    """Build a ScapRuleResult from a rule-result element.

    :param et._Element elem: The rule-result element
    :param Dict[str, ScapRuleMeta] rule_meta: Pre-built metadata dict
    :param str xccdf_ns: XCCDF namespace URI
    :param ScapAsset | None asset: Current asset (may be None for XCCDF-only files)
    :return: ScapRuleResult or None if rule_id is missing
    :rtype: ScapRuleResult | None
    """
    rule_id = (elem.get("idref") or "").strip()
    if not rule_id:
        return None
    result_elem = elem.find(f"{{{xccdf_ns}}}result")
    result = (result_elem.text or "notchecked").strip().lower() if result_elem is not None else "notchecked"
    meta = rule_meta.get(rule_id)
    idents = _extract_idents(elem, xccdf_ns) or (meta.idents if meta else [])
    references = meta.references if meta else []
    return ScapRuleResult.model_construct(
        rule_id=rule_id,
        result=result,
        severity=meta.severity if meta else "unknown",
        rule_title=meta.title if meta else "",
        description=meta.description if meta else "",
        fix_text=meta.fix_text if meta else "",
        idents=idents,
        references=references,
        asset_fqdn=asset.fqdn if asset else "",
        asset_ip=asset.ipv4 if asset else "",
        asset_motherboard_guid=asset.motherboard_guid if asset else "",
        check_content_ref=meta.check_content_ref if meta else "",
    )


def _parse_asset(elem: et._Element) -> "ScapAsset | None":
    """Extract ScapAsset data from an arf:asset element.

    :param et._Element elem: arf:asset element
    :return: ScapAsset or None if no computing-device found
    :rtype: ScapAsset | None
    """
    dev = elem.find(f".//{{{_AI_NS}}}computing-device")
    if dev is None:
        return None

    def _ai(local: str) -> str:
        child = dev.find(f"{{{_AI_NS}}}{local}")
        return (child.text or "").strip() if child is not None and child.text else ""

    fqdn = _ai("fqdn")
    motherboard_guid = _ai("motherboard-guid")
    cpe_elem = dev.find(f"{{{_AI_NS}}}cpe")
    cpe = (cpe_elem.get("name") or cpe_elem.text or "").strip() if cpe_elem is not None else ""
    ipv4 = ""
    ipv6 = ""
    mac = ""
    for conn in dev.findall(f".//{{{_AI_NS}}}connection"):
        for ip_elem in conn.findall(f"{{{_AI_NS}}}ip-address"):
            category = (ip_elem.get("category") or "").lower()
            text = (ip_elem.text or "").strip()
            if category == "ipv4" and not ipv4:
                ipv4 = text
            elif category == "ipv6" and not ipv6:
                ipv6 = text
        mac_elem = conn.find(f"{{{_AI_NS}}}mac-address")
        if mac_elem is not None and mac_elem.text and not mac:
            mac = mac_elem.text.strip()
    return ScapAsset.model_construct(
        fqdn=fqdn,
        motherboard_guid=motherboard_guid,
        mac_address=mac,
        ipv4=ipv4,
        ipv6=ipv6,
        cpe=cpe,
    )


class ArfParser:
    """Streaming parser for NIST ARF (Asset Reporting Format) XML files.

    Uses a two-phase iterparse approach for bounded memory usage regardless of file size.

    :param Path file_path: Path to the ARF XML file
    """

    def __init__(self, file_path: Path) -> None:
        """Initialise the ARF parser for the given file.

        :param Path file_path: Path to ARF XML file
        """
        self.file_path = Path(file_path)
        self._xccdf_ns = _detect_xccdf_namespace(self.file_path)
        self._tag_rule, self._tag_rule_result = _tag_constants(self._xccdf_ns)
        self._rule_meta: Dict[str, ScapRuleMeta] = {}
        self._meta_built = False

    def _ensure_meta(self) -> None:
        """Build rule metadata on first access (lazy, called by stream_results).

        :return: None
        :rtype: None
        """
        if not self._meta_built:
            self._rule_meta = _build_rule_meta(self.file_path, self._tag_rule, self._xccdf_ns)
            self._meta_built = True

    def stream_results(self) -> Generator[ScapRuleResult, None, None]:
        """Yield ScapRuleResult objects for each rule-result in the ARF file.

        Phase 1 (rule metadata) is performed lazily on first call. Phase 2 streams
        rule-results and associates them with the most recently seen asset.

        :yield: ScapRuleResult instances
        :rtype: Generator[ScapRuleResult, None, None]
        """
        self._ensure_meta()
        current_asset: ScapAsset | None = None
        context = et.iterparse(
            str(self.file_path),
            events=("end",),
            tag=[self._tag_rule_result, TAG_ASSET],
            recover=True,
            resolve_entities=False,
        )
        for _event, elem in context:
            if elem.tag == TAG_ASSET:
                current_asset = _parse_asset(elem)
                elem.clear()
                while elem.getprevious() is not None:  # pragma: no cover
                    del elem.getparent()[0]  # pragma: no cover
            elif elem.tag == self._tag_rule_result:  # pragma: no branch
                result = _parse_rule_result(elem, self._rule_meta, self._xccdf_ns, current_asset)
                elem.clear()
                while elem.getprevious() is not None:  # pragma: no cover
                    del elem.getparent()[0]  # pragma: no cover
                if result is not None:  # pragma: no branch
                    yield result
        del context

    def stream_assets(self) -> Generator[ScapAsset, None, None]:
        """Yield ScapAsset objects for each arf:asset element in the ARF file.

        :yield: ScapAsset instances
        :rtype: Generator[ScapAsset, None, None]
        """
        context = et.iterparse(
            str(self.file_path), events=("end",), tag=TAG_ASSET, recover=True, resolve_entities=False
        )
        for _event, elem in context:
            asset = _parse_asset(elem)
            elem.clear()
            while elem.getprevious() is not None:  # pragma: no cover
                del elem.getparent()[0]  # pragma: no cover
            if asset is not None:
                yield asset
        del context
