#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenSCAP scanner integration.

Provides OpenScapScanner, a ScannerIntegration subclass that ingests ARF, XCCDF,
and CSV scan artifacts as findings and assets.

XXE hardening: the format-detection iterparse call passes ``resolve_entities=False``
to prevent XML External Entity (XXE) injection from untrusted scan files.
"""

import logging
from pathlib import Path
from typing import Any, Iterator, Optional

import lxml.etree as et

from regscale.integrations.commercial.openscap.mappers import (
    rule_result_to_finding,
    scap_asset_to_integration_asset,
    should_skip_result,
)
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
)

logger = logging.getLogger("regscale")

# Type alias for the three parser types (ArfParser, XccdfParser, CsvParser)
ParserType = Any


def _detect_format(path: Path) -> str:
    """Detect file format from file content (ARF vs XCCDF vs CSV).

    For XML files, peeks at the root element to distinguish ARF from bare XCCDF.

    :param Path path: Path to the scan file
    :return: One of "arf", "xccdf", "csv"
    :rtype: str
    """
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return "csv"
    if suffix not in (".xml", ""):
        return "xccdf"
    try:
        fmt = "xccdf"
        context = et.iterparse(str(path), events=("start",), recover=True, resolve_entities=False)
        for _event, elem in context:
            tag = elem.tag or ""
            if "asset-reporting-format" in tag:
                fmt = "arf"
            break
        del context
        return fmt
    except Exception:
        pass
    return "xccdf"


def _make_parser(file_path: Path, fmt: str) -> ParserType:
    """Instantiate the appropriate parser for the given format.

    :param Path file_path: Path to scan file
    :param str fmt: Format string ("arf", "xccdf", "csv")
    :return: Parser instance
    :rtype: ParserType
    """
    if fmt == "arf":
        from regscale.integrations.commercial.openscap.parsers.arf_parser import ArfParser

        return ArfParser(file_path)
    if fmt == "csv":
        from regscale.integrations.commercial.openscap.parsers.csv_parser import CsvParser

        return CsvParser(file_path)
    from regscale.integrations.commercial.openscap.parsers.xccdf_parser import XccdfParser

    return XccdfParser(file_path)


def _glob_files(path: Path, pattern: str) -> list:
    """Return sorted list of matching files under path.

    :param Path path: Directory or file path
    :param str pattern: Glob pattern (e.g., "*.xml")
    :return: List of Path objects
    :rtype: list
    """
    if path.is_file():
        return [path]
    return sorted(path.rglob(pattern))


class OpenScapScanner(ScannerIntegration):
    """Scanner integration for OpenSCAP ARF, XCCDF, and CSV scan artifacts.

    Ingests rule-level pass/fail results as IntegrationFinding objects and
    computing-device metadata as IntegrationAsset objects.

    All files in a batch are processed together so that the ScannerIntegration
    mop-up (issue closure) runs exactly once at the end of the full batch,
    not after each individual file.

    :cvar str title: Display title used in logging and issue tracking
    :cvar ScannerIntegrationType integration_type: Scanner type (VULNERABILITY)
    """

    title = "OpenSCAP"
    integration_type = ScannerIntegrationType.VULNERABILITY

    def __init__(
        self,
        plan_id: int,
        file_paths: Optional[list] = None,
        file_path: Optional[Path] = None,
        **kwargs,
    ) -> None:
        """Initialise the OpenSCAP scanner.

        Accepts either ``file_paths`` (a list of Path objects for batch processing)
        or ``file_path`` (a single Path, wrapped into a list for back-compat).
        If neither is supplied, ``self._file_paths`` is an empty list and the
        scanner yields nothing.

        Parsers are NOT pre-built here; ``fetch_findings`` and ``fetch_assets``
        construct them lazily one at a time to keep memory usage constant across
        large batches.

        :param int plan_id: RegScale security plan ID
        :param Optional[list] file_paths: List of Path objects for batch processing
        :param Optional[Path] file_path: Single scan file (back-compat; wrapped into list)
        :param kwargs: Additional keyword arguments passed to ScannerIntegration
        """
        parent_module = kwargs.pop("parent_module", None)
        super().__init__(plan_id=plan_id, **kwargs)
        if parent_module:
            self.parent_module = parent_module

        if file_paths is not None:
            self._file_paths: list = list(file_paths)
        elif file_path is not None:
            self._file_paths = [file_path]
        else:
            self._file_paths = []

    def fetch_findings(self, **kwargs) -> Iterator[IntegrationFinding]:
        """Yield IntegrationFinding objects from all configured scan files.

        Streams results lazily file-by-file; only one parser exists in memory
        at a time. Results with result=notchecked or notselected are silently
        skipped. All files are consumed before control returns to the caller so
        the base-class mop-up fires once for the entire batch.

        :yield: IntegrationFinding instances
        :rtype: Iterator[IntegrationFinding]
        """
        if not self._file_paths:
            return
        for file_path in self._file_paths:
            fmt = _detect_format(file_path)
            logger.info("Processing %s file: %s", fmt, file_path)
            parser = _make_parser(file_path, fmt)
            for rule_result in parser.stream_results():
                if should_skip_result(rule_result.result):
                    continue
                # Use the same identifier the asset mapper uses (FQDN preferred,
                # motherboard_guid fallback) so finding.asset_identifier matches
                # asset.otherTrackingNumber across ARF, XCCDF, and CSV imports
                # of the same host.
                asset_id = rule_result.asset_fqdn or rule_result.asset_motherboard_guid or ""
                yield rule_result_to_finding(rule_result, asset_id)

    def fetch_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """Yield IntegrationAsset objects from all configured scan files.

        XCCDF-only and CSV files have no asset metadata; their parsers'
        ``stream_assets()`` yields nothing, which is handled transparently.

        :yield: IntegrationAsset instances
        :rtype: Iterator[IntegrationAsset]
        """
        if not self._file_paths:
            return
        for file_path in self._file_paths:
            fmt = _detect_format(file_path)
            parser = _make_parser(file_path, fmt)
            for scap_asset in parser.stream_assets():
                yield scap_asset_to_integration_asset(scap_asset)

    @classmethod
    def sync_arf(cls, plan_id: int, path: Path, parent_module: str = "securityplans", dry_run: bool = False) -> None:
        """Import an ARF file (or directory of ARF files) into RegScale.

        Collects all matching files first, then issues a single sync_assets and
        sync_findings call so the mop-up fires once for the entire batch.

        :param int plan_id: RegScale security plan ID
        :param Path path: File or directory containing ARF XML files
        :param str parent_module: RegScale parent module name
        :param bool dry_run: If True, parse but do not submit to RegScale
        :return: None
        :rtype: None
        """
        file_paths = _glob_files(Path(path), "*.xml")
        if dry_run:
            return
        cls.sync_assets(plan_id=plan_id, file_paths=file_paths, parent_module=parent_module)
        cls.sync_findings(plan_id=plan_id, file_paths=file_paths, parent_module=parent_module)

    @classmethod
    def sync_xccdf(cls, plan_id: int, path: Path, parent_module: str = "securityplans", dry_run: bool = False) -> None:
        """Import a XCCDF results file (or directory) into RegScale.

        Collects all matching files first, then issues a single sync_assets and
        sync_findings call so the mop-up fires once for the entire batch.

        :param int plan_id: RegScale security plan ID
        :param Path path: File or directory containing XCCDF XML files
        :param str parent_module: RegScale parent module name
        :param bool dry_run: If True, parse but do not submit to RegScale
        :return: None
        :rtype: None
        """
        file_paths = _glob_files(Path(path), "*.xml")
        if dry_run:
            return
        cls.sync_assets(plan_id=plan_id, file_paths=file_paths, parent_module=parent_module)
        cls.sync_findings(plan_id=plan_id, file_paths=file_paths, parent_module=parent_module)

    @classmethod
    def sync_csv(cls, plan_id: int, path: Path, parent_module: str = "securityplans", dry_run: bool = False) -> None:
        """Import a CSV export file (or directory of CSV files) into RegScale.

        Collects all matching files first, then issues a single sync_assets and
        sync_findings call so the mop-up fires once for the entire batch.

        :param int plan_id: RegScale security plan ID
        :param Path path: File or directory containing CSV files
        :param str parent_module: RegScale parent module name
        :param bool dry_run: If True, parse but do not submit to RegScale
        :return: None
        :rtype: None
        """
        file_paths = _glob_files(Path(path), "*.csv")
        if dry_run:
            return
        cls.sync_assets(plan_id=plan_id, file_paths=file_paths, parent_module=parent_module)
        cls.sync_findings(plan_id=plan_id, file_paths=file_paths, parent_module=parent_module)
