#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenSCAP compliance integration.

Provides OpenScapComplianceIntegration which maps SCAP rule results to
NIST controls and creates RegScale Assessments, ControlTests, and ControlTestResults.
"""

import logging
import re
from pathlib import Path
from typing import Any, Iterator, List, Optional

from regscale.integrations.commercial.openscap.mappers import (
    lookup_controls_for_cce,
    map_severity,
    should_skip_result,
)
from regscale.integrations.compliance_integration import ComplianceIntegration, ComplianceItem
from regscale.integrations.scanner_integration import IntegrationAsset, IntegrationFinding
from regscale.models.integration_models.openscap import ScapRuleResult

logger = logging.getLogger("regscale")

# Pattern matching NIST 800-53 control IDs (e.g., AC-2, SI-4(1))
_NIST_CONTROL_RE = re.compile(r"^[A-Z]{2}-\d+", re.IGNORECASE)

# XCCDF results that map to compliance PASS
_PASS_RESULTS = frozenset({"pass", "notapplicable"})
# XCCDF results that map to compliance FAIL
_FAIL_RESULTS = frozenset({"fail", "error", "unknown"})


class OpenScapComplianceItem(ComplianceItem):
    """Compliance item derived from an OpenSCAP rule result.

    Implements the ComplianceItem ABC for use with ComplianceIntegration machinery.
    """

    def __init__(
        self,
        rule_result: ScapRuleResult,
        control_id: str,
        framework: str,
        scap_asset_fqdn: str = "",
        scap_asset_guid: str = "",
    ) -> None:
        """Initialise a compliance item.

        :param ScapRuleResult rule_result: The parsed SCAP rule result
        :param str control_id: Resolved NIST control ID
        :param str framework: Compliance framework name
        :param str scap_asset_fqdn: Asset FQDN for resource identification
        :param str scap_asset_guid: Asset motherboard GUID for resource identification
        """
        self._rule_result = rule_result
        self._control_id = control_id
        self._framework = framework
        self._scap_asset_fqdn = scap_asset_fqdn
        self._scap_asset_guid = scap_asset_guid

    @property
    def resource_id(self) -> str:
        """Unique identifier for the assessed resource.

        :return: Motherboard GUID if available, else FQDN, else placeholder
        :rtype: str
        """
        return self._scap_asset_guid or self._scap_asset_fqdn or self._rule_result.asset_fqdn or "openscap-target"

    @property
    def resource_name(self) -> str:
        """Human-readable resource name.

        :return: FQDN or placeholder string
        :rtype: str
        """
        return self._scap_asset_fqdn or self._rule_result.asset_fqdn or "OpenSCAP target"

    @property
    def control_id(self) -> str:
        """NIST control ID for this compliance check.

        :return: Control ID string
        :rtype: str
        """
        return self._control_id

    @property
    def compliance_result(self) -> str:
        """Compliance result string (PASS or FAIL).

        :return: "PASS" or "FAIL"
        :rtype: str
        """
        return "PASS" if self._rule_result.result in _PASS_RESULTS else "FAIL"

    @property
    def severity(self) -> Optional[str]:
        """Severity of the compliance check.

        :return: Severity string derived from XCCDF severity
        :rtype: Optional[str]
        """
        return map_severity(self._rule_result.severity).name

    @property
    def description(self) -> str:
        """HTML-formatted description combining rule title and description.

        :return: HTML description string
        :rtype: str
        """
        title = self._rule_result.rule_title or self._rule_result.rule_id
        body = self._rule_result.description or ""
        return f"<strong>{title}</strong><br>{body}" if body else f"<strong>{title}</strong>"

    @property
    def framework(self) -> str:
        """Compliance framework name.

        :return: Framework identifier string
        :rtype: str
        """
        return self._framework


def _extract_nist_controls_from_references(references: List[str]) -> List[str]:
    """Return NIST control IDs from a list of reference strings.

    :param List[str] references: Reference strings from xccdf:reference elements
    :return: Filtered list of NIST control ID strings
    :rtype: List[str]
    """
    return [ref for ref in references if _NIST_CONTROL_RE.match(ref)]


def _resolve_control_ids_for_result(rule_result: ScapRuleResult, cce_override_path: Optional[str] = None) -> List[str]:
    """Resolve NIST control IDs for a rule result using references then CCE lookup.

    Priority:
    1. xccdf:reference elements matching NIST control pattern
    2. CCE identifier → cce_to_nist.yaml lookup
    3. Empty list (rule not linked to any control)

    :param ScapRuleResult rule_result: Rule result to resolve
    :param Optional[str] cce_override_path: Path to operator CCE override YAML
    :return: Deduplicated list of NIST control ID strings
    :rtype: List[str]
    """
    nist_refs = _extract_nist_controls_from_references(rule_result.references)
    if nist_refs:
        return list(dict.fromkeys(nist_refs))
    for ident in rule_result.idents:
        if ident.upper().startswith("CCE-"):
            controls = lookup_controls_for_cce(ident, override_path=cce_override_path)
            if controls:
                return list(controls)
    return []


class OpenScapComplianceIntegration(ComplianceIntegration):
    """Compliance integration for OpenSCAP scan artifacts.

    Streams rule results, resolves each to NIST control IDs, and populates
    passing_controls / failing_controls / not_applicable_controls dicts.
    The base class ComplianceIntegration handles all assessment/test/result creation.

    :param int plan_id: RegScale security plan ID
    :param Path file_path: Path to the ARF or XCCDF scan file
    :param str framework: Compliance framework name (default: "NIST800-53R5")
    :param Optional[str] cce_override_path: Operator-supplied CCE→NIST YAML path
    """

    title = "OpenSCAP"
    asset_identifier_field = "otherTrackingNumber"

    def __init__(
        self,
        plan_id: int,
        file_path: Optional[Path] = None,
        framework: str = "NIST800-53R5",
        cce_override_path: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Initialise the OpenSCAP compliance integration.

        :param int plan_id: RegScale security plan ID
        :param Optional[Path] file_path: Path to ARF or XCCDF scan file
        :param str framework: Compliance framework name
        :param Optional[str] cce_override_path: Path to operator CCE override YAML
        :param kwargs: Additional keyword arguments passed to ComplianceIntegration
        """
        super().__init__(plan_id=plan_id, framework=framework, **kwargs)
        self._file_path = file_path
        self._cce_override_path = cce_override_path
        self._parser: Any = None
        if file_path is not None:
            self._parser = self._build_parser(file_path)

    @staticmethod
    def _build_parser(file_path: Path) -> Any:
        """Build the appropriate parser for the given file.

        :param Path file_path: Path to scan file
        :return: Parser instance
        :rtype: Any
        """
        from regscale.integrations.commercial.openscap.scanner import _detect_format, _make_parser

        fmt = _detect_format(file_path)
        return _make_parser(file_path, fmt)

    def fetch_compliance_data(self) -> List[Any]:
        """Return empty list — compliance data is processed directly via stream.

        The base class calls process_compliance_data() which streams directly.
        This method satisfies the abstract interface.

        :return: Empty list
        :rtype: List[Any]
        """
        return []

    def create_compliance_item(self, raw_data: Any) -> ComplianceItem:
        """Not used — compliance items are created inline in process_compliance_data().

        :param Any raw_data: Unused
        :return: Never called in the streaming path
        :rtype: ComplianceItem
        :raises NotImplementedError: Always
        """
        raise NotImplementedError("OpenSCAP uses direct streaming via process_compliance_data()")

    def process_compliance_data(self) -> None:
        """Stream rule results and populate passing/failing/not_applicable control buckets.

        Overrides the base class implementation to use streaming rather than bulk fetch.
        For each rule result:
        1. Resolve to NIST control IDs via references then CCE lookup
        2. Route to the appropriate bucket based on result (pass/fail/notapplicable)

        :return: None
        :rtype: None
        """
        logger.info("Processing OpenSCAP compliance data...")
        self._reset_compliance_state()
        if self._parser is None:
            logger.warning("No parser configured — skipping compliance data processing")
            return
        count = 0
        skipped = 0
        for rule_result in self._parser.stream_results():
            if should_skip_result(rule_result.result):
                skipped += 1
                continue
            control_ids = _resolve_control_ids_for_result(rule_result, self._cce_override_path)
            if not control_ids:
                logger.debug("Rule %s has no resolved NIST controls — skipping compliance routing", rule_result.rule_id)
                skipped += 1
                continue
            for ctrl_id in control_ids:
                item = OpenScapComplianceItem(
                    rule_result=rule_result,
                    control_id=ctrl_id,
                    framework=self.framework,
                    scap_asset_fqdn=rule_result.asset_fqdn,
                )
                self._route_compliance_item(item)
                count += 1
        logger.info(
            "OpenSCAP compliance processing: %d items routed, %d skipped",
            count,
            skipped,
        )

    def _route_compliance_item(self, item: OpenScapComplianceItem) -> None:
        """Route a compliance item to the appropriate bucket.

        :param OpenScapComplianceItem item: Compliance item to route
        :return: None
        :rtype: None
        """
        ctrl_key = item.control_id
        result = item._rule_result.result
        if result == "notapplicable":
            self.not_applicable_controls[ctrl_key] = item
        elif result in _FAIL_RESULTS:
            self.failing_controls[ctrl_key] = item
        else:
            if ctrl_key not in self.failing_controls:
                self.passing_controls[ctrl_key] = item

    def fetch_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """Yield assets from the scan file (ARF only).

        :yield: IntegrationAsset instances
        :rtype: Iterator[IntegrationAsset]
        """
        from regscale.integrations.commercial.openscap.mappers import scap_asset_to_integration_asset

        if self._parser is None:
            return
        for scap_asset in self._parser.stream_assets():
            yield scap_asset_to_integration_asset(scap_asset)

    def fetch_findings(self, **kwargs) -> Iterator[IntegrationFinding]:
        """Yield findings for failed/error/unknown compliance items.

        :yield: IntegrationFinding instances
        :rtype: Iterator[IntegrationFinding]
        """
        from regscale.integrations.commercial.openscap.mappers import (
            rule_result_to_finding,
            should_skip_result,
        )

        if self._parser is None:
            return
        for rule_result in self._parser.stream_results():
            if should_skip_result(rule_result.result):
                continue
            yield rule_result_to_finding(rule_result, rule_result.asset_fqdn or "")

    @classmethod
    def run_sync_compliance(
        cls,
        plan_id: int,
        file_path: Path,
        framework: str = "NIST800-53R5",
        cce_override_path: Optional[str] = None,
    ) -> None:
        """Class-method entry point for CLI commands.

        :param int plan_id: RegScale security plan ID
        :param Path file_path: Path to ARF or XCCDF scan file
        :param str framework: Compliance framework name
        :param Optional[str] cce_override_path: Operator CCE override YAML path
        :return: None
        :rtype: None
        """
        integration = cls(
            plan_id=plan_id,
            file_path=file_path,
            framework=framework,
            cce_override_path=cce_override_path,
        )
        integration.sync_compliance()
