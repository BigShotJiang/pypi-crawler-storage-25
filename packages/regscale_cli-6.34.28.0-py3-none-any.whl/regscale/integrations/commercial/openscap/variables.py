#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenSCAP integration configuration variables.

Documents all init.yaml keys consumed by the OpenSCAP integration.
"""

from regscale.core.app.utils.variables import RsVariablesMeta, RsVariableType


class OpenScapVariables(metaclass=RsVariablesMeta):
    """OpenSCAP integration configuration variables.

    All variables are read from init.yaml or matching environment variables.

    Attributes:
        openscapCceNistOverridePath: Path to a custom CCE-to-NIST YAML override file.
        openscapComplianceFramework: Default compliance framework for sync_compliance when not auto-detected.
    """

    # Optional path to operator-supplied CCE→NIST mapping override
    openscapCceNistOverridePath: RsVariableType(  # type: ignore # noqa: F722,F821
        str, "/path/to/custom_cce_to_nist.yaml", required=False
    )

    # Compliance framework identifier; used by sync_compliance when not auto-detected from SSP
    openscapComplianceFramework: RsVariableType(  # type: ignore # noqa: F722,F821
        str, "NIST800-53R5", required=False, default="NIST800-53R5"
    )
