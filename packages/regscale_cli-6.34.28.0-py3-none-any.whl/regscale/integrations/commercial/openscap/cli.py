#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenSCAP CLI commands.

All scanner/integration class imports are deferred inside command bodies
to enforce lazy loading and avoid slowing CLI startup.
"""

import logging
import tempfile
from pathlib import Path
from typing import Optional

import click

from regscale.core.app.utils.file_utils import download_from_s3

logger = logging.getLogger("regscale")

_PATH_HELP_XML = "ARF/XCCDF XML file or directory of .xml files (mutually exclusive with --s3_bucket)."
_PATH_HELP_CSV = "CSV export file or directory of .csv files (mutually exclusive with --s3_bucket)."
_S3_BUCKET_HELP = "S3 bucket to download scan files from (mutually exclusive with --path)."
_S3_PREFIX_HELP = "Prefix (folder path) within the S3 bucket."
_AWS_PROFILE_HELP = "AWS profile for S3 access. Cred priority: direct keys > profile > init.yaml config."
_AWS_KEY_HELP = "AWS access key ID for S3 access (overrides profile and config)."
_AWS_SECRET_HELP = "AWS secret access key for S3 access (overrides profile and config)."
_AWS_TOKEN_HELP = "AWS session token for temporary S3 credentials (optional)."


def _validate_path_or_s3(path: Optional[str], s3_bucket: Optional[str]) -> None:
    """Validate that exactly one of --path or --s3_bucket is provided.

    :param Optional[str] path: Local file or directory path
    :param Optional[str] s3_bucket: S3 bucket name
    :raises click.UsageError: When neither or both are supplied
    :return: None
    :rtype: None
    """
    if path and s3_bucket:
        raise click.UsageError("--path and --s3_bucket are mutually exclusive. Provide exactly one.")
    if not path and not s3_bucket:
        raise click.UsageError("One of --path or --s3_bucket must be provided.")


def _resolve_local_path(
    path: Optional[str],
    s3_bucket: Optional[str],
    s3_prefix: str,
    aws_profile: Optional[str],
    aws_access_key_id: Optional[str],
    aws_secret_access_key: Optional[str],
    aws_session_token: Optional[str],
    extension: str,
) -> tuple:
    """Download S3 files to a temp dir if needed; return (resolved_path, tmp_dir).

    When S3 is used, files are downloaded and the returned tmp_dir context
    manager must be cleaned up by the caller.  When local path is used,
    tmp_dir is None.

    :param Optional[str] path: Local file or directory path
    :param Optional[str] s3_bucket: S3 bucket name
    :param str s3_prefix: S3 key prefix
    :param Optional[str] aws_profile: AWS named profile
    :param Optional[str] aws_access_key_id: AWS access key ID
    :param Optional[str] aws_secret_access_key: AWS secret access key
    :param Optional[str] aws_session_token: AWS session token
    :param str extension: File extension to filter in the temp dir (e.g. ".xml")
    :return: Tuple of (resolved Path, TemporaryDirectory or None)
    :rtype: tuple
    """
    if path:
        return Path(path), None

    tmp_dir = tempfile.TemporaryDirectory(prefix="openscap_s3_")
    tmp_path = Path(tmp_dir.name)
    logger.info("Downloading OpenSCAP files from s3://%s/%s to %s", s3_bucket, s3_prefix, tmp_path)
    download_from_s3(
        bucket=s3_bucket,
        prefix=s3_prefix,
        local_path=tmp_path,
        aws_profile=aws_profile,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        aws_session_token=aws_session_token,
    )
    matching = list(tmp_path.rglob(f"*{extension}"))
    if not matching:
        logger.warning("No %s files found in s3://%s/%s after download.", extension, s3_bucket, s3_prefix)
    return tmp_path, tmp_dir


def _s3_options(func):
    """Decorator that adds S3 + AWS credential options to a Click command.

    :param func: The click command function to decorate
    :return: The decorated function with S3 options attached
    """
    func = click.option(
        "--s3_bucket",
        "--s3-bucket",
        default=None,
        required=False,
        help=_S3_BUCKET_HELP,
        envvar="OPENSCAP_S3_BUCKET",
    )(func)
    func = click.option(
        "--s3_prefix",
        "--s3-prefix",
        default="",
        required=False,
        help=_S3_PREFIX_HELP,
        envvar="OPENSCAP_S3_PREFIX",
    )(func)
    func = click.option(
        "--aws_profile",
        "--aws-profile",
        default=None,
        required=False,
        help=_AWS_PROFILE_HELP,
        envvar="AWS_PROFILE",
    )(func)
    func = click.option(
        "--aws_access_key_id",
        "--aws-access-key-id",
        default=None,
        required=False,
        help=_AWS_KEY_HELP,
        envvar="AWS_ACCESS_KEY_ID",
    )(func)
    func = click.option(
        "--aws_secret_access_key",
        "--aws-secret-access-key",
        default=None,
        required=False,
        help=_AWS_SECRET_HELP,
        envvar="AWS_SECRET_ACCESS_KEY",
    )(func)
    func = click.option(
        "--aws_session_token",
        "--aws-session-token",
        default=None,
        required=False,
        help=_AWS_TOKEN_HELP,
        envvar="AWS_SESSION_TOKEN",
    )(func)
    return func


def _common_options(path_help: str):
    """Decorator factory that adds shared --path, --regscale_id, and --regscale_module options.

    :param str path_help: Help text for the --path option (differs per file type)
    :return: A decorator that applies the three shared click options to a command
    """

    def decorator(func):
        func = click.option(
            "--regscale_module",
            required=True,
            prompt=True,
            default="securityplans",
            show_default=True,
            help="RegScale parent module name.",
        )(func)
        func = click.option("--regscale_id", required=True, prompt=True, type=int, help="Target RegScale record ID.")(
            func
        )
        func = click.option(
            "--path",
            default=None,
            required=False,
            type=click.Path(exists=False),
            help=path_help,
        )(func)
        return func

    return decorator


@click.command(name="import_arf")
@_common_options(_PATH_HELP_XML)
@_s3_options
def import_arf(
    path: Optional[str],
    regscale_id: int,
    regscale_module: str,
    s3_bucket: Optional[str],
    s3_prefix: str,
    aws_profile: Optional[str],
    aws_access_key_id: Optional[str],
    aws_secret_access_key: Optional[str],
    aws_session_token: Optional[str],
) -> None:
    """Import OpenSCAP ARF (Asset Reporting Format) scan results into RegScale."""
    _validate_path_or_s3(path, s3_bucket)
    from regscale.integrations.commercial.openscap.scanner import OpenScapScanner

    resolved_path, tmp_dir = _resolve_local_path(
        path, s3_bucket, s3_prefix, aws_profile, aws_access_key_id, aws_secret_access_key, aws_session_token, ".xml"
    )
    try:
        OpenScapScanner.sync_arf(plan_id=regscale_id, path=resolved_path, parent_module=regscale_module)
    finally:
        if tmp_dir is not None:
            tmp_dir.cleanup()


@click.command(name="import_xccdf")
@_common_options(_PATH_HELP_XML)
@_s3_options
def import_xccdf(
    path: Optional[str],
    regscale_id: int,
    regscale_module: str,
    s3_bucket: Optional[str],
    s3_prefix: str,
    aws_profile: Optional[str],
    aws_access_key_id: Optional[str],
    aws_secret_access_key: Optional[str],
    aws_session_token: Optional[str],
) -> None:
    """Import standalone OpenSCAP XCCDF results into RegScale."""
    _validate_path_or_s3(path, s3_bucket)
    from regscale.integrations.commercial.openscap.scanner import OpenScapScanner

    resolved_path, tmp_dir = _resolve_local_path(
        path, s3_bucket, s3_prefix, aws_profile, aws_access_key_id, aws_secret_access_key, aws_session_token, ".xml"
    )
    try:
        OpenScapScanner.sync_xccdf(plan_id=regscale_id, path=resolved_path, parent_module=regscale_module)
    finally:
        if tmp_dir is not None:
            tmp_dir.cleanup()


@click.command(name="import_csv")
@_common_options(_PATH_HELP_CSV)
@_s3_options
def import_csv(
    path: Optional[str],
    regscale_id: int,
    regscale_module: str,
    s3_bucket: Optional[str],
    s3_prefix: str,
    aws_profile: Optional[str],
    aws_access_key_id: Optional[str],
    aws_secret_access_key: Optional[str],
    aws_session_token: Optional[str],
) -> None:
    """Import OpenSCAP CSV export results into RegScale."""
    _validate_path_or_s3(path, s3_bucket)
    from regscale.integrations.commercial.openscap.scanner import OpenScapScanner

    resolved_path, tmp_dir = _resolve_local_path(
        path, s3_bucket, s3_prefix, aws_profile, aws_access_key_id, aws_secret_access_key, aws_session_token, ".csv"
    )
    try:
        OpenScapScanner.sync_csv(plan_id=regscale_id, path=resolved_path, parent_module=regscale_module)
    finally:
        if tmp_dir is not None:
            tmp_dir.cleanup()


@click.command(name="sync_compliance")
@click.option("--path", required=True, type=click.Path(exists=True), help="ARF or XCCDF scan file for compliance sync.")
@click.option("--regscale_id", required=True, prompt=True, type=int, help="SSP ID in RegScale.")
@click.option(
    "--framework",
    default=None,
    show_default=False,
    help='Override compliance framework (e.g. "NIST800-53R5"). Auto-detected from SSP when omitted.',
)
def sync_compliance(path: str, regscale_id: int, framework: str) -> None:
    """Sync OpenSCAP compliance results as control assessments in RegScale."""
    from regscale.integrations.commercial.openscap.compliance import OpenScapComplianceIntegration
    from regscale.integrations.commercial.openscap.variables import OpenScapVariables

    effective_framework = framework or OpenScapVariables.openscapComplianceFramework
    cce_override = getattr(OpenScapVariables, "openscapCceNistOverridePath", None)
    OpenScapComplianceIntegration.run_sync_compliance(
        plan_id=regscale_id,
        file_path=Path(path),
        framework=effective_framework,
        cce_override_path=cce_override or None,
    )
