#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenSCAP field mapping functions.

Pure, stateless functions that convert SCAP data structures into RegScale
IntegrationFinding and IntegrationAsset objects.

Key mappings:
  - xccdf:rule-result/@result → IssueStatus
  - xccdf:Rule/@severity → IssueSeverity
  - CPE string prefix → AssetOperatingSystem
  - ScapRuleResult → IntegrationFinding
  - ScapAsset → IntegrationAsset
"""

import functools
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import yaml

from regscale.integrations.scanner_integration import IntegrationAsset, IntegrationFinding
from regscale.models import regscale_models

logger = logging.getLogger("regscale")

# ---------------------------------------------------------------------------
# Result → IssueStatus mapping
# None means "skip this result entirely — do not create a finding".
# Only actual problems (fail/error/unknown) produce vulnerabilities and issues.
# Compliant (pass) and not-applicable results are skipped here; they can be
# tracked through ``sync_compliance`` as control assessments instead.
# ---------------------------------------------------------------------------
XCCDF_RESULT_STATUS_MAP: Dict[str, Optional[regscale_models.IssueStatus]] = {
    "pass": None,
    "fail": regscale_models.IssueStatus.Open,
    "error": regscale_models.IssueStatus.Open,
    "unknown": regscale_models.IssueStatus.Open,
    "notapplicable": None,
    "notchecked": None,
    "notselected": None,
}

# ---------------------------------------------------------------------------
# Rule severity → IssueSeverity mapping
# ---------------------------------------------------------------------------
XCCDF_SEVERITY_MAP: Dict[str, regscale_models.IssueSeverity] = {
    "unknown": regscale_models.IssueSeverity.Low,
    "info": regscale_models.IssueSeverity.Low,
    "low": regscale_models.IssueSeverity.Low,
    "medium": regscale_models.IssueSeverity.Moderate,
    "high": regscale_models.IssueSeverity.High,
    "critical": regscale_models.IssueSeverity.Critical,
}

# ---------------------------------------------------------------------------
# CPE string prefix → AssetOperatingSystem (first-match, ordered)
# ---------------------------------------------------------------------------
CPE_OS_MAP: List[Tuple[str, regscale_models.AssetOperatingSystem]] = [
    ("cpe:/o:redhat", regscale_models.AssetOperatingSystem.Linux),
    ("cpe:/o:centos", regscale_models.AssetOperatingSystem.Linux),
    ("cpe:/o:fedora", regscale_models.AssetOperatingSystem.Linux),
    ("cpe:/o:ubuntu", regscale_models.AssetOperatingSystem.Linux),
    ("cpe:/o:debian", regscale_models.AssetOperatingSystem.Linux),
    ("cpe:/o:suse", regscale_models.AssetOperatingSystem.Linux),
    ("cpe:/o:microsoft", regscale_models.AssetOperatingSystem.WindowsServer),
    ("cpe:/o:apple:macosx", regscale_models.AssetOperatingSystem.MacOSX),
]

_MAX_TITLE_LEN = 450
_ERROR_NOTICE = " (Check returned error/unknown — manual review required.)"
_UNKNOWN_NOTICE = " (Check returned error/unknown — manual review required.)"


@functools.lru_cache(maxsize=1)
def _load_cce_nist_map(override_path: Optional[str] = None) -> Dict[str, List[str]]:
    """Load CCE→NIST control mapping from YAML, cached after first load.

    :param Optional[str] override_path: Path to operator-supplied override YAML (or None for bundled)
    :return: Dict mapping CCE string to list of NIST control IDs
    :rtype: Dict[str, List[str]]
    """
    if override_path:
        path = Path(override_path)
    else:
        path = Path(__file__).parent / "mappings" / "cce_to_nist.yaml"
    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return data
    except FileNotFoundError:
        logger.warning("CCE-to-NIST mapping file not found: %s", path)
        return {}
    except Exception as exc:
        logger.warning("Failed to load CCE-to-NIST mapping: %s", exc)
        return {}


def cpe_to_os(cpe: str) -> regscale_models.AssetOperatingSystem:
    """Map a CPE string to AssetOperatingSystem via prefix matching.

    :param str cpe: CPE identifier string
    :return: Matched AssetOperatingSystem or Other if no match
    :rtype: regscale_models.AssetOperatingSystem
    """
    cpe_lower = (cpe or "").lower()
    for prefix, os_enum in CPE_OS_MAP:
        if cpe_lower.startswith(prefix):
            return os_enum
    return regscale_models.AssetOperatingSystem.Other


def map_severity(severity_str: str) -> regscale_models.IssueSeverity:
    """Map an XCCDF severity string to IssueSeverity.

    :param str severity_str: XCCDF severity value (unknown, info, low, medium, high, critical)
    :return: Corresponding IssueSeverity enum value
    :rtype: regscale_models.IssueSeverity
    """
    return XCCDF_SEVERITY_MAP.get((severity_str or "unknown").lower(), regscale_models.IssueSeverity.Low)


def should_skip_result(result: str) -> bool:
    """Return True if a rule-result should be omitted from all outputs.

    notchecked and notselected results are skipped entirely.

    :param str result: XCCDF result string
    :return: True if the result should be skipped
    :rtype: bool
    """
    return XCCDF_RESULT_STATUS_MAP.get((result or "").lower()) is None


def _build_plugin_name(rule_id: str, idents: List[str]) -> str:
    """Determine plugin_name for a finding — must be unique per rule.

    Uses the first CCE ident if present, otherwise falls back to rule_id.

    :param str rule_id: Full XCCDF rule ID string
    :param List[str] idents: List of xccdf:ident values (CCE, OVAL, etc.)
    :return: Plugin name string
    :rtype: str
    """
    for ident in idents:
        if ident.upper().startswith("CCE-"):
            return ident
    return rule_id


def _extract_cve(idents: List[str], references: List[str]) -> Optional[str]:
    """Return the first CVE identifier found in idents or references, or None.

    SCAP vulnerability-focused rules (as opposed to configuration rules) carry
    their CVEs under ``<xccdf:ident system="http://cve.mitre.org">`` and/or
    ``<xccdf:reference>``. We scan both sources so CVE-bearing rules map to a
    proper CVE-keyed Vulnerability record in RegScale (which in turn enables
    KEV enrichment, CVE-based mop-up matching, and the ``{CVE}: {title}``
    issue-title format the server applies when a CVE is present).

    :param List[str] idents: Rule identifiers (xccdf:ident text)
    :param List[str] references: Rule references (xccdf:reference text)
    :return: First CVE-formatted string found (uppercased ``CVE-YYYY-NNNN``), or None
    :rtype: Optional[str]
    """
    for value in (*idents, *references):
        stripped = (value or "").strip()
        if stripped.upper().startswith("CVE-"):
            return stripped
    return None


def _enrich_description(description: str, result: str) -> str:
    """Append a notice for error/unknown results.

    :param str description: Original description text
    :param str result: XCCDF result string
    :return: Enriched description
    :rtype: str
    """
    if result in ("error", "unknown"):
        return description + _ERROR_NOTICE
    return description


def rule_result_to_finding(rule_result, asset_identifier: str = "") -> IntegrationFinding:
    """Convert a ScapRuleResult to an IntegrationFinding.

    :param ScapRuleResult rule_result: Parsed SCAP rule result
    :param str asset_identifier: Asset identifier to associate with the finding
    :return: IntegrationFinding ready for RegScale ingestion
    :rtype: IntegrationFinding
    """

    # ``.get(key, default)`` returns the mapped value even when it is None
    # (``pass``/``notapplicable``/``notchecked`` map to None so the scanner
    # skips them via ``should_skip_result``).  If a caller reaches the
    # mapper anyway, fall back to Open so the record is not dropped silently.
    status = XCCDF_RESULT_STATUS_MAP.get(rule_result.result) or regscale_models.IssueStatus.Open
    severity = map_severity(rule_result.severity)
    plugin_name = _build_plugin_name(rule_result.rule_id, rule_result.idents)
    title = (rule_result.rule_title or rule_result.rule_id)[:_MAX_TITLE_LEN]
    description = _enrich_description(rule_result.description, rule_result.result)
    control_labels = list(dict.fromkeys(rule_result.references))
    effective_asset_id = asset_identifier or rule_result.asset_fqdn or ""
    cve = _extract_cve(rule_result.idents, rule_result.references)
    # external_id identifies the *vulnerability* (the rule itself), not a
    # vuln-on-host instance. Matches Nessus's ``{plugin_id}_{cve}`` pattern
    # when a CVE is present so CVE-based mop-up matching also works; otherwise
    # falls back to the rule id alone (OpenSCAP configuration-compliance rules
    # typically have no CVE and are uniquely keyed by rule_id). The server
    # consolidates one vulnerability across many assets via the separate
    # ``asset_identifier`` array on the finding.
    external_id = f"openscap_{rule_result.rule_id}_{cve}" if cve else f"openscap_{rule_result.rule_id}"
    return IntegrationFinding(
        control_labels=control_labels,
        title=title,
        category="OpenSCAP",
        plugin_name=plugin_name,
        severity=severity,
        description=description,
        status=status,
        rule_id=rule_result.rule_id,
        plugin_id=rule_result.rule_id,
        cve=cve,
        external_id=external_id,
        asset_identifier=effective_asset_id,
        ip_address=rule_result.asset_ip or None,
        source_report=rule_result.check_content_ref or None,
        recommendation_for_mitigation=rule_result.fix_text,
    )


def scap_asset_to_integration_asset(scap_asset) -> IntegrationAsset:
    """Convert a ScapAsset to an IntegrationAsset.

    Prefers motherboard_guid as identifier when present, falls back to fqdn.
    ``other_tracking_number`` is always set to the same value as ``identifier``
    so that vulnerability-to-asset mapping (which uses ``otherTrackingNumber``
    as the default ``assetIdentifierFieldName``) resolves correctly regardless
    of whether the source data includes a motherboard GUID.

    :param ScapAsset scap_asset: Parsed SCAP asset
    :return: IntegrationAsset for RegScale ingestion
    :rtype: IntegrationAsset
    """
    # Prefer FQDN as the identifier across all three formats (ARF, XCCDF, CSV).
    # Only ARF ships a motherboard GUID, so using that as the identifier creates
    # a second asset record when the same host is re-imported from XCCDF or CSV.
    # Falling back to motherboard_guid keeps us resilient when FQDN is missing.
    identifier = scap_asset.fqdn or scap_asset.motherboard_guid or "unknown"
    name = scap_asset.fqdn or identifier
    os_enum = cpe_to_os(scap_asset.cpe) if scap_asset.cpe else None
    return IntegrationAsset(
        name=name,
        identifier=identifier,
        asset_type="Server",
        asset_category="Hardware",
        fqdn=scap_asset.fqdn or None,
        ip_address=scap_asset.ipv4 or None,
        ipv6_address=scap_asset.ipv6 or None,
        mac_address=scap_asset.mac_address or None,
        other_tracking_number=identifier,
        cpe=scap_asset.cpe or None,
        operating_system=os_enum,
        scanning_tool="openscap",
        is_virtual=False,
    )


def lookup_controls_for_cce(cce: str, override_path: Optional[str] = None) -> List[str]:
    """Return NIST control IDs for a CCE identifier from the bundled or override mapping.

    :param str cce: CCE identifier string (e.g., "CCE-27002-5")
    :param Optional[str] override_path: Path to operator-supplied override YAML
    :return: List of NIST control ID strings
    :rtype: List[str]
    """
    mapping = _load_cce_nist_map(override_path)
    return mapping.get(cce, [])
