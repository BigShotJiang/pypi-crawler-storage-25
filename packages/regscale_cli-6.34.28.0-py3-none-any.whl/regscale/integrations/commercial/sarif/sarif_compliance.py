#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SARIF Compliance Integration for RegScale CLI.

This module provides compliance posture management by mapping SARIF static analysis
findings to security controls and creating assessments in RegScale.
"""

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, List, Optional, Union

import click

from regscale.integrations.compliance_integration import (
    ComplianceIntegration,
    ComplianceItem,
)
from regscale.integrations.scanner_integration import IntegrationAsset, IntegrationFinding
from regscale.models.regscale_models import AssetCategory, AssetType
from regscale.models.regscale_models.control_implementation import ControlImplementationStatus

logger = logging.getLogger("regscale")

# HTML tag constants for description formatting
HTML_STRONG_OPEN = "<strong>"
HTML_STRONG_CLOSE = "</strong>"
HTML_P_OPEN = "<p>"
HTML_P_CLOSE = "</p>"

# Regex to extract CWE numeric ID from tag strings like "CWE-89: Improper Neutralization..."
_CWE_TAG_PATTERN = re.compile(r"^CWE-(\d+)", re.IGNORECASE)
HTML_UL_OPEN = "<ul>"
HTML_UL_CLOSE = "</ul>"
HTML_LI_OPEN = "<li>"
HTML_LI_CLOSE = "</li>"
HTML_H3_OPEN = "<h3>"
HTML_H3_CLOSE = "</h3>"
HTML_H4_OPEN = "<h4>"
HTML_H4_CLOSE = "</h4>"
HTML_BR = "<br>"


@dataclass
class SARIFControlMapping:
    """Configuration for mapping SARIF rules to security controls."""

    # Maps CWE IDs to control IDs (e.g., "CWE-89" -> ["AC-4", "SI-10"])
    cwe_to_controls: Optional[Dict[str, List[str]]] = None
    # Maps OWASP IDs to control IDs (e.g., "A01:2021" -> ["AC-3", "AC-6"])
    owasp_to_controls: Optional[Dict[str, List[str]]] = None
    # Maps rule IDs directly to control IDs
    rule_to_controls: Optional[Dict[str, List[str]]] = None


class SARIFComplianceItem(ComplianceItem):
    """
    Compliance item from SARIF static analysis finding.

    Represents a control assessment based on SARIF findings. Multiple findings
    can map to a single control, and the control fails if ANY findings exist
    for that control.
    """

    def __init__(
        self,
        control_id: str,
        control_name: str,
        framework: str,
        sarif_findings: List[Dict[str, Any]],
        resource_id: Optional[str] = None,
        resource_name: Optional[str] = None,
    ):
        """
        Initialize from SARIF findings.

        :param str control_id: Control identifier (e.g., AC-4, SI-10)
        :param str control_name: Human-readable control name
        :param str framework: Compliance framework
        :param List[Dict[str, Any]] sarif_findings: SARIF finding results for this control
        :param Optional[str] resource_id: Resource identifier (file/asset ID)
        :param Optional[str] resource_name: Resource name
        """
        self._control_id = control_id
        self._control_name = control_name
        self._framework = framework
        self.sarif_findings = sarif_findings
        self._resource_id = resource_id or ""
        self._resource_name = resource_name or ""

        # Cache for aggregated compliance result
        self._aggregated_compliance_result: Optional[str] = None
        self._result_was_cached = False

    @property
    def resource_id(self) -> str:
        """Unique identifier for the resource being assessed."""
        return self._resource_id

    @property
    def resource_name(self) -> str:
        """Human-readable name of the resource."""
        return self._resource_name

    @property
    def control_id(self) -> str:
        """Control identifier (e.g., AC-3, SI-2)."""
        return self._control_id

    def _aggregate_finding_compliance(self) -> str:
        """
        Aggregate SARIF findings to determine overall control compliance.

        Aggregation Logic:
        1. If ANY finding has error/warning level -> Control FAILS
        2. If ALL findings are note/none or no findings -> Control PASSES

        :return: "PASS" or "FAIL"
        :rtype: str
        """
        if not self.sarif_findings:
            logger.debug(
                "Control %s: No SARIF findings available - PASS by default",
                self.control_id,
            )
            return "PASS"

        fail_count = 0
        pass_count = 0
        total_findings = len(self.sarif_findings)

        for finding in self.sarif_findings:
            level = finding.get("level", "warning").lower()

            # Error, warning, and critical levels indicate failures
            if level in ("error", "warning", "critical"):
                fail_count += 1
            else:
                # Note, none, or other levels are passes
                pass_count += 1

        logger.debug(
            "Control %s finding summary: %d FAIL, %d PASS out of %d total",
            self.control_id,
            fail_count,
            pass_count,
            total_findings,
        )

        # If ANY finding indicates a failure, the control fails
        if fail_count > 0:
            logger.info(
                "Control %s FAILS: %d failing finding(s) out of %d",
                self.control_id,
                fail_count,
                total_findings,
            )
            return "FAIL"

        logger.info(
            "Control %s PASSES: No failing findings (total findings: %d)",
            self.control_id,
            total_findings,
        )
        return "PASS"

    @property
    def compliance_result(self) -> str:
        """
        Result of compliance check (PASS, FAIL).

        Aggregates SARIF findings to determine control-level compliance.

        :return: "PASS" or "FAIL"
        :rtype: str
        """
        # Use cached result if available
        if self._result_was_cached:
            return self._aggregated_compliance_result or "PASS"

        # Aggregate finding compliance checks
        result = self._aggregate_finding_compliance()

        # Cache the result
        self._aggregated_compliance_result = result
        self._result_was_cached = True
        return result

    @property
    def severity(self) -> Optional[str]:
        """Severity level of the compliance violation (if failed)."""
        if self.compliance_result != "FAIL":
            return None

        # Determine severity based on highest severity finding
        severity_map = {
            "critical": 4,
            "error": 3,
            "warning": 2,
            "note": 1,
        }

        max_severity = 0
        for finding in self.sarif_findings:
            level = finding.get("level", "warning").lower()
            severity_val = severity_map.get(level, 2)
            max_severity = max(max_severity, severity_val)

        # Map back to RegScale severity
        severity_reverse_map = {
            4: "Critical",
            3: "High",
            2: "Medium",
            1: "Low",
        }
        return severity_reverse_map.get(max_severity, "Medium")

    @property
    def description(self) -> str:
        """Description of the compliance check using HTML formatting."""
        desc_parts = [
            f"{HTML_H3_OPEN}SARIF Static Analysis compliance assessment for control {self.control_id}{HTML_H3_CLOSE}",
            HTML_P_OPEN,
            f"{HTML_STRONG_OPEN}Control:{HTML_STRONG_CLOSE} {self._control_name}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Framework:{HTML_STRONG_CLOSE} {self._framework}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Total Findings:{HTML_STRONG_CLOSE} {len(self.sarif_findings)}",
            HTML_P_CLOSE,
        ]

        # Add finding summary
        fail_findings = [f for f in self.sarif_findings if f.get("level", "warning").lower() in ("error", "warning")]
        pass_findings = [
            f for f in self.sarif_findings if f.get("level", "warning").lower() not in ("error", "warning")
        ]

        desc_parts.extend(
            [
                f"{HTML_H4_OPEN}Compliance Summary{HTML_H4_CLOSE}",
                HTML_UL_OPEN,
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Failing Findings:{HTML_STRONG_CLOSE} "
                f"{len(fail_findings)}{HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Passing Findings:{HTML_STRONG_CLOSE} "
                f"{len(pass_findings)}{HTML_LI_CLOSE}",
                HTML_UL_CLOSE,
            ]
        )

        # Add failing findings details
        if fail_findings:
            desc_parts.append(f"{HTML_H4_OPEN}Failing Findings (Why This Control Failed){HTML_H4_CLOSE}")
            for idx, finding in enumerate(fail_findings[:10], 1):  # Show up to 10 findings
                rule_id = finding.get("rule_id", "Unknown")
                message = finding.get("message", "")
                level = finding.get("level", "warning")
                location = finding.get("location", "")

                desc_parts.append(
                    '<div style="margin: 10px 0; padding: 10px; background-color: #fff3e0; '
                    'border-left: 3px solid #ff9800;">'
                )
                desc_parts.append(f"{HTML_STRONG_OPEN}Finding #{idx}: {rule_id}{HTML_STRONG_CLOSE}{HTML_BR}")
                desc_parts.append(f"{HTML_STRONG_OPEN}Level:{HTML_STRONG_CLOSE} {level}{HTML_BR}")
                if location:
                    desc_parts.append(f"{HTML_STRONG_OPEN}Location:{HTML_STRONG_CLOSE} {location}{HTML_BR}")
                if message:
                    desc_parts.append(f"{HTML_STRONG_OPEN}Message:{HTML_STRONG_CLOSE} {message}{HTML_BR}")
                desc_parts.append("</div>")

            if len(fail_findings) > 10:
                desc_parts.append(
                    f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Note:{HTML_STRONG_CLOSE} "
                    f"Showing 10 of {len(fail_findings)} failing findings.{HTML_P_CLOSE}"
                )

        return "".join(desc_parts)

    @property
    def framework(self) -> str:
        """Compliance framework (e.g., OWASP, NIST800-53R5)."""
        return self._framework


class SARIFComplianceIntegration(ComplianceIntegration):
    """
    SARIF Compliance Integration for RegScale.

    This integration parses SARIF files from static analysis tools and maps
    findings to security controls for compliance assessment.
    """

    title = "SARIF Static Analysis"

    # CWE-to-ASVS mapping loaded from the generated data file.  The file is
    # produced by tools/asvs_cwe_mapper.py from the enriched ASVS catalog
    # (regscale-catalogs/asvs.json externalMappings).  See REG-21682.
    _ASVS_CWE_MAPPING: Optional[Dict[str, List[str]]] = None

    @classmethod
    def _load_asvs_cwe_mapping(cls) -> Dict[str, List[str]]:
        """
        Load the CWE-to-ASVS mapping from the generated data file.

        The file is produced by ``tools/asvs_cwe_mapper.py`` from the enriched
        ASVS catalog and maps CWE IDs to lists of ASVS control IDs
        (e.g. ``{"CWE-89": ["V5.3.4", "V5.3.5"]}``).

        :return: Dictionary mapping CWE IDs to lists of ASVS control IDs
        :rtype: Dict[str, List[str]]
        """
        if cls._ASVS_CWE_MAPPING is not None:
            return cls._ASVS_CWE_MAPPING

        mapping_file = Path(__file__).parent / "asvs_cwe_mappings.json"
        try:
            with open(mapping_file, encoding="utf-8") as fhandle:
                data = json.load(fhandle)
            cls._ASVS_CWE_MAPPING = data.get("cwe_to_asvs", {})
            logger.info(
                "Loaded ASVS CWE mapping: %d CWEs -> %d control references",
                len(cls._ASVS_CWE_MAPPING),
                sum(len(ids) for ids in cls._ASVS_CWE_MAPPING.values()),
            )
        except FileNotFoundError:
            logger.warning(
                "ASVS CWE mapping file not found: %s. "
                "SARIF compliance sync will not produce any compliance items. "
                "Verify the regscale-cli installation is complete.",
                mapping_file,
            )
            cls._ASVS_CWE_MAPPING = {}
        except (json.JSONDecodeError, KeyError) as exc:
            logger.warning(
                "Failed to parse ASVS CWE mapping file %s: %s. "
                "SARIF compliance sync will not produce any compliance items.",
                mapping_file,
                exc,
            )
            cls._ASVS_CWE_MAPPING = {}

        return cls._ASVS_CWE_MAPPING

    # Status mappings for compliance
    PLANNED_STATUS = ControlImplementationStatus.Planned
    IN_REMEDIATION_STATUS = ControlImplementationStatus.InRemediation

    def __init__(
        self,
        plan_id: int,
        file_path: Union[str, Path],
        catalog_id: Optional[int] = None,
        framework: str = "OWASP",
        create_issues: bool = True,
        update_control_status: bool = True,
        create_poams: bool = False,
        control_mapping: Optional[SARIFControlMapping] = None,
        asset_id: Optional[int] = None,
        parent_module: str = "securityplans",
        dry_run: bool = False,
        offset: Optional[int] = None,
        limit: Optional[int] = None,
        **kwargs,
    ):
        """
        Initialize SARIF compliance integration.

        :param int plan_id: RegScale security plan ID
        :param Union[str, Path] file_path: Path to SARIF file or directory
        :param Optional[int] catalog_id: RegScale catalog ID
        :param str framework: Compliance framework (default: OWASP)
        :param bool create_issues: Whether to create issues for failed compliance
        :param bool update_control_status: Whether to update control implementation status
        :param bool create_poams: Whether to mark issues as POAMs
        :param Optional[SARIFControlMapping] control_mapping: Custom control mappings
        :param Optional[int] asset_id: Asset ID to associate findings with
        :param str parent_module: Parent module type
        :param bool dry_run: If True, report compliance item count without syncing
        :param Optional[int] offset: Skip this many items from the start
        :param Optional[int] limit: Process at most this many items
        :param kwargs: Additional arguments
        """
        super().__init__(
            plan_id=plan_id,
            catalog_id=catalog_id,
            framework=framework,
            create_issues=create_issues,
            update_control_status=update_control_status,
            create_poams=create_poams,
            parent_module=parent_module,
            **kwargs,
        )

        self.file_path = Path(file_path)
        self.asset_id = asset_id
        self.control_mapping = control_mapping or SARIFControlMapping()

        # Initialize CWE to control mappings
        self._cwe_to_controls = self._build_cwe_control_map()

        # Storage for parsed SARIF data
        self._sarif_runs: List[Dict[str, Any]] = []
        self._findings_by_control: Dict[str, List[Dict[str, Any]]] = {}

        # Resource info
        self.resource_id = str(self.file_path.name)
        self.resource_name = f"SARIF Analysis: {self.file_path.name}"

        self.dry_run = dry_run
        self.orchestration_offset = offset
        self.orchestration_limit = limit

        logger.info("Initialized SARIF Compliance Integration")
        logger.info("File path: %s", self.file_path)
        logger.info("Framework: %s", framework)

    def _build_cwe_control_map(self) -> Dict[str, List[str]]:
        """
        Build the CWE to control mapping dictionary.

        Loads the ASVS CWE mapping from the generated data file, then
        applies any custom overrides from the control_mapping configuration.

        :return: Dictionary mapping CWE IDs to lists of ASVS control IDs
        :rtype: Dict[str, List[str]]
        """
        cwe_map = dict(self._load_asvs_cwe_mapping())

        # Override/extend with custom mappings if provided
        if self.control_mapping.cwe_to_controls:
            cwe_map.update(self.control_mapping.cwe_to_controls)

        return cwe_map

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Fetch and parse SARIF data, mapping findings to controls.

        :return: List of raw compliance data (control + SARIF findings)
        :rtype: List[Dict[str, Any]]
        """
        logger.info("Parsing SARIF files for compliance data...")

        try:
            # Load and parse SARIF files
            sarif_files = self._get_sarif_files()
            if not sarif_files:
                logger.warning("No SARIF files found at: %s", self.file_path)
                return []

            # Parse each SARIF file
            all_findings = []
            for sarif_file in sarif_files:
                findings = self._parse_sarif_file(sarif_file)
                all_findings.extend(findings)

            logger.info("Parsed %d findings from %d SARIF file(s)", len(all_findings), len(sarif_files))

            # Group findings by control
            self._findings_by_control = self._group_findings_by_control(all_findings)

            # Build compliance data structure
            compliance_data = self._build_compliance_data()

            logger.info("Generated %d control compliance items from SARIF data", len(compliance_data))
            return compliance_data

        except Exception as e:
            logger.error("Error parsing SARIF files: %s", e)
            return []

    def sync_compliance(self) -> None:
        """
        Sync SARIF compliance data to RegScale with orchestration support.

        Extends the base sync_compliance method to add dry-run and pagination support.

        :return: None
        :rtype: None
        """
        if self.dry_run:
            raw_data = self.fetch_compliance_data()
            click.echo(
                json.dumps(
                    {
                        "integration": self.title,
                        "type": "compliance",
                        "plan_id": self.plan_id,
                        "total_count": len(raw_data),
                        "dry_run": True,
                    }
                )
            )
            return

        if self.orchestration_offset is not None or self.orchestration_limit is not None:
            original_fetch: Callable[[], List[Dict[str, Any]]] = self.fetch_compliance_data
            offset = self.orchestration_offset
            limit = self.orchestration_limit

            def paginated_fetch() -> List[Dict[str, Any]]:
                data = original_fetch()
                if offset is not None:
                    data = data[offset:]
                if limit is not None:
                    data = data[:limit]
                return data

            self.fetch_compliance_data = paginated_fetch  # type: ignore[method-assign]

        super().sync_compliance()

    def _get_sarif_files(self) -> List[Path]:
        """
        Get list of SARIF files to process.

        :return: List of SARIF file paths
        :rtype: List[Path]
        """
        if self.file_path.is_file():
            return [self.file_path]
        if self.file_path.is_dir():
            sarif_files = list(self.file_path.glob("*.sarif"))
            sarif_files.extend(self.file_path.glob("*.sarif.json"))
            return sarif_files
        return []

    def _parse_sarif_file(self, file_path: Path) -> List[Dict[str, Any]]:
        """
        Parse a single SARIF file and extract findings.

        :param Path file_path: Path to the SARIF file
        :return: List of finding dictionaries
        :rtype: List[Dict[str, Any]]
        """
        try:
            with open(file_path, encoding="utf-8") as file:
                sarif_data = json.load(file)

            findings = []
            runs = sarif_data.get("runs", [])

            for run in runs:
                tool_name = run.get("tool", {}).get("driver", {}).get("name", "Unknown Tool")
                rules = self._build_rules_map(run)

                for result in run.get("results", []):
                    finding = self._extract_finding(result, rules, tool_name, file_path)
                    if finding:
                        findings.append(finding)

            logger.debug("Parsed %d findings from %s", len(findings), file_path.name)
            return findings

        except json.JSONDecodeError as e:
            logger.error("Failed to parse SARIF file %s: %s", file_path, e)
            return []
        except Exception as e:
            logger.error("Error processing SARIF file %s: %s", file_path, e)
            return []

    def _build_rules_map(self, run: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """
        Build a mapping of rule IDs to rule definitions.

        :param Dict[str, Any] run: SARIF run object
        :return: Dictionary mapping rule IDs to rule definitions
        :rtype: Dict[str, Dict[str, Any]]
        """
        rules_map = {}
        driver = run.get("tool", {}).get("driver", {})

        for rule in driver.get("rules", []):
            rule_id = rule.get("id", "")
            rules_map[rule_id] = rule

        # Also include rules from extensions
        for extension in run.get("tool", {}).get("extensions", []):
            for rule in extension.get("rules", []):
                rule_id = rule.get("id", "")
                rules_map[rule_id] = rule

        return rules_map

    def _extract_finding(
        self,
        result: Dict[str, Any],
        rules: Dict[str, Dict[str, Any]],
        tool_name: str,
        file_path: Path,
    ) -> Optional[Dict[str, Any]]:
        """
        Extract finding information from a SARIF result.

        :param Dict[str, Any] result: SARIF result object
        :param Dict[str, Dict[str, Any]] rules: Rules mapping
        :param str tool_name: Name of the scanning tool
        :param Path file_path: Source file path
        :return: Finding dictionary or None
        :rtype: Optional[Dict[str, Any]]
        """
        rule_id = result.get("ruleId", "")
        rule = rules.get(rule_id, {})

        # Get message
        message = ""
        if msg := result.get("message"):
            message = msg.get("text", "") or msg.get("markdown", "")

        # Get level (severity)
        level = result.get("level", rule.get("defaultConfiguration", {}).get("level", "warning"))

        # Get location
        location = ""
        locations = result.get("locations", [])
        if locations:
            physical_location = locations[0].get("physicalLocation", {})
            artifact = physical_location.get("artifactLocation", {})
            region = physical_location.get("region", {})

            file_uri = artifact.get("uri", "")
            line = region.get("startLine", 0)
            location = f"{file_uri}:{line}" if line else file_uri

        # Extract CWE and OWASP IDs from rule properties/relationships
        cwe_ids = self._extract_cwe_ids(rule, result)
        owasp_ids = self._extract_owasp_ids(rule, result)

        return {
            "rule_id": rule_id,
            "message": message,
            "level": level,
            "location": location,
            "tool_name": tool_name,
            "source_file": str(file_path),
            "cwe_ids": cwe_ids,
            "owasp_ids": owasp_ids,
            "full_description": rule.get("fullDescription", {}).get("text", ""),
            "help_uri": rule.get("helpUri", ""),
        }

    def _extract_cwe_ids(self, rule: Dict[str, Any], result: Dict[str, Any]) -> List[str]:
        """
        Extract CWE IDs from rule definition and result.

        :param Dict[str, Any] rule: Rule definition
        :param Dict[str, Any] result: Result object
        :return: List of CWE IDs
        :rtype: List[str]
        """
        cwe_ids = []

        # Check rule properties
        properties = rule.get("properties", {})
        if cwe := properties.get("cwe"):
            if isinstance(cwe, list):
                cwe_ids.extend(cwe)
            else:
                cwe_ids.append(str(cwe))

        # Check rule relationships (taxa)
        for relationship in rule.get("relationships", []):
            target = relationship.get("target", {})
            if "cwe" in target.get("toolComponent", {}).get("name", "").lower():
                if target_id := target.get("id"):
                    cwe_ids.append(f"CWE-{target_id}")

        # Check result properties (used by HCL AppScan, Checkmarx, and other tools
        # that embed CWE IDs directly on each result rather than on the rule definition)
        result_props = result.get("properties", {})
        for key in ("CWE_ID", "cwe", "cwe_id", "CWE"):
            if cwe_val := result_props.get(key):
                if isinstance(cwe_val, list):
                    cwe_ids.extend(str(val) for val in cwe_val)
                else:
                    cwe_ids.append(str(cwe_val))
                break  # Only use the first matching key to avoid duplicates

        # Check result taxa
        for taxa in result.get("taxa", []):
            if "cwe" in taxa.get("toolComponent", {}).get("name", "").lower():
                if taxa_id := taxa.get("id"):
                    cwe_ids.append(f"CWE-{taxa_id}")

        # Check rule.properties.tags for CWE references embedded as strings
        # (used by Semgrep and other tools that store "CWE-89: Description..." in tags)
        if not cwe_ids:
            tags = rule.get("properties", {}).get("tags", [])
            for tag in tags:
                if isinstance(tag, str) and tag.upper().startswith("CWE-"):
                    cwe_match = _CWE_TAG_PATTERN.match(tag)
                    if cwe_match:
                        cwe_ids.append(f"CWE-{cwe_match.group(1)}")

        # Normalize CWE IDs
        normalized = []
        for cwe_id in cwe_ids:
            if not cwe_id.startswith("CWE-"):
                cwe_id = f"CWE-{cwe_id}"
            normalized.append(cwe_id)

        return list(set(normalized))

    def _extract_owasp_ids(self, rule: Dict[str, Any], result: Dict[str, Any]) -> List[str]:
        """
        Extract OWASP IDs from rule definition and result.

        :param Dict[str, Any] rule: Rule definition
        :param Dict[str, Any] result: Result object
        :return: List of OWASP IDs
        :rtype: List[str]
        """
        owasp_ids = []

        # Check rule properties
        properties = rule.get("properties", {})
        if owasp := properties.get("owasp"):
            if isinstance(owasp, list):
                owasp_ids.extend(owasp)
            else:
                owasp_ids.append(str(owasp))

        # Check security-severity tags
        tags = properties.get("tags", [])
        for tag in tags:
            if "owasp" in tag.lower() or tag.startswith("A0"):
                owasp_ids.append(tag)

        return list(set(owasp_ids))

    def _group_findings_by_control(self, findings: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Group SARIF findings by control ID.

        :param List[Dict[str, Any]] findings: List of finding dictionaries
        :return: Dictionary mapping control IDs to lists of findings
        :rtype: Dict[str, List[Dict[str, Any]]]
        """
        findings_by_control: Dict[str, List[Dict[str, Any]]] = {}

        for finding in findings:
            control_ids = set()

            # Map CWE IDs to controls
            for cwe_id in finding.get("cwe_ids", []):
                if mapped_controls := self._cwe_to_controls.get(cwe_id):
                    control_ids.update(mapped_controls)

            # NOTE: OWASP IDs from tags (e.g. "OWASP-A03:2021") are no longer
            # used as direct control IDs.  The CWE->ASVS mapping above
            # resolves CWEs to proper ASVS verification requirement IDs
            # (e.g. V5.3.4) that match real catalog controls.

            # Check custom rule mappings
            if self.control_mapping.rule_to_controls:
                rule_id = finding.get("rule_id", "")
                if mapped_controls := self.control_mapping.rule_to_controls.get(rule_id):
                    control_ids.update(mapped_controls)

            # Add finding to each mapped control
            for control_id in control_ids:
                if control_id not in findings_by_control:
                    findings_by_control[control_id] = []
                findings_by_control[control_id].append(finding)

            # Log unmapped findings
            if not control_ids:
                logger.debug(
                    "Finding with rule '%s' could not be mapped to any control (CWEs: %s)",
                    finding.get("rule_id"),
                    finding.get("cwe_ids"),
                )

        logger.info(
            "Mapped %d findings to %d controls",
            len(findings),
            len(findings_by_control),
        )
        return findings_by_control

    def _build_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Build compliance data structure from findings grouped by control.

        Emits one compliance item per control ID that has findings in
        ``_findings_by_control``.  Control IDs are ASVS verification
        requirement IDs (e.g. V5.3.4) produced by the CWE mapping.

        .. note::
            Only controls with findings are emitted (FAIL only).  A SAST tool
            not reporting a CWE does not prove the control passes -- it may
            lack a rule for that weakness.  A future enhancement could infer
            PASS for controls whose CWEs are covered by the tool's rule set
            (inspect SARIF ``tool.driver.rules``).  See REG-21682.

        :return: List of compliance data items
        :rtype: List[Dict[str, Any]]
        """
        compliance_data = []

        for control_id in sorted(self._findings_by_control.keys()):
            control_findings = self._findings_by_control[control_id]

            compliance_data.append(
                {
                    "control_id": control_id,
                    "control_name": f"ASVS {control_id}",
                    "sarif_findings": control_findings,
                    "resource_id": self.resource_id,
                    "resource_name": self.resource_name,
                }
            )

        return compliance_data

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> ComplianceItem:
        """
        Create a ComplianceItem from raw compliance data.

        :param Dict[str, Any] raw_data: Raw compliance data (control + SARIF findings)
        :return: ComplianceItem instance
        :rtype: ComplianceItem
        """
        control_id = raw_data.get("control_id", "")
        control_name = raw_data.get("control_name", "")
        sarif_findings = raw_data.get("sarif_findings", [])
        resource_id = raw_data.get("resource_id")
        resource_name = raw_data.get("resource_name")

        return SARIFComplianceItem(
            control_id=control_id,
            control_name=control_name,
            framework=self.framework,
            sarif_findings=sarif_findings,
            resource_id=resource_id,
            resource_name=resource_name,
        )

    def fetch_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Fetch assets from SARIF data.

        :param kwargs: Additional arguments
        :yield: IntegrationAsset objects
        :return: Iterator of IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        # If an asset ID was provided, use that asset
        if self.asset_id:
            logger.debug("Using existing asset ID: %d", self.asset_id)
            return

        # Create a synthetic asset representing the SARIF scan target
        yield IntegrationAsset(
            name=f"SARIF Scan Target: {self.file_path.name}",
            identifier=str(self.file_path.absolute()),
            asset_type=AssetType.Other,
            asset_category=AssetCategory.Software,
            parent_id=self.plan_id,
            parent_module=self.parent_module,
            component_names=[],
            external_id=str(self.file_path.name),
        )

    def fetch_findings(self, **kwargs) -> Iterator[IntegrationFinding]:
        """
        Fetch findings from SARIF data (for issue creation).

        :param kwargs: Additional arguments
        :yield: IntegrationFinding objects
        :return: Iterator of IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        # Findings are handled through the compliance item mechanism
        # This method can be used to create issues directly from findings
        return iter([])

    def _get_implementation_status_from_result(self, result: str, override: Optional[str] = None) -> str:
        """
        Override base class status mapping for SARIF-specific behavior.

        Per SARIF compliance requirements (REG-21682):
        - "Planned" when no findings found (Pass)
        - "In Remediation" when findings occur (Fail)

        This replaces the dead ``_get_status_for_compliance_result`` method
        that was never called from the assessment flow.

        :param str result: Assessment result ('Pass' or 'Fail')
        :param Optional[str] override: Optional override value
        :return: Implementation status string
        :rtype: str
        """
        if override:
            return override
        if result.lower() in ("pass", "passed", "compliant"):
            return self.PLANNED_STATUS.value
        return self.IN_REMEDIATION_STATUS.value
