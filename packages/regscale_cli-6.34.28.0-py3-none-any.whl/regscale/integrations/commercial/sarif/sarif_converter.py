#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SARIF Converter integration for RegScale CLI"""

import datetime
import json
import logging
import os
from pathlib import Path
from typing import List, Optional

import click

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.models.app_models.click import ssp_or_component_id
from regscale.models.app_models.orchestration_options import orchestration_options

logger = logging.getLogger("regscale")

# Supported frameworks for SARIF compliance
SARIF_SUPPORTED_FRAMEWORKS = ["OWASP", "NIST800-53R5"]


@click.group()
def sarif() -> None:
    """SARIF integration - import vulnerabilities or sync compliance data from static analysis tools."""


@sarif.command(name="import")
@click.option(
    "--file_path",
    "-f",
    type=click.Path(exists=True, file_okay=True, dir_okay=True, path_type=Path),
    help="Path to the SARIF file or a directory of files to convert",
    prompt="Enter the path",
    required=True,
)
@click.option(
    "--asset_id",
    "-id",
    type=click.INT,
    help="The RegScale Asset ID # to import the findings to.",
    prompt="RegScale Asset ID",
    required=True,
)
@click.option(
    "--scan_date",
    "-sd",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the file.",
    required=False,
    default=get_current_datetime("%Y-%m-%d"),
)
@orchestration_options()
def import_sarif(
    file_path: Path,
    asset_id: int,
    scan_date: Optional[datetime.datetime] = None,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
) -> None:
    """Convert a SARIF file(s) to OCSF format using an API converter."""
    process_sarif_files(file_path, asset_id, scan_date, dry_run=dry_run, offset=offset, limit=limit)


def process_sarif_files(
    file_path: Path,
    asset_id: int,
    scan_date: Optional[datetime.datetime],
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
) -> None:
    """
    Process SARIF files for import.

    :param Path file_path: Path to the SARIF file or directory of files
    :param int asset_id: The RegScale Asset ID to import the findings to
    :param Optional[datetime.datetime] scan_date: The scan date of the file
    :param bool dry_run: If True, report file count without importing
    :param Optional[int] offset: Skip this many files from the start
    :param Optional[int] limit: Process at most this many files
    :return: None
    """
    from regscale.integrations.commercial.sarif.sarif_importer import SarifImporter

    if not scan_date:
        scan_date = get_current_datetime()

    if dry_run:
        resolved = Path(file_path)
        sarif_files = [resolved] if resolved.is_file() else list(resolved.glob("*.sarif"))
        click.echo(
            json.dumps(
                {
                    "integration": "SARIF",
                    "type": "import",
                    "total_count": len(sarif_files),
                    "dry_run": True,
                }
            )
        )
        return

    SarifImporter(file_path, asset_id, scan_date=scan_date, offset=offset, limit=limit)


# =============================================================================
# Compliance Sync Commands
# =============================================================================


def _resolve_parent(regscale_ssp_id: Optional[int], component_id: Optional[int]) -> tuple[int, str]:
    """
    Resolve mutually-exclusive --regscale_ssp_id / --component_id into a
    (plan_id, parent_module) pair for the compliance integration.

    :param Optional[int] regscale_ssp_id: SSP ID if provided
    :param Optional[int] component_id: Component ID if provided
    :return: (plan_id, parent_module) where parent_module is "securityplans" or "components"
    :rtype: tuple[int, str]
    :raises click.UsageError: when neither or both are provided
    """
    if component_id is not None and regscale_ssp_id is not None:
        raise click.UsageError("Provide either --regscale_ssp_id or --component_id, not both.")
    if component_id is not None:
        return component_id, "components"
    if regscale_ssp_id is not None:
        return regscale_ssp_id, "securityplans"
    raise click.UsageError("Either --regscale_ssp_id or --component_id must be provided.")


@sarif.command(name="sync_compliance")
@click.option(
    "--file_path",
    "-f",
    type=click.Path(exists=True, file_okay=True, dir_okay=True, path_type=Path),
    help="Path to the SARIF file or directory of files to analyze for compliance",
    prompt="Enter the path to SARIF file(s)",
    required=True,
)
@ssp_or_component_id()
@click.option(
    "--framework",
    type=click.Choice(SARIF_SUPPORTED_FRAMEWORKS, case_sensitive=False),
    default="OWASP",
    help="Compliance framework to sync. Default: OWASP (OWASP Top 10 2021)",
)
@click.option(
    "--create-issues/--no-create-issues",
    default=True,
    help="Create issues for failed compliance controls. Default: True",
)
@click.option(
    "--update-control-status/--no-update-control-status",
    default=True,
    help="Update control implementation status based on compliance results. Default: True",
)
@click.option(
    "--create-poams",
    "-cp",
    is_flag=True,
    default=False,
    help="Mark created issues as POAMs. Default: False",
)
@click.option(
    "--asset_id",
    "-a",
    type=click.INT,
    help="Optional RegScale Asset ID to associate findings with.",
    required=False,
    default=None,
)
@orchestration_options()
def sync_compliance(
    file_path: Path,
    regscale_ssp_id: Optional[int],
    component_id: Optional[int],
    framework: str,
    create_issues: bool,
    update_control_status: bool,
    create_poams: bool,
    asset_id: Optional[int],
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
) -> None:
    """
    Sync SARIF static analysis compliance data to RegScale.

    This command parses SARIF files from static analysis tools and:
    - Maps findings to security controls (OWASP Top 10 or NIST 800-53)
    - Creates control assessments in RegScale based on SARIF findings
    - Creates issues for failed compliance controls (optional)
    - Updates control implementation status (optional):
      - "Planned" when no findings found (PASS)
      - "In Remediation" when findings occur (FAIL)

    Supported Frameworks:
    - OWASP: OWASP Top 10 2021 (default)
    - NIST800-53R5: NIST 800-53 Rev 5

    The integration maps SARIF findings via CWE IDs to the specified framework's
    controls, allowing for automated compliance assessment updates in RegScale.

    The compliance sync target is either a System Security Plan or a Component;
    provide exactly one of --regscale_ssp_id or --component_id.

    Example:
        regscale sarif sync_compliance -f ./scan-results.sarif --regscale_ssp_id 123
        regscale sarif sync_compliance -f ./scan-results.sarif --component_id 456

    SARIF files may include CWE references that automatically map to security controls.
    Tools like CodeQL, Semgrep, and other SAST tools produce SARIF-formatted output.
    """
    from regscale.integrations.commercial.sarif.sarif_compliance import SARIFComplianceIntegration

    plan_id, parent_module = _resolve_parent(regscale_ssp_id, component_id)

    try:
        logger.info("Starting SARIF compliance sync...")
        logger.info("File path: %s", file_path)
        logger.info("RegScale parent: %s id=%d", parent_module, plan_id)
        logger.info("Framework: %s", framework)

        integration = SARIFComplianceIntegration(
            plan_id=plan_id,
            file_path=file_path,
            framework=framework,
            create_issues=create_issues,
            update_control_status=update_control_status,
            create_poams=create_poams,
            asset_id=asset_id,
            parent_module=parent_module,
            dry_run=dry_run,
            offset=offset,
            limit=limit,
        )

        integration.sync_compliance()

        logger.info("SARIF compliance sync completed successfully.")

    except Exception as e:
        logger.error("Error during SARIF compliance sync: %s", e, exc_info=True)
        raise click.ClickException(str(e)) from e


# =============================================================================
# Unified Sync Command (composes import + compliance)
# =============================================================================


def _check_synqly_token_configured() -> bool:
    """
    Return True if ``synqlyAccessToken`` is available via env var or init.yaml.

    The vulnerability import phase calls Synqly to convert SARIF to OCSF. Missing
    token causes ``SarifImporter`` to ``sys.exit`` partway through, which would
    skip the compliance phase and the unified summary. Pre-check so we can fail
    fast with a clean UsageError instead.

    :return: True if a token is configured, False otherwise
    :rtype: bool
    """
    if os.getenv("synqlyAccessToken"):
        return True
    # Lazy-import Application to avoid startup cost when token is already set via env
    from regscale.core.app.application import Application

    return bool(Application().config.get("synqlyAccessToken"))


@sarif.command(name="sync")
@click.option(
    "--file_path",
    "-f",
    type=click.Path(exists=True, file_okay=True, dir_okay=True, path_type=Path),
    help="Path to the SARIF file or directory of files",
    prompt="Enter the path to SARIF file(s)",
    required=True,
)
@click.option(
    "--asset_id",
    type=click.INT,
    help="RegScale Asset ID. If provided, runs the vulnerability import phase.",
    required=False,
    default=None,
)
@click.option(
    "--regscale_ssp_id",
    type=click.INT,
    help="RegScale SSP ID. If provided, runs the compliance sync phase against the SSP.",
    required=False,
    default=None,
)
@click.option(
    "--component_id",
    "-c",
    type=click.INT,
    help="RegScale Component ID. If provided, runs the compliance sync phase against the Component.",
    required=False,
    default=None,
)
@click.option(
    "--framework",
    type=click.Choice(SARIF_SUPPORTED_FRAMEWORKS, case_sensitive=False),
    default="OWASP",
    help="Compliance phase: framework to sync against. Default: OWASP",
)
@click.option(
    "--create-issues/--no-create-issues",
    default=True,
    help="Compliance phase: create issues for failed controls. Default: True",
)
@click.option(
    "--update-control-status/--no-update-control-status",
    default=True,
    help="Compliance phase: update control implementation status. Default: True",
)
@click.option(
    "--create-poams",
    "-cp",
    is_flag=True,
    default=False,
    help="Compliance phase: mark created issues as POAMs. Default: False",
)
@click.option(
    "--scan_date",
    "-sd",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="Import phase: scan date of the file. Default: today.",
    required=False,
    default=get_current_datetime("%Y-%m-%d"),
)
@orchestration_options()
def sync(
    file_path: Path,
    asset_id: Optional[int],
    regscale_ssp_id: Optional[int],
    component_id: Optional[int],
    framework: str,
    create_issues: bool,
    update_control_status: bool,
    create_poams: bool,
    scan_date: datetime.datetime,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
) -> None:
    """
    Run SARIF vulnerability import and/or compliance sync in one command.

    Composes the two SARIF workflows so a single invocation can process one
    input file end-to-end:

    \b
      --asset_id          runs the vulnerability import phase on the asset
      --regscale_ssp_id   runs the compliance sync phase on the SSP
      --component_id      runs the compliance sync phase on the Component

    At least one of --asset_id, --regscale_ssp_id, or --component_id must be
    provided. --regscale_ssp_id and --component_id are mutually exclusive.
    Providing both phases runs them against the same input file with a
    unified summary and a single non-zero exit code if any phase fails.
    The compliance target is not auto-derived from the asset because an
    asset can transitively belong to multiple SSPs/Components.

    \b
    Examples:
        # Vulnerabilities + SSP compliance in one invocation
        regscale sarif sync -f scan.sarif --asset_id 42 --regscale_ssp_id 123

        # Compliance only against a Component
        regscale sarif sync -f scan.sarif --component_id 456

        # Vulnerabilities only
        regscale sarif sync -f scan.sarif --asset_id 42

    :param Path file_path: Path to the SARIF file or directory of files
    :param Optional[int] asset_id: RegScale Asset ID for the import phase
    :param Optional[int] regscale_ssp_id: RegScale SSP ID for the compliance phase
    :param Optional[int] component_id: RegScale Component ID for the compliance phase
    :param str framework: Compliance framework (OWASP or NIST800-53R5)
    :param bool create_issues: Create issues for failed controls
    :param bool update_control_status: Update control implementation status
    :param bool create_poams: Mark created issues as POAMs
    :param Optional[datetime.datetime] scan_date: Scan date for the import phase
    :param bool dry_run: If True, preview counts without writing
    :param Optional[int] offset: Skip this many items from the start
    :param Optional[int] limit: Process at most this many items
    :return: None
    :rtype: None
    :raises click.UsageError: when no targeting flag is provided, when both
        --regscale_ssp_id and --component_id are provided, or when --asset_id
        is provided but synqlyAccessToken is not configured
    :raises click.ClickException: when one or more phases fail
    """
    from regscale.integrations.commercial.sarif.sarif_compliance import SARIFComplianceIntegration

    if regscale_ssp_id is not None and component_id is not None:
        raise click.UsageError("Provide either --regscale_ssp_id or --component_id, not both.")
    if asset_id is None and regscale_ssp_id is None and component_id is None:
        raise click.UsageError("At least one of --asset_id, --regscale_ssp_id, or --component_id must be provided.")

    # Fail fast when the import phase is requested but Synqly isn't configured --
    # SarifImporter otherwise calls sys.exit mid-run, which skips our summary.
    if asset_id is not None and not _check_synqly_token_configured():
        raise click.UsageError(
            "synqlyAccessToken is required for the vulnerability import phase "
            "(set via 'synqlyAccessToken' env var or init.yaml) when --asset_id is provided."
        )

    phases: List[str] = []
    errors: List[str] = []

    # Per-phase try/except is intentionally scoped to Exception (not BaseException):
    # SystemExit / KeyboardInterrupt should propagate. SarifImporter uses sys.exit()
    # for fatal conditions like missing auth, and we want those to short-circuit the
    # unified sync rather than be converted into a "phase failed, continue" record.
    # The synqlyAccessToken pre-check above handles the only common sys.exit path.

    # Phase 1: vulnerability import (optional)
    if asset_id is not None:
        phases.append("import")
        logger.info("SARIF sync phase 1/? - vulnerability import (asset_id=%d)", asset_id)
        try:
            process_sarif_files(
                file_path,
                asset_id,
                scan_date,
                dry_run=dry_run,
                offset=offset,
                limit=limit,
            )
            logger.info("SARIF vulnerability import phase completed.")
        except Exception as exc:  # noqa: BLE001 - collect per-phase failures for summary
            logger.error("SARIF vulnerability import phase failed: %s", exc, exc_info=True)
            errors.append(f"import: {exc}")

    # Phase 2: compliance sync (optional)
    if regscale_ssp_id is not None or component_id is not None:
        compliance_plan_id, compliance_parent_module = _resolve_parent(regscale_ssp_id, component_id)
        phases.append("compliance")
        logger.info(
            "SARIF sync phase 2/? - compliance sync (%s id=%d, framework=%s)",
            compliance_parent_module,
            compliance_plan_id,
            framework,
        )
        try:
            integration = SARIFComplianceIntegration(
                plan_id=compliance_plan_id,
                file_path=file_path,
                framework=framework,
                create_issues=create_issues,
                update_control_status=update_control_status,
                create_poams=create_poams,
                asset_id=asset_id,
                parent_module=compliance_parent_module,
                dry_run=dry_run,
                offset=offset,
                limit=limit,
            )
            integration.sync_compliance()
            logger.info("SARIF compliance sync phase completed.")
        except Exception as exc:  # noqa: BLE001 - collect per-phase failures for summary
            logger.error("SARIF compliance sync phase failed: %s", exc, exc_info=True)
            errors.append(f"compliance: {exc}")

    total = len(phases)
    succeeded = total - len(errors)
    if errors:
        summary = f"SARIF sync: {succeeded} of {total} phases succeeded. Failures: {'; '.join(errors)}"
        logger.error(summary)
        raise click.ClickException(summary)
    logger.info("SARIF sync completed: %d of %d phases succeeded (%s).", succeeded, total, ", ".join(phases))
