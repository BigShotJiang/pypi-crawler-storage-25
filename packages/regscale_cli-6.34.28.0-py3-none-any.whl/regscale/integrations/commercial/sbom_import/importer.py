"""SBOM file importer for SPDX and CycloneDX JSON files."""

import json
import logging
from pathlib import Path
from typing import List, Optional

from regscale.models.regscale_models.sbom import Sbom

logger = logging.getLogger("regscale")

CYCLONEDX = "CycloneDX"
SPDX = "SPDX"


class SbomFormatError(Exception):
    """Raised when SBOM format cannot be detected or is invalid."""


class SbomValidationError(Exception):
    """Raised when SBOM content fails structural validation."""

    def __init__(self, errors: List[str]):
        self.errors = errors
        super().__init__(f"SBOM validation failed: {'; '.join(errors)}")


class SbomFileImporter:
    """Imports SPDX or CycloneDX JSON files into RegScale as SBOM records.

    :param str file_path: Path to the SBOM JSON file
    :param int parent_id: RegScale parent record ID
    :param str parent_module: Parent module name (e.g., assets, components, securityPlans)
    :param Optional[str] sbom_format: Explicit format override (cyclonedx, spdx, or None for auto-detect)
    """

    def __init__(
        self,
        file_path: str,
        parent_id: int,
        parent_module: str,
        sbom_format: Optional[str] = None,
    ):
        self.file_path = Path(file_path)
        self.parent_id = parent_id
        self.parent_module = parent_module
        self.sbom_format = sbom_format

    @staticmethod
    def detect_format(data: dict) -> str:
        """Auto-detect SBOM format from JSON structure.

        :param dict data: Parsed JSON data
        :return: Detected format string (CycloneDX or SPDX)
        :rtype: str
        :raises SbomFormatError: If format cannot be determined
        """
        if data.get("bomFormat") == CYCLONEDX:
            return CYCLONEDX
        if data.get("spdxVersion"):
            return SPDX
        raise SbomFormatError(
            "Unable to detect SBOM format. JSON must contain 'bomFormat': 'CycloneDX' or 'spdxVersion'."
        )

    @staticmethod
    def validate(data: dict, sbom_format: str) -> List[str]:
        """Validate SBOM structure for the given format.

        :param dict data: Parsed JSON data
        :param str sbom_format: The SBOM format (CycloneDX or SPDX)
        :return: List of validation error strings (empty means valid)
        :rtype: List[str]
        """
        errors: List[str] = []
        if sbom_format == CYCLONEDX:
            if data.get("bomFormat") != CYCLONEDX:
                errors.append("Missing or incorrect 'bomFormat' field")
            if not data.get("specVersion"):
                errors.append("Missing 'specVersion' field")
            if not isinstance(data.get("components"), list):
                errors.append("Missing or invalid 'components' array")
        elif sbom_format == SPDX:
            if not data.get("spdxVersion"):
                errors.append("Missing 'spdxVersion' field")
            if not data.get("name"):
                errors.append("Missing 'name' field")
            if not isinstance(data.get("packages"), list):
                errors.append("Missing or invalid 'packages' array")
        else:
            errors.append(f"Unsupported SBOM format: {sbom_format}")
        return errors

    def _extract_tool(self, data: dict, sbom_format: str) -> str:
        """Extract tool name from SBOM metadata.

        :param dict data: Parsed JSON data
        :param str sbom_format: The SBOM format
        :return: Tool name string
        :rtype: str
        """
        if sbom_format == CYCLONEDX:
            metadata = data.get("metadata", {})
            tools = metadata.get("tools")
            if isinstance(tools, list) and tools:
                first_tool = tools[0]
                if isinstance(first_tool, dict):
                    return first_tool.get("name", "file-import")
            elif isinstance(tools, dict):
                components = tools.get("components", [])
                if components and isinstance(components[0], dict):
                    return components[0].get("name", "file-import")
        elif sbom_format == SPDX:
            creators = data.get("creationInfo", {}).get("creators", [])
            for creator in creators:
                if isinstance(creator, str) and creator.startswith("Tool:"):
                    return creator.removeprefix("Tool:").strip()
        return "file-import"

    def _extract_name(self, data: dict, sbom_format: str) -> str:
        """Derive a name for the SBOM record.

        :param dict data: Parsed JSON data
        :param str sbom_format: The SBOM format
        :return: SBOM record name
        :rtype: str
        """
        if sbom_format == SPDX and data.get("name"):
            return data["name"]
        if sbom_format == CYCLONEDX:
            component = data.get("metadata", {}).get("component", {})
            if component.get("name"):
                return component["name"]
        return self.file_path.stem

    def _extract_version(self, data: dict, sbom_format: str) -> str:
        """Extract standard version from SBOM data.

        :param dict data: Parsed JSON data
        :param str sbom_format: The SBOM format
        :return: Standard version string
        :rtype: str
        """
        if sbom_format == CYCLONEDX:
            return data.get("specVersion", "")
        if sbom_format == SPDX:
            return data.get("spdxVersion", "")
        return ""

    def import_sbom(self) -> Sbom:
        """Read file, detect/validate format, and create an SBOM record in RegScale.

        :return: The created Sbom record
        :rtype: Sbom
        :raises FileNotFoundError: If the file does not exist
        :raises SbomFormatError: If format cannot be detected
        :raises SbomValidationError: If structural validation fails
        :raises json.JSONDecodeError: If file is not valid JSON
        """
        logger.info("Reading SBOM file: %s", self.file_path)
        raw_text = self.file_path.read_text(encoding="utf-8")
        data = json.loads(raw_text)

        if self.sbom_format and self.sbom_format.lower() != "auto":
            detected = CYCLONEDX if self.sbom_format.lower() == "cyclonedx" else SPDX
        else:
            detected = self.detect_format(data)

        logger.info("SBOM format: %s", detected)

        errors = self.validate(data, detected)
        if errors:
            raise SbomValidationError(errors)

        item_key = "components" if detected == CYCLONEDX else "packages"
        item_count = len(data.get(item_key, []))
        file_size_kb = self.file_path.stat().st_size / 1024
        logger.info("SBOM contains %d %s (%.1f KB)", item_count, item_key, file_size_kb)

        sbom = Sbom(
            name=self._extract_name(data, detected),
            sbomStandard=detected,
            standardVersion=self._extract_version(data, detected),
            tool=self._extract_tool(data, detected),
            results=raw_text,
            parentId=self.parent_id,
            parentModule=self.parent_module,
        )
        sbom.create()
        logger.info("SBOM record created successfully for parent %s/%d", self.parent_module, self.parent_id)
        return sbom
