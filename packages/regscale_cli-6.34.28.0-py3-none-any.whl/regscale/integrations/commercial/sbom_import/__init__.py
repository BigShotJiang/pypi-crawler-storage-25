"""Generic SBOM file import for SPDX and CycloneDX JSON files."""
