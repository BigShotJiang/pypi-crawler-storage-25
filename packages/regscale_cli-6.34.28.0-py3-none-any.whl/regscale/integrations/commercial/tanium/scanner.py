#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tanium Scanner Integration for RegScale.

This module provides the TaniumScanner class that fetches assets, vulnerabilities,
and compliance findings from Tanium and syncs them to RegScale.
"""

import logging
from collections import defaultdict
from typing import Dict, Generator, Optional, Set

from regscale.core.app.application import Application
from regscale.integrations.commercial.tanium.models.assets import TaniumEndpoint
from regscale.integrations.commercial.tanium.models.compliance import (
    TaniumComplianceFinding,
)
from regscale.integrations.commercial.tanium.models.vulnerabilities import (
    TaniumVulnerability,
)
from regscale.integrations.commercial.tanium.tanium_api_client import (
    TaniumAPIClient,
    TaniumAPIException,
)
from regscale.integrations.commercial.tanium.variables import TaniumVariables
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
)
from regscale.models import regscale_models

logger = logging.getLogger("regscale")

# Module-level severity map avoids rebuilding the dict on every finding conversion.
# At 500k findings this saves ~500k transient dict allocations.
_SEVERITY_MAP: Dict[str, regscale_models.IssueSeverity] = {
    "Critical": regscale_models.IssueSeverity.Critical,
    "High": regscale_models.IssueSeverity.High,
    "Medium": regscale_models.IssueSeverity.Moderate,
    "Low": regscale_models.IssueSeverity.Low,
    "Informational": regscale_models.IssueSeverity.Low,
}


def endpoint_to_integration_asset(endpoint: TaniumEndpoint) -> IntegrationAsset:
    """
    Convert TaniumEndpoint to IntegrationAsset.

    Args:
        endpoint: TaniumEndpoint instance

    Returns:
        IntegrationAsset for use with ScannerIntegration
    """
    return IntegrationAsset(
        name=endpoint.computer_name,
        identifier=endpoint.get_unique_identifier(),
        asset_type=endpoint.get_asset_type(),
        asset_category="Hardware",
        ip_address=endpoint.ip_address or "",
        mac_address=endpoint.mac_address or "",
        fqdn=endpoint._build_fqdn(),
        operating_system=endpoint.get_operating_system_category(),
        serial_number=endpoint.serial_number or "",
        manufacturer=endpoint.manufacturer or "",
        model=endpoint.model or "",
        description=endpoint._build_description(),
        is_virtual=endpoint.is_virtual,
    )


def vulnerability_to_integration_finding(
    vuln: TaniumVulnerability,
    asset_identifier: str = "",
    endpoint: TaniumEndpoint | None = None,
) -> IntegrationFinding:
    """
    Convert TaniumVulnerability to IntegrationFinding.

    Args:
        vuln: TaniumVulnerability instance
        asset_identifier: Optional asset identifier (may be a newline-separated list of
            identifiers for vulnerabilities affecting multiple endpoints; the scanner
            framework splits on "\n" to register one asset mapping per entry)
        endpoint: Optional representative TaniumEndpoint used only for IP/DNS
            enrichment fields; asset mappings come from asset_identifier

    Returns:
        IntegrationFinding for use with ScannerIntegration
    """
    severity = _map_severity_to_regscale(vuln.get_regscale_severity())

    # Enrich finding with endpoint network data for server-side asset discovery
    ip_address = ""
    dns = ""
    if endpoint:
        ip_address = endpoint.ip_address or ""
        dns = endpoint._build_fqdn()

    return IntegrationFinding(
        control_labels=[],
        title=vuln.title or vuln.cve_id or "Tanium Vulnerability",
        category="Vulnerability",
        plugin_name=vuln.title or vuln.cve_id or "Tanium Vulnerability",
        plugin_id=vuln.cve_id or vuln.tanium_id,
        severity=severity,
        description=vuln._build_description(),
        status=regscale_models.IssueStatus.Open,
        cve=vuln.cve_id,
        cvss_v3_score=vuln.cvss_score,
        cvss_v3_vector=vuln.cvss_vector,
        asset_identifier=asset_identifier,
        external_id=vuln.tanium_id,
        first_seen=vuln.first_detected or "",
        last_seen=vuln.last_detected or "",
        remediation=vuln.solution,
        ip_address=ip_address,
        dns=dns,
    )


def compliance_to_integration_finding(
    finding: TaniumComplianceFinding,
) -> IntegrationFinding:
    """
    Convert TaniumComplianceFinding to IntegrationFinding.

    Args:
        finding: TaniumComplianceFinding instance

    Returns:
        IntegrationFinding for use with ScannerIntegration
    """
    severity = _map_severity_to_regscale(finding.get_regscale_severity())
    status = regscale_models.IssueStatus.Closed if finding.is_compliant() else regscale_models.IssueStatus.Open

    # Build asset identifier if endpoint info available
    asset_identifier = ""
    if finding.endpoint_id:
        asset_identifier = "tanium-%s-%s" % (
            finding.endpoint_id,
            finding.endpoint_name or "",
        )

    return IntegrationFinding(
        control_labels=finding.get_nist_controls(),
        title=finding._build_title(),
        category="Compliance",
        plugin_name=finding.rule_title or finding.rule_id or "Tanium Compliance Check",
        plugin_id=finding.get_unique_identifier(),
        severity=severity,
        description=finding._build_description(),
        status=status,
        rule_id=finding.rule_id,
        cci_ref=",".join(finding.get_cci_ids()) if finding.get_cci_ids() else None,
        asset_identifier=asset_identifier,
        external_id=finding.tanium_id,
        remediation=finding.fix_text,
    )


def _map_severity_to_regscale(severity: str) -> regscale_models.IssueSeverity:
    """
    Map severity string to RegScale IssueSeverity enum.

    Args:
        severity: Severity string (Critical, High, Medium, Low)

    Returns:
        RegScale IssueSeverity enum value
    """
    return _SEVERITY_MAP.get(severity, regscale_models.IssueSeverity.Moderate)


class TaniumScanner(ScannerIntegration):
    """
    Tanium Scanner Integration for RegScale.

    Fetches assets, vulnerabilities, and compliance findings from Tanium
    and syncs them to RegScale.
    """

    title = "Tanium"
    type = ScannerIntegrationType.VULNERABILITY

    def __init__(self, *args, **kwargs):
        """
        Initialize the Tanium Scanner Integration.

        Args:
            *args: Arguments to pass to parent class
            **kwargs: Keyword arguments to pass to parent class
        """
        super().__init__(*args, **kwargs)

        self.app = Application()

        # Validate Tanium URL configuration
        tanium_url = TaniumVariables.taniumUrl
        if not tanium_url or not tanium_url.strip():
            raise TaniumAPIException("Tanium URL is not configured. Please set 'taniumUrl' in init.yaml")

        if "example.com" in tanium_url:
            logger.warning(
                "Tanium URL contains 'example.com' — this appears to be the default placeholder. "
                "Please configure 'taniumUrl' in init.yaml with your actual Tanium server URL."
            )
            raise TaniumAPIException(
                "Tanium URL is still set to the default placeholder. "
                "Please configure 'taniumUrl' in init.yaml with your actual Tanium server URL."
            )

        # Initialize API client
        self.api_client = TaniumAPIClient(
            base_url=tanium_url,
            api_token=TaniumVariables.taniumToken,
            verify_ssl=TaniumVariables.taniumVerifySsl,
            timeout=TaniumVariables.taniumTimeout,
            protocols=TaniumVariables.taniumProtocols,
            api_type=TaniumVariables.taniumApiType,
            is_cloud=TaniumVariables.taniumIsCloud,
        )

        # Cache for endpoint data
        self._endpoint_cache: Dict[int, TaniumEndpoint] = {}

    def _compute_max_items(self) -> Optional[int]:
        """
        Compute max_items for API client calls from orchestration params.

        When limit is set, returns (offset or 0) + limit so the API client
        stops pagination early. The base class _apply_pagination handles
        the actual offset/limit slicing afterward.

        Returns:
            Maximum items to fetch, or None for no limit.
        """
        offset = getattr(self, "orchestration_offset", None) or 0
        limit = getattr(self, "orchestration_limit", None)
        if limit is not None:
            return offset + limit
        return None

    def fetch_assets(self, **kwargs) -> Generator[IntegrationAsset, None, None]:
        """
        Fetch assets (endpoints) from Tanium, streaming page-by-page.

        Yields:
            IntegrationAsset objects for each Tanium endpoint
        """
        logger.info("Fetching assets from Tanium...")

        try:
            endpoint_stream = self.api_client.iter_endpoints(max_items=self._compute_max_items())
            seen_identifiers: Set[str] = set()
            yielded = 0
            for endpoint_data in endpoint_stream:
                try:
                    endpoint = TaniumEndpoint.from_tanium_data(endpoint_data)
                    # Cache endpoint for vulnerability/finding mapping (last-write-wins is fine)
                    self._endpoint_cache[endpoint.tanium_id] = endpoint
                    # Skip duplicate endpoints surfaced by overlapping pagination so the
                    # scanner framework only receives one IntegrationAsset per real asset.
                    identifier = endpoint.get_unique_identifier()
                    if identifier in seen_identifiers:
                        continue
                    seen_identifiers.add(identifier)
                    yield endpoint_to_integration_asset(endpoint)
                    yielded += 1
                except Exception as e:
                    logger.warning(
                        "Failed to process endpoint %s: %s",
                        endpoint_data.get("computerName", "Unknown"),
                        str(e),
                    )
        except TaniumAPIException as e:
            logger.error("Failed to fetch endpoints from Tanium: %s", str(e))
            return

        self.num_assets_to_process = yielded
        if yielded == 0:
            logger.warning("No endpoints found in Tanium")
        else:
            logger.info("Processed %s endpoints from Tanium", yielded)

    def fetch_findings(self, **kwargs) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch findings from Tanium.

        Yields vulnerabilities and optionally compliance findings.

        Yields:
            IntegrationFinding objects for each finding
        """
        logger.info("Fetching findings from Tanium...")

        # Pre-populate endpoint cache if empty so vulnerability findings
        # can be linked to assets via their asset_identifier field.
        # This is needed when sync_findings runs without sync_assets first.
        self._ensure_endpoint_cache()

        # Fetch vulnerabilities
        yield from self._fetch_vulnerabilities()

        # Optionally fetch compliance findings (deprecated — use sync_compliance instead)
        include_compliance = kwargs.get("include_compliance", False)
        if include_compliance:
            import warnings

            warnings.warn(
                "include_compliance is deprecated for sync_findings. "
                "Use 'regscale tanium sync_compliance' for proper control assessments.",
                DeprecationWarning,
                stacklevel=2,
            )
            yield from self._fetch_compliance_findings()

    def _ensure_endpoint_cache(self) -> None:
        """
        Populate the endpoint cache if it is empty, streaming page-by-page.

        When sync_findings runs without a prior sync_assets call the cache
        is empty, which causes all vulnerability findings to have blank
        asset_identifier values and prevents asset linkage.
        """
        if self._endpoint_cache:
            return

        logger.info("Pre-loading Tanium endpoints for asset linkage...")
        try:
            for endpoint_data in self.api_client.iter_endpoints():
                try:
                    endpoint = TaniumEndpoint.from_tanium_data(endpoint_data)
                    self._endpoint_cache[endpoint.tanium_id] = endpoint
                except Exception as e:
                    name = (
                        endpoint_data.get("computerName", "Unknown") if isinstance(endpoint_data, dict) else "Unknown"
                    )
                    logger.warning("Failed to cache endpoint %s: %s", name, str(e))
        except TaniumAPIException as e:
            logger.warning("Could not pre-load endpoints for asset linkage: %s", str(e))
            return

        if not self._endpoint_cache:
            logger.info("No endpoints returned from Tanium for cache pre-load")
            return

        logger.info("Pre-loaded %d endpoints into cache", len(self._endpoint_cache))

    @staticmethod
    def _vuln_dedup_key(vuln_data: Dict) -> str:
        """
        Build the dedup key for a Tanium vulnerability record.

        Uses pluginId first when present (covers non-CVE policy/data findings),
        then falls back to cveId, then to the raw record id. This matches the
        identifier semantics IntegrationFinding.plugin_id uses on the output side
        so consolidation groups align with the eventual finding key.
        """
        plugin_id = vuln_data.get("pluginId")
        if plugin_id:
            return str(plugin_id)
        cve_id = vuln_data.get("cveId")
        if cve_id:
            return str(cve_id)
        return str(vuln_data.get("id", ""))

    def _fetch_vulnerabilities(self) -> Generator[IntegrationFinding, None, None]:
        """
        Stream vulnerabilities from Tanium Comply, consolidating duplicates as we go.

        Memory profile is O(unique-findings), not O(records): for each plugin/CVE
        key we keep one canonical record dict and a set of endpoint ids. Cloud
        returns one record per (endpoint, CVE) pair, so this collapses the
        ~500k-record per-endpoint fan-out into ~100k canonical findings without
        ever materializing the full vulnerability list.

        Yields:
            IntegrationFinding objects, one per unique pluginId/cveId/id
        """
        logger.info("Fetching vulnerabilities from Tanium Comply...")

        canonical: Dict[str, Dict] = {}
        endpoint_ids: defaultdict = defaultdict(set)
        raw_count = 0

        try:
            for vuln_data in self.api_client.iter_vulnerabilities(max_items=self._compute_max_items()):
                raw_count += 1
                group_key = self._vuln_dedup_key(vuln_data)
                if not group_key:
                    continue

                if group_key not in canonical:
                    canonical[group_key] = vuln_data

                for ep in vuln_data.get("affectedEndpoints", []):
                    ep_id = ep.get("id")
                    if ep_id is not None:
                        endpoint_ids[group_key].add(ep_id)
        except TaniumAPIException as e:
            logger.error("Failed to fetch vulnerabilities from Tanium: %s", str(e))
            return

        if not canonical:
            logger.info("No vulnerabilities found in Tanium")
            return

        self.num_findings_to_process = len(canonical)
        findings_count = 0

        for group_key, primary_data in canonical.items():
            try:
                merged_ids = endpoint_ids[group_key]
                merged_endpoints = [{"id": eid} for eid in merged_ids]
                enriched = dict(primary_data)
                enriched["affectedEndpoints"] = merged_endpoints
                enriched["affectedEndpointCount"] = len(merged_endpoints)

                vuln = TaniumVulnerability.from_tanium_data(enriched)

                asset_identifiers: list[str] = []
                first_endpoint: Optional[TaniumEndpoint] = None
                for endpoint_id in vuln.get_affected_endpoint_ids():
                    endpoint = self._endpoint_cache.get(endpoint_id)
                    if not endpoint:
                        continue
                    asset_identifiers.append(endpoint.get_unique_identifier())
                    if first_endpoint is None:
                        first_endpoint = endpoint

                yield vulnerability_to_integration_finding(vuln, "\n".join(asset_identifiers), first_endpoint)
                findings_count += 1

            except Exception as e:
                logger.warning("Failed to process vulnerability group %s: %s", group_key, str(e))

        self.num_findings_to_process = findings_count
        logger.info(
            "Processed %s unique vulnerability findings from Tanium (consolidated from %s raw records)",
            findings_count,
            raw_count,
        )

    def _fetch_compliance_findings(self) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch compliance findings from Tanium Comply module.

        Only yields non-compliant findings (status=Fail).

        Yields:
            IntegrationFinding objects for each compliance finding
        """
        logger.info("Fetching compliance findings from Tanium Comply...")

        seen_compliance_keys: Set[str] = set()
        yielded = 0
        try:
            for finding_data in self.api_client.iter_compliance_findings(
                status="Fail", max_items=self._compute_max_items()
            ):
                try:
                    finding = TaniumComplianceFinding.from_tanium_data(finding_data)

                    # Skip compliant findings
                    if finding.is_compliant():
                        continue

                    # Dedup by (rule_id, endpoint_id) so overlapping pagination
                    # doesn't surface the same finding twice.
                    dedup_key = finding.get_unique_identifier()
                    if dedup_key in seen_compliance_keys:
                        continue
                    seen_compliance_keys.add(dedup_key)

                    yield compliance_to_integration_finding(finding)
                    yielded += 1

                except Exception as e:
                    logger.warning(
                        "Failed to process compliance finding %s: %s",
                        finding_data.get("ruleId", "Unknown"),
                        str(e),
                    )
        except TaniumAPIException as e:
            logger.error("Failed to fetch compliance findings from Tanium: %s", str(e))
            return

        if yielded == 0:
            logger.info("No compliance findings found in Tanium")
        else:
            logger.info("Processed %d compliance findings from Tanium", yielded)
