#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tanium compliance integration using the ComplianceIntegration base class.

Maps Tanium Comply benchmark/compliance data to RegScale control assessments
using the standard compliance framework patterns. The framework is auto-detected
from the SSP's existing control implementations.

Each Tanium compliance finding with multiple NIST controls is expanded into
one ComplianceItem per control ID, so the base class can create individual
assessments for each control.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from regscale.integrations.compliance_integration import (
    ComplianceIntegration,
    ComplianceItem,
    FrameworkDetectionError,
    detect_framework_from_control_ids,
)
from regscale.models.regscale_models import ControlImplementation

if TYPE_CHECKING:
    from regscale.integrations.commercial.tanium.models.compliance import TaniumComplianceFinding

logger = logging.getLogger("regscale")


class TaniumComplianceItem(ComplianceItem):
    """Compliance item wrapping a single control from a TaniumComplianceFinding."""

    def __init__(
        self,
        finding: "TaniumComplianceFinding",
        control_id: str,
        framework: str,
    ):
        """
        Initialize from a Tanium compliance finding for a specific control.

        :param TaniumComplianceFinding finding: Source compliance finding
        :param str control_id: Single NIST control ID (e.g. AC-2)
        :param str framework: Compliance framework
        """
        self._finding = finding
        self._control_id = control_id
        self._framework = framework

    @property
    def resource_id(self) -> str:
        """Resource identifier — endpoint ID or fallback."""
        if self._finding.endpoint_id:
            return "tanium-%s" % self._finding.endpoint_id
        return "tanium-comply"

    @property
    def resource_name(self) -> str:
        """Resource name — endpoint name or fallback."""
        return self._finding.endpoint_name or "Tanium Comply"

    @property
    def control_id(self) -> str:
        """Control identifier."""
        return self._control_id

    @property
    def compliance_result(self) -> str:
        """PASS if compliant, FAIL otherwise."""
        return "PASS" if self._finding.is_compliant() else "FAIL"

    @property
    def severity(self) -> Optional[str]:
        """Severity from the underlying finding."""
        return self._finding.get_regscale_severity()

    @property
    def description(self) -> str:
        """Description from the underlying finding."""
        return self._finding._build_description()

    @property
    def framework(self) -> str:
        """Compliance framework."""
        return self._framework


class TaniumComplianceIntegration(ComplianceIntegration):
    """Tanium compliance integration extending ComplianceIntegration.

    Fetches compliance/benchmark findings from Tanium Comply and maps them
    to RegScale control assessments. Each finding is expanded per NIST control
    so the base class can create per-control assessments.
    """

    def __init__(
        self,
        plan_id: int,
        framework: Optional[str] = None,
        **kwargs,
    ):
        """
        Initialize Tanium compliance integration.

        :param int plan_id: RegScale SSP ID
        :param Optional[str] framework: Compliance framework override. Auto-detected if None.
        """
        super().__init__(
            plan_id=plan_id,
            framework=framework or "NIST",
            create_issues=False,
            update_control_status=True,
            create_poams=False,
            parent_module="securityplans",
            **kwargs,
        )
        self._framework_override = framework
        self._init_api_client()

    def _init_api_client(self) -> None:
        """Initialize the Tanium API client from configuration variables."""
        from regscale.integrations.commercial.tanium.tanium_api_client import (
            TaniumAPIClient,
            TaniumAPIException,
        )
        from regscale.integrations.commercial.tanium.variables import TaniumVariables

        tanium_url = TaniumVariables.taniumUrl
        if not tanium_url or not tanium_url.strip():
            raise TaniumAPIException("Tanium URL is not configured. Please set 'taniumUrl' in init.yaml")

        self.api_client = TaniumAPIClient(
            base_url=tanium_url,
            api_token=TaniumVariables.taniumToken,
            verify_ssl=TaniumVariables.taniumVerifySsl,
            timeout=TaniumVariables.taniumTimeout,
            protocols=TaniumVariables.taniumProtocols,
            api_type=TaniumVariables.taniumApiType,
            is_cloud=TaniumVariables.taniumIsCloud,
        )

    @property
    def title(self) -> str:
        """Integration title for logging."""
        return "Tanium"

    def _resolve_framework(self) -> str:
        """
        Resolve the framework by auto-detecting from SSP control implementations.

        Falls back to NIST if the SSP has no control implementations or if
        detection fails, since Tanium Comply findings typically carry NIST mappings.

        :return: Resolved framework name
        :rtype: str
        """
        if self._framework_override:
            logger.info("Using user-specified framework: %s", self._framework_override)
            return self._framework_override

        try:
            implementations = ControlImplementation.get_existing_control_implementations(parent_id=self.plan_id)
        except (AttributeError, KeyError, ValueError, TypeError) as e:
            logger.warning(
                "Could not retrieve control implementations from SSP %d: %s. "
                "Defaulting to NIST. Use --framework to specify explicitly "
                "(e.g. regscale tanium sync_compliance --id %d --framework CSF).",
                self.plan_id,
                e,
                self.plan_id,
            )
            return "NIST"

        control_names = list(implementations.keys()) if implementations else []

        if not control_names:
            logger.warning(
                "SSP %d has no control implementations. Defaulting to NIST. "
                "Use --framework to specify explicitly "
                "(e.g. regscale tanium sync_compliance --id %d --framework CSF).",
                self.plan_id,
                self.plan_id,
            )
            return "NIST"

        try:
            detected = detect_framework_from_control_ids(control_names)
        except FrameworkDetectionError:
            logger.warning(
                "Could not auto-detect framework from %d control implementations on SSP %d. "
                "Defaulting to NIST. Use --framework to specify explicitly "
                "(e.g. regscale tanium sync_compliance --id %d --framework CSF).",
                len(control_names),
                self.plan_id,
                self.plan_id,
            )
            return "NIST"

        logger.info(
            "Auto-detected framework '%s' from %d control implementations on SSP %d.",
            detected,
            len(control_names),
            self.plan_id,
        )
        return detected

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Fetch compliance findings from Tanium and expand per control ID.

        Fetches ALL statuses (pass and fail) so the base class can determine
        the correct assessment result per control.

        :return: List of raw compliance data dicts, one per (finding, control) pair
        :rtype: List[Dict[str, Any]]
        """
        from regscale.integrations.commercial.tanium.models.compliance import TaniumComplianceFinding

        resolved_framework = self._resolve_framework()
        self.framework = resolved_framework

        logger.info("Fetching compliance findings from Tanium Comply...")

        offset = getattr(self, "orchestration_offset", None) or 0
        limit = getattr(self, "orchestration_limit", None)
        max_items = (offset + limit) if limit is not None else None

        raw_data: List[Dict[str, Any]] = []
        seen_findings: set[str] = set()
        raw_count = 0

        try:
            for finding_data in self.api_client.iter_compliance_findings(max_items=max_items):
                raw_count += 1
                try:
                    finding = TaniumComplianceFinding.from_tanium_data(finding_data)
                    # Skip duplicate findings surfaced by overlapping pagination (same rule+endpoint)
                    finding_key = finding.get_unique_identifier()
                    if finding_key in seen_findings:
                        continue
                    seen_findings.add(finding_key)

                    nist_controls = finding.get_nist_controls()

                    if not nist_controls:
                        logger.debug(
                            "Skipping compliance finding %s — no NIST control mappings",
                            finding.rule_id,
                        )
                        continue

                    # Dedup control IDs within a finding so a duplicate entry in nistControls
                    # doesn't produce two identical ComplianceItems for the same (finding, control).
                    seen_controls: set[str] = set()
                    for ctrl_id in nist_controls:
                        if ctrl_id in seen_controls:
                            continue
                        seen_controls.add(ctrl_id)
                        raw_data.append(
                            {
                                "finding": finding,
                                "control_id": ctrl_id,
                                "framework": resolved_framework,
                            }
                        )
                except Exception as e:
                    logger.warning(
                        "Failed to process compliance finding %s: %s",
                        finding_data.get("ruleId", "Unknown"),
                        str(e),
                    )
        except Exception as e:
            logger.error("Failed to fetch compliance findings from Tanium: %s", str(e))
            return []

        if raw_count == 0:
            logger.info("No compliance findings returned from Tanium")
            return []

        logger.info(
            "Expanded to %d compliance items across %d raw findings.",
            len(raw_data),
            raw_count,
        )

        # Apply offset/limit slicing for orchestration hub pagination
        if offset > 0:
            raw_data = raw_data[offset:]
        if limit is not None:
            raw_data = raw_data[:limit]

        return raw_data

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> ComplianceItem:
        """
        Create a TaniumComplianceItem from raw compliance data.

        :param Dict[str, Any] raw_data: Raw compliance data dictionary
        :return: ComplianceItem instance
        :rtype: ComplianceItem
        """
        return TaniumComplianceItem(
            finding=raw_data["finding"],
            control_id=raw_data["control_id"],
            framework=raw_data.get("framework", self.framework),
        )
