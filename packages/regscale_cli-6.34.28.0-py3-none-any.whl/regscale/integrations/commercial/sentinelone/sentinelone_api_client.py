#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne API Client for RegScale Integration.

This module provides a Python client for interacting with the SentinelOne
Management API. It supports authentication via API tokens and provides
methods for retrieving agents, threats, vulnerabilities, and applications.

SentinelOne API Documentation: Available in Management Console > Help > API Hub
"""

import logging
from typing import Any, Dict, Generator, List, Optional
from urllib.parse import urljoin

import httpx
from tenacity import (
    RetryError,
    retry,
    retry_if_exception_type,
    retry_if_result,
    stop_after_attempt,
    wait_exponential,
)

from regscale.core.app.utils.mock_service_headers import get_mock_service_headers

logger = logging.getLogger("regscale")

_RETRYABLE_ERRORS = (
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.ReadTimeout,
    httpx.ReadError,
    httpx.RemoteProtocolError,
    httpx.TimeoutException,
)
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def _should_retry_response(response: Optional[httpx.Response]) -> bool:
    if response is None:
        return False
    return response.status_code in _RETRYABLE_STATUS_CODES


# Constants
CONTENT_TYPE_JSON = "application/json"
ERROR_UNEXPECTED_RESPONSE = "Unexpected response type: %s"
API_VERSION = "v2.1"

# Default request headers. The Authorization header is intentionally added
# per-request rather than included here, so the API token cannot leak via
# debug logs or error traces that dump the client's stored headers.
DEFAULT_HEADERS: Dict[str, str] = {
    "Content-Type": CONTENT_TYPE_JSON,
    "Accept": CONTENT_TYPE_JSON,
}

# API Endpoint Constants
ENDPOINT_AGENTS = "/agents"
ENDPOINT_THREATS = "/threats"
ENDPOINT_VULNERABILITIES = "/ranger/cve/export/aggregated-cves"
ENDPOINT_APPLICATIONS = "/installed-applications"
ENDPOINT_ACTIVITIES = "/activities"
ENDPOINT_SYSTEM_INFO = "/system/info"


class SentinelOneAPIException(Exception):
    """Exception raised for SentinelOne API errors."""

    pass


class SentinelOneAPIClient:
    """
    Python client for SentinelOne REST API.

    Handles authentication, pagination, and result retrieval from SentinelOne.
    Uses API token authentication for API access.

    Example usage:
        >>> client = SentinelOneAPIClient(
        ...     base_url="https://usea1-partners.sentinelone.net",
        ...     api_token="your-api-token"
        ... )
        >>> agents = client.get_all_agents()
    """

    DEFAULT_TIMEOUT = 30
    DEFAULT_PAGE_SIZE = 1000

    def __init__(
        self,
        base_url: str,
        api_token: str,
        verify_ssl: bool = True,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = 3,
        site_id: Optional[str] = None,
        account_id: Optional[str] = None,
    ):
        """
        Initialize SentinelOne API client.

        Args:
            base_url: SentinelOne Management Console URL
            api_token: SentinelOne API token
            verify_ssl: Whether to verify SSL certificates
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
            site_id: Optional site ID filter
            account_id: Optional account ID filter
        """
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.site_id = site_id
        self.account_id = account_id
        self.max_retries = max_retries

        # Copy DEFAULT_HEADERS so per-instance mutations (e.g., mock-service
        # headers below) cannot leak back into the module-level constant.
        self._default_headers: Dict[str, str] = dict(DEFAULT_HEADERS)

        # Inject mockServicesConfig.sentinelone headers (X-Mock-*) when present
        # in init.yaml. Empty dict in production => no-op. Applied last so mock
        # values take precedence over any defaults set above.
        _mock_headers = get_mock_service_headers("sentinelone")
        if _mock_headers:
            self._default_headers.update(_mock_headers)

        self.client = self._create_client()

        logger.info("SentinelOne API client initialized for %s", self.base_url)

    def _create_client(self) -> httpx.Client:
        """
        Create an httpx client.

        Returns:
            Configured httpx.Client object
        """
        if not self.verify_ssl:
            logger.warning("SSL verification is disabled - not recommended for production")

        transport = httpx.HTTPTransport(verify=self.verify_ssl)
        return httpx.Client(transport=transport, timeout=self.timeout, verify=self.verify_ssl)

    def close(self) -> None:
        """
        Close the underlying HTTP client and release pooled connections.

        Safe to call multiple times; httpx.Client.close() is idempotent.
        """
        if getattr(self, "_closed", False):
            return
        try:
            self.client.close()
        except Exception as exc:
            logger.warning("Error closing SentinelOne HTTP client: %s", exc)
        finally:
            self._closed = True

    def __enter__(self) -> "SentinelOneAPIClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def _build_url(self, endpoint: str) -> str:
        """
        Build full URL for API endpoint.

        Args:
            endpoint: API endpoint path (e.g., ENDPOINT_AGENTS)

        Returns:
            Full URL with base and API version
        """
        api_path = "/web/api/%s%s" % (API_VERSION, endpoint)
        return urljoin(self.base_url, api_path)

    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the SentinelOne API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            params: Query parameters
            data: Request body data

        Returns:
            Response data as dictionary

        Raises:
            SentinelOneAPIException: If the request fails
        """
        url = self._build_url(endpoint)

        if params is None:
            params = {}
        if self.site_id:
            params["siteIds"] = self.site_id
        if self.account_id:
            params["accountIds"] = self.account_id

        # Authorization added per-request to avoid credential exposure in client headers
        headers = dict(self._default_headers)
        headers["Authorization"] = "ApiToken %s" % self.api_token

        @retry(
            stop=stop_after_attempt(self.max_retries + 1),
            wait=wait_exponential(multiplier=0.5, max=30),
            retry=(retry_if_result(_should_retry_response) | retry_if_exception_type(_RETRYABLE_ERRORS)),
            reraise=True,
        )
        def _do_request() -> httpx.Response:
            return self.client.request(method=method, url=url, headers=headers, params=params, json=data)

        try:
            response = _do_request()
        except RetryError as exc:
            last_attempt = exc.last_attempt
            if last_attempt and not last_attempt.failed:
                result = last_attempt.result()
                if isinstance(result, httpx.Response):
                    response = result
                else:
                    logger.error("SentinelOne API request failed after %s retries", self.max_retries)
                    raise SentinelOneAPIException("Request failed after %s retries" % self.max_retries) from exc
            else:
                logger.error("SentinelOne API request failed after %s retries", self.max_retries)
                raise SentinelOneAPIException("Request failed after %s retries" % self.max_retries) from exc
        except _RETRYABLE_ERRORS as exc:
            logger.error("SentinelOne API request failed: %s", str(exc))
            raise SentinelOneAPIException("Request failed: %s" % str(exc)) from exc

        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code
            logger.error("SentinelOne API request failed: HTTP %s", status_code)
            logger.debug("Full error response: %s", exc.response.text)
            raise SentinelOneAPIException("HTTP %s: Request failed" % status_code) from exc

        return response.json()

    def test_connection(self) -> bool:
        """
        Test the connection to SentinelOne API.

        Returns:
            True if connection is successful

        Raises:
            SentinelOneAPIException: If connection test fails
        """
        try:
            response = self._make_request("GET", ENDPOINT_SYSTEM_INFO)

            if "data" in response:
                version = response["data"].get("build", "Unknown")
                logger.info("Successfully connected to SentinelOne (build: %s)", version)

            return True
        except SentinelOneAPIException as exc:
            logger.error("Connection test failed: %s", str(exc))
            raise

    def get_system_info(self) -> Dict[str, Any]:
        """
        Get SentinelOne system information.

        Returns:
            System info dictionary
        """
        response = self._make_request("GET", ENDPOINT_SYSTEM_INFO)

        if not isinstance(response, dict):
            raise SentinelOneAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        return response.get("data", {})

    def _paginate(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Paginate through API results using cursor-based pagination.

        Args:
            endpoint: API endpoint path
            params: Query parameters
            page_size: Number of results per page

        Yields:
            Individual records from the API response
        """
        if params is None:
            params = {}

        params["limit"] = page_size
        cursor = None
        total_yielded = 0

        while True:
            if cursor:
                params["cursor"] = cursor

            response = self._make_request("GET", endpoint, params=params)

            if not isinstance(response, dict):
                raise SentinelOneAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

            data = response.get("data", [])
            for item in data:
                yield item

            total_yielded += len(data)
            logger.info("Fetched %d records from %s...", total_yielded, endpoint)

            # Check for next cursor
            pagination = response.get("pagination", {})
            cursor = pagination.get("nextCursor")

            if not cursor or not data:
                break

    # Agent/Endpoint Methods

    def get_agents(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        cursor: Optional[str] = None,
        **filters,
    ) -> Dict[str, Any]:
        """
        Fetch agents/endpoints from SentinelOne.

        Args:
            limit: Maximum number of results to return
            cursor: Pagination cursor
            **filters: Additional filters (computerName, osType, etc.)

        Returns:
            API response with agents data and pagination
        """
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        params.update(filters)

        return self._make_request("GET", ENDPOINT_AGENTS, params=params)

    def get_all_agents(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> List[Dict[str, Any]]:
        """
        Fetch all agents with pagination support.

        Args:
            page_size: Number of results per page
            **filters: Additional filters

        Returns:
            List of all agent records
        """
        agents: List[Dict[str, Any]] = []

        for agent in self._paginate(ENDPOINT_AGENTS, params=filters, page_size=page_size):
            agents.append(agent)

        logger.info("Retrieved total of %s agents", len(agents))
        return agents

    def iter_agents(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Iterate through all agents.

        Args:
            page_size: Number of results per page
            **filters: Additional filters

        Yields:
            Agent records one at a time
        """
        yield from self._paginate(ENDPOINT_AGENTS, params=filters, page_size=page_size)

    def get_agent_by_id(self, agent_id: str) -> Dict[str, Any]:
        """
        Fetch a single agent by ID.

        Args:
            agent_id: The agent ID

        Returns:
            Agent record
        """
        response = self._make_request("GET", ENDPOINT_AGENTS, params={"ids": agent_id})

        if not isinstance(response, dict):
            raise SentinelOneAPIException(ERROR_UNEXPECTED_RESPONSE % type(response).__name__)

        data = response.get("data", [])
        if not data:
            raise SentinelOneAPIException("Agent not found: %s" % agent_id)

        return data[0]

    # Threat Methods

    def get_threats(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        cursor: Optional[str] = None,
        **filters,
    ) -> Dict[str, Any]:
        """
        Fetch threats from SentinelOne.

        Args:
            limit: Maximum number of results to return
            cursor: Pagination cursor
            **filters: Additional filters

        Returns:
            API response with threats data and pagination
        """
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        params.update(filters)

        return self._make_request("GET", ENDPOINT_THREATS, params=params)

    def get_all_threats(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> List[Dict[str, Any]]:
        """
        Fetch all threats with pagination support.

        Args:
            page_size: Number of results per page
            **filters: Additional filters (resolved, analystVerdict, etc.)

        Returns:
            List of all threat records
        """
        threats: List[Dict[str, Any]] = []

        for threat in self._paginate(ENDPOINT_THREATS, params=filters, page_size=page_size):
            threats.append(threat)

        logger.info("Retrieved total of %s threats", len(threats))
        return threats

    def iter_threats(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Iterate through all threats.

        Args:
            page_size: Number of results per page
            **filters: Additional filters

        Yields:
            Threat records one at a time
        """
        yield from self._paginate(ENDPOINT_THREATS, params=filters, page_size=page_size)

    # Vulnerability Methods (Singularity Ranger)

    def get_vulnerabilities(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        cursor: Optional[str] = None,
        **filters,
    ) -> Dict[str, Any]:
        """
        Fetch vulnerabilities from SentinelOne Ranger.

        Args:
            limit: Maximum number of results to return
            cursor: Pagination cursor
            **filters: Additional filters

        Returns:
            API response with vulnerability data and pagination
        """
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        params.update(filters)

        return self._make_request("GET", ENDPOINT_VULNERABILITIES, params=params)

    def get_all_vulnerabilities(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> List[Dict[str, Any]]:
        """
        Fetch all vulnerabilities with pagination support.

        Args:
            page_size: Number of results per page
            **filters: Additional filters (severity, cveId, etc.)

        Returns:
            List of all vulnerability records
        """
        vulns: List[Dict[str, Any]] = []

        for vuln in self._paginate(ENDPOINT_VULNERABILITIES, params=filters, page_size=page_size):
            vulns.append(vuln)

        logger.info("Retrieved total of %s vulnerabilities", len(vulns))
        return vulns

    def iter_vulnerabilities(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Iterate through all vulnerabilities.

        Args:
            page_size: Number of results per page
            **filters: Additional filters

        Yields:
            Vulnerability records one at a time
        """
        yield from self._paginate(ENDPOINT_VULNERABILITIES, params=filters, page_size=page_size)

    # Application Methods

    def get_applications(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        cursor: Optional[str] = None,
        **filters,
    ) -> Dict[str, Any]:
        """
        Fetch installed applications from SentinelOne.

        Args:
            limit: Maximum number of results to return
            cursor: Pagination cursor
            **filters: Additional filters

        Returns:
            API response with applications data and pagination
        """
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        params.update(filters)

        return self._make_request("GET", ENDPOINT_APPLICATIONS, params=params)

    def get_all_applications(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> List[Dict[str, Any]]:
        """
        Fetch all applications with pagination support.

        Args:
            page_size: Number of results per page
            **filters: Additional filters

        Returns:
            List of all application records
        """
        apps: List[Dict[str, Any]] = []

        for app in self._paginate(ENDPOINT_APPLICATIONS, params=filters, page_size=page_size):
            apps.append(app)

        logger.info("Retrieved total of %s applications", len(apps))
        return apps

    # Activity Methods

    def get_activities(
        self,
        limit: int = DEFAULT_PAGE_SIZE,
        cursor: Optional[str] = None,
        **filters,
    ) -> Dict[str, Any]:
        """
        Fetch activity logs from SentinelOne.

        Args:
            limit: Maximum number of results to return
            cursor: Pagination cursor
            **filters: Additional filters (activityTypes, createdAt__gt, etc.)

        Returns:
            API response with activity data and pagination
        """
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        params.update(filters)

        return self._make_request("GET", ENDPOINT_ACTIVITIES, params=params)

    def iter_activities(
        self,
        page_size: int = DEFAULT_PAGE_SIZE,
        **filters,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Iterate through all activities.

        Args:
            page_size: Number of results per page
            **filters: Additional filters

        Yields:
            Activity records one at a time
        """
        yield from self._paginate(ENDPOINT_ACTIVITIES, params=filters, page_size=page_size)
