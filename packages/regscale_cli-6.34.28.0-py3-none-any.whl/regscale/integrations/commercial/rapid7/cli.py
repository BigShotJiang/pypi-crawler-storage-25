#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rapid7 InsightVM CLI commands for RegScale.

This module provides Click commands for syncing Rapid7 InsightVM data to RegScale.
"""

import logging
import sys
from typing import Optional

import click

from regscale.models import regscale_id, regscale_module
from regscale.models.app_models.orchestration_options import orchestration_options

logger = logging.getLogger("regscale")

# Log message constants to avoid duplication
LOG_TARGET_REGSCALE_ID = "Target RegScale ID: %s"
LOG_TARGET_REGSCALE_MODULE = "Target RegScale Module: %s"
LOG_ERROR_SYNCING_ASSETS = "Error syncing assets: %s"
LOG_ERROR_SYNCING_FINDINGS = "Error syncing findings: %s"
LOG_ERROR_DURING_SYNC = "Error during sync: %s"


def _is_component_module(module_name: str) -> bool:
    """
    Determine if the module name indicates a component.

    Accepts both singular and plural forms, case-insensitive.

    :param str module_name: The RegScale module name (e.g., "components", "securityplans")
    :return: True if module is "components" or "component", False otherwise
    :rtype: bool
    """
    return module_name.lower() in ("components", "component")


@click.group()
def rapid7():
    """
    Rapid7 InsightVM Integration.

    Commands for syncing assets and vulnerabilities from
    Rapid7 InsightVM to RegScale.
    """
    pass


@rapid7.command(name="test_connection")
def test_connection():
    """
    Test connection to Rapid7 InsightVM API.

    Verifies that the configured Rapid7 credentials are valid
    and the API is accessible.
    """
    try:
        from regscale.integrations.commercial.rapid7.api_client import (
            Rapid7ApiClient,
            Rapid7ApiException,
        )
        from regscale.integrations.commercial.rapid7.variables import Rapid7Variables

        deployment_type = Rapid7Variables.rapid7DeploymentType or "console"
        logger.info("Testing Rapid7 InsightVM connection (deployment: %s)...", deployment_type)

        with Rapid7ApiClient(
            deployment_type=deployment_type,
            console_url=Rapid7Variables.rapid7Url or "",
            username=Rapid7Variables.rapid7Username or "",
            password=Rapid7Variables.rapid7Password or "",
            verify_ssl=Rapid7Variables.rapid7VerifySsl,
            api_key=Rapid7Variables.rapid7ApiKey or "",
            region=Rapid7Variables.rapid7Region or "us",
        ) as client:
            client.test_connection()
            logger.info("Successfully connected to Rapid7 InsightVM")
            click.echo("Successfully connected to Rapid7 InsightVM (%s)" % deployment_type)

    except Rapid7ApiException as exc:
        logger.error("Rapid7 API error: %s", str(exc))
        click.echo("Connection failed: %s" % str(exc), err=True)
        sys.exit(1)
    except Exception as exc:
        logger.error("Unexpected error testing Rapid7 connection: %s", str(exc))
        click.echo("Error: %s" % str(exc), err=True)
        sys.exit(1)


@rapid7.command(name="sync_assets")
@regscale_id()
@regscale_module()
@orchestration_options()
def sync_assets(
    regscale_id: int,
    regscale_module: str,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync Rapid7 InsightVM assets to RegScale.

    Fetches all assets from Rapid7 InsightVM and synchronizes them
    into the specified RegScale record.
    """
    try:
        from regscale.core.app.utils.regscale_utils import verify_provided_module
        from regscale.integrations.commercial.rapid7.api_client import Rapid7ApiException
        from regscale.integrations.commercial.rapid7.scanner import Rapid7Scanner

        # Verify the module is valid
        verify_provided_module(regscale_module)

        # Determine if this is a component based on module name
        is_component = _is_component_module(regscale_module)

        logger.info("Starting Rapid7 InsightVM asset synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)
        logger.info(LOG_TARGET_REGSCALE_MODULE, regscale_module)
        logger.info("Target is component: %s", is_component)

        Rapid7Scanner.sync_assets(
            plan_id=regscale_id, is_component=is_component, dry_run=dry_run, offset=offset, limit=limit
        )

        logger.info("Rapid7 InsightVM asset synchronization complete.")
        click.echo("Rapid7 InsightVM asset synchronization complete.")

    except Rapid7ApiException as exc:
        logger.error("Rapid7 API error during asset sync: %s", str(exc))
        click.echo(LOG_ERROR_SYNCING_ASSETS % str(exc), err=True)
        sys.exit(1)
    except Exception as exc:
        logger.error(LOG_ERROR_SYNCING_ASSETS, str(exc), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_ASSETS % str(exc), err=True)
        sys.exit(1)


@rapid7.command(name="sync_findings")
@regscale_id()
@regscale_module()
@orchestration_options()
def sync_findings(
    regscale_id: int,
    regscale_module: str,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync Rapid7 InsightVM vulnerabilities to RegScale.

    Fetches vulnerabilities from Rapid7 InsightVM and synchronizes
    them as findings into the specified RegScale record.
    """
    try:
        from regscale.core.app.utils.api_handler import APIInsertionError
        from regscale.core.app.utils.regscale_utils import verify_provided_module
        from regscale.integrations.commercial.rapid7.api_client import Rapid7ApiException
        from regscale.integrations.commercial.rapid7.scanner import Rapid7Scanner

        # Verify the module is valid
        verify_provided_module(regscale_module)

        # Determine if this is a component based on module name
        is_component = _is_component_module(regscale_module)

        logger.info("Starting Rapid7 InsightVM findings synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)
        logger.info(LOG_TARGET_REGSCALE_MODULE, regscale_module)
        logger.info("Target is component: %s", is_component)

        Rapid7Scanner.sync_findings(
            plan_id=regscale_id, is_component=is_component, dry_run=dry_run, offset=offset, limit=limit
        )

        logger.info("Rapid7 InsightVM findings synchronization complete.")
        click.echo("Rapid7 InsightVM findings synchronization complete.")

    except APIInsertionError as exc:
        logger.error(
            "Failed to create ScanHistory record in RegScale. "
            "Verify the target module (%s) and ID (%s) are correct: %s",
            regscale_module,
            regscale_id,
            str(exc),
        )
        click.echo(
            "Error: Failed to create ScanHistory record. Check that regscale_id and regscale_module are valid.",
            err=True,
        )
        sys.exit(1)
    except Rapid7ApiException as exc:
        logger.error("Rapid7 API error during findings sync: %s", str(exc))
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(exc), err=True)
        sys.exit(1)
    except Exception as exc:
        logger.error(LOG_ERROR_SYNCING_FINDINGS, str(exc), exc_info=True)
        click.echo(LOG_ERROR_SYNCING_FINDINGS % str(exc), err=True)
        sys.exit(1)


@rapid7.command(name="sync_all")
@regscale_id()
@regscale_module()
@orchestration_options()
def sync_all(
    regscale_id: int,
    regscale_module: str,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync all Rapid7 InsightVM data to RegScale.

    Synchronizes both assets and findings (vulnerabilities) from
    Rapid7 InsightVM to the specified RegScale record.
    """
    try:
        from regscale.core.app.utils.regscale_utils import verify_provided_module
        from regscale.integrations.commercial.rapid7.api_client import Rapid7ApiException
        from regscale.integrations.commercial.rapid7.scanner import Rapid7Scanner

        # Verify the module is valid
        verify_provided_module(regscale_module)

        # Determine if this is a component based on module name
        is_component = _is_component_module(regscale_module)

        logger.info("Starting full Rapid7 InsightVM synchronization...")
        logger.info(LOG_TARGET_REGSCALE_ID, regscale_id)
        logger.info(LOG_TARGET_REGSCALE_MODULE, regscale_module)
        logger.info("Target is component: %s", is_component)

        # Sync assets first
        logger.info("Syncing assets...")
        Rapid7Scanner.sync_assets(
            plan_id=regscale_id, is_component=is_component, dry_run=dry_run, offset=offset, limit=limit
        )

        # Then sync findings
        logger.info("Syncing findings...")
        Rapid7Scanner.sync_findings(
            plan_id=regscale_id, is_component=is_component, dry_run=dry_run, offset=offset, limit=limit
        )

        logger.info("Full Rapid7 InsightVM synchronization complete.")
        click.echo("Full Rapid7 InsightVM synchronization complete.")

    except Rapid7ApiException as exc:
        logger.error("Rapid7 API error during sync: %s", str(exc))
        click.echo(LOG_ERROR_DURING_SYNC % str(exc), err=True)
        sys.exit(1)
    except Exception as exc:
        logger.error(LOG_ERROR_DURING_SYNC, str(exc), exc_info=True)
        click.echo(LOG_ERROR_DURING_SYNC % str(exc), err=True)
        sys.exit(1)
