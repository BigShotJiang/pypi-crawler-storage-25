#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rapid7 InsightVM Pydantic models for API responses.

This module defines data models for assets and vulnerabilities returned
by the Rapid7 InsightVM Console API (v3) and Cloud API (v4).
"""

from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class Rapid7Asset(BaseModel):
    """Rapid7 InsightVM asset from API response."""

    model_config = ConfigDict(slots=True)

    id: int
    ip: str = ""
    host_name: Optional[str] = None
    mac: Optional[str] = None
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    os_family: Optional[str] = None
    os_vendor: Optional[str] = None
    os_architecture: Optional[str] = None
    os_cpe: Optional[str] = None
    risk_score: float = 0.0
    asset_type: Optional[str] = None
    assessed_for_vulnerabilities: bool = False
    tags: List[str] = Field(default_factory=list)
    last_scan_end: Optional[str] = None
    unique_identifiers: List[Dict[str, str]] = Field(default_factory=list)

    @classmethod
    def from_v3_response(cls, data: dict) -> "Rapid7Asset":
        """Parse Console API v3 response into a Rapid7Asset.

        Args:
            data: Raw dictionary from the Rapid7 Console API v3 response.

        Returns:
            Rapid7Asset instance populated from the v3 response data.
        """
        os_data = data.get("os", {}) or {}
        addresses = data.get("addresses", []) or []
        ip = data.get("ip", "")
        mac = ""
        for addr in addresses:
            if not ip and addr.get("ip"):
                ip = addr["ip"]
            if not mac and addr.get("mac"):
                mac = addr["mac"]
        cpe_data = os_data.get("cpe")
        os_cpe = cpe_data.get("v2.3", "") if isinstance(cpe_data, dict) else ""
        return cls(
            id=data["id"],
            ip=ip,
            host_name=data.get("hostName") or data.get("host_name"),
            mac=mac,
            os_name=os_data.get("description", ""),
            os_version=os_data.get("version", ""),
            os_family=os_data.get("family", ""),
            os_vendor=os_data.get("vendor", ""),
            os_architecture=os_data.get("architecture", ""),
            os_cpe=os_cpe,
            risk_score=data.get("riskScore", 0.0),
            asset_type=data.get("type"),
            assessed_for_vulnerabilities=data.get("assessedForVulnerabilities", False),
            tags=[t.get("name", "") for t in (data.get("tags", []) or [])],
            last_scan_end=data.get("history", [{}])[0].get("date") if data.get("history") else None,
            unique_identifiers=data.get("uniqueIdentifiers", []),
        )

    @classmethod
    def from_v4_response(cls, data: dict) -> "Rapid7Asset":
        """Parse Cloud API v4 response into a Rapid7Asset.

        Args:
            data: Raw dictionary from the Rapid7 Cloud API v4 response.

        Returns:
            Rapid7Asset instance populated from the v4 response data.
        """
        os_data = data.get("os", {}) or {}
        return cls(
            id=data["id"],
            ip=data.get("ip", ""),
            host_name=data.get("host_name"),
            mac=data.get("mac"),
            os_name=os_data.get("description", ""),
            os_version=os_data.get("version", ""),
            os_family=os_data.get("family", ""),
            os_vendor=os_data.get("vendor", ""),
            os_architecture=os_data.get("architecture", ""),
            risk_score=data.get("risk_score", 0.0),
            assessed_for_vulnerabilities=data.get("assessed_for_vulnerabilities", False),
            tags=[t.get("name", "") for t in (data.get("tags", []) or [])],
            last_scan_end=data.get("last_scan_end"),
            unique_identifiers=data.get("unique_identifiers", []),
        )


class Rapid7Vulnerability(BaseModel):
    """Rapid7 InsightVM vulnerability from API response."""

    model_config = ConfigDict(slots=True)

    id: str
    title: str = ""
    description: str = ""
    severity: str = ""
    cvss_v3_score: Optional[float] = None
    cvss_v2_score: Optional[float] = None
    cvss_v3_vector: Optional[str] = None
    cvss_v2_vector: Optional[str] = None
    cves: List[str] = Field(default_factory=list)
    categories: List[str] = Field(default_factory=list)
    added: Optional[str] = None
    modified: Optional[str] = None
    risk_score: float = 0.0
    exploit_count: int = 0
    solution_fix: Optional[str] = None
    solution_summary: Optional[str] = None
    status: str = "vulnerable"
    port: Optional[int] = None
    protocol: Optional[str] = None
    proof: Optional[str] = None
    first_found: Optional[str] = None
    last_found: Optional[str] = None
    asset_id: Optional[int] = None

    @classmethod
    def from_v3_response(cls, data: dict, asset_id: Optional[int] = None) -> "Rapid7Vulnerability":
        """Parse Console API v3 response into a Rapid7Vulnerability.

        Args:
            data: Raw dictionary from the Rapid7 Console API v3 response.
            asset_id: Optional parent asset ID for per-asset vulnerability context.

        Returns:
            Rapid7Vulnerability instance populated from the v3 response data.
        """
        cvss = data.get("cvss", {}) or {}
        cvss_v3 = cvss.get("v3", {}) or {}
        cvss_v2 = cvss.get("v2", {}) or {}
        exploits = data.get("exploits", []) or []
        solutions = data.get("solutions", []) or []
        raw_description = data.get("description")
        if isinstance(raw_description, dict):
            description = raw_description.get("text", "")
        else:
            description = str(raw_description) if raw_description else ""
        return cls(
            id=data.get("id", ""),
            title=data.get("title", ""),
            description=description,
            severity=data.get("severity", ""),
            cvss_v3_score=cvss_v3.get("score"),
            cvss_v2_score=cvss_v2.get("score"),
            cvss_v3_vector=cvss_v3.get("vector"),
            cvss_v2_vector=cvss_v2.get("vector"),
            cves=data.get("cves", []) or [],
            categories=data.get("categories", []) or [],
            added=data.get("added"),
            modified=data.get("modified"),
            risk_score=data.get("riskScore", 0.0),
            exploit_count=len(exploits),
            solution_fix=solutions[0].get("fix", "") if solutions else None,
            solution_summary=solutions[0].get("summary", "") if solutions else None,
            status=data.get("status", "vulnerable"),
            port=data.get("port"),
            protocol=data.get("protocol"),
            proof=data.get("proof"),
            first_found=data.get("since"),
            last_found=data.get("lastFound"),
            asset_id=asset_id,
        )

    @classmethod
    def from_v4_response(cls, data: dict, asset_id: Optional[int] = None) -> "Rapid7Vulnerability":
        """Parse Cloud API v4 response into a Rapid7Vulnerability.

        Args:
            data: Raw dictionary from the Rapid7 Cloud API v4 response.
            asset_id: Optional parent asset ID for per-asset vulnerability context.

        Returns:
            Rapid7Vulnerability instance populated from the v4 response data.
        """
        cvss_v3 = data.get("cvss_v3", {}) or {}
        cvss_v2 = data.get("cvss_v2", {}) or {}
        exploits = data.get("exploits", []) or []
        return cls(
            id=data.get("vulnerability_id", data.get("id", "")),
            title=data.get("title", ""),
            description=data.get("description", ""),
            severity=data.get("severity", ""),
            cvss_v3_score=cvss_v3.get("score"),
            cvss_v2_score=cvss_v2.get("score"),
            cvss_v3_vector=cvss_v3.get("vector"),
            cvss_v2_vector=cvss_v2.get("vector"),
            cves=data.get("cves", []) or [],
            categories=data.get("categories", []) or [],
            added=data.get("added"),
            modified=data.get("modified"),
            risk_score=data.get("risk_score", 0.0),
            exploit_count=len(exploits),
            solution_fix=data.get("solution_fix"),
            solution_summary=data.get("solution_summary"),
            status=data.get("status", "vulnerable"),
            port=data.get("port"),
            protocol=data.get("protocol"),
            proof=data.get("proof"),
            first_found=data.get("first_found"),
            last_found=data.get("last_found"),
            asset_id=asset_id,
        )
