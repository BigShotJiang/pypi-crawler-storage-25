#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rapid7 InsightVM Variables for RegScale CLI configuration.

This module defines configuration variables for the Rapid7 InsightVM integration,
following the RegScale variable pattern using RsVariablesMeta metaclass.
"""

from regscale.core.app.utils.variables import RsVariablesMeta, RsVariableType


class Rapid7Variables(metaclass=RsVariablesMeta):
    """
    Rapid7 InsightVM configuration variables.

    These variables are read from the RegScale init.yaml configuration file
    or from environment variables. They control the Rapid7 InsightVM API integration.

    Attributes:
        rapid7DeploymentType: Deployment type - "console" for on-prem or "cloud" for InsightVM Cloud
        rapid7Url: Base URL of the Rapid7 InsightVM console (on-prem)
        rapid7Username: Username for console authentication
        rapid7Password: Password for console authentication
        rapid7VerifySsl: Whether to verify SSL certificates
        rapid7ApiKey: API key for InsightVM Cloud (v4 API)
        rapid7Region: Cloud region (us, us2, us3, eu, ca, au, ap)
        rapid7SiteIds: Comma-separated site IDs to filter scans
        rapid7PageSize: Page size for API pagination (max 500)
    """

    # Deployment type: "console" (on-prem v3 API) or "cloud" (InsightVM Cloud v4 API)
    rapid7DeploymentType: RsVariableType(  # type: ignore # noqa: F722,F821
        str,
        "console",
        required=False,
        default="console",
    )

    # Console URL for on-prem deployments
    rapid7Url: RsVariableType(  # type: ignore # noqa: F722,F821
        str,
        "https://insightvm.company.com:3780",
        required=False,
    )

    # Username for console authentication (on-prem)
    rapid7Username: RsVariableType(  # type: ignore # noqa: F722,F821
        str,
        "admin",
        required=False,
        sensitive=True,
    )

    # Password for console authentication (on-prem)
    rapid7Password: RsVariableType(  # type: ignore # noqa: F722,F821
        str,
        "password",
        required=False,
        sensitive=True,
    )

    # SSL verification
    rapid7VerifySsl: RsVariableType(  # type: ignore # noqa: F722,F821
        bool,
        "True",
        required=False,
        default=True,
    )

    # API key for InsightVM Cloud (v4 API)
    rapid7ApiKey: RsVariableType(  # type: ignore # noqa: F722,F821
        str,
        "your-api-key-here",
        required=False,
        sensitive=True,
    )

    # Cloud region for InsightVM Cloud API
    rapid7Region: RsVariableType(  # type: ignore # noqa: F722,F821
        str,
        "us",
        required=False,
        default="us",
    )

    # Comma-separated site IDs to filter (empty string means all sites)
    rapid7SiteIds: RsVariableType(  # type: ignore # noqa: F722,F821
        str,
        "",
        required=False,
        default="",
    )

    # Page size for API pagination (max 500 for Rapid7 API)
    rapid7PageSize: RsVariableType(  # type: ignore # noqa: F722,F821
        int,
        "500",
        required=False,
        default=500,
    )

    # Max concurrent workers for Console v3 per-asset vulnerability fetch
    rapid7MaxWorkers: RsVariableType(  # type: ignore # noqa: F722,F821
        int,
        "50",
        required=False,
        default=50,
    )
