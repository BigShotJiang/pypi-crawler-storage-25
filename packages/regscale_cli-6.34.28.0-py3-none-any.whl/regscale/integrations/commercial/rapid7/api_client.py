#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rapid7 InsightVM API Client.

Supports both Console API v3 (on-prem, Basic Auth) and
Cloud Integrations API v4 (SaaS, X-Api-Key).
"""

import logging
import urllib.parse
from typing import Any, Dict, Iterator, Optional

import httpx

from regscale.core.app.utils.mock_service_headers import get_mock_service_headers

logger = logging.getLogger("regscale")

# Constants
V3_MAX_PAGE_SIZE = 500
V4_MAX_PAGE_SIZE = 1000
DEFAULT_TIMEOUT = 30
CONNECT_TIMEOUT = 30
READ_TIMEOUT = 120


class Rapid7ApiException(Exception):
    """Exception for Rapid7 API errors."""

    pass


class Rapid7ApiClient:
    """
    HTTP client for Rapid7 InsightVM APIs.

    Supports Console API v3 (on-prem) and Cloud Integrations API v4 (SaaS).
    Uses a single long-lived httpx.Client for connection pooling.
    """

    def __init__(
        self,
        deployment_type: str = "console",
        console_url: str = "",
        username: str = "",
        password: str = "",
        verify_ssl: bool = True,
        api_key: str = "",
        region: str = "us",
        page_size: int = V3_MAX_PAGE_SIZE,
    ):
        """
        Initialize Rapid7 API client.

        Args:
            deployment_type: "console" for on-prem (Basic Auth) or "cloud" for SaaS (X-Api-Key).
            console_url: Base URL for Console API v3 (e.g., "https://insightvm.example.com:3780").
            username: Username for Console API v3 Basic Auth.
            password: Password for Console API v3 Basic Auth.
            verify_ssl: Whether to verify SSL certificates (Console only).
            api_key: API key for Cloud Integrations API v4.
            region: Cloud region identifier (e.g., "us", "eu", "au", "ca", "ap").
            page_size: Number of records per page (max 500 for v3, max 1000 for v4).
        """
        self.deployment_type = deployment_type
        max_size = V4_MAX_PAGE_SIZE if deployment_type == "cloud" else V3_MAX_PAGE_SIZE
        self.page_size = min(page_size, max_size)

        # Sized to accommodate parallel vuln-detail fetching in Console v3 streaming path
        limits = httpx.Limits(max_connections=200, max_keepalive_connections=100)

        if deployment_type == "console":
            self.base_url = console_url.rstrip("/")
            self._client = httpx.Client(
                auth=(username, password),
                verify=verify_ssl,
                http2=True,
                limits=limits,
                timeout=httpx.Timeout(CONNECT_TIMEOUT, read=READ_TIMEOUT),
                headers={"Accept": "application/json", "Content-Type": "application/json"},
            )
        else:  # cloud
            self.base_url = f"https://{region}.api.insight.rapid7.com"
            self._client = httpx.Client(
                verify=True,
                http2=True,
                limits=limits,
                timeout=httpx.Timeout(CONNECT_TIMEOUT, read=READ_TIMEOUT),
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "X-Api-Key": api_key,
                },
            )

        _mock_headers = get_mock_service_headers("rapid7")
        if _mock_headers:
            self._client.headers.update(_mock_headers)

    def close(self) -> None:
        """Close the HTTP client and release connection pool resources."""
        self._client.close()

    def __enter__(self) -> "Rapid7ApiClient":
        """Support usage as a context manager."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Close the client on context manager exit."""
        self.close()

    # --- Connection Test ---

    def test_connection(self) -> bool:
        """
        Test API connectivity.

        Returns:
            True on success.

        Raises:
            Rapid7ApiException: If authentication or authorization fails.
            httpx.HTTPStatusError: If the request fails for other reasons.
        """
        if self.deployment_type == "console":
            url = urllib.parse.urljoin(self.base_url + "/", "api/3/administration/info")
            response = self._client.get(url)
        else:
            url = urllib.parse.urljoin(self.base_url + "/", "vm/v4/integration/assets")
            response = self._client.post(url, json={"size": 1})

        if response.status_code == 401:
            raise Rapid7ApiException("Authentication failed - check credentials/API key")
        if response.status_code == 403:
            raise Rapid7ApiException("Authorization failed - insufficient permissions")
        response.raise_for_status()
        return True

    # --- Asset Methods ---

    def get_assets(self, site_id: Optional[int] = None) -> Iterator[Dict[str, Any]]:
        """
        Fetch all assets, optionally filtered by site.

        Args:
            site_id: Optional site ID filter (Console v3 only).

        Yields:
            Raw asset dictionaries from the API.
        """
        if self.deployment_type == "console":
            yield from self._get_assets_v3(site_id)
        else:
            yield from self._get_assets_v4()

    def _get_assets_v3(self, site_id: Optional[int] = None) -> Iterator[Dict[str, Any]]:
        """Console API v3: paginated GET on /api/3/assets or /api/3/sites/{id}/assets."""
        if site_id:
            path = f"api/3/sites/{site_id}/assets"
        else:
            path = "api/3/assets"
        url = urllib.parse.urljoin(self.base_url + "/", path)
        yield from self._paginate_v3(url)

    def _get_assets_v4(self) -> Iterator[Dict[str, Any]]:
        """Cloud API v4: POST to /vm/v4/integration/assets."""
        url = urllib.parse.urljoin(self.base_url + "/", "vm/v4/integration/assets")
        yield from self._paginate_v4(url, body={})

    # --- Vulnerability Methods ---

    def get_asset_vulnerabilities(self, asset_id: int) -> Iterator[Dict[str, Any]]:
        """
        Fetch vulnerabilities for a specific asset.

        Args:
            asset_id: The asset ID to retrieve vulnerabilities for.

        Yields:
            Raw vulnerability dictionaries from the API.
        """
        if self.deployment_type == "console":
            yield from self._get_asset_vulns_v3(asset_id)
        else:
            yield from self._get_vulns_v4()

    def _get_asset_vulns_v3(self, asset_id: int) -> Iterator[Dict[str, Any]]:
        """Console API v3: GET /api/3/assets/{id}/vulnerabilities."""
        url = urllib.parse.urljoin(self.base_url + "/", f"api/3/assets/{asset_id}/vulnerabilities")
        yield from self._paginate_v3(url)

    def _get_vulns_v4(self) -> Iterator[Dict[str, Any]]:
        """Cloud API v4: POST /vm/v4/integration/vulnerabilities."""
        url = urllib.parse.urljoin(self.base_url + "/", "vm/v4/integration/vulnerabilities")
        yield from self._paginate_v4(url, body={})

    def get_vulnerability_details(self, vuln_id: str) -> Dict[str, Any]:
        """
        Get detailed vulnerability definition (Console v3 only).

        Args:
            vuln_id: The vulnerability identifier string.

        Returns:
            Vulnerability detail dictionary.

        Raises:
            httpx.HTTPStatusError: If the request fails.
        """
        url = urllib.parse.urljoin(self.base_url + "/", f"api/3/vulnerabilities/{urllib.parse.quote(vuln_id)}")
        response = self._client.get(url)
        response.raise_for_status()
        return response.json()

    # --- Site Methods ---

    def get_sites(self) -> Iterator[Dict[str, Any]]:
        """
        List scan sites (Console v3 only).

        Yields:
            Raw site dictionaries from the API.
        """
        if self.deployment_type != "console":
            logger.warning("get_sites() is only available for Console API v3")
            return
        url = urllib.parse.urljoin(self.base_url + "/", "api/3/sites")
        yield from self._paginate_v3(url)

    # --- Pagination ---

    def _paginate_v3(self, url: str, params: Optional[Dict[str, Any]] = None) -> Iterator[Dict[str, Any]]:
        """
        Console API v3 page-based pagination.

        Args:
            url: The fully-qualified API URL to paginate.
            params: Optional query parameters to include with each request.

        Yields:
            Individual resource dictionaries from paginated responses.

        Raises:
            Rapid7ApiException: If authentication fails or HTTP error occurs.
        """
        if params is None:
            params = {}
        page = 0
        while True:
            params["page"] = page
            params["size"] = self.page_size
            try:
                response = self._client.get(url, params=params)
                if response.status_code == 401:
                    raise Rapid7ApiException("Authentication failed")
                response.raise_for_status()
            except httpx.HTTPStatusError as exc:
                logger.error("Rapid7 API error on %s: %s", url, exc.response.status_code)
                raise Rapid7ApiException(f"API request failed: {exc.response.status_code}") from exc

            data = response.json()
            resources = data.get("resources", [])
            if not resources:
                break
            yield from resources

            page_info = data.get("page", {})
            total_pages = page_info.get("totalPages", 0)
            if page >= total_pages - 1:
                break
            page += 1
            logger.debug("Fetching page %d/%d from %s", page + 1, total_pages, url)

    def _paginate_v4(self, url: str, body: Dict[str, Any]) -> Iterator[Dict[str, Any]]:
        """
        Cloud API v4 cursor-based pagination.

        Args:
            url: The fully-qualified API URL to paginate.
            body: Base request body to include with each POST request.

        Yields:
            Individual resource dictionaries from paginated responses.

        Raises:
            Rapid7ApiException: If authentication fails or HTTP error occurs.
        """
        cursor = None
        while True:
            request_body = {**body, "size": self.page_size}
            if cursor:
                request_body["cursor"] = cursor
            try:
                response = self._client.post(url, json=request_body)
                if response.status_code == 401:
                    raise Rapid7ApiException("Authentication failed - check API key")
                response.raise_for_status()
            except httpx.HTTPStatusError as exc:
                logger.error("Rapid7 Cloud API error on %s: %s", url, exc.response.status_code)
                raise Rapid7ApiException(f"Cloud API request failed: {exc.response.status_code}") from exc

            data = response.json()
            resources = data.get("data", [])
            if not resources:
                break
            yield from resources

            metadata = data.get("metadata", {})
            cursor = metadata.get("cursor")
            if not cursor:
                break
            logger.debug("Fetching next page from %s (cursor present)", url)
