#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""High-level orchestration for the Jira Data Center integration.

This module is deliberately thin: it composes :class:`JiraDcClient`, the
mappers, and the RegScale Pydantic model methods to produce the user-facing
sync behaviour. Click commands in :mod:`cli.py` parse arguments and then call
directly into these functions.

Every write to the RegScale platform uses :func:`Issue.batch_create` or
:func:`Task.bulk_save` rather than ad-hoc REST calls (commandment #3).
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Set, Tuple

import click
import httpx

from regscale.core.app.api import Api
from regscale.integrations.commercial.jira_dc.auth import resolve_auth
from regscale.integrations.commercial.jira_dc.client import JiraDcClient
from regscale.integrations.commercial.jira_dc.constants import (
    CLOSED_REGSCALE_STATUSES,
    JIRA_ATTACHMENT_PREFIX,
    SEARCH_FIELDS,
)
from regscale.integrations.commercial.jira_dc.exceptions import (
    JiraDcConfigurationError,
    JiraDcError,
    JiraDcPermissionError,
    JiraDcValidationError,
)
from regscale.integrations.commercial.jira_dc.mappers import (
    apply_updates_in_place,
    map_jira_to_regscale_issue,
    map_jira_to_regscale_task,
    map_regscale_to_jira_payload,
    map_regscale_to_jira_update_payload,
)
from regscale.models.regscale_models.comment import Comment
from regscale.models.regscale_models.file import File
from regscale.models.regscale_models.issue import Issue
from regscale.models.regscale_models.task import Task

logger = logging.getLogger("regscale")

VALID_SEVERITIES: Set[str] = {"critical", "high", "medium", "moderate", "low"}


@dataclass
class JiraDcSyncResult:
    """Thread-safe collector for sync outcomes."""

    created: int = 0
    updated: int = 0
    pushed: int = 0
    errors: List[str] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def add_error(self, message: str) -> None:
        """Record an error string (thread-safe)."""
        with self._lock:
            self.errors.append(message)

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable snapshot of the result."""
        return {
            "created": self.created,
            "updated": self.updated,
            "pushed": self.pushed,
            "errors": list(self.errors),
        }


def _build_client(
    config: Mapping[str, Any],
    verify_ssl: bool,
    page_size: Optional[int] = None,
) -> JiraDcClient:
    """Construct and return a connected :class:`JiraDcClient`."""
    base_url = str(config.get("jiraDcUrl") or "").strip()
    if not base_url:
        raise JiraDcConfigurationError(
            "jiraDcUrl is not configured. Set jiraDcUrl in init.yaml or JIRA_DC_URL env var.",
        )
    effective_page_size = int(page_size or config.get("jiraDcPageSize") or 50)
    timeout = int(config.get("jiraDcTimeoutSeconds") or 60)
    auth = resolve_auth(config)
    return JiraDcClient(
        base_url=base_url,
        auth=auth,
        verify_ssl=verify_ssl,
        timeout=timeout,
        page_size=effective_page_size,
    )


def _default_jql(project: str, issue_type: str) -> str:
    """Return the default JQL query for the given project / issue type."""
    return f'project = "{project}" AND issuetype = "{issue_type}"'


def _load_regscale_issues(parent_id: int, parent_module: str) -> Tuple[List[Issue], Dict[str, Issue]]:
    """Load existing RegScale issues for the parent and index them by jiraId."""
    issues = Issue.get_all_by_parent(parent_id, parent_module)
    by_jira_id: Dict[str, Issue] = {i.jiraId: i for i in issues if getattr(i, "jiraId", None)}
    return issues, by_jira_id


def _load_regscale_tasks(parent_id: int, parent_module: str) -> Tuple[List[Task], Dict[str, Task]]:
    """Load existing RegScale tasks for the parent and index them by otherIdentifier."""
    tasks = Task.get_all_by_parent(parent_id, parent_module)
    by_key: Dict[str, Task] = {t.otherIdentifier: t for t in tasks if getattr(t, "otherIdentifier", None)}
    return tasks, by_key


def _validate_issue_type(client: JiraDcClient, project: str, issue_type: str) -> None:
    """Verify that the requested issue type exists in the Jira project."""
    meta = client.create_meta(project)
    projects = meta.get("projects") or []
    if not projects:
        raise JiraDcValidationError(f"Jira project {project!r} not found or inaccessible.")
    issue_types = {it.get("name") for it in (projects[0].get("issuetypes") or []) if it.get("name")}
    if issue_type not in issue_types:
        raise JiraDcValidationError(
            f"Issue type {issue_type!r} not valid for project {project!r}. Available: {sorted(issue_types)}",
        )


def _slice_stream(
    stream: Iterable[Dict[str, Any]],
    offset: Optional[int],
    limit: Optional[int],
) -> Iterable[Dict[str, Any]]:
    """Apply client-side offset/limit to a streaming iterator."""
    skipped = 0
    yielded = 0
    for item in stream:
        if offset and skipped < offset:
            skipped += 1
            continue
        if limit is not None and yielded >= limit:
            return
        yield item
        yielded += 1


# ------------------------------------------------------------------ issues
def sync_issues(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    jira_issue_type: str,
    sync_attachments: bool = True,
    jql: Optional[str] = None,
    use_poams: bool = False,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
    verify_ssl: bool = True,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Bidirectional sync of issues between Jira DC and RegScale."""
    cfg: Mapping[str, Any] = config or {}
    result = JiraDcSyncResult()
    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        _validate_issue_type(client, jira_project, jira_issue_type)

        jql_text = jql or _default_jql(jira_project, jira_issue_type)
        regscale_issues, by_jira_id = _load_regscale_issues(parent_id, parent_module)

        to_create: List[Issue] = []
        to_update: List[Issue] = []

        stream = _slice_stream(client.search(jql_text, SEARCH_FIELDS), offset, limit)
        for payload in stream:
            key = payload.get("key")
            existing = by_jira_id.get(key) if key else None
            if existing:
                apply_updates_in_place(existing, payload, cfg)
                to_update.append(existing)
            else:
                to_create.append(
                    map_jira_to_regscale_issue(payload, cfg, parent_id, parent_module, is_poam=use_poams),
                )

        result.created = len(to_create)
        result.updated = len(to_update)

        if dry_run:
            click.echo(json.dumps(result.to_dict()))
            return result

        if to_create:
            Issue.batch_create(to_create)
        if to_update:
            for issue in to_update:
                issue.save(bulk=True)
            Issue.bulk_save()

        orphan_issues = [i for i in regscale_issues if not getattr(i, "jiraId", None)]
        if orphan_issues:
            result.pushed = _push_regscale_to_jira(
                client=client,
                issues=orphan_issues,
                project_key=jira_project,
                issue_type=jira_issue_type,
                result=result,
            )
        if sync_attachments:
            # Placeholder hook — detailed attachment sync lives in
            # sync_attachments() so the issues path stays fast.
            logger.debug("sync_attachments=True — run jira_dc sync_attachments for attachment reconciliation")
    return result


# ------------------------------------------------------------------ tasks
def sync_tasks(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    sync_attachments: bool = True,
    jql: Optional[str] = None,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
    verify_ssl: bool = True,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Sync Jira DC issues of type ``Task`` into RegScale Task objects."""
    cfg: Mapping[str, Any] = config or {}
    result = JiraDcSyncResult()
    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        _validate_issue_type(client, jira_project, "Task")

        jql_text = jql or _default_jql(jira_project, "Task")
        _, by_key = _load_regscale_tasks(parent_id, parent_module)

        to_create: List[Task] = []
        to_update: List[Task] = []

        stream = _slice_stream(client.search(jql_text, SEARCH_FIELDS), offset, limit)
        for payload in stream:
            key = payload.get("key")
            existing = by_key.get(key) if key else None
            mapped = map_jira_to_regscale_task(payload, parent_id, parent_module)
            if existing:
                existing.title = mapped.title
                existing.description = mapped.description
                existing.status = mapped.status
                existing.dueDate = mapped.dueDate
                existing.dateClosed = mapped.dateClosed
                existing.percentComplete = mapped.percentComplete
                to_update.append(existing)
            else:
                to_create.append(mapped)

        result.created = len(to_create)
        result.updated = len(to_update)

        if dry_run:
            click.echo(json.dumps(result.to_dict()))
            return result

        if to_create:
            # Task model does not expose a batch_create endpoint, so create tasks
            # individually. Volume is typically low enough that this is fine.
            for task in to_create:
                task.create()
        if to_update:
            for task in to_update:
                task.save(bulk=True)
            Task.bulk_save()
        if sync_attachments:
            logger.debug("sync_attachments=True — run jira_dc sync_attachments for attachment reconciliation")
    return result


# ------------------------------------------------------------------ push
def _push_one_to_jira(
    client: JiraDcClient,
    issue: Issue,
    project_key: str,
    issue_type: str,
    result: JiraDcSyncResult,
) -> Optional[str]:
    """Create a single issue in Jira DC from a RegScale Issue."""
    try:
        payload = map_regscale_to_jira_payload(issue, project_key, issue_type)
        response = client.create_issue(payload)
        jira_key = response.get("key")
        if jira_key:
            issue.jiraId = jira_key
            # Bypass change tracking: RegScaleModel captures _original_data
            # lazily on first has_changed() call, so a mutation made before
            # any tracking access ends up baked into the "original" snapshot.
            # _ignore_has_changed is the documented escape hatch checked in
            # RegScaleModel.save() (also used by model_editor and the
            # compliance assessment handler).
            issue._ignore_has_changed = True  # noqa: SLF001
        return jira_key
    except JiraDcError as exc:
        result.add_error(f"Failed to push issue {getattr(issue, 'id', '?')}: {exc}")
    except Exception as exc:  # noqa: BLE001 — we log-and-continue on push
        result.add_error(f"Unexpected error pushing issue {getattr(issue, 'id', '?')}: {exc}")
    return None


def _push_regscale_to_jira(
    client: JiraDcClient,
    issues: List[Issue],
    project_key: str,
    issue_type: str,
    result: JiraDcSyncResult,
    max_workers: int = 5,
) -> int:
    """Push a batch of RegScale issues to Jira DC using a ThreadPoolExecutor."""
    if not issues:
        return 0
    workers = max(1, min(max_workers, len(issues)))
    created_keys: List[str] = []
    updated_issues: List[Issue] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_push_one_to_jira, client, issue, project_key, issue_type, result) for issue in issues]
        for issue, future in zip(issues, futures):
            key = future.result()
            if key:
                created_keys.append(key)
                updated_issues.append(issue)

    if updated_issues:
        for issue in updated_issues:
            issue.save(bulk=True)
        Issue.bulk_save()
    return len(created_keys)


def _update_single_jira_issue(
    client: JiraDcClient,
    issue: Issue,
    result: JiraDcSyncResult,
) -> bool:
    """Update an existing Jira issue from a RegScale Issue; returns True on success."""
    jira_key = str(issue.jiraId)
    try:
        current = client.get_issue(jira_key)
    except JiraDcError as exc:
        result.add_error(f"Failed to fetch Jira issue {jira_key}: {exc}")
        return False
    if current is None:
        logger.warning("Jira issue %s not found (404); clearing jiraId on RegScale issue %s", jira_key, issue.id)
        issue.jiraId = None
        result.add_error(f"Jira issue {jira_key} not found; jiraId cleared on RegScale issue {issue.id}")
        return False
    existing_fields = current.get("fields") if isinstance(current, dict) else None
    payload = map_regscale_to_jira_update_payload(issue, existing_fields)
    if not payload.get("fields"):
        logger.debug("No-op update for Jira %s (all fields unchanged)", jira_key)
        return False
    try:
        client.update_issue(jira_key, payload)
    except JiraDcPermissionError as exc:
        logger.warning("Permission denied updating Jira issue %s: %s", jira_key, exc)
        result.add_error(f"Permission denied updating {jira_key}: {exc}")
        return False
    except JiraDcError as exc:
        result.add_error(f"Failed to update Jira issue {jira_key}: {exc}")
        return False
    return True


def _apply_updates_in_jira(
    client: JiraDcClient,
    issues: List[Issue],
    result: JiraDcSyncResult,
) -> int:
    """Iterate issues with a ``jiraId`` and push field updates back to Jira."""
    updated = 0
    for issue in issues:
        if _update_single_jira_issue(client, issue, result):
            updated += 1
    return updated


def push_issues(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    jira_issue_type: str,
    dry_run: bool = False,
    verify_ssl: bool = True,
    update_existing: bool = False,
    push_filter_label: Optional[str] = None,
    push_filter_status: Optional[str] = None,
    push_filter_severity: Optional[str] = None,
    push_filter_ids: Optional[str] = None,
    push_filter_source: Optional[str] = None,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Push orphan RegScale issues into Jira DC, optionally updating linked ones.

    Filters (all combined with AND when multiple supplied):

    * ``push_filter_label`` — substring match against RegScale Issue title or
      description.
    * ``push_filter_status`` — comma-separated RegScale statuses
      (default: ``"Open"``).
    * ``push_filter_severity`` — comma-separated severities
      (Critical / High / Medium / Low).
    * ``push_filter_ids`` — comma-separated RegScale Issue IDs.
    * ``push_filter_source`` — comma-separated source-attribution tokens
      matched against ``sourceReport`` / ``integrationFindingId`` /
      ``securityChecks`` / ``description``.
    """
    cfg: Mapping[str, Any] = config or {}
    statuses = _normalise_csv(push_filter_status) or ["open"]
    severities = _validate_severity_tokens(_normalise_csv(push_filter_severity))
    ids = _parse_int_csv(push_filter_ids)
    sources = _normalise_csv(push_filter_source)
    predicate = build_push_filter(
        label=push_filter_label,
        statuses=statuses,
        severities=severities,
        ids=ids,
        sources=sources,
    )
    result = JiraDcSyncResult()
    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        _validate_issue_type(client, jira_project, jira_issue_type)

        issues = Issue.get_all_by_parent(parent_id, parent_module)
        orphans = [i for i in issues if not getattr(i, "jiraId", None) and predicate(i)]
        linked = [i for i in issues if getattr(i, "jiraId", None) and predicate(i)] if update_existing else []

        if dry_run:
            result.pushed = len(orphans)
            result.updated = len(linked)
            click.echo(json.dumps(result.to_dict()))
            return result

        result.pushed = _push_regscale_to_jira(
            client=client,
            issues=orphans,
            project_key=jira_project,
            issue_type=jira_issue_type,
            result=result,
        )
        if linked:
            result.updated = _apply_updates_in_jira(client, linked, result)
    return result


# ------------------------------------------------------------------ attachments
def _sha256_of_bytes(data: bytes) -> str:
    """Return the SHA-256 hex digest of the given buffer."""
    return hashlib.sha256(data).hexdigest()


def _strip_jira_prefix(filename: str) -> str:
    """Remove the ``Jira_attachment_`` prefix so dedupe keys match across sides."""
    if filename.startswith(JIRA_ATTACHMENT_PREFIX):
        return filename[len(JIRA_ATTACHMENT_PREFIX) :]
    return filename


def _build_jira_attachment_index(attachments: Iterable[Mapping[str, Any]]) -> Dict[str, Mapping[str, Any]]:
    """Index Jira attachment metadata by ``(stripped_filename, size)`` tuple.

    Size is stringified so that the same key is produced when either side's
    size is missing.
    """
    index: Dict[str, Mapping[str, Any]] = {}
    for item in attachments:
        name = _strip_jira_prefix(str(item.get("filename") or ""))
        size = str(item.get("size") or "0")
        index[f"{name}|{size}"] = item
    return index


def _build_regscale_file_index(files: Iterable[Any]) -> Dict[str, Any]:
    """Index RegScale File objects by ``(stripped_filename, size)``.

    Uses the File's ``trustedDisplayName`` (primary) with a fallback to
    ``fileName`` if set. ``shaHash`` is included when available as a secondary
    dedupe axis via a second index entry.
    """
    index: Dict[str, Any] = {}
    for f in files:
        name = _strip_jira_prefix(str(getattr(f, "trustedDisplayName", "") or getattr(f, "fileName", "") or ""))
        size = str(getattr(f, "size", 0) or 0)
        index[f"{name}|{size}"] = f
        sha = getattr(f, "shaHash", None)
        if sha:
            index[f"sha:{sha}"] = f
    return index


def _pull_attachment_to_regscale(
    client: JiraDcClient,
    issue: Issue,
    api: Api,
    attachment: Mapping[str, Any],
    regscale_index: Mapping[str, Any],
    result: JiraDcSyncResult,
) -> None:
    """Download a single Jira attachment and upload into RegScale if new."""
    name = _strip_jira_prefix(str(attachment.get("filename") or ""))
    size = str(attachment.get("size") or "0")
    key = f"{name}|{size}"
    if key in regscale_index:
        return
    content_url = attachment.get("content")
    if not content_url:
        return
    try:
        data = client.stream_download_to_bytes(str(content_url))
    except JiraDcError as exc:
        result.add_error(f"Jira→RegScale attachment failed for {issue.jiraId} '{name}': {exc}")
        return
    sha = _sha256_of_bytes(data)
    if f"sha:{sha}" in regscale_index:
        return
    upload_name = f"{JIRA_ATTACHMENT_PREFIX}{name}" if not name.startswith(JIRA_ATTACHMENT_PREFIX) else name
    ok = File.upload_file_to_regscale(
        file_name=upload_name,
        parent_id=issue.id or 0,
        parent_module="issues",
        api=api,
        file_data=data,
    )
    if ok:
        result.updated += 1
    else:
        result.add_error(f"RegScale rejected upload of '{name}' for issue {issue.id}")


def _push_attachment_to_jira(
    client: JiraDcClient,
    issue: Issue,
    api: Api,
    regscale_file: Any,
    jira_index: Mapping[str, Mapping[str, Any]],
    result: JiraDcSyncResult,
) -> None:
    """Upload a single RegScale file to Jira if not already present."""
    name = _strip_jira_prefix(
        str(getattr(regscale_file, "trustedDisplayName", "") or getattr(regscale_file, "fileName", "") or ""),
    )
    size = str(getattr(regscale_file, "size", 0) or 0)
    if f"{name}|{size}" in jira_index:
        return
    stored_name = str(getattr(regscale_file, "trustedStorageName", "") or "")
    sha = str(getattr(regscale_file, "fileHash", "") or "")
    content = File.download_file_from_regscale_to_memory(
        api=api,
        record_id=issue.id or 0,
        module="issues",
        stored_name=stored_name,
        file_hash=sha,
    )
    if not content:
        result.add_error(f"RegScale→Jira download failed for issue {issue.id} file {name}")
        return
    try:
        client.upload_attachment_stream(
            key=str(issue.jiraId),
            filename=name,
            stream=io.BytesIO(content),
        )
    except JiraDcError as exc:
        result.add_error(f"RegScale→Jira upload failed for {issue.jiraId} '{name}': {exc}")
        return
    result.pushed += 1


def sync_attachments(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    direction: str = "both",
    verify_ssl: bool = True,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Bidirectional attachment transfer between Jira DC and RegScale.

    For each RegScale Issue under ``parent_id``/``parent_module`` that has a
    ``jiraId``:

    * ``to_regscale``: stream each Jira attachment, skip duplicates (by
      stripped filename + size, or matching SHA-256), and upload to RegScale
      via :meth:`File.upload_file_to_regscale`.
    * ``to_jira``: stream each RegScale ``File`` attached to the issue and
      upload it via :meth:`JiraDcClient.upload_attachment_stream`.

    ``jira_project`` is accepted for CLI parity with other ``jira_dc`` commands
    and is reserved for future per-project filtering; reconciliation is driven
    by the ``jiraId`` already linked on each RegScale Issue.
    """
    del jira_project  # reserved for future filtering — see docstring
    cfg: Mapping[str, Any] = config or {}
    if direction not in {"both", "to_regscale", "to_jira"}:
        raise JiraDcValidationError(f"direction must be one of both/to_regscale/to_jira; got {direction!r}")
    result = JiraDcSyncResult()
    api = Api()
    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        issues = Issue.get_all_by_parent(parent_id, parent_module)
        linked = [i for i in issues if getattr(i, "jiraId", None)]
        for issue in linked:
            _reconcile_one_issue_attachments(client, api, issue, direction, result)
    return result


def _reconcile_one_issue_attachments(
    client: JiraDcClient,
    api: Api,
    issue: Issue,
    direction: str,
    result: JiraDcSyncResult,
) -> None:
    """Reconcile attachments for a single linked issue."""
    if not issue.jiraId:
        return
    try:
        payload = client.get_issue(str(issue.jiraId), expand="attachment")
    except JiraDcError as exc:
        result.add_error(f"Failed to fetch Jira issue {issue.jiraId}: {exc}")
        return
    if not payload:
        return
    jira_attachments = (payload.get("fields") or {}).get("attachment") or []
    regscale_files = File.get_files_for_parent_from_regscale(
        parent_id=issue.id or 0,
        parent_module="issues",
        api=api,
    )
    jira_index = _build_jira_attachment_index(jira_attachments)
    regscale_index = _build_regscale_file_index(regscale_files)

    if direction in {"both", "to_regscale"}:
        for attachment in jira_attachments:
            _pull_attachment_to_regscale(client, issue, api, attachment, regscale_index, result)

    if direction in {"both", "to_jira"}:
        for regscale_file in regscale_files:
            _push_attachment_to_jira(client, issue, api, regscale_file, jira_index, result)


# ------------------------------------------------------------------ closures
def _is_regscale_closed(status: Optional[str]) -> bool:
    """Return True when a RegScale status maps to 'closed' for closure sync."""
    if not status:
        return False
    return str(status).strip().lower() in CLOSED_REGSCALE_STATUSES


def _transition_cache_key(project: str) -> str:
    """Build a cache key for the per-project transitions cache."""
    return f"jira_dc:transitions:{project}"


def _select_closed_transition(
    transitions: Iterable[Mapping[str, Any]],
    preferred_name: str,
    preferred_category: str,
) -> Optional[Mapping[str, Any]]:
    """Pick the best transition for closing an issue.

    First tries a case-insensitive match on the transition's ``name``. Falls
    back to any transition whose ``to.statusCategory.key`` matches the
    configured closed status category (default ``"done"``).
    """
    transitions = list(transitions)
    pref = preferred_name.strip().lower()
    for transition in transitions:
        if str(transition.get("name") or "").strip().lower() == pref:
            return transition
    cat = preferred_category.strip().lower()
    for transition in transitions:
        to = transition.get("to") or {}
        sc = (to.get("statusCategory") or {}) if isinstance(to, dict) else {}
        if isinstance(sc, dict) and str(sc.get("key") or "").strip().lower() == cat:
            return transition
    return None


def _already_closed(payload: Optional[Mapping[str, Any]], closed_category: str) -> bool:
    """Return True if a Jira issue is already in a closed ``statusCategory``."""
    if not payload:
        return False
    status = ((payload.get("fields") or {}).get("status") or {}) if isinstance(payload.get("fields"), dict) else {}
    sc = status.get("statusCategory") if isinstance(status, dict) else None
    if not isinstance(sc, dict):
        return False
    return str(sc.get("key") or "").strip().lower() == closed_category.strip().lower()


def _close_single_jira_issue(
    client: JiraDcClient,
    issue: Issue,
    transitions: List[Dict[str, Any]],
    preferred_name: str,
    preferred_category: str,
    result: JiraDcSyncResult,
) -> None:
    """Apply a closure transition to a single Jira issue."""
    jira_key = str(issue.jiraId)
    try:
        current = client.get_issue(jira_key)
    except JiraDcError as exc:
        result.add_error(f"Failed to fetch Jira issue {jira_key}: {exc}")
        return
    if current is None:
        logger.warning("Jira issue %s not found (404) during closure; skipping.", jira_key)
        result.add_error(f"Jira issue {jira_key} not found (404) during close")
        return
    if _already_closed(current, preferred_category):
        logger.debug("Jira issue %s is already closed; skipping", jira_key)
        return
    transition = _select_closed_transition(transitions, preferred_name, preferred_category)
    if not transition:
        result.add_error(
            f"No closure transition found for {jira_key} "
            f"(looked for name={preferred_name!r} or statusCategory={preferred_category!r})",
        )
        return
    try:
        client.apply_transition(jira_key, str(transition.get("id")))
    except JiraDcPermissionError as exc:
        logger.warning("Permission denied applying transition for %s: %s", jira_key, exc)
        result.add_error(f"Permission denied for closure of {jira_key}: {exc}")
        return
    except httpx.HTTPStatusError as exc:
        status_code = exc.response.status_code if exc.response is not None else None
        if status_code == 404:
            logger.warning("Jira issue %s not found when applying transition (404); skipping.", jira_key)
            result.add_error(f"Jira issue {jira_key} not found (404) during close")
            return
        result.add_error(f"Failed to apply transition for {jira_key}: {exc}")
        return
    except JiraDcError as exc:
        result.add_error(f"Failed to apply transition for {jira_key}: {exc}")
        return
    result.updated += 1


def sync_closures(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    verify_ssl: bool = True,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Close Jira DC issues whose linked RegScale Issue is now in a closed state.

    Reads :class:`Issue` records for the given parent, filters to those with a
    ``jiraId`` and a closed status, caches the Jira transition list per-project,
    and applies a closed-category transition.
    """
    cfg: Mapping[str, Any] = config or {}
    preferred_name = str(cfg.get("jiraDcClosedTransitionName") or "Done")
    preferred_category = str(cfg.get("jiraDcClosedStatusCategory") or "done")
    result = JiraDcSyncResult()
    transitions_cache: Dict[str, List[Dict[str, Any]]] = {}

    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        issues = Issue.get_all_by_parent(parent_id, parent_module)
        candidates = [
            i for i in issues if getattr(i, "jiraId", None) and _is_regscale_closed(getattr(i, "status", None))
        ]
        if not candidates:
            return result
        for issue in candidates:
            cache_key = _transition_cache_key(jira_project)
            transitions = transitions_cache.get(cache_key)
            if transitions is None:
                try:
                    transitions = client.list_transitions(str(issue.jiraId))
                except httpx.HTTPStatusError as exc:
                    status_code = exc.response.status_code if exc.response is not None else None
                    if status_code == 404:
                        logger.warning(
                            "Jira issue %s not found (404) when listing transitions; skipping closure.",
                            issue.jiraId,
                        )
                        result.add_error(f"Jira issue {issue.jiraId} not found (404)")
                        continue
                    result.add_error(f"Failed to list transitions for {issue.jiraId}: {exc}")
                    continue
                except JiraDcError as exc:
                    result.add_error(f"Failed to list transitions for {issue.jiraId}: {exc}")
                    continue
                transitions_cache[cache_key] = transitions
            _close_single_jira_issue(
                client,
                issue,
                transitions,
                preferred_name,
                preferred_category,
                result,
            )
    return result


# ------------------------------------------------------------------ push filters
def _normalise_csv(value: Optional[str]) -> List[str]:
    """Split a comma-separated CLI value into a list of lowercased tokens."""
    if not value:
        return []
    return [token.strip().lower() for token in value.split(",") if token.strip()]


def _parse_int_csv(value: Optional[str]) -> List[int]:
    """Parse a comma-separated list of integer IDs, raising on invalid input."""
    if not value:
        return []
    ids: List[int] = []
    for token in value.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            ids.append(int(token))
        except ValueError as exc:
            raise JiraDcValidationError(f"Invalid issue id in push_filter_ids: {token!r}") from exc
    return ids


def _validate_severity_tokens(tokens: Iterable[str]) -> List[str]:
    """Validate and canonicalise severity filter tokens."""
    canonical: List[str] = []
    for token in tokens:
        if token not in VALID_SEVERITIES:
            raise JiraDcValidationError(
                f"Invalid severity {token!r}; expected one of Critical/High/Medium/Low",
            )
        # Normalise "moderate" → "medium" for a consistent comparison key.
        canonical.append("medium" if token == "moderate" else token)
    return canonical


def _severity_matches(issue: Issue, severities: List[str]) -> bool:
    """Compare an issue's severity to a canonical severity filter list."""
    if not severities:
        return True
    level = str(getattr(issue, "severityLevel", "") or "").lower()
    # IssueSeverity enum values may be FedRAMP-style strings; normalise.
    for token in severities:
        if token in level:
            return True
    return False


def _source_matches(issue: Issue, sources: List[str]) -> bool:
    """Check whether an issue's source fields match any of the requested sources.

    Uses ``sourceReport`` (primary), ``integrationFindingId`` prefix, and
    ``securityChecks`` as fallbacks. None of the RegScale Issue model's fields
    directly correspond to "scanner name", so matching is substring-based.
    """
    if not sources:
        return True
    haystacks: List[str] = []
    for attr in ("sourceReport", "integrationFindingId", "securityChecks", "description"):
        value = getattr(issue, attr, None)
        if value:
            haystacks.append(str(value).lower())
    if not haystacks:
        return False
    return any(source in hay for source in sources for hay in haystacks)


def build_push_filter(
    *,
    label: Optional[str] = None,
    statuses: Optional[List[str]] = None,
    severities: Optional[List[str]] = None,
    ids: Optional[List[int]] = None,
    sources: Optional[List[str]] = None,
) -> Callable[[Issue], bool]:
    """Return a predicate that AND-composes all non-empty filter clauses."""
    status_set = {s.strip().lower() for s in statuses} if statuses else set()
    source_list = sources or []
    severity_list = severities or []
    id_set = set(ids or [])
    lbl = (label or "").strip().lower()

    def predicate(issue: Issue) -> bool:
        if id_set and getattr(issue, "id", None) not in id_set:
            return False
        if status_set and str(getattr(issue, "status", "") or "").strip().lower() not in status_set:
            return False
        if not _severity_matches(issue, severity_list):
            return False
        if not _source_matches(issue, source_list):
            return False
        if lbl:
            labels_field = str(getattr(issue, "description", "") or "") + " " + str(getattr(issue, "title", "") or "")
            if lbl not in labels_field.lower():
                return False
        return True

    return predicate


# ------------------------------------------------------------------ comments
def _extract_comment_text(raw: Any) -> Optional[str]:
    """Pull body text out of a RegScale Comment object or dict."""
    if raw is None:
        return None
    if isinstance(raw, str):
        return raw
    for attr in ("comment", "body", "text"):
        if isinstance(raw, Mapping) and raw.get(attr):
            return str(raw[attr])
        if hasattr(raw, attr):
            value = getattr(raw, attr)
            if value:
                return str(value)
    return None


def _utcnow() -> datetime:
    """Return an aware UTC datetime (wrapped for monkeypatching in tests)."""
    return datetime.now(tz=timezone.utc)


def _pull_comments_for_issue(
    client: JiraDcClient,
    issue: Issue,
    existing_bodies: Set[str],
    to_create: List[Comment],
    result: JiraDcSyncResult,
) -> None:
    """Fetch Jira comments for an issue and stage new ones for RegScale."""
    try:
        comments = client.list_comments(str(issue.jiraId))
    except httpx.HTTPStatusError as exc:
        status_code = exc.response.status_code if exc.response is not None else None
        if status_code == 404:
            logger.warning("Jira issue %s not found (404) when listing comments; skipping.", issue.jiraId)
            return
        result.add_error(f"Failed to fetch Jira comments for {issue.jiraId}: {exc}")
        return
    except JiraDcError as exc:
        result.add_error(f"Failed to fetch Jira comments for {issue.jiraId}: {exc}")
        return
    for jira_comment in comments:
        body = str(jira_comment.get("body") or "").strip()
        if not body:
            continue
        key = f"{issue.id}:{body}"
        if key in existing_bodies:
            continue
        existing_bodies.add(key)
        to_create.append(
            Comment(
                comment=f"[jira] {body}",
                parentID=issue.id or 0,
                parentModule="issues",
                commentDate=str(jira_comment.get("updated") or jira_comment.get("created") or ""),
            ),
        )
        logger.debug("Staged Jira comment for RegScale issue %s", issue.id)


def _push_comments_for_issue(
    client: JiraDcClient,
    issue: Issue,
    regscale_comments: Iterable[Any],
    since: Optional[datetime],
    result: JiraDcSyncResult,
) -> None:
    """Push RegScale comments newer than ``since`` to Jira."""
    for comment in regscale_comments:
        body = _extract_comment_text(comment)
        if not body:
            continue
        if body.startswith("[jira] "):
            # Avoid echoing back an imported Jira comment.
            continue
        if since is not None:
            date_str = (
                getattr(comment, "dateLastUpdated", None)
                or getattr(comment, "dateCreated", None)
                or getattr(comment, "commentDate", None)
            )
            if date_str:
                try:
                    parsed = datetime.fromisoformat(str(date_str).replace("Z", "+00:00"))
                    if parsed.tzinfo is None:
                        parsed = parsed.replace(tzinfo=timezone.utc)
                    if parsed < since:
                        continue
                except ValueError:
                    pass
        try:
            client.add_comment(str(issue.jiraId), body)
        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code if exc.response is not None else None
            if status_code == 404:
                logger.warning("Jira issue %s not found (404) when pushing comment; skipping.", issue.jiraId)
                continue
            result.add_error(f"Failed to push comment to {issue.jiraId}: {exc}")
            continue
        except JiraDcError as exc:
            result.add_error(f"Failed to push comment to {issue.jiraId}: {exc}")
            continue
        result.pushed += 1


def sync_comments(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    direction: str = "both",
    since: Optional[str] = None,
    verify_ssl: bool = True,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Sync comments between Jira DC issues and RegScale Issue comments.

    Dedupe strategy: the Jira → RegScale path concatenates the RegScale issue
    id and comment body to form a deterministic key; comments already present
    in RegScale (recognised by matching body text) are skipped. The RegScale →
    Jira path applies an ISO-8601 ``since`` watermark from
    ``dateLastUpdated`` (falling back to ``dateCreated`` / ``commentDate``)
    and also suppresses any comment whose body begins with ``[jira] ``
    (imported earlier).

    ``jira_project`` is accepted for CLI parity with other ``jira_dc`` commands
    and is reserved for future per-project filtering; reconciliation is driven
    by the ``jiraId`` already linked on each RegScale Issue.
    """
    del jira_project  # reserved for future filtering — see docstring
    cfg: Mapping[str, Any] = config or {}
    if direction not in {"both", "to_regscale", "to_jira"}:
        raise JiraDcValidationError(f"direction must be one of both/to_regscale/to_jira; got {direction!r}")
    watermark: Optional[datetime] = None
    if since:
        try:
            parsed = datetime.fromisoformat(since.replace("Z", "+00:00"))
            watermark = parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError as exc:
            raise JiraDcValidationError(f"Invalid ISO-8601 datetime for since: {since!r}") from exc

    result = JiraDcSyncResult()
    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        issues = Issue.get_all_by_parent(parent_id, parent_module)
        linked = [i for i in issues if getattr(i, "jiraId", None)]
        to_create: List[Comment] = []
        existing_bodies: Set[str] = set()
        for issue in linked:
            existing_comments = Comment.get_all_by_parent(issue.id or 0, "issues")
            for existing in existing_comments:
                body = _extract_comment_text(existing) or ""
                # Index by both the raw body and the `[jira] `-stripped form so
                # incoming Jira comments (which don't carry the prefix) still
                # match comments we previously imported and wrapped.
                existing_bodies.add(f"{issue.id}:{body}")
                existing_bodies.add(f"{issue.id}:{body.removeprefix('[jira] ')}")

            if direction in {"both", "to_regscale"}:
                _pull_comments_for_issue(client, issue, existing_bodies, to_create, result)
            if direction in {"both", "to_jira"}:
                _push_comments_for_issue(client, issue, existing_comments, watermark, result)

        if to_create:
            Comment.batch_create(to_create)
            result.created = len(to_create)
    return result


# ------------------------------------------------------------------ tickets from findings
def create_tickets_from_findings(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    jira_issue_type: str = "Task",
    sources: Optional[List[str]] = None,
    severity_gte: Optional[str] = None,
    verify_ssl: bool = True,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Push open scanner findings (RegScale Issues) into Jira as new tickets.

    Only issues whose ``status`` is ``Open``, ``severityLevel`` is at or above
    ``severity_gte``, and whose source fields match one of ``sources`` are
    pushed. Issues that already have a ``jiraId`` are skipped for idempotency.
    """
    cfg: Mapping[str, Any] = config or {}
    severities: List[str] = []
    if severity_gte:
        severities = _severity_gte_tokens(severity_gte)
    result = JiraDcSyncResult()
    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        _validate_issue_type(client, jira_project, jira_issue_type)
        issues = Issue.get_all_by_parent(parent_id, parent_module)
        predicate = build_push_filter(
            statuses=["open"],
            severities=severities,
            sources=sources,
        )
        matching = [i for i in issues if not getattr(i, "jiraId", None) and predicate(i)]
        if not matching:
            return result
        result.pushed = _push_regscale_to_jira(
            client=client,
            issues=matching,
            project_key=jira_project,
            issue_type=jira_issue_type,
            result=result,
        )
    return result


_SEVERITY_ORDER: Dict[str, int] = {"low": 0, "medium": 1, "moderate": 1, "high": 2, "critical": 3}


def _severity_gte_tokens(threshold: str) -> List[str]:
    """Return the canonical severities at or above ``threshold``."""
    token = threshold.strip().lower()
    if token not in _SEVERITY_ORDER:
        raise JiraDcValidationError(
            f"Invalid severity_gte {threshold!r}; expected one of Critical/High/Medium/Low",
        )
    min_rank = _SEVERITY_ORDER[token]
    keep = [name for name, rank in _SEVERITY_ORDER.items() if rank >= min_rank and name != "moderate"]
    return _validate_severity_tokens(keep)


# ------------------------------------------------------------------ recurring tasks
_CADENCE_LABEL_FORMATS: Dict[str, str] = {
    "daily": "%Y-%m-%d",
    "weekly": "%G-W%V",
    "monthly": "%Y-%m",
}


def _recurring_label(task_id: int, cadence: str, now: Optional[datetime] = None) -> str:
    """Build the dedupe label attached to mirrored recurring Jira tickets."""
    fmt = _CADENCE_LABEL_FORMATS.get(cadence.strip().lower())
    if not fmt:
        raise JiraDcValidationError(
            f"Invalid cadence {cadence!r}; expected one of daily/weekly/monthly",
        )
    stamp = (now or _utcnow()).strftime(fmt)
    return f"regscale-recurring:{task_id}:{stamp}"


def _find_existing_recurring_ticket(
    client: JiraDcClient,
    jira_project: str,
    label: str,
) -> Optional[str]:
    """Return the Jira key of an existing ticket carrying this recurrence label."""
    jql = f'project = "{jira_project}" AND labels = "{label}"'
    for match in client.search(jql, ["key"], hard_cap=1):
        key = match.get("key")
        if key:
            return str(key)
    return None


def create_recurring_task(
    parent_id: int,
    parent_module: str,
    jira_project: str,
    jira_issue_type: str = "Task",
    task_template: Optional[str] = None,
    cadence: str = "weekly",
    dry_run: bool = False,
    verify_ssl: bool = True,
    config: Optional[Mapping[str, Any]] = None,
) -> JiraDcSyncResult:
    """Mirror a recurring RegScale Task into Jira DC with an idempotency label.

    ``task_template`` is matched case-insensitively against each Task's title;
    if omitted, every task under ``parent_id`` is considered. A label of the
    form ``regscale-recurring:<task_id>:<yyyy-mm>`` (or week/day depending on
    cadence) is attached to the created Jira ticket so that a second run
    within the same period is a no-op.
    """
    cfg: Mapping[str, Any] = config or {}
    result = JiraDcSyncResult()
    template_lower = (task_template or "").strip().lower()
    with _build_client(cfg, verify_ssl) as client:
        client.server_info()
        _validate_issue_type(client, jira_project, jira_issue_type)
        tasks = Task.get_all_by_parent(parent_id, parent_module)
        for task in tasks:
            if template_lower and template_lower not in str(getattr(task, "title", "") or "").lower():
                continue
            label = _recurring_label(getattr(task, "id", 0) or 0, cadence)
            existing_key = _find_existing_recurring_ticket(client, jira_project, label)
            if existing_key:
                logger.debug("Recurring task %s already mirrored as %s", task.id, existing_key)
                continue
            if dry_run:
                logger.info("[dry-run] Would create Jira %s for task %s with label %s", jira_issue_type, task.id, label)
                result.created += 1
                continue
            payload = _build_recurring_task_payload(task, jira_project, jira_issue_type, label)
            try:
                client.create_issue(payload)
                result.created += 1
            except JiraDcError as exc:
                result.add_error(f"Failed to create recurring Jira task for {task.id}: {exc}")
    return result


def _build_recurring_task_payload(
    task: Task,
    project_key: str,
    issue_type: str,
    label: str,
) -> Dict[str, Any]:
    """Build the Jira create payload for a recurring task mirror."""
    return {
        "fields": {
            "project": {"key": project_key},
            "issuetype": {"name": issue_type},
            "summary": str(getattr(task, "title", "") or "RegScale recurring task"),
            "description": str(getattr(task, "description", "") or ""),
            "labels": [label],
        },
    }
