#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Click command group for the Jira Data Center integration.

Each command here is a thin parameter-binding layer: it parses user input and
delegates to :mod:`sync` or :mod:`importers`. Keeping the CLI free of business
logic makes it easy to reuse the sync functions from Airflow DAGs and tests.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

import click

from regscale.core.app.application import Application
from regscale.integrations.commercial.jira_dc import sync as jira_dc_sync
from regscale.integrations.commercial.jira_dc.auth import resolve_auth
from regscale.integrations.commercial.jira_dc.client import JiraDcClient
from regscale.integrations.commercial.jira_dc.importers import csv_importer, xml_importer
from regscale.models.app_models.click import regscale_id, regscale_module

logger = logging.getLogger("regscale")


@click.group(name="jira_dc")
def jira_dc() -> None:
    """Sync issues, tasks, and attachments between Jira Data Center and RegScale."""


def _load_config() -> dict:
    """Return the Application config as a dict."""
    return dict(Application().config)


# ------------------------------------------------------------------ sync_issues
@jira_dc.command(name="sync_issues")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True, help="Jira project key.")
@click.option("--jira_issue_type", type=click.STRING, required=True, help="Jira issue type (case sensitive).")
@click.option("--sync_attachments", type=click.BOOL, default=True, show_default=True)
@click.option("--jql", type=click.STRING, required=False, help="Custom JQL query override.")
@click.option("--poams", is_flag=True, help="Create or update incoming issues as POAMs.")
@click.option("--dry_run", is_flag=True, help="Return counts as JSON without writing to RegScale.")
@click.option("--offset", type=click.INT, required=False, help="Client-side skip.")
@click.option("--limit", type=click.INT, required=False, help="Client-side cap on imported items.")
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True, help="TLS verification toggle.")
def sync_issues(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    jira_issue_type: str,
    sync_attachments: bool,
    jql: Optional[str],
    poams: bool,
    dry_run: bool,
    offset: Optional[int],
    limit: Optional[int],
    verify_ssl: bool,
) -> None:
    """Bidirectional sync of issues between Jira DC and RegScale."""
    jira_dc_sync.sync_issues(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        jira_issue_type=jira_issue_type,
        sync_attachments=sync_attachments,
        jql=jql,
        use_poams=poams,
        dry_run=dry_run,
        offset=offset,
        limit=limit,
        verify_ssl=verify_ssl,
        config=_load_config(),
    )


# ------------------------------------------------------------------ sync_tasks
@jira_dc.command(name="sync_tasks")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True, help="Jira project key.")
@click.option("--sync_attachments", type=click.BOOL, default=True, show_default=True)
@click.option("--jql", type=click.STRING, required=False, help="Custom JQL query override.")
@click.option("--dry_run", is_flag=True, help="Return counts as JSON without writing to RegScale.")
@click.option("--offset", type=click.INT, required=False)
@click.option("--limit", type=click.INT, required=False)
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
def sync_tasks(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    sync_attachments: bool,
    jql: Optional[str],
    dry_run: bool,
    offset: Optional[int],
    limit: Optional[int],
    verify_ssl: bool,
) -> None:
    """Sync Jira DC Task-type issues into RegScale Tasks."""
    jira_dc_sync.sync_tasks(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        sync_attachments=sync_attachments,
        jql=jql,
        dry_run=dry_run,
        offset=offset,
        limit=limit,
        verify_ssl=verify_ssl,
        config=_load_config(),
    )


# ------------------------------------------------------------------ sync_attachments
@jira_dc.command(name="sync_attachments")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True)
@click.option(
    "--direction",
    type=click.Choice(["both", "to_regscale", "to_jira"], case_sensitive=False),
    default="both",
    show_default=True,
)
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
def sync_attachments(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    direction: str,
    verify_ssl: bool,
) -> None:
    """Attachment-only reconciliation between Jira DC and RegScale."""
    jira_dc_sync.sync_attachments(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        direction=direction,
        verify_ssl=verify_ssl,
        config=_load_config(),
    )


# ------------------------------------------------------------------ push_issues
@jira_dc.command(name="push_issues")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True)
@click.option("--jira_issue_type", type=click.STRING, required=True)
@click.option("--dry_run", is_flag=True)
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
@click.option("--update_existing", is_flag=True, help="Also update Jira tickets linked to RegScale issues.")
@click.option("--push_filter_label", type=click.STRING, required=False, help="Filter RegScale issues by label text.")
@click.option(
    "--push_filter_status",
    type=click.STRING,
    required=False,
    help="Comma-separated RegScale statuses to include (default: Open).",
)
@click.option(
    "--push_filter_severity",
    type=click.STRING,
    required=False,
    help="Comma-separated severities (Critical/High/Medium/Low).",
)
@click.option(
    "--push_filter_ids",
    type=click.STRING,
    required=False,
    help="Comma-separated RegScale Issue IDs to push.",
)
@click.option(
    "--push_filter_source",
    type=click.STRING,
    required=False,
    help="Comma-separated source/scanner tokens to match against the Issue source fields.",
)
def push_issues(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    jira_issue_type: str,
    dry_run: bool,
    verify_ssl: bool,
    update_existing: bool,
    push_filter_label: Optional[str],
    push_filter_status: Optional[str],
    push_filter_severity: Optional[str],
    push_filter_ids: Optional[str],
    push_filter_source: Optional[str],
) -> None:
    """Push orphan RegScale issues (no jiraId) into Jira DC, optionally updating linked tickets."""
    jira_dc_sync.push_issues(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        jira_issue_type=jira_issue_type,
        dry_run=dry_run,
        verify_ssl=verify_ssl,
        update_existing=update_existing,
        push_filter_label=push_filter_label,
        push_filter_status=push_filter_status,
        push_filter_severity=push_filter_severity,
        push_filter_ids=push_filter_ids,
        push_filter_source=push_filter_source,
        config=_load_config(),
    )


# ------------------------------------------------------------------ sync_closures
@jira_dc.command(name="sync_closures")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True)
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
def sync_closures(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    verify_ssl: bool,
) -> None:
    """Close Jira DC tickets whose RegScale Issue is Closed/Remediated/Resolved/Cancelled."""
    jira_dc_sync.sync_closures(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        verify_ssl=verify_ssl,
        config=_load_config(),
    )


# ------------------------------------------------------------------ sync_comments
@jira_dc.command(name="sync_comments")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True)
@click.option(
    "--direction",
    type=click.Choice(["both", "to_regscale", "to_jira"], case_sensitive=False),
    default="both",
    show_default=True,
)
@click.option("--since", type=click.STRING, required=False, help="ISO-8601 watermark for RegScale→Jira comments.")
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
def sync_comments(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    direction: str,
    since: Optional[str],
    verify_ssl: bool,
) -> None:
    """Sync comments/worklogs between Jira DC and RegScale Issues."""
    jira_dc_sync.sync_comments(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        direction=direction,
        since=since,
        verify_ssl=verify_ssl,
        config=_load_config(),
    )


# ------------------------------------------------------------------ create_tickets_from_findings
@jira_dc.command(name="create_tickets_from_findings")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True)
@click.option("--jira_issue_type", type=click.STRING, default="Task", show_default=True)
@click.option(
    "--source",
    "sources",
    type=click.STRING,
    required=False,
    help="Comma-separated scanner/source tokens (e.g. AWS,Qualys,Tenable,Wiz).",
)
@click.option(
    "--severity_gte",
    type=click.STRING,
    required=False,
    help="Minimum severity threshold (Low/Medium/High/Critical).",
)
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
def create_tickets_from_findings(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    jira_issue_type: str,
    sources: Optional[str],
    severity_gte: Optional[str],
    verify_ssl: bool,
) -> None:
    """Create Jira tickets from open scanner findings in RegScale."""
    source_list = [s.strip() for s in (sources or "").split(",") if s.strip()] or None
    jira_dc_sync.create_tickets_from_findings(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        jira_issue_type=jira_issue_type,
        sources=source_list,
        severity_gte=severity_gte,
        verify_ssl=verify_ssl,
        config=_load_config(),
    )


# ------------------------------------------------------------------ create_recurring_task
@jira_dc.command(name="create_recurring_task")
@regscale_id()
@regscale_module()
@click.option("--jira_project", type=click.STRING, required=True)
@click.option("--jira_issue_type", type=click.STRING, default="Task", show_default=True)
@click.option("--task_template", type=click.STRING, required=False, help="Title substring to match.")
@click.option(
    "--cadence",
    type=click.Choice(["daily", "weekly", "monthly"], case_sensitive=False),
    default="weekly",
    show_default=True,
)
@click.option("--dry_run", is_flag=True)
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
def create_recurring_task(
    regscale_id: int,
    regscale_module: str,
    jira_project: str,
    jira_issue_type: str,
    task_template: Optional[str],
    cadence: str,
    dry_run: bool,
    verify_ssl: bool,
) -> None:
    """Mirror recurring RegScale Tasks into Jira DC with idempotency labels."""
    jira_dc_sync.create_recurring_task(
        parent_id=regscale_id,
        parent_module=regscale_module,
        jira_project=jira_project,
        jira_issue_type=jira_issue_type,
        task_template=task_template,
        cadence=cadence,
        dry_run=dry_run,
        verify_ssl=verify_ssl,
        config=_load_config(),
    )


# ------------------------------------------------------------------ import_xml
@jira_dc.command(name="import_xml")
@click.option("--file_path", type=click.Path(exists=True, dir_okay=False), required=True)
@regscale_id()
@regscale_module()
@click.option("--poams", is_flag=True)
@click.option("--chunk_size", type=click.INT, default=100, show_default=True)
def import_xml(
    file_path: str,
    regscale_id: int,
    regscale_module: str,
    poams: bool,
    chunk_size: int,
) -> None:
    """Import a Jira DC XML export into RegScale."""
    total = xml_importer.import_xml(
        file_path=file_path,
        parent_id=regscale_id,
        parent_module=regscale_module,
        is_poam=poams,
        chunk_size=chunk_size,
        config=_load_config(),
    )
    click.echo(f"Imported {total} issues from {file_path}")


# ------------------------------------------------------------------ import_csv
@jira_dc.command(name="import_csv")
@click.option("--folder_path", type=click.Path(exists=True, file_okay=False), required=True)
@regscale_id()
@regscale_module()
@click.option("--mappings_path", type=click.Path(), required=False)
@click.option("--disable_mapping", is_flag=True)
@click.option("--chunk_size", type=click.INT, default=100, show_default=True)
def import_csv(
    folder_path: str,
    regscale_id: int,
    regscale_module: str,
    mappings_path: Optional[str],
    disable_mapping: bool,
    chunk_size: int,
) -> None:
    """Import Jira DC CSV export files from a folder into RegScale."""
    total = csv_importer.import_csv(
        folder_path=folder_path,
        parent_id=regscale_id,
        parent_module=regscale_module,
        mappings_path=mappings_path,
        disable_mapping=disable_mapping,
        chunk_size=chunk_size,
        config=_load_config(),
    )
    click.echo(f"Imported {total} issues from {folder_path}")


# ------------------------------------------------------------------ test_connection
@jira_dc.command(name="test_connection")
@click.option("--verify_ssl/--no-verify_ssl", default=True, show_default=True)
def test_connection(verify_ssl: bool) -> None:
    """Verify connectivity and credentials to Jira Data Center."""
    config = _load_config()
    base_url = str(config.get("jiraDcUrl") or "").strip()
    if not base_url:
        raise click.UsageError("jiraDcUrl is not configured in init.yaml.")
    auth = resolve_auth(config)
    client = JiraDcClient(
        base_url=base_url,
        auth=auth,
        verify_ssl=verify_ssl,
        timeout=int(config.get("jiraDcTimeoutSeconds") or 60),
    )
    try:
        info = client.server_info()
    finally:
        client.close()
    summary = {
        "title": info.get("serverTitle"),
        "version": info.get("version"),
        "deploymentType": info.get("deploymentType"),
        "auth_mode": auth.mode,
    }
    click.echo(json.dumps(summary, indent=2))
