#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Jira Data Center (on-prem) integration for RegScale CLI.

This package provides a standalone integration for Jira Data Center and Jira
Server deployments. It is intentionally isolated from the Jira Cloud integration
(``regscale.integrations.commercial.jira``) because the two products have
different REST endpoints, authentication models, pagination, and rich-text
conventions.

All HTTP communication is performed via ``httpx`` with a single long-lived
``httpx.Client`` per ``JiraDcClient`` instance. External writes to the RegScale
platform go through Pydantic models (``Issue.batch_create`` / ``Task.bulk_save``)
rather than direct REST calls.
"""

from regscale.integrations.commercial.jira_dc.cli import jira_dc

__all__ = ["jira_dc"]
