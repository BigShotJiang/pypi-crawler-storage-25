#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Streaming importer for Jira Data Center XML exports.

Jira DC's Issue Navigator "Export → XML" emits an RSS-like document where
each issue is a ``<item>`` element. This importer uses :func:`lxml.etree.iterparse`
so that large exports (tens of thousands of issues) can be processed without
reading the entire file into memory. After yielding each item we call
``elem.clear()`` and drop processed siblings to release memory aggressively.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Iterator, List, Mapping, Optional

from lxml import etree  # type: ignore[import-not-found]

from regscale.integrations.commercial.jira_dc.mappers import map_jira_to_regscale_issue
from regscale.models.regscale_models.issue import Issue

logger = logging.getLogger("regscale")


def _text_of(elem: Any, tag: str) -> Optional[str]:
    """Return the text content of ``elem/tag`` or None."""
    child = elem.find(tag)
    if child is None:
        return None
    return (child.text or "").strip() or None


def _name_attr(elem: Any, tag: str) -> Optional[str]:
    """Return the ``name`` attribute of ``elem/tag`` if present."""
    child = elem.find(tag)
    if child is None:
        return None
    return child.get("name") or (child.text or "").strip() or None


def _extract_labels(elem: Any) -> List[str]:
    """Return a list of label values under the ``<labels>`` wrapper."""
    labels_elem = elem.find("labels")
    if labels_elem is None:
        return []
    return [(label.text or "").strip() for label in labels_elem.findall("label") if label is not None]


def _extract_attachments(elem: Any) -> List[Dict[str, Any]]:
    """Return attachment metadata dicts from the ``<attachments>`` wrapper."""
    wrapper = elem.find("attachments")
    if wrapper is None:
        return []
    attachments: List[Dict[str, Any]] = []
    for att in wrapper.findall("attachment"):
        attachments.append(
            {
                "id": att.get("id"),
                "filename": att.get("name"),
                "size": int(att.get("size") or 0),
                "author": att.get("author"),
                "created": att.get("created"),
            },
        )
    return attachments


def _extract_custom_fields(elem: Any) -> Dict[str, Any]:
    """Flatten ``<customfields>`` into a ``{customfield_id: value}`` dict."""
    wrapper = elem.find("customfields")
    if wrapper is None:
        return {}
    out: Dict[str, Any] = {}
    for field_elem in wrapper.findall("customfield"):
        field_id = field_elem.get("id")
        if not field_id:
            continue
        values_elem = field_elem.find("customfieldvalues")
        if values_elem is None:
            continue
        values = [(v.text or "").strip() for v in values_elem.findall("customfieldvalue") if v is not None]
        out[field_id] = values[0] if len(values) == 1 else values
    return out


def _item_to_dict(elem: Any) -> Dict[str, Any]:
    """Convert a single ``<item>`` element into an API-shaped issue dict."""
    key = _text_of(elem, "key")
    labels = _extract_labels(elem)
    attachments = _extract_attachments(elem)
    custom_fields = _extract_custom_fields(elem)

    fields: Dict[str, Any] = {
        "summary": _text_of(elem, "summary") or _text_of(elem, "title"),
        "description": _text_of(elem, "description"),
        "duedate": _text_of(elem, "due"),
        "created": _text_of(elem, "created"),
        "updated": _text_of(elem, "updated"),
        "resolutiondate": _text_of(elem, "resolved"),
        "labels": labels,
        "attachment": attachments,
    }
    priority_name = _name_attr(elem, "priority")
    if priority_name:
        fields["priority"] = {"name": priority_name}
    status_name = _name_attr(elem, "status")
    if status_name:
        fields["status"] = {"name": status_name}
    issuetype_name = _name_attr(elem, "type")
    if issuetype_name:
        fields["issuetype"] = {"name": issuetype_name}
    reporter_child = elem.find("reporter")
    if reporter_child is not None:
        fields["reporter"] = {
            "name": reporter_child.get("username"),
            "displayName": (reporter_child.text or "").strip() or None,
        }
    assignee_child = elem.find("assignee")
    if assignee_child is not None:
        fields["assignee"] = {
            "name": assignee_child.get("username"),
            "displayName": (assignee_child.text or "").strip() or None,
        }
    fields.update(custom_fields)

    return {"key": key, "fields": fields}


def iter_jira_items(file_path: str) -> Iterator[Dict[str, Any]]:
    """Yield issue dicts from a Jira DC XML export file.

    :param str file_path: Path to the XML file on disk.
    :return: Iterator of API-shaped issue dicts.
    :rtype: Iterator[Dict[str, Any]]
    """
    context = etree.iterparse(file_path, events=("end",), tag="item")
    for _event, elem in context:
        yield _item_to_dict(elem)
        elem.clear()
        parent = elem.getparent()
        while parent is not None and elem.getprevious() is not None:
            del parent[0]
    del context


def import_xml(
    file_path: str,
    parent_id: int,
    parent_module: str,
    is_poam: bool = False,
    chunk_size: int = 100,
    config: Optional[Mapping[str, Any]] = None,
) -> int:
    """Stream a Jira DC XML export into RegScale Issues.

    :param str file_path: Path to the Jira XML export on disk.
    :param int parent_id: RegScale parent record ID.
    :param str parent_module: RegScale parent module slug.
    :param bool is_poam: Whether to mark imported issues as POAMs.
    :param int chunk_size: ``batch_create`` chunk size.
    :param Optional[Mapping[str, Any]] config: Application config mapping.
    :return: Number of issues imported.
    :rtype: int
    """
    if not Path(file_path).exists():
        raise FileNotFoundError(file_path)
    cfg: Mapping[str, Any] = config or {}
    buffer: List[Issue] = []
    total = 0
    for item in iter_jira_items(file_path):
        buffer.append(
            map_jira_to_regscale_issue(item, cfg, parent_id, parent_module, is_poam=is_poam),
        )
        if len(buffer) >= chunk_size:
            Issue.batch_create(buffer)
            total += len(buffer)
            buffer.clear()
    if buffer:
        Issue.batch_create(buffer)
        total += len(buffer)
    logger.info("Imported %s issues from Jira DC XML export %s", total, file_path)
    return total
