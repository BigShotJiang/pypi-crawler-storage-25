#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Streaming CSV importer for Jira Data Center exports.

Uses :class:`csv.DictReader` so rows are yielded one at a time and the file is
never read in full into memory. The mapping between CSV columns and Jira API
fields is configurable via :data:`DEFAULT_COLUMN_MAP`; callers may override
or extend it to match their tenant's export configuration.
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Any, Dict, Iterator, List, Mapping, Optional

from regscale.integrations.commercial.jira_dc.mappers import map_jira_to_regscale_issue
from regscale.models.regscale_models.issue import Issue

logger = logging.getLogger("regscale")


# Default column-name mapping for Jira DC "Export as CSV (current fields)".
DEFAULT_COLUMN_MAP: Dict[str, str] = {
    "Issue key": "key",
    "Key": "key",
    "Summary": "summary",
    "Description": "description",
    "Status": "status",
    "Priority": "priority",
    "Due Date": "duedate",
    "Created": "created",
    "Updated": "updated",
    "Resolved": "resolutiondate",
    "Issue Type": "issuetype",
    "Reporter": "reporter",
    "Assignee": "assignee",
    "Labels": "labels",
}


def _normalise_row(row: Mapping[str, Any], column_map: Mapping[str, str]) -> Dict[str, Any]:
    """Translate a CSV row into an API-shaped issue dict."""
    fields: Dict[str, Any] = {}
    key: Optional[str] = None
    for column, api_name in column_map.items():
        if column not in row:
            continue
        value = row.get(column)
        if value is None or value == "":
            continue
        if api_name == "key":
            key = str(value)
            continue
        if api_name in {"priority", "status", "issuetype"}:
            fields[api_name] = {"name": str(value)}
        elif api_name in {"reporter", "assignee"}:
            fields[api_name] = {"displayName": str(value)}
        elif api_name == "labels":
            fields[api_name] = [label.strip() for label in str(value).split(",") if label.strip()]
        else:
            fields[api_name] = str(value)
    return {"key": key, "fields": fields}


def iter_csv_rows(file_path: str) -> Iterator[Dict[str, Any]]:
    """Stream rows from a Jira DC CSV export as raw dicts."""
    with open(file_path, newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            yield row


def iter_jira_csv_items(
    file_path: str,
    column_map: Optional[Mapping[str, str]] = None,
) -> Iterator[Dict[str, Any]]:
    """Stream Jira-shaped issue dicts from a Jira DC CSV export."""
    mapping = column_map or DEFAULT_COLUMN_MAP
    for row in iter_csv_rows(file_path):
        yield _normalise_row(row, mapping)


def _collect_csv_files(folder_path: str) -> List[Path]:
    """Return sorted list of CSV files under ``folder_path`` (non-recursive)."""
    folder = Path(folder_path)
    if not folder.exists() or not folder.is_dir():
        raise FileNotFoundError(f"CSV folder not found: {folder_path}")
    return sorted(p for p in folder.iterdir() if p.is_file() and p.suffix.lower() == ".csv")


def import_csv(
    folder_path: str,
    parent_id: int,
    parent_module: str,
    mappings_path: Optional[str] = None,
    disable_mapping: bool = False,
    chunk_size: int = 100,
    config: Optional[Mapping[str, Any]] = None,
) -> int:
    """Stream one or more Jira DC CSV exports into RegScale Issues.

    :param str folder_path: Folder containing one or more CSV files.
    :param int parent_id: RegScale parent record ID.
    :param str parent_module: RegScale parent module slug.
    :param Optional[str] mappings_path: Path to a custom column map JSON file.
    :param bool disable_mapping: Reserved for FlatFileImporter parity; no-op here.
    :param int chunk_size: ``batch_create`` chunk size.
    :param Optional[Mapping[str, Any]] config: Application config mapping.
    :return: Total number of issues imported across all CSV files.
    :rtype: int
    """
    column_map = _load_column_map(mappings_path, disable_mapping)
    cfg: Mapping[str, Any] = config or {}
    total = 0
    for csv_file in _collect_csv_files(folder_path):
        buffer: List[Issue] = []
        for item in iter_jira_csv_items(str(csv_file), column_map):
            buffer.append(map_jira_to_regscale_issue(item, cfg, parent_id, parent_module))
            if len(buffer) >= chunk_size:
                Issue.batch_create(buffer)
                total += len(buffer)
                buffer.clear()
        if buffer:
            Issue.batch_create(buffer)
            total += len(buffer)
    logger.info("Imported %s issues from Jira DC CSV folder %s", total, folder_path)
    return total


def _load_column_map(mappings_path: Optional[str], disable_mapping: bool) -> Dict[str, str]:
    """Resolve a column map from the optional override file."""
    if disable_mapping or not mappings_path:
        return dict(DEFAULT_COLUMN_MAP)
    path = Path(mappings_path)
    if not path.exists():
        logger.warning("Mappings file %s not found — using default column map", mappings_path)
        return dict(DEFAULT_COLUMN_MAP)
    import json

    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Mappings file {mappings_path} must contain a JSON object")
    return {str(k): str(v) for k, v in data.items()}
