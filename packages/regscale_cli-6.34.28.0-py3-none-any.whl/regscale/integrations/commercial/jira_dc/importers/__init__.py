#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline import paths for Jira Data Center exports (XML, CSV)."""
