#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""startAt/maxResults pagination helpers for Jira Data Center.

Jira DC does not support the ``nextPageToken`` pattern used by Jira Cloud v3
— every search must page with ``startAt`` and ``maxResults``. The helper here
yields issues lazily so downstream code can stream-map them into RegScale
objects without ever materialising the full result set.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Iterator, Optional

FetchPage = Callable[[int, int], Dict[str, Any]]


def _issues_from(page: Dict[str, Any]) -> list:
    """Extract the ``issues`` list from a search response, tolerating None."""
    return page.get("issues") or []


def paginate_search(
    fetch_page: FetchPage,
    page_size: int = 50,
    hard_cap: Optional[int] = None,
) -> Iterator[Dict[str, Any]]:
    """Yield each Jira issue dict lazily across pages.

    :param FetchPage fetch_page: Callable that takes (start_at, max_results)
        and returns the raw search response dict.
    :param int page_size: Page size to request.
    :param Optional[int] hard_cap: Optional client-side cap on total yields.
    :return: Iterator over individual issue dicts.
    :rtype: Iterator[Dict[str, Any]]
    """
    start_at = 0
    yielded = 0
    while True:
        page = fetch_page(start_at, page_size)
        issues = _issues_from(page)
        if not issues:
            return
        for issue in issues:
            yield issue
            yielded += 1
            if hard_cap is not None and yielded >= hard_cap:
                return
        total = page.get("total")
        start_at += len(issues)
        # Stop when we've drained the reported total OR when the page was
        # short (last page on servers that omit or miscount ``total``).
        if total is not None and start_at >= total:
            return
        if len(issues) < page_size:
            return
