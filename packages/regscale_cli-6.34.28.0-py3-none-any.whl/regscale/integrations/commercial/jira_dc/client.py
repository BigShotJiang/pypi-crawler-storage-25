#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""httpx-native client for Jira Data Center.

Design goals:

* One long-lived :class:`httpx.Client` per :class:`JiraDcClient` instance —
  constructed in ``__init__`` and reused for every HTTP call.
* Every URL assembled with :func:`urllib.parse.urljoin` + :func:`urllib.parse.quote`;
  no f-string URL concatenation.
* Stream attachments rather than materialising them in memory.
* Respect ``Retry-After`` on 429s and fall back to exponential backoff with
  jitter. Never log credentials.

The client is safe to share across worker threads because ``httpx.Client`` is
documented as thread-safe for concurrent requests.
"""

from __future__ import annotations

import logging
import random
import time
from pathlib import Path
from typing import Any, BinaryIO, Dict, Iterator, List, Optional
from urllib.parse import quote, urljoin

import httpx

from regscale.integrations.commercial.jira_dc.auth import (
    AuthStrategy,
    build_auth_headers_and_client_auth,
)
from regscale.integrations.commercial.jira_dc.constants import (
    ATTACHMENT_CHUNK_SIZE,
    ISSUE_ATTACHMENTS_SUFFIX,
    ISSUE_COMMENT_SUFFIX,
    ISSUE_TRANSITIONS_SUFFIX,
    MAX_BACKOFF_SECONDS,
    MAX_RETRIES_5XX,
    MAX_RETRIES_429,
    MAX_RETRIES_NETWORK,
    REST_CREATE_META,
    REST_ISSUE,
    REST_SEARCH,
    REST_SERVER_INFO,
    XSRF_HEADER,
)
from regscale.integrations.commercial.jira_dc.exceptions import (
    JiraDcAuthError,
    JiraDcError,
    JiraDcPermissionError,
    JiraDcRateLimitError,
)
from regscale.integrations.commercial.jira_dc.pagination import paginate_search

logger = logging.getLogger("regscale")


class JiraDcClient:
    """Thin, retrying httpx client for Jira Data Center REST v2."""

    def __init__(
        self,
        base_url: str,
        auth: AuthStrategy,
        verify_ssl: bool = True,
        timeout: int = 60,
        page_size: int = 50,
    ) -> None:
        if not base_url:
            raise JiraDcError("Jira DC base URL is required.")
        # Ensure a trailing slash so urljoin treats it as a directory.
        self.base_url = base_url.rstrip("/") + "/"
        self.page_size = page_size
        headers, basic_auth = build_auth_headers_and_client_auth(auth)
        headers.setdefault("Accept", "application/json")
        headers.setdefault("Content-Type", "application/json")
        self.auth_mode = auth.mode
        self._client = httpx.Client(
            auth=basic_auth,
            verify=verify_ssl,
            timeout=httpx.Timeout(timeout, read=max(120.0, float(timeout) * 2)),
            headers=headers,
            follow_redirects=False,
        )

    def _rewrite_host_if_needed(self, url: str) -> str:
        """Rewrite absolute attachment URLs onto the configured base host.

        Jira often returns attachment ``content`` and ``self`` URLs pointing to
        the instance's externally-visible hostname, which may not resolve from
        the CLI's network (e.g. when talking to an internal proxy or a mock
        deployment). We swap the scheme/host/port with our ``base_url`` when the
        path structure still matches Jira (``/secure/attachment/...`` or
        ``/rest/api/...``), leaving relative URLs untouched.
        """
        if not url or "://" not in url:
            return url
        from urllib.parse import urlsplit, urlunsplit

        try:
            base = urlsplit(self.base_url)
            target = urlsplit(url)
        except ValueError:
            return url
        if not target.netloc or target.netloc == base.netloc:
            return url
        return urlunsplit((base.scheme, base.netloc, target.path, target.query, target.fragment))

    # ------------------------------------------------------------------ core
    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "JiraDcClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    # ------------------------------------------------------------------ retry
    def _handle_error_response(self, response: httpx.Response, url: str) -> None:
        """Translate auth/permission failures into package-specific errors."""
        status = response.status_code
        if status == 401:
            raise JiraDcAuthError(f"Jira DC auth failed for {url}")
        if status == 403:
            raise JiraDcPermissionError(f"Jira DC permission denied for {url}")

    def _backoff_sleep(self, attempt: int, response: Optional[httpx.Response]) -> float:
        """Compute and perform a backoff sleep, returning the duration used."""
        retry_after: Optional[float] = None
        if response is not None:
            header_value = response.headers.get("Retry-After")
            if header_value:
                try:
                    retry_after = float(header_value)
                except ValueError:
                    retry_after = None
        if retry_after is None:
            # Exponential backoff with jitter.
            retry_after = min(
                MAX_BACKOFF_SECONDS,
                (2 ** (attempt - 1)) + random.uniform(0.0, 0.5),
            )
        time.sleep(retry_after)
        return retry_after

    def _request_with_retry(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Execute an HTTP request with retry on 429/5xx/transport errors."""
        attempt = 0
        network_errors = 0
        while True:
            attempt += 1
            try:
                response = self._client.request(method, url, **kwargs)
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.RemoteProtocolError) as exc:
                network_errors += 1
                if network_errors >= MAX_RETRIES_NETWORK:
                    raise JiraDcError(f"Network error contacting {url}: {exc}") from exc
                self._backoff_sleep(network_errors, None)
                continue

            if response.status_code < 400:
                return response

            self._handle_error_response(response, url)

            if response.status_code == 429:
                if attempt >= MAX_RETRIES_429:
                    raise JiraDcRateLimitError(f"Exceeded 429 retry budget for {url}")
                logger.warning("Jira DC rate-limited on %s (attempt %s)", url, attempt)
                self._backoff_sleep(attempt, response)
                continue

            if 500 <= response.status_code < 600:
                if attempt >= MAX_RETRIES_5XX:
                    response.raise_for_status()
                logger.warning(
                    "Jira DC %s returned %s (attempt %s) — retrying",
                    url,
                    response.status_code,
                    attempt,
                )
                self._backoff_sleep(attempt, response)
                continue

            # 4xx that isn't auth/permission/rate — fail fast.
            response.raise_for_status()

    # ------------------------------------------------------------------ api
    def server_info(self) -> Dict[str, Any]:
        """Return the ``/serverInfo`` payload."""
        url = urljoin(self.base_url, REST_SERVER_INFO)
        return self._request_with_retry("GET", url).json()

    def get_issue(self, key: str, expand: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Fetch a single issue by key, returning ``None`` on 404."""
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded)
        params = {"expand": expand} if expand else None
        try:
            response = self._request_with_retry("GET", url, params=params)
        except httpx.HTTPStatusError as exc:
            if exc.response is not None and exc.response.status_code == 404:
                return None
            raise
        return response.json()

    def search(self, jql: str, fields: List[str], hard_cap: Optional[int] = None) -> Iterator[Dict[str, Any]]:
        """Iterate matching issues for a JQL query using startAt pagination."""
        url = urljoin(self.base_url, REST_SEARCH)

        def fetch(start_at: int, max_results: int) -> Dict[str, Any]:
            payload = {
                "jql": jql,
                "startAt": start_at,
                "maxResults": max_results,
                "fields": fields,
            }
            return self._request_with_retry("POST", url, json=payload).json()

        yield from paginate_search(fetch, page_size=self.page_size, hard_cap=hard_cap)

    def create_meta(self, project_key: str) -> Dict[str, Any]:
        """Return project metadata used to validate issue types before create.

        Falls back to ``/rest/api/2/issuetype`` + ``/rest/api/2/project/{key}``
        when ``createmeta`` returns 404. Some Jira DC deployments (and test
        doubles) do not expose ``createmeta`` but still expose the underlying
        issue-type and project endpoints, so we can reconstruct an equivalent
        response shape rather than hard-failing validation.
        """
        url = urljoin(self.base_url, REST_CREATE_META)
        params = {"projectKeys": project_key, "expand": "projects.issuetypes"}
        try:
            return self._request_with_retry("GET", url, params=params).json()
        except httpx.HTTPStatusError as exc:
            if exc.response is None or exc.response.status_code != 404:
                raise
            logger.debug("createmeta returned 404; falling back to project + issuetype endpoints")
            return self._create_meta_fallback(project_key)

    def _create_meta_fallback(self, project_key: str) -> Dict[str, Any]:
        """Reconstruct a createmeta-shaped response from project + issuetype endpoints."""
        encoded_key = quote(project_key, safe="")
        project_url = urljoin(self.base_url, "rest/api/2/project/" + encoded_key)
        issue_types_url = urljoin(self.base_url, "rest/api/2/issuetype")
        try:
            project_payload = self._request_with_retry("GET", project_url).json()
        except httpx.HTTPStatusError as exc:
            if exc.response is not None and exc.response.status_code == 404:
                return {"projects": []}
            raise
        issue_types = self._request_with_retry("GET", issue_types_url).json() or []
        return {
            "projects": [
                {
                    "key": project_payload.get("key", project_key),
                    "name": project_payload.get("name"),
                    "id": project_payload.get("id"),
                    "issuetypes": issue_types,
                }
            ]
        }

    def create_issue(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Create an issue from the given fields payload."""
        url = urljoin(self.base_url, "rest/api/2/issue")
        response = self._request_with_retry("POST", url, json=payload, headers=XSRF_HEADER)
        return response.json()

    def update_issue(self, key: str, payload: Dict[str, Any]) -> None:
        """Update an existing issue by key."""
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded)
        self._request_with_retry("PUT", url, json=payload, headers=XSRF_HEADER)

    def add_attachment(self, key: str, file_path: Path) -> List[Dict[str, Any]]:
        """Upload a file as an attachment to an existing issue.

        The file handle is streamed directly into httpx — the file is never
        read into memory as a whole.
        """
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded + "/attachments")
        headers = dict(XSRF_HEADER)
        # httpx will set its own multipart Content-Type header with boundary.
        headers.pop("Content-Type", None)
        with open(file_path, "rb") as handle:
            files = {"file": (file_path.name, handle)}
            response = self._client.post(url, files=files, headers=headers)
            if response.status_code >= 400:
                self._handle_error_response(response, url)
                response.raise_for_status()
        return response.json()

    def download_attachment(self, url: str, dest: Path) -> Path:
        """Stream an attachment to disk in fixed-size chunks."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        url = self._rewrite_host_if_needed(url)
        with self._client.stream("GET", url) as response:
            if response.status_code >= 400:
                self._handle_error_response(response, url)
                response.raise_for_status()
            with open(dest, "wb") as handle:
                for chunk in response.iter_bytes(chunk_size=ATTACHMENT_CHUNK_SIZE):
                    handle.write(chunk)
        return dest

    # ------------------------------------------------------------------ transitions
    def list_transitions(self, key: str) -> List[Dict[str, Any]]:
        """Return the available workflow transitions for an issue."""
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded + ISSUE_TRANSITIONS_SUFFIX)
        response = self._request_with_retry("GET", url)
        data = response.json() or {}
        transitions = data.get("transitions") or []
        return list(transitions)

    def apply_transition(self, key: str, transition_id: str, comment: Optional[str] = None) -> None:
        """Apply a workflow transition to an issue, optionally adding a comment."""
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded + ISSUE_TRANSITIONS_SUFFIX)
        payload: Dict[str, Any] = {"transition": {"id": str(transition_id)}}
        if comment:
            payload["update"] = {"comment": [{"add": {"body": comment}}]}
        self._request_with_retry("POST", url, json=payload, headers=XSRF_HEADER)

    # ------------------------------------------------------------------ comments
    def list_comments(self, key: str) -> List[Dict[str, Any]]:
        """Return the list of comments on a Jira issue."""
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded + ISSUE_COMMENT_SUFFIX)
        response = self._request_with_retry("GET", url)
        data = response.json() or {}
        return list(data.get("comments") or [])

    def add_comment(self, key: str, body: str) -> Dict[str, Any]:
        """Post a new comment to a Jira issue."""
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded + ISSUE_COMMENT_SUFFIX)
        response = self._request_with_retry(
            "POST",
            url,
            json={"body": body},
            headers=XSRF_HEADER,
        )
        return response.json() or {}

    # ------------------------------------------------------------------ attachments (streaming)
    def upload_attachment_stream(
        self,
        key: str,
        filename: str,
        stream: BinaryIO,
        content_type: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Upload a file-like stream as an attachment to an existing issue.

        Unlike :meth:`add_attachment` this accepts any readable binary stream
        (e.g. a :class:`BytesIO` fed from a Jira download) without requiring
        the full content to be on disk.
        """
        encoded = quote(key, safe="")
        url = urljoin(self.base_url, REST_ISSUE + encoded + ISSUE_ATTACHMENTS_SUFFIX)
        headers = dict(XSRF_HEADER)
        headers.pop("Content-Type", None)
        files = {"file": (filename, stream, content_type or "application/octet-stream")}
        response = self._client.post(url, files=files, headers=headers)
        if response.status_code >= 400:
            self._handle_error_response(response, url)
            response.raise_for_status()
        return response.json()

    def stream_download_to_bytes(self, url: str) -> bytes:
        """Stream an attachment into memory, chunk-by-chunk.

        Used when the caller wants to compute a hash and then upload the same
        buffer without touching disk.
        """
        url = self._rewrite_host_if_needed(url)
        with self._client.stream("GET", url) as response:
            if response.status_code >= 400:
                self._handle_error_response(response, url)
                response.raise_for_status()
            buffer = bytearray()
            for chunk in response.iter_bytes(chunk_size=ATTACHMENT_CHUNK_SIZE):
                buffer.extend(chunk)
        return bytes(buffer)
