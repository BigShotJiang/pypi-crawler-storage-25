#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Constants for the Jira Data Center integration.

Centralising these values keeps ``client.py`` and ``sync.py`` free of magic
strings and simplifies testing (tests can import these paths and compare the
exact URL a mock transport receives).
"""

from __future__ import annotations

# REST API paths — always appended to the configured base URL via urljoin.
REST_SERVER_INFO: str = "rest/api/2/serverInfo"
REST_SEARCH: str = "rest/api/2/search"
REST_ISSUE: str = "rest/api/2/issue/"
REST_CREATE_META: str = "rest/api/2/issue/createmeta"
# Appended to REST_ISSUE + encoded key.
ISSUE_TRANSITIONS_SUFFIX: str = "/transitions"
ISSUE_COMMENT_SUFFIX: str = "/comment"
ISSUE_ATTACHMENTS_SUFFIX: str = "/attachments"

# RegScale issue statuses that should trigger a Jira closure transition.
CLOSED_REGSCALE_STATUSES: frozenset[str] = frozenset(
    {"closed", "remediated", "resolved", "cancelled", "canceled"},
)

# Default fields to request from the search endpoint. Keeping this narrow
# reduces response payload size on large projects.
SEARCH_FIELDS: list[str] = [
    "summary",
    "description",
    "status",
    "priority",
    "duedate",
    "created",
    "updated",
    "resolutiondate",
    "statuscategorychangedate",
    "labels",
    "issuetype",
    "reporter",
    "assignee",
    "attachment",
]

# Header required by Jira DC to bypass XSRF checks on write and upload endpoints.
XSRF_HEADER: dict[str, str] = {"X-Atlassian-Token": "no-check"}

# Identifier constants written into RegScale records so that downstream logic
# can tell Jira DC-sourced issues from Jira Cloud-sourced ones.
SOURCE_REPORT: str = "Jira DC"
IDENTIFICATION: str = "Jira Sync"

# Retry policy tunables. Kept module-level so tests can monkeypatch them.
MAX_RETRIES_429: int = 5
MAX_RETRIES_5XX: int = 3
MAX_RETRIES_NETWORK: int = 3
MAX_BACKOFF_SECONDS: float = 60.0

# Default attachment download chunk size (1 MB).
ATTACHMENT_CHUNK_SIZE: int = 1024 * 1024

# File prefix applied to attachments when copying between systems.
JIRA_ATTACHMENT_PREFIX: str = "Jira_attachment_"
