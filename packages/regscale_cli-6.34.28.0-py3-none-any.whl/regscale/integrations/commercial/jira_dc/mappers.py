#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Field mapping between Jira Data Center and RegScale.

This module is the single source of truth for how Jira DC fields become
RegScale Issue / Task attributes and vice versa. Keeping mappings in pure
functions (no IO, no Application / Api globals) makes them trivial to unit
test and to swap for customised behaviour.

Severity is mapped to the canonical :class:`IssueSeverity` enum members.
Outbound severity names follow the simple-values convention documented in the
project memory ("Critical / High / Medium / Low") — ``Moderate`` is reported
back to Jira as ``Medium``.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Literal, Mapping, Optional

from regscale.integrations.commercial.jira_dc.constants import IDENTIFICATION, SOURCE_REPORT
from regscale.models.regscale_models.issue import Issue, IssueSeverity, IssueStatus
from regscale.models.regscale_models.task import Task

logger = logging.getLogger("regscale")


# ------------------------------------------------------------------ severity
_JIRA_TO_SEVERITY: Dict[str, IssueSeverity] = {
    "blocker": IssueSeverity.Critical,
    "highest": IssueSeverity.Critical,
    "critical": IssueSeverity.Critical,
    "high": IssueSeverity.High,
    "major": IssueSeverity.High,
    "medium": IssueSeverity.Moderate,
    "moderate": IssueSeverity.Moderate,
    "normal": IssueSeverity.Moderate,
    "low": IssueSeverity.Low,
    "minor": IssueSeverity.Low,
    "lowest": IssueSeverity.Low,
    "trivial": IssueSeverity.Low,
}

_SEVERITY_TO_JIRA: Dict[IssueSeverity, str] = {
    IssueSeverity.Critical: "Critical",
    IssueSeverity.High: "High",
    IssueSeverity.Moderate: "Medium",
    IssueSeverity.Low: "Low",
    IssueSeverity.NotAssigned: "Medium",
}

# Jira status name → RegScale IssueStatus mapping. Values are compared in
# case-insensitive form so tenant-level rename of "Done" to "done" still works.
_JIRA_CLOSED_STATUSES: frozenset[str] = frozenset({"done", "closed", "resolved"})

# Priority → remediation SLA in days. Used when Jira issue has no duedate.
_DEFAULT_DUE_DAYS: Dict[IssueSeverity, int] = {
    IssueSeverity.Critical: 7,
    IssueSeverity.High: 30,
    IssueSeverity.Moderate: 90,
    IssueSeverity.Low: 180,
    IssueSeverity.NotAssigned: 90,
}

_WIKI_MARKUP_PATTERN = re.compile(r"[{\[][^}\]]{0,200}[}\]]")
_MAX_DESCRIPTION = 8000
_MAX_TITLE = 450


def map_severity_to_issue(jira_priority_name: Optional[str]) -> IssueSeverity:
    """Translate a Jira priority name to a :class:`IssueSeverity` enum member."""
    if not jira_priority_name:
        return IssueSeverity.NotAssigned
    return _JIRA_TO_SEVERITY.get(jira_priority_name.strip().lower(), IssueSeverity.NotAssigned)


def map_severity_to_jira_priority(severity: IssueSeverity) -> str:
    """Translate a RegScale :class:`IssueSeverity` to a Jira priority name."""
    return _SEVERITY_TO_JIRA.get(severity, "Medium")


def _strip_wiki_markup(text: Optional[str]) -> Optional[str]:
    """Best-effort convert Jira wiki markup to plain text."""
    if not text:
        return text
    cleaned = _WIKI_MARKUP_PATTERN.sub("", text)
    return cleaned[:_MAX_DESCRIPTION]


def _safe_datetime(value: Optional[str]) -> Optional[str]:
    """Parse a Jira ISO datetime and return a RegScale-compatible ISO string."""
    if not value:
        return None
    # Jira DC emits ISO 8601 with timezone offset (e.g. 2026-04-14T10:00:00.000-0400)
    # Normalise to UTC ISO 8601 with 'Z'.
    text = value.strip()
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
    ):
        try:
            parsed = datetime.strptime(text, fmt)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc).isoformat()
        except ValueError:
            continue
    # Date-only (duedate)
    try:
        parsed = datetime.strptime(text, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc).isoformat()
    except ValueError:
        logger.debug("Unparseable Jira datetime: %s", text)
        return None


def _calc_default_due_date(severity: IssueSeverity, reference: Optional[str]) -> str:
    """Compute a duedate based on SLA when Jira has not supplied one."""
    days = _DEFAULT_DUE_DAYS.get(severity, 90)
    base = _safe_datetime(reference) if reference else None
    anchor = datetime.now(tz=timezone.utc)
    if base:
        try:
            anchor = datetime.fromisoformat(base.replace("Z", "+00:00"))
        except ValueError:
            anchor = datetime.now(tz=timezone.utc)
    return (anchor + timedelta(days=days)).isoformat()


def map_jira_due_date(
    jira_duedate: Optional[str],
    severity: IssueSeverity,
    reference_created: Optional[str] = None,
) -> str:
    """Resolve the RegScale dueDate from Jira's duedate or an SLA fallback."""
    resolved = _safe_datetime(jira_duedate)
    if resolved:
        return resolved
    return _calc_default_due_date(severity, reference_created)


def _is_closed(status_name: Optional[str]) -> bool:
    """Return True when the Jira status maps to a closed RegScale state."""
    if not status_name:
        return False
    return status_name.strip().lower() in _JIRA_CLOSED_STATUSES


def map_jira_status_to_issue(status_name: Optional[str]) -> IssueStatus:
    """Map a Jira status name onto :class:`IssueStatus` for an Issue."""
    return IssueStatus.Closed if _is_closed(status_name) else IssueStatus.Open


# ------------------------------------------------------------------ custom fields
def apply_custom_fields(
    issue: Issue,
    fields: Mapping[str, Any],
    custom_field_map: Optional[Mapping[str, str]],
) -> None:
    """Populate RegScale Issue attributes from configured Jira custom fields.

    :param Issue issue: The target RegScale Issue instance.
    :param Mapping[str, Any] fields: The ``fields`` dict from a Jira API payload.
    :param Optional[Mapping[str, str]] custom_field_map: Mapping of Jira custom
        field IDs (e.g. ``customfield_10500``) to RegScale Issue attribute names.
    """
    if not custom_field_map:
        return
    for jira_field, regscale_attr in custom_field_map.items():
        if jira_field not in fields:
            continue
        raw = fields.get(jira_field)
        value = _coerce_custom_field_value(raw)
        if value is not None and hasattr(issue, regscale_attr):
            setattr(issue, regscale_attr, value)


def _coerce_custom_field_value(raw: Any) -> Optional[str]:
    """Reduce a Jira custom field payload to a string, or ``None``."""
    if raw is None:
        return None
    if isinstance(raw, (str, int, float, bool)):
        return str(raw)
    if isinstance(raw, dict):
        for key in ("value", "name", "displayName"):
            if raw.get(key):
                return str(raw[key])
        return None
    if isinstance(raw, list):
        joined = ",".join(str(item) for item in raw if item)
        return joined or None
    return None


# ------------------------------------------------------------------ Issue
def _extract_fields(issue_payload: Mapping[str, Any]) -> Dict[str, Any]:
    """Return the ``fields`` subsection of a Jira issue payload, if any."""
    fields = issue_payload.get("fields") or {}
    return fields if isinstance(fields, dict) else {}


def _extract_name(obj: Any) -> Optional[str]:
    """Return ``obj.name`` for Jira sub-dicts, or None."""
    if isinstance(obj, dict):
        return obj.get("name")
    return None


def map_jira_to_regscale_issue(
    jira_payload: Mapping[str, Any],
    config: Mapping[str, Any],
    parent_id: int,
    parent_module: str,
    is_poam: bool = False,
) -> Issue:
    """Map a Jira API issue payload onto a new :class:`Issue` instance."""
    fields = _extract_fields(jira_payload)
    key = jira_payload.get("key") or fields.get("key") or ""
    summary = (fields.get("summary") or "")[:_MAX_TITLE] or "[no title]"
    description = _strip_wiki_markup(fields.get("description")) or ""

    priority_name = _extract_name(fields.get("priority"))
    severity = map_severity_to_issue(priority_name)
    status = map_jira_status_to_issue(_extract_name(fields.get("status")))

    due_date = map_jira_due_date(fields.get("duedate"), severity, fields.get("created"))
    date_created = _safe_datetime(fields.get("created"))
    date_updated = _safe_datetime(fields.get("updated"))
    date_completed = None
    if status == IssueStatus.Closed:
        # RegScale requires dateCompleted when status is Closed/Resolved.
        # Prefer Jira's resolutiondate, but fall back to updated/created when the
        # field is absent (some Jira exports and test fixtures omit resolutiondate).
        date_completed = _safe_datetime(fields.get("resolutiondate")) or date_updated or date_created

    reporter_name = None
    reporter = fields.get("reporter")
    if isinstance(reporter, dict):
        reporter_name = reporter.get("displayName") or reporter.get("name")

    issue = Issue(
        title=summary,
        severityLevel=severity,
        dueDate=due_date,
        identification=IDENTIFICATION,
        sourceReport=SOURCE_REPORT,
        status=status.value,
        description=description,
        jiraId=key or None,
        otherIdentifier=key or None,
        issueOwner=reporter_name,
        parentId=parent_id,
        parentModule=parent_module,
        isPoam=is_poam,
        dateCreated=date_created or None,
        dateLastUpdated=date_updated or None,
        dateCompleted=date_completed,
    )
    apply_custom_fields(issue, fields, config.get("jiraDcCustomFields"))
    return issue


def apply_updates_in_place(
    existing: Issue,
    jira_payload: Mapping[str, Any],
    config: Mapping[str, Any],
) -> Issue:
    """Update an existing Issue in place from a Jira payload."""
    fields = _extract_fields(jira_payload)
    summary = (fields.get("summary") or existing.title or "")[:_MAX_TITLE]
    existing.title = summary or existing.title

    description = _strip_wiki_markup(fields.get("description"))
    if description is not None:
        existing.description = description

    priority_name = _extract_name(fields.get("priority"))
    existing.severityLevel = map_severity_to_issue(priority_name)

    new_status = map_jira_status_to_issue(_extract_name(fields.get("status")))
    existing.status = new_status.value

    existing.dueDate = map_jira_due_date(fields.get("duedate"), existing.severityLevel, fields.get("created"))
    updated = _safe_datetime(fields.get("updated"))
    if updated:
        existing.dateLastUpdated = updated
    if new_status == IssueStatus.Closed:
        resolved = _safe_datetime(fields.get("resolutiondate"))
        if resolved:
            existing.dateCompleted = resolved
        elif not getattr(existing, "dateCompleted", None):
            existing.dateCompleted = updated or _safe_datetime(fields.get("created"))

    apply_custom_fields(existing, fields, config.get("jiraDcCustomFields"))
    return existing


# ------------------------------------------------------------------ Task
_TaskStatus = Literal["Backlog", "Open", "Closed", "Cancelled"]
_TASK_STATUS_LOOKUP: Dict[str, _TaskStatus] = {
    "to do": "Backlog",
    "todo": "Backlog",
    "backlog": "Backlog",
    "open": "Open",
    "in progress": "Open",
    "in review": "Open",
    "reopened": "Open",
    "done": "Closed",
    "closed": "Closed",
    "resolved": "Closed",
    "cancelled": "Cancelled",
    "canceled": "Cancelled",
}


def convert_task_status(status_name: Optional[str]) -> _TaskStatus:
    """Resolve a RegScale Task status literal from a Jira status string."""
    if not status_name:
        return "Backlog"
    return _TASK_STATUS_LOOKUP.get(status_name.strip().lower(), "Backlog")


def map_jira_to_regscale_task(
    jira_payload: Mapping[str, Any],
    parent_id: int,
    parent_module: str,
) -> Task:
    """Map a Jira issue payload onto a new :class:`Task` instance."""
    fields = _extract_fields(jira_payload)
    key = jira_payload.get("key") or ""
    summary = (fields.get("summary") or "")[:_MAX_TITLE] or "[no title]"
    description = _strip_wiki_markup(fields.get("description")) or ""

    priority_name = _extract_name(fields.get("priority"))
    severity = map_severity_to_issue(priority_name)
    due_date = map_jira_due_date(fields.get("duedate"), severity, fields.get("created"))

    status_name = _extract_name(fields.get("status"))
    status = convert_task_status(status_name)
    date_closed: Optional[str] = None
    percent_complete: Optional[int] = None
    if status == "Closed":
        date_closed = _safe_datetime(fields.get("statuscategorychangedate")) or _safe_datetime(
            fields.get("resolutiondate"),
        )
        percent_complete = 100

    return Task(
        title=summary,
        description=description,
        dueDate=due_date,
        status=status,
        otherIdentifier=key or None,
        dateClosed=date_closed,
        percentComplete=percent_complete,
        parentId=parent_id,
        parentModule=parent_module,
    )


# ------------------------------------------------------------------ RegScale → Jira
def _build_jira_description(issue: Issue) -> str:
    """Return a wiki-markup description for a RegScale issue."""
    parts = [issue.description or ""]
    if issue.otherIdentifier:
        parts.append(f"\n\n*RegScale Identifier:* {issue.otherIdentifier}")
    return "".join(parts)[:_MAX_DESCRIPTION]


def _issue_severity_value(issue: Issue) -> IssueSeverity:
    """Return the enum form of ``issue.severityLevel``."""
    level = issue.severityLevel
    if isinstance(level, IssueSeverity):
        return level
    for member in IssueSeverity:
        if str(member.value) == str(level):
            return member
    return IssueSeverity.NotAssigned


def _iso_date(value: Optional[str]) -> Optional[str]:
    """Coerce a datetime string to ``YYYY-MM-DD`` for Jira duedate."""
    if not value:
        return None
    cleaned = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(cleaned).date().isoformat()
    except ValueError:
        # Might already be a date-only ISO string (YYYY-MM-DD); otherwise return None.
        candidate = value[:10]
        try:
            return datetime.strptime(candidate, "%Y-%m-%d").date().isoformat()
        except ValueError:
            return None


def map_regscale_to_jira_payload(
    issue: Issue,
    project_key: str,
    issue_type: str,
) -> Dict[str, Any]:
    """Build a Jira create/update payload for a RegScale Issue."""
    severity = _issue_severity_value(issue)
    payload: Dict[str, Any] = {
        "fields": {
            "project": {"key": project_key},
            "issuetype": {"name": issue_type},
            "summary": (issue.title or "[no title]")[:_MAX_TITLE],
            "description": _build_jira_description(issue),
            "priority": {"name": map_severity_to_jira_priority(severity)},
        },
    }
    duedate = _iso_date(issue.dueDate)
    if duedate:
        payload["fields"]["duedate"] = duedate
    return payload


def map_regscale_to_jira_update_payload(
    issue: Issue,
    existing_jira_fields: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a PUT body for Jira issue update, sending only changed fields.

    :param Issue issue: Source RegScale Issue.
    :param Optional[Mapping[str, Any]] existing_jira_fields: The current
        Jira ``fields`` dict for the linked issue. Used to suppress no-op
        writes.
    :return: A dict ready to pass as ``json=`` on a PUT to ``rest/api/2/issue``.
    """
    severity = _issue_severity_value(issue)
    desired = {
        "summary": (issue.title or "[no title]")[:_MAX_TITLE],
        "description": _build_jira_description(issue),
        "priority": {"name": map_severity_to_jira_priority(severity)},
    }
    duedate = _iso_date(issue.dueDate)
    if duedate:
        desired["duedate"] = duedate

    fields: Dict[str, Any] = {}
    existing = existing_jira_fields or {}
    for key, value in desired.items():
        current = existing.get(key)
        if key == "priority":
            current_name = _extract_name(current) if isinstance(current, dict) else None
            if current_name != value["name"]:
                fields[key] = value
            continue
        if current != value:
            fields[key] = value
    return {"fields": fields}
