#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Exception hierarchy for the Jira Data Center integration.

All errors raised by this package inherit from :class:`JiraDcError` so that
callers can catch every integration-specific failure with a single except
clause while still being able to discriminate auth, permission, rate-limit, and
generic transport errors.
"""

from __future__ import annotations


class JiraDcError(Exception):
    """Base class for all Jira DC integration errors."""


class JiraDcAuthError(JiraDcError):
    """Raised when authentication to Jira DC fails (HTTP 401 or missing creds)."""


class JiraDcPermissionError(JiraDcError):
    """Raised when the authenticated user lacks permission (HTTP 403)."""


class JiraDcRateLimitError(JiraDcError):
    """Raised when Jira DC returns HTTP 429 beyond the retry budget."""


class JiraDcConfigurationError(JiraDcError):
    """Raised when the integration is misconfigured (missing URL, invalid type)."""


class JiraDcValidationError(JiraDcError):
    """Raised when input payloads or export files fail schema validation."""
