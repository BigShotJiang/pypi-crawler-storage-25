#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Authentication strategy resolution for the Jira Data Center integration.

Precedence (highest wins):

1. Environment variables (``JIRA_DC_PAT``, ``JIRA_DC_USERNAME`` +
   ``JIRA_DC_PASSWORD``).
2. ``init.yaml`` PAT (``jiraDcPat``).
3. ``init.yaml`` basic auth (``jiraDcUsername`` + ``jiraDcPassword``).

``resolve_auth`` never returns ``None`` — if no valid credential is found, it
raises :class:`JiraDcAuthError` with an actionable message. Token values are
never logged; callers log the *mode* only (``"pat"`` vs ``"basic"``).
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Mapping, Optional, Tuple

import httpx

from regscale.integrations.commercial.jira_dc.exceptions import JiraDcAuthError

logger = logging.getLogger("regscale")


@dataclass(slots=True)
class AuthStrategy:
    """Resolved authentication strategy.

    Exactly one of ``bearer`` and ``basic`` is populated; the other is ``None``.
    """

    mode: str
    bearer: Optional[str]
    basic: Optional[Tuple[str, str]]


def _env_pat() -> Optional[str]:
    """Return the PAT from ``JIRA_DC_PAT`` env var, or ``None``."""
    value = os.getenv("JIRA_DC_PAT")
    return value.strip() if value and value.strip() else None


def _env_basic() -> Optional[Tuple[str, str]]:
    """Return the basic-auth tuple from env vars, or ``None``."""
    user = os.getenv("JIRA_DC_USERNAME")
    password = os.getenv("JIRA_DC_PASSWORD")
    if user and password:
        return user, password
    return None


def _config_pat(config: Mapping[str, object]) -> Optional[str]:
    """Extract a non-empty PAT from the provided config mapping."""
    raw = config.get("jiraDcPat") or ""
    value = str(raw).strip()
    return value or None


def _config_basic(config: Mapping[str, object]) -> Optional[Tuple[str, str]]:
    """Extract a basic-auth tuple from the provided config mapping."""
    user = str(config.get("jiraDcUsername") or "").strip()
    password = str(config.get("jiraDcPassword") or "")
    if user and password:
        return user, password
    return None


def resolve_auth(config: Mapping[str, object]) -> AuthStrategy:
    """Resolve credentials from env vars then config.

    :param Mapping[str, object] config: The application configuration mapping.
    :raises JiraDcAuthError: If no credentials are resolvable.
    :return: The selected authentication strategy.
    :rtype: AuthStrategy
    """
    env_pat = _env_pat()
    if env_pat:
        logger.debug("Using Jira DC PAT from environment")
        return AuthStrategy(mode="pat", bearer=env_pat, basic=None)

    env_basic = _env_basic()
    if env_basic:
        logger.debug("Using Jira DC basic auth from environment")
        return AuthStrategy(mode="basic", bearer=None, basic=env_basic)

    cfg_pat = _config_pat(config)
    if cfg_pat:
        logger.debug("Using Jira DC PAT from init.yaml")
        return AuthStrategy(mode="pat", bearer=cfg_pat, basic=None)

    cfg_basic = _config_basic(config)
    if cfg_basic:
        logger.debug("Using Jira DC basic auth from init.yaml")
        return AuthStrategy(mode="basic", bearer=None, basic=cfg_basic)

    raise JiraDcAuthError(
        "No Jira DC credentials found. Set JIRA_DC_PAT (recommended) or "
        "JIRA_DC_USERNAME + JIRA_DC_PASSWORD environment variables, or populate "
        "jiraDcPat (or jiraDcUsername + jiraDcPassword) in init.yaml.",
    )


def build_auth_headers_and_client_auth(
    strategy: AuthStrategy,
) -> Tuple[dict, Optional[httpx.BasicAuth]]:
    """Translate an :class:`AuthStrategy` into httpx-client init kwargs.

    :param AuthStrategy strategy: Resolved credential strategy.
    :return: Tuple of (headers dict, optional httpx.BasicAuth).
    :rtype: Tuple[dict, Optional[httpx.BasicAuth]]
    """
    if strategy.mode == "pat" and strategy.bearer:
        return ({"Authorization": f"Bearer {strategy.bearer}"}, None)
    if strategy.mode == "basic" and strategy.basic:
        return ({}, httpx.BasicAuth(*strategy.basic))
    # Defensive: dataclass construction elsewhere should have prevented this.
    raise JiraDcAuthError("Invalid AuthStrategy: mode/credentials mismatch")
