#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Jira Data Center integration configuration variables.

These attributes are resolved through the standard RegScale variable pipeline
(``RsVariablesMeta``) — environment variables first, then ``init.yaml``. Keep
any new configuration knobs here so that documentation and generated config
samples stay in sync.

Note: ``from __future__ import annotations`` is *not* used in this module
because ``RsVariablesMeta`` inspects the live ``__annotations__`` dict at class
creation time; stringified annotations would prevent the metaclass from
installing the per-attribute descriptors.
"""

from regscale.core.app.utils.variables import RsVariablesMeta, RsVariableType


class JiraDcVariables(metaclass=RsVariablesMeta):
    """Jira Data Center (on-prem) integration configuration."""

    # Connection
    jiraDcUrl: RsVariableType(str, "https://jira.example.com", required=False, default="")  # type: ignore
    jiraDcVerifySsl: RsVariableType(bool, True, required=False, default=True)  # type: ignore

    # Authentication — prefer PAT (Bearer). Provide username+password only for
    # instances that do not allow PAT issuance.
    jiraDcPat: RsVariableType(str, "", sensitive=True, required=False, default="")  # type: ignore
    jiraDcUsername: RsVariableType(str, "", required=False, default="")  # type: ignore
    jiraDcPassword: RsVariableType(str, "", sensitive=True, required=False, default="")  # type: ignore

    # Defaults
    jiraDcDefaultIssueType: RsVariableType(str, "Task", required=False, default="Task")  # type: ignore
    jiraDcDefaultPriority: RsVariableType(str, "Medium", required=False, default="Medium")  # type: ignore
    jiraDcPageSize: RsVariableType(int, 50, required=False, default=50)  # type: ignore
    jiraDcTimeoutSeconds: RsVariableType(int, 60, required=False, default=60)  # type: ignore

    # Custom field mapping — keys are Jira custom field IDs (e.g.
    # ``customfield_10500``), values are RegScale Issue attribute names.
    jiraDcCustomFields: RsVariableType(dict, {}, required=False, default={})  # type: ignore

    # Closure sync — name of the Jira transition applied when a RegScale issue
    # reaches a closed status, and the Jira ``statusCategory.key`` used when
    # the preferred transition name is not available on the project workflow.
    jiraDcClosedTransitionName: RsVariableType(str, "Done", required=False, default="Done")  # type: ignore
    jiraDcClosedStatusCategory: RsVariableType(str, "done", required=False, default="done")  # type: ignore
