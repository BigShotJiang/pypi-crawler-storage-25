#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RegScale STIG Integration

Parses DISA STIG .ckl files and syncs findings to RegScale.
Uses the base ScannerIntegration CHECKLIST pattern to create checklists,
assessments (Assessment + ControlTest + ControlTestResult), and vulnerabilities.
"""

import datetime
import logging
from pathlib import Path
from typing import Generator, Iterator, Optional

from regscale.core.app.utils.app_utils import error_and_exit
from regscale.core.utils.date import date_str
from regscale.integrations.commercial.stigv2.ckl_parser import (
    CKLFile,
    Vuln,
    find_stig_files,
    parse_ckl_file,
)
from regscale.integrations.scanner.utils.field_utils import issue_due_date
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
)
from regscale.models import regscale_models

logger = logging.getLogger("regscale")


class StigIntegration(ScannerIntegration):
    """STIG Integration — syncs DISA STIG .ckl findings as assessments in RegScale."""

    options_map_assets_to_components = False
    import_all_findings = True
    suppress_asset_not_found_errors = True

    title = "STIG Integration"
    asset_identifier_field = "fqdn"
    type = ScannerIntegrationType.CHECKLIST

    checklist_status_map = {
        "NotAFinding": regscale_models.ChecklistStatus.PASS,
        "Open": regscale_models.ChecklistStatus.FAIL,
    }
    finding_status_map: dict[str, regscale_models.IssueStatus] = {
        "NotAFinding": regscale_models.IssueStatus.Closed,
        "Open": regscale_models.IssueStatus.Open,
    }
    finding_severity_map = {
        "critical": regscale_models.IssueSeverity.Critical,
        "high": regscale_models.IssueSeverity.High,
        "medium": regscale_models.IssueSeverity.Moderate,
        "low": regscale_models.IssueSeverity.Low,
    }

    def fetch_findings(self, **kwargs) -> Generator[IntegrationFinding, None, None]:
        """
        Parse STIG .ckl files and yield IntegrationFinding objects.

        Yields one finding per (asset, vulnerability, CCI reference) combination.

        :param kwargs: Must include 'path' — directory or file path to .ckl files
        :yields: IntegrationFinding for each finding
        :return: Generator of IntegrationFinding objects
        :rtype: Generator[IntegrationFinding, None, None]
        """
        path = Path(kwargs.get("path", ""))
        logger.info("Fetching findings...")
        stig_files = find_stig_files(path)

        self._init_due_date_cache()

        for stig_file in stig_files:
            logger.info("Processing '%s'", stig_file)
            ckl_file = parse_ckl_file(stig_file)

            if not ckl_file.stigs:
                continue

            vuln_count = sum(len(stig.vulns) for stig in ckl_file.stigs)
            logger.info("Found %d vulnerabilities in '%s'", vuln_count, stig_file)

            for stig in ckl_file.stigs:
                for vuln in stig.vulns:
                    for asset in ckl_file.assets:
                        asset_identifier = asset.host_fqdn or asset.host_name or asset.host_ip
                        if not asset_identifier:
                            self.log_error(
                                "No asset identifier found for asset '%s' (ip=%s), skipping vuln %s",
                                asset.host_name or "unknown",
                                asset.host_ip,
                                vuln.vuln_num,
                            )
                            continue

                        yield from self._create_findings_for_vuln(
                            asset_identifier, vuln, stig.stig_info.releaseinfo, stig.baseline
                        )

    def _init_due_date_cache(self) -> None:
        """Pre-compute due dates per severity to avoid redundant DueDateHandler instantiation."""
        self._created_date = date_str(datetime.datetime.now())
        self._due_date_cache: dict[regscale_models.IssueSeverity, str] = {}
        for sev in self.finding_severity_map.values():
            self._due_date_cache[sev] = issue_due_date(sev, self._created_date, title=self.title)

    def _create_findings_for_vuln(
        self,
        asset_identifier: str,
        vuln: Vuln,
        releaseinfo: str,
        baseline: str,
    ) -> Generator[IntegrationFinding, None, None]:
        """
        Create IntegrationFinding objects for a single vulnerability, one per CCI reference.

        :param str asset_identifier: The asset identifier (FQDN, hostname, or IP)
        :param Vuln vuln: The STIG vulnerability data
        :param str releaseinfo: The STIG release info string
        :param str baseline: The STIG baseline identifier
        :yields: IntegrationFinding for each CCI reference
        :rtype: Generator[IntegrationFinding, None, None]
        """
        if not hasattr(self, "_due_date_cache"):
            self._init_due_date_cache()

        severity = self.get_finding_severity(vuln.severity)
        created_date = self._created_date
        due_date = self._due_date_cache.get(severity, self._created_date)

        cci_refs = vuln.cci_ref if vuln.cci_ref else ["CCI-000366"]
        finding_title = f"{vuln.rule_title} {vuln.rule_ver} {releaseinfo} {vuln.vuln_num}"

        for cci_ref in cci_refs:
            yield IntegrationFinding(
                asset_identifier=asset_identifier,
                control_labels=[],
                title=finding_title,
                issue_title=finding_title,
                category=vuln.group_title,
                severity=severity,
                description=" ".join(part for part in (vuln.check_content, vuln.vuln_discuss, vuln.fix_text) if part),
                status=self.get_finding_status(vuln.status),
                checklist_status=self.get_checklist_status(vuln.status),
                external_id=f"{cci_ref}:{vuln.vuln_num}:{asset_identifier}",
                vulnerability_number=vuln.vuln_num,
                cci_ref=cci_ref,
                rule_id=vuln.rule_id,
                rule_version=vuln.rule_ver,
                results=(
                    f"Vulnerability Number: {vuln.vuln_num}, Severity: {vuln.severity}, "
                    f"Rule Title: {vuln.rule_title}<br><br>"
                    f"Check Content: {vuln.check_content}<br><br>"
                    f"Fix Text: {vuln.fix_text}<br><br>"
                    f"STIG Reference: {vuln.stigref}<br><br>"
                    f"Vulnerability Discussion: {vuln.vuln_discuss}"
                ),
                recommendation_for_mitigation=vuln.fix_text,
                comments=vuln.comments,
                poam_comments=vuln.finding_details,
                date_created=created_date,
                due_date=due_date,
                baseline=baseline,
                plugin_name=vuln.rule_id,
                observations=vuln.finding_details or "",
                gaps=vuln.check_content or "",
                evidence=vuln.check_content or "",
                impact=vuln.potential_impact or "",
            )

    def fetch_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Parse STIG .ckl files and yield IntegrationAsset objects.

        :param kwargs: Must include 'path' — directory or file path to .ckl files
        :raises ValueError: If no path is provided
        :yield: IntegrationAsset for each asset in the CKL files
        :return: Iterator of IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        path = kwargs.get("path")
        if not path:
            raise ValueError("Path to STIG files is required.")
        path = Path(path)

        logger.info("Fetching assets...")
        stig_files = find_stig_files(path)

        component_title = ""
        is_component = kwargs.get("is_component", False)
        if is_component:
            from regscale.validation.record import validate_regscale_object

            if not validate_regscale_object(parent_id=self.plan_id, parent_module="components"):
                raise error_and_exit("The provided Component ID is not valid.")
            component = regscale_models.Component.get_object(self.plan_id)
            component_title = component.title

        self.num_assets_to_process = len(stig_files)
        loading_stig_files = self.asset_progress.add_task(
            f"[#f8b737]Loading {len(stig_files)} STIG files.",
            total=len(stig_files),
        )

        parent_module = (
            regscale_models.Component.get_module_slug()
            if is_component
            else regscale_models.SecurityPlan.get_module_slug()
        )

        for stig_file in stig_files:
            logger.info("Processing '%s'", stig_file)
            ckl_file = parse_ckl_file(stig_file)

            component_names = self._get_component_names(ckl_file, component_title)

            for stig_asset in ckl_file.assets:
                identifier = stig_asset.host_fqdn or stig_asset.host_name or stig_asset.host_ip
                if not identifier:
                    logger.warning(
                        "No usable identifier for STIG asset (host_name=%s, host_fqdn=%s, host_ip=%s), skipping",
                        stig_asset.host_name,
                        stig_asset.host_fqdn,
                        stig_asset.host_ip,
                    )
                    continue
                if is_component and not component_names:
                    continue

                yield IntegrationAsset(
                    name=stig_asset.host_name or stig_asset.host_fqdn or "",
                    ip_address=stig_asset.host_ip,
                    fqdn=stig_asset.host_fqdn or stig_asset.host_name,
                    identifier=identifier,
                    asset_type=stig_asset.asset_type,
                    asset_owner_id=self.assessor_id,
                    parent_id=self.plan_id,
                    parent_module=parent_module,
                    asset_category=regscale_models.AssetCategory.Hardware,
                    component_names=component_names,
                    component_type=regscale_models.ComponentType.Hardware,
                )

            self.asset_progress.update(loading_stig_files, advance=1)

    @staticmethod
    def _get_component_names(ckl_file: CKLFile, component_title: Optional[str] = None) -> list[str]:
        """
        Extract component names from the CKL file's STIG titles.

        :param CKLFile ckl_file: The parsed CKL file.
        :param Optional[str] component_title: Override component title, defaults to None
        :return: A list of component names.
        :rtype: list[str]
        """
        if component_title:
            return [component_title]
        return [stig.component_title for stig in ckl_file.stigs]
