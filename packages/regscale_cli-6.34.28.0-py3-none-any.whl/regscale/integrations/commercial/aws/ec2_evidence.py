#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS EC2 Evidence Integration for RegScale CLI."""

import gzip
import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from io import BytesIO
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

from regscale.core.app.api import Api
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.commercial.aws._client_factory import make_aws_client
from regscale.integrations.commercial.aws.ec2_control_mappings import EC2ControlMapper
from regscale.integrations.compliance_integration import (
    ComplianceIntegration,
    ComplianceItem,
)
from regscale.models.regscale_models.evidence import Evidence
from regscale.models.regscale_models.evidence_mapping import EvidenceMapping
from regscale.models.regscale_models.file import File

logger = logging.getLogger("regscale")

EC2_CACHE_FILE = os.path.join("artifacts", "aws", "ec2_data.json")
CACHE_TTL_SECONDS = 4 * 60 * 60  # 4 hours

HTML_STRONG_OPEN = "<strong>"
HTML_STRONG_CLOSE = "</strong>"
HTML_P_OPEN = "<p>"
HTML_P_CLOSE = "</p>"
HTML_UL_OPEN = "<ul>"
HTML_UL_CLOSE = "</ul>"
HTML_LI_OPEN = "<li>"
HTML_LI_CLOSE = "</li>"
HTML_H2_OPEN = "<h2>"
HTML_H2_CLOSE = "</h2>"
HTML_H3_OPEN = "<h3>"
HTML_H3_CLOSE = "</h3>"
HTML_BR = "<br>"


@dataclass
class EC2EvidenceConfig:
    """Configuration for AWS EC2 evidence collection."""

    plan_id: int
    region: str = "us-east-1"
    framework: str = "NIST800-53R5"
    create_issues: bool = True
    update_control_status: bool = True
    create_poams: bool = False
    parent_module: str = "securityplans"
    collect_evidence: bool = False
    evidence_as_attachments: bool = False
    evidence_control_ids: Optional[List[str]] = None
    evidence_frequency: int = 30
    force_refresh: bool = False
    account_id: Optional[str] = None
    tags: Optional[Dict[str, str]] = field(default_factory=dict)
    profile: Optional[str] = None
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None


class EC2ComplianceItem(ComplianceItem):
    """
    Compliance item representing a single EC2 instance assessment.

    Maps EC2 instance attributes to compliance control requirements across
    EBS encryption, security groups, IMDSv2, public exposure, IAM profiles,
    VPC flow logs, and key pair usage.
    """

    def __init__(self, instance_data: Dict[str, Any], control_mapper: EC2ControlMapper):
        """
        Initialize EC2 compliance item from enriched instance data.

        :param Dict[str, Any] instance_data: Enriched EC2 instance data with EBS,
            security group, flow log, snapshot, and IAM metadata
        :param EC2ControlMapper control_mapper: Control mapper for compliance assessment
        """
        self.instance_data = instance_data
        self.control_mapper = control_mapper

        self._instance_id = instance_data.get("InstanceId", "")
        self._instance_type = instance_data.get("InstanceType", "")
        self._region = instance_data.get("Region", "unknown")
        self._account_id = instance_data.get("OwnerId", "unknown")
        self._state = instance_data.get("State", "unknown")
        self._tags = instance_data.get("Tags", [])
        self._vpc_id = instance_data.get("VpcId", "")
        self._subnet_id = instance_data.get("SubnetId", "")
        self._image_id = instance_data.get("ImageId", "")
        self._key_name = instance_data.get("KeyName", "")
        self._iam_profile = instance_data.get("IamInstanceProfile")

        self._compliance_results = control_mapper.assess_instance_compliance(instance_data)

    @property
    def resource_id(self) -> str:
        """Unique identifier for the EC2 instance."""
        return self._instance_id

    @property
    def resource_name(self) -> str:
        """Human-readable name of the EC2 instance."""
        for tag in self._tags:
            if tag.get("Key") == "Name":
                return f"{tag.get('Value')} ({self._instance_id})"
        return self._instance_id

    @property
    def control_id(self) -> str:
        """
        Primary control identifier for this instance assessment.

        Returns the first failing control, or first passing control if all pass.
        """
        for cid, result in self._compliance_results.items():
            if result == "FAIL":
                return cid
        return list(self._compliance_results.keys())[0] if self._compliance_results else "SC-13"

    def get_all_control_ids(self) -> List[str]:
        """
        Return all assessed control IDs for this instance.

        :return: List of all control IDs
        :rtype: List[str]
        """
        return list(self._compliance_results.keys())

    @property
    def compliance_result(self) -> str:
        """Overall compliance result -- FAIL if any control fails."""
        if not self._compliance_results:
            return "PASS"
        if "FAIL" in self._compliance_results.values():
            return "FAIL"
        return "PASS"

    @property
    def severity(self) -> Optional[str]:
        """Severity level based on which controls are failing."""
        if self.compliance_result == "PASS":
            return None

        high_controls = {"AC-3", "AC-4", "SC-7", "AC-6"}
        for cid in high_controls:
            if self._compliance_results.get(cid) == "FAIL":
                return "HIGH"

        medium_controls = {"SC-13", "SC-28", "IA-3", "CM-6"}
        for cid in medium_controls:
            if self._compliance_results.get(cid) == "FAIL":
                return "MEDIUM"

        return "LOW"

    @property
    def description(self) -> str:
        """Detailed HTML description of the EC2 instance compliance assessment."""
        parts = self._build_instance_details()
        parts.extend(self._build_compliance_results_section())
        if self.compliance_result == "FAIL":
            parts.extend(self._build_remediation_section())
        return "".join(parts)

    @property
    def framework(self) -> str:
        """Compliance framework used for assessment."""
        return self.control_mapper.framework

    # ── HTML description builders ──────────────────────────────────────

    def _build_instance_details(self) -> List[str]:
        """Build the instance details section of the description."""
        arn = f"arn:aws:ec2:{self._region}:{self._account_id}:instance/{self._instance_id}"
        profile_name = ""
        if self._iam_profile:
            profile_name = (
                self._iam_profile.get("Arn", "").split("/")[-1] if self._iam_profile.get("Arn") else "attached"
            )

        parts = [
            f"{HTML_H3_OPEN}AWS EC2 Instance Compliance Assessment{HTML_H3_CLOSE}",
            HTML_P_OPEN,
            f"{HTML_STRONG_OPEN}Instance ID:{HTML_STRONG_CLOSE} {self._instance_id}{HTML_BR}",
            f"{HTML_STRONG_OPEN}ARN:{HTML_STRONG_CLOSE} {arn}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Instance Type:{HTML_STRONG_CLOSE} {self._instance_type}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Region:{HTML_STRONG_CLOSE} {self._region}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Account:{HTML_STRONG_CLOSE} {self._account_id}{HTML_BR}",
            f"{HTML_STRONG_OPEN}State:{HTML_STRONG_CLOSE} {self._state}{HTML_BR}",
            f"{HTML_STRONG_OPEN}AMI:{HTML_STRONG_CLOSE} {self._image_id}{HTML_BR}",
            f"{HTML_STRONG_OPEN}VPC:{HTML_STRONG_CLOSE} {self._vpc_id}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Key Pair:{HTML_STRONG_CLOSE} {self._key_name or 'None'}{HTML_BR}",
            f"{HTML_STRONG_OPEN}IAM Profile:{HTML_STRONG_CLOSE} {profile_name or 'None'}",
            HTML_P_CLOSE,
        ]
        return parts

    def _build_compliance_results_section(self) -> List[str]:
        """Build the compliance results section."""
        section = [
            f"{HTML_H3_OPEN}Control Compliance Results{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
        ]
        for cid, result in self._compliance_results.items():
            color = "#d32f2f" if result == "FAIL" else "#2e7d32"
            desc = self.control_mapper.get_control_description(cid)
            section.append(
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}{cid}:{HTML_STRONG_CLOSE} "
                f"<span style='color: {color};'>{result}</span> - {desc}{HTML_LI_CLOSE}"
            )
        section.append(HTML_UL_CLOSE)
        return section

    def _build_remediation_section(self) -> List[str]:
        """Build remediation guidance for failed controls."""
        section = [
            f"{HTML_H3_OPEN}Remediation Guidance{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
        ]
        remediation_map = {
            "SC-13": "Enable encryption on all EBS volumes attached to this instance",
            "SC-28": "Ensure all EBS volumes use KMS encryption; prefer customer-managed keys",
            "AC-4": "Restrict security group inbound rules to specific IPs/CIDRs on sensitive ports",
            "SC-7": "Remove public IP or restrict outbound security group rules to required destinations",
            "IA-3": "Enforce IMDSv2 by setting HttpTokens to 'required' on the instance metadata options",
            "CM-6": "Update instance metadata options to require IMDSv2 (HttpTokens = required)",
            "AC-3": "Ensure AMI is private, remove public EBS snapshots, and attach an IAM instance profile",
            "AC-6": "Review IAM role policies; reduce managed policy count and remove wildcard actions",
            "AU-2": "Enable VPC flow logs on the VPC associated with this instance",
            "AU-12": "Verify VPC flow logs are in ACTIVE status and delivering to the configured destination",
            "SI-4": "Configure VPC flow logs for network traffic monitoring",
            "IA-5": "Assign an SSH key pair to the instance for authenticator management",
        }
        for cid, result in self._compliance_results.items():
            if result == "FAIL" and cid in remediation_map:
                section.append(
                    f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}{cid}:{HTML_STRONG_CLOSE} {remediation_map[cid]}{HTML_LI_CLOSE}"
                )
        section.append(HTML_UL_CLOSE)
        return section


class PerControlEC2ComplianceItem(EC2ComplianceItem):
    """
    EC2 compliance item pinned to a single control ID.

    Allows the compliance pipeline to generate one finding per (control, instance)
    pair instead of one finding per instance.
    """

    def __init__(self, instance_data: Dict[str, Any], control_mapper: EC2ControlMapper, specific_control_id: str):
        """
        Initialize per-control compliance item.

        :param Dict[str, Any] instance_data: Enriched EC2 instance data
        :param EC2ControlMapper control_mapper: Control mapper for compliance assessment
        :param str specific_control_id: The single control ID this item represents
        """
        super().__init__(instance_data, control_mapper)
        self._specific_control_id = specific_control_id

    @property
    def control_id(self) -> str:
        """Return the pinned control ID for this item."""
        return self._specific_control_id

    @property
    def compliance_result(self) -> str:
        """Return the compliance result for the pinned control only."""
        return self._compliance_results.get(self._specific_control_id, "PASS")

    def get_all_control_ids(self) -> List[str]:
        """Return only the pinned control ID."""
        return [self._specific_control_id]

    @property
    def severity(self) -> Optional[str]:
        """Severity for the pinned control only."""
        if self.compliance_result != "FAIL":
            return None
        high_controls = {"AC-3", "AC-4", "SC-7", "AC-6"}
        if self._specific_control_id in high_controls:
            return "HIGH"
        medium_controls = {"SC-13", "SC-28", "IA-3", "CM-6"}
        if self._specific_control_id in medium_controls:
            return "MEDIUM"
        return "LOW"


class AWSEC2EvidenceIntegration(ComplianceIntegration):
    """Process AWS EC2 instance data and create evidence/compliance records in RegScale."""

    # EC2 compliance findings are issues, not CVE vulnerabilities.
    # This ensures process_finding() routes through queue_issue_from_finding()
    # (the issues batch path) instead of _process_vulnerability_finding().
    skip_vulnerability_creation = True

    def __init__(self, config: EC2EvidenceConfig):
        """
        Initialize AWS EC2 evidence integration.

        :param EC2EvidenceConfig config: Configuration object
        """
        super().__init__(
            plan_id=config.plan_id,
            framework=config.framework,
            create_issues=config.create_issues,
            update_control_status=config.update_control_status,
            create_poams=config.create_poams,
            parent_module=config.parent_module,
        )

        self.api = Api()
        self.region = config.region
        self.title = "AWS EC2"
        self.framework = config.framework

        self.collect_evidence = config.collect_evidence
        self.evidence_as_attachments = config.evidence_as_attachments
        self.evidence_control_ids = config.evidence_control_ids
        self.evidence_frequency = config.evidence_frequency

        self.force_refresh = config.force_refresh
        self.account_id = config.account_id
        self.tags = config.tags or {}

        self.control_mapper = EC2ControlMapper(framework=config.framework)

        profile = config.profile
        aws_access_key_id = config.aws_access_key_id
        aws_secret_access_key = config.aws_secret_access_key
        aws_session_token = config.aws_session_token

        if aws_access_key_id and aws_secret_access_key:
            logger.info("Initializing AWS EC2 clients with explicit credentials")
            self.session = boto3.Session(
                region_name=config.region,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                aws_session_token=aws_session_token,
            )
        else:
            logger.info("Initializing AWS EC2 clients with profile: %s", profile if profile else "default")
            self.session = boto3.Session(profile_name=profile, region_name=config.region)

        try:
            self.ec2_client = make_aws_client(self.session, "ec2")
            self.iam_client = make_aws_client(self.session, "iam")
            logger.info("Successfully created AWS EC2 and IAM clients")
        except Exception as e:
            logger.error("Failed to create AWS clients: %s", e)
            raise

        self.raw_ec2_data: List[Dict[str, Any]] = []

    # ── Cache management ───────────────────────────────────────────────

    def _is_cache_valid(self) -> bool:
        """
        Check if the cache file exists and is within the TTL.

        :return: True if cache is valid
        :rtype: bool
        """
        if not os.path.exists(EC2_CACHE_FILE):
            return False

        file_age = time.time() - os.path.getmtime(EC2_CACHE_FILE)
        is_valid = file_age < CACHE_TTL_SECONDS

        if is_valid:
            logger.info("Using cached EC2 data (age: %.1f hours)", file_age / 3600)
        else:
            logger.debug("Cache expired (age: %.1f hours)", file_age / 3600)

        return is_valid

    def _load_cached_data(self) -> List[Dict[str, Any]]:
        """
        Load EC2 data from cache file.

        :return: List of enriched EC2 instance data
        :rtype: List[Dict[str, Any]]
        """
        try:
            with open(EC2_CACHE_FILE, encoding="utf-8") as f:
                cached = json.load(f)

            if not isinstance(cached, list):
                logger.warning("Invalid EC2 cache format (not a list). Invalidating cache.")
                return []
            if cached and not isinstance(cached[0], dict):
                logger.warning("Invalid EC2 cache format (items not dicts). Invalidating cache.")
                return []

            logger.info("Loaded %d EC2 instances from cache", len(cached))
            return cached
        except (json.JSONDecodeError, IOError) as e:
            logger.warning("Error reading EC2 cache: %s. Fetching fresh data.", e)
            return []

    def _save_to_cache(self, data: List[Dict[str, Any]]) -> None:
        """
        Save EC2 data to cache file.

        :param List[Dict[str, Any]] data: Data to cache
        """
        try:
            os.makedirs(os.path.dirname(EC2_CACHE_FILE), exist_ok=True)
            with open(EC2_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, default=str)
            logger.info("Cached %d EC2 instances to %s", len(data), EC2_CACHE_FILE)
        except IOError as e:
            logger.warning("Error writing EC2 cache: %s", e)

    # ── AWS data collection ────────────────────────────────────────────

    def _fetch_fresh_ec2_data(self) -> List[Dict[str, Any]]:
        """
        Fetch and enrich EC2 instance data from AWS.

        Collects instances and enriches each with EBS volume details, security
        group rules, IMDS metadata options, public AMI/snapshot status, IAM
        role details, VPC flow log configuration, and key pair metadata.

        :return: List of enriched instance dicts
        :rtype: List[Dict[str, Any]]
        """
        logger.info("Fetching EC2 data from AWS region %s ...", self.region)
        if self.account_id:
            logger.info("Filtering by account ID: %s", self.account_id)
        if self.tags:
            logger.info("Filtering by tags: %s", self.tags)

        instances = self._describe_instances()
        if not instances:
            logger.warning("No EC2 instances found in region %s", self.region)
            return []

        volume_map = self._describe_volumes()
        sg_map = self._describe_security_groups(instances)
        flow_log_map = self._describe_flow_logs(instances)
        public_snapshot_ids = self._describe_public_snapshots(instances)
        public_ami_ids = self._describe_public_amis(instances)

        enriched = []
        for inst in instances:
            inst["Region"] = self.region
            inst["EbsVolumes"] = self._get_instance_volumes(inst, volume_map)
            inst["SecurityGroupDetails"] = self._get_instance_sg_details(inst, sg_map)
            inst["VpcFlowLogs"] = flow_log_map.get(inst.get("VpcId", ""), [])
            inst["IsPublicAmi"] = inst.get("ImageId", "") in public_ami_ids
            inst["PublicSnapshots"] = self._get_instance_public_snapshots(inst, public_snapshot_ids)
            inst["IamRoleDetails"] = self._get_iam_role_details(inst)
            enriched.append(inst)

        logger.info("Enriched %d EC2 instances with compliance metadata", len(enriched))
        return enriched

    def _describe_instances(self) -> List[Dict[str, Any]]:
        """
        Describe all EC2 instances, applying account and tag filters.

        :return: List of instance dicts from describe_instances
        :rtype: List[Dict[str, Any]]
        """
        instances: List[Dict[str, Any]] = []
        try:
            paginator = self.ec2_client.get_paginator("describe_instances")
            for page in paginator.paginate():
                for reservation in page.get("Reservations", []):
                    owner_id = reservation.get("OwnerId", "")
                    if self.account_id and owner_id != self.account_id:
                        continue
                    for inst in reservation.get("Instances", []):
                        if self.tags and not self._instance_matches_tags(inst):
                            continue
                        inst["OwnerId"] = owner_id
                        instances.append(inst)
        except ClientError as e:
            self._handle_client_error(e, "describe_instances")
        return instances

    def _instance_matches_tags(self, instance: Dict[str, Any]) -> bool:
        """
        Check if instance tags match all configured filter tags.

        :param Dict[str, Any] instance: Instance dict
        :return: True if all filter tags match
        :rtype: bool
        """
        inst_tags = {t["Key"]: t["Value"] for t in instance.get("Tags", [])}
        return all(inst_tags.get(k) == v for k, v in self.tags.items())

    def _describe_volumes(self) -> Dict[str, Dict[str, Any]]:
        """
        Describe all EBS volumes in the region, keyed by volume ID.

        :return: volume_id -> volume dict
        :rtype: Dict[str, Dict[str, Any]]
        """
        vol_map: Dict[str, Dict[str, Any]] = {}
        try:
            paginator = self.ec2_client.get_paginator("describe_volumes")
            for page in paginator.paginate():
                for vol in page.get("Volumes", []):
                    vol_map[vol["VolumeId"]] = vol
        except ClientError as e:
            self._handle_client_error(e, "describe_volumes")
        return vol_map

    def _describe_security_groups(self, instances: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """
        Describe security groups referenced by instances.

        :param List[Dict[str, Any]] instances: List of instances
        :return: sg_id -> security group dict
        :rtype: Dict[str, Dict[str, Any]]
        """
        sg_ids: set = set()
        for inst in instances:
            for sg in inst.get("SecurityGroups", []):
                sg_ids.add(sg["GroupId"])

        sg_map: Dict[str, Dict[str, Any]] = {}
        if not sg_ids:
            return sg_map

        try:
            sg_id_list = list(sg_ids)
            for i in range(0, len(sg_id_list), 200):
                batch = sg_id_list[i : i + 200]
                resp = self.ec2_client.describe_security_groups(GroupIds=batch)
                for sg in resp.get("SecurityGroups", []):
                    sg_map[sg["GroupId"]] = sg
        except ClientError as e:
            self._handle_client_error(e, "describe_security_groups")
        return sg_map

    def _describe_flow_logs(self, instances: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Describe VPC flow logs for VPCs associated with instances.

        :param List[Dict[str, Any]] instances: List of instances
        :return: vpc_id -> list of flow log dicts
        :rtype: Dict[str, List[Dict[str, Any]]]
        """
        vpc_ids = {inst.get("VpcId") for inst in instances if inst.get("VpcId")}
        flow_map: Dict[str, List[Dict[str, Any]]] = {v: [] for v in vpc_ids}

        if not vpc_ids:
            return flow_map

        try:
            resp = self.ec2_client.describe_flow_logs(Filters=[{"Name": "resource-id", "Values": list(vpc_ids)}])
            for fl in resp.get("FlowLogs", []):
                rid = fl.get("ResourceId", "")
                if rid in flow_map:
                    flow_map[rid].append(fl)
        except ClientError as e:
            self._handle_client_error(e, "describe_flow_logs")
        return flow_map

    def _describe_public_snapshots(self, instances: List[Dict[str, Any]]) -> set:
        """
        Find EBS snapshot IDs from instance volumes that are publicly shared.

        :param List[Dict[str, Any]] instances: Instances
        :return: Set of public snapshot IDs
        :rtype: set
        """
        volume_ids: set = set()
        for inst in instances:
            for bdm in inst.get("BlockDeviceMappings", []):
                ebs = bdm.get("Ebs", {})
                if vid := ebs.get("VolumeId"):
                    volume_ids.add(vid)

        if not volume_ids:
            return set()

        snapshot_ids: set = set()
        try:
            paginator = self.ec2_client.get_paginator("describe_snapshots")
            for page in paginator.paginate(
                Filters=[{"Name": "volume-id", "Values": list(volume_ids)}],
                OwnerIds=["self"],
            ):
                for snap in page.get("Snapshots", []):
                    snapshot_ids.add(snap["SnapshotId"])
        except ClientError as e:
            self._handle_client_error(e, "describe_snapshots (by volume)")

        if not snapshot_ids:
            return set()

        # describe_snapshot_attribute has no batch variant — call once per snapshot.
        # Rate-limit to ~50 req/s (conservative) and back off on throttling to avoid
        # hitting the EC2 API limit in environments with many EBS snapshots.
        _RATE_LIMIT_BATCH = 50
        _RATE_LIMIT_SLEEP = 1.0  # seconds between batches
        _THROTTLE_SLEEP = 5.0  # seconds to wait after a RequestLimitExceeded error

        public_ids: set = set()
        snapshot_list = list(snapshot_ids)
        for idx, sid in enumerate(snapshot_list):
            try:
                resp = self.ec2_client.describe_snapshot_attribute(SnapshotId=sid, Attribute="createVolumePermission")
                for perm in resp.get("CreateVolumePermissions", []):
                    if perm.get("Group") == "all":
                        public_ids.add(sid)
                        break
            except ClientError as e:
                if e.response.get("Error", {}).get("Code") in ("RequestLimitExceeded", "Throttling"):
                    logger.warning("EC2 API rate limit hit on describe_snapshot_attribute, backing off...")
                    time.sleep(_THROTTLE_SLEEP)
                else:
                    self._handle_client_error(e, "describe_snapshot_attribute")

            # Pause every N calls to stay within AWS rate limits
            if (idx + 1) % _RATE_LIMIT_BATCH == 0:
                time.sleep(_RATE_LIMIT_SLEEP)

        return public_ids

    def _describe_public_amis(self, instances: List[Dict[str, Any]]) -> set:
        """
        Find AMI IDs used by instances that are publicly shared.

        :param List[Dict[str, Any]] instances: Instances
        :return: Set of public AMI IDs
        :rtype: set
        """
        ami_ids = {inst.get("ImageId") for inst in instances if inst.get("ImageId")}
        if not ami_ids:
            return set()

        public_ids: set = set()
        try:
            resp = self.ec2_client.describe_images(
                ImageIds=list(ami_ids),
                Filters=[{"Name": "is-public", "Values": ["true"]}],
            )
            for img in resp.get("Images", []):
                public_ids.add(img["ImageId"])
        except ClientError as e:
            self._handle_client_error(e, "describe_images (public check)")

        return public_ids

    # ── Instance enrichment helpers ────────────────────────────────────

    @staticmethod
    def _get_instance_volumes(instance: Dict[str, Any], volume_map: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Get EBS volume details for an instance.

        :param Dict[str, Any] instance: Instance dict
        :param Dict[str, Dict[str, Any]] volume_map: volume_id -> volume dict
        :return: List of volume dicts
        :rtype: List[Dict[str, Any]]
        """
        volumes = []
        for bdm in instance.get("BlockDeviceMappings", []):
            ebs = bdm.get("Ebs", {})
            vid = ebs.get("VolumeId")
            if vid and vid in volume_map:
                volumes.append(volume_map[vid])
        return volumes

    @staticmethod
    def _get_instance_sg_details(instance: Dict[str, Any], sg_map: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Get full security group details for an instance.

        :param Dict[str, Any] instance: Instance dict
        :param Dict[str, Dict[str, Any]] sg_map: sg_id -> SG dict
        :return: List of SG dicts
        :rtype: List[Dict[str, Any]]
        """
        return [sg_map[sg["GroupId"]] for sg in instance.get("SecurityGroups", []) if sg["GroupId"] in sg_map]

    @staticmethod
    def _get_instance_public_snapshots(instance: Dict[str, Any], public_snapshot_ids: set) -> List[str]:
        """
        Get public snapshot IDs for an instance's EBS volumes.

        :param Dict[str, Any] instance: Instance dict
        :param set public_snapshot_ids: Set of public snapshot IDs
        :return: List of public snapshot IDs
        :rtype: List[str]
        """
        result = []
        for bdm in instance.get("BlockDeviceMappings", []):
            ebs = bdm.get("Ebs", {})
            vid = ebs.get("VolumeId")
            if vid:
                for sid in public_snapshot_ids:
                    result.append(sid)
        return list(set(result))

    def _get_iam_role_details(self, instance: Dict[str, Any]) -> Dict[str, Any]:
        """
        Get IAM role details for the instance profile.

        :param Dict[str, Any] instance: Instance dict
        :return: Dict with ManagedPolicyCount, HasWildcardPolicy, RoleName
        :rtype: Dict[str, Any]
        """
        profile = instance.get("IamInstanceProfile")
        if not profile:
            return {}

        profile_arn = profile.get("Arn", "")
        profile_name = profile_arn.split("/")[-1] if "/" in profile_arn else ""
        if not profile_name:
            return {}

        try:
            resp = self.iam_client.get_instance_profile(InstanceProfileName=profile_name)
            roles = resp.get("InstanceProfile", {}).get("Roles", [])
            if not roles:
                return {}

            role_name = roles[0].get("RoleName", "")
            return self._assess_role(role_name)
        except ClientError as e:
            logger.debug("Could not get instance profile %s: %s", profile_name, e)
            return {}

    def _assess_role(self, role_name: str) -> Dict[str, Any]:
        """
        Assess an IAM role's policy scope.

        :param str role_name: IAM role name
        :return: Dict with RoleName, ManagedPolicyCount, HasWildcardPolicy
        :rtype: Dict[str, Any]
        """
        details: Dict[str, Any] = {"RoleName": role_name, "ManagedPolicyCount": 0, "HasWildcardPolicy": False}
        try:
            managed = self.iam_client.list_attached_role_policies(RoleName=role_name)
            details["ManagedPolicyCount"] = len(managed.get("AttachedPolicies", []))

            inline = self.iam_client.list_role_policies(RoleName=role_name)
            for policy_name in inline.get("PolicyNames", []):
                pol_resp = self.iam_client.get_role_policy(RoleName=role_name, PolicyName=policy_name)
                doc = pol_resp.get("PolicyDocument", {})
                if isinstance(doc, str):
                    import urllib.parse

                    doc = json.loads(urllib.parse.unquote(doc))
                for stmt in doc.get("Statement", []):
                    actions = stmt.get("Action", [])
                    if isinstance(actions, str):
                        actions = [actions]
                    if "*" in actions and stmt.get("Effect") == "Allow":
                        details["HasWildcardPolicy"] = True
                        break
                if details["HasWildcardPolicy"]:
                    break
        except ClientError as e:
            logger.debug("Could not assess role %s: %s", role_name, e)
        return details

    # ── ComplianceIntegration interface ────────────────────────────────

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Fetch enriched EC2 data from AWS (with caching).

        :return: List of enriched instance dicts
        :rtype: List[Dict[str, Any]]
        """
        if not self.force_refresh and self._is_cache_valid():
            cached = self._load_cached_data()
            if cached:
                self.raw_ec2_data = cached
                return cached

        if self.force_refresh:
            logger.info("Force refresh requested, bypassing EC2 cache...")

        try:
            data = self._fetch_fresh_ec2_data()
            self.raw_ec2_data = data
            self._save_to_cache(data)
            return data
        except ClientError as e:
            from regscale.integrations.commercial.aws.common import handle_aws_client_error

            handle_aws_client_error(e, "fetching EC2 data from AWS", region=self.region)
            return []

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> ComplianceItem:
        """
        Create a ComplianceItem from enriched EC2 instance data.

        :param Dict[str, Any] raw_data: Enriched instance data
        :return: EC2ComplianceItem
        :rtype: ComplianceItem
        """
        return EC2ComplianceItem(raw_data, self.control_mapper)

    def process_compliance_data(self) -> None:
        """
        Override to expand each EC2 instance into per-control compliance items.

        Generates one PerControlEC2ComplianceItem per (control, instance) pair so
        that every failing control on every instance produces a distinct finding with
        a unique title and external ID.

        :return: None
        """
        logger.info("Processing EC2 compliance data (per-control expansion)...")

        self._reset_compliance_state()
        allowed_controls = self._build_allowed_controls_set()
        raw_compliance_data = self.fetch_compliance_data()

        stats = {
            "skipped_no_control": 0,
            "skipped_no_resource": 0,
            "skipped_not_in_plan": 0,
            "processed_count": 0,
        }

        for raw_item in raw_compliance_data:
            try:
                base_item = EC2ComplianceItem(raw_item, self.control_mapper)
                for control_id in base_item.get_all_control_ids():
                    per_control_item = PerControlEC2ComplianceItem(raw_item, self.control_mapper, control_id)
                    self._process_single_compliance_item(per_control_item, allowed_controls, stats)
            except Exception as e:
                logger.error("Error processing EC2 compliance item: %s", e)
                continue

        self._log_processing_summary(raw_compliance_data, stats)
        self._categorize_controls_by_aggregation()
        self._log_final_results()

    def _map_resource_type_to_asset_type(self, compliance_item: ComplianceItem) -> str:
        """
        Map EC2 instance to RegScale asset type.

        :param ComplianceItem compliance_item: Compliance item
        :return: Asset type string
        :rtype: str
        """
        return "AWS EC2 Instance"

    def create_finding_from_compliance_item(self, compliance_item: ComplianceItem):
        """
        Override to stamp a unique plugin_id and descriptive title on each EC2 finding.

        The base class leaves plugin_id unset, which causes IntegrationFinding.__post_init__
        to fall back to plugin_name ("AWS EC2 Compliance Scanner") for every finding.
        Because get_finding_identifier uses plugin_id to build integrationFindingId, all
        findings collapse to the same key and are consolidated into one issue.

        Setting plugin_id to "EC2.<control_id>.<instance_id>" gives each (control, instance)
        pair a distinct key so 252 findings remain 252 issues.

        The title is updated to include the instance name so issues for the same control
        across different instances are distinguishable in the UI.

        :param ComplianceItem compliance_item: The compliance item to convert
        :return: IntegrationFinding with unique plugin_id and descriptive title, or None
        """
        finding = super().create_finding_from_compliance_item(compliance_item)
        if finding is not None:
            finding.plugin_id = f"EC2.{compliance_item.control_id}.{compliance_item.resource_id}"
            resource_label = compliance_item.resource_name or compliance_item.resource_id
            finding.title = f"Compliance Violation: {compliance_item.control_id} - {resource_label}"
        return finding

    def _build_issue_batch_options(self):
        """
        Return batch options for EC2 compliance issues.

        Uses pluginId (not integrationFindingId) as the server-side deduplication key,
        matching the pattern used by sync_findings. source="AWS" is required — the server
        pre-validates this field and rejects unknown values (e.g. "AWS EC2") with
        isSuccessful=False before any records are processed.

        :return: IssueBatchOptions for EC2 compliance issue batches
        """
        from regscale.models.regscale_models.batch_options import IssueBatchOptions

        return IssueBatchOptions(
            source="AWS",
            uniqueKeyFields=["pluginId"],
            enableMopUp=False,
            parentId=self.plan_id,
            parentModule=self.parent_module,
            assetIdentifierFieldName=self.asset_identifier_field,
        )

    def _sync_issues(self) -> None:
        """
        Override to route findings through the same path as aws sync_findings.

        With skip_vulnerability_creation=True, process_finding() routes each finding
        through queue_issue_from_finding() which queues issues for batch submission.
        _batch_submit_pending_issues() flushes via the issues endpoint with
        uniqueKeyFields=["integrationFindingId"] for server-side dedup.

        :return: None
        """
        if not self.create_issues:
            logger.info("Issue creation disabled (create_issues=False), skipping issue sync")
            return

        findings = list(self.fetch_findings())
        if not findings:
            logger.info("No EC2 compliance findings to process")
            return

        # Ensure asset map is populated before processing
        if not self.asset_map_by_identifier:
            self.asset_map_by_identifier.update(self.get_asset_map())

        # Filter to findings whose control has a matching SSP implementation
        matched_ids = self._matched_control_ids
        if matched_ids:
            filtered = [f for f in findings if self._finding_has_matching_control(f)]
            skipped = len(findings) - len(filtered)
            logger.info(
                "EC2 compliance: %d/%d findings match SSP controls (%d skipped — control not in SSP)",
                len(filtered),
                len(findings),
                skipped,
            )
            findings = filtered

        if not findings:
            logger.info("No EC2 findings with matching SSP controls to process")
            return

        # process_finding() → queue_issue_from_finding() for each (skip_vulnerability_creation=True)
        logger.info("Processing %d EC2 findings via issue batch path...", len(findings))
        self.update_regscale_findings(iter(findings))

        # Flush queued issues via the issues batch endpoint with integrationFindingId dedup
        self._batch_submit_pending_issues(progress=self.finding_progress)

    def sync_compliance(self) -> None:
        """
        Sync EC2 compliance data, then optionally collect evidence.

        :return: None
        """
        super().sync_compliance()

        if self.collect_evidence:
            logger.info("Evidence collection enabled, starting EC2 evidence collection...")
            self._collect_ec2_evidence()

    # ── Evidence collection ────────────────────────────────────────────

    def _collect_ec2_evidence(self) -> None:
        """Collect EC2 evidence and create Evidence records or SSP attachments."""
        if not self.raw_ec2_data:
            logger.warning("No EC2 data available for evidence collection")
            return

        scan_date = get_current_datetime(dt_format="%Y%m%d_%H%M%S")

        if self.evidence_as_attachments:
            logger.info("Creating SSP file attachment with EC2 evidence...")
            self._create_ssp_attachment(scan_date)
        else:
            logger.info("Creating Evidence record with EC2 evidence...")
            self._create_evidence_record(scan_date)

    def _create_ssp_attachment(self, scan_date: str) -> None:
        """
        Create SSP file attachment with EC2 evidence data.

        :param str scan_date: Scan timestamp string
        """
        try:
            date_str = datetime.now().strftime("%Y%m%d")
            account_suffix = f"_{self.account_id}" if self.account_id else ""
            file_name_pattern = f"ec2_evidence{account_suffix}_{date_str}"

            if self.check_for_existing_evidence(file_name_pattern):
                logger.info("EC2 evidence file already exists for today. Skipping to avoid duplicates.")
                return

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"ec2_evidence{account_suffix}_{timestamp}.jsonl.gz"

            jsonl_lines = self._build_evidence_jsonl(scan_date)
            jsonl_content = "\n".join(jsonl_lines)

            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz:
                gz.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()
            compressed_mb = len(compressed_data) / (1024 * 1024)
            raw_mb = len(jsonl_content.encode("utf-8")) / (1024 * 1024)
            reduction = (1 - (len(compressed_data) / max(len(jsonl_content.encode("utf-8")), 1))) * 100

            logger.info(
                "Compressed EC2 evidence: %.2f MB -> %.2f MB (%.1f%% reduction)",
                raw_mb,
                compressed_mb,
                reduction,
            )

            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=self.plan_id,
                parent_module=self.parent_module,
                api=api,
                file_data=compressed_data,
                tags="aws,ec2,compute,compliance,automated",
            )

            if success:
                logger.info("Uploaded EC2 evidence file to SSP %d: %s", self.plan_id, file_name)
            else:
                logger.error("Failed to upload EC2 evidence file to SSP %d", self.plan_id)
        except Exception as e:
            logger.error("Error creating SSP attachment for EC2 evidence: %s", e, exc_info=True)

    def _create_evidence_record(self, scan_date: str) -> None:
        """
        Create Evidence record with EC2 evidence data.

        :param str scan_date: Scan timestamp string
        """
        try:
            title = f"AWS EC2 Evidence - {scan_date}"
            description = self._build_evidence_description(scan_date)
            due_date = (datetime.now() + timedelta(days=self.evidence_frequency)).isoformat()

            evidence = Evidence(
                title=title,
                description=description,
                status="Collected",
                updateFrequency=self.evidence_frequency,
                dueDate=due_date,
            )

            created = evidence.create()
            if not created or not created.id:
                logger.error("Failed to create EC2 evidence record")
                return

            logger.info("Created evidence record %d: %s", created.id, title)
            self._upload_evidence_file(created.id, scan_date)
            self._link_evidence_to_ssp(created.id)

            if self.evidence_control_ids:
                self._link_evidence_to_controls(created.id, is_attachment=False)
        except Exception as e:
            logger.error("Error creating EC2 evidence record: %s", e, exc_info=True)

    def _build_evidence_jsonl(self, scan_date: str) -> List[str]:
        """Build JSONL lines with compliance results for each instance."""
        lines = []
        for inst in self.raw_ec2_data:
            item = self.create_compliance_item(inst)
            entry = {
                "InstanceId": inst.get("InstanceId"),
                "InstanceType": inst.get("InstanceType"),
                "Region": inst.get("Region"),
                "OwnerId": inst.get("OwnerId"),
                "State": inst.get("State"),
                "ImageId": inst.get("ImageId"),
                "VpcId": inst.get("VpcId"),
                "KeyName": inst.get("KeyName"),
                "Tags": inst.get("Tags", []),
                "compliance_assessment": {
                    "overall_result": item.compliance_result,
                    "control_results": item._compliance_results,
                    "assessed_controls": list(item._compliance_results.keys()),
                    "assessment_date": scan_date,
                },
            }
            lines.append(json.dumps(entry, default=str))
        return lines

    def _build_evidence_description(self, scan_date: str) -> str:
        """Build HTML evidence description with summary statistics."""
        stats = self._calculate_ec2_statistics()
        control_stats = self._calculate_control_compliance_stats()

        parts = [
            "<h1>AWS EC2 Evidence</h1>",
            f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Assessment Date:{HTML_STRONG_CLOSE} {scan_date}{HTML_P_CLOSE}",
            f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Region:{HTML_STRONG_CLOSE} {self.region}{HTML_P_CLOSE}",
        ]

        if self.account_id:
            parts.append(
                f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Filtered by Account ID:{HTML_STRONG_CLOSE} {self.account_id}{HTML_P_CLOSE}"
            )
        if self.tags:
            tags_str = ", ".join(f"{k}={v}" for k, v in self.tags.items())
            parts.append(
                f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Filtered by Tags:{HTML_STRONG_CLOSE} {tags_str}{HTML_P_CLOSE}"
            )

        parts.extend(
            [
                f"{HTML_H2_OPEN}Summary{HTML_H2_CLOSE}",
                HTML_UL_OPEN,
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Total Instances:{HTML_STRONG_CLOSE} {stats['total']}{HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Compliant:{HTML_STRONG_CLOSE} {stats['compliant']} ({stats['compliant_pct']:.1f}%){HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Non-Compliant:{HTML_STRONG_CLOSE} {stats['non_compliant']}{HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}EBS Encryption Coverage:{HTML_STRONG_CLOSE} {stats['ebs_encrypted_pct']:.1f}%{HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}IMDSv2 Enforced:{HTML_STRONG_CLOSE} {stats['imdsv2_pct']:.1f}%{HTML_LI_CLOSE}",
                HTML_UL_CLOSE,
            ]
        )

        parts.extend(
            [
                f"{HTML_H2_OPEN}Control Compliance Results{HTML_H2_CLOSE}",
                HTML_UL_OPEN,
            ]
        )
        for cid in sorted(control_stats.keys()):
            s = control_stats[cid]
            total = s["pass"] + s["fail"]
            pct = s["pass"] / max(total, 1) * 100
            desc = self.control_mapper.get_control_description(cid)
            parts.append(
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}{cid}:{HTML_STRONG_CLOSE} "
                f"{s['pass']} PASS / {s['fail']} FAIL ({pct:.1f}% compliant) - {desc}{HTML_LI_CLOSE}"
            )
        parts.append(HTML_UL_CLOSE)
        return "".join(parts)

    def _calculate_ec2_statistics(self) -> Dict[str, Any]:
        """Calculate summary statistics across all instances."""
        total = len(self.raw_ec2_data)
        compliant = 0
        ebs_encrypted_count = 0
        ebs_total_count = 0
        imdsv2_count = 0

        for inst in self.raw_ec2_data:
            item = self.create_compliance_item(inst)
            if item.compliance_result == "PASS":
                compliant += 1

            for vol in inst.get("EbsVolumes", []):
                ebs_total_count += 1
                if vol.get("Encrypted", False):
                    ebs_encrypted_count += 1

            md = inst.get("MetadataOptions", {})
            if md.get("HttpTokens") == "required":
                imdsv2_count += 1

        return {
            "total": total,
            "compliant": compliant,
            "non_compliant": total - compliant,
            "compliant_pct": compliant / max(total, 1) * 100,
            "ebs_encrypted_pct": ebs_encrypted_count / max(ebs_total_count, 1) * 100,
            "imdsv2_pct": imdsv2_count / max(total, 1) * 100,
        }

    def _calculate_control_compliance_stats(self) -> Dict[str, Dict[str, int]]:
        """Calculate per-control pass/fail statistics."""
        stats = {cid: {"pass": 0, "fail": 0} for cid in self.control_mapper.get_mapped_controls()}
        for inst in self.raw_ec2_data:
            item = self.create_compliance_item(inst)
            for cid, result in item._compliance_results.items():
                if result == "PASS":
                    stats[cid]["pass"] += 1
                else:
                    stats[cid]["fail"] += 1
        return stats

    def _upload_evidence_file(self, evidence_id: int, scan_date: str) -> None:
        """
        Upload compressed JSONL evidence file to Evidence record.

        :param int evidence_id: Evidence record ID
        :param str scan_date: Scan timestamp
        """
        try:
            jsonl_content = "\n".join(self._build_evidence_jsonl(scan_date))

            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz:
                gz.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()
            file_name = f"ec2_evidence_{scan_date}.jsonl.gz"
            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=evidence_id,
                parent_module="evidence",
                api=api,
                file_data=compressed_data,
                tags="aws,ec2,compute,compliance",
            )

            if success:
                logger.info("Uploaded EC2 evidence file to Evidence %d", evidence_id)
            else:
                logger.warning("Failed to upload EC2 evidence file to Evidence %d", evidence_id)
        except Exception as e:
            logger.error("Error uploading EC2 evidence file: %s", e, exc_info=True)

    def _link_evidence_to_ssp(self, evidence_id: int) -> None:
        """
        Link evidence to Security Plan.

        :param int evidence_id: Evidence record ID
        """
        try:
            mapping = EvidenceMapping(
                evidenceID=evidence_id,
                mappedID=self.plan_id,
                mappingType=self.parent_module,
            )
            mapping.create()
            logger.info("Linked evidence %d to SSP %d", evidence_id, self.plan_id)
        except Exception as ex:
            logger.warning("Failed to link evidence to SSP: %s", ex)

    def _link_evidence_to_controls(self, evidence_id: int, is_attachment: bool = False) -> None:
        """
        Link evidence to specified control IDs.

        :param int evidence_id: Evidence or attachment ID
        :param bool is_attachment: True if linking attachment, False for evidence record
        """
        try:
            assert self.evidence_control_ids is not None, "evidence_control_ids must be set before linking"
            for cid in self.evidence_control_ids:
                if is_attachment:
                    self.api.link_ssp_attachment_to_control(self.plan_id, evidence_id, cid)
                else:
                    self.api.link_evidence_to_control(evidence_id, cid)
                logger.info("Linked evidence %d to control %s", evidence_id, cid)
        except Exception as e:
            logger.error("Failed to link evidence to controls: %s", e, exc_info=True)

    @staticmethod
    def _handle_client_error(error: ClientError, operation: str) -> None:
        """Log a boto3 ClientError at the appropriate level."""
        code = error.response.get("Error", {}).get("Code", "Unknown")
        if code in ("AccessDenied", "UnauthorizedAccess"):
            logger.warning("Access denied during %s: %s", operation, error)
        else:
            logger.error("AWS API error during %s: %s", operation, error)
