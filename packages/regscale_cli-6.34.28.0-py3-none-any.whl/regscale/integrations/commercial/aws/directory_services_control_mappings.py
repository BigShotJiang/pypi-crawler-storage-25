#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS Directory Services Control Mappings for RegScale Compliance Integration."""

import logging
from typing import Dict, List, Optional

logger = logging.getLogger("regscale")

# NIST 800-53 R5 Control Mappings for AWS Directory Services
DIRECTORY_SERVICES_CONTROL_MAPPINGS = {
    "AC-2": {
        "name": "Account Management",
        "description": "Manage system accounts, group memberships, privileges, and access authorizations",
        "checks": {
            "directory_type": {
                "weight": 100,
                "pass_criteria": "Directory supports centralized account management (MicrosoftAD or ADConnector)",
                "fail_criteria": "No active directory or SimpleAD only (limited account management)",
            },
            "user_management": {
                "weight": 90,
                "pass_criteria": "Directory type supports user provisioning and deprovisioning",
                "fail_criteria": "Directory type does not support full user lifecycle management",
            },
        },
    },
    "IA-2": {
        "name": "Identification and Authentication",
        "description": "Uniquely identify and authenticate organizational users",
        "checks": {
            "mfa_configured": {
                "weight": 100,
                "pass_criteria": "Multi-factor authentication configured via RADIUS",
                "fail_criteria": "No MFA or RADIUS configuration detected",
            },
            "authentication_method": {
                "weight": 90,
                "pass_criteria": "Strong authentication methods enabled through directory services",
                "fail_criteria": "Weak or missing authentication methods",
            },
        },
    },
    "IA-5": {
        "name": "Authenticator Management",
        "description": "Manage system authenticators by verifying identity and enforcing policies",
        "checks": {
            "password_policy": {
                "weight": 100,
                "pass_criteria": "Password policies enforced via active directory",
                "fail_criteria": "Directory not active or password policies not enforced",
            },
        },
    },
    "SC-8": {
        "name": "Transmission Confidentiality",
        "description": "Protect the confidentiality of transmitted information",
        "checks": {
            "ldaps_enabled": {
                "weight": 100,
                "pass_criteria": "LDAPS configured for encrypted directory communications",
                "fail_criteria": "No LDAPS configured for directory communications",
            },
            "client_ldaps": {
                "weight": 90,
                "pass_criteria": "Client-side LDAPS enabled for secure client connections",
                "fail_criteria": "Client-side LDAPS not enabled",
            },
        },
    },
}


class DirectoryServicesControlMapper:
    """Map AWS Directory Services configuration to compliance control status."""

    def __init__(self, framework: str = "NIST800-53R5"):
        """
        Initialize Directory Services control mapper.

        :param str framework: Compliance framework
        """
        self.framework = framework
        self.mappings = DIRECTORY_SERVICES_CONTROL_MAPPINGS

    def assess_directory_services_compliance(self, ds_data: Dict) -> Dict[str, str]:
        """
        Assess Directory Services compliance against all mapped controls.

        :param Dict ds_data: Directory Services data with Directories key
        :return: Dictionary mapping control IDs to compliance results (PASS/FAIL)
        :rtype: Dict[str, str]
        """
        results = {}

        if self.framework == "NIST800-53R5":
            results["AC-2"] = self._assess_ac2(ds_data)
            results["IA-2"] = self._assess_ia2(ds_data)
            results["IA-5"] = self._assess_ia5(ds_data)
            results["SC-8"] = self._assess_sc8(ds_data)

        return results

    def _assess_ac2(self, ds_data: Dict) -> str:
        """
        Assess AC-2 (Account Management) compliance.

        PASS if any active MicrosoftAD or ADConnector directory exists.

        :param Dict ds_data: Directory Services data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        directories = ds_data.get("Directories", [])

        if not directories:
            logger.debug("Directory Services FAILS AC-2: No directories configured")
            return "FAIL"

        active_managed = [
            d for d in directories if d.get("Stage") == "Active" and d.get("Type") in ("MicrosoftAD", "ADConnector")
        ]

        if active_managed:
            logger.debug(
                "Directory Services PASSES AC-2: %d active MicrosoftAD/ADConnector directory(ies) found",
                len(active_managed),
            )
            return "PASS"

        logger.debug("Directory Services FAILS AC-2: No active MicrosoftAD or ADConnector directories")
        return "FAIL"

    def _assess_ia2(self, ds_data: Dict) -> str:
        """
        Assess IA-2 (Identification and Authentication) compliance.

        PASS if any directory has RADIUS MFA configured.

        :param Dict ds_data: Directory Services data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        directories = ds_data.get("Directories", [])

        if not directories:
            logger.debug("Directory Services FAILS IA-2: No directories configured")
            return "FAIL"

        mfa_configured = [d for d in directories if d.get("RadiusSettings")]

        if mfa_configured:
            logger.debug(
                "Directory Services PASSES IA-2: %d directory(ies) with RADIUS MFA configured",
                len(mfa_configured),
            )
            return "PASS"

        logger.debug("Directory Services FAILS IA-2: No directories with RADIUS MFA configured")
        return "FAIL"

    def _assess_ia5(self, ds_data: Dict) -> str:
        """
        Assess IA-5 (Authenticator Management) compliance.

        PASS if any directory is in Active stage (password policies enforced).

        :param Dict ds_data: Directory Services data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        directories = ds_data.get("Directories", [])

        if not directories:
            logger.debug("Directory Services FAILS IA-5: No directories configured")
            return "FAIL"

        active_dirs = [d for d in directories if d.get("Stage") == "Active"]

        if active_dirs:
            logger.debug(
                "Directory Services PASSES IA-5: %d active directory(ies) with enforced policies",
                len(active_dirs),
            )
            return "PASS"

        logger.debug("Directory Services FAILS IA-5: No active directories with enforced policies")
        return "FAIL"

    def _assess_sc8(self, ds_data: Dict) -> str:
        """
        Assess SC-8 (Transmission Confidentiality) compliance.

        PASS if any active MicrosoftAD directory exists (LDAPS available).

        :param Dict ds_data: Directory Services data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        directories = ds_data.get("Directories", [])

        if not directories:
            logger.debug("Directory Services FAILS SC-8: No directories configured")
            return "FAIL"

        ldaps_capable = [d for d in directories if d.get("Type") == "MicrosoftAD" and d.get("Stage") == "Active"]

        if ldaps_capable:
            logger.debug(
                "Directory Services PASSES SC-8: %d active MicrosoftAD directory(ies) with LDAPS capability",
                len(ldaps_capable),
            )
            return "PASS"

        logger.debug("Directory Services FAILS SC-8: No active MicrosoftAD directories with LDAPS capability")
        return "FAIL"

    def get_control_description(self, control_id: str) -> Optional[str]:
        """Get human-readable description for a control."""
        control_data = self.mappings.get(control_id)
        if control_data:
            return f"{control_data.get('name')}: {control_data.get('description', '')}"
        return None

    def get_mapped_controls(self) -> List[str]:
        """Get list of all control IDs mapped for this framework."""
        return list(self.mappings.keys())

    def get_check_details(self, control_id: str) -> Optional[Dict]:
        """Get detailed check criteria for a control."""
        control_data = self.mappings.get(control_id)
        if control_data:
            return control_data.get("checks", {})
        return None
