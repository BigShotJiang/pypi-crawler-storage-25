"""AWS resource collectors package."""

from .compute import ComputeCollector
from .containers import ContainerCollector
from .database import DatabaseCollector
from .directory_services import DirectoryServicesCollector
from .integration import IntegrationCollector
from .networking import NetworkingCollector
from .security import SecurityCollector
from .storage import StorageCollector

__all__ = [
    "ComputeCollector",
    "StorageCollector",
    "DatabaseCollector",
    "NetworkingCollector",
    "SecurityCollector",
    "IntegrationCollector",
    "ContainerCollector",
    "DirectoryServicesCollector",
]
