"""AWS Directory Services resource collectors."""

import logging
from typing import Any, Dict, List, Optional

from ..base import BaseCollector

logger = logging.getLogger("regscale")


class DirectoryServicesCollector(BaseCollector):
    """Collector for AWS Directory Services resources with filtering support."""

    def __init__(
        self,
        session: Any,
        region: str,
        account_id: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        enabled_services: Optional[Dict[str, bool]] = None,
    ):
        """
        Initialize Directory Services collector with filtering support.

        :param session: AWS session to use for API calls
        :param str region: AWS region to collect from
        :param str account_id: Optional AWS account ID to filter resources
        :param dict tags: Optional tag filters (AND logic)
        :param dict enabled_services: Optional dict of service names to boolean flags for enabling/disabling collection
        """
        super().__init__(session, region, account_id, tags)
        self.enabled_services = enabled_services or {}

    def _should_include_directory(self, ds: Any, directory: Dict[str, Any]) -> bool:
        """
        Check if directory should be included based on account and tag filters.

        :param ds: Directory Service client
        :param dict directory: Directory data
        :return: True if directory should be included, False otherwise
        :rtype: bool
        """
        # Filter by account using OwnerAccount field
        owner_account = directory.get("OwnerId", "")
        if self.account_id and owner_account and owner_account != self.account_id:
            logger.debug(
                "Filtering out directory %s - account %s != %s",
                directory.get("DirectoryId"),
                owner_account,
                self.account_id,
            )
            return False

        # Filter by tags
        if self.tags:
            try:
                directory_id = directory.get("DirectoryId", "")
                tags_response = ds.list_tags_for_resource(ResourceId=directory_id)
                dir_tags = tags_response.get("Tags", [])
                return self._matches_tags(dir_tags)
            except Exception:
                return False

        return True

    def get_directories(self) -> List[Dict[str, Any]]:
        """
        Get information about AWS Directory Service directories with filtering.

        :return: List of directory information
        :rtype: List[Dict[str, Any]]
        """
        directories = []
        try:
            ds = self._get_client("ds")
            next_token = None

            while True:
                kwargs: Dict[str, Any] = {}
                if next_token:
                    kwargs["NextToken"] = next_token

                response = ds.describe_directories(**kwargs)

                for directory in response.get("DirectoryDescriptions", []):
                    try:
                        if not self._should_include_directory(ds, directory):
                            continue

                        directories.append(
                            {
                                "Region": self.region,
                                "DirectoryId": directory.get("DirectoryId"),
                                "Name": directory.get("Name"),
                                "ShortName": directory.get("ShortName"),
                                "Type": directory.get("Type"),
                                "Size": directory.get("Size"),
                                "Edition": directory.get("Edition"),
                                "AccessUrl": directory.get("AccessUrl"),
                                "DnsIpAddrs": directory.get("DnsIpAddrs", []),
                                "VpcSettings": directory.get("VpcSettings", {}),
                                "ConnectSettings": directory.get("ConnectSettings", {}),
                                "Stage": directory.get("Stage"),
                                "LaunchTime": str(directory.get("LaunchTime")),
                                "ShareStatus": directory.get("ShareStatus"),
                            }
                        )
                    except Exception as e:
                        self._handle_error(e, "Directory %s" % directory.get("DirectoryId", "unknown"))

                next_token = response.get("NextToken")
                if not next_token:
                    break

        except Exception as e:
            self._handle_error(e, "Directory Services")
        return directories

    def collect(self) -> Dict[str, Any]:
        """
        Collect Directory Services resources based on enabled_services configuration.

        :return: Dictionary containing enabled Directory Services resource information
        :rtype: Dict[str, Any]
        """
        result = {}

        if self.enabled_services.get("directories", True):
            result["Directories"] = self.get_directories()

        return result
