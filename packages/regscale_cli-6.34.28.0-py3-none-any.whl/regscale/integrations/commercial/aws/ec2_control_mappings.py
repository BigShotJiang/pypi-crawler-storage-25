#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS EC2 Control Mappings for RegScale Compliance Integration."""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("regscale")

# NIST 800-53 R5 Control Mappings for AWS EC2
EC2_CONTROL_MAPPINGS = {
    "SC-13": {
        "name": "Cryptographic Protection",
        "description": "Implement cryptographic mechanisms to prevent unauthorized disclosure of CUI during transmission and at rest",
        "checks": {
            "ebs_encryption": {
                "weight": 100,
                "pass_criteria": "All EBS volumes attached to the instance are encrypted",
                "fail_criteria": "One or more EBS volumes attached to the instance are not encrypted",
            },
        },
    },
    "SC-28": {
        "name": "Protection of Information at Rest",
        "description": "Protect the confidentiality and integrity of information at rest",
        "checks": {
            "ebs_encryption_coverage": {
                "weight": 100,
                "pass_criteria": "All EBS volumes use encryption with a customer-managed or AWS-managed KMS key",
                "fail_criteria": "One or more EBS volumes lack encryption or use a non-KMS mechanism",
            },
            "ebs_encryption_key_type": {
                "weight": 60,
                "pass_criteria": "EBS volumes use a customer-managed KMS key (CMK)",
                "fail_criteria": "EBS volumes use only the default AWS-managed key",
            },
        },
    },
    "AC-4": {
        "name": "Information Flow Enforcement",
        "description": "Enforce approved authorizations for controlling the flow of information within the system and between connected systems",
        "checks": {
            "sg_no_unrestricted_inbound": {
                "weight": 100,
                "pass_criteria": "No security group rules allow unrestricted inbound access (0.0.0.0/0 or ::/0) on sensitive ports",
                "fail_criteria": "Security group rules allow unrestricted inbound access from 0.0.0.0/0 or ::/0",
            },
        },
    },
    "SC-7": {
        "name": "Boundary Protection",
        "description": "Monitor and control communications at the external managed interfaces to the system and at key internal boundaries within the system",
        "checks": {
            "sg_no_unrestricted_outbound": {
                "weight": 80,
                "pass_criteria": "Outbound security group rules are scoped to required destinations",
                "fail_criteria": "Security group rules allow unrestricted outbound access to 0.0.0.0/0 on all ports",
            },
            "no_public_ip": {
                "weight": 90,
                "pass_criteria": "Instance does not have a public IP address assigned",
                "fail_criteria": "Instance has a public IP address exposing it to the internet",
            },
        },
    },
    "IA-3": {
        "name": "Device Identification and Authentication",
        "description": "Uniquely identify and authenticate devices before establishing a connection",
        "checks": {
            "imdsv2_enforced": {
                "weight": 100,
                "pass_criteria": "Instance Metadata Service v2 (IMDSv2) is enforced (HttpTokens = required)",
                "fail_criteria": "IMDSv1 is still allowed (HttpTokens = optional), exposing SSRF risk",
            },
        },
    },
    "CM-6": {
        "name": "Configuration Settings",
        "description": "Establish and document configuration settings for systems",
        "checks": {
            "imdsv2_enforcement": {
                "weight": 100,
                "pass_criteria": "IMDSv2 is required per organizational configuration baseline",
                "fail_criteria": "IMDSv2 is not enforced, deviating from configuration baseline",
            },
        },
    },
    "AC-3": {
        "name": "Access Enforcement",
        "description": "Enforce approved authorizations for logical access to information and system resources",
        "checks": {
            "no_public_ami": {
                "weight": 90,
                "pass_criteria": "Instance AMI is not publicly shared",
                "fail_criteria": "Instance is running a publicly shared AMI",
            },
            "no_public_snapshots": {
                "weight": 90,
                "pass_criteria": "No EBS snapshots associated with the instance are publicly shared",
                "fail_criteria": "EBS snapshots from this instance are publicly accessible",
            },
            "iam_profile_attached": {
                "weight": 80,
                "pass_criteria": "Instance has an IAM instance profile attached for role-based access",
                "fail_criteria": "No IAM instance profile attached; instance cannot assume a role",
            },
        },
    },
    "AC-6": {
        "name": "Least Privilege",
        "description": "Employ the principle of least privilege, allowing only authorized accesses for users and processes",
        "checks": {
            "iam_role_policy_scope": {
                "weight": 100,
                "pass_criteria": "IAM role attached via instance profile has bounded policy count and no overly permissive policies",
                "fail_criteria": "IAM role has excessive managed policies or inline policies with Action: '*'",
            },
        },
    },
    "AU-2": {
        "name": "Event Logging",
        "description": "Identify the types of events that the system is capable of logging in support of the audit function",
        "checks": {
            "vpc_flow_logs_enabled": {
                "weight": 100,
                "pass_criteria": "VPC flow logs are enabled for the VPC associated with this instance",
                "fail_criteria": "VPC flow logs are not enabled for the instance VPC",
            },
        },
    },
    "AU-12": {
        "name": "Audit Record Generation",
        "description": "Provide audit record generation capability for the events identified in AU-2",
        "checks": {
            "flow_logs_active": {
                "weight": 100,
                "pass_criteria": "VPC flow logs are in ACTIVE status and delivering records",
                "fail_criteria": "VPC flow logs are not active or are in an error state",
            },
        },
    },
    "SI-4": {
        "name": "System Monitoring",
        "description": "Monitor the system to detect attacks, indicators of potential attacks, and unauthorized connections",
        "checks": {
            "flow_logs_monitoring": {
                "weight": 100,
                "pass_criteria": "VPC flow logs are configured and available for network monitoring",
                "fail_criteria": "No VPC flow logs available for network traffic monitoring",
            },
        },
    },
    "IA-5": {
        "name": "Authenticator Management",
        "description": "Manage system authenticators by verifying identity and protecting authenticators",
        "checks": {
            "key_pair_assigned": {
                "weight": 80,
                "pass_criteria": "Instance has a key pair assigned for SSH authentication",
                "fail_criteria": "Instance has no key pair assigned",
            },
        },
    },
}

SENSITIVE_PORTS = [22, 3389, 3306, 5432, 1433, 1521, 6379, 27017, 9200, 8080, 8443]

MAX_MANAGED_POLICIES_PER_ROLE = 10


class EC2ControlMapper:
    """Map AWS EC2 instance attributes to compliance control status."""

    def __init__(self, framework: str = "NIST800-53R5"):
        """
        Initialize EC2 control mapper.

        :param str framework: Compliance framework (NIST800-53R5)
        """
        self.framework = framework
        self.mappings = EC2_CONTROL_MAPPINGS

    def assess_instance_compliance(self, instance_data: Dict[str, Any]) -> Dict[str, str]:
        """
        Assess EC2 instance compliance against all mapped controls.

        :param Dict[str, Any] instance_data: Enriched EC2 instance data
        :return: Dictionary mapping control IDs to compliance results (PASS/FAIL)
        :rtype: Dict[str, str]
        """
        results = {}

        if self.framework == "NIST800-53R5":
            results["SC-13"] = self._assess_sc13(instance_data)
            results["SC-28"] = self._assess_sc28(instance_data)
            results["AC-4"] = self._assess_ac4(instance_data)
            results["SC-7"] = self._assess_sc7(instance_data)
            results["IA-3"] = self._assess_ia3(instance_data)
            results["CM-6"] = self._assess_cm6(instance_data)
            results["AC-3"] = self._assess_ac3(instance_data)
            results["AC-6"] = self._assess_ac6(instance_data)
            results["AU-2"] = self._assess_au2(instance_data)
            results["AU-12"] = self._assess_au12(instance_data)
            results["SI-4"] = self._assess_si4(instance_data)
            results["IA-5"] = self._assess_ia5(instance_data)

        return results

    def _assess_sc13(self, data: Dict[str, Any]) -> str:
        """
        Assess SC-13 (Cryptographic Protection) -- EBS volume encryption.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        volumes = data.get("EbsVolumes", [])

        if not volumes:
            logger.debug("Instance %s has no EBS volumes attached, auto-passing SC-13", instance_id)
            return "PASS"

        unencrypted = [v for v in volumes if not v.get("Encrypted", False)]
        if unencrypted:
            logger.debug(
                "Instance %s FAILS SC-13: %d/%d EBS volumes unencrypted",
                instance_id,
                len(unencrypted),
                len(volumes),
            )
            return "FAIL"

        logger.debug("Instance %s PASSES SC-13: all %d EBS volumes encrypted", instance_id, len(volumes))
        return "PASS"

    def _assess_sc28(self, data: Dict[str, Any]) -> str:
        """
        Assess SC-28 (Protection of Information at Rest) -- EBS encryption coverage and key type.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        volumes = data.get("EbsVolumes", [])

        if not volumes:
            logger.debug("Instance %s has no EBS volumes, auto-passing SC-28", instance_id)
            return "PASS"

        for vol in volumes:
            if not vol.get("Encrypted", False):
                logger.debug("Instance %s FAILS SC-28: volume %s not encrypted", instance_id, vol.get("VolumeId"))
                return "FAIL"

        logger.debug("Instance %s PASSES SC-28: all volumes encrypted", instance_id)
        return "PASS"

    def _assess_ac4(self, data: Dict[str, Any]) -> str:
        """
        Assess AC-4 (Information Flow Enforcement) -- unrestricted inbound security group rules.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        security_groups = data.get("SecurityGroupDetails", [])

        for sg in security_groups:
            for rule in sg.get("IpPermissions", []):
                if self._is_unrestricted_inbound_on_sensitive_port(rule):
                    logger.debug(
                        "Instance %s FAILS AC-4: SG %s allows unrestricted inbound on sensitive port",
                        instance_id,
                        sg.get("GroupId"),
                    )
                    return "FAIL"

        logger.debug("Instance %s PASSES AC-4: no unrestricted inbound on sensitive ports", instance_id)
        return "PASS"

    def _assess_sc7(self, data: Dict[str, Any]) -> str:
        """
        Assess SC-7 (Boundary Protection) -- unrestricted outbound rules and public IP.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")

        if data.get("PublicIpAddress"):
            logger.debug("Instance %s FAILS SC-7: has public IP %s", instance_id, data["PublicIpAddress"])
            return "FAIL"

        security_groups = data.get("SecurityGroupDetails", [])
        for sg in security_groups:
            for rule in sg.get("IpPermissionsEgress", []):
                if self._is_unrestricted_egress_all_ports(rule):
                    logger.debug(
                        "Instance %s FAILS SC-7: SG %s allows unrestricted outbound on all ports",
                        instance_id,
                        sg.get("GroupId"),
                    )
                    return "FAIL"

        logger.debug("Instance %s PASSES SC-7: no public IP and outbound rules are scoped", instance_id)
        return "PASS"

    def _assess_ia3(self, data: Dict[str, Any]) -> str:
        """
        Assess IA-3 (Device Identification and Authentication) -- IMDSv2 enforcement.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        metadata_options = data.get("MetadataOptions", {})
        http_tokens = metadata_options.get("HttpTokens", "optional")

        if http_tokens != "required":
            logger.debug("Instance %s FAILS IA-3: IMDSv2 not enforced (HttpTokens=%s)", instance_id, http_tokens)
            return "FAIL"

        logger.debug("Instance %s PASSES IA-3: IMDSv2 enforced", instance_id)
        return "PASS"

    def _assess_cm6(self, data: Dict[str, Any]) -> str:
        """
        Assess CM-6 (Configuration Settings) -- IMDSv2 enforcement only.

        Scoped to IMDS configuration; patch management and baseline configs are SSM's domain.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        metadata_options = data.get("MetadataOptions", {})
        http_tokens = metadata_options.get("HttpTokens", "optional")

        if http_tokens != "required":
            logger.debug("Instance %s FAILS CM-6: IMDSv2 not required", instance_id)
            return "FAIL"

        logger.debug("Instance %s PASSES CM-6: IMDSv2 required per configuration baseline", instance_id)
        return "PASS"

    def _assess_ac3(self, data: Dict[str, Any]) -> str:
        """
        Assess AC-3 (Access Enforcement) -- public AMIs, public snapshots, IAM profile.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")

        if data.get("IsPublicAmi", False):
            logger.debug("Instance %s FAILS AC-3: running a publicly shared AMI", instance_id)
            return "FAIL"

        public_snapshots = data.get("PublicSnapshots", [])
        if public_snapshots:
            logger.debug(
                "Instance %s FAILS AC-3: %d public EBS snapshots found",
                instance_id,
                len(public_snapshots),
            )
            return "FAIL"

        iam_profile = data.get("IamInstanceProfile")
        if not iam_profile:
            logger.debug("Instance %s FAILS AC-3: no IAM instance profile attached", instance_id)
            return "FAIL"

        logger.debug("Instance %s PASSES AC-3: private AMI, no public snapshots, IAM profile attached", instance_id)
        return "PASS"

    def _assess_ac6(self, data: Dict[str, Any]) -> str:
        """
        Assess AC-6 (Least Privilege) -- IAM instance profile role scope.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        role_info = data.get("IamRoleDetails", {})

        if not role_info:
            if not data.get("IamInstanceProfile"):
                logger.debug("Instance %s FAILS AC-6: no IAM instance profile attached", instance_id)
                return "FAIL"
            logger.debug("Instance %s PASSES AC-6: no role details available to assess", instance_id)
            return "PASS"

        managed_policy_count = role_info.get("ManagedPolicyCount", 0)
        if managed_policy_count > MAX_MANAGED_POLICIES_PER_ROLE:
            logger.debug(
                "Instance %s FAILS AC-6: role has %d managed policies (max %d)",
                instance_id,
                managed_policy_count,
                MAX_MANAGED_POLICIES_PER_ROLE,
            )
            return "FAIL"

        if role_info.get("HasWildcardPolicy", False):
            logger.debug("Instance %s FAILS AC-6: role has inline policy with Action: '*'", instance_id)
            return "FAIL"

        logger.debug("Instance %s PASSES AC-6: role policies are bounded and scoped", instance_id)
        return "PASS"

    def _assess_au2(self, data: Dict[str, Any]) -> str:
        """
        Assess AU-2 (Event Logging) -- VPC flow logs enabled.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        flow_logs = data.get("VpcFlowLogs", [])

        if not flow_logs:
            logger.debug("Instance %s FAILS AU-2: no VPC flow logs enabled", instance_id)
            return "FAIL"

        logger.debug("Instance %s PASSES AU-2: VPC flow logs enabled (%d found)", instance_id, len(flow_logs))
        return "PASS"

    def _assess_au12(self, data: Dict[str, Any]) -> str:
        """
        Assess AU-12 (Audit Record Generation) -- VPC flow logs active.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        flow_logs = data.get("VpcFlowLogs", [])

        if not flow_logs:
            logger.debug("Instance %s FAILS AU-12: no VPC flow logs found", instance_id)
            return "FAIL"

        active_logs = [fl for fl in flow_logs if fl.get("FlowLogStatus") == "ACTIVE"]
        if not active_logs:
            logger.debug("Instance %s FAILS AU-12: no ACTIVE flow logs", instance_id)
            return "FAIL"

        logger.debug("Instance %s PASSES AU-12: %d active flow logs", instance_id, len(active_logs))
        return "PASS"

    def _assess_si4(self, data: Dict[str, Any]) -> str:
        """
        Assess SI-4 (System Monitoring) -- VPC flow logs as monitoring evidence.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        flow_logs = data.get("VpcFlowLogs", [])

        if not flow_logs:
            logger.debug("Instance %s FAILS SI-4: no flow logs for monitoring", instance_id)
            return "FAIL"

        active_logs = [fl for fl in flow_logs if fl.get("FlowLogStatus") == "ACTIVE"]
        if not active_logs:
            logger.debug("Instance %s FAILS SI-4: flow logs not active for monitoring", instance_id)
            return "FAIL"

        logger.debug("Instance %s PASSES SI-4: flow logs available for monitoring", instance_id)
        return "PASS"

    def _assess_ia5(self, data: Dict[str, Any]) -> str:
        """
        Assess IA-5 (Authenticator Management) -- key pair usage.

        :param Dict[str, Any] data: Enriched instance data
        :return: PASS/FAIL
        :rtype: str
        """
        instance_id = data.get("InstanceId", "unknown")
        key_name = data.get("KeyName")

        if not key_name:
            logger.debug("Instance %s FAILS IA-5: no key pair assigned", instance_id)
            return "FAIL"

        logger.debug("Instance %s PASSES IA-5: key pair '%s' assigned", instance_id, key_name)
        return "PASS"

    @staticmethod
    def _is_unrestricted_inbound_on_sensitive_port(rule: Dict[str, Any]) -> bool:
        """
        Check if a security group inbound rule allows unrestricted access on sensitive ports.

        :param Dict[str, Any] rule: Security group IpPermissions entry
        :return: True if unrestricted on a sensitive port
        :rtype: bool
        """
        from_port = rule.get("FromPort", 0)
        to_port = rule.get("ToPort", 65535)
        ip_protocol = rule.get("IpProtocol", "")

        if ip_protocol == "-1":
            from_port, to_port = 0, 65535

        has_open_cidr = any(r.get("CidrIp") == "0.0.0.0/0" for r in rule.get("IpRanges", []))
        has_open_ipv6 = any(r.get("CidrIpv6") == "::/0" for r in rule.get("Ipv6Ranges", []))

        if not (has_open_cidr or has_open_ipv6):
            return False

        if ip_protocol == "-1":
            return True

        for port in SENSITIVE_PORTS:
            if from_port <= port <= to_port:
                return True

        return False

    @staticmethod
    def _is_unrestricted_egress_all_ports(rule: Dict[str, Any]) -> bool:
        """
        Check if an egress rule allows all traffic to 0.0.0.0/0 on all ports.

        :param Dict[str, Any] rule: Security group IpPermissionsEgress entry
        :return: True if fully open egress
        :rtype: bool
        """
        ip_protocol = rule.get("IpProtocol", "")

        if ip_protocol != "-1":
            return False

        has_open_cidr = any(r.get("CidrIp") == "0.0.0.0/0" for r in rule.get("IpRanges", []))
        has_open_ipv6 = any(r.get("CidrIpv6") == "::/0" for r in rule.get("Ipv6Ranges", []))

        return has_open_cidr or has_open_ipv6

    def get_control_description(self, control_id: str) -> Optional[str]:
        """
        Get human-readable description for a control.

        :param str control_id: Control identifier (e.g., SC-13)
        :return: Control description or None
        :rtype: Optional[str]
        """
        control_data = self.mappings.get(control_id)
        if control_data:
            return f"{control_data.get('name')}: {control_data.get('description', '')}"
        return None

    def get_mapped_controls(self) -> List[str]:
        """
        Get list of all control IDs mapped for this framework.

        :return: List of control IDs
        :rtype: List[str]
        """
        return list(self.mappings.keys())

    def get_check_details(self, control_id: str) -> Optional[Dict]:
        """
        Get detailed check criteria for a control.

        :param str control_id: Control identifier
        :return: Dictionary of check details or None
        :rtype: Optional[Dict]
        """
        control_data = self.mappings.get(control_id)
        if control_data:
            return control_data.get("checks", {})
        return None
