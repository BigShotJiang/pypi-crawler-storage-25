"""Centralized boto3 client factory for AWS integrations.

Every ``session.client(...)`` construction in the AWS integration code should
go through :func:`make_aws_client`. The factory creates the client via the
caller-supplied ``boto3.Session`` and then installs a ``before-send`` hook
that merges ``X-Mock-*`` headers into outbound requests when
``mockServicesConfig.aws`` is present in ``init.yaml``. In production (no
mock config) the hook is a no-op.

Note: the signature diverges from the generic example in the REG-21784 spec
(``make_aws_client(service, **kwargs)`` calling ``boto3.client(...)``). The
AWS integration code exclusively uses session-based client construction
(``session.client(...)``), so the factory takes the session as its first
argument to preserve the credential/region resolution already encoded in
those sessions.
"""

from typing import Any

from regscale.core.app.utils.mock_service_headers_boto3 import apply_mock_headers_to_boto3_client

_AWS_SERVICE_KEY = "aws"


def make_aws_client(session: Any, service_name: str, **kwargs: Any) -> Any:
    """Create a boto3 service client from *session* with mock headers applied.

    :param session: A ``boto3.Session`` (real or mock) used to build the client.
    :param str service_name: AWS service name (e.g. ``"s3"``, ``"ec2"``).
    :param kwargs: Additional keyword arguments forwarded to ``session.client``
        (e.g. ``region_name``).
    :return: The constructed boto3 client with the mock-header hook registered.
    :rtype: Any
    """
    client = session.client(service_name, **kwargs)
    apply_mock_headers_to_boto3_client(client, _AWS_SERVICE_KEY)
    return client
