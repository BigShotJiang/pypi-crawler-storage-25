#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS Inspector V2 Evidence Integration for RegScale CLI."""

import gzip
import json
import logging
import os
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from io import BytesIO
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

from regscale.core.app.api import Api
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.commercial.aws._client_factory import make_aws_client
from regscale.integrations.commercial.aws.inspector_control_mappings import (
    InspectorControlMapper,
)
from regscale.integrations.compliance_integration import (
    ComplianceIntegration,
    ComplianceItem,
)
from regscale.integrations.scanner_integration import IntegrationAsset, IntegrationFinding
from regscale.models import regscale_models
from regscale.models.regscale_models.evidence import Evidence
from regscale.models.regscale_models.evidence_mapping import EvidenceMapping
from regscale.models.regscale_models.file import File

logger = logging.getLogger("regscale")

INSPECTOR_CACHE_FILE = os.path.join("artifacts", "aws", "inspector_data.json")
CACHE_TTL_SECONDS = 4 * 60 * 60

HTML_STRONG_OPEN = "<strong>"
HTML_STRONG_CLOSE = "</strong>"
HTML_P_OPEN = "<p>"
HTML_P_CLOSE = "</p>"
HTML_UL_OPEN = "<ul>"
HTML_UL_CLOSE = "</ul>"
HTML_LI_OPEN = "<li>"
HTML_LI_CLOSE = "</li>"
HTML_H2_OPEN = "<h2>"
HTML_H2_CLOSE = "</h2>"
HTML_H3_OPEN = "<h3>"
HTML_H3_CLOSE = "</h3>"
HTML_BR = "<br>"


@dataclass
class InspectorEvidenceConfig:
    """Configuration for AWS Inspector V2 evidence collection."""

    plan_id: int
    region: str = "us-east-1"
    framework: str = "NIST800-53R5"
    create_issues: bool = True
    create_vulnerabilities: bool = True
    update_control_status: bool = True
    create_poams: bool = False
    parent_module: str = "securityplans"
    collect_evidence: bool = False
    evidence_as_attachments: bool = False
    evidence_control_ids: Optional[List[str]] = None
    evidence_frequency: int = 30
    force_refresh: bool = False
    account_id: Optional[str] = None
    tags: Optional[Dict[str, str]] = None
    profile: Optional[str] = None
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None
    # When None, InspectorCollector applies its own defaults (active Critical/High/Medium).
    severities: Optional[List[str]] = None
    finding_statuses: Optional[List[str]] = None


class InspectorComplianceItem(ComplianceItem):
    """
    Compliance item representing an Inspector V2 assessment for a specific control.

    Maps Inspector findings and coverage data to compliance control requirements.
    """

    def __init__(
        self,
        control_id: str,
        inspector_data: Dict[str, Any],
        control_mapper: InspectorControlMapper,
    ):
        """
        Initialize Inspector compliance item.

        :param str control_id: The control ID being assessed (e.g., 'RA-5', 'SI-2')
        :param Dict[str, Any] inspector_data: Complete Inspector data including findings and coverage
        :param InspectorControlMapper control_mapper: Control mapper for compliance assessment
        """
        self._control_id = control_id
        self.inspector_data = inspector_data
        self.control_mapper = control_mapper

        # Assess compliance for this specific control
        all_results = control_mapper.assess_inspector_compliance(inspector_data)
        self._compliance_result = all_results.get(control_id, "PASS")

        # Extract finding and coverage statistics
        self.findings = inspector_data.get("Findings", [])
        self.coverage = inspector_data.get("Coverage", [])

        # Count findings by severity
        self.critical_findings = self._count_findings_by_severity("CRITICAL")
        self.high_findings = self._count_findings_by_severity("HIGH")
        self.medium_findings = self._count_findings_by_severity("MEDIUM")
        self.low_findings = self._count_findings_by_severity("LOW")

        # Get the account ID from account status if available
        self._account_id = self._extract_account_id()

    def _count_findings_by_severity(self, severity: str) -> int:
        """Count findings matching the specified severity level."""
        count = 0
        for finding in self.findings:
            if finding.get("severity", "").upper() == severity:
                count += 1
        return count

    def _extract_account_id(self) -> str:
        """Extract AWS account ID from Inspector data."""
        account_status = self.inspector_data.get("AccountStatus", {})
        if isinstance(account_status, dict):
            account_id = account_status.get("accountId", "")
            if account_id:
                return account_id

        if self.findings:
            finding = self.findings[0]
            if isinstance(finding, dict):
                return finding.get("awsAccountId", "")

        return ""

    @property
    def resource_id(self) -> str:
        """Unique identifier for the Inspector service in this account/region."""
        if self._account_id:
            return f"inspector-{self._account_id}"
        return "inspector-service"

    @property
    def resource_name(self) -> str:
        """Human-readable name of the Inspector service."""
        if self._account_id:
            return f"AWS Inspector V2 - Account {self._account_id}"
        return "AWS Inspector V2 Service"

    @property
    def control_id(self) -> str:
        """Control identifier (e.g., RA-5, SI-2)."""
        return self._control_id

    @property
    def compliance_result(self) -> str:
        """Result of compliance check (PASS, FAIL)."""
        return self._compliance_result

    @property
    def severity(self) -> Optional[str]:
        """Severity level based on the control and findings."""
        if self.compliance_result == "PASS":
            return None

        if self._control_id == "SI-2":
            if self.critical_findings > 0:
                return "CRITICAL"
            elif self.high_findings > 0:
                return "HIGH"
            else:
                return "MEDIUM"
        elif self._control_id == "RA-5":
            return "HIGH"
        elif self._control_id in ("CM-6", "SA-11"):
            return "MEDIUM"

        return "MEDIUM"

    @property
    def description(self) -> str:
        """Detailed description of the Inspector compliance assessment."""
        desc_parts = self._build_assessment_header()
        desc_parts.extend(self._build_coverage_summary())
        desc_parts.extend(self._build_findings_summary())
        desc_parts.extend(self._build_control_assessment())

        if self.compliance_result == "FAIL":
            desc_parts.extend(self._build_remediation_guidance())

        return "".join(desc_parts)

    def _build_assessment_header(self) -> List[str]:
        """Build the assessment header section."""
        control_desc = self.control_mapper.get_control_description(self._control_id)
        return [
            f"{HTML_H3_OPEN}Inspector V2 Compliance Assessment{HTML_H3_CLOSE}",
            HTML_P_OPEN,
            f"{HTML_STRONG_OPEN}Control:{HTML_STRONG_CLOSE} {self._control_id} - {control_desc}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Result:{HTML_STRONG_CLOSE} {self._compliance_result}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Account:{HTML_STRONG_CLOSE} {self._account_id or 'N/A'}",
            HTML_P_CLOSE,
        ]

    def _build_coverage_summary(self) -> List[str]:
        """Build coverage status summary."""
        active_count = sum(1 for r in self.coverage if r.get("scanStatus", {}).get("statusCode") == "ACTIVE")
        inactive_count = len(self.coverage) - active_count

        return [
            f"{HTML_H3_OPEN}Coverage Status{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
            f"{HTML_LI_OPEN}Total Resources: {len(self.coverage)}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}Actively Scanned: {active_count}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}Not Scanned: {inactive_count}{HTML_LI_CLOSE}",
            HTML_UL_CLOSE,
        ]

    def _build_findings_summary(self) -> List[str]:
        """Build findings summary."""
        total_findings = len(self.findings)

        return [
            f"{HTML_H3_OPEN}Findings Summary{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
            f"{HTML_LI_OPEN}Total Findings: {total_findings}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}Critical: {self.critical_findings}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}High: {self.high_findings}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}Medium: {self.medium_findings}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}Low: {self.low_findings}{HTML_LI_CLOSE}",
            HTML_UL_CLOSE,
        ]

    def _build_control_assessment(self) -> List[str]:
        """Build control-specific assessment details."""
        control_mapping = self.control_mapper.mappings.get(self._control_id, {})
        checks = control_mapping.get("checks", {})

        section_parts = [
            f"{HTML_H3_OPEN}Control Assessment Details{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
        ]

        for _check_name, check_info in checks.items():
            if self.compliance_result == "PASS":
                criteria = check_info.get("pass_criteria", "")
            else:
                criteria = check_info.get("fail_criteria", "")
            section_parts.append(f"{HTML_LI_OPEN}{criteria}{HTML_LI_CLOSE}")

        section_parts.append(HTML_UL_CLOSE)
        return section_parts

    def _build_remediation_guidance(self) -> List[str]:
        """Build remediation guidance for failed controls."""
        section_parts = [
            f"{HTML_H3_OPEN}Remediation Guidance{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
        ]

        if self._control_id == "RA-5":
            section_parts.append(
                f"{HTML_LI_OPEN}Enable AWS Inspector V2 for all eligible resource types{HTML_LI_CLOSE}"
            )
            section_parts.append(
                f"{HTML_LI_OPEN}Ensure scanning coverage includes all accounts and regions{HTML_LI_CLOSE}"
            )
        elif self._control_id == "SI-2":
            section_parts.append(
                f"{HTML_LI_OPEN}Remediate all critical and high severity vulnerabilities{HTML_LI_CLOSE}"
            )
            section_parts.append(
                f"{HTML_LI_OPEN}Follow Inspector remediation recommendations for each finding{HTML_LI_CLOSE}"
            )
        elif self._control_id == "CM-6":
            section_parts.append(
                f"{HTML_LI_OPEN}Review and resolve coverage gaps for all eligible resources{HTML_LI_CLOSE}"
            )
            section_parts.append(
                f"{HTML_LI_OPEN}Ensure Inspector scan configuration covers all resource types{HTML_LI_CLOSE}"
            )
        elif self._control_id == "SA-11":
            section_parts.append(f"{HTML_LI_OPEN}Enable ECR image vulnerability scanning in Inspector{HTML_LI_CLOSE}")
            section_parts.append(f"{HTML_LI_OPEN}Enable Lambda function code scanning in Inspector{HTML_LI_CLOSE}")

        section_parts.append(HTML_UL_CLOSE)
        return section_parts

    @property
    def framework(self) -> str:
        """Compliance framework used for assessment."""
        return self.control_mapper.framework


class AWSInspectorEvidenceIntegration(ComplianceIntegration):
    """Process AWS Inspector V2 findings and create assessments/issues in RegScale."""

    def __init__(self, config: InspectorEvidenceConfig):
        """
        Initialize AWS Inspector V2 evidence integration.

        :param InspectorEvidenceConfig config: Configuration object containing all parameters
        """
        super().__init__(
            plan_id=config.plan_id,
            framework=config.framework,
            create_issues=config.create_issues,
            update_control_status=config.update_control_status,
            create_poams=config.create_poams,
            parent_module=config.parent_module,
        )

        # Initialize API for file operations
        self.api = Api()

        self.region = config.region
        self.title = "AWS Inspector V2"
        self.framework = config.framework
        self.create_issues = config.create_issues
        self.create_vulnerabilities = config.create_vulnerabilities
        self.collect_evidence = config.collect_evidence
        self.evidence_as_attachments = config.evidence_as_attachments
        self.evidence_control_ids = config.evidence_control_ids
        self.evidence_frequency = config.evidence_frequency
        self.force_refresh = config.force_refresh
        self.account_id = config.account_id
        self.tags = config.tags or {}
        self.severities = config.severities
        self.finding_statuses = config.finding_statuses

        self.control_mapper = InspectorControlMapper(framework=config.framework)

        profile = config.profile
        aws_access_key_id = config.aws_access_key_id
        aws_secret_access_key = config.aws_secret_access_key
        aws_session_token = config.aws_session_token

        if aws_access_key_id and aws_secret_access_key:
            logger.info("Initializing AWS Inspector V2 client with explicit credentials")
            self.session = boto3.Session(
                region_name=config.region,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                aws_session_token=aws_session_token,
            )
        else:
            logger.info(f"Initializing AWS Inspector V2 client with profile: {profile if profile else 'default'}")
            self.session = boto3.Session(profile_name=profile, region_name=config.region)

        try:
            self.client = make_aws_client(self.session, "inspector2")
            logger.info("Successfully created AWS Inspector V2 client")
        except Exception as e:
            logger.error(f"Failed to create AWS Inspector V2 client: {e}")
            raise

        self.raw_inspector_data: Dict[str, Any] = {}
        self.findings_with_cves: List[Dict[str, Any]] = []
        self.findings_without_cves: List[Dict[str, Any]] = []

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Fetch Inspector V2 compliance data.

        Returns the raw Inspector data which will be used to create compliance items
        for each control that Inspector maps to.

        :return: List containing raw Inspector data
        :rtype: List[Dict[str, Any]]
        """
        self.fetch_inspector_data()

        # Return the raw data wrapped in a list
        return [self.raw_inspector_data] if self.raw_inspector_data else []

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> List[ComplianceItem]:
        """
        Create compliance items from Inspector data.

        Inspector creates multiple compliance items (one per control) from the same data set.

        :param Dict[str, Any] raw_data: Raw Inspector data
        :return: List of compliance items for each control
        :rtype: List[ComplianceItem]
        """
        compliance_items = []

        # Get all controls that Inspector maps to
        control_results = self.control_mapper.assess_inspector_compliance(raw_data)

        # Create a compliance item for each control
        for control_id in control_results:
            compliance_item = InspectorComplianceItem(
                control_id=control_id,
                inspector_data=raw_data,
                control_mapper=self.control_mapper,
            )
            compliance_items.append(compliance_item)

        return compliance_items

    def process_compliance_data(self) -> None:
        """
        Override process_compliance_data to handle Inspector's unique pattern.

        Inspector creates multiple compliance items from a single data fetch,
        so we need to handle this differently than the base implementation.
        """
        logger.info("Processing Inspector V2 compliance data...")

        self._reset_compliance_state()
        raw_compliance_data = self.fetch_compliance_data()

        # Process the raw data - Inspector returns a list with one item
        for raw_item in raw_compliance_data:
            try:
                # Create multiple compliance items from the single raw data
                compliance_items = self.create_compliance_item(raw_item)

                # Process each compliance item
                for compliance_item in compliance_items:
                    control_id = getattr(compliance_item, "control_id", "")
                    resource_id = getattr(compliance_item, "resource_id", "")

                    if not control_id or not resource_id:
                        continue

                    # Add to collections
                    self.all_compliance_items.append(compliance_item)

                    # Build asset mapping
                    self.asset_compliance_map[compliance_item.resource_id].append(compliance_item)

                    # Categorize by result
                    if compliance_item.compliance_result in self.FAIL_STATUSES:
                        self.failed_compliance_items.append(compliance_item)
                        self.failing_controls[control_id.lower()] = compliance_item
                    else:
                        self.passing_controls[control_id.lower()] = compliance_item

            except Exception as e:
                logger.error(f"Error processing Inspector V2 compliance data: {e}")
                continue

        logger.info(
            f"Processed {len(self.all_compliance_items)} compliance items: "
            f"{len(self.passing_controls)} passing controls, "
            f"{len(self.failing_controls)} failing controls"
        )

    def _is_cache_valid(self) -> bool:
        if not os.path.exists(INSPECTOR_CACHE_FILE):
            return False
        file_age = time.time() - os.path.getmtime(INSPECTOR_CACHE_FILE)
        is_valid = file_age < CACHE_TTL_SECONDS
        if is_valid:
            logger.info(f"Using cached Inspector data (age: {file_age / 3600:.1f} hours)")
        return is_valid

    def _load_cached_data(self) -> Dict[str, Any]:
        try:
            with open(INSPECTOR_CACHE_FILE, encoding="utf-8") as file:
                data = json.load(file)

            if not isinstance(data, dict):
                logger.warning("Invalid cache format detected (not a dict). Invalidating cache.")
                return {}

            return data
        except (json.JSONDecodeError, IOError) as e:
            logger.warning(f"Error reading cache: {e}")
            return {}

    def _save_to_cache(self, inspector_data: Dict[str, Any]) -> None:
        try:
            os.makedirs(os.path.dirname(INSPECTOR_CACHE_FILE), exist_ok=True)
            with open(INSPECTOR_CACHE_FILE, "w", encoding="utf-8") as file:
                json.dump(inspector_data, file, indent=2, default=str)
            os.chmod(INSPECTOR_CACHE_FILE, 0o600)
            logger.info("Cached Inspector data to %s", INSPECTOR_CACHE_FILE)
        except IOError as e:
            logger.warning("Error writing cache: %s", e)

    def _fetch_fresh_inspector_data(self) -> Dict[str, Any]:
        logger.info("Fetching Inspector V2 data from AWS...")

        from regscale.integrations.commercial.aws.inventory.resources.inspector import (
            InspectorCollector,
        )

        collector = InspectorCollector(
            session=self.session,
            region=self.region,
            account_id=self.account_id,
            tags=self.tags,
            severities=self.severities,
            finding_statuses=self.finding_statuses,
        )

        inspector_data = collector.collect()
        logger.info(
            f"Fetched {len(inspector_data.get('Findings', []))} finding(s), "
            f"{len(inspector_data.get('Coverage', []))} covered resource(s)"
        )

        return inspector_data

    def fetch_inspector_data(self) -> Dict[str, Any]:
        """Fetch Inspector data with caching support."""
        if not self.force_refresh and self._is_cache_valid():
            cached_data = self._load_cached_data()
            if cached_data:
                self.raw_inspector_data = cached_data
                return cached_data

        if self.force_refresh:
            logger.info("Force refresh requested, fetching fresh Inspector data...")

        try:
            inspector_data = self._fetch_fresh_inspector_data()
            self.raw_inspector_data = inspector_data
            self._save_to_cache(inspector_data)
            return inspector_data
        except ClientError as e:
            from regscale.integrations.commercial.aws.common import handle_aws_client_error

            handle_aws_client_error(e, "fetching Inspector data", region=self.region)
            return {}

    def _classify_findings(self) -> None:
        """Classify findings into those with CVEs (vulnerabilities) and those without (issues)."""
        findings = self.raw_inspector_data.get("Findings", [])

        for finding in findings:
            if self._has_cve_reference(finding):
                self.findings_with_cves.append(finding)
            else:
                self.findings_without_cves.append(finding)

        logger.info(
            f"Classified findings: {len(self.findings_with_cves)} with CVEs (vulnerabilities), "
            f"{len(self.findings_without_cves)} without CVEs (issues)"
        )

    def _has_cve_reference(self, finding: Dict[str, Any]) -> bool:
        """
        Check if Inspector finding contains a CVE reference.

        :param Dict[str, Any] finding: Inspector finding
        :return: True if CVE referenced
        :rtype: bool
        """
        # Check packageVulnerabilityDetails for CVE ID
        pkg_vuln = finding.get("packageVulnerabilityDetails", {})
        vuln_id = pkg_vuln.get("vulnerabilityId", "")
        if vuln_id and vuln_id.upper().startswith("CVE-"):
            return True

        # Check title and description as fallback
        title = finding.get("title", "")
        description = finding.get("description", "")
        text_to_search = f"{title} {description}"
        return "CVE-" in text_to_search.upper()

    def _extract_cve_from_finding(self, finding: Dict[str, Any]) -> Optional[str]:
        """
        Extract the primary CVE ID from an Inspector finding.

        Inspector V2 package vulnerabilities frequently carry a distro-specific
        advisory ID in ``vulnerabilityId`` (USN-*, GHSA-*, ALAS-*, RHSA-*) and
        the real CVE(s) in ``relatedVulnerabilities``. This method walks that
        chain so the Vulnerability's ``cve`` field matches what the finding is
        actually about, not just the advisory wrapper.

        :param Dict[str, Any] finding: Inspector finding
        :return: CVE ID or None
        :rtype: Optional[str]
        """
        pkg_vuln = finding.get("packageVulnerabilityDetails", {})

        # 1. Primary source: vulnerabilityId, if it's already a CVE
        vuln_id = pkg_vuln.get("vulnerabilityId", "")
        if vuln_id and vuln_id.upper().startswith("CVE-"):
            return vuln_id.upper()

        # 2. relatedVulnerabilities — Inspector surfaces the underlying CVE(s) here
        #    when vulnerabilityId is an advisory ID (USN/GHSA/ALAS/RHSA/etc.)
        related = pkg_vuln.get("relatedVulnerabilities") or []
        for candidate in related:
            if candidate and candidate.upper().startswith("CVE-"):
                return candidate.upper()

        # 3. Fallback: regex-scan title + description + reference URLs for a CVE id
        reference_urls = pkg_vuln.get("referenceUrls") or []
        text_to_search = " ".join(
            [
                finding.get("title", "") or "",
                finding.get("description", "") or "",
                " ".join(reference_urls),
            ]
        )

        cve_pattern = r"CVE-\d{4}-\d{4,7}"
        matches = re.findall(cve_pattern, text_to_search, re.IGNORECASE)
        if matches:
            return matches[0].upper()

        return None

    def _extract_resource_identifier(self, finding: Dict[str, Any]) -> str:
        """
        Extract resource identifier from Inspector finding.

        :param Dict[str, Any] finding: Inspector finding
        :return: Resource identifier
        :rtype: str
        """
        resources = finding.get("resources", [])
        if resources:
            resource = resources[0]
            resource_id = resource.get("id", "")
            if resource_id:
                return resource_id

        # Fallback to finding ARN
        finding_arn = finding.get("findingArn", "")
        if finding_arn:
            return finding_arn

        # Fallback to account ID
        return finding.get("awsAccountId", "")

    def _get_inspector_score(self, finding: Dict[str, Any]) -> Optional[float]:
        """
        Extract Inspector score from finding.

        :param Dict[str, Any] finding: Inspector finding
        :return: Inspector score or None
        :rtype: Optional[float]
        """
        return finding.get("inspectorScore")

    def _extract_plugin_info(self, finding: Dict[str, Any]) -> tuple[str, str]:
        """
        Extract plugin_id and plugin_name from an Inspector V2 finding.

        Uses the most specific identifier the SDK exposes for each finding type:
          - PACKAGE_VULNERABILITY: plugin_id = vulnerabilityId (CVE/GHSA/ALAS), plugin_name = title
          - CODE_VULNERABILITY:    plugin_id = detectorId, plugin_name = detectorName (or title)
          - NETWORK_REACHABILITY:  plugin_id = finding type (no rule-level ID exists), plugin_name = title

        Falls back to the finding type and an "AWS Inspector V2" prefix when the specific
        fields are unavailable.

        :param Dict[str, Any] finding: Inspector finding
        :return: (plugin_id, plugin_name)
        :rtype: tuple[str, str]
        """
        finding_type = finding.get("type", "") or "UNKNOWN"
        title = finding.get("title", "")

        if finding_type == "PACKAGE_VULNERABILITY":
            pkg_vuln = finding.get("packageVulnerabilityDetails") or {}
            vuln_id = pkg_vuln.get("vulnerabilityId", "")
            if vuln_id:
                return vuln_id.upper(), title or vuln_id.upper()

        elif finding_type == "CODE_VULNERABILITY":
            code_vuln = finding.get("codeVulnerabilityDetails") or {}
            detector_id = code_vuln.get("detectorId", "")
            detector_name = code_vuln.get("detectorName", "")
            if detector_id:
                return detector_id, detector_name or title or detector_id

        fallback_name = title or f"AWS Inspector V2 - {finding_type}"
        return finding_type, fallback_name

    def _parse_inspector_finding_as_vulnerability(
        self, finding: Dict[str, Any], group: Optional[List[Dict[str, Any]]] = None
    ) -> IntegrationFinding:
        """Parse Inspector finding with CVE as RegScale Vulnerability.

        When ``group`` is provided, every resource ARN from the group is merged into the
        ``asset_identifier`` so one vulnerability maps to all affected assets instead of
        one duplicate per instance.
        """
        finding_arn = finding.get("findingArn", "")
        finding_type = finding.get("type", "")
        title = finding.get("title", "")
        severity_str = finding.get("severity", "MEDIUM")

        # Extract CVE
        cve = self._extract_cve_from_finding(finding)

        # Extract resource identifier — merged across the group when present.
        asset_identifier = (
            self._collect_asset_identifiers(group) if group else self._extract_resource_identifier(finding)
        )

        # Create URL-safe external_id
        external_id = finding_arn.replace(":", "-").replace("/", "-")

        # Build detailed description
        detailed_description = self._build_finding_description(finding)

        # Map severity to RegScale
        regscale_severity = self.control_mapper.get_severity_from_inspector(severity_str)

        # Get CVSS score from Inspector
        inspector_score = self._get_inspector_score(finding)
        cvss_info = ""
        if inspector_score is not None:
            cvss_info = f"\nInspector Score: {inspector_score}"

        plugin_id, plugin_name = self._extract_plugin_info(finding)

        integration_finding = IntegrationFinding(
            asset_identifier=asset_identifier,
            control_labels=[],
            category="Vulnerability",
            external_id=external_id,
            title=f"Inspector {finding_type}: {title}",
            description=detailed_description,
            severity=regscale_severity,
            status="Open",
            cve=cve,  # REG-21836: populate the cve field so the Vulnerability record carries it
            vulnerability_number=cve,
            plugin_id=plugin_id,
            plugin_name=plugin_name,
            comments=(
                f"Inspector Finding ARN: {finding_arn}\n"
                f"CVE: {cve or 'N/A'}{cvss_info}\n"
                f"Region: {finding.get('Region', self.region)}"
            ),
        )

        return integration_finding

    def _parse_inspector_finding_as_issue(
        self, finding: Dict[str, Any], group: Optional[List[Dict[str, Any]]] = None
    ) -> IntegrationFinding:
        """Parse Inspector finding as RegScale Issue, with optional multi-resource linking."""
        finding_arn = finding.get("findingArn", "")
        finding_type = finding.get("type", "")
        title = finding.get("title", "")
        severity_str = finding.get("severity", "MEDIUM")

        # Extract resource identifier — merged across the group when present.
        asset_identifier = (
            self._collect_asset_identifiers(group) if group else self._extract_resource_identifier(finding)
        )

        # Create URL-safe external_id
        external_id = finding_arn.replace(":", "-").replace("/", "-")

        # Build detailed description
        detailed_description = self._build_finding_description(finding)

        # Map severity to RegScale
        regscale_severity = self.control_mapper.get_severity_from_inspector(severity_str)

        plugin_id, plugin_name = self._extract_plugin_info(finding)

        integration_finding = IntegrationFinding(
            asset_identifier=asset_identifier,
            control_labels=[],
            category="Security",
            external_id=external_id,
            title=f"Inspector {finding_type}: {title}",
            description=detailed_description,
            severity=regscale_severity,
            status="Open",
            plugin_id=plugin_id,
            plugin_name=plugin_name,
            comments=(f"Inspector Finding ARN: {finding_arn}\nRegion: {finding.get('Region', self.region)}"),
        )

        return integration_finding

    def _build_finding_description(self, finding: Dict[str, Any]) -> str:
        """Build HTML-formatted finding description."""
        metadata = self._extract_finding_metadata(finding)

        desc_parts = self._build_finding_header()
        desc_parts.extend(self._build_finding_details(metadata))

        # Add CVE information if present
        cve_section = self._build_cve_section(finding)
        if cve_section:
            desc_parts.extend(cve_section)

        return "".join(desc_parts)

    def _extract_finding_metadata(self, finding: Dict[str, Any]) -> Dict[str, str]:
        """Extract metadata from finding for description building."""
        resources = finding.get("resources", [])
        resource_type = ""
        if resources:
            resource_type = resources[0].get("type", "")

        inspector_score = finding.get("inspectorScore")
        score_str = str(inspector_score) if inspector_score is not None else "N/A"

        return {
            "description": finding.get("description", ""),
            "finding_type": finding.get("type", ""),
            "severity": finding.get("severity", ""),
            "first_observed": finding.get("firstObservedAt", ""),
            "last_observed": finding.get("lastObservedAt", ""),
            "resource_type": resource_type,
            "inspector_score": score_str,
        }

    def _build_finding_header(self) -> List[str]:
        """Build the header section of finding description."""
        return [
            f"{HTML_H3_OPEN}Inspector V2 Security Finding{HTML_H3_CLOSE}",
            HTML_P_OPEN,
        ]

    def _build_finding_details(self, metadata: Dict[str, str]) -> List[str]:
        """Build the details section of finding description."""
        details = [
            f"{HTML_STRONG_OPEN}Finding Type:{HTML_STRONG_CLOSE} {metadata['finding_type']}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Severity:{HTML_STRONG_CLOSE} {metadata['severity']}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Inspector Score:{HTML_STRONG_CLOSE} {metadata['inspector_score']}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Resource Type:{HTML_STRONG_CLOSE} {metadata['resource_type']}{HTML_BR}",
            f"{HTML_STRONG_OPEN}First Observed:{HTML_STRONG_CLOSE} {metadata['first_observed']}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Last Observed:{HTML_STRONG_CLOSE} {metadata['last_observed']}",
            HTML_P_CLOSE,
            f"{HTML_H3_OPEN}Description{HTML_H3_CLOSE}",
            f"{HTML_P_OPEN}{metadata['description']}{HTML_P_CLOSE}",
        ]
        return details

    def _build_cve_section(self, finding: Dict[str, Any]) -> List[str]:
        """Build CVE references section if CVEs are present."""
        if not self._has_cve_reference(finding):
            return []

        cve = self._extract_cve_from_finding(finding)
        if not cve:
            return []

        # Also extract CVSS scores from packageVulnerabilityDetails
        pkg_vuln = finding.get("packageVulnerabilityDetails", {})
        cvss_scores = pkg_vuln.get("cvss", [])

        cve_parts = [
            f"{HTML_H3_OPEN}CVE References{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
            f"{HTML_LI_OPEN}{cve}{HTML_LI_CLOSE}",
        ]

        for cvss in cvss_scores:
            source = cvss.get("source", "")
            score = cvss.get("baseScore", "")
            version = cvss.get("version", "")
            cve_parts.append(f"{HTML_LI_OPEN}CVSS {version} ({source}): {score}{HTML_LI_CLOSE}")

        cve_parts.append(HTML_UL_CLOSE)
        return cve_parts

    def sync_compliance(self) -> None:
        """
        Main method to sync Inspector V2 compliance data.

        This extends the base sync_compliance to:
        1. Create assessments for controls (RA-5, SI-2, CM-6, SA-11)
        2. Update control implementation status
        3. Create issues for failed compliance
        4. Process individual findings as issues/vulnerabilities
        5. Collect evidence if requested
        """
        # Call the base class sync_compliance to handle control assessments and issues
        super().sync_compliance()

        # Additionally process individual findings as issues/vulnerabilities
        self._process_individual_findings()

        # Warn if nothing was created when the user expected items to be created
        self._warn_if_empty_run()

        # If evidence collection is enabled, collect evidence after compliance sync
        if self.collect_evidence:
            logger.info("Evidence collection enabled, starting evidence collection...")
            self._collect_inspector_evidence()

    def _warn_if_empty_run(self) -> None:
        """Emit a diagnostic warning when issue/vulnerability creation was enabled but produced nothing."""
        if not (self.create_issues or self.create_vulnerabilities):
            return

        issue_results = getattr(self, "_results", {}).get("issues", {}) or {}
        issues_created = issue_results.get("created_count", 0)
        vulns_created = len(self.findings_with_cves) if self.create_vulnerabilities else 0
        if issues_created or vulns_created:
            return

        findings_count = len(self.raw_inspector_data.get("Findings", []))
        logger.warning(
            "Inspector sync produced no issues or vulnerabilities (create_issues=%s, "
            "create_vulnerabilities=%s, raw Inspector findings=%s). Likely causes: "
            "(1) cached Inspector data is empty or stale - retry with --force_refresh; "
            "(2) --account_id or --tags filter is too narrow; "
            "(3) the target AWS account has no Inspector findings in this region; "
            "(4) all compliance controls passed (nothing to escalate).",
            self.create_issues,
            self.create_vulnerabilities,
            findings_count,
        )

    def _process_individual_findings(self) -> None:
        """Process Inspector findings as issues or vulnerabilities, grouped by plugin identity.

        Inspector returns one finding per ``(resource, finding)`` pair, so the same CVE on
        ten EC2 instances arrives as ten near-identical finding rows. We group by plugin
        identity (``findingType`` + CVE / detectorId / title) and merge every affected
        resource ARN into a newline-separated ``asset_identifier`` so RegScale creates one
        vulnerability / issue linked to all affected assets instead of ten duplicates.
        """
        self._classify_findings()

        if self.create_issues and self.findings_without_cves:
            issue_groups = self._group_findings_for_dedup(self.findings_without_cves)
            logger.info(
                "Creating %d issue(s) from %d Inspector finding(s) (deduplicated by plugin identity)",
                len(issue_groups),
                len(self.findings_without_cves),
            )
            issues = [self._parse_inspector_finding_as_issue(group[0], group) for group in issue_groups]
            self.update_regscale_findings(issues)

        if self.create_vulnerabilities and self.findings_with_cves:
            vuln_groups = self._group_findings_for_dedup(self.findings_with_cves)
            logger.info(
                "Creating %d vulnerability(ies) from %d Inspector CVE finding(s) (deduplicated by CVE)",
                len(vuln_groups),
                len(self.findings_with_cves),
            )
            vulns = [self._parse_inspector_finding_as_vulnerability(group[0], group) for group in vuln_groups]
            self.update_regscale_findings(vulns)

    def _group_findings_for_dedup(self, findings: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        """
        Group findings that represent the same plugin/CVE across multiple resources.

        Grouping key is ``(finding_type, plugin_id, plugin_name)`` — for package vulns this
        collapses to CVE, for code vulns to detectorId, for network-reachability to title.
        Preserves insertion order of both groups and members so log output remains stable.

        :param findings: Inspector finding dicts.
        :return: List of groups, each group being a list of findings that share a key.
        :rtype: List[List[Dict[str, Any]]]
        """
        groups: Dict[tuple, List[Dict[str, Any]]] = {}
        for finding in findings:
            plugin_id, plugin_name = self._extract_plugin_info(finding)
            key = (finding.get("type", ""), plugin_id, plugin_name)
            groups.setdefault(key, []).append(finding)
        return list(groups.values())

    def _collect_asset_identifiers(self, findings: List[Dict[str, Any]]) -> str:
        """Return a newline-joined list of unique resource ARNs across ``findings``.

        The vulnerability / issue handler splits ``asset_identifier`` on ``\\n`` or ``,``
        when the server matches findings to assets, so emitting a joined list links a
        single vulnerability to every affected resource.
        """
        seen: List[str] = []
        seen_set: set = set()
        for finding in findings:
            identifier = self._extract_resource_identifier(finding)
            if identifier and identifier not in seen_set:
                seen_set.add(identifier)
                seen.append(identifier)
        return "\n".join(seen) if seen else ""

    def sync_findings(self) -> None:
        """
        Legacy method for backward compatibility.
        Redirects to sync_compliance which now handles everything.
        """
        logger.info("sync_findings called - redirecting to sync_compliance for full compliance integration")
        self.sync_compliance()

    def _collect_inspector_evidence(self) -> None:
        if not self.raw_inspector_data:
            logger.warning("No Inspector data available for evidence collection")
            return

        scan_date = get_current_datetime(dt_format="%Y%m%d_%H%M%S")

        if self.evidence_as_attachments:
            logger.info("Creating SSP file attachment with Inspector evidence...")
            self._create_ssp_attachment(scan_date)
        else:
            logger.info("Creating Evidence record with Inspector evidence...")
            self._create_evidence_record(scan_date)

    def _create_ssp_attachment(self, scan_date: str) -> None:
        try:
            # Check for existing evidence to avoid duplicates
            date_str = datetime.now().strftime("%Y%m%d")
            file_name_pattern = f"inspector_evidence_{date_str}"

            if self.check_for_existing_evidence(file_name_pattern):
                logger.info(
                    "Evidence file for Inspector already exists for today. Skipping upload to avoid duplicates."
                )
                return

            # Add timestamp to make filename unique if run multiple times per day
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"inspector_evidence_{timestamp}.jsonl.gz"

            # Build compliance assessment
            compliance_results = self.control_mapper.assess_inspector_compliance(self.raw_inspector_data)

            evidence_entry = {
                **self.raw_inspector_data,
                "compliance_assessment": {
                    "control_results": compliance_results,
                    "assessed_controls": list(compliance_results.keys()),
                    "assessment_date": scan_date,
                },
                "findings_summary": {
                    "total": len(self.raw_inspector_data.get("Findings", [])),
                    "with_cves": len(self.findings_with_cves),
                    "without_cves": len(self.findings_without_cves),
                },
            }

            jsonl_content = json.dumps(evidence_entry, default=str)

            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz_file:
                gz_file.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()

            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=self.plan_id,
                parent_module=self.parent_module,
                api=api,
                file_data=compressed_data,
                tags="aws,inspector,vulnerability-scanning,automated",
            )

            if success:
                logger.info(f"Successfully uploaded Inspector evidence file: {file_name}")
            else:
                logger.error("Failed to upload Inspector evidence file")

        except Exception as e:
            logger.error(f"Error creating SSP attachment: {e}", exc_info=True)

    def _create_evidence_record(self, scan_date: str) -> None:
        try:
            title = f"AWS Inspector V2 Evidence - {scan_date}"
            description = self._build_evidence_description(scan_date)
            due_date = (datetime.now() + timedelta(days=self.evidence_frequency)).isoformat()

            evidence = Evidence(
                title=title,
                description=description,
                status="Collected",
                updateFrequency=self.evidence_frequency,
                dueDate=due_date,
            )

            created_evidence = evidence.create()
            if not created_evidence or not created_evidence.id:
                logger.error("Failed to create evidence record")
                return

            logger.info(f"Created evidence record {created_evidence.id}: {title}")
            self._upload_evidence_file(created_evidence.id, scan_date)
            self._link_evidence_to_ssp(created_evidence.id)

            # Link to controls if specified
            if self.evidence_control_ids:
                self._link_evidence_to_controls(created_evidence.id, is_attachment=False)

        except Exception as e:
            logger.error(f"Error creating evidence record: {e}", exc_info=True)

    def _build_evidence_description(self, scan_date: str) -> str:
        """Build HTML-formatted evidence description."""
        summary = self._get_inspector_summary()
        compliance_results = self.control_mapper.assess_inspector_compliance(self.raw_inspector_data)

        desc_parts = self._build_evidence_header(scan_date)
        desc_parts.extend(self._build_summary_section(summary))
        desc_parts.extend(self._build_compliance_section(compliance_results))

        return "".join(desc_parts)

    def _get_inspector_summary(self) -> Dict[str, int]:
        """Extract summary statistics from Inspector data."""
        return {
            "covered_resources": len(self.raw_inspector_data.get("Coverage", [])),
            "total_findings": len(self.raw_inspector_data.get("Findings", [])),
            "cve_findings": len(self.findings_with_cves),
            "security_issues": len(self.findings_without_cves),
        }

    def _build_evidence_header(self, scan_date: str) -> List[str]:
        """Build evidence header section."""
        return [
            "<h1>AWS Inspector V2 Vulnerability Scanning Evidence</h1>",
            f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Assessment Date:{HTML_STRONG_CLOSE} {scan_date}{HTML_P_CLOSE}",
        ]

    def _build_summary_section(self, summary: Dict[str, int]) -> List[str]:
        """Build Inspector summary section."""
        return [
            f"{HTML_H2_OPEN}Inspector V2 Summary{HTML_H2_CLOSE}",
            HTML_UL_OPEN,
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Covered Resources:{HTML_STRONG_CLOSE} {summary['covered_resources']}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Total Findings:{HTML_STRONG_CLOSE} {summary['total_findings']}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}CVE-Related Findings:{HTML_STRONG_CLOSE} {summary['cve_findings']}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Security Issues:{HTML_STRONG_CLOSE} {summary['security_issues']}{HTML_LI_CLOSE}",
            HTML_UL_CLOSE,
        ]

    def _build_compliance_section(self, compliance_results: Dict[str, str]) -> List[str]:
        """Build control compliance results section."""
        section_parts = [
            f"{HTML_H2_OPEN}Control Compliance Results{HTML_H2_CLOSE}",
            HTML_UL_OPEN,
        ]

        for control_id, result in compliance_results.items():
            control_item = self._format_control_result(control_id, result)
            section_parts.append(control_item)

        section_parts.append(HTML_UL_CLOSE)
        return section_parts

    def _format_control_result(self, control_id: str, result: str) -> str:
        """Format a single control result for display."""
        control_desc = self.control_mapper.get_control_description(control_id)
        result_color = "#d32f2f" if result == "FAIL" else "#2e7d32"
        return (
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}{control_id}:{HTML_STRONG_CLOSE} "
            f"<span style='color: {result_color};'>{result}</span> - {control_desc}{HTML_LI_CLOSE}"
        )

    def _upload_evidence_file(self, evidence_id: int, scan_date: str) -> None:
        try:
            compliance_results = self.control_mapper.assess_inspector_compliance(self.raw_inspector_data)
            evidence_entry = {
                **self.raw_inspector_data,
                "compliance_assessment": {
                    "control_results": compliance_results,
                    "assessed_controls": list(compliance_results.keys()),
                    "assessment_date": scan_date,
                },
            }
            jsonl_content = json.dumps(evidence_entry, default=str)

            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz_file:
                gz_file.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()
            file_name = f"inspector_evidence_{scan_date}.jsonl.gz"

            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=evidence_id,
                parent_module="evidence",
                api=api,
                file_data=compressed_data,
                tags="aws,inspector,vulnerability-scanning",
            )

            if success:
                logger.info(f"Uploaded Inspector evidence file to Evidence {evidence_id}")
            else:
                logger.warning(f"Failed to upload evidence file to Evidence {evidence_id}")

        except Exception as e:
            logger.error(f"Error uploading evidence file: {e}", exc_info=True)

    def _link_evidence_to_ssp(self, evidence_id: int) -> None:
        try:
            mapping = EvidenceMapping(
                evidenceID=evidence_id,
                mappedID=self.plan_id,
                mappingType=self.parent_module,
            )
            mapping.create()
            logger.info(f"Linked evidence {evidence_id} to SSP {self.plan_id}")
        except Exception as ex:
            logger.warning(f"Failed to link evidence to SSP: {ex}")

    def _link_evidence_to_controls(self, evidence_id: int, is_attachment: bool = False) -> None:
        """
        Link evidence to specified control IDs.

        :param int evidence_id: Evidence or attachment ID
        :param bool is_attachment: True if linking attachment, False for evidence record
        """
        if not self.evidence_control_ids:
            return
        try:
            for control_id in self.evidence_control_ids:
                if is_attachment:
                    self.api.link_ssp_attachment_to_control(self.plan_id, evidence_id, control_id)
                else:
                    self.api.link_evidence_to_control(evidence_id, control_id)
                logger.info("Linked evidence %s to control %s", evidence_id, control_id)
        except Exception as e:
            logger.error("Failed to link evidence to controls: %s", e, exc_info=True)

    def _map_resource_type_to_asset_type(self, compliance_item: ComplianceItem) -> str:
        """
        Map Inspector service to RegScale asset type.

        :param ComplianceItem compliance_item: Compliance item
        :return: Asset type string
        :rtype: str
        """
        return "AWS Inspector V2 Service"

    def fetch_findings(self, *args, **kwargs):
        """
        Fetch findings from failed Inspector compliance items.

        Delegates to the parent ComplianceIntegration implementation which
        iterates over failed_compliance_items and yields IntegrationFinding objects.

        :return: Iterator of IntegrationFinding objects
        :rtype: Iterator
        """
        yield from super().fetch_findings(*args, **kwargs)

    # Map AWS Inspector resource types to RegScale asset types. Anything unmapped falls
    # through to "Cloud Resource" so new resource types Inspector adds don't break sync.
    _INSPECTOR_ASSET_TYPE_MAP: Dict[str, str] = {
        "AWS_EC2_INSTANCE": "Virtual Machine",
        "AWS_LAMBDA_FUNCTION": "Cloud Resource",
        "AWS_ECR_CONTAINER_IMAGE": "Container",
        "AWS_ECR_REPOSITORY": "Container",
    }

    def fetch_assets(self, *args, **kwargs):
        """
        Yield the per-account compliance asset plus one asset per real Inspector resource.

        Inspector findings reference concrete resources (EC2 instances, Lambda functions,
        ECR images) via ARNs on ``resources[].id``. Emitting an IntegrationAsset per ARN
        — in addition to the synthetic per-account asset used for compliance-control
        assessments — lets server-side asset matching link vulnerabilities to the actual
        affected resource instead of defaulting to the account-level placeholder.

        :return: Iterator of IntegrationAsset objects.
        :rtype: Iterator
        """
        # Per-account compliance asset — keeps existing assessment linkage working.
        if self.all_compliance_items:
            account_asset = self.create_asset_from_compliance_item(self.all_compliance_items[0])
            if account_asset:
                yield account_asset

        # Per-resource assets from findings and coverage. Dedup by ARN.
        seen: set = set()
        for arn, resource_type in self._iter_unique_inspector_resources():
            if not arn or arn in seen:
                continue
            seen.add(arn)
            yield IntegrationAsset(
                name=self._resource_name_from_arn(arn, resource_type),
                identifier=arn,
                external_id=arn,
                other_tracking_number=arn,
                asset_type=self._INSPECTOR_ASSET_TYPE_MAP.get(resource_type, "Cloud Resource"),
                asset_category=regscale_models.AssetCategory.Hardware,
                description=f"AWS Inspector V2 {resource_type or 'resource'} discovered during sync",
                parent_id=self.plan_id,
                parent_module=self.parent_module,
                status=regscale_models.AssetStatus.Active,
                date_last_updated=self.scan_date,
            )

    def _iter_unique_inspector_resources(self):
        """Yield ``(arn, resource_type)`` tuples from every finding and coverage entry."""
        for finding in self.raw_inspector_data.get("Findings", []) or []:
            for resource in finding.get("resources", []) or []:
                yield resource.get("id", ""), resource.get("type", "")

        for covered in self.raw_inspector_data.get("Coverage", []) or []:
            yield covered.get("resourceId", ""), covered.get("resourceType", "")

    @staticmethod
    def _resource_name_from_arn(arn: str, resource_type: str) -> str:
        """Derive a readable asset name from an Inspector resource ARN."""
        if not arn:
            return resource_type or "AWS Inspector Resource"
        # Prefer the last path segment (e.g. "instance/i-xxx" → "i-xxx") but fall back to the
        # last colon-delimited segment for ARNs that never use "/" (e.g. some IAM ARN forms).
        if "/" in arn:
            return arn.rsplit("/", 1)[-1] or arn
        return arn.rsplit(":", 1)[-1] or arn
