#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS ECR Control Mappings for RegScale Compliance Integration.

Maps AWS Security Hub ECR controls (ECR.1-ECR.5) to NIST 800-53 Rev 5 controls.
Control mappings sourced from AWS Security Hub official NIST 800-53 R5 ECR documentation.
"""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("regscale")

# NIST 800-53 R5 Control Mappings for AWS ECR
# Each control maps to one or more ECR Security Hub checks (ECR.1, ECR.2, ECR.3, ECR.5)
ECR_CONTROL_MAPPINGS = {
    # ECR.1 - Image scanning configured (HIGH severity)
    "RA-5": {
        "name": "Vulnerability Monitoring and Scanning",
        "description": "Monitor and scan for vulnerabilities in container images",
        "ecr_check": "ECR.1",
        "severity": "HIGH",
        "checks": {
            "scan_on_push": {
                "weight": 100,
                "pass_criteria": "Repository has scan-on-push or continuous scanning enabled",
                "fail_criteria": "Repository does not have image scanning configured",
            },
        },
    },
    # ECR.2 - Tag immutability enabled (MEDIUM severity)
    "CA-9(1)": {
        "name": "Internal System Connections | Compliance Checks",
        "description": "Ensure container image tags are immutable and encryption meets compliance requirements",
        "ecr_check": "ECR.2,ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "tag_immutability": {
                "weight": 80,
                "pass_criteria": "Image tag immutability is enabled (IMMUTABLE)",
                "fail_criteria": "Image tag mutability allows tag overwriting (MUTABLE)",
            },
            "kms_encryption": {
                "weight": 80,
                "pass_criteria": "Repository uses customer-managed KMS key for encryption",
                "fail_criteria": "Repository does not use customer-managed KMS encryption",
            },
        },
    },
    "CM-2": {
        "name": "Baseline Configuration",
        "description": "Develop and maintain baseline configurations for container repositories",
        "ecr_check": "ECR.2,ECR.3",
        "severity": "MEDIUM",
        "checks": {
            "tag_immutability": {
                "weight": 80,
                "pass_criteria": "Image tag immutability ensures baseline integrity",
                "fail_criteria": "Mutable tags allow uncontrolled image replacement",
            },
            "lifecycle_policy": {
                "weight": 100,
                "pass_criteria": "Lifecycle policy configured to manage image retention",
                "fail_criteria": "No lifecycle policy configured for image management",
            },
        },
    },
    "CM-8(1)": {
        "name": "System Component Inventory | Updates During Installation and Removal",
        "description": "Update inventory of container images during deployment changes",
        "ecr_check": "ECR.2",
        "severity": "MEDIUM",
        "checks": {
            "tag_immutability": {
                "weight": 100,
                "pass_criteria": "Immutable tags enable reliable component tracking",
                "fail_criteria": "Mutable tags undermine component inventory accuracy",
            },
        },
    },
    # ECR.3 - Lifecycle policy configured (MEDIUM severity)
    "CM-2(2)": {
        "name": "Baseline Configuration | Automation Support for Accuracy and Currency",
        "description": "Employ automated mechanisms to maintain up-to-date container image inventory",
        "ecr_check": "ECR.3",
        "severity": "MEDIUM",
        "checks": {
            "lifecycle_policy": {
                "weight": 100,
                "pass_criteria": "Lifecycle policy automates image retention and cleanup",
                "fail_criteria": "No automated lifecycle management for container images",
            },
        },
    },
    # ECR.5 - KMS encryption with customer-managed keys (MEDIUM severity)
    "SC-12(2)": {
        "name": "Cryptographic Key Establishment and Management | Symmetric Keys",
        "description": "Produce, control, and distribute symmetric cryptographic keys for ECR encryption",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "kms_encryption": {
                "weight": 100,
                "pass_criteria": "Repository uses customer-managed KMS key for encryption",
                "fail_criteria": "Repository does not use customer-managed KMS encryption",
            },
        },
    },
    "CM-3(6)": {
        "name": "Configuration Change Control | Cryptography Management",
        "description": "Ensure cryptographic mechanisms are under configuration management",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "kms_encryption": {
                "weight": 100,
                "pass_criteria": "Repository encryption managed via customer-controlled KMS key",
                "fail_criteria": "Repository encryption not under customer configuration management",
            },
        },
    },
    "SC-13": {
        "name": "Cryptographic Protection",
        "description": "Implement FIPS-validated cryptography for container image storage",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "encryption_type": {
                "weight": 100,
                "pass_criteria": "Repository encrypted with KMS (FIPS 140-2 validated)",
                "fail_criteria": "Repository uses default AES-256 without customer-managed KMS",
            },
        },
    },
    "SC-28": {
        "name": "Protection of Information at Rest",
        "description": "Protect container images at rest with encryption",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "encryption_at_rest": {
                "weight": 100,
                "pass_criteria": "Container images encrypted at rest with customer-managed KMS key",
                "fail_criteria": "Images rely on default encryption without customer key management",
            },
        },
    },
    "SC-28(1)": {
        "name": "Protection of Information at Rest | Cryptographic Protection",
        "description": "Employ cryptographic mechanisms for container image storage",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "kms_encryption": {
                "weight": 100,
                "pass_criteria": "KMS encryption configured for repository",
                "fail_criteria": "No KMS encryption configured",
            },
        },
    },
    "SC-7(10)": {
        "name": "Boundary Protection | Prevent Exfiltration",
        "description": "Prevent unauthorized exfiltration of container images",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "encryption_boundary": {
                "weight": 100,
                "pass_criteria": "KMS encryption provides boundary protection for stored images",
                "fail_criteria": "Default encryption may not meet boundary protection requirements",
            },
        },
    },
    "SI-7(6)": {
        "name": "Software, Firmware, and Information Integrity | Cryptographic Protection",
        "description": "Use cryptographic mechanisms to protect integrity of container images",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "integrity_protection": {
                "weight": 100,
                "pass_criteria": "KMS encryption protects container image integrity",
                "fail_criteria": "Insufficient cryptographic integrity protection",
            },
        },
    },
    "AU-9": {
        "name": "Protection of Audit Information",
        "description": "Protect audit information related to container image operations",
        "ecr_check": "ECR.5",
        "severity": "MEDIUM",
        "checks": {
            "audit_protection": {
                "weight": 100,
                "pass_criteria": "KMS encryption protects audit-relevant image metadata",
                "fail_criteria": "Audit information may not be adequately protected",
            },
        },
    },
}


class ECRControlMapper:
    """Map AWS ECR repository attributes to compliance control status."""

    def __init__(self, framework: str = "NIST800-53R5"):
        """
        Initialize ECR control mapper.

        :param str framework: Compliance framework (NIST800-53R5)
        """
        self.framework = framework
        self.mappings = ECR_CONTROL_MAPPINGS

    def assess_repository_compliance(self, repo_data: Dict[str, Any]) -> Dict[str, str]:
        """
        Assess ECR repository compliance against all mapped controls.

        Runs four underlying checks (scanning, tag immutability, lifecycle policy, KMS encryption)
        and fans them out to all 13 NIST 800-53 controls.

        :param Dict repo_data: ECR repository data from ContainerCollector
        :return: Dictionary mapping control IDs to compliance results (PASS/FAIL)
        :rtype: Dict[str, str]
        """
        # Run the four underlying ECR checks
        scan_result = self._assess_scanning(repo_data)
        tag_result = self._assess_tag_immutability(repo_data)
        lifecycle_result = self._assess_lifecycle_policy(repo_data)
        kms_result = self._assess_kms_encryption(repo_data)

        repo_name = repo_data.get("RepositoryName", "unknown")

        # Fan out to all NIST controls
        results = {}

        # ECR.1 controls
        results["RA-5"] = scan_result

        # ECR.2 controls
        results["CM-8(1)"] = tag_result

        # ECR.3 controls
        results["CM-2(2)"] = lifecycle_result

        # Compound controls: CM-2 maps to ECR.2 + ECR.3
        results["CM-2"] = "FAIL" if tag_result == "FAIL" or lifecycle_result == "FAIL" else "PASS"

        # Compound controls: CA-9(1) maps to ECR.2 + ECR.5
        results["CA-9(1)"] = "FAIL" if tag_result == "FAIL" or kms_result == "FAIL" else "PASS"

        # ECR.5 controls (all depend on KMS encryption check)
        results["SC-12(2)"] = kms_result
        results["CM-3(6)"] = kms_result
        results["SC-13"] = kms_result
        results["SC-28"] = kms_result
        results["SC-28(1)"] = kms_result
        results["SC-7(10)"] = kms_result
        results["SI-7(6)"] = kms_result
        results["AU-9"] = kms_result

        # Log summary
        pass_count = sum(1 for r in results.values() if r == "PASS")
        fail_count = sum(1 for r in results.values() if r == "FAIL")
        logger.debug(
            "Repository %s compliance: %d PASS, %d FAIL (scan=%s, tags=%s, lifecycle=%s, kms=%s)",
            repo_name,
            pass_count,
            fail_count,
            scan_result,
            tag_result,
            lifecycle_result,
            kms_result,
        )

        return results

    def _assess_scanning(self, repo_data: Dict[str, Any]) -> str:
        """
        Assess ECR.1 - Image scanning configuration.

        Checks if the repository has scan-on-push enabled or enhanced/continuous scanning configured.

        :param Dict repo_data: ECR repository data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        repo_name = repo_data.get("RepositoryName", "unknown")

        # Check basic scan-on-push setting
        scan_config = repo_data.get("ImageScanningConfiguration", {})
        scan_on_push = scan_config.get("scanOnPush", False)

        # Check enhanced scanning configuration if available
        scanning_config = repo_data.get("ScanningConfiguration", {})
        scan_frequency = scanning_config.get("scanFrequency", "")

        if scan_on_push or scan_frequency in ("SCAN_ON_PUSH", "CONTINUOUS_SCAN"):
            logger.debug("Repository %s PASSES ECR.1: scanning configured", repo_name)
            return "PASS"

        logger.debug("Repository %s FAILS ECR.1: no scanning configured", repo_name)
        return "FAIL"

    def _assess_tag_immutability(self, repo_data: Dict[str, Any]) -> str:
        """
        Assess ECR.2 - Tag immutability configuration.

        Checks if imageTagMutability is set to IMMUTABLE.

        :param Dict repo_data: ECR repository data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        repo_name = repo_data.get("RepositoryName", "unknown")
        tag_mutability = repo_data.get("ImageTagMutability", "MUTABLE")

        if tag_mutability == "IMMUTABLE":
            logger.debug("Repository %s PASSES ECR.2: tag immutability enabled", repo_name)
            return "PASS"

        logger.debug("Repository %s FAILS ECR.2: tag mutability is %s", repo_name, tag_mutability)
        return "FAIL"

    def _assess_lifecycle_policy(self, repo_data: Dict[str, Any]) -> str:
        """
        Assess ECR.3 - Lifecycle policy configuration.

        Checks if the repository has at least one lifecycle policy configured.

        :param Dict repo_data: ECR repository data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        repo_name = repo_data.get("RepositoryName", "unknown")
        lifecycle_policy = repo_data.get("LifecyclePolicy")

        if lifecycle_policy is not None:
            logger.debug("Repository %s PASSES ECR.3: lifecycle policy configured", repo_name)
            return "PASS"

        logger.debug("Repository %s FAILS ECR.3: no lifecycle policy configured", repo_name)
        return "FAIL"

    def _assess_kms_encryption(self, repo_data: Dict[str, Any]) -> str:
        """
        Assess ECR.5 - KMS encryption with customer-managed keys.

        Checks if encryptionConfiguration.encryptionType is KMS with a customer-managed key.

        :param Dict repo_data: ECR repository data
        :return: Compliance result (PASS/FAIL)
        :rtype: str
        """
        repo_name = repo_data.get("RepositoryName", "unknown")
        encryption_config = repo_data.get("EncryptionConfiguration", {})
        encryption_type = encryption_config.get("encryptionType", "AES256")
        kms_key = encryption_config.get("kmsKey", "")

        if encryption_type == "KMS" and kms_key:
            logger.debug("Repository %s PASSES ECR.5: KMS encryption with key %s", repo_name, kms_key[:20])
            return "PASS"

        logger.debug(
            "Repository %s FAILS ECR.5: encryption type is %s (expected KMS with customer key)",
            repo_name,
            encryption_type,
        )
        return "FAIL"

    def get_ecr_check_for_control(self, control_id: str) -> Optional[str]:
        """
        Get the ECR Security Hub check ID(s) for a control.

        :param str control_id: NIST control identifier
        :return: ECR check ID(s) or None
        :rtype: Optional[str]
        """
        control_data = self.mappings.get(control_id)
        if control_data:
            return control_data.get("ecr_check")
        return None

    def get_control_description(self, control_id: str) -> Optional[str]:
        """
        Get human-readable description for a control.

        :param str control_id: Control identifier (e.g., RA-5)
        :return: Control description or None
        :rtype: Optional[str]
        """
        control_data = self.mappings.get(control_id)
        if control_data:
            return f"{control_data.get('name')}: {control_data.get('description', '')}"
        return None

    def get_mapped_controls(self) -> List[str]:
        """
        Get list of all control IDs mapped for this framework.

        :return: List of control IDs
        :rtype: List[str]
        """
        return list(self.mappings.keys())

    def get_check_details(self, control_id: str) -> Optional[Dict]:
        """
        Get detailed check criteria for a control.

        :param str control_id: Control identifier
        :return: Dictionary of check details or None
        :rtype: Optional[Dict]
        """
        control_data = self.mappings.get(control_id)
        if control_data:
            return control_data.get("checks", {})
        return None

    def get_severity_for_control(self, control_id: str) -> str:
        """
        Get the severity level for a control.

        :param str control_id: Control identifier
        :return: Severity string (HIGH or MEDIUM)
        :rtype: str
        """
        control_data = self.mappings.get(control_id)
        if control_data:
            return control_data.get("severity", "MEDIUM")
        return "MEDIUM"

    # -------------------------------------------------------------------------
    # ECR Check Consolidation Helpers
    # -------------------------------------------------------------------------

    # Canonical mapping: ECR check → list of NIST controls
    # Order controls with the most commonly-implemented SSP controls first.
    # The issue handler checks control_labels[0] for SSP match, so the lead
    # control must be one likely present in every NIST 800-53 R5 SSP.
    ECR_CHECK_TO_CONTROLS = {
        "ECR.1": ["RA-5"],
        "ECR.2": ["CM-2", "CM-8(1)", "CA-9(1)"],
        "ECR.3": ["CM-2", "CM-2(2)", "CA-9(1)"],
        "ECR.5": ["SC-13", "SC-28", "SC-12(2)", "SC-28(1)", "AU-9", "SI-7(6)", "CM-3(6)", "SC-7(10)", "CA-9(1)"],
    }

    # ECR check descriptions for issue titles
    ECR_CHECK_DESCRIPTIONS = {
        "ECR.1": "Image scanning not configured",
        "ECR.2": "Tag immutability not enabled",
        "ECR.3": "Lifecycle policy not configured",
        "ECR.5": "Customer-managed KMS encryption not configured",
    }

    # ECR check severity
    ECR_CHECK_SEVERITY = {
        "ECR.1": "HIGH",
        "ECR.2": "MEDIUM",
        "ECR.3": "MEDIUM",
        "ECR.5": "MEDIUM",
    }

    def get_failed_ecr_checks(self, repo_data: Dict[str, Any]) -> List[str]:
        """
        Get list of ECR checks that fail for a repository.

        :param Dict repo_data: ECR repository data
        :return: List of failed ECR check IDs (e.g., ["ECR.2", "ECR.3", "ECR.5"])
        :rtype: List[str]
        """
        failed = []
        if self._assess_scanning(repo_data) == "FAIL":
            failed.append("ECR.1")
        if self._assess_tag_immutability(repo_data) == "FAIL":
            failed.append("ECR.2")
        if self._assess_lifecycle_policy(repo_data) == "FAIL":
            failed.append("ECR.3")
        if self._assess_kms_encryption(repo_data) == "FAIL":
            failed.append("ECR.5")
        return failed

    def get_controls_for_ecr_check(self, ecr_check: str) -> List[str]:
        """
        Get all NIST controls mapped to a given ECR check.

        :param str ecr_check: ECR check ID (e.g., "ECR.5")
        :return: List of NIST control IDs
        :rtype: List[str]
        """
        return list(self.ECR_CHECK_TO_CONTROLS.get(ecr_check, []))

    def get_ecr_check_description(self, ecr_check: str) -> str:
        """
        Get human-readable description for an ECR check.

        :param str ecr_check: ECR check ID
        :return: Description string
        :rtype: str
        """
        return self.ECR_CHECK_DESCRIPTIONS.get(ecr_check, ecr_check)

    def get_ecr_check_severity(self, ecr_check: str) -> str:
        """
        Get severity for an ECR check.

        :param str ecr_check: ECR check ID
        :return: Severity string
        :rtype: str
        """
        return self.ECR_CHECK_SEVERITY.get(ecr_check, "MEDIUM")
