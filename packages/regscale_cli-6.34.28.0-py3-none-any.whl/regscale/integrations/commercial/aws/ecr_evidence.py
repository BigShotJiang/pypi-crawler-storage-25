#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AWS ECR Evidence Integration for RegScale CLI.

Syncs AWS ECR repository configurations and Inspector V2 container image vulnerability
findings to RegScale for compliance evidence and control assessments.

Implements Security Hub ECR controls:
- ECR.1: Image scanning configured (RA-5)
- ECR.2: Tag immutability enabled (CA-9(1), CM-2, CM-8(1))
- ECR.3: Lifecycle policy configured (CA-9(1), CM-2, CM-2(2))
- ECR.5: KMS encryption with customer-managed keys (SC-12(2), CM-3(6), SC-13, SC-28, SC-28(1),
         SC-7(10), SI-7(6), AU-9)
"""

import gzip
import json
import logging
import os
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from io import BytesIO
from typing import Any, Dict, List, Optional, Set

import boto3
from botocore.exceptions import ClientError

from regscale.core.app.api import Api
from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.commercial.aws._client_factory import make_aws_client
from regscale.integrations.commercial.aws.ecr_control_mappings import ECRControlMapper
from regscale.integrations.compliance_integration import (
    ComplianceIntegration,
    ComplianceItem,
)
from regscale.models.regscale_models.evidence import Evidence
from regscale.models.regscale_models.evidence_mapping import EvidenceMapping
from regscale.models.regscale_models.file import File
from regscale.models.regscale_models.issue import IssueSeverity

logger = logging.getLogger("regscale")

# Constants for file paths and cache TTL
ECR_CACHE_FILE = os.path.join("artifacts", "aws", "ecr_data.json")
CACHE_TTL_SECONDS = 4 * 60 * 60  # 4 hours in seconds

# HTML tag constants
HTML_STRONG_OPEN = "<strong>"
HTML_STRONG_CLOSE = "</strong>"
HTML_P_OPEN = "<p>"
HTML_P_CLOSE = "</p>"
HTML_UL_OPEN = "<ul>"
HTML_UL_CLOSE = "</ul>"
HTML_LI_OPEN = "<li>"
HTML_LI_CLOSE = "</li>"
HTML_H2_OPEN = "<h2>"
HTML_H2_CLOSE = "</h2>"
HTML_H3_OPEN = "<h3>"
HTML_H3_CLOSE = "</h3>"
HTML_BR = "<br>"

# Inspector severity to IssueSeverity mapping
INSPECTOR_SEVERITY_MAP = {
    "CRITICAL": IssueSeverity.Critical,
    "HIGH": IssueSeverity.High,
    "MEDIUM": IssueSeverity.Moderate,
    "LOW": IssueSeverity.Low,
    "INFORMATIONAL": IssueSeverity.Low,
}


@dataclass
class ECREvidenceConfig:
    """Configuration for AWS ECR evidence collection."""

    plan_id: int
    region: str = "us-east-1"
    framework: str = "NIST800-53R5"
    create_issues: bool = True
    update_control_status: bool = True
    create_poams: bool = False
    parent_module: str = "securityplans"
    collect_evidence: bool = False
    evidence_as_attachments: bool = False
    evidence_control_ids: Optional[List[str]] = None
    evidence_frequency: int = 30
    force_refresh: bool = False
    account_id: Optional[str] = None
    tags: Optional[Dict[str, str]] = None
    profile: Optional[str] = None
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None
    include_inspector_findings: bool = True


class ECRConfigComplianceItem(ComplianceItem):
    """
    Compliance item representing a single ECR repository control assessment.

    One instance is created per (repository, control) pair.
    Maps ECR repository configuration attributes to NIST 800-53 compliance controls.
    """

    def __init__(
        self,
        control_id: str,
        repo_data: Dict[str, Any],
        compliance_result: str,
        control_mapper: ECRControlMapper,
    ):
        """
        Initialize ECR compliance item.

        :param str control_id: NIST control being assessed (e.g., "RA-5")
        :param Dict repo_data: ECR repository data from ContainerCollector
        :param str compliance_result: "PASS" or "FAIL"
        :param ECRControlMapper control_mapper: Control mapper instance
        """
        self._control_id = control_id
        self.repo_data = repo_data
        self._compliance_result = compliance_result
        self.control_mapper = control_mapper

        # Extract repository attributes
        self._repo_name = repo_data.get("RepositoryName", "")
        self._repo_arn = repo_data.get("RepositoryArn", "")
        self._region = repo_data.get("Region", "unknown")
        self._registry_id = repo_data.get("RegistryId", "")

    @property
    def resource_id(self) -> str:
        """Unique identifier for the ECR repository."""
        return self._repo_arn

    @property
    def resource_name(self) -> str:
        """Human-readable name of the ECR repository."""
        return f"ECR: {self._repo_name}"

    @property
    def control_id(self) -> str:
        """NIST control identifier this item assesses."""
        return self._control_id

    @property
    def compliance_result(self) -> str:
        """Compliance result for this control assessment."""
        return self._compliance_result

    @property
    def severity(self) -> Optional[str]:
        """Severity level based on the control being assessed."""
        if self._compliance_result == "PASS":
            return None
        return self.control_mapper.get_severity_for_control(self._control_id)

    @property
    def description(self) -> str:
        """Detailed HTML description of the ECR repository compliance assessment."""
        desc_parts = self._build_repo_details()
        desc_parts.extend(self._build_config_summary())
        desc_parts.extend(self._build_control_result_section())

        if self._compliance_result == "FAIL":
            desc_parts.extend(self._build_remediation_section())

        return "".join(desc_parts)

    @property
    def framework(self) -> str:
        """Compliance framework used for assessment."""
        return self.control_mapper.framework

    def _build_repo_details(self) -> List[str]:
        """Build the repository details section of the description."""
        image_count = len(self.repo_data.get("Images", []))

        return [
            f"{HTML_H3_OPEN}AWS ECR Repository Compliance Assessment{HTML_H3_CLOSE}",
            HTML_P_OPEN,
            f"{HTML_STRONG_OPEN}Repository:{HTML_STRONG_CLOSE} {self._repo_name}{HTML_BR}",
            f"{HTML_STRONG_OPEN}ARN:{HTML_STRONG_CLOSE} {self._repo_arn}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Region:{HTML_STRONG_CLOSE} {self._region}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Registry ID:{HTML_STRONG_CLOSE} {self._registry_id}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Images:{HTML_STRONG_CLOSE} {image_count}",
            HTML_P_CLOSE,
        ]

    def _build_config_summary(self) -> List[str]:
        """Build the repository configuration summary."""
        encryption_config = self.repo_data.get("EncryptionConfiguration", {})
        encryption_type = encryption_config.get("encryptionType", "AES256")
        kms_key = encryption_config.get("kmsKey", "None")
        scan_config = self.repo_data.get("ImageScanningConfiguration", {})
        scan_on_push = "Yes" if scan_config.get("scanOnPush", False) else "No"
        tag_mutability = self.repo_data.get("ImageTagMutability", "MUTABLE")
        lifecycle = "Configured" if self.repo_data.get("LifecyclePolicy") else "Not configured"

        return [
            f"{HTML_H3_OPEN}Configuration{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Scan on Push:{HTML_STRONG_CLOSE} {scan_on_push}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Tag Immutability:{HTML_STRONG_CLOSE} {tag_mutability}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Lifecycle Policy:{HTML_STRONG_CLOSE} {lifecycle}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Encryption Type:{HTML_STRONG_CLOSE} {encryption_type}{HTML_LI_CLOSE}",
            f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}KMS Key:{HTML_STRONG_CLOSE} {kms_key}{HTML_LI_CLOSE}",
            HTML_UL_CLOSE,
        ]

    def _build_control_result_section(self) -> List[str]:
        """Build the control result section."""
        result_color = "#d32f2f" if self._compliance_result == "FAIL" else "#2e7d32"
        control_desc = self.control_mapper.get_control_description(self._control_id) or self._control_id
        ecr_check = self.control_mapper.get_ecr_check_for_control(self._control_id) or ""

        return [
            f"{HTML_H3_OPEN}Control Assessment{HTML_H3_CLOSE}",
            HTML_P_OPEN,
            f"{HTML_STRONG_OPEN}Control:{HTML_STRONG_CLOSE} {self._control_id} - {control_desc}{HTML_BR}",
            f"{HTML_STRONG_OPEN}ECR Check:{HTML_STRONG_CLOSE} {ecr_check}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Result:{HTML_STRONG_CLOSE} "
            f"<span style='color: {result_color};'>{self._compliance_result}</span>",
            HTML_P_CLOSE,
        ]

    def _build_remediation_section(self) -> List[str]:
        """Build remediation guidance for the failed control."""
        ecr_check = self.control_mapper.get_ecr_check_for_control(self._control_id) or ""
        section_parts = [
            f"{HTML_H3_OPEN}Remediation Guidance{HTML_H3_CLOSE}",
            HTML_UL_OPEN,
        ]

        if "ECR.1" in ecr_check:
            section_parts.append(
                f"{HTML_LI_OPEN}Enable scan-on-push or configure enhanced continuous scanning "
                f"for this repository via the ECR console or CLI{HTML_LI_CLOSE}"
            )
        if "ECR.2" in ecr_check:
            section_parts.append(
                f"{HTML_LI_OPEN}Enable tag immutability: "
                f"<code>aws ecr put-image-tag-mutability --repository-name {self._repo_name} "
                f"--image-tag-mutability IMMUTABLE</code>{HTML_LI_CLOSE}"
            )
        if "ECR.3" in ecr_check:
            section_parts.append(
                f"{HTML_LI_OPEN}Configure a lifecycle policy to automate image retention and cleanup. "
                f"See ECR lifecycle policy documentation{HTML_LI_CLOSE}"
            )
        if "ECR.5" in ecr_check:
            section_parts.append(
                f"{HTML_LI_OPEN}ECR encryption cannot be changed after repository creation. "
                f"Create a new repository with KMS encryption: "
                f"<code>aws ecr create-repository --repository-name {self._repo_name}-encrypted "
                f"--encryption-configuration encryptionType=KMS</code>{HTML_LI_CLOSE}"
            )

        section_parts.append(HTML_UL_CLOSE)
        return section_parts


class AWSECREvidenceIntegration(ComplianceIntegration):
    """Process AWS ECR repository data and create evidence/compliance records in RegScale.

    Assesses ECR repositories against NIST 800-53 controls and optionally collects
    Inspector V2 vulnerability findings for container images.
    """

    # ECR compliance findings are issues, not CVE vulnerabilities.
    # This ensures process_finding() routes through queue_issue_from_finding()
    # (the issues batch path) instead of _process_vulnerability_finding().
    skip_vulnerability_creation = True

    def __init__(self, config: ECREvidenceConfig):
        """
        Initialize AWS ECR evidence integration.

        :param ECREvidenceConfig config: Configuration object containing all parameters
        """
        super().__init__(
            plan_id=config.plan_id,
            framework=config.framework,
            create_issues=config.create_issues,
            update_control_status=config.update_control_status,
            create_poams=config.create_poams,
            parent_module=config.parent_module,
        )

        # Initialize API for file operations
        self.api = Api()

        self.region = config.region
        self.title = "AWS ECR"
        self.framework = config.framework

        # Evidence collection parameters
        self.collect_evidence = config.collect_evidence
        self.evidence_as_attachments = config.evidence_as_attachments
        self.evidence_control_ids = config.evidence_control_ids
        self.evidence_frequency = config.evidence_frequency

        # Cache control
        self.force_refresh = config.force_refresh

        # Filtering parameters
        self.account_id = config.account_id
        self.tags = config.tags or {}

        # Inspector findings toggle
        self.include_inspector_findings = config.include_inspector_findings

        # Initialize control mapper
        self.control_mapper = ECRControlMapper(framework=config.framework)

        # Extract AWS credentials from config
        profile = config.profile
        aws_access_key_id = config.aws_access_key_id
        aws_secret_access_key = config.aws_secret_access_key
        aws_session_token = config.aws_session_token

        # Initialize boto3 session
        if aws_access_key_id and aws_secret_access_key:
            logger.info("Initializing AWS ECR client with explicit credentials")
            self.session = boto3.Session(
                region_name=config.region,
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                aws_session_token=aws_session_token,
            )
        else:
            logger.info("Initializing AWS ECR client with profile: %s", profile if profile else "default")
            self.session = boto3.Session(profile_name=profile, region_name=config.region)

        try:
            self.ecr_client = make_aws_client(self.session, "ecr")
            logger.info("Successfully created AWS ECR client")
        except Exception as e:
            logger.error("Failed to create AWS ECR client: %s", e)
            raise

        # Initialize Inspector client if needed
        self.inspector_client = None
        if self.include_inspector_findings:
            try:
                self.inspector_client = make_aws_client(self.session, "inspector2")
                logger.info("Successfully created AWS Inspector V2 client")
            except Exception as e:
                logger.warning("Failed to create Inspector V2 client (findings will be skipped): %s", e)
                self.include_inspector_findings = False

        # Store raw data for evidence generation
        self.raw_ecr_data: List[Dict[str, Any]] = []
        self.raw_inspector_findings: List[Dict[str, Any]] = []

    # -------------------------------------------------------------------------
    # Cache Management
    # -------------------------------------------------------------------------

    def _is_cache_valid(self) -> bool:
        """
        Check if the cache file exists and is within the TTL.

        :return: True if cache is valid, False otherwise
        :rtype: bool
        """
        if not os.path.exists(ECR_CACHE_FILE):
            logger.debug("ECR cache file does not exist")
            return False

        file_age = time.time() - os.path.getmtime(ECR_CACHE_FILE)
        is_valid = file_age < CACHE_TTL_SECONDS

        if is_valid:
            hours_old = file_age / 3600
            logger.info("Using cached ECR data (age: %.1f hours)", hours_old)
        else:
            hours_old = file_age / 3600
            logger.debug("ECR cache expired (age: %.1f hours, TTL: %s hours)", hours_old, CACHE_TTL_SECONDS / 3600)

        return is_valid

    def _load_cached_data(self) -> List[Dict[str, Any]]:
        """
        Load ECR data from cache file.

        :return: List of raw ECR repository data from cache
        :rtype: List[Dict[str, Any]]
        """
        try:
            with open(ECR_CACHE_FILE, encoding="utf-8") as f:
                cached_data = json.load(f)

            if not isinstance(cached_data, list):
                logger.warning("Invalid ECR cache format (not a list). Invalidating cache.")
                return []

            if cached_data and not isinstance(cached_data[0], dict):
                logger.warning("Invalid ECR cache format (items not dicts). Invalidating cache.")
                return []

            logger.info("Loaded %d ECR repositories from cache", len(cached_data))
            return cached_data
        except (json.JSONDecodeError, IOError) as e:
            logger.warning("Error reading ECR cache file: %s. Fetching fresh data.", e)
            return []

    def _save_to_cache(self, ecr_data: List[Dict[str, Any]]) -> None:
        """
        Save ECR data to cache file.

        :param List ecr_data: Data to cache
        """
        try:
            os.makedirs(os.path.dirname(ECR_CACHE_FILE), exist_ok=True)
            with open(ECR_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(ecr_data, f, indent=2, default=str)
            logger.info("Cached %d ECR repositories to %s", len(ecr_data), ECR_CACHE_FILE)
        except IOError as e:
            logger.warning("Error writing to ECR cache file: %s", e)

    # -------------------------------------------------------------------------
    # Data Fetching
    # -------------------------------------------------------------------------

    def _fetch_fresh_ecr_data(self) -> List[Dict[str, Any]]:
        """
        Fetch fresh ECR repository data from AWS using ContainerCollector.

        Enriches each repository with scanning configuration from batch API.

        :return: List of ECR repository data
        :rtype: List[Dict[str, Any]]
        """
        logger.info("Fetching ECR repository data from AWS...")

        if self.account_id:
            logger.info("Filtering ECR repositories by account ID: %s", self.account_id)
        if self.tags:
            logger.info("Filtering ECR repositories by tags: %s", self.tags)

        from regscale.integrations.commercial.aws.inventory.resources.containers import (
            ContainerCollector,
        )

        collector = ContainerCollector(
            session=self.session,
            region=self.region,
            account_id=self.account_id,
            tags=self.tags,
            enabled_services={"ecr": True, "eks": False},
        )

        inventory = collector.collect()
        repositories = inventory.get("ECRRepositories", [])

        # Enrich with enhanced scanning configuration
        self._enrich_with_scanning_config(repositories)

        logger.info("Fetched %d ECR repositories from AWS (after filtering)", len(repositories))
        return repositories

    def _enrich_with_scanning_config(self, repositories: List[Dict[str, Any]]) -> None:
        """
        Enrich repositories with enhanced scanning configuration from batch API.

        :param List repositories: List of repository data dicts to enrich in-place
        """
        if not repositories:
            return

        repo_names = [r.get("RepositoryName") for r in repositories if r.get("RepositoryName")]
        if not repo_names:
            return

        try:
            # Batch API accepts up to 25 repo names at a time
            for i in range(0, len(repo_names), 25):
                batch = repo_names[i : i + 25]
                response = self.ecr_client.batch_get_repository_scanning_configuration(repositoryNames=batch)

                scan_configs = response.get("scanningConfigurations", [])
                config_map = {sc.get("repositoryName"): sc for sc in scan_configs}

                for repo in repositories:
                    name = repo.get("RepositoryName")
                    if name in config_map:
                        repo["ScanningConfiguration"] = config_map[name]

        except ClientError as e:
            from regscale.integrations.commercial.aws.common import handle_aws_client_error

            handle_aws_client_error(e, "fetching ECR scanning configuration", region=self.region)
        except Exception as e:
            logger.debug("Enhanced scanning configuration not available: %s", e)

    def _fetch_inspector_ecr_findings(self) -> List[Dict[str, Any]]:
        """
        Fetch Inspector V2 findings for ECR container images.

        :return: List of Inspector finding dicts
        :rtype: List[Dict[str, Any]]
        """
        if not self.inspector_client:
            return []

        logger.info("Fetching Inspector V2 findings for ECR container images...")
        findings = []

        try:
            paginator = self.inspector_client.get_paginator("list_findings")
            page_iterator = paginator.paginate(
                filterCriteria={
                    "resourceType": [
                        {
                            "comparison": "EQUALS",
                            "value": "AWS_ECR_CONTAINER_IMAGE",
                        }
                    ],
                },
                maxResults=100,
            )

            for page in page_iterator:
                findings.extend(page.get("findings", []))

            logger.info("Fetched %d Inspector V2 ECR findings", len(findings))

        except ClientError as e:
            from regscale.integrations.commercial.aws.common import handle_aws_client_error

            handle_aws_client_error(e, "fetching Inspector V2 ECR findings", region=self.region)
        except Exception as e:
            logger.warning("Inspector V2 not available or not enabled: %s", e)

        return findings

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Fetch raw ECR data from AWS.

        Uses cached data if available and not expired (4-hour TTL), unless force_refresh is True.
        Also fetches Inspector V2 findings if enabled.

        :return: List of raw ECR repository data
        :rtype: List[Dict[str, Any]]
        """
        # Check if we should use cached data
        if not self.force_refresh and self._is_cache_valid():
            cached_data = self._load_cached_data()
            if cached_data:
                self.raw_ecr_data = cached_data
                # Always fetch fresh Inspector findings (not cached)
                if self.include_inspector_findings:
                    self.raw_inspector_findings = self._fetch_inspector_ecr_findings()
                return cached_data

        if self.force_refresh:
            logger.info("Force refresh requested, bypassing cache and fetching fresh ECR data...")

        try:
            ecr_data = self._fetch_fresh_ecr_data()
            self.raw_ecr_data = ecr_data
            self._save_to_cache(ecr_data)

            # Fetch Inspector findings
            if self.include_inspector_findings:
                self.raw_inspector_findings = self._fetch_inspector_ecr_findings()

            return ecr_data
        except ClientError as e:
            from regscale.integrations.commercial.aws.common import handle_aws_client_error

            handle_aws_client_error(e, "fetching ECR data from AWS", region=self.region)
            return []

    # -------------------------------------------------------------------------
    # Compliance Processing (override)
    # -------------------------------------------------------------------------

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> List[ComplianceItem]:
        """
        Create compliance items from raw ECR repository data.

        ECR creates multiple compliance items (one per control) from each repository.

        :param Dict raw_data: Raw ECR repository data
        :return: List of compliance items for each control
        :rtype: List[ComplianceItem]
        """
        compliance_items = []
        control_results = self.control_mapper.assess_repository_compliance(raw_data)

        for control_id, result in control_results.items():
            compliance_item = ECRConfigComplianceItem(
                control_id=control_id,
                repo_data=raw_data,
                compliance_result=result,
                control_mapper=self.control_mapper,
            )
            compliance_items.append(compliance_item)

        return compliance_items

    def process_compliance_data(self) -> None:
        """
        Override process_compliance_data to handle ECR's multi-item pattern.

        ECR creates multiple compliance items per repository (one per control),
        and optionally processes Inspector V2 vulnerability findings.
        """
        logger.info("Processing ECR compliance data...")

        self._reset_compliance_state()
        raw_compliance_data = self.fetch_compliance_data()

        # Process ECR repository configuration compliance
        for raw_item in raw_compliance_data:
            try:
                compliance_items = self.create_compliance_item(raw_item)

                for compliance_item in compliance_items:
                    control_id = getattr(compliance_item, "control_id", "")
                    resource_id = getattr(compliance_item, "resource_id", "")

                    if not control_id or not resource_id:
                        continue

                    self.all_compliance_items.append(compliance_item)
                    self.asset_compliance_map[compliance_item.resource_id].append(compliance_item)

                    if compliance_item.compliance_result in self.FAIL_STATUSES:
                        self.failed_compliance_items.append(compliance_item)
                        self.failing_controls[control_id.lower()] = compliance_item
                    else:
                        self.passing_controls[control_id.lower()] = compliance_item

            except Exception as e:
                logger.error("Error processing ECR repository compliance data: %s", e)
                continue

        # Process Inspector V2 vulnerability findings as issues
        if self.raw_inspector_findings:
            self._process_inspector_findings()

        logger.info(
            "Processed %d compliance items: %d passing controls, %d failing controls, %d Inspector findings",
            len(self.all_compliance_items),
            len(self.passing_controls),
            len(self.failing_controls),
            len(self.raw_inspector_findings),
        )

    def _process_inspector_findings(self) -> None:
        """
        Process Inspector V2 ECR findings and queue them as issues.

        Findings are pre-consolidated by vulnerability ID (plugin_id) so that the
        same CVE across multiple ECR repositories produces a single issue instead of
        one per repository.  This matches the ``sync_findings`` pattern and ensures
        every queued issue has a non-null ``pluginId``, which is required for the
        batch issues endpoint when ``uniqueKeyFields=["pluginId"]``.
        """
        logger.info("Processing %d Inspector V2 ECR findings...", len(self.raw_inspector_findings))
        consolidated: Dict[str, Any] = {}

        for finding in self.raw_inspector_findings:
            parsed = self._parse_inspector_finding(finding)
            if parsed is None:
                continue
            integration_finding, stable_plugin_id = parsed
            if stable_plugin_id in consolidated:
                if integration_finding.asset_identifier:
                    existing = consolidated[stable_plugin_id]
                    existing_ids = {a for a in (existing.asset_identifier or "").split("\n") if a}
                    existing_ids.add(integration_finding.asset_identifier)
                    existing.asset_identifier = "\n".join(sorted(existing_ids))
            else:
                consolidated[stable_plugin_id] = integration_finding

        for f in consolidated.values():
            self.queue_issue_from_finding(issue_title=f.title, finding=f)

        logger.info(
            "Consolidated %d Inspector findings to %d unique vulnerabilities",
            len(self.raw_inspector_findings),
            len(consolidated),
        )

    def _parse_inspector_finding(self, finding: dict) -> Optional[tuple]:
        """
        Parse a single Inspector V2 raw finding into an IntegrationFinding.

        :param dict finding: Raw Inspector V2 finding dict
        :return: (IntegrationFinding, stable_plugin_id) or None on error
        :rtype: Optional[tuple]
        """
        from regscale.integrations.scanner_integration import IntegrationFinding
        from regscale.models.regscale_models.issue import IssueStatus

        try:
            finding_arn = finding.get("findingArn", "")
            title = finding.get("title", "ECR Vulnerability Finding")
            description_text = finding.get("description", "")
            severity_label = finding.get("severity", "MEDIUM")
            finding_status = finding.get("status", "ACTIVE")

            vuln_details = finding.get("packageVulnerabilityDetails", {})
            vulnerability_id = vuln_details.get("vulnerabilityId", "")
            source_url = vuln_details.get("sourceUrl", "")
            stable_plugin_id = vulnerability_id or self.hash_string(finding_arn)

            cvss_score = self._extract_inspector_cvss(vuln_details.get("cvss", []))
            package_info = self._extract_inspector_package_info(vuln_details)
            repo_name, asset_identifier = self._extract_inspector_asset_info(finding.get("resources", []))

            remediation = finding.get("remediation", {}).get("recommendation", {})
            description = self._build_inspector_description(
                vulnerability_id,
                repo_name,
                severity_label,
                cvss_score,
                package_info,
                source_url,
                description_text,
                remediation.get("text", ""),
            )

            issue_severity = INSPECTOR_SEVERITY_MAP.get(severity_label, IssueSeverity.Moderate)
            integration_finding = IntegrationFinding(
                control_labels=["RA-5"],
                title=f"{vulnerability_id}: {title[:100]}{package_info}" if vulnerability_id else title[:150],
                category="Vulnerability",
                plugin_name="AWS Inspector V2 - ECR",
                plugin_id=stable_plugin_id,
                severity=issue_severity,
                description=description,
                status=IssueStatus.Open if finding_status == "ACTIVE" else IssueStatus.Closed,
                cve=vulnerability_id if vulnerability_id.startswith("CVE-") else None,
                cvss_v3_score=cvss_score,
                external_id=finding_arn,
                asset_identifier=asset_identifier,
                source="AWS Inspector V2",
            )
            return integration_finding, stable_plugin_id
        except Exception as e:
            logger.error("Error processing Inspector finding: %s", e)
            return None

    @staticmethod
    def _extract_inspector_cvss(cvss_entries: list) -> Optional[float]:
        """Return the highest-priority CVSS base score (v3 preferred, else v2).

        :param list cvss_entries: List of CVSS dicts from packageVulnerabilityDetails
        :return: CVSS base score or None
        :rtype: Optional[float]
        """
        for entry in cvss_entries:
            if entry.get("version", "").startswith("3"):
                return entry.get("baseScore")
        return cvss_entries[0].get("baseScore") if cvss_entries else None

    @staticmethod
    def _extract_inspector_package_info(vuln_details: dict) -> str:
        """Return a human-readable package string from packageVulnerabilityDetails.

        :param dict vuln_details: packageVulnerabilityDetails dict
        :return: Package info string or empty string
        :rtype: str
        """
        packages = vuln_details.get("vulnerablePackages", [])
        if not packages:
            return ""
        pkg = packages[0]
        return (
            f" (Package: {pkg.get('name', 'unknown')} {pkg.get('version', 'unknown')},"
            f" Fix: {pkg.get('fixedInVersion', 'N/A')})"
        )

    @staticmethod
    def _extract_inspector_asset_info(resources: list) -> tuple:
        """Extract (repo_name, asset_identifier) from a finding's resources list.

        :param list resources: resources list from the raw Inspector finding
        :return: (repo_name, asset_identifier) — both empty strings if not found
        :rtype: tuple
        """
        for resource in resources:
            ecr_details = resource.get("details", {}).get("awsEcrContainerImage", {})
            if ecr_details:
                return ecr_details.get("repositoryName", ""), resource.get("id", "")
        return "", ""

    @staticmethod
    def _build_inspector_description(
        vulnerability_id: str,
        repo_name: str,
        severity_label: str,
        cvss_score: Optional[float],
        package_info: str,
        source_url: str,
        description_text: str,
        remediation_text: str,
    ) -> str:
        """Build the HTML description for an Inspector V2 ECR finding.

        :param str vulnerability_id: CVE or vulnerability identifier
        :param str repo_name: ECR repository name
        :param str severity_label: Severity label from Inspector
        :param Optional[float] cvss_score: CVSS base score
        :param str package_info: Formatted affected package string
        :param str source_url: Reference URL for the vulnerability
        :param str description_text: Raw description text from Inspector
        :param str remediation_text: Remediation recommendation text
        :return: HTML description string
        :rtype: str
        """
        parts = [
            f"{HTML_H3_OPEN}ECR Container Image Vulnerability{HTML_H3_CLOSE}",
            f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Vulnerability:{HTML_STRONG_CLOSE} {vulnerability_id}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Repository:{HTML_STRONG_CLOSE} {repo_name}{HTML_BR}",
            f"{HTML_STRONG_OPEN}Severity:{HTML_STRONG_CLOSE} {severity_label}{HTML_BR}",
        ]
        if cvss_score is not None:
            parts.append(f"{HTML_STRONG_OPEN}CVSS Score:{HTML_STRONG_CLOSE} {cvss_score}{HTML_BR}")
        if package_info:
            parts.append(f"{HTML_STRONG_OPEN}Affected:{HTML_STRONG_CLOSE}{package_info}{HTML_BR}")
        if source_url:
            parts.append(f"{HTML_STRONG_OPEN}Reference:{HTML_STRONG_CLOSE} {source_url}{HTML_BR}")
        parts.append(f"{HTML_P_OPEN}{description_text}{HTML_P_CLOSE}")
        parts.append(HTML_P_CLOSE)
        if remediation_text:
            parts.append(f"{HTML_H3_OPEN}Remediation{HTML_H3_CLOSE}{HTML_P_OPEN}{remediation_text}{HTML_P_CLOSE}")
        return "".join(parts)

    def _map_resource_type_to_asset_type(self, compliance_item: ComplianceItem) -> str:
        """
        Map ECR repository to RegScale asset type.

        :param ComplianceItem compliance_item: Compliance item
        :return: Asset type string
        :rtype: str
        """
        return "AWS ECR Repository"

    # -------------------------------------------------------------------------
    # Issue Consolidation (override base class)
    # -------------------------------------------------------------------------

    def fetch_findings(self, *args, **kwargs):
        """
        Override base fetch_findings to consolidate issues by ECR check per repository.

        Instead of creating one issue per NIST control (which causes duplicates when multiple
        controls map to the same underlying ECR check), this creates one issue per ECR check
        (ECR.1, ECR.2, ECR.3, ECR.5) per repository with all applicable control_labels.

        This matches how sync_findings deduplicates via plugin_id in other AWS integrations.

        :return: Iterator of consolidated IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        from regscale.integrations.scanner_integration import IntegrationFinding
        from regscale.models.regscale_models.issue import IssueStatus

        total_failed = len(self.failed_compliance_items)
        logger.info("Consolidating %d failed compliance items into ECR check-level issues...", total_failed)

        repo_failed_checks, repo_data_map = self._build_repo_check_maps()

        findings_count = 0
        for repo_arn, failed_checks in repo_failed_checks.items():
            repo_data = repo_data_map.get(repo_arn, {})
            repo_name = repo_data.get("RepositoryName") or repo_arn.rsplit("/", 1)[-1]
            for ecr_check in sorted(failed_checks):
                yield self._make_ecr_compliance_finding(
                    repo_arn, repo_name, ecr_check, repo_data, IntegrationFinding, IssueStatus
                )
                findings_count += 1

        logger.info("ECR issue consolidation: %d issues created from %d failed items", findings_count, total_failed)

    def _build_repo_check_maps(self) -> tuple:
        """Build maps of repo ARN -> failed ECR checks and repo ARN -> repo data dict.

        Combines information from ``failed_compliance_items`` (control-level results)
        and ``raw_ecr_data`` (direct repository attribute assessment) so no failing
        check is missed.

        :return: (repo_failed_checks, repo_data_map)
        :rtype: tuple
        """
        repo_failed_checks: Dict[str, set] = {}
        repo_data_map: Dict[str, Dict[str, Any]] = {}

        for item in self.failed_compliance_items:
            repo_arn = item.resource_id
            repo_data_map[repo_arn] = item.repo_data
            ecr_check_str = self.control_mapper.get_ecr_check_for_control(item.control_id)
            if ecr_check_str:
                for check in ecr_check_str.split(","):
                    repo_failed_checks.setdefault(repo_arn, set()).add(check.strip())

        for repo_data in self.raw_ecr_data:
            repo_arn = repo_data.get("RepositoryArn", "")
            if repo_arn:
                repo_data_map[repo_arn] = repo_data
                for check in self.control_mapper.get_failed_ecr_checks(repo_data):
                    repo_failed_checks.setdefault(repo_arn, set()).add(check)

        return repo_failed_checks, repo_data_map

    def _make_ecr_compliance_finding(
        self,
        repo_arn: str,
        repo_name: str,
        ecr_check: str,
        repo_data: dict,
        integration_finding_cls: type,
        issue_status_cls: type,
    ):
        """Create one IntegrationFinding for a single (repo, ECR check) pair.

        :param str repo_arn: Repository ARN used as asset_identifier
        :param str repo_name: Human-readable repository name
        :param str ecr_check: ECR check identifier (e.g. "ECR.1")
        :param dict repo_data: Raw ECR repository data dict
        :param type integration_finding_cls: IntegrationFinding class (lazy-imported by caller)
        :param type issue_status_cls: IssueStatus class (lazy-imported by caller)
        :return: Populated IntegrationFinding
        """
        control_labels = self.control_mapper.get_controls_for_ecr_check(ecr_check)
        check_desc = self.control_mapper.get_ecr_check_description(ecr_check)
        severity_str = self.control_mapper.get_ecr_check_severity(ecr_check)
        severity = IssueSeverity.High if severity_str == "HIGH" else IssueSeverity.Moderate
        desc = self._build_ecr_check_desc(ecr_check, check_desc, repo_name, repo_arn, repo_data, control_labels)

        return integration_finding_cls(
            control_labels=control_labels,
            title=f"{ecr_check}: {check_desc}",
            category="Compliance",
            plugin_name=f"AWS ECR - {ecr_check}",
            plugin_id=ecr_check,
            severity=severity,
            description=desc,
            status=issue_status_cls.Open,
            priority="High" if severity_str == "HIGH" else "Medium",
            external_id=f"aws-ecr-{ecr_check}",
            first_seen=self.scan_date,
            last_seen=self.scan_date,
            scan_date=self.scan_date,
            asset_identifier=repo_arn,
            vulnerability_type="Compliance Violation",
            rule_id=control_labels[0] if control_labels else ecr_check,
            baseline=self.framework,
            affected_controls=", ".join(control_labels),
            source="AWS ECR",
        )

    @staticmethod
    def _build_ecr_check_desc(
        ecr_check: str,
        check_desc: str,
        repo_name: str,
        repo_arn: str,
        repo_data: dict,
        control_labels: list,
    ) -> str:
        """Build the HTML description for an ECR compliance check finding.

        :param str ecr_check: ECR check identifier (e.g. "ECR.1")
        :param str check_desc: Human-readable check description
        :param str repo_name: Repository name
        :param str repo_arn: Repository ARN
        :param dict repo_data: Raw ECR repository data
        :param list control_labels: NIST control labels that map to this check
        :return: HTML description string
        :rtype: str
        """
        encryption_type = repo_data.get("EncryptionConfiguration", {}).get("encryptionType", "AES256")
        scan_on_push = repo_data.get("ImageScanningConfiguration", {}).get("scanOnPush", False)
        tag_mutability = repo_data.get("ImageTagMutability", "MUTABLE")
        lifecycle = "Yes" if repo_data.get("LifecyclePolicy") else "No"
        return (
            f"{HTML_H3_OPEN}{ecr_check}: {check_desc}{HTML_H3_CLOSE}"
            f"{HTML_P_OPEN}"
            f"{HTML_STRONG_OPEN}Repository:{HTML_STRONG_CLOSE} {repo_name}{HTML_BR}"
            f"{HTML_STRONG_OPEN}ARN:{HTML_STRONG_CLOSE} {repo_arn}{HTML_BR}"
            f"{HTML_STRONG_OPEN}Scan on Push:{HTML_STRONG_CLOSE} {'Yes' if scan_on_push else 'No'}{HTML_BR}"
            f"{HTML_STRONG_OPEN}Tag Immutability:{HTML_STRONG_CLOSE} {tag_mutability}{HTML_BR}"
            f"{HTML_STRONG_OPEN}Lifecycle Policy:{HTML_STRONG_CLOSE} {lifecycle}{HTML_BR}"
            f"{HTML_STRONG_OPEN}Encryption:{HTML_STRONG_CLOSE} {encryption_type}{HTML_BR}"
            f"{HTML_STRONG_OPEN}Mapped Controls:{HTML_STRONG_CLOSE} {', '.join(control_labels)}"
            f"{HTML_P_CLOSE}"
        )

    # -------------------------------------------------------------------------
    # Issue Sync Override — same pattern as aws sync_findings
    # -------------------------------------------------------------------------

    def _build_issue_batch_options(self):
        """
        Build batch options for ECR issue creation.

        Overrides the base class to use ``pluginId`` as the unique key, matching
        the pattern used by ``sync_findings`` (AWS Security Hub).  All repositories
        failing the same ECR check share the same ``pluginId`` (e.g. ``"ECR.1"``),
        so they are consolidated into one issue per control across runs.

        :return: IssueBatchOptions configured for ECR
        :rtype: IssueBatchOptions
        """
        from regscale.models.regscale_models.batch_options import IssueBatchOptions

        return IssueBatchOptions(
            source="AWS",
            uniqueKeyFields=["pluginId"],
            enableMopUp=False,  # Mop-up disabled until batchCreateOrUpdate is confirmed working
            parentId=self.plan_id,
            parentModule=self.parent_module,
            assetIdentifierFieldName=self.asset_identifier_field,
        )

    def _sync_issues(self) -> None:
        """
        Override to route findings through the same path as aws sync_findings.

        Flow:
        1. Collect consolidated findings from fetch_findings()
        2. Filter by SSP control match
        3. update_regscale_findings() — with skip_vulnerability_creation=True,
           process_finding() routes each finding through queue_issue_from_finding()
           which queues issues for batch submission
        4. _batch_submit_pending_issues() — flushes the batch via the issues
           endpoint with uniqueKeyFields=["pluginId"] for server-side dedup.
           All repositories failing the same ECR check share a pluginId (e.g.
           "ECR.1"), so repeated runs update the existing issue instead of
           creating duplicates.
        """
        if not self.create_issues:
            logger.info("Issue creation disabled (create_issues=False), skipping issue sync")
            return

        findings = list(self.fetch_findings())
        if not findings:
            logger.info("No ECR compliance findings to process")
            return

        # Filter to findings whose lead control has a matching SSP implementation
        matched_ids = self._matched_control_ids
        if matched_ids:
            filtered = [f for f in findings if self._finding_has_matching_control(f)]
            skipped = len(findings) - len(filtered)
            logger.info(
                "ECR compliance: %d/%d findings match SSP controls (%d skipped — control not in SSP)",
                len(filtered),
                len(findings),
                skipped,
            )
            findings = filtered

        if not findings:
            logger.info("No ECR findings with matching SSP controls to process")
            return

        # Load asset map so process_finding can link findings to assets
        if not self.asset_map_by_identifier:
            self.asset_map_by_identifier.update(self.get_asset_map())

        # Pre-consolidate by plugin_id so each failing ECR check produces a single
        # finding (matching the sync_findings pattern).  Without this, 156 per-repo
        # findings would produce 156 issues instead of ~4 (one per unique ECR check).
        findings = self._consolidate_ecr_findings_by_plugin_id(findings)

        # Process findings through the scanner pipeline — skip_vulnerability_creation=True
        # means process_finding() calls queue_issue_from_finding() for each finding
        logger.info("Processing %d ECR findings via issue batch path...", len(findings))
        self.update_regscale_findings(iter(findings))

        # Flush queued issues via the issues batch endpoint with integrationFindingId dedup
        self._batch_submit_pending_issues(progress=self.finding_progress)

    def _consolidate_ecr_findings_by_plugin_id(self, findings: list) -> list:
        """Consolidate per-repo ECR findings into one finding per ECR check (plugin_id).

        ``fetch_findings`` emits one finding per (repo, ECR check) pair.  Before passing
        them to ``update_regscale_findings``, this method merges all findings that share
        the same ``plugin_id`` so the batch endpoint receives a single issue per check
        with a combined ``asset_identifier`` listing all affected repositories.

        :param list findings: List of IntegrationFinding objects from fetch_findings()
        :return: Deduplicated list with one entry per unique plugin_id
        :rtype: list
        """
        seen: Dict[str, Any] = {}
        for finding in findings:
            key = finding.plugin_id or finding.external_id
            if key in seen:
                existing = seen[key]
                if finding.asset_identifier:
                    existing_ids = {a for a in (existing.asset_identifier or "").split("\n") if a}
                    existing_ids.add(finding.asset_identifier)
                    existing.asset_identifier = "\n".join(sorted(existing_ids))
            else:
                seen[key] = finding
        result = list(seen.values())
        if len(result) < len(findings):
            logger.info(
                "Consolidated ECR compliance findings by plugin_id: %d -> %d (%.1fx reduction)",
                len(findings),
                len(result),
                len(findings) / max(len(result), 1),
            )
        return result

    # -------------------------------------------------------------------------
    # Sync Orchestration
    # -------------------------------------------------------------------------

    def _load_existing_plugin_ids(self) -> Set[str]:
        """Load pluginId values of all issues already in the security plan for dedup.

        Tries ``pluginId`` first.  When the ``batchCreate`` fallback was used on a
        prior run the server may not have persisted ``pluginId``, so the method also
        parses ``integrationFindingId`` (format ``"<planId>:<pluginId>"``) as a
        fallback so that repeated runs still deduplicate correctly.

        :return: Set of plugin-ID strings (empty set on error or when plan has no issues)
        :rtype: Set[str]
        """
        from regscale.models.regscale_models.issue import Issue

        try:
            existing: list = Issue.get_all_by_parent(self.plan_id, self.parent_module) or []
            logger.debug(
                "get_all_by_parent returned %d issues for plan %d",
                len(existing),
                self.plan_id,
            )
            ids: Set[str] = set()
            for issue in existing:
                # Prefer the stored pluginId field
                plugin_id = getattr(issue, "pluginId", None)
                if plugin_id:
                    ids.add(plugin_id)
                    continue
                # batchCreate fallback may not persist pluginId; extract from integrationFindingId
                ifd = getattr(issue, "integrationFindingId", None)
                if ifd and ":" in ifd:
                    ids.add(ifd.split(":", 1)[1])

            logger.info(
                "Loaded %d existing issue identifiers from security plan %d for client-side dedup"
                " (raw issues: %d, with pluginId: %d, from integrationFindingId: %d)",
                len(ids),
                self.plan_id,
                len(existing),
                sum(1 for i in existing if getattr(i, "pluginId", None)),
                len(ids) - sum(1 for i in existing if getattr(i, "pluginId", None)),
            )
            return ids
        except Exception as exc:
            logger.warning("Could not load existing issue identifiers (dedup skipped): %s", exc)
            return set()

    def queue_issue_from_finding(
        self,
        issue_title: str,
        finding,
        **kwargs,
    ) -> None:
        """Queue an issue only if its pluginId does not already exist in the security plan.

        Overrides the base class to apply client-side deduplication by ``pluginId``
        before the issue reaches the batch queue.  This ensures that repeated sync
        runs do not re-create issues that the batch endpoint already created on a
        prior run, regardless of whether ``batchCreateOrUpdate`` succeeded or fell
        back to ``batchCreate``.

        :param str issue_title: Title for the queued issue
        :param finding: IntegrationFinding carrying the finding data
        :param kwargs: Forwarded to the base class
        :rtype: None
        """
        plugin_id = getattr(finding, "plugin_id", None)
        existing: Set[str] = getattr(self, "_existing_plugin_ids", set())
        if plugin_id and plugin_id in existing:
            logger.debug("Skipping already-synced pluginId: %s", plugin_id)
            return
        super().queue_issue_from_finding(issue_title=issue_title, finding=finding, **kwargs)

    def sync_compliance(self) -> None:
        """
        Main method to sync ECR compliance data.

        Extends base sync_compliance to add evidence collection support.
        Loads existing issue pluginIds before syncing so that
        ``queue_issue_from_finding`` can skip already-present issues.
        """
        self._existing_plugin_ids: Set[str] = self._load_existing_plugin_ids()
        super().sync_compliance()

        if self.collect_evidence:
            logger.info("Evidence collection enabled, starting ECR evidence collection...")
            self._collect_ecr_evidence()

    # -------------------------------------------------------------------------
    # Evidence Collection
    # -------------------------------------------------------------------------

    def _collect_ecr_evidence(self) -> None:
        """
        Collect ECR evidence and create Evidence records or SSP attachments.
        """
        if not self.raw_ecr_data:
            logger.warning("No ECR data available for evidence collection")
            return

        scan_date = get_current_datetime(dt_format="%Y%m%d_%H%M%S")

        if self.evidence_as_attachments:
            logger.info("Creating SSP file attachment with ECR evidence...")
            self._create_ssp_attachment(scan_date)
        else:
            logger.info("Creating Evidence record with ECR evidence...")
            self._create_evidence_record(scan_date)

    def _create_ssp_attachment(self, scan_date: str) -> None:
        """
        Create SSP file attachment with ECR evidence data.

        :param str scan_date: Scan date string
        """
        try:
            date_str = datetime.now().strftime("%Y%m%d")
            account_suffix = f"_{self.account_id}" if self.account_id else ""
            file_name_pattern = f"ecr_evidence{account_suffix}_{date_str}"

            if self.check_for_existing_evidence(file_name_pattern):
                logger.info("Evidence file for ECR already exists for today. Skipping upload to avoid duplicates.")
                return

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"ecr_evidence{account_suffix}_{timestamp}.jsonl.gz"

            # Prepare JSONL content with compliance results
            jsonl_lines = []
            for repo_data in self.raw_ecr_data:
                control_results = self.control_mapper.assess_repository_compliance(repo_data)
                evidence_entry = {
                    **repo_data,
                    "compliance_assessment": {
                        "overall_result": "FAIL" if "FAIL" in control_results.values() else "PASS",
                        "control_results": control_results,
                        "assessed_controls": list(control_results.keys()),
                        "assessment_date": scan_date,
                    },
                }
                jsonl_lines.append(json.dumps(evidence_entry, default=str))

            # Include Inspector findings if available
            if self.raw_inspector_findings:
                inspector_summary = {
                    "type": "inspector_v2_ecr_findings_summary",
                    "total_findings": len(self.raw_inspector_findings),
                    "findings": [
                        {
                            "findingArn": f.get("findingArn"),
                            "severity": f.get("severity"),
                            "title": f.get("title"),
                            "vulnerabilityId": f.get("packageVulnerabilityDetails", {}).get("vulnerabilityId"),
                        }
                        for f in self.raw_inspector_findings[:500]  # Cap at 500 for file size
                    ],
                    "assessment_date": scan_date,
                }
                jsonl_lines.append(json.dumps(inspector_summary, default=str))

            jsonl_content = "\n".join(jsonl_lines)

            # Compress
            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz_file:
                gz_file.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()
            compressed_size_mb = len(compressed_data) / (1024 * 1024)
            uncompressed_size_mb = len(jsonl_content.encode("utf-8")) / (1024 * 1024)
            compression_ratio = (1 - (len(compressed_data) / max(len(jsonl_content.encode("utf-8")), 1))) * 100

            logger.info(
                "Compressed ECR evidence: %.2f MB -> %.2f MB (%.1f%% reduction)",
                uncompressed_size_mb,
                compressed_size_mb,
                compression_ratio,
            )

            # Upload to SSP
            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=self.plan_id,
                parent_module=self.parent_module,
                api=api,
                file_data=compressed_data,
                tags="aws,ecr,container,compliance,automated",
            )

            if success:
                logger.info("Successfully uploaded ECR evidence file to SSP %d: %s", self.plan_id, file_name)
            else:
                logger.error("Failed to upload ECR evidence file to SSP %d", self.plan_id)

        except Exception as e:
            logger.error("Error creating SSP attachment for ECR evidence: %s", e, exc_info=True)

    def _create_evidence_record(self, scan_date: str) -> None:
        """
        Create Evidence record with ECR evidence data.

        :param str scan_date: Scan date string
        """
        try:
            title = f"AWS ECR Evidence - {scan_date}"
            description = self._build_evidence_description(scan_date)
            due_date = (datetime.now() + timedelta(days=self.evidence_frequency)).isoformat()

            evidence = Evidence(
                title=title,
                description=description,
                status="Collected",
                updateFrequency=self.evidence_frequency,
                dueDate=due_date,
            )

            created_evidence = evidence.create()
            if not created_evidence or not created_evidence.id:
                logger.error("Failed to create ECR evidence record")
                return

            logger.info("Created ECR evidence record %d: %s", created_evidence.id, title)

            # Upload compressed evidence file
            self._upload_evidence_file(created_evidence.id, scan_date)

            # Link evidence to SSP
            self._link_evidence_to_ssp(created_evidence.id)

            # Link to controls if specified
            if self.evidence_control_ids:
                self._link_evidence_to_controls(created_evidence.id, is_attachment=False)

        except Exception as e:
            logger.error("Error creating evidence record for ECR: %s", e, exc_info=True)

    def _build_evidence_description(self, scan_date: str) -> str:
        """
        Build HTML-formatted evidence description.

        :param str scan_date: Scan date string
        :return: HTML description
        :rtype: str
        """
        ecr_stats = self._calculate_ecr_statistics()
        control_stats = self._calculate_control_compliance_stats()

        desc_parts = [
            "<h1>AWS ECR Evidence</h1>",
            f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Assessment Date:{HTML_STRONG_CLOSE} {scan_date}{HTML_P_CLOSE}",
            f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Region:{HTML_STRONG_CLOSE} {self.region}{HTML_P_CLOSE}",
        ]

        # Filter info
        if self.account_id:
            desc_parts.append(
                f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Filtered by Account ID:{HTML_STRONG_CLOSE} "
                f"{self.account_id}{HTML_P_CLOSE}"
            )
        if self.tags:
            tags_str = ", ".join(f"{k}={v}" for k, v in self.tags.items())
            desc_parts.append(
                f"{HTML_P_OPEN}{HTML_STRONG_OPEN}Filtered by Tags:{HTML_STRONG_CLOSE} {tags_str}{HTML_P_CLOSE}"
            )

        # ECR summary
        desc_parts.extend(
            [
                f"{HTML_H2_OPEN}Summary{HTML_H2_CLOSE}",
                HTML_UL_OPEN,
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Total Repositories:{HTML_STRONG_CLOSE} "
                f"{ecr_stats['total']}{HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Scanning Enabled:{HTML_STRONG_CLOSE} "
                f"{ecr_stats['scanning_enabled']} ({ecr_stats['scanning_pct']:.1f}%){HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Tag Immutable:{HTML_STRONG_CLOSE} "
                f"{ecr_stats['tag_immutable']} ({ecr_stats['tag_immutable_pct']:.1f}%){HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Lifecycle Configured:{HTML_STRONG_CLOSE} "
                f"{ecr_stats['lifecycle_configured']} ({ecr_stats['lifecycle_pct']:.1f}%){HTML_LI_CLOSE}",
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}KMS Encrypted:{HTML_STRONG_CLOSE} "
                f"{ecr_stats['kms_encrypted']} ({ecr_stats['kms_pct']:.1f}%){HTML_LI_CLOSE}",
            ]
        )

        if self.raw_inspector_findings:
            desc_parts.append(
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}Inspector V2 Findings:{HTML_STRONG_CLOSE} "
                f"{len(self.raw_inspector_findings)}{HTML_LI_CLOSE}"
            )

        desc_parts.append(HTML_UL_CLOSE)

        # Control compliance summary
        desc_parts.extend(
            [
                f"{HTML_H2_OPEN}Control Compliance Results{HTML_H2_CLOSE}",
                HTML_UL_OPEN,
            ]
        )

        for control_id in sorted(control_stats.keys()):
            stats = control_stats[control_id]
            total = stats["pass"] + stats["fail"]
            pass_pct = stats["pass"] / max(total, 1) * 100
            control_desc = self.control_mapper.get_control_description(control_id) or control_id
            desc_parts.append(
                f"{HTML_LI_OPEN}{HTML_STRONG_OPEN}{control_id}:{HTML_STRONG_CLOSE} "
                f"{stats['pass']} PASS / {stats['fail']} FAIL ({pass_pct:.1f}% compliant) - "
                f"{control_desc}{HTML_LI_CLOSE}"
            )

        desc_parts.append(HTML_UL_CLOSE)

        return "".join(desc_parts)

    def _calculate_ecr_statistics(self) -> Dict[str, Any]:
        """Calculate ECR repository statistics."""
        total = len(self.raw_ecr_data)

        scanning_enabled = sum(
            1
            for r in self.raw_ecr_data
            if r.get("ImageScanningConfiguration", {}).get("scanOnPush", False)
            or r.get("ScanningConfiguration", {}).get("scanFrequency") in ("SCAN_ON_PUSH", "CONTINUOUS_SCAN")
        )

        tag_immutable = sum(1 for r in self.raw_ecr_data if r.get("ImageTagMutability") == "IMMUTABLE")

        lifecycle_configured = sum(1 for r in self.raw_ecr_data if r.get("LifecyclePolicy") is not None)

        kms_encrypted = sum(
            1
            for r in self.raw_ecr_data
            if r.get("EncryptionConfiguration", {}).get("encryptionType") == "KMS"
            and r.get("EncryptionConfiguration", {}).get("kmsKey")
        )

        return {
            "total": total,
            "scanning_enabled": scanning_enabled,
            "scanning_pct": scanning_enabled / max(total, 1) * 100,
            "tag_immutable": tag_immutable,
            "tag_immutable_pct": tag_immutable / max(total, 1) * 100,
            "lifecycle_configured": lifecycle_configured,
            "lifecycle_pct": lifecycle_configured / max(total, 1) * 100,
            "kms_encrypted": kms_encrypted,
            "kms_pct": kms_encrypted / max(total, 1) * 100,
        }

    def _calculate_control_compliance_stats(self) -> Dict[str, Dict[str, int]]:
        """Calculate compliance statistics by control."""
        control_stats = {control_id: {"pass": 0, "fail": 0} for control_id in self.control_mapper.get_mapped_controls()}

        for repo_data in self.raw_ecr_data:
            control_results = self.control_mapper.assess_repository_compliance(repo_data)
            for control_id, result in control_results.items():
                if result == "PASS":
                    control_stats[control_id]["pass"] += 1
                else:
                    control_stats[control_id]["fail"] += 1

        return control_stats

    def _upload_evidence_file(self, evidence_id: int, scan_date: str) -> None:
        """
        Upload compressed JSONL evidence file to Evidence record.

        :param int evidence_id: Evidence record ID
        :param str scan_date: Scan date string
        """
        try:
            jsonl_lines = []
            for repo_data in self.raw_ecr_data:
                control_results = self.control_mapper.assess_repository_compliance(repo_data)
                evidence_entry = {
                    **repo_data,
                    "compliance_assessment": {
                        "overall_result": "FAIL" if "FAIL" in control_results.values() else "PASS",
                        "control_results": control_results,
                        "assessed_controls": list(control_results.keys()),
                        "assessment_date": scan_date,
                    },
                }
                jsonl_lines.append(json.dumps(evidence_entry, default=str))

            jsonl_content = "\n".join(jsonl_lines)

            compressed_buffer = BytesIO()
            with gzip.open(compressed_buffer, "wt", encoding="utf-8", compresslevel=9) as gz_file:
                gz_file.write(jsonl_content)

            compressed_data = compressed_buffer.getvalue()

            file_name = f"ecr_evidence_{scan_date}.jsonl.gz"
            api = Api()
            success = File.upload_file_to_regscale(
                file_name=file_name,
                parent_id=evidence_id,
                parent_module="evidence",
                api=api,
                file_data=compressed_data,
                tags="aws,ecr,container,compliance",
            )

            if success:
                logger.info("Uploaded ECR evidence file to Evidence %d", evidence_id)
            else:
                logger.warning("Failed to upload ECR evidence file to Evidence %d", evidence_id)

        except Exception as e:
            logger.error("Error uploading ECR evidence file: %s", e, exc_info=True)

    def _link_evidence_to_ssp(self, evidence_id: int) -> None:
        """
        Link evidence to Security Plan.

        :param int evidence_id: Evidence record ID
        """
        try:
            mapping = EvidenceMapping(
                evidenceID=evidence_id,
                mappedID=self.plan_id,
                mappingType=self.parent_module,
            )
            mapping.create()
            logger.info("Linked ECR evidence %d to SSP %d", evidence_id, self.plan_id)
        except Exception as ex:
            logger.warning("Failed to link ECR evidence to SSP: %s", ex)

    def _link_evidence_to_controls(self, evidence_id: int, is_attachment: bool = False) -> None:
        """
        Link evidence to specified control IDs.

        :param int evidence_id: Evidence or attachment ID
        :param bool is_attachment: True if linking attachment, False for evidence record
        """
        try:
            for control_id in self.evidence_control_ids:
                if is_attachment:
                    self.api.link_ssp_attachment_to_control(self.plan_id, evidence_id, control_id)
                else:
                    self.api.link_evidence_to_control(evidence_id, control_id)
                logger.info("Linked ECR evidence %d to control %s", evidence_id, control_id)
        except Exception as e:
            logger.error("Failed to link ECR evidence to controls: %s", e, exc_info=True)
