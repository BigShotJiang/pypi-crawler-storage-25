#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike Scanner Integration for RegScale.

Syncs vulnerabilities from CrowdStrike Spotlight and assets from CrowdStrike Hosts
to RegScale using the ScannerIntegration base class.
"""

import logging
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from typing import Generator, Optional

from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
)

logger = logging.getLogger("regscale")

# Spotlight combined endpoint accepts up to 5000 records per page; 500 cuts request
# count 5x vs the prior 100 without inflating per-page parse cost noticeably.
_SPOTLIGHT_BATCH_SIZE = 500

# Hosts scroll + details endpoints both accept up to 5000 IDs per call; 500 keeps
# each detail response well under the FalconPy 6 MB body cap.
_HOSTS_BATCH_SIZE = 500

# Number of concurrent get_device_details_v2 calls in flight while the scroll
# cursor advances. Scroll itself must stay sequential (cursor-driven), but the
# detail hydration is independent per page and dominates wall-clock time.
_HOSTS_DETAIL_CONCURRENCY = 4

# Severity mapping from CrowdStrike Spotlight to RegScale
_SEVERITY_MAP = {
    "critical": "Critical",
    "high": "High",
    "medium": "Medium",
    "low": "Low",
    "none": "Low",
    "unknown": "Low",
}

# Status mapping from CrowdStrike Spotlight to RegScale
_STATUS_MAP = {
    "open": "Open",
    "closed": "Closed",
    "reopen": "Open",
}


def _map_severity(raw_severity: Optional[str]) -> str:
    """
    Map CrowdStrike severity to RegScale severity.

    :param Optional[str] raw_severity: Severity string from CrowdStrike
    :return: Normalized severity value
    :rtype: str
    """
    if not raw_severity:
        return "Low"
    return _SEVERITY_MAP.get(raw_severity.lower(), "Low")


def _map_status(raw_status: Optional[str]) -> str:
    """
    Map CrowdStrike vulnerability status to RegScale status.

    :param Optional[str] raw_status: Status string from CrowdStrike
    :return: Normalized status value
    :rtype: str
    """
    if not raw_status:
        return "Open"
    return _STATUS_MAP.get(raw_status.lower(), "Open")


def _get_nested(data: dict, *keys, default=None):
    """
    Safely traverse nested dictionary keys.

    :param dict data: Source dictionary
    :param keys: Sequence of keys to traverse
    :param default: Default value if any key is missing
    :return: Value at nested path or default
    """
    current = data
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key, default)
    return current


def vulnerability_to_integration_finding(vuln: dict) -> IntegrationFinding:
    """
    Convert a CrowdStrike Spotlight vulnerability to IntegrationFinding.

    :param dict vuln: Raw vulnerability dictionary from Spotlight API
    :return: IntegrationFinding instance
    :rtype: IntegrationFinding
    """
    cve_id = _get_nested(vuln, "cve", "id")
    description = _get_nested(vuln, "cve", "description", default="")
    base_score = _get_nested(vuln, "cve", "base_score")
    severity = _get_nested(vuln, "cve", "severity")
    exploit_status = _get_nested(vuln, "cve", "exploit_status")

    status = _get_nested(vuln, "status")
    aid = _get_nested(vuln, "aid", default="")
    vuln_id = vuln.get("id", "")
    created = _get_nested(vuln, "created_timestamp")
    updated = _get_nested(vuln, "updated_timestamp")

    remediation = _get_nested(vuln, "remediation", "action")
    app_name = _get_nested(vuln, "app", "product_name_version", default="")

    title = cve_id if cve_id else "CrowdStrike Spotlight Finding %s" % vuln_id

    finding_description = description
    if app_name:
        finding_description = "Affected application: %s\n%s" % (app_name, description)
    if exploit_status:
        finding_description += "\nExploit status: %s" % exploit_status

    return IntegrationFinding(
        control_labels=[],
        title=title,
        category="Vulnerability",
        plugin_name="CrowdStrike Spotlight",
        plugin_id=str(vuln_id),
        severity=_map_severity(severity),
        description=finding_description,
        status=_map_status(status),
        asset_identifier=str(aid),
        external_id=str(vuln_id),
        first_seen=created,
        last_seen=updated,
        cve=cve_id if cve_id and cve_id.startswith("CVE-") else None,
        cvss_v3_base_score=str(base_score) if base_score else None,
        remediation=remediation or "",
        source_report="CrowdStrike Spotlight",
    )


def host_to_integration_asset(host: dict) -> IntegrationAsset:
    """
    Convert a CrowdStrike Host device to IntegrationAsset.

    :param dict host: Raw host dictionary from Hosts API
    :return: IntegrationAsset instance
    :rtype: IntegrationAsset
    """
    device_id = host.get("device_id", "")
    hostname = host.get("hostname", device_id)
    platform = host.get("platform_name", "")
    os_version = host.get("os_version", "")
    local_ip = host.get("local_ip", "")
    external_ip = host.get("external_ip", "")
    mac_address = host.get("mac_address", "")
    system_manufacturer = host.get("system_manufacturer", "")
    system_product_name = host.get("system_product_name", "")
    agent_version = host.get("agent_version", "")
    site_name = host.get("site_name", "")
    machine_domain = host.get("machine_domain", "")
    status = host.get("status", "")
    serial_number = host.get("serial_number", "")

    # Determine asset type from platform
    asset_type = "Other"
    platform_lower = platform.lower() if platform else ""
    if "windows" in platform_lower:
        asset_type = "Windows"
    elif "linux" in platform_lower:
        asset_type = "Linux"
    elif "mac" in platform_lower:
        asset_type = "Mac"

    # Build FQDN
    fqdn = hostname
    if machine_domain and machine_domain not in hostname:
        fqdn = "%s.%s" % (hostname, machine_domain)

    # Determine asset status
    asset_status = "Active (On Network)" if status in ("normal", "contained") else "Inactive"

    return IntegrationAsset(
        name=hostname,
        identifier=device_id,
        asset_type=asset_type,
        asset_category="Hardware",
        ip_address=local_ip or external_ip or "",
        mac_address=mac_address or "",
        fqdn=fqdn,
        operating_system=platform,
        os_version=os_version,
        status=asset_status,
        description="CrowdStrike Falcon managed device",
        is_virtual=False,
        model=system_product_name,
        manufacturer=system_manufacturer,
        software_version=agent_version,
        software_name="CrowdStrike Falcon Sensor",
        software_vendor="CrowdStrike",
        location=site_name,
        serial_number=serial_number,
        external_id=device_id,
        other_tracking_number=device_id,
        scanning_tool="CrowdStrike",
    )


class CrowdStrikeScanner(ScannerIntegration):
    """CrowdStrike scanner integration for vulnerabilities and assets."""

    title = "CrowdStrike"
    type = ScannerIntegrationType.VULNERABILITY

    @staticmethod
    def _call_with_auth_retry(client, method_name, label, get_client, **params):
        """Invoke a FalconPy SDK method, refreshing the bearer token once on 401/403.

        Returns ``(client, body, status_code)``; when re-auth occurs the new client
        is returned so the caller can keep using it for subsequent pages.
        """
        from regscale.integrations.commercial.crowdstrike.sdk import invalidate_cached_auth

        response = getattr(client, method_name)(**params)
        body = response.get("body", {})
        status_code = response.get("status_code")
        if status_code in (401, 403):
            logger.warning("CrowdStrike %s token expired; refreshing and retrying.", label)
            invalidate_cached_auth()
            client = get_client()
            response = getattr(client, method_name)(**params)
            body = response.get("body", {})
            status_code = response.get("status_code")
        return client, body, status_code

    def fetch_findings(self, **kwargs) -> Generator[IntegrationFinding, None, None]:
        """
        Fetch vulnerabilities from CrowdStrike Spotlight API.

        Uses combined endpoint for efficient single-call retrieval of
        vulnerability details with pagination via after tokens.

        :return: Generator of IntegrationFinding objects
        :rtype: Generator[IntegrationFinding, None, None]
        """
        from regscale.integrations.commercial.crowdstrike.sdk import get_spotlight

        spotlight = get_spotlight()
        total_fetched = 0
        after = None

        logger.info("Fetching vulnerabilities from CrowdStrike Spotlight...")

        while True:
            params = {"filter": "status:'open'", "limit": _SPOTLIGHT_BATCH_SIZE}
            if after:
                params["after"] = after

            spotlight, body, status_code = self._call_with_auth_retry(
                spotlight, "query_vulnerabilities_combined", "Spotlight", get_spotlight, **params
            )

            if status_code != 200:
                errors = body.get("errors", [])
                error_msg = "; ".join(e.get("message", "Unknown") if isinstance(e, dict) else str(e) for e in errors)
                logger.error("CrowdStrike Spotlight API error (status %s): %s", status_code, error_msg)
                break

            resources = body.get("resources", [])
            if not resources:
                break

            for vuln in resources:
                yield vulnerability_to_integration_finding(vuln)
                total_fetched += 1

            pagination = body.get("meta", {}).get("pagination", {})
            after = pagination.get("after")
            total = pagination.get("total", 0)

            logger.info("Fetched %d of %d Spotlight vulnerabilities...", total_fetched, total)

            if not after or total_fetched >= total:
                break

        logger.info("Completed fetching %d CrowdStrike Spotlight vulnerabilities.", total_fetched)

    def _iter_host_id_pages(self, hosts_sdk, get_hosts):
        """Yield (sdk, ids, pagination, error_msg) for each scroll page (sequential)."""
        offset = None
        while True:
            params = {"limit": _HOSTS_BATCH_SIZE}
            if offset:
                params["offset"] = offset

            hosts_sdk, body, status_code = self._call_with_auth_retry(
                hosts_sdk, "query_devices_by_filter_scroll", "Hosts", get_hosts, **params
            )
            if status_code != 200:
                errors = body.get("errors", [])
                err = "; ".join(e.get("message", "Unknown") if isinstance(e, dict) else str(e) for e in errors)
                yield hosts_sdk, [], {}, "Hosts API error (status %s): %s" % (status_code, err)
                return

            ids = body.get("resources", [])
            if not ids:
                return

            pagination = body.get("meta", {}).get("pagination", {})
            yield hosts_sdk, ids, pagination, None

            offset = pagination.get("offset")
            if not offset:
                return

    def _fetch_host_details(self, ids, get_hosts):
        """Fetch device details for a single ID batch. Runs in worker thread."""
        _, body, status = self._call_with_auth_retry(get_hosts(), "get_device_details_v2", "Hosts", get_hosts, ids=ids)
        if status != 200:
            return [], "Hosts detail API error (status %s)" % status
        return body.get("resources", []), None

    @staticmethod
    def _drain_oldest_future(pending):
        """Pop the oldest detail-fetch future, log errors, return its devices."""
        devices, err = pending.popleft().result()
        if err:
            logger.error("CrowdStrike %s", err)
            return []
        return devices

    def fetch_assets(self, **kwargs) -> Generator[IntegrationAsset, None, None]:
        """
        Fetch hosts/devices from CrowdStrike Hosts API.

        Scroll pagination is sequential (cursor-driven), but detail hydration is
        parallelized via a sliding window of in-flight futures bounded by
        ``_HOSTS_DETAIL_CONCURRENCY`` so streaming and memory stay bounded.

        :return: Generator of IntegrationAsset objects
        :rtype: Generator[IntegrationAsset, None, None]
        """
        from regscale.integrations.commercial.crowdstrike.sdk import get_hosts

        hosts_sdk = get_hosts()
        total_fetched = 0
        total_expected = 0

        logger.info("Fetching hosts from CrowdStrike Hosts API...")

        with ThreadPoolExecutor(max_workers=_HOSTS_DETAIL_CONCURRENCY) as executor:
            pending = deque()

            for hosts_sdk, ids, pagination, error_msg in self._iter_host_id_pages(hosts_sdk, get_hosts):
                if error_msg:
                    logger.error("CrowdStrike %s", error_msg)
                    break

                total_expected = pagination.get("total", total_expected)
                pending.append(executor.submit(self._fetch_host_details, ids, get_hosts))

                while len(pending) >= _HOSTS_DETAIL_CONCURRENCY:
                    for device in self._drain_oldest_future(pending):
                        yield host_to_integration_asset(device)
                        total_fetched += 1
                    logger.info("Fetched %d of %d CrowdStrike hosts...", total_fetched, total_expected)

            while pending:
                for device in self._drain_oldest_future(pending):
                    yield host_to_integration_asset(device)
                    total_fetched += 1

        logger.info("Completed fetching %d CrowdStrike hosts.", total_fetched)
