#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CrowdStrike console display helpers for incident tables."""

import logging
from enum import Enum

import click

from regscale.core.app.utils.app_utils import error_and_exit
from regscale.integrations.commercial.crowdstrike.sdk import get_user_detail

logger = logging.getLogger("regscale")


class StatusColor(Enum):
    """Enum mapping status values to display colors."""

    NEW = "yellow"
    REOPENED = "yellow"
    INPROGRESS = "cyan"
    CLOSED = "green"


class Status(Enum):
    """Enum used to describe status values."""

    NEW = 20
    REOPENED = 25
    INPROGRESS = 30
    CLOSED = 40


def status_information(inc_data: dict) -> str:
    """
    Parse status information for tabular display.

    :param dict inc_data: Incident data to parse
    :return: Status information
    :rtype: str
    """
    status_name = Status(inc_data["status"]).name.title().replace("Inp", "InP")
    inc_status = [status_name]
    tag_list = inc_data.get("tags", [])
    if tag_list:
        inc_status.append(" ")
        inc_status.extend(tag_list)

    return "\n".join(inc_status)


def incident_information(inc_data: dict) -> str:
    """
    Parse incident overview information for tabular display.

    :param dict inc_data: Incident data to parse
    :return: Incident overview information
    :rtype: str
    """
    inc_info = []
    inc_info.append(inc_data.get("name", ""))
    inc_info.append(inc_data["incident_id"].split(":")[2])
    inc_info.append(f"Start: {inc_data.get('start', 'Unknown').replace('T', ' ')}")
    inc_info.append(f"  End: {inc_data.get('end', 'Unknown').replace('T', ' ')}")
    if assigned := inc_data.get("assigned_to"):
        inc_info.append("\nAssignment")
        inc_info.append(get_user_detail(assigned))
    if inc_data.get("description"):
        inc_info.append(" ")
        inc_info.append(chunk_long_description(inc_data["description"], 50))

    return "\n".join(inc_info)


def chunk_long_description(desc: str, col_width: int) -> str:
    """
    Chunk a long string by delimiting with CR based upon column length.

    :param str desc: Description to parse
    :param int col_width: Column width to chunk by
    :return: Chunked description
    :rtype: str
    """
    desc_chunks = []
    chunk = ""
    for word in desc.split():
        new_chunk = f"{chunk}{word.strip()} "
        if len(new_chunk) >= col_width:
            desc_chunks.append(new_chunk)
            chunk = ""
        else:
            chunk = new_chunk

    delim = "\n"
    desc_chunks.append(chunk)

    return delim.join(desc_chunks)


def hosts_information(inc_data: dict) -> str:
    """
    Parse hosts information for tabular display.

    :param dict inc_data: Incident data to parse
    :return: Host information
    :rtype: str
    """
    returned = ""
    if "hosts" in inc_data:
        host_str = []
        for host in inc_data["hosts"]:
            host_info = []
            host_info.append(f"{host.get('hostname', 'Unidentified')} ({host.get('platform_name', 'Not available')})")
            host_info.append(f"  Device ID: {host.get('device_id', 'Not available')}")
            host_info.append(f"  Int: {host.get('local_ip', 'Not available')}")
            host_info.append(f"  Ext: {host.get('external_ip', 'Not available')}")
            first = host.get("first_seen", "Unavailable").replace("T", " ").replace("Z", " ")
            host_info.append(f"First: {first}")
            last = host.get("last_seen", "Unavailable").replace("T", " ").replace("Z", " ")
            host_info.append(f" Last: {last}")
            host_str.append("\n".join(host_info))
        if host_str:
            returned = "\n".join(host_str)
        else:
            returned = "Unidentified"

    return returned


def show_incident_table(incident_listing: list) -> None:
    """
    Display all returned incidents in tabular fashion.

    :param list incident_listing: List of incidents to parse and print to console
    :raises General Error: If incident_listing is empty
    :rtype: None
    """
    if not incident_listing:
        error_and_exit("No incidents found, code 404")

    click.echo("\nIncidents")
    headers = ["Status", "Incident", "Host", "Tactics", "Techniques", "Objectives"]
    click.echo("  " + "  ".join(f"{h:<20}" for h in headers))
    click.echo("  " + "  ".join("-" * 20 for _ in headers))

    for inc in incident_listing:
        inc_detail = {
            "status": status_information(inc),
            "incident": incident_information(inc),
            "hostname": hosts_information(inc),
            "tactics": "\n".join(inc["tactics"]),
            "techniques": "\n".join(inc["techniques"]),
            "objectives": "\n".join(inc["objectives"]),
        }
        # Print first line of each field
        fields = [inc_detail["status"], inc_detail["incident"], inc_detail["hostname"]]
        fields.extend([inc_detail["tactics"], inc_detail["techniques"], inc_detail["objectives"]])
        first_lines = [f.split("\n")[0][:20] if f else "" for f in fields]
        click.echo("  " + "  ".join(f"{line:<20}" for line in first_lines))
