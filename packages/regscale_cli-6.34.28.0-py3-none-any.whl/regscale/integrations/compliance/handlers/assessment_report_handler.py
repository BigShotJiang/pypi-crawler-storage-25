"""Handler for generating HTML assessment reports from compliance data."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from regscale.integrations.compliance_integration import ComplianceItem

if TYPE_CHECKING:
    from regscale.integrations.compliance_integration import ComplianceIntegration

logger = logging.getLogger("regscale")


class ComplianceAssessmentReportHandler:
    """Generates HTML assessment reports for compliance controls.

    Extracts report-generation logic from ComplianceIntegration to keep
    the integration class focused on orchestration.

    :param ComplianceIntegration integration: The parent compliance integration instance
    """

    def __init__(self, integration: "ComplianceIntegration") -> None:
        self._integration = integration

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def create_assessment_report(self, control_id: str, result: str, compliance_items: List[ComplianceItem]) -> str:
        """
        Create HTML assessment report.

        :param str control_id: Control identifier
        :param str result: Assessment result ('Pass' or 'Fail')
        :param List[ComplianceItem] compliance_items: Compliance items for this control
        :return: Formatted HTML report string
        :rtype: str
        """
        result_color = "#d32f2f" if result == "Fail" else "#2e7d32"

        html_parts = [self.create_report_header(control_id, result, result_color, compliance_items)]

        if compliance_items:
            # Calculate statistics
            stats = self.calculate_assessment_statistics(compliance_items)

            # Collect unique resources and policies
            unique_resources, unique_policies = self.collect_unique_resources_and_policies(compliance_items)

            # Add summary section
            html_parts.append(
                self.create_summary_section(
                    control_id, result, result_color, stats, compliance_items, unique_resources, unique_policies
                )
            )

            # Add "what was tested" section showing per-policy results
            html_parts.append(self.create_policies_tested_section(compliance_items))

            # Add failure details if needed
            if result == "Fail" and stats["noncompliant_count"] > 0:
                failed_items = [
                    item for item in compliance_items if item.compliance_result in self._integration.FAIL_STATUSES
                ]
                html_parts.append(self.create_failure_details_section(failed_items))

        return "".join(html_parts)

    # ------------------------------------------------------------------
    # Header & statistics
    # ------------------------------------------------------------------

    def create_report_header(
        self, control_id: str, result: str, result_color: str, compliance_items: List[ComplianceItem]
    ) -> str:
        """Create the header section of the assessment report."""
        bg_color = "#ffebee" if result == "Fail" else "#e8f5e8"
        return f"""
            <div style="margin-bottom: 20px; padding: 15px; border: 2px solid {result_color};
                        border-radius: 5px; background-color: {bg_color};">
                <h3 style="margin: 0 0 10px 0; color: {result_color};">
                    {self._integration.title} Compliance Assessment for Control {control_id.upper()}
                </h3>
                <p><strong>Overall Result:</strong>
                   <span style="color: {result_color}; font-weight: bold;">{result}</span></p>
                <p><strong>Assessment Date:</strong> {self._integration.scan_date}</p>
                <p><strong>Framework:</strong> {self._integration.framework}</p>
                <p><strong>Total Policy Assessments:</strong> {len(compliance_items)}</p>
            </div>
            """  # NOSONAR

    def calculate_assessment_statistics(self, compliance_items: List[ComplianceItem]) -> Dict:
        """Calculate compliance statistics from compliance items."""
        compliant_count = len(
            [item for item in compliance_items if item.compliance_result in self._integration.PASS_STATUSES]
        )
        noncompliant_count = len(
            [item for item in compliance_items if item.compliance_result in self._integration.FAIL_STATUSES]
        )
        inconclusive_count = len(
            [item for item in compliance_items if item.compliance_result in self._integration.INCONCLUSIVE_STATUSES]
        )
        not_applicable_count = len(
            [item for item in compliance_items if item.compliance_result in self._integration.NOT_APPLICABLE_STATUSES]
        )

        # Calculate confidence score
        total_evaluated = compliant_count + noncompliant_count + inconclusive_count
        confidence_score: float = 0
        if total_evaluated > 0:
            conclusive_count = compliant_count + noncompliant_count
            confidence_score = round((conclusive_count / total_evaluated) * 100, 2)

        # Calculate compliance score
        compliance_score: float = 0
        if (compliant_count + noncompliant_count) > 0:
            compliance_score = round((compliant_count / (compliant_count + noncompliant_count)) * 100, 2)

        return {
            "compliant_count": compliant_count,
            "noncompliant_count": noncompliant_count,
            "inconclusive_count": inconclusive_count,
            "not_applicable_count": not_applicable_count,
            "confidence_score": confidence_score,
            "compliance_score": compliance_score,
        }

    @staticmethod
    def get_policy_name_for_item(item: ComplianceItem) -> str:
        """
        Extract a human-readable policy/check name from a compliance item.

        Checks integration-specific attributes (policy_name for Wiz, policy dict for AWS)
        before falling back to the generic description.

        :param ComplianceItem item: Compliance item to extract policy name from
        :return: Policy name string
        :rtype: str
        """
        # Wiz items have a policy_name attribute with the actual check name
        if hasattr(item, "policy_name") and item.policy_name:
            return item.policy_name
        # AWS Audit Manager items store policy as a dict
        if hasattr(item, "policy") and isinstance(item.policy, dict):
            return item.policy.get("name", "Unknown Policy")
        # Generic fallback — use description truncated to a reasonable length
        if hasattr(item, "description") and item.description:
            desc = item.description
            return desc[:80] + "..." if len(desc) > 80 else desc
        return "Unknown Policy"

    # ------------------------------------------------------------------
    # Unique resources / policies
    # ------------------------------------------------------------------

    def collect_unique_resources_and_policies(self, compliance_items: List[ComplianceItem]) -> tuple[set, set]:
        """Collect unique resources and policies from compliance items."""
        unique_resources = set()
        unique_policies = set()

        for item in compliance_items:
            unique_resources.add(item.resource_id)
            unique_policies.add(self.get_policy_name_for_item(item))

        return unique_resources, unique_policies

    # ------------------------------------------------------------------
    # Summary section
    # ------------------------------------------------------------------

    def create_summary_section(
        self,
        control_id: str,
        result: str,
        result_color: str,
        stats: Dict,
        compliance_items: List[ComplianceItem],
        unique_resources: set,
        unique_policies: set,
    ) -> str:
        """Create the aggregated assessment summary section."""
        not_applicable_suffix = (
            f", not_applicable={stats['not_applicable_count']}" if stats["not_applicable_count"] > 0 else ""
        )
        not_applicable_line = (
            f'<br><span style="color: #9e9e9e;">- Not Applicable:</span> {stats["not_applicable_count"]}'
            if stats["not_applicable_count"] > 0
            else ""
        )

        return f"""
            <div style="margin-top: 20px;">
                <h4>Aggregated Assessment Summary</h4>
                <p><strong>Control {control_id} Analysis:</strong>
                   status=<span style="color: {result_color}; font-weight: bold;">{result.upper()}</span>,
                   score={stats["compliance_score"]:.2f},
                   confidence={stats["confidence_score"]:.0f},
                   compliant={stats["compliant_count"]},
                   noncompliant={stats["noncompliant_count"]},
                   inconclusive={stats["inconclusive_count"]}{not_applicable_suffix}
                </p>
                <hr style="border: 0; border-top: 1px solid #e0e0e0; margin: 10px 0;">
                <p><strong>Policy Assessments:</strong> {len(compliance_items)} total</p>
                <p><strong>Unique Policies Tested:</strong> {len(unique_policies)}</p>
                <p><strong>Unique Resources Assessed:</strong> {len(unique_resources)}</p>
                <hr style="border: 0; border-top: 1px solid #e0e0e0; margin: 10px 0;">
                <h5>Evidence Breakdown:</h5>
                <p style="margin-left: 20px;">
                    <span style="color: #2e7d32;">✓ Compliant:</span> {stats["compliant_count"]}<br>
                    <span style="color: #d32f2f;">✗ Non-Compliant:</span> {stats["noncompliant_count"]}<br>
                    <span style="color: #ff9800;">⚠ Inconclusive:</span> {stats["inconclusive_count"]}{not_applicable_line}
                </p>
                <hr style="border: 0; border-top: 1px solid #e0e0e0; margin: 10px 0;">
                <p><strong>Compliance Score:</strong> {stats["compliance_score"]:.2f}%
                   <span style="font-size: 0.9em; color: #666;">(compliant / (compliant + noncompliant))</span></p>
                <p><strong>Confidence Level:</strong> {stats["confidence_score"]:.0f}%
                   <span style="font-size: 0.9em; color: #666;">(conclusive evidence ratio)</span></p>
                <p><strong>Overall Control Result:</strong>
                   <span style="color: {result_color}; font-weight: bold;">{result}</span></p>
            </div>
             """

    # ------------------------------------------------------------------
    # Policies tested section
    # ------------------------------------------------------------------

    def create_policies_tested_section(self, compliance_items: List[ComplianceItem]) -> str:
        """
        Create a section listing what policies/checks were evaluated and their results.

        Groups compliance items by policy name and shows each policy's result
        along with the resources it was tested against.

        :param List[ComplianceItem] compliance_items: Compliance items for this control
        :return: HTML section with per-policy details
        :rtype: str
        """
        if not compliance_items:
            return ""

        # Group items by policy name -> list of (resource_name, result)
        policy_details: Dict[str, List[tuple]] = {}
        for item in compliance_items:
            policy_name = self.get_policy_name_for_item(item)
            resource_name = getattr(item, "resource_name", item.resource_id)
            result = item.compliance_result
            policy_details.setdefault(policy_name, []).append((resource_name, result))

        # Build HTML table
        rows = []
        for policy_name, entries in sorted(policy_details.items()):
            pass_count = sum(1 for _, r in entries if r in self._integration.PASS_STATUSES)
            fail_count = sum(1 for _, r in entries if r in self._integration.FAIL_STATUSES)
            total = len(entries)

            if fail_count > 0:
                status_html = f'<span style="color: #d32f2f; font-weight: bold;">Fail</span> ({fail_count}/{total})'
            else:
                status_html = f'<span style="color: #2e7d32; font-weight: bold;">Pass</span> ({pass_count}/{total})'

            # Show up to 3 resource names as examples
            resource_samples = sorted({name for name, _ in entries})[:3]
            resources_text = ", ".join(resource_samples)
            if len({name for name, _ in entries}) > 3:
                resources_text += f" (+{len({name for name, _ in entries}) - 3} more)"

            rows.append(
                f"<tr><td>{policy_name}</td><td>{status_html}</td><td>{total}</td><td>{resources_text}</td></tr>"
            )

        return f"""
            <div style="margin-top: 20px;">
                <h4>Policies Tested</h4>
                <table style="width: 100%; border-collapse: collapse; font-size: 0.9em;">
                    <thead>
                        <tr style="background-color: #f5f5f5; border-bottom: 2px solid #ddd;">
                            <th style="text-align: left; padding: 8px;">Policy / Check</th>
                            <th style="text-align: left; padding: 8px;">Result</th>
                            <th style="text-align: left; padding: 8px;">Resources</th>
                            <th style="text-align: left; padding: 8px;">Sample Resources</th>
                        </tr>
                    </thead>
                    <tbody>
                        {"".join(rows)}
                    </tbody>
                </table>
            </div>
            """

    # ------------------------------------------------------------------
    # Failure details section
    # ------------------------------------------------------------------

    def create_failure_details_section(self, failed_items: List[ComplianceItem]) -> str:
        """
        Create detailed failure information section for failed compliance items.

        :param List[ComplianceItem] failed_items: List of failed compliance items
        :return: HTML section with detailed failure information
        :rtype: str
        """
        html_parts = [self.get_failure_section_header()]

        for idx, item in enumerate(failed_items, 1):
            html_parts.append(self.process_failed_item(idx, item))

        html_parts.append("</div>")
        return "".join(html_parts)

    def get_failure_section_header(self) -> str:
        """Get the HTML header for failure details section."""
        return """
            <div style="margin-top: 20px; padding: 15px; background-color: #fff3e0;
                        border-left: 4px solid #ff9800; border-radius: 5px;">
                <h4 style="color: #e65100; margin-top: 0;">Failed Evidence Details</h4>
            """

    # ------------------------------------------------------------------
    # Failed item processing
    # ------------------------------------------------------------------

    def process_failed_item(self, idx: int, item: ComplianceItem) -> str:
        """
        Process a single failed item and return HTML.

        :param int idx: The index of the failed item
        :param ComplianceItem item: The failed compliance item
        :return: HTML for the failed item
        :rtype: str
        """
        if self.has_aws_evidence(item):
            return self.process_aws_item_with_evidence(idx, item)
        return self.process_non_aws_item(idx, item)

    def has_aws_evidence(self, item: ComplianceItem) -> bool:
        """Check if item has AWS Audit Manager evidence."""
        return hasattr(item, "evidence_items") and item.evidence_items

    def process_aws_item_with_evidence(self, idx: int, item: ComplianceItem) -> str:
        """Process AWS item with evidence details."""
        evidence_categories = self.categorize_evidence(item)

        if not evidence_categories["failed"]:
            return ""

        html_parts = []
        html_parts.append(self.create_failed_check_header(idx, item, evidence_categories))
        html_parts.append(self.create_failed_evidence_details(evidence_categories["failed"]))
        html_parts.append(self.add_remediation_guidance(item))
        html_parts.append("</div>")

        return "".join(html_parts)

    def categorize_evidence(self, item: ComplianceItem) -> Dict[str, List[Any]]:
        """
        Categorize evidence items by compliance status.

        :param ComplianceItem item: The compliance item with evidence
        :return: Dictionary with categorized evidence
        :rtype: Dict[str, List[Any]]
        """
        categories: Dict[str, List[Any]] = {"failed": [], "compliant": [], "inconclusive": []}

        for evidence in item.evidence_items:
            compliance_check = self.get_evidence_compliance_check(item, evidence)

            if compliance_check == "FAILED":
                categories["failed"].append(evidence)
            elif compliance_check == "COMPLIANT":
                categories["compliant"].append(evidence)
            else:
                categories["inconclusive"].append(evidence)

        return categories

    def get_evidence_compliance_check(self, item: ComplianceItem, evidence: Any) -> Optional[str]:
        """Get compliance check result for evidence."""
        if hasattr(item, "_get_evidence_compliance"):
            return item._get_evidence_compliance(evidence)
        return None

    # ------------------------------------------------------------------
    # Failed check HTML helpers
    # ------------------------------------------------------------------

    def create_failed_check_header(
        self, idx: int, item: ComplianceItem, evidence_categories: Dict[str, List[Any]]
    ) -> str:
        """Create HTML header for failed check."""
        return f"""
            <div style="margin-top: 15px; padding: 10px; background-color: #ffebee; border-radius: 3px;">
                <h5 style="color: #c62828; margin-top: 0;">
                    Failed Check #{idx}: {item.control_id}
                </h5>
                <p><strong>Resource:</strong> {getattr(item, "resource_name", item.resource_id)}</p>
                <p><strong>Evidence Summary:</strong>
                   {len(evidence_categories["failed"])} failed, {len(evidence_categories["compliant"])} compliant,
                   {len(evidence_categories["inconclusive"])} inconclusive</p>
            """

    def create_failed_evidence_details(self, failed_evidence: List[Any]) -> str:
        """Create HTML for failed evidence details."""
        html_parts = ['<div style="margin-top: 10px;"><strong>Failed Evidence:</strong><ul>']

        # Limit to 10 failed evidence items
        for evidence in failed_evidence[:10]:
            html_parts.append(self.format_single_evidence(evidence))

        html_parts.append("</ul></div>")
        return "".join(html_parts)

    def format_single_evidence(self, evidence: Dict[str, Any]) -> str:
        """Format a single evidence item as HTML."""
        evidence_html = []
        evidence_source = evidence.get("dataSource", "Unknown source")
        evidence_id = evidence.get("id", "")[:50]

        evidence_html.append(f"<li><strong>Source:</strong> {evidence_source}")

        if evidence_id:
            evidence_html.append(f"<br><strong>Evidence ID:</strong> {evidence_id}")

        resources_info = self.get_resources_info(evidence)
        if resources_info:
            evidence_html.append(f"<br><strong>Resources:</strong><ul><li>{'</li><li>'.join(resources_info)}</li></ul>")

        evidence_html.append("</li>")
        return "".join(evidence_html)

    def get_resources_info(self, evidence: Dict[str, Any]) -> List[str]:
        """Extract resource information from evidence."""
        resources_info = []
        resources_included = evidence.get("resourcesIncluded", [])

        # Limit to 5 resources per evidence
        for resource in resources_included[:5]:
            resource_str = self.format_resource(resource)
            if resource_str:
                resources_info.append(resource_str)

        return resources_info

    def format_resource(self, resource: Dict[str, Any]) -> Optional[str]:
        """Format a single resource as a string."""
        resource_type = resource.get("type", "Unknown")
        resource_value = resource.get("value", "")[:100]
        resource_check = resource.get("complianceCheck", "N/A")

        if resource_value:
            return f"{resource_type}: {resource_value} (Status: {resource_check})"
        return None

    # ------------------------------------------------------------------
    # Remediation guidance
    # ------------------------------------------------------------------

    def add_remediation_guidance(self, item: ComplianceItem) -> str:
        """Add remediation guidance if available."""
        if not (hasattr(item, "action_plan_instructions") and item.action_plan_instructions):
            return ""

        instructions = item.action_plan_instructions[:500]
        truncated = "..." if len(item.action_plan_instructions) > 500 else ""

        return f"""
            <div style="margin-top: 10px; padding: 8px; background-color: #e3f2fd;
                        border-left: 3px solid #1976d2; border-radius: 3px;">
                <strong>Remediation Guidance:</strong><br>
                {instructions}{truncated}
            </div>
            """

    # ------------------------------------------------------------------
    # Non-AWS item processing
    # ------------------------------------------------------------------

    def process_non_aws_item(self, idx: int, item: ComplianceItem) -> str:
        """Process non-AWS items or items without evidence."""
        policy_name = self.get_policy_name_for_item(item)
        description = self.get_item_description(item)
        remediation = getattr(item, "remediation_steps", "") or ""

        remediation_html = ""
        if remediation:
            remediation_html = f"""
                <div style="margin-top: 8px; padding: 8px; background-color: #e3f2fd;
                            border-left: 3px solid #1976d2; border-radius: 3px;">
                    <strong>Remediation:</strong><br>{remediation}
                </div>"""

        return f"""
            <div style="margin-top: 15px; padding: 10px; background-color: #ffebee; border-radius: 3px;">
                <h5 style="color: #c62828; margin-top: 0;">Failed Check #{idx}: {policy_name}</h5>
                <p><strong>Control:</strong> {item.control_id}</p>
                <p><strong>Resource:</strong> {getattr(item, "resource_name", item.resource_id)}</p>
                <p><strong>Details:</strong> {description}</p>
                {remediation_html}
            </div>
            """

    def get_item_description(self, item: ComplianceItem) -> str:
        """Get description from item without truncation to show full failure details."""
        if hasattr(item, "description"):
            return item.description
        return "N/A"
