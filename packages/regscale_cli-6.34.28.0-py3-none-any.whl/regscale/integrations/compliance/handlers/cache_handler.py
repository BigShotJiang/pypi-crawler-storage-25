"""Cache handler for ComplianceIntegration.

Extracts cache management methods from ComplianceIntegration into a
dedicated handler that reads and writes the integration instance's
attributes directly.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from regscale.core.app.utils.app_utils import regscale_string_to_datetime
from regscale.models import regscale_models
from regscale.models.regscale_models import ControlImplementation

if TYPE_CHECKING:
    from regscale.integrations.compliance_integration import ComplianceIntegration

logger = logging.getLogger("regscale")


class ComplianceCacheHandler:
    """Manages record caching for a ComplianceIntegration instance.

    Provides methods to load existing RegScale records (assets, issues,
    assessments) into in-memory caches and to look up cached records,
    preventing duplicate creation during compliance syncs.
    """

    def __init__(self, integration: ComplianceIntegration) -> None:
        self._integration = integration

    # ------------------------------------------------------------------
    # Cache loading
    # ------------------------------------------------------------------

    def load_existing_records_cache(self) -> None:
        """Load existing RegScale records into cache to prevent duplicates.

        This method populates caches for assets and assessments.
        Issue deduplication is handled server-side by the BatchCreateOrUpdate API.

        :return: None
        :rtype: None
        """
        if self._integration._cache_loaded:
            return

        logger.info("Loading existing RegScale records cache...")

        try:
            # Load existing assets for this plan
            self.load_existing_assets()

            # Load existing assessments for control implementations
            self.load_existing_assessments()

            self._integration._cache_loaded = True
            logger.info("Loaded existing records cache:")
            logger.info("   - Assets: %d", len(self._integration._existing_assets_cache))
            logger.info("   - Assessments: %d", len(self._integration._existing_assessments_cache))

        except Exception as e:
            logger.error("Error loading existing records cache: %s", e)
            # Continue without cache to avoid blocking the integration
            self._integration._cache_loaded = True

    def load_existing_assets(self) -> None:
        """Load existing assets into cache.

        :return: None
        :rtype: None
        """
        try:
            # Get all assets for this plan
            existing_assets: list = regscale_models.Asset.get_all_by_parent(
                parent_id=self._integration.plan_id, parent_module=self._integration.parent_module
            )

            for asset in existing_assets:
                # Cache by identifier and other_tracking_number for flexible lookup
                if hasattr(asset, "identifier") and asset.identifier:
                    self._integration._existing_assets_cache[asset.identifier] = asset
                if hasattr(asset, "otherTrackingNumber") and asset.otherTrackingNumber:
                    self._integration._existing_assets_cache[asset.otherTrackingNumber] = asset

        except Exception as e:
            logger.debug("Error loading existing assets: %s", e)

    def get_assessment_cache_key(self, implementation_id: int, assessment) -> Optional[str]:
        """Generate cache key for assessment (impl_id + day).

        :param int implementation_id: Control implementation ID
        :param assessment: Assessment object with actualFinish attribute
        :return: Cache key string or None if key cannot be generated
        :rtype: Optional[str]
        """
        if not (hasattr(assessment, "actualFinish") and assessment.actualFinish):
            return None

        try:
            # actualFinish may be a string; normalize to date-only key
            if hasattr(assessment.actualFinish, "date"):
                day_key = assessment.actualFinish.date().isoformat()
            else:
                day_key = regscale_string_to_datetime(assessment.actualFinish).date().isoformat()
            return f"{implementation_id}_{day_key}"
        except Exception:
            return None

    def cache_implementation_assessments(self, implementation) -> None:
        """Load and cache assessments for a single implementation.

        :param implementation: ControlImplementation object to load assessments for
        :return: None
        :rtype: None
        """
        try:
            assessments: list = regscale_models.Assessment.get_all_by_parent(
                parent_id=implementation.id, parent_module="controls"
            )

            for assessment in assessments:
                cache_key = self.get_assessment_cache_key(implementation.id, assessment)
                if cache_key:
                    self._integration._existing_assessments_cache[cache_key] = assessment

        except Exception as e:
            logger.debug("Error loading assessments for implementation %s: %s", implementation.id, e)

    def load_existing_assessments(self) -> None:
        """Load existing assessments into cache.

        :return: None
        :rtype: None
        """
        try:
            # Get control implementations for this plan to find their assessments
            implementations: list = ControlImplementation.get_all_by_parent(
                parent_id=self._integration.plan_id, parent_module=self._integration.parent_module
            )

            for implementation in implementations:
                self.cache_implementation_assessments(implementation)

        except Exception as e:
            logger.debug("Error loading existing assessments: %s", e)

    # ------------------------------------------------------------------
    # Cache lookups
    # ------------------------------------------------------------------

    def find_existing_asset_cached(self, resource_id: str) -> Optional[regscale_models.Asset]:
        """Find existing asset by resource ID using cache.

        :param str resource_id: Resource identifier to search for
        :return: Existing asset or None if not found
        :rtype: Optional[regscale_models.Asset]
        """
        return self._integration._existing_assets_cache.get(resource_id)

    def find_existing_assessment_cached(
        self, implementation_id: int, scan_date
    ) -> Optional[regscale_models.Assessment]:
        """Find existing assessment by implementation ID and date using cache.

        :param int implementation_id: Control implementation ID
        :param scan_date: Scan date to check against existing assessments
        :return: Existing assessment or None if not found
        :rtype: Optional[regscale_models.Assessment]
        """
        # Normalize to date-only key
        try:
            if hasattr(scan_date, "date"):
                day_key = scan_date.date().isoformat()
            else:
                day_key = regscale_string_to_datetime(str(scan_date)).date().isoformat()
        except Exception:
            day_key = str(scan_date).split(" ")[0]
        cache_key = f"{implementation_id}_{day_key}"
        return self._integration._existing_assessments_cache.get(cache_key)

    # ------------------------------------------------------------------
    # Evidence checks
    # ------------------------------------------------------------------

    def check_for_existing_evidence(self, file_name_pattern: str) -> bool:
        """Check if an evidence file matching the pattern already exists in RegScale.

        This method fetches existing files for the plan and checks if any match
        the provided pattern, helping prevent duplicate evidence uploads.

        :param str file_name_pattern: Pattern to match against existing file names
        :return: True if a matching file exists, False otherwise
        :rtype: bool
        """
        try:
            # Import here to avoid circular dependency
            from regscale.models.regscale_models import File

            # Get all existing files for the plan
            existing_files = File.get_files_for_parent_from_regscale(
                parent_id=self._integration.plan_id, parent_module=self._integration.parent_module
            )

            # Check if any file matches the pattern
            for file_obj in existing_files:
                if hasattr(file_obj, "trustedDisplayName") and file_obj.trustedDisplayName:
                    # Check if the pattern is in the file name
                    if file_name_pattern in file_obj.trustedDisplayName:
                        logger.debug(
                            "Found existing evidence file matching pattern '%s': %s",
                            file_name_pattern,
                            file_obj.trustedDisplayName,
                        )
                        return True

            logger.debug(
                "No existing evidence files found matching pattern '%s'",
                file_name_pattern,
            )
            return False

        except Exception as e:
            logger.warning(
                "Unable to check for existing evidence files (pattern: '%s'): %s. Proceeding with upload.",
                file_name_pattern,
                e,
            )
            # Return False to allow upload to proceed if check fails
            return False
