#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Shared evidence utilities for all integrations.

Provides a single function to create an Evidence record, upload a source file
to it, and map the Evidence to a SecurityPlan.  This eliminates the duplicated
Evidence → File → EvidenceMapping boilerplate across AWS, GCP, Wiz, eMASS,
and any future integration.

Usage::

    from regscale.integrations.evidence_utils import attach_file_as_evidence

    evidence_id = attach_file_as_evidence(
        file_path="/tmp/scan_results.csv",
        plan_id=123,
        source_name="Qualys VM Scan",
        tags="qualys,scan",
    )
"""

import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Union

from regscale.models.regscale_models.evidence import Evidence
from regscale.models.regscale_models.evidence_mapping import EvidenceMapping
from regscale.models.regscale_models.file import File

logger = logging.getLogger("regscale")

MAX_EVIDENCE_FILE_SIZE = 100 * 1024 * 1024  # 100 MB — matches File.upload_file_to_regscale limit


def _upload_file_to_evidence(resolved: Path, evidence_id: int, tags: Optional[str]) -> None:
    """Upload a source file to an Evidence record."""
    from regscale.core.app.api import Api

    api = Api()
    try:
        file_data = resolved.read_bytes()
        ok = File.upload_file_to_regscale(
            file_name=resolved.name,
            parent_id=evidence_id,
            parent_module="evidence",
            api=api,
            file_data=file_data,
            tags=tags,
        )
        if ok:
            logger.info("Uploaded '%s' to Evidence record %d.", resolved.name, evidence_id)
        else:
            logger.warning("File upload returned False for '%s' on Evidence %d.", resolved.name, evidence_id)
    except Exception as exc:
        logger.error("Failed to upload '%s' to Evidence %d: %s", resolved.name, evidence_id, exc)


def _find_existing_evidence(plan_id: int, source_name: str) -> Optional[int]:
    """Return the ID of an existing Evidence record for *plan_id* whose title starts with *source_name*, or None.

    Uses ``GET /api/evidence/byParent/securityplans/{plan_id}`` which returns
    ``EvidenceByParentViewModel`` objects containing both ``id`` and ``title``
    directly — no secondary per-record fetches needed.
    """
    try:
        handler = Evidence._get_api_handler()
        headers = Evidence._get_headers()

        endpoint = Evidence.get_endpoint("by_parent").format(
            parentModule="securityplans",
            parentId=plan_id,
        )
        response = handler.get(endpoint=endpoint, headers=headers)
        if not response or not response.ok:
            logger.debug("Evidence dedup: byParent failed (status=%s).", getattr(response, "status_code", "N/A"))
            return None

        records = response.json() or []
        logger.debug("Evidence dedup: %d evidence record(s) for SSP %d.", len(records), plan_id)
        for rec in records:
            title = str(rec.get("title") or "")
            if title.startswith(source_name):
                ev_id = rec.get("id")
                logger.info("Evidence dedup: found existing record %d ('%s') for SSP %d.", ev_id, title, plan_id)
                return ev_id
    except Exception as exc:
        logger.warning("Could not check existing evidence for SSP %d: %s", plan_id, exc)
    return None


def _map_evidence(evidence_id: int, plan_id: int, control_ids: Optional[list]) -> None:
    """Create EvidenceMapping records linking Evidence to SSP and optionally controls."""
    try:
        mapping = EvidenceMapping(
            evidenceID=evidence_id,
            mappedID=plan_id,
            mappingType="securityplans",
        )
        mapping.create()
        logger.info("Mapped Evidence %d -> SecurityPlan %d.", evidence_id, plan_id)
    except Exception as exc:
        logger.error("Failed to map Evidence %d to SecurityPlan %d: %s", evidence_id, plan_id, exc)

    if not control_ids:
        return

    for ctrl_id in control_ids:
        try:
            ctrl_mapping = EvidenceMapping(
                evidenceID=evidence_id,
                mappedID=ctrl_id,
                mappingType="controls",
            )
            ctrl_mapping.create()
            logger.debug("Mapped Evidence %d -> Control %d.", evidence_id, ctrl_id)
        except Exception as exc:
            logger.warning("Failed to map Evidence %d to Control %d: %s", evidence_id, ctrl_id, exc)


def attach_file_as_evidence(
    file_path: Union[str, Path],
    plan_id: int,
    source_name: str,
    dry_run: bool = False,
    description: Optional[str] = None,
    tags: Optional[str] = None,
    update_frequency: int = 365,
    control_ids: Optional[list] = None,
) -> Optional[int]:
    """
    Save a file as Evidence and map it to a SecurityPlan (and optionally controls).

    This is the canonical way to attach an import/scan source file as auditable
    evidence in RegScale.  It performs three steps:

    1. Create an ``Evidence`` record.
    2. Upload the file to the Evidence record via ``File.upload_file_to_regscale``.
    3. Create ``EvidenceMapping`` records linking Evidence → SSP (and controls).

    :param Union[str, Path] file_path: Path to the source file.
    :param int plan_id: RegScale SecurityPlan ID to link the evidence to.
    :param str source_name: Human-readable label for the evidence title
        (e.g. ``"eMASS POA&M Workbook"``, ``"AWS GuardDuty Findings"``).
    :param bool dry_run: If True, log what would happen but skip API calls.
    :param Optional[str] description: Custom description. If omitted, a default
        is generated from the file name, plan ID, and timestamp.
    :param Optional[str] tags: Comma-separated tags for the uploaded file
        (e.g. ``"emass,import"``).
    :param int update_frequency: Evidence refresh cadence in days (default 365).
    :param Optional[list] control_ids: Optional list of ControlImplementation IDs
        to map the evidence to (in addition to the SSP mapping).
    :return: The created Evidence record ID, or None on failure / dry-run.
    :rtype: Optional[int]
    """
    resolved = Path(file_path).resolve()
    if not resolved.exists():
        logger.warning("Source file '%s' no longer exists — skipping evidence upload.", resolved)
        return None

    file_size = resolved.stat().st_size
    if file_size > MAX_EVIDENCE_FILE_SIZE:
        logger.error(
            "File '%s' (%d MB) exceeds maximum evidence upload size (%d MB) — skipping.",
            resolved.name,
            file_size // (1024 * 1024),
            MAX_EVIDENCE_FILE_SIZE // (1024 * 1024),
        )
        return None

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    title = f"{source_name} ({timestamp})"

    if description is None:
        description = f"Source file: {resolved.name}\nLinked to SecurityPlan {plan_id} on {timestamp}."

    if dry_run:
        logger.info("[DRY RUN] Would create Evidence '%s' and upload '%s' to SSP %d.", title, resolved.name, plan_id)
        return None

    # ── Dedup: skip creation if evidence for this source already exists ───────
    existing_id = _find_existing_evidence(plan_id, source_name)
    if existing_id:
        logger.info(
            "Evidence '%s' already exists (ID=%d) for SSP %d — skipping duplicate creation.",
            source_name,
            existing_id,
            plan_id,
        )
        return existing_id

    # ── 1. Create Evidence record ────────────────────────────────────────────
    due_date = (datetime.now() + timedelta(days=update_frequency)).isoformat()
    evidence = Evidence(
        title=title,
        description=description,
        status="Collected",
        updateFrequency=update_frequency,
        dueDate=due_date,
    )

    try:
        created = evidence.create()
    except Exception as exc:
        logger.error("Failed to create Evidence record for '%s': %s", resolved.name, exc)
        return None

    if not created or not created.id:
        logger.error("Evidence.create() returned no ID for '%s'.", resolved.name)
        return None

    logger.info("Created Evidence record %d: %s", created.id, created.title)

    # ── 2. Upload source file to the Evidence record ─────────────────────────
    _upload_file_to_evidence(resolved, created.id, tags)

    # ── 3. Map Evidence → SecurityPlan (and controls) ────────────────────────
    _map_evidence(created.id, plan_id, control_ids)

    return created.id
