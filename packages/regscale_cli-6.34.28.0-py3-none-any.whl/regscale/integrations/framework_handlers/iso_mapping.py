#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ISO 27001 Cross-Edition Mapping (2013 Annex A <-> 2022).

Provides bidirectional mapping between ISO/IEC 27001:2013 Annex A control IDs
(e.g. A.12.1.3) and ISO/IEC 27001:2022 control IDs (e.g. 8.6).

Source: ISO/IEC 27002:2022 Annex B (informative) correspondence table.
"""

import logging
from typing import Dict, FrozenSet, Optional, Set

logger = logging.getLogger("regscale")

# ---------------------------------------------------------------------------
# 2013 Annex A -> 2022 mapping  (many-to-one: multiple 2013 controls can map
# to the same 2022 control)
# ---------------------------------------------------------------------------
_ISO_2013_TO_2022: Dict[str, str] = {
    "A.5.1.1": "5.1",
    "A.5.1.2": "5.1",
    "A.6.1.1": "5.2",
    "A.6.1.2": "5.3",
    "A.6.1.3": "5.5",
    "A.6.1.4": "5.6",
    "A.6.1.5": "5.8",
    "A.6.2.1": "8.1",
    "A.6.2.2": "6.7",
    "A.7.1.1": "6.1",
    "A.7.1.2": "6.2",
    "A.7.2.1": "5.4",
    "A.7.2.2": "6.3",
    "A.7.2.3": "6.4",
    "A.7.3.1": "6.5",
    "A.8.1.1": "5.9",
    "A.8.1.2": "5.9",
    "A.8.1.3": "5.1",
    "A.8.1.4": "5.11",
    "A.8.2.1": "5.12",
    "A.8.2.2": "5.13",
    "A.8.2.3": "5.10",
    "A.8.3.1": "7.10",
    "A.8.3.2": "7.10",
    "A.8.3.3": "7.10",
    "A.9.1.1": "5.15",
    "A.9.1.2": "5.15",
    "A.9.2.1": "5.16",
    "A.9.2.2": "5.18",
    "A.9.2.3": "8.2",
    "A.9.2.4": "5.17",
    "A.9.2.5": "5.18",
    "A.9.2.6": "5.18",
    "A.9.3.1": "5.17",
    "A.9.4.1": "8.3",
    "A.9.4.2": "8.5",
    "A.9.4.3": "5.17",
    "A.9.4.4": "8.18",
    "A.9.4.5": "8.4",
    "A.10.1.1": "8.24",
    "A.10.1.2": "8.24",
    "A.11.1.1": "7.1",
    "A.11.1.2": "7.2",
    "A.11.1.3": "7.3",
    "A.11.1.4": "7.5",
    "A.11.1.5": "7.6",
    "A.11.1.6": "7.1",
    "A.11.2.1": "7.8",
    "A.11.2.2": "7.11",
    "A.11.2.3": "7.12",
    "A.11.2.4": "7.13",
    "A.11.2.5": "7.10",
    "A.11.2.6": "7.9",
    "A.11.2.7": "7.14",
    "A.11.2.8": "8.1",
    "A.11.2.9": "7.7",
    "A.12.1.1": "5.37",
    "A.12.1.2": "8.32",
    "A.12.1.3": "8.6",
    "A.12.1.4": "8.31",
    "A.12.2.1": "8.7",
    "A.12.3.1": "8.13",
    "A.12.4.1": "8.15",
    "A.12.4.2": "8.15",
    "A.12.4.3": "8.15",
    "A.12.4.4": "8.17",
    "A.12.5.1": "8.19",
    "A.12.6.1": "8.8",
    "A.12.6.2": "8.19",
    "A.12.7.1": "8.34",
    "A.13.1.1": "8.20",
    "A.13.1.2": "8.21",
    "A.13.1.3": "8.22",
    "A.13.2.1": "5.14",
    "A.13.2.2": "5.14",
    "A.13.2.3": "5.14",
    "A.13.2.4": "6.6",
    "A.14.1.1": "5.8",
    "A.14.1.2": "8.26",
    "A.14.1.3": "8.26",
    "A.14.2.1": "8.25",
    "A.14.2.2": "8.32",
    "A.14.2.3": "8.32",
    "A.14.2.4": "8.32",
    "A.14.2.5": "8.27",
    "A.14.2.6": "8.31",
    "A.14.2.7": "8.30",
    "A.14.2.8": "8.29",
    "A.14.2.9": "8.29",
    "A.14.3.1": "8.33",
    "A.15.1.1": "5.19",
    "A.15.1.2": "5.20",
    "A.15.1.3": "5.21",
    "A.15.2.1": "5.22",
    "A.15.2.2": "5.22",
    "A.16.1.1": "5.24",
    "A.16.1.2": "6.8",
    "A.16.1.3": "6.8",
    "A.16.1.4": "5.25",
    "A.16.1.5": "5.26",
    "A.16.1.6": "5.27",
    "A.16.1.7": "5.28",
    "A.17.1.1": "5.29",
    "A.17.1.2": "5.29",
    "A.17.1.3": "5.29",
    "A.17.2.1": "8.14",
    "A.18.1.1": "5.31",
    "A.18.1.2": "5.32",
    "A.18.1.3": "5.33",
    "A.18.1.4": "5.34",
    "A.18.1.5": "5.31",
    "A.18.2.1": "5.35",
    "A.18.2.2": "5.36",
    "A.18.2.3": "5.36",
}

# Reverse mapping: 2022 -> set of 2013 Annex A controls
_ISO_2022_TO_2013: Dict[str, FrozenSet[str]] = {}
for _annex_a, _new_id in _ISO_2013_TO_2022.items():
    _ISO_2022_TO_2013.setdefault(_new_id, set())  # type: ignore[arg-type]
    _ISO_2022_TO_2013[_new_id].add(_annex_a)  # type: ignore[union-attr]
_ISO_2022_TO_2013 = {k: frozenset(v) for k, v in _ISO_2022_TO_2013.items()}


def get_2022_for_2013(annex_a_id: str) -> Optional[str]:
    """
    Map an ISO 27001:2013 Annex A control to its 2022 equivalent.

    Accepts formats: A.12.1.3, a.12.1.3, 12.1.3

    :param str annex_a_id: 2013 Annex A control ID
    :return: 2022 control ID or None if no mapping exists
    :rtype: Optional[str]
    """
    if not annex_a_id:
        return None
    normalized = annex_a_id.strip()
    if not normalized.upper().startswith("A."):
        normalized = "A." + normalized
    return _ISO_2013_TO_2022.get(normalized.upper())


def get_2013_for_2022(control_2022: str) -> FrozenSet[str]:
    """
    Map an ISO 27001:2022 control to its 2013 Annex A equivalents.

    :param str control_2022: 2022 control ID (e.g. "8.6", "5.15")
    :return: Set of 2013 Annex A control IDs, empty if no mapping
    :rtype: FrozenSet[str]
    """
    if not control_2022:
        return frozenset()
    return _ISO_2022_TO_2013.get(control_2022.strip(), frozenset())


def get_cross_edition_variations(control_id: str) -> Set[str]:
    """
    Given any ISO 27001 control ID (either edition), return all equivalent IDs
    from the other edition plus common case/prefix variations.

    This is the primary entry point used by the compliance integration to bridge
    AWS Audit Manager's 2013 Annex A controls with RegScale SSPs using 2022 controls
    (or vice versa).

    :param str control_id: Control ID from either edition
    :return: Set of equivalent control IDs from the other edition (with variations)
    :rtype: Set[str]
    """
    if not control_id:
        return set()

    result: Set[str] = set()
    cid = control_id.strip()

    # Try 2013 -> 2022 direction
    mapped_2022 = get_2022_for_2013(cid)
    if mapped_2022:
        result.add(mapped_2022)
        result.add(mapped_2022.upper())
        result.add(mapped_2022.lower())
        return result

    # Try 2022 -> 2013 direction
    raw = cid
    if raw.upper().startswith("A."):
        raw = raw[2:]
    mapped_2013_set = get_2013_for_2022(raw)
    if mapped_2013_set:
        for annex_a in mapped_2013_set:
            result.add(annex_a)
            result.add(annex_a.upper())
            result.add(annex_a.lower())
            without_prefix = annex_a[2:] if annex_a.upper().startswith("A.") else annex_a
            result.add(without_prefix)
        return result

    return result
