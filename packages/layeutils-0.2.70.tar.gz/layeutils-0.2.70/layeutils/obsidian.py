import asyncio
import json
import logging
import os
from collections import OrderedDict, defaultdict
from typing import Optional

import httpx

# 全局变量：Obsidian Local REST API 服务器地址
DEFAULT_SERVER = 'http://home.laye.wang:27123'
# 异步客户端配置
DEFAULT_TIMEOUT = 30.0
MAX_CONCURRENT_REQUESTS = 50  # 最大并发请求数


def _build_auth_headers(obsidian_token: str) -> dict:
    """构建带有认证的请求头"""
    return {'Authorization': f'Bearer {obsidian_token}'}


def _make_request(method: str, url: str, obsidian_token: str, **kwargs) -> httpx.Response:
    """发起 HTTP 请求并检查响应状态（同步版本）"""
    headers = kwargs.pop('headers', {})
    headers.update(_build_auth_headers(obsidian_token))
    response = httpx.request(method, url, headers=headers, **kwargs)
    response.raise_for_status()
    return response


async def _make_request_async(
        method: str,
        url: str,
        obsidian_token: str,
        client: httpx.AsyncClient,
        **kwargs
) -> httpx.Response:
    """发起异步 HTTP 请求并检查响应状态"""
    headers = kwargs.pop('headers', {})
    headers.update(_build_auth_headers(obsidian_token))
    response = await client.request(method, url, headers=headers, **kwargs)
    response.raise_for_status()
    return response


def get_notes(obsidian_token: str, path: str = '', format: str = 'application/json', server: str = DEFAULT_SERVER) -> str:
    """使用Local REST API插件；取回单个note或文件夹下note名列表（同步版本）

    Args:
        obsidian_token (str): Obsidian Local REST API Token
        path (str, optional): 如果给定的是文件夹（需要以`/`结尾）则返回的是文件夹下所有note名列表；如果给定的是note文件名，则返回note内容. Defaults to ''.
        format (str, optional): 默认是`application/json`。可以修改成`application/vnd.olrapi.note+json`. Defaults to 'application/json'.
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.

    Returns:
        str: API 响应的文本内容（JSON 字符串或笔记内容）
    """
    import urllib.parse
    headers = {'accept': format}
    # URL 编码路径，处理特殊字符
    encoded_path = urllib.parse.quote(path, safe='/')
    response = _make_request('GET', f'{server}/vault/{encoded_path}', obsidian_token, headers=headers)
    return response.text


async def get_notes_async(
        obsidian_token: str,
        path: str = '',
        format: str = 'application/json',
        server: str = DEFAULT_SERVER,
        client: Optional[httpx.AsyncClient] = None
) -> str:
    """使用Local REST API插件；取回单个note或文件夹下note名列表（异步版本）

    Args:
        obsidian_token (str): Obsidian Local REST API Token
        path (str, optional): 如果给定的是文件夹（需要以`/`结尾）则返回的是文件夹下所有note名列表；如果给定的是note文件名，则返回note内容. Defaults to ''.
        format (str, optional): 默认是`application/json`。可以修改成`application/vnd.olrapi.note+json`. Defaults to 'application/json'.
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.
        client (httpx.AsyncClient, optional): 共享的异步客户端. Defaults to None.

    Returns:
        str: API 响应的文本内容（JSON 字符串或笔记内容）
    """
    import urllib.parse
    headers = {'accept': format}
    # URL 编码路径，处理特殊字符（如 % 和多余空格）
    encoded_path = urllib.parse.quote(path, safe='/')
    if client is None:
        async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as new_client:
            response = await _make_request_async('GET', f'{server}/vault/{encoded_path}', obsidian_token, new_client, headers=headers)
            return response.text
    else:
        response = await _make_request_async('GET', f'{server}/vault/{encoded_path}', obsidian_token, client, headers=headers)
        return response.text


def get_note_frontmatter(note_content: str) -> dict:
    """解析笔记的frontmatter

    Args:
        note_content (str): 笔记的完整内容

    Returns:
        dict: frontmatter 的键值对字典，如果解析失败则返回空字典
    """
    import yaml

    frontmatter = {}
    if note_content.startswith("---\n"):
        try:
            frontmatter = yaml.safe_load(note_content.split("---\n")[1])
        except yaml.YAMLError as e:
            print(f"解析frontmatter失败: {e}")
    return frontmatter


def insert_content_to_note(
        obsidian_token: str,
        path: str,
        content: str,
        heading_place: str,
        content_insert_position: str = 'beginning',
        server: str = DEFAULT_SERVER
) -> httpx.Response:
    """在指定位置（heading区分）插入内容，heading是必须的，如果没有heading的note，不能使用此方法

    Args:
        obsidian_token (str): Obsidian Local REST API Token
        path (str): 笔记文件路径
        content (str): 要插入的内容
        heading_place (str): 如果是多级heading → `level_1_heading::level_2_heading`
        content_insert_position (str, optional): ['beginning', 'end']. Defaults to 'beginning'.
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.

    Returns:
        requests.Response: API 响应对象
    """
    headers = {
        'accept': '*/*',
        'Heading': heading_place,
        'Content-Insertion-Position': content_insert_position,
        'Heading-Boundary': '::',
        'Content-Type': 'text/markdown',
    }

    response = _make_request('PATCH', f'{server}/vault/{path}', obsidian_token, headers=headers, data=content)
    return response


def update_note(
        obsidian_token: str,
        path: str,
        content: str,
        server: str = DEFAULT_SERVER
) -> httpx.Response:
    """更新内容到给定的note文件上，如果给定的note文件名不存在，则新建note，如果存在则**清空内容更新**

    Args:
        obsidian_token (str): Obsidian Local REST API Token
        path (str): 笔记文件路径
        content (str): 要更新的内容
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.

    Returns:
        requests.Response: API 响应对象
    """
    headers = {
        'accept': '*/*',
        'Content-Type': 'text/markdown',
    }

    response = _make_request('PUT', f'{server}/vault/{path}', obsidian_token, headers=headers, data=content)
    return response


def delete_note(
        obsidian_token: str,
        path: str,
        server: str = DEFAULT_SERVER
) -> httpx.Response:
    """删除给定的note文件

    Args:
        obsidian_token (str): Obsidian Local REST API Token
        path (str): 笔记文件路径
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.

    Returns:
        requests.Response: API 响应对象
    """
    headers = {'accept': '*/*'}

    response = _make_request('PUT', f'{server}/vault/{path}', obsidian_token, headers=headers)
    return response


def append_content_to_note(
        obsidian_token: str,
        path: str,
        content: str,
        server: str = DEFAULT_SERVER
) -> httpx.Response:
    """将给定内容附加到给定的note文件末尾，如果给定的note文件名不存在，则新建note

    Args:
        obsidian_token (str): Obsidian Local REST API Token
        path (str): 笔记文件路径
        content (str): 要附加的内容
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.

    Returns:
        requests.Response: API 响应对象
    """
    headers = {
        'accept': '*/*',
        'Content-Type': 'text/markdown',
    }

    response = _make_request('POST', f'{server}/vault/{path}', obsidian_token, headers=headers, data=content)
    return response


def search_note_name_by_dql(
        obsidian_token: str,
        query: str,
        server: str = DEFAULT_SERVER
) -> httpx.Response:
    """通过DQL语句查询note列表

    Args:
        obsidian_token (str): Obsidian Local REST API Token
        query (str): 类似在OB中使用dataview查询TABLE(不能使用LIST)
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.

    Returns:
        requests.Response: API 响应对象
    """
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/vnd.olrapi.dataview.dql+txt',
    }

    response = _make_request('POST', f'{server}/search/', obsidian_token, headers=headers, data=query)
    return response


def remove_frontmatter_property(folder_path: str, property_name: str) -> None:
    """给定的文件夹中所有后缀为.md的文件，删除frontmatter信息中给定的property

    Args:
        folder_path (str): 文件夹路径
        property_name (str): 要删除的 frontmatter 属性名
    """
    import yaml

    for filename in os.listdir(folder_path):
        if filename.endswith(".md"):
            file_path = os.path.join(folder_path, filename)
            with open(file_path, 'r+') as f:
                content = f.read()
                try:
                    _, frontmatter, body = content.split("---\n", 2)
                    frontmatter_dict = yaml.safe_load(frontmatter)
                    frontmatter_dict.pop(property_name)
                    updated_frontmatter = yaml.dump(frontmatter_dict, sort_keys=False,
                                                    default_flow_style=False, allow_unicode=True)
                    f.seek(0)
                    f.write("---\n{}\n---\n{}".format(updated_frontmatter, body))
                except yaml.YAMLError as exc:
                    logging.error(f"Error parsing YAML in {filename}: {exc}")
                except ValueError:
                    logging.error(f"File {filename} does not appear to have a frontmatter.")


def add_frontmatter_property(
        folder_path: str, before_property: str, property_name: str, default_value: str = ""
) -> None:
    """给定的文件夹中所有后缀为.md的文件，在frontmatter信息中的before_property属性之前插入新属性

    Args:
        folder_path (str): 文件夹路径
        before_property (str): 在此属性之前插入新属性
        property_name (str): 要插入的属性名
        default_value (str, optional): 新属性的默认值. Defaults to "".
    """
    import yaml

    for filename in os.listdir(folder_path):
        if filename.endswith(".md"):
            file_path = os.path.join(folder_path, filename)
            with open(file_path, 'r+') as f:
                content = f.read()
                try:
                    _, frontmatter, body = content.split("---\n", 2)
                    frontmatter_dict = yaml.safe_load(frontmatter)
                    # 将字典转换为 OrderedDict
                    ordered_dict = OrderedDict(frontmatter_dict)
                    # 创建一个新的 OrderedDict，并将 "Related" 插入到指定位置
                    new_ordered_dict = OrderedDict()
                    for key, value in ordered_dict.items():
                        if key == before_property:
                            new_ordered_dict[property_name] = default_value
                        new_ordered_dict[key] = value
                    updated_frontmatter = yaml.dump(
                        dict(new_ordered_dict),
                        sort_keys=False, default_flow_style=False, allow_unicode=True)
                    f.seek(0)
                    f.write("---\n{}\n---\n{}".format(updated_frontmatter, body))
                except yaml.YAMLError as exc:
                    logging.error(f"Error parsing YAML in {filename}: {exc}")
                except ValueError:
                    logging.error(f"File {filename} does not appear to have a frontmatter.")


def append_tag_frontmatter_property(folder_path: str, tag: str) -> None:
    """给定的文件夹中所有后缀为.md的文件，在frontmatter的tags列表中添加标签

    Args:
        folder_path (str): 文件夹路径
        tag (str): 要添加的标签
    """
    import yaml

    for filename in os.listdir(folder_path):
        if filename.endswith(".md"):
            file_path = os.path.join(folder_path, filename)
            with open(file_path, 'r+') as f:
                content = f.read()
                try:
                    _, frontmatter, body = content.split("---\n", 2)
                    frontmatter_dict = yaml.safe_load(frontmatter)
                    tag_list = frontmatter_dict['tags']
                    if not tag_list:
                        tag_list = []
                    tag_list.append(tag)
                    frontmatter_dict['tags'] = tag_list
                    updated_frontmatter = yaml.dump(frontmatter_dict, sort_keys=False,
                                                    default_flow_style=False, allow_unicode=True)
                    f.seek(0)
                    f.write("---\n{}\n---\n{}".format(updated_frontmatter, body))
                except yaml.YAMLError as exc:
                    logging.error(f"Error parsing YAML in {filename}: {exc}")
                except ValueError:
                    logging.error(f"File {filename} does not appear to have a frontmatter.")


def print_note_tree(
        folder: str, 
        root_note: str, 
        obsidian_token: str, 
        server: str = DEFAULT_SERVER
) -> None:
    """打印给定文件夹下的笔记树（同步版本）

    Args:
        folder (str): 文件夹路径
        root_note (str): 根笔记名
        obsidian_token (str): Obsidian Local REST API Token
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.
    """

    def print_tree(tree, node, level=0):
        """递归打印树状结构"""
        print("    " * level + "- [[" + node + "]]")
        for child in tree.get(node, []):
            print_tree(tree, child, level + 1)

    notes = json.loads(get_notes(obsidian_token, f"{folder}/", server=server))["files"]
    tree = defaultdict(list)

    # 首先构建父子关系
    for note in notes:
        content = get_notes(obsidian_token, f"{folder}/{note}", server=server)
        frontmatter = get_note_frontmatter(content)
        parent = frontmatter.get("parent", "")
        if parent:
            parent_note = parent.strip("[]").split("|")[0]
            # 统一使用不带 .md 后缀的名称作为 key
            parent_key = parent_note.split('.md')[0]
            child_key = note.split('.md')[0]
            tree[parent_key].append(child_key)

    # root_note 可能带 .md 后缀，需要统一
    root_key = root_note.split('.md')[0]
    print_tree(tree, root_key)


async def print_note_tree_async(
        folder: str,
        root_note: str,
        obsidian_token: str,
        server: str = DEFAULT_SERVER,
        max_concurrent: int = MAX_CONCURRENT_REQUESTS
) -> None:
    """打印给定文件夹下的笔记树（异步并发版本，大幅提升性能）

    Args:
        folder (str): 文件夹路径
        root_note (str): 根笔记名
        obsidian_token (str): Obsidian Local REST API Token
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.
        max_concurrent (int, optional): 最大并发请求数. Defaults to MAX_CONCURRENT_REQUESTS.

    Example:
        >>> asyncio.run(print_note_tree_async(
        ...     folder='02.Investment',
        ...     root_note='!MOC- Inner Circle Trader.md',
        ...     obsidian_token='your_token_here'
        ... ))
    """
    import yaml

    def _print_tree(tree, node, level=0):
        """递归打印树状结构"""
        print("    " * level + "- [[" + node + "]]")
        for child in tree.get(node, []):
            _print_tree(tree, child, level + 1)

    # 步骤1: 获取笔记列表（1次API调用）
    notes_response = await get_notes_async(obsidian_token, f"{folder}/", server=server)
    notes = json.loads(notes_response)["files"]

    # 步骤2: 使用信号量限制并发数，批量获取所有笔记内容
    semaphore = asyncio.Semaphore(max_concurrent)

    async def fetch_note_content(note: str) -> tuple[str, dict]:
        """获取单个笔记的内容和frontmatter"""
        async with semaphore:
            content = await get_notes_async(obsidian_token, f"{folder}/{note}", server=server)
            frontmatter = {}
            if content.startswith("---\n"):
                try:
                    frontmatter = yaml.safe_load(content.split("---\n")[1]) or {}
                except yaml.YAMLError as e:
                    print(f"解析frontmatter失败: {e}")
            return note, frontmatter

    # 并发获取所有笔记的frontmatter
    tasks = [fetch_note_content(note) for note in notes]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # 构建树状结构
    tree: dict = defaultdict(list)
    for result in results:
        if isinstance(result, Exception):
            print(f"获取笔记失败: {result}")
            continue
        note, frontmatter = result
        parent = frontmatter.get("parent", "")
        if parent:
            parent_note = parent.strip("[]").split("|")[0]
            # 统一使用不带 .md 后缀的名称作为 key
            parent_key = parent_note.split('.md')[0]
            child_key = note.split('.md')[0]
            tree[parent_key].append(child_key)

    # root_note 可能带 .md 后缀，需要统一
    root_key = root_note.split('.md')[0]
    _print_tree(tree, root_key)


def print_note_tree_simple(
        folder: str,
        root_note: str,
        obsidian_token: str,
        server: str = DEFAULT_SERVER
) -> None:
    """打印给定文件夹下的笔记树的简单包装器（兼容旧API）

    Args:
        folder (str): 文件夹路径
        root_note (str): 根笔记名
        obsidian_token (str): Obsidian Local REST API Token
        server (str, optional): Obsidian 服务器地址. Defaults to DEFAULT_SERVER.

    Note:
        推荐使用 print_note_tree_async() 替代以获得更好的性能。
    """
    asyncio.run(print_note_tree_async(folder, root_note, obsidian_token, server))
