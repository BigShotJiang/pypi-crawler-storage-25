"""
NLSQ Qt GUI Code Editor Widget

This widget provides a Python code editor with syntax highlighting
for defining custom model functions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from PySide6.QtCore import Signal
from PySide6.QtGui import (
    QColor,
    QFont,
    QFontDatabase,
    QSyntaxHighlighter,
    QTextCharFormat,
)
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QVBoxLayout,
    QWidget,
)

if TYPE_CHECKING:
    from PySide6.QtGui import QTextDocument

    from nlsq.gui_qt.theme import ThemeConfig

__all__ = ["CodeEditorWidget", "PythonHighlighter"]

# Python keywords for highlighting
PYTHON_KEYWORDS = {
    "and",
    "as",
    "assert",
    "async",
    "await",
    "break",
    "class",
    "continue",
    "def",
    "del",
    "elif",
    "else",
    "except",
    "finally",
    "for",
    "from",
    "global",
    "if",
    "import",
    "in",
    "is",
    "lambda",
    "nonlocal",
    "not",
    "or",
    "pass",
    "raise",
    "return",
    "try",
    "while",
    "with",
    "yield",
    "True",
    "False",
    "None",
}

# Built-in functions
PYTHON_BUILTINS = {
    "abs",
    "all",
    "any",
    "bin",
    "bool",
    "bytes",
    "callable",
    "chr",
    "dict",
    "dir",
    "divmod",
    "enumerate",
    "filter",
    "float",
    "format",
    "frozenset",
    "getattr",
    "hasattr",
    "hash",
    "hex",
    "id",
    "input",
    "int",
    "isinstance",
    "issubclass",
    "iter",
    "len",
    "list",
    "map",
    "max",
    "min",
    "next",
    "object",
    "oct",
    "open",
    "ord",
    "pow",
    "print",
    "range",
    "repr",
    "reversed",
    "round",
    "set",
    "setattr",
    "slice",
    "sorted",
    "str",
    "sum",
    "super",
    "tuple",
    "type",
    "vars",
    "zip",
}

# Scientific computing keywords
NUMPY_KEYWORDS = {
    "np",
    "jnp",
    "numpy",
    "jax",
    "exp",
    "log",
    "sin",
    "cos",
    "tan",
    "sqrt",
    "abs",
    "power",
    "array",
    "zeros",
    "ones",
    "linspace",
    "arange",
    "sum",
    "mean",
    "std",
    "where",
    "pi",
    "e",
}


class PythonHighlighter(QSyntaxHighlighter):
    """Syntax highlighter for Python code."""

    def __init__(self, document: QTextDocument) -> None:
        """Initialize the syntax highlighter with default (dark) colors.

        Call :meth:`set_theme_colors` to switch to a different palette.

        Args:
            document: The QTextDocument to highlight
        """
        super().__init__(document)
        # Set default dark-theme colors; overridden by set_theme_colors()
        self._build_formats(
            keyword="#569CD6",
            builtin="#4EC9B0",
            string="#CE9178",
            comment="#6A9955",
            number="#B5CEA8",
            function="#DCDCAA",
            decorator="#C586C0",
        )

    def _build_formats(
        self,
        keyword: str,
        builtin: str,
        string: str,
        comment: str,
        number: str,
        function: str,
        decorator: str,
    ) -> None:
        """Build QTextCharFormat objects from color strings.

        Args:
            keyword: Color for language keywords
            builtin: Color for built-in functions
            string: Color for string literals
            comment: Color for comments
            number: Color for numeric literals
            function: Color for function-definition names and scientific identifiers
            decorator: Color for decorators
        """
        self._keyword_format = QTextCharFormat()
        self._keyword_format.setForeground(QColor(keyword))
        self._keyword_format.setFontWeight(QFont.Weight.Bold)

        self._builtin_format = QTextCharFormat()
        self._builtin_format.setForeground(QColor(builtin))

        self._numpy_format = QTextCharFormat()
        self._numpy_format.setForeground(QColor(function))

        self._string_format = QTextCharFormat()
        self._string_format.setForeground(QColor(string))

        self._comment_format = QTextCharFormat()
        self._comment_format.setForeground(QColor(comment))
        self._comment_format.setFontItalic(True)

        self._number_format = QTextCharFormat()
        self._number_format.setForeground(QColor(number))

        self._function_format = QTextCharFormat()
        self._function_format.setForeground(QColor(function))

        self._decorator_format = QTextCharFormat()
        self._decorator_format.setForeground(QColor(decorator))

    def set_theme_colors(self, theme: ThemeConfig) -> None:
        """Update all format colors from a ThemeConfig and force re-highlight.

        Args:
            theme: Theme configuration carrying syntax_* color fields
        """
        self._build_formats(
            keyword=theme.syntax_keyword,
            builtin=theme.syntax_builtin,
            string=theme.syntax_string,
            comment=theme.syntax_comment,
            number=theme.syntax_number,
            function=theme.syntax_function,
            decorator=theme.syntax_decorator,
        )
        # Trigger a full re-highlight pass
        self.rehighlight()

    def highlightBlock(self, text: str) -> None:
        """Apply highlighting to a block of text.

        Args:
            text: The text to highlight
        """
        # Highlight keywords
        self._highlight_words(text, PYTHON_KEYWORDS, self._keyword_format)

        # Highlight builtins
        self._highlight_words(text, PYTHON_BUILTINS, self._builtin_format)

        # Highlight numpy/jax keywords
        self._highlight_words(text, NUMPY_KEYWORDS, self._numpy_format)

        # Highlight function definitions
        self._highlight_function_defs(text)

        # Highlight numbers
        self._highlight_numbers(text)

        # Highlight strings (single and double quotes)
        self._highlight_strings(text)

        # Highlight decorators (@jit, @partial, …)
        self._highlight_decorators(text)

        # Highlight comments (must be last to override other highlighting)
        self._highlight_comments(text)

    def _highlight_words(
        self, text: str, words: set[str], fmt: QTextCharFormat
    ) -> None:
        """Highlight specific words in the text."""
        import re

        for word in words:
            pattern = rf"\b{re.escape(word)}\b"
            for match in re.finditer(pattern, text):
                self.setFormat(match.start(), match.end() - match.start(), fmt)

    def _highlight_function_defs(self, text: str) -> None:
        """Highlight function definition names."""
        import re

        pattern = r"\bdef\s+(\w+)"
        for match in re.finditer(pattern, text):
            # Highlight the function name (group 1)
            start = match.start(1)
            length = len(match.group(1))
            self.setFormat(start, length, self._function_format)

    def _highlight_numbers(self, text: str) -> None:
        """Highlight numeric literals."""
        import re

        # Match integers, floats, and scientific notation
        pattern = r"\b\d+\.?\d*(?:[eE][+-]?\d+)?\b"
        for match in re.finditer(pattern, text):
            self.setFormat(
                match.start(), match.end() - match.start(), self._number_format
            )

    def _highlight_strings(self, text: str) -> None:
        """Highlight string literals."""
        import re

        # Single-quoted strings
        for match in re.finditer(r"'[^'\\]*(?:\\.[^'\\]*)*'", text):
            self.setFormat(
                match.start(), match.end() - match.start(), self._string_format
            )
        # Double-quoted strings
        for match in re.finditer(r'"[^"\\]*(?:\\.[^"\\]*)*"', text):
            self.setFormat(
                match.start(), match.end() - match.start(), self._string_format
            )

    def _highlight_decorators(self, text: str) -> None:
        """Highlight decorator lines (@jit, @partial, etc.)."""
        import re

        for match in re.finditer(r"@\w+", text):
            self.setFormat(
                match.start(), match.end() - match.start(), self._decorator_format
            )

    def _highlight_comments(self, text: str) -> None:
        """Highlight comments."""
        import re

        for match in re.finditer(r"#.*$", text):
            self.setFormat(
                match.start(), match.end() - match.start(), self._comment_format
            )


class CodeEditorWidget(QWidget):
    """Python code editor with syntax highlighting.

    Provides:
    - Python syntax highlighting
    - Line numbers (simplified)
    - Syntax validation
    - Function name extraction
    """

    # Signals
    code_changed = Signal(str)
    validation_changed = Signal(bool, str)  # is_valid, error_message

    def __init__(self, parent: QWidget | None = None) -> None:
        """Initialize the code editor widget.

        Args:
            parent: Parent widget
        """
        super().__init__(parent)

        from nlsq.gui_qt.theme import DARK_THEME

        self._theme: ThemeConfig = DARK_THEME
        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self) -> None:
        """Set up the widget UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # Editor with monospace font
        editor_layout = QHBoxLayout()
        editor_layout.setSpacing(0)
        editor_layout.setContentsMargins(0, 0, 0, 0)

        self._editor = QPlainTextEdit()
        self._editor.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)

        # Set monospace font
        font = QFontDatabase.systemFont(QFontDatabase.FixedFont)
        font.setPointSize(10)
        self._editor.setFont(font)

        # Set placeholder text
        self._editor.setPlaceholderText(
            "import jax.numpy as jnp\n\n"
            "def model(x, a, b, c):\n"
            "    return a * jnp.exp(-b * x) + c"
        )

        # Apply syntax highlighter
        self._highlighter = PythonHighlighter(self._editor.document())

        editor_layout.addWidget(self._editor)
        layout.addLayout(editor_layout)

        # Validation status
        self._validation_label = QLabel("")
        self._validation_label.setWordWrap(True)
        layout.addWidget(self._validation_label)

    def _connect_signals(self) -> None:
        """Connect internal signals."""
        self._editor.textChanged.connect(self._on_text_changed)

    def _on_text_changed(self) -> None:
        """Handle text changes."""
        code = self._editor.toPlainText()
        self.code_changed.emit(code)

        # Validate syntax
        is_valid, message = self.validate_syntax()
        self._update_validation_display(is_valid, message)
        self.validation_changed.emit(is_valid, message)

    def _update_validation_display(self, is_valid: bool, message: str) -> None:
        """Update the validation display.

        Args:
            is_valid: Whether the code is valid
            message: Validation message
        """
        if not self._editor.toPlainText().strip():
            self._validation_label.setText("")
            return

        if is_valid:
            funcs = self.get_function_names()
            if funcs:
                self._validation_label.setText(f"Functions found: {', '.join(funcs)}")
                self._validation_label.setStyleSheet(f"color: {self._theme.stat_good};")
            else:
                self._validation_label.setText("No functions defined")
                self._validation_label.setStyleSheet(
                    f"color: {self._theme.stat_warning};"
                )
        else:
            self._validation_label.setText(f"Error: {message}")
            self._validation_label.setStyleSheet(f"color: {self._theme.stat_bad};")

    def _reapply_validation_color(self, theme: ThemeConfig) -> None:
        """Refresh the validation label color after a theme change.

        Args:
            theme: New theme configuration
        """
        current_text = self._validation_label.text()
        if not current_text:
            return

        if current_text.startswith("Functions found"):
            self._validation_label.setStyleSheet(f"color: {theme.stat_good};")
        elif current_text.startswith("No functions"):
            self._validation_label.setStyleSheet(f"color: {theme.stat_warning};")
        elif current_text.startswith("Error"):
            self._validation_label.setStyleSheet(f"color: {theme.stat_bad};")

    def get_code(self) -> str:
        """Get the current code.

        Returns:
            The code content
        """
        return self._editor.toPlainText()

    def set_code(self, code: str) -> None:
        """Set the code content.

        Args:
            code: The code to set
        """
        self._editor.setPlainText(code)

    def get_function_names(self) -> list[str]:
        """Get function names defined in the code.

        Returns:
            List of function names
        """
        from nlsq.gui_qt.adapters.model_adapter import list_functions_in_module

        code = self._editor.toPlainText()
        if not code.strip():
            return []

        return list_functions_in_module(code)

    def validate_syntax(self) -> tuple[bool, str]:
        """Validate the code syntax.

        Returns:
            Tuple of (is_valid, error_message)
        """
        import ast

        code = self._editor.toPlainText()
        if not code.strip():
            return True, ""

        try:
            ast.parse(code)
            return True, "Syntax valid"
        except SyntaxError as e:
            line = e.lineno or 1
            return False, f"Line {line}: {e.msg}"

    def set_theme(self, theme: ThemeConfig) -> None:
        """Apply theme to this widget.

        Args:
            theme: Theme configuration
        """
        self._theme = theme

        # Editor background and base text color
        bg = theme.surface if theme.is_dark else theme.background
        self._editor.setStyleSheet(
            f"background-color: {bg}; "
            f"color: {theme.text_primary}; "
            f"border: 1px solid {theme.border};"
        )

        # Update syntax highlighter colors
        self._highlighter.set_theme_colors(theme)

        # Re-apply validation display so its color uses theme too
        self._reapply_validation_color(theme)

    def setReadOnly(self, read_only: bool) -> None:
        """Set read-only mode.

        Args:
            read_only: Whether to make the editor read-only
        """
        self._editor.setReadOnly(read_only)

    def setMaximumHeight(self, height: int) -> None:
        """Set maximum height for both the widget and its internal editor.

        Args:
            height: Maximum height in pixels
        """
        super().setMaximumHeight(height)
        self._editor.setMaximumHeight(height)
