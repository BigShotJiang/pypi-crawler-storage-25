# Documentation Changelog

## v0.6.11 (2026-03-12)
- Skip sparsity detection when `tr_solver` is already set (7–8ms per-call savings)
- Fix Windows CI: catch `AttributeError` for POSIX-only `os.sysconf` in xdist worker cap hook
- Align `release.yml` test step with `ci.yml` to prevent timeout on publish-triggered test runs
- Replace `warnings.warn()` with `logging.debug()` in SmartCache for operational fallback paths
- Reduce JIT cache clearing interval and add `pytest_xdist_auto_num_workers` hook for OOM prevention
- Align config tested-on version comments with local environment
- Update `uv.lock` for black 26.3.1

## v0.6.10 (2026-03-09)
- Added `check_plugin_conflicts()` for CUDA plugin dual-install and version-mismatch detection in `device.py`
- Fixed misleading GPU warning header; expanded uninstall command to include CUDA plugin packages
- Promoted xxhash, pyyaml, evosax, psutil, and dev/test tools to core dependencies (single `uv sync`)
- Removed `extra_requirements: [docs]` from `.readthedocs.yaml`; docs deps covered by core
- Added `gpu-diagnose` Makefile target and 3-step CUDA 13 install with conflict verification
- Major `architecture.rst` overhaul reflecting v0.6.4+ orchestration components and facades
- Trimmed ~1500 lines of redundant inline code blocks from tutorials 01–06
- Refreshed 18 autodoc RST stubs and added 5 new API stubs (stability.guard, utils.diagnostics, callbacks, core.factories, interfaces)
- Clarified mixed-precision fallback log message; added streaming docstring note
- Moved deferred `scipy.stats` imports to module level in GUI export/results pages
- Security: cryptography 46.0.4 → 46.0.5 (CVE-2026-26007), pillow 12.1.0 → 12.1.1 (CVE-2026-25990)

## v0.6.9 (2026-02-14)
- Bump version to 0.6.9

## v0.6.8 (2026-01-28)
- Fixed critical GUI startup crashes on macOS (SIGBUS) caused by OpenGL/Metal conflicts
- Enhanced JAX platform guards and device detection reliability
- Unified logging handlers to prevent file lock issues on Windows
- Hardened test suite against environmental variability and timeouts
- Fixed GUI cache directory cleanup on shutdown


## v0.6.4 (2026-01-14)
- Updated version references from v0.7.0 to v0.6.4 across all orchestration documentation
- Added CurveFit decomposition architecture documentation (v0.6.4 feature)
- Updated package structure references to v0.6.4

## v0.6.0 (2026-01-06)
- Reorganized documentation into Routine User Guide and Advanced User Guide
- Consolidated 3 migration files into single comprehensive `howto/migration.rst`
- Removed stale deprecation notices from result module
- Removed 8 non-existent workflow presets from CLI documentation
- Fixed broken documentation links in README

## v0.5.4 (2026-01-05)
- Migrated to Furo theme for modern documentation styling
- Removed all deprecated functionality from NLSQ package
- Comprehensive documentation update with AST-based code analysis (94.9% coverage)
- Fixed pre-push hook CI interference
- Fixed Windows resource module import compatibility

## v0.5.3 (2026-01-04)
- Replaced pyqtdarktheme with Qt 6.5+ built-in color scheme (`setColorScheme()`)
- Updated dependency versions: JAX 0.8.2, NumPy 2.4.0, SciPy 1.16.3, ruff 0.14.10, mypy 1.19.1
- Added CHANGELOG entries for v0.5.0, v0.5.1, v0.5.2 release history
- Reorganized benchmark suite into ci/components/microbench directories

## v0.5.2 (2026-01-04)
- 15% performance improvement in TRF optimizer (10K point fit: 1.04s → 0.88s)
- Fixed JIT compatibility in TRF subproblem solvers
- Fixed enum identity issues in parallel test execution

## v0.5.1 (2026-01-03)
- Added `nlsq.gui_qt` API documentation to Sphinx
- Fixed README link to GUI user guide (now points to ReadTheDocs)
- Updated README GUI description to reflect pyqtgraph plots (was incorrectly referencing Plotly)
- Fixed pre-commit issues: refactored complex functions, added contextlib.suppress, created .secrets.baseline
- Added mypy overrides for PySide6, pyqtgraph, and qdarktheme in pyproject.toml

## v0.5.0 (2026-01-02)
- **BREAKING**: Removed Streamlit GUI in favor of native Qt desktop application
  - The `nlsq.gui` package has been removed entirely
  - Use `nlsq.gui_qt` and `nlsq-gui` command for the desktop GUI
  - Removed `gui` optional extra from pyproject.toml; use `gui_qt` instead
  - Install with: `pip install "nlsq[gui_qt]"`
- Removed legacy StreamingOptimizer/StreamingConfig and the Adam warmup path from docs; use AdaptiveHybridStreamingOptimizer with HybridStreamingConfig (L-BFGS warmup) for large datasets.
- Removed DataGenerator, create_hdf5_dataset, and fit_unlimited_data from examples/docs; use LargeDatasetFitter or AdaptiveHybridStreamingOptimizer instead.
- Updated streaming workflow guidance to reflect hybrid streaming only.
