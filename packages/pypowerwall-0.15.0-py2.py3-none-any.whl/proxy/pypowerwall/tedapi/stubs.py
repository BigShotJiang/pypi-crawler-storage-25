import copy

_API_METERS_AGGREGATES_TEMPLATE = {
    "site": {
        "last_communication_time": None,
        "instant_power": None,
        "instant_reactive_power": 0,
        "instant_apparent_power": 0,
        "frequency": 0,
        "energy_exported": 0,
        "energy_imported": 0,
        "instant_average_voltage": 0,
        "instant_average_current": 0,
        "i_a_current": 0,
        "i_b_current": 0,
        "i_c_current": 0,
        "last_phase_voltage_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_power_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_energy_communication_time": "0001-01-01T00:00:00Z",
        "timeout": 1500000000,
        "num_meters_aggregated": 1,
        "instant_total_current": None
    },
    "battery": {
        "last_communication_time": None,
        "instant_power": None,
        "instant_reactive_power": 0,
        "instant_apparent_power": 0,
        "frequency": 0,
        "energy_exported": 0,
        "energy_imported": 0,
        "instant_average_voltage": 0,
        "instant_average_current": 0,
        "i_a_current": 0,
        "i_b_current": 0,
        "i_c_current": 0,
        "last_phase_voltage_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_power_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_energy_communication_time": "0001-01-01T00:00:00Z",
        "timeout": 1500000000,
        "num_meters_aggregated": None,
        "instant_total_current": None
    },
    "load": {
        "last_communication_time": None,
        "instant_power": None,
        "instant_reactive_power": 0,
        "instant_apparent_power": 0,
        "frequency": 0,
        "energy_exported": 0,
        "energy_imported": 0,
        "instant_average_voltage": 0,
        "instant_average_current": 0,
        "i_a_current": 0,
        "i_b_current": 0,
        "i_c_current": 0,
        "last_phase_voltage_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_power_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_energy_communication_time": "0001-01-01T00:00:00Z",
        "timeout": 1500000000,
        "instant_total_current": None
    },
    "solar": {
        "last_communication_time": None,
        "instant_power": None,
        "instant_reactive_power": 0,
        "instant_apparent_power": 0,
        "frequency": 0,
        "energy_exported": 0,
        "energy_imported": 0,
        "instant_average_voltage": 0,
        "instant_average_current": 0,
        "i_a_current": 0,
        "i_b_current": 0,
        "i_c_current": 0,
        "last_phase_voltage_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_power_communication_time": "0001-01-01T00:00:00Z",
        "last_phase_energy_communication_time": "0001-01-01T00:00:00Z",
        "timeout": 1000000000,
        "num_meters_aggregated": None,
        "instant_total_current": None
    }
}

def API_METERS_AGGREGATES_STUB():
    """Return a fresh copy of the API meters aggregates stub to prevent shared-state mutation."""
    return copy.deepcopy(_API_METERS_AGGREGATES_TEMPLATE)

_API_SYSTEM_STATUS_TEMPLATE = {  # TODO: Fill in 0 values
    "command_source": "Configuration",
    "battery_target_power": 0,
    "battery_target_reactive_power": 0,
    "nominal_full_pack_energy": None,
    "nominal_energy_remaining": None,
    "max_power_energy_remaining": 0,  # TODO: Calculate
    "max_power_energy_to_be_charged": 0,  # TODO: Calculate
    "max_charge_power": None,
    "max_discharge_power": None,
    "max_apparent_power": None,
    "instantaneous_max_discharge_power": 0,
    "instantaneous_max_charge_power": 0,
    "instantaneous_max_apparent_power": 0,
    "hardware_capability_charge_power": 0,
    "hardware_capability_discharge_power": 0,
    "grid_services_power": None,
    "system_island_state": None,
    "available_blocks": None,
    "available_charger_blocks": 0,
    "battery_blocks": [],  # TODO: Populate with battery blocks
    "ffr_power_availability_high": 0,
    "ffr_power_availability_low": 0,
    "load_charge_constraint": 0,
    "max_sustained_ramp_rate": 0,
    "grid_faults": [],  # TODO: Populate with grid faults
    "can_reboot": "Yes",
    "smart_inv_delta_p": 0,
    "smart_inv_delta_q": 0,
    "last_toggle_timestamp": "2023-10-13T04:08:05.957195-07:00",
    "solar_real_power_limit": None,
    "score": 10000,
    "blocks_controlled": None,
    "primary": True,
    "auxiliary_load": 0,
    "all_enable_lines_high": True,
    "inverter_nominal_usable_power": 0,
    "expected_energy_remaining": 0
}

def API_SYSTEM_STATUS_STUB():
    """Return a fresh copy of the API system status stub to prevent shared-state mutation."""
    return copy.deepcopy(_API_SYSTEM_STATUS_TEMPLATE)
