[![rag-knowledge-graph-mcp MCP server](https://glama.ai/mcp/servers/CSOAI-ORG/rag-knowledge-graph-mcp/badges/score.svg)](https://glama.ai/mcp/servers/CSOAI-ORG/rag-knowledge-graph-mcp)
[![MCP Registry](https://img.shields.io/badge/MCP_Registry-Published-green)](https://registry.modelcontextprotocol.io)
[![PyPI](https://img.shields.io/pypi/v/rag-knowledge-graph-mcp)](https://pypi.org/project/rag-knowledge-graph-mcp/)

[![rag-knowledge-graph-mcp MCP server](https://glama.ai/mcp/servers/CSOAI-ORG/rag-knowledge-graph-mcp/badges/card.svg)](https://glama.ai/mcp/servers/CSOAI-ORG/rag-knowledge-graph-mcp)

<div align="center">

[![GitHub stars](https://img.shields.io/github/stars/CSOAI-ORG/rag-knowledge-graph-mcp)](https://github.com/CSOAI-ORG/rag-knowledge-graph-mcp/stargazers)

# uragU knowledgeU graphU mcp

**RAG Knowledge Graph MCP — MEOK AI Labs. Vector search + knowledge graph + unified context retrieval.**

[![npm version](https://img.shields.io/npm/v/@meok-ai/rag-knowledge-graph-mcp)](https://www.npmjs.com/package/@meok-ai/rag-knowledge-graph-mcp)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![MEOK AI Labs](https://img.shields.io/badge/MEOK_AI_Labs-255+_servers-purple)](https://meok.ai)

[Installation](#installation) · [Docs](https://csoai.org) · [Report Bug](https://github.com/CSOAI-ORG/rag-knowledge-graph-mcp/issues)

</div>

---

## Installation

```bash
pip install rag-knowledge-graph-mcp
# or
npm install -g @meok-ai/rag-knowledge-graph-mcp
```

## Quick Start

See the project repository for full documentation and examples.

## Enterprise Support

- 📧 nicholas@csoai.org
- 🌐 [CSOAI.org](https://csoai.org)

## License

MIT © [CSOAI](https://csoai.org)
<!-- mcp-name: io.github.CSOAI-ORG/rag-knowledge-graph-mcp -->
