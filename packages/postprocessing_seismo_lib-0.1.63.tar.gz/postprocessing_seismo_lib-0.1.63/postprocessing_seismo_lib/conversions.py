import json, os, random, pandas as pd
from anssformats.amplitude import Amplitude
from anssformats.association import Association
from anssformats.machineLearning import MachineLearning
from anssformats.filter import Filter
from anssformats.pick import Pick
from anssformats.channel import Channel, ChannelProperties, ChannelGeometry
from anssformats.source import Source
from anssformats.quality import Quality
from datetime import datetime
from pytz import timezone
import traceback

def anss_to_soa_pick_format(anss_file_path):
    """
    Convert ANSS-formatted picks back to SOA format.
    
    Parameters:
    -----------
    anss_file_path : str
        Path to the JSON file containing ANSS picks.
        
    Returns:
    --------
    dict
        {
            "success": True/False,
            "num_picks": int,
            "num_errors": int,
            "picks": list of SOA-format picks,
            "errors": list of errors with traceback
        }
    """
    soa_picks = []
    errors = []

    # --- Load ANSS pick file ---
    try:
        with open(anss_file_path, 'r') as f:
            anss_picks = json.load(f)
    except Exception as e:
        return {
            "success": False,
            "stage": "load_anss_file",
            "error": str(e),
            "traceback": traceback.format_exc()
        }

    # --- Process each ANSS pick ---
    for idx, pick in enumerate(anss_picks):
        try:
            # Extract channel info
            channel = pick.get("channel", {})
            geometry = channel.get("geometry", {})
            coordinates = geometry.get("coordinates", [0.0, 0.0, 0.0])
            
            properties = channel.get("properties", {})
            station = properties.get("station", "")
            network = properties.get("network", "")
            channel_code = properties.get("channel", "")
            location = properties.get("location", "")

            # Extract source info
            source = pick.get("source", {})
            agencyID = source.get("agencyID", "")
            author = source.get("author", "")

            # Time back to ISO string with 'Z'
            time_val = pick.get("time")
            if isinstance(time_val, str):
                time_str = time_val
            elif hasattr(time_val, "isoformat"):
                time_str = time_val.isoformat() + "Z"
            else:
                time_str = str(time_val) + "Z"

            # Polarity
            polarity = pick.get("polarity")
            if not polarity:
                polarity = "no-result"

            # Picker
            picker_type = pick.get("pickerType", "manual")

            # Filters
            filter_info = []
            for f in pick.get("filterInfo", []):
                filter_info.append({
                    "Type": f.get("type", ""),
                    "HighPass": f.get("highPass", 0.0)
                })

            # Amplitude
            amp_info = pick.get("amplitudeInfo", {})
            amplitude = amp_info.get("amplitude", 0.0)
            snr = amp_info.get("snr", 0.0)

            # Quality
            quality_info = []
            for q in pick.get("qualityInfo", []):
                quality_info.append({
                    "Standard": q.get("standard", ""),
                    "Value": q.get("value", 0.0)
                })

            # Phase
            phase = pick.get("phase", "")

            # Build SOA pick
            soa_pick = {
                "Type": "Pick",
                "Site": {
                    "Station": station,
                    "Channel": channel_code,
                    "Network": network,
                    "Location": location
                },
                "Time": time_str,
                "Source": {
                    "AgencyID": agencyID,
                    "Author": author
                },
                "Phase": phase,
                "Polarity": polarity,
                "Picker": picker_type,
                "Filter": filter_info,
                "Amplitude": {
                    "Amplitude": amplitude,
                    "SNR": snr
                },
                "Quality": quality_info
            }

            soa_picks.append(soa_pick)

        except Exception as e:
            errors.append({
                "index": idx,
                "pick": pick,
                "error": str(e),
                "traceback": traceback.format_exc()
            })

    return {
        "success": True,
        "num_picks": len(soa_picks),
        "num_errors": len(errors),
        "picks": soa_picks,
        "errors": errors
    }


def create_channel(CHANNEL_GEOMETRY, CHANNEL_PROPERTIES):
    newChannel = Channel(
        geometry=CHANNEL_GEOMETRY, properties=CHANNEL_PROPERTIES
    )
    return newChannel


def soa_to_anss_pick_format(pick_file_path, station_csv_path):

    modified_anss_picks = []
    errors = []
    TYPE = "Pick"

    # --- Load pick file ---
    try:
        with open(pick_file_path, 'r') as f:
            pick_list = json.load(f)
    except Exception as e:
        return {
            "success": False,
            "stage": "load_pick_file",
            "error": str(e),
            "traceback": traceback.format_exc()
        }

    # --- Load station metadata ---
    try:
        station_metadata_df = pd.read_csv(station_csv_path)
    except Exception as e:
        return {
            "success": False,
            "stage": "load_station_csv",
            "error": str(e),
            "traceback": traceback.format_exc()
        }

    if station_metadata_df is None or station_metadata_df.empty:
        return {
            "success": False,
            "stage": "station_metadata_validation",
            "error": "Station metadata is empty or not loaded",
            "traceback": None
        }

    # --- Build lookup ---
    try:
        station_lookup = {
            (row.NET, str(row.STA), row.CHA): (row.LON, row.LAT, row.ELEV)
            for _, row in station_metadata_df.iterrows()
        }
    except Exception as e:
        return {
            "success": False,
            "stage": "station_lookup_build",
            "error": str(e),
            "traceback": traceback.format_exc()
        }

    # --- Process picks ---
    for idx, pick_used in enumerate(pick_list):
        try:
            rand_num = random.randint(1, 10000)
            ID = "PhasenetPick_" + str(rand_num)

            CHANNEL_PROPERTIES = ChannelProperties(
                station=pick_used["Site"]["Station"],
                channel=pick_used["Site"]["Channel"],
                network=pick_used["Site"]["Network"],
                location=pick_used["Site"]["Location"]
            )

            lon, lat, elev = station_lookup.get(
                (
                    pick_used["Site"]["Network"],
                    str(pick_used["Site"]["Station"]),
                    pick_used["Site"]["Channel"]
                ),
                (None, None, None)
            )

            if lon is None or lat is None or elev is None:
                print(f"Missing coordinates for {pick_used['Site']}, defaulting to 0.0")
                lon = lon or 0.0
                lat = lat or 0.0
                elev = elev or 0.0

            CHANNEL_GEOMETRY = ChannelGeometry(
                coordinates=[float(lon), float(lat), float(elev)]
            )

            SOURCE = Source(agencyID="US", author="ryant")

            # --- Time parsing ---
            time_str_clean = pick_used["Time"].rstrip("Z")
            TIME = datetime.strptime(time_str_clean, "%Y-%m-%dT%H:%M:%S.%f")

            PHASE = pick_used["Phase"]

            POLARITY = pick_used.get("Polarity", "").lower()
            if POLARITY not in ["up", "down"]:
                POLARITY = None

            PICKER = "manual"

            FILTER = [
                Filter(
                    type=pick_used["Filter"][0]["Type"],
                    highPass=pick_used["Filter"][0]["HighPass"],
                    units="Hertz"
                )
            ]

            amp_val = pick_used["Amplitude"].get("Amplitude", 0.0)
            snr_val = max(0.0, pick_used["Amplitude"].get("SNR", 0.0))
            AMPLITUDE = Amplitude(amplitude=amp_val, snr=snr_val)

            ASSOCIATIONINFO = Association(
                phase=pick_used["Phase"],
            )

            MACHINELEARNINGINFO = MachineLearning(
                phase=pick_used["Phase"],
                phaseProbability=pick_used["Quality"][0]["Value"],
                source=SOURCE,
            )

            QUALITY = [
                Quality(
                    standard=pick_used["Quality"][0]["Standard"],
                    value=pick_used["Quality"][0]["Value"]
                )
            ]

            pick = Pick(
                type=TYPE,
                id=ID,
                channel=create_channel(CHANNEL_GEOMETRY, CHANNEL_PROPERTIES),
                source=SOURCE,
                time=TIME,
                phase=PHASE,
                polarity=POLARITY,
                pickerType=PICKER,
                filterInfo=FILTER,
                amplitudeInfo=AMPLITUDE,
                associationInfo=ASSOCIATIONINFO,
                qualityInfo=QUALITY,
                machineLearningInfo=MACHINELEARNINGINFO,
            )

            dictionary_pick_anss_format = pick.model_dump()
            modified_anss_picks.append(dictionary_pick_anss_format)

        except Exception as e:
            errors.append({
                "index": idx,
                "pick": pick_used,
                "error": str(e),
                "traceback": traceback.format_exc()
            })

    # --- Final output ---
    return {
        "success": True,
        "num_picks": len(modified_anss_picks),
        "num_errors": len(errors),
        "picks": modified_anss_picks,
        "errors": errors
    }


def phasenet_csv_to_soa_pick_format(picks_file, highpass_filt):
    try:
        if not os.path.exists(picks_file):
            raise FileNotFoundError(f"File not found: {picks_file}")

        picks_df = pd.read_csv(picks_file)

    except Exception as e:
        return {
            "status": "error",
            "stage": "file_read",
            "message": str(e),
            "traceback": traceback.format_exc()
        }

    pick_list = []
    errors = []

    for idx, row in picks_df.iterrows():
        try:
            time_used = datetime.now()
            datetime_obj_pacific = timezone('US/Pacific').localize(time_used)
            now_utc = datetime_obj_pacific.astimezone(
                timezone('UTC')).replace(tzinfo=None)

            # --- ID parsing ---
            id = row['station_id']
            id_split = id.split('.')

            if len(id_split) < 4:
                raise ValueError(f"Invalid station_id format: {id}")

            net = id_split[0]
            sta = id_split[1]
            loc = id_split[2]
            inst = id_split[-1]

            # --- Required fields ---
            phase_time_str = row['phase_time'] + 'Z'
            prob = float(row['phase_score'])
            amp = float(row['phase_amp'])
            type = row['phase_type']
            snr = row['phase_snr_db']
            polarity = row['phase_polarity']

            # --- Polarity mapping ---
            if polarity == 'U':
                polarity = "up"
            elif polarity == 'D':
                polarity = "down"
            else:
                polarity = "no-result"

            pick_list.append(
                {
                    "Type": "Pick",
                    "Site": {
                        "Station": sta,
                        "Channel": inst,
                        "Network": net,
                        "Location": loc
                    },
                    "Time": phase_time_str,
                    "Source": {
                        "AgencyID": net,
                        "Author": "hypoPN"
                    },
                    "Phase": type,
                    "Polarity": polarity,
                    "Picker": "deep-learning",
                    "Filter": [{
                        "Type": "HighPass",
                        "HighPass": highpass_filt,
                    }],
                    "Amplitude": {
                        "Amplitude": amp,
                        "SNR": snr
                    },
                    "Quality": [{
                        "Standard": "PhaseNet",
                        "Value": prob
                    }],
                }
            )

        except Exception as e:
            errors.append({
                "row_index": idx,
                "row_data": row.to_dict(),
                "message": str(e),
                "traceback": traceback.format_exc()
            })

    return {
        "status": "success" if not errors else "partial_success",
        "picks": pick_list,
        "errors": errors
    }


def capitalize_keys(obj):
    """Recursively capitalize the first letter of every key in a nested structure."""
    if isinstance(obj, dict):
        return {k[0].upper() + k[1:] if k else k: capitalize_keys(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [capitalize_keys(i) for i in obj]
    else:
        return obj

def soa_to_soa_pick_format_using_anss_libraries(pick_file_used):

    TYPE = "Pick"
    pick_list = []
    errors = []

    # --- Load file safely ---
    try:
        with open(pick_file_used, 'r') as f:
            pick_list_modded = json.load(f)
    except Exception as e:
        return {
            "success": False,
            "stage": "load_pick_file",
            "error": str(e),
            "traceback": traceback.format_exc()
        }

    # --- Process picks ---
    for idx, pick_used in enumerate(pick_list_modded):
        try:
            CHANNEL_PROPERTIES = ChannelProperties(
                station=pick_used["Site"]["Station"],
                channel=pick_used["Site"]["Channel"],
                network=pick_used["Site"]["Network"],
                location=pick_used["Site"]["Location"]
            )

            SOURCE = Source(agencyID="net", author="hypoPN")

            # --- Parse time safely ---
            time_str_clean = pick_used["Time"].rstrip("Z")
            TIME = datetime.strptime(time_str_clean, "%Y-%m-%dT%H:%M:%S.%f")

            PHASE = pick_used["Phase"]

            POLARITY = pick_used.get("Polarity", "").lower()
            if POLARITY not in ["up", "down"]:
                POLARITY = None

            PICKER = "deep-learning"

            FILTER = [
                Filter(
                    type=pick_used["Filter"][0]["Type"],
                    highPass=pick_used["Filter"][0]["HighPass"]
                )
            ]

            # --- Amplitude handling ---
            amp_val = pick_used["Amplitude"].get("Amplitude", 0.0)
            snr_val = max(0.0, pick_used["Amplitude"].get("SNR", 0.0))
            AMPLITUDE = Amplitude(amplitude=amp_val, snr=snr_val)

            QUALITY = [
                Quality(
                    standard=pick_used["Quality"][0]["Standard"],
                    value=pick_used["Quality"][0]["Value"]
                )
            ]

            pick = {
                "Type": TYPE,
                "Site": CHANNEL_PROPERTIES.model_dump(),
                "Time": TIME,
                "Source": SOURCE.model_dump(),
                "Phase": PHASE,
                "Polarity": POLARITY,
                "Picker": PICKER,
                "Filter": [f.model_dump() for f in FILTER],
                "Amplitude": AMPLITUDE.model_dump(),
                "Quality": [f.model_dump() for f in QUALITY],
            }

            pick_list.append(pick)

        except Exception as e:
            errors.append({
                "index": idx,
                "pick": pick_used,
                "error": str(e),
                "traceback": traceback.format_exc()
            })

    # --- Final formatting step ---
    try:
        modified_anss_picks = capitalize_keys(pick_list)
    except Exception as e:
        return {
            "success": False,
            "stage": "capitalize_keys",
            "error": str(e),
            "traceback": traceback.format_exc(),
            "partial_picks": pick_list,
            "errors": errors
        }

    # --- Final return ---
    return {
        "success": True,
        "num_picks": len(modified_anss_picks),
        "num_errors": len(errors),
        "picks": modified_anss_picks,
        "errors": errors
    }
