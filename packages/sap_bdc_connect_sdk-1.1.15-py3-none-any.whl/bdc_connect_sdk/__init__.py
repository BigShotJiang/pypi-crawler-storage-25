# © 2025-2026 SAP SE or an SAP affiliate company. All rights reserved.
__version__="1.1.15"
# © 2025-2026 SAP SE or an SAP affiliate company. All rights reserved.
