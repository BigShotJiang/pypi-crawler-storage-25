# LogSentinelAI Installation & Usage Guide — AI-Powered Cybersecurity Log Analysis Setup for RHEL & Ubuntu

**Keywords**: `LogSentinelAI installation` • `cybersecurity tool setup` • `AI log analysis deployment` • `SIEM integration guide` • `threat detection installation` • `enterprise security monitoring` • `DevSecOps automation setup`

This document provides a comprehensive step-by-step guide for installing, configuring, and testing LogSentinelAI on enterprise Linux environments (RHEL, RockyLinux, CentOS) and Ubuntu systems. Perfect for **cybersecurity teams**, **DevOps engineers**, and **system administrators** implementing AI-powered security monitoring solutions.

---

## 1. System Requirements & Use Cases

LogSentinelAI is designed for **enterprise cybersecurity environments**, **SOC (Security Operations Center)** deployment, **compliance auditing**, and **real-time threat detection** scenarios.

### Infrastructure Requirements

- **OS**: RHEL 8/9, RockyLinux 8/9, CentOS 8/9, Ubuntu 20.04/22.04 (including WSL2)
- **Python**: **3.11 or 3.12 ONLY** (⚠️ Python 3.13+ not supported due to dependency compatibility issues)
- **Memory**: Minimum 4GB (8GB+ recommended for local LLM deployment)
- **Storage**: At least 2GB free space (additional for ELK stack if used)
- **Network**: Access to PyPI, GitHub, OpenAI API, Ollama/vLLM endpoints
- **(Optional) Docker**: Required for running Elasticsearch/Kibana, vLLM, Ollama containers

### Perfect for These Use Cases

- **Security Operations Center (SOC)** log analysis automation
- **Compliance reporting** (SOX, PCI DSS, HIPAA) with structured audit trails  
- **Incident response** and forensic log investigation
- **DevSecOps pipeline** integration for CI/CD security monitoring
- **Enterprise SIEM** enhancement with AI-powered threat detection
- **Real-time security monitoring** for critical infrastructure

---

## 2. Install uv & Create Virtual Environment

### 2.1 Install uv

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

After installation, ensure "$HOME/.local/bin" (default install path) is in your PATH:

```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
uv --version
```

### 2.2 Install Python 3.11+ & Create Virtual Environment

```bash
# Install Python 3.11 or 3.12 (3.13+ not supported)
uv python install 3.11
uv venv --python=3.11 logsentinelai-venv
source logsentinelai-venv/bin/activate
```

---

## 3. Install LogSentinelAI

### 3.1 Install from PyPI (Recommended)

```bash
# Install using uv
uv sync
uv pip install -U logsentinelai
```

### 3.2 Install from GitHub Source (Development/Latest)

```bash
git clone https://github.com/call518/LogSentinelAI.git
cd LogSentinelAI
uv sync
uv pip install .
```

---

## 4. Install Required External Tools

### 4.1 (Optional) Install Docker

- [Official Docker Install Guide](https://docs.docker.com/engine/install/)
- Refer to official docs for both RHEL/Ubuntu

### 4.2 (Optional) Install Ollama (Local LLM)

- [Ollama Official Install](https://ollama.com/download)

```bash
curl -fsSL https://ollama.com/install.sh | sh
systemctl start ollama
ollama pull gemma3:1b
```

### 4.3 (Optional) Install vLLM (Local GPU LLM)

```bash
# Docker-based vLLM install & model download example
git clone https://github.com/call518/vLLM-Tutorial.git
cd vLLM-Tutorial
uv pip install huggingface_hub
huggingface-cli download lmstudio-community/Qwen2.5-3B-Instruct-GGUF Qwen2.5-3B-Instruct-Q4_K_M.gguf --local-dir ./models/Qwen2.5-3B-Instruct/
huggingface-cli download Qwen/Qwen2.5-3B-Instruct generation_config.json --local-dir ./config/Qwen2.5-3B-Instruct
# Run vLLM with Docker
./run-docker-vllm---Qwen2.5-1.5B-Instruct.sh
# Check API is working
curl -s -X GET http://localhost:5000/v1/models | jq
```

#### vLLM generation_config.json example (recommended values)

```json
{
  "temperature": 0.1,
  "top_p": 0.5,
  "top_k": 20
}
```

---

## 5. Prepare Config File & Main Options

### Option 1: From GitHub (if installed from source)

```bash
cd ~/LogSentinelAI  # If installed from source
curl -o .env https://raw.githubusercontent.com/call518/LogSentinelAI/main/src/logsentinelai/.env.template
nano .env  # or vim .env
# Enter required fields such as OPENAI_API_KEY
```

### Option 2: From Installed Package

```bash
# Copy .env template from installed package
cp $(python -c "import logsentinelai; import os; print(os.path.join(os.path.dirname(logsentinelai.__file__), '.env.template'))") ./.env
nano .env  # or vim .env
# Enter required fields such as OPENAI_API_KEY
```

**Notes:**

- A .env file is MANDATORY. Base it on the provided `.env.template`.
- Runtime search order (if `--config` not given): `/etc/logsentinelai.config` → `./.env`.
- If no file is found the program aborts with guidance; create one and re-run.
- Override path explicitly: `--config /path/to/.env`
- If an explicit `--config /path/to/.env` is given and that file does not exist, the program aborts immediately (no fallback search).

### Example .env main items

```ini
# LLM Provider & Model
LLM_PROVIDER=openai   # openai/ollama/vllm/gemini/anthropic
LLM_MODEL_OPENAI=gpt-4o-mini
LLM_MODEL_OLLAMA=gemma3:1b
LLM_MODEL_VLLM=Qwen/Qwen2.5-1.5B-Instruct
LLM_MODEL_GEMINI=gemini-2.5-flash
LLM_MODEL_ANTHROPIC=claude-haiku-4-5-20251001

# API Keys
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE
ANTHROPIC_API_KEY=YOUR_ANTHROPIC_API_KEY_HERE

# Max output tokens per LLM provider (each provider has different model context limits)
# Gemini: uses max_output_tokens — set higher for Korean/multilingual structured JSON responses
# Anthropic: uses tool calling for structured output; max_tokens caps the response
# Ollama/vLLM/OpenAI: uses max_tokens — must not exceed the loaded model's max context length
LLM_MAX_TOKENS_OLLAMA=8192
LLM_MAX_TOKENS_VLLM=8192
LLM_MAX_TOKENS_OPENAI=8192
LLM_MAX_TOKENS_GEMINI=32768
LLM_MAX_TOKENS_ANTHROPIC=8192

# Response language
RESPONSE_LANGUAGE=korean   # or english

# Analysis mode
ANALYSIS_MODE=batch        # batch/realtime

# Log file paths (defaults when --log-path not specified)
LOG_PATH_HTTPD_ACCESS=sample-logs/access-10k.log
LOG_PATH_HTTPD_SERVER=sample-logs/apache-10k.log
LOG_PATH_LINUX_SYSTEM=sample-logs/linux-2k.log
LOG_PATH_GENERAL_LOG=sample-logs/general.log

# chunk size (analysis unit)
CHUNK_SIZE_HTTPD_ACCESS=10
CHUNK_SIZE_HTTPD_SERVER=10
CHUNK_SIZE_LINUX_SYSTEM=10
CHUNK_SIZE_GENERAL_LOG=10

# Realtime mode options
REALTIME_POLLING_INTERVAL=5
REALTIME_MAX_LINES_PER_BATCH=50
REALTIME_BUFFER_TIME=2
REALTIME_PROCESSING_MODE=full     # full/sampling
REALTIME_SAMPLING_THRESHOLD=100

# GeoIP options
GEOIP_ENABLED=true
GEOIP_DATABASE_PATH=~/.logsentinelai/GeoLite2-City.mmdb
GEOIP_FALLBACK_COUNTRY=Unknown
GEOIP_INCLUDE_PRIVATE_IPS=false

# Elasticsearch integration options (optional)
ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9200
ELASTICSEARCH_USER=elastic
ELASTICSEARCH_PASSWORD=changeme

# Telegram alert options (optional)
TELEGRAM_ENABLED=true                              # Enable/disable Telegram notifications
TELEGRAM_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_HERE       # Bot token from @BotFather
TELEGRAM_CHAT_ID=YOUR_TELEGRAM_CHAT_ID_HERE       # Group/channel chat ID
```

---

## 6. GeoIP DB Auto/Manual Install & Usage

- On first run, GeoIP City DB is automatically downloaded to `~/.logsentinelai/` (recommended)
- For manual download:

```bash
logsentinelai-geoip-download
# or
logsentinelai-geoip-download --output-dir ~/.logsentinelai/
```

### GeoIP main features

- City/country/coordinates (geo_point) auto assignment, Kibana map visualization supported
- Private IPs are excluded from geo_point
- Analysis works even if DB is missing (GeoIP enrich is skipped)

---

## 6.1. (Optional) Setup Telegram Alerts

LogSentinelAI can automatically send real-time alerts to Telegram groups when CRITICAL security events are detected or processing failures occur.

### 6.1.1 Create Telegram Bot

1. Start a chat with @BotFather on Telegram
2. Create a new bot: `/newbot`
3. Follow the instructions and save your bot token
4. Copy the token (format: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`)

### 6.1.2 Get Chat ID

Option 1 - For group/channel:
```bash
# Add your bot to the group/channel as admin
# Send a test message in the group
# Replace YOUR_BOT_TOKEN with your actual token
curl -s "https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates" | jq '.result[].message.chat.id'
```

Option 2 - For direct messages:
```bash
# Send a direct message to your bot
# Then run the same command to get your user chat ID
curl -s "https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates" | jq '.result[].message.chat.id'
```

### 6.1.3 Configure in .env file

```ini
# Enable Telegram alerts
TELEGRAM_ENABLED=true
TELEGRAM_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_CHAT_ID=-1001234567890  # Negative for groups, positive for users
```

### 6.1.4 Alert Triggers

- **CRITICAL Events**: SQL injection, XSS attacks, brute force attempts
- **Processing Failures**: LLM API errors, parsing failures, system errors
- **Real-time Mode**: Immediate notifications during live monitoring

---

## 7. Prepare Sample Log Files (for testing)

```bash
# If you already cloned the repo, skip this
git clone https://github.com/call518/LogSentinelAI.git
cd LogSentinelAI/sample-logs
ls *.log  # Check various sample logs
```

### Tip: Use More Public Sample Logs

For testing additional log types and formats, leverage this public repository:

- GitHub: [Sample Log Files Repository](https://github.com/SoftManiaTech/sample_log_files)

How to use with LogSentinelAI:

```bash
# Clone the public sample logs repository
cd ~
git clone https://github.com/SoftManiaTech/sample_log_files.git

# Example: test Linux system analyzer on a selected file
logsentinelai-linux-system --log-path ~/sample_log_files/linux/example.log

# Example: test HTTP access analyzer on an access log sample
logsentinelai-httpd-access --log-path ~/sample_log_files/web/apache_access.log
```

Notes:

- Some samples may have formats not fully covered by current analyzers; adjust prompts/schemas accordingly
- Use `--chunk-size` to tune batch size when experimenting with very large files

---

## 8. Install & Integrate Elasticsearch & Kibana (Optional)

### 8.1 Install ELK Stack via Docker

```bash
git clone https://github.com/call518/Docker-ELK.git
cd Docker-ELK
docker compose up setup
docker compose up kibana-genkeys  # Key generation (recommended)
docker compose up -d
# Access http://localhost:5601, elastic/changeme
```

**⚠️ Important**: Wait for Elasticsearch and Kibana to fully start before proceeding. Check with:
```bash
# Check Elasticsearch status
curl -u elastic:changeme http://localhost:9200/_cluster/health

# Check Kibana status  
curl -u elastic:changeme http://localhost:5601/api/status
```

### 8.2 Complete ELK Setup Process (Must Follow This Order)

**🔄 Follow these steps in the exact order below for successful setup:**

#### Step 1: Access Kibana Web Interface

1. Open browser and go to http://localhost:5601
2. Login with default credentials: `elastic` / `changeme`
3. Verify Kibana is fully loaded and functional

#### Step 2: Create Elasticsearch Index Infrastructure

Run the following commands in terminal to set up the index structure:

##### 1) Create ILM Policy (7 days retention, 10GB/1d rollover)

```bash
curl -X PUT "localhost:9200/_ilm/policy/logsentinelai-analysis-policy" \
-H "Content-Type: application/json" \
-u elastic:changeme \
-d '{
  "policy": {
    "phases": {
      "hot": {
        "actions": {
          "rollover": {
            "max_size": "10gb",
            "max_age": "1d"
          }
        }
      },
      "delete": {
        "min_age": "7d",
        "actions": {
          "delete": {}
        }
      }
    }
  }
}'
```

##### 2) Create Index Template

```bash
curl -X PUT "localhost:9200/_index_template/logsentinelai-analysis-template" \
-H "Content-Type: application/json" \
-u elastic:changeme \
-d '{
  "index_patterns": ["logsentinelai-analysis-*"],
  "template": {
    "settings": {
      "number_of_shards": 1,
      "number_of_replicas": 1,
      "index.lifecycle.name": "logsentinelai-analysis-policy",
      "index.lifecycle.rollover_alias": "logsentinelai-analysis",
      "index.mapping.total_fields.limit": "10000"
    },
    "mappings": {
      "properties": {
        "events": {
          "type": "object",
          "properties": {
            "source_ips": {
              "type": "object",
              "properties": {
                "ip": { "type": "ip" },
                "location": { "type": "geo_point" }
              }
            },
            "dest_ips": {
              "type": "object",
              "properties": {
                "ip": { "type": "ip" },
                "location": { "type": "geo_point" }
              }
            }
          }
        }
      }
    }
  }
}'
```

##### 3) Create Initial Index & Write Alias

```bash
curl -X PUT "localhost:9200/logsentinelai-analysis-000001" \
-H "Content-Type: application/json" \
-u elastic:changeme \
-d '{
  "aliases": {
    "logsentinelai-analysis": {
      "is_write_index": true
    }
  }
}'
```

**✅ Verify Index Creation**: Check that the index was created successfully:
```bash
curl -u elastic:changeme "localhost:9200/_cat/indices/logsentinelai-analysis*?v"
```

#### Step 3: Create Kibana Data View

**🎯 Critical Step**: Before importing dashboards, you must create a Data View in Kibana:

1. In Kibana web interface, go to **Stack Management** → **Data Views**
2. Click **Create data view**
3. Configure the Data View:
   - **Name**: `LogSentinelAI Analysis`
   - **Index pattern**: `logsentinelai-analysis*`
   - **Timestamp field**: `@timestamp` (⚠️ Important: Select this exact field)
4. Click **Save data view to Kibana**

**🔍 Alternative method via Dev Tools**:
You can also create the Data View using Kibana's Dev Tools console:

```bash
# Go to Kibana → Dev Tools and run:
POST /api/data_views/data_view
{
  "data_view": {
    "title": "logsentinelai-analysis*",
    "name": "LogSentinelAI Analysis",
    "timeFieldName": "@timestamp"
  }
}
```

#### Step 4: Import Kibana Configuration Files

**📂 Import Order**: Import configuration files in this specific order:

1. **First**: Import Advanced Settings
   - Go to **Stack Management** → **Saved Objects** → **Import**
   - Select and import `Kibana-9.0.3-Advanced-Settings.ndjson`
   - Click **Import** and resolve any conflicts

2. **Second**: Import Dashboard
   - In the same import interface
   - Select and import `Kibana-9.0.3-Dashboard-LogSentinelAI.ndjson`  
   - Click **Import** and resolve any conflicts
   - ⚠️ If there are missing references, ensure the Data View was created correctly in Step 3

#### Step 5: Verify Complete Setup

1. Go to **Analytics** → **Dashboard** → **LogSentinelAI Dashboard**
2. Verify the dashboard loads without errors
3. Check that all visualizations are properly configured
4. Test by running a LogSentinelAI analysis to populate data

**🚨 Troubleshooting**: If dashboard shows "No data" or errors:
- Verify Data View exists and uses `@timestamp` field
- Check that the index pattern `logsentinelai-analysis*` matches your data
- Ensure LogSentinelAI config has correct Elasticsearch settings
- Run a test analysis to generate sample data

---

## 9. LogSentinelAI Main Commands & Test

### 9.1 List All Commands

```bash
logsentinelai --help
```

### 9.2 Main Analysis Command Examples

```bash
# Single file analysis
logsentinelai-httpd-access --log-path sample-logs/access-10k.log
logsentinelai-httpd-server --log-path sample-logs/apache-10k.log
logsentinelai-linux-system --log-path sample-logs/linux-2k.log

# Multiple files with wildcard patterns (batch mode only)
logsentinelai-httpd-access --log-path "/var/log/apache*.log"
logsentinelai-linux-system --log-path "/var/log/messages*"
logsentinelai-general-log --log-path "logs/*.log"
logsentinelai-httpd-access --log-path "sample-logs/access*.log"

# Realtime monitoring (local)
logsentinelai-linux-system --mode realtime
# Manual GeoIP DB download/path
logsentinelai-geoip-download --output-dir ~/.logsentinelai/
```

### 9.3 CLI Option Summary

| Option | Description | .env default | CLI override |
|--------|-------------|---------------|-------------|
| --log-path <path> | Log file path or pattern (supports wildcards: *.log, /var/log/apache*.log) | LOG_PATH_* | Y |
| --mode <mode> | batch/realtime analysis mode | ANALYSIS_MODE | Y |
| --chunk-size <num> | Analysis unit (lines) | CHUNK_SIZE_* | Y |
| --processing-mode <mode> | Realtime processing (full/sampling) | REALTIME_PROCESSING_MODE | Y |
| --sampling-threshold <num> | Sampling threshold | REALTIME_SAMPLING_THRESHOLD | Y |
| --remote | Enable SSH remote analysis | REMOTE_LOG_MODE | Y |
| --ssh <user@host:port> | SSH connection info | REMOTE_SSH_* | Y |
| --ssh-key <path> | SSH key path | REMOTE_SSH_KEY_PATH | Y |
| --help | Help | - | - |

> CLI options always override .env file

### 9.8 Multiple File Processing with Wildcards

**Batch mode only** - Process multiple log files at once using wildcard patterns:

```bash
# Process all Apache access logs
logsentinelai-httpd-access --log-path "/var/log/httpd/access_log.*"
# Process all rotated system logs  
logsentinelai-linux-system --log-path "/var/log/messages*"
# Process all .log files in directory
logsentinelai-general-log --log-path "/path/to/logs/*.log"
```

- **✅ Supported patterns**: `*` (any characters), `?` (single character), `[abc]` (character sets)
- **✅ Memory safe**: Each file processed individually using streaming
- **✅ Error resilient**: Failed files don't stop processing of remaining files
- **❌ SSH limitation**: Wildcard patterns not supported for remote files (single file only)

### 9.9 SSH Remote Log Analysis

```bash
logsentinelai-linux-system --remote --ssh admin@192.168.1.100 --ssh-key ~/.ssh/id_rsa --log-path /var/log/messages
```

- **Tip:** Register the target server in known_hosts in advance (`ssh-keyscan -H <host> >> ~/.ssh/known_hosts`)

### 9.10 Manual GeoIP DB Download/Path

```bash
logsentinelai-geoip-download --output-dir ~/.logsentinelai/
```

---

## 10. Declarative Extraction Usage

LogSentinelAI's biggest feature is **Declarative Extraction**. By declaring only the desired result structure (Pydantic class) in each analyzer, the LLM automatically analyzes logs according to that structure and returns results in JSON format. Without complex parsing/post-processing, you just declare the desired fields and AI fills in the results.

### 10.1 Basic Usage

1. In your analyzer script, declare the result structure (Pydantic class) you want to receive.
2. When you run the analysis command, the LLM automatically generates JSON matching that structure.

#### Example: Customizing HTTP Access Log Analyzer

```python
from pydantic import BaseModel

class MyAccessLogResult(BaseModel):
    ip: str
    url: str
    is_attack: bool
```

Just define the fields you want, and the LLM will generate results like:

```json
{
  "ip": "192.168.0.1",
  "url": "/admin.php",
  "is_attack": true
}
```

#### Example: Customizing Apache Error Log Analyzer

```python
from pydantic import BaseModel

class MyApacheErrorResult(BaseModel):
    log_level: str
    event_message: str
    is_critical: bool
```

#### Example: Customizing Linux System Log Analyzer

```python
from pydantic import BaseModel

class MyLinuxLogResult(BaseModel):
    event_type: str
    user: str
    is_anomaly: bool
```

By declaring only the result structure you want in each analyzer, the LLM automatically returns results in that structure—no manual parsing required.

---

## 11. Advanced Usage Examples

### 11.1 Set Defaults in .env & Override with CLI

```bash
# Set CHUNK_SIZE_LINUX_SYSTEM=20 in .env
logsentinelai-linux-system --chunk-size 10  # CLI option takes precedence
```

### 11.2 Realtime Mode Auto Sampling Operation & Principle

> **Realtime Mode Key Features**  

- Starts from the **current End of File (EOF)** and processes only newly added logs
- Existing logs in the file are excluded from analysis (true real-time monitoring)  
- Even after program interruption and restart, past logs are not processed (always starts from current time)

```bash
logsentinelai-httpd-access --mode realtime --processing-mode full --sampling-threshold 100
# Check auto-switch to sampling mode on heavy log inflow
```

#### Sampling Operation Example

1. Normal: 15 lines in → FULL mode (below threshold), analyze by chunk_size
2. Traffic spike: 250 lines in → Exceeds threshold (100), auto-switch to SAMPLING mode, analyze only latest 10 lines, skip the rest (original logs preserved)
3. Traffic normalizes: Back to FULL mode

#### Sampling Strategy

- FIFO buffer, if threshold exceeded, only latest chunk_size analyzed
- No severity/pattern-based priority (purely time order)
- Possible analysis omission (original logs preserved)

### 11.3 Import Kibana Dashboard

**⚠️ Note**: If you followed the complete ELK setup process in Section 8.2, you've already completed this step. This section is for reference or if you need to re-import the dashboard.

**Prerequisites**: 
- Elasticsearch and Kibana must be running
- Data View `logsentinelai-analysis*` must be created with `@timestamp` as the time field
- Index infrastructure must be properly set up

**Import Steps**:
1. Access http://localhost:5601 (elastic/changeme)
2. Navigate to **Stack Management** → **Saved Objects** → **Import**
3. **Import in this order**:
   - First: `Kibana-9.0.3-Advanced-Settings.ndjson`
   - Second: `Kibana-9.0.3-Dashboard-LogSentinelAI.ndjson`
4. Resolve any import conflicts if prompted
5. Verify: Go to **Analytics** → **Dashboard** → **LogSentinelAI Dashboard**

**🚨 Troubleshooting Import Issues**:
- **"Missing references" error**: Ensure Data View was created correctly
- **Dashboard shows empty/no data**: Run a LogSentinelAI analysis to generate sample data
- **Visualization errors**: Check that index pattern matches `logsentinelai-analysis*`

---

## 12. Troubleshooting FAQ & Enterprise Deployment Issues

### Common Installation Issues

- **Permission denied on pip install**: Activate virtualenv or use `pip install --user`
- **Python 3.11 not found**: Check install path, use `python3.11` directly
- **Cannot access Elasticsearch/Kibana**: Check Docker status, port conflicts, firewall
- **GeoIP DB download failed**: Download manually and set path in .env
- **SSH remote analysis error**: Check SSH key permissions, known_hosts, firewall, port
- **LLM API error**: Check OPENAI_API_KEY, Ollama/vLLM server status, network

### ELK Stack Setup Issues

- **Elasticsearch not starting**: 
  ```bash
  # Check container logs
  docker logs docker-elk-elasticsearch-1
  # Increase memory if needed
  echo "vm.max_map_count=262144" | sudo tee -a /etc/sysctl.conf
  sudo sysctl -p
  ```

- **Kibana showing "Kibana server is not ready yet"**: 
  - Wait 2-3 minutes for full startup
  - Check Elasticsearch is healthy: `curl -u elastic:changeme http://localhost:9200/_cluster/health`

- **Dashboard import fails with "Missing references"**:
  - Ensure Data View `logsentinelai-analysis*` exists with `@timestamp` time field
  - Create index infrastructure first (Step 2 in Section 8.2)
  - Re-import in correct order: Advanced Settings → Dashboard

- **Dashboard shows "No data available"**:
  - Run LogSentinelAI analysis to populate data: `logsentinelai-linux-system --log-path sample-logs/linux-2k.log`
  - Check index exists: `curl -u elastic:changeme "localhost:9200/_cat/indices/logsentinelai-analysis*?v"`
  - Verify Elasticsearch config in LogSentinelAI .env file

- **Data View creation fails**:
  - Ensure index exists before creating Data View
  - Use exact pattern: `logsentinelai-analysis*`
  - Select `@timestamp` as time field (not `timestamp`)

- **Port conflicts (5601/9200 already in use)**:
  ```bash
  # Check what's using the ports
  sudo netstat -tlnp | grep :5601
  sudo netstat -tlnp | grep :9200
  # Stop conflicting services or modify docker-compose.yml ports
  ```

### Enterprise Environment Considerations

- **High-volume log processing**: Increase `REALTIME_SAMPLING_THRESHOLD` and `CHUNK_SIZE_*` for better performance
- **Network security policies**: Ensure outbound access to LLM providers (OpenAI, Ollama) or use local deployment
- **Compliance requirements**: Configure appropriate log retention policies in Elasticsearch ILM
- **Multi-server deployment**: Use SSH remote analysis for centralized security monitoring
- **Scalability planning**: Consider horizontal scaling with multiple LogSentinelAI instances

---

## 13. Reference/Recommended Links & Contact

- [LogSentinelAI GitHub](https://github.com/call518/LogSentinelAI)
- [Docker-ELK Official](https://github.com/deviantony/docker-elk)
- [Ollama Official](https://ollama.com/)
- [vLLM Official](https://github.com/vllm-project/vllm)
- [Python Official](https://www.python.org/downloads/)

Contact/Feedback: GitHub Issue, Discussions, Pull Request welcome

---

## 13. Reference Links & Contact

- [LogSentinelAI GitHub](https://github.com/call518/LogSentinelAI)
- [Docker-ELK Official](https://github.com/deviantony/docker-elk)
- [Ollama Official](https://ollama.com/)
- [vLLM Official](https://github.com/vllm-project/vllm)
- [Python Official](https://www.python.org/downloads/)

**Contact/Feedback**: GitHub Issue, Discussions, Pull Request welcome

---

## Appendix

### A. Real-time Auto-Sampling Detailed Mechanism

This section provides a detailed explanation of how the system automatically switches processing modes when large volumes of logs are ingested in real-time mode.

#### A.1 Related Parameters and Their Roles

| Parameter | Default | Role | Impact |
|-----------|---------|------|---------|
| `REALTIME_PROCESSING_MODE` | `full` | Base processing mode (full/sampling) | Determines initial processing method |
| `REALTIME_SAMPLING_THRESHOLD` | `100` | Auto-sampling switch threshold | Based on number of pending log lines |
| `CHUNK_SIZE_*` | `10` | LLM analysis unit | Number of log lines to analyze at once |
| `REALTIME_POLLING_INTERVAL` | `5` | Polling interval (seconds) | Log file check frequency |
| `REALTIME_MAX_LINES_PER_BATCH` | `50` | Read limit | Maximum lines to read at once |
| `REALTIME_BUFFER_TIME` | `2` | Buffer time (seconds) | Prevents incomplete log line processing |

#### A.2 Auto-Sampling Trigger Scenarios

##### Scenario 1: Normal Log Processing (FULL mode maintained)

```text
Configuration:
- CHUNK_SIZE_HTTPD_ACCESS = 10
- REALTIME_SAMPLING_THRESHOLD = 100
- REALTIME_POLLING_INTERVAL = 5
- REALTIME_MAX_LINES_PER_BATCH = 50

Process:
1. Check /var/log/apache2/access.log every 5 seconds
2. Find 15 new log lines → Add to internal pending buffer
3. Pending buffer: 15 lines (below threshold of 100)
4. Process CHUNK_SIZE(10): Analyze 10 lines with LLM, 5 lines remain pending
5. Check for additional logs in next polling cycle
```

##### Scenario 2: Traffic Spike - Auto-switch to Sampling

```text
Configuration: Same as above

Spike situation:
1. Poll every 5 seconds, reading 50 lines each time (MAX_LINES_PER_BATCH)
2. Continuous heavy log influx over multiple polling cycles
3. Pending buffer accumulation: 20 lines → 45 lines → 85 lines → 125 lines
4. 125 lines > threshold(100) ▶️ Auto-switch to SAMPLING mode

SAMPLING mode operation:
- System outputs "AUTO-SWITCH: Pending lines (125) exceed threshold (100)"
- Displays "SWITCHING TO SAMPLING MODE" message
- Select only latest 10 lines (CHUNK_SIZE) from 125 pending lines
- Discard remaining 115 lines (original log file preserved)
- Output "SAMPLING: Discarded 115 older lines, keeping latest 10" message
- Send only latest 10 lines to LLM for analysis
- Limit memory usage, prevent system overload
```

##### Scenario 3: Traffic Normalization - Return to FULL mode

```text
Normalization process:
1. Log influx decreases: around 5-15 lines per polling cycle
2. Pending buffer drops below threshold (100)
3. Automatically return to FULL mode
4. Resume sequential processing of all logs
```

#### A.3 Real-world Usage Examples

##### Web Server DDoS Attack Scenario

```bash
# Configuration: In .env file
CHUNK_SIZE_HTTPD_ACCESS=15
REALTIME_SAMPLING_THRESHOLD=200
REALTIME_POLLING_INTERVAL=3

# Execution
logsentinelai-httpd-access --mode realtime

# Situational behavior:
# Normal: 10-20 requests/sec → FULL mode analyzes all logs
# Attack: 500+ requests/sec → SAMPLING mode when pending buffer exceeds 200 lines
# SAMPLING: Analyze only latest 15 lines, ignore rest to protect system
# Attack ends: Request volume normalizes → Auto return to FULL mode
```

##### System Log Mass Generation Scenario

```bash
# Configuration
CHUNK_SIZE_LINUX_SYSTEM=20
REALTIME_SAMPLING_THRESHOLD=150

# Situation: System error generating 100 error log lines per second
# Within 1-2 minutes, pending buffer exceeds 150 lines
# → Auto SAMPLING: Analyze only latest 20 lines
# → Protect system resources, prioritize latest errors
```

#### A.4 Sampling Strategy Features and Limitations

##### Advantages

- **Automation**: Control system load without user intervention
- **Memory Protection**: Prevent unlimited buffer growth
- **Recency Guarantee**: Focus on most recent logs
- **Original Preservation**: Log files themselves remain intact

##### Limitations

- **Analysis Gaps**: Some logs skipped during sampling
- **Time-based Only**: Chronological processing, no severity-based priority
- **Temporary Blind Spots**: Limited pattern analysis during spike periods

##### Recommended Tuning Methods

```bash
# High-performance system (sufficient memory)
REALTIME_SAMPLING_THRESHOLD=500
CHUNK_SIZE_*=25

# Low-spec system (memory constrained)
REALTIME_SAMPLING_THRESHOLD=50
CHUNK_SIZE_*=5

# Critical logs (minimize gaps)
REALTIME_SAMPLING_THRESHOLD=1000
REALTIME_POLLING_INTERVAL=2

# General monitoring (efficiency priority)
REALTIME_SAMPLING_THRESHOLD=100
REALTIME_POLLING_INTERVAL=10
```

Through this auto-sampling mechanism, LogSentinelAI provides stable real-time analysis even in unpredictable log traffic situations.
