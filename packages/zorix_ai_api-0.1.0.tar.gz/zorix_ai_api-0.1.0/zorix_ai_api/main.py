def hello():
    print("Zorix AI API is running!")

if __name__ == "__main__":
    hello()
