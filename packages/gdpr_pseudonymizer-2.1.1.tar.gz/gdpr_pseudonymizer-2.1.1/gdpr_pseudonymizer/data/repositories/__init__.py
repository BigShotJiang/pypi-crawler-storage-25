"""Repository interfaces and implementations."""
