"""Background worker for NLP entity detection (Phase 1).

Runs DocumentProcessor.detect_entities() + build_pseudonym_previews() in a
QThreadPool thread. Produces a DetectionResult for the validation screen.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from PySide6.QtCore import QRunnable

from gdpr_pseudonymizer.gui.workers.signals import WorkerSignals
from gdpr_pseudonymizer.utils.logger import get_logger

if TYPE_CHECKING:
    from gdpr_pseudonymizer.nlp.entity_detector import DetectedEntity

logger = get_logger(__name__)


@dataclass
class DetectionResult:
    """Result of NLP detection phase for GUI validation."""

    document_text: str
    detected_entities: list[DetectedEntity]
    pseudonym_previews: dict[str, str]
    entity_type_counts: dict[str, int]
    db_path: str
    passphrase: str
    theme: str
    input_file: str
    detection_time_seconds: float
    # Maps canonical entity key ("{text}_{start_pos}") to ALL occurrences
    # in that variant group — used to expand back during finalization.
    variant_occurrences: dict[str, list[DetectedEntity]] | None = None


class DetectionWorker(QRunnable):
    """Background worker that runs NLP detection only (no pseudonymization).

    Constructor takes file_path, db_path, passphrase, and optional theme.
    Emits progress signals during detection phases.

    On success: emits ``finished`` with a ``DetectionResult``.
    On failure: emits ``error`` with a user-friendly French message.
    """

    def __init__(
        self,
        file_path: str,
        db_path: str,
        passphrase: str,
        theme: str = "neutral",
    ) -> None:
        super().__init__()
        self.signals = WorkerSignals()
        self._file_path = file_path
        self._db_path = db_path
        self._passphrase = passphrase
        self._theme = theme
        self._cancelled = False
        self.setAutoDelete(True)

    def cancel(self) -> None:
        """Request cancellation of the worker."""
        self._cancelled = True

    def run(self) -> None:
        """Execute detection in background thread."""
        try:
            self._run_detection()
        except Exception as e:
            logger.error(
                "detection_worker_unexpected", error=str(e), exc_type=type(e).__name__
            )
            self.signals.error.emit(
                f"Une erreur inattendue s'est produite lors de l'analyse.\n\n"
                f"Détail : {type(e).__name__}: {e}"
            )

    def _run_detection(self) -> None:
        """Internal detection logic with progress emission."""
        from gdpr_pseudonymizer.core.document_processor import DocumentProcessor
        from gdpr_pseudonymizer.data.database import init_database
        from gdpr_pseudonymizer.exceptions import FileProcessingError

        start_time = time.time()

        # Phase 1: Reading file (0-10%)
        self.signals.progress.emit(5, "Lecture du fichier...")

        if self._cancelled:
            return

        # Create mapping database if it doesn't exist yet
        if not Path(self._db_path).exists():
            try:
                self.signals.progress.emit(
                    8, "Création de la base de correspondances..."
                )
                init_database(self._db_path, self._passphrase)
            except ValueError as e:
                error_str = str(e)
                if "12" in error_str or "passphrase" in error_str.lower():
                    self.signals.error.emit(
                        "La phrase secrète doit contenir au moins 12 caractères."
                    )
                else:
                    self.signals.error.emit(error_str)
                return
            except Exception as e:
                logger.error("db_init_failed", error=str(e))
                self.signals.error.emit(
                    "Impossible de créer la base de correspondances."
                )
                return

        if self._cancelled:
            return

        # Phase 2: NLP detection (10-80%)
        self.signals.progress.emit(15, "Chargement du modèle linguistique...")

        try:
            processor = DocumentProcessor(
                db_path=self._db_path,
                passphrase=self._passphrase,
                theme=self._theme,
            )

            self.signals.progress.emit(40, "Détection des entités (NLP)...")

            if self._cancelled:
                return

            document_text, detected_entities = processor.detect_entities(
                input_path=self._file_path,
            )

            # Apply variant grouping (same as CLI) to deduplicate entities like
            # "Jean Dupont" and "Dr. Jean Dupont" into a single canonical entity
            from gdpr_pseudonymizer.nlp.entity_grouping import group_entity_variants

            self.signals.progress.emit(60, "Regroupement des variantes...")
            variant_groups = group_entity_variants(detected_entities)

            # Build variant occurrence map: canonical key → all occurrences
            # so finalization can expand back to every position in the document.
            variant_occurrences: dict[str, list[DetectedEntity]] = {}
            for canonical, all_occ, _ in variant_groups:
                key = f"{canonical.text}_{canonical.start_pos}"
                variant_occurrences[key] = all_occ

            # Extract canonical entities (longest form) for display
            detected_entities = [canonical for canonical, _, _ in variant_groups]

        except FileProcessingError as e:
            error_msg = str(e)
            if "protégé" in error_msg.lower() or "password" in error_msg.lower():
                self.signals.error.emit(
                    "Ce PDF est protégé par mot de passe. "
                    "Veuillez le déverrouiller avant traitement."
                )
            elif "corrompu" in error_msg.lower() or "corrupt" in error_msg.lower():
                self.signals.error.emit(
                    "Impossible de lire ce fichier. Il est peut-être corrompu."
                )
            else:
                self.signals.error.emit(error_msg)
            return
        except Exception as e:
            error_str = str(e)
            if "canary" in error_str.lower() or "passphrase" in error_str.lower():
                self.signals.error.emit(
                    "Phrase secrète incorrecte. Veuillez réessayer."
                )
            else:
                logger.error(
                    "detection_failed", error=error_str, exc_type=type(e).__name__
                )
                self.signals.error.emit(
                    f"Une erreur s'est produite lors de l'analyse.\n\n"
                    f"Détail : {type(e).__name__}: {error_str}"
                )
            return

        if self._cancelled:
            return

        # Phase 3: Build pseudonym previews (80-100%)
        self.signals.progress.emit(85, "Génération des pseudonymes...")

        try:
            pseudonym_previews = processor.build_pseudonym_previews(detected_entities)
        except Exception as e:
            logger.error("preview_generation_failed", error=str(e))
            # Non-fatal: proceed with empty previews
            pseudonym_previews = {}

        if self._cancelled:
            return

        # Count entity types from detection results (not DB — fixes DATA-001)
        entity_type_counts: dict[str, int] = {}
        for entity in detected_entities:
            t = entity.entity_type
            entity_type_counts[t] = entity_type_counts.get(t, 0) + 1

        detection_time = time.time() - start_time

        self.signals.progress.emit(100, "Analyse terminée")

        result = DetectionResult(
            document_text=document_text,
            detected_entities=detected_entities,
            pseudonym_previews=pseudonym_previews,
            entity_type_counts=entity_type_counts,
            db_path=self._db_path,
            passphrase=self._passphrase,
            theme=self._theme,
            input_file=self._file_path,
            detection_time_seconds=detection_time,
            variant_occurrences=variant_occurrences,
        )
        self.signals.finished.emit(result)
