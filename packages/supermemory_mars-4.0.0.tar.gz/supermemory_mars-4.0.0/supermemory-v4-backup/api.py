#!/usr/bin/env python3
"""
SuperMemory V4 - HTTP API Server
统一 API 入口，端口 8767
"""
import http.server
import threading
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlparse, parse_qs

# 添加包路径
SUPERMEMORY_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SUPERMEMORY_ROOT)

from supermemory.config import get_config, get_agent_config
from supermemory.core.service import SuperMemoryService

PORT = int(os.environ.get("SUPERMEMORY_PORT", 8767))

_instances = {}
_instances_lock = threading.Lock()


def get_sm(agent_id: str = "mars") -> SuperMemoryService:
    """获取或创建 Agent 服务实例"""
    with _instances_lock:
        if agent_id not in _instances:
            _instances[agent_id] = SuperMemoryService(agent_id)
        return _instances[agent_id]


class Handler(http.server.BaseHTTPRequestHandler):
    """HTTP 请求处理"""
    
    def _send_json(self, data, status: int = 200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        
        def json_safe(obj):
            if isinstance(obj, str):
                return obj.replace("\r", "\\r").replace("\n", "\\n")
            elif isinstance(obj, dict):
                return {k: json_safe(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [json_safe(item) for item in obj]
            elif hasattr(obj, "to_dict"):
                return json_safe(obj.to_dict())
            elif hasattr(obj, "__dict__"):
                return json_safe(vars(obj))
            else:
                return obj
        
        self.wfile.write(json.dumps(json_safe(data), ensure_ascii=False).encode())
    
    def _parse_path(self, path: str):
        """解析 API 路径: /api/{agent}/{resource}"""
        parts = path.strip("/").split("/")
        if len(parts) >= 3 and parts[0] == "api":
            return parts[1], parts[2] if len(parts) > 2 else None, parts[3] if len(parts) > 3 else None
        return None, None, None
    
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        
        # 健康检查
        if path == "/health":
            self._send_json({"status": "ok", "service": "SuperMemory", "version": "4.0.0"})
            return
        
        # 系统状态
        if path == "/status":
            sm = get_sm("mars")
            self._send_json(sm.get_stats())
            return
        
        # 所有 Agent 统计
        if path == "/all-stats":
            self._send_json(SuperMemoryService.all_stats())
            return
        
        # API 路由
        if path.startswith("/api/"):
            agent_id, resource, resource_id = self._parse_path(path)
            
            if not agent_id:
                self._send_json({"error": "invalid path"}, 400)
                return
            
            sm = get_sm(agent_id)
            
            # 记忆列表
            if resource == "memories":
                if resource_id:
                    mem = sm.get_memory(resource_id)
                    if mem:
                        self._send_json({"memory": mem.__dict__})
                    else:
                        self._send_json({"error": "memory not found"}, 404)
                else:
                    layer = query.get("layer", [None])[0]
                    limit = int(query.get("limit", [100])[0])
                    memories = sm.memory.search(layer=layer, limit=limit)
                    self._send_json({
                        "count": len(memories),
                        "memories": [m.__dict__ for m in memories]
                    })
                return
            
            # 搜索
            if resource == "search":
                q = query.get("q", [""])[0]
                top_k = int(query.get("top_k", [10])[0])
                layer = query.get("layer", [None])[0]
                
                if not q:
                    self._send_json({"error": "missing query parameter q"}, 400)
                    return
                
                results = sm.search_memories(q, top_k=top_k, layer=layer)
                self._send_json({
                    "query": q,
                    "count": len(results),
                    "results": [{"id": m.id, "content": m.content, "type": m.memory_type,
                                 "importance": m.importance, "layer": m.layer} for m in results]
                })
                return
            
            # 健康检查
            if resource == "health":
                self._send_json(sm.health_check())
                return
            
            # 统计
            if resource == "stats":
                self._send_json(sm.get_stats())
                return
            
            self._send_json({"error": "unknown endpoint"}, 404)
            return
        
        # 默认
        self._send_json({"error": "not found"}, 404)
    
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        # 添加记忆
        if path.startswith("/api/"):
            agent_id, resource, _ = self._parse_path(path)
            if not agent_id:
                self._send_json({"error": "invalid path"}, 400)
                return
            
            sm = get_sm(agent_id)
            
            # 读取 body
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
            
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                self._send_json({"error": "invalid JSON"}, 400)
                return
            
            # 添加记忆
            if resource == "memories":
                mem = sm.add_memory(
                    content=data.get("content", ""),
                    memory_type=data.get("type", "general"),
                    importance=data.get("importance", "P2"),
                    tags=data.get("tags", []),
                    metadata=data.get("metadata", {}),
                )
                self._send_json({"memory": mem.__dict__, "id": mem.id}, 201)
                return
            
            # 批量添加
            if resource == "bulk":
                count = sm.bulk_add(data.get("items", []))
                self._send_json({"added": count})
                return
            
            # 备份
            if resource == "backup":
                path = sm.backup_now()
                self._send_json({"backup": path})
                return
            
            # 层级流转
            if resource == "tick":
                result = sm.tick_layers()
                self._send_json(result)
                return
            
            # 健康检查触发
            if resource == "check":
                issues = sm.run_integrity_check()
                self._send_json({"issues": [i.__dict__ for i in issues]})
                return
            
            self._send_json({"error": "unknown endpoint"}, 404)
            return
        
        self._send_json({"error": "not found"}, 404)
    
    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path.startswith("/api/"):
            agent_id, resource, resource_id = self._parse_path(path)
            if not agent_id or not resource_id:
                self._send_json({"error": "invalid path"}, 400)
                return
            
            sm = get_sm(agent_id)
            
            if resource == "memories":
                success = sm.delete_memory(resource_id)
                self._send_json({"deleted": success})
                return
        
        self._send_json({"error": "not found"}, 404)
    
    def log_message(self, format, *args):
        """抑制默认日志"""
        pass


def run():
    """启动 API Server"""
    server = http.server.HTTPServer(("0.0.0.0", PORT), Handler)
    print(f"SuperMemory API Server v4.0 running on port {PORT}")
    print(f"  Health: http://localhost:{PORT}/health")
    print(f"  Status: http://localhost:{PORT}/status")
    print(f"  API:    http://localhost:{PORT}/api/{{agent}}/{{resource}}")
    server.serve_forever()


if __name__ == "__main__":
    run()
