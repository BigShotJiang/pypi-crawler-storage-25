#!/usr/bin/env python3
"""
SuperMemory V4 - 自愈进化器
"""
import os
import time
import threading
import traceback
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class HealerIssue:
    id: str
    severity: str  # critical, warning, info
    module: str
    description: str
    detected_at: str
    fixed: bool = False
    fix_attempts: int = 0


class SelfHealer:
    """
    自愈系统 - 自动检测并修复问题
    """
    
    VERSION = "4.0.0"
    
    def __init__(self, agents: List[str] = None):
        self.agents = agents or ["mars", "chen", "wei", "ying"]
        self._issues: Dict[str, HealerIssue] = {}
        self._lock = threading.Lock()
        self._enabled = True
        self._check_interval = 300  # 5分钟
    
    def check_all(self) -> List[HealerIssue]:
        """检查所有 Agent"""
        new_issues = []
        
        for agent in self.agents:
            issues = self._check_agent(agent)
            for issue in issues:
                key = f"{agent}:{issue.module}:{issue.description[:30]}"
                if key not in self._issues:
                    self._issues[key] = issue
                    new_issues.append(issue)
        
        return new_issues
    
    def _check_agent(self, agent: str) -> List[HealerIssue]:
        """检查单个 Agent"""
        issues = []
        
        # 导入在这里避免循环依赖
        from supermemory.core.service import SuperMemoryService
        
        try:
            sm = SuperMemoryService.get_instance(agent)
            health = sm.health_check()
            
            # 检查完整性
            integrity = health.get("integrity", {})
            if integrity.get("critical", 0) > 0:
                issues.append(HealerIssue(
                    id=f"{agent}:integrity",
                    severity="critical",
                    module="integrity",
                    description=f"Agent {agent} 存在关键完整性问题",
                    detected_at=datetime.now().isoformat(),
                ))
            
            # 检查数据一致性
            stats = health.get("stats", {})
            mem_count = stats.get("memory_count", 0)
            vec_count = stats.get("vector_count", 0)
            
            if vec_count == 0 and mem_count > 0:
                issues.append(HealerIssue(
                    id=f"{agent}:vectors",
                    severity="warning",
                    module="vector",
                    description=f"Agent {agent} 有 {mem_count} 条记忆但无向量",
                    detected_at=datetime.now().isoformat(),
                ))
        
        except Exception as e:
            issues.append(HealerIssue(
                id=f"{agent}:error",
                severity="critical",
                module="api",
                description=f"Agent {agent} API 错误: {str(e)[:50]}",
                detected_at=datetime.now().isoformat(),
            ))
        
        return issues
    
    def fix_issue(self, issue: HealerIssue) -> bool:
        """尝试修复问题"""
        from supermemory.core.service import SuperMemoryService
        
        try:
            agent = issue.id.split(":")[0]
            sm = SuperMemoryService.get_instance(agent)
            
            if issue.module == "integrity":
                # 运行完整性检查并自动修复
                checker = sm.integrity
                for ci in checker.check_all():
                    if ci.severity in ("critical", "warning"):
                        checker.fix_issue(ci)
                return True
            
            if issue.module == "vector":
                # 重新生成缺失的向量
                memories = sm.memory.search(limit=1000)
                for mem in memories:
                    emb = sm.vector.generate_embedding(mem.content)
                    sm.vector.add(mem.id, mem.content, emb)
                return True
            
            return False
        
        except Exception:
            return False
    
    def run_cycle(self) -> Dict:
        """执行一个完整的自愈周期"""
        if not self._enabled:
            return {"status": "disabled"}
        
        results = {
            "timestamp": datetime.now().isoformat(),
            "issues_found": 0,
            "issues_fixed": 0,
            "details": [],
        }
        
        new_issues = self.check_all()
        results["issues_found"] = len(new_issues)
        
        for issue in new_issues:
            if self.fix_issue(issue):
                issue.fixed = True
                issue.fix_attempts += 1
                results["issues_fixed"] += 1
                results["details"].append(f"✅ Fixed: {issue.description}")
            else:
                issue.fix_attempts += 1
                results["details"].append(f"❌ Failed: {issue.description}")
        
        return results
    
    def enable(self):
        self._enabled = True
    
    def disable(self):
        self._enabled = False
    
    def get_status(self) -> Dict:
        return {
            "enabled": self._enabled,
            "total_issues": len(self._issues),
            "unfixed": len([i for i in self._issues.values() if not i.fixed]),
            "check_interval": self._check_interval,
        }
