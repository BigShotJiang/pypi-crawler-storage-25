#!/usr/bin/env python3
"""
SuperMemory V4 - 备份服务
"""
import os
import shutil
import tarfile
import json
from pathlib import Path
from datetime import datetime
from typing import List, Optional


class BackupService:
    """
    记忆备份服务
    支持全量备份、增量备份、恢复
    """
    
    def __init__(self, data_dir: str, backup_dir: str = None):
        self.data_dir = data_dir
        self.backup_dir = backup_dir or os.path.join(data_dir, "backups")
        Path(self.backup_dir).mkdir(parents=True, exist_ok=True)
    
    def backup(self, agent_id: str = None, include_vectors: bool = True) -> str:
        """
        执行全量备份
        返回: 备份文件路径
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if agent_id:
            name = f"{agent_id}_{timestamp}.tar.gz"
        else:
            name = f"full_backup_{timestamp}.tar.gz"
        
        backup_path = os.path.join(self.backup_dir, name)
        
        with tarfile.open(backup_path, 'w:gz') as tar:
            if agent_id:
                source = os.path.join(self.data_dir, agent_id)
                tar.add(source, arcname=agent_id)
            else:
                for item in os.listdir(self.data_dir):
                    if item == "backups":
                        continue
                    source = os.path.join(self.data_dir, item)
                    tar.add(source, arcname=item)
        
        # 记录备份元数据
        meta_path = backup_path + ".meta.json"
        with open(meta_path, 'w') as f:
            json.dump({
                "timestamp": timestamp,
                "agent_id": agent_id,
                "size": os.path.getsize(backup_path),
                "include_vectors": include_vectors,
            }, f)
        
        return backup_path
    
    def list_backups(self, agent_id: str = None) -> List[dict]:
        """列出所有备份"""
        backups = []
        
        for fname in os.listdir(self.backup_dir):
            if not fname.endswith('.tar.gz'):
                continue
            
            meta_path = os.path.join(self.backup_dir, fname + ".meta.json")
            if os.path.exists(meta_path):
                with open(meta_path) as f:
                    meta = json.load(f)
            else:
                meta = {"timestamp": fname, "unknown": True}
            
            full_path = os.path.join(self.backup_dir, fname)
            meta["file"] = fname
            meta["size"] = os.path.getsize(full_path)
            meta["path"] = full_path
            
            if agent_id is None or meta.get("agent_id") == agent_id:
                backups.append(meta)
        
        return sorted(backups, key=lambda x: x["timestamp"], reverse=True)
    
    def restore(self, backup_path: str, agent_id: str = None) -> bool:
        """恢复备份"""
        if not os.path.exists(backup_path):
            return False
        
        extract_dir = os.path.join(self.backup_dir, "temp_restore")
        
        try:
            with tarfile.open(backup_path, 'r:gz') as tar:
                tar.extractall(extract_dir)
            
            # 找到解压的目录
            extracted_items = os.listdir(extract_dir)
            
            for item in extracted_items:
                src = os.path.join(extract_dir, item)
                if agent_id and item != agent_id:
                    continue
                dst = os.path.join(self.data_dir, item)
                
                # 删除旧的
                if os.path.isdir(dst):
                    shutil.rmtree(dst)
                elif os.path.isfile(dst):
                    os.remove(dst)
                
                # 移动新的
                shutil.move(src, dst)
            
            return True
        except Exception as e:
            print(f"Restore failed: {e}")
            return False
        finally:
            shutil.rmtree(extract_dir, ignore_errors=True)
    
    def cleanup_old_backups(self, keep: int = 10, agent_id: str = None):
        """清理旧备份"""
        backups = self.list_backups(agent_id)
        
        for backup in backups[keep:]:
            try:
                os.remove(backup["path"])
                meta = backup["path"] + ".meta.json"
                if os.path.exists(meta):
                    os.remove(meta)
            except OSError:
                pass
