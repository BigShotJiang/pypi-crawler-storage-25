#!/usr/bin/env python3
"""
SuperMemory V4 - 记忆核心服务
"""
import sqlite3
import json
import uuid
import threading
import time
from pathlib import Path
from typing import List, Dict, Optional, Any
from datetime import datetime
from dataclasses import dataclass


@dataclass
class Memory:
    id: str
    content: str
    memory_type: str = "general"
    importance: str = "P2"
    tags: List[str] = None
    embedding_id: str = None
    metadata: dict = None
    created_at: str = None
    updated_at: str = None
    access_count: int = 0
    last_accessed: str = None
    layer: str = "hot"
    version: int = 1
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []
        if self.metadata is None:
            self.metadata = {}
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()
        if self.updated_at is None:
            self.updated_at = self.created_at
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "content": self.content,
            "type": self.memory_type,
            "importance": self.importance,
            "tags": json.dumps(self.tags, ensure_ascii=False),
            "embedding_id": self.embedding_id,
            "metadata": json.dumps(self.metadata, ensure_ascii=False),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed or "",
            "layer": self.layer,
            "version": self.version,
        }
    
    @classmethod
    def from_row(cls, row: dict) -> "Memory":
        tags = row.get("tags", "[]")
        metadata = row.get("metadata", "{}")
        if isinstance(tags, str):
            tags = json.loads(tags)
        if isinstance(metadata, str):
            metadata = json.loads(metadata)
        return cls(
            id=row["id"],
            content=row["content"],
            memory_type=row.get("type", "general"),
            importance=row.get("importance", "P2"),
            tags=tags,
            embedding_id=row.get("embedding_id"),
            metadata=metadata,
            created_at=row.get("created_at"),
            updated_at=row.get("updated_at"),
            access_count=row.get("access_count", 0),
            last_accessed=row.get("last_accessed"),
            layer=row.get("layer", "hot"),
            version=row.get("version", 1),
        )


class MemoryService:
    """记忆存储服务"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._ensure_dir()
        self._init_db()
        self._lock = threading.RLock()
    
    def _ensure_dir(self):
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
    
    def _get_conn(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)
    
    def _init_db(self):
        conn = self._get_conn()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                type TEXT DEFAULT 'general',
                importance TEXT DEFAULT 'P2',
                tags TEXT DEFAULT '[]',
                embedding_id TEXT,
                metadata TEXT DEFAULT '{}',
                created_at TEXT,
                updated_at TEXT,
                access_count INTEGER DEFAULT 0,
                last_accessed TEXT DEFAULT '',
                layer TEXT DEFAULT 'hot',
                version INTEGER DEFAULT 1
            )
        """)
        # 确保所有列都存在（向后兼容）
        for col, col_type in [
            ("embedding_id", "TEXT"),
            ("access_count", "INTEGER DEFAULT 0"),
            ("last_accessed", "TEXT DEFAULT ''"),
            ("layer", "TEXT DEFAULT 'hot'"),
            ("version", "INTEGER DEFAULT 1"),
        ]:
            try:
                conn.execute(f"ALTER TABLE memories ADD COLUMN {col} {col_type}")
            except sqlite3.OperationalError:
                pass
        
        for idx, cols in [
            ("idx_type", "type"),
            ("idx_importance", "importance"),
            ("idx_layer", "layer"),
            ("idx_created", "created_at"),
            ("idx_last_accessed", "last_accessed"),
        ]:
            try:
                conn.execute(f"CREATE INDEX IF NOT EXISTS {idx} ON memories({cols})")
            except sqlite3.OperationalError:
                pass
        
        conn.commit()
        conn.close()
    
    def add(self, memory: Memory) -> bool:
        with self._lock:
            conn = self._get_conn()
            d = memory.to_dict()
            conn.execute("""
                INSERT INTO memories (id, content, type, importance, tags, embedding_id,
                                     metadata, created_at, updated_at, access_count,
                                     last_accessed, layer, version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                d["id"], d["content"], d["type"], d["importance"], d["tags"],
                d["embedding_id"], d["metadata"], d["created_at"], d["updated_at"],
                d["access_count"], d["last_accessed"], d["layer"], d["version"]
            ))
            conn.commit()
            conn.close()
            return True
    
    def get(self, memory_id: str) -> Optional[Memory]:
        with self._lock:
            conn = self._get_conn()
            conn.row_factory = sqlite3.Row
            cur = conn.execute(
                "SELECT * FROM memories WHERE id = ?",
                (memory_id,)
            )
            row = cur.fetchone()
            conn.close()
            if row:
                return Memory.from_row(dict(row))
            return None
    
    def update(self, memory_id: str, **kwargs) -> bool:
        with self._lock:
            allowed = {"content", "type", "importance", "tags", "metadata", "layer"}
            updates = {k: v for k, v in kwargs.items() if k in allowed}
            if not updates:
                return False
            
            updates["updated_at"] = datetime.now().isoformat()
            set_clause = ", ".join(f"{k} = ?" for k in updates.keys())
            values = list(updates.values()) + [memory_id]
            
            conn = self._get_conn()
            conn.execute(
                f"UPDATE memories SET {set_clause} WHERE id = ?",
                values
            )
            conn.commit()
            conn.close()
            return True
    
    def delete(self, memory_id: str) -> bool:
        with self._lock:
            conn = self._get_conn()
            conn.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
            conn.commit()
            conn.close()
            return True
    
    def search(self, query: str = None, layer: str = None,
               importance: str = None, memory_type: str = None,
               limit: int = 100, offset: int = 0) -> List[Memory]:
        with self._lock:
            conditions = []
            params = []
            
            if layer:
                conditions.append("layer = ?")
                params.append(layer)
            if importance:
                conditions.append("importance = ?")
                params.append(importance)
            if memory_type:
                conditions.append("type = ?")
                params.append(memory_type)
            if query:
                conditions.append("content LIKE ?")
                params.append(f"%{query}%")
            
            where = " AND ".join(conditions) if conditions else "1=1"
            params.extend([limit, offset])
            
            conn = self._get_conn()
            conn.row_factory = sqlite3.Row
            cur = conn.execute(
                f"SELECT * FROM memories WHERE {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
                params
            )
            rows = [Memory.from_row(dict(row)) for row in cur.fetchall()]
            conn.close()
            return rows
    
    def count(self, layer: str = None) -> int:
        with self._lock:
            conn = self._get_conn()
            if layer:
                cur = conn.execute("SELECT COUNT(*) FROM memories WHERE layer = ?", (layer,))
            else:
                cur = conn.execute("SELECT COUNT(*) FROM memories")
            count = cur.fetchone()[0]
            conn.close()
            return count
    
    def increment_access(self, memory_id: str):
        with self._lock:
            conn = self._get_conn()
            now = datetime.now().isoformat()
            conn.execute(
                "UPDATE memories SET access_count = access_count + 1, last_accessed = ? WHERE id = ?",
                (now, memory_id)
            )
            conn.commit()
            conn.close()
    
    def get_by_layer(self, layer: str) -> List[Memory]:
        return self.search(layer=layer)
    
    def get_recent(self, limit: int = 10) -> List[Memory]:
        return self.search(limit=limit)
    
    def get_old_memories(self, days: int = 30, layer: str = "hot") -> List[Memory]:
        """获取超过指定天数的热层记忆（待降级）"""
        cutoff = datetime.fromtimestamp(
            time.time() - days * 86400
        ).isoformat()
        
        with self._lock:
            conn = self._get_conn()
            conn.row_factory = sqlite3.Row
            cur = conn.execute(
                "SELECT * FROM memories WHERE layer = ? AND created_at < ? ORDER BY created_at",
                (layer, cutoff)
            )
            rows = [Memory.from_row(dict(row)) for row in cur.fetchall()]
            conn.close()
            return rows
