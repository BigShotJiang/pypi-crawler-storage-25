#!/usr/bin/env python3
"""
SuperMemory V4 - 向量嵌入服务
"""
import json
import os
import threading
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass


@dataclass
class VectorEntry:
    id: str
    content: str
    embedding: List[float]
    metadata: dict
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "content": self.content,
            "embedding": self.embedding,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> "VectorEntry":
        return cls(
            id=d["id"],
            content=d["content"],
            embedding=d["embedding"],
            metadata=d.get("metadata", {}),
        )


class VectorService:
    """
    本地向量存储服务
    使用 JSON 文件存储，支持语义搜索
    """
    
    def __init__(self, store_path: str):
        self.store_path = store_path
        self._ensure_dir()
        self._dim = 384  # 默认维度，会被 _load 覆盖
        self._vectors: Dict[str, VectorEntry] = self._load()
        self._lock = threading.RLock()
    
    def _ensure_dir(self):
        Path(self.store_path).parent.mkdir(parents=True, exist_ok=True)
    
    def _load(self) -> Dict[str, VectorEntry]:
        if os.path.exists(self.store_path):
            try:
                with open(self.store_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                # 自动检测向量维度
                for v in data.values():
                    if 'embedding' in v and isinstance(v['embedding'], list):
                        self._dim = len(v['embedding'])
                        break
                return {k: VectorEntry.from_dict(v) for k, v in data.items()}
            except (json.JSONDecodeError, KeyError):
                return {}
        return {}
    
    def _save(self):
        with open(self.store_path, 'w', encoding='utf-8') as f:
            data = {k: v.to_dict() for k, v in self._vectors.items()}
            json.dump(data, f, ensure_ascii=False)
    
    def count(self) -> int:
        return len(self._vectors)
    
    def add(self, vector_id: str, content: str, embedding: List[float],
            metadata: dict = None) -> bool:
        with self._lock:
            entry = VectorEntry(vector_id, content, embedding, metadata or {})
            self._vectors[vector_id] = entry
            self._save()
            return True
    
    def get(self, vector_id: str) -> Optional[VectorEntry]:
        return self._vectors.get(vector_id)
    
    def delete(self, vector_id: str) -> bool:
        with self._lock:
            if vector_id in self._vectors:
                del self._vectors[vector_id]
                self._save()
                return True
            return False
    
    def search(self, query_embedding: List[float], top_k: int = 10) -> List[Tuple[str, float]]:
        """
        语义搜索（余弦相似度）
        返回: [(vector_id, score), ...]
        """
        if not self._vectors:
            return []
        
        query = np.array(query_embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query)
        if query_norm == 0:
            return []
        
        results = []
        for vid, entry in self._vectors.items():
            emb = np.array(entry.embedding, dtype=np.float32)
            norm = np.linalg.norm(emb)
            if norm == 0:
                continue
            score = np.dot(query, emb) / (query_norm * norm)
            results.append((vid, float(score)))
        
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]
    
    def search_by_content(self, query: str, top_k: int = 10) -> List[Tuple[str, float]]:
        """
        基于关键词的简单搜索（BM25替代）
        直接在 content 中匹配关键词
        """
        query_words = query.lower().split()
        if not query_words:
            return []
        
        results = []
        for vid, entry in self._vectors.items():
            content_lower = entry.content.lower()
            # 简单计分：匹配的词数
            score = sum(1 for word in query_words if word in content_lower)
            if score > 0:
                results.append((vid, score))
        
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]
    
    def get_stats(self) -> dict:
        total = len(self._vectors)
        if total == 0:
            return {"total": 0, "avg_dim": 0}
        
        dims = set()
        for v in self._vectors.values():
            dims.add(len(v.embedding))
        
        return {
            "total": total,
            "dimensions": list(dims),
            "file_size": os.path.getsize(self.store_path) if os.path.exists(self.store_path) else 0,
        }
    
    def generate_embedding(self, content: str) -> List[float]:
        """
        生成伪嵌入向量（用于无外部模型时）
        基于内容哈希 + 词频生成确定性向量
        """
        words = content.lower().split()
        dim = self._dim
        
        # 如果还没有维度信息，使用默认值 384
        if dim == 0:
            dim = 768
        
        vec = np.zeros(dim, dtype=np.float32)
        
        for i, word in enumerate(words[:dim]):
            hash_val = hash(word) % 10000
            vec[i] = hash_val / 10000.0
        
        # 归一化
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        
        return vec.tolist()
    
    def bulk_sync(self):
        """强制同步到磁盘"""
        with self._lock:
            self._save()
