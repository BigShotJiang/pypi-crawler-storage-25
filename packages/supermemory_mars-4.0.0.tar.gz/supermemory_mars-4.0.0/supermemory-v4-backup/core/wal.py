#!/usr/bin/env python3
"""
SuperMemory V4 - WAL 预写日志
"""
import os
import json
import threading
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional


class WALLogger:
    """
    预写日志：重要信息先写入 WAL，再处理业务
    崩溃后可通过 WAL 恢复
    """
    
    def __init__(self, wal_path: str, max_entries: int = 10000):
        self.wal_path = wal_path
        self.max_entries = max_entries
        self._lock = threading.Lock()
        self._ensure_dir()
    
    def _ensure_dir(self):
        Path(self.wal_path).parent.mkdir(parents=True, exist_ok=True)
    
    def log(self, event_type: str, agent_id: str, content: str,
            metadata: dict = None) -> str:
        """
        写入 WAL 条目
        返回: entry_id
        """
        entry_id = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{event_type}"
        
        entry = {
            "id": entry_id,
            "timestamp": datetime.now().isoformat(),
            "type": event_type,
            "agent_id": agent_id,
            "content": content,
            "metadata": metadata or {},
        }
        
        with self._lock:
            with open(self.wal_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(entry, ensure_ascii=False) + '\n')
            
            # 定期清理
            self._maybe_compact()
        
        return entry_id
    
    def read(self, limit: int = 100, offset: int = 0) -> List[Dict]:
        """读取最近 WAL 条目"""
        if not os.path.exists(self.wal_path):
            return []
        
        with self._lock:
            with open(self.wal_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
        
        start = max(0, len(lines) - offset - limit)
        end = len(lines) - offset if offset > 0 else len(lines)
        
        results = []
        for line in lines[start:end]:
            try:
                results.append(json.loads(line.strip()))
            except json.JSONDecodeError:
                continue
        
        return results
    
    def count(self) -> int:
        if not os.path.exists(self.wal_path):
            return 0
        with open(self.wal_path, 'r', encoding='utf-8') as f:
            return len(f.readlines())
    
    def clear(self):
        """清空 WAL（危险操作）"""
        with self._lock:
            open(self.wal_path, 'w').close()
    
    def _maybe_compact(self):
        """超过最大条目数时压缩"""
        if not os.path.exists(self.wal_path):
            return
        
        size = os.path.getsize(self.wal_path)
        # 大于 10MB 则压缩
        if size > 10 * 1024 * 1024:
            self._compact()
    
    def _compact(self):
        """压缩 WAL，保留最近条目"""
        with open(self.wal_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 保留最近一半
        keep = lines[len(lines) // 2:]
        
        with open(self.wal_path, 'w', encoding='utf-8') as f:
            f.writelines(keep)
