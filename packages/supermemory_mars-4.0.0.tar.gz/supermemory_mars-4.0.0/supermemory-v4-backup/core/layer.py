#!/usr/bin/env python3
"""
SuperMemory V4 - 三层记忆管理层
热层(hot) -> 暖层(warm) -> 冷层(cold) -> 归档(archived)
"""
import time
import threading
from datetime import datetime, timedelta
from typing import List, Dict
from dataclasses import dataclass

from .memory import MemoryService, Memory


@dataclass
class LayerConfig:
    hot_ttl: int = 86400 * 7      # 7天
    warm_ttl: int = 86400 * 30    # 30天
    cold_ttl: int = 86400 * 90    # 90天
    archive_ttl: int = 86400 * 365 # 1年
    
    # 降级阈值
    hot_to_warm_access: int = 3   # 访问少于3次降级
    warm_to_cold_days: int = 30   # 30天无访问降级
    cold_to_archive_days: int = 90 # 90天无访问归档


class ThreeLayerManager:
    """
    三层记忆管理：
    - hot: 活跃记忆，7天无访问降级
    - warm: 一般记忆，30天无访问归档
    - cold: 冷记忆，90天后自动归档
    - archived: 归档记忆，保留但不参与搜索
    """
    
    LAYER_HOT = "hot"
    LAYER_WARM = "warm"
    LAYER_COLD = "cold"
    LAYER_ARCHIVED = "archived"
    
    def __init__(self, memory_service: MemoryService, config: LayerConfig = None):
        self.memory = memory_service
        self.config = config or LayerConfig()
        self._lock = threading.Lock()
    
    def get_layer_stats(self) -> Dict[str, int]:
        """获取各层记忆数量"""
        return {
            "hot": self.memory.count(layer=self.LAYER_HOT),
            "warm": self.memory.count(layer=self.LAYER_WARM),
            "cold": self.memory.count(layer=self.LAYER_COLD),
            "archived": self.memory.count(layer=self.LAYER_ARCHIVED),
            "total": self.memory.count(),
        }
    
    def tick(self) -> Dict[str, int]:
        """
        执行一次层级流转检查
        返回: 本次变更数量
        """
        changes = {"demoted": 0, "archived": 0}
        
        with self._lock:
            # 热层 -> 暖层（7天无访问或访问次数少）
            hot_memories = self.memory.get_old_memories(
                days=self.config.hot_ttl // 86400,
                layer=self.LAYER_HOT
            )
            for mem in hot_memories:
                if mem.access_count < self.config.hot_to_warm_access:
                    self.memory.update(mem.id, layer=self.LAYER_WARM)
                    changes["demoted"] += 1
            
            # 暖层 -> 冷层（30天无访问）
            warm_memories = self.memory.get_old_memories(
                days=self.config.warm_ttl // 86400,
                layer=self.LAYER_WARM
            )
            for mem in warm_memories:
                self.memory.update(mem.id, layer=self.LAYER_COLD)
                changes["demoted"] += 1
            
            # 冷层 -> 归档（90天无访问）
            cold_memories = self.memory.get_old_memories(
                days=self.config.cold_ttl // 86400,
                layer=self.LAYER_COLD
            )
            for mem in cold_memories:
                self.memory.update(mem.id, layer=self.LAYER_ARCHIVED)
                changes["archived"] += 1
        
        return changes
    
    def promote_to_hot(self, memory_id: str):
        """将记忆提升到热层（被访问时）"""
        self.memory.update(memory_id, layer=self.LAYER_HOT)
    
    def get_memories_by_layer(self, layer: str, limit: int = 100) -> List[Memory]:
        """获取指定层的记忆"""
        return self.memory.search(layer=layer, limit=limit)
    
    def archive_old_memories(self, days: int = 365) -> int:
        """归档超过指定天数的所有记忆"""
        cutoff = datetime.fromtimestamp(time.time() - days * 86400).isoformat()
        
        count = 0
        for layer in [self.LAYER_HOT, self.LAYER_WARM, self.LAYER_COLD]:
            memories = self.memory.search(layer=layer, limit=1000)
            for mem in memories:
                if mem.created_at < cutoff:
                    self.memory.update(mem.id, layer=self.LAYER_ARCHIVED)
                    count += 1
        return count
