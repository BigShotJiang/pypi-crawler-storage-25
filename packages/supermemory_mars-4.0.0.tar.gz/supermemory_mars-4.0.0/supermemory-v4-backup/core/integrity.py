#!/usr/bin/env python3
"""
SuperMemory V4 - 完整性健康检查
"""
import os
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class Issue:
    severity: str  # critical, warning, info
    module: str
    description: str
    fix_suggestion: str


class IntegrityChecker:
    """
    系统完整性检查
    检查数据库、文件、配置完整性
    """
    
    def __init__(self, agent_id: str, db_path: str, vector_path: str):
        self.agent_id = agent_id
        self.db_path = db_path
        self.vector_path = vector_path
    
    def check_all(self) -> List[Issue]:
        """执行所有检查"""
        issues = []
        issues.extend(self._check_database())
        issues.extend(self._check_vectors())
        issues.extend(self._check_schema())
        return issues
    
    def _check_database(self) -> List[Issue]:
        issues = []
        
        if not os.path.exists(self.db_path):
            issues.append(Issue(
                severity="critical",
                module="database",
                description=f"数据库不存在: {self.db_path}",
                fix_suggestion="初始化数据库"
            ))
            return issues
        
        # 检查文件大小
        size = os.path.getsize(self.db_path)
        if size == 0:
            issues.append(Issue(
                severity="critical",
                module="database",
                description="数据库文件为空",
                fix_suggestion="数据库可能损坏，需要恢复"
            ))
        
        return issues
    
    def _check_vectors(self) -> List[Issue]:
        issues = []
        
        if not os.path.exists(self.vector_path):
            issues.append(Issue(
                severity="warning",
                module="vector",
                description=f"向量文件不存在: {self.vector_path}",
                fix_suggestion="将创建新的向量文件"
            ))
            return issues
        
        size = os.path.getsize(self.vector_path)
        if size == 0:
            issues.append(Issue(
                severity="warning",
                module="vector",
                description="向量文件为空",
                fix_suggestion="检查向量是否正确生成"
            ))
        
        return issues
    
    def _check_schema(self) -> List[Issue]:
        issues = []
        
        required_columns = [
            "id", "content", "type", "importance", "tags",
            "embedding_id", "metadata", "created_at", "updated_at",
            "access_count", "last_accessed", "layer", "version"
        ]
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.execute("PRAGMA table_info(memories)")
            columns = {row[1] for row in cur.fetchall()}
            conn.close()
            
            missing = set(required_columns) - columns
            if missing:
                issues.append(Issue(
                    severity="warning",
                    module="schema",
                    description=f"缺少列: {missing}",
                    fix_suggestion="运行 schema 迁移"
                ))
        except Exception as e:
            issues.append(Issue(
                severity="critical",
                module="schema",
                description=f"无法读取 schema: {e}",
                fix_suggestion="检查数据库权限或修复损坏"
            ))
        
        return issues
    
    def fix_issue(self, issue: Issue) -> bool:
        """尝试自动修复问题"""
        if issue.module == "database" and issue.severity == "critical":
            if "不存在" in issue.description:
                # 初始化空数据库
                from .memory import MemoryService
                MemoryService(self.db_path)
                return True
        
        if issue.module == "schema":
            from .memory import MemoryService
            MemoryService(self.db_path)
            return True
        
        return False
    
    def health_summary(self) -> Dict:
        """健康状态摘要"""
        issues = self.check_all()
        return {
            "status": "healthy" if not any(i.severity == "critical" for i in issues) else "unhealthy",
            "total_issues": len(issues),
            "critical": len([i for i in issues if i.severity == "critical"]),
            "warnings": len([i for i in issues if i.severity == "warning"]),
        }
