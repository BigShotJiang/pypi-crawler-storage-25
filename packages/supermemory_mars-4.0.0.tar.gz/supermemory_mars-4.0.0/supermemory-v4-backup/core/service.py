#!/usr/bin/env python3
"""
SuperMemory V4 - 统一服务入口
"""
import os
import json
import uuid
import threading
from datetime import datetime
from typing import Dict, List, Optional, Any

from ..config import get_agent_config, SuperMemoryConfig
from .memory import MemoryService, Memory
from .vector import VectorService
from .layer import ThreeLayerManager, LayerConfig
from .wal import WALLogger
from .backup import BackupService
from .integrity import IntegrityChecker


class SuperMemoryService:
    """
    SuperMemory 统一服务
    整合所有核心功能，提供单一接口
    """
    
    def __init__(self, agent_id: str = "mars", config: SuperMemoryConfig = None):
        self.agent_id = agent_id
        self.config = config or SuperMemoryConfig()
        agent_config = get_agent_config(agent_id)
        
        # 核心服务
        self.memory = MemoryService(agent_config.db_path)
        self.vector = VectorService(agent_config.vector_path)
        self.layer = ThreeLayerManager(
            self.memory,
            LayerConfig(
                hot_ttl=self.config.hot_ttl,
                warm_ttl=self.config.warm_ttl,
                cold_ttl=self.config.cold_ttl,
                archive_ttl=self.config.archive_ttl,
            )
        )
        self.wal = WALLogger(agent_config.wal_path)
        self.backup = BackupService(self.config.data_dir)
        self.integrity = IntegrityChecker(
            agent_id,
            agent_config.db_path,
            agent_config.vector_path
        )
        
        self._lock = threading.RLock()
        self._instances: Dict[str, "SuperMemoryService"] = {}
    
    # -------------------------------------------------------------------------
    # 记忆操作
    # -------------------------------------------------------------------------
    
    def add_memory(self, content: str, memory_type: str = "general",
                   importance: str = "P2", tags: List[str] = None,
                   metadata: dict = None) -> Memory:
        """添加记忆"""
        with self._lock:
            memory = Memory(
                id=str(uuid.uuid4())[:8],
                content=content,
                memory_type=memory_type,
                importance=importance,
                tags=tags or [],
                metadata=metadata or {},
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
            )
            
            # 生成向量
            embedding = self.vector.generate_embedding(content)
            self.vector.add(memory.id, content, embedding)
            
            # 存储记忆
            self.memory.add(memory)
            
            # WAL 记录
            self.wal.log("memory_added", self.agent_id, content[:100])
            
            return memory
    
    def get_memory(self, memory_id: str) -> Optional[Memory]:
        """获取记忆"""
        mem = self.memory.get(memory_id)
        if mem:
            self.memory.increment_access(memory_id)
        return mem
    
    def search_memories(self, query: str, top_k: int = 10,
                        layer: str = None) -> List[Memory]:
        """搜索记忆（语义+关键词）"""
        # 向量搜索
        query_emb = self.vector.generate_embedding(query)
        vector_results = self.vector.search(query_emb, top_k=top_k * 2)
        
        # 关键词搜索
        keyword_results = self.vector.search_by_content(query, top_k=top_k * 2)
        
        # 合并结果
        all_ids = set()
        results = []
        seen = set()
        
        for score_list in [vector_results, keyword_results]:
            for vid, score in score_list:
                if vid in all_ids or vid in seen:
                    continue
                seen.add(vid)
                all_ids.add(vid)
                mem = self.memory.get(vid)
                if mem:
                    if layer is None or mem.layer == layer:
                        results.append(mem)
                        if len(results) >= top_k:
                            break
        
        # 如果结果不够，用关键词补充
        if len(results) < top_k:
            keyword_only = self.memory.search(query=query, layer=layer, limit=top_k)
            for mem in keyword_only:
                if mem.id not in seen:
                    results.append(mem)
                    seen.add(mem.id)
                    if len(results) >= top_k:
                        break
        
        return results[:top_k]
    
    def update_memory(self, memory_id: str, **kwargs) -> bool:
        """更新记忆"""
        return self.memory.update(memory_id, **kwargs)
    
    def delete_memory(self, memory_id: str) -> bool:
        """删除记忆"""
        self.vector.delete(memory_id)
        return self.memory.delete(memory_id)
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        layer_stats = self.layer.get_layer_stats()
        return {
            "agent_id": self.agent_id,
            "memory_count": layer_stats["total"],
            "vector_count": self.vector.count(),
            "wal_count": self.wal.count(),
            "layer_stats": layer_stats,
            "vector_stats": self.vector.get_stats(),
        }
    
    def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        integrity = self.integrity.health_summary()
        stats = self.get_stats()
        
        return {
            "status": integrity["status"],
            "agent_id": self.agent_id,
            "integrity": integrity,
            "stats": stats,
            "timestamp": datetime.now().isoformat(),
        }
    
    def tick_layers(self) -> Dict[str, int]:
        """执行层级流转"""
        return self.layer.tick()
    
    def run_integrity_check(self) -> List:
        """运行完整性检查"""
        return self.integrity.check_all()
    
    def backup_now(self) -> str:
        """立即备份"""
        return self.backup.backup(self.agent_id)
    
    # -------------------------------------------------------------------------
    # 批量操作
    # -------------------------------------------------------------------------
    
    def bulk_add(self, items: List[Dict]) -> int:
        """批量添加记忆"""
        count = 0
        for item in items:
            try:
                self.add_memory(
                    content=item.get("content", ""),
                    memory_type=item.get("type", "general"),
                    importance=item.get("importance", "P2"),
                    tags=item.get("tags", []),
                    metadata=item.get("metadata", {}),
                )
                count += 1
            except Exception:
                pass
        return count
    
    # -------------------------------------------------------------------------
    # 跨 Agent 统一入口（类方法）
    # -------------------------------------------------------------------------
    
    @classmethod
    def get_instance(cls, agent_id: str = "mars") -> "SuperMemoryService":
        """获取指定 Agent 的服务实例（单例）"""
        if not hasattr(cls, "_instances"):
            cls._instances = {}
        
        if agent_id not in cls._instances:
            cls._instances[agent_id] = cls(agent_id)
        
        return cls._instances[agent_id]
    
    @classmethod
    def all_stats(cls) -> Dict[str, Dict]:
        """获取所有 Agent 的统计"""
        agents = ["mars", "chen", "wei", "ying"]
        return {agent: cls.get_instance(agent).get_stats() for agent in agents}
