#!/usr/bin/env python3
"""
SuperMemory V4 - 主守护进程
启动所有服务并持续监控
"""
import os
import sys
import time
import signal
import threading
import subprocess
import http.server
import json
from pathlib import Path

# 添加包路径
SUPERMEMORY_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SUPERMEMORY_ROOT)

from supermemory.evolver.self_healer import SelfHealer

LOG_DIR = os.path.expanduser("~/.openclaw/workspace-mars/logs")
PID_DIR = os.path.expanduser("~/.openclaw/workspace-mars/pids")
API_PID_FILE = os.path.join(PID_DIR, "supermemory-api.pid")
HEALER_PID_FILE = os.path.join(PID_DIR, "self-healer.pid")

Path(LOG_DIR).mkdir(parents=True, exist_ok=True)
Path(PID_DIR).mkdir(parents=True, exist_ok=True)

LOG_FILE = os.path.join(LOG_DIR, "supermemory-all.log")


def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def kill_pid_file(path: str):
    if os.path.exists(path):
        try:
            pid = int(open(path).read().strip())
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, ValueError):
            pass
        os.remove(path)


def cleanup():
    log("正在停止所有服务...")
    kill_pid_file(API_PID_FILE)
    kill_pid_file(HEALER_PID_FILE)
    log("已停止")


def signal_handler(signum, frame):
    cleanup()
    sys.exit(0)


signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)


def start_api_server() -> bool:
    """启动 API Server"""
    kill_pid_file(API_PID_FILE)
    
    log("启动 SuperMemory API Server...")
    
    pid = os.fork()
    if pid == 0:
        # 子进程
        os.chdir(SUPERMEMORY_ROOT)
        os.execve(
            sys.executable,
            [sys.executable, "-c",
             f"""
import sys
sys.path.insert(0, '{SUPERMEMORY_ROOT}')
from supermemory.api import run
run()
"""],
            os.environ.copy()
        )
        os._exit(0)
    
    # 父进程
    time.sleep(2)
    
    # 验证启动
    try:
        import urllib.request
        with urllib.request.urlopen("http://localhost:8767/health", timeout=3) as resp:
            if resp.status == 200:
                with open(API_PID_FILE, "w") as f:
                    f.write(str(pid))
                log(f"API Server 启动成功 (PID {pid})")
                return True
    except:
        pass
    
    log("API Server 启动失败")
    return False


def start_self_healer_daemon():
    """Self-Healer 常驻进程"""
    kill_pid_file(HEALER_PID_FILE)
    
    log("启动 Self-Healer...")
    
    healer = SelfHealer()
    log(f"Self-Healer v{healer.VERSION} 初始化完成")
    
    while True:
        try:
            result = healer.run_cycle()
            if result.get("issues_found", 0) > 0:
                log(f"自愈检查: 发现 {result['issues_found']} 个问题, 修复 {result['issues_fixed']} 个")
                for detail in result.get("details", []):
                    log(f"  {detail}")
        except Exception as e:
            log(f"自愈检查异常: {e}")
        
        time.sleep(healer._check_interval)


def main():
    log("=" * 50)
    log("SuperMemory V4 主守护进程启动")
    log("=" * 50)
    
    # 启动 API
    if not start_api_server():
        log("API Server 启动失败，退出")
        sys.exit(1)
    
    # 启动 Self-Healer
    healer_pid = os.fork()
    if healer_pid == 0:
        os._exit(0) if os.fork() else start_self_healer_daemon()
    
    with open(HEALER_PID_FILE, "w") as f:
        f.write(str(healer_pid))
    
    log("所有服务已启动")
    log("守护进程主循环...")
    
    # 主循环：监控子进程
    while True:
        time.sleep(30)
        
        # 检查 API Server
        try:
            import urllib.request
            with urllib.request.urlopen("http://localhost:8767/health", timeout=3):
                pass
        except:
            log("检测到 API Server 离线，尝试重启...")
            start_api_server()
        
        # 检查 Self-Healer
        try:
            os.kill(healer_pid, 0)
        except OSError:
            log("检测到 Self-Healer 离线，尝试重启...")
            healer_pid = os.fork()
            if healer_pid == 0:
                os._exit(0) if os.fork() else start_self_healer_daemon()
            with open(HEALER_PID_FILE, "w") as f:
                f.write(str(healer_pid))


if __name__ == "__main__":
    main()
