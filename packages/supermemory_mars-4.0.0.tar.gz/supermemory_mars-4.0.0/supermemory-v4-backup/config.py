#!/usr/bin/env python3
"""
SuperMemory V4 - 统一配置管理
"""
import os
import json
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

DEFAULT_DATA_DIR = os.path.expanduser("~/.openclaw/workspace-shared/super-memory-data")
DEFAULT_CONFIG_DIR = os.path.expanduser("~/.openclaw/workspace-mars/projects/SuperMemory/config")


@dataclass
class SuperMemoryConfig:
    """SuperMemory 全局配置"""
    version: str = "4.0.0"
    api_port: int = 8767
    data_dir: str = DEFAULT_DATA_DIR
    
    # 健康检查
    health_check_interval: int = 300  # 秒
    auto_heal: bool = True
    auto_backup: bool = True
    backup_interval: int = 3600  # 秒
    
    # 三层记忆
    hot_ttl: int = 86400 * 7      # 7天
    warm_ttl: int = 86400 * 30    # 30天
    cold_ttl: int = 86400 * 90    # 90天
    archive_ttl: int = 86400 * 365 # 1年
    
    # 向量搜索
    vector_dim: int = 384
    vector_top_k: int = 10
    embedding_model: str = "local"
    
    # 进化
    evolution_enabled: bool = True
    evolution_interval: int = 300
    
    # Session 注入
    session_inject_enabled: bool = True
    session_inject_interval: int = 300
    
    # 日志
    log_dir: str = "{data_dir}/logs"
    log_level: str = "INFO"
    
    @classmethod
    def load(cls, config_path: str = None) -> "SuperMemoryConfig":
        if config_path is None:
            config_path = os.path.join(DEFAULT_CONFIG_DIR, "config.json")
        
        if os.path.exists(config_path):
            with open(config_path) as f:
                data = json.load(f)
                return cls(**{k: v for k, v in data.items() if hasattr(cls, k)})
        return cls()
    
    def save(self, config_path: str = None):
        if config_path is None:
            config_path = os.path.join(DEFAULT_CONFIG_DIR, "config.json")
        
        Path(config_path).parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, 'w') as f:
            json.dump(asdict(self), f, indent=2)


@dataclass
class AgentConfig:
    """单个 Agent 配置"""
    agent_id: str
    data_dir: str
    db_path: str = ""
    vector_path: str = ""
    wal_path: str = ""
    skills_db: str = ""
    
    @classmethod
    def for_agent(cls, agent_id: str, base_dir: str = None) -> "AgentConfig":
        if base_dir is None:
            base_dir = os.path.join(DEFAULT_DATA_DIR, agent_id)
        else:
            base_dir = os.path.join(base_dir, agent_id)
        
        return cls(
            agent_id=agent_id,
            data_dir=base_dir,
            db_path=os.path.join(base_dir, "memories.db"),
            vector_path=os.path.join(base_dir, "vectors.json"),
            wal_path=os.path.join(base_dir, "wal.log"),
            skills_db=os.path.join(base_dir, "skills.db"),
        )


class ConfigManager:
    """全局配置管理器"""
    
    _instance: Optional["ConfigManager"] = None
    _config: Optional[SuperMemoryConfig] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @property
    def config(self) -> SuperMemoryConfig:
        if self._config is None:
            self._config = SuperMemoryConfig.load()
        return self._config
    
    def get_agent_config(self, agent_id: str) -> AgentConfig:
        return AgentConfig.for_agent(agent_id, self.config.data_dir)
    
    def reload(self):
        self._config = SuperMemoryConfig.load()
    
    def update(self, **kwargs):
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
        self.config.save()


# 全局单例
_config_manager = ConfigManager()


def get_config() -> SuperMemoryConfig:
    return _config_manager.config


def get_agent_config(agent_id: str) -> AgentConfig:
    return _config_manager.get_agent_config(agent_id)
