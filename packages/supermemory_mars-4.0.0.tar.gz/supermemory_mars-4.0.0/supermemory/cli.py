#!/usr/bin/env python3
"""
SuperMemory V4 - 统一 CLI 入口
用法: sm <command> [options]
"""
import sys
import os
import argparse
import json
import subprocess
import urllib.request
import urllib.error

# 添加包路径
SUPERMEMORY_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SUPERMEMORY_ROOT)

from supermemory.config import get_config, get_agent_config, SuperMemoryConfig
from supermemory.core.service import SuperMemoryService
from supermemory.evolver.evolution_manager import EvolutionManager
from supermemory.evolver.self_healer import SelfHealer
import os

API_BASE = "http://localhost:8767"
DATA_DIR = os.path.expanduser("~/.openclaw/workspace-shared/super-memory-data")


def api_get(path: str) -> dict:
    try:
        with urllib.request.urlopen(f"{API_BASE}{path}", timeout=5) as resp:
            return json.loads(resp.read())
    except urllib.error.URLError:
        return {"error": "SuperMemory API 未运行，请先启动服务"}


def api_post(path: str, data: dict = None) -> dict:
    try:
        req = urllib.request.Request(
            f"{API_BASE}{path}",
            data=json.dumps(data or {}).encode("utf-8"),
            headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except urllib.error.URLError as e:
        return {"error": f"API 请求失败: {e}"}


def cmd_status(args):
    """显示系统状态"""
    print("╔════════════════════════════════════════════════╗")
    print("║         SuperMemory V4 - 系统状态              ║")
    print("╚════════════════════════════════════════════════╝")
    print()
    
    # API 健康
    health = api_get("/health")
    if "error" in health:
        print(f"❌ API Server: {health['error']}")
        return
    
    print(f"✅ API Server: {health['status']} ({health.get('version', '?')})")
    print()
    
    # 各 Agent 统计
    all_stats = api_get("/all-stats")
    
    print(f"{'Agent':<10} {'记忆数':<10} {'向量数':<10} {'热层':<8} {'暖层':<8} {'冷层':<8}")
    print("-" * 60)
    
    for agent, stats in all_stats.items():
        if isinstance(stats, dict):
            ls = stats.get("layer_stats", {})
            print(f"{agent:<10} {stats.get('memory_count', 0):<10} "
                  f"{stats.get('vector_count', 0):<10} "
                  f"{ls.get('hot', 0):<8} {ls.get('warm', 0):<8} {ls.get('cold', 0):<8}")
    
    print()


def cmd_search(args):
    """搜索记忆"""
    if not args.query:
        print("错误: 请提供搜索关键词 (-q)")
        return
    
    agent = args.agent or "mars"
    results = api_get(f"/api/{agent}/search?q={urllib.parse.quote(args.query)}&top_k={args.limit}")
    
    if "error" in results:
        print(results["error"])
        return
    
    print(f"搜索: \"{args.query}\" (找到 {results['count']} 条)")
    print()
    
    for i, r in enumerate(results.get("results", []), 1):
        importance = r.get("importance", "P2")
        layer = r.get("layer", "?")
        content = r.get("content", "")[:80]
        print(f"  [{i}] [{importance}] [{layer}] {content}...")


def cmd_add(args):
    """添加记忆"""
    if not args.content:
        print("错误: 请提供记忆内容 (-c)")
        return
    
    agent = args.agent or "mars"
    result = api_post(f"/api/{agent}/memories", {
        "content": args.content,
        "type": args.type or "general",
        "importance": args.importance or "P2",
        "tags": args.tags.split(",") if args.tags else [],
    })
    
    if "error" in result:
        print(result["error"])
    else:
        print(f"✅ 记忆已添加: {result.get('id', '?')}")


def cmd_health(args):
    """健康检查"""
    agent = args.agent or "mars"
    result = api_get(f"/api/{agent}/health")
    
    if "error" in result:
        print(f"❌ {result['error']}")
        return
    
    status = result.get("status", "?")
    icon = "✅" if status == "healthy" else "❌"
    
    print(f"{icon} 健康状态: {status}")
    print(f"   Agent: {result.get('agent_id', '?')}")
    
    integrity = result.get("integrity", {})
    print(f"   完整性: {integrity.get('total_issues', 0)} 个问题 "
          f"({integrity.get('critical', 0)} 严重, {integrity.get('warnings', 0)} 警告)")
    
    stats = result.get("stats", {})
    print(f"   记忆: {stats.get('memory_count', 0)} | "
          f"向量: {stats.get('vector_count', 0)}")


def cmd_backup(args):
    """备份"""
    agent = args.agent or "mars"
    result = api_post(f"/api/{agent}/backup")
    
    if "error" in result:
        print(f"❌ {result['error']}")
    else:
        print(f"✅ 备份完成: {result.get('backup', '?')}")


def cmd_restart(args):
    """重启服务"""
    print("正在重启 SuperMemory 服务...")
    
    # 停止
    subprocess.run(["launchctl", "bootout", f"gui/{os.getuid()}/com.marsai.supermemory-all"],
                   capture_output=True)
    
    # 启动
    result = subprocess.run(
        ["launchctl", "load", f"{os.path.expanduser('~')}/Library/LaunchAgents/com.marsai.supermemory-all.plist"],
        capture_output=True, text=True
    )
    
    if result.returncode == 0:
        print("✅ 服务已重启")
    else:
        print(f"❌ 重启失败: {result.stderr}")


def cmd_logs(args):
    """查看日志"""
    log_dir = os.path.expanduser("~/.openclaw/workspace-mars/logs")
    files = ["supermemory-api.log", "self-healer.log", "supermemory-all.stdout.log"]
    
    count = args.lines or 20
    
    for fname in files:
        fpath = os.path.join(log_dir, fname)
        if os.path.exists(fpath):
            print(f"=== {fname} (最后 {count} 行) ===")
            with open(fpath) as f:
                lines = f.readlines()
            for line in lines[-count:]:
                print(line.rstrip())
            print()


def cmd_config(args):
    """查看/修改配置"""
    config = get_config()
    
    if args.set:
        key, value = args.set.split("=", 1)
        if hasattr(config, key):
            old = getattr(config, key)
            setattr(config, key, type(old)(value) if value.isdigit() else value)
            config.save()
            print(f"✅ {key}: {old} → {getattr(config, key)}")
        else:
            print(f"❌ 未知配置项: {key}")
        return
    
    print("SuperMemory V4 配置")
    print("=" * 40)
    for key in ["version", "api_port", "health_check_interval", "auto_heal",
                "hot_ttl", "warm_ttl", "cold_ttl"]:
        val = getattr(config, key, "?")
        print(f"  {key}: {val}")


def cmd_heal(args):
    """运行自愈系统"""
    print("╔════════════════════════════════════════════════╗")
    print("║         SuperMemory V4 - 自愈系统             ║")
    print("╚════════════════════════════════════════════════╝")
    print()
    
    try:
        sh = SelfHealer({"data_dir": DATA_DIR, "agents": ["mars", "chen", "wei", "ying"]})
        print(f"版本: v{sh.version}")
        print(f"检查器: {len(sh.CHECKERS)} 个")
        print(f"修复器: {len(sh.FIXERS)} 个")
        print()
        
        result = sh.run_healing_cycle()
        print(f"自愈结果:")
        print(f"  发现问题: {result['issues_found']}")
        print(f"  修复问题: {result['issues_fixed']}")
        print(f"  执行检查: {len(result['checks_performed'])} 项")
        if result['errors']:
            print(f"  错误: {result['errors']}")
        
        status = sh.get_status()
        print()
        print(f"技能注册:")
        for mod, count in status['registry']['by_module'].items():
            print(f"  {mod}: {count} 个")
        
        unhealthy = status['registry']['unhealthy_count']
        print()
        if unhealthy == 0:
            print("✅ 所有技能健康")
        else:
            print(f"⚠️  {unhealthy} 个技能不健康")
            
    except Exception as e:
        print(f"❌ 自愈系统错误: {e}")
        import traceback
        traceback.print_exc()


def cmd_evolve(args):
    """运行进化系统"""
    print("╔════════════════════════════════════════════════╗")
    print("║         SuperMemory V4 - 进化系统             ║")
    print("╚════════════════════════════════════════════════╝")
    print()
    
    try:
        em = EvolutionManager({"data_dir": DATA_DIR})
        print(f"版本: v{em.VERSION}")
        print()
        
        print("已注册进化器:")
        for e in em.list_evolvers():
            enabled = "✅" if e['enabled'] else "❌"
            print(f"  {enabled} {e['name']} (v{e['version']}) [{e['stats'].get('evolution_count', 0)}次进化]")
        
        print()
        print("运行进化...")
        results = em.evolve_all()
        print(f"进化完成: {len(results)} 个进化器执行")
        for r in results:
            status = "✅" if r.success else "❌"
            print(f"  {status} {r.evolver_name}: {r.message}")
        
        print()
        hc = em.health_check()
        print(f"系统健康: {hc['status']}")
        print(f"技能状态: {hc['registry']['healthy_ratio']}")
        
    except Exception as e:
        print(f"❌ 进化系统错误: {e}")
        import traceback
        traceback.print_exc()


def main():
    parser = argparse.ArgumentParser(
        description="SuperMemory V4 - AI 记忆系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # status
    subparsers.add_parser("status", help="显示系统状态")
    
    # search
    p_search = subparsers.add_parser("search", help="搜索记忆")
    p_search.add_argument("-q", dest="query", help="搜索关键词")
    p_search.add_argument("-a", dest="agent", help="Agent ID (默认 mars)")
    p_search.add_argument("-l", dest="limit", type=int, default=10, help="结果数量")
    
    # add
    p_add = subparsers.add_parser("add", help="添加记忆")
    p_add.add_argument("-c", dest="content", required=True, help="记忆内容")
    p_add.add_argument("-a", dest="agent", help="Agent ID")
    p_add.add_argument("-t", dest="type", default="general", help="类型")
    p_add.add_argument("-i", dest="importance", default="P2", help="重要性")
    p_add.add_argument("--tags", dest="tags", help="标签 (逗号分隔)")
    
    # health
    p_health = subparsers.add_parser("health", help="健康检查")
    p_health.add_argument("-a", dest="agent", default="mars", help="Agent ID")
    
    # backup
    p_backup = subparsers.add_parser("backup", help="备份")
    p_backup.add_argument("-a", dest="agent", default="mars", help="Agent ID")
    
    # restart
    subparsers.add_parser("restart", help="重启服务")
    
    # logs
    p_logs = subparsers.add_parser("logs", help="查看日志")
    p_logs.add_argument("-n", dest="lines", type=int, default=20, help="行数")
    
    # config
    p_config = subparsers.add_parser("config", help="配置管理")
    p_config.add_argument("--set", dest="set", help="设置配置 (key=value)")
    
    # heal
    subparsers.add_parser("heal", help="运行自愈系统")
    
    # evolve
    subparsers.add_parser("evolve", help="运行进化系统")
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        return
    
    commands = {
        "status": cmd_status,
        "search": cmd_search,
        "add": cmd_add,
        "health": cmd_health,
        "backup": cmd_backup,
        "restart": cmd_restart,
        "logs": cmd_logs,
        "config": cmd_config,
        "heal": cmd_heal,
        "evolve": cmd_evolve,
    }
    
    commands[args.command](args)


if __name__ == "__main__":
    main()
