"""记忆版本管理"""
import json
from datetime import datetime
from typing import List, Dict, Optional
from pathlib import Path

class MemoryVersion:
    """记忆版本"""
    
    def __init__(self, version_id: str, memory_id: str, content: str, 
                 metadata: dict = None, created_at: str = None):
        self.version_id = version_id
        self.memory_id = memory_id
        self.content = content
        self.metadata = metadata or {}
        self.created_at = created_at or datetime.now().isoformat()
    
    def to_dict(self) -> dict:
        return {
            "version_id": self.version_id,
            "memory_id": self.memory_id,
            "content": self.content,
            "metadata": self.metadata,
            "created_at": self.created_at
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> 'MemoryVersion':
        return cls(
            d["version_id"],
            d["memory_id"],
            d["content"],
            d.get("metadata"),
            d.get("created_at")
        )

class MemoryVersionControl:
    """
    记忆版本控制系统
    每次修改保存快照，支持回滚
    """
    
    def __init__(self, storage_path: str = "./data/memory_versions.json"):
        self.storage_path = storage_path
        Path(storage_path).parent.mkdir(parents=True, exist_ok=True)
        self._versions = {}  # memory_id -> [versions]
        self._load()
    
    def _load(self):
        """加载版本数据"""
        if Path(self.storage_path).exists():
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for mem_id, versions in data.get("versions", {}).items():
                    self._versions[mem_id] = [
                        MemoryVersion.from_dict(v) for v in versions
                    ]
    
    def _save(self):
        """保存版本数据"""
        data = {
            "versions": {
                mem_id: [v.to_dict() for v in versions]
                for mem_id, versions in self._versions.items()
            }
        }
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def save_version(self, memory_id: str, content: str, metadata: dict = None) -> str:
        """
        保存记忆版本
        返回: version_id
        """
        if memory_id not in self._versions:
            self._versions[memory_id] = []
        
        # 计算版本号
        version_num = len(self._versions[memory_id]) + 1
        version_id = f"{memory_id}_v{version_num}"
        
        version = MemoryVersion(version_id, memory_id, content, metadata)
        self._versions[memory_id].append(version)
        
        # 限制版本数量（最多保留50个）
        if len(self._versions[memory_id]) > 50:
            self._versions[memory_id] = self._versions[memory_id][-50:]
        
        self._save()
        return version_id
    
    def get_history(self, memory_id: str) -> List[MemoryVersion]:
        """获取记忆的版本历史"""
        return self._versions.get(memory_id, [])
    
    def get_version(self, memory_id: str, version_id: str) -> Optional[MemoryVersion]:
        """获取特定版本"""
        versions = self._versions.get(memory_id, [])
        for v in versions:
            if v.version_id == version_id:
                return v
        return None
    
    def rollback(self, memory_id: str, version_id: str) -> Optional[str]:
        """
        回滚到指定版本
        返回: 回滚后的内容
        """
        version = self.get_version(memory_id, version_id)
        if not version:
            return None
        
        # 保存当前版本作为备份
        current = self._versions.get(memory_id, [])
        if current:
            self.save_version(
                memory_id + "_rollback_backup",
                current[-1].content,
                {"rolled_back_to": version_id}
            )
        
        return version.content
    
    def get_latest(self, memory_id: str) -> Optional[MemoryVersion]:
        """获取最新版本"""
        versions = self._versions.get(memory_id, [])
        return versions[-1] if versions else None
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        total_versions = sum(len(v) for v in self._versions.values())
        return {
            "total_memories": len(self._versions),
            "total_versions": total_versions,
            "avg_versions_per_memory": total_versions / len(self._versions) if self._versions else 0
        }
    
    def compare_versions(self, memory_id: str, v1_id: str, v2_id: str) -> Dict:
        """比较两个版本的差异"""
        v1 = self.get_version(memory_id, v1_id)
        v2 = self.get_version(memory_id, v2_id)
        
        if not v1 or not v2:
            return {"error": "Version not found"}
        
        # 简单diff实现
        lines1 = v1.content.split('\n')
        lines2 = v2.content.split('\n')
        
        return {
            "version1": v1_id,
            "version2": v2_id,
            "v1_lines": len(lines1),
            "v2_lines": len(lines2),
            "v1_time": v1.created_at,
            "v2_time": v2.created_at,
            "content_changed": v1.content != v2.content
        }
