"""
Conflict Resolver - Git同步冲突解决策略
"""
from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass


@dataclass
class ConflictRecord:
    """冲突记录"""
    local_version: Dict[str, Any]
    remote_version: Dict[str, Any]
    conflict_fields: List[str]
    resolution: Optional[str] = None
    resolved_at: Optional[float] = None


class ConflictResolver:
    """
    记忆同步冲突解决器
    
    支持策略:
    - latest_wins: 最新版本优先
    - merge: 智能合并（不同字段合并，相同字段最新优先）
    - keep_local: 保留本地版本
    - keep_remote: 保留远程版本
    - manual: 人工介入
    """
    
    STRATEGIES = ['latest_wins', 'merge', 'keep_local', 'keep_remote', 'manual']
    
    def __init__(self, default_strategy: str = 'latest_wins'):
        self.default_strategy = default_strategy
        self.conflict_history: List[ConflictRecord] = []
    
    def resolve(self, local: Dict[str, Any], remote: Dict[str, Any], 
                strategy: str = None) -> Dict[str, Any]:
        """
        解决冲突
        
        Args:
            local: 本地版本
            remote: 远程版本
            strategy: 解决策略，默认使用配置的default_strategy
        
        Returns:
            解决后的版本
        """
        strategy = strategy or self.default_strategy
        
        if strategy == 'latest_wins':
            return self._resolve_latest_wins(local, remote)
        elif strategy == 'merge':
            return self._resolve_merge(local, remote)
        elif strategy == 'keep_local':
            return local
        elif strategy == 'keep_remote':
            return remote
        elif strategy == 'manual':
            return self._create_unresolved(local, remote)
        else:
            return self._resolve_latest_wins(local, remote)
    
    def _resolve_latest_wins(self, local: Dict[str, Any], remote: Dict[str, Any]) -> Dict[str, Any]:
        """最新版本优先"""
        local_time = local.get('updated_at', 0)
        remote_time = remote.get('updated_at', 0)
        
        if isinstance(local_time, str):
            try:
                local_time = datetime.fromisoformat(local_time).timestamp()
            except:
                local_time = 0
        
        if isinstance(remote_time, str):
            try:
                remote_time = datetime.fromisoformat(remote_time).timestamp()
            except:
                remote_time = 0
        
        winner = local if local_time >= remote_time else remote
        
        # 记录冲突解决
        self._record_conflict(local, remote, ['*'], 'latest_wins')
        
        return {**winner, 'conflict_resolved': True}
    
    def _resolve_merge(self, local: Dict[str, Any], remote: Dict[str, Any]) -> Dict[str, Any]:
        """智能合并 - 不同字段合并，相同字段最新优先"""
        merged = {}
        all_fields = set(local.keys()) | set(remote.keys())
        conflict_fields = []
        
        for field in all_fields:
            if field not in remote:
                merged[field] = local[field]
            elif field not in local:
                merged[field] = remote[field]
            elif local[field] == remote[field]:
                merged[field] = local[field]
            else:
                # 冲突 - 比较时间
                conflict_fields.append(field)
                local_time = self._get_timestamp(local, field)
                remote_time = self._get_timestamp(remote, field)
                
                if local_time >= remote_time:
                    merged[field] = local[field]
                else:
                    merged[field] = remote[field]
        
        self._record_conflict(local, remote, conflict_fields, 'merge')
        
        return {**merged, 'conflict_resolved': True, 'merged_fields': list(all_fields)}
    
    def _get_timestamp(self, record: Dict[str, Any], field: str) -> float:
        """获取记录的时间戳"""
        time_fields = ['updated_at', 'created_at', 'timestamp']
        for tf in time_fields:
            if tf in record:
                val = record[tf]
                if isinstance(val, str):
                    try:
                        return datetime.fromisoformat(val).timestamp()
                    except:
                        return 0
                elif isinstance(val, (int, float)):
                    return val
        return 0
    
    def _create_unresolved(self, local: Dict[str, Any], remote: Dict[str, Any]) -> Dict[str, Any]:
        """创建未解决状态（需人工介入）"""
        self._record_conflict(local, remote, list(set(local.keys()) & set(remote.keys())), 'manual')
        
        return {
            '_conflict': True,
            'local_version': local,
            'remote_version': remote,
            'conflict_fields': list(set(local.keys()) & set(remote.keys())),
        }
    
    def _record_conflict(self, local: Dict[str, Any], remote: Dict[str, Any],
                        conflict_fields: List[str], resolution: str):
        """记录冲突解决历史"""
        record = ConflictRecord(
            local_version=local,
            remote_version=remote,
            conflict_fields=conflict_fields,
            resolution=resolution,
            resolved_at=datetime.now().timestamp()
        )
        self.conflict_history.append(record)
    
    def get_conflict_history(self) -> List[Dict[str, Any]]:
        """获取冲突解决历史"""
        return [
            {
                'local_version': r.local_version.get('id', 'unknown'),
                'remote_version': r.remote_version.get('id', 'unknown'),
                'conflict_fields': r.conflict_fields,
                'resolution': r.resolution,
                'resolved_at': r.resolved_at
            }
            for r in self.conflict_history
        ]
    
    def auto_resolve_batch(self, conflicts: List[tuple]) -> List[Dict[str, Any]]:
        """批量自动解决冲突"""
        results = []
        for local, remote in conflicts:
            resolved = self.resolve(local, remote)
            results.append(resolved)
        return results
