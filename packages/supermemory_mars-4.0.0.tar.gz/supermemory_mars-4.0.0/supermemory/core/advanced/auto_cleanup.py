"""
Auto Cleanup - 自动清理和完整性校验
"""
import os
import json
import hashlib
from datetime import datetime
from typing import Dict, List


class MemoryIntegrityChecker:
    """记忆完整性校验器"""
    
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.db_path = f"{data_dir}/memories.db"
        self.integrity_log = f"{data_dir}/integrity_check.json"
    
    def check(self) -> Dict:
        """执行完整性检查"""
        import sqlite3
        
        results = {
            'timestamp': datetime.now().isoformat(),
            'status': 'ok',
            'issues': [],
            'stats': {}
        }
        
        if not os.path.exists(self.db_path):
            results['status'] = 'error'
            results['issues'].append('数据库文件不存在')
            return results
        
        # 检查数据库文件
        db_size = os.path.getsize(self.db_path)
        results['stats']['db_size'] = db_size
        
        # 检查表结构
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        
        try:
            c.execute("SELECT COUNT(*) FROM memories")
            count = c.fetchone()[0]
            results['stats']['memory_count'] = count
            
            c.execute("SELECT COUNT(*) FROM memories WHERE content IS NULL OR content = ''")
            empty = c.fetchone()[0]
            if empty > 0:
                results['issues'].append(f'发现{empty}条空内容记忆')
            
            # 检查重复ID
            c.execute("SELECT id, COUNT(*) FROM memories GROUP BY id HAVING COUNT(*) > 1")
            dupes = c.fetchall()
            if dupes:
                results['issues'].append(f'发现{len(dupes)}个重复ID')
            
        except Exception as e:
            results['status'] = 'error'
            results['issues'].append(f'数据库错误: {e}')
        finally:
            conn.close()
        
        # 检查WAL文件 (JSONL格式 - 每行一个JSON对象)
        wal_path = f"{self.data_dir}/wal.json"
        if os.path.exists(wal_path):
            try:
                wal_count = 0
                with open(wal_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            json.loads(line)  # 验证每行都是有效JSON
                            wal_count += 1
                results['stats']['wal_count'] = wal_count
                # 检查是否需要归档 (超过1000条)
                if wal_count > 1000:
                    results['issues'].append(f'WAL文件已达{wal_count}条，建议归档')
            except json.JSONDecodeError as e:
                results['issues'].append(f'WAL文件部分损坏: {e}')
            except Exception as e:
                results['issues'].append(f'WAL文件检查失败: {e}')
        
        if results['issues']:
            results['status'] = 'warning'
        
        # 保存检查结果
        self._save_results(results)
        
        return results
    
    def _save_results(self, results: Dict):
        """保存检查结果"""
        history = []
        if os.path.exists(self.integrity_log):
            try:
                with open(self.integrity_log, 'r') as f:
                    history = json.load(f)
            except:
                history = []
        
        history.append(results)
        
        # 只保留最近100次检查
        history = history[-100:]
        
        with open(self.integrity_log, 'w') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)


class WorkingBufferCleaner:
    """Working Buffer清理器"""
    
    def __init__(self, memory_dir: str):
        self.memory_dir = memory_dir
        self.buffer_path = f"{memory_dir}/working-buffer/buffer.md"
        self.archive_path = f"{memory_dir}/.archive/working-buffer"
    
    def should_clean(self) -> bool:
        """检查是否需要清理"""
        if not os.path.exists(self.buffer_path):
            return False
        
        # 检查文件大小
        size = os.path.getsize(self.buffer_path)
        if size > 100 * 1024:  # > 100KB
            return True
        
        # 检查最后修改时间
        mtime = os.path.getmtime(self.buffer_path)
        age_hours = (datetime.now().timestamp() - mtime) / 3600
        
        return age_hours > 24  # 超过24小时
    
    def clean(self) -> Dict:
        """执行清理"""
        if not os.path.exists(self.buffer_path):
            return {'status': 'no_buffer'}
        
        os.makedirs(self.archive_path, exist_ok=True)
        
        # 读取buffer内容
        with open(self.buffer_path, 'r') as f:
            content = f.read()
        
        # 生成归档文件名
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        archive_file = f"{self.archive_path}/buffer_{timestamp}.md"
        
        # 保存归档
        with open(archive_file, 'w') as f:
            f.write(content)
        
        # 清空buffer
        with open(self.buffer_path, 'w') as f:
            f.write(f"# Working Buffer - 归档于 {timestamp}\n\n")
        
        return {
            'status': 'cleaned',
            'archived_to': archive_file,
            'size': len(content)
        }


class AutoSummarizer:
    """自动摘要器 - 当记忆超过阈值时自动生成摘要"""
    
    def __init__(self, memory_store, summarizer):
        self.store = memory_store
        self.summarizer = summarizer
        self.threshold = 500  # 500字符以上需要摘要
    
    def auto_summarize_long_memories(self) -> List[Dict]:
        """自动摘要长记忆"""
        import sqlite3
        
        results = []
        
        # 获取所有记忆
        conn = sqlite3.connect(self.store.db_path)
        c = conn.cursor()
        
        c.execute("SELECT id, content, metadata FROM memories WHERE content IS NOT NULL")
        memories = c.fetchall()
        
        for mem_id, content, metadata in memories:
            if content and len(content) > self.threshold:
                # 检查是否已有摘要
                meta = json.loads(metadata or '{}')
                if 'summary' not in meta:
                    # 生成摘要
                    summary = self.summarizer.summarize(content, max_length=100)
                    
                    # 更新记忆
                    meta['summary'] = summary
                    meta['original_length'] = len(content)
                    
                    c.execute(
                        "UPDATE memories SET metadata=? WHERE id=?",
                        (json.dumps(meta), mem_id)
                    )
                    
                    results.append({
                        'id': mem_id,
                        'summary': summary,
                        'original_length': len(content)
                    })
        
        conn.commit()
        conn.close()
        
        return results
