"""混合搜索：结合向量语义 + BM25关键词"""
import math
from collections import Counter
from typing import List, Tuple, Dict, Any
import re

class BM25:
    """BM25关键词搜索算法"""
    
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.doc_lengths = []
        self.avgdl = 0
        self.doc_freqs = []  # 每个文档的词频
        self.idf = {}        # 逆文档频率
        self.doc_count = 0
    
    def index(self, documents: List[str]):
        """建立BM25索引"""
        self.doc_count = len(documents)
        self.doc_lengths = []
        self.doc_freqs = []
        total_len = 0
        
        # 统计文档频率
        df = Counter()
        
        for doc in documents:
            # 分词
            words = self._tokenize(doc)
            self.doc_lengths.append(len(words))
            self.doc_freqs.append(Counter(words))
            total_len += len(words)
            
            # 统计词频
            for word in set(words):
                df[word] += 1
        
        self.avgdl = total_len / self.doc_count if self.doc_count > 0 else 1
        
        # 计算IDF
        for word, freq in df.items():
            self.idf[word] = math.log((self.doc_count - freq + 0.5) / (freq + 0.5) + 1)
    
    def _tokenize(self, text: str) -> List[str]:
        """简单分词"""
        text = text.lower()
        words = re.findall(r'\w+', text)
        return [w for w in words if len(w) > 1]
    
    def search(self, query: str, top_k: int = 10) -> List[Tuple[int, float]]:
        """搜索，返回[(doc_index, score)]"""
        query_words = self._tokenize(query)
        
        scores = []
        for i, doc_tf in enumerate(self.doc_freqs):
            score = 0.0
            dl = self.doc_lengths[i]
            
            for word in query_words:
                if word not in self.idf:
                    continue
                
                tf = doc_tf.get(word, 0)
                idf = self.idf[word]
                
                # BM25公式
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (1 - self.b + self.b * dl / self.avgdl)
                score += idf * numerator / denominator
            
            scores.append((i, score))
        
        # 按分数排序
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]


class HybridSearch:
    """
    混合搜索：RRF融合向量搜索 + BM25
    """
    
    def __init__(self, memory_store, vector_store, alpha: float = 0.7):
        self.memory_store = memory_store
        self.vector_store = vector_store
        self.alpha = alpha  # 向量权重，1-alpha是BM25权重
        self.bm25 = None
        self._rebuild_bm25()
    
    def _rebuild_bm25(self):
        """重建BM25索引"""
        memories = self.memory_store.search(limit=10000)
        docs = [m.content for m in memories]
        self.bm25 = BM25()
        self.bm25.index(docs)
        self._memories = memories  # 缓存
    
    def search(self, query: str, top_k: int = 10, 
               memory_type: str = None, importance: str = None) -> List[Dict[str, Any]]:
        """
        混合搜索
        返回: [{"memory": Memory, "score": float, "vector_score": float, "bm25_score": float}, ...]
        """
        # 1. BM25关键词搜索
        bm25_results = self.bm25.search(query, top_k * 3)
        
        # 2. 向量语义搜索 (需要query embedding)
        # 简化：使用query的hash作为伪embedding演示
        # 实际应该调用 embedding API
        query_embedding = self._generate_query_embedding(query)
        vector_results = self.vector_store.search(query_embedding, top_k * 3)
        
        # 3. RRF融合
        fused = self._rrf_fusion(vector_results, bm25_results, k=60)
        
        # 4. 构建结果
        results = []
        seen_ids = set()
        
        for doc_idx, bm25_score in bm25_results:
            if doc_idx >= len(self._memories):
                continue
            memory = self._memories[doc_idx]
            
            # 类型/重要性过滤
            if memory_type and memory.type != memory_type:
                continue
            if importance and memory.importance != importance:
                continue
            
            if memory.id in seen_ids:
                continue
            seen_ids.add(memory.id)
            
            # 获取向量分数
            vector_score = 0.0
            for vid, vs in vector_results:
                if vid == memory.id:
                    vector_score = vs
                    break
            
            # 计算融合分数
            fused_score = self.alpha * vector_score + (1 - self.alpha) * bm25_score
            
            results.append({
                "memory": memory,
                "score": fused_score,
                "vector_score": vector_score,
                "bm25_score": bm25_score
            })
        
        # 排序
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]
    
    def _rrf_fusion(self, vector_results: List[Tuple], bm25_results: List[Tuple], k=60):
        """RRF融合算法"""
        scores = {}
        
        # 向量结果
        for rank, (doc_id, score) in enumerate(vector_results):
            scores[doc_id] = scores.get(doc_id, 0) + score * self.alpha + (1 / (k + rank + 1))
        
        # BM25结果
        for rank, (doc_idx, score) in enumerate(bm25_results):
            # 使用内存索引作为doc_id
            scores[f"idx_{doc_idx}"] = scores.get(f"idx_{doc_idx}", 0) + score * (1 - self.alpha) + (1 / (k + rank + 1))
        
        return scores
    
    def _generate_query_embedding(self, text: str) -> List[float]:
        """使用 Ollama nomic-embed-text 生成真实语义向量"""
        import urllib.request
        import json
        try:
            req = urllib.request.Request(
                'http://localhost:11434/api/embeddings',
                data=json.dumps({'model': 'nomic-embed-text', 'prompt': text[:1000]}).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                result = json.loads(response.read())
                embedding = result.get('embedding', [])
                if embedding:
                    return embedding
        except Exception as e:
            print(f"[HybridSearch] Ollama embedding失败: {e}, 回退到关键词")
        # 回退: 返回None让调用方使用纯BM25
        return None
    
    def _text_to_embedding(self, text: str) -> List[float]:
        """将文本转为embedding向量"""
        emb = self._generate_query_embedding(text)
        if emb:
            return emb
        # 紧急回退: 随机向量(不要用MD5，破坏余弦相似度)
        import numpy as np
        return np.random.randn(768).astype(np.float32).tolist()
