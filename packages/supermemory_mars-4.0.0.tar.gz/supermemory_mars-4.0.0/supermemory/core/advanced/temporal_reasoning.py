"""时序推理引擎：支持自然语言时间表达"""
import re
from datetime import datetime, timedelta
from typing import Optional, Tuple, List, Dict
from calendar import weekday

class TemporalReasoning:
    """
    时序推理引擎
    支持: 今天/昨天/上周三/一个月前/去年 等自然语言
    """
    
    # 时间模式定义
    PATTERNS = [
        # 绝对时间
        (r'今天', lambda: (_today_start(), _today_end())),
        (r'昨天', lambda: (_yesterday_start(), _yesterday_end())),
        (r'前天', lambda: (_days_ago_start_end(2))),
        (r'后天', lambda: (_days_later_start_end(1))),
        (r'大后天', lambda: (_days_later_start_end(2))),
        
        # 本周/上周
        (r'这周', lambda: (_this_week_range())),
        (r'本周', lambda: (_this_week_range())),
        (r'上周', lambda: (_last_week_range())),
        (r'下周', lambda: (_next_week_range())),
        
        # 本月/上月
        (r'本月', lambda: (_this_month_range())),
        (r'上月', lambda: (_last_month_range())),
        (r'下月', lambda: (_next_month_range())),
        
        # 今年/去年
        (r'今年', lambda: (_this_year_range())),
        (r'去年', lambda: (_last_year_range())),
        
        # 星期几
        (r'周一', lambda: (_day_of_week_range(0))),
        (r'周二', lambda: (_day_of_week_range(1))),
        (r'周三', lambda: (_day_of_week_range(2))),
        (r'周四', lambda: (_day_of_week_range(3))),
        (r'周五', lambda: (_day_of_week_range(4))),
        (r'周六', lambda: (_day_of_week_range(5))),
        (r'周日', lambda: (_day_of_week_range(6))),
        (r'星期[一二三四五六日]', lambda m: (_day_of_week_range(_cn_weekday(m.group(0))))),
        
        # 相对时间
        (r'一个月前', lambda: (_days_ago_start_end(30))),
        (r'三个月前', lambda: (_days_ago_start_end(90))),
        (r'半年前', lambda: (_days_ago_start_end(180))),
        (r'一年前', lambda: (_days_ago_start_end(365))),
        (r'\d+天前', lambda m: (_days_ago_start_end(int(re.search(r'\d+', m.group(0)).group())))),
        (r'\d+天后', lambda m: (_days_later_start_end(int(re.search(r'\d+', m.group(0)).group())))),
        (r'\d+周前', lambda m: (_days_ago_start_end(int(re.search(r'\d+', m.group(0)).group()) * 7))),
        (r'\d+个月前', lambda m: (_days_ago_start_end(int(re.search(r'\d+', m.group(0)).group()) * 30))),
    ]
    
    def __init__(self):
        self._compiled_patterns = [(re.compile(p, re.IGNORECASE), resolver) for p, resolver in self.PATTERNS]
    
    def parse(self, text: str) -> Optional[Tuple[datetime, datetime]]:
        """
        解析时间表达式，返回(start, end)
        如果无法解析，返回None
        """
        for pattern, resolver in self._compiled_patterns:
            match = pattern.search(text)
            if match:
                try:
                    return resolver()
                except:
                    continue
        return None
    
    def extract_time_references(self, text: str) -> List[Dict[str, any]]:
        """
        提取文本中所有时间引用
        返回: [{"text": "上周三", "range": (start, end), "matched": "上周"}]
        """
        results = []
        
        for pattern, resolver in self._compiled_patterns:
            for match in pattern.finditer(text):
                try:
                    time_range = resolver()
                    results.append({
                        "text": match.group(0),
                        "matched": pattern.pattern,
                        "range": time_range
                    })
                except:
                    continue
        
        return results
    
    def filter_by_time(self, items: List[Dict], time_field: str = "created_at") -> List[Dict]:
        """
        根据时间范围过滤列表
        items: [{"created_at": "2026-03-25T10:00:00", ...}, ...]
        返回最近时间的项目
        """
        now = datetime.now()
        recent_items = []
        
        for item in items:
            if time_field not in item:
                continue
            
            try:
                item_time = datetime.fromisoformat(item[time_field])
                
                # 如果解析出的时间在项目时间之后，说明项目是"过去的"
                # 这个方法需要传入具体的时间范围才能过滤
                recent_items.append(item)
            except:
                continue
        
        return recent_items


# 辅助函数
def _today_start():
    now = datetime.now()
    return now.replace(hour=0, minute=0, second=0, microsecond=0)

def _today_end():
    now = datetime.now()
    return now.replace(hour=23, minute=59, second=59, microsecond=999999)

def _yesterday_start():
    return (_today_start() - timedelta(days=1))

def _yesterday_end():
    return (_today_end() - timedelta(days=1))

def _days_ago_start_end(days: int):
    start = (_today_start() - timedelta(days=days))
    end = (_today_start() - timedelta(seconds=1))
    return start, end

def _days_later_start_end(days: int):
    start = _today_end() + timedelta(seconds=1)
    end = (_today_end() + timedelta(days=days))
    return start, end

def _this_week_range():
    now = datetime.now()
    days_since_monday = now.weekday()
    monday = now - timedelta(days=days_since_monday)
    sunday = monday + timedelta(days=6)
    return (
        monday.replace(hour=0, minute=0, second=0, microsecond=0),
        sunday.replace(hour=23, minute=59, second=59, microsecond=999999)
    )

def _last_week_range():
    this_week_start, _ = _this_week_range()
    last_week_end = this_week_start - timedelta(seconds=1)
    last_week_start = last_week_end - timedelta(days=6)
    return last_week_start, last_week_end

def _next_week_range():
    _, this_week_end = _this_week_range()
    next_week_start = this_week_end + timedelta(seconds=1)
    next_week_end = next_week_start + timedelta(days=7)
    return next_week_start, next_week_end

def _this_month_range():
    now = datetime.now()
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if now.month == 12:
        end = now.replace(year=now.year+1, month=1, day=1, hour=23, minute=59, second=59) - timedelta(seconds=1)
    else:
        end = now.replace(month=now.month+1, day=1, hour=0, minute=0, second=0) - timedelta(seconds=1)
    return start, end

def _last_month_range():
    now = datetime.now()
    if now.month == 1:
        start = now.replace(year=now.year-1, month=12, day=1, hour=0, minute=0, second=0)
    else:
        start = now.replace(month=now.month-1, day=1, hour=0, minute=0, second=0)
    this_month_start, _ = _this_month_range()
    end = this_month_start - timedelta(seconds=1)
    return start, end

def _next_month_range():
    this_month_start, this_month_end = _this_month_range()
    start = this_month_end + timedelta(seconds=1)
    if this_month_start.month == 12:
        end = this_month_start.replace(year=this_month_start.year+1, month=1) - timedelta(seconds=1)
    else:
        end = this_month_start.replace(month=this_month_start.month+1) - timedelta(seconds=1)
    return start, end

def _this_year_range():
    now = datetime.now()
    start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
    end = now.replace(year=now.year+1, month=1, day=1, hour=0, minute=0, second=0) - timedelta(seconds=1)
    return start, end

def _last_year_range():
    now = datetime.now()
    start = now.replace(year=now.year-1, month=1, day=1, hour=0, minute=0, second=0)
    end = now.replace(year=now.year, month=1, day=1, hour=0, minute=0, second=0) - timedelta(seconds=1)
    return start, end

def _day_of_week_range(weekday: int):
    """weekday: 0=周一, 6=周日"""
    now = datetime.now()
    days_since_target = (now.weekday() - weekday) % 7
    target_day = now - timedelta(days=days_since_target)
    return (
        target_day.replace(hour=0, minute=0, second=0, microsecond=0),
        target_day.replace(hour=23, minute=59, second=59, microsecond=999999)
    )

def _cn_weekday(text: str) -> int:
    """将中文星期转为数字"""
    mapping = {"一": 0, "二": 1, "三": 2, "四": 3, "五": 4, "六": 5, "日": 6}
    for char, num in mapping.items():
        if char in text:
            return num
    return 0
