"""检索反馈闭环 - 对标Mem0"""
import json
import time
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from pathlib import Path


class RetrievalFeedback:
    """
    检索反馈闭环系统
    记录用户对检索结果的行为，优化后续检索权重
    """
    
    def __init__(self, storage_path: str = "./data/retrieval_feedback.json"):
        self.storage_path = storage_path
        Path(storage_path).parent.mkdir(parents=True, exist_ok=True)
        self._load()
    
    def _load(self):
        """加载反馈数据"""
        if Path(self.storage_path).exists():
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
        else:
            self.data = {"feedbacks": [], "memory_weights": {}}
    
    def _save(self):
        """保存反馈数据"""
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def record(self, query: str, results: List[str], 
               user_action: str, memory_id: str = None):
        """
        记录用户行为
        
        Args:
            query: 搜索查询
            results: 返回的记忆ID列表 [id1, id2, ...]
            user_action: click/dismiss/refine/accept
            memory_id: 用户点击的记忆ID（如果是click）
        """
        feedback = {
            "id": f"{time.time()}-{len(self.data['feedbacks'])}",
            "query": query,
            "results": results,
            "action": user_action,
            "selected_memory": memory_id,
            "timestamp": datetime.now().isoformat()
        }
        
        self.data["feedbacks"].append(feedback)
        
        # 更新记忆权重
        if user_action == "click" and memory_id:
            self._update_memory_weight(memory_id, positive=True)
        elif user_action == "dismiss" and memory_id:
            self._update_memory_weight(memory_id, positive=False)
        
        self._save()
    
    def _update_memory_weight(self, memory_id: str, positive: bool):
        """更新记忆的检索权重"""
        if memory_id not in self.data["memory_weights"]:
            self.data["memory_weights"][memory_id] = {
                "positive": 0,
                "total": 0,
                "weight": 1.0
            }
        
        weights = self.data["memory_weights"][memory_id]
        weights["total"] += 1
        
        if positive:
            weights["positive"] += 1
        
        # 计算新权重 (贝叶斯平均)
        alpha = 5  # 伪样本数
        beta = 5
        weights["weight"] = (weights["positive"] + alpha) / (weights["total"] + alpha + beta)
        
        # 确保权重在0.1-2.0范围内
        weights["weight"] = max(0.1, min(2.0, weights["weight"]))
    
    def get_memory_weight(self, memory_id: str) -> float:
        """获取记忆的检索权重"""
        if memory_id in self.data["memory_weights"]:
            return self.data["memory_weights"][memory_id]["weight"]
        return 1.0  # 默认权重
    
    def get_relevant_memories(self, query: str, top_k: int = 10) -> List[Tuple[str, float]]:
        """
        根据历史反馈获取与查询相关的记忆
        用于结果重排序
        """
        # 简单实现：返回历史上被点击过且包含query关键词的记忆
        relevant = []
        
        for mem_id, weights in self.data["memory_weights"].items():
            if weights["total"] >= 1 and weights["weight"] > 1.0:
                relevant.append((mem_id, weights["weight"]))
        
        relevant.sort(key=lambda x: x[1], reverse=True)
        return relevant[:top_k]
    
    def get_stats(self) -> Dict:
        """获取反馈统计"""
        total = len(self.data["feedbacks"])
        if total == 0:
            return {"total": 0, "click_rate": 0, "avg_weight": 1.0}
        
        clicks = sum(1 for f in self.data["feedbacks"] if f["action"] == "click")
        
        weights = [w["weight"] for w in self.data["memory_weights"].values()]
        avg_weight = sum(weights) / len(weights) if weights else 1.0
        
        return {
            "total": total,
            "click_rate": clicks / total,
            "avg_weight": avg_weight,
            "tracked_memories": len(self.data["memory_weights"])
        }
    def get_recent_feedback(self, hours: int = 24, limit: int = 20) -> List[Dict]:
        """
        获取最近 N 小时的反馈记录
        
        Args:
            hours: 最近多少小时
            limit: 返回最大数量
        """
        cutoff = time.time() - (hours * 3600)
        feedbacks = self.data.get("feedbacks", [])
        recent = [
            f for f in feedbacks
            if datetime.fromisoformat(f["timestamp"]).timestamp() > cutoff
        ]
        return recent[-limit:]
