"""
Context Manager - 主动式上下文管理
===================================
不依赖 LCM 自动压缩，自主管理 context 生命周期

工作原理：
1. 实时监控 token 使用量（通过 OpenClaw API 或 session info）
2. 当 context 达到 70% 时，主动分流旧消息到 SuperMemory
3. 每次回复时，智能拼接「近期消息 + SuperMemory 记忆」
4. 彻底绕开 LCM 压缩，让细节永不丢失
"""

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Tuple
import sys



from supermemory.core.service import SuperMemoryService

PROJECT_DIR = Path(__file__).parent.parent.parent
DATA_DIR = Path("~/.openclaw/workspace-shared/super-memory-data/mars").expanduser()
CONTEXT_MANAGER_DIR = DATA_DIR / "context_manager"
CONTEXT_MANAGER_DIR.mkdir(parents=True, exist_ok=True)

# 配置文件
CONFIG_FILE = CONTEXT_MANAGER_DIR / "config.json"
STATE_FILE = CONTEXT_MANAGER_DIR / "state.json"
INJECT_FILE = Path("~/.openclaw/workspace-mars/memory/inject.md").expanduser()

# 默认配置
DEFAULT_CONFIG = {
    "context_window": 200000,  # 总 context window
    "danger_threshold": 0.70,   # 70% 开始分流
    "protect_tail_tokens": 30000,  # 保留最近 30k tokens
    "offload_batch": 50,       # 每批分流 50 条消息
    "check_interval": 10,      # 每 10 秒检查一次
    "retention_messages": 30,  # 保留最近 30 条原始消息在本地
    "auto_enrich": True,       # 自动更新 inject.md
    "super_memory_top_k": 5,   # 从 SuperMemory 检索多少条相关记忆
}


class ContextManager:
    """
    主动式上下文管理器
    
    核心思想：预防优于补救
    - 不等 LCM 压缩，在 context 达到 70% 时就开始分流
    - 分流后的消息存入 SuperMemory，作为外部记忆
    - 每次回复时，智能补充 SuperMemory 中的相关内容
    """

    def __init__(self, agent_name: str = "mars"):
        self.agent_name = agent_name
        self.data_dir = DATA_DIR
        self.config = self._load_config()
        
        # SuperMemory 实例
        self.sm = SuperMemory({
            'data_dir': str(self.data_dir),
            'agent_name': agent_name,
            'shared_dir': str(Path("~/.openclaw/workspace-shared/super-memory-data").expanduser())
        })
        
        # 状态
        self.state = self._load_state()
        self._lock = threading.Lock()
        
        # 当前监控的会话
        self._monitoring = False
        self._monitor_thread = None

    def _load_config(self) -> dict:
        if CONFIG_FILE.exists():
            return json.loads(CONFIG_FILE.read_text())
        return DEFAULT_CONFIG.copy()

    def _save_config(self):
        CONFIG_FILE.write_text(json.dumps(self.config, indent=2, ensure_ascii=False))

    def _load_state(self) -> dict:
        if STATE_FILE.exists():
            return json.loads(STATE_FILE.read_text())
        return {
            "last_check": None,
            "last_offload_at": None,
            "last_offload_tokens": 0,
            "total_offloaded": 0,
            "session_key": None,
        }

    def _save_state(self):
        STATE_FILE.write_text(json.dumps(self.state, indent=2, ensure_ascii=False))

    def estimate_context_usage(self) -> Tuple[float, int, int]:
        """
        估算当前 context 使用量
        返回: (使用率, 已用tokens, 总tokens)
        """
        try:
            # 尝试从 LCM DB 获取
            lcm_db = Path("~/.openclaw/lcm.db").expanduser()
            if lcm_db.exists():
                import sqlite3
                conn = sqlite3.connect(str(lcm_db))
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                
                # 获取最新会话的消息
                cur.execute("""
                    SELECT SUM(token_count) as total_tokens, COUNT(*) as msg_count
                    FROM messages m
                    JOIN conversations c ON m.conversation_id = c.conversation_id
                    WHERE c.session_key IS NOT NULL
                    ORDER BY c.updated_at DESC
                    LIMIT 1
                """)
                row = cur.fetchone()
                conn.close()
                
                if row and row['total_tokens']:
                    total = row['total_tokens']
                    window = self.config['context_window']
                    usage = total / window
                    return usage, total, window
            
            # 回退：检查本地会话追踪文件
            tracker_state = DATA_DIR / "session_tracker" / "active_session.json"
            if tracker_state.exists():
                data = json.loads(tracker_state.read_text())
                # 估算：每条消息平均 500 tokens
                estimated = data.get('message_count', 0) * 500
                window = self.config['context_window']
                usage = estimated / window
                return usage, estimated, window
                
        except Exception:
            pass
        
        return 0.0, 0, self.config['context_window']

    def should_offload(self) -> bool:
        """判断是否需要分流"""
        usage, _, _ = self.estimate_context_usage()
        return usage >= self.config['danger_threshold']

    def offload_old_messages(self, session_key: str = None) -> dict:
        """
        将旧消息分流到 SuperMemory
        """
        with self._lock:
            try:
                lcm_db = Path("~/.openclaw/lcm.db").expanduser()
                if not lcm_db.exists():
                    return {"status": "no_db"}
                
                import sqlite3
                conn = sqlite3.connect(str(lcm_db))
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()
                
                # 获取会话
                if session_key:
                    cur.execute("""
                        SELECT conversation_id, title FROM conversations 
                        WHERE session_key = ?
                    """, (session_key,))
                else:
                    cur.execute("""
                        SELECT conversation_id, title FROM conversations 
                        WHERE session_key IS NOT NULL
                        ORDER BY updated_at DESC LIMIT 1
                    """)
                
                conv = cur.fetchone()
                if not conv:
                    conn.close()
                    return {"status": "no_session"}
                
                conv_id = conv['conversation_id']
                title = conv['title'] or "未命名会话"
                
                # 获取消息（排除最近 N 条）
                protect_msgs = self.config['retention_messages']
                cur.execute(f"""
                    SELECT seq, role, content, token_count, created_at
                    FROM messages
                    WHERE conversation_id = ? AND seq < (
                        SELECT MAX(seq) FROM messages WHERE conversation_id = ?
                    ) - ?
                    ORDER BY seq ASC
                    LIMIT 100
                """, (conv_id, conv_id, protect_msgs))
                
                messages = [dict(row) for row in cur.fetchall()]
                conn.close()
                
                if not messages:
                    return {"status": "no_old_messages"}
                
                # 构建分流内容
                total_tokens = sum(m['token_count'] for m in messages)
                offload_content = self._build_offload_content(title, session_key, messages)
                
                # 写入 SuperMemory
                memory_id = self.sm.add_memory(
                    content=offload_content,
                    memory_type="context_archive",
                    importance="P1",
                    tags=["上下文存档", "自动分流", "context-manager"],
                    metadata={
                        "session_key": session_key,
                        "conversation_id": conv_id,
                        "msg_count": len(messages),
                        "total_tokens": total_tokens,
                        "date_range": f"{messages[0]['created_at']} ~ {messages[-1]['created_at']}",
                        "offloaded_at": datetime.now().isoformat(),
                        "source": "context_manager"
                    }
                )
                
                # 更新状态
                self.state["last_offload_at"] = datetime.now().isoformat()
                self.state["last_offload_tokens"] = total_tokens
                self.state["total_offloaded"] += len(messages)
                self._save_state()
                
                return {
                    "status": "success",
                    "memory_id": memory_id,
                    "msg_count": len(messages),
                    "total_tokens": total_tokens
                }
                
            except Exception as e:
                return {"status": "error", "reason": str(e)}

    def _build_offload_content(self, title: str, session_key: str, messages: list) -> str:
        """构建分流内容"""
        lines = [
            f"# 上下文存档 - {title}",
            f"",
            f"**会话**: {session_key or 'unknown'}",
            f"**时间**: {messages[0]['created_at']} ~ {messages[-1]['created_at']}",
            f"**消息数**: {len(messages)}",
            f"",
            f"---",
            ""
        ]
        
        for m in messages:
            role_emoji = {"user": "👤", "assistant": "🤖", "system": "⚙️", "tool": "🔧"}.get(m['role'], "💬")
            content = m['content'][:2000]  # 截断超长
            lines.extend([
                f"### {role_emoji} {m['role'].upper()} (seq={m['seq']})",
                "",
                content,
                "",
                f"*[{m['token_count']} tokens, {m['created_at']}]*",
                "---",
                ""
            ])
        
        return "\n".join(lines)

    def get_enrichment_text(self, query: str = "") -> str:
        """
        获取需要注入到上下文的补充内容
        基于当前对话主题，从 SuperMemory 检索相关存档
        """
        try:
            # 估算当前 context 使用情况
            usage, used, total = self.estimate_context_usage()
            
            # 如果 context 还很空闲，不需要补充
            if usage < 0.5:
                return ""
            
            # 从 SuperMemory 检索相关存档
            search_query = query or "上下文存档 context_archive"
            results = self.sm.search(
                query=search_query,
                top_k=self.config['super_memory_top_k'],
                memory_type="context_archive"
            )
            
            if not results:
                return ""
            
            parts = [
                "\n\n【系统补充 - 历史上下文】\n",
                f"（当前 context 使用率: {usage*100:.1f}%）\n"
            ]
            
            for i, r in enumerate(results, 1):
                content = r.get('content', '') if isinstance(r, dict) else str(r)
                # 提取关键部分（不超过 2000 字）
                if len(content) > 2000:
                    content = content[:2000] + "\n... [内容已截断]"
                parts.append(f"\n--- 历史存档 {i} ---\n{content}")
            
            return "".join(parts)
            
        except Exception as e:
            return ""

    def update_inject_file(self):
        """更新 inject.md 文件"""
        enrichment = self.get_enrichment_text()
        
        if enrichment:
            marker = "<!-- CONTEXT_MANAGER_ENRICHMENT -->"
            content = f"{marker}\n{enrichment}\n{marker}\n"
            INJECT_FILE.write_text(content)
        else:
            # 如果没有 enrichment，清空文件
            if INJECT_FILE.exists():
                INJECT_FILE.write_text("")

    def start_monitoring(self):
        """启动监控线程"""
        if self._monitoring:
            return
        
        self._monitoring = True
        
        def monitor_loop():
            while self._monitoring:
                try:
                    usage, used, total = self.estimate_context_usage()
                    
                    # 记录状态
                    self.state["last_check"] = datetime.now().isoformat()
                    self.state["current_usage"] = usage
                    self.state["used_tokens"] = used
                    self._save_state()
                    
                    # 检查是否需要分流
                    if self.should_offload():
                        result = self.offload_old_messages()
                        if result.get("status") == "success":
                            print(f"[ContextManager] Offloaded {result['msg_count']} messages at {usage*100:.1f}% usage")
                    
                    # 更新 inject 文件
                    if self.config['auto_enrich']:
                        self.update_inject_file()
                        
                except Exception as e:
                    print(f"[ContextManager] Error: {e}")
                
                time.sleep(self.config['check_interval'])
        
        self._monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self._monitor_thread.start()
        print(f"[ContextManager] Started monitoring (interval={self.config['check_interval']}s, threshold={self.config['danger_threshold']*100:.0f}%)")

    def stop_monitoring(self):
        """停止监控"""
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2)

    def get_status(self) -> dict:
        """获取状态"""
        usage, used, total = self.estimate_context_usage()
        return {
            "monitoring": self._monitoring,
            "context_usage": f"{usage*100:.1f}%",
            "used_tokens": used,
            "total_tokens": total,
            "last_check": self.state.get("last_check"),
            "last_offload": self.state.get("last_offload_at"),
            "total_offloaded": self.state.get("total_offloaded", 0),
            "config": self.config
        }


# 全局实例
_manager_instance: Optional[ContextManager] = None

def get_manager() -> ContextManager:
    global _manager_instance
    if _manager_instance is None:
        _manager_instance = ContextManager()
    return _manager_instance


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Context Manager")
    parser.add_argument("action", choices=["start", "stop", "status", "offload", "enrich", "test"])
    parser.add_argument("--query", help="Query for enrichment")
    parser.add_argument("--threshold", type=float, help="Danger threshold (0.0-1.0)")
    
    args = parser.parse_args()
    manager = get_manager()
    
    if args.action == "start":
        manager.start_monitoring()
        print("Context Manager started")
        
    elif args.action == "stop":
        manager.stop_monitoring()
        print("Context Manager stopped")
        
    elif args.action == "status":
        print(json.dumps(manager.get_status(), indent=2, ensure_ascii=False))
        
    elif args.action == "offload":
        result = manager.offload_old_messages()
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
    elif args.action == "enrich":
        text = manager.get_enrichment_text(args.query or "")
        print(text if text else "(no enrichment needed)")
        
    elif args.action == "test":
        usage, used, total = manager.estimate_context_usage()
        print(f"Context usage: {usage*100:.1f}% ({used}/{total} tokens)")
        print(f"Should offload: {manager.should_offload()}")
