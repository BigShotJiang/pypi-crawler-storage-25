"""
SuperMemoryFunctionRegistry - 全功能自动发现与注册系统
自动扫描所有SuperMemory模块，建立功能清单，支持插件式扩展
"""
import os
import sys
import re
import json
import inspect
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Set
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)

# 扫描路径
SUPER_MEMORY_SRC = Path(os.path.expanduser("~/.openclaw/workspace-mars/projects/SuperMemory/src"))
DATA_BASE = Path(os.path.expanduser("~/.openclaw/workspace-shared/super-memory-data"))


class FunctionRegistry:
    """
    SuperMemory 功能注册表
    自动发现所有模块，提取健康检查和自愈能力
    """
    
    VERSION = "1.0.0"
    
    def __init__(self):
        self.src_path = SUPER_MEMORY_SRC
        self.data_base = DATA_BASE
        
        # 功能清单
        self.modules: Dict[str, "ModuleEntry"] = {}
        # 未纳管的新模块（供进化系统使用）
        self.unregistered_modules: Set[str] = set()
        # 已知的健康检查函数
        self.health_checkers: Dict[str, Callable] = {}
        # 已知的自愈函数
        self.auto_fixers: Dict[str, Callable] = {}
        # 模块→文件路径映射
        self.module_to_file: Dict[str, Path] = {}
        
        # 注册表文件
        self.registry_file = self.data_base / "mars" / "function_registry.json"
        
        logger.info(f"[FunctionRegistry] v{self.VERSION} 初始化")
    
    def scan_all_modules(self) -> Dict[str, "ModuleEntry"]:
        """扫描所有SuperMemory模块，建立功能清单"""
        self.modules.clear()
        self.module_to_file.clear()
        
        # 1. 扫描核心模块
        core_path = self.src_path / "core"
        self._scan_directory(core_path, "core")
        
        # 2. 扫描进化模块
        evolvers_path = self.src_path / "evolvers"
        if evolvers_path.exists():
            self._scan_directory(evolvers_path, "evolvers")
        
        # 3. 扫描SDK
        sdk_path = self.src_path / "sdk" / "python"
        if sdk_path.exists():
            self._scan_directory(sdk_path, "sdk")
        
        # 4. 扫描服务端
        server_path = self.src_path / "server.py"
        if server_path.exists():
            self.module_to_file["server"] = server_path
            self.modules["server"] = self._analyze_file(server_path, "server")
        
        # 5. 扫描入口
        init_path = self.src_path / "__init__.py"
        if init_path.exists():
            self.module_to_file["__init__"] = init_path
        
        # 6. 扫描插件
        plugins_path = self.src_path / "core" / "plugins"
        if plugins_path.exists():
            self._scan_directory(plugins_path, "plugins")
        
        # 加载已保存的注册信息，检测新增模块
        saved = self._load_registry()
        new_modules = self._detect_new_modules(saved)
        
        if new_modules:
            logger.info(f"[FunctionRegistry] 检测到 {len(new_modules)} 个新模块: {new_modules}")
            self.unregistered_modules.update(new_modules)
        
        # 保存注册表
        self._save_registry()
        
        logger.info(f"[FunctionRegistry] 扫描完成: {len(self.modules)} 个模块")
        return self.modules
    
    def _scan_directory(self, path: Path, category: str):
        """扫描目录下的所有Python文件"""
        if not path.exists():
            return
        
        for item in path.rglob("*.py"):
            if "__pycache__" in str(item):
                continue
            
            # 获取模块名
            rel = item.relative_to(self.src_path)
            module_name = str(rel).replace("/", ".").replace(".py", "")
            
            self.module_to_file[module_name] = item
            self.modules[module_name] = self._analyze_file(item, module_name)
    
    def _analyze_file(self, file_path: Path, module_name: str) -> "ModuleEntry":
        """分析单个Python文件，提取功能清单"""
        entry = ModuleEntry(
            name=module_name,
            file=str(file_path),
            category=self._categorize(module_name)
        )
        
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            
            # 提取类
            classes = re.findall(r'^class\s+(\w+)', content, re.MULTILINE)
            
            # 提取函数（包括async）
            functions = re.findall(r'^(?:async\s+)?def\s+(\w+)', content, re.MULTILINE)
            
            # 检测健康检查相关模式
            health_patterns = [
                r'def\s+(health_check|check_health|get_health|run_health)',
                r'def\s+(auto_fix|fix|repair|heal)',
                r'def\s+(self_test|test|validate|verify)',
                r'health_status|health_check|FAULT_DETECTION',
            ]
            
            has_health_check = bool(re.search(r'def\s+(health_check|check_health|get_health)', content))
            has_auto_fix = bool(re.search(r'def\s+(auto_fix|_fix|repair|heal)', content))
            has_self_test = bool(re.search(r'def\s+(self_test|test|validate)', content))
            
            entry.has_health_check = has_health_check
            entry.has_auto_fix = has_auto_fix
            entry.has_self_test = has_self_test
            entry.classes = classes
            entry.functions = functions
            entry.line_count = len(content.splitlines())
            
            # 提取依赖（import语句）
            imports = re.findall(r'^import\s+(\w+)', content, re.MULTILINE)
            from_imports = re.findall(r'^from\s+(\w+)', content, re.MULTILINE)
            entry.dependencies = list(set(imports + from_imports))
            
            # 检查是否是插件
            entry.is_plugin = "Plugin" in classes or "plugin" in module_name.lower()
            
            # 检查是否是核心模块
            entry.is_core = "core" in module_name and not entry.is_plugin
            
        except Exception as e:
            entry.error = str(e)
        
        return entry
    
    def _categorize(self, module_name: str) -> str:
        """对模块进行分类"""
        if "plugin" in module_name.lower():
            return "plugin"
        elif "evolver" in module_name.lower():
            return "evolver"
        elif "sdk" in module_name.lower():
            return "sdk"
        elif module_name == "server":
            return "server"
        elif "core" in module_name:
            return "core"
        else:
            return "other"
    
    def _detect_new_modules(self, saved: Dict) -> List[str]:
        """检测新增模块（上次扫描没有的）"""
        if not saved or "modules" not in saved:
            return list(self.modules.keys())
        
        saved_modules = set(saved["modules"].keys())
        current_modules = set(self.modules.keys())
        new = current_modules - saved_modules
        
        return list(new)
    
    def _load_registry(self) -> Dict:
        """加载已保存的注册表"""
        if self.registry_file.exists():
            try:
                with open(self.registry_file, "r") as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def _save_registry(self):
        """保存注册表"""
        self.registry_file.parent.mkdir(parents=True, exist_ok=True)
        
        data = {
            "version": self.VERSION,
            "timestamp": datetime.now().isoformat(),
            "modules": {
                name: {
                    "file": entry.file,
                    "category": entry.category,
                    "has_health_check": entry.has_health_check,
                    "has_auto_fix": entry.has_auto_fix,
                    "has_self_test": entry.has_self_test,
                    "is_plugin": entry.is_plugin,
                    "is_core": entry.is_core,
                    "health_status": entry.health_status,
                    "registered": entry.registered,
                }
                for name, entry in self.modules.items()
            }
        }
        
        with open(self.registry_file, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def get_unregistered_modules(self) -> List[str]:
        """获取未注册的新模块（供进化系统使用）"""
        return list(self.unregistered_modules)
    
    def mark_module_registered(self, module_name: str):
        """标记模块已注册"""
        if module_name in self.modules:
            self.modules[module_name].registered = True
            self.unregistered_modules.discard(module_name)
            self._save_registry()
    
    def get_health_summary(self) -> Dict:
        """获取健康总览"""
        categories = defaultdict(list)
        for name, entry in self.modules.items():
            categories[entry.category].append({
                "name": name,
                "status": entry.health_status,
                "has_check": entry.has_health_check,
                "has_fix": entry.has_auto_fix,
            })
        
        total = len(self.modules)
        with_check = sum(1 for e in self.modules.values() if e.has_health_check)
        with_fix = sum(1 for e in self.modules.values() if e.has_auto_fix)
        unknown = sum(1 for e in self.modules.values() if e.health_status == "unknown")
        healthy = sum(1 for e in self.modules.values() if e.health_status == "healthy")
        unhealthy = sum(1 for e in self.modules.values() if e.health_status in ("unhealthy", "error"))
        
        return {
            "total_modules": total,
            "with_health_check": with_check,
            "with_auto_fix": with_fix,
            "coverage_percent": round(with_check / total * 100, 1) if total else 0,
            "fix_coverage_percent": round(with_fix / total * 100, 1) if total else 0,
            "unregistered_new": len(self.unregistered_modules),
            "health_status": {
                "healthy": healthy,
                "unhealthy": unhealthy,
                "unknown": unknown,
            },
            "by_category": dict(categories),
        }
    
    def print_registry(self):
        """打印注册表"""
        print("\n" + "="*80)
        print(f"SuperMemory 功能注册表 v{self.VERSION}")
        print("="*80)
        
        summary = self.get_health_summary()
        print(f"\n📊 总模块数: {summary['total_modules']}")
        print(f"✅ 有健康检查: {summary['with_health_check']} ({summary['coverage_percent']}%)")
        print(f"🔧 有自动修复: {summary['with_auto_fix']} ({summary['fix_coverage_percent']}%)")
        print(f"🆕 未注册新模块: {summary['unregistered_new']}")
        
        print(f"\n🏥 健康状态: ✅{summary['health_status']['healthy']} "
              f"❌{summary['health_status']['unhealthy']} "
              f"❓{summary['health_status']['unknown']}")
        
        if self.unregistered_modules:
            print(f"\n🆕 新增模块（未纳管）:")
            for m in self.unregistered_modules:
                print(f"   - {m}")
        
        print("\n📁 按分类:")
        for cat, mods in summary["by_category"].items():
            print(f"\n  [{cat}] ({len(mods)})")
            for m in sorted(mods, key=lambda x: x["name"]):
                status = {
                    "healthy": "✅",
                    "unhealthy": "❌",
                    "unknown": "❓"
                }.get(m["status"], "❓")
                check = "🔍" if m["has_check"] else "  "
                fix = "🔧" if m["has_fix"] else "  "
                print(f"    {status} {check}{fix} {m['name']}")
        
        print("\n" + "="*80)


class ModuleEntry:
    """模块条目"""
    
    def __init__(self, name: str, file: str, category: str):
        self.name = name
        self.file = file
        self.category = category
        self.has_health_check = False
        self.has_auto_fix = False
        self.has_self_test = False
        self.classes: List[str] = []
        self.functions: List[str] = []
        self.dependencies: List[str] = []
        self.is_plugin = False
        self.is_core = False
        self.health_status = "unknown"
        self.last_check: Optional[datetime] = None
        self.issues: List[str] = []
        self.registered = False
        self.line_count = 0
        self.error: Optional[str] = None


def main():
    """命令行入口"""
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
    
    registry = FunctionRegistry()
    registry.scan_all_modules()
    registry.print_registry()
    
    # 保存到文件
    summary = registry.get_health_summary()
    output = Path.home() / ".openclaw" / "workspace-mars" / "reports" / "function_registry.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output, "w") as f:
        json.dump({
            "registry_version": registry.VERSION,
            "timestamp": datetime.now().isoformat(),
            "summary": summary,
            "unregistered": registry.get_unregistered_modules(),
        }, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 注册表已保存: {output}")
    
    return registry


if __name__ == "__main__":
    main()
