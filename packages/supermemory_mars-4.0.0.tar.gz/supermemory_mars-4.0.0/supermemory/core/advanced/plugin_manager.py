"""
Plugin Manager - Hot-swappable plugin system
"""
from typing import Dict, List, Type
from supermemory.core.advanced.event_bus import EventBus


class PluginManager:
    """
    Plugin Manager - Supports hot-swapping
    """

    def __init__(self, event_bus: EventBus):
        self.event_bus = event_bus
        self.plugins = {}  # name -> plugin_instance
        self.core_plugins = set()  # Core plugins cannot be uninstalled

    def register_plugin(self, plugin_class: Type['Plugin'], config: dict = None):
        """Register a plugin"""
        plugin = plugin_class(self.event_bus, config or {})
        self.plugins[plugin.name] = plugin

        # Mark core plugins
        if getattr(plugin, 'core', False):
            self.core_plugins.add(plugin.name)

        # Load plugin (registers handlers)
        plugin.on_load()

        # Register event handlers
        for event_handler in plugin.get_event_handlers():
            self.event_bus.on(event_handler['event'], event_handler['callback'])

        return plugin

    def load_plugin(self, name: str):
        """Load a plugin"""
        if name in self.plugins:
            self.plugins[name].on_load()

    def unload_plugin(self, name: str):
        """Unload a plugin (core plugins cannot be unloaded)"""
        if name in self.core_plugins:
            raise ValueError(f"Core plugin {name} cannot be unloaded")
        if name in self.plugins:
            self.plugins[name].on_unload()
            del self.plugins[name]

    def get_plugin(self, name: str):
        """Get plugin instance"""
        return self.plugins.get(name)

    def list_plugins(self) -> List[dict]:
        """List all plugins"""
        return [
            {"name": p.name, "version": p.version, "core": p.name in self.core_plugins}
            for p in self.plugins.values()
        ]
