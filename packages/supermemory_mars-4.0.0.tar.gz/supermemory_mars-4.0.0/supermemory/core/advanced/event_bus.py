"""
Event Bus - In-process event-driven communication hub
Replaces Cron polling, all components communicate via events
"""
import logging

logger = logging.getLogger(__name__)


class EventBus:
    """
    In-process event bus
    Replaces Cron polling, all components communicate via events
    """

    def __init__(self):
        self._handlers = {}  # event -> [handlers]
        self._middleware = []

    def on(self, event: str, handler: callable):
        """Register event handler"""
        if event not in self._handlers:
            self._handlers[event] = []
        self._handlers[event].append(handler)

    def subscribe(self, event: str, handler: callable, priority: int = 0):
        """Subscribe to event (alias for on)"""
        self.on(event, handler)

    def off(self, event: str, handler: callable):
        """Unregister event handler"""
        if event in self._handlers:
            self._handlers[event].remove(handler)

    def unsubscribe(self, event: str, handler: callable):
        """Unsubscribe from event (alias for off)"""
        self.off(event, handler)

    def emit(self, event: str, data=None):
        """Emit event"""
        # 1. Pass through middleware
        for mw in self._middleware:
            data = mw.process(event, data)
        # 2. Call handlers
        if event in self._handlers:
            for handler in self._handlers[event]:
                try:
                    handler(data)
                except Exception as e:
                    logger.error(f"Event handler error: {event} - {e}")

    def use(self, middleware):
        """Add middleware"""
        self._middleware.append(middleware)
