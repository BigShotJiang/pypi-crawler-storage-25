"""
Health Monitor - Built-in health monitoring
Replaces Cron - checks every second without external scheduler
"""
import time
import asyncio
import logging
from typing import Dict, Callable

try:
    from core.event_bus import EventBus
except ImportError:
    EventBus = None

logger = logging.getLogger(__name__)


class HealthMonitor:
    """
    Built-in health monitor - Replaces Cron
    Checks every second, no external scheduler needed
    """

    def __init__(self, event_bus: EventBus):
        self.event_bus = event_bus
        self._running = False
        self._checks = {}  # name -> check_fn
        self._last_results = {}  # name -> result
        self._health_score = 100.0

    def register_check(self, name: str, check_fn: Callable, threshold: float = 1.0):
        """Register a health check"""
        self._checks[name] = {
            "fn": check_fn,
            "threshold": threshold,
            "last_run": 0,
            "failures": 0
        }

    async def _run_checks(self):
        """Run all checks"""
        for name, check in self._checks.items():
            try:
                result = await check["fn"]()
                check["last_run"] = time.time()
                check["failures"] = 0 if result else check["failures"] + 1
                self._last_results[name] = result

                # Emit event if check failed
                if not result:
                    self.event_bus.emit("health_check_failed", {
                        "check": name,
                        "failures": check["failures"]
                    })
            except Exception as e:
                logger.error(f"Health check error: {name} - {e}")
                self._last_results[name] = False

    async def start(self):
        """Start monitoring (checks every second)"""
        self._running = True
        while self._running:
            await self._run_checks()
            await asyncio.sleep(1)

    def stop(self):
        """Stop monitoring"""
        self._running = False

    def get_health_score(self) -> float:
        """Get health score 0-100"""
        if not self._checks:
            return 100.0

        failed = sum(1 for r in self._last_results.values() if not r)
        return 100.0 * (len(self._checks) - failed) / len(self._checks)
