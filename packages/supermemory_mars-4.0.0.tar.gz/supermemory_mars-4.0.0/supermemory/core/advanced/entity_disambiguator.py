"""实体消歧 - 对标Memori"""
import re
import json
from typing import List, Dict, Optional, Tuple
from pathlib import Path
from datetime import datetime


class EntityRecord:
    """实体记录"""
    
    def __init__(self, name: str, entity_type: str, context: str, 
                 metadata: Dict = None, confidence: float = 1.0):
        self.id = f"entity_{name}_{hash(context) % 10000}"
        self.name = name
        self.type = entity_type  # person/company/product/location/concept
        self.context = context
        self.metadata = metadata or {}
        self.confidence = confidence
        self.occurrences = 1
        self.created_at = datetime.now().isoformat()
        self.updated_at = self.created_at
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "context": self.context,
            "metadata": self.metadata,
            "confidence": self.confidence,
            "occurrences": self.occurrences,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> 'EntityRecord':
        entity = cls(d["name"], d["type"], d["context"], d.get("metadata"), d.get("confidence", 1.0))
        entity.id = d["id"]
        entity.occurrences = d.get("occurrences", 1)
        entity.created_at = d.get("created_at", datetime.now().isoformat())
        entity.updated_at = d.get("updated_at", datetime.now().isoformat())
        return entity


class EntityDisambiguator:
    """
    实体消歧系统
    处理"Apple"等歧义实体，根据上下文确定具体含义
    """
    
    ENTITY_TYPES = ["person", "company", "product", "location", "concept"]
    
    # 常见歧义词汇
    COMMON_AMBIGUOUS = {
        "Apple": ["company", "fruit"],
        "Java": ["company", "language", "island"],
        "Python": ["company", "language", "animal"],
        "Trump": ["person", "action"],
        "China": ["country", "porcelain"],
        "Tiger": ["animal", "golf", "team"],
        "Microsoft": ["company"],
        "Google": ["company", "verb"],
        "Amazon": ["company", "river", "rainforest"],
    }
    
    def __init__(self, storage_path: str = "./data/entities.json"):
        self.storage_path = storage_path
        Path(storage_path).parent.mkdir(parents=True, exist_ok=True)
        self._entities = {}
        self._name_index = {}  # name -> [entity_ids]
        self._load()
    
    def _load(self):
        """加载实体数据"""
        if Path(self.storage_path).exists():
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                for entity_dict in data.get("entities", []):
                    entity = EntityRecord.from_dict(entity_dict)
                    self._entities[entity.id] = entity
                    
                    if entity.name not in self._name_index:
                        self._name_index[entity.name] = []
                    self._name_index[entity.name].append(entity.id)
    
    def _save(self):
        """保存实体数据"""
        data = {
            "entities": [e.to_dict() for e in self._entities.values()]
        }
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def extract_entities(self, text: str) -> List[Dict]:
        """
        从文本中提取潜在实体
        返回: [{"text": "Apple", "type": "company", "start": 0, "end": 5}, ...]
        """
        results = []
        
        # 提取常见歧义词
        for word, types in self.COMMON_AMBIGUOUS.items():
            for match in re.finditer(rf'\b{word}\b', text):
                results.append({
                    "text": match.group(),
                    "start": match.start(),
                    "end": match.end(),
                    "possible_types": types
                })
        
        # 提取首字母大写的词组 (简单NER)
        for match in re.finditer(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text):
            word = match.group()
            if len(word) > 2 and word not in self.COMMON_AMBIGUOUS:
                results.append({
                    "text": word,
                    "start": match.start(),
                    "end": match.end(),
                    "possible_types": ["unknown"]
                })
        
        return results
    
    def disambiguate(self, entity_mention: str, context: str) -> Optional[EntityRecord]:
        """
        消歧义 - 根据上下文确定实体具体含义
        
        Args:
            entity_mention: 实体提及，如"Apple"
            context: 上下文文本
            
        Returns:
            EntityRecord 或 None
        """
        # 获取所有候选实体
        candidates = self._get_candidates(entity_mention)
        
        if not candidates:
            # 没有候选，创建新实体
            return self._create_entity(entity_mention, context)
        
        # 计算每个候选的上下文相似度
        best_match = None
        best_score = 0
        
        context_lower = context.lower()
        
        for entity in candidates:
            score = self._calculate_similarity(entity, context_lower)
            
            # 类型一致性评分
            type_score = self._get_type_score(entity.type, context_lower)
            total_score = score * 0.7 + type_score * 0.3
            
            if total_score > best_score:
                best_score = total_score
                best_match = entity
        
        # 阈值判断
        if best_score < 0.3 or not best_match:
            # 无匹配或相似度太低，创建新实体
            return self._create_entity(entity_mention, context)
        
        # 更新实体出现次数
        best_match.occurrences += 1
        best_match.updated_at = datetime.now().isoformat()
        self._save()
        
        return best_match
    
    def _get_candidates(self, name: str) -> List[EntityRecord]:
        """获取同名所有实体"""
        entity_ids = self._name_index.get(name, [])
        return [self._entities[eid] for eid in entity_ids if eid in self._entities]
    
    def _calculate_similarity(self, entity: EntityRecord, context: str) -> float:
        """计算上下文相似度"""
        # 简单实现：检查实体metadata中的关键词是否出现在上下文中
        score = 0.0
        
        # 检查类型关键词
        type_keywords = {
            "company": ["company", "inc", "ltd", "corp", "股价", "营收", "收购"],
            "product": ["product", "launch", "release", "发布", "产品"],
            "person": ["ceo", "founder", "president", "ceo", "总裁", "创始人"],
            "language": ["language", "code", "programming", "编程", "语言"],
        }
        
        if entity.type in type_keywords:
            keywords = type_keywords[entity.type]
            for kw in keywords:
                if kw.lower() in context:
                    score += 0.2
        
        # 检查metadata中的关键词
        for key, value in entity.metadata.items():
            if isinstance(value, str) and value.lower() in context:
                score += 0.1
        
        # 上下文长度归一化
        return min(score, 1.0)
    
    def _get_type_score(self, entity_type: str, context: str) -> float:
        """根据类型获取基础分"""
        type_keywords = {
            "company": ["company", "inc", "股价", "ceo", "founder", "收购", "google", "apple"],
            "product": ["product", "launch", "release", "version", "发布"],
            "person": ["he", "she", "his", "her", "ceo", "founder", "president"],
            "location": ["in", "at", "located", "city", "country", "北京", "上海"],
            "concept": ["idea", "theory", "concept", "理论", "概念"],
        }
        
        keywords = type_keywords.get(entity_type, [])
        for kw in keywords:
            if kw in context:
                return 0.5
        
        return 0.1
    
    def _create_entity(self, name: str, context: str) -> EntityRecord:
        """创建新实体"""
        # 根据上下文推断类型
        inferred_type = self._infer_type(context)
        
        entity = EntityRecord(
            name=name,
            entity_type=inferred_type,
            context=context[:200],  # 保留前200字符作为上下文
            confidence=0.5
        )
        
        self._entities[entity.id] = entity
        
        if name not in self._name_index:
            self._name_index[name] = []
        self._name_index[name].append(entity.id)
        
        self._save()
        return entity
    
    def _infer_type(self, context: str) -> str:
        """从上下文推断实体类型"""
        context_lower = context.lower()
        
        type_scores = {
            "company": 0,
            "person": 0,
            "product": 0,
            "location": 0,
            "concept": 0
        }
        
        # 类型关键词打分
        keywords = {
            "company": ["company", "inc", "ltd", "股价", "营收", "ceo", "founder", "收购", "上市"],
            "person": ["he", "she", "his", "her", "ceo", "president", "founder", "他说", "他/她"],
            "product": ["product", "launch", "release", "version", "发布", "功能", "特性"],
            "location": ["city", "country", "located", "in", "at", "北京", "上海", "美国", "中国"],
            "concept": ["idea", "theory", "concept", "理论", "概念", "思想", "方法"],
        }
        
        for etype, kws in keywords.items():
            for kw in kws:
                if kw in context_lower:
                    type_scores[etype] += 1
        
        # 返回得分最高的类型
        return max(type_scores, key=type_scores.get)
    
    def merge_entities(self, entity_id1: str, entity_id2: str):
        """合并两个实体"""
        if entity_id1 not in self._entities or entity_id2 not in self._entities:
            return
        
        e1 = self._entities[entity_id1]
        e2 = self._entities[entity_id2]
        
        # 保留出现次数更多的
        if e2.occurrences > e1.occurrences:
            e1, e2 = e2, e1
        
        # 合并metadata
        e1.metadata.update(e2.metadata)
        e1.occurrences += e2.occurrences
        e1.confidence = min(1.0, (e1.confidence + e2.confidence) / 2 + 0.1)
        e1.updated_at = datetime.now().isoformat()
        
        # 删除e2
        self._name_index[e2.name].remove(entity_id2)
        del self._entities[entity_id2]
        
        self._save()
    
    def get_stats(self) -> Dict:
        """获取实体统计"""
        type_counts = {}
        for entity in self._entities.values():
            type_counts[entity.type] = type_counts.get(entity.type, 0) + 1
        
        return {
            "total": len(self._entities),
            "by_type": type_counts,
            "ambiguous_names": len([n for n, ids in self._name_index.items() if len(ids) > 1])
        }
    def infer_relationships(self, entity_id: str) -> List[Dict]:
        """推断实体的间接关系"""
        inferred = []
        entity = self.entities.get(entity_id)
        if not entity:
            return inferred
        
        # 一度关系
        for rel_type, related_ids in entity.get('relationships', {}).items():
            for related_id in related_ids:
                inferred.append({
                    'from': entity_id,
                    'to': related_id,
                    'type': rel_type,
                    'depth': 1,
                    'reasoning': f"直接{rel_type}关系"
                })
                # 二度关系
                if related_id in self.entities:
                    for second_rel, second_ids in self.entities[related_id].get('relationships', {}).items():
                        for second_id in second_ids:
                            if second_id != entity_id:
                                inferred.append({
                                    'from': entity_id,
                                    'to': second_id,
                                    'type': second_rel,
                                    'depth': 2,
                                    'reasoning': f"通过{related_id}的{rel_type}间接关联"
                                })
        return inferred
