"""Git跨机同步 - 对标engram"""
import os
import subprocess
import shutil
import difflib
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import json


class GitCommand:
    """Git命令封装"""

    def __init__(self, repo_path: str):
        self.repo_path = repo_path
        self.git_dir = os.path.join(repo_path, '.git')

    def _run(self, *args) -> Tuple[int, str, str]:
        """执行git命令"""
        try:
            result = subprocess.run(
                ['git', '-C', self.repo_path] + list(args),
                capture_output=True,
                text=True,
                timeout=30
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", "Git command timeout"
        except FileNotFoundError:
            return -1, "", "Git not found"

    def status(self) -> Dict:
        """获取git状态"""
        code, stdout, _ = self._run('status', '--porcelain')
        changed = []
        for line in stdout.strip().split('\n'):
            if line:
                changed.append(line)

        code2, stdout2, _ = self._run('log', '-1', '--format=%H %s')
        last_commit = None
        if code2 == 0 and stdout2.strip():
            parts = stdout2.strip().split(' ', 1)
            if len(parts) == 2:
                last_commit = {"hash": parts[0], "message": parts[1]}

        return {
            "changed": changed,
            "last_commit": last_commit,
            "clean": len(changed) == 0
        }

    def add(self, files: List[str] = None):
        """git add"""
        if files:
            self._run('add', *files)
        else:
            self._run('add', '.')

    def commit(self, message: str) -> Optional[str]:
        """git commit"""
        code, stdout, stderr = self._run('commit', '-m', message)
        if code == 0:
            # 返回commit hash
            code2, hash_out, _ = self._run('rev-parse', 'HEAD')
            return hash_out.strip() if code2 == 0 else None
        return None

    def push(self, remote: str = "origin", branch: str = "main") -> bool:
        """git push"""
        code, _, stderr = self._run('push', remote, branch)
        return code == 0

    def pull(self, remote: str = "origin", branch: str = "main") -> bool:
        """git pull"""
        code, _, stderr = self._run('pull', '--no-rebase', remote, branch)
        return code == 0

    def fetch(self, remote: str = "origin") -> bool:
        """git fetch"""
        code, _, stderr = self._run('fetch', remote)
        return code == 0

    def log(self, n: int = 10) -> List[Dict]:
        """获取最近N条commit"""
        code, stdout, _ = self._run('log', f'-{n}', '--format=%H|%s|%an|%ai')
        commits = []
        for line in stdout.strip().split('\n'):
            if line:
                parts = line.split('|')
                if len(parts) >= 4:
                    commits.append({
                        "hash": parts[0],
                        "message": parts[1],
                        "author": parts[2],
                        "date": parts[3]
                    })
        return commits

    def diff(self, file: str = None) -> str:
        """获取diff"""
        if file:
            code, stdout, _ = self._run('diff', file)
        else:
            code, stdout, _ = self._run('diff')
        return stdout

    def diff_3way(self, file: str, base: str, ours: str, theirs: str) -> str:
        """三方diff比较"""
        code, stdout, _ = self._run('diff', '--no-index', f"{base}", f"{ours}")
        code2, stdout2, _ = self._run('diff', '--no-index', f"{base}", f"{theirs}")
        return f"=== OURS ===\n{stdout}\n=== THEIRS ===\n{stdout2}"

    def stash(self, message: str = None) -> bool:
        """git stash"""
        args = ['stash', 'push']
        if message:
            args.extend(['-m', message])
        code, _, _ = self._run(*args)
        return code == 0

    def stash_pop(self) -> bool:
        """git stash pop"""
        code, _, _ = self._run('stash', 'pop')
        return code == 0

    def branch_list(self) -> List[str]:
        """列出所有分支"""
        code, stdout, _ = self._run('branch', '-a')
        if code == 0:
            return [b.strip().replace('* ', '') for b in stdout.strip().split('\n') if b]
        return []

    def current_branch(self) -> str:
        """当前分支"""
        code, stdout, _ = self._run('branch', '--show-current')
        return stdout.strip() if code == 0 else ""

    def rev_list(self, count: int = 1) -> List[str]:
        """获取最近的commit hash列表"""
        code, stdout, _ = self._run('rev-list', f'HEAD~{count}..HEAD', '--format=%H')
        return [h for h in stdout.strip().split('\n') if h and len(h) == 40]

    def remote_list(self) -> List[str]:
        """列出远程仓库"""
        code, stdout, _ = self._run('remote', '-v')
        remotes = []
        for line in stdout.strip().split('\n'):
            if line and '\t' in line:
                name = line.split('\t')[0]
                if name not in remotes:
                    remotes.append(name)
        return remotes

    def set_remote(self, name: str, url: str) -> bool:
        """设置远程仓库"""
        # 先尝试移除
        self._run('remote', 'remove', name)
        code, _, _ = self._run('remote', 'add', name, url)
        return code == 0


class ConflictMarker:
    """Git冲突标记解析器"""

    CONFLICT_START = '<<<<<<<'
    CONFLICT_MID = '======='
    CONFLICT_END = '>>>>>>>'

    @classmethod
    def parse_conflict_file(cls, filepath: str) -> List[Dict]:
        """解析冲突文件，返回冲突块列表"""
        conflicts = []
        current = None

        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        for i, line in enumerate(lines):
            if line.startswith(cls.CONFLICT_START):
                current = {
                    'start_line': i,
                    'ours': [],
                    'theirs': [],
                    'label': line[len(cls.CONFLICT_START):].strip()
                }
            elif line.startswith(cls.CONFLICT_MID) and current:
                current['mid_line'] = i
            elif line.startswith(cls.CONFLICT_END) and current:
                current['end_line'] = i
                conflicts.append(current)
                current = None
            elif current:
                if 'mid_line' not in current:
                    current['ours'].append(line)
                else:
                    current['theirs'].append(line)

        return conflicts

    @classmethod
    def has_conflicts(cls, content: str) -> bool:
        """检查内容是否包含冲突标记"""
        return cls.CONFLICT_START in content

    @classmethod
    def auto_resolve(cls, ours_content: str, theirs_content: str,
                     strategy: str = "newest") -> str:
        """
        自动解决冲突
        strategies:
            - newest: 使用最新修改
            - ours: 优先使用本地版本
            - theirs: 优先使用远程版本
            - merge: 合并两者的有效修改
        """
        if strategy == "ours":
            return ours_content
        elif strategy == "theirs":
            return theirs_content
        elif strategy == "newest":
            # 简单策略：使用较长的版本（通常包含更多内容）
            return theirs_content if len(theirs_content) >= len(ours_content) else ours_content
        else:
            return ours_content

    @classmethod
    def merge_text(cls, ours: str, theirs: str) -> str:
        """智能合并两段文本"""
        ours_lines = ours.splitlines(keepends=True)
        theirs_lines = theirs.splitlines(keepends=True)

        result = []
        matcher = difflib.SequenceMatcher(None, ours_lines, theirs_lines)

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                result.extend(ours_lines[i1:i2])
            elif tag == 'replace':
                # 冲突：保留both
                result.append(f"<<<<<<< LOCAL\n")
                result.extend(ours_lines[i1:i2])
                result.append(f"=======\n")
                result.extend(theirs_lines[j1:j2])
                result.append(f">>>>>>> REMOTE\n")
            elif tag == 'delete':
                result.extend(ours_lines[i1:i2])
            elif tag == 'insert':
                result.extend(theirs_lines[j1:j2])

        return ''.join(result)


class Conflict:
    """冲突信息"""

    def __init__(self, file_path: str, conflict_data: Dict):
        self.file_path = file_path
        self.ours = conflict_data.get('ours', '')
        self.theirs = conflict_data.get('theirs', '')
        self.base = conflict_data.get('base', '')
        self.label = conflict_data.get('label', file_path)
        self.timestamp = datetime.now()

    def to_dict(self) -> Dict:
        return {
            "file": self.file_path,
            "label": self.label,
            "ours_preview": self.ours[:200] + "..." if len(self.ours) > 200 else self.ours,
            "theirs_preview": self.theirs[:200] + "..." if len(self.theirs) > 200 else self.theirs,
            "timestamp": self.timestamp.isoformat()
        }


class GitSync:
    """
    Git同步服务
    支持多设备记忆同步，类engram设计
    """

    def __init__(self, repo_path: str = "./data/memory-git"):
        self.repo_path = repo_path
        self.git = GitCommand(repo_path)
        self.conflicts: List[Conflict] = []
        self._ensure_repo()

    def _ensure_repo(self):
        """确保git仓库存在"""
        Path(self.repo_path).mkdir(parents=True, exist_ok=True)

        git_dir = os.path.join(self.repo_path, '.git')
        if not os.path.exists(git_dir):
            # 初始化仓库
            self._run_git('init')
            self._run_git('config', 'user.email', 'supermemory@local')
            self._run_git('config', 'user.name', 'SuperMemory')

            # 创建初始commit
            Path(os.path.join(self.repo_path, '.gitkeep')).touch()
            self._run_git('add', '.gitkeep')
            self._run_git('commit', '-m', 'Initial commit')

    def _run_git(self, *args) -> Tuple[int, str, str]:
        return self.git._run(*args)

    def sync(self, remote: str = "origin") -> Dict:
        """
        完整同步流程
        1. fetch远程更新
        2. 检查冲突
        3. 自动merge或标记冲突
        4. push本地更改
        """
        report = {
            "success": True,
            "pulled": False,
            "pushed": False,
            "conflicts": [],
            "message": ""
        }

        # 1. Fetch远程
        if self._run_git('ls-remote', remote)[0] == 0:
            self.git.fetch(remote)
            report["pulled"] = True

        # 2. 获取状态
        status = self.git.status()

        # 3. 添加所有更改
        self.git.add()

        # 4. 如果有更改，commit并push
        if not status["clean"]:
            commit_hash = self.git.commit(f"Auto-sync {datetime.now().isoformat()}")
            if commit_hash:
                report["commits"] = [commit_hash]

        # 5. 尝试pull以处理远程更新
        if report["pulled"]:
            pull_success = self.git.pull(remote)
            if not pull_success:
                # 检测冲突文件
                conflict_files = self._detect_conflict_files()
                if conflict_files:
                    for cf in conflict_files:
                        conflict_data = self._parse_conflict_file(cf)
                        self.conflicts.append(Conflict(cf, conflict_data))
                    report["conflicts"] = [c.to_dict() for c in self.conflicts]
                    report["message"] = f"Found {len(conflict_files)} conflict files"
                    # 不标记为失败，保留本地工作
                report["success"] = True  # pull失败不影响整体流程

        # 6. Push本地更改
        if self._run_git('ls-remote', remote)[0] == 0:
            push_success = self.git.push(remote)
            report["pushed"] = push_success
            if not push_success:
                _, _, err = self._run_git('push', remote)
                report["message"] = f"Push failed: {err}"

        return report

    def _detect_conflict_files(self) -> List[str]:
        """检测冲突文件"""
        conflicts = []
        for root, dirs, files in os.walk(self.repo_path):
            # 跳过.git目录
            if '.git' in root:
                continue
            for file in files:
                filepath = os.path.join(root, file)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                    if ConflictMarker.has_conflicts(content):
                        conflicts.append(filepath)
                except:
                    continue
        return conflicts

    def _parse_conflict_file(self, filepath: str) -> Dict:
        """解析冲突文件"""
        conflicts = ConflictMarker.parse_conflict_file(filepath)
        if conflicts:
            # 返回第一个冲突块
            c = conflicts[0]
            return {
                'ours': ''.join(c['ours']),
                'theirs': ''.join(c['theirs']),
                'base': ''  # base需要额外的git命令获取
            }
        return {'ours': '', 'theirs': '', 'base': ''}

    def resolve_conflict(self, file_path: str, strategy: str = "newest",
                         custom_content: str = None) -> bool:
        """
        解决指定文件的冲突

        Args:
            file_path: 冲突文件路径
            strategy: 解决策略 (newest|ours|theirs|merge)
            custom_content: 自定义合并内容（用于merge策略）
        """
        if not os.path.exists(file_path):
            return False

        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        conflicts = ConflictMarker.parse_conflict_file(file_path)
        if not conflicts:
            return True  # 没有冲突了

        if custom_content:
            new_content = custom_content
        else:
            # 构建合并后的内容
            lines = content.splitlines(keepends=True)
            new_lines = []
            i = 0
            while i < len(lines):
                line = lines[i]
                if line.startswith(ConflictMarker.CONFLICT_START):
                    # 找到ours部分
                    ours_lines = []
                    theirs_lines = []
                    i += 1
                    while i < len(lines) and not lines[i].startswith(ConflictMarker.CONFLICT_MID):
                        ours_lines.append(lines[i])
                        i += 1
                    i += 1  # 跳过 ====
                    while i < len(lines) and not lines[i].startswith(ConflictMarker.CONFLICT_END):
                        theirs_lines.append(lines[i])
                        i += 1
                    i += 1  # 跳过 >>>>>>>

                    # 应用策略
                    resolved = ConflictMarker.auto_resolve(
                        ''.join(ours_lines),
                        ''.join(theirs_lines),
                        strategy
                    )
                    new_lines.append(resolved)
                else:
                    new_lines.append(line)
                    i += 1
            new_content = ''.join(new_lines)

        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)

        # 移除冲突标记后重新add
        self.git.add([file_path])
        return True

    def add_remote(self, name: str = "origin", url: str = None) -> bool:
        """添加远程仓库"""
        if url:
            return self.git.set_remote(name, url)
        return False

    def get_sync_status(self) -> Dict:
        """获取同步状态"""
        status = self.git.status()
        remotes = self.git.remote_list()
        branches = self.git.branch_list()
        current_branch = self.git.current_branch()

        return {
            "repo_path": self.repo_path,
            "is_clean": status["clean"],
            "changed_files": len(status["changed"]),
            "changed_detail": status["changed"],
            "last_commit": status["last_commit"],
            "remotes": remotes,
            "branches": branches,
            "current_branch": current_branch,
            "pending_conflicts": len(self.conflicts)
        }

    def get_conflicts(self) -> List[Dict]:
        """获取所有未解决的冲突"""
        return [c.to_dict() for c in self.conflicts]

    def export_memories(self, output_dir: str = "./exports") -> str:
        """导出记忆到指定目录（用于备份）"""
        export_path = Path(output_dir)
        export_path.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        export_file = export_path / f"memories_{timestamp}.tar.gz"

        # 使用git archive导出
        code, stdout, stderr = self._run_git(
            'archive', '--format=tar.gz',
            f'HEAD:data/memories',
            '-o', str(export_file)
        )

        if code == 0 and export_file.exists():
            return str(export_file)
        else:
            # Fallback: 复制整个仓库
            fallback = export_path / f"repo_backup_{timestamp}"
            shutil.copytree(self.repo_path, fallback)
            return str(fallback)

    def import_memories(self, import_source: str) -> bool:
        """从备份导入记忆"""
        source = Path(import_source)
        if not source.exists():
            return False

        if source.is_file() and source.suffix == '.gz':
            # 解压tar.gz
            import tarfile
            with tarfile.open(source, 'r:gz') as tar:
                tar.extractall(path=self.repo_path)
        else:
            # 复制目录
            src_data = source / 'data' / 'memories'
            if src_data.exists():
                dst_data = Path(self.repo_path) / 'data' / 'memories'
                shutil.copytree(src_data, dst_data, dirs_exist_ok=True)

        self.git.add()
        return True


class DeviceRegistry:
    """设备注册表 - 管理多设备"""

    def __init__(self, registry_path: str = "./data/.devices.json"):
        self.registry_path = registry_path
        self._devices: Dict[str, Dict] = {}
        self._load()

    def _load(self):
        """加载设备注册表"""
        if os.path.exists(self.registry_path):
            with open(self.registry_path, 'r') as f:
                self._devices = json.load(f)

    def _save(self):
        """保存设备注册表"""
        Path(self.registry_path).parent.mkdir(parents=True, exist_ok=True)
        with open(self.registry_path, 'w') as f:
            json.dump(self._devices, f, indent=2)

    def register_device(self, device_id: str, info: Dict) -> bool:
        """注册新设备"""
        self._devices[device_id] = {
            **info,
            "last_seen": datetime.now().isoformat(),
            "registered": datetime.now().isoformat()
        }
        self._save()
        return True

    def unregister_device(self, device_id: str) -> bool:
        """注销设备"""
        if device_id in self._devices:
            del self._devices[device_id]
            self._save()
            return True
        return False

    def get_device(self, device_id: str) -> Optional[Dict]:
        """获取设备信息"""
        return self._devices.get(device_id)

    def list_devices(self) -> List[Dict]:
        """列出所有设备"""
        return list(self._devices.values())

    def update_last_seen(self, device_id: str) -> bool:
        """更新设备最后活跃时间"""
        if device_id in self._devices:
            self._devices[device_id]["last_seen"] = datetime.now().isoformat()
            self._save()
            return True
        return False
