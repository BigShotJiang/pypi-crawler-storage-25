"""
Explainability Module - 记忆检索结果解释生成
当搜索记忆时，为每条结果生成"为什么这条记忆相关"的解释
"""
from typing import List, Dict, Any, Optional
import re


class ExplainabilityService:
    """
    可解释性服务
    为检索结果生成自然语言解释
    """

    def __init__(self, graph_plugin=None):
        self.graph = graph_plugin

    def explain_result(self, memory_content: str, query: str,
                       matched_terms: List[str] = None,
                       memory_metadata: dict = None,
                       rank_score: float = None) -> str:
        """
        生成单条记忆的解释

        Args:
            memory_content: 记忆原文
            query: 搜索query
            matched_terms: 命中的关键词列表
            memory_metadata: 记忆的元数据
            rank_score: 排序分数

        Returns:
            解释文本
        """
        parts = []

        # 1. 关键词命中说明
        if matched_terms:
            hits = [t for t in matched_terms if t and t in query.lower() or any(t.lower() in qw.lower() for qw in query.split())]
            if hits:
                parts.append(f"命中关键词：{'、'.join(hits[:5])}")

        # 2. 图谱关联说明
        if self.graph and memory_metadata:
            memory_id = memory_metadata.get("id")
            if memory_id:
                neighbors = self.graph._edges.get(memory_id, [])
                if neighbors:
                    rels = [n.get("relation", "related_to") for n in neighbors[:3]]
                    parts.append(f"与{'、'.join(set(rels))}的记忆相连")

        # 3. 标签匹配说明
        if memory_metadata:
            tags = memory_metadata.get("tags", [])
            if tags and isinstance(tags, list):
                tag_str = "、".join(tags[:3])
                parts.append(f"标签：{tag_str}")

        # 4. 记忆类型说明
        if memory_metadata:
            mem_type = memory_metadata.get("type", "general")
            if mem_type != "general":
                parts.append(f"类型：{mem_type}")

        if not parts:
            return "通过语义相似度匹配"

        return "；".join(parts) + "。"

    def explain_batch(self, query: str,
                      results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        为批量检索结果添加解释

        Args:
            query: 搜索query
            results: 检索结果列表，每项包含 content/metadata/score/id

        Returns:
            附加了 explanation 字段的结果列表
        """
        query_lower = query.lower()
        query_words = set(query_lower.split())

        explained = []
        for r in results:
            content = r.get("content", "")
            metadata = r.get("metadata", {})
            score = r.get("score", 0)

            # 找命中词
            content_lower = content.lower()
            matched = [w for w in query_words if w in content_lower and len(w) > 1]

            explanation = self.explain_result(
                memory_content=content,
                query=query,
                matched_terms=matched,
                memory_metadata=metadata,
                rank_score=score,
            )

            explained.append({
                **r,
                "explanation": explanation,
            })

        return explained
