#!/usr/bin/env python3
"""
SuperMemory V4 - Unified Package
合并 V4 简洁架构 + GitHub OpenSpace 进化器 + 全面自愈系统
"""
import sys
import os

__version__ = "4.0.0"
__author__ = "SuperMemory Team"

# =============================================================================
# Core - 简洁核心模块（V4，稳定）
# =============================================================================
from .core.memory import MemoryService, Memory
from .core.vector import VectorService, VectorEntry
from .core.layer import ThreeLayerManager, LayerConfig
from .core.wal import WALLogger
from .core.backup import BackupService
from .core.integrity import IntegrityChecker, Issue
from .core.service import SuperMemoryService

# =============================================================================
# Advanced - 高级模块（从 GitHub 集成）
# =============================================================================
try:
    from .core.advanced.hybrid_search import HybridSearch
except ImportError:
    HybridSearch = None

try:
    from .core.advanced.health_monitor import HealthMonitor
except ImportError:
    HealthMonitor = None

try:
    from .core.advanced.conflict_resolver import ConflictResolver
except ImportError:
    ConflictResolver = None

try:
    from .core.advanced.git_sync import GitSync
except ImportError:
    GitSync = None

try:
    from .core.advanced.version_control import MemoryVersionControl
except ImportError:
    MemoryVersionControl = None

try:
    from .core.advanced.context_manager import ContextManager
except ImportError:
    ContextManager = None

try:
    from .core.advanced.plugin_manager import PluginManager
except ImportError:
    PluginManager = None

try:
    from .core.advanced.event_bus import EventBus
except ImportError:
    EventBus = None

# =============================================================================
# Evolver - 统一进化框架 + 全面自愈
# =============================================================================
from .evolver.self_healer import SelfHealer, HealerIssue
from .evolver.skill_registry import SkillRegistry, Skill
from .evolver.evolution_manager import EvolutionManager
from .evolver.base import Evolver, EvolutionResult

# Advanced evolvers (from GitHub)
try:
    from .evolver.advanced.framework import EvolutionFramework
except ImportError:
    EvolutionFramework = None

try:
    from .evolver.advanced.openspace_evolution import OpenSpaceEvolver
except ImportError:
    OpenSpaceEvolver = None

try:
    from .evolver.advanced.github_learner import GitHubLearner
except ImportError:
    GitHubLearner = None

try:
    from .evolver.advanced.pattern_extractor import PatternExtractor
except ImportError:
    PatternExtractor = None

try:
    from .evolver.advanced.strategy_optimizer import StrategyOptimizer
except ImportError:
    StrategyOptimizer = None

try:
    from .evolver.advanced.incremental_learner import IncrementalLearner
except ImportError:
    IncrementalLearner = None

try:
    from .evolver.advanced.error_healer import ErrorHealer
except ImportError:
    ErrorHealer = None

# =============================================================================
# Plugins - 插件系统
# =============================================================================
try:
    from .plugins.self_healing import SelfHealingPlugin
except ImportError:
    SelfHealingPlugin = None

__all__ = [
    # Version
    "__version__",
    # Core (V4)
    "MemoryService", "Memory", "VectorService", "VectorEntry",
    "ThreeLayerManager", "LayerConfig", "WALLogger",
    "BackupService", "IntegrityChecker", "Issue", "SuperMemoryService",
    # Advanced Core
    "HybridSearch", "HealthMonitor", "ConflictResolver",
    "GitSync", "MemoryVersionControl", "ContextManager",
    "PluginManager", "EventBus",
    # Evolver (V4)
    "SelfHealer", "HealerIssue",
    "SkillRegistry", "Skill",
    "EvolutionManager", "EvolutionResult", "Evolver",
    # Advanced Evolvers
    "EvolutionFramework",
    "OpenSpaceEvolver",
    "GitHubLearner",
    "PatternExtractor",
    "StrategyOptimizer",
    "IncrementalLearner",
    "ErrorHealer",
    # Plugins
    "SelfHealingPlugin",
]
