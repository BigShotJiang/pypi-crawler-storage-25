#!/usr/bin/env python3
"""
SuperMemory - 模块入口
用法: python -m supermemory
"""
from .api import main
main()
