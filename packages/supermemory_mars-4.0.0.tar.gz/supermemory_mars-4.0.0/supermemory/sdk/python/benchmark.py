#!/usr/bin/env python3
"""
SuperMemory Benchmark - 对标 mem0 LOCOMO 基准
测试: 准确性、速度、Token消耗
"""

import time
import json
import statistics
from typing import List, Dict
from super_memory import SuperMemoryClient

class SuperMemoryBenchmark:
    def __init__(self, client: SuperMemoryClient):
        self.client = client
    
    def benchmark_search_accuracy(self, queries: List[Dict]) -> Dict:
        """搜索准确性测试"""
        results = []
        for q in queries:
            start = time.time()
            search_results = self.client.search(q["query"], top_k=q.get("top_k", 5))
            latency = (time.time() - start) * 1000  # ms
            
            # 检查是否命中正确答案
            correct = any(
                q.get("expected_id") == r.get("memory", {}).get("id")
                for r in search_results
            )
            results.append({
                "query": q["query"],
                "latency_ms": latency,
                "correct": correct,
                "results_count": len(search_results)
            })
        
        avg_latency = statistics.mean([r["latency_ms"] for r in results])
        accuracy = sum(1 for r in results if r["correct"]) / len(results) * 100
        
        return {
            "avg_latency_ms": avg_latency,
            "accuracy_percent": accuracy,
            "total_queries": len(results)
        }
    
    def benchmark_throughput(self, num_operations: int = 100) -> Dict:
        """吞吐量测试"""
        times = []
        for i in range(num_operations):
            start = time.time()
            self.client.search(f"test query {i}")
            times.append((time.time() - start) * 1000)
        
        return {
            "avg_latency_ms": statistics.mean(times),
            "p50_latency_ms": statistics.median(times),
            "p95_latency_ms": sorted(times)[int(len(times) * 0.95)],
            "p99_latency_ms": sorted(times)[int(len(times) * 0.99)],
            "ops_per_second": 1000 / statistics.mean(times)
        }
    
    def benchmark_memory_tiering(self) -> Dict:
        """层级效率测试"""
        status = self.client.get_status()
        stats = status.get("layer_stats", {})
        
        total = sum(stats.values())
        hot_ratio = stats.get("hot", 0) / total if total > 0 else 0
        warm_ratio = stats.get("warm", 0) / total if total > 0 else 0
        cold_ratio = stats.get("cold", 0) / total if total > 0 else 0
        
        return {
            "total_memories": total,
            "hot_ratio_percent": hot_ratio * 100,
            "warm_ratio_percent": warm_ratio * 100,
            "cold_ratio_percent": cold_ratio * 100,
            "estimated_token_savings": (warm_ratio * 0.5 + cold_ratio * 0.1) * 100
        }
    
    def run_full_benchmark(self) -> Dict:
        """运行完整基准测试"""
        print("运行 SuperMemory 基准测试...")
        
        # 测试查询
        test_queries = [
            {"query": "用户偏好", "top_k": 5},
            {"query": "项目进展", "top_k": 3},
            {"query": "错误修复", "top_k": 5},
        ]
        
        accuracy = self.benchmark_search_accuracy(test_queries)
        throughput = self.benchmark_throughput(50)
        tiering = self.benchmark_memory_tiering()
        
        return {
            "accuracy": accuracy,
            "throughput": throughput,
            "tiering": tiering,
            "summary": {
                "avg_latency_ms": throughput["avg_latency_ms"],
                "accuracy_percent": accuracy["accuracy_percent"],
                "estimated_token_savings_percent": tiering["estimated_token_savings"]
            }
        }


if __name__ == "__main__":
    client = SuperMemoryClient(agent_id="mars")
    benchmark = SuperMemoryBenchmark(client)
    
    results = benchmark.run_full_benchmark()
    print(json.dumps(results, indent=2, ensure_ascii=False))
