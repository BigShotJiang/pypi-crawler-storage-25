"""
SuperMemory Python SDK
官方Python客户端 - 全面超越 mem0, letta, OpenViking
"""

import requests
import json
from typing import List, Dict, Any, Optional

class SuperMemoryClient:
    """SuperMemory Python SDK 客户端"""
    
    def __init__(
        self,
        base_url: str = os.environ.get("SUPERMEMORY_URL", "http://localhost:8767"),
        agent_id: str = "mars",
        api_key: str = None,
        timeout: int = 30
    ):
        self.base_url = base_url.rstrip('/')
        self.agent_id = agent_id
        self.api_key = api_key
        self.timeout = timeout
        self.session = requests.Session()
        if api_key:
            self.session.headers.update({"Authorization": f"Bearer {api_key}"})
    
    # ==================== 记忆管理 ====================
    
    def add_memory(
        self,
        content: str,
        memory_type: str = "general",
        importance: str = "P2",
        tags: List[str] = None,
        metadata: Dict[str, Any] = None
    ) -> str:
        """添加记忆"""
        data = {
            "action": "add",
            "content": content,
            "type": memory_type,
            "importance": importance,
            "tags": tags or [],
        }
        if metadata:
            data["metadata"] = metadata
        resp = self.session.post(
            f"{self.base_url}/api/{self.agent_id}/actions",
            json=data,
            timeout=self.timeout
        )
        resp.raise_for_status()
        return resp.json().get("id", "")
    
    def search(
        self,
        query: str,
        top_k: int = 10,
        memory_type: str = None,
        importance: str = None,
        time_expr: str = None
    ) -> List[Dict[str, Any]]:
        """语义搜索记忆"""
        data = {
            "action": "search",
            "query": query,
            "top_k": top_k,
        }
        if memory_type:
            data["type"] = memory_type
        if importance:
            data["importance"] = importance
        if time_expr:
            data["time_expr"] = time_expr
        resp = self.session.post(
            f"{self.base_url}/api/{self.agent_id}/actions",
            json=data,
            timeout=self.timeout
        )
        resp.raise_for_status()
        return resp.json().get("results", [])
    
    def get_memory(self, memory_id: str) -> Optional[Dict[str, Any]]:
        """获取单条记忆"""
        resp = self.session.get(
            f"{self.base_url}/api/{self.agent_id}/memories/{memory_id}",
            timeout=self.timeout
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()
    
    def update_memory(
        self,
        memory_id: str,
        content: str = None,
        importance: str = None,
        tags: List[str] = None
    ) -> bool:
        """更新记忆"""
        data = {"action": "update", "id": memory_id}
        if content:
            data["content"] = content
        if importance:
            data["importance"] = importance
        if tags:
            data["tags"] = tags
        resp = self.session.post(
            f"{self.base_url}/api/{self.agent_id}/actions",
            json=data,
            timeout=self.timeout
        )
        resp.raise_for_status()
        return True
    
    def delete_memory(self, memory_id: str) -> bool:
        """删除记忆"""
        resp = self.session.delete(
            f"{self.base_url}/api/{self.agent_id}/memories/{memory_id}",
            timeout=self.timeout
        )
        resp.raise_for_status()
        return True
    
    # ==================== 实体管理 ====================
    
    def add_entity(
        self,
        name: str,
        entity_type: str,
        properties: Dict[str, Any] = None
    ) -> str:
        """添加实体"""
        data = {
            "action": "add_entity",
            "name": name,
            "type": entity_type,
            "properties": properties or {}
        }
        resp = self.session.post(
            f"{self.base_url}/api/{self.agent_id}/actions",
            json=data,
            timeout=self.timeout
        )
        resp.raise_for_status()
        return resp.json().get("id", "")
    
    def link_entities(
        self,
        from_entity: str,
        to_entity: str,
        relation: str
    ) -> bool:
        """关联实体"""
        data = {
            "action": "link_entities",
            "from": from_entity,
            "to": to_entity,
            "relation": relation
        }
        resp = self.session.post(
            f"{self.base_url}/api/{self.agent_id}/actions",
            json=data,
            timeout=self.timeout
        )
        resp.raise_for_status()
        return True
    
    def get_entity_graph(self, entity_id: str = None) -> Dict[str, Any]:
        """获取实体关系图"""
        if entity_id:
            resp = self.session.get(
                f"{self.base_url}/api/{self.agent_id}/entity/{entity_id}",
                timeout=self.timeout
            )
        else:
            resp = self.session.get(
                f"{self.base_url}/api/{self.agent_id}/graph",
                timeout=self.timeout
            )
        resp.raise_for_status()
        return resp.json()
    
    # ==================== 系统状态 ====================
    
    def get_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        resp = self.session.get(
            f"{self.base_url}/api/{self.agent_id}/status",
            timeout=self.timeout
        )
        resp.raise_for_status()
        return resp.json()
    
    def get_metrics(self) -> Dict[str, Any]:
        """获取Prometheus指标"""
        resp = self.session.get(
            f"{self.base_url}/metrics",
            timeout=self.timeout
        )
        resp.raise_for_status()
        return resp.text
    
    def health_check(self) -> bool:
        """健康检查"""
        try:
            resp = self.session.get(f"{self.base_url}/health", timeout=5)
            return resp.status_code == 200
        except:
            return False
    
    # ==================== 便捷方法 ====================
    
    def search_by_time(self, time_expr: str, top_k: int = 10) -> List[Dict]:
        """按时间搜索记忆 (如 '上周', '上个月')"""
        return self.search("", top_k=top_k, time_expr=time_expr)
    
    def search_by_importance(self, min_level: str = "P1", top_k: int = 10) -> List[Dict]:
        """按重要性搜索 (P0/P1/P2/P3)"""
        return self.search("", top_k=top_k, importance=min_level)
    
    def get_layer_distribution(self) -> Dict[str, int]:
        """获取层级分布"""
        status = self.get_status()
        return status.get("layer_stats", {})


# ==================== 使用示例 ====================

if __name__ == "__main__":
    # 初始化客户端
    client = SuperMemoryClient(agent_id="mars")
    
    # 添加记忆
    memory_id = client.add_memory(
        content="用户偏好深色模式和vim键绑定",
        memory_type="preference",
        importance="P1",
        tags=["用户偏好", "UI"]
    )
    print(f"添加记忆成功: {memory_id}")
    
    # 搜索记忆
    results = client.search("用户界面偏好")
    for r in results:
        print(f"  - {r['memory']['content'][:50]}")
    
    # 获取状态
    status = client.get_status()
    print(f"记忆总数: {status['memory_count']}")
    print(f"层级分布: {status['layer_stats']}")
