from setuptools import setup, find_packages

setup(
    name="super-memory",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.8",
    description="SuperMemory - Self-evolving memory system for AI Agents",
    author="SuperMemory Team",
    author_email="team@supermemory.ai",
    url="https://github.com/supermemory",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
