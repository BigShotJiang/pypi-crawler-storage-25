#!/usr/bin/env python3
"""
SuperMemory CLI - 命令行工具
支持: 记忆搜索/添加/列表, 实体管理, 系统状态
"""

import argparse
import json
import sys
from super_memory import SuperMemoryClient

def main():
    parser = argparse.ArgumentParser(description="SuperMemory CLI")
    parser.add_argument("--agent", default="mars", help="Agent ID")
    parser.add_argument("--url", default=os.environ.get("SUPERMEMORY_URL", "http://localhost:8767"), help="API URL (or set SUPERMEMORY_URL env var)")
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # 添加记忆
    add_parser = subparsers.add_parser("add", help="添加记忆")
    add_parser.add_argument("content", help="记忆内容")
    add_parser.add_argument("--type", "-t", default="general", help="类型")
    add_parser.add_argument("--importance", "-i", default="P2", help="重要性")
    add_parser.add_argument("--tags", nargs="+", help="标签")
    
    # 搜索记忆
    search_parser = subparsers.add_parser("search", help="搜索记忆")
    search_parser.add_argument("query", help="搜索查询")
    search_parser.add_argument("--top-k", "-k", type=int, default=10, help="返回数量")
    
    # 列出记忆
    list_parser = subparsers.add_parser("list", help="列出记忆")
    list_parser.add_argument("--limit", "-n", type=int, default=20, help="数量")
    
    # 实体管理
    entity_parser = subparsers.add_parser("entity", help="实体管理")
    entity_parser.add_argument("--add", help="添加实体")
    entity_parser.add_argument("--type", default="person", help="实体类型")
    entity_parser.add_argument("--link", nargs=3, metavar=("FROM", "REL", "TO"), help="关联实体")
    
    # 系统状态
    status_parser = subparsers.add_parser("status", help="系统状态")
    
    # 层级分布
    layers_parser = subparsers.add_parser("layers", help="层级分布")
    
    # 健康检查
    health_parser = subparsers.add_parser("health", help="健康检查")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    client = SuperMemoryClient(base_url=args.url, agent_id=args.agent)
    
    if args.command == "add":
        mem_id = client.add_memory(
            content=args.content,
            memory_type=args.type,
            importance=args.importance,
            tags=args.tags
        )
        print(f"记忆添加成功: {mem_id}")
    
    elif args.command == "search":
        results = client.search(args.query, top_k=args.top_k)
        print(f"找到 {len(results)} 条结果:")
        for i, r in enumerate(results, 1):
            mem = r.get('memory', {})
            print(f"  {i}. [{mem.get('importance','?')}] {mem.get('content','')[:60]}... (score={r.get('score',0):.3f})")
    
    elif args.command == "list":
        # 简单列表
        status = client.get_status()
        print(f"记忆总数: {status.get('memory_count', 'N/A')}")
        print(f"向量数: {status.get('vector_count', 'N/A')}")
        print(f"插件数: {status.get('plugin_count', 'N/A')}")
    
    elif args.command == "entity":
        if args.add:
            entity_id = client.add_entity(args.add, args.type)
            print(f"实体添加成功: {entity_id}")
        elif args.link:
            client.link_entities(args.link[0], args.link[2], args.link[1])
            print(f"实体关联成功")
        else:
            graph = client.get_entity_graph()
            print(json.dumps(graph, indent=2, ensure_ascii=False))
    
    elif args.command == "status":
        status = client.get_status()
        print(json.dumps(status, indent=2, ensure_ascii=False))
    
    elif args.command == "layers":
        dist = client.get_layer_distribution()
        print("层级分布:")
        for layer, count in dist.items():
            print(f"  {layer}: {count}")
    
    elif args.command == "health":
        if client.health_check():
            print("✅ SuperMemory 运行正常")
        else:
            print("❌ SuperMemory 未运行")
            sys.exit(1)

if __name__ == "__main__":
    main()
