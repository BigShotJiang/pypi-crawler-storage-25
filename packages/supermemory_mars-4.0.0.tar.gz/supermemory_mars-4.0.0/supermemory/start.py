#!/usr/bin/env python3
"""
SuperMemory - 一键启动脚本
用法: python -m supermemory.start
"""
import sys
import os

# 添加包路径
SUPERMEMORY_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SUPERMEMORY_ROOT)

from supermemory.api import main

if __name__ == "__main__":
    main()
