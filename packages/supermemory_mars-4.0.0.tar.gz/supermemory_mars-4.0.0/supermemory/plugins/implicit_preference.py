"""
I03 - 隐式偏好提取插件
自动提取用户未明确表达的偏好
"""

import logging
import re
from typing import Dict, Any, List, Optional
from collections import defaultdict
from .base import Plugin

logger = logging.getLogger(__name__)


class ImplicitPreferencePlugin(Plugin):
    """
    隐式偏好提取插件
    
    核心能力：
    1. 从对话/行为中提取未明确表达的偏好
    2. 分析语气、频率、上下文推断偏好
    3. 建立和维护用户偏好画像
    4. 实时更新偏好强度
    """
    
    name = "implicit_preference"
    version = "1.0.0"
    description = "隐式偏好提取 - 自动提取用户未明确表达的偏好"
    core = False
    dependencies = []
    
    # 偏好模式识别
    PREFERENCE_PATTERNS = {
        "time_preference": [
            (r"早上|上午|晨", "morning_person"),
            (r"下午|午后", "afternoon_person"),
            (r"晚上|夜间|深夜", "night_owl"),
        ],
        "communication_style": [
            (r"简洁|简短|扼要", "concise"),
            (r"详细|完整|展开", "detailed"),
            (r"直接|开门见山", "direct"),
            (r"委婉|绕弯子", "indirect"),
        ],
        "tech_preference": [
            (r"简单|易用|傻瓜", "simple_tech"),
            (r"高级|强大|专业", "advanced_tech"),
            (r"自动化|自动", "automation_preference"),
            (r"手动|可控", "manual_control"),
        ],
        "quality_vs_speed": [
            (r"质量|品质|精确", "quality_focus"),
            (r"速度|快|高效", "speed_focus"),
            (r"先做|再说|迭代", "iterative"),
        ],
    }
    
    NEGATIVE_SIGNALS = [r"不对", r"不是", r"错了", r"不好", r"不满意", r"不行", r"没用", r"不要"]
    POSITIVE_SIGNALS = [r"对", r"是", r"好", r"可以", r"满意", r"不错", r"喜欢", r"要"]
    
    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self._preference_profile: Dict[str, float] = defaultdict(float)
        self._preference_evidence: Dict[str, List[Dict]] = defaultdict(list)
        self._min_evidence_threshold = config.get("min_evidence", 3) if config else 3
        self._decay_factor = config.get("decay_factor", 0.95) if config else 0.95
    
    def _register_handlers(self):
        """注册事件处理器"""
        # 订阅对话事件
        self.event_bus.subscribe("conversation.message", self._on_message)
        self.event_bus.subscribe("memory.created", self._on_memory_created)
        self.event_bus.subscribe("preference.extract", self._on_extract_request)
    
    def _on_message(self, data: Dict):
        """处理对话消息"""
        text = data.get("text", "")
        if text:
            prefs = self.extract_preferences(text, data.get("context"))
            if prefs:
                self.update_preference_profile(prefs)
                # 发布提取的偏好
                self.event_bus.emit("preference.extracted", {
                    "preferences": prefs,
                    "source": data.get("source", "unknown")
                })
    
    def _on_memory_created(self, data: Dict):
        """处理记忆创建事件"""
        content = data.get("content", "")
        if content:
            prefs = self.extract_preferences(content, data.get("context"))
            if prefs:
                self.update_preference_profile(prefs)
    
    def _on_extract_request(self, data: Dict):
        """处理显式提取请求"""
        text = data.get("text", "")
        if text:
            prefs = self.extract_preferences(text, data.get("context"))
            return prefs
        return []
    
    def extract_preferences(self, text: str, context: Dict = None) -> List[Dict[str, Any]]:
        """从文本中提取隐式偏好"""
        extracted = []
        text_lower = text.lower()
        
        for category, patterns in self.PREFERENCE_PATTERNS.items():
            for pattern, preference in patterns:
                if re.search(pattern, text_lower):
                    strength = self._calculate_strength(text, pattern, category)
                    extracted.append({
                        "category": category,
                        "preference": preference,
                        "strength": strength,
                        "source": "pattern_match",
                        "evidence": self._extract_evidence(text, pattern)
                    })
        
        positive_count = len(re.findall('|'.join(self.POSITIVE_SIGNALS), text_lower))
        negative_count = len(re.findall('|'.join(self.NEGATIVE_SIGNALS), text_lower))
        
        if positive_count > negative_count:
            extracted.append({
                "category": "sentiment",
                "preference": "positive_reception",
                "strength": min(positive_count / 5.0, 1.0),
                "source": "sentiment_analysis"
            })
        elif negative_count > positive_count:
            extracted.append({
                "category": "sentiment", 
                "preference": "negative_feedback",
                "strength": min(negative_count / 5.0, 1.0),
                "source": "sentiment_analysis",
                "is_correction": True
            })
        
        frequency_prefs = self._analyze_frequency(text)
        extracted.extend(frequency_prefs)
        
        return extracted
    
    def _calculate_strength(self, text: str, pattern: str, category: str) -> float:
        matches = len(re.findall(pattern, text.lower()))
        base_strength = min(matches * 0.3, 1.0)
        category_weights = {"time_preference": 1.0, "communication_style": 1.2, "tech_preference": 1.5, "quality_vs_speed": 1.0}
        return min(base_strength * category_weights.get(category, 1.0), 1.0)
    
    def _extract_evidence(self, text: str, pattern: str) -> str:
        match = re.search(f'.{{0,20}}{pattern}.{{0,20}}', text, re.IGNORECASE)
        return match.group(0) if match else ""
    
    def _analyze_frequency(self, text: str) -> List[Dict]:
        results = []
        words = text.split()
        word_freq = defaultdict(int)
        for word in words:
            if len(word) > 2:
                word_freq[word] += 1
        for word, freq in word_freq.items():
            if freq >= 3:
                results.append({
                    "category": "emphasis",
                    "preference": f"emphasis_on_{word}",
                    "strength": min(freq * 0.2, 1.0),
                    "source": "frequency_analysis",
                    "evidence": f"'{word}' 重复 {freq} 次"
                })
        return results
    
    def update_preference_profile(self, preferences: List[Dict]):
        """更新用户偏好画像"""
        for pref in preferences:
            key = f"{pref['category']}:{pref['preference']}"
            strength = pref.get('strength', 0.5)
            current = self._preference_profile[key]
            new_strength = current * self._decay_factor + strength * (1 - self._decay_factor)
            self._preference_profile[key] = new_strength
            self._preference_evidence[key].append({**pref, "timestamp": self.event_bus._clock.now().isoformat() if hasattr(self.event_bus, '_clock') else ""})
    
    def get_preference_profile(self) -> Dict[str, float]:
        """获取当前偏好画像"""
        return {k: v for k, v in self._preference_profile.items() if len(self._preference_evidence[k]) >= self._min_evidence_threshold}
    
    def predict_next_action(self, context: Dict = None) -> List[str]:
        """预测用户下一步可能想要的操作"""
        predictions = []
        profile = self.get_preference_profile()
        if profile.get("communication_style:concise", 0) > 0.6:
            predictions.append("简洁回复")
        if profile.get("tech_preference:simple_tech", 0) > 0.6:
            predictions.append("简单方案")
        if profile.get("quality_vs_speed:speed_focus", 0) > 0.6:
            predictions.append("快速方案")
        return predictions
