"""Emotion Detection Plugin"""

import re
from typing import Dict, Any, Optional, List
from datetime import datetime

from .base import Plugin


class EmotionPlugin(Plugin):
    """
    情绪识别插件
    分析记忆和交互中的情绪色彩，标记情感状态
    """

    name = "emotion"
    version = "1.0.0"
    description = "Emotion detection and sentiment analysis"
    core = False
    dependencies = []

    POSITIVE_PATTERNS = [
        r"\b(开心|高兴|快乐|满意|喜欢|棒|好|赞|优秀|完美)\b",
        r"\b(happy|glad|pleased|love|great|awesome|perfect|excellent)\b",
    ]
    NEGATIVE_PATTERNS = [
        r"\b(难过|伤心|生气|愤怒|讨厌|糟糕|差|失望|不满)\b",
        r"\b(sad|angry|upset|hate|bad|terrible|awful|disappointed)\b",
    ]
    ANXIOUS_PATTERNS = [
        r"\b(担心|焦虑|紧张|害怕|不安|忧虑|压力|困惑)\b",
        r"\b(worried|anxious|nervous|afraid|stressed|confused)\b",
    ]
    URGENT_PATTERNS = [
        r"\b(紧急|马上|立刻|立即|急|快|赶紧|十万火急)\b",
        r"\b(urgent|immediately|asap|emergency|hurry|critical)\b",
    ]

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self._compile_patterns()

    def _compile_patterns(self) -> None:
        self._positive_re = [re.compile(p, re.IGNORECASE) for p in self.POSITIVE_PATTERNS]
        self._negative_re = [re.compile(p, re.IGNORECASE) for p in self.NEGATIVE_PATTERNS]
        self._anxious_re = [re.compile(p, re.IGNORECASE) for p in self.ANXIOUS_PATTERNS]
        self._urgent_re = [re.compile(p, re.IGNORECASE) for p in self.URGENT_PATTERNS]

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=20)
        self.subscribe("memory.update", self._on_memory_update, priority=20)
        self.subscribe("interaction.user_message", self._on_user_message, priority=20)
        self.subscribe("emotion.analyze", self._on_emotion_analyze, priority=50)

    def _detect_emotion(self, text: str) -> Dict[str, Any]:
        """检测文本情绪"""
        scores = {
            "positive": 0,
            "negative": 0,
            "anxious": 0,
            "urgent": 0,
        }
        tags = []

        for pattern in self._positive_re:
            scores["positive"] += len(pattern.findall(text))
        for pattern in self._negative_re:
            scores["negative"] += len(pattern.findall(text))
        for pattern in self._anxious_re:
            scores["anxious"] += len(pattern.findall(text))
        for pattern in self._urgent_re:
            scores["urgent"] += len(pattern.findall(text))

        max_score = max(scores.values())
        if max_score > 0:
            dominant = max(scores, key=scores.get)
            if scores[dominant] >= 1:
                tags.append(dominant)

        confidence = min(max_score / 3.0, 1.0) if max_score > 0 else 0.0
        return {"dominant": tags[0] if tags else "neutral", "scores": scores, "tags": tags, "confidence": confidence}

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        text = data.get("content", "") or data.get("text", "")
        if text:
            emotion = self._detect_emotion(str(text))
            data["emotion"] = emotion
            self.emit("emotion.detected", {"memory_id": data.get("id"), **emotion})

    def _on_memory_update(self, data: Dict[str, Any]) -> None:
        text = data.get("content", "") or data.get("text", "")
        if text:
            emotion = self._detect_emotion(str(text))
            data["emotion"] = emotion
            self.emit("emotion.detected", {"memory_id": data.get("id"), **emotion})

    def _on_user_message(self, data: Dict[str, Any]) -> None:
        text = data.get("text", "") or data.get("content", "")
        if text:
            emotion = self._detect_emotion(str(text))
            self.emit("emotion.detected", {"source": "user_message", **emotion})

    def _on_emotion_analyze(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        text = data.get("text")
        if not text:
            return None
        result = self._detect_emotion(str(text))
        self.emit("emotion.analysis_completed", result)
        return result

    def get_status(self) -> Dict[str, Any]:
        return {"plugin": self.name, "version": self.version}
