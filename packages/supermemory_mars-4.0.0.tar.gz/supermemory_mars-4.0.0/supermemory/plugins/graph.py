"""Knowledge Graph Plugin - 支持 SQLite 持久化"""

import json
import sqlite3
from typing import Dict, Any, Optional, List, Set, Tuple
from datetime import datetime
from collections import defaultdict, deque
from pathlib import Path

from .base import Plugin


class GraphPlugin(Plugin):
    """
    知识图谱插件
    构建和维护记忆间的关联图谱，支持关系查询和图遍历
    """

    name = "graph"
    version = "1.0.0"
    description = "Knowledge graph for memory relationships"
    core = False
    dependencies = []

    RELATION_TYPES = [
        "related_to",
        "causes",
        "depends_on",
        "similar_to",
        "contradicts",
        "part_of",
        "precedes",
        "follows",
        "references",
    ]

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        data_dir = config.get("data_dir", "/tmp") if config else "/tmp"
        self.db_path = Path(data_dir) / "graph.db"
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._edges: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._adjacency: Dict[str, Set[str]] = defaultdict(set)
        self._relation_index: Dict[str, List[str]] = defaultdict(list)
        self._init_db()
        self._load_from_db()

    def _init_db(self):
        """初始化 SQLite 数据库"""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS graph_nodes (
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS graph_edges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                node_from TEXT NOT NULL,
                node_to TEXT NOT NULL,
                relation TEXT NOT NULL,
                weight REAL DEFAULT 1.0,
                metadata TEXT DEFAULT '{}',
                created_at TEXT NOT NULL,
                UNIQUE(node_from, node_to, relation)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_edge_from ON graph_edges(node_from)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_edge_relation ON graph_edges(relation)")
        conn.commit()
        conn.close()

    def _load_from_db(self):
        """从 SQLite 加载已有数据到内存"""
        if not self.db_path.exists():
            return
        try:
            conn = sqlite3.connect(str(self.db_path))
            # 加载节点
            for row in conn.execute("SELECT id, data FROM graph_nodes"):
                node_id, data_json = row
                self._nodes[node_id] = json.loads(data_json)
            # 加载边
            for row in conn.execute("SELECT node_from, node_to, relation, weight, metadata, created_at FROM graph_edges"):
                from_id, to_id, relation, weight, meta_json, created_at = row
                edge = {"from": from_id, "to": to_id, "relation": relation, "weight": weight, "metadata": json.loads(meta_json), "created_at": created_at}
                self._edges[from_id].append(edge)
                self._adjacency[from_id].add(to_id)
                self._relation_index[relation].append(from_id)
            conn.close()
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"图谱加载失败: {e}")

    def _save_node_to_db(self, node_id: str, data: dict, created_at: str):
        """持久化节点到 SQLite"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute("""
                INSERT OR REPLACE INTO graph_nodes (id, data, created_at, updated_at)
                VALUES (?, ?, ?, ?)
            """, (node_id, json.dumps(data, ensure_ascii=False), created_at, datetime.now().isoformat()))
            conn.commit()
            conn.close()
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"节点保存失败: {e}")

    def _save_edge_to_db(self, from_id: str, to_id: str, relation: str, weight: float, metadata: dict, created_at: str):
        """持久化边到 SQLite"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute("""
                INSERT OR IGNORE INTO graph_edges (node_from, node_to, relation, weight, metadata, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (from_id, to_id, relation, weight, json.dumps(metadata, ensure_ascii=False), created_at))
            conn.commit()
            conn.close()
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"边保存失败: {e}")

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=20)
        self.subscribe("memory.update", self._on_memory_update, priority=20)
        self.subscribe("graph.add_node", self._on_add_node, priority=50)
        self.subscribe("graph.add_edge", self._on_add_edge, priority=50)
        self.subscribe("graph.query", self._on_graph_query, priority=50)
        self.subscribe("graph.traverse", self._on_graph_traverse, priority=50)
        self.subscribe("graph.get_neighbors", self._on_get_neighbors, priority=50)

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        """自动为记忆创建节点"""
        memory_id = data.get("id")
        if memory_id:
            self._add_node(memory_id, {
                "type": "memory",
                "content": data.get("content", ""),
                "tags": data.get("tags", []),
                "entities": data.get("entities", []),
                "created_at": datetime.now().isoformat(),
            })

    def _on_memory_update(self, data: Dict[str, Any]) -> None:
        """更新节点信息"""
        memory_id = data.get("id")
        if memory_id and memory_id in self._nodes:
            self._nodes[memory_id].update({
                "content": data.get("content", ""),
                "tags": data.get("tags", []),
                "entities": data.get("entities", []),
                "updated_at": datetime.now().isoformat(),
            })

    def _add_node(self, node_id: str, data: Dict[str, Any]) -> None:
        created_at = datetime.now().isoformat()
        if node_id not in self._nodes:
            self._nodes[node_id] = {"id": node_id, "created_at": created_at}
        self._nodes[node_id].update(data)
        self._save_node_to_db(node_id, self._nodes[node_id], created_at)

    def _on_add_node(self, data: Dict[str, Any]) -> None:
        node_id = data.get("id")
        node_data = data.get("data", {})
        if node_id:
            self._add_node(node_id, node_data)
            self.emit("graph.node_added", {"id": node_id})

    def _on_add_edge(self, data: Dict[str, Any]) -> None:
        """添加关系边"""
        from_id = data.get("from")
        to_id = data.get("to")
        relation = data.get("relation", "related_to")
        weight = data.get("weight", 1.0)

        if not from_id or not to_id:
            self.emit("graph.edge_failed", {"error": "Missing from/to"})
            return

        edge = {
            "from": from_id,
            "to": to_id,
            "relation": relation,
            "weight": weight,
            "metadata": {},
            "created_at": datetime.now().isoformat(),
        }

        self._edges[from_id].append(edge)
        self._adjacency[from_id].add(to_id)
        self._relation_index[relation].append(from_id)

        # 持久化到 SQLite
        self._save_edge_to_db(from_id, to_id, relation, weight, {}, edge["created_at"])

        self.emit("graph.edge_added", edge)

    def _on_graph_query(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """查询图数据"""
        query_type = data.get("query_type")
        if query_type == "node":
            node_id = data.get("id")
            result = self._nodes.get(node_id)
        elif query_type == "path":
            result = self._find_path(data.get("from"), data.get("to"), data.get("max_depth", 5))
        else:
            result = None
        self.emit("graph.query_result", {"query_type": query_type, "result": result})
        return result

    def _on_graph_traverse(self, data: Dict[str, Any]) -> List[str]:
        """图遍历"""
        start = data.get("start")
        mode = data.get("mode", "bfs")  # bfs or dfs
        max_depth = data.get("max_depth", 3)
        relation = data.get("relation")

        if not start:
            return []

        if mode == "bfs":
            result = self._bfs_traverse(start, max_depth, relation)
        else:
            result = self._dfs_traverse(start, max_depth, relation)

        self.emit("graph.traverse_result", {"start": start, "nodes": result, "count": len(result)})
        return result

    def _bfs_traverse(
        self, start: str, max_depth: int, relation: Optional[str] = None
    ) -> List[str]:
        visited = {start}
        queue = deque([(start, 0)])
        result = []

        while queue:
            node, depth = queue.popleft()
            if depth >= max_depth:
                continue
            for neighbor in self._adjacency.get(node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    result.append(neighbor)
                    queue.append((neighbor, depth + 1))
        return result

    def _dfs_traverse(
        self, start: str, max_depth: int, relation: Optional[str] = None, visited: Optional[Set[str]] = None
    ) -> List[str]:
        if visited is None:
            visited = set()
        if start in visited or max_depth < 0:
            return []
        visited.add(start)
        result = [start]
        for neighbor in self._adjacency.get(start, []):
            result.extend(self._dfs_traverse(neighbor, max_depth - 1, relation, visited))
        return result

    def _find_path(self, from_id: str, to_id: str, max_depth: int = 5) -> Optional[List[str]]:
        """BFS查找两点间路径"""
        if not from_id or not to_id:
            return None
        if from_id == to_id:
            return [from_id]

        queue = deque([(from_id, [from_id])])
        visited = {from_id}

        while queue:
            node, path = queue.popleft()
            if len(path) > max_depth:
                continue
            for neighbor in self._adjacency.get(node, []):
                if neighbor == to_id:
                    return path + [neighbor]
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        return None

    def _on_get_neighbors(self, data: Dict[str, Any]) -> List[Dict[str, Any]]:
        node_id = data.get("id")
        relation = data.get("relation")
        if not node_id:
            return []
        neighbors = []
        for edge in self._edges.get(node_id, []):
            if relation is None or edge.get("relation") == relation:
                neighbors.append(edge)
        self.emit("graph.neighbors", {"id": node_id, "neighbors": neighbors})
        return neighbors

    def get_status(self) -> Dict[str, Any]:
        return {
            "node_count": len(self._nodes),
            "edge_count": sum(len(v) for v in self._edges.values()),
            "relation_types": list(self._relation_index.keys()),
        }
