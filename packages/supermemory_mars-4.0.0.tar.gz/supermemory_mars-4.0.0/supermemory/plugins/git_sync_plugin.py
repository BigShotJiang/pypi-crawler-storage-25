"""Git Sync Plugin - Git-based memory synchronization with conflict resolution"""

import os
import time
from datetime import datetime
from typing import Dict, Any, Optional, List

from .base import Plugin
from ..git_sync import GitSync, Conflict, ConflictMarker


class GitSyncPlugin(Plugin):
    """
    Git同步插件
    基于Git的跨设备记忆同步，带冲突检测与解决
    对标engram的Git Sync功能
    """

    name = "git_sync"
    version = "1.0.0"
    description = "Git-based cross-device memory synchronization with conflict resolution"
    core = True
    dependencies = ["core_wal"]

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self.repo_path = config.get("repo_path", "./data/memory-git") if config else "./data/memory-git"
        self.remote_name = config.get("remote", "origin") if config else "origin"
        self.auto_sync_interval = config.get("auto_sync_interval", 60) if config else 60
        self.auto_resolve = config.get("auto_resolve", True) if config else True
        self.resolve_strategy = config.get("resolve_strategy", "newest") if config else "newest"

        # 初始化GitSync服务
        self._git_sync = GitSync(self.repo_path)
        self._last_sync: Optional[float] = None
        self._sync_in_progress = False
        self._change_queue: List[Dict] = []
        self._device_id = config.get("device_id", "local") if config else "local"

    def _register_handlers(self) -> None:
        """注册事件处理器"""
        # 记忆变更事件
        self.subscribe("memory.write", self._on_memory_write, priority=20)
        self.subscribe("memory.update", self._on_memory_update, priority=20)
        self.subscribe("memory.delete", self._on_memory_delete, priority=20)

        # 同步控制事件
        self.subscribe("sync.push", self._on_sync_push, priority=50)
        self.subscribe("sync.pull", self._on_sync_pull, priority=50)
        self.subscribe("sync.full", self._on_sync_full, priority=50)
        self.subscribe("sync.status", self._on_sync_status, priority=50)

        # 冲突解决事件
        self.subscribe("conflict.resolve", self._on_conflict_resolve, priority=50)
        self.subscribe("conflict.list", self._on_conflict_list, priority=50)

        # 系统节拍
        self.subscribe("system.tick", self._on_tick, priority=5)

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        """记忆写入时记录变更"""
        memory_id = data.get("id")
        if memory_id:
            self._queue_change({
                "type": "write",
                "memory_id": memory_id,
                "content": data.get("content", ""),
                "timestamp": time.time(),
                "device_id": self._device_id
            })

    def _on_memory_update(self, data: Dict[str, Any]) -> None:
        """记忆更新时记录变更"""
        memory_id = data.get("id")
        if memory_id:
            self._queue_change({
                "type": "update",
                "memory_id": memory_id,
                "content": data.get("content", ""),
                "timestamp": time.time(),
                "device_id": self._device_id
            })

    def _on_memory_delete(self, data: Dict[str, Any]) -> None:
        """记忆删除时记录变更"""
        memory_id = data.get("id")
        if memory_id:
            self._queue_change({
                "type": "delete",
                "memory_id": memory_id,
                "timestamp": time.time(),
                "device_id": self._device_id
            })

    def _queue_change(self, change: Dict) -> None:
        """将变更加入队列"""
        self._change_queue.append(change)
        # 限制队列大小
        if len(self._change_queue) > 100:
            self._change_queue.pop(0)

    def _on_sync_push(self, data: Optional[Dict[str, Any]] = None) -> None:
        """推送本地更改到远程"""
        if self._sync_in_progress:
            self.emit("sync.push.skipped", {"reason": "Sync in progress"})
            return

        self._sync_in_progress = True
        try:
            report = self._git_sync.sync(self.remote_name)

            if report["conflicts"]:
                self.emit("sync.conflicts_found", {
                    "count": len(report["conflicts"]),
                    "conflicts": report["conflicts"]
                })

                # 自动解决冲突
                if self.auto_resolve:
                    self._auto_resolve_conflicts()

            if report["success"]:
                self._last_sync = time.time()
                self.emit("sync.push.completed", report)
            else:
                self.emit("sync.push.failed", {"message": report.get("message", "Unknown error")})

        finally:
            self._sync_in_progress = False

    def _on_sync_pull(self, data: Optional[Dict[str, Any]] = None) -> None:
        """从远程拉取更改"""
        if self._sync_in_progress:
            self.emit("sync.pull.skipped", {"reason": "Sync in progress"})
            return

        self._sync_in_progress = True
        try:
            # fetch + pull
            report = self._git_sync.sync(self.remote_name)

            # 检查冲突
            conflicts = self._git_sync.get_conflicts()
            if conflicts:
                self.emit("sync.conflicts_found", {
                    "count": len(conflicts),
                    "conflicts": conflicts
                })

            if report["success"]:
                self._last_sync = time.time()
                self.emit("sync.pull.completed", report)
            else:
                self.emit("sync.pull.failed", {"message": report.get("message", "Unknown error")})

        finally:
            self._sync_in_progress = False

    def _on_sync_full(self, data: Optional[Dict[str, Any]] = None) -> None:
        """执行完整同步（push + pull）"""
        if self._sync_in_progress:
            self.emit("sync.full.skipped", {"reason": "Sync in progress"})
            return

        self._sync_in_progress = True
        try:
            report = self._git_sync.sync(self.remote_name)

            if report["conflicts"]:
                self._auto_resolve_conflicts()
                # 重新同步以推送解决后的结果
                report = self._git_sync.sync(self.remote_name)

            self._last_sync = time.time()
            self.emit("sync.full.completed", report)

        finally:
            self._sync_in_progress = False

    def _on_sync_status(self, data: Optional[Dict[str, Any]] = None) -> None:
        """获取同步状态"""
        status = self._git_sync.get_sync_status()
        status["last_sync"] = self._last_sync
        status["sync_in_progress"] = self._sync_in_progress
        status["pending_changes"] = len(self._change_queue)
        self.emit("sync.status.result", status)

    def _on_conflict_resolve(self, data: Dict[str, Any]) -> None:
        """解决冲突"""
        file_path = data.get("file_path")
        strategy = data.get("strategy", self.resolve_strategy)
        custom_content = data.get("custom_content")

        if not file_path:
            self.emit("conflict.resolve.failed", {"error": "No file_path provided"})
            return

        success = self._git_sync.resolve_conflict(file_path, strategy, custom_content)

        if success:
            self.emit("conflict.resolved", {
                "file_path": file_path,
                "strategy": strategy
            })
        else:
            self.emit("conflict.resolve.failed", {"file_path": file_path})

    def _on_conflict_list(self, data: Optional[Dict[str, Any]] = None) -> None:
        """列出所有冲突"""
        conflicts = self._git_sync.get_conflicts()
        self.emit("conflict.list.result", {
            "count": len(conflicts),
            "conflicts": conflicts
        })

    def _auto_resolve_conflicts(self) -> None:
        """自动解决所有冲突"""
        for conflict in self._git_sync.conflicts:
            self._git_sync.resolve_conflict(conflict.file_path, self.resolve_strategy)
            self.emit("conflict.auto_resolved", {
                "file_path": conflict.file_path,
                "strategy": self.resolve_strategy
            })
        # 清空冲突列表
        self._git_sync.conflicts.clear()

    def _on_tick(self, data: Optional[Dict[str, Any]] = None) -> None:
        """定期自动同步"""
        if self._sync_in_progress:
            return

        # 检查是否需要同步
        should_sync = False

        # 有待处理的更改
        if self._change_queue:
            should_sync = True

        # 超过自动同步间隔
        if self._last_sync and (time.time() - self._last_sync) >= self.auto_sync_interval:
            should_sync = True

        # 立即同步间隔已到但从未同步过
        if not self._last_sync and self._change_queue:
            should_sync = True

        if should_sync:
            self._on_sync_push()

    def get_status(self) -> Dict[str, Any]:
        """获取插件状态"""
        sync_status = self._git_sync.get_sync_status()
        return {
            "repo_path": self.repo_path,
            "remote": self.remote_name,
            "last_sync": self._last_sync,
            "sync_in_progress": self._sync_in_progress,
            "pending_changes": len(self._change_queue),
            "auto_resolve": self.auto_resolve,
            "resolve_strategy": self.resolve_strategy,
            "conflicts_pending": sync_status.get("pending_conflicts", 0),
            "is_clean": sync_status.get("is_clean", True)
        }

    def set_remote(self, name: str, url: str) -> bool:
        """设置远程仓库"""
        return self._git_sync.add_remote(name, url)

    def export_backup(self, output_dir: str = None) -> str:
        """导出备份"""
        if output_dir:
            return self._git_sync.export_memories(output_dir)
        return self._git_sync.export_memories()

    def import_backup(self, source: str) -> bool:
        """导入备份"""
        return self._git_sync.import_memories(source)
