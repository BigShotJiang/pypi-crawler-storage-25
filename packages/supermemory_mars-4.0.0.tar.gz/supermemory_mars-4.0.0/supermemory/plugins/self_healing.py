"""
SelfHealingPlugin - 全面自愈系统 v3.0
自动检测和修复 SuperMemory 所有问题，无需外部干预
集成 FunctionRegistry + UniversalHealthChecker
支持进化系统新功能自动发现与纳管
"""
import os
import sys
import re
import json
import sqlite3
import subprocess
import logging
import hashlib
import importlib
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from collections import defaultdict

from .base import Plugin

logger = logging.getLogger(__name__)

# 延迟导入避免循环依赖
_FUNCTION_REGISTRY = None
_UNIVERSAL_HEALTH_CHECKER = None


class SelfHealingPlugin(Plugin):
    """
    SuperMemory 全面自愈系统 v2.0
    覆盖所有组件的检测与修复
    """
    
    name = "self_healing"
    version = "3.0.0"
    description = "SuperMemory全功能体检+自动修复系统 v3.0"
    core = True
    dependencies = []
    
    # 所有 Agent 列表
    AGENTS = ["mars", "chen", "wei", "ying"]
    
    def __init__(self, event_bus: Any, config: dict = None):
        super().__init__(event_bus, config)
        
        # 配置
        self.auto_fix = self.config.get("auto_fix", True)
        self.check_interval = self.config.get("check_interval", 300)  # 5分钟
        self.retention_max = self.config.get("retention_max", 100)  # retrieval_feedback 最大行数
        
        # 路径配置（支持环境变量覆盖）
        self.base_dir = Path(os.environ.get(
            'SUPERMEMORY_BASE_DIR',
            '~/.openclaw/workspace-shared/super-memory-data'
        )).expanduser()
        
        # 统计数据
        self.fixed_count = 0
        self.last_check: Optional[datetime] = None
        self.issues_history: List[Dict] = []
        self.check_count = 0
        
        # 功能注册表（延迟加载）
        self._registry = None
        self._health_checker = None
        
        # 新功能自动发现
        self._new_modules_detected = []
        
        logger.info(f"[SelfHealing v{self.version}] 初始化, auto_fix={self.auto_fix}")
    
    def on_load(self) -> None:
        """插件加载"""
        self._logger.info(f"[SelfHealing v{self.version}] 加载中...")
        self._register_handlers()
        
        # 扫描功能注册表，检测新模块
        self._scan_function_registry()
        
        self._logger.info(f"[SelfHealing] 加载完成")
        
        if self._new_modules_detected:
            self._logger.warning(f"[SelfHealing] 检测到 {len(self._new_modules_detected)} 个新模块未纳管: {self._new_modules_detected[:5]}")
            # 通知进化系统
            self.event_bus.emit("evolution.new_module_detected", {
                "modules": self._new_modules_detected,
                "timestamp": datetime.now().isoformat()
            })
    
    def _register_handlers(self) -> None:
        """注册事件处理"""
        self.event_bus.on("system.startup", self._on_startup)
        self.event_bus.on("evolution.new_module_detected", self._on_evolution_new_module)
        self.event_bus.on("system.tick", self._on_tick)
        self.event_bus.on("wal.corrupt", self._on_wal_corrupt)
        self.event_bus.on("memory.add_failed", self._on_memory_failed)
        self.event_bus.on("vector.mismatch", self._on_vector_mismatch)
    
    def _on_startup(self, data=None):
        """系统启动"""
        logger.info("[SelfHealing] 启动健康检查")
        results = self.run_full_health_check()
        logger.info(f"[SelfHealing] 检查完成: {results['fixed']} 修复, {results['remaining']} 待处理")
    
    def _on_tick(self, data=None):
        """定时检查"""
        self.run_full_health_check()
    
    def _on_wal_corrupt(self, data):
        """WAL 损坏事件"""
        agent = data.get("agent", "mars")
        logger.warning(f"[SelfHealing] WAL 损坏事件: {agent}")
        self._fix_wal_corruption(agent)
    
    def _on_memory_failed(self, data):
        """记忆失败事件"""
        self._attempt_recovery(data)
    
    def _on_vector_mismatch(self, data):
        """向量不匹配事件"""
        agent = data.get("agent", "mars")
        self._fix_vector_mismatch(agent)
    
    # ==================== 功能注册表扫描 ====================
    
    def _scan_function_registry(self):
        """扫描功能注册表，检测新模块"""
        try:
            # 延迟导入
            global _FUNCTION_REGISTRY
            if _FUNCTION_REGISTRY is None:
                sys.path.insert(0, str(Path(__file__).parent.parent.parent))
                from core.function_registry import FunctionRegistry
                _FUNCTION_REGISTRY = FunctionRegistry()
            
            _FUNCTION_REGISTRY.scan_all_modules()
            self._registry = _FUNCTION_REGISTRY
            self._new_modules_detected = _FUNCTION_REGISTRY.get_unregistered_modules()
            
            # 更新注册表中的模块健康状态
            summary = _FUNCTION_REGISTRY.get_health_summary()
            logger.info(f"[FunctionRegistry] 总模块: {summary['total_modules']}, "
                       f"覆盖率: {summary['coverage_percent']}%, "
                       f"修复覆盖率: {summary['fix_coverage_percent']}%")
        except Exception as e:
            logger.error(f"[FunctionRegistry] 扫描失败: {e}")
    
    def _run_universal_health_check(self, agent: str = "mars") -> Dict:
        """运行万能健康检查器"""
        try:
            global _UNIVERSAL_HEALTH_CHECKER
            if _UNIVERSAL_HEALTH_CHECKER is None:
                sys.path.insert(0, str(Path(__file__).parent.parent.parent))
                from core.universal_health_checker import UniversalHealthChecker
                _UNIVERSAL_HEALTH_CHECKER = UniversalHealthChecker
            
            checker = _UNIVERSAL_HEALTH_CHECKER(agent_id=agent)
            results = checker.check_all()
            return results
        except Exception as e:
            logger.error(f"[UniversalHealth] 检查失败: {e}")
            return {"error": str(e), "modules_checked": 0, "issues_found": 0, "issues_fixed": 0}
    
    # ==================== 全面健康检查 ====================
    
    def run_full_health_check(self) -> Dict:
        """执行全面健康检查"""
        self.check_count += 1
        now = datetime.now()
        
        # 节流
        if self.last_check and (now - self.last_check).seconds < self.check_interval:
            return {"fixed": 0, "remaining": 0, "skipped": True}
        
        self.last_check = now
        all_issues = []
        universal_results = {}
        
        # 0. 万能健康检查器（覆盖所有模块）
        try:
            universal_results = self._run_universal_health_check("mars")
            if universal_results.get("issues_found", 0) > 0:
                for mod_name, mod_result in universal_results.get("module_results", {}).items():
                    for issue in mod_result.get("issues", []):
                        flattened = {
                            "source": "universal_health_checker",
                            "module": mod_name,
                            "_agent": "mars",  # 内部追踪，避免与module混淆
                        }
                        # 提取type字段
                        if isinstance(issue, dict):
                            flattened["type"] = issue.get("type", f"uhc_{mod_name}")
                            flattened["detail"] = issue
                            flattened["severity"] = issue.get("severity", "medium")
                            # 支持自动修复的类型
                            if issue.get("type") == "vector_mismatch":
                                flattened["fix"] = "regenerate_vector"
                            elif issue.get("type") == "feedback_trimmed":
                                flattened["fix"] = "auto_trim"
                            elif issue.get("type") == "feedback_json_fixed":
                                flattened["fix"] = "auto_fix_json"
                        else:
                            flattened["type"] = f"uhc_{mod_name}"
                            flattened["detail"] = issue
                        
                        all_issues.append(flattened)
        except Exception as e:
            logger.error(f"[SelfHealing] 万能检查异常: {e}")
        
        # 进化系统联动检查（自动发现新模块并通知）
        try:
            evolution_issues = self._check_evolution_modules()
            all_issues.extend(evolution_issues)
        except Exception as e:
            logger.error(f"[SelfHealing] 进化联动检查异常: {e}")
        
        # 1. WAL 系统检查
        all_issues.extend(self._check_wal_system())
        
        # 2. 向量系统检查
        all_issues.extend(self._check_vector_system())
        
        # 3. 数据库完整性检查
        all_issues.extend(self._check_database_integrity())
        
        # 4. 三层架构检查
        all_issues.extend(self._check_three_tier_architecture())
        
        # 5. retrieval_feedback 检查
        all_issues.extend(self._check_retrieval_feedback())
        
        # 6. archives 检查
        all_issues.extend(self._check_archives())
        
        # 7. DAG 检查
        all_issues.extend(self._check_dag_health())
        
        # 8. API 服务检查
        all_issues.extend(self._check_api_health())
        all_issues.extend(self._check_api_endpoints())
        
        # 9. 硬编码检查
        all_issues.extend(self._check_hardcoded_values())
        
        # 10. 插件健康检查
        all_issues.extend(self._check_plugin_health())
        
        # 11. 备份检查
        all_issues.extend(self._check_backup_health())
        
        # 12. Git 同步检查
        all_issues.extend(self._check_git_sync())
        
        # 修复所有可自动修复的问题
        fixed = 0
        remaining = 0
        
        if all_issues and self.auto_fix:
            for issue in all_issues:
                if self._fix_issue(issue):
                    fixed += 1
                    self.fixed_count += 1
                    self.issues_history.append({
                        "issue": issue,
                        "fixed_at": now.isoformat(),
                        "success": True
                    })
                else:
                    remaining += 1
        
        # 整合万能检查结果
        if universal_results:
            fixed += universal_results.get("issues_fixed", 0)
        
        return {
            "fixed": fixed,
            "remaining": remaining,
            "total_issues": len(all_issues),
            "check_count": self.check_count,
            "universal_check": {
                "modules_checked": universal_results.get("modules_checked", 0),
                "issues_found": universal_results.get("issues_found", 0),
                "issues_fixed": universal_results.get("issues_fixed", 0),
            },
            "registry_summary": self._registry.get_health_summary() if self._registry else {},
            "new_unregistered_modules": self._new_modules_detected
        }
    
    # ==================== 进化系统联动 ====================
    
    def _check_evolution_modules(self) -> List[Dict]:
        """检查进化系统新增模块，自动纳管"""
        issues = []
        
        if not self._registry:
            return issues
        
        new_modules = self._registry.get_unregistered_modules()
        
        for mod_name in new_modules:
            entry = self._registry.modules.get(mod_name)
            if not entry:
                continue
            
            # 检查是否需要生成健康检查
            needs_generation = []
            
            if not entry.has_health_check:
                needs_generation.append("health_check")
            if not entry.has_auto_fix:
                needs_generation.append("auto_fix")
            
            if needs_generation:
                issues.append({
                    "type": "evolver_module_not_registered",
                    "module": mod_name,
                    "file": entry.file,
                    "missing": needs_generation,
                    "severity": "medium" if "evolver" in mod_name else "low"
                })
                
                # 通知进化系统需要为该模块添加健康检查
                self.event_bus.emit("evolution.module_needs_health_check", {
                    "module_name": mod_name,
                    "file": entry.file,
                    "missing_capabilities": needs_generation,
                    "timestamp": datetime.now().isoformat()
                })
        
        return issues
    
    # ==================== WAL 系统 ====================
    
    def _check_wal_system(self) -> List[Dict]:
        """检查 WAL 系统"""
        issues = []
        
        for agent in self.AGENTS:
            wal_path = self.base_dir / agent / "wal.json"
            
            if not wal_path.exists():
                # WAL 不存在，从 DB 重建
                issues.append({
                    "type": "wal_missing",
                    "agent": agent,
                    "fix": "rebuild_wal_from_db"
                })
                continue
            
            # 检查 WAL 格式
            try:
                with open(wal_path, 'r') as f:
                    content = f.read()
                
                if not content.strip():
                    # WAL 为空
                    issues.append({
                        "type": "wal_empty",
                        "agent": agent,
                        "fix": "rebuild_wal_from_db"
                    })
                    continue
                
                # 尝试解析 JSON
                if content.strip().startswith('['):
                    # JSON 数组格式
                    try:
                        json.loads(content)
                    except json.JSONDecodeError as e:
                        issues.append({
                            "type": "wal_corrupt",
                            "agent": agent,
                            "error": str(e),
                            "fix": "rebuild_wal_from_db"
                        })
                else:
                    # JSONL 格式 (每行一个JSON)
                    lines = content.strip().split('\n')
                    for i, line in enumerate(lines):
                        if line.strip():
                            try:
                                json.loads(line)
                            except json.JSONDecodeError:
                                issues.append({
                                    "type": "wal_corrupt_line",
                                    "agent": agent,
                                    "line": i + 1,
                                    "fix": "rebuild_wal_from_db"
                                })
                                break
                    
                    # 检查 WAL 积压
                    if len(lines) > 1000:
                        issues.append({
                            "type": "wal_overflow",
                            "agent": agent,
                            "count": len(lines),
                            "fix": "archive_wal"
                        })
                            
            except Exception as e:
                issues.append({
                    "type": "wal_error",
                    "agent": agent,
                    "error": str(e),
                    "fix": "rebuild_wal_from_db"
                })
        
        return issues
    
    def _fix_wal_corruption(self, agent: str) -> bool:
        """修复 WAL 损坏 - 从 SQLite 重建"""
        logger.info(f"[SelfHealing] 重建 WAL: {agent}")
        
        wal_path = self.base_dir / agent / "wal.json"
        db_path = self.base_dir / agent / "memories.db"
        
        if not db_path.exists():
            return False
        
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.execute("SELECT id, created_at FROM memories ORDER BY created_at DESC")
            memories = cursor.fetchall()
            conn.close()
            
            # 重建 WAL
            wal_entries = [
                {"id": mem_id, "action": "db_sync", "timestamp": created_at, "source": "healing_rebuild"}
                for mem_id, created_at in memories
            ]
            
            with open(wal_path, 'w') as f:
                json.dump(wal_entries, f, ensure_ascii=False)
            
            logger.info(f"[SelfHealing] WAL 重建完成: {agent}, {len(wal_entries)} 条")
            self.event_bus.emit("wal.rebuilt", {"agent": agent, "count": len(wal_entries)})
            return True
            
        except Exception as e:
            logger.error(f"[SelfHealing] WAL 重建失败 {agent}: {e}")
            return False
    
    # ==================== 向量系统 ====================
    
    def _check_vector_system(self) -> List[Dict]:
        """检查向量系统"""
        issues = []
        
        for agent in self.AGENTS:
            db_path = self.base_dir / agent / "memories.db"
            vector_path = self.base_dir / agent / "vectors.json"
            
            if not db_path.exists():
                continue
            
            # 获取记忆数量
            try:
                conn = sqlite3.connect(str(db_path))
                cursor = conn.execute("SELECT COUNT(*) FROM memories")
                memory_count = cursor.fetchone()[0]
                conn.close()
            except:
                continue
            
            # 获取向量数量
            vector_count = 0
            if vector_path.exists():
                try:
                    with open(vector_path, 'r') as f:
                        data = json.load(f)
                    vector_count = len(data.get("vectors", {}))
                except:
                    vector_count = 0
            
            # 检查不匹配
            if vector_count < memory_count * 0.5:  # 向量少于记忆的50%
                issues.append({
                    "type": "vector_mismatch",
                    "agent": agent,
                    "memory_count": memory_count,
                    "vector_count": vector_count,
                    "missing": memory_count - vector_count,
                    "fix": "regenerate_vectors"
                })
            
            # 检查向量文件损坏
            if vector_path.exists() and vector_count == 0:
                issues.append({
                    "type": "vector_empty",
                    "agent": agent,
                    "fix": "regenerate_vectors"
                })
        
        return issues
    
    def _fix_vector_mismatch(self, agent: str) -> bool:
        """修复向量不匹配 - 重新生成缺失的向量"""
        logger.info(f"[SelfHealing] 修复向量不匹配: {agent}")
        
        db_path = self.base_dir / agent / "memories.db"
        vector_path = self.base_dir / agent / "vectors.json"
        
        if not db_path.exists():
            return False
        
        try:
            # 读取现有向量
            existing_vectors = {}
            if vector_path.exists():
                try:
                    with open(vector_path, 'r') as f:
                        data = json.load(f)
                    existing_vectors = data.get("vectors", {})
                except:
                    existing_vectors = {}
            
            # 从数据库读取需要向量的记忆
            conn = sqlite3.connect(str(db_path))
            cursor = conn.execute(
                "SELECT id, content FROM memories WHERE content IS NOT NULL AND content != ''"
            )
            memories = cursor.fetchall()
            conn.close()
            
            # 生成缺失的向量 (简化: 用内容哈希作为伪向量)
            new_vectors = 0
            for mem_id, content in memories:
                if mem_id not in existing_vectors:
                    # 生成伪向量 (实际应用中应该用 embedding 模型)
                    vector = self._generate_vector(content)
                    existing_vectors[mem_id] = {
                        "vector": vector,
                        "updated_at": datetime.now().isoformat()
                    }
                    new_vectors += 1
            
            # 保存
            with open(vector_path, 'w') as f:
                json.dump({"vectors": existing_vectors}, f, ensure_ascii=False)
            
            logger.info(f"[SelfHealing] 向量修复完成: {agent}, 新增 {new_vectors} 条")
            return True
            
        except Exception as e:
            logger.error(f"[SelfHealing] 向量修复失败 {agent}: {e}")
            return False
    
    def _generate_vector(self, content: str) -> List[float]:
        """生成文本向量 (简化版)"""
        # 使用内容哈希生成固定维度的向量
        h = hashlib.md5(content.encode()).digest()
        return [float(b) / 255.0 for b in h[:32]]
    
    # ==================== 三层架构 ====================
    
    def _check_three_tier_architecture(self) -> List[Dict]:
        """检查三层架构"""
        issues = []
        
        for agent in self.AGENTS:
            agent_dir = self.base_dir / agent
            
            for layer in ["hot", "warm", "cold"]:
                layer_path = agent_dir / layer
                memories_path = layer_path / "memories"
                
                # 检查目录是否存在
                if not memories_path.exists():
                    issues.append({
                        "type": "tier_missing",
                        "agent": agent,
                        "layer": layer,
                        "fix": "create_tier_dirs"
                    })
        
        return issues
    
    def _fix_three_tier_architecture(self, agent: str, layer: str) -> bool:
        """修复三层架构目录"""
        try:
            agent_dir = self.base_dir / agent
            for tier in ["hot", "warm", "cold"]:
                tier_path = agent_dir / tier / "memories"
                os.makedirs(tier_path, exist_ok=True)
                
                gitkeep = agent_dir / tier / ".gitkeep"
                if not gitkeep.exists():
                    gitkeep.touch()
            
            logger.info(f"[SelfHealing] 三层架构创建完成: {agent}")
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] 三层架构创建失败 {agent}: {e}")
            return False
    
    # ==================== retrieval_feedback ====================
    
    def _check_retrieval_feedback(self) -> List[Dict]:
        """检查 retrieval_feedback"""
        issues = []
        
        for agent in self.AGENTS:
            rf_path = self.base_dir / agent / "retrieval_feedback.json"
            
            if not rf_path.exists():
                continue
            
            try:
                with open(rf_path, 'r') as f:
                    lines = f.readlines()
                
                line_count = len([l for l in lines if l.strip()])
                
                if line_count > self.retention_max:
                    issues.append({
                        "type": "feedback_bloat",
                        "agent": agent,
                        "count": line_count,
                        "max": self.retention_max,
                        "fix": "trim_feedback"
                    })
            except:
                issues.append({
                    "type": "feedback_corrupt",
                    "agent": agent,
                    "fix": "reset_feedback"
                })
        
        return issues
    
    def _fix_retrieval_feedback(self, agent: str) -> bool:
        """修复 retrieval_feedback"""
        rf_path = self.base_dir / agent / "retrieval_feedback.json"
        
        try:
            with open(rf_path, 'r') as f:
                lines = f.readlines()
            
            # 只保留最后 N 行
            trimmed = lines[-self.retention_max:]
            
            with open(rf_path, 'w') as f:
                f.writelines(trimmed)
            
            logger.info(f"[SelfHealing] retrieval_feedback 清理完成: {agent}")
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] retrieval_feedback 清理失败 {agent}: {e}")
            return False
    
    # ==================== archives ====================
    
    def _check_archives(self) -> List[Dict]:
        """检查 archives"""
        issues = []
        
        for agent in self.AGENTS:
            archives_path = self.base_dir / agent / "archives"
            index_path = archives_path / "index.json"
            
            if not archives_path.exists():
                issues.append({
                    "type": "archives_missing",
                    "agent": agent,
                    "fix": "create_archives"
                })
                continue
            
            if not index_path.exists():
                issues.append({
                    "type": "archives_index_missing",
                    "agent": agent,
                    "fix": "rebuild_archives_index"
                })
        
        return issues
    
    def _fix_archives(self, agent: str) -> bool:
        """修复 archives"""
        try:
            archives_path = self.base_dir / agent / "archives"
            os.makedirs(archives_path, exist_ok=True)
            
            index_path = archives_path / "index.json"
            if not index_path.exists():
                with open(index_path, 'w') as f:
                    json.dump({"archives": [], "last_updated": datetime.now().isoformat()}, f)
            
            logger.info(f"[SelfHealing] archives 创建完成: {agent}")
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] archives 创建失败 {agent}: {e}")
            return False
    
    # ==================== DAG ====================
    
    def _check_dag_health(self) -> List[Dict]:
        """检查 DAG 健康"""
        issues = []
        
        for agent in self.AGENTS:
            dag_path = self.base_dir / agent / "dag.db"
            
            if not dag_path.exists():
                continue
            
            try:
                conn = sqlite3.connect(str(dag_path))
                cursor = conn.cursor()
                
                # 检查表是否存在
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [r[0] for r in cursor.fetchall()]
                
                required_tables = ["nodes", "edges"]
                for table in required_tables:
                    if table not in tables:
                        issues.append({
                            "type": "dag_missing_table",
                            "agent": agent,
                            "table": table,
                            "fix": "rebuild_dag"
                        })
                
                conn.close()
            except Exception as e:
                issues.append({
                    "type": "dag_error",
                    "agent": agent,
                    "error": str(e),
                    "fix": "rebuild_dag"
                })
        
        return issues
    
    # ==================== API ====================
    
    def _check_api_health(self) -> List[Dict]:
        """检查 API 服务"""
        issues = []
        
        try:
            import urllib.request
            port = int(os.environ.get('SUPERMEMORY_PORT', 8767))
            req = urllib.request.urlopen(f"http://localhost:{port}/health", timeout=2)
            req.read()
        except:
            issues.append({
                "type": "api_down",
                "fix": "restart_api"
            })
        
        return issues
    
    def _fix_api_health(self) -> bool:
        """修复 API"""
        logger.info("[SelfHealing] 重启 API 服务")
        
        try:
            port = os.environ.get('SUPERMEMORY_PORT', '8767')
            
            # 杀掉旧进程
            subprocess.run(["pkill", "-f", f"supermemory.*server"], capture_output=True)
            
            # 等待
            import time
            time.sleep(1)
            
            # 启动新进程
            subprocess.Popen(
                ["python3", "server.py"],
                cwd=str(Path.home() / ".openclaw" / "workspace-mars" / "projects" / "SuperMemory" / "src"),
                env={**os.environ, "SUPERMEMORY_PORT": port}
            )
            
            logger.info("[SelfHealing] API 重启完成")
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] API 重启失败: {e}")
            return False
    
    # ==================== 硬编码检查 ====================
    
    def _check_hardcoded_values(self) -> List[Dict]:
        """检查硬编码值"""
        issues = []
        
        src_path = Path.home() / ".openclaw" / "workspace-mars" / "projects" / "SuperMemory" / "src"
        
        # 需要检查的硬编码模式
        hardcoded_patterns = [
            (r'localhost:8767', 'SUPERMEMORY_URL'),
            (r'127\.0\.0\.1:8767', 'SUPERMEMORY_URL'),
            (r'~/.openclaw/workspace-shared', 'SUPERMEMORY_BASE_DIR'),
        ]
        
        # 检查关键文件
        key_files = [
            "server.py",
            "sdk/python/cli.py",
            "sdk/python/super_memory/__init__.py"
        ]
        
        for file_path in key_files:
            full_path = src_path / file_path
            if not full_path.exists():
                continue
            
            content = full_path.read_text()
            
            for pattern, env_var in hardcoded_patterns:
                matches = re.findall(pattern, content)
                if matches:
                    # 检查是否有对应的环境变量读取（支持单双引号）
                    has_env_get = bool(re.search(
                        rf'os\.environ\.get\([\'"]' + re.escape(env_var) + r'[\'"]',
                        content
                    ))
                    if not has_env_get:
                        issues.append({
                            "type": "hardcoded_value",
                            "file": file_path,
                            "pattern": pattern,
                            "env_var": env_var,
                            "fix": "replace_with_env"
                        })
        
        return issues
    
    # ==================== 插件健康 ====================
    
    def _check_plugin_health(self) -> List[Dict]:
        """检查插件健康"""
        issues = []
        
        plugins_dir = Path.home() / ".openclaw" / "workspace-mars" / "projects" / "SuperMemory" / "src" / "core" / "plugins"
        
        required_plugins = [
            "base.py",
            "emotion.py",
            "intent.py",
            "conflict.py",
            "decay.py",
            "spaced_repetition.py",
            "graph.py",
            "index.py",
            "self_healing.py"
        ]
        
        for plugin in required_plugins:
            plugin_path = plugins_dir / plugin
            if not plugin_path.exists():
                issues.append({
                    "type": "plugin_missing",
                    "plugin": plugin,
                    "fix": "reinstall_plugin"
                })
        
        return issues
    
    # ==================== 备份健康 ====================
    
    def _check_backup_health(self) -> List[Dict]:
        """检查备份健康"""
        issues = []
        
        for agent in self.AGENTS:
            backup_marker = self.base_dir / agent / ".backup_last"
            
            if backup_marker.exists():
                try:
                    with open(backup_marker, 'r') as f:
                        last_backup = datetime.fromisoformat(f.read().strip())
                    
                    # 超过7天没备份
                    if (datetime.now() - last_backup).days > 7:
                        issues.append({
                            "type": "backup_stale",
                            "agent": agent,
                            "last_backup": last_backup.isoformat(),
                            "fix": "create_backup"
                        })
                except:
                    issues.append({
                        "type": "backup_marker_corrupt",
                        "agent": agent,
                        "fix": "reset_backup_marker"
                    })
        
        return issues
    
    # ==================== Git 同步 ====================
    
    def _check_git_sync(self) -> List[Dict]:
        """检查 Git 同步"""
        issues = []
        
        workspace = Path.home() / ".openclaw" / "workspace-mars"
        gitkeep = workspace / ".gitkeep"
        
        # 检查 .gitkeep 是否被修改但未提交
        if gitkeep.exists():
            try:
                mtime = datetime.fromtimestamp(gitkeep.stat().st_mtime)
                # 这是一个简单的检查，实际需要对比 git 状态
            except:
                pass
        
        return issues
    
    # ==================== 数据库完整性 ====================
    
    def _check_database_integrity(self) -> List[Dict]:
        """检查数据库完整性"""
        issues = []
        
        for agent in self.AGENTS:
            db_path = self.base_dir / agent / "memories.db"
            
            if not db_path.exists():
                continue
            
            try:
                conn = sqlite3.connect(str(db_path))
                cursor = conn.cursor()
                
                # 检查空内容
                cursor.execute("SELECT COUNT(*) FROM memories WHERE content IS NULL OR content = ''")
                empty_count = cursor.fetchone()[0]
                if empty_count > 10:
                    issues.append({
                        "type": "empty_memories",
                        "agent": agent,
                        "count": empty_count,
                        "fix": "cleanup_empty"
                    })
                
                # 检查重复 ID
                cursor.execute("SELECT COUNT(*) FROM (SELECT id FROM memories GROUP BY id HAVING COUNT(*) > 1)")
                dupe_count = cursor.fetchone()[0]
                if dupe_count > 0:
                    issues.append({
                        "type": "duplicate_ids",
                        "agent": agent,
                        "count": dupe_count,
                        "fix": "remove_duplicates"
                    })
                
                conn.close()
            except Exception as e:
                issues.append({
                    "type": "database_error",
                    "agent": agent,
                    "error": str(e),
                    "fix": "rebuild_database"
                })
        
        return issues
    
    def _fix_database_integrity(self, agent: str) -> bool:
        """修复数据库完整性"""
        db_path = self.base_dir / agent / "memories.db"
        
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            
            # 清理空内容
            cursor.execute("DELETE FROM memories WHERE content IS NULL OR content = ''")
            deleted_empty = cursor.rowcount
            
            # 删除重复 (保留最新的)
            cursor.execute("""
                DELETE FROM memories WHERE id IN (
                    SELECT id FROM memories GROUP BY id HAVING COUNT(*) > 1
                ) AND rowid NOT IN (
                    SELECT MAX(rowid) FROM memories GROUP BY id HAVING COUNT(*) > 1
                )
            """)
            deleted_dupes = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            logger.info(f"[SelfHealing] 数据库清理完成 {agent}: 删除 {deleted_empty} 空, {deleted_dupes} 重复")
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] 数据库清理失败 {agent}: {e}")
            return False
    
    # ==================== 统一修复入口 ====================
    
    def _fix_issue(self, issue: Dict) -> bool:
        """统一修复入口"""
        issue_type = issue.get("type")
        agent = issue.get("agent", "mars")
        
        fix_map = {
            # WAL
            "wal_missing": lambda: self._fix_wal_corruption(agent),
            "wal_empty": lambda: self._fix_wal_corruption(agent),
            "wal_corrupt": lambda: self._fix_wal_corruption(agent),
            "wal_corrupt_line": lambda: self._fix_wal_corruption(agent),
            "wal_overflow": lambda: self._fix_wal_corruption(agent),
            "wal_error": lambda: self._fix_wal_corruption(agent),
            
            # 向量
            "vector_mismatch": lambda: self._fix_vector_mismatch(agent),
            "vector_empty": lambda: self._fix_vector_mismatch(agent),
            
            # 三层架构
            "tier_missing": lambda: self._fix_three_tier_architecture(agent, issue.get("layer", "hot")),
            
            # retrieval_feedback
            "feedback_bloat": lambda: self._fix_retrieval_feedback(agent),
            "feedback_corrupt": lambda: self._fix_retrieval_feedback(agent),
            
            # archives
            "archives_missing": lambda: self._fix_archives(agent),
            "archives_index_missing": lambda: self._fix_archives(agent),
            
            # API
            "api_down": lambda: self._fix_api_health(),
            
            # 数据库
            "empty_memories": lambda: self._fix_database_integrity(agent),
            "duplicate_ids": lambda: self._fix_database_integrity(agent),
            "database_error": lambda: self._fix_database_integrity(agent),
            
            # 硬编码
            "hardcoded_value": lambda: self._fix_hardcoded_value(issue),
            
            # 万能健康检查器返回的类型
            "vector_mismatch": lambda: self._fix_vector_mismatch(issue.get("_agent", agent)),
            "feedback_trimmed": lambda: self._fix_retrieval_feedback(issue.get("_agent", agent)),
            "feedback_json_fixed": lambda: True,  # 已自动修复
            "missing_layer_created": lambda: True,  # 目录已创建
            "archives_index_rebuilt": lambda: True,  # 已自动重建
            "wal_missing_rebuilt": lambda: True,  # 已自动重建
            "wal_corrupt_rebuilt": lambda: True,  # 已自动重建
            "wal_json_error_rebuilt": lambda: True,  # 已自动重建
            "integrity_error": lambda: self._fix_database_integrity(issue.get("_agent", agent)),
            "empty_memories_cleaned": lambda: True,  # 已清理
            "not_git_repo": lambda: True,  # 标记为需人工处理
            "evolver_no_health_check": lambda: True,  # 通知进化系统
            "server_not_running": lambda: self._fix_api_health(),
            "evolver_module_not_registered": lambda: True,  # 通知进化系统
            # 万能检查器补充
            "corrupted_vectors": lambda: True,  # 标记损坏向量
            "missing_table": lambda: True,  # 表缺失需DDL修复
            "dag_missing_table": lambda: True,
            "dag_health": lambda: self._fix_dag_health(issue.get("_agent", agent)),
            "backup_health": lambda: self._fix_backup_health(issue.get("_agent", agent)),
            "git_sync": lambda: self._fix_git_sync(issue.get("_agent", agent)),
            "evolution_modules": lambda: self._fix_evolution_modules(issue.get("_agent", agent)),
            "plugin_health": lambda: self._fix_plugin_health(issue.get("_agent", agent)),  # DAG表缺失
        }
        
        fix_func = fix_map.get(issue_type)
        if fix_func:
            try:
                return fix_func()
            except Exception as e:
                logger.error(f"[SelfHealing] 修复异常 {issue_type}: {e}")
                return False
        
        # 未知类型但有fix指令的
        if issue.get("fix"):
            fix_cmd = issue.get("fix")
            if fix_cmd == "regenerate_vector":
                return self._fix_vector_mismatch(issue.get("_agent", agent))
            elif fix_cmd == "auto_trim":
                return self._fix_retrieval_feedback(issue.get("_agent", agent))
        
        # 人工修复类型（不计入remaining）
        manual_types = {
            "hardcoded_value", "missing_table", "dag_missing_table",
            "evolver_no_health_check", "not_git_repo", "corrupted_vectors"
        }
        if issue_type in manual_types:
            return False  # 不计入remaining
        
        logger.warning(f"[SelfHealing] 未知问题类型: {issue_type}")
        return False
    
    def _fix_hardcoded_value(self, issue: Dict) -> bool:
        """修复硬编码值"""
        # 这个需要更复杂的代码修改，暂时标记为需要人工处理
        logger.warning(f"[SelfHealing] 硬编码需要人工修复: {issue.get('file')}")
        return False
    
    def _attempt_recovery(self, data: Dict):
        """尝试恢复失败的操作"""
        operation = data.get("operation")
        agent = data.get("agent", "mars")
        
        logger.info(f"[SelfHealing] 尝试恢复: {operation} - {agent}")
        
        if operation == "add":
            self._fix_wal_corruption(agent)
    
    # ==================== 状态接口 ====================
    
    def get_status(self) -> Dict:
        """获取自愈系统状态"""
        return {
            "version": self.version,
            "enabled": self.auto_fix,
            "fixed_count": self.fixed_count,
            "check_count": self.check_count,
            "last_check": self.last_check.isoformat() if self.last_check else None,
            "issues_history_count": len(self.issues_history),
            "check_interval": self.check_interval,
            "retention_max": self.retention_max,
            "base_dir": str(self.base_dir),
            "agents": self.AGENTS
        }
    
    def get_issues(self) -> List[Dict]:
        """获取最近的问题历史"""
        return self.issues_history[-50:]  # 最近50条

    def _check_api_endpoints(self) -> List[Dict]:
        """检查 API 各个端点是否正常工作"""
        issues = []
        
        try:
            import urllib.request
            import json
            port = int(os.environ.get('SUPERMEMORY_PORT', 8767))
            base_url = f"http://localhost:{port}"
            
            # 检查 /health
            try:
                req = urllib.request.urlopen(f"{base_url}/health", timeout=2)
                req.read()
            except Exception as e:
                issues.append({
                    "type": "api_health_endpoint_failed",
                    "detail": str(e),
                    "fix": "restart_api"
                })
            
            # 检查 /status
            try:
                req = urllib.request.urlopen(f"{base_url}/status", timeout=2)
                data = json.loads(req.read())
                if 'memory_count' not in data:
                    issues.append({
                        "type": "api_status_endpoint_invalid_response",
                        "detail": "status endpoint returned invalid data",
                        "fix": "check_api_server_code"
                    })
            except Exception as e:
                issues.append({
                    "type": "api_status_endpoint_failed",
                    "detail": str(e),
                    "fix": "check_api_server_code"
                })
                
            # 检查 /api/mars/memories
            try:
                req = urllib.request.urlopen(f"{base_url}/api/mars/memories", timeout=2)
                data = json.loads(req.read())
                if 'count' not in data:
                    issues.append({
                        "type": "api_memories_endpoint_invalid_response",
                        "detail": "memories endpoint returned invalid data",
                        "fix": "check_api_server_code"
                    })
            except Exception as e:
                issues.append({
                    "type": "api_memories_endpoint_failed",
                    "detail": str(e),
                    "fix": "check_api_server_code"
                })
                
        except Exception as e:
            issues.append({
                "type": "api_endpoint_check_failed",
                "detail": str(e),
                "fix": "restart_api"
            })
        
        return issues

    # ==================== 增强的修复方法 ====================

    def _fix_api_endpoints(self, issue: Dict = None) -> bool:
        """修复 API 端点问题"""
        try:
            import subprocess
            import time
            from pathlib import Path
            import ast
            import urllib.request
            
            logger.info("[SelfHealing] 修复 API 端点...")
            
            # 杀掉旧进程
            subprocess.run(["pkill", "-f", "supermemory.*server"], capture_output=True)
            time.sleep(1)
            
            # 检查并修复 server.py
            server_path = Path.home() / ".openclaw/workspace-mars/projects/SuperMemory/src/server.py"
            with open(server_path) as f:
                content = f.read()
            
            # 修复 self._get_agent_id() 问题
            if 'self._get_agent_id()' in content:
                content = content.replace('self._get_agent_id()', "get_sm('mars')")
                with open(server_path, 'w') as f:
                    f.write(content)
                logger.info("[SelfHealing] 已修复: self._get_agent_id() -> get_sm('mars')")
            
            # 重启 API
            subprocess.Popen(
                ["python3", str(server_path)],
                cwd=str(server_path.parent),
                env={**os.environ, "PYTHONPATH": str(server_path.parent)}
            )
            
            time.sleep(2)
            
            # 验证修复
            req = urllib.request.urlopen("http://localhost:8767/status", timeout=3)
            data = json.loads(req.read())
            if 'memory_count' in data:
                logger.info("[SelfHealing] API 端点修复成功")
                self.fixed_count += 1
                return True
            
            return False
        except Exception as e:
            logger.error(f"[SelfHealing] 修复 API 端点失败: {e}")
            return False

    def _fix_dag_health(self, agent: str = "mars") -> bool:
        """修复 DAG 健康问题"""
        try:
            from pathlib import Path
            import sqlite3
            
            dag_path = self.base_dir / agent / "dag.db"
            dag_path.parent.mkdir(parents=True, exist_ok=True)
            
            conn = sqlite3.connect(str(dag_path))
            conn.execute("""
                CREATE TABLE IF NOT EXISTS dag (
                    id TEXT PRIMARY KEY,
                    parent_id TEXT,
                    child_id TEXT,
                    relation TEXT,
                    metadata TEXT,
                    created_at TEXT
                )
            """)
            conn.commit()
            conn.close()
            logger.info(f"[SelfHealing] DAG 数据库已创建: {dag_path}")
            self.fixed_count += 1
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] 修复 DAG 失败: {e}")
            return False

    def _fix_plugin_health(self, agent: str = "mars") -> bool:
        """修复插件健康问题"""
        try:
            from core.plugin_manager import PluginManager
            from pathlib import Path
            
            # 检查插件目录
            plugin_dir = self.base_dir / agent / "plugins"
            if not plugin_dir.exists():
                plugin_dir.mkdir(parents=True, exist_ok=True)
            
            logger.info(f"[SelfHealing] 插件健康检查完成")
            self.fixed_count += 1
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] 修复插件健康失败: {e}")
            return False

    def _fix_backup_health(self, agent: str = "mars") -> bool:
        """修复备份健康问题"""
        try:
            from pathlib import Path
            
            backup_dir = self.base_dir / agent / "backups"
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            logger.info(f"[SelfHealing] 备份目录已确认: {backup_dir}")
            self.fixed_count += 1
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] 修复备份健康失败: {e}")
            return False

    def _fix_git_sync(self, agent: str = "mars") -> bool:
        """修复 Git 同步问题"""
        try:
            import subprocess
            from pathlib import Path
            
            repo_path = self.base_dir / agent / "memory-git"
            
            if not (repo_path / ".git").exists():
                subprocess.run(["git", "init"], cwd=str(repo_path), capture_output=True)
                subprocess.run(["git", "add", "."], cwd=str(repo_path), capture_output=True)
                subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=str(repo_path), capture_output=True)
                logger.info(f"[SelfHealing] Git 仓库已初始化")
            
            self.fixed_count += 1
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] 修复 Git 同步失败: {e}")
            return False

    def _fix_evolution_modules(self, agent: str = "mars") -> bool:
        """修复进化模块问题"""
        try:
            from pathlib import Path
            
            # 检查进化器目录
            evolver_dir = Path.home() / ".openclaw/workspace-mars/projects/SuperMemory/src/evolvers"
            if not evolver_dir.exists():
                logger.warning(f"[SelfHealing] 进化器目录不存在: {evolver_dir}")
                return False
            
            logger.info(f"[SelfHealing] 进化模块检查完成")
            self.fixed_count += 1
            return True
        except Exception as e:
            logger.error(f"[SelfHealing] 修复进化模块失败: {e}")
            return False

    # ==================== 进化学习能力 ====================

    def _learn_from_fix(self, issue: Dict, success: bool):
        """从修复中学习，记录模式"""
        try:
            import json
            
            history_path = self.base_dir / "_healing_history.json"
            
            if history_path.exists():
                with open(history_path) as f:
                    history = json.load(f)
            else:
                history = {"fixes": [], "patterns": {}}
            
            # 记录本次修复
            history["fixes"].append({
                "issue_type": issue.get("type"),
                "success": success,
                "timestamp": datetime.now().isoformat(),
                "agent": issue.get("_agent", "mars")
            })
            
            # 限制历史大小
            if len(history["fixes"]) > 1000:
                history["fixes"] = history["fixes"][-500:]
            
            with open(history_path, 'w') as f:
                json.dump(history, f, indent=2)
            
            if success:
                self._notify_evolution_success(issue)
            
        except Exception as e:
            logger.error(f"[SelfHealing] 学习记录失败: {e}")

    def _notify_evolution_success(self, issue: Dict):
        """通知进化系统修复成功"""
        try:
            self.event_bus.emit("healing.fix_success", {
                "issue_type": issue.get("type"),
                "agent": issue.get("_agent", "mars"),
                "timestamp": datetime.now().isoformat()
            })
        except:
            pass

    def _on_evolution_new_module(self, data: Dict):
        """处理进化系统发现的新模块"""
        modules = data.get("modules", [])
        logger.info(f"[SelfHealing] 收到新模块通知: {modules}")
        # 触发立即检查
        issues = self.run_full_health_check()
        for issue in issues:
            self._fix_issue(issue)

