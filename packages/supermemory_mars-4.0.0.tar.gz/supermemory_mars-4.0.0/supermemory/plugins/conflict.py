"""Conflict Detection Plugin"""

import time
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime

from .base import Plugin


class ConflictPlugin(Plugin):
    """
    冲突检测插件
    检测记忆冲突、提供冲突解决策略
    """

    name = "conflict"
    version = "1.0.0"
    description = "Memory conflict detection and resolution"
    core = False
    dependencies = ["core_wal"]

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self._conflict_history: List[Dict[str, Any]] = []
        self._version_store: Dict[str, Dict[str, Any]] = {}
        self._max_history = config.get("max_history", 100) if config else 100

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=80)
        self.subscribe("memory.update", self._on_memory_update, priority=80)
        self.subscribe("memory.read", self._on_memory_read, priority=30)
        self.subscribe("conflict.detect", self._on_conflict_detect, priority=50)
        self.subscribe("conflict.resolve", self._on_conflict_resolve, priority=50)
        self.subscribe("sync.remote_change", self._on_remote_change, priority=40)

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        """记录版本信息"""
        memory_id = data.get("id")
        if memory_id:
            self._version_store[memory_id] = {
                "id": memory_id,
                "version": data.get("version", 1),
                "timestamp": time.time(),
                "content": data.get("content", ""),
                "device_id": data.get("device_id", "local"),
            }

    def _on_memory_update(self, data: Dict[str, Any]) -> None:
        """检查更新冲突"""
        memory_id = data.get("id")
        if not memory_id:
            return

        existing = self._version_store.get(memory_id)
        new_version = data.get("version", 1)

        if existing and new_version <= existing["version"]:
            conflict = {
                "type": "version_conflict",
                "memory_id": memory_id,
                "local_version": existing["version"],
                "incoming_version": new_version,
                "local_content": existing["content"],
                "incoming_content": data.get("content", ""),
                "timestamp": time.time(),
            }
            self._add_conflict(conflict)
            self.emit("conflict.detected", conflict)
            data["_conflict"] = conflict
            data["_conflict_resolved"] = False
        else:
            self._version_store[memory_id] = {
                "id": memory_id,
                "version": new_version,
                "timestamp": time.time(),
                "content": data.get("content", ""),
                "device_id": data.get("device_id", "local"),
            }

    def _on_memory_read(self, data: Dict[str, Any]) -> None:
        """读取时检查冲突状态"""
        memory_id = data.get("id")
        if memory_id:
            conflicts = [c for c in self._conflict_history if c.get("memory_id") == memory_id]
            if conflicts:
                data["has_conflicts"] = True
                data["conflicts"] = conflicts

    def _on_conflict_detect(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """手动检测冲突"""
        memory_id = data.get("memory_id")
        content_a = data.get("content_a", "")
        content_b = data.get("content_b", "")

        if content_a and content_b:
            similarity = self._calculate_similarity(str(content_a), str(content_b))
            if similarity < 0.7:
                conflict = {
                    "type": "content_conflict",
                    "memory_id": memory_id,
                    "similarity": similarity,
                    "content_a": content_a,
                    "content_b": content_b,
                    "timestamp": time.time(),
                }
                self._add_conflict(conflict)
                self.emit("conflict.detected", conflict)
                return conflict
        return None

    def _calculate_similarity(self, text_a: str, text_b: str) -> float:
        """简单的文本相似度计算"""
        if not text_a or not text_b:
            return 0.0
        set_a = set(text_a.lower().split())
        set_b = set(text_b.lower().split())
        if not set_a or not set_b:
            return 0.0
        intersection = len(set_a & set_b)
        union = len(set_a | set_b)
        return intersection / union if union > 0 else 0.0

    def _add_conflict(self, conflict: Dict[str, Any]) -> None:
        self._conflict_history.append(conflict)
        if len(self._conflict_history) > self._max_history:
            self._conflict_history.pop(0)

    def _on_conflict_resolve(self, data: Dict[str, Any]) -> None:
        """解决冲突"""
        memory_id = data.get("memory_id")
        resolution = data.get("resolution", "local")  # local | remote | merge
        resolved_content = data.get("resolved_content", "")

        if not memory_id:
            return

        if resolution == "local":
            new_content = data.get("local_content", "")
        elif resolution == "remote":
            new_content = data.get("remote_content", "")
        else:
            new_content = resolved_content

        # Update version store
        if memory_id in self._version_store:
            self._version_store[memory_id]["version"] += 1
            self._version_store[memory_id]["content"] = new_content
            self._version_store[memory_id]["timestamp"] = time.time()

        # Remove from conflict history
        self._conflict_history = [
            c for c in self._conflict_history if c.get("memory_id") != memory_id
        ]

        self.emit("memory.update", {
            "id": memory_id,
            "content": new_content,
            "version": self._version_store.get(memory_id, {}).get("version", 1),
            "conflict_resolved": True,
        })
        self.emit("conflict.resolved", {"memory_id": memory_id, "resolution": resolution})

    def _on_remote_change(self, data: Dict[str, Any]) -> None:
        """处理远程变更"""
        memory_id = data.get("memory_id")
        remote_version = data.get("version", 1)
        remote_content = data.get("content", "")
        remote_device = data.get("device_id", "remote")

        local = self._version_store.get(memory_id)
        if local and remote_version > local["version"]:
            conflict = {
                "type": "sync_conflict",
                "memory_id": memory_id,
                "local_version": local["version"],
                "remote_version": remote_version,
                "local_content": local["content"],
                "remote_content": remote_content,
                "remote_device": remote_device,
                "timestamp": time.time(),
            }
            self._add_conflict(conflict)
            self.emit("conflict.detected", conflict)

    def get_status(self) -> Dict[str, Any]:
        return {
            "conflict_count": len(self._conflict_history),
            "versioned_memories": len(self._version_store),
        }
