"""Spaced Repetition Plugin"""

import time
import math
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta

from .base import Plugin


class SpacedRepetitionPlugin(Plugin):
    """
    间隔重复插件
    基于SM-2算法实现复习调度，优化长期记忆保持
    """

    name = "spaced_repetition"
    version = "1.0.0"
    description = "Spaced repetition scheduling for memory review"
    core = False
    dependencies = ["decay"]

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self._review_data: Dict[str, Dict[str, Any]] = {}
        self._due_reviews: List[str] = []
        self._easiness_factor = 2.5  # SM-2 default

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=15)
        self.subscribe("memory.mark_to_review", self._on_mark_to_review, priority=50)
        self.subscribe("memory.review", self._on_review, priority=50)
        self.subscribe("review.get_due", self._on_get_due_reviews, priority=50)
        self.subscribe("review.get_next", self._on_get_next_review_date, priority=50)

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        """初始化复习数据"""
        memory_id = data.get("id")
        if memory_id and memory_id not in self._review_data:
            self._review_data[memory_id] = {
                "id": memory_id,
                "easiness_factor": self._easiness_factor,
                "interval": 0,
                "repetitions": 0,
                "next_review": time.time(),
                "last_review": None,
            }

    def _on_mark_to_review(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        if memory_id:
            if memory_id not in self._review_data:
                self._review_data[memory_id] = {
                    "id": memory_id,
                    "easiness_factor": self._easiness_factor,
                    "interval": 0,
                    "repetitions": 0,
                    "next_review": time.time(),
                    "last_review": None,
                }
            self.emit("review.scheduled", {"id": memory_id, "next": self._review_data[memory_id]["next_review"]})

    def _on_review(self, data: Dict[str, Any]) -> None:
        """处理复习反馈 - SM-2算法"""
        memory_id = data.get("id")
        quality = data.get("quality", 3)  # 0-5 scale

        if not memory_id or memory_id not in self._review_data:
            self.emit("review.failed", {"error": "Memory not in review system", "id": memory_id})
            return

        review_info = self._review_data[memory_id]
        ef = review_info["easiness_factor"]
        n = review_info["repetitions"]
        interval = review_info["interval"]

        # SM-2 Algorithm
        if quality >= 3:
            # Correct response
            if n == 0:
                interval = 1
            elif n == 1:
                interval = 6
            else:
                interval = round(interval * ef)
            n += 1
        else:
            # Incorrect response - reset
            n = 0
            interval = 1

        # Update easiness factor
        ef = ef + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
        ef = max(1.3, ef)

        next_review = time.time() + interval * 86400  # interval in days

        self._review_data[memory_id] = {
            "id": memory_id,
            "easiness_factor": ef,
            "interval": interval,
            "repetitions": n,
            "next_review": next_review,
            "last_review": time.time(),
        }

        self.emit("review.completed", {
            "id": memory_id,
            "quality": quality,
            "next_review": next_review,
            "interval": interval,
            "repetitions": n,
        })

        # Update due list
        if next_review <= time.time() + 86400:
            if memory_id not in self._due_reviews:
                self._due_reviews.append(memory_id)
        elif memory_id in self._due_reviews:
            self._due_reviews.remove(memory_id)

    def _on_get_due_reviews(self, data: Optional[Dict[str, Any]] = None) -> List[str]:
        """获取到期复习的记忆ID列表"""
        now = time.time()
        due = [
            mid for mid, info in self._review_data.items()
            if info["next_review"] <= now
        ]
        self.emit("review.due_list", {"due": due, "count": len(due)})
        return due

    def _on_get_next_review_date(self, data: Dict[str, Any]) -> Optional[float]:
        memory_id = data.get("id")
        if memory_id and memory_id in self._review_data:
            next_review = self._review_data[memory_id]["next_review"]
            self.emit("review.next_date", {"id": memory_id, "next": next_review})
            return next_review
        return None

    def get_review_info(self, memory_id: str) -> Optional[Dict[str, Any]]:
        return self._review_data.get(memory_id)

    def get_status(self) -> Dict[str, Any]:
        now = time.time()
        due_count = sum(1 for info in self._review_data.values() if info["next_review"] <= now)
        return {
            "total_review_items": len(self._review_data),
            "due_count": due_count,
            "easiness_factor": self._easiness_factor,
        }

    def get_due_reviews(self, limit: int = 10) -> List[Dict]:
        """
        获取今日待复习的记忆（供外部调用）
        """
        return self._on_get_due_reviews({"limit": limit})
