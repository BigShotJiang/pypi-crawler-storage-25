"""Core WAL (Write-Ahead Log) Plugin"""

import os
import json
import time
from datetime import datetime
from typing import Dict, Any, Optional, List
from pathlib import Path

from .base import Plugin


class CoreWALPlugin(Plugin):
    """
    WAL核心插件 - 预写日志
    确保所有写入操作先记录到WAL，再应用到主存储
    """

    name = "core_wal"
    version = "1.0.0"
    description = "Write-Ahead Log for crash-safe memory operations"
    core = True
    dependencies = []

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self.wal_dir = config.get("wal_dir", "./data/wal") if config else "./data/wal"
        self.wal_file: Optional[str] = None
        self._buffer: List[Dict[str, Any]] = []
        self._buffer_size = config.get("buffer_size", 100) if config else 100
        self._flush_interval = config.get("flush_interval", 5) if config else 5  # seconds
        self._last_flush = time.time()
        self._ensure_wal_dir()

    def _ensure_wal_dir(self) -> None:
        Path(self.wal_dir).mkdir(parents=True, exist_ok=True)
        self.wal_file = os.path.join(
            self.wal_dir, f"wal_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        )

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=100)
        self.subscribe("memory.update", self._on_memory_update, priority=100)
        self.subscribe("memory.delete", self._on_memory_delete, priority=100)
        self.subscribe("wal.flush", self._on_flush, priority=100)
        self.subscribe("wal.recover", self._on_recover, priority=100)
        self.subscribe("system.tick", self._on_tick, priority=1)

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        """记录写操作到WAL"""
        entry = {
            "type": "write",
            "timestamp": time.time(),
            "data": data,
        }
        self._append_entry(entry)
        self.emit("wal.entry_appended", entry)

    def _on_memory_update(self, data: Dict[str, Any]) -> None:
        """记录更新操作到WAL"""
        entry = {
            "type": "update",
            "timestamp": time.time(),
            "data": data,
        }
        self._append_entry(entry)
        self.emit("wal.entry_appended", entry)

    def _on_memory_delete(self, data: Dict[str, Any]) -> None:
        """记录删除操作到WAL"""
        entry = {
            "type": "delete",
            "timestamp": time.time(),
            "data": data,
        }
        self._append_entry(entry)
        self.emit("wal.entry_appended", entry)

    def _append_entry(self, entry: Dict[str, Any]) -> None:
        self._buffer.append(entry)
        if len(self._buffer) >= self._buffer_size:
            self._flush()

    def _flush(self) -> None:
        """将缓冲区内容刷写到磁盘"""
        if not self._buffer or not self.wal_file:
            return

        with open(self.wal_file, "a", encoding="utf-8") as f:
            for entry in self._buffer:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        self._buffer.clear()
        self._last_flush = time.time()
        self.emit("wal.flushed", {"count": len(self._buffer), "file": self.wal_file})

    def _on_flush(self, data: Optional[Dict[str, Any]] = None) -> None:
        self._flush()
        self.emit("wal.flush_completed", {})

    def _on_recover(self, data: Optional[Dict[str, Any]] = None) -> None:
        """从WAL恢复数据"""
        entries = self._recover_entries()
        self.emit("wal.recovery_completed", {"entries": entries})
        return entries

    def _recover_entries(self) -> List[Dict[str, Any]]:
        """读取WAL文件恢复所有条目"""
        entries = []
        if not self.wal_file or not os.path.exists(self.wal_file):
            return entries

        with open(self.wal_file, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    entries.append(entry)
                except json.JSONDecodeError:
                    continue
        return entries

    def _on_tick(self, data: Optional[Dict[str, Any]] = None) -> None:
        """定期检查是否需要flush"""
        if (
            self._buffer
            and time.time() - self._last_flush >= self._flush_interval
        ):
            self._flush()

    def get_status(self) -> Dict[str, Any]:
        return {
            "buffer_size": len(self._buffer),
            "wal_file": self.wal_file,
            "last_flush": self._last_flush,
            "flush_interval": self._flush_interval,
        }
