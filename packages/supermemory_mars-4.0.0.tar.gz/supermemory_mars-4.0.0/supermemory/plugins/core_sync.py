"""Core Sync Plugin - Multi-device synchronization"""

import time
from datetime import datetime
from typing import Dict, Any, Optional, List

from .base import Plugin


class CoreSyncPlugin(Plugin):
    """
    同步核心插件
    处理多设备间的记忆同步、冲突检测和版本管理
    """

    name = "core_sync"
    version = "1.0.0"
    description = "Multi-device memory synchronization"
    core = True
    dependencies = ["core_wal"]

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self.device_id = config.get("device_id", "default") if config else "default"
        self.sync_endpoint = config.get("sync_endpoint", "") if config else ""
        self._pending_changes: List[Dict[str, Any]] = []
        self._last_sync: Optional[float] = None
        self._version_vector: Dict[str, int] = {}
        self._sync_interval = config.get("sync_interval", 30) if config else 30

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=10)
        self.subscribe("memory.update", self._on_memory_update, priority=10)
        self.subscribe("memory.delete", self._on_memory_delete, priority=10)
        self.subscribe("sync.push", self._on_sync_push, priority=50)
        self.subscribe("sync.pull", self._on_sync_pull, priority=50)
        self.subscribe("sync.full", self._on_sync_full, priority=50)
        self.subscribe("sync.resolve_conflict", self._on_resolve_conflict, priority=50)
        self.subscribe("system.tick", self._on_tick, priority=1)

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        """记录变更用于同步"""
        memory_id = data.get("id")
        if memory_id:
            self._pending_changes.append(
                {
                    "type": "write",
                    "memory_id": memory_id,
                    "data": data,
                    "timestamp": time.time(),
                    "device_id": self.device_id,
                }
            )

    def _on_memory_update(self, data: Dict[str, Any]) -> None:
        """记录更新用于同步"""
        memory_id = data.get("id")
        if memory_id:
            self._pending_changes.append(
                {
                    "type": "update",
                    "memory_id": memory_id,
                    "data": data,
                    "timestamp": time.time(),
                    "device_id": self.device_id,
                }
            )

    def _on_memory_delete(self, data: Dict[str, Any]) -> None:
        """记录删除用于同步"""
        memory_id = data.get("id")
        if memory_id:
            self._pending_changes.append(
                {
                    "type": "delete",
                    "memory_id": memory_id,
                    "data": data,
                    "timestamp": time.time(),
                    "device_id": self.device_id,
                }
            )

    def _on_sync_push(self, data: Optional[Dict[str, Any]] = None) -> None:
        """推送本地变更到远程"""
        if not self.sync_endpoint:
            self.emit("sync.push.failed", {"error": "No sync endpoint configured"})
            return

        changes = self._pending_changes[:]
        if not changes:
            self.emit("sync.push.skipped", {"reason": "No pending changes"})
            return

        # Emit push request
        self.emit(
            "sync.push.request",
            {"changes": changes, "device_id": self.device_id},
        )
        self._pending_changes.clear()
        self._last_sync = time.time()

    def _on_sync_pull(self, data: Optional[Dict[str, Any]] = None) -> None:
        """从远程拉取变更"""
        if not self.sync_endpoint:
            self.emit("sync.pull.failed", {"error": "No sync endpoint configured"})
            return

        self.emit(
            "sync.pull.request",
            {
                "version_vector": self._version_vector,
                "device_id": self.device_id,
            },
        )

    def _on_sync_full(self, data: Optional[Dict[str, Any]] = None) -> None:
        """执行全量同步"""
        self.emit("sync.full.request", {"device_id": self.device_id})
        self._last_sync = time.time()

    def _on_resolve_conflict(self, data: Dict[str, Any]) -> None:
        """解决同步冲突"""
        memory_id = data.get("memory_id")
        resolution = data.get("resolution", "local")  # local | remote | merge
        resolved_data = data.get("resolved_data")

        if resolution == "local":
            self.emit("memory.write", resolved_data or data.get("local_data"))
        elif resolution == "remote":
            self.emit("memory.write", data.get("remote_data"))
        elif resolution == "merge":
            self.emit("memory.write", resolved_data)

        self.emit(
            "sync.conflict_resolved",
            {"memory_id": memory_id, "resolution": resolution},
        )

    def _on_tick(self, data: Optional[Dict[str, Any]] = None) -> None:
        """定期检查是否需要同步"""
        if (
            self._pending_changes
            and self._last_sync is None
            or (
                self._last_sync
                and time.time() - self._last_sync >= self._sync_interval
            )
        ):
            self._on_sync_push()

    def get_status(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "pending_changes": len(self._pending_changes),
            "last_sync": self._last_sync,
            "version_vector": self._version_vector,
            "sync_endpoint": self.sync_endpoint,
        }
