"""Core Vector Plugin - Vector storage and similarity search"""

import os
import numpy as np
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime

from .base import Plugin


class CoreVectorPlugin(Plugin):
    """
    向量核心插件
    提供向量存储、相似度搜索、聚类等功能
    """

    name = "core_vector"
    version = "1.0.0"
    description = "Vector storage and semantic similarity search"
    core = True
    dependencies = ["core_wal"]

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self.dimension = config.get("dimension", 768) if config else 768
        self._vectors: Dict[str, np.ndarray] = {}
        self._metadata: Dict[str, Dict[str, Any]] = {}
        self._index_ready = False
        # 持久化路径
        import os
        data_dir = os.path.expanduser('~/.openclaw/workspace-shared/super-memory-data/mars')
        self._persist_path = os.path.join(data_dir, 'vectors.json')
        self._load_vectors()

    def _register_handlers(self) -> None:
        self.subscribe("vector.add", self._on_vector_add, priority=50)
        self.subscribe("vector.search", self._on_vector_search, priority=50)
        self.subscribe("vector.delete", self._on_vector_delete, priority=50)
        self.subscribe("vector.batch_add", self._on_batch_add, priority=50)
        self.subscribe("vector.rebuild_index", self._on_rebuild_index, priority=50)
        self.subscribe("memory.write", self._on_memory_write, priority=50)

    def _on_vector_add(self, data: Dict[str, Any]) -> None:
        """添加向量"""
        vector_id = data.get("id")
        vector = data.get("vector")
        metadata = data.get("metadata", {})

        if vector_id is None or vector is None:
            self.emit("vector.add.failed", {"error": "Missing id or vector", "data": data})
            return

        if isinstance(vector, list):
            vector = np.array(vector, dtype=np.float32)

        self._vectors[vector_id] = vector
        self._metadata[vector_id] = {
            **metadata,
            "created_at": datetime.now().isoformat(),
        }
        self._index_ready = False
        self._save_vectors()  # 持久化
        self.emit("vector.added", {"id": vector_id, "metadata": self._metadata[vector_id]})

    def _on_vector_delete(self, data: Dict[str, Any]) -> None:
        """删除向量"""
        vector_id = data.get("id")
        if vector_id in self._vectors:
            del self._vectors[vector_id]
            del self._metadata[vector_id]
            self._index_ready = False
            self.emit("vector.deleted", {"id": vector_id})
        else:
            self.emit("vector.delete.failed", {"id": vector_id, "error": "Not found"})

    def _on_batch_add(self, data: Dict[str, Any]) -> None:
        """批量添加向量"""
        items = data.get("items", [])
        added = []
        for item in items:
            vector_id = item.get("id")
            vector = item.get("vector")
            metadata = item.get("metadata", {})
            if vector_id and vector:
                if isinstance(vector, list):
                    vector = np.array(vector, dtype=np.float32)
                self._vectors[vector_id] = vector
                self._metadata[vector_id] = {
                    **metadata,
                    "created_at": datetime.now().isoformat(),
                }
                added.append(vector_id)
        self._index_ready = False
        self.emit("vector.batch_added", {"count": len(added), "ids": added})

    def _on_vector_search(
        self, data: Dict[str, Any]
    ) -> Optional[List[Dict[str, Any]]]:
        """向量相似度搜索"""
        query = data.get("query")
        top_k = data.get("top_k", 10)
        threshold = data.get("threshold", 0.0)

        if query is None:
            self.emit("vector.search.failed", {"error": "Missing query vector"})
            return None

        if isinstance(query, list):
            query = np.array(query, dtype=np.float32)

        results = self._search_internal(query, top_k, threshold)
        self.emit("vector.search.completed", {"results": results, "query_id": data.get("id")})
        return results

    def _search_internal(
        self, query: np.ndarray, top_k: int, threshold: float
    ) -> List[Dict[str, Any]]:
        """内部搜索实现 - 简单的余弦相似度"""
        if not self._vectors:
            return []

        results = []
        for vector_id, vector in self._vectors.items():
            # Cosine similarity
            norm_q = np.linalg.norm(query)
            norm_v = np.linalg.norm(vector)
            if norm_q == 0 or norm_v == 0:
                similarity = 0.0
            else:
                similarity = np.dot(query, vector) / (norm_q * norm_v)

            if similarity >= threshold:
                results.append(
                    {
                        "id": vector_id,
                        "score": float(similarity),
                        "metadata": self._metadata.get(vector_id, {}),
                    }
                )

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    def _on_rebuild_index(self, data: Optional[Dict[str, Any]] = None) -> None:
        """重建索引"""
        self._index_ready = True
        self.emit("vector.index_rebuilt", {"count": len(self._vectors)})

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        """自动为新记忆生成真实向量（使用Ollama nomic-embed-text）"""
        memory_id = data.get("id")
        content = data.get("content", "")
        
        if memory_id and memory_id not in self._vectors:
            # 调用 Ollama 生成真实向量
            embedding = self._generate_embedding(content)
            self._vectors[memory_id] = embedding
            self._metadata[memory_id] = {
                "source": "memory",
                "created_at": datetime.now().isoformat(),
            }

    def _generate_embedding(self, text: str) -> np.ndarray:
        """使用 Ollama nomic-embed-text 生成向量"""
        import urllib.request
        import json
        
        if not text:
            return np.random.randn(self.dimension).astype(np.float32)
        
        try:
            req = urllib.request.Request(
                'http://localhost:11434/api/embeddings',
                data=json.dumps({'model': 'nomic-embed-text', 'prompt': text[:1000]}).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                result = json.loads(response.read())
                embedding = result.get('embedding', [])
                if embedding:
                    return np.array(embedding, dtype=np.float32)
        except Exception as e:
            print(f"Embedding生成失败: {e}")
        
        # 回退到随机向量
        return np.random.randn(self.dimension).astype(np.float32)


    def _load_vectors(self):
        """从 vectors.json 加载向量"""
        import json
        if os.path.exists(self._persist_path):
            try:
                with open(self._persist_path, 'r') as f:
                    data = json.load(f)
                for vid, vdata in data.items():
                    if 'embedding' in vdata and vdata['embedding']:
                        self._vectors[vid] = np.array(vdata['embedding'], dtype=np.float32)
                        self._metadata[vid] = vdata.get('metadata', {})
                print(f"[CoreVectorPlugin] 加载了 {len(self._vectors)} 个向量")
            except Exception as e:
                print(f"[CoreVectorPlugin] 加载向量失败: {e}")

    def _save_vectors(self):
        """保存向量到 vectors.json"""
        import json
        try:
            data = {}
            for vid, vec in self._vectors.items():
                data[vid] = {
                    'embedding': vec.tolist() if hasattr(vec, 'tolist') else list(vec),
                    'metadata': self._metadata.get(vid, {})
                }
            with open(self._persist_path, 'w') as f:
                json.dump(data, f)
        except Exception as e:
            print(f"[CoreVectorPlugin] 保存向量失败: {e}")

    def get_status(self) -> Dict[str, Any]:
        return {
            "vector_count": len(self._vectors),
            "dimension": self.dimension,
            "index_ready": self._index_ready,
        }
