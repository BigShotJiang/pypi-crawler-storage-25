"""Intelligent Index Plugin"""

import re
import time
from typing import Dict, Any, Optional, List, Set
from datetime import datetime
from collections import defaultdict

from .base import Plugin


class IndexPlugin(Plugin):
    """
    智能索引插件
    提供多维度索引、倒排索引、全文搜索能力
    """

    name = "index"
    version = "1.0.0"
    description = "Intelligent indexing and full-text search"
    core = False
    dependencies = []

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self._inverted_index: Dict[str, Set[str]] = defaultdict(set)
        self._memory_index: Dict[str, Dict[str, Any]] = {}
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)
        self._entity_index: Dict[str, Set[str]] = defaultdict(set)
        self._time_index: Dict[str, List[str]] = defaultdict(list)
        self._index_interval = config.get("index_interval", 3600) if config else 3600

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=30)
        self.subscribe("memory.update", self._on_memory_update, priority=30)
        self.subscribe("memory.delete", self._on_memory_delete, priority=30)
        self.subscribe("index.search", self._on_search, priority=50)
        self.subscribe("index.rebuild", self._on_rebuild_index, priority=50)
        self.subscribe("index.get_by_tag", self._on_get_by_tag, priority=50)
        self.subscribe("index.get_by_entity", self._on_get_by_entity, priority=50)
        self.subscribe("index.get_by_time", self._on_get_by_time, priority=50)

    def _tokenize(self, text: str) -> List[str]:
        """中英文分词（简单实现）"""
        if not text:
            return []
        # 英文按空格和标点分词
        tokens = re.findall(r"[a-zA-Z0-9_]+", text.lower())
        # 中文按bigram分词（简化）
        chinese_chars = re.findall(r"[\u4e00-\u9fff]+", text)
        for chunk in chinese_chars:
            for i in range(len(chunk) - 1):
                tokens.append(chunk[i : i + 2])
        return tokens

    def _index_memory(self, memory_id: str, content: str, metadata: Dict[str, Any]) -> None:
        """索引记忆"""
        # 清除旧索引
        for term, ids in list(self._inverted_index.items()):
            ids.discard(memory_id)
            if not ids:
                del self._inverted_index[term]

        # 内容分词索引
        tokens = self._tokenize(content)
        for token in tokens:
            self._inverted_index[token].add(memory_id)

        # Tag索引
        tags = metadata.get("tags", [])
        for tag in tags:
            self._tag_index[tag].add(memory_id)

        # Entity索引
        entities = metadata.get("entities", [])
        for entity in entities:
            self._entity_index[entity].add(memory_id)

        # 存储索引信息
        self._memory_index[memory_id] = {
            "content": content,
            "tags": tags,
            "entities": entities,
            "indexed_at": time.time(),
        }

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        content = data.get("content", "")
        if memory_id and content:
            self._index_memory(memory_id, content, data)
            self.emit("index.memory_indexed", {"id": memory_id})

    def _on_memory_update(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        content = data.get("content", "")
        if memory_id and content:
            self._index_memory(memory_id, content, data)
            self.emit("index.memory_updated", {"id": memory_id})

    def _on_memory_delete(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        if memory_id:
            # 清除所有索引
            for term_ids in self._inverted_index.values():
                term_ids.discard(memory_id)
            for tag_ids in self._tag_index.values():
                tag_ids.discard(memory_id)
            for entity_ids in self._entity_index.values():
                entity_ids.discard(memory_id)
            for time_ids in self._time_index.values():
                if memory_id in time_ids:
                    time_ids.remove(memory_id)
            self._memory_index.pop(memory_id, None)
            self.emit("index.memory_removed", {"id": memory_id})

    def _on_search(self, data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """搜索记忆"""
        query = data.get("query", "")
        mode = data.get("mode", "and")  # and | or
        limit = data.get("limit", 20)
        tags = data.get("tags", [])
        entities = data.get("entities", [])

        result_ids: Set[str] = set()
        first_set = True

        # 关键词搜索
        if query:
            tokens = self._tokenize(query)
            for token in tokens:
                if first_set:
                    result_ids = self._inverted_index.get(token, set()).copy()
                    first_set = False
                else:
                    if mode == "and":
                        result_ids &= self._inverted_index.get(token, set())
                    else:
                        result_ids |= self._inverted_index.get(token, set())

        # Tag过滤
        for tag in tags:
            tag_results = self._tag_index.get(tag, set())
            if first_set:
                result_ids = tag_results.copy()
                first_set = False
            else:
                result_ids &= tag_results

        # Entity过滤
        for entity in entities:
            entity_results = self._entity_index.get(entity, set())
            if first_set:
                result_ids = entity_results.copy()
                first_set = False
            else:
                result_ids &= entity_results

        if first_set:
            result_ids = set(self._memory_index.keys())

        results = [
            {"id": mid, "score": 1.0}
            for mid in list(result_ids)[:limit]
        ]
        self.emit("index.search_completed", {"query": query, "results": results})
        return results

    def _on_rebuild_index(self, data: Optional[Dict[str, Any]] = None) -> None:
        """重建索引"""
        self._inverted_index.clear()
        self._memory_index.clear()
        self.emit("index.rebuild_started", {})
        # 发出重建请求，由其他组件提供数据
        self.emit("memory.rebuild_request", {})

    def _on_get_by_tag(self, data: Dict[str, Any]) -> List[str]:
        tag = data.get("tag")
        if tag:
            results = list(self._tag_index.get(tag, set()))
            self.emit("index.tag_results", {"tag": tag, "results": results})
            return results
        return []

    def _on_get_by_entity(self, data: Dict[str, Any]) -> List[str]:
        entity = data.get("entity")
        if entity:
            results = list(self._entity_index.get(entity, set()))
            self.emit("index.entity_results", {"entity": entity, "results": results})
            return results
        return []

    def _on_get_by_time(self, data: Dict[str, Any]) -> List[str]:
        time_range = data.get("range", "day")  # day | week | month
        now = time.time()
        results = []
        if time_range == "day":
            start = now - 86400
        elif time_range == "week":
            start = now - 86400 * 7
        else:
            start = now - 86400 * 30

        for mid, info in self._memory_index.items():
            indexed_at = info.get("indexed_at", 0)
            if indexed_at >= start:
                results.append(mid)
        return results

    def get_status(self) -> Dict[str, Any]:
        return {
            "indexed_memories": len(self._memory_index),
            "vocabulary_size": len(self._inverted_index),
            "tag_count": len(self._tag_index),
            "entity_count": len(self._entity_index),
        }
