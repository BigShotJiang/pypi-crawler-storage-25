"""Memory Decay Management Plugin"""

import time
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta

from .base import Plugin


class DecayPlugin(Plugin):
    """
    衰减管理插件
    根据记忆的访问频率、重要性、时间等因素动态调整衰减
    """

    name = "decay"
    version = "1.0.0"
    description = "Adaptive memory decay management"
    core = False
    dependencies = []

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self._memory_weights: Dict[str, float] = {}
        self._memory_access: Dict[str, float] = {}
        self._memory_importance: Dict[str, int] = {}
        self._base_decay_rate = config.get("decay_rate", 0.01) if config else 0.01
        self._decay_interval = config.get("decay_interval", 3600) if config else 3600  # 1 hour
        self._last_decay_check = time.time()

    def _register_handlers(self) -> None:
        self.subscribe("memory.write", self._on_memory_write, priority=10)
        self.subscribe("memory.read", self._on_memory_read, priority=10)
        self.subscribe("memory.access", self._on_memory_access, priority=10)
        self.subscribe("memory.set_importance", self._on_set_importance, priority=50)
        self.subscribe("decay.check", self._on_decay_check, priority=50)
        self.subscribe("decay.get_weights", self._on_get_weights, priority=50)
        self.subscribe("system.tick", self._on_tick, priority=1)

    def _on_memory_write(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        if memory_id:
            self._memory_weights[memory_id] = 1.0
            self._memory_access[memory_id] = time.time()
            importance = data.get("importance", 5)
            self._memory_importance[memory_id] = importance

    def _on_memory_read(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        if memory_id and memory_id in self._memory_weights:
            self._memory_access[memory_id] = time.time()
            self._boost_weight(memory_id, boost=0.1)

    def _on_memory_access(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        if memory_id and memory_id in self._memory_weights:
            self._memory_access[memory_id] = time.time()
            self._boost_weight(memory_id, boost=0.05)

    def _on_set_importance(self, data: Dict[str, Any]) -> None:
        memory_id = data.get("id")
        importance = data.get("importance", 5)
        if memory_id:
            self._memory_importance[memory_id] = importance
            self.emit("decay.importance_updated", {"id": memory_id, "importance": importance})

    def _boost_weight(self, memory_id: str, boost: float) -> None:
        """增强记忆权重"""
        if memory_id not in self._memory_weights:
            self._memory_weights[memory_id] = 1.0
        importance = self._memory_importance.get(memory_id, 5)
        max_boost = boost * (importance / 5.0)
        self._memory_weights[memory_id] = min(
            self._memory_weights[memory_id] + max_boost, 2.0
        )

    def _calculate_decay(self, memory_id: str) -> float:
        """计算衰减"""
        if memory_id not in self._memory_weights:
            return 0.0

        last_access = self._memory_access.get(memory_id, 0)
        time_since_access = time.time() - last_access
        decay_interval_count = time_since_access / self._decay_interval
        importance = self._memory_importance.get(memory_id, 5)
        importance_factor = 1.0 + (importance - 5) * 0.1
        decay = self._base_decay_rate * decay_interval_count * importance_factor
        new_weight = max(self._memory_weights[memory_id] - decay, 0.1)
        self._memory_weights[memory_id] = new_weight
        return new_weight

    def _on_decay_check(self, data: Optional[Dict[str, Any]] = None) -> None:
        """执行衰减检查"""
        decayed = []
        for memory_id in list(self._memory_weights.keys()):
            old_weight = self._memory_weights[memory_id]
            new_weight = self._calculate_decay(memory_id)
            if new_weight != old_weight:
                decayed.append({"id": memory_id, "old": old_weight, "new": new_weight})

        self.emit("decay.check_completed", {"decayed": decayed, "count": len(decayed)})
        return decayed

    def _on_get_weights(self, data: Optional[Dict[str, Any]] = None) -> None:
        """获取所有记忆权重"""
        weights = {
            mid: {
                "weight": w,
                "last_access": self._memory_access.get(mid, 0),
                "importance": self._memory_importance.get(mid, 5),
            }
            for mid, w in self._memory_weights.items()
        }
        self.emit("decay.weights", {"weights": weights})

    def _on_tick(self, data: Optional[Dict[str, Any]] = None) -> None:
        """定期检查"""
        if time.time() - self._last_decay_check >= self._decay_interval:
            self._on_decay_check()
            self._last_decay_check = time.time()

    def get_weight(self, memory_id: str) -> Optional[float]:
        return self._memory_weights.get(memory_id)

    def get_status(self) -> Dict[str, Any]:
        return {
            "tracked_memories": len(self._memory_weights),
            "decay_rate": self._base_decay_rate,
            "decay_interval": self._decay_interval,
        }
