"""
M13 - 多媒体记忆插件
支持图片、语音、视频的记忆存储与检索
"""

import logging
import os
import hashlib
import json
import subprocess
import shutil
from typing import Dict, Any, List, Optional
from pathlib import Path
from .base import Plugin

logger = logging.getLogger(__name__)


class MultimediaMemoryPlugin(Plugin):
    """
    多媒体记忆插件
    
    支持类型：
    - 🖼️ 图片：OCR文字提取 + 自动描述
    - 🎤 语音：Whisper转录 + 时间戳
    - 🎬 视频：关键帧提取 + 场景分析
    """
    
    name = "multimedia_memory"
    version = "1.0.0"
    description = "多媒体记忆 - 支持图片/语音/视频"
    core = False
    dependencies = []
    
    SUPPORTED_TYPES = ["image", "audio", "video"]
    
    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self.data_dir = Path(config.get("data_dir", "/tmp/multimedia_memory")) if config else Path("/tmp/multimedia_memory")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._media_index: Dict[str, Dict] = {}
        self._load_index()
        self._has_ffmpeg = False
        self._has_tesseract = False
    
    def _register_handlers(self):
        """注册事件处理器"""
        self.event_bus.subscribe("media.add", self._on_media_add)
        self.event_bus.subscribe("media.search", self._on_media_search)
        self.event_bus.subscribe("media.list", self._on_media_list)
    
    def _ensure_tools(self):
        """确保必要的工具已安装"""
        try:
            subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
            self._has_ffmpeg = True
        except:
            self._has_ffmpeg = False
            logger.warning("ffmpeg 未安装，视频处理能力受限")
            
        try:
            subprocess.run(["tesseract", "--version"], capture_output=True, check=True)
            self._has_tesseract = True
        except:
            self._has_tesseract = False
            logger.warning("tesseract 未安装，OCR能力受限")
    
    def on_load(self):
        """插件加载"""
        super().on_load()
        self._ensure_tools()
        logger.info(f"{self.name} v{self.version} 加载成功")
    
    def _load_index(self):
        """加载媒体索引"""
        index_file = self.data_dir / "media_index.json"
        if index_file.exists():
            try:
                with open(index_file) as f:
                    self._media_index = json.load(f)
            except:
                self._media_index = {}
                
    def _save_index(self):
        """保存媒体索引"""
        index_file = self.data_dir / "media_index.json"
        with open(index_file, 'w', encoding='utf-8') as f:
            json.dump(self._media_index, f, indent=2, ensure_ascii=False)
    
    def _calculate_hash(self, file_path: str) -> str:
        """计算文件哈希"""
        with open(file_path, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()[:16]
    
    def _on_media_add(self, data: Dict):
        """处理媒体添加请求"""
        file_path = data.get("file_path")
        media_type = data.get("type")
        if not file_path or not media_type:
            return {"error": "missing file_path or type"}
        
        try:
            if media_type == "image":
                result = self.add_image(file_path, data.get("description"), data.get("metadata"))
            elif media_type == "audio":
                result = self.add_audio(file_path, data.get("metadata"))
            elif media_type == "video":
                result = self.add_video(file_path, data.get("description"), data.get("metadata"))
            else:
                return {"error": f"unsupported type: {media_type}"}
            
            self.event_bus.emit("media.added", result)
            return result
        except Exception as e:
            logger.error(f"添加媒体失败: {e}")
            return {"error": str(e)}
    
    def _on_media_search(self, data: Dict):
        """处理媒体搜索请求"""
        query = data.get("query", "")
        media_types = data.get("types")
        return self.search(query, media_types)
    
    def _on_media_list(self, data: Dict):
        """处理媒体列表请求"""
        return self.list_media(data.get("type"), data.get("limit", 100))
    
    def add_image(self, file_path: str, description: str = None, metadata: Dict = None) -> Dict:
        """添加图片记忆"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"图片文件不存在: {file_path}")
            
        media_id = self._calculate_hash(file_path)
        ocr_text = self._extract_ocr(file_path) if self._has_tesseract else ""
        
        record = {
            "id": media_id,
            "type": "image",
            "source_path": file_path,
            "description": description or "",
            "ocr_text": ocr_text,
            "metadata": metadata or {},
            "created_at": self._get_timestamp(),
            "indexed": False
        }
        
        dest_dir = self.data_dir / "images"
        dest_dir.mkdir(exist_ok=True)
        dest_path = dest_dir / f"{media_id}.jpg"
        shutil.copy2(file_path, dest_path)
        record["stored_path"] = str(dest_path)
        
        self._media_index[media_id] = record
        self._save_index()
        
        logger.info(f"图片记忆已添加: {media_id}")
        return record
    
    def add_audio(self, file_path: str, metadata: Dict = None) -> Dict:
        """添加语音记忆"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"音频文件不存在: {file_path}")
            
        media_id = self._calculate_hash(file_path)
        transcript = self._transcribe_audio(file_path)
        duration = self._get_audio_duration(file_path)
        
        record = {
            "id": media_id,
            "type": "audio",
            "source_path": file_path,
            "transcript": transcript,
            "duration_seconds": duration,
            "metadata": metadata or {},
            "created_at": self._get_timestamp(),
            "indexed": False
        }
        
        dest_dir = self.data_dir / "audio"
        dest_dir.mkdir(exist_ok=True)
        dest_path = dest_dir / f"{media_id}.m4a"
        shutil.copy2(file_path, dest_path)
        record["stored_path"] = str(dest_path)
        
        self._media_index[media_id] = record
        self._save_index()
        
        logger.info(f"语音记忆已添加: {media_id}")
        return record
    
    def add_video(self, file_path: str, description: str = None, metadata: Dict = None) -> Dict:
        """添加视频记忆"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"视频文件不存在: {file_path}")
            
        if not self._has_ffmpeg:
            raise RuntimeError("视频处理需要 ffmpeg")
            
        media_id = self._calculate_hash(file_path)
        frames = self._extract_key_frames(file_path)
        duration = self._get_video_duration(file_path)
        
        record = {
            "id": media_id,
            "type": "video",
            "source_path": file_path,
            "description": description or "",
            "key_frames": frames,
            "duration_seconds": duration,
            "metadata": metadata or {},
            "created_at": self._get_timestamp(),
            "indexed": False
        }
        
        dest_dir = self.data_dir / "video"
        dest_dir.mkdir(exist_ok=True)
        dest_path = dest_dir / f"{media_id}.mp4"
        shutil.copy2(file_path, dest_path)
        record["stored_path"] = str(dest_path)
        
        self._media_index[media_id] = record
        self._save_index()
        
        logger.info(f"视频记忆已添加: {media_id}")
        return record
    
    def _extract_ocr(self, image_path: str) -> str:
        """提取图片OCR文字"""
        try:
            result = subprocess.run(
                ["tesseract", image_path, "stdout", "-l", "chi_sim+eng"],
                capture_output=True, text=True, timeout=30
            )
            return result.stdout.strip()
        except Exception as e:
            logger.warning(f"OCR提取失败: {e}")
            return ""
    
    def _transcribe_audio(self, audio_path: str) -> str:
        """转录音频（使用 Whisper）"""
        try:
            import whisper
            model = whisper.load_model("base")
            result = model.transcribe(audio_path, fp16=False)
            return result.get("text", "").strip()
        except Exception as e:
            logger.warning(f"Whisper 转录失败: {e}")
            return "[转录失败]"
    
    def _extract_key_frames(self, video_path: str, num_frames: int = 5) -> List[str]:
        """提取视频关键帧"""
        frames_dir = self.data_dir / "video" / f"{self._calculate_hash(video_path)}_frames"
        frames_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            duration = self._get_video_duration(video_path)
            interval = duration / (num_frames + 1)
            
            frame_paths = []
            for i in range(1, num_frames + 1):
                timestamp = interval * i
                output_path = frames_dir / f"frame_{i:03d}.jpg"
                
                subprocess.run([
                    "ffmpeg", "-y", "-ss", str(timestamp),
                    "-i", video_path, "-vframes", "1",
                    "-q:v", "2", str(output_path)
                ], capture_output=True)
                
                if output_path.exists():
                    frame_paths.append(str(output_path))
            return frame_paths
        except Exception as e:
            logger.warning(f"关键帧提取失败: {e}")
            return []
    
    def _get_audio_duration(self, media_path: str) -> float:
        """获取音视频时长"""
        try:
            result = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries",
                 "format=duration", "-of",
                 "default=noprint_wrappers=1:nokey=1", media_path],
                capture_output=True, text=True
            )
            return float(result.stdout.strip())
        except:
            return 0.0
    
    def _get_video_duration(self, video_path: str) -> float:
        return self._get_audio_duration(video_path)
    
    def _get_timestamp(self) -> str:
        from datetime import datetime
        return datetime.now().isoformat()
    
    def search(self, query: str, media_types: List[str] = None) -> List[Dict]:
        """搜索多媒体记忆"""
        results = []
        query_lower = query.lower()
        
        for media_id, record in self._media_index.items():
            if media_types and record["type"] not in media_types:
                continue
                
            if record["type"] == "image":
                if (query_lower in record.get("description", "").lower() or
                    query_lower in record.get("ocr_text", "").lower()):
                    results.append(record)
            elif record["type"] == "audio":
                if query_lower in record.get("transcript", "").lower():
                    results.append(record)
            elif record["type"] == "video":
                if query_lower in record.get("description", "").lower():
                    results.append(record)
                    
        return results
    
    def get_media(self, media_id: str) -> Optional[Dict]:
        return self._media_index.get(media_id)
    
    def list_media(self, media_type: str = None, limit: int = 100) -> List[Dict]:
        records = list(self._media_index.values())
        if media_type:
            records = [r for r in records if r["type"] == media_type]
        records.sort(key=lambda x: x["created_at"], reverse=True)
        return records[:limit]
    
    def delete_media(self, media_id: str) -> bool:
        if media_id in self._media_index:
            record = self._media_index[media_id]
            stored_path = record.get("stored_path")
            if stored_path and os.path.exists(stored_path):
                os.remove(stored_path)
            del self._media_index[media_id]
            self._save_index()
            return True
        return False
    
    def get_stats(self) -> Dict:
        stats = {"total": len(self._media_index), "by_type": {}, "storage_size_mb": 0}
        for media_id, record in self._media_index.items():
            media_type = record["type"]
            stats["by_type"][media_type] = stats["by_type"].get(media_type, 0) + 1
            stored_path = record.get("stored_path")
            if stored_path and os.path.exists(stored_path):
                stats["storage_size_mb"] += os.path.getsize(stored_path) / (1024 * 1024)
        return stats
