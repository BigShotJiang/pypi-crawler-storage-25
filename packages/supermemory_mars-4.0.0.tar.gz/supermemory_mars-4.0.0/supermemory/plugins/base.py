"""Plugin Base Class for SuperMemory"""

from abc import ABC, abstractmethod
from typing import Dict, List, Callable, Any, Optional
import logging

logger = logging.getLogger(__name__)


class Plugin(ABC):
    """
    插件基类
    所有插件必须继承此类
    """

    name: str = "base_plugin"
    version: str = "1.0.0"
    description: str = ""
    core: bool = False  # 核心插件不可卸载
    dependencies: List[str] = []

    def __init__(self, event_bus, config: dict = None):
        self.event_bus = event_bus
        self.config = config or {}
        self._handlers: List[Dict[str, Any]] = []
        self._enabled = True
        self._logger = logging.getLogger(f"{__name__}.{self.name}")

    def on_load(self) -> None:
        """插件加载时调用"""
        self._logger.info(f"Plugin {self.name} v{self.version} loading...")
        self._register_handlers()
        self._logger.info(f"Plugin {self.name} loaded successfully")

    def on_unload(self) -> None:
        """插件卸载时调用"""
        self._logger.info(f"Plugin {self.name} unloading...")
        self._unregister_handlers()
        self._logger.info(f"Plugin {self.name} unloaded")

    def on_enable(self) -> None:
        """插件启用时调用"""
        self._enabled = True
        self._logger.info(f"Plugin {self.name} enabled")

    def on_disable(self) -> None:
        """插件禁用时调用"""
        self._enabled = False
        self._logger.info(f"Plugin {self.name} disabled")

    @abstractmethod
    def _register_handlers(self) -> None:
        """注册事件处理器 - 子类必须实现"""
        pass

    def _unregister_handlers(self) -> None:
        """注销所有事件处理器"""
        for handler in self._handlers:
            event = handler.get("event")
            callback = handler.get("callback")
            if event and callback:
                self.event_bus.unsubscribe(event, callback)
        self._handlers.clear()

    def subscribe(self, event: str, callback: Callable, priority: int = 0) -> None:
        """订阅事件"""
        self.event_bus.subscribe(event, callback, priority)
        self._handlers.append({"event": event, "callback": callback, "priority": priority})

    def emit(self, event: str, data: Any = None) -> None:
        """发出事件"""
        self.event_bus.emit(event, data)

    def get_event_handlers(self) -> List[Dict[str, Any]]:
        """获取已注册的事件处理器列表"""
        return self._handlers

    @property
    def enabled(self) -> bool:
        return self._enabled

    def get_info(self) -> Dict[str, Any]:
        """获取插件信息"""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "core": self.core,
            "dependencies": self.dependencies,
            "enabled": self._enabled,
        }
