"""Intent Prediction Plugin"""

import re
from typing import Dict, Any, Optional, List
from datetime import datetime

from .base import Plugin


class IntentPlugin(Plugin):
    """
    意图预测插件
    预测用户意图，提前准备相关记忆和动作
    """

    name = "intent"
    version = "1.0.0"
    description = "User intent prediction and anticipation"
    core = False
    dependencies = []

    INTENT_PATTERNS = {
        "search": [
            r"\b(搜索|查找|找|查询|搜)\b",
            r"\b(search|find|look for|query)\b",
        ],
        "create": [
            r"\b(创建|新建|添加|增加)\b",
            r"\b(create|add|new|make)\b",
        ],
        "update": [
            r"\b(更新|修改|编辑|改变|调整)\b",
            r"\b(update|edit|change|modify|alter)\b",
        ],
        "delete": [
            r"\b(删除|移除|去掉|清除)\b",
            r"\b(delete|remove|clear)\b",
        ],
        "share": [
            r"\b(分享|发送|发给|共享)\b",
            r"\b(share|send|give)\b",
        ],
        "recall": [
            r"\b(记得|回忆|想起|记起|想起)\b",
            r"\b(remember|recall|remind)\b",
        ],
        "compare": [
            r"\b(比较|对比|相比|差别)\b",
            r"\b(compare|versus|vs|difference)\b",
        ],
        "plan": [
            r"\b(计划|打算|准备|预计)\b",
            r"\b(plan|intend|prepare|schedule)\b",
        ],
    }

    def __init__(self, event_bus, config: dict = None):
        super().__init__(event_bus, config)
        self._intent_history: List[Dict[str, Any]] = []
        self._max_history = config.get("max_history", 50) if config else 50
        self._confidence_threshold = config.get("confidence_threshold", 0.3) if config else 0.3

    def _register_handlers(self) -> None:
        self.subscribe("interaction.user_message", self._on_user_message, priority=30)
        self.subscribe("intent.predict", self._on_intent_predict, priority=50)
        self.subscribe("intent.learn", self._on_intent_learn, priority=50)

    def _predict_intent(self, text: str) -> Dict[str, Any]:
        """预测用户意图"""
        text = str(text).lower()
        scores: Dict[str, float] = {}
        matched_patterns: Dict[str, List[str]] = {}

        for intent, patterns in self.INTENT_PATTERNS.items():
            scores[intent] = 0.0
            matched_patterns[intent] = []
            for pattern in patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                if matches:
                    scores[intent] += len(matches)
                    matched_patterns[intent].extend(matches)

        total_score = sum(scores.values())
        if total_score > 0:
            normalized = {k: v / total_score for k, v in scores.items()}
        else:
            normalized = scores

        # Filter by confidence threshold
        predictions = [
            {"intent": k, "confidence": v, "matches": matched_patterns.get(k, [])}
            for k, v in normalized.items()
            if v >= self._confidence_threshold
        ]
        predictions.sort(key=lambda x: x["confidence"], reverse=True)

        dominant = predictions[0] if predictions else {"intent": "unknown", "confidence": 0.0}
        return {
            "dominant": dominant["intent"],
            "confidence": dominant["confidence"],
            "predictions": predictions[:3],
            "timestamp": datetime.now().isoformat(),
        }

    def _on_user_message(self, data: Dict[str, Any]) -> None:
        text = data.get("text", "") or data.get("content", "")
        if text:
            prediction = self._predict_intent(text)
            data["intent_prediction"] = prediction
            self._intent_history.append({"text": text[:100], **prediction})
            if len(self._intent_history) > self._max_history:
                self._intent_history.pop(0)
            self.emit("intent.predicted", {"source": "user_message", **prediction})

    def _on_intent_predict(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        text = data.get("text")
        if not text:
            return None
        result = self._predict_intent(str(text))
        self.emit("intent.prediction_completed", result)
        return result

    def _on_intent_learn(self, data: Dict[str, Any]) -> None:
        """学习用户意图模式"""
        text = data.get("text", "")
        intent = data.get("intent")
        if text and intent:
            self._intent_history.append({
                "text": text[:100],
                "intent": intent,
                "learned": True,
                "timestamp": datetime.now().isoformat(),
            })
            self.emit("intent.learned", {"text": text[:50], "intent": intent})

    def get_status(self) -> Dict[str, Any]:
        return {
            "history_count": len(self._intent_history),
            "max_history": self._max_history,
            "confidence_threshold": self._confidence_threshold,
        }
