#!/usr/bin/env python3
"""
SuperMemory V4 - HTTP API Server
统一 API 入口,端口 8767
支持 X-API-Key 认证
"""
import http.server
import threading
import json
import os
import sys
import hashlib
import hmac
import secrets
from pathlib import Path
from urllib.parse import urlparse, parse_qs

# 添加包路径
SUPERMEMORY_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SUPERMEMORY_ROOT)

from supermemory.config import get_config, get_agent_config
from supermemory.core.service import SuperMemoryService

PORT = int(os.environ.get("SUPERMEMORY_PORT", 8767))

# API Key 认证配置
_API_KEY_FILE = os.path.expanduser("~/.supermemory/api_key.txt")
_API_KEY = None

def _load_api_key():
    """加载或生成API Key"""
    global _API_KEY
    if _API_KEY:
        return _API_KEY
    os.makedirs(os.path.dirname(_API_KEY_FILE), exist_ok=True)
    if os.path.exists(_API_KEY_FILE):
        with open(_API_KEY_FILE, "r") as f:
            _API_KEY = f.read().strip()
    else:
        _API_KEY = f"sm_{secrets.token_urlsafe(32)}"
        with open(_API_KEY_FILE, "w") as f:
            f.write(_API_KEY)
        os.chmod(_API_KEY_FILE, 0o600)
        print(f"New API Key generated: {_API_KEY}")
    return _API_KEY

def _verify_api_key(api_key: str) -> bool:
    """验证API Key"""
    if not api_key:
        return False
    stored_key = _load_api_key()
    return hmac.compare_digest(api_key, stored_key)

class Handler(http.server.BaseHTTPRequestHandler):
    """HTTP 请求处理"""

    def _send_json(self, data, status: int = 200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        def json_safe(obj):
            if isinstance(obj, str):
                return obj.replace("\r", "\\r").replace("\n", "\\n")
            elif isinstance(obj, dict):
                return {k: json_safe(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [json_safe(item) for item in obj]
            elif hasattr(obj, "to_dict"):
                return json_safe(obj.to_dict())
            elif hasattr(obj, "__dict__"):
                return json_safe(vars(obj))
            else:
                return obj
        self.wfile.write(json.dumps(json_safe(data), ensure_ascii=False).encode())

    def _check_auth(self) -> bool:
        """检查API Key认证"""
        api_key = self.headers.get("X-API-Key", "")
        if not api_key:
            parsed = urlparse(self.path)
            query = parse_qs(parsed.query)
            api_key = query.get("api_key", [""])[0]
        # Always require API key - generate if missing
        if not os.path.exists(_API_KEY_FILE):
            _load_api_key()  # Generate on first access
        if not _verify_api_key(api_key):
            self._send_json({"error": "Invalid or missing API Key. Use X-API-Key header."}, 401)
            return False
        return True

    def _parse_path(self, path: str):
        parts = path.strip("/").split("/")
        if len(parts) >= 3 and parts[0] == "api":
            return parts[1], parts[2] if len(parts) > 2 else None, parts[3] if len(parts) > 3 else None
        return None, None, None

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/health":
            self._send_json({"status": "ok", "service": "SuperMemory", "version": "4.0.0"})
            return
        if path == "/api-key-info":
            api_key = self.headers.get("X-API-Key", "")
            self._send_json({"status": "valid" if _verify_api_key(api_key) else "invalid"})
            return
        if not self._check_auth():
            return
        if path == "/status":
            sm = get_sm("mars")
            self._send_json(sm.get_stats())
            return
        if path == "/all-stats":
            self._send_json(SuperMemoryService.all_stats())
            return
        self._send_json({"error": "Unknown endpoint"}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode() if content_length > 0 else "{}"
        if path == "/health":
            self._send_json({"status": "ok", "service": "SuperMemory", "version": "4.0.0"})
            return
        if path == "/api-key-info":
            api_key = self.headers.get("X-API-Key", "")
            self._send_json({"status": "valid" if _verify_api_key(api_key) else "invalid"})
            return
        if not self._check_auth():
            return
        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            self._send_json({"error": "Invalid JSON"}, 400)
            return
        agent_id, endpoint, resource_id = self._parse_path(path)
        if endpoint == "search":
            query = data.get("query", "")
            limit = data.get("limit", 10)
            agent = agent_id or "mars"
            sm = get_sm(agent)
            results = sm.search(query, limit=limit)
            self._send_json({"results": results})
            return
        if endpoint == "add":
            content = data.get("content", "")
            agent = agent_id or "mars"
            tags = data.get("tags", [])
            importance = data.get("importance", "P1")
            sm = get_sm(agent)
            memory = sm.add_memory(content, tags=tags, importance=importance)
            self._send_json({"memory": memory})
            return
        if endpoint == "get" and resource_id:
            agent = agent_id or "mars"
            sm = get_sm(agent)
            memory = sm.get_memory(resource_id)
            if memory:
                self._send_json({"memory": memory})
            else:
                self._send_json({"error": "Memory not found"}, 404)
            return
        if endpoint == "stats":
            agent = agent_id or "mars"
            sm = get_sm(agent)
            self._send_json(sm.get_stats())
            return
        self._send_json({"error": "Unknown endpoint"}, 404)

def run():
    """启动 API 服务器"""
    main()

def main():
    import argparse
    parser = argparse.ArgumentParser(description="SuperMemory API Server")
    parser.add_argument("--port", type=int, default=PORT, help="Port")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Host")
    parser.add_argument("--reset-key", action="store_true", help="Reset API Key")
    args = parser.parse_args()
    if args.reset_key:
        global _API_KEY
        _API_KEY = f"sm_{secrets.token_urlsafe(32)}"
        os.makedirs(os.path.dirname(_API_KEY_FILE), exist_ok=True)
        with open(_API_KEY_FILE, "w") as f:
            f.write(_API_KEY)
        os.chmod(_API_KEY_FILE, 0o600)
        print(f"New API Key: {_API_KEY}")
        return
    _load_api_key()
    print(f"API Key: {_API_KEY}")
    server = http.server.HTTPServer((args.host, args.port), Handler)
    print(f"SuperMemory API started: http://{args.host}:{args.port}")
    print(f"Health: curl http://localhost:{args.port}/health")
    server.serve_forever()

if __name__ == "__main__":
    main()
