#!/usr/bin/env python3
"""
SuperMemory V4 - Evolver Framework
包含 V4 统一进化 + 自愈 + OpenSpace 高级进化器
"""
from .self_healer import SelfHealer, HealerIssue
from .skill_registry import SkillRegistry, Skill
from .evolution_manager import EvolutionManager
from .base import Evolver, EvolutionResult

# Advanced evolvers (from GitHub)
try:
    from .advanced.framework import EvolutionFramework
except ImportError:
    EvolutionFramework = None

try:
    from .advanced.openspace_evolution import OpenSpaceEvolver
except ImportError:
    OpenSpaceEvolver = None

try:
    from .advanced.github_learner import GitHubLearner
except ImportError:
    GitHubLearner = None

try:
    from .advanced.pattern_extractor import PatternExtractor
except ImportError:
    PatternExtractor = None

try:
    from .advanced.strategy_optimizer import StrategyOptimizer
except ImportError:
    StrategyOptimizer = None

try:
    from .advanced.incremental_learner import IncrementalLearner
except ImportError:
    IncrementalLearner = None

try:
    from .advanced.error_healer import ErrorHealer
except ImportError:
    ErrorHealer = None

try:
    from .advanced.base import Evolver as BaseEvolver
except ImportError:
    BaseEvolver = None

__all__ = [
    # 核心
    "SelfHealer", "HealerIssue",
    "SkillRegistry", "Skill",
    "EvolutionManager", "EvolutionResult",
    "Evolver", "BaseEvolver",
    # 高级进化器
    "EvolutionFramework",
    "OpenSpaceEvolver",
    "GitHubLearner",
    "PatternExtractor",
    "StrategyOptimizer",
    "IncrementalLearner",
    "ErrorHealer",
]
