#!/usr/bin/env python3
"""
SuperMemory V4 - 技能注册中心
所有进化出来的技能在此注册，自愈系统统一管理和修复
"""
import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import logging

logger = logging.getLogger(__name__)


@dataclass
class Skill:
    """技能条目"""
    skill_id: str
    name: str
    module: str          # 所属模块 (core/advanced/evolver/plugin)
    version: str = "1.0.0"
    lineage: str = ""    # 父技能ID
    owner: str = ""      # 拥有者 (OpenSpaceEvolver, GitHubLearner 等)
    health_score: float = 1.0  # 0.0-1.0
    issues: List[str] = None   # 当前问题列表
    created_at: str = ""
    last_checked: str = ""
    evolve_type: str = "FIX"  # FIX, DERIVED, CAPTURED
    metadata: Dict[str, Any] = None
    description: str = ""  # 技能描述

    def __post_init__(self):
        if self.issues is None:
            self.issues = []
        if self.metadata is None:
            self.metadata = {}
        if not self.created_at:
            self.created_at = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Skill":
        d.pop('_event_bus', None)
        d.pop('event_bus', None)
        # Handle missing description field (backwards compat)
        d.setdefault('description', '')
        return cls(**d)


class SkillRegistry:
    """
    技能注册中心 - 所有进化技能的核心数据库
    自愈系统通过此中心知道所有技能的状态，并进行修复
    """

    VERSION = "1.0.0"

    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.registry_file = self.data_dir / "skill_registry.json"
        self._lock = threading.RLock()
        self._skills: Dict[str, Skill] = {}
        self._listeners: List[callable] = []  # 技能变更监听器
        self._load()

        # 自动注册核心技能（第一次初始化时）
        if not self._skills:
            self._register_core_skills()

    def _load(self):
        """从磁盘加载"""
        if self.registry_file.exists():
            try:
                with open(self.registry_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self._skills = {k: Skill.from_dict(v) for k, v in data.items()}
                logger.info(f"SkillRegistry 加载了 {len(self._skills)} 个技能")
            except (json.JSONDecodeError, TypeError) as e:
                logger.warning(f"SkillRegistry 加载失败: {e}，将重新初始化")
                self._skills = {}

    def _save(self):
        """持久化到磁盘"""
        self.registry_file.parent.mkdir(parents=True, exist_ok=True)
        data = {k: v.to_dict() for k, v in self._skills.items()}
        with open(self.registry_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _notify_listeners(self, event: str, skill: Skill):
        """通知所有监听器"""
        for listener in self._listeners:
            try:
                listener(event, skill)
            except Exception as e:
                logger.warning(f"SkillRegistry 监听器异常: {e}")

    def register_skill(self, skill: Skill) -> bool:
        """注册技能"""
        with self._lock:
            if skill.skill_id in self._skills:
                logger.warning(f"技能 {skill.skill_id} 已存在，将更新")
            skill.last_checked = datetime.now().isoformat()
            self._skills[skill.skill_id] = skill
            self._save()
            self._notify_listeners("registered", skill)
            logger.info(f"注册技能: {skill.skill_id} (owner: {skill.owner})")
            return True

    def get_skill(self, skill_id: str) -> Optional[Skill]:
        """获取技能"""
        return self._skills.get(skill_id)

    def list_skills(self, module: str = None, owner: str = None,
                    unhealthy_only: bool = False) -> List[Skill]:
        """列出技能"""
        results = list(self._skills.values())
        if module:
            results = [s for s in results if s.module == module]
        if owner:
            results = [s for s in results if s.owner == owner]
        if unhealthy_only:
            results = [s for s in results if s.health_score < 1.0]
        return results

    def update_health(self, skill_id: str, health_score: float,
                      issues: List[str] = None) -> bool:
        """更新技能健康状态"""
        with self._lock:
            skill = self._skills.get(skill_id)
            if not skill:
                return False
            skill.health_score = max(0.0, min(1.0, health_score))
            if issues is not None:
                skill.issues = issues
            skill.last_checked = datetime.now().isoformat()
            self._save()
            event = "healed" if health_score >= 1.0 else "degraded"
            self._notify_listeners(event, skill)
            return True

    def get_unhealthy_skills(self) -> List[Skill]:
        """获取所有不健康的技能"""
        return [s for s in self._skills.values() if s.health_score < 1.0]

    def get_stats(self) -> Dict:
        """获取统计信息"""
        skills = list(self._skills.values())
        by_module = {}
        by_owner = {}
        by_health = {"healthy": 0, "degraded": 0, "broken": 0}

        for s in skills:
            by_module[s.module] = by_module.get(s.module, 0) + 1
            by_owner[s.owner] = by_owner.get(s.owner, 0) + 1
            if s.health_score >= 1.0:
                by_health["healthy"] += 1
            elif s.health_score >= 0.5:
                by_health["degraded"] += 1
            else:
                by_health["broken"] += 1

        return {
            "total": len(skills),
            "by_module": by_module,
            "by_owner": by_owner,
            "by_health": by_health,
            "unhealthy_count": len(self.get_unhealthy_skills()),
        }

    def add_listener(self, listener: callable):
        """添加技能变更监听器（用于自愈系统）"""
        self._listeners.append(listener)

    def _register_core_skills(self):
        """注册核心技能（系统内置）"""
        core_skills = [
            Skill(skill_id="core.memory", name="记忆服务", module="core",
                  owner="system", evolve_type="FIX",
                  description="SQLite记忆存储服务"),
            Skill(skill_id="core.vector", name="向量服务", module="core",
                  owner="system", evolve_type="FIX",
                  description="768维向量嵌入与语义搜索"),
            Skill(skill_id="core.layer", name="三层记忆", module="core",
                  owner="system", evolve_type="FIX",
                  description="热/暖/冷层自动流转"),
            Skill(skill_id="core.wal", name="WAL日志", module="core",
                  owner="system", evolve_type="FIX",
                  description="预写日志崩溃恢复"),
            Skill(skill_id="core.backup", name="备份服务", module="core",
                  owner="system", evolve_type="FIX",
                  description="定时全量备份与恢复"),
            Skill(skill_id="core.integrity", name="完整性检查", module="core",
                  owner="system", evolve_type="FIX",
                  description="数据库健康检查"),
            Skill(skill_id="core.service", name="统一服务", module="core",
                  owner="system", evolve_type="FIX",
                  description="SuperMemory统一服务门面"),
            Skill(skill_id="core.hybrid_search", name="混合搜索", module="core.advanced",
                  owner="system", evolve_type="FIX",
                  description="BM25+向量联合搜索"),
            Skill(skill_id="core.git_sync", name="Git同步", module="core.advanced",
                  owner="system", evolve_type="FIX",
                  description="记忆自动Git备份"),
            Skill(skill_id="core.version_control", name="版本控制", module="core.advanced",
                  owner="system", evolve_type="FIX",
                  description="记忆版本历史追踪"),
            Skill(skill_id="core.context_manager", name="上下文管理", module="core.advanced",
                  owner="system", evolve_type="FIX",
                  description="主动式上下文压缩"),
            Skill(skill_id="evolver.self_healer", name="自愈系统", module="evolver",
                  owner="system", evolve_type="FIX",
                  description="全面自愈与修复"),
            Skill(skill_id="evolver.openspace", name="OpenSpace进化", module="evolver",
                  owner="system", evolve_type="FIX",
                  description="OpenSpace技能自进化"),
            Skill(skill_id="evolver.github_learner", name="GitHub学习器", module="evolver",
                  owner="system", evolve_type="FIX",
                  description="从GitHub学习最佳实践"),
            Skill(skill_id="evolver.pattern_extractor", name="模式提取", module="evolver",
                  owner="system", evolve_type="FIX",
                  description="模式识别与提取"),
            Skill(skill_id="evolver.strategy_optimizer", name="策略优化", module="evolver",
                  owner="system", evolve_type="FIX",
                  description="策略优化与推导"),
        ]

        for skill in core_skills:
            self._skills[skill.skill_id] = skill

        self._save()
        logger.info(f"已注册 {len(core_skills)} 个核心技能")

    def evolve_skill(self, parent_id: str, new_skill: Skill) -> bool:
        """
        进化技能（创建新版本或派生技能）
        新技能自动注册到注册中心
        """
        parent = self._skills.get(parent_id)
        if not parent:
            logger.warning(f"父技能 {parent_id} 不存在，无法进化")
            return False

        new_skill.lineage = parent_id
        new_skill.evolve_type = "DERIVED"
        new_skill.owner = parent.owner

        # 版本继承并更新
        parent_ver = parent.version.split(".")
        if len(parent_ver) == 3:
            new_ver = f"{parent_ver[0]}.{parent_ver[1]}.{int(parent_ver[2]) + 1}"
        else:
            new_ver = f"{parent.version}.1"

        new_skill.version = new_ver
        self.register_skill(new_skill)

        # 标记父技能为"已进化"
        parent.issues.append(f"superseded_by: {new_skill.skill_id}")
        parent.health_score = 0.5
        self.update_health(parent.skill_id, 0.5, parent.issues)

        logger.info(f"技能进化: {parent_id} → {new_skill.skill_id} (v{new_ver})")
        return True
