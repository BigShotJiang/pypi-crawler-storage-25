#!/usr/bin/env python3
"""
SuperMemory V4 - 进化管理器
统一管理所有进化器，集成自愈系统
"""
import logging
import os
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed

from .base import Evolver, EvolutionResult
from .skill_registry import SkillRegistry, Skill
from .self_healer import SelfHealer

logger = logging.getLogger(__name__)


class EvolutionManager:
    """
    进化管理器 - 所有进化系统的中央协调器
    1. 管理所有 evolver 的注册和运行
    2. 与 SelfHealer 深度集成：进化后自动触发健康检查
    3. 进化出的新技能自动注册到 SkillRegistry
    4. 支持扩展：新增 evolver 后自动发现并注册
    """

    VERSION = "4.0.0"
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, config: dict = None):
        # 避免重复初始化（__new__ 每次调用，__init__ 只在首次执行）
        if EvolutionManager._initialized:
            return
        EvolutionManager._initialized = True

        self.config = config or {}

        data_dir = os.path.expanduser(
            self.config.get("data_dir", "~/.openclaw/workspace-shared/super-memory-data")
        )
        self.data_dir = Path(data_dir)

        # 技能注册中心
        self.registry = SkillRegistry(str(self.data_dir))

        # 自愈系统（与进化深度集成）
        self.self_healer = SelfHealer({
            "data_dir": str(self.data_dir),
            "agents": self.config.get("agents", ["mars", "chen", "wei", "ying"]),
        })

        # 进化器注册表
        self._evolvers: Dict[str, Evolver] = {}
        self._lock = threading.Lock()

        # 回调函数
        self._callbacks: List[Callable] = []

        # 扫描并注册所有内置 evolver
        self._register_builtin_evolvers()

        # 将 SelfHealer 注册为进化回调（进化完成后自动自愈）
        self.register_callback(self._on_evolution_complete)

        # 线程池（用于并行运行 evolver）
        self._executor = ThreadPoolExecutor(max_workers=4)

        logger.info(f"EvolutionManager v{self.VERSION} 初始化完成")
        logger.info(f"已注册进化器: {list(self._evolvers.keys())}")

    # ============================================================================
    # 进化器注册
    # ============================================================================

    def register_evolver(self, evolver: Evolver, skill_id: str = None) -> bool:
        """注册进化器（含自动验证）"""
        with self._lock:
            # 验证必需属性
            issues = self._validate_evolver(evolver)
            if issues:
                logger.error(f"[EvolutionManager] 进化器 {evolver.name} 验证失败: {issues}")
                return False

            # 测试运行一次 evolve()（带超时，避免 GitHubLearner 等网络调用卡住初始化）
            try:
                import threading
                import queue
                
                result_queue = queue.Queue()
                def run_evolve():
                    try:
                        r = evolver.evolve()
                        result_queue.put(('ok', r))
                    except Exception as e:
                        result_queue.put(('err', str(e)))
                
                t = threading.Thread(target=run_evolve, daemon=True)
                t.start()
                t.join(timeout=5)  # 最多等5秒
                
                if t.is_alive():
                    logger.warning(f"[EvolutionManager] 进化器 {evolver.name} 测试运行超时（5s），跳过")
                else:
                    try:
                        status, data = result_queue.get_nowait()
                        if status == 'ok':
                            logger.info(f"[EvolutionManager] 进化器 {evolver.name} 测试运行: {data.message[:60]}")
                        else:
                            logger.warning(f"[EvolutionManager] 进化器 {evolver.name} 测试运行失败: {data}")
                    except queue.Empty:
                        pass
            except Exception as e:
                logger.warning(f"[EvolutionManager] 进化器 {evolver.name} 测试运行异常: {e}")

            if evolver.name in self._evolvers:
                logger.warning(f"进化器 {evolver.name} 已存在，将更新")
            self._evolvers[evolver.name] = evolver

            # 自动注册到 SkillRegistry
            if skill_id:
                skill = Skill(
                    skill_id=skill_id,
                    name=evolver.name,
                    module="evolver",
                    owner=evolver.name,
                    evolve_type="FIX",
                    version=evolver.version,
                    description=evolver.description or evolver.name,
                )
                self.registry.register_skill(skill)

            logger.info(f"注册进化器: {evolver.name} (v{evolver.version})")
            return True

    def _validate_evolver(self, evolver: Evolver) -> List[str]:
        """验证 evolver 是否有所有必需属性"""
        issues = []
        REQUIRED = ["name", "version", "description", "_enabled", "interval_hours"]
        for attr in REQUIRED:
            if not hasattr(evolver, attr):
                issues.append(f"缺少属性: {attr}")
            elif getattr(evolver, attr) is None:
                issues.append(f"属性为空: {attr}")
        # 检查 evolve() 方法存在
        if not hasattr(evolver, "evolve"):
            issues.append("缺少 evolve() 方法")
        elif not callable(getattr(evolver, "evolve")):
            issues.append("evolve 不是可调用方法")
        return issues

    def unregister_evolver(self, name: str) -> bool:
        with self._lock:
            if name in self._evolvers:
                del self._evolvers[name]
                return True
            return False

    def list_evolvers(self) -> List[Dict]:
        return [
            {
                "name": e.name,
                "version": e.version,
                "description": e.description,
                "enabled": e._enabled,
                "stats": e.stats,
            }
            for e in self._evolvers.values()
        ]

    # ============================================================================
    # 进化执行
    # ============================================================================

    def evolve_all(self) -> List[EvolutionResult]:
        """运行所有需要进化的 evolver"""
        results = []

        for name, evolver in list(self._evolvers.items()):
            if evolver.should_evolve():
                logger.info(f"[EvolutionManager] 运行进化器: {name}")
                result = evolver.evolve()
                results.append(result)

                # 进化完成后，通知回调
                self._fire_callbacks(name, result)

                # 如果进化产生了新技能，注册到 SkillRegistry
                if result.success and result.changes:
                    self._register_evolved_skills(name, result)

        return results

    def evolve(self, evolver_name: str) -> EvolutionResult:
        """运行指定的进化器"""
        evolver = self._evolvers.get(evolver_name)
        if not evolver:
            return EvolutionResult(
                success=False,
                evolver_name=evolver_name,
                error=f"进化器 {evolver_name} 不存在",
            )

        result = evolver.evolve()
        self._fire_callbacks(evolver_name, result)

        if result.success and result.changes:
            self._register_evolved_skills(evolver_name, result)

        return result

    # ============================================================================
    # 自愈集成
    # ============================================================================

    def _on_evolution_complete(self, evolver_name: str, result: EvolutionResult):
        """
        进化完成后的回调：自动触发自愈
        确保进化产生的新功能立即纳入自愈体系
        """
        if result.success:
            logger.info(f"[EvolutionManager] 进化 {evolver_name} 完成，触发自愈检查...")
            self.self_healer.run_healing_cycle()

    def run_self_healing(self) -> Dict[str, Any]:
        """主动触发自愈"""
        return self.self_healer.run_healing_cycle()

    def get_healer_status(self) -> Dict[str, Any]:
        """获取自愈系统状态"""
        return self.self_healer.get_status()

    # ============================================================================
    # 回调系统
    # ============================================================================

    def register_callback(self, callback: Callable):
        """注册进化完成回调"""
        self._callbacks.append(callback)

    def _fire_callbacks(self, evolver_name: str, result: EvolutionResult):
        for cb in self._callbacks:
            try:
                cb(evolver_name, result)
            except Exception as e:
                logger.warning(f"[EvolutionManager] 回调异常: {e}")

    # ============================================================================
    # 扩展机制
    # ============================================================================

    def _register_builtin_evolvers(self):
        """自动扫描并注册所有内置 evolver"""
        try:
            import supermemory as sm

            # 从 GitHub 集成的 evolver
            evolver_map = {
                "OpenSpaceEvolver": ("evolver.openspace", sm.OpenSpaceEvolver, True),  # needs data_dir
                "GitHubLearner": ("evolver.github_learner", sm.GitHubLearner, False),
                "PatternExtractor": ("evolver.pattern_extractor", sm.PatternExtractor, False),
                "StrategyOptimizer": ("evolver.strategy_optimizer", sm.StrategyOptimizer, False),
                "IncrementalLearner": ("evolver.incremental_learner", sm.IncrementalLearner, False),
                "ErrorHealer": ("evolver.error_healer", sm.ErrorHealer, False),
            }

            for name, (skill_id, cls, needs_data_dir) in evolver_map.items():
                try:
                    if needs_data_dir:
                        evolver = cls(data_dir=str(self.data_dir))
                    else:
                        evolver = cls()
                    self.register_evolver(evolver, skill_id)
                    logger.info(f"[EvolutionManager] 自动注册: {name}")
                except Exception as e:
                    logger.warning(f"[EvolutionManager] 无法注册 {name}: {e}")

            # 扫描 evolver/advanced/ 目录，自动注册新 evolver
            evolver_dir = Path(__file__).parent / "advanced"
            if evolver_dir.exists():
                # 构建已注册 skill_id suffix 集合（从 evolver_map 的 skill_id 中提取）
                # evolver_map = {"ClassName": ("evolver.xxx", cls, needs_data_dir)}
                # 我们提取 "xxx" 部分来匹配文件 stems
                registered_suffixes = set()
                for skill_id, _cls, _needs in evolver_map.values():
                    # skill_id like "evolver.openspace" -> "openspace"
                    suffix = skill_id.replace("evolver.", "").lower()
                    # Normalize: remove underscores/hyphens for comparison
                    normalized = suffix.replace("-", "").replace("_", "")
                    registered_suffixes.add(suffix)
                    registered_suffixes.add(normalized)
                    registered_suffixes.add(suffix.replace("-", "_"))
                    registered_suffixes.add(suffix.replace("_", "-"))

                for py_file in evolver_dir.glob("*.py"):
                    stem_lower = py_file.stem.lower()
                    stem_normalized = py_file.stem.lower().replace("-", "").replace("_", "")

                    # 跳过已注册（通过 evolver_map skill_id 匹配，考虑各种命名变体）
                    if stem_lower in registered_suffixes or stem_normalized in registered_suffixes:
                        continue

                    # 跳过基础设施文件
                    if py_file.stem in ("base", "framework", "__init__"):
                        continue
                    try:
                        module = __import__(
                            f"supermemory.evolver.advanced.{py_file.stem}",
                            fromlist=[py_file.stem]
                        )
                        cls = getattr(module, py_file.stem.title().replace("_", ""), None)
                        if cls and isinstance(cls, type):
                            evolver = cls()
                            skill_id = f"evolver.advanced.{py_file.stem}"
                            self.register_evolver(evolver, skill_id)
                            logger.info(f"[EvolutionManager] 自动注册 (advanced): {py_file.stem}")
                    except Exception:
                        pass

        except Exception as e:
            logger.warning(f"[EvolutionManager] 扫描内置 evolver 失败: {e}")

    def _register_evolved_skills(self, evolver_name: str, result: EvolutionResult):
        """
        将进化产生的新技能注册到 SkillRegistry
        自愈系统会自动接管这些新技能
        """
        changes = result.changes or {}

        for key, value in changes.items():
            if key.startswith("new_skill:") or key == "skill_id":
                skill_data = value if isinstance(value, dict) else {"skill_id": value}
                skill = Skill(
                    skill_id=skill_data.get("skill_id", f"{evolver_name}.evolved.1"),
                    name=skill_data.get("name", evolver_name),
                    module=skill_data.get("module", "evolved"),
                    owner=evolver_name,
                    evolve_type="DERIVED",
                    description=result.message,
                )
                self.registry.register_skill(skill)
                logger.info(f"[EvolutionManager] 注册进化技能: {skill.skill_id} (owner: {evolver_name})")

    # ============================================================================
    # 统计和状态
    # ============================================================================

    def summary(self) -> Dict[str, Any]:
        """获取完整系统状态"""
        return {
            "version": self.VERSION,
            "evolvers": {
                "count": len(self._evolvers),
                "list": self.list_evolvers(),
            },
            "skills": self.registry.get_stats(),
            "healer": self.self_healer.get_status(),
        }

    def health_check(self) -> Dict[str, Any]:
        """整体健康检查"""
        healer_hc = self.self_healer.health_check()
        registry_stats = self.registry.get_stats()

        all_healthy = (
            healer_hc.get("status") == "healthy" and
            registry_stats.get("unhealthy_count", 0) == 0
        )

        return {
            "status": "healthy" if all_healthy else "degraded",
            "version": self.VERSION,
            "healer": healer_hc,
            "registry": {
                "total_skills": registry_stats.get("total", 0),
                "unhealthy": registry_stats.get("unhealthy_count", 0),
                "healthy_ratio": f"{registry_stats.get('by_health', {}).get('healthy', 0)}/{registry_stats.get('total', 0)}",
            },
        }

    def get_unhealthy_skills(self) -> List[Skill]:
        """获取所有不健康的技能"""
        return self.registry.get_unhealthy_skills()
