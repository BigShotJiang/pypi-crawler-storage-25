#!/usr/bin/env python3
"""
SuperMemory V4 - 全面自愈系统
所有记忆系统问题都能修复,同时自动修复进化系统扩展出的新功能
"""
import json
import logging
import os
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict

from .base import Evolver, EvolutionResult
from .skill_registry import SkillRegistry, Skill

logger = logging.getLogger(__name__)


@dataclass
class HealerIssue:
    """自愈问题条目"""
    id: str
    severity: str          # critical, warning, info
    module: str           # 对应 SkillRegistry 的 skill_id
    description: str
    detected_at: str
    fixed: bool = False
    fix_attempts: int = 0
    last_fix_error: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class SelfHealer(Evolver):
    VERSION = "4.0.0"

    """
    全面自愈系统
    - 内置所有核心模块的检查器和修复器
    - 监听 SkillRegistry,自动修复进化的技能
    - 作为 EvolutionFramework 的回调,接收进化通知
    - 扩展性:新增 evolver 时自动注册,无需修改代码
    """

    name = "self_healer"
    version = "4.0.0"
    description = "全面自愈系统 - 修复所有模块和进化技能"
    interval_hours = 1  # 每小时自愈检查一次

    def __init__(self, config: dict = None):
        super().__init__(config)

        # 数据目录
        data_dir = os.path.expanduser(
            self.config.get("data_dir", "~/.openclaw/workspace-shared/super-memory-data")
        )
        self.data_dir = Path(data_dir)

        # 技能注册中心(自愈系统管辖的所有技能)
        self.registry = SkillRegistry(str(self.data_dir))

        # 自愈系统管辖的 Agent
        self.agents = self.config.get("agents", ["mars", "chen", "wei", "ying"])

        # 问题追踪
        self._issues: Dict[str, HealerIssue] = {}
        self._lock = threading.Lock()

        # 自愈检查间隔（秒）
        self._check_interval = self.config.get("check_interval", 300)  # 默认5分钟

        # ================================================================
        # 检查器注册表 (skill_id → checker_function)
        # 每个 core 模块、evolver、plugin 都有对应的检查函数
        # 扩展方式:直接在 CHECKERS dict 里加一行
        # ================================================================
        self.CHECKERS: Dict[str, Callable] = {
            # Core 模块检查器
            "core.memory": self._check_memory,
            "core.vector": self._check_vector,
            "core.layer": self._check_layer,
            "core.wal": self._check_wal,
            "core.backup": self._check_backup,
            "core.integrity": self._check_integrity,
            "core.service": self._check_service,
            "core.hybrid_search": self._check_hybrid_search,
            "core.git_sync": self._check_git_sync,
            "core.version_control": self._check_version_control,
            "core.context_manager": self._check_context_manager,
            # Evolver 检查器
            "evolver.self_healer": self._check_self_healer,
            "evolver.openspace": self._check_openspace,
            "evolver.github_learner": self._check_github_learner,
            "evolver.pattern_extractor": self._check_pattern_extractor,
            "evolver.strategy_optimizer": self._check_strategy_optimizer,
            # 高级进化器
            "evolver.framework": self._check_framework,
            "evolver.error_healer": self._check_error_healer,
            "evolver.incremental_learner": self._check_incremental_learner,
        }

        # ================================================================
        # 修复器注册表 (skill_id → fixer_function)
        # 每个模块的修复函数
        # ================================================================
        self.FIXERS: Dict[str, Callable] = {
            "core.memory": self._fix_memory,
            "core.vector": self._fix_vector,
            "core.layer": self._fix_layer,
            "core.wal": self._fix_wal,
            "core.backup": self._fix_backup,
            "core.integrity": self._fix_integrity,
            "core.service": self._fix_service,
            "core.hybrid_search": self._fix_hybrid_search,
            "core.git_sync": self._fix_git_sync,
            "core.version_control": self._fix_version_control,
            "core.context_manager": self._fix_context_manager,
            "evolver.self_healer": self._fix_self_healer,
            "evolver.openspace": self._fix_openspace,
            "evolver.github_learner": self._fix_github_learner,
            "evolver.pattern_extractor": self._fix_pattern_extractor,
            "evolver.strategy_optimizer": self._fix_strategy_optimizer,
            "evolver.framework": self._fix_framework,
            "evolver.error_healer": self._fix_error_healer,
            "evolver.incremental_learner": self._fix_incremental_learner,
        }

        # 监听 SkillRegistry,自动修复新增的进化技能
        self.registry.add_listener(self._on_skill_event)

        logger.info(f"SelfHealer v{self.version} 初始化完成")
        logger.info(f"CHECKERS: {len(self.CHECKERS)} 个")
        logger.info(f"FIXERS: {len(self.FIXERS)} 个")

    # ============================================================================
    # Evolver 基类方法
    # ============================================================================

    def _evolve(self) -> EvolutionResult:
        """执行自愈进化(由 Evolver 基类调用)"""
        result = self.run_healing_cycle()
        return EvolutionResult(
            success=True,
            evolver_name=self.name,
            changes={"issues_found": result["issues_found"],
                     "issues_fixed": result["issues_fixed"]},
            message=f"自愈完成: 发现{result['issues_found']}个问题,修复{result['issues_fixed']}个",
        )

    # ============================================================================
    # 核心自愈循环
    # ============================================================================

    def run_healing_cycle(self) -> Dict[str, Any]:
        """
        执行一次完整的自愈周期
        1. 检查所有注册的技能
        2. 发现问题
        3. 自动修复
        4. 更新 SkillRegistry 健康状态
        5. 通知进化系统
        """
        results = {
            "timestamp": datetime.now().isoformat(),
            "issues_found": 0,
            "issues_fixed": 0,
            "checks_performed": [],
            "fixes_performed": [],
            "errors": [],
        }

        logger.info("[SelfHealer] 开始自愈检查...")

        # 1. 检查所有注册的技能
        for skill in self.registry.list_skills():
            checker = self.CHECKERS.get(skill.skill_id)
            if not checker:
                # 新技能没有检查器,自动注册(扩展机制)
                logger.info(f"[SelfHealer] 发现新技能 {skill.skill_id},尝试动态检查...")
                issues = self._dynamic_check(skill)
            else:
                issues = checker()

            results["checks_performed"].append(skill.skill_id)

            current_issues = []  # 重置当前技能的问题列表
            fixed_count = 0
            health = 1.0  # 默认健康（无问题=健康）

            if issues:
                results["issues_found"] += len(issues)
                logger.warning(f"[SelfHealer] {skill.skill_id}: {len(issues)} 个问题")

                # 记录问题
                for issue_desc in issues:
                    issue_id = f"{skill.skill_id}:{issue_desc[:30]}"
                    issue = HealerIssue(
                        id=issue_id,
                        severity="warning",
                        module=skill.skill_id,
                        description=issue_desc,
                        detected_at=datetime.now().isoformat(),
                    )

                    with self._lock:
                        self._issues[issue_id] = issue

                    # 2. 尝试修复
                    fixer = self.FIXERS.get(skill.skill_id)
                    if fixer:
                        try:
                            fix_ok = fixer(issues)
                            if fix_ok:
                                issue.fixed = True
                                issue.fix_attempts += 1
                                fixed_count += 1
                                results["issues_fixed"] += 1
                                results["fixes_performed"].append(skill.skill_id)
                                logger.info(f"[SelfHealer] ✅ 修复成功: {skill.skill_id}")
                            else:
                                issue.fix_attempts += 1
                                issue.last_fix_error = "fixer returned False"
                        except Exception as e:
                            issue.fix_attempts += 1
                            issue.last_fix_error = str(e)[:100]
                            results["errors"].append(f"{skill.skill_id}: {e}")
                            logger.error(f"[SelfHealer] ❌ 修复失败: {skill.skill_id}: {e}")
                    else:
                        logger.warning(f"[SelfHealer] {skill.skill_id}: 无修复器")
                        issue.fix_attempts += 1
                        issue.last_fix_error = "no fixer registered"

                    # 收集未修复的问题
                    if not issue.fixed:
                        current_issues.append(issue.description)

            # 3. 更新技能健康状态
            # 有问题但全部修复 → 健康(1.0)
            # 有问题但部分修复 → 部分健康(0.5)
            # 有问题但都没修复 → 不健康(0.0)
            # 没有问题 → 健康(1.0)
            if not issues:
                health = 1.0
            elif fixed_count == len(issues):
                health = 1.0
            elif fixed_count > 0:
                health = 0.5
            else:
                health = 0.0

            self.registry.update_health(skill.skill_id, health, current_issues)

        logger.info(f"[SelfHealer] 自愈完成: {results['issues_found']}发现/{results['issues_fixed']}修复")

        return results

    def _dynamic_check(self, skill: Skill) -> List[str]:
        """
        动态检查未知技能
        通过尝试导入模块来验证技能是否可用
        """
        issues = []
        try:
            parts = skill.skill_id.split(".")
            # 硬编码映射:skill_id -> 实际模块路径
            skill_to_module = {
                # evolver.xxx -> actual module path
                "evolver.openspace": "supermemory.evolver.advanced.openspace_evolution",
                "evolver.github_learner": "supermemory.evolver.advanced.github_learner",
                "evolver.pattern_extractor": "supermemory.evolver.advanced.pattern_extractor",
                "evolver.strategy_optimizer": "supermemory.evolver.advanced.strategy_optimizer",
                "evolver.incremental_learner": "supermemory.evolver.advanced.incremental_learner",
                "evolver.error_healer": "supermemory.evolver.advanced.error_healer",
                "evolver.framework": "supermemory.evolver.advanced.framework",
                # evolver.advanced.xxx -> actual module path
                "evolver.advanced.openspace_evolution": "supermemory.evolver.advanced.openspace_evolution",
                "evolver.advanced.github_learner": "supermemory.evolver.advanced.github_learner",
                "evolver.advanced.pattern_extractor": "supermemory.evolver.advanced.pattern_extractor",
                "evolver.advanced.strategy_optimizer": "supermemory.evolver.advanced.strategy_optimizer",
                "evolver.advanced.incremental_learner": "supermemory.evolver.advanced.incremental_learner",
                "evolver.advanced.error_healer": "supermemory.evolver.advanced.error_healer",
                "evolver.advanced.framework": "supermemory.evolver.advanced.framework",
            }

            if skill.skill_id in skill_to_module:
                module_path = skill_to_module[skill.skill_id]
            elif parts[0] == "core":
                module_path = "supermemory.core." + ".".join(parts[1:])
            elif parts[0] == "evolver":
                if len(parts) >= 2 and parts[1] == "advanced":
                    # evolver.advanced.xxx -> supermemory.evolver.advanced.xxx
                    module_path = "supermemory.evolver." + ".".join(parts[1:])
                elif len(parts) >= 2 and parts[1] not in ("memory", "vector", "layer", "wal", "backup", "integrity", "service"):
                    module_path = "supermemory.evolver.advanced." + ".".join(parts[1:])
                else:
                    module_path = "supermemory.evolver." + ".".join(parts[1:])
            elif parts[0] == "plugin":
                module_path = "supermemory.plugins." + ".".join(parts[1:])
            else:
                module_path = f"supermemory.{skill.skill_id}"

            __import__(module_path)
            logger.info(f"[SelfHealer] 动态检查 {skill.skill_id}: ✅ 可导入")

        except ImportError as e:
            issues.append(f"模块导入失败: {e}")
            logger.warning(f"[SelfHealer] 动态检查 {skill.skill_id}: ❌ {e}")

        return issues

    def _on_skill_event(self, event: str, skill: Skill):
        """
        监听 SkillRegistry 的技能变更事件
        当进化系统新增 evolver 时,自动注册检查器和修复器
        """
        if event != "registered":
            return

        logger.info(f"[SelfHealer] 新 evolver 注册事件: {skill.skill_id}")

        # 如果是 evolver.* 且还没有专属 fixer，自动注册通用验证 fixer
        if skill.skill_id.startswith("evolver.") and skill.skill_id not in self.FIXERS:
            # 动态注册通用验证检查器 + 修复器
            skill_id = skill.skill_id

            def make_check(sid):
                def check() -> List[str]:
                    return self._check_evolver_validity(sid)
                return check

            def make_fix(sid):
                def fix(issues: List[str]) -> bool:
                    return self._fix_evolver_validity(sid)
                return fix

            self.CHECKERS[skill_id] = make_check(skill_id)
            self.FIXERS[skill_id] = make_fix(skill_id)
            logger.info(f"[SelfHealer] 为新 evolver {skill_id} 自动注册检查器+修复器")

        # 如果技能不健康，触发修复
        if skill.health_score < 1.0:
            fixer = self.FIXERS.get(skill.skill_id)
            if fixer:
                logger.info(f"[SelfHealer] 自动修复退化技能: {skill.skill_id}")
                fixer([])

    def _check_evolver_validity(self, skill_id: str) -> List[str]:
        """检查 evolver 技能是否有效（属性齐全、可运行）"""
        issues = []
        try:
            # 动态导入 evolver 模块
            skill = self.registry.get_skill(skill_id)
            if not skill:
                return issues

            # 通过 EvolutionManager 验证
            from supermemory.evolver.evolution_manager import EvolutionManager
            em = EvolutionManager({"data_dir": str(self.data_dir)})
            evolver = em._evolvers.get(skill.name)
            if not evolver:
                issues.append(f"进化器 {skill.name} 未在 EvolutionManager 中注册")
                return issues

            # 检查必需属性
            for attr in ["name", "version", "description", "_enabled", "interval_hours"]:
                if not hasattr(evolver, attr):
                    issues.append(f"缺少属性: {attr}")
                elif getattr(evolver, attr) is None:
                    issues.append(f"属性为空: {attr}")

            # 测试运行
            result = evolver.evolve()
            if not result.success:
                issues.append(f"测试运行失败: {result.message}")
        except Exception as e:
            issues.append(f"验证异常: {e}")
        return issues

    def _fix_evolver_validity(self, skill_id: str) -> bool:
        """修复 evolver 技能：重新注册/验证"""
        try:
            from supermemory.evolver.evolution_manager import EvolutionManager
            em = EvolutionManager({"data_dir": str(self.data_dir)})
            evolver = em._evolvers.get(skill_id.replace("evolver.", ""))
            if evolver:
                logger.info(f"[SelfHealer] 重新验证进化器 {skill_id}")
                result = evolver.evolve()
                return result.success
            logger.warning(f"[SelfHealer] 无法找到 evolver: {skill_id}")
            return False
        except Exception as e:
            logger.error(f"[SelfHealer] 修复 {skill_id} 失败: {e}")
            return False

    # ============================================================================
    # Agent 数据层检查
    # ============================================================================

    def _check_all_agents(self) -> List[str]:
        """对所有 Agent 执行数据库完整性检查"""
        issues = []

        for agent in self.agents:
            agent_dir = self.data_dir / agent
            if not agent_dir.exists():
                continue

            db_path = agent_dir / "memories.db"
            vec_path = agent_dir / "vectors.json"

            # 数据库检查
            if db_path.exists():
                try:
                    conn = sqlite3.connect(str(db_path))
                    cur = conn.execute("PRAGMA integrity_check")
                    result = cur.fetchone()
                    conn.close()
                    if result[0] != "ok":
                        issues.append(f"{agent}.db: {result[0]}")
                        logger.warning(f"[SelfHealer] {agent}.db: {result[0]}")
                except Exception as e:
                    issues.append(f"{agent}.db: {e}")

            # 向量文件检查
            if not vec_path.exists() or vec_path.stat().st_size == 0:
                issues.append(f"{agent}.vectors: 文件不存在或为空")
                # 自动修复:创建空向量文件
                if not vec_path.exists():
                    vec_path.write_text("{}")

        return issues

    # ============================================================================
    # 各模块检查器
    # ============================================================================

    def _check_memory(self) -> List[str]:
        issues = []
        for agent in self.agents:
            db = self.data_dir / agent / "memories.db"
            if not db.exists():
                issues.append(f"{agent}.db: 不存在")
                continue
            try:
                conn = sqlite3.connect(str(db))
                cur = conn.execute("PRAGMA table_info(memories)")
                cols = {row[1] for row in cur.fetchall()}
                required = {"id", "content", "type", "importance", "tags",
                            "embedding_id", "metadata", "created_at", "updated_at",
                            "access_count", "last_accessed", "layer", "version"}
                missing = required - cols
                if missing:
                    issues.append(f"{agent}.db: 缺少列 {missing}")
                conn.close()
            except Exception as e:
                issues.append(f"{agent}.db: {e}")
        return issues

    def _check_vector(self) -> List[str]:
        issues = []
        for agent in self.agents:
            vp = self.data_dir / agent / "vectors.json"
            if not vp.exists():
                issues.append(f"{agent}.vectors: 不存在")
            elif vp.stat().st_size == 0:
                issues.append(f"{agent}.vectors: 空文件")
        return issues

    def _check_layer(self) -> List[str]:
        return []  # 三层管理本身无状态,不需要检查

    def _check_wal(self) -> List[str]:
        return []

    def _check_backup(self) -> List[str]:
        issues = []
        backup_dir = self.data_dir / "backups"
        if backup_dir.exists():
            backups = list(backup_dir.glob("*.tar.gz"))
            if len(backups) > 50:
                issues.append(f"backups: 超过50个备份文件 ({len(backups)})")
        return issues

    def _check_integrity(self) -> List[str]:
        return self._check_all_agents()

    def _check_service(self) -> List[str]:
        issues = []
        # 检查 API 是否响应
        try:
            import urllib.request
            with urllib.request.urlopen("http://localhost:8767/health", timeout=3) as resp:
                if resp.status != 200:
                    issues.append("API: 响应状态异常")
        except Exception:
            issues.append("API: 无法连接")
        return issues

    def _check_hybrid_search(self) -> List[str]:
        return []

    def _check_git_sync(self) -> List[str]:
        return []

    def _check_version_control(self) -> List[str]:
        return []

    def _check_context_manager(self) -> List[str]:
        return []

    def _check_self_healer(self) -> List[str]:
        return []

    def _check_openspace(self) -> List[str]:
        return []

    def _check_github_learner(self) -> List[str]:
        return []

    def _check_pattern_extractor(self) -> List[str]:
        return []

    def _check_strategy_optimizer(self) -> List[str]:
        return []

    def _check_framework(self) -> List[str]:
        return []

    def _check_error_healer(self) -> List[str]:
        return []

    def _check_incremental_learner(self) -> List[str]:
        return []

    # ============================================================================
    # 各模块修复器
    # ============================================================================

    def _fix_memory(self, issues: List[str]) -> bool:
        try:
            for agent in self.agents:
                db = self.data_dir / agent / "memories.db"
                if not db.exists():
                    continue
                conn = sqlite3.connect(str(db))
                for col, col_type in [
                    ("embedding_id", "TEXT"),
                    ("access_count", "INTEGER DEFAULT 0"),
                    ("last_accessed", "TEXT DEFAULT ''"),
                    ("layer", "TEXT DEFAULT 'hot'"),
                    ("version", "INTEGER DEFAULT 1"),
                ]:
                    try:
                        conn.execute(f"ALTER TABLE memories ADD COLUMN {col} {col_type}")
                        logger.info(f"[SelfHealer] {agent}.db: 添加列 {col}")
                    except sqlite3.OperationalError:
                        pass
                for idx, cols in [
                    ("idx_layer", "layer"),
                    ("idx_last_accessed", "last_accessed"),
                ]:
                    try:
                        conn.execute(f"CREATE INDEX IF NOT EXISTS {idx} ON memories({cols})")
                    except:
                        pass
                conn.commit()
                conn.close()
            return True
        except Exception as e:
            logger.error(f"[SelfHealer] _fix_memory 失败: {e}")
            return False

    def _fix_vector(self, issues: List[str]) -> bool:
        for agent in self.agents:
            vp = self.data_dir / agent / "vectors.json"
            if not vp.exists() or vp.stat().st_size == 0:
                vp.write_text("{}")
                logger.info(f"[SelfHealer] {agent}.vectors: 已重建")
        return True

    def _fix_layer(self, issues: List[str]) -> bool:
        return True

    def _fix_wal(self, issues: List[str]) -> bool:
        return True

    def _fix_backup(self, issues: List[str]) -> bool:
        try:
            backup_dir = self.data_dir / "backups"
            if backup_dir.exists():
                backups = sorted(backup_dir.glob("*.tar.gz"), key=lambda p: p.stat().st_mtime)
                for old in backups[:-20]:  # 保留最近20个
                    old.unlink()
                    logger.info(f"[SelfHealer] 删除旧备份: {old.name}")
            return True
        except Exception as e:
            logger.error(f"[SelfHealer] _fix_backup 失败: {e}")
            return False

    def _fix_integrity(self, issues: List[str]) -> bool:
        return self._fix_memory([]) and self._fix_vector([])

    def _fix_service(self, issues: List[str]) -> bool:
        # API 无响应时重启服务
        try:
            import urllib.request
            urllib.request.urlopen("http://localhost:8767/health", timeout=2)
            return True  # 正常
        except:
            logger.warning("[SelfHealer] API 无响应,尝试重启...")
            os.system("launchctl bootout gui/$(id -u)/com.marsai.supermemory-v4 2>/dev/null; "
                      "launchctl load ~/Library/LaunchAgents/com.marsai.supermemory-v4.plist 2>/dev/null")
            return True

    def _fix_hybrid_search(self, issues: List[str]) -> bool:
        """修复混合搜索:重新注册索引"""
        try:
            from supermemory.core.advanced.hybrid_search import HybridSearch
            for agent in self.agents:
                try:
                    hs = HybridSearch(agent_id=agent)
                    hs.rebuild_index()
                    logger.info(f"[SelfHealer] {agent}.hybrid_search: 索引重建完成")
                except Exception as e:
                    logger.warning(f"[SelfHealer] {agent}.hybrid_search: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] hybrid_search 模块导入失败: {e}")
            return False

    def _fix_git_sync(self, issues: List[str]) -> bool:
        """修复Git同步:验证git配置并重试同步"""
        try:
            from supermemory.core.advanced.git_sync import GitSync
            for agent in self.agents:
                try:
                    gs = GitSync(agent_id=agent)
                    if gs.validate_config():
                        gs.sync_all()
                        logger.info(f"[SelfHealer] {agent}.git_sync: 同步完成")
                    else:
                        logger.warning(f"[SelfHealer] {agent}.git_sync: 配置无效")
                except Exception as e:
                    logger.warning(f"[SelfHealer] {agent}.git_sync: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] git_sync 模块导入失败: {e}")
            return False

    def _fix_version_control(self, issues: List[str]) -> bool:
        """修复版本控制:验证版本历史完整性"""
        try:
            for agent in self.agents:
                vc_path = self.data_dir / agent / "versions"
                if not vc_path.exists():
                    vc_path.mkdir(parents=True, exist_ok=True)
                    logger.info(f"[SelfHealer] {agent}.version_control: 重建版本目录")
            return True
        except Exception as e:
            logger.error(f"[SelfHealer] version_control 修复失败: {e}")
            return False

    def _fix_context_manager(self, issues: List[str]) -> bool:
        """修复上下文管理器:清空损坏的缓存"""
        try:
            for agent in self.agents:
                ctx_path = self.data_dir / agent / "context_cache.json"
                if ctx_path.exists():
                    try:
                        import json
                        with open(ctx_path) as f:
                            json.load(f)  # 验证JSON完整性
                    except (json.JSONDecodeError, Exception):
                        # 文件损坏,清空
                        ctx_path.unlink()
                        logger.info(f"[SelfHealer] {agent}.context_manager: 已清空损坏缓存")
            return True
        except Exception as e:
            logger.error(f"[SelfHealer] context_manager 修复失败: {e}")
            return False

    def _fix_self_healer(self, issues: List[str]) -> bool:
        """修复自愈系统:重新初始化自身"""
        try:
            # 重新加载配置
            self.CHECKERS.clear()
            self.FIXERS.clear()
            # 重新注册所有检查器和修复器
            # 这会重新扫描所有模块
            self._register_extended_evolver_skills()
            logger.info("[SelfHealer] 自我修复:重新初始化完成")
            return True
        except Exception as e:
            logger.error(f"[SelfHealer] 自我修复失败: {e}")
            return False

    def _fix_openspace(self, issues: List[str]) -> bool:
        """修复OpenSpace进化器:验证技能存储并重新进化"""
        try:
            from supermemory.evolver.advanced.openspace_evolution import OpenSpaceEvolver
            for agent in self.agents:
                try:
                    oe = OpenSpaceEvolver(data_dir=str(self.data_dir / agent))
                    # 验证技能存储
                    if hasattr(oe, 'skill_store'):
                        oe.skill_store.validate()
                    # 重新进化失败技能
                    if hasattr(oe, 'evolve_all'):
                        oe.evolve_all()
                    logger.info(f"[SelfHealer] {agent}.openspace: 重新进化完成")
                except Exception as e:
                    logger.warning(f"[SelfHealer] {agent}.openspace: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] openspace 模块导入失败: {e}")
            return False

    def _fix_github_learner(self, issues: List[str]) -> bool:
        """修复GitHub学习器:重新拉取最新内容"""
        try:
            from supermemory.evolver.advanced.github_learner import GitHubLearner
            try:
                learner = GitHubLearner()
                if hasattr(learner, 'fetch_latest'):
                    learner.fetch_latest()
                logger.info("[SelfHealer] github_learner: 重新拉取完成")
            except Exception as e:
                logger.warning(f"[SelfHealer] github_learner.fetch: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] github_learner 模块导入失败: {e}")
            return False

    def _fix_pattern_extractor(self, issues: List[str]) -> bool:
        """修复模式提取器:重新运行提取"""
        try:
            from supermemory.evolver.advanced.pattern_extractor import PatternExtractor
            try:
                pe = PatternExtractor(data_dir=str(self.data_dir))
                if hasattr(pe, 'extract_all'):
                    pe.extract_all()
                logger.info("[SelfHealer] pattern_extractor: 重新提取完成")
            except Exception as e:
                logger.warning(f"[SelfHealer] pattern_extractor: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] pattern_extractor 模块导入失败: {e}")
            return False

    def _fix_strategy_optimizer(self, issues: List[str]) -> bool:
        """修复策略优化器:重新运行优化"""
        try:
            from supermemory.evolver.advanced.strategy_optimizer import StrategyOptimizer
            try:
                so = StrategyOptimizer(data_dir=str(self.data_dir))
                if hasattr(so, 'optimize_all'):
                    so.optimize_all()
                logger.info("[SelfHealer] strategy_optimizer: 重新优化完成")
            except Exception as e:
                logger.warning(f"[SelfHealer] strategy_optimizer: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] strategy_optimizer 模块导入失败: {e}")
            return False

    def _fix_framework(self, issues: List[str]) -> bool:
        """修复进化框架:重新注册所有进化器"""
        try:
            # 重新扫描并注册所有 evolver
            self._register_extended_evolver_skills()
            # 验证所有 evolver 可导入
            for skill_id in list(self.CHECKERS.keys()):
                if skill_id.startswith('evolver.'):
                    try:
                        parts = skill_id.split('.')
                        if len(parts) >= 2 and parts[1] not in ('memory', 'vector', 'layer', 'wal', 'backup', 'integrity', 'service'):
                            __import__(f'supermemory.evolver.advanced.{parts[1]}')
                    except ImportError:
                        logger.warning(f"[SelfHealer] {skill_id}: 无法导入")
            logger.info("[SelfHealer] framework: 重新注册进化器完成")
            return True
        except Exception as e:
            logger.error(f"[SelfHealer] framework 修复失败: {e}")
            return False

    def _fix_error_healer(self, issues: List[str]) -> bool:
        """修复错误修复器:重新分析错误历史"""
        try:
            from supermemory.evolver.advanced.error_healer import ErrorHealer
            try:
                eh = ErrorHealer(data_dir=str(self.data_dir))
                if hasattr(eh, 'analyze_errors'):
                    eh.analyze_errors()
                if hasattr(eh, 'fix_all'):
                    eh.fix_all()
                logger.info("[SelfHealer] error_healer: 重新分析完成")
            except Exception as e:
                logger.warning(f"[SelfHealer] error_healer: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] error_healer 模块导入失败: {e}")
            return False

    def _fix_incremental_learner(self, issues: List[str]) -> bool:
        """修复增量学习器:重新运行增量学习"""
        try:
            from supermemory.evolver.advanced.incremental_learner import IncrementalLearner
            for agent in self.agents:
                try:
                    il = IncrementalLearner(data_dir=str(self.data_dir / agent))
                    if hasattr(il, 'learn'):
                        il.learn()
                    logger.info(f"[SelfHealer] {agent}.incremental_learner: 学习完成")
                except Exception as e:
                    logger.warning(f"[SelfHealer] {agent}.incremental_learner: {e}")
            return True
        except ImportError as e:
            logger.error(f"[SelfHealer] incremental_learner 模块导入失败: {e}")
            return False

    # ============================================================================
    # 扩展机制
    # ============================================================================

    def _register_extended_evolver_skills(self):
        """
        自动发现并注册新进化的技能
        扫描所有 evolver/advanced/*.py,为每个模块创建 Skill 并注册
        """
        evolver_dir = Path(__file__).parent / "advanced"
        if not evolver_dir.exists():
            return

        # 获取所有已注册的 evolver.* skill IDs
        registered_ids = {s.skill_id for s in self.registry.list_skills(module="evolver")}
        # 硬编码映射:文件名 -> 实际类名 (避免错误匹配导致重复注册)
        class_name_map = {
            "incremental_learner": "IncrementalLearner",
            "strategy_optimizer": "StrategyOptimizer",
            "error_healer": "ErrorHealer",
            "pattern_extractor": "PatternExtractor",
            "openspace_evolution": "OpenSpaceEvolver",
            "github_learner": "GitHubLearner",
            "framework": "EvolutionFramework",  # 正确类名,避免被误注册为 evolver.framework
            "base": "Evolver",                     # 避免被误注册为 evolver.base (Evolver是base class)
        }

        for py_file in evolver_dir.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            skill_id = f"evolver.{py_file.stem}"

            # Skip if already registered
            if skill_id in registered_ids:
                continue

            # Skip known hardcoded classes (文件名不匹配类名的情况)
            class_canonical = class_name_map.get(py_file.stem, "")

            # Check if the canonical class exists in the module
            try:
                import importlib
                mod = importlib.import_module(f"supermemory.evolver.advanced.{py_file.stem}")
                # For known classes, verify class name matches
                if class_canonical and hasattr(mod, class_canonical):
                    # This is a known class handled by hardcoded map, skip
                    continue
                # For unknown classes, auto-register
            except ImportError:
                pass

            try:
                # 尝试导入验证
                __import__(f"supermemory.evolver.advanced.{py_file.stem}")

                skill = Skill(
                    skill_id=skill_id,
                    name=py_file.stem.replace("_", " ").title(),
                    module="evolver.advanced",
                    owner="system",
                    evolve_type="FIX",
                    description=f"高级进化模块: {py_file.stem}",
                )
                self.registry.register_skill(skill)
                self.CHECKERS[skill_id] = self._dynamic_check
                self.FIXERS[skill_id] = lambda issues: True
                logger.info(f"[SelfHealer] 自动注册新进化技能: {skill_id}")
            except ImportError as e:
                logger.warning(f"[SelfHealer] 无法导入 {skill_id}: {e}")

    # ============================================================================
    # 统计和状态
    # ============================================================================

    def get_status(self) -> Dict[str, Any]:
        """获取自愈系统状态"""
        registry_stats = self.registry.get_stats()
        return {
            "version": self.version,
            "enabled": self._enabled,
            "checkers_count": len(self.CHECKERS),
            "fixers_count": len(self.FIXERS),
            "tracked_issues": len(self._issues),
            "unfixed_issues": len([i for i in self._issues.values() if not i.fixed]),
            "registry": registry_stats,
            "interval_hours": self.interval_hours,
        }

    def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        return {
            "status": "healthy" if self._enabled else "disabled",
            "module": "SelfHealer",
            "version": self.version,
            "checks": {
                "registry_loaded": len(self.registry.list_skills()) > 0,
                "checkers_registered": len(self.CHECKERS) > 0,
                "fixers_registered": len(self.FIXERS) > 0,
            }
        }
