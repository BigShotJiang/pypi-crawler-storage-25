"""
StrategyOptimizer - 策略优化器
分析历史执行结果，优化决策策略
"""

import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict
import statistics

from .base import Evolver, EvolutionResult

logger = logging.getLogger(__name__)


class StrategyOptimizer(Evolver):
    """
    策略优化器
    分析成功/失败案例，优化未来决策
    """

    name = "strategy_optimizer"
    version = "1.0.0"
    description = "优化决策策略"
    interval_hours = 24  # 每天运行一次

    def __init__(self, config: dict = None):
        super().__init__(config)
        self.memory_dir = Path(self.config.get("memory_dir", self.config.get("data_dir", "memory")))
        self.decisions: List[Dict] = []
        self.strategies: Dict[str, Dict] = {}
        self.min_samples = self.config.get("min_samples", 2)
        self._load_data()

    def _load_data(self):
        """加载数据"""
        decisions_file = self.memory_dir / "decisions.json"
        if decisions_file.exists():
            try:
                with open(decisions_file, "r") as f:
                    self.decisions = json.load(f)
            except Exception as e:
                logger.warning(f"加载决策数据失败: {e}")

        strategies_file = self.memory_dir / "strategies.json"
        if strategies_file.exists():
            try:
                with open(strategies_file, "r") as f:
                    self.strategies = json.load(f)
            except Exception as e:
                logger.warning(f"加载策略数据失败: {e}")

        # 从 SuperMemory 数据库补充决策样本
        self._load_decisions_from_memories()

    def _load_decisions_from_memories(self):
        """从 SuperMemory 数据库和 WAL 中提取决策模式"""
        import sqlite3
        import re
        data_root = Path("~/.openclaw/workspace-shared/super-memory-data").expanduser()
        wal_path = Path("~/.openclaw/workspace-mars/memory/WAL.md").expanduser()

        # 扩展决策标记（中文+英文，覆盖更多场景）
        decision_markers = [
            (r"(?:决定|确定|采用|选择|使用)\s*(?:了)?(?:使用|选择|采用)\s*[:：]?\s*([\S]{3,60})", "cn_decision"),
            (r"(?:go\s+with|use|using|pick|choose|prefer)\s+(?:the\s+)?(\S.{0,60})", "en_decision"),
            (r"(?:赚钱|变现|方向|项目|方案)\s*[是为]\s*([\S]{2,40})", "direction_decision"),
            (r"(?:执行|启动|开始)\s*:?\s*([\S]{2,40})", "action_decision"),
            (r"(?:选|用)\s+([^\s，,。]{2,30})(?=方案|方式|方法|策略)", "method_decision"),
            (r"方向[是为]?\s*([\S]{2,30})", "direction"),
        ]

        # 从 WAL 提取决策
        if wal_path.exists():
            try:
                wal_content = wal_path.read_text()
                lines = wal_content.split("\n")
                for line in lines:
                    for marker, mtype in decision_markers:
                        matches = re.finditer(marker, line, re.IGNORECASE)
                        for match in matches:
                            decision_text = match.group(0)[:100]
                            if len(decision_text) < 4:
                                continue
                            # 避免重复
                            if not any(d.get("decision", "") == decision_text for d in self.decisions):
                                self.decisions.append({
                                    "context": line.strip()[:80],
                                    "decision": decision_text,
                                    "success": True,
                                    "timestamp": datetime.now().isoformat(),
                                    "source": "wal",
                                    "type": mtype,
                                })
            except Exception as e:
                logger.warning(f"从WAL提取决策失败: {e}")

        # 从数据库提取
        if not data_root.exists():
            return

        for agent_dir in data_root.iterdir():
            if not agent_dir.is_dir() or agent_dir.name in ("metrics", "health", "plugins"):
                continue
            db_path = agent_dir / "memories.db"
            if not db_path.exists():
                continue
            try:
                conn = sqlite3.connect(str(db_path))
                cur = conn.execute(
                    "SELECT content FROM memories ORDER BY created_at DESC LIMIT 300"
                )
                for row in cur.fetchall():
                    content = row[0] or ""
                    for marker, mtype in decision_markers:
                        matches = re.finditer(marker, content, re.IGNORECASE)
                        for match in matches:
                            decision_text = match.group(0)[:100]
                            if len(decision_text) < 4:
                                continue
                            if not any(d.get("decision", "") == decision_text for d in self.decisions):
                                self.decisions.append({
                                    "context": content[:100],
                                    "decision": decision_text,
                                    "success": True,
                                    "timestamp": datetime.now().isoformat(),
                                    "source": agent_dir.name,
                                    "type": mtype,
                                })
                conn.close()
            except Exception as e:
                logger.warning(f"从 {db_path} 提取决策失败: {e}")

    def _save_data(self):
        """保存数据"""
        self.memory_dir.mkdir(parents=True, exist_ok=True)

        decisions_file = self.memory_dir / "decisions.json"
        try:
            with open(decisions_file, "w") as f:
                json.dump(self.decisions, f, indent=2)
        except Exception as e:
            logger.error(f"保存决策数据失败: {e}")

        strategies_file = self.memory_dir / "strategies.json"
        try:
            with open(strategies_file, "w") as f:
                json.dump(self.strategies, f, indent=2)
        except Exception as e:
            logger.error(f"保存策略数据失败: {e}")

    def record_decision(
        self,
        context: str,
        decision: str,
        outcome: str,
        success: bool,
    ) -> None:
        """记录一个决策"""
        self.decisions.append({
            "context": context,
            "decision": decision,
            "outcome": outcome,
            "success": success,
            "timestamp": datetime.now().isoformat(),
        })
        self._save_data()

    def _analyze_success_factors(self) -> Dict[str, float]:
        """分析成功因素"""
        if len(self.decisions) < self.min_samples:
            return {}

        successful = [d for d in self.decisions if d["success"]]
        if not successful:
            return {}

        # 统计成功决策的特征
        factors = defaultdict(lambda: {"success": 0, "total": 0})

        for d in self.decisions:
            key = d["context"][:30] if d["context"] else "unknown"
            factors[key]["total"] += 1
            if d["success"]:
                factors[key]["success"] += 1

        # 计算成功率
        success_rates = {}
        for key, data in factors.items():
            if data["total"] >= 2:
                success_rates[key] = data["success"] / data["total"]

        return success_rates

    def _optimize_strategies(self) -> Dict[str, Any]:
        """优化策略"""
        success_rates = self._analyze_success_factors()

        if not success_rates:
            return {"message": "样本不足，无法优化"}

        # 更新策略评分
        for context, rate in success_rates.items():
            if context not in self.strategies:
                self.strategies[context] = {"score": 0, "count": 0}

            self.strategies[context]["score"] = (
                self.strategies[context]["score"] * 0.7 + rate * 0.3
            )
            self.strategies[context]["count"] += 1
            self.strategies[context]["last_updated"] = datetime.now().isoformat()

        return {
            "updated_strategies": len(success_rates),
            "top_strategy": max(success_rates.items(), key=lambda x: x[1])[0]
            if success_rates else None,
        }

    def _generate_recommendations(self) -> List[str]:
        """生成建议"""
        recommendations = []

        # 基于成功率生成建议
        sorted_strategies = sorted(
            self.strategies.items(), key=lambda x: x[1].get("score", 0), reverse=True
        )

        for context, data in sorted_strategies[:3]:
            if data.get("score", 0) >= 0.7:
                recommendations.append(
                    f"高置信度策略: {context[:40]} (评分: {data['score']:.2f})"
                )

        return recommendations

    def _evolve(self) -> EvolutionResult:
        """执行策略优化"""
        logger.info("开始策略优化...")

        if len(self.decisions) < self.min_samples:
            return EvolutionResult(
                success=True,
                evolver_name=self.name,
                changes={"sample_count": len(self.decisions)},
                message=f"样本不足 ({len(self.decisions)}/{self.min_samples})，跳过优化",
            )

        optimization = self._optimize_strategies()
        recommendations = self._generate_recommendations()

        self._save_data()

        changes = {
            "total_decisions": len(self.decisions),
            "total_strategies": len(self.strategies),
            **optimization,
            "recommendations": recommendations,
        }

        return EvolutionResult(
            success=True,
            evolver_name=self.name,
            changes=changes,
            message=f"优化了 {optimization.get('updated_strategies', 0)} 个策略",
        )

    def get_best_strategy(self, context: str) -> Optional[Dict]:
        """获取最佳策略"""
        context_key = context[:30] if context else "unknown"
        return self.strategies.get(context_key)


    def health_check(self) -> dict:
        """健康检查 - 验证模块功能正常"""
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "version": getattr(self, 'VERSION', '1.0.0'),
            "checks": {
                "initialized": hasattr(self, '_initialized') and self._initialized,
                "config_loaded": hasattr(self, 'config') and self.config is not None,
            }
        }

    def self_test(self) -> bool:
        """自测试 - 验证模块可正常运行"""
        try:
            result = self.health_check()
            return result.get("status") == "healthy"
        except Exception:
            return False

