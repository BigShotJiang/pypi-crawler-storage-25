"""
E05 - 增量学习Evolver
新知识增量加入，不遗忘旧知识
"""

import logging
from pathlib import Path
from typing import Dict, Any, List, Set
from datetime import datetime
from .base import Evolver, EvolutionResult

logger = logging.getLogger(__name__)


class IncrementalLearner(Evolver):
    """
    增量学习进化器
    
    核心能力：
    1. 检测新知识并增量加入记忆库
    2. 基于记忆重要性决定保留策略
    3. 防止新知识覆盖旧知识
    4. 自动识别知识边界（哪些是新的，哪些是已有的）
    """
    
    name = "incremental_learner"
    version = "1.0.0"
    description = "增量学习 - 新知识增量加入，不遗忘旧知识"
    interval_hours = 6  # 每6小时检查一次
    
    def __init__(self, config: dict = None):
        super().__init__(config)
        self._learned_ids: Set[str] = set()
        cfg = config or {}
        self._max_old_protection = cfg.get("max_old_protection", 100)
        self._new_threshold = cfg.get("new_threshold", 0.7)
        
    def _evolve(self) -> EvolutionResult:
        """执行增量学习"""
        try:
            changes = {
                "new_memories_added": 0,
                "old_memories_protected": 0,
                "knowledge_gaps_found": [],
                "merged_knowledge": []
            }
            
            # 1. 检测新知识来源
            new_knowledge = self._detect_new_knowledge()
            
            # 2. 增量加入记忆
            for item in new_knowledge:
                if self._is_new_knowledge(item):
                    self._add_memory_incrementally(item)
                    changes["new_memories_added"] += 1
                    
            # 3. 保护旧知识不被遗忘
            protected = self._protect_old_knowledge()
            changes["old_memories_protected"] = protected
            
            # 4. 识别知识空白
            gaps = self._identify_knowledge_gaps()
            changes["knowledge_gaps_found"] = gaps
            
            # 5. 合并相关知识
            merged = self._merge_related_knowledge()
            changes["merged_knowledge"] = merged
            
            message = f"增量学习完成：新知识{changes['new_memories_added']}条，旧知识保护{changes['old_memories_protected']}条"
            
            return EvolutionResult(
                success=True,
                evolver_name=self.name,
                changes=changes,
                message=message
            )
            
        except Exception as e:
            logger.exception("增量学习执行失败")
            return EvolutionResult(
                success=False,
                evolver_name=self.name,
                error=str(e),
                message=f"增量学习失败: {e}"
            )
    
    def _detect_new_knowledge(self) -> List[Dict]:
        """从 SuperMemory WAL 和最新记忆中检测新知识"""
        import sqlite3
        new_items = []
        data_root = Path("~/.openclaw/workspace-shared/super-memory-data").expanduser()
        wal_path = Path("~/.openclaw/workspace-mars/memory/WAL.md").expanduser()

        # 从 WAL 中检测最新条目
        if wal_path.exists():
            try:
                content = wal_path.read_text()
                lines = content.strip().split("\n")[-50:]  # 最近50条
                for line in lines:
                    if line.strip():
                        new_items.append({
                            "source": "wal",
                            "content": line.strip()[:200],
                            "id": f"wal_{hash(line.strip()) & 0xFFFFFFFF}"
                        })
            except Exception as e:
                logger.warning(f"读取WAL失败: {e}")

        # 从各Agent最新记忆中检测
        if data_root.exists():
            for agent_dir in data_root.iterdir():
                if not agent_dir.is_dir():
                    continue
                db_path = agent_dir / "memories.db"
                if db_path.exists():
                    try:
                        conn = sqlite3.connect(str(db_path))
                        cur = conn.execute(
                            "SELECT id, content FROM memories ORDER BY created_at DESC LIMIT 10"
                        )
                        for row in cur.fetchall():
                            new_items.append({
                                "source": agent_dir.name,
                                "content": row[1][:200] if row[1] else "",
                                "id": row[0]
                            })
                        conn.close()
                    except Exception as e:
                        logger.warning(f"检测 {db_path} 失败: {e}")

        return new_items
    
    def _is_new_knowledge(self, item: Dict) -> bool:
        """判断知识是否是新知识"""
        if "id" not in item:
            return True
        return item["id"] not in self._learned_ids
    
    def _add_memory_incrementally(self, item: Dict) -> str:
        """增量添加记忆，返回记忆ID"""
        # 1. 生成记忆ID
        memory_id = item.get("id", f"inc_{datetime.now().timestamp()}")
        
        # 2. 检查是否与旧知识冲突
        if self._has_conflict(item):
            # 合并而非覆盖
            self._merge_knowledge(item)
        else:
            # 直接添加
            self._store_memory(item)
            
        # 3. 记录已学习
        self._learned_ids.add(memory_id)
        
        return memory_id
    
    def _has_conflict(self, item: Dict) -> bool:
        """检查是否与现有知识冲突"""
        # TODO: 实现冲突检测
        return False
    
    def _merge_knowledge(self, item: Dict):
        """合并知识而非覆盖"""
        # TODO: 实现知识合并逻辑
        pass
    
    def _store_memory(self, item: Dict):
        """存储记忆"""
        # TODO: 调用 SuperMemory API 存储
        pass
    
    def _protect_old_knowledge(self) -> int:
        """保护旧知识不被遗忘"""
        protected_count = 0
        
        # TODO: 实现旧知识保护
        # - P0/P1 知识永久保护
        # - 被频繁访问的知识延长TTL
        # - 重要决策永不删除
        
        return protected_count
    
    def _identify_knowledge_gaps(self) -> List[str]:
        """识别知识空白"""
        gaps = []
        
        # TODO: 分析知识库中的空白
        # - 缺少某个领域的知识
        # - 某个时间段的记录缺失
        # - 某些实体的信息不完整
        
        return gaps
    
    def _merge_related_knowledge(self) -> List[Dict]:
        """合并相关知识"""
        merged = []
        
        # TODO: 查找相关知识并合并
        # - 同一实体的多条记录
        # - 相关的决策和结果
        # - 互补的经验总结
        
        return merged
    
    def add_knowledge_batch(self, items: List[Dict]) -> int:
        """批量添加知识，返回添加数量"""
        added = 0
        for item in items:
            if self._is_new_knowledge(item):
                self._add_memory_incrementally(item)
                added += 1
        return added


    def health_check(self) -> dict:
        """健康检查 - 验证模块功能正常"""
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "version": getattr(self, 'VERSION', '1.0.0'),
            "checks": {
                "initialized": hasattr(self, '_initialized') and self._initialized,
                "config_loaded": hasattr(self, 'config') and self.config is not None,
            }
        }

    def self_test(self) -> bool:
        """自测试 - 验证模块可正常运行"""
        try:
            result = self.health_check()
            return result.get("status") == "healthy"
        except Exception:
            return False

