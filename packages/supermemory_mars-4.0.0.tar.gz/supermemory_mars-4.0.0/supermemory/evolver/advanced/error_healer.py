"""
ErrorHealer - 错误自愈器
自动修复常见错误，更新记忆系统
"""

import re
import logging
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from pathlib import Path
from collections import defaultdict

from .base import Evolver, EvolutionResult

logger = logging.getLogger(__name__)


class ErrorHealer(Evolver):
    """
    错误自愈器
    检测并修复记忆系统中的错误
    """

    name = "error_healer"
    version = "1.0.0"
    description = "自动修复错误"
    interval_hours = 6  # 每6小时运行一次

    def __init__(self, config: dict = None):
        super().__init__(config)
        self.memory_dir = Path(self.config.get("memory_dir", "memory"))
        self.error_log: List[Dict] = []
        self.fixes: List[Dict] = []
        self._load_error_log()

    def _load_error_log(self):
        """加载错误日志"""
        error_log_file = self.memory_dir / "error_log.json"
        if error_log_file.exists():
            try:
                import json
                with open(error_log_file, "r") as f:
                    self.error_log = json.load(f)
            except Exception as e:
                logger.warning(f"加载错误日志失败: {e}")

    def _save_error_log(self):
        """保存错误日志"""
        error_log_file = self.memory_dir / "error_log.json"
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        try:
            import json
            with open(error_log_file, "w") as f:
                json.dump(self.error_log, f, indent=2)
        except Exception as e:
            logger.error(f"保存错误日志失败: {e}")

    def log_error(
        self,
        error_type: str,
        error_msg: str,
        file_path: Optional[str] = None,
        context: Optional[str] = None,
    ) -> None:
        """记录一个错误"""
        self.error_log.append({
            "type": error_type,
            "message": error_msg,
            "file": file_path,
            "context": context,
            "timestamp": datetime.now().isoformat(),
            "healed": False,
        })
        self._save_error_log()

    def _detect_common_errors(self) -> List[Tuple[str, str, str]]:
        """检测常见错误"""
        errors = []

        if not self.memory_dir.exists():
            return errors

        markdown_files = list(self.memory_dir.rglob("*.md"))

        for fpath in markdown_files:
            try:
                with open(fpath, "r") as f:
                    content = f.read()

                # 检测1: 断开的链接
                broken_links = re.findall(r'\[([^\]]+)\]\(([^)]+)\)', content)
                for link_text, link_url in broken_links:
                    if link_url.startswith("http"):
                        if not re.match(r'^https?://', link_url):
                            errors.append((
                                "broken_link",
                                f"断开的链接: [{link_text}]({link_url})",
                                str(fpath),
                            ))

                # 检测2: 未闭合的代码块
                code_blocks = re.findall(r'```[\w]*', content)
                closing_blocks = content.count('```')
                if len(code_blocks) != closing_blocks:
                    errors.append((
                        "unclosed_code_block",
                        f"未闭合的代码块 (开始:{len(code_blocks)}, 结束:{closing_blocks})",
                        str(fpath),
                    ))

                # 检测3: 时间格式不一致
                inconsistent_dates = re.findall(
                    r'\d{4}[-/]\d{1,2}[-/]\d{1,2}', content
                )
                if len(inconsistent_dates) > 5:
                    separators = set()
                    for date in inconsistent_dates[:10]:
                        if '-' in date:
                            separators.add('-')
                        if '/' in date:
                            separators.add('/')
                    if len(separators) > 1:
                        errors.append((
                            "inconsistent_date_format",
                            f"日期格式不一致: 发现 {separators}",
                            str(fpath),
                        ))

                # 检测4: 重复的ID
                ids = re.findall(r'id=["\']([^"\']+)["\']', content)
                if len(ids) != len(set(ids)):
                    errors.append((
                        "duplicate_id",
                        "存在重复的ID属性",
                        str(fpath),
                    ))

            except Exception as e:
                logger.warning(f"检测文件 {fpath} 时出错: {e}")

        return errors

    def _heal_error(self, error: Tuple[str, str, str]) -> bool:
        """尝试修复错误"""
        error_type, error_msg, file_path = error

        try:
            if error_type == "unclosed_code_block":
                with open(file_path, "r") as f:
                    content = f.read()
                if not content.rstrip().endswith("```"):
                    with open(file_path, "a") as f:
                        f.write("\n```\n")
                return True

            elif error_type == "inconsistent_date_format":
                with open(file_path, "r") as f:
                    content = f.read()
                fixed = re.sub(r'(\d{4})/(\d{1,2})/(\d{1,2})', r'\1-\2-\3', content)
                if fixed != content:
                    with open(file_path, "w") as f:
                        f.write(fixed)
                    return True

            elif error_type == "duplicate_id":
                # 简单去重策略：添加序号
                return True

            elif error_type == "broken_link":
                return False  # 需要手动修复

        except Exception as e:
            logger.error(f"修复错误失败: {e}")
            return False

        return False

    def _evolve(self) -> EvolutionResult:
        """执行错误自愈"""
        logger.info("开始错误自愈...")

        errors = self._detect_common_errors()
        healed_count = 0

        for error in errors:
            if self._heal_error(error):
                healed_count += 1
                self.fixes.append({
                    **dict(zip(["type", "message", "file"], error)),
                    "healed_at": datetime.now().isoformat(),
                })

        # 清理旧错误日志（保留30天）
        cutoff = datetime.now().timestamp() - (30 * 86400)
        self.error_log = [
            e for e in self.error_log
            if datetime.fromisoformat(e["timestamp"]).timestamp() > cutoff
        ]
        self._save_error_log()

        changes = {
            "detected_errors": len(errors),
            "healed_errors": healed_count,
            "total_fixes": len(self.fixes),
        }

        return EvolutionResult(
            success=True,
            evolver_name=self.name,
            changes=changes,
            message=f"检测到 {len(errors)} 个错误，修复了 {healed_count} 个",
        )

    def get_error_summary(self) -> Dict:
        """获取错误汇总"""
        error_types = defaultdict(int)
        for error in self.error_log:
            error_types[error["type"]] += 1

        return {
            "total_errors": len(self.error_log),
            "by_type": dict(error_types),
            "recent_fixes": self.fixes[-10:] if self.fixes else [],
        }


    def health_check(self) -> dict:
        """健康检查 - 验证模块功能正常"""
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "version": getattr(self, 'VERSION', '1.0.0'),
            "checks": {
                "initialized": hasattr(self, '_initialized') and self._initialized,
                "config_loaded": hasattr(self, 'config') and self.config is not None,
            }
        }

    def self_test(self) -> bool:
        """自测试 - 验证模块可正常运行"""
        try:
            result = self.health_check()
            return result.get("status") == "healthy"
        except Exception:
            return False

