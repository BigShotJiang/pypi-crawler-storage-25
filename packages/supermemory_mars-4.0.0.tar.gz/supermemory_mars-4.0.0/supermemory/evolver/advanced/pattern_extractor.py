"""
PatternExtractor - 模式提取器
从用户交互和记忆中提取可复用的模式
"""

import re
import logging
from typing import Dict, Any, List, Set, Optional
from datetime import datetime
from collections import defaultdict
from pathlib import Path

from .base import Evolver, EvolutionResult

logger = logging.getLogger(__name__)


class PatternExtractor(Evolver):
    """
    模式提取器
    分析交互历史，提取行为模式和最佳实践
    """

    name = "pattern_extractor"
    version = "1.0.0"
    description = "从交互中提取可复用模式"
    interval_hours = 12  # 每12小时运行一次

    def __init__(self, config: dict = None):
        super().__init__(config)
        # 支持 memory_dir 或 data_dir（SuperMemory 标准）
        self.memory_dir = Path(self.config.get("memory_dir", self.config.get("data_dir", "memory")))
        self.patterns: Dict[str, List[Dict]] = defaultdict(list)
        self.min_confidence = self.config.get("min_confidence", 0.7)
        self._load_patterns()

    def _load_patterns(self):
        """加载已有模式"""
        pattern_file = self.memory_dir / "patterns" / "extracted.json"
        if pattern_file.exists():
            try:
                import json
                with open(pattern_file, "r") as f:
                    data = json.load(f)
                    self.patterns = defaultdict(list, data)
            except Exception as e:
                logger.warning(f"加载模式失败: {e}")

    def _save_patterns(self):
        """保存模式"""
        pattern_file = self.memory_dir / "patterns"
        pattern_file.mkdir(parents=True, exist_ok=True)
        try:
            import json
            with open(pattern_file / "extracted.json", "w") as f:
                json.dump(dict(self.patterns), f, indent=2)
        except Exception as e:
            logger.error(f"保存模式失败: {e}")

    def _scan_memory_files(self) -> List[str]:
        """扫描记忆文件（包括 SuperMemory 数据库中的记忆内容）"""
        import sqlite3
        contents = []

        # 扫描 markdown 文件
        if self.memory_dir.exists():
            for md_file in self.memory_dir.rglob("*.md"):
                try:
                    with open(md_file, "r") as f:
                        contents.append(f.read())
                except Exception as e:
                    logger.warning(f"读取 {md_file} 失败: {e}")

        # 扫描 SuperMemory 数据库
        data_root = Path("~/.openclaw/workspace-shared/super-memory-data").expanduser()
        if data_root.exists():
            for agent_dir in data_root.iterdir():
                if not agent_dir.is_dir():
                    continue
                db_path = agent_dir / "memories.db"
                if db_path.exists():
                    try:
                        conn = sqlite3.connect(str(db_path))
                        cur = conn.execute(
                            "SELECT content FROM memories ORDER BY created_at DESC LIMIT 200"
                        )
                        rows = cur.fetchall()
                        conn.close()
                        for row in rows:
                            if row[0]:
                                contents.append(row[0])
                    except Exception as e:
                        logger.warning(f"读取 {db_path} 失败: {e}")

        return contents

    def _extract_decision_patterns(self, content: str) -> List[Dict]:
        """提取决策模式"""
        patterns = []
        decision_markers = [
            r"\b(decided|choosing|use\s+|using|go\s+with|prefer|pick\s+|选择|决定|采用)\s*[:\-]?\s*(\S.{0,80})",
            r"\b(do\s+this|go\s+ahead|proceed)\s+with\s+(\S.{0,60})",
        ]

        for marker in decision_markers:
            matches = re.finditer(marker, content, re.IGNORECASE)
            for match in matches:
                decision_text = match.group(0)
                if len(decision_text) > 5:
                    patterns.append({
                        "type": "decision",
                        "content": decision_text[:100],
                        "marker": marker,
                        "confidence": 0.7,
                        "extracted_at": datetime.now().isoformat(),
                    })

        return patterns

    def _extract_preference_patterns(self, content: str) -> List[Dict]:
        """提取偏好模式"""
        patterns = []
        pref_markers = [
            r"\b(like|prefer|love|hate|dislike)\s+(\S.{0,60})",
            r"\b(倾向|偏好|喜欢|讨厌)\s*[:\-]?\s*(\S.{0,60})",
            r"my\s+(?:preferred|favorite|best)\s+(\S.{0,60})",
        ]

        for marker in pref_markers:
            matches = re.finditer(marker, content, re.IGNORECASE)
            for match in matches:
                pref_text = match.group(0)
                if len(pref_text) > 5:
                    patterns.append({
                        "type": "preference",
                        "content": pref_text[:100],
                        "confidence": 0.65,
                        "extracted_at": datetime.now().isoformat(),
                    })

        return patterns

    def _extract_workflow_patterns(self, content: str) -> List[Dict]:
        """提取工作流模式"""
        patterns = []
        # 匹配编号列表
        steps = re.findall(r"^(\d+)[.\)]\s+(.{5,80})", content, re.MULTILINE)
        if len(steps) >= 3:
            patterns.append({
                "type": "workflow",
                "steps": [s[1] for s in steps[:7]],
                "confidence": 0.75,
                "extracted_at": datetime.now().isoformat(),
            })

        return patterns

    def _deduplicate_patterns(self, patterns: List[Dict]) -> List[Dict]:
        """去重模式"""
        seen: Set[str] = set()
        unique = []
        for p in patterns:
            key = p.get("content", "")[:50]
            if key and key not in seen:
                seen.add(key)
                unique.append(p)
        return unique

    def _evolve(self) -> EvolutionResult:
        """执行模式提取"""
        logger.info("开始提取模式...")

        contents = self._scan_memory_files()
        all_patterns = []

        for content in contents:
            all_patterns.extend(self._extract_decision_patterns(content))
            all_patterns.extend(self._extract_preference_patterns(content))
            all_patterns.extend(self._extract_workflow_patterns(content))

        # 去重
        all_patterns = self._deduplicate_patterns(all_patterns)

        # 按类型分组
        by_type = defaultdict(list)
        for p in all_patterns:
            by_type[p["type"]].append(p)

        # 更新模式库
        for ptype, plist in by_type.items():
            self.patterns[ptype].extend(plist)
            # 只保留最近50个
            self.patterns[ptype] = self.patterns[ptype][-50:]

        self._save_patterns()

        changes = {
            "total_extracted": len(all_patterns),
            "by_type": {k: len(v) for k, v in by_type.items()},
        }

        return EvolutionResult(
            success=True,
            evolver_name=self.name,
            changes=changes,
            message=f"提取了 {len(all_patterns)} 个新模式",
        )

    def get_patterns(self, pattern_type: Optional[str] = None) -> Dict:
        """获取模式"""
        if pattern_type:
            return {pattern_type: self.patterns.get(pattern_type, [])}
        return dict(self.patterns)


    def health_check(self) -> dict:
        """健康检查 - 验证模块功能正常"""
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "version": getattr(self, 'VERSION', '1.0.0'),
            "checks": {
                "initialized": hasattr(self, '_initialized') and self._initialized,
                "config_loaded": hasattr(self, 'config') and self.config is not None,
            }
        }

    def self_test(self) -> bool:
        """自测试 - 验证模块可正常运行"""
        try:
            result = self.health_check()
            return result.get("status") == "healthy"
        except Exception:
            return False

