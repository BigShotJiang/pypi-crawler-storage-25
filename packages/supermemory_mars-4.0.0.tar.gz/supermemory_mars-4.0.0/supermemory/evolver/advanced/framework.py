"""
EvolutionFramework - P3进化框架核心
"""

import logging
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import threading

from .base import Evolver, EvolutionResult

logger = logging.getLogger(__name__)


class EvolutionTrigger:
    """触发器 - 条件满足时执行指定动作"""

    def __init__(
        self,
        name: str,
        condition: Callable[[], bool],
        action: Callable[[], Any],
        interval: int = 3600,
        enabled: bool = True,
    ):
        self.name = name
        self.condition = condition
        self.action = action
        self.interval = interval  # 秒
        self.enabled = enabled
        self._last_run: Optional[datetime] = None

    def should_run(self) -> bool:
        """检查是否应该运行"""
        if not self.enabled:
            return False
        if self._last_run is None:
            return True
        elapsed = (datetime.now() - self._last_run).total_seconds()
        return elapsed >= self.interval

    def run(self) -> EvolutionResult:
        """执行触发器动作"""
        try:
            result = self.action()
            self._last_run = datetime.now()
            return EvolutionResult(
                success=True,
                evolver_name=f"trigger:{self.name}",
                changes={"triggered": True},
                message=f"触发器 {self.name} 执行成功",
            )
        except Exception as e:
            logger.exception(f"触发器 {self.name} 执行失败")
            return EvolutionResult(
                success=False,
                evolver_name=f"trigger:{self.name}",
                error=str(e),
                message=f"触发器 {self.name} 执行失败",
            )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "interval": self.interval,
            "enabled": self.enabled,
            "last_run": self._last_run.isoformat() if self._last_run else None,
        }


class EvolutionStats:
    """进化统计"""

    def __init__(self):
        self.total_runs = 0
        self.successful_runs = 0
        self.failed_runs = 0
        self.total_changes = 0
        self.start_time = datetime.now()
        self.last_run_time: Optional[datetime] = None

    def record_run(self, result: EvolutionResult):
        """记录一次运行结果"""
        self.total_runs += 1
        if result.success:
            self.successful_runs += 1
            self.total_changes += len(result.changes) if result.changes else 0
        else:
            self.failed_runs += 1
        self.last_run_time = datetime.now()

    @property
    def success_rate(self) -> float:
        if self.total_runs == 0:
            return 0.0
        return self.successful_runs / self.total_runs

    def to_dict(self) -> dict:
        return {
            "total_runs": self.total_runs,
            "successful_runs": self.successful_runs,
            "failed_runs": self.failed_runs,
            "total_changes": self.total_changes,
            "success_rate": f"{self.success_rate:.1%}",
            "start_time": self.start_time.isoformat(),
            "last_run_time": (
                self.last_run_time.isoformat() if self.last_run_time else None
            ),
        }


class EvolutionFramework:
    """
    进化框架核心
    管理和调度所有进化器
    """

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.evolvers: Dict[str, Evolver] = {}
        self.stats = EvolutionStats()
        self._enabled = True
        self._max_workers = self.config.get("max_workers", 4)
        self._callbacks: Dict[str, List[Callable]] = {
            "before_evolve": [],
            "after_evolve": [],
            "on_error": [],
        }
        self._triggers: List[EvolutionTrigger] = []
        self._trigger_thread: Optional[threading.Thread] = None
        self._trigger_running = False

    def register_evolver(self, evolver: Evolver) -> None:
        """注册进化器"""
        if not isinstance(evolver, Evolver):
            raise TypeError("evolver must be an instance of Evolver")

        if not evolver.validate_config():
            raise ValueError(f"进化器 {evolver.name} 配置验证失败")

        self.evolvers[evolver.name] = evolver
        logger.info(f"已注册进化器: {evolver.name} v{evolver.version}")

    def unregister_evolver(self, name: str) -> bool:
        """取消注册进化器"""
        if name in self.evolvers:
            del self.evolvers[name]
            logger.info(f"已取消注册进化器: {name}")
            return True
        return False

    def get_evolver(self, name: str) -> Optional[Evolver]:
        """获取进化器"""
        return self.evolvers.get(name)

    def list_evolvers(self) -> List[Dict[str, Any]]:
        """列出所有进化器"""
        return [evolver.stats for evolver in self.evolvers.values()]

    def register_callback(
        self, event: str, callback: Callable[[EvolutionResult], None]
    ) -> None:
        """注册回调函数"""
        if event in self._callbacks:
            self._callbacks[event].append(callback)

    def register_trigger(self, trigger: EvolutionTrigger) -> None:
        """注册触发器"""
        self._triggers.append(trigger)
        logger.info(f"已注册触发器: {trigger.name} (间隔: {trigger.interval}s)")

    def unregister_trigger(self, name: str) -> bool:
        """取消注册触发器"""
        for i, t in enumerate(self._triggers):
            if t.name == name:
                del self._triggers[i]
                logger.info(f"已取消注册触发器: {name}")
                return True
        return False

    def check_triggers(self) -> List[EvolutionResult]:
        """检查并执行所有就绪的触发器"""
        results = []
        for trigger in self._triggers:
            if trigger.should_run():
                logger.info(f"触发器 {trigger.name} 条件满足，执行中...")
                result = trigger.run()
                results.append(result)
                if not result.success:
                    self._trigger_callbacks("on_error", result)
        return results

    def start_trigger_daemon(self, check_interval: int = 60) -> None:
        """启动触发器守护线程"""
        if self._trigger_running:
            logger.warning("触发器守护线程已在运行")
            return

        def daemon_loop():
            self._trigger_running = True
            while self._trigger_running:
                self.check_triggers()
                time.sleep(check_interval)

        self._trigger_thread = threading.Thread(target=daemon_loop, daemon=True)
        self._trigger_thread.start()
        logger.info(f"触发器守护线程已启动 (检查间隔: {check_interval}s)")

    def stop_trigger_daemon(self) -> None:
        """停止触发器守护线程"""
        self._trigger_running = False
        if self._trigger_thread:
            self._trigger_thread.join(timeout=5)
            logger.info("触发器守护线程已停止")

    def _trigger_callbacks(self, event: str, result: EvolutionResult):
        """触发回调"""
        for callback in self._callbacks.get(event, []):
            try:
                callback(result)
            except Exception as e:
                logger.error(f"回调执行失败: {e}")

    def evolve_all(self, parallel: bool = False) -> List[EvolutionResult]:
        """执行所有待进化的进化器"""
        if not self._enabled:
            logger.warning("进化框架已禁用")
            return []

        results = []
        pending = [
            evolver
            for evolver in self.evolvers.values()
            if evolver.should_evolve()
        ]

        logger.info(f"开始进化，共 {len(pending)} 个进化器待执行")

        if parallel and len(pending) > 1:
            results = self._evolve_parallel(pending)
        else:
            results = self._evolve_sequential(pending)

        return results

    def _evolve_sequential(
        self, evolvers: List[Evolver]
    ) -> List[EvolutionResult]:
        """顺序执行"""
        results = []
        for evolver in evolvers:
            self._trigger_callbacks("before_evolve", EvolutionResult(
                success=True, evolver_name=evolver.name, message="开始执行"
            ))
            result = evolver.evolve()
            results.append(result)
            self.stats.record_run(result)
            self._trigger_callbacks("after_evolve", result)

            if not result.success:
                self._trigger_callbacks("on_error", result)

        return results

    def _evolve_parallel(self, evolvers: List[Evolver]) -> List[EvolutionResult]:
        """并行执行"""
        results = []

        with ThreadPoolExecutor(max_workers=self._max_workers) as executor:
            futures = {executor.submit(evolver.evolve): evolver for evolver in evolvers}

            for future in as_completed(futures):
                evolver = futures[future]
                try:
                    result = future.result()
                    results.append(result)
                    self.stats.record_run(result)
                    self._trigger_callbacks("after_evolve", result)

                    if not result.success:
                        self._trigger_callbacks("on_error", result)

                except Exception as e:
                    logger.exception(f"进化器 {evolver.name} 执行异常")
                    result = EvolutionResult(
                        success=False,
                        evolver_name=evolver.name,
                        error=str(e),
                        message="执行异常",
                    )
                    results.append(result)
                    self.stats.record_run(result)

        return results

    def evolve(self, name: str) -> Optional[EvolutionResult]:
        """执行指定的进化器"""
        evolver = self.evolvers.get(name)
        if not evolver:
            logger.warning(f"未找到进化器: {name}")
            return None

        result = evolver.evolve()
        self.stats.record_run(result)
        return result

    def enable(self):
        """启用框架"""
        self._enabled = True
        logger.info("进化框架已启用")

    def disable(self):
        """禁用框架"""
        self._enabled = False
        logger.info("进化框架已禁用")

    @property
    def summary(self) -> dict:
        """获取框架汇总信息"""
        return {
            "enabled": self._enabled,
            "evolver_count": len(self.evolvers),
            "stats": self.stats.to_dict(),
            "evolvers": self.list_evolvers(),
        }


    def health_check(self) -> dict:
        """健康检查 - 验证模块功能正常"""
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "version": getattr(self, 'VERSION', '1.0.0'),
            "checks": {
                "initialized": hasattr(self, '_initialized') and self._initialized,
                "config_loaded": hasattr(self, 'config') and self.config is not None,
            }
        }

    def self_test(self) -> bool:
        """自测试 - 验证模块可正常运行"""
        try:
            result = self.health_check()
            return result.get("status") == "healthy"
        except Exception:
            return False

