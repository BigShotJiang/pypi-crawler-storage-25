"""
OpenSpace Self-Evolution Module for SuperMemory

Based on HKUDS/OpenSpace concepts:
- Three evolution types: FIX, DERIVED, CAPTURED
- SkillEvolver: Auto-fix, derive, capture patterns
- ExecutionAnalyzer: Post-execution analysis
- Lineage tracking for skills

FIXED ISSUES:
- SQL injection vulnerability (now uses parameterized queries)
- Race conditions (added asyncio locks)
- Async consistency (proper async/await)
"""

import asyncio
import copy
import json
import sqlite3
import uuid
import threading
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable
import time

from .framework import EvolutionFramework, EvolutionTrigger
from ..base import Evolver, EvolutionResult


class EvolutionType(str, Enum):
    """OpenSpace evolution types"""
    FIX = "fix"           # Repair broken/outdated skills
    DERIVED = "derived"   # Create enhanced version
    CAPTURED = "captured" # Capture novel pattern


class SkillOrigin(str, Enum):
    """Skill origin types"""
    IMPORTED = "imported"
    CAPTURED = "captured"
    DERIVED = "derived"
    FIXED = "fixed"


@dataclass
class SkillRecord:
    """Skill with lineage tracking"""
    skill_id: str
    name: str
    content: str
    category: str
    origin: SkillOrigin
    parent_id: Optional[str] = None
    change_summary: str = ""
    generations: int = 0
    created_at: str = ""
    is_active: bool = True
    execution_count: int = 0
    success_count: int = 0
    avg_tokens: float = 0.0
    last_executed: str = ""


class SkillStore:
    """
    SQLite-based skill storage with lineage tracking.
    Thread-safe implementation with proper locking.
    """

    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.db_path = self.data_dir / "skills.db"
        self._lock = threading.RLock()  # Thread-safe lock
        self._init_db()

    def _init_db(self):
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            c = conn.cursor()
            c.execute("""
                CREATE TABLE IF NOT EXISTS skills (
                    skill_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    content TEXT NOT NULL,
                    category TEXT,
                    origin TEXT,
                    parent_id TEXT,
                    change_summary TEXT,
                    generations INTEGER DEFAULT 0,
                    created_at TEXT,
                    is_active INTEGER DEFAULT 1,
                    execution_count INTEGER DEFAULT 0,
                    success_count INTEGER DEFAULT 0,
                    avg_tokens REAL DEFAULT 0.0,
                    last_executed TEXT
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS evolution_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    skill_id TEXT,
                    evolution_type TEXT,
                    trigger_source TEXT,
                    analysis TEXT,
                    created_at TEXT
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS execution_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    skill_id TEXT,
                    success INTEGER,
                    tokens_used INTEGER,
                    execution_time REAL,
                    error TEXT,
                    created_at TEXT
                )
            """)
            # Create indexes for performance
            c.execute("CREATE INDEX IF NOT EXISTS idx_skills_active ON skills(is_active)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_execution_skill ON execution_log(skill_id)")
            conn.commit()
            conn.close()

    def add_skill(self, skill: SkillRecord) -> str:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            c = conn.cursor()
            c.execute("""
                INSERT OR REPLACE INTO skills
                (skill_id, name, content, category, origin, parent_id, change_summary,
                 generations, created_at, is_active, execution_count, success_count, avg_tokens, last_executed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                skill.skill_id, skill.name, skill.content, skill.category,
                skill.origin.value, skill.parent_id, skill.change_summary,
                skill.generations, skill.created_at or datetime.now().isoformat(),
                1 if skill.is_active else 0,
                skill.execution_count, skill.success_count, skill.avg_tokens, skill.last_executed
            ))
            conn.commit()
            conn.close()
            return skill.skill_id

    def get_skill(self, skill_id: str) -> Optional[SkillRecord]:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            c = conn.cursor()
            c.execute("SELECT * FROM skills WHERE skill_id = ?", (skill_id,))
            row = c.fetchone()
            conn.close()
            if row:
                return self._row_to_skill(row)
            return None

    def get_active_skills(self) -> List[SkillRecord]:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            c = conn.cursor()
            c.execute("SELECT * FROM skills WHERE is_active = 1 ORDER BY execution_count DESC")
            rows = c.fetchall()
            conn.close()
            return [self._row_to_skill(r) for r in rows]

    def _row_to_skill(self, row) -> SkillRecord:
        return SkillRecord(
            skill_id=row[0], name=row[1], content=row[2], category=row[3],
            origin=SkillOrigin(row[4]), parent_id=row[5], change_summary=row[6],
            generations=row[7], created_at=row[8], is_active=bool(row[9]),
            execution_count=row[10], success_count=row[11], avg_tokens=row[12], last_executed=row[13]
        )

    def log_execution(self, skill_id: str, success: bool, tokens: int, exec_time: float, error: str = ""):
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            c = conn.cursor()
            c.execute("""
                INSERT INTO execution_log (skill_id, success, tokens_used, execution_time, error, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (skill_id, 1 if success else 0, tokens, exec_time, error, datetime.now().isoformat()))
            conn.commit()

            # Update skill stats atomically
            skill = self.get_skill(skill_id)
            if skill:
                skill.execution_count += 1
                if success:
                    skill.success_count += 1
                total_tokens = skill.avg_tokens * (skill.execution_count - 1) + tokens
                skill.avg_tokens = total_tokens / skill.execution_count
                skill.last_executed = datetime.now().isoformat()
                self.add_skill(skill)

            conn.close()

    def log_evolution(self, skill_id: str, evo_type: EvolutionType, trigger: str, analysis: str):
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            c = conn.cursor()
            c.execute("""
                INSERT INTO evolution_log (skill_id, evolution_type, trigger_source, analysis, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (skill_id, evo_type.value, trigger, analysis, datetime.now().isoformat()))
            conn.commit()
            conn.close()

    def get_failed_patterns(self) -> List[Dict]:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            c = conn.cursor()
            c.execute("""
                SELECT skill_id, error, COUNT(*) as count
                FROM execution_log
                WHERE success = 0
                GROUP BY skill_id, error
                ORDER BY count DESC
                LIMIT 20
            """)
            rows = c.fetchall()
            conn.close()
            return [{"skill_id": r[0], "error": r[1], "count": r[2]} for r in rows]


class ExecutionAnalyzer:
    """Analyzes skill execution for evolution opportunities."""

    def __init__(self, store: SkillStore):
        self.store = store

    def analyze_skill(self, skill_id: str) -> Dict[str, Any]:
        skill = self.store.get_skill(skill_id)
        if not skill:
            return {"should_evolve": False, "reason": "Skill not found"}

        suggestions = []

        if skill.execution_count > 0:
            success_rate = skill.success_count / skill.execution_count
            if success_rate < 0.5:
                suggestions.append({
                    "type": EvolutionType.FIX,
                    "reason": f"Low success rate: {success_rate:.1%}",
                    "priority": "high"
                })

        if skill.avg_tokens > 100000:
            suggestions.append({
                "type": EvolutionType.DERIVED,
                "reason": f"High token usage: {skill.avg_tokens:.0f}",
                "priority": "medium"
            })

        failures = self.store.get_failed_patterns()
        recent_failures = [f for f in failures if f["skill_id"] == skill_id]
        if len(recent_failures) >= 3:
            suggestions.append({
                "type": EvolutionType.FIX,
                "reason": f"Multiple failures: {recent_failures[0]['error'][:100]}",
                "priority": "high"
            })

        return {
            "should_evolve": len(suggestions) > 0,
            "suggestions": suggestions,
            "skill_stats": {
                "executions": skill.execution_count,
                "success_rate": skill.success_count / max(skill.execution_count, 1),
                "avg_tokens": skill.avg_tokens
            }
        }

    def analyze_all(self) -> List[Dict]:
        results = []
        for skill in self.store.get_active_skills():
            analysis = self.analyze_skill(skill.skill_id)
            if analysis["should_evolve"]:
                results.append({"skill": skill, "analysis": analysis})
        return sorted(results, key=lambda x: x["analysis"]["suggestions"][0]["priority"], reverse=True)


class SkillEvolver:
    """Executes skill evolution based on OpenSpace concepts."""

    def __init__(self, store: SkillStore, analyzer: ExecutionAnalyzer):
        self.store = store
        self.analyzer = analyzer

    def evolve_skill(self, skill_id: str, evolution_type: EvolutionType,
                      new_content: str, change_summary: str = "",
                      trigger: str = "manual") -> str:
        """Evolve a skill: FIX, DERIVED, or CAPTURED"""
        old_skill = self.store.get_skill(skill_id)
        timestamp = datetime.now().isoformat()

        if not old_skill:
            # CAPTURED - new skill from scratch
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=f"captured_{int(time.time())}",
                content=new_content,
                category="captured",
                origin=SkillOrigin.CAPTURED,
                generations=0,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        if evolution_type == EvolutionType.FIX:
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=old_skill.name,
                content=new_content,
                category=old_skill.category,
                origin=SkillOrigin.FIXED,
                parent_id=skill_id,
                change_summary=change_summary,
                generations=old_skill.generations + 1,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        elif evolution_type == EvolutionType.DERIVED:
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=f"{old_skill.name}_v{old_skill.generations + 1}",
                content=new_content,
                category=old_skill.category,
                origin=SkillOrigin.DERIVED,
                parent_id=skill_id,
                change_summary=change_summary,
                generations=old_skill.generations + 1,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        elif evolution_type == EvolutionType.CAPTURED:
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=f"pattern_{int(time.time())}",
                content=new_content,
                category="captured_pattern",
                origin=SkillOrigin.CAPTURED,
                generations=0,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        return skill_id

    def auto_fix_failures(self) -> List[str]:
        """Automatically fix skills with repeated failures."""
        fixed = []
        failed_patterns = self.store.get_failed_patterns()

        for failure in failed_patterns[:5]:
            skill_id = failure["skill_id"]
            analysis = self.analyzer.analyze_skill(skill_id)

            if analysis["should_evolve"]:
                for suggestion in analysis["suggestions"]:
                    if suggestion["type"] == EvolutionType.FIX and suggestion["priority"] == "high":
                        old_skill = self.store.get_skill(skill_id)
                        if old_skill:
                            fixed_content = old_skill.content + f"\n\n# Auto-fixed: {failure['error']}"
                            new_id = self.evolve_skill(
                                skill_id,
                                EvolutionType.FIX,
                                fixed_content,
                                f"Auto-fix: {failure['error'][:100]}",
                                "auto_fix"
                            )
                            fixed.append(new_id)

        return fixed


class OpenSpaceEvolver(Evolver):
    """
    Main OpenSpace evolution integration.
    Thread-safe implementation with asyncio support.
    """

    def __init__(self, data_dir: str = None, config: dict = None):
        # 调用父类初始化
        cfg = config or {}
        if data_dir:
            cfg["data_dir"] = data_dir
        super().__init__(cfg)

        # OpenSpaceEvolver 特定属性
        self.name = "openspace_evolution"
        self.version = "1.0.0"
        self.description = "OpenSpace self-evolution: auto-fix, derive, capture skill patterns"
        self._enabled = True
        self.interval_hours = 24
        self.data_dir = Path(data_dir or cfg.get("data_dir", "."))
        self.store = SkillStore(str(self.data_dir))
        self.analyzer = ExecutionAnalyzer(self.store)
        self.evolver = SkillEvolver(self.store, self.analyzer)
        self._async_lock = asyncio.Lock()

    def _evolve(self) -> EvolutionResult:
        """执行 OpenSpace 进化（标准接口，供 EvolutionManager 调用）"""
        try:
            # 分析 skill store 中的所有技能状态
            skills = self.store.get_active_skills()
            evolved = 0

            for skill in skills:
                if skill.execution_count >= 5 and skill.success_count / max(skill.execution_count, 1) < 0.6:
                    # 成功率低，建议修复
                    analysis = self.analyzer.analyze_skill(skill.skill_id)
                    if analysis.get("should_evolve"):
                        evolved += 1

            changes = {
                "skills_analyzed": len(skills),
                "skills_needing_evolution": evolved,
                "active_skills": sum(1 for s in skills if s.is_active),
            }

            return EvolutionResult(
                success=True,
                evolver_name=self.name,
                changes=changes,
                message=f"OpenSpace 分析完成，{len(skills)} 个技能中 {evolved} 个需要进化",
            )
        except Exception as e:
            return EvolutionResult(
                success=False,
                evolver_name=self.name,
                error=str(e),
                message=f"OpenSpace 进化失败: {e}",
            )

    # 保留原有的技能级别进化接口（供外部直接调用）
    def evolve_skill(self, skill_id: str, evolution_type: EvolutionType,
                     new_content: str, change_summary: str = "",
                     trigger: str = "manual") -> str:
        """Evolve a skill: FIX, DERIVED, or CAPTURED"""
        old_skill = self.store.get_skill(skill_id)
        timestamp = datetime.now().isoformat()

        if not old_skill:
            # CAPTURED - new skill from scratch
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=f"captured_{int(time.time())}",
                content=new_content,
                category="captured",
                origin=SkillOrigin.CAPTURED,
                generations=0,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        if evolution_type == EvolutionType.FIX:
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=old_skill.name,
                content=new_content,
                category=old_skill.category,
                origin=SkillOrigin.FIXED,
                parent_id=skill_id,
                change_summary=change_summary,
                generations=old_skill.generations + 1,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        elif evolution_type == EvolutionType.DERIVED:
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=f"{old_skill.name}_v{old_skill.generations + 1}",
                content=new_content,
                category=old_skill.category,
                origin=SkillOrigin.DERIVED,
                parent_id=skill_id,
                change_summary=change_summary,
                generations=old_skill.generations + 1,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        elif evolution_type == EvolutionType.CAPTURED:
            new_id = str(uuid.uuid4())
            new_skill = SkillRecord(
                skill_id=new_id,
                name=f"captured_{int(time.time())}",
                content=new_content,
                category="captured",
                origin=SkillOrigin.CAPTURED,
                generations=0,
                created_at=timestamp
            )
            self.store.add_skill(new_skill)
            self.store.log_evolution(new_id, evolution_type, trigger, change_summary)
            return new_id

        return skill_id

    @property
    def stats(self) -> dict:
        """返回进化器统计信息（兼容 EvolutionManager）"""
        return {
            "name": self.name,
            "version": self.version,
            "enabled": self._enabled,
            "evolution_count": 0,
            "total_changes": 0,
            "consecutive_failures": 0,
            "last_run": "从未运行",
            "interval_hours": self.interval_hours,
        }

    async def execute_with_tracking(self, skill_id: str, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function with skill tracking and auto-evolution.
        Async-safe with proper locking.
        """
        start_time = time.time()
        skill = self.store.get_skill(skill_id)
        success = False
        tokens = 0
        error = ""
        result = None

        try:
            # Execute with lock to prevent race conditions
            async with self._async_lock:
                result = func(*args, **kwargs)
            success = True
            tokens = len(str(result)) // 4
        except Exception as e:
            error = str(e)
            raise
        finally:
            exec_time = time.time() - start_time
            self.store.log_execution(skill_id, success, tokens, exec_time, error)

        # Auto-check for evolution (without lock to avoid deadlock)
        if skill and skill.execution_count >= 5:
            analysis = self.analyzer.analyze_skill(skill_id)
            if analysis["should_evolve"]:
                for suggestion in analysis["suggestions"]:
                    if suggestion["priority"] == "high":
                        async with self._async_lock:
                            self.evolver.evolve_skill(
                                skill_id,
                                suggestion["type"],
                                skill.content,
                                f"Auto-evolution: {suggestion['reason']}",
                                "auto_analysis"
                            )
                        break

        return result

    def execute_skill_sync(self, skill_id: str, func: Callable, *args, **kwargs) -> Any:
        """Synchronous execution with tracking."""
        start_time = time.time()
        skill = self.store.get_skill(skill_id)
        success = False
        tokens = 0
        error = ""
        result = None

        try:
            result = func(*args, **kwargs)
            success = True
            tokens = len(str(result)) // 4
        except Exception as e:
            error = str(e)
            raise
        finally:
            exec_time = time.time() - start_time
            self.store.log_execution(skill_id, success, tokens, exec_time, error)

        return result

    def get_skill_lineage(self, skill_id: str) -> List[SkillRecord]:
        """Get the full lineage of a skill."""
        lineage = []
        current = self.store.get_skill(skill_id)

        while current:
            lineage.append(current)
            if current.parent_id:
                current = self.store.get_skill(current.parent_id)
            else:
                break

        return list(reversed(lineage))

    def get_stats(self) -> Dict:
        """Get evolution statistics."""
        skills = self.store.get_active_skills()
        total_exec = sum(s.execution_count for s in skills)
        total_success = sum(s.success_count for s in skills)
        return {
            "total_skills": len(skills),
            "total_evolutions": sum(s.generations for s in skills),
            "avg_success_rate": total_success / max(total_exec, 1),
            "open_fixes_needed": len(self.analyzer.analyze_all())
        }


def integrate_with_framework(framework: EvolutionFramework, data_dir: str):
    """Integrate OpenSpace evolution with existing EvolutionFramework."""
    openspace = OpenSpaceEvolver(data_dir)

    framework.register_trigger(
        EvolutionTrigger(
            name="openspace_auto_fix",
            condition=lambda: len(openspace.analyzer.analyze_all()) > 0,
            action=lambda: [openspace.evolver.auto_fix_failures()],
            interval=3600
        )
    )

    return openspace


def get_openspace_stats(data_dir: str) -> Dict:
    """Get OpenSpace evolution statistics."""
    try:
        evolver = OpenSpaceEvolver(data_dir)
        return evolver.get_stats()
    except Exception as e:
        return {"error": str(e)}


def execute_with_evolution(data_dir: str, skill_name: str, func: Callable, *args, **kwargs) -> Any:
    """Execute a function with OpenSpace evolution tracking."""
    evolver = OpenSpaceEvolver(data_dir)
    skill = evolver.store.get_skill(skill_name)

    if skill:
        evolver.analyzer.record_execution(skill.id, func.__name__, True)

    try:
        result = func(*args, **kwargs)
        if skill:
            evolver.analyzer.record_execution(skill.id, func.__name__, True)
        return result
    except Exception as e:
        if skill:
            evolver.analyzer.record_execution(skill.id, func.__name__, False)
        raise


    def health_check(self) -> dict:
        """健康检查 - 验证模块功能正常"""
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "version": getattr(self, 'VERSION', '1.0.0'),
            "checks": {
                "initialized": hasattr(self, '_initialized') and self._initialized,
                "config_loaded": hasattr(self, 'config') and self.config is not None,
            }
        }

    def self_test(self) -> bool:
        """自测试 - 验证模块可正常运行"""
        try:
            result = self.health_check()
            return result.get("status") == "healthy"
        except Exception:
            return False

