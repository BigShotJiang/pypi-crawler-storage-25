"""
GitHubLearner - 每周扫描GitHub记忆系统项目，优化我们的记忆系统
设计：用户审批 -> 执行进化
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path

from .base import Evolver, EvolutionResult

logger = logging.getLogger(__name__)


# GitHub上值得关注的记忆系统相关仓库（纯ASCII）
MEMORY_SYSTEM_REPOS = [
    "mem0ai/mem0",
    "MemoriLabs/Memori",
    "topoteretes/cognee",
    "memvid/memvid",
    "Shichun-Liu/Agent-Memory-Paper-List",
    "assafelovic/gpt-researcher",
    "KAI-DMU/LoneMemory",
    "langchain-ai/langchain",
    "run-llama/llama_index",
    "romaintha/LongMemory",
]


class GitHubLearner(Evolver):
    """
    GitHub记忆系统学习器

    每周任务：
    1. 扫描 GitHub 上记忆系统相关项目
    2. 分析优秀项目的实现方式
    3. 生成优化我们的记忆系统的提案
    4. 提案经过用户审批后再执行进化
    """

    name = "github_learner"
    version = "1.0.0"
    description = "每周扫描GitHub记忆系统项目，生成优化提案，经用户审批后执行"
    interval_hours = 168  # 每周一次

    PROPOSAL_FILE = "memory/github_evolution_proposal.json"

    def __init__(self, config: dict = None):
        super().__init__(config)
        self.github_token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
        self.tracked_repos = self.config.get("tracked_repos", MEMORY_SYSTEM_REPOS)
        self.proposals: List[Dict] = []
        self.cache_file = Path(self.config.get("cache_file", self.PROPOSAL_FILE))
        self.data_dir = Path(self.config.get("data_dir", "~/.openclaw/workspace-shared/super-memory-data")).expanduser()
        self._load_proposals()

    # ============================
    # 核心进化逻辑
    # ============================

    def _evolve(self) -> EvolutionResult:
        """执行每周GitHub扫描 + 生成提案"""
        logger.info("[GitHubLearner] 开始每周GitHub扫描...")

        # 1. 扫描跟踪的仓库
        repo_updates = self._scan_tracked_repos()

        # 2. 搜索新的记忆系统项目
        new_projects = self._search_memory_projects()

        # 3. 分析有价值项目，生成提案
        proposals = self._generate_proposals(repo_updates, new_projects)

        if not proposals:
            return EvolutionResult(
                success=True,
                evolver_name=self.name,
                changes={},
                message="本周无新的优化提案（没有发现值得学习的项目）",
            )

        # 4. 保存提案，等待用户审批
        self._save_proposals(proposals)
        self._notify_new_proposals(proposals)

        proposal_summaries = [self._summarize_proposal(p) for p in proposals]

        return EvolutionResult(
            success=True,
            evolver_name=self.name,
            changes={
                "proposals_generated": len(proposals),
                "projects_analyzed": len(repo_updates) + len(new_projects),
                "pending_approval": len(proposals),
                "proposals": proposal_summaries,
            },
            message=f"生成了 {len(proposals)} 个优化提案，等待审批后再执行",
        )

    # ============================
    # GitHub 数据获取
    # ============================

    def _fetch_github(self, url: str) -> Optional[dict]:
        """发送GitHub API请求"""
        try:
            import urllib.request

            headers = {
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "SuperMemory-Bot/1.0",
            }
            if self.github_token:
                headers["Authorization"] = f"token {self.github_token}"

            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=15) as response:
                return json.loads(response.read().decode())
        except Exception as e:
            logger.warning(f"GitHub API请求失败: {e}")
            return None

    def _scan_tracked_repos(self) -> List[Dict[str, Any]]:
        """扫描跟踪的仓库，获取最新信息"""
        updates = []
        for repo in self.tracked_repos:
            data = self._fetch_github(f"https://api.github.com/repos/{repo}")
            if data and "full_name" in data:
                update = {
                    "repo": data["full_name"],
                    "stars": data.get("stargazers_count", 0),
                    "forks": data.get("forks_count", 0),
                    "language": data.get("language"),
                    "description": data.get("description"),
                    "latest_commit": data.get("pushed_at"),
                    "topics": data.get("topics", []),
                    "open_issues": data.get("open_issues_count", 0),
                    "license": data.get("license", {}).get("name") if data.get("license") else None,
                    "readme_url": f"https://raw.githubusercontent.com/{repo}/main/README.md",
                }
                updates.append(update)
                logger.info(f"  扫描: {repo} ⭐{update['stars']}")
        return updates

    def _search_memory_projects(self) -> List[Dict[str, Any]]:
        """搜索新的记忆系统相关项目"""
        projects = []
        queries = [
            "AI+memory+system+lang:Python",
            "LLM+memory+retrieval+stars:>50",
            "agent+memory+vector+lang:Python",
        ]
        for query in queries:
            url = f"https://api.github.com/search/repositories?q={query}&sort=stars&per_page=5"
            data = self._fetch_github(url)
            if data and "items" in data:
                for item in data["items"]:
                    # 跳过已跟踪的
                    if item["full_name"] in [r["repo"] for r in projects]:
                        continue
                    if item["full_name"] in self.tracked_repos:
                        continue
                    projects.append({
                        "repo": item["full_name"],
                        "stars": item.get("stargazers_count", 0),
                        "language": item.get("language"),
                        "description": item.get("description"),
                        "topics": item.get("topics", []),
                        "url": item.get("html_url"),
                    })
                    logger.info(f"  发现: {item['full_name']} ⭐{item.get('stargazers_count')}")
        return projects

    # ============================
    # 提案生成
    # ============================

    def _generate_proposals(self, repo_updates: List[Dict], new_projects: List[Dict]) -> List[Dict[str, Any]]:
        """分析项目，生成对我们有价值的优化提案"""
        proposals = []

        for repo_data in repo_updates + new_projects:
            proposal = self._analyze_project_for_proposal(repo_data)
            if proposal:
                proposals.append(proposal)

        # 按价值排序
        proposals.sort(key=lambda x: x.get("priority_score", 0), reverse=True)
        return proposals[:3]  # 最多3个提案

    def _analyze_project_for_proposal(self, project: Dict) -> Optional[Dict[str, Any]]:
        """分析单个项目，生成具体优化提案"""
        repo = project["repo"]
        stars = project.get("stars", 0)
        description = project.get("description", "")

        # 高价值项目才生成提案（避免噪音）
        if stars < 50 and repo not in self.tracked_repos:
            return None

        # 基于仓库名和描述判断类型，生成针对性提案
        proposal = {
            "id": f"gh-{repo.replace('/', '-')}-{datetime.now().strftime('%Y%m%d')}",
            "repo": repo,
            "stars": stars,
            "description": description,
            "topics": project.get("topics", []),
            "created_at": datetime.now().isoformat(),
            "status": "pending_approval",  # pending_approved / rejected / executed
            "priority_score": min(stars / 100, 10),  # 最高10分
        }

        # 分析可以借鉴什么
        借鉴点 = []
        优势 = []
        风险 = []

        if "mem0" in repo.lower():
            借鉴点 = ["向量检索层", "多模态记忆", "API设计", "用户配置灵活性"]
            优势 = ["stars高，社区活跃", "Python生态完善", "文档齐全"]
            风险 = ["架构差异大，集成难度高", "可能引入外部依赖"]
            proposal["evolve_action"] = "study_mem0_architecture"
        elif "cognee" in repo.lower() or "memori" in repo.lower():
            借鉴点 = ["图谱记忆", "关系抽取", "可解释性"]
            优势 = ["与我们的方向接近", "代码质量高"]
            风险 = ["实现复杂度高", "性能待验证"]
            proposal["evolve_action"] = "study_graph_memory"
        elif "longmemory" in repo.lower() or "long-context" in str(description).lower():
            借鉴点 = ["长上下文处理", "记忆压缩", "摘要技术"]
            优势 = ["解决我们的核心痛点", "可以小范围先试"]
            风险 = ["效果不确定", "需要大量测试"]
            proposal["evolve_action"] = "study_long_context"
        elif "agent" in repo.lower() and "memory" in repo.lower():
            借鉴点 = ["Agent记忆框架", "记忆检索策略", "优先级机制"]
            优势 = ["通用性强", "实现难度适中"]
            风险 = ["定制化程度高", "可能改动范围大"]
            proposal["evolve_action"] = "study_agent_memory"
        else:
            借鉴点 = ["代码组织", "API设计", "测试覆盖"]
            优势 = ["学习成本低", "风险可控"]
            风险 = ["产出有限"]
            proposal["evolve_action"] = "study_general"

        proposal["借鉴点"] = 借鉴点
        proposal["优势"] = 优势
        proposal["风险"] = 风险
        proposal["具体说明"] = (
            f"从 {repo} (⭐{stars}) 学习：{'、'.join(借鉴点)}。"
            f"优势：{'；'.join(优势)}。"
            f"风险：{'；'.join(风险)}。"
        )

        return proposal

    def _summarize_proposal(self, proposal: Dict) -> str:
        """生成提案摘要"""
        return (
            f"[{proposal['repo']}] ⭐{proposal['stars']}："
            f"{'、'.join(proposal.get('借鉴点', [])[:2])}"
        )

    # ============================
    # 提案管理（用户审批流程）
    # ============================

    def get_pending_proposals(self) -> List[Dict]:
        """获取待审批的提案"""
        return [p for p in self.proposals if p.get("status") == "pending_approval"]

    def approve_proposal(self, proposal_id: str) -> Dict[str, Any]:
        """用户批准提案 -> 执行进化"""
        for p in self.proposals:
            if p["id"] == proposal_id and p["status"] == "pending_approval":
                p["status"] = "approved"
                p["approved_at"] = datetime.now().isoformat()
                self._save_proposals([])
                return {"success": True, "proposal": p, "message": f"提案 {proposal_id} 已批准，开始执行"}
        return {"success": False, "message": f"未找到提案: {proposal_id}"}

    def reject_proposal(self, proposal_id: str) -> Dict[str, Any]:
        """用户拒绝提案"""
        for p in self.proposals:
            if p["id"] == proposal_id:
                p["status"] = "rejected"
                p["rejected_at"] = datetime.now().isoformat()
                self._save_proposals([])
                return {"success": True, "message": f"提案 {proposal_id} 已拒绝"}
        return {"success": False, "message": f"未找到提案: {proposal_id}"}

    def execute_proposal(self, proposal_id: str) -> EvolutionResult:
        """执行已批准的提案"""
        for p in self.proposals:
            if p["id"] == proposal_id and p.get("status") == "approved":
                # 根据 evolve_action 执行具体进化
                action = p.get("evolve_action", "study_general")
                logger.info(f"[GitHubLearner] 执行进化: {action} for {p['repo']}")

                # 这里后续接入具体执行逻辑
                # 目前是框架，执行时记录
                p["status"] = "executed"
                p["executed_at"] = datetime.now().isoformat()
                self._save_proposals([])

                return EvolutionResult(
                    success=True,
                    evolver_name=self.name,
                    changes={
                        "executed_proposal": proposal_id,
                        "repo": p["repo"],
                        "action": action,
                        "learned_points": p.get("借鉴点", []),
                    },
                    message=f"已执行：{p['repo']} 的 {'、'.join(p.get('借鉴点', []))}",
                )

        return EvolutionResult(
            success=False,
            evolver_name=self.name,
            changes={},
            message=f"提案 {proposal_id} 不存在或未批准",
        )

    # ============================
    # 持久化
    # ============================

    def _load_proposals(self):
        """加载历史提案"""
        f = self.data_dir / "github_learner_proposals.json"
        if f.exists():
            try:
                self.proposals = json.loads(f.read_text())
            except:
                self.proposals = []

    def _save_proposals(self, new_proposals: List[Dict]):
        """保存提案"""
        # 合并新提案（避免重复）
        existing_ids = {p["id"] for p in self.proposals}
        for np in new_proposals:
            if np["id"] not in existing_ids:
                self.proposals.append(np)

        f = self.data_dir / "github_learner_proposals.json"
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps(self.proposals, ensure_ascii=False, indent=2))

    def _notify_new_proposals(self, proposals: List[Dict]):
        """通知用户有新的提案待审批"""
        if not proposals:
            return
        try:
            notify_file = self.data_dir / "github_learner_pending_notify.json"
            content = {
                "type": "github_proposals",
                "count": len(proposals),
                "proposals": [
                    {
                        "id": p["id"],
                        "repo": p["repo"],
                        "stars": p["stars"],
                        "借鉴点": p.get("借鉴点", []),
                        "优势": p.get("优势", []),
                        "风险": p.get("风险", []),
                        "具体说明": p.get("具体说明", ""),
                    }
                    for p in proposals
                ],
                "created_at": datetime.now().isoformat(),
                "notified": False,
            }
            notify_file.write_text(json.dumps(content, ensure_ascii=False, indent=2))
            logger.info(f"[GitHubLearner] 提案通知已写入: {notify_file}")
        except Exception as e:
            logger.warning(f"[GitHubLearner] 通知写入失败: {e}")

    # ============================
    # 健康检查
    # ============================

    def health_check(self) -> dict:
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "tracked_repos": len(self.tracked_repos),
            "pending_proposals": len(self.get_pending_proposals()),
            "total_proposals": len(self.proposals),
        }
