from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from datetime import datetime
import time
import logging

logger = logging.getLogger(__name__)


class EvolutionResult:
    """进化结果"""

    def __init__(
        self,
        success: bool,
        evolver_name: str,
        changes: Dict[str, Any] = None,
        message: str = "",
        error: Optional[str] = None,
    ):
        self.success = success
        self.evolver_name = evolver_name
        self.changes = changes or {}
        self.message = message
        self.error = error
        self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "evolver_name": self.evolver_name,
            "changes": self.changes,
            "message": self.message,
            "error": self.error,
            "timestamp": self.timestamp,
        }

    def __repr__(self) -> str:
        status = "✅" if self.success else "❌"
        return f"<EvolutionResult {status} [{self.evolver_name}] {self.message}>"


class Evolver(ABC):
    """
    进化器基类
    所有进化器必须继承此类
    """

    name: str = "base_evolver"
    version: str = "1.0.0"
    description: str = ""
    interval_hours: int = 24  # 默认24小时进化一次

    def __init__(self, config: dict = None):
        self.config = config or {}
        self._last_run = 0
        self._enabled = True
        self._evolution_count = 0
        self._total_changes = 0
        self._consecutive_failures = 0

    @property
    def last_run_str(self) -> str:
        """返回上次运行时间的可读字符串"""
        if self._last_run == 0:
            return "从未运行"
        return datetime.fromtimestamp(self._last_run).strftime("%Y-%m-%d %H:%M:%S")

    @property
    def stats(self) -> dict:
        """返回进化器统计信息"""
        return {
            "name": self.name,
            "version": self.version,
            "enabled": self._enabled,
            "evolution_count": self._evolution_count,
            "total_changes": self._total_changes,
            "consecutive_failures": self._consecutive_failures,
            "last_run": self.last_run_str,
            "interval_hours": self.interval_hours,
        }

    def should_evolve(self) -> bool:
        """检查是否应该运行进化"""
        if not self._enabled:
            return False

        now = time.time()
        interval_seconds = self.interval_hours * 3600

        # 如果从未运行，应该运行
        if self._last_run == 0:
            return True

        # 检查间隔
        return (now - self._last_run) >= interval_seconds

    def evolve(self) -> EvolutionResult:
        """
        执行进化操作
        包含通用错误处理和统计更新
        """
        if not self.should_evolve():
            return EvolutionResult(
                success=True,
                evolver_name=self.name,
                message="未达到进化间隔，跳过",
            )

        logger.info(f"开始执行进化器: {self.name}")
        start_time = time.time()

        try:
            result = self._evolve()
            result.evolver_name = self.name

            # 更新统计
            self._last_run = start_time
            self._evolution_count += 1

            if result.success:
                change_count = len(result.changes) if result.changes else 0
                self._total_changes += change_count
                self._consecutive_failures = 0
                logger.info(
                    f"进化器 {self.name} 执行成功，产生了 {change_count} 项变更"
                )
            else:
                self._consecutive_failures += 1
                logger.warning(f"进化器 {self.name} 执行失败: {result.message}")

            return result

        except Exception as e:
            self._consecutive_failures += 1
            logger.exception(f"进化器 {self.name} 发生异常")
            return EvolutionResult(
                success=False,
                evolver_name=self.name,
                error=str(e),
                message=f"执行异常: {e}",
            )

    @abstractmethod
    def _evolve(self) -> EvolutionResult:
        """
        具体进化逻辑
        子类必须实现此方法
        """
        pass

    def enable(self):
        """启用进化器"""
        self._enabled = True

    def disable(self):
        """禁用进化器"""
        self._enabled = False

    def reset_stats(self):
        """重置统计信息"""
        self._evolution_count = 0
        self._total_changes = 0
        self._consecutive_failures = 0
        self._last_run = 0

    def validate_config(self) -> bool:
        """
        验证配置
        子类可重写此方法进行配置验证
        """
        return True


    def health_check(self) -> dict:
        """健康检查 - 验证模块功能正常"""
        return {
            "status": "healthy",
            "module": self.__class__.__name__,
            "version": getattr(self, 'VERSION', '1.0.0'),
            "checks": {
                "initialized": hasattr(self, '_initialized') and self._initialized,
                "config_loaded": hasattr(self, 'config') and self.config is not None,
            }
        }

    def self_test(self) -> bool:
        """自测试 - 验证模块可正常运行"""
        try:
            result = self.health_check()
            return result.get("status") == "healthy"
        except Exception:
            return False

