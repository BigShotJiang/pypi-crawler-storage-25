#!/usr/bin/env python3
"""
SuperMemory V4 - Setup Script
备用安装方式: python setup.py install
或: pip install .
"""
from setuptools import setup, find_packages
import os

# 读取 README
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "SuperMemory - AI记忆系统"

# 读取版本
version = "4.0.0"
try:
    init_path = os.path.join(os.path.dirname(__file__), "supermemory", "__init__.py")
    with open(init_path, "r") as f:
        for line in f:
            if line.startswith("__version__"):
                version = line.split("=")[1].strip().strip('"').strip("'")
                break
except:
    pass

setup(
    name="supermemory-mars",
    version=version,
    description="SuperMemory - AI记忆系统，让AI永远记得你的所有偏好、决策和上下文",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="SuperMemory Team",
    author_email="supermemory.ai.agent@gmail.com",
    url="https://github.com/mars82311111/SuperMemory",
    packages=find_packages(exclude=["tests", "tests.*", "docs"]),
    python_requires=">=3.9",
    install_requires=[
        "chromadb>=0.4.0",
        "numpy>=1.21.0",
        "requests>=2.28.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "ruff>=0.1.0",
        ],
        "all": [
            "chromadb>=0.4.0",
            "numpy>=1.21.0",
            "requests>=2.28.0",
            "flask>=2.3.0",
            "fastapi>=0.100.0",
            "uvicorn>=0.23.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "sm=supermemory.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="ai memory llm vector-search context",
    project_urls={
        "Bug Reports": "https://github.com/mars82311111/SuperMemory/issues",
        "Source": "https://github.com/mars82311111/SuperMemory",
    },
)
