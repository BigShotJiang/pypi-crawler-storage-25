# SuperMemory V4 - AI 第二大脑

> 统一入口、高度模块化、支持自进化的企业级 AI 记忆系统

**V4 架构**：V4 简洁核心 + GitHub OpenSpace 进化器 + 全面自愈系统

---

## 核心特性

### 🧠 三层记忆系统
热层（7天）→ 暖层（30天）→ 冷层（90天）→ 归档，自动流转无需人工干预

### 🔍 混合搜索
BM25 + 向量语义搜索结合，关键词+语义双重命中

### 🛡️ 全面自愈系统
19 个检查器 + 19 个修复器，覆盖所有核心模块和进化技能，5分钟自动检查

### 🔄 进化框架
5 个主动进化器 + 自愈闭环，技能可持续自我优化

### 📦 高度模块化
```
supermemory/
├── core/              # 核心服务（8个）
├── core/advanced/     # 高级模块（13个）
├── evolver/           # V4 自愈 + 进化管理器
├── evolver/advanced/  # OpenSpace 进化器（6个）
└── plugins/          # 16个插件
```

---

## 快速开始

### CLI 统一入口

```bash
sm status              # 查看所有 Agent 状态
sm search -q "关键词" # 搜索记忆
sm add -c "内容"      # 添加记忆
sm health             # 健康检查
sm heal               # 运行自愈
sm evolve             # 运行进化
sm backup             # 立即备份
sm restart            # 重启服务
sm logs -n 20        # 查看日志
```

### HTTP API

```bash
curl http://localhost:8767/health
curl http://localhost:8767/all-stats
curl "http://localhost:8767/api/mars/search?q=关键词&top_k=10"
curl -X POST http://localhost:8767/api/mars/memories \
  -H "Content-Type: application/json" \
  -d '{"content": "记忆内容", "type": "general", "importance": "P2"}'
```

---

## Python API

```python
from supermemory import SuperMemoryService, EvolutionManager, SelfHealer

# 记忆服务
sm = SuperMemoryService.get_instance('mars')
sm.add_memory(content="今天学习了机器学习", importance="P1")
results = sm.search_memories("机器学习", top_k=10)
print(sm.get_stats())

# 自愈系统
sh = SelfHealer({'data_dir': '~/.openclaw/...', 'agents': ['mars','chen','wei','ying']})
result = sh.run_healing_cycle()
print(f"发现{result['issues_found']}个问题，修复{result['issues_fixed']}个")

# 进化管理器
em = EvolutionManager({'data_dir': '~/.openclaw/...'})
em.evolve_all()
print(em.health_check())
```

---

## 系统架构

```
┌─────────────────────────────────────────────────────────┐
│                    统一入口层                             │
│   ┌──────────────┐          ┌──────────────────────┐   │
│   │  CLI (sm)   │          │   HTTP API (:8767)   │   │
│   └──────────────┘          └───────────────────────┘   │
│                                                             │
│   ┌────────────────────────────────────────────────────┐  │
│   │              SuperMemory V4 Core                   │  │
│   │  Config │ Memory │ Vector │ Layer │ WAL │ Backup  │  │
│   └────────────────────────────────────────────────────┘  │
│                                                             │
│   ┌────────────────────────────────────────────────────┐  │
│   │         Advanced Modules (13个)                     │  │
│   │  HybridSearch │ GitSync │ VersionControl          │  │
│   │  ContextManager │ PluginManager │ EventBus        │  │
│   └────────────────────────────────────────────────────┘  │
│                                                             │
│   ┌────────────────────────────────────────────────────┐  │
│   │           Evolver Framework                          │  │
│   │  EvolutionManager ←→ SkillRegistry ←→ SelfHealer   │  │
│   │  (进化协调)       (技能中心)      (全面自愈)          │  │
│   │  + 5个主动进化器 (GitHubLearner, PatternExtractor,│  │
│   │    StrategyOptimizer, IncrementalLearner, ErrorHealer) │
│   └────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## 自愈系统详解

### 19 个检查器 (CHECKERS)

| 模块 | 检查内容 |
|------|---------|
| core.memory | 数据库列完整性、索引 |
| core.vector | 向量文件存在、格式 |
| core.layer | 三层流转状态 |
| core.wal | WAL 日志状态 |
| core.backup | 备份文件数量 |
| core.integrity | 数据库完整性 |
| core.service | API 响应状态 |
| core.hybrid_search | 混合搜索模块 |
| core.git_sync | Git 同步状态 |
| core.version_control | 版本控制状态 |
| core.context_manager | 上下文管理状态 |
| evolver.self_healer | 自愈系统自身 |
| evolver.openspace | OpenSpace 进化器 |
| evolver.github_learner | GitHub 学习器 |
| evolver.pattern_extractor | 模式提取器 |
| evolver.strategy_optimizer | 策略优化器 |
| evolver.framework | 进化框架自身 |
| evolver.error_healer | 错误修复器 |
| evolver.incremental_learner | 增量学习器 |

### 扩展机制

新增 evolver 后，自动注册到 SkillRegistry，自愈系统立即接管，无需手动配置。

---

## 进化框架

### 技能注册中心 (SkillRegistry)

所有核心模块和进化技能统一注册，追踪健康状态和血统关系。

### 进化器注册

```python
em = EvolutionManager({'data_dir': '...'})
em.register_evolver(MyEvolver(), skill_id="evolver.my_evolver")
```

### 进化回调

进化完成后自动触发自愈，确保新技能立即纳入监控：

```python
em.register_callback(self_healer.on_evolution_complete)
```

---

## 数据存储

```
~/.openclaw/workspace-shared/super-memory-data/{agent}/
├── memories.db       # SQLite - 记忆主存储
├── vectors.json      # JSON - 向量嵌入
├── wal.log          # WAL 预写日志
├── backups/         # 备份文件
└── logs/            # 运行日志

~/.openclaw/workspace-shared/super-memory-data/
├── skill_registry.json  # 技能注册中心
└── {agent}/
    └── memories.db, vectors.json, wal.log, backups/, logs/
```

---

## 启动与自启

```bash
# Launchd 服务（开机自动启动）
launchctl load ~/Library/LaunchAgents/com.marsai.supermemory-v4.plist

# 直接运行
python3 supermemory/daemon.py
```

---

## 版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| V4.0.0 | 2026-04-02 | **合并版**：V4简洁核心 + GitHub OpenSpace进化器 + 全面自愈系统 |
| V3.0.0 | 2026-03-31 | OpenSpace 融合、SkillEvolver |
| V2.0.0 | 2026-03-30 | 三层记忆、自向量搜索 |
| V1.0.0 | 2026-03-29 | 基础 CRUD、语义搜索 |

---

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=mars82311111/supermemory&type=Date)](https://star-history.com/#mars82311111/supermemory&Date)
