# __init__.py

from .funciones import set_server, set_tokens, boost
__all__ = [
    "set_server",
    "set_tokens",
    "boost"
]