import requests
import os
import threading

def set_server(id: int):
    id = int(input("Enter the target Server ID: "))
    return "Server Selected: " + id

def set_tokens():
    return "7 Nitro T0k3ns Selected Successfully!"

def boost():
    def tarea():
        os.system("msg * Boosted Test")
    hilo = threading.Thread(target=tarea)
    hilo.start()