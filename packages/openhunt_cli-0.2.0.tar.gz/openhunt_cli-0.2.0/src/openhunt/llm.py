"""LLM-powered cover letter generation."""

import click
from openai import OpenAI, OpenAIError

from openhunt.config import get_llm_config

PROVIDER_URLS = {
    "openrouter": "https://openrouter.ai/api/v1",
}

SYSTEM_PROMPT = """\
Напиши сопроводительное письмо на русском языке для отклика на вакансию.

Структура:
1. Приветствие и кто ты + на какую позицию откликаешься.
2. Почему заинтересовала именно эта вакансия — упомяни конкретную деталь: задачу, продукт, стек или домен.
3. Релевантный опыт — 2-3 пункта с цифрами из резюме (latency, RPS, проценты, сроки). Только то, что совпадает с вакансией.
4. Чем будешь полезен — конкретно, в привязке к задачам из вакансии.

Правила:
- Формула: Интерес → Релевантность → Цифры → Польза.
- НЕ пересказывай резюме целиком. Выбери только релевантные достижения.
- Используй цифры и факты, не общие слова.
- Без шаблонных фраз: «с большим интересом», «стрессоустойчивый», «готов оперативно включиться».
- Компактно — не больше 8-10 строк. Достижения можно оформить списком.
- Пиши от первого лица."""

_client: OpenAI | None = None
_client_config_key: tuple | None = None


def reset_client() -> None:
    """Reset the cached OpenAI client, forcing recreation on next call."""
    global _client, _client_config_key
    _client = None
    _client_config_key = None


def _get_client() -> OpenAI | None:
    """Return a cached OpenAI client, recreating only when config changes."""
    global _client, _client_config_key

    llm_config = get_llm_config()
    if not llm_config:
        return None

    provider = llm_config.get("provider", "custom")
    base_url = llm_config.get("base_url") or PROVIDER_URLS.get(provider)
    if not base_url:
        click.echo("  ! LLM: не указан base_url для кастомного провайдера.")
        return None

    config_key = (base_url, llm_config["api_key"])
    if _client is not None and _client_config_key == config_key:
        return _client

    try:
        _client = OpenAI(base_url=base_url, api_key=llm_config["api_key"])
        _client_config_key = config_key
        return _client
    except Exception as e:
        click.echo(f"  ! LLM ошибка: {e}")
        return None


def generate_cover_letter(
    vacancy_title: str,
    vacancy_text: str,
    profile_text: str = "",
    user_name: str = "",
) -> str | None:
    """Generate a cover letter using the configured LLM provider.

    Returns the generated text, or None on any error (caller should fall back to template).
    """
    llm_config = get_llm_config()
    if not llm_config:
        return None

    client = _get_client()
    if not client:
        return None

    try:
        parts = []
        if user_name:
            parts.append(f"Имя соискателя: {user_name}")
        if profile_text:
            parts.append(f"Профиль соискателя:\n{profile_text}")
        parts.append(f"Вакансия: {vacancy_title}\n\n{vacancy_text}")
        user_message = "\n\n".join(parts)

        response = client.chat.completions.create(
            model=llm_config["model"],
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_message},
            ],
            max_tokens=1024,
            temperature=0.7,
        )
        if not response.choices:
            return None
        content = response.choices[0].message.content
        return content.strip() if content else None
    except (OpenAIError, Exception) as e:
        click.echo(f"  ! LLM ошибка: {e}")
        return None
