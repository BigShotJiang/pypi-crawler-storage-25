============
Overview
============

What is PyCF?
=============

PyCF (Python Crystal Field) is a sophisticated package for crystal field calculations
on rare-earth ions. It combines density-functional-theory computations with experimental
fitting to model and understand the electronic structure of rare-earth systems.

Crystal Field Theory Basics
============================

Crystal field theory describes how the electric potential created by surrounding charges
(ligands, counter-ions, etc.) perturbs the electronic states of a central ion. For rare-earth ions,
this typically results in:

- **Spin-orbit coupling**: Splits states into J-manifolds
- **Crystal field splitting**: Further splits J-manifold into (2J+1)/2 doublets for even J
- **Level ordering**: Depends on ion, ligand geometry, and crystal structure

Core Concepts
=============

Hamiltonian
-----------

The total electronic Hamiltonian for a rare-earth ion includes:

1. **Free-ion Hamiltonian**: H₀ (Coulomb repulsion, spin-orbit coupling)
2. **Crystal field Hamiltonian**: H_CF (electron-ligand interactions)
3. **Magnetic field coupling**: H_mag (for external field experiments)

The crystal field is typically expanded as::

    H_CF = Σ B^k_q O^k_q

where B^k_q are crystal field parameters and O^k_q are tensor operators.

Tensors
-------

PyCF represents crystal field operators as **tensors** - sparse matrices in the
eigenbasis of the free-ion Hamiltonian. Common tensors include:

- **CF**: Crystal field tensor
- **MAG** (MAGX, MAGY, MAGZ): Magnetic moment tensors
- **HYP**: Hyperfine coupling tensor

Experimental Data
-----------------

PyCF handles experimental data through the **ExData** class, supporting modes:

- **'A'**: Absorption (level population weighted by oscillator strength)
- **'D'**: Emission/Fluorescence
- **'AS'**: Absorption spin-selective
- **'DS'**: Emission spin-selective

Architecture
=============

PyCF is structured in layers:

.. image::

    User Code (Examples, Custom Scripts)
         |
         v
    Python API (pycf/*.py)
         |
         +-- Crystal Field Module: cfl (Hamiltonian, Tensor, ExData)
         +-- Intensity Calculations: inten, paramcalc
         +-- Data Import: import_sljm
         +-- Utilities: spinh, pyemp, cfl_util
         |
         v
    Cython Bridge (pycf/cfl.pyx)
         |
         v
    Performance-Critical C Library (cfl/src/*.c)
         |
         v
    BLAS/LAPACK (System or Intel MKL)

Module Organization
====================

**Core Modules**

- **cfl**: Hamiltonian, Tensor, and ExData classes
- **import_sljm**: Load tensor data from SLJM/EMP output
- **inten**: Calculate transition intensities and spectra
- **paramcalc**: Crystal field parameters and intensity coefficients

**Utility Modules**

- **spinh**: Extract spin-Hamiltonian from crystal field
- **pyemp**: Wrapper around EMP program suite
- **cfl_util**: Formatting and result summary utilities
- **njsymbols**: Wigner symbols (3j, 6j, 9j)
- **matel**: Matrix element calculations

**C Library (cfl/)**

- **cfl_h.c**: Hamiltonian construction and diagonalization
- **cfl_tensor.c**: Tensor storage and arithmetic
- **cfl_opt.c**: Optimization and fitting
- **cfl_zefoz.c**: ZEFOZ deconvolution

Typical Workflow
================

1. **Load data**: Import tensors from SLJM output
2. **Build Hamiltonian**: Add tensor terms with parameters
3. **Diagonalize**: Compute eigenvalues and eigenvectors
4. **Transform tensors**: Project to eigenbasis
5. **Calculate intensities**: Compute transition strengths
6. **Compare with experiment**: Fit to experimental spectra
7. **Extract physics**: Spin-Hamiltonian, g-factors, etc.

Performance Characteristics
============================

- **Matrix operations**: 10-100x faster in C vs pure Python
- **Diagonalization**: O(N³) via LAPACK (N = basis dimension)
- **Fitting**: Nelder-Mead or user-provided optimizer
- **Memory**: ~100 KB per moderate-sized crystal field problem

Optimization is available through environment variables:

- ``CFL_CC``: C compiler (gcc, icc)
- ``CFL_CFLAGS``: Compiler flags
- ``CFL_LDLIBS``: BLAS/LAPACK libraries
- ``INTEL_PATH``: Path to Intel MKL installation

See see `ENVIRONMENT.md <../ENVIRONMENT.md>`__ for details.

Supported Platforms
====================

- **Linux**: Debian, Ubuntu, RHEL, Fedora
- **macOS**: Intel and Apple Silicon (ARM64)
- **WSL2**: Windows Subsystem for Linux
- **HPC clusters**: Tested with MKL and system LAPACK

Language Support
================

- **Primary**: Python 3.8+
- **Performance layer**: C99
- **Glue layer**: Cython 3.0+
- **Type hints**: Full Python 3.8+ compatibility

History and References
======================

PyCF builds on decades of crystal field theory:

- **Theory**: Wybourne (1965), Newman & Ng (1989)
- **SLJM/EMP**: Michael F. Reid's EMP suite (1990s-2000s)
- **Implementation**: Sebastian Horvath's C library (2010s)
- **Python wrapper**: Recent modernization with Cython and type hints

Key academic references are listed in the main documentation index.
