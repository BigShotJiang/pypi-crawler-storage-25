# fork EVA ICS v4 Python macros controller service
* Unlike the original version, here the scripts are stored at the specified path '<script-path>/{full_id}.py'.
