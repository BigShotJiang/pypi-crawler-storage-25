__version__ = '0.1.11'

import setuptools

with open('README.md', 'r') as fh:
    long_description = fh.read()

setuptools.setup(
    name='softkip-controller-py',
    version=__version__,
    author='Andrei Losev',
    author_email='loseu.andrei.g@gmail.com',
    description='fork EVA ICS v4 Python macros controller service',
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=setuptools.find_packages(),
    license='Apache License 2.0',
    install_requires=['busrt>=0.1.0', 'evaics>=0.2.9', 'timeouter>=0.0.15'],
    classifiers=('Programming Language :: Python :: 3',
                 'License :: OSI Approved :: MIT License',
                 'Topic :: Communications'),
    scripts=['bin/softkip-svc-controller-py'])
