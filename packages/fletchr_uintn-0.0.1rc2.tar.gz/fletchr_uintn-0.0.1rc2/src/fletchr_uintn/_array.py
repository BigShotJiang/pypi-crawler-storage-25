from __future__ import annotations

from typing import Iterable, Optional

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc

from fletchr_uintn._type import UIntNType, _storage_for_bits

_NP_DTYPES = {8: np.uint8, 16: np.uint16, 32: np.uint32, 64: np.uint64}
_CONTAINER_WIDTH = {np.uint8: 8, np.uint16: 16, np.uint32: 32, np.uint64: 64}


def _np_dtype_for_bits(bits: int):
    if bits <= 8:
        return np.uint8
    if bits <= 16:
        return np.uint16
    if bits <= 32:
        return np.uint32
    return np.uint64


def _container_width(dtype) -> int:
    return _CONTAINER_WIDTH[np.dtype(dtype).type]


def _mask_value(bits: int, dtype) -> np.generic:
    # (1 << bits) - 1 always fits in the storage dtype since storage is the
    # smallest container that holds N bits (so bits <= container_width).
    return np.dtype(dtype).type((1 << bits) - 1)


def _apply_mask(values: np.ndarray, bits: int) -> np.ndarray:
    cw = _container_width(values.dtype)
    if bits == cw:
        return values
    return values & _mask_value(bits, values.dtype)


def _split(arr: pa.Array):
    """Return `(values: np.ndarray, valid_mask: np.ndarray | None)`.

    `valid_mask` is None when there are no nulls; otherwise a bool array
    where True marks valid (non-null) positions. Null positions in
    `values` are filled with 0 so they are safe to operate on.
    """
    if arr.null_count == 0:
        return arr.to_numpy(zero_copy_only=False), None
    filled = pc.fill_null(arr, 0)
    valid_mask = arr.is_valid().to_numpy(zero_copy_only=False)
    return filled.to_numpy(zero_copy_only=False), valid_mask


def _rebuild(values: np.ndarray, valid_mask, bits: int) -> UIntNArray:
    """Wrap `values` into a `UIntNArray`, re-masking padding bits and reapplying nulls.

    `valid_mask` follows the convention **True = valid** (the inverse of pyarrow's
    `pa.array(mask=...)` parameter, which expects True = null). Pass `None` to
    indicate no nulls. Mixing the two conventions silently swaps which positions
    are null — handle with care at every call site.
    """
    dtype = _np_dtype_for_bits(bits)
    values = values.astype(dtype, copy=False)
    values = _apply_mask(values, bits)
    storage_type = _storage_for_bits(bits)
    if valid_mask is None:
        storage = pa.array(values, type=storage_type)
    else:
        storage = pa.array(values, type=storage_type, mask=~valid_mask)
    return pa.ExtensionArray.from_storage(UIntNType(bits), storage)


class UIntNArray(pa.ExtensionArray):
    """A 1-D PyArrow extension array of unsigned integers with arbitrary
    fixed bit width `N` in `[1, 64]`.

    Storage is the smallest native `uintN` container that fits `N`
    bits; padding bits above `N` are kept zero after every construction
    and operation. All operations return new arrays — instances are
    immutable.

    Construction is normally done via `uintn_array`, which dispatches
    over the various accepted input types. The classmethods on this class
    (`from_pylist`, `from_numpy`, `from_dict`) are also available when
    the input type is known statically.

    Notes:
        `from_storage(typ, storage)` is inherited from
        `pyarrow.ExtensionArray` and follows pyarrow's convention: it is
        a trusted, zero-validation wrapper. For validated construction
        from any input — including raw storage arrays — use
        `uintn_array`.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_pylist(cls, values: Iterable[Optional[int]], bits: int) -> UIntNArray:
        """Build a `UIntNArray` from a Python iterable of `int | None`.

        Args:
            values: Values to store. `None` produces a null in that
                position. Python `bool` is accepted and coerced to
                `0` / `1`.
            bits: Bit width `N`. Must satisfy `1 <= bits <= 64`.

        Returns:
            A new array of length `len(values)` and the given `bits`.

        Raises:
            ValueError: If `bits` is outside `[1, 64]`.
            OverflowError: If any value is outside `[0, 2**bits - 1]`.
            TypeError: If any element is not `int`, `bool`, or `None`.
        """
        UIntNType(bits)  # validates bits
        mask_val = (1 << bits) - 1
        py_vals = []
        null_mask = []
        for v in values:
            if v is None:
                py_vals.append(0)
                null_mask.append(True)
            elif isinstance(v, bool):
                py_vals.append(int(v))
                null_mask.append(False)
            elif isinstance(v, (int, np.integer)):
                iv = int(v)
                if iv < 0 or iv > mask_val:
                    raise OverflowError(f"value {iv} out of range for bits={bits}")
                py_vals.append(iv)
                null_mask.append(False)
            else:
                raise TypeError(f"expected int or None, got {type(v).__name__}: {v!r}")
        dtype = _np_dtype_for_bits(bits)
        arr = np.array(py_vals, dtype=dtype) if py_vals else np.empty(0, dtype=dtype)
        nm = np.array(null_mask, dtype=bool) if null_mask else np.empty(0, dtype=bool)
        valid = (~nm) if nm.any() else None
        return _rebuild(arr, valid, bits)

    @classmethod
    def from_numpy(
        cls,
        arr: np.ndarray,
        bits: int,
        mask: Optional[np.ndarray] = None,
    ) -> UIntNArray:
        """Build a `UIntNArray` from a 1-D integer NumPy array.

        Non-native byte order is coerced to native little-endian. Values
        are range-checked against `[0, 2**bits - 1]`.

        Args:
            arr: 1-D array of any integer dtype (signed or unsigned, any
                byte order). Signed input is rejected if it contains
                negative values.
            bits: Bit width `N`. Must satisfy `1 <= bits <= 64`.
            mask: Optional boolean array of the same length as `arr`.
                `True` marks a position as null in the resulting array.

        Returns:
            A new array of length `len(arr)` and the given `bits`.

        Raises:
            TypeError: If `arr` is not a NumPy ndarray of integer dtype.
            ValueError: If `bits` is outside `[1, 64]`, if `arr` is not
                1-D, or if `mask.shape` does not match `arr.shape`.
            OverflowError: If any value is outside `[0, 2**bits - 1]`.
        """
        UIntNType(bits)
        if not isinstance(arr, np.ndarray):
            raise TypeError(f"expected np.ndarray, got {type(arr).__name__}")
        if arr.ndim != 1:
            raise ValueError(f"expected 1-D array, got ndim={arr.ndim}")
        if not np.issubdtype(arr.dtype, np.integer):
            raise TypeError(f"expected integer dtype, got {arr.dtype}")
        # Coerce non-native byte order to native.
        if arr.dtype.byteorder not in ("=", "|"):
            arr = arr.astype(arr.dtype.newbyteorder("="))
        mask_val = (1 << bits) - 1
        if np.issubdtype(arr.dtype, np.signedinteger) and arr.size and (arr < 0).any():
            raise OverflowError("negative values not allowed for unsigned uintN")
        # Compare in a wide unsigned dtype to avoid overflow surprises.
        if arr.size and (arr.astype(np.uint64, casting="unsafe") > np.uint64(mask_val)).any():
            raise OverflowError(f"values exceed 2^{bits} - 1")
        target_dtype = _np_dtype_for_bits(bits)
        storage_vals = arr.astype(target_dtype, casting="unsafe")
        valid_mask = None
        if mask is not None:
            mask = np.asarray(mask, dtype=bool)
            if mask.shape != storage_vals.shape:
                raise ValueError("mask shape must match values shape")
            valid_mask = ~mask
        return _rebuild(storage_vals, valid_mask, bits)

    @classmethod
    def from_dict(cls, data: dict) -> UIntNArray:
        """Build a `UIntNArray` from a JSON-friendly dict.

        Inverse of `to_dict`.

        Args:
            data: A mapping containing `"bits"` (int) and `"values"`
                (list of `int | None`).

        Returns:
            A new array.

        Raises:
            TypeError: If `data` is not a dict.
            ValueError: If required keys are missing.
            OverflowError: If any value is outside `[0, 2**bits - 1]`.
        """
        if not isinstance(data, dict):
            raise TypeError(f"expected dict, got {type(data).__name__}")
        if "bits" not in data or "values" not in data:
            raise ValueError("dict must contain 'bits' and 'values' keys")
        return cls.from_pylist(data["values"], int(data["bits"]))

    # ------------------------------------------------------------------
    # Basic properties
    # ------------------------------------------------------------------

    @property
    def bits(self) -> int:
        """The bit width `N` of this array's values."""
        return self.type.bits

    @property
    def mask(self) -> int:
        """The value mask `2**N - 1` for this array's bit width."""
        return (1 << self.bits) - 1

    def __repr__(self) -> str:
        # Reuse pyarrow's body formatting (head + tail with literal "...")
        # so we stay consistent with how every other pa.Array prints.
        _, _, body = repr(self.storage).partition("\n")
        return f"<UIntNArray bits={self.bits} object at 0x{id(self):x}>\n{body}"

    # ------------------------------------------------------------------
    # Indexing
    # ------------------------------------------------------------------

    def __getitem__(self, key):
        """Index or slice the array.

        Args:
            key: One of:

                - `int` (or numpy integer) — returns a Python `int` (or
                  `None` for null positions). Negative indices are
                  supported.
                - `slice` — returns a `UIntNArray`.
                - Boolean array (ndarray, list, `pa.Array`) — filter;
                  returns a `UIntNArray`.
                - Integer array (ndarray, list, `pa.Array`) — take;
                  returns a `UIntNArray`.

        Returns:
            An `int`, `None`, or `UIntNArray` depending on `key`.

        Raises:
            IndexError: If `key` is an integer outside `[-len, len)`.
            TypeError: If `key` is a Python `bool` (ambiguous) or any
                other unsupported type.
        """
        if isinstance(key, bool):
            raise TypeError("bool index is ambiguous; use a slice or array")
        if isinstance(key, (int, np.integer)):
            n = len(self)
            idx = int(key)
            if idx < 0:
                idx += n
            if idx < 0 or idx >= n:
                raise IndexError(int(key))
            scalar = self.storage[idx]
            return scalar.as_py()
        if isinstance(key, slice):
            return pa.ExtensionArray.from_storage(self.type, self.storage[key])
        indexer = key
        if isinstance(indexer, (list, tuple)):
            indexer = np.asarray(indexer)
        if isinstance(indexer, np.ndarray):
            if indexer.dtype == bool:
                pa_idx = pa.array(indexer)
                new_storage = self.storage.filter(pa_idx)
            elif np.issubdtype(indexer.dtype, np.integer):
                pa_idx = pa.array(indexer)
                new_storage = self.storage.take(pa_idx)
            else:
                raise TypeError(f"unsupported index dtype: {indexer.dtype}")
            return pa.ExtensionArray.from_storage(self.type, new_storage)
        if isinstance(indexer, (pa.Array, pa.ChunkedArray)):
            if pa.types.is_boolean(indexer.type):
                new_storage = self.storage.filter(indexer)
            elif pa.types.is_integer(indexer.type):
                new_storage = self.storage.take(indexer)
            else:
                raise TypeError(f"unsupported pa index type: {indexer.type}")
            return pa.ExtensionArray.from_storage(self.type, new_storage)
        raise TypeError(f"unsupported index type: {type(key).__name__}")

    # ------------------------------------------------------------------
    # Equality / hashing
    # ------------------------------------------------------------------

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, UIntNArray):
            return NotImplemented
        return self.type == other.type and self.storage.equals(other.storage)

    def __ne__(self, other: object) -> bool:
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    # Setting __hash__ = None makes the array unhashable, mirroring pa.Array
    # and numpy.ndarray. mypy can't statically model this idiom.
    __hash__ = None  # type: ignore[assignment]

    def equals(self, other) -> bool:
        """Test whole-array equality.

        Args:
            other: Compared as equal iff `other` is a `UIntNArray` with
                the same `bits`, same length, same values, and same
                null mask.

        Returns:
            `True` on whole-array equality, otherwise `False`.
        """
        return self.__eq__(other) is True

    # ------------------------------------------------------------------
    # Unary ops
    # ------------------------------------------------------------------

    def bit_wise_not(self) -> UIntNArray:
        """Element-wise bitwise NOT, re-masked to `N` bits.

        Equivalent to `~self`. Nulls are preserved.

        Returns:
            A new array of the same `bits` and length.
        """
        values, valid_mask = _split(self.storage)
        result = np.bitwise_not(values)
        return _rebuild(result, valid_mask, self.bits)

    def __invert__(self) -> UIntNArray:
        return self.bit_wise_not()

    def bit_wise_reverse(self) -> UIntNArray:
        """Reverse the order of the `N` significant bits within each value.

        For `N=5` and value `0b00011`, the result is `0b11000`.
        Padding bits remain zero. Nulls are preserved.

        Returns:
            A new array of the same `bits` and length.
        """
        values, valid_mask = _split(self.storage)
        bits = self.bits
        if len(values) == 0:
            return _rebuild(values, valid_mask, bits)
        # Build (M, N) MSB-first bit matrix; flip on axis 1; collapse back.
        shifts = np.arange(bits - 1, -1, -1, dtype=values.dtype)
        bit_matrix = (values[:, None] >> shifts[None, :]) & values.dtype.type(1)
        reversed_bits = bit_matrix[:, ::-1]
        out_shifts = np.arange(bits - 1, -1, -1, dtype=values.dtype)
        result = (reversed_bits.astype(values.dtype) << out_shifts[None, :]).sum(
            axis=1, dtype=values.dtype
        )
        return _rebuild(result, valid_mask, bits)

    def bit_wise_count(self) -> UIntNArray:
        """Element-wise population count (`popcount`) of the `N` significant bits.

        Padding bits (above `N`) are masked off before counting, so the
        result lies in `[0, N]`. Nulls are preserved.

        Returns:
            A new array of the same `bits` and length, holding the
            per-element bit counts.
        """
        values, valid_mask = _split(self.storage)
        masked = _apply_mask(values, self.bits)
        counts = np.bitwise_count(masked)
        return _rebuild(counts.astype(values.dtype, copy=False), valid_mask, self.bits)

    # ------------------------------------------------------------------
    # Binary ops
    # ------------------------------------------------------------------

    def _binary_prep(self, other) -> tuple:
        """Prepare LHS/RHS arrays and combined valid-mask for a binary bitwise op.

        Returns `(lhs_values, rhs_values_or_scalar, valid_mask)`. Validates
        that `other` is an int in range or a same-`bits`, same-length
        `UIntNArray`. Null masks from both operands are AND-combined
        (`valid_mask` follows the True-is-valid convention used by
        `_rebuild`).
        """
        if isinstance(other, UIntNArray):
            if other.bits != self.bits:
                raise ValueError(f"bits mismatch: {self.bits} vs {other.bits}")
            if len(other) != len(self):
                raise ValueError(f"length mismatch: {len(self)} vs {len(other)}")
            lvals, lvalid = _split(self.storage)
            rvals, rvalid = _split(other.storage)
            if lvalid is None and rvalid is None:
                valid = None
            elif lvalid is None:
                valid = rvalid
            elif rvalid is None:
                valid = lvalid
            else:
                valid = lvalid & rvalid
            return lvals, rvals, valid
        if isinstance(other, (bool, int, np.integer)):
            other_int = int(other)
        else:
            raise TypeError(f"unsupported RHS type for bitwise op: {type(other).__name__}")
        if other_int < 0 or other_int > self.mask:
            raise OverflowError(f"scalar {other_int} out of range for bits={self.bits}")
        lvals, lvalid = _split(self.storage)
        rvals = lvals.dtype.type(other_int)
        return lvals, rvals, lvalid

    def bit_wise_and(self, other) -> UIntNArray:
        """Element-wise bitwise AND.

        Equivalent to `self & other`. Null positions in either operand
        produce a null in the result.

        Args:
            other: One of:

                - `int` — scalar AND broadcast over the array. Must lie
                  in `[0, 2**bits - 1]`.
                - `UIntNArray` — element-wise. Must have the same `bits`
                  and the same length.

        Returns:
            A new array of the same `bits` and length.

        Raises:
            TypeError: If `other` is neither an integer nor a `UIntNArray`.
            ValueError: If `other` is a `UIntNArray` with a different
                `bits` or different length.
            OverflowError: If `other` is a scalar outside
                `[0, 2**bits - 1]`.
        """
        lhs, rhs, valid = self._binary_prep(other)
        return _rebuild(lhs & rhs, valid, self.bits)

    def bit_wise_or(self, other) -> UIntNArray:
        """Element-wise bitwise OR.

        Equivalent to `self | other`. See `bit_wise_and` for the
        parameter contract; semantics are identical except for the operation.

        Args:
            other: An `int` or `UIntNArray`.

        Returns:
            A new array of the same `bits` and length.
        """
        lhs, rhs, valid = self._binary_prep(other)
        return _rebuild(lhs | rhs, valid, self.bits)

    def bit_wise_xor(self, other) -> UIntNArray:
        """Element-wise bitwise XOR.

        Equivalent to `self ^ other`. See `bit_wise_and` for the
        parameter contract; semantics are identical except for the operation.

        Args:
            other: An `int` or `UIntNArray`.

        Returns:
            A new array of the same `bits` and length.
        """
        lhs, rhs, valid = self._binary_prep(other)
        return _rebuild(lhs ^ rhs, valid, self.bits)

    def __and__(self, other):
        return self.bit_wise_and(other)

    def __or__(self, other):
        return self.bit_wise_or(other)

    def __xor__(self, other):
        return self.bit_wise_xor(other)

    def __rand__(self, other):
        return self.bit_wise_and(other)

    def __ror__(self, other):
        return self.bit_wise_or(other)

    def __rxor__(self, other):
        return self.bit_wise_xor(other)

    # ------------------------------------------------------------------
    # Shifts
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_shift(n) -> int:
        if isinstance(n, bool) or not isinstance(n, (int, np.integer)):
            raise TypeError(f"shift amount must be int, got {type(n).__name__}")
        n = int(n)
        if n < 0:
            raise ValueError("shift amount must be non-negative")
        return n

    def shift_left(self, n: int) -> UIntNArray:
        """Logical left shift by `n` bit positions.

        Bits shifted out the top are discarded; padding bits above `N`
        are re-masked to zero. Nulls are preserved.

        Args:
            n: Non-negative shift amount. If `n >= self.bits`, the result
                is all zeros (with nulls preserved).

        Returns:
            A new array of the same `bits` and length.

        Raises:
            TypeError: If `n` is not an integer.
            ValueError: If `n` is negative.
        """
        n = self._validate_shift(n)
        values, valid_mask = _split(self.storage)
        if n >= self.bits or len(values) == 0:
            result = np.zeros_like(values)
        else:
            # Promote to uint64 for shifting to avoid C-undefined-behavior on
            # shifts equal to the dtype width; then mask and cast back.
            wide = values.astype(np.uint64, copy=False) << np.uint64(n)
            result = (wide & np.uint64(self.mask)).astype(values.dtype)
        return _rebuild(result, valid_mask, self.bits)

    def shift_right(self, n: int) -> UIntNArray:
        """Logical right shift by `n` bit positions.

        Since the array is unsigned, shifted-in bits are zero. Nulls are
        preserved.

        Args:
            n: Non-negative shift amount. If `n >= self.bits`, the result
                is all zeros (with nulls preserved).

        Returns:
            A new array of the same `bits` and length.

        Raises:
            TypeError: If `n` is not an integer.
            ValueError: If `n` is negative.
        """
        n = self._validate_shift(n)
        values, valid_mask = _split(self.storage)
        if n >= self.bits or len(values) == 0:
            result = np.zeros_like(values)
        else:
            result = (values >> np.array(n, dtype=values.dtype)).astype(values.dtype)
        return _rebuild(result, valid_mask, self.bits)

    # ------------------------------------------------------------------
    # Sequence: append / extend
    # ------------------------------------------------------------------

    def append(self, value) -> UIntNArray:
        """Return a new array with `value` appended.

        The original array is not modified.

        Args:
            value: Value to append. `None` appends a null.

        Returns:
            A new array of length `len(self) + 1`.

        Raises:
            TypeError: If `value` is not `int`, `bool`, or `None`.
            OverflowError: If `value` is outside `[0, 2**bits - 1]`.
        """
        return self.extend([value])

    def extend(self, values: Iterable) -> UIntNArray:
        """Return a new array with `values` appended.

        The original array is not modified.

        Args:
            values: Iterable of `int | None`. `None` appends a null in
                that position.

        Returns:
            A new array of length `len(self) + len(values)`.

        Raises:
            TypeError: If any element is not `int`, `bool`, or `None`.
            OverflowError: If any value is outside `[0, 2**bits - 1]`.
        """
        new_arr = UIntNArray.from_pylist(list(values), self.bits)
        combined = pa.concat_arrays([self.storage, new_arr.storage])
        return pa.ExtensionArray.from_storage(self.type, combined)

    # ------------------------------------------------------------------
    # Bit packing
    # ------------------------------------------------------------------

    def unpack_bits(self) -> pa.FixedSizeListArray:
        """Expand each value into its `N` constituent bits, MSB-first.

        For `bits=4` and value `0b1011`, the corresponding inner list
        is `[1, 0, 1, 1]` (index `0` is the most significant bit).
        Nulls propagate: a null value yields a null inner list.

        Inverse of `pack_bits`.

        Returns:
            A `FixedSizeList<uint8>[N]` with one inner list per value.
        """
        bits = self.bits
        values, valid_mask = _split(self.storage)
        n = len(values)
        if n == 0:
            child = pa.array(np.empty(0, dtype=np.uint8), type=pa.uint8())
            return pa.FixedSizeListArray.from_arrays(child, bits)
        shifts = np.arange(bits - 1, -1, -1, dtype=values.dtype)
        bit_matrix = ((values[:, None] >> shifts[None, :]) & values.dtype.type(1)).astype(np.uint8)
        child = pa.array(bit_matrix.reshape(-1), type=pa.uint8())
        result = pa.FixedSizeListArray.from_arrays(child, bits)
        if valid_mask is not None:
            # FixedSizeListArray has a single buffer (the validity bitmap);
            # the data lives in the child array.
            null_buf = pa.py_buffer(np.packbits(valid_mask, bitorder="little").tobytes())
            list_type = pa.list_(pa.uint8(), bits)
            result = pa.Array.from_buffers(
                list_type,
                length=n,
                buffers=[null_buf],
                null_count=int((~valid_mask).sum()),
                offset=0,
                children=[child],
            )
        return result

    # ------------------------------------------------------------------
    # Reductions
    # ------------------------------------------------------------------

    def sum(self) -> Optional[int]:
        """Sum of all non-null values.

        Returns:
            The sum, or `None` if every value is null.
        """
        r = pc.sum(self.storage)
        v = r.as_py()
        return int(v) if v is not None else None

    def max(self) -> Optional[int]:
        """Maximum of all non-null values.

        Returns:
            The maximum, or `None` if every value is null.
        """
        r = pc.max(self.storage)
        v = r.as_py()
        return int(v) if v is not None else None

    def min(self) -> Optional[int]:
        """Minimum of all non-null values.

        Returns:
            The minimum, or `None` if every value is null.
        """
        r = pc.min(self.storage)
        v = r.as_py()
        return int(v) if v is not None else None

    def any(self) -> Optional[bool]:
        """Test whether any non-null value is non-zero.

        Returns:
            `True` if at least one non-null value is non-zero,
            `False` if all non-null values are zero,
            `None` if the array is empty or contains only nulls.
        """
        ne = pc.not_equal(self.storage, 0)
        r = pc.any(ne)
        v = r.as_py()
        return bool(v) if v is not None else None

    def all(self) -> Optional[bool]:
        """Test whether every non-null value is non-zero.

        Returns:
            `True` if every non-null value is non-zero,
            `False` if at least one non-null value is zero,
            `None` if the array is empty or contains only nulls.
        """
        ne = pc.not_equal(self.storage, 0)
        r = pc.all(ne)
        v = r.as_py()
        return bool(v) if v is not None else None

    # ------------------------------------------------------------------
    # Conversions
    # ------------------------------------------------------------------

    def to_numpy(self, zero_copy_only: bool = False) -> np.ndarray:
        """Return values as a NumPy array.

        When the array has no nulls (and is a single chunk), a zero-copy
        view of the storage buffer is returned. With nulls, a copy is made.

        Args:
            zero_copy_only: If `True`, raise instead of copying when
                zero-copy is not possible (e.g. when nulls are present).

        Returns:
            A 1-D array of the storage dtype.

        Raises:
            pa.ArrowInvalid: If `zero_copy_only=True` and the array has
                nulls.
        """
        if self.storage.null_count == 0:
            try:
                return self.storage.to_numpy(zero_copy_only=True)
            except (pa.ArrowInvalid, ValueError):
                pass
        return self.storage.to_numpy(zero_copy_only=zero_copy_only)

    def to_pylist(self) -> list:
        """Return values as a Python list.

        Returns:
            One element per array slot; `None` for null positions.
        """
        return self.storage.to_pylist()

    def to_dict(self) -> dict:
        """Return a JSON-friendly dict representation.

        Inverse of `from_dict`.

        Returns:
            A mapping with keys `"bits"` (int) and `"values"` (list of
            `int | None`).
        """
        return {"bits": self.bits, "values": self.to_pylist()}


def pack_bits(values, bits: int) -> UIntNArray:
    """Inverse of `UIntNArray.unpack_bits` — collapse bit rows into `UIntN` values.

    Bit order is MSB-first: index `0` of each inner list is the most
    significant bit of the resulting integer.

    Args:
        values: One of:

            - `pa.FixedSizeListArray` with `uint8` child and
              `list_size == bits`. Slice offsets are respected. Nulls
              on the parent list propagate.
            - 2-D `numpy.ndarray` of shape `(M, bits)`. Any integer
              dtype is accepted; values must be `0` or `1`.
        bits: Bit width `N`. Must satisfy `1 <= bits <= 64` and match
            the inner width of `values`.

    Returns:
        A new array of length `M` and the given `bits`.

    Raises:
        TypeError: If `values` is not a supported type, or the
            FixedSizeList child type is not `uint8`.
        ValueError: If the inner width of `values` does not match
            `bits`, or any element of `values` is not `0` / `1`.
    """
    UIntNType(bits)
    if isinstance(values, pa.FixedSizeListArray):
        if values.type.list_size != bits:
            raise ValueError(f"FixedSizeList width {values.type.list_size} != bits {bits}")
        if not pa.types.is_uint8(values.type.value_type):
            raise TypeError("FixedSizeList child must be uint8")
        valid_mask = None
        if values.null_count > 0:
            valid_mask = values.is_valid().to_numpy(zero_copy_only=False)
        # ``flatten`` respects the parent offset/length; ``.values`` does
        # not and would silently include neighbours when ``values`` is a
        # slice of a larger FSL.
        child = values.flatten().to_numpy(zero_copy_only=False)
        if (child > 1).any():
            raise ValueError("pack_bits input must be 0 or 1")
        matrix = child.reshape(-1, bits)
    elif isinstance(values, np.ndarray):
        if values.ndim != 2:
            raise ValueError(f"expected 2-D array, got ndim={values.ndim}")
        if values.shape[1] != bits:
            raise ValueError(f"second dim {values.shape[1]} != bits {bits}")
        if values.dtype != np.uint8:
            values = values.astype(np.uint8, casting="unsafe")
        if values.size and (values > 1).any():
            raise ValueError("pack_bits input must be 0 or 1")
        matrix = values
        valid_mask = None
    else:
        raise TypeError(f"expected FixedSizeListArray or 2-D ndarray, got {type(values).__name__}")
    dtype = _np_dtype_for_bits(bits)
    out_shifts = np.arange(bits - 1, -1, -1, dtype=dtype)
    out = (matrix.astype(dtype) << out_shifts[None, :]).sum(axis=1, dtype=dtype)
    return _rebuild(out, valid_mask, bits)
