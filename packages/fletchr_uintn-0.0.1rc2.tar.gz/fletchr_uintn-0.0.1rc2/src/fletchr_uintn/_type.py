from __future__ import annotations

import json

import numpy as np
import pyarrow as pa

EXTENSION_NAME = "fletchr.uintn"


def _validate_bits(bits) -> int:
    """Validate and coerce `bits`; raise `TypeError` / `ValueError` on bad input."""
    if isinstance(bits, bool) or not isinstance(bits, (int, np.integer)):
        raise TypeError(f"bits must be int, got {type(bits).__name__}")
    b = int(bits)
    if b < 1 or b > 64:
        raise ValueError(f"bits must be in [1, 64], got {b}")
    return b


def _storage_for_bits(bits: int) -> pa.DataType:
    """Return the smallest `pa.uint*` storage type that fits `bits` bits."""
    b = _validate_bits(bits)
    if b <= 8:
        return pa.uint8()
    if b <= 16:
        return pa.uint16()
    if b <= 32:
        return pa.uint32()
    return pa.uint64()


class UIntNType(pa.ExtensionType):
    """Extension type for unsigned integers of arbitrary fixed bit width `N`.

    The storage type is the smallest of `uint8` / `uint16` / `uint32` /
    `uint64` that fits `N` bits. Two instances are equal iff their
    `bits` are equal; the value `bits` rides the extension metadata so
    arrays round-trip losslessly through Arrow IPC and Parquet.

    Args:
        bits: The bit width `N`. Must satisfy `1 <= bits <= 64`.

    Raises:
        TypeError: If `bits` is not an integer.
        ValueError: If `bits` is outside `[1, 64]`.
    """

    def __init__(self, bits) -> None:
        self._bits = _validate_bits(bits)
        super().__init__(_storage_for_bits(self._bits), EXTENSION_NAME)

    @property
    def bits(self) -> int:
        """The bit width `N` of values in this type."""
        return self._bits

    @property
    def mask(self) -> int:
        """The value mask `2**N - 1` for this bit width."""
        return (1 << self._bits) - 1

    def __arrow_ext_serialize__(self) -> bytes:
        return json.dumps({"bits": self._bits}).encode("utf-8")

    @classmethod
    def __arrow_ext_deserialize__(cls, storage_type: pa.DataType, serialized: bytes) -> UIntNType:
        meta = json.loads(serialized.decode("utf-8"))
        bits = int(meta["bits"])
        instance = cls(bits)
        if instance.storage_type != storage_type:
            raise ValueError(
                f"storage type mismatch on deserialize: expected {instance.storage_type}, got {storage_type}"
            )
        return instance

    def __arrow_ext_class__(self):
        from fletchr_uintn._array import UIntNArray

        return UIntNArray

    def __eq__(self, other: object) -> bool:
        return isinstance(other, UIntNType) and other._bits == self._bits

    def __ne__(self, other: object) -> bool:
        # pa.ExtensionType is a Cython class whose __ne__ does not derive from
        # our Python-level __eq__; define both explicitly.
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash((EXTENSION_NAME, self._bits))

    def __repr__(self) -> str:
        return f"UIntNType(bits={self._bits})"
