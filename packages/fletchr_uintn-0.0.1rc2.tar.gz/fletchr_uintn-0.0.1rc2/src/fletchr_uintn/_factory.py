from __future__ import annotations

from typing import Optional

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc

from fletchr_uintn._array import UIntNArray
from fletchr_uintn._type import UIntNType, _storage_for_bits


def _validate_raw_storage(arr: pa.Array, bits: int) -> pa.Array:
    """Range-check a raw integer `pa.Array` and return it unchanged.

    Caller is expected to have verified that `arr.type` matches the
    expected storage type for `bits`.
    """
    if len(arr) == 0:
        return arr
    if arr.null_count == len(arr):
        return arr
    source = pc.fill_null(arr, 0) if arr.null_count else arr
    np_view = source.to_numpy(zero_copy_only=False)
    if (np_view > (1 << bits) - 1).any():
        raise OverflowError(f"storage values exceed 2^{bits} - 1")
    return arr


def uintn_array(
    values,
    bits: int,
    *,
    mask: Optional[np.ndarray] = None,
) -> UIntNArray:
    """Construct a validated `UIntNArray` from a variety of inputs.

    This is the primary user-facing factory; it dispatches on the type
    of `values` and validates every input against the `[0, 2**bits - 1]`
    range.

    Args:
        values: The input data. Accepts:

            - A Python `list`, `tuple`, or other iterable of `int | None`.
              `bool` is accepted and coerced to `0` / `1`.
            - A 1-D `numpy.ndarray` of integer dtype (any byte order;
              non-native byte order is coerced to native LE).
            - A `pa.Array` or `pa.ChunkedArray` whose type is either a
              `UIntNType` with matching `bits`, or the raw `uint` storage
              type that `bits` maps to (`pa.uint8()` for `bits <= 8`, etc.).
              Raw storage is range-validated.
            - A JSON-friendly dict `{"bits": N, "values": [...]}`. The
              dict's `"bits"` must equal `bits`.
        bits: Bit width `N`. Must satisfy `1 <= bits <= 64`.
        mask: Optional boolean array marking null positions (`True` =
            null). Only valid when `values` is a `numpy.ndarray`; passing
            it with any other input type raises `TypeError`.

    Returns:
        A new array of length `len(values)` and the given `bits`.

    Raises:
        TypeError: If `values` is not a supported type, if `mask` is
            given for a non-ndarray input, or if a raw storage array
            has the wrong dtype.
        ValueError: If `bits` is outside `[1, 64]`, if an extension-typed
            input has a different `bits`, or if `mask.shape` does not
            match.
        OverflowError: If any value is outside `[0, 2**bits - 1]`.

    Examples:
        >>> from fletchr_uintn import uintn_array
        >>> uintn_array([0, 1, 2, 30, 31], bits=5).to_pylist()
        [0, 1, 2, 30, 31]
        >>> uintn_array([0, None, 31], bits=5).to_pylist()
        [0, None, 31]
    """
    UIntNType(bits)  # validate bits up front
    if isinstance(values, dict):
        if mask is not None:
            raise TypeError("mask is only valid with ndarray input")
        arr = UIntNArray.from_dict(values)
        if arr.bits != bits:
            raise ValueError(f"dict bits {arr.bits} does not match requested bits {bits}")
        return arr
    if isinstance(values, np.ndarray):
        return UIntNArray.from_numpy(values, bits, mask=mask)
    if isinstance(values, UIntNArray):
        if mask is not None:
            raise TypeError("mask is only valid with ndarray input")
        if values.bits != bits:
            raise ValueError(f"array bits {values.bits} does not match requested bits {bits}")
        return values
    if isinstance(values, pa.ChunkedArray):
        if mask is not None:
            raise TypeError("mask is only valid with ndarray input")
        if isinstance(values.type, UIntNType):
            if values.type.bits != bits:
                raise ValueError(
                    f"ChunkedArray bits {values.type.bits} does not match requested bits {bits}"
                )
            combined = values.combine_chunks()
            return pa.ExtensionArray.from_storage(combined.type, combined.storage)
        expected = _storage_for_bits(bits)
        if values.type != expected:
            raise TypeError(
                f"ChunkedArray must have UIntNType or {expected} storage for bits={bits}, got {values.type}"
            )
        combined = values.combine_chunks()
        _validate_raw_storage(combined, bits)
        return pa.ExtensionArray.from_storage(UIntNType(bits), combined)
    if isinstance(values, pa.Array):
        # A pa.Array of UIntNType is always a UIntNArray instance (pyarrow
        # constructs extension arrays via __arrow_ext_class__), so it was
        # already handled by the UIntNArray branch above. Here we only see
        # raw storage arrays.
        if mask is not None:
            raise TypeError("mask is only valid with ndarray input")
        expected = _storage_for_bits(bits)
        if values.type != expected:
            raise TypeError(
                f"pa.Array must have UIntNType or {expected} storage for bits={bits}, got {values.type}"
            )
        _validate_raw_storage(values, bits)
        return pa.ExtensionArray.from_storage(UIntNType(bits), values)
    if isinstance(values, (list, tuple)) or hasattr(values, "__iter__"):
        if mask is not None:
            raise TypeError("mask is only valid with ndarray input")
        return UIntNArray.from_pylist(list(values), bits)
    raise TypeError(f"unsupported values type: {type(values).__name__}")
