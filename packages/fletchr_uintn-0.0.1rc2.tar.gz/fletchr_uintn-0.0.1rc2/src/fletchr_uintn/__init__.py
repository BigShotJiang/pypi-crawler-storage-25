from __future__ import annotations

import contextlib

import pyarrow as pa

from fletchr_uintn._array import UIntNArray, pack_bits
from fletchr_uintn._factory import uintn_array
from fletchr_uintn._type import UIntNType

try:
    from fletchr_uintn._version import __version__
except ImportError:
    __version__ = "0.0.0"


def _register() -> None:
    # ArrowKeyError fires if the extension is already registered (re-import).
    with contextlib.suppress(pa.ArrowKeyError):
        pa.register_extension_type(UIntNType(1))


_register()


__all__ = [
    "UIntNArray",
    "UIntNType",
    "__version__",
    "pack_bits",
    "uintn_array",
]
