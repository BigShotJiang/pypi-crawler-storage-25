from __future__ import annotations

import io

import pyarrow as pa
import pyarrow.parquet as pq

from fletchr_uintn import UIntNType, uintn_array


def test_ipc_roundtrip(bits, tmp_path):
    mask = (1 << bits) - 1
    arr = uintn_array([0, 1, mask, None], bits=bits)
    table = pa.table({"x": arr})
    buf = io.BytesIO()
    with pa.ipc.new_stream(buf, table.schema) as writer:
        writer.write_table(table)
    buf.seek(0)
    with pa.ipc.open_stream(buf) as reader:
        table2 = reader.read_all()
    col = table2.column("x")
    assert isinstance(col.type, UIntNType)
    assert col.type.bits == bits
    assert col.combine_chunks().to_pylist() == [0, 1, mask, None]


def test_parquet_roundtrip(bits, tmp_path):
    mask = (1 << bits) - 1
    arr = uintn_array([0, 1, mask, None], bits=bits)
    table = pa.table({"x": arr})
    path = tmp_path / "x.parquet"
    pq.write_table(table, path)
    table2 = pq.read_table(path)
    col = table2.column("x")
    assert isinstance(col.type, UIntNType)
    assert col.type.bits == bits
    assert col.combine_chunks().to_pylist() == [0, 1, mask, None]
