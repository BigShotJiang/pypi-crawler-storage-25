from __future__ import annotations

import numpy as np
import pyarrow as pa
import pytest

from fletchr_uintn import UIntNArray, uintn_array


def test_from_pylist_basic(bits):
    mask = (1 << bits) - 1
    values = [0, 1, mask, mask // 2 if bits > 1 else 0]
    arr = uintn_array(values, bits=bits)
    assert isinstance(arr, UIntNArray)
    assert arr.bits == bits
    assert arr.to_pylist() == values


def test_from_pylist_with_nulls():
    arr = uintn_array([0, None, 5, None, 31], bits=5)
    assert arr.to_pylist() == [0, None, 5, None, 31]


def test_overflow_value_raises():
    with pytest.raises(OverflowError):
        uintn_array([0, 32], bits=5)


def test_negative_value_raises():
    with pytest.raises(OverflowError):
        uintn_array([-1, 0], bits=5)


def test_non_int_raises():
    with pytest.raises(TypeError):
        uintn_array([1.5, 2], bits=5)


def test_bool_accepted_as_int():
    arr = uintn_array([True, False, True], bits=3)
    assert arr.to_pylist() == [1, 0, 1]


def test_from_numpy_native(bits):
    mask = (1 << bits) - 1
    arr_in = np.array([0, mask], dtype=np.uint64)
    arr = uintn_array(arr_in, bits=bits)
    assert arr.to_pylist() == [0, mask]


def test_from_numpy_non_native_byteorder():
    arr_in = np.array([1, 2, 3], dtype=">u4")
    arr = uintn_array(arr_in, bits=10)
    assert arr.to_pylist() == [1, 2, 3]


def test_from_numpy_overflow():
    arr_in = np.array([0, 32], dtype=np.uint8)
    with pytest.raises(OverflowError):
        uintn_array(arr_in, bits=5)


def test_from_numpy_negative():
    arr_in = np.array([-1, 0], dtype=np.int8)
    with pytest.raises(OverflowError):
        uintn_array(arr_in, bits=5)


def test_from_numpy_with_mask():
    arr_in = np.array([1, 2, 3], dtype=np.uint8)
    mask = np.array([False, True, False])
    arr = uintn_array(arr_in, bits=5, mask=mask)
    assert arr.to_pylist() == [1, None, 3]


def test_from_dict_roundtrip():
    d = {"bits": 9, "values": [0, 1, 511, None]}
    arr = uintn_array(d, bits=9)
    assert arr.to_dict() == d


def test_from_dict_mismatched_bits():
    with pytest.raises(ValueError):
        uintn_array({"bits": 4, "values": [0, 1]}, bits=5)


def test_from_pa_array():
    src = uintn_array([1, 2, 3], bits=4)
    rebuilt = uintn_array(src, bits=4)
    assert rebuilt.equals(src)


def test_from_chunked_array():
    a = uintn_array([1, 2], bits=4)
    b = uintn_array([3, 4], bits=4)
    chunked = pa.chunked_array([a, b])
    arr = uintn_array(chunked, bits=4)
    assert arr.to_pylist() == [1, 2, 3, 4]


def test_from_raw_pa_storage():
    raw = pa.array([1, 2, 15], type=pa.uint8())
    arr = uintn_array(raw, bits=4)
    assert arr.to_pylist() == [1, 2, 15]
    assert arr.bits == 4


def test_from_raw_pa_storage_overflow():
    raw = pa.array([1, 2, 16], type=pa.uint8())  # 16 > 15 for bits=4
    with pytest.raises(OverflowError):
        uintn_array(raw, bits=4)


def test_from_raw_pa_storage_wrong_dtype():
    raw = pa.array([1, 2, 3], type=pa.uint16())  # bits=4 wants uint8
    with pytest.raises(TypeError):
        uintn_array(raw, bits=4)


def test_from_raw_pa_storage_with_nulls():
    raw = pa.array([1, None, 15], type=pa.uint8())
    arr = uintn_array(raw, bits=4)
    assert arr.to_pylist() == [1, None, 15]


def test_from_raw_chunked_storage():
    a = pa.array([1, 2], type=pa.uint8())
    b = pa.array([3, 15], type=pa.uint8())
    chunked = pa.chunked_array([a, b])
    arr = uintn_array(chunked, bits=4)
    assert arr.to_pylist() == [1, 2, 3, 15]


def test_from_raw_chunked_storage_overflow():
    a = pa.array([1, 2], type=pa.uint8())
    b = pa.array([3, 16], type=pa.uint8())
    chunked = pa.chunked_array([a, b])
    with pytest.raises(OverflowError):
        uintn_array(chunked, bits=4)


def test_pa_array_extension_bits_mismatch():
    src = uintn_array([1, 2], bits=4)
    wrapped = pa.ExtensionArray.from_storage(src.type, src.storage)
    with pytest.raises(ValueError):
        uintn_array(wrapped, bits=5)


def test_chunked_extension_bits_mismatch():
    src = uintn_array([1, 2], bits=4)
    chunked = pa.chunked_array([src])
    with pytest.raises(ValueError):
        uintn_array(chunked, bits=5)


def test_raw_chunked_wrong_dtype():
    a = pa.array([1, 2], type=pa.uint16())  # bits=4 wants uint8
    chunked = pa.chunked_array([a])
    with pytest.raises(TypeError):
        uintn_array(chunked, bits=4)


def test_mask_with_non_ndarray_inputs_rejected():
    m = np.array([False, False])
    with pytest.raises(TypeError):
        uintn_array([1, 2], bits=4, mask=m)
    with pytest.raises(TypeError):
        uintn_array({"bits": 4, "values": [1, 2]}, bits=4, mask=m)
    src = uintn_array([1, 2], bits=4)
    with pytest.raises(TypeError):
        uintn_array(src, bits=4, mask=m)
    with pytest.raises(TypeError):
        uintn_array(pa.chunked_array([src]), bits=4, mask=m)


def test_factory_unsupported_type():
    with pytest.raises(TypeError):
        uintn_array(3.14, bits=4)


def test_raw_storage_empty_and_all_null():
    empty = pa.array([], type=pa.uint8())
    assert uintn_array(empty, bits=4).to_pylist() == []
    all_null = pa.array([None, None], type=pa.uint8())
    assert uintn_array(all_null, bits=4).to_pylist() == [None, None]


def test_invalid_bits():
    with pytest.raises(ValueError):
        uintn_array([1, 2], bits=0)
    with pytest.raises(ValueError):
        uintn_array([1, 2], bits=65)


def test_empty():
    arr = uintn_array([], bits=5)
    assert len(arr) == 0
    assert arr.to_pylist() == []
