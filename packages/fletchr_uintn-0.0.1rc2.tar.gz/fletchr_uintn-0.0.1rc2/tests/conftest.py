from __future__ import annotations

import pytest
from hypothesis import HealthCheck, settings

settings.register_profile(
    "default",
    deadline=None,
    suppress_health_check=[HealthCheck.too_slow],
    max_examples=100,
)
settings.load_profile("default")


BITS_BOUNDARY_VALUES = [1, 2, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64]


@pytest.fixture(params=BITS_BOUNDARY_VALUES)
def bits(request) -> int:
    return request.param
