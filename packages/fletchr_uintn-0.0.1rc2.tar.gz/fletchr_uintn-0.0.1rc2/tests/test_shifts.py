from __future__ import annotations

import pytest

from fletchr_uintn import uintn_array


def test_shift_left_basic():
    arr = uintn_array([1, 2, 3], bits=5)
    s = arr.shift_left(2)
    assert s.to_pylist() == [4, 8, 12]
    assert s.bits == 5


def test_shift_left_remasks_padding():
    # 0b11000 << 1 = 0b110000, masked to 5 bits = 0b10000 (16).
    arr = uintn_array([0b11000, 0b00001], bits=5)
    s = arr.shift_left(1)
    assert s.to_pylist() == [0b10000, 0b00010]
    # Storage padding bits must be zero.
    storage = s.storage.to_numpy(zero_copy_only=False)
    assert (storage < 32).all()


def test_shift_left_full_width():
    arr = uintn_array([1, 31], bits=5)
    s = arr.shift_left(5)
    assert s.to_pylist() == [0, 0]


def test_shift_left_over_width():
    arr = uintn_array([1, 31], bits=5)
    s = arr.shift_left(100)
    assert s.to_pylist() == [0, 0]


def test_shift_right_basic():
    arr = uintn_array([0b11000, 0b00010], bits=5)
    s = arr.shift_right(2)
    assert s.to_pylist() == [0b00110, 0b00000]


def test_shift_right_over_width():
    arr = uintn_array([31, 1], bits=5)
    assert arr.shift_right(100).to_pylist() == [0, 0]


def test_shifts_preserve_nulls():
    arr = uintn_array([1, None, 3], bits=5)
    assert arr.shift_left(1).to_pylist() == [2, None, 6]
    assert arr.shift_right(1).to_pylist() == [0, None, 1]


def test_negative_shift_raises():
    arr = uintn_array([1, 2], bits=5)
    with pytest.raises(ValueError):
        arr.shift_left(-1)
    with pytest.raises(ValueError):
        arr.shift_right(-1)


def test_non_int_shift_raises():
    arr = uintn_array([1, 2], bits=5)
    with pytest.raises(TypeError):
        arr.shift_left(1.5)


def test_shift_left_bits_64():
    arr = uintn_array([1, 2, 1 << 32], bits=64)
    s = arr.shift_left(31)
    assert s.to_pylist() == [1 << 31, 1 << 32, (1 << 63)]
