from __future__ import annotations

from fletchr_uintn import uintn_array


def test_bit_wise_reverse_n5():
    # 0b00011 → 0b11000
    arr = uintn_array([0b00011], bits=5)
    r = arr.bit_wise_reverse()
    assert r.to_pylist() == [0b11000]


def test_bit_wise_reverse_n3():
    # 0b101 → 0b101 (palindrome)
    # 0b110 → 0b011
    arr = uintn_array([0b101, 0b110, 0b000, 0b111], bits=3)
    r = arr.bit_wise_reverse()
    assert r.to_pylist() == [0b101, 0b011, 0b000, 0b111]


def test_double_reverse_is_identity(bits):
    mask = (1 << bits) - 1
    vals = [0, 1, mask, mask // 3 if bits > 2 else 1]
    arr = uintn_array(vals, bits=bits)
    assert arr.bit_wise_reverse().bit_wise_reverse().to_pylist() == vals


def test_bit_wise_reverse_padding_zero():
    arr = uintn_array([1, 31], bits=5)
    r = arr.bit_wise_reverse()
    storage = r.storage.to_numpy(zero_copy_only=False)
    assert (storage < 32).all()


def test_bit_wise_reverse_preserves_nulls():
    arr = uintn_array([0b001, None, 0b110], bits=3)
    r = arr.bit_wise_reverse()
    assert r.to_pylist() == [0b100, None, 0b011]
