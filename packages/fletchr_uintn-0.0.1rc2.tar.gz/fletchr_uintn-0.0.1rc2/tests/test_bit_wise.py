from __future__ import annotations

import pytest

from fletchr_uintn import uintn_array


def test_invert(bits):
    mask = (1 << bits) - 1
    arr = uintn_array([0, 1, mask], bits=bits)
    inv = ~arr
    assert inv.to_pylist() == [mask, mask ^ 1, 0]
    assert inv.bits == bits


def test_invert_preserves_nulls():
    arr = uintn_array([0, None, 5], bits=5)
    inv = ~arr
    assert inv.to_pylist() == [31, None, 26]


def test_and_or_xor_scalar(bits):
    mask = (1 << bits) - 1
    arr = uintn_array([0, 1, mask], bits=bits)
    assert (arr & 1).to_pylist() == [0, 1, 1]
    assert (arr | 1).to_pylist() == [1, 1, mask]
    assert (arr ^ mask).to_pylist() == [mask, mask ^ 1, 0]


def test_and_or_xor_array():
    a = uintn_array([0b1010, 0b1100, 0b0011], bits=4)
    b = uintn_array([0b0110, 0b1010, 0b1111], bits=4)
    assert a.bit_wise_and(b).to_pylist() == [0b0010, 0b1000, 0b0011]
    assert a.bit_wise_or(b).to_pylist() == [0b1110, 0b1110, 0b1111]
    assert a.bit_wise_xor(b).to_pylist() == [0b1100, 0b0110, 0b1100]


def test_binary_op_null_propagation():
    a = uintn_array([1, None, 3], bits=4)
    b = uintn_array([2, 2, None], bits=4)
    assert (a & b).to_pylist() == [0, None, None]


def test_bits_mismatch_raises():
    a = uintn_array([1], bits=4)
    b = uintn_array([1], bits=5)
    with pytest.raises(ValueError):
        a & b


def test_length_mismatch_raises():
    a = uintn_array([1, 2], bits=4)
    b = uintn_array([1, 2, 3], bits=4)
    with pytest.raises(ValueError):
        a | b


def test_scalar_out_of_range_raises():
    a = uintn_array([1], bits=4)
    with pytest.raises(OverflowError):
        a & 16


def test_scalar_negative_raises():
    a = uintn_array([1], bits=4)
    with pytest.raises(OverflowError):
        a & -1


def test_unsupported_rhs_raises():
    a = uintn_array([1], bits=4)
    with pytest.raises(TypeError):
        a & "x"


def test_bit_wise_count():
    arr = uintn_array([0, 1, 0b1011, 0b1111], bits=4)
    cnt = arr.bit_wise_count()
    assert cnt.to_pylist() == [0, 1, 3, 4]
    assert cnt.bits == 4


def test_rop_with_int():
    a = uintn_array([0b0011, 0b1100], bits=4)
    assert (0b1010 & a).to_pylist() == [0b0010, 0b1000]
    assert (0b1010 | a).to_pylist() == [0b1011, 0b1110]


def test_padding_zero_after_invert():
    # bits=5 on uint8 storage: max value 31; ~ all 0s should give 31, not 255.
    arr = uintn_array([0, 0, 0], bits=5)
    inv = ~arr
    storage = inv.storage.to_numpy(zero_copy_only=False)
    assert (storage < 32).all()
    assert inv.to_pylist() == [31, 31, 31]
