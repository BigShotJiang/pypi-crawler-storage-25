from __future__ import annotations

import pytest

from fletchr_uintn import uintn_array


def test_append_returns_new_array():
    arr = uintn_array([1, 2, 3], bits=4)
    new = arr.append(5)
    assert new.to_pylist() == [1, 2, 3, 5]
    # Original unchanged.
    assert arr.to_pylist() == [1, 2, 3]
    assert new.bits == 4


def test_extend_with_nulls():
    arr = uintn_array([1, 2], bits=4)
    new = arr.extend([3, None, 5])
    assert new.to_pylist() == [1, 2, 3, None, 5]


def test_append_overflow_raises():
    arr = uintn_array([1], bits=4)
    with pytest.raises(OverflowError):
        arr.append(16)


def test_append_non_int_raises():
    arr = uintn_array([1], bits=4)
    with pytest.raises(TypeError):
        arr.append("x")


def test_append_none():
    arr = uintn_array([1, 2], bits=4)
    new = arr.append(None)
    assert new.to_pylist() == [1, 2, None]
