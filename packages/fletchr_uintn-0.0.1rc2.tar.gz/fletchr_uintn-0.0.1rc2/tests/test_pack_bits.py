from __future__ import annotations

import numpy as np
import pyarrow as pa
import pytest

from fletchr_uintn import pack_bits, uintn_array


def test_unpack_bits_msb_first():
    # 0b1011 (= 11) with bits=4 → [1, 0, 1, 1] MSB-first.
    arr = uintn_array([0b1011], bits=4)
    fsl = arr.unpack_bits()
    assert isinstance(fsl, pa.FixedSizeListArray)
    assert fsl.type.list_size == 4
    assert fsl.values.to_pylist() == [1, 0, 1, 1]


def test_pack_bits_unpack_bits_roundtrip(bits):
    mask = (1 << bits) - 1
    values = [0, 1, mask, mask // 2 if bits > 1 else 0]
    arr = uintn_array(values, bits=bits)
    fsl = arr.unpack_bits()
    back = pack_bits(fsl, bits=bits)
    assert back.to_pylist() == values
    assert back.bits == bits


def test_pack_bits_from_ndarray():
    # MSB-first: [1,0,1,1] → 0b1011 = 11
    mat = np.array([[1, 0, 1, 1], [0, 0, 0, 1]], dtype=np.uint8)
    arr = pack_bits(mat, bits=4)
    assert arr.to_pylist() == [0b1011, 0b0001]


def test_unpack_bits_preserves_nulls():
    arr = uintn_array([0b101, None, 0b011], bits=3)
    fsl = arr.unpack_bits()
    assert fsl.null_count == 1
    assert fsl.is_null().to_pylist() == [False, True, False]


def test_pack_bits_invalid_bit_value():
    mat = np.array([[1, 2, 0, 0]], dtype=np.uint8)
    with pytest.raises(ValueError):
        pack_bits(mat, bits=4)


def test_pack_bits_wrong_inner_width():
    mat = np.array([[1, 0, 1]], dtype=np.uint8)
    with pytest.raises(ValueError):
        pack_bits(mat, bits=4)


def test_pack_bits_bad_type():
    with pytest.raises(TypeError):
        pack_bits([1, 0, 1], bits=3)


def test_unpack_bits_empty():
    arr = uintn_array([], bits=5)
    fsl = arr.unpack_bits()
    assert len(fsl) == 0
    assert fsl.type.list_size == 5


def test_pack_bits_on_sliced_fsl():
    arr = uintn_array([0b101, 0b011, 0b110, 0b001], bits=3)
    fsl = arr.unpack_bits()
    sliced = fsl.slice(1, 2)
    back = pack_bits(sliced, bits=3)
    assert back.to_pylist() == [0b011, 0b110]
