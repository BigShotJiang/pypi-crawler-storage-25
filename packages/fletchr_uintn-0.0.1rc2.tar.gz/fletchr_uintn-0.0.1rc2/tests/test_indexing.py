from __future__ import annotations

import numpy as np
import pytest

from fletchr_uintn import UIntNArray, uintn_array


def test_int_index_returns_python_int():
    arr = uintn_array([1, 5, 30, 31], bits=5)
    assert arr[0] == 1
    assert isinstance(arr[0], int)
    assert arr[-1] == 31


def test_int_index_null():
    arr = uintn_array([1, None, 3], bits=5)
    assert arr[1] is None


def test_int_index_out_of_range():
    arr = uintn_array([1, 2, 3], bits=4)
    with pytest.raises(IndexError):
        arr[5]


def test_slice_returns_array():
    arr = uintn_array([1, 2, 3, 4, 5], bits=4)
    s = arr[1:4]
    assert isinstance(s, UIntNArray)
    assert s.to_pylist() == [2, 3, 4]
    assert s.bits == 4


def test_bool_ndarray_mask():
    arr = uintn_array([1, 2, 3, 4, 5], bits=4)
    m = np.array([True, False, True, False, True])
    s = arr[m]
    assert isinstance(s, UIntNArray)
    assert s.to_pylist() == [1, 3, 5]


def test_int_ndarray_take():
    arr = uintn_array([10, 11, 12, 13], bits=5)
    idx = np.array([3, 0, 2])
    s = arr[idx]
    assert s.to_pylist() == [13, 10, 12]


def test_list_indexer_bool():
    arr = uintn_array([1, 2, 3], bits=4)
    s = arr[[True, False, True]]
    assert s.to_pylist() == [1, 3]


def test_list_indexer_int():
    arr = uintn_array([1, 2, 3], bits=4)
    s = arr[[2, 0]]
    assert s.to_pylist() == [3, 1]


def test_unsupported_index_type():
    arr = uintn_array([1, 2, 3], bits=4)
    with pytest.raises(TypeError):
        arr[{"x": 1}]
