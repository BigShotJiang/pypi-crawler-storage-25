from __future__ import annotations

from fletchr_uintn import uintn_array


def test_sum_max_min():
    arr = uintn_array([3, 7, 1, 5], bits=5)
    assert arr.sum() == 16
    assert arr.max() == 7
    assert arr.min() == 1


def test_sum_skips_nulls():
    arr = uintn_array([3, None, 5], bits=5)
    assert arr.sum() == 8
    assert arr.max() == 5
    assert arr.min() == 3


def test_all_nulls_reductions_return_none():
    arr = uintn_array([None, None], bits=5)
    assert arr.sum() is None or arr.sum() == 0
    assert arr.max() is None
    assert arr.min() is None


def test_any_all():
    assert uintn_array([0, 0, 1], bits=3).any() is True
    assert uintn_array([0, 0, 0], bits=3).any() is False
    assert uintn_array([1, 1, 1], bits=3).all() is True
    assert uintn_array([1, 0, 1], bits=3).all() is False


def test_empty_reductions():
    arr = uintn_array([], bits=5)
    # any/all on empty pa array: any = False, all = True per pa.compute conventions.
    assert arr.any() in (False, None)
    assert arr.all() in (True, None)
