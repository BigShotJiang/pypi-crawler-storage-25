from __future__ import annotations

import numpy as np

from fletchr_uintn import uintn_array


def test_to_numpy_no_nulls():
    arr = uintn_array([1, 2, 3], bits=5)
    out = arr.to_numpy()
    assert out.tolist() == [1, 2, 3]
    assert out.dtype == np.uint8


def test_to_numpy_with_nulls():
    arr = uintn_array([1, None, 3], bits=5)
    out = arr.to_numpy(zero_copy_only=False)
    # When nulls are present, output may be an object array or contain a sentinel.
    out_list = list(out)
    assert out_list[0] == 1
    assert out_list[2] == 3


def test_to_pylist_roundtrip(bits):
    mask = (1 << bits) - 1
    values = [0, 1, mask, None, mask // 2 if bits > 1 else 0]
    arr = uintn_array(values, bits=bits)
    assert arr.to_pylist() == values


def test_to_dict_roundtrip(bits):
    mask = (1 << bits) - 1
    values = [0, 1, mask, None]
    arr = uintn_array(values, bits=bits)
    d = arr.to_dict()
    assert d == {"bits": bits, "values": values}
    rebuilt = uintn_array(d, bits=bits)
    assert rebuilt.equals(arr)


def test_storage_dtype_selection():
    cases = {1: np.uint8, 8: np.uint8, 9: np.uint16, 16: np.uint16, 17: np.uint32, 33: np.uint64}
    for bits, expected in cases.items():
        arr = uintn_array([0], bits=bits)
        assert arr.to_numpy().dtype == expected


def test_repr_short():
    arr = uintn_array([1, 2, 3], bits=4)
    r = repr(arr)
    assert r.startswith("<UIntNArray bits=4 object at 0x")
    # All three values appear, no truncation marker.
    for v in ("1", "2", "3"):
        assert f"  {v}" in r
    assert "..." not in r


def test_repr_truncates_long_arrays():
    arr = uintn_array(list(range(50)), bits=8)
    r = repr(arr)
    # pyarrow style: head + literal "..." + tail.
    assert "..." in r
    # First and last values are present; middle values are elided.
    assert "  0," in r
    assert "  49" in r
    assert "  25," not in r
