from __future__ import annotations

from hypothesis import given
from hypothesis import strategies as st

from fletchr_uintn import pack_bits, uintn_array


@st.composite
def uintn_inputs(draw, max_len: int = 20):
    bits = draw(st.sampled_from([1, 2, 3, 5, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64]))
    mask = (1 << bits) - 1
    n = draw(st.integers(min_value=0, max_value=max_len))
    values = draw(st.lists(st.integers(min_value=0, max_value=mask), min_size=n, max_size=n))
    return bits, values


@given(uintn_inputs())
def test_and_idempotent(data):
    bits, values = data
    arr = uintn_array(values, bits=bits)
    assert (arr & arr).to_pylist() == values


@given(uintn_inputs())
def test_or_idempotent(data):
    bits, values = data
    arr = uintn_array(values, bits=bits)
    assert (arr | arr).to_pylist() == values


@given(uintn_inputs())
def test_xor_self_zero(data):
    bits, values = data
    arr = uintn_array(values, bits=bits)
    assert (arr ^ arr).to_pylist() == [0] * len(values)


@given(uintn_inputs())
def test_double_invert_identity(data):
    bits, values = data
    arr = uintn_array(values, bits=bits)
    assert (~~arr).to_pylist() == values


@given(uintn_inputs())
def test_double_bit_wise_reverse_identity(data):
    bits, values = data
    arr = uintn_array(values, bits=bits)
    assert arr.bit_wise_reverse().bit_wise_reverse().to_pylist() == values


@given(uintn_inputs())
def test_pack_bits_unpack_bits_roundtrip(data):
    bits, values = data
    arr = uintn_array(values, bits=bits)
    back = pack_bits(arr.unpack_bits(), bits=bits)
    assert back.to_pylist() == values


@given(uintn_inputs(), st.integers(min_value=0, max_value=70))
def test_shift_left_padding_zero(data, n):
    bits, values = data
    arr = uintn_array(values, bits=bits)
    shifted = arr.shift_left(n)
    out = shifted.to_pylist()
    mask = (1 << bits) - 1
    for v in out:
        assert 0 <= v <= mask


@given(uintn_inputs())
def test_op_results_within_range(data):
    bits, values = data
    if not values:
        return
    mask = (1 << bits) - 1
    arr = uintn_array(values, bits=bits)
    for result in [
        ~arr,
        arr & arr,
        arr | arr,
        arr ^ arr,
        arr.bit_wise_reverse(),
        arr.bit_wise_count(),
    ]:
        for v in result.to_pylist():
            assert 0 <= v <= mask
