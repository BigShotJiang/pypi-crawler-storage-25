from __future__ import annotations

import pyarrow as pa
import pytest

from fletchr_uintn import UIntNType


def test_storage_type_mapping():
    cases = {
        1: pa.uint8(),
        8: pa.uint8(),
        9: pa.uint16(),
        16: pa.uint16(),
        17: pa.uint32(),
        32: pa.uint32(),
        33: pa.uint64(),
        64: pa.uint64(),
    }
    for bits, expected in cases.items():
        assert UIntNType(bits).storage_type == expected


@pytest.mark.parametrize("bad", [0, -1, 65, 100])
def test_invalid_bits_raises_value_error(bad):
    with pytest.raises(ValueError):
        UIntNType(bad)


@pytest.mark.parametrize("bad", [1.5, "8", None, [8]])
def test_non_int_bits_raises(bad):
    with pytest.raises(TypeError):
        UIntNType(bad)


def test_equality_and_hash():
    assert UIntNType(7) == UIntNType(7)
    assert UIntNType(7) != UIntNType(8)
    assert hash(UIntNType(7)) == hash(UIntNType(7))
    s = {UIntNType(1), UIntNType(1), UIntNType(2)}
    assert len(s) == 2


def test_repr_contains_bits():
    assert "bits=5" in repr(UIntNType(5))


def test_extension_name():
    assert UIntNType(8).extension_name == "fletchr.uintn"


def test_register_is_idempotent():
    # The extension type is auto-registered on import; calling _register a
    # second time must swallow ArrowKeyError without re-raising.
    from fletchr_uintn import _register

    _register()
    _register()
