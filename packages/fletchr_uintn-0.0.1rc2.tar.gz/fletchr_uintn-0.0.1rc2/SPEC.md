# `fletchr.uintn` extension type — wire format specification

This document specifies the on-disk and on-wire representation of the
`fletchr.uintn` Apache Arrow extension type, so that Arrow readers in
languages other than Python (Java, C++, Go, R, JavaScript, ...) can implement
compatible deserializers.

This is a **community extension type**, not a canonical Arrow extension. It
follows the structural conventions of Arrow's canonical extension types — see
the Apache Arrow [Columnar Format specification, "Extension types"][arrow-ext]
for the underlying mechanism — but is published and maintained outside the
Arrow project.

[arrow-ext]: https://arrow.apache.org/docs/format/Columnar.html#extension-types

## Extension name

```
fletchr.uintn
```

This is the string that appears under the `ARROW:extension:name` field
metadata key on any column using this type. Readers identify the extension by
exact-match on this string.

## Extension parameters

The type has one parameter:

| Name   | Type | Range          | Description                                  |
|--------|------|----------------|----------------------------------------------|
| `bits` | int  | `1 <= N <= 64` | Bit width of the unsigned integer values.    |

## Storage type

Given `bits = N`, the storage type is the smallest unsigned integer type that
fits `N` bits:

| `bits` range      | Storage type |
|-------------------|--------------|
| `1 <= N <= 8`     | `uint8`      |
| `9 <= N <= 16`    | `uint16`     |
| `17 <= N <= 32`   | `uint32`     |
| `33 <= N <= 64`   | `uint64`     |

A reader MUST verify that the on-disk storage type matches this rule given the
deserialized `bits`. If not (for example `bits=5` paired with `uint16`
storage), the reader MUST reject the column as malformed.

## Extension metadata

The `ARROW:extension:metadata` value is a UTF-8-encoded JSON object conforming
to the following JSON Schema:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://example.com/fletchr/uintn/v1.json",
  "type": "object",
  "required": ["bits"],
  "properties": {
    "bits": {
      "type": "integer",
      "minimum": 1,
      "maximum": 64
    }
  },
  "additionalProperties": false
}
```

Producers MUST emit the metadata as a single-line object with no trailing
newline. Readers SHOULD however be tolerant of insignificant whitespace.

Readers MUST reject metadata that omits `"bits"` or contains a value outside
`[1, 64]`. For forward compatibility with future minor revisions, readers MAY
ignore unknown additional keys; this revision of the spec emits none.

## Description and semantics

A `UIntN` column represents a 1-D array of unsigned integers with a fixed bit
width `N` declared in the extension metadata. The bit width is type-level
(not per-array), so two columns with different `bits` are distinct types and
do not concatenate.

### Value invariant

For every non-null element value `v` in storage, the producer MUST guarantee:

```
0 <= v <= 2^N - 1
```

Equivalently: the high `(container_width - N)` bits of every container MUST be
zero. A reader MAY trust this invariant for performance, but a strict reader
SHOULD validate at read time and reject inputs where padding bits are
non-zero.

### Nulls

Nulls are represented exclusively in Arrow's standard validity bitmap on the
storage array. The extension type adds no null semantics of its own.

### Byte order

Storage is always native little-endian on every supported Arrow target.
Arrow's IPC and Parquet formats handle byte-order conversion at the protocol
layer; the UIntN extension introduces no additional byte-order
considerations.

## Examples

A column `x` containing the values `[0, 1, 31]` with `bits=5`, serialized
inside a Parquet file or Arrow IPC stream, appears in the schema as:

```
field "x":
    type: uint8                                    # storage type
    metadata:
        "ARROW:extension:name":     "fletchr.uintn"
        "ARROW:extension:metadata": "{\"bits\":5}"
```

The raw storage bytes for this column are `00 01 1F` (one `uint8` per
element). All padding bits (positions 5-7 of each byte) are zero.

## Versioning

This document describes revision **1.0** of `fletchr.uintn`. The revision
number is implicit in the extension name; if a backwards-incompatible change
is ever needed, the new revision will use a distinct extension name (for
example `fletchr.uintn_v2`) so that old readers fail loudly rather than
misinterpret new data.

Backwards-*compatible* changes (additional optional metadata keys) MAY be
made under the same name; readers MUST ignore unknown keys for this to remain
true.

## Reference implementations

* **Python** — this repository. See [`src/fletchr_uintn/_type.py`](src/fletchr_uintn/_type.py)
  for `UIntNType.__arrow_ext_serialize__` and `__arrow_ext_deserialize__`.

Implementations in other languages are welcome — please open an issue or PR
linking to your implementation.
