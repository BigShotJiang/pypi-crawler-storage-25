"""`jun wrapped` — the shareable daemon card. A portrait, legible to anyone."""

from datetime import date

from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text

from . import state as store
from .engine import world
from .engine.daemon import Daemon, render


def build_card() -> Panel:
    daemon = store.load_daemon() or Daemon.hatch()
    exped = world.expedition(date.today().isoformat(),
                             daemon.best_combo, daemon.name)

    art = Text(render(daemon), style="bold cyan", justify="center")
    stats = "\n".join([
        f"   [bold yellow]{daemon.name}[/]  ·  level [cyan]{daemon.level}[/]",
        "",
        f"   hunts          [cyan]{daemon.hunts}[/]",
        f"   best combo     [green]{daemon.best_combo}×[/]",
        f"   essence        [cyan]{int(daemon.essence)}[/]",
        f"   eyes / limbs   {daemon.eye_count} / {daemon.limb_count}",
        f"   gifts received [magenta]{daemon.gifts_received}[/]",
        "",
        f"   [dim]today · {exped.name}[/]",
        f"   ranked [bold]#{exped.your_rank}[/] of {exped.party_size:,} devs",
        "",
        "   [dim]raise your own:[/]  [bold green]uvx jun[/]",
    ])
    return Panel(
        Group(art, Text(""), Text.from_markup(stats)),
        title="[bold]⊹  jun — daemon card[/]",
        border_style="cyan", width=46, padding=(1, 2),
    )


def print_card() -> None:
    Console().print(build_card())
