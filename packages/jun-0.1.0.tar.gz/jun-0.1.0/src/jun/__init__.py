"""jun — a turn-based roguelike you play while your AI coding agent works."""

__version__ = "1.0.0"
