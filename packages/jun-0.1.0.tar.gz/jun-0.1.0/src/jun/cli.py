"""jun command-line entry point."""

import argparse
import sys

from . import __version__


def _cmd_play(_: argparse.Namespace) -> int:
    from .app import play
    play()
    return 0


def _cmd_init(_: argparse.Namespace) -> int:
    from . import hooks
    print(hooks.install())
    return 0


def _cmd_wrapped(_: argparse.Namespace) -> int:
    from .wrapped import print_card
    print_card()
    return 0


def _cmd_new(_: argparse.Namespace) -> int:
    from . import state as store
    store.clear_daemon()
    print("Daemon released. The next `jun` hatches a fresh one.")
    return 0


def _cmd_hook(args: argparse.Namespace) -> int:
    """Internal: invoked by the Claude Code hooks installed via `jun init`."""
    from . import hooks
    if args.event == "tool":
        hooks.record_tool()
    else:
        hooks.record_done()
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="jun",
        description="Raise a daemon that hunts while your AI agent works.",
    )
    parser.add_argument("--version", action="version", version=f"jun {__version__}")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("play", help="play jun (default)").set_defaults(func=_cmd_play)
    sub.add_parser("init", help="install Claude Code hooks") \
        .set_defaults(func=_cmd_init)
    sub.add_parser("wrapped", help="print the shareable daemon card") \
        .set_defaults(func=_cmd_wrapped)
    sub.add_parser("new", help="release your daemon and start fresh") \
        .set_defaults(func=_cmd_new)

    hook = sub.add_parser("_hook", help=argparse.SUPPRESS)
    hook.add_argument("event", choices=["tool", "done"])
    hook.set_defaults(func=_cmd_hook)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", _cmd_play)  # bare `jun` launches the game
    return func(args)


if __name__ == "__main__":
    sys.exit(main())
