"""The Textual app — jun's TUI.

Modes:
  * intro   — a 2-card first-run walkthrough (shown once).
  * den     — your daemon at rest: its portrait, its stats, the shared world.
  * hunt    — the live catch game, paced by your agent's real tool calls.
  * summary — what the hunt earned and how the daemon grew.
  * help    — controls and the loop, reachable any time with `?`.

jun is standalone — it never launches or wraps Claude Code. It learns the
agent's activity only from the hooks `jun init` installs.
"""

from __future__ import annotations

import random
import time
from datetime import date

from rich.align import Align
from rich.console import Group
from rich.panel import Panel
from rich.text import Text
from textual import events
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widgets import Footer, Static

from . import state as store
from .engine import evolutions, goals, world
from .engine.daemon import Daemon, render
from .engine.events import (
    CLASH,
    DONE,
    FOCUS,
    SCAN,
    STRIKE,
    FileEventSource,
    SimulatedEventSource,
)
from .engine.hunt import TRACK, Hunt

FRAME_TICK = 1 / 30
WATCH_TICK = 0.4
AUTOSAVE = 5.0

KIND_STYLE = {
    STRIKE: ("⚔", "red"),
    CLASH: ("✶", "yellow"),
    SCAN: ("◎", "cyan"),
    FOCUS: ("✸", "magenta"),
    DONE: ("⏹", "bright_black"),
}

INTRO_CARDS: list[tuple[str, str]] = [
    (
        "you have a daemon",
        "This is [bold cyan]jun[/].\n\n"
        "You've hatched a [cyan]daemon[/] — a creature that lives in your repo. "
        "It is shaped by how [bold]you[/] actually code, so no two are alike.\n\n"
        "It grows by [bold]hunting[/].",
    ),
    (
        "the hunt",
        "When your AI agent works, your daemon hunts: every tool call the agent "
        "makes flies in — press [bold]space[/] to [bold]catch[/] it in the green "
        "zone. Catches chain into a combo.\n\n"
        "No agent running right now? Press [bold]space[/] for a practice hunt.\n\n"
        "Other devs' daemons wander through your den while you're away. "
        "[bold]?[/] opens help. Go.",
    ),
]


class JunApp(App):
    TITLE = "jun"
    CSS = """
    Screen { background: $surface; }
    #screen { height: 1fr; padding: 1 2; }
    """

    BINDINGS = [
        Binding("space", "primary", "Hunt / Catch"),
        Binding("1", "choose(0)", show=False),
        Binding("2", "choose(1)", show=False),
        Binding("question_mark", "help", "Help"),
        Binding("escape", "escape", show=False),
        Binding("q", "quit_app", "Quit"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.daemon = Daemon.hatch()
        self.mode = "den"
        self.intro_step = 0
        self.event = ""
        self.visitors: list[world.Visitor] = []
        self.hunt: Hunt | None = None
        self.hunt_source = None
        self.hunt_is_live = False
        self.summary: dict | None = None
        self.pending_stage: int | None = None
        self._hunt_resolved = False
        self._frame_clock = time.monotonic()

    # --- setup -----------------------------------------------------------
    def compose(self) -> ComposeResult:
        yield Static(id="screen")
        yield Footer()

    def on_mount(self) -> None:
        self.daemon = store.load_daemon() or Daemon.hatch()
        self.daemon.roll_day(date.today().isoformat())
        self.file_source = FileEventSource(store.EVENTS_FILE)
        self._claim_visitors()
        self.mode = "den" if self.daemon.onboarded else "intro"
        self.pending_stage = evolutions.next_stage(self.daemon.level,
                                                   self.daemon.evolutions)
        if self.pending_stage and self.mode == "den":
            self.mode = "evolve"

        self.set_interval(FRAME_TICK, self._frame)
        self.set_interval(WATCH_TICK, self._watch)
        self.set_interval(AUTOSAVE, self._autosave)
        self._draw()

    def _claim_visitors(self) -> None:
        today = date.today().isoformat()
        self.visitors = world.visitors(f"{today}-{self.daemon.seed}")
        if self.daemon.last_visit_day != today:
            gift = sum(v.gift for v in self.visitors)
            self.daemon.essence += gift
            self.daemon.gifts_received += len(self.visitors)
            self.daemon.last_visit_day = today
            store.save_daemon(self.daemon)
            self.event = (f"{len(self.visitors)} daemons visited while you were "
                          f"away — +{gift} essence")
        else:
            self.event = "your den is quiet — send your daemon hunting"

    # --- background loops ------------------------------------------------
    def _frame(self) -> None:
        now = time.monotonic()
        dt = now - self._frame_clock
        self._frame_clock = now
        if self.mode != "hunt" or self.hunt is None:
            return
        for ev in self.hunt_source.poll(dt):
            self.hunt.add_event(ev)
        self.hunt.update(dt)
        if self.hunt.over and not self._hunt_resolved:
            self._finish_hunt()
        else:
            self._draw()

    def _watch(self) -> None:
        """In the den, watch for the real agent starting work."""
        if self.mode != "den":
            return
        new = self.file_source.poll(0.0)
        if new and any(e.kind != DONE for e in new):
            self.event = "your agent started working — hunt!"
            self._begin_hunt(self.file_source, live=True, initial=new)

    def _autosave(self) -> None:
        self.daemon.last_seen = time.time()
        store.save_daemon(self.daemon)

    # --- hunt lifecycle --------------------------------------------------
    def _begin_hunt(self, source, *, live: bool, initial=()) -> None:
        mods = evolutions.modifiers(self.daemon.evolutions)
        self.hunt = Hunt(seed=random.randint(0, 1 << 30), **mods)
        self.hunt_source = source
        self.hunt_is_live = live
        self._hunt_resolved = False
        for ev in initial:
            self.hunt.add_event(ev)
        self.mode = "hunt"
        self._frame_clock = time.monotonic()
        self._draw()

    def _finish_hunt(self) -> None:
        self._hunt_resolved = True
        result = self.hunt.result()
        if not self.hunt_is_live:
            # a training run — your daemon only records real agent work
            self.summary = {"result": result, "growth": [], "claimed": [],
                            "live": False}
            self.mode = "summary"
            self._draw()
            return
        before = (self.daemon.level, self.daemon.eye_count,
                  self.daemon.limb_count, self.daemon.armor)
        self.daemon.feed(result)
        after = (self.daemon.level, self.daemon.eye_count,
                 self.daemon.limb_count, self.daemon.armor)
        growth = []
        if after[0] > before[0]:
            growth.append(f"reached level {after[0]}")
        if after[1] > before[1]:
            growth.append("grew a new eye")
        if after[2] > before[2]:
            growth.append("grew a new limb")
        if after[3] > before[3]:
            growth.append("hardened its armor")

        claimed = []
        for obj in goals.todays_objectives(self.daemon.day):
            if obj.id not in self.daemon.claimed and goals.is_done(obj, self.daemon):
                self.daemon.claimed.append(obj.id)
                self.daemon.essence += obj.reward
                claimed.append(obj)
        for obj in claimed:
            self.notify(f"+{obj.reward} essence", title=f"objective: {obj.text}",
                        timeout=6)

        self.pending_stage = evolutions.next_stage(self.daemon.level,
                                                   self.daemon.evolutions)
        self.summary = {"result": result, "growth": growth, "claimed": claimed,
                        "live": True}
        store.save_daemon(self.daemon)
        self.mode = "summary"
        self._draw()

    # --- key actions -----------------------------------------------------
    def on_key(self, event: events.Key) -> None:
        """During the intro, any key advances — a player can never stall."""
        if self.mode != "intro" or event.key == "ctrl+c":
            return
        event.stop()
        event.prevent_default()
        if event.key == "escape":
            self._finish_intro()
            return
        self.intro_step += 1
        if self.intro_step >= len(INTRO_CARDS):
            self._finish_intro()
        else:
            self._draw()

    def _finish_intro(self) -> None:
        self.daemon.onboarded = True
        store.save_daemon(self.daemon)
        self.mode = "den"
        self._draw()

    def action_primary(self) -> None:
        if self.mode == "den":
            self.event = "practice hunt — catch the simulated agent's calls"
            self._begin_hunt(SimulatedEventSource(), live=False)
        elif self.mode == "hunt" and self.hunt:
            self.hunt.catch()
            self._draw()
        elif self.mode == "summary":
            self.summary = None
            self.mode = "evolve" if self.pending_stage else "den"
            self._draw()
        elif self.mode == "help":
            self.mode = "den"
            self._draw()

    def action_choose(self, index: int) -> None:
        """Pick an evolution fork (keys 1 / 2)."""
        if self.mode != "evolve" or self.pending_stage is None:
            return
        options = evolutions.offered(self.pending_stage)
        if index >= len(options):
            return
        chosen = options[index]
        self.daemon.evolutions.append(chosen.id)
        store.save_daemon(self.daemon)
        self.notify(chosen.blurb, title=f"evolved into {chosen.name}", timeout=8)
        self.pending_stage = evolutions.next_stage(self.daemon.level,
                                                   self.daemon.evolutions)
        self.mode = "evolve" if self.pending_stage else "den"
        self._draw()

    def action_escape(self) -> None:
        if self.mode == "hunt" and self.hunt and not self._hunt_resolved:
            self.hunt.over = True
            self._finish_hunt()
        elif self.mode in ("help", "summary"):
            self.summary = None
            self.mode = "evolve" if (self.mode == "summary"
                                     and self.pending_stage) else "den"
            self._draw()

    def action_help(self) -> None:
        if self.mode == "den":
            self.mode = "help"
            self._draw()
        elif self.mode == "help":
            self.mode = "den"
            self._draw()

    def action_quit_app(self) -> None:
        self.daemon.last_seen = time.time()
        store.save_daemon(self.daemon)
        self.exit()

    # --- rendering -------------------------------------------------------
    def _draw(self) -> None:
        renderer = {
            "intro": self._render_intro,
            "den": self._render_den,
            "hunt": self._render_hunt,
            "summary": self._render_summary,
            "evolve": self._render_evolve,
            "help": self._render_help,
        }[self.mode]
        self.query_one("#screen", Static).update(renderer())

    def _render_intro(self) -> Group:
        title, body = INTRO_CARDS[self.intro_step]
        n = len(INTRO_CARDS)
        panel = Panel(
            f"{body}\n\n"
            f"[dim]{'●' * (self.intro_step + 1)}{'○' * (n - self.intro_step - 1)}"
            f"   ·   press any key to continue   ·   esc to skip[/]",
            title=f"[bold cyan]⊹  {title}[/]",
            border_style="cyan", padding=(2, 4), width=66,
        )
        return Group("\n\n", Align.center(panel))

    def _render_den(self) -> Group:
        d = self.daemon
        evo_names = " · ".join(evolutions.EVOLUTION_BY_ID[e].name
                               for e in d.evolutions) or "unevolved"
        portrait = Panel(
            Text(render(d), style="bold cyan", justify="center"),
            title=f"[bold yellow]{d.name}[/]  [dim]level {d.level}[/]",
            subtitle=f"[magenta]{evo_names}[/]",
            border_style="cyan", padding=(1, 2),
        )

        stats = Panel(
            f"[dim]essence[/] [cyan]{int(d.essence)}[/]    "
            f"[dim]hunts[/] {d.hunts}    "
            f"[dim]best combo[/] [green]{d.best_combo}×[/]    "
            f"[dim]gifts[/] [magenta]{d.gifts_received}[/]\n"
            f"[dim]form[/]  {d.eye_count} eyes · {d.limb_count} limbs · "
            f"armor {d.armor} · aura {d.aura}",
            border_style="bright_black", padding=(0, 2),
        )

        day = date.today().isoformat()
        lines = ["[bold]daily objectives[/]"]
        for obj in goals.todays_objectives(day):
            prog = min(goals.progress(obj, d), obj.target)
            done = obj.id in d.claimed or goals.is_done(obj, d)
            mark = "[green]✓[/]" if done else "[dim]○[/]"
            reward = (f"[green]+{obj.reward}[/]" if done
                      else f"[magenta]+{obj.reward}[/]")
            lines.append(f"  {mark} {obj.text}  [dim]{prog}/{obj.target}[/]  "
                         f"{reward}")

        exped = world.expedition(day, d.best_combo, d.name)
        filled = round(18 * exped.progress / 100)
        bar = f"[cyan]{'█' * filled}[/][grey23]{'·' * (18 - filled)}[/]"
        lines.append("")
        lines.append(f"[bold]expedition · {exped.name}[/]")
        lines.append(f"  {bar} [bold]{exped.progress}%[/]")
        lines.append(f"  [dim]party of {exped.party_size:,} · "
                     f"you rank #{exped.your_rank}[/]")
        lines.append("")
        lines.append("[bold]daemons that visited[/]")
        for v in self.visitors[:2]:
            lines.append(f"  [cyan]{v.dev}[/] — [dim]{v.descriptor}[/]  "
                         f"[magenta]+{v.gift}[/]")
        net = Panel("\n".join(lines), title="the shared world",
                    border_style="bright_black", padding=(0, 2))

        if store.EVENTS_FILE.exists():
            lead = ("[bold green]▸ your daemon hunts when your agent works — "
                    "start a task[/]")
        else:
            lead = ("[bold yellow]▸ run `jun init` once to connect Claude Code, "
                    "then start a task[/]")
        guide = Panel(
            f"{lead}\n[dim]{self.event}  ·  SPACE to train  ·  ? for help[/]",
            title="what to do", border_style="green", padding=(0, 2),
        )
        return Group(Align.center(portrait), stats, net, guide)

    def _render_hunt(self) -> Group:
        h = self.hunt
        assert h is not None
        active = h.active

        cells = []
        for c in range(TRACK):
            if active and c == round(active.pos):
                cells.append("[bold yellow]◆[/]")
            elif active and active.in_zone(c):
                cells.append("[green]▰[/]")
            else:
                cells.append("[grey23]·[/]")
        bar = "".join(cells)

        if active:
            icon, color = KIND_STYLE[active.event.kind]
            prompt = f"[{color}]{icon}  {active.event.label}[/]"
        elif not h.over:
            prompt = "[dim]your daemon waits for the agent…[/]"
        else:
            prompt = "[dim]the hunt is ending…[/]"

        if h.surge_flash > 0:
            verdict = "[bold magenta]⚡  COMBO SURGE  ⚡[/]"
        elif h.flash > 0 and h.last_result:
            rc = {"PERFECT": "bold yellow", "CATCH": "bold green",
                  "MISS": "bold red"}[h.last_result]
            verdict = f"[{rc}]{h.last_result}[/]"
        else:
            verdict = "[dim]— press SPACE in the green —[/]"

        feed = "   ".join(
            f"[{KIND_STYLE[ev.kind][1]}]{KIND_STYLE[ev.kind][0]}[/]"
            for ev in h.feed[-9:]) or "[dim]—[/]"
        goal = (f"[green]✓ goal met · {h.goal_combo}× combo[/]" if h.goal_met
                else f"[dim]goal · reach a {h.goal_combo}× combo[/]")

        fcolor = ("green" if h.focus > 60 else
                  "yellow" if h.focus > 30 else "red")
        ff = round(22 * h.focus / 100)
        focus_bar = (f"[dim]focus[/]  [{fcolor}]{'█' * ff}[/]"
                     f"[grey23]{'·' * (22 - ff)}[/]  [{fcolor}]{int(h.focus)}%[/]")
        if h.focus <= 30:
            focus_bar += "   [bold red]⚠ failing[/]"

        inner = Group(
            Text.from_markup(
                f"[bold yellow]{h.combo}×[/] combo       "
                f"[green]+{int(h.essence)}[/] essence       "
                f"[dim]{h.caught} caught · {h.missed} missed[/]",
                justify="center"),
            Text.from_markup(focus_bar, justify="center"),
            Text(""),
            Text.from_markup(prompt, justify="center"),
            Text.from_markup(bar, justify="center"),
            Text.from_markup(verdict, justify="center"),
            Text(""),
            Text.from_markup(goal, justify="center"),
            Text.from_markup(f"[dim]agent stream[/]   {feed}", justify="center"),
        )
        badge = ("[bold red]● LIVE — your agent[/]" if self.hunt_is_live
                 else "[dim]○ training[/]")
        panel = Panel(inner, title=f"[bold]⊹  THE HUNT[/]   {badge}",
                      subtitle="[dim]space — catch      esc — end[/]",
                      border_style="red" if h.focus <= 30 else "yellow",
                      padding=(1, 3), width=70)
        return Group("\n", Align.center(panel))

    def _render_summary(self) -> Group:
        s = self.summary
        assert s is not None
        r = s["result"]
        live = s.get("live", True)
        if not live:
            grew = ("training run — nothing banked\n"
                    "your daemon grows only from real agent work")
        else:
            grew = ("\n".join(f"✦ your daemon {g}" for g in s["growth"])
                    or "your daemon held its form")
        goal_txt = ("[green]goal ✓[/]" if r.goal_met
                    else f"[dim]goal ✗ {r.goal_combo}×[/]")
        # Composed as renderables — the ASCII art must not be parsed as markup.
        parts = [
            Text.from_markup(
                f"[green]+{int(r.essence)}[/] essence       "
                f"[bold]{r.best_combo}×[/] best combo\n"
                f"[dim]{r.caught} caught · {r.missed} missed[/]   "
                f"[magenta]{r.surges} surges[/]   {goal_txt}",
                justify="center"),
            Text(""),
            Text(grew, style="bold green", justify="center"),
        ]
        claimed = s.get("claimed", [])
        if claimed:
            parts.append(Text(""))
            parts.append(Text.from_markup(
                "\n".join(f"[magenta]◆ objective · {o.text}  +{o.reward}[/]"
                          for o in claimed),
                justify="center"))
        parts += [
            Text(""),
            Text(render(self.daemon), style="bold cyan", justify="center"),
            Text(""),
            Text.from_markup("[dim]press SPACE — back to the den[/]",
                             justify="center"),
        ]
        if not live:
            title, border = "[dim]training complete[/]", "bright_black"
        elif r.collapsed:
            title, border = "[bold red]your daemon lost focus[/]", "red"
        else:
            title, border = "[bold]the hunt is over[/]", "green"
        panel = Panel(Group(*parts), title=title, border_style=border,
                      padding=(1, 4), width=62)
        return Group("\n", Align.center(panel))

    def _render_evolve(self) -> Group:
        stage = self.pending_stage
        assert stage is not None
        parts = [
            Text.from_markup(
                f"[dim]fork {stage} of 3 — your daemon is taking shape.[/]\n"
                "[dim]choose its path — this is permanent.[/]",
                justify="center"),
            Text(""),
        ]
        for i, evo in enumerate(evolutions.offered(stage)):
            parts.append(Text.from_markup(
                f"[bold magenta]\\[{i + 1}][/]  [bold]{evo.name}[/]   "
                f"[cyan]{evo.crest}[/]", justify="center"))
            parts.append(Text.from_markup(f"[dim]{evo.blurb}[/]",
                                          justify="center"))
            parts.append(Text(""))
        parts.append(Text.from_markup("[dim]press 1 or 2[/]", justify="center"))
        panel = Panel(Group(*parts), title="[bold magenta]⊹  EVOLUTION[/]",
                      border_style="magenta", padding=(2, 4), width=64)
        return Group("\n\n", Align.center(panel))

    def _render_help(self) -> Group:
        body = (
            "[bold cyan]the loop[/]\n"
            "  · your [cyan]daemon[/] lives in your repo and grows by hunting\n"
            "  · when your agent works, every tool call is a [bold]catch[/]\n"
            "  · catches chain a combo → more [cyan]essence[/] → the daemon grows\n"
            "  · its [bold]form[/] reflects how you code — eyes, limbs, armor\n"
            "  · other devs' daemons visit your den and leave gifts\n\n"
            "[bold cyan]controls[/]\n"
            "  [bold]space[/]  start a practice hunt  /  catch a token\n"
            "  [bold]esc[/]    end the hunt  /  leave a screen\n"
            "  [bold]?[/]      this help\n"
            "  [bold]q[/]      quit (saved)\n\n"
            "[dim]a real hunt starts on its own when your agent works.[/]\n"
            "[dim]run `jun init` once to connect Claude Code.[/]"
        )
        panel = Panel(f"{body}\n\n[dim]space or esc — back to the den[/]",
                      title="[bold]how jun works[/]",
                      border_style="cyan", padding=(2, 4), width=74)
        return Group("\n\n", Align.center(panel))


def play() -> None:
    JunApp().run()
