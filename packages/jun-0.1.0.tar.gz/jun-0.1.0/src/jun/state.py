"""On-disk persistence — everything jun remembers lives under ~/.jun/."""

import json
import os
import time
from pathlib import Path

from .engine.daemon import Daemon

JUN_DIR = Path(os.path.expanduser("~/.jun"))
DAEMON_FILE = JUN_DIR / "daemon.json"
EVENTS_FILE = JUN_DIR / "events.jsonl"


def _ensure() -> None:
    JUN_DIR.mkdir(parents=True, exist_ok=True)


def save_daemon(d: Daemon) -> None:
    _ensure()
    tmp = DAEMON_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(d.to_dict(), indent=2))
    tmp.replace(DAEMON_FILE)  # atomic — a crash mid-write never corrupts it


def load_daemon() -> Daemon | None:
    if not DAEMON_FILE.exists():
        return None
    try:
        return Daemon.from_dict(json.loads(DAEMON_FILE.read_text()))
    except (json.JSONDecodeError, OSError):
        return None


def clear_daemon() -> None:
    DAEMON_FILE.unlink(missing_ok=True)
    EVENTS_FILE.unlink(missing_ok=True)


def append_event(kind: str, label: str) -> None:
    """Called by the Claude Code hook for each tool call the agent makes."""
    _ensure()
    with EVENTS_FILE.open("a") as f:
        f.write(json.dumps({"kind": kind, "label": label,
                            "ts": time.time()}) + "\n")
