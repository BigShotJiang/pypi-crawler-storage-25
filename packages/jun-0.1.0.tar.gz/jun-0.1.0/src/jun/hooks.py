"""Claude Code integration.

jun is standalone — it never launches or wraps Claude Code. `jun init` installs
two hooks so the agent reports its activity to jun:
  * PostToolUse -> `jun _hook tool`  — each tool call becomes a hunt event
  * Stop        -> `jun _hook done`  — ends the hunt
"""

import json
import os
import sys
from pathlib import Path

from . import state as store
from .engine.events import kind_for_tool

CLAUDE_SETTINGS = Path(os.path.expanduser("~/.claude/settings.json"))

_HOOKS = {
    "PostToolUse": "jun _hook tool",
    "Stop": "jun _hook done",
}


def record_tool() -> None:
    """PostToolUse entry — reads the tool name from stdin, logs a hunt event."""
    tool_name = "Read"
    try:
        payload = json.loads(sys.stdin.read() or "{}")
        tool_name = payload.get("tool_name", tool_name)
    except (json.JSONDecodeError, ValueError):
        pass
    store.append_event(kind_for_tool(tool_name), tool_name)


def record_done() -> None:
    store.append_event("done", "agent finished")


def install() -> str:
    """Merge jun's hooks into the user's Claude Code settings. Idempotent."""
    settings: dict = {}
    if CLAUDE_SETTINGS.exists():
        try:
            settings = json.loads(CLAUDE_SETTINGS.read_text())
        except json.JSONDecodeError:
            return (f"Could not parse {CLAUDE_SETTINGS} — leaving it untouched.\n"
                    "Fix the JSON, then re-run `jun init`.")
    hooks = settings.setdefault("hooks", {})
    added = []
    for event, command in _HOOKS.items():
        entries = hooks.setdefault(event, [])
        if not any(h.get("command") == command
                   for entry in entries for h in entry.get("hooks", [])):
            entries.append({"hooks": [{"type": "command", "command": command}]})
            added.append(event)
    CLAUDE_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    CLAUDE_SETTINGS.write_text(json.dumps(settings, indent=2))
    if not added:
        return "jun hooks already installed — nothing to do."
    return (f"Installed jun hooks ({', '.join(added)}) into {CLAUDE_SETTINGS}.\n"
            "Your agent's tool calls will now drive jun's hunts.")
