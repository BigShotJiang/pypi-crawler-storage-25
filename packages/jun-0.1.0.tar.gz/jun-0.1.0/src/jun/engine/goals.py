"""Daily objectives — three goals a day, the reason to come back tomorrow.

Objectives are regenerated deterministically from the date, so every developer
gets the same three each day. Progress is read from the daemon's per-day
counters; a finished objective is claimed once for an essence reward.
"""

import random
from dataclasses import dataclass

# (metric, text template, target choices, reward choices)
_POOL = [
    ("hunts", "complete {n} hunts", (2, 3, 4), (120, 180, 260)),
    ("combo", "land a {n}x combo", (8, 10, 13), (150, 230, 340)),
    ("clashes", "catch {n} clashes (test runs)", (4, 6, 9), (130, 200, 280)),
    ("catches", "catch {n} tokens total", (30, 45, 65), (140, 210, 300)),
]


@dataclass(frozen=True)
class Objective:
    id: str
    text: str
    metric: str  # hunts | combo | clashes | catches
    target: int
    reward: int


def todays_objectives(day: str) -> list[Objective]:
    rng = random.Random("obj-" + day)
    out = []
    for metric, template, targets, rewards in rng.sample(_POOL, 3):
        tier = rng.randrange(3)
        out.append(Objective(
            id=f"{day}-{metric}",
            text=template.format(n=targets[tier]),
            metric=metric,
            target=targets[tier],
            reward=rewards[tier],
        ))
    return out


def progress(objective: Objective, daemon: "object") -> int:
    return {
        "hunts": daemon.today_hunts,
        "combo": daemon.today_combo,
        "clashes": daemon.today_clashes,
        "catches": daemon.today_catches,
    }[objective.metric]


def is_done(objective: Objective, daemon: "object") -> bool:
    return progress(objective, daemon) >= objective.target
