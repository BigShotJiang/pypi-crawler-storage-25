"""The tool-call event stream — the live feed that paces a hunt.

A hunt is driven by real agent activity: Claude Code's PostToolUse hook writes
one JSON line per tool call to ~/.jun/events.jsonl, and the Stop hook writes a
'done' line (see hooks.py). `FileEventSource` tails that file. `SimulatedEvent
Source` fakes a believable stream so jun is fully playable with no agent.
"""

import json
import random
import time
from dataclasses import dataclass
from pathlib import Path

# Event kinds — what a tool call becomes inside the game.
STRIKE = "strike"  # Edit / Write — the daemon attacks
CLASH = "clash"    # Bash — a risky, heavy hit
SCAN = "scan"      # Read / Grep / Glob — light, lenient
FOCUS = "focus"    # a thinking pause — a charge
DONE = "done"      # the agent finished — the hunt ends

KIND_BY_TOOL = {
    "Edit": STRIKE, "Write": STRIKE, "MultiEdit": STRIKE, "NotebookEdit": STRIKE,
    "Bash": CLASH,
    "Read": SCAN, "Grep": SCAN, "Glob": SCAN, "LS": SCAN, "WebFetch": SCAN,
}


def kind_for_tool(tool_name: str) -> str:
    return KIND_BY_TOOL.get(tool_name, SCAN)


@dataclass
class ToolEvent:
    kind: str
    label: str
    ts: float

    def to_json(self) -> str:
        return json.dumps({"kind": self.kind, "label": self.label, "ts": self.ts})

    @classmethod
    def from_dict(cls, d: dict) -> "ToolEvent":
        return cls(d["kind"], d.get("label", d["kind"]), d.get("ts", time.time()))


# --- live source: the real agent ----------------------------------------

class FileEventSource:
    """Tails ~/.jun/events.jsonl. Only events written after jun started count."""

    label = "LIVE · your agent"

    def __init__(self, path: Path) -> None:
        self.path = path
        # Start at the current end of file — ignore history, hunt live only.
        self._offset = path.stat().st_size if path.exists() else 0

    def poll(self, dt: float) -> list[ToolEvent]:
        if not self.path.exists():
            return []
        size = self.path.stat().st_size
        if size < self._offset:  # the file was truncated or replaced
            self._offset = 0
        if size <= self._offset:
            return []
        with self.path.open("r") as f:
            f.seek(self._offset)
            chunk = f.read()
            self._offset = f.tell()
        events = []
        for line in chunk.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                events.append(ToolEvent.from_dict(json.loads(line)))
            except (json.JSONDecodeError, KeyError):
                continue
        return events


# --- practice source: a simulated agent ----------------------------------

_FLAVOR = {
    STRIKE: ["edit auth.py", "write models.py", "patch router.ts", "edit utils.go",
             "rewrite parser.py", "edit views.jsx", "write tests.py"],
    CLASH: ["run pytest", "run npm test", "run the build", "run migrations",
            "run the linter", "run docker build"],
    SCAN: ["read config.py", "grep TODO", "read schema.sql", "glob **/*.ts",
           "read README", "grep import"],
    FOCUS: ["thinking it through", "planning the change", "reading the diff"],
}


class SimulatedEventSource:
    """A believable fake stream — for practice hunts and demos."""

    label = "PRACTICE · simulated agent"

    def __init__(self, seed: int | None = None) -> None:
        self.rng = random.Random(seed)
        self._elapsed = 0.0
        self._next_at = self.rng.uniform(0.4, 1.2)
        self._emitted = 0
        self._target = self.rng.randint(14, 24)
        self._finished = False

    def poll(self, dt: float) -> list[ToolEvent]:
        if self._finished:
            return []
        self._elapsed += dt
        out: list[ToolEvent] = []
        while self._elapsed >= self._next_at and not self._finished:
            if self._emitted >= self._target:
                out.append(ToolEvent(DONE, "agent finished", time.time()))
                self._finished = True
                break
            kind = self.rng.choices(
                [STRIKE, SCAN, CLASH, FOCUS], weights=[5, 3, 2, 1])[0]
            out.append(ToolEvent(kind, self.rng.choice(_FLAVOR[kind]), time.time()))
            self._emitted += 1
            gap = self.rng.uniform(1.1, 2.7)
            if kind == FOCUS:
                gap += self.rng.uniform(1.4, 2.8)
            self._next_at = self._elapsed + gap
        return out
