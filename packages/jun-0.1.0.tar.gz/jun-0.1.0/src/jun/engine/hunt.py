"""The hunt — catch your agent's tool calls in rhythm. Pure logic.

Depth, kept inside the one core action:
  * each kind catches differently — a test run (clash) is a narrow, rich zone,
    a file read (scan) is wide and forgiving;
  * every Nth combo step triggers a surge — a burst of bonus essence;
  * each hunt carries a goal combo worth a one-off bonus;
  * FOCUS is the stakes — misses drain it, and at zero the hunt collapses.

Evolution modifiers (zone_mult, essence_mult, …) arrive as plain fields.
The hunt ends when the agent finishes, when focus runs out, or — defensively —
if the event stream goes silent for too long.
"""

import random
from dataclasses import dataclass, field

from .events import CLASH, DONE, FOCUS, SCAN, STRIKE, ToolEvent

TRACK = 32           # cells on the catch bar
TARGET_WIDTH = 7.0   # base catch zone, before per-kind and evolution scaling
CATCH_WINDOW = 2.6   # seconds a token stays catchable
BASE_REWARD = 10.0
GOAL_BONUS = 250.0
IDLE_TIMEOUT = 25.0
FEED_KEEP = 9

MAX_FOCUS = 100.0
MISS_FOCUS = 20.0    # focus lost per miss (before evolution scaling)
CATCH_FOCUS = 5.0    # focus restored per catch
SURGE_FOCUS = 18.0   # focus restored by a combo surge

KIND_WEIGHT = {STRIKE: 1.0, CLASH: 1.6, SCAN: 0.7, FOCUS: 1.3}
# Per-kind zone width: a clash is hard and rich, a scan is wide and gentle.
KIND_ZONE = {STRIKE: 1.0, CLASH: 0.62, SCAN: 1.5, FOCUS: 1.05}


@dataclass
class Catch:
    event: ToolEvent
    target: float
    zone: float  # half-width of the catch zone for this token
    pos: float = 0.0
    direction: int = 1
    age: float = 0.0

    def in_zone(self, cell: int) -> bool:
        return abs(cell - self.target) <= self.zone


@dataclass
class HuntResult:
    essence: float
    counts: dict
    best_combo: int
    caught: int
    missed: int
    surges: int
    goal_combo: int
    goal_met: bool
    collapsed: bool


@dataclass
class Hunt:
    seed: int | None = None
    speed: float = 17.0
    # evolution modifiers — neutral by default
    zone_mult: float = 1.0
    essence_mult: float = 1.0
    focus_miss_mult: float = 1.0
    combo_scale: float = 1.0
    surge_every: int = 5
    goal_bonus_mult: float = 1.0
    # live state
    queue: list[ToolEvent] = field(default_factory=list)
    feed: list[ToolEvent] = field(default_factory=list)
    active: Catch | None = None
    combo: int = 0
    best_combo: int = 0
    essence: float = 0.0
    focus: float = MAX_FOCUS
    caught: int = 0
    missed: int = 0
    surges: int = 0
    goal_combo: int = 0
    goal_met: bool = False
    counts: dict = field(default_factory=lambda: {
        STRIKE: 0, CLASH: 0, SCAN: 0, FOCUS: 0})
    last_result: str = ""
    flash: float = 0.0
    surge_flash: float = 0.0
    since_event: float = 0.0
    over: bool = False
    collapsed: bool = False
    _done_pending: bool = False
    _rng: random.Random = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._rng = random.Random(self.seed)
        self.goal_combo = self._rng.choice([6, 8, 10, 12])

    @property
    def combo_mult(self) -> float:
        return 1 + 0.25 * self.combo_scale * self.combo

    @property
    def cursor_speed(self) -> float:
        # the cursor quickens with the combo — a built-in mastery curve
        return self.speed + min(14.0, self.combo * 0.35)

    # --- input from the event stream ------------------------------------
    def add_event(self, event: ToolEvent) -> None:
        self.since_event = 0.0
        self.feed.append(event)
        del self.feed[:-FEED_KEEP]
        if event.kind == DONE:
            self._done_pending = True
        else:
            self.queue.append(event)

    # --- simulation ------------------------------------------------------
    def _spawn(self) -> None:
        event = self.queue.pop(0)
        zone = (TARGET_WIDTH / 2) * KIND_ZONE.get(event.kind, 1.0) * self.zone_mult
        margin = zone + 1
        target = self._rng.uniform(margin, TRACK - 1 - margin)
        self.active = Catch(event, target, zone)

    def update(self, dt: float) -> None:
        if self.over:
            return
        self.since_event += dt
        if self.flash > 0:
            self.flash -= dt
        if self.surge_flash > 0:
            self.surge_flash -= dt
        if self.active is None and self.queue:
            self._spawn()
        if self.active is not None:
            c = self.active
            c.age += dt
            c.pos += c.direction * self.cursor_speed * dt
            if c.pos <= 0:
                c.pos, c.direction = 0.0, 1
            elif c.pos >= TRACK - 1:
                c.pos, c.direction = float(TRACK - 1), -1
            if c.age >= CATCH_WINDOW:
                self._resolve(hit=False)
        if not self.over and self.active is None and not self.queue:
            if self._done_pending or self.since_event > IDLE_TIMEOUT:
                self.over = True

    def catch(self) -> None:
        if self.active is None:
            return
        dist = abs(self.active.pos - self.active.target)
        self._resolve(hit=dist <= self.active.zone, dist=dist)

    def _resolve(self, hit: bool, dist: float = 99.0) -> None:
        c = self.active
        if hit:
            self.combo += 1
            self.best_combo = max(self.best_combo, self.combo)
            self.caught += 1
            self.counts[c.event.kind] += 1
            self.focus = min(MAX_FOCUS, self.focus + CATCH_FOCUS)
            perfect = dist <= c.zone / 3
            gain = (BASE_REWARD * KIND_WEIGHT[c.event.kind]
                    * self.combo_mult * self.essence_mult)
            if perfect:
                gain *= 2
            self.essence += gain
            self.last_result = "PERFECT" if perfect else "CATCH"
            if self.combo % self.surge_every == 0:  # combo milestone — a surge
                self.essence += BASE_REWARD * self.combo
                self.focus = min(MAX_FOCUS, self.focus + SURGE_FOCUS)
                self.surges += 1
                self.surge_flash = 1.4
            if not self.goal_met and self.combo >= self.goal_combo:
                self.goal_met = True
                self.essence += GOAL_BONUS * self.goal_bonus_mult
        else:
            self.combo = 0
            self.missed += 1
            self.last_result = "MISS"
            self.focus -= MISS_FOCUS * self.focus_miss_mult
            if self.focus <= 0:  # focus spent — the hunt collapses
                self.focus = 0.0
                self.collapsed = True
                self.over = True
        self.flash = 0.35
        self.active = None

    # --- output ----------------------------------------------------------
    def result(self) -> HuntResult:
        return HuntResult(self.essence, dict(self.counts), self.best_combo,
                          self.caught, self.missed, self.surges,
                          self.goal_combo, self.goal_met, self.collapsed)
