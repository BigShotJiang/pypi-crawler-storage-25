"""The shared world — other developers' daemons.

v0.1 is *simulated locally*: the social layer feels real but the data is
generated on-device, seeded so it is stable per day. Swapping these two
functions for HTTP calls to a registry is the only change needed to make jun
genuinely multiplayer.
"""

import random
from dataclasses import dataclass

_DEVS = ["pylon_enjoyer", "merge_gandalf", "null_whisper", "async_owl",
         "tabs_over_spaces", "rm_rf_renee", "big_O_notation", "heap_sortie",
         "kewlbeans", "segfault_sam", "the_lint_lord", "promise_pending",
         "yak_shaver", "regex_witch", "cache_invalidator"]

_NOTES = ["tests were green today", "found a gift in the dark/ folder",
          "left you some essence — go hunt", "your daemon looked strong",
          "shipped on a friday, living dangerously", "rebased and survived",
          "the build is finally fast", "say hi to your daemon for me"]

_ADJ = ["nimble", "armored", "watchful", "hulking", "restless", "ancient"]

_EXPEDITIONS = ["the Null Caverns", "the Merge Conflict", "the Legacy Depths",
                "the Flaky Test Marsh", "the Dependency Tangle",
                "the Race Condition", "the Off-by-One Cliffs"]


@dataclass
class Visitor:
    dev: str
    descriptor: str
    gift: int
    note: str


@dataclass
class Expedition:
    name: str
    board: list[tuple[str, int]]  # (dev, score), sorted desc, includes you
    your_rank: int
    party_size: int
    progress: int  # 0-100 — the party's shared progress through it today


def visitors(seed_key: str) -> list[Visitor]:
    """Daemons that wandered through while you were away — stable per day."""
    rng = random.Random("visit-" + seed_key)
    out = []
    for _ in range(rng.randint(2, 4)):
        eyes = rng.randint(2, 7)
        adj = rng.choice(_ADJ)
        article = "an" if adj[0] in "aeiou" else "a"
        out.append(Visitor(
            dev=rng.choice(_DEVS),
            descriptor=f"{article} {adj} {eyes}-eyed daemon",
            gift=rng.randint(15, 80),
            note=rng.choice(_NOTES),
        ))
    return out


def expedition(today: str, your_score: int, your_name: str) -> Expedition:
    """Today's shared challenge — the same for every dev, seeded by the date."""
    rng = random.Random("expedition-" + today)
    name = _EXPEDITIONS[rng.randrange(len(_EXPEDITIONS))]
    party_size = rng.randint(400, 4000)
    progress = rng.randint(58, 94)
    board = [(rng.choice(_DEVS), rng.randint(40, 1300)) for _ in range(8)]
    board.append((f"{your_name} (you)", your_score))
    board.sort(key=lambda entry: entry[1], reverse=True)
    rank = next(i for i, (n, _) in enumerate(board) if "(you)" in n) + 1
    return Expedition(name, board[:6], rank, party_size, progress)
