"""Evolutions — the three choices that define your daemon.

A daemon evolves three times. Each evolution is a fork: you pick one of two
forms and the choice is permanent. Three forks → eight possible daemons.
Every evolution is a single, legible modifier to the hunt — no trees, no bloat.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Evolution:
    id: str
    name: str
    stage: int  # 1, 2 or 3
    blurb: str  # one line — exactly what it does
    crest: str  # the motif drawn on top of the daemon once chosen


# Daemon level at which each evolution fork unlocks.
STAGE_LEVEL = {1: 3, 2: 8, 3: 15}

EVOLUTIONS: list[Evolution] = [
    Evolution("stalker", "Stalker", 1,
              "catch zones are 30% wider — forgiving", "·˘˘˘·"),
    Evolution("reaper", "Reaper", 1,
              "+25% essence, but misses cost more focus", "╲╳╳╳╱"),
    Evolution("anchor", "Anchor", 2,
              "misses cost 40% less focus — you endure", "▙▆▆▆▟"),
    Evolution("frenzy", "Frenzy", 2,
              "the combo multiplier builds far faster", "≀≀≀≀≀"),
    Evolution("oracle", "Oracle", 3,
              "combo surges trigger every 4 catches, not 5", "◌✶✶✶◌"),
    Evolution("titan", "Titan", 3,
              "the per-hunt goal bonus is tripled", "▟█████▙"),
]

EVOLUTION_BY_ID: dict[str, Evolution] = {e.id: e for e in EVOLUTIONS}


def offered(stage: int) -> list[Evolution]:
    """The two evolutions on a given fork."""
    return [e for e in EVOLUTIONS if e.stage == stage]


def next_stage(level: int, chosen_ids: list[str]) -> int | None:
    """The next evolution fork the daemon has unlocked but not yet chosen."""
    chosen = {EVOLUTION_BY_ID[e].stage for e in chosen_ids if e in EVOLUTION_BY_ID}
    for stage in (1, 2, 3):
        if stage not in chosen and level >= STAGE_LEVEL[stage]:
            return stage
    return None


def modifiers(chosen_ids: list[str]) -> dict:
    """Combine chosen evolutions into the hunt modifiers they grant."""
    mods = {
        "zone_mult": 1.0,        # catch-zone width
        "essence_mult": 1.0,     # essence per catch
        "focus_miss_mult": 1.0,  # focus lost per miss
        "combo_scale": 1.0,      # how fast the combo multiplier climbs
        "surge_every": 5,        # combo steps between surges
        "goal_bonus_mult": 1.0,  # per-hunt goal payout
    }
    for eid in chosen_ids:
        if eid == "stalker":
            mods["zone_mult"] *= 1.3
        elif eid == "reaper":
            mods["essence_mult"] *= 1.25
            mods["focus_miss_mult"] *= 1.45
        elif eid == "anchor":
            mods["focus_miss_mult"] *= 0.6
        elif eid == "frenzy":
            mods["combo_scale"] *= 1.7
        elif eid == "oracle":
            mods["surge_every"] = 4
        elif eid == "titan":
            mods["goal_bonus_mult"] *= 3.0
    return mods
