"""The daemon — a creature grown from your real coding, drawn as ASCII art.

It is persistent and fully serializable. Its *form* is generative: every trait
counter (strikes, scans, clashes, focuses) shapes how it is drawn, so a
daemon is a unique portrait of how its owner actually works.
"""

import dataclasses
import random
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .evolutions import EVOLUTION_BY_ID

if TYPE_CHECKING:
    from .hunt import HuntResult

_SYLLABLES = ["jun", "ka", "mo", "ru", "ne", "ash", "vel", "ix", "or", "um",
              "ti", "za", "grim", "lo", "syn", "que", "rax", "in"]


def _coin_name(rng: random.Random) -> str:
    return "".join(rng.choice(_SYLLABLES)
                   for _ in range(rng.randint(2, 3))).capitalize()


@dataclass
class Daemon:
    name: str = ""
    seed: int = 0
    essence: float = 0.0
    strikes: int = 0
    clashes: int = 0
    scans: int = 0
    focuses: int = 0
    hunts: int = 0
    best_combo: int = 0
    gifts_received: int = 0
    onboarded: bool = False
    last_seen: float = field(default_factory=time.time)
    last_visit_day: str = ""  # date string — visitors refresh once per day
    born_at: float = field(default_factory=time.time)
    # per-day counters — drive the daily objectives, reset by roll_day()
    day: str = ""
    today_hunts: int = 0
    today_catches: int = 0
    today_combo: int = 0
    today_clashes: int = 0
    claimed: list[str] = field(default_factory=list)
    evolutions: list[str] = field(default_factory=list)  # chosen forks

    @classmethod
    def hatch(cls) -> "Daemon":
        seed = random.randint(0, 2**31 - 1)
        return cls(name=_coin_name(random.Random(seed)), seed=seed)

    # --- derived traits (also drive the rendering) -----------------------
    @property
    def level(self) -> int:
        return int((self.essence / 60.0) ** 0.5) + 1

    def _form(self) -> dict[str, int]:
        """Trait development — paces with level, shaped by how the daemon hunts.

        Each level carries 'form points'; they split across the four traits in
        proportion to how the daemon earned its essence (edits → limbs, reads →
        eyes, test runs → armor, thinking → aura). So the daemon always *looks*
        its level, and its shape still reflects how its owner codes.
        """
        activity = self.strikes + self.scans + self.clashes + self.focuses
        budget = min(14, self.level - 1)  # level 1 is a newborn — 0 points
        if activity == 0 or budget <= 0:
            return {"eyes": 0, "limbs": 0, "armor": 0, "aura": 0}
        return {
            "eyes": min(5, round(budget * self.scans / activity)),
            "limbs": min(4, round(budget * self.strikes / activity)),
            "armor": min(3, round(budget * self.clashes / activity)),
            "aura": min(2, round(budget * self.focuses / activity)),
        }

    @property
    def eye_count(self) -> int:
        return 2 + self._form()["eyes"]

    @property
    def limb_count(self) -> int:
        return 2 + self._form()["limbs"]

    @property
    def armor(self) -> int:
        return self._form()["armor"]

    @property
    def aura(self) -> int:
        return self._form()["aura"]

    # --- growth ----------------------------------------------------------
    def roll_day(self, today: str) -> None:
        """Reset the per-day counters when the date changes."""
        if self.day != today:
            self.day = today
            self.today_hunts = self.today_catches = 0
            self.today_combo = self.today_clashes = 0
            self.claimed = []

    def feed(self, result: "HuntResult") -> None:
        self.essence += result.essence
        self.strikes += result.counts.get("strike", 0)
        self.clashes += result.counts.get("clash", 0)
        self.scans += result.counts.get("scan", 0)
        self.focuses += result.counts.get("focus", 0)
        self.hunts += 1
        self.best_combo = max(self.best_combo, result.best_combo)
        self.today_hunts += 1
        self.today_catches += result.caught
        self.today_combo = max(self.today_combo, result.best_combo)
        self.today_clashes += result.counts.get("clash", 0)

    # --- persistence -----------------------------------------------------
    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Daemon":
        valid = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in valid})


def render(d: Daemon) -> str:
    """Draw the daemon — a round-headed imp whose form is set by its traits.

    eyes ← scans · limbs ← strikes · horns ← clashes · aura ← focuses.
    """
    eyes = "  ".join("•" for _ in range(d.eye_count))
    inner = len(eyes) + 4

    rows: list[str] = []
    if d.evolutions:  # the latest evolution crowns the daemon
        rows.append(EVOLUTION_BY_ID[d.evolutions[-1]].crest)
    if d.aura == 2:
        rows.append("✦  ·  ✦  ·  ✦")
    elif d.aura == 1:
        rows.append("·  ✦  ·")
    if d.armor:
        rows.append("   ".join("Λ" for _ in range(d.armor)))
    rows.append("╭" + "─" * inner + "╮")
    rows.append("│" + eyes.center(inner) + "│")
    rows.append("│" + "‿".center(inner) + "│")
    rows.append("╰" + "─" * inner + "╯")
    rows.append("  ".join("│" for _ in range(d.limb_count)))
    rows.append("  ".join("╨" for _ in range(d.limb_count)))

    span = max(len(r) for r in rows)
    return "\n".join(r.center(span) for r in rows)
