"""LightGBM defaults — task mappings, common defaults, and default search space."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from lizyml.core.types.search_dim import CategoricalDim, FloatDim, IntDim, SearchDim
from lizyml.core.types.task import TaskType

if TYPE_CHECKING:  # pragma: no cover — H-0079 type hint only (import cycle)
    from lizyml.estimators.provider import EstimatorProvider

# H-0079 Phase 3: tune-safe default objective candidates per task.
# Conservative subset of ``TASK_COMPATIBLE_OBJECTIVES`` chosen because
# every value here works on **arbitrary** target distributions
# (``gamma`` / ``poisson`` / ``tweedie`` need non-negative targets,
# ``mape`` needs non-zero, etc.; those would fail tune trials on
# generic regression data, so they are not surfaced as defaults).
# Users that want the wider set can pass an explicit
# ``CategoricalDim("objective", LGBMProvider().objective_choices(task))``
# in ``tuning.search_space``.
_DEFAULT_TUNE_OBJECTIVES: dict[str, tuple[str, ...]] = {
    "regression": ("huber", "fair"),
    "binary": ("binary",),
    "multiclass": ("multiclass", "multiclassova"),
}

# Maps task → objective
_TASK_OBJECTIVE: dict[str, str] = {
    "regression": "huber",
    "binary": "binary",
    "multiclass": "multiclass",
}

# H-0079: Per-task whitelist of LightGBM objective names accepted by
# ``LGBMAdapter._build_params``. Canonical names only (no aliases). Source:
# https://lightgbm.readthedocs.io/en/latest/Parameters.html#objective
TASK_COMPATIBLE_OBJECTIVES: dict[str, frozenset[str]] = {
    "regression": frozenset(
        [
            "regression",
            "regression_l1",
            "huber",
            "fair",
            "poisson",
            "quantile",
            "mape",
            "gamma",
            "tweedie",
        ]
    ),
    "binary": frozenset(
        [
            "binary",
            "cross_entropy",
            "cross_entropy_lambda",
        ]
    ),
    "multiclass": frozenset(
        [
            "multiclass",
            "multiclassova",
        ]
    ),
}

# Maps task → eval_metric list
_TASK_METRIC: dict[str, list[str]] = {
    "regression": ["huber", "mae", "mape"],
    "binary": ["auc", "binary_logloss"],
    "multiclass": ["auc_mu", "multi_logloss"],
}

# Common LightGBM defaults (also used by resolve_smart_params)
_COMMON_DEFAULTS: dict[str, Any] = {
    "boosting": "gbdt",
    "n_estimators": 1500,
    "learning_rate": 0.001,
    "max_depth": 5,
    "max_bin": 511,
    "feature_fraction": 0.7,
    "bagging_fraction": 0.7,
    "bagging_freq": 10,
    "lambda_l1": 0.0,
    "lambda_l2": 0.000001,
    "first_metric_only": False,
}


def default_space(
    task: TaskType,
    provider: EstimatorProvider | None = None,
) -> list[SearchDim]:
    """Return the PLAN-specified default search space for LightGBM.

    Args:
        task: ML task type (``"regression"``, ``"binary"``, ``"multiclass"``).
        provider: Optional ``EstimatorProvider`` used to source the
            ``objective`` choices (H-0079). When ``None`` (the default),
            a conservative ``_DEFAULT_TUNE_OBJECTIVES`` set is used so
            that tune over arbitrary regression data does not fail trials
            with task-incompatible distributions (e.g. ``gamma`` /
            ``poisson`` need non-negative targets). When supplied, the
            full ``provider.objective_choices(task)`` is used — caller
            opts in to a wider tune space.

    Returns:
        List of 10 SearchDim across model / smart / training categories.
    """
    if provider is not None:
        objective_choices = provider.objective_choices(
            task
        ) or _DEFAULT_TUNE_OBJECTIVES.get(task, ("huber",))
    else:
        objective_choices = _DEFAULT_TUNE_OBJECTIVES.get(task, ("huber",))
    dims: list[SearchDim] = [
        # -- model --
        CategoricalDim(
            "objective",
            objective_choices,
            category="model",
        ),
        IntDim("n_estimators", 600, 2500, category="model"),
        FloatDim("learning_rate", 0.0001, 0.1, log=True, category="model"),
        IntDim("max_depth", 3, 12, category="model"),
        FloatDim("feature_fraction", 0.5, 1.0, category="model"),
        FloatDim("bagging_fraction", 0.5, 1.0, category="model"),
        # -- smart --
        FloatDim("num_leaves_ratio", 0.5, 1.0, category="smart"),
        FloatDim("min_data_in_leaf_ratio", 0.01, 0.2, category="smart"),
        # -- training --
        IntDim("early_stopping_rounds", 40, 240, category="training"),
        FloatDim("validation_ratio", 0.1, 0.3, category="training"),
    ]
    return dims


def default_fixed_params(task: TaskType) -> dict[str, Any]:
    """Return fixed parameters applied to every trial when using default space.

    Only model-level LightGBM parameters belong here.  Smart params
    (``auto_num_leaves`` etc.) are handled via ``base_smart_params`` in the
    tune objective and must **not** leak into model params (#76).

    Args:
        task: ML task type.

    Returns:
        Dict with ``first_metric_only`` and ``metric``.
    """
    return {
        "first_metric_only": True,
        "metric": _TASK_METRIC.get(task, ["huber", "mae", "mape"]),
    }
