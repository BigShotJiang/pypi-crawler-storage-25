# Changelog

All notable changes to Efterlev will be tracked here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) loosely.

## [0.1.136] — 2026-05-16

**Shell polish bundle: three real-customer-feedback fixes.** All three
surfaced from a customer's first-time test of the shell at v0.1.135.

### Fixed — `/ai` now works with AWS Bedrock

Previously `/ai` was hardcoded to the Anthropic API. After configuring
Bedrock via `/setup`, `/ai` would fail with `AuthenticationError: 401
invalid x-api-key` because it tried to call Anthropic anyway (and the
env var or stale credentials.toml had a non-working key).

v0.1.136 makes `/ai` backend-aware: detects which backend the user
configured and routes accordingly. Anthropic when an API key is
available (env or credentials.toml); Bedrock when a region is recorded
with no Anthropic key. Default models: Sonnet 4.6 on Anthropic, Haiku
4.5 on Bedrock. Cost line + receipts-log append work identically for
both paths.

### Fixed — `/se<TAB>` now completes to `/setup`

Tab completion was `complete_while_typing=False` (manual Tab required).
Users didn't realize they had to press Tab, and the inline ghost-text
suggestions from `AutoSuggestFromHistory` only surface things you've
previously typed — so fresh commands like `/setup` were invisible.
Switched to `complete_while_typing=True` so matches appear as you type.

### Fixed — file-location confusion ("where do I put my .tf?")

The most damaging first-run failure: customers thought they needed to
copy `.tf` files into the (hidden) `.efterlev/` directory and gave up
when they couldn't find it. Two changes:

1. The shell entry block now clarifies in plain text: "Efterlev scans
   the directory it runs from — your IaC files stay where they are.
   The `.efterlev/` directory holds workspace metadata only."
2. The `Next` hint when uninitialized is now state-aware: if the cwd
   has no `.tf` / `.yaml` / `aws_cdk*.py` files, the suggestion is
   `/cd <repo-root>` (with a "cd into your repo root first") instead
   of the misleading `/init`. If IaC files are present, `/init` shows
   with "found IaC files here; create a workspace to scan them" —
   confirming Efterlev sees them.

## [0.1.135] — 2026-05-16

**ISV workflow polish: `efterlev readiness` + `efterlev submission package`.**
Closes the "now what?" loop. ISVs running their first FedRAMP 20x can
now (a) get a single signal of how close they are to a 3PAO scoping
conversation and (b) bundle the artifacts into a single deliverable
to hand to that 3PAO. Both commands are deterministic — zero LLM
spend.

### Added — `efterlev readiness` (`/readiness` in the shell)

Single-page scorecard answering "am I close?". Heuristic 0-100%
weighted across three dimensions:

- **KSI coverage** (50% weight) — fraction of baseline KSIs
  classified as `implemented`, `not_applicable`, or
  `evidence_layer_inapplicable`. Partial = half credit.
- **Manifest coverage** (30% weight) — fraction of procedural KSIs
  (AFR/CED/INR themes) backed by signed Evidence Manifests.
- **Severity penalty** (20% weight) — open HIGH-severity POA&M items
  reduce the score (5 points per item, floored at 0).

Renders a `▰▰▰▰▰▰▰▱▱▱  72%` progress bar with a human-readable
band label ("ready for 3PAO scoping conversation", etc.) and the
top 3 blockers with suggested next commands. `--json` flag emits
the structured `ReadinessReport` for downstream tools.

The score is a rule-of-thumb for ISVs to track progress — not a
3PAO methodology. Reviewers should evaluate the underlying
artifacts; the score is a navigation aid.

### Added — `efterlev submission package` (`/package` in the shell)

One-command bundle of the artifacts a 3PAO actually wants. Picks
the LATEST of each artifact type from `.efterlev/reports/` and
`.efterlev/manifests/`, writes a zip with:

- `attestation/frmr-attestation.json` — Documentation Agent output
- `poam/poam.md` — Plan-of-Action-and-Milestones markdown
- `oscal/poam.json` — OSCAL 1.0.4 POA&M (NIST + FedRAMP + oscal-cli validated)
- `oscal/component-definition.json` — OSCAL CD with per-KSI implemented-requirements
- `reports/gap-report.html` — color-coded gap report
- `reports/documentation.html` — narrative-shaped FRMR view
- `manifests/*.yml` — customer-authored procedural attestations
- `README.md` — explains what's in the package + suggested read order
- `index.json` — machine-readable manifest with SHA-256 per artifact

Default output: `.efterlev/submissions/submission-<ts>.zip`.
`--no-archive` writes a directory tree instead. `--version <str>`
embeds a custom version string in the README + index.

Missing artifacts are reported informationally (not fatal) so the
customer can iteratively close gaps and re-package without
ceremony. Each iteration is a separate versioned zip — natural
progress trail.

### Architecture

- New `src/efterlev/primitives/readiness/` package — score module +
  ReadinessReport dataclass. Pure-read; pure deterministic.
- New `src/efterlev/primitives/submission/` package — packaging
  module + SubmissionResult/SubmissionManifest dataclasses. Atomic
  archive writes via temp file + rename. SHA-256 per artifact.
- New CLI handlers: `src/efterlev/cli/readiness_cli.py` +
  `src/efterlev/cli/submission_cli.py`.
- Shell registrations: `/readiness` (alias `/ready`), `/package`.

### Tests

- 9 readiness tests covering scoring math across edge cases (all
  implemented, all not_implemented, partial-as-half-credit,
  procedural-needs-manifest, blocker ranking, missing store
  tolerance, band-label thresholds).
- 9 submission tests covering full-set archive, missing-pieces
  fallback, directory mode, output-path override, latest-version
  selection, SHA-256 recording, version embedding, empty workspace.

## [0.1.134] — 2026-05-16

**`/setup` wizard + `/ai` Q&A** — onboarding + conversational
assistance for the interactive shell. The two pieces work together:
`/setup` gets the user's LLM credentials configured (Anthropic API
or AWS Bedrock); `/ai <question>` answers Efterlev/FedRAMP questions
grounded in the live workspace state.

### Added — `/setup`

Interactive wizard that walks the user through LLM configuration.

- Two backends supported: **Anthropic API** (~5 min setup; opens
  https://console.anthropic.com/settings/keys, prompts for the key,
  validates with a 1-token test query, persists) and **AWS Bedrock**
  (verifies boto3 credentials via STS, verifies Bedrock model access
  via a Haiku Converse test call, records region).
- Persistence target: `~/.efterlev/credentials.toml` (mode 0o600,
  directory mode 0o700). Same posture as `~/.aws/credentials`. No
  shell profile modification.
- Validation does real test queries — credentials are only saved
  after they're proven to work.

### Added — `/ai <question>`

Single-shot conversational assistance grounded in the live workspace
snapshot. Streams responses; appends a one-line cost summary.

- Default model: Claude Sonnet 4.6 (~$0.01-0.05 per query).
- System prompt composed from three live parts: domain primer (KSIs,
  FRMR, the pipeline), workspace snapshot (state, evidence count,
  classifications), slash command catalog. The AI is told to suggest
  commands, never to invent them.
- Single-shot only: each `/ai` is independent. No persistent chat
  state at v1.
- Suggested commands are printed, not auto-run. The user types them
  to confirm.
- Writes spend to `.efterlev/receipts.log` when a workspace exists,
  so `/cost` rolls up `/ai` spend alongside agent spend.
- Alias: `/ask`.

### Added — credentials resolution

- New `src/efterlev/shell/credentials.py` — read/write
  `~/.efterlev/credentials.toml`; resolve API key via env → file
  fallback chain.
- `efterlev/llm/anthropic_client.py` now falls back to the
  credentials file when `ANTHROPIC_API_KEY` is not in the env. CI
  and per-process overrides keep working unchanged (env wins).

### Tests

- 10 new tests for credentials (load/save/roundtrip/permissions/env
  precedence/tolerance to malformed TOML).
- 6 new tests for the `/ai` handler (catalog content, prompt
  composition, error paths when no key configured / empty question).

## [0.1.133] — 2026-05-16

**Beginner-friendly shell + readable banner + README positioning.**
Three improvements responding to first-run feedback on v0.1.132:
the box-drawing banner rendered poorly on common terminals; the
shell offered no walkthrough for users who didn't know which slash
command to run; the README's positioning vs Rev 5-first compliance
tooling was under-developed.

### Added

- **`/tour` slash command** — guided walkthrough for new users.
  Walks the canonical pipeline (`init → scan → agent gap →
  agent document → poam`) one step at a time, explaining what
  each step does and why it matters before running it. Pauses
  for Enter at every gate; Ctrl+C exits the tour without
  leaving the shell. Steps that have already run (workspace
  already initialized, scan already done, etc.) are skipped
  with a one-line note. Alias: `/walk`.
- Shell entry hint now surfaces `/tour` for first-time users
  (when `.efterlev/` doesn't exist) and for returning users
  (alongside `/help`).
- New `src/efterlev/shell/tour.py` module + 9 tests in
  `tests/test_shell_tour.py`.

### Changed — banner

`src/efterlev/shell/banner.py` rewritten using the figlet "standard"
font rendering of "Efterlev." The v0.1.132 box-drawing approach
(`┌─┐ ├─ ╲`) fragmented visually on common terminals — verticals
rendered at inconsistent heights, horizontals didn't connect to
corners, letterforms came apart. The v0.1.133 attempt at solid
block characters (`█ ▀ ▄`) read as too-bold and unrelated to the
logo. Figlet standard renders reliably across terminals, is
instantly recognizable, and stays compact. 5 rows tall, ~39 cols
wide. Banner test updated to 5-row shape.

### Changed — README

Substantial positioning rewrite expanding the customer-story zone
into three named sections that sharpen the 20x-native vs Rev 5
distinction:

- **Why this exists** — replaces the original pull quote with a
  fuller customer-story narrative.
- **Built for 20x. Not retrofitted from Rev 5.** — explains why
  Rev 5-first tooling breaks down under persistent-validation
  workflows where assessors evaluate the pipeline itself, not
  the assembled artifact package.
- **Compliance falls out of your security program, not alongside
  it.** — positions Efterlev's "evidence-first, FRMR-as-byproduct"
  shape vs traditional parallel GRC workflows.

Also adds **What it does** / **What it doesn't do** structural
sections and the **How it's built** layered architecture
explanation (intent → execution → outcome chain, multi-detector-per-KSI
defense-in-depth, structural hallucination defenses).

## [0.1.132] — 2026-05-15

**`efterlev shell` — interactive REPL (v1).** Compresses the 36-command
CLI surface into one persistent session. Workspace state always visible,
tab completion against the slash-command registry, state-aware next-step
hints, command history. Subtle styling: one accent color, no panels, no
emojis, plays nice with terminal scrollback.

### Added

- **`efterlev shell`** new top-level CLI command. Opens a session at
  `--target` (default cwd) showing an ASCII banner inspired by the
  efterlev.org logotype, then the workspace status block:

  ```
  Workspace  ~/repos/my-app
  Status     initialized · 23 evidence · 60 claims · last scan 2m ago
  Baseline   fedramp-20x-moderate
  Cost       $1.23 opus-4-7 · $0.04 haiku-4-5 · ($1.27 total)

  Next       /agent gap     classify evidence against KSIs
  ```

- **20 slash commands** dispatch to existing Typer entrypoints. Each
  has aliases (`/s` → `/scan`, `/g` → `/agent`, `?` → `/help`, etc.).
  Subprocess (not direct function call) on purpose: contains the
  `sys.exit` Typer commands use for error paths so they don't tear
  down the shell.

- **State-aware Next hint** picks the most useful next command from
  workspace state: `/init` when uninitialized; `/scan` when init done
  but no scan; `/agent gap` when evidence exists but no claims;
  `/report` when classifications exist.

- **Tab completion** against the slash-command registry (canonical
  names + aliases, with one-line descriptions in the dropdown).
  File-path completion for command arguments is a v1.x follow-up.

- **Command history** persisted to
  `~/.cache/efterlev/shell_history` so up/down arrow recalls across
  sessions. Reverse search (Ctrl+R) works.

- **Non-slash input gets a hint** rather than being interpreted —
  the surface stays unambiguous. `scan` (no slash) prints
  `commands start with / — try /help`.

### Architecture

- New `src/efterlev/shell/` package: `banner.py` (pure data),
  `state.py` (snapshot + suggestion), `layout.py` (rich rendering),
  `commands.py` (slash registry + dispatch), `session.py`
  (prompt_toolkit loop).
- New deps: `prompt_toolkit>=3.0,<4` (explicit pin; was transitive),
  `rich>=13.7,<15` (explicit pin; was transitive via Typer).
- **42 new tests**: 26 for state/snapshot/formatters, 14 for command
  registry/dispatch/parsing, 4 for banner shape invariants.

### Styling

Two colors total: a muted teal accent (`color(73)`) for command names,
`✓` confirmations, the `Next` hint. Mid-gray (`color(244)`) for labels
and metadata. Errors are unstyled bold red. No box-drawing UI chrome —
columns are aligned with whitespace, not boxes.

### What's NOT in v1

(Deliberate scope cuts so the first ship can be tight.)
- Shell escape (`!ls`) — defer until requested.
- Multi-line / heredoc input — defer.
- File-path completion for command args — defer.
- Custom themes — defer (one well-tuned default).
- Output redirection (`/scan > file.json`) — defer.
- AI conversational routing — separate arc if it ever ships.

## [0.1.131] — 2026-05-15

**CDK source-mode arc Stage 6 — graduation. Arc CLOSED.**

Final release of the Python CDK source-mode arc. Removes the
`--allow-cdk-py` opt-in flag from `efterlev scan`. CDK Python
source-mode now runs unconditionally — any `.py` file with
`aws_cdk.*` imports is parsed for supported constructs and emits
Evidence with file:line citations. Mirrors the v0.1.102 removal of
`--allow-cfn` after the CFN graduation arc.

### Removed

- `--allow-cdk-py` CLI flag from `efterlev scan`. Invoking with
  the flag will fail with `Error: No such option: --allow-cdk-py`;
  scripts should drop it.

### Changed

- `efterlev scan` now always invokes `scan_cdk_python` alongside
  Terraform, GitHub workflows, CFN, and Evidence Manifests. No
  customer ceremony beyond the existing `init → scan → agent gap →
  report` pipeline.
- LIMITATIONS.md updated to reflect graduated default-on status.

### Python CDK source-mode arc summary (v0.1.126 → v0.1.131)

The arc is now CLOSED:

- **v0.1.126** Stage 1 — Python parser + scan integration; `s3.Bucket`
- **v0.1.127** Stage 2 — KMS Key + EC2 SecurityGroup + IAM Role + CloudTrail Trail
- **v0.1.128** Stage 3 — Lambda + RDS DBInstance + DynamoDB + LogGroup
- **v0.1.129** Stage 4 — finisher batch (18 constructs across remaining service families)
- **v0.1.130** Stage 5 — design-rationale doc graduation (intentional narrowness)
- **v0.1.131** Stage 6 — `--allow-cdk-py` removed (this release)

**27 supported CDK Python constructs at graduation**, default-on,
emitting Evidence with `.py` file:line citations. Composes with
existing synth-mode (`cdk synth → CFN → scan`, default-on since
v0.1.99) for property-level depth.

### What's next

Python CDK source-mode arc is closed. **TypeScript CDK** is now a
separate post-graduation arc (parallel to how M1 closed → CDK
opened); not on the immediate roadmap.

## [0.1.130] — 2026-05-15

**CDK source-mode arc Stage 5 — design-rationale doc graduation.**
Documents CDK source-mode as INTENTIONALLY narrow (construct presence
+ `.py` file:line citations; deep-property L2 translation deliberately
not pursued). Compresses the remaining roadmap from ~6 stages to 1
more (graduation at v0.1.131). DECISIONS amendment captures the full
rationale.

### Why intentionally narrow

The next planned work was L2 property-shape translation
(`encryption=BucketEncryption.S3_MANAGED` → CFN `BucketEncryption: {
ServerSideEncryptionConfiguration: [...] }` → TF
`server_side_encryption_configuration { rule { ... } }`). After
shipping 27 constructs at v0.1.129 across 4 stages, reflection
surfaced this as wrong-shaped: re-implementing CDK's own
L2-to-CFN translator inside the parser duplicates the CDK runtime
imperfectly and indefinitely. The CDK runtime IS the correct
translator; existing synth-mode (`cdk synth → CFN → scan`,
default-on since v0.1.99) already invokes it.

The two modes are designed to compose:

- **Source-mode** (this arc): `.py` file:line citations + construct
  presence. Best for code-review and inventory artifacts. Land in
  the customer's actual code.
- **Synth-mode** (graduated v0.1.99-102): full property-shape depth
  via CFN translation. Best for compliance artifacts. Reviewer sees
  property-level evidence.

### Documentation changes

- LIMITATIONS.md gains a new "CDK Python source-mode is intentionally
  narrow" section explaining what source-mode does and doesn't do,
  with cross-reference to synth-mode for property-level depth.
- README "Scans" bullet adds CDK Python source-mode mention.
- DECISIONS 2026-05-15 amendment 1 captures the full rationale for
  not pursuing L2 translation, plus the compressed remaining
  roadmap (Stage 6 = graduation).

### What's deferred to post-graduation

- TypeScript CDK parser is now a separate post-graduation arc
  (parallel to how M1 closed → CDK opened), not part of the "CDK
  source-mode arc."
- L2 property translation: **not on the roadmap.** Customers needing
  property-level depth use synth-mode.

## [0.1.129] — 2026-05-15

**CDK source-mode arc Stage 4 — finisher batch.** Adds 18 constructs
in one batch covering remaining common AWS service families. Mirrors
the CFN gamma.2 batch 8 v0.1.93 finisher pattern.

### Added (18 constructs)

| CDK construct | CFN type |
|---|---|
| `aws_sns.Topic` | `AWS::SNS::Topic` |
| `aws_sqs.Queue` | `AWS::SQS::Queue` |
| `aws_efs.FileSystem` | `AWS::EFS::FileSystem` |
| `aws_eks.Cluster` | `AWS::EKS::Cluster` |
| `aws_ec2.Vpc` | `AWS::EC2::VPC` |
| `aws_secretsmanager.Secret` | `AWS::SecretsManager::Secret` |
| `aws_apigateway.RestApi` | `AWS::ApiGateway::RestApi` |
| `aws_apigatewayv2.HttpApi` | `AWS::ApiGatewayV2::Api` |
| `aws_autoscaling.AutoScalingGroup` | `AWS::AutoScaling::AutoScalingGroup` |
| `aws_elasticloadbalancingv2.ApplicationLoadBalancer` | `AWS::ElasticLoadBalancingV2::LoadBalancer` |
| `aws_cloudwatch.Alarm` | `AWS::CloudWatch::Alarm` |
| `aws_events.Rule` | `AWS::Events::Rule` |
| `aws_backup.BackupVault` | `AWS::Backup::BackupVault` |
| `aws_backup.BackupPlan` | `AWS::Backup::BackupPlan` |
| `aws_iam.User` | `AWS::IAM::User` |
| `aws_iam.Group` | `AWS::IAM::Group` |
| `aws_kinesis.Stream` | `AWS::Kinesis::Stream` |
| `aws_opensearchservice.Domain` | `AWS::OpenSearchService::Domain` |

### Coverage at Stage 4

**27 supported constructs** total. New `services_stack.py` 4th
fixture stack covers all 18 new constructs. Tree-walker test asserts
28 construct instances across 27 distinct CFN types.

Stage 5+ next: property-shape translation for L2 construct semantics
(`encryption=BucketEncryption.S3_MANAGED` → CFN `BucketEncryption: {...}`)
so detectors that read deep nested HCL block syntax fire on CDK
sources.

## [0.1.128] — 2026-05-15

**CDK source-mode arc Stage 3 — construct expansion batch 2.** Adds
four constructs covering compute, data, and observability families.

### Added

- 4 new entries in `src/efterlev/cdk_python/parser.py`:
  - `aws_lambda.Function` → `AWS::Lambda::Function`
  - `aws_rds.DatabaseInstance` → `AWS::RDS::DBInstance`
  - `aws_dynamodb.Table` → `AWS::DynamoDB::Table`
  - `aws_logs.LogGroup` → `AWS::Logs::LogGroup`
- `evals/fixtures/cdk-python-sample/infra/compute_stack.py` — third
  fixture stack covering the new constructs.
- 1 new parser test: `test_parse_compute_stack_finds_stage3_constructs`.
- Existing tree-walker test updated to assert 10 constructs across 9
  distinct CFN types.

### Coverage at Stage 3

9 supported constructs across 7 KSI families. Detectors that read
deep nested HCL block syntax still won't fire on raw CDK kwargs —
property-shape translation remains Stage N.

## [0.1.127] — 2026-05-15

**CDK source-mode arc Stage 2 — construct expansion batch 1.**
Adds four constructs to the Python CDK parser: `aws_kms.Key`,
`aws_ec2.SecurityGroup`, `aws_iam.Role`, `aws_cloudtrail.Trail`.
Mirrors v0.1.74-77 CFN property-mapping batches: each new construct
= one line in `_SUPPORTED_CONSTRUCTS` + fixture coverage + test.

### Added

- 4 new entries in `src/efterlev/cdk_python/parser.py`:
  - `aws_kms.Key` → `AWS::KMS::Key`
  - `aws_ec2.SecurityGroup` → `AWS::EC2::SecurityGroup`
  - `aws_iam.Role` → `AWS::IAM::Role`
  - `aws_cloudtrail.Trail` → `AWS::CloudTrail::Trail`
- `evals/fixtures/cdk-python-sample/infra/security_stack.py` — second
  fixture stack covering the new constructs. Uses both alias and
  direct import styles (IAM Role uses direct).
- 1 new test: `test_parse_security_stack_finds_stage2_constructs`.
- Existing fixture-walker test updated to assert 6 constructs (2
  buckets from Stage 1 + 4 new from Stage 2) across 5 distinct
  CFN types.

### Coverage at Stage 2

5 constructs across 5 KSI families (CNA-storage, CMA, CNA-RNT/network,
ELP, CMT). Detectors that read deep nested HCL block syntax still
won't fire on raw CDK kwargs — property-shape translation is Stage N.

### Roadmap progress

| Stage | Status |
|-------|--------|
| 1 | ✅ shipped (v0.1.126) — Python parser + scan integration |
| **2** | **✅ shipped (this release) — construct expansion batch 1** |
| 3+ | next — more constructs (lambda.Function, rds.DatabaseInstance, ...) |
| N | property-shape translation for L2 construct semantics |
| N+1 | labeled fixture + maintainer-validation |
| N+2 | graduation: `--allow-cdk-py` removed |
| N+3 | TypeScript parser |

## [0.1.126] — 2026-05-15

**CDK source-mode arc — Stage 1: Python CDK parser + scan integration.**
First substantive release of the next strategic arc. Adds direct parsing
of Python CDK source files (the value vs the existing `cdk synth → CFN
→ scan` synth-mode that ships at v0.1.99-102: source-mode preserves
file:line citations back to the customer's `.py` source rather than
landing them on CDK-generated CFN names).

### Added

- **`src/efterlev/cdk_python/`** — new top-level package mirroring
  `src/efterlev/cloudformation/`. Same parser → adapter → detector
  pipeline shape.
  - `parser.py` — Python stdlib `ast`-based walker. Handles both CDK
    import styles (`from aws_cdk import aws_s3 as s3` aliased and
    `from aws_cdk.aws_s3 import Bucket` direct). Returns `CdkConstruct`
    records with `source_file` + `source_line` for source-mode
    traceability.
  - `adapter.py` — converts `CdkConstruct` → `TerraformResource`,
    populating `SourceRef.line_start` (the source-mode value;
    contrast with CFN adapter which sets `line_start=None` per
    DECISIONS 2026-05-12 #4).
- **`scan_cdk_python` primitive** under
  `src/efterlev/primitives/scan/scan_cdk_python.py`. Sibling to
  `scan_cloudformation`, dispatches to the same `source="terraform"`
  detector library.
- **`efterlev scan --allow-cdk-py`** — opt-in flag for Stage 1
  (mirrors the v0.1.72-v0.1.98 `--allow-cfn` posture). Removed at end
  of CDK arc when source-mode is validated against a labeled fixture.
- **`evals/fixtures/cdk-python-sample/`** — synthetic 2-bucket CDK
  Python project. Hand-authored, zero proprietary content. Exercises
  both import styles.
- **24 new tests** in `tests/test_cdk_python_parser.py` (10) +
  `tests/test_cdk_python_scan.py` (4) — parser, adapter, scan
  primitive, both import styles, edge cases (excluded dirs, no CDK
  imports, syntax errors).

### Construct coverage at Stage 1

One construct: `aws_cdk.aws_s3.Bucket` → `AWS::S3::Bucket` →
`aws_s3_bucket`. Stage 2+ batches expand the construct table the same
way the CFN property-mapping table grew across v0.1.74-93.

### Why Python first (TS will follow at Stage 2+)

TypeScript is the ~70% majority of CDK usage; Python is ~15-20%. We
ship Python first because Python's stdlib `ast` keeps the
architecture-validation parser trivial — zero new deps, ~150 lines of
parser. Once the source-mode pipeline is validated end-to-end (Stage
1 = this release), TS adds a parser layer (Node.js subprocess or
tree-sitter) reusing all the downstream wiring.

### Roadmap (CDK source-mode arc)

| Stage | Scope |
|-------|-------|
| 1 (this release) | Python CDK parser + scan integration; `s3.Bucket` only; `--allow-cdk-py` opt-in |
| 2+ | Construct expansion batches (kms.Key, ec2.SecurityGroup, iam.Role, etc.) |
| N | Property-shape translation for L2 construct semantics (`encryption=BucketEncryption.S3_MANAGED` → CFN `BucketEncryption: {ServerSideEncryptionConfiguration: [...]}`) |
| N+1 | Labeled fixture + maintainer-validation (mirrors v0.1.81/v0.1.98 CFN validation pattern) |
| N+2 | Graduation: `--allow-cdk-py` removed, source-mode default-on |
| N+3 | TypeScript CDK parser (architecture reuses Stage 1's adapter + detector dispatch) |

## [0.1.125] — 2026-05-15

**Polish bundle: Gap Agent retry, release notes describe what shipped, doc cleanup.**
Four small wins responding to post-M1-graduation feedback.

### Added — Gap Agent built-in retry on validator-rejection (closes #327)

`GapAgent.run()` now retries once internally when the prompt-injection
guard rejects an LLM response containing a fabricated evidence ID
(DECISIONS 2026-05-09 pattern, ~1% per call on Haiku 4.5 per v0.1.118
maintainer-validation). Previously this retry lived in
`scripts/e2e_smoke.py` and `evals/harness`; moving it into the agent
absorbs the failure before customers see it.

- New `AgentValidatorRejectionError` (subclass of `AgentError`) so
  callers can selectively retry on this transient failure mode.
  `_validate_cited_ids` raises it instead of generic `AgentError`.
  Existing `except AgentError` callers continue to catch it.
- New `GapAgent._invoke_with_validator_retry()` helper wraps
  `_invoke_llm` + `_validate_cited_ids`. Single retry only —
  unbounded would mask deterministic prompt or fixture issues. A
  second consecutive rejection still raises.
- Diagnostic line on stderr cites DECISIONS 2026-05-09 and #327 so
  reviewers see what happened.
- 5 new tests in `tests/test_gap_agent_validator_retry.py` covering
  first-attempt success, retry-success, both-fail, two-attempt cap,
  subclass relationship.

### Added — release notes describe what shipped (closes #328)

`scripts/extract_changelog_section.py` pulls the matching CHANGELOG
section for a release tag; the `post-release-triage.yml` workflow now
prepends a "What's new in <tag>" block above the deterministic triage
output. Previously the GitHub Release page showed only triage
results — anyone landing on /releases/tag/<v> saw test status, not
features. Best-effort: if extraction fails, falls back to triage-only
with a CHANGELOG link.

- New script: `scripts/extract_changelog_section.py` (regex-based,
  handles `v` prefix or bare version, last-section-to-EOF case).
- 6 new tests in `tests/test_extract_changelog_section.py`.

### Fixed

- README "Status" paragraph said "one hundred and twenty-four patch
  releases" while the count was 125 (off-by-one, surfaced by external
  evaluator review of the v0.1.124 release page). Corrected to
  match the count line elsewhere in README.

### Documentation

- LIMITATIONS.md gains a new section explaining the in-agent retry
  for Haiku users (recommends Opus/Sonnet for production runs unless
  cost-sensitive; documents the 1-call observation rate from
  v0.1.118 validation).

## [0.1.124] — 2026-05-15

**M1 Stage 6 — runtime-evidence ingestion graduates to default-on.**
Final M1 release: removes the `--allow-import` opt-in flag from all
three import commands (`import-security-hub`, `import-config`,
`import-prowler`). Mirrors the v0.1.102 removal of `--allow-cfn` after
the CFN graduation arc — same pattern, same trade-off (opt-in safety
during arc development → default-on once the surface is validated).

### Removed

- `--allow-import` CLI flag from all three import commands. Invoking
  any of them no longer requires the gate; the existing arguments
  (`<findings.json>` / `<evaluations.json>`, `--target <path>`) are
  unchanged. **Customer-visible behavior change**: scripts that pass
  `--allow-import` will fail with `Error: No such option: --allow-import`.
  Such scripts should drop the flag.

### Changed

- CLI command help text and module docstrings (`src/efterlev/imports/__init__.py`,
  the three CLI handlers) updated to reflect graduated status.
- `evals/fixtures/security-hub-asff-extended/GROUND_TRUTH.yaml` example
  invocation no longer includes the flag.

### M1 arc summary (v0.1.113 → v0.1.124)

The runtime-evidence-ingestion arc is now CLOSED:
- **v0.1.113** Stage 1 — Security Hub ASFF parser + ingest (5 mappings)
- **v0.1.114** Stage 3 — AWS Config evaluations parser + ingest (5 mappings)
- **v0.1.115-117** infra: benchmark harness fixes + Bedrock backend wiring
  + Bedrock-Haiku validation at 99.1% / 100% across all 5 fixtures
- **v0.1.119-120** Stage 4 — extended labeled fixtures (ASFF + Config)
- **v0.1.121** Security Hub mapping batch (5 → 13 controls)
- **v0.1.122** AWS Config mapping batch (5 → 13 rules)
- **v0.1.123** Stage 5 — Prowler native ingestion (8 mappings)
- **v0.1.124** Stage 6 — `--allow-import` removed (this release)

The Gap Agent now reasons over IaC + Security Hub + Config + Prowler
evidence uniformly, with no opt-in gate. Coverage relative to FedRAMP
20x's 70% automated-validation threshold improves at the runtime layer
without any new customer ceremony beyond the existing
`init → scan → agent gap → report` pipeline.

### What's next

M1 is complete. Forward work focuses on customer-driven mapping
expansion (each ingest source ships an extensible YAML mapping table;
PRs that add new entries are welcome) and the next strategic arc TBD.

## [0.1.123] — 2026-05-15

**M1 Stage 5 — Prowler ingestion (`efterlev import-prowler`).**
Third runtime-evidence-import sibling alongside `import-security-hub`
(v0.1.113) and `import-config` (v0.1.114). Consumes Prowler's native
JSON output rather than its ASFF translation — Prowler-specific fields
(Risk, Remediation, ServiceName, ResourceTags) come through, and
customers running Prowler in Comp-AI-style workflows skip the ASFF
translation step.

### Added

- **`src/efterlev/imports/prowler/`** — new sibling package mirroring
  `imports/security_hub/` and `imports/config/`. Same parser → mapping
  → ingest → Evidence pattern.
  - `parser.py` — `parse_prowler_document()` accepts both top-level
    array (`prowler aws -M json` default) and `{"findings": [...]}`
    wrapper shapes. Same soft-schema-drift tolerance as ASFF + Config
    parsers.
  - `mapping.yaml` — initial 8 mappings covering high-impact Prowler
    checks across CNA / IAM / MLA / RPL themes:
    `ec2_securitygroup_default_restrict_traffic` → KSI-CNA-RNT,
    `iam_root_hardware_mfa_enabled` → KSI-IAM-MFA,
    `s3_bucket_public_access` → KSI-CNA-RNT,
    `cloudtrail_multi_region_enabled` → KSI-MLA-CMA,
    `iam_customer_unattached_policy_no_administrative_privileges` → KSI-IAM-ELP,
    `ec2_securitygroup_allow_ingress_from_internet_to_any_port` → KSI-CNA-RNT,
    `vpc_flow_logs_enabled` → KSI-MLA-LET,
    `rds_instance_deletion_protection` → KSI-RPL-ABO.
  - `mapping.py` — `load_prowler_mapping()` + `ProwlerMapping.lookup()`.
  - `ingest.py` — `ingest_prowler` primitive. Skips MANUAL status
    (Prowler's "this check requires human inspection"); emits
    Evidence for both PASS + FAIL.
- **`efterlev import-prowler <findings.json> --target . --allow-import`**
  — new CLI command. Same `--allow-import` opt-in posture as the
  Security Hub + Config siblings; flag removed at v0.1.124 graduation.
- **`evals/fixtures/prowler-sample/findings.json`** — synthetic 6-finding
  sample (4 mapped + 1 MANUAL skipped + 1 unmapped) hand-crafted from
  Prowler v4 output schema; zero Prowler invocation.
- **`tests/test_prowler_import.py`** — 13 tests covering parser, mapping,
  ingest, override seam, MANUAL-skip, unmapped-skip semantics.

### Why ingest Prowler natively (not via ASFF translation)

Prowler can emit ASFF too, which `import-security-hub` would happily
consume. Reasons to add a native path:
- Native Prowler JSON has richer fields (CheckType, Severity, ResourceTags,
  Risk, Remediation) that the ASFF translation drops.
- Customers running Prowler often have the native JSON available
  already; avoiding an ASFF translation step is friction-removal.
- Native ingest lets us evolve the Prowler-specific Evidence content
  shape independently of the ASFF mapping table.

### M1 arc roadmap (one release remaining)

- v0.1.113-114: Stage 1 + 3 ingest (shipped)
- v0.1.119-120: Stage 4 labeled fixtures (shipped)
- v0.1.121-122: Mapping batches expand 5 → 13 each (shipped)
- **v0.1.123**: Stage 5 — Prowler ingestion (this release)
- v0.1.124: Stage 6 — graduate to default-on (`--allow-import` removed)

---

## [0.1.122] — 2026-05-15

**M1 mapping batch — AWS Config coverage 5 → 13 rules.**
Mirrors v0.1.121's Security Hub batch for AWS Config managed rules.
Adds 8 high-confidence Config rule → KSI mappings spanning 4 themes
(IAM via password-policy + MFA rules, MLA via cloudtrail + flow-logs,
RPL via deletion-protection, CNA via SSH).

### Added (8 new Config mappings)

| Config Rule | KSIs | Controls | Strength |
|--|--|--|--|
| `vpc-flow-logs-enabled` | KSI-MLA-LET | au-12 | high |
| `cloudtrail-encryption-enabled` | KSI-MLA-CMA | au-9 | high |
| `cloudtrail-log-file-validation-enabled` | KSI-MLA-CMA | au-10 | high |
| `rds-instance-deletion-protection-enabled` | KSI-RPL-ABO | cp-9 | high |
| `iam-password-policy` | KSI-IAM-APM | ia-5 | high |
| `iam-user-mfa-enabled` | KSI-IAM-MFA | ia-2 | high |
| `mfa-enabled-for-iam-console-access` | KSI-IAM-MFA | ia-2 | high |
| `incoming-ssh-disabled` | KSI-CNA-RNT | sc-7 | high |

### Compatibility

- **v0.1.120 Config labeled fixture stays valid.** None of the 8 new
  mappings collide with the v0.1.120 fixture's intentionally-unmapped
  list (ec2-imdsv2-check, rds-storage-encrypted,
  lambda-function-public-access-prohibited, kms-cmk-not-scheduled-for-deletion,
  vpc-default-security-group-closed).
- Mapping-count test floor raised from `>= 5` to `>= 13`.

### M1 arc roadmap (updated)

- v0.1.113-114: Stage 1 + 3 ingest (shipped)
- v0.1.119-120: Stage 4 labeled fixtures (shipped)
- v0.1.121: Mapping batch — Security Hub 5 → 13 (shipped)
- **v0.1.122**: Mapping batch — AWS Config 5 → 13 (this release)
- v0.1.123: Stage 5 — Prowler ingestion
- v0.1.124: Stage 6 — graduate to default-on (`--allow-import` removed)

---

## [0.1.121] — 2026-05-15

**M1 mapping batch — Security Hub coverage 5 → 13 controls.**
First mapping-table expansion since v0.1.113 shipped the initial 5
high-impact mappings. Adds 8 more high-confidence ASFF generator-id
→ KSI mappings spanning 4 additional FRMR themes (CMT-adjacent via
EC2.18, MLA via CloudTrail.2 + CloudTrail.4 + EC2.6, CNA via Config.1
+ EC2.18, RPL via RDS.6 + RDS.7, SVC via SecretsManager.1).

### Added (8 new ASFF mappings)

| Generator ID | Title | KSIs | Controls | Strength |
|--|--|--|--|--|
| `CloudTrail.2` | Encryption at rest enabled | KSI-MLA-CMA | au-9 | high |
| `CloudTrail.4` | Log file validation enabled | KSI-MLA-CMA | au-10 | high |
| `Config.1` | AWS Config enabled with service-linked role | KSI-CNA-EIS | ca-7 | high |
| `EC2.6` | VPC flow logging enabled | KSI-MLA-LET | au-12 | high |
| `EC2.18` | SGs only allow unrestricted incoming for authorized ports | KSI-CNA-RNT | sc-7 | high |
| `RDS.6` | Enhanced monitoring configured | KSI-RPL-ABO | cp-9 | medium |
| `RDS.7` | DB cluster deletion protection enabled | KSI-RPL-ABO | cp-9 | high |
| `SecretsManager.1` | Automatic rotation enabled | KSI-SVC-ASM | ia-5 | high |

### Why these 8 specifically

Picked for **high-confidence KSI alignment** — each control's NIST
800-53 mapping is in efterlev's existing FRMR catalog (`au-9`,
`au-10`, `ca-7`, etc.) and the KSI is unambiguous. Skipped controls
where the KSI fit was borderline (e.g., RDS.3 encryption-at-rest
doesn't have a clean FRMR-side KSI for "data at rest" specifically).

### Compatibility

- **v0.1.119 ASFF labeled fixture stays valid.** None of the 8 new
  mappings collide with the v0.1.119 fixture's intentionally-unmapped
  list (Lambda.5, RDS.13, Inspector.1, GuardDuty.1, SSM.1).
- **v0.1.119 ground-truth test passes unchanged.** The fixture's
  expected behavior is unchanged because the 8 new mappings refer
  to controls that don't appear in the fixture's findings.
- Mapping-count test floor raised from `>= 5` to `>= 13` to lock in
  the v0.1.121 baseline.

### M1 arc roadmap (updated)

- v0.1.113: Stage 1 — Security Hub ASFF ingestion (shipped)
- v0.1.114: Stage 3 — AWS Config evaluations ingestion (shipped)
- v0.1.119: Stage 4 — labeled extended ASFF fixture (shipped)
- v0.1.120: Stage 4 (continued) — labeled extended Config fixture (shipped)
- **v0.1.121**: Mapping batch — Security Hub 5 → 13 controls (this release)
- v0.1.122: Mapping batch — AWS Config 5 → ~13 rules
- v0.1.123: Stage 5 — Prowler ingestion
- v0.1.124: Stage 6 — graduate to default-on (`--allow-import` removed)

---

## [0.1.120] — 2026-05-15

**M1 Stage 4 (continued) — labeled extended Config fixture (config-evaluations-extended).**
Mirrors v0.1.119's ASFF labeled-fixture pattern for AWS Config
evaluations (the `ingest_config` primitive shipped at v0.1.114). Same
20-evaluation hand-crafted shape, same 6-test ground-truth-comparison
suite, same regression-gate posture. Zero LLM spend.

### Added

- **`evals/fixtures/config-evaluations-extended/evaluations.json`** —
  20 hand-crafted Config evaluations:
  - 5 mapped rules (encrypted-volumes, s3-bucket-public-read-prohibited,
    s3-bucket-public-write-prohibited, iam-root-access-key-check,
    cloudtrail-enabled) × 3 evaluations each = 15 mapped
  - 5 unmapped rules (ec2-imdsv2-check, rds-storage-encrypted,
    lambda-function-public-access-prohibited, kms-cmk-not-scheduled-for-deletion,
    vpc-default-security-group-closed) × 1 evaluation each = 5 unmapped
  - 1 of the 15 mapped (encrypted-volumes #3) carries
    `ComplianceType=INSUFFICIENT_DATA` to exercise the no-signal skip path
  - Net: 14 Evidence emitted, 1 INSUFFICIENT_DATA-skipped,
    5 unmapped-skipped
  - Mix of COMPLIANT + NON_COMPLIANT across emitted findings
- **`evals/fixtures/config-evaluations-extended/GROUND_TRUTH.yaml`** —
  declarative expected ingest output, same shape as the ASFF version
- **`tests/test_config_extended_fixture.py`** — 6 ground-truth
  comparison tests (mirrors `test_security_hub_extended_fixture.py`)

### M1 arc roadmap (updated)

- v0.1.113: Stage 1 — Security Hub ASFF ingestion (shipped)
- v0.1.114: Stage 3 — AWS Config evaluations ingestion (shipped)
- v0.1.119: Stage 4 — labeled extended ASFF fixture (shipped)
- **v0.1.120**: Stage 4 (continued) — labeled extended Config fixture (this release)
- v0.1.121-122: mapping batches expand to ~30 each
- v0.1.123: Stage 5 — Prowler ingestion
- v0.1.124: Stage 6 — graduate to default-on (`--allow-import` removed)

---

## [0.1.119] — 2026-05-15

**M1 Stage 4 — labeled extended ASFF fixture (security-hub-asff-extended).**
The v0.1.113 sample fixture (4 findings) exercised the parser path but was
too small to validate mapping coverage and skip semantics under realistic
volume. v0.1.119 ships a 20-finding hand-crafted fixture synthesized from
AWS published per-control example findings (per the user's 2026-05-15
decision to use AWS-docs examples rather than fund a real AWS sandbox),
plus a `GROUND_TRUTH.yaml` that locks the expected ingest output, plus
6 ground-truth-comparison tests.

### Added

- **`evals/fixtures/security-hub-asff-extended/findings.json`** — 20
  hand-crafted ASFF findings:
  - 5 mapped controls (EC2.2, IAM.6, S3.1, CloudTrail.1, KMS.1) × 3
    findings each = 15 mapped
  - 5 unmapped controls (Lambda.5, RDS.13, Inspector.1, GuardDuty.1,
    SSM.1) × 1 finding each = 5 unmapped
  - 1 of the 15 mapped (IAM.6 #3) carries `Compliance.Status=NOT_AVAILABLE`
    to exercise the no-signal skip path
  - Net: 14 Evidence records emitted, 1 NOT_AVAILABLE-skipped,
    5 unmapped-skipped
  - Mix of FAILED + PASSED across emitted findings to exercise both
    evidence-of-gap and evidence-of-implementation flows
- **`evals/fixtures/security-hub-asff-extended/GROUND_TRUTH.yaml`** —
  declarative expected ingest output: aggregate counts, skipped-unmapped
  generator-id list, per-generator-id (count + KSI list + control list).
- **`tests/test_security_hub_extended_fixture.py`** — 6 ground-truth
  comparison tests:
  - aggregate counts (`findings_total` / `evidence_emitted` /
    `skipped_status_not_available`)
  - skipped-unmapped generator-id list match
  - per-generator-id (count + ksis_evidenced + controls_evidenced)
  - no unexpected generator-ids emitted
  - required content fields present on every Evidence record
  - PASSED + FAILED both represented in emitted output

### Why ground-truth tests for a deterministic primitive

The ingest is deterministic (parser + mapping table lookup, no LLM), so
"validation" is structural rather than statistical. The value of the
labeled fixture isn't a precision/recall measurement (those are 100%
by construction) — it's a **regression gate**: when v0.1.115.x batches
expand the mapping table, this test will fail until the GROUND_TRUTH.yaml
is updated to reflect the new coverage. Failing here catches "we
expanded the table but forgot to refresh the labeled fixture."

### M1 arc roadmap (updated)

- v0.1.113: Stage 1 — Security Hub ASFF ingestion (shipped)
- v0.1.114: Stage 3 — AWS Config evaluations ingestion (shipped)
- **v0.1.119**: Stage 4 — labeled extended ASFF fixture (this release)
- v0.1.120: Stage 4 (continued) — labeled extended Config fixture
- v0.1.121-122: mapping batches expand to ~30 each
- v0.1.123: Stage 5 — Prowler ingestion
- v0.1.124: Stage 6 — graduate to default-on (`--allow-import` removed)

---

## [0.1.118] — 2026-05-15

**Bedrock-Haiku validation extended to all 5 labeled fixtures + customer-facing GovCloud
recommendation in README + docs/deploy-govcloud-ec2.md.**
v0.1.117 validated Bedrock-Haiku-4.5 against the 2 CFN fixtures (45/45 = 100%).
v0.1.118 extends that to the full 5-fixture scope (matches the v0.1.69 baseline):
**111/112 = 99.1% precision + 100% recall** across csp-starter-cfn, aws-vpc-cfn,
aws-vpc-tfm, aws-s3-bucket-tfm, aws-lambda-tfm. Substantively equivalent to the
Anthropic-API baseline of 111/111 = 100%; the single miss is a borderline
over-classification of KSI-CNA-MAT on aws-lambda-tfm (partial vs ground-truth
not_implemented — drift band, not systematic failure).

### Added

- `docs/benchmark-2026-05.md` — full 5-fixture results table with per-fixture
  precision + recall; v0.1.117 CFN-only section retained as superseded-by
  diff history.
- `docs/deploy-govcloud-ec2.md` — recommended-model section pinning
  `us.anthropic.claude-haiku-4-5-20251001-v1:0` as the validated default,
  with explicit caveats on why GPT-OSS + Nemotron are NOT recommended.
- README.md "Two LLM backends" bullet now leads with the validated
  numbers (was generic "GovCloud-deployable").

### Customer-recommendation table (from CHANGELOG v0.1.117, validated by v0.1.118 measurement)

| Goal | Model | Validated? |
|--|--|--|
| **GovCloud + max quality + cheap** | `us.anthropic.claude-haiku-4-5-20251001-v1:0` | **111/112 (99.1%) across 5 fixtures** |
| GovCloud + max quality regardless of cost | `us.anthropic.claude-opus-4-7` | (assumed; same model class as Anthropic API baseline) |
| Non-GovCloud + cheap | `claude-haiku-4-5` (Anthropic API) | 111/111 (100%) — v0.1.69 + v0.1.81 + v0.1.98 baselines |
| Remediation Agent (always) | `claude-opus-4-7` | (no precision metric for diff generation) |

### Total maintainer cost across the 5-fixture validation

- v0.1.117 CFN runs (csp-starter-cfn + aws-vpc-cfn): ~$0.80
- v0.1.118 TF runs (aws-vpc-tfm + aws-s3-bucket-tfm + aws-lambda-tfm): ~$1.20
- **Total: ~$2.00** to definitively answer "is Bedrock Claude Haiku 4.5 a viable
  GovCloud-deployable cheap model" with maintainer-validated numbers. Yes.

---

## [0.1.117] — 2026-05-15

**Bedrock model evaluation — Anthropic Claude Haiku 4.5 validated at 100/100; GPT-OSS-120B failed.**
Three Bedrock models evaluated end-to-end against the labeled CFN
fixtures (csp-starter-cfn + aws-vpc-cfn) using `evals/cli.py run`
(precision+recall vs ground truth, the v0.1.69/v0.1.81/v0.1.98
methodology). Real numbers in `docs/benchmark-2026-05.md`. Total
maintainer cost to definitively answer the GovCloud-cheap-model
question: ~$2.20.

### Findings

| Backend / Model | Combined precision | GovCloud | Recommendation |
|--|--|--|--|
| **bedrock / Claude Haiku 4.5** | **45/45 (100%)** | **✓** | **Default for GovCloud customers** |
| anthropic / Claude Haiku 4.5 | 44/44 (100%) | ✗ | Default for non-GovCloud |
| bedrock / Nemotron Super 120B | (precision not measured; benchmark missed 1 KSI) | ✓ | Speed-optimized only |
| bedrock / GPT-OSS-120B | 12/45 (27%) | ✓ | **NOT recommended** |

### Headline

**Anthropic Claude Haiku 4.5 on Bedrock** is the GovCloud-deployable +
maintainer-validated cheap model (Bedrock inference profile
`us.anthropic.claude-haiku-4-5-20251001-v1:0`, ~$0.40 per fixture
eval). Same model that hit 100/100 via Anthropic API at v0.1.81 +
v0.1.98 — the API → Bedrock switch is quality-neutral.

### Why GPT-OSS-120B failed (worth documenting for future model evaluation)

GPT-OSS-120B emitted all 60 KSI verdicts (looked good in the
benchmark's completeness count) but **27% precision vs ground truth**.
Pattern: defaults everything-without-evidence to `not_implemented`,
missing the `evidence_layer_inapplicable` distinction efterlev
pioneered for procedural KSIs (AFR / CED / INR themes). The benchmark's
"60/60 classified" was completeness, not correctness. **Lesson:
maintainer-validation against ground truth is the gate, not benchmark
classification count.**

### Added

- Pricing entries for `claude-haiku-4-5` (Anthropic API, $1/$5 MTok)
  and `us.anthropic.claude-haiku-4-5-20251001-v1:0` (Bedrock inference
  profile, same rate).
- Updated `docs/benchmark-2026-05.md` with the full evaluation matrix +
  graduated recommendations.

### Customer-recommendation table (graduated, validated)

| Goal | Model |
|--|--|
| **GovCloud-deployable + max quality + cheap** | `us.anthropic.claude-haiku-4-5-20251001-v1:0` (Bedrock) |
| GovCloud + max quality regardless of cost | `us.anthropic.claude-opus-4-7` (Bedrock) |
| Non-GovCloud + max quality regardless of cost | `claude-opus-4-7` (Anthropic API) |
| Non-GovCloud + cheap | `claude-haiku-4-5` (Anthropic API) |
| **Remediation Agent (always)** | `claude-opus-4-7` |

### Eval-harness note

Both Bedrock-Haiku eval runs hit a Haiku flake in the documentation
agent (fabricated evidence ID, prompt-injection guard caught it) —
same well-documented v0.1.x flake. Gap stage (where precision+recall
is measured) succeeded; doc + poam stages failed afterward. Precision
extracted directly from gap.json; metrics still authoritative.

---

## [0.1.116] — 2026-05-15

**Critical fix — agents now honor workspace `[llm].backend` config.**
v0.1.115 wired `--llm-backend bedrock` through the benchmark harness's
`init` call, but the FIRST Nemotron dispatch still failed with `401
Unauthorized from Anthropic API`. Root cause: the CLI agent commands
construct `GapAgent(model=config.llm.model)` etc. but DON'T pass a
`client=` arg, so the agents fall back to `get_default_client()` which
walks up from cwd looking for `.efterlev/config.toml` — and the CLI
runs in the caller's cwd (typically the efterlev source repo), not
the workspace, so the workspace's `[llm].backend = "bedrock"` is
silently ignored.

This bug had been present since the `[llm].backend` config field was
introduced. Live-impact: Bedrock-backend customers running `report run`
were silently routed to the Anthropic API (failing on missing API key
or — worse — leaking traffic across their FedRAMP boundary). Surfaced
by the v0.1.115 Bedrock + Nemotron benchmark dispatch, which is exactly
the scenario the boundary discipline is designed to catch.

### Fixed

- **All three agent CLI commands** (`agent gap`, `agent document`,
  `agent remediate`) now construct the LLM client from the workspace
  config:
  ```python
  agent = GapAgent(
      model=config.llm.model,
      client=get_client_from_config(config.llm),
  )
  ```
  No silent fallback to anthropic when the workspace says bedrock.
- Per-agent CLI invocation now respects `--llm-backend`/`--llm-model`
  overrides too (via the workspace config init wrote at the start of
  the pipeline).

### Validated against the original failure mode

Re-ran the v0.1.115 Bedrock + Nemotron benchmark after the fix; ran
clean. Numbers now in `docs/benchmark-2026-05.md`.

### Pre-existing customers

Anyone running efterlev with `[llm].backend = "bedrock"` in their
workspace config should upgrade to v0.1.116. Pre-fix versions silently
routed agent traffic to the Anthropic API regardless of backend
setting; post-fix versions actually use the configured backend.

---

## [0.1.115] — 2026-05-15

**Benchmark bug fixes + Bedrock backend wiring + NVIDIA Nemotron pricing.**
The v0.1.114 benchmark dispatch surfaced 4 bugs that masked real cost
data. Fixed all 4 + added support for non-Claude Bedrock models
(starting with NVIDIA Nemotron Super 120B for the GovCloud-aligned
cheap-model story). No release pipelines run by default; the benchmark
workflow remains opt-in via `gh workflow run benchmark-dispatch.yml`.

### Fixed

- **`--llm-model` is no longer a no-op.** `scripts/benchmark.py`
  previously set `EFTERLEV_LLM_BACKEND/MODEL` env vars that agents
  don't read, so requesting `--model haiku` actually ran on the agent
  defaults (Opus + Sonnet). The harness now invokes `efterlev init
  --llm-backend X --llm-model Y --force` first, then `report run
  --skip-init` — model selection takes effect via workspace config.
  This matters: the v0.1.114 dispatch cost ~$60 because of this bug;
  with the fix, the same Haiku run costs ~$0.30.
- **Estimated cost is no longer always $0.** `benchmark.py` was
  calling `estimate_cost_usd(pricing_obj, ...)` but the function
  signature is `(model_id_str, ...)`. Fix: pass the model ID string,
  let `estimate_cost_usd` do the lookup internally.
- **`poam_md` artifact detection works.** Glob was `poam-*.md` but
  the actual file lives at `.efterlev/reports/poam/poam-<ts>.md`.
  Fixed glob to `poam/poam-*.md`.
- **Artifact upload reaches the actual files.** Workflow staging step
  (`cp -r ${RUNNER_TEMP}/...`) wasn't running. Switched the upload-
  artifact path directly to `${{ runner.temp }}/...` instead — no
  staging step needed.

### Added

- **NVIDIA Nemotron pricing entries** under `efterlev.llm.pricing`:
  - `nvidia.nemotron-super-3-120b` — $0.15/MTok in, $0.65/MTok out
  - `nvidia.nemotron-3-nano-30b-a3b` — $0.06/$0.24
  - `nvidia.nemotron-nano-2` — $0.06/$0.23
- **`is_bedrock_model()` recognizes NVIDIA + Meta Bedrock prefixes**
  (`nvidia.`, `us.nvidia.`, `meta.`, `us.meta.`).
- **Benchmark workflow takes `backend` + `region` inputs.** `bedrock`
  backend automatically configures AWS OIDC role (uses
  `secrets.AWS_BEDROCK_ROLE_ARN` if configured; absence fails fast
  with a clear error).
- **Benchmark CLI takes `--region`.** Required when `--backend bedrock`.

### Architecture context: why NVIDIA Nemotron specifically

Per the v0.1.114 follow-up discussion:
- Bedrock = GovCloud-deployable. Customers can use this in their
  FedRAMP boundary; Anthropic API direct cannot.
- Nemotron Super 120B (12B active params, MoE) is roughly Sonnet-class
  quality at ~50× lower cost than Opus 4.7. Validates the Gap Agent
  + Documentation Agent classification quality on a non-Claude model.
- **Remediation Agent stays on Opus** — Terraform diff generation
  needs the strongest code reasoning. Customer-driven whether to
  swap that later.

### How to dispatch (after this release)

**Local** (uses your AWS profile, no GitHub Actions setup needed):

```bash
uv run python scripts/benchmark.py \
    --fixture evals/fixtures/csp-starter-cfn \
    --model nvidia.nemotron-super-3-120b \
    --backend bedrock \
    --region us-east-1 \
    --runs 1
```

**CI** (requires `AWS_BEDROCK_ROLE_ARN` secret configured first):

```bash
gh workflow run benchmark-dispatch.yml \
    -f fixture=evals/fixtures/csp-starter-cfn \
    -f backend=bedrock \
    -f llm_model=nvidia.nemotron-super-3-120b \
    -f region=us-east-1 \
    -f runs=3
```

---

## [0.1.114] — 2026-05-15

**M1 Stage 3 — AWS Config evaluations ingestion (`efterlev import-config`).**
Sibling to v0.1.113's Security Hub ingestion. Same architecture
(parser → mapping → ingest), different runtime tool. Both ingest paths
write into the same provenance store; the Gap Agent reasons over IaC +
Security Hub + Config evidence uniformly.

### Added

- **`src/efterlev/imports/config/`** — new sibling package to
  `imports/security_hub/`. Mirrors the Stage 1 architecture:
  - `parser.py` — `parse_config_document()` accepts both AWS Config
    JSON shapes (`{"EvaluationResults": [...]}` from
    `aws configservice get-compliance-details-by-config-rule`,
    bare-array from EventBridge export). Same soft-schema-drift
    tolerance as the ASFF parser.
  - `mapping.yaml` — initial 5 mappings covering the highest-impact
    AWS-managed Config Rules: `encrypted-volumes`,
    `s3-bucket-public-read-prohibited`,
    `s3-bucket-public-write-prohibited`, `iam-root-access-key-check`,
    `cloudtrail-enabled` → KSI-CNA-OFA, KSI-CNA-RNT, KSI-IAM-ELP,
    KSI-MLA-CMA.
  - `mapping.py` — `load_config_mapping()` + `ConfigMapping.lookup()`.
  - `ingest.py` — `ingest_config` primitive.
- **`efterlev import-config <evaluations.json> --target . --allow-import`**
  — new CLI command. Same opt-in posture as `import-security-hub`.
- **`evals/fixtures/config-evaluations-sample/`** — synthetic Config
  evaluations sample (5 evaluations × 4 mapped + 1 unmapped). Hand-
  crafted from the AWS Config spec; zero AWS spend.
- **`tests/test_config_import.py`** — 13 tests covering parser,
  mapping loader, ingest primitive, mapping override (test seam),
  unmapped-skip, INSUFFICIENT_DATA-skip semantics.

### Why Config + Security Hub coexist (not "pick one")

Security Hub and AWS Config provide overlapping but distinct evidence:
- Security Hub aggregates findings from many sources (Config, Inspector,
  GuardDuty, third-party vendors). Standards-aware (FedRAMP, NIST 800-53).
- AWS Config provides per-rule, per-resource compliance evaluations
  with explicit annotations. Better for resource-level audit trails.

Customers running both tools (the typical FedRAMP-pursuing AWS shop)
get richer evidence by importing from both. v0.1.114 makes that
trivial.

### M1 arc roadmap (updated)

- v0.1.113: Stage 1 — Security Hub ASFF ingestion (shipped)
- **v0.1.114** (this release): Stage 3 — AWS Config ingestion
- v0.1.115: Mapping batches expand to ~15 each (Security Hub + Config)
- v0.1.116: Labeled fixture + maintainer-validation
- v0.1.117: Stage 5 — Prowler ingestion
- v0.1.118: Graduate to default-on

---

## [0.1.113] — 2026-05-15

**M1 Stage 1 — AWS Security Hub ASFF ingestion (`efterlev import-security-hub`).**
First step in the M1 runtime-evidence-ingestion arc. Closes the gap
between the README's "60% from union of layers" math claim and a real
workflow — customers no longer hand-author Evidence Manifests citing
their Security Hub findings; the ingest does it from ASFF JSON.

### Added

- **`src/efterlev/imports/`** — new top-level package for runtime-evidence
  imports. Detectors PARSE local IaC; imports CONSUME pre-existing
  runtime tool output. Both layers emit Evidence into the same
  provenance store, so the Gap Agent reasons over IaC + runtime
  uniformly.
- **`src/efterlev/imports/security_hub/`** — ASFF parser + mapping
  table loader + ingest primitive:
  - `parser.py` — `parse_asff_document()` accepts both ASFF shapes
    (`{"Findings": [...]}` from `aws securityhub get-findings`,
    bare-array from EventBridge export). Tolerates soft schema drift
    (skips un-validatable findings rather than aborting).
  - `mapping.yaml` — initial 5 mappings covering AWS Foundational
    Security Best Practices controls EC2.2, IAM.6, S3.1, CloudTrail.1,
    KMS.1 → KSI-CNA-RNT, KSI-IAM-MFA, KSI-MLA-CMA, KSI-IAM-ELP.
  - `mapping.py` — `load_asff_mapping()` + `AsffMapping.lookup()`.
  - `ingest.py` — `ingest_security_hub` primitive. Deterministic
    transform: parse → look up GeneratorId → emit Evidence record.
- **`efterlev import-security-hub <findings.json> --target . --allow-import`**
  — new CLI command. Behind `--allow-import` opt-in flag (mirrors the
  CFN `--allow-cfn` pattern; removed at end of M1 arc).
- **`evals/fixtures/security-hub-asff-sample/`** — synthetic ASFF
  sample (4 findings × 3 mapped + 1 unmapped, exercising the unmapped-
  skip path). Hand-crafted from the ASFF spec; zero AWS spend.
- **`tests/test_security_hub_import.py`** — 15 tests covering the
  parser, mapping loader, ingest primitive, mapping override (test
  seam), unmapped-skip semantics, NOT_AVAILABLE-skip semantics.

### Honest scope at v0.1.113

- **File-based ingestion only.** No AWS API calls. Customer runs
  `aws securityhub get-findings`; Efterlev consumes the JSON. **Local-
  first posture intact.** Per the v0.1.111 roadmap "Defer or refuse"
  table, live cloud API scanning is explicitly out of scope.
- **5 mappings ship.** Property-mapping table batches expand in
  v0.1.113.x as additional Security Hub standards get characterized.
  Same iterative pattern as the CFN property-mapping batches 1-8.
- **Behind `--allow-import` flag.** Mirrors `--allow-cfn` (v0.1.72-
  v0.1.99). Graduates to default-on at the end of the M1 arc when
  Stage 5 (Prowler) ships and the validation fixture lands.

### What this catches that the existing layers don't

- **Runtime drift.** A Terraform-applied resource that drifted via
  console click won't show in IaC scan but WILL show in Security Hub
  findings. Importing those findings as Evidence makes the drift
  visible to the Gap Agent.
- **AWS-managed-control evidence.** Some controls (e.g., root-user MFA)
  are account-level, not resource-level — IaC doesn't declare them but
  Security Hub checks them. Ingestion brings these into the FRMR/POA&M
  flow.
- **The 70% threshold workflow.** The README correctly identifies
  AWS-native as the runtime evidence layer covering ~14 KSIs. Before
  v0.1.113, those KSIs required hand-authored Evidence Manifests.
  Now: pipe the JSON in.

### M1 arc roadmap

- **v0.1.113** (this release): Stage 1 — Security Hub ASFF ingestion.
- **v0.1.114-115**: Stages 2-3 — mapping-table batches expand to
  ~30 high-impact controls; AWS Config ingestion (`import-config`).
- **v0.1.116**: Stage 4 — labeled fixture + maintainer-validation
  dispatch (mirrors the CFN graduation arc validation pattern).
- **v0.1.117**: Stage 5 — Prowler ingestion (`import-prowler`).
- **v0.1.118**: Stage 6 — graduate to default-on; deprecate
  `--allow-import`.

---

## [0.1.112] — 2026-05-15

**M2 — time-to-FRMR benchmark harness + methodology.**
First step in the post-OSCAL-arc roadmap. Ships the reproducible
harness; first published numbers land in v0.1.112.x once a maintainer
dispatches the workflow against the labeled-fixture matrix.

### Why ship the harness first (numbers later)

Without a benchmark in place, every later release is unmeasured —
we can't tell if M1 (runtime-evidence ingestion) makes the pipeline
slower or faster, or whether a prompt change shifted token usage by
10% or 50%. Shipping the harness first means the M1 arc lands into a
measurable baseline.

### Added

- **`scripts/benchmark.py`** — reproducible Python harness. Takes a
  fixture path + model + run count; runs the full `efterlev report
  run` pipeline against a fresh workspace; captures wall-clock + LLM
  token usage + estimated cost from `receipts.log`; outputs structured
  JSON under `.benchmark-results/<timestamp>/summary.json` with
  per-run + aggregate (mean, median, p95, max) for wall-clock + cost.
- **`.github/workflows/benchmark-dispatch.yml`** — workflow_dispatch
  only (mirrors `eval-harness-cfn.yml`). Maintainer-dispatched
  measurement; uploads `.benchmark-results/**` as a 90-day artifact.
- **`docs/benchmark-2026-05.md`** — methodology + reproducibility
  recipe + fixture inventory + comparison-framing discipline.
  Result tables to be populated by maintainer dispatches.

### What this measures

Wall-clock from `efterlev report run` invocation to the last artifact
landing on disk (OSCAL CD JSON, since v0.1.111). Plus LLM token usage
+ estimated cost, KSI classifications produced, and artifact-presence
checks (regression guard against silent failure modes).

### What this is NOT

Not authorization timeline. Not customer-review time. Not anything
beyond fixture-shaped tool runtime. The doc explicitly carries this
caveat in the same surface as the numbers — the same LIMITATIONS
discipline that applies to every Efterlev claim.

### Why N=3 default, Haiku 4.5 default

N=3 is the smallest sample where median is meaningful; N=10 deep-dives
land on quarterly-cadence dispatches. Haiku 4.5 is the cost-sensitive
default since CFN maintainer-validation showed 100% precision + recall
on Haiku across both labeled CFN fixtures — measuring on the
default-recommended model produces numbers customers will actually
experience.

### Roadmap context

Post-OSCAL-arc sequence:
- v0.1.112: M2 benchmark harness (this release)
- v0.1.112.x: maintainer-dispatched first benchmark numbers
- v0.1.113+: M1 runtime-evidence ingestion (Security Hub / Config / Prowler)

---

## [0.1.111] — 2026-05-14

**OSCAL output arc step 7 — doc graduation. OSCAL POA&M + Component-Definition
ship by default from `efterlev report run`.**

The OSCAL emit primitives have shipped through 6 progressive releases
(v0.1.105 emit → v0.1.106 schema gate → v0.1.107 FedRAMP rules →
v0.1.108 CD emit → v0.1.109 narratives → v0.1.110 NIST oscal-cli gate),
each shaking out real bugs. The output is now validated against three
independent gates (Python schema, Python FedRAMP rules, NIST canonical
Java validator). Time to make it default-on.

### Changed

- **`efterlev report run` pipeline now ends with two new stages**:
  `oscal export --kind poam` + `oscal export --kind component-definition`.
  Pipeline reads: `init → scan → agent gap → agent document → poam → oscal`.
- **`--skip-oscal` flag** added (mirrors `--skip-poam`, `--skip-document`).
  Use for fast iteration loops where OSCAL output isn't needed.
- **Help text + init's next-steps line** updated to reflect the
  graduated pipeline shape.

### Why graduate now

The OSCAL emit is **deterministic** (no LLM cost), completes in <1s
against typical fixtures, and validates against three independent
external gates. There's no remaining uncertainty about correctness or
cost — the only reason to keep it opt-in was the v0.1.105 "minimum
viable feature" gate, which has been steadily strengthened through
v0.1.110.

### What's still opt-in

- **`--narratives-from <attestation-path>` for CD emit** (v0.1.109)
  remains opt-in because it requires an attestation artifact path. A
  future enhancement may auto-discover the latest attestation under
  `.efterlev/reports/` and pass it automatically.

### OSCAL output arc roadmap (closed)

| Release | Step | Status |
|--|--|--|
| v0.1.105 | POA&M emit | shipped |
| v0.1.106 | NIST OSCAL JSON-schema validation | shipped |
| v0.1.107 | FedRAMP rule layer (5 rules) | shipped |
| v0.1.108 | Component-Definition emit | shipped |
| v0.1.109 | Documentation Agent narratives → CD statements | shipped |
| v0.1.110 | NIST oscal-cli round-trip CI gate | shipped |
| v0.1.111 | Doc graduation (OSCAL default-emitted) | **this release** |
| v1.5+ | Full OSCAL SSP (needs customer-shape data) | deferred |

**Arc closed.** OSCAL artifacts are now first-class outputs of every
`report run`. Forward work focuses on customer-driven enhancements:
auto-narrative discovery, RegScale OSCAL Hub round-trip if a customer
hits the gap, full SSP when the data shape is clear.

---

## [0.1.110] — 2026-05-14

**OSCAL output arc step 6 — NIST oscal-cli round-trip CI gate.**
The v0.1.106 schema gate + v0.1.107 FedRAMP rule layer use Python
(jsonschema + hand-ported rules). Useful, but our OWN validation
of our OWN output is a closed loop. NIST publishes a canonical OSCAL
CLI tool — a Java reference implementation. Running our labeled OSCAL
fixtures through THAT tool is a second-opinion gate: if NIST's own
validator accepts our output, that's the strongest external conformance
signal short of the GSA fedramp-automation Saxon pipeline.

### Added

- **`.github/workflows/oscal-cli-conformance.yml`** — new CI workflow.
  Pinned to NIST `oscal-cli` v1.0.3 (latest stable on Maven Central
  as of 2026-05-14; NIST distributes oscal-cli via Maven Central,
  not GitHub release assets). Runs `poam validate` against the labeled
  POA&M fixture and `component-definition validate` against the
  labeled CD fixture on every PR + main push (path-filtered to changes
  in OSCAL primitives + fixtures + this workflow itself).

### Fixed (caught by the new gate)

The first PR-CI run of the new gate caught **two real OSCAL shape bugs**
in the v0.1.105–109 generators that the Python schema/rule layers missed:

- **POA&M item + risk + CD implemented-requirement props missing `ns`
  field.** OSCAL constrains `prop.name` to a small well-known set
  (`marking`, `accepted`, `false-positive`, `priority`, `risk-adjusted`)
  unless namespace-qualified via `ns`. Our custom names
  (`severity`, `weakness-source-identifier`, `frmr-baseline`,
  `frmr-version`, `control-id`, `implementation-status`) were
  unqualified and rejected. Fix: every custom prop now carries
  `ns: "https://efterlev.com/ns/oscal"`.
- **Generator primitive versions bumped**: POA&M 0.3.0 → 0.4.0,
  Component-Definition 0.2.0 → 0.3.0. Labeled fixtures regenerated.
- **2 new regression tests** assert every custom prop carries `ns`.

### Why strict (gates merges) at v0.1.110

The labeled fixtures are byte-stable (deterministic generators + pinned
timestamps). A flake in oscal-cli output would surface as a real
regression, not noise. Per the strategic arc principle, a strict gate
that surfaces incompatibility is more valuable than a soft one that
hides it. If oscal-cli's accepted-OSCAL-version diverges from our
pinned 1.0.4 in a future release, the failure surfaces immediately +
we pin oscal-cli explicitly (already done at v2.5.2 above).

### What this catches that the v0.1.106/107 gates don't

- OSCAL constraints expressed in metaschema (not pure JSON schema)
- FedRAMP-specific shape rules NIST ships as part of the canonical
  toolchain
- PCRE Unicode property escape patterns the v0.1.106 PCRE-tolerant
  validator skips silently
- Cross-element references (constraint-target paths, prop applicability)

### OSCAL output arc roadmap (updated)

| Release | Step | Status |
|--|--|--|
| v0.1.105–109 | POA&M + CD emit + schema gate + FedRAMP rules + narratives | shipped |
| v0.1.110 | NIST oscal-cli round-trip CI gate | **this release** |
| v0.1.111 | Doc graduation (OSCAL becomes default-emitted) | next |
| v1.5+ | Full OSCAL SSP (needs customer-shape data) | deferred |

---

## [0.1.109] — 2026-05-14

**OSCAL output arc step 5 — Documentation Agent narratives populate CD `implemented-requirement.statements[]`.**
The v0.1.108 Component-Definition emit had no implementation prose — just
the deterministic `description` field built from classification + rationale.
v0.1.109 wires the Documentation Agent's per-KSI narrative output (FRMR
attestation `narrative`) into OSCAL `statements[]`, with `statement-id`
following the NIST 800-53 `<control-id>_smt` convention.

### Added

- **`narratives` field on `GenerateComponentDefinitionOscalInput`** —
  optional `dict[str, str]` (KSI ID → narrative text). Backward compatible:
  empty dict → no statements emitted (current v0.1.108 behavior).
- **`--narratives-from <path>` CLI option on `efterlev oscal export
  --kind component-definition`** — accepts a Documentation Agent
  `attestation-*.json` artifact path; loads via `AttestationArtifact`
  Pydantic model + extracts `KSI[theme].indicators[ksi_id].narrative`
  per KSI. Ignored for `--kind poam`.
- **2 new tests** on `tests/test_generate_component_definition_oscal.py`
  covering the narrative → statements path + backward-compat with no
  narratives. pytest 1791 → 1793.

### Changed

- **`generate_component_definition_oscal` primitive bumped 0.1.0 →
  0.2.0** to mark the additive output-shape extension. CD documents
  emitted without narratives produce byte-identical output to v0.1.108
  (no breaking change for existing callers).

### Why optional, not auto-discovered

A future `efterlev report run` invocation may auto-emit OSCAL CD
alongside the markdown POA&M, at which point auto-discovery of the
latest attestation artifact in `.efterlev/reports/` is the right move.
At v0.1.109 the OSCAL emit is opt-in, so an opt-in narratives flag
keeps the seam in the CLI rather than the primitive (which stays
deterministic and side-effect-free).

### OSCAL output arc roadmap (updated)

| Release | Step | Status |
|--|--|--|
| v0.1.105 | POA&M emit | shipped |
| v0.1.106 | NIST OSCAL JSON-schema validation | shipped |
| v0.1.107 | FedRAMP rule layer (5 rules) | shipped |
| v0.1.108 | Component-Definition emit | shipped |
| v0.1.109 | Documentation Agent narratives → CD statements | **this release** |
| v0.1.110 | NIST oscal-cli round-trip CI gate | next |
| v0.1.111 | Doc graduation (OSCAL becomes default-emitted) | planned |
| v1.5+ | Full OSCAL SSP (needs customer-shape data) | deferred |

---

## [0.1.108] — 2026-05-14

**OSCAL output arc step 4 — Component-Definition emit (`efterlev oscal export --kind component-definition`).**
The POA&M says "here are the gaps"; the Component-Definition says "here is what we
implement and how." Both target OSCAL 1.0.4, both are FedRAMP-current submission
artifacts. Component-Definitions are the OSCAL-native answer to "publish my
implementation statements as a reusable artifact" — a SaaS vendor can hand a
3PAO a CD and say "this is how our service satisfies these controls."

### Added

- **`catalogs/oscal/oscal_component_schema_v1.0.4.json`** — vendored NIST
  OSCAL 1.0.4 component-definition JSON schema (78 KB).
- **`src/efterlev/primitives/generate/generate_component_definition_oscal.py`** —
  new `generate_component_definition_oscal` primitive. Deterministic via uuid5
  (same namespace as POA&M emit). One component per scan, one
  control-implementation block, one implemented-requirement per (KSI ×
  cited control). Implementation-status props derived from Gap Agent
  classifications: `implemented` → `implemented`, `partial` → `partial`,
  `not_implemented` → `planned`, `not_applicable` /
  `evidence_layer_inapplicable` → `not-applicable`. Catalog source defaults
  to NIST 800-53 Rev 5 OSCAL catalog.
- **`src/efterlev/primitives/validate/validate_oscal_component_definition.py`** —
  schema validator sibling. Same PCRE-tolerant pattern keyword as the POA&M
  validator (Python stdlib `re` doesn't support `\p{...}` Unicode escapes).
- **`src/efterlev/cli/oscal.py`** — `efterlev oscal export --kind component-definition`
  is now a supported choice alongside `--kind poam`. Shared system-name +
  system-id options apply to both kinds.
- **`tests/test_generate_component_definition_oscal.py`** — 6 tests covering
  CD shape, per-control implemented-requirement emission, status mapping,
  UUID determinism, JSON serializability.
- **`tests/test_validate_oscal_component_definition.py`** — 5 tests
  (round-trip + missing required fields + malformed UUID).
- **`tests/test_oscal_cd_labeled_fixture.py`** — 3 tests guarding the
  labeled CD fixture.
- **`evals/fixtures/csp-starter-cfn/oscal/labeled-component-definition-v0.1.108.json`** —
  first labeled OSCAL CD fixture (1 component, 12 implemented-requirements).
  Same KSI source-of-truth as the POA&M fixture so 3PAOs see consistent
  cross-artifact data.
- **`scripts/regenerate_oscal_cd_labeled_fixture.py`** — regenerator script.

### Why a separate generator (not extending the POA&M emit)

POA&M and Component-Definition target different OSCAL roots and serve
different reviewer questions. Sharing input shape (`PoamClassificationInput`
+ `Indicator` dict) is the right level of reuse; merging the emit path
would over-couple two artifacts that may evolve separately (e.g.,
v0.1.108.5+ wires Documentation Agent narratives into CD
implemented-requirement statements but leaves POA&M emit unchanged).

### OSCAL output arc roadmap (updated)

| Release | Step | Status |
|--|--|--|
| v0.1.105 | POA&M emit | shipped |
| v0.1.106 | NIST OSCAL JSON-schema validation | shipped |
| v0.1.107 | FedRAMP rule layer (5 rules) | shipped |
| v0.1.108 | Component-Definition emit + schema gate + labeled fixture | **this release** |
| v0.1.108.5 | Documentation Agent narratives → CD implemented-requirement statements | next |
| v0.1.109 | RegScale OSCAL Hub round-trip test | planned |
| v0.1.110 | Doc graduation (OSCAL becomes default-emitted) | planned |
| v1.5+ | Full OSCAL SSP (needs customer-shape data) | deferred |

---

## [0.1.107] — 2026-05-14

**OSCAL output arc step 3 — FedRAMP rule layer (Python-native subset of GSA fedramp-automation).**
Layered on top of the v0.1.106 NIST schema gate. Catches FedRAMP-specific
shape constraints the upstream OSCAL schema doesn't enforce — value
enumerations, evidence-link presence, baseline + version conventions.

### Added

- **`src/efterlev/primitives/validate/validate_oscal_fedramp_rules.py`** —
  new `validate_oscal_fedramp_rules` primitive. Five rules ship at
  v0.1.107, each with a stable `FRMP-OSCAL-NNN` identifier:
  - **FRMP-OSCAL-001** — POA&M-item `severity` prop must be `high`,
    `moderate`, or `low` (FedRAMP convention).
  - **FRMP-OSCAL-002** — risk `status` must be one of `open`,
    `investigating`, `remediation-pending`, `closed`, or
    `deviation-requested`.
  - **FRMP-OSCAL-003** — every POA&M item must reference at least one
    risk or observation. An orphan POA&M item is unreviewable.
  - **FRMP-OSCAL-004** — `frmr-baseline` prop must reference a FedRAMP
    20x baseline (`fedramp-20x-low`, `fedramp-20x-moderate`,
    `fedramp-20x-high`).
  - **FRMP-OSCAL-005** — `oscal-version` must be a FedRAMP-current
    version (1.0.4 today; expand when FedRAMP publishes 1.1.0
    guidance).
- **`tests/test_validate_oscal_fedramp_rules.py`** — 8 tests (round-trip
  + per-rule negative tests + multi-violation surfacing).
- **`tests/test_oscal_labeled_fixture.py::test_labeled_fixture_passes_fedramp_rules`** —
  labeled fixture must satisfy every FedRAMP rule. Catches regressions
  in the rule layer against the canonical 3PAO-inspectable artifact.

### Fixed

- **OSCAL severity emit `medium` → `moderate`.** FedRAMP convention is
  `moderate`, not `medium` (matches Rev5 POA&M template + GSA rule
  set). v0.1.106 emitted `medium` and would have failed FRMP-OSCAL-001
  the moment the rule layer landed. **Generator primitive version
  bumped 0.2.0 → 0.3.0** to mark the value-vocabulary change. The
  markdown POA&M (human-readable) intentionally keeps `HIGH`/`MEDIUM`
  — different consumer, different convention.
- **Labeled fixture regenerated** with the new severity vocabulary
  (`scripts/regenerate_oscal_labeled_fixture.py`).

### Why Python-native (not vendored Schematron + Saxon)

GSA fedramp-automation Schematron rules are XML-Schematron + metaschema
targeting OSCAL XML. Running them against our JSON output would require
NIST `oscal-cli` (Java) for JSON↔XML conversion + Saxon-HE for the
Schematron engine — adding ~50 MB of Java runtime to CI for a rule set
small enough at v0.1.107 (5 rules) that a hand-port is shorter, more
legible, and easier for contributors to extend. The trade-off becomes
worth flipping at ~30 rules; tracked as a v0.1.108+ consideration.

### OSCAL output arc roadmap (updated)

| Release | Step | Status |
|--|--|--|
| v0.1.105 | POA&M emit (`oscal export --kind poam`) | shipped |
| v0.1.106 | NIST OSCAL JSON-schema validation + labeled fixture | shipped |
| v0.1.107 | FedRAMP rule layer (5 rules ported from GSA) | **this release** |
| v0.1.108 | Component-definition emit | next |
| v0.1.109 | RegScale OSCAL Hub round-trip test | planned |
| v0.1.110 | Doc graduation (OSCAL becomes default-emitted) | planned |
| v1.5+ | Full OSCAL SSP (needs customer-shape data) | deferred |

---

## [0.1.106] — 2026-05-14

**OSCAL output arc step 2 — JSON-schema conformance gate + first labeled OSCAL fixture.**
Catches structural OSCAL bugs at PR time, before any artifact ever reaches a
3PAO. Surfaced two real generator bugs in v0.1.105 (see "Fixed" below) within
five minutes of being wired up — exactly the kind of feedback-loop the
quality-scaffolding-before-market-expansion arc was designed to produce.

### Added

- **`catalogs/oscal/oscal_poam_schema_v1.0.4.json`** — vendored NIST OSCAL 1.0.4
  POA&M JSON schema (146 KB), frozen at the version the generator emits.
  Refresh procedure documented in `evals/OSCAL_CONFORMANCE.md`.
- **`src/efterlev/primitives/validate/validate_oscal_poam.py`** — new
  `validate_oscal_poam` primitive. Runs the vendored schema against an
  OSCAL POA&M dict via the `jsonschema` library, surfaces ALL violations
  (no early-exit) so maintainers can fix them in one pass. PCRE Unicode
  property escapes (`\p{L}` etc.) in the OSCAL schema are tolerated —
  unparseable patterns are skipped silently; standard regex (UUIDs,
  identifiers) is enforced. Full PCRE coverage layered in v0.1.107
  via GSA Schematron.
- **`tests/test_validate_oscal_poam.py`** — 6 tests covering round-trip
  validation, missing required fields, malformed UUIDs, multi-error
  surfacing.
- **`evals/fixtures/csp-starter-cfn/oscal/labeled-poam-v0.1.106.json`** —
  first labeled OSCAL fixture, derived from the csp-starter-cfn
  Phase 2 lite verdicts (6 KSIs → 6 POA&M items, 12 risks, 6
  observations). Schema-validated in CI on every PR.
- **`tests/test_oscal_labeled_fixture.py`** — 3 tests guarding the
  labeled fixture (presence on disk, schema conformance, expected
  shape).

### Fixed

- **OSCAL POA&M shape — `findings` → `risks`.** OSCAL `plan-of-action-and-milestones`
  has no `findings` property; per-control deficiencies live in `risks`
  (findings are an assessment-results concept, a sibling layer).
  v0.1.105 emitted `findings` at the root + `related-findings` on
  poam-items — both rejected by the vendored schema. v0.1.106 emits
  `risks` (with required `statement` + `status: open` fields) and
  `related-risks` on poam-items. **Generator primitive version bumped
  0.1.0 → 0.2.0** to mark the output-shape change; downstream
  consumers (RegScale, etc.) that diff by UUID will see the v0.1.105
  finding-uuids replaced with new risk-uuids.
- **`related-observations` empty-array elision.** OSCAL schema
  requires `related-observations` to be non-empty when present.
  Procedural KSIs with no `evidence_ids` previously emitted `[]` and
  failed validation; now the field is omitted entirely.

### Why JSON-schema gate before Schematron

Schematron is the canonical FedRAMP-specific shape gate (GSA
fedramp-automation rule set, layered in v0.1.107). JSON-schema
validation is the cheaper structural prerequisite — same toolchain,
no Java / Saxon dependency, runs in milliseconds against any OSCAL
1.0.4 POA&M. Catching the v0.1.105 `findings` bug at v0.1.106 cost
~30 seconds of CI time; the same bug would have surfaced as 3PAO
feedback ("your tool emits invalid OSCAL") in the worst case.

### OSCAL output arc roadmap (updated)

| Release | Step | Status |
|--|--|--|
| v0.1.105 | POA&M emit (`oscal export --kind poam`) | shipped |
| v0.1.106 | JSON-schema validation + labeled fixture | **this release** |
| v0.1.107 | GSA fedramp-automation Schematron rules layer | next |
| v0.1.108 | Component-definition emit (uses Documentation Agent narratives) | planned |
| v0.1.109 | RegScale OSCAL Hub round-trip test | planned |
| v0.1.110 | Doc graduation (OSCAL becomes default-emitted) | planned |
| v1.5+ | Full OSCAL SSP (needs customer-shape data) | deferred |

---

## [0.1.105] — 2026-05-14

**OSCAL output arc step 1 — POA&M emit (`efterlev oscal export --kind poam`).**
First step in the OSCAL output arc per 2026-05-14 strategic plan.
Anchored on the FedRAMP RFC-0024 deadline (Sep 2026) which targets
OSCAL as the FedRAMP submission format.

### Added

- **`src/efterlev/cli/oscal.py`** — new `efterlev oscal` subcommand.
  `oscal export --kind poam --output <path>` emits OSCAL 1.0.4
  POA&M JSON. Future kinds (`component-definition` v0.1.107,
  `partial-ssp` v0.1.108+) ship behind the same `--kind` flag.
  `--system-name` and `--system-id` options for OSCAL metadata
  (placeholders the maintainer overrides before 3PAO submission).
- **`src/efterlev/primitives/generate/generate_poam_oscal.py`** —
  new deterministic primitive. UUIDs derived via `uuid5` from a
  fixed namespace (`uuid.NAMESPACE_DNS / "efterlev.com/oscal"`) +
  KSI/control identifiers, so re-runs produce stable diffs.
- **`tests/test_generate_poam_oscal.py`** — 10 new tests covering
  UUID determinism, severity heuristic (`not_implemented` → high,
  `partial` → medium, mirrors the markdown POA&M), per-control
  finding emission, observation deduplication by evidence_id,
  JSON serializability.

### OSCAL output structure

Per `not_implemented` / `partial` KSI → 1 `poam-item`. Per (KSI ×
cited control) pair → 1 `finding` (per-control deficiency, matches
how 3PAOs read POA&Ms). Per cited evidence_id → 1 deduplicated
`observation` (multi-finding-on-same-evidence cases share the
observation).

### Why a dedicated subcommand (not a flag on `report run`)

- OSCAL has multiple output kinds (POA&M, component-definition,
  partial-SSP). Subcommand namespace lets us add `oscal validate`
  etc. without overloading the top-level CLI.
- `efterlev report run` users who don't care about OSCAL shouldn't
  pay the OSCAL emit cost.
- Trestle (IBM) and RegScale CLI both use the subcommand pattern;
  this keeps the OSCAL-tool surface familiar to compliance users.

### Why OSCAL 1.0.4 (not 1.1.0)

FedRAMP's current published guidance + GSA's `fedramp-automation`
validation rule set both target OSCAL 1.0.4. OSCAL 1.1.0 has
breaking schema changes; emitting 1.1.0 would not validate against
the GSA rule set. When FedRAMP publishes 1.1.0 guidance, add a
`--oscal-version` flag.

### Honest scope at v0.1.105

Minimal-conformant POA&M with `metadata`, `system-id`, `observations`,
`findings`, `poam-items`. NOT included (planned later):
- `import-ssp` reference (system-id-only mode for now)
- `risks` block
- `local-definitions.components` (component-definition export at v0.1.107)
- LLM-narrative implementation statements
- Full SSP assembly (deferred to v1.5+; needs customer-shape data)

### Next OSCAL steps

| Step | Release | Scope |
|---|---|---|
| 1: POA&M emit | ✅ v0.1.105 | this |
| 2: GSA Schematron validation in CI | v0.1.106 | wire `fedramp-automation` rule set as a CI check |
| 3: Component-definition emit | v0.1.107 | `oscal export --kind component-definition` (3-5 days; uses Documentation Agent's existing implementation-statement narratives) |
| 4: RegScale OSCAL Hub round-trip test | v0.1.108 | maintainer-validation-equivalent for OSCAL: confirm our JSON ingests cleanly into RegScale |
| 5: Doc graduation | v0.1.109 | OSCAL becomes default-emitted alongside POA&M markdown |
| 6: Full OSCAL SSP | (deferred to v1.5+) | needs customer-shape data |

## [0.1.104] — 2026-05-14

**SAM transparency note (LIMITATIONS only).** Tiny doc patch
documenting that AWS SAM templates are a known limitation.

### Changed

- **`LIMITATIONS.md`** — added explicit note that AWS SAM templates
  (`Transform: AWS::Serverless-2016-10-31`) parse without crashing
  but the SAM-specific resource types (`AWS::Serverless::Function`,
  `AWS::Serverless::Api`, `AWS::Serverless::SimpleTable`,
  `AWS::Serverless::GraphQLApi`, etc.) fall through the unmapped-
  fallback path — detectors don't read them, so a SAM-only template
  produces zero detector evidence. Workaround: scan the post-`sam build`
  CFN output (which expands SAM types to underlying CFN).

### Why doc-only and not real SAM mappings

SAM is a niche dialect (~10-20% of FedRAMP-pursuing SaaS by
architecture; pure-serverless apps only). Surfaced by an internal
QA scan against three `aws-samples/serverless-patterns` templates.
No active customer is asking. Real SAM property mappings are
deferred until the first customer hits the gap so we can use their
template as the validation fixture rather than guessing SAM-app
shape — same discipline as v0.1.103's nested-stack call (transparent
limitation > speculative real fix).

### Closes the QA-driven release loop

After v0.1.103 surfaced 3 universal CFN regressions and v0.1.104
documented one niche-dialect gap, the QA-driven release pattern has
served its purpose for this cycle. Next move is a strategic-arc
choice (v0.2.0 eval-harness-as-user-feature, CDK adapter, real
customer pitches), not more speculative QA scans.

### No code changes

Pure docs. pytest still 1749 passing.

## [0.1.103] — 2026-05-14

**QA-surfaced CFN parser + scan-summary bundle.** Internal QA scan
against `aws-quickstart/quickstart-aws-aurora-postgresql` (1758 lines
of real-world Quick Start CFN; 71 `AWS::*` references) surfaced 3
real bugs that the 2 maintainer-validated fixtures
(`csp-starter-cfn` + `aws-vpc-cfn`) had missed. All 3 fixed in this
release.

### Bugs fixed

**1. Parser crashed on Rules-section intrinsics.** The
`!ValueOf` / `!RefAll` / `!EachMemberEquals` / `!EachMemberIn` /
`!Contains` / `!ValueOfAll` short-form tags are CFN intrinsics used
in `Rules:` blocks (parameter validation pre-flight). The
`_CfnSafeLoader` only had the resource-section intrinsics
registered. Hitting any Rules-section intrinsic crashed the YAML
load, and the parse failure was silently swallowed at the tree-walk
level — the user saw a successfully-completed scan that had silently
dropped the entire 1091-line aurora_postgres.template.yaml.

Fix: registered all 6 Rules-section intrinsics in
`_CFN_INTRINSICS`. Parse now succeeds; resources are extracted
normally. (Rules-section content itself is parameter validation and
isn't relevant to detector firing — we just need the parser not to
crash on the tags.)

**2. Parse failures not surfaced in scan summary.** The
`ScanCloudFormationOutput.parse_failures` field was already
populated by `parse_cfn_tree`, but the CLI summary never showed it.
Users got "1 cfn templates" without knowing a 2nd template silently
failed to parse.

Fix: added `cfn parse failures: N — see scan-<ts>.json sidecar`
line to the scan summary when failures > 0.

**3. Nested-stack references not surfaced.** Quick Starts and many
production CFN deployments use `AWS::CloudFormation::Stack` with
`TemplateURL` pointing at child templates. Efterlev parses the
nested-stack reference as a single resource and stops; child
templates aren't followed. Pre-v0.1.103 the user had no signal that
the `aurora_postgres-main.template.yaml` they scanned was mostly a
3-nested-stack thin wrapper.

Fix: added `nested_stack_refs` field to
`ScanCloudFormationOutput`; CLI summary surfaces
`cfn nested stacks: N (TemplateURL not followed; scan child
templates directly to reach nested resources)`. Honest
documentation of the limitation; nested-stack expansion (S3 fetch
+ recursive parse) remains a v0.x followup.

**4. Stale scan summary text.** The summary line said
`(N resources adapted; v0.1.72 plumbing — property-mapping in PR
gamma)`. The "v0.1.72 plumbing" framing was from the day-one CFN
scaffolding — laughably wrong as of v0.1.102 (property mapping
shipped in full through gamma.2 batch 9 at v0.1.96). Replaced with
`(N resources adapted)`.

### Validation against the fixture that surfaced the bugs

| Metric | Pre-v0.1.103 | v0.1.103 |
|---|---|---|
| CFN templates parsed | 1 | **2** |
| Resources adapted | 3 | **24** (8×) |
| Evidence records | 1 | **19** (19×) |
| Parse failures shown | (silent) | (none — bug 1 fixed) |
| Nested-stack visibility | none | **3 (with explanation)** |
| Stale text | "v0.1.72 plumbing" | clean |

### Tests

- `tests/test_cloudformation_parser.py` — 2 new tests:
  `test_intrinsic_value_of_in_rules_section` (regression for the
  specific `!ValueOf` failure) +
  `test_intrinsic_rules_section_others` (covers the other 5
  Rules-section intrinsics).
- `tests/test_scan_cloudformation_summary.py` — 4 new tests for the
  new `nested_stack_refs` field, the parse-failure surfacing path,
  and the `!ValueOf`-no-longer-silent-failure regression.

Test count: 1743 → 1749.

### Why this matters

The 2 maintainer-validated fixtures (`csp-starter-cfn` synthetic +
`aws-vpc-cfn` vendored AWS Quick Start) hit 100/100 precision +
recall. But the fixture surface only exercised ~10 of the 60+ CFN
property mappings, and neither used the Rules section or
nested-stack pattern. Real-world Quick Starts shipped by AWS use
both. Internal QA against a real production-shape template surfaced
gaps that synthetic-fixture validation can't reach. The pattern —
periodically scan an external real-world IaC codebase, ship fixes
for what surfaces — is the right cadence for shipping quality.

## [0.1.102] — 2026-05-14

**CFN graduation arc step 4 — remove `--allow-cfn` flag.** Closes
the CFN graduation arc completely. The deprecated flag (introduced
v0.1.72, deprecated v0.1.99) is now gone; CFN scans unconditionally.

### BREAKING

- `efterlev scan --allow-cfn` returns a CLI parse error: "No such
  option: --allow-cfn". Drop the flag from your scripts; the
  behavior is now unconditional.
- `efterlev scan --no-allow-cfn` (the explicit opt-out introduced in
  v0.1.99) also gone. CFN scanning cannot be disabled per-invocation;
  if you want CFN-free scanning, point `--target` at a TF-only
  subdirectory.

### Changed

- **`src/efterlev/cli/main.py`** — removed the
  `allow_cfn: bool | None = typer.Option(...)` parameter and the
  sentinel logic that decided whether to invoke
  `scan_cloudformation`. The primitive is now invoked unconditionally
  on every scan.
- **`LIMITATIONS.md`** — replaced "removed in v0.2.0" promise with
  "removed at v0.1.102; CFN now scans unconditionally."
- **`evals/PHASE_2_LITE_CFN_VALIDATION.md`** — same correction.

### Why v0.1.102 (not v0.2.0)

Three DECISIONS.md entries explicitly reserved v0.2.0 for the
"eval-harness-as-user-feature substantive arc" (Phase 3 pre-merge
eval gate as required check). Removing a deprecated flag is a
cleanup, not a capability shift. Per the DECISIONS commitment:
"Bumping major version on a change that gives users nothing is a
form of marketing inflation; reserves v0.2.0 for an actual capability
shift." The v0.1.99 deprecation message that promised "removed in
v0.2.0" was technically inaccurate; v0.1.102 corrects the timing
without compromising the v0.2.0 strategic arc.

### CFN graduation arc — COMPLETE

| Step | Status | Release |
|---|---|---|
| 1: Detector parity audit | ✅ | v0.1.95 |
| 1.5: Close missing mappings (100% type coverage) | ✅ | v0.1.96 |
| 2 (labeling): 2nd CFN fixture labeled | ✅ | v0.1.97 |
| 2 (validation): aws-vpc-cfn maintainer-validation dispatch | ✅ | v0.1.98 |
| 3: Doc graduation + `--allow-cfn` deprecation | ✅ | v0.1.99 |
| 4: Remove `--allow-cfn` (CFN unconditionally on) | ✅ | **v0.1.102** |
| 5: Line-level CFN provenance | 🚫 deferred | v0.3+ |

### Test plan

- `ruff check`, `ruff format --check`, `mypy`, `bandit` clean
- pytest still 1743 passing — no test reference to `--allow-cfn`
  required maintenance because the existing test suite invokes
  `scan_cloudformation` directly through the primitive layer, not
  through the CLI flag

## [0.1.101] — 2026-05-14

**verify-release.sh ghcr-propagation retry-and-wait.** Closes the
recurring release-smoke `signature-verify` timing race that hit
v0.1.87 and v0.1.99 (~1 in 5 release tags).

### Root cause

`cosign verify` for the container signature and
`cosign verify-attestation` for the SLSA provenance both race the
`release-container.yml` workflow's ghcr push. The release artifacts
are cryptographically valid in both cases — running
`scripts/verify-release.sh vX.Y.Z` locally a few minutes later
returns 4/4 pass — only the CI status reads false-red.

### Fix

Wrap both cosign calls in retry-and-wait loops matching the smoke
matrix's `docker pull` shape — 10 attempts × 30s = 5min total.
Self-contained in `scripts/verify-release.sh`; benefits both CI
signature-verify AND end users running the script immediately after
a release. The retry loop logs an `info` line on each attempt so
the CI log reads cleanly:

```
ghcr.io not yet serving ghcr.io/efterlev/efterlev:vX.Y.Z (attempt 1/10); waiting 30s...
ghcr.io not yet serving ghcr.io/efterlev/efterlev:vX.Y.Z (attempt 2/10); waiting 30s...
✓ ghcr.io/efterlev/efterlev:vX.Y.Z: cosign signature valid
```

### Test plan

- Sanity-checked against the just-shipped v0.1.100 — 4/4 pass.
- `bash -n scripts/verify-release.sh` syntax-clean.
- pytest still 1743 (no Python changes).

### Why a separate release

Bundling this with v0.2.0 (the `--allow-cfn` flag removal) would
have meant: the v0.2.0 release-smoke run hits the same timing race
the fix is supposed to close, defeating the point. Better to ship
v0.1.101, watch one release-smoke pipeline land clean first try,
then confidently ship v0.2.0.

## [0.1.100] — 2026-05-14

**Post-CFN-graduation doc cleanup.** Audit after v0.1.99 surfaced 5
stale CFN claims missed during the graduation work. Fixed in this
release.

### Changed

- **`docs/faq.md`** — "What if my code is in something other than
  Terraform?" answer said "v0.1.0 supports Terraform and OpenTofu
  only... CloudFormation, AWS CDK, Pulumi, and Kubernetes manifests
  are roadmap items." CFN ships now. Updated to reflect default-on
  status + 60/60 + 44/44 numbers.
- **`docs/architecture.md`** — "Two Evidence sources" section said
  "Terraform today; CloudFormation / K8s / runtime in v1.5+." CFN
  ships now. Updated to reflect the property-mapping-table-translates-
  CFN-to-TF-shape architecture.
- **`README.md`** Status para — narrated the CFN arc through v0.1.81
  only. Extended through v0.1.95-99 graduation steps (parity audit,
  missing-mapping closeout, 2nd fixture, validation dispatch, doc
  graduation), with the combined 44/44 = 100/100 number.
- **`evals/PHASE_2_LITE_CFN_VALIDATION.md`** — closing line called
  doc graduation "next arc release." It shipped in v0.1.99; updated
  to reflect that.
- **`evals/harness.py`** — still appended `--allow-cfn` to scan_args,
  which would emit the deprecation warning every harness run. Dropped
  the append. Also removed `_fixture_has_cfn_templates` as dead code
  (only callsite was the now-removed flag dispatch).

### Why this matters

The graduation-arc PRs (v0.1.95-99) updated the load-bearing docs
(README lede + Coverage section, LIMITATIONS, doctor, CHANGELOG) but
missed downstream references in FAQ + architecture + harness +
validation doc. The audit caught them all in one sweep — better to
ship a small explicit cleanup than carry stale claims.

### No CFN behavior change

Pure docs + a dead-code removal in the eval-harness. pytest still
1743 passing.

## [0.1.99] — 2026-05-14

**CFN graduation arc step 3 — doc graduation + `--allow-cfn`
deprecation.** CFN scanning is now default-on. The `--allow-cfn`
flag is kept for backward compatibility but emits a deprecation
warning when explicitly passed; will be removed in v0.2.0.

### Changed

- **`src/efterlev/cli/main.py`** — `allow_cfn` parameter changed
  from `bool = False` to `bool | None = None`. Sentinel logic:
  `None` (default) and `True` (explicit `--allow-cfn`) both run
  CFN scanning. `False` (explicit `--no-allow-cfn`) opts out.
  Deprecation warning fires only when `allow_cfn is True` (i.e.
  the flag was explicitly passed). One-minor-release deprecation
  window per standard CLI pattern.
- **`src/efterlev/cli/doctor.py`** — `check_cloudformation_templates`
  now reports `pass` with "will be scanned by default" instead of
  `warn` with the now-defunct flag hint when CFN templates are
  detected.
- **`README.md`** — removed "experimental, opt-in via `--allow-cfn`"
  framing from the lede, the Coverage section, and the comparison
  table. Replaced with the actual graduation numbers.
- **`LIMITATIONS.md`** — replaced "experimental status with 18 resource
  types... maintainer-validation deferred" with the v0.1.96/v0.1.98
  graduation numbers (60/60 type coverage, 44/44 = 100/100 across
  2 fixtures).
- Cross-doc version refs (CLAUDE, docs/index, README, LIMITATIONS).

### CFN graduation arc status

| Step | Status | Release |
|---|---|---|
| 1: Detector parity audit | ✅ | v0.1.95 |
| 1.5: Close missing mappings (100% type coverage) | ✅ | v0.1.96 |
| 2 (labeling): 2nd CFN fixture labeled | ✅ | v0.1.97 |
| 2 (validation): aws-vpc-cfn maintainer-validation dispatch | ✅ | v0.1.98 |
| **3: Doc graduation + `--allow-cfn` deprecation** | ✅ | **v0.1.99** |
| 4: Remove `--allow-cfn` (CFN unconditionally on) | ⏳ | v0.2.0 candidate |
| 5: Line-level CFN provenance | 🚫 deferred | v0.3+ |

### Why this matters

The marketing claim "Efterlev reads CloudFormation" is now defensible
end-to-end: 100% type-mapping coverage + 100% precision/recall across
2 maintainer-validated fixtures. Pre-v0.1.99, the `--allow-cfn`
opt-in flag still framed CFN as experimental despite the validated
quality. v0.1.99 removes that friction while preserving backward
compatibility for one minor release.

### Test plan

- pytest 1743 still passing (no test count change — pure CLI/docs
  graduation; the CFN scan path was already exercised by the existing
  test suite).
- mypy clean against the new `bool | None` typing.

## [0.1.98] — 2026-05-14

**CFN graduation arc step 2 (validation) — aws-vpc-cfn maintainer-validation
dispatch.** Triggered the existing `eval-harness-cfn.yml`
workflow_dispatch with `fixture=evals/fixtures/aws-vpc-cfn` +
`llm_model=claude-haiku-4-5` (same backend as the v0.1.81
csp-starter-cfn run). **Result: 21/21 = 100% precision + 100% recall**
against revision-1 labels.

### Per-KSI verdict comparison

The 4 detector-evidence KSIs all matched expectation:

| KSI | Label | Agent verdict | Match |
|---|---|---|---|
| `KSI-CNA-MAT` | `partial\|not_implemented` | `partial` | ✓ |
| `KSI-CNA-RNT` | `partial\|not_implemented` | `partial` | ✓ |
| `KSI-CNA-ULN` | `partial\|not_implemented` | `not_implemented` | ✓ (alternation) |
| `KSI-PIY-GIV` | `partial` | `partial` | ✓ |

The 17 procedural-only KSIs (9 AFR + 4 CED + 3 INR + 1 PIY-RSD) all
classified `evidence_layer_inapplicable` matching the labels.

### Cross-fixture summary

| Fixture | Labels | Match | Precision | Recall |
|---|---|---|---|---|
| `csp-starter-cfn` (v0.1.81) | 23 | 23 | 1.0 | 1.0 |
| `aws-vpc-cfn` (v0.1.98) | 21 | 21 | 1.0 | 1.0 |
| **Combined** | **44** | **44** | **1.0** | **1.0** |

### Changed

- **`evals/fixtures/aws-vpc-cfn/GROUND_TRUTH.yaml`** — bumped
  revision 1 → 2 to mark validated. Label content unchanged from
  revision 1.
- **`evals/PHASE_2_LITE_CFN_VALIDATION.md`** — appended Results
  section documenting the v0.1.98 dispatch + cross-fixture
  summary.

### Why this matters

This proves the v0.1.97 thesis: **detector verdicts are invariant
under IaC syntax once the property-mapping table translates CFN
bodies to TF shape.** The same VPC architecture in CloudFormation
classifies identically to the same architecture in Terraform
(`aws-vpc-tfm`, v0.1.69 baseline).

The CFN side now stands at **44/44 = 100% across 2 fixtures**,
matching the TF baseline shape (67 across 3) closely enough to
support the marketing claim "Efterlev reads CloudFormation" with
the same defensibility as the TF claim.

### CFN graduation arc status

| Step | Status | Release |
|---|---|---|
| 1: Detector parity audit | ✅ | v0.1.95 |
| 1.5: Close missing mappings (100% type coverage) | ✅ | v0.1.96 |
| 2 (labeling): 2nd CFN fixture labeled | ✅ | v0.1.97 |
| 2 (validation): aws-vpc-cfn maintainer-validation dispatch | ✅ | v0.1.98 |
| 3: Doc graduation + `--allow-cfn` deprecation | ⏳ | v0.2.0 candidate |
| 4: Line-level CFN provenance | 🚫 deferred | v0.3+ |

### No code changes

Pure docs + label-revision update. pytest still 1743 passing.

## [0.1.97] — 2026-05-14

**CFN graduation arc step 2 — label aws-vpc-cfn (2nd CFN fixture).**
Lifts CFN-side validation breadth from 23 labels (csp-starter-cfn
alone) toward ~50 (matching the TF baseline of 67 across 3 fixtures).

### Changed

- **`evals/fixtures/aws-vpc-cfn/GROUND_TRUTH.yaml`** — replaced empty
  v0.1.72 plumbing-only stub with maintainer-draft labels mirroring
  `aws-vpc-tfm`'s GROUND_TRUTH.yaml structure. The TF companion
  fixture is the authoritative shape for "what an honest maintainer
  expects from a real-shape VPC fixture," and the property-mapping
  layer (PR γ + γ.2 batches 1-9) should make verdicts equivalent at
  the KSI level.
  - 4 detector-evidence KSIs: `KSI-CNA-MAT`, `KSI-CNA-RNT`
    (`partial|not_implemented` per `aws.nacl_restrictiveness`
    no-explicit-deny gap), `KSI-CNA-ULN`
    (`partial|not_implemented` per `aws.vpc_logical_segmentation`),
    `KSI-PIY-GIV` (`partial` per `aws.terraform_inventory` which
    fires on any `aws_*` resources including CFN-translated).
  - 16 procedural-only KSIs (9 AFR + 4 CED + 3 INR) labeled
    `evidence_layer_inapplicable|not_applicable` because the fixture
    has no Evidence Manifests.
  - 1 PIY-RSD labeled `not_implemented|evidence_layer_inapplicable`
    (workflow surface skipped via `--allow-subdir-target`).
  - **Total: 21 labels for aws-vpc-cfn.**
- **`evals/fixtures/aws-vpc-cfn/SOURCE.md`** — updated post-v0.1.97
  status block; documents that the maintainer-validation dispatch is
  the next graduation step.

### CFN-side validation breadth

| Fixture | Labels |
|---|---|
| `csp-starter-cfn` (synthetic mixed) | 23 |
| `aws-vpc-cfn` (vendored AWS Quick Start VPC) | **21 (new)** |
| **Total** | **44 across 2 fixtures** |

TF baseline shape for comparison: 67 labels across 3 fixtures
(`aws-vpc-tfm` + `aws-s3-bucket-tfm` + `aws-lambda-tfm`). The CFN
side is now at the same fixture cadence as the TF mid-state
(2 fixtures of 3); a 3rd CFN fixture (S3-bucket or Lambda
companion) would close the breadth gap entirely.

### Why this matters

Single-fixture validation is brittle. The v0.1.81 23/23 = 100/100
maintainer-validation pass on `csp-starter-cfn` alone leaves a
defensible-but-narrow validation surface. Adding `aws-vpc-cfn` —
real-shape vendored AWS Quick Start template, NOT synthetic —
broadens the surface to include parameter-driven, condition-
conditional templates, which is what real customers ship.

### Next CFN graduation steps

1. **v0.1.98** (proposed): maintainer-validation dispatch against
   `aws-vpc-cfn` (the v0.1.81-equivalent step). Compare per-KSI
   verdicts to labels; if any diverge from `aws-vpc-tfm`, that's a
   CFN-side regression to investigate.
2. **v0.2.0**: doc graduation (remove "experimental" framing) +
   `--allow-cfn` deprecation warning.
3. **v0.3+**: line-level provenance for CFN — deferred, not a
   graduation gate.

## [0.1.96] — 2026-05-14

**CFN graduation arc step 1.5 — close 8 missing mappings.** Closes
the 8 CFN-type mappings the v0.1.95 parity audit surfaced as real
gaps. After this lands, CFN coverage is genuinely 100% — every
detector reachable from CFN with zero real gaps.

### Added

| CFN type | TF type | Notes |
|---|---|---|
| `AWS::IAM::AccessKey` | `aws_iam_access_key` | UserName → user. Closes `iam_user_access_keys` + `iam_service_account_keys_age`. |
| `AWS::Logs::Destination` | `aws_cloudwatch_log_destination` | TF prefixes `cloudwatch_` for CloudWatch Logs resources. |
| `AWS::Logs::SubscriptionFilter` | `aws_cloudwatch_log_subscription_filter` | Same `cloudwatch_` prefix asymmetry. |
| `AWS::OpenSearchService::Domain` | `aws_opensearch_domain` | TF drops the `service` namespace segment. |
| `AWS::Elasticsearch::Domain` | `aws_elasticsearch_domain` | Legacy AWS service; default tf_type correct. |
| `AWS::KinesisFirehose::DeliveryStream` | `aws_kinesis_firehose_delivery_stream` | tf_type override needed (CamelCase segments collapse). |
| `AWS::SecurityHub::Hub` | `aws_securityhub_account` | **NAME asymmetry**: TF models the enable-on-account semantics rather than the hub-as-resource. |
| `AWS::SecurityHub::FindingAggregator` | `aws_securityhub_finding_aggregator` | tf_type override needed. |

- **`tests/test_cfn_property_mapping_batch9.py`** — 11 new parity
  tests: per-mapping basic translation + 2 IAM detector parity tests
  (iam_user_access_keys, iam_service_account_keys_age) +
  end-to-end test that exercises all 7 centralized-logging
  detector reads from a single CFN stack.

### Changed

- **`scripts/build_cfn_parity_table.py`** — removed the 8 closed
  types from the `TF_SUBRESOURCES_BUNDLED_IN_CFN` "missing mapping"
  table. Reclassified `aws_iam_user_login_profile` as
  `TF_NO_CFN_EQUIVALENT` (AWS exposes login-profile creation only via
  the IAM API; no CFN resource type).
- **`docs/cfn-detector-parity.md`** — updated coverage tables to
  reflect the new 100% effective coverage.
- **`docs/cfn-detector-parity.csv`** — regenerated.

### Coverage at v0.1.96

| Status | Count |
|---|---|
| full | 47 |
| partial-by-design | 11 |
| TF-only-by-design | 2 |

**Effective CFN coverage: 100%** (60/60). Zero real gaps.

The 2 TF-only-by-design entries remain intentional: `aws.iam_password_policy`
(account-level setting; no CFN type exists) and `aws.iam_managed_via_terraform`
(meta-detector by definition).

### Why this matters

The v0.1.93 "CFN coverage CLOSED" claim was off by 8 types; v0.1.95
made the audit honest; v0.1.96 closes the gap for real. The
marketing claim "Efterlev reads CloudFormation" is now defensible
end-to-end.

### Next CFN graduation steps

1. **v0.1.97+**: 2nd labeled CFN fixture + maintainer-validation pass
   to lift validation breadth from 23 labels (1 fixture) to ~50
   (matching the TF-side baseline shape).
2. **v0.2.0**: doc graduation (remove "experimental" framing) +
   `--allow-cfn` deprecation warning.
3. **v0.3+**: line-level provenance for CFN — deferred, not a
   graduation gate.

## [0.1.95] — 2026-05-14

**CFN graduation arc step 1 — detector parity audit.** First step in
the CFN graduation plan agreed 2026-05-14. Goal: produce a defensible
matrix of detector→CFN status so the marketing claim "Efterlev reads
CloudFormation" matches what the code actually does.

### Added

- **`scripts/build_cfn_parity_table.py`** — generator that introspects
  `_MAPPINGS` + each mapping function's `tf_type` overrides + each
  detector's `r.type ==` filters. Adds a manual-review classification
  layer for: TF type aliases (`aws_alb` ↔ `aws_lb`), TF data sources
  (`aws_iam_policy_document` — no CFN concept), TF-only-by-design
  types (account-level settings), and TF sub-resources CFN bundles
  inline (S3 versioning/acl/SSE/lifecycle inside `AWS::S3::Bucket`'s
  body). Re-run when a new detector lands or the property mapping
  table changes.
- **`docs/cfn-detector-parity.csv`** (authoritative) — one row per
  detector with: `detector_id`, `tf_types_read`,
  `cfn_types_mapped_or_bundled_into`, `cfn_status`, `notes`.
- **`docs/cfn-detector-parity.md`** — wrapper page explaining the
  matrix, the classification scheme, and the real coverage gaps.

### Coverage at v0.1.95

| Status | Count |
|---|---|
| full | 45 |
| partial-by-design | 10 |
| partial | 1 |
| TF-only-by-design | 2 |
| TF-only-missing-mapping | 2 |

**Effective CFN coverage: 92%** (full + partial-by-design = 55 of 60).

### Honest correction

The v0.1.93 "CFN type-coverage CLOSED" claim was off by 8 types. The
parity audit surfaced:

- `aws.centralized_log_aggregation` (partial) — reads 7 unmapped CFN
  types: `AWS::Logs::Destination`, `AWS::Logs::SubscriptionFilter`,
  `AWS::OpenSearchService::Domain`, `AWS::Elasticsearch::Domain`,
  `AWS::KinesisFirehose::DeliveryStream`, `AWS::SecurityHub::Hub`,
  `AWS::SecurityHub::FindingAggregator`.
- `aws.iam_user_access_keys` + `aws.iam_service_account_keys_age`
  (TF-only-missing-mapping) — both need `AWS::IAM::AccessKey` (a real
  CFN resource type).

Closing this gap is a small follow-up patch (v0.1.96 candidate). The
v0.1.93 inventory script missed `centralized_log_aggregation`'s
7-type read because the detector reads many TF types in one filter —
auto-inventory needs better spot-checks.

### TF-only by design (no fix planned)

- `aws.iam_password_policy`: IAM account password policy is an
  account-level setting in AWS, deployable only via the IAM API or
  AWS Console. No CFN resource type exists.
- `aws.iam_managed_via_terraform`: meta-detector that confirms the
  workspace declares any `aws_iam_*` resources at all — TF-only by
  definition.

### Why this matters

Pre-v0.1.95, the `--allow-cfn` flag still framed CFN as experimental,
but the CFN→TF mapping table covered 62 types and detector tests
passed. The parity audit gives us defensible per-detector coverage
data — the input the next graduation steps need (2nd CFN fixture +
maintainer-validation pass; doc graduation; flag deprecation).

### Next steps in the CFN graduation arc

1. **v0.1.96** (proposed): close the 8 missing-mapping types so
   coverage actually IS at 100%.
2. **v0.1.97+**: 2nd labeled CFN fixture + maintainer-validation pass
   to lift validation breadth from 23 labels (1 fixture) to ~50
   (matching the TF-side baseline shape).
3. **v0.2.0**: doc graduation (remove "experimental" framing) +
   `--allow-cfn` deprecation warning.
4. **v0.3+**: line-level provenance for CFN (deferred — not a
   graduation gate).

## [0.1.94] — 2026-05-14

**Repo-content cleanup — competitive positioning + hackathon framing
removed.** Two scrubs in one PR per user directive: (1) "remove the
COMPETITIVE_LANDSCAPE.md file. that is not appropriate" and
(2) "some documents still mention a hackathon. that never happened.
remove all references to it."

### Removed

- `COMPETITIVE_LANDSCAPE.md` (18KB top-level competitive analysis
  positioning Efterlev against Paramify, compliance.tf, Comp AI,
  RegScale, Vanta/Drata)
- `docs/comparisons/paramify.md`
- `docs/comparisons/compliance-tf.md`
- `docs/comparisons/comp-ai.md`
- `docs/comparisons/vanta-drata.md`
- `docs/comparisons/consultant.md`
- `docs/dual_horizon_plan.md` (hackathon-framed planning doc;
  Layer 1 Hackathon MVP / Layer 2 Post-hackathon structure was
  inaccurate since no hackathon happened, and doc was also stale
  at v0.1.93)

### Changed

- **`mkdocs.yml`** — dropped the entire Comparisons nav section
  (5 entries) and the Competitive landscape Project links entry.
  Removed `dual_horizon_plan.md` from `exclude_docs`.
- **CLAUDE.md** — scrubbed 3 references to `COMPETITIVE_LANDSCAPE.md`
  + 2 references to `dual_horizon_plan.md` from the project
  layout, project-links list, and intro paragraph. Updated repo
  layout snippet to reflect the deleted `comparisons/` subdir.
- **CODE_OF_CONDUCT.md** — preserved the no-FUD-about-competitors
  policy but removed the inline `COMPETITIVE_LANDSCAPE.md` reference.
- **CONTRIBUTING.md** — same treatment for the No FUD bullet.
  Renamed "Post-hackathon community coordination" header to
  "Community coordination."
- **GOVERNANCE.md** — removed `COMPETITIVE_LANDSCAPE.md` from the
  Scope boundaries entry; left `docs/icp.md` reference intact.
- **docs/architecture.md** — removed `COMPETITIVE_LANDSCAPE.md`
  + `docs/dual_horizon_plan.md` bullets from the related-docs list.
- **docs/faq.md** — removed broken `comparisons/paramify.md` link.
- **docs/index.md** — removed broken `comparisons/comp-ai.md` link;
  rephrased the "see [comparisons]" callout into a bare statement.
- **DECISIONS.md** — bulk-replaced 29 "hackathon" references with
  "v0 MVP" / "v0" / "pre-v0" depending on context. Dates and
  decisions unchanged; only the framing language updated.
- **README.md** — rephrased the Credits paragraph: "bootstrapped
  in a 4-day hackathon" → "bootstrapped" (claim was false anyway).
- **THREAT_MODEL.md** — "hackathon MVP" → "v0".
- **docs/icp.md** — "post-hackathon, first external usage" →
  "first external usage".
- **scripts/{README, catalogs_crossref, trestle_smoke,
  mcp_smoke_server}.py** — narrative "pre-hackathon" / "during the
  hackathon" → "during initial setup" / "MCP smoke test" etc.
- **tests/{test_agents, test_oscal_loader}.py** — narrative refs
  scrubbed.
- **scripts/launch-grep-scrub.allowlist** — removed the
  COMPETITIVE_LANDSCAPE-specific allowlist line.

### Why this matters

Public competitive analysis on the project's GitHub repo is
unprofessional and risks legal exposure when positioning claims
go stale. Hackathon framing was inaccurate (no hackathon happened);
keeping it in user-visible docs misrepresented the project's
provenance. Both scrubs land together in v0.1.94.

### Preserved (deliberate, documented)

Historical entries in `DECISIONS.md` (3 references mentioning
the deleted COMPETITIVE_LANDSCAPE.md), `docs/specs/SPEC-01.md`,
`docs/specs/SPEC-38.md` left intact. These are dated records of
past planning; rewriting them would falsify history. Anyone
reading them as research understands they're historical.

### No code changes

Pytest still **1732 passing** — no test-count change. No source
files modified. mypy / ruff / bandit / check-docs all clean.
Pure repo-content cleanup.

## [0.1.93] — 2026-05-14

**CFN PR gamma.2 batch 8 — finishing batch.** Closes out CFN
type-coverage in one PR per user directive ("finish cloudformation, I
want it done"). 30 mappings unlock the remaining detector-referenced
CFN types. **Every detector is now reachable from CloudFormation.**

### Added

API Gateway DomainName (v1 + v2):
- **`AWS::ApiGateway::DomainName`** → `aws_api_gateway_domain_name`
- **`AWS::ApiGatewayV2::DomainName`** → `aws_apigatewayv2_domain_name`
  (CFN's nested `DomainNameConfigurations[0]` → TF's
  `domain_name_configuration[0]` block)

Monitoring + governance:
- **`AWS::AccessAnalyzer::Analyzer`** → `aws_accessanalyzer_analyzer`
- **`AWS::GuardDuty::Detector`** → `aws_guardduty_detector`
- **`AWS::Config::ConfigurationRecorder`** →
  `aws_config_configuration_recorder` (override)
- **`AWS::Config::DeliveryChannel`** →
  `aws_config_delivery_channel` (override)
- **`AWS::CloudWatch::Alarm`** → `aws_cloudwatch_metric_alarm`
  (override; TF type adds `metric_` infix)
- **`AWS::Events::Rule`** → `aws_cloudwatch_event_rule` + synthesized
  `aws_cloudwatch_event_target` per `Targets` entry (1→1+N).
  `EventPattern` dict JSON-stringified per TF schema.

Data services for `aws.svc_at_rest_encryption_coverage`:
- **`AWS::DocDB::DBCluster`** → `aws_docdb_cluster` (override)
- **`AWS::Neptune::DBCluster`** → `aws_neptune_cluster` (override;
  Neptune uses `kms_key_arn` while RDS uses `kms_key_id` — AWS API
  asymmetry the mapping handles)
- **`AWS::ElastiCache::ReplicationGroup`** →
  `aws_elasticache_replication_group` (override)
- **`AWS::ElastiCache::CacheCluster`** → `aws_elasticache_cluster`
  (note: CFN's `CacheCluster` becomes TF's bare `cluster`)
- **`AWS::EFS::FileSystem`** → `aws_efs_file_system` (override)

EC2 family completion:
- **`AWS::EC2::LaunchTemplate`** → `aws_launch_template` (unwraps
  CFN's `LaunchTemplateData` envelope to lift `MetadataOptions` to
  the top level matching the EC2::Instance pattern from batch 6;
  unlocks `aws.ec2_imdsv2_required` on launch templates)
- **`AWS::EC2::VPC`** → `aws_vpc` (override)
- **`AWS::EC2::Subnet`** → `aws_subnet` (override)
- **`AWS::EC2::SecurityGroupIngress`** → `aws_security_group_rule`
  (CFN's single-string `CidrIp` → TF's single-element list
  `cidr_blocks`; sets `type=ingress` to match the detector's filter)

Load balancer family:
- **`AWS::ElasticLoadBalancingV2::LoadBalancer`** → `aws_lb`. CFN's
  generic `LoadBalancerAttributes: [{Key, Value}, ...]` translates
  to TF's `access_logs[0].{enabled, bucket, prefix}` block by
  parsing `access_logs.s3.enabled` / `.bucket` / `.prefix` keys.
- **`AWS::ElasticLoadBalancing::LoadBalancer`** (Classic v1) →
  `aws_elb`. CFN's structured `AccessLoggingPolicy.{Enabled,
  S3BucketName, S3BucketPrefix, EmitInterval}` → TF's
  `access_logs[0].{enabled, bucket, bucket_prefix, interval}`.

IAM federation:
- **`AWS::IAM::SAMLProvider`** → `aws_iam_saml_provider` (override)
- **`AWS::IAM::OIDCProvider`** → `aws_iam_openid_connect_provider`
  (note tf_type asymmetry: CFN's compact `OIDCProvider` becomes TF's
  spelled-out `openid_connect_provider`)

Backup family:
- **`AWS::Backup::BackupPlan`** → `aws_backup_plan`. Unwraps
  `BackupPlan.BackupPlanRule` nested-list with `Lifecycle.{DeleteAfterDays,
  MoveToColdStorageAfterDays}` → `lifecycle[0].{delete_after,
  cold_storage_after}`.
- **`AWS::Backup::BackupVault`** → `aws_backup_vault` (`EncryptionKeyArn`
  → `kms_key_arn`)
- **`AWS::Backup::BackupSelection`** → `aws_backup_selection`
- **`AWS::Backup::RestoreTestingPlan`** → `aws_backup_restore_testing_plan`
- **`AWS::Backup::RestoreTestingSelection`** → `aws_backup_restore_testing_selection`

Misc:
- **`AWS::Logs::ResourcePolicy`** → `aws_cloudwatch_log_resource_policy`
  (note tf_type asymmetry: CFN's `Logs::ResourcePolicy` → TF's
  `cloudwatch_log_resource_policy`; PolicyDocument dict JSON-stringified)
- **`AWS::SecretsManager::RotationSchedule`** →
  `aws_secretsmanager_secret_rotation`
- **`AWS::AutoScaling::AutoScalingGroup`** → `aws_autoscaling_group`
  (override)
- **`AWS::ECS::Service`** → `aws_ecs_service`
- **`AWS::CloudFront::Distribution`** → `aws_cloudfront_distribution`
  with `DistributionConfig` envelope unwrap;
  `DefaultCacheBehavior` → `default_cache_behavior[0]`,
  `CacheBehaviors` → `ordered_cache_behavior[N]`,
  `ViewerCertificate` → `viewer_certificate[0]`

### Tests

- **`tests/test_cfn_property_mapping_batch8.py`** — 43 new parity
  tests covering basic translation + detector-fires-on-CFN
  end-to-end for each new type.
- Updated 3 pre-existing tests in `test_cloudformation_adapter.py` +
  `test_cfn_property_mapping.py` to use `AWS::Athena::WorkGroup`
  (no detector reads Athena; reliably unmapped) for the
  unmapped-fallback path. CloudFront::Distribution was the previous
  stand-in but is now explicitly mapped.
- Test count: 1689 → **1732** (+43).

### Why this matters

Pre-v0.1.93 CFN type-coverage was 32 of 54 detector-referenced types.
Batch 8 closes the remaining 22 detector-referenced types (some are
covered transitively — e.g. `AWS::WAFv2::WebACLAssociation` was
already mapped). **Every detector is now reachable from CFN at
v0.1.93** — the strategic arc that started with the v0.1.81 22/22 =
100/100 maintainer-validation gate has its full property-mapping
back-end shipped.

### NOT mapped (deliberate — documented limitation)

- **`AWS::IAM::AccountPasswordPolicy`** — not a real CFN resource type.
  The IAM account password policy is an account-level setting in AWS,
  deployable only via the IAM API or AWS Console. The
  `aws.iam_password_policy` detector still works on Terraform (TF's
  `aws_iam_account_password_policy` abstracts the API call). CFN
  users hit this gap via direct API call — outside Efterlev's IaC
  scope.

### Next steps (post-CFN)

Per strategic arc memory: CDK adapter (synthesize CDK to CFN
templates, then route through the now-complete CFN pipeline). CDK is
a larger market story but lands cleanly because CFN coverage is now
closed.

## [0.1.92] — 2026-05-14

**CFN PR gamma.2 batch 7 — IAM Group + API Gateway pair.** 5 CFN type
mappings unlock 7 detectors. Documents two AWS-side naming
inconsistencies between API Gateway v1 and v2 that the mapping handles
transparently.

### Added

- **`AWS::IAM::Group`** → `aws_iam_group` + synthesized
  `aws_iam_group_policy_attachment` per `ManagedPolicyArns` entry +
  synthesized `aws_iam_group_policy` per inline `Policies` entry. Same
  1→(1+N+M) synthesis pattern as `AWS::IAM::Role` / `AWS::IAM::User`
  from PR gamma.2 batch 2. Unlocks 4 detectors: iam_admin_policy_usage,
  iam_inline_policies_audit, mfa_required_on_iam_policies,
  mla_log_access_least_privilege.
- **`AWS::ApiGateway::Stage`** → `aws_api_gateway_stage` (REST API v1).
  CFN's singular `AccessLogSetting` → TF's plural `access_log_settings`.
  tf_type override needed.
- **`AWS::ApiGatewayV2::Stage`** → `aws_apigatewayv2_stage` (HTTP /
  WebSocket v2). CFN's plural `AccessLogSettings` (note the v1/v2
  asymmetry) → TF's `access_log_settings`. No tf_type override needed.
- **`AWS::ApiGateway::Method`** → `aws_api_gateway_method`. v1's
  `AuthorizationType` maps to TF's bare `authorization` — TF v1
  flattened the suffix in its schema. tf_type override needed.
- **`AWS::ApiGatewayV2::Route`** → `aws_apigatewayv2_route`. v2's
  `AuthorizationType` maps to TF's `authorization_type` — v2 keeps the
  suffix. No tf_type override needed.
- **`tests/test_cfn_property_mapping_batch7.py`** — 13 parity tests:
  IAM Group basic + managed-policy synthesis + inline-policy
  synthesis + admin detector parity; v1 Stage basic + access-logging
  detector parity; v2 Stage basic + adapter-routing + access-logging
  detector parity; v1 Method basic + auth detector parity; v2 Route
  basic + auth detector parity.

### Why this matters

Pre-v0.1.92 CFN type-coverage was 27 of 54 detector-referenced types.
Batch 7 → **32 (59%)**. The IAM Group mapping is high-yield (4
detectors) — same shape as the IAM Role/User mappings already in the
table. The API Gateway pair docs the v1/v2 naming inconsistencies in
one place so future detector authors don't get bitten.

### Deferred

- **`AWS::ApiGateway::DomainName` + `AWS::ApiGatewayV2::DomainName`**
  — `aws.api_gateway_tls_min_version` reads them. Saved for batch 8
  (long tail).
- **`AWS::IAM::AccessKey`** — `aws.iam_service_account_keys_age` and
  `aws.iam_user_access_keys` read it; deferred to a later batch.

### Next batches

- **Batch 8+**: long tail (Backup, Config, GuardDuty, EFS,
  ElastiCache, OpenSearch, CloudFront, EC2 LaunchTemplate, etc.).
  Each is a 1-detector unlock; the marginal yield drops from here.

## [0.1.91] — 2026-05-14

**CFN PR gamma.2 batch 6 — RDS Cluster + EC2 NetworkAcl pair + EC2 Instance.**
Mid-tier batch in the gamma.2 series: 4 CFN type mappings unlock 7
detectors, no detector code changes.

### Added

- **`AWS::RDS::DBCluster`** → `aws_rds_cluster`. Sibling to
  `AWS::RDS::DBInstance` from PR gamma.2 batch 3; same flat-rename
  pattern. Reads exposed: `backup_retention_period`,
  `storage_encrypted`, `kms_key_id`, `availability_zones`,
  `deletion_protection`.
- **`AWS::EC2::NetworkAcl`** → `aws_network_acl` (bare). CFN splits
  NACL rules into separate Entry resources unlike SecurityGroup which
  inlines them. tf_type override needed because `cfn_type_to_tf_type`
  yields `aws_ec2_networkacl`.
- **`AWS::EC2::NetworkAclEntry`** → `aws_network_acl_rule`. Structural
  flatten: `PortRange.{From, To}` → top-level `from_port`/`to_port`;
  `Icmp.{Type, Code}` → `icmp_type`/`icmp_code`. tf_type override.
- **`AWS::EC2::Instance`** → `aws_instance`. tf_type override.
  `MetadataOptions.{HttpTokens, ...}` → `metadata_options[0]` list-
  wrapped block. `BlockDeviceMappings: [{DeviceName, Ebs: {Encrypted,
  KmsKeyId, ...}}]` → `ebs_block_device[N]`. v0.1.91 puts ALL Ebs
  mappings under `ebs_block_device` — no root-vs-non-root heuristic
  (CFN doesn't carry the AMI's root device name; detectors flag
  unencrypted volumes from either `root_block_device` or
  `ebs_block_device`, so coverage is preserved — only the per-Evidence
  label differs).
- **`tests/test_cfn_property_mapping_batch6.py`** — 17 parity tests:
  RDS Cluster (basic + AZ list + 3 detector parity), NACL (basic Acl +
  Entry + Icmp flatten + 2 detector parity), EC2 Instance (basic +
  metadata_options + ebs_block_device + virtual-name skip + 2 detector
  parity).

### Why this matters

Pre-v0.1.91 CFN type-coverage was 23 of 54 detector-referenced types.
Batch 6 → **27 (50%)**. Detector-coverage delta: 7 detectors. The
RDS Cluster mapping is the highest-yield item (4 detectors); NACL pair
+ EC2 Instance round out the EC2 family started in batches 1 and 5.

### Deferred

- **Root-vs-non-root EBS heuristic for `AWS::EC2::Instance`** — CFN
  doesn't tell us which mapping is the root volume. Future enhancement:
  match `/dev/sda1`, `/dev/xvda`, `/dev/nvme0n1` to put root mapping
  under `root_block_device` instead of `ebs_block_device`.
- **`AWS::EC2::LaunchTemplate`** — `aws.ec2_imdsv2_required` reads it
  too. Deferred to a later batch (LaunchTemplate has its own
  `LaunchTemplateData` envelope with embedded MetadataOptions /
  BlockDeviceMappings; non-trivial nested-block translation).

### Next batches

- **Batch 7**: IAM Group + API Gateway pair (`AWS::ApiGateway::Stage`,
  `AWS::ApiGatewayV2::Stage`) — 4 types unlocking ~4 detectors.
- **Batch 8+**: long tail (Backup, Config, GuardDuty, EFS,
  ElastiCache, OpenSearch, etc.).

## [0.1.90] — 2026-05-14

**CFN PR gamma.2 batch 5 — WAF family.** Highest-impact batch in the
gamma.2 series: 5 CFN type mappings unlock 8 detectors (the whole WAF
family + cna_dos_protection's WAFv2 path), no detector code changes.

### Added

- **`AWS::WAFv2::WebACL`** → `aws_wafv2_web_acl` with deep
  `Rules → rule[N]` and `Statement → statement[0]` translation.
  Statement kinds translated explicitly (read by current detectors):
  `GeoMatchStatement.CountryCodes`, `RateBasedStatement.{Limit,
  AggregateKeyType}`, `ManagedRuleGroupStatement.{VendorName, Name,
  Version}`, `IPSetReferenceStatement.Arn`,
  `RuleGroupReferenceStatement.Arn`. `Action.{Block, Allow, Count,
  Captcha, Challenge}` and `OverrideAction.{None, Count}` each become
  list-wrapped empty blocks per python-hcl2 convention.
- **`AWS::WAFv2::WebACLAssociation`** → `aws_wafv2_web_acl_association`
  (`ResourceArn`, `WebACLArn` rename).
- **`AWS::WAFv2::RuleGroup`** → `aws_wafv2_rule_group` (Rules deep-
  translation reuses the WebACL Statement translator).
- **`AWS::WAF::WebACL`** (legacy v1) → `aws_waf_web_acl`. Minimal
  mapping: only `cna_dos_protection` reads WAF Classic, and only for
  existence/name. Deep-translation deferred until a Tier-3-#4 detector
  targets WAF Classic specifically.
- **`AWS::Shield::Protection`** → `aws_shield_protection` (Name +
  ResourceArn rename; default tf_type already correct).
- **`tests/test_cfn_property_mapping_batch5.py`** — 21 parity tests:
  every Statement kind isolated, every Action/OverrideAction kind, an
  end-to-end fixture exercising 6 of the 8 detector read paths
  (waf_geo_blocking, waf_rate_limiting, waf_managed_rule_groups,
  waf_ip_set_blocking, waf_custom_rule_groups, waf_rule_count,
  waf_action_types, plus cna_dos_protection's WAFv2-aware path).

### Why this matters

Pre-v0.1.90 CFN coverage was 18 mapped types out of 54 detector-
referenced types. The WAF family alone is 8 detectors; this batch
moves the gamma.2 needle from 28% type-coverage → 37%, but the
detector-coverage delta is bigger because the WAF family is unusually
detector-dense (most CFN types unlock 1-2 detectors; WAFv2::WebACL
alone unlocks 8).

### Deferred (continuing the gamma.2 plan)

- **Batch 6** (next): RDS Cluster + EC2 NetworkAcl pair + EC2 Instance
  — 4 types unlocking ~7 detectors.
- **Batch 7**: IAM Group + API Gateway pair — 4 types unlocking ~4
  detectors. IAM Group needs the same `Policies` inline-list synthesis
  pattern as IAM Role (PR gamma.2 batch 2).
- **Batch 8+**: long tail — Backup, Config, GuardDuty, EFS,
  ElastiCache, OpenSearch, etc. (each 1 detector).

## [0.1.89] — 2026-05-14

**release-smoke signature-verify cosign-installer v3 → v4.1.2.** Real
fix for the SLSA-attestation verification gap that v0.1.88 attempted
to close.

v0.1.88 pinned `cosign-release: 'v3.0.6'` under `cosign-installer@v3`,
but the v3-action's installer 404s on `cosign-linux-amd64.sig` —
**cosign v3.x dropped `.sig` files** in favor of `.sigstore.json`
bundles, and the v3-action only knows how to install v2.x. v4.0+ added
cosign v3 install support; v4.1.2 (2026-05-07) defaults to cosign
v3.0.6 per its release notes ("Bump cosign to 3.0.6 in #232").

### Changed

- **`.github/workflows/release-smoke.yml`** — bump `cosign-installer`
  from `@v3` (sha `398d4b0e…`) to `@v4.1.2` (sha
  `6f9f1778…`). Drop the now-redundant `cosign-release: 'v3.0.6'`
  input — that's the v4.1.2 default. Keeps action SHA-pinned per
  the v0.1.62 SLSA-L3 hardening.

### Why this matters

The v0.1.87 release exposed a latent CI bug: cosign v2.5.2 in CI can't
verify the SLSA v1 attestations actions/attest-build-provenance writes.
v0.1.88 picked the wrong fix shape (right cosign version, wrong action
version). v0.1.89 lands the action bump that actually installs cosign
v3.x in CI. The v0.1.87 + v0.1.88 published artifacts remain
cryptographically valid (verified locally with cosign v3.0.6, 4/4) —
this is purely the CI-tooling lag.

### Deferred (unchanged from v0.1.88)

- **`release-container.yml`'s cosign-installer at @v3** — its `cosign
  sign` and `cosign verify` (signature, not attestation) calls work
  fine on cosign v2.5.2; only SLSA-attestation verify breaks. Leaving
  alone; will bump if/when its surface area widens.

## [0.1.88] — 2026-05-14

**release-smoke signature-verify cosign pin.** Surgical CI-tooling fix
to the `signature-verify` job in `.github/workflows/release-smoke.yml`.
The job runs `scripts/verify-release.sh` against each tag's published
artifacts; it had been failing on v0.1.87 even though the release was
fully cryptographically valid (verified locally with cosign v3.0.6:
4/4 checks passed end-to-end — Sigstore wheel + sdist + container
cosign sig + SLSA provenance).

Root cause: `sigstore/cosign-installer@v3`'s default `cosign-release`
input is **cosign v2.5.2**, which cannot verify the **SLSA v1**
attestations (`predicateType: https://slsa.dev/provenance/v1`) that
`actions/attest-build-provenance` writes to the container manifest.
cosign v3.x reads them correctly. Pre-v0.1.87 releases hid this
regression because the `macos-13` release-smoke cell got stuck queued
indefinitely (the same cell `v0.1.87` removed as part of the matrix
slim) — so `signature-verify` (which depends on `needs: [smoke]`)
never actually ran on v0.1.80 through v0.1.86.

### Changed

- **`.github/workflows/release-smoke.yml`** — pin `cosign-release:
  'v3.0.6'` on the `Install cosign` step in the `signature-verify`
  job. One-line workflow fix; the action SHA stays pinned.

### Why this matters

Without the pin, every future release would show a misleading red
"signature-verify failed" status on its release page even though
the artifacts are cryptographically valid. The product itself is
unaffected — `pipx install efterlev` and `docker pull
ghcr.io/efterlev/efterlev:vX.Y.Z` work fine, and any user running
`scripts/verify-release.sh` locally with a modern cosign passes
verification. The pin makes the CI status match reality.

### Deferred

- **release-container.yml's cosign-installer also pulls the v2.5.2
  default**, but its `cosign sign` and `cosign verify` (signature, not
  attestation) calls succeed fine on v2.5.2 — the SLSA-attestation
  verify is the only operation that breaks. Keeping that workflow
  unchanged at v0.1.88; will pin if/when its surface area widens.

## [0.1.87] — 2026-05-13

**GitHub Actions minute-budget reduction — 3-fix workflow bundle.**
The repo-wide audit on 2026-05-13 surfaced three structural CI-cost
leaks: a 7-cell release-smoke matrix that double-covered the same
(OS × install-method) combinations, a `push:` trigger on `ci.yml`
that double-fired the lint/type-check/test job on every PR (the
concurrency group key included `github.ref` so push and PR didn't
dedup), and a `paths:` filter on `e2e-smoke.yml` that matched the
`__version__` source-of-truth file and triggered the ~3-4min
harness on doc-only releases. None of these change product
behavior — they just stop paying for waste.

### Changed

- **`.github/workflows/release-smoke.yml`** — install-verification
  matrix slimmed from 7 cells to 4. Dropped `ubuntu-24.04-arm pipx`
  + `ubuntu-24.04-arm docker-ghcr` (architecture-specific bugs are
  rare for pure-Python projects with no native deps; the container
  image is still built for both archs in `release-container.yml`)
  and `macos-13 pipx` (one macOS version is enough for first-
  impression catch; macOS users upgrade promptly). Coverage
  retained: pipx on linux/mac/windows, docker on linux. Saves
  ~15 min per release tag (~3 cells × ~5 min).
- **`.github/workflows/ci.yml`** — dropped `push: branches: ['**']`
  trigger; kept only `pull_request:`. The concurrency group's key
  (`${{ github.workflow }}-${{ github.ref }}`) doesn't dedup push
  vs PR because `github.ref` differs (`refs/heads/<branch>` vs
  `refs/pull/<N>/merge`), so every PR was running CI twice. Saves
  ~3 min per PR. Push-to-main still gets covered (all merges land
  via PR under this repo's protected-branch posture); direct pushes
  to feature branches that aren't yet PRs no longer auto-trigger
  CI — developer runs gates locally before opening the PR.
- **`.github/workflows/e2e-smoke.yml`** — added a version-bump-only
  filter to the `Detect source/test changes vs PR base` step. If
  `src/efterlev/__init__.py` is the only changed file under `src/`
  and no other matched files changed, the harness sets `skip=true`
  and graceful-no-ops. Pre-v0.1.87 doc-only releases triggered
  e2e_smoke (~5 min wasted) because the `paths:` regex matched
  `^src/`. Saves ~5 min per doc-only release PR.

### Why this matters

Aggregate savings under our current ~5 releases/week + ~10 PRs/week
cadence is ~75 min/week of release-smoke and ~30 min/week of CI
double-firing — material against the GH Actions minute budget. Even
on Enterprise (50,000 min/mo cap), removing waste lowers the run
bill regardless of cap. None of the cuts are coverage-blind: each
removal documents what was dropped and why it's low-yield.

### Deferred

- **Re-enabling arm + macos-13 cells** if those architectures
  become a customer ask. The trigger to re-add is "first arm-
  specific or macos-13-specific install bug from a real install
  path" — at that point the cost of the cell is justified.
- **Bedrock-path e2e-smoke** still opt-in via
  `EFTERLEV_BEDROCK_SMOKE=1` (separate harness, not yet wired
  into CI — needs AWS OIDC role + region config; tracked as a
  v0.2 followup, unchanged from v0.1.86).

## [0.1.86] — 2026-05-13

**Streaming-tokens-as-progress for the Gap Agent.** Closes the
"silent for ~60-90s" UX gap during `efterlev agent gap`. The agent
is a single batched LLM call by design (DECISIONS 2026-04-22 —
classification needs cross-KSI reasoning), but until v0.1.86 the
user had no signal the process wasn't hung. Now: per-KSI lines
stream to stderr as the model emits classifications.

### Added

- **`src/efterlev/agents/gap_progress.py`** — new module.
  `GapProgressReporter` regex-extracts `"ksi_id": "KSI-XXX-YYY"`
  patterns from cumulative streaming text and prints `[gap]
  classifying KSI X/N: KSI-AAA-BBB` per new ID. Falls back to a
  `[gap] thinking... (Ns elapsed, ~K tokens received)` heartbeat
  every 2s during the model's reasoning-summary preamble. Final
  `[gap] done in T.Ts — N/total KSIs classified` summary on
  completion. `make_reporter_if_tty()` helper returns a reporter
  only when stderr is a TTY (CI runs get None — output stays
  clean).
- **`tests/test_gap_progress.py`** — 8 tests covering regex
  extraction, deduplication, heartbeat behavior, TTY-only helper,
  finish-summary semantics, and end-to-end plumbing through the
  StubLLMClient.

### Changed

- **`LLMClient.complete` Protocol** + `StubLLMClient` +
  `AnthropicClient` + `BedrockClient` all accept an optional
  `on_chunk: Callable[[str], None]` parameter. Anthropic streams
  text-deltas (uses the existing `client.messages.stream()` per
  DECISIONS 2026-05-10 — just exposes the chunks now). Bedrock
  Converse is non-streaming so `on_chunk` fires once with the full
  text at end (uniform contract; per-backend granularity differs).
  `StubLLMClient` simulates ~8 chunks for test coverage.
- **`Agent._invoke_llm`** plumbs `on_chunk` through to the LLM call.
- **`GapAgentInput.progress_callback`** new optional field; CLI
  `agent gap` installs `make_reporter_if_tty()` and wires it through.
- **CLI `agent gap`** end-of-run calls `progress.finish()` for the
  final summary.

### Why this matters

Three different prospects this morning ran `efterlev report run` and
asked the maintainer mid-run if the tool was hung. Per-KSI streaming
output is the cheapest possible UX fix — uses already-streaming
infrastructure (Anthropic SDK's `messages.stream` ships chunks; we
just stopped throwing them away). Zero LLM-call cost change. Zero
risk to the v0.1.81 23/23 = 100/100 baseline (no prompt change, no
per-KSI emission semantics change — the agent still produces the
same JSON; we just narrate the user through the wait).

### Deferred

- **Bedrock streaming** would require switching from `Converse` to
  `ConverseStream` API + a different result-aggregation path. Not
  worth the work today; Bedrock users get one final-text on_chunk
  call (no incremental progress) — same UX as pre-v0.1.86.
- **Documentation Agent / Remediation Agent streaming progress** —
  Documentation already has `TerminalProgressCallback` per-KSI;
  Remediation is a single per-KSI run (no per-KSI loop to narrate).
  Both are fine as-is.

## [0.1.85] — 2026-05-13

**Documentation Agent narrative quality — honest finding + targeted
template improvement.** Item #7 from the maintainer-feedback list.
Surveyed the v0.1.81 dispatch artifacts to identify weak spots in
the FRMR attestation narratives.

### Honest finding (no LLM-prompt change)

The Documentation Agent's **LLM-drafted narratives are already in
strong shape**. 32/32 LLM-drafted narratives in the v0.1.81 dispatch
have explicit reviewer-action framing ("A reviewer should verify…"),
specific resource names (`aws_kms_key.DataTierKey`,
`aws_lambda_function.AppHandler`), exact config quotes
(`rotation_status = enabled`, `algorithm = aws:kms`), multi-layer
scope, and explicit gap callouts. The system prompt
(`agents/documentation_prompt.md`) is mature: 3 worked examples,
explicit scope discipline, forbids hedge/marketing language, requires
verbatim quoting from manifest evidence.

**Therefore: no LLM system-prompt changes in v0.1.85.** Touching it
would risk the v0.1.81 23/23 = 100/100 baseline without a clear gain
visible in the existing artifacts. Defer prompt-engineering polish
until concrete user feedback identifies a specific weakness — not
maintainer speculation.

### Changed (deterministic-template polish, no LLM-prompt risk)

The "templated" feedback in the original list applies most to the
**deterministic inapplicable narratives** (cost-optimized template
that fires for the 25-45 procedural KSIs in a typical 60-KSI run,
saving the per-narrative LLM call). These are formulaic by design;
v0.1.85 makes the procedural-corroboration framing per-KSI-family-
specific so reviewers know exactly which artifacts to ask the
customer for:

- **AFR-*** → "signed FedRAMP authorization-data-sharing agreements,
  agency liaison records, and per-KSI continuity-of-operations
  attestations from program leadership."
- **CED-*** → "security-awareness training completion records
  (per-employee, per-quarter), role-based education curricula, and
  trainer-of-record attestations."
- **INR-*** → "incident-response playbooks, post-incident review
  records, on-call schedule attestations, and tabletop-exercise
  sign-offs."
- **PIY-*** → "policy publication evidence (version-controlled with
  effective dates), internal-training records, and management
  acknowledgment signatures."
- Unknown families → fall back to the pre-v0.1.85 generic hint.

Pre-v0.1.85 the generic hint ("policy documents, signed attestations,
operational runbooks, training-completion records, or other non-IaC-
evidenceable sources") applied uniformly. Per-family hints make the
3PAO ask sharper without burning an LLM call (cost stays $0 on the
inapplicable path).

### Added

- **`src/efterlev/agents/documentation.py:_PROCEDURAL_EVIDENCE_HINTS_BY_FAMILY`**
  + `_procedural_hint_for(ksi_id)` helper.
- **`tests/test_documentation_agent.py::test_inapplicable_narrative_includes_family_specific_procedural_hint`**
  — pins the 4 known-family hints + the unknown-family fallback.

### Re-validation

LLM prompt unchanged → no eval-harness re-dispatch needed for this
release. The deterministic template changes are pure-string changes
in the procedural narrative; the harness's status_precision and
status_recall metrics are unaffected by narrative content (they're
computed from KSI verdicts, not narrative text).

### What's still legitimate-future-work for the Doc Agent

- LLM-prompt tightening based on **specific user feedback** ("this
  narrative felt vague because…"). Speculative-without-feedback
  changes carry regression risk against the validated baseline.
- Per-family LLM examples in the prompt itself (currently 3 generic
  examples; could be ~10 examples covering each KSI family). Would
  require the eval-harness re-dispatch to confirm no regression.
- Streaming-tokens-as-progress in the gap agent (silent ~60-90s).
  Different agent; different work shape.

## [0.1.84] — 2026-05-13

**UX-polish bundle — first-time-user onboarding moments.** Four
small additions to the user-facing prompts/output where prospects'
Claude instances and human first-time users decide whether the tool
is honest about cost, reachable, and pointed at the right next step.
No agent system prompt changes (those are v0.1.85's risk-bearing
work, gated on re-validating the 22/22 = 100/100 baseline).

### Added

- **`efterlev report run` cost rollup.** End-of-pipeline "Pipeline
  total: $X.XX over N tokens" line that sums Gap + Documentation +
  Remediation spend in one place. Each per-agent stage already
  printed its own line; the rollup is what users actually want to
  see ("what did the whole report cost?"). Captured per `run_once()`
  invocation so `--watch` iterations roll only their own spend.
- **`efterlev quickstart` cost rollup.** Same shape — single "Total"
  line at the bottom of the success summary on the API-key path.
  Silently omitted on the keyless path (nothing to sum).
- **`efterlev doctor` — CFN-template detection check.** Walks the
  target tree for `.yaml`/`.yml`/`.json` files with `Resources:`
  or `AWSTemplateFormatVersion`. When found, surfaces a `warn` with
  an actionable hint pointing at `efterlev scan --allow-cfn` (citing
  the v0.1.81 23/23 = 100/100 validation number). Pure-TF repos get
  a clean pass. Closes a real first-time-user gap: a CFN-shop
  prospect who runs `doctor` got no signal that the tool would skip
  their templates without the flag.
- **`efterlev init` next-steps section.** Three lines at the end of
  successful init pointing at `doctor`, `report run`, and `scan` —
  matching the pattern `agent gap` already uses. The post-init
  moment is the highest-leverage spot to point first-time users at
  the natural next commands.

### Changed

- **`efterlev doctor` — wrong-shape API key.** When the workspace
  is configured for the Anthropic backend AND `ANTHROPIC_API_KEY` is
  set but doesn't start with `sk-ant-`, the check now `fail`s
  (escalated from `warn`) — the LLM call is essentially guaranteed
  to 401. Hint identifies common confusables by prefix: `sk-proj-`
  → OpenAI project key (the maintainer hit this earlier this
  session); `sk_live_`/`sk_test_` → Stripe; `ghp_`/`gho_` → GitHub.
  Bedrock-configured workspaces stay at `warn` since the env var is
  irrelevant to that path.

### Verified, NOT changed

- Per-KSI agent progress: Documentation Agent already has a
  `TerminalProgressCallback` that prints `[idx/total] KSI-XXX ✓` per
  narrative. Gap Agent is a single batched LLM call (not per-KSI by
  design — DECISIONS 2026-04-22) so per-KSI progress doesn't apply.
  Streaming-tokens-as-progress for the gap call is a future
  enhancement, not in scope here.

## [0.1.83] — 2026-05-13

**Doc-accuracy patch — third-party-Claude-readability sweep.** With
prospects pointing their own Claude instances at the repo instead of
asking the maintainer questions, every README inaccuracy gets
multiplied across every prospect interaction. Three corrections:

### Fixed

- **`22/22` → `23/23`** across README + `evals/PHASE_2_LITE_CFN_VALIDATION.md`
  + CHANGELOG/CLAUDE/DECISIONS narrative. The CI workflow_dispatch
  artifact (run 25814274941, 2026-05-13 17:06:27 UTC) is authoritative
  at 23/23 against revision 2 labels; the prior 22/22 claim came from
  a manual Python recompute against the local Bedrock run's
  gap-*.json (against revision 1 before the second-pass review),
  not from an actual rev2 harness run. Both numbers are 100%
  precision + 100% recall — qualitative claim unchanged. Validation
  doc now explains the denominator difference (the harness's metric
  counts only labels where the agent ALSO produced a verdict; the
  agent's coverage of inapplicable-by-default KSIs is mildly
  stochastic across runs).
- **Patch-release count off-by-one.** README, LIMITATIONS, CLAUDE.md,
  and docs/index.md all said "eighty-four patch releases since
  v0.1.0" at v0.1.82 ship time. Only 83 tags existed (v0.1.0 through
  v0.1.82). Counting framing was inconsistent across files. v0.1.83
  release fixes by making the count correct (84 tags including
  v0.1.83) — the four docs were anticipating the next bump by
  accident.
- **`docs/index.md` stale CFN-validation framing.** The status para
  still said "the maintainer-validation LLM-call run for CFN remains
  the deferred bet-pays-off measurement" — stale post-v0.1.81 close.
  Updated to reflect the closed gate at 23/23 = 100/100.

### Verified accurate (non-bugs)

- All 19 doc/script/workflow file paths in README link to existing
  files.
- All 13 CLI commands + subcommands exist.
- "7 secret families" claim matches `src/efterlev/llm/scrubber.py`
  exactly (PEM, AWS access key, GCP API key, GitHub token, Slack
  token, Stripe API key, JWT).
- Per-agent default models match source: Gap (Opus 4.7),
  Documentation (Sonnet 4.6), Remediation (Opus 4.7).
- Quickstart default is Sonnet — matches the README claim.
- AI prompt recommends Sonnet 4.6 across all agents — matches the
  "Sonnet 4.6 (recommended default)" cost framing.
- Coverage numbers (66 detectors, 1629 tests, 227 source files,
  31 CLI commands) verified by `scripts/check-docs.py`.

### Why this batch shape

User-reported context: prospects pointing their own Claude instances
at github.com/efterlev/efterlev for tool questions instead of
asking the maintainer directly. Saves the maintainer time + gives
prospects better answers — but only if the README is 100% accurate.
The 22/22 vs 23/23 inconsistency would have been caught by any
careful Claude reading the validation doc + README; the patch-count
inconsistency would have surfaced on a `git tag -l` check. v0.1.83
closes both.

## [0.1.82] — 2026-05-13

**README visual content — first-impression credibility.** Adds a
real Gap Report HTML screenshot + a real POA&M markdown snippet
inline in the README, sourced from the v0.1.81 maintainer-validation
run artifacts. First-screen readers now see what the output actually
looks like before scrolling. Pairs with the v0.1.79 elevator-pitch
lift and v0.1.81's 23/23 = 100/100 numbers to give a complete pitch
shape: value-prop → artifact → install.

### Added

- **`docs/screenshots/gap-report-csp-starter.png`** — 1280×800 PNG
  (~100 KB) hero shot of the Gap Report HTML page from the v0.1.81
  validation run. Shows the title, classification counts, DRAFT
  banner, FedRAMP boundary state, and the color-coded coverage
  matrix across all KSI themes (AFR, CED, CMT, CNA, ...). Real
  output from a real `csp-starter-cfn` run.
- **`scripts/capture-screenshots.sh`** — regenerates the screenshot
  from the latest eval-harness run under
  `evals/results/csp-starter-cfn/`. Uses headless Google Chrome
  (override `CHROME_BIN` for non-macOS-standard paths). Future
  validation dispatches can refresh the README hero shot in one
  command rather than re-tooling around `playwright` or similar.
- **README screenshot embed + POA&M snippet** — between the
  elevator pitch (`$250K-consultant` blockquote) and the install
  commands. The shape now reads: value-prop → real artifact →
  install, so first-screen readers see what they'd get before
  deciding to `pipx install`. POA&M snippet is a fenced markdown
  block with 4 real KSI rows from the actual generated POA&M (full
  output has 32 open items).

### Why this batch shape

The maintainer-feedback thread (2026-05-13 morning) flagged the
missing-screenshot + missing-POA&M-snippet as the highest first-
impression-credibility wins available. v0.1.81 produced the real
artifacts; v0.1.82 lifts them into the README. The artifacts have
provenance — they're outputs of the maintainer-validation pass that
hit 23/23 = 100/100 (CI authoritative; see v0.1.83 entry for the correction history), not stock photos or doctored examples.

## [0.1.81] — 2026-05-13

**CFN maintainer-validation harness wiring + first dispatch run +
second-pass label review.** Closes the v0.1.78-deferred work AND
ships the actual precision/recall numbers in one release. The
strategic gate from DECISIONS 2026-05-12 ("we'll know whether the
strategic bet pays off only after this number is in") is now closed:

- **First-pass (revision 1, Haiku 4.5):** 20/22 = 90.9% precision +
  90.9% recall.
- **Second-pass (revision 2, alternation expansion):** **23/23 =
  100% precision + 100% recall** (CI workflow_dispatch authoritative;
  the original v0.1.81 entry said 22/22 from a manual recompute and
  was corrected in v0.1.83) — matches the TF-side v0.1.69 baseline
  (67/67 across 3 fixtures at 100/100).

The 2-of-22 first-pass gap was entirely maintainer-side label
optimism — 4 disagreements, 0 property-mapping bugs, 0 detector
bugs. After alternation-expanding the 4 labels (v0.1.67 TF-side
discipline applied here), the gap closes. Detailed analysis in
`evals/PHASE_2_LITE_CFN_VALIDATION.md`.

### Added

- **`evals/harness.py`** — `_fixture_has_cfn_templates()` helper
  content-sniffs `infra/*.{yaml,yml,json}` for the top-level
  `Resources:` / `AWSTemplateFormatVersion:` keys. When detected, the
  scan stage gets `--allow-cfn` appended. TF-only fixtures unchanged;
  mixed fixtures get both paths.
- **`.github/workflows/eval-harness-cfn.yml`** — `workflow_dispatch`
  workflow that runs the harness against any configured fixture with
  a real `ANTHROPIC_API_KEY` from CI secrets, prints per-KSI verdicts
  + metrics JSON to the run log, and uploads the full results dir as
  a 30-day-retained artifact. Inputs: `fixture` (default
  `evals/fixtures/csp-starter-cfn`), `llm_model` (default
  `claude-haiku-4-5`; choice list includes Sonnet 4.6 + Opus 4.7).
- **`evals/PHASE_2_LITE_CFN_VALIDATION.md`** — the CFN-side
  counterpart to `PHASE_2_LITE_MAINTAINER_VALIDATION.md`.
  Methodology + scope + cost-envelope-per-model are authoritative as
  of v0.1.81; the per-KSI Results table fills in after the first
  dispatch lands. Includes the strategic-implication framing: at
  ≥95% precision/recall the Tier 5 #1 bet pays off; below 95%
  surfaces what to fix in the next iteration.

### Why a workflow_dispatch instead of PR-trigger

Real Anthropic spend (~$0.20-0.50 per Haiku run; ~$2 on Sonnet; ~$5
on Opus). Not a regression gate — the e2e_smoke workflow already
gates per-PR with a separate synthetic fixture. This workflow is for
the deliberate maintainer-validation measurement and follow-up
label-revision sessions (Phase 2 lite discipline mirrors the TF-side
v0.1.63→v0.1.69 cycle).

### The run itself

Initial attempt with `--llm-backend anthropic` failed because the
local environment's `ANTHROPIC_API_KEY` was an OpenAI `sk-proj-*`
key, not Anthropic `sk-ant-api03-*`. Re-ran with `AWS_PROFILE=bedrock-test`
+ harness's default Bedrock backend (Haiku 4.5). All stages
completed successfully: init → scan (17 detector firings via
`--allow-cfn` auto-detection) → gap (60 KSI verdicts produced) →
document → poam (32 open items).

### The 4 first-pass disagreements

| KSI | rev 1 label | Agent verdict | Resolution |
|---|---|---|---|
| KSI-AFR-UCM | `implemented` | `partial` | rev 2 → `partial\|implemented` (agent's hedge defensible per Tier 1 #4.1 audit) |
| KSI-MLA-LET | `implemented` | `partial` | rev 2 → `partial\|implemented` (no formal coverage-policy attestation) |
| KSI-CNA-RNT | `evidence_layer_inapplicable` | `not_implemented` | rev 2 → `not_implemented\|evidence_layer_inapplicable` (agent is more honest — absence ≠ out-of-scope) |
| KSI-SVC-EIS | `evidence_layer_inapplicable` | `not_implemented` | rev 2 → `not_implemented\|evidence_layer_inapplicable` (same correction) |

Two typo KSI IDs (`KSI-MLA-LRP`, `KSI-SVC-EAR`) removed from rev 2
— neither exists in FRMR 0.9.43-beta; the harness auto-excluded them
from the denominator.

### Strategic implication

The Tier 5 #1 strategic arc is **validated**. Structural parity
with TF (mapping table produces detector-readable shapes); empirical
parity with TF (revision 2 hits the same 100/100 baseline). PR
gamma.2 batches 5+ (ELBv2 LB/TG, CloudFront, API Gateway, WAFv2,
etc.) are the natural next coverage-expansion work — the foundation
is validated, not speculative.

### What's next (v0.1.82)

README visual content using the v0.1.81 validation-run artifacts as
real-fixture sources: HTML gap-report screenshot + POA&M markdown
snippet inline in README. The artifacts already exist at
`evals/results/csp-starter-cfn/20260513T143530Z/workspace/.efterlev/reports/`.

## [0.1.80] — 2026-05-13

**README + LIMITATIONS CFN-support honesty pass.** The README lede,
"Why this exists", "What it does"/Scans bullet, and the
comparison-table "Reads" row all framed Efterlev as a Terraform-only
tool — stale post-v0.1.72 when CloudFormation support shipped behind
`--allow-cfn`. LIMITATIONS.md was actively wrong, claiming
"CloudFormation, AWS CDK, Pulumi... are deferred to v1.5+" when
CloudFormation YAML/JSON has shipped through 4 batches of mapping
work (v0.1.74-77) + a labeled eval fixture (v0.1.78). Honest framing
now: TF is the validated primary path; CFN is experimental opt-in
with 18 mapped resource types and ~12 detectors firing identically
to TF; the empirical maintainer-validation pass remains deferred per
the strategic-gate memory note.

### Changed

- **`README.md` lede** (line 5) — "Efterlev reads your Terraform" →
  "Efterlev reads your AWS infrastructure-as-code — Terraform `.tf`
  and `terraform show -json` plan output (the validated path), plus
  AWS CloudFormation YAML/JSON templates (experimental, opt-in via
  `--allow-cfn`)".
- **`README.md` "Why this exists"** — generalized from "reads their
  Terraform" to "reads their infrastructure-as-code — whatever
  flavor they use". Customer-problem framing is IaC-agnostic.
- **`README.md` Scans bullet** — adds CFN with concrete coverage
  numbers ("18 resource types mapped end-to-end at v0.1.80, ~12
  detectors fire on CFN inputs identically to TF").
- **`README.md` Efterlev-vs-AWS-native comparison table** — adds
  CloudFormation to the "Reads" cell.
- **`docs/index.md` "Why Efterlev"** — same generalization as
  README's "Why this exists".
- **`LIMITATIONS.md` "What Efterlev sees and doesn't see" section**
  — replaces the actively-wrong "CloudFormation... deferred to v1.5+"
  sentence with current status (experimental opt-in via
  `--allow-cfn`, 18 mapped resource types, deferred
  maintainer-validation memory-tracked). Honest scope: `cdk synth`-
  generated CFN output is supported; CDK source TypeScript/Python
  is not (different artifact). Pulumi + Kubernetes + runtime API
  scanning remain v1.5+.

### Why ship this as its own release

Customer pitches today, per maintainer time-sensitivity. The README
is the customer-facing artifact and the lede was inaccurate. Even
if CFN coverage is experimental, framing the tool as Terraform-only
when CloudFormation works for AWS-native CSPs is a forwarding-link
miss — exactly the AWS-managers audience the previous Status-trim
work targeted. Surgical edits, no functional changes.

## [0.1.79] — 2026-05-12

**Doc-quality sweep — first-impression polish.** Lifts the strongest
two sentences of the README's "Why this exists" section above the
install commands so first-screen readers see the value-prop before
the code blocks. Adds a real Troubleshooting subsection to the README
"How to run it" that lifts the recovery patterns from the
ai-quickstart-prompt (the AI-prompt path had polish; the manual path
didn't). Improves the keyless `efterlev quickstart` footer to name
the three concrete artifacts the user is missing without an
`ANTHROPIC_API_KEY` (Gap classifications, FRMR attestation drafts,
POA&M markdown) instead of the previous vague "AI-driven KSI
classification + draft attestation" wording. Fixes two stale
`efterlev --version` floor refs in `docs/ai-quickstart-prompt.md`
that the v0.1.68 documentation audit sweep missed (`0.1.11` → "the
latest published release"; the floor is now self-evergreening with
a `pip index versions efterlev` check).

### Added

- **README "Why this exists" lift** — the `$250K-consultant`
  framing is now a blockquote between the tagline and the install
  commands, so the value-prop hits in the first 8 seconds without
  scrolling. The full "Why this exists" section stays where it was;
  this is a 2-sentence preview not a relocation.
- **README "Troubleshooting" subsection** — under "How to run it".
  Documents the `terraform init -backend=false` / throwaway-tfvars /
  HCL-fallback recovery dance for real customer repos. Sources from
  `docs/ai-quickstart-prompt.md` Step 4 (which already had the
  patterns the manual-path README lacked).
- **`efterlev quickstart` keyless footer** — names the three
  concrete artifacts (KSI classifications under `.efterlev/reports/`,
  FRMR attestation drafts under `.efterlev/attestations/`, POA&M
  markdown under `.efterlev/reports/poam/`). Helps first-time users
  understand what they're missing on the keyless path so the
  upgrade path is clear.

### Changed

- **`docs/ai-quickstart-prompt.md`** — version-floor wording at both
  Step 2a + Step 2b.3 changed from `0.1.11` (six weeks stale at
  v0.1.78 ship time; the v0.1.68 doc-audit sweep missed it) to
  "matches the latest published release" with a `pip index versions
  efterlev | head -1` check command. Self-evergreening.

### Verified, NOT changed

- The path inconsistency between `.efterlev/reports/gap-<ts>.json`
  (flat) and `.efterlev/reports/poam/poam-<ts>.md` (subdir) in the
  AI prompt is **intentional** per `cli/main.py:1388-1390` ("POA&M
  outputs land under `reports/poam/` (subdirectory) so the file
  layout doesn't collide with gap reports; pre-v0.1.6 wrote flat
  `reports/poam-<ts>.md`"). Both paths in the AI prompt are correct.

### Status paragraph in README — already trimmed

Already cut from ~700 words to 4 sentences (current version + what
shipped this week + what's open + how to verify) at v0.1.78 ship
time per the same maintainer-feedback thread. CHANGELOG carries the
release-by-release narrative.

## [0.1.78] — 2026-05-12

**CFN eval-harness Phase 2 lite scaffolding + first labeled fixture
(maintainer-validation LLM-call run deferred).** Strategic pivot from
Tier 5 #1 mapping work to the validation-gate work the original
DECISIONS 2026-05-12 entry framed as "we'll know whether the strategic
bet pays off only after this number is in." Coverage 18 CFN types is
enough; this release lays the regression-instrument scaffolding in
place to actually measure CFN classification quality.

### Added

- **`evals/fixtures/csp-starter-cfn/`** — first CFN Phase 2 lite
  fixture with maintainer labels.
  - `infra/csp-starter.template.yaml` — synthetic CFN template
    covering KMS + S3 + CloudTrail + IAM + RDS + Lambda + Logs
    (~10 logical resources expanding to 14 TF-shape resources via
    sub-resource synthesis). Hand-authored 2026-05-12, NOT vendored
    — see SOURCE.md for the synthesis rationale (no public
    single-publisher canonical CFN equivalent of
    `terraform-aws-modules/*` exists, and the published AWS Quick
    Start templates are too narrow to exercise the full v0.1.73-77
    mapping table end-to-end).
  - `SOURCE.md` — synthesis rationale + per-resource detector
    expectations + intentional partial patterns documentation
    (`AuditorRole` has AdministratorAccess; `AppHandler` has env
    vars without KMS + no VpcConfig — both deliberate v0 scaffolding
    patterns).
  - `GROUND_TRUTH.yaml` — first revision (`revision: 1`) with
    conservative maintainer labels for ~25 KSIs (8 with detector
    evidence: AFR-UCM, IAM-ELP, IAM-JIT, MLA-LET, MLA-LRP, CNA-MAT,
    SVC-EAR, plus alternations; 9 AFR procedural; 4 CED; 3 INR;
    PIY-RSD; CNA-RNT/SVC-EIS as evidence_layer_inapplicable). The
    remaining ~38 KSIs left unlabeled per Phase 2 lite discipline
    ("conservative-by-default; when in doubt, leave a KSI unlabeled
    rather than guess"). Future revisions add labels as more
    detector firings get verdicts.
- **Per-detector validation**: ran 12 detectors locally against the
  fixture (`aws.encryption_s3_at_rest`, `aws.s3_public_access_block`,
  `aws.kms_key_rotation`, `aws.kms_customer_managed_keys`,
  `aws.cloudtrail_audit_logging`, `aws.cloudtrail_log_file_validation`,
  `aws.iam_admin_policy_usage`, `aws.iam_inline_policies_audit`,
  `aws.rds_encryption_at_rest`, `aws.rds_public_accessibility`,
  `aws.lambda_env_kms_encryption`, `aws.lambda_vpc_isolation`).
  11 of 12 emit Evidence as expected; the 12th (`rds_public_accessibility`)
  correctly emits 0 because the fixture has `PubliclyAccessible: false`
  (detector is configured to fire only on the unsafe `true` case).

### Deferred (memory note: come back to this)

- **The maintainer-validation LLM-call run** — the v0.1.69-equivalent
  step where the gap agent runs against the labeled fixture(s) with a
  real `ANTHROPIC_API_KEY` and we compare verdicts → maintainer labels
  for precision/recall numbers. Deferred because: GitHub Actions
  minutes at 90% of monthly cap, Anthropic spend cap had a recent
  incident (memory `project_efterlev_anthropic_spend_cap`), and the
  TF Phase 2 lite validation pass at v0.1.69 was a real spend hit
  (~$X for 67 labels across 3 fixtures with Opus-strength gap-agent
  reasoning).
- New memory entry will track this so a future session knows the
  validation gate is unfinished; the gate is what the original Tier
  5 #1 strategic-arc framing called the bet-pays-off measurement.

### Why this batch beats batch 5

Per the DECISIONS 2026-05-12 amendments 4 + 5 thread: at 18 CFN types
across 13 namespaces, every additional mapping is mechanical
local-optimization on a metric that wasn't the strategic gate.
The validation gate IS the strategic question. Shipping scaffolding
+ labels now closes the unfinished-business risk; the LLM-call run
can land in a future release without re-doing the labeling work.

### Compressed scope

This release compresses what the TF Phase 2 lite arc spread across
4 releases (v0.1.63 scaffolding + v0.1.64-66 first-pass labels +
v0.1.67 second-pass review). The pattern-knowledge from doing it
once means the CFN equivalent fits in one release.

## [0.1.77] — 2026-05-12

**Tier 5 #1 PR gamma.2 batch 4: long-tail services.** Adds 5 new
property mappings spanning the most common long-tail AWS services:
CloudTrail + SNS + SQS + DynamoDB + Secrets Manager. Coverage now
**18 CFN types** across 13 AWS namespaces.

### Added

- **`AWS::CloudTrail::Trail`** → `aws_cloudtrail`. Translates
  `EnableLogFileValidation`, `IsMultiRegionTrail`,
  `IncludeGlobalServiceEvents`, `S3BucketName`, `KMSKeyId`,
  `CloudWatchLogsLogGroupArn` etc. EventSelectors list passes through
  for the detector's presence check. Read by
  `aws.cloudtrail_audit_logging` + `aws.cloudtrail_log_file_validation`.
- **`AWS::SNS::Topic`** → `aws_sns_topic`. Read by
  `aws.sns_topic_encryption` (`kms_master_key_id`).
- **`AWS::SQS::Queue`** → `aws_sqs_queue`. Read by
  `aws.sqs_queue_encryption` (`kms_master_key_id` +
  `sqs_managed_sse_enabled`).
- **`AWS::DynamoDB::Table`** → `aws_dynamodb_table`. Translates
  `SSESpecification` and `PointInTimeRecoverySpecification` into
  list-wrapped block shapes (the v0.1.76 pattern). No detector
  currently reads DynamoDB but the type appears in customer fixtures
  + future detectors land without per-resource shipping work.
- **`AWS::SecretsManager::Secret`** → `aws_secretsmanager_secret`.
  Read by `aws.secrets_manager_rotation` (inventory of secrets-without-
  rotation; rotation-itself ships separately as
  `AWS::SecretsManager::RotationSchedule`, deferred).
- **`tests/test_cfn_property_mapping_batch4.py`** — 13 tests covering
  per-mapping translation + per-detector parity for `cloudtrail_audit_logging`,
  `cloudtrail_log_file_validation`, `sns_topic_encryption`,
  `sqs_queue_encryption`, `secrets_manager_rotation` + DynamoDB
  list-wrapped block translation tests.

### Changed

- `test_unmapped_type_raises_on_apply_mapping` now uses
  `AWS::CloudFront::Distribution` (genuinely unmapped) — DynamoDB,
  the prior placeholder, was mapped in this batch.
- `test_type_translation_unmapped`, `test_unmapped_body_shallow_snake_case_mirror`,
  and `test_parser_plus_adapter_round_trip_unmapped` switched from
  `AWS::SNS::Topic` (now mapped) to `AWS::CloudFront::Distribution`
  for the unmapped-fallback paths.
- v0.1.76 batch-3 coverage-pin test refactored to "subset present".

### Why this batch

Closes 5 high-yield long-tail services in one batch: each has
existing TF detectors that immediately benefit from CFN coverage.
Pattern catalog unchanged from v0.1.76 (per-key rename + structural
wrap + sub-resource synthesis + flat-dict-to-list-wrapped-block) —
this batch is mostly mechanical translation on top of the patterns
established by earlier batches. Coverage milestone: 18 CFN types
across 13 namespaces.

## [0.1.76] — 2026-05-12

**Tier 5 #1 PR gamma.2 batch 3: KMS + RDS + Lambda mappings.** Adds 3
new property mappings spanning the most common encryption-bearing
resource families (KMS keys + RDS databases + Lambda functions).
Coverage now 13 CFN types.

### Added

- **`AWS::KMS::Key`** → `aws_kms_key`. Includes the `KeySpec` →
  `customer_master_key_spec` rename for the legacy TF attribute name
  detectors actually read. KeyPolicy dict → `policy` JSON-string.
  Read by `aws.kms_key_rotation` (rotation flag) and
  `aws.kms_customer_managed_keys` (CMK detection).
- **`AWS::RDS::DBInstance`** → `aws_db_instance`. Read by
  `aws.rds_encryption_at_rest` (storage_encrypted + kms_key_id) and
  `aws.rds_public_accessibility` (publicly_accessible flag).
- **`AWS::Lambda::Function`** → `aws_lambda_function`. Introduces the
  flat-dict-to-list-wrapped-block translation pattern: CFN's flat
  `Environment.Variables` and `VpcConfig.{SubnetIds,SecurityGroupIds}`
  become TF's list-wrapped nested-block shape (`environment[0].variables`,
  `vpc_config[0].subnet_ids`), matching python-hcl2's `[{...}]`
  convention. Read by `aws.lambda_env_kms_encryption` and
  `aws.lambda_vpc_isolation`.
- **`tests/test_cfn_property_mapping_batch3.py`** — 11 tests covering
  per-mapping translation; `KeyPolicy` JSON-stringification; the
  list-wrapped-block translation for Lambda; per-detector parity
  (`kms_key_rotation`, `rds_encryption_at_rest`,
  `rds_public_accessibility`, `lambda_env_kms_encryption`,
  `lambda_vpc_isolation`).

### Changed

- v0.1.75 batch-2 coverage-pin test refactored to "subset present".
- `test_unmapped_type_raises_on_apply_mapping` updated to use
  `AWS::DynamoDB::Table` (genuinely unmapped at v0.1.76) since
  Lambda is now mapped.

### Why this batch

KMS, RDS, and Lambda are the three most common encryption-bearing
resource families in real AWS workloads. The Lambda mapping
introduces the third structural-translation pattern in the table:
flat-CFN → list-wrapped-TF nested blocks, joining the structural-wrap
pattern (S3 BucketEncryption) and sub-resource-synthesis (S3 PAB,
IAM Role attachments). With these three patterns demonstrated end-to-
end, the remaining batches' work is mostly per-key-rename mechanics
on top of the existing infrastructure.

## [0.1.75] — 2026-05-12

**Tier 5 #1 PR gamma.2 batch 2: IAM family mappings.** Adds 3 new
property mappings covering the most-detector-dense AWS namespace.
Introduces the 1→(1+N+M) sub-resource synthesis pattern: CFN bundles
managed-policy attachments and inline policies into the IAM principal's
own properties; TF separates them into per-attachment / per-policy
resources. The mapping synthesizes those separate resources from the
inline CFN structure, so `aws.iam_admin_policy_usage` and
`aws.iam_inline_policies_audit` (which read the separated resources)
fire on CFN inputs identically to TF.

### Added

- **`AWS::IAM::Role`** → `aws_iam_role` + N synthesized
  `aws_iam_role_policy_attachment` (one per `ManagedPolicyArns` entry,
  suffix `_attach_<idx>`) + M synthesized `aws_iam_role_policy` (one
  per inline `Policies` entry, suffix `_inline_<PolicyName>`).
  AssumeRolePolicyDocument dict → `assume_role_policy` JSON-string.
- **`AWS::IAM::ManagedPolicy`** → `aws_iam_policy` (explicit `tf_type`
  override; default would yield `aws_iam_managedpolicy`). PolicyDocument
  dict → `policy` JSON-string.
- **`AWS::IAM::User`** → `aws_iam_user` + N synthesized
  `aws_iam_user_policy_attachment` + M synthesized `aws_iam_user_policy`.
- **`tests/test_cfn_property_mapping_batch2.py`** — 11 tests covering:
  per-mapping translation; the 1→1+N synthesis (managed-policy
  attachments) + 1→1+M synthesis (inline policies) + combined
  1→(1+N+M); per-detector parity (CFN role with AdministratorAccess
  inline ManagedPolicyArns fires `aws.iam_admin_policy_usage` exactly
  like TF; CFN role with inline Policies fires
  `aws.iam_inline_policies_audit`); negative parity (read-only
  managed policy doesn't trigger admin detector); user-side parity
  (CFN user with AdministratorAccess fires admin detector via
  synthesized `aws_iam_user_policy_attachment`).

### Changed

- **`json.dumps` calls** in property_mapping.py now pass `default=str`
  so PyYAML-parsed `date` values (which appear in CFN AWS-quickstart
  templates as YYYY-MM-DD policy version strings interpreted as YAML
  dates) don't crash JSON-stringification. Caught by the integration
  test reading the vendored `aws-vpc-cfn` IAM role.
- v0.1.74 batch-1 coverage-pin test refactored to "subset present"
  (same pattern as v0.1.73's pin), so future batches don't break it.

### Why this batch

IAM is the densest detector cluster in the library (5+ detectors
referencing IAM TF resource types). The 1→(1+N+M) synthesis pattern
that batch 2 introduces is the most powerful adapter capability so
far; getting it right means all the IAM detectors that read the
separated TF resources now work on CFN inputs without per-detector
modification. Coverage now 10 CFN types.

## [0.1.74] — 2026-05-12

**Tier 5 #1 PR gamma.2 batch 1: EC2 + Logs property mappings.** Extends
the v0.1.73 property-mapping table with 4 new resource types covering
the EC2 family that the existing `aws-vpc-cfn` vendored fixture
already exercises. The closure: `parser` shipped at v0.1.72, `adapter`
type-translation at v0.1.72, property-mapping for S3+ELBv2 at v0.1.73.
At v0.1.74, parsing `aws-vpc-cfn`'s VPC + FlowLog + (etc.) and running
`aws.vpc_flow_logs_enabled` against it now emits real Evidence — not
hypothetical Evidence, an actual record from a real published AWS
quickstart template.

### Added

- **`AWS::EC2::FlowLog`** → `aws_flow_log` mapping. Dispatches CFN's
  `(ResourceType, ResourceId)` discriminator pair to one of TF's
  `vpc_id` / `subnet_id` / `eni_id` fields. Renames `TrafficType`,
  `LogDestinationType`, `LogDestination`, `LogGroupName`,
  `DeliverLogsPermissionArn`, `MaxAggregationInterval`. Read by
  `aws.vpc_flow_logs_enabled` (KSI-MLA-LET, AU-2/AU-12).
- **`AWS::EC2::SecurityGroup`** → `aws_security_group` mapping.
  Translates `SecurityGroupIngress`/`SecurityGroupEgress` lists to TF
  inline `ingress`/`egress` block-list shape. CFN scalar `CidrIp` /
  `CidrIpv6` / `SourcePrefixListId` wrap into TF list shape
  (`cidr_blocks`/`ipv6_cidr_blocks`/`prefix_list_ids`). Read by
  `aws.security_group_open_ingress` (KSI-CNA-RNT/MAT, SC-7).
- **`AWS::EC2::Volume`** → `aws_ebs_volume` mapping. Renames
  `Encrypted`/`KmsKeyId`/`Size`/`VolumeType`/`Iops`/`Throughput`/
  `AvailabilityZone`. Read by `aws.encryption_ebs` (SC-28).
- **`AWS::Logs::LogGroup`** → `aws_cloudwatch_log_group` mapping.
  Explicit `tf_type` override since default translation would yield
  `aws_logs_loggroup`. Renames `LogGroupName`/`RetentionInDays`/
  `KmsKeyId`. Read by `aws.centralized_log_aggregation` (inventory).
- **`tests/test_cfn_property_mapping_batch1.py`** — 13 tests covering:
  per-mapping translation; per-detector parity (CFN flow log fires
  `vpc_flow_logs_enabled` exactly like TF; CFN open-SSH SG fires
  `security_group_open_ingress`; CFN encrypted EBS fires
  `encryption_ebs`); HTTPS-on-SG-doesn't-fire (negative parity);
  the batch-N coverage-pin assertion.
- **`test_aws_vpc_cfn_fixture_emits_flow_log_evidence`** — the
  end-to-end integration test: parses the real vendored
  `aws-vpc-cfn/infra/aws-vpc.template.yaml` (from
  `aws-quickstart/quickstart-aws-vpc`), adapts it, runs
  `aws.vpc_flow_logs_enabled` against the adapted resources, asserts
  evidence is emitted with `target_kind=vpc`. The first real
  end-to-end CFN→TF→detector run on a real vendored template.

### Changed

- Coverage-pin test renamed from `test_mapped_cfn_types_at_v0_1_73`
  (single-batch list-equality) to `test_v0_1_73_coverage_subset_still_present`
  (subset assertion). Going forward each batch pins its own coverage
  in the batch's test file; the v0.1.73 test ensures the original 3
  remain present across batches.
- `property_mapping.py` module docstring updated to reflect the
  v0.1.74 batch + the EC2 family rationale (the immediate-fixture-
  validation argument).

### Why this batch

Strategic argument: the v0.1.73 batch validated the mapping shape
against 3 detectors. The v0.1.74 batch is the first batch where
property-mapping unlocks measurement against a *real* vendored
fixture (`aws-vpc-cfn`). Every additional EC2 mapping now means
one more detector that can be measured against that fixture for
the eventual maintainer-validation run. The strategic-arc gate
("CFN/CDK is the next major arc but only after eval-harness Phase 2
lite ships") was opened by v0.1.69's TF maintainer-validation;
v0.1.74 is the first release where the parallel CFN-fixture
labeling work has detector evidence to label *against*.

## [0.1.73] — 2026-05-12

**Tier 5 #1 PR gamma: CFN→TF property-mapping table.** v0.1.72 (PR
beta) shipped the parser + type-translation plumbing; this release
adds the property-translation layer so detectors actually see TF-shape
bodies for the three sample CFN resource types named in DECISIONS
2026-05-12. Architecture validation — bulk sweep across the remaining
~50 detectors is PR gamma.2.

### Added

- **`src/efterlev/cloudformation/property_mapping.py`** — new module.
  Per-resource-type table mapping CFN property paths to TF body keys,
  with structural transforms for the cases where CFN and TF disagree
  on nesting (notably S3 `BucketEncryption` → TF's nested
  `server_side_encryption_configuration[0].rule[0].apply_server_side_encryption_by_default[0]`
  wrapper layers). Dict-of-functions design — each entry is 10–30
  lines, readable end-to-end; alternatives considered (pure
  dict-of-dicts, pydantic schemas, per-detector dual-mode) rejected
  with documented rationale. Coverage at v0.1.73: 3 CFN types.
  - `AWS::S3::Bucket` → `aws_s3_bucket` (with structural transform
    for `BucketEncryption.ServerSideEncryptionConfiguration`)
  - `AWS::S3::Bucket` with `PublicAccessBlockConfiguration` →
    synthesizes a second `aws_s3_bucket_public_access_block` resource
    (1→N adapter expansion).
  - `AWS::S3::BucketPolicy` → `aws_s3_bucket_policy` (PolicyDocument
    dict → JSON-string for TF compatibility; explicit `tf_type`
    override since default translation `aws_s3_bucketpolicy` is broken
    by the multi-word-segment limitation).
  - `AWS::ElasticLoadBalancingV2::Listener` → `aws_lb_listener`
    (explicit `tf_type` override; `Certificates[0].CertificateArn` →
    `certificate_arn`).
- **`tests/test_cfn_property_mapping.py`** — CFN ↔ TF parity test
  suite. For each of the 3 sample detectors
  (`aws.encryption_s3_at_rest`, `aws.s3_public_access_block`,
  `aws.tls_on_lb_listeners`), constructs an equivalent CFN YAML
  fixture + TF resource list, runs the same detector against both,
  asserts the emitted Evidence content matches. 10 tests covering
  encrypted/unencrypted/fully-blocked/partial/HTTPS/HTTP/sub-resource-
  synthesis end-to-end/BucketPolicy translation/coverage-list pin/
  KeyError on unmapped types.
- **Coverage-list pin test** (`test_mapped_cfn_types_at_v0_1_73`):
  asserts `mapped_cfn_types()` is exactly the 3-tuple at this release.
  Updating it should be coordinated with DECISIONS amendment +
  CHANGELOG bump to keep the architectural pin honest.

### Changed

- **`src/efterlev/cloudformation/adapter.py`** — signature change:
  `adapt_cfn_to_terraform` now returns `list[TerraformResource]`
  instead of a single `TerraformResource`. A single CFN resource may
  yield multiple TF resources when the CFN structure folds multiple
  TF concerns together (notably `AWS::S3::Bucket`'s
  `PublicAccessBlockConfiguration`). `adapt_cfn_resources` flattens
  the per-resource expansion. Output list length may exceed input
  list length.
- Adapter now branches: registered CFN types use the property-mapping
  table (TF-shape body); unregistered types still use the v0.1.72
  shallow snake_case body mirror (fallback — detector sees the
  resource type but reads no meaningful body data).
- Adapter module docstring updated to honest scope at v0.1.73.
- `__init__.py` exports `MappedResource`, `apply_mapping`,
  `has_mapping`, `mapped_cfn_types`.

### Documentation

- **DECISIONS 2026-05-12** amended with the PR gamma follow-on entry
  (honest scope correction): option (D) per-resource-type table
  chosen over options (A) IR refactor / (B) per-detector dual-mode /
  (C) per-detector property-mapping; coverage limited to 3 types at
  v0.1.73 (architecture validation); PR gamma.2 expands to remaining
  detectors.
- README, CLAUDE.md, LIMITATIONS, docs/index.md version refs bumped.

### Rationale

The user delegated the PR gamma architectural call to the implementer
("you decide" 2026-05-12 evening). Option (D) chosen because:
centralization beats distribution (one table, not 53 detector edits);
incrementally shippable (validate against 3 types, expand later);
smaller blast radius (mapping table changes localized to one file);
doesn't inflate detector-count metric; the speculative
Pulumi/Bicep argument for option (A) IR refactor doesn't justify the
2-week refactor given how thin the speculative demand is. See
DECISIONS 2026-05-12 amendment for full reasoning.

## [0.1.72] — 2026-05-12

**Single-PR Tier 5 #1 PR β: CFN parser + adapter + scan integration
+ first vendored CFN fixture.** First code shipment of the
CloudFormation/CDK synth-mode arc per DECISIONS 2026-05-12.
Plumbing-only — per-detector property mapping is deferred to PR γ
with honest scope acknowledgment in the new modules' docstrings
and the `--allow-cfn` flag's help text.

### Added

- **`src/efterlev/cloudformation/`** — new package.
  - `parser.py`: CFN YAML/JSON loader. Custom `_CfnSafeLoader` (PyYAML
    SafeLoader subclass — does NOT pollute the global SafeLoader)
    handles all 19 CFN intrinsic-function tags (`!Ref`, `!Sub`,
    `!GetAtt`, `!Join`, `!Select`, `!FindInMap`, `!If`, `!Equals`,
    `!And`, `!Or`, `!Not`, `!Condition`, `!Base64`, `!Cidr`, `!Length`,
    `!Split`, `!Transform`, `!ForEach`, `!ToJsonString`, `!ImportValue`)
    by translating to the long-form dict shape `cdk synth` JSON
    output uses natively. Content-sniffs files via
    `AWSTemplateFormatVersion` or `Resources` top-level key; non-CFN
    YAML/JSON skipped silently per the existing scan-policy pattern.
    Partial-success collect-and-continue across many files.
  - `adapter.py`: `CfnResource` → `TerraformResource` shim. Type
    translation `AWS::S3::Bucket` → `aws_s3_bucket` (segment-lowercase
    join — clean for ~80% of common AWS resource types; multi-word
    Resource segments like `WebACL` lose word boundary, documented
    limitation, deferred to PR γ). Body has shallow snake_case
    top-level key mirror; nested keys NOT converted.
- **`src/efterlev/primitives/scan/scan_cloudformation.py`** — new
  primitive. Mirror of `scan_terraform`: parse CFN tree → adapt to
  TF shape → run the SAME `source="terraform"` detectors. No
  `source="cloudformation"` detector identity at v1; reuses TF
  detector library per DECISIONS Decision #2.
- **`efterlev scan --allow-cfn`** — CLI opt-in flag per DECISIONS
  Decision #5. Off by default; will become default-on after PR γ
  ships and 2-3 design partners validate classification quality.
  When set, scans walk YAML/JSON files alongside the existing
  Terraform walk; CFN evidence joins the scan output summary
  with a `(cfn)` tag on the per-detector evidence count.
- **`evals/fixtures/aws-vpc-cfn/`** — first vendored CFN fixture.
  `infra/aws-vpc.template.yaml` is `aws-quickstart/quickstart-aws-vpc`
  at commit `e7ab8614` (Apache 2.0). Real-shape: ~75 raw
  `AWS::EC2::*` resources across VPCs, Subnets, RouteTables,
  Routes, NACLs, NATGateways, EIPs, FlowLogs, plus Conditions,
  Mappings, Parameters. GROUND_TRUTH.yaml empty until PR γ wires
  property mapping (mirrors v0.1.63's initial-state pattern).

### Honest scope acknowledgment

The DECISIONS 2026-05-12 entry framed the adapter shim as letting
"most existing detectors work unchanged." Reality discovered while
implementing: CFN and Terraform property structures diverge enough
per-resource (e.g. CFN `Properties.BucketEncryption.ServerSideEncryptionConfiguration`
vs TF top-level `server_side_encryption_configuration`) that
uniform translation isn't tractable at the adapter layer. v0.1.72
ships type-translation only; per-detector property-mapping is the
PR γ work. Detectors at v0.1.72 SEE CFN-adapted resources via
`r.type` matching (validated against the 75-resource real-shape
fixture: parser succeeds, adapter produces 75 TF-shape records)
but read empty / shallow body data. The plumbing is honest and
verifiable; the DECISIONS entry will be amended in a follow-on
once PR γ's IR-vs-N-detectors call lands with full information.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 → 1554 (+26 — 22 new in
  `tests/test_cloudformation_parser.py` + `test_cloudformation_adapter.py`,
  plus 4 from `test_eval_fixtures_parse.py` parametrization expanding
  to cover the new aws-vpc-cfn fixture and the CFN-vs-Terraform split).
- Source files: 222 → 226 (4 new under `src/efterlev/cloudformation/`
  + `src/efterlev/primitives/scan/scan_cloudformation.py`).
- CLI commands: 31 unchanged (`--allow-cfn` is a flag, not a command).
- Eval fixtures: 8 → 9 (5 synthetic + 3 Terraform real-shape + 1 CFN
  real-shape).

## [0.1.71] — 2026-05-12

**Single-PR README tagline rephrase.** Per maintainer feedback,
the lead tagline reframes from "Compliance scanning for SaaS
teams pursuing FedRAMP 20x — that lives in your repo, not a SaaS
dashboard." to "Open source. Runs locally. Compliance evidence
lives in your repo alongside the code it describes." The new
tagline leads with the open-source + local positioning that
distinguishes Efterlev from the SaaS GRC competitive landscape;
the FedRAMP 20x framework specificity moves to the body sentence
where it's still surfaced.

### Changed

- `README.md` lead tagline + body sentence.

### Internal (count deltas)

- All counts unchanged (README copy edit only).

## [0.1.70] — 2026-05-12

**Single-PR docs-only release: CFN/CDK synth-mode DECISIONS entry
+ docs/index.md feature-list refresh.** Two doc-only deliverables
bundled into one release. Strategic-arc next step (CFN synth-mode
design) is now locked in DECISIONS.md per the established
DECISIONS-entry-then-PR convention; the docs-site status bullet
that had stopped at v0.1.59 features is now caught up to v0.1.69
state.

### Added

- **DECISIONS.md "2026-05-12 — Tier 5 #1 design: CloudFormation/CDK
  synth-mode support"** — locks the architectural shape of the
  CFN/CDK support work + the 3-PR rollout sequence (α this release;
  β = parser + adapter + 3 sample detector adaptations + 1 CFN
  fixture; γ = bulk detector sweep + scan integration + design-
  partner outreach). Decisions: (1) v1 scope = scan CFN JSON
  whether hand-authored or `cdk synth`-generated, (2) thin adapter
  shim over IaC-agnostic IR refactor for v1, (3) auto-detect input
  by extension + `Resources` content sniff, (4) source-level
  citation = file-level only at v1 (matches plan-JSON mode),
  (5) behind `--allow-cfn` flag at v0 then default-on after
  partner validation, (6) design-partner recruitment kicks off
  WITH PR β shipping (not as a blocker), (7) 3-PR α/β/γ sequence.

### Changed

- **`docs/index.md`** status bullet refreshed: feature list had
  stopped at v0.1.59 work (was missing the v0.1.60-v0.1.69 SHA-
  pinning, `[dev]`-extra security tools, Phase 2 lite eval harness
  + 67 validated labels, CFN-design lock). Now lists everything
  shipped through v0.1.70.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

This release is doc-only; no source/test/CI code touched.

## [0.1.69] — 2026-05-12

**Single-PR Phase 2 lite maintainer validation pass: 67/67 labels
validated, 100% precision + 100% recall, 0 overrides.** The "what
the maintainer review pass should do" follow-on documented in
`evals/PHASE_2_LITE_LABEL_REVIEW.md` (v0.1.67) has now been
executed end-to-end with the v0.1.69 release. The strategic-arc
gate to start CFN synth-mode design (per the 2026-05-11 strategic-
arc memory) is now genuinely open: Phase 2 lite is operational as
a regression instrument.

### Added

- `evals/PHASE_2_LITE_MAINTAINER_VALIDATION.md` — side-by-side
  validation doc. Per-fixture, per-KSI: drafted label, agent
  verdict, alternation resolution, match indicator. Plus an
  aggregate table, "what this validation does NOT prove"
  honesty section, and "suggested next steps" outlining the
  Phase 3 promotion path + new-fixture vendoring options + CFN
  DECISIONS-entry kickoff.

### Validation results

Ran `python -m evals run --fixture <fixture-id> --llm-backend
anthropic --llm-model claude-haiku-4-5` against each Phase 2 lite
fixture, captured the agent's per-KSI verdicts from the gap
report, and compared to the post-v0.1.67 labels:

| Fixture | Labels | Precision | Recall |
|---|---|---|---|
| aws-vpc-tfm | 21 | 100% | 100% |
| aws-s3-bucket-tfm | 25 | 100% | 100% |
| aws-lambda-tfm | 21 | 100% | 100% |

**Zero label overrides needed.** All v0.1.67 second-pass revisions
were correct — particularly the Lambda-fixture tightenings
(KSI-CNA-MAT `not_implemented|partial` → `not_implemented`,
KSI-MLA-LET `not_implemented|partial` → `partial`) that nailed the
agent's exact verdict on the trickiest cases.

POAM scope discipline (M5) also scored 100% on every fixture.

### Strategic-arc state

Updated `project_efterlev_strategic_arc_2026-05.md` (memory): the
"awaits maintainer validation" gating is **resolved**. Phase 2
lite is operational as the regression instrument the CFN/CDK
expansion was structurally gated on. CFN synth-mode design can
proceed (still wants a DECISIONS entry first per the original
strategic-arc framing).

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Phase 2 lite labels: 67 (validated; 0 overrides).

## [0.1.68] — 2026-05-12

**Single-PR documentation audit: stale-claim sweep across the
docs.** During v0.1.55-v0.1.67's rapid release cadence (13 releases
on 2026-05-11 alone), several long-form docs accumulated count
references and capability claims that fell out of sync with the
current state. This pass swept them.

### Changed

- **`docs/quickstart.md`**: "we ship 45 detectors" → "we ship 66
  detectors" (in the troubleshooting block).
- **`docs/ai-quickstart-prompt.md`**: GitHub-workflow detector
  count "4 detectors" → "5 detectors".
- **`LIMITATIONS.md`**: "It does not cover the full FedRAMP 20x
  Moderate KSI set via detectors alone" section rewritten:
  "At v0.1.17, **45 detectors ship** (38 KSI-mapped + 7
  supplementary 800-53-only), covering 31 of 60 KSIs across 8 of
  11 themes" → "At v0.1.67, **66 detectors ship** (62 KSI-mapped
  + 4 supplementary 800-53-only), covering 37 of 60 KSIs across
  10 of 11 themes." Plus the trailing sentence about manifest
  starter pack being "v0.1.18+ work" rewritten to credit the
  v0.1.21 ship + v0.1.36 expansion (both already shipped).
- **`docs/aws-coexistence.md`**:
  - Detector breakdown updated: "Of Efterlev's 38 KSI-mapped
    detectors, 34 read AWS-resource-shaped Terraform; 4 read
    .github/workflows/" → "Of Efterlev's 62 KSI-mapped detectors,
    56 read AWS-resource-shaped Terraform; 5 read
    .github/workflows/; 1 reads `github_branch_protection`
    Terraform" (the v0.1.55 first-of-kind).
  - KSI coverage: "31 of 60 thematic KSIs" → "37 of 60 thematic
    KSIs" (in three places).
  - Threshold-vs-coverage math: "Union ≈ 30 + 14 − 11 = ~33 of
    63 KSIs (~52%)" → "Union ≈ 37 + 14 − 11 = ~40 of 60 KSIs
    (~67%)" (closes the gap to FedRAMP 20x Phase 2's 70%
    automated-validation threshold).
- **`docs/v0.2-eval-harness-plan.md`**: "Phase 2 (during v0.2.x):
  add 2-3 sanitized real fixtures as customer relationships
  permit. Solicit ground-truth labeling help" → annotated with
  "Shipped as 'Phase 2 lite' v0.1.63-v0.1.67" + the 3 vendored
  real-shape fixtures + 67 conservative claude-drafted labels.
  Phase 1 + Phase 3 lines also annotated to reflect current state.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged (no source/test code touched).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.67] — 2026-05-12

**Single-PR Phase 2 lite second pass: label review + 6 revisions
across the three real-shape fixtures.** v0.1.64-v0.1.66 shipped 67
conservative claude-drafted labels authored by reading scan output
directly (no LLM agent verdict consulted). v0.1.67 is the second-
look review against the canonical FRMR statements: each label
re-examined, 6 revised (3 tightenings + 3 loosenings), 61 confirmed
unchanged.

### Added

- `evals/PHASE_2_LITE_LABEL_REVIEW.md` — consolidated review doc.
  Per-fixture, per-KSI section with FRMR statement, evidence
  summary, drafted label, second-pass reasoning, confidence, and
  decision (confirm/revise/flag). Plus a revisions table and a
  "what the maintainer review pass should do" section that walks
  through the API-key-required follow-on.

### Changed

- `evals/fixtures/aws-vpc-tfm/GROUND_TRUTH.yaml` (revision 2 → 3):
  - **KSI-CNA-MAT** `partial` → `partial|not_implemented` (loosen
    — the missing-explicit-deny gap could honestly be weighted to
    not_implemented; alternation now matches how CNA-MAT is
    handled in fixture #2)
  - **KSI-CNA-RNT** `partial` → `partial|not_implemented` (same)
- `evals/fixtures/aws-s3-bucket-tfm/GROUND_TRUTH.yaml` (revision 1 → 2):
  - **KSI-AFR-UCM** `partial|not_implemented` → `partial` (tighten
    — the split-resource SSE pattern IS the post-2022 AWS best
    practice; calling it `not_implemented` would miss real
    encryption infrastructure)
  - **KSI-SVC-RUD** `not_implemented` → `not_implemented|partial`
    (loosen — lifecycle resource exists, just empty; agent could
    honestly call either)
- `evals/fixtures/aws-lambda-tfm/GROUND_TRUTH.yaml` (revision 1 → 2):
  - **KSI-CNA-MAT** `not_implemented|partial` → `not_implemented`
    (tighten — Lambda-no-vpc_config is unambiguously default-VPC
    internet-facing; the partial alternation was reading-into-the-
    future)
  - **KSI-MLA-LET** `not_implemented|partial` → `partial` (tighten
    — the fixture HAS 2 `aws_cloudwatch_log_group` resources, so
    logging IS configured; `not_implemented` would be wrong)

Phase 2 lite labeled-KSI count unchanged at 67 across 3 fixtures
(this release adjusts label content, not count).

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged (no test changes; `test_eval_fixtures_parse`
  parametrization still covers all 8 fixtures).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 8 unchanged.
- Phase 2 lite labels: 67 (revisions: 6/67 = 9%).

## [0.1.66] — 2026-05-11

**Single-PR Phase 2 lite expansion: third real-shape fixture
(`aws-lambda-tfm`) + 21 conservative draft labels.** Rounds out
the initial three-fixture corpus covering the most-common AWS
workload patterns:
- `aws-vpc-tfm` (v0.1.63) — network/segmentation
- `aws-s3-bucket-tfm` (v0.1.65) — storage/encryption
- `aws-lambda-tfm` (v0.1.66) — serverless compute

### Added

- `evals/fixtures/aws-lambda-tfm/` — third Phase 2 lite fixture.
  `infra/` vendored verbatim from
  [`terraform-aws-modules/terraform-aws-lambda`](https://github.com/terraform-aws-modules/terraform-aws-lambda)
  v8.8.0 (commit `b8423741`). Apache 2.0 license preserved
  under `infra/LICENSE`; vendoring provenance + update procedure
  under `SOURCE.md`. ~15 raw `aws_lambda_*` + `aws_cloudwatch_*`
  resource types + null_resource layer mechanics.
- 21 conservative draft labels in
  `evals/fixtures/aws-lambda-tfm/GROUND_TRUTH.yaml`:
  - 4 KSIs WITH detector evidence: KSI-CNA-MAT (Lambda
    `internet_facing` — no vpc_config), KSI-MLA-LET (logging
    `unverifiable` — function_name var-driven), KSI-MLA-OSM
    (`producers_only` — log groups exist but no centralization
    primitive), KSI-PIY-GIV (terraform_inventory tracked).
  - 17 procedural-only KSIs (same set as the prior two
    fixtures; AFR-UCM left unlabeled because no encryption
    resources to evidence cryptographic-module use).

  Phase 2 lite labeled-KSI count: 46 → 67 (across 3 fixtures).
  (PR #264)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1526 → 1528 (+2 — `test_eval_fixtures_parse`
  parametrization now covers 8 fixtures).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 7 → 8 (5 synthetic + 3 real-shape).

## [0.1.65] — 2026-05-11

**Single-PR Phase 2 lite expansion: second real-shape fixture
(`aws-s3-bucket-tfm`) + 25 conservative draft labels.** Companion
to v0.1.63's `aws-vpc-tfm`. Where VPC exercises the
network/segmentation detector dimensions, this exercises the
**storage + encryption** dimensions — same vendor (terraform-aws-
modules), same labeling discipline (claude-drafted from scan
output, no LLM agent verdict consulted, awaits maintainer review).

### Added

- `evals/fixtures/aws-s3-bucket-tfm/` — second Phase 2 lite
  fixture. `infra/` vendored verbatim from
  [`terraform-aws-modules/terraform-aws-s3-bucket`](https://github.com/terraform-aws-modules/terraform-aws-s3-bucket)
  v5.13.0 (commit `af0286ff`). Apache 2.0 license preserved
  under `infra/LICENSE`; vendoring provenance + update procedure
  under `SOURCE.md`. ~20 raw `aws_s3_*` resource types focused on
  bucket lifecycle: encryption, public-access-block, ACL,
  lifecycle, replication, ownership controls, versioning, logging,
  object lock, intelligent tiering, inventory.
- 25 conservative draft labels in
  `evals/fixtures/aws-s3-bucket-tfm/GROUND_TRUTH.yaml`:
  - 8 KSIs WITH detector evidence: KSI-AFR-UCM (split-resource
    encryption pattern), KSI-CNA-MAT/RNT (`s3_bucket_public_acl`
    unparseable from jsonencode), KSI-CNA-OFA (replication
    configured), KSI-IAM-AAM (13 policy documents tracked),
    KSI-PIY-GIV (terraform_inventory tracked), KSI-RPL-ABO
    (versioning unresolvable), KSI-SVC-RUD (lifecycle is a
    placeholder, 0 enabled rules → `not_implemented`).
  - 17 procedural-only KSIs (same set as `aws-vpc-tfm`):
    9 AFR-* (excl AFR-UCM), 4 CED-*, 3 INR-*, plus PIY-RSD.
  Phase 2 lite labeled-KSI count: 21 → 46 (across both
  fixtures). (PR #263)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1524 → 1526 (+2 — 1 new `test_fixture_terraform_parses
  [aws-s3-bucket-tfm]` + 1 new `test_fixture_ground_truth_yaml_
  well_formed[aws-s3-bucket-tfm]`).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 6 → 7 (5 synthetic + 2 real-shape).

## [0.1.64] — 2026-05-11

**Single-PR Phase 2 lite first-pass: harness scan-fix +
aws-vpc-tfm draft labels (claude-drafted, awaits maintainer
review).** v0.1.63 shipped the scaffolding; v0.1.64 turns the
empty `expected_classifications: {}` into a working baseline of
21 conservative evidence-based labels, plus a v0.1.59 follow-on
bug fix the v0.1.63 invocation surfaced.

### Fixed

- `evals/harness.py` now passes `--allow-subdir-target` on its
  internal `efterlev scan` invocation. v0.1.59 hard-errored on
  scans below a `.github/workflows/` ancestor; the eval-harness
  workspaces live at `evals/results/<fixture>/<ts>/workspace/`,
  which is exactly that pattern. v0.1.59's CI-compat sweep got
  `e2e_smoke.py` + `release-smoke.yml` but missed this; the
  harness was unable to run end-to-end on any fixture between
  v0.1.59 and this release.

### Added

- `evals/fixtures/aws-vpc-tfm/GROUND_TRUTH.yaml`:
  `expected_classifications` filled in with 21 conservative
  draft labels authored by reading the deterministic
  `efterlev scan` output (NO LLM agent verdict consulted —
  avoids the confirmation-bias risk of "label whatever the
  agent said as honest"):
  - 4 KSIs WITH detector evidence: KSI-CNA-MAT, KSI-CNA-RNT
    (`partial`; 7 NACLs `partially_restrictive`), KSI-CNA-ULN
    (`partial|not_implemented`; var-driven cidr blocked subnet
    linkage), KSI-PIY-GIV (`partial`; aws.terraform_inventory
    `tracked`).
  - 17 procedural-only KSIs: 9 AFR-* (excl AFR-UCM), 4 CED-*,
    3 INR-*, plus KSI-PIY-RSD (workflow surface skipped via
    --allow-subdir-target). All `evidence_layer_inapplicable
    |not_applicable` per Phase 1 alternation discipline.
  Labels marked `# claude-drafted, awaits maintainer review`
  for spot-check + override during evening grading sessions.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1524 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval-harness Phase 2 lite labeled-KSI count: 0 → 21
  (12 procedural-only `evidence_layer_inapplicable|...` +
  4 `partial` from detector evidence + 4 alternations).

## [0.1.63] — 2026-05-11

**Single-PR strategic-arc kickoff: eval-harness Phase 2 lite
scaffolding — first real-shape fixture vendored.** Per the
2026-05-11 strategic-arc decision (memory:
`project_efterlev_strategic_arc_2026-05.md`), Phase 2 lite was
the gating prerequisite before CFN/CDK market-expansion work.
The user's chosen fixture-sourcing path: public open-source
Terraform corpora (vs design-partner real-customer boundaries),
hand-graded by the maintainer in evening sessions.

The 5 Phase 1 in-repo eval fixtures (`govnotes-v1`,
`encryption-mixed`, `iam-dynamic-policy`, `runtime-monitoring`,
`serverless-mixed`) all hit 1.000 / 0.000 on the agent-quality
metrics — textbook overfit risk because the prompts were tuned
against them. Real-shape fixtures from third-party Terraform are
the regression instrument that catches that overfit.

### Added

- `evals/fixtures/aws-vpc-tfm/` — first Phase 2 lite fixture.
  `infra/` is verbatim vendored from
  [`terraform-aws-modules/terraform-aws-vpc`](https://github.com/terraform-aws-modules/terraform-aws-vpc)
  v6.6.1 (commit `3ffbd46f`); the most-downloaded VPC module in
  the Terraform Registry. Apache 2.0 license preserved under
  `infra/LICENSE`; vendoring provenance + update procedure under
  `SOURCE.md`; labeling-review workflow documented in
  `GROUND_TRUTH.yaml` (which ships with empty
  `expected_classifications` per the Phase 1 "skip unlabeled"
  discipline — labels accumulate over evening grading sessions).
- `tests/test_eval_fixtures_parse.py` — smoke test parametrized
  over every `evals/fixtures/<id>/`. Confirms `infra/` parses
  cleanly via efterlev's HCL parser AND that `GROUND_TRUTH.yaml`
  carries the required scaffolding fields. No LLM cost — guards
  against a vendored-upstream re-vendor breaking the fixture
  shape at PR time. (PR #261)

### Changed

- `evals/README.md` — header bumped to "Phase 1 + Phase 2 lite".
  New "Phase 2 lite — labeling real-shape vendored fixtures"
  section walks the 4-step workflow (run snapshot → review
  verdicts → fill in `GROUND_TRUTH.yaml` → re-run with metrics).

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 → 1524 (+12 — `tests/test_eval_fixtures_parse.py`
  parametrizes over 6 fixtures × 2 contracts = 12 new test cases).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 5 → 6 (`aws-vpc-tfm` is the first real-shape).

### Pending (user follow-up)

- Run `python -m evals run --fixture evals/fixtures/aws-vpc-tfm`
  once to capture the first snapshot. Then walk the per-KSI
  verdicts in evening sessions and accumulate labels in
  `GROUND_TRUTH.yaml`. Once ~15 KSIs are labeled, M1 + M2 against
  this fixture become a real regression-detection signal.

## [0.1.62] — 2026-05-11

**Single-PR closure: `pypa/gh-action-pypi-publish` SHA-pinned to
v1.14.0.** Closes the v0.1.60 SHA-pinning gap — that release left
`pypa/gh-action-pypi-publish@release/v1` (a moving branch ref
documented as the canonical install) on a tag-pin, deferred for a
follow-on. v0.1.62 lands the follow-on: pin to the latest stable
release tag's SHA so all third-party Action references across all
workflows are now SHA-pinned with no exceptions.

### Changed

- `.github/workflows/release-pypi.yml`: both
  `uses: pypa/gh-action-pypi-publish@release/v1` (test-pypi publish
  + real-pypi publish) rewritten to
  `uses: pypa/gh-action-pypi-publish@cef221092ed1bacb1cc03d23a2d87d1d172e277b # v1.14.0`.
  Dependabot's wildcard github-actions group (v0.1.60) will pick up
  future v1.x releases automatically. (PR #260)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.61] — 2026-05-11

**Single-PR supply-chain reproducibility fix: `pip-audit` + `bandit`
baked into the `[dev]` extra.** Closes `docs/security-review-2026-04.md`
§7 + the "Bake security tools into [dev] extra" followup held since
the v0.1.0 launch security review. CI was using `uv run --with
pip-audit` (pip-audit) and `pip install --upgrade 'bandit[toml]
>=1.7,<2'` (bandit), both of which fetch whatever PyPI happens to
have on every CI run — defeats reproducibility AND means a Bandit
release with a regression could turn green PRs red overnight without
any code change here.

### Changed

- `pyproject.toml`: `pip-audit>=2.7,<3` and `bandit[toml]>=1.7,<2`
  added to `[project.optional-dependencies].dev`. Both tools now
  pin into `uv.lock` and update via Dependabot's grouped Python PRs.
- `.github/workflows/ci-security.yml`: pip-audit job switched from
  `uv run --with pip-audit pip-audit ...` to `uv run pip-audit ...`
  (lockfile-pinned). Bandit job switched from `actions/setup-python`
  + `pip install --upgrade ...` to `astral-sh/setup-uv` + `uv sync
  --extra dev` + `uv run bandit ...` (same lockfile). Local-dev
  parity with CI is the bonus. (PR #258)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 unchanged (no Python source touched).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.60] — 2026-05-11

**Single-PR supply-chain hardening: third-party GitHub Actions
SHA-pinned across all workflows + Dependabot grouping wildcarded.**
Closes the `docs/security-review-2026-04.md` §5 + §7 expectation
held in `docs/followups.md` since the v0.1.0 launch security
review. OpenSSF Scorecard / SLSA L3 expects every external Action
reference to be pinned to an immutable commit SHA rather than a
movable tag — protects against a compromised maintainer force-
moving a tag to inject malicious code into our build pipeline.

### Changed

- `.github/workflows/*.yml`: every `uses: <org>/<repo>@<tag>` for a
  third-party Action rewritten to `uses: <org>/<repo>@<full-sha> #
  <tag>` (tag preserved as comment for human readability and for
  Dependabot's version-bump detection). Pinned: `astral-sh/setup-uv`,
  `sigstore/cosign-installer`, `anchore/sbom-action`,
  `returntocorp/semgrep-action`, `docker/setup-qemu-action`,
  `docker/setup-buildx-action`, `docker/login-action`,
  `docker/build-push-action`. Skipped: `pypa/gh-action-pypi-publish
  @release/v1` (moving branch ref documented as the canonical
  install — different pinning strategy needed; deferred to a future
  PR). First-party `actions/*` and `github/*` left tag-pinned per
  common GitHub convention.
- `.github/dependabot.yml`: github-actions group rewritten from
  `update-types: [minor, patch]` to `patterns: ["*"]`. With SHA
  pins, every Dependabot detection (whether semver-major / minor /
  patch / re-tag-of-same-version-to-new-SHA) emits a separate PR by
  default — would generate ~10 PRs per weekly cycle even when only
  one Action moved. Wildcard collapses that into a review-friendly
  single grouped PR per cycle. (PR #257)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 unchanged (CI-only change; no Python source touched).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.59] — 2026-05-11

**First-run UX fix: `efterlev scan` hard-errors when `--target` sits
below a `.github/workflows/` ancestor.** Bridge release before the
next strategic arc (DECISIONS 2026-05-11 "Strategic arc post-v0.1.58
— quality scaffolding before market expansion"). Closes a
documented funnel-killer: a first-run user pointing `--target` at
`infra/terraform/` (the dominant real-customer layout) used to get
a `20 evidence records` success line and conclude the tool covered
their repo, when actually github-source detectors had silently
contributed zero. The pre-v0.1.59 post-scan warning was easy to
miss in CI logs.

### Changed

- `efterlev scan` now refuses to run by default when `--target`
  resolves to a directory below a `.github/workflows/` ancestor.
  Exit code 2 with a two-paths error message: (1) re-run from the
  detected repo root, or (2) pass the new `--allow-subdir-target`
  flag to acknowledge the trade-off and proceed with Terraform-only
  scope (the legitimate monorepo-with-multiple-Terraform-roots
  case). The post-scan warning still fires when
  `--allow-subdir-target` is passed, so the under-coverage is
  visible in the output. (PR #255)

### Fixed (CI compatibility)

- `scripts/e2e_smoke.py` and `.github/workflows/release-smoke.yml`
  pass `--allow-subdir-target` to acknowledge their deliberately-
  Terraform-only scope (e2e workspace at `.e2e-results/<ts>/`,
  smoke fixture at `tests/smoke/`). Both sit below the repo's
  `.github/workflows/` and would otherwise hard-error.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1511 → 1512 (+1 — replaced the
  `test_scan_warns_when_target_sits_below_*` test with
  `test_scan_hard_errors_*` + a new
  `test_scan_proceeds_with_warning_when_allow_subdir_target_passed`).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.58] — 2026-05-11

**Single-PR feature: `efterlev manifests validate <path>` — offline
schema validation for Evidence Manifests.** Pre-commit / pre-PR
gate that catches the high-leverage authoring mistakes a contributor
makes while drafting a manifest: typo'd field names (`extra="forbid"`
rejects them — the canonical `attester:` vs `attested_by:` swallowed-
typo), malformed dates, missing required fields, top-level not-a-mapping.
Pure schema check; no FRMR / baseline load required.

Fourth small focused single-PR feature in the post-Tier-4 cadence
(after v0.1.53 detectors-new + v0.1.54 boundary --interactive +
v0.1.56 detectors-show).

### Added

- `efterlev manifests validate <path>` CLI command. Path argument
  accepts a single file OR a directory (walked via the same glob as
  scan-time manifest discovery: `*.yml` + `*.yaml`, with
  `*.template.yml` skipped to match loader behavior). Per-file ✓
  or ✗ output with the pydantic validation error inline; summary
  line shows valid/total. Exit codes: 0 if every manifest validates,
  1 if any fail, 2 if the path doesn't exist or no manifests
  discoverable in a directory. Does NOT cross-check `ksi:` against
  the FRMR baseline — that's the scan-time check; offline validate
  is the schema gate. (PR #254)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1500 → 1511 (+11 — `tests/test_manifests_validate.py`).
- Source files: 222 unchanged (the new command is a function inside
  `cli/main.py`).
- CLI commands: 30 → 31.

## [0.1.57] — 2026-05-11

**Single-PR supply-chain feature: wheel + sdist SBOMs attached to
GitHub Releases.** The container image already carries an embedded
SBOM via `buildx sbom: true`; this closes the parallel gap on the
PyPI artifacts. Held in `docs/followups.md` "v0.1.x patch follow-
ups" since the v0.1.0 launch security review.

### Added

- `release-pypi.yml` runs `anchore/sbom-action@v0` after
  `publish-pypi` to generate CycloneDX SBOMs for both the wheel
  and sdist, and attaches them to the GitHub Release as
  `efterlev-<VERSION>-wheel-sbom.cdx.json` +
  `efterlev-<VERSION>-sdist-sbom.cdx.json`. The job creates the
  Release if `post-release-triage.yml` hasn't yet (race-tolerant);
  triage's `gh release edit --notes-file` path correctly handles
  the "Release exists, replace notes" case. Final tags only — rc
  tags don't get a public Release page. (PR #253)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1500 unchanged (CI-only change; no Python source touched).
- Source files: 222 unchanged.
- CLI commands: 30 unchanged.

## [0.1.56] — 2026-05-11

**Single-PR feature: `efterlev detectors show <id>` — read/inspect
counterpart that completes the detectors-CLI symmetry.** Third
verb after `detectors list` (registry summary, existing) and
`detectors new` (write/scaffold, v0.1.53). Surfaces what
`detectors list` elides: mapping.yaml KSI/control coverage notes,
evidence.yaml shape (per-record `content` keys), README lead
paragraph, and fixture file counts.

Useful for contributors choosing what to extend (read the existing
detector's notes to see if a new gap fits the same KSI), and for
operators trying to understand what a scanned-evidence record
means without opening the source tree.

### Added

- `efterlev detectors show <detector_id>` CLI command. Each
  section degrades gracefully: missing `mapping.yaml` /
  `evidence.yaml` / `README.md` / `fixtures/` skips that section
  rather than erroring. Detectors registered from outside the
  source tree (e.g. third-party packages) print only the
  registry-level header. Unknown id exits 1 with helpful
  suggestions: substring overlaps first, then cloud-prefix
  fallback, then a pointer at `detectors list`. (PR #251)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1490 → 1500 (+10 — `tests/test_detectors_show.py`).
- Source files: 222 unchanged (the new command is a function
  inside `cli/main.py`).
- CLI commands: 29 → 30.

## [0.1.55] — 2026-05-11

**Single-PR detector: `github.branch_protection` (KSI-PIY-RSD; SA-15
+ CM-2).** First detector under `detectors/github/` that reads
Terraform source rather than `.github/workflows/*.yml`. Joins
`github.piy_sdlc_security_gates` on the same KSI: workflow gates
run on PRs; branch protection enforces that PRs require those
gates to pass before merge. Together they cover the configured-
gate half of KSI-PIY-RSD's `partial` classification at both the
workflow layer and the merge-enforcement layer.

Two binary states: `protections_present` (any of
`required_status_checks` / `required_pull_request_reviews` /
`enforce_admins=true`) and `protections_absent` — the canonical
"branch protection rule declared but enforces nothing" gap where
the GitHub API accepts the resource and the boundary owner can
point at it during audit, but no actual merge-time gate is in
place.

### Added

- `github.branch_protection` detector. Walks `github_branch_protection`
  Terraform resources and emits one Evidence record per resource
  describing whether the rule actually enforces a meaningful merge-
  time gate. Coverage `partial` — presence of the blocks doesn't
  prove the values are appropriate (`required_approving_review_count=0`
  is meaningless; an empty `contexts` list is meaningless). The
  Gap Agent reasons about specific values from the `detail` field.
  (PR #249)

### Diagnostics

- `friendly_errors` for Anthropic HTTP 400 now includes the API
  response body in the hint (was hidden behind a canned "this is
  usually a code-level bug" message), and pattern-matches the
  account-level monthly-spend-cap body (`"API usage limit"` /
  `"regain access"`) to a quota classification with cap-bump and
  Bedrock-backend remediation hints. Forced surface during
  PR #249 e2e debugging when efterlev's `ANTHROPIC_API_KEY` hit
  its monthly cap and Anthropic returned 400 (not 429), making
  the failure look like a code regression for ~30 minutes before
  the diagnostic landed. (PR #249)

### Internal (count deltas)

- Detector count: 65 → 66 (`github.branch_protection`).
- KSI-mapped detectors: 61 → 62.
- Detector sources: 56 → 57 Terraform (KSI-mapped); GitHub-workflows
  count unchanged at 5; supplementary unchanged at 4.
- Tests: 1483 → 1490 (+7 — `tests/detectors/test_github_branch_protection.py`).
- Source files: 220 → 222 (the new detector folder adds
  `__init__.py` + `detector.py`).

## [0.1.54] — 2026-05-11

**Single-PR feature: `efterlev boundary set --interactive` —
contributor / first-time-user friction reducer for boundary glob
entry.** Held in `LIMITATIONS.md` "Future ideas" since v0.1.18+;
second small focused single-PR feature after v0.1.53's
detectors-new scaffolder. Walks the user through include +
exclude glob entry instead of requiring them to remember the
`--include`/`--exclude` flag syntax.

### Added

- `--interactive` / `-i` flag on `efterlev boundary set`. When
  passed, prompts repeatedly for include + exclude globs (empty
  input ends each section), shows a preview, and asks for
  confirmation before writing `[boundary]` to
  `.efterlev/config.toml`. Mutually exclusive with
  `--include`/`--exclude` (clear error + exit 2 if combined).
  Bail-fast: if no globs entered, returns early without
  prompting for confirmation, and the caller refuses with "no
  globs supplied" + exit 2 (avoids wiping existing config).
  The non-interactive `--include`/`--exclude` path is unchanged.
  (PR #247)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1477 → 1483 (+6 — `tests/test_boundary_set_interactive.py`).
- Source files: 220 unchanged (the helper is a function inside
  `cli/main.py`).
- CLI commands: 29 unchanged (extending existing `boundary set`).

### Cross-references

- `LIMITATIONS.md` "Future ideas" — "Boundary-scoping interactive
  helper" deferral, removed in this release since it shipped.
- v0.1.53 release (PR #246) — the prior single-PR-feature release
  (detectors-new scaffolder).

## [0.1.53] — 2026-05-11

**Single-PR feature: `efterlev detectors new <id>` — contributor
scaffolder for the 5-file detector folder convention.** Held in
`LIMITATIONS.md` "Future ideas" since the v0.1.18+ planning surface;
ships as a small focused OSS-friction reducer after the multi-batch
ConMon Lite arc closed.

### Added

- New CLI command `efterlev detectors new <detector_id>` —
  generates the canonical 5-file detector folder skeleton plus
  fixture directories. Argument: `<cloud>.<snake_case_name>`
  (e.g. `aws.foo_bar`). Cloud must be one of `aws / github / gcp
  / azure`; name must be snake_case starting with a letter.
  Options: `--ksi KSI-X` (repeatable; default empty →
  supplementary 800-53-only detector), `--control X-NN[(N)]`
  (repeatable), `--source terraform | terraform-plan | github`
  (default `terraform`). Refuses to overwrite an existing folder.
  The generated `detector.py` is a registration-ready stub with
  the `@detector` decorator + an empty `detect()` function. The
  generated `mapping.yaml`, `evidence.yaml`, and `README.md`
  include TODO placeholders keyed off the requested KSIs +
  controls. The scaffolder writes into the `efterlev` package's
  source tree (located via `efterlev.detectors.__file__`), so it
  works from a checkout (the typical contributor workflow) AND
  from a site-packages install. (PR #245)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1468 → 1477 (+9 — `tests/test_detectors_new_scaffolder.py`).
- Source files: 220 unchanged (the scaffolder lives in `cli/main.py`).
- CLI commands: 28 → 29 (+1 — `efterlev detectors new`).

### Cross-references

- `LIMITATIONS.md` "Future ideas" — "Detector contribution
  scaffolder" deferral, removed in this release since it shipped.
- v0.1.52 release (PR #244) — the prior release shipping ConMon
  Lite v1.

## [0.1.52] — 2026-05-11

**Tier 4 #2: ConMon Lite v1 — Gap-Agent KSI-verdict regression
diff with 2-of-3 majority voting.** Closes the verdict-stability
deferral from Tier 4 #1. Opt-in via `EFTERLEV_CONMON_LITE_V1` repo
variable (default OFF; per-PR cost ~$0.90 on Sonnet 4.6, lower on
Bedrock). When enabled, every PR gets a SECOND sticky comment
(distinct from the v0 scanner-only delta) listing KSIs whose
verdict regressed (implemented → partial / not_implemented).

### Added

- `--runs N` flag on `efterlev agent gap` (default 1; preserves
  existing single-run behavior). When N > 1, the multi-run path
  invokes the Gap Agent N times in a loop and reduces per-KSI to
  the majority verdict via `Counter` + `ceil(N/2)` threshold.
  Tie-break picks the most-conservative verdict from the tied set
  (precedence: `implemented < partial < not_implemented <
  not_applicable < evidence_layer_inapplicable`); KSIs whose top
  vote count is below the threshold are recorded as flickering.
  (PR #242)
- New module `src/efterlev/agents/multi_run.py`:
  `aggregate_gap_reports(reports) -> (synthesized_report,
  per_run_verdicts, flickering_ksis)`. Pure function; sources
  rationale + evidence_ids from the FIRST run that voted majority
  (deterministic + traceable); sources `claim_record_ids` +
  `unmapped_findings` from the LAST run (most-recently persisted
  to the provenance store). (PR #242)
- New gap-report JSON sidecar fields: `runs_aggregated: int`,
  `per_run_verdicts: dict[ksi_id, list[verdict]]`,
  `flickering_ksis: list[str]`. Always emitted for forward
  compatibility; defaults when single-run. (PR #242)
- `--print-markdown` + `--base-branch` flags on `efterlev report
  diff` (mirrors the `scan-diff` CLI's pattern). Captures the v1
  PR-comment body for the workflow's posting step. (PR #243)
- `render_gap_diff_markdown` function in
  `src/efterlev/reports/gap_diff.py`. Renders a `GapDiff` as the
  markdown PR-comment body with the distinct
  `<!-- efterlev-conmon-lite-v1 -->` marker. Per DECISIONS
  Decision #4, scope is REGRESSED KSIs only — improvements appear
  in the JSON sidecar / HTML report. Tail-truncate at `max_rows`.
  (PR #243)

### Changed

- `.github/workflows/pr-compliance-scan.yml` extended with the
  ConMon Lite v1 path, gated on the `EFTERLEV_CONMON_LITE_V1` GH
  Actions repo variable being `"true"`. When enabled: PR-branch
  Gap Agent runs with `--runs 3`; new step scans the base branch
  with `--runs 3` (reuses the `/tmp/efterlev-conmon-base/`
  worktree the v0 step set up); new step computes the KSI-verdict
  diff via `efterlev report diff --print-markdown`; new step
  posts the v1 sticky comment with `<!-- efterlev-conmon-lite-v1
  -->` marker. v0 + v1 comments coexist on the same PR (different
  audiences: v0 for code reviewers, v1 for compliance reviewers).
  (PR #243)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1455 → 1468 (+13 — 10 in `tests/test_multi_run.py`,
  3 in `tests/test_gap_diff.py`).
- Source files: 219 → 220 (+1 — `multi_run.py`).
- CLI commands: 28 unchanged (extended existing commands rather
  than adding new ones).

### ConMon Lite v0 + v1 status (post-this-release)

| Layer | Marker | Audience | Default | Cost/PR |
|---|---|---|---|---|
| v0 (per-detector gap emissions) | `<!-- efterlev-conmon-lite -->` | Code reviewers | ON | free (deterministic) |
| v1 (KSI-verdict regressions) | `<!-- efterlev-conmon-lite-v1 -->` | Compliance reviewers | OFF (opt-in via `EFTERLEV_CONMON_LITE_V1`) | ~$0.90 (Sonnet 4.6) |

Both coexist on the same PR when v1 is enabled. Each surfaces a
different layer of the regression signal; reading either alone is
useful but the two together are the full picture.

### What's still deferred to future ConMon Lite work

- **Configurable severity thresholds** (which KSI verdict
  transitions warrant block vs warn).
- **Gating policy** (block-on-regress with skip label).
- **Drift detection over time** (not just PR-delta but
  base-vs-prior-base; would need a stored baseline rather than
  ephemeral CI artifacts).
- **Suppression annotations**
  (`# efterlev-ignore: KSI-CNA-RVP`).

### Cross-references

- DECISIONS 2026-05-11 "Tier 4 #2 design: ConMon Lite v1
  (Gap-Agent KSI-verdict diffs with 2-of-3 voting)" (PR #241) —
  the locking entry.
- DECISIONS 2026-05-11 "Tier 4 #1 design: ConMon Lite (PR-delta
  scan comparison)" (PR #237) — the v0 entry whose Decision #2
  deferred this work; this release closes that deferral.
- v0.1.51 release (PR #240) — the prior release shipping ConMon
  Lite v0.

## [0.1.51] — 2026-05-11

**Tier 4 #1: ConMon Lite v0 — the first non-detector strategic
batch since the Tier 3 WAF arc closure.** PR-delta scan
comparison: every PR now gets a sticky comment listing
newly-introduced gaps relative to the base branch. Scanner-only
at v0 (deterministic + free); KSI-verdict diffs deferred to
ConMon Lite v1 once a verdict-stability mechanism is in place.

### Added

- New CLI command `efterlev scan-diff <prior> <current>` —
  per-detector gap-emission diff between two scan-result JSON
  sidecars. Outputs `.efterlev/reports/scan-diff-<ts>.html`
  (full HTML report including resolved gaps for context),
  `.efterlev/reports/scan-diff-<ts>.json` (machine-readable
  structured diff), and optional `--print-markdown` for the
  PR-comment surface. Exit code 2 if any new or modified gaps
  (CI-friendly soft-fail signal). (PR #238)
- `efterlev scan` now emits a JSON sidecar at
  `.efterlev/reports/scan-<ts>.json` alongside the existing
  HTML output. Mirrors the gap/documentation/remediation
  sidecar pattern. Schema v1 fields: `schema_version`,
  `generated_at`, `scan_root`, `scan_mode` (hcl/plan),
  `summary`, `evidence` (per-record `detector_id`, resource
  info, `source_ref`, `content`). The provenance store remains
  the source of truth for within-workspace queries; the sidecar
  is the portable input format for cross-branch diffing. (PR #238)
- New module `src/efterlev/reports/scan_diff.py`:
  `compute_scan_diff` (pure function), `render_scan_diff_markdown`
  (PR-comment renderer), `render_scan_diff_html` (HTML report
  renderer), `ScanDiff` + `ScanDiffEntry` Pydantic models.
  Diff keying is `(detector_id, resource_name)`; three
  outcomes: `new_gap`, `resolved_gap`, `modified_gap`.
  Canonical gap predicate: an evidence record is a gap iff its
  content payload contains a string `gap` field. (PR #238)

### Changed

- `.github/workflows/pr-compliance-scan.yml` extended with
  base-branch scan + ConMon Lite delta-comment posting. Bumped
  checkout `fetch-depth: 1 → 0` so the workflow can
  `git worktree add` the base branch into a sibling directory.
  New steps: "Scan base branch (ConMon Lite v0)", "Compute
  ConMon Lite PR-delta", "Post / update ConMon Lite delta PR
  comment". The new sticky comment uses the
  `<!-- efterlev-conmon-lite -->` marker, distinct from the
  existing posture-comment marker so the two coexist on the
  same PR. Soft-fail at the workflow level: scan-diff exits 2
  on regressions, which IS the signal we want. (PR #239)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1442 → 1455 (+13 — the new `tests/test_scan_diff.py`).
- Source files: 218 → 219 (+1 — the new `scan_diff.py`).
- CLI commands: 27 → 28 (+1 — `efterlev scan-diff`).

### ConMon Lite v0 vs v1 boundaries

**v0 ships (this release):**
- Per-detector gap-emission diff (deterministic, scanner-only).
- New + modified + resolved gap classification.
- Soft-fail PR-comment posting; no merge gating.

**v1 deferred:**
- Gap-Agent KSI-verdict regressions ("KSI X flipped from
  implemented to partial"). Requires a verdict-stability
  mechanism (probably 2-of-3 vote or fixed-RNG prompts) to
  dampen Haiku stochasticity. Tier 4 #2 candidate.
- Configurable severity thresholds.
- Gating policy (block-on-regress with skip label).
- Drift detection over time (not just PR-delta).
- Suppression annotations
  (`# efterlev-ignore: aws.security_group_open_ingress`).

### Cross-references

- DECISIONS 2026-05-11 "Tier 4 #1 design: ConMon Lite (PR-delta
  scan comparison)" (PR #237) — the locking entry.
- v0.1.50 release (PR #236) — the prior release; closes the
  Tier 3 WAF family arc that occupied v0.1.46–v0.1.50.
- `LIMITATIONS.md` "ConMon Lite" deferral since v0.1.18+ — now
  shipped at the v0 layer.

## [0.1.50] — 2026-05-10

**Tier 3 #5: `aws.waf_custom_rule_groups` — closing the `aws.waf_*`
family at 7 of 7 v0/v1 dimensions shipped.** The WAF family arc
spanning 5 batches across 5 releases (v0.1.46 #1, v0.1.47 #2
streaming refactor, v0.1.48 #3, v0.1.49 #4, v0.1.50 #5) is now
complete. Detector count rises 64 → 65; KSI-mapped 60 → 61.
KSI-CNA-RVP cross-coverage rises 8 → 9, the most
cross-resource-type-evidenced KSI in the library by a wide margin
(next-most: KSI-MLA-LET at 5). The 3-dimension SC-7 evidence base
(geo / IP / custom) + 2-dimension AC-3 evidence base (IP / geo) +
the bulk SI-3 coverage make the WAF family the most
cross-control-evidenced detector family.

### Added (Tier 3 #5)

- `aws.waf_custom_rule_groups` (KSI-CNA-RVP, controls SI-3/SC-7) —
  cross-resource detector that walks both `aws_wafv2_web_acl` AND
  `aws_wafv2_rule_group` resources. For each Web ACL, walks rules
  looking for `statement.rule_group_reference_statement.arn`
  references; emits per Web ACL whether any references exist. Two
  states (binary): `custom_rule_groups_present` (lists deduplicated
  referenced ARN strings, with a `defined_rule_groups` inventory
  field), `custom_rule_groups_absent` (gap message surfaces the
  `defined_rule_groups` inventory so the Gap Agent can flag the
  canonical "defined but unreferenced" anti-pattern explicitly —
  a customer paying for the rule-group plumbing without the
  protection). Per DECISIONS Decision #3 carry-forward, no
  cross-resource VALIDATION at the detector layer — ARN strings
  emitted as-is; Gap Agent handles cross-reference resolution.
  9th detector evidencing KSI-CNA-RVP. (PR #234)

### Changed

- `evals/fixtures/serverless-mixed/` rev 7 — extends rev 6 with
  one new rule on `api_protection` (rule_group_reference_statement
  pointing at the new top-level `aws_wafv2_rule_group` resource
  `api_specific_rules`). The bare `legacy_unprotected_waf` ACL now
  exercises both the negative path AND the "defined but
  unreferenced" inventory hint (the api_specific_rules group is
  defined in scope but the legacy ACL doesn't reference it).
  After rev 7, the fixture exercises ALL 7 WAF detectors at both
  posture extremes. (PR #235)

### Internal (count deltas)

- Detector count: 64 → 65 (+1).
- KSI-mapped detectors: 60 → 61 (+1, KSI-CNA-RVP already covered).
- KSI-CNA-RVP detector cross-coverage: 8 → 9.
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 7.
- Test count: 1435 → 1442 (+7 unit tests).
- Source files: 216 → 218 (+2 for the new detector).
- `tests/test_cli.py` KSI-mapped narrative comment condensed (was
  ~35 lines tracking each tier bump; now a 4-line pointer to
  CHANGELOG history) — appropriate now that the WAF arc completes.

### WAF family closure summary

The `aws.waf_*` family v0/v1 arc is now complete. **5 batches
across 5 releases tonight** built up the family from 0 to 7
detectors:

| Release | Tier | Adds |
|---|---|---|
| v0.1.46 | Tier 3 #1 | `waf_rule_count`, `waf_managed_rule_groups`, `waf_rate_limiting` |
| v0.1.47 | Tier 3 #2 | (no new detectors — streaming refactor + cap lift to 32768 unblocking the family's growth) |
| v0.1.48 | Tier 3 #3 | `waf_action_types` (3-state), `waf_ip_set_blocking` (first WAF AC-3) |
| v0.1.49 | Tier 3 #4 | `waf_geo_blocking` (first WAF SC-7) |
| v0.1.50 | Tier 3 #5 | `waf_custom_rule_groups` (cross-resource) |

`serverless-mixed` rev 4 → rev 7 grew to exercise the full family.
KSI-CNA-RVP went from 2 detectors (cna_dos_protection +
api_gateway_waf_attached) to 9.

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #5 design: aws.waf_custom_rule_groups
  (closes the WAF family at 7/7)" (PR #233) — the locking entry.
- DECISIONS 2026-05-10 "Tier 3 #1 design" (PR #213) — Decision #7
  deferred this dimension; this release closes that deferral.
- v0.1.49 release (PR #232) — the prior release shipping Tier 3 #4.

### Tier 3 status

All Tier 3 batches complete:

- ✅ Tier 3 #1 (v0.1.46): `waf_rule_count`, `waf_managed_rule_groups`, `waf_rate_limiting`
- ✅ Tier 3 #2 (v0.1.47): streaming refactor + max_tokens cap lift 20480 → 32768
- ✅ Tier 3 #3 (v0.1.48): `waf_action_types`, `waf_ip_set_blocking`
- ✅ Tier 3 #4 (v0.1.49): `waf_geo_blocking`
- ✅ **Tier 3 #5 (this release): `waf_custom_rule_groups` — closes the WAF family at 7/7**

Future Tier 4 candidates (rule-group-version pinning, scope-down
breadth, custom-aggregation keys, action-type appropriateness
per managed-group) get separate scoping passes when there's
customer pull or specific findings.

## [0.1.49] — 2026-05-10

**Tier 3 #4 `aws.waf_geo_blocking`: 1 new detector closing the
geo-blocking dimension** deferred from Tier 3 #1 Decision #7.
Detector count rises 63 → 64; KSI-mapped 59 → 60. KSI-CNA-RVP
cross-coverage rises 7 → 8 (most cross-resource-type-evidenced
KSI in the library by a wide margin). New 800-53 mapping for the
WAF family: SC-7 (Boundary Protection) — first WAF detector to
evidence boundary protection at the IaC layer.

### Added (Tier 3 #4)

- `aws.waf_geo_blocking` (KSI-CNA-RVP, controls SC-7/AC-3) —
  per-`aws_wafv2_web_acl` evidence on whether at least one rule
  references a `statement.geo_match_statement`. Two states
  (binary): `geo_blocking_present` (lists deduplicated, sorted set
  of country codes covered across all geo rules — ISO 3166-1
  alpha-2), `geo_blocking_absent` (gap message that explicitly
  names "may be intentional for global-customer workloads" so the
  Gap Agent reasons about whether absence is appropriate, not the
  detector). For US-federal workloads the canonical posture
  blocks embargoed countries (KP, IR, CU, SY, plus sanctioned
  subsets of RU). **First WAF-family detector to evidence SC-7
  (Boundary Protection)** at the IaC layer — geo-blocking IS the
  canonical perimeter-side boundary control at the country level;
  the existing SC-7 evidence base is heavily VPC-internal, this
  widens it to the public-internet perimeter. AC-3 mapping
  generalizes the IP-layer mapping that `aws.waf_ip_set_blocking`
  earned in Tier 3 #3 up one layer of the network stack. 8th
  detector evidencing KSI-CNA-RVP. (PR #230)

### Changed

- `evals/fixtures/serverless-mixed/` rev 6 — extends rev 5 with
  one new rule on `api_protection`: a geo-match block rule
  blocking the canonical embargoed-country set (`KP`, `IR`, `CU`,
  `SY`). The bare `legacy_unprotected_waf` ACL exercises the
  negative path. After rev 6, all SIX WAF detectors fire
  positively on `api_protection` and (excluding `action_types`
  which goes vacuously enforcing on the empty rule set) negatively
  on `legacy_unprotected_waf`. (PR #231)

### Internal (count deltas)

- Detector count: 63 → 64 (+1 — see Added section above).
- KSI-mapped detectors: 59 → 60 (+1 — KSI-CNA-RVP already
  covered; widens the resource-type evidence base. Total
  covered-KSI count unchanged at 37/60).
- KSI-CNA-RVP detector cross-coverage: 7 → 8.
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 6.
- Test count: 1428 → 1435 (+7 unit tests for the new detector).
- Source files: 214 → 216 (+2 for the new detector).

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #4 design: aws.waf_geo_blocking
  (single-detector batch)" (PR #229) — the locking entry. Seven
  governing design choices including "two states, NOT three
  (intentional-vs-unintentional axis belongs in the Gap Agent)"
  and "first WAF detector to evidence SC-7".
- DECISIONS 2026-05-10 "Tier 3 #1 design" (PR #213) — Decision #7
  deferred this dimension; this release closes it.
- DECISIONS 2026-05-10 "Tier 3 #3 design" (PR #223) — Decision #7
  carry-forward kept this dimension deferred for individual
  scoping; this release closes that scoping pass.
- v0.1.48 release (PR #227) — the prior release shipping Tier 3 #3.

### Tier 3 status

After this release, the WAF family is at **6 of 7 v0/v1 dimensions
shipped**:

- ✅ rule_count (v0.1.46)
- ✅ managed_rule_groups (v0.1.46)
- ✅ rate_limiting (v0.1.46)
- ✅ action_types (v0.1.48)
- ✅ ip_set_blocking (v0.1.48)
- ✅ geo_blocking (this release)
- ⏸ custom_rule_groups — deferred for Tier 3 #5; cross-resource
  matching pattern needs its own scoping pass

## [0.1.48] — 2026-05-10

**Tier 3 #3 `aws.waf_*` family v1: 2 new detectors closing the
action-type + IP-set-blocking dimensions** deferred from Tier 3 #1
Decision #7. Detector count rises 61 → 63; KSI-mapped 57 → 59.
KSI-CNA-RVP cross-coverage rises 5 → 7 (most cross-resource-type-
evidenced KSI in the library by a wide margin). New 800-53 mapping
for the WAF family: AC-3 (Access Enforcement) on
`aws.waf_ip_set_blocking`.

### Added (Tier 3 #3)

- `aws.waf_action_types` (KSI-CNA-RVP, controls SI-3/SC-5) —
  per-`aws_wafv2_web_acl` evidence classifying the rules' action
  posture as `enforcing` (every rule has block/allow/captcha or
  override_action.none), `observing_only` (every declared rule is
  count-action — the canonical "WAF that observes but does not
  enforce" gap), or `mixed` (both — informational, NOT a gap by
  itself; legitimate ramp-up tactic). The canonical gap this
  detector closes: a managed-group rule with `override_action {
  count {} }` looks like protection in the AWS console but blocks
  nothing. Three states (vs Tier 3 #1's binary detectors) per
  DECISIONS Decision #3 — the third state has real informational
  value the Gap Agent can reason about. 6th detector evidencing
  KSI-CNA-RVP. (PR #224)
- `aws.waf_ip_set_blocking` (KSI-CNA-RVP, controls SC-5/AC-3) —
  per-`aws_wafv2_web_acl` evidence on whether at least one rule
  references an IP-set blocklist via
  `statement.ip_set_reference_statement`. Two states (binary):
  `ip_set_blocking_present` (lists the referenced ARN strings),
  `ip_set_blocking_absent`. **First WAF-family detector to evidence
  AC-3 (Access Enforcement)** at the IaC layer — the mapping is
  honest: an IP-set reference with a block action is the AWS-native
  primitive that enforces access control by source IP, independent
  of any application-layer authentication or authorization. Per
  DECISIONS Decision #1 carry-forward, no cross-resource matching
  at the detector layer — the ARN strings (typically Terraform
  interpolations) are emitted as-is and the Gap Agent resolves
  them. 7th detector evidencing KSI-CNA-RVP. (PR #225)

### Changed

- `evals/fixtures/serverless-mixed/` rev 5 — extends rev 4 with two
  new rules on `api_protection`: a count-action managed-group rule
  (KnownBadInputsRuleSet, `override_action.count`) producing
  `waf_action_types` mixed state, and an IP-set blocking rule
  (`block-bad-actor-ips`, `ip_set_reference_statement`) producing
  `waf_ip_set_blocking` present. Plus a new top-level
  `aws_wafv2_ip_set.bad_actors_blocklist` resource so the
  cross-resource ARN reference resolves. The bare
  `legacy_unprotected_waf` ACL exercises the negative path of
  `waf_ip_set_blocking` (and emits vacuously enforcing on
  `waf_action_types` per its DECISIONS Decision #3 — the
  rules-absent gap is already flagged by `waf_rule_count`). After
  rev 5, the fixture exercises ALL FIVE WAF detectors at both
  posture extremes. (PR #226)

### Internal (count deltas)

- Detector count: 61 → 63 (+2 — see Added section above).
- KSI-mapped detectors: 57 → 59 (+2 — both new detectors map to
  KSI-CNA-RVP, which was already covered. Total covered-KSI count
  unchanged at 37/60).
- KSI-CNA-RVP detector cross-coverage: 5 → 7. KSI-CNA-RVP is now
  the most cross-resource-type-evidenced KSI in the library by a
  wide margin (next-most: KSI-MLA-LET at 5 detectors).
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 5.
- Test count: 1413 → 1428 (+15 — 8 + 7 unit tests across the two
  new detector test files).
- Source files: 210 → 214 (+4 — 2 files per new detector × 2 = 4).

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #3 design: aws.waf_* family v1 —
  action types + IP-set blocking" (PR #223) — the locking entry.
  Seven governing design choices including "two-detector batch is
  the right size for the clean dimensions" and "first WAF detector
  to evidence AC-3 at the IaC layer".
- DECISIONS 2026-05-10 "Tier 3 #1 design" (PR #213) — Decision #7
  deferred this batch. After v0.1.48, two of the four originally-
  deferred WAF dimensions are shipped (action_types, ip_set_blocking);
  two remain deferred (geo_blocking, custom_rule_groups) per Tier 3
  #3 Decision #7 carry-forward, each pending its own scoping pass.
- v0.1.46 release (PR #218) — Tier 3 #1 v0 ship date.
- v0.1.47 release (PR #222) — Tier 3 #2 streaming refactor that
  gives this batch headroom past 20480 max_tokens.

### Tier 3 status

After this release, Tier 3 #1 (waf_* family v0), Tier 3 #2 (streaming
refactor + cap lift), and Tier 3 #3 (waf_* family v1) are all fully
shipped. Five of seven WAF dimensions shipped:

- ✅ rule_count (v0.1.46)
- ✅ managed_rule_groups (v0.1.46)
- ✅ rate_limiting (v0.1.46)
- ✅ action_types (this release)
- ✅ ip_set_blocking (this release)
- ⏸ geo_blocking — deferred per Tier 3 #1/#3 Decision #7; needs own
  scoping pass for the intentional-absence shape
- ⏸ custom_rule_groups — deferred; needs own scoping pass for the
  cross-resource matching pattern

## [0.1.47] — 2026-05-10

**Tier 3 #2 streaming refactor + cap lift to 32768.** Anthropic-direct
`max_tokens` ceiling moves 20480 → 32768, matching Bedrock; the
non-streaming "streaming required for operations that may take longer
than 10 minutes" pre-flight no longer applies. Unblocks fixture
growth and customer-codebase scans previously gated by the cap. No
new detectors, no new KSI mappings, no test count change — this is
an architectural fix to a recurring failure mode that bit twice in
the v0.1.46 patch arc (PR #215 and PR #217 both flaked at the
20480-cap boundary on first attempt and cleared on rerun).

### Changed

- `src/efterlev/llm/anthropic_client.py` — `_one_call` now uses the
  streaming API (`client.messages.stream(...)` context manager) in
  place of `client.messages.create(...)`. Streaming is unconditional
  per DECISIONS Decision #1 (one code path, not two). Public API at
  the agent layer is unchanged: `complete()` still returns the same
  `LLMResponse` shape; the SDK's `stream.get_final_message()` exposes
  `.content`, `.stop_reason`, `.model`, and `.usage` identical to the
  non-streaming response, so the response-validation block + the
  truncation-detection block + the token-usage telemetry are all
  unchanged from the pre-refactor implementation. The retry helper
  (PR #193 Haiku stochastic-rejection) keeps working untouched.
  (PR #220)
- `src/efterlev/agents/gap.py` — `_resolve_max_tokens(default_anthropic=20480, ...)`
  → `_resolve_max_tokens(default_anthropic=32768, ...)`. Replaced
  the obsolete 23-line "Backend-aware default" rationale comment
  (which walked through the v0.1.0/v0.1.1 16384/32768 failure
  history) with a 6-line note pointing at the DECISIONS entry +
  streaming refactor. Documentation Agent and Remediation Agent
  audited per the DECISIONS Decision #1 — neither passes a high
  `max_tokens` (Documentation uses the 4096 default; Remediation
  passes 8192) so neither needed a change. (PR #221)

### Internal

- Bedrock client untouched per DECISIONS Decision #6 — its cap is
  already where we want it; adding streaming to Bedrock is a
  separate change with a separate test surface and zero current
  motivating bug.
- Test surface unchanged at 1413 (the streaming refactor swapped
  the fake SDK shape from `_FakeMessages.create()` returning a
  response to `_FakeMessages.stream()` returning a `_FakeStream`
  context manager, but the assertions are unchanged).
- Source files unchanged at 210.
- Detector count unchanged at 61. KSI-mapped count unchanged at 57.

### Verified end-to-end

`tests/test_deep_smoke.py::test_s5_v0_1_38_quickstart_with_invalid_api_key_friendly_error`
passes against the real Anthropic API at `max_tokens=32768` with the
streaming refactor in place. Without the streaming refactor (cap
bump alone), the SDK rejects the request pre-flight with
"Streaming is required" — exactly the failure mode the refactor
removes.

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #2 design: stream the Anthropic
  client" (PR #219) — the locking entry. Six governing design
  choices including "streaming is unconditional", "no public API
  change at the agent layer", "Bedrock untouched".
- v0.1.46 release (PR #218) — the prior release. PRs #215 and #217
  both hit the 20480 cap on first attempt; PR #217's flake was
  the immediate motivating evidence cited in the DECISIONS entry.
- DECISIONS 2026-05-10 "Tier 3 #1 design: aws.waf_* detector family
  v0" (PR #213) — the batch whose fixture rev surfaced this as a
  recurring failure.

### Tier 3 status

After this release, Tier 3 #1 (aws.waf_* family v0) and Tier 3 #2
(streaming refactor + cap lift) are both fully shipped. Next
candidate: Tier 3 #3, scoped against the Tier 3 #1 Decision #7
deferred WAF dimensions (action types, geo-blocking, IP-set
blocking, custom rule groups) -- DECISIONS entry to follow.

## [0.1.46] — 2026-05-10

**Tier 3 #1 `aws.waf_*` detector family v0: 3 new detectors closing
the WAF-posture-quality dimension that the Tier 2 #3
`aws.api_gateway_waf_attached` left unaddressed. Rule presence,
managed-rule-group references, and rate-based statements are now
evidenced per Web ACL, with serverless-mixed fixture rev 4
exercising both posture extremes in one fixture. Detector count
rises 58 → 61; KSI-mapped 54 → 57. KSI-CNA-RVP detector
cross-coverage rises 2 → 5.**

### Added (Tier 3 #1)

- `aws.waf_rule_count` (KSI-CNA-RVP, controls SI-3/SC-5) — per-Web-ACL
  evidence on whether `aws_wafv2_web_acl` declares at least one `rule`
  block. Two states (binary): `rules_present` (count ≥ 1),
  `rules_absent` (count == 0 — the canonical "WAF attached but does
  nothing" gap). Closes the gap where a Web ACL with
  `default_action { allow {} }` and zero rules passes
  `aws.api_gateway_waf_attached` (it IS attached) but provides no L7
  protection beyond the default action. 3rd detector evidencing
  KSI-CNA-RVP. (PR #214)
- `aws.waf_managed_rule_groups` (KSI-CNA-RVP, controls SI-3/RA-5(11))
  — per-Web-ACL evidence on whether at least one rule references an
  AWS- or vendor-managed rule group via
  `statement.managed_rule_group_statement`. Two states (binary):
  `managed_groups_present` (lists the group names in the detail
  field — e.g. `AWSManagedRulesCommonRuleSet`,
  `AWSManagedRulesKnownBadInputsRuleSet`), `managed_groups_absent`.
  Captures the gap where a Web ACL has only hand-written custom rules
  and lacks the bulk OWASP Top 10 / known-bad-input coverage that
  managed groups provide. Maps to RA-5(11) as a thin proxy signal:
  AWS-managed rule sets track CVE-class disclosures. 4th detector
  evidencing KSI-CNA-RVP. (PR #215)
- `aws.waf_rate_limiting` (KSI-CNA-RVP, controls SC-5/SC-5(2)) —
  per-Web-ACL evidence on whether at least one rule declares a
  rate-based statement via `statement.rate_based_statement`. Two
  states (binary): `rate_limiting_present` (lists each
  `(limit, aggregate_key_type)` tuple in the detail field — e.g.
  `limit=2000 key=IP`), `rate_limiting_absent`. Captures the gap
  where a Web ACL has managed groups but no per-client request cap
  — managed groups catch known-bad patterns but not novel volumetric
  abuse. 5th detector evidencing KSI-CNA-RVP. (PR #216)

### Changed

- `evals/fixtures/serverless-mixed/` rev 4 — extends rev 3 to also
  exercise all three Tier 3 #1 detectors. The existing
  `api_protection` Web ACL gains a managed-rule-group rule
  (CommonRuleSet) and a rate-based rule (limit=2000, IP) — positive
  emission for all three new detectors. A second `aws_wafv2_web_acl`
  `legacy_unprotected_waf` is added with no rules at all — negative
  emission for all three. KSI-CNA-RVP posture is now evidenced
  across 3 stages (waf_attached, +/-) PLUS 2 Web ACLs (3 detectors ×
  2 ACLs = 6 emissions). M3 cross-resource-type signal widens at the
  same KSI without changing the `partial` verdict. (PR #217)

### Internal (count deltas)

- Detector count: 58 → 61 (+3 — see Added section above).
- KSI-mapped detectors: 54 → 57 (+3 — all three new detectors map to
  KSI-CNA-RVP, which was already covered by `aws.cna_dos_protection`
  and `aws.api_gateway_waf_attached`. The new detectors widen the
  resource-type evidence base for KSI-CNA-RVP without adding first-time
  coverage. Total KSI count is unchanged at 37/60).
- KSI-CNA-RVP detector cross-coverage: 2 → 5 (now spans Shield-side
  DOS posture, APIGW-stage WAF attachment, Web-ACL rule presence,
  Web-ACL managed-rule-group references, Web-ACL rate-based
  statements).
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 4.
- Test count: 1392 → 1413 (+21 — 6 + 7 + 8 unit tests across the
  three new detector test files).
- Source files: 204 → 210 (+6 — 2 files per new detector × 3 = 6).

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #1 design: aws.waf_* detector family
  v0" (PR #213) — locked the v0 scope and the three governing design
  calls (per-Web-ACL emission, no `unverifiable` state, no new KSI
  mappings).
- DECISIONS 2026-05-10 Tier 2 #3 — the entry that explicitly deferred
  the broader `aws.waf_*` family to Tier 3 (Decision #2). This
  release closes that deferral.
- v0.1.45 release (PR #210) — the prior release shipping Tier 2 #3.

### Tier 3 status

After this release, the original `aws.waf_*` family Tier 3 #1 v0
scope is **fully closed**: rule presence, managed-rule-group
references, and rate-based statements are evidenced. Future
extensions (action types, version pinning, scope-down breadth,
custom-aggregation keys) remain candidates for later Tier 3
batches but were explicitly out of v0 scope per DECISIONS
Decision #1.

## [0.1.45] — 2026-05-10

**Tier 2 #3 serverless detector batch: 3 new detectors closing the
original 5-detector deferred backlog from PR #196. Lambda VPC
isolation, API Gateway route-level auth, API Gateway WAF attachment.
Detector count rises 55 → 58; KSI-mapped 51 → 54. The new detectors
widen the resource-type evidence base for already-covered KSIs
(CNA family especially) without changing the total covered-KSI
count of 37/60. (Note: the original release headline framed two
of the cited KSIs as previously uncovered; corrected 2026-05-10 —
see the DECISIONS correction entry of that date.)**

### Added (Tier 2 #3)

- `aws.lambda_vpc_isolation` (KSI-CNA-MAT, controls SC-7/SC-7(3)) —
  per-Lambda evidence on whether the function declares a `vpc_config`
  block (network-isolated execution) or runs in the AWS-managed
  default VPC pool (internet-facing). Three states: `vpc_isolated`,
  `internet_facing`, `unverifiable`. 7th detector evidencing
  KSI-CNA-MAT and the library's first Lambda-side network-isolation
  evidence. Per the DECISIONS Decision #1: emits per-resource posture
  and lets the Gap Agent reason about intentionality (webhook
  handlers, public health endpoints). (PR #206)
- `aws.api_gateway_auth_required` (KSI-CNA-EIS + KSI-CNA-DFP, controls
  AC-3/AC-6) — per-route evidence on whether the route declares
  non-NONE authorization. Covers `aws_api_gateway_method`
  (REST v1, `authorization` field) and `aws_apigatewayv2_route`
  (HTTP v2, `authorization_type` field). Three states: `auth_required`,
  `auth_none`, `unverifiable`. **Adds APIGW route-level evidence for
  both KSI-CNA-EIS and KSI-CNA-DFP** — KSI-CNA-EIS was already evidenced
  by `aws.access_analyzer_enabled` (assessment slice via CA-7 + AC-6),
  KSI-CNA-DFP by `aws.ec2_imdsv2_required` (CM-2 baseline-configuration
  slice). This detector contributes the routing-edge slice; the three
  detectors together cover the KSIs across distinct resource-type
  surfaces. (PR #207. Correction note: the original PR #205 / #207
  framing of those KSIs as previously uncovered was incorrect —
  see the 2026-05-10 DECISIONS correction entry.)
- `aws.api_gateway_waf_attached` (KSI-CNA-RVP, controls SI-3/SC-5) —
  per-stage evidence on whether an `aws_wafv2_web_acl_association`
  references the stage by Terraform name. Two states (binary, no
  `unverifiable` per Decision #3 — interpolation in `resource_arn` is
  the norm). 2nd detector evidencing KSI-CNA-RVP (joins
  `aws.cna_dos_protection` on the Shield-side DOS protection). Per
  Decision #2: ships as a single WAF-attachment detector; the broader
  `aws.waf_*` family (rule coverage, rate limiting, geo-blocking,
  managed groups) deferred to Tier 3. (PR #208)

### Changed

- `evals/fixtures/serverless-mixed/` rev 3 — extends rev 2 to also
  exercise all three Tier 2 #3 detectors. Lambda `api_handler` gains
  `vpc_config`; new APIGW methods (`get_users` IAM, `get_health`
  NONE) + v2 route (`post_orders` JWT); new `aws_wafv2_web_acl` +
  association protecting `public_api_v1_prod_stage`. KSI-CNA-MAT,
  KSI-CNA-EIS, KSI-CNA-DFP, KSI-CNA-RVP added to the labeled set.
  After rev 3, the fixture exercises ALL SEVEN Tier 2 detectors and
  the original 5-detector deferred backlog from PR #196 is fully
  closed at both the detector layer AND the eval-harness regression
  surface. (PR #209)

### Internal (count deltas)

- Detector count: 55 → 58 (+3 — see Added section above).
- KSI-mapped detectors: 51 → 54 (+3 — all three new detectors map to
  KSIs already in the FRMR catalog AND already covered by at least one
  pre-existing detector; the new detectors widen the resource-type
  evidence base on those KSIs without adding first-time coverage. Total
  KSI count is unchanged at 37/60).
- KSI-CNA-MAT detector cross-coverage: 6 → 7 (now spans security_group,
  NACL, S3 PAB, RDS, S3 ACL, plus Lambda VPC isolation).
- KSI-CNA-RVP detector cross-coverage: 1 → 2 (joins
  `aws.cna_dos_protection`).
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 3.
- Test count: 1365 → 1385 (+20 — 6 + 7 + 7 unit tests across the
  three new detector test files).
- Source files: 198 → 204 (+6 — 2 files per new detector × 3 = 6).

### Cross-references

- DECISIONS 2026-05-10 "Tier 2 #3 design: VPC isolation, route auth,
  WAF attachment" (PR #205) — locked the v0 scope and the three
  governing design calls (emit-and-let-agent-reason, ship-WAF-now,
  no-unverifiable-on-WAF).
- DECISIONS 2026-05-09 "Tier 2 #1 design" (PR #196) — the original
  entry that deferred these three detectors; this release closes
  the entire deferred backlog.
- v0.1.44 release (PR #204) — the prior release shipping Tier 2
  #1 + #2.

### Tier 2 status

After this release, the original 5-detector Lambda + API Gateway
deferred backlog from PR #196 is **fully closed**:

- ✅ Tier 2 #1: `aws.lambda_logging_configured`,
  `aws.api_gateway_tls_min_version` (v0.1.44)
- ✅ Tier 2 #2: `aws.lambda_env_kms_encryption`,
  `aws.api_gateway_access_logging` (v0.1.44)
- ✅ Tier 2 #3: `aws.lambda_vpc_isolation`,
  `aws.api_gateway_auth_required`, `aws.api_gateway_waf_attached`
  (this release)

Remaining serverless follow-ups: an `aws.waf_*` family (per Tier 2
#3 Decision #2) is the natural next-tier candidate.

## [0.1.44] — 2026-05-10

**Tier 2 serverless detector batches: 4 new detectors covering Lambda
observability, Lambda env-var KMS, API Gateway TLS-floor, and API
Gateway access logging, plus a new `serverless-mixed` eval-harness
fixture. Detector count rises 51 → 55; KSI-mapped 47 → 51.**

### Added (Tier 2 #1)

- `aws.lambda_logging_configured` (KSI-MLA-LET, controls AU-2/AU-12) —
  reads `aws_lambda_function` resources and emits one Evidence record
  per function describing whether a corresponding
  `aws_cloudwatch_log_group` is declared in the same plan/repo
  (matched by the canonical `/aws/lambda/<function_name>` naming
  convention). Three states: `configured`, `absent`, `unverifiable`
  (function_name uses Terraform interpolation). Library's first
  `aws_lambda_function`-side detector. (PR #197)
- `aws.api_gateway_tls_min_version` (KSI-SVC-SNT, controls
  SC-8/SC-13/SC-23) — reads `aws_api_gateway_domain_name` (REST API
  v1) and `aws_apigatewayv2_domain_name` (HTTP/WebSocket API v2)
  resources and emits one Evidence record per custom domain
  describing whether `security_policy` enforces TLS 1.2 or higher.
  Surfaces the canonical legacy gap where v1 custom domains created
  without an explicit `security_policy` accept TLS 1.0. (PR #198)
- New eval-harness fixture `evals/fixtures/serverless-mixed/` (rev 1)
  exercising both new Tier 2 #1 detectors with mixed posture (2
  Lambdas, 3 APIGW custom domains). 5th eval-harness fixture. (PR #199)

### Added (Tier 2 #2)

- `aws.lambda_env_kms_encryption` (KSI-AFR-UCM, controls
  SC-28/SC-28(1)) — reads `aws_lambda_function` resources whose
  `environment.variables` block is non-empty and emits one Evidence
  record per such function describing whether `kms_key_arn` is set
  (customer-managed-key encryption-at-rest of env-var values).
  Functions with no env vars are skipped (no secrets to protect).
  8th detector evidencing KSI-AFR-UCM. (PR #201)
- `aws.api_gateway_access_logging` (KSI-MLA-LET, controls AU-2/AU-3)
  — reads `aws_api_gateway_stage` (REST v1) and `aws_apigatewayv2_stage`
  (HTTP v2) resources and emits one Evidence record per stage
  describing whether an `access_log_settings` block is declared.
  Stage-shaped evidence (per-stage granularity matters: a single API
  can have prod with logging on and staging without). 5th detector
  evidencing KSI-MLA-LET — KSI-MLA-LET is now the most
  cross-resource-type-evidenced KSI in the library. (PR #202)

### Changed

- `evals/fixtures/serverless-mixed/` rev 2 — extends rev 1 to also
  exercise the Tier 2 #2 detectors. New `aws_kms_key.lambda_env_secrets`,
  env-vars + kms_key_arn on api_handler (positive on Tier 2 #2 PR β),
  env-vars without kms_key_arn on background_worker (negative).
  Three new stage resources covering both REST v1 prod-with-logs +
  staging-without (the canonical mixed-prod-staging shape) and HTTP v2
  default-with-logs. KSI-AFR-UCM added to the labeled set. (PR #203)

### Internal (count deltas)

- Detector count: 51 → 55 (+4 — see Added sections above).
- KSI-mapped detectors: 47 → 51 (+4 — all four new detectors map to
  KSIs already in the corpus, widening resource-type coverage rather
  than introducing new KSI mappings).
- KSI-MLA-LET detector cross-coverage: 3 → 5 (now spans CloudTrail,
  CloudWatch alarms, CloudTrail log-file validation, Lambda log
  groups, and APIGW stage access logs).
- Eval-harness fixtures: 4 → 5 (govnotes-v1, encryption-mixed,
  iam-dynamic-policy, runtime-monitoring, serverless-mixed).
  Encryption-mixed at rev 3 unchanged this release; serverless-mixed
  rev 2 (extended in this release).
- Test count: 1329 → 1365 (+36 — roughly 6 unit tests per new
  detector × 4 = 24, plus 12 from the M3 + retry test additions
  shipped between v0.1.43 and v0.1.44).
- Source files: 190 → 198 (+8 — 2 files per new detector × 4 = 8).

### Cross-references

- DECISIONS 2026-05-09 "Tier 2 #1 design: Lambda + API Gateway
  detector batch v0" (PR #196) — locked the Tier 2 #1 v0 scope.
- DECISIONS 2026-05-10 "Tier 2 #2 design: Lambda env-var KMS +
  APIGW access logging" (PR #200) — locked the Tier 2 #2 v0 scope.
- v0.1.43's eval-harness `--runs N` flag and gap-stage retry helper
  saved real time during the Tier 2 work — the retry helper had
  three production saves across the Tier 2 baselines (PRs #195,
  #199, #203).

### Deferred to follow-on Tier 2 entries

Three detectors flagged in PR #196's deferred-items list remain on
the backlog, each gated on its own DECISIONS entry: `lambda_vpc_isolation`
(false-positive-discipline design needed); `api_gateway_auth_required`
(REST-vs-HTTP-API model design); `api_gateway_waf_attached` (likely
deserves its own `aws.waf_*` detector family).

## [0.1.43] — 2026-05-09

**Agent-quality maturity sprint: gap/doc/remediation prompts rewritten
against the current Anthropic best-practices guide. Eval-harness M1
status_precision lifted 0.818 → 1.0 on the most-exercised fixture.
v0.2 eval-harness gains a `--runs N` flag for multi-run noise-floor
calibration; per-metric noise floor calibrated to 0.0 stddev empirically
on the post-prompt-overhaul output.**

### Changed

- `src/efterlev/agents/gap_prompt.md` — rewritten against the 2026
  Anthropic prompting best-practices guide. Wrapped sections in
  semantic XML tags, added 5 few-shot `<example>` blocks (covering
  hard status calls including manifest-self-attestation and
  comprehensive-IaC-still-partial patterns), tightened classification
  rule 2 to require zero procedural layer for `implemented`, encoded
  the policy decision that manifest evidence never reaches
  `implemented` (operator self-attestation, not independently
  verified).
- `src/efterlev/agents/documentation_prompt.md` — same XML-tag pass,
  3 worked few-shot narratives, new `<evidence_categories>` section
  requiring verbatim manifest-substring quoting (codifies what M4
  measures so the prompt and metric agree).
- `src/efterlev/agents/remediation_prompt.md` — same XML-tag pass,
  1 worked diff example, expanded anti-overengineering breakdown
  (scope / docs / defensive coding / abstractions sub-bullets),
  concrete `git apply + terraform fmt -check + terraform validate`
  bar replacing the qualitative "produce valid Terraform" guidance.
- `evals/fixtures/govnotes-v1/` rev 4 — added `aws_security_group`
  (mixed: HTTPS-only + SSH-to-internet), `aws_network_acl` (mixed:
  restrictive private subnet + wide-open public), and the full AWS
  Backup orchestration stack (`aws_backup_plan` + `_vault` +
  `_selection` covering the RDS instance). KSI-CNA-MAT/CNA-RNT/RPL-ARP
  now classify against real evidence instead of falling through to
  `evidence_layer_inapplicable`.
- `evals/fixtures/encryption-mixed/` rev 2 — added ELI alternation
  for KSI-CNA-MAT/SVC-VRI/SVC-PRR (their detector mappings target
  surfaces this S3-only fixture doesn't exercise); moved M3 expected
  resources to KSI-AFR-UCM where S3 evidence actually attaches.

### Added

- `evals/aggregate.py` + `--runs N` flag on `python -m evals run` —
  multi-run aggregator that prints per-metric mean / stddev / min /
  max and writes `aggregate.json` for cross-aggregate comparison.
  Use `--runs 3` or `--runs 5` to get above the per-metric noise
  floor when evaluating a prompt or fixture change.
- `tests/test_evals_aggregate.py` — 7 cases covering aggregation
  formula, zero-denominator skip path, per-metric/global empty input,
  formatter shape.

### Internal (count deltas)

- Test count: 1322 → 1329 (+7 from `test_evals_aggregate.py`).
- Detector count: unchanged at 51.
- KSI coverage: unchanged at 37/60.
- Source-file count: unchanged at 190.

### Cross-references

- DECISIONS 2026-05-09 "Per-metric noise-floor calibration; pipeline-
  reliability ceiling on Haiku 4.5 surfaces" — empirical noise-floor
  data underlying this release's metric claims.
- DECISIONS 2026-05-08 "v0.2 agent-quality eval harness: lock Phase 1
  scope" — the harness this release matures.
- PR #189 — the prompt-overhaul + `--runs N` PR squash-merged into
  this release.

## [0.1.42] — 2026-05-08

**Tier 1 #4.1 implementation: KSI-AFR-UCM coverage via mapping updates
on 7 existing detectors. KSI coverage rises 36/60 → 37/60.**

### Root cause

DECISIONS 2026-05-08 "Tier 1 #4.1: re-classification audit of the 24
procedural-only KSIs" identified KSI-AFR-UCM (Using Cryptographic
Modules) as a re-classification candidate. The original 2026-05-07
analysis classified UCM as procedural-only on the read that "selection
and use" is a documentation activity. Re-read: the requirement also
names the *technical artifact* (actual cryptographic modules in use),
which IS in IaC.

Implementation discovery (during this PR's work): 7 existing detectors
already evidence UCM-relevant infrastructure (KMS keys, KMS rotation,
EBS/S3/RDS encryption, CloudFront viewer protocol, LB TLS policies)
but none were mapped to KSI-AFR-UCM. The right design pivot was
**mapping updates on existing detectors**, NOT a fresh detector folder.
This is a smaller, cleaner change than the DECISIONS entry's original
scope of "1 new detector + 1 manifest template" — the manifest
template already shipped in v0.1.21 as part of the 24-template
starter pack, so the only work needed was the mapping updates.

### Changed

- **`aws.kms_customer_managed_keys`** — added `KSI-AFR-UCM` (partial).
  CMKs evidence FIPS-validated cryptographic-module use (AWS KMS HSMs
  are FIPS 140-2 Level 3 validated).
- **`aws.kms_key_rotation`** — added `KSI-AFR-UCM` (reinforces).
  Automatic rotation evidences cryptographic-key lifecycle alignment
  with UCM expectations.
- **`aws.fips_ssl_policies_on_lb_listeners`** — added `KSI-AFR-UCM`
  (partial). TLS-policy choice on LB listeners evidences the FIPS-
  aligned cipher suite layer of UCM.
- **`aws.cloudfront_viewer_protocol_https`** — added `KSI-AFR-UCM`
  (reinforces). HTTPS-only viewer protocol + TLSv1.2+ minimum on
  CloudFront distributions evidence cryptographic transport for
  federal customer data in transit.
- **`aws.encryption_ebs`**, **`aws.encryption_s3_at_rest`**,
  **`aws.rds_encryption_at_rest`** — added `KSI-AFR-UCM` (partial).
  Pre-v0.1.42 these were `ksis=[]` per DECISIONS 2026-04-21 because
  SC-28 has no direct FRMR KSI mapping in 0.9.43-beta; the v0.1.42
  re-classification audit identified the IaC angle. At-rest encryption
  evidences cryptographic-module use on the storage tier
  (FIPS-validated AWS KMS by default in commercial regions).

### Internal

- Detector count: unchanged at 51.
- Test count: 1266 (no test count change — assertion updates only).
- KSI-mapped detectors: 44 → 47. Supplementary 800-53-only: 7 → 4.
- Both the `@detector(ksis=[...])` decorator AND the in-body
  `Evidence.create(ksis_evidenced=[...])` calls were updated. This
  is the existing pattern (decorator informs the registry; in-body
  list informs each emitted Evidence record); both are needed.
- `mapping.yaml` companion files updated for human-readable
  documentation of the new KSI relationship.

### Sibling fix

- **`pip-audit` ignores CVE-2026-44405 (paramiko 4.0.0).** The
  advisory dropped between v0.1.41's CI pass and v0.1.42's CI run
  with no fix version published. paramiko is transitive via
  compliance-trestle's OSCAL/FRMR pipeline; efterlev imports no SSH
  code, so the vulnerable surface is unreachable from any agent /
  detector / scan path. `.github/workflows/ci-security.yml` now
  carries an `--ignore-vuln CVE-2026-44405` exception with the
  rationale + revisit condition documented inline. Bundled into
  this release rather than a standalone PR to save GHA minutes.

### Cross-references

- DECISIONS 2026-05-08 "Tier 1 #4.1: re-classification audit of the
  24 procedural-only KSIs" (PR #177) — the design entry that approved
  this implementation.
- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis" —
  the parent classification this audit revisited.
- DECISIONS 2026-04-21 — the original `ksis=[]` posture for the SC-28
  trio that v0.1.42 supersedes.
- v0.1.21 manifest starter pack — `KSI-AFR-UCM.template.yml` already
  shipped; no manifest work needed in this release.

### Design refinement vs DECISIONS entry

The DECISIONS entry described the implementation as "1 new detector
(`aws.afr_cryptographic_modules_fips`) + 1 new manifest template +
LIMITATIONS update + EXPECTED_DETECTORS bump 51→52." During
implementation we discovered the existing-detector overlap and
pivoted to mapping updates. Cleaner outcome: smaller diff, no new
detector folder, no EXPECTED_DETECTORS bump, manifest template
already exists. Same KSI-coverage outcome (37/60).

The original "fresh detector" scope COULD still ship later if
ACM key-algorithm checks or GovCloud region detection prove worth
adding (neither was covered by existing detectors). Deferred — this
release achieves the UCM-coverage win at low cost.

## [0.1.41] — 2026-05-08

**Bedrock probe — test-call closure (catches every AWS misalignment
class, including ones we haven't enumerated yet).**

### Root cause

The v0.1.40 deep-test re-validation (S2 finding) hit a fourth distinct
AWS-state misalignment class on top of the three v0.1.36/39/40 caught
with enumerable filters:

  1. v0.1.36: lexical sort wrong → version-tuple parse.
  2. v0.1.39: `lifecycle=LEGACY` underlying foundation models →
     skip those profiles.
  3. v0.1.40: `inferenceTypesSupported` lacks `ON_DEMAND` →
     skip those foundation-model fallback candidates.
  4. **v0.1.41 (this finding):** an inference profile pointing at a
     foundation model AWS has EOL'd. The foundation model is
     **removed entirely** from `list_foundation_models`, but the
     cross-region profile lingers as `status=ACTIVE`. AWS only
     surfaces the EOL state at Converse time as
     `ResourceNotFoundException: This model version has reached
     the end of its life.`

Each iteration we've added another filter chasing AWS's published
signals. Each shipped, then the next deep-test surfaced a new class.
Test-call is the closure: invoke a 1-token Converse ping against
each candidate before settling. Catches every Bedrock misalignment
class, present and future.

### Fixed

- **`_probe_bedrock_for_family` walks candidates in version-priority
  order, performs a 1-token Converse test-call against each, returns
  the first that accepts the call.** Cost: ~$0.0001 per ping +
  ~200ms latency. Worst case is ~5 pings if the top candidates fail.
  Best case is 1 ping.
- **Graceful degradation if `bedrock-runtime` client construction
  fails** — falls back to v0.1.40 behavior (return highest-version
  candidate untested) rather than failing init outright.
- **Catches three categories without explicit handling:**
  - EOL'd foundation models lingering as ACTIVE profiles
    (the v0.1.40 S2 finding).
  - Invalid model IDs (typos, region mismatches — would produce
    `ValidationException: The provided model identifier is invalid.`).
  - Inference-profile-only models that slip past the `ON_DEMAND`
    filter for any reason.
  - Anything AWS invents next.
- **Validation-prompt skill — fixed the Sonnet ID typo.** The runbook
  was using `us.anthropic.claude-sonnet-4-6-v1:0` (which doesn't
  exist as a real Bedrock ID) — the actual ID drops the `-v1:0`
  suffix for `4-6` and `4-7` shapes. The dated `-YYYYMMDD-v1:0`
  shape is only used for older variants. Now the skill explicitly
  notes this naming convention so future validation prompts don't
  repeat the typo.

### Added

- 4 new probe tests:
  - `test_v0_1_41_skips_eol_profile_caught_only_by_test_call` —
    A/B lock; reproduces the user's exact account state where
    Claude 3 Opus is EOL but its cross-region profile is still
    ACTIVE.
  - `test_v0_1_41_returns_none_when_no_candidate_test_call_succeeds`
    — locks the "all candidates fail → return None → init surfaces
    actionable error" path.
  - `test_v0_1_41_test_call_walks_candidates_in_version_order` —
    locks priority ordering: 4-7 fails, 4-1 next; not Claude 3 Opus.
  - `test_v0_1_41_falls_back_to_first_candidate_when_runtime_client_construction_fails`
    — graceful degradation lock for credential edge cases.
- Test mock helper `_patch_boto` extended with an `invokable: set[str] |
  None` parameter. None preserves pre-v0.1.41 default ("everything
  invokable"); explicit set lets tests pin which candidates the
  Converse mock accepts vs rejects.
- `_is_invokable(runtime_client, model_id)` helper — extracted for
  testability and clarity. Catches all exceptions; the probe only
  cares about success-vs-not, not the exception class.

### Changed

- `.claude/commands/validation-prompt.md` — naming-convention note
  for newer Bedrock IDs (`-4-6` / `-4-7` drop the `-v1:0` suffix
  vs older `-YYYYMMDD-v1:0` shape).

### Internal

- Test count: 1262 → 1266 (+4).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- Init takes ~200ms–1s longer when --llm-backend=bedrock is used
  without --llm-model (the test-call latency). No-op for the
  Anthropic backend or when --llm-model is passed explicitly.

### Cross-references

- v0.1.40 deep-test re-validation S2 finding (the source).
- v0.1.36/39/40 enumerable-filter additions — v0.1.41 supersedes
  the iteration cycle by closing on Converse-time validation.
- AWS Bedrock `Converse` API contract — the same call agents will
  make at runtime, so probe-time success implies agent-time success
  (modulo throughput throttling differences).

## [0.1.40] — 2026-05-08

**Bedrock probe — on-demand-callability filter (closes the v0.1.39
deep-test S2 finding); init surfaces a clear actionable error when no
usable model is auto-discoverable instead of silently writing a doomed
config.**

### Root cause

v0.1.39's lifecycle-aware probe correctly skipped LEGACY-backed
inference profiles and fell back to the highest-version `ACTIVE`
foundation model — but the gap call died with
`ValidationException: Invocation of model ID anthropic.claude-opus-4-7
with on-demand throughput isn't supported. Retry your request with the
ID or ARN of an inference profile that contains this model.` AWS's
contract is that `lifecycle=ACTIVE` does NOT imply directly invokable;
newer Anthropic Opus 4.x foundation models are inference-profile-only,
and the documented signal is the `inferenceTypesSupported` field in
`list_foundation_models` — present-and-contains-`ON_DEMAND` is the
right test, lifecycle alone is insufficient. Surfaced by the v0.1.39
deep-test re-validation against a real account (S2 finding).

### Fixed

- **Foundation-model fallback in `_probe_bedrock_for_family` now
  filters on `inferenceTypesSupported` containing `ON_DEMAND`.** ACTIVE
  foundation models that AWS publishes as inference-profile-only get
  rejected. The filter applies ONLY to the foundation-model fallback
  path, NOT to inference profiles themselves — a profile is by
  definition the right way to invoke its underlying model regardless
  of the model's own inference-types listing.
- **Defensive: missing `inferenceTypesSupported` field treated as
  not-on-demand.** Edge cases / older API responses skip rather than
  optimistically pick something that might fail at runtime.
- **Init no longer silently falls back to `DEFAULT_BEDROCK_MODEL` when
  the probe returns None.** In the user's account state that triggered
  this finding, the hardcoded default was ALSO not invokable —
  silently writing it to config produced a "succeeds at init, fails
  at agent call" footgun. v0.1.40 surfaces a clear error at init
  time with three concrete remediation options:
  1. Opt into a `us.*` cross-region inference profile in the AWS
     Bedrock Model Access page.
  2. Override with `--llm-model global.anthropic.claude-opus-4-7-v1:0`
     (with explicit FedRAMP-boundary tradeoff acknowledgment).
  3. Override with `--llm-model us.anthropic.claude-sonnet-4-6-v1:0`
     or another directly-invokable family.

  Plus a diagnostic `aws bedrock list-foundation-models …` command
  the user can paste straight into their terminal to see what their
  account actually exposes.

### Added

- 4 new probe tests:
  - `test_v0_1_40_skips_foundation_model_without_on_demand_inference_type`
    — A/B lock against the documented contract.
  - `test_v0_1_40_returns_none_when_only_inference_profile_only_models_exist`
    — reproduces the user's exact account state.
  - `test_v0_1_40_treats_missing_inference_types_field_as_no_on_demand`
    — defensive lock.
  - `test_v0_1_40_inference_profile_kept_even_when_underlying_lacks_on_demand`
    — locks that the on-demand filter doesn't accidentally reject
    inference profiles whose underlying model is profile-only (which
    is the entire point of inference profiles).
- Test mock helper `_mock_foundation_models_response` extended to
  accept 3-tuples `(model_id, lifecycle, inference_types)` while
  preserving 2-tuple back-compat (defaults to `["ON_DEMAND"]`).

### Changed

- `.claude/commands/validation-prompt.md` — added the `set -o pipefail`
  / `${PIPESTATUS[0]}` guidance per the v0.1.39 deep-test session
  surprise: a `efterlev <verb> 2>&1 | tee /tmp/log; $?` pattern
  captures `tee`'s exit code (always 0), masking real failures. First
  S2 report falsely reported PASS for this reason.

### Internal

- Test count: 1258 → 1262 (+4).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- The init-path change (error vs silent fallback) is technically
  user-observable but only on accounts where probe couldn't find any
  usable model anyway — those users got a doomed config + agent-time
  failure pre-v0.1.40, now they get a clear init-time error. Strict
  improvement.

### Cross-references

- v0.1.39 deep-test re-validation S2 finding (the source).
- v0.1.39 (foundation-model fallback) — v0.1.40 narrows that fallback
  to actually-callable models.
- AWS Bedrock docs on `inferenceTypesSupported` — the documented
  signal we filter on.

## [0.1.39] — 2026-05-08

**Bedrock probe — lifecycle-aware + foundation-model fallback (resolves
the v0.1.38 deep-test S4-derivative finding); init no longer refuses on
manifests-only `.efterlev/` directories (S3b).**

### Root cause for the lifecycle issue

The v0.1.38 deep-test re-validation surfaced a real account-state where
the only `us.*` Anthropic Opus inference profile in `us-east-1` was
`us.anthropic.claude-opus-4-20250514-v1:0` — whose underlying foundation
model `anthropic.claude-opus-4-20250514-v1:0` is marked `lifecycle=LEGACY`.
Init's auto-pick succeeded against the profile, but the gap-agent call
died with AccessDenied because Bedrock rejects calls to LEGACY models.
Newer Opus models (4-1, 4-5, 4-6, 4-7) ARE present in the account as
ACTIVE foundation models — but AWS hasn't yet stood up corresponding
`us.*` cross-region inference profiles in this region, so the v0.1.36
probe never saw them.

### Fixed

- **`_probe_bedrock_for_family` now consults
  `bedrock:list_foundation_models(byProvider="anthropic")`** in addition
  to `list_inference_profiles`. It builds a lifecycle map and applies
  two new rules:
  1. Skip inference profiles whose underlying foundation model has
     `lifecycle=LEGACY`. The profile itself reports `status=ACTIVE` but
     the model behind it has been deprecated, so calls fail at agent
     runtime with AccessDenied.
  2. When no usable cross-region profile remains, fall back to the
     highest-version `lifecycle=ACTIVE` foundation model directly.
     Bedrock's Converse API accepts foundation-model IDs (e.g.
     `anthropic.claude-opus-4-7`), so this is a valid call path.
- **Cross-region profile preferred over direct foundation-model
  invocation when versions tie** — encoded as an explicit secondary
  sort key, not relying on lexical accident. Cross-region routing has
  better availability characteristics.
- **Graceful degradation if `ListFoundationModels` permission is
  denied** — probe falls back to the v0.1.36 profiles-only path. Better
  than hard-failing the auto-pick.
- **S3b: `init_workspace` no longer refuses on a `.efterlev/manifests/`-
  only directory.** The canonical git pattern is to commit
  `.efterlev/manifests/` while gitignoring `.efterlev/cache/`. Pre-v0.1.39
  a fresh clone of a repo that ships Evidence Manifests forced the user
  to pass `--force` just to bootstrap. Now refusal only fires when init's
  actual outputs (`cache/`, `config.toml`, `provenance.db`) already
  exist. Surfaced by the v0.1.35 deep-test S3b finding.

### Added

- 6 new probe tests in `tests/test_bedrock_probe.py`:
  - `test_v0_1_39_skips_legacy_backed_inference_profile` — A/B lock
  - `test_v0_1_39_falls_back_to_active_foundation_model` — reproduces
    the user's actual account state and verifies the right pick
  - `test_v0_1_39_prefers_profile_over_equal_version_foundation_model`
  - `test_v0_1_39_returns_none_when_only_legacy_candidates`
  - `test_v0_1_39_continues_when_list_foundation_models_denied`
  - `test_v0_1_39_foundation_model_fallback_filters_by_family`
- 2 new workspace tests in `tests/test_workspace.py`:
  - `test_v0_1_39_init_allows_manifests_only_directory`
  - `test_v0_1_39_init_still_refuses_when_cache_present` (lock against
    accidentally loosening the destructive-overwrite safety check)
- Test mock helpers extended: `_mock_foundation_models_response` and
  `_patch_boto(foundation_models=...)` parameter so existing tests
  continue to work unchanged while new tests can exercise the
  lifecycle path.

### Internal

- Test count: 1236 → 1244 (+8).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- AgentError-wrapping contract for `*Client.complete()` is unchanged.
- Probe behavior is backward-compatible when the lifecycle data is
  unavailable (e.g. older boto3 / restricted IAM): old profile-only
  selection is preserved.

### Cross-references

- v0.1.36 (lexical-sort fix) — v0.1.39 builds on v0.1.36's tuple-parse
  + `us.*` filter; the new lifecycle check sits on top.
- v0.1.38 deep-test re-validation session (the finding source).
- The diagnosis was a multi-hop investigation across CWD-shadow imports
  and reporting-vs-raw-output confusion — see CLAUDE.md "Known gotchas"
  for the import-path lessons.

## [0.1.38] — 2026-05-07

**HIGH-priority UX fixes from the v0.1.35 deep-test session.** Closes
S2 (quickstart raw 401 traceback) and S1 (uv-tool symlink silently
shadows pipx → user runs `pipx upgrade` and stays on the old version).

### Fixed

- **S2: Friendly handler unwraps chained SDK errors via `__cause__`.**
  Pre-v0.1.38 the `friendly_llm_error_handler` only matched
  `isinstance(e, anthropic.APIError)` against the OUTER exception. But
  `AnthropicClient.complete()` (and `AnthropicBedrockClient.complete()`)
  wrap non-retryable SDK errors as `AgentError(...)` for caller-uniform
  error typing — so by the time the handler ran, `e` was an
  `AgentError`, not an `APIError`, and the friendly path was bypassed.
  Result: a set-but-invalid `ANTHROPIC_API_KEY` gave the user a 600-line
  raw 401 traceback mid-quickstart (the exact thing this layer was
  built to prevent). v0.1.38 walks the `__cause__` chain looking for an
  `anthropic.APIError`; if found, the friendly message + hint surface
  as designed. Cycle-safe (tracked via `seen` set on `id()`).
- **S1: `efterlev --version` warns on parallel installs.** When the
  user has both pipx and uv-tool venvs of efterlev, only one of them
  owns the `~/.local/bin/efterlev` symlink — so the OTHER manager's
  `upgrade` command silently leaves the user on the older install.
  The deep-test tester hit this exactly: `pipx upgrade` to v0.1.35
  succeeded, but PATH still routed to v0.1.15 (uv-tool's symlink won
  the race). Pre-v0.1.38 this was only surfaced via `efterlev doctor`
  (which the tester didn't run before tripping over it). v0.1.38 prints
  the warning to stderr on every `--version` invocation so the user
  notices BEFORE running into mysterious old-version behavior. Single-
  install hosts get no warning (no false-positive noise).

### Added

- 5 new tests:
  - `test_v0_1_38_handler_unwraps_chained_sdk_error_via_cause` — A/B-style
    lock that fails the suite if the handler stops walking `__cause__`.
  - `test_v0_1_38_handler_unwraps_deeply_chained_sdk_error` — multi-level
    nesting (AgentError → AgentError → APIError).
  - `test_v0_1_38_handler_does_not_loop_on_self_referential_cause` —
    cycle-safety lock.
  - `test_v0_1_38_version_flag_warns_on_parallel_installs` — locks the
    shadow warning fires on the 2-manager case.
  - `test_v0_1_38_version_flag_silent_when_one_install` — locks no false
    positive on single-install hosts.

### Internal

- Test count: 1231 → 1236 (+5).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- AgentError-wrapping contract for `*Client.complete()` is unchanged —
  callers that catch `AgentError` keep working. Only the friendly handler
  was changed (additive: it ALSO catches anthropic.APIError when found
  via `__cause__`).

### Cross-references

- v0.1.35 deep-test session report (S1 + S2 findings).
- v0.1.37 (Bedrock silent-wedge fix, also from the same session report).
- S3b (init refuses on pre-existing manifests) and S4b (Opus 4.7 not in
  pricing registry) deferred — S3b needs scope decision (init UX is more
  involved than a one-line fix); S4b needs the actual runtime model_id
  the tester used (the static keys ARE in the registry; the runtime
  lookup must be a different ID shape).

## [0.1.37] — 2026-05-07

**CRITICAL: Bedrock silent-wedge fix.** Surfaced by the v0.1.35 deep-test
session — `efterlev report run` against a Bedrock backend hung 24 minutes
at 0% CPU on a `ReadTimeoutError` mid-retry. Only SIGINT broke it. This
release fixes the wedge and adds visible progress so the failure mode is
no longer silent.

### Root cause

The pre-v0.1.37 retry loop had three reinforcing problems that compounded
into the wedge:

1. **`ReadTimeoutError` consumed the full retry budget** (`_MAX_RETRIES=3`)
   despite each ReadTimeout burning ~600s of `read_timeout` wall time.
   Worst case: 3 × 600s = 30 min of stalled reads on a single agent call.
2. **No total wall-clock cap** on the retry+fallback sequence, so multiple
   ReadTimeouts could compound to 30+ min silently.
3. **Progress messages emitted only via `log.warning`** — invisible to
   the user when the project doesn't configure logging (it doesn't).

### Fixed

- **`_MAX_READ_TIMEOUT_RETRIES = 1`** — ReadTimeoutError now caps at
  1 retry (~20 min worst case for the ReadTimeout path; 1 retry rarely
  recovers a stuck connection but burns another 600s). Other retryable
  errors (Throttling, 5xx, ConnectTimeout) keep the full
  `_MAX_RETRIES=3` budget.
- **`_MAX_TOTAL_WALL_SECONDS = 1200`** — hard 20-min wall-clock ceiling
  on the entire `complete()` call sequence. Pre-flight check at each
  retry iteration; aborts with a clear `AgentError` when the deadline
  is exceeded.
- **`_emit_progress(message)`** — writes `[bedrock] …` lines directly
  to stderr with explicit flush, so the user sees retry attempts +
  wall-clock budget consumption + abort decisions even when logging
  is unconfigured.
- **`_is_read_timeout(error)`** — new classifier helper (alongside the
  existing `_is_retryable_bedrock`) so callers can apply distinct retry
  budgets per error class.
- The bottom-of-`complete()` `assert last_error is not None` is replaced
  with an explicit `AgentError` for the wall-clock-exhausted-at-entry
  case (where no converse call ever ran).

### Added

- 5 new tests in `tests/test_bedrock_client.py`:
  - `test_v0_1_37_read_timeout_capped_at_one_retry` — A/B-style lock
    that fails the suite if a future edit lets ReadTimeout consume the
    full retry budget.
  - `test_v0_1_37_progress_messages_visible_on_retry` — verifies
    stderr `[bedrock]` lines appear on retry.
  - `test_v0_1_37_wall_clock_budget_caps_total_time` — uses
    `monkeypatch.setattr(time, "monotonic", …)` to simulate a clock
    jump past the 1200s deadline; verifies the loop bails with no
    further converse calls.
  - `test_v0_1_37_is_read_timeout_classifier` — pins the
    ReadTimeoutError vs other-retryable distinction.
  - `test_v0_1_37_non_read_timeout_uses_full_retry_budget` — locks
    that the ReadTimeout cap is targeted, not a global retry-budget
    reduction.

### Internal

- Test count: 1226 → 1231 (+5).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.

### Cross-references

- v0.1.35 deep-test session report (S4a finding): the credibility-killer
  "give it to a compliance team unattended" failure mode this fixes.
- CLAUDE.md "Known gotchas" — Bedrock client retry behavior section.
  Pre-v0.1.37 the `read_timeout=600` + `retries={"max_attempts": 1}`
  config was correct, but the OUR retry loop on top of it was the
  amplifier. v0.1.37 keeps the boto config; tightens the OUR loop.

## [0.1.36] — 2026-05-07

**Bedrock inference-profile probe correctness fix** — surfaced by a real
fresh-install test session against an account with both Opus 4.0 and
Opus 4.1 enabled. v0.1.0–v0.1.35 picked Opus 4.0 (older) over Opus 4.1
(newer) at `efterlev init`, because the lexical sort treats
`claude-opus-4-20250514` as outranking `claude-opus-4-1-20250805`
(at position 14, `2` > `1`). Plus the probe didn't filter by region
prefix at all — meaning it could pick `eu.*` / `apac.*` / `global.*`
profiles over US ones in some accounts.

### Fixed

- **Version-aware sort.** The probe now parses
  `(major, minor, date_int, rev)` tuples from each candidate
  inference-profile ID and ranks by tuple compare. Both modern
  (`claude-opus-4-7-v1:0`, `claude-opus-4-1-20250805-v1:0`) and legacy
  (`claude-3-opus-…`, `claude-3-5-sonnet-…`, `claude-3-7-sonnet-…`)
  shapes parse correctly. The negative-lookahead `(?=-|$)` on the
  minor-version capture prevents the regex from greedy-matching the
  first 1–2 digits of an 8-digit date as `minor`.
- **`us.*` cross-region prefix filter.** The probe now excludes
  `eu.*` / `apac.*` / `global.*` inference profiles. Rationale: FedRAMP-
  bound deployments shouldn't egress federal customer data outside
  the US authorization boundary; `global.*` specifically forfeits the
  US-region geographic guarantee some FedRAMP boundary documentation
  depends on. Users who explicitly want a non-US profile can pass
  `--llm-model=<arn>` to override.
- **Belt-and-suspenders Anthropic check.** Where the inference-profile
  response includes the underlying model ARNs, the probe now confirms
  at least one is from Anthropic. Some accounts have third-party
  profiles whose IDs collide with Anthropic family names.

### Added

- `_probe_bedrock_for_family(region, family)` — a generic helper
  supporting `opus`, `sonnet`, and `haiku` families. Today only Opus
  is wired to the init probe; the helper is ready for the Tier 2
  per-agent Bedrock-default candidate (each agent picks its own
  US cross-region profile at runtime).
- `_parse_bedrock_anthropic_version` — parses a sortable version
  tuple from a Bedrock inference-profile ID. Handles 11+ shapes of
  Anthropic-on-Bedrock IDs in production today.
- `tests/test_bedrock_probe.py` — 24 tests covering parser correctness
  on every shipped Anthropic-on-Bedrock ID shape, ranking sanity (e.g.
  Opus 4.7 > 4.1 > 4.0 > 3), the v0.1.36 failure-mode lock (an
  account with both Opus 4.0 and 4.1 must pick 4.1), and the
  `us.*`-filter (eu/apac/global excluded).

### Internal

- Test count: 1202 → 1226 (+24).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.

### Cross-references

- CLAUDE.md "Known gotchas" — updated Bedrock-probe entry now
  documents the `us.*` filter + version-aware sort.
- The hardcoded `DEFAULT_BEDROCK_MODEL` fallback
  (`us.anthropic.claude-opus-4-7-v1:0`) is unchanged; the probe
  remains a best-effort discovery layer that picks whatever the
  user's account actually has access to right now.

## [0.1.35] — 2026-05-07

**Tier 1 follow-up: 2 manifest templates close the v0.1.34 design's
projected outcome.** Per DECISIONS 2026-05-07 "Tier 1 #4 design"
the gap analysis classified 24 KSIs `procedural-only`; 22 already
had v0.1.21 starter-pack templates, but 2 were missing
(`KSI-MLA-RVL` log review + `KSI-SVC-EIS` security improvement
program). This release adds those two templates, expanding the
starter pack from 24 → 26.

### Added

- **2 hand-authored templates** in `src/efterlev/manifest_templates/`:
  - `KSI-MLA-RVL.template.yml` — log review cadence, named
    reviewer / rotation, evidence-of-review artifacts, escalation
    rubric.
  - `KSI-SVC-EIS.template.yml` — security improvement program:
    evaluation surfaces, triage cadence, severity-based SLAs,
    metrics, program ownership.

  Each carries a hand-authored `_template_help` block with
  description + 5–6 questions + DRAFT example_statement matching
  the v0.1.21 starter-pack pattern. Generated by re-running
  `scripts/generate_starter_pack.py` after appending the two
  KSI entries to its `KSI_HELP` dict (the source of truth).

- `SELECTION.md` regenerated to document the 2 new entries
  alongside the original 24.

### Changed

- `tests/test_manifest_starter_pack.py`:
  - `test_starter_pack_has_24_templates` → renamed
    `test_starter_pack_has_26_templates`; assertion bumped to 26.
  - CLI-integration test stderr-message + count assertions
    bumped 24 → 26.
- `src/efterlev/cli/main.py`: `--starter-pack` help text
  "(24 KSIs covering ...)" → "(26 KSIs covering ...)".

### Internal

- Test count: 1202 → 1202 (no test-count delta — existing
  manifest tests just have updated expectations).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- Manifest templates: 24 → 26.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — the design entry that promised these 2 templates as
  follow-ups. **With v0.1.35 the design entry's projected
  outcome is fully delivered.**
- DECISIONS 2026-05-06 "Tier 1 #3 design: Evidence Manifest
  starter pack" — the parent design that established the
  generator pattern + `_template_help` shape these new templates
  follow.

### Tier 1 fully complete after this release

- ~~#1 quickstart~~ (v0.1.18)
- ~~#2a cost summary~~ (v0.1.19)
- ~~#2b --dry-run / --dump-prompt~~ (v0.1.20)
- ~~#3 manifest starter pack~~ (v0.1.21, expanded v0.1.35)
- ~~#4 detector gap analysis~~ (v0.1.28–v0.1.34, manifest
  follow-ups v0.1.35)

Next: Tier 2 candidates per `CLAUDE.md` "Path forward" — each
gets its own DECISIONS entry when promoted.

## [0.1.34] — 2026-05-07

**Tier 1 #4 detector backlog complete (6/6).** Final detector ships
KSI-PIY-RSD "Reviewing Security in the SDLC" — the GitHub-workflow-
based SDLC security gates detector.

### Added

- **`github.piy_sdlc_security_gates` detector.** Reads
  `.github/workflows/*.yml` for the canonical SDLC security-gate
  patterns:
  - **CodeQL:** `uses: github/codeql-action/(init|analyze|autobuild)@...`
  - **Dependency review:** `uses: actions/dependency-review-action@...`
  - **Secret scanning:** TruffleHog or Gitleaks action

  Emits per-workflow Evidence: `gate_state="configured"` with
  `gates_present=[...]` listing which subset is found, or
  `gate_state="absent"` with a gap message.

  Maps to KSI-PIY-RSD + SA-3 (System Development Life Cycle) +
  SA-8 (Security and Privacy Engineering Principles). KSI-PIY-RSD
  classified `partial`; this detector covers the configured-gate
  half (the procedural review cadence is manifest territory).

- 6 fixtures (4 should_match including a combined-gates fixture +
  2 should_not_match) + 9 unit tests covering each gate, the
  combined-gates path, the absent path, and contract pins
  (mappings, source category, state lock, gate-label allowlist).

### Changed

- `tests/test_cli.py` expected count: 50 → 51, KSI-mapped: 43 → 44.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 50 → 51. The v0.1.29
  source-level pin caught the drift at PR time (fifth release in
  a row — the lock has now caught EVERY detector PR).

### Internal

- Test count: 1193 → 1202 (+9). Detector count: 50 → 51.
  Source files: 188 → 190. KSI-mapped: 43 → 44.
  KSIs covered: 35 → 36.

### Tier 1 #4 backlog summary

All 6 detectors from DECISIONS 2026-05-07 "Tier 1 #4 design"
shipped:

1. v0.1.28 — `aws.cna_optimizing_for_availability` → KSI-CNA-OFA
2. v0.1.30 — `aws.mla_log_access_least_privilege` → KSI-MLA-ALA
3. v0.1.31 — `aws.cna_dos_protection` → KSI-CNA-RVP
4. v0.1.32 — `aws.svc_at_rest_encryption_coverage` → KSI-SVC-PRR
5. v0.1.33 — `aws.rpl_backup_configured` → KSI-RPL-ARP
6. **v0.1.34** (this) — `github.piy_sdlc_security_gates` → KSI-PIY-RSD

Coverage moved from 30/60 KSIs at the design entry to 36/60 — exactly
matching the design's projected outcome. Per the design entry, 2
manifest templates (`KSI-MLA-RVL`, `KSI-SVC-EIS`) are still pending
when convenient.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #6 of 6 (FINAL).
- Tier 1 of the v0.1.18+ originally-planned UX sequence is now
  fully complete (#1 quickstart, #2a cost summary, #2b --dry-run,
  #3 starter pack, #4 detector gap analysis).

## [0.1.33] — 2026-05-07

Tier 1 #4 detector backlog item #5 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design", ships KSI-RPL-ARP "Aligning Recovery Plan" —
AWS Backup orchestration + cross-region replication.

### Added

- **`aws.rpl_backup_configured` detector.** Reads Terraform for
  recovery-plan orchestration primitives:
  - `aws_backup_plan` — counts rules + cross-region copy_actions.
  - `aws_backup_vault` — emits `cmk=true` when `kms_key_arn` set.
  - `aws_backup_selection` — backup-coverage signal.
  - `aws_db_instance_automated_backups_replication` — RDS
    automated-backups cross-region replication.

  Distinct from `aws.backup_retention_configured` (KSI-RPL-ABO,
  CP-9, RDS retention + S3 versioning); this detector covers the
  orchestration + alternate-site half. Test
  `test_detector_does_not_overlap_with_backup_retention_configured`
  pins the no-overlap contract by running both detectors against
  the same fixture.

- 5 fixtures (4 should_match, 1 should_not_match) + 9 unit tests
  covering each pattern, the no-overlap pin, positive-only
  state lock, and contract pins.

### Changed

- `tests/test_cli.py` expected count: 49 → 50, KSI-mapped: 42 → 43.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 49 → 50. The v0.1.29
  source-level pin caught the drift at PR time (fourth release
  in a row).

### Internal

- Test count: 1184 → 1193 (+9). Detector count: 49 → 50.
  Source files: 186 → 188. KSI-mapped: 42 → 43.
  KSIs covered: 34 → 35.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #5 of 6.
- 1 detector remaining on the backlog: `github.piy_sdlc_security_gates`.

## [0.1.32] — 2026-05-07

Tier 1 #4 detector backlog item #4 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design", ships KSI-SVC-PRR "Preventing Residual Risk" —
encryption-at-rest coverage on data stores not covered by the
existing per-service detectors.

### Added

- **`aws.svc_at_rest_encryption_coverage` detector.** Reads
  Terraform for at-rest encryption configuration on the data
  stores not in the existing detector inventory:
  - `aws_dynamodb_table` — `server_side_encryption.enabled`
    (AWS default is on; explicit-false is the negative case).
  - `aws_efs_file_system` — `encrypted`
  - `aws_elasticache_cluster` — `at_rest_encryption_enabled`
  - `aws_elasticache_replication_group` — same flag
  - `aws_rds_cluster` (Aurora) — `storage_encrypted`
  - `aws_neptune_cluster` — `storage_encrypted`
  - `aws_docdb_cluster` (DocumentDB) — `storage_encrypted`

  Emits positive (`configured`, with `cmk=true` detail when a
  customer-managed KMS key is referenced) or negative (`absent`
  with a gap message) per resource.

- 7 fixtures (4 should_match, 3 should_not_match) + 9 unit tests
  covering each resource type, both encryption states, the no-
  resource path, and contract pins.

### Changed

- `tests/test_cli.py` expected count: 48 → 49, KSI-mapped: 41 → 42.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 48 → 49. The v0.1.29
  source-level pin caught the drift at PR time (third release
  in a row).

### Internal

- Test count: 1175 → 1184 (+9). Detector count: 48 → 49.
  Source files: 184 → 186. KSI-mapped: 41 → 42.
  KSIs covered: 33 → 34.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #4 of 6.
- 2 detectors remain on the backlog: `rpl_backup_configured`,
  `github.piy_sdlc_security_gates`.

## [0.1.31] — 2026-05-07

Tier 1 #4 detector backlog item #3 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design: detector gap analysis", ships KSI-CNA-RVP
"Reviewing Protections" — DoS-protection inventory.

### Added

- **`aws.cna_dos_protection` detector.** Reads Terraform for the
  IaC-declared DoS-protection primitives:
  - `aws_wafv2_web_acl` — modern WAF web ACL; counts rate-based
    statements in nested rule blocks.
  - `aws_wafv2_web_acl_association` — WAF attached to ALB /
    CloudFront / API Gateway (resource_arn target preserved).
  - `aws_waf_web_acl` — classic (v1) WAF, flagged distinctly so
    downstream agents can note the deprecated surface.
  - `aws_shield_protection` — Shield Advanced subscription.

  Only positive (configured) evidence is emitted — KSI-CNA-RVP is
  classified `partial`, where this detector covers the
  configured-state half and the procedural review cadence
  ("persistently review the effectiveness") is manifest territory.
  Absence of WAF/Shield isn't a gap per se; the Gap Agent reasons
  about exposure-justified gaps.

- 5 fixtures (4 should_match, 1 should_not_match) + 8 unit tests
  covering each pattern, the no-evidence case, and contract pins
  (mappings, evidence schema, positive-only state lock).

### Changed

- `tests/test_cli.py` expected count: 47 → 48, KSI-mapped: 40 → 41.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 47 → 48. The v0.1.29
  source-level pin caught the drift at PR time.

### Internal

- Test count: 1167 → 1175 (+8). Detector count: 47 → 48.
  Source files: 182 → 184. KSI-mapped: 40 → 41.
  KSIs covered: 32 → 33.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #3 of 6.
- 3 detectors remain on the Tier 1 #4 backlog:
  `svc_at_rest_encryption_coverage`, `rpl_backup_configured`,
  `github.piy_sdlc_security_gates`.

## [0.1.30] — 2026-05-07

Tier 1 #4 detector backlog item #2 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design: detector gap analysis", ships the second
`evidenceable-via-iac` detector: KSI-MLA-ALA "Authorizing Log
Access" — least-privilege patterns on log data.

### Added

- **`aws.mla_log_access_least_privilege` detector.** Reads
  Terraform for two surfaces of log-data access control:
  - `aws_cloudwatch_log_resource_policy` — explicit log-group
    resource policies (positive: an admin has governed access).
  - IAM policies (`aws_iam_policy` + `aws_iam_role_policy` +
    `aws_iam_user_policy` + `aws_iam_group_policy`) with `logs:`
    actions: classified `scoped` (specific log group ARN) or
    `overly_permissive` (wildcard `logs:*` on `Resource: "*"`).
  - Resolves both literal-JSON policies AND
    `${data.aws_iam_policy_document.NAME.json}` references through
    the data-source registry (same pattern as
    `aws.mfa_required_on_iam_policies`).

- 6 fixtures (3 should_match, 3 should_not_match) + 9 unit tests
  covering the configured / scoped / overly_permissive paths,
  literal-JSON + data-source-reference resolution, the no-evidence
  case for IAM policies that don't touch log data, and contract
  pins (mappings, evidence schema, pattern enum).

### Changed

- `tests/test_cli.py::test_detectors_list_lists_all_thirty_detectors`
  expected count: 46 → 47, KSI-mapped: 39 → 40.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 46 → 47. The
  v0.1.29 source-level pin
  (`tests/test_triage_constant_alignment.py`) caught this drift
  at PR time — the new lock is doing its job.

### Internal

- Test count: 1158 → 1167 (+9). Detector count: 46 → 47.
  Source files: 180 → 182. KSI-mapped detectors: 39 → 40.
  KSIs covered by detectors: 31 → 32.

### Known duplication (will refactor when 3rd IAM-policy
content detector lands)

The IAM-policy-document parsing (literal JSON + data-source
reference resolution) is now duplicated between
`aws.mfa_required_on_iam_policies` and
`aws.mla_log_access_least_privilege`. Refactor candidate:
`efterlev.iam.policy_doc` shared helper. Looking at the Tier 1
#4 backlog, neither `cna_dos_protection` nor
`svc_at_rest_encryption_coverage` nor `rpl_backup_configured`
nor `github.piy_sdlc_security_gates` need IAM-policy-content
parsing — so the duplication ends here. If a future detector
needs this, refactor at that PR.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — the design entry; this is item #2 of 6.
- 4 detectors remain on the Tier 1 #4 backlog: `cna_dos_protection`,
  `svc_at_rest_encryption_coverage`, `rpl_backup_configured`,
  `github.piy_sdlc_security_gates`.

## [0.1.29] — 2026-05-07

Hotfix for v0.1.28's auto-triage T3 FAIL. v0.1.28 added detector
#46 (`aws.cna_optimizing_for_availability`) but missed bumping
`EXPECTED_DETECTORS=45 → 46` in `scripts/triage.sh`. Auto-triage
ran against the published v0.1.28 wheel, found 46 detectors,
expected 45, and reported T3 FAIL on the v0.1.28 release page.

Fix is mechanical (one number); the structural lock makes the
mistake un-recurrable.

### Fixed

- `scripts/triage.sh`: `EXPECTED_DETECTORS=45 → 46`. Comment
  updated to reference the new test that locks this against
  drift.

### Added

- `tests/test_triage_constant_alignment.py`: scans
  `scripts/triage.sh` for the `EXPECTED_DETECTORS=N` line and
  asserts N equals `len(get_registry())`. **Future detector
  PRs that forget to bump the constant fail the suite at
  PR review** — no Windows runner needed, no release needed.
  Same source-level pin pattern as the v0.1.23-v0.1.27 cascade
  fixes.

### Internal

- Test count: 1157 → 1158 (+1).
- Detector count unchanged at 46.

### Cross-references

- v0.1.28's release page T3 FAIL: <https://github.com/efterlev/efterlev/releases/tag/v0.1.28>
- DECISIONS 2026-05-07 "Process improvements from v0.1.22-v0.1.27 cascade" — same source-level-pin pattern that drove this lock.

## [0.1.28] — 2026-05-07

Tier 1 #4 detector backlog item #1 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design: detector gap analysis", ships the first
`evidenceable-via-iac` detector from the gap analysis: KSI-CNA-OFA
"Optimizing for Availability."

### Added

- **`aws.cna_optimizing_for_availability` detector.** Reads
  Terraform for the common availability primitives that contribute
  to KSI-CNA-OFA's "high availability and rapid recovery" outcome:
  - `aws_db_instance` with `multi_az = true` (positive) or read-
    replica via `replicate_source_db` (positive); else negative.
  - `aws_rds_cluster` with explicit `availability_zones` (≥2) or
    `global_cluster_identifier`.
  - `aws_autoscaling_group` with ≥2 subnets in
    `vpc_zone_identifier` (positive) or 1 subnet (negative).
  - `aws_s3_bucket_replication_configuration` (positive).
  - `aws_ecs_service` with `placement_constraints.type = "spread"`
    on `availability-zone`.

- 9 fixtures (6 should_match, 3 should_not_match) + 11 unit tests
  covering each pattern, the negative-evidence paths, and contract
  pins (`controls=[]` declared explicitly; `availability_state ∈
  {configured, absent}` schema lock).

### Changed

- **`@detector` decorator: relaxed `controls` non-empty
  requirement.** Pre-v0.1.28 the decorator required at least one
  800-53 control, which forbade detectors for KSIs FRMR doesn't map
  to any 800-53 control (KSI-CNA-OFA's `controls` field is `[]` in
  FRMR 0.9.43-beta). New rule: at least one of `ksis` OR `controls`
  must be non-empty (the detector must evidence SOMETHING). The
  symmetric inverse case (`ksis=[]` with non-empty `controls`)
  was already permitted per DECISIONS 2026-04-21 (e.g. SC-28 has no
  KSI mapping in FRMR). Tests in `test_detector_contract.py`
  updated to lock both directions.

### Internal

- Test count: 1145 → 1157 (+12). Detector count: 45 → 46. Source
  files: 178 → 180. KSI-mapped detectors: 38 → 39. KSIs covered
  by detectors: 30 → 31 (closing the gap surfaced in DECISIONS
  2026-05-07 doc-drift note).

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — full classification of the 30 uncovered KSIs and the 6-detector
  backlog this is item #1 of.
- 5 detectors remain on the Tier 1 #4 backlog: `mla_log_access_least_privilege`
  (#2), `cna_dos_protection` (#3), `svc_at_rest_encryption_coverage`
  (#4), `rpl_backup_configured` (#5), `github.piy_sdlc_security_gates`
  (#6). Each lands as its own PR per the working agreement.

## [0.1.27] — 2026-05-07

Sixth Windows-cascade layer. v0.1.26's first release-smoke run on
Windows-2022 hit `UnicodeEncodeError: 'charmap' codec can't encode
character '⚠' in position 2`. Root cause: Windows console
default encoding is cp1252; cp1252 can't encode U+26A0 (WARNING
SIGN ⚠) which `efterlev scan` uses in 4 user-facing scan-result
warning lines. Any `efterlev scan` invocation that triggers a
warning path crashed on Windows with this error.

### Fixed

- `src/efterlev/cli/main.py`:
  - At CLI import time, on Windows, reconfigure `sys.stdout` and
    `sys.stderr` to UTF-8. POSIX is unaffected (default already
    utf-8). Uses `TextIOWrapper.reconfigure(encoding="utf-8")`
    (Python 3.7+); `hasattr` guard handles redirected stdio in
    subprocess capture cases.
  - In-file comment block explains the bug + fix shape.

### Added

- `tests/test_cli_windows_stdio.py` (2 tests):
  - `test_cli_main_reconfigures_stdio_to_utf8_on_windows` —
    source-level pin (platform-independent). Asserts
    `if sys.platform == "win32":` block + both
    `sys.stdout.reconfigure(encoding="utf-8")` and
    `sys.stderr.reconfigure(encoding="utf-8")` calls are present.
  - `test_warning_emoji_present_in_cli_output_paths` — sanity
    check that the U+26A0 character is still used; documents
    the use case for the reconfigure block.

### Internal

- Test count: 1143 → 1145 (+2).
- Source files unchanged at 178; detector count unchanged at 45.

### Cumulative cascade context (v0.1.22 → v0.1.27)

- v0.1.22: assertion script (matrix could finally measure)
- v0.1.23: Windows fcntl + docker-ghcr `?mode=ro`
- v0.1.24: WAL-mode for docker-ghcr (`&immutable=1`)
- v0.1.25: Windows charmap encoding (FRMR loader read)
- v0.1.26: Windows msvcrt.locking O_APPEND byte-range
- v0.1.27 (this): Windows charmap encoding (CLI stdout/stderr write)

The v0.1.25 fix handled READING UTF-8 from files; v0.1.27
handles WRITING UTF-8 to console. Two distinct categories of
encoding bug, both surfaced as the matrix progressed past
prior layers.

### Cross-references

- v0.1.26's Windows-2022 cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25498326520/job/74824004090>
  — exact UnicodeEncodeError trace.
- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.27 Windows stdio utf-8 follow-on" — root cause +
  cascade summary.

## [0.1.26] — 2026-05-07

Windows `msvcrt.locking` byte-range bug. v0.1.25's first
release-smoke run on Windows-2022 hit
`PermissionError: [Errno 13]` from `_flock_release(fd)` at
`receipts.py:116`. Root cause: `msvcrt.locking()` is BYTE-RANGE
based (unlike POSIX `fcntl.flock` which locks the whole file).
The `O_APPEND` open mode advances the file position after each
write, so by the time the unlock call runs, the position is at
NEW_EOF and the unlock targets a different byte range than the
original lock — `msvcrt.locking` raises PermissionError.

### Fixed

- `src/efterlev/provenance/receipts.py`:
  - `_flock_exclusive` and `_flock_release` (Windows branch) now
    `os.lseek(fd, 0, os.SEEK_SET)` before each `msvcrt.locking`
    call. Both lock and unlock target byte range `[0, 1)`. With
    `O_APPEND` set on the fd, actual writes still go to EOF
    regardless of file position; the byte-0 lock is purely
    advisory and no real data ever gets written at byte 0.
  - In-file comment block explains the bug + fix shape.

### Added

- `tests/test_receipts_locking.py::test_windows_lock_helpers_lseek_to_byte_zero_before_lock_and_unlock`
  — source-level pin (platform-independent): reads `receipts.py`,
  finds the Windows branch, asserts both helpers `lseek(fd, 0)`
  before their `msvcrt.locking` call. A regression that drops
  either lseek would re-break Windows; this test catches it
  on macOS / Linux dev laptops, no Windows runner needed.
  A/B-verified before commit: removing either lseek line fails
  this test immediately.

### Internal

- Test count: 1142 → 1143 (+1).
- Source files unchanged at 178; detector count unchanged at 45.

### Cumulative cascade context (v0.1.22 → v0.1.26)

The silent-matrix gap had been masking a *cascade* of platform-
specific bugs that surfaced one-by-one as each prior bug was
fixed. v0.1.26 closes the fifth and (we believe) last layer:

- v0.1.22: assertion script (couldn't measure anything)
- v0.1.23: Windows `import fcntl` (import-time crash) +
  docker-ghcr `?mode=ro` (sqlite default mode)
- v0.1.24: WAL-mode case for docker-ghcr
  (`?mode=ro&immutable=1`)
- v0.1.25: Windows charmap encoding in FRMR loader
- v0.1.26 (this): Windows `msvcrt.locking` O_APPEND byte-range
  semantics

Each layer was hidden by the prior one because Windows / docker-
ghcr cells crashed early. With v0.1.26, the cascade should be
exhausted and v0.1.26's release-smoke matrix should land fully
green for the first time since the silent-matrix was opened.

### Cross-references

- v0.1.25's Windows-2022 cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25496572508/job/74817835258>
  — exact PermissionError trace.
- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.26 Windows msvcrt.locking follow-on" — root-cause +
  cumulative cascade summary.

## [0.1.25] — 2026-05-07

Windows `UnicodeDecodeError` in the FRMR loader. v0.1.24's first
release-smoke run on Windows-2022 hit
`UnicodeDecodeError: 'charmap' codec can't decode byte 0x9d in
position 214643` because `Path.open()` defaults to the OS-default
encoding (cp1252 on Windows) and the FRMR catalog contains UTF-8
sequences (en-dashes, smart quotes, em-dashes in requirement
text). The bug was latent on every Windows install since the FRMR
catalog grew non-ASCII content but was masked by the prior
`import fcntl` ImportError (v0.1.23 fix) which crashed Windows at
import time before runtime could reach the loader.

### Fixed

- `src/efterlev/frmr/loader.py`:
  - Both `path.open()` calls (catalog + schema) now pass
    `encoding="utf-8"` explicitly. In-file comment block explains
    why the OS-default fallback isn't safe.

### Added

- `tests/test_frmr_loader.py::test_loader_passes_explicit_utf8_encoding`
  — synthesizes a minimal catalog with non-ASCII chars (en-dash,
  smart quote, em-dash matching the vendored content shape) and
  loads it. Behavioral lock against accidental reversion of the
  encoding parameter on POSIX (where the test would still pass
  by platform default but would fail on Windows in CI).
- `tests/test_frmr_loader.py::test_loader_source_explicitly_passes_utf8_to_open`
  — source-level pin: reads `frmr/loader.py` and asserts both
  `path.open(encoding="utf-8")` and `schema_path.open(encoding="utf-8")`
  are present. Fails the suite immediately if a future edit drops
  `encoding=` from either call.
- `tests/test_frmr_loader.py::test_vendored_frmr_loads_with_expected_shape`
  — extracted from the original
  `test_loads_vendored_frmr_without_schema` so the new
  encoding-tests can sit between smoke-load and shape-assertions
  without disturbing them.

### Internal

- Test count: 1139 → 1142 (+3 in `test_frmr_loader.py`).
- Source files unchanged at 178; detector count unchanged at 45.

### Cross-references

- v0.1.24's Windows-2022 cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25495339151/job/74813517916>
  — exact `UnicodeDecodeError` trace.
- DECISIONS 2026-05-07 "release-smoke matrix visibility: v0.1.25
  Windows utf-8 follow-on" — root cause + lessons learned about
  the cascade of Windows bugs the silent-matrix had been masking.

## [0.1.24] — 2026-05-07

The actual fix for the docker-ghcr readonly-DB matrix cell.
v0.1.23 changed `tests/smoke/assert.py` to open the SQLite store
with `?mode=ro` — but that's not enough when the store is in WAL
mode (the prod schema enables WAL via
`PRAGMA journal_mode=WAL` at `src/efterlev/provenance/store.py:87`).
Even with `?mode=ro`, SQLite tries to open a journal file in the
DB's directory during a SELECT to handle hot-journal recovery; if
the directory is read-only (matches docker-ghcr's root-owned
mounted volume), this fails with "attempt to write a readonly
database". Caught by v0.1.23's own first release-smoke run on
docker-ghcr cells.

`&immutable=1` tells SQLite the DB is on read-only media and
skips ALL write-path operations including journal opens. v0.1.24
adds it; the docker-ghcr cells should now pass.

### Fixed

- `tests/smoke/assert.py` — open the store via
  `sqlite3.connect(f"file:{db_path}?mode=ro&immutable=1", uri=True)`.
  In-file comment block explains why `?mode=ro` alone wasn't
  enough.

### Added (test discipline)

- `tests/test_smoke_assert.py::test_assert_passes_against_wal_mode_readonly_dir`
  — strengthens the v0.1.23 test by reproducing the prod failure
  mode exactly: WAL-mode SQLite store + chmod readonly on BOTH
  the DB file and the directory. Without `&immutable=1` the test
  fails with the exact prod error message ("attempt to write a
  readonly database"). A/B-verified before commit. The v0.1.23
  test
  (`test_assert_passes_against_readonly_db`) used a non-WAL
  fixture and chmod on only the file, which passed under
  `?mode=ro` alone — the test's assumed scenario didn't match
  what prod actually was.
- `tests/test_smoke_assert.py::test_assert_uri_includes_immutable_flag`
  — source-level pin against accidental reversion to `?mode=ro`
  alone. If a future edit drops `immutable=1`, this test fails
  the suite immediately.

### Internal

- Test count: 1137 → 1139 (+2 in `test_smoke_assert.py`).
- The earlier v0.1.23 test
  `test_assert_passes_against_readonly_db` is kept (still useful
  as a sanity check on non-WAL fixtures).
- v0.1.23's `test_assert_passes_against_wal_mode_readonly_db`
  was renamed to `test_assert_passes_against_wal_mode_readonly_dir`
  with a strengthened body matching what actually reproduces the
  bug — chmod on the directory too, not just the file.

### Cross-references

- v0.1.23's docker-ghcr cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25473754617/job/74742740327>
  — shows the exact prod error message that v0.1.23's
  insufficient `?mode=ro` produced.
- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.23 follow-on" — v0.1.23 design context.
- `src/efterlev/provenance/store.py:87` — the
  `PRAGMA journal_mode=WAL` that drives the WAL-related half of
  this bug.

## [0.1.23] — 2026-05-07

CI follow-on + cross-platform repair. v0.1.22's matrix-assertion
fix to `release-smoke` made the matrix actually run far enough to
expose problems that were silently masked across every prior
release. Four bugs in one PR — all surfaced by v0.1.22's first
auto-triage + first matrix run that got past the assertion script:

1. **Workflow: T7 reported SKIP** ("no GH token in env") because
   `GITHUB_TOKEN` is not auto-injected into shell env in GH
   Actions — it has to be passed explicitly via `env:`.

2. **Workflow: triage fired against the wrong tag.** Within
   minutes of v0.1.22 landing, GitHub cancelled a 24h-old
   release-smoke run for v0.1.12; that cancellation fired the
   new `workflow_run` trigger with `head_branch=v0.1.12`,
   running triage against v0.1.12 (which fails current T-checks).
   v0.1.18–v0.1.21 still have queued release-smoke runs that
   would re-fire the same false trigger.

3. **Product: Windows-2022 cells failed `import fcntl`.**
   `src/efterlev/provenance/receipts.py:33` had an unconditional
   `import fcntl` (POSIX-only stdlib). Wheel was un-importable
   on Windows; every Windows install since fcntl was added to
   receipts.py was broken at import time. Masked by the silent
   matrix until v0.1.22's assertion fix let Windows cells run
   far enough to surface `ModuleNotFoundError: No module named
   'fcntl'`.

4. **Workflow: docker-ghcr cells failed "attempt to write a
   readonly database".** Container writes the SQLite store as
   root onto the mounted host volume; host's
   `sqlite3.connect()` defaults to read-write mode and tries to
   create a journal file, which fails on root-owned files.
   v0.1.22 surfaced the failure but didn't have the fix yet.

### Fixed

- `.github/workflows/post-release-triage.yml`:
  - Pass `GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}` into the
    "Run triage and capture report" step env. Without this, T7
    reports SKIP instead of querying the matrix conclusion API.
  - Tighten the trigger `if` gate to allowlist upstream
    conclusion `{success, failure}` only. Cancelled / skipped /
    timed_out events from stale runs no longer fire.
- `src/efterlev/provenance/receipts.py`:
  - Replace the unconditional `import fcntl` with platform-gated
    `_flock_exclusive` / `_flock_release` helpers. fcntl on
    POSIX, msvcrt on Windows. Both are stdlib; no new deps.
  - Wheel now imports cleanly on Windows.
- `tests/smoke/assert.py`:
  - Open the SQLite store in URI read-only mode
    (`file:<path>?mode=ro`). The assertion only counts rows; no
    writes needed. Bypasses the journal-file create path so
    docker-ghcr cells (root-owned DB on host) can pass.

### Added

- `tests/test_receipts_locking.py` (5 tests) — pin the cross-
  platform lock helpers + a regression test that fails the
  suite if `import fcntl` reappears at module top.
- `tests/test_smoke_assert.py::test_assert_passes_against_readonly_db`
  — chmod a fixture DB to 0o444 + verify the assertion still
  passes. Locks the URI-read-only fix against accidental
  reversion.

### Internal

- Test count: 1131 → 1137 (+6: 5 new in
  `test_receipts_locking.py` + 1 new in `test_smoke_assert.py`).
- Source files unchanged at 178; detector count unchanged at 45.

### Cross-references

- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.23 follow-on" — root-cause + design discussion for all
  four bugs and the bundled-PR rationale.
- v0.1.22's CHANGELOG + DECISIONS entries — prior context.
- `release-smoke` matrix at
  <https://github.com/efterlev/efterlev/actions/workflows/release-smoke.yml>
  — should land green on v0.1.23 across mac/win/linux/arm + both
  install methods. **This is the first release whose Release
  page is expected to show T1-T7 all PASS** with T7 reporting
  the actual matrix conclusion (not SKIP).

## [0.1.22] — 2026-05-07

CI repair + observability lift. release-smoke had been silently
failing across every matrix cell on v0.1.20 + v0.1.21 (and probably
earlier — these are the two cycles I checked back) without anyone
noticing: the workflow_run row in `gh run list` collapsed to a
single "queued" status while individual matrix jobs failed on a
stale assertion script. v0.1.22 fixes the assertion AND adds T7 to
the post-release-triage report so silent matrix failures cannot
recur.

### Fixed

- **`tests/smoke/assert.py`** — the post-install matrix assertion
  had two bugs that made it impossible to pass against a real
  install:
  - Wrong table name: `FROM records` → `FROM provenance_records`
    (actual table per `src/efterlev/provenance/store.py:32`). The
    `OperationalError: no such table: records` was caught by the
    bare `sqlite3.Error` handler and surfaced one line down in
    the FAILED list as "sqlite error querying store: no such
    table: records".
  - Wrong expectation: the script asserted `<store>/reports/`
    exists, but the smoke workflow runs `efterlev init` +
    `efterlev scan` only — never `efterlev report run`, which is
    what generates HTML reports. The `reports/` requirement was a
    category error against the workflow's actual command sequence
    and would have failed every matrix cell on v0.1.20 + v0.1.21
    even without the SQLite bug.

### Added

- **`tests/test_smoke_assert.py`** (11 tests) — unit-tests the
  smoke assertion against an in-memory fixture store. Locks the
  contract so this can't silently break again: happy path with
  seeded evidence passes, missing DB / missing store dir fails,
  empty `provenance_records` table fails with a clear message,
  presence of a `records` table without `provenance_records`
  also fails (no false-positive PASS path), reports/ dir is NOT
  required (the test specifically asserts the script passes
  against a store with no reports/ dir at all).

- **T7 release-smoke matrix** in `scripts/triage.sh` — surfaces
  the release-smoke matrix conclusion on the GitHub Release
  page, alongside the existing T1-T6 deterministic checks.
  Queries the GH Actions API for the release-smoke workflow run
  matching the tag and reports per-cell failure detail when red.
  PENDING is a valid status when triage fires before smoke
  completes; the workflow now reruns triage on release-smoke
  completion to repopulate.

- **`.github/workflows/post-release-triage.yml`** — added
  `release-smoke` to the `workflow_run` trigger list so triage
  reruns when the matrix finishes (~10 min after tag), repopulating
  T7 with real data after the initial release-container-triggered
  run (~4 min after tag) showed T7 PENDING. Added
  `actions: read` permission so triage can query the GH Actions
  API for matrix conclusion. Dropped the prior
  `conclusion == 'success'` gate: triage now fires regardless of
  upstream success/failure so the Release page surfaces actual
  state instead of staying blank when something went wrong.

### Internal

- Test count: 1120 → 1131 (+11 from the new
  `tests/test_smoke_assert.py`). Source files: unchanged at 178.
  Detector count: unchanged at 45.
- `scripts/triage.sh` phase numbering documented in the file
  header. PENDING gets a ⏳ marker in the Release table.

### Cross-references

- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  surfacing silent failures via T7" — full design rationale,
  alternatives considered (separate workflow vs. T7-in-triage),
  and the decision to make the GH Release page the single
  observable surface for release-quality data.
- LIMITATIONS.md "Lessons learned: silent matrix failures
  v0.1.20–v0.1.21" — a callout flagging the prior gap.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — Tier 1 #1–#3
  shipped; Tier 1 #4 (detector gap analysis) still on the
  roadmap. v0.1.22 is an unscheduled CI repair, not a Tier 1
  item.

## [0.1.21] — 2026-05-06

Tier 1 #3 of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #3 design"). Ships the Evidence Manifest
starter pack — the biggest single coverage lift available per
LIMITATIONS' "scanner + manifests can approach 80%+" claim. Closes
the procedural-KSI gap that detectors structurally can't reach.

### Added

- **`efterlev manifests init --starter-pack`** — new subcommand tree
  (`efterlev manifests`) for Evidence Manifest content management.
  When `--starter-pack` is set, copies 24 bundled
  `<KSI-ID>.template.yml` files + a `README.md` workflow guide + a
  `SELECTION.md` audit trail into `.efterlev/manifests/starter-pack/`.
  Subdir lands OUTSIDE the manifest loader's pickup glob — templates
  are physically present (the user can read, copy from, version-
  control them) but invisible to the attestation pipeline until
  explicitly moved to the parent `.efterlev/manifests/` dir.
  `--force` required to overwrite an existing subdir.

- **24 hand-authored manifest templates** under
  `src/efterlev/manifest_templates/`. Bundled in the wheel via
  `importlib.resources`. Selection criteria locked in DECISIONS
  2026-05-06: hybrid theme + control-family check produces 17 KSIs
  from the 3 entirely-procedural FRMR themes (AFR/CED/INR) + 7 from
  detector-covered themes whose mapped 800-53 controls are
  procedural-only families (PIY/CMT/RPL/SVC). Each template:
  - `ksi: KSI-XXX-XXX` + `name: "..."`
  - `_template_help.description` (2-3 sentences from FRMR + audit framing)
  - `_template_help.questions` (3-7 hand-authored questions per KSI)
  - `evidence[0]` attestation skeleton with explicit `DRAFT —`
    placeholders for `statement`, `attested_by`, `attested_at`,
    `reviewed_at`, `next_review`, `supporting_docs`
  - Inline DRAFT example showing realistic attestation shape

- **`scripts/generate_starter_pack.py`** — source of truth for the 24
  templates. Re-run when FRMR adds a new KSI matching the selection
  criteria, or when maintainer-curated `_template_help` content changes.

### Changed

- `efterlev.manifests.loader.discover_manifest_files` now skips
  `*.template.yml` files. Defense-in-depth: even if a user
  accidentally copies `KSI-XXX.template.yml` directly to
  `.efterlev/manifests/` without dropping the suffix, the loader
  excludes it from the attestation pipeline. One-line filter
  addition; behavior preserved for all real `*.yml` / `*.yaml`
  manifests.

- `LIMITATIONS.md` adds a Tier 1 #3 shipped marker; updated
  `next_review` recommendation in templates is "6-month cadence".

### Internal

- `tests/test_manifest_starter_pack.py` (11 tests) covers: 24-template
  count lock, README + SELECTION presence, every KSI ID exists in
  FRMR catalog, every template has ≥3 hand-authored questions, every
  fillable field carries a `DRAFT` placeholder, loader skip filter
  excludes `*.template.yml`, CLI happy path copies all templates,
  CLI refuses overwrite without `--force`, CLI overwrites cleanly
  with `--force`, CLI refuses without `--starter-pack` flag, CLI
  refuses against an uninitialized workspace.
- Test count: 1109 → 1120 (+11). Source files: 177 → 178
  (`manifest_templates/` package marker). CLI commands: 25 → 27
  (added `manifests` subcommand tree + `manifests init`).
- Wheel build verified to include all 24 `*.template.yml` files +
  README.md + SELECTION.md under `efterlev/manifest_templates/`.

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #3 design: Evidence Manifest starter
  pack" — full design rationale, selection criteria, alternatives
  considered, locked-not-open decisions per "never lazy" directive.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — this is Tier 1 #3.
  Tier 1 progress: #1 (quickstart, v0.1.18), #2a (cost summary,
  v0.1.19), #2b (--dry-run, v0.1.20), #3 (this) shipped; #4
  (detector gap analysis) remains.
- LIMITATIONS.md "scanner + manifests can approach 80%+" — what the
  starter pack enables in practice.
- `src/efterlev/manifest_templates/SELECTION.md` — per-KSI selection
  audit trail.

## [0.1.20] — 2026-05-06

Tier 1 #2b of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #2b design"). Adds `--dry-run` and
`--dump-prompt PATH` to every agent command — the audit-credibility
primitive a 3PAO needs to verify exactly what the LLM was sent.
Pairs with v0.1.19's end-of-run cost summary to complete the
"cost + prompt visibility" Tier 1 #2 work.

### Added

- **`--dry-run` and `--dump-prompt PATH` flags on `efterlev agent
  {gap, document, remediate}`.** When set, the command builds every
  assembled prompt the agent would send, surfaces them as a JSON array
  of literal Anthropic API request envelopes (model + system + messages
  + max_tokens), augmented with `_efterlev` metadata (per-prompt
  iteration index, label, token estimate, dollar cost estimate from
  v0.1.19's pricing table), and exits 0 without invoking the LLM. No
  network call, no Claim records written, no `receipts.log` lines —
  zero side effects on `.efterlev/`. Per-run nonced fences are present
  in every dumped prompt — exactly what Anthropic would have seen.
  Implementation via context-var pattern (matches `active_redaction_ledger`
  / `active_store`); `Agent._invoke_llm` checks
  `active_dry_run_session.get()` and short-circuits with a per-agent
  structurally-valid stub output. (DECISIONS 2026-05-06 "Tier 1 #2b
  design")

- **`--force` flag on `--dump-prompt PATH`.** Refuses to overwrite
  an existing PATH unless `--force` also passed. Standard CLI hygiene
  for the regulated context this command targets — clobbering an
  audit packet is a real harm. Initial design draft of this entry
  rejected `--force` as "friction without real benefit"; revised on
  re-reading per the maintainer's "never lazy" directive.

- **`scripts/triage.sh` T2 doctor-shape unchanged** but `efterlev
  agent {gap,document,remediate} --help` now lists the three new
  flags. Manual smoke after PR lands: `efterlev agent gap
  --target . --dry-run | jq '.[0]._efterlev'` shows the per-prompt
  metadata.

### Changed

- `Agent._invoke_llm` (in `efterlev.agents.base`) gained a
  `dry_run_label: str | None = None` parameter (used for the captured
  prompt's label field). Backwards-compatible default; existing
  callers unchanged.
- `ProvenanceStore.write_record` short-circuits early when a
  `DryRunSession` is active in the context var, returning a
  structurally-valid sentinel `ProvenanceRecord` without touching
  SQLite, the blob store, or `receipts.log`.
- Each agent class (`GapAgent`, `DocumentationAgent`,
  `RemediationAgent`) declares a `_dry_run_stub_output()` factory
  that returns an empty `output_model` instance. The base class's
  default raises if a subclass forgets to implement.
- LIMITATIONS.md adds Tier 1 #2b under "Aspirational / roadmap" as
  shipped at v0.1.20.

### Internal

- `tests/test_dry_run.py` (12 tests) covers session capture +
  serialization, context-var lifecycle, `_invoke_llm`
  short-circuit (asserted via a `FailIfCalledClient` stub),
  `ProvenanceStore.write_record` no-op contract (zero side effects
  on the workspace), CLI flag validation (`--force` requires
  `--dump-prompt`), end-to-end agent-gap dry-run via subprocess,
  `--dump-prompt` file-write semantics, overwrite refusal without
  `--force`, force-overwrite, and the "no new store rows" contract.
- Test count: 1097 → 1109 (+12). Source files: 176 → 177
  (`agents/dry_run.py`).
- The dry-run path is ready for v0.2's vendored Anthropic
  tokenizer follow-up: today the `_efterlev.token_estimate` is a
  4-chars-per-token approximation flagged honestly via the
  `token_estimate_method` field. When precision matters more than
  it does today (real customer feedback), swap in the official
  tokenizer; the surface is one function in `agents/dry_run.py`.

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #2b design" — full design rationale,
  alternatives considered, the "never lazy" revision note that drove
  the all-prompts / API-envelope / `--force` decisions.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — meta-decision; #2b
  closes the "cost + prompt visibility" pair.
- v0.1.19 cost summary (PR #144) — sister feature; together they
  give pre-run AND post-run cost visibility.

## [0.1.19] — 2026-05-06

Tier 1 #2a of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #2a design: end-of-run cost summary on
agent commands"). Adds per-run cost visibility to every agent command
without changing the agent API or scanner output.

### Added

- **End-of-run cost summary on `efterlev agent {gap, document,
  remediate}`.** Each command prints one line at the end of its
  success path:
  ```
  LLM cost: 38,201 in / 8,455 out tokens on claude-sonnet-4-6 (~$0.24)
  ```
  Sums tokens by model from `.efterlev/receipts.log` (filtered to
  this invocation's window via `started_at`), looks up pricing in
  `src/efterlev/llm/pricing.py`, prints. Bedrock backend appends
  `(via bedrock; AWS region pricing may differ)`. Unregistered
  models surface tokens-only with a `pricing for <model> not
  registered` hint instead of crashing. Multi-model runs (e.g. Opus
  → Sonnet fallback fired mid-run) sum correctly and use a short-name
  comma-joined display. Reads from receipts.log rather than collecting
  per-agent — no agent API change, the data is already captured.
  (DECISIONS 2026-05-06 "Tier 1 #2a design"; agents/cost_summary.py
  + llm/pricing.py + 3-line CLI hook in each agent command)

### Changed

- `LIMITATIONS.md` adds a new "Cost estimates are best-effort" note
  documenting the snapshot-pricing posture, Bedrock proxy caveat, and
  the unregistered-model fallback. Tier 1 #2a flips from
  "aspirational" to "shipped at v0.1.19" in the Aspirational/roadmap
  section.

### Internal

- `tests/test_cost_summary.py` (8 tests) covers single-model run,
  multi-model run, Bedrock suffix, unregistered-model fallback,
  mixed priced+unpriced run, started_at timestamp filter excluding
  prior-run entries, no-receipts-file case, no-LLM-entries case
  (StubLLMClient). `tests/test_pricing.py` (6 tests) locks the
  pricing-table API behavior independent of dollar amounts (which
  drift over time as Anthropic adjusts rates).
- Test count: 1083 → 1097 (+14). Source file count: 174 → 176
  (`pricing.py` + `cost_summary.py`).
- 2b (`--dry-run` / `--dump-prompt` flags) gets its own DECISIONS
  entry next, then implementation. Tier 1 sequence:
  1 (quickstart, v0.1.18) ✓ → 2a (cost summary, this) ✓ → 2b →
  3 (manifest starter pack) → 4 (detector gap analysis).

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #2a design" — full design rationale,
  open questions, alternatives considered.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — meta-decision sequencing.
- v0.1.9 token-usage telemetry — the data layer this presentation reads.

## [0.1.18] — 2026-05-06

Tier 1 #1 of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 0/1 sequencing"). Ships the first ICP-aligned
feature after the v0.1.16/17 auto-triage infrastructure landed:
**`efterlev quickstart`** — a one-command activation demo for the
ICP A day-one experience.

### Added

- **`efterlev quickstart`** lays down a bundled synthetic Terraform
  + Evidence Manifest fixture in a temp workspace under the
  platform-appropriate user cache dir (`~/Library/Caches/efterlev/`
  on macOS, `~/.cache/efterlev/` on Linux, `%LOCALAPPDATA%\efterlev\`
  on Windows via `platformdirs`), runs `init → scan → agent gap →
  agent document` end-to-end against it, and prints a 5-line summary
  with workspace path, scan stats, classification breakdown, and a
  next-steps line pointing at the user's own repo. Realistic wall
  time: 60–180s with `ANTHROPIC_API_KEY` set (~$0.30 on Sonnet);
  honors `EFTERLEV_E2E_MODEL` for backend/model override.
  (DECISIONS 2026-05-06 "Tier 1 #1 design"; cli/main.py +
  src/efterlev/quickstart/)

- **Graceful no-key degradation.** When `ANTHROPIC_API_KEY` is unset,
  the deterministic phases (init + scan) still run and produce real
  detector evidence; the agent stages skip with a clear "set the key
  and re-run for AI-driven KSI classification + draft attestation"
  hint. ICP A users without a Claude account yet get actionable output
  rather than a stack trace. The summary surfaces real scan stats
  (resources / evidence records / detectors fired) on this path.

- **`python -m efterlev` entry point** (`src/efterlev/__main__.py`).
  Lets `quickstart` shell out to the CLI without depending on the
  `efterlev` script being on PATH at the time the subprocess starts.
  No user-visible change for the standard pipx / uv-tool installs;
  the script-on-PATH invocation continues to work.

### Changed

- **Bundled fixture moved to `src/efterlev/quickstart/`** so
  `efterlev quickstart` and `scripts/e2e_smoke.py` share the same
  source of truth. Growing the fixture for new detector coverage
  in either consumer benefits both automatically. The CI E2E smoke
  gate continues to use the same fixture; no behavior change for
  the harness.

- **`platformdirs>=4.0,<5`** added to dependencies. Tiny dep with no
  transitives; same library pip / uv / ruff use for cross-platform
  cache-dir resolution.

### Internal

- 8 new regression tests in `tests/test_quickstart.py`: fixture
  shape lock; terraform-writer skips manifests; manifest-writer
  skips terraform; cache-root resolves under user HOME; scan-output
  parser extracts the right fields; gap-summary returns None on
  no-report path; e2e_smoke imports the same FIXTURE object as
  quickstart (asserts the shared-source refactor); end-to-end
  no-key path runs clean and produces the expected summary.
- Test count: 1075 → 1083. Source file count: 172 → 174 (added
  `__main__.py` + `quickstart/__init__.py`).

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #1 design: efterlev quickstart" —
  full design rationale, alternatives considered, scope of v0.1.18.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing for v0.1.18+
  post-auto-triage-landing" — the meta-decision sequencing this
  as Tier 1 #1.
- `CLAUDE.md` "Path forward (v0.1.18+)" — Tier 1 #1 entry.
- `LIMITATIONS.md` "Aspirational / roadmap" — Tier 1 #1 flips from
  "aspirational" to "shipped at v0.1.18" in the same PR.

## [0.1.17] — 2026-05-06

Triage-driven patch from the v0.1.16 first-of-kind auto-triage. Two
findings, both in the v0.1.16 triage infrastructure itself (not in the
v0.1.16 release artifacts, which are 4/4 cryptographically clean):

1. The `post-release-triage.yml` workflow used the default
   `sigstore/cosign-installer@v3` (cosign 2.5.2), which doesn't
   auto-discover OCI 1.1 referrer attestations. Pinned to cosign **2.6.3**
   (the latest 2.x; cosign 3.0.x can't be installed by the action because
   it dropped legacy `.sig` files for `.sigstore.json` bundles). Landed in
   PRs #136 + #137 ahead of v0.1.17.
2. `scripts/triage.sh`'s T6 ("cosign tree visibility") was a redundant
   lightweight inventory check that produced false-negatives on cosign
   2.6.x — `cosign tree` doesn't enumerate OCI 1.1 referrer attestations
   even when they're present. T4 (`verify-release.sh`) already
   cryptographically verifies both attestation presence and validity via
   `cosign verify-attestation --type slsaprovenance1`. **v0.1.17 drops T6.**

The auto-triage methodology is working as designed: caught the issue in
the first auto-triage run for v0.1.16, surfaced both findings, and
v0.1.17 closes them via the standard release loop. v0.1.16's GitHub
Release page has been updated with a clarifying note explaining the
T6 false-negative and pointing at v0.1.17 as the structural fix.

### Changed

- **`scripts/triage.sh` drops T6** ("cosign tree visibility"). The 6
  remaining phases (T1 install + version sanity, T2 doctor shape, T3
  detector count, T4 verify-release.sh, T5 container manifest, T6
  check-docs against tagged source — renumbered from T7) cover the
  release-correctness surface that produced findings F1–H1. T4's
  `cosign verify-attestation` is now the single canonical check for
  "is the SLSA attestation attached and valid" — no separate inventory
  check needed.

### Internal

- `verify-release.sh` example version bumped from v0.1.16 to v0.1.17.
- The `post-release-triage.yml` cosign 2.6.3 pin (PR #137) carries
  forward unchanged.
- v0.1.17 will be the second release with an auto-generated GH Release
  page. Expected outcome: 6/6 PASS, no findings, no manual notes
  required.

## [0.1.16] — 2026-05-06

Infrastructure release. Adds `scripts/triage.sh <tag>` — a deterministic,
zero-LLM post-release validator — and a workflow that runs it after every
tag publish, attaching the triage report as the GitHub Release notes body.
This codifies the manual triage methodology that surfaced findings F1–H1
across v0.1.12–v0.1.15 (each cut catching paper cuts the prior cut's fix
introduced) into automation that runs without human prompting. Side
benefit: auto-creates the GitHub Release pages that have been missing
since v0.1.5 (the team never wrote release notes manually).

No scanner-output behavior change. v0.1.15's 4/4 cryptographic
verification carries forward unchanged.

### Added

- **`scripts/triage.sh <tag>`** runs T1–T7 deterministically:
  - T1: pipx-install the published wheel from PyPI, confirm `--version`
  - T2: confirm `efterlev doctor` returns the expected 7-check shape
  - T3: confirm `efterlev detectors list` reports the expected count
  - T4: invoke `scripts/verify-release.sh` (4/4 PEP 740 + cosign + SLSA v1)
  - T5: confirm container manifest has linux/amd64 + linux/arm64 via
        the OCI registry API (no Docker daemon needed)
  - T6: confirm `cosign tree` shows signature + SLSA v1 attestation
  - T7: run `scripts/check-docs.py` against the tagged source

  Output: GitHub-Flavored Markdown report. Exit 0 = clean; exit 1 =
  findings. Runnable locally for ad-hoc triage of any prior tag.

- **`.github/workflows/post-release-triage.yml`** triggers on
  `release-container.yml` completion (the longer of the two release
  workflows). On the first run for a tag, creates the GitHub Release
  for that tag with the triage report as the body. On reruns
  (`workflow_dispatch`), edits the existing notes. Job exits non-zero
  when triage reports findings, so the Actions UI flags release-quality
  regressions visibly.

- **DECISIONS 2026-05-06** documents the architectural choice — why
  triage runs decoupled from `release-container.yml`, why the report
  attaches to the GH Release rather than a `docs/triage/` directory,
  and which alternatives were considered (full backfill, daily cron,
  external validation framework).

### Internal

- Triage script smoke-tested against v0.1.15 → 7/7 PASS; fail-path
  verified by injecting a synthetic detector-count mismatch (exit 1,
  finding surfaced in the report's Findings section).
- v0.1.16 will be the first release with an auto-generated GH Release
  page. The page body becomes the per-version triage landing page,
  giving 3PAOs and external auditors a documented post-publish
  validation trail without per-release manual effort.

## [0.1.15] — 2026-05-06

Triage-driven patch from the v0.1.14 deterministic validation. Closes the
single finding (H1): the v0.1.14 `install_uniqueness` doctor check walked
PATH only, which missed the dominant parallel-install footgun. Real
repro this session: `pipx install efterlev` venv at
`~/.local/pipx/venvs/efterlev/`, `uv tool install efterlev` venv at
`~/.local/share/uv/tools/efterlev/`, single PATH symlink at
`~/.local/bin/efterlev` pointing into the uv-tool venv. The user runs
`pipx upgrade efterlev`, sees "upgraded", but `efterlev --version`
keeps returning the OLD version because the PATH symlink belongs to uv
tool. v0.1.14's check returned PASS on this state; v0.1.15's catches it.

### Changed

- **`efterlev doctor` install_uniqueness check now walks package-manager
  metadata dirs in addition to PATH.** The PATH walk (G2 in v0.1.14)
  catches the case of two custom installs both on PATH; the new
  manager-metadata walk catches the dominant case of two managers
  fighting over a single PATH symlink. Detected manager dirs:
  - `~/.local/pipx/venvs/efterlev/` → pipx
  - `~/.local/share/uv/tools/efterlev/` → uv tool
  - `~/Library/Python/<v>/lib/python/site-packages/efterlev/` (macOS user pip)
  - `~/.local/lib/python<v>/site-packages/efterlev/` (linux user pip)

  When ≥2 distinct installations are detected by either strategy, the
  warning names each path + the matching uninstall command. PATH
  binaries that resolve under a known manager dir aren't double-counted
  (otherwise a single pipx install + its `~/.local/bin` shim would
  false-positive). The green-case detail also names which manager
  owns the install — useful diagnostic for "where IS efterlev installed?"
  (H1 from v0.1.14 triage; cli/doctor.py)

### Internal

- Test count: 1073 → 1075 (+2: `detects_pipx_and_uv_tool_managers`
  asserts the dominant H1 footgun fires the warn; `does_not_double_
  count_path_under_manager` guards against the false-positive case
  where a single pipx install plus its PATH shim would otherwise
  read as two installs). The existing 3 install_uniqueness tests
  carry forward unchanged in semantics; one was renamed for clarity.

## [0.1.14] — 2026-05-06

Triage-driven patch from the deterministic, zero-LLM post-release validation
of v0.1.13 (the same methodology that produced the v0.1.12 patch). Two
paper-cut findings closed; no scanner-output behavior change. v0.1.13's
4/4 cryptographic verification carries forward unchanged.

### Fixed

- **`docs/index.md` carried two stale current-version references to
  v0.1.11** — one at line 67 (*"45 ship today (v0.1.11)"*) and one at
  line 77 (*"v0.1.11 ... thirteen patch releases..."*). The
  drift slipped through every prior release because the existing
  `check-docs.py` rules cover test/detector/indicator/source-file
  counts and CLI-verb references, but not "current version" prose.
  Both lines now read v0.1.14. (G1 from v0.1.13 triage)
- **`scripts/check-docs.py` gains a `current_version_claim` rule.**
  Scans every `.md` repo-wide for `vX.Y.Z is current` / `vX.Y.Z current`
  patterns and asserts the version matches `efterlev.__version__`.
  Past-tense references ("v0.1.11 closed five findings", "since v0.1.0")
  deliberately don't match — those are historical, not current-state
  claims. The rule caught three additional v0.1.13 stragglers in
  README + CLAUDE.md during the v0.1.14 cut, plus a stale 1070 → 1073
  test-count claim. The doc/code agreement now stays tight by
  construction. (G1 from v0.1.13 triage; scripts/check-docs.py)

### Added

- **`efterlev doctor` warns when multiple `efterlev` binaries sit on
  PATH.** When `pipx install efterlev` and `uv tool install efterlev`
  both exist, PATH ordering picks the winner silently — `pipx upgrade`
  / `uv tool upgrade` against the loser reports success but
  `efterlev --version` still returns the older install. Real repro
  from the v0.1.13 triage: pipx 0.1.13, uv tool 0.1.11, PATH found uv
  first, "upgraded but version unchanged" with no obvious cause. The
  new `install_uniqueness` check walks PATH (resolving symlinks so
  `/usr/local/bin → /opt/bin` doesn't false-positive), names every
  `efterlev` binary it finds, identifies the PATH winner, and points
  at the matching uninstall command. Pre-flight surfaces the
  parallel-install state before the user hits the version-mismatch
  confusion. (G2 from v0.1.13 triage; cli/doctor.py)

### Internal

- Test count: 1070 → 1073 (3 new per-fix regression tests for
  `install_uniqueness`: warns-on-multiple, passes-on-single, and
  dedups-symlinked-paths to prevent the false-positive case).
- `verify-release.sh` example version bumped from v0.1.13 to v0.1.14.

## [0.1.13] — 2026-05-06

Permissions-fix patch on top of v0.1.12. The v0.1.12
`actions/attest-build-provenance@v2` step added to `release-container.yml`
failed at runtime with `Resource not accessible by integration` because
the workflow's `permissions:` block was missing `attestations: write`.
Result: v0.1.12 published with a cosign-signed container but no SLSA
cosign-verifiable attestation, leaving `verify-release.sh v0.1.12` at
3/4 passed (the same posture as v0.1.10 + v0.1.11). v0.1.13 adds the
missing permission and re-fires the full sign + attest path, taking
`verify-release.sh v0.1.13` to 4/4.

### Fixed

- **`release-container.yml` carries `attestations: write`** so the v0.1.12
  `actions/attest-build-provenance@v2` step can call the GitHub
  attestations API. The step's docs list the required permissions but
  the workflow comment that named the related `id-token: write` permission
  obscured the omission. v0.1.13 ships nothing else; the v0.1.12 changes
  (PEP 740 verifier, F2/F3/F4 fixes) all carry forward.

### Internal

- `scripts/verify-release.sh` failure message updated: pre-v0.1.13
  releases are now disambiguated as either "buildx-only provenance"
  (v0.1.10 + v0.1.11) or "attest step misconfigured" (v0.1.12).

## [0.1.12] — 2026-05-06

Triage-driven patch from a deterministic, zero-LLM post-release validation
of v0.1.11 (the first such validation against published wheel + container
artifacts). Four findings closed; no scanner-output behavior change. The
biggest piece is `verify-release.sh` going from 0/4 passed to 4/4 passed
on v0.1.12+ — the script's PyPI check was hitting a 404 because PyPI
moved Trusted-Publishing attestations from `<url>.sigstore` sidecars to
the PEP 740 `/integrity` endpoint, and the container SLSA check was
failing because buildx's in-OCI-manifest provenance was never wrapped as
a cosign-verifiable attestation. Both are wired correctly now; the
project's "verify the release" claim is no longer aspirational.

### Fixed

- **`scripts/verify-release.sh` rewritten for PEP 740 + drops `docker
  buildx` hard-dep.** The PyPI check now fetches each artifact's
  Sigstore bundle from `https://pypi.org/integrity/{project}/{version}/{filename}/provenance`,
  reshapes the PEP 740 attestation into a Sigstore v0.3 bundle (snake_case
  → camelCase, certificate string → `{rawBytes:...}`, envelope DSSE
  reshape), and verifies with `python -m sigstore verify identity`. The
  cosign signature check uses `cosign verify <tag>` directly (cosign
  resolves tag→digest internally; the previous `docker buildx imagetools
  inspect` step was unneeded). The SLSA check (#3 below) now finds a
  cosign-verifiable attestation on v0.1.12+ container images. Pre-v0.1.12
  releases still fail check 3 by design — the script's failure message
  names the upgrade path so users aren't left guessing. (F1 from v0.1.11
  triage; DECISIONS 2026-05-05)
- **`actions/attest-build-provenance@v2` wired into `release-container.yml`.**
  Produces a cosign-verifiable SLSA v1 build-provenance attestation
  pushed to GHCR alongside the image. v0.1.10 + v0.1.11 had buildx-emitted
  SLSA v0.2 provenance attached to the OCI image manifest only
  (verifiable via `docker buildx imagetools inspect --format '{{ json
  .Provenance }}'`); the absence of a separate cosign attestation made
  `cosign verify-attestation --type slsaprovenance` fail. From v0.1.12
  onward, cosign discovers the attestation via the OCI 1.1 referrers
  API. (F1 from v0.1.11 triage)
- **`efterlev scan` warns when `--target` sits below a `.github/workflows/`
  ancestor.** Real customer repos with `infra/terraform/`-style layouts
  routinely run `efterlev scan --target infra/terraform/` and silently
  drop every GitHub-source detector (4 in v0.1.x — sbom-action, codeql,
  dependency-review, ci_validation_gates). The new warning surfaces the
  ancestor path and recommends scanning from the repo root. Walks parents
  of `--target` until it finds `.github/workflows/` or hits the git repo
  root. Documented v0.1.x footgun, no in-tool mitigation pre-v0.1.12.
  (F2 from v0.1.11 triage; cli/main.py)
- **`efterlev scan` surfaces a plan-JSON hint when ≥1 evidence record
  contains an `unparseable` attribute value.** The dominant case is
  `aws_iam_policy { policy = jsonencode({...}) }` — python-hcl2 doesn't
  evaluate Terraform function calls, so the policy comes through as
  `mfa_required="unparseable"` (or equivalents in other detectors).
  Pre-v0.1.12 the unparseable status was buried inside individual
  Evidence records; users who didn't grep the JSON sidecar never saw
  the recommendation to switch to `--plan plan.json` mode (which gives
  Terraform-resolved values). The hint is suppressed in plan-JSON mode
  itself. (F4 from v0.1.11 triage; cli/main.py)
- **Two doc-drift fixes for `.efterlev/reports/<subdir>/` paths, plus a
  `check-docs.py` rule that catches the pattern.** `docs/ai-quickstart-prompt.md:288`
  cited a non-existent gap-report subdir; the actual gap-report path is
  flat (`.efterlev/reports/gap-<ts>.json`). The opposite drift in
  `docs/reference/poam-markdown-shape.md:5` said POA&M lands flat; the
  actual path is `.efterlev/reports/poam/poam-<ts>.md`. The new
  check-docs rule scans every repo `.md` for the
  `.efterlev/reports/<subdir>/` shape and asserts the subdir is in the
  allowlist (currently `{"poam"}` — gap, scan, attestation, documentation
  are flat). When a new subdir is added in code, the check fails until
  the allowlist is bumped, forcing the doc/code agreement to stay tight.
  (F3 from v0.1.11 triage; scripts/check-docs.py)

### Internal

- Test count: 1066 → 1070 (4 new per-fix regression tests for F2/F4 — F3
  is covered by the new check-docs rule).

## [0.1.11] — 2026-05-06

3PAO-finding patch from the v0.1.10 blinded review. A FedRAMP-accredited
3PAO ran a paper review against a clean v0.1.10 govnotes-demo run and
returned an Accept-with-conditions disposition with five findings the
tool's own automation couldn't catch. This release closes the four
artifact-credibility findings and disambiguates the misleading walker
message that drove the highest-severity finding.

No behavior changes for scanner output or LLM-call costs — every fix
lands at the rendering / display / persistence layer.

### Fixed

- **Agent-drafted narratives carry an injected `DRAFT — requires human
  review.` marker** regardless of what the LLM returned. v0.1.10
  shipped the marker hardcoded into the `deterministic_template`
  branch but missing from `agent_drafted` entries when the model
  declined to emit it; the asymmetry made some attestations look
  finalized when they were not. The marker is now structural —
  injected post-response — and the persisted Claim payload, the
  rendered HTML narrative, and the FRMR artifact entry agree.
  Idempotent: a model that already produced the prefix doesn't get
  a doubled marker. (3PAO HIGH; agents/documentation.py)
- **`AttestationDraft` carries `controls_mapped`** so the doc HTML
  and JSON sidecar render the FRMR-mapped 800-53 control split
  alongside `controls_evidenced`. The HTML report now shows the
  mapping explicitly per attestation; the JSON schema bumps to v1.1
  with `controls_mapped` + `boundary_state` fields. Empty case is
  surfaced explicitly for the 9 procedural KSIs in the FRMR catalog
  (KSI-AFR-CCM, FSI, ICP, …) that ship without any `controls` field
  — the renderer now prints "this KSI is procedural in the FRMR
  catalog (no per-control 800-53 attribution)" rather than rendering
  an unexplained blank that read as a tool bug to the 3PAO.
  Uppercase-normalized to NIST canonical form to match
  `generate_frmr_attestation`. (3PAO MEDIUM)
- **Aggregate boundary state rendered per attestation in the doc HTML**
  alongside the existing mode pill. New `AggregateBoundaryState`
  type extends the per-evidence three-valued state with two
  draft-level cases: `mixed` (cited evidence spans in/out-of-
  boundary — variance signal worth flagging by design per DECISIONS
  2026-05-04, but reviewers should see the mix) and `no_evidence`
  (procedural / not_implemented KSIs with no citations). The
  `boundary_state` field is now part of the JSON sidecar schema and
  renders as a pill ("in boundary" / "out of boundary" / "boundary
  mixed" / "boundary undeclared" / "no evidence") with title-text
  explaining each case. (3PAO MEDIUM)
- **`provenance show <evidence_id>` surfaces both `record_id` and
  `evidence_id`** when the resolved record is an Evidence record.
  The dual-key reality (envelope hash on the SQLite row vs. content
  hash inside the payload) was previously hidden behind the prefix-
  resolution banner, which confused the 3PAO trying to verify that
  POA&M citations matched what the walker walked. New output shape
  prints both lines so reviewers can match either citation form
  against the walked record. (3PAO HIGH; cli/main.py)
- **Walker leaf message disambiguated by `record_type`.** A `Claim`
  record with empty `derived_from` is legitimate when the underlying
  classification was `not_implemented` or `evidence_layer_inapplicable`
  with no cited evidence — but the bare "(leaf — no derived_from)"
  message read as a traceability break to the v0.1.10 3PAO. The
  walker now prints `(scanner-emitted leaf — Evidence is derived
  directly from source files; no further derived_from edges by
  design)` for Evidence leaves and a parallel "claim with empty
  derived_from — typical for not_implemented…; not a traceability
  break" message for Claim leaves. No semantic change — only output
  text clarification. (3PAO HIGH; provenance/walker.py)

### Tests

- Ten new regression tests pinned to the v0.1.11 fixes (DRAFT marker
  injection idempotency, `controls_mapped` inheritance through both
  agent_drafted and deterministic_template paths, empty
  `controls_mapped` for procedural KSIs, mixed boundary aggregation,
  no_evidence aggregation, dual-key CLI display, claim-leaf
  disambiguated output, HTML pill rendering, HTML procedural empty
  surfacing). Total suite at 1066 tests; CI E2E smoke gate continues
  to run on every PR.

### Changed (internal)

- `AttestationDraft.controls_mapped: list[str]` (default `[]`).
- `AttestationDraft.boundary_state: AggregateBoundaryState`
  (default `"no_evidence"`).
- Documentation report JSON schema_version 1.0 → 1.1.
- New `aggregate_boundary_state(evidence)` helper in
  `primitives.generate.generate_frmr_skeleton`.

## [0.1.10] — 2026-05-05

Detector-coverage patch closing the v0.1.5–0.1.9 carry-forward Bug A:
`aws.mfa_required_on_iam_policies` now resolves the canonical
`aws_iam_policy_document` data-source pattern. Pre-v0.1.10 every
realistic Terraform repo (most policies in production codebases come
from data sources, not literal JSON) classified KSI-IAM-MFA as
`not_implemented` even when the policies DID enforce MFA. v0.1.10
walks the data source's HCL `statement {}` / `condition {}` blocks
and reports `present` / `absent` with the same fidelity as the
literal-JSON path.

### Fixed

- **`aws.mfa_required_on_iam_policies` resolves data-source policy
  references.** When an `aws_iam_policy` (or sibling) sets `policy =
  data.aws_iam_policy_document.NAME.json`, the detector now looks up
  the matching `data "aws_iam_policy_document" "NAME"` block and walks
  its statements + conditions. Detects the HCL `condition { variable =
  "aws:MultiFactorAuthPresent" values = ["true"] }` form (camelCase /
  list-shape — different from the JSON Condition dict). Emits a new
  `resolved_via_data_source` field on the evidence content so reviewers
  can navigate back to the source statement.
- **Terraform parser emits `data` blocks alongside `resource` blocks.**
  `TerraformResource` gains a `kind: Literal["resource", "data"]`
  field (default `"resource"` for backwards compat). The parser walks
  both `parsed["resource"]` and `parsed["data"]` lists, line-tracking
  via a 3-tuple key. Detectors that iterate `r.type in {...}` keep
  working unchanged (they just see additional resources whose types
  don't match their lists). Detectors that need cross-references
  (this one; potentially future ones) opt into reading data sources
  via `r.kind == "data"`.

### Notes

- Limitations carried into v0.2 prompt-tuning territory:
  `jsonencode(...)` policies and composed `source_policy_documents`
  remain unparseable. Real-world impact is small (most teams use
  `aws_iam_policy_document`); tracked in `docs/followups.md` for
  v0.2.
- This is the first v0.1.x patch shipped through the new CI E2E smoke
  gate (PR #125, v0.1.10). Required-check posture means this PR's CI
  exercises the full pipeline before merge.

## [0.1.9] — 2026-05-05

UX + audit-credibility patch from the v0.1.8 govnotes-demo Bedrock
shakedown. Five fixes: the manifest-out-of-boundary trap, missing
token telemetry on records, `boundary set` defaulting to append (the
verb-vs-behavior surprise), uv-vs-pipx install hint mis-targeting,
and two new DECISIONS entries codifying the boundary-rationale
behavior so 3PAOs can read it explicitly.

### Fixed

- **Evidence Manifests are always in-boundary.** Customer-authored
  Evidence Manifests at `.efterlev/manifests/*.yml` can't structurally
  be out-of-scope, but pre-v0.1.9 they got swept up by tight include
  patterns (`infra/terraform/**` / `.github/workflows/**`) that didn't
  cover the manifest path. The doc-agent drafted narratives but the
  POAM silently excluded them. v0.1.9 special-cases manifest paths
  in `compute_boundary_state` so they're unconditionally `in_boundary`,
  regardless of include/exclude config. Encoding the rule is more
  honest than relying on users to remember a third include pattern
  (see DECISIONS 2026-05-05).
- **Token usage telemetry on Claim records and `receipts.log`.** The
  Anthropic SDK and Bedrock Converse both return `usage.input_tokens`
  / `usage.output_tokens` on every completion. Pre-v0.1.9 these were
  dropped — only `model` and `prompt_hash` made it to the store, so
  post-hoc cost auditing required CloudWatch / Anthropic billing
  dashboards. v0.1.9 captures usage on `LLMResponse`, plumbs it
  through every agent's `metadata` dict, and surfaces both numbers as
  top-level fields on the receipt-log JSONL line. Operators can now
  sum a run's spend with one `jq` invocation.
- **`boundary set` defaults to replace.** v0.1.0 through v0.1.8
  `boundary set` appended by default — surprising because "set" reads
  as "set, replacing what was there." v0.1.9 flips the default:
  `set` replaces; new `--append` flag opts into the old accumulating
  behavior. `--replace` is kept as a deprecated no-op so pre-v0.1.9
  scripts continue to work; surfaces a one-line deprecation note on
  stderr. Surfaced 2026-05-04.
- **Doctor + runbook detect uv vs pipx installer.** The boto3-missing
  hint pointed at `pipx inject efterlev boto3`, but `uv tool install`
  users found pipx commands silently failed against the wrong venv.
  v0.1.9 reads `sys.executable` to detect the installer (uv / pipx /
  pip), then surfaces the right fix-up command:
  `uv tool install --reinstall 'efterlev[bedrock]'` for uv users,
  `pipx install 'efterlev[bedrock]'` for pipx, `pip install` for the
  rest. README runbook Step 2b.3 also splits the install instructions
  by installer.

### Decisions

- **Manifests are always in-boundary** (DECISIONS 2026-05-05). The
  rule is encoded as a pre-config short-circuit in
  `compute_boundary_state`. Other `.efterlev/`-internal paths
  (cache, store) still follow normal config — they're machine-
  generated runtime state, not customer intent.
- **Doc-agent narratives may carry variance-signal references to OOB
  resources** (DECISIONS 2026-05-05). Narratives inherit the gap-
  rationale freedom codified 2026-05-04. The POA&M output is still
  strictly scope-filtered (items with all-OOB evidence are dropped),
  but narratives that survive into in-boundary POA&M items may name
  OOB resources for variance-signal context. Documented explicitly
  so 3PAOs see this as intended, not a leak.

### Notes

- Carry-forward bugs still observed (deferred to v0.2 prompt-tuning):
  KSI-SVC-PRR over/under-classification of CMK posture, IAM
  `aws_iam_policy_document` data-source parsing, sha256-prefix-only
  citations in 30 of 60 narratives, F5 manifest cross-wiring (PagerDuty
  quoted in AFR-FSI narrative instead of INR-RIR's). These want
  prompt iteration + a real-customer corpus.
- v0.1.8's `max_tokens=32768` Bedrock default cleanly cured the
  Sonnet 4.6 truncation in the v0.1.8 verification run.

## [0.1.8] — 2026-05-04

Release-blocker patch from the v0.1.7 govnotes shakedown. Three new
HIGH-severity bugs surfaced; v0.1.8 closes all three plus three smaller
ergonomics fixes.

### Fixed

- **Doc agent dual-emission (60 KSIs → 120 attestations).** Append-only
  store + multi-run `agent gap` (e.g. retry after a max_tokens error,
  A/B-testing prompts) accumulates one Claim per KSI per run.
  `reconstruct_classifications_from_store` returned every Claim, so
  doc-agent processed each KSI N times and emitted N attestations
  with potentially contradictory status. v0.1.8 dedups latest-wins
  (timestamp ascending order from the store, last occurrence per
  ksi_id keeps). Affects `agent document`, `agent remediate`, and
  `efterlev poam`. Each command now prints a one-line stderr note
  when dedup fired (`note: deduped N duplicate classification(s)
  from prior agent gap runs`). Pass `keep_all=True` to
  `reconstruct_classifications_from_store` for run-diffing use cases.
- **Boundary state propagation evidence→KSI on stale-evidence.**
  When the boundary is set AFTER an initial scan (or after
  `agent gap` writes classifications referencing pre-boundary
  evidence), classifications cite a mix of newer (correctly
  out_of_boundary) and older (stale boundary_undeclared) evidence.
  Pre-v0.1.8 the resolver collapsed any non-uniform mix to
  `boundary_undeclared`, leaving the POA&M filter unable to drop
  out-of-scope items. v0.1.8 treats stale-undeclared + at-least-one-
  out_of_boundary (in a workspace with a declared boundary) as
  out_of_boundary, mirroring the user's intent.
- **Configurable max_tokens with backend-aware default.** Sonnet 4.6
  on Bedrock hard-blocked by `max_tokens=20480` (set in v0.1.2 to
  duck Anthropic's 10-min streaming threshold; doesn't apply on
  Bedrock). Adds `LLMConfig.max_tokens` field; default is 20480 on
  Anthropic API, 32768 on Bedrock. Each agent's `_resolve_max_tokens`
  helper picks the right value.
- **Doctor reads AWS config-file region.** v0.1.3 doctor only checked
  env vars; users with `aws configure set region us-east-1` (writes
  to `~/.aws/config`) got false-warned "no region configured" even
  though the runtime worked. v0.1.8 mirrors boto3's full chain —
  `Session.region_name` resolves the config file alongside env.
- **`efterlev poam` always prints out-of-boundary count.** Pre-v0.1.8
  the line was conditional on `count > 0`; users couldn't tell
  whether the boundary had been considered or not. Now prints
  unconditionally; `0` is a useful signal.

### Improved

- **Runbook reality-check on plan-JSON fallback.** `terraform
  -refresh=false` doesn't always bypass `terraform { backend "s3" {} }`
  blocks; the runbook now says "drop straight to HCL if you see
  'Backend initialization required.'"
- **Runbook boundary-pattern guidance.** When users declare
  `--include 'infra/terraform/**'`, all workflow evidence becomes
  out_of_boundary because workflows aren't under that path. The
  Step 5 brief now explicitly mentions the two-pattern fix:
  `--include 'infra/terraform/**' --include '.github/workflows/**'`.

### Notes

- Agent-quality misclassifications surfaced in the v0.1.7 shakedown
  (KSI-SVC-PRR over-classifying as `evidence_layer_inapplicable`,
  KSI-MLA-LET missing retention variance, KSI-SCR-MIT mapping
  "mixed" to `not_implemented`) are tracked as v0.2 prompt-tuning
  work in `docs/followups.md` — they want a real-customer corpus to
  validate against.
- Carry-forward bugs still observed (deferred): IAM
  `aws_iam_policy_document` data-source parsing (`docs/followups.md`),
  rationales citing by sha256 hash without resource name
  (`docs/followups.md`).

## [0.1.7] — 2026-05-04

Detector-coverage + UX patch release. Closes a false-negative finding
on KSI-SCR-MON surfaced by the v0.1.6 terraform-aws-vpc / govnotes-demo
shakedown (the supply-chain-monitoring detector didn't recognize the
canonical `anchore/sbom-action`), plus a POAM artifact gap, a runbook
overhaul to halve the friction on first-run, and an explicit decision
on out-of-boundary evidence visibility.

### Fixed

- **`github.supply_chain_monitoring` recognizes modern action ecosystem**
  (false-negative on KSI-SCR-MON). The detector's action registry was
  too narrow — `anchore/sbom-action` (the canonical post-2023 SBOM
  emitter, the modern replacement for the deprecated `anchore/syft-
  action`) wasn't in the map, so workflows using it surfaced
  `sbom_tools_detected: []` and got classified as `not_implemented`.
  v0.1.7 adds: `anchore/sbom-action`, `aquasecurity/tfsec-action`,
  `step-security/harden-runner`, `google/osv-scanner-action`,
  `anchore/grype-action`, the CycloneDX language-action family
  (`gh-node-module-cyclonedx`, `gh-gomod-generate-sbom`,
  `gh-dotnet-cyclonedx`, `gh-python-generate-sbom`), and per-language
  Snyk action variants. Run-command registry adds: `cdxgen`,
  `spdx-sbom-generator` (SBOM); `dependency-check` (OWASP),
  `bundle-audit`, `govulncheck`, `trivy config` (CVE/scan).
- **POA&M markdown header surfaces out-of-boundary excluded count.**
  v0.1.4's boundary filter drops POA&M items whose cited evidence is
  entirely out-of-boundary; v0.1.5+ surfaced the count to stdout but
  the markdown body was silent on disk. v0.1.7 adds an `Excluded as
  out-of-boundary: N item(s)` bullet to the POA&M header so reviewers
  see the scope drop when reading the artifact later. Header omits
  the bullet when zero items were excluded (avoids visual clutter for
  boundary-undeclared workspaces).

### Improved

- **README AI-quickstart prompt — major UX overhaul.** Six structural
  changes informed by three rounds of real first-run shakedown reports:
  - **Step 0 (new):** repo-root verification before any scan, with a
    heuristic check (`.git/` + at least one of `.tf` or
    `.github/workflows/`) and an explicit confirm-vs-subdir prompt.
    Closes the silent 20%-coverage-loss footgun where a Terraform-only
    subdir gets named instead of the repo root.
  - **Step 1:** backend decision tree. Each option carries an explicit
    "RECOMMEND if…" rationale (credit card → Anthropic API; AWS
    already → Bedrock). Default fallback is Anthropic API since
    first-run friction differential is real.
  - **Step 2b.0 (new):** model family question (Claude / OpenAI /
    other). Honest about Claude-only support today; OpenAI + others
    on the v0.3+ roadmap.
  - **Step 2b.2:** tier picker is a recommendation (Sonnet latest) with
    concrete cost ratios, not a multiple-choice question. Opus / Haiku
    presented as overrides with use-case framing.
  - **Step 3:** `--force` is the default (manifests preserved, cache
    regenerates fresh defaults). Skip-force is the exception.
  - **Step 4:** explicit `terraform init -backend=false` fallback for
    the very-common missing-remote-state case (S3 backend, Terraform
    Cloud) — plus the throwaway-`.tfvars` fallback for missing
    required variables.
  - **Step 5:** proactive brief after gap. Reads the gap-report JSON
    and surfaces the classification breakdown, workspace boundary
    state, top 3 KSIs to focus on (biased toward SVC + IAM hot spots),
    and 2 partial KSIs flagged as best `agent remediate` targets.
    After document/poam: mode breakdown + POA&M counts.

### Decisions

- **Out-of-boundary evidence visibility codified
  (DECISIONS 2026-05-04):** the boundary filter scopes the POA&M
  output, not the gap-report rationales. Agents may cite any evidence
  in the active store when reasoning; only the POA&M renderer drops
  items whose cited evidence is entirely out of scope. The v0.1.6
  shakedown surfaced this as ambiguous (KSI-RPL-ABO citing
  out-of-boundary `dev_scratch` instances) — codifying the variance-
  signal interpretation rather than the redaction interpretation.
  See DECISIONS 2026-05-04 for the full rationale.

### Notes

- Per-classification `confidence` field on `KsiClassification` (vs the
  current hardcoded `Claim.confidence="medium"`) is tracked in
  `docs/followups.md` as v0.2 work — needs prompt-template change +
  schema bump and wants real-customer corpus to calibrate against.
- `govnotes-demo` separately ships a doc-only fix for KSI naming drift
  in DELIBERATE_GAPS.md (v0.9.43-beta uses `KSI-SVC-PRR` /
  `KSI-CNA-MAT` / `KSI-MLA-LET`, not the `CMT-CKM` / `CNA-IAS` /
  `MLA-RTN` ids the Tier 1 doc cited).

## [0.1.6] — 2026-05-04

Provenance-integrity patch release. Closes the three issues surfaced by
the v0.1.5 terraform-aws-vpc shakedown plus a v0.1.5 messaging miss.
The headline finding ("Gap Agent fabricates evidence IDs") was a
false alarm — the IDs were real `Evidence.evidence_id` values that
v0.1.5's prefix-resolver couldn't reach because it only matched
`record_id`. Fixing the resolver makes the chain walkable from any
POAM-shown prefix.

### Fixed

- **`provenance show <prefix>` resolves evidence_ids, not just
  record_ids** — POA&Ms and rationales print 8-char prefixes of
  `Evidence.evidence_id` (the content hash the model sees in fences).
  v0.1.5's `resolve_record_id_prefix` only matched against
  `provenance_records.record_id` (the envelope hash). Pasting a
  POAM-shown prefix returned "no record matches" even though the full
  evidence_id walked correctly. Extends the resolver with a Step 2
  payload-scan that mirrors `resolve_to_record`'s dual-key lookup,
  with collision detection across both id spaces.
- **POA&M output lands under `.efterlev/reports/poam/`** — pre-v0.1.6
  wrote flat `.efterlev/reports/poam-<ts>.md`, but the runbook docs
  pointed at the subdir form. Aligns the writer with the docs and
  clusters per-report-type artifacts. Pass `--output` to override.
- **Plan-JSON trade-off note also fires when `--plan` IS used** —
  v0.1.5 added the line-numbers caveat but only in the
  recommend-plan-JSON branch. Users who were already in plan-JSON
  mode never saw the explanation for their `source_lines: null`
  citations. Now prints the trade-off any time plan-JSON is in use.
- **GitHub-workflow detectors emit file-level line ranges instead of
  null** — workflow files are conceptually single units (one Evidence
  per file), but v0.1.5 left `source_ref.line_start`/`line_end`
  as None, making the audit trail unnecessarily weak. v0.1.6 sets
  `line_start=1, line_end=<file_total_lines>`. Per-step line
  numbers (e.g. `uses:` step lines) are tracked as a v0.2 enhancement.
- **`provenance verify` adds derived_from referential-integrity
  check** — pre-v0.1.6 only verified blob hashes match content_refs.
  Now also walks every record's envelope `derived_from` and confirms
  each cited id resolves via the dual-key path. Catches anything
  that ever bypasses the write-time validator (future tooling, manual
  DB writes, migrations).

## [0.1.5] — 2026-05-03

Honesty-and-ergonomics patch release. Closes three issues surfaced by
the v0.1.4 fully-private-cluster shakedown: a CLI dead-end, a misleading
metadata field, and a marketing claim that didn't survive contact with
plan-JSON mode.

### Fixed

- **`provenance show` accepts truncated SHA prefixes** — POA&Ms,
  rationales, and attestation report tables print 8-char prefixes for
  readability, and users naturally pasted those into `provenance show`
  expecting them to resolve. Earlier versions matched only the full
  64-hex form, so the prefix was a dead end. Now the CLI prefix-resolves
  via `record_id LIKE 'sha256:<prefix>%'` and prints the resolution
  banner (`resolved sha256:81fffc53 → sha256:81fffc53...full`). Refuses
  prefixes shorter than 4 hex chars (collision risk) and raises
  `ProvenanceError` on prefix collisions instead of silently picking the
  first match.
- **Attestation `mode` field stops lying about deterministic
  narratives** — v0.1.4 introduced a no-LLM template path for
  `evidence_layer_inapplicable` KSIs, but kept stamping the resulting
  drafts as `mode="agent_drafted"`. That hid the cost-saving from
  reviewers AND broke the field's contract as a "what produced this
  prose?" signal — downstream tooling could no longer tell template-
  filled entries apart from LLM-drafted ones. Adds a third literal
  `deterministic_template` to `AttestationMode` and threads it through
  the artifact serializer, the JSON sidecar (`mode` field), and the
  HTML report (a new mode-pill badge alongside the status pill).
- **README + scan output drop the "cited source lines" claim on
  plan-JSON mode** — `terraform show -json` output doesn't preserve HCL
  line numbers, so plan-JSON Evidence records carry `source_lines:
  null` on every citation. The README, the AI-quickstart prompt, and
  the scan-mode-recommendation message now state the trade-off
  explicitly ("plan-JSON gives full module coverage but citations land
  at file-level only until line recovery lands in v0.2"). Line recovery
  is tracked in `docs/followups.md` as the leading v0.2.0 item.

## [0.1.4] — 2026-05-01

First-run UX patch release. Closes the friction items surfaced by a real
v0.1.3 Bedrock first-run report against govnotes-demo. Each fix maps to
a specific report number; bundled so the next first-run is dramatically
quieter and cheaper.

### Fixed

- **`agent document` runs deterministic narratives on
  `evidence_layer_inapplicable` KSIs by default** (report #5). On a
  typical 60-KSI baseline, 25-45 KSIs are procedural-only — earlier
  versions generated full Sonnet narratives for each that were
  essentially boilerplate ("scanner cannot evidence; reviewer must
  corroborate procedurally"). Now those entries get a deterministic
  narrative built from the Gap Agent's already-produced rationale + the
  KSI's underlying 800-53 controls, with no LLM call. The FRMR
  attestation completeness is preserved — all 60 KSIs still get an
  entry. Pass `--include-inapplicable-narratives` to opt back into
  LLM-drafted prose for these. **Saves ~70% of Sonnet spend on
  documentation runs.**
- **`doctor` warns when boundary scope is undeclared** (report #3).
  Earlier doctor runs reported "5 pass, 0 warn, 0 fail" while the gap
  report header showed `workspace_boundary_state: boundary_undeclared`.
  Now reads `[boundary]` from `.efterlev/config.toml` and surfaces a
  warn-level check with a remediation hint pointing at
  `efterlev boundary set --include 'boundary/**'`. The check is
  informational; running outside a formal authorization boundary stays
  permitted.
- **SHA256 record-ID dumps moved behind `--verbose`** (report #6) on
  `efterlev scan` and `efterlev agent gap`. Default output now prints
  a one-line summary ("N record(s) written to .efterlev/store.db; pass
  --verbose..."). Forensics still available; first-time users no longer
  get a flood of hashes.
- **Absolute paths for printed report files** (report #7). `efterlev
  scan`, `agent gap`, `agent document`, `agent remediate`, and
  `report diff` all now print fully-resolved paths for HTML/JSON
  outputs. Earlier mix of relative and absolute (within the same
  block on `agent document`) is fixed.
- **"Next steps" footers** on `agent gap` and `agent document` outputs
  (report #8). Each surfaces the right follow-on commands with their
  typical cost — `agent document`, `poam`, `agent remediate --ksi <id>`.
- **`init` creates `.efterlev/manifests/` with a README** (report #10)
  on first run. Earlier versions created the directory lazily (only
  when a manifest was loaded), leaving the gap between docs ("commit
  manifests under `.efterlev/manifests/`") and on-disk state unbridged.
  README inside the new dir explains the format with a worked example.
- **README AI-quickstart prompt clarifies "repo root" vs "Terraform
  path"** — silent root cause of the prior shakedown's two anomalies
  (3 manifests not loading, 4 GitHub-workflow detectors not firing,
  ~20% of detector coverage disappeared). Repo-root scoping is now
  explicit with a one-paragraph note on what subdir-scoping skips.

### Notes

- Cost-summary at end of agent runs (report #4) and `--llm-tier=opus|
  sonnet|haiku` shorthand for Bedrock (report #9) are tracked as
  v0.2.0 features in `docs/followups.md` — both want token-counting
  + price-model design that's bigger than a patch release.
- terraform-init-failure → cleaner scan-mode message (report #2)
  tracked in followups.

## [0.1.3] — 2026-04-30

Patch release closing the Bedrock-onboarding cliff surfaced in a real
first-run test against AWS Bedrock (`us-east-1`). Each fix matches a
reproducible failure mode the user hit; bundled to ship together so a
single `pipx install efterlev[bedrock]` works end-to-end.

### Fixed

- **Bedrock client used the boto3 default 60s read_timeout.** Gap Agent
  prompts (60 KSIs × ~75 evidence records) routinely take longer on
  Opus 4.7. Three retries multiplied 60s into ~3× wasted cost before
  surfacing failure. Now sets `read_timeout=600`, `connect_timeout=10`,
  and `retries={"max_attempts": 1}` on the boto client (Efterlev has
  its own retry loop; the boto layer's was redundant).
- **Agents crashed when LLMs wrapped output in ` ```json ` fences.**
  Opus 4.6 (and occasionally Sonnet 4.6 on Bedrock) wraps structured
  output in markdown fences despite system-prompt instructions to
  return raw JSON. Added defensive fence-stripping before
  `json.loads` in `agents/base.py._invoke_llm`.
- **`init --llm-backend=bedrock` defaulted to a model ID that doesn't
  exist in most accounts.** v0.1.x had `us.anthropic.claude-opus-4-7-v1:0`
  hardcoded. Now probes the user's account via
  `bedrock.list_inference_profiles(typeEquals="SYSTEM_DEFINED")` and
  picks the latest available Anthropic Opus profile when `--llm-model`
  isn't passed. Falls back to the hardcoded default with a clear warning
  when the probe fails (no perms, no boto, no profiles).
- **`doctor` only checked AWS credentials in env vars,** false-warning
  users whose creds came from `~/.aws/credentials`, `AWS_PROFILE`, IMDS,
  or SSO. Now uses `boto3.Session().get_credentials()` (the full
  credential chain) — matches what the runtime client actually consults.
- **`doctor` now pings `InvokeModel` end-to-end** when the workspace is
  configured for Bedrock. 1-token throwaway prompt validates that the
  configured model is reachable, the credentials work, and access is
  granted — catches stale defaults, missing inference-profile access,
  and expired SSO sessions before the user spends API budget on a
  doomed agent run.
- **`doctor`'s ANTHROPIC_API_KEY check skips when backend is bedrock.**
  Earlier versions warned about a missing key on workspaces where the
  key is irrelevant.

### Notes

- Streaming refactor of the Anthropic clients (deferred from v0.1.2)
  remains queued for v0.2.0. The Bedrock-side `read_timeout=600` makes
  long completions practical without it; the structural fix is still
  the right destination.

## [0.1.2] — 2026-04-30

Patch release closing two real-CI bugs surfaced by the govnotes-demo
deep-dive shakedown — the canonical Evidence Manifest pattern (commit
manifests, gitignore cache) didn't survive a fresh clone, and v0.1.1's
bumped `max_tokens=32768` tripped Anthropic's streaming-required
threshold and prevented the gap agent from running at all.

### Fixed

- **`report run` skipped init when `.efterlev/manifests/` was the only
  thing in the workspace dir.** The detection looked at the dir, not
  the FRMR cache file scan needs. Fresh clones with manifests
  committed but the cache gitignored hit "FRMR cache missing"
  immediately. `report run` now detects the cache (the actual
  artifact) and passes `--force` to its sub-init step when the dir
  exists but the cache is missing — regenerates cache + provenance
  store while preserving customer-authored manifests. Regression
  test added.
- **Gap Agent `max_tokens=32768` raised "streaming required" on real
  workloads.** Anthropic's `messages.create()` (non-streaming) path
  rejects requests whose `max_tokens` could plausibly take >10
  minutes. Reduced to **20480** — enough headroom over the v0.1.0
  truncation site (~16384) for the full 60-KSI baseline with
  substantive rationales, but well below the streaming threshold.
  If real workloads need more, the right move is the streaming
  refactor (`client.messages.stream()`), not chasing the cap.
- **README + CLAUDE.md test count drift** (1019 → 1020 after PR #104
  added a regression test for the half-init pattern).

### Notes

- Streaming refactor of the Anthropic client is queued as a
  v0.2.0-targeted item — the right structural fix when output budget
  needs to grow further. The fake-client surface in
  `tests/test_anthropic_retry_fallback.py` would need rewiring for a
  streaming context manager.

## [0.1.1] — 2026-04-29

Patch release closing three v0.1.0 bugs surfaced in a deep-dive shakedown
test against `terraform-aws-modules/terraform-aws-iam` and a synthetic
ground-truth target.

### Fixed

- **Gap Agent `max_tokens` truncation.** The cap was 16384, which truncated
  mid-JSON on real-world full-baseline runs (60 KSIs each with substantive
  rationales). Bumped to 32768 — Claude Opus 4.7's output ceiling. The
  agent's own error message ("increase the max_tokens argument") is now
  acted on; full-baseline runs complete without truncation.
- **Confusing LLM-invocation transcript record.** `agents.base._invoke_llm`
  used to write a per-run transcript record with `record_type="claim"`,
  payload `{user_message, response_text, parsed}`, and empty `derived_from`.
  It looked like a malformed Claim to anyone listing claim records or
  walking provenance — and triggered tester confusion about whether the
  retry path was corrupting state. Removed; per-claim records (per KSI for
  Gap, per narrative for Documentation, per remediation for Remediation)
  already carry `model`, `prompt_hash`, and properly-populated
  `derived_from`. No information loss.
- **`efterlev --version` reported stale `0.0.1` from the published 0.1.0
  wheel.** `pyproject.toml` had a version literal `"0.1.0"` while
  `src/efterlev/__init__.py` had `__version__ = "0.0.1"` — two sources of
  truth, drifted. Switched to hatch dynamic versioning
  (`[tool.hatch.version] path = "src/efterlev/__init__.py"`) so pyproject
  reads from the source file. Added a CI-time regression test
  (`test_in_source_version_matches_package_metadata`) so future drift is
  caught before release.

### Notes

- Bug #5 from the shakedown report (gap/remediate disagreement on
  KSI-AFR-UCM scope: gap classified `partial` citing FIPS-TLS evidence, but
  remediate refused with "no Terraform surface to remediate") deferred to
  `docs/followups.md`. Root cause is design-level: the Gap Agent has
  freedom to cite any prompt-visible Evidence in its rationale, while
  remediate's CLI gate strictly filters by `Evidence.ksis_evidenced`. The
  fix needs a design call between trusting the Gap Agent's citations vs.
  enforcing detector-level KSI mapping at remediate time. Not a regression;
  present in v0.1.0.
- Prompt-tuning concerns from the shakedown (systematic leniency, rationale
  reuse across thematically-adjacent KSIs) are v0.2.0 work — they want a
  real-customer evidence corpus to tune against rather than synthetic
  dogfood.

## [0.1.0] — 2026-04-29

First public release. The work in this section closes Priorities 1, 2,
and 3 of `docs/v1-readiness-plan.md` plus the post-launch-prep
walkback / audit / new-detector arc. 51 PRs landed 2026-04-27 →
2026-04-29 (#36 → #96).

### Priority 1 — Detector breadth (✅ complete; lifted post-floor)

Coverage moved from 14 → 31 KSIs / 5 → 8 themes / 38 → 45 detectors.
The plan's ≥30 KSI / ≥8 theme floor was reached at PR #51; post-walkback
work (PRs #88, #89, #92) lifted coverage to 31 / 8 / 45.

- **Added detectors:**
  - `aws.terraform_inventory` — KSI-PIY-GIV (PR #39)
  - `aws.s3_lifecycle_policies` — KSI-SVC-RUD (PR #40)
  - `aws.federated_identity_providers` — KSI-IAM-APM (PR #41)
  - `aws.iam_managed_via_terraform` — KSI-IAM-AAM (PR #42)
  - `aws.cloudfront_viewer_protocol_https` — KSI-SVC-VCM (PR #47)
  - `aws.ec2_imdsv2_required` — KSI-CNA-IBP (PR #48); cross-mapped to KSI-CNA-DFP via CM-2 (PR #51)
  - `aws.backup_restore_testing` — KSI-RPL-TRC (PR #49)
  - `aws.suspicious_activity_response` — KSI-IAM-SUS (PR #50)
  - `aws.vpc_logical_segmentation` — KSI-CNA-ULN (PR #36)
  - `github.ci_validation_gates` — KSI-CMT-VTD (PR #37)
  - `github.supply_chain_monitoring` — KSI-SCR-MON (PR #38)
  - `github.immutable_deploy_patterns` — KSI-CMT-RMV (PR #44)
  - `github.action_pinning` — KSI-SCR-MIT (PR #46)

- **Cross-mappings** (existing detectors gained additional KSI attributions
  via FRMR control overlap, not invented attribution):
  - `aws.cloudtrail_audit_logging` → +KSI-CMT-LMC via AU-2 (PR #43)
  - `aws.iam_admin_policy_usage`, `aws.iam_inline_policies_audit` → +KSI-IAM-JIT via AC-6 (PR #45)
  - `aws.ec2_imdsv2_required` → +KSI-CNA-DFP via CM-2 (PR #51)

### Priority 2 — HTML report overhaul (✅ complete)

All 9 acceptance items closed. 11 PRs (#52 → #62 + #63 doc).

- **JSON sidecars on all 3 reports** — `gap-{ts}.json`, `documentation-{ts}.json`,
  `remediation-{ksi}-{ts}.json`. Schema-versioned; suitable for tool integration.
  PRs #52, #53, #54.
- **Coverage matrix** — single-page heatmap of all 11 themes × 60 KSIs at the
  top of the gap report. KSIs the agent didn't classify render as `unclassified`.
  Click any cell to scroll to the per-KSI classification card. PR #55.
- **Filter by status** — single-click pills above the classification list.
  Inline vanilla JS, no framework. PR #56.
- **Free-text search** — debounced input, live match count, additive with
  the status filter. PR #57.
- **Print stylesheet** — interactive bits hide; cards don't split across
  pages; out-of-boundary `<details>` expand on paper. PR #58.
- **Sort controls** — by KSI / severity / evidence count. PR #59.
- **Drill-down** — per-classification `<details>` listing each cited
  evidence's `source_file:line_range`. JSON sidecar gains
  `cited_evidence_refs[]`. PR #60.
- **Diff view** — `efterlev report diff PRIOR CURRENT` writes both
  `gap-diff-{ts}.html` and `gap-diff-{ts}.json`. CI-gateable: exits 2 on
  regression. PRs #61 (compute), #62 (CLI + HTML).

All Priority-2 features are self-contained (no external CDN, no fonts beyond
system-default, no analytics) and degrade gracefully without JavaScript
(filter/sort show all results in input order).

### Post-launch-prep walkback + audit (✅ complete)

Triggered by AWS's 2026-04-27 FedRAMP 20x deep-dive blog and a
maintainer review pass. 12 PRs landed 2026-04-28 → 2026-04-29
(#80 → #92), plus the dependency unblock #93.

**Detector additions:**
- `aws.nacl_restrictiveness` — KSI-CNA-RNT (PR #88). Per-NACL
  posture summary (restrictive / partially_restrictive / permissive
  / empty); emits Evidence even on clean NACLs so positive evidence
  flows to the Gap Agent.
- `aws.centralized_log_aggregation` — KSI-MLA-OSM (PR #89). Workspace-
  scoped summary of log producers + aggregators; closes the
  "no SIEM aggregation primitives visible" agent narrative gap.

**Detector reclassifications:**
- `aws.iam_user_access_keys` (PR #92): primary mapping
  KSI-IAM-MFA → **KSI-IAM-SNU** (Securing Non-User Authentication);
  KSI-IAM-MFA preserved as cross-mapping. Adds KSI-IAM-SNU to the
  covered set (30 → 31 KSIs).

**Mapping audits + partial-coverage discipline:**
- PR #83: SVC-RUD and SVC-VCM downgraded to partial cross-mappings
  with explicit notes (scheduled-vs-on-request, viewer-edge-vs-S2S).
- PR #91: 6 detectors gained explicit `coverage: partial` notes
  (cloudtrail_log_file_validation, cloudwatch_alarms_critical,
  guardduty_enabled, elb_access_logs, vpc_flow_logs_enabled,
  access_analyzer_enabled).
- PR #90: systematic audit of all 34 remaining KSI-mapped detectors
  (`docs/detector-mapping-audit.md`). 23 direct fits, 9 partial
  cross-mappings, 2 reclassification candidates.

**Real bug fixes:**
- PR #82: FRMR loader now reads `varies_by_level.{level}.statement`
  with fallback to top-level. 5 KSIs (KSI-CNA-EIS, KSI-MLA-ALA,
  KSI-SVC-PRR, KSI-SVC-RUD, KSI-SVC-VCM) were silently statement-
  less; the Gap Agent had been classifying them blind.
- PR #81: report path display uses the user-supplied form (e.g.
  `/tmp/...`) instead of canonical (`/private/tmp/...`); macOS
  symlink paper-cut surfaced by a real local run.

**CSX-SUM / CSX-ORD gap closures:**
- PR #84: `validation_cadence` field added to documentation artifact
  (closes the CSX-SUM cadence-field-gap acknowledged in csx-mapping.md).
- PR #85: `efterlev poam --sort csx-ord` mode (closes the CSX-ORD
  prescribed-sequence-sort gap).

**Init-time UX:**
- PR #86: catalog freshness warning at `efterlev init` (180-day
  staleness + post-CR26-window heuristics).

**Framing walkback:**
- PR #80: walked back overclaims in csx-mapping.md / aws-coexistence.md
  / release-notes-v0.1.0-draft.md / README.md / aws-ksi-blog-analysis.md.
  "shaped to satisfy CSX-SUM" instead of "IS the artifact 3PAOs
  consume" (pending Priority 5 empirical validation).

**Documentation + upstream:**
- PR #87: drafts of two FRMR upstream feedback issues (file post-tag).
- PR #93: pathspec upper bound widened `<1` → `<2` to unblock
  Dependabot resolver.

**Dependabot bulk-merge:**
- 7 minor/major version bumps merged (#3, #4, #5, #6, #7, #9, #10).
  Python 3.14 (#2) and mypy 1.20 (#8) deferred to v0.1.x.

### Priority 3 — UX during install and usage (✅ complete)

All 6 acceptance items closed. 6 PRs (#64 → #69 + #70 doc).

- **`efterlev doctor`** — five pre-flight checks (Python, .efterlev workspace,
  FRMR cache freshness, ANTHROPIC_API_KEY shape, AWS Bedrock credentials)
  with per-check pass/warn/fail and remediation hints. No network calls.
  PR #64.
- **Friendly errors** — all 8 typed `anthropic.APIError` subclasses mapped to
  one-line messages + remediation hints at the agent CLI boundary. PR #65.
- **`efterlev report run`** — one-command pipeline (init → scan → agent gap
  → agent document → poam) with per-stage `--skip-*` flags. PR #66.
- **First-run wizard** — TTY-gated, credential-aware intro at `efterlev init`.
  Auto-skips on non-TTY (CI-safe); never modifies config silently. PR #67.
- **Progress indicators** — Documentation Agent emits
  `[idx/total] KSI-XXX ✓` per narrative to stderr. PR #68.
- **`--watch` mode** — `efterlev report run --watch` polls the target for
  `.tf`/`.tfvars`/`.yml`/`.yaml`/`.json` changes (debounced 2s) and re-runs
  the pipeline. Polling-based, no `watchdog` dependency. PR #69.

### Catalog stats (post-session)

- 1018 tests passing
- 172 source files
- 24 CLI commands
- 45 detectors (38 KSI-mapped + 7 supplementary 800-53-only)
- 31 KSIs covered across 8 themes
- mypy strict / ruff check / ruff format clean

### Documentation

- `docs/v1-readiness-plan.md` updated to mark Priorities 1, 2, 3 complete
  with PR pointers per acceptance item (PRs #51, #63, #70).

### Out of scope this session

- Priority 4 (boundary scoping): already shipped pre-session.
- Priority 5 (real customer dogfood + 3PAO touchpoint): calendar-time
  work outside the code surface — needs maintainer outreach.
- Priority 6 (honesty pass on `ksis=[]` detectors): already done
  pre-session.

The remaining gates to v0.1.0 are: maintainer security-review §8 sign-off,
24-hour fresh-eyes pause, optional GovCloud walkthrough, then `git push
origin v0.1.0`.
