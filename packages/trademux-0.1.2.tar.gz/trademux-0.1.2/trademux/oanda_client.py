"""OANDA client SDK that routes through TradeMux server."""

from __future__ import annotations

from datetime import datetime, timezone
import time
from typing import Any, Dict, List, Optional, Union

import pandas as pd
import requests


class OandaClient:
    """
    Python client for OANDA trading via TradeMux.

    All requests are routed through the TradeMux server which:
    - Auto-detects practice vs live environment
    - Proxies requests to the correct OANDA API
    - Tracks usage for billing

    Example:
        client = OandaClient(
            api_key="sb_tmux_xxx",          # TradeMux API key
            oanda_api_key="xxx-xxx-xxx",    # Your OANDA API key
        )
        print(client.get_balance())
    """

    def __init__(
        self,
        api_key: str,
        oanda_api_key: str,
        server_url: str = "https://mux.skybluefin.tech",
        timeout: int = 10,
    ) -> None:
        """
        Initialize the OANDA client.

        Args:
            api_key: TradeMux API key for authentication and billing
            oanda_api_key: Your OANDA API key (passed through to OANDA)
            server_url: TradeMux server URL (default: https://mux.skybluefin.tech)
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.oanda_api_key = oanda_api_key
        self.server_url = server_url.rstrip("/")
        self.timeout = timeout
        self.account_no: Optional[str] = None
        self.environment: Optional[str] = None  # "practice" or "live"
        self._min_interval = 1.0  # 1 rps to protect shared upstream limit
        self._last_request_ts = 0.0

        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-Api-Key": api_key,
                "X-Oanda-Api-Key": oanda_api_key,
                "Content-Type": "application/json",
            }
        )

        # Fetch key info and validate connection
        self._init_connection()

    def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make a request to TradeMux server."""
        self._apply_rate_limit()
        url = f"{self.server_url}/v1/oanda{endpoint}"
        try:
            response = self.session.request(
                method,
                url,
                params=params,
                json=data,
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.Timeout as exc:
            raise RuntimeError(f"Request timeout after {self.timeout}s") from exc
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError(f"Failed to connect to {self.server_url}") from exc
        except requests.exceptions.HTTPError as exc:
            error_detail = response.text
            try:
                error_json = response.json()
                error_detail = error_json.get("detail", error_detail)
            except Exception:
                pass
            raise RuntimeError(f"HTTP {response.status_code}: {error_detail}") from exc

    def _apply_rate_limit(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_request_ts
        if elapsed < self._min_interval:
            time.sleep(self._min_interval - elapsed)
        self._last_request_ts = time.monotonic()

    def _init_connection(self) -> None:
        """Fetch account info from server and validate OANDA credentials."""
        try:
            info = self._request("GET", "/init")
            self.account_no = info.get("account_no")
            self.environment = info.get("environment", "practice")
            env_label = "paper" if self.environment == "practice" else "live"
            print(
                f"OandaClient to OANDA {env_label} account no. {self.account_no} established"
            )
        except Exception as e:
            raise RuntimeError(f"Failed to initialize OandaClient: {e}") from e

    def _normalize_symbol(self, symbol: str) -> str:
        """Convert symbol to OANDA format (e.g., EURUSD -> EUR_USD)."""
        if "_" in symbol:
            return symbol.upper()
        if len(symbol) == 6:
            return f"{symbol[:3]}_{symbol[3:]}".upper()
        return symbol.upper()

    # ==================== CONNECTION STATUS ====================

    def get_server_status(self) -> Dict[str, Any]:
        """Get server health status."""
        self._apply_rate_limit()
        url = f"{self.server_url}/"
        response = self.session.get(url, timeout=self.timeout)
        response.raise_for_status()
        return response.json()

    def get_account_info(self) -> Dict[str, Any]:
        """Get account summary from OANDA."""
        return self._request("GET", "/account")

    def is_connected(self) -> bool:
        """Check if connection to OANDA is working."""
        try:
            self.get_server_status()
            return True
        except Exception:
            return False

    # ==================== ACCOUNT INFO ====================

    def get_balance(self) -> float:
        """Get account balance."""
        data = self.get_account_info()
        return float(data.get("account", {}).get("balance", 0.0))

    def get_equity(self) -> float:
        """Get account equity (NAV)."""
        data = self.get_account_info()
        return float(data.get("account", {}).get("NAV", 0.0))

    def get_floating_pnl(self) -> float:
        """Get unrealized P&L."""
        account = self.get_account_info().get("account", {})
        return float(account.get("NAV", 0.0)) - float(account.get("balance", 0.0))

    # ==================== MARKET DATA ====================

    def get_price(self, symbol: str) -> Dict[str, Any]:
        """Get current price for a symbol."""
        instrument = self._normalize_symbol(symbol)
        return self._request("GET", "/pricing", params={"instruments": instrument})

    def get_bid(self, symbol: str) -> float:
        """Get current bid price."""
        data = self.get_price(symbol)
        return float(data["prices"][0]["bids"][0]["price"])

    def get_ask(self, symbol: str) -> float:
        """Get current ask price."""
        data = self.get_price(symbol)
        return float(data["prices"][0]["asks"][0]["price"])

    def get_mid(self, symbol: str) -> float:
        """Get mid price (average of bid and ask)."""
        return (self.get_bid(symbol) + self.get_ask(symbol)) / 2

    def get_spread(self, symbol: str) -> float:
        """Get current spread."""
        return self.get_ask(symbol) - self.get_bid(symbol)

    def get_symbol_specs(self, symbol: str) -> Dict[str, Any]:
        """Get instrument specifications."""
        instrument = self._normalize_symbol(symbol)
        return self._request("GET", "/instruments", params={"instrument": instrument})

    def list_tradeable_instruments(self) -> List[Dict[str, Any]]:
        """
        List all tradeable instruments for the account.

        Returns a simplified list of instruments available for trading based on
        the account's regulatory division. Use get_symbol_specs() for full details.

        Returns:
            List of instrument dictionaries containing:
            - api_symbol: OANDA API symbol (e.g., "EUR_USD")
            - displayName: Human-readable name (e.g., "EUR/USD")
        """
        response = self._request("GET", "/instruments/all")
        return response.get("instruments", [])

    def get_ohlc(
        self,
        symbol: str,
        timeframe: str = "1h",
        count: Optional[int] = None,
        start_date: Optional[Union[str, datetime, int]] = None,
        as_df: bool = True,
    ) -> Union[Dict[str, Any], "pd.DataFrame"]:
        """
        Get OHLC candle data.

        Note:
            This implementation always fetches the maximum 5000 candles first,
            then filters locally based on `count` or `start_date`.

        Args:
            symbol: Trading symbol (e.g., "EURUSD" or "EUR_USD")
            timeframe: Candle timeframe ("1min", "5min", "15min", "30min", "1h", "4h", "1d", "1w")
            count: Number of candles to return (mutually exclusive with start_date)
            start_date: Start date for candles (mutually exclusive with count)
            as_df: Return as pandas DataFrame if True
        """
        if (count is None and start_date is None) or (
            count is not None and start_date is not None
        ):
            raise ValueError("Provide exactly one of 'count' or 'start_date'")

        if count is not None and count > 5000:
            raise ValueError("count cannot exceed 5000 (OANDA limit)")

        def _to_utc_dt(value: Union[str, datetime, int]) -> datetime:
            if isinstance(value, datetime):
                dt = value
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return dt.astimezone(timezone.utc)

            if isinstance(value, int):
                return datetime.fromtimestamp(int(value), tz=timezone.utc)

            s = str(value)
            if "T" in s:
                dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            else:
                dt = datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)

            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)

        instrument = self._normalize_symbol(symbol)

        # Always fetch the maximum slice first, then filter locally.
        params: Dict[str, Any] = {
            "instrument": instrument,
            "timeframe": timeframe,
            "count": 5000,
        }
        response = self._request("GET", "/candles", params=params)

        candles: List[Dict[str, Any]] = response.get("candles", []) or []

        # Local filtering
        filtered: List[Dict[str, Any]]
        if count is not None:
            filtered = candles[-count:] if count else []
        else:
            cutoff = _to_utc_dt(start_date)  # type: ignore[arg-type]
            filtered = []
            for c in candles:
                t = c.get("time")
                if not t:
                    continue
                try:
                    tdt = pd.to_datetime(t, utc=True).to_pydatetime()
                except Exception:
                    continue
                if tdt >= cutoff:
                    filtered.append(c)

        if as_df:
            if not filtered:
                return pd.DataFrame()

            rows = []
            for c in filtered:
                mid = c.get("mid", {}) or {}
                rows.append(
                    {
                        "time": c.get("time"),
                        "open": float(mid.get("o", 0)),
                        "high": float(mid.get("h", 0)),
                        "low": float(mid.get("l", 0)),
                        "close": float(mid.get("c", 0)),
                        "volume": int(c.get("volume", 0)),
                    }
                )

            df = pd.DataFrame(rows)
            df["time"] = pd.to_datetime(df["time"], utc=True)
            df.set_index("time", inplace=True)
            return df

        out = dict(response)
        out["candles"] = filtered
        return out

    # ==================== TRADING ORDERS ====================

    def _lots_to_units(self, symbol: str, lots: float) -> int:
        """Convert lots to OANDA units."""
        specs = self.get_symbol_specs(symbol)
        contract_size = float(specs.get("contract_size", 100000))
        units = int(round(lots * contract_size))
        if units == 0:
            raise ValueError("Lot size too small")
        return units

    def buy_market(
        self,
        symbol: str,
        lots: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Place a market buy order."""
        return self._request(
            "POST",
            "/order",
            data={
                "instrument": self._normalize_symbol(symbol),
                "side": "BUY",
                "lots": lots,
                "type": "MARKET",
                "sl": sl,
                "tp": tp,
                "comment": comment,
            },
        )

    def sell_market(
        self,
        symbol: str,
        lots: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Place a market sell order."""
        return self._request(
            "POST",
            "/order",
            data={
                "instrument": self._normalize_symbol(symbol),
                "side": "SELL",
                "lots": lots,
                "type": "MARKET",
                "sl": sl,
                "tp": tp,
                "comment": comment,
            },
        )

    def buy_limit(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Place a limit buy order."""
        exp_str = None
        if expiration:
            if isinstance(expiration, datetime):
                exp_str = expiration.astimezone(timezone.utc).isoformat()
            else:
                exp_str = datetime.fromtimestamp(
                    expiration, tz=timezone.utc
                ).isoformat()

        return self._request(
            "POST",
            "/order",
            data={
                "instrument": self._normalize_symbol(symbol),
                "side": "BUY",
                "lots": lots,
                "type": "LIMIT",
                "price": price,
                "sl": sl,
                "tp": tp,
                "comment": comment,
                "expiration": exp_str,
            },
        )

    def sell_limit(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Place a limit sell order."""
        exp_str = None
        if expiration:
            if isinstance(expiration, datetime):
                exp_str = expiration.astimezone(timezone.utc).isoformat()
            else:
                exp_str = datetime.fromtimestamp(
                    expiration, tz=timezone.utc
                ).isoformat()

        return self._request(
            "POST",
            "/order",
            data={
                "instrument": self._normalize_symbol(symbol),
                "side": "SELL",
                "lots": lots,
                "type": "LIMIT",
                "price": price,
                "sl": sl,
                "tp": tp,
                "comment": comment,
                "expiration": exp_str,
            },
        )

    def buy_stop(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Place a stop buy order."""
        exp_str = None
        if expiration:
            if isinstance(expiration, datetime):
                exp_str = expiration.astimezone(timezone.utc).isoformat()
            else:
                exp_str = datetime.fromtimestamp(
                    expiration, tz=timezone.utc
                ).isoformat()

        return self._request(
            "POST",
            "/order",
            data={
                "instrument": self._normalize_symbol(symbol),
                "side": "BUY",
                "lots": lots,
                "type": "STOP",
                "price": price,
                "sl": sl,
                "tp": tp,
                "comment": comment,
                "expiration": exp_str,
            },
        )

    def sell_stop(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Place a stop sell order."""
        exp_str = None
        if expiration:
            if isinstance(expiration, datetime):
                exp_str = expiration.astimezone(timezone.utc).isoformat()
            else:
                exp_str = datetime.fromtimestamp(
                    expiration, tz=timezone.utc
                ).isoformat()

        return self._request(
            "POST",
            "/order",
            data={
                "instrument": self._normalize_symbol(symbol),
                "side": "SELL",
                "lots": lots,
                "type": "STOP",
                "price": price,
                "sl": sl,
                "tp": tp,
                "comment": comment,
                "expiration": exp_str,
            },
        )

    def buy_conditional_entry(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Buy if touched order - auto-selects limit/stop based on current price."""
        current_price = self.get_mid(symbol)
        if price < current_price:
            return self.buy_limit(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        if price > current_price:
            return self.buy_stop(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        return self.buy_market(symbol, lots, sl, tp, comment=comment)

    def sell_conditional_entry(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Sell if touched order - auto-selects limit/stop based on current price."""
        current_price = self.get_mid(symbol)
        if price > current_price:
            return self.sell_limit(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        if price < current_price:
            return self.sell_stop(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        return self.sell_market(symbol, lots, sl, tp, comment=comment)

    # ==================== POSITIONS & ORDERS ====================

    def list_positions(self) -> Dict[str, Any]:
        """Get all open positions."""
        return self._request("GET", "/positions")

    def list_orders(self) -> Dict[str, Any]:
        """Get all pending orders."""
        return self._request("GET", "/orders")

    def list_trades(self) -> Dict[str, Any]:
        """Get all open trades."""
        return self._request("GET", "/trades")

    def close_position(self, symbol: str) -> Dict[str, Any]:
        """Close all positions for a symbol."""
        instrument = self._normalize_symbol(symbol)
        return self._request("PUT", f"/positions/{instrument}/close")

    def close_symbol(self, symbol: str) -> Dict[str, Any]:
        """Close all positions for a symbol (alias for close_position)."""
        return self.close_position(symbol)

    def close_trade(self, trade_id: int) -> Dict[str, Any]:
        """Close a specific trade by ID."""
        return self._request("PUT", f"/trades/{trade_id}/close")

    def close_ticket(self, trade_id: int) -> Dict[str, Any]:
        """Close a specific trade by ID (alias for close_trade)."""
        return self.close_trade(trade_id)

    def close_same_comment(self, comment: str) -> Dict[str, Any]:
        """Close all trades with matching comment in clientExtensions."""
        trades = self.list_trades().get("trades", [])
        closed = []
        skipped = []
        for trade in trades:
            extensions = trade.get("clientExtensions", {})
            trade_comment = extensions.get("comment") if extensions else None
            trade_id = trade.get("id")
            if trade_id is None:
                skipped.append(trade)
                continue
            if trade_comment == comment:
                closed.append(self.close_trade(int(trade_id)))
            else:
                skipped.append(trade)
        return {"closed": closed, "skipped": skipped}

    def close_same_tag(self, tag: str) -> Dict[str, Any]:
        """Close all trades with matching tag in clientExtensions (OANDA equivalent to MT's close_magic)."""
        trades = self.list_trades().get("trades", [])
        closed = []
        skipped = []
        for trade in trades:
            extensions = trade.get("clientExtensions", {})
            trade_tag = extensions.get("tag") if extensions else None
            trade_id = trade.get("id")
            if trade_id is None:
                skipped.append(trade)
                continue
            if trade_tag == tag:
                closed.append(self.close_trade(int(trade_id)))
            else:
                skipped.append(trade)
        return {"closed": closed, "skipped": skipped}

    def get_trade_details(self, trade_id: int) -> Dict[str, Any]:
        """Get details of a specific trade."""
        return self._request("GET", f"/trades/{trade_id}")

    def get_order_details(self, order_id: int) -> Dict[str, Any]:
        """Get details of a specific order."""
        return self._request("GET", f"/orders/{order_id}")

    def cancel_order(self, order_id: int) -> Dict[str, Any]:
        """Cancel a pending order."""
        return self._request("PUT", f"/orders/{order_id}/cancel")

    def modify_order(
        self,
        order_id: int,
        *,
        price: Optional[float] = None,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Modify a pending order."""
        exp_str = None
        if expiration:
            if isinstance(expiration, datetime):
                exp_str = expiration.astimezone(timezone.utc).isoformat()
            else:
                exp_str = datetime.fromtimestamp(
                    expiration, tz=timezone.utc
                ).isoformat()

        return self._request(
            "PUT",
            f"/orders/{order_id}",
            data={
                "price": price,
                "sl": sl,
                "tp": tp,
                "expiration": exp_str,
            },
        )

    def modify_trade(
        self,
        trade_id: int,
        *,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Modify SL/TP for an open trade."""
        return self._request(
            "PUT",
            f"/trades/{trade_id}",
            data={
                "sl": sl,
                "tp": tp,
            },
        )

    # ==================== RISK MANAGEMENT ====================

    def kill_switch(self) -> Dict[str, Any]:
        """Close all positions and cancel all pending orders."""
        return self._request("POST", "/kill-switch")

    # ==================== HISTORY ====================

    def get_history(
        self,
        start_date: Optional[Union[datetime, str, int]] = None,
        as_df: bool = False,
    ) -> Union[Dict[str, Any], "pd.DataFrame"]:
        """Get transaction history."""
        params = {}
        if start_date:
            if isinstance(start_date, datetime):
                params["start_date"] = start_date.astimezone(timezone.utc).isoformat()
            else:
                params["start_date"] = str(start_date)
        response = self._request("GET", "/transactions", params=params or None)
        if not as_df:
            return response

        transactions = response.get("transactions", []) or []
        if not transactions:
            return pd.DataFrame()

        def _to_utc_timestamp(value: Any) -> "pd.Timestamp":
            if value in (None, ""):
                return pd.NaT
            return pd.to_datetime(value, utc=True, errors="coerce")

        def _to_float(value: Any) -> Optional[float]:
            if value in (None, ""):
                return None
            try:
                return float(value)
            except (TypeError, ValueError):
                return None

        def _first_valid(frame: "pd.DataFrame", column: str) -> Any:
            if column not in frame.columns:
                return None
            valid = frame[column].dropna()
            return valid.iloc[0] if not valid.empty else None

        def _weighted_avg(
            frame: "pd.DataFrame", price_col: str, units_col: str
        ) -> Optional[float]:
            if frame.empty or price_col not in frame.columns:
                return None
            prices = pd.to_numeric(frame[price_col], errors="coerce")
            if units_col in frame.columns:
                units = pd.to_numeric(frame[units_col], errors="coerce")
            else:
                units = pd.Series(1.0, index=frame.index, dtype=float)
            valid = prices.notna() & units.notna()
            if not valid.any():
                return None
            prices = prices[valid]
            units = units[valid]
            units_sum = float(units.sum())
            if units_sum <= 0:
                return float(prices.iloc[-1])
            return float((prices * units).sum() / units_sum)

        trade_events: List[Dict[str, Any]] = []
        for tx in transactions:
            tx_id = tx.get("id")
            tx_type = str(tx.get("type", "")).upper()
            tx_time = _to_utc_timestamp(tx.get("time"))
            instrument = tx.get("instrument")
            order_id = tx.get("orderID")
            reason = tx.get("reason")
            tx_price = _to_float(tx.get("price"))
            tx_units = _to_float(tx.get("units"))
            tx_pl = _to_float(tx.get("pl")) or 0.0
            tx_financing = _to_float(tx.get("financing")) or 0.0
            tx_commission = _to_float(tx.get("commission")) or 0.0
            tx_half_spread = _to_float(tx.get("halfSpreadCost")) or 0.0

            comment = None
            client_ext = tx.get("clientExtensions")
            if isinstance(client_ext, dict):
                comment = client_ext.get("comment")

            mapped = False

            trade_opened = tx.get("tradeOpened")
            if (
                isinstance(trade_opened, dict)
                and trade_opened.get("tradeID") is not None
            ):
                raw_units = _to_float(trade_opened.get("units"))
                signed_units = raw_units if raw_units is not None else (tx_units or 0.0)
                trade_events.append(
                    {
                        "trade_id": str(trade_opened.get("tradeID")),
                        "instrument": instrument,
                        "side": "BUY" if signed_units >= 0 else "SELL",
                        "event": "OPEN",
                        "event_time": tx_time,
                        "tx_id": tx_id,
                        "order_id": order_id,
                        "tx_type": tx_type,
                        "reason": reason,
                        "comment": comment,
                        "open_units": abs(signed_units),
                        "close_units": 0.0,
                        "open_price": _to_float(trade_opened.get("price")) or tx_price,
                        "close_price": None,
                        "realized_pl": tx_pl,
                        "financing": tx_financing,
                        "commission": tx_commission,
                        "half_spread_cost": tx_half_spread,
                    }
                )
                mapped = True

            for closed in tx.get("tradesClosed", []) or []:
                if not isinstance(closed, dict) or closed.get("tradeID") is None:
                    continue
                raw_units = _to_float(closed.get("units"))
                signed_units = raw_units if raw_units is not None else (tx_units or 0.0)
                trade_events.append(
                    {
                        "trade_id": str(closed.get("tradeID")),
                        "instrument": instrument,
                        "side": "BUY" if signed_units >= 0 else "SELL",
                        "event": "CLOSE",
                        "event_time": tx_time,
                        "tx_id": tx_id,
                        "order_id": order_id,
                        "tx_type": tx_type,
                        "reason": reason,
                        "comment": comment,
                        "open_units": 0.0,
                        "close_units": abs(signed_units),
                        "open_price": None,
                        "close_price": _to_float(closed.get("price")) or tx_price,
                        "realized_pl": _to_float(closed.get("realizedPL")) or tx_pl,
                        "financing": _to_float(closed.get("financing")) or tx_financing,
                        "commission": _to_float(closed.get("commission"))
                        or tx_commission,
                        "half_spread_cost": _to_float(closed.get("halfSpreadCost"))
                        or tx_half_spread,
                    }
                )
                mapped = True

            trade_reduced = tx.get("tradeReduced")
            if (
                isinstance(trade_reduced, dict)
                and trade_reduced.get("tradeID") is not None
            ):
                raw_units = _to_float(trade_reduced.get("units"))
                signed_units = raw_units if raw_units is not None else (tx_units or 0.0)
                trade_events.append(
                    {
                        "trade_id": str(trade_reduced.get("tradeID")),
                        "instrument": instrument,
                        "side": "BUY" if signed_units >= 0 else "SELL",
                        "event": "REDUCE",
                        "event_time": tx_time,
                        "tx_id": tx_id,
                        "order_id": order_id,
                        "tx_type": tx_type,
                        "reason": reason,
                        "comment": comment,
                        "open_units": 0.0,
                        "close_units": abs(signed_units),
                        "open_price": None,
                        "close_price": _to_float(trade_reduced.get("price"))
                        or tx_price,
                        "realized_pl": _to_float(trade_reduced.get("realizedPL"))
                        or tx_pl,
                        "financing": _to_float(trade_reduced.get("financing"))
                        or tx_financing,
                        "commission": _to_float(trade_reduced.get("commission"))
                        or tx_commission,
                        "half_spread_cost": _to_float(
                            trade_reduced.get("halfSpreadCost")
                        )
                        or tx_half_spread,
                    }
                )
                mapped = True

            direct_trade_id = tx.get("tradeID")
            if not mapped and direct_trade_id is not None:
                signed_units = tx_units or 0.0
                trade_events.append(
                    {
                        "trade_id": str(direct_trade_id),
                        "instrument": instrument,
                        "side": "BUY" if signed_units >= 0 else "SELL",
                        "event": tx_type or "EVENT",
                        "event_time": tx_time,
                        "tx_id": tx_id,
                        "order_id": order_id,
                        "tx_type": tx_type,
                        "reason": reason,
                        "comment": comment,
                        "open_units": 0.0,
                        "close_units": 0.0,
                        "open_price": None,
                        "close_price": tx_price,
                        "realized_pl": tx_pl,
                        "financing": tx_financing,
                        "commission": tx_commission,
                        "half_spread_cost": tx_half_spread,
                    }
                )

        if not trade_events:
            df = pd.json_normalize(transactions, sep="_")
            if "time" in df.columns:
                df["time"] = df["time"].map(_to_utc_timestamp)
                df.sort_values("time", inplace=True)
            return df

        events_df = pd.DataFrame(trade_events)
        for col in (
            "open_units",
            "close_units",
            "open_price",
            "close_price",
            "realized_pl",
            "financing",
            "commission",
            "half_spread_cost",
        ):
            if col in events_df.columns:
                events_df[col] = pd.to_numeric(events_df[col], errors="coerce")
        if "event_time" in events_df.columns:
            events_df["event_time"] = events_df["event_time"].map(_to_utc_timestamp)

        rows: List[Dict[str, Any]] = []
        grouped = events_df.groupby("trade_id", dropna=False, sort=False)
        for trade_id, group in grouped:
            group = group.sort_values("event_time")
            opens = group[group["event"] == "OPEN"]
            closes = group[group["event"].isin(["CLOSE", "REDUCE"])]

            open_units = (
                float(opens["open_units"].fillna(0.0).sum())
                if "open_units" in opens.columns
                else 0.0
            )
            close_units = (
                float(closes["close_units"].fillna(0.0).sum())
                if "close_units" in closes.columns
                else 0.0
            )
            remaining_units = max(open_units - close_units, 0.0)

            status = "open"
            if open_units == 0 and close_units > 0:
                status = "closed"
            elif open_units > 0 and close_units >= (open_units - 1e-9):
                status = "closed"

            closes_desc = closes.sort_values("event_time", ascending=False)
            row: Dict[str, Any] = {
                "trade_id": trade_id,
                "instrument": _first_valid(opens, "instrument")
                or _first_valid(group, "instrument"),
                "side": _first_valid(opens, "side") or _first_valid(group, "side"),
                "status": status,
                "open_time": (
                    opens["event_time"].min()
                    if ("event_time" in opens.columns and not opens.empty)
                    else (
                        group["event_time"].min()
                        if "event_time" in group.columns
                        else pd.NaT
                    )
                ),
                "close_time": (
                    closes["event_time"].max()
                    if ("event_time" in closes.columns and not closes.empty)
                    else pd.NaT
                ),
                "open_tx_id": _first_valid(opens, "tx_id"),
                "close_tx_id": _first_valid(closes_desc, "tx_id"),
                "open_order_id": _first_valid(opens, "order_id"),
                "close_order_id": _first_valid(closes_desc, "order_id"),
                "open_price": _weighted_avg(opens, "open_price", "open_units"),
                "close_price": _weighted_avg(closes, "close_price", "close_units"),
                "open_units": open_units,
                "close_units": close_units,
                "remaining_units": remaining_units,
                "gross_profit": float(group["realized_pl"].fillna(0.0).sum()),
                "financing": float(group["financing"].fillna(0.0).sum()),
                "commission": float(group["commission"].fillna(0.0).sum()),
                "half_spread_cost": float(group["half_spread_cost"].fillna(0.0).sum()),
                "comment": _first_valid(opens, "comment")
                or _first_valid(group, "comment"),
                "open_reason": _first_valid(opens, "reason"),
                "close_reason": _first_valid(closes_desc, "reason"),
                "event_count": int(len(group)),
            }
            row["net_pnl"] = row["gross_profit"] + row["financing"] + row["commission"]
            rows.append(row)

        trades_df = pd.DataFrame(rows)
        if not trades_df.empty and "open_time" in trades_df.columns:
            trades_df.sort_values("open_time", inplace=True)
        return trades_df

    # ==================== UTILITY ====================

    def get_conversion_rate(
        self, counter_currency: str, accnt_currency: str = "USD"
    ) -> float:
        """Get conversion rate between two currencies."""
        resp = self.session.get(
            f"https://api.frankfurter.dev/v1/latest?base={counter_currency}&symbols={accnt_currency}",
            timeout=self.timeout,
        ).json()
        rates = resp.get("rates", {})
        if accnt_currency in rates:
            return float(rates[accnt_currency])
        raise RuntimeError(f"Rate not found for {counter_currency} to {accnt_currency}")

    def close(self) -> None:
        """Close the HTTP session."""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
