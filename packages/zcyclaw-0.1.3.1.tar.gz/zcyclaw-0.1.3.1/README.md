# zcyclaw

政府采购智能顾问 — 基于 RAG 的法规问答 CLI 工具。

独立于采购平台，基于中国政府采购法律法规提供专业问答、采购方式推荐等功能。核心开源，数据本地存储，隐私第一。

## 功能

- **法规智能问答**：基于 16 部核心法规（766 条法条），回答自动标注法条来源
- **流式输出**：token-by-token 逐字显示，体验流畅
- **多 LLM 支持**：DeepSeek / 智谱 GLM / 通义千问 / Moonshot / MiniMax / OpenAI / Ollama / Anthropic
- **开箱即用**：预构建法规数据随包分发，安装即可使用
- **本地优先**：向量库、配置、日志全部本地存储，API Key 直连 LLM 厂商

## 快速开始

```bash
# 安装
uv tool install zcyclaw

# 或使用 pip
pip install zcyclaw

# 初始化配置（选择 LLM 提供商 + 输入 API Key）
zcyclaw init

# 单次问答
zcyclaw ask "询价采购需要满足什么条件？"

# 交互式多轮问答
zcyclaw ask -i

# 更新法规数据
zcyclaw update

# 查看数据统计
zcyclaw stats
```

## 配置

配置文件位置：`~/.zcyclaw/config.json`

### 交互式配置

运行 `zcyclaw init` 将引导完成以下配置：

1. **选择提供商**：从已注册列表中选择
2. **API Key**：输入对应厂商的 API Key（Ollama 不需要）
3. **模型名称**：可使用默认值，也可自定义为其他模型（如 `deepseek-reasoner`、`glm-4-plus`）
4. **API 地址**：可使用默认值，也可自定义为兼容 OpenAI 协议的第三方地址

### 手动编辑

直接编辑 `~/.zcyclaw/config.json`：

```json
{
  "default_provider": "deepseek",
  "providers": {
    "deepseek": {
      "api_key": "sk-xxx",
      "base_url": "https://api.deepseek.com/v1",
      "model": "deepseek-chat",
      "temperature": 0.3,
      "max_tokens": 2048
    },
    "minimax": {
      "api_key": "sk-xxx",
      "base_url": "https://api.minimax.chat/v1",
      "model": "MiniMax-Text-01",
      "temperature": 0.3,
      "max_tokens": 2048
    }
  }
}
```

### 环境变量覆盖

前缀 `ZCYCLAW_`，双下划线分隔嵌套：

```bash
export ZCYCLAW_PROVIDERS__DEEPSEEK__API_KEY=sk-xxx
export ZCYCLAW_PROVIDERS__DEEPSEEK__MODEL=deepseek-reasoner
export ZCYCLAW_DEFAULT_PROVIDER=deepseek
```

### 支持的提供商

| 提供商 | 默认模型 | 需要API Key |
|--------|---------|------------|
| DeepSeek | deepseek-chat | 是 |
| 智谱 GLM | glm-4-flash | 是 |
| 通义千问 | qwen-turbo | 是 |
| Moonshot | moonshot-v1-8k | 是 |
| MiniMax | MiniMax-Text-01 | 是 |
| OpenAI | gpt-4o-mini | 是 |
| Ollama | qwen2.5:7b | 否 |
| Anthropic | claude-sonnet-4-20250514 | 是 |

## 可选安装

```bash
# Anthropic 后端支持
uv tool install "zcyclaw[anthropic]"

# 本地 Embedding（fastembed/BGE-M3）
uv tool install "zcyclaw[fastembed]"

# 完整安装
uv tool install "zcyclaw[full]"
```

## 内置法规

| 效力层级 | 法规 |
|----------|------|
| 法律 | 政府采购法、招标投标法 |
| 行政法规 | 政府采购法实施条例、招标投标法实施条例 |
| 部门规章 | 货物和服务招标投标管理办法、非招标采购方式管理办法、竞争性磋商采购方式管理暂行办法、框架协议采购方式管理暂行办法、促进中小企业发展管理办法、需求管理办法、信息公开办法、评审专家管理办法、进口产品管理办法、代理机构管理暂行办法、政府和社会资本合作项目政府采购管理办法、关于促进政府采购公平竞争优化营商环境的通知 |

## 技术栈

Python 3.11+ / Typer / Rich / Pydantic / ChromaDB / httpx / loguru

## 许可证

MIT License
