# RAG + CLI 工具：技术与市场调研报告

> 调研日期：2026-04-29
> 项目背景：基于 RAG 架构的政府采购领域 CLI 智能顾问工具，使用 ChromaDB 做向量存储，支持多 LLM 厂商，uv/pipx 安装分发

---

## 一、类似的开源 RAG CLI 工具项目

### 1.1 法律法规相关 RAG 项目

| 项目 | GitHub 地址 | Stars | 技术栈 | 特点 | 活跃度 |
|------|------------|-------|--------|------|--------|
| **ChatLaw** | github.com/PKU-YuanGroup/ChatLaw | ~4.5K | LLM + MoE + 知识图谱 + 多Agent | 北大团队，法律领域专用大模型，ChatLaw-TextVec 做文本向量化，MoE+知识图谱+多Agent协作降低幻觉 | 中等，论文驱动 |
| **law-cn-ai** | github.com/lvwzhen/law-cn-ai | ~5K | Next.js + Supabase + pgvector + OpenAI | 中国法律 AI 助手，将开源法律法规数据(LawRefBook/Laws)向量化后接入 ChatGPT，Web 端非 CLI | 低，维护较少 |
| **LawRefBook/Laws** | github.com/LawRefBook/Laws | ~2K | 纯数据 | 中国法律法规开源数据集，是 law-cn-ai 的数据来源 | 中等，数据更新 |

**关键发现**：
- 法律领域 RAG 项目数量有限，且大多面向 Web 端，**CLI 形态的法律 RAG 工具几乎空白**
- ChatLaw 是学术影响力最大的项目，但定位是大模型研究而非工具产品
- law-cn-ai 验证了法律法规向量化+问答的可行性，但技术栈较老(Next.js + pgvector)，未做 CLI 化

### 1.2 通用知识库 RAG 问答工具

| 项目 | GitHub 地址 | Stars | 技术栈 | 形态 | 活跃度 |
|------|------------|-------|--------|------|--------|
| **PrivateGPT** | github.com/imartinez/privateGPT | ~55K | FastAPI + LlamaIndex + Qdrant/Chroma | API + Gradio UI | 高，持续更新 |
| **RAGFlow** | github.com/infiniflow/ragflow | ~47K | DeepDoc + ES + MinIO + MySQL | Web UI | 高，企业级 |
| **Dify** | github.com/langgenius/dify | ~90K+ | Flask + LangChain + 多向量库 | Web 平台 | 高，商业化 |
| **Kotaemon** | github.com/Cinnamon/kotaemon | ~18K | Gradio + 多LLM/Embedding | Web UI | 高 |
| **QAnything** | github.com/netease-youdao/QAnything | ~6K | LangChain + FastChat + BCEmbedding | Docker 全栈 | 中等 |
| **AnythingLLM** | github.com/Mintplex-Labs/anything-llm | ~35K | LanceDB + 多LLM | 桌面客户端 + Web | 高 |
| **Embedchain** | github.com/kael-aiur/embedchain | ~20K | LangChain + Chroma | Python SDK | 中等 |
| **FastGPT** | github.com/labring/FastGPT | ~22K | Next.js + MongoDB + PgVector | Web 平台 | 高 |

**关键发现**：
- **RAG 领域的主流产项目几乎全是 Web/桌面 GUI 形态**，CLI 形态的 RAG 工具市场极度空白
- PrivateGPT 架构最接近本项目：支持多 LLM、多 Embedding、多向量库，API 优先设计
- QAnything 值得关注：网易有道出品，中文优化，使用自研 BCEmbedding，支持离线部署

### 1.3 本地化 RAG 方案

| 方案 | 硬件要求 | 离线能力 | 中文支持 | 适用场景 |
|------|---------|---------|---------|---------|
| **PrivateGPT (本地模式)** | GPU 8GB+ (LlamaCPP) | 完全离线 | 一般(需中文模型) | 高隐私场景 |
| **QAnything** | GPU 16GB+ (3090) | 完全离线(断网安装) | 优秀(中文专项优化) | 企业本地部署 |
| **AnythingLLM** | 4GB+ RAM | API 模式需联网 | 一般 | 个人桌面使用 |
| **LocalGPT** | GPU 8GB+ | 完全离线 | 差 | 英文文档问答 |

### 1.4 竞品空白分析

**本项目 (政府采购 RAG CLI) 的差异化定位**：
1. **唯一 CLI 形态的法律/政采 RAG 工具** -- 无直接竞品
2. **轻量级本地部署** -- 无需 GPU，使用 API 模型 + 本地向量库
3. **垂直领域深耕** -- 政府采购法规、招标文件，非通用知识库
4. **开发者友好** -- uv/pipx 一键安装，集成到工作流

---

## 二、RAG 技术方案对比

### 2.1 向量数据库对比（CLI 场景）

| 特性 | **ChromaDB** | FAISS | Qdrant | Milvus | Weaviate |
|------|-------------|-------|--------|--------|----------|
| **部署方式** | 嵌入式（纯Python） | 纯库（C++/Python） | 独立服务/Docker | 独立服务/Docker | 独立服务/Docker |
| **CLI 友好度** | **极高** | 高 | 中 | 低 | 低 |
| **安装体积** | ~50MB (pip) | ~30MB | 需 Docker/二进制 | 需 Docker | 需 Docker |
| **持久化** | 内建(PersistentClient) | 需手动保存 | 内建 | 内建 | 内建 |
| **元数据过滤** | 支持 | 不支持 | 支持(强) | 支持(强) | 支持(强) |
| **数据规模** | 万~十万级 | 百万~亿级 | 千万级 | 亿级 | 千万级 |
| **实时更新** | 支持 | 需重建索引 | 支持 | 支持 | 支持 |
| **社区生态** | LangChain/LlamaIndex 原生支持 | 成熟但独立 | 增长快 | 企业级 | 成熟 |
| **GitHub Stars** | ~18K | ~34K | ~24K | ~30K | ~14K |
| **依赖复杂度** | 低(pip install) | 低 | 中(需运行服务) | 高(Docker 栈) | 高(Docker 栈) |
| **适合 CLI 分发** | **最佳** | 好 | 差 | 差 | 差 |

**选型建议**：

对于 CLI 工具场景，**ChromaDB 是最合理的选择**，原因：
1. 嵌入式运行，无需额外服务进程，`pip install chromadb` 即可
2. PersistentClient 直接写入本地文件，数据跟随项目目录
3. 元数据过滤支持法规分类检索（如按法规类型、发布年份过滤）
4. LangChain/LlamaIndex 一等公民支持

**备选方案 FAISS**：如果对安装体积极端敏感，FAISS 更轻量，但缺少元数据过滤和持久化管理，需自行封装。

**不推荐 Qdrant/Milvus/Weaviate**：它们是服务端方案，需要独立进程或 Docker，违背 CLI 工具"开箱即用"的原则。

### 2.2 Embedding 方案对比

| 模型 | 维度 | 输入长度 | 中文能力 | 开源 | 大小 | API 可用 | 适合场景 |
|------|------|---------|---------|------|------|---------|---------|
| **BGE-M3** | 1024 | 8192 tokens | **极强**(100+语言) | 是 | ~2.2GB | 是(FlagEmbedding) | 长文本、跨语言、混合检索 |
| **bge-large-zh-v1.5** | 1024 | 512 tokens | **最强中文** | 是 | ~1.3GB | 是 | 短文本中文检索 |
| **M3E-large** | 1024 | 512 tokens | 强(中文专项) | 是 | ~1.3GB | 是 | 中文问答场景 |
| **BCEmbedding** | 768 | 512 tokens | 强(有道出品) | 是 | ~1.1GB | 是 | 中文双语场景 |
| **OpenAI text-embedding-3** | 1536/3072 | 8191 tokens | 强 | 否(闭源) | N/A | 仅 API | API 优先场景 |
| **GTE-Qwen2-7B** | 3584 | 32K tokens | 极强 | 是 | ~15GB | 是 | 超长文本、高精度 |
| **fastembed(BAAI/bge-small-zh)** | 384 | 512 tokens | 中等 | 是 | ~130MB | 是 | 轻量本地部署 |

**中文法规检索场景分析**：

对于政府采购 CLI 工具的 Embedding 选择，需要考虑三种模式：

**模式 A：纯 API 模式（推荐起步方案）**
- 使用 OpenAI / 智谱 / 阿里云等 Embedding API
- 优点：零本地资源消耗，安装体积最小
- 缺点：需联网，API 费用，数据隐私
- 推荐模型：OpenAI text-embedding-3-small 或 智谱 embedding-3

**模式 B：本地轻量模型（推荐进阶方案）**
- 使用 fastembed + bge-small-zh，仅 ~130MB
- 优点：离线可用，安装体积可控
- 缺点：中文长法规检索精度有损失
- 适合：CLI 工具首次安装体验

**模式 C：本地高精度模型（专业方案）**
- 使用 BGE-M3，支持 8K tokens + 混合检索(稠密+稀疏+多向量)
- 优点：政务文档测试首条命中率 83%，法律领域微调后专业术语召回率 89%
- 缺点：模型 ~2.2GB，FP16 显存 6.8GB，CPU 推理较慢
- 适合：高频专业用户

**推荐策略**：默认 API 模式，可选本地 fastembed 轻量模型，高级用户可下载 BGE-M3。

### 2.3 RAG 框架对比

| 维度 | **LangChain** | **LlamaIndex** | **自研方案** |
|------|-------------|----------------|-------------|
| **定位** | 通用 LLM 应用框架 | 专用 RAG/索引框架 | 针对需求定制 |
| **RAG 专注度** | 中（RAG 是功能之一） | 高（核心就是 RAG） | 最高 |
| **学习曲线** | 陡峭（概念多、抽象层多） | 中等 | 取决于设计 |
| **代码量** | 引入大，依赖链长 | 中等 | 可控 |
| **CLI 体积影响** | 大（+200MB 依赖） | 中（+100MB 依赖） | 小 |
| **灵活性** | 高（但改动链条长） | 中（索引逻辑较固定） | 最高 |
| **中文法规适配** | 需大量定制 | 需定制 | 天然适配 |
| **社区/生态** | 最大（100K+ stars） | 大（38K+ stars） | 无 |
| **版本稳定性** | 差（频繁 breaking changes） | 中等 | 完全可控 |
| **适合本项目** | **不推荐** | **可选** | **推荐** |

**选型建议**：

**推荐自研方案**，理由：
1. **体积控制**：CLI 工具对安装体积敏感，LangChain 引入的依赖链过长
2. **领域特化**：政府采购法规有独特的结构（条款引用、效力层级、时效性），通用框架反而增加适配成本
3. **稳定性**：LangChain 频繁的 breaking changes 对 CLI 工具是致命的
4. **核心功能简单**：一个 RAG CLI 只需要：文档加载 -> 分块 -> Embedding -> 存储 -> 检索 -> 生成，自研代码量不大

**可借鉴 LlamaIndex 的**：文档分块策略、查询引擎设计模式

**自研方案核心组件**：
```
文档加载器 (PDF/HTML/Markdown) -> 法规专用分块器 (按条款/章节)
    -> Embedding 适配层 (API/本地模型切换)
    -> ChromaDB 存储层 (含元数据)
    -> 检索器 (向量相似度 + 元数据过滤 + 重排序)
    -> LLM 生成层 (多厂商 API 适配)
```

---

## 三、CLI 分发方式现状

### 3.1 分发渠道对比

| 特性 | **uv tool install** | **pipx** | **Homebrew** | **pip install** |
|------|-------------------|---------|-------------|----------------|
| **成熟度** | 快速增长中(2024-) | 成熟(2019-) | 成熟(macOS) | 最成熟 |
| **安装速度** | 极快(Rust 引擎) | 中等 | 中等 | 慢 |
| **环境隔离** | 自动(独立 venv) | 自动(独立 venv) | 自动(独立 cellar) | 不隔离 |
| **适用平台** | 全平台 | 全平台 | macOS/Linux | 全平台 |
| **用户群** | 早期采纳者/开发者 | Python 开发者 | macOS 用户 | 所有人 |
| **CLI 工具支持** | 原生支持 [project.scripts] | 原生支持 | 需维护 Formula | 需手动添加 PATH |
| **GitHub Stars** | ~47K | ~10K | ~42K | N/A |
| **安装命令** | `uv tool install zcyclaw` | `pipx install zcyclaw` | `brew install zcyclaw` | `pip install zcyclaw` |
| **国内可用性** | 需配置镜像 | 需配置镜像 | 需配置镜像 | 可用国内镜像 |

### 3.2 uv vs pipx 详细对比

**uv tool install 优势**：
- 速度：比 pipx 快 10-100 倍（Rust 引擎）
- 自动管理 Python 版本（可自动下载缺失版本）
- 依赖解析更快更准确
- 2025-2026 年增长极快，新项目 README 中 `uv pip install` 已逐渐取代 `pip install`
- 支持 `uvx` 命令直接运行（无需安装，类似 npx）

**pipx 优势**：
- 更成熟，文档完善，社区认知度高
- 所有 Python 开发者都了解
- 稳定性好，breaking changes 少

**推荐策略**：
- **主推 `uv tool install`**：作为首选安装方式，覆盖追求效率的开发者
- **兼容 `pipx install`**：作为备选，覆盖保守用户
- **支持 `pip install`**：最后兜底

### 3.3 捆绑向量库分发的实践与挑战

**核心问题**：向量库数据（法规向量化结果）如何随 CLI 工具一起分发？

**方案对比**：

| 方案 | 安装体积 | 首次体验 | 更新难度 | 适用场景 |
|------|---------|---------|---------|---------|
| A. 预构建向量库打包 | 大(50MB-500MB) | 即装即用 | 需重新发布版本 | 数据量小且稳定 |
| B. 首次运行时下载 | 小(~10MB 安装包) | 需等待下载 | 灵活更新 | 需联网场景 |
| C. 首次运行时构建 | 小(~10MB 安装包) | 需长时间构建 | 灵活更新 | 离线+有原始文档 |
| D. 混合方案 | 中 | 中等 | 平衡 | 推荐 |

**实践案例**：
- **PrivateGPT**：方案 C，首次运行时从原始文档构建向量库
- **AnythingLLM**：方案 B，预置基础向量库，在线可更新
- **Embedchain**：方案 C，运行时构建

**挑战**：
1. **ChromaDB 依赖体积**：`pip install chromadb` 及其依赖链约 50-100MB
2. **Embedding 模型体积**：BGE-M3 约 2.2GB，bge-small-zh 约 130MB
3. **预构建向量库体积**：政府采购全量法规向量化后约 100-500MB（取决于法规数量和维度）
4. **ChromaDB 安装问题**：在某些 Linux 环境（CentOS 7 等）需较新版本的 gcc 才能编译 chroma-hnswlib

**推荐方案 D（混合方案）**：
```
安装时：仅安装核心 CLI + ChromaDB 依赖（~80MB）
首次运行：
  1. 检测本地是否有预构建向量库
  2. 有 -> 直接加载
  3. 无 -> 提示用户选择：
     a. 从 CDN 下载预构建向量库（推荐，~100-200MB）
     b. 从原始文档重新构建（需 Embedding 模型/API）
```

### 3.4 首次使用体验的关键问题

**核心指标**：从安装到第一次有效查询的时间（Time-to-First-Query, TTFQ）

| 场景 | 预期 TTFQ | 瓶颈 |
|------|----------|------|
| uv tool install + 下载向量库 | 2-5 分钟 | 网络下载向量库 |
| uv tool install + 在线构建(API模式) | 5-15 分钟 | API 调用 Embedding |
| uv tool install + 在线构建(本地模型) | 15-60 分钟 | 本地模型推理 |
| pip install + 下载向量库 | 5-10 分钟 | pip 依赖安装较慢 |

**优化建议**：
1. 提供最小安装包 + 预构建向量库 CDN 下载
2. 首次运行向导：选择 LLM 厂商 -> 选择 Embedding 方案 -> 下载/构建向量库
3. 内置 demo 向量库（10 条法规），确保 30 秒内可体验
4. `uvx zcyclaw` 免安装直接运行体验

---

## 四、Playwright 爬虫方案评估

### 4.1 中国政府采购网爬取可行性

**目标网站**：ccgp.gov.cn（中国政府采购网），search.ccgp.gov.cn（搜索子站）

**网站技术特征分析**：

| 特征 | 分析 |
|------|------|
| 页面渲染 | 部分动态加载（JavaScript 渲染列表） |
| 反爬机制 | 中等：521 状态码 + JavaScript 生成 Cookie（__jsl_clearance） |
| 请求加密 | 搜索接口参数有编码加密 |
| 验证码 | 高频访问触发验证码 |
| 数据量 | 累计招标/采购公告数十万条 |

**已有实践**：
- GitHub 项目 `Clemente420/ccgp_gov` 使用 Selenium 爬取政府采购网
- 多个技术博客记录了使用 requests + BeautifulSoup、Selenium 等方案的爬取实践
- 搜索接口 `search.ccgp.gov.cn/bxsearch` 可通过参数构造查询

### 4.2 反爬机制应对方案

| 反爬措施 | 应对方案 | 难度 |
|---------|---------|------|
| **521 状态码 + JS Cookie** | Playwright 无头浏览器自动执行 JS 获取 Cookie | 中等 |
| **请求频率限制** | 随机延时 + 代理轮换 | 低 |
| **User-Agent 检测** | Playwright 设置真实 UA | 低 |
| **参数加密** | Playwright 直接操作页面，绕过加密 | 中等 |
| **验证码** | 降低爬取频率避免触发；手动处理 | 中等 |
| **IP 封锁** | 代理池 + 限速 | 中等 |

**Playwright 方案优势**：
- 自动执行 JavaScript，绕过 JS Cookie 生成
- 模拟真实浏览器行为，降低被识别为爬虫的概率
- 已有成功案例：中国联通采购网、中国移动采购网均可用 Playwright 爬取
- 支持无头模式，适合 CLI 工具集成

**Playwright 方案劣势**：
- 安装体积大：Chromium 浏览器约 150-200MB
- 资源消耗：每个浏览器实例约 100-300MB 内存
- 速度较慢：相比直接 HTTP 请求慢 5-10 倍

### 4.3 替代方案评估

| 方案 | 优势 | 劣势 | 推荐度 |
|------|------|------|--------|
| **Playwright** | 绕过反爬能力强，成熟稳定 | 体积大(200MB+) | 中 |
| **Selenium** | 社区成熟，案例多 | 速度慢，维护少 | 低 |
| **requests + JS 逆向** | 轻量，速度快 | 需逆向 JS，维护成本高 | 中 |
| **官方 API/数据源** | 合规，稳定 | 可能不存在或受限 | 需调研 |
| **预构建数据包** | 零爬虫依赖 | 需要数据源 | **高** |
| **第三方数据平台** | 数据结构化，合规 | 可能付费 | 高 |
| **手动导入** | 用户自主控制 | 用户体验差 | 兜底 |

**推荐策略**：

**阶段一（MVP）**：预构建数据包
- 自行编写一次性爬虫（可用 Playwright）采集法规数据
- 构建向量库后打包发布到 CDN/GitHub Release
- CLI 工具首次运行时下载预构建数据包
- **不将 Playwright 作为 CLI 工具的运行时依赖**

**阶段二（增量更新）**：轻量级增量爬取
- 使用 requests + BeautifulSoup 做增量数据采集
- 仅爬取新增/变更的法规
- 作为后台定时任务，非用户直接调用

**阶段三（高级功能）**：可选的 Playwright 爬取模块
- 作为可选扩展 `pip install zcyclaw[crawler]`
- 用户可自行爬取自定义数据源
- 按需安装 Playwright，不影响基础安装体积

### 4.4 政府采购网数据获取的合规性考量

- 政府采购信息属于**公开信息**，爬取用于个人/企业内部研究一般不违法
- 但需注意：遵守 robots.txt、控制访问频率、不破坏网站正常运行
- 最佳实践：**优先寻找官方数据开放渠道**（如 API、数据开放平台、数据下载服务）
- 财政部主办的政府采购网可能有数据接口服务，需进一步调研

---

## 五、技术风险点分析

### 5.1 向量库打包分发的体积问题

**风险评估：中高**

| 组件 | 体积 | 必选/可选 |
|------|------|----------|
| CLI 核心代码 | <1MB | 必选 |
| ChromaDB + 依赖 | ~50-100MB | 必选 |
| 预构建向量库(示例数据) | ~10-50MB | 推荐 |
| 预构建向量库(全量法规) | ~100-500MB | 可选下载 |
| Embedding 模型(fastembed) | ~130MB | 可选 |
| Embedding 模型(BGE-M3) | ~2.2GB | 可选 |
| Playwright + Chromium | ~200MB | 可选 |

**最小安装体积估算**：~80-120MB（CLI + ChromaDB + 示例数据）

**缓解措施**：
1. 分层安装：核心包最小化，扩展功能通过 extras 可选安装
2. 预构建向量库通过 CDN 独立下载，不打包在安装包中
3. Embedding 模型按需下载，首次使用时提示
4. 考虑使用 SQLite + faiss-cpu 替代 ChromaDB 以减小体积（但牺牲元数据过滤能力）

### 5.2 Embedding 模型选择对中文法规检索效果的影响

**风险评估：中**

| 场景 | bge-large-zh-v1.5 | BGE-M3 | OpenAI API | fastembed |
|------|-------------------|--------|-----------|-----------|
| 短法规标题检索 | **最优** | 优 | 优 | 良 |
| 长法规全文检索 | 良(需分块) | **最优**(8K) | 优 | 中(精度低) |
| 跨法规引用检索 | 良 | **优**(混合检索) | 良 | 差 |
| 法规时效性判断 | 需定制 | 需定制 | 需定制 | 需定制 |
| 专业术语检索 | 优 | **优**(微调后89%) | 优 | 中 |

**关键风险**：
1. **通用 Embedding 模型对法律术语的语义理解有限**：如"招标""投标""中标"的细微差别
2. **法规引用链的检索困难**：法规 A 引用法规 B 条款 C，需跨文档递归检索
3. **时效性问题**：法规有修订、废止，向量库需反映最新状态

**缓解措施**：
1. 使用 BGE-M3 的混合检索(稠密+稀疏)提升法规关键词命中
2. 在元数据中存储法规效力状态、修订历史，检索时过滤
3. 考虑对 Embedding 模型在法律领域做微调
4. 实现引用追踪：检索到结果后，自动查找引用的其他法规

### 5.3 本地部署的硬件门槛

**风险评估：低中**

| 使用模式 | 最低配置 | 推荐配置 | 说明 |
|---------|---------|---------|------|
| **纯 API 模式** | 2GB RAM, 任何 CPU | 4GB RAM | 仅向量库在本地，LLM/Embedding 走 API |
| **API + 本地 Embedding (fastembed)** | 4GB RAM | 8GB RAM | fastembed 可在 CPU 运行 |
| **API + 本地 Embedding (BGE-M3)** | 8GB RAM + GPU 8GB | 16GB RAM + GPU 16GB | BGE-M3 FP16 需 6.8GB 显存 |
| **全本地模式** | 16GB RAM + GPU 16GB | 32GB RAM + GPU 24GB | 含本地 LLM |

**对 CLI 工具而言**，推荐 **纯 API 模式** 作为默认，硬件门槛极低：
- 基本要求：Python 3.10+，2GB RAM，网络连接
- ChromaDB 在纯 CPU 环境下可流畅运行万级向量检索
- 这也是选择 ChromaDB 而非 FAISS 的重要原因之一：FAISS 在 CPU 上的性能优势需要特定编译配置

### 5.4 其他技术风险

| 风险 | 等级 | 描述 | 缓解 |
|------|------|------|------|
| **ChromaDB 版本兼容性** | 中 | ChromaDB 不同版本的存储格式可能不兼容 | 版本锁定，升级时提供迁移脚本 |
| **多 LLM 厂商 API 稳定性** | 低 | API 变更、服务宕机 | 抽象适配层，支持 fallback |
| **法规数据更新频率** | 中 | 新法规持续发布，向量库需同步更新 | 定期增量更新机制 + 用户手动触发 |
| **Python 版本兼容** | 低 | 用户系统 Python 版本可能较老 | uv 可自动管理 Python 版本 |
| **chroma-hnswlib 编译失败** | 中 | 旧系统 gcc 版本不足 | 提供 pre-built wheel，或改用 SQLite+faiss |

---

## 六、综合建议与路线图

### 6.1 推荐技术栈

```
核心框架：     自研（参考 LlamaIndex 设计模式）
向量数据库：   ChromaDB（嵌入式模式，PersistentClient）
Embedding：    默认 OpenAI/智谱 API + 可选 fastembed 本地
LLM：         多厂商适配（OpenAI / 智谱 / 阿里 / DeepSeek / Ollama）
爬虫：        阶段一预构建数据，阶段二 requests 增量，阶段三可选 Playwright
分发：        uv tool install（主推） + pipx install（备选）
打包：        pyproject.toml + [project.scripts] + 分层 extras
```

### 6.2 分层安装设计

```toml
[project]
name = "zcyclaw"
# 核心依赖（最小安装）
dependencies = [
    "chromadb>=0.4.0",
    "click>=8.0",
    "rich>=13.0",
    "httpx>=0.25",
]

[project.optional-dependencies]
openai = ["openai>=1.0"]
zhipu = ["zhipuai>=2.0"]
local-embed = ["fastembed>=0.2"]     # ~130MB
bge-m3 = ["FlagEmbedding>=1.2"]      # ~2.2GB
crawler = ["playwright>=1.40"]       # ~200MB
all-api = ["zcyclaw[openai,zhipu]"]
full = ["zcyclaw[all-api,local-embed]"]
```

### 6.3 建议开发路线图

**Phase 1 - MVP（4-6 周）**
- CLI 框架搭建（Click + Rich）
- ChromaDB 嵌入式存储
- OpenAI/智谱 API 适配
- 预构建法规向量库（核心法规 500 条）
- uv/pipx 安装分发
- 基础问答功能

**Phase 2 - 增强（4-6 周）**
- 多 LLM 厂商支持（阿里、DeepSeek、Ollama）
- 法规专用分块器（按条款/章节）
- 元数据过滤检索（按法规类型、年份、效力层级）
- 增量数据更新机制
- 引用追踪功能
- 本地 Embedding 支持（fastembed）

**Phase 3 - 专业版（6-8 周）**
- BGE-M3 高精度本地检索
- 可选 Playwright 爬虫模块
- 法规时效性标注与提醒
- 法规对比分析功能
- 招标文件智能审查
- Homebrew 分发

---

## 七、参考链接

- PrivateGPT: https://github.com/imartinez/privateGPT
- RAGFlow: https://github.com/infiniflow/ragflow
- Dify: https://github.com/langgenius/dify
- Kotaemon: https://github.com/Cinnamon/kotaemon
- QAnything: https://github.com/netease-youdao/QAnything
- ChatLaw: https://github.com/PKU-YuanGroup/ChatLaw
- law-cn-ai: https://github.com/lvwzhen/law-cn-ai
- LawRefBook/Laws: https://github.com/LawRefBook/Laws
- ChromaDB: https://github.com/chroma-core/chroma
- FAISS: https://github.com/facebookresearch/faiss
- uv: https://github.com/astral-sh/uv
- BGE-M3: https://huggingface.co/BAAI/bge-m3
- Embedchain: https://github.com/kael-aiur/embedchain
- ccgp_gov 爬虫: https://github.com/Clemente420/ccgp_gov
