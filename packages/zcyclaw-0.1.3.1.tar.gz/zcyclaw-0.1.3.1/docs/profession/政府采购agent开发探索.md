# 政府采购领域AI Agent开发探索

本文记录从零开始构建一个**政府采购领域专业AI助手**的设计思路。

> 最后更新：2026-04-29，基于市场调研进行规划纠偏，参考 nanobot 项目架构模式

## 项目定位

这是一个**独立于采购平台的政府采购智能顾问**，定位：
- 面向政府采购全角色（采购人、代理机构、供应商）
- 基于RAG架构，专业知识准确可追溯
- 用户配置自己的API Key，算力由用户承担，隐私安全
- **不绑定任何采购平台**，作为独立工具使用

核心价值：
- 新手：快速上手，不懂就问，流程法规随时查
- 老手：节省时间，模板生成，减少重复劳动
- 供应商：投标合规自查，报价参考，质疑辅助
- 专业：回答标注法条来源，不胡说八道

### 产品形态策略

| 阶段 | 形态 | 说明 |
|------|------|------|
| **MVP** | CLI（命令行） | 开发者/技术用户优先，快速验证核心功能 |
| **扩展** | TUI（终端UI） | 使用 Textual/Rich 构建交互式终端界面，降低使用门槛 |
| **长期** | Web UI | 使用 Gradio/Streamlit 快速出 Web 界面，覆盖非技术用户 |

> **为什么 CLI 先行**：MVP 阶段用 CLI 快速验证 RAG 问答效果和用户需求，避免过早投入 UI 开发。但长期必须提供更友好的交互形态，因为政府采购从业人员大多不使用命令行。

### 差异化定位（对比市场竞品）

| 维度 | 竞品（政采云/云之龙/易采通） | 本项目 |
|------|---------------------------|--------|
| 平台绑定 | 绑定特定采购平台 | **独立，不绑定任何平台** |
| 开源 | 全部闭源 | **核心开源** |
| 分发 | 平台内嵌/Web/APP | CLI → TUI → Web，渐进式 |
| 目标用户 | 偏采购人/代理机构 | **全角色，特别补充供应商侧** |
| 价格查询 | 智采AI做了一部分 | 整合为功能模块之一 |
| 部署方式 | 多数仅在线使用 | **支持本地部署，数据完全自主** |

## 整体架构设计

```
┌─────────────────────────────────────────────────────────────────┐
│                      用户交互层                                  │
│  CLI (MVP) → TUI (扩展) → Web UI (长期)                         │
│  zcyclaw ask / config / update / gen / price / check             │
├─────────────────────────────────────────────────────────────────┤
│                      会话记忆层                                  │
│  • 会话上下文记忆（多轮追问）                                    │
│  • 持久化对话历史（支持搜索回看）                                │
├─────────────────────────────────────────────────────────────────┤
│                      RAG 知识检索层（自研核心）                   │
│  • 政府采购法规向量库（本地ChromaDB）                            │
│  • 法规专用分块器（按条款/章节）                                 │
│  • 向量检索 + 元数据过滤 + 重排序                               │
│  • 法规效力层级感知 + 时效性标注                                 │
├─────────────────────────────────────────────────────────────────┤
│                      结构化数据层                                │
│  • 历史成交价格库（SQLite，关键词/分类检索）                     │
│  • 法规元数据库（效力层级、发布时间、修订状态）                   │
├─────────────────────────────────────────────────────────────────┤
│                      数据更新层                                  │
│  • 预构建数据包 + CDN 下载（MVP）                                │
│  • 轻量 requests 增量更新（扩展）                                │
│  • 可选 Playwright 爬虫模块（进阶，按需安装）                    │
├─────────────────────────────────────────────────────────────────┤
│                      LLM 推理生成层                              │
│  • 优先国产模型：DeepSeek / 智谱GLM / 通义千问                  │
│  • 兼容：OpenAI / Anthropic / Ollama                            │
│  • 用户配置API Key，请求直连，不中转                             │
│  • 基于检索到的法条+对话历史生成回答                             │
└─────────────────────────────────────────────────────────────────┘
```

## 核心设计原则

1. **专业准确优先**：所有回答必须标注法条来源，可追溯，不知道就直说
2. **隐私第一**：所有数据存在用户本地，API Key不经过第三方
3. **开箱即用**：预构建法规数据包首次运行下载，核心功能安装即用
4. **渐进式功能**：先搞定核心问答，再逐步扩展
5. **国产优先**：LLM 和 Embedding 优先支持国产模型，确保国内用户体验
6. **轻量安装**：核心包最小化，扩展功能通过 extras 按需安装
7. **参考 nanobot 架构**：Provider 注册表 + Pydantic 配置 + 懒加载 + 路径集中管理

## 核心功能模块（按优先级）

### 🔥 第一阶段：核心必做（MVP）

#### 1. 政策法规问答咨询
- 基于RAG检索相关法条，LLM总结回答
- 每条回答标注**具体法条出处**（"根据《政府采购法》第三十二条"）
- 区分不同位阶法规效力（法律 > 行政法规 > 部门规章 > 规范性文件）
- 边界感知：超出知识库范围明确告知，不编造
- 法规时效性标注：已修订/已废止的法规明确提示

#### 2. 采购方式选择辅助
- 交互式询问项目基本情况（预算金额、项目性质、竞争情况等）
- 根据法规推荐合适采购方式：公开招标/邀请招标/竞争性磋商/竞争性谈判/询价/单一来源
- 给出具体法条依据

#### 3. 采购流程全指引
- 按阶段解答："现在该做什么，下一步做什么，注意什么时限"
- 解答常见疑问："公告期限最少几天？""质疑期限几天？"

#### 4. 基础配置与知识更新
- `zcyclaw config` —— 配置LLM API Key、选择默认模型
- `zcyclaw update` —— 从CDN下载/更新本地法规知识库
- `zcyclaw stats` —— 查看已收录法规数量和数据概览

---

### ⚡ 第二阶段：扩展增值

#### 5. 历史成交价格查询
- 根据品目/关键词查询同类项目历史成交价
- 数据来源：中国政府采购网公开成交公告（结构化存储于本地SQLite）
- 辅助预算编制和报价决策
- 支持按地区、时间、采购方式筛选

#### 6. 招标文件/投标文件模板生成
- 交互式询问项目信息
- 基于Jinja2模板生成完整`.docx`文件
- 支持：公开招标文件、询价文件、竞争性磋商文件、投标函模板
- 自动检查是否遗漏法定必备条款（中小企业预留声明等）

#### 7. 中小企业政策合规计算
- 根据项目预算自动计算预留份额是否符合政策（200万以上货物服务项目预留≥30%）
- 告知小微企业报价扣除比例（6%-10%）
- 生成中小企业预留份额说明表

#### 8. 对话历史管理
- `zcyclaw history list` —— 查看历史对话
- `zcyclaw history search <keyword>` —— 搜索历史问题
- `zcyclaw history clear` —— 清空历史

---

### 🚀 第三阶段：专业进阶

#### 9. 供应商侧功能
- 投标文件合规自查：对照法规检查投标文件是否满足法定要求
- 报价策略参考：基于历史成交数据分析同类项目中标价格区间
- 质疑函辅助生成：交互式收集质疑要点 → 生成规范格式docx

#### 10. 质疑函/答复函辅助生成
- 帮助采购单位起草答复函，给出法规依据
- 帮助供应商起草质疑函，标注法条支撑

#### 11. 最新政策搜索与追踪
- 可选安装 Playwright 爬虫模块 `pip install zcyclaw[crawler]`
- 定向爬取：中国政府采购网、省级/地方政府采购网
- 提取搜索结果正文 → LLM总结 → 标注来源链接和发布时间
- 法规变更追踪：自动检测已收录法规的修订/废止状态
- 失败降级：爬取失败时引导用户手动粘贴内容

#### 12. 合同/验收报告模板生成
- 生成标准政府采购合同模板
- 生成履约验收报告模板

## 记忆策略设计

采用**分层记忆**，从简单到复杂：

| 层级 | 功能 | 实现方式 |
|------|------|----------|
| **会话内记忆** | 记住当前对话上下文，支持多轮追问 | 内存维护对话历史列表，滑动窗口控制token数量，保留最近5-10轮 |
| **持久化历史** | 保存对话，支持后续回看 | SQLite本地存储，记录时间戳+问题+回答+来源 |
| **个性化记忆**（可选） | 记住用户常用采购方式、过往项目 | 用户对话也做Embedding，检索时召回相关历史上下文 |

**建议**：第一阶段先做前两层就够用，第三层后续扩展。

## 知识更新与数据方案

### 本地知识库建设
- 初始数据：政府采购法、招标投标法、实施条例、主要部门规章
- **MVP方案**：预构建向量库通过CDN/GitHub Release下载，首次运行自动提示
- 用户更新：`zcyclaw update` 拉取最新法规增量更新

### 数据更新策略（三阶段）

| 阶段 | 方案 | 优点 | 缺点 |
|------|------|------|------|
| **MVP** | 预构建数据包 + CDN下载 | 零爬虫依赖，安装体积极小，速度快 | 需要维护者定期构建发布 |
| **扩展** | 轻量 requests 增量爬取 | 自动更新，用户无需手动 | 需维护解析逻辑，可能有反爬 |
| **进阶** | 可选 Playwright 爬虫模块 | 绕过JS反爬，支持动态网站 | 安装体积大(200MB+)，作为可选扩展 |

> **关键决策**：不将 Playwright 作为运行时依赖。MVP 阶段由维护者离线爬取数据构建向量库，用户首次运行时下载。Playwright 仅作为可选的 `pip install zcyclaw[crawler]` 扩展模块。

### 价格数据方案
- 历史成交数据独立于向量库，存储于本地 SQLite
- 数据来源：政府采购网公开成交公告（品目、金额、供应商、地区、时间）
- MVP：维护者预构建SQLite数据文件，随CDN一起分发
- 扩展：支持用户导入自定义数据源

## 用户配置与隐私设计

### 配置管理（参考 nanobot 的 Pydantic 模式）

采用 **Pydantic + pydantic-settings** 管理配置，而非手工解析 JSON：

- JSON 配置文件 + 环境变量自动解析（`ZCYCLAW_DEEPSEEK_API_KEY` 自动映射到 `providers.deepseek.api_key`）
- 配置文件位置：`~/.zcyclaw/config.json`
- 代码不收集不上传，完全本地

```json
{
  "agents": {
    "defaults": {
      "model": "deepseek-chat",
      "provider": "auto",
      "temperature": 0.7,
      "max_tokens": 4096
    }
  },
  "providers": {
    "deepseek": { "api_key": "sk-xxx" },
    "zhipu": { "api_key": "xxx" },
    "openai": { "api_key": "sk-xxx" },
    "ollama": { "api_base": "http://localhost:11434/v1" }
  },
  "embedding": {
    "provider": "zhipu",
    "model": "embedding-3"
  }
}
```

**核心优势**（对比手工 JSON 解析）：
- 类型安全：Pydantic 自动校验字段类型，配置错误即时发现
- 环境变量覆盖：支持 `ZCYCLAW_PROVIDERS__DEEPSEEK__API_KEY=xxx` 环境变量注入，CI/CD 友好
- 默认值集中：所有默认值在 Schema 中定义，不散落在各模块
- 向后兼容：新增配置字段自动使用默认值，不破坏旧配置文件

### 支持多LLM厂商（按优先级排列）

**Provider 架构（参考 nanobot 的注册表模式）**：

采用 `ProviderSpec` 注册表 + 懒加载设计，新增厂商只需：
1. 在注册表添加一条 `ProviderSpec`
2. 在 `ProvidersConfig` 添加一个字段
3. 完成。环境变量、配置匹配、状态展示全部自动派生

| 优先级 | 厂商 | 模型 | 后端 | 理由 |
|--------|------|------|------|------|
| **首选** | DeepSeek | deepseek-chat / deepseek-reasoner | openai_compat | 国内直连、中文强、价格极低、推理能力突出 |
| **首选** | 智谱AI | glm-4-flash / glm-4 | openai_compat | 国内直连、中文强、Embedding 生态完善 |
| **备选** | 阿里通义(DashScope) | qwen-turbo / qwen-plus | openai_compat | 国内直连、企业级稳定、Embedding 可用 |
| **兼容** | OpenAI | gpt-4o / gpt-4o-mini | openai_compat | 海外用户或已有Key的用户 |
| **兼容** | Anthropic | claude-sonnet / claude-haiku | anthropic | 海外用户或已有Key的用户 |
| **可选** | Ollama | 本地开源模型 | openai_compat (local) | 完全离线运行，不用API Key，隐私最强 |
| **可选** | 月之暗面(Moonshot) | kimi-latest | openai_compat | 国内直连，长上下文 |

> **关键设计**：绝大多数国产模型兼容 OpenAI API 协议，统一走 `openai_compat` 后端，只需配置 `api_base` 和 `api_key` 即可。Anthropic 使用独立后端。这样避免了每个厂商写一个适配器的冗余。

### Embedding 方案（按优先级排列）

| 优先级 | 方案 | 模型 | 适用场景 |
|--------|------|------|----------|
| **首选** | 智谱API | embedding-3 | 国内直连、中文效果好、成本低 |
| **备选** | 通义API | text-embedding-v3 | 国内直连、阿里生态 |
| **兼容** | OpenAI API | text-embedding-3-small | 海外用户 |
| **可选本地** | fastembed | bge-small-zh (~130MB) | 离线场景，首次安装体验 |
| **可选高级** | FlagEmbedding | BGE-M3 (~2.2GB) | 高频专业用户，法律领域召回率89% |

### 隐私保护
- 所有对话历史、知识向量库都存在用户本地
- API请求直接从用户机器发到LLM厂商，我们不中转
- 数据更新从CDN拉取，不涉及用户隐私数据上传

## RAG 核心设计（自研）

### 为什么自研而非用 LangChain

| 维度 | LangChain | 自研 |
|------|-----------|------|
| 安装体积 | +200MB 依赖 | 可控，仅核心依赖 |
| 稳定性 | 频繁 breaking changes | 完全可控 |
| 领域适配 | 需大量定制 | 天然适配政府采购法规结构 |
| 复杂度 | 概念多、抽象层厚 | 核心流程清晰简单 |

### 自研核心组件

```
文档加载器 (PDF/HTML/Markdown)
    → 法规专用分块器 (按条款/章节，保留引用关系)
    → Embedding 适配层 (API/本地模型切换)
    → ChromaDB 存储层 (含元数据：法规类型/效力层级/发布时间/修订状态)
    → 检索器 (向量相似度 + 元数据过滤 + 法规效力排序 + 重排序)
    → LLM 生成层 (多厂商 API 适配)
```

### 法规专用分块策略
- 按"条"分块为主：每一条作为一个检索单元，保留条号和所属法规名
- 保留引用关系：法条A引用法条B时，元数据中记录引用链
- 效力层级标注：法律 > 行政法规 > 部门规章 > 规范性文件，检索时优先返回高效力法规
- 时效性标注：标注法规当前状态（有效/已修订/已废止），检索时过滤或提示

## 分发安装方案

### 分层安装设计

```toml
[project]
name = "zcyclaw"
# 核心依赖（最小安装 ~80MB）
dependencies = [
    "chromadb>=0.4.0",
    "click>=8.0",
    "rich>=13.0",
    "httpx>=0.25",
    "sqlite-utils>=3.0",
]

[project.optional-dependencies]
deepseek = ["openai>=1.0"]          # DeepSeek 兼容 OpenAI SDK
zhipu = ["zhipuai>=2.0"]
openai = ["openai>=1.0"]
anthropic = ["anthropic>=0.20"]
local-embed = ["fastembed>=0.2"]    # ~130MB，本地轻量Embedding
bge-m3 = ["FlagEmbedding>=1.2"]     # ~2.2GB，高精度本地Embedding
crawler = ["playwright>=1.40"]      # ~200MB，可选爬虫模块
docx = ["python-docx>=1.0", "jinja2>=3.0"]  # 文档生成
all-api = ["zcyclaw[deepseek,zhipu,openai,anthropic]"]
full = ["zcyclaw[all-api,local-embed,docx]"]
```

### 用户安装

```bash
# 最小安装（MVP）
uv tool install zcyclaw

# 带国产模型支持
uv tool install "zcyclaw[deepseek,zhipu]"

# 完整安装
uv tool install "zcyclaw[full]"

# 备选：pipx
pipx install zcyclaw

# 首次运行向导
zcyclaw init
# → 选择LLM厂商 → 输入API Key → 下载法规数据包 → 开始使用
```

### 首次使用体验优化

**核心指标**：Time-to-First-Query（从安装到第一次有效查询的时间）

| 措施 | 说明 |
|------|------|
| 内置 demo 数据 | 打包10条核心法规向量，安装后30秒内可体验 |
| 首次运行向导 | `zcyclaw init` 引导配置LLM和下载数据 |
| 预构建数据包 | CDN下载核心法规向量库（~100-200MB），避免本地构建 |
| uvx 免安装体验 | `uvx zcyclaw ask "询价条件"` 无需安装直接运行 |

### 维护者发布
1. 在 `pyproject.toml` 配置项目信息和入口脚本
2. `uv build` 打包
3. `uv publish` 发布到PyPI
4. 预构建数据包发布到 GitHub Release / CDN

## 项目代码结构

```
zcyclaw/
├── pyproject.toml                 # hatchling构建 + 分层extras
├── README.md                      # 使用说明
├── src/
│   └── zcyclaw/
│       ├── __init__.py            # 版本号(从pyproject.toml读取，参考nanobot)
│       ├── __main__.py            # 入口: from zcyclaw.cli.commands import app; app()
│       ├── cli/
│       │   ├── commands.py        # Typer命令定义(app, ask, config, update, gen, price)
│       │   └── stream.py         # 流式输出渲染(Rich Markdown + spinner)
│       ├── config/
│       │   ├── schema.py          # Pydantic配置模型(参考nanobot的Config/ProvidersConfig)
│       │   ├── loader.py          # 配置加载(读JSON + 环境变量解析)
│       │   └── paths.py           # 路径集中管理(参考nanobot的paths.py)
│       ├── session.py             # 会话记忆管理
│       ├── history.py             # 历史记录管理
│       ├── rag/
│       │   ├── loader.py          # 文档加载器(PDF/HTML/Markdown)
│       │   ├── chunker.py         # 法规专用分块器(按条款/章节)
│       │   ├── embeddings.py      # Embedding适配层(API/本地切换)
│       │   ├── vector_store.py    # ChromaDB存储层(含元数据)
│       │   └── retriever.py       # 检索器(向量+元数据过滤+重排序)
│       ├── price/
│       │   ├── store.py           # 历史成交价SQLite存储
│       │   └── query.py           # 价格查询与分析
│       ├── crawler/
│       │   └── gov_crawler.py     # 政府采购网爬虫(可选模块)
│       ├── llm/
│       │   ├── __init__.py        # 懒加载导出(参考nanobot的providers/__init__.py)
│       │   ├── base.py            # LLMProvider基类 + LLMResponse(参考nanobot的base.py)
│       │   ├── registry.py        # ProviderSpec注册表(参考nanobot的registry.py)
│       │   ├── openai_compat.py   # OpenAI兼容后端(覆盖DeepSeek/智谱/通义/Ollama等)
│       │   └── anthropic_provider.py  # Anthropic独立后端
│       ├── template/
│       │   ├── doc_generator.py   # Word文档生成
│       │   └── *.jinja2           # 各类文档模板
│       └── types.py               # 类型定义
├── data/
│   ├── demo_embeddings/           # 内置demo向量库(10条核心法规)
│   └── seed_data/                 # 法规原始数据(用于构建向量库)
├── scripts/
│   └── build_data.py              # 离线构建向量库和价格数据库的脚本
└── tests/                         # 测试
```

### 参考 nanobot 的关键架构模式

| 模式 | nanobot 实现 | 本项目采用 | 说明 |
|------|-------------|-----------|------|
| **Provider 注册表** | `ProviderSpec` + `PROVIDERS` 元组 | 同样模式，按优先级排列 | 新增厂商只需加一条 Spec，不用写适配器 |
| **统一 OpenAI 兼容后端** | `OpenAICompatProvider` 覆盖 20+ 厂商 | 同样策略，国产模型走 `openai_compat` | 绝大多数国产模型兼容 OpenAI 协议，避免为每个厂商写适配器 |
| **懒加载** | `__init__.py` 的 `__getattr__` 动态导入 | 同样模式 | 用户只装了 DeepSeek 就不导入 Anthropic SDK，减少启动时间和内存 |
| **Pydantic 配置** | `BaseSettings` + `ConfigDict` | 同样模式 | 类型安全 + 环境变量自动解析 + 默认值集中 |
| **路径集中管理** | `config/paths.py` | 同样模式 | 所有运行时目录从配置派生，不散落各处 |
| **LLMResponse 统一** | `LLMResponse` dataclass | 同样模式 | 统一响应结构(content, tool_calls, usage, error) |
| **重试机制** | `chat_with_retry` + 瞬态错误识别 | 同样模式 | 429/500/502/503 自动重试，配额耗尽不重试 |
| **流式输出** | `chat_stream` + `on_content_delta` 回调 | 同样模式 | 支持流式 Markdown 渲染 |
| **构建系统** | hatchling + `project.scripts` | 同样模式 | 现代 Python 打包 |
| **版本管理** | 从 pyproject.toml 读取，fallback 到包元数据 | 同样模式 | 开发态和安装态都能正确获取版本 |

## 分阶段开发计划

| 阶段 | 功能 | 目标 | 预计周期 |
|------|------|------|----------|
| Phase 1 | CLI框架 + RAG问答(自研) + 国产模型支持 + 预构建数据包 | 核心问答跑通，能回答政府采购法规问题 | 4-6周 |
| Phase 2 | 价格查询 + 文档模板生成 + 合规计算 + 历史管理 | 解决实际工作痛点，覆盖供应商需求 | 4-6周 |
| Phase 3 | 供应商功能 + 可选爬虫 + 法规追踪 + TUI/Web UI | 完整专业体验，降低使用门槛 | 6-8周 |

### Phase 1 详细任务

1. 项目脚手架：pyproject.toml、分层extras、CLI命令框架
2. 配置管理：`zcyclaw init` 首次运行向导、多厂商API Key配置
3. RAG核心：法规分块器、ChromaDB存储、Embedding适配、检索器
4. LLM适配：DeepSeek + 智谱GLM 优先，OpenAI兼容
5. 数据管道：离线构建向量库脚本、CDN分发、`zcyclaw update` 下载
6. 核心问答：法条标注、效力层级感知、时效性提示
7. Demo数据：打包10条核心法规向量，确保安装后30秒可体验

## 关键技术选型

| 组件 | 选型 | 理由 |
|------|------|------|
| 语言 | Python 3.11+ | RAG生态好，CLI开发快，async/await 原生支持 |
| CLI框架 | **Typer** + Rich + prompt_toolkit | Typer比Click更现代(自动生成help、类型推断)，Rich美化输出，prompt_toolkit支持交互式输入和命令历史 |
| 配置管理 | **Pydantic + pydantic-settings** | 类型安全、环境变量自动解析、默认值集中、校验即时（参考nanobot） |
| 向量库 | ChromaDB | 嵌入式运行，pip install即可，PersistentClient本地持久化，支持元数据过滤 |
| RAG框架 | **自研** | 体积可控、稳定、天然适配法规结构；LangChain依赖链过重且breaking changes频繁 |
| Embedding | 智谱API(首选) / fastembed(本地可选) | 国产优先，中文效果好，API模式零本地资源消耗 |
| LLM | DeepSeek / 智谱GLM(首选) | 国内直连、中文强、价格低；兼容OpenAI/Anthropic |
| LLM Provider | **ProviderSpec注册表 + openai_compat统一后端** | 参考nanobot，20+厂商共用一个后端，新增厂商只需加一条Spec |
| 日志 | **loguru** | 参考nanobot，比logging更简洁，开箱即用，支持结构化日志 |
| 爬虫 | 预构建数据(MVP) / requests增量(扩展) / Playwright(可选) | 不将Playwright作为运行时依赖，控制安装体积 |
| 价格数据 | SQLite | 结构化查询，轻量，无需额外服务 |
| Word生成 | python-docx + Jinja2 | 成熟稳定，模板灵活 |
| 构建系统 | **hatchling** | 参考nanobot，现代PEP 517构建后端 |
| 打包分发 | uv + PyPI | 现代Python工具链，分层extras，用户安装方便 |

## 核心优势总结

1. **独立**：不绑定任何采购平台，这是市场空白——竞品全部绑定平台
2. **开源**：GitHub上无政府采购领域开源AI项目，先发优势明显
3. **专业**：RAG架构保证回答基于准确法条，标注来源可验证
4. **国产**：优先支持国产LLM/Embedding，国内用户体验好
5. **隐私**：全流程本地运行，用户API Key不上传第三方
6. **便捷**：uv一键安装，预构建数据包首次运行下载，开箱即用
7. **灵活**：分层安装，核心包最小化，扩展功能按需安装
8. **渐进**：功能分阶段，CLI先行验证，逐步扩展UI和功能

## 需关注的风险

| 风险 | 等级 | 应对策略 |
|------|------|----------|
| CLI形态限制用户规模 | 高 | Phase 1验证后尽快推进TUI/Web UI |
| 法规数据维护成本 | 中 | 自动化构建脚本 + 定期更新机制 |
| 安装体积累赘 | 中 | 分层extras + 预构建数据CDN独立下载 |
| ChromaDB版本兼容 | 中 | 版本锁定，升级时提供迁移脚本 |
| 通用Embedding对法律术语理解有限 | 中 | 元数据过滤补偿 + 远期考虑法律领域微调 |
| 竞品平台护城河 | 中 | 以"独立+开源"差异化，避免正面竞争 |
| 商业模式待明确 | 中 | 开源核心 + 数据增值/托管服务，后续探索 |
