# 功能开发闭环 (develop)

使用 plan + publish 进行功能开发的完整闭环。

## Ralph Loop Prompt

当需要执行功能开发时，复制以下内容启动 Ralph Loop（对应的内容要获取填充）：

```
/ralph-loop:ralph-loop 执行功能开发闭环：

1. 使用 plan 模式规划 todo 里面 [序号] 功能的开发步骤
2. 功能完成后使用 publish 模式发布

验收标准：[从 todo.md 读取]

完成后输出 <promise>DEVELOP COMPLETE</promise>
```

## 示例

```
执行功能开发闭环：

1. 使用 plan 模式规划 todo 里面 1 功能的开发步骤
2. 功能完成后使用 publish 模式发布

验收标准：能够在tui启动后，实现流式输出，并且有上下文记忆能力

完成后输出 <promise>DEVELOP COMPLETE</promise>
```
