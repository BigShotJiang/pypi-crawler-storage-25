# 发布指南

## 1. 修改版本号

编辑 `pyproject.toml`，更新 `version` 字段：

```toml
[project]
name = "zcyclaw"
version = "0.1.3"  # 修改此处
```

## 2. 构建发行包

```bash
uv build
```

生成文件在 `dist/` 目录下：

- `dist/zcyclaw-<version>.tar.gz`（源码包）
- `dist/zcyclaw-<version>-py3-none-any.whl`（wheel 包）

## 3. 发布到 PyPI

### 首次配置 Token

1. 访问 [pypi.org/manage/account/token](https://pypi.org/manage/account/token) 创建 API Token
2. 配置凭证（任选一种）：

```bash
# 方式一：命令行直接传入
uv publish --token pypi-xxx

# 方式二：保存到 keyring（推荐，后续免输入）
uv publish  # 首次会提示输入用户名和密码
            # 用户名: __token__
            # 密码: pypi-xxx
```

### 发布

```bash
uv publish
```

## 注意事项

- 版本号一旦发布到 PyPI 就**不可覆盖**，必须升级版本号才能再次发布
- 发布前确认 `dist/` 下只有当前版本的文件，旧版本文件需清理：
  ```bash
  rm -rf dist/
  uv build
  ```
- 发布后可在 [pypi.org/project/zcyclaw](https://pypi.org/project/zcyclaw) 查看
