"""政府采购智能顾问 - 基于RAG的法规问答CLI工具"""

from importlib.metadata import version

try:
    __version__ = version("zcyclaw")
except Exception:
    __version__ = "0.1.0"


def _setup_logging():
    """配置 loguru：移除默认 stderr handler，只写文件"""
    from loguru import logger

    # 移除默认的 stderr 输出
    logger.remove()
    # 添加文件日志（DEBUG 以上）
    from zcyclaw.config.paths import get_cache_dir

    log_path = get_cache_dir() / "zcyclaw.log"
    logger.add(
        str(log_path),
        level="DEBUG",
        rotation="5 MB",
        retention="7 days",
        encoding="utf-8",
    )


# 模块加载时自动配置
_setup_logging()
