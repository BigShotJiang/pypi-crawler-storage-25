"""会话记忆管理 - deque 滑动窗口，10 轮记忆"""

from __future__ import annotations

from collections import deque


class Session:
    """会话记忆

    使用 deque 维护滑动窗口，保留最近 10 轮对话。
    """

    def __init__(self, max_turns: int = 10):
        self._max_turns = max_turns
        self._history: deque[dict[str, str]] = deque(maxlen=max_turns)

    def add_exchange(self, question: str, answer: str) -> None:
        """添加一轮对话"""
        self._history.append({"question": question, "answer": answer})

    def get_history(self) -> list[dict[str, str]]:
        """获取对话历史"""
        return [dict(item) for item in self._history]

    def clear(self) -> None:
        """清空对话历史"""
        self._history.clear()

    @property
    def turn_count(self) -> int:
        """当前轮次"""
        return len(self._history)
