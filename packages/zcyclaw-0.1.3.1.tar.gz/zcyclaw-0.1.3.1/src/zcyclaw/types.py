"""公共类型定义"""

from enum import IntEnum


class HierarchyLevel(IntEnum):
    """法规效力层级（数值越大效力越高）"""

    部门规章 = 1
    地方性法规 = 2
    行政法规 = 3
    法律 = 4
    宪法 = 5


class LawStatus:
    """法规时效状态"""

    有效 = "有效"
    已修订 = "已修订"
    已废止 = "已废止"
    部分失效 = "部分失效"
