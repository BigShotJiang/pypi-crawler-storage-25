"""路径集中管理"""

from pathlib import Path


def get_config_dir() -> Path:
    """获取配置目录 ~/.zcyclaw/"""
    path = Path.home() / ".zcyclaw"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_config_file() -> Path:
    """获取配置文件路径"""
    return get_config_dir() / "config.json"


def get_data_dir() -> Path:
    """获取数据目录"""
    path = get_config_dir() / "data"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_vector_store_dir() -> Path:
    """获取向量库目录"""
    path = get_data_dir() / "chroma"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_seed_data_dir() -> Path:
    """获取预构建法规数据目录"""
    return get_data_dir() / "seed"


def get_cache_dir() -> Path:
    """获取缓存目录"""
    path = get_config_dir() / "cache"
    path.mkdir(parents=True, exist_ok=True)
    return path
