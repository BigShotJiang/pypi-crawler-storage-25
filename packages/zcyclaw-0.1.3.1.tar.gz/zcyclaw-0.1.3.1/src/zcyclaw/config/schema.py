"""Pydantic 配置模型 - 支持 ZCYCLAW_ 前缀环境变量覆盖"""

from __future__ import annotations

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class DeepSeekConfig(BaseModel):
    """DeepSeek 配置"""

    api_key: str | None = None
    base_url: str = "https://api.deepseek.com/v1"
    model: str = "deepseek-chat"
    temperature: float = 0.3
    max_tokens: int = 2048


class ZhipuConfig(BaseModel):
    """智谱配置"""

    api_key: str | None = None
    base_url: str = "https://open.bigmodel.cn/api/paas/v4"
    model: str = "glm-4-flash"
    temperature: float = 0.3
    max_tokens: int = 2048


class TongyiConfig(BaseModel):
    """通义千问配置"""

    api_key: str | None = None
    base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    model: str = "qwen-turbo"
    temperature: float = 0.3
    max_tokens: int = 2048


class MoonshotConfig(BaseModel):
    """Moonshot 配置"""

    api_key: str | None = None
    base_url: str = "https://api.moonshot.cn/v1"
    model: str = "moonshot-v1-8k"
    temperature: float = 0.3
    max_tokens: int = 2048


class OpenAIConfig(BaseModel):
    """OpenAI 配置"""

    api_key: str | None = None
    base_url: str = "https://api.openai.com/v1"
    model: str = "gpt-4o-mini"
    temperature: float = 0.3
    max_tokens: int = 2048


class OllamaConfig(BaseModel):
    """Ollama 本地配置"""

    base_url: str = "http://localhost:11434/v1"
    model: str = "qwen2.5:7b"
    temperature: float = 0.3
    max_tokens: int = 2048


class AnthropicConfig(BaseModel):
    """Anthropic 配置"""

    api_key: str | None = None
    model: str = "claude-sonnet-4-20250514"
    temperature: float = 0.3
    max_tokens: int = 2048


class MiniMaxConfig(BaseModel):
    """MiniMax 配置"""

    api_key: str | None = None
    base_url: str = "https://api.minimax.chat/v1"
    model: str = "MiniMax-Text-01"
    temperature: float = 0.3
    max_tokens: int = 2048


class ProvidersConfig(BaseModel):
    """所有 LLM 提供商配置"""

    deepseek: DeepSeekConfig = Field(default_factory=DeepSeekConfig)
    zhipu: ZhipuConfig = Field(default_factory=ZhipuConfig)
    tongyi: TongyiConfig = Field(default_factory=TongyiConfig)
    moonshot: MoonshotConfig = Field(default_factory=MoonshotConfig)
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    ollama: OllamaConfig = Field(default_factory=OllamaConfig)
    anthropic: AnthropicConfig = Field(default_factory=AnthropicConfig)
    minimax: MiniMaxConfig = Field(default_factory=MiniMaxConfig)


class EmbeddingConfig(BaseModel):
    """Embedding 配置"""

    provider: str = "auto"  # auto / zhipu / openai_compat / fastembed
    model: str = ""  # 留空则根据 provider 自动选择
    api_key: str | None = None
    base_url: str | None = None


class AgentDefaultsConfig(BaseModel):
    """Agent 默认行为配置"""

    top_k: int = 5
    temperature: float = 0.3
    max_tokens: int = 2048
    show_sources: bool = True


class AppConfig(BaseSettings):
    """应用总配置

    环境变量覆盖：ZCYCLAW_ 前缀，双下划线分隔嵌套
    示例：ZCYCLAW_PROVIDERS__DEEPSEEK__API_KEY=sk-xxx
    """

    model_config = SettingsConfigDict(env_prefix="ZCYCLAW_", env_nested_delimiter="__")

    default_provider: str = "deepseek"
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    agent: AgentDefaultsConfig = Field(default_factory=AgentDefaultsConfig)


def get_provider_config(app_config: AppConfig, provider_name: str) -> BaseModel | None:
    """根据名称获取提供商配置"""
    return getattr(app_config.providers, provider_name, None)
