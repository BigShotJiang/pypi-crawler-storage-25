"""配置加载/保存 - 环境变量覆盖由 pydantic-settings 自动处理"""

from __future__ import annotations

import json

from loguru import logger

from zcyclaw.config.paths import get_config_file
from zcyclaw.config.schema import AppConfig


def load_config() -> AppConfig:
    """加载配置（文件 + 环境变量覆盖）

    环境变量覆盖由 pydantic-settings BaseSettings 自动处理：
    ZCYCLAW_PROVIDERS__DEEPSEEK__API_KEY=xxx 自动映射到 config.providers.deepseek.api_key
    """
    config_path = get_config_file()

    if config_path.exists():
        try:
            data = json.loads(config_path.read_text(encoding="utf-8"))
            # BaseSettings 会自动合并环境变量
            config = AppConfig(**data)
            logger.debug(f"已加载配置: {config_path}")
        except Exception as e:
            logger.warning(f"配置文件解析失败，使用默认配置: {e}")
            config = AppConfig()
    else:
        config = AppConfig()

    return config


def save_config(config: AppConfig) -> None:
    """保存配置到文件"""
    config_path = get_config_file()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    data = config.model_dump(exclude_none=False)
    config_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.debug(f"配置已保存: {config_path}")
