"""create_provider 工厂函数"""

from __future__ import annotations

from zcyclaw.config.schema import AppConfig, get_provider_config
from zcyclaw.llm.anthropic_provider import AnthropicProvider
from zcyclaw.llm.base import LLMProvider
from zcyclaw.llm.openai_compat import OpenAICompatProvider
from zcyclaw.llm.registry import get_spec, list_providers


def create_provider(name: str, config: AppConfig) -> LLMProvider:
    """根据提供商名称和配置创建 LLMProvider 实例

    Args:
        name: 提供商名称 (deepseek/zhipu/tongyi/moonshot/openai/ollama/anthropic)
        config: 应用配置

    Returns:
        LLMProvider 实例

    Raises:
        ValueError: 未知的提供商名称
    """
    spec = get_spec(name)
    if not spec:
        raise ValueError(f"未知提供商: {name}，可选: {[s.name for s in list_providers()]}")

    provider_config = get_provider_config(config, name)

    if spec.backend == "openai_compat":
        return OpenAICompatProvider(
            spec=spec,
            api_key=getattr(provider_config, "api_key", None) if provider_config else None,
            base_url=getattr(provider_config, "base_url", None) if provider_config else None,
            model=getattr(provider_config, "model", None) if provider_config else None,
            temperature=getattr(provider_config, "temperature", 0.3) if provider_config else 0.3,
            max_tokens=getattr(provider_config, "max_tokens", 2048) if provider_config else 2048,
        )
    elif spec.backend == "anthropic":
        return AnthropicProvider(
            spec=spec,
            api_key=getattr(provider_config, "api_key", None) if provider_config else None,
            model=getattr(provider_config, "model", None) if provider_config else None,
            temperature=getattr(provider_config, "temperature", 0.3) if provider_config else 0.3,
            max_tokens=getattr(provider_config, "max_tokens", 2048) if provider_config else 2048,
        )
    else:
        raise ValueError(f"未知后端类型: {spec.backend}")
