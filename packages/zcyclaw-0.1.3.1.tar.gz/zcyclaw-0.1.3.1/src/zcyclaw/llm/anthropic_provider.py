"""Anthropic 独立后端"""

from __future__ import annotations

from typing import AsyncIterator

from zcyclaw.llm.base import LLMProvider, LLMResponse
from zcyclaw.llm.registry import ProviderSpec


class AnthropicProvider(LLMProvider):
    """Anthropic 原生 API 后端

    使用 httpx 直接调用 Anthropic Messages API。
    不依赖 anthropic SDK，保持轻量安装。
    """

    def __init__(
        self,
        spec: ProviderSpec,
        api_key: str | None = None,
        model: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 2048,
    ):
        self.name = spec.name
        self._spec = spec
        self._api_key = api_key
        self._model = model or spec.default_model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._base_url = "https://api.anthropic.com"

    async def chat(self, messages: list[dict], **kwargs) -> LLMResponse:
        """异步非流式对话"""
        import httpx

        system_msg, chat_msgs = self._split_messages(messages)

        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                f"{self._base_url}/v1/messages",
                headers=self._headers(),
                json=self._build_payload(system_msg, chat_msgs, stream=False, **kwargs),
            )
            resp.raise_for_status()
            data = resp.json()

        content = "".join(
            block["text"] for block in data.get("content", []) if block["type"] == "text"
        )
        return LLMResponse(
            content=content,
            model=data.get("model", self._model),
            provider=self.name,
            usage={
                "input_tokens": data.get("usage", {}).get("input_tokens", 0),
                "output_tokens": data.get("usage", {}).get("output_tokens", 0),
            },
            finish_reason=data.get("stop_reason", ""),
        )

    async def chat_stream(self, messages: list[dict], **kwargs) -> AsyncIterator[str]:
        """异步流式对话"""
        import json

        import httpx

        system_msg, chat_msgs = self._split_messages(messages)

        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream(
                "POST",
                f"{self._base_url}/v1/messages",
                headers=self._headers(),
                json=self._build_payload(system_msg, chat_msgs, stream=True, **kwargs),
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    try:
                        event = json.loads(line[6:])
                        if event["type"] == "content_block_delta":
                            delta = event.get("delta", {})
                            if delta.get("type") == "text_delta":
                                yield delta.get("text", "")
                    except (json.JSONDecodeError, KeyError):
                        continue

    def _headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "x-api-key": self._api_key or "",
            "anthropic-version": "2023-06-01",
        }

    def _split_messages(self, messages: list[dict]) -> tuple[str | None, list[dict]]:
        """将 OpenAI 格式消息拆分为 system + chat 消息"""
        system = None
        chat = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                chat.append(msg)
        return system, chat

    def _build_payload(
        self, system: str | None, messages: list[dict], stream: bool = False, **kwargs
    ) -> dict:
        payload: dict = {
            "model": kwargs.pop("model", self._model),
            "messages": messages,
            "max_tokens": kwargs.pop("max_tokens", self._max_tokens),
            "stream": stream,
        }
        if system:
            payload["system"] = system
        temperature = kwargs.pop("temperature", self._temperature)
        if temperature is not None:
            payload["temperature"] = temperature
        return payload
