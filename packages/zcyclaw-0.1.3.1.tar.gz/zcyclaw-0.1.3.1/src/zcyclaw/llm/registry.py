"""ProviderSpec 注册表 - 新增厂商只需加一条 Spec"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderSpec:
    """提供商规格说明"""

    name: str
    display_name: str
    backend: str  # "openai_compat" 或 "anthropic"
    default_model: str
    default_base_url: str
    needs_api_key: bool = True
    env_key_hint: str = ""  # 环境变量名提示


# 全局注册表
PROVIDERS: dict[str, ProviderSpec] = {}


def register(spec: ProviderSpec) -> None:
    """注册一个提供商"""
    PROVIDERS[spec.name] = spec


def get_spec(name: str) -> ProviderSpec | None:
    """获取提供商规格"""
    return PROVIDERS.get(name)


def list_providers() -> list[ProviderSpec]:
    """列出所有已注册提供商"""
    return list(PROVIDERS.values())


# ---- 注册所有内置提供商 ----

register(ProviderSpec(
    name="deepseek",
    display_name="DeepSeek",
    backend="openai_compat",
    default_model="deepseek-chat",
    default_base_url="https://api.deepseek.com/v1",
    needs_api_key=True,
    env_key_hint="ZCYCLAW_PROVIDERS__DEEPSEEK__API_KEY",
))

register(ProviderSpec(
    name="zhipu",
    display_name="智谱 GLM",
    backend="openai_compat",
    default_model="glm-4-flash",
    default_base_url="https://open.bigmodel.cn/api/paas/v4",
    needs_api_key=True,
    env_key_hint="ZCYCLAW_PROVIDERS__ZHIPU__API_KEY",
))

register(ProviderSpec(
    name="tongyi",
    display_name="通义千问",
    backend="openai_compat",
    default_model="qwen-turbo",
    default_base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    needs_api_key=True,
    env_key_hint="ZCYCLAW_PROVIDERS__TONGYI__API_KEY",
))

register(ProviderSpec(
    name="moonshot",
    display_name="Moonshot",
    backend="openai_compat",
    default_model="moonshot-v1-8k",
    default_base_url="https://api.moonshot.cn/v1",
    needs_api_key=True,
    env_key_hint="ZCYCLAW_PROVIDERS__MOONSHOT__API_KEY",
))

register(ProviderSpec(
    name="openai",
    display_name="OpenAI",
    backend="openai_compat",
    default_model="gpt-4o-mini",
    default_base_url="https://api.openai.com/v1",
    needs_api_key=True,
    env_key_hint="ZCYCLAW_PROVIDERS__OPENAI__API_KEY",
))

register(ProviderSpec(
    name="minimax",
    display_name="MiniMax",
    backend="openai_compat",
    default_model="MiniMax-Text-01",
    default_base_url="https://api.minimax.chat/v1",
    needs_api_key=True,
    env_key_hint="ZCYCLAW_PROVIDERS__MINIMAX__API_KEY",
))

register(ProviderSpec(
    name="ollama",
    display_name="Ollama (本地)",
    backend="openai_compat",
    default_model="qwen2.5:7b",
    default_base_url="http://localhost:11434/v1",
    needs_api_key=False,
))

register(ProviderSpec(
    name="anthropic",
    display_name="Anthropic",
    backend="anthropic",
    default_model="claude-sonnet-4-20250514",
    default_base_url="",
    needs_api_key=True,
    env_key_hint="ZCYCLAW_PROVIDERS__ANTHROPIC__API_KEY",
))
