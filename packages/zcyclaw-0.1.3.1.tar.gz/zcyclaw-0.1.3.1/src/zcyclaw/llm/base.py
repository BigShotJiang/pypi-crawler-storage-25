"""LLMProvider 基类 + LLMResponse"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class LLMResponse:
    """LLM 响应"""

    content: str
    model: str = ""
    provider: str = ""
    usage: dict = field(default_factory=dict)
    finish_reason: str = ""


class LLMProvider(ABC):
    """LLM 提供商基类"""

    name: str

    @abstractmethod
    async def chat(self, messages: list[dict], **kwargs) -> LLMResponse:
        """异步对话"""
        ...

    @abstractmethod
    async def chat_stream(self, messages: list[dict], **kwargs):
        """异步流式对话，yield 内容片段"""
        ...
        # 使此方法成为异步生成器
        yield ""  # type: ignore  # noqa: E999

    def chat_sync(self, messages: list[dict], **kwargs) -> LLMResponse:
        """同步对话（阻塞包装）"""
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, self.chat(messages, **kwargs))
                return future.result()
        else:
            return asyncio.run(self.chat(messages, **kwargs))

    def chat_sync_with_retry(
        self, messages: list[dict], max_retries: int = 3, **kwargs
    ) -> LLMResponse:
        """同步对话（带重试）"""
        import asyncio

        from zcyclaw.llm.retry import chat_with_retry

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(
                    asyncio.run, chat_with_retry(self, messages, max_retries=max_retries, **kwargs)
                )
                return future.result()
        else:
            return asyncio.run(chat_with_retry(self, messages, max_retries=max_retries, **kwargs))

    def chat_stream_sync(self, messages: list[dict], **kwargs):
        """同步流式对话，yield 内容片段"""
        import asyncio

        async def _collect():
            full_content = ""
            async for chunk in self.chat_stream(messages, **kwargs):
                full_content += chunk
                yield chunk
            # 返回完整内容供调用方使用（如果需要）

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures
            import queue

            q: queue.Queue = queue.Queue()

            async def _run():
                async for chunk in self.chat_stream(messages, **kwargs):
                    q.put(chunk)
                q.put(None)  # sentinel

            with concurrent.futures.ThreadPoolExecutor() as pool:
                pool.submit(asyncio.run, _run()).result()
                while True:
                    chunk = q.get()
                    if chunk is None:
                        break
                    yield chunk
        else:
            gen = _collect()

            async def _drain():
                results = []
                async for chunk in gen:
                    results.append(chunk)
                return results

            for chunk in asyncio.run(_drain()):
                yield chunk
