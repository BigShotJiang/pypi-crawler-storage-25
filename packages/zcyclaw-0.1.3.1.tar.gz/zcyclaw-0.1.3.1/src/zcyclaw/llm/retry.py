"""chat_with_retry - 429/500 自动重试，配额耗尽不重试"""

from __future__ import annotations

import asyncio

import httpx
from loguru import logger

from zcyclaw.llm.base import LLMProvider, LLMResponse

# 不可重试的状态码（配额耗尽、认证失败等）
NO_RETRY_STATUS = {401, 402, 403, 422}

# 可重试的状态码（限流、服务端错误）
RETRY_STATUS = {429, 500, 502, 503, 504}

MAX_RETRIES = 3
BASE_DELAY = 1.0  # 秒


async def chat_with_retry(
    provider: LLMProvider,
    messages: list[dict],
    max_retries: int = MAX_RETRIES,
    **kwargs,
) -> LLMResponse:
    """带重试的异步对话

    - 429 (限流) / 5xx (服务端错误) 自动重试，指数退避
    - 401/402/403/422 (认证/配额/参数错误) 立即失败
    """
    last_error = None

    for attempt in range(max_retries + 1):
        try:
            return await provider.chat(messages, **kwargs)
        except httpx.HTTPStatusError as e:
            status = e.response.status_code

            if status in NO_RETRY_STATUS:
                logger.error(f"[{provider.name}] 请求失败 (HTTP {status})，不重试: {e}")
                raise

            if status in RETRY_STATUS and attempt < max_retries:
                delay = BASE_DELAY * (2 ** attempt)
                logger.warning(
                    f"[{provider.name}] 请求失败 (HTTP {status})，{delay:.1f}s 后重试 "
                    f"({attempt + 1}/{max_retries})"
                )
                await asyncio.sleep(delay)
                last_error = e
                continue

            raise

        except (httpx.ConnectError, httpx.TimeoutException) as e:
            if attempt < max_retries:
                delay = BASE_DELAY * (2 ** attempt)
                logger.warning(
                    f"[{provider.name}] 连接失败，{delay:.1f}s 后重试 "
                    f"({attempt + 1}/{max_retries}): {e}"
                )
                await asyncio.sleep(delay)
                last_error = e
                continue
            raise

    # 理论上不会到这里，但以防万一
    if last_error:
        raise last_error
    raise RuntimeError("chat_with_retry 意外退出")
