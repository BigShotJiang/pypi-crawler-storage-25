"""OpenAI 兼容统一后端 - 覆盖 DeepSeek/智谱/通义/Moonshot/OpenAI/Ollama"""

from __future__ import annotations

from typing import AsyncIterator

import httpx

from zcyclaw.llm.base import LLMProvider, LLMResponse
from zcyclaw.llm.registry import ProviderSpec


class OpenAICompatProvider(LLMProvider):
    """OpenAI 兼容后端

    使用 httpx 直接调用 OpenAI 兼容 API，避免 openai SDK 依赖。
    覆盖 DeepSeek、智谱、通义、Moonshot、OpenAI、Ollama。
    """

    def __init__(
        self,
        spec: ProviderSpec,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 2048,
    ):
        self.name = spec.name
        self._spec = spec
        self._api_key = api_key
        self._base_url = (base_url or spec.default_base_url).rstrip("/")
        self._model = model or spec.default_model
        self._temperature = temperature
        self._max_tokens = max_tokens

    async def chat(self, messages: list[dict], **kwargs) -> LLMResponse:
        """异步非流式对话"""
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                f"{self._base_url}/chat/completions",
                headers=self._headers(),
                json=self._build_payload(messages, stream=False, **kwargs),
            )
            resp.raise_for_status()
            data = resp.json()

        choice = data["choices"][0]
        return LLMResponse(
            content=choice["message"]["content"],
            model=data.get("model", self._model),
            provider=self.name,
            usage=data.get("usage", {}),
            finish_reason=choice.get("finish_reason", ""),
        )

    async def chat_stream(self, messages: list[dict], **kwargs) -> AsyncIterator[str]:
        """异步流式对话"""
        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream(
                "POST",
                f"{self._base_url}/chat/completions",
                headers=self._headers(),
                json=self._build_payload(messages, stream=True, **kwargs),
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        break
                    import json

                    try:
                        chunk = json.loads(payload)
                        delta = chunk["choices"][0].get("delta", {})
                        content = delta.get("content", "")
                        if content:
                            yield content
                    except (json.JSONDecodeError, KeyError, IndexError):
                        continue

    def _headers(self) -> dict:
        """构建请求头"""
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    def _build_payload(self, messages: list[dict], stream: bool = False, **kwargs) -> dict:
        """构建请求体"""
        return {
            "model": kwargs.pop("model", self._model),
            "messages": messages,
            "temperature": kwargs.pop("temperature", self._temperature),
            "max_tokens": kwargs.pop("max_tokens", self._max_tokens),
            "stream": stream,
        }
