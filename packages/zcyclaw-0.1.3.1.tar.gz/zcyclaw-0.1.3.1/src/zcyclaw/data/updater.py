"""数据更新模块 - 检查远程版本 + 下载 + 部署"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from loguru import logger

from zcyclaw.config.paths import get_data_dir, get_seed_data_dir
from zcyclaw.config.schema import AppConfig
from zcyclaw.rag.loader import LawLoader
from zcyclaw.rag.vector_store import VectorStore

# 本地版本文件
VERSION_FILE = "version.json"


def _get_local_version() -> str:
    """获取本地数据版本"""
    version_path = get_data_dir() / VERSION_FILE
    if version_path.exists():
        try:
            data = json.loads(version_path.read_text(encoding="utf-8"))
            return data.get("version", "0")
        except Exception:
            return "0"
    return "0"


def _set_local_version(version: str) -> None:
    """设置本地数据版本"""
    version_path = get_data_dir() / VERSION_FILE
    version_path.write_text(
        json.dumps({"version": version}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _get_seed_data_path() -> Path:
    """获取包内预构建数据路径

    使用 importlib.resources 定位包内 seed_data 目录，
    无论开发模式还是 pip install 后都能正确找到。
    """
    try:
        from importlib.resources import files

        seed_dir = Path(str(files("zcyclaw.data").joinpath("seed_data")))
        if seed_dir.exists() and list(seed_dir.glob("*.md")):
            return seed_dir
    except Exception:
        pass

    # 开发模式回退：基于 __file__ 推导
    dev_seed_dir = Path(__file__).parent / "seed_data"
    if dev_seed_dir.exists() and list(dev_seed_dir.glob("*.md")):
        return dev_seed_dir

    # 旧位置回退：项目根目录/data/seed_data
    project_root = Path(__file__).parent.parent.parent.parent
    fallback_dir = project_root / "data" / "seed_data"
    if fallback_dir.exists() and list(fallback_dir.glob("*.md")):
        return fallback_dir

    return Path("")


def _deploy_seed_data() -> int:
    """部署预构建法规数据到用户数据目录"""
    source = _get_seed_data_path()
    if not source or not source.exists():
        logger.warning("未找到预构建法规数据")
        return 0

    target = get_seed_data_dir()
    target.mkdir(parents=True, exist_ok=True)

    # 复制 .md 文件
    count = 0
    for md_file in source.glob("*.md"):
        dest = target / md_file.name
        shutil.copy2(md_file, dest)
        count += 1

    logger.info(f"已部署 {count} 个法规文件到 {target}")
    return count


def _build_vector_store(config: AppConfig) -> int:
    """从法规文件构建向量库"""
    seed_dir = get_seed_data_dir()
    if not seed_dir.exists() or not list(seed_dir.glob("*.md")):
        logger.warning("法规目录为空，无法构建向量库")
        return 0

    loader = LawLoader()
    chunks = loader.load_directory(seed_dir)

    if not chunks:
        logger.warning("未加载到任何法条")
        return 0

    store = VectorStore(config)
    store.clear()
    added = store.add_chunks(chunks)
    logger.info(f"已添加 {added} 条法条到向量库")
    return added


def check_and_update(config: AppConfig | None = None) -> bool:
    """检查并更新数据

    Returns:
        True 表示数据已更新，False 表示无需更新
    """
    config = config or AppConfig()

    current_version = _get_local_version()
    # MVP 阶段固定版本
    new_version = "1.0.0"

    if current_version == new_version:
        # 检查向量库是否有数据
        store = VectorStore(config)
        if store.count() > 0:
            logger.debug("数据已是最新")
            return False

    # 部署法规文件
    count = _deploy_seed_data()
    if count == 0:
        logger.warning("没有可部署的法规数据")
        return False

    # 构建向量库
    added = _build_vector_store(config)
    if added > 0:
        _set_local_version(new_version)
        return True

    return False


def ensure_demo_data(config: AppConfig | None = None) -> bool:
    """确保 demo 数据已部署（首次运行自动调用）

    Returns:
        True 表示数据可用
    """
    config = config or AppConfig()

    store = VectorStore(config)
    if store.count() > 0:
        return True

    logger.info("首次运行，正在部署法规数据...")
    return check_and_update(config)
