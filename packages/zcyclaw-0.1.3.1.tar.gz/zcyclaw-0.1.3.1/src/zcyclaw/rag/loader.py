"""LawLoader - 从 Markdown 目录加载法规文件"""

from __future__ import annotations

from pathlib import Path

from loguru import logger

from zcyclaw.rag.chunker import LawChunk, LawChunker


class LawLoader:
    """法规文档加载器

    从指定目录加载 Markdown 格式的法规文件，
    解析文件名中的法规名称/效力层级/时效状态，
    然后使用 LawChunker 分块。
    """

    # 文件名格式: {法规名}.{效力层级}.{状态}.md
    # 简化格式: {法规名}.md (默认法律/有效)

    def __init__(self, chunker: LawChunker | None = None):
        self._chunker = chunker or LawChunker()

    def load_directory(self, directory: Path) -> list[LawChunk]:
        """加载目录下所有 .md 法规文件"""
        if not directory.exists():
            logger.warning(f"法规目录不存在: {directory}")
            return []

        all_chunks = []
        md_files = sorted(directory.glob("*.md"))

        if not md_files:
            logger.warning(f"目录下没有 .md 文件: {directory}")
            return []

        for md_file in md_files:
            chunks = self.load_file(md_file)
            all_chunks.extend(chunks)
            logger.debug(f"已加载 {md_file.name}: {len(chunks)} 条法条")

        logger.info(f"共加载 {len(md_files)} 个法规，{len(all_chunks)} 条法条")
        return all_chunks

    def load_file(self, file_path: Path) -> list[LawChunk]:
        """加载单个法规文件"""
        text = file_path.read_text(encoding="utf-8")

        # 从文件名解析元数据
        law_name, hierarchy, status = self._parse_filename(file_path.stem)

        return self._chunker.chunk(
            text=text,
            law_name=law_name,
            hierarchy=hierarchy,
            status=status,
        )

    def _parse_filename(self, stem: str) -> tuple[str, str, str]:
        """解析文件名获取法规元数据

        格式: 法规名.效力层级.状态
        示例: 政府采购法.法律.有效
        """
        parts = stem.split(".")

        law_name = parts[0] if parts else stem
        hierarchy = parts[1] if len(parts) > 1 else ""
        status = parts[2] if len(parts) > 2 else "有效"

        return law_name, hierarchy, status
