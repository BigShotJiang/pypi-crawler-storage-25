"""Embedding 适配层 - 智谱/OpenAI兼容/fastembed"""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from zcyclaw.config.schema import EmbeddingConfig


class ZhipuEmbeddingFunction:
    """智谱 Embedding - 使用 httpx 直接调用 API"""

    def __init__(self, api_key: str, model: str = "embedding-3", base_url: str | None = None):
        self._api_key = api_key
        self._model = model
        self._base_url = base_url or "https://open.bigmodel.cn/api/paas/v4"

    def __call__(self, input: list[str]) -> list[list[float]]:
        """ChromaDB 调用接口"""
        embeddings = []
        # 智谱 API 单次最多 16 条
        batch_size = 16
        for i in range(0, len(input), batch_size):
            batch = input[i : i + batch_size]
            resp = httpx.post(
                f"{self._base_url}/embeddings",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                json={"model": self._model, "input": batch},
                timeout=30.0,
            )
            resp.raise_for_status()
            data = resp.json()
            for item in data["data"]:
                embeddings.append(item["embedding"])
        return embeddings


class OpenAICompatEmbeddingFunction:
    """OpenAI 兼容 Embedding (通义/Moonshot/DeepSeek/Ollama)"""

    def __init__(self, api_key: str, model: str = "text-embedding-v3", base_url: str = ""):
        self._api_key = api_key
        self._model = model
        self._base_url = base_url.rstrip("/")

    def __call__(self, input: list[str]) -> list[list[float]]:
        embeddings = []
        batch_size = 16
        for i in range(0, len(input), batch_size):
            batch = input[i : i + batch_size]
            resp = httpx.post(
                f"{self._base_url}/embeddings",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                json={"model": self._model, "input": batch},
                timeout=30.0,
            )
            resp.raise_for_status()
            data = resp.json()
            for item in data["data"]:
                embeddings.append(item["embedding"])
        return embeddings


class FastEmbedEmbeddingFunction:
    """fastembed 本地 Embedding（可选）"""

    def __init__(self, model: str = "BAAI/bge-m3"):
        self._model_name = model
        self._model = None

    def __call__(self, input: list[str]) -> list[list[float]]:
        if self._model is None:
            try:
                from fastembed import TextEmbedding

                self._model = TextEmbedding(self._model_name)
            except ImportError:
                raise ImportError(
                    "fastembed 未安装，请运行: uv pip install 'zcyclaw[fastembed]'"
                )

        embeddings = list(self._model.embed(input))
        return [emb.tolist() for emb in embeddings]


def create_embedding_function(config: EmbeddingConfig, provider_api_key: str | None = None):
    """工厂函数：根据配置创建 EmbeddingFunction

    provider="auto" 时自动选择：优先用 zhipu API Key，其次用 provider_api_key 对应的
    OpenAI 兼容接口，最后回退到 fastembed。
    """
    provider = config.provider

    if provider == "auto":
        return _create_auto_embedding(config, provider_api_key)

    if provider == "zhipu":
        api_key = config.api_key or provider_api_key
        if not api_key:
            raise ValueError("智谱 Embedding 需要配置 API Key")
        return ZhipuEmbeddingFunction(
            api_key=api_key,
            model=config.model or "embedding-3",
            base_url=config.base_url,
        )

    elif provider == "openai_compat":
        api_key = config.api_key or provider_api_key
        base_url = config.base_url
        if not api_key or not base_url:
            raise ValueError("OpenAI 兼容 Embedding 需要配置 api_key 和 base_url")
        return OpenAICompatEmbeddingFunction(
            api_key=api_key,
            model=config.model or "text-embedding-v3",
            base_url=base_url,
        )

    elif provider == "fastembed":
        return FastEmbedEmbeddingFunction(model=config.model or "BAAI/bge-m3")

    else:
        raise ValueError(f"未知 Embedding 提供商: {provider}")


def _create_auto_embedding(config: EmbeddingConfig, provider_api_key: str | None = None):
    """auto 模式：自动选择可用的 Embedding 方案

    优先级：zhipu API → openai_compat(有 base_url) → fastembed 本地
    注意：DeepSeek/Moonshot 不提供 embedding 端点，不自动尝试。
    """
    # 1. 如果有专用 embedding api_key → zhipu
    if config.api_key:
        return ZhipuEmbeddingFunction(
            api_key=config.api_key,
            model=config.model or "embedding-3",
            base_url=config.base_url,
        )

    # 2. 如果有 provider_api_key 且有 base_url → openai_compat（通义/OpenAI 等）
    if provider_api_key and config.base_url:
        return OpenAICompatEmbeddingFunction(
            api_key=provider_api_key,
            model=config.model or "text-embedding-v3",
            base_url=config.base_url,
        )

    # 3. 尝试 fastembed 本地（无需 API Key）
    try:
        from fastembed import TextEmbedding  # noqa: F401
        return FastEmbedEmbeddingFunction(model=config.model or "BAAI/bge-m3")
    except ImportError:
        pass

    raise ValueError(
        "未找到可用的 Embedding 方案。请配置 API Key 或安装 fastembed：\n"
        "  1. 运行 zcyclaw init 配置智谱 API Key\n"
        "  2. 或安装本地 Embedding: uv pip install 'zcyclaw[fastembed]'"
    )
