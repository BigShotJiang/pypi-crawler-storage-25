"""LawRetriever - 向量检索 + 元数据过滤 + 效力层级加权"""

from __future__ import annotations

from zcyclaw.config.schema import AppConfig
from zcyclaw.rag.vector_store import VectorStore
from zcyclaw.types import HierarchyLevel

# 效力层级加权系数（层级越高，权重越大）
HIERARCHY_BOOST = {
    HierarchyLevel.法律: 0.15,
    HierarchyLevel.行政法规: 0.10,
    HierarchyLevel.地方性法规: 0.05,
    HierarchyLevel.部门规章: 0.0,
}


class LawRetriever:
    """法规检索器

    核心逻辑：
    1. 向量相似度检索 top_k*2 条
    2. 时效性过滤：排除已废止法条
    3. 效力层级加权：法律 > 行政法规 > 部门规章
    4. 返回 top_k 条最相关法条
    """

    def __init__(self, config: AppConfig, store: VectorStore | None = None):
        self._config = config
        self._store = store or VectorStore(config)

    def retrieve(self, query: str, top_k: int | None = None) -> list[dict]:
        """检索相关法条

        Args:
            query: 用户问题
            top_k: 返回条数，默认从配置读取

        Returns:
            排序后的法条列表
        """
        top_k = top_k or self._config.agent.top_k
        # 多检索一些，过滤后取 top_k
        search_k = min(top_k * 3, 20)

        results = self._store.query(query, top_k=search_k)
        if not results:
            return []

        # 过滤已废止
        filtered = [r for r in results if r["metadata"].get("status", "有效") != "已废止"]

        # 效力层级加权
        for item in filtered:
            hierarchy = item["metadata"].get("hierarchy", "")
            try:
                level = HierarchyLevel[hierarchy]
                boost = HIERARCHY_BOOST.get(level, 0.0)
            except (KeyError, ValueError):
                boost = 0.0

            # distance 越小越相似，boost 减小 distance（更靠前）
            item["adjusted_distance"] = item["distance"] - boost

        # 按 adjusted_distance 排序
        filtered.sort(key=lambda x: x["adjusted_distance"])

        return filtered[:top_k]
