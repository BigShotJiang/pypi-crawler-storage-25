"""ChromaDB 向量存储层"""

from __future__ import annotations

from pathlib import Path

import chromadb
from loguru import logger

from zcyclaw.config.paths import get_vector_store_dir
from zcyclaw.config.schema import AppConfig
from zcyclaw.rag.chunker import LawChunk
from zcyclaw.rag.embeddings import create_embedding_function


class VectorStore:
    """ChromaDB 向量库

    - PersistentClient 本地持久化
    - Collection: "gov_laws"
    - 元数据字段: law_name, article_number, chapter, hierarchy, status
    """

    COLLECTION_NAME = "gov_laws"

    def __init__(self, config: AppConfig, persist_dir: Path | None = None):
        self._config = config
        self._persist_dir = persist_dir or get_vector_store_dir()
        self._client = chromadb.PersistentClient(path=str(self._persist_dir))
        self._collection = None

    def _get_collection(self):
        """懒加载 collection"""
        if self._collection is None:
            try:
                emb_func = create_embedding_function(
                    self._config.embedding,
                    provider_api_key=self._resolve_embedding_api_key(),
                )
                self._collection = self._client.get_or_create_collection(
                    name=self.COLLECTION_NAME,
                    embedding_function=emb_func,
                    metadata={"hnsw:space": "cosine"},
                )
            except Exception as e:
                logger.warning(f"Embedding 初始化失败，使用默认: {e}")
                self._collection = self._client.get_or_create_collection(
                    name=self.COLLECTION_NAME,
                    metadata={"hnsw:space": "cosine"},
                )
        return self._collection

    def _resolve_embedding_api_key(self) -> str | None:
        """解析 Embedding API Key：优先用 embedding 配置，
        其次用对应 provider，最后用默认 provider"""
        emb = self._config.embedding
        if emb.api_key:
            return emb.api_key

        # 尝试从 providers 配置中获取对应 provider 的 key
        from zcyclaw.config.schema import get_provider_config
        provider_cfg = get_provider_config(self._config, emb.provider)
        if provider_cfg and getattr(provider_cfg, "api_key", None):
            return provider_cfg.api_key

        # 尝试默认 LLM provider 的 key
        default_cfg = get_provider_config(self._config, self._config.default_provider)
        if default_cfg and getattr(default_cfg, "api_key", None):
            return default_cfg.api_key

        return None

    def add_chunks(self, chunks: list[LawChunk]) -> int:
        """添加法条分块到向量库"""
        if not chunks:
            return 0

        collection = self._get_collection()

        # 生成唯一 ID: law_name + article_number + hash
        ids = []
        documents = []
        metadatas = []

        for i, chunk in enumerate(chunks):
            chunk_id = f"{chunk.law_name}::{chunk.article_number or i}"
            # ChromaDB ID 不允许特殊字符
            chunk_id = chunk_id.replace(" ", "_").replace("(", "").replace(")", "")

            ids.append(chunk_id)
            documents.append(chunk.content)
            metadatas.append({
                "law_name": chunk.law_name,
                "article_number": chunk.article_number,
                "chapter": chunk.chapter,
                "hierarchy": chunk.hierarchy,
                "status": chunk.status,
            })

        # ChromaDB 单次最多添加 5000 条
        batch_size = 5000
        added = 0
        for i in range(0, len(ids), batch_size):
            batch_ids = ids[i : i + batch_size]
            batch_docs = documents[i : i + batch_size]
            batch_meta = metadatas[i : i + batch_size]

            # 使用 upsert 避免重复
            collection.upsert(
                ids=batch_ids,
                documents=batch_docs,
                metadatas=batch_meta,
            )
            added += len(batch_ids)

        logger.info(f"已添加 {added} 条法条到向量库")
        return added

    def query(
        self,
        query_text: str,
        top_k: int = 5,
        where: dict | None = None,
    ) -> list[dict]:
        """向量检索

        Args:
            query_text: 查询文本
            top_k: 返回条数
            where: ChromaDB 元数据过滤条件

        Returns:
            检索结果列表，每项包含 document, metadata, distance
        """
        collection = self._get_collection()

        kwargs = {
            "query_texts": [query_text],
            "n_results": min(top_k, collection.count()) if collection.count() > 0 else 1,
        }
        if where:
            kwargs["where"] = where

        if collection.count() == 0:
            logger.warning("向量库为空，无法查询")
            return []

        results = collection.query(**kwargs)

        # 整理结果
        items = []
        if results and results["documents"] and results["documents"][0]:
            for i, doc in enumerate(results["documents"][0]):
                metadata = results["metadatas"][0][i] if results["metadatas"] else {}
                distance = results["distances"][0][i] if results["distances"] else 0.0
                items.append({
                    "document": doc,
                    "metadata": metadata,
                    "distance": distance,
                })

        return items

    def count(self) -> int:
        """获取法条数量"""
        try:
            return self._get_collection().count()
        except Exception:
            return 0

    def get_stats(self) -> dict:
        """获取统计信息"""
        collection = self._get_collection()
        count = collection.count()

        # 获取不重复的法规名称
        law_names = set()
        if count > 0:
            try:
                all_meta = collection.get(include=["metadatas"])
                for meta in all_meta.get("metadatas", []):
                    if meta and "law_name" in meta:
                        law_names.add(meta["law_name"])
            except Exception:
                pass

        return {
            "chunk_count": count,
            "law_count": len(law_names),
            "path": str(self._persist_dir),
        }

    def clear(self) -> None:
        """清空向量库"""
        try:
            self._client.delete_collection(self.COLLECTION_NAME)
            self._collection = None
            logger.info("向量库已清空")
        except Exception:
            pass
