"""法规专用分块器 - 按"条"分块，保留章节/引用关系"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class LawChunk:
    """法规分块"""

    content: str
    law_name: str = ""
    article_number: str = ""  # 第X条
    chapter: str = ""  # 所属章节
    hierarchy: str = ""  # 效力层级
    status: str = "有效"  # 时效状态
    metadata: dict = field(default_factory=dict)


class LawChunker:
    """法规分块器

    核心逻辑：
    - 按"第X条"切分
    - 保留章节归属关系
    - 过短法条（<20字）合并到下一条
    """

    # 匹配"第X条"模式（兼容 **第X条** Markdown加粗格式）
    ARTICLE_PATTERN = re.compile(
        r"^\*{0,2}第[一二三四五六七八九十百千零\d]+条\*{0,2}\s*",
        re.MULTILINE,
    )
    # 匹配章节标题（兼容 ## 第X章 Markdown标题格式）
    CHAPTER_PATTERN = re.compile(
        r"^#{0,3}\s*(第[一二三四五六七八九十百千零\d]+[编章节部分])\s*(.*)$",
        re.MULTILINE,
    )

    def chunk(
        self,
        text: str,
        law_name: str = "",
        hierarchy: str = "",
        status: str = "有效",
    ) -> list[LawChunk]:
        """将法规文本分块"""
        # 先找到所有章节位置
        chapters = self._find_chapters(text)

        # 找到所有法条位置
        article_positions = self._find_articles(text)

        if not article_positions:
            # 没有"条"结构，整篇作为一块
            return [LawChunk(
                content=text.strip(),
                law_name=law_name,
                hierarchy=hierarchy,
                status=status,
            )]

        # 按法条切分
        chunks = []
        for i, (match, art_num) in enumerate(article_positions):
            start = match.end()
            has_next = i + 1 < len(article_positions)
            end = article_positions[i + 1][0].start() if has_next else len(text)
            content = text[start:end].strip()

            if not content and i + 1 < len(article_positions):
                continue  # 空条跳过

            # 确定所属章节
            chapter = self._find_chapter_for_position(chapters, match.start())

            chunks.append(LawChunk(
                content=f"第{art_num}条 {content}",
                law_name=law_name,
                article_number=f"第{art_num}条",
                chapter=chapter,
                hierarchy=hierarchy,
                status=status,
            ))

        # 合并过短法条
        chunks = self._merge_short_chunks(chunks)

        return chunks

    def _find_articles(self, text: str) -> list[tuple[re.Match, str]]:
        """找到所有法条位置"""
        results = []
        for m in self.ARTICLE_PATTERN.finditer(text):
            # 提取条号（去除 Markdown 加粗标记）
            matched = m.group().strip().replace("*", "")
            art_num = matched.replace("第", "").replace("条", "").strip()
            results.append((m, art_num))
        return results

    def _find_chapters(self, text: str) -> list[tuple[int, str]]:
        """找到所有章节位置"""
        results = []
        for m in self.CHAPTER_PATTERN.finditer(text):
            results.append((m.start(), f"{m.group(1)} {m.group(2)}".strip()))
        return sorted(results, key=lambda x: x[0])

    def _find_chapter_for_position(self, chapters: list[tuple[int, str]], pos: int) -> str:
        """根据位置确定所属章节"""
        current_chapter = ""
        for ch_pos, ch_name in chapters:
            if ch_pos <= pos:
                current_chapter = ch_name
            else:
                break
        return current_chapter

    def _merge_short_chunks(self, chunks: list[LawChunk], min_length: int = 15) -> list[LawChunk]:
        """合并过短法条到下一条（仅当法条正文不足 min_length 字符时）"""
        if len(chunks) <= 1:
            return chunks

        merged = []
        i = 0
        while i < len(chunks):
            chunk = chunks[i]
            if len(chunk.content) < min_length and i + 1 < len(chunks):
                # 合并到下一条
                chunks[i + 1].content = chunk.content + "\n" + chunks[i + 1].content
                # 跳过当前条，不加入 merged
            else:
                merged.append(chunk)
            i += 1

        return merged
