"""TUI 应用 - 基于 prompt_toolkit 的交互式界面"""

from __future__ import annotations

import asyncio

from loguru import logger
from prompt_toolkit.application import Application
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.filters import has_focus
from prompt_toolkit.key_binding import KeyBindings, merge_key_bindings
from prompt_toolkit.key_binding.defaults import load_key_bindings
from prompt_toolkit.layout.containers import HSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.layout.layout import Layout
from prompt_toolkit.styles import Style
from prompt_toolkit.widgets import Label

from zcyclaw.config.loader import load_config
from zcyclaw.qa import answer_question_stream
from zcyclaw.session import Session


class MessageBuffer:
    """消息缓冲区，存储历史消息"""

    def __init__(self, max_size: int = 100):
        self._messages: list[dict[str, str]] = []
        self._max_size = max_size

    def add_user(self, text: str) -> None:
        self._messages.append({"role": "user", "content": text})
        self._trim()

    def add_assistant(self, text: str) -> None:
        self._messages.append({"role": "assistant", "content": text})
        self._trim()

    def _trim(self) -> None:
        if len(self._messages) > self._max_size:
            self._messages = self._messages[-self._max_size :]

    def get_formatted(self) -> list[tuple[str, str]]:
        """获取格式化后的消息列表 (style_str, text)"""
        lines = []
        for msg in self._messages:
            role = msg["role"]
            content = msg["content"]
            if role == "user":
                lines.append(("fg:ansimagenta bold", f"\n你: {content}\n"))
            else:
                for line in content.split("\n"):
                    lines.append(("fg:ansicyan", f"\n助手: {line}\n"))
        return lines


class TUIApp:
    """TUI 应用主类

    特性：
    - 顶部标题栏
    - 中部消息历史区域（只读）
    - 底部输入框
    - 流式输出支持
    - 上下文记忆
    """

    def __init__(self):
        self._config = load_config()
        self._session = Session()
        self._msg_buffer = MessageBuffer()
        self._streaming = False
        self._current_answer = ""
        self._provider_name = self._config.default_provider

    def _create_layout(self) -> Layout:
        """创建布局"""
        # 标题栏
        header = Label(
            text="政府采购智能顾问 (zcyclaw) - 输入问题开始对话，/quit 退出",
            style="bg:darkblue fg:white bold",
        )

        # 消息显示区域
        self._output_control = FormattedTextControl(
            text=self._get_output_text,
            focusable=False,
        )
        output_window = Window(
            content=self._output_control,
            wrap_text=True,
            style="bg:#1e1e1e fg:#cccccc",
        )

        # 输入区域
        self._input_buffer = Buffer(
            multiline=False,
            accept_handler=self._on_input_accept,
        )
        self._input_window = Window(
            content=self._input_buffer,
            height=1,
            style="bg:#2d2d2d fg:#ffffff",
        )

        # 底部状态栏
        status_text = (
            f"[status] 对话轮次: {self._session.turn_count} | "
            f"提供商: {self._provider_name} | /quit 退出"
        )
        self._status_control = FormattedTextControl(text=status_text)
        status_bar = Window(
            content=self._status_control,
            height=1,
            style="bg:#333333 fg:#aaaaaa",
        )

        # 组合布局
        container = HSplit(
            [
                header,
                output_window,
                self._input_window,
                status_bar,
            ]
        )

        return Layout(container, focused_element=self._input_window)

    def _get_output_text(self) -> list[tuple[str, str]]:
        """获取输出文本"""
        lines: list[tuple[str, str]] = []

        # 欢迎信息
        lines.append(("fg:#888888 italic", "\n欢迎使用政府采购智能顾问\n"))
        lines.append(
            (
                "fg:#888888",
                "基于 RAG 检索的法规问答，支持多轮对话上下文记忆\n",
            )
        )

        # 历史消息
        lines.extend(self._msg_buffer.get_formatted())

        # 流式输出中的当前回答
        if self._streaming and self._current_answer:
            lines.append(("fg:ansicyan", f"\n助手(typing...): {self._current_answer}\n"))

        return lines

    def _create_key_bindings(self) -> KeyBindings:
        """创建按键绑定"""
        kb = KeyBindings()

        @kb.add("c-c", filter=has_focus(self._input_buffer))
        async def _cancel_input(event):
            """Ctrl+C 取消输入"""
            self._input_buffer.text = ""
            event.app.output.flush()

        @kb.add("c-q")
        async def _quit_app(event):
            """Ctrl+Q 退出"""
            event.app.exit()

        return kb

    def _on_input_accept(self, buffer: Buffer) -> None:
        """输入确认处理"""
        text = buffer.text.strip()
        if not text:
            return

        if text.lower() in ("/quit", "/exit", "/q"):
            self._running = False
            return

        # 清空输入
        buffer.text = ""

        # 添加用户消息
        self._msg_buffer.add_user(text)
        self._refresh_output()

        # 异步处理回答
        asyncio.create_task(self._generate_response(text))

    async def _generate_response(self, question: str) -> None:
        """生成回答（流式）"""
        self._streaming = True
        self._current_answer = ""
        self._refresh_output()

        full_answer = ""

        try:
            # 在后台线程运行同步流式生成器，主线程异步消费
            loop = asyncio.get_event_loop()
            queue: asyncio.Queue[str] = asyncio.Queue()

            def sync_producer():
                """同步生成器，在后台线程运行"""
                try:
                    for chunk in answer_question_stream(
                        question,
                        self._config,
                        provider_name=self._provider_name,
                        session=self._session,
                    ):
                        # 放入队列，如果队列满则阻塞
                        loop.call_soon_threadsafe(lambda c: queue.put_nowait(c), chunk)
                        # 小延迟避免过度占用CPU
                        import time
                        time.sleep(0.01)
                except Exception as e:
                    logger.error(f"流式生成异常: {e}")
                finally:
                    loop.call_soon_threadsafe(lambda: queue.put_nowait(None))

            # 在线程池中启动生产者
            import concurrent.futures
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            executor.submit(sync_producer)
            executor.shutdown(wait=False)

            # 异步消费队列
            while True:
                try:
                    chunk = await asyncio.wait_for(queue.get(), timeout=30.0)
                except asyncio.TimeoutError:
                    continue

                if chunk is None:
                    break

                if isinstance(chunk, str):
                    full_answer += chunk
                    self._current_answer = full_answer
                    self._refresh_output()

        except Exception as e:
            logger.error(f"生成回答失败: {e}")
            full_answer = f"抱歉，发生错误: {e}"

        # 完成回答
        self._streaming = False
        self._current_answer = ""
        self._msg_buffer.add_assistant(full_answer)
        self._session.add_exchange(question, full_answer)
        self._refresh_output()

    def _refresh_output(self) -> None:
        """刷新输出区域"""
        if hasattr(self, "_output_control"):
            self._output_control.text = self._get_output_text()

    async def run_async(self) -> None:
        """异步运行应用"""
        self._running = True

        # 创建布局和按键绑定
        layout = self._create_layout()
        key_bindings = merge_key_bindings(
            [
                load_key_bindings(),
                self._create_key_bindings(),
            ]
        )

        # 创建应用
        app = Application(
            layout=layout,
            key_bindings=key_bindings,
            style=Style.from_dict(
                {
                    "outputfield": "bg:#1e1e1e",
                    "buffer": "bg:#2d2d2d #ffffff",
                }
            ),
            erase_when_done=False,
            replace_environment=False,
        )

        self._app = app

        # 运行
        await app.run_async()

    def run(self) -> None:
        """同步运行入口"""
        asyncio.run(self.run_async())


def run_tui() -> None:
    """TUI 入口函数"""
    app = TUIApp()
    app.run()
