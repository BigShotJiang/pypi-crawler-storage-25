"""StreamRenderer - 流式输出渲染"""

from __future__ import annotations

import time

from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.spinner import Spinner


class StreamRenderer:
    """流式输出渲染器

    - 等待阶段：显示 spinner
    - 内容到达后：切换到 Rich Live 渲染 Markdown
    - 150ms 节流，避免频繁刷新
    """

    def __init__(self):
        self._console = Console()
        self._live: Live | None = None
        self._content = ""
        self._last_update = 0.0
        self._throttle = 0.15  # 150ms

    def __enter__(self):
        spinner = Spinner("dots", text="思考中...")
        self._live = Live(spinner, console=self._console, transient=True)
        self._live.__enter__()
        return self

    def __exit__(self, *args):
        if self._live:
            self._live.__exit__(*args)

    def update(self, chunk: str):
        """接收流式内容片段"""
        self._content += chunk
        now = time.monotonic()
        if now - self._last_update >= self._throttle:
            self._last_update = now
            if self._live:
                self._live.update(Markdown(self._content))

    def finish(self, content: str | None = None):
        """完成渲染，输出最终内容"""
        if content:
            self._content = content
        if self._live:
            self._live.update(Markdown(self._content))
            self._live.refresh()
        # 退出 Live 上下文，让最终内容留在终端
        if self._live:
            self._live.stop()
            # 最终输出确保完整渲染
            self._console.print(Markdown(self._content))
