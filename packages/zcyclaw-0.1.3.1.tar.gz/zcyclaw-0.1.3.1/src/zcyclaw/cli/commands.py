"""Typer CLI 命令定义"""

import typer
from rich import print as rprint

from zcyclaw import __version__

app = typer.Typer(
    name="zcyclaw",
    help="政府采购智能顾问 - 基于RAG的法规问答CLI工具",
    no_args_is_help=True,
)


def _version_callback(value: bool):
    if value:
        rprint(f"zcyclaw {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None, "--version", "-v", callback=_version_callback, is_eager=True, help="显示版本号"
    ),
):
    """政府采购智能顾问"""
    pass


@app.command()
def init():
    """交互式配置向导"""
    rprint("[bold cyan]政府采购智能顾问 - 配置向导[/bold cyan]")
    rprint("")

    from zcyclaw.config.loader import load_config, save_config
    from zcyclaw.config.schema import get_provider_config
    from zcyclaw.llm.registry import get_spec, list_providers

    config = load_config()

    # 动态列出所有提供商
    providers = list_providers()
    rprint("[bold]选择默认 LLM 提供商:[/bold]")
    for i, spec in enumerate(providers, 1):
        recommend = " (推荐)" if spec.name == "deepseek" else ""
        rprint(f"  {i}. {spec.display_name}{recommend}")
    choice = typer.prompt("请输入编号", default="1")

    try:
        idx = int(choice) - 1
        provider_name = providers[idx].name if 0 <= idx < len(providers) else "deepseek"
    except ValueError:
        provider_name = "deepseek"

    spec = get_spec(provider_name)
    provider_config = get_provider_config(config, provider_name)

    # 配置 API Key
    if spec and spec.needs_api_key:
        rprint(f"\n[bold]配置 {spec.display_name}:[/bold]")
        rprint(f"[dim]  环境变量: {spec.env_key_hint}[/dim]")
        api_key = typer.prompt("  API Key（回车跳过）", default="", hide_input=True)
        if provider_config and api_key:
            provider_config.api_key = api_key

    # 配置 Model
    if spec and provider_config:
        current_model = getattr(provider_config, "model", None) or spec.default_model
        model = typer.prompt("  模型名称", default=current_model)
        if model and hasattr(provider_config, "model"):
            provider_config.model = model

    # 配置 Base URL
    if spec and provider_config and hasattr(provider_config, "base_url"):
        current_url = getattr(provider_config, "base_url", None) or spec.default_base_url
        if current_url:
            base_url = typer.prompt("  API 地址", default=current_url)
            if base_url:
                provider_config.base_url = base_url

    config.default_provider = provider_name

    save_config(config)
    rprint("\n[green]✓ 配置已保存到 ~/.zcyclaw/config.json[/green]")
    rprint(f"[green]✓ 默认提供商: {spec.display_name if spec else provider_name}[/green]")


@app.command()
def ask(
    question: str = typer.Argument(None, help="提问内容"),
    interactive: bool = typer.Option(False, "--interactive", "-i", help="交互式多轮问答"),
    provider: str = typer.Option(None, "--provider", "-p", help="指定LLM提供商"),
):
    """法规智能问答"""
    if interactive:
        _interactive_ask(provider)
    elif question:
        _single_ask(question, provider)
    else:
        rprint("[red]请提供问题内容，或使用 -i 进入交互模式[/red]")
        raise typer.Exit(1)


def _single_ask(question: str, provider: str | None = None):
    """单次问答（流式输出）"""
    from zcyclaw.cli.stream import StreamRenderer
    from zcyclaw.config.loader import load_config
    from zcyclaw.qa import answer_question_stream

    config = load_config()
    provider_name = provider or config.default_provider

    with StreamRenderer() as renderer:
        for chunk in answer_question_stream(question, config, provider_name=provider_name):
            renderer.update(chunk)
        renderer.finish()


def _interactive_ask(provider: str | None = None):
    """交互式多轮问答（流式输出）"""
    from zcyclaw.cli.stream import StreamRenderer
    from zcyclaw.config.loader import load_config
    from zcyclaw.qa import answer_question_stream
    from zcyclaw.session import Session

    config = load_config()
    provider_name = provider or config.default_provider
    session = Session()

    rprint("[bold cyan]政府采购智能顾问 - 交互式问答[/bold cyan]")
    rprint("[dim]输入问题开始对话，输入 /quit 退出[/dim]")
    rprint("")

    while True:
        try:
            question = input("你> ").strip()
        except (EOFError, KeyboardInterrupt):
            rprint("\n[dim]再见！[/dim]")
            break

        if not question:
            continue
        if question.lower() in ("/quit", "/exit", "/q"):
            rprint("[dim]再见！[/dim]")
            break

        answer = ""
        with StreamRenderer() as renderer:
            for chunk in answer_question_stream(
                question, config, provider_name=provider_name, session=session
            ):
                answer += chunk
                renderer.update(chunk)
            renderer.finish()

        session.add_exchange(question, answer)


@app.command()
def update():
    """更新法规数据"""
    from zcyclaw.data.updater import check_and_update

    rprint("[cyan]正在检查数据更新...[/cyan]")
    updated = check_and_update()
    if updated:
        rprint("[green]✓ 数据已更新[/green]")
    else:
        rprint("[dim]数据已是最新[/dim]")


@app.command()
def stats():
    """显示数据统计"""
    from zcyclaw.config.loader import load_config
    from zcyclaw.rag.vector_store import VectorStore

    config = load_config()
    try:
        store = VectorStore(config)
        info = store.get_stats()
        rprint("[bold]法规数据统计[/bold]")
        rprint(f"  法规数量: {info.get('law_count', 0)}")
        rprint(f"  法条片段: {info.get('chunk_count', 0)}")
        rprint(f"  向量库路径: {info.get('path', 'N/A')}")
    except Exception as e:
        rprint(f"[red]无法读取数据统计: {e}[/red]")
        rprint("[dim]提示: 运行 zcyclaw update 初始化法规数据[/dim]")


@app.command()
def tui(
    provider: str = typer.Option(None, "--provider", "-p", help="指定LLM提供商"),
):
    """启动交互式TUI界面（流式输出+上下文记忆）"""
    from zcyclaw.config.loader import load_config
    from zcyclaw.tui.app import run_tui

    config = load_config()
    provider_name = provider or config.default_provider

    rprint("[bold cyan]启动 TUI 模式...[/bold cyan]")
    rprint(f"[dim]使用提供商: {provider_name}[/dim]")
    rprint("[dim]按 Ctrl+Q 或输入 /quit 退出[/dim]")
    rprint("")

    # 设置提供商
    if provider:
        config.default_provider = provider

    run_tui()
