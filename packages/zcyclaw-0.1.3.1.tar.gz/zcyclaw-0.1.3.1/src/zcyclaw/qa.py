"""核心问答模块 - 检索→构造 Prompt→LLM 生成"""

from __future__ import annotations

from typing import TYPE_CHECKING

from loguru import logger

from zcyclaw.config.schema import AppConfig
from zcyclaw.data.updater import ensure_demo_data
from zcyclaw.llm.factory import create_provider
from zcyclaw.rag.retriever import LawRetriever
from zcyclaw.rag.vector_store import VectorStore

if TYPE_CHECKING:
    from zcyclaw.session import Session

SYSTEM_PROMPT = """\
你是一位专业的政府采购法规顾问。你的职责是基于中国政府采购相关法律法规，
为用户提供准确、专业的解答。

## 回答规范

1. **法条标注**：每个论点必须标注具体法条来源，格式为「《法规名称》第X条」
2. **效力层级**：当多个法规有不同规定时，按效力层级
   （法律 > 行政法规 > 部门规章 > 地方性法规）说明适用规则
3. **时效性**：引用法条前确认其是否有效，已废止的法规不能作为依据
4. **专业准确**：不确定的内容明确告知，不得编造法条
5. **结构清晰**：使用标题、列表、引用等格式组织回答

## 检索上下文

以下是检索到的相关法规条文，请以此为基础回答问题：

{context}
"""


def answer_question(
    question: str,
    config: AppConfig,
    provider_name: str | None = None,
    session: "Session | None" = None,
) -> str:
    """回答用户问题

    流程：检索相关法条 → 构造 Prompt → LLM 生成

    Args:
        question: 用户问题
        config: 应用配置
        provider_name: LLM 提供商名称
        session: 会话记忆（可选）

    Returns:
        回答内容
    """
    provider_name = provider_name or config.default_provider

    # 0. 确保数据可用
    ensure_demo_data(config)

    # 1. 检索相关法条
    context = _retrieve_context(question, config)

    if not context:
        return (
            "抱歉，未能检索到相关法规条文。请确认：\n"
            "1. 是否已运行 `zcyclaw update` 初始化法规数据\n"
            "2. 问题是否与政府采购法规相关\n"
        )

    # 2. 构造消息
    messages = _build_messages(question, context, session)

    # 3. LLM 生成
    try:
        provider = create_provider(provider_name, config)
        response = provider.chat_sync_with_retry(messages)
        return response.content
    except Exception as e:
        logger.error(f"LLM 调用失败: {e}")
        return (
            f"抱歉，调用 {provider_name} 失败：{e}\n\n"
            "请检查：\n"
            "1. API Key 是否正确配置（运行 `zcyclaw init`）\n"
            "2. 网络连接是否正常\n"
        )


def answer_question_stream(
    question: str,
    config: AppConfig,
    provider_name: str | None = None,
    session: "Session | None" = None,
):
    """流式回答用户问题，yield 内容片段

    流程与 answer_question 相同，但使用 chat_stream 逐片段输出。
    """
    provider_name = provider_name or config.default_provider

    # 0. 确保数据可用
    ensure_demo_data(config)

    # 1. 检索相关法条
    context = _retrieve_context(question, config)

    if not context:
        yield (
            "抱歉，未能检索到相关法规条文。请确认：\n"
            "1. 是否已运行 `zcyclaw update` 初始化法规数据\n"
            "2. 问题是否与政府采购法规相关\n"
        )
        return

    # 2. 构造消息
    messages = _build_messages(question, context, session)

    # 3. LLM 流式生成
    try:
        provider = create_provider(provider_name, config)
        for chunk in provider.chat_stream_sync(messages):
            yield chunk
    except Exception as e:
        logger.error(f"LLM 流式调用失败: {e}")
        yield (
            f"\n\n抱歉，调用 {provider_name} 失败：{e}\n\n"
            "请检查：\n"
            "1. API Key 是否正确配置（运行 `zcyclaw init`）\n"
            "2. 网络连接是否正常\n"
        )


def _retrieve_context(question: str, config: AppConfig) -> str:
    """检索相关法规上下文"""
    try:
        store = VectorStore(config)
        if store.count() == 0:
            logger.warning("向量库为空，无法检索")
            return ""

        retriever = LawRetriever(config, store)
        results = retriever.retrieve(question)

        if not results:
            return ""

        # 构造上下文文本
        context_parts = []
        for i, item in enumerate(results, 1):
            doc = item["document"]
            meta = item["metadata"]
            law_name = meta.get("law_name", "未知法规")
            article = meta.get("article_number", "")
            hierarchy = meta.get("hierarchy", "")
            status = meta.get("status", "有效")

            source = f"《{law_name}》"
            if article:
                source += f" {article}"
            if hierarchy:
                source += f" [{hierarchy}]"
            if status != "有效":
                source += f" ({status})"

            context_parts.append(f"[{i}] {source}\n{doc}")

        return "\n\n".join(context_parts)

    except Exception as e:
        logger.error(f"检索失败: {e}")
        return ""


def _build_messages(
    question: str,
    context: str,
    session: "Session | None" = None,
) -> list[dict]:
    """构造 LLM 消息列表"""
    messages = []

    # System prompt
    messages.append({
        "role": "system",
        "content": SYSTEM_PROMPT.format(context=context),
    })

    # 会话历史
    if session:
        for exchange in session.get_history():
            messages.append({"role": "user", "content": exchange["question"]})
            messages.append({"role": "assistant", "content": exchange["answer"]})

    # 当前问题
    messages.append({"role": "user", "content": question})

    return messages
