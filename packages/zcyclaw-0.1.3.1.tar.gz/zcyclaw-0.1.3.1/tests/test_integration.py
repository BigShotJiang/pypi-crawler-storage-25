"""集成测试 - 分块器/配置/注册表/环境变量"""

import os
import tempfile
from pathlib import Path

import pytest

from zcyclaw.config.schema import AppConfig, DeepSeekConfig, ProvidersConfig
from zcyclaw.config.loader import load_config, save_config
from zcyclaw.llm.registry import list_providers, get_spec, PROVIDERS
from zcyclaw.llm.factory import create_provider
from zcyclaw.rag.chunker import LawChunker, LawChunk
from zcyclaw.rag.loader import LawLoader
from zcyclaw.session import Session


class TestLawChunker:
    """测试法规分块器"""

    def setup_method(self):
        self.chunker = LawChunker()

    def test_basic_chunking(self):
        text = (
            "第一条 为了规范政府采购行为，制定本法。\n"
            "第二条 本法所称政府采购，是指各级国家机关的采购行为。\n"
            "第三条 政府采购应当遵循公开透明原则和公平竞争原则。"
        )
        chunks = self.chunker.chunk(text, law_name="测试法")
        assert len(chunks) == 3
        assert chunks[0].article_number == "第一条"
        assert chunks[1].article_number == "第二条"
        assert chunks[2].article_number == "第三条"

    def test_with_chapters(self):
        text = (
            "第一章 总则\n"
            "第一条 为了规范政府采购行为，制定本法。\n"
            "第二章 附则\n"
            "第二条 本法自2003年1月1日起施行。"
        )
        chunks = self.chunker.chunk(text, law_name="测试法")
        assert len(chunks) == 2
        assert "第一章" in chunks[0].chapter
        assert "第二章" in chunks[1].chapter

    def test_no_articles(self):
        text = "这是一段没有法条格式的文本"
        chunks = self.chunker.chunk(text, law_name="测试法")
        assert len(chunks) == 1
        assert chunks[0].content == text

    def test_metadata_preserved(self):
        text = "第一条 内容"
        chunks = self.chunker.chunk(text, law_name="政府采购法", hierarchy="法律", status="有效")
        assert chunks[0].law_name == "政府采购法"
        assert chunks[0].hierarchy == "法律"
        assert chunks[0].status == "有效"

    def test_chinese_numbered_articles(self):
        text = "第一百二十三条 长条号内容"
        chunks = self.chunker.chunk(text, law_name="测试法")
        assert len(chunks) == 1
        assert "一百二十三" in chunks[0].article_number


class TestConfig:
    """测试配置管理"""

    def test_default_config(self):
        config = AppConfig()
        assert config.default_provider == "deepseek"
        assert config.providers.deepseek.model == "deepseek-chat"

    def test_env_override(self, monkeypatch):
        monkeypatch.setenv("ZCYCLAW_PROVIDERS__DEEPSEEK__API_KEY", "sk-test-123")
        # BaseSettings 自动从环境变量读取
        config = AppConfig()
        assert config.providers.deepseek.api_key == "sk-test-123"

    def test_config_round_trip(self, tmp_path):
        config = AppConfig(default_provider="zhipu")
        config.providers.zhipu.api_key = "test-key"

        # 保存
        config_path = tmp_path / "config.json"
        config_path.write_text(
            config.model_dump_json(indent=2),
            encoding="utf-8",
        )

        # 加载
        loaded = AppConfig.model_validate_json(config_path.read_text(encoding="utf-8"))
        assert loaded.default_provider == "zhipu"
        assert loaded.providers.zhipu.api_key == "test-key"


class TestProviderRegistry:
    """测试提供商注册表"""

    def test_all_providers_registered(self):
        specs = list_providers()
        assert len(specs) >= 7

    def test_get_spec(self):
        spec = get_spec("deepseek")
        assert spec is not None
        assert spec.backend == "openai_compat"
        assert spec.needs_api_key is True

    def test_ollama_no_api_key(self):
        spec = get_spec("ollama")
        assert spec is not None
        assert spec.needs_api_key is False

    def test_anthropic_backend(self):
        spec = get_spec("anthropic")
        assert spec is not None
        assert spec.backend == "anthropic"


class TestFactory:
    """测试工厂函数"""

    def test_create_openai_compat_provider(self):
        config = AppConfig()
        provider = create_provider("deepseek", config)
        assert provider.name == "deepseek"

    def test_create_anthropic_provider(self):
        config = AppConfig()
        provider = create_provider("anthropic", config)
        assert provider.name == "anthropic"

    def test_create_unknown_provider(self):
        config = AppConfig()
        with pytest.raises(ValueError, match="未知提供商"):
            create_provider("nonexistent", config)


class TestLawLoader:
    """测试法规加载器"""

    def test_load_directory(self, tmp_path):
        # 创建测试法规文件
        (tmp_path / "测试法.法律.有效.md").write_text(
            "第一条 为了规范政府采购行为，制定本法。\n第二条 本法所称政府采购，是指采购行为。", encoding="utf-8"
        )
        (tmp_path / "测试条例.行政法规.有效.md").write_text(
            "第一条 根据政府采购法，制定本条例。", encoding="utf-8"
        )

        loader = LawLoader()
        chunks = loader.load_directory(tmp_path)
        assert len(chunks) >= 3

    def test_parse_filename(self):
        loader = LawLoader()
        name, hierarchy, status = loader._parse_filename("政府采购法.法律.有效")
        assert name == "政府采购法"
        assert hierarchy == "法律"
        assert status == "有效"

    def test_parse_simple_filename(self):
        loader = LawLoader()
        name, hierarchy, status = loader._parse_filename("测试法")
        assert name == "测试法"
        assert hierarchy == ""
        assert status == "有效"


class TestSession:
    """测试会话记忆"""

    def test_add_and_retrieve(self):
        session = Session(max_turns=10)
        session.add_exchange("问题1", "答案1")
        session.add_exchange("问题2", "答案2")
        assert session.turn_count == 2
        history = session.get_history()
        assert history[0]["question"] == "问题1"

    def test_sliding_window(self):
        session = Session(max_turns=2)
        session.add_exchange("问题1", "答案1")
        session.add_exchange("问题2", "答案2")
        session.add_exchange("问题3", "答案3")
        assert session.turn_count == 2
        history = session.get_history()
        assert history[0]["question"] == "问题2"

    def test_clear(self):
        session = Session()
        session.add_exchange("问题1", "答案1")
        session.clear()
        assert session.turn_count == 0
