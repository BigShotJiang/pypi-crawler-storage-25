"""重试逻辑测试"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock, AsyncMock

import pytest

from zcyclaw.llm.retry import (
    NO_RETRY_STATUS,
    RETRY_STATUS,
    MAX_RETRIES,
    BASE_DELAY,
    chat_with_retry,
)


class TestRetryConstants:
    """重试常量测试"""

    def test_no_retry_status(self):
        """测试不重试的状态码"""
        assert 401 in NO_RETRY_STATUS
        assert 402 in NO_RETRY_STATUS
        assert 403 in NO_RETRY_STATUS
        assert 422 in NO_RETRY_STATUS

    def test_retry_status(self):
        """测试可重试的状态码"""
        assert 429 in RETRY_STATUS
        assert 500 in RETRY_STATUS
        assert 502 in RETRY_STATUS
        assert 503 in RETRY_STATUS
        assert 504 in RETRY_STATUS

    def test_max_retries(self):
        """测试最大重试次数"""
        assert MAX_RETRIES == 3

    def test_base_delay(self):
        """测试基础延迟"""
        assert BASE_DELAY == 1.0


class TestChatWithRetry:
    """chat_with_retry 函数测试"""

    @pytest.fixture
    def mock_provider(self):
        """创建 Mock Provider"""
        provider = MagicMock()
        provider.name = "test_provider"
        provider.chat = AsyncMock()
        return provider

    @pytest.mark.asyncio
    async def test_success_first_try(self, mock_provider):
        """测试首次成功"""
        mock_response = MagicMock()
        mock_response.content = "成功"
        mock_provider.chat.return_value = mock_response

        result = await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}])

        assert result.content == "成功"
        assert mock_provider.chat.call_count == 1

    @pytest.mark.asyncio
    async def test_retry_on_429(self, mock_provider):
        """测试 429 状态码重试"""
        from httpx import HTTPStatusError, Response

        # 第一次失败，第二次成功
        mock_response = MagicMock()
        mock_provider.chat.side_effect = [
            HTTPStatusError(
                "Rate limited",
                response=MagicMock(status_code=429),
                request=MagicMock(),
            ),
            mock_response,
        ]

        result = await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}])

        assert result is mock_response
        assert mock_provider.chat.call_count == 2

    @pytest.mark.asyncio
    async def test_no_retry_on_401(self, mock_provider):
        """测试 401 不重试"""
        from httpx import HTTPStatusError

        mock_provider.chat.side_effect = HTTPStatusError(
            "Unauthorized",
            response=MagicMock(status_code=401),
            request=MagicMock(),
        )

        with pytest.raises(HTTPStatusError):
            await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}])

        assert mock_provider.chat.call_count == 1

    @pytest.mark.asyncio
    async def test_no_retry_on_403(self, mock_provider):
        """测试 403 不重试"""
        from httpx import HTTPStatusError

        mock_provider.chat.side_effect = HTTPStatusError(
            "Forbidden",
            response=MagicMock(status_code=403),
            request=MagicMock(),
        )

        with pytest.raises(HTTPStatusError):
            await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}])

        assert mock_provider.chat.call_count == 1

    @pytest.mark.asyncio
    async def test_retry_on_500(self, mock_provider):
        """测试 500 状态码重试"""
        from httpx import HTTPStatusError

        mock_response = MagicMock()
        mock_provider.chat.side_effect = [
            HTTPStatusError(
                "Server Error",
                response=MagicMock(status_code=500),
                request=MagicMock(),
            ),
            mock_response,
        ]

        result = await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}])

        assert result is mock_response
        assert mock_provider.chat.call_count == 2

    @pytest.mark.asyncio
    async def test_max_retries_exceeded(self, mock_provider):
        """测试超过最大重试次数"""
        from httpx import HTTPStatusError

        mock_provider.chat.side_effect = HTTPStatusError(
            "Still Rate Limited",
            response=MagicMock(status_code=429),
            request=MagicMock(),
        )

        with pytest.raises(HTTPStatusError):
            await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}], max_retries=3)

        # 1 次初始 + 3 次重试 = 4 次
        assert mock_provider.chat.call_count == 4

    @pytest.mark.asyncio
    async def test_retry_on_connect_error(self, mock_provider):
        """测试连接错误重试"""
        import httpx

        mock_response = MagicMock()
        mock_provider.chat.side_effect = [
            httpx.ConnectError("Connection failed"),
            mock_response,
        ]

        result = await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}])

        assert result is mock_response
        assert mock_provider.chat.call_count == 2

    @pytest.mark.asyncio
    async def test_retry_on_timeout(self, mock_provider):
        """测试超时重试"""
        import httpx

        mock_response = MagicMock()
        mock_provider.chat.side_effect = [
            httpx.TimeoutException("Timeout"),
            mock_response,
        ]

        result = await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}])

        assert result is mock_response
        assert mock_provider.chat.call_count == 2

    @pytest.mark.asyncio
    async def test_custom_max_retries(self, mock_provider):
        """测试自定义最大重试次数"""
        from httpx import HTTPStatusError

        mock_response = MagicMock()
        # 3 次失败后第 4 次成功
        mock_provider.chat.side_effect = [
            HTTPStatusError("Error", response=MagicMock(status_code=429), request=MagicMock())
            for _ in range(3)
        ] + [mock_response]

        result = await chat_with_retry(mock_provider, [{"role": "user", "content": "hi"}], max_retries=5)

        assert result is mock_response
        assert mock_provider.chat.call_count == 4
