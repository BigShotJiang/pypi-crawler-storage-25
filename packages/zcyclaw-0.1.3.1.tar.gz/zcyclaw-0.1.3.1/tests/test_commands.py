"""CLI Commands 测试 - 覆盖 init/ask/update/stats 命令"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
import typer

from zcyclaw import __version__


class TestVersion:
    """版本测试"""

    def test_version_exists(self):
        """测试版本号存在"""
        assert __version__ is not None
        assert isinstance(__version__, str)

    def test_version_format(self):
        """测试版本号格式"""
        parts = __version__.split(".")
        assert len(parts) >= 2  # 至少 major.minor


class TestAppImport:
    """App 导入测试"""

    def test_app_import(self):
        """测试 App 可以导入"""
        from zcyclaw.cli.commands import app

        assert app is not None

    def test_version_callback_exists(self):
        """测试版本回调函数存在"""
        from zcyclaw.cli.commands import _version_callback

        assert callable(_version_callback)

    def test_single_ask_exists(self):
        """测试单次问答函数存在"""
        from zcyclaw.cli.commands import _single_ask

        assert callable(_single_ask)

    def test_interactive_ask_exists(self):
        """测试交互式问答函数存在"""
        from zcyclaw.cli.commands import _interactive_ask

        assert callable(_interactive_ask)


class TestAppAttributes:
    """App 属性测试"""

    def test_app_name(self):
        """测试 App 名称"""
        from zcyclaw.cli.commands import app

        # Typer app 有 info 属性
        assert app.info.name == "zcyclaw"


class TestAskCommand:
    """ask 命令测试"""

    def test_single_ask_function_exists(self):
        """测试单次问答函数存在"""
        from zcyclaw.cli.commands import _single_ask

        assert callable(_single_ask)

    def test_interactive_ask_function_exists(self):
        """测试交互式问答函数存在"""
        from zcyclaw.cli.commands import _interactive_ask

        assert callable(_interactive_ask)

    @patch("zcyclaw.qa.answer_question_stream")
    @patch("zcyclaw.config.loader.load_config")
    @patch("zcyclaw.cli.stream.StreamRenderer")
    def test_single_ask_with_question(self, mock_renderer_cls, mock_load_config, mock_answer):
        """测试 _single_ask 函数处理问题"""
        from zcyclaw.cli.commands import _single_ask
        from zcyclaw.config.schema import AppConfig

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_config.default_provider = "deepseek"
        mock_load_config.return_value = mock_config

        # Mock answer 返回流式输出
        mock_answer.return_value = iter(["测试", "回答"])

        # Mock StreamRenderer
        mock_renderer = MagicMock()
        mock_renderer_cls.return_value.__enter__ = MagicMock(return_value=mock_renderer)
        mock_renderer_cls.return_value.__exit__ = MagicMock(return_value=False)

        # 执行
        _single_ask("测试问题", "deepseek")

        # 验证
        mock_load_config.assert_called_once()
        mock_answer.assert_called_once()
        mock_renderer.update.assert_called()
        mock_renderer.finish.assert_called_once()

    @patch("zcyclaw.qa.answer_question_stream")
    @patch("zcyclaw.config.loader.load_config")
    @patch("zcyclaw.session.Session")
    @patch("zcyclaw.cli.stream.StreamRenderer")
    def test_interactive_ask_quit(self, mock_renderer_cls, mock_session_cls, mock_load_config, mock_answer):
        """测试 _interactive_ask 函数输入 /quit 退出"""
        from zcyclaw.cli.commands import _interactive_ask
        from zcyclaw.config.schema import AppConfig

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_config.default_provider = "deepseek"
        mock_load_config.return_value = mock_config

        # Mock Session
        mock_session = MagicMock()
        mock_session_cls.return_value = mock_session

        # Mock StreamRenderer
        mock_renderer = MagicMock()
        mock_renderer_cls.return_value.__enter__ = MagicMock(return_value=mock_renderer)
        mock_renderer_cls.return_value.__exit__ = MagicMock(return_value=False)

        # Mock input 返回 /quit
        with patch("builtins.input", return_value="/quit"):
            _interactive_ask("deepseek")

        # 验证 Session 创建但 add_exchange 未被调用（因为立即退出）
        mock_session_cls.assert_called_once()

    @patch("zcyclaw.qa.answer_question_stream")
    @patch("zcyclaw.config.loader.load_config")
    @patch("zcyclaw.session.Session")
    @patch("zcyclaw.cli.stream.StreamRenderer")
    def test_interactive_ask_with_question(self, mock_renderer_cls, mock_session_cls, mock_load_config, mock_answer):
        """测试 _interactive_ask 函数处理一个问题"""
        from zcyclaw.cli.commands import _interactive_ask
        from zcyclaw.config.schema import AppConfig

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_config.default_provider = "deepseek"
        mock_load_config.return_value = mock_config

        # Mock Session
        mock_session = MagicMock()
        mock_session_cls.return_value = mock_session

        # Mock StreamRenderer
        mock_renderer = MagicMock()
        mock_renderer_cls.return_value.__enter__ = MagicMock(return_value=mock_renderer)
        mock_renderer_cls.return_value.__exit__ = MagicMock(return_value=False)

        # Mock answer 返回流式输出然后 quit
        mock_answer.return_value = iter(["回答内容"])

        # Mock input: 第一个问题，第二个 /quit
        with patch("builtins.input", side_effect=["测试问题", "/quit"]):
            _interactive_ask("deepseek")

        # 验证 add_exchange 被调用
        mock_session.add_exchange.assert_called_once()


class TestUpdateCommand:
    """update 命令测试"""

    @patch("zcyclaw.data.updater.check_and_update")
    def test_update_returns_true(self, mock_check):
        """测试 update 命令数据更新"""
        from zcyclaw.cli.commands import update

        mock_check.return_value = True

        update()

        mock_check.assert_called_once()

    @patch("zcyclaw.data.updater.check_and_update")
    def test_update_returns_false(self, mock_check):
        """测试 update 命令数据已是最新"""
        from zcyclaw.cli.commands import update

        mock_check.return_value = False

        update()

        mock_check.assert_called_once()


class TestStatsCommand:
    """stats 命令测试"""

    @patch("zcyclaw.rag.vector_store.VectorStore")
    @patch("zcyclaw.config.loader.load_config")
    def test_stats_with_data(self, mock_load_config, mock_store_cls):
        """测试 stats 命令有数据时显示统计"""
        from zcyclaw.cli.commands import stats
        from zcyclaw.config.schema import AppConfig

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_load_config.return_value = mock_config

        # Mock VectorStore
        mock_store = MagicMock()
        mock_store.get_stats.return_value = {
            "law_count": 5,
            "chunk_count": 100,
            "path": "/fake/path",
        }
        mock_store_cls.return_value = mock_store

        # 执行
        stats()

        mock_store.get_stats.assert_called_once()

    @patch("zcyclaw.rag.vector_store.VectorStore")
    @patch("zcyclaw.config.loader.load_config")
    def test_stats_with_exception(self, mock_load_config, mock_store_cls):
        """测试 stats 命令异常处理"""
        from zcyclaw.cli.commands import stats
        from zcyclaw.config.schema import AppConfig

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_load_config.return_value = mock_config

        # Mock VectorStore 抛出异常
        mock_store = MagicMock()
        mock_store.get_stats.side_effect = Exception("Connection error")
        mock_store_cls.return_value = mock_store

        # 执行不应崩溃
        stats()


class TestInitCommand:
    """init 命令测试"""

    @patch("zcyclaw.config.loader.save_config")
    @patch("zcyclaw.config.loader.load_config")
    @patch("zcyclaw.llm.registry.list_providers")
    @patch("zcyclaw.llm.registry.get_spec")
    @patch("zcyclaw.config.schema.get_provider_config")
    @patch("typer.prompt")
    def test_init_defaults(
        self, mock_prompt, mock_get_provider_config, mock_get_spec, mock_list_providers, mock_load_config, mock_save_config
    ):
        """测试 init 命令使用默认值"""
        from zcyclaw.cli.commands import init
        from zcyclaw.config.schema import AppConfig
        from zcyclaw.llm.registry import ProviderSpec

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_config.default_provider = "deepseek"
        mock_load_config.return_value = mock_config

        # Mock ProviderSpec
        mock_spec = MagicMock(spec=ProviderSpec)
        mock_spec.name = "deepseek"
        mock_spec.display_name = "DeepSeek"
        mock_spec.needs_api_key = True
        mock_spec.default_model = "deepseek-chat"
        mock_spec.default_base_url = "https://api.deepseek.com/v1"
        mock_get_spec.return_value = mock_spec
        mock_list_providers.return_value = [mock_spec]

        # Mock provider config
        mock_provider_config = MagicMock()
        mock_provider_config.api_key = None
        mock_provider_config.model = "deepseek-chat"
        mock_provider_config.base_url = "https://api.deepseek.com/v1"
        mock_get_provider_config.return_value = mock_provider_config

        # Mock prompt 返回默认值（通过按回车）
        def mock_prompt_side_effect(*args, default=None, **kwargs):
            return default

        mock_prompt.side_effect = mock_prompt_side_effect

        # 执行
        init()

        # 验证
        mock_save_config.assert_called_once_with(mock_config)
        assert mock_config.default_provider == "deepseek"

    @patch("zcyclaw.config.loader.save_config")
    @patch("zcyclaw.config.loader.load_config")
    @patch("zcyclaw.llm.registry.list_providers")
    @patch("zcyclaw.llm.registry.get_spec")
    @patch("zcyclaw.config.schema.get_provider_config")
    @patch("typer.prompt")
    def test_init_selects_second_provider(
        self, mock_prompt, mock_get_provider_config, mock_get_spec, mock_list_providers, mock_load_config, mock_save_config
    ):
        """测试 init 命令选择第二个提供商"""
        from zcyclaw.cli.commands import init
        from zcyclaw.config.schema import AppConfig
        from zcyclaw.llm.registry import ProviderSpec

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_config.default_provider = "deepseek"
        mock_load_config.return_value = mock_config

        # Mock 多个 ProviderSpec
        mock_spec1 = MagicMock(spec=ProviderSpec)
        mock_spec1.name = "deepseek"
        mock_spec1.display_name = "DeepSeek"
        mock_spec1.needs_api_key = True
        mock_spec1.default_model = "deepseek-chat"
        mock_spec1.default_base_url = "https://api.deepseek.com/v1"

        mock_spec2 = MagicMock(spec=ProviderSpec)
        mock_spec2.name = "zhipu"
        mock_spec2.display_name = "智谱"
        mock_spec2.needs_api_key = True
        mock_spec2.default_model = "glm-4-flash"
        mock_spec2.default_base_url = "https://open.bigmodel.cn/api/paas/v4"

        mock_list_providers.return_value = [mock_spec1, mock_spec2]
        mock_get_spec.return_value = mock_spec2

        # Mock provider config
        mock_provider_config = MagicMock()
        mock_provider_config.api_key = None
        mock_provider_config.model = "glm-4-flash"
        mock_provider_config.base_url = "https://open.bigmodel.cn/api/paas/v4"
        mock_get_provider_config.return_value = mock_provider_config

        # Mock prompt: 第一个选择编号=2，其他用默认值
        call_count = [0]

        def mock_prompt_side_effect(*args, default=None, **kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                return "2"  # 选择第二个 provider
            return default

        mock_prompt.side_effect = mock_prompt_side_effect

        # 执行
        init()

        # 验证选择了第二个 provider
        mock_save_config.assert_called_once()
        assert mock_config.default_provider == "zhipu"

    @patch("zcyclaw.config.loader.save_config")
    @patch("zcyclaw.config.loader.load_config")
    @patch("zcyclaw.llm.registry.list_providers")
    @patch("zcyclaw.llm.registry.get_spec")
    @patch("zcyclaw.config.schema.get_provider_config")
    @patch("typer.prompt")
    def test_init_ollama_works(
        self, mock_prompt, mock_get_provider_config, mock_get_spec, mock_list_providers, mock_load_config, mock_save_config
    ):
        """测试 init 命令 Ollama 配置正常工作"""
        from zcyclaw.cli.commands import init
        from zcyclaw.config.schema import AppConfig, ProvidersConfig
        from zcyclaw.llm.registry import ProviderSpec

        # Mock 配置
        mock_config = MagicMock(spec=AppConfig)
        mock_config.default_provider = "deepseek"
        mock_config.providers = MagicMock(spec=ProvidersConfig)
        mock_load_config.return_value = mock_config

        # Mock ProviderSpec
        mock_spec = MagicMock(spec=ProviderSpec)
        mock_spec.name = "ollama"
        mock_spec.display_name = "Ollama"
        mock_spec.needs_api_key = False
        mock_spec.default_model = "qwen2.5:7b"
        mock_spec.default_base_url = "http://localhost:11434/v1"
        mock_spec.env_key_hint = "OLLAMA_API_KEY"
        mock_list_providers.return_value = [mock_spec]

        # Mock get_provider_config
        mock_provider_config = MagicMock()
        mock_provider_config.api_key = None
        mock_provider_config.model = "qwen2.5:7b"
        mock_provider_config.base_url = "http://localhost:11434/v1"
        mock_get_provider_config.return_value = mock_provider_config

        # Mock prompt 返回默认值
        def mock_prompt_side_effect(*args, default=None, **kwargs):
            return default

        mock_prompt.side_effect = mock_prompt_side_effect

        # 执行
        init()

        # 验证配置保存
        mock_save_config.assert_called_once()
        assert mock_config.default_provider == "ollama"


class TestVersionCallback:
    """版本回调测试"""

    def test_version_callback_prints(self):
        """测试版本回调输出版本号"""
        from zcyclaw.cli.commands import _version_callback

        with patch("zcyclaw.cli.commands.rprint") as mock_print:
            with pytest.raises(typer.Exit):
                _version_callback(True)

            mock_print.assert_called_once()
            call_args = mock_print.call_args[0][0]
            assert __version__ in call_args

    def test_version_callback_not_called(self):
        """测试版本回调值为 False 时不输出"""
        from zcyclaw.cli.commands import _version_callback

        with patch("zcyclaw.cli.commands.rprint") as mock_print:
            result = _version_callback(False)
            assert result is None
            mock_print.assert_not_called()


class TestAskFunctionIntegration:
    """ask 函数集成测试（直接调用函数）"""

    @patch("zcyclaw.qa.answer_question_stream")
    @patch("zcyclaw.config.loader.load_config")
    @patch("zcyclaw.cli.stream.StreamRenderer")
    def test_single_ask_uses_default_provider(self, mock_renderer_cls, mock_load_config, mock_answer):
        """测试 _single_ask 使用配置中的默认 provider"""
        from zcyclaw.cli.commands import _single_ask
        from zcyclaw.config.schema import AppConfig

        # Mock 配置，默认 provider 是 zhipu
        mock_config = MagicMock(spec=AppConfig)
        mock_config.default_provider = "zhipu"
        mock_load_config.return_value = mock_config

        # Mock answer
        mock_answer.return_value = iter(["回答"])

        # Mock StreamRenderer
        mock_renderer = MagicMock()
        mock_renderer_cls.return_value.__enter__ = MagicMock(return_value=mock_renderer)
        mock_renderer_cls.return_value.__exit__ = MagicMock(return_value=False)

        # 调用时不指定 provider
        _single_ask("问题")

        # 验证使用了配置的默认 provider
        call_args = mock_answer.call_args
        assert call_args is not None
