"""检索器测试"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from zcyclaw.config.schema import AppConfig
from zcyclaw.rag.retriever import LawRetriever, HIERARCHY_BOOST
from zcyclaw.types import HierarchyLevel


class TestLawRetriever:
    """LawRetriever 类测试"""

    @pytest.fixture
    def mock_store(self):
        """创建 mock VectorStore"""
        store = MagicMock()
        return store

    @pytest.fixture
    def config(self):
        """创建测试配置"""
        from zcyclaw.config.schema import AgentDefaultsConfig
        return AppConfig(
            default_provider="deepseek",
            agent=AgentDefaultsConfig(top_k=5),
        )

    def test_init_default_store(self, config):
        """测试默认 store 初始化"""
        with patch("zcyclaw.rag.retriever.VectorStore"):
            retriever = LawRetriever(config)
            assert retriever._config is config

    def test_retrieve_basic(self, mock_store, config):
        """测试基本检索功能"""
        mock_store.query.return_value = [
            {"document": "法条1", "metadata": {"law_name": "测试法", "status": "有效", "hierarchy": "法律"}, "distance": 0.1},
            {"document": "法条2", "metadata": {"law_name": "测试法", "status": "有效", "hierarchy": "行政法规"}, "distance": 0.2},
        ]

        retriever = LawRetriever(config, store=mock_store)
        results = retriever.retrieve("测试查询")

        mock_store.query.assert_called_once()
        assert len(results) == 2

    def test_retrieve_excludes_revoked(self, mock_store, config):
        """测试排除已废止法条"""
        mock_store.query.return_value = [
            {"document": "有效法条", "metadata": {"status": "有效"}, "distance": 0.1},
            {"document": "已废止法条", "metadata": {"status": "已废止"}, "distance": 0.05},
        ]

        retriever = LawRetriever(config, store=mock_store)
        results = retriever.retrieve("测试")

        assert len(results) == 1
        assert results[0]["document"] == "有效法条"

    def test_retrieve_empty_results(self, mock_store, config):
        """测试空检索结果"""
        mock_store.query.return_value = []

        retriever = LawRetriever(config, store=mock_store)
        results = retriever.retrieve("测试")

        assert results == []

    def test_retrieve_hierarchy_boost(self, mock_store, config):
        """测试效力层级加权"""
        mock_store.query.return_value = [
            {"document": "部门规章", "metadata": {"status": "有效", "hierarchy": "部门规章"}, "distance": 0.05},
            {"document": "法律", "metadata": {"status": "有效", "hierarchy": "法律"}, "distance": 0.1},
        ]

        retriever = LawRetriever(config, store=mock_store)
        results = retriever.retrieve("测试")

        # 法律应该排在前面（adjusted_distance 更小）
        assert results[0]["metadata"]["hierarchy"] == "法律"

    def test_retrieve_custom_top_k(self, mock_store, config):
        """测试自定义 top_k"""
        # 返回10条
        mock_store.query.return_value = [
            {"document": f"法条{i}", "metadata": {"status": "有效"}, "distance": 0.1 + i * 0.01}
            for i in range(10)
        ]

        retriever = LawRetriever(config, store=mock_store)
        results = retriever.retrieve("测试", top_k=3)

        assert len(results) == 3

    def test_retrieve_search_k_calculation(self, mock_store, config):
        """测试搜索数量计算 (top_k * 3)"""
        mock_store.query.return_value = []

        retriever = LawRetriever(config, store=mock_store)
        retriever.retrieve("测试", top_k=5)

        # 验证调用参数
        call_args = mock_store.query.call_args
        assert call_args is not None

    def test_hierarchy_boost_values(self):
        """测试层级加权系数"""
        assert HIERARCHY_BOOST[HierarchyLevel.法律] == 0.15
        assert HIERARCHY_BOOST[HierarchyLevel.行政法规] == 0.10
        assert HIERARCHY_BOOST[HierarchyLevel.地方性法规] == 0.05
        assert HIERARCHY_BOOST[HierarchyLevel.部门规章] == 0.0

    def test_unknown_hierarchy_no_boost(self, mock_store, config):
        """测试未知层级无加权"""
        mock_store.query.return_value = [
            {"document": "未知层级", "metadata": {"status": "有效", "hierarchy": "未知层级"}, "distance": 0.1},
        ]

        retriever = LawRetriever(config, store=mock_store)
        results = retriever.retrieve("测试")

        assert results[0]["adjusted_distance"] == 0.1  # 无 boost


class TestHIERARCHYBOOST:
    """HIERARCHY_BOOST 常量测试"""

    def test_all_hierarchy_levels_covered(self):
        """测试常见层级都有加权系数"""
        # 注意：HIERARCHY_BOOST 不包含宪法（最高层级通常不参与日常检索）
        expected_levels = [
            HierarchyLevel.部门规章,
            HierarchyLevel.地方性法规,
            HierarchyLevel.行政法规,
            HierarchyLevel.法律,
        ]
        for level in expected_levels:
            assert level in HIERARCHY_BOOST

    def test_boost_values_non_negative(self):
        """测试加权值非负"""
        for boost in HIERARCHY_BOOST.values():
            assert boost >= 0
