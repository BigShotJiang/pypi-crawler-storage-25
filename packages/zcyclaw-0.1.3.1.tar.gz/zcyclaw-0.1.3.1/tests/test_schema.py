"""配置模型测试"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from zcyclaw.config.schema import (
    DeepSeekConfig,
    ZhipuConfig,
    TongyiConfig,
    MoonshotConfig,
    OpenAIConfig,
    OllamaConfig,
    AnthropicConfig,
    MiniMaxConfig,
    ProvidersConfig,
    EmbeddingConfig,
    AgentDefaultsConfig,
    AppConfig,
    get_provider_config,
)


class TestProviderConfigs:
    """各提供商配置模型测试"""

    def test_deepseek_config_defaults(self):
        """测试 DeepSeekConfig 默认值"""
        config = DeepSeekConfig()
        assert config.api_key is None
        assert config.base_url == "https://api.deepseek.com/v1"
        assert config.model == "deepseek-chat"
        assert config.temperature == 0.3
        assert config.max_tokens == 2048

    def test_deepseek_config_custom(self):
        """测试 DeepSeekConfig 自定义值"""
        config = DeepSeekConfig(
            api_key="test-key",
            base_url="https://custom.api.com",
            model="custom-model",
            temperature=0.5,
            max_tokens=4096,
        )
        assert config.api_key == "test-key"
        assert config.base_url == "https://custom.api.com"
        assert config.model == "custom-model"
        assert config.temperature == 0.5
        assert config.max_tokens == 4096

    def test_zhipu_config(self):
        """测试智谱配置"""
        config = ZhipuConfig()
        assert config.base_url == "https://open.bigmodel.cn/api/paas/v4"
        assert config.model == "glm-4-flash"

    def test_tongyi_config(self):
        """测试通义配置"""
        config = TongyiConfig()
        assert config.base_url == "https://dashscope.aliyuncs.com/compatible-mode/v1"
        assert config.model == "qwen-turbo"

    def test_moonshot_config(self):
        """测试 Moonshot 配置"""
        config = MoonshotConfig()
        assert config.base_url == "https://api.moonshot.cn/v1"
        assert config.model == "moonshot-v1-8k"

    def test_openai_config(self):
        """测试 OpenAI 配置"""
        config = OpenAIConfig()
        assert config.base_url == "https://api.openai.com/v1"
        assert config.model == "gpt-4o-mini"

    def test_ollama_config(self):
        """测试 Ollama 配置（不需要 API Key）"""
        config = OllamaConfig()
        assert config.base_url == "http://localhost:11434/v1"
        assert config.model == "qwen2.5:7b"

    def test_anthropic_config(self):
        """测试 Anthropic 配置"""
        config = AnthropicConfig()
        assert config.model == "claude-sonnet-4-20250514"
        assert config.max_tokens == 2048

    def test_minimax_config(self):
        """测试 MiniMax 配置"""
        config = MiniMaxConfig()
        assert config.base_url == "https://api.minimax.chat/v1"
        assert config.model == "MiniMax-Text-01"


class TestProvidersConfig:
    """ProvidersConfig 聚合配置测试"""

    def test_providers_config_default(self):
        """测试默认聚合配置"""
        config = ProvidersConfig()
        assert config.deepseek is not None
        assert config.zhipu is not None
        assert isinstance(config.deepseek, DeepSeekConfig)

    def test_providers_config_nested(self):
        """测试嵌套配置"""
        config = ProvidersConfig(
            deepseek=DeepSeekConfig(api_key="my-key"),
        )
        assert config.deepseek.api_key == "my-key"


class TestEmbeddingConfig:
    """Embedding 配置测试"""

    def test_embedding_config_defaults(self):
        """测试默认 Embedding 配置"""
        config = EmbeddingConfig()
        assert config.provider == "auto"
        assert config.model == ""
        assert config.api_key is None
        assert config.base_url is None

    def test_embedding_config_custom(self):
        """测试自定义 Embedding 配置"""
        config = EmbeddingConfig(
            provider="zhipu",
            model="embedding-model",
            api_key="emb-key",
        )
        assert config.provider == "zhipu"
        assert config.model == "embedding-model"
        assert config.api_key == "emb-key"


class TestAgentDefaultsConfig:
    """Agent 默认行为配置测试"""

    def test_agent_defaults(self):
        """测试默认 Agent 配置"""
        config = AgentDefaultsConfig()
        assert config.top_k == 5
        assert config.temperature == 0.3
        assert config.max_tokens == 2048
        assert config.show_sources is True

    def test_agent_defaults_custom(self):
        """测试自定义 Agent 配置"""
        config = AgentDefaultsConfig(top_k=10, show_sources=False)
        assert config.top_k == 10
        assert config.show_sources is False


class TestAppConfig:
    """AppConfig 总配置测试"""

    def test_app_config_defaults(self):
        """测试默认应用配置"""
        config = AppConfig()
        assert config.default_provider == "deepseek"
        assert config.providers is not None
        assert config.embedding is not None
        assert config.agent is not None

    def test_app_config_custom(self):
        """测试自定义应用配置"""
        config = AppConfig(
            default_provider="zhipu",
            embedding=EmbeddingConfig(provider="zhipu"),
            agent=AgentDefaultsConfig(top_k=10),
        )
        assert config.default_provider == "zhipu"
        assert config.embedding.provider == "zhipu"
        assert config.agent.top_k == 10


class TestGetProviderConfig:
    """get_provider_config 辅助函数测试"""

    def test_get_existing_provider(self):
        """测试获取已存在的提供商配置"""
        config = AppConfig()
        provider_cfg = get_provider_config(config, "deepseek")
        assert provider_cfg is not None
        assert isinstance(provider_cfg, DeepSeekConfig)

    def test_get_nonexistent_provider(self):
        """测试获取不存在的提供商配置"""
        config = AppConfig()
        # 使用不存在的提供商名称（通过动态属性访问）
        provider_cfg = getattr(config.providers, "nonexistent", None)
        assert provider_cfg is None
