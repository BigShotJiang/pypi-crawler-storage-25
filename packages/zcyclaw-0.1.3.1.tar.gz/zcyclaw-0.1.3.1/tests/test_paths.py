"""路径管理测试"""

from __future__ import annotations

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from zcyclaw.config.paths import (
    get_config_dir,
    get_config_file,
    get_data_dir,
    get_vector_store_dir,
    get_seed_data_dir,
    get_cache_dir,
)


class TestPaths:
    """路径函数测试"""

    def test_get_config_dir(self):
        """测试获取配置目录"""
        with patch("pathlib.Path.home", return_value=Path("/tmp/fake_home")):
            with patch("pathlib.Path.mkdir"):
                path = get_config_dir()
                assert path == Path("/tmp/fake_home/.zcyclaw")

    def test_get_config_file(self):
        """测试获取配置文件路径"""
        with patch("zcyclaw.config.paths.get_config_dir", return_value=Path("/tmp/.zcyclaw")):
            path = get_config_file()
            assert path == Path("/tmp/.zcyclaw/config.json")

    def test_get_data_dir(self):
        """测试获取数据目录"""
        with patch("zcyclaw.config.paths.get_config_dir", return_value=Path("/tmp/.zcyclaw")):
            path = get_data_dir()
            assert path == Path("/tmp/.zcyclaw/data")

    def test_get_vector_store_dir(self):
        """测试获取向量库目录"""
        with patch("zcyclaw.config.paths.get_data_dir", return_value=Path("/tmp/.zcyclaw/data")):
            path = get_vector_store_dir()
            assert path == Path("/tmp/.zcyclaw/data/chroma")

    def test_get_seed_data_dir(self):
        """测试获取种子数据目录"""
        with patch("zcyclaw.config.paths.get_data_dir", return_value=Path("/tmp/.zcyclaw/data")):
            path = get_seed_data_dir()
            assert path == Path("/tmp/.zcyclaw/data/seed")

    def test_get_cache_dir(self):
        """测试获取缓存目录"""
        with patch("zcyclaw.config.paths.get_config_dir", return_value=Path("/tmp/.zcyclaw")):
            path = get_cache_dir()
            assert path == Path("/tmp/.zcyclaw/cache")

    def test_directories_created_if_not_exist(self):
        """测试目录不存在时创建"""
        with patch("pathlib.Path.mkdir") as mock_mkdir:
            with patch("pathlib.Path.home", return_value=Path("/tmp/fake_home")):
                get_config_dir()
                mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
