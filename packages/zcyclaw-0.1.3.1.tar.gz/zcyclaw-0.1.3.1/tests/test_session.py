"""Session 会话管理测试"""

from __future__ import annotations

import pytest

from zcyclaw.session import Session


class TestSession:
    """Session 类测试"""

    def test_init_default(self):
        """测试默认初始化"""
        session = Session()
        assert session._max_turns == 10
        assert session.turn_count == 0
        assert session.get_history() == []

    def test_init_custom_max_turns(self):
        """测试自定义最大轮次"""
        session = Session(max_turns=5)
        assert session._max_turns == 5
        assert session.turn_count == 0

    def test_add_exchange(self):
        """测试添加对话"""
        session = Session(max_turns=3)
        session.add_exchange("问题1", "回答1")
        assert session.turn_count == 1
        history = session.get_history()
        assert len(history) == 1
        assert history[0]["question"] == "问题1"
        assert history[0]["answer"] == "回答1"

    def test_add_multiple_exchanges(self):
        """测试添加多轮对话"""
        session = Session(max_turns=3)
        session.add_exchange("问题1", "回答1")
        session.add_exchange("问题2", "回答2")
        session.add_exchange("问题3", "回答3")
        assert session.turn_count == 3
        assert len(session.get_history()) == 3

    def test_sliding_window(self):
        """测试滑动窗口"""
        session = Session(max_turns=2)
        session.add_exchange("问题1", "回答1")
        session.add_exchange("问题2", "回答2")
        assert session.turn_count == 2

        session.add_exchange("问题3", "回答3")
        assert session.turn_count == 2
        history = session.get_history()
        assert history[0]["question"] == "问题2"
        assert history[1]["question"] == "问题3"

    def test_clear(self):
        """测试清空历史"""
        session = Session()
        session.add_exchange("问题1", "回答1")
        assert session.turn_count == 1

        session.clear()
        assert session.turn_count == 0
        assert session.get_history() == []

    def test_get_history_returns_copy(self):
        """测试 get_history 返回副本而非引用"""
        session = Session()
        session.add_exchange("问题1", "回答1")

        history1 = session.get_history()
        history2 = session.get_history()

        history1[0]["question"] = "修改后的提问"

        assert session.get_history()[0]["question"] == "问题1"
