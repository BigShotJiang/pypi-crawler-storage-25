"""Provider 工厂函数测试"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from zcyclaw.llm.factory import create_provider
from zcyclaw.llm.base import LLMProvider


class TestCreateProvider:
    """create_provider 函数测试"""

    def test_create_unknown_provider(self):
        """测试创建未知提供商"""
        with patch("zcyclaw.llm.factory.get_spec", return_value=None):
            with patch("zcyclaw.llm.factory.list_providers", return_value=[]):
                with pytest.raises(ValueError, match="未知提供商"):
                    create_provider("unknown", MagicMock())

    def test_create_openai_compat_provider(self):
        """测试创建 OpenAI 兼容提供商"""
        mock_spec = MagicMock()
        mock_spec.name = "deepseek"
        mock_spec.backend = "openai_compat"

        mock_config = MagicMock()
        mock_config.api_key = "test-key"
        mock_config.base_url = "https://api.deepseek.com"
        mock_config.model = "deepseek-chat"
        mock_config.temperature = 0.3
        mock_config.max_tokens = 2048

        with patch("zcyclaw.llm.factory.get_spec", return_value=mock_spec):
            with patch("zcyclaw.llm.factory.get_provider_config", return_value=mock_config):
                with patch("zcyclaw.llm.factory.OpenAICompatProvider") as mock_provider_class:
                    mock_instance = MagicMock()
                    mock_provider_class.return_value = mock_instance

                    provider = create_provider("deepseek", MagicMock())

                    assert provider is mock_instance
                    mock_provider_class.assert_called_once()

    def test_create_anthropic_provider(self):
        """测试创建 Anthropic 提供商"""
        mock_spec = MagicMock()
        mock_spec.name = "anthropic"
        mock_spec.backend = "anthropic"

        mock_config = MagicMock()
        mock_config.api_key = "test-key"
        mock_config.model = "claude-sonnet"
        mock_config.temperature = 0.3
        mock_config.max_tokens = 2048

        with patch("zcyclaw.llm.factory.get_spec", return_value=mock_spec):
            with patch("zcyclaw.llm.factory.get_provider_config", return_value=mock_config):
                with patch("zcyclaw.llm.factory.AnthropicProvider") as mock_provider_class:
                    mock_instance = MagicMock()
                    mock_provider_class.return_value = mock_instance

                    provider = create_provider("anthropic", MagicMock())

                    assert provider is mock_instance
                    mock_provider_class.assert_called_once()

    def test_create_provider_with_missing_config(self):
        """测试配置缺失时使用默认值"""
        mock_spec = MagicMock()
        mock_spec.name = "deepseek"
        mock_spec.backend = "openai_compat"

        with patch("zcyclaw.llm.factory.get_spec", return_value=mock_spec):
            with patch("zcyclaw.llm.factory.get_provider_config", return_value=None):
                with patch("zcyclaw.llm.factory.OpenAICompatProvider") as mock_provider_class:
                    mock_instance = MagicMock()
                    mock_provider_class.return_value = mock_instance

                    provider = create_provider("deepseek", MagicMock())

                    call_kwargs = mock_provider_class.call_args.kwargs
                    assert call_kwargs["api_key"] is None
                    assert call_kwargs["temperature"] == 0.3
                    assert call_kwargs["max_tokens"] == 2048

    def test_create_provider_unknown_backend(self):
        """测试未知后端类型"""
        mock_spec = MagicMock()
        mock_spec.name = "test"
        mock_spec.backend = "unknown_backend"

        with patch("zcyclaw.llm.factory.get_spec", return_value=mock_spec):
            with pytest.raises(ValueError, match="未知后端类型"):
                create_provider("test", MagicMock())
