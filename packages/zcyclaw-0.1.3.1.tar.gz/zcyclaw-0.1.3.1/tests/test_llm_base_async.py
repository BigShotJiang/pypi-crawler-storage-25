"""LLM Base 异步方法测试"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

from zcyclaw.llm.base import LLMProvider, LLMResponse


class TestLLMProviderChatSyncWithRetry:
    """chat_sync_with_retry 方法测试"""

    def test_chat_sync_with_retry_success(self):
        """测试带重试的同步对话成功"""
        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="success")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk"

        provider = TestProvider()

        with patch("asyncio.get_running_loop", side_effect=RuntimeError("No loop")):
            result = provider.chat_sync_with_retry([{"role": "user", "content": "hi"}])
            assert result.content == "success"

    def test_chat_sync_with_retry_in_running_loop(self):
        """测试在运行中的事件循环调用"""
        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="success")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk"

        provider = TestProvider()

        # 创建一个正在运行的事件循环
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            # 不抛出异常即可
            result = provider.chat_sync([{"role": "user", "content": "hi"}])
            assert result.content == "success"
        finally:
            loop.close()


class TestLLMProviderChatStreamSync:
    """chat_stream_sync 方法测试"""

    def test_chat_stream_sync_no_loop(self):
        """测试无事件循环时的流式对话"""
        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="response")

            async def chat_stream(self, messages, **kwargs):
                for chunk in ["chunk1", "chunk2", "chunk3"]:
                    yield chunk

        provider = TestProvider()

        with patch("asyncio.get_running_loop", side_effect=RuntimeError("No loop")):
            result = list(provider.chat_stream_sync([{"role": "user", "content": "hi"}]))
            assert "chunk1" in result
            assert "chunk2" in result
            assert "chunk3" in result

    def test_chat_stream_sync_collects_content(self):
        """测试流式对话收集内容"""
        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="response")

            async def chat_stream(self, messages, **kwargs):
                yield "a"
                yield "b"
                yield "c"

        provider = TestProvider()

        with patch("asyncio.get_running_loop", side_effect=RuntimeError("No loop")):
            result = list(provider.chat_stream_sync([{"role": "user", "content": "hi"}]))
            assert len(result) == 3

    def test_chat_stream_sync_in_running_loop(self):
        """测试在运行中的事件循环调用流式方法"""
        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="response")

            async def chat_stream(self, messages, **kwargs):
                for chunk in ["a", "b", "c"]:
                    yield chunk

        provider = TestProvider()

        # 创建一个正在运行的事件循环
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            # 不抛出异常即可
            result = list(provider.chat_stream_sync([{"role": "user", "content": "hi"}]))
            assert len(result) == 3
        finally:
            loop.close()


class TestLLMProviderAbstractMethods:
    """抽象方法测试"""

    def test_chat_is_abstract(self):
        """测试 chat 是抽象方法"""
        assert hasattr(LLMProvider.chat, "__isabstractmethod__")

    def test_chat_stream_is_abstract(self):
        """测试 chat_stream 是抽象方法"""
        assert hasattr(LLMProvider.chat_stream, "__isabstractmethod__")


class TestLLMProviderAsyncContext:
    """异步上下文测试"""

    @pytest.mark.asyncio
    async def test_provider_with_async_context(self):
        """测试在异步上下文中使用 Provider"""
        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="async content")

            async def chat_stream(self, messages, **kwargs):
                yield "async chunk"

        provider = TestProvider()

        # 在异步上下文中运行
        result = await provider.chat([{"role": "user", "content": "hi"}])
        assert result.content == "async content"

        # 测试流式
        chunks = []
        async for chunk in provider.chat_stream([{"role": "user", "content": "hi"}]):
            chunks.append(chunk)
        assert "async chunk" in chunks
