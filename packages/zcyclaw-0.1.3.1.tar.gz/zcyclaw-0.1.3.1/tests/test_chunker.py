"""法规分块器测试"""

from __future__ import annotations

import pytest

from zcyclaw.rag.chunker import LawChunk, LawChunker


class TestLawChunk:
    """LawChunk 数据类测试"""

    def test_create_default_chunk(self):
        """测试创建默认分块"""
        chunk = LawChunk(content="测试内容")
        assert chunk.content == "测试内容"
        assert chunk.law_name == ""
        assert chunk.article_number == ""
        assert chunk.chapter == ""
        assert chunk.hierarchy == ""
        assert chunk.status == "有效"
        assert chunk.metadata == {}

    def test_create_full_chunk(self):
        """测试创建完整分块"""
        chunk = LawChunk(
            content="这是法条内容",
            law_name="政府采购法",
            article_number="第一条",
            chapter="第一章 总则",
            hierarchy="法律",
            status="有效",
            metadata={"source": "test"},
        )
        assert chunk.content == "这是法条内容"
        assert chunk.law_name == "政府采购法"
        assert chunk.article_number == "第一条"
        assert chunk.chapter == "第一章 总则"
        assert chunk.hierarchy == "法律"
        assert chunk.status == "有效"
        assert chunk.metadata == {"source": "test"}


class TestLawChunker:
    """LawChunker 分块器测试"""

    def test_init(self):
        """测试初始化"""
        chunker = LawChunker()
        assert chunker.ARTICLE_PATTERN is not None
        assert chunker.CHAPTER_PATTERN is not None

    def test_chunk_simple_articles(self):
        """测试简单法条分块"""
        chunker = LawChunker()
        text = """**第一条** 第一款内容。
第二款内容。

**第二条** 内容二。
"""
        chunks = chunker.chunk(text, law_name="测试法", hierarchy="法律")

        assert len(chunks) == 2
        assert chunks[0].article_number == "第一条"
        assert chunks[0].law_name == "测试法"
        assert chunks[0].hierarchy == "法律"
        assert "第一条" in chunks[0].content
        assert "第一款内容" in chunks[0].content

    def test_chunk_with_chapters(self):
        """测试带章节的法条分块"""
        chunker = LawChunker()
        text = """# 第一编 总则

## 第一章 基本原则

**第一条** 这是第一条规定的内容，用于规范相关行为。

**第二条** 这是第二条规定的内容，对细节进行补充说明。

## 第二章 适用范围

**第三条** 这是第三条规定的内容。
"""
        chunks = chunker.chunk(text, law_name="测试法", hierarchy="行政法规")

        assert len(chunks) == 3
        # 第一条应该属于第一章
        first_chunk = next(c for c in chunks if c.article_number == "第一条")
        assert "第一章" in first_chunk.chapter

    def test_chunk_no_articles(self):
        """测试无"条"结构的文本"""
        chunker = LawChunker()
        text = "这是一段没有法条结构的文本。"
        chunks = chunker.chunk(text, law_name="测试法")

        assert len(chunks) == 1
        assert chunks[0].content == text.strip()
        assert chunks[0].article_number == ""

    def test_chunk_empty_text(self):
        """测试空文本"""
        chunker = LawChunker()
        chunks = chunker.chunk("", law_name="测试法")
        assert len(chunks) == 1
        assert chunks[0].content == ""

    def test_chunk_chinese_numbers(self):
        """测试中文数字法条编号"""
        chunker = LawChunker()
        text = """**第一条** 这是第一条规定的内容，较长以避免合并。
**第二条** 这是第二条规定的内容，同样较长以避免合并。
**第十条** 这是第十条规定的内容。
**第一百条** 这是第一百条规定的内容。
"""
        chunks = chunker.chunk(text)
        assert len(chunks) == 4

    def test_chunk_markdown_bold_format(self):
        """测试 Markdown 加粗格式"""
        chunker = LawChunker()
        text = """**第一条** 这是第一条的加粗格式内容。

第二条 这是第二条的非加粗格式内容。
"""
        chunks = chunker.chunk(text)
        assert len(chunks) == 2

    def test_merge_short_chunks(self):
        """测试短法条合并"""
        chunker = LawChunker()
        text = """**第一条** 短。
**第二条** 这里是相对较长的内容来避免被合并。
**第三条** 也短。
**第四条** 正常长度的内容。
"""
        chunks = chunker.chunk(text)

        # 检查是否有被合并的短法条
        # 第一条太短应该被合并到第二条
        # 第三条太短应该被合并到第四条
        assert len(chunks) < 4

    def test_chunk_status_preserved(self):
        """测试时效状态保留"""
        chunker = LawChunker()
        text = """**第一条** 有效法条。
**第二条** 已废止法条。
"""
        chunks = chunker.chunk(text, status="有效")
        assert all(c.status == "有效" for c in chunks)

    def test_find_articles(self):
        """测试 _find_articles 方法"""
        chunker = LawChunker()
        text = "**第一条** 内容1。\n\n**第二条** 内容2。"
        results = chunker._find_articles(text)

        assert len(results) == 2
        assert results[0][1] == "一"  # 条号部分
        assert results[1][1] == "二"

    def test_find_chapters(self):
        """测试 _find_chapters 方法"""
        chunker = LawChunker()
        text = """# 第一编 总则
## 第一章 基本原则
### 第一节
"""
        results = chunker._find_chapters(text)

        assert len(results) == 3
        assert "第一编" in results[0][1]
        assert "第一章" in results[1][1]
        assert "第一节" in results[2][1]

    def test_find_chapter_for_position(self):
        """测试 _find_chapter_for_position 方法"""
        chunker = LawChunker()
        chapters = [(0, "第一章"), (100, "第二章"), (200, "第三章")]

        assert chunker._find_chapter_for_position(chapters, 50) == "第一章"
        assert chunker._find_chapter_for_position(chapters, 150) == "第二章"
        assert chunker._find_chapter_for_position(chapters, 300) == "第三章"
        assert chunker._find_chapter_for_position([], 50) == ""

    def test_content_structure(self):
        """测试分块内容格式"""
        chunker = LawChunker()
        text = """**第一条** 这是第一条的完整内容。
包含多行内容。
"""
        chunks = chunker.chunk(text)
        assert len(chunks) == 1
        # 分块后内容应该以"第X条"开头
        assert "第一条" in chunks[0].content
        assert "这是第一条的完整内容" in chunks[0].content
