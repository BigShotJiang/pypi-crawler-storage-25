"""共享 pytest fixtures"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from zcyclaw.config.schema import AppConfig, DeepSeekConfig


@pytest.fixture
def mock_config() -> AppConfig:
    """创建一个测试用配置"""
    config = AppConfig(
        default_provider="deepseek",
        providers=AppConfig(
            default_provider="deepseek",
            providers__deepseek__api_key="test-api-key",
        ).providers,
    )
    return config


@pytest.fixture
def sample_law_text() -> str:
    """示例法规文本"""
    return """# 政府采购法

## 第一章 总则

**第一条** 为了规范政府采购行为，提高政府采购资金的使用效益，维护国家利益和社会公共利益，保护政府采购当事人的合法权益，促进廉政建设，制定本法。

**第二条** 在中华人民共和国境内进行的政府采购适用本法。

**第三条** 政府采购应当遵循公开透明原则、公平竞争原则、公正原则和诚实信用原则。

## 第二章 政府采购当事人

**第四条** 政府采购当事人是指在政府采购活动中享有权利和承担义务的各类主体，包括采购人、供应商、采购代理机构等。

**第五条** 采购人是指依法进行政府采购的国家机关、事业单位、团体组织。

**第六条** 供应商是指向采购人提供货物、工程或者服务的法人、其他组织或者自然人。
"""


@pytest.fixture
def mock_chroma_collection():
    """Mock ChromaDB Collection"""
    collection = MagicMock()
    collection.count.return_value = 0
    collection.get.return_value = {"metadatas": []}
    collection.query.return_value = {
        "documents": [["测试法条内容"]],
        "metadatas": [[{"law_name": "测试法", "article_number": "第一条", "chapter": "第一章", "hierarchy": "法律", "status": "有效"}]],
        "distances": [[0.1]],
    }
    return collection


@pytest.fixture
def mock_chroma_client(mock_chroma_collection):
    """Mock ChromaDB PersistentClient"""
    client = MagicMock()
    client.get_or_create_collection.return_value = mock_chroma_collection
    return client


@pytest.fixture
def mock_provider():
    """Mock LLM Provider"""
    provider = MagicMock()
    response = MagicMock()
    response.content = "这是测试回答"
    provider.chat_sync_with_retry.return_value = response
    provider.chat_stream_sync.return_value = iter(["这是", "测试", "回答"])
    return provider
