"""LLM Provider 基类测试"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from unittest.mock import MagicMock, AsyncMock, patch

import pytest

from zcyclaw.llm.base import LLMProvider, LLMResponse


class TestLLMResponse:
    """LLMResponse 数据类测试"""

    def test_create_response(self):
        """测试创建响应"""
        response = LLMResponse(content="测试内容")
        assert response.content == "测试内容"
        assert response.model == ""
        assert response.provider == ""
        assert response.usage == {}
        assert response.finish_reason == ""

    def test_create_full_response(self):
        """测试创建完整响应"""
        response = LLMResponse(
            content="完整内容",
            model="gpt-4",
            provider="openai",
            usage={"tokens": 100},
            finish_reason="stop",
        )
        assert response.content == "完整内容"
        assert response.model == "gpt-4"
        assert response.provider == "openai"
        assert response.usage == {"tokens": 100}
        assert response.finish_reason == "stop"


class TestLLMProvider:
    """LLMProvider 基类测试"""

    def test_is_abc(self):
        """测试是抽象基类"""
        assert issubclass(LLMProvider, __import__("abc").ABC)

    def test_abstract_methods(self):
        """测试抽象方法"""
        # chat 和 chat_stream 应该是抽象方法
        provider = LLMProvider.__dict__["chat"]
        assert getattr(provider, "__isabstractmethod__", False) is True

        stream_method = LLMProvider.__dict__["chat_stream"]
        assert getattr(stream_method, "__isabstractmethod__", False) is True

    def test_sync_methods_not_abstract(self):
        """测试同步方法不是抽象的"""
        # chat_sync 不应该是抽象方法
        assert not getattr(LLMProvider.chat_sync, "__isabstractmethod__", False)
        assert not getattr(LLMProvider.chat_sync_with_retry, "__isabstractmethod__", False)
        assert not getattr(LLMProvider.chat_stream_sync, "__isabstractmethod__", False)


class TestLLMProviderSync:
    """LLMProvider 同步方法测试"""

    def test_chat_stream_sync_basic(self):
        """测试 chat_stream_sync 基本功能"""
        from zcyclaw.llm.base import LLMProvider

        # 创建一个实现抽象方法的子类
        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="response")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk1"
                yield "chunk2"

        provider = TestProvider()

        # 收集同步流式输出
        chunks = list(provider.chat_stream_sync([{"role": "user", "content": "test"}]))

        assert chunks == ["chunk1", "chunk2"]

    def test_chat_sync_basic(self):
        """测试 chat_sync 基本功能"""
        from zcyclaw.llm.base import LLMProvider

        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="sync response")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk"

        provider = TestProvider()
        result = provider.chat_sync([{"role": "user", "content": "test"}])

        assert result.content == "sync response"

    def test_chat_sync_with_retry_basic(self):
        """测试 chat_sync_with_retry 基本功能"""
        from zcyclaw.llm.base import LLMProvider

        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="retry response")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk"

        provider = TestProvider()
        result = provider.chat_sync_with_retry([{"role": "user", "content": "test"}], max_retries=3)

        assert result.content == "retry response"

    def test_chat_sync_no_running_loop(self):
        """测试 chat_sync 在没有运行中 loop 时正常执行"""
        from zcyclaw.llm.base import LLMProvider

        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="no loop response")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk"

        provider = TestProvider()

        # 在没有运行中 loop 的情况下调用
        result = provider.chat_sync([{"role": "user", "content": "test"}])

        assert result.content == "no loop response"

    def test_chat_stream_sync_no_running_loop(self):
        """测试 chat_stream_sync 在没有运行中 loop 时正常执行"""
        from zcyclaw.llm.base import LLMProvider

        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="response")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk1"
                yield "chunk2"
                yield "chunk3"

        provider = TestProvider()

        # 在没有运行中 loop 的情况下调用
        chunks = list(provider.chat_stream_sync([{"role": "user", "content": "test"}]))

        assert chunks == ["chunk1", "chunk2", "chunk3"]

    def test_chat_sync_with_running_loop(self):
        """测试 chat_sync 在有运行中 loop 时使用 ThreadPoolExecutor"""
        from zcyclaw.llm.base import LLMProvider

        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="loop response")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk"

        provider = TestProvider()

        # 创建一个 running loop 并在其中调用 chat_sync
        async def run_with_loop():
            result = provider.chat_sync([{"role": "user", "content": "test"}])
            return result

        # 运行
        result = asyncio.run(run_with_loop())
        assert result.content == "loop response"

    def test_chat_stream_sync_with_running_loop(self):
        """测试 chat_stream_sync 在有运行中 loop 时使用 queue"""
        from zcyclaw.llm.base import LLMProvider

        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="response")

            async def chat_stream(self, messages, **kwargs):
                yield "a"
                yield "b"
                yield "c"

        provider = TestProvider()

        async def run_with_loop():
            chunks = list(provider.chat_stream_sync([{"role": "user", "content": "test"}]))
            return chunks

        result = asyncio.run(run_with_loop())
        assert result == ["a", "b", "c"]

    def test_chat_sync_with_retry_with_running_loop(self):
        """测试 chat_sync_with_retry 在有运行中 loop 时使用 ThreadPoolExecutor"""
        from zcyclaw.llm.base import LLMProvider

        class TestProvider(LLMProvider):
            name = "test"

            async def chat(self, messages, **kwargs):
                return LLMResponse(content="retry loop response")

            async def chat_stream(self, messages, **kwargs):
                yield "chunk"

        provider = TestProvider()

        async def run_with_loop():
            result = provider.chat_sync_with_retry([{"role": "user", "content": "test"}], max_retries=3)
            return result

        result = asyncio.run(run_with_loop())
        assert result.content == "retry loop response"
