"""CLI Stream 模块测试"""

from __future__ import annotations

from unittest.mock import MagicMock, patch
import time

import pytest
from rich.live import Live
from rich.markdown import Markdown


class TestStreamRenderer:
    """StreamRenderer 类测试"""

    def test_init(self):
        """测试初始化"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        assert renderer._content == ""
        assert renderer._live is None
        assert renderer._throttle == 0.15

    def test_init_custom_throttle(self):
        """测试自定义节流时间"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        assert renderer._throttle == 0.15

    def test_update_accumulates_content(self):
        """测试 update 方法累积内容"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        renderer.update("第一")
        assert renderer._content == "第一"
        renderer.update("第二")
        assert renderer._content == "第一第二"

    def test_finish_sets_content(self):
        """测试 finish 方法设置内容"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        renderer._content = "旧内容"
        renderer.finish(content="新内容")
        assert renderer._content == "新内容"

    def test_context_manager_enter(self):
        """测试上下文管理器 enter"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        with patch.object(renderer, "_live"):
            with renderer:
                pass  # 只是测试不抛出异常

    def test_context_manager_exit(self):
        """测试上下文管理器 exit"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        # 测试 exit 不抛出异常
        renderer.__exit__(None, None, None)

    def test_update_with_time_throttle(self):
        """测试节流逻辑"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        # 快速连续调用应该被节流
        renderer._last_update = time.monotonic()
        renderer.update("chunk1")
        # 由于时间很接近，可能不会更新 _live
        assert renderer._content == "chunk1"

    def test_finish_without_content(self):
        """测试 finish 不传内容时保留现有内容"""
        from zcyclaw.cli.stream import StreamRenderer

        renderer = StreamRenderer()
        renderer._content = "已有内容"
        renderer.finish()
        assert renderer._content == "已有内容"
