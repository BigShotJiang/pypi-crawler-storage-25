"""OpenAI 兼容后端测试"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, AsyncMock, patch

import pytest

from zcyclaw.llm.openai_compat import OpenAICompatProvider
from zcyclaw.llm.registry import ProviderSpec


class TestOpenAICompatProvider:
    """OpenAICompatProvider 类测试"""

    @pytest.fixture
    def mock_spec(self):
        """创建 mock ProviderSpec"""
        return ProviderSpec(
            name="deepseek",
            display_name="DeepSeek",
            backend="openai_compat",
            default_model="deepseek-chat",
            default_base_url="https://api.deepseek.com/v1",
        )

    def test_init(self, mock_spec):
        """测试初始化"""
        provider = OpenAICompatProvider(spec=mock_spec)
        assert provider.name == "deepseek"
        assert provider._spec is mock_spec
        assert provider._base_url == "https://api.deepseek.com/v1"
        assert provider._model == "deepseek-chat"
        assert provider._temperature == 0.3
        assert provider._max_tokens == 2048

    def test_init_custom(self, mock_spec):
        """测试自定义参数初始化"""
        provider = OpenAICompatProvider(
            spec=mock_spec,
            api_key="test-key",
            base_url="https://custom.api.com",
            model="custom-model",
            temperature=0.5,
            max_tokens=4096,
        )
        assert provider._api_key == "test-key"
        assert provider._base_url == "https://custom.api.com"
        assert provider._model == "custom-model"
        assert provider._temperature == 0.5
        assert provider._max_tokens == 4096

    def test_base_url_strip(self, mock_spec):
        """测试 base_url 去除末尾斜杠"""
        provider = OpenAICompatProvider(
            spec=mock_spec,
            base_url="https://api.test.com/",
        )
        assert provider._base_url == "https://api.test.com"

    def test_headers_without_key(self, mock_spec):
        """测试无 API Key 的请求头"""
        provider = OpenAICompatProvider(spec=mock_spec, api_key=None)
        headers = provider._headers()
        assert headers["Content-Type"] == "application/json"
        assert "Authorization" not in headers

    def test_headers_with_key(self, mock_spec):
        """测试有 API Key 的请求头"""
        provider = OpenAICompatProvider(spec=mock_spec, api_key="test-key")
        headers = provider._headers()
        assert headers["Authorization"] == "Bearer test-key"

    def test_build_payload(self, mock_spec):
        """测试构建请求体"""
        provider = OpenAICompatProvider(spec=mock_spec, temperature=0.5, max_tokens=1000)
        messages = [{"role": "user", "content": "hello"}]
        payload = provider._build_payload(messages)

        assert payload["model"] == "deepseek-chat"
        assert payload["messages"] == messages
        assert payload["temperature"] == 0.5
        assert payload["max_tokens"] == 1000
        assert payload["stream"] is False

    def test_build_payload_with_override(self, mock_spec):
        """测试构建请求体时覆盖参数"""
        provider = OpenAICompatProvider(spec=mock_spec, temperature=0.5, max_tokens=1000)
        messages = [{"role": "user", "content": "hello"}]
        payload = provider._build_payload(messages, temperature=0.9, model="override-model")

        assert payload["temperature"] == 0.9
        assert payload["model"] == "override-model"
        assert payload["max_tokens"] == 1000  # 保持默认值


class TestOpenAICompatProviderAsync:
    """OpenAICompatProvider 异步方法测试"""

    @pytest.fixture
    def mock_spec(self):
        """创建 mock ProviderSpec"""
        return ProviderSpec(
            name="deepseek",
            display_name="DeepSeek",
            backend="openai_compat",
            default_model="deepseek-chat",
            default_base_url="https://api.deepseek.com/v1",
        )

    @pytest.mark.asyncio
    async def test_chat_success(self, mock_spec):
        """测试异步对话成功"""
        provider = OpenAICompatProvider(spec=mock_spec, api_key="test-key")

        mock_response_data = {
            "choices": [{
                "message": {"content": "测试回答"},
                "finish_reason": "stop",
            }],
            "model": "deepseek-chat",
            "usage": {"total_tokens": 100},
        }

        mock_response = MagicMock()
        mock_response.json.return_value = mock_response_data
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.__aenter__.return_value.post = AsyncMock(return_value=mock_response)

        with patch("httpx.AsyncClient", return_value=mock_client):
            result = await provider.chat([{"role": "user", "content": "你好"}])

            assert result.content == "测试回答"
            assert result.provider == "deepseek"
            assert result.finish_reason == "stop"

    @pytest.mark.asyncio
    async def test_chat_uses_custom_model(self, mock_spec):
        """测试使用自定义模型"""
        provider = OpenAICompatProvider(
            spec=mock_spec,
            api_key="test-key",
            model="custom-model",
        )

        mock_response_data = {
            "choices": [{
                "message": {"content": "回答"},
                "finish_reason": "stop",
            }],
        }

        mock_response = MagicMock()
        mock_response.json.return_value = mock_response_data
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.__aenter__.return_value.post = AsyncMock(return_value=mock_response)

        with patch("httpx.AsyncClient", return_value=mock_client):
            await provider.chat([{"role": "user", "content": "hi"}])

            # 验证请求体中的 model
            call_args = mock_client.__aenter__.return_value.post.call_args
            payload = call_args.kwargs["json"]
            assert payload["model"] == "custom-model"


class TestOpenAICompatProviderStream:
    """OpenAICompatProvider 流式方法测试"""

    @pytest.fixture
    def mock_spec(self):
        """创建 mock ProviderSpec"""
        return ProviderSpec(
            name="deepseek",
            display_name="DeepSeek",
            backend="openai_compat",
            default_model="deepseek-chat",
            default_base_url="https://api.deepseek.com/v1",
        )

    @pytest.mark.asyncio
    async def test_chat_stream_success(self, mock_spec):
        """测试异步流式对话成功"""
        provider = OpenAICompatProvider(spec=mock_spec, api_key="test-key")

        # 模拟流式响应行
        async def mock_aiter_lines():
            yield 'data: {"choices":[{"delta":{"content":"chunk1"}}]}'
            yield 'data: {"choices":[{"delta":{"content":"chunk2"}}]}'
            yield "data: [DONE]"

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.aiter_lines = mock_aiter_lines

        mock_client = AsyncMock()
        mock_client.__aenter__.return_value.__aexit__.return_value = None
        mock_client.__aenter__.return_value.stream = MagicMock()
        mock_client.__aenter__.return_value.stream.return_value.__aenter__.return_value = mock_response

        with patch("httpx.AsyncClient", return_value=mock_client):
            chunks = []
            async for chunk in provider.chat_stream([{"role": "user", "content": "hi"}]):
                chunks.append(chunk)

            assert "chunk1" in chunks
            assert "chunk2" in chunks

    @pytest.mark.asyncio
    async def test_chat_stream_handles_done(self, mock_spec):
        """测试流式对话处理 [DONE]"""
        provider = OpenAICompatProvider(spec=mock_spec, api_key="test-key")

        async def mock_aiter_lines():
            yield 'data: {"choices":[{"delta":{"content":"content"}}]}'
            yield "data: [DONE]"
            yield "data: extra"  # [DONE] 之后的不应处理

        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.aiter_lines = mock_aiter_lines

        mock_client = AsyncMock()
        mock_client.__aenter__.return_value.__aexit__.return_value = None
        mock_client.__aenter__.return_value.stream = MagicMock()
        mock_client.__aenter__.return_value.stream.return_value.__aenter__.return_value = mock_response

        with patch("httpx.AsyncClient", return_value=mock_client):
            chunks = []
            async for chunk in provider.chat_stream([{"role": "user", "content": "hi"}]):
                chunks.append(chunk)

            # 只应有一个 chunk
            assert len(chunks) == 1
