"""向量存储测试"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from zcyclaw.config.schema import AppConfig
from zcyclaw.rag.chunker import LawChunk
from zcyclaw.rag.vector_store import VectorStore


class TestVectorStore:
    """VectorStore 类测试"""

    @pytest.fixture
    def mock_client(self):
        """Mock ChromaDB client"""
        client = MagicMock()
        collection = MagicMock()
        collection.count.return_value = 0
        client.get_or_create_collection.return_value = collection
        return client

    @pytest.fixture
    def config(self):
        """创建测试配置"""
        return AppConfig()

    def test_init_with_persist_dir(self, mock_client, config):
        """测试指定持久化目录"""
        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            store = VectorStore(config, persist_dir=Path("/tmp/test"))
            assert store._persist_dir == Path("/tmp/test")
            assert store._client is mock_client

    def test_collection_name(self):
        """测试 collection 名称"""
        assert VectorStore.COLLECTION_NAME == "gov_laws"

    def test_add_chunks_empty(self, mock_client, config):
        """测试添加空分块列表"""
        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            store = VectorStore(config, persist_dir=Path("/tmp/test"))
            result = store.add_chunks([])
            assert result == 0

    def test_add_chunks_single(self, mock_client, config):
        """测试添加单个分块"""
        collection = mock_client.get_or_create_collection()
        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                chunks = [
                    LawChunk(
                        content="测试内容",
                        law_name="测试法",
                        article_number="第一条",
                        chapter="第一章",
                        hierarchy="法律",
                        status="有效",
                    )
                ]
                result = store.add_chunks(chunks)
                assert result == 1
                collection.upsert.assert_called_once()

    def test_add_chunks_id_generation(self, mock_client, config):
        """测试 ID 生成逻辑"""
        collection = mock_client.get_or_create_collection()
        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                chunks = [
                    LawChunk(
                        content="内容",
                        law_name="测试法 (2024)",
                        article_number="第X条",
                    )
                ]
                store.add_chunks(chunks)

                call_args = collection.upsert.call_args
                ids = call_args.kwargs["ids"]
                # 特殊字符应该被替换
                assert "(" not in ids[0]
                assert ")" not in ids[0]

    def test_add_chunks_batch(self, mock_client, config):
        """测试批量添加（>5000条）"""
        collection = mock_client.get_or_create_collection()
        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                chunks = [
                    LawChunk(content=f"内容{i}", law_name="测试法", article_number=f"第{i}条")
                    for i in range(100)
                ]
                result = store.add_chunks(chunks)
                assert result == 100

    def test_query_empty_collection(self, mock_client, config):
        """测试查询空 collection"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 0

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                results = store.query("测试查询")
                assert results == []

    def test_query_with_results(self, mock_client, config):
        """测试查询返回结果"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 2
        # ChromaDB query 返回格式：documents/metadatas/distances 都是嵌套列表
        # 外层列表长度 = 查询数量，内层列表长度 = 结果数量
        collection.query.return_value = {
            "documents": [["内容1", "内容2"]],
            "metadatas": [[
                {"law_name": "法1", "article_number": "第一条", "chapter": "第一章", "hierarchy": "法律", "status": "有效"},
                {"law_name": "法2", "article_number": "第二条", "chapter": "第一章", "hierarchy": "行政法规", "status": "有效"},
            ]],
            "distances": [[0.1, 0.2]],
        }

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                results = store.query("测试", top_k=2)

                assert len(results) == 2
                assert results[0]["document"] == "内容1"
                assert results[0]["metadata"]["law_name"] == "法1"
                assert results[0]["distance"] == 0.1

    def test_query_with_where_filter(self, mock_client, config):
        """测试带元数据过滤的查询"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 1

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                store.query("测试", where={"hierarchy": "法律"})

                call_args = collection.query.call_args
                assert call_args.kwargs["where"] == {"hierarchy": "法律"}

    def test_count(self, mock_client, config):
        """测试计数"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 42

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                assert store.count() == 42

    def test_count_exception(self, mock_client, config):
        """测试计数异常处理"""
        collection = mock_client.get_or_create_collection()
        collection.count.side_effect = Exception("DB Error")

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                assert store.count() == 0

    def test_get_stats(self, mock_client, config):
        """测试统计信息"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 5
        collection.get.return_value = {
            "metadatas": [
                {"law_name": "法1"},
                {"law_name": "法1"},
                {"law_name": "法2"},
                {"law_name": "法3"},
                {"law_name": "法3"},
            ]
        }

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                stats = store.get_stats()

                assert stats["chunk_count"] == 5
                assert stats["law_count"] == 3  # 不重复的法规数

    def test_clear(self, mock_client, config):
        """测试清空向量库"""
        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                store.clear()

                mock_client.delete_collection.assert_called_once_with(VectorStore.COLLECTION_NAME)
                assert store._collection is None

    def test_lazy_collection_loading(self, mock_client, config):
        """测试懒加载 collection"""
        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                # 初始化时 collection 应该是 None
                assert store._collection is None

                # 访问时才加载
                collection = store._get_collection()
                assert collection is not None
                mock_client.get_or_create_collection.assert_called_once()

    def test_get_stats_empty_collection(self, mock_client, config):
        """测试空 collection 的统计信息"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 0

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                stats = store.get_stats()

                assert stats["chunk_count"] == 0
                assert stats["law_count"] == 0

    def test_get_stats_metadata_exception(self, mock_client, config):
        """测试元数据获取异常处理"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 5
        collection.get.side_effect = Exception("Metadata error")

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                stats = store.get_stats()

                # 异常时 law_count 应该为 0
                assert stats["chunk_count"] == 5
                assert stats["law_count"] == 0

    def test_get_stats_null_metadata(self, mock_client, config):
        """测试空元数据的处理"""
        collection = mock_client.get_or_create_collection()
        collection.count.return_value = 3
        collection.get.return_value = {
            "metadatas": [
                {"law_name": "法1"},
                None,  # 空元数据
                {"law_name": "法1"},
            ]
        }

        with patch("zcyclaw.rag.vector_store.chromadb.PersistentClient", return_value=mock_client):
            with patch("zcyclaw.rag.vector_store.create_embedding_function"):
                store = VectorStore(config, persist_dir=Path("/tmp/test"))
                stats = store.get_stats()

                # 应该正确处理 None 元数据
                assert stats["chunk_count"] == 3
                assert stats["law_count"] == 1  # 只有法1
