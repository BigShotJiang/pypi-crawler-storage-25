"""问答核心模块测试"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from zcyclaw.qa import (
    SYSTEM_PROMPT,
    _retrieve_context,
    _build_messages,
    answer_question,
    answer_question_stream,
)


class TestSystemPrompt:
    """System Prompt 测试"""

    def test_system_prompt_contains_key_instrucations(self):
        """测试系统提示包含关键指令"""
        assert "法条标注" in SYSTEM_PROMPT
        assert "效力层级" in SYSTEM_PROMPT
        assert "时效性" in SYSTEM_PROMPT
        assert "政府采购" in SYSTEM_PROMPT

    def test_system_prompt_has_context_placeholder(self):
        """测试系统提示有上下文占位符"""
        assert "{context}" in SYSTEM_PROMPT


class TestBuildMessages:
    """_build_messages 函数测试"""

    def test_build_messages_basic(self):
        """测试基本消息构建"""
        messages = _build_messages(
            question="测试问题",
            context="检索到的上下文",
            session=None,
        )

        assert len(messages) == 2  # system + user
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"
        assert "检索到的上下文" in messages[0]["content"]
        assert "测试问题" in messages[1]["content"]

    def test_build_messages_with_session(self):
        """测试带会话历史的消息构建"""
        from zcyclaw.session import Session

        session = Session()
        session.add_exchange("历史问题1", "历史回答1")
        session.add_exchange("历史问题2", "历史回答2")

        messages = _build_messages(
            question="当前问题",
            context="上下文",
            session=session,
        )

        # system + 2*history + user = 6
        assert len(messages) == 6
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"
        assert messages[1]["content"] == "历史问题1"
        assert messages[2]["role"] == "assistant"
        assert messages[2]["content"] == "历史回答1"

    def test_context_substituted_in_system_prompt(self):
        """测试上下文被正确替换"""
        messages = _build_messages(
            question="问题",
            context="这里是上下文内容",
            session=None,
        )

        assert "这里是上下文内容" in messages[0]["content"]
        assert "{context}" not in messages[0]["content"]


class TestRetrieveContext:
    """_retrieve_context 函数测试"""

    @pytest.fixture
    def mock_store(self):
        """Mock VectorStore"""
        store = MagicMock()
        return store

    def test_retrieve_empty_vector_store(self, mock_store):
        """测试空向量库的检索"""
        mock_store.count.return_value = 0

        with patch("zcyclaw.qa.VectorStore", return_value=mock_store):
            result = _retrieve_context("测试问题", MagicMock())
            assert result == ""

    def test_retrieve_no_results(self, mock_store):
        """测试无检索结果"""
        mock_store.count.return_value = 10

        with patch("zcyclaw.qa.VectorStore", return_value=mock_store):
            with patch("zcyclaw.qa.LawRetriever") as mock_retriever_class:
                mock_retriever = MagicMock()
                mock_retriever.retrieve.return_value = []
                mock_retriever_class.return_value = mock_retriever

                result = _retrieve_context("测试问题", MagicMock())
                assert result == ""

    def test_retrieve_with_results(self, mock_store):
        """测试有检索结果"""
        mock_store.count.return_value = 5

        with patch("zcyclaw.qa.VectorStore", return_value=mock_store):
            with patch("zcyclaw.qa.LawRetriever") as mock_retriever_class:
                mock_retriever = MagicMock()
                mock_retriever.retrieve.return_value = [
                    {
                        "document": "法条内容",
                        "metadata": {
                            "law_name": "政府采购法",
                            "article_number": "第一条",
                            "chapter": "第一章",
                            "hierarchy": "法律",
                            "status": "有效",
                        },
                    }
                ]
                mock_retriever_class.return_value = mock_retriever

                result = _retrieve_context("政府采购问题", MagicMock())

                assert "政府采购法" in result
                assert "第一条" in result
                assert "法律" in result

    def test_retrieve_exception_handling(self, mock_store):
        """测试检索异常处理"""
        mock_store.count.side_effect = Exception("DB Error")

        with patch("zcyclaw.qa.VectorStore", return_value=mock_store):
            result = _retrieve_context("测试问题", MagicMock())
            assert result == ""


class TestAnswerQuestion:
    """answer_question 函数测试"""

    @pytest.fixture
    def mock_provider(self):
        """Mock LLM Provider"""
        provider = MagicMock()
        response = MagicMock()
        response.content = "这是测试回答"
        provider.chat_sync_with_retry.return_value = response
        return provider

    def test_answer_empty_context(self):
        """测试无上下文时的回答"""
        with patch("zcyclaw.qa.ensure_demo_data"):
            with patch("zcyclaw.qa._retrieve_context", return_value=""):
                result = answer_question(
                    question="测试问题",
                    config=MagicMock(),
                    provider_name="deepseek",
                )

                assert "未能检索到" in result

    def test_answer_success(self, mock_provider):
        """测试成功回答"""
        with patch("zcyclaw.qa.ensure_demo_data"):
            with patch("zcyclaw.qa._retrieve_context", return_value="相关法条"):
                with patch("zcyclaw.qa.create_provider", return_value=mock_provider):
                    result = answer_question(
                        question="测试问题",
                        config=MagicMock(),
                        provider_name="deepseek",
                    )

                    assert result == "这是测试回答"
                    mock_provider.chat_sync_with_retry.assert_called_once()

    def test_answer_llm_exception(self, mock_provider):
        """测试 LLM 调用异常"""
        mock_provider.chat_sync_with_retry.side_effect = Exception("API Error")

        with patch("zcyclaw.qa.ensure_demo_data"):
            with patch("zcyclaw.qa._retrieve_context", return_value="相关法条"):
                with patch("zcyclaw.qa.create_provider", return_value=mock_provider):
                    result = answer_question(
                        question="测试问题",
                        config=MagicMock(),
                        provider_name="deepseek",
                    )

                    assert "API Error" in result
                    assert "调用 deepseek 失败" in result


class TestAnswerQuestionStream:
    """answer_question_stream 函数测试"""

    @pytest.fixture
    def mock_provider(self):
        """Mock LLM Provider"""
        provider = MagicMock()
        provider.chat_stream_sync.return_value = iter(["这", "是", "测试", "回答"])
        return provider

    def test_stream_empty_context(self):
        """测试空上下文时的流式回答"""
        with patch("zcyclaw.qa.ensure_demo_data"):
            with patch("zcyclaw.qa._retrieve_context", return_value=""):
                result = list(answer_question_stream(
                    question="测试问题",
                    config=MagicMock(),
                    provider_name="deepseek",
                ))

                assert any("未能检索到" in r for r in result)

    def test_stream_success(self, mock_provider):
        """测试成功流式回答"""
        with patch("zcyclaw.qa.ensure_demo_data"):
            with patch("zcyclaw.qa._retrieve_context", return_value="相关法条"):
                with patch("zcyclaw.qa.create_provider", return_value=mock_provider):
                    result = list(answer_question_stream(
                        question="测试问题",
                        config=MagicMock(),
                        provider_name="deepseek",
                    ))

                    assert result == ["这", "是", "测试", "回答"]
                    mock_provider.chat_stream_sync.assert_called_once()

    def test_stream_llm_exception(self, mock_provider):
        """测试流式 LLM 异常"""
        mock_provider.chat_stream_sync.side_effect = Exception("Stream Error")

        with patch("zcyclaw.qa.ensure_demo_data"):
            with patch("zcyclaw.qa._retrieve_context", return_value="相关法条"):
                with patch("zcyclaw.qa.create_provider", return_value=mock_provider):
                    result = list(answer_question_stream(
                        question="测试问题",
                        config=MagicMock(),
                        provider_name="deepseek",
                    ))

                    result_text = "".join(result)
                    assert "Stream Error" in result_text
