"""LLM Provider 注册表测试"""

from __future__ import annotations

import pytest

from zcyclaw.llm.registry import (
    ProviderSpec,
    get_spec,
    list_providers,
    register,
    PROVIDERS,
)


class TestProviderSpec:
    """ProviderSpec 数据类测试"""

    def test_create_spec(self):
        """测试创建 ProviderSpec"""
        spec = ProviderSpec(
            name="test_provider",
            display_name="测试提供商",
            backend="openai_compat",
            default_model="test-model",
            default_base_url="https://api.test.com",
            needs_api_key=True,
            env_key_hint="TEST_API_KEY",
        )
        assert spec.name == "test_provider"
        assert spec.display_name == "测试提供商"
        assert spec.backend == "openai_compat"
        assert spec.default_model == "test-model"
        assert spec.default_base_url == "https://api.test.com"
        assert spec.needs_api_key is True
        assert spec.env_key_hint == "TEST_API_KEY"

    def test_spec_is_frozen(self):
        """测试 dataclass 是 frozen 的"""
        spec = ProviderSpec(
            name="test",
            display_name="测试",
            backend="openai_compat",
            default_model="model",
            default_base_url="https://api.test.com",
        )
        with pytest.raises(Exception):  # dataclasses.FrozenInstanceError
            spec.name = "modified"  # type: ignore


class TestRegistry:
    """注册表函数测试"""

    def test_register_and_get_spec(self):
        """测试注册和获取"""
        spec = ProviderSpec(
            name="test_reg",
            display_name="注册测试",
            backend="openai_compat",
            default_model="model",
            default_base_url="https://api.test.com",
            needs_api_key=False,
        )
        register(spec)
        retrieved = get_spec("test_reg")
        assert retrieved is not None
        assert retrieved.name == "test_reg"
        assert retrieved.display_name == "注册测试"

    def test_get_spec_not_found(self):
        """测试获取不存在的 provider"""
        result = get_spec("nonexistent_provider")
        assert result is None

    def test_list_providers(self):
        """测试列出所有提供商"""
        providers = list_providers()
        assert isinstance(providers, list)
        assert len(providers) > 0
        for p in providers:
            assert isinstance(p, ProviderSpec)
            assert p.name in PROVIDERS

    def test_builtin_providers_exist(self):
        """测试内置提供商都存在"""
        builtin_names = ["deepseek", "zhipu", "tongyi", "moonshot", "openai", "minimax", "ollama", "anthropic"]
        for name in builtin_names:
            spec = get_spec(name)
            assert spec is not None, f"Provider {name} should exist"
            assert spec.name == name

    def test_builtin_providers_have_required_fields(self):
        """测试内置提供商的必需字段"""
        for spec in list_providers():
            assert spec.name
            assert spec.display_name
            assert spec.backend in ("openai_compat", "anthropic")
            assert spec.default_model
            assert spec.default_base_url is not None
