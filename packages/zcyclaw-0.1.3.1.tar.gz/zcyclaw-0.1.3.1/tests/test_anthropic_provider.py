"""Anthropic Provider 测试"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, AsyncMock, patch

import pytest

from zcyclaw.llm.anthropic_provider import AnthropicProvider
from zcyclaw.llm.registry import ProviderSpec


class TestAnthropicProvider:
    """AnthropicProvider 类测试"""

    @pytest.fixture
    def mock_spec(self):
        """创建 mock ProviderSpec"""
        return ProviderSpec(
            name="anthropic",
            display_name="Anthropic",
            backend="anthropic",
            default_model="claude-sonnet-4-20250514",
            default_base_url="",
        )

    def test_init(self, mock_spec):
        """测试初始化"""
        provider = AnthropicProvider(spec=mock_spec)
        assert provider.name == "anthropic"
        assert provider._model == "claude-sonnet-4-20250514"
        assert provider._temperature == 0.3
        assert provider._max_tokens == 2048
        assert provider._base_url == "https://api.anthropic.com"

    def test_init_custom(self, mock_spec):
        """测试自定义参数初始化"""
        provider = AnthropicProvider(
            spec=mock_spec,
            api_key="test-key",
            model="claude-opus",
            temperature=0.5,
            max_tokens=4096,
        )
        assert provider._api_key == "test-key"
        assert provider._model == "claude-opus"
        assert provider._temperature == 0.5
        assert provider._max_tokens == 4096

    def test_headers(self, mock_spec):
        """测试请求头"""
        provider = AnthropicProvider(spec=mock_spec, api_key="test-key")
        headers = provider._headers()
        assert headers["Content-Type"] == "application/json"
        assert headers["x-api-key"] == "test-key"
        assert headers["anthropic-version"] == "2023-06-01"

    def test_split_messages(self, mock_spec):
        """测试消息拆分"""
        provider = AnthropicProvider(spec=mock_spec)
        messages = [
            {"role": "system", "content": "你是助手"},
            {"role": "user", "content": "你好"},
            {"role": "assistant", "content": "你好！"},
        ]
        system, chat = provider._split_messages(messages)

        assert system == "你是助手"
        assert len(chat) == 2
        assert chat[0]["content"] == "你好"
        assert chat[1]["content"] == "你好！"

    def test_split_messages_no_system(self, mock_spec):
        """测试无 system 消息"""
        provider = AnthropicProvider(spec=mock_spec)
        messages = [
            {"role": "user", "content": "你好"},
        ]
        system, chat = provider._split_messages(messages)

        assert system is None
        assert len(chat) == 1

    def test_build_payload(self, mock_spec):
        """测试构建请求体"""
        provider = AnthropicProvider(spec=mock_spec, temperature=0.5, max_tokens=1000)
        payload = provider._build_payload("system", [{"role": "user", "content": "hi"}])

        assert payload["model"] == "claude-sonnet-4-20250514"
        assert payload["system"] == "system"
        assert payload["temperature"] == 0.5
        assert payload["max_tokens"] == 1000
        assert payload["stream"] is False

    def test_build_payload_with_override(self, mock_spec):
        """测试构建请求体时覆盖参数"""
        provider = AnthropicProvider(spec=mock_spec, temperature=0.5, max_tokens=1000)
        payload = provider._build_payload(
            None,
            [{"role": "user", "content": "hi"}],
            temperature=0.9,
            model="override-model",
        )

        assert payload["temperature"] == 0.9
        assert payload["model"] == "override-model"
        assert payload["max_tokens"] == 1000

    def test_build_payload_no_system(self, mock_spec):
        """测试无 system 的请求体"""
        provider = AnthropicProvider(spec=mock_spec)
        payload = provider._build_payload(None, [{"role": "user", "content": "hi"}])

        assert "system" not in payload


class TestAnthropicProviderAsync:
    """AnthropicProvider 异步方法测试"""

    @pytest.fixture
    def mock_spec(self):
        """创建 mock ProviderSpec"""
        return ProviderSpec(
            name="anthropic",
            display_name="Anthropic",
            backend="anthropic",
            default_model="claude-sonnet-4-20250514",
            default_base_url="",
        )

    @pytest.mark.asyncio
    async def test_chat_success(self, mock_spec):
        """测试异步对话成功"""
        provider = AnthropicProvider(spec=mock_spec, api_key="test-key")

        mock_response_data = {
            "content": [{"type": "text", "text": "测试回答"}],
            "model": "claude-sonnet",
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 10, "output_tokens": 20},
        }

        mock_response = MagicMock()
        mock_response.json.return_value = mock_response_data
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.__aenter__.return_value.post = AsyncMock(return_value=mock_response)

        with patch("httpx.AsyncClient", return_value=mock_client):
            result = await provider.chat([
                {"role": "user", "content": "你好"}
            ])

            assert result.content == "测试回答"
            assert result.provider == "anthropic"
            assert result.finish_reason == "end_turn"
            assert result.usage["input_tokens"] == 10

    @pytest.mark.asyncio
    async def test_chat_with_system(self, mock_spec):
        """测试带 system 消息的对话"""
        provider = AnthropicProvider(spec=mock_spec, api_key="test-key")

        mock_response_data = {
            "content": [{"type": "text", "text": "回答"}],
            "model": "claude-sonnet",
            "stop_reason": "end_turn",
        }

        mock_response = MagicMock()
        mock_response.json.return_value = mock_response_data
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.__aenter__.return_value.post = AsyncMock(return_value=mock_response)

        with patch("httpx.AsyncClient", return_value=mock_client):
            await provider.chat([
                {"role": "system", "content": "你是助手"},
                {"role": "user", "content": "你好"},
            ])

            # 验证 system 消息被正确处理
            call_args = mock_client.__aenter__.return_value.post.call_args
            payload = call_args.kwargs["json"]
            assert payload["system"] == "你是助手"
            assert len(payload["messages"]) == 1  # 只有 user 消息


class TestAnthropicProviderStream:
    """AnthropicProvider 流式方法测试"""

    @pytest.fixture
    def mock_spec(self):
        """创建 mock ProviderSpec"""
        return ProviderSpec(
            name="anthropic",
            display_name="Anthropic",
            backend="anthropic",
            default_model="claude-sonnet-4-20250514",
            default_base_url="",
        )

    @pytest.mark.asyncio
    async def test_chat_stream_method_exists(self, mock_spec):
        """测试流式方法存在"""
        provider = AnthropicProvider(spec=mock_spec, api_key="test-key")
        assert hasattr(provider, "chat_stream")
        assert callable(provider.chat_stream)

    @pytest.mark.asyncio
    async def test_chat_stream_yields_chunks(self, mock_spec):
        """测试流式方法返回多个 chunk"""
        provider = AnthropicProvider(spec=mock_spec, api_key="test-key")

        # 验证 chat_stream 是异步生成器
        result = provider.chat_stream([{"role": "user", "content": "hi"}])

        # 检查返回的是异步生成器
        import inspect
        assert inspect.isasyncgen(result)

    def test_build_payload_stream_true(self, mock_spec):
        """测试流式请求体包含 stream=True"""
        provider = AnthropicProvider(spec=mock_spec, api_key="test-key")
        payload = provider._build_payload(
            "system",
            [{"role": "user", "content": "hi"}],
            stream=True
        )

        assert payload["stream"] is True
        assert payload["system"] == "system"

    def test_build_payload_stream_false(self, mock_spec):
        """测试非流式请求体 stream=False"""
        provider = AnthropicProvider(spec=mock_spec, api_key="test-key")
        payload = provider._build_payload(
            None,
            [{"role": "user", "content": "hi"}],
            stream=False
        )

        assert payload["stream"] is False
        assert "system" not in payload

    def test_split_messages_with_assistant(self, mock_spec):
        """测试消息拆分包含 assistant 角色"""
        provider = AnthropicProvider(spec=mock_spec)
        messages = [
            {"role": "system", "content": "系统"},
            {"role": "user", "content": "用户"},
            {"role": "assistant", "content": "助手"},
        ]
        system, chat = provider._split_messages(messages)

        assert system == "系统"
        assert len(chat) == 2
        assert chat[0]["role"] == "user"
        assert chat[1]["role"] == "assistant"
