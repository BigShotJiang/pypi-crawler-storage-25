"""数据更新模块测试"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from zcyclaw.config.schema import AppConfig


class TestUpdaterFunctions:
    """updater 模块函数测试"""

    @pytest.fixture
    def temp_data_dir(self):
        """创建临时数据目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    def test_get_local_version_no_file(self, temp_data_dir):
        """测试无版本文件时返回 0"""
        with patch("zcyclaw.data.updater.get_data_dir", return_value=temp_data_dir):
            from zcyclaw.data.updater import _get_local_version
            result = _get_local_version()
            assert result == "0"

    def test_get_local_version_with_file(self, temp_data_dir):
        """测试有版本文件时返回版本号"""
        version_file = temp_data_dir / "version.json"
        version_file.write_text(json.dumps({"version": "1.0.0"}), encoding="utf-8")

        with patch("zcyclaw.data.updater.get_data_dir", return_value=temp_data_dir):
            from zcyclaw.data.updater import _get_local_version
            result = _get_local_version()
            assert result == "1.0.0"

    def test_get_local_version_invalid_json(self, temp_data_dir):
        """测试无效 JSON 时返回 0"""
        version_file = temp_data_dir / "version.json"
        version_file.write_text("invalid json", encoding="utf-8")

        with patch("zcyclaw.data.updater.get_data_dir", return_value=temp_data_dir):
            from zcyclaw.data.updater import _get_local_version
            result = _get_local_version()
            assert result == "0"

    def test_set_local_version(self, temp_data_dir):
        """测试设置版本号"""
        with patch("zcyclaw.data.updater.get_data_dir", return_value=temp_data_dir):
            from zcyclaw.data.updater import _set_local_version, _get_local_version

            _set_local_version("2.0.0")
            assert _get_local_version() == "2.0.0"

    def test_get_seed_data_path_fallback_to_project_root(self):
        """测试获取种子数据路径回退到项目根目录"""
        from zcyclaw.data.updater import _get_seed_data_path
        # 验证函数存在且返回 Path
        path = _get_seed_data_path()
        assert isinstance(path, Path)

    def test_deploy_seed_data_no_source(self, temp_data_dir):
        """测试部署时源目录不存在"""
        with patch("zcyclaw.data.updater._get_seed_data_path", return_value=Path("/nonexistent")):
            with patch("zcyclaw.data.updater.get_seed_data_dir", return_value=temp_data_dir):
                from zcyclaw.data.updater import _deploy_seed_data
                result = _deploy_seed_data()
                assert result == 0

    def test_deploy_seed_data_with_files(self, temp_data_dir):
        """测试部署法规文件"""
        # 创建临时源目录和文件
        source_dir = temp_data_dir / "source"
        source_dir.mkdir()
        (source_dir / "test.md").write_text("# Test", encoding="utf-8")

        target_dir = temp_data_dir / "target"

        with patch("zcyclaw.data.updater._get_seed_data_path", return_value=source_dir):
            with patch("zcyclaw.data.updater.get_seed_data_dir", return_value=target_dir):
                from zcyclaw.data.updater import _deploy_seed_data
                result = _deploy_seed_data()
                assert result == 1
                assert (target_dir / "test.md").exists()

    def test_build_vector_store_empty_dir(self, temp_data_dir):
        """测试空目录构建向量库"""
        empty_dir = temp_data_dir / "empty"

        with patch("zcyclaw.data.updater.get_seed_data_dir", return_value=empty_dir):
            from zcyclaw.data.updater import _build_vector_store
            result = _build_vector_store(AppConfig())
            assert result == 0

    def test_build_vector_store_with_files(self, temp_data_dir):
        """测试有法规文件时构建向量库"""
        seed_dir = temp_data_dir / "seed"
        seed_dir.mkdir()
        (seed_dir / "test.md").write_text("**第一条** 测试内容。", encoding="utf-8")

        mock_store = MagicMock()
        mock_store.add_chunks.return_value = 1

        with patch("zcyclaw.data.updater.get_seed_data_dir", return_value=seed_dir):
            with patch("zcyclaw.data.updater.LawLoader") as mock_loader_class:
                mock_loader = MagicMock()
                mock_loader.load_directory.return_value = [MagicMock()]
                mock_loader_class.return_value = mock_loader

                with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
                    from zcyclaw.data.updater import _build_vector_store
                    result = _build_vector_store(AppConfig())

                    assert result == 1
                    mock_store.clear.assert_called_once()


class TestEnsureDemoData:
    """ensure_demo_data 函数测试"""

    def test_already_has_data(self):
        """测试数据已存在时直接返回"""
        mock_store = MagicMock()
        mock_store.count.return_value = 100

        with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
            from zcyclaw.data.updater import ensure_demo_data
            result = ensure_demo_data(AppConfig())
            assert result is True
            mock_store.count.assert_called_once()

    def test_no_data_triggers_update(self):
        """测试无数据时触发更新"""
        mock_store = MagicMock()
        mock_store.count.return_value = 0

        with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
            with patch("zcyclaw.data.updater.check_and_update", return_value=True) as mock_update:
                from zcyclaw.data.updater import ensure_demo_data
                result = ensure_demo_data(AppConfig())
                assert result is True
                mock_update.assert_called_once()


class TestCheckAndUpdate:
    """check_and_update 函数测试"""

    def test_already_up_to_date(self):
        """测试数据已是最新"""
        mock_store = MagicMock()
        mock_store.count.return_value = 10

        with patch("zcyclaw.data.updater._get_local_version", return_value="1.0.0"):
            with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
                from zcyclaw.data.updater import check_and_update
                result = check_and_update(AppConfig())
                assert result is False

    def test_version_mismatch_triggers_update(self):
        """测试版本不匹配时触发更新"""
        mock_store = MagicMock()
        mock_store.count.return_value = 0  # 向量库为空

        with patch("zcyclaw.data.updater._get_local_version", return_value="0"):
            with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
                with patch("zcyclaw.data.updater._deploy_seed_data", return_value=5):
                    with patch("zcyclaw.data.updater._build_vector_store", return_value=10):
                        with patch("zcyclaw.data.updater._set_local_version"):
                            from zcyclaw.data.updater import check_and_update
                            result = check_and_update(AppConfig())
                            assert result is True

    def test_no_data_triggers_deploy(self):
        """测试无数据时触发部署"""
        mock_store = MagicMock()
        mock_store.count.return_value = 0

        with patch("zcyclaw.data.updater._get_local_version", return_value="0"):
            with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
                with patch("zcyclaw.data.updater._deploy_seed_data", return_value=5):
                    with patch("zcyclaw.data.updater._build_vector_store", return_value=10):
                        with patch("zcyclaw.data.updater._set_local_version"):
                            from zcyclaw.data.updater import check_and_update
                            result = check_and_update(AppConfig())
                            assert result is True

    def test_deploy_returns_zero(self):
        """测试部署返回0时返回False"""
        mock_store = MagicMock()
        mock_store.count.return_value = 0

        with patch("zcyclaw.data.updater._get_local_version", return_value="0"):
            with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
                with patch("zcyclaw.data.updater._deploy_seed_data", return_value=0):
                    from zcyclaw.data.updater import check_and_update
                    result = check_and_update(AppConfig())
                    assert result is False

    def test_build_returns_zero(self):
        """测试构建返回0时返回False"""
        mock_store = MagicMock()
        mock_store.count.return_value = 0

        with patch("zcyclaw.data.updater._get_local_version", return_value="0"):
            with patch("zcyclaw.data.updater.VectorStore", return_value=mock_store):
                with patch("zcyclaw.data.updater._deploy_seed_data", return_value=5):
                    with patch("zcyclaw.data.updater._build_vector_store", return_value=0):
                        from zcyclaw.data.updater import check_and_update
                        result = check_and_update(AppConfig())
                        assert result is False
