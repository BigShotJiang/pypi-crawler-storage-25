"""TUI 模块测试"""

import pytest

from zcyclaw.tui.app import MessageBuffer, TUIApp


class TestMessageBuffer:
    """MessageBuffer 测试"""

    def test_add_user_message(self):
        """添加用户消息"""
        buffer = MessageBuffer()
        buffer.add_user("测试问题")

        formatted = buffer.get_formatted()
        assert len(formatted) == 1
        assert "测试问题" in formatted[0][1]
        assert "fg:ansimagenta bold" in formatted[0][0]

    def test_add_assistant_message(self):
        """添加助手消息"""
        buffer = MessageBuffer()
        buffer.add_assistant("这是回答")

        formatted = buffer.get_formatted()
        assert len(formatted) == 1
        assert "这是回答" in formatted[0][1]
        assert "fg:ansicyan" in formatted[0][0]

    def test_conversation_flow(self):
        """对话流程"""
        buffer = MessageBuffer()
        buffer.add_user("问题1")
        buffer.add_assistant("回答1")
        buffer.add_user("问题2")
        buffer.add_assistant("回答2")

        formatted = buffer.get_formatted()
        assert len(formatted) == 4

    def test_max_size_trimming(self):
        """消息数量限制"""
        buffer = MessageBuffer(max_size=3)
        for i in range(5):
            buffer.add_user(f"问题{i}")
            buffer.add_assistant(f"回答{i}")

        # max_size=3 限制消息条数，5轮对话=10条，只保留最后3条
        # 最后一条是回答4，倒数第二条是问题4
        formatted = buffer.get_formatted()
        # 验证最新的消息在列表中
        assert len(formatted) == 3

    def test_empty_content(self):
        """空内容处理"""
        buffer = MessageBuffer()
        buffer.add_user("")
        buffer.add_assistant("")

        formatted = buffer.get_formatted()
        # 空消息也会被添加
        assert len(formatted) == 2


class TestTUIApp:
    """TUIApp 测试"""

    def test_tui_app_init(self):
        """TUIApp 初始化"""
        app = TUIApp()
        assert app._session is not None
        assert app._msg_buffer is not None
        assert app._streaming is False
        assert app._current_answer == ""

    def test_get_output_text(self):
        """输出文本生成"""
        app = TUIApp()
        text = app._get_output_text()

        # 应该有欢迎信息
        welcome_lines = [t for s, t in text if "欢迎" in t]
        assert len(welcome_lines) >= 1

    def test_message_buffer_integration(self):
        """消息缓冲集成"""
        app = TUIApp()
        app._msg_buffer.add_user("测试问题")
        app._msg_buffer.add_assistant("测试回答")

        output_text = app._get_output_text()
        text_contents = [t for _, t in output_text]

        assert "测试问题" in "".join(text_contents)
        assert "测试回答" in "".join(text_contents)

    def test_streaming_state(self):
        """流式状态"""
        app = TUIApp()
        assert app._streaming is False
        assert app._current_answer == ""

        # 模拟流式输出
        app._streaming = True
        app._current_answer = "部分回答"
        output_text = app._get_output_text()

        # 流式状态应该在输出中体现
        assert app._streaming is True

    def test_session_turn_count(self):
        """会话轮次计数"""
        app = TUIApp()
        assert app._session.turn_count == 0

        app._session.add_exchange("问题", "回答")
        assert app._session.turn_count == 1

        app._msg_buffer.add_user("问题2")
        app._msg_buffer.add_assistant("回答2")
        # MessageBuffer 和 Session 是独立的
        # Session 只通过 add_exchange 增加
