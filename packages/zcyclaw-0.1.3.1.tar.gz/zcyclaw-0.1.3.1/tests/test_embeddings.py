"""Embedding 模块测试"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, AsyncMock

import pytest

from zcyclaw.config.schema import EmbeddingConfig


class TestZhipuEmbeddingFunction:
    """智谱 Embedding 测试"""

    def test_init(self):
        """测试初始化"""
        from zcyclaw.rag.embeddings import ZhipuEmbeddingFunction

        emb = ZhipuEmbeddingFunction(api_key="test-key")
        assert emb._api_key == "test-key"
        assert emb._model == "embedding-3"
        assert "bigmodel.cn" in emb._base_url

    def test_init_custom(self):
        """测试自定义参数"""
        from zcyclaw.rag.embeddings import ZhipuEmbeddingFunction

        emb = ZhipuEmbeddingFunction(
            api_key="key",
            model="custom-model",
            base_url="https://custom.api.com",
        )
        assert emb._model == "custom-model"
        assert emb._base_url == "https://custom.api.com"

    def test_call_single_input(self):
        """测试单条输入"""
        from zcyclaw.rag.embeddings import ZhipuEmbeddingFunction

        emb = ZhipuEmbeddingFunction(api_key="test-key")

        mock_response = {
            "data": [
                {"embedding": [0.1, 0.2, 0.3]},
            ]
        }

        with patch("httpx.post") as mock_post:
            mock_post.return_value.json.return_value = mock_response
            mock_post.return_value.raise_for_status = MagicMock()

            result = emb(["test input"])

            assert len(result) == 1
            assert result[0] == [0.1, 0.2, 0.3]

    def test_call_batch_input(self):
        """测试批量输入"""
        from zcyclaw.rag.embeddings import ZhipuEmbeddingFunction

        emb = ZhipuEmbeddingFunction(api_key="test-key")

        mock_response = {
            "data": [
                {"embedding": [0.1, 0.2]},
                {"embedding": [0.3, 0.4]},
            ]
        }

        with patch("httpx.post") as mock_post:
            mock_post.return_value.json.return_value = mock_response
            mock_post.return_value.raise_for_status = MagicMock()

            result = emb(["input1", "input2"])

            assert len(result) == 2


class TestOpenAICompatEmbeddingFunction:
    """OpenAI 兼容 Embedding 测试"""

    def test_init(self):
        """测试初始化"""
        from zcyclaw.rag.embeddings import OpenAICompatEmbeddingFunction

        emb = OpenAICompatEmbeddingFunction(api_key="test-key")
        assert emb._api_key == "test-key"
        assert emb._model == "text-embedding-v3"

    def test_base_url_strip(self):
        """测试 base_url 去除末尾斜杠"""
        from zcyclaw.rag.embeddings import OpenAICompatEmbeddingFunction

        emb = OpenAICompatEmbeddingFunction(api_key="key", base_url="https://api.test.com/")
        assert emb._base_url == "https://api.test.com"

    def test_call_single_input(self):
        """测试单条输入"""
        from zcyclaw.rag.embeddings import OpenAICompatEmbeddingFunction

        emb = OpenAICompatEmbeddingFunction(api_key="test-key", base_url="https://api.test.com")

        mock_response = {
            "data": [
                {"embedding": [0.1, 0.2, 0.3]},
            ]
        }

        with patch("httpx.post") as mock_post:
            mock_post.return_value.json.return_value = mock_response
            mock_post.return_value.raise_for_status = MagicMock()

            result = emb(["test input"])

            assert len(result) == 1
            assert result[0] == [0.1, 0.2, 0.3]


class TestFastEmbedEmbeddingFunction:
    """FastEmbed Embedding 测试"""

    def test_init(self):
        """测试初始化"""
        from zcyclaw.rag.embeddings import FastEmbedEmbeddingFunction

        emb = FastEmbedEmbeddingFunction()
        assert emb._model_name == "BAAI/bge-m3"
        assert emb._model is None

    def test_init_custom_model(self):
        """测试自定义模型"""
        from zcyclaw.rag.embeddings import FastEmbedEmbeddingFunction

        emb = FastEmbedEmbeddingFunction(model="custom/model")
        assert emb._model_name == "custom/model"

    def test_call_loads_model(self):
        """测试 __call__ 懒加载模型"""
        from zcyclaw.rag.embeddings import FastEmbedEmbeddingFunction

        emb = FastEmbedEmbeddingFunction()

        # Mock TextEmbedding
        mock_model = MagicMock()
        mock_embedding = MagicMock()
        mock_embedding.tolist.return_value = [0.1, 0.2, 0.3]
        mock_model.embed.return_value = [mock_embedding]

        # Mock fastembed 模块
        mock_fastembed = MagicMock()
        mock_fastembed.TextEmbedding = MagicMock(return_value=mock_model)

        with patch.dict("sys.modules", {"fastembed": mock_fastembed}):
            result = emb(["test input"])

            assert len(result) == 1
            assert result[0] == [0.1, 0.2, 0.3]

    def test_call_uses_cached_model(self):
        """测试 __call__ 使用缓存的模型"""
        from zcyclaw.rag.embeddings import FastEmbedEmbeddingFunction

        emb = FastEmbedEmbeddingFunction()

        # 预设置模型
        mock_model = MagicMock()
        mock_embedding = MagicMock()
        mock_embedding.tolist.return_value = [0.4, 0.5, 0.6]
        mock_model.embed.return_value = [mock_embedding]
        emb._model = mock_model

        result = emb(["cached test"])

        assert len(result) == 1
        assert result[0] == [0.4, 0.5, 0.6]
        # 模型已缓存，不会重新加载

    def test_call_import_error(self):
        """测试 fastembed 未安装时抛出 ImportError"""
        from zcyclaw.rag.embeddings import FastEmbedEmbeddingFunction

        emb = FastEmbedEmbeddingFunction()

        with patch.dict("sys.modules", {"fastembed": None}):
            with patch("builtins.__import__", side_effect=ImportError("No module named 'fastembed'")):
                with pytest.raises(ImportError, match="fastembed 未安装"):
                    emb(["test"])

    def test_call_batch_processing(self):
        """测试批量处理"""
        from zcyclaw.rag.embeddings import FastEmbedEmbeddingFunction

        emb = FastEmbedEmbeddingFunction()

        # Mock 模型
        mock_model = MagicMock()
        mock_embeddings = []
        for i in range(3):
            mock_emb = MagicMock()
            mock_emb.tolist.return_value = [float(i), float(i + 1)]
            mock_embeddings.append(mock_emb)
        mock_model.embed.return_value = mock_embeddings

        emb._model = mock_model

        result = emb(["input1", "input2", "input3"])

        assert len(result) == 3
        assert result[0] == [0.0, 1.0]
        assert result[1] == [1.0, 2.0]
        assert result[2] == [2.0, 3.0]


class TestCreateEmbeddingFunction:
    """create_embedding_function 工厂函数测试"""

    def test_create_zhipu(self):
        """测试创建智谱 Embedding"""
        from zcyclaw.rag.embeddings import create_embedding_function, ZhipuEmbeddingFunction

        config = EmbeddingConfig(provider="zhipu", api_key="test-key")
        result = create_embedding_function(config)
        assert isinstance(result, ZhipuEmbeddingFunction)

    def test_create_zhipu_without_key(self):
        """测试无 API Key 时抛出异常"""
        from zcyclaw.rag.embeddings import create_embedding_function

        config = EmbeddingConfig(provider="zhipu")
        with pytest.raises(ValueError, match="需要配置 API Key"):
            create_embedding_function(config)

    def test_create_openai_compat(self):
        """测试创建 OpenAI 兼容 Embedding"""
        from zcyclaw.rag.embeddings import create_embedding_function, OpenAICompatEmbeddingFunction

        config = EmbeddingConfig(
            provider="openai_compat",
            api_key="test-key",
            base_url="https://api.test.com",
        )
        result = create_embedding_function(config)
        assert isinstance(result, OpenAICompatEmbeddingFunction)

    def test_create_openai_compat_missing_params(self):
        """测试 OpenAI 兼容缺少参数时抛出异常"""
        from zcyclaw.rag.embeddings import create_embedding_function

        config = EmbeddingConfig(provider="openai_compat")
        with pytest.raises(ValueError, match="需要配置"):
            create_embedding_function(config)

    def test_create_fastembed(self):
        """测试创建 FastEmbed Embedding"""
        from zcyclaw.rag.embeddings import create_embedding_function, FastEmbedEmbeddingFunction

        config = EmbeddingConfig(provider="fastembed")
        result = create_embedding_function(config)
        assert isinstance(result, FastEmbedEmbeddingFunction)

    def test_unknown_provider(self):
        """测试未知提供商"""
        from zcyclaw.rag.embeddings import create_embedding_function

        config = EmbeddingConfig(provider="unknown")
        with pytest.raises(ValueError, match="未知 Embedding"):
            create_embedding_function(config)

    def test_auto_with_config_api_key(self):
        """测试 auto 模式有配置 API Key"""
        from zcyclaw.rag.embeddings import create_embedding_function, ZhipuEmbeddingFunction

        config = EmbeddingConfig(provider="auto", api_key="test-key")
        result = create_embedding_function(config)
        assert isinstance(result, ZhipuEmbeddingFunction)

    def test_auto_fallback_to_openai_compat(self):
        """测试 auto 模式回退到 openai_compat"""
        from zcyclaw.rag.embeddings import create_embedding_function, OpenAICompatEmbeddingFunction

        config = EmbeddingConfig(
            provider="auto",
            base_url="https://api.test.com",
        )
        result = create_embedding_function(config, provider_api_key="test-key")
        assert isinstance(result, OpenAICompatEmbeddingFunction)

    def test_auto_fallback_to_fastembed(self):
        """测试 auto 模式回退到 fastembed（当无 API Key 时）"""
        from zcyclaw.rag.embeddings import create_embedding_function, FastEmbedEmbeddingFunction

        config = EmbeddingConfig(provider="auto")

        try:
            result = create_embedding_function(config)
            assert isinstance(result, FastEmbedEmbeddingFunction)
        except (ImportError, ValueError) as e:
            pytest.skip(f"Cannot test fastembed fallback: {e}")

    def test_auto_no_solution_raises(self):
        """测试 auto 模式无可用方案时抛出异常"""
        from zcyclaw.rag.embeddings import create_embedding_function

        config = EmbeddingConfig(provider="auto")

        # Mock fastembed import failure
        with patch("zcyclaw.rag.embeddings._create_auto_embedding") as mock_auto:
            mock_auto.side_effect = ValueError("No solution")
            with pytest.raises(ValueError, match="No solution"):
                create_embedding_function(config)


class TestCreateEmbeddingFunctionAuto:
    """create_embedding_function auto 模式测试"""

    def test_auto_with_provider_api_key_and_base_url(self):
        """测试 auto 使用 provider_api_key 和 base_url"""
        from zcyclaw.rag.embeddings import create_embedding_function, OpenAICompatEmbeddingFunction

        config = EmbeddingConfig(provider="auto", base_url="https://api.test.com")
        result = create_embedding_function(config, provider_api_key="test-key")
        assert isinstance(result, OpenAICompatEmbeddingFunction)

    def test_auto_uses_config_model(self):
        """测试 auto 使用配置中的 model"""
        from zcyclaw.rag.embeddings import create_embedding_function, ZhipuEmbeddingFunction

        config = EmbeddingConfig(provider="auto", api_key="key", model="custom-model")
        result = create_embedding_function(config)
        assert isinstance(result, ZhipuEmbeddingFunction)
        assert result._model == "custom-model"
