"""配置加载器测试"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from zcyclaw.config.loader import load_config, save_config
from zcyclaw.config.schema import AppConfig


class TestLoadConfig:
    """load_config 函数测试"""

    def test_load_config_no_file(self):
        """测试配置文件不存在时返回默认配置"""
        with patch("zcyclaw.config.loader.get_config_file", return_value=Path("/nonexistent/config.json")):
            config = load_config()
            assert isinstance(config, AppConfig)

    def test_load_config_with_valid_file(self):
        """测试加载有效配置文件"""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"
            config_data = {
                "default_provider": "zhipu",
                "providers": {
                    "deepseek": {"api_key": "test-key"},
                },
            }
            config_file.write_text(json.dumps(config_data), encoding="utf-8")

            with patch("zcyclaw.config.loader.get_config_file", return_value=config_file):
                config = load_config()
                assert config.default_provider == "zhipu"

    def test_load_config_invalid_json(self):
        """测试无效 JSON 时返回默认配置"""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"
            config_file.write_text("invalid json", encoding="utf-8")

            with patch("zcyclaw.config.loader.get_config_file", return_value=config_file):
                config = load_config()
                assert isinstance(config, AppConfig)


class TestSaveConfig:
    """save_config 函数测试"""

    def test_save_config_creates_directory(self):
        """测试保存配置时创建目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "subdir" / "config.json"

            with patch("zcyclaw.config.loader.get_config_file", return_value=config_file):
                config = AppConfig()
                save_config(config)

                assert config_file.exists()

    def test_save_config_writes_json(self):
        """测试保存配置写入 JSON"""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"

            with patch("zcyclaw.config.loader.get_config_file", return_value=config_file):
                config = AppConfig(default_provider="deepseek")
                save_config(config)

                data = json.loads(config_file.read_text(encoding="utf-8"))
                assert data["default_provider"] == "deepseek"

    def test_save_config_exclude_none(self):
        """测试保存配置排除 None 值"""
        with tempfile.TemporaryDirectory() as tmpdir:
            config_file = Path(tmpdir) / "config.json"

            with patch("zcyclaw.config.loader.get_config_file", return_value=config_file):
                config = AppConfig()
                save_config(config)

                data = json.loads(config_file.read_text(encoding="utf-8"))
                # 验证配置可以正确序列化
                assert "default_provider" in data
