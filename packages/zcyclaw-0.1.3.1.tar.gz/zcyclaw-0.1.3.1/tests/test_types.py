"""类型定义测试"""

from __future__ import annotations

import pytest

from zcyclaw.types import HierarchyLevel, LawStatus


class TestHierarchyLevel:
    """HierarchyLevel 枚举测试"""

    def test_all_levels_exist(self):
        """测试所有层级都存在"""
        assert HierarchyLevel.部门规章 is not None
        assert HierarchyLevel.地方性法规 is not None
        assert HierarchyLevel.行政法规 is not None
        assert HierarchyLevel.法律 is not None
        assert HierarchyLevel.宪法 is not None

    def test_int_enum_values(self):
        """测试 IntEnum 值"""
        assert int(HierarchyLevel.部门规章) == 1
        assert int(HierarchyLevel.地方性法规) == 2
        assert int(HierarchyLevel.行政法规) == 3
        assert int(HierarchyLevel.法律) == 4
        assert int(HierarchyLevel.宪法) == 5

    def test_comparison(self):
        """测试层级比较"""
        assert HierarchyLevel.法律 > HierarchyLevel.行政法规
        assert HierarchyLevel.行政法规 > HierarchyLevel.地方性法规
        assert HierarchyLevel.地方性法规 > HierarchyLevel.部门规章

    def test_highest_level(self):
        """测试最高层级"""
        levels = list(HierarchyLevel)
        highest = max(levels)
        assert highest == HierarchyLevel.宪法

    def test_lowest_level(self):
        """测试最低层级"""
        levels = list(HierarchyLevel)
        lowest = min(levels)
        assert lowest == HierarchyLevel.部门规章

    def test_subscript_access(self):
        """测试下标访问"""
        assert HierarchyLevel["法律"] == HierarchyLevel.法律
        assert HierarchyLevel["部门规章"] == HierarchyLevel.部门规章


class TestLawStatus:
    """LawStatus 类测试"""

    def test_all_statuses_exist(self):
        """测试所有状态都存在"""
        assert LawStatus.有效 == "有效"
        assert LawStatus.已修订 == "已修订"
        assert LawStatus.已废止 == "已废止"
        assert LawStatus.部分失效 == "部分失效"

    def test_status_values(self):
        """测试状态值是字符串"""
        assert isinstance(LawStatus.有效, str)
        assert isinstance(LawStatus.已修订, str)
        assert isinstance(LawStatus.已废止, str)
        assert isinstance(LawStatus.部分失效, str)

    def test_status_equality(self):
        """测试状态比较"""
        assert LawStatus.有效 == "有效"
        assert LawStatus.已废止 == "已废止"
        assert LawStatus.有效 != LawStatus.已废止
