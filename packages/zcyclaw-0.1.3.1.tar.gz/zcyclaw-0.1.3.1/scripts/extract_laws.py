#!/usr/bin/env python3
"""
从政府采购制度文件汇编2022版.docx 中提取核心全国性法规文本，转为 Markdown 格式。

用法:
    uv run python scripts/extract_laws.py <汇编docx> [独立docx] -o <输出目录>

示例:
    uv run python scripts/extract_laws.py 汇编.docx 政府采购法.docx -o data/seed_data
    uv run python scripts/extract_laws.py 汇编.docx -o data/seed_data

输出:
    {输出目录}/{法规名}.{效力层级}.{状态}.md

核心逻辑:
1. 从汇编 docx 中按段落索引定位每部法规
2. 合并因分页符断裂的段落（docx 中长段落经常被分成多段）
3. 格式化为 Markdown: 一级标题(法规名), 二级标题(章节), 条号加粗
"""

import argparse
import re
import sys
from pathlib import Path
from docx import Document

# ============================================================
# 配置
# ============================================================

# 需要提取的法规列表
# compilation_title_idx: 法规正文标题在汇编中的段落索引
LAWS_TO_EXTRACT = [
    {
        "name": "中华人民共和国政府采购法",
        "filename": "政府采购法.法律.有效.md",
        "level": "法律",
        "compilation_title_idx": 317,
        "use_standalone": True,  # 优先使用独立 docx（更完整、2025年修正版）
    },
    {
        "name": "中华人民共和国政府采购法实施条例",
        "filename": "政府采购法实施条例.行政法规.有效.md",
        "level": "行政法规",
        "compilation_title_idx": 642,
    },
    {
        "name": "中华人民共和国招标投标法",
        "filename": "招标投标法.法律.有效.md",
        "level": "法律",
        "compilation_title_idx": 1010,
    },
    {
        "name": "中华人民共和国招标投标法实施条例",
        "filename": "招标投标法实施条例.行政法规.有效.md",
        "level": "行政法规",
        "compilation_title_idx": 1235,
    },
    {
        "name": "政府采购货物和服务招标投标管理办法",
        "filename": "政府采购货物和服务招标投标管理办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 1953,
    },
    {
        "name": "政府采购非招标采购方式管理办法",
        "filename": "政府采购非招标采购方式管理办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 1618,
    },
    {
        "name": "政府采购竞争性磋商采购方式管理暂行办法",
        "filename": "政府采购竞争性磋商采购方式管理暂行办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 2790,
    },
    {
        "name": "政府采购框架协议采购方式管理暂行办法",
        "filename": "政府采购框架协议采购方式管理暂行办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 2978,
    },
    {
        "name": "政府采购促进中小企业发展管理办法",
        "filename": "政府采购促进中小企业发展管理办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 4178,
    },
    {
        "name": "政府采购需求管理办法",
        "filename": "政府采购需求管理办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 3637,
    },
    {
        "name": "政府采购信息发布管理办法",
        "filename": "政府采购信息公开办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 2615,
    },
    {
        "name": "政府采购评审专家管理办法",
        "filename": "政府采购评审专家管理办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 7482,
    },
    {
        "name": "政府采购进口产品管理办法",
        "filename": "政府采购进口产品管理办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 8885,
    },
    {
        "name": "政府采购代理机构管理暂行办法",
        "filename": "政府采购代理机构管理暂行办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 6625,
    },
    {
        "name": "政府和社会资本合作项目政府采购管理办法",
        "filename": "政府和社会资本合作项目政府采购管理办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 8252,
    },
    {
        "name": "关于促进政府采购公平竞争优化营商环境的通知",
        "filename": "关于促进政府采购公平竞争优化营商环境的通知.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": 6389,
    },
    {
        "name": "政府采购合作创新采购方式管理暂行办法",
        "filename": "政府采购合作创新采购方式管理暂行办法.部门规章.有效.md",
        "level": "部门规章",
        "compilation_title_idx": None,  # 不在2022版汇编中
    },
]


# ============================================================
# 工具函数
# ============================================================

def get_font_size(paragraph):
    """获取段落的字号大小（pt）。"""
    for run in paragraph.runs:
        if run.font.size:
            return run.font.size.pt
    return None


def is_bold_para(paragraph):
    """检查段落是否有加粗的 run。"""
    return any(run.bold for run in paragraph.runs if run.bold is not None)


def is_chapter_title(paragraph):
    """判断段落是否是章节标题（'第一章 总则'等）。

    两种检测方式：
    1. 格式检测：12pt以上加粗 + "第X章"开头（汇编 docx 中的格式）
    2. 纯文本检测：短文本 + "第X章"开头 + 不是条款内容（独立 docx 中的格式）
    """
    text = paragraph.text.strip()
    if not text:
        return False
    # 方式1：格式检测
    font_size = get_font_size(paragraph)
    bold = is_bold_para(paragraph)
    if font_size and font_size >= 12 and bold and re.match(r'^第[一二三四五六七八九十百千]+章', text):
        return True
    # 方式2：纯文本检测 - "第X章"开头且总长度较短（<30字）
    if re.match(r'^第[一二三四五六七八九十百千]+章[　\s]?\S*$', text) and len(text) < 30:
        return True
    return False


def is_structural_start(text):
    """
    判断文本是否是一个结构性元素的开始（不应与前段合并）。

    包括：
    - 第X条（条款开头）
    - 第X章（章节标题）
    - （一）（二）等项
    - 一、二、等款
    - 大写数字标题（一、全面清理...）
    """
    if not text:
        return False
    # 第X条
    if re.match(r'^第[一二三四五六七八九十百千]+条', text):
        return True
    # 第X章
    if re.match(r'^第[一二三四五六七八九十百千]+章', text):
        return True
    # （一）中文圆括号项
    if re.match(r'^（[一二三四五六七八九十]+）', text):
        return True
    # (一)英文圆括号项
    if re.match(r'^\([一二三四五六七八九十]+\)', text):
        return True
    # "一、" "二、" 等大写数字标题
    if re.match(r'^[一二三四五六七八九十]+、', text):
        return True
    return False


def find_all_title_indices(doc, min_idx=300):
    """找到汇编文档中所有法规大标题的段落索引。"""
    indices = []
    for i, p in enumerate(doc.paragraphs):
        if i < min_idx:
            continue
        text = p.text.strip()
        if not text:
            continue
        font_size = get_font_size(p)
        if font_size and font_size >= 19.0:
            indices.append(i)
    return sorted(indices)


def clean_page_numbers(text):
    """清理汇编 docx 中混入的页码数字（如 '216'、'160' 等）。

    页码特征：紧跟在法规正文文本末尾，是一个纯数字（1-3位），
    且与前文内容之间没有标点符号分隔。
    """
    # 清理句末或段中混入的页码数字（如 "...的除外。160" 或 "...的除外160"）
    # 模式：中文标点或汉字后面紧跟一个2-3位数字，且数字后面没有紧跟中文字符或标点
    text = re.sub(r'([。；：！？）\)】»"\u3001\u2026])\d{2,3}(\s|$)', r'\1\2', text)
    # 特殊处理：数字紧跟在正文末尾无标点的情况
    text = re.sub(r'([\u4e00-\u9fff])\d{2,3}$', r'\1', text)
    return text


def is_page_number_paragraph(text):
    """判断段落是否纯粹是一个页码数字（应完全跳过）。"""
    text = text.strip()
    if re.match(r'^\d{1,3}$', text):
        return True
    return False


def merge_paragraphs(paragraphs, start_idx, end_idx, law_name):
    """
    提取并合并段落：将因分页断裂的连续段落合并为逻辑段落。

    返回: [(merged_text, paragraph_for_metadata), ...]
    其中 paragraph_for_metadata 取合并组的第一个段落（用于判断格式信息）。
    """
    raw = []
    for i in range(start_idx, end_idx):
        text = paragraphs[i].text.strip()
        if text and not is_page_number_paragraph(text):
            raw.append((text, paragraphs[i]))

    if not raw:
        return []

    # 合并逻辑：如果当前文本不是结构性开始，则与前一条合并
    merged = []
    current_text = raw[0][0]
    current_para = raw[0][1]  # 保留第一个段落用于格式判断

    for i in range(1, len(raw)):
        text, para = raw[i]
        font_size = get_font_size(para)
        is_big_title = font_size and font_size >= 19.0
        is_chapter = is_chapter_title(para)

        # 判断是否应该开始新的逻辑段落
        should_start_new = (
            is_big_title or                           # 大标题（法规名）
            is_chapter or                              # 章节标题
            is_structural_start(text) or               # 第X条、（一）、一、等
            current_text == law_name                   # 前一段是法规名本身
        )

        if should_start_new:
            # 保存当前累积的段落（先清理页码）
            merged.append((clean_page_numbers(current_text), current_para))
            current_text = text
            current_para = para
        else:
            # 合并到当前段落（docx中因分页符断裂的续行）
            current_text += text

    # 最后一段
    if current_text:
        merged.append((clean_page_numbers(current_text), current_para))

    return merged


def normalize_chapter_title(text):
    """标准化章节标题格式：清理全角/多余空格，统一为'第X章 标题'。"""
    # 将全角空格(\u3000)替换为半角空格，并去除多余空格
    text = text.replace("\u3000", " ").strip()
    # 标准化为 "第X章 标题"
    text = re.sub(r'^(第[一二三四五六七八九十百千]+章)\s+(.+)$', r'\1 \2', text)
    text = re.sub(r'^(第[一二三四五六七八九十百千]+章)([^ ])', r'\1 \2', text)
    return text


def detect_and_remove_toc(merged_paragraphs):
    """
    检测并移除目录区域。

    目录的特征：在法规名/序言之后，正文开始之前，出现连续的"第X章 XXX"短行列表。
    通常以"目录"标题开始，到遇到非目录内容（如条款正文）时结束。

    处理方式：
    1. 清理包含"目录"关键词段落中的"目录"文本（保留其他内容如修订信息）
    2. 移除目录区域中连续的章节标题（但保留正文中重复出现的章节标题）

    返回: 清理后的 merged_paragraphs
    """
    if not merged_paragraphs:
        return merged_paragraphs

    # 第一步：定位目录区域
    # 查找包含"目录"关键词的段落
    toc_keyword_idx = None
    for i, (text, para) in enumerate(merged_paragraphs):
        if re.search(r'目\s{0,3}录', text):
            toc_keyword_idx = i
            break

    if toc_keyword_idx is None:
        # 没有"目录"关键词，无需处理
        return merged_paragraphs

    # 第二步：从"目录"关键词之后开始，查找连续的章节标题
    # 目录区域 = "目录"关键词所在段落之后，连续的章节标题列表
    # 目录结束的标志：
    #   a) 遇到非章节标题的实质性内容（如条款正文）
    #   b) 章节标题开始重复（说明已进入正文）
    toc_chapter_indices = set()  # 要移除的章节标题段落索引
    seen_chapter_names = set()   # 已见章节名（用于检测重复）
    i = toc_keyword_idx + 1
    while i < len(merged_paragraphs):
        text, para = merged_paragraphs[i]
        text_stripped = text.strip()
        # 章节标题（短文本，以"第X章"开头）
        if is_chapter_title(para) and len(text_stripped) < 30:
            # 标准化章节名（去除空格差异）
            normalized = text_stripped.replace(" ", "").replace("\u3000", "")
            if normalized in seen_chapter_names:
                # 章节名重复，说明已进入正文，停止目录区域
                break
            seen_chapter_names.add(normalized)
            toc_chapter_indices.add(i)
            i += 1
            continue
        # 空文本，跳过
        if not text_stripped:
            i += 1
            continue
        # 遇到其他内容，目录区域结束
        break

    # 如果只找到1个或更少的章节标题，可能不是真正的目录，只清理"目录"文本
    if len(toc_chapter_indices) < 2:
        result = []
        for text, para in merged_paragraphs:
            cleaned_text = re.sub(r'目\s{0,3}录\s*$', '', text).strip()
            if cleaned_text:
                result.append((cleaned_text, para))
        return result

    # 第三步：构建结果
    # - 清理含"目录"段落中的"目录"文本
    # - 移除目录区域中的章节标题
    # - 保留其他所有段落
    result = []
    for i, (text, para) in enumerate(merged_paragraphs):
        if i == toc_keyword_idx:
            # 清理"目录"文本，保留其他内容
            cleaned_text = re.sub(r'目\s{0,3}录\s*$', '', text).strip()
            if cleaned_text:
                result.append((cleaned_text, para))
            continue
        if i in toc_chapter_indices:
            # 跳过目录中的章节标题
            continue
        result.append((text, para))
    return result


def format_law_text(merged_paragraphs, law_name, level):
    """
    将合并后的逻辑段落格式化为 Markdown 文本。

    参数:
        merged_paragraphs: [(merged_text, paragraph), ...]
        law_name: 法规名称
        level: 效力层级
    返回:
        Markdown 格式字符串
    """
    # 先清理目录区域
    merged_paragraphs = detect_and_remove_toc(merged_paragraphs)

    lines = []
    # 一级标题：法规名
    lines.append(f"# {law_name}")
    lines.append("")

    for text, para in merged_paragraphs:
        font_size = get_font_size(para)

        # 跳过法规大标题本身（已作为一级标题）
        if font_size and font_size >= 19.0:
            normalized = text.replace(" ", "").replace("\n", "")
            normalized_name = law_name.replace(" ", "")
            if normalized == normalized_name:
                continue
            if re.match(r'^第[一二三四五六七八九十]+部分', text):
                continue
            continue

        # 章节标题 -> 二级标题
        if is_chapter_title(para):
            section_text = normalize_chapter_title(text)
            lines.append(f"## {section_text}")
            lines.append("")
            continue

        # 第X条 -> 条号加粗
        article_match = re.match(r'^(第[一二三四五六七八九十百千]+条)\s*(.*)', text, re.DOTALL)
        if article_match:
            article_num = article_match.group(1)
            article_content = article_match.group(2)
            if article_content:
                lines.append(f"**{article_num}** {article_content}")
            else:
                lines.append(f"**{article_num}**")
            lines.append("")
            continue

        # 其他段落（序言、通知正文、款项续行等）
        lines.append(text)
        lines.append("")

    # 清理末尾空行
    while lines and lines[-1] == "":
        lines.pop()

    return "\n".join(lines) + "\n"


def extract_from_compilation(doc, law_config, all_title_indices):
    """从汇编文档中提取单个法规文本。"""
    title_idx = law_config["compilation_title_idx"]
    if title_idx is None:
        print(f"  ⚠ {law_config['name']} 未在汇编中找到，跳过")
        return None

    law_name = law_config["name"]
    paragraphs = doc.paragraphs

    # 找到下一个法规大标题位置
    end_idx = len(paragraphs)
    for idx in all_title_indices:
        if idx > title_idx:
            end_idx = idx
            break

    # 合并断裂段落
    merged = merge_paragraphs(paragraphs, title_idx, end_idx, law_name)

    # 格式化
    md_text = format_law_text(merged, law_name, law_config["level"])
    return md_text


def extract_from_standalone(docx_path, law_config):
    """从独立 docx 文件中提取法规文本。"""
    doc = Document(str(docx_path))
    paragraphs = doc.paragraphs
    law_name = law_config["name"]

    # 合并段落
    merged = merge_paragraphs(paragraphs, 0, len(paragraphs), law_name)

    md_text = format_law_text(merged, law_name, law_config["level"])
    return md_text


# ============================================================
# 主函数
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="从 docx 中提取政府采购法规文本，转为 Markdown 格式")
    parser.add_argument("compilation", type=Path, help="汇编 docx 文件路径")
    parser.add_argument("standalone", type=Path, nargs="?", default=None, help="独立 docx 文件路径（可选）")
    parser.add_argument("-o", "--output", type=Path, default=Path("data/seed_data"), help="输出目录（默认: data/seed_data）")
    args = parser.parse_args()

    compilation_docx = args.compilation
    standalone_docx = args.standalone
    output_dir = args.output

    if not compilation_docx.exists():
        print(f"错误: 汇编文件不存在: {compilation_docx}")
        sys.exit(1)

    print("=" * 60)
    print("政府采购法规提取工具")
    print("=" * 60)

    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n加载汇编文档: {compilation_docx}")
    compilation_doc = Document(str(compilation_docx))
    print(f"  总段落数: {len(compilation_doc.paragraphs)}")

    all_title_indices = find_all_title_indices(compilation_doc)
    print(f"  找到 {len(all_title_indices)} 个大标题段落")

    extracted_count = 0
    skipped_count = 0

    for law_config in LAWS_TO_EXTRACT:
        law_name = law_config["name"]
        filename = law_config["filename"]
        output_path = output_dir / filename

        print(f"\n提取: {law_name}")
        print(f"  输出文件: {filename}")

        md_text = None

        if law_config.get("use_standalone") and standalone_docx and standalone_docx.exists():
            print(f"  使用独立文档: {standalone_docx.name}")
            md_text = extract_from_standalone(standalone_docx, law_config)
        elif law_config["compilation_title_idx"] is not None:
            print(f"  从汇编中提取 (起始段落: {law_config['compilation_title_idx']})")
            md_text = extract_from_compilation(compilation_doc, law_config, all_title_indices)
        else:
            print(f"  无可用源，跳过")
            skipped_count += 1
            continue

        if md_text is None:
            skipped_count += 1
            continue

        output_path.write_text(md_text, encoding="utf-8")
        line_count = md_text.count("\n") + 1
        char_count = len(md_text)
        print(f"  已保存 ({line_count} 行, {char_count} 字符)")
        extracted_count += 1

    print(f"\n{'=' * 60}")
    print(f"提取完成！")
    print(f"  成功: {extracted_count} 个")
    print(f"  跳过: {skipped_count} 个")
    print(f"  输出目录: {output_dir}")


if __name__ == "__main__":
    main()
