"""离线构建向量库脚本

用法: uv run python scripts/build_data.py
"""

import sys
from pathlib import Path

# 将 src 加入路径
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from zcyclaw.config.schema import AppConfig
from zcyclaw.rag.loader import LawLoader
from zcyclaw.rag.vector_store import VectorStore


def main():
    print("开始构建向量库...")

    config = AppConfig()

    # 加载法规数据
    seed_dir = Path(__file__).parent.parent / "data" / "seed_data"
    if not seed_dir.exists():
        print(f"错误: 法规目录不存在: {seed_dir}")
        sys.exit(1)

    loader = LawLoader()
    chunks = loader.load_directory(seed_dir)
    print(f"已加载 {len(chunks)} 条法条")

    if not chunks:
        print("错误: 没有加载到任何法条")
        sys.exit(1)

    # 构建向量库
    store = VectorStore(config)
    # 清除旧数据
    store.clear()

    added = store.add_chunks(chunks)
    print(f"已添加 {added} 条法条到向量库")

    # 验证
    stats = store.get_stats()
    print(f"\n统计信息:")
    print(f"  法规数量: {stats['law_count']}")
    print(f"  法条片段: {stats['chunk_count']}")
    print(f"  存储路径: {stats['path']}")

    # 测试检索
    results = store.query("询价采购需要满足什么条件", top_k=3)
    print(f"\n测试检索 '询价采购需要满足什么条件':")
    for i, r in enumerate(results, 1):
        meta = r["metadata"]
        print(f"  [{i}] {meta.get('law_name', '')} {meta.get('article_number', '')} (distance={r['distance']:.4f})")
        print(f"      {r['document'][:60]}...")

    print("\n✓ 向量库构建完成!")


if __name__ == "__main__":
    main()
