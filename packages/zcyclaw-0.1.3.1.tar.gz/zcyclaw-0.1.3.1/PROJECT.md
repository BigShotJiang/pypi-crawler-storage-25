# PROJECT.md

本文件面向**人类开发者**，介绍项目概述、技术栈、代码结构、开发命令等信息。

---

## 项目概述

**zcyclaw**（政府采购 Agent）是一个独立于采购平台的政府采购智能顾问工具，基于 RAG 架构提供专业法规问答、采购方式推荐、价格查询、文档模板生成等功能。不绑定任何采购平台，核心开源。

CLI 命令名：`zcyclaw`

---

## 代码结构

```
src/zcyclaw/
├── __init__.py            # 版本号(从pyproject.toml读取)
├── __main__.py            # 入口
├── types.py               # 类型定义
├── session.py             # 会话记忆管理
├── qa.py                  # RAG问答核心逻辑
├── cli/
│   ├── __init__.py
│   ├── commands.py        # Typer命令定义
│   └── stream.py          # 流式输出渲染
├── config/
│   ├── __init__.py
│   ├── schema.py          # Pydantic配置模型
│   ├── loader.py          # 配置加载
│   └── paths.py           # 路径集中管理
├── data/
│   ├── __init__.py
│   └── updater.py         # 数据更新管理
├── rag/
│   ├── __init__.py
│   ├── loader.py          # 文档加载器
│   ├── chunker.py         # 法规专用分块器(按条款/章节)
│   ├── embeddings.py      # Embedding适配层
│   ├── vector_store.py    # ChromaDB存储层
│   └── retriever.py       # 检索器
├── llm/
│   ├── __init__.py        # 懒加载导出
│   ├── base.py            # LLMProvider基类 + LLMResponse
│   ├── factory.py         # LLM工厂
│   ├── registry.py        # ProviderSpec注册表
│   ├── retry.py           # 重试逻辑
│   ├── openai_compat.py   # OpenAI兼容后端(覆盖DeepSeek/智谱/通义/Ollama等)
│   └── anthropic_provider.py  # Anthropic独立后端
├── price/                 # 价格查询模块(待实现)
├── crawler/               # 爬虫模块(可选，待实现)
└── template/              # 文档生成模板(待实现)
```

---

## 技术栈

| 类别 | 技术 |
|------|------|
| 语言 | Python 3.11+ |
| CLI 框架 | Typer + Rich + prompt_toolkit |
| 配置管理 | Pydantic + pydantic-settings |
| 包管理 | uv（pyproject.toml + 分层extras + hatchling构建） |
| 向量库 | ChromaDB（嵌入式运行，PersistentClient本地持久化） |
| Embedding | 智谱API(首选) / fastembed(本地可选) / BGE-M3(高级可选) |
| LLM | DeepSeek / 智谱GLM(首选)，兼容OpenAI/Anthropic |
| RAG框架 | 自研（不用LangChain，体积可控、稳定、领域适配） |
| 日志 | loguru |
| 价格数据 | SQLite（结构化查询） |
| 文档生成 | python-docx + Jinja2 |

---

## 开发命令

```bash
# 安装依赖
uv sync

# 运行 CLI
uv run zcyclaw

# 构建
uv build

# 发布到 PyPI
uv publish

# 运行测试
uv run pytest

# 免安装直接运行
uvx zcyclaw ask "询价采购需要满足什么条件？"
```

---

## 分层安装

```bash
uv tool install zcyclaw                          # 最小安装
uv tool install "zcyclaw[deepseek,zhipu]"        # 国产模型支持
uv tool install "zcyclaw[full]"                  # 完整安装
```

---

## 配置

配置文件位置：`~/.zcyclaw/config.json`

采用 Pydantic + pydantic-settings，支持环境变量覆盖：

```bash
ZCYCLAW_PROVIDERS__DEEPSEEK__API_KEY=xxx
```

---

## 关键决策

- **Typer 替代 Click**: 更现代的CLI框架，自动类型推断和help生成
- **Pydantic 配置**: 类型安全 + 环境变量自动解析，参考nanobot
- **ProviderSpec注册表**: 新增厂商只需加一条Spec + 一个Config字段，参考nanobot
- **openai_compat统一后端**: 绝大多数国产模型兼容OpenAI协议，避免为每个厂商写适配器
- **懒加载**: 用户只装了DeepSeek就不导入Anthropic SDK，减少启动时间和内存
- **不用LangChain**: 依赖链重(+200MB)、breaking changes频繁，自研RAG核心代码量可控
- **Playwright非运行时依赖**: 安装体积200MB+，仅作可选"zcyclaw[crawler]`扩展
- **国产模型优先**: 目标用户在国内，OpenAI/Anthropic访问不稳定
- **预构建数据包**: 首次运行从CDN下载，避免本地构建耗时
- **loguru替代logging**: 更简洁的日志库，开箱即用

---

## 架构分层

```
用户交互层(CLI→TUI→Web)
    ↓
会话记忆层
    ↓
RAG知识检索层(ChromaDB+自研)
    ↓
结构化数据层(SQLite)
    ↓
数据更新层(预构建→增量→可选爬虫)
    ↓
LLM推理生成层
```

---

## 分阶段开发计划

### Phase 1（当前）
CLI框架 + RAG问答(自研) + 国产模型支持 + 预构建数据包

### Phase 2（规划中）
价格查询 + 文档模板生成 + 合规计算 + 历史管理

### Phase 3（规划中）
供应商功能 + 可选爬虫 + 法规追踪 + TUI/Web UI

---

## 模块说明

### CLI 模块 (`cli/`)
用户交互入口，提供命令行界面。

### Config 模块 (`config/`)
配置管理，通过 Pydantic 实现类型安全的配置加载与环境变量支持。

### RAG 模块 (`rag/`)
自研 RAG 核心，包含：
- `loader.py` - 文档加载
- `chunker.py` - 法规专用分块（按条款/章节）
- `embeddings.py` - Embedding 适配层
- `vector_store.py` - ChromaDB 存储
- `retriever.py` - 检索器

### LLM 模块 (`llm/`)
大模型支持，包含：
- `base.py` - Provider 基类定义
- `registry.py` - ProviderSpec 注册表
- `openai_compat.py` - OpenAI 兼容后端（DeepSeek/智谱/通义/Ollama等）
- `anthropic_provider.py` - Anthropic 独立后端
- `factory.py` - LLM 工厂
- `retry.py` - 重试逻辑

### Session 模块 (`session.py`)
会话记忆管理，支持多轮对话上下文。

### QA 模块 (`qa.py`)
RAG 问答核心逻辑，串联检索与生成。

### Data 模块 (`data/`)
数据更新管理。

---

## 目录规范

```
docs/               # 项目文档
  codereview/       # 复盘报告目录
scripts/            # 辅助脚本
tests/              # 测试文件
```
