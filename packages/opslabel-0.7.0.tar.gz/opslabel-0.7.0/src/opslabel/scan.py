"""Scan orchestrator — runs the 47-criteria reviewer-checklist lint and
assembles the v3 report payload.

v0.7.0 — replaced the v0.5.x QA-check pipeline with the deterministic 47-
criteria lint runner. The dashboard's existing reader continues to work
because we wrap the lint summary into the legacy summary key shape:

    legacy_passed       <- lint pass count
    legacy_failed       <- lint fail count
    legacy_warned       <- lint needs_review count
    legacy_skipped      <- lint human_only count
    legacy_verdict      <- "FAIL" | "WARN" | "PASS"

The new keys (`pass`, `fail`, `needs_review`, `human_only`, `total`) live
alongside the legacy keys in the same `summary` block; the rich per-
criterion detail lives in the top-level `criteria` block, replacing the
old `checks` block.
"""
from __future__ import annotations

import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from . import __version__, machine
from .tb2_lint.runner import run_lint as _run_lint
from .tb2_lint.types import LintReport


TASK_INSTRUCTION_MAX_CHARS = 50_000


def run_scan(
    task_path: Path,
    *,
    runs: int = 5,
    no_multi_run: bool = False,
    r3_mode: str = "aggregate",
    task_name: Optional[str] = None,
) -> dict:
    """Run the 47-criteria lint and return the v3 scan report dict.

    No LLM calls. No network. No subprocesses (apart from the optional
    multi-run oracle check inside the lint runner).
    """
    started = datetime.now(timezone.utc)
    t0 = time.monotonic()

    report: LintReport = _run_lint(
        task_path,
        runs=runs,
        no_multi_run=no_multi_run,
        r3_mode=r3_mode,
    )

    duration_ms = int((time.monotonic() - t0) * 1000)
    summary = _wrap_summary(report.summary)

    payload: dict[str, Any] = {
        "schema_version": 3,
        "task_path": str(task_path.resolve()),
        "task_name": task_name or report.task_id,
        "task_metadata": _read_task_metadata_header(task_path),
        "ran_at": started.isoformat().replace("+00:00", "Z"),
        "duration_ms": duration_ms,
        "cli_version": __version__,
        "machine": machine.info(),
        "summary": summary,
        "criteria": report.criteria,
    }

    instruction = _read_task_instruction(task_path)
    if instruction is not None:
        payload["task_instruction_md"] = instruction
    return payload


def _wrap_summary(lint_summary: dict) -> dict:
    """Combine lint summary keys with legacy scan summary keys.

    Legacy keys (`passed`, `failed`, `warned`, `skipped`, `verdict`) preserve
    backwards compat with the dashboard's current reader. New keys (`pass`,
    `fail`, `needs_review`, `human_only`, `total`) provide the canonical
    per-tier counts for newer consumers.

    Verdict mapping (per v0.7.0 brief):
        "FAIL"  if fail > 0
        "WARN"  if needs_review > 0 or human_only > 0
        "PASS"  otherwise
    """
    p = int(lint_summary.get("pass", 0))
    f = int(lint_summary.get("fail", 0))
    nr = int(lint_summary.get("needs_review", 0))
    ho = int(lint_summary.get("human_only", 0))
    total = int(lint_summary.get("total", p + f + nr + ho))

    if f > 0:
        verdict = "FAIL"
    elif nr > 0 or ho > 0:
        verdict = "WARN"
    else:
        verdict = "PASS"

    return {
        # New canonical keys
        "total": total,
        "pass": p,
        "fail": f,
        "needs_review": nr,
        "human_only": ho,
        # Legacy keys preserved for the dashboard's current reader
        "verdict": verdict,
        "passed": p,
        "failed": f,
        "warned": nr,
        "skipped": ho,
    }


def _read_task_instruction(task_path: Path) -> Optional[str]:
    """Read instruction.md raw, capped at TASK_INSTRUCTION_MAX_CHARS.
    Returns None if the file is missing or unreadable.
    """
    p = task_path / "instruction.md"
    if not p.is_file():
        return None
    try:
        text = p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None
    if len(text) > TASK_INSTRUCTION_MAX_CHARS:
        text = text[:TASK_INSTRUCTION_MAX_CHARS] + "\n\n[...truncated]"
    return text


def _read_task_metadata_header(task_path: Path) -> dict:
    """Best-effort metadata extraction for the dashboard's metadata strip.
    Failures degrade silently to {}.
    """
    try:
        try:
            import tomllib  # type: ignore[import-not-found]
        except ModuleNotFoundError:
            import tomli as tomllib  # type: ignore[no-redef]
        with open(task_path / "task.toml", "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return {}
    meta = data.get("metadata") or {}
    if not isinstance(meta, dict):
        meta = {}
    tags = meta.get("tags")
    if not isinstance(tags, list):
        tags = []
    return {
        "version": data.get("version") if isinstance(data.get("version"), str) else None,
        "author_name": meta.get("author_name") if isinstance(meta.get("author_name"), str) else None,
        "author_email": meta.get("author_email") if isinstance(meta.get("author_email"), str) else None,
        "difficulty": meta.get("difficulty") if isinstance(meta.get("difficulty"), str) else None,
        "category": meta.get("category") if isinstance(meta.get("category"), str) else None,
        "tags": [t for t in tags if isinstance(t, str)],
    }
