"""Rubric checks: R-1, R-2, R-3, R-4, R-5, R-7, R-10, R-11."""
from __future__ import annotations

import re
from pathlib import Path

from ..tb2_lint.parsers import rubric as rubric_parser
from ..tb2_lint.parsers.rubric import Rubric, RubricCriterion, is_valid_score
from ..tb2_lint.types import CheckResult, EvidenceEntry, RunContext, Verdict


def _get_rubrics(ctx: RunContext) -> list[Rubric]:
    return rubric_parser.locate_rubrics(
        ctx.task_dir, ctx.task_toml, ctx.is_milestone, ctx.num_milestones,
    )


def _no_rubric_result(verdict_for_missing: Verdict, name: str) -> CheckResult:
    return CheckResult(
        verdict=verdict_for_missing,
        reasoning=(
            f"Could not locate any rubric content "
            f"(checked task.toml `rubric` field, [rubric] table, and rubric.md)."
        ),
        auditor_notes=(
            f"Reviewer must locate the rubric and verify {name} manually."
            if verdict_for_missing == Verdict.NEEDS_REVIEW else ""
        ),
    )


# ============================================================================
# R-1: Rubrics must not reference testing logic
# ============================================================================

_R1_PATTERN = re.compile(
    r"\b(?: /tests?/ | test\.sh | test_m\d+ | verifier | unit\s+tests? | "
    r"reward\.txt | pytest | passes\s+(?:the\s+)?tests?)\b",
    re.IGNORECASE | re.VERBOSE,
)


def check_r1(ctx: RunContext) -> CheckResult:
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "no testing-logic references")

    evidence: list[EvidenceEntry] = []
    for rub in rubs:
        for c in rub.criteria:
            if _R1_PATTERN.search(c.raw):
                evidence.append(EvidenceEntry(
                    file=rub.source, line=c.line, snippet=c.raw,
                ))
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence[:20],
            reasoning=(
                "Rubric criteria reference testing logic (/tests/, test.sh, "
                "verifier, etc.). The agent doesn't run those — grade only the trace."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="No rubric criteria reference testing logic.",
    )


# ============================================================================
# R-2: Rubrics must not reference metadata or instruction.md
# ============================================================================

_R2_PATTERN = re.compile(
    r"\b(?: task\.toml | instruction\.md | \[ ?metadata ?\] | "
    r"\[ ?verifier ?\] | \[ ?agent ?\] | metadata)\b",
    re.IGNORECASE | re.VERBOSE,
)


def check_r2(ctx: RunContext) -> CheckResult:
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "no metadata/instruction references")

    evidence: list[EvidenceEntry] = []
    for rub in rubs:
        for c in rub.criteria:
            if _R2_PATTERN.search(c.raw):
                evidence.append(EvidenceEntry(
                    file=rub.source, line=c.line, snippet=c.raw,
                ))
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence[:20],
            reasoning=(
                "Rubric criteria reference task.toml, instruction.md, or metadata "
                "blocks. The agent has no access to those — never reference them."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="No rubric criteria reference metadata or instruction.md.",
    )


# ============================================================================
# R-3: ≥3 negative penalties
# ============================================================================

def check_r3(ctx: RunContext) -> CheckResult:
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "≥3 negative penalties")

    if ctx.r3_mode == "per-milestone":
        # Each milestone rubric must individually have ≥3 negatives
        evidence: list[EvidenceEntry] = []
        for rub in rubs:
            negs = [c for c in rub.criteria if c.score is not None and c.score < 0]
            if len(negs) < 3:
                evidence.append(EvidenceEntry(
                    file=rub.source, line=None,
                    snippet=f"only {len(negs)} negative criteria (needs ≥3)",
                ))
        if evidence:
            return CheckResult(
                verdict=Verdict.FAIL,
                evidence=evidence,
                reasoning=(
                    f"Per-milestone R-3 mode: each rubric needs ≥3 negative criteria. "
                    f"{len(evidence)} rubric(s) fall short."
                ),
            )
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning=f"All {len(rubs)} rubric(s) contain ≥3 negative criteria.",
        )

    # default: aggregate
    total_neg = sum(
        1 for rub in rubs for c in rub.criteria
        if c.score is not None and c.score < 0
    )
    if total_neg >= 3:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning=f"Aggregate negative criteria across all rubrics: {total_neg} (≥3).",
        )
    return CheckResult(
        verdict=Verdict.FAIL,
        reasoning=(
            f"Aggregate negative criteria across all rubrics: {total_neg} (need ≥3). "
            "(R-3 mode: aggregate; pass --r3-mode=per-milestone for stricter check.)"
        ),
    )


# ============================================================================
# R-4: Scores ∈ {±1, ±2, ±3, ±5}
# ============================================================================

def check_r4(ctx: RunContext) -> CheckResult:
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "valid score enumeration")

    evidence: list[EvidenceEntry] = []
    for rub in rubs:
        for c in rub.criteria:
            if not c.well_formed:
                # Format error caught by R-5; skip here
                continue
            if not is_valid_score(c.score):
                evidence.append(EvidenceEntry(
                    file=rub.source, line=c.line,
                    snippet=f"{c.raw} → score={c.score} (must be ±1, ±2, ±3, or ±5)",
                ))
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence[:20],
            reasoning=(
                f"Found {len(evidence)} rubric criterion(s) with invalid scores. "
                "Allowed scores: 1, 2, 3, 5, -1, -2, -3, -5."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="All rubric scores are within the allowed enumeration {±1, ±2, ±3, ±5}.",
    )


# ============================================================================
# R-5: Block format correct
# ============================================================================

def check_r5(ctx: RunContext) -> CheckResult:
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "block format")

    evidence: list[EvidenceEntry] = []
    total_criteria = 0
    for rub in rubs:
        for c in rub.criteria:
            total_criteria += 1
            if not c.well_formed:
                evidence.append(EvidenceEntry(
                    file=rub.source, line=c.line,
                    snippet=c.raw,
                ))
    if total_criteria == 0:
        return CheckResult(
            verdict=Verdict.FAIL,
            reasoning="Rubric block(s) located but contain no `Agent ..., <score>` lines.",
        )
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence[:20],
            reasoning=(
                f"Found {len(evidence)}/{total_criteria} malformed rubric line(s). "
                "Each line must start with `Agent`, end with `, <score>`, and use a "
                "valid score from {±1, ±2, ±3, ±5}."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning=f"All {total_criteria} rubric criteria are correctly formatted.",
    )


# ============================================================================
# R-7: ≥1 negative criterion per milestone (Medium)
# ============================================================================

def check_r7(ctx: RunContext) -> CheckResult:
    if not ctx.is_milestone:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="Non-milestone task; R-7 (per-milestone negative criteria) does not apply.",
        )
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "≥1 negative per milestone")

    evidence: list[EvidenceEntry] = []
    for rub in rubs:
        negs = [c for c in rub.criteria if c.score is not None and c.score < 0]
        if not negs:
            evidence.append(EvidenceEntry(
                file=rub.source, line=None,
                snippet=f"milestone_{rub.milestone_index}: 0 negative criteria",
            ))
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence,
            reasoning=(
                f"{len(evidence)} milestone rubric(s) have no negative criteria. "
                "Each milestone rubric must contain at least one."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="Every milestone rubric has at least one negative criterion.",
    )


# ============================================================================
# R-10: No oracle / NOP mentions in rubric
# ============================================================================

_R10_PATTERN = re.compile(r"\b(?: oracle | nop | no[-_\s]?op )\b", re.IGNORECASE | re.VERBOSE)


def check_r10(ctx: RunContext) -> CheckResult:
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "no oracle/NOP mentions")

    evidence: list[EvidenceEntry] = []
    for rub in rubs:
        for c in rub.criteria:
            if _R10_PATTERN.search(c.raw):
                evidence.append(EvidenceEntry(
                    file=rub.source, line=c.line, snippet=c.raw,
                ))
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence[:20],
            reasoning=(
                "Rubric mentions oracle / NOP runs. The agent has no context "
                "about those — never reference them."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="No rubric criteria mention oracle or NOP.",
    )


# ============================================================================
# R-11: Per-milestone points 10–40 (sum of |score|)
# ============================================================================

def check_r11(ctx: RunContext) -> CheckResult:
    if not ctx.is_milestone:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="Non-milestone task; R-11 (per-milestone point cap) does not apply.",
        )
    rubs = _get_rubrics(ctx)
    if not rubs:
        return _no_rubric_result(Verdict.NEEDS_REVIEW, "per-milestone point range 10–40")

    evidence: list[EvidenceEntry] = []
    for rub in rubs:
        total = sum(abs(c.score) for c in rub.criteria if c.score is not None)
        if total < 10 or total > 40:
            evidence.append(EvidenceEntry(
                file=rub.source, line=None,
                snippet=f"milestone_{rub.milestone_index}: total points = {total} (must be 10–40)",
            ))
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence,
            reasoning=(
                f"{len(evidence)} milestone rubric(s) have point totals outside 10–40. "
                "Sum of |score| per milestone must be in [10, 40]."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="All milestone rubric point totals are within 10–40.",
    )
