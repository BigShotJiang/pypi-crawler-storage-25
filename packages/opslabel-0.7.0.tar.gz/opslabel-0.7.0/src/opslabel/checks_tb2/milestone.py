"""Milestone Tasks checks: M-1, M-2, M-3, M-4.

Per audit C-2: M-3 is python_partial_human. Existence is Python; scope is human.
"""
from __future__ import annotations

import re
from pathlib import Path

from ..tb2_lint.types import CheckResult, EvidenceEntry, RunContext, Verdict


# ============================================================================
# M-1: steps/ directory layout (only applies to milestone tasks)
# ============================================================================

def check_m1(ctx: RunContext) -> CheckResult:
    if not ctx.is_milestone:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="Non-milestone task; M-1 (steps/ layout) does not apply.",
        )
    issues: list[EvidenceEntry] = []
    steps_dir = ctx.task_dir / "steps"
    if not steps_dir.is_dir():
        issues.append(EvidenceEntry(file="steps/", snippet="missing"))
    else:
        # Each milestone_N/ subdir must contain instruction.md, tests/, solution/
        for idx in range(1, ctx.num_milestones + 1):
            mdir = steps_dir / f"milestone_{idx}"
            if not mdir.is_dir():
                issues.append(EvidenceEntry(
                    file=f"steps/milestone_{idx}/", snippet="missing",
                ))
                continue
            for sub in ("instruction.md", "tests", "solution"):
                p = mdir / sub
                expected = "directory" if sub in ("tests", "solution") else "file"
                ok = p.is_dir() if expected == "directory" else p.is_file()
                if not ok:
                    issues.append(EvidenceEntry(
                        file=f"steps/milestone_{idx}/{sub}", snippet=f"missing {expected}",
                    ))

    # Forbidden root-level files for milestone tasks
    for forbidden in ("instruction.md", "tests", "solution"):
        p = ctx.task_dir / forbidden
        if p.exists():
            issues.append(EvidenceEntry(
                file=forbidden, snippet="root-level forbidden in milestone tasks",
            ))
    for p in ctx.task_dir.glob("milestone_*.md"):
        if p.is_file():
            issues.append(EvidenceEntry(
                file=p.name, snippet="root-level milestone_x.md not allowed",
            ))

    if issues:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=issues,
            reasoning=(
                f"Milestone task layout incomplete or has forbidden root files: "
                f"{len(issues)} issue(s)."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="steps/milestone_N/ layout matches spec for all milestones.",
    )


# ============================================================================
# M-2: [[steps]] count == number_of_milestones, names match
# ============================================================================

def check_m2(ctx: RunContext) -> CheckResult:
    if not ctx.is_milestone:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="Non-milestone task; M-2 ([[steps]] declarations) does not apply.",
        )
    if ctx.task_toml is None:
        return CheckResult(
            verdict=Verdict.FAIL,
            reasoning="task.toml missing or unparseable.",
        )

    steps = ctx.task_toml.get("steps")
    issues: list[EvidenceEntry] = []
    if not isinstance(steps, list) or not steps:
        return CheckResult(
            verdict=Verdict.FAIL,
            reasoning="[[steps]] array missing or empty (required for milestone tasks).",
        )
    if len(steps) != ctx.num_milestones:
        issues.append(EvidenceEntry(
            file="task.toml",
            snippet=(
                f"[[steps]] count = {len(steps)}, but [metadata].number_of_milestones "
                f"= {ctx.num_milestones}. They must match."
            ),
        ))
    for i, step in enumerate(steps, 1):
        if not isinstance(step, dict):
            issues.append(EvidenceEntry(
                file="task.toml", snippet=f"[[steps]][{i-1}] is not a table",
            ))
            continue
        name = step.get("name")
        if not isinstance(name, str):
            issues.append(EvidenceEntry(
                file="task.toml", snippet=f"[[steps]][{i-1}].name missing",
            ))
            continue
        if not re.fullmatch(r"milestone_\d+", name):
            issues.append(EvidenceEntry(
                file="task.toml",
                snippet=f"[[steps]][{i-1}].name = {name!r} (must match `milestone_<N>`)",
            ))
        # Each step must include [steps.agent].timeout_sec and [steps.verifier].timeout_sec
        ag = step.get("agent") or {}
        if not isinstance(ag, dict) or not isinstance(ag.get("timeout_sec"), (int, float)):
            issues.append(EvidenceEntry(
                file="task.toml",
                snippet=f"[[steps]][{i-1}].agent.timeout_sec missing or not numeric",
            ))
        ver = step.get("verifier") or {}
        if not isinstance(ver, dict) or not isinstance(ver.get("timeout_sec"), (int, float)):
            issues.append(EvidenceEntry(
                file="task.toml",
                snippet=f"[[steps]][{i-1}].verifier.timeout_sec missing or not numeric",
            ))

    if issues:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=issues,
            reasoning=(
                "[[steps]] array doesn't match milestone count, has malformed names, "
                "or is missing per-step agent/verifier timeouts. "
                "(Each step must include [steps.agent] with timeout_sec and "
                "[steps.verifier] with timeout_sec.)"
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning=(
            f"[[steps]] array has {ctx.num_milestones} block(s) with valid names "
            "and per-step agent/verifier timeouts."
        ),
    )


# ============================================================================
# M-3: Each milestone has solveN.sh + solve.sh wrapper
#       (existence Python; scope check is human → NEEDS_REVIEW per C-2)
# ============================================================================

def check_m3(ctx: RunContext) -> CheckResult:
    if not ctx.is_milestone:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="Non-milestone task; M-3 (per-milestone solveN.sh) does not apply.",
        )
    missing: list[EvidenceEntry] = []
    for idx in range(1, ctx.num_milestones + 1):
        sol = ctx.task_dir / "steps" / f"milestone_{idx}" / "solution"
        if not sol.is_dir():
            missing.append(EvidenceEntry(
                file=f"steps/milestone_{idx}/solution/",
                snippet="solution/ directory missing",
            ))
            continue
        if not (sol / f"solve{idx}.sh").is_file():
            missing.append(EvidenceEntry(
                file=f"steps/milestone_{idx}/solution/solve{idx}.sh",
                snippet="missing per-milestone oracle solver",
            ))
        if not (sol / "solve.sh").is_file():
            missing.append(EvidenceEntry(
                file=f"steps/milestone_{idx}/solution/solve.sh",
                snippet="missing solve.sh wrapper",
            ))

    if missing:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=missing,
            reasoning=(
                f"Missing {len(missing)} required solveN.sh / solve.sh file(s). "
                "Each milestone needs both `solveN.sh` (scoped solver) and "
                "`solve.sh` (wrapper that invokes it)."
            ),
        )
    # Existence passed → reviewer must verify scope.
    return CheckResult(
        verdict=Verdict.NEEDS_REVIEW,
        reasoning=(
            f"All {ctx.num_milestones} milestone(s) have solveN.sh + solve.sh wrapper. "
            "Existence verified by Python; scope check is human-only."
        ),
        auditor_notes=(
            "Reviewer must verify each solveN.sh is independently scoped to its "
            "milestone (does NOT include cumulative work from earlier milestones). "
            "Per PDF: 'The solveN.sh files must be independently scoped to the "
            "milestone they correspond to.'"
        ),
    )


# ============================================================================
# M-4: Each milestone has test_mN.py with TestMilestoneN class + test.sh runner
# ============================================================================

def check_m4(ctx: RunContext) -> CheckResult:
    if not ctx.is_milestone:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="Non-milestone task; M-4 (per-milestone test_mN.py) does not apply.",
        )
    issues: list[EvidenceEntry] = []
    for idx in range(1, ctx.num_milestones + 1):
        tdir = ctx.task_dir / "steps" / f"milestone_{idx}" / "tests"
        if not tdir.is_dir():
            issues.append(EvidenceEntry(
                file=f"steps/milestone_{idx}/tests/",
                snippet="tests/ directory missing",
            ))
            continue
        # test.sh runner
        if not (tdir / "test.sh").is_file():
            issues.append(EvidenceEntry(
                file=f"steps/milestone_{idx}/tests/test.sh",
                snippet="missing test.sh runner",
            ))
        # test_mN.py with TestMilestoneN class
        tm_file = tdir / f"test_m{idx}.py"
        if not tm_file.is_file():
            issues.append(EvidenceEntry(
                file=f"steps/milestone_{idx}/tests/test_m{idx}.py",
                snippet=f"missing test_m{idx}.py",
            ))
            continue
        try:
            text = tm_file.read_text(errors="replace")
        except OSError:
            issues.append(EvidenceEntry(
                file=str(tm_file.relative_to(ctx.task_dir)),
                snippet="could not read file",
            ))
            continue
        if not re.search(rf"\bclass\s+TestMilestone{idx}\b", text):
            issues.append(EvidenceEntry(
                file=f"steps/milestone_{idx}/tests/test_m{idx}.py",
                snippet=f"file present but missing `class TestMilestone{idx}`",
            ))

    if issues:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=issues,
            reasoning=(
                f"{len(issues)} milestone test issue(s). "
                "(solve1.sh corresponds to test_m1.py and so on — each milestone "
                "needs its own test_mN.py with TestMilestoneN class plus a test.sh "
                "runner that produces /logs/verifier/reward.txt.)"
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning=(
            f"All {ctx.num_milestones} milestone(s) have test_mN.py with "
            "TestMilestoneN class + test.sh runner."
        ),
    )
