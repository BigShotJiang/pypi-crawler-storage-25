"""Verifier checks: V-3, V-4."""
from __future__ import annotations

import re
from pathlib import Path

from ..tb2_lint.scanners import web_fetch
from ..tb2_lint.types import CheckResult, EvidenceEntry, RunContext, Verdict


# ============================================================================
# V-3: No web fetches in tests/
# ============================================================================

def check_v3(ctx: RunContext) -> CheckResult:
    hits = web_fetch.scan_verifier(ctx.task_dir)
    if not hits:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="No non-package-manager web fetches detected in tests/.",
        )
    evidence = [
        EvidenceEntry(file=h.file, line=h.line, snippet=f"{h.reason}: {h.snippet}")
        for h in hits[:20]
    ]
    return CheckResult(
        verdict=Verdict.FAIL,
        evidence=evidence,
        reasoning=(
            f"Found {len(hits)} potential web fetch(es) in tests/. Verifiers may "
            "install pinned package dependencies, but must not download arbitrary "
            "content from the internet."
        ),
    )


# ============================================================================
# V-4: Binary rewards (0/1) only
# ============================================================================

# Match `echo <value> > .../reward.txt`, `printf "...%s..." <value> > .../reward.txt`,
# Python `f.write(<expr>)` to a reward.txt-bound file.

_SHELL_REWARD_RE = re.compile(
    r"""
    (?: echo | printf | tee )           # any of the three
    \s+ (?P<value>.+?)                  # the value being written
    \s* > >? \s*
    [^|;&\n]*                            # rest of the redirect target
    /reward\.txt
    """,
    re.VERBOSE | re.IGNORECASE,
)

# Python: f.write(...) where f opens reward.txt; or open("reward.txt").write(...)
_PY_OPEN_REWARD_RE = re.compile(
    r"""
    open \s* \(
      \s* (?: ['\"]) [^'\"]*reward\.txt ['\"]   # path arg containing reward.txt
      [^)]*
    \)
    """,
    re.VERBOSE,
)

_PY_PATHLIB_WRITE_RE = re.compile(
    r"""
    (?: Path \( [^)]* (?:reward\.txt) [^)]* \) | reward_path | reward_txt )
    \s* \. \s* write_text \s* \( \s*
    (?P<value>[^,)]+)
    """,
    re.VERBOSE,
)

# What does a value need to look like to count as a literal binary write?
# Acceptable: "1", "0", '1', '0', `1`, `0`, single-token bare 0/1.
_LITERAL_BINARY_RE = re.compile(r"^['\"]?[01]['\"]?$")


def _classify_value(val: str) -> tuple[bool, str]:
    """Return (is_known_binary, reason)."""
    s = val.strip().rstrip(";").strip()
    # Strip trailing > append redirect leftovers
    s = s.split("|")[0].strip()
    s = s.split(">")[0].strip()
    s = s.strip("()")
    if _LITERAL_BINARY_RE.match(s):
        return True, "literal 0/1"
    return False, f"non-literal value: `{s}`"


def check_v4(ctx: RunContext) -> CheckResult:
    tests = ctx.task_dir / "tests"
    if not tests.is_dir():
        # On milestone tasks, tests/ lives under steps/milestone_N/
        if ctx.is_milestone:
            tests_dirs = [
                (ctx.task_dir / "steps" / f"milestone_{i}" / "tests")
                for i in range(1, ctx.num_milestones + 1)
            ]
            tests_dirs = [t for t in tests_dirs if t.is_dir()]
            if not tests_dirs:
                return CheckResult(
                    verdict=Verdict.FAIL,
                    reasoning="No tests/ directory found under any milestone.",
                )
        else:
            return CheckResult(
                verdict=Verdict.FAIL,
                reasoning="No tests/ directory found.",
            )
    else:
        tests_dirs = [tests]

    failures: list[EvidenceEntry] = []
    found_any_write = False

    for td in tests_dirs:
        for p in td.rglob("*"):
            if not p.is_file():
                continue
            if p.suffix not in (".sh", ".bash", ".py"):
                continue
            try:
                text = p.read_text(errors="replace")
            except OSError:
                continue
            try:
                rel = str(p.relative_to(ctx.task_dir))
            except ValueError:
                rel = str(p)

            # Shell-style writes
            for ln_idx, raw in enumerate(text.splitlines(), 1):
                for m in _SHELL_REWARD_RE.finditer(raw):
                    found_any_write = True
                    val = m.group("value")
                    is_binary, why = _classify_value(val)
                    if not is_binary:
                        failures.append(EvidenceEntry(
                            file=rel, line=ln_idx,
                            snippet=f"{raw.strip()} → {why}",
                        ))

            # Python-style writes
            if p.suffix == ".py":
                # Track which `open(...reward.txt...)` produces a file handle that
                # then gets `.write(...)` called. Heuristic: scan for paired patterns.
                for ln_idx, raw in enumerate(text.splitlines(), 1):
                    if "reward.txt" in raw and (
                        ".write(" in raw or "write_text(" in raw
                    ):
                        found_any_write = True
                        # Attempt to extract the written value
                        m = re.search(r"\.write(?:_text)?\(\s*([^)]+?)\s*\)", raw)
                        if m:
                            val = m.group(1)
                            is_binary, why = _classify_value(val)
                            if not is_binary:
                                failures.append(EvidenceEntry(
                                    file=rel, line=ln_idx,
                                    snippet=f"{raw.strip()} → {why}",
                                ))

    if not found_any_write:
        return CheckResult(
            verdict=Verdict.NEEDS_REVIEW,
            reasoning="No reward.txt write detected in tests/. The verifier may write through indirection.",
            auditor_notes=(
                "Reviewer must confirm reward.txt is always written, with value ∈ {0, 1}, "
                "in both pass and fail paths."
            ),
        )
    if failures:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=failures[:20],
            reasoning=(
                f"Found {len(failures)} non-binary reward write(s). "
                "Verifiers must write only literal `0` or `1` to reward.txt."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="All detected reward.txt writes use literal 0/1.",
    )
