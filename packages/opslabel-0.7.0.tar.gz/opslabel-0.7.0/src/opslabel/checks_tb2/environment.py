"""Environment checks: E-1, E-2, E-3, E-5, E-6, E-7, E-8, E-9."""
from __future__ import annotations

import re
import shlex
from pathlib import Path

import yaml

from ..tb2_lint.parsers import compose, dockerfile, package_json, pyproject
from ..tb2_lint.scanners import dangerous_ops, web_fetch
from ..tb2_lint.types import CheckResult, EvidenceEntry, RunContext, Verdict

# Floating tags that are not specific versions (E-8)
_FLOATING_TAGS = {
    "latest", "edge", "stable", "nightly", "dev", "main", "master",
    "rolling", "current",
}

# Reserved harbor mount targets (E-6)
_RESERVED_MOUNTS = ("/logs/artifacts/", "/logs/verifier/", "/tests/", "/solution/",
                    "/logs/artifacts", "/logs/verifier", "/tests", "/solution")


# ============================================================================
# E-1: No web fetches in environment
# ============================================================================

def check_e1(ctx: RunContext) -> CheckResult:
    hits = web_fetch.scan_environment(ctx.task_dir)
    if not hits:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="No non-package-manager web fetches detected in environment/.",
        )
    evidence = [
        EvidenceEntry(file=h.file, line=h.line, snippet=f"{h.reason}: {h.snippet}")
        for h in hits[:20]
    ]
    return CheckResult(
        verdict=Verdict.FAIL,
        evidence=evidence,
        reasoning=(
            f"Found {len(hits)} potential web fetch(es) in environment/. Network "
            "access during environment build is forbidden except for package-"
            "manager installs (apt, pip, npm, etc.)."
        ),
    )


# ============================================================================
# E-2: All non-apt dependencies use pinned versions
# ============================================================================

# pip pin requires `==<version>` (PEP 440). Range / open / git+ → unpinned.
_PIP_PIN_RE = re.compile(r"==\s*[\w.\-+!]+")

# npm pin requires exact version, no caret/tilde/star/x/range
_NPM_PIN_OK = re.compile(r"^\d+\.\d+\.\d+(?:[-+][\w.]+)?$")

# Cargo pin requires `=<version>` prefix
_CARGO_PIN_RE = re.compile(r"^\s*=\s*\d+")


def _parse_pip_argv(line: str) -> list[str]:
    """Tokenize a pip-install command, skipping flags. Returns the package
    spec strings only. Auditor C-4 — fixes the regex-on-tokens bug."""
    try:
        toks = shlex.split(line)
    except ValueError:
        return []
    if not toks:
        return []
    # Find "pip" then "install"
    try:
        pip_idx = next(i for i, t in enumerate(toks) if t.endswith("pip") or t == "pip3")
    except StopIteration:
        return []
    if pip_idx + 1 >= len(toks) or toks[pip_idx + 1] != "install":
        return []
    pkgs: list[str] = []
    i = pip_idx + 2
    skip_value_flags = {"--index-url", "-i", "--extra-index-url",
                         "-c", "--constraint", "-r", "--requirement",
                         "--target", "-t", "--prefix", "--root",
                         "--cache-dir", "--user"}
    while i < len(toks):
        t = toks[i]
        if t in ("-U", "--upgrade", "--no-deps", "--no-cache-dir", "--quiet", "-q",
                 "--user", "--break-system-packages"):
            i += 1
            continue
        if t in skip_value_flags:
            i += 2
            continue
        if t.startswith("-"):
            # Unknown flag; assume it takes no value (safer than swallowing the next pkg)
            i += 1
            continue
        # Positional package spec
        pkgs.append(t)
        i += 1
    return pkgs


def _is_pip_spec_pinned(spec: str) -> bool:
    s = spec.strip()
    if not s:
        return False
    # `-r requirements.txt` is handled above; if it slipped through, treat as not-a-spec
    if s.startswith("-"):
        return False
    if s.startswith("git+") or "://" in s:
        return False     # web fetch (separate rule); definitely not pinned
    return bool(_PIP_PIN_RE.search(s))


def check_e2(ctx: RunContext) -> CheckResult:
    """Walk every supported manifest under environment/ + solution/ + tests/
    and flag unpinned deps. apt is exempt per PDF (handled in E-7)."""
    failures: list[EvidenceEntry] = []

    for root_label in ("environment", "solution", "tests"):
        root = ctx.task_dir / root_label
        if not root.is_dir():
            continue
        failures.extend(_scan_python_manifests(root, ctx.task_dir))
        failures.extend(_scan_node_manifests(root, ctx.task_dir))
        failures.extend(_scan_cargo(root, ctx.task_dir))
        failures.extend(_scan_gemfile(root, ctx.task_dir))
        failures.extend(_scan_environment_yml(root, ctx.task_dir))
        failures.extend(_scan_composer(root, ctx.task_dir))
        failures.extend(_scan_go_mod(root, ctx.task_dir))
        failures.extend(_scan_pip_in_shell_or_dockerfile(root, ctx.task_dir))

    if not failures:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="All scanned dependency manifests use pinned versions.",
        )
    return CheckResult(
        verdict=Verdict.FAIL,
        evidence=failures[:30],
        reasoning=(
            f"Found {len(failures)} unpinned dependency reference(s). All non-apt "
            "deps must be pinned (`==X.Y.Z` for pip, exact `X.Y.Z` for npm, "
            "`= X.Y.Z` for Cargo, etc.)."
        ),
    )


def _rel(p: Path, base: Path) -> str:
    try:
        return str(p.relative_to(base))
    except ValueError:
        return str(p)


def _scan_python_manifests(root: Path, base: Path) -> list[EvidenceEntry]:
    hits: list[EvidenceEntry] = []
    # requirements*.txt anywhere under root
    for p in root.rglob("requirements*.txt"):
        if not p.is_file():
            continue
        try:
            for ln_idx, raw in enumerate(p.read_text(errors="replace").splitlines(), 1):
                line = raw.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                if not _is_pip_spec_pinned(line):
                    hits.append(EvidenceEntry(file=_rel(p, base), line=ln_idx, snippet=line))
        except OSError:
            pass

    # uv.lock / poetry.lock — locks are positive signals; skip flagging.

    # pyproject.toml
    for p in root.rglob("pyproject.toml"):
        if not p.is_file():
            continue
        pp = pyproject.parse(p)
        for spec in pyproject.project_dependencies(pp):
            if not _is_pip_spec_pinned(spec):
                hits.append(EvidenceEntry(
                    file=_rel(p, base), line=None, snippet=f"[project.dependencies] {spec}",
                ))
        for name, spec in pyproject.poetry_dependencies(pp):
            if spec in ("*", ""):
                hits.append(EvidenceEntry(
                    file=_rel(p, base), line=None,
                    snippet=f"[tool.poetry.dependencies] {name} = {spec or '<no version>'}",
                ))
            elif spec.startswith("^") or spec.startswith("~"):
                hits.append(EvidenceEntry(
                    file=_rel(p, base), line=None,
                    snippet=f"[tool.poetry.dependencies] {name} = {spec}",
                ))
    return hits


def _scan_node_manifests(root: Path, base: Path) -> list[EvidenceEntry]:
    hits: list[EvidenceEntry] = []
    for p in root.rglob("package.json"):
        if not p.is_file():
            continue
        pkg = package_json.parse(p)
        for section, name, spec in package_json.dependency_versions(pkg):
            s = spec.strip()
            if s.startswith("file:") or s.startswith("link:") or s.startswith("workspace:"):
                continue
            if s.startswith("git+") or "://" in s or s.startswith("github:"):
                hits.append(EvidenceEntry(
                    file=_rel(p, base), line=None,
                    snippet=f"{section}.{name}={spec} (git/url)",
                ))
                continue
            if not _NPM_PIN_OK.match(s):
                hits.append(EvidenceEntry(
                    file=_rel(p, base), line=None,
                    snippet=f"{section}.{name}={spec}",
                ))
    # bun.lock / bun.lockb / pnpm-lock.yaml are positive signals; skip.
    return hits


def _scan_cargo(root: Path, base: Path) -> list[EvidenceEntry]:
    hits: list[EvidenceEntry] = []
    for p in root.rglob("Cargo.toml"):
        if not p.is_file():
            continue
        # Cargo.lock alongside is the positive signal. If lock is present skip.
        if (p.parent / "Cargo.lock").is_file():
            continue
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        # Match lines under [dependencies], [dev-dependencies], [build-dependencies].
        in_deps = False
        for ln_idx, raw in enumerate(text.splitlines(), 1):
            s = raw.strip()
            if s.startswith("[") and s.endswith("]"):
                in_deps = s in ("[dependencies]", "[dev-dependencies]", "[build-dependencies]")
                continue
            if not in_deps or not s or s.startswith("#"):
                continue
            # Capture `name = "<version-spec>"` or `name = { version = "..." }`
            m = re.match(r"^([\w\-]+)\s*=\s*(.+?)\s*$", s)
            if not m:
                continue
            spec = m.group(2).strip().strip('"').strip("'")
            # If the spec is a table, find version inside
            if spec.startswith("{"):
                vm = re.search(r"version\s*=\s*\"([^\"]+)\"", spec)
                if not vm:
                    continue
                spec = vm.group(1)
            if not _CARGO_PIN_RE.match(" " + spec):
                hits.append(EvidenceEntry(
                    file=_rel(p, base), line=ln_idx, snippet=raw.strip(),
                ))
    return hits


def _scan_gemfile(root: Path, base: Path) -> list[EvidenceEntry]:
    hits: list[EvidenceEntry] = []
    for p in root.rglob("Gemfile"):
        if not p.is_file():
            continue
        if (p.parent / "Gemfile.lock").is_file():
            continue
        try:
            for ln_idx, raw in enumerate(p.read_text(errors="replace").splitlines(), 1):
                s = raw.strip()
                if not s.startswith("gem "):
                    continue
                # Pinned form: gem 'name', '1.2.3'
                if not re.search(r"['\"][\d.]+['\"]", s):
                    hits.append(EvidenceEntry(file=_rel(p, base), line=ln_idx, snippet=s))
        except OSError:
            pass
    return hits


def _scan_environment_yml(root: Path, base: Path) -> list[EvidenceEntry]:
    hits: list[EvidenceEntry] = []
    for name in ("environment.yml", "environment.yaml"):
        for p in root.rglob(name):
            if not p.is_file():
                continue
            try:
                data = yaml.safe_load(p.read_text(errors="replace"))
            except (OSError, yaml.YAMLError):
                continue
            if not isinstance(data, dict):
                continue
            deps = data.get("dependencies")
            if not isinstance(deps, list):
                continue
            for entry in deps:
                if isinstance(entry, str):
                    if "=" not in entry:
                        hits.append(EvidenceEntry(
                            file=_rel(p, base), line=None,
                            snippet=f"dependencies: {entry}",
                        ))
                elif isinstance(entry, dict):
                    pip = entry.get("pip")
                    if isinstance(pip, list):
                        for spec in pip:
                            if isinstance(spec, str) and not _is_pip_spec_pinned(spec):
                                hits.append(EvidenceEntry(
                                    file=_rel(p, base), line=None,
                                    snippet=f"pip: {spec}",
                                ))
    return hits


def _scan_composer(root: Path, base: Path) -> list[EvidenceEntry]:
    hits: list[EvidenceEntry] = []
    for p in root.rglob("composer.json"):
        if not p.is_file():
            continue
        if (p.parent / "composer.lock").is_file():
            continue
        try:
            import json as _json
            data = _json.loads(p.read_text(errors="replace"))
        except (OSError, ValueError):
            continue
        for section in ("require", "require-dev"):
            block = data.get(section) if isinstance(data, dict) else None
            if not isinstance(block, dict):
                continue
            for name, spec in block.items():
                if not isinstance(spec, str):
                    continue
                # Pinned: literal version (no ^ ~ * >= etc.)
                if re.search(r"[\^~*]|>=|<=|>|<|\|", spec):
                    hits.append(EvidenceEntry(
                        file=_rel(p, base), line=None, snippet=f"{section}.{name}={spec}",
                    ))
    return hits


def _scan_go_mod(root: Path, base: Path) -> list[EvidenceEntry]:
    """Go has built-in pinning, but `replace` directives can introduce
    unpinned local refs. We flag replace lines for human attention."""
    hits: list[EvidenceEntry] = []
    for p in root.rglob("go.mod"):
        if not p.is_file():
            continue
        try:
            for ln_idx, raw in enumerate(p.read_text(errors="replace").splitlines(), 1):
                s = raw.strip()
                if s.startswith("replace ") and "=>" in s:
                    # Replace directive — version on RHS may be unpinned local path
                    rhs = s.split("=>", 1)[1].strip()
                    if "/" in rhs and " " not in rhs:    # local-path replace, no version
                        hits.append(EvidenceEntry(file=_rel(p, base), line=ln_idx, snippet=s))
        except OSError:
            pass
    return hits


def _scan_pip_in_shell_or_dockerfile(root: Path, base: Path) -> list[EvidenceEntry]:
    """Scan Dockerfile RUN lines and *.sh files for unpinned `pip install <name>`."""
    hits: list[EvidenceEntry] = []
    candidates: list[Path] = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        nm = p.name.lower()
        if nm == "dockerfile" or nm.startswith("dockerfile."):
            candidates.append(p)
        elif p.suffix in (".sh", ".bash"):
            candidates.append(p)
    for p in candidates:
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        for ln_idx, raw in enumerate(text.splitlines(), 1):
            line = raw.strip()
            if "pip install" not in line and "pip3 install" not in line:
                continue
            if line.startswith("#"):
                continue
            specs = _parse_pip_argv(line)
            for spec in specs:
                if not _is_pip_spec_pinned(spec):
                    hits.append(EvidenceEntry(
                        file=_rel(p, base), line=ln_idx,
                        snippet=f"pip install ... {spec}",
                    ))
    return hits


# ============================================================================
# E-3: Does not use context from outside environment/
# ============================================================================

def check_e3(ctx: RunContext) -> CheckResult:
    env_dir = ctx.task_dir / "environment"
    if not env_dir.is_dir():
        return CheckResult(
            verdict=Verdict.FAIL,
            reasoning="environment/ directory not found.",
        )
    evidence: list[EvidenceEntry] = []

    # Dockerfile COPY/ADD with parent escape
    df = dockerfile.parse_dockerfile(env_dir / "Dockerfile")
    for instr in df:
        if instr.directive in ("COPY", "ADD"):
            # Drop any --from=stage / --chown=user flags so the source token
            # isn't accidentally one of those.
            tokens = [t for t in instr.args.split() if not t.startswith("--")]
            if len(tokens) < 2:
                continue
            # Last token is destination; everything else is source(s)
            sources = tokens[:-1]
            for src in sources:
                if src.startswith("/") or src.startswith(".."):
                    evidence.append(EvidenceEntry(
                        file="environment/Dockerfile", line=instr.line,
                        snippet=f"{instr.directive} {src} ... (escapes build context)",
                    ))

    # docker-compose context / volumes
    compose_path = compose.find_compose(ctx.task_dir)
    if compose_path is not None:
        data = compose.parse_compose(compose_path)
        if data is not None:
            for svc_name, svc in compose.services(data).items():
                if not isinstance(svc, dict):
                    continue
                build = svc.get("build")
                if isinstance(build, str):
                    if build.startswith("..") or build.startswith("/"):
                        evidence.append(EvidenceEntry(
                            file=_rel(compose_path, ctx.task_dir), line=None,
                            snippet=f"services.{svc_name}.build: {build}",
                        ))
                elif isinstance(build, dict):
                    bctx = build.get("context")
                    if isinstance(bctx, str) and (bctx.startswith("..") or bctx.startswith("/")):
                        evidence.append(EvidenceEntry(
                            file=_rel(compose_path, ctx.task_dir), line=None,
                            snippet=f"services.{svc_name}.build.context: {bctx}",
                        ))
                vols = svc.get("volumes")
                if isinstance(vols, list):
                    for v in vols:
                        src = _compose_volume_source(v)
                        if src and (src.startswith("..") or
                                    (src.startswith("/") and "/Users/" in src)):
                            evidence.append(EvidenceEntry(
                                file=_rel(compose_path, ctx.task_dir), line=None,
                                snippet=f"services.{svc_name}.volumes: {v}",
                            ))

    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence[:20],
            reasoning=(
                "Build context references files outside of environment/. "
                "All build inputs must live under environment/."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="All COPY/ADD sources and compose contexts stay within environment/.",
    )


def _compose_volume_source(v) -> str | None:
    if isinstance(v, str):
        # short form: "<src>:<dst>[:opts]"
        return v.split(":", 1)[0] if ":" in v else None
    if isinstance(v, dict):
        # long form: {type, source, target}
        s = v.get("source")
        return s if isinstance(s, str) else None
    return None


# ============================================================================
# E-5: No dangerous Dockerfile / compose ops
# ============================================================================

def check_e5(ctx: RunContext) -> CheckResult:
    paths: list[Path] = []
    env = ctx.task_dir / "environment"
    if env.is_dir():
        for nm in ("Dockerfile",):
            p = env / nm
            if p.is_file():
                paths.append(p)
        for nm in ("docker-compose.yaml", "docker-compose.yml", "compose.yaml", "compose.yml"):
            p = env / nm
            if p.is_file():
                paths.append(p)
    hits = dangerous_ops.scan_paths(paths, ctx.task_dir)
    if not hits:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="No dangerous Dockerfile / compose operations detected.",
        )
    evidence = [
        EvidenceEntry(file=h.file, line=h.line, snippet=f"{h.reason}: {h.snippet}")
        for h in hits[:20]
    ]
    return CheckResult(
        verdict=Verdict.FAIL,
        evidence=evidence,
        reasoning=(
            f"Found {len(hits)} dangerous operation(s). The Dockerfile must not "
            "use --privileged, mount the docker socket, share host namespaces, "
            "disable seccomp/AppArmor, or grant elevated capabilities."
        ),
    )


# ============================================================================
# E-6: Compose volumes do not collide with reserved harbor mounts
# ============================================================================

def check_e6(ctx: RunContext) -> CheckResult:
    cpath = compose.find_compose(ctx.task_dir)
    if cpath is None:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="No docker-compose.yaml — no reserved-mount collision possible.",
        )
    data = compose.parse_compose(cpath)
    if data is None:
        return CheckResult(
            verdict=Verdict.NEEDS_REVIEW,
            reasoning=f"Could not parse {_rel(cpath, ctx.task_dir)}.",
            auditor_notes="Reviewer must manually inspect the compose file's volume mounts.",
        )
    evidence: list[EvidenceEntry] = []
    for svc_name, vol in compose.iter_volumes(data):
        target = _compose_volume_target(vol)
        if not target:
            continue
        norm = target.rstrip("/") + "/"
        for reserved in _RESERVED_MOUNTS:
            r = reserved.rstrip("/") + "/"
            if norm == r or norm.startswith(r):
                evidence.append(EvidenceEntry(
                    file=_rel(cpath, ctx.task_dir), line=None,
                    snippet=f"services.{svc_name}: volume target {target}",
                ))
                break
    if evidence:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=evidence,
            reasoning=(
                "Compose mounts collide with reserved harbor paths "
                "(/logs/artifacts/, /logs/verifier/, /tests/, /solution/)."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="No compose volumes target reserved harbor mount paths.",
    )


def _compose_volume_target(v) -> str | None:
    if isinstance(v, str):
        parts = v.split(":")
        return parts[1] if len(parts) >= 2 else None
    if isinstance(v, dict):
        t = v.get("target")
        return t if isinstance(t, str) else None
    return None


# ============================================================================
# E-7: Apt package versions pinned (Low)
# ============================================================================

_APT_LINE_RE = re.compile(
    r"\bapt(?:-get)?\s+install\b([^\n]*)", re.IGNORECASE,
)
_APT_FLAGS = re.compile(r"^-")


def check_e7(ctx: RunContext) -> CheckResult:
    df = dockerfile.parse_dockerfile(ctx.task_dir / "environment" / "Dockerfile")
    unpinned: list[EvidenceEntry] = []
    for instr in df:
        if instr.directive != "RUN":
            continue
        for m in _APT_LINE_RE.finditer(instr.args):
            tail = m.group(1)
            try:
                tokens = shlex.split(tail) if tail.strip() else []
            except ValueError:
                tokens = []
            for tok in tokens:
                # Shell separator → end of the apt install command. Anything
                # after this is a different command (e.g. `&& rm -rf ...`).
                if tok in ("&&", "||", ";", "|"):
                    break
                if _APT_FLAGS.match(tok):
                    continue
                # `pkg=version` → pinned
                if "=" in tok:
                    continue
                # heuristic: package names are alnum + . + - + _; reject anything else
                if not re.match(r"^[A-Za-z0-9][A-Za-z0-9._\-+]*$", tok):
                    continue
                unpinned.append(EvidenceEntry(
                    file="environment/Dockerfile", line=instr.line,
                    snippet=f"apt install: {tok} (no version)",
                ))
    if unpinned:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=unpinned[:20],
            reasoning=(
                f"Found {len(unpinned)} unpinned apt package(s). "
                "Low severity — advisory only; pinning is nice-to-have."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="All apt-installed packages are pinned (or no apt installs found).",
    )


# ============================================================================
# E-8: Specific image tag (Low)
# ============================================================================

def check_e8(ctx: RunContext) -> CheckResult:
    issues: list[EvidenceEntry] = []
    df = dockerfile.parse_dockerfile(ctx.task_dir / "environment" / "Dockerfile")
    for instr in df:
        if instr.directive != "FROM":
            continue
        # FROM may have a "AS stage" suffix
        toks = instr.args.split()
        if not toks:
            continue
        ref = toks[0]
        if "@" in ref:
            continue                          # digest pin: always OK
        if ":" not in ref:
            issues.append(EvidenceEntry(
                file="environment/Dockerfile", line=instr.line,
                snippet=f"FROM {ref} (no tag → defaults to :latest)",
            ))
            continue
        tag = ref.rsplit(":", 1)[1].strip()
        if tag.lower() in _FLOATING_TAGS:
            issues.append(EvidenceEntry(
                file="environment/Dockerfile", line=instr.line,
                snippet=f"FROM {ref} (floating tag '{tag}')",
            ))
        elif re.fullmatch(r"\d+", tag):
            # Major-only tag like `python:3` is floating
            issues.append(EvidenceEntry(
                file="environment/Dockerfile", line=instr.line,
                snippet=f"FROM {ref} (major-only tag, floating)",
            ))

    cpath = compose.find_compose(ctx.task_dir)
    if cpath is not None:
        data = compose.parse_compose(cpath)
        if isinstance(data, dict):
            for svc_name, svc in compose.services(data).items():
                if not isinstance(svc, dict):
                    continue
                img = svc.get("image")
                if not isinstance(img, str):
                    continue
                if "@" in img:
                    continue
                if ":" not in img:
                    issues.append(EvidenceEntry(
                        file=_rel(cpath, ctx.task_dir), line=None,
                        snippet=f"services.{svc_name}.image: {img} (no tag)",
                    ))
                    continue
                tag = img.rsplit(":", 1)[1].strip().lower()
                if tag in _FLOATING_TAGS or re.fullmatch(r"\d+", tag):
                    issues.append(EvidenceEntry(
                        file=_rel(cpath, ctx.task_dir), line=None,
                        snippet=f"services.{svc_name}.image: {img} (floating tag)",
                    ))

    if issues:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=issues,
            reasoning="Base images use floating tags. Pin to a specific version like `python:3.11-slim`.",
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="All base images use specific version tags or digest pins.",
    )


# ============================================================================
# E-9: No heredocs in Dockerfile (Low)
# ============================================================================

# Auditor m-4 — also catch double-quoted heredoc terminators.
_HEREDOC_RE = re.compile(r"<<-?(['\"])?\w+\1?")


def check_e9(ctx: RunContext) -> CheckResult:
    df = dockerfile.parse_dockerfile(ctx.task_dir / "environment" / "Dockerfile")
    issues: list[EvidenceEntry] = []
    for instr in df:
        if instr.directive in ("RUN", "COPY", "ADD", "ENTRYPOINT", "CMD"):
            for m in _HEREDOC_RE.finditer(instr.args):
                issues.append(EvidenceEntry(
                    file="environment/Dockerfile", line=instr.line,
                    snippet=f"{instr.directive} {m.group(0)} ...",
                ))
                break
    if issues:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=issues,
            reasoning="Dockerfile uses heredoc syntax. Move embedded content into separate files.",
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="No heredocs detected in Dockerfile.",
    )
