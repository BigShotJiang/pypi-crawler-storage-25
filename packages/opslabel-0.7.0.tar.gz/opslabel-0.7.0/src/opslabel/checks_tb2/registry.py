"""Registry of all check specs.

47 criteria total:
  - 31 deterministic (30 python_full + 1 python_partial_human via M-3)
  - 16 human_only — surfaced as reminders; require human judgement

Severity (per the reviewer-checklist PDF): 34 H + 8 M + 5 L = 47.

The LLM tier is intentionally absent from this build. Every criterion that
benefits from semantic judgement (I-4, V-1, V-2, R-9, TM-3, M-5, O-3, V-5,
V-6, R-6, R-8) is a HUMAN_ONLY reminder — the human reviewer evaluates them.

For HUMAN_ONLY entries, `reasoning` carries the verbatim PDF rule (sourced
from the reviewer-checklist audit report) and `auditor_notes` carries a
brief 'what to look for' hint. The criterion `name` field matches the
canonical PDF heading.
"""
from __future__ import annotations

from ..tb2_lint.types import CheckResult, CheckSpec, Severity, Tier, Verdict

from . import (
    environment,
    instruction,
    metadata,
    milestone,
    oracle,
    rubric,
    structure,
    verifier,
)


def _human_only(*, rule: str, hint: str):
    """Build a check function that always returns HUMAN_ONLY.

    `rule` becomes the reasoning shown to the reviewer (verbatim PDF text).
    `hint` is a brief 'what to look for' note attached as auditor_notes.
    """
    def _fn(_ctx) -> CheckResult:
        return CheckResult(
            verdict=Verdict.HUMAN_ONLY,
            reasoning=rule,
            auditor_notes=hint,
        )
    return _fn


CHECK_SPECS: list[CheckSpec] = [
    # --- Instruction Prompt — deterministic (3) --------------------------- #
    CheckSpec("I-6", "Instruction Prompt", "Instruction must use absolute paths",
              Severity.HIGH, Tier.PYTHON_FULL, instruction.check_i6),
    CheckSpec("I-7", "Instruction Prompt", "Instruction.md does not contain a canary string",
              Severity.MEDIUM, Tier.PYTHON_FULL, instruction.check_i7),
    CheckSpec("I-8", "Instruction Prompt", "Instruction.md does not contain the task name",
              Severity.MEDIUM, Tier.PYTHON_FULL, instruction.check_i8),

    # --- Environment — deterministic (8) ---------------------------------- #
    CheckSpec("E-1", "Environment", "Dockerfile / build scripts do not grab content from the web",
              Severity.HIGH, Tier.PYTHON_FULL, environment.check_e1),
    CheckSpec("E-2", "Environment", "All non-apt dependencies use pinned versions",
              Severity.HIGH, Tier.PYTHON_FULL, environment.check_e2),
    CheckSpec("E-3", "Environment", "Does not use context from outside environment/",
              Severity.HIGH, Tier.PYTHON_FULL, environment.check_e3),
    CheckSpec("E-5", "Environment", "Dockerfile does not execute dangerous operations",
              Severity.HIGH, Tier.PYTHON_FULL, environment.check_e5),
    CheckSpec("E-6", "Environment", "Compose volumes do not collide with reserved harbor mounts",
              Severity.HIGH, Tier.PYTHON_FULL, environment.check_e6),
    CheckSpec("E-7", "Environment", "Apt package versions are pinned",
              Severity.LOW, Tier.PYTHON_FULL, environment.check_e7),
    CheckSpec("E-8", "Environment", "Base image uses a specific version tag",
              Severity.LOW, Tier.PYTHON_FULL, environment.check_e8),
    CheckSpec("E-9", "Environment", "Avoids using heredocs in Dockerfile",
              Severity.LOW, Tier.PYTHON_FULL, environment.check_e9),

    # --- Oracle Solution — deterministic (2) ------------------------------ #
    CheckSpec("O-1", "Oracle Solution", "Oracle passes consistently (multi-run + static scan)",
              Severity.HIGH, Tier.PYTHON_FULL, oracle.check_o1),
    CheckSpec("O-2", "Oracle Solution", "Oracle does not access internet",
              Severity.HIGH, Tier.PYTHON_FULL, oracle.check_o2),

    # --- Verifiers — deterministic (2) ------------------------------------ #
    CheckSpec("V-3", "Verifiers", "Verifier scripts do not grab content from the web",
              Severity.HIGH, Tier.PYTHON_FULL, verifier.check_v3),
    CheckSpec("V-4", "Verifiers", "Verifier writes only binary rewards (0/1)",
              Severity.HIGH, Tier.PYTHON_FULL, verifier.check_v4),

    # --- Rubrics — deterministic (8) -------------------------------------- #
    CheckSpec("R-1", "Rubrics", "Rubrics must not reference testing logic",
              Severity.HIGH, Tier.PYTHON_FULL, rubric.check_r1),
    CheckSpec("R-2", "Rubrics", "Rubrics must not reference metadata or instruction.md",
              Severity.HIGH, Tier.PYTHON_FULL, rubric.check_r2),
    CheckSpec("R-3", "Rubrics", "Rubrics contain ≥3 negative penalties",
              Severity.HIGH, Tier.PYTHON_FULL, rubric.check_r3),
    CheckSpec("R-4", "Rubrics", "Rubric scores ∈ {±1, ±2, ±3, ±5}",
              Severity.HIGH, Tier.PYTHON_FULL, rubric.check_r4),
    CheckSpec("R-5", "Rubrics", "Rubric block correctly formatted",
              Severity.HIGH, Tier.PYTHON_FULL, rubric.check_r5),
    CheckSpec("R-7", "Rubrics", "≥1 negative criterion per milestone rubric",
              Severity.MEDIUM, Tier.PYTHON_FULL, rubric.check_r7),
    CheckSpec("R-10", "Rubrics", "Rubric does not mention oracle / NOP runs",
              Severity.MEDIUM, Tier.PYTHON_FULL, rubric.check_r10),
    CheckSpec("R-11", "Rubrics", "Per-milestone rubric points in [10, 40]",
              Severity.LOW, Tier.PYTHON_FULL, rubric.check_r11),

    # --- Task Structure — deterministic (2) ------------------------------- #
    CheckSpec("TS-1", "Task Structure", "Required files exist (branched by task type)",
              Severity.HIGH, Tier.PYTHON_FULL, structure.check_ts1),
    CheckSpec("TS-2", "Task Structure", "No unnecessary files in task root",
              Severity.LOW, Tier.PYTHON_FULL, structure.check_ts2),

    # --- Task Metadata — deterministic (2) -------------------------------- #
    CheckSpec("TM-1", "Task Metadata", "Required task.toml metadata fields present",
              Severity.HIGH, Tier.PYTHON_FULL, metadata.check_tm1),
    CheckSpec("TM-2", "Task Metadata", "Multi-container / custom-compose flags correct",
              Severity.HIGH, Tier.PYTHON_FULL, metadata.check_tm2),

    # --- Milestone Tasks — deterministic (4) ------------------------------ #
    CheckSpec("M-1", "Milestone Tasks", "steps/milestone_N/ directory layout correct",
              Severity.HIGH, Tier.PYTHON_FULL, milestone.check_m1),
    CheckSpec("M-2", "Milestone Tasks", "[[steps]] count == milestones (with timeouts)",
              Severity.HIGH, Tier.PYTHON_FULL, milestone.check_m2),
    CheckSpec("M-3", "Milestone Tasks", "Each milestone has solveN.sh + solve.sh wrapper",
              Severity.HIGH, Tier.PYTHON_PARTIAL_HUMAN, milestone.check_m3),
    CheckSpec("M-4", "Milestone Tasks", "Each milestone has test_mN.py with TestMilestoneN class",
              Severity.HIGH, Tier.PYTHON_FULL, milestone.check_m4),

    # ===================================================================== #
    # HUMAN_ONLY tier (16) — reviewer must judge these manually.
    # Names match canonical PDF headings. Reasoning is verbatim PDF text
    # from the reviewer-checklist audit report. Severities (12 H + 4 M)
    # match the PDF.
    # ===================================================================== #

    # --- Instruction Prompt — human (5) ----------------------------------- #
    CheckSpec("I-1", "Instruction Prompt", "Task Instruction is concise",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "Task instructions should be concise and clear. This "
                      "means outlining the task in as little as one sentence, "
                      "and as much as three paragraphs. Tasks should not be "
                      "long running with many different instructions/"
                      "requirements to follow. The goal is to create tasks "
                      "that represent genuinely challenging coding problems, "
                      "not ones that challenge instruction following. Task "
                      "instructions should generally read like how a human "
                      "would prompt a coding agent. This means no emojis, "
                      "not a lot of markdown styling, and no longer running "
                      "prompts."
                  ),
                  hint=(
                      "Count paragraphs (>3 → fail), check for emojis, check "
                      "markdown density. Then judge tone — does it read like "
                      "a human prompting a coding agent, or like a step-by-"
                      "step manual?"
                  ),
              )),
    CheckSpec("I-2", "Instruction Prompt", "Task Instruction is well specified",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "While task instructions are now required to be "
                      "concise, they still must be well specified. This "
                      "means that the goal of a task is clear and obvious "
                      "to the human/agent. The main criteria to look for "
                      "here is tasks with a larger number of edge cases and "
                      "requirements. If a task is primarily hard due to a "
                      "large number of edge cases/requirements that are not "
                      "handled well, it should be rejected."
                  ),
                  hint=(
                      "Look for edge-case overload — tasks where difficulty "
                      "comes from a long list of poorly-handled edge cases "
                      "rather than from a genuine engineering challenge. "
                      "Reject those."
                  ),
              )),
    CheckSpec("I-3", "Instruction Prompt", "Task Instruction is interesting",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The task instruction should not be obscure or "
                      "irrelevant to the point that no group of developers "
                      "or users would find them interesting. Every task "
                      "must be interesting or useful in some way."
                  ),
                  hint=(
                      "Apply the project's taste call — would any group of "
                      "developers or users find this task interesting or "
                      "useful? Reject obscure or irrelevant tasks."
                  ),
              )),
    CheckSpec("I-4", "Instruction Prompt", "Task instruction does not provide hints on how to solve",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "Conceptually, we are going for tasks that represent "
                      "one shot tasks from a user to a terminal agent. If "
                      "tasks contain significant hints or rubrics in the "
                      "instruction.md for how to solve the task, it is not "
                      "representative of the style of task we are looking "
                      "for. Requirements can be included, but hints or "
                      "stepwise instructions should not be."
                  ),
                  hint=(
                      "Look for stepwise procedures ('first do X, then Y'), "
                      "code snippets longer than ~5 lines, or rubric-style "
                      "guidance. Pure requirements are fine."
                  ),
              )),
    CheckSpec("I-5", "Instruction Prompt",
              "Task instruction is unique to previously submitted tasks and open source tasks",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The task must be noticeably unique to any task in "
                      "TB2, TB3 or Snorkel Terminal Bench Edition 1. "
                      "Similarity search eval results are provided to help "
                      "make this determination. Generally, the logic for "
                      "too similar tasks is: 1. Are the initial state/"
                      "instructions different in a way that is non trivial "
                      "OR 2. Is the expected output different in a way "
                      "that is non trivial."
                  ),
                  hint=(
                      "Check the similarity-search results against the "
                      "prior-task index. Cosine ≥0.95 against any prior "
                      "task is a strong duplicate signal; 0.7-0.95 needs "
                      "human judgement on whether the differences are "
                      "non-trivial."
                  ),
              )),

    # --- Environment — human (1) ------------------------------------------ #
    CheckSpec("E-4", "Environment", "Environment does not contain solution / ground truth answers",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The environment must not contain any files that "
                      "provide the oracle solution or ground truth used in "
                      "the unit tests. All scripts related to the oracle "
                      "solution should be stored only in the solution "
                      "directory, and all files needed to verify the task "
                      "should only be included in the tests/ directory."
                  ),
                  hint=(
                      "Scan environment/ for filenames containing solve/"
                      "solution/oracle/answer/expected/ground_truth. Also "
                      "watch for paraphrased solution code (e.g., a 'utils' "
                      "file that is actually the algorithm with renamed "
                      "variables)."
                  ),
              )),

    # --- Verifiers — human (4) -------------------------------------------- #
    CheckSpec("V-1", "Verifiers", "Verifier cannot exit before reward is assigned",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The test.sh file should always assign a reward to "
                      "reward.txt on both success and failure, to avoid "
                      "triggering a RewardNotFoundError. However, exiting "
                      "before assigning a reward is acceptable in cases "
                      "where continuing would unfairly penalize the agent "
                      "for factors outside its control."
                  ),
                  hint=(
                      "Trace every code path in test.sh and tests/*.py. If "
                      "any path can reach exit/return without writing "
                      "reward.txt — and the path isn't an externally-broken "
                      "one — fail."
                  ),
              )),
    CheckSpec("V-2", "Verifiers", "Verifiers use the exact same logic for oracle and agent runs",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The verifiers must not contain any conditional logic "
                      "that causes the oracle solution to be validated "
                      "differently than the agent's solution. This ensures "
                      "that the oracle and agent are validated equivalently "
                      "and fairly."
                  ),
                  hint=(
                      "Look for branches on $ORACLE / $RUN_TYPE / "
                      "$IS_ORACLE, file-marker tricks, different timeouts/"
                      "tolerances by run type, conditional log parsing. Any "
                      "differential behavior fails."
                  ),
              )),
    CheckSpec("V-5", "Verifiers", "Verifiers must be aligned with instructions",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "All unit tests must be aligned to the task that was "
                      "outlined in the instructions. The verifiers must not "
                      "test requirements that are not explicitly or "
                      "implicitly defined in the instructions."
                  ),
                  hint=(
                      "For each test in tests/test_*.py, find a "
                      "corresponding requirement in instruction.md "
                      "(explicit or implicit). Tests that exercise "
                      "requirements not stated in instructions should be "
                      "removed."
                  ),
              )),
    CheckSpec("V-6", "Verifiers", "Verifiers check for correctness, not just format",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The verifiers must actually verify that an "
                      "implemented solution is correct. They should not "
                      "just settle for checking high level requirements or "
                      "general formatting."
                  ),
                  hint=(
                      "Tests must exercise actual correctness, not just "
                      "check that an output file exists or matches a "
                      "format. A passing reward should mean the agent "
                      "solved the task correctly, not just produced "
                      "something well-formed."
                  ),
              )),

    # --- Oracle Solution — human (1) -------------------------------------- #
    CheckSpec("O-3", "Oracle Solution", "Oracle is reflective of what is described in the instruction.md",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The oracle solution must actually solve the problem "
                      "outlined in the instruction.md. This should cover "
                      "every requirement outlined in the instructions, not "
                      "just those that are tested. It is also crucial that "
                      "the solution is an actual implementation, not a "
                      "hardcoded answer to pass the tests."
                  ),
                  hint=(
                      "Read instruction.md, then read solve.sh + "
                      "dependencies. Confirm every requirement is "
                      "implemented (not just the tested ones), and that "
                      "the solution is a real implementation rather than "
                      "hardcoded values that just happen to make the tests "
                      "pass."
                  ),
              )),

    # --- Rubrics — human (3) ---------------------------------------------- #
    CheckSpec("R-6", "Rubrics", "Rubric criteria are detailed and precise",
              Severity.HIGH, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "Each criterion in the rubric must be detailed and "
                      "precise enough to describe the specific action they "
                      "are meant to grade. Vague criteria or ones that "
                      "should not always apply given the task should not "
                      "be included."
                  ),
                  hint=(
                      "Each criterion must describe a specific gradable "
                      "action precisely. Reject vague criteria "
                      "('appropriate', 'reasonable', 'good', 'clean', "
                      "'elegant') and ones that wouldn't always apply "
                      "given the task."
                  ),
              )),
    CheckSpec("R-8", "Rubrics", "Rubric scores must be correctly mapped to level of importance",
              Severity.MEDIUM, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "Critical criteria must be associated with the most "
                      "extreme scores (5, -5), while Major or Minor "
                      "criteria should be associated with less extreme "
                      "scores."
                  ),
                  hint=(
                      "Critical criteria must use ±5; Major use ±2 or ±3; "
                      "Minor use ±1. Verify each criterion's score "
                      "reflects its actual importance — flag any "
                      "low-importance criterion using extreme scores or "
                      "any high-importance criterion underweighted."
                  ),
              )),
    CheckSpec("R-9", "Rubrics", "Rubric criteria should always include positive language",
              Severity.MEDIUM, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "The criteria should always be phrased positively "
                      "not negatively. A negatively phrased criterion can "
                      "be rephrased into a positively phrased criterion "
                      "with a negative reward."
                  ),
                  hint=(
                      "Flag any criterion using negation words ('not', "
                      "'without', 'never', 'fails to') paired with a "
                      "positive reward. Adverbial uses ('completes the "
                      "task without using internet, +5') are fine."
                  ),
              )),

    # --- Task Metadata — human (1) ---------------------------------------- #
    CheckSpec("TM-3", "Task Metadata",
              "Tags, languages, categories, and subcategories must be applicable to the task",
              Severity.MEDIUM, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "Any assigned tag, language, category, or subcategory "
                      "must be aligned with the actual content of the task. "
                      "The definitions for categories and subcategories can "
                      "be found in our documentation."
                  ),
                  hint=(
                      "Cross-check task.toml [metadata] against "
                      "instruction.md and environment/Dockerfile. Each "
                      "claimed tag must be defensible from the task content."
                  ),
              )),

    # --- Milestone Tasks — human (1) -------------------------------------- #
    CheckSpec("M-5", "Milestone Tasks", "Per-milestone instruction.md files cover only that milestone",
              Severity.MEDIUM, Tier.HUMAN_ONLY,
              _human_only(
                  rule=(
                      "Each steps/milestone_N/instruction.md should "
                      "describe only the requirements for that milestone. "
                      "The first milestone's instruction.md should also "
                      "include the overall task context the agent needs "
                      "to get oriented; subsequent milestones can be "
                      "shorter."
                  ),
                  hint=(
                      "Milestone 1 may include overall context. Milestones "
                      "2+ must be scoped only to their own work — backward "
                      "references ('building on milestone 1') are fine, "
                      "forward references ('we'll handle X in milestone 3') "
                      "fail."
                  ),
              )),
]


# Sentinel — module-import-time validation
assert len(CHECK_SPECS) == 47, f"Expected 47 checks, got {len(CHECK_SPECS)}"

_high = sum(1 for s in CHECK_SPECS if s.severity == Severity.HIGH)
_med = sum(1 for s in CHECK_SPECS if s.severity == Severity.MEDIUM)
_low = sum(1 for s in CHECK_SPECS if s.severity == Severity.LOW)
assert (_high, _med, _low) == (34, 8, 5), \
    f"Severity mix off: {_high}H / {_med}M / {_low}L (expected 34/8/5 per PDF)"

_human = sum(1 for s in CHECK_SPECS if s.tier == Tier.HUMAN_ONLY)
_python = sum(1 for s in CHECK_SPECS if s.tier == Tier.PYTHON_FULL)
_partial = sum(1 for s in CHECK_SPECS if s.tier == Tier.PYTHON_PARTIAL_HUMAN)
assert (_python, _partial, _human) == (30, 1, 16), \
    f"Tier mix off: {_python} python_full / {_partial} python_partial / {_human} human_only"
