"""Task Metadata checks: TM-1, TM-2."""
from __future__ import annotations

from pathlib import Path

from ..tb2_lint.parsers import compose
from ..tb2_lint.types import CheckResult, EvidenceEntry, RunContext, Verdict


# Per the brief's TM-1 note: inline the field list, don't say "see PDF".

_REQUIRED_METADATA_FIELDS = [
    "author_name", "author_email", "category", "subcategories",
    "difficulty", "codebase_size", "number_of_milestones",
    "languages", "tags",
    "expert_time_estimate_min", "junior_time_estimate_min",
]
_REQUIRED_ENVIRONMENT_FIELDS = [
    "build_timeout_sec", "cpus", "memory_mb", "storage_mb", "workdir",
]
_REQUIRED_VERIFIER_FIELDS = ["timeout_sec"]
_REQUIRED_AGENT_FIELDS = ["timeout_sec"]
_REQUIRED_STEPS_AGENT_FIELDS = ["timeout_sec"]
_REQUIRED_STEPS_VERIFIER_FIELDS = ["timeout_sec"]


# ============================================================================
# TM-1: Required metadata fields
# ============================================================================

def check_tm1(ctx: RunContext) -> CheckResult:
    if ctx.task_toml is None:
        return CheckResult(
            verdict=Verdict.FAIL,
            reasoning="task.toml missing or unparseable.",
        )

    issues: list[EvidenceEntry] = []
    t = ctx.task_toml

    # Top-level: version = "2.0"
    v = t.get("version")
    if v != "2.0":
        issues.append(EvidenceEntry(
            file="task.toml", snippet=f"version={v!r}, expected exactly \"2.0\"",
        ))

    # [metadata]
    md = t.get("metadata") or {}
    if not isinstance(md, dict):
        issues.append(EvidenceEntry(
            file="task.toml", snippet="[metadata] section missing or wrong type",
        ))
        md = {}
    for field in _REQUIRED_METADATA_FIELDS:
        if field not in md or md[field] in (None, "", [], {}):
            issues.append(EvidenceEntry(
                file="task.toml", snippet=f"[metadata].{field} missing or empty",
            ))

    # [environment]
    env = t.get("environment") or {}
    if not isinstance(env, dict):
        issues.append(EvidenceEntry(
            file="task.toml", snippet="[environment] section missing or wrong type",
        ))
        env = {}
    for field in _REQUIRED_ENVIRONMENT_FIELDS:
        if field not in env or env[field] in (None, ""):
            issues.append(EvidenceEntry(
                file="task.toml", snippet=f"[environment].{field} missing or empty",
            ))

    if not ctx.is_milestone:
        # Non-milestone: [verifier].timeout_sec, [agent].timeout_sec
        ver = t.get("verifier") or {}
        if not isinstance(ver, dict):
            issues.append(EvidenceEntry(
                file="task.toml", snippet="[verifier] section missing (required for non-milestone)",
            ))
            ver = {}
        for field in _REQUIRED_VERIFIER_FIELDS:
            if field not in ver or not isinstance(ver[field], (int, float)):
                issues.append(EvidenceEntry(
                    file="task.toml", snippet=f"[verifier].{field} missing or not numeric",
                ))
        ag = t.get("agent") or {}
        if not isinstance(ag, dict):
            issues.append(EvidenceEntry(
                file="task.toml", snippet="[agent] section missing (required for non-milestone)",
            ))
            ag = {}
        for field in _REQUIRED_AGENT_FIELDS:
            if field not in ag or not isinstance(ag[field], (int, float)):
                issues.append(EvidenceEntry(
                    file="task.toml", snippet=f"[agent].{field} missing or not numeric",
                ))
    else:
        # Milestone: [[steps]] blocks; M-2 enforces count, but TM-1 still
        # checks each step has agent + verifier timeouts.
        steps = t.get("steps")
        if not isinstance(steps, list) or not steps:
            issues.append(EvidenceEntry(
                file="task.toml", snippet="[[steps]] array required for milestone tasks",
            ))
        else:
            for i, step in enumerate(steps, 1):
                if not isinstance(step, dict):
                    issues.append(EvidenceEntry(
                        file="task.toml", snippet=f"[[steps]][{i-1}] is not a table",
                    ))
                    continue
                if not isinstance(step.get("name"), str) or not step["name"].strip():
                    issues.append(EvidenceEntry(
                        file="task.toml", snippet=f"[[steps]][{i-1}].name missing or empty",
                    ))
                ag = step.get("agent") or {}
                if not isinstance(ag, dict) or not isinstance(ag.get("timeout_sec"), (int, float)):
                    issues.append(EvidenceEntry(
                        file="task.toml",
                        snippet=f"[[steps]][{i-1}].agent.timeout_sec missing or not numeric",
                    ))
                ver = step.get("verifier") or {}
                if not isinstance(ver, dict) or not isinstance(ver.get("timeout_sec"), (int, float)):
                    issues.append(EvidenceEntry(
                        file="task.toml",
                        snippet=f"[[steps]][{i-1}].verifier.timeout_sec missing or not numeric",
                    ))

    if issues:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=issues[:30],
            reasoning=(
                f"Found {len(issues)} missing or invalid task.toml field(s). "
                "Required (always): version=\"2.0\"; [metadata] with author_name, "
                "author_email, category, subcategories, difficulty, codebase_size, "
                "number_of_milestones, languages, tags, expert_time_estimate_min, "
                "junior_time_estimate_min; [environment] with build_timeout_sec, "
                "cpus, memory_mb, storage_mb, workdir. "
                "Non-milestone also: [verifier].timeout_sec, [agent].timeout_sec. "
                "Milestone also: one [[steps]] block per milestone with name, "
                "[steps.agent].timeout_sec, [steps.verifier].timeout_sec."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="All required task.toml fields are present.",
    )


# ============================================================================
# TM-2: Multi-container / custom-compose flag correctness
# ============================================================================

def check_tm2(ctx: RunContext) -> CheckResult:
    if ctx.task_toml is None:
        return CheckResult(
            verdict=Verdict.FAIL,
            reasoning="task.toml missing or unparseable.",
        )
    md = ctx.task_toml.get("metadata") or {}
    if not isinstance(md, dict):
        md = {}
    custom_flag = bool(md.get("custom_docker_compose"))
    multi_flag = bool(md.get("is_multi_container"))

    cpath = compose.find_compose(ctx.task_dir)
    has_compose = cpath is not None

    issues: list[EvidenceEntry] = []

    # Compose present → flag must be true
    if has_compose and not custom_flag:
        issues.append(EvidenceEntry(
            file="task.toml",
            snippet=f"docker-compose.yaml present at {cpath.relative_to(ctx.task_dir) if cpath else 'environment/'}, "
                    f"but [metadata].custom_docker_compose is not true",
        ))

    # Flag set but no compose → mismatch
    if custom_flag and not has_compose:
        issues.append(EvidenceEntry(
            file="task.toml",
            snippet="[metadata].custom_docker_compose=true but no docker-compose.yaml found",
        ))

    # Multi-container check: services count > 1 → multi flag must be true
    if has_compose:
        data = compose.parse_compose(cpath) if cpath else None
        services_count = len(compose.services(data) if isinstance(data, dict) else {})
        if services_count > 1 and not multi_flag:
            issues.append(EvidenceEntry(
                file="task.toml",
                snippet=f"docker-compose.yaml declares {services_count} services, "
                        "but [metadata].is_multi_container is not true",
            ))
        if multi_flag and services_count <= 1:
            issues.append(EvidenceEntry(
                file="task.toml",
                snippet=f"[metadata].is_multi_container=true but docker-compose.yaml has "
                        f"only {services_count} service(s)",
            ))

    if issues:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=issues,
            reasoning="Task.toml multi-container / custom-compose flags don't match the actual environment.",
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="Compose / multi-container flags correctly reflect the environment.",
    )
