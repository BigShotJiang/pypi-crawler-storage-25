"""Per-section TB2 reviewer-checklist check modules.

Importing this package re-exports the registry of all check specs.
"""
from .registry import CHECK_SPECS  # noqa: F401
