"""Oracle Solution checks: O-1, O-2."""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from ..tb2_lint.scanners import web_fetch
from ..tb2_lint.types import CheckResult, EvidenceEntry, RunContext, Verdict

# Static-scan patterns for nondeterminism (O-1).
# These are advisory only — multi-run is the authoritative gate.
_NONDETERMINISM_PATTERNS = [
    (re.compile(r"\bimport\s+random\b"), "imports `random` module"),
    (re.compile(r"\brandom\.(?:choice|random|randint|sample|shuffle|uniform)"),
     "uses `random.<fn>` directly"),
    (re.compile(r"\bnp\.random|\bnumpy\.random"), "uses numpy.random"),
    (re.compile(r"\btime\.sleep\b"), "uses time.sleep (latency-dependent)"),
    (re.compile(r"\bDate\.now\(\)|\btime\.time\(\)"), "reads wall-clock time"),
    (re.compile(r"\bos\.urandom\b|\bsecrets\."), "reads OS randomness"),
    (re.compile(r"\bthreading\.Thread|\bThreadPoolExecutor"),
     "uses threading (race-prone)"),
    (re.compile(r"\basyncio\.gather\b"), "uses asyncio.gather (ordering)"),
    (re.compile(r"\$RANDOM\b"), "shell $RANDOM"),
    (re.compile(r"\bsleep\s+\d"), "shell `sleep N`"),
]


def _scan_solution_static(task_dir: Path) -> list[EvidenceEntry]:
    sol = task_dir / "solution"
    hits: list[EvidenceEntry] = []
    if not sol.is_dir():
        return hits
    for p in sol.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix not in (".py", ".sh", ".bash", ".rs", ".go", ".ts", ".js"):
            continue
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        try:
            rel = str(p.relative_to(task_dir))
        except ValueError:
            rel = str(p)
        for ln_idx, raw in enumerate(text.splitlines(), 1):
            for rx, why in _NONDETERMINISM_PATTERNS:
                if rx.search(raw):
                    hits.append(EvidenceEntry(
                        file=rel, line=ln_idx, snippet=f"{why}: {raw.strip()}",
                    ))
                    break
    return hits


# Per the brief's open Q2 + your answer 5: Docker not available → NEEDS_REVIEW
# clearly labeled, do NOT abort.

def _multi_run_oracle(task_dir: Path, runs: int) -> tuple[Optional[bool], str]:
    """Return (success, message). success is None if we cannot run (no harbor/docker).

    We delegate to harbor since the existing CLI already integrates with it for
    `opslabel scan`. Building the image + running oracle from scratch in this
    CLI would duplicate harbor's logic; instead we shell out.
    """
    if shutil.which("harbor") is None:
        return None, "harbor binary not found on PATH"
    if shutil.which("docker") is None:
        return None, "docker binary not found on PATH"

    rewards: list[float] = []
    for run_idx in range(runs):
        try:
            r = subprocess.run(
                ["harbor", "run", "--path", str(task_dir), "--agent", "oracle"],
                capture_output=True, text=True, timeout=900,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            return False, f"harbor invocation failed on run {run_idx + 1}: {e}"
        if r.returncode != 0:
            return False, f"harbor returned rc={r.returncode} on run {run_idx + 1}"
        # Locate the most recent reward.txt
        reward = _read_latest_reward(task_dir)
        if reward is None:
            return False, f"could not locate reward.txt after run {run_idx + 1}"
        rewards.append(reward)

    if not all(r == 1.0 for r in rewards):
        return False, f"oracle did not pass all {runs} runs; rewards = {rewards}"
    return True, f"oracle passed all {runs} runs with reward=1.0"


def _read_latest_reward(task_dir: Path) -> Optional[float]:
    jobs = task_dir / "jobs"
    if not jobs.is_dir():
        return None
    try:
        runs = sorted(
            (d for d in jobs.iterdir() if d.is_dir() and not d.name.startswith(".")),
            key=lambda d: d.stat().st_mtime, reverse=True,
        )
    except OSError:
        return None
    for run_dir in runs:
        for trial in run_dir.iterdir():
            if not trial.is_dir():
                continue
            r = trial / "verifier" / "reward.txt"
            if r.is_file():
                try:
                    return float(r.read_text().strip())
                except (OSError, ValueError):
                    return None
    return None


# ============================================================================
# O-1: Oracle passes consistently (multi-run + static scan)
# ============================================================================

def check_o1(ctx: RunContext) -> CheckResult:
    sol = ctx.task_dir / "solution"
    if not sol.is_dir():
        # Milestone tasks don't have root solution/; they have steps/milestone_N/solution/
        if ctx.is_milestone:
            sol_alt = ctx.task_dir / "steps"
            if sol_alt.is_dir():
                pass
            else:
                return CheckResult(
                    verdict=Verdict.FAIL,
                    reasoning="No solution/ directory found.",
                )
        else:
            return CheckResult(
                verdict=Verdict.FAIL,
                reasoning="No solution/ directory found.",
            )

    static_hits = _scan_solution_static(ctx.task_dir)
    static_evidence = [
        EvidenceEntry(file=h.file, line=h.line, snippet=h.snippet)
        for h in static_hits[:10]
    ]

    if ctx.no_multi_run:
        if static_hits:
            return CheckResult(
                verdict=Verdict.FAIL,
                evidence=static_evidence,
                reasoning=(
                    f"Static scan flagged {len(static_hits)} nondeterminism pattern(s). "
                    "Multi-run validation skipped (--no-multi-run)."
                ),
            )
        return CheckResult(
            verdict=Verdict.NEEDS_REVIEW,
            reasoning=(
                "Multi-run validation skipped (--no-multi-run). Static scan found "
                "no obvious nondeterminism patterns; reviewer must still verify "
                "the oracle is deterministic by running it ≥5 times manually."
            ),
            auditor_notes="Run `harbor run --agent oracle` ≥5 times and confirm reward=1 every time.",
        )

    success, msg = _multi_run_oracle(ctx.task_dir, ctx.runs)
    if success is None:
        # Docker / harbor not available — graceful fallback
        return CheckResult(
            verdict=Verdict.NEEDS_REVIEW,
            evidence=static_evidence,
            reasoning=(
                f"Cannot run multi-run validation: {msg}. Static scan "
                f"{'flagged ' + str(len(static_hits)) + ' nondeterminism pattern(s)' if static_hits else 'found no obvious patterns'}."
            ),
            auditor_notes=(
                "Multi-run requires Docker + harbor. Install both, then run "
                "`harbor run --agent oracle` ≥5 times and confirm reward=1 every time."
            ),
        )
    if not success:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=static_evidence,
            reasoning=(
                f"Oracle multi-run failed: {msg}. "
                f"Static scan additionally found {len(static_hits)} nondeterminism pattern(s)."
                if static_hits else f"Oracle multi-run failed: {msg}."
            ),
        )
    if static_hits:
        return CheckResult(
            verdict=Verdict.NEEDS_REVIEW,
            evidence=static_evidence,
            reasoning=(
                f"Multi-run passed ({msg}), but static scan flagged "
                f"{len(static_hits)} potential nondeterminism pattern(s). "
                "Reviewer should confirm these are intentional / safe."
            ),
            auditor_notes="Confirm flagged randomness/timing patterns are seeded or otherwise deterministic.",
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning=msg,
    )


# ============================================================================
# O-2: Oracle does not access internet
# ============================================================================

def check_o2(ctx: RunContext) -> CheckResult:
    hits = web_fetch.scan_solution(ctx.task_dir)
    if not hits:
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning="No web fetches detected in solution/.",
        )
    evidence = [
        EvidenceEntry(file=h.file, line=h.line, snippet=f"{h.reason}: {h.snippet}")
        for h in hits[:20]
    ]
    return CheckResult(
        verdict=Verdict.FAIL,
        evidence=evidence,
        reasoning=(
            f"Found {len(hits)} potential web fetch(es) in solution/. "
            "The oracle must not access the internet — install dependencies "
            "in the environment instead."
        ),
    )
