"""Task Structure checks: TS-1, TS-2."""
from __future__ import annotations

from pathlib import Path

from ..tb2_lint.types import CheckResult, EvidenceEntry, RunContext, Verdict


_NON_MILESTONE_REQUIRED = [
    "environment/Dockerfile",
    "solution/solve.sh",
    "tests/test.sh",
    "instruction.md",
    "task.toml",
]
_NON_MILESTONE_FORBIDDEN = []   # nothing currently forbidden for non-milestone

_MILESTONE_REQUIRED_GLOBAL = [
    "environment/",
    "task.toml",
]
# Milestone tasks must NOT have these at root (they live under steps/milestone_N/)
_MILESTONE_FORBIDDEN_AT_ROOT = [
    "instruction.md",
    "tests",
    "solution",
]


# ============================================================================
# TS-1: Required files exist
# ============================================================================

def check_ts1(ctx: RunContext) -> CheckResult:
    missing: list[EvidenceEntry] = []
    forbidden: list[EvidenceEntry] = []

    if not ctx.is_milestone:
        for rel in _NON_MILESTONE_REQUIRED:
            p = ctx.task_dir / rel
            if not p.exists():
                missing.append(EvidenceEntry(file=rel, snippet="missing"))
        # also need environment/, solution/, tests/ as directories
        for d in ("environment", "solution", "tests"):
            p = ctx.task_dir / d
            if not p.is_dir():
                missing.append(EvidenceEntry(file=f"{d}/", snippet="missing directory"))
    else:
        # global required
        for rel in _MILESTONE_REQUIRED_GLOBAL:
            p = ctx.task_dir / rel
            if not (p.is_dir() if rel.endswith("/") else p.exists()):
                missing.append(EvidenceEntry(file=rel, snippet="missing"))

        # forbidden at root
        for rel in _MILESTONE_FORBIDDEN_AT_ROOT:
            p = ctx.task_dir / rel
            if p.exists():
                forbidden.append(EvidenceEntry(
                    file=rel, snippet="present at root (must live under steps/milestone_N/ for milestone tasks)",
                ))
        # milestone_x.md root files
        for p in ctx.task_dir.glob("milestone_*.md"):
            if p.is_file():
                forbidden.append(EvidenceEntry(
                    file=p.name, snippet="root-level milestone_x.md not allowed (use steps/milestone_N/instruction.md instead)",
                ))

        # per-milestone required files
        for idx in range(1, ctx.num_milestones + 1):
            base = ctx.task_dir / "steps" / f"milestone_{idx}"
            if not base.is_dir():
                missing.append(EvidenceEntry(
                    file=f"steps/milestone_{idx}/", snippet="milestone subdirectory missing",
                ))
                continue
            for rel in (
                "instruction.md",
                "tests/test.sh",
                f"tests/test_m{idx}.py",
                "solution/solve.sh",
                f"solution/solve{idx}.sh",
            ):
                if not (base / rel).exists():
                    missing.append(EvidenceEntry(
                        file=f"steps/milestone_{idx}/{rel}", snippet="missing",
                    ))

    if not missing and not forbidden:
        kind = "milestone" if ctx.is_milestone else "non-milestone"
        return CheckResult(
            verdict=Verdict.PASS,
            reasoning=f"All required files for a {kind} task are present.",
        )
    return CheckResult(
        verdict=Verdict.FAIL,
        evidence=missing + forbidden,
        reasoning=(
            f"Task structure incomplete: {len(missing)} missing file(s), "
            f"{len(forbidden)} forbidden file(s) at root."
        ),
    )


# ============================================================================
# TS-2: No unnecessary parent files
# ============================================================================

_UNNECESSARY_AT_ROOT = (
    "jobs",        # leftover harbor logs
    "README.md",
    "data",
)


def check_ts2(ctx: RunContext) -> CheckResult:
    flagged: list[EvidenceEntry] = []
    for name in _UNNECESSARY_AT_ROOT:
        p = ctx.task_dir / name
        if p.exists():
            flagged.append(EvidenceEntry(
                file=name + ("/" if p.is_dir() else ""),
                snippet="unnecessary at task root",
            ))
    if flagged:
        return CheckResult(
            verdict=Verdict.FAIL,
            evidence=flagged,
            reasoning=(
                f"Found {len(flagged)} unnecessary file(s) at the task root "
                "(jobs/, README.md, data/, etc.). Low severity — clean up before submission."
            ),
        )
    return CheckResult(
        verdict=Verdict.PASS,
        reasoning="No leftover jobs/, README.md, or data/ at task root.",
    )
