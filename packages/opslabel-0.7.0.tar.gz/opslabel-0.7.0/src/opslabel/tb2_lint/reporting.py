"""Reporting: serialize LintReport to JSON, render to terminal via rich.

The summary surfaces NEEDS_REVIEW and HUMAN_ONLY separately from PASS so
contributors don't accidentally treat either as 'good to go'.
"""
from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console
from rich.table import Table

from .types import LintReport


def write_json(report: LintReport, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False))


def render_terminal(report: LintReport, console: Console, *, quiet: bool = False) -> None:
    s = report.summary
    total = s.get("total", 0)
    p = s.get("pass", 0)
    f = s.get("fail", 0)
    n = s.get("needs_review", 0)
    h = s.get("human_only", 0)

    if not quiet:
        table = Table(
            title=f"TB2 Reviewer Checklist Lint — {report.task_id}",
            show_lines=False, expand=True, header_style="bold",
        )
        table.add_column("ID", no_wrap=True, style="cyan", width=5)
        table.add_column("Section", no_wrap=True, style="dim")
        table.add_column("Sev", no_wrap=True, width=4)
        table.add_column("Verdict", no_wrap=True, width=14)
        table.add_column("Reasoning", overflow="fold")

        for cid, crit in report.criteria.items():
            verdict = crit["verdict"]
            reasoning = crit["reasoning"]
            if crit.get("auditor_notes"):
                reasoning = reasoning + "\n[dim]→ " + crit["auditor_notes"] + "[/dim]"
            table.add_row(
                cid, crit["section"], _sev_color(crit["severity"]),
                _verdict_color(verdict), reasoning,
            )
        console.print(table)
        console.print()

    summary_parts = [
        f"[green]{p} PASS[/green]",
        f"[red]{f} FAIL[/red]",
        f"[yellow]{n} NEEDS_REVIEW[/yellow]",
    ]
    if h > 0:
        summary_parts.append(f"[blue]{h} HUMAN_ONLY[/blue]")

    console.print(
        f"[bold]Lint summary:[/bold] " + " · ".join(summary_parts) +
        f"  ({total} total)"
    )
    if f > 0:
        console.print("[bold red]❗ FAIL must be fixed before submission.[/bold red]")
    if n > 0:
        o1 = report.criteria.get("O-1") or {}
        if o1.get("verdict") == "NEEDS_REVIEW" and "harbor" in (o1.get("reasoning") or "").lower():
            console.print(
                f"[yellow]⚠ {n} check(s) need review.[/yellow] "
                "[dim]Includes O-1 (Docker + harbor required for multi-run).[/dim]"
            )
        else:
            console.print(f"[yellow]⚠ NEEDS_REVIEW will be checked by a human reviewer.[/yellow]")
    if h > 0:
        console.print(
            f"[blue]👤 HUMAN_ONLY: {h} criteria require human judgement (subjective; not auto-checkable).[/blue]"
        )


def _verdict_color(v: str) -> str:
    if v == "PASS":
        return "[green]PASS[/green]"
    if v == "FAIL":
        return "[red]FAIL[/red]"
    if v == "NEEDS_REVIEW":
        return "[yellow]NEEDS_REVIEW[/yellow]"
    if v == "HUMAN_ONLY":
        return "[blue]HUMAN_ONLY[/blue]"
    return v


def _sev_color(sev: str) -> str:
    if sev == "High":
        return "[red]H[/red]"
    if sev == "Medium":
        return "[yellow]M[/yellow]"
    if sev == "Low":
        return "[dim]L[/dim]"
    return sev
