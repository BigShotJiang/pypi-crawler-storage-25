"""Terminal Bench Edition 2 reviewer-checklist linter.

Phase 1: 31 deterministic Python-full / Python-partial-Human checks.

Public surface:
    from opslabel.tb2_lint.runner import run_lint
    from opslabel.tb2_lint.types import LintReport, CheckResult, Verdict

`run_lint` is intentionally NOT re-exported at this package level to avoid
a circular import (runner → checks_tb2.registry → tb2_lint.types → ...).
"""
from .types import (
    CheckResult,
    EvidenceEntry,
    LintReport,
    Severity,
    Tier,
    Verdict,
)

__all__ = [
    "CheckResult",
    "EvidenceEntry",
    "LintReport",
    "Severity",
    "Tier",
    "Verdict",
]
