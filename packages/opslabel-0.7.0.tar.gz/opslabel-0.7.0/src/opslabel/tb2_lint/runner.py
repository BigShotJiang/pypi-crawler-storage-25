"""Lint orchestrator: parse once, run all checks, build LintReport."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from .. import __version__
from ..checks_tb2.registry import CHECK_SPECS
from .parsers import compose, task_toml
from .types import LintReport, RunContext, Verdict


def run_lint(
    task_dir: Path,
    *,
    runs: int = 5,
    no_multi_run: bool = False,
    r3_mode: str = "aggregate",
) -> LintReport:
    """Run every check against task_dir and return the structured report."""
    task_dir = task_dir.resolve()

    parsed_toml = task_toml.parse_task_toml(task_dir)
    is_ms, n_ms = task_toml.is_milestone(parsed_toml)
    cpath = compose.find_compose(task_dir)
    parsed_compose = compose.parse_compose(cpath) if cpath else None

    ctx = RunContext(
        task_dir=task_dir,
        runs=runs,
        no_multi_run=no_multi_run,
        r3_mode=r3_mode,
        task_toml=parsed_toml,
        docker_compose=parsed_compose,
        is_milestone=is_ms,
        num_milestones=n_ms,
    )

    # Resolve task_id: prefer task.toml metadata.name, fall back to dir name.
    task_id = task_dir.name
    if isinstance(parsed_toml, dict):
        md = parsed_toml.get("metadata") or {}
        if isinstance(md, dict) and isinstance(md.get("name"), str):
            n = md["name"].strip()
            if n:
                task_id = n

    started = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    criteria_block: dict = {}
    pass_n = fail_n = nr_n = ho_n = 0

    for spec in CHECK_SPECS:
        try:
            result = spec.fn(ctx)
        except Exception as e:
            from .types import CheckResult
            result = CheckResult(
                verdict=Verdict.NEEDS_REVIEW,
                reasoning=f"Check crashed: {type(e).__name__}: {e}",
                auditor_notes="CLI-internal error; please report.",
            )

        v = result.verdict
        if v == Verdict.PASS:
            pass_n += 1
        elif v == Verdict.FAIL:
            fail_n += 1
        elif v == Verdict.NEEDS_REVIEW:
            nr_n += 1
        elif v == Verdict.HUMAN_ONLY:
            ho_n += 1

        criteria_block[spec.id] = {
            "section": spec.section,
            "name": spec.name,
            "severity": spec.severity.value,
            "tier": spec.tier.value,
            "verdict": v.value,
            "evidence": [e.to_dict() for e in result.evidence],
            "reasoning": result.reasoning,
            "auditor_notes": result.auditor_notes,
        }

    summary = {
        "total": len(CHECK_SPECS),
        "pass": pass_n,
        "fail": fail_n,
        "needs_review": nr_n,
        "human_only": ho_n,
    }

    return LintReport(
        version="1.0",
        task_id=task_id,
        task_dir=str(task_dir),
        ran_at=started,
        cli_version=__version__,
        summary=summary,
        criteria=criteria_block,
    )
