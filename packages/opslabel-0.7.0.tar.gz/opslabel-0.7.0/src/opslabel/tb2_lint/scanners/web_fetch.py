"""Shared web-fetch detection used by E-1, V-3, and O-2.

Auditor C-3 corrections applied:
  - Scan list extends beyond .sh + Dockerfile to: Makefile, package.json scripts,
    pyproject.toml [tool.*.scripts], *.py in environment/ or tests/, Cargo.toml
    build.rs reference, Gemfile, composer.json scripts, environment.yml.

Surface: every match returns (file, line, snippet, reason).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Iterator

import yaml

from ..parsers import package_json, pyproject

# Patterns that indicate a network fetch.
# Match heuristic: the regex matches the literal command/URL marker; we
# additionally check the surrounding command tokens to avoid false positives
# on `pip install` style commands (handled by allow-list below).
_FETCH_PATTERNS = [
    (re.compile(r"\bcurl\b", re.IGNORECASE), "curl invocation"),
    (re.compile(r"\bwget\b", re.IGNORECASE), "wget invocation"),
    (re.compile(r"\bgit\s+clone\b", re.IGNORECASE), "git clone"),
    (re.compile(r"https?://[^\s'\"<>`]+", re.IGNORECASE), "URL literal"),
    (re.compile(r"\bftp://[^\s'\"<>`]+", re.IGNORECASE), "ftp URL literal"),
    (re.compile(r"\bgit://[^\s'\"<>`]+", re.IGNORECASE), "git URL literal"),
]

# `pip install ... git+https://` etc. — these are explicit web fetches even
# though the line starts with pip install.
_PIP_GIT_RE = re.compile(
    r"\bpip\s+install\b[^\n]*?\bgit\+[a-z+]+://", re.IGNORECASE
)
_NPM_GIT_RE = re.compile(
    r"\b(?:npm|pnpm|yarn|bun)\s+(?:install|add|i)\b[^\n]*?(?:git\+|github:|ssh:)",
    re.IGNORECASE,
)

# Allow-list: lines starting with these are package-manager invocations and
# are exempt from URL flagging UNLESS they hit one of the explicit web rules
# above (pip git+, npm git, etc.).
_ALLOW_LINE_PREFIXES = re.compile(
    r"^\s*(?:RUN\s+)?"
    r"(?:apt(?:-get)?|apk|dnf|yum|pacman|brew|zypper|microdnf|"
    r"pip3?|pipx|uv|poetry|conda|mamba|"
    r"npm|pnpm|yarn|bun|"
    r"gem|bundle|"
    r"cargo|"
    r"go\s+(?:get|install|mod)|"
    r"composer|"
    r"choco|scoop"
    r")\b",
    re.IGNORECASE,
)


@dataclass
class FetchHit:
    file: str
    line: int
    snippet: str
    reason: str


def _join_continuations(text: str) -> list[tuple[int, str]]:
    """Join shell/Dockerfile backslash-continued lines into single logical lines.

    Returns [(start_line_1based, joined_text)]. This lets the allow-list /
    pattern checks see a complete command in one piece, eliminating false
    positives like `RUN apt-get install -y \\` followed by `    curl=1.2.3 \\`
    being read as two independent lines.
    """
    out: list[tuple[int, str]] = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        start = i + 1
        parts = [lines[i]]
        while parts[-1].rstrip().endswith("\\") and i + 1 < len(lines):
            i += 1
            parts.append(lines[i])
        joined = " ".join(p.rstrip().rstrip("\\").rstrip() for p in parts)
        out.append((start, joined))
        i += 1
    return out


def scan_text(rel_file: str, text: str) -> list[FetchHit]:
    """Scan a multi-line text blob for web-fetch indicators.

    Backslash-continued lines are joined before pattern matching so that
    an allowlisted command (e.g. `apt-get install`) continued across multiple
    physical lines doesn't trigger false-positives on `curl` package names.
    """
    hits: list[FetchHit] = []
    for start, logical in _join_continuations(text):
        s = logical.strip()
        if not s or s.startswith("#"):
            continue
        # Always-bad explicit-pull patterns (regardless of allow-list)
        for rx, why in (
            (_PIP_GIT_RE, "pip install from git+ URL"),
            (_NPM_GIT_RE, "package manager install from git/github URL"),
        ):
            if rx.search(s):
                hits.append(FetchHit(file=rel_file, line=start, snippet=s, reason=why))
        # Allow-listed package-manager line: skip generic patterns
        if _ALLOW_LINE_PREFIXES.match(s):
            continue
        for rx, why in _FETCH_PATTERNS:
            m = rx.search(s)
            if m:
                hits.append(FetchHit(file=rel_file, line=start, snippet=s, reason=why))
                break
    return hits


def _scan_file(path: Path, rel: str) -> list[FetchHit]:
    if not path.is_file():
        return []
    try:
        text = path.read_text(errors="replace")
    except OSError:
        return []
    return scan_text(rel, text)


def scan_directory_files(
    base: Path, files: Iterable[str], rel_root: Path
) -> list[FetchHit]:
    """Scan a fixed list of file paths under `base` (relative names).
    rel_root is used to build the report-friendly relative file string."""
    hits: list[FetchHit] = []
    for name in files:
        p = base / name
        if p.is_file():
            try:
                rel = str(p.relative_to(rel_root))
            except ValueError:
                rel = str(p)
            hits.extend(_scan_file(p, rel))
    return hits


def _walk_python_files(base: Path) -> Iterator[Path]:
    if not base.is_dir():
        return
    for p in base.rglob("*.py"):
        if p.is_file():
            yield p


def scan_environment(task_dir: Path) -> list[FetchHit]:
    """E-1 surface: Dockerfile + compose + .sh + Makefile + package.json scripts +
    pyproject [tool.*.scripts] + *.py inside environment/ + Cargo.toml + Gemfile +
    composer.json scripts + environment.yml.
    """
    env = task_dir / "environment"
    return _scan_buildlike(env, task_dir, label="environment")


def scan_verifier(task_dir: Path) -> list[FetchHit]:
    """V-3 surface: same regex set, applied to tests/ instead of environment/."""
    tests = task_dir / "tests"
    return _scan_buildlike(tests, task_dir, label="tests")


def scan_solution(task_dir: Path) -> list[FetchHit]:
    """O-2 surface: same regex set, applied to solution/."""
    sol = task_dir / "solution"
    return _scan_buildlike(sol, task_dir, label="solution")


def _scan_buildlike(base: Path, task_dir: Path, label: str) -> list[FetchHit]:
    hits: list[FetchHit] = []
    if not base.is_dir():
        return hits

    # Direct .sh, .bash, .zsh files (recursively under base)
    for p in base.rglob("*"):
        if not p.is_file():
            continue
        suffix = p.suffix.lower()
        name = p.name.lower()
        rel = _rel(p, task_dir)

        if name == "dockerfile" or name.startswith("dockerfile."):
            hits.extend(_scan_file(p, rel))
            continue
        if suffix in (".sh", ".bash", ".zsh", ".fish"):
            hits.extend(_scan_file(p, rel))
            continue
        if name in ("makefile",) or suffix == ".mk":
            hits.extend(_scan_file(p, rel))
            continue
        if suffix == ".py":
            hits.extend(_scan_file(p, rel))
            continue
        if name == "package.json":
            hits.extend(_scan_package_json(p, rel))
            continue
        if name == "pyproject.toml":
            hits.extend(_scan_pyproject(p, rel))
            continue
        if name == "cargo.toml":
            hits.extend(_scan_cargo_toml(p, rel))
            continue
        if name == "build.rs":
            hits.extend(_scan_file(p, rel))
            continue
        if name == "gemfile":
            hits.extend(_scan_file(p, rel))
            continue
        if name == "composer.json":
            hits.extend(_scan_composer_json(p, rel))
            continue
        if name in ("environment.yml", "environment.yaml"):
            hits.extend(_scan_environment_yml(p, rel))
            continue

    # Compose files: scan as text since YAML strings are still textual
    for cname in ("docker-compose.yaml", "docker-compose.yml", "compose.yaml", "compose.yml"):
        p = base / cname
        if p.is_file():
            hits.extend(_scan_file(p, _rel(p, task_dir)))

    return hits


def _rel(p: Path, task_dir: Path) -> str:
    try:
        return str(p.relative_to(task_dir))
    except ValueError:
        return str(p)


def _scan_package_json(p: Path, rel: str) -> list[FetchHit]:
    pkg = package_json.parse(p)
    hits: list[FetchHit] = []
    for name, cmd in package_json.script_strings(pkg):
        for h in scan_text(rel, cmd):
            h.snippet = f"scripts.{name}: {cmd.strip()}"
            hits.append(h)
    return hits


def _scan_pyproject(p: Path, rel: str) -> list[FetchHit]:
    pp = pyproject.parse(p)
    hits: list[FetchHit] = []
    for tool, name, cmd in pyproject.tool_scripts(pp):
        for h in scan_text(rel, cmd):
            h.snippet = f"[tool.{tool}.scripts].{name}: {cmd.strip()}"
            hits.append(h)
    return hits


def _scan_cargo_toml(p: Path, rel: str) -> list[FetchHit]:
    """Surface a flag if Cargo.toml references a build.rs (which itself runs
    arbitrary Rust at build time and is scanned separately if present)."""
    try:
        text = p.read_text(errors="replace")
    except OSError:
        return []
    hits: list[FetchHit] = []
    for ln_idx, ln in enumerate(text.splitlines(), 1):
        if re.search(r"^\s*build\s*=\s*\"build\.rs\"", ln, re.IGNORECASE):
            hits.append(FetchHit(
                file=rel, line=ln_idx, snippet=ln.strip(),
                reason="Cargo.toml declares build.rs (scanned separately if present)",
            ))
            break
    return hits


def _scan_composer_json(p: Path, rel: str) -> list[FetchHit]:
    try:
        import json as _json
        data = _json.loads(p.read_text(errors="replace"))
    except (OSError, ValueError):
        return []
    hits: list[FetchHit] = []
    scripts = data.get("scripts") if isinstance(data, dict) else None
    if isinstance(scripts, dict):
        for name, cmd in scripts.items():
            if isinstance(cmd, str):
                for h in scan_text(rel, cmd):
                    h.snippet = f"scripts.{name}: {cmd.strip()}"
                    hits.append(h)
    return hits


def _scan_environment_yml(p: Path, rel: str) -> list[FetchHit]:
    """environment.yml (conda) — flag pip URLs in the dependencies stanza
    and any explicit URL-looking entries."""
    try:
        data = yaml.safe_load(p.read_text(errors="replace"))
    except (OSError, yaml.YAMLError):
        return []
    if not isinstance(data, dict):
        return []
    hits: list[FetchHit] = []
    deps = data.get("dependencies")
    if isinstance(deps, list):
        for entry in deps:
            if isinstance(entry, str):
                for h in scan_text(rel, entry):
                    hits.append(h)
            elif isinstance(entry, dict):
                pip = entry.get("pip")
                if isinstance(pip, list):
                    for line in pip:
                        if isinstance(line, str):
                            for h in scan_text(rel, line):
                                hits.append(h)
    return hits
