"""E-5 dangerous Dockerfile / docker-compose operations.

Auditor M-1 corrections applied:
  - keyword list extended for namespace-sharing, security_opt unconfined,
    --cap-add=ALL, additional capabilities (SYS_PTRACE, SYS_RAWIO, SYS_TIME,
    MAC_OVERRIDE).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

# Capabilities the PDF lists explicitly + auditor additions
_DANGEROUS_CAPS = {
    "SYS_ADMIN", "NET_ADMIN", "SYS_MODULE",      # PDF
    "NET_RAW", "DAC_OVERRIDE",                    # audit report
    "SYS_PTRACE", "SYS_RAWIO", "SYS_TIME",        # audit-of-audit
    "MAC_ADMIN", "MAC_OVERRIDE",
}

# Keywords/regex patterns flagged anywhere in Dockerfile or compose
_FLAT_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"--privileged\b", re.IGNORECASE), "Container runs in --privileged mode"),
    (re.compile(r"/var/run/docker\.sock"), "Mounts docker socket /var/run/docker.sock"),
    (re.compile(r"--cap-add\s*=?\s*ALL", re.IGNORECASE), "Adds ALL Linux capabilities"),
    # namespace sharing (compose-style)
    (re.compile(r"^\s*pid\s*:\s*['\"]?host['\"]?\s*$", re.MULTILINE), "Shares host PID namespace"),
    (re.compile(r"^\s*ipc\s*:\s*['\"]?host['\"]?\s*$", re.MULTILINE), "Shares host IPC namespace"),
    (re.compile(r"^\s*network(?:_mode)?\s*:\s*['\"]?host['\"]?\s*$", re.MULTILINE),
     "Uses host network (bypasses isolation)"),
    (re.compile(r"^\s*userns_mode\s*:\s*['\"]?host['\"]?\s*$", re.MULTILINE),
     "Disables user-namespace isolation"),
    # security_opt unconfined modes
    (re.compile(r"seccomp\s*=\s*unconfined", re.IGNORECASE),
     "Disables seccomp syscall filtering"),
    (re.compile(r"apparmor\s*=\s*unconfined", re.IGNORECASE),
     "Disables AppArmor mandatory access control"),
    # Setuid / setgid bits (Dockerfile RUN lines)
    (re.compile(r"\bchmod\s+(?:[ugo]?[+-]?[sS]\b|[0-7]*[2-7][0-7]{3}\b)"),
     "Sets setuid/setgid bit on a file"),
]


@dataclass
class DangerHit:
    file: str
    line: Optional[int]
    snippet: str
    reason: str


def scan_text(rel_file: str, text: str) -> list[DangerHit]:
    hits: list[DangerHit] = []
    lines = text.splitlines()

    # Per-line capability flagging (cap_add: SYS_ADMIN etc.)
    for ln_idx, ln in enumerate(lines, 1):
        upper = ln.upper()
        for cap in _DANGEROUS_CAPS:
            # match the cap as a whole word (avoid partial matches like SYS_ADMINISTRATOR)
            if re.search(rf"\b{re.escape(cap)}\b", upper):
                hits.append(DangerHit(
                    file=rel_file, line=ln_idx, snippet=ln.strip(),
                    reason=f"References capability {cap}",
                ))
                break       # one cap per line is enough

    # Flat patterns scanned line-by-line for accurate line numbers
    for ln_idx, ln in enumerate(lines, 1):
        for rx, why in _FLAT_PATTERNS:
            if rx.search(ln):
                hits.append(DangerHit(
                    file=rel_file, line=ln_idx, snippet=ln.strip(), reason=why,
                ))
                break

    return hits


def scan_paths(paths: Iterable[Path], task_dir: Path) -> list[DangerHit]:
    out: list[DangerHit] = []
    for p in paths:
        if not p.is_file():
            continue
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        try:
            rel = str(p.relative_to(task_dir))
        except ValueError:
            rel = str(p)
        out.extend(scan_text(rel, text))
    return out
