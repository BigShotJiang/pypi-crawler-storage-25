"""I-6 path-token extraction with auditor M-3 corrections applied.

The original regex `\\w+(/\\w+)+` had a known false-positive surface — natural
phrases like 'build/release', 'client/server', 'input/output' all matched.
That's the difference between a Python-full check (binary, trustworthy) and
a check that needs human triage.

Tightened rule: a token is path-LIKE only if it satisfies ANY of:
  1. Starts with `/`   (absolute path candidate)
  2. Starts with `./`  (relative path) — flagged
  3. Starts with `~`   (home-relative) — flagged
  4. Starts with `../` (parent-relative) — flagged
  5. Contains a `.` followed by 2-6 alphanumeric chars (file extension)

Rule (5) catches `tests/test_outputs.py`, `data/foo.json`, `src/main.rs` etc.
without matching `client/server` or `build/release` (no dot-extension).

We exclude tokens that:
  - Are inside a URL (`http://`, `https://`, `ftp://`, `git://`)
  - Are Python import paths (`from foo.bar import baz`)
  - Are inside fenced code blocks (we record the path but tag it; I-6 still
    flags it on a strict reading of the PDF, which makes no carve-out for
    code blocks)
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# A path-like token: requires `/` and starts with one of the path-prefix
# anchors OR contains a file-extension-looking dot.
_PATH_TOKEN_RE = re.compile(
    r"""
    (?<![\w/.])              # not preceded by word/slash/dot
    (?P<token>
        (?: /                # absolute
          | \./              # explicit relative
          | \.\./            # parent-relative
          | ~/?              # home-relative
        )
        [A-Za-z0-9_./\-]*
      |
        (?:                  # path-with-extension: <segment>(/<segment>)+ where the
          [A-Za-z0-9_\-]+    # last segment has a .ext suffix
          (?: / [A-Za-z0-9_\-]+ )+
          \.[A-Za-z0-9]{2,6}
        )
    )
    (?![\w/])                # not followed by word/slash
    """,
    re.VERBOSE,
)

_URL_RE = re.compile(r"\b(?:https?|ftp|git|ssh|file)://[^\s'\"<>`]+")
_IMPORT_LINE_RE = re.compile(r"^\s*(?:from\s+\S+\s+import|import\s+\S+)\b")


@dataclass
class PathHit:
    line: int
    column: int
    token: str
    is_absolute: bool


def extract_path_tokens(text: str) -> list[PathHit]:
    """Walk every line and emit path-like tokens."""
    out: list[PathHit] = []
    in_fenced = False
    for ln_idx, raw in enumerate(text.splitlines(), 1):
        # Track triple-backtick fences (we still scan inside, per I-6 strict reading)
        stripped = raw.lstrip()
        if stripped.startswith("```"):
            in_fenced = not in_fenced
            continue
        if _IMPORT_LINE_RE.match(raw):
            continue

        # Mask URLs first so their internal slashes don't leak through
        masked = _URL_RE.sub(lambda m: " " * len(m.group(0)), raw)

        for m in _PATH_TOKEN_RE.finditer(masked):
            tok = m.group("token")
            # Strip a trailing punctuation sometimes captured at sentence-end
            while tok and tok[-1] in ".,;:":
                tok = tok[:-1]
            if not tok or "/" not in tok:
                continue
            out.append(PathHit(
                line=ln_idx, column=m.start() + 1,
                token=tok,
                is_absolute=tok.startswith("/"),
            ))
    return out


def is_relative(token: str) -> bool:
    """A path token is 'relative' (and therefore a violation) if it does not
    start with `/`. Includes `./`, `../`, `~`, and bare `foo/bar.ext`."""
    return not token.startswith("/")
