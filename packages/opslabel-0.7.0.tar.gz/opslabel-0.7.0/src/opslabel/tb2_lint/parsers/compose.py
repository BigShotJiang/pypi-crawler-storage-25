"""docker-compose.yaml parser. Returns the parsed dict, or None on failure."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import yaml


def parse_compose(path: Path) -> Optional[dict]:
    if not path.is_file():
        return None
    try:
        text = path.read_text(errors="replace")
    except OSError:
        return None
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError:
        return None
    return data if isinstance(data, dict) else None


def find_compose(task_dir: Path) -> Optional[Path]:
    """Return the path to a compose file in environment/ if it exists, else None."""
    env = task_dir / "environment"
    for name in ("docker-compose.yaml", "docker-compose.yml", "compose.yaml", "compose.yml"):
        p = env / name
        if p.is_file():
            return p
    return None


def services(compose: dict) -> dict:
    """Return the `services:` block, or {} if absent / malformed."""
    s = compose.get("services") if isinstance(compose, dict) else None
    return s if isinstance(s, dict) else {}


def iter_volumes(compose: dict):
    """Yield (service_name, volume_entry) for every volume across all services.

    volume_entry is either a string ("./src:/app/src") or dict (long-form mount).
    """
    for name, svc in services(compose).items():
        if not isinstance(svc, dict):
            continue
        vols = svc.get("volumes")
        if isinstance(vols, list):
            for v in vols:
                yield name, v
