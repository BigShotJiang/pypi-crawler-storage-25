"""Parse package.json for both `scripts` (E-1/V-3 web-fetch surface) and
dependency manifests (E-2 pinning)."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional


def parse(path: Path) -> Optional[dict]:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(errors="replace"))
    except (OSError, json.JSONDecodeError):
        return None


def script_strings(pkg: Optional[dict]) -> list[tuple[str, str]]:
    """Return [(script_name, script_command)] from package.json `scripts` block."""
    if not isinstance(pkg, dict):
        return []
    scripts = pkg.get("scripts")
    if not isinstance(scripts, dict):
        return []
    return [(k, v) for k, v in scripts.items() if isinstance(v, str)]


def dependency_versions(pkg: Optional[dict]) -> list[tuple[str, str, str]]:
    """Return [(section, name, version_spec)] across `dependencies` and `devDependencies`."""
    if not isinstance(pkg, dict):
        return []
    out: list[tuple[str, str, str]] = []
    for section in ("dependencies", "devDependencies"):
        block = pkg.get(section)
        if not isinstance(block, dict):
            continue
        for name, spec in block.items():
            if isinstance(name, str) and isinstance(spec, str):
                out.append((section, name, spec))
    return out
