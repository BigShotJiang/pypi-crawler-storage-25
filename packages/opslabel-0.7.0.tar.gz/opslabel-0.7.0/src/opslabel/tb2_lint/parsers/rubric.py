"""Locate and parse rubric blocks.

A rubric criterion is a single line in the format:

    Agent <description>, <score>

where score ∈ {±1, ±2, ±3, ±5}. Lines that don't match are flagged for R-5
(format check) but still parsed best-effort.

Rubric source resolution (in priority order):
  Non-milestone task:
    1. task.toml top-level `rubric` (string)
    2. task.toml [rubric].text (string)
    3. <task_dir>/rubric.md
  Milestone task (per-milestone, returns one rubric per milestone):
    1. task.toml [[steps]].rubric for each step
    2. <task_dir>/steps/milestone_N/rubric.md
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

# Score must be one of ±1 ±2 ±3 ±5. R-4 enforces this enumeration.
_VALID_SCORES = {1, 2, 3, 5, -1, -2, -3, -5}

# R-5 format: line starts with "Agent" + whitespace + content + comma + score.
# We capture even malformed lines so R-5 can flag them; R-4 then validates the score.
_LINE_RE = re.compile(
    r"^(?P<prefix>Agent)\s+(?P<body>.+?),\s*(?P<score>[+-]?\d+(?:\.\d+)?)\s*$"
)
_LOOSE_LINE_RE = re.compile(r"^\s*Agent\b", re.IGNORECASE)


@dataclass
class RubricCriterion:
    raw: str                # original line, stripped
    line: int               # 1-based within the rubric block
    body: Optional[str]     # description part (None if format invalid)
    score: Optional[int]    # int score (None if format invalid OR non-integer)
    well_formed: bool       # True iff matches strict R-5 regex AND starts with capital "Agent"


@dataclass
class Rubric:
    """Parsed rubric. One per task (non-milestone) or one per milestone."""
    source: str                              # human-readable source descriptor
    text: str                                # raw rubric text
    criteria: list[RubricCriterion]
    milestone_index: Optional[int] = None    # 1-based; None for non-milestone


def parse_rubric_text(text: str) -> list[RubricCriterion]:
    """Tokenize a rubric block into per-line criteria."""
    out: list[RubricCriterion] = []
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        # Some rubrics use a leading "- " or "* " bullet; tolerate them when scoring
        # the criterion content but require strict format for R-5.
        m = _LINE_RE.match(line)
        if m and m.group("prefix") == "Agent":
            try:
                score_f = float(m.group("score"))
                score = int(score_f) if score_f.is_integer() else None
            except ValueError:
                score = None
            out.append(RubricCriterion(
                raw=line,
                line=i,
                body=m.group("body").strip(),
                score=score,
                well_formed=score is not None,
            ))
        elif _LOOSE_LINE_RE.match(line):
            # Line claims to be a criterion but doesn't match strict format.
            out.append(RubricCriterion(
                raw=line, line=i, body=None, score=None, well_formed=False,
            ))
        # Lines that don't even start with "Agent" are ignored entirely
        # (e.g. blank rubric headings or stray paragraph text).
    return out


def _read_md(path: Path) -> Optional[str]:
    if not path.is_file():
        return None
    try:
        return path.read_text(errors="replace")
    except OSError:
        return None


def locate_rubrics(
    task_dir: Path,
    task_toml: Optional[dict],
    is_milestone: bool,
    num_milestones: int,
) -> list[Rubric]:
    """Find rubric blocks. Returns [] if no rubric source can be located."""
    if is_milestone and num_milestones > 0:
        return _locate_milestone_rubrics(task_dir, task_toml, num_milestones)
    return _locate_single_rubric(task_dir, task_toml)


def _locate_single_rubric(task_dir: Path, task_toml: Optional[dict]) -> list[Rubric]:
    # 1. task.toml top-level "rubric" string
    if isinstance(task_toml, dict):
        r = task_toml.get("rubric")
        if isinstance(r, str) and r.strip():
            return [Rubric(source="task.toml:rubric", text=r,
                           criteria=parse_rubric_text(r))]
        # 2. [rubric].text
        rb = task_toml.get("rubric")
        if isinstance(rb, dict):
            t = rb.get("text")
            if isinstance(t, str) and t.strip():
                return [Rubric(source="task.toml:[rubric].text", text=t,
                               criteria=parse_rubric_text(t))]
    # 3. rubric.md
    rmd = _read_md(task_dir / "rubric.md")
    if rmd is not None and rmd.strip():
        return [Rubric(source="rubric.md", text=rmd,
                       criteria=parse_rubric_text(rmd))]
    return []


def _locate_milestone_rubrics(
    task_dir: Path, task_toml: Optional[dict], num_milestones: int
) -> list[Rubric]:
    out: list[Rubric] = []
    steps = task_toml.get("steps") if isinstance(task_toml, dict) else None
    steps_list = steps if isinstance(steps, list) else []
    for idx in range(1, num_milestones + 1):
        # Try [[steps]] block at index idx-1
        rubric_text: Optional[str] = None
        source = ""
        if idx - 1 < len(steps_list):
            step = steps_list[idx - 1]
            if isinstance(step, dict):
                r = step.get("rubric")
                if isinstance(r, str) and r.strip():
                    rubric_text = r
                    source = f"task.toml:[[steps]][{idx-1}].rubric"
        # Fallback to per-milestone rubric.md
        if rubric_text is None:
            mpath = task_dir / "steps" / f"milestone_{idx}" / "rubric.md"
            md = _read_md(mpath)
            if md is not None and md.strip():
                rubric_text = md
                source = f"steps/milestone_{idx}/rubric.md"
        if rubric_text is None:
            # missing rubric for this milestone: emit empty Rubric so checks
            # can flag it (R-7, R-3 per-milestone, R-11)
            out.append(Rubric(
                source=f"<missing for milestone_{idx}>",
                text="",
                criteria=[],
                milestone_index=idx,
            ))
        else:
            out.append(Rubric(
                source=source, text=rubric_text,
                criteria=parse_rubric_text(rubric_text),
                milestone_index=idx,
            ))
    return out


def is_valid_score(score: Optional[int]) -> bool:
    return score is not None and score in _VALID_SCORES
