"""pyproject.toml parser — extracts [project.dependencies] specs and any
script-table strings under [tool.*.scripts] / [tool.poetry.scripts]."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

try:
    import tomllib  # type: ignore[import-not-found]
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]


def parse(path: Path) -> Optional[dict]:
    if not path.is_file():
        return None
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):
        return None


def project_dependencies(pp: Optional[dict]) -> list[str]:
    """Return PEP-621 `[project.dependencies]` entries (raw spec strings)."""
    if not isinstance(pp, dict):
        return []
    proj = pp.get("project")
    if not isinstance(proj, dict):
        return []
    deps = proj.get("dependencies")
    return [d for d in deps if isinstance(d, str)] if isinstance(deps, list) else []


def poetry_dependencies(pp: Optional[dict]) -> list[tuple[str, str]]:
    """Return [(name, spec)] from [tool.poetry.dependencies], skipping 'python'."""
    if not isinstance(pp, dict):
        return []
    poetry = (pp.get("tool") or {}).get("poetry") if isinstance(pp.get("tool"), dict) else None
    if not isinstance(poetry, dict):
        return []
    deps = poetry.get("dependencies")
    if not isinstance(deps, dict):
        return []
    out: list[tuple[str, str]] = []
    for name, spec in deps.items():
        if name == "python":
            continue
        if isinstance(spec, str):
            out.append((name, spec))
        elif isinstance(spec, dict):
            v = spec.get("version")
            if isinstance(v, str):
                out.append((name, v))
            else:
                out.append((name, ""))   # path / git / extras-only entry: treat as unpinned
    return out


def tool_scripts(pp: Optional[dict]) -> list[tuple[str, str, str]]:
    """Return [(tool_name, script_name, command)] for every [tool.*.scripts] table.

    Used by E-1/V-3 to scan for embedded web fetches in script values.
    """
    if not isinstance(pp, dict):
        return []
    tool = pp.get("tool")
    if not isinstance(tool, dict):
        return []
    out: list[tuple[str, str, str]] = []
    for tool_name, tool_block in tool.items():
        if not isinstance(tool_block, dict):
            continue
        scripts = tool_block.get("scripts")
        if not isinstance(scripts, dict):
            continue
        for s_name, s_cmd in scripts.items():
            if isinstance(s_cmd, str):
                out.append((tool_name, s_name, s_cmd))
    return out
