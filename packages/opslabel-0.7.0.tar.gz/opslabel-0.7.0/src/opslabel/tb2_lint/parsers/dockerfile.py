"""Lightweight Dockerfile parser — handles continuations + comments.

Returns a list of `Instruction(directive, args, line, raw)` for every directive
the linter cares about. We do NOT validate Dockerfile semantics; we just need
enough structure for downstream regex / keyword scans.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class Instruction:
    directive: str          # "FROM", "RUN", "COPY", "ADD", "ENTRYPOINT", "CMD", ...
    args: str               # everything after the directive, joined-across-continuations
    line: int               # 1-based line of the directive's first line
    raw: str                # original directive + args (joined)


def parse_dockerfile(path: Path) -> list[Instruction]:
    """Parse a Dockerfile into a list of Instructions. Returns [] on missing/unreadable file."""
    if not path.is_file():
        return []
    try:
        text = path.read_text(errors="replace")
    except OSError:
        return []

    out: list[Instruction] = []
    i = 0
    lines = text.splitlines()
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        # Skip blank + comment lines (parser-directive comments not relevant for our checks)
        if not stripped or stripped.startswith("#"):
            i += 1
            continue

        # Directive line. Capture continuations (\ at end-of-line, optionally with trailing whitespace).
        first_line_no = i + 1
        joined_lines = [line]
        while joined_lines[-1].rstrip().endswith("\\"):
            i += 1
            if i >= len(lines):
                break
            joined_lines.append(lines[i])

        # Drop the trailing backslashes when joining.
        joined = " ".join(
            l.rstrip().rstrip("\\").rstrip() for l in joined_lines
        )
        # Split directive vs rest. Directive is the first whitespace-delimited token.
        parts = joined.split(None, 1)
        if not parts:
            i += 1
            continue
        directive = parts[0].upper()
        args = parts[1] if len(parts) > 1 else ""
        out.append(Instruction(directive=directive, args=args, line=first_line_no, raw=joined))
        i += 1

    return out


def find_instructions(instrs: list[Instruction], directive: str) -> list[Instruction]:
    return [i for i in instrs if i.directive == directive.upper()]
