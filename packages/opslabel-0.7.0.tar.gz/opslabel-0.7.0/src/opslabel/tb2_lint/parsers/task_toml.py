"""task.toml parser."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

try:
    import tomllib  # type: ignore[import-not-found]
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]


def parse_task_toml(task_dir: Path) -> Optional[dict]:
    p = task_dir / "task.toml"
    if not p.is_file():
        return None
    try:
        with open(p, "rb") as f:
            return tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):
        return None


def is_milestone(task_toml: Optional[dict]) -> tuple[bool, int]:
    """Return (is_milestone, num_milestones). is_milestone is True iff
    metadata.number_of_milestones > 0."""
    if not isinstance(task_toml, dict):
        return False, 0
    md = task_toml.get("metadata") or {}
    n = md.get("number_of_milestones") if isinstance(md, dict) else 0
    if isinstance(n, int) and n > 0:
        return True, n
    return False, 0
