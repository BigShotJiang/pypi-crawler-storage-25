"""Core types for the TB2 reviewer-checklist linter."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional


class Severity(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class Verdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    HUMAN_ONLY = "HUMAN_ONLY"        # Surfaced in the report; not auto-checked.


class Tier(str, Enum):
    PYTHON_FULL = "python_full"
    PYTHON_PARTIAL_HUMAN = "python_partial_human"
    HUMAN_ONLY = "human_only"


@dataclass
class EvidenceEntry:
    file: str
    line: Optional[int] = None
    snippet: Optional[str] = None

    def to_dict(self) -> dict:
        d: dict[str, Any] = {"file": self.file}
        if self.line is not None:
            d["line"] = self.line
        if self.snippet is not None:
            d["snippet"] = self.snippet
        return d


@dataclass
class CheckResult:
    verdict: Verdict
    evidence: list[EvidenceEntry] = field(default_factory=list)
    reasoning: str = ""
    auditor_notes: str = ""


@dataclass
class CheckSpec:
    """Static metadata + executable check function for one criterion."""
    id: str
    section: str
    name: str
    severity: Severity
    tier: Tier
    fn: Callable[["RunContext"], CheckResult]


@dataclass
class RunContext:
    """Shared state across all checks in one lint run.

    Files parsed once and cached so checks don't re-parse.
    """
    task_dir: Path
    runs: int = 5
    no_multi_run: bool = False
    r3_mode: str = "aggregate"

    # parsed-once cache (filled by runner before checks execute)
    task_toml: Optional[dict] = None
    docker_compose: Optional[dict] = None
    is_milestone: bool = False
    num_milestones: int = 0


@dataclass
class LintReport:
    version: str = "1.0"
    task_id: str = ""
    task_dir: str = ""
    ran_at: str = ""
    cli_version: str = ""
    summary: dict = field(default_factory=dict)
    criteria: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "task_id": self.task_id,
            "task_dir": self.task_dir,
            "ran_at": self.ran_at,
            "cli_version": self.cli_version,
            "summary": self.summary,
            "criteria": self.criteria,
        }
