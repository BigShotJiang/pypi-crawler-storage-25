from __future__ import annotations

import json
import os
import time
from typing import Any, Optional

import requests

NIM_URL = "https://integrate.api.nvidia.com/v1/chat/completions"
DEFAULT_MODEL = "minimaxai/minimax-m2.7"


def _env_int(key: str, default: int) -> int:
    v = (os.environ.get(key) or "").strip()
    if not v:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def _env_float(key: str, default: float) -> float:
    v = (os.environ.get(key) or "").strip()
    if not v:
        return default
    try:
        return float(v)
    except ValueError:
        return default


MAX_RETRIES = 3
# Reasoning-class models on NIM can run 60–300s on multi-section prompts.
# 360s gives generous headroom. All overridable via env:
#   NIM_MODEL, NIM_TIMEOUT_SEC, NIM_TEMPERATURE, NIM_TOP_P, NIM_SEED, NIM_MAX_TOKENS
TIMEOUT = _env_int("NIM_TIMEOUT_SEC", 360)
# Determinism: temperature=0 + fixed seed + top_p=1 makes verdicts reproducible.
# Without this, minimax-m2.7 was returning different pass/warn verdicts on
# repeat runs of the same prompt — bad for QA.
DEFAULT_TEMPERATURE = _env_float("NIM_TEMPERATURE", 0.0)
DEFAULT_TOP_P = _env_float("NIM_TOP_P", 1.0)
DEFAULT_SEED = _env_int("NIM_SEED", 42)
DEFAULT_MAX_TOKENS = _env_int("NIM_MAX_TOKENS", 2048)


class NIMError(RuntimeError):
    pass


def chat_complete(
    api_key: str,
    *,
    system: str,
    user: str,
    model: Optional[str] = None,
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    seed: Optional[int] = None,
    top_p: Optional[float] = None,
    timeout: Optional[int] = None,
) -> dict[str, Any]:
    if model is None:
        model = os.environ.get("NIM_MODEL") or DEFAULT_MODEL
    if temperature is None:
        temperature = DEFAULT_TEMPERATURE
    if max_tokens is None:
        max_tokens = DEFAULT_MAX_TOKENS
    if seed is None:
        seed = DEFAULT_SEED
    if top_p is None:
        top_p = DEFAULT_TOP_P
    if timeout is None:
        timeout = TIMEOUT
    """Call NIM chat completions and parse the model's JSON response.

    Retries on 429 / 5xx with exponential backoff (1s, 2s, 4s).
    Raises NIMError on terminal failure.
    """
    body: dict[str, Any] = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": temperature,
        "top_p": top_p,
        "max_tokens": max_tokens,
        "response_format": {"type": "json_object"},
        "stream": False,
    }
    # Some NIM models honor `seed` for reproducibility; harmless if ignored.
    if seed is not None:
        body["seed"] = seed
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    last_err: Exception | None = None
    for attempt in range(MAX_RETRIES):
        try:
            r = requests.post(NIM_URL, headers=headers, json=body, timeout=timeout)
        except requests.RequestException as e:
            last_err = e
            _backoff(attempt)
            continue

        if r.status_code == 429 or 500 <= r.status_code < 600:
            last_err = NIMError(f"HTTP {r.status_code}: {r.text[:300]}")
            _backoff(attempt)
            continue

        if not r.ok:
            raise NIMError(f"HTTP {r.status_code}: {r.text[:500]}")

        try:
            payload = r.json()
            content = payload["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError) as e:
            raise NIMError(f"unexpected response shape: {e}") from e

        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            # Some models wrap JSON in ```json ... ``` fences despite response_format.
            stripped = _strip_fences(content)
            try:
                return json.loads(stripped)
            except json.JSONDecodeError:
                raise NIMError(f"model did not return JSON: {e} — got {content[:200]!r}") from e

    raise NIMError(f"all {MAX_RETRIES} attempts failed: {last_err}")


def _backoff(attempt: int) -> None:
    time.sleep(2**attempt)


def _strip_fences(s: str) -> str:
    s = s.strip()
    if s.startswith("```"):
        lines = s.splitlines()
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        s = "\n".join(lines)
    return s.strip()
