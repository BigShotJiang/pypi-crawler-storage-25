# OpsLabel CLI

Internal QA CLI for [opslabel.in](https://opslabel.in) contributors.

## Install

```bash
pip install opslabel
```

Requires Python 3.10+.

## Usage

Generate a pairing code on the dashboard at https://opslabel.in/app and follow the on-screen instructions to authenticate this machine.

For all available commands, run:

```bash
opslabel --help
```

### `opslabel lint <task-dir>`

Local-only TB2 reviewer-checklist linter. No auth required, no network calls (except optional Docker for the multi-run oracle check).

```bash
opslabel lint ./my-tb2-task
opslabel lint ./my-task --no-multi-run --quiet
opslabel lint ./my-task --r3-mode=per-milestone
```

Writes `lint-report.json` (path overridable with `--json-out`) and prints a coloured per-check table plus a summary line that surfaces PASS, FAIL, and NEEDS_REVIEW separately. Exit code is non-zero if any FAIL is present (CI-friendly).

## License

MIT — see [LICENSE](LICENSE).
