"""MCP server for deja — thin wrappers over core. No business logic here."""
from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager
from typing import Optional

from mcp.server.fastmcp import FastMCP

from deja.config import load_config
from deja.core.store import MemoryStore
from deja.interfaces.cli import _format_load_result
from deja.llm.factory import create_embedding_adapter

logger = logging.getLogger(__name__)

_store: Optional[MemoryStore] = None


async def _get_store() -> MemoryStore:
    global _store
    if _store is None:
        _store = MemoryStore(load_config())
        await _store.init_db()
    return _store


@asynccontextmanager
async def _lifespan(server):
    yield
    if _store is not None:
        await _store.close()


mcp = FastMCP("deja", lifespan=_lifespan)


@mcp.tool()
async def memory_load(project: Optional[str] = None, context: Optional[str] = None) -> str:
    """Load memories at session start. Returns type-budgeted memories as compact text
    (top-5 per type for gotcha/decision/preference/pattern, top-3 procedures by reuse,
    top-3 recent progress). Call this at the beginning of every session.

    context: task description to re-rank memories by relevance instead of raw confidence.
    Always pass a short summary of what the user wants to work on — e.g. "fix auth bug in
    login flow" or "add dark mode to dashboard". Without context, memories are sorted by
    raw confidence and the most relevant ones may not surface.
    """
    store = await _get_store()
    config = load_config()
    embedding_adapter = await create_embedding_adapter(config) if context else None
    result = await store.load_budgeted(project, context=context, embedding_adapter=embedding_adapter)
    await store.confirm_memories([m["id"] for m in result["memories"]])
    return _format_load_result(result)


@mcp.tool()
async def memory_save(
    content: str,
    type: str,
    project: Optional[str] = None,
    confidence: float = 1.0,
    category: str = "agent",
    domain: Optional[str] = None,
) -> str:
    """Save a memory to the vault. Deduplicates automatically — if a near-identical
    memory already exists, its confidence is bumped instead of inserting a duplicate.

    type: preference | pattern | decision | gotcha | progress | procedure
    category: user (preferences/habits) | agent (operational knowledge)
    domain: debug | build | test | deploy | research (optional, for procedure type)
    """
    store = await _get_store()
    config = load_config()

    embedding_bytes = None
    embedding_adapter = await create_embedding_adapter(config)
    if embedding_adapter is not None:
        try:
            from deja.llm.embedding import EmbeddingAdapter
            emb = await embedding_adapter.embed(content)
            embedding_bytes = EmbeddingAdapter.to_bytes(emb)
        except Exception as e:
            logger.warning("Embedding generation failed, memory saved without embedding: %s", e)

    # Per-memory content cap: surface as a structured error so the agent
    # sees the directive message and can split before retrying.
    from deja.core.store.policy import MemoryTooLongError
    try:
        result = await store.save(
            {
                "content": content,
                "type": type,
                "project": project,
                "scope": f"project:{project}" if project else "global",
                "confidence": confidence,
                "category": category,
                "domain": domain,
                "source": "mcp",
            },
            embedding=embedding_bytes,
        )
    except MemoryTooLongError as e:
        return json.dumps({
            "error": str(e),
            "kind": "memory_too_long",
            "content_length": e.content_length,
            "limit": e.limit,
        })

    # Bug R3 (2026-04-22): surface the cloud-push outcome to the agent.
    # Previously the ``(ok, msg)`` tuple returned by ``push_memory`` was
    # discarded and the response was always ``{"status": "saved"}`` —
    # so an agent with an expired PAT saw every save "succeed" while
    # memories silently piled up local-only until the user ran
    # ``deja sync`` by hand. The agent now sees ``cloud`` in
    # {"ok", "skipped", "failed"} and can react (surface to user,
    # prompt re-login) instead of trusting a misleading success.
    cloud_status = "skipped"
    cloud_reason: Optional[str] = None
    if config.cloud.sync_on_save:
        from deja.cloud import get_token, push_memory
        if get_token(config):
            # Bug N5 (2026-04-19): trigger → triggerCmds translation now lives
            # in ``_sanitize_for_push``; eager push delegates to the same path
            # as batch ``sync_push`` so the three codepaths can't drift again.
            ok, msg = push_memory(result.cloud_data, config)
            cloud_status = "ok" if ok else "failed"
            cloud_reason = None if ok else msg

    return json.dumps({
        "id": result.id,
        "status": "saved",
        "cloud": cloud_status,
        "cloud_reason": cloud_reason,
    })


@mcp.tool()
async def memory_search(
    query: str,
    project: Optional[str] = None,
    type: Optional[str] = None,
    limit: int = 10,
) -> str:
    """Full-text search over active memories. Use when looking for specific knowledge
    mid-session. With project: searches global + that project. Without: all scopes."""
    store = await _get_store()
    config = load_config()
    embedding_adapter = await create_embedding_adapter(config)
    results = await store.search(query, project, mem_type=type, limit=limit, embedding_adapter=embedding_adapter)
    return json.dumps(results, default=str)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
