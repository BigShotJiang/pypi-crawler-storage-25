from __future__ import annotations

import asyncio
from typing import Optional

import typer

from deja.core.reflection import ReflectionEngine
from deja.llm.embedding import EmbeddingAdapter
from deja.llm.factory import create_adapter, create_embedding_adapter
from ._helpers import _get_config, _get_store


def register(app: typer.Typer) -> None:

    @app.command()
    def reflect(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Project to reflect on."),
        agent_mode: bool = typer.Option(
            False, "--agent-mode", "-a",
            help="Print memory dump + instructions for the coding agent to reflect. No LLM call.",
        ),
    ):
        """Reflect on memories: compress (Observer/Reflector), decay, promote, archive.

        Two modes:

        Agent mode (--agent-mode): prints a memory dump with instructions for the active
        coding agent (Claude Code, Codex, Gemini CLI) to execute deja commands directly.
        Zero extra API cost — the agent is already being billed for the session.

        Default mode: always runs decay/promote/archive. If reflection.provider is configured,
        also runs Observer and Reflector passes; otherwise those are silently skipped.
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                if agent_mode:
                    engine = ReflectionEngine(store, config.reflection)
                    return "agent_mode", await engine.agent_mode_prompt(project)
                adapter = await create_adapter(config, "reflection")
                engine = ReflectionEngine(store, config.reflection, adapter)
                return "done", await engine.run_full(project)
            finally:
                await store.close()

        result_type, data = asyncio.run(_run())

        if result_type == "agent_mode":
            typer.echo(data)
        else:
            results = data
            lines = ["Reflection complete:"]
            if results.get("observer"):
                lines.append(f"  Observer:  {results['observer']} observations created")
            if results.get("reflector"):
                lines.append(f"  Reflector: {results['reflector']} observations condensed")
            if results.get("decay"):
                lines.append(f"  Decay:     {results['decay']} memories decayed")
            if results.get("promote"):
                lines.append(f"  Promote:   {results['promote']} patterns promoted to global")
            dedup = results.get("dedup_fuzzy") or {}
            if dedup.get("merged") or dedup.get("archived"):
                lines.append(
                    f"  Dedup:     {dedup.get('merged', 0)} merged, "
                    f"{dedup.get('archived', 0)} near-duplicates archived"
                )
            if results.get("archive"):
                lines.append(f"  Archive:   {results['archive']} memories archived")
            if len(lines) == 1:
                lines.append("  Nothing to do.")
            typer.echo("\n".join(lines))

    @app.command()
    def embed(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Scope backfill to global + this project. Omit to backfill all."),
    ):
        """Generate embeddings for memories that don't have one yet.

        Run this after enabling embedding.provider in ~/.deja/config.yaml to
        backfill embeddings for memories saved before semantic search was configured.

        Requires:
          1. embedding.provider set to 'ollama' in ~/.deja/config.yaml
          2. Ollama running with the configured model pulled:
               ollama pull nomic-embed-text
        """
        async def _run():
            config = _get_config()
            embedding_adapter = await create_embedding_adapter(config)
            if embedding_adapter is None:
                typer.echo(
                    "No embedding provider configured.\n"
                    "Set embedding.provider in ~/.deja/config.yaml, e.g.:\n"
                    "  embedding:\n"
                    "    provider: ollama\n"
                    "    model: nomic-embed-text",
                    err=True,
                )
                return 0, 0

            store = _get_store(config)
            await store.init_db()
            try:
                memories = await store.get_memories_without_embeddings(project)
                done = 0
                failed = 0
                for mem in memories:
                    try:
                        emb = await embedding_adapter.embed(mem["content"])
                        emb_bytes = EmbeddingAdapter.to_bytes(emb)
                        await store.save_embedding(mem["id"], emb_bytes)
                        done += 1
                    except Exception as e:
                        typer.echo(f"[deja] Failed to embed {mem['id']}: {e}", err=True)
                        failed += 1
                return done, failed
            finally:
                await store.close()

        done, failed = asyncio.run(_run())
        typer.echo(f"Embedded {done} memories." + (f" {failed} failed." if failed else ""))

    @app.command()
    def invalidate(
        memory_id: str = typer.Argument(..., help="Memory ID to mark as superseded."),
    ):
        """Mark a memory as invalidated (superseded by newer information).

        Unlike archive (soft-delete for low-confidence memories), invalidate signals that
        this memory has been actively contradicted — used in agent-mode reflection when
        the agent identifies a memory that is no longer correct.
        """
        async def _run():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                await store.invalidate(memory_id)
            finally:
                await store.close()

        asyncio.run(_run())
        typer.echo(f"Invalidated: {memory_id}")
