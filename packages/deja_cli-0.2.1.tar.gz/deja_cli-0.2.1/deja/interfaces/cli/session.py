from __future__ import annotations

import asyncio
import re
from pathlib import Path
from typing import Optional

import typer

from deja.llm.factory import create_adapter, create_embedding_adapter
from ._helpers import _get_config, _get_store, _embed_and_save


def _parse_transcript_for_path(path: Path, content: str) -> str:
    """Auto-detect session file format from filename and convert to plain text.

    Dispatches to the appropriate watcher's parse_transcript() based on filename:
      session-*.json  → Gemini CLI JSON format
      rollout-*.jsonl → Codex CLI JSONL format
      anything else   → plain text (Claude Code summary.md, custom files)

    This ensures deja save-session --transcript works correctly for all agents,
    not just Claude Code's plain-text summary.md.
    """
    name = path.name
    if name.startswith("session-") and name.endswith(".json"):
        from deja.ingest.watchers.gemini_cli import GeminiCLIWatcher
        return GeminiCLIWatcher.__new__(GeminiCLIWatcher).parse_transcript(content)
    if name.startswith("rollout-") and name.endswith(".jsonl"):
        from deja.ingest.watchers.codex_cli import CodexCLIWatcher
        return CodexCLIWatcher.__new__(CodexCLIWatcher).parse_transcript(content)
    return content


def _parse_skills_markdown(content: str, project: Optional[str], scope: str) -> list[dict]:
    """Parse a markdown file into procedure memories by splitting on ## headings."""
    sections = re.split(r"^#{1,3} ", content, flags=re.MULTILINE)
    memories = []
    for section in sections:
        section = section.strip()
        if not section:
            continue
        lines = section.splitlines()
        heading = lines[0].strip()
        body = "\n".join(lines[1:]).strip()
        if not heading:
            continue
        mem_content = f"{heading}: {body}" if body else heading
        memories.append(
            {
                "type": "procedure",
                "category": "agent",
                "content": mem_content,
                "scope": scope,
                "project": project,
                "source": "ingest-skills",
                "confidence": 1.0,
                "domain": None,
            }
        )
    return memories


def register(app: typer.Typer) -> None:

    @app.command(name="save-session")
    def save_session(
        transcript: Optional[str] = typer.Option(None, "--transcript", "-t", help="Path to transcript file"),
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name"),
    ):
        """Extract memories from a session transcript.

        Without --transcript: prints an extraction prompt to stdout. The agent reads
        it, identifies memories from the session, and calls deja save for each one.
        This requires no API key — the agent already running IS the model.
        Works identically for Claude Code, Gemini CLI, Codex, or any agent.

        With --transcript: reads the file and uses the configured LLM to extract
        memories automatically (requires extraction.provider set in config).
        File format is auto-detected from the filename:
          session-*.json  → Gemini CLI
          rollout-*.jsonl → Codex CLI
          anything else   → plain text (Claude Code summary.md)
        """
        from deja.core.extractor import EXTRACTION_SYSTEM

        if transcript is None:
            project_hint = f" for project '{project}'" if project else ""
            typer.echo(
                f"Review this session's context{project_hint} and identify memories worth keeping.\n\n"
                f"{EXTRACTION_SYSTEM}\n\n"
                f"For each memory you identify, call:\n"
                f"  deja save \"<content>\" --type <type>"
                + (f" --project {project}" if project else "")
                + "\n\n"
                f"Only save things that are non-obvious, reusable, and important. "
                f"If nothing is worth saving, do nothing."
            )
            return

        async def _run():
            config = _get_config()
            adapter = await create_adapter(config, "extraction")
            if adapter is None:
                typer.echo(
                    "No LLM configured for extraction. Set extraction.provider in "
                    "~/.deja/config.yaml, or run `deja save-session` without "
                    "--transcript to let the agent extract memories interactively.",
                    err=True,
                )
                raise typer.Exit(1)

            transcript_path = Path(transcript).expanduser()
            if not transcript_path.exists():
                typer.echo(f"Transcript file not found: {transcript_path}", err=True)
                raise typer.Exit(1)

            content = transcript_path.read_text(encoding="utf-8", errors="replace")
            content = _parse_transcript_for_path(transcript_path, content)

            store = _get_store(config)
            await store.init_db()
            try:
                from deja.core.extractor import extract_memories
                # Bug R2 (2026-04-22): extract_memories now raises on
                # transport / adapter / JSON-parse failures instead of
                # returning []. Catch and exit cleanly so the user sees
                # the real cause instead of a bare traceback.
                try:
                    memories = await extract_memories(
                        content, project or "unknown", "save-session", adapter
                    )
                except Exception as e:
                    typer.echo(f"Extraction failed: {e}", err=True)
                    raise typer.Exit(1)
                embedding_adapter = await create_embedding_adapter(config)
                saved = await _embed_and_save(memories, store, embedding_adapter)
                return saved
            finally:
                await store.close()

        count = asyncio.run(_run())
        typer.echo(f"Saved {count} memories from transcript.")

    @app.command(name="ingest-skills")
    def ingest_skills(
        path: str = typer.Argument(..., help="Path to skill/rules file to import (markdown, plain text, .cursorrules, etc.)"),
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name to scope imported memories to."),
        dry_run: bool = typer.Option(False, "--dry-run", help="Print what would be saved without writing to the store."),
        no_llm: bool = typer.Option(False, "--no-llm", help="Skip LLM extraction. Parse markdown sections directly as procedure memories."),
    ):
        """Import an existing skill/rules file as procedure + pattern memories.

        Accepts any plain-text file: markdown skill docs, .cursorrules, AGENTS.md,
        custom rules files, etc.

        LLM mode (default): passes the file through the extraction pipeline, same as
        `deja save-session --transcript`. Requires extraction.provider set in config.
        Infers types (procedure, pattern, gotcha) from content.

        --no-llm mode: parses markdown ## headings as section boundaries. Each section
        becomes one procedure memory (heading as title, body as content). Zero API cost.

        --dry-run: prints what would be saved without touching the store.
        """
        skill_path = Path(path).expanduser()
        if not skill_path.exists():
            typer.echo(f"File not found: {skill_path}", err=True)
            raise typer.Exit(1)

        content = skill_path.read_text(encoding="utf-8", errors="replace")
        if not content.strip():
            typer.echo("File is empty.", err=True)
            raise typer.Exit(1)

        scope = f"project:{project}" if project else "global"

        if no_llm:
            memories = _parse_skills_markdown(content, project, scope)
            if not memories:
                typer.echo("No ## sections found. Use LLM mode or add markdown headings.", err=True)
                raise typer.Exit(1)
        else:
            async def _extract():
                config = _get_config()
                adapter = await create_adapter(config, "extraction")
                if adapter is None:
                    typer.echo(
                        "No LLM configured for extraction. Set extraction.provider in "
                        "~/.deja/config.yaml, or use --no-llm to parse markdown headings directly.",
                        err=True,
                    )
                    raise typer.Exit(1)
                from deja.core.extractor import extract_memories
                return await extract_memories(content, project or "unknown", "ingest-skills", adapter)

            # Bug R2 (2026-04-22): extract_memories propagates adapter
            # errors; catch and exit cleanly with the error message.
            try:
                memories = asyncio.run(_extract())
            except typer.Exit:
                raise
            except Exception as e:
                typer.echo(f"Extraction failed: {e}", err=True)
                raise typer.Exit(1)
            if not memories:
                typer.echo("Extraction returned no memories. Try --no-llm or check the file format.", err=True)
                raise typer.Exit(1)

            if project:
                for mem in memories:
                    mem["scope"] = scope
                    mem["project"] = project

        if dry_run:
            typer.echo(f"[dry-run] Would save {len(memories)} memories from {skill_path.name}:")
            for mem in memories:
                label = f"[{mem['type']}]"
                if mem.get("project"):
                    label += f"({mem['project']})"
                typer.echo(f"  {label} {mem['content'][:100]}")
            return

        async def _save():
            config = _get_config()
            store = _get_store(config)
            await store.init_db()
            try:
                embedding_adapter = await create_embedding_adapter(config)
                return await _embed_and_save(memories, store, embedding_adapter)
            finally:
                await store.close()

        saved = asyncio.run(_save())
        typer.echo(f"Saved {saved} memories from {skill_path.name}.")
