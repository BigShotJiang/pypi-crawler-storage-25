from __future__ import annotations

import asyncio
from typing import Optional

import typer

from deja.core.store._helpers import _parse_dt

from ._helpers import _get_config, _get_store


def register(app: typer.Typer) -> None:

    @app.command()
    def login(
        token: Optional[str] = typer.Option(None, "--token", "-t", help="Paste a PAT directly (skips browser, for headless/CI)."),
        endpoint: Optional[str] = typer.Option(None, "--endpoint", help="Custom API endpoint, e.g. http://localhost:3001"),
    ):
        """Log in to deja.sh cloud sync.

        Opens deja.sh in your browser. If you're already logged in, authorization
        completes instantly with no clicks required.

        For headless / CI environments, pass a token directly:

          deja login --token deja_<your_token>
        """
        from deja.cloud import save_auth, whoami as cloud_whoami, clear_auth

        config = _get_config()
        if endpoint:
            config.cloud.endpoint = endpoint

        if token:
            if not token.startswith("deja_"):
                typer.echo("Invalid token: must start with 'deja_'.", err=True)
                raise typer.Exit(1)
            pat = token
        else:
            from deja.cloud import login_browser
            try:
                pat = login_browser(config)
            except Exception as e:
                typer.echo(f"Login failed: {e}", err=True)
                raise typer.Exit(1)

        # Bug N6 (2026-04-19): persist the endpoint alongside the token
        # so subsequent commands resolve it via _get_endpoint() instead
        # of falling back to config / DEFAULT_ENDPOINT. Without this,
        # `deja login --endpoint http://localhost:3001 --token X`
        # looked successful but the next `deja sync` shipped the PAT to
        # api.deja.sh (or the config-file endpoint, if set) — silent
        # misroute, possibly to a different production cluster.
        auth_payload: dict = {"access_token": pat}
        if endpoint:
            auth_payload["endpoint"] = endpoint
        save_auth(auth_payload)

        try:
            user = cloud_whoami(config)
            if not user:
                raise RuntimeError("/auth/me returned nothing — token may be invalid")
            typer.echo(f"Logged in as {user.get('email', 'unknown')}")
        except Exception as e:
            clear_auth()
            typer.echo(f"Login failed: {e}", err=True)
            raise typer.Exit(1)

    @app.command()
    def logout():
        """Log out of deja.sh and remove local credentials."""
        from deja.cloud import clear_auth, load_auth

        if not load_auth():
            typer.echo("Not logged in.")
            return

        clear_auth()
        typer.echo("Logged out.")

    @app.command()
    def whoami():
        """Show the currently logged-in deja.sh account."""
        from deja.cloud import whoami as cloud_whoami

        config = _get_config()
        user = cloud_whoami(config)
        if not user:
            typer.echo("Not logged in. Run `deja login`.")
            return

        typer.echo(f"Email:    {user.get('email', 'unknown')}")
        typer.echo(f"Plan:     {user.get('plan', 'unknown')}")
        typer.echo(f"Memories: {user.get('memoryCount', 'unknown')}")

    @app.command()
    def sync(
        project: Optional[str] = typer.Option(None, "--project", "-p", help="Push only this project's memories. Implies push-only and does not advance the global pull cursor."),
        push_only: bool = typer.Option(False, "--push", help="Push local changes only, skip pull."),
        pull_only: bool = typer.Option(False, "--pull", help="Pull cloud changes only, skip push."),
    ):
        """Sync memories with deja.sh cloud (push local + pull remote).

        ``-p <project>`` scopes the push to one project AND skips pull, so it
        will not move the global cursor past edits in other projects you
        haven't pushed yet. Run an unscoped ``deja sync`` to pull and advance
        the cursor.
        """
        from deja.cloud import (
            _sanitize_for_pull,
            get_token, sync_push, sync_pull,
            load_sync_state, update_sync_state,
            load_stuck_ids, save_stuck_ids,
        )

        config = _get_config()
        if not get_token(config):
            typer.echo("Not logged in. Run `deja login`.", err=True)
            raise typer.Exit(1)

        async def _run():
            store = _get_store(config)
            await store.init_db()
            state = load_sync_state()
            endpoint = config.cloud.endpoint
            last_synced = state.get(endpoint)
            previously_stuck = load_stuck_ids(endpoint)
            pushed = 0
            pulled = 0
            push_conflicts: list[dict] = []
            # ID → first-line preview so we can surface "stuck rows" in the
            # CLI warning. Lets the user `deja show` or `deja archive`
            # without grepping for the localId by hand.
            stuck_previews: dict[str, str] = {}

            try:
                if not pull_only:
                    # list_for_sync (NOT list_all) so locally-archived rows
                    # propagate to the cloud — list_all filters them out, which
                    # was the bug fixed alongside cloud Phase 3.4. invalidated
                    # rows stay excluded (local fuzzy-dedup state).
                    all_memories = await store.list_for_sync()
                    if project:
                        all_memories = [m for m in all_memories if m.get("project") == project]
                    if last_synced:
                        # Bug M6 (2026-04-18): the previous code did
                        # ``datetime.fromisoformat(s).replace(tzinfo=utc)``
                        # which RELABELS the wall clock as UTC instead of
                        # CONVERTING to UTC. So a cursor stored as e.g.
                        # ``"2026-04-19T10:00:00+05:30"`` (=04:30Z) was
                        # misread as 10:00Z and silently dropped any row
                        # whose real updated_at was between 04:30Z and
                        # 10:00Z. ``_parse_dt`` only adds UTC when the
                        # parsed dt is naive; aware dts are left alone
                        # (Python compares aware dts by UTC instant, so
                        # the comparison is correct without astimezone).
                        cutoff = _parse_dt(last_synced)
                        to_push = [
                            m for m in all_memories
                            if _parse_dt(m.get("updated_at", "1970-01-01")) > cutoff
                        ]
                    else:
                        to_push = all_memories

                    # Force-include previously-stuck rows even though their
                    # updated_at hasn't moved past the cursor. Without this,
                    # a row rejected once for content_too_long / quota
                    # falls out of every subsequent push and the warning
                    # silently stops re-firing — the user has no signal
                    # those rows are stranded. We dedup by id since stuck
                    # rows often *also* match the cursor on the very first
                    # push (before the cursor advanced past them).
                    if previously_stuck:
                        already = {m.get("id") for m in to_push}
                        for m in all_memories:
                            mid = m.get("id")
                            if mid in previously_stuck and mid not in already:
                                to_push.append(m)

                    if to_push:
                        result = sync_push(to_push, config)
                        pushed = result.get("accepted", 0)
                        push_conflicts = result.get("conflicts") or []

                        # Recompute the stuck set from this push's conflicts.
                        #
                        # Bug H3 (2026-04-18): when ``-p`` was set, the old
                        # code overwrote the *whole* stuck-set with only the
                        # requested project's conflicts, wiping entries from
                        # other projects. Fix: when scoped, only update the
                        # IDs we actually pushed (i.e. ones in this project's
                        # batch); preserve everything else.
                        #
                        # Bug M7 (2026-04-18): if the cloud returns a
                        # conflict without a ``localId`` (a future cloud
                        # release matching by server-side ``id``, or a
                        # malformed response), it gets silently filtered
                        # out of ``new_conflict_map``. Without the guard
                        # below, the full-sync branch would replace the
                        # stuck set with ``{}`` and drop every existing
                        # entry — even though the cloud is *still rejecting*
                        # those rows. Conservative defense: when ANY
                        # conflict lacks a ``localId``, preserve the
                        # currently-stuck entries that were in this push
                        # (we have no evidence they were accepted).
                        pushed_ids = {m.get("id") for m in to_push}
                        new_conflict_map = {
                            c["localId"]: (c.get("reason") or "unknown")
                            for c in push_conflicts if c.get("localId")
                        }
                        has_unmatched_conflicts = any(
                            not c.get("localId") for c in push_conflicts
                        )
                        if project:
                            # Project-scoped: rebuild the stuck-set as
                            # ``other-project entries`` ∪ ``this push's conflicts``.
                            # Drop entries we pushed-and-accepted (i.e. were
                            # in our batch but didn't come back as conflicts).
                            new_stuck = {
                                mid: reason for mid, reason in previously_stuck.items()
                                if mid not in pushed_ids
                            }
                        else:
                            # Full sync: every previously-stuck row was
                            # force-included in this push, so an entry that
                            # doesn't reappear in conflicts must have been
                            # accepted. Same shape as the project-scoped
                            # branch — preserve everything we *didn't* push.
                            new_stuck = {
                                mid: reason for mid, reason in previously_stuck.items()
                                if mid not in pushed_ids
                            }
                        # M7 conservative defense: if any conflict came back
                        # without a localId, we can't tell *which* of the
                        # pushed rows it refers to. Don't conclude that any
                        # of them were accepted — keep their existing stuck
                        # entries (matched conflicts overwrite below).
                        if has_unmatched_conflicts:
                            for mid, reason in previously_stuck.items():
                                if mid in pushed_ids:
                                    new_stuck.setdefault(mid, reason)
                        new_stuck.update(new_conflict_map)
                        if new_stuck != previously_stuck:
                            save_stuck_ids(endpoint, new_stuck)

                        # Build previews only for rows surfaced *this run*
                        # (the user can't act on a row they aren't being
                        # warned about right now).
                        if new_conflict_map:
                            preview_lookup = {m.get("id"): (m.get("content") or "")
                                              for m in all_memories}
                            for stuck_id in new_conflict_map:
                                content = preview_lookup.get(stuck_id, "")
                                first_line = content.splitlines()[0] if content else ""
                                stuck_previews[stuck_id] = first_line[:80]

                # Bug H2 (2026-04-18): ``-p`` used to advance the global
                # cursor even though only one project was pushed. Edits in
                # other projects that pre-dated the cursor would never reach
                # the cloud (next full sync's ``updated_at > cursor`` filter
                # excluded them). Fix: ``-p`` is push-only-and-scoped — no
                # pull, no cursor advance, leaving global state untouched.
                if not push_only and not project:
                    result = sync_pull(since=last_synced, config=config)
                    cloud_memories = result.get("memories", [])
                    server_time = result.get("serverTime")

                    for m in cloud_memories:
                        # Translate camelCase cloud payload to snake_case
                        # local schema. Without this, every cloud-only field
                        # (localId, triggerCmds, lastConfirmed, archivedAt,
                        # createdAt, updatedAt, reuseCount) would be silently
                        # dropped by upsert's snake_case allowlist.
                        await store.upsert(_sanitize_for_pull(m), merge_strategy="update-confidence")
                    pulled = len(cloud_memories)

                    if server_time:
                        # Bug M5 (2026-04-18): use ``update_sync_state``
                        # for the cursor write so the read-modify-write is
                        # serialized cross-process. The previous "re-read
                        # state from disk before writing" mitigation
                        # narrowed the race window for this one path but
                        # didn't close it; the locked helper does.
                        update_sync_state(
                            lambda s: s.__setitem__(endpoint, server_time)
                        )

            finally:
                await store.close()

            return pushed, pulled, push_conflicts, stuck_previews

        pushed, pulled, push_conflicts, stuck_previews = asyncio.run(_run())
        typer.echo(f"Sync complete. Pushed: {pushed}, pulled: {pulled}")
        if push_conflicts:
            # Mirror the structured warning sync_push already logged to stderr,
            # but make it visible on stdout next to "Pushed: N" so the user
            # can't miss that some rows were silently rejected. Bucket by
            # reason — a quota-blown free user can have hundreds.
            by_reason: dict[str, int] = {}
            for c in push_conflicts:
                reason = c.get("reason") or "unknown"
                by_reason[reason] = by_reason.get(reason, 0) + 1
            for reason, count in sorted(by_reason.items()):
                if reason == "quota_exceeded":
                    typer.echo(
                        f"  ⚠ {count} rejected: quota exceeded — "
                        "upgrade at https://deja.sh/dashboard/billing"
                    )
                elif reason == "content_too_long":
                    typer.echo(
                        f"  ⚠ {count} rejected: content exceeds plan's per-memory limit"
                    )
                else:
                    typer.echo(f"  ⚠ {count} rejected: {reason}")
            # Show up to 5 stuck localIds + content preview so the user can
            # act (deja show / deja archive). Without this, they'd have to
            # diff local vs cloud by hand to find which rows are stranded.
            if stuck_previews:
                shown = list(stuck_previews.items())[:5]
                for mid, preview in shown:
                    typer.echo(f"     • {mid}: {preview}")
                remaining = len(stuck_previews) - len(shown)
                if remaining > 0:
                    typer.echo(f"     • ... and {remaining} more (run `deja sync` again to see)")
