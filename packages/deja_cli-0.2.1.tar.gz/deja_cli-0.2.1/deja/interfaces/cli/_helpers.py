from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from deja.config import load_config
from deja.core.store import MemoryStore
from deja.llm.embedding import EmbeddingAdapter

logger = logging.getLogger(__name__)


def _get_config():
    return load_config()


def _get_store(config=None) -> MemoryStore:
    if config is None:
        config = _get_config()
    return MemoryStore(config)


async def _init_store(store: MemoryStore) -> None:
    await store.init_db()


async def _embed_and_save(
    memories: list[dict],
    store: MemoryStore,
    embedding_adapter,  # Optional[EmbeddingAdapter]
) -> int:
    """Embed each memory (if adapter available) and save in a single transaction."""
    items: list[tuple[dict, bytes | None]] = []
    for memory in memories:
        emb_bytes = None
        if embedding_adapter is not None:
            try:
                emb = await embedding_adapter.embed(memory["content"])
                emb_bytes = EmbeddingAdapter.to_bytes(emb)
            except Exception as e:
                logger.warning("Embedding failed: %s", e)
        items.append((memory, emb_bytes))
    if items:
        await store.save_batch(items)
    return len(items)


def _format_memory_text(mem: dict) -> str:
    scope = mem["scope"]
    scope_label = "global" if scope == "global" else mem.get("project", scope)
    domain = mem.get("domain")
    domain_tag = f" [domain:{domain}]" if domain else ""
    return (
        f"[{mem['type']}]{domain_tag} [{scope_label}] {mem['content']} "
        f"(confidence: {mem['confidence']:.1f})"
    )


def _format_load_result(result: dict) -> str:
    """Render a load_budgeted() result as compact, agent-readable text."""
    memories = result["memories"]
    total = result["total"]
    overflow = result["overflow"]
    project = result["project"]
    overflow_hints = result.get("overflow_hints", [])

    if not memories and total == 0:
        return "No memories found."

    header = f"=== deja: {len(memories)}/{total} memories"
    if project != "global":
        header += f" (project: {project})"
    header += " ==="

    lines = [header]

    by_type: dict[str, list[dict]] = {}
    for mem in memories:
        t = mem.get("type", "pattern")
        by_type.setdefault(t, []).append(mem)

    type_order = ["preference", "gotcha", "decision", "pattern", "procedure", "progress"]
    for mem_type in type_order:
        mems = by_type.get(mem_type, [])
        if not mems:
            continue
        lines.append("")
        for mem in mems:
            label = f"[{mem_type}]"
            if mem.get("domain"):
                label += f"[{mem['domain']}]"
            if mem_type == "procedure" and mem.get("reuse_count", 0):
                label += f"(reuse:{mem['reuse_count']})"
            if mem.get("scope") != "global":
                label += f"({mem.get('project', '')})"
            lines.append(f"{label} {mem['content']}")

    if overflow > 0:
        lines.append("")
        search_cmd = 'deja search "<topic>"'
        if project != "global":
            search_cmd += f" --project {project}"
        hints_str = ", ".join(f"{h['type']} +{h['overflow']}" for h in overflow_hints)
        lines.append(f"--- {overflow} more memories available. Run: {search_cmd} ---")
        if hints_str:
            lines.append(f"Overflow: {hints_str}")

    return "\n".join(lines)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _prepare_import_memory(raw: object, project: Optional[str]) -> tuple[Optional[dict], Optional[str]]:
    """Validate and normalize one imported memory record."""
    if not isinstance(raw, dict):
        return None, "record is not a JSON object"

    required_fields = ("id", "type", "content")
    for field in required_fields:
        value = raw.get(field)
        if not isinstance(value, str) or not value.strip():
            return None, f"missing required field: {field}"

    scope = f"project:{project}" if project else raw.get("scope")
    if not isinstance(scope, str) or not scope.strip():
        return None, "missing required field: scope"

    project_name = project if project else raw.get("project")
    created_at = raw.get("created_at") or _now_iso()
    updated_at = raw.get("updated_at") or created_at
    last_confirmed = raw.get("last_confirmed") or updated_at

    confidence = raw.get("confidence", 1.0)
    try:
        confidence = float(confidence)
    except (TypeError, ValueError):
        return None, "invalid confidence value"
    confidence = max(0.0, min(1.0, confidence))

    reuse_count = raw.get("reuse_count", 0)
    try:
        reuse_count = int(reuse_count)
    except (TypeError, ValueError):
        reuse_count = 0

    normalized = {
        "id": raw["id"],
        "type": raw["type"],
        "category": raw.get("category", "agent"),
        "content": raw["content"],
        "scope": scope,
        "project": project_name,
        "source": raw.get("source"),
        "confidence": confidence,
        "reuse_count": reuse_count,
        "domain": raw.get("domain"),
        "entity_graph": raw.get("entity_graph"),
        "created_at": created_at,
        "updated_at": updated_at,
        "last_confirmed": last_confirmed,
        "archived_at": raw.get("archived_at"),
        "invalidated_at": raw.get("invalidated_at"),
    }
    return normalized, None
