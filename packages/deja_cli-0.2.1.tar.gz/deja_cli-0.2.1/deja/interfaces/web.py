"""Web viewer backend for the deja memory vault.

Serves a single-page HTML UI and a minimal JSON API.
Started by `deja viewer`; not imported elsewhere.

Security model:
    - Binds to 127.0.0.1 only (localhost). Not exposed on the network.
    - No authentication. Any local process can read and modify the vault
      via the API (archive, invalidate). This is acceptable for a single-user
      dev tool — the threat model assumes a trusted local machine.
    - Do NOT bind to 0.0.0.0 or expose via a reverse proxy without adding
      authentication first.
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse

from deja.config import load_config
from deja.core.store import MemoryStore

_store: Optional[MemoryStore] = None
_HTML = Path(__file__).parent / "web_ui" / "index.html"


def _get_store() -> MemoryStore:
    assert _store is not None, "Store not initialised"
    return _store


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _store
    config = load_config()
    _store = MemoryStore(config)
    await _store.init_db()
    yield
    await _store.close()


app = FastAPI(title="deja vault", lifespan=lifespan)


# ── UI ────────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    return _HTML.read_text(encoding="utf-8")


# ── API ───────────────────────────────────────────────────────────────────────

@app.get("/api/memories")
async def list_memories(
    project: Optional[str] = Query(None),
    type: Optional[str] = Query(None),
    status: str = Query("active"),
    limit: int = Query(300, ge=1, le=2000),
    offset: int = Query(0, ge=0),
):
    memories, total = await _get_store().list_filtered(
        project=project, mem_type=type, status=status, limit=limit, offset=offset
    )
    return {"memories": memories, "total": total}


@app.get("/api/memories/{memory_id}")
async def get_memory(memory_id: str):
    mem = await _get_store().get(memory_id)
    if not mem:
        raise HTTPException(404, "Memory not found")
    return mem


@app.get("/api/projects")
async def list_projects():
    projects = await _get_store().list_projects()
    return {"projects": projects}


@app.get("/api/stats")
async def get_stats(project: Optional[str] = Query(None)):
    return await _get_store().get_stats(project)


@app.get("/api/search")
async def search_memories(
    q: str = Query(..., min_length=1),
    project: Optional[str] = Query(None),
    type: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
):
    memories = await _get_store().search(
        q, project=project, mem_type=type, limit=limit, track_usage=False
    )
    return {"memories": memories, "query": q}


@app.post("/api/memories/{memory_id}/archive")
async def archive_memory(memory_id: str):
    await _get_store().archive(memory_id)
    return {"ok": True}


@app.post("/api/memories/{memory_id}/invalidate")
async def invalidate_memory(memory_id: str):
    await _get_store().invalidate(memory_id)
    return {"ok": True}
