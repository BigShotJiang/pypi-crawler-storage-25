import logging

# Package-level logger. All deja modules use logging.getLogger(__name__) which
# inherits from this root "deja" logger. Default handler writes to stderr with
# the same "[deja] ..." format the codebase used previously via print().
_logger = logging.getLogger("deja")
if not _logger.handlers:
    _handler = logging.StreamHandler()  # stderr by default
    _handler.setFormatter(logging.Formatter("[deja] %(message)s"))
    _logger.addHandler(_handler)
    _logger.setLevel(logging.INFO)
