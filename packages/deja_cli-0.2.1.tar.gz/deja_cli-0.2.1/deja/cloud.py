from __future__ import annotations

import contextlib
import fcntl
import json
import logging
import os
import secrets
import stat
import tempfile
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Callable, Iterator, Optional
from urllib.parse import parse_qs, urlparse

import httpx

logger = logging.getLogger(__name__)

CLI_REDIRECT_PORT = 51234

AUTH_FILE = Path.home() / ".deja" / "auth.json"
SYNC_STATE_FILE = Path.home() / ".deja" / "sync_state.json"

DEFAULT_ENDPOINT = "https://api.deja.sh"


def _get_endpoint(config=None) -> str:
    """Resolve the effective cloud endpoint for outgoing requests.

    Precedence (highest first):
      1. ``endpoint`` persisted in ``~/.deja/auth.json`` (Bug N6,
         2026-04-19 — written by ``deja login --endpoint X`` so the
         override survives across processes; without this, the override
         was thrown away on process exit and every subsequent command
         misrouted the PAT to the default endpoint).
      2. ``config.cloud.endpoint`` from the loaded YAML config.
      3. ``DEFAULT_ENDPOINT`` (built-in fallback).

    Auth-file override wins because it's the *credential's* endpoint —
    sending a PAT issued by host A to host B is the worst class of
    misroute (silent 401 at best, leaked token at worst). The config
    file is "what to do when no creds are pinned"; the auth file is
    "where these specific creds belong."
    """
    auth = load_auth()
    if auth and auth.get("endpoint"):
        return str(auth["endpoint"]).rstrip("/")
    if config is None:
        return DEFAULT_ENDPOINT
    cloud = getattr(config, "cloud", None)
    if cloud is None:
        return DEFAULT_ENDPOINT
    return getattr(cloud, "endpoint", DEFAULT_ENDPOINT).rstrip("/")


# ── Token storage ─────────────────────────────────────────────────────


def load_auth() -> Optional[dict]:
    if not AUTH_FILE.exists():
        return None
    return json.loads(AUTH_FILE.read_text())


def save_auth(data: dict) -> None:
    # Bug Q2 (2026-04-19 pass 3): atomic rewrite. ``Path.write_text``
    # truncates then writes, so a crash mid-write (Ctrl-C, OOM, kernel
    # panic) leaves ``auth.json`` empty or half-written — ``load_auth``
    # then raises ``json.JSONDecodeError`` on every subsequent command,
    # wedging the user with no recovery short of re-running ``deja
    # login``. Mirrors ``_atomic_write_state`` below: tempfile in the
    # same directory + ``os.replace`` + cleanup on failure.
    # Bug Q3 (2026-04-19 pass 3): 0700 on the parent so new installs
    # don't create a world-readable ~/.deja.
    AUTH_FILE.parent.mkdir(exist_ok=True, mode=0o700)
    payload = json.dumps(data, indent=2)
    fd, tmp_name = tempfile.mkstemp(
        prefix=".auth.", suffix=".tmp", dir=AUTH_FILE.parent,
    )
    os.close(fd)
    tmp_path = Path(tmp_name)
    try:
        # Tighten perms on the tmp file BEFORE rename so there's no
        # window where a 0644 auth file is readable.
        tmp_path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 600
        tmp_path.write_text(payload)
        os.replace(tmp_path, AUTH_FILE)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            tmp_path.unlink()
        raise


def clear_auth() -> None:
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()


def get_token(config=None) -> Optional[str]:
    """Return the stored PAT, or None if not logged in."""
    auth = load_auth()
    if not auth:
        return None
    return auth.get("access_token")


# ── Browser login flow ────────────────────────────────────────────────


def login_browser(config=None) -> str:
    """Open deja.sh in the browser, wait for the CLI callback, exchange code for PAT."""
    endpoint = _get_endpoint(config)
    web_url = getattr(getattr(config, "cloud", None), "web_url", None) or endpoint.replace("api.", "www.", 1)

    state = secrets.token_urlsafe(16)
    code_holder: dict = {}
    ready = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            qs = parse_qs(urlparse(self.path).query)
            returned_state = qs.get("state", [None])[0]
            if returned_state != state:
                code_holder["error"] = "state mismatch — possible CSRF attack"
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"<html><body>State mismatch. Please retry login.</body></html>")
                ready.set()
                return
            code_holder["code"] = qs.get("code", [None])[0]
            code_holder["error"] = qs.get("error", [None])[0]
            self.send_response(200)
            self.end_headers()
            self.wfile.write(
                b"<html><body style='font-family:sans-serif;background:#09090b;color:#fff;"
                b"display:flex;align-items:center;justify-content:center;height:100vh;margin:0'>"
                b"<p>CLI authorized. Return to your terminal.</p>"
                b"<script>window.close()</script></body></html>"
            )
            ready.set()

        def log_message(self, *args):
            pass

    server = HTTPServer(("localhost", CLI_REDIRECT_PORT), Handler)

    auth_url = f"{web_url}/auth/cli?state={state}&port={CLI_REDIRECT_PORT}"
    webbrowser.open(auth_url)
    print(f"Opening deja.sh in your browser…")
    print(f"If it doesn't open, visit: {auth_url}")

    server.handle_request()

    if code_holder.get("error"):
        raise RuntimeError(f"Auth error: {code_holder['error']}")
    if not code_holder.get("code"):
        raise RuntimeError("No auth code received")

    # Exchange one-time code for a PAT
    resp = httpx.post(
        f"{endpoint}/auth/cli/exchange",
        json={"code": code_holder["code"]},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()["token"]


# ── Whoami ────────────────────────────────────────────────────────────


def whoami(config=None) -> Optional[dict]:
    token = get_token(config)
    if not token:
        return None
    endpoint = _get_endpoint(config)
    resp = httpx.get(
        f"{endpoint}/auth/me",
        headers={"Authorization": f"Bearer {token}"},
        timeout=10,
    )
    if not resp.is_success:
        return None
    return resp.json()


# ── Save to cloud ─────────────────────────────────────────────────────


_PUSH_FIELDS = {"content", "type", "project", "confidence", "triggerCmds", "category"}


def push_memory(memory: dict, config=None) -> tuple[bool, Optional[str]]:
    """Push a single memory to cloud. Best-effort, never raises.

    Returns ``(ok, message)``:
    - ``(True, None)`` on success.
    - ``(False, reason)`` on any non-success. ``reason`` is also logged at
      WARNING (quota / auth) or INFO (network / unknown), so callers that
      ignore the return value still get a visible signal on stderr via the
      package's root ``deja`` logger.

    Failure is non-fatal — a failed push never blocks ``deja save``. The
    memory stays in the local SQLite and will be picked up by the next
    ``deja sync``.
    """
    token = get_token(config)
    if not token:
        msg = "not logged in (run `deja login` to enable cloud sync)"
        logger.info("cloud push skipped: %s", msg)
        return False, msg
    endpoint = _get_endpoint(config)
    payload = _sanitize_for_push(memory)
    try:
        resp = httpx.post(
            f"{endpoint}/v1/memories",
            json=payload,
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
    except httpx.RequestError as e:
        msg = f"network error: {e}"
        logger.info("cloud push failed: %s", msg)
        return False, msg

    if resp.is_success:
        return True, None

    if resp.status_code == 401:
        msg = "auth failed (PAT may be revoked) — run `deja login` to refresh"
        logger.warning("cloud push failed: %s", msg)
        return False, msg
    if resp.status_code == 403:
        # Cloud returns {error: "content_too_long" | "quota_exceeded" | ...}.
        # Surface the specific reason when we can; default to a quota-friendly
        # message since that's the dominant 403 in production.
        try:
            body = resp.json()
            err = body.get("error") if isinstance(body, dict) else None
        except Exception:
            err = None
        if err == "content_too_long":
            msg = "memory exceeds your plan's content length limit"
        else:
            msg = (
                "quota exceeded — upgrade at https://deja.sh/dashboard/billing"
            )
        logger.warning("cloud push failed: %s", msg)
        return False, msg
    if resp.status_code == 429:
        msg = "rate limited — try again in a minute"
        logger.warning("cloud push failed: %s", msg)
        return False, msg

    msg = f"HTTP {resp.status_code}"
    logger.info("cloud push failed: %s", msg)
    return False, msg


# ── Sync ──────────────────────────────────────────────────────────────


def load_sync_state() -> dict:
    """Read the current sync state. Loosely consistent — for an atomic
    read-modify-write, use :func:`update_sync_state` instead.
    """
    if not SYNC_STATE_FILE.exists():
        return {}
    return json.loads(SYNC_STATE_FILE.read_text())


@contextlib.contextmanager
def _exclusive_state_lock() -> Iterator[None]:
    """Hold an exclusive POSIX advisory lock on the sync-state file for the
    duration of the ``with`` block. Cross-process; safe under contention.

    Bug M5 (2026-04-18): without a lock, ``load_sync_state`` →
    ``save_sync_state`` from two ``deja sync`` invocations interleaved
    across the read+write window would lose one writer's mutation (LWW).
    The lock is held on a sentinel file (``sync_state.lock``) sitting next
    to the state file rather than on the state file itself, so we can
    open the state file fresh inside the critical section without losing
    the lock when a temp-file rename replaces it.
    """
    SYNC_STATE_FILE.parent.mkdir(exist_ok=True)
    lock_path = SYNC_STATE_FILE.with_suffix(".lock")
    with open(lock_path, "w") as lock_fd:
        fcntl.flock(lock_fd.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_fd.fileno(), fcntl.LOCK_UN)


def _atomic_write_state(state: dict) -> None:
    """Write ``state`` to ``SYNC_STATE_FILE`` atomically: serialize to a
    sibling temp file in the same directory, then ``os.replace`` it over
    the destination. ``os.replace`` is atomic on POSIX, so a crash mid-
    write leaves either the old file or the new — never a half-truncated
    one. Caller is responsible for holding :func:`_exclusive_state_lock`
    across the read+write window.
    """
    SYNC_STATE_FILE.parent.mkdir(exist_ok=True)
    payload = json.dumps(state, indent=2)
    # Write the temp file via Path.write_text so tests can patch it to
    # simulate disk-full / I/O errors and verify the original survives.
    fd, tmp_name = tempfile.mkstemp(
        prefix=".sync_state.", suffix=".tmp", dir=SYNC_STATE_FILE.parent
    )
    os.close(fd)
    tmp_path = Path(tmp_name)
    try:
        tmp_path.write_text(payload)
        os.replace(tmp_path, SYNC_STATE_FILE)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            tmp_path.unlink()
        raise


def update_sync_state(mutate: Callable[[dict], None]) -> dict:
    """Atomic read-modify-write of the sync-state file.

    Holds an exclusive cross-process lock for the entire load → mutate →
    write window, so two concurrent ``deja sync`` invocations can't
    clobber each other (Bug M5, 2026-04-18). ``mutate`` is called with
    the freshly-loaded state dict and may mutate it in place; the
    function returns the post-mutation state.
    """
    with _exclusive_state_lock():
        state = load_sync_state()
        mutate(state)
        _atomic_write_state(state)
        return state


def save_sync_state(state: dict) -> None:
    """Replace the entire sync state with ``state``. Atomic + locked.

    Prefer :func:`update_sync_state` for read-modify-write flows — it
    re-reads inside the lock so concurrent writers can't ghost each
    other's mutations.
    """
    with _exclusive_state_lock():
        _atomic_write_state(state)


# ── Per-endpoint "stuck" memories ─────────────────────────────────────
#
# Cloud-rejected localIds (``content_too_long``, ``quota_exceeded``, …)
# get stranded by the cursor: their ``updated_at`` doesn't change, but the
# cursor advances past them, so they fall out of the next ``to_push`` set
# and the rejection warning never re-fires. We persist them per-endpoint
# alongside the cursor so the CLI handler can force-include them on every
# subsequent push until the user trims/archives/upgrades.
#
# Format chosen for backward compatibility: the legacy shape was
# ``{endpoint: cursor_iso_string}``. We add a sibling ``"_stuck"`` key
# that nests by endpoint:
#   {
#     "https://api.deja.sh": "2026-04-19T00:00:00Z",
#     "_stuck": {
#       "https://api.deja.sh": {"01ABC": "content_too_long"}
#     }
#   }
# Old readers ignore ``_stuck`` cleanly (they only key into the top-level
# endpoint map), so this is a forward-only migration with no version bump.


def load_stuck_ids(endpoint: str) -> dict[str, str]:
    """Return ``{localId: reason}`` the cloud rejected on the last push.

    Empty dict when the state file is missing, the file has no ``_stuck``
    slice, or the endpoint has no entry. Never raises on missing keys —
    a fresh CLI install must Just Work.
    """
    state = load_sync_state()
    return dict(state.get("_stuck", {}).get(endpoint, {}))


def save_stuck_ids(endpoint: str, stuck: dict[str, str]) -> None:
    """Persist this endpoint's ``{localId: reason}`` map.

    Passing an empty dict removes this endpoint from the ``_stuck`` slice
    entirely (sync recovered, nothing to retry). Other endpoints' stuck
    sets are left alone.

    Always preserves the top-level cursor map so we don't regress the
    legacy ``{endpoint: cursor}`` contract. Bug M5 (2026-04-18): the RMW
    is wrapped in :func:`update_sync_state` so a parallel ``deja sync``
    can't clobber another endpoint's stuck slice between the load and
    the write.
    """
    def _mutate(state: dict) -> None:
        stuck_slice = dict(state.get("_stuck", {}))
        if stuck:
            stuck_slice[endpoint] = dict(stuck)
        else:
            stuck_slice.pop(endpoint, None)
        if stuck_slice:
            state["_stuck"] = stuck_slice
        else:
            state.pop("_stuck", None)

    update_sync_state(_mutate)


def _sanitize_for_push(memory: dict) -> dict:
    """Convert a local memory dict to the shape the cloud API accepts.

    The cloud uses ``forbidNonWhitelisted`` validation, so any key not on the
    DTO causes ``HTTP 400 "property X should not exist"``. This function
    (1) filters to the snake_case allowlist ``_PUSH_FIELDS`` and (2) maps the
    snake_case local schema fields that have a different camelCase name on
    the cloud DTO (``last_confirmed``→``lastConfirmed``, ``archived_at``→
    ``archivedAt``, plus the synthetic ``archived`` boolean derived from
    ``archived_at IS NOT NULL`` since the local schema has no boolean column).

    Bug N5 (2026-04-19): the local schema stores command-boundary triggers as
    a snake-case ``trigger`` comma-string (``"alembic upgrade, db migrate"``),
    while the cloud DTO expects camelCase ``triggerCmds: list[str]``. The
    pre-fix sanitizer's allowlist filter dropped ``trigger`` (wrong key) and
    never synthesized ``triggerCmds``, so the **batch** push path
    (``sync_push`` → ``_sanitize_for_push``) silently lost every trigger on
    every backlog flush. Single-row pushes worked only because the two
    eager-push call sites manually pre-translated before calling
    ``push_memory``. Translation is now done here so all three codepaths
    (eager-CLI, eager-MCP, batch-sync) share one source of truth.

    Keep this in sync with ``CreateMemoryDto`` in
    ``~/projects/deja_sh/apps/api/src/memories/dto/create-memory.dto.ts``.
    """
    payload = {k: v for k, v in memory.items() if k in _PUSH_FIELDS}
    if "id" in memory:
        payload["localId"] = memory["id"]
    payload["scope"] = "global"
    if memory.get("last_confirmed"):
        payload["lastConfirmed"] = memory["last_confirmed"]
    archived_at = memory.get("archived_at")
    if archived_at:
        # Local truth is the timestamp; the boolean is derived. Send both so
        # the cloud has the original archive time for LWW conflict resolution
        # rather than auto-stamping NOW() on receipt.
        payload["archived"] = True
        payload["archivedAt"] = archived_at
    trigger_str = memory.get("trigger")
    if trigger_str:
        tokens = [t.strip() for t in trigger_str.split(",") if t.strip()]
        if tokens:
            payload["triggerCmds"] = tokens
    return payload


_PULL_RENAME = {
    "localId": "id",
    "lastConfirmed": "last_confirmed",
    "archivedAt": "archived_at",
    "createdAt": "created_at",
    "updatedAt": "updated_at",
    "reuseCount": "reuse_count",
}
"""Cloud camelCase → local snake_case key translation for pull."""

_PULL_DROP = {"id", "userId", "archived", "tags"}
"""Cloud-only or derived fields to drop on pull.

- ``id``: the cloud UUID is server-side only; the original local id rides on
  ``localId`` and we map it back to ``id``. For cloud-native rows that have no
  ``localId``, we fall back to keeping the cloud ``id`` (see code).
- ``userId``: server-only.
- ``archived``: a boolean derived from ``archived_at IS NOT NULL`` locally;
  the timestamp on ``archivedAt`` is the source of truth.
- ``tags``: no local column today (the local schema has no ``tags`` field;
  see ``deja/core/store/_schema.py``). Dropping silently rather than failing
  the upsert; revisit if local tags ship.
"""


def _sanitize_for_pull(memory: dict) -> dict:
    """Convert a cloud memory payload into the local SQLite shape.

    The cloud serializes its TypeORM ``Memory`` entity as camelCase JSON; the
    local store's ``MemoryStore.upsert`` filters incoming dicts down to a
    snake_case allowlist (``_KNOWN_COLUMNS`` in ``deja/core/store/__init__.py``)
    and silently drops anything else. Without translation, every camelCase
    field on the cloud row (``localId``, ``triggerCmds``, ``lastConfirmed``,
    ``archivedAt``, ``createdAt``, ``updatedAt``, ``reuseCount``) would be
    lost on every pull — which silently broke dashboard-side archives ever
    propagating to the CLI before this helper existed (cloud Phase 3.4).

    Specific translations:

    - Cloud-only / derived fields are dropped (``_PULL_DROP``).
    - Camel→snake renames per ``_PULL_RENAME``. ``localId`` becomes the local
      ``id``; cloud-native rows without a ``localId`` fall back to the cloud
      ``id`` so the upsert still has a primary key.
    - ``triggerCmds: list[str]`` collapses to ``trigger: "a,b,c"`` (the local
      column is comma-separated). Empty list → ``None``.
    - ``scope`` is regenerated from ``project``: a cloud row with ``project``
      set becomes ``scope = "project:<name>"`` locally; otherwise ``"global"``.
      The cloud's own ``"local"|"global"`` enum is meaningless locally and
      ignored.

    Keep this in sync with the cloud ``Memory`` entity at
    ``~/projects/deja_sh/apps/api/src/memories/entities/memory.entity.ts``.
    """
    out: dict = {}
    for k, v in memory.items():
        if k in _PULL_DROP:
            continue
        if k == "triggerCmds":
            out["trigger"] = ",".join(v) if v else None
        elif k in _PULL_RENAME:
            out[_PULL_RENAME[k]] = v
        elif k == "scope":
            continue  # regenerated below from project
        else:
            out[k] = v
    # Cloud-native rows can serialize ``localId: null`` (the field exists
    # with a null value, not absent). The straight rename above would set
    # ``id=None`` and blow up the local upsert with ``IntegrityError: NOT
    # NULL constraint failed: memories.id`` (the constraint we added in
    # Bug #2). Fall back to the cloud's UUID ``id`` whenever the rename
    # produced None or didn't fire at all.
    if not out.get("id") and memory.get("id"):
        out["id"] = memory["id"]
    project = out.get("project")
    out["scope"] = f"project:{project}" if project else "global"
    return out


SYNC_PUSH_BATCH_SIZE = 50
"""Max rows per ``POST /v1/sync/push`` body.

The cloud's NestJS body parser defaults to 100KB and api.deja.sh has a
proxy in front that 413s on bigger payloads. With memories averaging
1–2KB serialized, 50 rows lands comfortably under the limit while keeping
round-trips few. We hit a real 413 with 158 rows in one POST during a
backlog flush (2026-04-19 live smoke); see the ``SyncPushBatchingTests``
contract for what behavior this constant pins.
"""


def sync_push(memories: list[dict], config=None) -> dict:
    """Bulk-push memories to cloud in batches; surface per-row conflicts.

    Returns the API's structured response shape: ``{accepted, skipped,
    conflicts, serverTime}`` aggregated across however many HTTP requests
    we needed. ``conflicts`` is a list of ``{localId, reason}`` for rows
    the cloud rejected. Known reasons today: ``"quota_exceeded"``
    (free-plan cap hit) and ``"content_too_long"`` (content exceeds plan's
    per-memory limit). ``serverTime`` is the *last* batch's serverTime
    (the cloud is monotonic, so the latest is what the cursor needs).

    Batching: rows are split into chunks of ``SYNC_PUSH_BATCH_SIZE``. Each
    chunk is its own POST. Without batching, a backlog of ~150+ memories
    blows past the cloud's 100KB body-parser limit and the entire push
    aborts with HTTP 413 — leaving zero rows accepted and zero conflicts
    surfaced. We hit this for real on 2026-04-19 when clearing the cursor
    on a 158-row local DB.

    When ``conflicts`` is non-empty, also logs a WARNING summarizing the
    rejection reasons via the ``deja.cloud`` logger — so callers that ignore
    the return value still get a visible signal on stderr (mirrors the
    ``push_memory`` contract from §3.6). Without this, ``deja sync --push``
    can silently lose memories to quota and the user only sees "Pushed: N"
    where N counts the *attempted* rows, not the *accepted* ones.

    Hard transport failures (auth, network, 5xx) still raise — those are
    pipeline-fatal, not per-row. The raised message includes how many rows
    were already accepted so the operator knows the state isn't a clean
    rollback (pushes are LWW upserts so retry-from-cursor is safe).
    """
    token = get_token(config)
    if not token:
        raise RuntimeError("Not logged in. Run `deja login`.")
    endpoint = _get_endpoint(config)
    sanitized = [_sanitize_for_push(m) for m in memories]

    aggregated = {
        "accepted": 0,
        "skipped": 0,
        "conflicts": [],
        "serverTime": None,
    }
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{endpoint}/v1/sync/push"

    for start in range(0, len(sanitized), SYNC_PUSH_BATCH_SIZE):
        chunk = sanitized[start : start + SYNC_PUSH_BATCH_SIZE]
        resp = httpx.post(url, json={"memories": chunk}, headers=headers, timeout=60)
        if not resp.is_success:
            raise RuntimeError(
                f"sync push failed ({resp.status_code}) after "
                f"{aggregated['accepted']} accepted in earlier batches: {resp.text}"
            )
        body = resp.json()
        aggregated["accepted"] += body.get("accepted", 0) or 0
        aggregated["skipped"] += body.get("skipped", 0) or 0
        aggregated["conflicts"].extend(body.get("conflicts") or [])
        if body.get("serverTime"):
            aggregated["serverTime"] = body["serverTime"]

    conflicts = aggregated["conflicts"]
    if conflicts:
        # Bucket by reason so the warning is one-line-per-reason, not one-
        # line-per-row (a quota-blown user can have hundreds of rejections).
        by_reason: dict[str, int] = {}
        for c in conflicts:
            reason = c.get("reason") or "unknown"
            by_reason[reason] = by_reason.get(reason, 0) + 1
        parts = []
        for reason, count in sorted(by_reason.items()):
            if reason == "quota_exceeded":
                parts.append(
                    f"{count} rejected: quota exceeded "
                    "(upgrade at https://deja.sh/dashboard/billing)"
                )
            elif reason == "content_too_long":
                parts.append(
                    f"{count} rejected: content exceeds plan's per-memory limit"
                )
            else:
                parts.append(f"{count} rejected: {reason}")
        logger.warning("cloud sync push: %s", "; ".join(parts))
    return aggregated


def sync_pull(since: Optional[str] = None, config=None) -> dict:
    token = get_token(config)
    if not token:
        raise RuntimeError("Not logged in. Run `deja login`.")
    endpoint = _get_endpoint(config)
    params = f"?since={since}" if since else ""
    resp = httpx.get(
        f"{endpoint}/v1/sync/pull{params}",
        headers={"Authorization": f"Bearer {token}"},
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()
