"""Connection lifecycle + composable transactions for MemoryStore.

Phase 4 of the store restructure (see docs/store-restructure-plan.md). The MemoryStore class used to
hand-roll connect/close and mix BEGIN/COMMIT into ``save_batch``. That logic
now lives here so services (Phase 5/6) can share a transaction without each
one knowing about the open connection.

Design notes that are load-bearing for later phases:

- **Soft-reentrant transactions.** The first ``async with conn.transaction()``
  issues ``BEGIN`` and sets ``_in_tx=True``; nested calls join the existing
  transaction without a second ``BEGIN``. Commit happens only at the outermost
  exit. Any exception — from any depth — triggers ``ROLLBACK`` and clears the
  flag before re-raising. This keeps services composable (e.g. a batch pass
  calling ``SaveService.save`` inside ``conn.transaction()``) without either
  side needing to know about the other's transaction boundary.

- **Single connection, single writer.** Deja is a local CLI with one writer.
  No pool, no per-request connections. The flag is a plain ``bool`` because
  asyncio gives us cooperative single-threaded scheduling — a second coroutine
  can't enter ``transaction()`` mid-BEGIN. If that ever changes, this file is
  the place to migrate to ``SAVEPOINT``.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator, Optional

import aiosqlite

logger = logging.getLogger(__name__)

DEFAULT_OPEN_TIMEOUT_SEC: float = 5.0
"""Default ceiling for the lazy-open path (connect + WAL/foreign_keys PRAGMAs).

Sized to cover cold WAL setup on slow disks while still surfacing pathological
hangs (notably: coding-agent sandboxes that block writes outside the workspace
make ``aiosqlite.connect`` block forever during ``PRAGMA journal_mode=WAL``)
in seconds rather than never. See ``Connection.get`` for the rationale.
"""


class Connection:
    """Lazy-open aiosqlite connection with a composable ``transaction()``.

    Lifecycle:
        conn = Connection(db_path)
        db = await conn.get()            # first call connects
        ...                              # subsequent calls reuse
        await conn.close()               # releases; get() will reconnect

    Transactions::

        async with conn.transaction() as db:
            await db.execute(...)        # BEGIN issued on entry
            await db.execute(...)
        # COMMIT on normal exit, ROLLBACK on exception.

        async with conn.transaction() as db:
            async with conn.transaction() as db2:
                # same db; no inner BEGIN; commits with outer
                ...
    """

    def __init__(
        self,
        db_path: Path,
        *,
        open_timeout: Optional[float] = DEFAULT_OPEN_TIMEOUT_SEC,
    ) -> None:
        """Create a lazy connection handle.

        Args:
            db_path: Path to the SQLite file. Parent dir is created on first ``get``.
            open_timeout: Seconds to wait for the connect + initial PRAGMAs.
                ``None`` disables the guard (useful for tests or non-sandboxed
                long-running setup tasks). Defaults to
                ``DEFAULT_OPEN_TIMEOUT_SEC``. The guard exists because
                coding-agent sandboxes can make the open path hang indefinitely
                instead of failing fast — see ``get`` for the failure mode.
        """
        self._db_path = db_path
        self._db: Optional[aiosqlite.Connection] = None
        self._in_tx: bool = False
        self._open_timeout = open_timeout

    @property
    def is_open(self) -> bool:
        """True iff the underlying aiosqlite connection is currently open.

        Public surface for lifecycle assertions (e.g. context-manager tests
        verifying the connection actually closed). Prefer this over reading
        ``self._db`` directly so callers don't depend on the private field.
        """
        return self._db is not None

    async def get(self) -> aiosqlite.Connection:
        """Return the underlying aiosqlite connection, opening it on first call.

        The whole open sequence (``aiosqlite.connect`` + ``PRAGMA journal_mode=WAL``
        + ``PRAGMA foreign_keys=ON``) runs under a single ``asyncio.wait_for``
        deadline because any of those steps can wedge when the SQLite file
        lives outside a writable area. Coding-agent sandboxes (Cursor, Codex,
        ...) routinely block writes to ``~/.deja/store/memories.db``; without
        the timeout, ``aiosqlite``'s worker thread silently absorbs the
        ``OperationalError`` and the awaited future never resolves. The
        ``deja`` CLI then leaks one hanging process per invocation.

        On timeout, we tear down any partially-opened handle and raise
        ``RuntimeError`` with an actionable hint pointing at the sandbox
        escape hatch documented in AGENTS.md.
        """
        if self._db is not None:
            return self._db

        try:
            if self._open_timeout is None:
                await self._open()
            else:
                await asyncio.wait_for(self._open(), timeout=self._open_timeout)
        except asyncio.TimeoutError as exc:
            await self._discard_partial_open()
            raise RuntimeError(
                f"Timed out after {self._open_timeout:.1f}s opening SQLite at "
                f"{self._db_path}. This usually means a coding-agent sandbox is "
                "blocking writes outside the workspace (see AGENTS.md: re-run "
                "with the agent's escalated/out-of-sandbox permission)."
            ) from exc
        except BaseException:
            await self._discard_partial_open()
            raise

        assert self._db is not None  # _open populated it
        return self._db

    async def _open(self) -> None:
        """Run the actual connect + PRAGMA sequence. Caller owns the timeout."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db = await aiosqlite.connect(self._db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA foreign_keys=ON")
        # Bug H4-companion (2026-04-18): without busy_timeout, the second
        # writer in a CLI + watcher + MCP-server contention immediately
        # fails with "database is locked" instead of waiting for the
        # other writer's transaction to commit. 5s gives the other tx
        # plenty of headroom on a hot path that finishes in milliseconds.
        await self._db.execute("PRAGMA busy_timeout=5000")

    async def _discard_partial_open(self) -> None:
        """Best-effort cleanup of a half-opened connection after a failed ``_open``.

        After ``asyncio.wait_for`` cancels ``_open``, ``self._db`` may be set
        to a connection whose PRAGMA setup never completed. We try to close it
        so the caller can retry without leaking a worker thread; we swallow
        any error from the close itself because we're already in a failure
        path and the caller is about to see a more useful exception.
        """
        if self._db is None:
            return
        try:
            await self._db.close()
        except Exception:
            logger.debug("ignoring close() error during partial-open cleanup", exc_info=True)
        finally:
            self._db = None
            self._in_tx = False

    async def close(self) -> None:
        """Close the connection if open. Safe to call multiple times."""
        if self._db is not None:
            await self._db.close()
            self._db = None
            self._in_tx = False

    async def __aenter__(self) -> aiosqlite.Connection:
        return await self.get()

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[aiosqlite.Connection]:
        """Soft-reentrant transaction block.

        Outermost entry issues ``BEGIN IMMEDIATE``; nested calls yield the same
        connection without a second ``BEGIN``. Commit runs at the outermost exit;
        any exception anywhere in the nest rolls back the whole transaction.

        ``BEGIN IMMEDIATE`` (instead of plain ``BEGIN``, which is deferred) is
        the half of the H4-companion fix that ``PRAGMA busy_timeout=5000`` alone
        couldn't do. With deferred BEGIN, two writers each take a SHARED read
        lock, then each ``INSERT`` tries to upgrade SHARED→RESERVED — and SQLite
        returns ``SQLITE_BUSY`` *immediately* on lock-upgrade contention,
        bypassing ``busy_timeout`` to avoid deadlock. ``BEGIN IMMEDIATE`` takes
        RESERVED up front, so contention happens at the BEGIN step where
        ``busy_timeout`` *does* apply — the second writer simply waits up to
        5s for the first to commit. Without this, the H4 dedup-race test was
        flaky on Linux CI ("database is locked" on the INSERT path) even though
        the index + IntegrityError-recovery were correct.
        """
        db = await self.get()
        if self._in_tx:
            yield db
            return

        await db.execute("BEGIN IMMEDIATE")
        self._in_tx = True
        try:
            yield db
        except BaseException:
            try:
                await db.rollback()
            finally:
                self._in_tx = False
            raise
        else:
            await db.commit()
            self._in_tx = False
