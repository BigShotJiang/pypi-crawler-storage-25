"""Store policy constants.

All magic numbers that govern memory lifecycle, dedup, ranking, and decay
live here so they can be read, tuned, and referenced by name. Anything
that appears in a formula or threshold in the store should be imported
from this module — not hardcoded at the call site.

Changes here are behavior changes. Adjust with care and add a test that
locks the new constant to the expected outcome.
"""
from __future__ import annotations

# ── dedup ──────────────────────────────────────────────────────────────────────

# At reflection time (MaintenanceService.dedup_fuzzy → ReflectionEngine.run_full),
# a candidate memory with token-overlap above this ratio against an existing
# memory of the same type+scope+project is treated as a near-duplicate: the
# survivor's confidence and reuse_count are bumped, the loser is archived.
# Save-time dedup is exact-match only (idx_memories_dedup composite index)
# to keep the hot path <1ms; fuzzy work batches into reflection (R4, 2026-04-22).
DEDUP_OVERLAP_THRESHOLD: float = 0.8

# How much to add to an existing memory's confidence when a dedup match
# confirms it. Capped by CONFIDENCE_MAX.
CONFIDENCE_BUMP: float = 0.05

CONFIDENCE_MAX: float = 1.0


# ── activation ranking ────────────────────────────────────────────────────────
#
# score = task_match * TASK_MATCH_WEIGHT
#       + confidence
#       + recency * RECENCY_WEIGHT
#       + reuse_norm * REUSE_WEIGHT
#       + (SCOPE_FIT_BONUS if project matches else 0)

# Retrieval relevance is the primary signal, so its weight exceeds the
# theoretical max of any other component (all others ≤ 1.0).
TASK_MATCH_WEIGHT: float = 2.0

RECENCY_WEIGHT: float = 0.5
REUSE_WEIGHT: float = 0.5
SCOPE_FIT_BONUS: float = 0.1

# Recency decays linearly from 1.0 (today) to 0.0 at this many days old.
RECENCY_HORIZON_DAYS: int = 365

# reuse_count is clamped to this value before normalizing to [0, 1].
REUSE_NORMALIZATION_CAP: int = 10


# ── confusability penalty ─────────────────────────────────────────────────────

# Two procedures are considered confusable if their embedding cosine
# similarity exceeds this threshold.
CONFUSABILITY_COSINE_THRESHOLD: float = 0.85

# Multiplicative score penalty applied to a procedure that is confusable
# with a higher-ranked procedure already in the result set.
CONFUSABILITY_PENALTY: float = 0.6


# ── FTS fallback ──────────────────────────────────────────────────────────────

# When no embedding is available, we fall back to FTS BM25 rank position.
# The bottom result still gets at least this much task_match so it can
# compete with other signals in activation scoring.
FTS_RANK_FLOOR: float = 0.1


# ── load / slot policy ────────────────────────────────────────────────────────

# Progress memories are only included in load() if updated within this window.
PROGRESS_FRESHNESS_DAYS: int = 7


# ── decay / archival ──────────────────────────────────────────────────────────

# Memories with confidence below this threshold are archived by the
# default maintenance pass.
ARCHIVE_CONFIDENCE_THRESHOLD: float = 0.3

# Confidence decays proportional to weeks since last_confirmed.
# new_conf = old_conf - decay_rate * weeks_since
DECAY_WEEK_DIVISOR: float = 7.0


# ── per-memory content cap ─────────────────────────────────────────────────────
#
# A memory is one piece of info — a gotcha, a decision, a procedure step.
# Anything longer is almost certainly two memories that should be split,
# and the cloud's free tier rejects content > 2000 chars at the API
# boundary anyway. Enforcing the same cap locally at save() time keeps
# local and cloud in lockstep, surfaces the principle violation at write
# time (when the agent can still split), and prevents the
# "content_too_long" stuck-set from growing.
#
# Enforced at SaveService._save_in_tx (the chokepoint every save() and
# save_batch() reaches). System-internal mutation paths — MemoryStore.upsert
# (cloud-pull / import) and MaintenanceService.dedup_fuzzy (reflection
# consolidation) — are deliberately exempt; those handle pre-validated
# data or legitimately consolidate content. See
# docs/superpowers/specs/2026-04-18-memory-content-limit-design.md.
MAX_CONTENT_LENGTH: int = 2000


class MemoryTooLongError(ValueError):
    """Raised when a save() candidate's content exceeds MAX_CONTENT_LENGTH.

    Subclass of ValueError so generic ``except ValueError`` blocks at the
    surface (CLI/MCP) keep working, while specific handlers can match on
    the subclass to render the structured error.

    Attributes:
        content_length: actual char count of the rejected content.
        limit: the cap that was exceeded (always MAX_CONTENT_LENGTH for
            now; carried explicitly so future per-tier limits are
            forward-compatible without changing the message format).
    """

    def __init__(self, content_length: int, limit: int = MAX_CONTENT_LENGTH) -> None:
        self.content_length = content_length
        self.limit = limit
        super().__init__(
            f"memory is too long ({content_length} chars, max {limit}). "
            f"Memories must be ≤{limit} chars. "
            f"Split into 2+ memories, each one specific fact."
        )
