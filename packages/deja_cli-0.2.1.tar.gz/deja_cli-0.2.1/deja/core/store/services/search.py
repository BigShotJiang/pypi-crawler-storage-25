"""Search service: trigger / FTS / embedding / hybrid retrieval.

Public surface mirrors what the facade's ``search()`` orchestrates today,
broken into single-purpose methods so callers can mix and match (e.g.
``MaintenanceService.dedup_fuzzy`` only wants the FTS pass).

Pipeline contract for ``hybrid_search``, in execution order:

0. **Trigger pass** — ``trigger_search``: substring match against the
   memory's stored ``trigger`` field. High precision; pinned above all
   scored results in the merge step. No ranking on this pass.
1. **FTS5 pass** — ``fts_search``: BM25 keyword match.
2. **Embedding pass** — ``embedding_search``: cosine similarity against
   stored embeddings. Always runs when ``embedding_adapter`` is configured
   (not a fallback — both signals contribute).
3. **Merge** — by ID, trigger first, then FTS, then embedding.
4. **Activation ranking** — :func:`ranking.activation_score` applied to
   each candidate. Trigger results get ``task_match=TASK_MATCH_WEIGHT``
   so they outrank everything regardless of embedding cosine.
5. **Confusability penalty** — :func:`ranking.confusability_penalty`
   down-ranks procedures cosine-similar to a higher-ranked procedure.
6. **Reuse increment** — when ``track_usage=True``, bump ``reuse_count``
   for returned ids. Off by default in benchmarks/batch jobs.
"""
from __future__ import annotations

import logging
import struct
from datetime import datetime, timezone
from typing import Any, Optional

import aiosqlite

from deja.core.store._helpers import (
    _bytes_to_emb,
    _cosine_similarity,
    _now_iso,
    _strip_embedding,
)
from deja.core.store.connection import Connection
from deja.core.store.model import Memory
from deja.core.store.policy import FTS_RANK_FLOOR, TASK_MATCH_WEIGHT
from deja.core.store.repos.memories import MemoryRepository
from deja.core.store.services import ranking

logger = logging.getLogger(__name__)


class SearchService:
    """Trigger + FTS + embedding pipeline on top of ``MemoryRepository``."""

    def __init__(self, connection: Connection, repo: MemoryRepository) -> None:
        self._connection = connection
        self._repo = repo

    # ── primitives ───────────────────────────────────────────────────────────

    async def find_similar(
        self,
        content: str,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        limit: int = 5,
    ) -> list[Memory]:
        """FTS-based similarity. Convenience wrapper used by maintenance/promote."""
        db = await self._connection.get()
        return await self._repo.find_similar_by_fts(
            db, content, project=project, mem_type=mem_type, limit=limit
        )

    async def trigger_search(
        self,
        query: str,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
    ) -> list[dict]:
        """Pass-0 trigger search: query contains any comma-separated trigger phrase.

        Returns up to 5 memory dicts (matches the legacy facade cap). The
        substring direction is **query contains phrase** (not phrase
        contains query) — a query like ``"kubectl apply -f k8s/"`` matches
        a memory with trigger ``"kubectl apply"``.
        """
        db = await self._connection.get()
        memories = await self._repo.fetch_with_trigger(
            db, project=project, mem_type=mem_type
        )
        query_lower = query.lower()

        matches: list[dict] = []
        for m in memories:
            if m.trigger is None:
                continue
            phrases = [p.strip().lower() for p in m.trigger.split(",") if p.strip()]
            if any(phrase in query_lower for phrase in phrases):
                matches.append(m.to_dict(include_embedding=True))
        return matches[:5]

    async def fts_search(
        self,
        query: str,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        limit: int = 20,
    ) -> list[dict]:
        """Raw FTS5 keyword search — embedding bytes preserved for downstream cosine."""
        db = await self._connection.get()
        memories = await self._repo.find_similar_by_fts(
            db, query, project=project, mem_type=mem_type, limit=limit
        )
        return [m.to_dict(include_embedding=True) for m in memories]

    async def embedding_search(
        self,
        query_embedding: list[float],
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        limit: int = 20,
    ) -> list[dict]:
        """Cosine search across rows that have a stored embedding."""
        db = await self._connection.get()
        memories = await self._repo.fetch_with_embeddings(
            db, project=project, mem_type=mem_type
        )

        scored: list[tuple[float, dict]] = []
        for m in memories:
            if m.embedding is None:
                continue
            try:
                mem_emb = _bytes_to_emb(m.embedding)
                sim = _cosine_similarity(query_embedding, mem_emb)
                scored.append((sim, m.to_dict(include_embedding=True)))
            except (struct.error, TypeError):
                # Malformed embedding bytes (truncated row, dimension mismatch,
                # or non-bytes column) — skip the row, don't crash search.
                continue

        scored.sort(key=lambda x: x[0], reverse=True)
        return [row for _, row in scored[:limit]]

    async def increment_reuse(self, ids: list[str]) -> None:
        """Bump reuse_count for a set of memory ids. Used after hybrid_search."""
        if not ids:
            return
        async with self._connection.transaction() as db:
            await self._repo.increment_reuse_for_ids(db, ids, updated_at=_now_iso())

    # ── orchestration ────────────────────────────────────────────────────────

    async def hybrid_search(
        self,
        query: str,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        limit: int = 20,
        embedding_adapter: Any = None,
        track_usage: bool = True,
    ) -> list[dict]:
        """Full pipeline (trigger → FTS → embedding → merge → score → penalty → emit).

        See module docstring for step semantics. Returns memory dicts with
        embedding bytes stripped.
        """
        trigger_results = await self.trigger_search(query, project, mem_type)
        fts_results = await self.fts_search(query, project, mem_type, limit)

        embedding_results: list[dict] = []
        query_embedding: Optional[list[float]] = None
        if embedding_adapter is not None:
            try:
                query_embedding = await embedding_adapter.embed(query)
                embedding_results = await self.embedding_search(
                    query_embedding, project, mem_type, limit
                )
            except Exception as e:  # pragma: no cover — adapter-dependent
                logger.warning("Embedding search error: %s", e)

        merged = self._merge_by_id(trigger_results, fts_results, embedding_results)
        if not merged:
            return []

        scored = self._activation_rank(merged, fts_results, query_embedding, project)
        scored = ranking.confusability_penalty(scored)
        scored.sort(key=lambda x: x[2], reverse=True)
        final = [_strip_embedding(mem) for mem, _, _ in scored[:limit]]

        if embedding_adapter is not None and track_usage and final:
            await self.increment_reuse([m["id"] for m in final])

        return final

    # ── orchestration helpers ────────────────────────────────────────────────

    def _merge_by_id(
        self,
        trigger_results: list[dict],
        fts_results: list[dict],
        embedding_results: list[dict],
    ) -> list[tuple[dict, str, int]]:
        """Dedup three result lists by id. Returns (mem, source, rank_within_source)."""
        seen: set[str] = set()
        merged: list[tuple[dict, str, int]] = []
        for source, results in (
            ("trigger", trigger_results),
            ("fts", fts_results),
            ("emb", embedding_results),
        ):
            for rank, mem in enumerate(results):
                if mem["id"] not in seen:
                    seen.add(mem["id"])
                    merged.append((mem, source, rank))
        return merged

    def _activation_rank(
        self,
        merged: list[tuple[dict, str, int]],
        fts_results: list[dict],
        query_embedding: Optional[list[float]],
        project: Optional[str],
    ) -> list[tuple[dict, Optional[bytes], float]]:
        """Score each candidate. Triggers pin via TASK_MATCH_WEIGHT; cosine
        beats FTS rank when an embedding is available; FTS rank floor otherwise.
        """
        now_dt = datetime.now(timezone.utc)
        fts_count = max(len(fts_results), 1)
        scored: list[tuple[dict, Optional[bytes], float]] = []

        for mem, source, rank in merged:
            emb_bytes = mem.get("embedding")
            if not isinstance(emb_bytes, bytes):
                emb_bytes = None

            if source == "trigger":
                task_match = TASK_MATCH_WEIGHT
            elif query_embedding is not None and emb_bytes:
                task_match = _cosine_similarity(
                    query_embedding, _bytes_to_emb(emb_bytes)
                )
            else:
                task_match = max(FTS_RANK_FLOOR, 1.0 - rank / fts_count)

            score = ranking.activation_score(mem, task_match, project, now_dt)
            scored.append((mem, emb_bytes, score))

        return scored
