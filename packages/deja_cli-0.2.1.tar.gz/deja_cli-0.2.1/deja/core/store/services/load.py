"""Load service: slot-allocated context loading with overflow hints.

The thing the CLI calls when an agent boots up — fetch the active memories
for a project + global, allocate them across per-type slots, and report
what got cut so the agent can ask for more if it needs to.

Shape stays identical to the legacy ``MemoryStore.load_budgeted`` so Phase 7
can swap the facade method body without touching any caller.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from deja.core.store._helpers import (
    DEFAULT_LOAD_SLOTS,
    _parse_dt,
    _strip_embedding,
)
from deja.core.store.connection import Connection
from deja.core.store.policy import PROGRESS_FRESHNESS_DAYS
from deja.core.store.repos.memories import MemoryRepository
from deja.core.store.services import ranking


class LoadService:
    """Slot-allocated context loader.

    Composition note: depends on ``MemoryRepository`` only. The context-
    aware ranking path needs an FTS lookup and that's served by
    ``repo.find_similar_by_fts`` directly — ``LoadService`` does **not**
    depend on ``SearchService`` (the per-Phase-4 composition rule).
    """

    def __init__(self, connection: Connection, repo: MemoryRepository) -> None:
        self._connection = connection
        self._repo = repo

    async def load(self, project: Optional[str] = None) -> list[dict]:
        """Active memories for project + global, ordered by confidence DESC.

        Plain version (no slots, no context). Used directly by ``deja load``
        and by ``load_budgeted`` for the candidate set.
        """
        db = await self._connection.get()
        memories = await self._repo.fetch_active(db, project)
        return [m.to_dict() for m in memories]

    async def load_budgeted(
        self,
        project: Optional[str] = None,
        slots: Optional[dict[str, int]] = None,
        context: Optional[str] = None,
        embedding_adapter: Any = None,
    ) -> dict:
        """Slot-allocated load with optional context-aware re-ranking.

        Per-type ranking when ``context`` is **not** provided:
        - ``progress``: filter to last ``PROGRESS_FRESHNESS_DAYS`` days, then
          most-recently-updated first.
        - ``procedure``: most-used first (``reuse_count`` then ``confidence``).
        - everything else: highest confidence first.

        With ``context``: each type bucket sorted by activation score
        (task_match × 2 + confidence + recency*0.5 + reuse*0.5 + scope_fit).
        ``progress`` still filters by freshness even when context-ranked.

        Returns the same shape the facade returns today:
        ``{memories, total, overflow, overflow_hints, project}``.
        """
        if slots is None:
            slots = dict(DEFAULT_LOAD_SLOTS)

        all_memories = await self.load(project)
        now = datetime.now(timezone.utc)
        cutoff_7d = now - timedelta(days=PROGRESS_FRESHNESS_DAYS)

        task_match_by_id: dict[str, float] = {}
        if context:
            # Need full rows incl. embeddings for the cosine pass. Re-fetch
            # via FTS — load() above strips embeddings for cleanliness.
            db = await self._connection.get()
            fts_memories = await self._repo.find_similar_by_fts(
                db, context, project=project, limit=len(all_memories) or 200
            )
            fts_results = [m.to_dict(include_embedding=True) for m in fts_memories]

            # Mirror the same shape for the embedding pass: load_budgeted's
            # cosine override needs each candidate's embedding bytes too.
            candidates_with_emb = await self._repo.fetch_active(db, project)
            mem_dicts = [m.to_dict(include_embedding=True) for m in candidates_with_emb]

            task_match_by_id = await ranking.compute_task_match(
                mem_dicts, context, embedding_adapter, fts_results
            )

        by_type: dict[str, list[dict]] = {}
        for mem in all_memories:
            by_type.setdefault(mem.get("type", "pattern"), []).append(mem)

        selected, overflow_hints = self._allocate_slots(
            by_type, slots, task_match_by_id, context, project, cutoff_7d
        )

        # Any types not in the slot config become overflow hints too.
        known = set(slots.keys())
        for mem_type, mems in by_type.items():
            if mem_type not in known and mems:
                overflow_hints.append({"type": mem_type, "overflow": len(mems)})

        return {
            "memories": [_strip_embedding(m) for m in selected],
            "total": len(all_memories),
            "overflow": len(all_memories) - len(selected),
            "overflow_hints": overflow_hints,
            "project": project or "global",
        }

    def _allocate_slots(
        self,
        by_type: dict[str, list[dict]],
        slots: dict[str, int],
        task_match_by_id: dict[str, float],
        context: Optional[str],
        project: Optional[str],
        cutoff_7d: datetime,
    ) -> tuple[list[dict], list[dict]]:
        """Pick top-N per type using the per-type ranking rules. Returns
        (selected, overflow_hints).
        """
        now = datetime.now(timezone.utc)
        selected: list[dict] = []
        overflow_hints: list[dict] = []

        for mem_type, limit in slots.items():
            mems = list(by_type.get(mem_type, []))

            if context:
                mems.sort(
                    key=lambda m: ranking.activation_score(
                        m, task_match_by_id.get(m["id"], 0.0), project, now
                    ),
                    reverse=True,
                )
                if mem_type == "progress":
                    mems = [
                        m for m in mems if _parse_dt(m.get("updated_at", "")) >= cutoff_7d
                    ]
            elif mem_type == "progress":
                mems = [
                    m for m in mems if _parse_dt(m.get("updated_at", "")) >= cutoff_7d
                ]
                mems.sort(key=lambda m: m.get("updated_at", ""), reverse=True)
            elif mem_type == "procedure":
                mems.sort(
                    key=lambda m: (m.get("reuse_count", 0), m.get("confidence", 0.0)),
                    reverse=True,
                )
            else:
                mems.sort(key=lambda m: m.get("confidence", 0.0), reverse=True)

            chosen = mems[:limit]
            leftover = len(mems) - len(chosen)
            selected.extend(chosen)
            if leftover > 0:
                overflow_hints.append({"type": mem_type, "overflow": leftover})

        return selected, overflow_hints
