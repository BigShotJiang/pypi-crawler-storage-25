"""Pure ranking functions for search and load.

No DB, no I/O, no service state — these functions take a list of memory
dicts and return scores or re-ranked lists. Tests cover them directly.

Three responsibilities:

- ``activation_score(memory, task_match, project, now)`` — score one memory
  for ranking. ``task_match * 2 + confidence + recency*0.5 + reuse*0.5 +
  scope_fit``. Constants live in :mod:`deja.core.store.policy`.
- ``confusability_penalty(scored)`` — down-rank procedures with cosine >0.85
  to a higher-ranked procedure. Returns the same shape with mutated scores.
- ``compute_task_match(memories, context, embedding_adapter, fts_results)``
  — produces the ``{id: task_match}`` map used by ``LoadService.load_budgeted``
  to drive context-aware re-ranking.

Phase 8 moved the bodies of ``activation_score`` and ``confusability_penalty``
here from ``_helpers.py``. The underscore-prefixed names there
(``_activation_score`` / ``_apply_confusability_penalty``) are now thin
back-compat aliases pointing at this module — kept because external
imports and ``test_store_module_split`` pin that import path.
"""
from __future__ import annotations

import logging
import struct
from datetime import datetime, timezone
from typing import Any, Optional

from deja.core.store._helpers import _bytes_to_emb, _cosine_similarity
from deja.core.store.policy import (
    CONFUSABILITY_COSINE_THRESHOLD,
    CONFUSABILITY_PENALTY,
    FTS_RANK_FLOOR,
    RECENCY_HORIZON_DAYS,
    RECENCY_WEIGHT,
    REUSE_NORMALIZATION_CAP,
    REUSE_WEIGHT,
    SCOPE_FIT_BONUS,
    TASK_MATCH_WEIGHT,
)

logger = logging.getLogger(__name__)


def activation_score(
    mem: dict,
    task_match: float,
    project: Optional[str],
    now_dt: datetime,
) -> float:
    """Score a memory for activation ranking.

    ``score = task_match * TASK_MATCH_WEIGHT + confidence + recency *
    RECENCY_WEIGHT + reuse_norm * REUSE_WEIGHT + scope_fit``.

    All components are in [0, 1] except ``task_match`` which is weighted
    ``TASK_MATCH_WEIGHT`` (currently 2×) because retrieval relevance is
    the primary signal. Defensive: malformed/empty ``created_at`` falls
    through as ``days_old=0`` (treats it as "just now").
    """
    try:
        created_str = mem.get("created_at", "")
        created = datetime.fromisoformat(created_str)
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        days_old = (now_dt - created).days
    except (ValueError, TypeError):
        days_old = 0
    recency = max(0.0, 1.0 - days_old / RECENCY_HORIZON_DAYS)
    reuse_norm = (
        min(mem.get("reuse_count", 0), REUSE_NORMALIZATION_CAP)
        / REUSE_NORMALIZATION_CAP
    )
    scope_fit = SCOPE_FIT_BONUS if (project and mem.get("project") == project) else 0.0
    confidence = mem.get("confidence", 1.0)
    return (
        task_match * TASK_MATCH_WEIGHT
        + confidence
        + recency * RECENCY_WEIGHT
        + reuse_norm * REUSE_WEIGHT
        + scope_fit
    )


def confusability_penalty(
    scored: list[tuple[dict, Optional[bytes], float]],
) -> list[tuple[dict, Optional[bytes], float]]:
    """Down-rank procedures highly similar to a higher-ranked procedure.

    Processes in score-descending order. For each procedure, if its
    embedding is more than ``CONFUSABILITY_COSINE_THRESHOLD`` cosine-
    similar to any higher-ranked procedure, multiply its score by
    ``CONFUSABILITY_PENALTY``. Only applies when the memory has a stored
    embedding.
    """
    scored_sorted = sorted(scored, key=lambda x: x[2], reverse=True)
    claimed_embeddings: list[list[float]] = []
    result: list[tuple[dict, Optional[bytes], float]] = []

    for mem, emb_bytes, score in scored_sorted:
        if mem.get("type") == "procedure" and emb_bytes:
            try:
                mem_emb = _bytes_to_emb(emb_bytes)
                is_confusable = any(
                    _cosine_similarity(mem_emb, higher) > CONFUSABILITY_COSINE_THRESHOLD
                    for higher in claimed_embeddings
                )
            except (struct.error, TypeError):
                # Malformed embedding bytes (truncated row, dim mismatch, or
                # non-bytes column) — skip confusability ranking for this row
                # rather than blowing up the entire load/search re-rank pass.
                # Mirrors the guard in SearchService.embedding_search.
                result.append((mem, emb_bytes, score))
                continue
            if is_confusable:
                score *= CONFUSABILITY_PENALTY
            else:
                claimed_embeddings.append(mem_emb)
        result.append((mem, emb_bytes, score))

    return result


async def compute_task_match(
    memories: list[dict],
    context: str,
    embedding_adapter: Any,
    fts_results: list[dict],
) -> dict[str, float]:
    """Build the ``{memory_id: task_match}`` map for context-aware ranking.

    Two passes (the second overrides the first per id):

    1. **FTS pass** — every memory in ``fts_results`` gets
       ``max(FTS_RANK_FLOOR, 1.0 - rank / len(fts_results))``. So the top FTS
       hit gets ~1.0 and the floor caps the bottom at 0.1.
    2. **Embedding pass** — when ``embedding_adapter`` is present, embed
       ``context`` once, then write cosine similarity for every memory that
       has a stored embedding. This **overrides** the FTS task_match for the
       same id — embeddings are the higher-quality signal when both fire.

    Embedding errors are logged at WARNING and swallowed; the FTS task_match
    survives for those ids. Memories that match neither signal are absent
    from the map (caller defaults them to 0.0).
    """
    task_match_by_id: dict[str, float] = {}

    fts_count = max(len(fts_results), 1)
    for rank, mem in enumerate(fts_results):
        task_match_by_id[mem["id"]] = max(FTS_RANK_FLOOR, 1.0 - rank / fts_count)

    if embedding_adapter is not None:
        try:
            query_emb = await embedding_adapter.embed(context)
            for mem in memories:
                emb_bytes = mem.get("embedding")
                if isinstance(emb_bytes, bytes):
                    sim = _cosine_similarity(query_emb, _bytes_to_emb(emb_bytes))
                    task_match_by_id[mem["id"]] = sim
        except Exception as e:  # pragma: no cover — adapter-dependent
            logger.warning("compute_task_match embedding error: %s", e)

    return task_match_by_id


__all__ = [
    "activation_score",
    "confusability_penalty",
    "compute_task_match",
]
