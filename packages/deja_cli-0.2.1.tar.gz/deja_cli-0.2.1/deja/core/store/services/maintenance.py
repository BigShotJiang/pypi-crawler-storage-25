"""Maintenance service: dedup_fuzzy, decay, archive, promote, stats.

The cold-path complement to ``SaveService``. Owns operations that need a
whole-corpus or cross-table view rather than the per-row hot path:

- ``dedup_fuzzy`` — token-overlap dedup, formerly inlined in ``save``. Now
  runs at reflection time so save stays <1ms. Idempotent.
- ``decay_unconfirmed`` — drop confidence on rows not confirmed in N days.
- ``archive_below_threshold`` — sweep low-confidence rows into the archive.
- ``increment_reuse_count`` — bump every active row's reuse_count after a
  successful reflection pass (a "you survived compression" signal).
- ``promote_patterns_to_global`` — promote project-scoped patterns/procedures
  that recur across N projects. Allowed to call ``SearchService.find_similar``
  per the Phase-4 composition rule (the global-existence check is a ranking
  concern, not a SQL concern).
- ``get_stats`` — composes counts across ``MemoryRepository``,
  ``ObservationRepository``, ``ReflectionMetaRepository``.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import aiosqlite
from ulid import ULID

from deja.core.store._helpers import (
    _merge_trigger_phrases,
    _now_iso,
    _token_overlap,
)
from deja.core.store.connection import Connection
from deja.core.store.policy import (
    DECAY_WEEK_DIVISOR,
    DEDUP_OVERLAP_THRESHOLD,
)
from deja.core.store.queries import MEMORY_INSERT_SQL
from deja.core.store.repos.memories import MemoryRepository
from deja.core.store.repos.observations import ObservationRepository
from deja.core.store.repos.reflection import ReflectionMetaRepository


class MaintenanceService:
    """Reflection-time and scheduled maintenance.

    Holds three repos because ``get_stats`` composes across all of them and
    splitting it across services would invert the dependency direction.
    """

    def __init__(
        self,
        connection: Connection,
        memory_repo: MemoryRepository,
        observation_repo: ObservationRepository,
        reflection_repo: ReflectionMetaRepository,
        search_service: Any = None,
    ) -> None:
        self._connection = connection
        self._mem = memory_repo
        self._obs = observation_repo
        self._meta = reflection_repo
        # Optional — only promote_patterns_to_global needs it. Tests can omit.
        self._search = search_service

    # ── fuzzy dedup (Phase 6 behavior change; ships in Phase 7 wiring) ─────

    async def dedup_fuzzy(
        self,
        project: Optional[str] = None,
        threshold: float = DEDUP_OVERLAP_THRESHOLD,
    ) -> dict:
        """Token-overlap dedup across active memories for a project (or global).

        Algorithm:
        1. Stream active memories for the scope.
        2. For each, FTS-search same-type candidates (cheap candidate set).
        3. If token overlap with any candidate exceeds ``threshold`` and that
           candidate is older, merge into the older row: bump its confidence
           via ``_merge_trigger_phrases``-style trigger union, then archive
           the newer row (preserve audit trail — never delete).

        Returns ``{"merged": N, "archived": N}``. **Idempotent**: a second
        run finds nothing new because the newer rows are now archived.
        """
        merged = 0
        archived = 0

        async with self._connection.transaction() as db:
            active = await self._mem.fetch_active(db, project)
            seen: set[str] = set()  # ids already merged-away in this pass

            for mem in active:
                if mem.id in seen:
                    continue
                candidates = await self._mem.find_similar_by_fts(
                    db, mem.content, project=project, mem_type=mem.type, limit=10
                )
                for cand in candidates:
                    if cand.id == mem.id or cand.id in seen:
                        continue
                    if cand.scope != mem.scope:
                        continue
                    if _token_overlap(mem.content, cand.content) <= threshold:
                        continue

                    # Merge into the older row to preserve created_at history.
                    older, newer = (
                        (mem, cand) if mem.created_at <= cand.created_at else (cand, mem)
                    )
                    new_trigger = _merge_trigger_phrases(older.trigger, newer.trigger)
                    now = _now_iso()
                    await self._mem.update_confidence(
                        db,
                        memory_id=older.id,
                        confidence=min(1.0, older.confidence + 0.05),
                        reuse_count=older.reuse_count + 1,
                        last_confirmed=now,
                        updated_at=now,
                        trigger=new_trigger,
                    )
                    await self._mem.archive(db, newer.id, when=now)
                    seen.add(newer.id)
                    merged += 1
                    archived += 1
                    if newer.id == mem.id:
                        # mem itself got archived — stop comparing it.
                        break

        return {"merged": merged, "archived": archived}

    # ── decay / archive / reuse ────────────────────────────────────────────

    async def decay_unconfirmed(
        self,
        days_threshold: int,
        decay_per_week: float,
        user_decay_per_week: float,
    ) -> int:
        """Reduce confidence on memories not confirmed in ``days_threshold`` days.

        Two rates by category:
        - ``agent`` (gotcha/decision/progress/pattern): operational knowledge,
          decays at ``decay_per_week``.
        - ``user`` (preferences/habits): personal style, decays at the slower
          ``user_decay_per_week``.

        Returns the number of rows whose confidence actually moved (>0.001).
        """
        now = datetime.now(timezone.utc)
        threshold_iso = (now - timedelta(days=days_threshold)).isoformat()

        async with self._connection.transaction() as db:
            stale_rows = await self._mem.fetch_stale_for_decay(db, threshold_iso)
            count = 0
            for row in stale_rows:
                lc = row["last_confirmed"]
                if lc:
                    weeks_since = (now - datetime.fromisoformat(lc)).days / DECAY_WEEK_DIVISOR
                else:
                    weeks_since = days_threshold / DECAY_WEEK_DIVISOR

                rate = (
                    user_decay_per_week
                    if row["category"] == "user"
                    else decay_per_week
                )
                new_conf = max(0.0, row["confidence"] - rate * weeks_since)
                if abs(new_conf - row["confidence"]) > 0.001:
                    await self._mem.update_fields(
                        db,
                        row["id"],
                        confidence=new_conf,
                        updated_at=_now_iso(),
                    )
                    count += 1
        return count

    async def archive_below_threshold(self, threshold: float) -> int:
        """Sweep active rows with confidence < threshold into the archive."""
        async with self._connection.transaction() as db:
            return await self._mem.archive_below(db, threshold, when=_now_iso())

    async def increment_reuse_count(self, project: Optional[str] = None) -> int:
        """Bump every active row's reuse_count by 1 (post-reflection signal)."""
        async with self._connection.transaction() as db:
            return await self._mem.increment_reuse_by_scope(
                db, project, updated_at=_now_iso()
            )

    # ── promote patterns to global ─────────────────────────────────────────

    async def promote_patterns_to_global(self, min_project_count: int) -> int:
        """Promote project-scoped patterns/procedures recurring across N projects.

        For each pattern, find token-overlap-similar (>0.7) rows in *other*
        projects. If at least ``min_project_count`` distinct projects have a
        match and no global-scope memory of that type already exists for the
        content, insert a copy at global scope. Returns count promoted.

        Calls ``SearchService.find_similar`` for the global-existence check —
        this is the one declared service→service exception (see
        ``services/__init__.py`` composition rules).
        """
        if self._search is None:
            raise RuntimeError(
                "promote_patterns_to_global requires SearchService. Pass it to "
                "MaintenanceService.__init__."
            )

        promoted = 0
        processed: set[str] = set()

        async with self._connection.transaction() as db:
            patterns_pat = await self._mem.fetch_active_type_scope(
                db, mem_type="pattern", exclude_global=True
            )
            patterns_proc = await self._mem.fetch_active_type_scope(
                db, mem_type="procedure", exclude_global=True
            )
            patterns = patterns_pat + patterns_proc
            patterns.sort(key=lambda m: m.created_at)

            for i, pat in enumerate(patterns):
                if pat.id in processed:
                    continue

                similar = [pat]
                for other in patterns[i + 1:]:
                    if other.id in processed or other.project == pat.project:
                        continue
                    if _token_overlap(pat.content, other.content) > 0.7:
                        similar.append(other)

                distinct_projects = {m.project for m in similar if m.project}
                if len(distinct_projects) < min_project_count:
                    continue

                global_candidates = await self._search.find_similar(
                    pat.content, project=None, mem_type=pat.type, limit=5
                )
                if any(m.scope == "global" for m in global_candidates):
                    for m in similar:
                        processed.add(m.id)
                    continue

                best = max(similar, key=lambda m: m.confidence)
                now = _now_iso()
                await db.execute(
                    MEMORY_INSERT_SQL,
                    (
                        str(ULID()),
                        best.type,
                        best.category,
                        best.content,
                        "global",
                        None,
                        "deja_promote",
                        best.confidence,
                        best.reuse_count,
                        best.domain,
                        best.entity_graph,
                        best.trigger,
                        None,  # embedding — promote leaves regen to backfill
                        now,
                        now,
                        # Bug N4 (2026-04-19): a promoted-to-global row is
                        # a brand-new memory from the Observer's POV (the
                        # global scope hasn't seen this content before),
                        # so seed last_content_change_at = now to make
                        # the row immediately visible to the next observer
                        # pass at global scope.
                        now,
                        now,
                    ),
                )
                promoted += 1
                for m in similar:
                    processed.add(m.id)

        return promoted

    # ── stats (cross-repo composition) ─────────────────────────────────────

    async def get_stats(self, project: Optional[str] = None) -> dict:
        """Compose counts/aggregates from all three repos. Mirrors the facade."""
        db = await self._connection.get()

        by_type = await self._mem.count_active(db, project)
        archived = await self._mem.count_archived(db, project)
        invalidated = await self._mem.count_invalidated(db, project)
        with_embeddings = await self._mem.count_with_embeddings(db, project)
        contents = await self._mem.active_contents(db, project)
        token_estimate = sum(len(c.split()) * 2 for c in contents)
        obs_count = await self._obs.count(db, project)
        meta = await self._meta.get(db, project)

        return {
            "project": project or "global",
            "active": sum(by_type.values()),
            "by_type": by_type,
            "archived": archived,
            "invalidated": invalidated,
            "observations": obs_count,
            "token_estimate": token_estimate,
            "with_embeddings": with_embeddings,
            "last_observer_at": meta.last_observer_at if meta else None,
            "last_reflector_at": meta.last_reflector_at if meta else None,
            "last_decay_at": meta.last_decay_at if meta else None,
        }
