"""Save path service.

The hot path: turn an incoming ``Memory`` into either a new row or a
confidence bump on an existing one. **Exact-match dedup only** — fuzzy
token-overlap dedup is a maintenance concern (see
:class:`deja.core.store.services.maintenance.MaintenanceService.dedup_fuzzy`),
not a save-time tax.

Behavior contract:

- Exact duplicate (same scope/project/type/content, active row): bump
  ``confidence`` by ``CONFIDENCE_BUMP`` (cap ``CONFIDENCE_MAX``), increment
  ``reuse_count``, stamp ``last_confirmed`` + ``updated_at`` to now, merge
  trigger phrases (``_merge_trigger_phrases``). Returns ``SaveResult(id,
  is_new=False, cloud_data=...)``.
- No duplicate: ``repo.insert(memory)`` and return
  ``SaveResult(id, is_new=True, cloud_data=...)``.
- Trigger merging fires on every dedup hit, not just save: if you call
  ``save(content="X", trigger="alpha")`` then ``save(content="X",
  trigger="beta")``, the row ends up with ``trigger="alpha, beta"``.

``cloud_data`` shape (Phase 8 normalization)
-------------------------------------------

Both the dedup and insert paths return **the same set of keys** so
downstream cloud sync (``deja.cloud.push_memory``) sees a uniform
contract. The shape is built by :func:`_build_cloud_data` and is:

``id, content, type, category, scope, project, confidence, trigger,
created_at, updated_at, last_confirmed``.

On the dedup path ``created_at`` is the original row's creation
timestamp (from the existing record, not the incoming write); on the
insert path it's the just-minted timestamp. Either way the key is
present, which lets cloud-side replicators audit row age without a
second SELECT and removes a quiet shape divergence that was a latent
bug pre-Phase-8.
"""
from __future__ import annotations

from typing import Optional

import aiosqlite

from deja.core.store._helpers import (
    SaveResult,
    _merge_trigger_phrases,
    _now_iso,
)
from deja.core.store.connection import Connection
from deja.core.store.model import Memory
from deja.core.store.policy import (
    CONFIDENCE_BUMP,
    CONFIDENCE_MAX,
    MAX_CONTENT_LENGTH,
    MemoryTooLongError,
)
from deja.core.store.repos.memories import MemoryRepository


class SaveService:
    """Save + save_batch on top of ``MemoryRepository``.

    Owns its ``Connection`` for transaction management. ``save()`` opens its
    own outer transaction; ``save_batch()`` opens one transaction for all
    items so a single failure rolls back the whole batch.
    """

    def __init__(self, connection: Connection, repo: MemoryRepository) -> None:
        self._connection = connection
        self._repo = repo

    async def save(
        self, memory: Memory, embedding: Optional[bytes] = None
    ) -> SaveResult:
        """Save one memory. Exact-match dedup → bump-or-insert. See module docstring."""
        async with self._connection.transaction() as db:
            return await self._save_in_tx(db, memory, embedding)

    async def save_batch(
        self, items: list[tuple[Memory, Optional[bytes]]]
    ) -> list[SaveResult]:
        """Save a list of (memory, embedding) pairs in one transaction.

        Any exception in the middle rolls back the whole batch (the soft-
        reentrant ``Connection.transaction()`` re-raises after rollback).
        Empty list returns ``[]`` without touching the DB.
        """
        if not items:
            return []
        results: list[SaveResult] = []
        async with self._connection.transaction() as db:
            for memory, embedding in items:
                results.append(await self._save_in_tx(db, memory, embedding))
        return results

    async def _save_in_tx(
        self,
        db: aiosqlite.Connection,
        memory: Memory,
        embedding: Optional[bytes],
    ) -> SaveResult:
        """Core dedup-or-insert. Caller owns the transaction (see save/save_batch)."""
        # Per-memory content cap. The check is the very first statement so
        # an oversized item never touches the repo (no find_exact_duplicate
        # query, no insert, no embedding merge) and inside save_batch the
        # raise rolls back the whole transaction. The cap matches the
        # cloud's free-tier limit; see deja.core.store.policy for rationale.
        if len(memory.content) > MAX_CONTENT_LENGTH:
            raise MemoryTooLongError(content_length=len(memory.content))

        # Apply embedding to the model so the persisted row carries it.
        if embedding is not None and memory.embedding is None:
            memory = memory.model_copy(update={"embedding": embedding})

        existing = await self._repo.find_exact_duplicate(
            db,
            content=memory.content,
            scope=memory.scope,
            project=memory.project,
            mem_type=memory.type,
        )

        if existing is not None:
            return await self._bump_existing(db, existing, memory)

        # Bug H4 (2026-04-18): the SELECT-then-INSERT is racy across
        # processes. Two writers (CLI + watcher + MCP server) can both
        # pass find_exact_duplicate before either INSERT lands. The
        # partial UNIQUE index on (scope, project, type, content) for
        # active rows now turns the loser's INSERT into IntegrityError;
        # we catch it and converge to the bump path instead of
        # silently producing duplicate rows.
        try:
            await self._repo.insert(db, memory)
        except aiosqlite.IntegrityError:
            existing = await self._repo.find_exact_duplicate(
                db,
                content=memory.content,
                scope=memory.scope,
                project=memory.project,
                mem_type=memory.type,
            )
            if existing is None:
                # The IntegrityError wasn't from our dedup index — re-raise
                # so we don't mask a different schema violation (e.g. a
                # NOT NULL on a column we forgot).
                raise
            return await self._bump_existing(db, existing, memory)

        cloud_data = _build_cloud_data(
            id=memory.id,
            content=memory.content,
            type=memory.type,
            category=memory.category,
            scope=memory.scope,
            project=memory.project,
            confidence=memory.confidence,
            trigger=memory.trigger,
            created_at=memory.created_at,
            updated_at=memory.updated_at,
            last_confirmed=memory.last_confirmed,
        )
        return SaveResult(memory.id, True, cloud_data)

    async def _bump_existing(
        self,
        db: aiosqlite.Connection,
        existing: Memory,
        incoming: Memory,
    ) -> SaveResult:
        """Apply the dedup bump to ``existing`` from ``incoming``.

        Extracted so both the SELECT-found and IntegrityError-recovered
        paths share the exact same shape (confidence cap, trigger merge,
        timestamp stamping, cloud_data assembly).
        """
        now = _now_iso()
        new_confidence = min(CONFIDENCE_MAX, existing.confidence + CONFIDENCE_BUMP)
        new_reuse = existing.reuse_count + 1
        merged_trigger = _merge_trigger_phrases(existing.trigger, incoming.trigger)

        await self._repo.update_confidence(
            db,
            memory_id=existing.id,
            confidence=new_confidence,
            reuse_count=new_reuse,
            last_confirmed=now,
            updated_at=now,
            trigger=merged_trigger,
        )

        # Bug N1 (2026-04-19): backfill the embedding when the existing row
        # has none and the incoming save brought one along. Without this
        # the bytes the embedding adapter just computed are silently
        # dropped on every dedup-bump, so the row never gets a vector and
        # search ranking has to fall back to FTS forever. We never
        # *overwrite* an existing embedding — first-write wins; recompute
        # is fine but rewriting the row's vector here would churn the
        # ANN index for no semantic gain.
        if existing.embedding is None and incoming.embedding is not None:
            await self._repo.set_embedding(
                db,
                memory_id=existing.id,
                embedding=incoming.embedding,
                updated_at=now,
            )

        cloud_data = _build_cloud_data(
            id=existing.id,
            content=incoming.content,
            type=incoming.type,
            category=existing.category,
            scope=incoming.scope,
            project=incoming.project,
            confidence=new_confidence,
            trigger=merged_trigger,
            created_at=existing.created_at,
            updated_at=now,
            last_confirmed=now,
        )
        return SaveResult(existing.id, False, cloud_data)


# Single source of truth for the SaveResult.cloud_data shape so both the
# dedup and insert paths emit an identical key set. Downstream consumers
# (deja.cloud.push_memory) filter to the cloud's _PUSH_FIELDS subset; the
# extra keys here let auditors and other replicators see the full mutated
# row without a second SELECT.
def _build_cloud_data(
    *,
    id: str,
    content: str,
    type: str,
    category: str,
    scope: str,
    project: Optional[str],
    confidence: float,
    trigger: Optional[str],
    created_at: str,
    updated_at: str,
    last_confirmed: Optional[str],
) -> dict:
    return {
        "id": id,
        "content": content,
        "type": type,
        "category": category,
        "scope": scope,
        "project": project,
        "confidence": confidence,
        "trigger": trigger,
        "created_at": created_at,
        "updated_at": updated_at,
        "last_confirmed": last_confirmed,
    }
