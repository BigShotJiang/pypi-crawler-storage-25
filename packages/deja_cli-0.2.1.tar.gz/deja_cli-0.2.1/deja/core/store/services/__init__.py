"""Service layer for the store package.

Phase 6 of the restructure (see ``docs/store-restructure-plan.md``). Each service
class owns one responsibility on top of the repos:

- ``SaveService`` — exact-match dedup + insert (hot path; <1ms).
- ``SearchService`` — trigger / FTS / embedding / hybrid retrieval.
- ``LoadService`` — slot-allocated context loading with overflow hints.
- ``MaintenanceService`` — fuzzy dedup, decay, archive, promote, stats.

Pure ranking math lives in :mod:`deja.core.store.services.ranking` rather
than on a service so the facade and other services can call it directly.

Composition rules — locked in Phase 4, enforced here:

1. **Services depend on repos only**, never on other services. Shared
   primitives (e.g. an FTS candidate lookup used by both search and dedup)
   live on a **repo** instead.

2. **One declared exception**: ``MaintenanceService.promote_patterns_to_global``
   may call ``SearchService.find_similar``. That's a ranking concern, not a
   SQL concern, and the alternative is duplicating the hybrid-search pipeline
   inside maintenance.

3. **Services hold a ``Connection`` and own their commits.** Methods open
   ``conn.transaction()`` internally for write paths. Read-only methods can
   use ``await connection.get()`` directly. Soft-reentrant transactions mean
   callers can wrap multiple service calls in one outer ``conn.transaction()``
   without deadlocking — the inner transactions join the outer BEGIN.

4. **No facade wiring yet.** Phase 6 ships the services as standalone,
   tested classes. Phase 7 rewires ``MemoryStore`` to delegate. Until then,
   the existing facade methods continue to own their inline SQL and the
   services run only via their unit tests.
"""
from deja.core.store.services.load import LoadService
from deja.core.store.services.maintenance import MaintenanceService
from deja.core.store.services.save import SaveService
from deja.core.store.services.search import SearchService

__all__ = [
    "LoadService",
    "MaintenanceService",
    "SaveService",
    "SearchService",
]
