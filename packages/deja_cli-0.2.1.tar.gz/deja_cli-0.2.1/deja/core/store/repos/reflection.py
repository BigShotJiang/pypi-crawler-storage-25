"""Repository for the ``reflection_meta`` table."""
from __future__ import annotations

from typing import Any, Optional

import aiosqlite

from deja.core.store._helpers import _project_meta_key
from deja.core.store.model import ReflectionMeta

# Columns accepted by upsert. Matches the schema minus the PK.
_META_COLUMNS: tuple[str, ...] = (
    "last_observer_at",
    "last_reflector_at",
    "last_decay_at",
    "last_promote_at",
    "last_archive_at",
)


class ReflectionMetaRepository:
    """Per-project reflection timestamps. One row per project (``"__global__"``
    sentinel for memories with no project)."""

    async def get(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> Optional[ReflectionMeta]:
        key = _project_meta_key(project)
        async with db.execute(
            "SELECT * FROM reflection_meta WHERE project = ?", (key,)
        ) as cur:
            row = await cur.fetchone()
            return ReflectionMeta.from_row(row) if row else None

    async def upsert(
        self, db: aiosqlite.Connection, project: Optional[str], **fields: Any
    ) -> None:
        """Insert a new row with defaults or update the existing one.

        Only columns in ``_META_COLUMNS`` are accepted. Unknown keys raise.
        """
        unknown = set(fields) - set(_META_COLUMNS)
        if unknown:
            raise ValueError(f"unknown column(s) for reflection_meta: {sorted(unknown)}")

        key = _project_meta_key(project)
        existing = await self.get(db, project)
        if existing is None:
            row: dict[str, Any] = {"project": key}
            for col in _META_COLUMNS:
                row[col] = fields.get(col)
            cols = ",".join(row.keys())
            placeholders = ",".join("?" for _ in row)
            await db.execute(
                f"INSERT INTO reflection_meta ({cols}) VALUES ({placeholders})",
                list(row.values()),
            )
            return

        if not fields:
            return
        set_clause = ",".join(f"{f} = ?" for f in fields)
        await db.execute(
            f"UPDATE reflection_meta SET {set_clause} WHERE project = ?",
            list(fields.values()) + [key],
        )
