"""Repository for the ``observations`` table."""
from __future__ import annotations

from typing import Optional

import aiosqlite

from deja.core.store.model import Observation


class ObservationRepository:
    """CRUD on the ``observations`` table. No commits inside — caller owns the
    transaction (services typically use ``Connection.transaction()``).
    """

    async def insert(
        self, db: aiosqlite.Connection, observation: Observation
    ) -> None:
        await db.execute(
            "INSERT INTO observations "
            "(id, project, content, token_estimate, created_at, reflector_pass) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                observation.id,
                observation.project,
                observation.content,
                observation.token_estimate,
                observation.created_at,
                observation.reflector_pass,
            ),
        )

    async def list(
        self, db: aiosqlite.Connection, project: Optional[str] = None
    ) -> list[Observation]:
        if project is not None:
            async with db.execute(
                "SELECT * FROM observations WHERE project = ? ORDER BY created_at ASC",
                (project,),
            ) as cur:
                rows = await cur.fetchall()
        else:
            async with db.execute(
                "SELECT * FROM observations ORDER BY created_at ASC"
            ) as cur:
                rows = await cur.fetchall()
        return [Observation.from_row(r) for r in rows]

    async def delete_for(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> None:
        """Delete all observations for a project (or the global bucket)."""
        if project is not None:
            await db.execute("DELETE FROM observations WHERE project = ?", (project,))
        else:
            await db.execute("DELETE FROM observations WHERE project IS NULL")

    async def delete_by_ids(
        self, db: aiosqlite.Connection, ids: list[str]
    ) -> None:
        """Delete only the observations matching the supplied IDs.

        Bug N3 (2026-04-19): the reflector previously called ``delete_for(
        project)`` after the LLM round-trip, which atomically wiped every
        observation for the project — including any rows the Observer had
        just inserted while the LLM was thinking. Those rows were never
        condensed (the reflector didn't know about them), so they were
        permanently lost. Switching to "delete only the IDs we actually
        consumed" closes that race window: any concurrent observer write
        survives to the next reflector pass.
        """
        if not ids:
            return
        # SQLite has a 999-host-parameter cap; chunk to stay well under
        # that for large reflector batches.
        CHUNK = 500
        for start in range(0, len(ids), CHUNK):
            chunk = ids[start : start + CHUNK]
            placeholders = ",".join("?" * len(chunk))
            await db.execute(
                f"DELETE FROM observations WHERE id IN ({placeholders})",
                chunk,
            )

    async def list_distinct_projects(
        self, db: aiosqlite.Connection
    ) -> list[Optional[str]]:
        """Return the set of distinct project values that have at least one
        observation. Includes ``None`` (NULL bucket) if any global observations
        exist. Used by ReflectionEngine.run_reflector(None) to fan out into
        per-project passes (Bug N2, 2026-04-19) — without this, ``project=None``
        would mix every per-project log into a single condensed NULL row.

        SQLite's ``SELECT DISTINCT`` keeps NULL as a single distinct value;
        the resulting list contains ``None`` *at most once* if any rows have
        ``project IS NULL``, otherwise just the non-NULL strings.
        """
        async with db.execute(
            "SELECT DISTINCT project FROM observations"
        ) as cur:
            rows = await cur.fetchall()
        return [r["project"] for r in rows]

    async def count(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> int:
        if project is None:
            async with db.execute(
                "SELECT COUNT(*) AS n FROM observations"
            ) as cur:
                row = await cur.fetchone()
        else:
            async with db.execute(
                "SELECT COUNT(*) AS n FROM observations WHERE project = ?",
                (project,),
            ) as cur:
                row = await cur.fetchone()
        return row["n"] if row else 0
