"""Repository for the ``memories`` table.

CRUD + targeted read queries on a single table. SQL and row↔Memory mapping
only — no dedup logic, no ranking, no decay math. Callers hand in an
``aiosqlite.Connection`` and get back ``Memory`` objects (or primitives for
narrow queries like ``without_embeddings``/``distinct_projects``).

The method surface mirrors what the MemoryStore facade needs today plus a
``find_exact_duplicate`` stub for the Phase-6 save-service fast path.
"""
from __future__ import annotations

from typing import Any, Optional

import aiosqlite

from deja.core.store._helpers import _build_where, _sanitize_fts_query
from deja.core.store.model import Memory
from deja.core.store.queries import (
    ACTIVE_FILTER,
    MEMORY_INSERT_SQL,
    scope_filter,
)

def _project_scope_predicate(project: Optional[str]) -> tuple[str, list[Any]]:
    """Stats/aggregation scope predicate. Returns (clause, params).

    Differs from ``queries.scope_filter`` deliberately:
    - ``project=None`` here means **all scopes** (clause is ``"1=1"``) — the
      shape stats and bulk maintenance want.
    - ``project="X"`` matches **only** ``scope = 'project:X'`` (no global
      fallthrough), because counts/aggregates per project should not double-
      count global rows.

    Use this for ``count_*``/``active_contents``/``increment_reuse_by_scope``.
    Use ``queries.scope_filter`` for read paths that want global+project rows.
    """
    if project is None:
        return "1=1", []
    return "scope = ?", [f"project:{project}"]


# Columns accepted by update_fields. Matches the subset of memories columns
# that make sense to mutate post-insert (no PK, no immutable timestamps).
_UPDATABLE_COLUMNS: frozenset[str] = frozenset(
    {
        "type",
        "category",
        "content",
        "scope",
        "project",
        "source",
        "confidence",
        "reuse_count",
        "domain",
        "entity_graph",
        "trigger",
        "embedding",
        "last_confirmed",
        "archived_at",
        "invalidated_at",
    }
)


class MemoryRepository:
    """CRUD + queries on the ``memories`` table.

    Methods take an ``aiosqlite.Connection`` and NEVER call ``commit()``.
    The caller owns the transaction — compose with ``Connection.transaction()``
    when you need atomicity across multiple calls.
    """

    # ── reads ────────────────────────────────────────────────────────────────

    async def get(self, db: aiosqlite.Connection, memory_id: str) -> Optional[Memory]:
        async with db.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ) as cur:
            row = await cur.fetchone()
            return Memory.from_row(row) if row else None

    async def fetch_active(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> list[Memory]:
        """Active memories for a project + global, ordered by confidence DESC.

        Scope semantics — read carefully, they differ from other repo methods:
        - ``project=None`` → **global-only** (matches the historical behaviour
          of ``MemoryStore.load``; an unscoped session loads only global rows).
        - ``project="X"`` → ``scope='global' OR scope='project:X'`` (project
          rows plus global rows that apply everywhere).

        Other repo methods (``without_embeddings``, ``fetch_with_embeddings``,
        ``count_*``, ``active_contents``, ``increment_reuse_by_scope``) treat
        ``project=None`` as **all scopes** instead. The convention is split
        because ``fetch_active`` serves the load path (per-session view) while
        the others serve stats/maintenance (whole-DB view). Pick the right
        method for the call site.
        """
        scope_clause, params = scope_filter(project or "__global__")
        query = (
            "SELECT * FROM memories "
            f"WHERE {scope_clause} AND {ACTIVE_FILTER} "
            "ORDER BY confidence DESC"
        )
        async with db.execute(query, params) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def fetch_all_active(self, db: aiosqlite.Connection) -> list[Memory]:
        """All active memories across every scope, ordered scope ASC, confidence DESC."""
        async with db.execute(
            f"SELECT * FROM memories WHERE {ACTIVE_FILTER} "
            "ORDER BY scope ASC, confidence DESC"
        ) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def list_active_projects(
        self, db: aiosqlite.Connection
    ) -> list[Optional[str]]:
        """Distinct ``project`` values with at least one active memory.

        Includes ``None`` (global bucket) iff any active global rows
        exist. Parallels ``ObservationRepository.list_distinct_projects``
        and is used by ``ReflectionEngine.run_dedup_fuzzy(None)`` (Bug
        R4, 2026-04-22) to fan out dedup across every scope instead of
        operating only on globals.
        """
        async with db.execute(
            f"SELECT DISTINCT project FROM memories WHERE {ACTIVE_FILTER}"
        ) as cur:
            rows = await cur.fetchall()
        return [r["project"] for r in rows]

    async def fetch_for_sync(self, db: aiosqlite.Connection) -> list[Memory]:
        """Active + archived memories across every scope, for cloud sync push.

        Differs from ``fetch_all_active`` by including rows with
        ``archived_at IS NOT NULL`` so a ``deja archive``/``deja reflect``
        archive transition propagates on the next ``deja sync push`` (cloud
        Phase 3.4 — see CHANGELOG and ``~/projects/deja_sh/docs/improvement-
        plans/2026-04-18.md``). ``invalidated_at`` rows are still excluded —
        invalidation is local fuzzy-dedup state and intentionally does not
        cross the sync boundary (the cloud has no concept of it).

        Ordering matches ``fetch_all_active`` so push enumeration stays stable
        across the two methods.
        """
        async with db.execute(
            "SELECT * FROM memories WHERE invalidated_at IS NULL "
            "ORDER BY scope ASC, confidence DESC"
        ) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def fetch(
        self,
        db: aiosqlite.Connection,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        status: str = "active",
        limit: int = 200,
        offset: int = 0,
    ) -> tuple[list[Memory], int]:
        """Paginated list with filters. Returns (memories, total_matching)."""
        conditions: list[str] = []
        params: list[Any] = []

        if project == "__global__":
            conditions.append("scope = 'global'")
        elif project is not None:
            conditions.append("project = ?")
            params.append(project)

        if mem_type:
            conditions.append("type = ?")
            params.append(mem_type)

        if status == "active":
            conditions.append(ACTIVE_FILTER)
        elif status == "archived":
            conditions.append("archived_at IS NOT NULL")
        elif status == "invalidated":
            conditions.append("invalidated_at IS NOT NULL")
        # "all" — no status filter

        where = _build_where(conditions)

        async with db.execute(
            f"SELECT COUNT(*) AS n FROM memories {where}", params
        ) as cur:
            row = await cur.fetchone()
            total = row["n"] if row else 0

        async with db.execute(
            f"SELECT * FROM memories {where} "
            "ORDER BY confidence DESC, updated_at DESC LIMIT ? OFFSET ?",
            params + [limit, offset],
        ) as cur:
            rows = await cur.fetchall()

        return [Memory.from_row(r) for r in rows], total

    async def fetch_for_reflection(
        self,
        db: aiosqlite.Connection,
        project: Optional[str] = None,
        since: Optional[str] = None,
    ) -> list[Memory]:
        """Active memories for the Observer to process.

        ``project=None`` returns every scope; ``project="X"`` restricts to
        ``scope='project:X'``. ``since`` is an ISO timestamp lower bound
        on ``last_content_change_at`` (Bug N4, 2026-04-19) — the
        content-only mtime, NOT ``updated_at`` which gets bumped by every
        maintenance write (decay, reuse-bump, dedup-bump, embedding
        backfill). Filtering on ``updated_at`` made the cursor reset to
        "every active row" after any maintenance pass; on
        ``last_content_change_at`` it advances exactly when the Observer
        has new material to look at.

        ``COALESCE(last_content_change_at, updated_at)`` falls back for
        any rows whose backfill hasn't run yet (defense in depth — the
        backfill in init_db should already have seeded them).
        """
        conditions = [ACTIVE_FILTER]
        params: list[Any] = []
        if project is not None:
            conditions.append("scope = ?")
            params.append(f"project:{project}")
        if since:
            conditions.append(
                "COALESCE(last_content_change_at, updated_at) > ?"
            )
            params.append(since)
        where = _build_where(conditions)
        async with db.execute(
            f"SELECT * FROM memories {where} "
            f"ORDER BY COALESCE(last_content_change_at, updated_at) ASC",
            params,
        ) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def fetch_for_export(
        self,
        db: aiosqlite.Connection,
        project: Optional[str] = None,
        types: Optional[list[str]] = None,
        include_archived: bool = False,
    ) -> list[Memory]:
        """Export-oriented read: project-only (no global), typed, optional archived."""
        conditions: list[str] = []
        params: list[Any] = []

        if project:
            conditions.append("scope = ?")
            params.append(f"project:{project}")

        if types:
            placeholders = ",".join("?" for _ in types)
            conditions.append(f"type IN ({placeholders})")
            params.extend(types)

        if not include_archived:
            conditions.append(ACTIVE_FILTER)

        where = _build_where(conditions)
        async with db.execute(
            f"SELECT * FROM memories {where} ORDER BY created_at ASC", params
        ) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def without_embeddings(
        self, db: aiosqlite.Connection, project: Optional[str] = None
    ) -> list[dict]:
        """Active rows with no stored embedding — used by the backfill command.

        Returns ``[{"id": ..., "content": ...}]`` (narrow shape) rather than
        full ``Memory`` objects because that's all the caller needs.
        """
        conditions = [ACTIVE_FILTER, "embedding IS NULL"]
        scope_clause, params = scope_filter(project)
        if scope_clause:
            conditions.append(scope_clause)
        where = _build_where(conditions)
        async with db.execute(
            f"SELECT id, content FROM memories {where}", params
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]

    async def distinct_projects(self, db: aiosqlite.Connection) -> list[dict]:
        """Distinct project names with active memory count, ordered by count DESC."""
        async with db.execute(
            "SELECT project, COUNT(*) AS count FROM memories "
            f"WHERE project IS NOT NULL AND {ACTIVE_FILTER} "
            "GROUP BY project ORDER BY count DESC"
        ) as cur:
            rows = await cur.fetchall()
        return [{"name": r["project"], "count": r["count"]} for r in rows]

    async def find_exact_duplicate(
        self,
        db: aiosqlite.Connection,
        content: str,
        scope: str,
        project: Optional[str],
        mem_type: str,
    ) -> Optional[Memory]:
        """Equality-keyed dedup lookup for SaveService (Phase 6 hot path).

        Backed by ``idx_memories_dedup`` — exact match on
        (scope, project, type, content). Returns the active row if one exists,
        else None. Not called from the current facade yet.
        """
        # NOTE: ``project IS ?`` is intentional, not a typo. ``project`` is
        # nullable for the global scope, and SQL's ``=`` is NULL-unsafe
        # (``NULL = NULL`` evaluates to NULL, not TRUE). ``IS`` does the
        # equality we want for both NULL and non-NULL bound params.
        async with db.execute(
            "SELECT * FROM memories "
            "WHERE scope = ? AND project IS ? AND type = ? AND content = ? "
            f"AND {ACTIVE_FILTER} LIMIT 1",
            (scope, project, mem_type, content),
        ) as cur:
            row = await cur.fetchone()
            return Memory.from_row(row) if row else None

    async def find_similar_by_fts(
        self,
        db: aiosqlite.Connection,
        query: str,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        limit: int = 20,
    ) -> list[Memory]:
        """Raw FTS5 keyword search — no side effects, no ranking re-score.

        Used by SaveService's dedup candidate lookup and (in Phase 6) by
        SearchService and MaintenanceService.dedup_fuzzy.
        """
        params: list[Any] = [_sanitize_fts_query(query)]

        extra_conditions: list[str] = []
        scope_sql, scope_params = scope_filter(project, column_prefix="m.")
        if scope_sql:
            extra_conditions.append(scope_sql)
            params.extend(scope_params)

        if mem_type:
            extra_conditions.append("m.type = ?")
            params.append(mem_type)

        extra_clause = (
            ("AND " + " AND ".join(extra_conditions)) if extra_conditions else ""
        )
        params.append(limit)

        sql = (
            "SELECT m.* FROM memories m "
            "JOIN memories_fts ON m.rowid = memories_fts.rowid "
            "WHERE memories_fts MATCH ? "
            f"{extra_clause} "
            "AND m.archived_at IS NULL AND m.invalidated_at IS NULL "
            "ORDER BY memories_fts.rank LIMIT ?"
        )
        async with db.execute(sql, params) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def fetch_with_embeddings(
        self,
        db: aiosqlite.Connection,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
    ) -> list[Memory]:
        """Active rows that have a stored embedding. Used by embedding search."""
        conditions = [ACTIVE_FILTER, "embedding IS NOT NULL"]
        scope_sql, params = scope_filter(project)
        if scope_sql:
            conditions.append(scope_sql)
        if mem_type:
            conditions.append("type = ?")
            params.append(mem_type)
        where = _build_where(conditions)
        async with db.execute(
            f"SELECT * FROM memories {where}", params
        ) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def fetch_with_trigger(
        self,
        db: aiosqlite.Connection,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
    ) -> list[Memory]:
        """Active rows whose ``trigger`` is not NULL — Pass-0 candidates for search."""
        scope_sql, scope_params = scope_filter(project, column_prefix="m.")
        scope_clause = f"AND {scope_sql}" if scope_sql else ""

        type_clause = ""
        type_params: list[Any] = []
        if mem_type:
            type_clause = "AND m.type = ?"
            type_params = [mem_type]

        sql = (
            "SELECT m.* FROM memories m "
            "WHERE m.trigger IS NOT NULL "
            f"{scope_clause} {type_clause} "
            "AND m.archived_at IS NULL AND m.invalidated_at IS NULL "
            "ORDER BY m.reuse_count DESC, m.confidence DESC"
        )
        async with db.execute(sql, scope_params + type_params) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def fetch_active_type_scope(
        self,
        db: aiosqlite.Connection,
        mem_type: str,
        exclude_global: bool,
    ) -> list[Memory]:
        """Active rows of a given type, optionally excluding global scope.

        Supports MaintenanceService.promote_patterns_to_global (Phase 6) which
        looks at candidates per type in non-global scope.
        """
        conditions = ["type = ?", ACTIVE_FILTER]
        params: list[Any] = [mem_type]
        if exclude_global:
            conditions.append("scope != 'global'")
        where = _build_where(conditions)
        async with db.execute(
            f"SELECT * FROM memories {where} ORDER BY created_at ASC", params
        ) as cur:
            rows = await cur.fetchall()
        return [Memory.from_row(r) for r in rows]

    async def fetch_stale_for_decay(
        self,
        db: aiosqlite.Connection,
        threshold_iso: str,
    ) -> list[dict]:
        """Active rows whose last_confirmed is null or older than threshold.

        Narrow projection — the decay service only reads id/category/
        confidence/last_confirmed.
        """
        async with db.execute(
            "SELECT id, category, confidence, last_confirmed FROM memories "
            f"WHERE {ACTIVE_FILTER} "
            "AND (last_confirmed IS NULL OR last_confirmed < ?)",
            (threshold_iso,),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]

    # ── writes ───────────────────────────────────────────────────────────────

    async def insert(self, db: aiosqlite.Connection, memory: Memory) -> None:
        """Insert a new row. No commit — caller owns the transaction."""
        await db.execute(MEMORY_INSERT_SQL, memory.to_insert_params())

    async def update_fields(
        self, db: aiosqlite.Connection, memory_id: str, **fields: Any
    ) -> bool:
        """Generic UPDATE on a whitelist of columns. Returns True if a row changed.

        Always bumps ``updated_at`` to the caller-provided value — pass it as
        a keyword along with the other fields. Raises ``ValueError`` on an
        unknown column name to surface typos instead of silently no-op'ing.
        """
        unknown = set(fields) - _UPDATABLE_COLUMNS - {"updated_at"}
        if unknown:
            raise ValueError(f"unknown column(s) for update: {sorted(unknown)}")
        if not fields:
            return False

        set_clause = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [memory_id]
        cur = await db.execute(
            f"UPDATE memories SET {set_clause} WHERE id = ?", values
        )
        return cur.rowcount > 0

    async def update_confidence(
        self,
        db: aiosqlite.Connection,
        memory_id: str,
        confidence: float,
        reuse_count: int,
        last_confirmed: str,
        updated_at: str,
        trigger: Optional[str],
    ) -> None:
        """Dedup-path update: bump confidence + reuse + trigger merge + timestamps."""
        await db.execute(
            "UPDATE memories "
            "SET confidence = ?, reuse_count = ?, last_confirmed = ?, "
            "    updated_at = ?, trigger = ? "
            "WHERE id = ?",
            (confidence, reuse_count, last_confirmed, updated_at, trigger, memory_id),
        )

    async def set_embedding(
        self,
        db: aiosqlite.Connection,
        memory_id: str,
        embedding: bytes,
        updated_at: str,
    ) -> None:
        await db.execute(
            "UPDATE memories SET embedding = ?, updated_at = ? WHERE id = ?",
            (embedding, updated_at, memory_id),
        )

    async def stamp_last_confirmed(
        self,
        db: aiosqlite.Connection,
        memory_ids: list[str],
        when: str,
    ) -> None:
        if not memory_ids:
            return
        placeholders = ",".join("?" * len(memory_ids))
        await db.execute(
            f"UPDATE memories SET last_confirmed = ?, updated_at = ? "
            f"WHERE id IN ({placeholders})",
            [when, when, *memory_ids],
        )

    async def increment_reuse_for_ids(
        self,
        db: aiosqlite.Connection,
        memory_ids: list[str],
        updated_at: str,
    ) -> None:
        if not memory_ids:
            return
        placeholders = ",".join("?" * len(memory_ids))
        await db.execute(
            f"UPDATE memories SET reuse_count = reuse_count + 1, updated_at = ? "
            f"WHERE id IN ({placeholders})",
            [updated_at, *memory_ids],
        )

    async def increment_reuse_by_scope(
        self,
        db: aiosqlite.Connection,
        project: Optional[str],
        updated_at: str,
    ) -> int:
        """Bulk ``reuse_count += 1`` across a scope. Returns rowcount."""
        scope_clause, params = _project_scope_predicate(project)
        conditions = [ACTIVE_FILTER, scope_clause]
        where = _build_where(conditions)
        cur = await db.execute(
            f"UPDATE memories SET reuse_count = reuse_count + 1, updated_at = ? {where}",
            [updated_at] + params,
        )
        return cur.rowcount

    # Status columns ``archive`` and ``invalidate`` may stamp. Whitelist
    # rather than passing the column name through directly so the helper can
    # never be coaxed into writing to an arbitrary column.
    _STATUS_STAMP_COLUMNS: frozenset[str] = frozenset({"archived_at", "invalidated_at"})

    async def _set_status_stamp(
        self,
        db: aiosqlite.Connection,
        memory_id: str,
        column: str,
        when: str,
    ) -> None:
        """Stamp a status column + ``updated_at`` to ``when`` for one row.

        Private. ``column`` MUST be one of ``_STATUS_STAMP_COLUMNS`` — the
        helper raises ``ValueError`` otherwise so the column name can't
        leak in from caller-supplied input. Used by ``archive`` /
        ``invalidate`` to share the SET-and-stamp pattern.
        """
        if column not in self._STATUS_STAMP_COLUMNS:
            raise ValueError(f"unknown status column: {column!r}")
        await db.execute(
            f"UPDATE memories SET {column} = ?, updated_at = ? WHERE id = ?",
            (when, when, memory_id),
        )

    async def archive(
        self, db: aiosqlite.Connection, memory_id: str, when: str
    ) -> None:
        await self._set_status_stamp(db, memory_id, "archived_at", when)

    async def invalidate(
        self, db: aiosqlite.Connection, memory_id: str, when: str
    ) -> None:
        # Bug N4 (2026-04-19): invalidate is a content-state change (the
        # row asserted X but X turned out to be wrong). The Observer
        # already filters on ACTIVE_FILTER so it'll never *see* an
        # invalidated row, but we still bump last_content_change_at to
        # keep the column semantics honest: it tracks every change to
        # whether the row counts as "live knowledge".
        await self._set_status_stamp(db, memory_id, "invalidated_at", when)
        await db.execute(
            "UPDATE memories SET last_content_change_at = ? WHERE id = ?",
            (when, memory_id),
        )

    async def archive_below(
        self,
        db: aiosqlite.Connection,
        threshold: float,
        when: str,
    ) -> int:
        """Archive every active memory with confidence < threshold. Returns count."""
        cur = await db.execute(
            "UPDATE memories SET archived_at = ?, updated_at = ? "
            f"WHERE confidence < ? AND {ACTIVE_FILTER}",
            (when, when, threshold),
        )
        return cur.rowcount

    async def count_active(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> dict[str, int]:
        """Active counts grouped by type for a single project (or all when None).

        Shape: ``{"gotcha": 5, "pattern": 10, ...}``. Used by stats.
        """
        scope_clause, params = _project_scope_predicate(project)
        async with db.execute(
            "SELECT type, COUNT(*) AS cnt FROM memories "
            f"WHERE {scope_clause} AND {ACTIVE_FILTER} "
            "GROUP BY type",
            params,
        ) as cur:
            return {r["type"]: r["cnt"] for r in await cur.fetchall()}

    async def count_archived(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> int:
        scope_clause, params = _project_scope_predicate(project)
        async with db.execute(
            f"SELECT COUNT(*) AS n FROM memories "
            f"WHERE {scope_clause} AND archived_at IS NOT NULL",
            params,
        ) as cur:
            row = await cur.fetchone()
            return row["n"] if row else 0

    async def count_invalidated(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> int:
        scope_clause, params = _project_scope_predicate(project)
        async with db.execute(
            "SELECT COUNT(*) AS n FROM memories "
            f"WHERE {scope_clause} AND invalidated_at IS NOT NULL AND archived_at IS NULL",
            params,
        ) as cur:
            row = await cur.fetchone()
            return row["n"] if row else 0

    async def count_with_embeddings(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> int:
        scope_clause, params = _project_scope_predicate(project)
        async with db.execute(
            "SELECT COUNT(*) AS n FROM memories "
            f"WHERE {scope_clause} AND {ACTIVE_FILTER} AND embedding IS NOT NULL",
            params,
        ) as cur:
            row = await cur.fetchone()
            return row["n"] if row else 0

    async def active_contents(
        self, db: aiosqlite.Connection, project: Optional[str]
    ) -> list[str]:
        """Raw content strings for active memories — used for token estimate."""
        scope_clause, params = _project_scope_predicate(project)
        async with db.execute(
            f"SELECT content FROM memories WHERE {scope_clause} AND {ACTIVE_FILTER}",
            params,
        ) as cur:
            return [r["content"] for r in await cur.fetchall()]
