"""Repository layer for the store package.

Each repository encapsulates CRUD for a single table and returns typed
domain objects (``Memory``, ``Observation``, ``ReflectionMeta``). No business
policy lives here — weights, thresholds, merge rules, decay math all belong
to services (Phase 6).

Repositories are stateless classes: methods accept an ``aiosqlite.Connection``
as the first argument so the caller — the facade or a service — controls the
transaction boundary. This is what lets ``save_batch`` wrap many repo calls
in a single ``conn.transaction()`` without the repo knowing about it.
"""
from deja.core.store.repos.memories import MemoryRepository
from deja.core.store.repos.observations import ObservationRepository
from deja.core.store.repos.reflection import ReflectionMetaRepository

__all__ = [
    "MemoryRepository",
    "ObservationRepository",
    "ReflectionMetaRepository",
]
