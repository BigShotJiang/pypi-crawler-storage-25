"""Domain models for the store package.

Replaces the dict-based API inside the store with typed pydantic models.
The `MemoryStore` facade still accepts/returns dicts at the public boundary —
conversion happens there (``Memory.from_dict`` / ``memory.to_dict``). Inside
the package, repositories and services pass `Memory` objects.

Scope is kept as a flat string (``"global"`` or ``f"project:{name}"``) to
match the on-disk schema. A dedicated ``Scope`` type was drafted in Phase 1
but never adopted — see docs/store-restructure-plan.md for the reasoning.
"""
from __future__ import annotations

from typing import Any, NamedTuple, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator
from ulid import ULID


# ── Memory ────────────────────────────────────────────────────────────────────

class Memory(BaseModel):
    """A single memory row from the ``memories`` table.

    Field order mirrors the SQL column order in ``_schema.py`` so
    ``to_insert_params`` lines up with the static INSERT statement.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    id: str
    type: str
    category: str = "agent"
    content: str
    scope: str  # stored as raw string; Scope type is a boundary helper
    project: Optional[str] = None
    source: Optional[str] = None
    confidence: float = 1.0
    reuse_count: int = 0
    domain: Optional[str] = None
    entity_graph: Optional[str] = None
    trigger: Optional[str] = None
    embedding: Optional[bytes] = None
    created_at: str
    updated_at: str
    # Bug N4 (2026-04-19): content-only mtime so the Observer cursor isn't
    # invalidated by maintenance writes (decay, reuse-bump, dedup-bump,
    # embedding-backfill). Bumped on insert, content-changing upsert,
    # invalidate. Optional because pre-N4 rows / pre-N4 fixture dicts may
    # omit it; the store-side backfill seeds those to ``updated_at``.
    last_content_change_at: Optional[str] = None
    last_confirmed: Optional[str] = None
    archived_at: Optional[str] = None
    invalidated_at: Optional[str] = None

    @model_validator(mode="after")
    def _default_last_content_change_at(self) -> "Memory":
        # Bug N4 (2026-04-19): when the column is missing (legacy dict
        # constructions, fixtures pre-N4, ALTER-added rows whose backfill
        # hasn't run yet), default to ``created_at`` so ``to_insert_params``
        # round-trips with ``getattr(model, col)`` and the Observer cursor
        # has a sensible value to compare against. The DB-side backfill
        # provides the same default for legacy *rows*; this provides it
        # for legacy *callers*.
        if self.last_content_change_at is None:
            object.__setattr__(self, "last_content_change_at", self.created_at)
        return self

    @classmethod
    def from_row(cls, row: Any) -> "Memory":
        """Construct from an aiosqlite.Row (or any mapping-like)."""
        return cls(**{k: row[k] for k in cls.model_fields.keys() if k in row.keys()})

    @classmethod
    def from_dict(cls, d: dict) -> "Memory":
        """Construct from a plain dict, ignoring unknown keys.

        For *parsing* an existing memory (e.g. import, cloud sync). Required
        fields must already be present — no defaults are filled in. Use
        ``Memory.new`` instead when constructing a fresh memory for save.
        """
        known = {k: d.get(k) for k in cls.model_fields.keys() if k in d}
        return cls(**known)

    @classmethod
    def new(
        cls,
        d: dict,
        *,
        now: str,
        mem_id: Optional[str] = None,
    ) -> "Memory":
        """Construct a fresh ``Memory`` for the save path.

        This is the *write-time* factory — the one used when a caller hands
        the facade a dict and we need to materialize a brand-new row. It
        differs from ``from_dict`` in three ways:

        1. Mints a fresh ULID for ``id`` (override with ``mem_id`` for
           imports / tests that need deterministic ids).
        2. Stamps ``created_at``, ``updated_at``, and ``last_confirmed`` to
           the same ``now`` value passed in (caller computes it so the three
           stay in lockstep and tests can fake the clock).
        3. Fills in the public-API defaults for missing optional fields:
           ``type='pattern'``, ``category='agent'``, ``scope='global'``,
           ``confidence=1.0``, ``reuse_count=0``. Required field is
           ``content``.

        Note: ``embedding`` is intentionally always ``None`` here. The save
        path passes the embedding bytes alongside the ``Memory`` so the
        adapter doesn't have to be wired through this layer; ``SaveService``
        applies it before insert.
        """
        return cls(
            id=mem_id if mem_id is not None else str(ULID()),
            type=d.get("type", "pattern"),
            category=d.get("category", "agent"),
            content=d["content"],
            scope=d.get("scope", "global"),
            project=d.get("project"),
            source=d.get("source"),
            confidence=d.get("confidence", 1.0),
            reuse_count=d.get("reuse_count", 0),
            domain=d.get("domain"),
            entity_graph=d.get("entity_graph"),
            trigger=d.get("trigger"),
            embedding=None,
            created_at=now,
            updated_at=now,
            # Bug N4: same wall-clock as updated_at on insert; the column
            # only diverges from updated_at after the first non-content
            # write (decay, reuse-bump, etc).
            last_content_change_at=now,
            last_confirmed=now,
        )

    def to_dict(self, *, include_embedding: bool = False) -> dict:
        """Back to a plain dict for the public API. Omits embedding by default."""
        exclude = set() if include_embedding else {"embedding"}
        return self.model_dump(exclude=exclude)

    def to_insert_params(self) -> tuple:
        """Params tuple for ``MEMORY_INSERT_SQL``, in column order.

        Returns 17 values — archived_at/invalidated_at are always NULL at
        insert time and are set later by archive/invalidate calls, so they're
        deliberately excluded from the INSERT column list (see
        ``queries.MEMORY_INSERT_COLUMNS``).

        ``last_content_change_at`` (Bug N4, 2026-04-19) is guaranteed
        non-None by the model validator (it falls back to ``created_at``
        if not supplied) so the INSERT always lands a value.
        """
        return (
            self.id,
            self.type,
            self.category,
            self.content,
            self.scope,
            self.project,
            self.source,
            self.confidence,
            self.reuse_count,
            self.domain,
            self.entity_graph,
            self.trigger,
            self.embedding,
            self.created_at,
            self.updated_at,
            self.last_content_change_at,
            self.last_confirmed,
        )


# ── Observation ───────────────────────────────────────────────────────────────

class Observation(BaseModel):
    """A row from the ``observations`` table."""

    id: str
    project: Optional[str] = None
    content: str
    token_estimate: Optional[int] = None
    created_at: str
    reflector_pass: int = 0

    @classmethod
    def from_row(cls, row: Any) -> "Observation":
        return cls(**{k: row[k] for k in cls.model_fields.keys() if k in row.keys()})

    def to_dict(self) -> dict:
        return self.model_dump()


# ── ReflectionMeta ────────────────────────────────────────────────────────────

class ReflectionMeta(BaseModel):
    """A row from the ``reflection_meta`` table."""

    project: str  # "__global__" for the global sentinel key
    last_observer_at: Optional[str] = None
    last_reflector_at: Optional[str] = None
    last_decay_at: Optional[str] = None
    last_promote_at: Optional[str] = None
    last_archive_at: Optional[str] = None

    @classmethod
    def from_row(cls, row: Any) -> "ReflectionMeta":
        return cls(**{k: row[k] for k in cls.model_fields.keys() if k in row.keys()})

    def to_dict(self) -> dict:
        return self.model_dump()


# ── SaveResult ────────────────────────────────────────────────────────────────

class SaveResult(NamedTuple):
    """Return type for save() / save_batch().

    Kept as a NamedTuple rather than a pydantic model because callers already
    destructure ``.id / .is_new / .cloud_data`` positionally and by attribute.
    """
    id: str
    is_new: bool
    cloud_data: dict
