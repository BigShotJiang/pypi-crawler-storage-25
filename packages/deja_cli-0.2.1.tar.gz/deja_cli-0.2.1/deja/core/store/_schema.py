"""SQLite DDL for MemoryStore.

Extracted from store.py so the schema is readable without scrolling past the
class. `SCHEMA_SQL` is executed via `executescript` on init_db(); `MIGRATIONS`
holds ALTER statements that are idempotent (duplicate-column errors are caught).
"""
from __future__ import annotations


SCHEMA_SQL = """
    CREATE TABLE IF NOT EXISTS memories (
        id                       TEXT PRIMARY KEY NOT NULL,
        type                     TEXT NOT NULL,
        category                 TEXT NOT NULL DEFAULT 'agent',
        content                  TEXT NOT NULL,
        scope                    TEXT NOT NULL,
        project                  TEXT,
        source                   TEXT,
        confidence               REAL NOT NULL DEFAULT 1.0,
        reuse_count              INTEGER NOT NULL DEFAULT 0,
        domain                   TEXT,
        entity_graph             TEXT,
        trigger                  TEXT,
        embedding                BLOB,
        created_at               TEXT NOT NULL,
        updated_at               TEXT NOT NULL,
        -- Bug N4 (2026-04-19): a content-only mtime so the Observer cursor
        -- doesn't get reset by every maintenance pass. Bumped on insert,
        -- content-changing upsert, invalidate, archive — never on
        -- decay/dedup-bump/reuse-bump/embedding-backfill.
        last_content_change_at   TEXT,
        last_confirmed           TEXT,
        archived_at              TEXT,
        invalidated_at           TEXT
    );

    -- Fast path for SaveService exact-duplicate lookup (wired in Phase 6).
    -- Composite index on (scope, project, type, content) so
    -- find_exact_duplicate is O(log n) instead of a full scan. Content is
    -- short (<~2KB), so an in-key index is cheaper than a content_hash column
    -- + migration + hashing on every write.
    CREATE INDEX IF NOT EXISTS idx_memories_dedup
        ON memories (scope, project, type, content);

    -- Bug H4 (2026-04-18): the partial UNIQUE index for race-safe dedup
    -- is created by ``backfill_unique_active_dedup_index`` after any
    -- existing-row duplicates are merged. Putting it in SCHEMA_SQL
    -- directly would make ``init_db`` fail on existing DBs that already
    -- have duplicates (the bug we're fixing).

    CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
    USING fts5(content, type, scope, content=memories, content_rowid=rowid);

    CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
        INSERT INTO memories_fts(rowid, content, type, scope)
        VALUES (new.rowid, new.content, new.type, new.scope);
    END;

    CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
        INSERT INTO memories_fts(memories_fts, rowid, content, type, scope)
        VALUES ('delete', old.rowid, old.content, old.type, old.scope);
    END;

    CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
        INSERT INTO memories_fts(memories_fts, rowid, content, type, scope)
        VALUES ('delete', old.rowid, old.content, old.type, old.scope);
        INSERT INTO memories_fts(rowid, content, type, scope)
        VALUES (new.rowid, new.content, new.type, new.scope);
    END;

    CREATE TABLE IF NOT EXISTS entity_nodes (
        id          TEXT PRIMARY KEY NOT NULL,
        project     TEXT,
        entity      TEXT NOT NULL,
        created_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS entity_edges (
        id                  TEXT PRIMARY KEY NOT NULL,
        project             TEXT,
        subject_entity      TEXT NOT NULL,
        predicate           TEXT NOT NULL,
        object_entity       TEXT NOT NULL,
        confidence          REAL NOT NULL DEFAULT 0.5,
        confirmations       INTEGER NOT NULL DEFAULT 1,
        is_negation         INTEGER NOT NULL DEFAULT 0,
        first_seen_session  TEXT,
        valid_from          TEXT NOT NULL,
        invalidated_at      TEXT
    );

    CREATE TABLE IF NOT EXISTS observations (
        id              TEXT PRIMARY KEY NOT NULL,
        project         TEXT,
        content         TEXT NOT NULL,
        token_estimate  INTEGER,
        created_at      TEXT NOT NULL,
        reflector_pass  INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS reflection_meta (
        project             TEXT PRIMARY KEY,
        last_observer_at    TEXT,
        last_reflector_at   TEXT,
        last_decay_at       TEXT,
        last_promote_at     TEXT,
        last_archive_at     TEXT
    );
"""


# ALTER TABLE ADD COLUMN statements for columns introduced after initial schema.
# Each is wrapped in a try/except in init_db — duplicate-column errors are
# ignored, so this list is safe to re-run on existing databases.
MIGRATIONS: list[str] = [
    "ALTER TABLE memories ADD COLUMN reuse_count INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE memories ADD COLUMN domain TEXT",
    "ALTER TABLE memories ADD COLUMN embedding BLOB",
    "ALTER TABLE memories ADD COLUMN trigger TEXT",
    # Bug N4 (2026-04-19): content-only mtime for the Observer cursor.
    # On existing DBs the column lands NULL; the backfill below seeds it
    # to ``updated_at`` so existing rows aren't re-observed on first run.
    "ALTER TABLE memories ADD COLUMN last_content_change_at TEXT",
]


# Memory table column list — must match SCHEMA_SQL above and (after the ALTER
# ADD COLUMN migrations have run) every existing on-disk DB. Used by the
# id-NOT-NULL backfill migration to copy data row-for-row into the rebuilt
# table. Kept here, next to the DDL, so adding a column requires editing one
# place — adding a column without updating this list would silently truncate
# data on any future structural migration.
_MEMORIES_COLUMNS: tuple[str, ...] = (
    "id",
    "type",
    "category",
    "content",
    "scope",
    "project",
    "source",
    "confidence",
    "reuse_count",
    "domain",
    "entity_graph",
    "trigger",
    "embedding",
    "created_at",
    "updated_at",
    "last_content_change_at",
    "last_confirmed",
    "archived_at",
    "invalidated_at",
)


async def backfill_memory_id_not_null(db) -> None:
    """One-shot structural migration: enforce ``memories.id`` is NOT NULL.

    SQLite quirk: ``id TEXT PRIMARY KEY`` does *not* implicitly enforce
    ``NOT NULL`` (unlike ``id INTEGER PRIMARY KEY``, which is a synonym for
    the rowid alias and is thus always non-null). This let a debug-detritus
    row land with ``id=NULL`` during early dev, which then crashed
    ``Memory.from_row`` (Pydantic enforces ``id: str``) on every code path
    that reads memories — including ``deja list``, ``deja search``, and
    crucially ``deja sync --push``, where it was discovered during the
    Phase 3.4 archive-propagation live smoke test.

    SQLite has no ``ALTER COLUMN`` for adding ``NOT NULL`` to an existing
    column, so this migration follows the canonical recreate-and-copy
    pattern (see https://www.sqlite.org/lang_altertable.html#otheralter):

    1. Skip if already migrated (``PRAGMA table_info`` says ``id`` is NOT
       NULL). Idempotent — safe to replay on every ``init_db`` call.
    2. Drop FTS triggers so the row-by-row copy doesn't fan out into
       ``memories_fts`` writes (and so the post-migration FTS rebuild is the
       single authority on the index).
    3. Mint a fresh ULID for any orphan ``id IS NULL`` row — preserves user
       data rather than silently dropping it (matches deja's archive-only
       philosophy). Logs each minted id with a content snippet so the user
       can find the row if they want to inspect / archive / move it.
    4. Create ``memories_new`` with ``id NOT NULL``, copy all rows, drop the
       old table, rename. Inside one transaction so a crash leaves either
       the old or the new table — never both, never neither.
    5. Recreate the dedup index and the three FTS triggers (DDL was wiped
       with the table). Run ``INSERT INTO memories_fts(memories_fts) VALUES
       ('rebuild')`` to repopulate the FTS index from scratch.

    The caller (``MemoryStore.init_db``) wraps this in a transaction; we use
    ``conn.transaction()`` here only to be defensive against future direct
    callers. Triggers and indexes are recreated from the source-of-truth
    strings below — kept in sync with ``SCHEMA_SQL`` above by code review,
    not by automation. (Diverging would mean fresh DBs and migrated DBs
    drift; the test suite catches this by asserting ``PRAGMA table_info``
    matches between fresh and migrated schemas.)
    """
    import logging

    from ulid import ULID

    logger = logging.getLogger("deja.core.store.schema")

    cursor = await db.execute("PRAGMA table_info(memories)")
    cols = await cursor.fetchall()
    await cursor.close()
    if not cols:
        # No memories table yet — SCHEMA_SQL hasn't run. Nothing to do; the
        # CREATE TABLE IF NOT EXISTS in SCHEMA_SQL will land the right shape
        # on first init.
        return
    id_col = next((c for c in cols if c["name"] == "id"), None)
    if id_col is None:
        # Schema is structurally wrong — let a downstream INSERT fail loudly
        # rather than guess.
        return
    if id_col["notnull"] == 1:
        # Already migrated. Idempotent skip.
        return

    cursor = await db.execute("SELECT id, content FROM memories WHERE id IS NULL")
    null_rows = await cursor.fetchall()
    await cursor.close()
    for row in null_rows:
        new_id = str(ULID())
        snippet = (row["content"] or "")[:80].replace("\n", " ")
        logger.warning(
            "backfill_memory_id_not_null: minted id=%s for orphan NULL-id row "
            "(content snippet: %r)",
            new_id,
            snippet,
        )
        await db.execute(
            "UPDATE memories SET id = ? WHERE id IS NULL AND content = ? "
            "AND rowid = (SELECT rowid FROM memories WHERE id IS NULL LIMIT 1)",
            (new_id, row["content"]),
        )

    cols_csv = ", ".join(_MEMORIES_COLUMNS)

    await db.execute("DROP TRIGGER IF EXISTS memories_ai")
    await db.execute("DROP TRIGGER IF EXISTS memories_ad")
    await db.execute("DROP TRIGGER IF EXISTS memories_au")

    await db.execute(
        """
        CREATE TABLE memories_new (
            id                       TEXT PRIMARY KEY NOT NULL,
            type                     TEXT NOT NULL,
            category                 TEXT NOT NULL DEFAULT 'agent',
            content                  TEXT NOT NULL,
            scope                    TEXT NOT NULL,
            project                  TEXT,
            source                   TEXT,
            confidence               REAL NOT NULL DEFAULT 1.0,
            reuse_count              INTEGER NOT NULL DEFAULT 0,
            domain                   TEXT,
            entity_graph             TEXT,
            trigger                  TEXT,
            embedding                BLOB,
            created_at               TEXT NOT NULL,
            updated_at               TEXT NOT NULL,
            last_content_change_at   TEXT,
            last_confirmed           TEXT,
            archived_at              TEXT,
            invalidated_at           TEXT
        )
        """
    )
    await db.execute(
        f"INSERT INTO memories_new ({cols_csv}) SELECT {cols_csv} FROM memories"
    )
    await db.execute("DROP TABLE memories")
    await db.execute("ALTER TABLE memories_new RENAME TO memories")

    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_memories_dedup "
        "ON memories (scope, project, type, content)"
    )
    await db.execute(
        """
        CREATE TRIGGER memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, content, type, scope)
            VALUES (new.rowid, new.content, new.type, new.scope);
        END
        """
    )
    await db.execute(
        """
        CREATE TRIGGER memories_ad AFTER DELETE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, content, type, scope)
            VALUES ('delete', old.rowid, old.content, old.type, old.scope);
        END
        """
    )
    await db.execute(
        """
        CREATE TRIGGER memories_au AFTER UPDATE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, content, type, scope)
            VALUES ('delete', old.rowid, old.content, old.type, old.scope);
            INSERT INTO memories_fts(rowid, content, type, scope)
            VALUES (new.rowid, new.content, new.type, new.scope);
        END
        """
    )
    await db.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
    logger.info("backfill_memory_id_not_null: migration complete")


async def backfill_unique_active_dedup_index(db) -> None:
    """Bug H4 (2026-04-18) + N0 (2026-04-19): create / repair the partial
    UNIQUE index that makes exact-duplicate dedup race-safe across processes.

    SaveService.find_exact_duplicate is a SELECT-then-INSERT, which two
    independent connections (CLI + watcher + MCP server) can both pass
    before either INSERT lands. Result on hot paths: silent duplicate
    rows, since fuzzy dedup isn't wired into save.

    The index shape is::

        UNIQUE(scope, COALESCE(project, ''), type, content)
        WHERE archived_at IS NULL AND invalidated_at IS NULL

    **N0 (2026-04-19): why the COALESCE.** SQLite treats every NULL as
    distinct in UNIQUE constraints — so a plain ``UNIQUE(... project ...)``
    only fires when ``project`` is non-NULL. That made the original H4
    index a no-op for global memories (``project IS NULL``: preferences,
    cross-project patterns), and the SELECT-then-INSERT race re-opened
    silently for every global write. ``COALESCE(project, '')`` collapses
    NULLs to the empty string so they collide with each other — and stays
    consistent with ``find_exact_duplicate``'s ``project IS ?`` semantics
    (both treat NULL globals as equal to other NULL globals, both treat
    project='foo' as distinct from project=NULL).

    The complication is existing DBs that *already* have duplicates
    (the H4 bug for project-scoped rows; the N0 bug for globals).
    Naively creating the unique index on those DBs would raise
    IntegrityError and crash ``init_db``. So we first merge any
    duplicate active rows into a single canonical row, preserving the
    most-confirmed history:

    1. Detect the index state (none / old non-COALESCE / new
       COALESCE-shaped). If it's already the new shape, idempotent skip.
       If it's the old shape, drop it so we can recreate with the
       COALESCE expression — and so the merge step below can re-find
       any duplicate globals that snuck through under the old index.
    2. Find every (scope, COALESCE(project,''), type, content) group
       that has more than one active row. Using COALESCE in the GROUP BY
       so global duplicates (the N0 case) actually group together
       instead of getting one bucket per row.
    3. Within each group: keep the row with the highest reuse_count;
       break ties by highest confidence; final tiebreak by lexicographically
       largest id (latest ULID).
    4. Sum reuse_count across the group onto the survivor; take the max
       confidence; merge trigger phrases (comma-joined unique tokens);
       stamp updated_at = max(updated_at) and last_confirmed = max(...).
    5. Archive the loser rows (set archived_at) — never delete, matching
       deja's archive-only philosophy. The loser rows fall out of the
       active partial-index scope and are now safe.
    6. Create the partial UNIQUE index with the COALESCE expression.

    The whole migration runs in the caller's transaction; a crash leaves
    the DB exactly as it was (no half-merged groups, no half-built index).
    """
    import logging

    logger = logging.getLogger("deja.core.store.schema")

    # Distinguish three states by inspecting the stored CREATE INDEX SQL:
    #   - missing: no row in sqlite_master
    #   - old shape (H4 only): exists, but SQL has no COALESCE
    #   - new shape (N0 fix): exists and SQL contains COALESCE
    cursor = await db.execute(
        "SELECT sql FROM sqlite_master "
        "WHERE type='index' AND name='idx_memories_dedup_unique_active'"
    )
    existing = await cursor.fetchone()
    await cursor.close()
    if existing is not None:
        existing_sql = existing["sql"] or ""
        if "COALESCE" in existing_sql.upper():
            # Already on the COALESCE-aware shape; idempotent skip.
            return
        # Old H4-shape index. Drop it so we can recreate with COALESCE
        # below. The DROP+CREATE happens inside the caller's transaction,
        # so a crash mid-migration leaves the old index in place.
        await db.execute("DROP INDEX idx_memories_dedup_unique_active")
        logger.warning(
            "backfill_unique_active_dedup_index: dropped pre-N0 index "
            "(no COALESCE on project) — recreating with NULL-safe shape"
        )

    cursor = await db.execute(
        """
        SELECT scope, COALESCE(project, '') AS project_key, type, content,
               COUNT(*) AS cnt
        FROM memories
        WHERE archived_at IS NULL AND invalidated_at IS NULL
        GROUP BY scope, COALESCE(project, ''), type, content
        HAVING cnt > 1
        """
    )
    groups = await cursor.fetchall()
    await cursor.close()

    merged_groups = 0
    archived_losers = 0
    for g in groups:
        # ``project_key`` is COALESCE(project, ''), so an empty string
        # represents the NULL-globals bucket. Translate back to the real
        # SQL semantics for the per-group SELECT below.
        scope, project_key, mem_type, content, _cnt = (
            g["scope"], g["project_key"], g["type"], g["content"], g["cnt"],
        )
        params = [scope, mem_type, content]
        if project_key == "":
            project_clause = "project IS NULL"
        else:
            project_clause = "project = ?"
            params.insert(1, project_key)
        cursor = await db.execute(
            f"""
            SELECT id, reuse_count, confidence, trigger, updated_at, last_confirmed
            FROM memories
            WHERE scope = ? AND {project_clause} AND type = ? AND content = ?
              AND archived_at IS NULL AND invalidated_at IS NULL
            ORDER BY reuse_count DESC, confidence DESC, id DESC
            """,
            params,
        )
        rows = await cursor.fetchall()
        await cursor.close()
        if len(rows) < 2:
            continue

        survivor = rows[0]
        losers = rows[1:]
        total_reuse = sum(r["reuse_count"] or 0 for r in rows)
        max_conf = max(r["confidence"] or 0.0 for r in rows)
        max_updated = max((r["updated_at"] or "") for r in rows)
        max_confirmed = max((r["last_confirmed"] or "") for r in rows) or None

        merged_trigger_tokens: list[str] = []
        seen_tokens: set[str] = set()
        for r in rows:
            t = r["trigger"]
            if not t:
                continue
            for tok in t.split(","):
                tok = tok.strip()
                if tok and tok.lower() not in seen_tokens:
                    seen_tokens.add(tok.lower())
                    merged_trigger_tokens.append(tok)
        merged_trigger = ", ".join(merged_trigger_tokens) or None

        await db.execute(
            """
            UPDATE memories
            SET reuse_count = ?, confidence = ?, trigger = ?,
                updated_at = ?, last_confirmed = ?
            WHERE id = ?
            """,
            (total_reuse, max_conf, merged_trigger, max_updated,
             max_confirmed, survivor["id"]),
        )
        for loser in losers:
            await db.execute(
                "UPDATE memories SET archived_at = ? WHERE id = ?",
                (max_updated, loser["id"]),
            )
            archived_losers += 1
        merged_groups += 1

    if merged_groups:
        logger.warning(
            "backfill_unique_active_dedup_index: merged %d duplicate group(s), "
            "archived %d loser row(s) before creating UNIQUE index",
            merged_groups, archived_losers,
        )

    await db.execute(
        "CREATE UNIQUE INDEX idx_memories_dedup_unique_active "
        "ON memories (scope, COALESCE(project, ''), type, content) "
        "WHERE archived_at IS NULL AND invalidated_at IS NULL"
    )


async def backfill_last_content_change_at(db) -> None:
    """Bug N4 (2026-04-19): seed ``last_content_change_at`` on rows that
    pre-date the column.

    The column is added by a MIGRATIONS ALTER (lands NULL on existing
    rows). The Observer cursor compares ``last_content_change_at >
    since``, and a NULL on the right side of ``>`` is always FALSE in
    SQLite — so without a backfill, every existing row would be
    permanently invisible to the Observer until something content-bumped
    it. Seed NULL rows to ``updated_at`` so the cursor behaves identically
    to the pre-N4 world for existing data, then takes effect for fresh
    writes (which set the column directly).

    Idempotent: only updates rows where the new column is still NULL.
    """
    await db.execute(
        "UPDATE memories SET last_content_change_at = updated_at "
        "WHERE last_content_change_at IS NULL"
    )
