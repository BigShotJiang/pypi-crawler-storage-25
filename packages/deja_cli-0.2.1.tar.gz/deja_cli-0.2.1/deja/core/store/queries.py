"""SQL query builders and constants for MemoryStore.

Centralizes the recurring WHERE fragments, column lists, and INSERT
templates used across the store. All values here are hardcoded string
literals and "?" placeholders — user input flows only through parameter
bindings. Never concatenate user-supplied strings into these templates.
"""
from __future__ import annotations

from typing import Any, Optional


# ── active-filter (non-archived, non-invalidated) ─────────────────────────────

ACTIVE_FILTER: str = "archived_at IS NULL AND invalidated_at IS NULL"


# ── scope filter ──────────────────────────────────────────────────────────────

def scope_filter(project: Optional[str], *, column_prefix: str = "") -> tuple[str, list[Any]]:
    """Build a scope WHERE fragment and its bind parameters.

    - project=None: returns ``("", [])`` — caller should omit any scope clause
      to include everything.
    - project="__global__": returns a clause matching only global-scope memories.
    - project=<name>: returns a clause matching global-scope OR project:<name>.

    ``column_prefix`` is prepended to the bare ``scope``/``project`` column
    names (e.g. ``"m."`` for joined queries where the table is aliased).

    The returned clause is already wrapped in parentheses so it can be joined
    with ``AND`` safely.
    """
    p = column_prefix
    if project is None:
        return "", []
    if project == "__global__":
        return f"{p}scope = 'global'", []
    return (
        f"({p}scope = 'global' OR ({p}scope = ? AND {p}project = ?))",
        [f"project:{project}", project],
    )


# ── memory INSERT ─────────────────────────────────────────────────────────────
#
# The INSERT deliberately omits archived_at and invalidated_at — those are
# always NULL at insert time and get set later by archive/invalidate calls.
# Callers pass exactly the columns listed in MEMORY_INSERT_COLUMNS, in order.

MEMORY_INSERT_COLUMNS: tuple[str, ...] = (
    "id",
    "type",
    "category",
    "content",
    "scope",
    "project",
    "source",
    "confidence",
    "reuse_count",
    "domain",
    "entity_graph",
    "trigger",
    "embedding",
    "created_at",
    "updated_at",
    # Bug N4 (2026-04-19): content-only mtime for the Observer cursor.
    # Initialised to ``created_at`` on insert so the row is immediately
    # observable in the next observer pass.
    "last_content_change_at",
    "last_confirmed",
)

_INSERT_PLACEHOLDERS = ", ".join(["?"] * len(MEMORY_INSERT_COLUMNS))
MEMORY_INSERT_SQL: str = (
    f"INSERT INTO memories ({', '.join(MEMORY_INSERT_COLUMNS)}) "
    f"VALUES ({_INSERT_PLACEHOLDERS})"
)

# ``memory_insert_params`` lived here through Phase 6 — a dict-shaped helper
# the old facade used to build INSERT bind params. Phase 7 wired the facade
# to ``Memory.to_insert_params()`` (typed, defined on the model in
# ``model.py``); the dict variant had no production callers after that and
# was deleted in Phase 8 cleanup. If you need a dict→params converter for
# something new, prefer routing through ``Memory.new(d, now=...)`` (the
# fresh-memory factory on the model) so save-time defaults stay defined
# in one place.
