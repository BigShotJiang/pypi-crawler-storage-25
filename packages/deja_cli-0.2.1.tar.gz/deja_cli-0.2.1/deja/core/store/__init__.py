"""MemoryStore facade — thin delegator over services + repos.

Phase 7 collapsed this module from 1353 lines of inline SQL into a
composition of ``Connection`` (DB lifecycle + transactions), four services
(``SaveService``, ``SearchService``, ``LoadService``, ``MaintenanceService``),
and three repos (``MemoryRepository``, ``ObservationRepository``,
``ReflectionMetaRepository``). The facade keeps three jobs: dict↔model
conversion at the public boundary (delegated to ``Memory.new`` /
``Observation``-construction sites below), lazy service+repo construction,
and lifecycle (``__aenter__``/``__aexit__``). See
``docs/store-restructure-plan.md`` for the restructure history.
"""
from __future__ import annotations

import sqlite3
from typing import Any, Optional

from ulid import ULID

from deja.config import Config
from deja.core.store._helpers import (
    DEFAULT_LOAD_SLOTS,
    SaveResult,
    _build_where,
    _bytes_to_emb,
    _cosine_similarity,
    _emb_to_bytes,
    _merge_trigger_phrases,
    _now_iso,
    _project_meta_key,
    _sanitize_fts_query,
)
from deja.core.store._schema import (
    MIGRATIONS,
    SCHEMA_SQL,
    backfill_last_content_change_at,
    backfill_memory_id_not_null,
    backfill_unique_active_dedup_index,
)
from deja.core.store.connection import Connection
from deja.core.store.model import Memory, Observation
from deja.core.store.policy import CONFIDENCE_BUMP, CONFIDENCE_MAX
from deja.core.store.repos.memories import MemoryRepository
from deja.core.store.repos.observations import ObservationRepository
from deja.core.store.repos.reflection import ReflectionMetaRepository
from deja.core.store.services.load import LoadService
from deja.core.store.services.maintenance import MaintenanceService
from deja.core.store.services.save import SaveService
from deja.core.store.services.search import SearchService

# Re-exports used by tests and benchmarks that import names directly from
# deja.core.store. Keep the list narrow — only add when an external caller
# needs the symbol.
__all__ = [
    "DEFAULT_LOAD_SLOTS",
    "MemoryStore",
    "SaveResult",
    "_bytes_to_emb",
    "_build_where",
    "_cosine_similarity",
    "_emb_to_bytes",
    "_sanitize_fts_query",
]


class MemoryStore:
    """SQLite-backed memory store. Dict-in/dict-out facade over the service layer.

    Confidence lifecycle is the one cross-service concern worth flagging
    here: ``save()`` takes the initial value from the caller, exact-match
    dedup bumps it by ``CONFIDENCE_BUMP`` (cap ``CONFIDENCE_MAX``), fuzzy
    dedup runs at reflection time via ``MaintenanceService.dedup_fuzzy``
    (Phase 7 behavior change), ``decay_unconfirmed`` knocks stale rows
    down, and ``archive_below_threshold`` archives anything beneath the
    cutoff. Archived rows are excluded from load/search but never deleted.
    """

    def __init__(self, config: Config) -> None:
        self._connection = Connection(config.store.db_path)
        self._mem_repo: Optional[MemoryRepository] = None
        self._obs_repo: Optional[ObservationRepository] = None
        self._refl_repo: Optional[ReflectionMetaRepository] = None
        self._save_svc: Optional[SaveService] = None
        self._search_svc: Optional[SearchService] = None
        self._load_svc: Optional[LoadService] = None
        self._maint_svc: Optional[MaintenanceService] = None

    # ── lifecycle ────────────────────────────────────────────────────────────

    async def __aenter__(self) -> "MemoryStore":
        await self.init_db()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def init_db(self) -> None:
        async with self._connection.transaction() as db:
            await db.executescript(SCHEMA_SQL)
            for sql in MIGRATIONS:
                try:
                    await db.execute(sql)
                except sqlite3.OperationalError as e:
                    # Bug M1 (2026-04-18): the original ``except OperationalError: pass``
                    # was intended to swallow the *idempotent replay* case
                    # (``ALTER TABLE ADD COLUMN <existing>``), but it also
                    # ate every other operational error — disk full, locked DB,
                    # schema corruption, "no such table". A migration that
                    # failed for a real reason looked identical to a successful
                    # no-op, and the next ``init_db`` ran against a half-
                    # migrated schema and silently produced wrong results.
                    # Match SQLite's stable "duplicate column name" message
                    # explicitly; everything else propagates so the operator
                    # sees the failure instead of inheriting bad state.
                    if "duplicate column name" not in str(e).lower():
                        raise
            # Structural migration: enforce id NOT NULL on existing DBs.
            # Self-skipping via PRAGMA introspection, so safe to run on every
            # init. New DBs land already-NOT-NULL via SCHEMA_SQL above and
            # short-circuit on the first PRAGMA check.
            await backfill_memory_id_not_null(db)
            # Bug H4 (2026-04-18): merge active duplicates and create the
            # partial UNIQUE dedup index. Idempotent: short-circuits if
            # the index already exists. Runs in the same outer transaction
            # so a crash leaves the DB unchanged.
            await backfill_unique_active_dedup_index(db)
            # Bug N4 (2026-04-19): seed the new last_content_change_at
            # column on rows that pre-date it (lands NULL via ALTER, and
            # NULL > X is always FALSE — so the Observer cursor would
            # treat every existing row as never-content-changed). Seeded
            # to ``updated_at`` so cursor behaviour matches the pre-N4
            # world for legacy data, then takes effect for fresh writes.
            # Idempotent: only writes rows where the column is still NULL.
            await backfill_last_content_change_at(db)

    async def close(self) -> None:
        await self._connection.close()

    def transaction(self):
        """Expose ``Connection.transaction()`` for callers that need to
        compose multiple writes atomically. Soft-reentrant — see ``Connection``.
        """
        return self._connection.transaction()

    # ── lazy-built services & repos ──────────────────────────────────────────

    def _mem(self) -> MemoryRepository:
        if self._mem_repo is None:
            self._mem_repo = MemoryRepository()
        return self._mem_repo

    def _obs(self) -> ObservationRepository:
        if self._obs_repo is None:
            self._obs_repo = ObservationRepository()
        return self._obs_repo

    def _refl(self) -> ReflectionMetaRepository:
        if self._refl_repo is None:
            self._refl_repo = ReflectionMetaRepository()
        return self._refl_repo

    def _save(self) -> SaveService:
        if self._save_svc is None:
            self._save_svc = SaveService(self._connection, self._mem())
        return self._save_svc

    def _search(self) -> SearchService:
        if self._search_svc is None:
            self._search_svc = SearchService(self._connection, self._mem())
        return self._search_svc

    def _load(self) -> LoadService:
        if self._load_svc is None:
            self._load_svc = LoadService(self._connection, self._mem())
        return self._load_svc

    def _maint(self) -> MaintenanceService:
        if self._maint_svc is None:
            # The single declared service-to-service exception
            # (services/__init__.py): promote_patterns_to_global needs the
            # SearchService for the global-existence check.
            self._maint_svc = MaintenanceService(
                self._connection,
                self._mem(),
                self._obs(),
                self._refl(),
                search_service=self._search(),
            )
        return self._maint_svc

    # ── save (delegates to SaveService) ──────────────────────────────────────

    async def save(self, memory: dict, embedding: Optional[bytes] = None) -> SaveResult:
        """Save a memory; deduplicate on exact (scope, project, type, content) match.

        Returns ``SaveResult(id, is_new, cloud_data)``. ``cloud_data`` is the
        full mutated row (no embedding blob) for downstream cloud sync.

        The dict is converted to a fresh ``Memory`` (id + timestamps minted)
        via ``Memory.new`` — see ``model.py`` for the public-API defaults.
        """
        return await self._save().save(Memory.new(memory, now=_now_iso()), embedding)

    async def save_batch(
        self, items: list[tuple[dict, Optional[bytes]]]
    ) -> list[SaveResult]:
        """Save multiple memories in a single transaction. See ``save``.

        Each item gets its own ``now`` (preserving the per-item timestamp
        behavior the pre-refactor ``_dict_to_memory`` had). If you want a
        single shared ``now`` across the batch, build the ``Memory`` objects
        yourself with ``Memory.new(d, now=shared_now)`` and call
        ``self._save().save_batch(...)`` directly.
        """
        typed = [(Memory.new(m, now=_now_iso()), emb) for m, emb in items]
        return await self._save().save_batch(typed)

    # ── search / load (delegate to services) ─────────────────────────────────

    async def search(
        self,
        query: str,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        limit: int = 20,
        embedding_adapter: Any = None,
        track_usage: bool = True,
    ) -> list[dict]:
        return await self._search().hybrid_search(
            query,
            project=project,
            mem_type=mem_type,
            limit=limit,
            embedding_adapter=embedding_adapter,
            track_usage=track_usage,
        )

    async def load(self, project: Optional[str] = None) -> list[dict]:
        return await self._load().load(project)

    async def load_budgeted(
        self,
        project: Optional[str] = None,
        slots: Optional[dict[str, int]] = None,
        context: Optional[str] = None,
        embedding_adapter: Any = None,
    ) -> dict:
        return await self._load().load_budgeted(
            project=project,
            slots=slots,
            context=context,
            embedding_adapter=embedding_adapter,
        )

    # ── maintenance (delegates to MaintenanceService) ────────────────────────

    async def decay_unconfirmed(
        self,
        days_threshold: int,
        decay_per_week: float,
        user_decay_per_week: float,
    ) -> int:
        return await self._maint().decay_unconfirmed(
            days_threshold, decay_per_week, user_decay_per_week
        )

    async def archive_below_threshold(self, threshold: float) -> int:
        return await self._maint().archive_below_threshold(threshold)

    async def dedup_fuzzy(
        self, project: Optional[str] = None, threshold: Optional[float] = None
    ) -> dict:
        """Token-overlap dedup across active memories for the scope.

        Merges near-duplicates (overlap > ``threshold``) into the older
        row and archives the newer — preserves audit trail via archive,
        never deletes. Returns ``{"merged": N, "archived": N}``.
        Idempotent. See ``MaintenanceService.dedup_fuzzy``.
        """
        # Keep policy default in the service so the facade stays thin.
        if threshold is None:
            return await self._maint().dedup_fuzzy(project=project)
        return await self._maint().dedup_fuzzy(project=project, threshold=threshold)

    async def increment_reuse_count(self, project: Optional[str] = None) -> int:
        return await self._maint().increment_reuse_count(project)

    async def promote_patterns_to_global(self, min_project_count: int) -> int:
        return await self._maint().promote_patterns_to_global(min_project_count)

    async def get_stats(self, project: Optional[str] = None) -> dict:
        return await self._maint().get_stats(project)

    # ── memory CRUD (delegate to MemoryRepository) ───────────────────────────

    async def get(self, memory_id: str) -> Optional[dict]:
        db = await self._connection.get()
        mem = await self._mem().get(db, memory_id)
        return mem.to_dict() if mem else None

    async def archive(self, memory_id: str) -> None:
        async with self._connection.transaction() as db:
            await self._mem().archive(db, memory_id, when=_now_iso())

    async def invalidate(self, memory_id: str) -> None:
        """Mark a memory as invalidated (superseded by newer information)."""
        async with self._connection.transaction() as db:
            await self._mem().invalidate(db, memory_id, when=_now_iso())

    async def confirm_memories(self, ids: list[str]) -> None:
        """Stamp last_confirmed = now on a list of memory IDs (called after load)."""
        if not ids:
            return
        async with self._connection.transaction() as db:
            await self._mem().stamp_last_confirmed(db, ids, when=_now_iso())

    async def save_embedding(self, memory_id: str, embedding: bytes) -> None:
        """Store an embedding for an existing memory (used for backfill)."""
        async with self._connection.transaction() as db:
            await self._mem().set_embedding(
                db, memory_id, embedding, updated_at=_now_iso()
            )

    async def get_memories_without_embeddings(
        self, project: Optional[str] = None
    ) -> list[dict]:
        """Active memories with no embedding yet (for backfill)."""
        db = await self._connection.get()
        return await self._mem().without_embeddings(db, project)

    async def update_memory(self, memory_id: str, fields: dict) -> bool:
        """Update allowed metadata fields on an existing active memory.

        Only ``trigger`` and ``type`` can be updated this way — content
        changes go through ``save()`` (which deduplicates). Returns True iff
        a row was updated. Trigger merge: incoming phrases are unioned with
        existing via ``_merge_trigger_phrases`` — the same helper SaveService
        and MaintenanceService use, so the merge rule has one definition.
        Archived/invalidated rows are skipped (return False) to match the
        legacy facade contract.
        """
        allowed = {"trigger", "type"}
        updates = {k: v for k, v in fields.items() if k in allowed and v is not None}
        if not updates:
            return False

        async with self._connection.transaction() as db:
            existing = await self._mem().get(db, memory_id)
            if existing is None:
                return False
            if existing.archived_at is not None or existing.invalidated_at is not None:
                return False

            if "trigger" in updates:
                updates["trigger"] = _merge_trigger_phrases(
                    existing.trigger, updates["trigger"]
                )

            return await self._mem().update_fields(
                db, memory_id, updated_at=_now_iso(), **updates
            )

    # ── list / export reads (delegate to MemoryRepository) ───────────────────

    async def list_all(self) -> list[dict]:
        """All active memories across every scope, ordered by scope then confidence."""
        db = await self._connection.get()
        memories = await self._mem().fetch_all_active(db)
        return [m.to_dict() for m in memories]

    async def list_for_sync(self) -> list[dict]:
        """Active + archived memories across every scope, for cloud sync push.

        Use this (not ``list_all``) for ``deja sync push`` enumeration —
        ``list_all`` filters out archived rows, so a local archive performed
        via ``deja archive`` or ``deja reflect`` would never propagate to the
        cloud. Excludes ``invalidated_at`` rows: invalidation is local fuzzy-
        dedup state, never crosses the sync boundary. See
        ``MemoryRepository.fetch_for_sync`` for the SQL.
        """
        db = await self._connection.get()
        memories = await self._mem().fetch_for_sync(db)
        return [m.to_dict() for m in memories]

    async def list_filtered(
        self,
        project: Optional[str] = None,
        mem_type: Optional[str] = None,
        status: str = "active",
        limit: int = 200,
        offset: int = 0,
    ) -> tuple[list[dict], int]:
        """Web-viewer list with project/type/status filtering.

        ``project``: ``None`` = all, ``"__global__"`` = global scope only,
        else by name. ``status``: ``active`` | ``archived`` | ``invalidated`` | ``all``.
        """
        db = await self._connection.get()
        memories, total = await self._mem().fetch(
            db, project=project, mem_type=mem_type, status=status,
            limit=limit, offset=offset,
        )
        return [m.to_dict() for m in memories], total

    async def list_projects(self) -> list[dict]:
        """Distinct project names with active memory count, ordered by count desc."""
        db = await self._connection.get()
        return await self._mem().distinct_projects(db)

    async def list_for_export(
        self,
        project: Optional[str] = None,
        types: Optional[list[str]] = None,
        include_archived: bool = False,
    ) -> list[dict]:
        """List memories for export with filtering. Embedding bytes excluded."""
        db = await self._connection.get()
        memories = await self._mem().fetch_for_export(
            db, project=project, types=types, include_archived=include_archived
        )
        return [m.to_dict() for m in memories]

    async def list_for_reflection(
        self,
        project: Optional[str] = None,
        since: Optional[str] = None,
    ) -> list[dict]:
        """Active memories for the Observer.

        ``project=None`` returns all scopes; ``project='X'`` only
        ``scope='project:X'``. ``since`` filters by
        ``COALESCE(last_content_change_at, updated_at) > since`` (Bug N4,
        2026-04-19) — the content-only mtime, NOT ``updated_at``, so
        decay/reuse/dedup-bump maintenance writes don't reset the
        cursor.
        """
        db = await self._connection.get()
        memories = await self._mem().fetch_for_reflection(db, project=project, since=since)
        return [m.to_dict() for m in memories]

    # ── upsert (import path) ─────────────────────────────────────────────────

    async def upsert(self, memory: dict, merge_strategy: str = "skip") -> str:
        """Insert or update a memory during import based on merge strategy.

        Strategies: ``skip`` | ``overwrite`` | ``update-confidence``. Stays
        inline rather than going through SaveService because import
        intentionally bypasses dedup (the import payload is the source of
        truth, not the local FTS index) and operates on a caller-supplied
        ``id`` rather than minting a new one.
        """
        _KNOWN_COLUMNS = {
            "id", "type", "category", "content", "scope", "project", "source",
            "confidence", "reuse_count", "domain", "entity_graph", "trigger",
            "embedding", "created_at", "updated_at", "last_content_change_at",
            "last_confirmed", "archived_at", "invalidated_at",
        }
        memory = {k: v for k, v in memory.items() if k in _KNOWN_COLUMNS}

        now = _now_iso()
        memory.setdefault("created_at", now)
        memory.setdefault("updated_at", now)
        memory.setdefault("type", "semantic")
        memory.setdefault("category", "agent")
        memory.setdefault("content", "")
        memory.setdefault("scope", "global")
        memory.setdefault("confidence", 1.0)
        memory.setdefault("reuse_count", 0)
        # Bug N4 (2026-04-19): ensure the content-only mtime is always set
        # on insert. Default to ``created_at`` so the row enters the
        # Observer's queue at exactly the same moment it became visible.
        memory.setdefault("last_content_change_at", memory["created_at"])

        mem_id = memory["id"]

        # Bug M2 (2026-04-18): the existence check used to live *outside*
        # the transaction. Two writers calling ``upsert`` for the same id
        # could both see "no existing row", both take the INSERT branch,
        # and the second crashed with ``IntegrityError: UNIQUE constraint
        # failed: memories.id``. Moving the read inside the transaction
        # serializes it under the RESERVED lock that ``BEGIN IMMEDIATE``
        # (per the H4 companion fix in ``connection.py``) acquires upfront,
        # so the second writer waits, re-reads, and correctly takes the
        # update branch instead of racing into the insert.
        async with self._connection.transaction() as db:
            existing_row = await self._mem().get(db, mem_id)
            existing = existing_row.to_dict() if existing_row else None

            if not existing:
                fields = list(memory.keys())
                placeholders = ",".join("?" for _ in fields)
                await db.execute(
                    f"INSERT INTO memories ({','.join(fields)}) VALUES ({placeholders})",
                    [memory[f] for f in fields],
                )
                return "inserted"
            if merge_strategy == "skip":
                return "skipped"
            if merge_strategy == "overwrite":
                # Bug N4 (2026-04-19): overwrite can change content, so
                # bump last_content_change_at unless the caller already
                # provided one (cloud-side mtime is canonical when it
                # comes through sync_pull). Comparing content is the
                # most defensible signal — only bump on a real diff.
                if (
                    "last_content_change_at" not in memory
                    and memory.get("content") != existing.get("content")
                ):
                    memory["last_content_change_at"] = now
                fields = [f for f in memory.keys() if f != "id"]
                set_clause = ",".join(f"{f} = ?" for f in fields)
                await db.execute(
                    f"UPDATE memories SET {set_clause} WHERE id = ?",
                    [memory[f] for f in fields] + [mem_id],
                )
                return "overwritten"
            if merge_strategy == "update-confidence":
                if memory["content"] != existing["content"]:
                    return "skipped"
                new_confidence = min(
                    CONFIDENCE_MAX, existing["confidence"] + CONFIDENCE_BUMP
                )
                await db.execute(
                    "UPDATE memories "
                    "SET confidence = ?, last_confirmed = ?, updated_at = ? "
                    "WHERE id = ?",
                    (new_confidence, now, now, mem_id),
                )
                return "updated"
            return "skipped"

    # ── observations + reflection meta (delegate to repos) ───────────────────

    async def save_observation(self, project: Optional[str], content: str) -> str:
        """Save one observation. Reflector_pass=0 marks it as live (not condensed)."""
        obs_id = str(ULID())
        observation = Observation(
            id=obs_id,
            project=project,
            content=content,
            token_estimate=len(content.split()) * 2,
            created_at=_now_iso(),
            reflector_pass=0,
        )
        async with self._connection.transaction() as db:
            await self._obs().insert(db, observation)
        return obs_id

    async def list_observations(self, project: Optional[str] = None) -> list[dict]:
        """List all observations for a project (or all if project is None)."""
        db = await self._connection.get()
        return [o.to_dict() for o in await self._obs().list(db, project)]

    async def list_observation_projects(self) -> list[Optional[str]]:
        """Distinct project values that have ≥1 observation, including ``None``
        for the global bucket. Used by ``ReflectionEngine.run_reflector(None)``
        to fan out into per-project passes (Bug N2, 2026-04-19).
        """
        db = await self._connection.get()
        return await self._obs().list_distinct_projects(db)

    async def list_memory_projects(self) -> list[Optional[str]]:
        """Distinct project values with at least one active memory.

        Used by ``ReflectionEngine.run_dedup_fuzzy(None)`` (Bug R4,
        2026-04-22) to fan dedup out across every scope instead of
        touching only globals (the historical ``dedup_fuzzy(None)``
        semantics).
        """
        db = await self._connection.get()
        return await self._mem().list_active_projects(db)

    async def replace_observations(
        self, project: Optional[str], new_texts: list[str],
        *,
        consumed_ids: Optional[list[str]] = None,
    ) -> None:
        """Replace the observation log for a project with condensed versions.

        ``reflector_pass=1`` flags the new rows as condensed (vs raw 0 from
        the live observer). One transaction so a partial replace can't leave
        the log half-deleted.

        ``consumed_ids`` (Bug N3, 2026-04-19): the IDs the caller actually
        read and fed to the LLM. When supplied, only those rows are
        deleted — anything inserted into the same project while the LLM
        was thinking survives to the next reflector pass. When ``None``
        (legacy callers), falls back to the old "wipe the whole project
        bucket" behaviour. New callers should always pass the IDs.

        Empty ``new_texts`` is a no-op (defense in depth for Bug C1, 2026-04-18):
        without this guard, a flaky reflector LLM that returned blank text would
        atomically wipe the project's entire observation history — unrecoverable
        local data loss. Refusing the empty replace at the store boundary
        protects every caller, including future ones.
        """
        if not new_texts:
            return
        now = _now_iso()
        async with self._connection.transaction() as db:
            if consumed_ids is None:
                await self._obs().delete_for(db, project)
            else:
                await self._obs().delete_by_ids(db, consumed_ids)
            for text in new_texts:
                await self._obs().insert(
                    db,
                    Observation(
                        id=str(ULID()),
                        project=project,
                        content=text,
                        token_estimate=len(text.split()) * 2,
                        created_at=now,
                        reflector_pass=1,
                    ),
                )

    async def get_reflection_meta(self, project: Optional[str] = None) -> Optional[dict]:
        """Get reflection metadata for a project."""
        db = await self._connection.get()
        meta = await self._refl().get(db, project)
        if meta is None:
            return None
        # Map the internal ``__global__`` sentinel back to None to keep the
        # external dict shape stable for callers (project name or NULL).
        d = meta.to_dict()
        if d.get("project") == _project_meta_key(None):
            d["project"] = None
        return d

    async def set_reflection_meta(self, project: Optional[str] = None, **fields) -> None:
        """Insert or update reflection metadata fields for a project."""
        async with self._connection.transaction() as db:
            await self._refl().upsert(db, project, **fields)
