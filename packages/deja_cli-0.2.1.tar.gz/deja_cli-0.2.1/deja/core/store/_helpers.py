"""Pure helpers for MemoryStore.

Extracted from store.py to keep that module focused on the class. Everything
here is dependency-free (no aiosqlite, no Config) and safe to unit-test on its
own. store.py re-exports the names that external callers (tests) rely on.
"""
from __future__ import annotations

import math
import re
import struct
from datetime import datetime, timezone
from typing import Optional

from .model import SaveResult  # re-export — callers import from here

__all__ = [
    "SaveResult",
    "DEFAULT_LOAD_SLOTS",
    "_activation_score",
    "_apply_confusability_penalty",
    "_build_where",
    "_bytes_to_emb",
    "_cosine_similarity",
    "_emb_to_bytes",
    "_merge_trigger_phrases",
    "_now_iso",
    "_parse_dt",
    "_project_meta_key",
    "_sanitize_fts_query",
    "_strip_embedding",
    "_token_overlap",
]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_dt(dt_str: str) -> datetime:
    """Parse an ISO datetime string, defaulting to UTC epoch on failure.

    Catches the two realistic failure modes from ``datetime.fromisoformat``:
    ``ValueError`` (malformed string), ``TypeError`` (non-string input).
    """
    try:
        dt = datetime.fromisoformat(dt_str)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (ValueError, TypeError):
        return datetime(1970, 1, 1, tzinfo=timezone.utc)


def _token_overlap(a: str, b: str) -> float:
    """Simple token overlap ratio between two strings."""
    tokens_a = set(a.lower().split())
    tokens_b = set(b.lower().split())
    if not tokens_a or not tokens_b:
        return 0.0
    intersection = tokens_a & tokens_b
    union = tokens_a | tokens_b
    return len(intersection) / len(union)


def _merge_trigger_phrases(
    existing: Optional[str], incoming: Optional[str]
) -> Optional[str]:
    """Union two comma-separated trigger phrase strings.

    Returns the deduped, sorted, comma-joined union — or ``None`` when both
    inputs are empty/None. Whitespace around each phrase is stripped.

    Used by SaveService on dedup hit, MaintenanceService.dedup_fuzzy on merge,
    and the facade's ``update_memory`` (Phase 7 will collapse these onto this
    one helper). Three previous inline copies of this logic shared the same
    bug: they treated empty strings and None inconsistently. This is the
    single source of truth.
    """
    e = existing or ""
    i = incoming or ""
    if not e and not i:
        return None
    e_phrases = {p.strip() for p in e.split(",") if p.strip()}
    i_phrases = {p.strip() for p in i.split(",") if p.strip()}
    merged = sorted(e_phrases | i_phrases)
    return ", ".join(merged) if merged else None


# ── embedding helpers ──────────────────────────────────────────────────────────

def _emb_to_bytes(embedding: list[float]) -> bytes:
    return struct.pack(f"{len(embedding)}f", *embedding)


def _bytes_to_emb(data: bytes) -> list[float]:
    n = len(data) // 4
    return list(struct.unpack(f"{n}f", data))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = math.sqrt(sum(x * x for x in a))
    mag_b = math.sqrt(sum(x * x for x in b))
    if mag_a == 0.0 or mag_b == 0.0:
        return 0.0
    return dot / (mag_a * mag_b)


# ── query construction helpers ────────────────────────────────────────────────
#
# SAFETY INVARIANT: WHERE clauses are assembled from hardcoded string literals
# and "?" placeholders only — never from user input. All user-provided values
# flow through parameterized "?" bindings. The f-string interpolation of {where}
# into SQL is safe because `where` is built exclusively from constants defined
# in this module. Do not construct WHERE fragments from external input.


# FTS5 operators that could alter query semantics if passed through unescaped.
_FTS5_OPERATOR_RE = re.compile(r"\b(AND|OR|NOT|NEAR)\b", re.IGNORECASE)
_FTS5_SPECIAL_CHARS = re.compile(r"[*+\-^:]")


def _sanitize_fts_query(query: str) -> str:
    """Escape FTS5 special syntax so the query is treated as a literal phrase.

    Strips operator keywords (AND, OR, NOT, NEAR) and special characters
    (*, +, -, ^, :), then wraps the result in double quotes for phrase matching.
    Internal double quotes are escaped as "".
    """
    cleaned = _FTS5_OPERATOR_RE.sub("", query)
    cleaned = _FTS5_SPECIAL_CHARS.sub("", cleaned)
    cleaned = " ".join(cleaned.split())
    escaped = cleaned.replace('"', '""')
    return f'"{escaped}"'


def _build_where(conditions: list[str]) -> str:
    """Join hardcoded SQL condition fragments into a WHERE clause.

    Every element of `conditions` must be a hardcoded string literal with
    "?" placeholders for user-provided values. This function exists to make
    the safety invariant explicit and auditable.
    """
    if not conditions:
        return ""
    return "WHERE " + " AND ".join(conditions)


# ── activation ranking — back-compat aliases ──────────────────────────────────
#
# Phase 8 moved the bodies of these two functions to
# ``deja.core.store.services.ranking`` (under the cleaner names
# ``activation_score`` / ``confusability_penalty``). Kept here as one-line
# aliases because ``test_store_module_split`` and external callers import
# the underscore names from this module. Late-imported at the bottom of
# the file to avoid the ``services.ranking → _helpers`` import cycle.


def _strip_embedding(mem: dict) -> dict:
    """Remove the binary embedding field before returning to callers."""
    m = dict(mem)
    m.pop("embedding", None)
    return m


# ── load budgeting ─────────────────────────────────────────────────────────────

DEFAULT_LOAD_SLOTS: dict[str, int] = {
    "preference": 5,
    "gotcha": 5,
    "decision": 5,
    "pattern": 5,
    "procedure": 3,
    "progress": 3,  # only if updated within the last 7 days
}


# ── project meta key ──────────────────────────────────────────────────────────

_GLOBAL_PROJECT_KEY = "__global__"


def _project_meta_key(project: Optional[str]) -> str:
    return project if project is not None else _GLOBAL_PROJECT_KEY


# Back-compat alias bindings — late import so ``services.ranking`` (which
# imports ``_bytes_to_emb`` and ``_cosine_similarity`` from this module)
# can finish loading before we ask it for ``activation_score`` /
# ``confusability_penalty``. New code should import the cleanly-named
# functions directly from ``services.ranking``.
from .services.ranking import (  # noqa: E402  — intentional late import
    activation_score as _activation_score,
    confusability_penalty as _apply_confusability_penalty,
)
