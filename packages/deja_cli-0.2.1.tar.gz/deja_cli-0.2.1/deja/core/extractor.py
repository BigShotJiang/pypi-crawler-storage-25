from __future__ import annotations

import logging
from typing import Optional

from deja.core.store.policy import MAX_CONTENT_LENGTH
from deja.llm.base import LLMAdapter

logger = logging.getLogger(__name__)

EXTRACTION_SYSTEM = (
    "You are a memory extraction system for a software engineer.\n"
    "Given a coding session transcript or summary, extract ONLY memories\n"
    "that would be genuinely useful in a future session.\n"
    "\n"
    f"Each memory's ``content`` field MUST be ≤{MAX_CONTENT_LENGTH} characters.\n"
    "A memory is one piece of info — not an essay. If something is longer\n"
    "than that, it's almost certainly two memories that should be split.\n"
    "\n"
) + """Be ruthless — most session content is NOT worth remembering.
Only extract things that are:
- Non-obvious (not derivable from reading the codebase)
- Reusable (would apply in future sessions)
- Important (would cause problems if forgotten)

Memory types:
- preference: how the user likes to code (style, tools, patterns)
- pattern: reusable solution / architectural approach that applies across contexts ("knowing what works")
- decision: non-obvious architectural choice with reasoning
- gotcha: bug, trap, or non-obvious issue to avoid
- progress: current state of in-progress work
- procedure: reusable ordered steps for a recurring class of work ("knowing how to execute"). Keep thin: numbered steps + tool hints + exit criteria only. Do NOT inline gotchas or decisions — save those as separate memory types.

Category:
- user: personal preferences and habits (applies across all projects)
- agent: operational knowledge discovered while doing work

Domain (optional, coarse routing tag — use for procedure type mainly):
- debug | build | test | deploy | research

Output ONLY valid JSON:
{
  "memories": [
    {
      "type": "preference|pattern|decision|gotcha|progress|procedure",
      "category": "user|agent",
      "content": "concise, self-contained fact. 1-2 sentences max for most types. For procedure: one-line description followed by numbered steps, tool hints, and exit criteria.",
      "scope": "global|project",
      "project": "project_name or null if global",
      "confidence": 0.0-1.0,
      "domain": "debug|build|test|deploy|research|null"
    }
  ]
}

If nothing is worth remembering, return: {"memories": []}"""

EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "memories": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": ["preference", "pattern", "decision", "gotcha", "progress", "procedure"],
                    },
                    "category": {"type": "string", "enum": ["user", "agent"]},
                    "content": {"type": "string"},
                    "scope": {"type": "string", "enum": ["global", "project"]},
                    "project": {"type": ["string", "null"]},
                    "confidence": {"type": "number"},
                    "domain": {"type": ["string", "null"]},
                },
                "required": ["type", "category", "content", "scope", "confidence"],
            },
        }
    },
    "required": ["memories"],
}


async def extract_memories(
    transcript: str,
    project: str,
    source: str,
    adapter: LLMAdapter,
) -> list[dict]:
    """Extract memories from a session transcript or summary.

    Returns list of memory dicts ready to pass to store.save().
    """
    if not transcript.strip():
        return []

    user_prompt = f"Session transcript/summary to extract memories from:\n\n{transcript}"

    # Bug R2 (2026-04-22): let adapter / transport / JSON-parse errors
    # propagate. The previous ``except Exception: return []`` made every
    # LLM outage indistinguishable from "the model had nothing to
    # extract." The watcher's ``_process`` then treated the empty list
    # as a successful extraction and stamped ``_processed[path]`` —
    # silently burning the transcript. Same bug class as H5 on the read
    # side. Callers decide:
    #
    # - Watcher (``deja/ingest/watchers/base.py``) wraps this call in
    #   its own try/except and routes to ``_schedule_extraction_retry``
    #   (bounded N8/P2 backoff: 30s / 2min / 10min, then give up loudly).
    # - CLI callers (``deja save-session``, ``deja ingest-skills``,
    #   ``deja backfill``) catch and either exit cleanly or log + skip
    #   the one file and continue.
    result = await adapter.complete_structured(
        system=EXTRACTION_SYSTEM,
        user=user_prompt,
        schema=EXTRACTION_SCHEMA,
    )

    memories = result.get("memories", [])
    if not isinstance(memories, list):
        return []

    output = []
    for mem in memories:
        if not isinstance(mem, dict):
            continue
        if not mem.get("content") or not mem.get("type"):
            continue

        # Normalize scope: if scope is "project" but no project given, use the provided project
        scope = mem.get("scope", "global")
        mem_project = mem.get("project") or (project if scope == "project" else None)
        if scope == "project" and mem_project:
            scope_value = f"project:{mem_project}"
        else:
            scope_value = "global"
            mem_project = None

        # Bug M4 (2026-04-18): defense-in-depth content cap. The system
        # prompt asks the LLM to keep each memory ≤MAX_CONTENT_LENGTH, but
        # we can't trust that — a degenerate model run can return a single
        # 4000-char "memory" anyway. Without truncation here, that item
        # would propagate to ``SaveService.save`` which raises
        # ``MemoryTooLongError``, and (under H5) the watcher would retry
        # the whole transcript indefinitely while losing the same section
        # every time. Truncating mirrors the watcher's no-LLM fallback
        # (``deja/ingest/watchers/base.py``) so ingestion paths are
        # symmetric: agent/user paths reject, system/extracted paths
        # truncate. WARNING is loud enough to surface a misbehaving model.
        content = mem["content"]
        if len(content) > MAX_CONTENT_LENGTH:
            logger.warning(
                "Extractor truncated an oversized memory: %d chars exceeds the "
                "%d-char cap; check the LLM's prompt compliance.",
                len(content), MAX_CONTENT_LENGTH,
            )
            content = content[:MAX_CONTENT_LENGTH]

        output.append(
            {
                "type": mem["type"],
                "category": mem.get("category", "agent"),
                "content": content,
                "scope": scope_value,
                "project": mem_project,
                "source": source,
                "confidence": float(mem.get("confidence", 0.8)),
                "domain": mem.get("domain"),
            }
        )

    return output
