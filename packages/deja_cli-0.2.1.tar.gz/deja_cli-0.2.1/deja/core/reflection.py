from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from typing import Optional

from deja.config import ReflectionConfig
from deja.core.store import MemoryStore

logger = logging.getLogger(__name__)
from deja.llm.base import LLMAdapter

OBSERVER_SYSTEM = """You are a memory compressor for a software engineer's coding knowledge base.
Given these recent memories, extract the key observations worth preserving long-term.

Discard:
- Obvious facts derivable from the codebase
- Task-specific one-offs that won't recur
- Superseded progress updates (if newer progress exists)

Keep:
- Patterns and gotchas
- Architectural decisions and their reasoning
- User preferences and working style
- Ongoing work that is not yet complete
- Procedures (reusable step sequences) — keep steps thin

For procedure memories:
- Preserve only: numbered steps, tool hints, exit criteria
- Strip any inline gotchas or decisions — those belong in separate memories
- Merge near-duplicate procedures rather than keeping both

Output concise observations in plain text, one per line.
Each observation should be self-contained and useful without context.

After the observations, if any memories would benefit from metadata improvements, append a
MEMORY_UPDATES block with a JSON array of suggested changes. Only update what you are
confident about — omit the block entirely if no improvements are needed.

Rules for memory_updates:
- Add a trigger only if the memory is a gotcha clearly tied to a specific command or action
  boundary (e.g. kubectl apply, alembic upgrade, terraform apply, git push --force).
  Trigger phrases must be commands the agent would literally type, comma-separated.
- Change type only if clearly wrong (e.g. saved as pattern but describes a specific
  command failure → gotcha). Be conservative.
- Never update preferences, decisions, or progress entries.
- If the memory already has a trigger shown in [trigger:...], skip it.

Format (append at the end, after all observations):

MEMORY_UPDATES:
[
  {"id": "01JKB...", "trigger": "kubectl apply, helm upgrade"},
  {"id": "01JKC...", "type": "gotcha", "trigger": "alembic upgrade"}
]"""

REFLECTOR_SYSTEM = """Given this observation log, identify which observations are:
- Superseded by a newer observation about the same topic
- Redundant (same fact stated multiple ways)
- Resolved (a gotcha that was fixed, progress that completed)

Remove or merge superseded/redundant/resolved observations.
For merged observations, keep the most recent and accurate version.

Output the condensed observation log only. Plain text, one observation per line.
Do not add commentary. Do not add headers. Just the observations."""


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_observer_response(text: str) -> tuple[str, list[dict]]:
    """Split Observer LLM response into (observations_text, memory_updates).

    The LLM appends a MEMORY_UPDATES: JSON block after the plain-text observations.
    If the block is absent or malformed, returns the full text as observations and
    an empty updates list — observations always take priority.
    """
    marker = "MEMORY_UPDATES:"
    idx = text.find(marker)
    if idx == -1:
        return text, []

    obs_part = text[:idx].strip()
    json_part = text[idx + len(marker):].strip()

    # Extract JSON array — tolerate surrounding whitespace or markdown fences
    json_match = re.search(r"\[.*\]", json_part, re.DOTALL)
    if not json_match:
        return obs_part, []

    try:
        updates = json.loads(json_match.group())
        if not isinstance(updates, list):
            return obs_part, []
        return obs_part, [u for u in updates if isinstance(u, dict) and "id" in u]
    except json.JSONDecodeError:
        return obs_part, []


def _format_memories_for_prompt(memories: list[dict]) -> str:
    lines = []
    for m in memories:
        label = m.get("project") or "global"
        trigger_str = f" [trigger:{m['trigger']}]" if m.get("trigger") else ""
        lines.append(
            f"[{m['type']}] [conf:{m['confidence']:.2f}] [{label}] [id:{m['id']}]{trigger_str}\n"
            f"{m['content']}"
        )
    return "\n\n".join(lines)


def _format_observations_for_prompt(observations: list[dict]) -> str:
    return "\n".join(o["content"] for o in observations)


class ReflectionEngine:
    """Compresses, deduplicates, decays, and promotes memories over time.

    Two reflection modes
    --------------------
    LLM mode  — uses the configured ``reflection`` LLM (Ollama / Anthropic).
                Invoked manually via ``deja reflect`` or on a cron schedule.

    Agent mode — no extra LLM call. The active coding agent (Claude Code,
                 Codex, Gemini CLI) reads the output of ``agent_mode_prompt()``
                 and executes ``deja archive / invalidate / save`` commands
                 directly. Zero additional API cost — the agent is already
                 being billed for the session.
    """

    def __init__(
        self,
        store: MemoryStore,
        config: ReflectionConfig,
        adapter: Optional[LLMAdapter] = None,
    ) -> None:
        self.store = store
        self.config = config
        self.adapter = adapter

    # ── LLM-driven compression ─────────────────────────────────────────────

    async def run_observer(self, project: Optional[str] = None) -> int:
        """Compress memories into observations via LLM. Returns observations created."""
        if not self.adapter:
            raise RuntimeError(
                "No LLM adapter configured for reflection. "
                "Set reflection.provider in ~/.deja/config.yaml or use --agent-mode."
            )

        meta = await self.store.get_reflection_meta(project)
        last_run = meta.get("last_observer_at") if meta else None

        memories = await self.store.list_for_reflection(project, since=last_run)
        if not memories:
            return 0

        token_estimate = sum(len(m["content"].split()) * 2 for m in memories)
        if token_estimate < 100:
            return 0

        user_prompt = (
            "Recent memories to compress into observations:\n\n"
            + _format_memories_for_prompt(memories)
        )

        try:
            response = await self.adapter.complete(system=OBSERVER_SYSTEM, user=user_prompt)
            observations_text = response.content.strip()
        except Exception as e:
            logger.error("Observer LLM error: %s", e)
            return 0

        # Split on MEMORY_UPDATES: block — observations come first, JSON updates after
        obs_part, memory_updates = _parse_observer_response(observations_text)

        new_obs = [line.strip() for line in obs_part.splitlines() if line.strip()]
        for obs_text in new_obs:
            await self.store.save_observation(project, obs_text)

        # Apply memory metadata updates suggested by the Observer
        applied = 0
        for update in memory_updates:
            mem_id = update.get("id")
            if not mem_id:
                continue
            fields = {k: v for k, v in update.items() if k in ("trigger", "type")}
            if fields:
                ok = await self.store.update_memory(mem_id, fields)
                if ok:
                    applied += 1
        if applied:
            logger.info("Observer applied %d memory metadata update(s).", applied)

        # Bug M3 (2026-04-18): only stamp ``last_observer_at`` when the LLM
        # actually did useful work — observations created OR memory metadata
        # applied. The original code advanced the cursor unconditionally, so
        # if the LLM returned blank text (rate-limited / degenerate / prompt
        # edge case), the cursor still moved past these memories and the
        # next observer pass would never re-attempt them. Result: real
        # observation work pushed further into the future for no reason.
        if new_obs or applied:
            await self.store.set_reflection_meta(project, last_observer_at=_now_iso())
        return len(new_obs)

    async def run_reflector(self, project: Optional[str] = None) -> int:
        """Condense the observation log via LLM. Returns reduction in observation count.

        Bug N2 (2026-04-19): when ``project is None`` (the default for
        ``deja reflect`` with no flag), this used to read **every**
        observation across **every** project as one mixed input
        (``ObservationRepository.list(None)`` has no project filter), call
        the LLM to condense that mixed input, then ``replace_observations(
        None, ...)`` whose ``delete_for(None)`` only deletes
        ``project IS NULL`` rows. Per-project observations survived
        alongside a fresh NULL-project condensed copy derived from them —
        each pass duplicated the log and ``increment_reuse_count(None)``
        bumped reuse on every active memory globally. The fix is to fan
        out: when called with ``project=None``, run one independent
        condense pass per distinct project that has observations
        (including, separately, the genuine ``project IS NULL`` global
        bucket if any global observations exist). Per-project semantics
        match how ``run_observer`` already operates.
        """
        if not self.adapter:
            raise RuntimeError(
                "No LLM adapter configured for reflection. "
                "Set reflection.provider in ~/.deja/config.yaml or use --agent-mode."
            )

        if project is None:
            # Fan out per project. ``list_observation_projects`` returns the
            # distinct set including ``None`` for global observations; we
            # want each scope condensed in isolation, never mixed.
            projects = await self.store.list_observation_projects()
            if not projects:
                return 0
            total_reduction = 0
            for p in projects:
                total_reduction += await self.run_reflector(p)
            return total_reduction

        observations = await self.store.list_observations(project)
        if len(observations) < 3:
            return 0

        # Bug N3 (2026-04-19): remember the exact IDs we're about to feed
        # to the LLM. The reflector is split across two transactions
        # (read → LLM round-trip → replace) and the LLM call can take
        # seconds-to-minutes. If the Observer concurrently writes a fresh
        # observation in the same project during that window, the old
        # ``replace_observations`` would wipe it (delete_for(project)
        # took out everything, including rows the reflector never saw and
        # therefore couldn't condense). Passing the consumed IDs through
        # to ``replace_observations`` makes the delete strictly scoped to
        # what we read, so any concurrent observer write survives to the
        # next reflector pass.
        consumed_ids = [o["id"] for o in observations]

        user_prompt = (
            "Observation log to condense:\n\n"
            + _format_observations_for_prompt(observations)
        )

        try:
            response = await self.adapter.complete(system=REFLECTOR_SYSTEM, user=user_prompt)
            condensed_text = response.content.strip()
        except Exception as e:
            logger.error("Reflector LLM error: %s", e)
            return 0

        condensed = [line.strip() for line in condensed_text.splitlines() if line.strip()]
        if not condensed:
            # Bug C1 (2026-04-18): a blank/whitespace LLM response used to
            # collapse to ``condensed=[]`` and replace_observations would
            # atomically wipe the entire observation log. The store-side
            # guard now refuses the empty replace; we mirror it here so we
            # also (a) don't bump reuse_count on a no-op pass and (b) don't
            # advance ``last_reflector_at`` and starve the next real run.
            logger.warning(
                "Reflector returned no usable text for project=%s; "
                "leaving %d existing observations untouched",
                project, len(observations),
            )
            return 0

        original_count = len(observations)
        await self.store.replace_observations(
            project, condensed, consumed_ids=consumed_ids
        )

        # Surviving compression is a confirmation signal — increment reuse_count
        # for all active memories. We can't map observations back to specific
        # memories, so we treat all active memories as "surviving" this pass.
        await self.store.increment_reuse_count(project)

        await self.store.set_reflection_meta(project, last_reflector_at=_now_iso())
        return original_count - len(condensed)

    # ── No-LLM maintenance passes ──────────────────────────────────────────

    async def run_decay(self) -> int:
        """Reduce confidence on memories not confirmed recently.

        Two rates are applied:
        - category='agent': config.confidence_decay_per_week (default 0.05/week)
          Operational knowledge (gotchas, decisions, progress) goes stale.
        - category='user': config.user_confidence_decay_per_week (default 0.01/week)
          Preferences and habits are stable; they decay ~5x slower.
        """
        count = await self.store.decay_unconfirmed(
            days_threshold=14,
            decay_per_week=self.config.confidence_decay_per_week,
            user_decay_per_week=self.config.user_confidence_decay_per_week,
        )
        await self.store.set_reflection_meta(None, last_decay_at=_now_iso())
        return count

    async def run_promote(self) -> int:
        """Promote patterns seen in 2+ projects to global scope."""
        count = await self.store.promote_patterns_to_global(
            self.config.min_project_pattern_count
        )
        await self.store.set_reflection_meta(None, last_promote_at=_now_iso())
        return count

    async def run_archive(self) -> int:
        """Archive memories below confidence threshold."""
        count = await self.store.archive_below_threshold(
            self.config.confidence_archive_threshold
        )
        await self.store.set_reflection_meta(None, last_archive_at=_now_iso())
        return count

    async def run_dedup_fuzzy(self, project: Optional[str] = None) -> dict:
        """Bug R4 (2026-04-22): wire fuzzy dedup into scheduled reflection.

        ``MaintenanceService.dedup_fuzzy`` has shipped since the Phase 7
        restructure but was never invoked from ``run_full`` — while
        docstrings (MemoryStore, SaveService, MaintenanceService) and
        user-facing docs (code-reading-guide, plan.md, AGENTS.md,
        GEMINI.md, repo-strategic-assessment) all asserted it ran at
        reflection time. Save-side dedup stayed exact-match only, so
        two-character edits accumulated forever and the vault's
        top-ranked results filled with near-duplicates over time.
        Returns ``{"merged": N, "archived": N}``.

        When ``project is None``, fan out per-project + globals (mirrors
        ``run_reflector(None)``'s N2 pattern). The underlying service's
        ``dedup_fuzzy(project=None)`` touches only the global bucket
        because ``fetch_active(None)`` is global-only by convention —
        so a single call would silently leave every project-scoped
        near-duplicate unmerged. Fanning out keeps the scheduled pass
        honest.
        """
        if project is not None:
            return await self.store.dedup_fuzzy(project=project)
        merged = 0
        archived = 0
        for p in await self.store.list_memory_projects():
            result = await self.store.dedup_fuzzy(project=p)
            merged += result.get("merged", 0)
            archived += result.get("archived", 0)
        return {"merged": merged, "archived": archived}

    # ── Agent mode ─────────────────────────────────────────────────────────

    async def agent_mode_prompt(self, project: Optional[str] = None) -> str:
        """Return a formatted memory dump with instructions for the coding agent to reflect.

        The agent (Claude Code, Codex, Gemini CLI) reads this output and executes
        deja commands directly — no separate LLM API call needed.
        """
        memories = await self.store.list_for_reflection(project)
        project_label = project or "global"
        project_flag = f" --project {project}" if project else ""

        if not memories:
            return f"No active memories found for project '{project_label}'. Nothing to reflect on."

        lines = [
            f"You are acting as a memory reflector for project '{project_label}'.",
            "",
            f"PROCESS EVERY ONE of the {len(memories)} active memories below — not just",
            "whatever topic the user happened to ask about in this session. The default",
            "mode of `deja reflect --agent-mode` is a complete sweep: comb every row,",
            "build a punch list of all obvious issues, then execute the punch list in",
            "one pass.",
            "",
            "Scan for, in roughly this priority order:",
            "  - Exact-content duplicates (same words across multiple IDs — pick the",
            "    one with highest reuse_count, archive the rest)",
            "  - Scope-leaks (same content saved at scope:global AND scope:project:X —",
            "    keep the correctly-scoped one, archive the other)",
            "  - Junk / save errors (single-word patterns, truncated content, malformed",
            "    entries)",
            "  - Stale stub TODO lists ('next items: 1. X, 2. Y') — typically archive",
            "  - Untriggered gotchas tied to a specific command boundary (add --trigger)",
            "  - Misclassified entries (pattern that is really a gotcha; gotcha that is",
            "    really a preference)",
            "  - Semantic duplicates (same rule, different wording — fuzzy threshold",
            "    won't catch these, you must)",
            "",
            "Actions:",
            "  1. Archive (stale, no longer relevant):",
            "       deja archive <id>",
            "  2. Invalidate (actively contradicted by newer information):",
            "       deja invalidate <id>",
            "  3. Consolidate (two or more memories express the same thing):",
            "       deja archive <id1>",
            "       deja archive <id2>",
            f'       deja save "<condensed content>" --type <type>{project_flag}',
            "     (If one existing version is clearly better, just archive the lesser",
            "     and keep the better as-is — no new save needed.)",
            "  4. Trigger-tag (gotcha clearly tied to a specific command, no trigger yet):",
            '       deja update <id> --trigger "cmd1, cmd2"',
            "       Use this for gotchas about what to do right before/after a specific",
            "       command. Example triggers: 'kubectl apply', 'alembic upgrade',",
            "       'terraform apply'. Only tag gotchas — not preferences, decisions,",
            "       or progress.",
            "  5. Reclassify (saved as the wrong type — e.g. pattern that is really a",
            "     gotcha):",
            "       deja update <id> --type gotcha",
            "",
            "Be conservative on each ACTION (skip a memory when intent is unclear),",
            "but exhaustive on COVERAGE (visit every memory, not just user-flagged ones).",
            "For trigger tagging: if a gotcha is already tagged (shown as [trigger:...]),",
            "skip it.",
            f"If after sweeping all {len(memories)} you find nothing actionable, that's",
            "fine — say so.",
            "",
            "--- MEMORIES ---",
            "",
        ]

        for m in memories:
            scope_label = f"project:{m['project']}" if m.get("project") else "global"
            trigger_str = f" [trigger:{m['trigger']}]" if m.get("trigger") else ""
            lines.append(
                f"[{m['type']}] [conf:{m['confidence']:.2f}] [scope:{scope_label}]"
                f" [ID:{m['id']}]{trigger_str}"
            )
            lines.append(m["content"])
            lines.append("")

        lines.append("--- END MEMORIES ---")
        return "\n".join(lines)

    # ── Full pass + auto-trigger ────────────────────────────────────────────

    async def run_full(self, project: Optional[str] = None) -> dict:
        """Full reflection pass: observer → reflector → decay → promote → dedup_fuzzy → archive.

        Bug R4 (2026-04-22): ``dedup_fuzzy`` slots between ``promote``
        and ``archive`` — after promotion (so promoted patterns are in
        the active set for cross-project dedup) and before archival (so
        archive sweeps low-confidence rows AFTER near-duplicates have
        been merged, giving the survivor the full merged confidence/
        reuse bump).
        """
        results: dict = {}
        if self.adapter:
            results["observer"] = await self.run_observer(project)
            results["reflector"] = await self.run_reflector(project)
        else:
            results["observer"] = 0
            results["reflector"] = 0
        results["decay"] = await self.run_decay()
        results["promote"] = await self.run_promote()
        results["dedup_fuzzy"] = await self.run_dedup_fuzzy(project)
        results["archive"] = await self.run_archive()
        return results

