from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, field_validator


def _substitute_env(value: str) -> str:
    """Substitute ${ENV_VAR} patterns with environment variable values."""
    def replacer(match: re.Match) -> str:
        var_name = match.group(1)
        return os.environ.get(var_name, match.group(0))

    return re.sub(r"\$\{([^}]+)\}", replacer, value)


def _expand_paths(data: dict) -> dict:
    """Recursively expand ~ in string values."""
    result = {}
    for key, value in data.items():
        if isinstance(value, dict):
            result[key] = _expand_paths(value)
        elif isinstance(value, str):
            result[key] = _substitute_env(value)
        else:
            result[key] = value
    return result


class LLMProviderConfig(BaseModel):
    provider: str = "ollama"
    model: str = "qwen2.5:3b"
    base_url: str = "http://localhost:11434"
    api_key: Optional[str] = None

    @field_validator("api_key", mode="before")
    @classmethod
    def expand_env_vars(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        return _substitute_env(v)


class LLMConfig(BaseModel):
    extraction: LLMProviderConfig = LLMProviderConfig(provider="none")
    reflection: LLMProviderConfig = LLMProviderConfig(provider="none")
    fallback: LLMProviderConfig = LLMProviderConfig(
        provider="anthropic",
        model="claude-haiku-4-5-20251001",
        api_key="${ANTHROPIC_API_KEY}",
    )


class StoreConfig(BaseModel):
    path: str = "~/.deja/store/memories.db"
    vault_path: str = "~/.deja/store/vault/"

    @property
    def db_path(self) -> Path:
        return Path(self.path).expanduser()

    @property
    def vault_dir(self) -> Path:
        return Path(self.vault_path).expanduser()


class ReflectionConfig(BaseModel):
    observer_trigger_tokens: int = 30000
    reflector_trigger_tokens: int = 40000
    kg_merge_schedule: str = "0 2 * * *"
    confidence_archive_threshold: float = 0.3
    # agent memories (gotcha, decision, progress, pattern) decay at this rate.
    # Operational knowledge goes stale; 0.05/week means a memory hits the 0.3
    # archive threshold in ~14 weeks without re-confirmation.
    confidence_decay_per_week: float = 0.05
    # user memories (preferences, habits) decay ~5x slower. Personal style
    # preferences don't go stale the way project-specific gotchas do.
    user_confidence_decay_per_week: float = 0.01
    min_project_pattern_count: int = 2


class WatchersConfig(BaseModel):
    claude_code: bool = True
    gemini_cli: bool = False
    codex_cli: bool = False
    aider: bool = False
    debounce_seconds: int = 30


class EmbeddingConfig(BaseModel):
    provider: str = "none"  # none | ollama
    model: str = "nomic-embed-text"
    base_url: str = "http://localhost:11434"


class CloudConfig(BaseModel):
    enabled: bool = False
    endpoint: str = "https://api.deja.sh"
    web_url: str = "https://www.deja.sh"
    sync_on_save: bool = False
    # Contract change (2026-04-19): ``deja load`` is local-only by default.
    # Cross-machine pull is now opt-in via the ``--pull`` CLI flag, this
    # config knob, or running ``deja sync --pull`` from a session-start
    # hook (cron / Cursor plugin / shell rc). MCP ``memory_load`` stays
    # local-only intentionally — there's no MCP equivalent of a flag, and
    # cross-machine MCP users should rely on a scheduled ``deja sync``.
    # See ``docs/code-reviews/2026-04-19.md`` §"Contract Change: pulls
    # become explicit". Pre-2026-04-19 behavior was equivalent to
    # ``pull_on_load: true`` — flipping this back gives you the old default.
    pull_on_load: bool = False


class Config(BaseModel):
    llm: LLMConfig = LLMConfig()
    store: StoreConfig = StoreConfig()
    reflection: ReflectionConfig = ReflectionConfig()
    watchers: WatchersConfig = WatchersConfig()
    embedding: EmbeddingConfig = EmbeddingConfig()
    cloud: CloudConfig = CloudConfig()


def load_config(path: Optional[Path] = None) -> Config:
    """Load config from path, falling back to ~/.deja/config.yaml,
    then to the bundled default."""
    candidates = []
    if path:
        candidates.append(Path(path).expanduser())
    candidates.append(Path("~/.deja/config.yaml").expanduser())

    for candidate in candidates:
        if candidate.exists():
            with open(candidate) as f:
                raw = yaml.safe_load(f) or {}
            raw = _expand_paths(raw)
            return Config.model_validate(raw)

    return Config()
