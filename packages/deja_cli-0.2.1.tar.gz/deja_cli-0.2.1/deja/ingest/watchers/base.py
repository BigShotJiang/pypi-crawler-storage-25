from __future__ import annotations

import asyncio
import json
import logging
import os
import tempfile
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable, Awaitable, Optional

from deja.core.store import MemoryStore
from deja.core.store.policy import MAX_CONTENT_LENGTH
from deja.llm.base import LLMAdapter
from deja.llm.embedding import EmbeddingAdapter

logger = logging.getLogger(__name__)


# Bug N8 (2026-04-19): bounded retry on extraction failure.
# Schedule pattern is "ride through a typical LLM blip, then give up loudly":
# 30s catches transient 429 / rate-limit recovery, 2min catches a longer
# provider hiccup, 10min covers a broader outage. After three attempts we
# stop scheduling and warn — at that point the failure is structural
# (auth revoked, prompt regression, bad transcript) and silently retrying
# forever would mask the real problem.
EXTRACTION_RETRY_BACKOFF: tuple[int, ...] = (30, 120, 600)

# Bug N9 (2026-04-19): per-watcher state lives in this directory. Each
# concrete subclass gets its own ``<ClassName>.state.json`` sidecar
# holding ``{path -> mtime}`` so ``_processed`` survives across runs.
DEFAULT_WATCHER_STATE_DIR: Path = Path("~/.deja/watchers").expanduser()


class BaseWatcher(ABC):
    def __init__(
        self,
        store: MemoryStore,
        extractor_fn: Callable[..., Awaitable[list[dict]]],
        adapter: Optional[LLMAdapter],
        debounce_seconds: int = 30,
        embedding_adapter: Optional[EmbeddingAdapter] = None,
        state_dir: Optional[Path] = None,
    ) -> None:
        self.store = store
        self.extractor_fn = extractor_fn
        self.adapter = adapter
        self.debounce_seconds = debounce_seconds
        self.embedding_adapter = embedding_adapter
        # Bug N9 (2026-04-19): per-watcher cursor sidecar. Default lives
        # in ``~/.deja/watchers/<ClassName>.state.json``. Tests pass a
        # tmpdir to keep state ephemeral.
        self._state_dir = (
            Path(state_dir) if state_dir is not None else DEFAULT_WATCHER_STATE_DIR
        )
        # path -> last mtime we processed (loaded from sidecar at startup,
        # rewritten after every successful stamp).
        self._processed: dict[Path, float] = self._load_processed_state()
        # path -> pending debounce task
        self._pending: dict[Path, asyncio.TimerHandle] = {}
        # Bug N8 (2026-04-19): per-path extraction retry state. Without
        # this, an extraction-side failure (LLM 429, provider 5xx, JSON
        # parse) would log-and-return — and since ``_pending.pop(path)``
        # already ran at the top of ``_process``, no retry was scheduled.
        # If the user's session ended (no more file events), the
        # transcript was stranded forever. We now schedule bounded
        # retries with exponential-ish backoff so a typical "LLM blipped
        # at the end of my session" failure self-heals.
        self._extraction_retries: dict[Path, int] = {}
        self._extraction_retry_handles: dict[Path, asyncio.TimerHandle] = {}
        # Bug N10 (2026-04-19): track every spawned ``_process`` task so
        # ``drain_inflight`` can await them on shutdown. Without this,
        # SIGTERM/Ctrl-C cancels mid-extraction tasks and the extracted
        # memories never land. Tasks self-remove on completion.
        self._inflight: set[asyncio.Task] = set()

    @property
    def state_file(self) -> Path:
        """Sidecar holding the persisted ``_processed`` cursor for this
        concrete watcher subclass. Path is keyed by class name so
        Claude/Gemini/Codex watchers don't fight over one file.
        """
        return self._state_dir / f"{self.__class__.__name__}.state.json"

    def _load_processed_state(self) -> dict[Path, float]:
        """Read the on-disk cursor sidecar. Returns ``{}`` on first run
        or any read/parse error — a corrupted sidecar should not block
        the watcher from starting; the worst case is one extra LLM call
        per known file as ``startup_replay`` re-extracts them.
        """
        sidecar = self._state_dir / f"{self.__class__.__name__}.state.json"
        if not sidecar.exists():
            return {}
        try:
            raw = json.loads(sidecar.read_text())
        except (OSError, json.JSONDecodeError) as e:
            logger.warning(
                "Failed to load watcher state from %s: %s — starting empty",
                sidecar, e,
            )
            return {}
        out: dict[Path, float] = {}
        for k, v in raw.items():
            try:
                out[Path(k)] = float(v)
            except (TypeError, ValueError):
                continue
        return out

    def _persist_processed_state(self) -> None:
        """Atomically rewrite the cursor sidecar after a successful stamp.

        Atomic-replace via tempfile + ``os.replace`` so a crash between
        write and rename can't leave a half-written sidecar that the next
        load would refuse — losing the entire cursor.
        """
        try:
            # Bug Q3 (2026-04-19 pass 3): 0700 so the sidecar's session
            # path list (which transcripts we've processed and when) isn't
            # world-readable on a multi-user machine. ``mode`` is only
            # applied when the directory is created, so pre-existing dirs
            # keep their bits — safe no-op on upgrade.
            self._state_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        except OSError as e:
            logger.warning(
                "Failed to create watcher state dir %s: %s", self._state_dir, e,
            )
            return
        payload = {str(p): m for p, m in self._processed.items()}
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                dir=str(self._state_dir),
                prefix=f".{self.__class__.__name__}.",
                suffix=".tmp",
                delete=False,
            ) as tmp:
                json.dump(payload, tmp)
                tmp_path = tmp.name
            os.replace(tmp_path, self.state_file)
        except OSError as e:
            logger.warning("Failed to persist watcher state: %s", e)

    @abstractmethod
    def get_watch_paths(self) -> list[Path]: ...

    @abstractmethod
    def should_process(self, path: Path) -> bool: ...

    @abstractmethod
    def get_project_name(self, path: Path) -> str: ...

    def parse_transcript(self, content: str) -> str:
        """Convert raw file content to a plain-text transcript for extraction.

        Default implementation returns content unchanged (suitable for plain text
        files like summary.md). Subclasses override this to parse JSON/JSONL formats.
        """
        return content

    def handle_file_event(self, path: Path) -> None:
        """Called from watchdog thread. Schedules debounced async processing."""
        if not self.should_process(path):
            return

        loop = asyncio.get_event_loop()

        # Cancel any existing pending timer for this path
        if path in self._pending:
            self._pending[path].cancel()

        # Bug P2 (2026-04-19 pass 2): a fresh file event supersedes any
        # pending extraction retry for the same path. Without this, a retry
        # timer scheduled by a prior failed extraction and the fresh
        # debounce can both fire and invoke ``_process`` concurrently —
        # both then call the LLM extractor on the same mtime before either
        # can stamp ``_processed``, doubling the cost (correctness is
        # preserved by save-side dedup). Drop the retry bookkeeping here.
        retry_handle = self._extraction_retry_handles.pop(path, None)
        if retry_handle is not None:
            retry_handle.cancel()
        self._extraction_retries.pop(path, None)

        # Bug N10 (2026-04-19): route through _spawn_process so the
        # resulting task is tracked and drain_inflight can await it on
        # shutdown.
        handle = loop.call_later(
            self.debounce_seconds,
            lambda: self._spawn_process(path),
        )
        self._pending[path] = handle

    def shutdown(self) -> None:
        """Cancel all pending debounce and retry timers.

        Call from the watcher-lifecycle owner (``deja watch``) before
        stopping the event loop. Without this, timers scheduled via
        ``call_later`` can fire against a stopping loop, producing
        spurious ``asyncio.ensure_future`` warnings and possibly invoking
        ``_process`` after ``store.close()`` has been awaited.
        """
        for handle in self._pending.values():
            handle.cancel()
        self._pending.clear()
        for handle in self._extraction_retry_handles.values():
            handle.cancel()
        self._extraction_retry_handles.clear()
        self._extraction_retries.clear()

    async def _process(self, path: Path) -> None:
        """Read file and run extraction pipeline."""
        self._pending.pop(path, None)

        if not path.exists():
            return

        try:
            mtime = path.stat().st_mtime
        except OSError:
            return

        # Skip if we already processed this exact version
        if self._processed.get(path) == mtime:
            return

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            logger.error("Failed to read %s: %s", path, e)
            return

        project = self.get_project_name(path)
        source = self.__class__.__name__.lower().replace("watcher", "")

        content = self.parse_transcript(content)

        if self.adapter is None:
            # No LLM configured — save the raw summary as a single progress memory.
            # The agent-driven path (CLAUDE.md skill prompt) handles structured extraction.
            #
            # Truncate (not reject) at MAX_CONTENT_LENGTH: the watcher is a
            # system-side ingestion path with no agent on the other end to
            # split a long transcript, so SaveService's reject-and-ask
            # contract doesn't apply here. Truncating keeps the watcher
            # working under the cap; the better fix is to configure an
            # extraction LLM, which produces multiple typed memories from
            # the same blob. The bound mirrors the save-time cap so a
            # future bump to MAX_CONTENT_LENGTH doesn't silently lose
            # transcript bytes here.
            raw_memory = {
                "type": "progress",
                "category": "agent",
                "content": content[:MAX_CONTENT_LENGTH].strip(),
                "scope": f"project:{project}",
                "project": project,
                "source": source,
                "confidence": 0.5,
            }
            try:
                await self.store.save(raw_memory)
                logger.info("Saved raw summary from %s (no LLM configured)", path)
                # Bug H5 (2026-04-18): only stamp _processed on success.
                # Previously this was stamped unconditionally, so a transient
                # DB lock or schema validation error would silently strand
                # this transcript forever — the next debounce would
                # short-circuit on _processed.get(path) == mtime.
                # Bug N9 (2026-04-19): also flush to the sidecar so the
                # cursor survives a restart.
                self._processed[path] = mtime
                self._persist_processed_state()
            except Exception as e:
                logger.error("Failed to save raw summary: %s", e)
            return

        try:
            memories = await self.extractor_fn(content, project, source, self.adapter)
        except Exception as e:
            logger.error("Extraction failed for %s: %s", path, e)
            self._schedule_extraction_retry(path, reason=str(e))
            return

        # Extraction succeeded — clear any retry bookkeeping from prior
        # failed attempts so a future failure starts the backoff fresh.
        self._clear_extraction_retry(path)

        saved = 0
        failed = 0
        for memory in memories:
            try:
                emb_bytes = None
                if self.embedding_adapter is not None:
                    try:
                        emb = await self.embedding_adapter.embed(memory["content"])
                        emb_bytes = EmbeddingAdapter.to_bytes(emb)
                    except Exception as emb_e:
                        logger.warning("Embedding failed: %s", emb_e)
                await self.store.save(memory, emb_bytes)
                saved += 1
            except Exception as e:
                failed += 1
                logger.error("Failed to save memory: %s", e)

        # Bug H5 (2026-04-18): only mark processed when every extracted
        # memory actually persisted. A transient DB lock or schema
        # validation error on even one memory would otherwise let the
        # short-circuit at the top of _process drop the file forever.
        # Empty extraction (memories == []) is success: there's nothing
        # to retry, so stamp.
        # Bug N9 (2026-04-19): persist the cursor so a watcher restart
        # doesn't replay everything from scratch.
        if failed == 0:
            self._processed[path] = mtime
            self._persist_processed_state()
        else:
            logger.warning(
                "Not marking %s as processed: %d/%d save(s) failed; will retry on next event",
                path, failed, len(memories),
            )
        if saved:
            logger.info("Saved %d memories from %s (project: %s)", saved, path, project)

    def _schedule_extraction_retry(self, path: Path, *, reason: str) -> None:
        """Bug N8 (2026-04-19): re-queue ``_process(path)`` after extraction
        failure with bounded exponential-ish backoff.

        Without this, a transient extractor exception (LLM 429, provider
        5xx, JSON parse fail) at the tail end of a user's session would
        strand the transcript forever — ``_pending.pop(path, None)`` at
        the top of ``_process`` already cleared the debounce timer, and
        the ``except Exception: return`` path leaves nothing behind.
        Watchdog only re-fires on filesystem events, which never come
        once the session is closed.

        After ``len(EXTRACTION_RETRY_BACKOFF)`` failed attempts (the
        typical-blip window plus a broader-outage tail), we stop
        scheduling and warn loudly. Continuing past the cap would mask a
        structural failure (revoked auth, prompt regression, bad
        transcript) under a sea of retry log lines.
        """
        attempt = self._extraction_retries.get(path, 0)
        if attempt >= len(EXTRACTION_RETRY_BACKOFF):
            logger.warning(
                "Extraction for %s failed %d times (last error: %s); giving up "
                "and stranding this transcript. The next file event will retry.",
                path, attempt, reason,
            )
            self._extraction_retries.pop(path, None)
            return

        delay = EXTRACTION_RETRY_BACKOFF[attempt]
        self._extraction_retries[path] = attempt + 1

        existing = self._extraction_retry_handles.pop(path, None)
        if existing is not None:
            existing.cancel()

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            # No running loop — happens in non-async test harnesses or if
            # the watcher is being torn down. Nothing to schedule onto.
            logger.warning(
                "Extraction retry for %s skipped — no running event loop", path,
            )
            return

        # Bug N10 (2026-04-19): track the retry-spawned task too.
        handle = loop.call_later(
            delay,
            lambda: self._spawn_process(path),
        )
        self._extraction_retry_handles[path] = handle
        logger.info(
            "Scheduled extraction retry %d/%d for %s in %ds (last error: %s)",
            attempt + 1, len(EXTRACTION_RETRY_BACKOFF), path, delay, reason,
        )

    def _clear_extraction_retry(self, path: Path) -> None:
        """Drop any pending retry bookkeeping for ``path`` after a successful
        extraction so the next failure starts the backoff schedule fresh.
        """
        handle = self._extraction_retry_handles.pop(path, None)
        if handle is not None:
            handle.cancel()
        self._extraction_retries.pop(path, None)

    # ── lifecycle: startup replay (N9) and shutdown drain (N10) ────────────

    def _spawn_process(self, path: Path) -> asyncio.Task:
        """Bug N10 (2026-04-19): create + track a ``_process`` task.

        Centralizing task creation lets ``drain_inflight`` await every
        live extraction on shutdown. Tasks self-remove from the set on
        completion via ``add_done_callback`` so the set doesn't leak.
        """
        task = asyncio.ensure_future(self._process(path))
        self._inflight.add(task)
        task.add_done_callback(self._inflight.discard)
        return task

    async def startup_replay(self) -> int:
        """Bug N9 (2026-04-19): walk every watched directory and re-process
        files whose mtime has advanced past the persisted cursor.

        Without this, files modified while ``deja watch`` was down (laptop
        sleep, crash, machine restart, ``brew services restart``) are
        invisible — watchdog only fires on events that happen *after*
        ``observer.start()``. The watcher's contract is "capture every
        session", and a restart-without-replay breaks it on the most
        common failure mode.

        Returns the number of files enqueued for processing.
        """
        # Re-read the sidecar in case it was updated between __init__ and
        # the call to startup_replay (e.g. the CLI wrote it while wiring
        # things up, or a test pre-seeded it after construction).
        self._processed = self._load_processed_state()
        enqueued = 0
        for watch_path in self.get_watch_paths():
            if not watch_path.exists():
                continue
            try:
                candidates = [p for p in watch_path.rglob("*") if p.is_file()]
            except OSError as e:
                logger.warning("Replay walk of %s failed: %s", watch_path, e)
                continue
            for path in candidates:
                if not self.should_process(path):
                    continue
                try:
                    mtime = path.stat().st_mtime
                except OSError:
                    continue
                cursor = self._processed.get(path)
                if cursor is not None and mtime <= cursor:
                    continue
                # Synchronously await each replay rather than spawning
                # tasks. Replay runs once at startup, before file events
                # arrive, so concurrency buys nothing — and processing
                # serially makes the LLM-rate-limit tail predictable.
                logger.info(
                    "Replay: processing %s (mtime=%s, cursor=%s)",
                    path, mtime, cursor,
                )
                try:
                    await self._process(path)
                    enqueued += 1
                except Exception as e:
                    logger.error("Replay of %s failed: %s", path, e)
        return enqueued

    async def drain_inflight(self, timeout: float = 10.0) -> None:
        """Bug N10 (2026-04-19): await every spawned ``_process`` task,
        bounded by ``timeout`` so a hung adapter can't block shutdown.

        Called from the ``deja watch`` ``finally`` block before
        ``store.close()``. Without this, SIGTERM/Ctrl-C cancels mid-flight
        extraction tasks and the extracted memories vanish — and per N9,
        the file is never replayed (until N9 is also fixed).
        """
        if not self._inflight:
            return
        # Snapshot under no-await; tasks self-remove via callback when done.
        tasks = list(self._inflight)
        try:
            results = await asyncio.wait_for(
                asyncio.gather(*tasks, return_exceptions=True),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            still_running = [t for t in tasks if not t.done()]
            logger.warning(
                "drain_inflight timed out after %.1fs with %d task(s) still "
                "running; abandoning them. Files will be replayed on next "
                "startup via the persisted cursor.",
                timeout, len(still_running),
            )
            return
        # Bug Q1 (2026-04-19 pass 3): don't swallow task exceptions.
        # ``return_exceptions=True`` stops one failure short-circuiting
        # the gather, but the captured exceptions still need to surface —
        # otherwise a shutdown save that raises (aiosqlite write-after-
        # close, embedding-adapter crash, validator failure) is silently
        # lost and the operator sees a clean shutdown. The persisted
        # cursor (N9) protects replay, but loud failure is still the
        # contract.
        for result in results:
            if isinstance(result, BaseException) and not isinstance(
                result, asyncio.CancelledError,
            ):
                logger.warning(
                    "drain_inflight: task raised during shutdown: %r", result,
                )
