# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from __future__ import annotations

from microsoft_agents.hosting.core.authorization.auth_types import AuthTypes


class AgentAuthConfiguration:
    """
    Configuration for Agent authentication.

    TENANT_ID: The tenant ID for the Azure AD.
    CLIENT_ID: The client ID for the Azure AD application.
    AUTH_TYPE: The type of authentication to use (microsoft_agents.hosting.core.authorization.auth_types.AuthTypes).
    CLIENT_SECRET: The client secret for the Azure AD application (if using client secret authentication).
    CERT_PFX_FILE: The path to the PFX certificate file (if using certificate authentication).
    CONNECTION_NAME: The name of the connection
    FEDERATED_CLIENT_ID: The client ID for federated credentials (if using federated credentials authentication).
    SCOPES: The scopes to request
    AUTHORITY: The authority URL for the Azure AD (if different from the default).
    ALT_BLUEPRINT_ID: An optional alternative blueprint ID used when constructing a connector client.
    """

    TENANT_ID: str | None
    AUTH_TYPE: AuthTypes
    CLIENT_ID: str | None
    CLIENT_SECRET: str | None
    CERT_PFX_FILE: str | None
    CONNECTION_NAME: str | None
    FEDERATED_CLIENT_ID: str | None
    SCOPES: list[str] | None
    AUTHORITY: str | None
    ALT_BLUEPRINT_ID: str | None
    ANONYMOUS_ALLOWED: bool = False

    # Multi-connection support: Maintains a map of all configured connections
    # to enable JWT validation across connections. This allows tokens issued
    # for any configured connection to be validated, supporting multi-tenant
    # scenarios where connections share a security boundary.
    #
    # Note: This is an internal implementation detail. External code should
    # not directly access _connections.
    _connections: dict[str, AgentAuthConfiguration]

    def __init__(
        self,
        auth_type: AuthTypes | None = None,
        client_id: str | None = None,
        tenant_id: str | None = None,
        client_secret: str | None = None,
        cert_pfx_file: str | None = None,
        connection_name: str | None = None,
        federated_client_id: str | None = None,
        authority: str | None = None,
        scopes: list[str] | None = None,
        anonymous_allowed: bool = False,
        **kwargs: str,
    ):

        self.AUTH_TYPE = auth_type or kwargs.get("AUTHTYPE", AuthTypes.client_secret)
        self.CLIENT_ID = client_id or kwargs.get("CLIENTID", None)
        self.AUTHORITY = authority or kwargs.get("AUTHORITY", None)
        self.TENANT_ID = tenant_id or kwargs.get("TENANTID", None)
        self.CLIENT_SECRET = client_secret or kwargs.get("CLIENTSECRET", None)
        self.CERT_PFX_FILE = cert_pfx_file or kwargs.get("CERTPFXFILE", None)
        self.CONNECTION_NAME = connection_name or kwargs.get("CONNECTIONNAME", None)
        self.FEDERATED_CLIENT_ID = federated_client_id or kwargs.get(
            "FEDERATEDCLIENTID", None
        )
        self.SCOPES = scopes or kwargs.get("SCOPES", None)
        self.ALT_BLUEPRINT_ID = kwargs.get("ALT_BLUEPRINT_NAME", None)
        self.ANONYMOUS_ALLOWED = anonymous_allowed or kwargs.get(
            "ANONYMOUS_ALLOWED", False
        )

        # JWT-patch: always at least include self for backward compat
        self._connections = {str(self.CONNECTION_NAME): self}

    @property
    def ISSUERS(self) -> list[str]:
        """
        Gets the list of issuers.
        """
        return [
            "https://api.botframework.com",
            f"https://sts.windows.net/{self.TENANT_ID}/",
            f"https://login.microsoftonline.com/{self.TENANT_ID}/v2.0",
        ]

    def _jwt_patch_is_valid_aud(self, aud: str) -> bool:
        """
        JWT-patch: Checks if the given audience is valid for any of the connections.
        """
        for conn in self._connections.values():
            if not conn.CLIENT_ID:
                continue
            if aud.lower() == conn.CLIENT_ID.lower():
                return True
        return False
