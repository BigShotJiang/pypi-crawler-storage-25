"""Tests for AgentRefStateMeta and AgentRefState behavior."""

from __future__ import annotations

import pytest

from agentref.config import AgentRefRuntime, configure
from agentref.core.descriptors import ExternalizedDescriptor, InlineDescriptor
from agentref.core.reference import ContentRef
from agentref.core.state import AgentRefState
from agentref.core.types import Externalized, Inline
from agentref.exceptions import AgentRefError
from agentref.storage import InMemoryCAS


def test_metaclass_installs_descriptors_and_field_metadata() -> None:
    class ResearchState(AgentRefState):
        step: Inline[str]
        docs: Externalized[list[str]]

    assert isinstance(ResearchState.__dict__["step"], InlineDescriptor)
    assert isinstance(ResearchState.__dict__["docs"], ExternalizedDescriptor)
    assert ResearchState.fields()["step"].kind == "inline"
    assert ResearchState.fields()["docs"].kind == "externalized"
    assert ResearchState.inline_fields().keys() == {"step"}
    assert ResearchState.externalized_fields().keys() == {"docs"}


def test_metaclass_preserves_inherited_agentref_fields() -> None:
    class BaseState(AgentRefState):
        current_step: Inline[str]

    class ChildState(BaseState):
        docs: Externalized[list[str]]

    assert set(ChildState.fields()) == {"current_step", "docs"}
    child = ChildState(current_step="retrieve", docs=["a"])

    assert child.current_step == "retrieve"
    assert child.docs == ["a"]


def test_constructor_rejects_unknown_fields() -> None:
    class ResearchState(AgentRefState):
        step: Inline[str]

    with pytest.raises(AgentRefError, match="Unknown field"):
        ResearchState(step="retrieve", missing=True)


def test_unassigned_field_access_raises_attribute_error() -> None:
    class ResearchState(AgentRefState):
        step: Inline[str]
        docs: Externalized[list[str]]

    state = ResearchState()

    with pytest.raises(AttributeError, match="step"):
        _ = state.step
    with pytest.raises(AttributeError, match="docs"):
        _ = state.docs


def test_checkpoint_round_trip_restores_inline_and_externalized_fields() -> None:
    backend = InMemoryCAS()
    configure(backend=backend)

    class ResearchState(AgentRefState):
        step: Inline[str]
        docs: Externalized[list[str]]

    original = ResearchState(step="retrieve", docs=["doc-a", "doc-b"])
    checkpoint = original.to_checkpoint_dict()
    restored = ResearchState.from_checkpoint_dict(checkpoint)

    assert restored.step == "retrieve"
    assert restored.docs == ["doc-a", "doc-b"]
    assert restored.to_checkpoint_dict() == checkpoint


def test_checkpoint_round_trip_accepts_content_ref_dicts() -> None:
    backend = InMemoryCAS()
    configure(backend=backend)

    class BlobState(AgentRefState):
        blob: Externalized[bytes]

    original = BlobState(blob=b"payload")
    ref = original.to_checkpoint_dict()["blob"]
    assert isinstance(ref, ContentRef)

    restored = BlobState.from_checkpoint_dict({"blob": ref.to_dict()})

    assert restored.blob == b"payload"


def test_agent_ref_can_use_instance_runtime_without_global_configure() -> None:
    backend = InMemoryCAS("instance-local")
    runtime = AgentRefRuntime(backend=backend)

    class BlobState(AgentRefState):
        blob: Externalized[bytes]

    state = BlobState(_runtime=runtime, blob=b"payload")
    ref = state.to_checkpoint_dict()["blob"]

    assert isinstance(ref, ContentRef)
    assert ref.backend_id == "instance-local"
    assert state.blob == b"payload"


def test_checkpoint_restore_rejects_invalid_externalized_value() -> None:
    class BlobState(AgentRefState):
        blob: Externalized[bytes]

    with pytest.raises(AgentRefError, match="ContentRef"):
        BlobState.from_checkpoint_dict({"blob": b"not-a-ref"})


def test_mapping_access_hydrates_and_assigns_declared_fields() -> None:
    class ResearchState(AgentRefState):
        step: Inline[str]
        docs: Externalized[list[str]]

    state = ResearchState()
    state["step"] = "retrieve"
    state["docs"] = ["doc"]

    assert state["step"] == "retrieve"
    assert state["docs"] == ["doc"]
    assert "step" in state
    assert "missing" not in state

    with pytest.raises(KeyError, match="Unknown field"):
        _ = state["missing"]


def test_framework_conversion_methods_are_checkpoint_safe_aliases() -> None:
    class ResearchState(AgentRefState):
        step: Inline[str]
        docs: Externalized[list[str]]

    state = ResearchState(step="retrieve", docs=["doc"])
    checkpoint = state.to_checkpoint_dict()

    assert state.to_langgraph_state() == checkpoint
    assert state.to_llamaindex_context_dict() == checkpoint
    assert state.to_autogen_state() == checkpoint
    assert ResearchState.from_langgraph_state(checkpoint).docs == ["doc"]
    assert ResearchState.from_llamaindex_context_dict(checkpoint).docs == ["doc"]
    assert ResearchState.from_autogen_state(checkpoint).docs == ["doc"]
