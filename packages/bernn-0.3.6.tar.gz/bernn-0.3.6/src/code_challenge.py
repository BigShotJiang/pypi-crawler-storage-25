from __future__ import annotations

import ast
from datetime import datetime, timezone
from pathlib import Path
import builtins
from io import StringIO
import base64
import json

import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression, RidgeClassifier, SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, RobustScaler, StandardScaler
from sklearn.decomposition import PCA
from sklearn.svm import LinearSVC, SVC

from src.hf_utils import download_private_inference_file, load_private_inference, load_private_labels
from src.leaderboard import evaluate_predictions, sorted_board


ROOT = Path(__file__).resolve().parent.parent

FORBIDDEN_CALLS = {
    "open",
    "eval",
    "exec",
    "compile",
    "__import__",
    "input",
    "help",
    "globals",
    "locals",
    "vars",
    "dir",
    "getattr",
    "setattr",
    "delattr",
}
FORBIDDEN_ATTR_PREFIX = "__"
MAX_CODE_CHARS = 40000


class CodeValidationError(ValueError):
    pass


class PlotCapture:
    """Capture matplotlib plots as base64-encoded images (private - not shared)."""
    
    def __init__(self):
        self.plots = []
    
    def add_plot(self, title: str = ""):
        """Capture current matplotlib figure as base64 PNG."""
        try:
            import matplotlib.pyplot as plt
            import io
            
            buf = io.BytesIO()
            plt.savefig(buf, format='png', dpi=100, bbox_inches='tight')
            buf.seek(0)
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            self.plots.append({
                'title': title,
                'type': 'matplotlib',
                'data': img_base64
            })
            plt.close()
        except Exception as e:
            self.plots.append({
                'title': title or 'Plot Error',
                'type': 'error',
                'data': str(e)
            })
    
    def to_html(self) -> str:
        """Convert plots to scrollable HTML (displayed on leaderboard)."""
        if not self.plots:
            return ""
        
        html = '<div style="display: flex; gap: 10px; overflow-x: auto; max-height: 400px; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">'
        for plot in self.plots:
            if plot['type'] == 'matplotlib':
                html += f'''
                <div style="flex-shrink: 0; text-align: center;">
                    <p style="margin: 0 0 5px 0; font-size: 12px; font-weight: bold;">{plot['title']}</p>
                    <img src="data:image/png;base64,{plot['data']}" style="max-width: 300px; max-height: 300px; border: 1px solid #ccc; border-radius: 2px;" />
                </div>
                '''
            else:
                html += f'<div style="color: red; padding: 10px;">{plot["data"]}</div>'
        html += '</div>'
        return html
    
    def to_json(self) -> str:
        """Serialize plots to JSON for database storage."""
        return json.dumps(self.plots)
    
    @classmethod
    def from_json(cls, json_str: str) -> "PlotCapture":
        """Restore plots from JSON."""
        instance = cls()
        try:
            instance.plots = json.loads(json_str)
        except Exception:
            pass
        return instance


def _safe_builtins() -> dict[str, object]:
    allowed = {
        "abs": builtins.abs,
        "all": builtins.all,
        "any": builtins.any,
        "bool": builtins.bool,
        "dict": builtins.dict,
        "enumerate": builtins.enumerate,
        "Exception": builtins.Exception,
        "IndexError": builtins.IndexError,
        "float": builtins.float,
        "int": builtins.int,
        "isinstance": builtins.isinstance,
        "len": builtins.len,
        "hasattr": builtins.hasattr,
        "list": builtins.list,
        "max": builtins.max,
        "min": builtins.min,
        "print": builtins.print,
        "range": builtins.range,
        "RuntimeError": builtins.RuntimeError,
        "set": builtins.set,
        "sorted": builtins.sorted,
        "str": builtins.str,
        "object": builtins.object,
        "sum": builtins.sum,
        "tuple": builtins.tuple,
        "ValueError": builtins.ValueError,
        "zip": builtins.zip,
        "__build_class__": builtins.__build_class__,
    }
    return allowed


def _base_exec_env(plot_capture: PlotCapture | None = None) -> dict[str, object]:
    env: dict[str, object] = {
        "__builtins__": _safe_builtins(),
        "np": np,
        "pd": pd,
        "Pipeline": Pipeline,
        "StandardScaler": StandardScaler,
        "RobustScaler": RobustScaler,
        "MinMaxScaler": MinMaxScaler,
        "PCA": PCA,
        "LogisticRegression": LogisticRegression,
        "RidgeClassifier": RidgeClassifier,
        "SGDClassifier": SGDClassifier,
        "LinearSVC": LinearSVC,
        "SVC": SVC,
        "RandomForestClassifier": RandomForestClassifier,
        "ExtraTreesClassifier": ExtraTreesClassifier,
        "KNeighborsClassifier": KNeighborsClassifier,
        "GaussianNB": GaussianNB,
        "plot_capture": plot_capture,
        "download_private_inference_file": download_private_inference_file,
    }

    # Visualization
    try:
        import matplotlib.pyplot as plt
        env["plt"] = plt
    except Exception:
        pass

    try:
        import seaborn as sns
        env["sns"] = sns
    except Exception:
        pass

    try:
        import plotly.graph_objects as go
        import plotly.express as px
        env["go"] = go
        env["px"] = px
    except Exception:
        pass

    # UMAP
    try:
        import umap
        env["umap"] = umap
    except Exception:
        pass

    # Batch correction methods
    try:
        import scanpy as sc
        env["sc"] = sc
    except Exception:
        pass

    try:
        import harmonypy
        env["harmonypy"] = harmonypy
    except Exception:
        pass

    env["BERNN_AVAILABLE"] = False
    env["BERNN_LOAD_ERROR"] = ""

    # BERNN trainers exposed by the installed bernn package
    bernn_error = None
    try:
        from bernn import TrainAEClassifierHoldout, TrainAEThenClassifierHoldout
        from bernn.config.training_config import TrainingConfig
        env["TrainAEClassifierHoldout"] = TrainAEClassifierHoldout
        env["TrainAEThenClassifierHoldout"] = TrainAEThenClassifierHoldout
        env["TrainingConfig"] = TrainingConfig
        env["BERNN_AVAILABLE"] = True
    except Exception as exc:
        bernn_error = exc

    if bernn_error is not None:
        env["BERNN_LOAD_ERROR"] = f"{type(bernn_error).__name__}: {bernn_error}"

    # Deep learning
    try:
        import torch
        env["torch"] = torch
    except Exception:
        pass

    try:
        import jax
        import jax.numpy as jnp
        env["jax"] = jax
        env["jnp"] = jnp
    except Exception:
        pass

    return env


def _validate_code(code: str, label: str) -> None:
    if len(code) > MAX_CODE_CHARS:
        raise CodeValidationError(f"{label} code is too long (max {MAX_CODE_CHARS} chars).")

    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        raise CodeValidationError(f"{label} has a syntax error: {exc}") from exc

    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            raise CodeValidationError(
                f"{label} cannot use import statements. Common ML libs are preloaded."
            )

        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in FORBIDDEN_CALLS:
                raise CodeValidationError(f"{label} uses forbidden call: {node.func.id}")

        if isinstance(node, ast.Attribute) and isinstance(node.attr, str):
            if node.attr.startswith(FORBIDDEN_ATTR_PREFIX):
                raise CodeValidationError(f"{label} uses forbidden dunder attribute access.")


def _exec_user_code(code: str, label: str, env: dict | None = None) -> dict[str, object]:
    _validate_code(code, label)
    if env is None:
        env = _base_exec_env()
    exec(compile(code, f"<{label}>", "exec"), env, env)
    return env


def _clean_features(df: pd.DataFrame, feature_cols: list[str]) -> pd.DataFrame:
    return (
        df[feature_cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0)
        .reset_index(drop=True)
    )


def _load_data_for_dataset(dataset: str) -> tuple[pd.DataFrame, pd.Series, pd.Series, pd.DataFrame, pd.Series, pd.DataFrame]:
    train_path = ROOT / "data" / "datasets" / dataset / f"{dataset}_train.csv"
    if not train_path.exists():
        raise FileNotFoundError(f"Public train split not found: {train_path}")

    train = pd.read_csv(train_path)
    private_inference = load_private_inference(dataset)
    private_labels = load_private_labels(dataset)

    required_train = {"name", "batch", "label"}
    required_inf = {"name", "batch"}
    if not required_train.issubset(set(train.columns)):
        raise ValueError(f"Train file for {dataset} must contain name, batch, label")
    if not required_inf.issubset(set(private_inference.columns)):
        raise ValueError(f"Private inference for {dataset} must contain name and batch")

    feature_cols = [c for c in train.columns if c not in {"name", "batch", "label"}]
    missing = [c for c in feature_cols if c not in private_inference.columns]
    if missing:
        raise ValueError(f"Private inference for {dataset} is missing {len(missing)} feature columns")

    y_train = train["label"].astype(str)
    non_pool = y_train.str.lower() != "pool"

    X_train = _clean_features(train.loc[non_pool], feature_cols)
    y_train = y_train.loc[non_pool].reset_index(drop=True)
    batches_train = train.loc[non_pool, "batch"].astype(str).reset_index(drop=True)

    X_test = _clean_features(private_inference, feature_cols)
    batches_test = private_inference["batch"].astype(str).reset_index(drop=True)
    test_names = private_inference["name"].astype(str).reset_index(drop=True)

    if len(test_names) != len(private_labels):
        raise ValueError(
            f"Private inference rows ({len(test_names)}) and private labels ({len(private_labels)}) do not match"
        )

    return X_train, y_train, batches_train, X_test, batches_test, test_names.to_frame(name="name")


def _apply_user_batch_correction(
    correction_code: str,
    X_train: pd.DataFrame,
    batches_train: pd.Series,
    X_test: pd.DataFrame,
    batches_test: pd.Series,
    plot_capture: PlotCapture | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not correction_code.strip():
        return X_train.copy(), X_test.copy()

    env = _base_exec_env(plot_capture)
    env = _exec_user_code(correction_code, "batch-correction", env)
    batch_correct = env.get("batch_correct")
    if not callable(batch_correct):
        raise CodeValidationError(
            "Batch-correction code must define a callable function: "
            "batch_correct(X_train, train_batches, X_test, test_batches)."
        )

    corrected = batch_correct(
        X_train.copy(),
        batches_train.copy(),
        X_test.copy(),
        batches_test.copy(),
    )

    if not isinstance(corrected, (tuple, list)) or len(corrected) != 2:
        raise CodeValidationError("batch_correct must return exactly two values: X_train_corr, X_test_corr")

    X_train_corr = pd.DataFrame(corrected[0]).replace([np.inf, -np.inf], np.nan).fillna(0)
    X_test_corr = pd.DataFrame(corrected[1]).replace([np.inf, -np.inf], np.nan).fillna(0)

    if X_train_corr.shape[0] != X_train.shape[0]:
        raise CodeValidationError("Corrected training data row count changed.")
    if X_test_corr.shape[0] != X_test.shape[0]:
        raise CodeValidationError("Corrected test data row count changed.")

    return X_train_corr.reset_index(drop=True), X_test_corr.reset_index(drop=True)


def _run_user_model(
    model_code: str,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    plot_capture: PlotCapture | None = None,
) -> pd.Series:
    env = _base_exec_env(plot_capture)
    env = _exec_user_code(model_code, "model", env)

    fit_predict = env.get("fit_predict")
    if callable(fit_predict):
        preds = fit_predict(X_train.copy(), y_train.copy(), X_test.copy())
        out = pd.Series(preds).astype(str).reset_index(drop=True)
        if len(out) != len(X_test):
            raise CodeValidationError("fit_predict output length does not match test set rows.")
        return out

    build_model = env.get("build_model")
    if callable(build_model):
        model = build_model()
        if model is None:
            raise CodeValidationError("build_model returned None.")
        if not hasattr(model, "fit"):
            raise CodeValidationError("Model returned by build_model must define fit().")
        if not hasattr(model, "predict"):
            raise CodeValidationError("Model returned by build_model must define predict().")

        model.fit(X_train.copy(), y_train.copy())
        preds = model.predict(X_test.copy())
        out = pd.Series(preds).astype(str).reset_index(drop=True)
        if len(out) != len(X_test):
            raise CodeValidationError("Model predict() output length does not match test set rows.")
        return out

    raise CodeValidationError(
        "Model code must define either fit_predict(X_train, y_train, X_test) or build_model()."
    )


def run_code_submission(
    team: str,
    model_name: str,
    dataset: str,
    correction_code: str,
    model_code: str,
) -> tuple[pd.DataFrame, dict[str, float | int], str, str]:
    """
    Run code submission and capture visualizations.
    
    Returns:
        - predictions: DataFrame with predictions
        - metrics: Evaluation metrics
        - plot_html: HTML display of plots (shown publicly)
        - plots_json: JSON serialized plots (stored privately in database, used when displaying)
    """
    plot_capture = PlotCapture()
    
    X_train, y_train, batches_train, X_test, batches_test, test_meta = _load_data_for_dataset(dataset)
    X_train_corr, X_test_corr = _apply_user_batch_correction(
        correction_code,
        X_train,
        batches_train,
        X_test,
        batches_test,
        plot_capture,
    )
    preds = _run_user_model(model_code, X_train_corr, y_train, X_test_corr, plot_capture)

    pred_df = pd.DataFrame({"name": test_meta["name"], "prediction": preds.astype(str)})
    reference = load_private_labels(dataset)
    metrics = evaluate_predictions(pred_df, reference)
    
    plot_html = plot_capture.to_html()
    plots_json = plot_capture.to_json()
    
    return pred_df, metrics, plot_html, plots_json


def load_code_leaderboard(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        _empty_code_board().to_csv(p, index=False)
    return pd.read_csv(p)


def save_code_leaderboard(df: pd.DataFrame, path: str | Path) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(p, index=False)


def append_code_result(
    board: pd.DataFrame,
    team: str,
    model_name: str,
    dataset: str,
    metrics: dict[str, float | int],
    correction_code: str = "",
    model_code: str = "",
    public: bool = False,
) -> pd.DataFrame:
    row = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "team": team,
        "model": model_name,
        "dataset": dataset,
        "track": "real_code",
        "accuracy": round(float(metrics["accuracy"]), 4),
        "macro_f1": round(float(metrics["macro_f1"]), 4),
        "n_samples": int(metrics["n_samples"]),
        "correction_code": correction_code,
        "model_code": model_code,
        "public": int(public),
    }
    out = pd.concat([board, pd.DataFrame([row])], ignore_index=True)
    return sorted_board(out)


def _empty_code_board() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "timestamp",
            "team",
            "model",
            "dataset",
            "track",
            "accuracy",
            "macro_f1",
            "n_samples",
            "correction_code",
            "model_code",
            "public",
        ]
    )
