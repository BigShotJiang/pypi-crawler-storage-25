from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, matthews_corrcoef


DATASETS = [
    "massbench_adenocarcinoma",
    "massbench_alzheimer",
    "massbench_benchmark",
]


def evaluate_predictions(
    predictions: pd.DataFrame,
    reference: pd.DataFrame,
) -> dict[str, float | int]:
    """Score predictions against private reference labels.

    Args:
        predictions: DataFrame with columns [name, prediction] from user.
        reference:   DataFrame with columns [name, prediction] — ground truth.
    Returns:
        Dict with mcc (primary), accuracy, macro_f1, n_samples.
    """
    merged = reference.merge(
        predictions.rename(columns={"prediction": "pred_user"}),
        on="name",
        how="left",
    )

    missing = int(merged["pred_user"].isna().sum())
    if missing:
        raise ValueError(
            f"Submission is missing predictions for {missing} sample(s)."
        )

    extra = len(predictions) - len(reference)
    if extra > 0:
        raise ValueError(
            f"Submission contains {extra} extra sample name(s) not in the reference."
        )

    y_true = merged["prediction"].astype(str)
    y_pred = merged["pred_user"].astype(str)

    return {
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro")),
        "n_samples": int(len(merged)),
    }


def sorted_board(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    
    # Handle sorting by MCC if available, otherwise by macro_f1 for backward compatibility
    if "mcc" in df.columns:
        return df.sort_values(["mcc", "accuracy"], ascending=[False, False]).reset_index(drop=True)
    elif "macro_f1" in df.columns:
        return df.sort_values(["macro_f1", "accuracy"], ascending=[False, False]).reset_index(drop=True)
    else:
        return df.sort_values("accuracy", ascending=False).reset_index(drop=True)


def append_result(
    board: pd.DataFrame,
    team: str,
    model: str,
    dataset: str,
    metrics: dict[str, float | int],
) -> pd.DataFrame:
    row = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "team": team,
        "model": model,
        "dataset": dataset,
        "mcc": round(metrics["mcc"], 4),
        "accuracy": round(metrics["accuracy"], 4),
        "macro_f1": round(metrics["macro_f1"], 4),
        "n_samples": metrics["n_samples"],
    }
    return sorted_board(pd.concat([board, pd.DataFrame([row])], ignore_index=True))
