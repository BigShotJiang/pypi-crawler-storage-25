"""Pre-built baseline examples for batch correction and model training."""

BATCH_CORRECTION_EXAMPLES = {
    "none": {
        "name": "No Correction",
        "description": "Return data unchanged (baseline)",
        "code": """def batch_correct(X_train, train_batches, X_test, test_batches):
    return X_train, X_test""",
    },
    "standard_global": {
        "name": "StandardScaler (Global)",
        "description": "Global standardization across all batches",
        "code": """def batch_correct(X_train, train_batches, X_test, test_batches):
    scaler = StandardScaler()
    X_train_corr = pd.DataFrame(
        scaler.fit_transform(X_train),
        index=X_train.index,
        columns=X_train.columns
    )
    X_test_corr = pd.DataFrame(
        scaler.transform(X_test),
        index=X_test.index,
        columns=X_test.columns
    )
    return X_train_corr, X_test_corr""",
    },
    "robust_per_batch": {
        "name": "RobustScaler (Per-Batch)",
        "description": "RobustScaler per batch (ComBat-like)",
        "code": """def batch_correct(X_train, train_batches, X_test, test_batches):
    X_train_corr = X_train.copy()
    X_test_corr = X_test.copy()
    for batch in sorted(set(train_batches)):
        mask_train = train_batches == batch
        mask_test = test_batches == batch
        scaler = RobustScaler()
        if mask_train.sum() > 0:
            X_train_corr.loc[mask_train] = scaler.fit_transform(X_train[mask_train])
        if mask_test.sum() > 0:
            X_test_corr.loc[mask_test] = scaler.transform(X_test[mask_test])
    return X_train_corr, X_test_corr""",
    },
    "minmax_per_batch": {
        "name": "MinMaxScaler (Per-Batch)",
        "description": "MinMax normalization per batch",
        "code": """def batch_correct(X_train, train_batches, X_test, test_batches):
    X_train_corr = X_train.copy()
    X_test_corr = X_test.copy()
    for batch in sorted(set(train_batches)):
        mask_train = train_batches == batch
        mask_test = test_batches == batch
        scaler = MinMaxScaler()
        if mask_train.sum() > 0:
            X_train_corr.loc[mask_train] = scaler.fit_transform(X_train[mask_train])
        if mask_test.sum() > 0:
            X_test_corr.loc[mask_test] = scaler.transform(X_test[mask_test])
    return X_train_corr, X_test_corr""",
    },
    "harmony": {
        "name": "Harmony (harmonypy)",
        "description": "Harmony batch correction using harmonypy",
        "code": """def batch_correct(X_train, train_batches, X_test, test_batches):
    import harmonypy as hm
    
    # Convert to numpy for harmony
    X_combined = np.vstack([X_train.values, X_test.values])
    batch_combined = np.hstack([train_batches.values, test_batches.values])
    
    # Create metadata for harmony
    meta_data = pd.DataFrame({
        'batch': batch_combined.astype(str)
    })
    
    # Apply Harmony correction
    harmony_out = hm.run_harmony(X_combined, meta_data, ['batch'], verbose=False)
    
    # Split corrected data back
    X_train_corr = pd.DataFrame(
        harmony_out[:len(X_train)],
        index=X_train.index,
        columns=X_train.columns
    )
    X_test_corr = pd.DataFrame(
        harmony_out[len(X_train):],
        index=X_test.index,
        columns=X_test.columns
    )
    return X_train_corr, X_test_corr""",
    },
    "pca_batch": {
        "name": "PCA-based Batch Correction",
        "description": "PCA projection per batch for correction",
        "code": """def batch_correct(X_train, train_batches, X_test, test_batches):
    n_components = min(10, X_train.shape[1] - 1)
    X_train_corr = X_train.copy()
    X_test_corr = X_test.copy()
    
    for batch in sorted(set(train_batches)):
        mask_train = train_batches == batch
        mask_test = test_batches == batch
        
        if mask_train.sum() > n_components:
            pca = PCA(n_components=n_components)
            pca.fit(X_train[mask_train])
            X_transformed = pca.transform(X_train[mask_train])
            X_train_corr.loc[mask_train] = pca.inverse_transform(X_transformed)
        
        if mask_test.sum() > 0:
            X_transformed = pca.transform(X_test[mask_test])
            X_test_corr.loc[mask_test] = pca.inverse_transform(X_transformed)
    
    return X_train_corr, X_test_corr""",
    },
    "quantile_norm": {
        "name": "Quantile Normalization (Per-Batch)",
        "description": "Quantile normalization applied per batch",
        "code": """def batch_correct(X_train, train_batches, X_test, test_batches):
    def quantile_normalize(data):
        # Compute quantiles
        sorted_data = np.sort(data, axis=0)
        mean_sorted = np.mean(sorted_data, axis=1, keepdims=True)
        ranks = np.argsort(np.argsort(data, axis=0), axis=0)
        return mean_sorted[ranks]
    
    X_train_corr = X_train.copy()
    X_test_corr = X_test.copy()
    
    for batch in sorted(set(train_batches)):
        mask_train = train_batches == batch
        mask_test = test_batches == batch
        if mask_train.sum() > 0:
            X_train_corr.loc[mask_train] = quantile_normalize(X_train[mask_train].values)
        if mask_test.sum() > 0:
            X_test_corr.loc[mask_test] = quantile_normalize(X_test[mask_test].values)
    
    return X_train_corr, X_test_corr""",
    },
}

MODEL_EXAMPLES = {
    "gaussian_nb": {
        "name": "Gaussian Naive Bayes",
        "description": "Simple probabilistic classifier",
        "code": """def fit_predict(X_train, y_train, X_test):
    clf = GaussianNB()
    clf.fit(X_train, y_train)
    return clf.predict(X_test)""",
    },
    "logistic_regression": {
        "name": "Logistic Regression",
        "description": "Linear classifier with balanced weights",
        "code": """def fit_predict(X_train, y_train, X_test):
    clf = LogisticRegression(max_iter=3000, class_weight="balanced", solver="lbfgs")
    clf.fit(X_train, y_train)
    return clf.predict(X_test)""",
    },
    "random_forest": {
        "name": "Random Forest",
        "description": "Ensemble of random decision trees",
        "code": """def fit_predict(X_train, y_train, X_test):
    clf = RandomForestClassifier(n_estimators=100, class_weight="balanced_subsample", random_state=42)
    clf.fit(X_train, y_train)
    return clf.predict(X_test)""",
    },
    "svc": {
        "name": "Support Vector Classifier",
        "description": "Non-linear SVM classifier",
        "code": """def fit_predict(X_train, y_train, X_test):
    clf = SVC(kernel='rbf', class_weight='balanced', probability=True)
    clf.fit(X_train, y_train)
    return clf.predict(X_test)""",
    },
    "knn": {
        "name": "k-Nearest Neighbors",
        "description": "k-NN classifier with k=5",
        "code": """def fit_predict(X_train, y_train, X_test):
    clf = KNeighborsClassifier(n_neighbors=5)
    clf.fit(X_train, y_train)
    return clf.predict(X_test)""",
    },
    "ridge": {
        "name": "Ridge Classifier",
        "description": "Ridge regression for classification",
        "code": """def fit_predict(X_train, y_train, X_test):
    clf = RidgeClassifier(alpha=1.0)
    clf.fit(X_train, y_train)
    return clf.predict(X_test)""",
    },
    "bernn": {
        "name": "BERNN (Batch Effect Removal Neural Network)",
        "description": "Deep learning for batch effect removal and classification",
        "code": """def fit_predict(X_train, y_train, X_test):
    if not BERNN_AVAILABLE:
        reason = BERNN_LOAD_ERROR if BERNN_LOAD_ERROR else "unknown import error"
        raise RuntimeError(f"BERNN trainers are unavailable: {reason}")

    # Select between BERNN training strategies
    trainer_name = "ae_classifier"  # or "ae_then_classifier"
    trainer_cls = TrainAEClassifierHoldout if trainer_name == "ae_classifier" else TrainAEThenClassifierHoldout

    # Use private HF CSV directly (no generated local unique_genes.csv)
    hf_csv_path = download_private_inference_file(
        "massbench_adenocarcinoma"
    )
    hf_csv_path = str(hf_csv_path).replace("\\\\", "/")
    hf_csv_name = hf_csv_path.split("/")[-1]
    hf_csv_dir = "/".join(hf_csv_path.split("/")[:-1])
    if hf_csv_dir == "":
        hf_csv_dir = "."
    # BERNN custom loader expects: name, label, batch, features...
    # Private inference is usually: name, batch, features...
    _orig_read_csv = pd.read_csv

    def _bernn_read_csv(path, *args, **kwargs):
        path_str = str(path).replace("\\\\\\\\", "/")
        df = _orig_read_csv(path, *args, **kwargs)
        if path_str.endswith("/" + hf_csv_name) or path_str == hf_csv_name:
            cols = list(df.columns)
            if "name" in cols and "batch" in cols and "label" not in cols:
                df = df.copy()
                default_label = str(pd.Series(y_train).astype(str).mode().iloc[0])
                insert_at = cols.index("batch")
                df.insert(insert_at, "label", default_label)
                front = ["name", "label", "batch"]
                rest = [c for c in df.columns if c not in front]
                df = df[front + rest]
        return df

    pd.read_csv = _bernn_read_csv


    print("=== Modern Configuration Class Approach ===")
    bernn_config = TrainingConfig(
        csv_file=hf_csv_name,
        exp_id="modern_ae_then_classifier",
        dloss="inverseTriplet",
        variational=False,
        n_epochs=1000,
        device="cpu",
        groupkfold=True,
        n_meta=0,
        embeddings_meta=0,
        n_layers=2,
        n_agg=5,
        bad_batches="",
        remove_zeros=False,
        dataset="custom",
        kan=True,
        bs=32,
        strategy="CU_DEM",
        log1p=True,
        pool=False,
        update_grid=True,
        use_l1=True,
        clip_val=1.0,
    )

    # Type-safe trainer instantiation from TrainingConfig
    trainer_modern = trainer_cls(
        config=bernn_config,
        path=hf_csv_dir,
        fix_thres=-1,
        load_tb=False,
        log_metrics=False,
        keep_models=False,
        log_inputs=False,
        log_plots=False,
        log_tb=False,
        log_neptune=False,
        log_mlflow=False,
        log_dvclive=False,
        groupkfold=True,
        pools=False,
    )
    trainer = trainer_modern
    # No fallback: run BERNN path directly

    train_params = {
        "scaler": "standard",
        "warmup": 0,
        "disc_b_warmup": 0,
        "prune_threshold": 0.0,
        "dropout": 0.0,
        "lr": 1e-3,
        "wd": 0.0,
        "margin": 1.0,
        "nu": 0.1,
        "smoothing": 0.0,
        "layer1": 256,
        "layer2": 128,
        "gamma": 0.0,
        "beta": 0.0,
        "zeta": 0.0,
        "l1": 0.0,
        "reg_entropy": 0.0,
        "thres": 0.0,
    }
    # Work around BERNN split edge-cases where empty idx arrays become non-integer dtype
    _orig_make_samples_weights = trainer.make_samples_weights

    def _safe_make_samples_weights():
        try:
            return _orig_make_samples_weights()
        except Exception as exc:
            err_msg = str(exc)
            if "arrays used as indices" not in err_msg and "After filtering, no samples remain for group" not in err_msg:
                raise

            for group in ["train", "valid", "test"]:
                labels = np.array(trainer.data["labels"][group], dtype=object)
                keep = np.array([i for i, x in enumerate(labels) if x in trainer.unique_labels], dtype=int)
                if keep.size == 0:
                    keep = np.arange(len(labels), dtype=int)

                trainer.data["inputs"][group] = trainer.data["inputs"][group].iloc[keep]
                try:
                    trainer.data["names"][group] = trainer.data["names"][group].iloc[keep]
                except Exception:
                    trainer.data["names"][group] = np.array(trainer.data["names"][group])[keep]
                trainer.data["labels"][group] = np.array(trainer.data["labels"][group], dtype=object)[keep]
                trainer.data["cats"][group] = np.array(trainer.data["cats"][group], dtype=object)[keep]
                trainer.data["batches"][group] = np.array(trainer.data["batches"][group], dtype=object)[keep]

            return None

    trainer.make_samples_weights = _safe_make_samples_weights
    trainer.train(train_params)

    pd.read_csv = _orig_read_csv
    # Expose predictions if trainer produced them (no getattr: sandbox forbids it)
    if hasattr(trainer, "predictions"):
        return pd.Series(trainer.predictions).astype(str).reset_index(drop=True)
    if hasattr(trainer, "preds"):
        return pd.Series(trainer.preds).astype(str).reset_index(drop=True)
    if hasattr(trainer, "y_pred"):
        return pd.Series(trainer.y_pred).astype(str).reset_index(drop=True)
    if hasattr(trainer, "test_predictions"):
        return pd.Series(trainer.test_predictions).astype(str).reset_index(drop=True)

    raise RuntimeError("BERNN trainer ran but produced no accessible test predictions.")""",
    },
}

def get_baseline_text() -> str:
    """Return formatted text listing all available libraries and baselines."""
    return """
**Available Pre-Built Baselines:**

**Batch Correction Examples:**
- none: No correction (baseline)
- standard_global: Global StandardScaler
- robust_per_batch: RobustScaler per batch (ComBat-like)
- minmax_per_batch: MinMax per batch
- harmony: Harmony (harmonypy) — R-like batch correction
- pca_batch: PCA-based per-batch correction
- quantile_norm: Quantile normalization

**Model Examples:**
- gaussian_nb: Gaussian Naive Bayes
- logistic_regression: Logistic Regression
- random_forest: Random Forest
- svc: Support Vector Classifier
- knn: k-Nearest Neighbors
- ridge: Ridge Classifier
- bernn: BERNN (Batch Effect Removal Neural Network)

**Fully Preloaded Libraries:**
- **Fundamentals**: numpy, scipy, pandas
- **ML**: scikit-learn, imbalanced-learn, shap, statsmodels
- **Dimensionality Reduction**: PCA, umap
- **Visualization**: matplotlib (plt), seaborn (sns), plotly (go, px)
- **Batch Correction**: scanpy (sc), harmonypy
- **Boosting**: xgboost, lightgbm, catboost
- **Deep Learning**: torch, tensorflow, jax/jaxlib
- **Hyperparameter Opt**: optuna, ax-platform
- **Neural Network Batch Correction (if installed)**: TrainAEClassifierHoldout, TrainAEThenClassifierHoldout
- **Utilities**: networkx

**Capture Plots:**
After creating a matplotlib plot, call: `plot_capture.add_plot("Title")` to display it

**Example: PCA Visualization**
```python
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_train_corr)
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y_train, alpha=0.6)
plt.title('PCA of Corrected Data')
plot_capture.add_plot('PCA')
```

**Example: UMAP Visualization**
```python
reducer = umap.UMAP(n_components=2)
X_umap = reducer.fit_transform(X_train_corr)
plt.scatter(X_umap[:, 0], X_umap[:, 1], c=y_train, alpha=0.6)
plt.title('UMAP of Corrected Data')
plot_capture.add_plot('UMAP')
```

**Advanced: BERNN (if installed)**
If bernn is available, you can use TrainAEClassifierHoldout or TrainAEThenClassifierHoldout with rich parameters:
```python
def fit_predict(X_train, y_train, X_test):
    trainer = TrainAEClassifierHoldout(
        config=None,
        path="./data",
        fix_thres=-1,
        load_tb=False,
        log_metrics=False,
        keep_models=False,
        groupkfold=True,
    )
    train_params = {
        "scaler": "standard",
        "warmup": 0,
        "disc_b_warmup": 0,
        "prune_threshold": 0.0,
        "dropout": 0.0,
        "lr": 1e-3,
        "wd": 0.0,
        "margin": 1.0,
        "nu": 0.1,
        "smoothing": 0.0,
        "layer1": 256,
        "layer2": 128,
        "gamma": 0.0,
        "beta": 0.0,
        "zeta": 0.0,
        "l1": 0.0,
        "reg_entropy": 0.0,
        "thres": 0.0,
    }
    trainer.train(train_params)
    if hasattr(trainer, "predictions"):
        return pd.Series(trainer.predictions).astype(str).reset_index(drop=True)
    if hasattr(trainer, "preds"):
        return pd.Series(trainer.preds).astype(str).reset_index(drop=True)
    if hasattr(trainer, "y_pred"):
        return pd.Series(trainer.y_pred).astype(str).reset_index(drop=True)
    if hasattr(trainer, "test_predictions"):
        return pd.Series(trainer.test_predictions).astype(str).reset_index(drop=True)
    raise RuntimeError("BERNN trainer ran but produced no accessible test predictions.")
```
"""
