from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
from huggingface_hub import HfApi, hf_hub_download


PRIVATE_LABELS_DATASET = os.getenv(
    "HF_PRIVATE_LABELS_DATASET", "spell0/massbench-private-labels"
)
RESULTS_DATASET = os.getenv("HF_RESULTS_DATASET", "")
RESULTS_FILE = os.getenv("HF_RESULTS_FILE", "leaderboard.csv")


def _token() -> str | None:
    return os.getenv("HF_TOKEN")


def download_private_inference_file(dataset_name: str, filename: str | None = None) -> str:
    """Download a private inference CSV and return its local cached path.

    If *filename* is provided, it is used directly.
    Otherwise tries dataset-specific defaults in order.
    """
    token = _token()
    if not token:
        raise EnvironmentError(
            "HF_TOKEN is not set. The evaluator cannot access private inference data."
        )

    candidates = []
    if filename:
        candidates.append(filename)

    # Always include standard dataset-based names as fallbacks for repo naming differences.
    candidates.extend(
        [
            f"{dataset_name}_test.csv",
            f"{dataset_name}_inference.csv",
        ]
    )

    # Keep order while removing duplicates.
    deduped = []
    for c in candidates:
        if c not in deduped:
            deduped.append(c)
    candidates = deduped

    last_exc: Exception | None = None
    for candidate in candidates:
        try:
            return hf_hub_download(
                repo_id=PRIVATE_LABELS_DATASET,
                filename=candidate,
                repo_type="dataset",
                token=token,
            )
        except Exception as exc:
            last_exc = exc

    raise FileNotFoundError(
        f"Could not download private inference file for {dataset_name}. "
        f"Tried: {', '.join(candidates)}. Last error: {last_exc}"
    )


def load_private_labels(dataset_name: str) -> pd.DataFrame:
    """Download the private ground truth labels for *dataset_name* from the
    private HF dataset.  Returns DataFrame with columns [name, prediction]."""
    filename = f"{dataset_name}_predictions.csv"
    token = _token()
    if not token:
        raise EnvironmentError(
            "HF_TOKEN is not set. The evaluator cannot access private labels."
        )
    path = hf_hub_download(
        repo_id=PRIVATE_LABELS_DATASET,
        filename=filename,
        repo_type="dataset",
        token=token,
    )
    df = pd.read_csv(path)
    df["name"] = df["name"].astype(str)
    df["prediction"] = df["prediction"].astype(str)
    return df


def load_private_inference(dataset_name: str) -> pd.DataFrame:
    """Download the private inference matrix for *dataset_name*.

    Tries {dataset_name}_test.csv then {dataset_name}_inference.csv.
    """
    path = download_private_inference_file(dataset_name)
    df = pd.read_csv(path)
    if "name" in df.columns:
        df["name"] = df["name"].astype(str)
    if "batch" in df.columns:
        df["batch"] = df["batch"].astype(str)
    return df


def load_leaderboard(local_fallback: str | Path) -> pd.DataFrame:
    """Return leaderboard DataFrame, pulling from Hub dataset when configured."""
    fallback = Path(local_fallback)
    _ensure_leaderboard_file(fallback)

    if not RESULTS_DATASET:
        return pd.read_csv(fallback)

    token = _token()
    try:
        path = hf_hub_download(
            repo_id=RESULTS_DATASET,
            filename=RESULTS_FILE,
            repo_type="dataset",
            token=token,
        )
        return pd.read_csv(path)
    except Exception:
        return pd.read_csv(fallback)


def save_leaderboard(df: pd.DataFrame, local_path: str | Path) -> None:
    """Persist leaderboard locally and optionally push to Hub dataset."""
    path = Path(local_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)

    if not RESULTS_DATASET:
        return
    token = _token()
    if not token:
        return
    api = HfApi(token=token)
    api.upload_file(
        path_or_fileobj=str(path),
        path_in_repo=RESULTS_FILE,
        repo_id=RESULTS_DATASET,
        repo_type="dataset",
        commit_message="Update leaderboard results",
    )


def _ensure_leaderboard_file(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        _empty_leaderboard().to_csv(path, index=False)


def _empty_leaderboard() -> pd.DataFrame:
    return pd.DataFrame(
        columns=["timestamp", "team", "model", "dataset", "accuracy", "macro_f1", "n_samples"]
    )
