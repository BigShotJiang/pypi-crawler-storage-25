"""Database layer for user management, submissions, and version tracking."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from sqlalchemy import Column, Float, Integer, String, Text, DateTime, Boolean, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session, sessionmaker

Base = declarative_base()

PROJECT_VERSION = "1.0.0"


class User(Base):
    """User account."""

    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(255), unique=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.now(timezone.utc), nullable=False)

    def __repr__(self) -> str:
        return f"<User {self.username}>"


class Submission(Base):
    """Code submission for real leaderboard."""

    __tablename__ = "submissions"

    id = Column(Integer, primary_key=True)
    username = Column(String(255), nullable=False, index=True)
    dataset = Column(String(255), nullable=False, index=True)
    submission_name = Column(String(255), nullable=False)
    correction_code = Column(Text, nullable=False)
    model_code = Column(Text, nullable=False)
    is_public = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.now(timezone.utc), nullable=False, index=True)
    version_created = Column(String(32), default=PROJECT_VERSION, nullable=False)

    def __repr__(self) -> str:
        return f"<Submission {self.id} by {self.username} on {self.dataset}>"


class Score(Base):
    """Evaluation score for a submission."""

    __tablename__ = "scores"

    id = Column(Integer, primary_key=True)
    submission_id = Column(Integer, nullable=False, index=True)
    mcc = Column(Float, nullable=True, default=0.0)  # Matthews Correlation Coefficient (primary metric)
    accuracy = Column(Float, nullable=False)
    macro_f1 = Column(Float, nullable=False)
    n_samples = Column(Integer, nullable=False)
    version_evaluated = Column(String(32), default=PROJECT_VERSION, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.now(timezone.utc), nullable=False)
    needs_recalc = Column(Boolean, default=False, nullable=False)
    plots_json = Column(Text, nullable=True, default="")  # Store visualization plots

    def __repr__(self) -> str:
        return f"<Score sub_id={self.submission_id} mcc={self.mcc:.4f} v{self.version_evaluated}>"


class VersionHistory(Base):
    """Track version changes and evaluation metadata."""

    __tablename__ = "version_history"

    id = Column(Integer, primary_key=True)
    version = Column(String(32), nullable=False, unique=True, index=True)
    released_at = Column(DateTime, default=datetime.now(timezone.utc), nullable=False)
    major_version_bump = Column(Boolean, default=False, nullable=False)
    notes = Column(Text, nullable=True)

    def __repr__(self) -> str:
        return f"<VersionHistory v{self.version}>"


class DatabaseManager:
    """Manage database connections and operations."""

    def __init__(self, db_path: str | Path = "data/leaderboard.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine(f"sqlite:///{self.db_path}", echo=False)
        Base.metadata.create_all(self.engine)
        self.SessionLocal = sessionmaker(bind=self.engine)

    def get_session(self) -> Session:
        return self.SessionLocal()

    def get_or_create_user(self, username: str) -> User:
        session = self.get_session()
        user = session.query(User).filter_by(username=username).first()
        if not user:
            user = User(username=username)
            session.add(user)
            session.commit()
        session.close()
        return user

    def create_submission(
        self,
        username: str,
        dataset: str,
        submission_name: str,
        correction_code: str,
        model_code: str,
        is_public: bool = False,
    ) -> Submission:
        session = self.get_session()
        self.get_or_create_user(username)
        submission = Submission(
            username=username,
            dataset=dataset,
            submission_name=submission_name,
            correction_code=correction_code,
            model_code=model_code,
            is_public=is_public,
            version_created=PROJECT_VERSION,
        )
        session.add(submission)
        session.commit()
        sub_id = submission.id
        session.close()
        return submission

    def create_score(
        self,
        submission_id: int,
        accuracy: float,
        macro_f1: float,
        n_samples: int,
        mcc: float = 0.0,
        version: str | None = None,
        plots_json: str = "",
    ) -> Score:
        session = self.get_session()
        score = Score(
            submission_id=submission_id,
            mcc=float(mcc),
            accuracy=float(accuracy),
            macro_f1=float(macro_f1),
            n_samples=int(n_samples),
            version_evaluated=version or PROJECT_VERSION,
            needs_recalc=False,
            plots_json=plots_json,
        )
        session.add(score)
        session.commit()
        score_id = score.id
        session.close()
        return score

    def get_latest_score(self, submission_id: int) -> Optional[Score]:
        session = self.get_session()
        score = (
            session.query(Score)
            .filter_by(submission_id=submission_id)
            .order_by(Score.created_at.desc())
            .first()
        )
        session.close()
        return score

    def get_submissions_for_user(self, username: str) -> list[Submission]:
        session = self.get_session()
        submissions = session.query(Submission).filter_by(username=username).all()
        session.close()
        return submissions

    def get_public_submissions(self, dataset: str | None = None) -> list[Submission]:
        session = self.get_session()
        query = session.query(Submission).filter_by(is_public=True)
        if dataset:
            query = query.filter_by(dataset=dataset)
        submissions = query.all()
        session.close()
        return submissions

    def get_submission_by_id(self, submission_id: int) -> Optional[Submission]:
        session = self.get_session()
        submission = session.query(Submission).filter_by(id=submission_id).first()
        session.close()
        return submission

    def get_leaderboard(self, dataset: str | None = None) -> list[dict]:
        """Get leaderboard with latest scores, sorted by MCC (Matthews Correlation Coefficient)."""
        session = self.get_session()
        query = session.query(Submission, Score).join(
            Score, Submission.id == Score.submission_id
        )
        if dataset:
            query = query.filter(Submission.dataset == dataset)

        query = query.order_by(Score.mcc.desc(), Score.accuracy.desc())
        results = query.all()

        leaderboard = []
        for sub, score in results:
            leaderboard.append(
                {
                    "submission_id": sub.id,
                    "username": sub.username,
                    "dataset": sub.dataset,
                    "submission_name": sub.submission_name,
                    "mcc": score.mcc,
                    "accuracy": score.accuracy,
                    "macro_f1": score.macro_f1,
                    "n_samples": score.n_samples,
                    "created_at": sub.created_at.isoformat(),
                    "version_created": sub.version_created,
                    "version_evaluated": score.version_evaluated,
                    "is_public": sub.is_public,
                    "correction_code": sub.correction_code,
                    "model_code": sub.model_code,
                    "plots_json": score.plots_json,  # Visualization data (private storage)
                }
            )
        session.close()
        return leaderboard

    def mark_for_recalculation(self, old_version: str) -> int:
        """Mark all scores from a previous version for recalculation."""
        session = self.get_session()
        count = (
            session.query(Score)
            .filter(Score.version_evaluated == old_version)
            .update({"needs_recalc": True})
        )
        session.commit()
        session.close()
        return count

    def get_submissions_needing_recalc(self) -> list[int]:
        """Get all submission IDs that need score recalculation."""
        session = self.get_session()
        submissions = session.query(Score.submission_id).filter(Score.needs_recalc == True).distinct().all()
        session.close()
        return [s[0] for s in submissions]

    def record_version(self, version: str, is_major: bool = False, notes: str = "") -> VersionHistory:
        """Record a version release."""
        session = self.get_session()
        vh = VersionHistory(
            version=version,
            major_version_bump=is_major,
            notes=notes,
        )
        session.add(vh)
        session.commit()
        session.close()
        return vh

    def get_current_version(self) -> str:
        """Get the current project version."""
        return PROJECT_VERSION
