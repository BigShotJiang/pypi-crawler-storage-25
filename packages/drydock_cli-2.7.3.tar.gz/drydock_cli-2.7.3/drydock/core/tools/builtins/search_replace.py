from __future__ import annotations

from collections.abc import AsyncGenerator
import difflib
from pathlib import Path
import re
import shutil
from typing import ClassVar, NamedTuple, final

import anyio
from pydantic import BaseModel, Field

from drydock.core.tools.base import (
    BaseTool,
    BaseToolConfig,
    BaseToolState,
    InvokeContext,
    ToolError,
    ToolPermission,
)
from drydock.core.tools.ui import ToolCallDisplay, ToolResultDisplay, ToolUIData
from drydock.core.tools.utils import resolve_file_tool_permission
from drydock.core.types import ToolResultEvent, ToolStreamEvent

SEARCH_REPLACE_BLOCK_RE = re.compile(
    r"<{5,}\s*(?:SEARCH\s*)+\r?\n(.*?)\r?\n?={5,}\r?\n(.*?)\r?\n?>{5,}\s*(?:REPLACE\s*)+",
    flags=re.DOTALL,
)

SEARCH_REPLACE_BLOCK_WITH_FENCE_RE = re.compile(
    r"```[\s\S]*?\n<{5,}\s*(?:SEARCH\s*)+\r?\n(.*?)\r?\n?={5,}\r?\n(.*?)\r?\n?>{5,}\s*(?:REPLACE\s*)+\s*\n```",
    flags=re.DOTALL,
)


class SearchReplaceBlock(NamedTuple):
    search: str
    replace: str


class FuzzyMatch(NamedTuple):
    similarity: float
    start_line: int
    end_line: int
    text: str


class BlockApplyResult(NamedTuple):
    content: str
    applied: int
    errors: list[str]
    warnings: list[str]


class SearchReplaceArgs(BaseModel):
    file_path: str = Field(default="", description="Path to the file to edit")
    content: str = Field(default="", description="SEARCH/REPLACE blocks or JSON with old_string/new_string")
    # Gemma 4 sometimes sends these directly instead of in content
    old_string: str | None = Field(default=None, description="Text to find (alternative to content blocks)")
    new_string: str | None = Field(default=None, description="Replacement text (alternative to content blocks)")


class SearchReplaceResult(BaseModel):
    file: str
    blocks_applied: int
    lines_changed: int
    content: str
    warnings: list[str] = Field(default_factory=list)


class SearchReplaceConfig(BaseToolConfig):
    max_content_size: int = 100_000
    create_backup: bool = False
    fuzzy_threshold: float = 0.9


class SearchReplace(
    BaseTool[
        SearchReplaceArgs, SearchReplaceResult, SearchReplaceConfig, BaseToolState
    ],
    ToolUIData[SearchReplaceArgs, SearchReplaceResult],
):
    description: ClassVar[str] = (
        "Replace sections of files using SEARCH/REPLACE blocks. "
        "Supports fuzzy matching and detailed error reporting. "
        "Format: <<<<<<< SEARCH\\n[text]\\n=======\\n[replacement]\\n>>>>>>> REPLACE"
    )

    @classmethod
    def format_call_display(cls, args: SearchReplaceArgs) -> ToolCallDisplay:
        blocks = cls._parse_search_replace_blocks(args.content)
        return ToolCallDisplay(
            summary=f"Patching {args.file_path} ({len(blocks)} blocks)",
            content=args.content,
        )

    @classmethod
    def get_result_display(cls, event: ToolResultEvent) -> ToolResultDisplay:
        if isinstance(event.result, SearchReplaceResult):
            return ToolResultDisplay(
                success=True,
                message=f"Applied {event.result.blocks_applied} block{'' if event.result.blocks_applied == 1 else 's'}",
                warnings=event.result.warnings,
            )

        return ToolResultDisplay(success=True, message="Patch applied")

    @classmethod
    def get_status_text(cls) -> str:
        return "Editing files"

    def resolve_permission(self, args: SearchReplaceArgs) -> ToolPermission | None:
        return resolve_file_tool_permission(
            args.file_path,
            allowlist=self.config.allowlist,
            denylist=self.config.denylist,
            config_permission=self.config.permission,
        )

    @final
    async def run(
        self, args: SearchReplaceArgs, ctx: InvokeContext | None = None
    ) -> AsyncGenerator[ToolStreamEvent | SearchReplaceResult, None]:
        try:
            file_path, search_replace_blocks = self._prepare_and_validate_args(args)
        except ToolError as e:
            err_msg = str(e)
            if err_msg.startswith("NO_BLOCKS:"):
                # Gemma 4 sent raw code without SEARCH/REPLACE markers.
                # CAREFULLY fall back to full file overwrite — but refuse if
                # the raw content is much shorter than the existing file
                # (would be catastrophic data loss). See CLAUDE.md learning
                # #39: drydock nuked a 5171-char cli.py with a 16-line fragment.
                raw_content = err_msg[len("NO_BLOCKS:"):]
                file_path_str = args.file_path.strip()
                if file_path_str and len(raw_content) > 20:
                    target = Path(file_path_str).expanduser()
                    if not target.is_absolute():
                        target = Path.cwd() / target
                    target = target.resolve()
                    if target.exists():
                        import logging as _log
                        existing_size = target.stat().st_size
                        # SAFETY CHECK: refuse to shrink a file by >50% via the
                        # raw-code fallback. The model almost certainly intended
                        # a partial patch, not a full replace, if the new content
                        # is dramatically shorter.
                        if existing_size > 500 and len(raw_content) < existing_size * 0.5:
                            _log.getLogger(__name__).warning(
                                "search_replace: REFUSING destructive overwrite of %s "
                                "(existing=%d chars, new=%d chars, would shrink by %d%%)",
                                target, existing_size, len(raw_content),
                                100 - int(len(raw_content) * 100 / existing_size),
                            )
                            raise ToolError(
                                f"REFUSED: the raw content you sent ({len(raw_content)} "
                                f"chars) is much shorter than the existing {target.name} "
                                f"({existing_size} chars). This would destroy most of "
                                f"the file. If you intended a small patch, use proper "
                                f"SEARCH/REPLACE blocks:\n"
                                f"<<<<<<< SEARCH\n"
                                f"[exact existing text to replace]\n"
                                f"=======\n"
                                f"[new text]\n"
                                f">>>>>>> REPLACE\n"
                                f"If you intended a full rewrite, use write_file instead."
                            )
                        _log.getLogger(__name__).info(
                            "search_replace: no blocks — overwriting %s", target,
                        )
                        await self._write_file(target, raw_content)
                        yield SearchReplaceResult(
                            file=str(target),
                            blocks_applied=1,
                            lines_changed=0,
                            warnings=["Wrote entire file (no SEARCH/REPLACE blocks). "
                                      "Use write_file next time."],
                            content=raw_content[:100] + "...",
                        )
                        return
            raise

        # Read-before-Edit enforcement (Claude Code tool contract).
        # Editing a file without having seen it is the #1 cause of the
        # "SEARCH text not found" failure cascade. Require the model to
        # have read this path (or just written it) this session.
        # Structured rejection (not ToolError) — model sees guidance in
        # the result content and pivots to read_file.
        read_state = ctx.read_file_state if ctx else None
        path_key = str(file_path)
        if read_state is not None and file_path.exists():
            prior = read_state.get(path_key)
            if prior is None:
                yield SearchReplaceResult(
                    file=path_key,
                    blocks_applied=0,
                    lines_changed=0,
                    warnings=[],
                    content=(
                        "<system-reminder>\n"
                        f"{file_path.name} has not been read this session. "
                        "Use read_file first so you can see the current "
                        "contents — then search_replace with the actual "
                        "text from the file. This edit was NOT applied.\n"
                        "</system-reminder>"
                    ),
                )
                return
            try:
                current_mtime = file_path.stat().st_mtime_ns
            except OSError:
                current_mtime = 0
            if prior.get("timestamp") and current_mtime and current_mtime > prior["timestamp"]:
                yield SearchReplaceResult(
                    file=path_key,
                    blocks_applied=0,
                    lines_changed=0,
                    warnings=[],
                    content=(
                        "<system-reminder>\n"
                        f"{file_path.name} was modified on disk since your "
                        "last read. Re-read before editing to avoid "
                        "clobbering changes you haven't seen. This edit "
                        "was NOT applied.\n"
                        "</system-reminder>"
                    ),
                )
                return

        # Injection guard: scan replacement content for suspicious patterns
        from drydock.core.tools.injection_guard import check_content_for_injection
        if warning := check_content_for_injection(args.content, args.file_path):
            import logging
            logging.getLogger(__name__).warning("search_replace: %s", warning)

        original_content = await self._read_file(file_path)

        # Detect placeholder/omission patterns that would delete code
        PLACEHOLDER_PATTERNS = [
            "# rest of code", "# ... rest", "# unchanged",
            "// rest of code", "// ... rest", "// unchanged",
            "# TODO: implement", "pass  # placeholder",
            "...",  # bare ellipsis as entire replacement
        ]
        for block in search_replace_blocks:
            replacement = block.replace.strip()
            if replacement in PLACEHOLDER_PATTERNS or any(
                p in replacement.lower() for p in [
                    "rest of code", "rest of the code", "unchanged",
                    "remaining code", "code continues", "etc.",
                ]
            ):
                raise ToolError(
                    f"Your replacement contains a placeholder ('{replacement[:50]}') "
                    f"that would delete existing code. Provide the COMPLETE replacement "
                    f"code, not a summary. If the code is unchanged, don't edit it."
                )

        block_result = self._apply_blocks(
            original_content,
            search_replace_blocks,
            file_path,
            self.config.fuzzy_threshold,
        )

        if block_result.errors:
            error_message = "SEARCH/REPLACE blocks failed:\n" + "\n\n".join(
                block_result.errors
            )
            if block_result.warnings:
                error_message += "\n\nWarnings encountered:\n" + "\n".join(
                    block_result.warnings
                )

            # Mechanical loop-breaker: if search_replace has failed with
            # "Search text not found" on the SAME file 2+ times in a row,
            # embed the current file head in the error so the model sees
            # actual file state and can't keep retrying phantom edits.
            # (One session had 8 consecutive identical search_replace
            # failures with 0 behavior change. Nudges didn't help.)
            state = self.state.__dict__.setdefault("_sr_fail_history", {})
            fail_key = str(file_path)
            entry = state.get(fail_key, {"count": 0})
            entry["count"] += 1
            state[fail_key] = entry
            if entry["count"] >= 2:
                try:
                    head = original_content[:2000]
                    line_count = original_content.count("\n")
                    error_message += (
                        f"\n\n[LOOP-BREAKER: this is the #{entry['count']} "
                        f"consecutive search_replace failure on "
                        f"{file_path.name}. Stop retrying the same search. "
                        f"Actual file content (first 2000 chars of "
                        f"{line_count} lines):\n"
                        f"-----FILE START-----\n{head}\n-----FILE END-----\n"
                        f"Use THIS exact text as your search target, OR "
                        f"abandon this edit and try write_file.]"
                    )
                except Exception:
                    pass

            raise ToolError(error_message)
        else:
            # Success → reset the fail counter for this file
            state = self.state.__dict__.setdefault("_sr_fail_history", {})
            state.pop(str(file_path), None)

        modified_content = block_result.content

        # Calculate line changes
        if modified_content == original_content:
            lines_changed = 0
        else:
            original_lines = len(original_content.splitlines())
            new_lines = len(modified_content.splitlines())
            lines_changed = new_lines - original_lines

            try:
                if self.config.create_backup:
                    await self._backup_file(file_path)
            except Exception:
                pass

            await self._write_file(file_path, modified_content)

            # Update read_file_state so chained edits don't trip Read-
            # before-Edit. We just wrote — we know disk state.
            if read_state is not None:
                try:
                    new_mtime = file_path.stat().st_mtime_ns
                except OSError:
                    new_mtime = 0
                read_state[path_key] = {
                    "content": modified_content,
                    "timestamp": new_mtime,
                    "offset": 0,
                    "limit": None,
                }

            # Auto-verify syntax for Python files
            if file_path.suffix == ".py":
                try:
                    import ast
                    ast.parse(modified_content)
                except SyntaxError as e:
                    block_result.warnings.append(
                        f"⚠ SYNTAX ERROR after edit at line {e.lineno}: {e.msg}. "
                        f"Fix this before continuing."
                    )

        # Terse success content (Claude Code pattern) — don't echo the
        # SEARCH/REPLACE payload back. Model already has it in history;
        # echoing wastes context and tempts re-reading. Warnings still go
        # through so the model sees actionable issues.
        yield SearchReplaceResult(
            file=str(file_path),
            blocks_applied=block_result.applied,
            lines_changed=lines_changed,
            warnings=block_result.warnings,
            content=(
                f"{file_path.name} edited successfully "
                f"({block_result.applied} block(s), "
                f"{lines_changed:+d} line(s))."
            ),
        )

    @final
    def _prepare_and_validate_args(
        self, args: SearchReplaceArgs
    ) -> tuple[Path, list[SearchReplaceBlock]]:
        file_path_str = args.file_path.strip()
        content = args.content.strip()

        # Handle direct old_string/new_string args (Gemma 4 sometimes sends these)
        if not content and args.old_string is not None and args.new_string is not None:
            content = f"<<<<<<< SEARCH\n{args.old_string}\n=======\n{args.new_string}\n>>>>>>> REPLACE"

        # Try to extract file_path from content if missing
        if not file_path_str and content:
            # Look for file path in the content (common when model puts everything in content)
            path_match = re.search(r'(?:file[_\s]?path|path|file)[\s:="\']+([^\s"\']+\.py)', content[:200], re.IGNORECASE)
            if path_match:
                file_path_str = path_match.group(1)

        # Last resort: if file_path is still missing but we have SEARCH text,
        # scan project files for a match.  Gemma 4 frequently drops file_path.
        # Limit scan to avoid hanging on large repos.
        if not file_path_str and content:
            blocks = self._parse_search_replace_blocks(content)
            if blocks:
                search_text = blocks[0].search.strip()
                if search_text and len(search_text) >= 10:
                    project_root = Path.cwd()
                    candidates: list[Path] = []
                    files_checked = 0
                    for ext in ("*.py",):  # Only scan Python files
                        for f in project_root.rglob(ext):
                            if files_checked > 200:
                                break
                            if "__pycache__" in str(f) or ".git" in str(f):
                                continue
                            files_checked += 1
                            try:
                                text = f.read_text(encoding="utf-8", errors="replace")
                                if len(text) > 100_000:
                                    continue
                                if search_text in text:
                                    candidates.append(f)
                            except Exception:
                                continue
                    if len(candidates) == 1:
                        file_path_str = str(candidates[0])
                    elif candidates:
                        candidates.sort(key=lambda p: len(str(p)))
                        file_path_str = str(candidates[0])

        if not file_path_str:
            raise ToolError(
                "File path is required. Use: search_replace(file_path='path/to/file.py', content='...')"
            )

        if len(content) > self.config.max_content_size:
            raise ToolError(
                f"Content size ({len(content)} bytes) exceeds max_content_size "
                f"({self.config.max_content_size} bytes)"
            )

        if not content:
            raise ToolError("Empty content provided")

        project_root = Path.cwd()
        file_path = Path(file_path_str).expanduser()
        if not file_path.is_absolute():
            file_path = project_root / file_path
        file_path = file_path.resolve()

        if not file_path.exists():
            raise ToolError(f"File does not exist: {file_path}")

        if not file_path.is_file():
            raise ToolError(f"Path is not a file: {file_path}")

        search_replace_blocks = self._parse_search_replace_blocks(content)
        if not search_replace_blocks:
            raise ToolError(
                "NO_BLOCKS:" + content  # sentinel for run() to handle fallback
            )

        # Detect garbled token output — only flag obvious corruption
        # (mixed angle brackets + repeated letters like <<t<ttt<t), not normal repeats
        for block in search_replace_blocks:
            if re.search(r'<[a-z]<[a-z]{2,}<[a-z]', block.search):
                raise ToolError(
                    "Your search text appears garbled (token corruption). "
                    "Use write_file to rewrite the function instead of search_replace."
                )

        return file_path, search_replace_blocks

    async def _read_file(self, file_path: Path) -> str:
        import asyncio

        def _sync_read():
            with open(file_path, encoding="utf-8") as f:
                return f.read()

        try:
            loop = asyncio.get_running_loop()
            return await asyncio.wait_for(
                loop.run_in_executor(None, _sync_read), timeout=10,
            )
        except asyncio.TimeoutError:
            raise ToolError(f"Timed out reading {file_path} after 10s.")
        except UnicodeDecodeError as e:
            raise ToolError(f"Unicode decode error reading {file_path}: {e}") from e
        except PermissionError:
            raise ToolError(f"Permission denied reading file: {file_path}")
        except Exception as e:
            raise ToolError(f"Unexpected error reading {file_path}: {e}") from e

    async def _backup_file(self, file_path: Path) -> None:
        shutil.copy2(file_path, file_path.with_suffix(file_path.suffix + ".bak"))

    async def _write_file(self, file_path: Path, content: str) -> None:
        import asyncio

        def _sync_write():
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)

        try:
            loop = asyncio.get_running_loop()
            await asyncio.wait_for(
                loop.run_in_executor(None, _sync_write), timeout=10,
            )
        except asyncio.TimeoutError:
            raise ToolError(f"Timed out writing {file_path} after 10s.")
        except PermissionError:
            raise ToolError(f"Permission denied writing to file: {file_path}")
        except OSError as e:
            raise ToolError(f"OS error writing to {file_path}: {e}") from e
        except Exception as e:
            raise ToolError(f"Unexpected error writing to {file_path}: {e}") from e

    @final
    @staticmethod
    def _apply_blocks(
        content: str,
        blocks: list[SearchReplaceBlock],
        filepath: Path,
        fuzzy_threshold: float = 0.9,
    ) -> BlockApplyResult:
        applied = 0
        errors: list[str] = []
        warnings: list[str] = []
        current_content = content

        for i, (search, replace) in enumerate(blocks, 1):
            if search not in current_content:
                # Check if this change was ALREADY APPLIED — the replacement
                # text is in the file but the search text is not.  This is the
                # #1 cause of edit loops: the model successfully edits a file
                # then retries the same edit because it doesn't realise it
                # already worked.
                if (replace and replace.strip()
                        and len(replace.strip()) >= 10
                        and replace.strip() in current_content):
                    warnings.append(
                        f"Block {i}: ALREADY APPLIED — the replacement text already "
                        f"exists in {filepath.name}. The search text is gone because "
                        f"a previous edit already made this change. "
                        f"Move on to the next task."
                    )
                    # Count as "applied" so we don't error — the file is correct
                    applied += 1
                    continue
                # Also detect deletion that already happened (search text removed,
                # replace is empty — the line is simply gone).  Only trigger
                # for meaningful search strings to avoid false positives.
                if (not replace or not replace.strip()) and len(search.strip()) >= 10:
                    warnings.append(
                        f"Block {i}: ALREADY APPLIED — the text you want to remove "
                        f"is already absent from {filepath.name}. "
                        f"Move on to the next task."
                    )
                    applied += 1
                    continue

                # Try auto-applying high-confidence fuzzy match (>= 0.95 similarity)
                auto_apply_threshold = max(fuzzy_threshold, 0.95)
                best_match = SearchReplace._find_best_fuzzy_match(
                    current_content, search, auto_apply_threshold
                )
                if best_match and best_match.similarity >= auto_apply_threshold:
                    # Auto-apply: replace the fuzzy-matched text with the replacement
                    current_content = current_content.replace(best_match.text, replace, 1)
                    applied += 1
                    similarity_pct = best_match.similarity * 100
                    warnings.append(
                        f"Block {i}: auto-applied via fuzzy match ({similarity_pct:.1f}% similarity, "
                        f"lines {best_match.start_line}-{best_match.end_line}). "
                        f"Whitespace differences were normalized."
                    )
                    continue

                context = SearchReplace._find_search_context(current_content, search)
                fuzzy_context = SearchReplace._find_fuzzy_match_context(
                    current_content, search, fuzzy_threshold
                )

                error_msg = (
                    f"SEARCH/REPLACE block {i} failed: Search text not found in {filepath}\n"
                    f"Search text was:\n{search!r}\n"
                    f"Context analysis:\n{context}"
                )

                if fuzzy_context:
                    error_msg += f"\n{fuzzy_context}"

                error_msg += (
                    "\nDebugging tips:\n"
                    "1. Check for exact whitespace/indentation match\n"
                    "2. Verify line endings match the file exactly (\\r\\n vs \\n)\n"
                    "3. Ensure the search text hasn't been modified by previous blocks or user edits\n"
                    "4. Check for typos or case sensitivity issues"
                )

                errors.append(error_msg)
                continue

            occurrences = current_content.count(search)
            if occurrences > 1:
                warning_msg = (
                    f"Search text in block {i} appears {occurrences} times in the file. "
                    f"Only the first occurrence will be replaced. Consider making your "
                    f"search pattern more specific to avoid unintended changes."
                )
                warnings.append(warning_msg)

            current_content = current_content.replace(search, replace, 1)
            applied += 1

        return BlockApplyResult(
            content=current_content, applied=applied, errors=errors, warnings=warnings
        )

    @final
    @staticmethod
    def _find_fuzzy_match_context(
        content: str, search_text: str, threshold: float = 0.9
    ) -> str | None:
        best_match = SearchReplace._find_best_fuzzy_match(
            content, search_text, threshold
        )

        if not best_match:
            return None

        diff = SearchReplace._create_unified_diff(
            search_text, best_match.text, "SEARCH", "CLOSEST MATCH"
        )

        similarity_pct = best_match.similarity * 100

        return (
            f"Closest fuzzy match (similarity {similarity_pct:.1f}%) "
            f"at lines {best_match.start_line}–{best_match.end_line}:\n"
            f"```diff\n{diff}\n```"
        )

    @final
    @staticmethod
    def _find_best_fuzzy_match(  # noqa: PLR0914
        content: str, search_text: str, threshold: float = 0.9
    ) -> FuzzyMatch | None:
        content_lines = content.split("\n")
        search_lines = search_text.split("\n")
        window_size = len(search_lines)

        if window_size == 0:
            return None

        non_empty_search = [line for line in search_lines if line.strip()]
        if not non_empty_search:
            return None

        first_anchor = non_empty_search[0]
        last_anchor = (
            non_empty_search[-1] if len(non_empty_search) > 1 else first_anchor
        )

        candidate_starts = set()
        spread = 5

        for i, line in enumerate(content_lines):
            if first_anchor in line or last_anchor in line:
                start_min = max(0, i - spread)
                start_max = min(len(content_lines) - window_size + 1, i + spread + 1)
                for s in range(start_min, start_max):
                    candidate_starts.add(s)

        if not candidate_starts:
            max_positions = min(len(content_lines) - window_size + 1, 100)
            candidate_starts = set(range(0, max_positions))

        best_match = None
        best_similarity = 0.0

        for start in candidate_starts:
            end = start + window_size
            window_text = "\n".join(content_lines[start:end])

            matcher = difflib.SequenceMatcher(None, search_text, window_text)
            similarity = matcher.ratio()

            if similarity >= threshold and similarity > best_similarity:
                best_similarity = similarity
                best_match = FuzzyMatch(
                    similarity=similarity,
                    start_line=start + 1,  # 1-based line numbers
                    end_line=end,
                    text=window_text,
                )

        return best_match

    @final
    @staticmethod
    def _create_unified_diff(
        text1: str, text2: str, label1: str = "SEARCH", label2: str = "CLOSEST MATCH"
    ) -> str:
        lines1 = text1.splitlines(keepends=True)
        lines2 = text2.splitlines(keepends=True)

        lines1 = [line if line.endswith("\n") else line + "\n" for line in lines1]
        lines2 = [line if line.endswith("\n") else line + "\n" for line in lines2]

        diff = difflib.unified_diff(
            lines1, lines2, fromfile=label1, tofile=label2, lineterm="", n=3
        )

        diff_lines = list(diff)

        if diff_lines and not diff_lines[0].startswith("==="):
            diff_lines.insert(2, "=" * 67 + "\n")

        result = "".join(diff_lines)

        max_chars = 2000
        if len(result) > max_chars:
            result = result[:max_chars] + "\n...(diff truncated)"

        return result.rstrip()

    @final
    @staticmethod
    def _parse_search_replace_blocks(content: str) -> list[SearchReplaceBlock]:
        """Parse SEARCH/REPLACE blocks from content.

        Supports multiple formats for model compatibility:
        1. Standard: <<<<<<< SEARCH ... ======= ... >>>>>>> REPLACE
        2. With code fences: ```...<<<<<<< SEARCH...```
        3. Simple separator: old_text\n=======\nnew_text (Gemma 4 style)
        4. JSON: {"old_string": "...", "new_string": "..."} or {"search": "...", "replace": "..."}
        """
        # Try standard format first
        matches = SEARCH_REPLACE_BLOCK_WITH_FENCE_RE.findall(content)
        if not matches:
            matches = SEARCH_REPLACE_BLOCK_RE.findall(content)

        if matches:
            return [
                SearchReplaceBlock(
                    search=search.rstrip("\r\n"), replace=replace.rstrip("\r\n")
                )
                for search, replace in matches
            ]

        # Fallback: try JSON format (some models send structured args)
        import json
        try:
            data = json.loads(content)
            if isinstance(data, dict):
                old = data.get("old_string") or data.get("search") or data.get("old")
                new = data.get("new_string") or data.get("replace") or data.get("new")
                if old is not None and new is not None:
                    return [SearchReplaceBlock(search=str(old), replace=str(new))]
        except (json.JSONDecodeError, TypeError):
            pass

        # Fallback: simple ======= separator (Gemma 4 often uses this)
        if "\n=======\n" in content:
            parts = content.split("\n=======\n", 1)
            if len(parts) == 2:
                search = parts[0].strip()
                replace = parts[1].strip()
                if search:
                    return [SearchReplaceBlock(search=search, replace=replace)]

        # Fallback: --- separator
        if "\n---\n" in content:
            parts = content.split("\n---\n", 1)
            if len(parts) == 2:
                search = parts[0].strip()
                replace = parts[1].strip()
                if search:
                    return [SearchReplaceBlock(search=search, replace=replace)]

        return []

    @final
    @staticmethod
    def _find_search_context(
        content: str, search_text: str, max_context: int = 5
    ) -> str:
        lines = content.split("\n")
        search_lines = search_text.split("\n")

        if not search_lines:
            return "Search text is empty"

        first_search_line = search_lines[0].strip()
        if not first_search_line:
            return "First line of search text is empty or whitespace only"

        matches = []
        for i, line in enumerate(lines):
            if first_search_line in line:
                matches.append(i)

        if not matches:
            return f"First search line '{first_search_line}' not found anywhere in file"

        context_lines = []
        for match_idx in matches[:3]:
            start = max(0, match_idx - max_context)
            end = min(len(lines), match_idx + max_context + 1)

            context_lines.append(f"\nPotential match area around line {match_idx + 1}:")
            for i in range(start, end):
                marker = ">>>" if i == match_idx else "   "
                context_lines.append(f"{marker} {i + 1:3d}: {lines[i]}")

        return "\n".join(context_lines)
