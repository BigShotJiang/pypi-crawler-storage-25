"""Infrastructure layer for flowr — config, session store, and IO."""
