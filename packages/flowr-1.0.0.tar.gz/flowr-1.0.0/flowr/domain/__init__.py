"""Flow definition domain types."""
