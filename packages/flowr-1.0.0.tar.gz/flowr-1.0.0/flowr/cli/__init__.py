"""CLI package for flowr."""
