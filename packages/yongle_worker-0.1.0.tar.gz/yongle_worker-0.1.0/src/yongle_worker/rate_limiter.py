from __future__ import annotations

import threading
import time


class RateLimiter:
    def __init__(self, rate_per_sec: float) -> None:
        self.rate_per_sec = max(rate_per_sec, 0.1)
        self.interval = 1.0 / self.rate_per_sec
        self._lock = threading.Lock()
        self._next_ts = 0.0

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            if now < self._next_ts:
                time.sleep(self._next_ts - now)
            self._next_ts = max(now, self._next_ts) + self.interval
