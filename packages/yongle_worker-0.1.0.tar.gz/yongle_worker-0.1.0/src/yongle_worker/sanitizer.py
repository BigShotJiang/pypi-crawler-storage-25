from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from .models import PolicyBundle


PHONE_RE = re.compile(r"(?<!\d)(?:1[3-9]\d{9})(?!\d)")
ID_CARD_RE = re.compile(r"\b\d{17}[\dXx]\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


class SensitiveDataBlockedError(ValueError):
    pass


@dataclass(slots=True)
class SanitizationHit:
    field_path: str
    field_type: str
    action: str


class DataSanitizer:
    def __init__(self, policy: PolicyBundle):
        self.policy = policy
        self.custom_regex = {
            name: re.compile(pattern)
            for name, pattern in policy.custom_patterns.items()
        }

    def sanitize(self, payload: dict[str, Any]) -> tuple[dict[str, Any], list[SanitizationHit]]:
        hits: list[SanitizationHit] = []
        output = self._walk(payload, path="", hits=hits)
        if output is None:
            return {}, hits
        return output, hits

    def assert_clean(self, payload: dict[str, Any]) -> list[SanitizationHit]:
        _, hits = self.sanitize(payload)
        blocked = [h for h in hits if h.action == "block"]
        if blocked:
            top = blocked[0]
            raise SensitiveDataBlockedError(
                f"blocked field_type={top.field_type} field_path={top.field_path}"
            )
        return hits

    def _walk(self, value: Any, path: str, hits: list[SanitizationHit]) -> Any:
        if isinstance(value, dict):
            out: dict[str, Any] = {}
            for key, sub_value in value.items():
                sub_path = f"{path}.{key}" if path else key
                detected = self._detect_field_type(key, sub_value)
                action = self._resolve_action(detected)
                if detected and action == "drop":
                    hits.append(SanitizationHit(sub_path, detected, action))
                    continue
                if detected and action == "block":
                    hits.append(SanitizationHit(sub_path, detected, action))
                    raise SensitiveDataBlockedError(
                        f"blocked field_type={detected} field_path={sub_path}"
                    )
                walked = self._walk(sub_value, sub_path, hits)
                if detected and action == "mask":
                    hits.append(SanitizationHit(sub_path, detected, action))
                    out[key] = self._mask_value(walked)
                elif walked is not None:
                    out[key] = walked
            return out
        if isinstance(value, list):
            out_list = []
            for idx, item in enumerate(value):
                item_path = f"{path}[{idx}]"
                walked = self._walk(item, item_path, hits)
                if walked is not None:
                    out_list.append(walked)
            return out_list
        return value

    def _detect_field_type(self, key: str, value: Any) -> str | None:
        key_low = key.lower()
        text = str(value) if isinstance(value, (str, int, float)) else ""
        if any(tag in key_low for tag in ["name", "full_name", "real_name", "xingming"]):
            return "name"
        if any(tag in key_low for tag in ["phone", "mobile", "tel"]):
            return "phone"
        if any(tag in key_low for tag in ["id_card", "idno", "identity"]):
            return "id_card"
        if any(tag in key_low for tag in ["email", "mail"]):
            return "email"
        if PHONE_RE.search(text):
            return "phone"
        if ID_CARD_RE.search(text):
            return "id_card"
        if EMAIL_RE.search(text):
            return "email"
        for custom_name, pattern in self.custom_regex.items():
            if pattern.search(text):
                return "custom"
        return None

    def _resolve_action(self, field_type: str | None) -> str | None:
        if field_type is None:
            return None
        for rule in self.policy.rules:
            if rule.field_type == field_type:
                return rule.action
        if self.policy.mode == "strict":
            return {
                "name": "drop",
                "phone": "drop",
                "id_card": "block",
                "email": "drop",
                "custom": "drop",
            }.get(field_type, "drop")
        if self.policy.mode == "research":
            return {
                "name": "mask",
                "phone": "drop",
                "id_card": "block",
                "email": "drop",
                "custom": "drop",
            }.get(field_type, "drop")
        return {
            "name": "mask",
            "phone": "mask",
            "id_card": "block",
            "email": "mask",
            "custom": "mask",
        }.get(field_type, "drop")

    @staticmethod
    def _mask_value(value: Any) -> Any:
        text = str(value)
        if len(text) <= 2:
            return "**"
        return f"{text[0]}***{text[-1]}"
