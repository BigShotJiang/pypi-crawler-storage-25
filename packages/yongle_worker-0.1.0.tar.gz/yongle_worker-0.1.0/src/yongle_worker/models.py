from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class RegisterAgentRequest(BaseModel):
    agent_name: str
    sdk_version: str = "0.1.0"
    capabilities: list[str] = Field(default_factory=lambda: ["http"])


class RegisterAgentResponse(BaseModel):
    agent_id: str


class PullTaskRequest(BaseModel):
    agent_id: str


class HttpRequestSpec(BaseModel):
    method: str = "GET"
    url: str
    headers: dict[str, str] = Field(default_factory=dict)
    params: dict[str, Any] = Field(default_factory=dict)
    json_body: dict[str, Any] | None = Field(default=None, alias="json")
    data: str | None = None
    timeout_sec: float | None = None


class TaskPolicyRule(BaseModel):
    field_type: Literal["name", "phone", "id_card", "email", "custom"]
    action: Literal["mask", "drop", "block"]


class PolicyBundle(BaseModel):
    policy_version: str
    mode: Literal["strict", "research", "custom"] = "strict"
    allow_local_fields: list[str] = Field(default_factory=list)
    custom_patterns: dict[str, str] = Field(default_factory=dict)
    rules: list[TaskPolicyRule] = Field(default_factory=list)


class TaskPayload(BaseModel):
    id: str
    type: Literal["http"]
    request: HttpRequestSpec
    policy: PolicyBundle


class PullTaskResponse(BaseModel):
    task: TaskPayload | None = None


class HeartbeatRequest(BaseModel):
    agent_id: str


class ResultPayload(BaseModel):
    agent_id: str
    policy_version: str
    data: dict[str, Any]


class FailPayload(BaseModel):
    agent_id: str
    policy_version: str
    error_code: str
    error_message: str


class PolicyCurrentResponse(BaseModel):
    policy: PolicyBundle
