from __future__ import annotations

import time
from typing import Any

import httpx

from .checkpoint import CheckpointStore
from .config import WorkerSettings
from .executor import HttpExecutor
from .logging_utils import setup_logger
from .models import (
    FailPayload,
    HeartbeatRequest,
    PolicyBundle,
    PullTaskRequest,
    PullTaskResponse,
    RegisterAgentRequest,
    RegisterAgentResponse,
    ResultPayload,
    TaskPayload,
)
from .sanitizer import DataSanitizer, SensitiveDataBlockedError


class WorkerClient:
    def __init__(self, settings: WorkerSettings | None = None) -> None:
        self.settings = settings or WorkerSettings()
        self.logger = setup_logger("yongle_worker", self.settings.log_level)
        self.checkpoint = CheckpointStore(self.settings.checkpoint_path)
        self.executor = HttpExecutor(
            timeout_sec=self.settings.request_timeout_sec,
            retries=self.settings.request_retries,
            backoff_sec=self.settings.request_backoff_sec,
            rate_limit_per_sec=self.settings.rate_limit_per_sec,
        )
        self.agent_id: str | None = None

    def register_agent(self) -> str:
        req = RegisterAgentRequest(agent_name=self.settings.agent_name)
        data = self._post("/agent/register", req.model_dump())
        parsed = RegisterAgentResponse.model_validate(data)
        self.agent_id = parsed.agent_id
        self.logger.info("agent registered", extra={"agent_id": self.agent_id})
        return parsed.agent_id

    def pull_task(self) -> TaskPayload | None:
        agent_id = self._require_agent_id()
        req = PullTaskRequest(agent_id=agent_id)
        data = self._post("/tasks/pull", req.model_dump())
        parsed = PullTaskResponse.model_validate(data)
        return parsed.task

    def heartbeat(self, task_id: str) -> None:
        agent_id = self._require_agent_id()
        req = HeartbeatRequest(agent_id=agent_id)
        self._post(f"/tasks/{task_id}/heartbeat", req.model_dump())

    def push_result(self, task_id: str, policy: PolicyBundle, data: dict[str, Any]) -> None:
        agent_id = self._require_agent_id()
        sanitizer = DataSanitizer(policy)

        # Layer-1 local preprocess before upload.
        cleaned, hits = sanitizer.sanitize(data)
        for hit in hits:
            self.logger.info(
                "sanitization hit",
                extra={
                    "task_id": task_id,
                    "agent_id": agent_id,
                    "policy_version": policy.policy_version,
                    "field_type": hit.field_type,
                    "action": hit.action,
                },
            )

        # Layer-2 validation gate right before upload.
        sanitizer.assert_clean(cleaned)

        req = ResultPayload(
            agent_id=agent_id,
            policy_version=policy.policy_version,
            data=cleaned,
        )
        self._post(f"/tasks/{task_id}/result", req.model_dump())
        self.logger.info(
            "result pushed",
            extra={"task_id": task_id, "agent_id": agent_id, "policy_version": policy.policy_version},
        )

    def push_fail(
        self,
        task_id: str,
        policy_version: str,
        error_code: str,
        error_message: str,
    ) -> None:
        agent_id = self._require_agent_id()
        req = FailPayload(
            agent_id=agent_id,
            policy_version=policy_version,
            error_code=error_code,
            error_message=error_message,
        )
        self._post(f"/tasks/{task_id}/fail", req.model_dump())
        self.logger.error(
            "task failed",
            extra={"task_id": task_id, "agent_id": agent_id, "policy_version": policy_version},
        )

    def run_once(self) -> dict[str, Any] | None:
        if not self.agent_id:
            self.register_agent()

        task = self.pull_task()
        if task is None:
            self.logger.info("no task")
            return None

        self.checkpoint.set_state(task.id, "pulled", {"policy_version": task.policy.policy_version})
        self.heartbeat(task.id)
        self.checkpoint.set_state(task.id, "executing")

        try:
            result = self.executor.execute(task.request)
            self.checkpoint.set_state(task.id, "executed")
            self.push_result(task.id, task.policy, result)
            self.checkpoint.set_state(task.id, "reported")
            self.checkpoint.clear()
            return result
        except SensitiveDataBlockedError as exc:
            self.push_fail(task.id, task.policy.policy_version, "SENSITIVE_BLOCKED", str(exc))
            raise
        except Exception as exc:
            self.push_fail(task.id, task.policy.policy_version, "EXECUTION_ERROR", str(exc))
            raise

    def run_forever(self) -> None:
        if not self.agent_id:
            self.register_agent()

        while True:
            try:
                self.run_once()
            except Exception:
                self.logger.exception("run_once failed")
            time.sleep(self.settings.poll_interval_sec)

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.settings.control_base_url.rstrip('/')}{path}"
        headers = {
            "x-api-key": self.settings.api_key,
            "content-type": "application/json",
        }
        with httpx.Client(timeout=self.settings.request_timeout_sec) as client:
            resp = client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        if not isinstance(data, dict):
            return {}
        return data

    def _require_agent_id(self) -> str:
        if not self.agent_id:
            raise RuntimeError("agent not registered")
        return self.agent_id
