from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class CheckpointStore:
    path: Path

    def load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {}

    def save(self, data: dict[str, Any]) -> None:
        self.path.write_text(json.dumps(data, ensure_ascii=True, indent=2), encoding="utf-8")

    def set_state(self, task_id: str, state: str, extra: dict[str, Any] | None = None) -> None:
        payload = self.load()
        payload["task_id"] = task_id
        payload["state"] = state
        payload["updated_at"] = datetime.now(timezone.utc).isoformat()
        if extra:
            payload.update(extra)
        self.save(payload)

    def clear(self) -> None:
        if self.path.exists():
            self.path.unlink()
