from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


load_dotenv()


@dataclass(slots=True)
class WorkerSettings:
    control_base_url: str = os.getenv("YONGLE_CONTROL_BASE_URL", "http://127.0.0.1:8000")
    api_key: str = os.getenv("YONGLE_API_KEY", "dev-api-key")
    agent_name: str = os.getenv("YONGLE_AGENT_NAME", "local-agent")
    poll_interval_sec: float = float(os.getenv("YONGLE_POLL_INTERVAL_SEC", "3"))
    request_timeout_sec: float = float(os.getenv("YONGLE_REQUEST_TIMEOUT_SEC", "15"))
    request_retries: int = int(os.getenv("YONGLE_REQUEST_RETRIES", "2"))
    request_backoff_sec: float = float(os.getenv("YONGLE_REQUEST_BACKOFF_SEC", "0.8"))
    rate_limit_per_sec: float = float(os.getenv("YONGLE_RATE_LIMIT_PER_SEC", "2"))
    checkpoint_path: Path = Path(os.getenv("YONGLE_CHECKPOINT_PATH", ".yongle_checkpoint.json"))
    log_level: str = os.getenv("YONGLE_LOG_LEVEL", "INFO")
