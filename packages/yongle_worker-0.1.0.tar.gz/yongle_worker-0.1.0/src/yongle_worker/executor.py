from __future__ import annotations

import json
import time
from typing import Any

import httpx

from .models import HttpRequestSpec
from .rate_limiter import RateLimiter


class HttpExecutor:
    def __init__(
        self,
        timeout_sec: float,
        retries: int,
        backoff_sec: float,
        rate_limit_per_sec: float,
    ) -> None:
        self.timeout_sec = timeout_sec
        self.retries = retries
        self.backoff_sec = backoff_sec
        self.limiter = RateLimiter(rate_limit_per_sec)

    def execute(self, req: HttpRequestSpec) -> dict[str, Any]:
        method = req.method.upper()
        timeout = req.timeout_sec or self.timeout_sec
        last_error: Exception | None = None

        for attempt in range(self.retries + 1):
            self.limiter.wait()
            try:
                with httpx.Client(timeout=timeout) as client:
                    resp = client.request(
                        method=method,
                        url=req.url,
                        headers=req.headers,
                        params=req.params,
                        json=req.json_body,
                        content=req.data,
                    )
                return self._normalize_response(resp)
            except Exception as exc:
                last_error = exc
                if attempt >= self.retries:
                    break
                time.sleep(self.backoff_sec * (2 ** attempt))

        raise RuntimeError(f"http execution failed: {last_error}")

    @staticmethod
    def _normalize_response(resp: httpx.Response) -> dict[str, Any]:
        content_type = resp.headers.get("content-type", "")
        body: Any
        if "application/json" in content_type:
            try:
                body = resp.json()
            except json.JSONDecodeError:
                body = resp.text[:2000]
        else:
            body = resp.text[:2000]

        return {
            "status_code": resp.status_code,
            "headers": {
                "content_type": content_type,
                "date": resp.headers.get("date", ""),
            },
            "body": body,
            "url": str(resp.url),
        }
