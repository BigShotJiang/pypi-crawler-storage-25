from __future__ import annotations

from fastapi import Header, HTTPException

from .config import ControlSettings


def require_api_key(x_api_key: str | None = Header(default=None)) -> str:
    settings = ControlSettings()
    if not x_api_key or x_api_key not in settings.api_keys:
        raise HTTPException(status_code=401, detail="invalid api key")
    return x_api_key
