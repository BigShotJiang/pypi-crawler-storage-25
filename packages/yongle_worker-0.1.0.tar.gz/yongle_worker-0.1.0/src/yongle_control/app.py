from __future__ import annotations

from uuid import uuid4

import uvicorn
from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel

from yongle_worker.models import (
    FailPayload,
    HeartbeatRequest,
    PolicyCurrentResponse,
    PullTaskRequest,
    PullTaskResponse,
    RegisterAgentRequest,
    RegisterAgentResponse,
    ResultPayload,
)
from yongle_worker.sanitizer import DataSanitizer, SensitiveDataBlockedError

from .auth import require_api_key
from .config import ControlSettings
from .db import DB


settings = ControlSettings()
db = DB(settings.db_path)
app = FastAPI(title="yongle-control", version="0.1.0")


class SimpleOK(BaseModel):
    ok: bool = True


@app.post("/agent/register", response_model=RegisterAgentResponse)
def register_agent(payload: RegisterAgentRequest, _: str = Depends(require_api_key)) -> RegisterAgentResponse:
    agent_id = f"agent-{uuid4().hex[:12]}"
    db.register_agent(agent_id=agent_id, agent_name=payload.agent_name)
    return RegisterAgentResponse(agent_id=agent_id)


@app.post("/tasks/pull", response_model=PullTaskResponse)
def pull_task(payload: PullTaskRequest, _: str = Depends(require_api_key)) -> PullTaskResponse:
    db.touch_agent(payload.agent_id)
    task = db.pull_task(payload.agent_id)
    return PullTaskResponse(task=task)


@app.post("/tasks/{task_id}/heartbeat", response_model=SimpleOK)
def heartbeat(task_id: str, payload: HeartbeatRequest, _: str = Depends(require_api_key)) -> SimpleOK:
    db.heartbeat(task_id=task_id, agent_id=payload.agent_id)
    return SimpleOK()


@app.post("/tasks/{task_id}/result", response_model=SimpleOK)
def push_result(task_id: str, payload: ResultPayload, _: str = Depends(require_api_key)) -> SimpleOK:
    expected_policy_version = db.get_task_policy_version(task_id)
    if payload.policy_version != expected_policy_version:
        raise HTTPException(status_code=400, detail="policy_version mismatch")

    policy = db.get_current_policy()
    sanitizer = DataSanitizer(policy)
    try:
        cleaned, hits = sanitizer.sanitize(payload.data)
    except SensitiveDataBlockedError as exc:
        db.mark_fail(task_id, payload.agent_id, "PLATFORM_BLOCKED", str(exc))
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    for hit in hits:
        db.add_audit(
            agent_id=payload.agent_id,
            task_id=task_id,
            policy_version=payload.policy_version,
            field_type=hit.field_type,
            action=hit.action,
        )

    db.mark_result(task_id=task_id, agent_id=payload.agent_id, result=cleaned)
    return SimpleOK()


@app.post("/tasks/{task_id}/fail", response_model=SimpleOK)
def push_fail(task_id: str, payload: FailPayload, _: str = Depends(require_api_key)) -> SimpleOK:
    expected_policy_version = db.get_task_policy_version(task_id)
    if payload.policy_version != expected_policy_version:
        raise HTTPException(status_code=400, detail="policy_version mismatch")
    db.mark_fail(task_id, payload.agent_id, payload.error_code, payload.error_message)
    return SimpleOK()


@app.get("/policy/current", response_model=PolicyCurrentResponse)
def get_policy(_: str = Depends(require_api_key)) -> PolicyCurrentResponse:
    return PolicyCurrentResponse(policy=db.get_current_policy())


def run() -> None:
    uvicorn.run("yongle_control.app:app", host=settings.host, port=settings.port, reload=False)


if __name__ == "__main__":
    run()
