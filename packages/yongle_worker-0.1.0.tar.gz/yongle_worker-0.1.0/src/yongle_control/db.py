from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from yongle_worker.models import PolicyBundle, TaskPayload


class DB:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS agents (
                    agent_id TEXT PRIMARY KEY,
                    agent_name TEXT NOT NULL,
                    calls_total INTEGER NOT NULL DEFAULT 0,
                    success_total INTEGER NOT NULL DEFAULT 0,
                    fail_total INTEGER NOT NULL DEFAULT 0,
                    last_seen_at TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    type TEXT NOT NULL,
                    request_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    assigned_agent_id TEXT,
                    policy_version TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    result_json TEXT,
                    error_code TEXT,
                    error_message TEXT
                );

                CREATE TABLE IF NOT EXISTS policies (
                    version TEXT PRIMARY KEY,
                    mode TEXT NOT NULL,
                    allow_local_fields_json TEXT NOT NULL,
                    custom_patterns_json TEXT NOT NULL,
                    rules_json TEXT NOT NULL,
                    is_current INTEGER NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    policy_version TEXT NOT NULL,
                    field_type TEXT NOT NULL,
                    action TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                );
                """
            )

        self.ensure_default_policy()
        self.ensure_demo_task()

    @staticmethod
    def now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def ensure_default_policy(self) -> None:
        with self._connect() as conn:
            row = conn.execute("SELECT version FROM policies WHERE is_current = 1 LIMIT 1").fetchone()
            if row:
                return
            now = self.now()
            conn.execute(
                """
                INSERT INTO policies(version, mode, allow_local_fields_json, custom_patterns_json, rules_json, is_current, created_at)
                VALUES (?, ?, ?, ?, ?, 1, ?)
                """,
                (
                    "2026.04.16.1",
                    "strict",
                    json.dumps([]),
                    json.dumps({}),
                    json.dumps(
                        [
                            {"field_type": "name", "action": "drop"},
                            {"field_type": "phone", "action": "drop"},
                            {"field_type": "id_card", "action": "block"},
                            {"field_type": "email", "action": "drop"},
                        ]
                    ),
                    now,
                ),
            )
            conn.commit()

    def ensure_demo_task(self) -> None:
        with self._connect() as conn:
            row = conn.execute("SELECT id FROM tasks LIMIT 1").fetchone()
            if row:
                return
            policy = self.get_current_policy()
            now = self.now()
            task = {
                "id": "task-demo-001",
                "type": "http",
                "request": {
                    "method": "GET",
                    "url": "https://httpbin.org/json",
                    "headers": {},
                    "params": {},
                    "json": None,
                    "data": None,
                    "timeout_sec": 10,
                },
                "policy": policy.model_dump(),
            }
            conn.execute(
                """
                INSERT INTO tasks(id, type, request_json, status, assigned_agent_id, policy_version, created_at, updated_at)
                VALUES (?, ?, ?, 'queued', NULL, ?, ?, ?)
                """,
                (task["id"], task["type"], json.dumps(task["request"]), policy.policy_version, now, now),
            )
            conn.commit()

    def get_current_policy(self) -> PolicyBundle:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM policies WHERE is_current = 1 LIMIT 1").fetchone()
            if not row:
                raise RuntimeError("current policy not found")
            return PolicyBundle(
                policy_version=row["version"],
                mode=row["mode"],
                allow_local_fields=json.loads(row["allow_local_fields_json"]),
                custom_patterns=json.loads(row["custom_patterns_json"]),
                rules=json.loads(row["rules_json"]),
            )

    def register_agent(self, agent_id: str, agent_name: str) -> None:
        now = self.now()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO agents(agent_id, agent_name, calls_total, success_total, fail_total, last_seen_at, created_at)
                VALUES (?, ?, 0, 0, 0, ?, ?)
                ON CONFLICT(agent_id) DO UPDATE SET
                    agent_name=excluded.agent_name,
                    last_seen_at=excluded.last_seen_at
                """,
                (agent_id, agent_name, now, now),
            )
            conn.commit()

    def touch_agent(self, agent_id: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE agents SET last_seen_at = ? WHERE agent_id = ?",
                (self.now(), agent_id),
            )
            conn.commit()

    def pull_task(self, agent_id: str) -> TaskPayload | None:
        with self._lock:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT * FROM tasks WHERE status = 'queued' ORDER BY created_at LIMIT 1"
                ).fetchone()
                if not row:
                    return None
                now = self.now()
                conn.execute(
                    "UPDATE tasks SET status = 'running', assigned_agent_id = ?, updated_at = ? WHERE id = ?",
                    (agent_id, now, row["id"]),
                )
                conn.execute(
                    "UPDATE agents SET calls_total = calls_total + 1, last_seen_at = ? WHERE agent_id = ?",
                    (now, agent_id),
                )
                conn.commit()
                policy = self.get_current_policy()
                return TaskPayload(
                    id=row["id"],
                    type=row["type"],
                    request=json.loads(row["request_json"]),
                    policy=policy,
                )

    def heartbeat(self, task_id: str, agent_id: str) -> None:
        now = self.now()
        with self._connect() as conn:
            conn.execute(
                "UPDATE tasks SET updated_at = ? WHERE id = ? AND assigned_agent_id = ?",
                (now, task_id, agent_id),
            )
            conn.execute("UPDATE agents SET last_seen_at = ? WHERE agent_id = ?", (now, agent_id))
            conn.commit()

    def mark_result(self, task_id: str, agent_id: str, result: dict[str, Any]) -> None:
        now = self.now()
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE tasks
                SET status = 'success', result_json = ?, updated_at = ?
                WHERE id = ? AND assigned_agent_id = ?
                """,
                (json.dumps(result, ensure_ascii=True), now, task_id, agent_id),
            )
            conn.execute(
                "UPDATE agents SET success_total = success_total + 1, last_seen_at = ? WHERE agent_id = ?",
                (now, agent_id),
            )
            conn.commit()

    def mark_fail(self, task_id: str, agent_id: str, error_code: str, error_message: str) -> None:
        now = self.now()
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE tasks
                SET status = 'failed', error_code = ?, error_message = ?, updated_at = ?
                WHERE id = ? AND assigned_agent_id = ?
                """,
                (error_code, error_message[:500], now, task_id, agent_id),
            )
            conn.execute(
                "UPDATE agents SET fail_total = fail_total + 1, last_seen_at = ? WHERE agent_id = ?",
                (now, agent_id),
            )
            conn.commit()

    def add_audit(
        self,
        agent_id: str,
        task_id: str,
        policy_version: str,
        field_type: str,
        action: str,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO audit_logs(agent_id, task_id, policy_version, field_type, action, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (agent_id, task_id, policy_version, field_type, action, self.now()),
            )
            conn.commit()

    def get_task_policy_version(self, task_id: str) -> str:
        with self._connect() as conn:
            row = conn.execute("SELECT policy_version FROM tasks WHERE id = ?", (task_id,)).fetchone()
            if not row:
                raise RuntimeError("task not found")
            return row["policy_version"]
