from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


load_dotenv()


@dataclass(slots=True)
class ControlSettings:
    db_path: Path = Path(os.getenv("YONGLE_CONTROL_DB_PATH", "./yongle_control.db"))
    api_keys: list[str] = None  # type: ignore[assignment]
    host: str = os.getenv("YONGLE_CONTROL_HOST", "127.0.0.1")
    port: int = int(os.getenv("YONGLE_CONTROL_PORT", "8000"))

    def __post_init__(self) -> None:
        raw = os.getenv("YONGLE_CONTROL_API_KEYS", "dev-api-key")
        self.api_keys = [x.strip() for x in raw.split(",") if x.strip()]
