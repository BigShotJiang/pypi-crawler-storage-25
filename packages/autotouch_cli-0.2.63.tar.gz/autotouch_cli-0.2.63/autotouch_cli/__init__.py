"""Autotouch CLI package."""
