import os

from .util import execute_command, need_sudo


def _sudo_prefix():
    return "sudo " if need_sudo() else ""


def fix_sing():
    sudo = _sudo_prefix()

    # Add hosts entry
    cmd = f'echo "52.239.210.1 msranlphot.blob.core.windows.net" | {sudo}tee -a /etc/hosts'
    execute_command(cmd)

    # Fix apt sources and update
    cmd = (
        f"{sudo}sed -i "
        "'s|http://archive.ubuntu.com|http://azure.archive.ubuntu.com|g; "
        "s|http://security.ubuntu.com|http://azure.archive.ubuntu.com|g' "
        "/etc/apt/sources.list /etc/apt/sources.list.d/*.sources 2>/dev/null; "
        f"{sudo}apt-get update -y || true"
    )
    execute_command(cmd)


FIX_TARGETS = {
    "sing": fix_sing,
}


def add_fix_args(subparsers):
    fix_parser = subparsers.add_parser("fix", help="Apply predefined fixes")
    fix_parser.add_argument("target", type=str, choices=list(FIX_TARGETS.keys()), help="Fix target to apply")


def fix_main(args):
    target = args.target
    if target in FIX_TARGETS:
        FIX_TARGETS[target]()
    else:
        print(f"Unknown fix target: {target}")
