# Overview

Small toolkit for capturing and dumping browser cookies via an embedded browser and then being able to use them from cURL or any way you see fit this supports crawling or capturing authenticated web content.

# Install

From the repository root:

```bash
pip install .
```

# Tools

- `ct_authenticate`: Opens an embedded Chromium window to the given URL. The output should be redirected. Login as necessary and press the "Done" button.

- `ct_to_curl`: Reads the JSON output from `ct_authenticate` and prints `curl` cookie arguments

## Example

```bash
ct_authenticate https://example.com > session.json
curl -s $(ct_to_curl < session.json) 'https://example.com/'
```

# Tests

```bash
pytest
```
