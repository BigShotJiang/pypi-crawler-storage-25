# Predictions

## StructureAndBinding

Types:

```python
from boltz_compute.types.predictions import (
    StructureAndBindingRetrieveResponse,
    StructureAndBindingListResponse,
    StructureAndBindingDeleteDataResponse,
    StructureAndBindingEstimateCostResponse,
    StructureAndBindingStartResponse,
)
```

Methods:

- <code title="get /compute/v1/predictions/structure-and-binding/{id}">client.predictions.structure_and_binding.<a href="./src/boltz_compute/resources/predictions/structure_and_binding.py">retrieve</a>(id, \*\*<a href="src/boltz_compute/types/predictions/structure_and_binding_retrieve_params.py">params</a>) -> <a href="./src/boltz_compute/types/predictions/structure_and_binding_retrieve_response.py">StructureAndBindingRetrieveResponse</a></code>
- <code title="get /compute/v1/predictions/structure-and-binding">client.predictions.structure_and_binding.<a href="./src/boltz_compute/resources/predictions/structure_and_binding.py">list</a>(\*\*<a href="src/boltz_compute/types/predictions/structure_and_binding_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/predictions/structure_and_binding_list_response.py">SyncCursorPage[StructureAndBindingListResponse]</a></code>
- <code title="post /compute/v1/predictions/structure-and-binding/{id}/delete-data">client.predictions.structure_and_binding.<a href="./src/boltz_compute/resources/predictions/structure_and_binding.py">delete_data</a>(id) -> <a href="./src/boltz_compute/types/predictions/structure_and_binding_delete_data_response.py">StructureAndBindingDeleteDataResponse</a></code>
- <code title="post /compute/v1/predictions/structure-and-binding/estimate-cost">client.predictions.structure_and_binding.<a href="./src/boltz_compute/resources/predictions/structure_and_binding.py">estimate_cost</a>(\*\*<a href="src/boltz_compute/types/predictions/structure_and_binding_estimate_cost_params.py">params</a>) -> <a href="./src/boltz_compute/types/predictions/structure_and_binding_estimate_cost_response.py">StructureAndBindingEstimateCostResponse</a></code>
- <code title="post /compute/v1/predictions/structure-and-binding">client.predictions.structure_and_binding.<a href="./src/boltz_compute/resources/predictions/structure_and_binding.py">start</a>(\*\*<a href="src/boltz_compute/types/predictions/structure_and_binding_start_params.py">params</a>) -> <a href="./src/boltz_compute/types/predictions/structure_and_binding_start_response.py">StructureAndBindingStartResponse</a></code>

# SmallMolecule

## Design

Types:

```python
from boltz_compute.types.small_molecule import (
    DesignRetrieveResponse,
    DesignListResponse,
    DesignDeleteDataResponse,
    DesignEstimateCostResponse,
    DesignListResultsResponse,
    DesignStartResponse,
    DesignStopResponse,
)
```

Methods:

- <code title="get /compute/v1/small-molecule/design/{run_id}">client.small_molecule.design.<a href="./src/boltz_compute/resources/small_molecule/design.py">retrieve</a>(run_id, \*\*<a href="src/boltz_compute/types/small_molecule/design_retrieve_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/design_retrieve_response.py">DesignRetrieveResponse</a></code>
- <code title="get /compute/v1/small-molecule/design">client.small_molecule.design.<a href="./src/boltz_compute/resources/small_molecule/design.py">list</a>(\*\*<a href="src/boltz_compute/types/small_molecule/design_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/design_list_response.py">SyncCursorPage[DesignListResponse]</a></code>
- <code title="post /compute/v1/small-molecule/design/{run_id}/delete-data">client.small_molecule.design.<a href="./src/boltz_compute/resources/small_molecule/design.py">delete_data</a>(run_id) -> <a href="./src/boltz_compute/types/small_molecule/design_delete_data_response.py">DesignDeleteDataResponse</a></code>
- <code title="post /compute/v1/small-molecule/design/estimate-cost">client.small_molecule.design.<a href="./src/boltz_compute/resources/small_molecule/design.py">estimate_cost</a>(\*\*<a href="src/boltz_compute/types/small_molecule/design_estimate_cost_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/design_estimate_cost_response.py">DesignEstimateCostResponse</a></code>
- <code title="get /compute/v1/small-molecule/design/{run_id}/results">client.small_molecule.design.<a href="./src/boltz_compute/resources/small_molecule/design.py">list_results</a>(run_id, \*\*<a href="src/boltz_compute/types/small_molecule/design_list_results_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/design_list_results_response.py">SyncCursorPage[DesignListResultsResponse]</a></code>
- <code title="post /compute/v1/small-molecule/design">client.small_molecule.design.<a href="./src/boltz_compute/resources/small_molecule/design.py">start</a>(\*\*<a href="src/boltz_compute/types/small_molecule/design_start_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/design_start_response.py">DesignStartResponse</a></code>
- <code title="post /compute/v1/small-molecule/design/{run_id}/stop">client.small_molecule.design.<a href="./src/boltz_compute/resources/small_molecule/design.py">stop</a>(run_id) -> <a href="./src/boltz_compute/types/small_molecule/design_stop_response.py">DesignStopResponse</a></code>

## LibraryScreen

Types:

```python
from boltz_compute.types.small_molecule import (
    LibraryScreenRetrieveResponse,
    LibraryScreenListResponse,
    LibraryScreenDeleteDataResponse,
    LibraryScreenEstimateCostResponse,
    LibraryScreenListResultsResponse,
    LibraryScreenStartResponse,
    LibraryScreenStopResponse,
)
```

Methods:

- <code title="get /compute/v1/small-molecule/library-screen/{screen_id}">client.small_molecule.library_screen.<a href="./src/boltz_compute/resources/small_molecule/library_screen.py">retrieve</a>(screen_id, \*\*<a href="src/boltz_compute/types/small_molecule/library_screen_retrieve_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/library_screen_retrieve_response.py">LibraryScreenRetrieveResponse</a></code>
- <code title="get /compute/v1/small-molecule/library-screen">client.small_molecule.library_screen.<a href="./src/boltz_compute/resources/small_molecule/library_screen.py">list</a>(\*\*<a href="src/boltz_compute/types/small_molecule/library_screen_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/library_screen_list_response.py">SyncCursorPage[LibraryScreenListResponse]</a></code>
- <code title="post /compute/v1/small-molecule/library-screen/{screen_id}/delete-data">client.small_molecule.library_screen.<a href="./src/boltz_compute/resources/small_molecule/library_screen.py">delete_data</a>(screen_id) -> <a href="./src/boltz_compute/types/small_molecule/library_screen_delete_data_response.py">LibraryScreenDeleteDataResponse</a></code>
- <code title="post /compute/v1/small-molecule/library-screen/estimate-cost">client.small_molecule.library_screen.<a href="./src/boltz_compute/resources/small_molecule/library_screen.py">estimate_cost</a>(\*\*<a href="src/boltz_compute/types/small_molecule/library_screen_estimate_cost_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/library_screen_estimate_cost_response.py">LibraryScreenEstimateCostResponse</a></code>
- <code title="get /compute/v1/small-molecule/library-screen/{screen_id}/results">client.small_molecule.library_screen.<a href="./src/boltz_compute/resources/small_molecule/library_screen.py">list_results</a>(screen_id, \*\*<a href="src/boltz_compute/types/small_molecule/library_screen_list_results_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/library_screen_list_results_response.py">SyncCursorPage[LibraryScreenListResultsResponse]</a></code>
- <code title="post /compute/v1/small-molecule/library-screen">client.small_molecule.library_screen.<a href="./src/boltz_compute/resources/small_molecule/library_screen.py">start</a>(\*\*<a href="src/boltz_compute/types/small_molecule/library_screen_start_params.py">params</a>) -> <a href="./src/boltz_compute/types/small_molecule/library_screen_start_response.py">LibraryScreenStartResponse</a></code>
- <code title="post /compute/v1/small-molecule/library-screen/{screen_id}/stop">client.small_molecule.library_screen.<a href="./src/boltz_compute/resources/small_molecule/library_screen.py">stop</a>(screen_id) -> <a href="./src/boltz_compute/types/small_molecule/library_screen_stop_response.py">LibraryScreenStopResponse</a></code>

# Protein

## Design

Types:

```python
from boltz_compute.types.protein import (
    DesignRetrieveResponse,
    DesignListResponse,
    DesignDeleteDataResponse,
    DesignEstimateCostResponse,
    DesignListResultsResponse,
    DesignStartResponse,
    DesignStopResponse,
)
```

Methods:

- <code title="get /compute/v1/protein/design/{run_id}">client.protein.design.<a href="./src/boltz_compute/resources/protein/design.py">retrieve</a>(run_id, \*\*<a href="src/boltz_compute/types/protein/design_retrieve_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/design_retrieve_response.py">DesignRetrieveResponse</a></code>
- <code title="get /compute/v1/protein/design">client.protein.design.<a href="./src/boltz_compute/resources/protein/design.py">list</a>(\*\*<a href="src/boltz_compute/types/protein/design_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/design_list_response.py">SyncCursorPage[DesignListResponse]</a></code>
- <code title="post /compute/v1/protein/design/{run_id}/delete-data">client.protein.design.<a href="./src/boltz_compute/resources/protein/design.py">delete_data</a>(run_id) -> <a href="./src/boltz_compute/types/protein/design_delete_data_response.py">DesignDeleteDataResponse</a></code>
- <code title="post /compute/v1/protein/design/estimate-cost">client.protein.design.<a href="./src/boltz_compute/resources/protein/design.py">estimate_cost</a>(\*\*<a href="src/boltz_compute/types/protein/design_estimate_cost_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/design_estimate_cost_response.py">DesignEstimateCostResponse</a></code>
- <code title="get /compute/v1/protein/design/{run_id}/results">client.protein.design.<a href="./src/boltz_compute/resources/protein/design.py">list_results</a>(run_id, \*\*<a href="src/boltz_compute/types/protein/design_list_results_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/design_list_results_response.py">SyncCursorPage[DesignListResultsResponse]</a></code>
- <code title="post /compute/v1/protein/design">client.protein.design.<a href="./src/boltz_compute/resources/protein/design.py">start</a>(\*\*<a href="src/boltz_compute/types/protein/design_start_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/design_start_response.py">DesignStartResponse</a></code>
- <code title="post /compute/v1/protein/design/{run_id}/stop">client.protein.design.<a href="./src/boltz_compute/resources/protein/design.py">stop</a>(run_id) -> <a href="./src/boltz_compute/types/protein/design_stop_response.py">DesignStopResponse</a></code>

## LibraryScreen

Types:

```python
from boltz_compute.types.protein import (
    LibraryScreenRetrieveResponse,
    LibraryScreenListResponse,
    LibraryScreenDeleteDataResponse,
    LibraryScreenEstimateCostResponse,
    LibraryScreenListResultsResponse,
    LibraryScreenStartResponse,
    LibraryScreenStopResponse,
)
```

Methods:

- <code title="get /compute/v1/protein/library-screen/{screen_id}">client.protein.library_screen.<a href="./src/boltz_compute/resources/protein/library_screen.py">retrieve</a>(screen_id, \*\*<a href="src/boltz_compute/types/protein/library_screen_retrieve_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/library_screen_retrieve_response.py">LibraryScreenRetrieveResponse</a></code>
- <code title="get /compute/v1/protein/library-screen">client.protein.library_screen.<a href="./src/boltz_compute/resources/protein/library_screen.py">list</a>(\*\*<a href="src/boltz_compute/types/protein/library_screen_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/library_screen_list_response.py">SyncCursorPage[LibraryScreenListResponse]</a></code>
- <code title="post /compute/v1/protein/library-screen/{screen_id}/delete-data">client.protein.library_screen.<a href="./src/boltz_compute/resources/protein/library_screen.py">delete_data</a>(screen_id) -> <a href="./src/boltz_compute/types/protein/library_screen_delete_data_response.py">LibraryScreenDeleteDataResponse</a></code>
- <code title="post /compute/v1/protein/library-screen/estimate-cost">client.protein.library_screen.<a href="./src/boltz_compute/resources/protein/library_screen.py">estimate_cost</a>(\*\*<a href="src/boltz_compute/types/protein/library_screen_estimate_cost_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/library_screen_estimate_cost_response.py">LibraryScreenEstimateCostResponse</a></code>
- <code title="get /compute/v1/protein/library-screen/{screen_id}/results">client.protein.library_screen.<a href="./src/boltz_compute/resources/protein/library_screen.py">list_results</a>(screen_id, \*\*<a href="src/boltz_compute/types/protein/library_screen_list_results_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/library_screen_list_results_response.py">SyncCursorPage[LibraryScreenListResultsResponse]</a></code>
- <code title="post /compute/v1/protein/library-screen">client.protein.library_screen.<a href="./src/boltz_compute/resources/protein/library_screen.py">start</a>(\*\*<a href="src/boltz_compute/types/protein/library_screen_start_params.py">params</a>) -> <a href="./src/boltz_compute/types/protein/library_screen_start_response.py">LibraryScreenStartResponse</a></code>
- <code title="post /compute/v1/protein/library-screen/{screen_id}/stop">client.protein.library_screen.<a href="./src/boltz_compute/resources/protein/library_screen.py">stop</a>(screen_id) -> <a href="./src/boltz_compute/types/protein/library_screen_stop_response.py">LibraryScreenStopResponse</a></code>

# Admin

## Workspaces

Types:

```python
from boltz_compute.types.admin import (
    WorkspaceCreateResponse,
    WorkspaceRetrieveResponse,
    WorkspaceUpdateResponse,
    WorkspaceListResponse,
    WorkspaceArchiveResponse,
)
```

Methods:

- <code title="post /compute/v1/admin/workspaces">client.admin.workspaces.<a href="./src/boltz_compute/resources/admin/workspaces.py">create</a>(\*\*<a href="src/boltz_compute/types/admin/workspace_create_params.py">params</a>) -> <a href="./src/boltz_compute/types/admin/workspace_create_response.py">WorkspaceCreateResponse</a></code>
- <code title="get /compute/v1/admin/workspaces/{workspace_id}">client.admin.workspaces.<a href="./src/boltz_compute/resources/admin/workspaces.py">retrieve</a>(workspace_id) -> <a href="./src/boltz_compute/types/admin/workspace_retrieve_response.py">WorkspaceRetrieveResponse</a></code>
- <code title="post /compute/v1/admin/workspaces/{workspace_id}">client.admin.workspaces.<a href="./src/boltz_compute/resources/admin/workspaces.py">update</a>(workspace_id, \*\*<a href="src/boltz_compute/types/admin/workspace_update_params.py">params</a>) -> <a href="./src/boltz_compute/types/admin/workspace_update_response.py">WorkspaceUpdateResponse</a></code>
- <code title="get /compute/v1/admin/workspaces">client.admin.workspaces.<a href="./src/boltz_compute/resources/admin/workspaces.py">list</a>(\*\*<a href="src/boltz_compute/types/admin/workspace_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/admin/workspace_list_response.py">SyncCursorPage[WorkspaceListResponse]</a></code>
- <code title="post /compute/v1/admin/workspaces/{workspace_id}/archive">client.admin.workspaces.<a href="./src/boltz_compute/resources/admin/workspaces.py">archive</a>(workspace_id) -> <a href="./src/boltz_compute/types/admin/workspace_archive_response.py">WorkspaceArchiveResponse</a></code>

## APIKeys

Types:

```python
from boltz_compute.types.admin import APIKeyCreateResponse, APIKeyListResponse, APIKeyRevokeResponse
```

Methods:

- <code title="post /compute/v1/admin/api-keys">client.admin.api_keys.<a href="./src/boltz_compute/resources/admin/api_keys.py">create</a>(\*\*<a href="src/boltz_compute/types/admin/api_key_create_params.py">params</a>) -> <a href="./src/boltz_compute/types/admin/api_key_create_response.py">APIKeyCreateResponse</a></code>
- <code title="get /compute/v1/admin/api-keys">client.admin.api_keys.<a href="./src/boltz_compute/resources/admin/api_keys.py">list</a>(\*\*<a href="src/boltz_compute/types/admin/api_key_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/admin/api_key_list_response.py">SyncCursorPage[APIKeyListResponse]</a></code>
- <code title="post /compute/v1/admin/api-keys/{api_key_id}/revoke">client.admin.api_keys.<a href="./src/boltz_compute/resources/admin/api_keys.py">revoke</a>(api_key_id) -> <a href="./src/boltz_compute/types/admin/api_key_revoke_response.py">APIKeyRevokeResponse</a></code>

## Usage

Types:

```python
from boltz_compute.types.admin import UsageListResponse
```

Methods:

- <code title="get /compute/v1/admin/usage">client.admin.usage.<a href="./src/boltz_compute/resources/admin/usage.py">list</a>(\*\*<a href="src/boltz_compute/types/admin/usage_list_params.py">params</a>) -> <a href="./src/boltz_compute/types/admin/usage_list_response.py">SyncOpaqueCursorPage[UsageListResponse]</a></code>
