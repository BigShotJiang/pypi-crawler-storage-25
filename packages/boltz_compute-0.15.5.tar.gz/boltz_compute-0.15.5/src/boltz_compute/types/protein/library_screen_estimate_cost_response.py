# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["LibraryScreenEstimateCostResponse", "Breakdown"]


class Breakdown(BaseModel):
    application: Literal[
        "structure_and_binding",
        "small_molecule_design",
        "small_molecule_library_screen",
        "protein_design",
        "protein_library_screen",
    ]

    cost_per_unit_usd: str
    """Cost per unit as a decimal string"""

    num_units: int


class LibraryScreenEstimateCostResponse(BaseModel):
    breakdown: Breakdown

    disclaimer: str

    estimated_cost_usd: str
    """Estimated total cost as a decimal string"""
