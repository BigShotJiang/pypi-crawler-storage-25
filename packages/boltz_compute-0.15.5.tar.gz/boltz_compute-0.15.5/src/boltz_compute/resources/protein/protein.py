# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .design import (
    DesignResource,
    AsyncDesignResource,
    DesignResourceWithRawResponse,
    AsyncDesignResourceWithRawResponse,
    DesignResourceWithStreamingResponse,
    AsyncDesignResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from .library_screen import (
    LibraryScreenResource,
    AsyncLibraryScreenResource,
    LibraryScreenResourceWithRawResponse,
    AsyncLibraryScreenResourceWithRawResponse,
    LibraryScreenResourceWithStreamingResponse,
    AsyncLibraryScreenResourceWithStreamingResponse,
)

__all__ = ["ProteinResource", "AsyncProteinResource"]


class ProteinResource(SyncAPIResource):
    """
    Protein Engine — design novel protein binders and screen protein libraries against targets. Includes de novo protein design and library screening.
    """

    @cached_property
    def design(self) -> DesignResource:
        """Generate novel protein binders optimized for binding to a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return DesignResource(self._client)

    @cached_property
    def library_screen(self) -> LibraryScreenResource:
        """Screen an existing library of proteins against a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return LibraryScreenResource(self._client)

    @cached_property
    def with_raw_response(self) -> ProteinResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/boltz-bio/boltz-compute-api-python#accessing-raw-response-data-eg-headers
        """
        return ProteinResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ProteinResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/boltz-bio/boltz-compute-api-python#with_streaming_response
        """
        return ProteinResourceWithStreamingResponse(self)


class AsyncProteinResource(AsyncAPIResource):
    """
    Protein Engine — design novel protein binders and screen protein libraries against targets. Includes de novo protein design and library screening.
    """

    @cached_property
    def design(self) -> AsyncDesignResource:
        """Generate novel protein binders optimized for binding to a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return AsyncDesignResource(self._client)

    @cached_property
    def library_screen(self) -> AsyncLibraryScreenResource:
        """Screen an existing library of proteins against a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return AsyncLibraryScreenResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncProteinResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/boltz-bio/boltz-compute-api-python#accessing-raw-response-data-eg-headers
        """
        return AsyncProteinResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncProteinResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/boltz-bio/boltz-compute-api-python#with_streaming_response
        """
        return AsyncProteinResourceWithStreamingResponse(self)


class ProteinResourceWithRawResponse:
    def __init__(self, protein: ProteinResource) -> None:
        self._protein = protein

    @cached_property
    def design(self) -> DesignResourceWithRawResponse:
        """Generate novel protein binders optimized for binding to a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return DesignResourceWithRawResponse(self._protein.design)

    @cached_property
    def library_screen(self) -> LibraryScreenResourceWithRawResponse:
        """Screen an existing library of proteins against a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return LibraryScreenResourceWithRawResponse(self._protein.library_screen)


class AsyncProteinResourceWithRawResponse:
    def __init__(self, protein: AsyncProteinResource) -> None:
        self._protein = protein

    @cached_property
    def design(self) -> AsyncDesignResourceWithRawResponse:
        """Generate novel protein binders optimized for binding to a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return AsyncDesignResourceWithRawResponse(self._protein.design)

    @cached_property
    def library_screen(self) -> AsyncLibraryScreenResourceWithRawResponse:
        """Screen an existing library of proteins against a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return AsyncLibraryScreenResourceWithRawResponse(self._protein.library_screen)


class ProteinResourceWithStreamingResponse:
    def __init__(self, protein: ProteinResource) -> None:
        self._protein = protein

    @cached_property
    def design(self) -> DesignResourceWithStreamingResponse:
        """Generate novel protein binders optimized for binding to a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return DesignResourceWithStreamingResponse(self._protein.design)

    @cached_property
    def library_screen(self) -> LibraryScreenResourceWithStreamingResponse:
        """Screen an existing library of proteins against a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return LibraryScreenResourceWithStreamingResponse(self._protein.library_screen)


class AsyncProteinResourceWithStreamingResponse:
    def __init__(self, protein: AsyncProteinResource) -> None:
        self._protein = protein

    @cached_property
    def design(self) -> AsyncDesignResourceWithStreamingResponse:
        """Generate novel protein binders optimized for binding to a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return AsyncDesignResourceWithStreamingResponse(self._protein.design)

    @cached_property
    def library_screen(self) -> AsyncLibraryScreenResourceWithStreamingResponse:
        """Screen an existing library of proteins against a target structure.

        Results are scored by binding confidence (likelihood of protein-protein interaction) and structure confidence.
        """
        return AsyncLibraryScreenResourceWithStreamingResponse(self._protein.library_screen)
