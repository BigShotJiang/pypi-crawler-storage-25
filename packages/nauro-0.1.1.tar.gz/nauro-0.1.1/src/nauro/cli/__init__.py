"""Nauro CLI package."""
