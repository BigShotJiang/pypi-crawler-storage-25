::: llmeter.callbacks.cost.dimensions
