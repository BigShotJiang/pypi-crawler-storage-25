::: llmeter.callbacks.cost.model
