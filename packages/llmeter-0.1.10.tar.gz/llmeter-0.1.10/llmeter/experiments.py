# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Higher-level experiments (generally combining multiple Runs)

This module provides utilities to run more complex "experiments" that go beyond the scope of a
single [Run][llmeter.runner.Runner].
"""

import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from math import ceil
from typing import Callable, Literal

from tqdm.auto import tqdm
from upath import UPath as Path
from upath.types import ReadablePathLike, WritablePathLike

from .callbacks.base import Callback
from .endpoints.base import Endpoint
from .plotting import color_sequences, plot_heatmap, plot_load_test_results
from .prompt_utils import CreatePromptCollection
from .results import Result
from .runner import Runner
from .tokenizers import Tokenizer
from .utils import ensure_path

logger = logging.getLogger(__name__)

# using a custom env variable because the TQDM one (https://github.com/tqdm/tqdm/issues/612#issuecomment-2015702344) doesn't work reliably
_disable_tqdm = False
if os.getenv("LLMETER_DISABLE_ALL_PROGRESS_BARS") == "1":
    logger.info("Disabling tqdm progress bars")
    _disable_tqdm = True


@dataclass
class LoadTestResult:
    results: dict[int, Result]
    test_name: str
    output_path: WritablePathLike | None = None

    def plot_results(self, show: bool = True, format: Literal["html", "png"] = "html"):
        figs = plot_load_test_results(self)

        # add individual color sequence for each plot
        c_seqs = [
            color_sequences.Bluered,
            color_sequences.Turbo,
            color_sequences.Sunsetdark_r,
            color_sequences.Blackbody,
            color_sequences.Viridis,
            color_sequences.Plasma,
        ]

        for i, (_, f) in enumerate(figs.items()):
            f.update_layout(colorway=c_seqs[i % len(c_seqs)])

        if self.output_path is not None:
            output_path = ensure_path(self.output_path)
            # save figure to the output path
            output_path.parent.mkdir(parents=True, exist_ok=True)
            for k, f in figs.items():
                if format == "html":
                    f.write_html(output_path / f"{k}.{format}")
                else:
                    f.write_image(output_path / f"{k}.{format}")

        if show:
            [f.show() for _, f in figs.items()]
        return figs

    @classmethod
    def load(
        cls,
        load_path: ReadablePathLike | None,
        test_name: str | None = None,
        load_responses: bool = True,
    ) -> "LoadTestResult":
        """Load test results from a directory.

        Args:
            load_path: Directory path containing the load test results subdirectories
            test_name: Optional name for the test. If not provided, will use the directory name
            load_responses: Whether to load individual invocation responses. Defaults to True.
                When False, only summaries and pre-computed stats are loaded.

        Returns:
            LoadTestResult: A LoadTestResult object containing the loaded results

        Raises:
            FileNotFoundError: If load_path does not exist or is None/empty
            ValueError: If no results are found in the directory
        """
        if not load_path:
            raise FileNotFoundError("Load path cannot be None or empty")

        if not isinstance(load_path, Path):
            load_path = ensure_path(load_path)

        if not load_path.exists():
            raise FileNotFoundError(f"Load path {load_path} does not exist")

        results = [
            Result.load(x, load_responses=load_responses)
            for x in load_path.iterdir()
            if x.is_dir()
        ]

        if not results:
            raise ValueError(f"No results found in {load_path}")

        return LoadTestResult(
            results={r.clients: r for r in results},
            test_name=test_name or load_path.name,
            output_path=load_path.parent,
        )


@dataclass
class LoadTest:
    """Experiment to explore how performance changes at different concurrency levels.

    This experiment creates a series of Runs with different levels of concurrency, defined by
    ``sequence_of_clients``, and runs them one after the other.

    By default, each run sends a fixed number of requests (count-bound). Set ``run_duration``
    to run each concurrency level for a fixed number of seconds instead (time-bound), which
    gives a more realistic picture of sustained throughput.

    Attributes:
        endpoint (Endpoint): The LLM endpoint to test.
        payload (dict | list[dict]): The request payload(s) to send.
        sequence_of_clients (list[int]): Concurrency levels to test.
        min_requests_per_client (int): Minimum requests per client in count-bound mode.
        min_requests_per_run (int): Minimum total requests per run in count-bound mode.
        run_duration (int | float | None): When set, each concurrency level runs for this
            many seconds instead of a fixed request count. Mutually exclusive with
            ``min_requests_per_client`` / ``min_requests_per_run``.
        low_memory (bool): When ``True``, responses are written to disk but not kept in
            memory. Requires ``output_path``. Defaults to ``False``.
        progress_bar_stats (dict | None): Controls which live stats appear on the progress
            bar. See ``DEFAULT_DISPLAY_STATS`` in ``llmeter.live_display`` for the default.
        output_path (os.PathLike | str | None): Where to save results.
        tokenizer (Tokenizer | None): Optional tokenizer for token counting.
        test_name (str | None): Name for this test. Defaults to current date/time.
        callbacks (list[Callback] | None): Optional callbacks.

    Example::

        # Count-bound: 10 requests per client at each concurrency level
        load_test = LoadTest(
            endpoint=my_endpoint,
            payload=sample_payload,
            sequence_of_clients=[1, 5, 10, 20],
            min_requests_per_client=10,
            output_path="outputs/load_test",
        )
        result = await load_test.run()
        result.plot_results()

        # Time-bound: 60 seconds per concurrency level
        load_test = LoadTest(
            endpoint=my_endpoint,
            payload=sample_payload,
            sequence_of_clients=[1, 5, 10, 20],
            run_duration=60,
            output_path="outputs/load_test",
        )
        result = await load_test.run()

        # Time-bound with low-memory mode for large-scale tests
        load_test = LoadTest(
            endpoint=my_endpoint,
            payload=sample_payload,
            sequence_of_clients=[1, 5, 10, 20, 50],
            run_duration=120,
            low_memory=True,
            output_path="outputs/large_load_test",
        )
        result = await load_test.run()
    """

    endpoint: Endpoint
    payload: dict | list[dict]
    sequence_of_clients: list[int]
    min_requests_per_client: int = 1
    min_requests_per_run: int = 10
    run_duration: int | float | timedelta | None = None
    low_memory: bool = False
    progress_bar_stats: dict[str, str | tuple[str, str]] | None = None
    output_path: WritablePathLike | None = None
    tokenizer: Tokenizer | None = None
    test_name: str | None = None
    callbacks: list[Callback] | None = None

    def __post_init__(self) -> None:
        self._test_name = self.test_name or f"{datetime.now():%Y%m%d-%H%M}"

    def _get_n_requests(self, clients):
        if clients * self.min_requests_per_client < self.min_requests_per_run:
            return int(ceil(self.min_requests_per_run / clients))
        return int(self.min_requests_per_client)

    async def run(self, output_path: WritablePathLike | None = None):
        """Run the load test across all configured concurrency levels.

        Creates a :class:`~llmeter.runner.Runner` and iterates through
        ``sequence_of_clients``, running one test per concurrency level. In
        time-bound mode (``run_duration`` is set), each level runs for a fixed
        duration. In count-bound mode, each level sends a fixed number of
        requests per client.

        Args:
            load_path: Optional (local or remote) folder to save results. If provided, individual
            Run results will be written to `{output_path}/{test_name}/{NNNNN-clients}` subfolders.
            Default: `self.output_path` if set, else no files will be saved.

        Returns:
            LoadTestResult: A result object containing one
            :class:`~llmeter.results.Result` per concurrency level, keyed by
            client count.

        Example::

            load_test = LoadTest(
                endpoint=my_endpoint,
                payload=sample_payload,
                sequence_of_clients=[1, 5, 10],
                run_duration=30,
            )
            result = await load_test.run(output_path="outputs/my_test")

            # Access individual results by client count
            result.results[5].stats["requests_per_minute"]

            # Plot all standard charts
            result.plot_results()
        """
        output_path = ensure_path(output_path or self.output_path)
        if output_path:
            test_output_path = output_path / self._test_name
        else:
            test_output_path = None
        _runner = Runner(
            endpoint=self.endpoint,
            tokenizer=self.tokenizer,
            output_path=test_output_path,
        )

        self._results = []
        for c in tqdm(
            self.sequence_of_clients, desc="Configurations", disable=_disable_tqdm
        ):
            if self.run_duration is not None:
                result = await _runner.run(
                    payload=self.payload,
                    clients=c,
                    run_duration=self.run_duration,
                    run_name=f"{c:05.0f}-clients",
                    callbacks=self.callbacks,
                    low_memory=self.low_memory,
                    progress_bar_stats=self.progress_bar_stats,
                    output_path=test_output_path,
                )
            else:
                result = await _runner.run(
                    payload=self.payload,
                    clients=c,
                    n_requests=self._get_n_requests(c),
                    run_name=f"{c:05.0f}-clients",
                    callbacks=self.callbacks,
                    low_memory=self.low_memory,
                    progress_bar_stats=self.progress_bar_stats,
                    output_path=test_output_path,
                )
            self._results.append(result)

        return LoadTestResult(
            results={r.clients: r for r in self._results},
            test_name=self._test_name,
            output_path=test_output_path,
        )


@dataclass
class LatencyHeatmap:
    """
    Experiment to measure how latency varies by input and output token count

    This experiment uses a source text file to generate input prompts/payloads of different
    lengths, and measures how response time varies with both the input lengths and output/response
    lengths.

    Attributes:
        endpoint (Endpoint): The LLM endpoint to test.
        source_file (UPath | str): The source file from which prompts of different lengths will be
            sampled (see `llmeter.prompt_utils.CreatePromptCollection` for details).
        clients (int): The number of concurrent clients (requests) to use for the experiment. Note
            that using a high number of concurrent clients could impact observed latency.
        output_path (UPath | str | None): The (local or Cloud e.g. `s3://...`) path to save the
            results.
        input_lengths (Sequence[int]): The *approximate* input/prompt lengths to test. Since the
            locally-available `tokenizer` will often differ from the endpoint's own token counting,
            it's typically not possible to generate prompts with the exact specified token counts.
        output_lengths (Sequence[int]): The *target* output lengths to test. Since generation may
            stop early for certain prompts, and some endpoints may not report exact token counts in
            their responses, the results may not correspond exactly to these targets.
        requests_per_combination (int): The number of requests to make *for each combination* of
            input and output lengths.
        create_payload_fn (Callable | None): A function to create the actual endpoint payload for
            each invocation, from the sampled text prompt. Typically, you'll want to specify a
            prefix for your prompt in either this or the `create_payload_kwargs`. If not set, the
            endpoint's default `create_payload` method will be used.
        create_payload_kwargs (Dict): Keyword arguments to pass to the `create_payload_fn`.
        tokenizer (Tokenizer | None): A tokenizer to be used for sampling prompts of the specified
            lengths, and also estimating the generated output lengths if necessary for your
            endpoint. If not set, the `llmeter.tokenizers.DummyTokenizer` will be used.
    """

    endpoint: Endpoint
    source_file: ReadablePathLike
    clients: int = 4
    output_path: WritablePathLike | None = None
    input_lengths: list[int] = field(default_factory=lambda: [10, 50, 200, 500])
    output_lengths: list[int] = field(default_factory=lambda: [128, 256, 512, 1024])
    requests_per_combination: int = 1
    create_payload_fn: Callable[..., list[dict] | dict] | None = None
    create_payload_kwargs: dict = field(default_factory=dict)
    tokenizer: Tokenizer | None = None

    def __post_init__(self) -> None:
        _prompt_collection = CreatePromptCollection(
            requests_per_combination=self.requests_per_combination,
            input_lengths=self.input_lengths,
            output_lengths=self.output_lengths,
            source_file=ensure_path(self.source_file),
            tokenizer=self.tokenizer,  # type: ignore
        )

        self.create_payload_fn = self.create_payload_fn or self.endpoint.create_payload
        self.payload = _prompt_collection.create_collection()
        self.payload = [
            self.create_payload_fn(
                input_text, max_tokens=max_new_tokens, **self.create_payload_kwargs
            )
            for input_text, max_new_tokens in self.payload
        ]

        self._runner = Runner(
            endpoint=self.endpoint,
            output_path=ensure_path(self.output_path)
            if self.output_path is not None
            else None,
            tokenizer=self.tokenizer,
        )

    async def run(self, output_path=None):
        # Handle None output_path properly
        final_output_path = output_path or self.output_path
        if final_output_path is not None:
            final_output_path = ensure_path(final_output_path)

        heatmap_results = await self._runner.run(
            payload=self.payload,
            clients=self.clients,
            n_requests=len(self.input_lengths)
            * len(self.output_lengths)
            * self.requests_per_combination
            // self.clients,
            output_path=final_output_path,
        )
        self._results = heatmap_results
        return heatmap_results

    def plot_heatmaps(
        self, n_bins_x: int | None, n_bins_y: int | None, show: bool = True
    ):
        if not self._results:
            raise ValueError("No results to plot")
        f1 = plot_heatmap(
            self._results,
            "time_to_first_token",
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
            # output_path=self._results.output_path,
            show_scatter=True,
        )

        f2 = plot_heatmap(
            self._results,
            "time_to_last_token",
            n_bins_x=n_bins_x,
            n_bins_y=n_bins_y,
            # output_path=self._results.output_path,
            show_scatter=True,
        )

        if show:
            f1.show()
            f2.show()

        return f1, f2
