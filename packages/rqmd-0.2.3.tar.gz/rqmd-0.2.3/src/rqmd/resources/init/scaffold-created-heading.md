Initialized requirement scaffold:
