import os

from dotenv import load_dotenv


def load_env_recursive(
    start_env_file: str,
    prefix: str = "PRONTO_",
    override: bool = False,
    _loaded: set[str] | None = None,
) -> None:
    """
    Recursively load environment variables from a tree of env files.

    Parses `start_env_file` line by line. When an `ENV_FILE` key is found, it
    immediately recurses depth-first into that file before continuing with the
    remaining lines. This allows one file to reference many others. Relative
    paths in `ENV_FILE` are resolved against the directory of the current file.
    Cycle detection prevents infinite loops.

    :param start_env_file: The env file to load.
    :param prefix: The prefix prepended to every key in `os.environ`.
    :param override: If True, loaded values overwrite existing environment variables.
    """
    if _loaded is None:
        _loaded = set()

    resolved = os.path.abspath(start_env_file)
    if resolved in _loaded:
        return
    _loaded.add(resolved)

    base_dir = os.path.dirname(resolved)

    with open(resolved) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key == "ENV_FILE" and value:
                path = value if os.path.isabs(value) else os.path.join(base_dir, value)
                load_env_recursive(
                    path, prefix=prefix, override=override, _loaded=_loaded
                )
            else:
                env_key = prefix + key
                if override or env_key not in os.environ:
                    os.environ[env_key] = value

    load_dotenv(resolved, override=override)
