import json
import re
from pathlib import Path

_TEMPLATES_DIR = Path(__file__).parent / "templates"

_PROFILE_TEMPLATES: dict[str, list[str]] = {
    "fastapi": ["python_module", "fastapi", "pytest"],
}

AVAILABLE_PROFILES = list(_PROFILE_TEMPLATES.keys())


def _load_template(name: str) -> dict:
    return json.loads((_TEMPLATES_DIR / f"{name}.json").read_text())


def _read_launch_json(path: Path) -> dict:
    if not path.exists():
        return {"version": "0.2.0", "configurations": []}
    text = path.read_text()
    # strip single-line comments so json.loads can parse VS Code's launch.json
    text = re.sub(r"//[^\n]*", "", text)
    return json.loads(text)


def install_profile(profile: str, project_dir: Path) -> None:
    if profile not in _PROFILE_TEMPLATES:
        raise ValueError(
            f"Unknown profile '{profile}'. Available: {AVAILABLE_PROFILES}"
        )

    vscode_dir = project_dir / ".vscode"
    vscode_dir.mkdir(exist_ok=True)
    launch_path = vscode_dir / "launch.json"

    data = _read_launch_json(launch_path)
    configs: list[dict] = data.setdefault("configurations", [])
    existing_names = {c["name"] for c in configs}

    added = []
    for template_name in _PROFILE_TEMPLATES[profile]:
        template = _load_template(template_name)
        if template["name"] in existing_names:
            print(f"  skip  '{template['name']}' (already exists)")
        else:
            configs.append(template)
            existing_names.add(template["name"])
            added.append(template["name"])
            print(f"  add   '{template['name']}'")

    launch_path.write_text(json.dumps(data, indent=4) + "\n")

    if added:
        print(f"\nWritten to {launch_path.relative_to(project_dir)}")
    else:
        print("\nNothing to add.")
