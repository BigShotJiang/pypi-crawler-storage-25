import argparse
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(prog="pronto-utils")
    subparsers = parser.add_subparsers(dest="command")

    vscode = subparsers.add_parser("vscode", help="Install VS Code debug configs")
    vscode.add_argument(
        "profile",
        help="Debug profile to install (e.g. fastapi)",
    )
    vscode.add_argument(
        "--dir",
        default=".",
        help="Project directory (default: current directory)",
    )

    args = parser.parse_args()

    if args.command == "vscode":
        from pronto_utils.v1.devkit.vscode import AVAILABLE_PROFILES, install_profile

        if args.profile not in AVAILABLE_PROFILES:
            print(
                f"Unknown profile '{args.profile}'. Available: {', '.join(AVAILABLE_PROFILES)}",
                file=sys.stderr,
            )
            sys.exit(1)

        install_profile(args.profile, Path(args.dir).resolve())
    else:
        parser.print_help()
        sys.exit(1)
