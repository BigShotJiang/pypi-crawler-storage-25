# CI/CD Setup

## How it works

| Trigger | Workflow | Result |
|---|---|---|
| Push to any branch (except `release`), or PR | `ci.yml` | test + lint + build check |
| Push to `release` branch | `publish.yml` | publish to TestPyPI |
| Push tag `v*` to `main` | `publish.yml` | publish to PyPI (prod) |

## Versioning (hatch-vcs)

Versions are derived automatically from git tags — never edit `pyproject.toml` manually.

| State | Example version |
|---|---|
| On a tag `v0.2.0` | `0.2.0` |
| 3 commits after tag | `0.2.0.dev3` |

Each commit to `release` gets a unique `0.x.y.devN`, so TestPyPI never sees a duplicate version.

## One-time PyPI trusted publisher setup

No tokens required. GitHub authenticates to PyPI via OIDC.

### TestPyPI

1. Go to [test.pypi.org/manage/account/publishing](https://test.pypi.org/manage/account/publishing)
2. Add a new publisher:
   - **PyPI project name:** `pronto-utils`
   - **Owner:** your GitHub username or org
   - **Repository:** `pronto-utils` (or whatever the repo is named)
   - **Workflow filename:** `publish.yml`
   - **Environment name:** `testpypi`

### PyPI (prod)

1. Go to [pypi.org/manage/account/publishing](https://pypi.org/manage/account/publishing)
2. Add a new publisher with the same fields, but **Environment name:** `pypi`

### GitHub environments

In your GitHub repo go to **Settings → Environments** and create two environments: `testpypi` and `pypi`.

You can optionally add a required reviewer to the `pypi` environment for an extra confirmation gate before prod releases.

## Release workflow

```
# Work on a feature
git checkout -b my-feature
# ... make changes ...
git push origin my-feature   # CI runs: test + lint + build

# Merge to main via PR (CI runs again on the PR)

# Promote to release branch for TestPyPI
git checkout -b release/0.2.0
git push origin release/0.2.0   # publishes 0.x.y.devN to TestPyPI

# When ready to ship: tag on main
git checkout main
git tag v0.2.0
git push origin v0.2.0       # publishes 0.2.0 to PyPI prod
```
