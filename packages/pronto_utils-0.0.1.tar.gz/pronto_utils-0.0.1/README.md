# pronto-utils

Shared Python utilities for your python projects.

## What's included

**`pronto_utils.v1`** — stable public API:

- `load_env_recursive(start_env_file, prefix, override)` — loads a tree of `.env` files depth-first, following `ENV_FILE` pointers between files. Useful for projects with layered or environment-specific config.
- `get_required_env(key)` — reads an env var and raises a clear `ValueError` if it's missing, rather than silently returning `None`.

**`pronto-utils` CLI**:

- `pronto-utils vscode <profile>` — installs VS Code debug launch configs into a project directory (e.g. `fastapi` profile).

## Installation

```bash
pip install pronto-utils
```

Or, for local development with editable install:

```bash
pip install -e ".[dev]"
```

## Usage

```python
from pronto_utils.v1 import load_env_recursive, get_required_env

load_env_recursive(".env")
db_url = get_required_env("DATABASE_URL")
```

## Development

Run tests:

```bash
pytest
```

## Versioning

Versions are derived from git tags via [hatch-vcs](https://github.com/ofek/hatch-vcs). The file `src/pronto_utils/_version.py` is auto-generated at build time and is not tracked in version control — the git tag is the source of truth.

To release a new version, tag a commit and build:

```bash
git tag v0.2.0
hatch build
```
