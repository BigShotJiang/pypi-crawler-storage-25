import pytest
from pronto_utils.v1 import get_required_env


def test_returns_value(monkeypatch):
    monkeypatch.setenv("MY_KEY", "my_value")
    assert get_required_env("MY_KEY") == "my_value"


def test_raises_when_missing(monkeypatch):
    monkeypatch.delenv("MY_KEY", raising=False)
    with pytest.raises(ValueError, match="MY_KEY"):
        get_required_env("MY_KEY")
