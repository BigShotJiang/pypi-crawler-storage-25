import os
from pathlib import Path

import pytest
from pronto_utils.v1 import load_env_recursive

FIXTURES = Path(__file__).parent / "fixtures"

PREFIXED_KEYS = [
    "PRONTO_APP_NAME",
    "PRONTO_APP_ENV",
    "PRONTO_DB_HOST",
    "PRONTO_DB_PORT",
    "PRONTO_CACHE_HOST",
    "PRONTO_CACHE_TTL",
]


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    for key in PREFIXED_KEYS:
        monkeypatch.delenv(key, raising=False)


def test_loads_all_files_in_tree():
    load_env_recursive(str(FIXTURES / "start.env"))

    assert os.environ["PRONTO_APP_NAME"] == "myapp"
    assert os.environ["PRONTO_APP_ENV"] == "production"
    assert os.environ["PRONTO_DB_HOST"] == "localhost"
    assert os.environ["PRONTO_DB_PORT"] == "5432"
    assert os.environ["PRONTO_CACHE_HOST"] == "redis.local"
    assert os.environ["PRONTO_CACHE_TTL"] == "300"


def test_does_not_override_existing(monkeypatch):
    monkeypatch.setenv("PRONTO_DB_HOST", "existing_host")
    load_env_recursive(str(FIXTURES / "start.env"), override=False)
    assert os.environ["PRONTO_DB_HOST"] == "existing_host"


def test_override_replaces_existing(monkeypatch):
    monkeypatch.setenv("PRONTO_DB_HOST", "existing_host")
    load_env_recursive(str(FIXTURES / "start.env"), override=True)
    assert os.environ["PRONTO_DB_HOST"] == "localhost"


def test_cycle_detection(tmp_path):
    a = tmp_path / "a.env"
    b = tmp_path / "b.env"
    a.write_text(f"KEY_A=1\nENV_FILE={b}\n")
    b.write_text(f"KEY_B=2\nENV_FILE={a}\n")

    load_env_recursive(str(a))

    assert os.environ.get("PRONTO_KEY_A") == "1"
    assert os.environ.get("PRONTO_KEY_B") == "2"
