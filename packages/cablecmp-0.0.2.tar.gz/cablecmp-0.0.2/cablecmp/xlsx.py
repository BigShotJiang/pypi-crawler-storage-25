import cablecmp.common as com
from zipfile import ZipFile
from lxml import etree
from openpyxl import load_workbook
from openpyxl.worksheet.filters import (FilterColumn, Filters, AutoFilter, SortState, SortCondition)
import sys

def find_missing_tags(args, tags, ws):
    cs = ws.tables[args.table_name]
    out_tags = get_tags(args, args.output, ignore_hidden=False)[0]
    for t in tags:
        if t not in out_tags:
            print("Warning, couldn't find tag '{}' from file '{}' in output"
                  .format(t, tags[t]), file=sys.stderr)


def get_tags(args, file_path, ignore_hidden=True, cmp=None):

    wb = load_workbook(filename = file_path, data_only = True)
    ws = wb.active
    if args.table_name not in ws.tables:
        print("Warning, no table called '{}' in sheet '{}'"
              .format(args.table_name, file_path), file=sys.stderr)
        return ({},{})

    cs = ws.tables[args.table_name] 
    
    visible_rows = get_visible_rows(file_path, ignore_hidden=ignore_hidden)

    start_cords = cs.ref.split(':')
    end_row = ws[start_cords[1]].row
    start_row = ws[start_cords[0]].row + 1
    col = get_cols_i(args, ws, [args.tag_title.upper()])
    if len(col) == 0:
        print("Warning, Couldn't find column titled '{}' in sheet '{}'"
              .format(args.tag_title, file_path), file=sys.stderr)
        return ({},{})
    col = col[0]

    tags = {}
    discarded = {}
    for r in visible_rows:
        if r < start_row:
            continue
        if r > end_row:
            break
        # Strip whitespace from tag, and make upper case
        v = str(ws.cell(row=r, column=col).value).upper().replace(" ", "")
        if v in tags or v == "NONE":
            continue

        if not ignore_hidden or check_row_black(args, ws, r):
            cts = [args.tag_title]
            cts.extend(args.column_titles)
            row_dta = get_rows(args, ws, [r], cts)[0]
            com.print_row_diff(row_dta, v, cmp, file_path)

            tags[v] = file_path
        else:
            fname = file_path.split("/")[-1]
            discarded[v] = fname
        #print(ws.cell(row=r, column=col).value)
    return (tags, discarded)

def get_rows(args, ws, rows, col_titles):
    cs = ws.tables[args.table_name] 
    start_cords = cs.ref.split(':')
    end_row = ws[start_cords[1]].row
    start_row = ws[start_cords[0]].row + 1
    if rows == None:
        rows = range(start_row, end_row + 1)

    cols = get_cols_i(args, ws, col_titles)
    row_lst = []

    for r in rows:
        if r < start_row:
            continue
        if r > end_row:
            break
        row = []
        for c in cols:
            row.append(ws.cell(row=r, column=c).value)
        row_lst.append(row)
    return row_lst

def get_cols_i(args, ws, title_lst):
    # Convert title_lst to uppercase
    if title_lst != None:
        title_lst = [x.upper() for x in title_lst]
    cs = ws.tables[args.table_name]
    # Find table start column
    i = ws[cs.ref.split(':')[0]].column
    # find offset to specified columns
    ret = []
    for col in cs.tableColumns:
        if title_lst == None or col.name.upper() in title_lst:
            ret.append(i)
        i += 1

    return ret


def get_cols_i_dict(args, ws, title_lst):
    out = {}
    for t in title_lst:
        cols_i_lst = get_cols_i(args, ws, [t])
        # Make sure we could actually find a column with matching tag.
        if len(cols_i_lst) == 1:
            out[t] = cols_i_lst[0]
    return out


def check_row_black(args, ws, r):
    cols = get_cols_i(args, ws, None)
    for c in cols:
        dta = ws.cell(row=r, column=c).fill.fgColor
        if dta.theme == 1:
            return False
    return True

def get_visible_rows(file_path, ignore_hidden=True):
    # Data about hidden rows doesn't seem to make it into openpyxl...
    # Parse the xlsx file to find which rows are actually visible.
    archive = ZipFile(file_path, 'r')
    src = archive.read(get_sheet_path(archive))
    root = etree.fromstring(src)
    sheet_data = _rec_traverse_xml_path(root, ["sheetData"])
    visible = []
    for e in sheet_data:
        if ignore_hidden and "hidden" in e.keys() and e.attrib["hidden"]:
            continue
        visible.append(int(e.attrib['r']))

    return visible


def _rec_traverse_xml_path(element, path_lst):
    if len(path_lst) == 0:
        return element

    child_name = path_lst[0]
    for e in element:
        if etree.QName(e).localname == child_name:
            return _rec_traverse_xml_path(e, path_lst[1:])
    return None


def get_sheet_path(archive):
    src = archive.read("xl/workbook.xml")
    root = etree.fromstring(src)
    workbookview = _rec_traverse_xml_path(root, ["bookViews", "workbookView"])
    try:
        i = int(workbookview.attrib["activeTab"]) + 1
    except:
        i = 1
    return 'xl/worksheets/sheet{}.xml'.format(i)

def get_col_titles(cs):
    return cs.column_names



def filter_output(args, tags):
    wb = load_workbook(filename = args.output, data_only = True)
    ws = wb.active
    cs = ws.tables[args.table_name]
    find_missing_tags(args, tags, ws)

    # Clear Autofilter from Table
    ws.auto_filter.filterColumn = []
    ws.auto_filter.sortState = None
    cs.autoFilter.filterColumn = []
    filters = cs.autoFilter
    # Set filter ref
    filters.ref = cs.ref

    # Excel uses 0-index here, but nowhere else... 
    # Also the column appears to be a refrence from the start of the table, not the sheet
    # Therefore we subtract column of table start from our computed tag column.
    col_n = get_cols_i(args, ws, [args.tag_title.upper()])[0] - ws[cs.ref.split(':')[0]].column
    col = FilterColumn(colId=col_n)
    col.filters = Filters(filter=list(tags.keys()))
    filters.filterColumn.append(col)
    cs.autoFilter.add_sort_condition(cs.ref)

    # Openpyxl doesnt seem to do anything with sort state.  Find the ref's here.
    ss_ref = "{ltr1}{r1}:{ltr2}{r2}".format(
            ltr1 = ws[cs.ref.split(':')[0]].column_letter,
            r1 = ws[cs.ref.split(':')[0]].row + 1,
            ltr2 = ws[cs.ref.split(':')[1]].column_letter,
            r2 = ws[cs.ref.split(':')[1]].row
            )

    sc_ref = "{ltr}{r1}:{ltr}{r2}".format(
            ltr = ws[cs.ref.split(':')[0]].column_letter,
            r1 = ws[cs.ref.split(':')[0]].row + 1,
            r2 = ws[cs.ref.split(':')[1]].row
            )
    ss = SortState(ref=ss_ref, sortCondition=[SortCondition(ref=sc_ref, customList="")])
    cs.autoFilter.sortState = ss

    wb.save(args.output)

def get_src_dict(args, path):
    ws = load_workbook(filename = path, data_only = True).active
    cs = ws.tables[args.table_name] 

    src_dict = {}   # {Tag: {Col_name: Value}}

    start_cords = cs.ref.split(':')
    end_row = ws[start_cords[1]].row
    start_row = ws[start_cords[0]].row + 1

    cts = args.column_titles
    cti = get_cols_i_dict(args, ws, cts)
    rows = get_visible_rows(path)
    # Print warning if not all columns could be found.
    _check_cti(cts, cti, path)

    for row in rows:
        if not check_row_black(args, ws, row) or row < start_row:
            continue
        if row > end_row:
            break

        tag = ws.cell(row=row, column=cti[args.tag_title]).value
        tag_dict = {}

        for col_n in cti.keys():
            if col_n == args.tag_title:
                continue
            tag_dict[col_n] = ws.cell(row=row, column=cti[col_n]).value

        if tag in src_dict:
            print("Warning, Duplicate cable tag found: '{}'"
                  .format(tag), file=sys.stderr)
        src_dict[tag] = tag_dict
    return src_dict

def _check_cti(cts, cti, path):
    if len(cts) == len(cti):
        return True
    ret = True
    for ct in cts:
        try:
            cti[ct]
        except KeyError:
            ret = False
            print("Warning, Column: '{}' not found in file '{}'"
                  .format(ct, path), file=sys.stderr)
    return ret

def update_wb(args, src_dict):
    wb = load_workbook(filename=args.output, data_only=True)
    ws = wb.active
    cs = ws.tables[args.table_name] 

    start_cords = cs.ref.split(':')
    end_row = ws[start_cords[1]].row 
    start_row = ws[start_cords[0]].row + 1
    
    cts = args.column_titles
    cti = get_cols_i_dict(args, ws, cts)
    
    _check_cti(cts, cti, args.output)
    
    updated_tags = []
    rows = get_visible_rows(args.output, ignore_hidden=False)

    for row in rows:
        if row < start_row:
            continue
        if row > end_row:
            break

        tag = ws.cell(row=row, column=cti[args.tag_title]).value 

        if tag in src_dict:
            updated_tags.append(tag)
            for col_n in src_dict[tag].keys():
                val = src_dict[tag][col_n]
                try:
                    ws.cell(row=row, column=cti[col_n], value=val)
                except KeyError:
                    print("Warning, could not update column: '{}' in output file: '{}'"
                          .format(col_n, args.output), file=sys.stderr)
    wb.save(args.output)

    return updated_tags


