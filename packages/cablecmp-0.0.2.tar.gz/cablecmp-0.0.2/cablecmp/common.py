import os
import glob
import sys

def get_in_files(args, ext_lst):
    files = []
    for path in args.input:
        if os.path.isdir(path):
            # Get all files with relevant extension in specified dir
            dir_files = []
            for ext in ext_lst:
                dir_files.extend(glob.glob(path +'/**/*' + ext, recursive=True))
            if len(dir_files) == 0:
                print("Error, Directory '{}' does not contain any files " \
                      "with extensions {}".format(path, ext_lst), file=sys.stderr)
                exit(-1)
            files.extend(dir_files)
        
        elif os.path.isfile(path):
            # Check Extension type
            match = False
            for ext in ext_lst:
                if path[len(ext) * -1:] == ext:
                    match = True
                    break
            if not match:
                print("Error, File '{}' must have extension {}"
                      .format(path, ext_lst), file=sys.stderr)
                exit(-1)
            # Append file
            files.append(path)
        else:
            print("Error, path '{}' does not exist".format(path), file=sys.stderr)
            exit(-1)

    return files

def print_row_diff(row_dta, tag, cmp, file_path):
    if cmp == None or row_dta in cmp:
        return

    match = None
    for cmp_r in cmp:
        if str(cmp_r[0]).upper().replace(" ", "") == tag:
            match = cmp_r
            break
    if match != None:
        print("Warning, Tag '{}' from file '{}' has columns that do not match output file"
                      .format(tag, file_path), file=sys.stderr)
        print("{} vs {}".format(row_dta, match))

def print_discarded(discarded):
    if len(discarded) == 0:
        return

    print("\nTags discarded due to blacked out cells:", file=sys.stderr)
    for t in discarded:
        print("TAG: '{}'    FILE: '{}'".format(t, discarded[t]), file=sys.stderr)

def print_duplicates(dup):
    if len(dup) == 0:
        return

    print("\nDuplicate tags:", file=sys.stderr)
    for t in dup:
        print("TAG: '{}'    FILES: '{}'".format(t, dup[t]), file=sys.stderr)

def check_update(updated_tags, src_dict):
    for tag in src_dict.keys():
        if tag not in updated_tags:
            print("Warning, tag: '{}' not updated!"
                  .format(tag), file=sys.stderr)

def check_sd_upd(src_dict, new_sd):
    for tag in new_sd.keys():
        if tag in src_dict:
            print("Warning, duplicate tag found: '{}'"
            .format(tag), file=sys.stderr)
