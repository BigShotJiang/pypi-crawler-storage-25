from openpyxl import load_workbook
import cablecmp.xlsx as xlsx
import cablecmp.common as com
import cablecmp.csv as cc_csv
#import xlsx as xlsx
#import common as com
#import csv as cc_csv
import argparse
import sys
import csv_diff

def parse_args():
    parser = argparse.ArgumentParser(
        prog="CableComp",
        description="Script for comparing Cable schedules in 'xlsx' format." \
                    "take 1 or more input Schedules, and filter output sheet to" \
                    "include/exclude tags found in input files." \
                    "Output Schedules to csv, with option to diff files, if only 2 were specified.",
        epilog="Tristan Carlson (2026)"
    )

    parser.add_argument("-i", "--input", action='extend', nargs='*', required= True, 
        help="Specify One or more input files.  If a directory is given, it " \
             "will be recursively searched for '.xlsx' files, and all will be " \
             "taken as inputs. Can be specified more than once."
    )
    parser.add_argument("-o", "--output", action="store",
        help="Specify exactly one output file.  If '-f' (default) is specified," \
             " this file will be filtered.  Likewise this file will contain " \
             "csv output if '-c' is specified."
    )
    parser.add_argument("-f", "--filter", action='store_true', default=False, 
        help="Default operation mode.  Filter the output file to include only " \
             "tags from the input files.  Output file must be of type '.xlsx'"
    )
    parser.add_argument("-c", "--csv",  action='store_true',
        help="Operation mode: Output to csv format.  Input files will be combined and output to csv format."
    )
    parser.add_argument("-d", "--diff", action='store_true', 
        help="Operation mode: Produce diff between 2 files.  Exactly 2 input " \
             "files must be specified.  Input files must be '.csv'." \
             "Output Defaults to stdout, but can be written to file if '-o' is specified."
    )
    parser.add_argument("-u", "--update", action='store_true',
        help="Operation mode: Copy values in output sheet from values in input sheet." \
             "Defaults to all columns, but if -t is specified, only those columns" \
             "will be updated." 
    )
    parser.add_argument("-t", "--column-titles", nargs='*', action='extend', default=[],
        help="Column titles to include.  If used in csv mode, only specified columns " \
             "will be output to csv. Otherwise all columns will be included." \
             "If used in filter mode, it will verify tags have matching data " \
             "with the output in the specified columns"
    )
    parser.add_argument("-T", "--tag-title", nargs = 1, default='CABLE TAG NO.', 
        help= "Specify the title of the column containing cable tags."
    )
    parser.add_argument("-n", "--table-name", nargs = 1, default='CableSchedule', 
        help= "Specify the name of the table containing the cable schedule."
    )
    parser.add_argument("-p", "--print-tags", action='store_true', 
        help= "print all cable tags found in input to stdout, and exit."
    )
    parser.add_argument("-v", "--verify-columns", nargs = '*', 
        help= "In filter mode, verify that the specified columns are identical " \
              "between the input and output files.  If there is a deviation, " \
              "produce a warning to stderr.  If this option is not specified, " \
              "all columns from the input will be verified against the output"
    )
    parser.add_argument("-V", "--verbose", action='store_true', default=False, 
        help= "Output stats about blacked out cells and duplicates to stderr"
    )

    return parser.parse_args()

def filter(args):
    file_paths = com.get_in_files(args, ['.xlsx', '.csv'])

    tags = {}           # {'tag':'path', ...}
    discarded = {}      # {'tag':'path', ...}
    duplicates = {}     # {'tag':['path1', 'path2', ...], ...}
    output_dta = None
    if args.column_titles:
        ws = load_workbook(filename = args.output, data_only = True).active
        output_rows = xlsx.get_visible_rows(args.output, ignore_hidden=False)
        cts = [args.tag_title]
        cts.extend(args.column_titles)

        output_dta = xlsx.get_rows(args, ws, output_rows, cts)
        print("od =", output_dta[-1])

    for path in file_paths:
        if path[-5:] == '.xlsx':
            new_tags, new_discarded = xlsx.get_tags(args, path, cmp=output_dta)
        else:
            new_tags, new_discarded = get_csv_tags(args, path)

        # Check for duplicates
        for t in new_tags:
            if t in tags:
                if t in duplicates:
                    duplicates[t].append(new_tags[t].split("/")[-1])
                else:
                    duplicates[t] = [new_tags[t].split("/")[-1], tags[t].split("/")[-1]]
        tags.update(new_tags)
        discarded.update(new_discarded)
    xlsx.filter_output(args, tags)
    if args.verbose:
        com.print_discarded(discarded)
        com.print_duplicates(duplicates)


def diff(args):
    file_paths = com.get_in_files(args, ['.csv'])
    f1 = open(file_paths[0], "r")
    f2 = open(file_paths[1], "r")
    key = args.tag_title
    diff = csv_diff.compare(
            csv_diff.load_csv(f1, key=key),
            csv_diff.load_csv(f2, key=key)
    )
    out_txt = csv_diff.human_text(diff, key=key)
    if args.output:
        with open(args.output, "w") as f:
            f.write(out_txt)
    else:
        print(out_txt)


def csv_conv(args):
    file_paths = com.get_in_files(args, ['.xlsx', '.csv'])
    rows = []
    if len(args.column_titles) == 0:
        cts = None
    elif args.tag_title not in args.column_titles:
        cts = [args.tag_title]
        cts.extend(args.column_titles)
    else: 
        cts = args.column_titles

    header = cts

    for path in file_paths:
        new_rows = []
        if path[-5:] == '.xlsx':
            ws = load_workbook(filename = path, data_only = True).active
            new_rows = xlsx.get_rows(args, ws, xlsx.get_visible_rows(path), cts)
            if not header:
                header = xlsx.get_col_titles(ws.tables[args.table_name])
        else:
            new_rows = cc_csv.get_rows(path, None, cts)
            if not header:
                header = cc_csv.get_col_titles(path)
        rows.extend(new_rows)
    cc_csv.write_csv(args.output, rows, header)

def update(args):
    file_paths = com.get_in_files(args, ['.xlsx', '.csv'])
    cts = args.column_titles

    header = cts
    src_dict = {}   # {Tag: {Col_name: Value}}

    for path in file_paths:
        if path[-5:] == '.xlsx':
            new_sd = xlsx.get_src_dict(args, path)
            com.check_sd_upd(src_dict, new_sd)
            src_dict.update(new_sd)


        else:
            print("Error, CSV support not implemented :(", file=sys.stderr)
            exit -1
    print(src_dict)
    if args.output[-5:] == '.xlsx':

        updated_tags = xlsx.update_wb(args, src_dict)
        com.check_update(updated_tags, src_dict)

    else:
        print("Error, CSV support not implemented :(", file=sys.stderr)
        exit -1




def print_tags(args):
    file_paths = com.get_in_files(args, ['.xlsx', '.csv'])
    tags = []

    for path in file_paths:
        if path[-5:] == '.xlsx':
            new_tags = list(xlsx.get_tags(args, path)[0].keys())
        else:
            new_tags = cc_csv.get_tags(args, path)
        tags.extend(new_tags)
    f = sys.stdout
    if args.output:
        f = open(args.output, "w")
    for tag in tags:
        print(tag, file=f)

def filter_arg_chk(args):
    if args.output == None:
        print("Error, must specify an output file in filter mode.", file=sys.stderr)
        exit(-1)
    if args.output[-5:] != ".xlsx":
        print("Error, output file must be a '.xlsx' file in filter mode", file=sys.stderr)
        exit(-1)

def diff_arg_chk(args):
    if len(args.input) != 2:
        print("Error, Exactly 2 input files must be specified in diff mode.", file=sys.stderr)

def csv_arg_chk(args):
    pass

def update_arg_chk(args):
    if args.output == None:
        print("Error, must specify an output file in update mode.", file=sys.stderr)
        exit(-1)

    if len(args.column_titles) == 0 and args.output[-5:] == '.xlsx':
        ws = load_workbook(filename=args.output, data_only=True).active
        cs = ws.tables[args.table_name]
        args.column_titles = xlsx.get_col_titles(cs)
    
    args.tag_title = args.tag_title.upper()
    
    cts = []
    for ct in args.column_titles:
        cts.append(ct.upper())
    args.column_titles = cts

    if args.tag_title not in args.column_titles:
        args.column_titles.append(args.tag_title)
        



def run_operation(args):
    f = args.filter
    c = args.csv
    d = args.diff
    p = args.print_tags
    u = args.update
    total = int(f) + int(c) + int(d) + int(p) + int(u)


    if total > 1:
        print("Error, can only specify one operation at a time.", file=sys.stderr)
        exit(-1)
    elif total < 1:
        f = True

    if f:
        filter_arg_chk(args)
        filter(args)
    elif d:
        diff_arg_chk(args)
        diff(args)
    elif c:
        csv_arg_chk(args)
        csv_conv(args)
    elif p:
        print_tags(args)
    elif u:
        update_arg_chk(args)
        update(args)


def cli():
    args = parse_args()
    run_operation(args)

