import csv
import sys

def get_rows(path, rows, col_titles):
    row_lst = []
    i = 0
    with open(path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if col_titles == None:
                col_titles = list(row.keys())
            new_row = []
            for c in col_titles:
                new_row.append(row[c])
            if rows == None or i in rows:
                row_lst.append(new_row)
            i += 1
    return row_lst



def get_tags(args, file_path):
    tags = {}
    with open(file_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            tags[row[args.tag_title]] = file_path
    return tags

def get_col_titles(path):
    with open(path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            return list(row.keys())



def write_csv(path, rows, col_titles):
    out = [col_titles]
    out.extend(rows)

    if path == None:
        writer = csv.writer(sys.stdout)
        writer.writerows(out)
    else:
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(out)




