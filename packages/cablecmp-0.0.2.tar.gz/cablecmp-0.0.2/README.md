# Cablecmp
### A command line tool to filter and compare cable schedules
---
## Windows installation with pip:
- Navagate to Microsoft store, and install Python
- open a command prompt session and type: `pip install cablecmp`
- close and re-open command prompt (to update $PATH), and cablecmp will be available as a command.  Type `cablecmp --help` for a info on it's usage.
---
## Linux/*nix installation with pip:
- `pip install cablecmp`
- Type `cablecmp --help` for info on how to use cablecmp