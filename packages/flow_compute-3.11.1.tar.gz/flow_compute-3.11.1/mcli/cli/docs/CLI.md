# Command-Line Help for `mcli`

This document contains the help content for the `mcli` command-line program.

**Command Overview:**

* [`mcli`↴](#mcli)
* [`mcli ssh`↴](#mcli-ssh)
* [`mcli instance`↴](#mcli-instance)
* [`mcli instance list`↴](#mcli-instance-list)
* [`mcli instance create`↴](#mcli-instance-create)
* [`mcli instance delete`↴](#mcli-instance-delete)
* [`mcli instance info`↴](#mcli-instance-info)
* [`mcli instance list-types`↴](#mcli-instance-list-types)
* [`mcli instance ssh`↴](#mcli-instance-ssh)
* [`mcli k8s`↴](#mcli-k8s)
* [`mcli k8s list`↴](#mcli-k8s-list)
* [`mcli k8s info`↴](#mcli-k8s-info)
* [`mcli k8s ssh`↴](#mcli-k8s-ssh)
* [`mcli k8s update-kubeconfig`↴](#mcli-k8s-update-kubeconfig)

## `mcli`

Mithril CLI

**Usage:** `mcli [ARGS]... [COMMAND]`

###### **Subcommands:**

* `ssh` — SSH into an instance by spot bid name, or interactively select an instance
* `instance` — Manage compute instances (spot bids)
* `k8s` — Manage Kubernetes clusters

###### **Arguments:**

* `<ARGS>` — Pass-through arguments for delegation to flow CLI



## `mcli ssh`

SSH into an instance by spot bid name, or interactively select an instance

**Usage:** `mcli ssh [OPTIONS] [BID_NAME] [COMMAND]...`

###### **Arguments:**

* `<BID_NAME>` — Spot bid name to connect to (if not provided, shows interactive picker)
* `<COMMAND>` — Command to run on the remote instance (if not provided, starts interactive shell)

###### **Options:**

* `--node <NODE>` — Node index for multi-instance tasks (remote commands default to all nodes; interactive default is 0)
* `--show` — Show the raw SSH command instead of executing it
* `--no-wait` — Don't wait for instance to become available (fail immediately if not running)



## `mcli instance`

Manage compute instances (spot bids)

**Usage:** `mcli instance <COMMAND>`

###### **Subcommands:**

* `list` — List instances/bids
* `create` — Create a new instance/bid
* `delete` — Delete (cancel) an instance/bid
* `info` — Show detailed info about an instance/bid
* `list-types` — List available instance types
* `ssh` — SSH into an instance by spot bid name, or interactively select an instance



## `mcli instance list`

List instances/bids

**Usage:** `mcli instance list [OPTIONS]`

###### **Options:**

* `--all` — Show all bids (default: active only)
* `-s`, `--state <STATE>` — Filter by status

  Possible values: `allocated`, `pending`, `open`, `starting`, `running`, `paused`, `preempting`, `completed`, `failed`, `cancelled`

* `--limit <LIMIT>` — Maximum number of bids to show
* `--json` — Output JSON for automation



## `mcli instance create`

Create a new instance/bid

**Usage:** `mcli instance create [OPTIONS] --instance-type <INSTANCE_TYPE> --region <REGION> --max-price-per-hour <MAX_PRICE_PER_HOUR>`

###### **Options:**

* `-i`, `--instance-type <INSTANCE_TYPE>` — GPU instance type (e.g., a100, 8xa100, h100)
* `-r`, `--region <REGION>` — Region (e.g., us-west1-b)
* `-n`, `--name <NAME>` — Bid name (default: auto-generated)
* `-m`, `--max-price-per-hour <MAX_PRICE_PER_HOUR>` — Maximum hourly price in USD (e.g., 8.0 or $8.0)
* `-N`, `--num-instances <NUM_INSTANCES>` — Number of instances in the bid

  Default value: `1`
* `-p`, `--project <PROJECT>` — Project name (skip interactive selection)
* `--k8s <K8S>` — Attach to Kubernetes cluster (name)
* `--wait` — Wait for instances to start running
* `-d`, `--dry-run` — Validate configuration without submitting
* `-w`, `--watch` — Watch instance progress interactively
* `--json` — Output JSON for automation



## `mcli instance delete`

Delete (cancel) an instance/bid

**Usage:** `mcli instance delete [OPTIONS] [BID_NAME]`

###### **Arguments:**

* `<BID_NAME>` — Bid name or FID (interactive if omitted)

###### **Options:**

* `-y`, `--yes` — Skip confirmation prompt
* `--all` — Cancel all active bids
* `-n`, `--name-pattern <NAME_PATTERN>` — Cancel bids matching wildcard pattern (e.g., 'dev-*')



## `mcli instance info`

Show detailed info about an instance/bid

**Usage:** `mcli instance info [OPTIONS] [BID_NAME]`

###### **Arguments:**

* `<BID_NAME>` — Bid name or FID (interactive if omitted)

###### **Options:**

* `--json` — Output JSON for automation



## `mcli instance list-types`

List available instance types

**Usage:** `mcli instance list-types [OPTIONS]`

###### **Options:**

* `-r`, `--region <REGION>` — Filter by region
* `-v`, `--verbose` — Show detailed GPU/memory info
* `--json` — Output JSON for automation



## `mcli instance ssh`

SSH into an instance by spot bid name, or interactively select an instance

**Usage:** `mcli instance ssh [OPTIONS] [BID_NAME] [COMMAND]...`

###### **Arguments:**

* `<BID_NAME>` — Spot bid name to connect to (if not provided, shows interactive picker)
* `<COMMAND>` — Command to run on the remote instance (if not provided, starts interactive shell)

###### **Options:**

* `--node <NODE>` — Node index for multi-instance tasks (remote commands default to all nodes; interactive default is 0)
* `--show` — Show the raw SSH command instead of executing it
* `--no-wait` — Don't wait for instance to become available (fail immediately if not running)



## `mcli k8s`

Manage Kubernetes clusters

**Usage:** `mcli k8s <COMMAND>`

###### **Subcommands:**

* `list` — List Kubernetes clusters
* `info` — Show detailed information about a Kubernetes cluster
* `ssh` — SSH into Kubernetes cluster control node
* `update-kubeconfig` — Fetch k8s cluster credentials and update local kubeconfig



## `mcli k8s list`

List Kubernetes clusters

**Usage:** `mcli k8s list [OPTIONS]`

###### **Options:**

* `--all` — Show all clusters including terminated
* `--json` — Output JSON for automation



## `mcli k8s info`

Show detailed information about a Kubernetes cluster

**Usage:** `mcli k8s info [OPTIONS] [CLUSTER]`

###### **Arguments:**

* `<CLUSTER>` — Cluster name or FID (interactive if omitted)

###### **Options:**

* `--json` — Output JSON for automation



## `mcli k8s ssh`

SSH into Kubernetes cluster control node

**Usage:** `mcli k8s ssh [OPTIONS] [CLUSTER] [COMMAND]...`

###### **Arguments:**

* `<CLUSTER>` — Cluster name or FID (interactive if omitted)
* `<COMMAND>` — Command to run on the remote host

###### **Options:**

* `--show` — Show the raw SSH command instead of executing it
* `-i`, `--identity <IDENTITY>` — Path to SSH identity file (auto-detected if omitted)



## `mcli k8s update-kubeconfig`

Fetch k8s cluster credentials and update local kubeconfig

**Usage:** `mcli k8s update-kubeconfig [OPTIONS] [CLUSTER]`

###### **Arguments:**

* `<CLUSTER>` — Cluster name or FID (interactive if omitted)

###### **Options:**

* `-i`, `--identity <IDENTITY>` — Path to SSH identity file (auto-detected if omitted)
* `-y`, `--yes` — Skip confirmation prompt
* `--no-backup` — Skip creating backup of existing kubeconfig
* `--skip-validation` — Skip validation with kubectl



<hr/>

<small><i>
    This document was generated automatically by
    <a href="https://crates.io/crates/clap-markdown"><code>clap-markdown</code></a>.
</i></small>
