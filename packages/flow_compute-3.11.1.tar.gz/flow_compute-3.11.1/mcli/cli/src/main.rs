//! Entrypoint for native binary `mcli`.

use anyhow::Result;

#[tokio::main]
async fn main() -> Result<()> {
    env_logger::Builder::from_env(env_logger::Env::default().filter_or("MITHRIL_CLI_LOG", "warn"))
        .init();

    let args: Vec<String> = std::env::args().collect();
    let code = _mcli::run_cli(args).await?;

    if code == -1 {
        eprintln!("No command provided. Use --help for usage.");
        eprintln!("Note: this is the native dev binary.");
        std::process::exit(1);
    }

    std::process::exit(code);
}
