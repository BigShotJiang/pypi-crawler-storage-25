//! Core CLI library + python extension entrypoint for flow/mithril-cli.

mod api;
mod cli;
mod commands;
mod util;

use anyhow::Result;
use clap::Parser;

pub use cli::{Cli, Commands, InstanceCommands, KubernetesCommands};

/// Core CLI execution logic, shared between binary and pyo3 extension.
pub async fn run_cli(args: Vec<String>) -> Result<i32> {
    util::setup_signal_handlers();

    // Handle clap errors (help, version, parse errors) by printing and returning exit code
    let cli = match Cli::try_parse_from(&args) {
        Ok(cli) => cli,
        Err(e) => {
            // Clap errors include help output, version, and parse errors
            // Print them and return appropriate exit code
            let _ = e.print();
            return Ok(e.exit_code());
        }
    };

    match cli.command {
        Some(Commands::Ssh { args }) => {
            commands::ssh::run(
                args.bid_name,
                args.node,
                args.show,
                args.no_wait,
                args.command,
            )
            .await?;
        }
        Some(Commands::Instance(subcmd)) => match subcmd {
            InstanceCommands::List {
                all,
                state,
                limit,
                json,
            } => {
                commands::instance::list::run(all, state, limit, json).await?;
            }
            InstanceCommands::Create {
                instance_type,
                region,
                name,
                max_price_per_hour,
                num_instances,
                project,
                k8s,
                wait,
                dry_run,
                watch,
                json,
            } => {
                commands::instance::create::run(
                    instance_type,
                    region,
                    name,
                    max_price_per_hour,
                    num_instances,
                    project,
                    k8s,
                    wait,
                    dry_run,
                    watch,
                    json,
                )
                .await?;
            }
            InstanceCommands::Delete {
                bid_name,
                yes,
                all,
                name_pattern,
            } => {
                commands::instance::delete::run(bid_name, yes, all, name_pattern).await?;
            }
            InstanceCommands::Info { bid_name, json } => {
                commands::instance::info::run(bid_name, json).await?;
            }
            InstanceCommands::ListTypes {
                region,
                verbose,
                json,
            } => {
                commands::instance::list_types::run(region, verbose, json).await?;
            }
            InstanceCommands::Ssh { args } => {
                commands::ssh::run(
                    args.bid_name,
                    args.node,
                    args.show,
                    args.no_wait,
                    args.command,
                )
                .await?;
            }
        },
        Some(Commands::K8s(subcmd)) => match subcmd {
            KubernetesCommands::List { all, json } => {
                commands::kubernetes::list::run(all, json).await?;
            }
            KubernetesCommands::Info { cluster, json } => {
                commands::kubernetes::info::run(cluster, json).await?;
            }
            KubernetesCommands::Ssh {
                cluster,
                show,
                identity,
                command,
            } => {
                commands::kubernetes::ssh::run(cluster, show, identity, command).await?;
            }
            KubernetesCommands::UpdateKubeconfig {
                cluster,
                identity,
                yes,
                no_backup,
                skip_validation,
            } => {
                commands::kubernetes::update_kubeconfig::run(
                    cluster,
                    identity,
                    yes,
                    no_backup,
                    skip_validation,
                )
                .await?;
            }
        },
        None => {
            // No mcli-specific command; delegate to flow CLI
            return Ok(-1);
        }
    }

    Ok(0)
}

// pyo3 extension module, only built by maturin
#[cfg(feature = "extension-module")]
mod python {
    use super::*;
    use pyo3::prelude::*;

    #[pyfunction]
    fn run(py: Python<'_>, args: Vec<String>) -> PyResult<i32> {
        // Release the GIL during async execution
        py.allow_threads(|| {
            let rt = tokio::runtime::Runtime::new()
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

            rt.block_on(async { run_cli(args).await })
                .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))
        })
    }

    #[pymodule]
    pub fn _mcli(m: &Bound<'_, PyModule>) -> PyResult<()> {
        m.add_function(wrap_pyfunction!(run, m)?)?;
        Ok(())
    }
}

#[cfg(feature = "extension-module")]
pub use python::_mcli;
