# HistoricalPricesResponseModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prices** | [**Vec<models::HistoricalPricePointModel>**](HistoricalPricePointModel.md) | List of historical price points | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


