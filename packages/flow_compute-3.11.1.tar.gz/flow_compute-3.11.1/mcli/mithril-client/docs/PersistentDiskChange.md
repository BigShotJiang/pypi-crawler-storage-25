# PersistentDiskChange

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attached** | Option<**String**> |  | [optional]
**removed** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


