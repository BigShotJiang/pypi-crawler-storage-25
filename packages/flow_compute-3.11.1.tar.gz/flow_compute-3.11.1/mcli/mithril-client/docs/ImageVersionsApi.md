# \ImageVersionsApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_image_versions_v2_image_versions_get**](ImageVersionsApi.md#get_image_versions_v2_image_versions_get) | **GET** /v2/image-versions | Get Image Versions



## get_image_versions_v2_image_versions_get

> Vec<models::ImageVersionModel> get_image_versions_v2_image_versions_get()
Get Image Versions

Get all available image versions; the stable image version is the default unless otherwise specified.

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::ImageVersionModel>**](ImageVersionModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

