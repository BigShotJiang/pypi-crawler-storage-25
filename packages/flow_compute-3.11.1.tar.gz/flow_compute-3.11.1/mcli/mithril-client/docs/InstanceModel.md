# InstanceModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fid** | **String** |  | 
**name** | **String** |  | 
**project** | **String** |  | 
**created_at** | **String** |  | 
**created_by** | **String** |  | 
**instance_type** | **String** |  | 
**region** | Option<**String**> |  | [optional]
**bid** | Option<**String**> |  | [optional]
**reservation** | Option<**String**> |  | [optional]
**ssh_destination** | Option<**String**> |  | [optional]
**private_ip** | Option<**String**> |  | [optional]
**status** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


