# BidHistoryEventModel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **String** | When the event occurred | 
**event_type** | **String** |  | 
**limit_price** | Option<**String**> |  | [optional]
**user_id** | Option<**String**> |  | [optional]
**memory_gb** | Option<**i32**> |  | [optional]
**persistent_disk_change** | Option<[**models::PersistentDiskChange**](PersistentDiskChange.md)> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


