# CreateKubernetesClusterRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**project** | **String** |  | 
**region** | **String** |  | 
**ssh_keys** | **Vec<String>** |  | 
**instance_type** | **String** |  | 
**k8s_version** | Option<**String**> |  | [optional][default to Variant134]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


