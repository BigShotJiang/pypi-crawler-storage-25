# UpdateReservationRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paused** | Option<**bool**> |  | [optional]
**volumes** | Option<**Vec<String>**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


