# \InstanceTypesApi

All URIs are relative to *https://api.mithril.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_instance_types_v2_instance_types_get**](InstanceTypesApi.md#get_instance_types_v2_instance_types_get) | **GET** /v2/instance-types | Get Instance Types



## get_instance_types_v2_instance_types_get

> Vec<models::InstanceTypeModel> get_instance_types_v2_instance_types_get()
Get Instance Types

Get all instance types.

### Parameters

This endpoint does not need any parameter.

### Return type

[**Vec<models::InstanceTypeModel>**](InstanceTypeModel.md)

### Authorization

[MithrilAPIKey](../README.md#MithrilAPIKey)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

