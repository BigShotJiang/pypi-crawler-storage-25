# MeResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**fid** | **String** |  | 
**email** | **String** |  | 
**user_name** | Option<**String**> |  | [optional]
**organization_id** | **String** |  | 
**organization_role** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


