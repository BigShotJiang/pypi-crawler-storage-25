# LifecycleScriptScope

## Enum Variants

| Name | Value |
|---- | -----|
| Project | PROJECT |
| Organization | ORGANIZATION |
| Platform | PLATFORM |


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


