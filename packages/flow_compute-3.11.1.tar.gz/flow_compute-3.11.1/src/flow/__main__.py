"""Direct module execution support: ``python -m flow``."""

import sys

if __name__ == "__main__":
    # Guard against running with too-old Python before importing modern syntax.
    if sys.version_info < (3, 10):
        print(
            f"Error: Flow requires Python 3.10 or later. "
            f"You are using Python {sys.version_info.major}.{sys.version_info.minor}.",
            file=sys.stderr,
        )
        raise SystemExit(1)

    from flow.cli.app import main

    raise SystemExit(main() or 0)
