"""mithril-cli entrypoint: call into Rust pyo3 module or delegate to flow."""

import platform
import sys


def main() -> int:
    """Entrypoint for mithril-cli command."""
    try:
        from flow._mcli import run
    except ImportError:
        return _handle_missing_extension()

    result = run(sys.argv)

    # Return code -1 means delegate to flow CLI
    if result == -1:
        from flow.cli.app import main as flow_main

        return flow_main()

    return result


def _handle_missing_extension() -> int:
    os_name = platform.system()
    arch = platform.machine()

    supported = [
        ("Linux", "x86_64"),
        ("Linux", "aarch64"),
        ("Darwin", "x86_64"),
        ("Darwin", "arm64"),
    ]

    is_supported = (os_name, arch) in supported

    print("mithril-cli: Native extension not available", file=sys.stderr)
    print(file=sys.stderr)

    if not is_supported:
        print(f"Your platform ({os_name} {arch}) is not yet supported.", file=sys.stderr)
        print("Supported platforms: macOS (x86_64, arm64), Linux (x86_64, arm64)", file=sys.stderr)
        print(file=sys.stderr)
        print("The 'flow' command is available and works on all platforms.", file=sys.stderr)
        print("Run: flow --help", file=sys.stderr)
    else:
        print("This may happen if:", file=sys.stderr)
        print("  - You installed from source without Rust toolchain", file=sys.stderr)
        print("  - The wheel was built for a different Python version", file=sys.stderr)
        print(file=sys.stderr)
        print("Try reinstalling: pip install --force-reinstall flow-compute", file=sys.stderr)

    return 1


if __name__ == "__main__":
    sys.exit(main())
