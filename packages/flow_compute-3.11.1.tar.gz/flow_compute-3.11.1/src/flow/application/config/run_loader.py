"""Configuration loading for the run command.

This module handles loading and parsing of task configurations from
various sources (YAML, SLURM scripts) following single responsibility
and dependency injection principles.
"""

from __future__ import annotations

import logging
from pathlib import Path

import yaml

from flow.errors import ConfigParserError
from flow.sdk.models import TaskConfig
from flow.sdk.models.run_params import RunParameters

logger = logging.getLogger(__name__)


class ConfigurationError(ConfigParserError):
    """Raised when configuration loading or parsing fails."""

    pass


class TaskConfigLoader:
    """Loads and parses task configurations from files.

    This class encapsulates all configuration loading logic that was
    previously embedded in the RunCommand._execute method (lines 680-806).
    """

    def load(self, params: RunParameters) -> tuple[TaskConfig | None, list[TaskConfig] | None]:
        """Load configuration based on parameters.

        Args:
            params: Run parameters including config file path and type hints.

        Returns:
            Tuple of (single_config, config_list) where one will be None.

        Raises:
            ConfigurationError: If configuration is invalid or cannot be loaded.
        """
        if not params.config_file:
            return self._create_interactive_config(params), None

        if self._is_slurm_file(params.config_file, params.is_slurm):
            return None, self._load_slurm_configs(params.config_file, params)

        return self._load_yaml_config(params.config_file, params), None

    def _is_slurm_file(self, path: Path, explicit_slurm: bool) -> bool:
        """Detect if a file is a SLURM script."""
        if explicit_slurm:
            return True

        # Check extension
        if path.suffix.lower() in (".slurm", ".sbatch"):
            return True

        # Check content for SLURM directives
        if path.exists():
            try:
                with open(path, encoding="utf-8") as f:
                    head = f.read(4096)
                    if "#SBATCH" in head:
                        return True
            except (OSError, UnicodeDecodeError):
                logger.debug(f"Could not read {path} to detect SLURM format")

        return False

    def _load_yaml_config(self, path: Path, params: RunParameters) -> TaskConfig:
        """Load and parse a YAML configuration file.

        Args:
            path: Path to YAML file.
            params: Run parameters for applying overrides.

        Returns:
            Parsed TaskConfig with overrides applied.

        Raises:
            ConfigurationError: If YAML is invalid or file not found.
        """
        if not path.exists():
            raise ConfigurationError(f"Configuration file does not exist: {path}")

        try:
            with open(path, encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not isinstance(data, dict):
                raise ConfigurationError("YAML must be a mapping of keys to values")

            # Apply naming policy
            self._apply_naming_policy(data, params)

            # Create base config
            config = TaskConfig(**data)

            # Apply overrides
            return self._apply_overrides(config, params)

        except yaml.YAMLError as e:
            logger.debug("YAML parse error in %s: %s", path, e)
            raise ConfigurationError(
                f"Failed to parse config file '{path}'",
                suggestions=[
                    "Check YAML syntax — common issues: missing colons, incorrect indentation, tabs instead of spaces",
                    f"Validate your file: python -c \"import yaml; yaml.safe_load(open('{path}'))\"",
                    "See examples: flow example list",
                ],
            )
        except (ValueError, TypeError) as e:
            logger.debug("Configuration value error in %s: %s", path, e)
            raise ConfigurationError(
                f"Invalid configuration in '{path}': {e}",
                suggestions=[
                    "Check that all fields use the correct types (e.g., strings, numbers, lists)",
                    "See examples: flow example list",
                ],
            )

    def _load_slurm_configs(self, path: Path, params: RunParameters) -> list[TaskConfig]:
        """Load and parse a SLURM script into task configs.

        Args:
            path: Path to SLURM script.
            params: Run parameters for applying overrides.

        Returns:
            List of TaskConfig objects (possibly array job).

        Raises:
            ConfigurationError: If SLURM script is invalid.
        """
        try:
            from flow.plugins.slurm.adapter import SlurmFrontendAdapter
            from flow.plugins.slurm.parser import parse_sbatch_script

            adapter = SlurmFrontendAdapter()

            # Build SLURM overrides from parameters
            slurm_overrides = self._build_slurm_overrides(params)

            # Check for array job
            slurm_cfg = parse_sbatch_script(str(path))
            if getattr(slurm_cfg, "array", None):
                configs = adapter.parse_array_job(str(path), **slurm_overrides)
            else:
                single = adapter.parse_and_convert(str(path), **slurm_overrides)
                configs = [single]

            # Apply overrides to each config
            return [self._apply_overrides(cfg, params) for cfg in configs]

        except ImportError as e:
            logger.debug("SLURM import error: %s", e)
            raise ConfigurationError(
                "SLURM support is not installed",
                suggestions=[
                    "Install SLURM support: uv pip install 'flow-compute[slurm]'",
                ],
            )
        except Exception as e:  # noqa: BLE001
            logger.debug("SLURM parse error in %s: %s", path, e)
            raise ConfigurationError(
                f"Failed to parse SLURM script '{path}'",
                suggestions=[
                    "Check #SBATCH directives for syntax errors",
                    "Ensure the script is a valid SLURM batch file",
                ],
            )

    def _create_interactive_config(self, params: RunParameters) -> TaskConfig:
        """Create configuration for interactive instance.

        Args:
            params: Run parameters.

        Returns:
            TaskConfig for interactive session.
        """
        config_dict = {
            "name": params.execution.name or ("run" if params.execution.command else "interactive"),
            "unique_name": params.execution.unique_name,
            "instance_type": params.instance.instance_type,
            "k8s": params.instance.k8s,
            "image": params.execution.image,
            "env": params.execution.environment,
        }

        if params.instance.region:
            config_dict["region"] = params.instance.region

        if params.execution.command:
            config_dict["command"] = params.execution.command
        else:
            config_dict["command"] = ["sleep", "infinity"]

        if params.ssh.keys:
            config_dict["ssh_keys"] = list(params.ssh.keys)

        if params.instance.priority:
            config_dict["priority"] = params.instance.priority

        if params.instance.max_price_per_hour is not None:
            config_dict["max_price_per_hour"] = params.instance.max_price_per_hour

        if params.instance.num_instances != 1:
            config_dict["num_instances"] = params.instance.num_instances

        if params.instance.distributed_mode:
            config_dict["distributed_mode"] = params.instance.distributed_mode

        # Apply upload settings
        if params.upload.upload_code is not None:
            config_dict["upload_code"] = params.upload.upload_code
        if params.upload.code_root:
            config_dict["code_root"] = str(params.upload.code_root)

        return TaskConfig(**config_dict)

    def _apply_naming_policy(self, data: dict, params: RunParameters) -> None:
        """Apply naming policy to configuration data.

        Modifies data dict in place to set unique_name appropriately.
        """
        if "unique_name" not in data:
            has_name = bool((data.get("name") or "").strip())
            data["unique_name"] = not has_name

    def _apply_overrides(self, config: TaskConfig, params: RunParameters) -> TaskConfig:
        """Apply CLI parameter overrides to a YAML-loaded configuration.

        Only overrides values that the user explicitly typed on the command line,
        using params.cli_overrides to distinguish user intent from Click defaults.
        Precedence: CLI explicit flag > YAML config value > TaskConfig default.

        Args:
            config: Base configuration (from YAML or interactive).
            params: Parameters containing potential overrides.

        Returns:
            New TaskConfig with explicit CLI overrides applied.
        """
        overrides = params.cli_overrides
        updates: dict = {}

        # Instance overrides
        if "instance_type" in overrides:
            updates["instance_type"] = params.instance.instance_type
        if "region" in overrides:
            updates["region"] = params.instance.region
        if "priority" in overrides:
            updates["priority"] = params.instance.priority
        if "max_price_per_hour" in overrides:
            updates["max_price_per_hour"] = params.instance.max_price_per_hour
        if "num_instances" in overrides:
            updates["num_instances"] = params.instance.num_instances
        if "distributed_mode" in overrides:
            updates["distributed_mode"] = params.instance.distributed_mode

        # Image override (previously missing -- CLI --image couldn't override YAML)
        if "image" in overrides:
            updates["image"] = params.execution.image

        # Upload overrides
        if "upload_strategy" in overrides:
            updates["upload_strategy"] = params.upload.strategy
        if "upload_timeout" in overrides:
            updates["upload_timeout"] = params.upload.timeout
        if "code_root" in overrides:
            updates["code_root"] = str(params.upload.code_root)
        if "upload_code" in overrides:
            updates["upload_code"] = params.upload.upload_code

        # Environment overrides (additive: CLI env merges into YAML env)
        if "env" in overrides:
            merged_env = dict(getattr(config, "env", {}) or {})
            merged_env.update(params.execution.environment)
            updates["env"] = merged_env

        # Port overrides
        if "ports" in overrides:
            updates["ports"] = list(params.execution.ports)

        # SSH keys override
        if "ssh_keys" in overrides:
            updates["ssh_keys"] = list(params.ssh.keys)

        # Name override
        if "name" in overrides:
            updates["name"] = params.execution.name

        return config.model_copy(update=updates) if updates else config

    def _build_slurm_overrides(self, params: RunParameters) -> dict:
        """Build override dictionary for SLURM adapter.

        Args:
            params: Run parameters.

        Returns:
            Dictionary of SLURM-specific overrides.
        """
        cli = params.cli_overrides
        overrides = {}

        # Convert Flow instance type to SLURM GPU specification
        if "instance_type" in cli and params.instance.instance_type:
            instance_type = params.instance.instance_type.strip().lower()
            if "x" in instance_type:
                try:
                    count, gpu = instance_type.split("x", 1)
                    int(count)  # Validate it's a number
                    overrides["gpus"] = f"{gpu}:{count}"
                except (ValueError, AttributeError):
                    overrides["gpus"] = instance_type
            else:
                overrides["gpus"] = instance_type

        if "num_instances" in cli:
            overrides["nodes"] = params.instance.num_instances

        return overrides
