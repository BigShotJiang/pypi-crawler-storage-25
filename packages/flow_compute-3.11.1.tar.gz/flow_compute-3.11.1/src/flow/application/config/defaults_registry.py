"""Registry for provider-specific ``ConfigDefaultsProvider`` implementations.

Providers self-register their defaults via the ``flow.config_defaults``
entry-point group. The application layer looks up defaults by provider name
without importing any adapter module directly, preserving the layer
boundary.

Registration is lazy: the first call to :func:`get` triggers entry-point
discovery. Manual registration via :func:`register` is also supported for
tests or bespoke composition roots.
"""

from __future__ import annotations

import logging
from importlib.metadata import entry_points

from flow.protocols.config_defaults import ConfigDefaultsProvider

logger = logging.getLogger(__name__)

_ENTRY_POINT_GROUP = "flow.config_defaults"

_registry: dict[str, ConfigDefaultsProvider] = {}
_discovered: bool = False


def register(name: str, provider: ConfigDefaultsProvider) -> None:
    """Register a ``ConfigDefaultsProvider`` under the given provider name.

    Args:
        name: Provider identifier (e.g. ``"mithril"``).
        provider: Concrete implementation of :class:`ConfigDefaultsProvider`.
    """
    _registry[name] = provider


def get(name: str) -> ConfigDefaultsProvider | None:
    """Look up defaults for ``name``, triggering discovery on first call.

    Returns ``None`` when no defaults provider is registered, so callers can
    degrade gracefully to a hard-coded fallback.
    """
    _ensure_discovered()
    return _registry.get(name)


def clear() -> None:
    """Reset the registry. Intended for tests."""
    global _discovered
    _registry.clear()
    _discovered = False


def _ensure_discovered() -> None:
    global _discovered
    if _discovered:
        return
    _discovered = True
    try:
        eps = entry_points()
        select = getattr(eps, "select", None)
        candidates = select(group=_ENTRY_POINT_GROUP) if select else []
        for ep in candidates:
            try:
                provider = ep.load()
                instance = provider() if isinstance(provider, type) else provider
                register(ep.name, instance)
            except Exception as load_err:  # noqa: BLE001
                logger.debug(
                    "Failed to load config defaults entry point %s: %s", ep.name, load_err
                )
    except Exception as disc_err:  # noqa: BLE001
        logger.debug("Config defaults discovery unavailable: %s", disc_err)


__all__ = ["clear", "get", "register"]
