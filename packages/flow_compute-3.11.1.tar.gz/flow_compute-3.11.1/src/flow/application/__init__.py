"""Application layer: orchestration and configuration.

Coordinates domain logic with abstract ports from ``flow.protocols``. Depends
on ``flow.domain`` and ``flow.protocols`` only — no provider-specific code,
no direct I/O.

Notable modules:
  - ``config``: loading, validation, and configuration management
  - ``services``: cohesive orchestration helpers
  - ``slurm_overlay``: Slurm-compatible submission overlay
"""
