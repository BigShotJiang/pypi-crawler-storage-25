"""Slurm overlay cluster orchestrator.

Coordinates the creation, modification, and dissolution of Slurm overlay
clusters on existing Flow instances via SSH. Delegates to focused modules
for SSH operations, hardware detection, node setup, and health monitoring.
"""

from __future__ import annotations

import base64
import logging
import shlex
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from flow.application.slurm_overlay import hardware, health, node_setup, ssh_ops
from flow.application.slurm_overlay.exceptions import (
    ClusterExistsError,
    SlurmOverlayError,
    SSHExecutionError,
)
from flow.application.slurm_overlay.health import ClusterHealthReport
from flow.application.slurm_overlay.ssh_ops import ResolvedInstance
from flow.sdk.models.slurm_overlay import (
    ClusterUser,
    SlurmOverlayConfig,
    SlurmOverlayState,
)

if TYPE_CHECKING:
    from flow.protocols.provider import ProviderProtocol

logger = logging.getLogger(__name__)


class SlurmOverlayOrchestrator:
    """Orchestrates Slurm overlay cluster operations.

    This class coordinates the SSH-based installation and configuration of Slurm
    on existing Flow instances to form overlay clusters.
    """

    def __init__(
        self,
        provider: ProviderProtocol | None = None,
        state_store: Any | None = None,
        preflight_validator: Any | None = None,
    ):
        """Initialize the orchestrator.

        Args:
            provider: Provider instance for API operations. If None, will be
                created from environment configuration.
            state_store: ClusterStateStore for persisting cluster state. If
                None, the default file-backed store is created on first access.
            preflight_validator: PreflightValidator for pre-create checks. If
                None, one is created using this orchestrator's SSH runner.
        """
        self._provider = provider
        self._state_store = state_store
        self._preflight_validator = preflight_validator
        self._setup_script_path = node_setup.get_setup_script_path()

    @property
    def provider(self) -> ProviderProtocol:
        """Get or create the provider instance."""
        if self._provider is None:
            import flow.sdk.factory as sdk_factory

            flow_client = sdk_factory.create_client(auto_init=True)
            self._provider = flow_client.provider
        return self._provider

    def _get_state_store(self):
        """Return the cluster state store, creating the default if needed."""
        if self._state_store is None:
            from flow.application.slurm_overlay.state import get_state_store

            self._state_store = get_state_store()
        return self._state_store

    def _get_preflight_validator(self):
        """Return the preflight validator, creating the default if needed."""
        if self._preflight_validator is None:
            from flow.application.slurm_overlay.preflight import PreflightValidator

            self._preflight_validator = PreflightValidator(
                ssh_runner=lambda inst, cmd, timeout=300: self.run_ssh_command(
                    inst, cmd, timeout=timeout
                )
            )
        return self._preflight_validator

    def _get_identity_facet(self):
        """Return the provider's IdentityProtocol facet, or None."""
        from flow.protocols.facets.identity import IdentityProtocol

        identity = getattr(self.provider, "identity", None)
        if identity is not None and isinstance(identity, IdentityProtocol):
            return identity
        return None

    # ------------------------------------------------------------------
    # Delegation wrappers — preserve the public API
    # ------------------------------------------------------------------

    def resolve_instance(self, identifier: str) -> ResolvedInstance:
        """Resolve an instance identifier to SSH connection details.

        Args:
            identifier: Instance name, FID, or bid ID.

        Returns:
            ResolvedInstance with connection details.

        Raises:
            InstanceNotFoundError: If the instance cannot be found.
            InstanceNotReadyError: If the instance is not in a ready state.
        """
        return ssh_ops.resolve_instance(self.provider, identifier)

    def run_ssh_command(
        self,
        instance: ResolvedInstance,
        command: str,
        stdin: bytes | None = None,
        timeout: int = 300,
        retries: int = 3,
        retry_delay: float = 2.0,
    ) -> str:
        """Execute a command on an instance via SSH with automatic retries.

        Args:
            instance: Resolved instance to connect to.
            command: Command to execute.
            stdin: Optional stdin data to send.
            timeout: Command timeout in seconds.
            retries: Number of retry attempts for transient failures.
            retry_delay: Delay between retries in seconds.

        Returns:
            Command stdout.

        Raises:
            SSHExecutionError: If the command fails after all retries.
        """
        return ssh_ops.run_ssh_command(
            instance,
            command,
            stdin=stdin,
            timeout=timeout,
            retries=retries,
            retry_delay=retry_delay,
        )

    def get_instance_private_ip(self, instance: ResolvedInstance) -> str:
        """Get the private IP address of an instance via SSH."""
        return ssh_ops.get_instance_private_ip(instance)

    def detect_gpu_info(self, instance: ResolvedInstance) -> hardware.GPUInfo:
        """Detect GPU information from an instance via SSH."""
        return hardware.detect_gpu_info(instance)

    def determine_partition_name(
        self,
        config: SlurmOverlayConfig,
        gpu_info: hardware.GPUInfo | None = None,
    ) -> str:
        """Determine the partition name for a cluster."""
        return hardware.determine_partition_name(config, gpu_info)

    def get_cluster_info(self, controller: ResolvedInstance) -> dict[str, Any]:
        """Get Slurm cluster information from the controller."""
        return health.get_cluster_info(controller)

    def get_cluster_health(self, cluster_name: str) -> ClusterHealthReport:
        """Perform comprehensive health check on a cluster.

        Args:
            cluster_name: Name of the cluster to check.

        Returns:
            ClusterHealthReport with detailed health status.

        Raises:
            SlurmOverlayError: If cluster not found.
        """
        cluster = self.get_cluster(cluster_name)
        if cluster is None:
            raise SlurmOverlayError(f"Cluster '{cluster_name}' not found")
        return health.get_cluster_health(cluster, self.resolve_instance)

    # ------------------------------------------------------------------
    # Private delegation wrappers — keep tests that patch these working
    # ------------------------------------------------------------------

    def _check_ssh_reachable(self, instance: ResolvedInstance) -> bool:
        """Quick SSH connectivity check."""
        return ssh_ops.check_ssh_reachable(instance)

    def _check_service_running(self, instance: ResolvedInstance, service: str) -> bool:
        """Check if a systemd service is running."""
        return ssh_ops.check_service_running(instance, service)

    def _get_node_slurm_state(self, controller: ResolvedInstance, node_name: str) -> str:
        """Get a node's state from Slurm."""
        return health.get_node_slurm_state(controller, node_name)

    def _upload_and_run_script(
        self,
        instance: ResolvedInstance,
        role: str,
        controller_ip: str | None = None,
        partition: str = "gpu",
        max_time: str = "7-00:00:00",
        munge_key: bytes | None = None,
    ) -> str:
        """Upload and execute the setup script on an instance."""
        return node_setup.upload_and_run_script(
            instance,
            role,
            self._setup_script_path,
            controller_ip=controller_ip,
            partition=partition,
            max_time=max_time,
            munge_key=munge_key,
        )

    def _get_munge_key(self, controller: ResolvedInstance) -> bytes:
        """Retrieve the munge key from the controller."""
        return node_setup.get_munge_key(controller)

    def _get_node_resources(self, instance: ResolvedInstance) -> dict[str, Any]:
        """Get node resources from an instance."""
        return hardware.get_node_resources(instance)

    def _register_workers_on_controller(
        self,
        controller: ResolvedInstance,
        workers: list[ResolvedInstance],
    ) -> None:
        """Register worker nodes in the controller's slurm.conf and gres.conf."""
        node_setup.register_workers_on_controller(controller, workers)

    def _apply_controller_overrides(
        self,
        controller: ResolvedInstance,
        config: SlurmOverlayConfig,
    ) -> None:
        """Apply supported controller-side config overrides."""
        node_setup.apply_controller_overrides(controller, config.get_slurm_conf_extra_lines())

    def _update_instance_metadata(
        self,
        instance: ResolvedInstance,
        cluster_name: str,
        role: str,
        controller_ip: str,
        partition: str = "gpu",
    ) -> None:
        """Update instance metadata with overlay cluster info."""
        node_setup.update_instance_metadata(
            instance,
            cluster_name,
            role,
            controller_ip,
            partition=partition,
            ssh_runner=self.run_ssh_command,
        )

    def _clear_instance_metadata(self, instance: ResolvedInstance) -> None:
        """Remove overlay metadata from an instance."""
        node_setup.clear_instance_metadata(instance, ssh_runner=self.run_ssh_command)

    def _check_instance_not_in_cluster(
        self,
        instance: ResolvedInstance,
        *,
        require_remote_check: bool = False,
        allowed_cluster_name: str | None = None,
    ) -> None:
        """Check that an instance is not already in a cluster."""
        node_setup.check_instance_not_in_cluster(
            instance,
            ssh_runner=self.run_ssh_command if require_remote_check else None,
            allowed_cluster_name=allowed_cluster_name,
        )

    def _validate_instance_regions(
        self,
        controller: ResolvedInstance,
        workers: list[ResolvedInstance],
    ) -> None:
        """Validate that all instances are in the same region."""
        node_setup.validate_instance_regions(controller, workers)

    def _cleanup_stale_state(self, controller: ResolvedInstance) -> None:
        """Clean up stale Slurm state on controller before fresh setup."""
        node_setup.cleanup_stale_state(controller)

    def _verify_cluster_health(
        self,
        controller: ResolvedInstance,
        expected_worker_count: int,
        max_wait: int = 30,
        poll_interval: float = 2.0,
    ) -> None:
        """Verify cluster is operational after setup."""
        node_setup.verify_cluster_health(
            controller,
            expected_worker_count,
            max_wait=max_wait,
            poll_interval=poll_interval,
        )

    def _rollback_create(
        self,
        controller: ResolvedInstance | None,
        workers: list[ResolvedInstance],
    ) -> None:
        """Rollback a failed cluster creation."""
        node_setup.rollback_create(controller, workers)

    def _parse_sinfo(self, report: ClusterHealthReport) -> None:
        """Parse sinfo output to extract node counts."""
        health.parse_sinfo(report)

    def _determine_health_status(self, report: ClusterHealthReport) -> str:
        """Determine overall cluster health status."""
        return health.determine_health_status(report)

    def _generate_health_suggestions(self, report: ClusterHealthReport) -> None:
        """Generate suggested actions based on health issues."""
        health.generate_health_suggestions(report)

    def _validate_supported_config(self, config: SlurmOverlayConfig) -> None:
        """Reject config fields that are declared but not implemented."""
        unsupported: list[str] = []

        if config.shared_volume is not None:
            unsupported.append("shared_volume")
        if config.shared_mount_paths != ["/home", "/scratch"]:
            unsupported.append("shared_mount_paths")
        if config.accounting:
            unsupported.append("accounting")
        if config.gres_conf is not None:
            unsupported.append("gres_conf")
        if config.cgroup_conf is not None:
            unsupported.append("cgroup_conf")

        if unsupported:
            raise SlurmOverlayError(
                "Unsupported Slurm overlay config fields: "
                f"{', '.join(sorted(unsupported))}. "
                "These options are not implemented yet and are rejected explicitly "
                "instead of being ignored."
            )

    def _resolve_cluster_workers(self, worker_fids: list[str]) -> list[ResolvedInstance]:
        """Resolve the current worker set, preserving order and removing duplicates."""
        workers: list[ResolvedInstance] = []
        seen: set[str] = set()
        for worker_fid in worker_fids:
            worker = self.resolve_instance(worker_fid)
            if worker.fid in seen:
                continue
            seen.add(worker.fid)
            workers.append(worker)
        return workers

    def _provision_users_on_nodes(
        self,
        nodes: list[ResolvedInstance],
        usernames: list[str],
    ) -> None:
        """Provision users on all given nodes, failing on the first error."""
        for node in nodes:
            try:
                self.provision_users_on_node(node, usernames)
            except Exception as e:
                raise SlurmOverlayError(f"Failed to provision users on {node.name}: {e}") from e

    def _cleanup_worker_overlay(self, worker: ResolvedInstance) -> None:
        """Stop Slurm services and clear overlay artifacts from a worker."""
        self.run_ssh_command(
            worker,
            "sudo systemctl stop slurmd munge; "
            "sudo rm -f /etc/slurm/slurm.conf /etc/munge/munge.key",
            timeout=60,
        )
        self._clear_instance_metadata(worker)

    def _drain_worker(
        self, controller: ResolvedInstance, worker: ResolvedInstance, timeout: int
    ) -> None:
        """Drain a worker and wait until it has no remaining jobs."""
        import time as time_module

        hostname = self.run_ssh_command(worker, "hostname -s", timeout=30).strip()
        if not hostname:
            raise SlurmOverlayError(f"Could not determine hostname for worker {worker.name}")

        safe_hostname = shlex.quote(hostname)
        self.run_ssh_command(
            controller,
            f"sudo scontrol update NodeName={safe_hostname} State=DRAIN Reason='Removing from overlay'",
            timeout=30,
        )

        deadline = time_module.monotonic() + timeout
        last_jobs = ""
        while time_module.monotonic() < deadline:
            jobs = self.run_ssh_command(
                controller,
                f"squeue -h -w {safe_hostname} -o '%i %T %j' 2>/dev/null",
                timeout=30,
                retries=1,
            ).strip()
            if not jobs:
                self.run_ssh_command(
                    controller,
                    f"sudo scontrol update NodeName={safe_hostname} State=DOWN Reason='Removed from overlay'",
                    timeout=30,
                )
                return
            last_jobs = jobs
            time_module.sleep(5)

        detail = f" Remaining jobs:\n{last_jobs}" if last_jobs else ""
        raise SlurmOverlayError(
            f"Timed out draining worker {worker.name} after {timeout}s.{detail}"
        )

    # ------------------------------------------------------------------
    # User management — needs identity facet + provider, stays here
    # ------------------------------------------------------------------

    def get_current_user(self) -> dict[str, Any]:
        """Get the current authenticated user's info from the provider API."""
        identity = self._get_identity_facet()
        if identity is None:
            raise SlurmOverlayError("Provider does not support user identity API")
        try:
            return identity.get_current_user()
        except SlurmOverlayError:
            raise
        except Exception as e:
            raise SlurmOverlayError(f"Failed to get current user: {e}") from e

    def get_project_teammates(self, user_id: str) -> list[dict[str, Any]]:
        """Get all teammates for the current user via the teammates API."""
        identity = self._get_identity_facet()
        if identity is None:
            logger.info("Provider does not support teammates API, cluster will have single user")
            return []
        try:
            return identity.get_user_teammates(user_id)
        except Exception as e:  # noqa: BLE001 – provider may raise arbitrary errors
            logger.warning(f"Failed to get teammates: {e}")
            return []

    def provision_users_on_node(self, instance: ResolvedInstance, usernames: list[str]) -> None:
        """Provision Linux users on a cluster node, copying SSH keys from ubuntu."""
        if not usernames:
            return

        logger.info(f"Provisioning {len(usernames)} users on {instance.name}")

        commands = []
        for username in usernames:
            if username == "ubuntu":
                continue
            safe_user = shlex.quote(username)
            commands.append(f"""
if ! id {safe_user} &>/dev/null; then
    useradd -m -s /bin/bash {safe_user}
    usermod -aG sudo {safe_user}
fi
mkdir -p /home/{safe_user}/.ssh
if [ -f /home/ubuntu/.ssh/authorized_keys ]; then
    cp /home/ubuntu/.ssh/authorized_keys /home/{safe_user}/.ssh/
fi
chmod 700 /home/{safe_user}/.ssh
chmod 600 /home/{safe_user}/.ssh/authorized_keys 2>/dev/null || true
chown -R {safe_user}:{safe_user} /home/{safe_user}/.ssh
""")

        if commands:
            combined_cmd = "\n".join(commands)
            encoded = base64.b64encode(combined_cmd.encode()).decode()
            self.run_ssh_command(
                instance,
                f"echo {shlex.quote(encoded)} | base64 -d | sudo bash",
                timeout=120,
            )

    def _sync_cluster_users(
        self,
        cluster: SlurmOverlayState,
        repairs_attempted: list[str],
        repair_errors: list[str],
    ) -> None:
        """Sync users on a cluster - add new teammates and refresh SSH keys."""
        from flow.application.slurm_overlay.users import create_cluster_user

        current_user = self.get_current_user()
        current_user_id = current_user.get("fid") or current_user.get("id") or ""
        teammates = self.get_project_teammates(current_user_id)
        all_users = [current_user] + [
            t for t in teammates if (t.get("fid") or t.get("id")) != current_user_id
        ]

        existing_flow_ids = {u.flow_user_id for u in cluster.users}
        used_usernames = {u.linux_username for u in cluster.users}

        new_cluster_users: list[ClusterUser] = []
        for user_info in all_users:
            flow_id = user_info.get("fid") or user_info.get("id") or ""
            if flow_id not in existing_flow_ids:
                cluster_user = create_cluster_user(user_info, used_usernames)
                used_usernames.add(cluster_user.linux_username)
                new_cluster_users.append(cluster_user)

        if new_cluster_users:
            logger.info(f"Found {len(new_cluster_users)} new teammates to provision")

        all_usernames = [u.linux_username for u in cluster.users + new_cluster_users]

        nodes_total = 1 + len(cluster.worker_fids)
        nodes_provisioned = 0
        for fid in [cluster.controller_fid] + list(cluster.worker_fids):
            try:
                self.provision_users_on_node(self.resolve_instance(fid), all_usernames)
                nodes_provisioned += 1
            except Exception as e:  # noqa: BLE001
                repair_errors.append(f"Failed to provision users on {fid}: {e}")

        # Only persist newly-added users when they were successfully provisioned
        # on every node. A partial provision would otherwise be recorded as
        # "done" in state and skipped on the next repair, leaving nodes without
        # the expected Linux accounts.
        if new_cluster_users and nodes_provisioned == nodes_total:
            repairs_attempted.append(
                f"Provisioned {len(new_cluster_users)} new user(s) on {nodes_provisioned} node(s)"
            )
            cluster.users.extend(new_cluster_users)
            self._get_state_store().save(cluster)
        elif new_cluster_users:
            repair_errors.append(
                f"New users were not persisted: only {nodes_provisioned}/{nodes_total} "
                "nodes completed user provisioning; re-run repair after fixing "
                "unreachable nodes."
            )
        elif nodes_provisioned > 0:
            repairs_attempted.append(f"Refreshed SSH keys on {nodes_provisioned} node(s)")

    # ------------------------------------------------------------------
    # Lifecycle operations — core orchestration, stays here
    # ------------------------------------------------------------------

    def create(
        self,
        config: SlurmOverlayConfig,
        skip_preflight: bool = False,
    ) -> SlurmOverlayState:
        """Create a Slurm overlay cluster from existing instances.

        Args:
            config: Overlay cluster configuration.
            skip_preflight: Skip preflight validation (not recommended).

        Returns:
            Cluster state after creation.

        Raises:
            InstanceNotFoundError: If any instance cannot be found.
            ClusterExistsError: If any instance is already in a cluster.
            PreflightValidationError: If preflight checks fail.
            SSHExecutionError: If SSH operations fail.
        """
        logger.info(f"Creating Slurm overlay cluster '{config.name}'")
        self._validate_supported_config(config)

        state_store = self._get_state_store()
        if state_store.exists(config.name):
            raise ClusterExistsError(
                f"Cluster '{config.name}' already exists. "
                f"Use 'flow cluster dissolve {config.name}' first."
            )

        controller = self.resolve_instance(config.controller)
        workers = [self.resolve_instance(w) for w in config.workers]

        self._check_instance_not_in_cluster(controller, require_remote_check=True)
        for worker in workers:
            self._check_instance_not_in_cluster(worker, require_remote_check=True)

        if workers:
            self._validate_instance_regions(controller, workers)

        logger.info("Cleaning up stale Slurm state on instances...")
        self._cleanup_stale_state(controller)
        for worker in workers:
            self._cleanup_stale_state(worker)

        if not skip_preflight:
            logger.info("Running preflight validation...")
            validator = self._get_preflight_validator()
            validator.validate_for_create(controller, workers)
            logger.info("Preflight validation passed")

        from flow.application.slurm_overlay.users import create_cluster_user

        current_user = self.get_current_user()
        current_user_id = current_user.get("fid") or current_user.get("id") or ""
        logger.info(f"Cluster creator: {current_user.get('email', current_user_id)}")

        teammates = self.get_project_teammates(current_user_id)
        all_users = [current_user] + [
            t for t in teammates if (t.get("fid") or t.get("id")) != current_user_id
        ]
        logger.info(f"Found {len(all_users)} project users to provision")

        cluster_users: list[ClusterUser] = []
        used_usernames: set[str] = set()
        for user_info in all_users:
            cluster_user = create_cluster_user(user_info, used_usernames)
            used_usernames.add(cluster_user.linux_username)
            cluster_users.append(cluster_user)

        creator_username = cluster_users[0].linux_username if cluster_users else "ubuntu"

        project_id = controller.metadata.get("project")

        gpu_info = self.detect_gpu_info(controller)
        if gpu_info.count > 0:
            logger.info(
                f"Detected {gpu_info.count}x {gpu_info.raw_name} "
                f"({gpu_info.memory_mb}MB each) on controller"
            )

        partition = self.determine_partition_name(config, gpu_info)
        if partition != config.partition:
            logger.info(f"Using detected GPU-based partition name: {partition}")

        controller_setup = False
        setup_workers: list[ResolvedInstance] = []

        try:
            logger.info(f"Setting up controller on {controller.name} ({controller.host})")
            self._upload_and_run_script(
                controller,
                role="controller",
                partition=partition,
                max_time=config.max_time,
            )
            controller_setup = True

            controller_ip = self.get_instance_private_ip(controller)
            logger.info(f"Controller private IP: {controller_ip}")

            logger.info("Retrieving munge key from controller")
            munge_key = self._get_munge_key(controller)

            self._apply_controller_overrides(controller, config)

            if workers:
                self._register_workers_on_controller(controller, workers)

            for worker in workers:
                logger.info(f"Setting up worker on {worker.name} ({worker.host})")
                self._upload_and_run_script(
                    worker,
                    role="worker",
                    controller_ip=controller_ip,
                    munge_key=munge_key,
                )
                setup_workers.append(worker)

            logger.info("Verifying cluster health...")
            self._verify_cluster_health(controller, len(workers))

            self._update_instance_metadata(
                controller,
                config.name,
                "controller",
                controller_ip,
                partition=partition,
            )
            for worker in workers:
                self._update_instance_metadata(
                    worker,
                    config.name,
                    "worker",
                    controller_ip,
                    partition=partition,
                )

            if cluster_users:
                usernames = [u.linux_username for u in cluster_users]
                logger.info(f"Provisioning {len(usernames)} users on cluster nodes...")
                self._provision_users_on_nodes([controller] + workers, usernames)

        except Exception as e:
            logger.error(f"Cluster creation failed: {e}")
            logger.info("Rolling back partial setup...")
            self._rollback_create(controller if controller_setup else None, setup_workers)
            raise

        state = SlurmOverlayState(
            name=config.name,
            status="ready",
            controller_fid=controller.fid,
            controller_ip=controller_ip,
            worker_fids=[w.fid for w in workers],
            worker_ips={w.fid: w.private_ip for w in workers},
            partition=partition,
            created_at=datetime.now(UTC),
            project_id=project_id,
            created_by_user_id=current_user_id,
            created_by_username=creator_username,
            users=cluster_users,
        )
        state_store.save(state)
        logger.info(f"Cluster '{config.name}' created successfully with {len(cluster_users)} users")

        return state

    def add_workers(self, cluster_name: str, instance_ids: list[str]) -> SlurmOverlayState:
        """Add workers to an existing overlay cluster.

        This is idempotent - adding an already-joined worker will rejoin it.

        Args:
            cluster_name: Name of the cluster to add to.
            instance_ids: Instance identifiers to add as workers.

        Returns:
            Updated cluster state.
        """
        cluster = self.get_cluster(cluster_name)
        if cluster is None:
            raise SlurmOverlayError(f"Cluster '{cluster_name}' not found")

        controller = self.resolve_instance(cluster.controller_fid)
        existing_workers = self._resolve_cluster_workers(cluster.worker_fids)
        existing_worker_fids = {worker.fid for worker in existing_workers}

        controller_ip = cluster.controller_ip
        if not controller_ip:
            controller_ip = self.get_instance_private_ip(controller)
            logger.info(f"Got controller private IP via SSH: {controller_ip}")

        munge_key = self._get_munge_key(controller)

        requested_workers: list[ResolvedInstance] = []
        seen_requested: set[str] = set()
        for instance_id in instance_ids:
            worker = self.resolve_instance(instance_id)
            if worker.fid == cluster.controller_fid:
                raise SlurmOverlayError(
                    f"Cannot add controller '{worker.name}' as a worker in cluster '{cluster_name}'"
                )
            if worker.fid in seen_requested:
                continue
            seen_requested.add(worker.fid)
            self._check_instance_not_in_cluster(
                worker,
                require_remote_check=True,
                allowed_cluster_name=cluster_name,
            )
            requested_workers.append(worker)

        new_workers = [
            worker for worker in requested_workers if worker.fid not in existing_worker_fids
        ]
        desired_workers = existing_workers + new_workers
        if desired_workers:
            self._validate_instance_regions(controller, desired_workers)
        configured_new_workers: list[ResolvedInstance] = []
        controller_synced = False

        try:
            self._register_workers_on_controller(controller, desired_workers)
            controller_synced = True

            for worker in requested_workers:
                logger.info(f"Adding worker {worker.name} to cluster {cluster_name}")
                self._upload_and_run_script(
                    worker,
                    role="worker",
                    controller_ip=controller_ip,
                    munge_key=munge_key,
                )
                self._update_instance_metadata(
                    worker,
                    cluster_name,
                    "worker",
                    controller_ip,
                    partition=cluster.partition,
                )
                if worker.fid not in existing_worker_fids:
                    configured_new_workers.append(worker)

            if cluster.users and new_workers:
                usernames = [u.linux_username for u in cluster.users]
                logger.info(
                    f"Provisioning {len(usernames)} users on {len(new_workers)} new worker(s)..."
                )
                self._provision_users_on_nodes(new_workers, usernames)

            self._verify_cluster_health(controller, len(desired_workers))
        except Exception:
            # Best-effort rollback. We must not let rollback exceptions mask
            # the original failure, so each cleanup step logs and continues.
            if controller_synced:
                try:
                    self._register_workers_on_controller(controller, existing_workers)
                except Exception as revert_error:  # noqa: BLE001
                    logger.error(
                        "Failed to revert controller worker registration during "
                        "add_workers rollback: %s",
                        revert_error,
                    )
            for worker in configured_new_workers:
                try:
                    self._cleanup_worker_overlay(worker)
                except Exception as cleanup_error:  # noqa: BLE001
                    logger.error(
                        "Failed to clean up partially-added worker %s: %s",
                        worker.name,
                        cleanup_error,
                    )
            raise

        cluster.worker_fids = [worker.fid for worker in desired_workers]
        cluster.worker_ips = {worker.fid: worker.private_ip for worker in desired_workers}

        state_store = self._get_state_store()
        state_store.save(cluster)

        return cluster

    def remove_workers(
        self,
        cluster_name: str,
        instance_ids: list[str],
        force: bool = False,
        drain_timeout: int = 300,
    ) -> SlurmOverlayState:
        """Remove workers from an overlay cluster.

        Args:
            cluster_name: Name of the cluster.
            instance_ids: Instance identifiers to remove.
            force: Skip job drain if True.
            drain_timeout: Timeout for draining jobs in seconds.

        Returns:
            Updated cluster state.
        """
        cluster = self.get_cluster(cluster_name)
        if cluster is None:
            raise SlurmOverlayError(f"Cluster '{cluster_name}' not found")

        controller = self.resolve_instance(cluster.controller_fid)
        current_workers = self._resolve_cluster_workers(cluster.worker_fids)
        current_worker_map = {worker.fid: worker for worker in current_workers}
        removal_workers: list[ResolvedInstance] = []
        removal_fids: set[str] = set()

        for instance_id in instance_ids:
            worker = self.resolve_instance(instance_id)

            if worker.fid == cluster.controller_fid:
                raise SlurmOverlayError(
                    f"Cannot remove controller '{worker.name}' from cluster. "
                    f"Use 'dissolve' to remove the entire cluster."
                )
            if worker.fid not in current_worker_map:
                raise SlurmOverlayError(
                    f"Worker '{worker.name}' is not a member of cluster '{cluster_name}'"
                )
            if worker.fid in removal_fids:
                continue
            removal_fids.add(worker.fid)
            removal_workers.append(worker)

        if not force:
            for worker in removal_workers:
                logger.info(f"Draining jobs on {worker.name}...")
                self._drain_worker(controller, worker, drain_timeout)

        remaining_workers = [worker for worker in current_workers if worker.fid not in removal_fids]
        self._register_workers_on_controller(controller, remaining_workers)

        for worker in removal_workers:
            logger.info(f"Removing worker {worker.name} from cluster {cluster_name}")
            self._cleanup_worker_overlay(worker)

        cluster.worker_fids = [worker.fid for worker in remaining_workers]
        cluster.worker_ips = {worker.fid: worker.private_ip for worker in remaining_workers}
        state_store = self._get_state_store()
        state_store.save(cluster)

        return cluster

    def dissolve(self, cluster_name: str, force: bool = False) -> None:
        """Dissolve an overlay cluster.

        Removes Slurm from all instances but keeps them running.

        When ``force`` is True and a node cannot be resolved (for example
        because the underlying instance has been terminated outside Flow),
        the cleanup for that node is skipped with a warning and dissolve
        proceeds. Without ``force``, any unreachable node aborts the dissolve
        so state is preserved for later retry.

        Args:
            cluster_name: Name of the cluster to dissolve.
            force: Proceed past unreachable nodes if True.
        """
        from flow.application.slurm_overlay.exceptions import InstanceNotFoundError

        cluster = self.get_cluster(cluster_name)
        if cluster is None:
            raise SlurmOverlayError(f"Cluster '{cluster_name}' not found")

        logger.info(f"Dissolving cluster '{cluster_name}'")
        errors: list[str] = []
        skipped: list[str] = []

        for worker_fid in cluster.worker_fids:
            try:
                worker = self.resolve_instance(worker_fid)
            except InstanceNotFoundError as e:
                if force:
                    skipped.append(f"worker {worker_fid}: instance not found ({e})")
                    continue
                errors.append(f"worker {worker_fid}: instance not found ({e})")
                continue
            try:
                logger.info(f"Stopping Slurm on worker {worker.name}")
                self.run_ssh_command(
                    worker,
                    "sudo /tmp/slurm_overlay_setup.sh cleanup 2>/dev/null || "
                    "sudo systemctl stop slurmd munge; "
                    "sudo rm -f /etc/slurm/slurm.conf /etc/munge/munge.key",
                )
                self._clear_instance_metadata(worker)
            except SSHExecutionError as e:
                if force:
                    skipped.append(f"worker {worker.name}: {e}")
                else:
                    errors.append(f"worker {worker.name}: {e}")

        try:
            controller = self.resolve_instance(cluster.controller_fid)
        except InstanceNotFoundError as e:
            if force:
                skipped.append(f"controller {cluster.controller_fid}: {e}")
                controller = None
            else:
                errors.append(f"controller {cluster.controller_fid}: {e}")
                controller = None

        if controller is not None:
            try:
                logger.info(f"Stopping Slurm on controller {controller.name}")
                self.run_ssh_command(
                    controller,
                    "sudo /tmp/slurm_overlay_setup.sh cleanup 2>/dev/null || "
                    "sudo systemctl stop slurmctld slurmd slurmrestd munge; "
                    "sudo rm -f /etc/slurm/slurm.conf /etc/munge/munge.key",
                )
                self._clear_instance_metadata(controller)
            except SSHExecutionError as e:
                if force:
                    skipped.append(f"controller {controller.name}: {e}")
                else:
                    errors.append(f"controller {controller.name}: {e}")

        if errors:
            raise SlurmOverlayError(
                f"Failed to dissolve cluster '{cluster_name}': "
                + "; ".join(errors)
                + (f" (skipped: {', '.join(skipped)})" if skipped else "")
            )

        state_store = self._get_state_store()
        state_store.delete(cluster_name)

        if skipped:
            logger.warning(
                "Cluster '%s' dissolved with %d skipped node(s): %s",
                cluster_name,
                len(skipped),
                "; ".join(skipped),
            )
        else:
            logger.info(f"Cluster '{cluster_name}' dissolved")

    def get_cluster(self, cluster_name: str) -> SlurmOverlayState | None:
        """Get cluster state by name.

        Args:
            cluster_name: Name of the cluster.

        Returns:
            Cluster state, or None if not found.
        """
        state_store = self._get_state_store()
        return state_store.get(cluster_name)

    def list_clusters(self) -> list[SlurmOverlayState]:
        """List all overlay clusters.

        Returns:
            List of cluster states.
        """
        state_store = self._get_state_store()
        return state_store.list_all()

    # ------------------------------------------------------------------
    # Repair — high-level coordination, stays here
    # ------------------------------------------------------------------

    def repair_cluster(self, cluster_name: str) -> ClusterHealthReport:
        """Attempt to automatically repair common cluster issues.

        Performs the following repairs:
        1. Syncs users (adds new teammates, refreshes SSH keys)
        2. Restarts stopped Slurm services on reachable nodes
        3. Reconfigures Slurm controller to update node list
        4. Resumes nodes in DOWN state

        Args:
            cluster_name: Name of the cluster to repair.

        Returns:
            ClusterHealthReport after repair attempts (re-checked health).

        Raises:
            SlurmOverlayError: If cluster not found.
        """
        health_report = self.get_cluster_health(cluster_name)
        cluster = self.get_cluster(cluster_name)
        if cluster is None:
            raise SlurmOverlayError(f"Cluster '{cluster_name}' not found")

        repairs_attempted: list[str] = []
        repair_errors: list[str] = []

        try:
            self._sync_cluster_users(cluster, repairs_attempted, repair_errors)
        except SlurmOverlayError as e:
            repair_errors.append(f"User sync failed: {e}")

        # Repair 1: Restart stopped services on controller
        if (
            health_report.controller
            and health_report.controller.ssh_reachable
            and not health_report.controller.slurm_running
        ):
            try:
                controller = self.resolve_instance(cluster.controller_fid)
                self.run_ssh_command(
                    controller,
                    "sudo systemctl restart munge slurmctld slurmd",
                    timeout=60,
                )
                repairs_attempted.append("Restarted Slurm services on controller")
                logger.info(f"Restarted Slurm services on controller {controller.name}")
            except SSHExecutionError as e:
                repair_errors.append(f"Failed to restart controller services: {e}")
                logger.warning(f"Failed to restart controller services: {e}")

        # Repair 2: Restart stopped services on workers
        for worker_health in health_report.workers:
            if worker_health.ssh_reachable and not worker_health.slurm_running:
                try:
                    worker = self.resolve_instance(worker_health.fid)
                    self.run_ssh_command(
                        worker,
                        "sudo systemctl restart munge slurmd",
                        timeout=60,
                    )
                    repairs_attempted.append(f"Restarted slurmd on {worker_health.name}")
                    logger.info(f"Restarted slurmd on {worker_health.name}")
                except SSHExecutionError as e:
                    repair_errors.append(f"Failed to restart {worker_health.name}: {e}")
                    logger.warning(f"Failed to restart services on {worker_health.name}: {e}")

        # Repair 3: Resume nodes in DOWN state
        if (
            health_report.controller
            and health_report.controller.ssh_reachable
            and health_report.controller.slurm_running
        ):
            controller = self.resolve_instance(cluster.controller_fid)
            for worker_health in health_report.workers:
                if worker_health.slurm_state and "down" in worker_health.slurm_state.lower():
                    try:
                        short_name = worker_health.name.split(".")[0]
                        self.run_ssh_command(
                            controller,
                            f"sudo scontrol update NodeName={short_name} State=RESUME",
                            timeout=30,
                        )
                        repairs_attempted.append(f"Resumed node {worker_health.name}")
                        logger.info(f"Resumed node {worker_health.name}")
                    except SSHExecutionError as e:
                        repair_errors.append(f"Failed to resume {worker_health.name}: {e}")
                        logger.warning(f"Failed to resume node {worker_health.name}: {e}")

        # Repair 4: Reconfigure Slurm to apply pending changes
        if health_report.controller and health_report.controller.ssh_reachable:
            try:
                controller = self.resolve_instance(cluster.controller_fid)
                self.run_ssh_command(
                    controller,
                    "sudo scontrol reconfigure",
                    timeout=30,
                )
                repairs_attempted.append("Reconfigured Slurm controller")
                logger.info("Reconfigured Slurm controller")
            except SSHExecutionError:
                logger.debug("scontrol reconfigure did not complete (may be expected)")

        # Re-check health after repairs
        logger.info(f"Repairs attempted: {repairs_attempted}")
        if repair_errors:
            logger.warning(f"Repair errors: {repair_errors}")

        import time as time_module

        # Poll health for up to ~10s waiting for restarted services to settle.
        final_report = health_report
        for _ in range(5):
            time_module.sleep(2)
            final_report = self.get_cluster_health(cluster_name)
            if final_report.overall_status == "healthy":
                break

        if repairs_attempted:
            for repair in repairs_attempted:
                final_report.issues.append(f"[Repaired] {repair}")
        if repair_errors:
            for error in repair_errors:
                final_report.issues.append(f"[Repair failed] {error}")

        return final_report
