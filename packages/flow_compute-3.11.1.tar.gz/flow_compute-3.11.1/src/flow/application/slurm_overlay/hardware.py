"""Hardware detection for Slurm overlay clusters.

Provides GPU detection, node resource introspection, and partition naming
as free functions. Uses ssh_ops for remote command execution.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from flow.application.slurm_overlay.exceptions import SlurmOverlayError, SSHExecutionError
from flow.application.slurm_overlay.ssh_ops import ResolvedInstance, run_ssh_command

if TYPE_CHECKING:
    from flow.sdk.models.slurm_overlay import SlurmOverlayConfig

logger = logging.getLogger(__name__)


@dataclass
class GPUInfo:
    """Detected GPU information from an instance."""

    count: int
    gpu_type: str  # e.g., "b200", "h100", "a100"
    memory_mb: int
    driver_version: str
    raw_name: str  # e.g., "NVIDIA B200"

    @classmethod
    def empty(cls) -> GPUInfo:
        """Create an empty GPUInfo for instances without GPUs."""
        return cls(count=0, gpu_type="cpu", memory_mb=0, driver_version="", raw_name="")


# Known GPU type patterns ordered longest-first so that e.g. "L40S" matches
# before "L4".  Each entry is (substring to look for in lowercase, canonical type).
_GPU_TYPE_PATTERNS: list[tuple[str, str]] = [
    ("rtx4090", "rtx4090"),
    ("rtx3090", "rtx3090"),
    ("l40s", "l40s"),
    ("l40", "l40"),
    ("b200", "b200"),
    ("b100", "b100"),
    ("h200", "h200"),
    ("h100", "h100"),
    ("a100", "a100"),
    ("a10g", "a10g"),
    ("a10", "a10"),
    ("v100", "v100"),
    ("l4", "l4"),
    ("t4", "t4"),
]


def detect_gpu_type_from_name(gpu_name: str) -> str:
    """Extract GPU type from nvidia-smi output.

    Args:
        gpu_name: Full GPU name like "NVIDIA B200" or "NVIDIA A100-SXM4-80GB".

    Returns:
        Normalized GPU type like "b200", "a100", "h100".
    """
    if not gpu_name:
        return "gpu"

    name_lower = gpu_name.lower()
    for pattern, gpu_type in _GPU_TYPE_PATTERNS:
        if pattern in name_lower:
            return gpu_type

    return "gpu"


def detect_gpu_info(instance: ResolvedInstance) -> GPUInfo:
    """Detect GPU information from an instance via SSH.

    Args:
        instance: Resolved instance to query.

    Returns:
        GPUInfo with detected GPU details.
    """
    try:
        output = run_ssh_command(
            instance,
            "nvidia-smi --query-gpu=name,memory.total,driver_version "
            "--format=csv,noheader,nounits 2>/dev/null",
            timeout=30,
        )
    except SSHExecutionError as e:
        logger.warning(f"Failed to detect GPUs on {instance.name}: {e}")
        return GPUInfo.empty()

    # Each GPU produces one CSV line: "<name>, <memory_mib>, <driver>".
    # Filter stray stdout (warnings, blank lines) before counting devices.
    gpu_rows: list[list[str]] = []
    for line in output.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 3 and parts[0]:
            gpu_rows.append(parts)
    if not gpu_rows:
        logger.debug(f"No GPUs detected on {instance.name}")
        return GPUInfo.empty()

    first = gpu_rows[0]
    raw_name = first[0]
    memory_mb = int(first[1]) if first[1].isdigit() else 0
    driver_version = first[2]

    return GPUInfo(
        count=len(gpu_rows),
        gpu_type=detect_gpu_type_from_name(raw_name),
        memory_mb=memory_mb,
        driver_version=driver_version,
        raw_name=raw_name,
    )


def determine_partition_name(
    config: SlurmOverlayConfig,
    gpu_info: GPUInfo | None = None,
) -> str:
    """Determine the partition name for a cluster.

    The partition name is determined by:
    1. Explicit partition in config (if not default "gpu")
    2. Detected GPU type (e.g., "b200", "h100")
    3. Default fallback "gpu"

    Args:
        config: Cluster configuration with ``partition`` attribute.
        gpu_info: Detected GPU information (optional).

    Returns:
        Partition name to use.
    """
    if config.partition != "gpu":
        return config.partition

    if gpu_info and gpu_info.count > 0 and gpu_info.gpu_type != "gpu":
        return gpu_info.gpu_type

    return config.partition


def get_node_resources(instance: ResolvedInstance) -> dict[str, Any]:
    """Get node resources (hostname, CPUs, memory, GPUs, IP) from an instance.

    Args:
        instance: Resolved instance to query.

    Returns:
        Dictionary with hostname, cpus, real_memory, gpu_count, private_ip.

    Raises:
        SSHExecutionError: If SSH fails.
        SlurmOverlayError: If the remote shell could not produce usable
            resource data (no hostname, no CPU count, or no IP).
    """
    output = run_ssh_command(
        instance,
        "hostname -s && nproc && free -m | awk '/^Mem:/{print $2}' && hostname -I | awk '{print $1}'",
        timeout=30,
    )
    lines = [line.strip() for line in output.strip().split("\n")]

    hostname = lines[0] if len(lines) > 0 and lines[0] else instance.name
    cpus = int(lines[1]) if len(lines) > 1 and lines[1].isdigit() else 1
    total_mem = int(lines[2]) if len(lines) > 2 and lines[2].isdigit() else 8000
    private_ip = lines[3] if len(lines) > 3 and lines[3] else ""

    if not private_ip:
        # hostname -I can return empty if only loopback is up, which would
        # produce a broken slurm.conf (NodeAddr pointing at a public/fallback
        # IP). Fail loud so the caller can surface a clear error.
        raise SlurmOverlayError(
            f"Could not determine private IP for {instance.name}. "
            f"'hostname -I' returned no non-loopback addresses; check that "
            "the private network interface is up."
        )

    # Reserve 2GB for system
    real_memory = max(total_mem - 2048, 1024)

    gpu_info = detect_gpu_info(instance)

    return {
        "hostname": hostname,
        "cpus": cpus,
        "real_memory": real_memory,
        "gpu_count": gpu_info.count,
        "private_ip": private_ip,
    }
