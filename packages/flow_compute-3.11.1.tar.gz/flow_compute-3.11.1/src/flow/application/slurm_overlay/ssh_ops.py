"""SSH operations for Slurm overlay clusters.

Provides instance resolution, SSH command execution, and key management
as free functions. This module is the foundation that all other overlay
modules depend on for remote execution.
"""

from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from flow.application.slurm_overlay.exceptions import (
    InstanceNotFoundError,
    InstanceNotReadyError,
    SlurmOverlayError,
    SSHExecutionError,
)

if TYPE_CHECKING:
    from flow.protocols.provider import ProviderProtocol

logger = logging.getLogger(__name__)


@dataclass
class ResolvedInstance:
    """Resolved instance information for SSH operations."""

    fid: str
    name: str
    host: str
    private_ip: str
    ssh_user: str
    ssh_port: int
    ssh_key_path: Path
    metadata: dict[str, Any]
    region: str = ""  # Region where instance is deployed (e.g., "us-central1-b")


def resolve_instance(provider: ProviderProtocol, identifier: str) -> ResolvedInstance:
    """Resolve an instance identifier to SSH connection details.

    The lookup order is:

    1. Treat ``identifier`` as a task/bid id and call ``provider.get_task``.
       Only ``NotFoundError``-style results return ``None`` and fall through;
       other provider failures (auth, transient 5xx) propagate so the user
       sees the real error.
    2. Scan reservations for a matching name or FID.
    3. Scan tasks for a matching name or id.

    Args:
        provider: Provider instance for API operations.
        identifier: Instance name, FID, or bid ID.

    Returns:
        ResolvedInstance with connection details.

    Raises:
        InstanceNotFoundError: If the instance cannot be found by any lookup.
        InstanceNotReadyError: If the instance is not in a ready state.
    """
    try:
        task = _try_get_task(provider, identifier)

        if task is None:
            # Try to find by name or FID in reservations/instances
            reservations = provider.list_reservations()
            for res in reservations:
                if res.name == identifier or res.fid == identifier:
                    instances = getattr(res, "instances", []) or []
                    if instances:
                        inst = instances[0]
                        return _instance_to_resolved(inst, res)

            # Try to find in tasks
            tasks = provider.list_tasks()
            for t in tasks:
                if t.name == identifier or t.task_id == identifier:
                    task = t
                    break

        if task is None:
            raise InstanceNotFoundError(f"Instance '{identifier}' not found")

        # Check task status
        status = getattr(task, "status", None)
        if status and status.lower() not in ("running", "ready", "available"):
            raise InstanceNotReadyError(f"Instance '{identifier}' is not ready (status: {status})")

        # Get SSH connection info
        host = task.host() if callable(getattr(task, "host", None)) else getattr(task, "host", None)
        if not host:
            raise InstanceNotReadyError(f"Instance '{identifier}' has no SSH host available")

        ssh_key_path = _resolve_ssh_key(provider, task)

        region = getattr(task, "region", "") or ""

        return ResolvedInstance(
            fid=task.task_id,
            name=getattr(task, "name", identifier),
            host=host,
            private_ip=getattr(task, "private_ip", host),
            ssh_user=getattr(task, "ssh_user", "ubuntu"),
            ssh_port=int(getattr(task, "ssh_port", 22)),
            ssh_key_path=ssh_key_path,
            metadata=getattr(task, "provider_metadata", {}) or {},
            region=region,
        )

    except (InstanceNotFoundError, InstanceNotReadyError, SlurmOverlayError):
        raise
    except (AttributeError, TypeError, ValueError) as e:
        # These indicate bad provider response shapes; surface them as
        # not-found since the caller wanted to locate a specific instance.
        logger.debug(f"Error resolving instance {identifier}: {e}", exc_info=True)
        raise InstanceNotFoundError(f"Failed to resolve instance '{identifier}': {e}") from e


_NOT_FOUND_MARKERS = ("not found", "does not exist", "unknown task", "404")


def _try_get_task(provider: ProviderProtocol, identifier: str) -> Any | None:
    """Call ``provider.get_task`` and translate not-found errors to ``None``.

    Prefers the typed :class:`flow.errors.ResourceNotFoundError` hierarchy so
    callers do not need to rely on message-string heuristics. Providers that
    pre-date the typed errors can still surface not-found conditions via a
    class name containing ``NotFound`` or one of the ``_NOT_FOUND_MARKERS``
    in the message. Any other exception propagates so auth/rate-limit/5xx
    failures are not masked as a generic "instance not found".
    """
    try:
        return provider.get_task(identifier)
    except Exception as e:
        if _is_not_found(e):
            return None
        logger.debug(
            "provider.get_task raised a non-not-found error for %r: %s",
            identifier,
            e,
        )
        raise


def _is_not_found(error: Exception) -> bool:
    """Return True when ``error`` unambiguously indicates a missing resource."""
    try:
        from flow.errors import ResourceNotFoundError  # Imported lazily to keep overlays thin
    except ImportError:
        ResourceNotFoundError = None  # type: ignore[assignment]
    if ResourceNotFoundError is not None and isinstance(error, ResourceNotFoundError):
        return True
    # Fall back to class-name + message inspection for legacy providers.
    if "notfound" in type(error).__name__.lower():
        return True
    message = str(error).lower()
    return any(marker in message for marker in _NOT_FOUND_MARKERS)


def _instance_to_resolved(instance: Any, reservation: Any) -> ResolvedInstance:
    """Convert a provider instance object to ResolvedInstance."""
    host = getattr(instance, "public_ip", None) or getattr(instance, "private_ip", None)
    if not host:
        raise InstanceNotReadyError("Instance has no IP address available")

    ssh_key_path = _resolve_ssh_key_from_reservation(reservation)

    region = getattr(instance, "region", "") or getattr(reservation, "region", "") or ""

    return ResolvedInstance(
        fid=getattr(instance, "fid", str(instance)),
        name=getattr(instance, "name", getattr(reservation, "name", "")),
        host=host,
        private_ip=getattr(instance, "private_ip", host),
        ssh_user="ubuntu",
        ssh_port=22,
        ssh_key_path=ssh_key_path,
        metadata=getattr(instance, "provider_metadata", {}) or {},
        region=region,
    )


def _resolve_ssh_key(provider: ProviderProtocol, task: Any) -> Path:
    """Resolve SSH key path for a task.

    Falls back to the default local SSH key if the provider does not expose a
    task-scoped key or the lookup fails. Failures are logged at debug level so
    the fallback remains observable during troubleshooting.
    """
    try:
        result = provider.get_task_ssh_connection_info(task.task_id)
    except Exception as e:  # noqa: BLE001
        logger.debug("Provider could not supply SSH info for task %r: %s", task.task_id, e)
        return _find_default_ssh_key()
    if isinstance(result, Path):
        return result
    return _find_default_ssh_key()


def _resolve_ssh_key_from_reservation(reservation: Any) -> Path:
    """Resolve SSH key path for a reservation, falling back to defaults on error."""
    ssh_key_fids = getattr(reservation, "ssh_keys", []) or []

    if ssh_key_fids:
        try:
            from flow.core.utils.ssh_key import discover_local_ssh_keys

            local_keys = discover_local_ssh_keys()
        except Exception as e:  # noqa: BLE001
            logger.debug("Failed to discover local SSH keys for reservation: %s", e)
            local_keys = []
        if local_keys:
            return local_keys[0].private_key_path

    return _find_default_ssh_key()


def _find_default_ssh_key() -> Path:
    """Find a default SSH key."""
    from flow.core.ssh import find_fallback_private_key

    key = find_fallback_private_key()
    if key:
        return key

    ssh_dir = Path.home() / ".ssh"
    for name in ("id_ed25519", "id_rsa", "id_ecdsa"):
        p = ssh_dir / name
        if p.exists():
            return p

    raise SlurmOverlayError("No SSH key found. Please configure SSH keys.")


def run_ssh_command(
    instance: ResolvedInstance,
    command: str,
    stdin: bytes | None = None,
    timeout: int = 300,
    retries: int = 3,
    retry_delay: float = 2.0,
) -> str:
    """Execute a command on an instance via SSH with automatic retries.

    Args:
        instance: Resolved instance to connect to.
        command: Command to execute.
        stdin: Optional stdin data to send.
        timeout: Command timeout in seconds.
        retries: Number of retry attempts for transient failures.
        retry_delay: Delay between retries in seconds.

    Returns:
        Command stdout.

    Raises:
        SSHExecutionError: If the command fails after all retries.
    """
    import time as time_module

    from flow.core.ssh import build_ssh_command

    ssh_cmd = build_ssh_command(
        user=instance.ssh_user,
        host=instance.host,
        port=instance.ssh_port,
        key_path=instance.ssh_key_path,
        remote_command=command,
    )

    logger.debug(f"Executing SSH command on {instance.name}: {command[:100]}...")

    last_error: Exception | None = None
    for attempt in range(retries):
        try:
            result = subprocess.run(
                ssh_cmd,
                input=stdin,
                capture_output=True,
                timeout=timeout,
            )

            if result.returncode != 0:
                stderr = result.stderr.decode("utf-8", errors="replace")
                raise SSHExecutionError(
                    f"SSH command failed on {instance.name}: {stderr}",
                    returncode=result.returncode,
                    stderr=stderr,
                )

            return result.stdout.decode("utf-8", errors="replace")

        except subprocess.TimeoutExpired as e:
            last_error = SSHExecutionError(
                f"SSH command timed out on {instance.name} after {timeout}s",
                returncode=-1,
                stderr=str(e),
            )
            if attempt < retries - 1:
                logger.warning(
                    f"SSH timeout on {instance.name}, retrying ({attempt + 1}/{retries})..."
                )
                time_module.sleep(retry_delay)
        except OSError as e:
            last_error = SSHExecutionError(
                f"SSH connection error on {instance.name}: {e}",
                returncode=-1,
                stderr=str(e),
            )
            if attempt < retries - 1:
                logger.warning(
                    f"SSH connection error on {instance.name}, retrying ({attempt + 1}/{retries})..."
                )
                time_module.sleep(retry_delay)

    if last_error:
        raise last_error
    raise SSHExecutionError(
        f"SSH command failed on {instance.name} after {retries} attempts",
        returncode=-1,
        stderr="Unknown error",
    )


def get_instance_private_ip(instance: ResolvedInstance) -> str:
    """Get the private IP address of an instance via SSH.

    This is needed because the API may not always provide the private IP,
    and configless Slurm requires nodes to communicate via private IPs.

    Args:
        instance: Resolved instance to query.

    Returns:
        Private IP address of the instance.
    """
    output = run_ssh_command(
        instance,
        "hostname -I | awk '{print $1}'",
        timeout=30,
    )
    ip = output.strip()
    if not ip:
        logger.warning(f"Could not determine private IP for {instance.name}, using host")
        return instance.host
    return ip


def check_ssh_reachable(instance: ResolvedInstance) -> bool:
    """Quick SSH connectivity check.

    Returns False on SSH-level failures (timeout, auth, connection refused).
    Unexpected errors (e.g., programming bugs, missing key file) are logged
    and surfaced to the caller via re-raise so they are not silently masked.
    """
    try:
        run_ssh_command(instance, "echo ok", timeout=10)
        return True
    except SSHExecutionError as e:
        logger.debug("SSH unreachable for %s: %s", instance.name, e)
        return False


def check_service_running(instance: ResolvedInstance, service: str) -> bool:
    """Check if a systemd service is running.

    Returns False if the service is inactive or if SSH fails. Unexpected
    errors (bad key, programming bugs) are re-raised to surface the problem
    rather than silently marking the service as down.
    """
    try:
        output = run_ssh_command(
            instance,
            f"systemctl is-active {service} 2>/dev/null || echo inactive",
            timeout=10,
        )
    except SSHExecutionError as e:
        logger.debug("Service check for %s on %s failed: %s", service, instance.name, e)
        return False
    normalized = output.lower()
    return "active" in normalized and "inactive" not in normalized
