"""Serve command -- provision GPUs and run inference servers with local tunneling.

Provisions GPU instances, starts vLLM or SGLang model servers, and creates
an SSH tunnel so the OpenAI-compatible API is available on localhost.

Examples:
    flow serve meta-llama/Llama-3.1-405B
    flow serve deepseek-ai/DeepSeek-V3 --gpu b200 --num-gpus 8
    flow serve mistralai/Mistral-7B --engine sglang
    flow serve list
    flow serve stop my-serve
"""

from __future__ import annotations

import logging
import os
import re
import time
import urllib.error
import urllib.request

import click

import flow.sdk.factory as sdk_factory
from flow import DEFAULT_ALLOCATION_ESTIMATED_SECONDS
from flow.cli.commands.base import BaseCommand, console
from flow.cli.commands.utils import wait_for_task
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.step_progress import (
    AllocationProgressAdapter,
    SSHWaitProgressAdapter,
    StepTimeline,
)
from flow.domain.models.engine import build_engine_config
from flow.domain.models.inference import estimate_gpu_requirements, validate_gpu_capacity
from flow.errors import AuthenticationError, FlowError
from flow.sdk.models import TaskConfig
from flow.sdk.models.volume import VolumeSpec

logger = logging.getLogger(__name__)

_SERVE_ENV_KEY = "FLOW_SERVE"
_SERVE_MODEL_KEY = "FLOW_SERVE_MODEL"
_SERVE_ENGINE_KEY = "FLOW_SERVE_ENGINE"

# Health check settings
_HEALTH_CHECK_TIMEOUT_SECONDS = 600
_HEALTH_CHECK_INTERVAL_SECONDS = 3

# Model cache volume
_MODEL_CACHE_VOLUME_NAME = "model-cache"
_MODEL_CACHE_SIZE_GB = 500
_MODEL_CACHE_MOUNT_PATH = "/root/.cache/huggingface"


def _slugify_model_name(model: str) -> str:
    """Convert a HuggingFace model ID to a short slug for task naming.

    Example: "meta-llama/Llama-3.1-70B-Instruct" -> "llama-3-1-70b"
    """
    # Take the model part after the org
    name = model.split("/")[-1] if "/" in model else model
    # Lowercase, replace non-alphanumeric with hyphens, collapse runs
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    # Truncate to reasonable length
    return slug[:40]


def _build_instance_type(gpu_type: str, gpu_count: int) -> str:
    """Build a count-qualified instance type string like '1xa100' or '8xh100'."""
    return f"{gpu_count}x{gpu_type}"


class _ServeGroup(click.Group):
    """Custom group that routes unknown subcommands to the default 'run' handler.

    This allows both ``flow serve <model>`` and ``flow serve list`` to work:
    known subcommands (list, stop, logs) are dispatched normally, while any
    other first argument is treated as a model name for the 'run' subcommand.
    """

    def resolve_command(self, ctx: click.Context, args: list[str]) -> tuple:
        cmd_name, cmd, remaining = super().resolve_command(ctx, args)
        if cmd is not None:
            return cmd_name, cmd, remaining
        # Unknown subcommand: route to 'run' with original args
        return "run", self.commands["run"], args

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        # If first arg is not a known subcommand and not a flag, prepend 'run'
        if args and args[0] not in self.commands and not args[0].startswith("-"):
            args = ["run"] + args
        return super().parse_args(ctx, args)


class ServeCommand(BaseCommand):
    """Serve inference models on GPU instances."""

    @property
    def name(self) -> str:
        return "serve"

    @property
    def help(self) -> str:
        return "Serve models with vLLM/SGLang on GPU instances"

    @property
    def manages_own_progress(self) -> bool:
        return True

    def get_command(self) -> click.Group:
        @click.group(
            name=self.name,
            help=self.help,
            cls=_ServeGroup,
        )
        def serve_group():
            """Serve models with vLLM/SGLang on GPU instances.

            \b
            Examples:
                flow serve meta-llama/Llama-3.1-405B
                flow serve deepseek-ai/DeepSeek-V3 --gpu b200 --num-gpus 8
                flow serve list
                flow serve stop my-serve
            """

        serve_group.add_command(self._run_cmd())
        serve_group.add_command(self._list_cmd())
        serve_group.add_command(self._stop_cmd())
        serve_group.add_command(self._logs_cmd())
        return serve_group

    def _run_cmd(self) -> click.Command:
        from flow.cli.completion import complete_gpu_families as _complete_gpu_families

        @click.command(name="run")
        @click.argument("model")
        @click.option(
            "--gpu",
            type=str,
            default=None,
            help="GPU type (e.g., h100, b200)",
            shell_complete=_complete_gpu_families,
        )
        @click.option("--num-gpus", type=int, default=None, help="Number of GPUs")
        @click.option(
            "--engine",
            type=click.Choice(["vllm", "sglang"], case_sensitive=False),
            default="vllm",
            help="Inference engine (default: vllm)",
        )
        @click.option(
            "--quantization",
            "-q",
            type=str,
            default=None,
            help="Quantization method (awq, gptq, fp8)",
        )
        @click.option("--port", type=int, default=8000, help="Local port (default: 8000)")
        @click.option("--name", "-n", type=str, default=None, help="Task name")
        @click.option("--detach", is_flag=True, help="Provision and exit without tunneling")
        @click.option("--max-model-len", type=int, default=None, help="Maximum sequence length")
        @click.option("--region", "-r", type=str, default=None, help="Preferred region")
        @click.option("--hours", type=float, default=None, help="Maximum runtime in hours")
        @click.option(
            "--hf-token",
            type=str,
            default=None,
            help="HuggingFace token (default: $HF_TOKEN)",
        )
        @click.option(
            "--no-volume",
            is_flag=True,
            default=False,
            help="Skip persistent model-cache volume (use ephemeral storage)",
        )
        @cli_error_guard(self)
        def run_serve(
            model,
            gpu,
            num_gpus,
            engine,
            quantization,
            port,
            name,
            detach,
            max_model_len,
            region,
            hours,
            hf_token,
            no_volume,
        ):
            """Serve a model with GPU-accelerated inference."""
            self._execute_serve(
                model=model,
                gpu=gpu,
                num_gpus=num_gpus,
                engine=engine,
                quantization=quantization,
                local_port=port,
                task_name=name,
                detach=detach,
                max_model_len=max_model_len,
                region=region,
                hours=hours,
                hf_token=hf_token,
                no_volume=no_volume,
            )

        return run_serve

    # ------------------------------------------------------------------
    # Main serve execution
    # ------------------------------------------------------------------

    def _execute_serve(
        self,
        *,
        model: str,
        gpu: str | None,
        num_gpus: int | None,
        engine: str,
        quantization: str | None,
        local_port: int,
        task_name: str | None,
        detach: bool,
        max_model_len: int | None,
        region: str | None,
        hours: float | None,
        hf_token: str | None,
        no_volume: bool = False,
    ) -> None:
        """Resolve config, provision instance, start engine, tunnel to localhost."""
        # 1. Resolve GPU requirements
        auto_gpu, auto_count = estimate_gpu_requirements(model, quantization)
        gpu_type = gpu or auto_gpu
        gpu_count = num_gpus or auto_count

        # 1b. Validate GPU capacity when user overrides defaults
        if gpu or num_gpus:
            capacity_error = validate_gpu_capacity(
                model,
                gpu_type,
                gpu_count,
                quantization,
            )
            if capacity_error:
                raise click.UsageError(capacity_error)

        # 2. Build engine config
        engine_config = build_engine_config(
            model=model,
            engine=engine,  # type: ignore[arg-type]
            gpu_count=gpu_count,
            quantization=quantization,
            max_model_len=max_model_len,
            port=local_port,
        )

        # 3. Resolve HF token
        resolved_hf_token = hf_token or os.environ.get("HF_TOKEN")

        # 4. Build task name
        resolved_name = task_name or f"serve-{_slugify_model_name(model)}"

        # 5. Build TaskConfig
        instance_type = _build_instance_type(gpu_type, gpu_count)
        env: dict[str, str] = {
            _SERVE_ENV_KEY: "true",
            _SERVE_MODEL_KEY: model,
            _SERVE_ENGINE_KEY: engine_config.engine,
        }
        if not no_volume:
            # Point HuggingFace cache at the persistent volume so models
            # survive across instances. Without this, the Docker section
            # defaults HF_HOME to ephemeral NVMe and the volume goes unused.
            env["HF_HOME"] = _MODEL_CACHE_MOUNT_PATH
        if resolved_hf_token:
            env["HF_TOKEN"] = resolved_hf_token

        volumes: list[VolumeSpec] = []
        if not no_volume:
            volumes.append(
                VolumeSpec(
                    name=_MODEL_CACHE_VOLUME_NAME,
                    size_gb=_MODEL_CACHE_SIZE_GB,
                    mount_path=_MODEL_CACHE_MOUNT_PATH,
                    create_if_missing=True,
                ),
            )

        config = TaskConfig(
            name=resolved_name,
            unique_name=True,
            instance_type=instance_type,
            num_instances=1,
            command=engine_config.command,
            image=engine_config.image,
            ports=[engine_config.port],
            upload_code=False,
            volumes=volumes,
            env=env,
            max_run_time_hours=hours,
            region=region,
        )

        # 6. Show configuration
        console.print(f"\n[bold]Serving {model}[/bold]")
        console.print(f"  Engine:       {engine_config.engine}")
        console.print(f"  GPUs:         {gpu_count}x {gpu_type}")
        if quantization:
            console.print(f"  Quantization: {quantization}")
        console.print(f"  Local port:   {local_port}")
        console.print()

        # 7. Provision and wait
        timeline = StepTimeline(console, title="flow serve", title_animation="auto")
        timeline.start()

        try:
            # Submit
            submit_idx = timeline.add_step(
                f"Submitting {instance_type} request",
                show_bar=False,
            )
            timeline.start_step(submit_idx)
            flow_client = sdk_factory.create_client(auto_init=True)
            task = flow_client.run(config)
            timeline.complete_step()

            # Allocate
            alloc_idx = timeline.add_step(
                "Allocating GPU instance",
                show_bar=True,
                estimated_seconds=DEFAULT_ALLOCATION_ESTIMATED_SECONDS,
            )
            alloc = AllocationProgressAdapter(
                timeline,
                alloc_idx,
                estimated_seconds=DEFAULT_ALLOCATION_ESTIMATED_SECONDS,
            )
            with alloc:
                final_status = wait_for_task(
                    flow_client,
                    task.task_id,
                    watch=False,
                    task_name=task.name,
                    progress_adapter=alloc,
                    show_submission_message=False,
                )
            if final_status == "failed":
                timeline.fail_step(f"Status: {final_status}")
                timeline.finish()
                raise FlowError("Failed to start instance")
            if final_status != "running":
                # Still provisioning/pending -- continue to SSH wait which
                # has its own longer timeout and handles the transition.
                timeline.complete_step()

            # Wait for SSH
            from flow.sdk.ssh_utils import DEFAULT_PROVISION_MINUTES

            ssh_idx = timeline.add_step(
                f"Provisioning instance (up to {DEFAULT_PROVISION_MINUTES}m)",
                show_bar=True,
                estimated_seconds=DEFAULT_PROVISION_MINUTES * 60,
            )
            ssh_adapter = SSHWaitProgressAdapter(
                timeline,
                ssh_idx,
                DEFAULT_PROVISION_MINUTES * 60,
            )
            with ssh_adapter:
                task = flow_client.wait_for_ssh(
                    task_id=task.task_id,
                    timeout=DEFAULT_PROVISION_MINUTES * 60 * 2,
                    show_progress=False,
                    progress_adapter=ssh_adapter,
                )

            # Verify SSH daemon is accepting connections (not just that
            # metadata is available). Mirrors the probe loop in flow dev.
            ssh_key_path = flow_client.get_task_ssh_connection_info(task.task_id)
            if ssh_key_path and getattr(task, "ssh_host", None):
                from flow.core.ssh import is_ssh_ready as _is_ssh_ready

                ssh_probe_deadline = time.time() + 120
                while time.time() < ssh_probe_deadline:
                    if _is_ssh_ready(
                        user=getattr(task, "ssh_user", "ubuntu"),
                        host=task.ssh_host,
                        port=getattr(task, "ssh_port", 22) or 22,
                        key_path=ssh_key_path,
                    ):
                        break
                    time.sleep(2)

            # Detach mode: print info and exit
            if detach:
                timeline.finish()
                console.print("\n[bold success]Server provisioned[/bold success]")
                console.print(f"  Task:   {task.name}")
                console.print("  Status: flow serve list")
                console.print(f"  Logs:   flow serve logs {task.name}")
                console.print(f"  Stop:   flow serve stop {task.name}")
                return

            # Create SSH tunnel with retry for transient failures.
            tunnel_idx = timeline.add_step(
                f"Creating tunnel localhost:{local_port} -> remote:{engine_config.port}",
                show_bar=False,
            )
            timeline.start_step(tunnel_idx)

            from flow.adapters.transport.ssh.tunnel import SSHTunnelManager

            tunnel = None
            last_err: Exception | None = None
            for attempt in range(3):
                try:
                    tunnel = SSHTunnelManager.create_tunnel(
                        task,
                        local_port=local_port,
                        remote_port=engine_config.port,
                        key_path=ssh_key_path,
                    )
                    break
                except RuntimeError as exc:
                    last_err = exc
                    if attempt < 2:
                        logger.info(
                            "Tunnel attempt %d failed: %s; retrying in %ds",
                            attempt + 1,
                            exc,
                            5 * (attempt + 1),
                        )
                        time.sleep(5 * (attempt + 1))
            if tunnel is None:
                raise RuntimeError(f"SSH tunnel failed after 3 attempts: {last_err}") from last_err
            timeline.complete_step()

            # Health check: wait for model to load
            health_idx = timeline.add_step(
                "Waiting for model to load",
                show_bar=True,
                estimated_seconds=_HEALTH_CHECK_TIMEOUT_SECONDS,
            )
            timeline.start_step(health_idx)

            if self._health_check(tunnel.local_port):
                timeline.complete_step()
            else:
                timeline.fail_step("Model loading timed out")
                console.print(
                    "\n[warning]Warning: Health check timed out. "
                    "The model may still be loading.[/warning]"
                )
                console.print(f"Check logs: flow serve logs {task.name}")

            timeline.finish()

            # Print ready message
            self._print_ready(model, tunnel.local_port, task.name)

            # Block until Ctrl+C
            try:
                while tunnel.is_alive():
                    time.sleep(1)
            except KeyboardInterrupt:
                console.print("\n[dim]Disconnecting tunnel...[/dim]")
                tunnel.terminate()
                console.print(f"Instance still running. Stop: flow serve stop {task.name}")

        except AuthenticationError:
            timeline.finish()
            self.handle_auth_error()
        except KeyboardInterrupt:
            timeline.finish()
            console.print("\n[dim]Cancelled[/dim]")
        except FlowError:
            raise
        except Exception as exc:  # noqa: BLE001
            timeline.finish()
            self.handle_error(exc)

    def _health_check(self, port: int) -> bool:
        """Poll the vLLM/SGLang health endpoint until the model is ready."""
        deadline = time.time() + _HEALTH_CHECK_TIMEOUT_SECONDS
        url = f"http://localhost:{port}/v1/models"
        while time.time() < deadline:
            try:
                resp = urllib.request.urlopen(url, timeout=5)
                if resp.status == 200:
                    return True
            except (urllib.error.URLError, OSError, TimeoutError):
                pass
            time.sleep(_HEALTH_CHECK_INTERVAL_SECONDS)
        return False

    def _print_ready(self, model: str, port: int, task_name: str) -> None:
        """Print the ready message with usage examples."""
        console.print(f"\n[bold success]Model ready at http://localhost:{port}/v1[/bold success]")
        console.print("\nOpenAI-compatible API:")
        console.print(f"  curl http://localhost:{port}/v1/chat/completions \\")
        console.print('    -H "Content-Type: application/json" \\')
        console.print(
            f'    -d \'{{"model": "{model}", '
            f'"messages": [{{"role": "user", "content": "Hello"}}]}}\''
        )
        console.print("\nPython (OpenAI SDK):")
        console.print("  from openai import OpenAI")
        console.print(f'  client = OpenAI(base_url="http://localhost:{port}/v1", api_key="unused")')
        console.print(f'  client.chat.completions.create(model="{model}", messages=[...])')
        console.print("\nPress Ctrl+C to disconnect (instance keeps running)")
        console.print(f"Stop server: flow serve stop {task_name}")

    # ------------------------------------------------------------------
    # Subcommands
    # ------------------------------------------------------------------

    def _list_cmd(self) -> click.Command:
        @click.command(name="list")
        @click.option("--json", "output_json", is_flag=True, help="Output as JSON")
        @cli_error_guard(self)
        def list_servers(output_json: bool):
            """List running inference servers."""
            import json as json_mod

            flow_client = sdk_factory.create_client(auto_init=True)
            tasks = flow_client.list_tasks(limit=100)
            serve_tasks = [t for t in tasks if _is_serve_task(t)]

            if output_json:
                rows = [
                    {
                        "name": t.name,
                        "task_id": t.task_id,
                        "model": _get_serve_env(t, _SERVE_MODEL_KEY),
                        "engine": _get_serve_env(t, _SERVE_ENGINE_KEY),
                        "status": t.status,
                    }
                    for t in serve_tasks
                ]
                console.print(json_mod.dumps(rows, indent=2))
                return

            if not serve_tasks:
                console.print("[dim]No running inference servers[/dim]")
                console.print("Start one: flow serve <model>")
                return

            from flow.cli.ui.presentation.table_styles import create_flow_table

            table = create_flow_table(title="Inference Servers")
            table.add_column("Model", style="bold")
            table.add_column("Status")
            table.add_column("GPU")
            table.add_column("Engine", style="dim")
            table.add_column("Name", style="dim")

            for t in serve_tasks:
                model = _get_serve_env(t, _SERVE_MODEL_KEY) or "unknown"
                engine = _get_serve_env(t, _SERVE_ENGINE_KEY) or "vllm"
                status_style = "success" if t.status == "running" else "warning"
                instance = getattr(t, "instance_type", None) or ""
                table.add_row(
                    model,
                    f"[{status_style}]{t.status}[/{status_style}]",
                    str(instance),
                    engine,
                    t.name,
                )

            console.print(table)

        return list_servers

    def _stop_cmd(self) -> click.Command:
        @click.command(name="stop")
        @click.argument("task_identifier")
        @click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
        @cli_error_guard(self)
        def stop_server(task_identifier: str, yes: bool):
            """Stop a running inference server."""
            from flow.cli.utils.task_resolver import resolve_task_identifier

            flow_client = sdk_factory.create_client(auto_init=True)
            task, error = resolve_task_identifier(flow_client, task_identifier)
            if error:
                self.handle_error(error)
                return
            if task is None:
                self.handle_error(f"Task not found: {task_identifier}")
                return

            if not yes and not click.confirm(f"Stop server {task.name}?"):
                console.print("[dim]Cancelled[/dim]")
                return

            flow_client.cancel(task.task_id)
            console.print(f"[bold success]Stopped {task.name}[/bold success]")

        return stop_server

    def _logs_cmd(self) -> click.Command:
        @click.command(name="logs")
        @click.argument("task_identifier")
        @click.option("--follow", "-f", is_flag=True, help="Follow log output")
        @click.option("--tail", "-n", type=int, default=100, help="Number of lines to show")
        @cli_error_guard(self)
        def serve_logs(task_identifier: str, follow: bool, tail: int):
            """View inference server logs."""
            from flow.cli.utils.task_resolver import resolve_task_identifier

            flow_client = sdk_factory.create_client(auto_init=True)
            task, error = resolve_task_identifier(flow_client, task_identifier)
            if error:
                self.handle_error(error)
                return
            if task is None:
                self.handle_error(f"Task not found: {task_identifier}")
                return

            logs_text = flow_client.logs(
                task.task_id,
                follow=follow,
                tail=tail,
            )
            if logs_text:
                console.print(logs_text, markup=False, highlight=False)
            else:
                console.print("[dim]No logs available yet[/dim]")

        return serve_logs


def _is_serve_task(task: object) -> bool:
    """Check if a task was created by flow serve."""
    env = getattr(task, "env", None) or {}
    return env.get(_SERVE_ENV_KEY) == "true"


def _get_serve_env(task: object, key: str) -> str | None:
    """Get a serve-specific env value from a task."""
    env = getattr(task, "env", None) or {}
    return env.get(key)


command = ServeCommand()
