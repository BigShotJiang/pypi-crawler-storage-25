"""Synthetic demo data factory for health check demo mode.

Creates deterministic GPU health snapshots per task for consistent demo experiences.
"""

from __future__ import annotations

import hashlib
import random
from datetime import datetime, timezone
from typing import Any

from flow.cli.commands.health.scoring import calculate_health_score, determine_health_status
from flow.sdk.health_models import (
    ComponentHealth,
    GPUMetric,
    GPUProcess,
    HealthState,
    HealthStatus,
    NodeHealthSnapshot,
    SystemEvent,
    SystemMetrics,
)


def create_demo_snapshot(
    task: Any,
    thresholds: dict[str, Any],
    scenario_override: str | None = None,
) -> NodeHealthSnapshot:
    """Create a realistic demo snapshot matching production schema.

    Data is deterministic per-task to provide a stable experience across runs.

    Args:
        task: Task object with task_id, name, instance_type, num_instances.
        thresholds: Health threshold configuration dict.
        scenario_override: Force a specific scenario (healthy/degraded/critical).

    Returns:
        Fully populated NodeHealthSnapshot with computed health score/status.
    """
    # Deterministic RNG per task
    seed_int = int(hashlib.md5((task.task_id or task.name or "").encode()).hexdigest()[:8], 16)
    rng = random.Random(seed_int)

    gpu_count = _resolve_gpu_count(task)

    # Scenario: healthy / degraded / critical split
    scenario_roll = rng.random()
    scenario = (
        scenario_override
        if scenario_override in {"healthy", "degraded", "critical"}
        else (
            "healthy"
            if scenario_roll < 0.6
            else ("degraded" if scenario_roll < 0.85 else "critical")
        )
    )

    # GPU template values
    gpu_name = rng.choice(["NVIDIA A100 80GB", "NVIDIA H100 80GB", "NVIDIA L4"])
    mem_total = 81920 if "100" in gpu_name or "A100" in gpu_name else 24576
    power_limit = 300 if "100" in gpu_name or "A100" in gpu_name else 120
    max_clock = 1410 if "100" in gpu_name or "A100" in gpu_name else 1530

    gpu_metrics = _build_gpu_metrics(
        rng, gpu_count, scenario, gpu_name, mem_total, power_limit, max_clock, task.task_id
    )

    system_metrics = _build_system_metrics(rng, scenario)
    health_states, events = _build_health_events(rng, scenario)

    # Machine info
    machine_info = _build_machine_info(task, rng, gpu_count)

    snapshot = NodeHealthSnapshot(
        task_id=task.task_id,
        task_name=task.name or task.task_id,
        instance_id=getattr(task, "instance_id", "demo-instance"),
        instance_type=task.instance_type or "demo.gpu",
        timestamp=datetime.now(timezone.utc),
        gpud_healthy=True,
        gpud_version=machine_info.get("gpud_version"),
        machine_info=machine_info,
        gpu_metrics=gpu_metrics,
        system_metrics=system_metrics,
        health_states=health_states,
        events=events,
    )

    # Compute derived health
    snapshot.health_score = calculate_health_score(snapshot, thresholds)
    snapshot.health_status = determine_health_status(snapshot.health_score)

    # In demo, make scenario classification explicit for clarity
    if scenario == "degraded":
        snapshot.health_status = HealthStatus.DEGRADED
        snapshot.health_score = min(snapshot.health_score, 0.72)
    elif scenario == "critical":
        snapshot.health_status = HealthStatus.CRITICAL
        snapshot.health_score = min(snapshot.health_score, 0.55)

    return snapshot


def _resolve_gpu_count(task: Any) -> int:
    """Determine GPU count from instance type, aligned with status view logic."""
    gpu_count = 1
    try:
        it = (task.instance_type or "").lower()
        from flow.cli.ui.formatters.shared_gpu import GPUFormatter as _GPUFormatter

        parsed = _GPUFormatter.parse_gpu_count(it)
        if parsed and parsed > 0:
            gpu_count = parsed
    except Exception:  # noqa: BLE001
        # Fallback simple heuristics
        it = (task.instance_type or "").lower()
        if any(x in it for x in ["8x", "x8", "8g", "8gpu"]):
            gpu_count = 8
        elif any(x in it for x in ["2x", "x2", "2g", "2gpu"]):
            gpu_count = 2
        elif any(x in it for x in ["1x", "x1", "1g", "1gpu"]):
            gpu_count = 1

        # NVL topology (e.g., gb200nvl72) implies that many GPUs per node
        import re as _re

        m = _re.search(r"nvl(\d{1,3})", it)
        if m:
            try:
                nvl_count = int(m.group(1))
                if nvl_count > 0:
                    gpu_count = nvl_count
            except Exception:  # noqa: BLE001
                pass

    return gpu_count


def _build_gpu_metrics(
    rng: random.Random,
    gpu_count: int,
    scenario: str,
    gpu_name: str,
    mem_total: int,
    power_limit: int,
    max_clock: int,
    task_id: str,
) -> list[GPUMetric]:
    """Build synthetic GPU metrics for all GPUs in a node."""
    gpu_metrics: list[GPUMetric] = []
    for idx in range(gpu_count):
        base = rng.random()
        # Utilization per scenario
        if scenario == "healthy":
            utilization = 40 + base * 45  # 40-85%
            ecc = 0
            xid: list[str] = []
        elif scenario == "degraded":
            utilization = 70 + base * 25  # 70-95%
            ecc = 0 if base < 0.8 else 1
            xid = []
        else:  # critical
            utilization = 85 + base * 15  # 85-100%
            ecc = 1 if base < 0.6 else 2
            xid = ["Xid 79"] if base < 0.5 else ["Xid 13"]

        # Memory/power/clock
        mem_used = int((0.35 + base * 0.55) * mem_total)
        power_draw = min(power_limit, round((0.5 + base * 0.5) * power_limit, 1))
        clock = int(0.9 * max_clock + base * 0.1 * max_clock)

        # Temperature model tied to workload intensity
        mem_pct = (mem_used / max(1, mem_total)) * 100.0
        temp = 30.0 + 0.6 * utilization + 0.15 * mem_pct
        if scenario == "healthy":
            temp += rng.uniform(-3.0, 3.0)
        elif scenario == "degraded":
            temp += rng.uniform(5.0, 9.0)
        else:
            temp += rng.uniform(10.0, 14.0)
        temp = max(40.0, min(90.0, temp))

        # Processes
        processes = _build_processes(rng, idx, mem_used, base)

        gpu_metrics.append(
            GPUMetric(
                gpu_index=idx,
                uuid=f"GPU-{idx}-{task_id[:8]}",
                name=gpu_name,
                temperature_c=temp,
                power_draw_w=power_draw,
                power_limit_w=power_limit,
                memory_used_mb=mem_used,
                memory_total_mb=mem_total,
                gpu_utilization_pct=utilization,
                sm_occupancy_pct=max(0.0, min(100.0, utilization - 5 + rng.random() * 10)),
                clock_mhz=clock,
                max_clock_mhz=max_clock,
                ecc_errors=ecc,
                xid_events=xid,
                nvlink_status=(
                    "healthy"
                    if scenario != "critical"
                    else ("degraded" if base < 0.5 else "healthy")
                ),
                processes=processes,
            )
        )
    return gpu_metrics


def _build_processes(
    rng: random.Random, gpu_idx: int, mem_used: int, base: float
) -> list[GPUProcess]:
    """Build synthetic GPU process list."""
    processes: list[GPUProcess] = []
    proc_count = 1 + int(base * 3)
    remaining = mem_used
    for p in range(proc_count):
        if p == proc_count - 1:
            mem_p = max(128, remaining // 2)
        else:
            mem_p = max(128, int(remaining * (0.2 + rng.random() * 0.4)))
        remaining = max(0, remaining - mem_p)
        processes.append(
            GPUProcess(
                pid=10000 + gpu_idx * 100 + p,
                name=rng.choice(["python", "torchrun", "trainer", "inference-server"]),
                memory_mb=mem_p,
                gpu_index=gpu_idx,
            )
        )
    return processes


def _build_system_metrics(rng: random.Random, scenario: str) -> SystemMetrics:
    """Build synthetic system metrics."""
    if scenario == "healthy":
        cpu = 30 + rng.random() * 40
        mem_used_gb = 45 + rng.random() * 30
        disk = 50 + rng.random() * 20
    elif scenario == "degraded":
        cpu = 60 + rng.random() * 35
        mem_used_gb = 60 + rng.random() * 35
        disk = 70 + rng.random() * 20
    else:
        cpu = 85 + rng.random() * 10
        mem_used_gb = 90 + rng.random() * 30
        disk = 85 + rng.random() * 10

    return SystemMetrics(
        cpu_usage_pct=cpu,
        memory_used_gb=mem_used_gb,
        memory_total_gb=128.0,
        disk_usage_pct=disk,
        network_rx_mbps=round(50 + rng.random() * 150, 1),
        network_tx_mbps=round(40 + rng.random() * 120, 1),
        open_file_descriptors=400 + int(rng.random() * 800),
        load_average=[round(cpu / 100 * (1.0 + rng.random()), 2) for _ in range(3)],
    )


def _build_health_events(
    rng: random.Random, scenario: str
) -> tuple[list[HealthState], list[SystemEvent]]:
    """Build scenario-appropriate health states and events."""
    health_states: list[HealthState] = []
    events: list[SystemEvent] = []
    now = datetime.now(timezone.utc)

    if scenario == "healthy":
        health_states.append(
            HealthState(
                component="gpud", health=ComponentHealth.HEALTHY, message="GPUd OK", timestamp=now
            )
        )
    elif scenario == "degraded":
        health_states.append(
            HealthState(
                component="nvml",
                health=ComponentHealth.DEGRADED,
                message="ECC correctable errors detected",
                timestamp=now,
            )
        )
        events.append(
            SystemEvent(
                timestamp=now,
                component="driver",
                level="warning",
                message="Thermal throttling observed",
                details={},
            )
        )
        # Provider proactive response note for demos
        health_states.append(
            HealthState(
                component="provider",
                health=ComponentHealth.HEALTHY,
                message="Hot-swap node pre-warmed; automatic migration available",
                timestamp=now,
            )
        )
        events.append(
            SystemEvent(
                timestamp=now,
                component="provider",
                level="info",
                message="Provider alerted: thermal hotspot detected; replacement node ready",
                details={"action": "hot-swap-standby", "eta": "<30s"},
            )
        )
    else:  # critical
        health_states.append(
            HealthState(
                component="gpu",
                health=ComponentHealth.UNHEALTHY,
                message="High temperature and XID errors",
                timestamp=now,
            )
        )
        events.append(
            SystemEvent(
                timestamp=now,
                component="gpu",
                level="error",
                message="Xid error reported",
                details={"xid": rng.choice([79, 13])},
            )
        )

    return health_states, events


def _build_machine_info(task: Any, rng: random.Random, gpu_count: int) -> dict[str, Any]:
    """Build machine info dict for a demo snapshot."""
    machine_info: dict[str, Any] = {
        "gpud_version": "v0.5.1",
        "hostname": (task.name or task.task_id)[:20],
        "gpu_driver": rng.choice(["550.54", "535.129", "470.223"]),
        "cuda_version": rng.choice(["12.4", "12.1", "11.8"]),
        "note": "Demo mode: synthetic metrics",
    }

    try:
        nodes = int(getattr(task, "num_instances", 1) or 1)
    except Exception:  # noqa: BLE001
        nodes = 1
    try:
        machine_info["nodes"] = nodes
        machine_info["gpus_per_node"] = gpu_count
        machine_info["total_gpus"] = nodes * gpu_count
    except Exception:  # noqa: BLE001
        pass

    return machine_info
