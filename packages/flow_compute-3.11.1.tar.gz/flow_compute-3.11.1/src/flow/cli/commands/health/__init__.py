"""Health check command package.

Re-exports HealthCommand and the module-level command instance for
backward compatibility with ``from flow.cli.commands.health import command``.
"""

from flow.cli.commands.health.checker import HealthChecker
from flow.cli.commands.health.command import HealthCommand

command = HealthCommand()

__all__ = ["HealthChecker", "HealthCommand", "command"]
