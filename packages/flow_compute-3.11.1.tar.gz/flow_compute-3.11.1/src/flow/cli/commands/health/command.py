"""Health command CLI entry point.

HealthCommand defines the Click command group and dispatches to HealthChecker.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timedelta, timezone
from typing import Any

import click

from flow.adapters.integrations.health.config import (
    DEFAULT_GPUD_BIND,
    DEFAULT_GPUD_PORT,
    DEFAULT_GPUD_VERSION,
)
from flow.cli.commands.base import BaseCommand
from flow.cli.commands.health.checker import HealthChecker
from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.step_progress import StepTimeline
from flow.cli.utils.theme_manager import theme_manager
from flow.sdk.health import MetricsAggregator

console = theme_manager.create_console()


class _HealthGroup(click.Group):
    """Custom group that routes unknown subcommands to the 'task' handler.

    This allows ``flow health <task-id>`` as a shortcut for
    ``flow health task <task-id>``. Known subcommands (gpu, task,
    dashboard) are dispatched normally; anything else is treated as
    a task identifier.
    """

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0] not in self.commands and not args[0].startswith("-"):
            args = ["task"] + args
        return super().parse_args(ctx, args)


class HealthCommand(BaseCommand):
    """Health check command implementation."""

    @property
    def name(self) -> str:
        return "health"

    @property
    def help(self) -> str:
        return """Run health checks for your Flow setup or a specific task.

Usage:
  flow health              # System checks (connectivity, auth, SSH, sync)
  flow health <task>       # GPU health deep dive for a task
  flow health gpu          # Fleet-wide GPU monitoring
  flow health dashboard <task>  # Open GPU monitoring dashboard
"""

    def get_command(self) -> click.Command:
        @click.group(
            name=self.name,
            help=self.help,
            cls=_HealthGroup,
            invoke_without_command=True,
        )
        @click.option("--json", is_flag=True, help="Output results as JSON")
        @click.option("--fix", is_flag=True, help="Attempt to fix issues automatically")
        @click.option(
            "--verbose", "-v", is_flag=True, help="Show detailed diagnostics and explanations"
        )
        @click.pass_context
        @cli_error_guard(self)
        def health(ctx: click.Context, json: bool, fix: bool, verbose: bool) -> None:
            if ctx.invoked_subcommand is None:
                if verbose and not json and not fix:
                    console.print("\n[bold]Flow Health Check Details:[/bold]\n")
                    console.print("What it checks:")
                    console.print("  • API connectivity and response times")
                    console.print("  • Authentication and credential validity")
                    console.print("  • SSH key configuration and access")
                    console.print("  • Running instance synchronization")
                    console.print("  • GPU health metrics (temperature, memory, utilization)")
                    console.print("  • Task state consistency\n")
                    return
                self._execute(
                    json,
                    fix,
                    task_id=None,
                    gpu=False,
                    show_all=False,
                    history=None,
                    verbose=verbose,
                )

        @health.command(name="gpu", help="GPUd fleet monitoring")
        @click.option("--json", is_flag=True, help="Output results as JSON")
        @click.option("--watch", type=int, help="Refresh interval in seconds")
        @click.option("--filter", "name_filter", type=str, help="Substring filter for task name/ID")
        @click.option("--limit", type=int, help="Limit number of tasks scanned")
        @click.option("--all", "show_all", is_flag=True, help="Include non-GPU tasks")
        @cli_error_guard(self)
        def gpu(
            json: bool,
            watch: int | None,
            name_filter: str | None,
            limit: int | None,
            show_all: bool,
        ) -> None:
            self._execute(
                json,
                fix=False,
                task_id=None,
                gpu=True,
                show_all=show_all,
                history=None,
                verbose=False,
                watch_interval=watch,
                name_filter=name_filter,
                limit=limit,
            )

        @health.command(name="task", help="Task deep dive & history")
        @click.argument("task_id")
        @click.option("--json", is_flag=True, help="Output results as JSON")
        @click.option("--history", type=int, help="Show health history for last N hours")
        @click.option(
            "--no-auto-install",
            is_flag=True,
            default=False,
            help="Skip automatic GPUd installation on instances without it",
        )
        @cli_error_guard(self)
        def task(task_id: str, json: bool, history: int | None, no_auto_install: bool) -> None:
            self._execute(
                json,
                fix=False,
                task_id=task_id,
                gpu=False,
                show_all=False,
                history=history,
                verbose=False,
                auto_install=not no_auto_install,
            )

        @health.command(
            name="dashboard", help="Open GPU monitoring dashboard (Grafana + Prometheus)"
        )
        @click.argument("task_id")
        @click.option("--no-open", is_flag=True, help="Do not open browser automatically")
        @click.option(
            "--port",
            "local_port",
            type=int,
            default=None,
            help="Local port for Grafana UI (default: auto-select)",
        )
        @cli_error_guard(self)
        def dashboard(task_id: str, no_open: bool, local_port: int | None) -> None:
            import socket
            import subprocess
            import time
            import webbrowser

            import httpx

            import flow.sdk.factory as _sdk_factory
            from flow.cli.commands.health.grafana import (
                REMOTE_GRAFANA_HOST_PORT,
                RemoteGrafanaDashboard,
            )
            from flow.cli.utils.task_resolver import resolve_task_identifier
            from flow.core.ssh import build_ssh_command, find_fallback_private_key

            flow_client = _sdk_factory.create_client(auto_init=True)
            resolved_task, error = resolve_task_identifier(flow_client, task_id)
            if error:
                console.print(f"[error]{error}[/error]")
                return

            if not resolved_task.ssh_host:
                console.print(
                    "[error]Task has no SSH endpoint. It may still be provisioning.[/error]"
                )
                return

            key_path = flow_client.get_task_ssh_connection_info(resolved_task.task_id)
            if key_path is None:
                key_path = find_fallback_private_key()
            if key_path is None:
                console.print(
                    "[error]No SSH key found. Configure one via "
                    "MITHRIL_SSH_KEY or place a key in ~/.ssh/[/error]"
                )
                return

            task_label = resolved_task.name or resolved_task.task_id
            health_config = getattr(getattr(flow_client, "config", None), "health_config", {}) or {}
            gpud_port = int(health_config.get("gpud_port", DEFAULT_GPUD_PORT))
            gpud_version = str(health_config.get("gpud_version", DEFAULT_GPUD_VERSION))
            gpud_bind = str(health_config.get("gpud_bind", DEFAULT_GPUD_BIND))

            # Build SSH command prefix for remote commands
            ssh_prefix = build_ssh_command(
                user=resolved_task.ssh_user,
                host=resolved_task.ssh_host,
                port=resolved_task.ssh_port or 22,
                key_path=key_path,
            )

            # Ensure GPUd is running on the instance
            check_cmd = ssh_prefix + [f"curl -sf -m 3 https://localhost:{gpud_port}/healthz -k"]
            check = subprocess.run(
                check_cmd,
                capture_output=True,
                text=True,
                timeout=15,
            )
            if check.returncode != 0:
                console.print("GPUd is not running. Installing GPU monitoring daemon...")
                install_cmd = ssh_prefix + [
                    f"curl -fsSL https://pkg.gpud.dev/install.sh | bash -s -- {gpud_version}"
                ]
                install = subprocess.run(
                    install_cmd,
                    capture_output=True,
                    text=True,
                    timeout=120,
                )
                if install.returncode != 0:
                    console.print(
                        "[error]GPUd installation failed. "
                        "Check SSH access and instance state.[/error]"
                    )
                    return

                start_cmd = ssh_prefix + [f"sudo gpud up --web-address={gpud_bind}:{gpud_port}"]
                start_result = subprocess.run(
                    start_cmd,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if start_result.returncode != 0:
                    err = start_result.stderr.strip() if start_result.stderr else "unknown error"
                    console.print(
                        f"[error]GPUd failed to start: {err}. "
                        "Try running 'sudo gpud up' manually on the instance.[/error]"
                    )
                    return

                console.print("Waiting for GPUd to start...")
                gpud_ready = False
                deadline = time.monotonic() + 30
                while time.monotonic() < deadline:
                    poll = subprocess.run(
                        check_cmd,
                        capture_output=True,
                        text=True,
                        timeout=5,
                    )
                    if poll.returncode == 0:
                        gpud_ready = True
                        break
                    time.sleep(2)

                if not gpud_ready:
                    console.print(
                        "[error]GPUd installed but not responding. "
                        "Try again in a few seconds.[/error]"
                    )
                    return

                console.print("[success]GPUd installed and running.[/success]")

            # Deploy Grafana + Prometheus on the remote instance
            console.print(f"Deploying dashboard on [bold]{task_label}[/bold]...")
            remote_dashboard = RemoteGrafanaDashboard(
                ssh_prefix=ssh_prefix,
                task_name=task_label,
            )
            deploy_error = remote_dashboard.deploy()
            if deploy_error:
                console.print(f"[error]{deploy_error}[/error]")
                return

            # Pick a free local port for the SSH tunnel to Grafana
            if local_port is None:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(("127.0.0.1", 0))
                    local_port = s.getsockname()[1]

            # SSH tunnel: local_port -> instance Grafana port
            tunnel_cmd = build_ssh_command(
                user=resolved_task.ssh_user,
                host=resolved_task.ssh_host,
                port=resolved_task.ssh_port or 22,
                key_path=key_path,
                prefix_args=[
                    "-N",
                    "-o",
                    "ExitOnForwardFailure=yes",
                    "-L",
                    f"{local_port}:localhost:{REMOTE_GRAFANA_HOST_PORT}",
                ],
                use_mux=False,
            )

            tunnel = subprocess.Popen(
                tunnel_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            # Wait for Grafana to be reachable through the tunnel
            grafana_url = f"http://localhost:{local_port}"
            tunnel_ready = False
            for _ in range(15):
                time.sleep(1)
                if tunnel.poll() is not None:
                    break
                try:
                    resp = httpx.get(
                        f"{grafana_url}/api/health",
                        timeout=2,
                    )
                    if resp.status_code == 200:
                        tunnel_ready = True
                        break
                except (httpx.ConnectError, httpx.ReadError, httpx.TimeoutException):
                    continue

            if tunnel.poll() is not None:
                remote_dashboard.teardown()
                console.print(
                    "[error]SSH tunnel exited unexpectedly. Cannot reach instance.[/error]"
                )
                return

            if not tunnel_ready:
                tunnel.terminate()
                remote_dashboard.teardown()
                console.print(
                    "[error]SSH tunnel established but Grafana is not "
                    "responding. Check instance state.[/error]"
                )
                return

            if not no_open:
                webbrowser.open(grafana_url)

            console.print(f"\n[bold]Dashboard:[/bold] {grafana_url}")
            console.print(f"[bold]Task:[/bold]      {task_label}")
            console.print("\nPress Ctrl+C to stop.")

            try:
                tunnel.wait()
            except KeyboardInterrupt:
                pass
            finally:
                console.print("\n[dim]Stopping dashboard...[/dim]")
                remote_dashboard.teardown()
                tunnel.terminate()
                tunnel.wait(timeout=5)
                console.print("[dim]Done.[/dim]")

        return health

    def _execute(
        self,
        output_json: bool,
        fix: bool,
        task_id: str | None,
        gpu: bool,
        show_all: bool,
        history: int | None,
        verbose: bool = False,
        watch_interval: int | None = None,
        name_filter: str | None = None,
        limit: int | None = None,
        auto_install: bool = True,
    ) -> None:
        """Execute health check command."""
        try:
            import flow.sdk.factory as _sdk_factory
            from flow.cli.utils.task_resolver import resolve_task_identifier

            flow_client = _sdk_factory.create_client(auto_init=True)
            checker = HealthChecker(flow_client, json_mode=output_json)

            # Resolve task identifier (name, prefix, index) to actual task ID
            if task_id:
                resolved_task, error = resolve_task_identifier(flow_client, task_id)
                if error:
                    if output_json:
                        print(json.dumps({"error": error}, indent=2))
                    else:
                        console.print(f"[error]{error}[/error]")
                    return
                task_id = resolved_task.task_id

            # GPU health check mode
            if gpu:
                fleet_summary = checker.check_fleet_gpu_health(
                    show_all=show_all,
                    json_mode=output_json,
                    name_filter=name_filter,
                    limit=limit,
                    watch_interval=watch_interval,
                )

                if not output_json:
                    checker.renderer.render_fleet_summary(fleet_summary)

                report = checker.generate_report()
                report["fleet_summary"] = {
                    "timestamp": fleet_summary.timestamp.isoformat(),
                    "total_nodes": fleet_summary.total_nodes,
                    "healthy_nodes": fleet_summary.healthy_nodes,
                    "degraded_nodes": fleet_summary.degraded_nodes,
                    "critical_nodes": fleet_summary.critical_nodes,
                    "total_gpus": fleet_summary.total_gpus,
                    "healthy_gpus": fleet_summary.healthy_gpus,
                    "avg_gpu_temperature": fleet_summary.avg_gpu_temperature,
                    "avg_gpu_utilization": fleet_summary.avg_gpu_utilization,
                    "avg_gpu_memory_utilization": fleet_summary.avg_gpu_memory_utilization,
                    "fleet_health_score": fleet_summary.fleet_health_score,
                    "critical_issues": fleet_summary.critical_issues,
                    "warnings": fleet_summary.warnings,
                }

                if output_json:
                    print(json.dumps(report, indent=2))
                return

            # Task health history mode
            if task_id and history:
                if not output_json:
                    with AnimatedEllipsisProgress(
                        console, f"Fetching health history for {task_id}", start_immediately=True
                    ):
                        snapshots = list(
                            checker.metrics_store.read_snapshots(
                                start_date=datetime.now(timezone.utc) - timedelta(hours=history),
                                task_id=task_id,
                            )
                        )
                else:
                    snapshots = list(
                        checker.metrics_store.read_snapshots(
                            start_date=datetime.now(timezone.utc) - timedelta(hours=history),
                            task_id=task_id,
                        )
                    )

                if snapshots:
                    latest = max(snapshots, key=lambda s: s.timestamp)

                    if not output_json:
                        checker.renderer.render_node_details(latest)

                        if len(snapshots) > 1:
                            aggregator = MetricsAggregator(checker.metrics_store)
                            summary = aggregator.get_task_summary(task_id, history)

                            console.print("\n[bold]Historical Summary[/bold]")
                            console.print(f"Snapshots: {summary['snapshot_count']}")
                            console.print(
                                f"Average Health Score: {summary['health_score']['average']:.1%}"
                            )
                            console.print(
                                f"Min/Max: {summary['health_score']['min']:.1%} / {summary['health_score']['max']:.1%}"
                            )
                            console.print(f"Unhealthy Periods: {summary['unhealthy_periods']}")
                    else:
                        report = {
                            "task_id": task_id,
                            "hours": history,
                            "snapshots": [s.to_dict() for s in snapshots],
                            "latest": latest.to_dict(),
                        }
                        print(json.dumps(report, indent=2))
                else:
                    if not output_json:
                        console.print(
                            f"[warning]No health history found for task {task_id}[/warning]"
                        )
                    else:
                        print(
                            json.dumps(
                                {"error": f"No health history found for task {task_id}"}, indent=2
                            )
                        )
                return

            # Regular health check mode
            if not output_json:
                timeline = StepTimeline(console)
                timeline.start()
                try:
                    from rich.text import Text

                    accent = theme_manager.get_color("accent")
                    hint = Text()
                    hint.append("  Press ")
                    hint.append("Ctrl+C", style=accent)
                    hint.append(" to skip remaining checks. You can re-run with ")
                    hint.append("flow health --verbose", style=accent)
                    timeline.set_active_hint_text(hint)
                except Exception:  # noqa: BLE001
                    pass

                idx_conn = timeline.add_step("Connectivity", show_bar=False)
                timeline.start_step(idx_conn)
                checker.check_connectivity()
                timeline.complete_step()

                idx_auth = timeline.add_step("Authentication", show_bar=False)
                timeline.start_step(idx_auth)
                checker.check_authentication()
                timeline.complete_step()

                idx_cloud = timeline.add_step("Cloud credentials", show_bar=False)
                timeline.start_step(idx_cloud)
                checker.check_cloud_credentials()
                timeline.complete_step()

                idx_ssh = timeline.add_step("SSH keys", show_bar=False)
                timeline.start_step(idx_ssh)
                checker.check_ssh_keys()
                timeline.complete_step()

                idx_sync = timeline.add_step("State synchronization", show_bar=False)
                timeline.start_step(idx_sync)
                sync_status = checker.check_instance_sync()
                timeline.complete_step()
                timeline.finish()
            else:
                checker.check_connectivity()
                checker.check_authentication()
                checker.check_cloud_credentials()
                checker.check_ssh_keys()
                sync_status = checker.check_instance_sync()

            # Specific task check
            task_health = None
            gpu_health = None
            if task_id:
                task_health = checker.check_instance_health(task_id)

                if task_health["ssh_ready"]:
                    checker.add_success("Task Health", f"Task {task_id} is healthy and SSH-ready")
                else:
                    issues_str = (
                        ", ".join(task_health["issues"]) if task_health["issues"] else "Unknown"
                    )
                    checker.add_issue(
                        "Task Health",
                        f"Task {task_id} has issues: {issues_str}",
                        "Check logs with 'flow logs' or try restarting the task",
                    )

                gpu_health = checker.check_gpu_health(task_id, auto_install=auto_install)
                if gpu_health and not output_json:
                    console.print("\n")
                    checker.renderer.render_node_details(gpu_health)

            report = checker.generate_report()
            report["schema_version"] = "1.0"
            report["sync_status"] = sync_status
            if task_health:
                report["task_health"] = task_health

            if output_json:
                print(json.dumps(report, indent=2))
            else:
                checker.renderer.render_report_sections(
                    report.get("summary", {}), report.get("details", {})
                )
                if "sync_status" in report:
                    checker.renderer.render_orphaned_instances(report["sync_status"], fix)

                # Show cached fleet health if a recent GPU scan exists
                try:
                    recent = list(
                        checker.metrics_store.read_snapshots(
                            start_date=datetime.now(timezone.utc) - timedelta(hours=1),
                        )
                    )
                    if recent:
                        from flow.adapters.integrations.health.fleet_aggregator import (
                            FleetHealthAggregator,
                        )

                        latest_by_task: dict[str, Any] = {}
                        for snap in recent:
                            existing = latest_by_task.get(snap.task_id)
                            if existing is None or snap.timestamp > existing.timestamp:
                                latest_by_task[snap.task_id] = snap
                        fleet = FleetHealthAggregator().aggregate(list(latest_by_task.values()))
                        if fleet.total_nodes > 0:
                            checker.renderer.render_fleet_summary(fleet)
                except Exception:  # noqa: BLE001
                    pass  # Cached data unavailable -- not a failure

                fail_on = (os.environ.get("FLOW_HEALTH_FAIL_ON") or "never").lower()
                issues = report["summary"].get("issues", 0)
                warnings = report["summary"].get("warnings", 0)
                if fail_on == "issues" and issues > 0:
                    sys.exit(2)
                if fail_on == "warnings" and (issues > 0 or warnings > 0):
                    sys.exit(1)

        except Exception as e:  # noqa: BLE001
            if output_json:
                error_report = {
                    "error": str(e),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                print(json.dumps(error_report, indent=2))
            else:
                console.print(f"[error]✗ Health check failed: {e!s}[/error]")
