"""Health score calculation and GPU health analysis.

Pure computation on NodeHealthSnapshot data with configurable thresholds.
"""

from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any

from flow.sdk.health_models import HealthStatus, NodeHealthSnapshot


def calculate_health_score(
    snapshot: NodeHealthSnapshot,
    thresholds: dict[str, Any],
) -> float:
    """Calculate overall health score (v2) with component weights and time-decayed events.

    Args:
        snapshot: Node health snapshot to score.
        thresholds: Configurable threshold dict (temperature_warning_c, etc.).

    Returns:
        Health score between 0.0 and 1.0.
    """
    event_tau = float(thresholds.get("event_tau_hours", 6.0))

    def decay(age_hours: float | None, tau: float | None = None) -> float:
        if tau is None:
            tau = event_tau
        if age_hours is None or age_hours < 0:
            return 1.0
        try:
            return math.exp(-float(age_hours) / float(tau))
        except Exception:  # noqa: BLE001
            return 1.0

    def event_penalty(match_terms: list[str], base_penalty: float = 0.3, tau: float = 6.0) -> float:
        if not snapshot.events:
            return 0.0
        penalty = 0.0
        now = datetime.now(timezone.utc)
        for ev in snapshot.events:
            comp = (ev.component or "").lower()
            msg = (ev.message or "").lower()
            text = comp + " " + msg
            if any(term in text for term in match_terms):
                severity = (ev.level or "info").lower()
                sev_weight = 1.0 if severity == "error" else 0.5 if severity == "warning" else 0.2
                age_h = None
                try:
                    age_h = (now - ev.timestamp).total_seconds() / 3600.0
                except Exception:  # noqa: BLE001
                    age_h = None
                penalty += base_penalty * sev_weight * decay(age_h, tau)
        return min(penalty, 0.8)

    # Thresholds (configurable)
    temp_warn_c = float(thresholds.get("temperature_warning_c", 75))
    temp_crit_c = float(thresholds.get("temperature_critical_c", 85))
    mem_warn_pct = float(thresholds.get("gpu_memory_warning_pct", 90))
    mem_crit_pct = float(thresholds.get("gpu_memory_critical_pct", 98))
    host_cpu_crit_pct = float(thresholds.get("host_cpu_critical_pct", 95))
    host_mem_crit_pct = float(thresholds.get("host_memory_critical_pct", 95))
    host_disk_crit_pct = float(thresholds.get("host_disk_critical_pct", 95))

    # Component: GPU hardware
    if snapshot.gpu_metrics:
        gpu_scores = []
        for g in snapshot.gpu_metrics:
            score = 1.0
            if g.temperature_c >= temp_crit_c:
                score *= 0.4
            elif g.temperature_c >= temp_warn_c:
                score *= 0.75
            if g.is_throttling:
                score *= 0.75
            if getattr(g, "ecc_errors", 0) and g.ecc_errors > 0:
                score *= 0.6
            if getattr(g, "xid_events", None):
                score *= 0.7
            gpu_scores.append(score)
        gpu_hardware = sum(gpu_scores) / len(gpu_scores)
    else:
        gpu_hardware = 0.5

    # Component: Memory
    if snapshot.gpu_metrics:
        mem_scores = []
        for g in snapshot.gpu_metrics:
            score = 1.0
            mem_pct = getattr(g, "memory_utilization_pct", 0.0)
            if mem_pct >= mem_crit_pct:
                score *= 0.7
            elif mem_pct >= mem_warn_pct:
                score *= 0.85
            if getattr(g, "ecc_errors", 0) and g.ecc_errors > 0:
                score *= 0.7
            mem_scores.append(score)
        memory_component = sum(mem_scores) / len(mem_scores)
    else:
        memory_component = 0.7

    # Component: Interconnect
    interconnect = 1.0
    nvlink_bad = any(
        str(getattr(g, "nvlink_status", "healthy")).lower() not in ("healthy", "ok")
        for g in (snapshot.gpu_metrics or [])
    )
    if nvlink_bad:
        interconnect *= 0.75
    interconnect -= event_penalty(["nvlink", "nvswitch"], base_penalty=0.25)
    interconnect -= event_penalty(
        ["infiniband", "ib", "rdma", "roce", "nic", "ethernet"], base_penalty=0.25
    )
    interconnect = max(0.0, interconnect)

    # Component: Host
    host = 1.0
    if snapshot.system_metrics:
        if snapshot.system_metrics.cpu_usage_pct >= host_cpu_crit_pct:
            host *= 0.9
        if snapshot.system_metrics.memory_utilization_pct >= host_mem_crit_pct:
            host *= 0.85
        disk = getattr(snapshot.system_metrics, "disk_usage_pct", None)
        if isinstance(disk, int | float) and disk >= host_disk_crit_pct:
            host *= 0.9
    else:
        host = 0.8

    # Component: Software
    software = 1.0
    software -= event_penalty(["nccl", "watchdog", "timeout"], base_penalty=0.35)
    software -= event_penalty(["driver", "reset", "xid", "sxid"], base_penalty=0.2)
    software = max(0.0, software)

    weights = {
        "gpu": 0.55,
        "memory": 0.15,
        "interconnect": 0.10,
        "host": 0.10,
        "software": 0.10,
    }
    score = (
        weights["gpu"] * gpu_hardware
        + weights["memory"] * memory_component
        + weights["interconnect"] * interconnect
        + weights["host"] * host
        + weights["software"] * software
    )

    # Confidence annotation
    signals = 0
    present = 0
    for present_flag in [
        bool(snapshot.gpu_metrics),
        True,
        snapshot.system_metrics is not None,
        bool(snapshot.events),
    ]:
        signals += 1
        if present_flag:
            present += 1
    confidence = present / max(1, signals)
    snapshot.machine_info = dict(snapshot.machine_info or {})
    snapshot.machine_info["health_score_breakdown"] = {
        "gpu": round(gpu_hardware, 3),
        "memory": round(memory_component, 3),
        "interconnect": round(interconnect, 3),
        "host": round(host, 3),
        "software": round(software, 3),
        "confidence": round(confidence, 3),
    }

    return max(0.0, min(1.0, score))


def determine_health_status(score: float) -> HealthStatus:
    """Determine health status from score."""
    if score >= 0.8:
        return HealthStatus.HEALTHY
    elif score >= 0.6:
        return HealthStatus.DEGRADED
    elif score > 0:
        return HealthStatus.CRITICAL
    else:
        return HealthStatus.UNKNOWN


def analyze_gpu_health(
    snapshot: NodeHealthSnapshot,
) -> tuple[list[dict], list[dict], list[dict]]:
    """Analyze GPU health and return categorized findings.

    Args:
        snapshot: Node health snapshot to analyze.

    Returns:
        Tuple of (issues, warnings, successes) where each is a list of
        dicts with keys: category, message, suggestion (optional).
    """
    issues: list[dict] = []
    warnings: list[dict] = []
    successes: list[dict] = []

    if not snapshot.gpu_metrics:
        return issues, warnings, successes

    for gpu in snapshot.gpu_metrics:
        # Temperature warnings
        if gpu.temperature_c >= 85:
            issues.append(
                {
                    "category": "GPU Health",
                    "message": f"GPU {gpu.gpu_index} temperature critical: {gpu.temperature_c}°C",
                    "suggestion": "Check cooling and reduce workload",
                }
            )
        elif gpu.temperature_c >= 75:
            warnings.append(
                {
                    "category": "GPU Health",
                    "message": f"GPU {gpu.gpu_index} temperature high: {gpu.temperature_c}°C",
                }
            )

        # Memory pressure
        if gpu.memory_utilization_pct >= 95:
            warnings.append(
                {
                    "category": "GPU Health",
                    "message": f"GPU {gpu.gpu_index} memory nearly full: {gpu.memory_utilization_pct:.0f}%",
                    "suggestion": "Consider using gradient checkpointing or smaller batch sizes",
                }
            )

        # Throttling
        if gpu.is_throttling:
            issues.append(
                {
                    "category": "GPU Health",
                    "message": f"GPU {gpu.gpu_index} is throttling (clock: {gpu.clock_mhz}MHz, max: {gpu.max_clock_mhz}MHz)",
                    "suggestion": "Check power limits and thermal conditions",
                }
            )

        # ECC errors
        if gpu.ecc_errors > 0:
            issues.append(
                {
                    "category": "GPU Health",
                    "message": f"GPU {gpu.gpu_index} has {gpu.ecc_errors} ECC errors",
                    "suggestion": "Monitor for increasing errors; may indicate hardware issues",
                }
            )

    # Overall status
    if snapshot.health_status == HealthStatus.HEALTHY:
        successes.append(
            {
                "category": "GPU Health",
                "message": f"All {len(snapshot.gpu_metrics)} GPUs are healthy",
            }
        )

    return issues, warnings, successes
