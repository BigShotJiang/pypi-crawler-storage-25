"""SSH-based GPUd diagnostics and remote API queries.

Handles SSH command building, GPUd health checking via SSH fallback,
marker file interpretation, and GPUd API querying (via tunnel or SSH curl).
"""

from __future__ import annotations

import logging
import subprocess
from datetime import datetime, timezone
from typing import Any

import httpx

from flow.adapters.integrations.health.gpud_v08_adapter import (
    build_events,
    build_health_states,
    parse_network_health,
)
from flow.cli.commands.health.scoring import calculate_health_score, determine_health_status
from flow.sdk.health_models import (
    ComponentHealth,
    GPUMetric,
    GPUProcess,
    HealthState,
    NodeHealthSnapshot,
    SystemEvent,
    SystemMetrics,
)

logger = logging.getLogger(__name__)


def build_ssh_command_prefix(
    task: Any,
    *,
    key_path: str | None = None,
) -> list[str]:
    """Build SSH command prefix for remote commands.

    Args:
        task: Task object with ssh_user, ssh_host, ssh_port attributes.
        key_path: Path to the SSH private key. When None, falls back to
            ``find_fallback_private_key()`` which searches environment
            variables and ``~/.ssh/`` defaults. Callers should prefer
            passing the provider-resolved key obtained from
            ``flow_client.get_task_ssh_connection_info(task_id)``.
    """
    from flow.core.ssh import build_ssh_command, find_fallback_private_key

    if key_path is None:
        key_path = find_fallback_private_key()
    return build_ssh_command(
        user=getattr(task, "ssh_user", "ubuntu"),
        host=task.ssh_host,
        port=getattr(task, "ssh_port", 22),
        key_path=key_path,
    )


def check_gpud_via_ssh(
    task: Any,
    task_age_hours: float | None,
    marker_status: str | None,
    health_endpoints: list[str],
    ssh_curl_timeout: int,
    gpud_port: int,
    *,
    key_path: str | None = None,
) -> Any:
    """Check GPUd health via direct SSH commands (fallback method).

    Args:
        task: Task object with SSH details.
        task_age_hours: Age of task in hours.
        marker_status: GPUd marker file status.
        health_endpoints: Ordered list of health endpoint paths to try.
        ssh_curl_timeout: Curl timeout in seconds.
        gpud_port: GPUd port number.
        key_path: Path to the SSH private key for authentication.

    Returns:
        GPUdDiagnosis object.
    """
    from flow.sdk.health import GPUdDiagnosis, GPUdStatus

    try:
        ssh_cmd = build_ssh_command_prefix(task, key_path=key_path)

        # Check if GPUd is responding using configured endpoints
        result = None
        for path in health_endpoints:
            check_cmd = ssh_cmd + [
                "curl",
                "-s",
                "-k",
                "-f",
                "-m",
                str(ssh_curl_timeout),
                f"https://localhost:{gpud_port}{path}",
            ]
            result = subprocess.run(check_cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                break

        if result and result.returncode == 0:
            return GPUdDiagnosis(
                GPUdStatus.HEALTHY,
                "GPUd is responding to health checks",
                {"method": "ssh_fallback"},
            )
        else:
            # Check if GPUd process exists
            ps_result = subprocess.run(
                ssh_cmd + ["sh", "-c", "ps aux | grep gpud | grep -v grep"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if ps_result.returncode == 0 and "gpud" in ps_result.stdout:
                return GPUdDiagnosis(
                    GPUdStatus.STARTING,
                    "GPUd process is running but not responding to health checks yet",
                )
            else:
                if marker_status in ("install_failed", "start_failed"):
                    return GPUdDiagnosis(GPUdStatus.FAILED, f"GPUd setup failed: {marker_status}")
                elif marker_status in ("attempted", "not_ready"):
                    return GPUdDiagnosis(
                        GPUdStatus.STARTING,
                        f"GPUd setup in progress: {marker_status}",
                    )
                else:
                    return GPUdDiagnosis(
                        GPUdStatus.NOT_INSTALLED, "GPUd not installed or not running"
                    )

    except subprocess.TimeoutExpired:
        return GPUdDiagnosis(GPUdStatus.FAILED, "SSH command timed out")
    except Exception as e:  # noqa: BLE001
        return GPUdDiagnosis(GPUdStatus.FAILED, f"Failed to check GPUd via SSH: {e!s}")


def diagnose_with_marker(
    api_url: str,
    task_age_hours: float | None,
    marker_status: str | None,
    http_client: httpx.Client,
    health_endpoints: list[str],
    gpud_health_timeout: int,
) -> Any:
    """Diagnose GPUd status using both API check and marker file.

    Args:
        api_url: GPUd API base URL (via tunnel).
        task_age_hours: Age of task in hours.
        marker_status: GPUd marker file status.
        http_client: HTTP client for API requests.
        health_endpoints: Ordered list of health endpoint paths.
        gpud_health_timeout: Timeout for health check requests.

    Returns:
        GPUdDiagnosis object.
    """
    from flow.sdk.health import GPUdDiagnosis, GPUdStatus

    # Probe live health endpoints FIRST — a live GPUd overrides any stale marker.
    for path in health_endpoints:
        try:
            resp = http_client.get(f"{api_url}{path}", timeout=gpud_health_timeout)
            if resp.status_code == 200:
                return GPUdDiagnosis(GPUdStatus.HEALTHY, "GPUd is responding")
        except Exception:  # noqa: BLE001
            continue

    # Endpoint not responding — use marker as diagnostic context.
    # Marker values written by the startup template (gpud_health.sh.j2):
    #   attempted      -> install started but hasn't finished yet
    #   install_failed -> install script returned nonzero
    #   start_failed   -> gpud up returned nonzero
    #   not_ready      -> gpud started but health endpoint didn't respond in time
    #   running        -> full setup succeeded
    if marker_status in ("install_failed", "start_failed"):
        return GPUdDiagnosis(
            GPUdStatus.FAILED,
            f"GPUd setup failed: {marker_status}",
            {"marker_status": marker_status},
        )
    if marker_status == "attempted":
        return GPUdDiagnosis(
            GPUdStatus.STARTING,
            "GPUd installation is in progress",
            {"marker_status": marker_status},
        )
    if marker_status == "not_ready":
        return GPUdDiagnosis(
            GPUdStatus.STARTING,
            "GPUd started but health endpoint not ready yet",
            {"marker_status": marker_status},
        )
    if marker_status == "running":
        return GPUdDiagnosis(
            GPUdStatus.STARTING,
            "GPUd marker says running but health endpoint is not responding yet",
            {"marker_status": marker_status},
        )

    return GPUdDiagnosis(GPUdStatus.NOT_INSTALLED, "GPUd not installed or not running")


def query_gpud_api(
    api_url: str,
    task: Any,
    http_client: httpx.Client,
    health_endpoints: list[str],
    gpud_http_timeout: int,
    thresholds: dict[str, Any],
) -> tuple[NodeHealthSnapshot | None, list[dict], list[dict]]:
    """Query GPUd API endpoints to build health snapshot.

    Args:
        api_url: GPUd API base URL.
        task: Task object with instance info.
        http_client: HTTP client for requests.
        health_endpoints: Ordered list of health endpoint paths.
        gpud_http_timeout: HTTP request timeout.
        thresholds: Health threshold configuration.

    Returns:
        Tuple of (snapshot_or_none, issues, warnings).
    """
    issues: list[dict] = []
    warnings: list[dict] = []

    try:
        # Check if GPUd is running using configured endpoints
        gpud_healthy = False
        for path in health_endpoints:
            try:
                health_resp = http_client.get(f"{api_url}{path}", timeout=gpud_http_timeout)
                if health_resp.status_code == 200:
                    gpud_healthy = True
                    break
            except Exception:  # noqa: BLE001
                continue

        if not gpud_healthy:
            issues.append(
                {
                    "category": "GPU Health",
                    "message": "GPUd is not responding",
                    "suggestion": "Check if GPUd is running on the instance",
                }
            )
            return None, issues, warnings

        # Get machine info
        machine_info = {}
        try:
            resp = http_client.get(f"{api_url}/machine-info", timeout=gpud_http_timeout)
            if resp.status_code == 200:
                machine_info = resp.json()
        except Exception:  # noqa: BLE001
            pass

        # Get GPU metrics
        gpu_metrics = _fetch_gpu_metrics(http_client, api_url, gpud_http_timeout, warnings)

        # Get system metrics and health states
        system_metrics, health_states, network_health = _fetch_system_states(
            http_client, api_url, gpud_http_timeout
        )

        # Get recent events
        events = _fetch_events(http_client, api_url, gpud_http_timeout)

        # Enrich machine_info with cluster topology
        _enrich_machine_info(machine_info, task, gpu_metrics)

        # Create snapshot
        snapshot = NodeHealthSnapshot(
            task_id=task.task_id,
            task_name=task.name or task.task_id,
            instance_id=getattr(task, "instance_id", "unknown"),
            instance_type=task.instance_type or "unknown",
            timestamp=datetime.now(timezone.utc),
            gpud_healthy=gpud_healthy,
            gpud_version=machine_info.get("gpud_version"),
            machine_info=machine_info,
            gpu_metrics=gpu_metrics,
            system_metrics=system_metrics,
            health_states=health_states,
            events=events,
            infiniband_healthy=network_health["infiniband_healthy"],
            nccl_healthy=network_health["nccl_healthy"],
        )

        # Calculate health score
        snapshot.health_score = calculate_health_score(snapshot, thresholds)
        snapshot.health_status = determine_health_status(snapshot.health_score)

        return snapshot, issues, warnings

    except Exception as e:  # noqa: BLE001
        issues.append({"category": "GPU Health", "message": f"Failed to query GPUd API: {e!s}"})
        return None, issues, warnings


def query_gpud_api_via_ssh(
    task: Any,
    ssh_curl_timeout: int,
    gpud_port: int,
    thresholds: dict[str, Any],
    *,
    key_path: str | None = None,
) -> NodeHealthSnapshot | None:
    """Query GPUd API via direct SSH curl commands when tunneling is unavailable.

    Args:
        task: Task object with SSH details.
        ssh_curl_timeout: Curl timeout in seconds.
        gpud_port: GPUd port number.
        thresholds: Health threshold configuration.
        key_path: Path to the SSH private key for authentication.

    Returns:
        NodeHealthSnapshot if successful, None otherwise.
    """
    import json as _json

    try:
        ssh_cmd = build_ssh_command_prefix(task, key_path=key_path)

        def ssh_curl(path: str) -> tuple[int, str]:
            cmd = ssh_cmd + [
                "sh",
                "-c",
                f"curl -s -k -f -m {int(ssh_curl_timeout)} https://localhost:{int(gpud_port)}{path}",
            ]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            return res.returncode, res.stdout

        # Machine info
        machine_info = {}
        rc, out = ssh_curl("/machine-info")
        if rc == 0 and out.strip():
            try:
                machine_info = _json.loads(out)
            except Exception:  # noqa: BLE001
                pass

        # GPU metrics
        gpu_metrics: list[GPUMetric] = []
        raw_metrics: list | None = None
        rc, out = ssh_curl("/v1/metrics")
        if rc == 0 and out.strip():
            try:
                parsed = _json.loads(out)
                gpu_metrics = _parse_metrics_response(parsed)
                if isinstance(parsed, list):
                    raw_metrics = parsed
            except Exception:  # noqa: BLE001
                pass

        # System states
        system_metrics = None
        health_states: list[HealthState] = []
        network_health = {"infiniband_healthy": True, "nccl_healthy": True}
        rc, out = ssh_curl("/v1/states")
        if rc == 0 and out.strip():
            try:
                states_data = _json.loads(out)
                system_metrics, health_states, network_health = _parse_states_response(states_data)
            except Exception:  # noqa: BLE001
                pass

        # v0.5.1: states list doesn't include system metrics; extract from metrics
        if system_metrics is None and raw_metrics is not None:
            system_metrics = _extract_system_metrics_from_v051(raw_metrics)

        # Events
        events: list[SystemEvent] = []
        rc, out = ssh_curl("/v1/events")
        if rc == 0 and out.strip():
            try:
                events = _parse_events_response(_json.loads(out) or {})
            except Exception:  # noqa: BLE001
                pass

        # Enrich machine info
        _enrich_machine_info(machine_info, task, gpu_metrics)

        snapshot = NodeHealthSnapshot(
            task_id=task.task_id,
            task_name=task.name or task.task_id,
            instance_id=getattr(task, "instance_id", "unknown"),
            instance_type=task.instance_type or "unknown",
            timestamp=datetime.now(timezone.utc),
            gpud_healthy=True,
            gpud_version=machine_info.get("gpud_version"),
            machine_info=machine_info,
            gpu_metrics=gpu_metrics,
            system_metrics=system_metrics,
            health_states=health_states,
            events=events,
            infiniband_healthy=network_health["infiniband_healthy"],
            nccl_healthy=network_health["nccl_healthy"],
        )

        snapshot.health_score = calculate_health_score(snapshot, thresholds)
        snapshot.health_status = determine_health_status(snapshot.health_score)

        return snapshot

    except Exception:  # noqa: BLE001
        return None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_states_response(
    states_data: dict | list,
) -> tuple[SystemMetrics | None, list[HealthState], dict[str, bool]]:
    """Parse /v1/states response, handling both dict and list formats.

    GPUd v0.5.1+ returns a JSON array of component objects::

        [{"component": "...", "states": [{"health": "Healthy", ...}]}]

    Older versions returned a dict with ``cpu``, ``memory``, etc. keys.
    """
    system_metrics = None
    health_states: list[HealthState] = []
    network_health = {"infiniband_healthy": True, "nccl_healthy": True}

    # v0.5.1+ list format: extract HealthState entries from each component
    if isinstance(states_data, list):
        health_states = build_health_states(states_data)
        network_health = parse_network_health(states_data)
        return system_metrics, health_states, network_health

    # Legacy dict format
    cpu_data = states_data.get("cpu", {})
    memory_data = states_data.get("memory", {})
    system_metrics = SystemMetrics(
        cpu_usage_pct=cpu_data.get("usage_percent", 0),
        memory_used_gb=memory_data.get("used_gb", 0),
        memory_total_gb=memory_data.get("total_gb", 0),
        disk_usage_pct=float(states_data.get("disk", {}).get("usage_pct", 0) or 0),
        load_average=cpu_data.get("load_average", []),
    )
    components = (
        states_data.get("health_states")
        or states_data.get("states")
        or states_data.get("components")
        or []
    )
    for comp in components:
        health_str = str(comp.get("health", "unknown")).lower()
        health_enum = (
            ComponentHealth(health_str)
            if health_str in {e.value for e in ComponentHealth}
            else ComponentHealth.UNKNOWN
        )
        ts = None
        ts_raw = comp.get("timestamp")
        if ts_raw:
            try:
                ts = datetime.fromisoformat(str(ts_raw).replace("Z", "+00:00"))
            except Exception:  # noqa: BLE001
                pass
        health_states.append(
            HealthState(
                component=str(comp.get("component", comp.get("name", "unknown"))),
                health=health_enum,
                message=str(comp.get("message", "")),
                severity=str(comp.get("severity", "info")),
                timestamp=ts,
            )
        )

    return system_metrics, health_states, network_health


def _parse_metrics_response(
    metrics_data: dict | list,
) -> list[GPUMetric]:
    """Parse /v1/metrics response, handling both dict and list formats.

    GPUd v0.5.1+ returns a flat list of component metric objects (Prometheus-style)::

        [{"component": "accelerator-nvidia-power", "metrics": [
            {"name": "accelerator_nvidia_power_current_usage_milli_watts",
             "labels": {"uuid": "GPU-xxx"}, "value": 139428}, ...
        ]}, ...]

    Older versions returned a dict with a ``gpu_metrics`` key containing
    pre-aggregated per-GPU objects.
    """
    # Legacy dict format
    if isinstance(metrics_data, dict):
        return _parse_legacy_gpu_metrics(metrics_data)

    # v0.5.1+ list format: aggregate flat metrics by GPU UUID
    gpu_data_by_uuid: dict[str, dict[str, float]] = {}
    for comp in metrics_data:
        comp_name = comp.get("component", "")
        if "nvidia" not in comp_name:
            continue
        for m in comp.get("metrics", []):
            uuid = m.get("labels", {}).get("uuid")
            if not uuid:
                continue
            gpu_data_by_uuid.setdefault(uuid, {})
            gpu_data_by_uuid[uuid][m["name"]] = m.get("value", 0)

    gpu_metrics: list[GPUMetric] = []
    for idx, uuid in enumerate(sorted(gpu_data_by_uuid)):
        d = gpu_data_by_uuid[uuid]
        power_mw = d.get("accelerator_nvidia_power_current_usage_milli_watts", 0)
        limit_mw = d.get("accelerator_nvidia_power_enforced_limit_milli_watts", 0)
        mem_used = d.get("accelerator_nvidia_memory_used_bytes", 0)
        mem_total = d.get("accelerator_nvidia_memory_total_bytes", 0)
        ecc_uncorrected = int(d.get("accelerator_nvidia_ecc_aggregate_total_uncorrected", 0) or 0)
        nvlink_enabled = d.get("accelerator_nvidia_nvlink_feature_enabled", 1)
        nvlink_errs = (
            int(d.get("accelerator_nvidia_nvlink_replay_errors", 0) or 0)
            + int(d.get("accelerator_nvidia_nvlink_recovery_errors", 0) or 0)
            + int(d.get("accelerator_nvidia_nvlink_crc_errors", 0) or 0)
        )
        nvlink_status = "healthy" if nvlink_enabled and nvlink_errs == 0 else "degraded"

        gpu_metrics.append(
            GPUMetric(
                gpu_index=idx,
                uuid=uuid,
                name="GPU",  # v0.5.1 metrics don't include GPU model name
                temperature_c=d.get("accelerator_nvidia_temperature_current_celsius", 0),
                power_draw_w=power_mw / 1000.0,
                power_limit_w=limit_mw / 1000.0,
                memory_used_mb=int(mem_used / 1_048_576),
                memory_total_mb=int(mem_total / 1_048_576),
                gpu_utilization_pct=d.get("accelerator_nvidia_utilization_gpu_util_percent", 0),
                sm_occupancy_pct=0,
                clock_mhz=int(d.get("accelerator_nvidia_clock_speed_graphics_mhz", 0) or 0),
                max_clock_mhz=0,
                ecc_errors=ecc_uncorrected,
                nvlink_status=nvlink_status,
            )
        )
    return gpu_metrics


def _parse_legacy_gpu_metrics(metrics_data: dict) -> list[GPUMetric]:
    """Parse legacy dict-format GPU metrics (pre-v0.5.1)."""
    gpu_metrics: list[GPUMetric] = []
    for gpu_data in metrics_data.get("gpu_metrics", []):
        processes = []
        for p in gpu_data.get("processes", []) or []:
            try:
                processes.append(
                    GPUProcess(
                        pid=int(p.get("pid", 0)),
                        name=str(p.get("name", "")),
                        memory_mb=int(p.get("memory_mb", 0)),
                        gpu_index=int(p.get("gpu_index", gpu_data.get("index", 0))),
                    )
                )
            except Exception:  # noqa: BLE001
                continue
        gpu_metrics.append(
            GPUMetric(
                gpu_index=gpu_data.get("index", 0),
                uuid=gpu_data.get("uuid", ""),
                name=gpu_data.get("name", "Unknown"),
                temperature_c=gpu_data.get("temperature", 0),
                power_draw_w=gpu_data.get("power_draw", 0),
                power_limit_w=gpu_data.get("power_limit", 0),
                memory_used_mb=gpu_data.get("memory_used_mb", 0),
                memory_total_mb=gpu_data.get("memory_total_mb", 0),
                gpu_utilization_pct=gpu_data.get("gpu_utilization", 0),
                sm_occupancy_pct=gpu_data.get("sm_occupancy", 0),
                clock_mhz=gpu_data.get("clock_mhz", 0),
                max_clock_mhz=gpu_data.get("max_clock_mhz", 0),
                ecc_errors=int(gpu_data.get("ecc_errors", 0) or 0),
                xid_events=list(gpu_data.get("xid_events", []) or []),
                nvlink_status=str(gpu_data.get("nvlink_status", "healthy") or "healthy"),
                processes=processes,
            )
        )
    return gpu_metrics


def _fetch_gpu_metrics(
    http_client: httpx.Client, api_url: str, timeout: int, warnings: list[dict]
) -> list[GPUMetric]:
    """Fetch and parse GPU metrics from GPUd API."""
    try:
        resp = http_client.get(f"{api_url}/v1/metrics", timeout=timeout)
        if resp.status_code == 200:
            return _parse_metrics_response(resp.json())
    except Exception as e:  # noqa: BLE001
        warnings.append({"category": "GPU Health", "message": f"Failed to get GPU metrics: {e!s}"})
    return []


def _extract_system_metrics_from_v051(metrics_data: list) -> SystemMetrics | None:
    """Extract system metrics (CPU, memory, disk) from v0.5.1 metrics list.

    v0.5.1 bundles system metrics alongside GPU metrics in the same
    ``/v1/metrics`` response. This extracts CPU, memory, and disk data
    when ``/v1/states`` doesn't provide them in the list format.
    """
    flat: dict[str, float] = {}
    for comp in metrics_data:
        comp_name = comp.get("component", "")
        if comp_name not in ("cpu", "memory", "disk"):
            continue
        for m in comp.get("metrics", []):
            flat[m["name"]] = m.get("value", 0)

    if not flat:
        return None

    mem_total = flat.get("memory_total_bytes", 0)
    mem_used = flat.get("memory_used_bytes", 0)
    disk_total = flat.get("disk_total_bytes", 0)
    disk_used = flat.get("disk_used_bytes", 0)

    return SystemMetrics(
        cpu_usage_pct=flat.get("cpu_used_percent", 0),
        memory_used_gb=mem_used / (1024**3) if mem_used else 0,
        memory_total_gb=mem_total / (1024**3) if mem_total else 0,
        disk_usage_pct=(disk_used / disk_total * 100) if disk_total else 0,
        load_average=[flat.get("cpu_load_average", 0)],
    )


def _fetch_system_states(
    http_client: httpx.Client, api_url: str, timeout: int
) -> tuple[SystemMetrics | None, list[HealthState], dict[str, bool]]:
    """Fetch system metrics and component health states from GPUd API."""
    system_metrics = None
    health_states: list[HealthState] = []
    network_health = {"infiniband_healthy": True, "nccl_healthy": True}
    try:
        resp = http_client.get(f"{api_url}/v1/states", timeout=timeout)
        if resp.status_code == 200:
            states_data = resp.json()
            system_metrics, health_states, network_health = _parse_states_response(states_data)
    except Exception:  # noqa: BLE001
        pass

    # v0.5.1: states list format doesn't include system metrics.
    # Fall back to extracting them from /v1/metrics if available.
    if system_metrics is None:
        try:
            resp = http_client.get(f"{api_url}/v1/metrics", timeout=timeout)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list):
                    system_metrics = _extract_system_metrics_from_v051(data)
        except Exception:  # noqa: BLE001
            pass

    return system_metrics, health_states, network_health


def _parse_event_level(event: dict[str, Any]) -> str:
    """Normalize event severity from either legacy or component-grouped formats."""
    level = str(event.get("level", "") or "").lower()
    if level:
        return level

    event_type = str(event.get("type", "") or "")
    if event_type in ("Critical", "Fatal"):
        return "error"
    if event_type == "Warning":
        return "warning"
    return "info"


def _parse_events_response(events_data: dict | list) -> list[SystemEvent]:
    """Parse /v1/events response, handling both flat and component-grouped formats."""
    if isinstance(events_data, list) and all(
        isinstance(item, dict) and "events" in item for item in events_data
    ):
        return build_events(events_data)

    if isinstance(events_data, dict):
        items = events_data.get("events", [])
    elif isinstance(events_data, list):
        items = events_data
    else:
        items = []

    events: list[SystemEvent] = []
    for ev in items:
        try:
            ts_raw = ev.get("timestamp") or ev.get("time") or ""
            ts = datetime.fromisoformat(str(ts_raw).replace("Z", "+00:00"))
        except Exception:  # noqa: BLE001
            ts = datetime.now(timezone.utc)

        details = dict(ev.get("details", {}))
        if "name" in ev and "name" not in details:
            details["name"] = ev.get("name", "")

        events.append(
            SystemEvent(
                timestamp=ts,
                component=str(ev.get("component", "unknown")),
                level=_parse_event_level(ev),
                message=str(ev.get("message", "")),
                details=details,
            )
        )
    return events


def _fetch_events(http_client: httpx.Client, api_url: str, timeout: int) -> list[SystemEvent]:
    """Fetch recent events from GPUd API."""
    try:
        resp = http_client.get(f"{api_url}/v1/events", timeout=timeout)
        if resp.status_code == 200:
            return _parse_events_response(resp.json() or {})
    except Exception:  # noqa: BLE001
        pass
    return []


def _enrich_machine_info(machine_info: dict, task: Any, gpu_metrics: list[GPUMetric]) -> None:
    """Enrich machine_info dict with cluster topology data in-place."""
    try:
        nodes = int(getattr(task, "num_instances", 1) or 1)
    except Exception:  # noqa: BLE001
        nodes = 1
    try:
        machine_info_mut = (
            dict(machine_info) if not isinstance(machine_info, dict) else machine_info
        )
        machine_info_mut.setdefault("nodes", nodes)
        gpn = (
            len(gpu_metrics) if gpu_metrics else int(machine_info_mut.get("gpus_per_node", 0) or 0)
        )
        machine_info_mut.setdefault("gpus_per_node", gpn)
        if gpn and nodes:
            machine_info_mut["total_gpus"] = gpn * nodes
    except Exception:  # noqa: BLE001
        pass
