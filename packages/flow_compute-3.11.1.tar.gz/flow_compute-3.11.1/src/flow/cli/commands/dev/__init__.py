"""Dev command package.

This package modularizes the legacy monolithic `dev.py` implementation into
separate components for improved maintainability and testability.

Exports:
- `command`: Click command instance for CLI registration
- `DevVMManager`: VM lifecycle manager
- `DevContainerExecutor`: Command execution on the dev VM
"""

from flow.application.dev.executor import DevContainerExecutor
from flow.application.dev.vm_manager import DevVMManager
from flow.cli.commands.dev.command import command

__all__ = ["DevContainerExecutor", "DevVMManager", "command"]
