"""Setup components for configuration UI.

Provides UI components for interactive configuration including intelligent
option selection for projects, SSH keys, and other configuration items.
"""

from typing import Any

from rich.console import Console
from rich.prompt import Prompt

from flow.cli.ui.components import InteractiveSelector, SelectionItem


def _build_selection_item(
    option: dict[str, Any],
    name_key: str,
    id_key: str,
    is_ssh: bool,
) -> SelectionItem[dict[str, Any]]:
    """Build a SelectionItem from an option dict."""
    name = option.get(name_key, option.get("display_name", "Unknown"))
    option_id = option.get(id_key, "")

    if option_id.startswith("GENERATE_"):
        return SelectionItem(value=option, id="", title=name, subtitle="", status="")

    subtitle_parts = []
    if is_ssh:
        if option.get("created_at"):
            subtitle_parts.append(f"Created: {option['created_at']}")
        display_name = option.get("display_name") or option.get("name") or ""
        if "(local)" in str(display_name):
            subtitle_parts.append("local private key")
        fingerprint = option.get("fingerprint", "")
        if fingerprint and fingerprint not in ("", "unknown"):
            subtitle_parts.append(fingerprint)
        return SelectionItem(
            value=option,
            id="",
            title=name,
            subtitle=" · ".join(subtitle_parts),
            status="",
        )

    return SelectionItem(value=option, id=option_id, title=name, subtitle="", status="Available")


def select_from_options(
    console: Console,
    options: list[dict[str, Any]],
    name_key: str = "name",
    id_key: str = "id",
    title: str = "Select an option",
    show_ssh_table: bool = False,
    default_id: str | None = None,
    extra_header_html: str | None = None,
    breadcrumbs: list[str] | None = None,
    preferred_viewport_size: int | None = None,
) -> dict[str, Any] | None:
    """Select from options using interactive UI with numbered fallback.

    Args:
        console: Console for output
        options: List of option dictionaries
        name_key: Key for display name in option dict
        id_key: Key for ID in option dict
        title: Title for selection interface
        show_ssh_table: Use SSH-specific formatting
        default_id: Option ID to preselect when present
        extra_header_html: Optional header content
        breadcrumbs: Navigation breadcrumbs
        preferred_viewport_size: Preferred number of visible items

    Returns:
        Selected option dict or None if cancelled
    """
    if not options:
        return None

    is_ssh = show_ssh_table and any("created_at" in opt for opt in options)

    # For SSH display, separate generation options from existing keys
    if is_ssh:
        gen_options = [opt for opt in options if opt.get(id_key, "").startswith("GENERATE_")]
        ssh_keys = [opt for opt in options if not opt.get(id_key, "").startswith("GENERATE_")]

        # Sort existing keys: newest first by created_at date
        ssh_keys.sort(key=lambda k: k.get("created_at", ""), reverse=True)

        display_options = []
        for opt in gen_options:
            display_options.append({**opt, "display_name": opt.get(name_key, "Unknown")})
        for key in ssh_keys:
            display_options.append({**key, "display_name": key.get("name", "Unknown")})
    else:
        display_options = options

    default_index = 0
    if default_id is not None:
        for idx, option in enumerate(display_options):
            if str(option.get(id_key, "")) == str(default_id):
                default_index = idx
                break

    try:
        selector = InteractiveSelector(
            items=display_options,
            item_to_selection=lambda opt: _build_selection_item(opt, name_key, id_key, is_ssh),
            title=title,
            allow_multiple=False,
            allow_back=True,
            show_preview=False,
            breadcrumbs=breadcrumbs,
            extra_header_html=extra_header_html,
            preferred_viewport_size=preferred_viewport_size,
        )
        if 0 <= default_index < len(display_options):
            selector.selected_index = default_index

        result = selector.select()
        if result is InteractiveSelector.BACK_SENTINEL:
            return None
        if result is not None:
            return result
    except Exception:  # noqa: BLE001
        pass

    # Fallback: numbered prompt
    console.print(f"\n[bold]{title}:[/bold]")
    for i, option in enumerate(display_options, 1):
        name = option.get(name_key, option.get("display_name", "Unknown"))
        console.print(f"  {i}. {name}")

    while True:
        choice = Prompt.ask("\nSelect number", default=str(default_index + 1))
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(display_options):
                return display_options[idx]
            else:
                console.print("[error]Invalid selection[/error]")
        except ValueError:
            console.print("[error]Please enter a number[/error]")
