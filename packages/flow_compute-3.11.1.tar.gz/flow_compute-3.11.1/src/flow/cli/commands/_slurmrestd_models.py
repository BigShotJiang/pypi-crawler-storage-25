"""Pydantic models for the slurmrestd v0.0.41 HTTP boundary.

These models describe the request and response shapes used by ``flow slurm``
subcommands. They normalize several quirks of the slurmrestd JSON surface so
CLI consumers see clean, predictable types:

* ``job_state`` can be a list (newer slurmrestd) or a bare string.
* ``submit_time`` / other timestamps can be an int, float, ISO string,
  or a ``{"set": bool, "number": int, "infinite": bool}`` wrapper struct.
* ``node_count`` can be a bare integer or the same wrapper struct.
* Error payloads can appear at the top level as ``errors``, or nested under
  a ``result`` envelope depending on the endpoint.

Downstream code should accept the normalized types exposed here rather than
reaching into the raw response dictionary.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from flow.cli.utils.json_output import iso_z


def _coerce_scalar_number(value: Any) -> int | float | None:
    """Reduce a slurmrestd numeric field to an int/float or ``None``.

    slurmrestd v0.0.41 commonly wraps numeric values as
    ``{"set": bool, "number": <int>, "infinite": bool}``. This helper peels
    that wrapper off and returns the raw scalar while preserving any plain
    numeric inputs.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        # bool is a subclass of int; treat it as "no value"
        return None
    if isinstance(value, int | float):
        return value
    if isinstance(value, dict):
        if value.get("infinite") is True:
            return None
        if value.get("set") is False:
            return None
        number = value.get("number")
        if isinstance(number, bool):
            return None
        if isinstance(number, int | float):
            return number
        return None
    return None


def _coerce_timestamp(value: Any) -> str | None:
    """Coerce a slurmrestd timestamp field to an ISO-8601 ``Z``-suffixed string."""
    if value is None or value == "":
        return None
    if isinstance(value, str):
        return value
    numeric = _coerce_scalar_number(value)
    if numeric is None or numeric == 0:
        return None
    try:
        dt = datetime.fromtimestamp(float(numeric), tz=UTC)
    except (OSError, OverflowError, ValueError):
        return None
    return iso_z(dt)


class SlurmrestdError(BaseModel):
    """A single error entry returned by slurmrestd."""

    model_config = ConfigDict(extra="allow")

    description: str | None = None
    error: str | None = None
    error_number: int | None = None
    source: str | None = None


class SlurmrestdEnvelope(BaseModel):
    """Common envelope fields present in every slurmrestd response."""

    model_config = ConfigDict(extra="allow")

    errors: list[SlurmrestdError] = Field(default_factory=list)
    warnings: list[dict[str, Any]] = Field(default_factory=list)
    meta: dict[str, Any] | None = None

    def has_errors(self) -> bool:
        """Return True if the response contains any error entries."""
        return bool(self.errors)

    def error_summary(self) -> str:
        """Produce a user-readable summary of the error list.

        Returns an empty string when ``errors`` is empty. Callers should guard
        with :meth:`has_errors` first.
        """
        parts: list[str] = []
        for err in self.errors:
            descr = err.description or err.error or "unknown slurmrestd error"
            if err.error_number is not None:
                parts.append(f"{descr} (err={err.error_number})")
            else:
                parts.append(descr)
        return "; ".join(parts)


class JobSubmitRequest(BaseModel):
    """Payload for ``POST /slurm/{version}/job/submit``.

    This is what Flow sends to slurmrestd. Kept explicit so the wire shape
    is documented rather than a free-form dict.
    """

    model_config = ConfigDict(extra="allow")

    script: str = Field(..., min_length=1, description="Slurm batch script contents.")
    environment: dict[str, str] = Field(default_factory=dict)
    account: str | None = None
    partition: str | None = None
    array: str | None = None
    name: str | None = None

    def to_wire(self) -> dict[str, Any]:
        """Serialize to the dict shape slurmrestd expects.

        Omits fields whose value is ``None`` so optional parameters are not
        sent as explicit nulls.
        """
        payload = self.model_dump(exclude_none=True)
        payload.setdefault("environment", {})
        return payload


class JobSubmitResponse(SlurmrestdEnvelope):
    """Response from ``POST /slurm/{version}/job/submit``.

    slurmrestd sometimes returns ``job_id`` at the top level, and sometimes
    nests it under a ``result`` object. We normalize that at the boundary so
    callers always read :attr:`job_id`.
    """

    job_id: int | None = None
    step_id: str | None = None
    job_submit_user_msg: str | None = None

    @model_validator(mode="before")
    @classmethod
    def _hoist_result(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        if data.get("job_id") is None:
            nested = data.get("result")
            if isinstance(nested, dict):
                candidate = nested.get("job_id")
                if candidate:
                    data = {**data, "job_id": candidate}
        return data


class SlurmJob(BaseModel):
    """A single job entry as returned by slurmrestd's ``/jobs`` endpoints.

    Quirks normalized:
    * ``job_state`` is coerced to an uppercase string (slurmrestd v0.0.41+
      returns a single-element list; older versions return a bare string).
    * ``submit_time`` is coerced to an ISO-8601 UTC string.
    * ``node_count`` is coerced to an ``int | None`` regardless of whether
      slurmrestd returned the integer directly or wrapped it.

    ``job_state_raw`` preserves the original value for callers that need to
    disambiguate list vs. scalar representations for display.
    """

    model_config = ConfigDict(extra="allow")

    job_id: int | None = None
    name: str | None = None
    user_name: str | None = None
    job_state: str | None = None
    job_state_raw: list[str] | str | None = None
    node_count: int | None = None
    partition: str | None = None
    submit_time: str | None = None
    account: str | None = None

    @model_validator(mode="before")
    @classmethod
    def _normalize(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data

        normalized = dict(data)

        raw_state = normalized.get("job_state")
        normalized["job_state_raw"] = raw_state
        if isinstance(raw_state, list):
            if raw_state:
                normalized["job_state"] = str(raw_state[0]).upper()
            else:
                normalized["job_state"] = None
        elif isinstance(raw_state, str) and raw_state:
            normalized["job_state"] = raw_state.upper()
        else:
            normalized["job_state"] = None

        node_count = _coerce_scalar_number(normalized.get("node_count"))
        normalized["node_count"] = int(node_count) if node_count is not None else None

        normalized["submit_time"] = _coerce_timestamp(normalized.get("submit_time"))

        job_id = _coerce_scalar_number(normalized.get("job_id"))
        normalized["job_id"] = int(job_id) if job_id is not None else None

        return normalized

    def to_display_dict(self) -> dict[str, Any]:
        """Project to the dict shape used by ``flow slurm status --json``."""
        return {
            "job_id": self.job_id,
            "name": self.name,
            "user_name": self.user_name,
            "job_state": self.job_state.lower() if self.job_state else None,
            "job_state_raw": self.job_state_raw,
            "node_count": self.node_count,
            "partition": self.partition,
            "submit_time": self.submit_time,
            "account": self.account,
        }


class JobStatusResponse(SlurmrestdEnvelope):
    """Response from ``GET /slurm/{version}/jobs`` or ``/job/{id}``.

    slurmrestd always wraps results in a ``jobs`` list even when querying by
    id, so we mirror that here. Errors (e.g., "job not found") arrive via the
    inherited :attr:`errors` field.
    """

    jobs: list[SlurmJob] = Field(default_factory=list)

    @field_validator("jobs", mode="before")
    @classmethod
    def _coerce_jobs_list(cls, value: Any) -> Any:
        if value is None:
            return []
        if isinstance(value, list):
            return value
        if isinstance(value, dict):
            return [value]
        return value


class JobCancelResponse(SlurmrestdEnvelope):
    """Response from ``DELETE /slurm/{version}/job/{id}``.

    slurmrestd usually returns an empty body with just the envelope. Treat
    non-empty errors as failure and an empty error list as success.
    """

    pass


class SlurmrestdErrorResponse(SlurmrestdEnvelope):
    """A slurmrestd response that we are handling purely for its error list.

    Used when we know a call failed and we just want to format the cause
    for a user-facing error message.
    """

    pass
