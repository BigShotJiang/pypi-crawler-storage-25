"""Install Claude Code skills for flow-compute globally.

Copies bundled skill definitions into ~/.claude/skills/ so that Claude Code
can use them across all projects.

Usage:
    flow claude          # Install skills globally
    flow claude --list   # Show bundled skills without installing
"""

from __future__ import annotations

import shutil
from pathlib import Path

import click
from rich.console import Console

from flow.cli.commands.base import BaseCommand, console
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.theme_manager import theme_manager


def get_bundled_dir() -> Path:
    """Return the path to bundled Claude data shipped with the package."""
    from flow.data.claude import get_data_dir

    return get_data_dir()


# Skills from previous versions that have been consolidated into "flow".
_DEPRECATED_SKILLS = ["flow-api", "flow-dashboard", "flow-debug", "flow-run", "flow-setup"]


def install_skills(target_dir: Path, bundled_dir: Path) -> list[str]:
    """Copy bundled skills into the target .claude/skills/ directory.

    Removes deprecated skills from previous versions and installs current ones.
    Returns list of installed skill names.
    """
    skills_src = bundled_dir / "skills"
    skills_dst = target_dir / ".claude" / "skills"
    installed = []

    if not skills_src.exists():
        return installed

    for old_name in _DEPRECATED_SKILLS:
        old_dir = skills_dst / old_name
        if old_dir.exists():
            shutil.rmtree(old_dir)

    for skill_dir in sorted(skills_src.iterdir()):
        if not skill_dir.is_dir():
            continue
        skill_file = skill_dir / "SKILL.md"
        if not skill_file.exists():
            continue

        dst_dir = skills_dst / skill_dir.name
        dst_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(skill_file, dst_dir / "SKILL.md")
        installed.append(skill_dir.name)

    return installed


def install_claude_assets(target_dir: Path, out: Console | None = None) -> None:
    """Install skills globally, printing results to console.

    Shared entry point used by both `flow claude` and `flow setup --claude-code`.
    """
    out = out or console
    bundled_dir = get_bundled_dir()
    success_color = theme_manager.get_color("success")
    muted = theme_manager.get_color("muted")

    installed = install_skills(target_dir, bundled_dir)

    if installed:
        out.print(
            f"\n[{success_color}]✓[/{success_color}] Installed {len(installed)} skills "
            f"into {target_dir / '.claude' / 'skills'}"
        )
        for name in installed:
            out.print(f"  [{muted}]{name}[/{muted}]")
        out.print(
            f"\n[{muted}]Flow skills are now available in Claude Code[/{muted}]"
        )
    else:
        out.print("[warning]No skills found to install[/warning]")


class ClaudeCommand(BaseCommand):
    """Install Claude Code skills for flow-compute."""

    @property
    def name(self) -> str:
        return "claude"

    @property
    def help(self) -> str:
        return "Install Claude Code skills globally"

    def get_command(self) -> click.Command:
        @click.command(name=self.name, help=self.help)
        @click.option(
            "--list", "list_only", is_flag=True, help="List bundled skills without installing"
        )
        @cli_error_guard(self)
        def claude(list_only: bool):
            """Install Claude Code skills globally (~/.claude/skills/).

            \b
            Examples:
                flow claude              # Install skills globally
                flow claude --list       # Show available skills
            """
            if list_only:
                bundled_dir = get_bundled_dir()
                muted = theme_manager.get_color("muted")
                skills_dir = bundled_dir / "skills"
                if not skills_dir.exists():
                    console.print("[warning]No bundled skills found[/warning]")
                    return

                console.print("\n[bold]Bundled Claude Code skills[/bold]\n")
                for skill_dir in sorted(skills_dir.iterdir()):
                    if not skill_dir.is_dir():
                        continue
                    skill_file = skill_dir / "SKILL.md"
                    if not skill_file.exists():
                        continue

                    # Parse description from YAML front matter
                    content = skill_file.read_text()
                    name = skill_dir.name
                    desc = ""
                    if content.startswith("---"):
                        end = content.find("---", 3)
                        front_matter = content[3:end] if end > 3 else content[3:]
                        for line in front_matter.split("\n"):
                            if line.startswith("description:"):
                                desc = line.split(":", 1)[1].strip()
                                break

                    console.print(f"  [accent]{name:<16}[/accent] [{muted}]{desc}[/{muted}]")

                console.print(f"\n[{muted}]Install with: flow claude[/{muted}]")
                return

            install_claude_assets(Path.home(), console)

        return claude


command = ClaudeCommand()
