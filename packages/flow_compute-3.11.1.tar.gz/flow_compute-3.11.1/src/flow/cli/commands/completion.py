"""Completion command for Flow CLI.

``flow completion`` installs shell tab-completion. ``flow completion uninstall``
removes it. A hidden ``generate`` subcommand prints the raw script for manual
sourcing.
"""

import click

from flow.cli.commands.base import BaseCommand, console


class CompletionCLICommand(BaseCommand):
    """Manage shell completion for the Flow CLI."""

    @property
    def name(self) -> str:
        return "completion"

    @property
    def help(self) -> str:
        return "Set up shell tab-completion"

    def get_command(self) -> click.Command:
        @click.group(name=self.name, help=self.help, invoke_without_command=True)
        @click.option(
            "--shell",
            "shell",
            type=click.Choice(["bash", "zsh", "fish"]),
            help="Shell to install for (auto-detect if omitted)",
        )
        @click.option(
            "--path",
            "path",
            type=click.Path(dir_okay=False, path_type=str),
            help="Path to rc file to modify (defaults per shell)",
        )
        @click.pass_context
        def completion(ctx: click.Context, shell: str | None, path: str | None):
            if ctx.invoked_subcommand is None:
                from flow.cli.completion.shell_manager import ShellCompletionManager

                ShellCompletionManager().install(shell, path)

        @completion.command(name="uninstall", help="Remove installed shell completion")
        @click.option(
            "--shell",
            "shell",
            type=click.Choice(["bash", "zsh", "fish"]),
            help="Shell to uninstall for (auto-detect if omitted)",
        )
        @click.option(
            "--path",
            "path",
            type=click.Path(dir_okay=False, path_type=str),
            help="Path to rc file to clean (defaults per shell)",
        )
        def uninstall(shell: str | None, path: str | None):
            from flow.cli.completion.shell_manager import ShellCompletionManager

            ShellCompletionManager().uninstall(shell, path)

        @completion.command(name="generate", hidden=True, help="Print raw completion script")
        @click.argument("shell", required=False, type=click.Choice(["bash", "zsh", "fish"]))
        def generate(shell: str | None = None):
            """Print raw completion script to stdout for manual sourcing."""
            from flow.cli.completion.shell_manager import ShellCompletionManager

            manager = ShellCompletionManager()
            if not shell:
                shell = manager.detect_shell()
                if not shell:
                    console.print(
                        "[error]Could not auto-detect shell. Specify one of: bash, zsh, fish[/error]"
                    )
                    raise click.exceptions.Exit(1)
            click.echo(manager.render_script(shell))

        @completion.command(name="doctor", help="Diagnose (and optionally repair) shell completion")
        @click.option(
            "--shell",
            "shell",
            type=click.Choice(["bash", "zsh", "fish"]),
            help="Shell to inspect (auto-detect if omitted)",
        )
        @click.option(
            "--path",
            "path",
            type=click.Path(dir_okay=False, path_type=str),
            help="Path to rc file to inspect (defaults per shell)",
        )
        @click.option(
            "--fix",
            is_flag=True,
            help="Apply repairs in place after reporting issues",
        )
        def doctor(shell: str | None, path: str | None, fix: bool):
            """Report (and optionally repair) shell completion problems."""
            from flow.cli.completion.shell_manager import ShellCompletionManager

            issues = ShellCompletionManager().doctor(shell, path, fix=fix)
            # Non-zero exit when issues remain so CI/scripts can react.
            if issues > 0 and not fix:
                raise click.exceptions.Exit(1)

        return completion


# Export command instance
command = CompletionCLICommand()
