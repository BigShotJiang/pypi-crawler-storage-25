"""CLI package for the ``flow`` command.

Provides the interactive and non-interactive command-line interface over the
Application layer. The CLI should be a thin wrapper: parse inputs, call
use-cases, print results. Keep business logic in ``flow.application``.

Structure:
  - ``commands``: user-facing commands and options
  - ``services``: non-UI helpers used by commands
  - ``utils``/``ui``: presentation helpers and TUI bits
"""
