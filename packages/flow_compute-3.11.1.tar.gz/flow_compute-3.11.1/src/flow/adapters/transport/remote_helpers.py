"""Remote SSH helpers for safe path handling and directory preparation.

This module centralizes small, opinionated operations used by code transfer
to avoid brittle shell quoting and duplication across call sites.
"""

from __future__ import annotations

import shlex
import subprocess

from flow.core.ssh import SSHConnectionInfo, build_ssh_command


def _to_remote_expr(path: str) -> str:
    """Return a path expression suitable for bash -lc with $HOME expansion.

    - "~"      -> "$HOME"
    - "~/foo"  -> "$HOME/foo"
    - other     -> unchanged
    """
    p = (path or "").strip()
    if p == "~":
        return "$HOME"
    if p.startswith("~/"):
        return "$HOME/" + p[2:]
    return p


def _ssh_bash(
    connection: SSHConnectionInfo, script: str, timeout: int = 30
) -> subprocess.CompletedProcess:
    """Execute a bash -lc script via SSH with hardened options.

    Uses build_ssh_command from flow.core.ssh for consistent SSH options.
    Returns the CompletedProcess for callers that need stdout/rc.
    """
    prefix_args = None
    if connection.proxyjump:
        prefix_args = ["-J", connection.proxyjump]
    cmd = build_ssh_command(
        user=connection.user,
        host=connection.host,
        port=connection.port,
        key_path=connection.key_path,
        prefix_args=prefix_args,
        remote_command=["bash", "-lc", script],
        use_mux=False,
    )
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def ensure_dir(connection: SSHConnectionInfo, path: str, *, sudo: bool = False) -> None:
    """Create the directory if missing. Uses sudo -n when requested.

    Best-effort: errors are swallowed.
    """
    expr = _to_remote_expr(path)
    if not expr:
        return
    mkdir = f"mkdir -p {shlex.quote(expr)}"
    if sudo and expr.startswith("/"):
        mkdir = f"sudo -n {mkdir}"
    try:
        _ssh_bash(connection, mkdir)
    except Exception:  # noqa: BLE001 - subprocess can fail many ways
        pass


def ensure_writable(
    connection: SSHConnectionInfo, path: str, *, user: str | None = None, sudo: bool = False
) -> None:
    """Ensure path is writable by user: chown/chmod when allowed.

    Only runs chown/chmod when sudo=True and path is absolute.
    """
    expr = _to_remote_expr(path)
    if not expr:
        return
    cmds = []
    if sudo and expr.startswith("/"):
        quoted = shlex.quote(expr)
        if user:
            safe_user = shlex.quote(f"{user}:{user}")
            cmds.append(f"sudo -n chown -R {safe_user} {quoted} || true")
        cmds.append(f"sudo -n chmod 777 {quoted} || true")
    if not cmds:
        return
    script = " ; ".join(cmds)
    try:
        _ssh_bash(connection, script)
    except Exception:  # noqa: BLE001 - subprocess can fail many ways
        pass


def is_writable(connection: SSHConnectionInfo, path: str) -> bool:
    """Return True if path is writable by the SSH user.

    Creates the directory first (without sudo) to avoid false negatives.
    """
    expr = _to_remote_expr(path)
    if not expr:
        return False
    quoted = shlex.quote(expr)
    script = f"mkdir -p {quoted} >/dev/null 2>&1 || true; test -w {quoted} && echo OK || echo DENY"
    try:
        res = _ssh_bash(connection, script)
        return res.returncode == 0 and isinstance(res.stdout, str) and "OK" in res.stdout
    except Exception:  # noqa: BLE001 - subprocess can fail many ways
        return False
