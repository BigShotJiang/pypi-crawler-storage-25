"""SSH client-side wait utilities.

Provides ``ISSHWaiter`` protocol and ``ExponentialBackoffSSHWaiter``
implementation that delegates to ``flow.core.ssh`` primitives.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from pathlib import Path
from typing import Protocol

from flow.core.ssh import SSHConnectionInfo
from flow.core.ssh.probe import (
    find_fallback_private_key,
    resolve_proxyjump,
    wait_for_ssh_ready,
)
from flow.errors.ssh import SSHNotReadyError

logger = logging.getLogger(__name__)

# Re-export for backward compatibility
__all__ = [
    "ExponentialBackoffSSHWaiter",
    "ISSHWaiter",
    "SSHConnectionInfo",
]


class ISSHWaiter(Protocol):
    def wait_for_ssh(
        self,
        task: object,
        timeout: int | None = None,
        probe_interval: float = 10.0,
        progress_callback: Callable[[str], None] | None = None,
        node: int | None = None,
    ) -> SSHConnectionInfo: ...


class ExponentialBackoffSSHWaiter:
    """Waits for SSH reachability using fast, adaptive probes.

    Delegates core probing to ``flow.core.ssh.wait_for_ssh_ready()``.
    """

    def __init__(self, provider: object | None = None) -> None:
        self.provider = provider
        try:
            self.max_backoff = int(os.getenv("FLOW_SSH_MAX_BACKOFF", "8"))
        except (ValueError, TypeError):
            self.max_backoff = 8

    def wait_for_ssh(
        self,
        task: object,
        timeout: int | None = None,
        probe_interval: float = 1.0,
        progress_callback: Callable[[str], None] | None = None,
        node: int | None = None,
    ) -> SSHConnectionInfo:
        # Lazy import to avoid adapter -> sdk import at module level
        from flow.sdk.ssh_utils import wait_for_task_ssh_info

        # Wait for SSH info (host/port) to appear on the task
        try:
            task = wait_for_task_ssh_info(
                task=task,
                provider=self.provider,
                timeout=timeout or 1200,
                show_progress=False,
            )
        except SSHNotReadyError as e:
            raise TimeoutError(str(e)) from e

        host = (
            task.host(node)
            if node is not None
            else getattr(task, "ssh_host", None) or task.host(node)
        )
        port = int(getattr(task, "ssh_port", 22) or 22)
        user = getattr(task, "ssh_user", "ubuntu")
        key_path = self._get_ssh_key_path(task)

        # Compute ProxyJump if needed
        private_ip = self._get_private_ip(task)
        effective_host, effective_port, proxyjump = resolve_proxyjump(
            host,
            port,
            user,
            private_ip=private_ip,
        )

        # Also check provider metadata for explicit proxyjump hint
        task_meta = getattr(task, "provider_metadata", {}) or {}
        pj_hint = task_meta.get("ssh_proxyjump")
        if pj_hint:
            proxyjump = str(pj_hint)

        connection = SSHConnectionInfo(
            host=effective_host,
            port=effective_port,
            user=user,
            key_path=key_path,
            proxyjump=proxyjump,
            task_id=getattr(task, "task_id", None),
        )

        # Delegate readiness wait to core
        wait_for_ssh_ready(
            user=connection.user,
            host=connection.host,
            port=connection.port,
            key_path=connection.key_path,
            proxyjump=connection.proxyjump,
            timeout=float(timeout or 1200),
            initial_interval=probe_interval,
            max_backoff=float(self.max_backoff),
            progress_callback=progress_callback,
        )

        return connection

    def _get_ssh_key_path(self, task: object) -> Path:
        """Resolve SSH key for the task via provider or fallback."""
        if getattr(self.provider, "get_task_ssh_connection_info", None):
            result = self.provider.get_task_ssh_connection_info(getattr(task, "task_id", ""))
            if result is None:
                raise RuntimeError("Failed to resolve SSH key: no matching local key found")
            return result

        fallback = find_fallback_private_key()
        if fallback:
            return fallback
        raise RuntimeError("No SSH key available; set provider or ensure default key exists")

    def _get_private_ip(self, task: object) -> str | None:
        """Best-effort: get private IP from provider instances."""
        if not getattr(self.provider, "get_task_instances", None):
            return None
        try:
            instances = self.provider.get_task_instances(getattr(task, "task_id", ""))
            if instances:
                return getattr(instances[0], "private_ip", None)
        except (RuntimeError, OSError, KeyError, AttributeError, IndexError):
            return None
        return None
