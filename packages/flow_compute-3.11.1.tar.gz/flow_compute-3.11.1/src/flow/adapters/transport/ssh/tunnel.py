"""SSH tunneling utilities (port-forwarding lifecycle)."""

from __future__ import annotations

import atexit
import os
import signal
import socket
import subprocess
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from flow.core.ssh import build_ssh_command, find_fallback_private_key


@dataclass
class SSHTunnel:
    """Represents an active SSH tunnel process."""

    process: subprocess.Popen
    local_port: int
    remote_port: int
    remote_host: str = "localhost"
    task_id: str = ""

    def is_alive(self) -> bool:
        return self.process.poll() is None

    def terminate(self) -> None:
        if self.is_alive():
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()


class SSHTunnelManager:
    """Provider-agnostic SSH tunnel manager.

    All SSH primitives are delegated to ``flow.core.ssh``.
    """

    _lock: threading.Lock = threading.Lock()
    _active: dict[str, SSHTunnel] = {}
    _signal_handlers_installed: bool = False

    @classmethod
    def create_tunnel(
        cls,
        task: object,
        local_port: int = 0,
        remote_port: int = 22,
        remote_host: str = "localhost",
        ssh_options: list[str] | None = None,
        *,
        host: str | None = None,
        port: int = 22,
        user: str = "ubuntu",
        key_path: Path | str | None = None,
    ) -> SSHTunnel:
        """Create an SSH tunnel.

        Args:
            task: Task-like object (reads ssh_host/ssh_port/ssh_user/task_id via getattr).
                  Pass None and use keyword args instead for decoupled usage.
            local_port: Local port to bind (0 = auto-select).
            remote_port: Remote port to forward to.
            remote_host: Remote host for the forwarding destination.
            ssh_options: Additional SSH options.
            host: Explicit SSH host (overrides task.ssh_host).
            port: Explicit SSH port (overrides task.ssh_port).
            user: Explicit SSH user (overrides task.ssh_user).
            key_path: Explicit SSH key path.
        """
        # Resolve connection params: explicit kwargs take precedence over task attrs
        effective_host = host or getattr(task, "ssh_host", None)
        if not effective_host:
            task_id = getattr(task, "task_id", "?")
            raise RuntimeError(f"Task {task_id} has no SSH host information")
        effective_port = port if host else int(getattr(task, "ssh_port", 22) or 22)
        effective_user = user if host else getattr(task, "ssh_user", "ubuntu")
        effective_key = Path(key_path) if key_path else find_fallback_private_key()
        task_id = getattr(task, "task_id", "") if task else ""

        if local_port == 0:
            local_port = cls._find_free_port()

        # Ensure signal handlers are registered on first tunnel creation
        cls._ensure_signal_handlers()

        cmd = cls._build_tunnel_cmd(
            effective_host,
            effective_port,
            effective_user,
            effective_key,
            local_port,
            remote_port,
            remote_host,
            ssh_options,
        )
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid if os.name != "nt" else None,
        )

        try:
            import time as _t

            # Give SSH a moment to fail fast (wrong key, bad host).
            _t.sleep(0.5)
            if proc.poll() is not None:
                err = proc.stderr.read().decode() if proc.stderr else ""
                raise RuntimeError(f"SSH tunnel failed to start: {err}")

            # Verify the tunnel is forwarding traffic. Default 30s is
            # well above SSH's ConnectTimeout=10 to avoid false negatives.
            verify_timeout = float(os.environ.get("FLOW_TUNNEL_TIMEOUT", "30"))
            if not cls._verify(local_port, timeout=verify_timeout):
                raise RuntimeError(f"SSH tunnel on port {local_port} is not responding")
        except Exception:
            if proc.stderr:
                proc.stderr.close()
            if proc.poll() is None:
                proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            raise

        tunnel = SSHTunnel(
            process=proc,
            local_port=local_port,
            remote_port=remote_port,
            remote_host=remote_host,
            task_id=task_id,
        )
        with cls._lock:
            cls._active[f"{tunnel.task_id}:{tunnel.local_port}"] = tunnel
        return tunnel

    @classmethod
    @contextmanager
    def tunnel_context(
        cls,
        task: object,
        local_port: int = 0,
        remote_port: int = 22,
        remote_host: str = "localhost",
        ssh_options: list[str] | None = None,
        *,
        key_path: Path | str | None = None,
    ):
        tunnel = None
        try:
            tunnel = cls.create_tunnel(
                task,
                local_port,
                remote_port,
                remote_host,
                ssh_options,
                key_path=key_path,
            )
            yield tunnel
        finally:
            if tunnel:
                try:
                    tunnel.terminate()
                finally:
                    with cls._lock:
                        cls._active.pop(f"{tunnel.task_id}:{tunnel.local_port}", None)

    @staticmethod
    def _find_free_port() -> int:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            s.listen(1)
            return s.getsockname()[1]

    @staticmethod
    def _build_tunnel_cmd(
        host: str,
        port: int,
        user: str,
        key_path: Path | None,
        local_port: int,
        remote_port: int,
        remote_host: str,
        ssh_options: list[str] | None,
    ) -> list[str]:
        forward = ["-N", "-L", f"{local_port}:{remote_host}:{remote_port}"]
        # Disable mux so the tunnel process stays alive for lifecycle
        # management. With ControlMaster=auto, the SSH process hands off
        # forwarding to an existing master and exits immediately, which
        # breaks the process-based health/liveness checks.
        cmd = build_ssh_command(
            user=user,
            host=host,
            port=port,
            key_path=key_path,
            prefix_args=forward,
            use_mux=False,
        )
        if ssh_options:
            cmd.extend(ssh_options)
        cmd.extend(["-o", "ExitOnForwardFailure=yes"])
        return cmd

    @staticmethod
    def _verify(port: int, timeout: float = 5.0) -> bool:
        """Verify the SSH tunnel has bound the local port.

        Checks that SSH has actually bound ``localhost:port`` (i.e. the
        tunnel is active).  A bare ``ConnectionRefusedError`` is ambiguous:
        it fires both when the port is unbound (no tunnel) and when SSH
        forwarded the connection but the remote refused.  We disambiguate
        by trying to bind the port ourselves — ``OSError`` (address in use)
        means SSH owns it.
        """
        import time as _t

        start = _t.time()
        while _t.time() - start < timeout:
            try:
                with socket.create_connection(("localhost", port), timeout=1):
                    return True
            except ConnectionRefusedError:
                # Check whether SSH has actually bound the port.
                try:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.bind(("localhost", port))
                    # Bind succeeded → port is FREE → SSH hasn't started yet.
                    _t.sleep(0.3)
                except OSError:
                    # Bind failed → port is in use by SSH → tunnel is up.
                    return True
            except OSError:
                _t.sleep(0.1)
        return False

    @classmethod
    def _ensure_signal_handlers(cls) -> None:
        """Install signal handlers on first use (not at import time)."""
        if cls._signal_handlers_installed:
            return
        cls._signal_handlers_installed = True
        _install_signal_handlers()


def _cleanup_all():
    try:
        with SSHTunnelManager._lock:
            tunnels = list(SSHTunnelManager._active.values())
            SSHTunnelManager._active.clear()
        for t in tunnels:
            try:
                t.terminate()
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001
        pass


atexit.register(_cleanup_all)


def _install_signal_handlers() -> None:
    """Install SIGTERM/SIGINT handlers that clean up tunnels."""
    # SIGTERM
    try:
        prev_sigterm = signal.getsignal(signal.SIGTERM) if hasattr(signal, "SIGTERM") else None
    except (OSError, ValueError):
        prev_sigterm = None

    def _handle_sigterm(signum, frame):  # pragma: no cover
        try:
            _cleanup_all()
        finally:
            if callable(prev_sigterm):
                prev_sigterm(signum, frame)
            elif prev_sigterm in (None, signal.SIG_DFL):
                raise SystemExit(0)

    try:
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, _handle_sigterm)
    except (OSError, ValueError):
        pass

    # SIGINT
    try:
        prev_sigint = signal.getsignal(signal.SIGINT) if hasattr(signal, "SIGINT") else None
    except (OSError, ValueError):
        prev_sigint = None

    def _handle_sigint(signum, frame):  # pragma: no cover
        try:
            _cleanup_all()
        finally:
            if callable(prev_sigint) and prev_sigint not in {signal.SIG_DFL, signal.SIG_IGN}:
                prev_sigint(signum, frame)
            else:
                signal.default_int_handler(signum, frame)

    try:
        if hasattr(signal, "SIGINT"):
            signal.signal(signal.SIGINT, _handle_sigint)
    except (OSError, ValueError):
        pass
