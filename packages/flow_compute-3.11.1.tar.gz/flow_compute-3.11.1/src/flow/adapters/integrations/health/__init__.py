"""Health monitoring adapters for GPU instances.

This module provides clients and utilities for collecting GPU health metrics
from GPUd (the GPU health monitoring daemon).
"""

from flow.adapters.integrations.health.config import (
    DEFAULT_CONFIG,
    DEFAULT_GPUD_PORT,
    DEFAULT_HEALTH_ENDPOINTS,
    DEFAULT_TIMEOUT,
    GPUdConfig,
    HealthConfig,
    ScoringConfig,
    StorageConfig,
    StreamingConfig,
)
from flow.adapters.integrations.health.fleet_aggregator import (
    FleetHealthAggregator,
)
from flow.adapters.integrations.health.gpud_ssh_client import (
    GPUdSSHClient,
)
from flow.adapters.integrations.health.gpud_v08_adapter import (
    GPUdV08Client,
)
from flow.adapters.integrations.health.score_calculator import (
    HealthScoreBreakdown,
    calculate_health_score,
    score_to_status,
)
from flow.adapters.integrations.health.storage import (
    MetricsAggregator,
    MetricsBatcher,
    MetricsStore,
)

__all__ = [
    "DEFAULT_CONFIG",
    "DEFAULT_GPUD_PORT",
    "DEFAULT_HEALTH_ENDPOINTS",
    "DEFAULT_TIMEOUT",
    "FleetHealthAggregator",
    "GPUdConfig",
    "GPUdSSHClient",
    "GPUdV08Client",
    "HealthConfig",
    "HealthScoreBreakdown",
    "MetricsAggregator",
    "MetricsBatcher",
    "MetricsStore",
    "ScoringConfig",
    "StorageConfig",
    "StreamingConfig",
    "calculate_health_score",
    "score_to_status",
]
