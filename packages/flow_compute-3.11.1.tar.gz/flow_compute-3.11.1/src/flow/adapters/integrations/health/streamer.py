"""Health metrics streamer for GPU instances.

This module provides a standalone metrics collection and streaming service
that runs on GPU instances. It collects metrics from GPUd and either sends
them to a remote endpoint or stores them locally.

Can be invoked as:
    python -m flow.adapters.integrations.health.streamer --help

Or imported and used programmatically:
    from flow.adapters.integrations.health.streamer import MetricsStreamer
    streamer = MetricsStreamer(gpud_url="http://localhost:15132")
    streamer.run()
"""

from __future__ import annotations

import argparse
import json
import logging
import signal
import socket
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

from flow.adapters.integrations.health.config import DEFAULT_CONFIG
from flow.adapters.integrations.health.gpud_v08_adapter import GPUdV08Client

logger = logging.getLogger(__name__)


@dataclass
class StreamerConfig:
    """Configuration for the metrics streamer."""

    gpud_url: str = field(default_factory=lambda: DEFAULT_CONFIG.gpud.base_url)
    metrics_endpoint: str | None = field(default_factory=lambda: DEFAULT_CONFIG.streaming.endpoint)
    metrics_interval: int = field(default_factory=lambda: DEFAULT_CONFIG.streaming.interval_seconds)
    batch_size: int = field(default_factory=lambda: DEFAULT_CONFIG.streaming.batch_size)
    auth_token: str | None = field(default_factory=lambda: DEFAULT_CONFIG.streaming.auth_token)
    task_id: str = "unknown"
    task_name: str = "unknown"
    instance_type: str = "unknown"
    log_dir: Path = field(default_factory=lambda: DEFAULT_CONFIG.streaming.log_dir)

    @property
    def instance_id(self) -> str:
        """Get instance ID from hostname."""
        return socket.gethostname()


class MetricsStreamer:
    """Collects and streams GPU health metrics.

    This class provides the core metrics collection and streaming functionality.
    It can send metrics to a remote endpoint or store them locally in JSONL format.
    """

    def __init__(self, config: StreamerConfig | None = None, **kwargs: Any):
        """Initialize the metrics streamer.

        Args:
            config: StreamerConfig instance. If not provided, one will be
                created from kwargs.
            **kwargs: Arguments passed to StreamerConfig if config is None.
        """
        if config is None:
            config = StreamerConfig(**kwargs)
        self.config = config

        self._gpud_client: GPUdV08Client | None = None
        self._http_client: httpx.Client | None = None
        self._buffer: list[dict[str, Any]] = []
        self._shutdown_requested = False
        self._metrics_sent = 0
        self._metrics_failed = 0

    def _get_gpud_client(self) -> GPUdV08Client:
        """Get or create GPUd client."""
        if self._gpud_client is None:
            self._gpud_client = GPUdV08Client(
                base_url=self.config.gpud_url,
            )
        return self._gpud_client

    def _get_http_client(self) -> httpx.Client:
        """Get or create HTTP client for sending metrics."""
        if self._http_client is None:
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "flow-metrics-streamer/1.0",
            }
            if self.config.auth_token:
                headers["Authorization"] = f"Bearer {self.config.auth_token}"
            self._http_client = httpx.Client(headers=headers, timeout=30.0)
        return self._http_client

    def collect_metrics(self) -> dict[str, Any]:
        """Collect current metrics from GPUd.

        Returns:
            Dictionary containing all collected metrics in NodeHealthSnapshot-compatible format.
        """
        gpud = self._get_gpud_client()
        now = datetime.now(timezone.utc)

        metrics: dict[str, Any] = {
            "task_id": self.config.task_id,
            "task_name": self.config.task_name,
            "instance_id": self.config.instance_id,
            "instance_type": self.config.instance_type,
            "timestamp": now.isoformat(),
            "version": "1.0",
            "source": "flow-metrics-streamer",
        }

        # Check GPUd health
        try:
            metrics["gpud_healthy"] = gpud.is_healthy()
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to check GPUd health: {e}")
            metrics["gpud_healthy"] = False

        # Get machine info
        try:
            metrics["machine_info"] = gpud.get_machine_info()
            metrics["gpud_version"] = metrics["machine_info"].get("gpud_version")
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to get machine info: {e}")
            metrics["machine_info"] = {}
            metrics["gpud_version"] = None

        # Get GPU metrics
        try:
            gpu_metrics = gpud.get_gpu_metrics()
            metrics["gpu_metrics"] = [
                {
                    "gpu_index": g.gpu_index,
                    "uuid": g.uuid,
                    "name": g.name,
                    "temperature_c": g.temperature_c,
                    "power_draw_w": g.power_draw_w,
                    "power_limit_w": g.power_limit_w,
                    "memory_used_mb": g.memory_used_mb,
                    "memory_total_mb": g.memory_total_mb,
                    "gpu_utilization_pct": g.gpu_utilization_pct,
                    "sm_occupancy_pct": g.sm_occupancy_pct,
                    "clock_mhz": g.clock_mhz,
                    "max_clock_mhz": g.max_clock_mhz,
                    "ecc_errors": g.ecc_errors,
                    "xid_events": g.xid_events,
                    "nvlink_status": g.nvlink_status,
                    "processes": [
                        {
                            "pid": p.pid,
                            "name": p.name,
                            "memory_mb": p.memory_mb,
                            "gpu_index": p.gpu_index,
                        }
                        for p in g.processes
                    ],
                }
                for g in gpu_metrics
            ]
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to get GPU metrics: {e}")
            metrics["gpu_metrics"] = []

        # Get system metrics
        try:
            sys_metrics = gpud.get_system_metrics()
            if sys_metrics:
                metrics["system_metrics"] = {
                    "cpu_usage_pct": sys_metrics.cpu_usage_pct,
                    "memory_used_gb": sys_metrics.memory_used_gb,
                    "memory_total_gb": sys_metrics.memory_total_gb,
                    "disk_usage_pct": sys_metrics.disk_usage_pct,
                    "network_rx_mbps": sys_metrics.network_rx_mbps,
                    "network_tx_mbps": sys_metrics.network_tx_mbps,
                    "open_file_descriptors": sys_metrics.open_file_descriptors,
                    "load_average": sys_metrics.load_average,
                }
            else:
                metrics["system_metrics"] = {}
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to get system metrics: {e}")
            metrics["system_metrics"] = {}

        # Get health states
        try:
            health_states = gpud.get_health_states()
            metrics["health_states"] = [
                {
                    "component": hs.component,
                    "health": hs.health.value,
                    "message": hs.message,
                    "severity": hs.severity,
                    "timestamp": hs.timestamp.isoformat() if hs.timestamp else None,
                }
                for hs in health_states
            ]
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to get health states: {e}")
            metrics["health_states"] = []

        # Get network health
        try:
            metrics.update(gpud.get_network_health())
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to get network health: {e}")
            metrics["infiniband_healthy"] = True
            metrics["nccl_healthy"] = True

        # Get events
        try:
            events = gpud.get_events()
            metrics["events"] = [
                {
                    "timestamp": ev.timestamp.isoformat(),
                    "component": ev.component,
                    "level": ev.level,
                    "message": ev.message,
                    "details": ev.details,
                }
                for ev in events
            ]
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Failed to get events: {e}")
            metrics["events"] = []

        return metrics

    def _send_to_remote(self, batch: list[dict[str, Any]]) -> bool:
        """Send metrics batch to remote endpoint.

        Args:
            batch: List of metrics dictionaries to send.

        Returns:
            True if successful, False otherwise.
        """
        if not self.config.metrics_endpoint:
            return False

        try:
            client = self._get_http_client()
            payload = {
                "metrics": batch,
                "batch_size": len(batch),
            }
            response = client.post(self.config.metrics_endpoint, json=payload)

            if response.status_code >= 400:
                logger.warning(
                    f"Failed to send metrics: HTTP {response.status_code} - {response.text}"
                )
                return False

            logger.debug(f"Successfully sent {len(batch)} metrics")
            return True

        except httpx.HTTPError as e:
            logger.warning(f"HTTP error sending metrics: {e}")
            return False

    def _write_to_local(self, batch: list[dict[str, Any]]) -> bool:
        """Write metrics batch to local JSONL file.

        Args:
            batch: List of metrics dictionaries to write.

        Returns:
            True if successful, False otherwise.
        """
        try:
            # Create log directory if needed
            self.config.log_dir.mkdir(parents=True, exist_ok=True)

            # Daily rotation
            date_str = datetime.now(timezone.utc).strftime("%Y%m%d")
            log_file = self.config.log_dir / f"health-metrics-{date_str}.jsonl"

            with open(log_file, "a") as f:
                for metric in batch:
                    f.write(json.dumps(metric) + "\n")

            logger.debug(f"Wrote {len(batch)} metrics to {log_file}")
            return True

        except OSError as e:
            logger.error(f"Failed to write metrics locally: {e}")
            return False

    def flush(self) -> None:
        """Flush buffered metrics."""
        if not self._buffer:
            return

        batch = self._buffer.copy()
        self._buffer.clear()

        # Try remote first, fall back to local
        if self.config.metrics_endpoint:
            if self._send_to_remote(batch):
                self._metrics_sent += len(batch)
                return
            else:
                self._metrics_failed += len(batch)
                # Fall through to local storage

        # Write locally (either as fallback or primary)
        if self._write_to_local(batch):
            self._metrics_sent += len(batch)
        else:
            self._metrics_failed += len(batch)
            # Last resort: write to error log
            self._write_to_error_log(batch)

    def _write_to_error_log(self, batch: list[dict[str, Any]]) -> None:
        """Write metrics to error log as last resort."""
        try:
            self.config.log_dir.mkdir(parents=True, exist_ok=True)
            error_file = self.config.log_dir / "health-metrics-error.jsonl"
            with open(error_file, "a") as f:
                for metric in batch:
                    f.write(json.dumps(metric) + "\n")
        except OSError:
            pass  # Truly nothing we can do

    def _handle_signal(self, signum: int, frame: Any) -> None:
        """Handle shutdown signals gracefully."""
        logger.info(f"Received signal {signum}, shutting down...")
        self._shutdown_requested = True

    def run(self) -> None:
        """Main loop to collect and stream metrics.

        This method runs indefinitely until a shutdown signal is received.
        """
        # Set up signal handlers
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

        logger.info("Starting Flow metrics streamer...")
        logger.info(f"GPUd URL: {self.config.gpud_url}")
        logger.info(f"Metrics endpoint: {self.config.metrics_endpoint or 'local storage'}")
        logger.info(f"Collection interval: {self.config.metrics_interval}s")
        logger.info(f"Batch size: {self.config.batch_size}")

        while not self._shutdown_requested:
            try:
                metrics = self.collect_metrics()
                self._buffer.append(metrics)

                # Flush if buffer is full
                if len(self._buffer) >= self.config.batch_size:
                    self.flush()

            except Exception as e:  # noqa: BLE001
                logger.error(f"Error collecting metrics: {e}")

            # Sleep in small intervals to check shutdown flag
            for _ in range(self.config.metrics_interval):
                if self._shutdown_requested:
                    break
                time.sleep(1)

        # Final flush on shutdown
        logger.info("Flushing remaining metrics...")
        self.flush()
        self.close()

        logger.info(
            f"Shutdown complete. Sent: {self._metrics_sent}, Failed: {self._metrics_failed}"
        )

    def close(self) -> None:
        """Clean up resources."""
        if self._gpud_client:
            self._gpud_client.close()
            self._gpud_client = None
        if self._http_client:
            self._http_client.close()
            self._http_client = None


def main() -> None:
    """CLI entry point for the metrics streamer."""
    parser = argparse.ArgumentParser(
        description="Flow health metrics streamer",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--gpud-url",
        default=DEFAULT_CONFIG.gpud.base_url,
        help="GPUd API base URL",
    )
    parser.add_argument(
        "--endpoint",
        default=DEFAULT_CONFIG.streaming.endpoint,
        help="Remote metrics endpoint URL (omit for local storage)",
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=DEFAULT_CONFIG.streaming.interval_seconds,
        help="Metrics collection interval in seconds",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=DEFAULT_CONFIG.streaming.batch_size,
        help="Number of metrics to batch before sending",
    )
    parser.add_argument(
        "--auth-token",
        default=DEFAULT_CONFIG.streaming.auth_token,
        help="Authentication token for remote endpoint",
    )
    parser.add_argument(
        "--task-id",
        default="unknown",
        help="Task ID for metric attribution",
    )
    parser.add_argument(
        "--task-name",
        default="unknown",
        help="Task name for metric attribution",
    )
    parser.add_argument(
        "--instance-type",
        default="unknown",
        help="Instance type for metric attribution",
    )
    parser.add_argument(
        "--log-dir",
        type=Path,
        default=DEFAULT_CONFIG.streaming.log_dir,
        help="Directory for local metric storage",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Create config
    config = StreamerConfig(
        gpud_url=args.gpud_url,
        metrics_endpoint=args.endpoint,
        metrics_interval=args.interval,
        batch_size=args.batch_size,
        auth_token=args.auth_token,
        task_id=args.task_id,
        task_name=args.task_name,
        instance_type=args.instance_type,
        log_dir=args.log_dir,
    )

    # Run streamer
    streamer = MetricsStreamer(config)
    streamer.run()


if __name__ == "__main__":
    main()
