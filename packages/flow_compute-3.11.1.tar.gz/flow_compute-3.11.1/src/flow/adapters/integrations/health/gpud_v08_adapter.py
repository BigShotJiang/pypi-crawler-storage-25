"""GPUd v0.8.0 API adapter.

Handles the component-based API format introduced in GPUd v0.8.0, which returns
health states and metrics in a different structure than earlier versions.

The v0.8.0 API:
- Uses HTTPS with self-signed certificates by default
- Returns component-based health states via /v1/states
- Embeds detailed data in extra_info.data as JSON strings
- Returns Prometheus-style metrics via /v1/metrics
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import httpx

from flow.adapters.integrations.health.config import DEFAULT_CONFIG, GPUdConfig
from flow.errors import GPUdConnectionError
from flow.sdk.health_models import (
    ComponentHealth,
    GPUMetric,
    GPUProcess,
    HealthState,
    SystemEvent,
    SystemMetrics,
)

logger = logging.getLogger(__name__)


# Component names in GPUd v0.8.0
COMPONENT_TEMPERATURE = "accelerator-nvidia-temperature"
COMPONENT_MEMORY = "accelerator-nvidia-memory"
COMPONENT_UTILIZATION = "accelerator-nvidia-utilization"
COMPONENT_POWER = "accelerator-nvidia-power"
COMPONENT_CLOCK_SPEED = "accelerator-nvidia-clock-speed"
COMPONENT_ECC = "accelerator-nvidia-ecc"
COMPONENT_NVLINK = "accelerator-nvidia-nvlink"
COMPONENT_HW_SLOWDOWN = "accelerator-nvidia-hw-slowdown"
COMPONENT_PROCESSES = "accelerator-nvidia-processes"
COMPONENT_XID = "accelerator-nvidia-error-xid"
COMPONENT_SXID = "accelerator-nvidia-error-sxid"
COMPONENT_INFINIBAND = "accelerator-nvidia-infiniband"
COMPONENT_NCCL = "accelerator-nvidia-nccl"
COMPONENT_CPU = "cpu"
COMPONENT_DISK = "disk"
COMPONENT_HOST_MEMORY = "memory"

# Cache TTL for /v1/states response (seconds)
_STATES_CACHE_TTL = 2.0


@dataclass
class GPUData:
    """Intermediate structure to aggregate GPU data from multiple components."""

    uuid: str
    bus_id: str = ""
    name: str = "Unknown"
    temperature_c: float = 0.0
    power_draw_w: float = 0.0
    power_limit_w: float = 0.0
    memory_used_bytes: int = 0
    memory_total_bytes: int = 0
    gpu_utilization_pct: float = 0.0
    sm_occupancy_pct: float = 0.0
    clock_mhz: int = 0
    max_clock_mhz: int = 0
    ecc_errors: int = 0
    xid_events: list[str] = field(default_factory=list)
    nvlink_healthy: bool = True
    is_throttling: bool = False
    processes: list[GPUProcess] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Module-level parsing functions (shared by HTTP and SSH clients)
# ---------------------------------------------------------------------------


def parse_component_health(status: str) -> ComponentHealth:
    """Convert GPUd health string to ComponentHealth enum."""
    status_lower = status.lower()
    if status_lower == "healthy":
        return ComponentHealth.HEALTHY
    elif status_lower in ("degraded", "warning"):
        return ComponentHealth.DEGRADED
    elif status_lower in ("critical", "unhealthy", "error"):
        return ComponentHealth.UNHEALTHY
    else:
        return ComponentHealth.UNKNOWN


def parse_gpu_component_data(
    component: str,
    data: dict[str, Any],
    gpu_data: dict[str, GPUData],
) -> None:
    """Parse component-specific data and update GPU data structures."""
    if component == COMPONENT_TEMPERATURE:
        for temp in data.get("temperatures", []):
            uuid = temp.get("uuid")
            if uuid and uuid in gpu_data:
                temp_c = temp.get("current_celsius_gpu_core", temp.get("current_celsius", 0))
                gpu_data[uuid].temperature_c = float(temp_c)

    elif component == COMPONENT_MEMORY:
        for mem in data.get("memories", []):
            uuid = mem.get("uuid")
            if uuid and uuid in gpu_data:
                gpu_data[uuid].memory_used_bytes = int(mem.get("used_bytes", 0))
                gpu_data[uuid].memory_total_bytes = int(mem.get("total_bytes", 0))

    elif component == COMPONENT_UTILIZATION:
        for util in data.get("utilizations", []):
            uuid = util.get("uuid")
            if uuid and uuid in gpu_data:
                gpu_data[uuid].gpu_utilization_pct = float(util.get("gpu_used_percent", 0))
                gpu_data[uuid].sm_occupancy_pct = float(util.get("memory_used_percent", 0))

    elif component == COMPONENT_POWER:
        for power in data.get("powers", []):
            uuid = power.get("uuid")
            if uuid and uuid in gpu_data:
                usage_mw = power.get("usage_milli_watts", 0)
                limit_mw = power.get("enforced_limit_milli_watts", 0)
                gpu_data[uuid].power_draw_w = float(usage_mw) / 1000.0
                gpu_data[uuid].power_limit_w = float(limit_mw) / 1000.0

    elif component == COMPONENT_CLOCK_SPEED:
        for clock in data.get("clock_speeds", []):
            uuid = clock.get("uuid")
            if uuid and uuid in gpu_data:
                gpu_data[uuid].clock_mhz = int(clock.get("graphics_mhz", 0))
                # Leave max_clock_mhz as 0 when unknown; is_throttling handles it

    elif component == COMPONENT_ECC:
        for ecc in data.get("ecc_errors", []):
            uuid = ecc.get("uuid")
            if uuid and uuid in gpu_data:
                aggregate = ecc.get("aggregate", {})
                total = aggregate.get("total", {})
                uncorrected = int(total.get("uncorrected", 0))
                gpu_data[uuid].ecc_errors = uncorrected

    elif component == COMPONENT_NVLINK:
        for nvlink in data.get("nvlinks", []):
            uuid = nvlink.get("uuid")
            if uuid and uuid in gpu_data:
                for state in nvlink.get("states", []):
                    if (
                        state.get("replay_errors", 0) > 0
                        or state.get("recovery_errors", 0) > 0
                        or state.get("crc_errors", 0) > 0
                    ):
                        gpu_data[uuid].nvlink_healthy = False
                        break

    elif component == COMPONENT_HW_SLOWDOWN:
        for event in data.get("clock_events", []):
            uuid = event.get("uuid")
            if (
                uuid
                and uuid in gpu_data
                and (event.get("hw_slowdown") or event.get("hw_thermal_slowdown"))
            ):
                gpu_data[uuid].is_throttling = True

    elif component == COMPONENT_PROCESSES:
        for proc_info in data.get("processes", []):
            uuid = proc_info.get("uuid")
            if uuid and uuid in gpu_data:
                for proc in proc_info.get("processes", []):
                    gpu_data[uuid].processes.append(
                        GPUProcess(
                            pid=int(proc.get("pid", 0)),
                            name=str(proc.get("name", "")),
                            memory_mb=int(proc.get("used_gpu_memory_bytes", 0)) // (1024 * 1024),
                            gpu_index=list(gpu_data.keys()).index(uuid),
                        )
                    )


def build_gpu_metrics(
    components: list[dict[str, Any]],
    machine_info: dict[str, Any],
) -> list[GPUMetric]:
    """Build GPUMetric list from raw /v1/states components and machine info."""
    gpu_info = machine_info.get("gpuInfo", {})
    gpus = gpu_info.get("gpus", [])

    gpu_data: dict[str, GPUData] = {}
    for i, gpu in enumerate(gpus):
        uuid = gpu.get("uuid", f"GPU-{i}")
        gpu_data[uuid] = GPUData(
            uuid=uuid,
            bus_id=gpu.get("busID", ""),
            name=gpu_info.get("product", "Unknown"),
        )

    # Parse each component's data
    for component in components:
        comp_name = component.get("component", "")
        states = component.get("states", [])
        for state in states:
            extra_info = state.get("extra_info", {})
            data_str = extra_info.get("data", "")
            if not data_str:
                continue
            try:
                data = json.loads(data_str)
            except json.JSONDecodeError:
                continue
            parse_gpu_component_data(comp_name, data, gpu_data)

    metrics = []
    for i, (_uuid, data) in enumerate(gpu_data.items()):
        memory_used_mb = data.memory_used_bytes // (1024 * 1024)
        memory_total_mb = data.memory_total_bytes // (1024 * 1024)
        metrics.append(
            GPUMetric(
                gpu_index=i,
                uuid=data.uuid,
                name=data.name,
                temperature_c=data.temperature_c,
                power_draw_w=data.power_draw_w,
                power_limit_w=data.power_limit_w,
                memory_used_mb=memory_used_mb,
                memory_total_mb=memory_total_mb,
                gpu_utilization_pct=data.gpu_utilization_pct,
                sm_occupancy_pct=data.sm_occupancy_pct,
                clock_mhz=data.clock_mhz,
                max_clock_mhz=data.max_clock_mhz,
                ecc_errors=data.ecc_errors,
                xid_events=data.xid_events,
                nvlink_status="healthy" if data.nvlink_healthy else "degraded",
                processes=data.processes,
            )
        )
    return metrics


def build_system_metrics(components: list[dict[str, Any]]) -> SystemMetrics:
    """Build SystemMetrics from raw /v1/states components."""
    cpu_usage = 0.0
    memory_used_gb = 0.0
    memory_total_gb = 0.0
    disk_usage_pct = 0.0

    for component in components:
        comp_name = component.get("component", "")
        states = component.get("states", [])
        for state in states:
            extra_info = state.get("extra_info", {})
            data_str = extra_info.get("data", "")
            if not data_str:
                continue
            try:
                data = json.loads(data_str)
            except json.JSONDecodeError:
                continue

            if comp_name == COMPONENT_CPU:
                cpu_usage = float(data.get("usage_percent", 0))
            elif comp_name == COMPONENT_HOST_MEMORY:
                memory_used_gb = float(data.get("used_bytes", 0)) / (1024**3)
                memory_total_gb = float(data.get("total_bytes", 0)) / (1024**3)
            elif comp_name == COMPONENT_DISK:
                disk_usage_pct = float(data.get("usage_percent", 0))

    return SystemMetrics(
        cpu_usage_pct=cpu_usage,
        memory_used_gb=memory_used_gb,
        memory_total_gb=memory_total_gb,
        disk_usage_pct=disk_usage_pct,
        network_rx_mbps=0.0,
        network_tx_mbps=0.0,
        open_file_descriptors=0,
        load_average=[],
    )


def build_health_states(components: list[dict[str, Any]]) -> list[HealthState]:
    """Build HealthState list from raw /v1/states components."""
    health_states = []
    for component in components:
        comp_name = component.get("component", "")
        states = component.get("states", [])
        for state in states:
            health_str = state.get("health", "Unknown")
            health = parse_component_health(health_str)

            timestamp = None
            time_str = state.get("time")
            if time_str:
                try:
                    timestamp = datetime.fromisoformat(time_str.replace("Z", "+00:00"))
                except (ValueError, TypeError):
                    pass

            health_states.append(
                HealthState(
                    component=comp_name,
                    health=health,
                    message=state.get("reason", ""),
                    severity="info" if health == ComponentHealth.HEALTHY else "warning",
                    timestamp=timestamp,
                )
            )
    return health_states


def build_events(components: list[dict[str, Any]]) -> list[SystemEvent]:
    """Build SystemEvent list from raw /v1/events components."""
    events = []
    for component in components:
        comp_name = component.get("component", "")
        for event in component.get("events", []):
            timestamp = datetime.now(timezone.utc)
            time_str = event.get("time")
            if time_str:
                try:
                    timestamp = datetime.fromisoformat(time_str.replace("Z", "+00:00"))
                except (ValueError, TypeError):
                    pass

            event_type = event.get("type", "Unknown")
            level = "info"
            if event_type in ("Critical", "Fatal"):
                level = "error"
            elif event_type == "Warning":
                level = "warning"

            events.append(
                SystemEvent(
                    timestamp=timestamp,
                    component=comp_name,
                    level=level,
                    message=event.get("message", ""),
                    details={"name": event.get("name", "")},
                )
            )
    return events


def parse_network_health(components: list[dict[str, Any]]) -> dict[str, bool]:
    """Extract InfiniBand and NCCL health flags from /v1/states components.

    Returns:
        Dict with keys 'infiniband_healthy' and 'nccl_healthy'.
    """
    ib_healthy = True
    nccl_healthy = True

    for component in components:
        comp_name = component.get("component", "")
        states = component.get("states", [])

        if comp_name == COMPONENT_INFINIBAND:
            for state in states:
                health = parse_component_health(state.get("health", "Unknown"))
                if health in (ComponentHealth.UNHEALTHY, ComponentHealth.DEGRADED):
                    ib_healthy = False
                    break

        elif comp_name == COMPONENT_NCCL:
            for state in states:
                health = parse_component_health(state.get("health", "Unknown"))
                if health in (ComponentHealth.UNHEALTHY, ComponentHealth.DEGRADED):
                    nccl_healthy = False
                    break

    return {"infiniband_healthy": ib_healthy, "nccl_healthy": nccl_healthy}


# ---------------------------------------------------------------------------
# HTTP Client
# ---------------------------------------------------------------------------


class GPUdV08Client:
    """Client for GPUd v0.8.0 API.

    This client handles the component-based API format, aggregating data from
    multiple component endpoints into unified GPU metrics.
    """

    def __init__(
        self,
        base_url: str | None = None,
        config: GPUdConfig | None = None,
    ):
        """Initialize GPUd v0.8.0 client.

        Args:
            base_url: Base URL for GPUd API. If not provided, uses config.
            config: GPUdConfig instance. Uses DEFAULT_CONFIG if not provided.
        """
        self._config = config or DEFAULT_CONFIG.gpud
        self._base_url = (base_url or self._config.base_url).rstrip("/")
        self._client = httpx.Client(
            timeout=self._config.timeout_seconds,
            verify=self._config.verify_ssl,
        )
        self._machine_info_cache: dict[str, Any] | None = None
        self._states_cache: list[dict[str, Any]] | None = None
        self._states_cache_time: float = 0.0

    def _fetch_states(self) -> list[dict[str, Any]]:
        """Fetch /v1/states with short TTL cache.

        Avoids redundant HTTP calls when get_gpu_metrics(), get_system_metrics(),
        and get_health_states() are called in sequence within the same collection cycle.
        """
        now = time.monotonic()
        if self._states_cache is not None and (now - self._states_cache_time) < _STATES_CACHE_TTL:
            return self._states_cache

        resp = self._client.get(f"{self._base_url}/v1/states")
        resp.raise_for_status()
        self._states_cache = resp.json()
        self._states_cache_time = now
        return self._states_cache

    def invalidate_cache(self) -> None:
        """Clear the /v1/states response cache."""
        self._states_cache = None

    def is_healthy(self) -> bool:
        """Check if GPUd is responding."""
        for endpoint in self._config.health_endpoints:
            try:
                resp = self._client.get(f"{self._base_url}{endpoint}")
                if resp.status_code == 200:
                    return True
            except httpx.HTTPError:
                continue
        return False

    def get_machine_info(self) -> dict[str, Any]:
        """Get machine info from GPUd."""
        if self._machine_info_cache is not None:
            return self._machine_info_cache

        try:
            resp = self._client.get(f"{self._base_url}/machine-info")
            resp.raise_for_status()
            self._machine_info_cache = resp.json()
            return self._machine_info_cache
        except httpx.HTTPError as e:
            logger.warning(f"Failed to get machine info: {e}")
            return {}

    def get_gpu_metrics(self) -> list[GPUMetric]:
        """Get GPU metrics by aggregating component states."""
        try:
            components = self._fetch_states()
        except httpx.HTTPError as e:
            raise GPUdConnectionError(f"Failed to fetch component states: {e}") from e

        machine_info = self.get_machine_info()
        return build_gpu_metrics(components, machine_info)

    def get_system_metrics(self) -> SystemMetrics | None:
        """Get system metrics from component states."""
        try:
            components = self._fetch_states()
        except httpx.HTTPError as e:
            logger.warning(f"Failed to get system metrics: {e}")
            return None
        return build_system_metrics(components)

    def get_health_states(self) -> list[HealthState]:
        """Get component health states."""
        try:
            components = self._fetch_states()
        except httpx.HTTPError as e:
            logger.warning(f"Failed to get health states: {e}")
            return []
        return build_health_states(components)

    def get_network_health(self) -> dict[str, bool]:
        """Get InfiniBand and NCCL health flags from component states."""
        try:
            components = self._fetch_states()
        except httpx.HTTPError as e:
            logger.warning(f"Failed to get network health: {e}")
            return {"infiniband_healthy": True, "nccl_healthy": True}
        return parse_network_health(components)

    def get_events(self) -> list[SystemEvent]:
        """Get recent events from GPUd."""
        try:
            resp = self._client.get(f"{self._base_url}/v1/events")
            resp.raise_for_status()
            components = resp.json()
        except httpx.HTTPError as e:
            logger.warning(f"Failed to get events: {e}")
            return []
        return build_events(components)

    def collect_all(
        self,
    ) -> tuple[list[GPUMetric], SystemMetrics | None, list[HealthState], list[SystemEvent]]:
        """Collect all data with a single /v1/states fetch.

        Returns:
            Tuple of (gpu_metrics, system_metrics, health_states, events).
            Events require a separate /v1/events call.
        """
        self.invalidate_cache()
        gpu_metrics = self.get_gpu_metrics()
        system_metrics = self.get_system_metrics()
        health_states = self.get_health_states()
        events = self.get_events()
        return gpu_metrics, system_metrics, health_states, events

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> GPUdV08Client:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


__all__ = [
    "GPUData",
    "GPUdV08Client",
    "build_events",
    "build_gpu_metrics",
    "build_health_states",
    "build_system_metrics",
    "parse_component_health",
    "parse_gpu_component_data",
    "parse_network_health",
]
