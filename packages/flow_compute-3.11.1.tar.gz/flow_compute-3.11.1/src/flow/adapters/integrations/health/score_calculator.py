"""Health score calculation for GPU nodes.

This module provides pure functions for calculating health scores from
NodeHealthSnapshot data. All functions are side-effect free and easily testable.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flow.sdk.health_models import NodeHealthSnapshot, SystemEvent

from flow.adapters.integrations.health.config import DEFAULT_CONFIG, ScoringConfig
from flow.sdk.health_models import HealthStatus


@dataclass
class HealthScoreBreakdown:
    """Breakdown of health score by component."""

    gpu: float
    memory: float
    interconnect: float
    host: float
    software: float
    confidence: float
    overall: float

    def to_dict(self) -> dict[str, float]:
        """Convert to dictionary for serialization."""
        return {
            "gpu": round(self.gpu, 3),
            "memory": round(self.memory, 3),
            "interconnect": round(self.interconnect, 3),
            "host": round(self.host, 3),
            "software": round(self.software, 3),
            "confidence": round(self.confidence, 3),
            "overall": round(self.overall, 3),
        }


def calculate_health_score(
    snapshot: NodeHealthSnapshot,
    config: ScoringConfig | None = None,
) -> HealthScoreBreakdown:
    """Calculate health score with component breakdown.

    This is a pure function with no side effects - it takes a snapshot
    and returns a score breakdown without modifying any state.

    Args:
        snapshot: Node health snapshot to score
        config: Optional custom config for thresholds and weights (uses defaults if not provided)

    Returns:
        HealthScoreBreakdown with per-component and overall scores
    """
    config = config or DEFAULT_CONFIG.scoring

    # Calculate component scores
    gpu_score = _calculate_gpu_score(snapshot, config)
    memory_score = _calculate_memory_score(snapshot, config)
    interconnect_score = _calculate_interconnect_score(snapshot, config)
    host_score = _calculate_host_score(snapshot, config)
    software_score = _calculate_software_score(snapshot, config)

    # Calculate overall weighted score using config weights
    weights = config.weights
    overall = (
        weights["gpu"] * gpu_score
        + weights["memory"] * memory_score
        + weights["interconnect"] * interconnect_score
        + weights["host"] * host_score
        + weights["software"] * software_score
    )

    # Calculate confidence based on data availability
    confidence = _calculate_confidence(snapshot)

    # Clamp overall score to [0, 1]
    overall = max(0.0, min(1.0, overall))

    return HealthScoreBreakdown(
        gpu=gpu_score,
        memory=memory_score,
        interconnect=interconnect_score,
        host=host_score,
        software=software_score,
        confidence=confidence,
        overall=overall,
    )


def score_to_status(
    score: float,
    config: ScoringConfig | None = None,
) -> HealthStatus:
    """Convert numeric health score to status enum.

    Args:
        score: Health score between 0.0 and 1.0
        config: Optional config for thresholds (uses defaults if not provided)

    Returns:
        HealthStatus enum value
    """
    config = config or DEFAULT_CONFIG.scoring
    if score >= config.threshold_healthy:
        return HealthStatus.HEALTHY
    elif score >= config.threshold_degraded:
        return HealthStatus.DEGRADED
    elif score > 0:
        return HealthStatus.CRITICAL
    else:
        return HealthStatus.UNKNOWN


def _calculate_gpu_score(
    snapshot: NodeHealthSnapshot,
    thresholds: ScoringConfig,
) -> float:
    """Calculate GPU hardware health score."""
    if not snapshot.gpu_metrics:
        return 0.5  # Unknown/no data

    gpu_scores = []
    for gpu in snapshot.gpu_metrics:
        score = 1.0

        # Temperature penalty
        if gpu.temperature_c >= thresholds.temperature_critical_c:
            score *= 0.4
        elif gpu.temperature_c >= thresholds.temperature_warning_c:
            score *= 0.75

        # Throttling penalty
        if gpu.is_throttling:
            score *= 0.75

        # ECC errors penalty
        if gpu.ecc_errors > 0:
            score *= 0.6

        # XID events penalty
        if gpu.xid_events:
            score *= 0.7

        gpu_scores.append(score)

    return sum(gpu_scores) / len(gpu_scores)


def _calculate_memory_score(
    snapshot: NodeHealthSnapshot,
    thresholds: ScoringConfig,
) -> float:
    """Calculate GPU memory health score."""
    if not snapshot.gpu_metrics:
        return 0.7  # Assume reasonable default

    mem_scores = []
    for gpu in snapshot.gpu_metrics:
        score = 1.0

        mem_pct = gpu.memory_utilization_pct
        if mem_pct >= thresholds.gpu_memory_critical_pct:
            score *= 0.7
        elif mem_pct >= thresholds.gpu_memory_warning_pct:
            score *= 0.85

        # ECC errors also affect memory health
        if gpu.ecc_errors > 0:
            score *= 0.7

        mem_scores.append(score)

    return sum(mem_scores) / len(mem_scores)


def _calculate_interconnect_score(
    snapshot: NodeHealthSnapshot,
    thresholds: ScoringConfig,
) -> float:
    """Calculate interconnect (NVLink, InfiniBand, NCCL) health score."""
    score = 1.0

    # Check NVLink status from GPU metrics
    for gpu in snapshot.gpu_metrics or []:
        nvlink_status = gpu.nvlink_status.lower()
        if nvlink_status not in ("healthy", "ok", ""):
            score *= 0.75
            break

    # Direct InfiniBand and NCCL health flags from GPUd components
    if not snapshot.infiniband_healthy:
        score *= 0.7
    if not snapshot.nccl_healthy:
        score *= 0.7

    # Event-based penalties
    score -= _event_penalty(
        snapshot.events,
        ["nvlink", "nvswitch"],
        base_penalty=0.25,
        tau=thresholds.event_decay_tau_hours,
    )
    score -= _event_penalty(
        snapshot.events,
        ["infiniband", "ib", "rdma", "roce", "nic", "ethernet"],
        base_penalty=0.25,
        tau=thresholds.event_decay_tau_hours,
    )

    return max(0.0, score)


def _calculate_host_score(
    snapshot: NodeHealthSnapshot,
    thresholds: ScoringConfig,
) -> float:
    """Calculate host system health score."""
    score = 1.0

    # SSH connectivity penalty
    if not snapshot.ssh_reachable:
        score *= 0.3
    elif snapshot.ssh_latency_ms is not None and snapshot.ssh_latency_ms > 5000:
        score *= 0.8

    if not snapshot.system_metrics:
        return score * 0.8  # Discount without system data

    # CPU pressure
    if snapshot.system_metrics.cpu_usage_pct >= thresholds.host_cpu_critical_pct:
        score *= 0.9

    # Memory pressure
    if snapshot.system_metrics.memory_utilization_pct >= thresholds.host_memory_critical_pct:
        score *= 0.85

    # Disk pressure
    disk_pct = snapshot.system_metrics.disk_usage_pct
    if disk_pct >= thresholds.host_disk_critical_pct:
        score *= 0.9

    return score


def _calculate_software_score(
    snapshot: NodeHealthSnapshot,
    thresholds: ScoringConfig,
) -> float:
    """Calculate software/driver health score based on events."""
    score = 1.0

    # NCCL/distributed training issues
    score -= _event_penalty(
        snapshot.events,
        ["nccl", "watchdog", "timeout"],
        base_penalty=0.35,
        tau=thresholds.event_decay_tau_hours,
    )

    # Driver/hardware events
    score -= _event_penalty(
        snapshot.events,
        ["driver", "reset", "xid", "sxid"],
        base_penalty=0.2,
        tau=thresholds.event_decay_tau_hours,
    )

    return max(0.0, score)


def _calculate_confidence(snapshot: NodeHealthSnapshot) -> float:
    """Calculate confidence score based on data availability."""
    signals = [
        bool(snapshot.gpu_metrics),
        bool(snapshot.health_states),
        snapshot.system_metrics is not None,
        snapshot.gpud_healthy,
    ]
    return sum(signals) / len(signals)


def _event_penalty(
    events: list[SystemEvent],
    match_terms: list[str],
    base_penalty: float,
    tau: float,
) -> float:
    """Calculate time-decayed penalty for matching events.

    Args:
        events: List of system events
        match_terms: Terms to match in event component/message
        base_penalty: Maximum penalty per event
        tau: Time decay constant in hours

    Returns:
        Total penalty (capped at 0.8)
    """
    if not events:
        return 0.0

    penalty = 0.0
    now = datetime.now(timezone.utc)

    for event in events:
        # Check if event matches any term
        text = f"{event.component} {event.message}".lower()
        if not any(term in text for term in match_terms):
            continue

        # Calculate severity weight
        severity = event.level.lower()
        if severity == "error":
            sev_weight = 1.0
        elif severity == "warning":
            sev_weight = 0.5
        else:
            sev_weight = 0.2

        # Calculate time decay
        try:
            age_hours = (now - event.timestamp).total_seconds() / 3600.0
            decay = _time_decay(age_hours, tau)
        except (TypeError, AttributeError):
            decay = 1.0  # No timestamp, assume recent

        penalty += base_penalty * sev_weight * decay

    return min(penalty, 0.8)


def _time_decay(age_hours: float, tau: float) -> float:
    """Calculate exponential time decay factor.

    Args:
        age_hours: Age of event in hours
        tau: Time constant (events at age tau have ~37% weight)

    Returns:
        Decay factor between 0.0 and 1.0
    """
    if age_hours < 0:
        return 1.0
    try:
        return math.exp(-age_hours / tau)
    except (OverflowError, ValueError):
        return 0.0


__all__ = [
    "HealthScoreBreakdown",
    "ScoringConfig",
    "calculate_health_score",
    "score_to_status",
]
