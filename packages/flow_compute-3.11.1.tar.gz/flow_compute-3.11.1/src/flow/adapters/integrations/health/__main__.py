"""Allow running the health streamer as a module.

Usage:
    python -m flow.adapters.integrations.health --help
    python -m flow.adapters.integrations.health --gpud-url http://localhost:15132
"""

from flow.adapters.integrations.health.streamer import main

if __name__ == "__main__":
    main()
