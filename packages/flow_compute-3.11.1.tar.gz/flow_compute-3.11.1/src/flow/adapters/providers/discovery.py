"""Auto-detection of available compute providers.

Discovers which providers have valid credentials and can be queried.
Used by multi-provider status aggregation to determine which backends
to include in `flow status` output.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)


def _is_mithril_available() -> bool:
    """Check if Mithril API credentials are configured."""
    return bool(os.environ.get("MITHRIL_API_KEY"))


def _is_gcp_available() -> bool:
    """Check if GCP Application Default Credentials are available."""
    try:
        import google.auth

        credentials, project = google.auth.default()
        return credentials is not None
    except ImportError:
        return False
    except Exception:  # noqa: BLE001
        return False


def _is_skypilot_available() -> bool:
    """Check if SkyPilot is installed and importable."""
    try:
        import sky  # noqa: F401

        return True
    except ImportError:
        return False


# Ordered list of secondary providers to probe.
_SECONDARY_PROVIDER_NAMES = ("mithril", "gcp", "skypilot")


def _check_provider(name: str) -> bool:
    """Check if a provider has valid credentials."""
    checks = {
        "mithril": _is_mithril_available,
        "gcp": _is_gcp_available,
        "skypilot": _is_skypilot_available,
    }
    fn = checks.get(name)
    return fn() if fn else False


def discover_available_providers(primary: str) -> list[str]:
    """Return names of all providers that have valid credentials.

    The primary provider is always first in the returned list (and always
    included, even if its availability check fails -- the caller handles
    auth errors). Additional providers are auto-detected and appended.

    Args:
        primary: The primary/configured provider name.

    Returns:
        List of provider names, primary first, then detected secondaries.
    """
    available = [primary]

    for name in _SECONDARY_PROVIDER_NAMES:
        if name == primary:
            continue
        try:
            if _check_provider(name):
                available.append(name)
                logger.debug("Auto-detected provider: %s", name)
        except Exception:  # noqa: BLE001
            logger.debug("Provider check failed for %s", name, exc_info=True)

    return available
