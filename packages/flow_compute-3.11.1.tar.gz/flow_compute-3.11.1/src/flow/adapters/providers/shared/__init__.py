"""Shared provider utilities.

Provider-agnostic helpers that multiple providers can reuse without violating
the cross-provider independence contract. Modules here must not import from
any concrete provider package (mithril, local, mock).
"""
