"""Filesystem copy primitives for local/in-process provider file transfers.

These helpers exist to eliminate copy-paste of ``shutil.copy2`` blocks across
providers that back storage with a local filesystem path (e.g. the local
provider's volume directories). They are deliberately narrow: path-to-path
operations with no knowledge of volumes, tasks, or providers.

Design notes:

* ``copy_file`` and ``copy_directory`` **raise** on failure rather than
  returning a boolean. Callers that need to translate failures into a
  protocol-level ``bool`` should catch and convert at the boundary; the
  helper itself follows the project's "fail closed, not silent" rule.
* Parent directories for destinations are created automatically. This
  mirrors the common caller expectation and avoids repeated
  ``mkdir(parents=True, exist_ok=True)`` boilerplate.
* ``copy_directory`` copies file contents and metadata via
  :func:`shutil.copy2`, preserving mtimes so that incremental sync use
  cases can trust timestamps.
"""

from __future__ import annotations

import shutil
from pathlib import Path

__all__ = ["copy_directory", "copy_file"]


def copy_file(src: Path, dst: Path) -> None:
    """Copy a single file from ``src`` to ``dst``.

    Creates ``dst``'s parent directory if it does not already exist. Metadata
    (mtime, permissions) is preserved via :func:`shutil.copy2`.

    Args:
        src: Existing source file path.
        dst: Destination file path. Parent directories are created as needed.

    Raises:
        FileNotFoundError: If ``src`` does not exist.
        IsADirectoryError: If ``src`` is a directory rather than a file.
        OSError: On underlying I/O failure (permissions, disk full, ...).
    """
    if not src.exists():
        raise FileNotFoundError(f"source file does not exist: {src}")
    if src.is_dir():
        raise IsADirectoryError(f"source is a directory, not a file: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def copy_directory(src: Path, dst: Path) -> None:
    """Recursively copy a directory tree from ``src`` to ``dst``.

    Walks ``src`` and copies every regular file beneath it into the matching
    relative location under ``dst``. Intermediate directories under ``dst``
    are created as needed. Symbolic links are dereferenced.

    This does **not** use :func:`shutil.copytree` because it is intentionally
    permissive about an already-existing destination directory: callers may
    merge a source tree into an existing target.

    Args:
        src: Existing source directory.
        dst: Destination directory. Created if missing; merged if present.

    Raises:
        FileNotFoundError: If ``src`` does not exist.
        NotADirectoryError: If ``src`` exists but is not a directory.
        OSError: On underlying I/O failure.
    """
    if not src.exists():
        raise FileNotFoundError(f"source directory does not exist: {src}")
    if not src.is_dir():
        raise NotADirectoryError(f"source is not a directory: {src}")
    dst.mkdir(parents=True, exist_ok=True)
    for entry in src.rglob("*"):
        if not entry.is_file():
            continue
        target = dst / entry.relative_to(src)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(entry, target)
