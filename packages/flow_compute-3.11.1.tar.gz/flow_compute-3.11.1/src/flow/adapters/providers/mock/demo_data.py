"""Factory functions for mock provider demo data.

Creates pre-seeded tasks and volumes for demo/tutorial mode.
"""

from __future__ import annotations

import hashlib
import threading
import uuid
from datetime import datetime, timedelta, timezone

from flow.sdk.models import Task, TaskStatus, Volume


def _make_task_id() -> str:
    return f"mock-{uuid.uuid4().hex[:8]}"


def _demo_ip(name: str) -> str:
    h = int(hashlib.sha256(name.encode("utf-8")).hexdigest()[:6], 16)
    return f"10.{(h >> 16) & 0xFF}.{(h >> 8) & 0xFF}.{h & 0xFF}"


def _flow_task(
    name: str,
    instance_type: str,
    age: timedelta,
    status: TaskStatus,
    project: str,
    *,
    now: datetime,
    num_instances: int = 1,
    ssh_host: str | None = None,
    cost: str = "$8.00",
    message: str | None = None,
    instance_status: str = "STATUS_RUNNING",
    completed_age: timedelta | None = None,
) -> Task:
    """Create a Flow CLI-originated demo task."""
    task_id = _make_task_id()
    created = now - age
    started = created if status != TaskStatus.PENDING else None
    completed_at = (
        (now - completed_age)
        if completed_age
        and status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED)
        else None
    )

    if ssh_host is None and status == TaskStatus.RUNNING:
        ssh_host = _demo_ip(name)

    t = Task(
        task_id=task_id,
        name=name,
        status=status,
        config=None,
        created_at=created,
        started_at=started,
        completed_at=completed_at,
        instance_type=instance_type,
        num_instances=num_instances,
        region="demo-region-1",
        cost_per_hour=cost,
        message=message,
        created_by="you",
        ssh_host=ssh_host,
        ssh_port=22,
        ssh_user="ubuntu",
        shell_command=(f"ssh ubuntu@{ssh_host}" if ssh_host else None),
    )
    t.provider_metadata = {
        "origin": "flow-cli",
        "instance_status": instance_status,
        "project": project,
    }
    t.instances = [f"inst-{task_id}-{i}" for i in range(num_instances)]
    return t


def _external_task(
    name: str,
    instance_type: str,
    age: timedelta,
    num_instances: int,
    ssh_host: str,
    *,
    now: datetime,
    created_by: str = "external",
) -> Task:
    """Create an externally managed demo task."""
    task_id = _make_task_id()
    created = now - age
    t = Task(
        task_id=task_id,
        name=name,
        status=TaskStatus.RUNNING,
        config=None,
        created_at=created,
        started_at=created,
        instance_type=instance_type,
        num_instances=num_instances,
        region="demo-region-1",
        cost_per_hour="$0.00",
        created_by=created_by,
        ssh_host=ssh_host,
        ssh_port=22,
        ssh_user="ubuntu",
        shell_command=f"ssh ubuntu@{ssh_host}",
    )
    t.provider_metadata = {"origin": "external", "instance_status": "STATUS_RUNNING"}
    return t


class _TaskEntry:
    """Container for a demo task and its log lines."""

    __slots__ = ("lock", "logs", "task")

    def __init__(self, task: Task, logs: list[str]):
        self.task = task
        self.logs = logs
        self.lock = threading.Lock()


def create_all_demo_tasks(now: datetime | None = None) -> list[_TaskEntry]:
    """Create all seeded demo tasks.

    Returns:
        List of (task, logs) entries ready to be registered by MockProvider.
    """
    if now is None:
        now = datetime.now(timezone.utc)

    entries: list[_TaskEntry] = []

    # 1) CLI welcome task (running, just started)
    t0 = _flow_task(
        "cli-welcome",
        "a100",
        timedelta(seconds=15),
        TaskStatus.RUNNING,
        "post-training-team",
        now=now,
        ssh_host=None,
        instance_status="STATUS_STARTING",
    )
    entries.append(_TaskEntry(t0, ["[mock] welcome to Flow CLI"]))

    # 2) 8×A100 training run
    t1 = _flow_task(
        "pretraining-train-8xa100",
        "8xa100",
        timedelta(minutes=7),
        TaskStatus.RUNNING,
        "pretraining",
        now=now,
        cost="$64.00",
        ssh_host="10.0.0.11",
    )
    entries.append(_TaskEntry(t1, ["[mock] demo-training running"]))

    # 3) Pending A100 provisioning
    t2 = _flow_task(
        "pretraining-pending-a100-40g",
        "a100-40gb",
        timedelta(minutes=1),
        TaskStatus.PENDING,
        "pretraining",
        now=now,
        instance_status="STATUS_SCHEDULED",
    )
    entries.append(_TaskEntry(t2, ["[mock] provisioning"]))

    # 4) H100 inference serving
    t3 = _flow_task(
        "inference-serving",
        "h100",
        timedelta(minutes=3),
        TaskStatus.RUNNING,
        "inference-optimization",
        now=now,
        cost="$24.00",
        ssh_host="10.0.0.13",
    )
    entries.append(_TaskEntry(t3, ["[mock] demo-inference serving"]))

    # 5) Post-training eval (old, running)
    t4 = _flow_task(
        "post-training-eval",
        "a100-40gb",
        timedelta(days=5),
        TaskStatus.RUNNING,
        "post-training-team",
        now=now,
        ssh_host=None,
    )
    entries.append(_TaskEntry(t4, ["[mock] post-processing complete"]))

    # 6) Fine-tune pipeline (starting)
    t5 = _flow_task(
        "post-training-fine-tune",
        "8xh100",
        timedelta(minutes=2),
        TaskStatus.RUNNING,
        "post-training-team",
        now=now,
        cost="$192.00",
        ssh_host=None,
        message="Starting fine-tune pipeline",
        instance_status="STATUS_STARTING",
    )
    entries.append(
        _TaskEntry(
            t5,
            [
                "[mock] pulling container image",
                "[mock] preparing datasets",
                "[mock] launching trainers",
            ],
        )
    )

    # 7) Large pretraining cluster (256 nodes)
    t6 = _flow_task(
        "pretraining-2048-h100",
        "8xh100",
        timedelta(hours=6),
        TaskStatus.RUNNING,
        "pretraining",
        now=now,
        num_instances=256,
        cost="$384.00",
        ssh_host="10.0.1.1",
    )
    entries.append(_TaskEntry(t6, ["[mock] orchestrator ready", "[mock] workers connected: 256"]))

    # 8) Post-training sanity checks
    entries.append(
        _TaskEntry(
            _flow_task(
                "post-training-sanity-1",
                "a100-40gb",
                timedelta(seconds=45),
                TaskStatus.RUNNING,
                "post-training-team",
                now=now,
            ),
            ["[mock] sanity checks running"],
        )
    )
    entries.append(
        _TaskEntry(
            _flow_task(
                "post-training-sanity-2",
                "a100-40gb",
                timedelta(minutes=10),
                TaskStatus.RUNNING,
                "post-training-team",
                now=now,
            ),
            ["[mock] additional checks running"],
        )
    )

    # 9) H200 / B200 research tasks
    entries.append(
        _TaskEntry(
            _flow_task(
                "reasoning-train-h200",
                "h200",
                timedelta(weeks=3),
                TaskStatus.RUNNING,
                "reasoning-research",
                now=now,
            ),
            ["[mock] h200 training loop active"],
        )
    )
    entries.append(
        _TaskEntry(
            _flow_task(
                "reasoning-rollout-b200",
                "8xb200",
                timedelta(hours=2),
                TaskStatus.RUNNING,
                "reasoning-research",
                now=now,
            ),
            ["[mock] 8xB200 rollout running"],
        )
    )
    entries.append(
        _TaskEntry(
            _flow_task(
                "reasoning-experiment-b200",
                "b200",
                timedelta(days=365),
                TaskStatus.FAILED,
                "reasoning-research",
                now=now,
                completed_age=timedelta(days=364, hours=23),
            ),
            ["[mock] oom on step 42"],
        )
    )

    # 10) External clusters
    ext0 = _external_task(
        "cluster-mithril-gui",
        "8xh100",
        timedelta(days=2),
        256,
        "10.0.2.1",
        now=now,
        created_by="console",
    )
    ext0.provider_metadata["project"] = "pretraining"
    ext0.instances = [f"inst-{ext0.task_id}-{i}" for i in range(256)]
    entries.append(_TaskEntry(ext0, ["[mock] managed via GUI"]))

    # 11) GB200 NVL72 cluster (Flow-managed)
    gb_flow = _flow_task(
        "gb200-nvl72-cluster",
        "gb200nvl72",
        timedelta(days=1),
        TaskStatus.RUNNING,
        "infrastructure",
        now=now,
        num_instances=100,
        cost="$0.00",
        ssh_host="10.0.3.1",
    )
    entries.append(_TaskEntry(gb_flow, ["[mock] GB200 NVL72 cluster running (Flow-managed)"]))

    # 12) External mega-clusters
    ext1 = _external_task(
        "training-cluster", "8xh100", timedelta(days=10), 2500, "10.0.2.2", now=now
    )
    entries.append(_TaskEntry(ext1, ["[mock] external training cluster active"]))

    ext2 = _external_task(
        "guilds-cluster", "8xh100", timedelta(days=21), 12500, "10.0.2.3", now=now
    )
    entries.append(_TaskEntry(ext2, ["[mock] guilds mega cluster active"]))

    ext3 = _external_task(
        "integrated-private-cloud",
        "8xh100",
        timedelta(days=30),
        12500,
        "10.0.2.4",
        now=now,
    )
    entries.append(_TaskEntry(ext3, ["[mock] integrated private cloud active"]))

    return entries


def create_demo_volumes(now: datetime | None = None) -> list[Volume]:
    """Create seeded demo volumes."""
    if now is None:
        now = datetime.now(timezone.utc)

    volumes = []
    for name, size in (
        ("dataset-imagenet", 500),
        ("pretrained-llama-7b", 100),
        ("checkpoints", 200),
    ):
        vol_id = f"mock-vol-{uuid.uuid4().hex[:6]}"
        volumes.append(
            Volume(
                volume_id=vol_id,
                name=name,
                size_gb=size,
                region="demo-region-1",
                interface="block",  # type: ignore
                created_at=now,
            )
        )
    return volumes
