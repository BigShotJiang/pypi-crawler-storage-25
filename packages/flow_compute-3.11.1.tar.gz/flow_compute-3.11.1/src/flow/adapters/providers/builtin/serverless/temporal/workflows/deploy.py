"""DeployWorkflow -- creates/updates K8s resources for a function deployment.

Used by ``flow deploy`` to set up Deployments, Services, KEDA ScaledObjects,
Ingress resources, and Temporal Schedules for all declared functions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any

try:
    from temporalio import workflow

    with workflow.unsafe.imports_passed_through():
        from flow.adapters.providers.builtin.serverless.temporal.activities.container import (
            ensure_container_ready,
        )
        from flow.adapters.providers.builtin.serverless.temporal.activities.image import (
            ensure_image,
        )
        from flow.adapters.providers.builtin.serverless.temporal.workflows.invocation import (
            EnsureContainerInput,
            EnsureImageInput,
        )
except ImportError:
    workflow = None  # type: ignore[assignment]


@dataclass(frozen=True)
class DeployInput:
    """Input to DeployWorkflow.

    Attributes:
        functions: List of function specs to deploy. Each dict contains:
            name, image_spec, instance_type, min_containers, max_containers,
            scaledown_window, schedule (optional), web_endpoint (bool).
        namespace: K8s namespace.
        registry: Container image registry URL.
        project: Project ID.
    """

    functions: list[dict[str, Any]]
    namespace: str = "flow-serverless"
    registry: str = ""
    project: str = ""


@dataclass(frozen=True)
class DeployResult:
    """Result of a deployment."""

    deployed_functions: list[str] = field(default_factory=list)
    web_endpoints: dict[str, str] = field(default_factory=dict)
    schedules: list[str] = field(default_factory=list)


if workflow is not None:

    @workflow.defn
    class DeployWorkflow:
        """Workflow that deploys one or more functions to the serverless backend.

        For each function:
        1. Build and push container image.
        2. Create/update K8s Deployment + Service + KEDA ScaledObject.
        3. Create Temporal Schedule if schedule is declared.
        4. Create Ingress if web_endpoint is True.
        """

        @workflow.run
        async def run(self, input: DeployInput) -> DeployResult:
            result = DeployResult()

            for func_spec in input.functions:
                name = func_spec["name"]

                # Build image
                image_ref = await workflow.execute_activity(
                    ensure_image,
                    EnsureImageInput(
                        image_spec=func_spec["image_spec"],
                        registry=input.registry,
                        project=input.project,
                        function_name=name,
                    ),
                    start_to_close_timeout=timedelta(minutes=30),
                )

                # Create K8s resources
                await workflow.execute_activity(
                    ensure_container_ready,
                    EnsureContainerInput(
                        function_name=name,
                        image_ref=image_ref,
                        gpu=func_spec.get("instance_type", ""),
                        namespace=input.namespace,
                        min_containers=func_spec.get("min_containers", 0),
                        max_containers=func_spec.get("max_containers", 100),
                        scaledown_window=func_spec.get("scaledown_window", 60),
                    ),
                    start_to_close_timeout=timedelta(minutes=10),
                )

                result.deployed_functions.append(name)

            return result

else:

    class DeployWorkflow:  # type: ignore[no-redef]
        """Stub when temporalio is not installed."""

        async def run(self, input: DeployInput) -> DeployResult:
            raise ImportError("temporalio is required for serverless backend")
