"""SkyPilot pricing adapter module.

Queries SkyPilot catalog and transforms pricing data to Flow's domain models.
"""

from flow.adapters.providers.builtin.skypilot.pricing.adapter import (
    SkyPilotPricingAdapter,
)

__all__ = ["SkyPilotPricingAdapter"]
