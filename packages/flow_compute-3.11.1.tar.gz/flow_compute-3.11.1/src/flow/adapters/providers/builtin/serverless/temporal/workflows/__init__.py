"""Temporal workflow definitions for serverless function execution.

Workflows:
    FunctionInvocationWorkflow: Single .remote() call lifecycle.
    MapWorkflow: Fan-out via child workflows for .map().
    ClassMethodWorkflow: @app.cls() enter/method/exit lifecycle.
    DeployWorkflow: Create/update K8s resources on deploy.
"""
