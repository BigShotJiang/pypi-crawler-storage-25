"""MapWorkflow -- fan-out via Temporal child workflows for .map() calls.

Each input item spawns an independent FunctionInvocationWorkflow as a child.
Results are collected in input order and returned as a list.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

try:
    from temporalio import workflow

    with workflow.unsafe.imports_passed_through():
        from flow.adapters.providers.builtin.serverless.temporal.workflows.invocation import (
            FunctionInvocationInput,
            FunctionInvocationWorkflow,
        )
except ImportError:
    workflow = None  # type: ignore[assignment]


@dataclass(frozen=True)
class MapInput:
    """Input to MapWorkflow.

    Attributes:
        function_name: Registered function name.
        image_spec: Serialized Image build steps.
        instance_type: GPU type.
        items: List of serialized (args, kwargs) for each invocation.
        volume_ids: Volume IDs to mount.
        timeout_seconds: Max time per individual invocation.
        namespace: K8s namespace.
    """

    function_name: str
    image_spec: dict[str, Any]
    instance_type: str
    items: list[bytes]
    volume_ids: list[str] = field(default_factory=list)
    timeout_seconds: int = 3600
    namespace: str = "flow-serverless"


if workflow is not None:

    @workflow.defn
    class MapWorkflow:
        """Fan-out workflow that spawns child FunctionInvocationWorkflows.

        Provides a progress query so the SDK can report completion incrementally.
        """

        def __init__(self) -> None:
            self._completed: int = 0

        @workflow.run
        async def run(self, input: MapInput) -> list[bytes]:
            children = []
            for i, item_args in enumerate(input.items):
                child = await workflow.start_child_workflow(
                    FunctionInvocationWorkflow.run,
                    FunctionInvocationInput(
                        function_name=input.function_name,
                        image_spec=input.image_spec,
                        instance_type=input.instance_type,
                        args_serialized=item_args,
                        volume_ids=input.volume_ids,
                        timeout_seconds=input.timeout_seconds,
                        namespace=input.namespace,
                    ),
                    id=f"{workflow.info().workflow_id}-item-{i}",
                )
                children.append((i, child))

            # Collect results in input order
            results: list[bytes | None] = [None] * len(children)
            for i, child in children:
                results[i] = await child
                self._completed += 1

            return results  # type: ignore[return-value]

        @workflow.query
        def progress(self) -> int:
            """Return number of completed child workflows."""
            return self._completed

else:

    class MapWorkflow:  # type: ignore[no-redef]
        """Stub when temporalio is not installed."""

        async def run(self, input: MapInput) -> list[bytes]:
            raise ImportError("temporalio is required for serverless backend")
