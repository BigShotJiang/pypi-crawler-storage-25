"""SkyPilot provider implementation.

This provider uses SkyPilot to orchestrate GPU workloads across cloud providers.
All SkyPilot interactions are isolated through the bridge layer.
"""

from __future__ import annotations

import logging
import os
import subprocess
import threading
import uuid
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

from flow.adapters.providers.adapter import ProviderAdapter
from flow.adapters.providers.base import PricingModel, ProviderCapabilities
from flow.adapters.providers.builtin.skypilot.bridge import SkyBridge
from flow.adapters.providers.builtin.skypilot.config import SkyPilotConfig
from flow.adapters.providers.builtin.skypilot.domain.gpu_constants import (
    normalize_gpu_name,
)
from flow.adapters.providers.builtin.skypilot.domain.gpu_constants import (
    parse_instance_type as _parse_gpu_spec,
)
from flow.adapters.providers.builtin.skypilot.domain.state_store import StateStore, TaskRecord
from flow.adapters.providers.builtin.skypilot.domain.status_map import is_terminal_status
from flow.adapters.providers.builtin.skypilot.domain.storage import StorageManager
from flow.adapters.providers.builtin.skypilot.exceptions import (
    ClusterNotFoundError,
    SkyPilotProviderError,
)
from flow.errors import TaskNotFoundError
from flow.sdk.models import Task, TaskConfig, TaskStatus, Volume

if TYPE_CHECKING:
    from flow.application.config.config import Config
    from flow.sdk.models import AvailableInstance

logger = logging.getLogger(__name__)

# SkyPilot SSH config directory
_SKY_SSH_CONFIG_DIR = Path.home() / ".sky" / "generated" / "ssh"


def _read_sky_ssh_directive(cluster_name: str, directive: str) -> str | None:
    """Read a directive value from SkyPilot's generated SSH config.

    SkyPilot writes per-cluster SSH configs at
    ~/.sky/generated/ssh/<cluster_name> containing directives like
    User, IdentityFile, etc.

    Args:
        cluster_name: SkyPilot cluster name.
        directive: SSH config directive to read (e.g. "User", "IdentityFile").

    Returns:
        Directive value, or None if not found.
    """
    ssh_config = _SKY_SSH_CONFIG_DIR / cluster_name
    if not ssh_config.exists():
        return None
    prefix = f"{directive} "
    for line in ssh_config.read_text().splitlines():
        stripped = line.strip()
        if stripped.startswith(prefix):
            parts = stripped.split(None, 1)
            if len(parts) == 2:
                return parts[1]
    return None


@dataclass(frozen=True)
class _LaunchPolicy:
    """Resolved cloud and region policy for a SkyPilot launch."""

    clouds: list[str]
    region_by_cloud: dict[str, str]
    task_region: str


class SkyPilotRemoteOperations:
    """Remote operations for SkyPilot clusters.

    Delegates SSH to SkyPilot's auto-generated SSH config at
    ~/.sky/generated/ssh/<cluster_name>. SkyPilot manages keys,
    so no key resolution is needed.
    """

    def __init__(self, provider: SkyPilotProvider) -> None:
        self._provider = provider

    def _cluster_name(self, task_id: str) -> str:
        """Resolve task_id to cluster name."""
        task = self._provider.get_task(task_id)
        if not task.instances:
            raise SkyPilotProviderError(f"No cluster for task {task_id}")
        return task.instances[0]

    def open_shell(
        self,
        task_id: str,
        command: str | None = None,
        node: int | None = None,
        progress_context: Any = None,
        record: bool = False,
        *,
        ssh_details: Any = None,
    ) -> None:
        """Open interactive SSH or execute command on SkyPilot cluster."""
        cluster = self._cluster_name(task_id)
        argv = ["ssh", cluster]
        if command:
            argv.extend(["--", command])

        if command:
            subprocess.run(argv, check=False)
        else:
            os.execvp(argv[0], argv)

    def execute_command(
        self,
        task_id: str,
        command: str,
        timeout: int | None = None,
        *,
        node: int | None = None,
    ) -> str:
        """Execute command on SkyPilot cluster and return output."""
        cluster = self._cluster_name(task_id)
        argv = ["ssh", cluster, "--", command]
        result = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            logger.warning(
                "Command failed on %s (exit %d): %s",
                cluster,
                result.returncode,
                stderr or "(no stderr)",
            )
        return result.stdout

    def upload_file(self, task_id: str, local_path: Path, remote_path: str) -> bool:
        """Upload file via SCP."""
        cluster = self._cluster_name(task_id)
        result = subprocess.run(
            ["scp", str(local_path), f"{cluster}:{remote_path}"],
            check=False,
        )
        return result.returncode == 0

    def download_file(self, task_id: str, remote_path: str, local_path: Path) -> bool:
        """Download file via SCP."""
        cluster = self._cluster_name(task_id)
        result = subprocess.run(
            ["scp", f"{cluster}:{remote_path}", str(local_path)],
            check=False,
        )
        return result.returncode == 0

    def get_task_logs(self, task_id: str, log_type: str = "stdout", tail: int | None = None) -> str:
        """Get logs via provider."""
        return self._provider.get_task_logs(task_id, tail=tail or 100, log_type=log_type)

    def stream_task_logs(
        self, task_id: str, log_type: str = "stdout", follow: bool = True
    ) -> Iterable[str]:
        """Stream logs via provider."""
        return self._provider.stream_task_logs(task_id, log_type=log_type, follow=follow)

    def get_ssh_connection_info(self, task_id: str) -> dict[str, Any]:
        """Get SSH connection info from SkyPilot's SSH config."""
        cluster = self._cluster_name(task_id)
        return {
            "host": cluster,
            "user": "ubuntu",  # SkyPilot manages SSH; user varies by cloud
            "port": 22,
            "method": "ssh_config",
            "note": "SkyPilot manages SSH keys automatically",
        }


class SkyPilotProvider(ProviderAdapter):
    """Provider for SkyPilot-based GPU workloads.

    This provider orchestrates GPU workloads across multiple cloud providers
    (GCP, AWS, Azure) using SkyPilot. It supports:
    - Multi-cloud GPU pricing and selection
    - Spot and on-demand instances
    - Automatic cloud failover
    - Task submission and monitoring

    All SkyPilot interactions are isolated through the bridge layer to prevent
    sky.* types from leaking into the Flow codebase.
    """

    def __init__(self, config: Config) -> None:
        """Initialize SkyPilot provider.

        Args:
            config: SDK configuration object.
        """
        if config.provider != "skypilot":
            raise ValueError(
                f"SkyPilotProvider requires 'skypilot' provider, got: {config.provider}"
            )

        # Define SkyPilot provider capabilities
        capabilities = ProviderCapabilities(
            supports_spot_instances=True,
            supports_on_demand=True,
            supports_multi_node=True,
            supports_attached_storage=True,
            supports_shared_storage=False,
            storage_types=["volume"],
            requires_ssh_keys=False,  # SkyPilot manages its own SSH keys
            supports_console_access=False,
            pricing_model=PricingModel.MARKET,
            supports_reservations=False,
            supported_regions=[],  # Dynamically determined by enabled clouds
            max_instances_per_task=None,
            max_storage_per_instance_gb=None,
            supports_custom_images=True,
            supports_gpu_passthrough=True,
            supports_live_migration=False,
        )

        super().__init__(name="skypilot", capabilities=capabilities)

        self.config = config
        self._sky_config = SkyPilotConfig.from_dict(config.provider_config or {})
        self._bridge = SkyBridge(self._sky_config)
        self._state_store = StateStore()
        self._storage_manager = StorageManager(self._bridge, self._state_store)

        # In-memory task tracking, lazily seeded from state store + SkyPilot
        self._lock = threading.Lock()
        self._tasks: dict[str, Task] = {}
        self._recovered = False

    @classmethod
    def from_config(cls, config: Config) -> SkyPilotProvider:
        """Create SkyPilotProvider from config.

        This is the standard factory method used by the SDK.

        Args:
            config: SDK configuration.

        Returns:
            Initialized SkyPilotProvider instance.
        """
        return cls(config)

    def validate_task_config(self, config: TaskConfig) -> tuple[bool, str]:
        """Validate Flow task config against SkyPilot adapter constraints."""
        is_valid, error = super().validate_task_config(config)
        if not is_valid:
            return is_valid, error

        try:
            self._validate_launch_configuration(config)
        except SkyPilotProviderError as exc:
            return False, str(exc)

        return True, ""

    # =========================================================================
    # TASK LIFECYCLE
    # =========================================================================

    def submit_task(
        self,
        instance_type: str,
        config: TaskConfig,
        volume_ids: list[str] | None = None,
        allow_partial_fulfillment: bool = False,
        chunk_size: int | None = None,
        dryrun: bool = False,
    ) -> Task:
        """Submit a task for execution via SkyPilot.

        Args:
            instance_type: GPU instance type (e.g., "A100", "H100").
            config: Task configuration.
            volume_ids: Optional volume IDs to attach (mounted at /data/<volume_name>).
            allow_partial_fulfillment: Whether to allow partial resource allocation.
            chunk_size: Chunk size for partial fulfillment.
            dryrun: If True, validate through SkyPilot without launching.

        Returns:
            Task object with SkyPilot execution details.
        """
        self._validate_launch_configuration(config)

        task_id = f"sky-{uuid.uuid4().hex[:8]}"
        cluster_name = f"{self._sky_config.cluster_prefix}-{task_id}"
        launch_policy = self._resolve_launch_policy(config)

        # Parse GPU requirements from instance type
        accelerators = self._parse_accelerators(instance_type)

        # Resolve volume names for bridge
        volume_names = self._resolve_volume_names(volume_ids)

        # Create initial task object
        task = Task(
            task_id=task_id,
            name=config.name,
            status=TaskStatus.PENDING,
            config=config,
            created_at=datetime.now(timezone.utc),
            instance_type=instance_type,
            num_instances=config.num_instances,
            region=launch_policy.task_region,
            cost_per_hour="$0.00",  # Updated after launch
        )

        # Store task only for actual launches (not dryrun)
        if not dryrun:
            with self._lock:
                self._tasks[task_id] = task

        try:
            # Launch via bridge (or validate if dryrun)
            launch_result = self._bridge.launch_task(
                config=config,
                cloud=None,
                clouds=launch_policy.clouds,
                accelerators=accelerators,
                region=None,
                region_by_cloud=launch_policy.region_by_cloud,
                use_spot=self._sky_config.use_spot,
                cluster_name=cluster_name,
                volume_names=volume_names,
                dryrun=dryrun,
            )

            if dryrun:
                # Return validated task without storing
                task = task.copy_with_updates(
                    status=TaskStatus.PENDING,
                    message="Validated successfully (dryrun)",
                )
                logger.info("Validated task config for %s (dryrun)", task_id)
                return task

            # Store SkyPilot job_id for later status/log queries
            job_id = launch_result.job_id if launch_result else None

            # Update task with launch result
            task = task.copy_with_updates(
                status=TaskStatus.RUNNING,
                started_at=datetime.now(timezone.utc),
                instances=[cluster_name],
                provider_metadata=self._build_provider_metadata(
                    cluster_name=cluster_name,
                    job_id=job_id,
                    clouds=launch_policy.clouds,
                    region_by_cloud=launch_policy.region_by_cloud,
                ),
            )
            with self._lock:
                self._tasks[task_id] = task

            # Persist to state store for recovery across restarts
            self._state_store.put(
                TaskRecord(
                    task_id=task_id,
                    cluster_name=cluster_name,
                    name=config.name,
                    instance_type=instance_type,
                    created_at=task.created_at.isoformat(),
                    job_id=job_id,
                    num_instances=config.num_instances,
                    cloud=launch_policy.clouds[0] if len(launch_policy.clouds) == 1 else None,
                    region=task.region,
                    config_snapshot={
                        "name": config.name,
                        "command": config.command,
                        "instance_type": getattr(config, "instance_type", instance_type),
                        "region": getattr(config, "region", None),
                    },
                )
            )

            logger.info("Launched task %s on cluster %s", task_id, cluster_name)
            return task

        except SkyPilotProviderError as e:
            # Update task with failure
            task = task.copy_with_updates(
                status=TaskStatus.FAILED,
                message=str(e),
            )
            if not dryrun:
                with self._lock:
                    self._tasks[task_id] = task
            raise

    def get_task(self, task_id: str) -> Task:
        """Get task by ID.

        Args:
            task_id: Task identifier.

        Returns:
            Task object.

        Raises:
            TaskNotFoundError: If task doesn't exist.
        """
        self._ensure_recovered()
        if task_id not in self._tasks:
            raise TaskNotFoundError(f"Task {task_id} not found")
        return self._tasks[task_id]

    def get_task_status(self, task_id: str) -> TaskStatus:
        """Get current task status.

        Args:
            task_id: Task identifier.

        Returns:
            Current task status.
        """
        task = self.get_task(task_id)

        # If task has a cluster, check its live status
        if task.instances:
            cluster_name = task.instances[0]
            cluster_info = self._bridge.get_cluster_status(cluster_name)
            if cluster_info:
                status = self._resolve_task_status(task_id, task, cluster_info)
                if status != task.status:
                    updates: dict[str, Any] = {"status": status}
                    if is_terminal_status(status):
                        updates["completed_at"] = datetime.now(timezone.utc)
                    task = task.copy_with_updates(**updates)
                    with self._lock:
                        self._tasks[task_id] = task
            elif not is_terminal_status(task.status):
                task = task.copy_with_updates(
                    status=TaskStatus.COMPLETED,
                    completed_at=datetime.now(timezone.utc),
                )
                with self._lock:
                    self._tasks[task_id] = task

        return task.status

    def list_tasks(
        self,
        status: str | None = None,
        limit: int = 100,
        force_refresh: bool = False,
    ) -> list[Task]:
        """List tasks with optional filtering.

        Args:
            status: Filter by status.
            limit: Maximum tasks to return.
            force_refresh: Whether to force refresh from SkyPilot.

        Returns:
            List of tasks.
        """
        self._ensure_recovered()
        if force_refresh:
            self._refresh_cluster_states(raise_on_error=True)

        tasks = list(self._tasks.values())

        if status:
            tasks = [t for t in tasks if t.status.value == status]

        # Sort by creation time (newest first)
        tasks.sort(key=lambda t: t.created_at, reverse=True)

        return tasks[:limit]

    def stop_task(self, task_id: str) -> bool:
        """Stop a running task.

        Args:
            task_id: Task to stop.

        Returns:
            True if task was stopped successfully.

        Raises:
            SkyPilotProviderError: If cluster termination fails.
        """
        task = self.get_task(task_id)

        if task.status not in [TaskStatus.PENDING, TaskStatus.RUNNING]:
            return True  # Already stopped

        # Terminate the cluster (raises on failure, so state update
        # is only reached on success)
        if task.instances:
            cluster_name = task.instances[0]
            self._bridge.terminate_cluster(cluster_name)

        task = task.copy_with_updates(
            status=TaskStatus.CANCELLED,
            completed_at=datetime.now(timezone.utc),
            message="Cancelled by user",
        )
        with self._lock:
            self._tasks[task_id] = task
        self._state_store.remove(task_id)
        return True

    def cancel_task(self, task_id: str) -> None:
        """Cancel a task.

        Args:
            task_id: Task identifier.
        """
        self.stop_task(task_id)

    # =========================================================================
    # REMOTE OPERATIONS (SSH)
    # =========================================================================

    def get_remote_operations(self) -> SkyPilotRemoteOperations:
        """Return remote operations interface for SkyPilot SSH.

        SkyPilot manages SSH keys and config automatically. The returned
        object delegates to SkyPilot's auto-generated SSH config.

        Returns:
            SkyPilotRemoteOperations instance.
        """
        return SkyPilotRemoteOperations(self)

    def resolve_ssh_endpoint(self, task_id: str, node: int | None = None) -> tuple[str, int]:
        """Resolve SSH endpoint for a SkyPilot cluster.

        Queries live cluster status from SkyPilot for the IP address.
        Also parses the SSH user from SkyPilot's generated SSH config
        and updates the internal task record so downstream consumers
        (handshake checks, open_shell) use the correct user.

        Args:
            task_id: Task identifier.
            node: Node index (unused for single-node clusters).

        Returns:
            Tuple of (host, port).

        Raises:
            SkyPilotProviderError: If endpoint cannot be resolved.
        """
        task = self.get_task(task_id)
        if not task.instances:
            raise SkyPilotProviderError(f"No cluster associated with task {task_id}")
        cluster_name = task.instances[0]
        cluster_info = self._bridge.get_cluster_status(cluster_name)
        if not cluster_info or not cluster_info.ip_address:
            raise SkyPilotProviderError(f"SSH endpoint not available for cluster {cluster_name}")

        # Parse SSH user from SkyPilot's generated config so downstream
        # handshake probes use the right user (GCP=gcpuser, AWS=ubuntu, etc.)
        ssh_user = self._parse_ssh_user(cluster_name)
        if ssh_user:
            task = task.copy_with_updates(ssh_user=ssh_user)
            with self._lock:
                self._tasks[task_id] = task

        return (cluster_info.ip_address, 22)

    def get_task_ssh_connection_info(self, task_id: str, task: Any = None) -> Path | None:
        """Return SkyPilot SSH key path by parsing generated SSH config.

        Args:
            task_id: Task identifier.
            task: Optional pre-fetched task to avoid redundant lookup.

        Returns:
            Path to the SSH private key, or None if unavailable.
        """
        t = task or self.get_task(task_id)
        if not t.instances:
            return None
        return self._parse_ssh_identity_file(t.instances[0])

    def pause_task(self, task_id: str) -> bool:
        """Pause a running task.

        SkyPilot supports stopping clusters, which preserves state.

        Args:
            task_id: Task to pause.

        Returns:
            True if task was paused successfully.

        Raises:
            SkyPilotProviderError: If cluster stop fails.
        """
        task = self.get_task(task_id)

        if task.status != TaskStatus.RUNNING:
            return False

        if not task.instances:
            return False

        cluster_name = task.instances[0]
        # Raises on failure -- state update only reached on success
        self._bridge.stop_cluster(cluster_name)

        task = task.copy_with_updates(status=TaskStatus.PAUSED)
        with self._lock:
            self._tasks[task_id] = task
        return True

    def unpause_task(self, task_id: str) -> bool:
        """Unpause a paused task.

        Args:
            task_id: Task to unpause.

        Returns:
            True if task was unpaused successfully.

        Raises:
            SkyPilotProviderError: If cluster start fails.
        """
        task = self.get_task(task_id)

        if task.status != TaskStatus.PAUSED:
            return False

        if not task.instances:
            return False

        cluster_name = task.instances[0]
        # Raises on failure -- state update only reached on success
        self._bridge.start_cluster(cluster_name)

        task = task.copy_with_updates(status=TaskStatus.RUNNING)
        with self._lock:
            self._tasks[task_id] = task
        return True

    # =========================================================================
    # LOGS
    # =========================================================================

    def get_task_logs(
        self,
        task_id: str,
        tail: int = 100,
        log_type: str = "stdout",
        node: int | None = None,
    ) -> str:
        """Get task logs.

        Args:
            task_id: Task identifier.
            tail: Number of lines to return from end.
            log_type: Type of logs (stdout/stderr).
            node: Node index for multi-node tasks (unused; SkyPilot
                does not separate logs per node).

        Returns:
            Log content as string.
        """
        task = self.get_task(task_id)

        if not task.instances:
            return "No cluster associated with task"

        cluster_name = task.instances[0]
        job_id = self._get_task_job_id(task_id, task)

        try:
            logs = self._bridge.get_logs(cluster_name, job_id=job_id)
            if tail:
                lines = logs.splitlines()
                return "\n".join(lines[-tail:])
            return logs
        except ClusterNotFoundError:
            return "Cluster not found - task may have completed"

    def stream_task_logs(
        self,
        task_id: str,
        log_type: str = "stdout",
        follow: bool = True,
        tail: int = 10,
    ) -> Iterable[str]:
        """Stream task logs.

        Args:
            task_id: Task identifier.
            log_type: Type of logs.
            follow: Whether to follow logs.
            tail: Initial lines to return.

        Yields:
            Log lines as they become available.
        """
        task = self.get_task(task_id)

        if not task.instances:
            yield "No cluster associated with task"
            return

        cluster_name = task.instances[0]
        job_id = self._get_task_job_id(task_id, task)
        yield from self._bridge.stream_logs(cluster_name, job_id=job_id)

    # =========================================================================
    # INSTANCE DISCOVERY
    # =========================================================================

    def find_instances(
        self,
        requirements: dict[str, Any],
        limit: int = 10,
    ) -> list[AvailableInstance]:
        """Find available instances matching requirements.

        Args:
            requirements: Dictionary of requirements (gpu_type, gpu_count, etc.).
            limit: Maximum number of instances to return.

        Returns:
            List of available instances sorted by price.
        """
        from flow.sdk.models import AvailableInstance

        gpu_type = requirements.get("gpu_type")
        gpu_count = requirements.get("gpu_count", 1)
        use_spot = requirements.get("use_spot", self._sky_config.use_spot)

        options = self._bridge.list_gpu_options(
            gpu_type=gpu_type,
            gpu_count=gpu_count,
            clouds=self._get_enabled_clouds(),
            use_spot=use_spot,
        )

        instances = []
        for opt in options[:limit]:
            instances.append(
                AvailableInstance(
                    allocation_id=f"{opt['provider']}-{opt['region']}-{opt['instance_type']}",
                    instance_type=opt["instance_type"],
                    region=opt["region"],
                    price_per_hour=opt["price"],
                    status="available",
                    gpu_type=opt.get("gpu_type"),
                    gpu_count=opt.get("gpu_count"),
                    cpu_count=opt.get("cpu_count"),
                    memory_gb=opt.get("memory_gb"),
                    available_quantity=None,
                )
            )

        return instances

    # =========================================================================
    # VOLUMES (Cloud Storage via SkyPilot)
    # =========================================================================

    def create_volume(
        self,
        size_gb: int,
        name: str | None = None,
        interface: str = "block",
        region: str | None = None,
    ) -> Volume:
        """Create a new cloud storage volume.

        SkyPilot uses cloud object storage (GCS, S3, Azure Blob) which
        persists independently of clusters and can be mounted to any task.

        Args:
            size_gb: Requested size in GB (informational for cloud storage).
            name: Optional volume name.
            interface: Storage interface type (ignored for cloud storage).
            region: Target region for bucket location.

        Returns:
            Volume object with cloud storage details.
        """
        return self._storage_manager.create_volume(
            size_gb=size_gb,
            name=name,
            region=region,
        )

    def delete_volume(self, volume_id: str) -> bool:
        """Delete a cloud storage volume.

        Args:
            volume_id: Volume identifier.

        Returns:
            True if deleted successfully.
        """
        return self._storage_manager.delete_volume(volume_id)

    def list_volumes(self, limit: int = 100) -> list[Volume]:
        """List cloud storage volumes.

        Args:
            limit: Maximum volumes to return.

        Returns:
            List of Volume objects.
        """
        return self._storage_manager.list_volumes(limit=limit)

    def get_volume(self, volume_id: str) -> Volume | None:
        """Get a volume by ID.

        Args:
            volume_id: Volume identifier.

        Returns:
            Volume object or None if not found.
        """
        return self._storage_manager.get_volume(volume_id)

    def is_volume_id(self, identifier: str) -> bool:
        """Check if identifier is a volume ID.

        Args:
            identifier: String to check.

        Returns:
            True if it's a volume ID.
        """
        return self._storage_manager.is_volume_id(identifier)

    # =========================================================================
    # PRIVATE HELPERS
    # =========================================================================

    def _validate_launch_configuration(self, config: TaskConfig) -> None:
        """Reject unsupported SkyPilot task configuration explicitly."""
        uses_reservations = (
            config.allocation_mode == "reserved"
            or config.reservation_id is not None
            or config.scheduled_start_time is not None
            or config.reserved_duration_hours is not None
        )
        if uses_reservations:
            raise SkyPilotProviderError(
                "Flow's SkyPilot adapter does not implement reservation-backed "
                "launches. Remove reservation-specific fields or use a provider "
                "that supports reservations."
            )

        self._resolve_launch_policy(config)

    def _resolve_launch_policy(self, config: TaskConfig) -> _LaunchPolicy:
        """Resolve the allowed cloud set and per-cloud region policy."""
        enabled_clouds = self._get_enabled_clouds()
        explicit_region = getattr(config, "region", None)

        if explicit_region is not None and len(enabled_clouds) != 1:
            raise SkyPilotProviderError(
                "TaskConfig.region requires exactly one enabled SkyPilot cloud. "
                f"Enabled clouds: {', '.join(enabled_clouds)}."
            )

        region_by_cloud: dict[str, str] = {}
        if explicit_region is not None:
            region_by_cloud[enabled_clouds[0]] = explicit_region
            task_region = explicit_region
        else:
            for cloud in enabled_clouds:
                default_region = self._sky_config.get_default_region_for_cloud(cloud)
                if default_region:
                    region_by_cloud[cloud] = default_region
            task_region = (
                region_by_cloud.get(enabled_clouds[0], "auto")
                if len(enabled_clouds) == 1
                else "auto"
            )

        return _LaunchPolicy(
            clouds=enabled_clouds,
            region_by_cloud=region_by_cloud,
            task_region=task_region,
        )

    def _get_enabled_clouds(self) -> list[str]:
        """Return validated enabled clouds or raise a provider error."""
        try:
            enabled_clouds = self._sky_config.get_enabled_clouds()
        except ValueError as exc:
            raise SkyPilotProviderError(str(exc)) from exc

        if not enabled_clouds:
            raise SkyPilotProviderError(
                "SkyPilot has no enabled clouds after applying clouds/disabled_clouds "
                "configuration."
            )
        return enabled_clouds

    def _build_provider_metadata(
        self,
        *,
        cluster_name: str,
        job_id: int | None,
        clouds: list[str],
        region_by_cloud: dict[str, str],
    ) -> dict[str, Any]:
        """Build provider metadata stored on Flow tasks."""
        metadata: dict[str, Any] = {
            "skypilot_cluster_name": cluster_name,
            "skypilot_allowed_clouds": list(clouds),
        }
        if job_id is not None:
            metadata["sky_job_id"] = job_id
        if region_by_cloud:
            metadata["skypilot_region_by_cloud"] = dict(region_by_cloud)
        return metadata

    def _get_task_job_id(self, task_id: str, task: Task | None = None) -> int | None:
        """Look up the persisted SkyPilot job id for a task."""
        task = task or self._tasks.get(task_id)
        if task is not None:
            job_id = task.provider_metadata.get("sky_job_id")
            if isinstance(job_id, int):
                return job_id

            message = task.message or ""
            if message.startswith("sky_job_id="):
                _, _, raw_job_id = message.partition("=")
                if not raw_job_id.isdigit():
                    raise SkyPilotProviderError(
                        f"Task {task_id} has invalid legacy sky_job_id message: {message!r}"
                    )
                return int(raw_job_id)

        record = self._state_store.get(task_id)
        if record is not None and isinstance(record.job_id, int):
            return record.job_id
        return None

    def _resolve_task_status(
        self,
        task_id: str,
        task: Task,
        cluster_info: Any,
    ) -> TaskStatus:
        """Prefer SkyPilot job state over cluster state when job_id is known."""
        job_id = self._get_task_job_id(task_id, task)
        if job_id is None:
            return cluster_info.status

        job_info = self._bridge.get_job_status(cluster_info.name, job_id)
        if job_info is None:
            logger.info(
                "SkyPilot job %s for task %s is no longer present on cluster %s; "
                "treating task as completed.",
                job_id,
                task_id,
                cluster_info.name,
            )
            return TaskStatus.COMPLETED
        return job_info.status

    def _resolve_recovered_task_status(
        self,
        record: TaskRecord,
        cluster_info: Any,
    ) -> TaskStatus:
        """Resolve recovered task status from persisted job_id and live cluster."""
        if record.job_id is None:
            return cluster_info.status

        job_info = self._bridge.get_job_status(cluster_info.name, record.job_id)
        if job_info is None:
            logger.info(
                "SkyPilot job %s for recovered task %s is no longer present on cluster %s; "
                "treating task as completed.",
                record.job_id,
                record.task_id,
                cluster_info.name,
            )
            return TaskStatus.COMPLETED
        return job_info.status

    def _parse_accelerators(self, instance_type: str) -> dict[str, int] | None:
        """Parse instance type into SkyPilot accelerators dict.

        Delegates to gpu_constants.parse_instance_type for consistent
        normalization across the SkyPilot adapter.

        Args:
            instance_type: Instance type string (e.g. "8xH100", "a100:4",
                "cpu" for CPU-only).

        Returns:
            Dict mapping normalized GPU type to count, or None for CPU-only.
        """
        s = instance_type.strip()
        if not s:
            return {"GPU": 1}

        # CPU-only instances (no accelerators)
        if s.lower() == "cpu":
            return None

        # Handle colon format ("H100:8") which parse_instance_type doesn't cover
        if ":" in s:
            parts = s.split(":", 1)
            if len(parts) == 2 and parts[1].strip().isdigit():
                gpu_type = normalize_gpu_name(parts[0].strip())
                count = int(parts[1].strip())
                return {gpu_type: count}

        gpu_type, count = _parse_gpu_spec(s)
        return {gpu_type: count}

    def _parse_ssh_user(self, cluster_name: str) -> str | None:
        """Parse SSH user from SkyPilot's generated SSH config.

        Args:
            cluster_name: SkyPilot cluster name.

        Returns:
            SSH username, or None if config not found.
        """
        return _read_sky_ssh_directive(cluster_name, "User")

    def _parse_ssh_identity_file(self, cluster_name: str) -> Path | None:
        """Parse SSH identity file from SkyPilot's generated SSH config.

        Args:
            cluster_name: SkyPilot cluster name.

        Returns:
            Path to SSH key, or None if unavailable.
        """
        value = _read_sky_ssh_directive(cluster_name, "IdentityFile")
        if value is None:
            return None
        key_path = Path(value).expanduser()
        return key_path if key_path.exists() else None

    def _resolve_volume_names(
        self,
        volume_ids: list[str] | None,
    ) -> list[tuple[str, str]] | None:
        """Resolve volume IDs to (storage_name, mount_path) pairs.

        The bridge handles all sky.Storage construction internally to prevent
        sky types from leaking into the provider layer.

        Args:
            volume_ids: List of volume IDs to mount.

        Returns:
            List of (storage_name, mount_path) tuples, or None if no volumes.
        """
        if not volume_ids:
            return None

        result: list[tuple[str, str]] = []

        for volume_id in volume_ids:
            volume = self._storage_manager.get_volume(volume_id)
            if volume is None:
                raise SkyPilotProviderError(
                    f"Volume {volume_id} not found. Cannot mount non-existent volume."
                )

            storage_name = volume.name or volume_id
            mount_path = f"/data/{storage_name}"
            result.append((storage_name, mount_path))
            logger.info("Mounting volume %s at %s", volume_id, mount_path)

        return result if result else None

    def _refresh_cluster_states(self, raise_on_error: bool = False) -> None:
        """Refresh task states from SkyPilot clusters.

        Args:
            raise_on_error: If True, propagate bridge errors to caller.
                If False, log and continue with stale state.
        """
        try:
            clusters = self._bridge.list_clusters()
            cluster_map = {c.name: c for c in clusters}

            with self._lock:
                for task_id, task in list(self._tasks.items()):
                    if task.instances:
                        cluster_name = task.instances[0]
                        if cluster_name in cluster_map:
                            cluster = cluster_map[cluster_name]
                            new_status = self._resolve_task_status(task_id, task, cluster)
                            if new_status != task.status:
                                updates: dict[str, Any] = {"status": new_status}
                                if is_terminal_status(new_status):
                                    updates["completed_at"] = datetime.now(timezone.utc)
                                self._tasks[task_id] = task.copy_with_updates(**updates)
                        elif not is_terminal_status(task.status):
                            # SkyPilot confirmed the cluster is gone.
                            self._tasks[task_id] = task.copy_with_updates(
                                status=TaskStatus.COMPLETED,
                                completed_at=datetime.now(timezone.utc),
                            )

        except SkyPilotProviderError:
            if raise_on_error:
                raise
            logger.error("Failed to refresh cluster states from SkyPilot")

    def _ensure_recovered(self) -> None:
        """Lazily recover tasks on first access."""
        if self._recovered:
            return
        self._recovered = True
        self._recover_tasks()

    def _recover_tasks(self) -> None:
        """Recover task state from persisted records and live SkyPilot clusters.

        Strategy:
        1. Load task records from state store (disk).
        2. Query SkyPilot for live cluster states.
        3. Reconcile: create Task objects from records + live status.
        4. If SkyPilot confirmed cluster is gone, mark COMPLETED and prune.
        5. If SkyPilot is unreachable, assume RUNNING (conservative).
        """
        records = self._state_store.all_records()
        if not records:
            return

        sky_reachable = True
        try:
            clusters = self._bridge.list_clusters()
            cluster_map = {c.name: c for c in clusters}
        except SkyPilotProviderError:
            logger.warning("Could not query SkyPilot during task recovery")
            cluster_map = {}
            sky_reachable = False

        pruned: list[str] = []
        with self._lock:
            for record in records:
                cluster = cluster_map.get(record.cluster_name)
                if cluster:
                    status = self._resolve_recovered_task_status(record, cluster)
                elif sky_reachable:
                    # SkyPilot responded but cluster is gone — prune from store
                    status = TaskStatus.COMPLETED
                    pruned.append(record.task_id)
                else:
                    # SkyPilot unreachable -- conservatively assume still running
                    status = TaskStatus.RUNNING

                task = Task(
                    task_id=record.task_id,
                    name=record.name,
                    status=status,
                    config=TaskConfig(
                        name=record.config_snapshot.get("name", record.name),
                        command=record.config_snapshot.get("command", ""),
                        instance_type=record.instance_type,
                        region=record.config_snapshot.get("region", record.region),
                    ),
                    created_at=datetime.fromisoformat(record.created_at),
                    instance_type=record.instance_type,
                    num_instances=record.num_instances,
                    instances=[record.cluster_name],
                    region=cluster.region if cluster else (record.region or "auto"),
                    cost_per_hour="$0.00",
                    provider_metadata=self._build_provider_metadata(
                        cluster_name=record.cluster_name,
                        job_id=record.job_id,
                        clouds=[],
                        region_by_cloud={},
                    ),
                )
                self._tasks[record.task_id] = task

        # Prune completed tasks whose clusters are confirmed gone
        for task_id in pruned:
            self._state_store.remove(task_id)

        logger.info("Recovered %s task(s) from state store", len(records))
