"""Volume preparation service.

Resolves/creates volumes declared in TaskConfig and returns updated specs and
resolved IDs. Centralizes logic used by submission/storage flows to keep them
thin and DRY, and to enable consistent validation behavior.
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Any

from flow.errors import APIError

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.mithril.domain.volumes import VolumeService
    from flow.sdk.models import TaskConfig
    from flow.sdk.models.volume import Volume

logger = logging.getLogger(__name__)


def resolve_volume(
    name: str,
    existing_volumes: list[Volume],
    *,
    region: str | None = None,
) -> Volume | None:
    """Resolve a volume by exact name from a pre-fetched list.

    Resolution order:
    1. If region specified, prefer exact name match in that region.
    2. If no in-region match, return any out-of-region match (allows callers
       to distinguish "doesn't exist" from "wrong region").

    Returns the matched Volume, or None if no match exists.
    """
    matches = [v for v in existing_volumes if v.name == name]
    if not matches:
        return None

    if region is not None:
        in_region = [v for v in matches if v.region == region]
        if in_region:
            if len(in_region) == 1:
                return in_region[0]
            # Multiple in-region matches -- ambiguous, caller should handle
            return None
        # Return first out-of-region match for diagnostic messaging
        return matches[0]

    # No region filter: return single match, or None if ambiguous
    if len(matches) == 1:
        return matches[0]
    return None


def _region_qualified_name(base_name: str, region: str) -> str:
    """Append a region slug to a volume name to avoid cross-region conflicts.

    Example: _region_qualified_name("model-cache", "us-central2-a")
             -> "model-cache-uscentral2a"
    """
    slug = re.sub(r"[^a-z0-9]", "", region.lower())[:12]
    return f"{base_name}-{slug}"


def _create_or_resolve_existing(
    volumes: VolumeService,
    project_id: str,
    name: str,
    spec: Any,
    region: str,
) -> str:
    """Create a volume, or resolve it if it already exists (409 conflict).

    Volume names are unique per-project. A 409 means the volume was created
    between our list call and this create call (stale cache or concurrent
    request). Rather than failing, re-fetch and resolve the existing volume.
    """
    try:
        created = volumes.create_volume(
            project_id=project_id,
            size_gb=spec.size_gb,
            name=name,
            interface=spec.interface.value,
            region=region,
        )
        return created.id
    except APIError as exc:
        if exc.status_code != 409:
            raise
        logger.info(
            "Volume '%s' already exists (409); resolving existing volume",
            name,
        )
        fresh = volumes.list_volumes(project_id=project_id, region=None, limit=1000)
        existing = resolve_volume(name, fresh)
        if existing:
            return existing.id
        raise ValueError(
            f"Volume '{name}' creation returned 409 but could not be "
            f"resolved. This may indicate a transient API issue."
        ) from exc


class VolumePreparationService:
    """Resolves and ensures volumes exist before bidding.

    Responsibilities:
    - Resolve by ID or name (exact match in region)
    - Auto-create when create_if_missing is set
    - Provide actionable diagnostics on region mismatches
    - Return updated TaskConfig volume specs and list of resolved IDs
    """

    @staticmethod
    def resolve_and_ensure_volumes(
        volumes: VolumeService,
        config: TaskConfig,
        *,
        region: str,
        project_id: str,
        cached_volumes: list[Any] | None = None,
    ) -> tuple[list[Any], list[str], list[Any]]:
        """Resolve or create volumes declared in the config.

        Args:
            volumes: Volume service for listing/creating volumes.
            config: TaskConfig containing ``volumes`` specs.
            region: Target region for volumes.
            project_id: Project identifier.
            cached_volumes: Pre-fetched volume list to avoid redundant API calls.
                When provided, skips the internal list_volumes() call.

        Returns:
            (updated_volume_specs, resolved_volume_ids, all_volumes) -- the
            third element is the fetched (or provided) volume list so callers
            can reuse it without an additional API round-trip.

        Raises:
            ValueError: When a volume cannot be resolved and
                create_if_missing is False, with actionable diagnostics.
        """
        resolved_ids: list[str] = []
        updated_specs = list(config.volumes)

        if not updated_specs:
            all_volumes = cached_volumes if cached_volumes is not None else []
            return updated_specs, resolved_ids, all_volumes

        # Fetch ALL volumes once upfront; derive per-region subset locally.
        # This eliminates per-volume API calls (was O(N) list_volumes calls).
        all_volumes = cached_volumes if cached_volumes is not None else volumes.list_volumes(
            project_id=project_id, region=None, limit=1000
        )
        in_region = [v for v in all_volumes if v.region == region]

        for i, spec in enumerate(updated_specs):
            # Already have an ID -- use it directly
            if spec.volume_id:
                resolved_ids.append(spec.volume_id)
                continue

            vol_name = spec.name
            if not vol_name:
                raise ValueError(f"Volume spec at index {i} has neither volume_id nor name")

            # Try in-region name match
            match = resolve_volume(vol_name, in_region, region=region)

            if match and match.region == region:
                resolved_ids.append(match.id)
                continue

            # Not found in region -- try auto-create
            if spec.create_if_missing:
                # Volume names are unique per-project (not per-region).
                # Check all regions to avoid a 409 conflict if the name
                # already exists elsewhere (e.g., user switched GPU types
                # which changed the target region).
                cross_region = resolve_volume(vol_name, all_volumes)

                if cross_region:
                    # Name taken in another region. Use a region-qualified
                    # name so the caller still gets a volume without manual
                    # intervention.
                    qualified = _region_qualified_name(vol_name, region)
                    existing_qualified = resolve_volume(
                        qualified,
                        all_volumes,
                        region=region,
                    )
                    if existing_qualified and existing_qualified.region == region:
                        resolved_ids.append(existing_qualified.id)
                        continue
                    logger.info(
                        "Volume '%s' exists in %s; creating '%s' in %s",
                        vol_name,
                        cross_region.region,
                        qualified,
                        region,
                    )
                    vol_id = _create_or_resolve_existing(
                        volumes,
                        project_id,
                        qualified,
                        spec,
                        region,
                    )
                    resolved_ids.append(vol_id)
                    continue

                vol_id = _create_or_resolve_existing(
                    volumes,
                    project_id,
                    vol_name,
                    spec,
                    region,
                )
                resolved_ids.append(vol_id)
                continue

            # Not found, not auto-creating -- give a diagnostic error.
            # Check all regions for a helpful message (already cached).
            cross_region = resolve_volume(vol_name, all_volumes)

            if cross_region:
                raise ValueError(
                    f"Volume '{vol_name}' exists in {cross_region.region} "
                    f"but task targets {region}.\n\n"
                    "Solutions:\n"
                    f"  1. Create a volume in {region}:\n"
                    f"     flow volume create --size {cross_region.size_gb} "
                    f"--name {vol_name} --region {region}\n"
                    f"  2. Set create_if_missing=True to auto-create:\n"
                    f"     VolumeSpec(name='{vol_name}', create_if_missing=True)\n"
                    f"  3. Target {cross_region.region} instead:\n"
                    f"     TaskConfig(..., region='{cross_region.region}')"
                )

            raise ValueError(
                f"Volume '{vol_name}' not found in any region.\n\n"
                "Solutions:\n"
                f"  1. Create it first:\n"
                f"     flow volume create --size {spec.size_gb} --name {vol_name}\n"
                f"  2. Set create_if_missing=True to auto-create at submission:\n"
                f"     VolumeSpec(name='{vol_name}', create_if_missing=True)"
            )

        return updated_specs, resolved_ids, all_volumes
