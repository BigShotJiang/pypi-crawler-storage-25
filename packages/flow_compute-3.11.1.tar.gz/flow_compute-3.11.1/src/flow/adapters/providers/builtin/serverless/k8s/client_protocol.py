"""Protocol definition for the Kubernetes client used by serverless activities.

Defines the narrow interface that Temporal activities depend on when applying
Deployment/Service/ScaledObject manifests. A concrete implementation lives in
`client.py`; tests substitute mocks that satisfy this protocol.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol


@dataclass(frozen=True)
class DeploymentStatus:
    """Snapshot of a Deployment's status subresource.

    Attributes:
        name: Deployment name.
        namespace: K8s namespace.
        replicas: Desired replica count (``spec.replicas``).
        ready_replicas: Ready pod count (``status.readyReplicas``).
        observed_generation: Controller-observed generation.
        generation: ``metadata.generation`` the controller should converge to.
        conditions: Deployment conditions (list of {type, status, reason,
            message}) copied from ``status.conditions``. Useful for diagnosing
            timeouts.
    """

    name: str
    namespace: str
    replicas: int
    ready_replicas: int
    observed_generation: int
    generation: int
    conditions: list[dict[str, str]] = field(default_factory=list)

    @property
    def is_ready(self) -> bool:
        """Return True when the controller has reconciled and all pods ready."""
        return (
            self.replicas > 0
            and self.ready_replicas == self.replicas
            and self.observed_generation >= self.generation
        )


class K8sClient(Protocol):
    """Narrow K8s interface consumed by serverless Temporal activities.

    Implementations must be idempotent where the operation is conceptually
    idempotent (apply, delete-on-missing), and must raise on unexpected
    failures rather than swallowing errors. All methods are synchronous;
    activities run them via ``asyncio.to_thread``.
    """

    def apply_manifests(
        self,
        manifests: list[dict[str, object]],
        namespace: str,
        request_timeout_s: float = 30.0,
    ) -> None:
        """Apply a batch of K8s manifests to the cluster.

        Supports kinds: ``Deployment`` (apps/v1), ``Service`` (v1),
        ``ScaledObject`` (keda.sh/v1alpha1), and ``HTTPScaledObject``
        (http.keda.sh/v1alpha1). Uses server-side apply for standard resources
        and custom-object create/replace for KEDA kinds.

        Args:
            manifests: K8s resource dicts. ``kind`` must be present.
            namespace: Target namespace for resources without an explicit
                ``metadata.namespace`` value.
            request_timeout_s: Per-request timeout.

        Raises:
            ValueError: If a manifest has an unsupported kind or missing name.
            kubernetes.client.exceptions.ApiException: On non-2xx responses
                that are not benign retries.
        """

    def delete_deployment(
        self,
        name: str,
        namespace: str,
        request_timeout_s: float = 30.0,
    ) -> None:
        """Delete a Deployment and its matching Service by name.

        Deletion uses foreground propagation so replica sets and pods are
        reaped before the call returns success. A 404 for either resource is
        not an error.

        Args:
            name: Deployment and Service name (they share one name).
            namespace: K8s namespace.
            request_timeout_s: Per-request timeout.

        Raises:
            kubernetes.client.exceptions.ApiException: On non-404 failures.
        """

    def wait_for_ready(
        self,
        name: str,
        namespace: str,
        timeout_s: int,
        poll_interval_s: float = 2.0,
    ) -> DeploymentStatus:
        """Poll Deployment status until ready or ``timeout_s`` elapses.

        Ready means ``ready_replicas == replicas`` and
        ``observed_generation >= metadata.generation``.

        Args:
            name: Deployment name.
            namespace: K8s namespace.
            timeout_s: Maximum time to wait, in seconds.
            poll_interval_s: Delay between status polls.

        Returns:
            Final ``DeploymentStatus`` when ready.

        Raises:
            TimeoutError: If the Deployment is not ready within ``timeout_s``.
                The message carries the last observed status.
        """

    def get_deployment_status(
        self,
        name: str,
        namespace: str,
        request_timeout_s: float = 30.0,
    ) -> DeploymentStatus:
        """Fetch the current Deployment status.

        Args:
            name: Deployment name.
            namespace: K8s namespace.
            request_timeout_s: Per-request timeout.

        Returns:
            ``DeploymentStatus`` populated from ``status`` and ``spec``.

        Raises:
            kubernetes.client.exceptions.ApiException: On any API failure,
                including 404 (deployment does not exist).
        """
