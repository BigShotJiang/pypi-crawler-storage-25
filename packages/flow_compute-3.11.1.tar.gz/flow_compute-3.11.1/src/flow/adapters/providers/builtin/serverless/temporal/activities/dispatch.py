"""Request dispatch activities for Temporal workflows.

Send serialized function arguments to container endpoints via HTTP
and return serialized results.
"""

from __future__ import annotations

import logging

from flow.adapters.providers.builtin.serverless.temporal.workflows.inputs import (
    DispatchInput,
)

try:
    from temporalio import activity
except ImportError:
    activity = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


async def _post_to_container(
    endpoint: str,
    path: str,
    payload: bytes,
    headers: dict[str, str],
    timeout_seconds: float,
) -> bytes:
    """POST ``payload`` to ``{endpoint}{path}`` and return the response body.

    Raises:
        httpx.HTTPStatusError: On non-2xx responses.
        httpx.TimeoutException: If the request times out.
    """
    import httpx

    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        response = await client.post(
            f"{endpoint}{path}",
            content=payload,
            headers={"Content-Type": "application/octet-stream", **headers},
        )
        response.raise_for_status()
        return response.content


async def _dispatch_request(input: DispatchInput) -> bytes:
    """Send serialized args to container endpoint, return serialized result.

    Makes an HTTP POST to the container's /invoke endpoint with the
    serialized function arguments. The container deserializes, executes,
    and returns the serialized result.
    """
    headers: dict[str, str] = {"X-Flow-Function": input.function_name}
    if input.method:
        headers["X-Flow-Method"] = input.method

    return await _post_to_container(
        input.endpoint,
        "/invoke",
        input.args_serialized,
        headers,
        input.timeout_seconds,
    )


async def _dispatch_batch(
    endpoint: str,
    function_name: str,
    method: str,
    batch_serialized: bytes,
    batch_size: int,
    timeout_seconds: int = 3600,
) -> bytes:
    """Send a batch of inputs to a container for dynamic batching."""
    return await _post_to_container(
        endpoint,
        "/invoke_batch",
        batch_serialized,
        {
            "X-Flow-Function": function_name,
            "X-Flow-Method": method,
            "X-Flow-Batch-Size": str(batch_size),
        },
        timeout_seconds,
    )


if activity is not None:
    dispatch_request = activity.defn(_dispatch_request)
    dispatch_batch = activity.defn(_dispatch_batch)
else:
    dispatch_request = _dispatch_request  # type: ignore[assignment]
    dispatch_batch = _dispatch_batch  # type: ignore[assignment]
