"""SkyPilot provider exceptions.

All SkyPilot-specific exceptions inherit from FlowError.
The bridge maps sky.* exceptions to these Flow exceptions.
"""

from __future__ import annotations

from flow.errors import FlowError

# Cloud-specific URLs for actionable error suggestions.
_QUOTA_URLS: dict[str, str] = {
    "gcp": "https://console.cloud.google.com/iam-admin/quotas",
    "aws": "https://console.aws.amazon.com/servicequotas",
    "azure": "https://portal.azure.com/#view/Microsoft_Azure_Capacity/QuotaMenuBlade",
}

_AUTH_COMMANDS: dict[str, str] = {
    "gcp": "gcloud auth application-default login",
    "aws": "aws configure",
    "azure": "az login",
}


class SkyPilotProviderError(FlowError):
    """Base exception for SkyPilot provider errors."""

    pass


class SkyPilotNotInstalledError(SkyPilotProviderError):
    """SkyPilot package is not installed."""

    def __init__(self, message: str | None = None) -> None:
        super().__init__(
            message or "SkyPilot is not installed. Install with: pip install 'flow[skypilot]'"
        )


class NoPricingOptionsError(SkyPilotProviderError):
    """No instances available within price constraint."""

    def __init__(
        self,
        gpu_type: str | None,
        gpu_count: int,
        max_price: float | None,
        available_options: list | None = None,
        detail: str | None = None,
    ) -> None:
        self.gpu_type = gpu_type
        self.gpu_count = gpu_count
        self.max_price = max_price
        self.available_options = available_options

        if gpu_type and gpu_count > 0:
            resource_desc = f"{gpu_count}x{gpu_type}"
        elif gpu_type:
            resource_desc = gpu_type
        else:
            resource_desc = "requested resources"

        if max_price and available_options:
            cheapest = min(available_options, key=lambda x: x.price)
            msg = (
                f"No {resource_desc} available under ${max_price:.2f}/hr. "
                f"Cheapest option: ${cheapest.price:.2f}/hr on {cheapest.provider}"
            )
        else:
            msg = f"No {resource_desc} available on any enabled cloud"

        if detail:
            msg = f"{msg}. Detail: {detail}"

        suggestions = [
            "Try a different GPU type or count",
            "Try a different region with 'flow submit --region <region>'",
            "Check enabled clouds in ~/.flow/config.yaml",
        ]

        super().__init__(msg, suggestions=suggestions, error_code="RESOURCE_002")


class CloudCredentialsError(SkyPilotProviderError):
    """Cloud credentials are invalid or missing."""

    def __init__(self, cloud: str, message: str) -> None:
        self.cloud = cloud
        auth_cmd = _AUTH_COMMANDS.get(cloud)
        suggestions = [
            f"Authenticate with: {auth_cmd}" if auth_cmd
            else "Configure credentials for your cloud provider",
            "Run 'flow setup' to reconfigure cloud providers",
            "Run 'flow health' to validate your setup",
        ]
        super().__init__(
            f"{cloud} credentials error: {message}",
            suggestions=suggestions,
            error_code="AUTH_002",
        )


class QuotaExceededError(SkyPilotProviderError):
    """Cloud quota exceeded."""

    def __init__(self, cloud: str, resource: str, message: str) -> None:
        self.cloud = cloud
        self.resource = resource
        url = _QUOTA_URLS.get(cloud)
        suggestions = [
            f"Request a quota increase: {url}" if url
            else "Request a quota increase from your cloud provider",
            "Try a different region with 'flow submit --region <region>'",
            "Try spot instances if not already using them",
        ]
        super().__init__(
            f"{cloud} quota exceeded for {resource}: {message}",
            suggestions=suggestions,
            error_code="QUOTA_002",
        )


class ClusterNotFoundError(SkyPilotProviderError):
    """Cluster does not exist."""

    def __init__(self, cluster_name: str) -> None:
        self.cluster_name = cluster_name
        super().__init__(f"Cluster not found: {cluster_name}")


class StorageNotFoundError(SkyPilotProviderError):
    """Storage bucket does not exist."""

    def __init__(self, storage_name: str) -> None:
        self.storage_name = storage_name
        super().__init__(f"Storage not found: {storage_name}")


class ClusterOperationError(SkyPilotProviderError):
    """Cluster lifecycle operation (terminate/stop/start) failed."""

    def __init__(self, cluster_name: str, operation: str, cause: str) -> None:
        self.cluster_name = cluster_name
        self.operation = operation
        super().__init__(f"Failed to {operation} cluster {cluster_name}: {cause}")
