"""Mithril implementation of :class:`ConfigDefaultsProvider`.

Supplies provider-specific fallback values consumed by the application
configuration loader. This module is discovered via the
``flow.config_defaults`` entry-point group so the application layer never
imports Mithril modules directly.
"""

from __future__ import annotations

from flow.adapters.providers.builtin.mithril.core.constants import (
    MITHRIL_API_PRODUCTION_URL,
    MITHRIL_API_STAGING_URL,
)
from flow.protocols.config_defaults import Environment


class MithrilConfigDefaults:
    """Defaults for the Mithril provider."""

    def default_api_url(self, environment: Environment) -> str:
        if environment == "staging":
            return MITHRIL_API_STAGING_URL
        return MITHRIL_API_PRODUCTION_URL


__all__ = ["MithrilConfigDefaults"]
