"""Cluster capabilities metadata for constraint-based selection.

Converts auction response data into ClusterCapabilities objects by merging
runtime auction fields (price, capacity) with optional enrichment metadata
(interconnect bandwidth, topology, compliance).

Enrichment metadata is nullable: None means "unknown", not "absent". The
domain solver handles unknowns explicitly (fail-closed on safety-critical
constraints, pessimistic scoring on performance). This design creates natural
pressure to expose capabilities through the API rather than hardcoding them.

When the API exposes cluster capabilities, replace get_cluster_metadata()
with an API call + TTL cache. The domain solver requires zero changes.
"""

from __future__ import annotations

import re

from flow.domain.constraints.models import ClusterCapabilities

# Verified enrichment metadata for known regions.
#
# Only include data we're confident about. None = unknown.
# This dict should shrink over time as the API exposes these fields.
_KNOWN_METADATA: dict[str, dict] = {
    "eu-central1-a": {
        "compliance_certifications": frozenset({"gdpr", "soc2"}),
    },
    "eu-central1-b": {
        "compliance_certifications": frozenset({"gdpr", "soc2"}),
    },
    "eu-west-1": {
        "compliance_certifications": frozenset({"gdpr", "soc2"}),
    },
}


def get_cluster_metadata(region: str) -> dict:
    """Return enrichment metadata for a region.

    Returns only verified data. Missing keys mean "unknown" -- the caller
    must not treat absence as "none" or fabricate values.
    """
    return _KNOWN_METADATA.get(region, {})


def auction_to_capabilities(
    auction_data: dict,
    region: str,
    instance_type_id: str,
) -> ClusterCapabilities:
    """Convert an auction response dict into ClusterCapabilities.

    Fields from the auction API (price, capacity, interconnect) are always
    populated. Enrichment metadata (compliance, topology) is nullable --
    unknown regions get None, which the solver handles explicitly.

    Args:
        auction_data: Dict from auction API response.
        region: Cluster region identifier.
        instance_type_id: Provider instance type FID for downstream bid submission.

    Returns:
        ClusterCapabilities with nullable metadata fields.
    """
    enrichment = get_cluster_metadata(region)

    price = _parse_price(
        auction_data.get("last_instance_price") or auction_data.get("price") or "$0"
    )

    capacity = int(auction_data.get("capacity") or auction_data.get("available_gpus") or 0)

    # Interconnect: from auction data when available, None otherwise
    internode = auction_data.get("internode_interconnect") or None
    intranode = auction_data.get("intranode_interconnect") or None

    # Bandwidth: from auction data > inferred from interconnect string > None
    bandwidth: float | None = None
    if auction_data.get("interconnect_bandwidth_gbps"):
        bandwidth = float(auction_data["interconnect_bandwidth_gbps"])
    elif internode:
        bandwidth = _infer_bandwidth_from_interconnect(internode)

    # Topology: from auction data > enrichment > None
    topology = auction_data.get("topology") or enrichment.get("topology")

    gpu_type = auction_data.get("gpu_type") or _infer_gpu_type(instance_type_id)

    return ClusterCapabilities(
        cluster_id=f"{region}:{instance_type_id}",
        region=region,
        gpu_type=gpu_type,
        gpu_count=capacity,
        price_per_hour=price,
        available_quantity=capacity,
        instance_type_id=instance_type_id,
        auction_id=auction_data.get("fid") or auction_data.get("auction_id"),
        internode_interconnect=internode,
        intranode_interconnect=intranode,
        interconnect_bandwidth_gbps=bandwidth,
        topology=topology,
        startup_latency_p50_minutes=enrichment.get("startup_latency_p50_minutes"),
        reliability_score=enrichment.get("reliability_score"),
        egress_gbps=enrichment.get("egress_gbps"),
        ingress_gbps=enrichment.get("ingress_gbps"),
        compliance_certifications=enrichment.get("compliance_certifications"),
    )


def _parse_price(price_str: str) -> float:
    """Parse a price string like '$10.00' to float. Returns 0.0 on failure."""
    s = str(price_str).strip()
    if s.startswith("$"):
        s = s[1:]
    s = s.replace(",", "")
    try:
        return float(s)
    except (ValueError, TypeError):
        return 0.0


def _infer_bandwidth_from_interconnect(interconnect: str) -> float | None:
    """Infer bandwidth in Gbps from interconnect description string.

    Returns None if the interconnect type is unrecognized.
    """
    upper = interconnect.upper()
    match = re.search(r"(\d{3,5})", upper)
    if match:
        return float(match.group(1))
    if "INFINIBAND" in upper or upper.startswith("IB"):
        return 3200.0
    if "ETHERNET" in upper:
        return 100.0
    return None


def _infer_gpu_type(instance_type_id: str) -> str:
    """Best-effort GPU type extraction from instance type ID."""
    lower = instance_type_id.lower()
    for gpu in ("h100", "a100", "l40s", "l40", "h200", "b200", "gb200"):
        if gpu in lower:
            return gpu.upper()
    return "unknown"
