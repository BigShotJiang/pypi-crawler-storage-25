"""Dependency injection hub for the serverless provider.

ServerlessContext bundles shared dependencies (Temporal client, K8s client,
image registry URL, namespace) and is passed explicitly to all sub-components.
Analogous to MithrilContext in the VM backend.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from flow.adapters.providers.builtin.serverless.k8s.client_protocol import K8sClient

logger = logging.getLogger(__name__)


@dataclass
class ServerlessContext:
    """Shared state for serverless provider operations.

    All fields are injected at construction time -- no global state or singletons.

    Attributes:
        config: Provider-level configuration dict.
        temporal_client: Connected Temporal client instance.
        k8s_client: Kubernetes API client for deployment management.
            ``None`` only in bootstrap/fallback paths; activities that need it
            fail loudly when it is missing rather than silently skipping.
        image_registry: Container registry URL (e.g. "registry.mithril.ai").
        namespace: K8s namespace for function deployments.
        project_id: Project identifier for resource scoping.
        task_queue: Temporal task queue name for workers.
    """

    config: dict[str, Any]
    temporal_client: Any  # temporalio.client.Client (lazy import)
    k8s_client: K8sClient | None
    image_registry: str
    namespace: str
    project_id: str
    task_queue: str = "flow-serverless"

    @classmethod
    async def build(cls, provider_config: dict[str, Any]) -> ServerlessContext:
        """Construct a ServerlessContext from provider configuration.

        Args:
            provider_config: Dict with keys: temporal_address, k8s_api_url,
                auth_token, image_registry, project_id, and optional
                temporal_namespace, k8s_namespace, task_queue.

        Returns:
            Fully initialized ServerlessContext.

        Raises:
            ImportError: If temporalio is not installed.
            ConnectionError: If Temporal or K8s connections fail.
        """
        try:
            from temporalio.client import Client as TemporalClient
        except ImportError as e:
            raise ImportError(
                "The serverless backend requires 'temporalio'. "
                "Install it with: pip install 'flow-compute[serverless]'"
            ) from e

        temporal_client = await TemporalClient.connect(
            provider_config["temporal_address"],
            namespace=provider_config.get("temporal_namespace", "default"),
        )

        # Reuse existing K8s API client from mithril adapter if available,
        # otherwise accept a generic client.
        k8s_client = provider_config.get("k8s_client")
        if k8s_client is None:
            logger.info(
                "No K8s client provided in config; "
                "K8s operations will fail until a client is configured"
            )

        return cls(
            config=provider_config,
            temporal_client=temporal_client,
            k8s_client=k8s_client,
            image_registry=provider_config["image_registry"],
            namespace=provider_config.get("k8s_namespace", "flow-serverless"),
            project_id=provider_config["project_id"],
            task_queue=provider_config.get("task_queue", "flow-serverless"),
        )
