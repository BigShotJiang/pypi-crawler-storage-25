"""Kubernetes resource generation for serverless function deployments.

Generates Deployment, Service, KEDA ScaledObject, and Ingress manifests
from function configurations.
"""
