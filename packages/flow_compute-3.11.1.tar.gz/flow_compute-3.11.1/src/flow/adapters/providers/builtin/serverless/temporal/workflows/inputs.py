"""Input dataclasses shared between workflows and activities.

Extracted from ``workflows.invocation`` to avoid a circular import: activity
modules need the input types at runtime (for ``@activity.defn`` type-hint
resolution), but ``workflows.invocation`` imports the activity callables.
This module sits below both and depends on neither.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class FunctionInvocationInput:
    """Input to ``FunctionInvocationWorkflow``.

    Attributes:
        function_name: Registered function name.
        image_spec: Serialized Image build steps (dict).
        instance_type: GPU type (e.g. "a100").
        args_serialized: cloudpickle'd (args, kwargs) as bytes.
        volume_ids: Volume IDs to mount in the container.
        timeout_seconds: Max execution time for the function call.
        namespace: K8s namespace for the deployment.
        min_containers: Minimum container replicas (0 = scale-to-zero).
        max_containers: Maximum container replicas.
        scaledown_window: Seconds idle before scale-down.
    """

    function_name: str
    image_spec: dict[str, Any]
    instance_type: str
    args_serialized: bytes = b""
    volume_ids: list[str] = field(default_factory=list)
    timeout_seconds: int = 3600
    namespace: str = "flow-serverless"
    min_containers: int = 0
    max_containers: int = 100
    scaledown_window: int = 60


@dataclass(frozen=True)
class EnsureImageInput:
    """Input for the ``ensure_image`` activity."""

    image_spec: dict[str, Any]
    registry: str
    project: str
    function_name: str


@dataclass(frozen=True)
class EnsureContainerInput:
    """Input for the ``ensure_container_ready`` activity."""

    function_name: str
    image_ref: str
    gpu: str
    namespace: str
    volume_ids: list[str] = field(default_factory=list)
    min_containers: int = 0
    max_containers: int = 100
    scaledown_window: int = 60


@dataclass(frozen=True)
class DispatchInput:
    """Input for the ``dispatch_request`` activity."""

    endpoint: str
    function_name: str
    args_serialized: bytes
    method: str | None = None
    timeout_seconds: int = 3600
