"""GPU name normalization constants for the SkyPilot adapter.

Single source of truth for mapping Flow GPU names to SkyPilot catalog names.
All GPU normalization in the adapter must use this module.
"""

from __future__ import annotations

import re

# Flow GPU name -> SkyPilot catalog name
GPU_NAME_MAP: dict[str, str] = {
    "a100": "A100",
    "a100-40gb": "A100",
    "a100-80gb": "A100-80GB",
    "h100": "H100",
    "h100-80gb": "H100",
    "h200": "H200",
    "l4": "L4",
    "l40s": "L40S",
    "t4": "T4",
    "v100": "V100",
    "a10": "A10",
    "a10g": "A10G",
    "rtx4090": "RTX4090",
    "rtx3090": "RTX3090",
}


def normalize_gpu_name(gpu: str) -> str:
    """Normalize GPU name to SkyPilot catalog format.

    Handles count prefixes (e.g., "8xA100" -> "A100"), lowercase input,
    and memory suffixes (e.g., "a100-80gb" -> "A100-80GB").

    Args:
        gpu: GPU identifier in any format accepted by Flow.

    Returns:
        Normalized GPU name for SkyPilot catalog queries.
    """
    if "x" in gpu.lower():
        parts = gpu.lower().split("x", 1)
        if len(parts) == 2 and parts[0].isdigit():
            gpu = parts[1]

    return GPU_NAME_MAP.get(gpu.lower(), gpu.upper())


def parse_instance_type(instance_type: str) -> tuple[str, int]:
    """Parse Flow instance type to (gpu_type, gpu_count).

    Examples:
        "8xA100" -> ("A100", 8)
        "A100" -> ("A100", 1)
        "4xH100-80GB" -> ("H100-80GB", 4)

    Args:
        instance_type: Instance type string.

    Returns:
        Tuple of (normalized_gpu_type, gpu_count).
    """
    instance_type = instance_type.strip()

    # Handle "8xA100" format
    match = re.match(r"^(\d+)x(.+)$", instance_type, re.IGNORECASE)
    if match:
        count = int(match.group(1))
        gpu_type = normalize_gpu_name(match.group(2))
        return (gpu_type, count)

    return (normalize_gpu_name(instance_type), 1)
