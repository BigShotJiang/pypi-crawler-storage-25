"""GCP provider for direct GCE instance visibility.

Read-only provider that queries the Google Compute Engine API to list
running instances. Enables `flow status` to show raw GCE VMs alongside
Mithril-managed workloads.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterable
from datetime import datetime, timezone
from typing import Any

from flow.adapters.providers.adapter import ProviderAdapter
from flow.adapters.providers.base import PricingModel, ProviderCapabilities
from flow.application.config.config import Config
from flow.errors import TaskNotFoundError
from flow.sdk.models import AvailableInstance, Task, TaskConfig, TaskStatus, Volume

logger = logging.getLogger(__name__)

# GCE status -> Flow TaskStatus
_GCE_STATUS_MAP: dict[str, TaskStatus] = {
    "PROVISIONING": TaskStatus.PENDING,
    "STAGING": TaskStatus.PENDING,
    "RUNNING": TaskStatus.RUNNING,
    "STOPPING": TaskStatus.RUNNING,
    "STOPPED": TaskStatus.PAUSED,
    "SUSPENDED": TaskStatus.PAUSED,
    "SUSPENDING": TaskStatus.PAUSED,
    "TERMINATED": TaskStatus.COMPLETED,
    "REPAIRING": TaskStatus.RUNNING,
}


def _parse_machine_type(machine_type_url: str) -> str:
    """Extract short machine type from full GCE resource URL.

    Example: ".../zones/us-central1-a/machineTypes/n1-standard-4" -> "n1-standard-4"
    """
    return machine_type_url.rsplit("/", 1)[-1] if "/" in machine_type_url else machine_type_url


def _parse_zone(zone_key: str) -> str:
    """Extract zone name from aggregated list key.

    Example: "zones/us-central1-a" -> "us-central1-a"
    """
    return zone_key.split("/", 1)[-1] if "/" in zone_key else zone_key


def _extract_external_ip(instance: Any) -> str | None:
    """Extract the first external IP from instance network interfaces."""
    for iface in getattr(instance, "network_interfaces", None) or []:
        for access in getattr(iface, "access_configs", None) or []:
            ip = getattr(access, "nat_i_p", None)
            if ip:
                return ip
    return None


def _parse_creation_timestamp(timestamp_str: str) -> datetime:
    """Parse GCE creation timestamp (RFC 3339) to datetime."""
    try:
        return datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return datetime.now(timezone.utc)


def _resolve_project() -> str:
    """Resolve GCP project ID from environment or ADC."""
    project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get("GCLOUD_PROJECT")
    if project:
        return project

    try:
        import google.auth

        _, adc_project = google.auth.default()
        if adc_project:
            return adc_project
    except Exception:  # noqa: BLE001
        pass

    raise ValueError(
        "GCP project not found. Set GOOGLE_CLOUD_PROJECT or configure "
        "Application Default Credentials with `gcloud auth application-default login`."
    )


class GCPProvider(ProviderAdapter):
    """Read-only provider for GCE instance visibility.

    Queries the Google Compute Engine API to list running VM instances.
    Supports `flow status` display but not task submission or management.
    """

    def __init__(self, config: Config) -> None:
        capabilities = ProviderCapabilities(
            supports_spot_instances=False,
            supports_on_demand=True,
            supports_multi_node=False,
            supports_attached_storage=False,
            supports_shared_storage=False,
            storage_types=[],
            requires_ssh_keys=False,
            supports_console_access=False,
            pricing_model=PricingModel.FIXED,
            supports_reservations=False,
            supported_regions=[],
            max_instances_per_task=1,
        )
        super().__init__(name="gcp", capabilities=capabilities)
        self.config = config
        self._project = _resolve_project()
        self._client = self._create_client()

    @staticmethod
    def _create_client() -> Any:
        """Create the GCE instances client."""
        try:
            from google.cloud.compute_v1 import InstancesClient

            return InstancesClient()
        except ImportError:
            raise ImportError(
                "google-cloud-compute is required for the GCP provider. "
                "Install it with: pip install flow-compute[gcp]"
            ) from None

    def list_tasks(
        self,
        status: str | None = None,
        limit: int = 100,
        force_refresh: bool = False,
    ) -> list[Task]:
        """List GCE instances as Flow tasks."""
        tasks: list[Task] = []

        try:
            agg_list = self._client.aggregated_list(
                project=self._project,
                max_results=limit * 2,
            )
        except Exception as exc:  # noqa: BLE001
            logger.error("Failed to list GCE instances: %s", exc)
            return []

        for zone_key, scoped_list in agg_list:
            instances = getattr(scoped_list, "instances", None)
            if not instances:
                continue

            zone = _parse_zone(zone_key)
            for instance in instances:
                task = self._instance_to_task(instance, zone)
                if status is not None and task.status.value != status:
                    continue
                tasks.append(task)
                if len(tasks) >= limit:
                    return tasks

        return tasks

    def get_task(self, task_id: str) -> Task:
        """Get a specific GCE instance by task ID."""
        for task in self.list_tasks(limit=500):
            if task.task_id == task_id:
                return task
        raise TaskNotFoundError(task_id)

    def get_task_status(self, task_id: str) -> TaskStatus:
        """Get status of a specific GCE instance."""
        return self.get_task(task_id).status

    def _instance_to_task(self, instance: Any, zone: str) -> Task:
        """Convert a GCE instance protobuf to a Flow Task."""
        gce_status = getattr(instance, "status", "TERMINATED")
        flow_status = _GCE_STATUS_MAP.get(gce_status, TaskStatus.COMPLETED)
        machine_type = _parse_machine_type(getattr(instance, "machine_type", "unknown"))
        instance_id = str(getattr(instance, "id", "0"))
        instance_name = getattr(instance, "name", "unknown")

        return Task(
            task_id=f"gce-{instance_id}",
            name=instance_name,
            status=flow_status,
            config=TaskConfig(
                name=instance_name,
                command="(gce-instance)",
                instance_type=machine_type,
                unique_name=False,
            ),
            created_at=_parse_creation_timestamp(
                getattr(instance, "creation_timestamp", ""),
            ),
            instance_type=machine_type,
            num_instances=1,
            region=zone,
            cost_per_hour=None,
            ssh_host=_extract_external_ip(instance),
            instances=[instance_name],
            provider_metadata={
                "source_provider": "gcp",
                "gce_id": instance_id,
                "gce_status": gce_status,
                "zone": zone,
            },
        )

    # -- Abstract methods with read-only defaults --

    def submit_task(
        self,
        instance_type: str,
        config: TaskConfig,
        volume_ids: list[str] | None = None,
        allow_partial_fulfillment: bool = False,
        chunk_size: int | None = None,
        dryrun: bool = False,
    ) -> Task:
        raise NotImplementedError("GCP provider is read-only. Use `gcloud` to create instances.")

    def stop_task(self, task_id: str) -> bool:
        raise NotImplementedError("GCP provider is read-only. Use `gcloud` to manage instances.")

    def cancel_task(self, task_id: str) -> None:
        raise NotImplementedError("GCP provider is read-only. Use `gcloud` to manage instances.")

    def pause_task(self, task_id: str) -> bool:
        raise NotImplementedError("GCP provider is read-only.")

    def unpause_task(self, task_id: str) -> bool:
        raise NotImplementedError("GCP provider is read-only.")

    def get_task_logs(self, task_id: str, tail: int = 100, log_type: str = "stdout") -> str:
        return "(logs not available for raw GCE instances)"

    def stream_task_logs(
        self,
        task_id: str,
        log_type: str = "stdout",
        follow: bool = True,
        tail: int = 10,
    ) -> Iterable[str]:
        return iter(["(log streaming not available for raw GCE instances)"])

    def find_instances(
        self, requirements: dict[str, Any], limit: int = 10
    ) -> list[AvailableInstance]:
        return []

    def create_volume(
        self,
        size_gb: int,
        name: str | None = None,
        interface: str = "block",
        region: str | None = None,
    ) -> Volume:
        raise NotImplementedError("Volume management not supported by GCP provider.")

    def delete_volume(self, volume_id: str) -> bool:
        raise NotImplementedError("Volume management not supported by GCP provider.")

    def list_volumes(self, limit: int = 100) -> list[Volume]:
        return []
