from __future__ import annotations

import logging
import os
import subprocess
import sys
import time
from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING

from flow.adapters.providers.builtin.mithril.core.constants import (
    EXPECTED_PROVISION_MINUTES,
    SSH_READY_WAIT_SECONDS,
)
from flow.adapters.providers.builtin.mithril.remote.connection_manager import (
    ConnectionDetails,
    SshConnectionManager,
)
from flow.adapters.providers.builtin.mithril.remote.errors import (
    RemoteExecutionError,
    SshConnectionError,
    make_error,
)
from flow.adapters.providers.builtin.mithril.remote.recording import build_recording_command
from flow.adapters.providers.builtin.mithril.remote.utils import new_request_id
from flow.core.ssh import build_ssh_command, is_ssh_ready
from flow.errors import FlowError
from flow.protocols.remote_operations import RemoteOperationsProtocol as IRemoteOperations

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.mithril.provider import MithrilProvider


logger = logging.getLogger(__name__)


class MithrilRemoteOperations(IRemoteOperations):
    """Mithril remote operations via SSH (refactored)."""

    def __init__(self, provider: MithrilProvider):
        self.provider = provider
        self.connection_manager = SshConnectionManager(provider)

    # ------------------------------------------------------------------
    # Command execution
    # ------------------------------------------------------------------
    def execute_command(
        self, task_id: str, command: str, timeout: int | None = None, *, node: int | None = None
    ) -> str:
        request_id = new_request_id("ssh-exec")

        try:
            # Use a shorter readiness window for command exec to reduce latency
            conn = self.connection_manager.establish_connection(
                task_id=task_id,
                request_id=request_id,
                timeout_seconds=(timeout or SSH_READY_WAIT_SECONDS),
                node=node,
                quick_ready=True,
            )
        except SshConnectionError:
            raise
        except (OSError, TimeoutError, ConnectionError) as e:
            raise make_error(f"SSH setup failed: {e!s}", request_id) from e

        # Optional debug: print resolved SSH details for logs/exec paths
        try:
            if os.getenv("FLOW_LOGS_DEBUG") == "1" or os.getenv("FLOW_SSH_DEBUG") == "1":
                logger.debug(
                    "SSH exec details (request_id=%s): user=%s host=%s port=%s key=%s cmd=%r",
                    request_id,
                    getattr(conn, "user", "ubuntu"),
                    getattr(conn, "host", ""),
                    getattr(conn, "port", 22),
                    str(getattr(conn, "key_path", "")),
                    command,
                )
        except (KeyError, TypeError, AttributeError):
            pass

        prefix: list[str] | None = None
        if getattr(conn, "proxyjump", None):
            prefix = ["-J", str(conn.proxyjump)]
        ssh_cmd = build_ssh_command(
            user=conn.user,
            host=conn.host,
            port=conn.port,
            key_path=Path(conn.key_path),
            prefix_args=prefix,
            remote_command=command,
        )

        try:
            result = subprocess.run(
                ssh_cmd,
                capture_output=True,
                text=True,
                timeout=timeout if timeout else None,
            )
            if result.returncode != 0:
                stderr = (result.stderr or "").lower()
                if "permission denied" in stderr or "publickey" in stderr:
                    suggestions = [
                        "Verify the task was launched with your SSH key",
                        "Run: flow ssh-key list (confirm your key on the project)",
                        "Optionally override: MITHRIL_SSH_KEY=/path/to/private/key flow <cmd>",
                    ]
                    raise make_error(
                        (
                            "SSH authentication failed (Permission denied).\n"
                            f"Key used: {Path(conn.key_path).expanduser()!s}"
                        ),
                        request_id,
                        suggestions=suggestions,
                    )
                if "connection closed" in stderr or "connection reset" in stderr:
                    raise make_error(
                        "SSH connection was closed. The instance may still be starting up. "
                        "Please wait a moment and try again.",
                        request_id,
                    )
                raise make_error(f"Command failed: {result.stderr}", request_id)
            # Mark a recent success so subsequent quick ops (preflights) skip heavy waits
            try:
                self.connection_manager.mark_success(getattr(conn, "cache_key", None))
            except (KeyError, TypeError, AttributeError):
                pass
            return result.stdout
        except subprocess.TimeoutExpired as e:
            raise TimeoutError(f"Command timed out after {timeout} seconds") from e
        except RemoteExecutionError:
            raise
        except (OSError, TimeoutError, ConnectionError) as e:
            raise make_error(f"SSH execution failed: {e!s}", request_id) from e

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------
    def stream_command(
        self, task_id: str, command: str, *, node: int | None = None
    ) -> Iterator[str]:
        request_id = new_request_id("ssh-stream")

        try:
            conn = self.connection_manager.establish_connection(
                task_id=task_id,
                request_id=request_id,
                timeout_seconds=SSH_READY_WAIT_SECONDS,
                node=node,
            )
        except SshConnectionError:
            raise
        except (OSError, TimeoutError, ConnectionError) as e:
            raise make_error(f"SSH setup failed: {e!s}", request_id) from e

        # Optional debug: print resolved SSH details for streaming path
        try:
            if os.getenv("FLOW_LOGS_DEBUG") == "1" or os.getenv("FLOW_SSH_DEBUG") == "1":
                logger.debug(
                    "SSH stream details (request_id=%s): user=%s host=%s port=%s key=%s cmd=%r",
                    request_id,
                    getattr(conn, "user", "ubuntu"),
                    getattr(conn, "host", ""),
                    getattr(conn, "port", 22),
                    str(getattr(conn, "key_path", "")),
                    command,
                )
        except (KeyError, TypeError, AttributeError):
            pass

        ssh_cmd = build_ssh_command(
            user=conn.user,
            host=conn.host,
            port=conn.port,
            key_path=Path(conn.key_path),
            remote_command=command,
        )

        process = None
        try:
            process = subprocess.Popen(
                ssh_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )

            if process.stdout is not None:
                for line in iter(process.stdout.readline, ""):
                    yield line.rstrip("\n")

            process.wait()

            if process.returncode != 0 and process.returncode == 255:
                raise make_error("SSH connection error (exit code 255)", request_id)
        except GeneratorExit:
            if process and process.poll() is None:
                process.terminate()
            raise
        except RemoteExecutionError:
            raise
        except (OSError, TimeoutError, ConnectionError) as e:
            raise make_error(f"SSH streaming failed unexpectedly: {e!s}", request_id) from e
        finally:
            if process:
                if process.stdout:
                    process.stdout.close()
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()

    # ------------------------------------------------------------------
    # Interactive shell helpers
    # ------------------------------------------------------------------
    _TRANSIENT_MARKERS = (
        "connection reset by peer",
        "kex_exchange_identification",
        "connection closed",
    )

    def _run_diagnostic_probe(self, task, ssh_key_path: str, pj: str | None) -> str:
        """Run a BatchMode SSH probe and return lowercased stderr."""
        try:
            probe_prefix = [
                "-o",
                "BatchMode=yes",
                "-o",
                "ConnectTimeout=4",
                "-o",
                "ConnectionAttempts=1",
            ]
            if pj:
                probe_prefix.extend(["-J", str(pj)])
            probe_cmd = build_ssh_command(
                user=getattr(task, "ssh_user", "ubuntu"),
                host=task.ssh_host,
                port=getattr(task, "ssh_port", 22),
                key_path=Path(ssh_key_path),
                use_mux=False,
                prefix_args=probe_prefix,
                remote_command="echo SSH_OK",
            )
            probe = subprocess.run(probe_cmd, capture_output=True, text=True, timeout=6)
            return (probe.stderr or "").lower()
        except (OSError, TimeoutError, ConnectionError, subprocess.TimeoutExpired):
            return ""

    def _retry_transient_failure(
        self,
        ssh_cmd: list[str],
        result: subprocess.CompletedProcess,
        stderr_lower: str,
        cache_key: tuple | None,
        request_id: str,
    ) -> bool:
        """Retry on transient SSH failures. Returns True if a retry succeeded."""
        is_transient = (
            any(m in stderr_lower for m in self._TRANSIENT_MARKERS) or result.returncode == 255
        )
        if not is_transient:
            return False
        for backoff in (1.5, 3.0):
            time.sleep(backoff)
            retry = subprocess.run(ssh_cmd)
            if retry.returncode == 0:
                self.connection_manager.mark_success(cache_key)
                return True
        self.connection_manager.bust_cache(cache_key)
        raise make_error(
            "SSH connection was reset while the instance was initializing.\n"
            "Please wait 1-2 minutes and try again.",
            request_id,
        )

    def _retry_auth_failure(
        self,
        task,
        task_id: str,
        ssh_key_path: str,
        stderr_lower: str,
        cache_key: tuple | None,
        request_id: str,
    ) -> bool:
        """Handle auth failures: clear cache, re-resolve key, retry once. Returns True on success."""
        if "permission denied" not in stderr_lower and "publickey" not in stderr_lower:
            return False
        try:
            from flow.core.utils.ssh_key_cache import SSHKeyCache as _KC

            _KC().clear()
        except (ImportError, OSError):
            pass
        try:
            new_key_path = self.provider.get_task_ssh_connection_info(task_id)
            if isinstance(new_key_path, Path):
                ssh_key_path = str(new_key_path)
            retry_cmd = build_ssh_command(
                user=getattr(task, "ssh_user", "ubuntu"),
                host=task.ssh_host,
                port=getattr(task, "ssh_port", 22),
                key_path=Path(ssh_key_path),
                use_mux=False,
            )
            retry = subprocess.run(retry_cmd)
            if retry.returncode == 0:
                self.connection_manager.mark_success(cache_key)
                return True
        except (OSError, TimeoutError, ConnectionError):
            pass
        self.connection_manager.bust_cache(cache_key)
        raise make_error(
            "SSH authentication failed (Permission denied).\n"
            "Verify your key matches the task's SSH key, or set MITHRIL_SSH_KEY to override.",
            request_id,
        )

    def _handle_interactive_failure(
        self,
        ssh_cmd: list[str],
        result: subprocess.CompletedProcess,
        task,
        task_id: str,
        ssh_key_path: str,
        pj: str | None,
        cache_key: tuple | None,
        request_id: str,
    ) -> None:
        """Probe, classify, and handle a failed interactive SSH connection."""
        stderr_lower = self._run_diagnostic_probe(task, ssh_key_path, pj)
        if self._retry_transient_failure(ssh_cmd, result, stderr_lower, cache_key, request_id):
            return
        if self._retry_auth_failure(
            task, task_id, ssh_key_path, stderr_lower, cache_key, request_id
        ):
            return
        self.connection_manager.bust_cache(cache_key)
        raise make_error(
            f"SSH connection failed (exit {result.returncode}).",
            request_id,
        )

    @staticmethod
    def _is_interactive_command(command: str | None) -> bool:
        """Return True if the command requires an interactive TTY session."""
        if not command:
            return False
        interactive_markers = ["exec bash -l", "exec zsh -l", "exec sh -l", "exec fish -l"]
        if any(marker in command for marker in interactive_markers):
            return True
        return "docker exec" in command and any(f in command for f in [" -it", " --tty", " -t "])

    @staticmethod
    def _stop_progress_animation(progress_context) -> None:
        """Stop a progress animation before taking over the terminal."""
        if (
            progress_context and hasattr(progress_context, "_active") and progress_context._active  # type: ignore[attr-defined]
        ):
            progress_context.__exit__(None, None, None)

    @staticmethod
    def _get_ssh_debug_flags() -> tuple[bool, bool]:
        """Return (debug, fast) flags from settings or env."""
        try:
            from flow.application.config.runtime import settings as _settings  # local import

            return (
                bool((_settings.ssh or {}).get("debug", False)),
                bool((_settings.ssh or {}).get("fast", False)),
            )
        except (ImportError, AttributeError, TypeError):
            return (
                os.environ.get("FLOW_SSH_DEBUG") == "1",
                os.environ.get("FLOW_SSH_FAST") == "1",
            )

    # ------------------------------------------------------------------
    # Interactive shell
    # ------------------------------------------------------------------
    def open_shell(
        self,
        task_id: str,
        command: str | None = None,
        node: int | None = None,
        progress_context=None,
        record: bool = False,
        *,
        ssh_details: ConnectionDetails | None = None,
    ) -> None:
        request_id = new_request_id("ssh-connect")

        if ssh_details is not None:
            # Pre-resolved path: skip all re-derivation (steps 10-16 in trace)
            task = ssh_details.task
            ssh_key_path = ssh_details.key_path
            pj = ssh_details.proxyjump
            cache_key = ssh_details.cache_key
            recent_success = self.connection_manager.check_recent_success(cache_key)
            _debug, fast_flag = self._get_ssh_debug_flags()
            ssh_is_ready = True  # CLI already validated readiness
            if _debug:
                logger.debug(
                    "SSH open_shell using pre-resolved details: host=%s port=%s key=%s",
                    task.ssh_host,
                    getattr(task, "ssh_port", 22),
                    str(ssh_key_path),
                )
        else:
            # Full resolution path (backward compat for SDK and non-CLI callers)
            task = self.provider.get_task(task_id)

            # Use task.host(node) directly if available for multi-instance tasks
            if node is not None and hasattr(task, "host") and callable(task.host):
                try:
                    node_host = task.host(node)
                    if node_host:
                        task.ssh_host = node_host
                        if not getattr(task, "ssh_port", None):
                            task.ssh_port = 22
                except (KeyError, TypeError, AttributeError, IndexError):
                    pass  # Fall back to resolver
            # If task.ssh_host not set by node-specific path, use resolver
            if not getattr(task, "ssh_host", None):
                try:
                    host, port = self.provider.resolve_ssh_endpoint(task_id, node=node)
                    task.ssh_host = host
                    try:
                        task.ssh_port = int(port or 22)
                    except (ValueError, TypeError):
                        task.ssh_port = 22
                except (FlowError, AttributeError, TypeError) as e:
                    if not getattr(task, "ssh_host", None):
                        raise make_error(str(e), request_id)

            # SSH key path
            ssh_key_path = self.provider.get_task_ssh_connection_info(task_id, task=task)
            if ssh_key_path is None:
                raise make_error(
                    "SSH key resolution failed: no matching local key found", request_id
                )

            # Build cache key for recent-success heuristics
            cache_key = self.connection_manager.build_cache_key(task_id, task, node)
            recent_success = self.connection_manager.check_recent_success(cache_key)

            _debug, fast_flag = self._get_ssh_debug_flags()
            if _debug:
                logger.debug(
                    "SSH readiness probe for %s host=%s port=%s key=%s",
                    task_id,
                    task.ssh_host,
                    getattr(task, "ssh_port", 22),
                    str(ssh_key_path),
                )

            pj = (getattr(task, "provider_metadata", {}) or {}).get("ssh_proxyjump")
            pfx = ["-J", str(pj)] if pj else None
            ssh_is_ready = is_ssh_ready(
                user=getattr(task, "ssh_user", "ubuntu"),
                host=task.ssh_host,
                port=getattr(task, "ssh_port", 22),
                key_path=Path(ssh_key_path),
                prefix_args=pfx,
            )

            if _debug:
                logger.debug(
                    "SSH open details (request_id=%s): ready=%s recent_success=%s command=%r",
                    request_id,
                    bool(ssh_is_ready),
                    bool(recent_success),
                    command,
                )

        try:
            # Fast-path: skip readiness wait when SSH is known-good and no recording
            if command is None and not record and (recent_success or ssh_is_ready or fast_flag):
                prefix: list[str] | None = ["-J", str(pj)] if pj else None
                ssh_cmd = build_ssh_command(
                    user=getattr(task, "ssh_user", "ubuntu"),
                    host=task.ssh_host,
                    port=getattr(task, "ssh_port", 22),
                    key_path=Path(ssh_key_path),
                    prefix_args=prefix,
                )
                if _debug:
                    logger.debug("SSH fast-path exec argv: %s", " ".join(ssh_cmd))
                fast_result = subprocess.run(ssh_cmd)
                if fast_result.returncode == 0:
                    self.connection_manager.mark_success(cache_key)
                    return
        except (OSError, TimeoutError, ConnectionError):
            pass

        if progress_context and hasattr(progress_context, "update_message"):
            try:
                progress_context.update_message(
                    "SSH ready, connecting..." if ssh_is_ready else "Waiting for SSH to be ready..."
                )
            except (KeyError, TypeError, AttributeError):
                pass

        # Wait for readiness if needed (short sleeps/backoff), unless we recently succeeded
        if not ssh_is_ready and not recent_success:
            start_time = time.time()
            timeout = SSH_READY_WAIT_SECONDS
            attempts = 0
            while time.time() - start_time < timeout:
                if is_ssh_ready(
                    user=getattr(task, "ssh_user", "ubuntu"),
                    host=task.ssh_host,
                    port=getattr(task, "ssh_port", 22),
                    key_path=Path(ssh_key_path),
                ):
                    break
                wait_time = min(0.2 * (1 + attempts), 2.0)
                time.sleep(wait_time)
                attempts += 1
            else:
                # Fallback: try immediate interactive connect once
                try:
                    prefix = ["-J", str(pj)] if pj else None
                    ssh_cmd = build_ssh_command(
                        user=getattr(task, "ssh_user", "ubuntu"),
                        host=task.ssh_host,
                        port=getattr(task, "ssh_port", 22),
                        key_path=Path(ssh_key_path),
                        prefix_args=prefix,
                    )
                    if _debug:
                        logger.debug("SSH fallback exec argv: %s", " ".join(ssh_cmd))
                    subprocess.run(ssh_cmd)
                    return
                except (OSError, TimeoutError, ConnectionError):
                    pass
                raise make_error("SSH connection timed out", request_id)

        # Build base SSH command with ControlMaster for connection reuse
        prefix = ["-J", str(pj)] if pj else None
        ssh_cmd = build_ssh_command(
            user=getattr(task, "ssh_user", "ubuntu"),
            host=task.ssh_host,
            port=getattr(task, "ssh_port", 22),
            key_path=Path(ssh_key_path),
            prefix_args=prefix,
        )

        # Apply recording wrapper if requested
        if record:
            remote_command, requires_tty = build_recording_command(command)
            if requires_tty:
                ssh_cmd.insert(1, "-tt")
            ssh_cmd.append(remote_command)
        elif command:
            ssh_cmd.append(command)

        if _debug:
            logger.debug("SSH exec argv: %s", " ".join(ssh_cmd))

        try:
            is_interactive_cmd = self._is_interactive_command(command)

            if is_interactive_cmd:
                # Force TTY for remote command so the shell is interactive
                ssh_cmd.insert(1, "-tt")
                ssh_cmd.append(command)  # run remote command but attach to user's TTY
                self._stop_progress_animation(progress_context)

                result = subprocess.run(ssh_cmd)
                if result.returncode == 0:
                    self.connection_manager.mark_success(cache_key)
                    return

                self._handle_interactive_failure(
                    ssh_cmd,
                    result,
                    task,
                    task_id,
                    str(ssh_key_path),
                    pj,
                    cache_key,
                    request_id,
                )
                return

            # Non-interactive command: capture output
            if command:
                logger.debug("Executing SSH command: %s", " ".join(ssh_cmd))
                result = subprocess.run(
                    ssh_cmd, capture_output=True, text=True, stdin=subprocess.DEVNULL
                )
                logger.debug(
                    "SSH command result: returncode=%s, stdout_len=%s, stderr_len=%s",
                    result.returncode,
                    len(result.stdout or ""),
                    len(result.stderr or ""),
                )

                if result.returncode == 0:
                    print(result.stdout, end="")
                    self.connection_manager.mark_success(cache_key)
                    return

            # Pure interactive shell (no command specified)
            else:
                self._stop_progress_animation(progress_context)

                result = subprocess.run(ssh_cmd)
                if result.returncode == 0:
                    self.connection_manager.mark_success(cache_key)
                    return

                self._handle_interactive_failure(
                    ssh_cmd,
                    result,
                    task,
                    task_id,
                    str(ssh_key_path),
                    pj,
                    cache_key,
                    request_id,
                )
                return

            # Error handling for failed non-interactive commands
            if result.stdout:
                print(result.stdout, end="")
            if result.stderr:
                print(result.stderr, end="", file=sys.stderr)

            stderr = (result.stderr or "").lower()
            if result.returncode != 0:
                if "connection timed out" in stderr or "operation timed out" in stderr:
                    elapsed = getattr(task, "instance_age_seconds", 0) or 0
                    if elapsed < EXPECTED_PROVISION_MINUTES * 60:
                        raise make_error(
                            f"SSH connection timed out. Instance may still be provisioning "
                            f"(elapsed: {elapsed / 60:.1f} minutes). Mithril instances can take up to "
                            f"{EXPECTED_PROVISION_MINUTES} minutes to become fully available. Please try again later.",
                            request_id,
                        )
                    self.connection_manager.bust_cache(cache_key)
                    raise make_error(
                        "SSH connection timed out. Possible causes:\n"
                        f"  - Instance is still provisioning (can take up to {EXPECTED_PROVISION_MINUTES} minutes)\n"
                        "  - Network connectivity issues\n"
                        "  - Security group/firewall blocking SSH (port 22)",
                        request_id,
                    )
                elif "connection refused" in stderr:
                    self.connection_manager.bust_cache(cache_key)
                    raise make_error(
                        "SSH connection refused. The instance is reachable but SSH service "
                        "is not ready yet. Please wait a few more minutes and try again.",
                        request_id,
                    )
                elif (
                    "connection reset by peer" in stderr or "kex_exchange_identification" in stderr
                ):
                    self.connection_manager.bust_cache(cache_key)
                    raise make_error(
                        "SSH connection was reset. The SSH service is still initializing.\n"
                        "This typically happens during the first few minutes after instance creation.\n"
                        "Please wait 1-2 minutes and try again.",
                        request_id,
                    )
                elif "permission denied" in stderr:
                    raise make_error(
                        "SSH authentication failed (Permission denied).\n"
                        f"Key used: {Path(ssh_key_path).expanduser()!s}\n"
                        "Verify the task was launched with your SSH key, "
                        "or set MITHRIL_SSH_KEY to override.",
                        request_id,
                    )
                else:
                    raise make_error(f"SSH connection failed: {result.stderr}", request_id)
        except RemoteExecutionError:
            raise
        except (OSError, TimeoutError, ConnectionError) as e:
            raise make_error(f"SSH shell failed: {e!s}", request_id) from e
