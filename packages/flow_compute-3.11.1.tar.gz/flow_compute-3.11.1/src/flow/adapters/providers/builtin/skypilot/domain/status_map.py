"""Status mapping between SkyPilot and Flow.

This module provides conversion functions between SkyPilot's cluster/job
status representations and Flow's TaskStatus enum.
"""

from __future__ import annotations

from flow.sdk.models import TaskStatus

# SkyPilot cluster status to Flow TaskStatus mapping
SKYPILOT_CLUSTER_STATUS_MAP = {
    "INIT": TaskStatus.PENDING,
    "init": TaskStatus.PENDING,
    "starting": TaskStatus.PENDING,
    "UP": TaskStatus.RUNNING,
    "up": TaskStatus.RUNNING,
    "running": TaskStatus.RUNNING,
    "STOPPED": TaskStatus.PAUSED,
    "stopped": TaskStatus.PAUSED,
    "DOWN": TaskStatus.COMPLETED,
    "down": TaskStatus.COMPLETED,
    "unknown": TaskStatus.FAILED,
}

# SkyPilot job status to Flow TaskStatus mapping
SKYPILOT_JOB_STATUS_MAP = {
    "PENDING": TaskStatus.PENDING,
    "pending": TaskStatus.PENDING,
    "INIT": TaskStatus.PENDING,
    "init": TaskStatus.PENDING,
    "SETTING_UP": TaskStatus.PENDING,
    "setting_up": TaskStatus.PENDING,
    "RUNNING": TaskStatus.RUNNING,
    "running": TaskStatus.RUNNING,
    "SUCCEEDED": TaskStatus.COMPLETED,
    "succeeded": TaskStatus.COMPLETED,
    "COMPLETED": TaskStatus.COMPLETED,
    "completed": TaskStatus.COMPLETED,
    "FAILED": TaskStatus.FAILED,
    "failed": TaskStatus.FAILED,
    "FAILED_SETUP": TaskStatus.FAILED,
    "failed_setup": TaskStatus.FAILED,
    "CANCELLED": TaskStatus.CANCELLED,
    "cancelled": TaskStatus.CANCELLED,
    "CANCELLING": TaskStatus.CANCELLED,
    "cancelling": TaskStatus.CANCELLED,
}


def map_cluster_status(sky_status: str) -> TaskStatus:
    """Map SkyPilot cluster status to Flow TaskStatus.

    Args:
        sky_status: Cluster status from SkyPilot (e.g., "UP", "STOPPED").

    Returns:
        Corresponding Flow TaskStatus.
    """
    return SKYPILOT_CLUSTER_STATUS_MAP.get(sky_status, TaskStatus.FAILED)


def map_job_status(sky_status: str) -> TaskStatus:
    """Map SkyPilot job status to Flow TaskStatus.

    Args:
        sky_status: Job status from SkyPilot (e.g., "RUNNING", "SUCCEEDED").

    Returns:
        Corresponding Flow TaskStatus.
    """
    return SKYPILOT_JOB_STATUS_MAP.get(sky_status, TaskStatus.FAILED)


def is_terminal_status(status: TaskStatus) -> bool:
    """Check if status is terminal (task is finished).

    Args:
        status: Flow TaskStatus to check.

    Returns:
        True if task is in a terminal state.
    """
    return status in (
        TaskStatus.COMPLETED,
        TaskStatus.FAILED,
        TaskStatus.CANCELLED,
    )


def is_active_status(status: TaskStatus) -> bool:
    """Check if status indicates task is active.

    Args:
        status: Flow TaskStatus to check.

    Returns:
        True if task is pending or running.
    """
    return status in (TaskStatus.PENDING, TaskStatus.RUNNING)
