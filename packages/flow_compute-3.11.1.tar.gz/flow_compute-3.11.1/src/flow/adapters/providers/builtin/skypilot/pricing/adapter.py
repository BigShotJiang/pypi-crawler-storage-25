"""SkyPilot pricing adapter.

Queries SkyPilot catalog and returns Flow PricingOption objects.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from flow.adapters.providers.builtin.skypilot.bridge import SkyBridge
from flow.adapters.providers.builtin.skypilot.domain.gpu_constants import (
    normalize_gpu_name,
    parse_instance_type,
)
from flow.domain.pricing import PricingOption, sort_by_price

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.skypilot.config import SkyPilotConfig

logger = logging.getLogger(__name__)


class SkyPilotPricingAdapter:
    """Adapter for querying SkyPilot catalog pricing.

    This adapter queries the SkyPilot catalog for GPU pricing options
    and transforms them to Flow's PricingOption domain model.

    All SkyPilot types are transformed to Flow types before returning,
    ensuring no sky.* types escape the adapter.
    """

    def __init__(
        self,
        bridge: SkyBridge,
        config: SkyPilotConfig | None = None,
    ) -> None:
        """Initialize the pricing adapter.

        Args:
            bridge: SkyBridge instance for catalog queries.
            config: Optional SkyPilot configuration.
        """
        self._bridge = bridge
        self._config = config

    def get_options(
        self,
        gpu_type: str | None = None,
        gpu_count: int = 1,
        use_spot: bool = True,
        regions: list[str] | None = None,
        clouds: list[str] | None = None,
        instance_type: str | None = None,
    ) -> list[PricingOption]:
        """Query SkyPilot catalog for pricing options.

        Args:
            gpu_type: GPU type to search for (e.g., "A100", "H100").
            gpu_count: Number of GPUs required.
            use_spot: Whether to use spot pricing.
            regions: Optional list of regions to filter by.
            clouds: Optional list of clouds to query.
            instance_type: Optional instance type string (e.g., "8xA100").
                If provided, gpu_type and gpu_count are extracted from it.

        Returns:
            List of PricingOption objects sorted by price (cheapest first).
        """
        # Parse instance_type if provided
        if instance_type:
            parsed_gpu, parsed_count = parse_instance_type(instance_type)
            gpu_type = gpu_type or parsed_gpu
            gpu_count = parsed_count

        if not gpu_type:
            logger.warning("No GPU type specified for pricing query")
            return []

        # Normalize GPU name for SkyPilot catalog
        normalized_gpu = normalize_gpu_name(gpu_type)

        # Determine which clouds to query
        enabled_clouds = clouds
        if enabled_clouds is None and self._config is not None:
            enabled_clouds = self._config.get_enabled_clouds()

        # Query bridge for pricing options
        raw_options = self._bridge.list_gpu_options(
            gpu_type=normalized_gpu,
            gpu_count=gpu_count,
            clouds=enabled_clouds,
            use_spot=use_spot,
        )

        # Transform to PricingOption domain models
        options: list[PricingOption] = []
        for opt in raw_options:
            options.append(self._transform_dict_to_option(opt, use_spot))

        # Filter by regions if specified
        if regions:
            region_set = set(regions)
            options = [opt for opt in options if opt.region in region_set]

        # Sort by price (cheapest first)
        return sort_by_price(options)

    def get_cheapest_option(
        self,
        gpu_type: str | None = None,
        gpu_count: int = 1,
        max_price: float | None = None,
        use_spot: bool = True,
        regions: list[str] | None = None,
        clouds: list[str] | None = None,
        instance_type: str | None = None,
    ) -> PricingOption | None:
        """Get the cheapest pricing option under the specified max price.

        Args:
            gpu_type: GPU type to search for.
            gpu_count: Number of GPUs required.
            max_price: Maximum acceptable hourly price in USD.
            use_spot: Whether to use spot pricing.
            regions: Optional list of regions to filter by.
            clouds: Optional list of clouds to query.
            instance_type: Optional instance type string.

        Returns:
            Cheapest PricingOption under max_price, or None if not found.
        """
        options = self.get_options(
            gpu_type=gpu_type,
            gpu_count=gpu_count,
            use_spot=use_spot,
            regions=regions,
            clouds=clouds,
            instance_type=instance_type,
        )

        if not options:
            return None

        # Filter by max price if specified
        if max_price is not None:
            options = [opt for opt in options if opt.price <= max_price]

        # Return cheapest (list is already sorted)
        return options[0] if options else None

    def _transform_dict_to_option(
        self,
        opt: dict[str, Any],
        use_spot: bool,
    ) -> PricingOption:
        """Transform bridge dict output to PricingOption.

        Args:
            opt: Dictionary from SkyBridge.list_gpu_options().
            use_spot: Whether this is spot pricing.

        Returns:
            PricingOption domain model.
        """
        return PricingOption(
            provider=str(opt.get("provider", "unknown")).lower(),
            instance_type=opt.get("instance_type", "unknown"),
            gpu_type=opt.get("gpu_type", "unknown"),
            gpu_count=int(opt.get("gpu_count", 1)),
            price=float(opt.get("price", 0.0)),
            region=opt.get("region", "unknown"),
            is_spot=use_spot,
            cpu_count=opt.get("cpu_count"),
            memory_gb=opt.get("memory_gb"),
            gpu_memory_gb=opt.get("gpu_memory_gb"),
            cloud=opt.get("provider"),
            raw_instance_type=opt.get("instance_type"),
        )
