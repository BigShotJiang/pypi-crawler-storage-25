"""Single entry point to SkyPilot.

This is the ONLY file that knows about sky.* types.
All other code in the skypilot adapter uses this bridge.

Key principles:
1. Lazily imports sky.* only when methods are called
2. Translates ALL sky types to Flow types before returning
3. Catches ALL sky exceptions and re-raises as Flow exceptions
4. Never exposes sky.* types in its public API
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING, Any

from flow.adapters.providers.builtin.skypilot.bridge.error_mapper import map_sky_error
from flow.adapters.providers.builtin.skypilot.bridge.types import (
    ClusterInfo,
    DevClusterInfo,
    ExecResult,
    JobInfo,
    LaunchResult,
    StorageInfo,
)
from flow.adapters.providers.builtin.skypilot.domain.gpu_constants import (
    normalize_gpu_name,
)
from flow.adapters.providers.builtin.skypilot.domain.status_map import (
    map_cluster_status,
    map_job_status,
)
from flow.adapters.providers.builtin.skypilot.exceptions import SkyPilotNotInstalledError
from flow.sdk.models.enums import TaskStatus

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.skypilot.config import SkyPilotConfig
    from flow.sdk.models.task_config import TaskConfig

logger = logging.getLogger(__name__)


class SkyBridge:
    """Bridge to SkyPilot - isolates all sky.* imports.

    This class:
    1. Lazily imports sky.* only when methods are called
    2. Translates ALL sky types to Flow types before returning
    3. Catches ALL sky exceptions and re-raises as Flow exceptions
    4. Never exposes sky.* types in its public API

    All sky.* SDK calls in SkyPilot v0.11+ return a RequestId.
    The _resolve() helper blocks until the request completes.
    """

    def __init__(self, config: SkyPilotConfig) -> None:
        self._config = config
        self._sky: Any = None  # Lazy import

    @property
    def _sky_module(self) -> Any:
        """Lazy import of sky module."""
        if self._sky is None:
            try:
                import sky

                self._sky = sky
            except ImportError as e:
                raise SkyPilotNotInstalledError() from e
        return self._sky

    def _resolve(self, request_id: Any) -> Any:
        """Block until a SkyPilot RequestId resolves and return the result.

        SkyPilot v0.11+ returns RequestId from all SDK calls.
        sky.get() blocks until the operation completes.

        Args:
            request_id: RequestId returned by a sky.* call.

        Returns:
            The resolved result of the operation.
        """
        sky = self._sky_module
        return sky.get(request_id)

    # =========================================================================
    # PRICING API
    # =========================================================================

    def list_gpu_options(
        self,
        gpu_type: str | None,
        gpu_count: int,
        clouds: list[str] | None = None,
        use_spot: bool = True,
    ) -> list[dict[str, Any]]:
        """Query GPU pricing options.

        Returns list of dicts with pricing info, NOT sky's InstanceTypeInfo.

        Args:
            gpu_type: GPU type (e.g., "A100", "H100"), or None for all GPUs.
            gpu_count: Number of GPUs
            clouds: List of enabled clouds
            use_spot: Whether to use spot pricing

        Returns:
            List of pricing option dicts sorted by price
        """
        try:
            sky = self._sky_module

            results = sky.catalog.list_accelerators(
                gpus_only=True,
                name_filter=normalize_gpu_name(gpu_type) if gpu_type else None,
                quantity_filter=gpu_count,
                clouds=clouds,
                require_price=True,
            )

            # Transform to dicts BEFORE returning (no sky types escape)
            options: list[dict[str, Any]] = []
            for _gpu_name, infos in results.items():
                for info in infos:
                    options.append(self._instance_info_to_dict(info, use_spot))

            return sorted(options, key=lambda x: x["price"])

        except Exception as e:
            raise map_sky_error(e) from e

    def _instance_info_to_dict(self, info: Any, use_spot: bool) -> dict[str, Any]:
        """Transform sky.InstanceTypeInfo to dict.

        This is where the translation happens - sky types NEVER escape.
        """
        return {
            "provider": info.cloud,
            "instance_type": info.instance_type
            or f"{int(info.accelerator_count)}x{info.accelerator_name}",
            "gpu_type": info.accelerator_name,
            "gpu_count": int(info.accelerator_count),
            "price": info.spot_price if use_spot else info.price,
            "region": info.region,
            "is_spot": use_spot,
            "cpu_count": int(info.cpu_count) if info.cpu_count else None,
            "memory_gb": int(info.memory) if info.memory else None,
            "gpu_memory_gb": int(info.device_memory) if info.device_memory else None,
        }

    # =========================================================================
    # TASK API
    # =========================================================================

    def launch_task(
        self,
        config: TaskConfig,
        cloud: str | None,
        clouds: list[str] | None,
        accelerators: dict[str, int] | None,
        region: str | None,
        region_by_cloud: dict[str, str] | None,
        use_spot: bool,
        cluster_name: str,
        volume_names: list[str] | None = None,
        dryrun: bool = False,
    ) -> LaunchResult:
        """Launch a task on SkyPilot."""
        try:
            sky = self._sky_module
            storage_mounts = self._build_storage_mounts(volume_names) if volume_names else None
            task = self._build_sky_task(config, sky, storage_mounts)
            task.set_resources(
                self._build_task_resources(
                    sky=sky,
                    config=config,
                    cloud=cloud,
                    clouds=clouds,
                    accelerators=accelerators,
                    region=region,
                    region_by_cloud=region_by_cloud,
                    use_spot=use_spot,
                )
            )

            idle_minutes = self._config.idle_timeout_minutes or 5
            request_id = sky.launch(
                task,
                cluster_name=cluster_name,
                idle_minutes_to_autostop=idle_minutes,
                down=self._config.idle_timeout_minutes == 0,
                dryrun=dryrun,
            )

            job_id = None
            if not dryrun:
                job_id, _handle = self._resolve(request_id)

            return LaunchResult(
                cluster_name=cluster_name,
                job_id=job_id if not dryrun else None,
                status="validated" if dryrun else "starting",
            )

        except Exception as e:
            raise map_sky_error(e) from e

    def _build_sky_task(
        self,
        config: TaskConfig,
        sky: Any,
        storage_mounts: dict[str, Any] | None = None,
    ) -> Any:
        """Build sky.Task from Flow config.

        Note: Docker images are NOT set here. They belong on sky.Resources
        (image_id parameter), which is set by the caller after building the task.
        """
        if isinstance(config.command, list):
            run_cmd = " && ".join(config.command)
        else:
            run_cmd = config.command or "sleep infinity"

        task_kwargs: dict[str, Any] = {
            "name": config.name,
            "run": run_cmd,
            "envs": dict(config.env) if config.env else {},
        }

        # Setup script
        setup = getattr(config, "setup", None)
        if setup:
            task_kwargs["setup"] = setup

        # Code upload -- fail loud on invalid path
        if config.code_root:
            code_root_path = Path(config.code_root)
            if not code_root_path.exists():
                raise FileNotFoundError(f"code_root directory does not exist: {config.code_root}")
            if not code_root_path.is_dir():
                raise NotADirectoryError(f"code_root is not a directory: {config.code_root}")
            task_kwargs["workdir"] = str(code_root_path)

        # Multi-node
        num_instances = getattr(config, "num_instances", 1)
        if num_instances > 1:
            task_kwargs["num_nodes"] = num_instances

        if storage_mounts:
            task_kwargs["storage_mounts"] = storage_mounts

        return sky.Task(**task_kwargs)

    def _get_cloud_class(self, provider: str) -> type | None:
        """Get sky cloud class by name."""
        sky = self._sky_module
        cloud_map = {
            "gcp": sky.GCP,
            "aws": sky.AWS,
            "azure": sky.Azure,
        }
        return cloud_map.get(provider.lower())

    def _build_task_resources(
        self,
        *,
        sky: Any,
        config: TaskConfig,
        cloud: str | None,
        clouds: list[str] | None,
        accelerators: dict[str, int] | None,
        region: str | None,
        region_by_cloud: dict[str, str] | None,
        use_spot: bool,
    ) -> Any:
        """Build one or more SkyPilot resource candidates for a task."""
        if cloud and clouds:
            raise ValueError("Specify either 'cloud' or 'clouds' for SkyPilot launch, not both.")

        if clouds is not None and not clouds:
            raise ValueError("SkyPilot launch requires at least one enabled cloud.")

        base_kwargs: dict[str, Any] = {
            "accelerators": accelerators,
            "use_spot": use_spot,
            "disk_size": self._config.disk_size_gb,
        }

        image = getattr(config, "image", None)
        if image:
            base_kwargs["image_id"] = str(image)

        if clouds is None:
            resource_kwargs = dict(base_kwargs)
            if region:
                resource_kwargs["region"] = region
            if cloud:
                cloud_cls = self._get_cloud_class(cloud)
                if cloud_cls is None:
                    raise ValueError(f"Unsupported SkyPilot cloud '{cloud}'.")
                resource_kwargs["cloud"] = cloud_cls()
            return sky.Resources(**resource_kwargs)

        resources: list[Any] = []
        for candidate_cloud in clouds:
            cloud_cls = self._get_cloud_class(candidate_cloud)
            if cloud_cls is None:
                raise ValueError(f"Unsupported SkyPilot cloud '{candidate_cloud}'.")

            resource_kwargs = dict(base_kwargs)
            resource_kwargs["cloud"] = cloud_cls()

            candidate_region = region_by_cloud.get(candidate_cloud) if region_by_cloud else None
            if candidate_region:
                resource_kwargs["region"] = candidate_region

            resources.append(sky.Resources(**resource_kwargs))

        if not resources:
            raise ValueError("SkyPilot launch requires at least one resource candidate.")

        return resources

    # =========================================================================
    # CLUSTER API
    # =========================================================================

    def get_cluster_status(self, cluster_name: str) -> ClusterInfo | None:
        """Get cluster status.

        Returns Flow's ClusterInfo, NOT sky.ClusterStatus.
        """
        try:
            sky = self._sky_module

            request_id = sky.status(cluster_names=[cluster_name])
            statuses = self._resolve(request_id)
            if not statuses:
                return None

            status = statuses[0]
            return self._status_to_cluster_info(cluster_name, status)

        except Exception as e:
            raise map_sky_error(e) from e

    def _status_to_cluster_info(self, name: str, status: Any) -> ClusterInfo:
        """Convert a sky status record to ClusterInfo."""
        # Extract SSH user from handle if available (varies by cloud/image)
        ssh_user = None
        if status.handle:
            ssh_user = getattr(status.handle, "ssh_user", None)
        return ClusterInfo(
            name=name,
            status=map_cluster_status(status.status.value),
            cloud=str(status.cloud) if hasattr(status, "cloud") else "unknown",
            region=str(status.region) if hasattr(status, "region") else "unknown",
            instance_type=str(status.instance_type)
            if hasattr(status, "instance_type")
            else "unknown",
            ip_address=status.handle.head_ip if status.handle else None,
            ssh_user=ssh_user,
        )

    def list_clusters(self) -> list[ClusterInfo]:
        """List all clusters.

        Returns list of Flow's ClusterInfo, NOT sky types.
        """
        try:
            sky = self._sky_module

            request_id = sky.status()
            statuses = self._resolve(request_id)
            clusters: list[ClusterInfo] = []

            for status in statuses:
                clusters.append(self._status_to_cluster_info(status.name, status))

            return clusters

        except Exception as e:
            raise map_sky_error(e) from e

    def terminate_cluster(self, cluster_name: str) -> None:
        """Terminate a cluster.

        Args:
            cluster_name: Cluster to terminate.

        Raises:
            SkyPilotProviderError: If termination fails.
        """
        try:
            sky = self._sky_module
            self._resolve(sky.down(cluster_name))
        except Exception as e:
            raise map_sky_error(e) from e

    def stop_cluster(self, cluster_name: str) -> None:
        """Stop (pause) a cluster without terminating.

        Args:
            cluster_name: Cluster to stop.

        Raises:
            SkyPilotProviderError: If stop fails.
        """
        try:
            sky = self._sky_module
            self._resolve(sky.stop(cluster_name))
        except Exception as e:
            raise map_sky_error(e) from e

    def start_cluster(self, cluster_name: str) -> None:
        """Start (resume) a stopped cluster.

        Args:
            cluster_name: Cluster to start.

        Raises:
            SkyPilotProviderError: If start fails.
        """
        try:
            sky = self._sky_module
            self._resolve(sky.start(cluster_name))
        except Exception as e:
            raise map_sky_error(e) from e

    # =========================================================================
    # LOGS API
    # =========================================================================

    def get_logs(self, cluster_name: str, job_id: int | None = None) -> str:
        """Get task logs.

        Returns string (Flow convention), not sky log stream.

        In SkyPilot v0.11+, download_logs() returns a dict mapping
        job_id -> local log directory path (not a RequestId).
        When the cluster is gone (auto-stopped/terminated), falls back to
        the local log cache at ~/sky_logs/{cluster_name}/.
        """
        try:
            sky = self._sky_module

            job_ids = [str(job_id)] if job_id else None
            try:
                log_dirs = sky.download_logs(cluster_name, job_ids=job_ids)
            except Exception:  # noqa: BLE001
                # Cluster may be gone; fall back to local cache
                log_dirs = None

            # If download succeeded, read from returned paths
            if log_dirs:
                return self._read_log_dirs(log_dirs)

            # Fall back to local SkyPilot log cache
            return self._read_cached_logs(cluster_name)

        except Exception as e:
            raise map_sky_error(e) from e

    def _read_log_dirs(self, log_dirs: dict[str, str]) -> str:
        """Read log content from a download_logs result dict."""
        log_content: list[str] = []
        for _job_id, log_dir in log_dirs.items():
            log_path = Path(log_dir).expanduser()
            if not log_path.exists():
                continue
            for log_file in log_path.rglob("*.log"):
                log_content.append(log_file.read_text())
        return "\n".join(log_content)

    def _read_cached_logs(self, cluster_name: str) -> str:
        """Read logs from SkyPilot's local cache (~/.sky_logs/{cluster})."""
        cache_dir = Path.home() / "sky_logs" / cluster_name
        if not cache_dir.exists():
            return ""
        log_content: list[str] = []
        for log_file in sorted(cache_dir.rglob("*.log")):
            log_content.append(log_file.read_text())
        return "\n".join(log_content)

    def stream_logs(self, cluster_name: str, job_id: int | None = None) -> Iterator[str]:
        """Stream task logs from a SkyPilot cluster.

        In SkyPilot v0.11+, tail_logs with preload_content=False returns
        an Iterator[Optional[str]] directly, avoiding the need for
        stdout redirection hacks.

        Args:
            cluster_name: Cluster to stream logs from.
            job_id: Optional job ID to filter.

        Yields:
            Log lines as they become available.

        Raises:
            SkyPilotProviderError: If log streaming fails.
        """
        try:
            sky = self._sky_module

            result = sky.tail_logs(
                cluster_name,
                job_id=job_id,
                follow=True,
                preload_content=False,
            )

            # v0.11: returns Iterator[Optional[str]] when preload_content=False
            if hasattr(result, "__iter__") and not isinstance(result, int):
                for line in result:
                    if line is not None:
                        yield line
            else:
                # Fallback: tail_logs returned an int (exit code) because
                # it wrote directly to stdout. Nothing to yield.
                logger.debug("tail_logs returned exit code %s", result)

        except Exception as e:
            raise map_sky_error(e) from e

    # =========================================================================
    # JOB API
    # =========================================================================

    def get_job_status(self, cluster_name: str, job_id: int) -> JobInfo | None:
        """Get job status on a cluster."""
        try:
            sky = self._sky_module

            request_id = sky.job_status(cluster_name, job_ids=[job_id])
            jobs = self._resolve(request_id)
            if not jobs or job_id not in jobs:
                return None

            job = jobs[job_id]
            return JobInfo(
                job_id=job_id,
                status=map_job_status(str(job)),
                name=None,
                start_time=None,
                end_time=None,
            )

        except Exception as e:
            raise map_sky_error(e) from e

    def cancel_job(self, cluster_name: str, job_id: int) -> None:
        """Cancel a job on a cluster.

        Args:
            cluster_name: Cluster hosting the job.
            job_id: Job to cancel.

        Raises:
            SkyPilotProviderError: If cancellation fails.
        """
        try:
            sky = self._sky_module
            self._resolve(sky.cancel(cluster_name, job_ids=[job_id]))
        except Exception as e:
            raise map_sky_error(e) from e

    # =========================================================================
    # DEV MODE API
    # =========================================================================

    def launch_dev_cluster(
        self,
        config: TaskConfig,
        cloud: str | None,
        accelerators: dict[str, int],
        region: str | None,
        use_spot: bool,
        cluster_name: str,
        dryrun: bool = False,
    ) -> DevClusterInfo:
        """Launch a persistent dev cluster (no auto-termination)."""
        try:
            sky = self._sky_module
            task = self._build_sky_task(config, sky)
            cloud_cls = self._get_cloud_class(cloud) if cloud else None

            # Build resource kwargs
            resource_kwargs: dict[str, Any] = {
                "accelerators": accelerators,
                "region": region,
                "use_spot": use_spot,
                "disk_size": self._config.disk_size_gb,
            }
            if cloud_cls:
                resource_kwargs["cloud"] = cloud_cls()

            # Docker image goes on Resources, not Task.
            # Skip Mithril's default Docker image — SkyPilot's own base image
            # already includes CUDA.  Only pass user-chosen images.
            image = getattr(config, "image", None)
            if image:
                resource_kwargs["image_id"] = str(image)

            task.set_resources(sky.Resources(**resource_kwargs))

            request_id = sky.launch(
                task,
                cluster_name=cluster_name,
                idle_minutes_to_autostop=None,
                down=False,
                dryrun=dryrun,
            )
            self._resolve(request_id)

            if dryrun:
                return DevClusterInfo(
                    name=cluster_name,
                    status=TaskStatus.PENDING,
                    ip_address=None,
                    cloud=cloud or "unknown",
                    region=region or "unknown",
                    instance_type=next(iter(accelerators.keys()), "unknown"),
                )

            info = self.get_dev_cluster_info(cluster_name)
            if info is None:
                return DevClusterInfo(
                    name=cluster_name,
                    status=TaskStatus.PROVISIONING,
                    ip_address=None,
                    cloud=cloud or "unknown",
                    region=region or "unknown",
                    instance_type=next(iter(accelerators.keys()), "unknown"),
                )
            return info

        except Exception as e:
            raise map_sky_error(e) from e

    def exec_on_dev_cluster(
        self,
        cluster_name: str,
        command: str,
        env: dict[str, str] | None = None,
        stream_logs: bool = True,
    ) -> ExecResult:
        """Execute command on existing dev cluster.

        Args:
            cluster_name: Name of the dev cluster
            command: Command to execute
            env: Environment variables
            stream_logs: Whether to stream logs to stdout

        Returns:
            ExecResult with job_id for tracking
        """
        try:
            sky = self._sky_module

            task = sky.Task(
                run=command,
                envs=env or {},
            )

            request_id = sky.exec(
                task,
                cluster_name,
                stream_logs=stream_logs,
            )
            job_id, _ = self._resolve(request_id)

            return ExecResult(
                job_id=job_id or 0,
                status="running",
                cluster_name=cluster_name,
            )

        except Exception as e:
            raise map_sky_error(e) from e

    def get_dev_cluster_info(self, cluster_name: str) -> DevClusterInfo | None:
        """Get dev cluster status.

        Args:
            cluster_name: Name of the dev cluster

        Returns:
            DevClusterInfo if cluster exists, None otherwise
        """
        try:
            sky = self._sky_module

            request_id = sky.status(cluster_names=[cluster_name])
            statuses = self._resolve(request_id)
            if not statuses:
                return None

            status = statuses[0]
            return self._status_to_dev_cluster_info(cluster_name, status)

        except Exception as e:
            raise map_sky_error(e) from e

    def _status_to_dev_cluster_info(self, name: str, status: Any) -> DevClusterInfo:
        """Convert a sky status record to DevClusterInfo."""
        uptime_hours = None
        launched_at = None
        if hasattr(status, "launched_at") and status.launched_at:
            from datetime import datetime, timezone

            launched_at = str(status.launched_at)
            try:
                if isinstance(status.launched_at, datetime):
                    delta = datetime.now(timezone.utc) - status.launched_at
                    uptime_hours = delta.total_seconds() / 3600
            except Exception:  # noqa: BLE001
                pass

        return DevClusterInfo(
            name=name,
            status=map_cluster_status(status.status.value),
            ip_address=status.handle.head_ip if status.handle else None,
            cloud=str(status.cloud) if hasattr(status, "cloud") else "unknown",
            region=str(status.region) if hasattr(status, "region") else "unknown",
            instance_type=str(status.instance_type)
            if hasattr(status, "instance_type")
            else "unknown",
            uptime_hours=uptime_hours,
            launched_at=launched_at,
        )

    def list_dev_clusters(self, name_prefix: str = "flow-dev-") -> list[DevClusterInfo]:
        """List all dev clusters owned by Flow.

        Args:
            name_prefix: Prefix to filter dev clusters (default: "flow-dev-")

        Returns:
            List of DevClusterInfo for matching clusters
        """
        try:
            sky = self._sky_module

            request_id = sky.status()
            statuses = self._resolve(request_id)
            clusters: list[DevClusterInfo] = []

            for status in statuses:
                if hasattr(status, "name") and status.name.startswith(name_prefix):
                    clusters.append(self._status_to_dev_cluster_info(status.name, status))

            return clusters

        except Exception as e:
            raise map_sky_error(e) from e

    # =========================================================================
    # STORAGE API
    # =========================================================================

    def create_storage(
        self,
        name: str,
        source: str | None = None,
        store_type: str | None = None,
        region: str | None = None,
    ) -> StorageInfo:
        """Create and provision a cloud storage bucket.

        This creates a sky.Storage config and adds it to SkyPilot's storage
        registry, which provisions the actual cloud bucket (S3/GCS/Azure).

        Args:
            name: Unique name for the storage.
            source: Optional local path to sync to storage.
            store_type: Storage backend (s3, gcs, azure). Auto-detected if None.
            region: Explicit storage region. Requires a resolvable backend.

        Returns:
            StorageInfo with storage details.
        """
        try:
            sky = self._sky_module
            resolved_store_type = self._resolve_storage_store_type(store_type, region)
            sky_store_type = (
                self._get_store_type_enum(sky, resolved_store_type)
                if resolved_store_type is not None
                else None
            )

            # Determine storage mode
            storage_mode = getattr(sky, "StorageMode", None)
            mode = getattr(storage_mode, "MOUNT", None) if storage_mode else None

            # Build storage kwargs
            storage_kwargs: dict[str, Any] = {"name": name}
            if mode is not None:
                storage_kwargs["mode"] = mode
            if source:
                storage_kwargs["source"] = source

            if sky_store_type is not None and region is None:
                storage_kwargs["stores"] = [sky_store_type]

            # Create storage config object
            storage = sky.Storage(**storage_kwargs)

            self._provision_storage(
                sky=sky,
                storage=storage,
                sky_store_type=sky_store_type,
                region=region,
                resolved_store_type=resolved_store_type,
            )
            actual_store_type, actual_region = self._extract_storage_details(
                storage=storage,
                fallback_store_type=resolved_store_type or "auto",
                fallback_region=region,
            )

            return StorageInfo(
                name=name,
                store_type=actual_store_type,
                status="ready",
                source=source,
                bucket_name=name,
                region=actual_region,
            )

        except Exception as e:
            raise map_sky_error(e) from e

    def delete_storage(self, name: str) -> None:
        """Delete a cloud storage bucket.

        Args:
            name: Storage name to delete.

        Raises:
            SkyPilotProviderError: If deletion fails.
        """
        try:
            sky = self._sky_module
            result = sky.storage_delete(name)
            # storage_delete may return RequestId in v0.11+
            if result is not None:
                self._resolve(result)
        except Exception as e:
            raise map_sky_error(e) from e

    def list_storage(self) -> list[StorageInfo]:
        """List all cloud storage buckets managed by SkyPilot.

        Returns:
            List of StorageInfo objects.
        """
        try:
            sky = self._sky_module

            if not hasattr(sky, "storage_ls"):
                logger.warning("sky.storage_ls not available")
                return []

            # v0.11+: storage_ls() returns a RequestId that must be resolved.
            request_id = sky.storage_ls()
            storage_list = self._resolve(request_id)
            if not storage_list:
                return []

            result: list[StorageInfo] = []
            for storage in storage_list:
                name = getattr(storage, "name", "unknown")

                status_attr = getattr(storage, "status", None)
                status = str(status_attr).lower() if status_attr else "ready"
                store_type, region = self._extract_storage_details(
                    storage=storage,
                    fallback_store_type="unknown",
                    fallback_region=getattr(storage, "region", None),
                )

                result.append(
                    StorageInfo(
                        name=name,
                        store_type=store_type,
                        status=status,
                        source=None,
                        bucket_name=name,
                        region=region,
                    )
                )

            return result

        except Exception as e:
            raise map_sky_error(e) from e

    def get_storage(self, name: str) -> StorageInfo | None:
        """Get storage info by name.

        Args:
            name: Storage name.

        Returns:
            StorageInfo if found, None otherwise.
        """
        storages = self.list_storage()
        for storage in storages:
            if storage.name == name:
                return storage
        return None

    def _resolve_storage_store_type(
        self,
        store_type: str | None,
        region: str | None,
    ) -> str | None:
        """Resolve a concrete storage backend, or raise when policy is ambiguous."""
        if store_type is not None:
            return store_type.strip().lower()

        enabled_clouds = self._config.get_enabled_clouds()
        cloud_to_store = {
            "aws": "s3",
            "azure": "azure",
            "gcp": "gcs",
        }

        if len(enabled_clouds) == 1:
            return cloud_to_store[enabled_clouds[0]]

        if region is not None:
            raise ValueError(
                "SkyPilot storage region selection requires an explicit backend or "
                "exactly one enabled cloud. Configure skypilot.clouds to a single "
                "provider before creating a regional volume."
            )

        return None

    def _get_store_type_enum(self, sky: Any, store_type: str) -> Any:
        """Resolve a SkyPilot StoreType enum member from a normalized name."""
        store_enum = getattr(sky, "StoreType", None)
        if store_enum is None:
            raise ValueError(
                "This SkyPilot version does not expose StoreType; explicit storage "
                "backend selection is unsupported."
            )

        enum_name = store_type.strip().upper()
        if not hasattr(store_enum, enum_name):
            raise ValueError(f"Unsupported SkyPilot storage backend '{store_type}'.")
        return getattr(store_enum, enum_name)

    def _provision_storage(
        self,
        *,
        sky: Any,
        storage: Any,
        sky_store_type: Any,
        region: str | None,
        resolved_store_type: str | None,
    ) -> None:
        """Provision storage using the best supported explicit API."""
        if region is not None:
            if sky_store_type is None:
                raise ValueError(
                    "SkyPilot cannot honor an explicit storage region without a "
                    "concrete storage backend."
                )
            if not hasattr(storage, "construct") or not hasattr(storage, "add_store"):
                raise ValueError(
                    "This SkyPilot version cannot provision storage in an explicit "
                    "region. Remove the region or upgrade SkyPilot."
                )
            storage.construct()
            storage.add_store(sky_store_type, region=region)
            return

        if hasattr(sky, "storage_add"):
            sky.storage_add(storage)
            return

        if (
            sky_store_type is not None
            and hasattr(storage, "construct")
            and hasattr(storage, "add_store")
        ):
            storage.construct()
            storage.add_store(sky_store_type, region=None)
            return

        if hasattr(storage, "add"):
            storage.add()
            return

        if resolved_store_type is None:
            raise ValueError(
                "Automatic SkyPilot storage backend selection is unavailable in this "
                "SkyPilot version. Configure exactly one enabled cloud so Flow can "
                "choose a backend explicitly."
            )

        raise ValueError(
            "This SkyPilot version does not expose a supported storage provisioning "
            "API for explicit backend selection."
        )

    def _extract_storage_details(
        self,
        *,
        storage: Any,
        fallback_store_type: str,
        fallback_region: str | None,
    ) -> tuple[str, str | None]:
        """Extract normalized store type and region from SkyPilot storage objects."""
        actual_store_type = fallback_store_type
        actual_region = fallback_region

        store_attr = getattr(storage, "store", None)
        stores_attr = getattr(storage, "stores", None)

        if store_attr:
            first_store = next(iter(store_attr), None)
            if first_store is not None:
                actual_store_type = self._normalize_store_name(first_store)

        if stores_attr:
            if isinstance(stores_attr, dict):
                for store_name, store_obj in stores_attr.items():
                    if store_obj is None:
                        continue
                    actual_store_type = self._normalize_store_name(store_name)
                    actual_region = getattr(store_obj, "region", actual_region)
                    break
            else:
                first_store = next(iter(stores_attr), None)
                if first_store is not None:
                    actual_store_type = self._normalize_store_name(first_store)
                    actual_region = getattr(first_store, "region", actual_region)

        return actual_store_type, actual_region

    def _normalize_store_name(self, store: Any) -> str:
        """Normalize SkyPilot store enum/object values to Flow strings."""
        if hasattr(store, "value"):
            return str(store.value).lower()
        return str(store).lower()

    def _build_storage_mounts(
        self,
        volume_names: list[str],
    ) -> dict[str, Any]:
        """Build sky.Storage mount config from volume names.

        This is internal to the bridge -- sky.Storage objects never escape.
        The returned dict is passed directly to sky.Task(storage_mounts=...).

        Args:
            volume_names: List of (storage_name, mount_path) pairs.

        Returns:
            Dict mapping mount paths to sky.Storage objects.
        """
        sky = self._sky_module
        storage_mode = getattr(sky, "StorageMode", None)
        mode = getattr(storage_mode, "MOUNT", None) if storage_mode else None

        mounts: dict[str, Any] = {}
        for entry in volume_names:
            if isinstance(entry, tuple):
                name, mount_path = entry
            else:
                name = entry
                mount_path = f"/data/{name}"
            mounts[mount_path] = sky.Storage(name=name, mode=mode)

        return mounts
