"""Lightweight JSON state persistence for SkyPilot task metadata.

Stores the mapping between Flow task IDs and SkyPilot cluster names,
plus original TaskConfig metadata that SkyPilot does not track.

SkyPilot is the source of truth for cluster status. This file stores
only the Flow<->SkyPilot ID mapping and original task configuration.

File location: ~/.flow/skypilot_state.json
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_STATE_PATH = Path.home() / ".flow" / "skypilot_state.json"


@dataclass
class TaskRecord:
    """Persisted metadata for a SkyPilot-managed task.

    Attributes:
        task_id: Flow task identifier (e.g., "sky-abc12345").
        cluster_name: SkyPilot cluster name (e.g., "flow-sky-abc12345").
        name: Human-readable task name from TaskConfig.
        instance_type: GPU instance type (e.g., "A100", "8xH100").
        created_at: ISO 8601 creation timestamp.
        job_id: SkyPilot job identifier used for job-aware status recovery.
        num_instances: Original multi-node width.
        region: Requested region, if any.
        config_snapshot: Serialized essential TaskConfig fields.
    """

    task_id: str
    cluster_name: str
    name: str
    instance_type: str
    created_at: str
    config_snapshot: dict[str, Any]
    job_id: int | None = None
    num_instances: int = 1
    cloud: str | None = None
    region: str | None = None


@dataclass
class VolumeRecord:
    """Persisted metadata for a SkyPilot-managed volume.

    Attributes:
        name: Volume name (e.g., "flow-vol-abc12345").
        size_gb: Requested size in GB.
        store_type: Storage backend (s3, gcs, azure).
        created_at: ISO 8601 creation timestamp.
        region: Region where storage was created.
    """

    name: str
    size_gb: int
    store_type: str = "auto"
    created_at: str = ""
    region: str | None = None


class StateStore:
    """JSON-file-backed state store for task<->cluster mappings and volume metadata.

    Thread-safety: not thread-safe. The SkyPilot adapter is used from
    a single CLI process, so this is acceptable.
    """

    def __init__(self, path: Path | None = None) -> None:
        """Initialize state store.

        Args:
            path: Path to state file. Defaults to ~/.flow/skypilot_state.json.
        """
        self._path = path or DEFAULT_STATE_PATH
        self._records: dict[str, TaskRecord] = {}
        self._volumes: dict[str, VolumeRecord] = {}
        self._load()

    def _load(self) -> None:
        """Load state from disk. Tolerates missing or corrupt files."""
        if not self._path.exists():
            return
        try:
            data = json.loads(self._path.read_text())
            for task_id, record_dict in data.get("tasks", {}).items():
                self._records[task_id] = TaskRecord(**record_dict)
            for vol_name, vol_dict in data.get("volumes", {}).items():
                self._volumes[vol_name] = VolumeRecord(**vol_dict)
        except (json.JSONDecodeError, TypeError, KeyError) as e:
            logger.warning("Corrupt state file %s, starting fresh: %s", self._path, e)
            self._records = {}
            self._volumes = {}

    def _save(self) -> None:
        """Persist state to disk atomically.

        Writes to a temporary file in the same directory, then uses
        os.rename() for atomic replacement (POSIX guarantee). This
        prevents data loss if the process crashes mid-write.
        """
        self._path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "tasks": {tid: asdict(r) for tid, r in self._records.items()},
            "volumes": {name: asdict(v) for name, v in self._volumes.items()},
        }
        content = json.dumps(data, indent=2)

        fd = tempfile.NamedTemporaryFile(  # noqa: SIM115
            mode="w",
            dir=self._path.parent,
            suffix=".tmp",
            delete=False,
        )
        try:
            fd.write(content)
            fd.flush()
            os.fsync(fd.fileno())
            fd.close()
            os.rename(fd.name, self._path)
        except BaseException:
            fd.close()
            # Clean up the temp file on failure.
            try:
                os.unlink(fd.name)
            except OSError:
                pass
            raise

    def put(self, record: TaskRecord) -> None:
        """Store or update a task record.

        Args:
            record: Task record to persist.
        """
        self._records[record.task_id] = record
        self._save()

    def get(self, task_id: str) -> TaskRecord | None:
        """Get a task record by Flow task ID.

        Args:
            task_id: Flow task identifier.

        Returns:
            TaskRecord if found, None otherwise.
        """
        return self._records.get(task_id)

    def get_by_cluster(self, cluster_name: str) -> TaskRecord | None:
        """Get a task record by SkyPilot cluster name.

        Args:
            cluster_name: SkyPilot cluster name.

        Returns:
            TaskRecord if found, None otherwise.
        """
        for record in self._records.values():
            if record.cluster_name == cluster_name:
                return record
        return None

    def remove(self, task_id: str) -> None:
        """Remove a task record.

        Args:
            task_id: Flow task identifier.
        """
        if task_id in self._records:
            del self._records[task_id]
            self._save()

    def all_records(self) -> list[TaskRecord]:
        """Get all stored task records.

        Returns:
            List of all TaskRecord objects.
        """
        return list(self._records.values())

    # ------------------------------------------------------------------
    # Volume operations
    # ------------------------------------------------------------------

    def put_volume(self, record: VolumeRecord) -> None:
        """Store or update a volume record."""
        self._volumes[record.name] = record
        self._save()

    def get_volume(self, name: str) -> VolumeRecord | None:
        """Get a volume record by name."""
        return self._volumes.get(name)

    def remove_volume(self, name: str) -> None:
        """Remove a volume record."""
        if name in self._volumes:
            del self._volumes[name]
            self._save()

    def all_volumes(self) -> list[VolumeRecord]:
        """Get all stored volume records."""
        return list(self._volumes.values())
