"""Low-level K8s CRUD operations for serverless deployments.

These activities wrap a ``K8sClient`` implementation for creating, updating,
deleting, and polling Kubernetes resources. They are invoked by the higher
level workflow activities (``ensure_container_ready``, etc.).

Design rules:
    * Fail loud: a missing ``K8sClient`` raises ``RuntimeError`` rather than
      returning silently.
    * Blocking K8s calls are dispatched through ``asyncio.to_thread`` so the
      activity loop stays responsive.
    * All timeouts are explicit; no unbounded waits.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from flow.adapters.providers.builtin.serverless.k8s.client_protocol import (
    DeploymentStatus,
    K8sClient,
)

logger = logging.getLogger(__name__)

_DEFAULT_REQUEST_TIMEOUT_S = 30.0
_DEFAULT_READY_POLL_INTERVAL_S = 2.0


def _require_client(k8s_client: K8sClient | None, operation: str) -> K8sClient:
    """Return the client or raise a loud error naming the failed operation."""
    if k8s_client is None:
        raise RuntimeError(
            f"K8sClient is required for '{operation}' but none was provided; "
            "configure 'k8s_client' on ServerlessContext before running "
            "serverless activities."
        )
    return k8s_client


async def apply_manifests(
    k8s_client: K8sClient | None,
    manifests: list[dict[str, Any]],
    namespace: str,
    request_timeout_s: float = _DEFAULT_REQUEST_TIMEOUT_S,
) -> None:
    """Apply a list of K8s manifests (Deployment, Service, ScaledObject).

    Args:
        k8s_client: K8s API client instance.
        manifests: List of K8s resource dicts to apply.
        namespace: Target namespace for resources without an explicit
            ``metadata.namespace``.
        request_timeout_s: Per-request timeout passed to the client.

    Raises:
        RuntimeError: If ``k8s_client`` is ``None``.
    """
    client = _require_client(k8s_client, "apply_manifests")
    logger.info("Applying %d manifest(s) in namespace %s", len(manifests), namespace)
    await asyncio.to_thread(
        client.apply_manifests,
        manifests,
        namespace,
        request_timeout_s,
    )


async def delete_deployment(
    k8s_client: K8sClient | None,
    name: str,
    namespace: str,
    request_timeout_s: float = _DEFAULT_REQUEST_TIMEOUT_S,
) -> None:
    """Delete a K8s Deployment and its matching Service (idempotent).

    Args:
        k8s_client: K8s API client instance.
        name: Deployment and Service name.
        namespace: Target namespace.
        request_timeout_s: Per-request timeout passed to the client.

    Raises:
        RuntimeError: If ``k8s_client`` is ``None``.
        kubernetes.client.exceptions.ApiException: On non-404 failures.
    """
    client = _require_client(k8s_client, "delete_deployment")
    logger.info("Deleting deployment %s in namespace %s", name, namespace)
    await asyncio.to_thread(
        client.delete_deployment,
        name,
        namespace,
        request_timeout_s,
    )


async def wait_for_ready(
    k8s_client: K8sClient | None,
    deployment_name: str,
    namespace: str,
    timeout_seconds: int = 300,
    poll_interval_s: float = _DEFAULT_READY_POLL_INTERVAL_S,
) -> DeploymentStatus:
    """Poll until a Deployment has ``ready_replicas == replicas``.

    Args:
        k8s_client: K8s API client instance.
        deployment_name: Name of the Deployment.
        namespace: K8s namespace.
        timeout_seconds: Maximum time to wait.
        poll_interval_s: Delay between status polls.

    Returns:
        Final ``DeploymentStatus`` when the deployment becomes ready.

    Raises:
        RuntimeError: If ``k8s_client`` is ``None``.
        TimeoutError: If the deployment is not ready within ``timeout_seconds``.
    """
    client = _require_client(k8s_client, "wait_for_ready")
    logger.info(
        "Waiting for deployment %s/%s to be ready (timeout=%ds)",
        namespace,
        deployment_name,
        timeout_seconds,
    )
    return await asyncio.to_thread(
        client.wait_for_ready,
        deployment_name,
        namespace,
        timeout_seconds,
        poll_interval_s,
    )
