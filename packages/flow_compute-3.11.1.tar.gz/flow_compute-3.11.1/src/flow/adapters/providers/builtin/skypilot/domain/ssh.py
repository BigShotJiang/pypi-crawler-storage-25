"""SSH connection utilities for SkyPilot clusters.

Provides functions for obtaining SSH connection information and
executing commands on SkyPilot clusters.
"""

from __future__ import annotations

import logging
import shlex
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.skypilot.bridge.sky_bridge import SkyBridge

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SSHConnectionInfo:
    """SSH connection information for a cluster.

    Attributes:
        host: IP address or hostname.
        user: SSH username.
        port: SSH port (default 22).
        identity_file: Path to SSH private key.
        cluster_name: Name of the SkyPilot cluster.
        node_id: Node identifier for multi-node clusters.
    """

    host: str
    user: str
    port: int = 22
    identity_file: str | None = None
    cluster_name: str | None = None
    node_id: int | None = None

    def to_ssh_command(self, command: str | None = None) -> str:
        """Generate SSH command string.

        Args:
            command: Optional command to run on remote host.

        Returns:
            SSH command string ready for execution.
        """
        parts = ["ssh"]

        # Add standard options
        parts.extend(["-o", "StrictHostKeyChecking=no"])
        parts.extend(["-o", "UserKnownHostsFile=/dev/null"])

        # Add port if not default
        if self.port != 22:
            parts.extend(["-p", str(self.port)])

        # Add identity file if specified
        if self.identity_file:
            parts.extend(["-i", self.identity_file])

        # Add user@host
        parts.append(f"{self.user}@{self.host}")

        # Add command if specified
        if command:
            parts.append(shlex.quote(command))

        return " ".join(parts)

    def to_scp_command(
        self,
        local_path: str,
        remote_path: str,
        upload: bool = True,
    ) -> str:
        """Generate SCP command string.

        Args:
            local_path: Local file path.
            remote_path: Remote file path.
            upload: True for upload, False for download.

        Returns:
            SCP command string ready for execution.
        """
        parts = ["scp"]

        # Add standard options
        parts.extend(["-o", "StrictHostKeyChecking=no"])
        parts.extend(["-o", "UserKnownHostsFile=/dev/null"])

        # Add port if not default
        if self.port != 22:
            parts.extend(["-P", str(self.port)])

        # Add identity file if specified
        if self.identity_file:
            parts.extend(["-i", self.identity_file])

        # Add source and destination based on direction
        remote = f"{self.user}@{self.host}:{remote_path}"
        if upload:
            parts.extend([local_path, remote])
        else:
            parts.extend([remote, local_path])

        return " ".join(parts)


def get_ssh_info(
    bridge: SkyBridge,
    cluster_name: str,
    node_id: int = 0,
) -> SSHConnectionInfo | None:
    """Get SSH connection info for a cluster.

    Args:
        bridge: SkyBridge instance for cluster communication.
        cluster_name: Name of the cluster.
        node_id: Node index for multi-node clusters (0 = head node).

    Returns:
        SSHConnectionInfo or None if unavailable.
    """
    try:
        cluster_info = bridge.get_cluster_status(cluster_name)
        if cluster_info is None:
            logger.warning("Cluster %s not found", cluster_name)
            return None

        if cluster_info.ip_address is None:
            logger.warning("Cluster %s has no IP address", cluster_name)
            return None

        ssh_user = cluster_info.ssh_user or "ubuntu"

        return SSHConnectionInfo(
            host=cluster_info.ip_address,
            user=ssh_user,
            port=22,
            identity_file=None,  # SkyPilot manages SSH keys
            cluster_name=cluster_name,
            node_id=node_id,
        )

    except Exception as e:  # noqa: BLE001
        logger.warning("Failed to get SSH info for %s: %s", cluster_name, e)
        return None


def get_multi_node_ssh_info(
    bridge: SkyBridge,
    cluster_name: str,
) -> list[SSHConnectionInfo]:
    """Get SSH connection info for all nodes in a multi-node cluster.

    Args:
        bridge: SkyBridge instance for cluster communication.
        cluster_name: Name of the cluster.

    Returns:
        List of SSHConnectionInfo for each node.
    """
    try:
        cluster_info = bridge.get_cluster_status(cluster_name)
        if cluster_info is None:
            return []

        # For now, only return head node
        # Multi-node SSH info requires SkyPilot API extensions
        head_info = get_ssh_info(bridge, cluster_name, node_id=0)
        if head_info:
            return [head_info]
        return []

    except Exception as e:  # noqa: BLE001
        logger.warning("Failed to get multi-node SSH info for %s: %s", cluster_name, e)
        return []


class SSHManager:
    """Manages SSH connections to SkyPilot clusters."""

    def __init__(self, bridge: SkyBridge) -> None:
        """Initialize SSHManager.

        Args:
            bridge: SkyBridge instance for cluster communication.
        """
        self._bridge = bridge

    def get_connection_info(
        self,
        cluster_name: str,
        node_id: int = 0,
    ) -> SSHConnectionInfo | None:
        """Get SSH connection info for cluster.

        Args:
            cluster_name: Cluster name.
            node_id: Node index (0 = head node).

        Returns:
            SSHConnectionInfo or None.
        """
        return get_ssh_info(self._bridge, cluster_name, node_id)

    def get_ssh_command(
        self,
        cluster_name: str,
        command: str | None = None,
    ) -> str | None:
        """Get SSH command for connecting to cluster.

        Args:
            cluster_name: Cluster name.
            command: Optional command to run.

        Returns:
            SSH command string or None if unavailable.
        """
        info = self.get_connection_info(cluster_name)
        if info is None:
            return None
        return info.to_ssh_command(command)

    def get_all_nodes(
        self,
        cluster_name: str,
    ) -> list[SSHConnectionInfo]:
        """Get SSH info for all nodes in cluster.

        Args:
            cluster_name: Cluster name.

        Returns:
            List of SSHConnectionInfo.
        """
        return get_multi_node_ssh_info(self._bridge, cluster_name)
