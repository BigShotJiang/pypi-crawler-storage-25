"""Temporal client factory.

Creates connected Temporal clients with appropriate retry and timeout settings.
All Temporal SDK imports are isolated to this module and the workflow/activity
modules to keep the optional dependency boundary clean.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


async def connect(
    address: str,
    namespace: str = "default",
    **kwargs: Any,
) -> Any:
    """Connect to a Temporal cluster and return a client.

    Args:
        address: Temporal frontend address (e.g. "localhost:7233").
        namespace: Temporal namespace (default "default").
        **kwargs: Additional arguments passed to temporalio.client.Client.connect.

    Returns:
        A connected temporalio.client.Client instance.

    Raises:
        ImportError: If temporalio is not installed.
        ConnectionError: If the connection fails.
    """
    try:
        from temporalio.client import Client
    except ImportError as e:
        raise ImportError(
            "The serverless backend requires 'temporalio'. "
            "Install it with: pip install 'flow-compute[serverless]'"
        ) from e

    logger.info("Connecting to Temporal at %s (namespace=%s)", address, namespace)
    client = await Client.connect(address, namespace=namespace, **kwargs)
    logger.info("Connected to Temporal successfully")
    return client
