"""Shared helpers for task cancellation used by lifecycle sections.

Both terminate_on_exit and runtime_monitor need to:
1. Write runtime credentials to /var/lib/flow/task-runtime.conf
2. Resolve the task ID from the Mithril API
3. Cancel the task via DELETE with retries

This module provides the cancel script and config block generation
as single sources of truth, eliminating duplication.
"""

from __future__ import annotations

import shlex
import textwrap


def build_cancel_script() -> str:
    """Generate the bash cancel script body for flow-runtime-cancel.sh.

    The script sources credentials from /var/lib/flow/task-runtime.conf,
    resolves the Mithril task ID by matching the EC2 instance ID or task
    name against the bids API, then sends a DELETE to cancel the task.

    This script does NOT stop Docker containers. Callers should handle
    container lifecycle before invoking cancel.
    """
    return textwrap.dedent("""\
        #!/bin/bash
        set -euo pipefail
        CONFIG="/var/lib/flow/task-runtime.conf"
        [ -f "$CONFIG" ] && source "$CONFIG" || true
        log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [flow-cancel] $*"; }

        FLOW_RUNTIME_UA="${FLOW_RUNTIME_UA:-flow-runtime/$(uname -s)-$(uname -m)}"

        : "${MITHRIL_API_KEY:=}"
        : "${MITHRIL_API_URL:=https://api.mithril.ai}"
        : "${MITHRIL_PROJECT:=}"

        INSTANCE_ID=$(curl -s --max-time 5 http://169.254.169.254/latest/meta-data/instance-id 2>/dev/null || hostname)
        JSON=$(curl -sS --max-time 20 \\
          -H "Authorization: Bearer $MITHRIL_API_KEY" \\
          -H "User-Agent: $FLOW_RUNTIME_UA" \\
          "$MITHRIL_API_URL/v2/spot/bids?project=$MITHRIL_PROJECT" || true)

        TASK_ID="unknown"
        if command -v jq >/dev/null 2>&1; then
          TASK_ID=$(echo "$JSON" | jq -r --arg IID "$INSTANCE_ID" --arg NAME "${TASK_NAME:-}" '
            (.. | objects | select(has("instances")))? as $x |
            ($x.instances[]? | select(.instance_id == $IID) | $x.fid) //
            ((.data // .)[]? | select(.name == $NAME and .fid != null) | .fid) //
            "unknown"
          ')
        else
          TASK_ID=$( INSTANCE_ID="$INSTANCE_ID" TASK_NAME="${TASK_NAME:-}" python3 - <<'PY' 2>/dev/null || echo unknown
import os, sys, json
try:
    data = json.load(sys.stdin)
except Exception:
    print("unknown"); sys.exit(0)
items = data if isinstance(data, list) else data.get("data", [])
iid = os.environ.get("INSTANCE_ID", "")
name = os.environ.get("TASK_NAME", "")
fid = "unknown"
for x in items:
    for inst in (x.get("instances") or []):
        if inst.get("instance_id") == iid:
            fid = x.get("fid") or "unknown"
            break
    if fid != "unknown":
        break
if fid == "unknown" and name:
    for x in items:
        if x.get("name") == name:
            fid = x.get("fid") or "unknown"
            break
print(fid)
PY
          )
        fi

        if [ "$TASK_ID" != "unknown" ]; then
          log "Cancelling task $TASK_ID"
          for attempt in 1 2 3 4 5; do
            CODE=$(curl -sS -o /dev/null -w "%{http_code}" -X DELETE \\
              -H "Authorization: Bearer $MITHRIL_API_KEY" \\
              -H "User-Agent: $FLOW_RUNTIME_UA" \\
              -H "Content-Type: application/json" \\
              "$MITHRIL_API_URL/v2/spot/bids/$TASK_ID" --max-time 30 || true)
            if [ "$CODE" = "200" ] || [ "$CODE" = "204" ] || [ "$CODE" = "202" ]; then
              log "Cancelled task $TASK_ID successfully"
              break
            fi
            sleep $((attempt * attempt))
          done
        else
          log "Could not resolve TASK_ID from provider API; skipping remote cancel"
        fi""")


def build_runtime_config(
    task_name: str,
    api_key: str,
    api_url: str,
    project: str,
) -> str:
    """Generate shell code that writes /var/lib/flow/task-runtime.conf.

    Only writes the file if it does not already exist, preventing
    overwrites by later lifecycle sections. Values are escaped with
    shlex.quote() to prevent shell injection.
    """
    safe_task = shlex.quote(task_name)
    safe_key = shlex.quote(api_key)
    safe_url = shlex.quote(api_url)
    safe_proj = shlex.quote(project)
    return textwrap.dedent(f"""\
        CONFIG_PATH="/var/lib/flow/task-runtime.conf"
        umask 077
        if [ ! -f "$CONFIG_PATH" ]; then
          mkdir -p /var/lib/flow
          cat > "$CONFIG_PATH" <<'FLOW_CONFIG_EOF'
TASK_NAME={safe_task}
MITHRIL_API_KEY={safe_key}
MITHRIL_API_URL={safe_url}
MITHRIL_PROJECT={safe_proj}
FLOW_CONFIG_EOF
        fi""")


__all__ = ["build_cancel_script", "build_runtime_config"]
