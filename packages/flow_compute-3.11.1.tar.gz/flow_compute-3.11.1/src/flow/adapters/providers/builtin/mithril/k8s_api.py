"""Hand-written Kubernetes cluster API client.

Replaces the auto-generated bindings (13K lines) with the three API calls
actually used by the codebase: list clusters, get cluster, list SSH keys.

Wire models are Pydantic v2 BaseModels so validation errors surface at the
HTTP boundary rather than degrading silently via dict ``.get()`` defaults.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

import httpx
from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class KubernetesClusterStatus(str, Enum):
    AVAILABLE = "Available"
    PENDING = "Pending"
    TERMINATED = "Terminated"

    def __str__(self) -> str:
        return str(self.value)


class _WireModel(BaseModel):
    """Base for all API wire models.

    - ``extra="ignore"`` so forward-compatible fields from the server don't
      fail parsing, but missing required fields still raise.
    - ``frozen=True`` keeps model instances hashable and immutable, matching
      the prior ``@dataclass(frozen=True)`` behaviour.
    """

    model_config = ConfigDict(extra="ignore", frozen=True)


class KubernetesCluster(_WireModel):
    """Kubernetes cluster as returned by the Mithril API."""

    fid: str
    project: str
    name: str
    region: str
    created_at: str
    kube_host: str | None = None
    ssh_keys: list[str] = Field(default_factory=list)
    instances: list[str] = Field(default_factory=list)
    join_command: str | None = None
    status: KubernetesClusterStatus
    deleted_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict for CLI/JSON output."""
        result: dict[str, Any] = {
            "fid": self.fid,
            "project": self.project,
            "name": self.name,
            "region": self.region,
            "created_at": self.created_at,
            "kube_host": self.kube_host,
            "ssh_keys": self.ssh_keys,
            "instances": self.instances,
            "join_command": self.join_command,
            "status": self.status.value,
        }
        if self.deleted_at is not None:
            result["deleted_at"] = self.deleted_at
        return result


class SshKey(_WireModel):
    """SSH key as returned by the Mithril API."""

    fid: str
    name: str
    project: str
    public_key: str
    created_at: str
    required: bool = False


class ValidationErrorDetail(_WireModel):
    """Single validation error entry from a 422 response."""

    loc: list[str] = Field(default_factory=list)
    msg: str = ""


class InstanceHealthSummary(_WireModel):
    """Aggregate instance health across listed clusters.

    Emitted as part of the ``flow k8s list --json`` envelope.
    """

    running: int = 0
    failed: int = 0
    pending: int = 0


class K8sListEnvelope(_WireModel):
    """Rectangular envelope for ``flow k8s list --json``.

    The JSON output is stable so automation can rely on the shape regardless
    of how the CLI's human-readable rendering evolves.
    """

    kubeconfig_context: str | None = None
    instance_health_summary: InstanceHealthSummary = Field(default_factory=InstanceHealthSummary)
    clusters: list[KubernetesCluster] = Field(default_factory=list)

    def to_json(self) -> dict[str, Any]:
        """Serialize envelope into a vanilla dict for ``print_json``."""
        return {
            "kubeconfig_context": self.kubeconfig_context,
            "instance_health_summary": self.instance_health_summary.model_dump(),
            "clusters": [c.to_dict() for c in self.clusters],
        }


class K8sApiError(Exception):
    """Raised when the Mithril K8s API returns an error."""

    def __init__(self, message: str, details: list[ValidationErrorDetail] | None = None):
        super().__init__(message)
        self.details = details or []


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


def _handle_error(response: httpx.Response) -> None:
    """Raise :class:`K8sApiError` for 422 responses, otherwise raise_for_status.

    Extracted as a module-level function so both sync and async paths use
    identical error handling without duplicating logic.
    """
    if response.status_code == 422:
        body = response.json()
        raw_detail = body.get("detail", [])
        if isinstance(raw_detail, list):
            details = [ValidationErrorDetail.model_validate(d) for d in raw_detail]
            msgs = [f"{d.loc}: {d.msg}" for d in details]
        else:
            details = []
            msgs = [str(raw_detail)]
        raise K8sApiError(
            f"Validation error: {', '.join(msgs)}" if msgs else "Validation error from API",
            details=details,
        )
    response.raise_for_status()


def _parse_clusters(payload: Any) -> list[KubernetesCluster]:
    """Validate a raw JSON payload into a list of cluster models."""
    if not isinstance(payload, list):
        raise K8sApiError(f"Expected JSON array of clusters, got {type(payload).__name__}")
    return [KubernetesCluster.model_validate(item) for item in payload]


def _parse_ssh_keys(payload: Any) -> list[SshKey]:
    """Validate a raw JSON payload into a list of SSH key models."""
    if not isinstance(payload, list):
        raise K8sApiError(f"Expected JSON array of SSH keys, got {type(payload).__name__}")
    return [SshKey.model_validate(item) for item in payload]


@dataclass
class K8sApiClient:
    """Minimal HTTP client for the Mithril Kubernetes and SSH key APIs.

    Provides both synchronous and asynchronous methods. The sync path exists
    because :mod:`flow.adapters.providers.builtin.mithril.provider.context`
    resolves K8s cluster IDs from synchronous submission hot paths where
    spinning up an asyncio event loop per call would hurt latency and fight
    the surrounding sync code. Both paths share :func:`_handle_error` and
    the ``_parse_*`` helpers so response handling is not duplicated.
    """

    base_url: str
    token: str

    def _headers(self) -> dict[str, str]:
        # Mirror the identification headers the main HttpClient/Config attach
        # so Mithril can attribute K8s requests to a concrete Flow client.
        # Same shape as ``flow.application.config.config.Config.get_headers``.
        from flow._version import get_version
        from flow.domain.action import get_action
        from flow.domain.origin import detect_origin

        version = get_version()
        headers: dict[str, str] = {
            "Authorization": f"Bearer {self.token}",
            "User-Agent": f"flow-compute/{version}",
            "X-Flow-Compute-Version": version,
            "X-Flow-Origin": detect_origin(),
            "X-Flow-Action": get_action(),
        }
        try:
            from flow.adapters.providers.builtin.mithril.runtime.startup.origin import (
                get_flow_session_id,
            )

            headers["X-Flow-Session-Id"] = get_flow_session_id()
        except Exception:  # noqa: BLE001
            pass
        return headers

    # -- Synchronous methods (used by context.py) ---------------------------

    def list_clusters_sync(self, project: str) -> list[KubernetesCluster]:
        """List all Kubernetes clusters for a project (synchronous)."""
        url = f"{self.base_url}/v2/kubernetes_clusters"
        with httpx.Client(timeout=_DEFAULT_TIMEOUT) as client:
            resp = client.get(url, headers=self._headers(), params={"project": project})
        _handle_error(resp)
        return _parse_clusters(resp.json())

    # -- Async methods (used by k8s/impl.py) --------------------------------

    async def list_clusters(self, project: str) -> list[KubernetesCluster]:
        """List all Kubernetes clusters for a project."""
        url = f"{self.base_url}/v2/kubernetes_clusters"
        async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT) as client:
            resp = await client.get(url, headers=self._headers(), params={"project": project})
        _handle_error(resp)
        return _parse_clusters(resp.json())

    async def get_cluster(self, cluster_fid: str) -> KubernetesCluster:
        """Get a single Kubernetes cluster by FID."""
        url = f"{self.base_url}/v2/kubernetes_clusters/{cluster_fid}"
        async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT) as client:
            resp = await client.get(url, headers=self._headers())
        _handle_error(resp)
        return KubernetesCluster.model_validate(resp.json())

    async def list_ssh_keys(self, project: str) -> list[SshKey]:
        """List SSH keys for a project."""
        url = f"{self.base_url}/v2/ssh_keys"
        async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT) as client:
            resp = await client.get(url, headers=self._headers(), params={"project": project})
        _handle_error(resp)
        return _parse_ssh_keys(resp.json())
