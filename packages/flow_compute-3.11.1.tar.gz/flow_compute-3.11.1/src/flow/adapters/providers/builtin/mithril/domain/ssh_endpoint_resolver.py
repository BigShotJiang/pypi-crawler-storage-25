"""Centralized SSH endpoint resolver for Mithril provider.

Resolves the best SSH host and port for a bid (task) by consulting provider
APIs with correct scoping, normalizing statuses, and performing an optional
TCP probe to prefer endpoints that are already accepting connections.

This module is intentionally provider-scoped but free of CLI/UI coupling. Both
the CLI and provider remote ops should use this resolver for consistent
behavior.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable, Iterable, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime

from flow.adapters.providers.builtin.mithril.api.client import MithrilApiClient
from flow.adapters.providers.builtin.mithril.domain.instances import InstanceService
from flow.core.ssh import has_ssh_banner, tcp_port_open
from flow.errors import FlowError
from flow.utils.ttl_cache import TTLCache

logger = logging.getLogger(__name__)

# Type aliases for API response documents
InstanceDoc = Mapping[str, object]
BidDoc = Mapping[str, object]


def _safe_parse_iso8601(ts: object) -> datetime | None:
    try:
        if isinstance(ts, datetime):
            return ts
        if isinstance(ts, str):
            return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    return None


def _is_dead_status(status: object) -> bool:
    try:
        s = str(status or "").strip().lower()
    except (ValueError, TypeError):
        return False
    if s.startswith("status_"):
        s = s.replace("status_", "")
    if "termin" in s or "cancel" in s:
        return True
    return s in {"terminated", "cancelled", "failed"}


def _is_public_ipv4(ip: str) -> bool:
    """Return True only for literal, public IPv4 addresses.

    Previous logic treated any non-RFC1918-looking string as "public", which
    incorrectly included DNS hostnames (e.g., bastion endpoints). That caused
    the resolver to prefer a bastion hostname over the instance's actual
    public IPv4, leading to SSH resets when the bastion wasn't the correct
    target for direct SSH.

    Use ipaddress parsing to ensure the value is an IPv4 literal and is
    globally routable (not private, loopback, link-local, multicast, or
    reserved).
    """
    try:
        from ipaddress import ip_address

        addr = ip_address(str(ip))
        # is_global implies not private/loopback/link-local/multicast/reserved
        return getattr(addr, "version", 0) == 4 and getattr(addr, "is_global", False)
    except (ValueError, TypeError):
        # Not a literal IP (likely a hostname) → not a public IPv4
        return False


def _dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for v in values:
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


@dataclass
class ResolveOptions:
    node: int | None = None
    tcp_probe: bool = True
    max_ids_to_check: int = 5


class SshEndpointResolver:
    """Resolves SSH host/port for Mithril tasks (bids)."""

    def __init__(
        self,
        api: MithrilApiClient,
        get_project_id: Callable[[], str],
        instance_service: InstanceService,
    ) -> None:
        self._api = api
        self._get_project_id = get_project_id
        self._instances = instance_service
        # TTL caches for endpoints and bids
        self._endpoint_cache: TTLCache[tuple[str, int], tuple[str, int]] = TTLCache(
            ttl_seconds=15.0
        )
        self._bid_cache: TTLCache[str, BidDoc] = TTLCache(ttl_seconds=60.0)

    def resolve(
        self, bid_id: str, *, node: int | None = None, tcp_probe: bool = True
    ) -> tuple[str, int]:
        opts = ResolveOptions(node=node, tcp_probe=tcp_probe)
        debug_enabled = logger.isEnabledFor(logging.DEBUG)
        bid = self._fetch_bid(bid_id)
        instances = bid.get("instances", [])

        if not isinstance(instances, list) or not instances:
            try:
                docs = self._instances.list_project_instances_by_bid(bid_id, max_pages=3)
                instances = docs if isinstance(docs, list) else []
            except (KeyError, TypeError, AttributeError):
                instances = []
        if not isinstance(instances, list) or not instances:
            raise ValueError("No instances associated with bid")

        # Ensure stable ordering for deterministic node indexing
        instances = self._normalize_instance_order(instances)

        # Node-specific selection overrides generic selection
        if opts.node is not None:
            if opts.node < 0 or opts.node >= len(instances):
                raise ValueError(
                    f"Invalid node index {opts.node}; bid has {len(instances)} instances"
                )
            chosen = instances[opts.node]
        else:
            chosen = self._select_best_instance(instances, opts)
            if chosen is None:
                raise ValueError("No suitable instance found for SSH resolution")

        host, port, candidates = self._extract_endpoint_candidates(chosen)
        if debug_enabled:
            logger.debug(
                "ssh-resolver bid=%s selected_instance=%s status=%s candidates=%s",
                bid_id,
                chosen.get("fid"),
                chosen.get("status"),
                candidates,
            )

        if not candidates and not host:
            # Provide actionable error with instance details
            instance_name = chosen.get("name") or chosen.get("fid") or "unknown"
            instance_status = chosen.get("status") or "unknown"
            if opts.node is not None:
                raise ValueError(
                    f"Node {opts.node} ('{instance_name}') has no SSH endpoint "
                    f"(status={instance_status})"
                )
            raise ValueError(
                f"Instance '{instance_name}' has no SSH endpoint (status={instance_status})"
            )

        # Build final candidate list: prefer parsed host first if present
        ordered_candidates: list[str] = []
        if host:
            ordered_candidates.append(str(host))
        for c in candidates:
            if c not in ordered_candidates:
                ordered_candidates.append(str(c))

        # Prefer public IPv4s first
        public_candidates = [c for c in ordered_candidates if _is_public_ipv4(str(c))]
        if opts.tcp_probe:
            # Happy-eyeballs: probe all candidates in parallel, pick the first
            # one that responds.  Public IPs are preferred via ordering.
            probe_order = _dedupe_preserve_order(public_candidates + ordered_candidates)

            # Phase 1: parallel SSH banner check -- strongest signal
            winner = self._parallel_probe(
                probe_order, port, has_ssh_banner, debug_enabled, "banner"
            )
            if winner is not None:
                return winner, port

            # Phase 2: parallel TCP open -- weaker but still useful
            winner = self._parallel_probe(probe_order, port, tcp_port_open, debug_enabled, "tcp")
            if winner is not None:
                return winner, port

        # Fallback to first public, else first overall
        if public_candidates:
            if debug_enabled:
                logger.debug(
                    "ssh-resolver selected host (first public): %s:%s", public_candidates[0], port
                )
            return str(public_candidates[0]), port
        if ordered_candidates:
            if debug_enabled:
                logger.debug(
                    "ssh-resolver selected host (first overall): %s:%s", ordered_candidates[0], port
                )
            return str(ordered_candidates[0]), port

        raise ValueError("No suitable SSH endpoint found")

    def resolve_with_cache(
        self,
        bid_id: str,
        *,
        node: int | None = None,
        tcp_probe: bool = True,
    ) -> tuple[str, int]:
        """Resolve with a small in-memory TTL cache.

        Caches the (host, port) per (bid_id, node) for 15 seconds to reduce
        repeated API calls and TCP probes during frequent lookups.
        """
        key = (bid_id, int(node or -1))

        # Check cache first
        if cached := self._endpoint_cache.get(key):
            return cached

        # Cache miss - resolve and cache
        host, port = self.resolve(bid_id, node=node, tcp_probe=tcp_probe)
        self._endpoint_cache.set(key, (host, port))
        return host, port

    # -------------------------- helpers --------------------------

    @staticmethod
    def _parallel_probe(
        candidates: list[str],
        port: int,
        probe_fn: Callable[[str, int], bool],
        debug_enabled: bool,
        label: str,
    ) -> str | None:
        """Probe candidates in parallel and return the first that succeeds.

        Uses ThreadPoolExecutor + as_completed so the first positive result
        wins immediately without waiting for slower candidates.
        """
        if not candidates:
            return None

        with ThreadPoolExecutor(max_workers=len(candidates)) as pool:
            future_to_ip = {pool.submit(probe_fn, str(ip), port): ip for ip in candidates}
            try:
                for future in as_completed(future_to_ip):
                    ip = future_to_ip[future]
                    try:
                        result = future.result()
                    except (OSError, TimeoutError, ConnectionError):
                        result = False
                    if debug_enabled:
                        logger.debug("ssh-resolver %s %s:%s -> %s", label, ip, port, result)
                    if result:
                        if debug_enabled:
                            logger.debug("ssh-resolver selected host (%s): %s:%s", label, ip, port)
                        return str(ip)
            finally:
                # Cancel remaining futures once a winner is found or all checked
                for f in future_to_ip:
                    f.cancel()
        return None

    def _fetch_bid(self, bid_id: str) -> BidDoc:
        """Fetch bid by ID using direct API lookup.

        Uses an in-memory cache with TTL to avoid redundant API calls for the same bid.
        """
        # Check cache first
        if cached := self._bid_cache.get(bid_id):
            return cached

        # Direct bid lookup
        try:
            bid_result = self._api.get_bid(bid_id)
        except FlowError as exc:
            status = getattr(exc, "status_code", None)
            if status == 404:
                raise ValueError(
                    f"Task '{bid_id}' not found via API. "
                    "It may have been deleted or is not accessible."
                ) from exc
            raise

        # Normalize response format (some APIs wrap in 'data')
        bid_result = bid_result.get("data", bid_result)

        # Verify this is the right bid
        fid = bid_result.get("fid")
        if fid != bid_id:
            raise ValueError(f"get_bid returned wrong bid: expected {bid_id}, got {fid}")

        # Cache and return
        self._bid_cache.set(bid_id, bid_result)
        return bid_result

    def _select_best_instance(
        self, instances: list[InstanceDoc], opts: ResolveOptions
    ) -> InstanceDoc | None:
        """Select the best instance from the list.

        Assumes instances are dicts (API contract). Prefers live instances,
        sorted by newest created_at.
        """
        selected: list[InstanceDoc] = []

        for checked, inst in enumerate(reversed(instances)):
            selected.append(inst)

            if checked + 1 >= opts.max_ids_to_check:
                break

        if not selected:
            return None

        # Prefer non-terminated, newest by created_at when available
        live = [e for e in selected if not _is_dead_status(e.get("status"))]

        def sort_key(e: InstanceDoc) -> tuple[datetime]:
            ts = _safe_parse_iso8601(e.get("created_at")) or _safe_parse_iso8601(e.get("createdAt"))
            return (ts or datetime.min,)

        if live:
            live_sorted = sorted(live, key=sort_key, reverse=True)
            return live_sorted[0]
        selected_sorted = sorted(selected, key=sort_key, reverse=True)
        return selected_sorted[0]

    def _extract_endpoint_candidates(
        self, instance_doc: InstanceDoc
    ) -> tuple[str | None, int, list[str]]:
        host: str | None = None
        port: int = 22
        candidates: list[str] = []

        ssh_destination = instance_doc.get("ssh_destination")
        if isinstance(ssh_destination, str) and ssh_destination:
            parts = ssh_destination.split(":")
            host = parts[0]
            try:
                port = int(parts[1]) if len(parts) > 1 else 22
            except (ValueError, TypeError):
                port = 22

        try:
            ssh_port_val = instance_doc.get("ssh_port")
            if ssh_port_val is not None:
                p = int(ssh_port_val)
                if p > 0:
                    port = p
        except (ValueError, TypeError):
            pass

        def add(val: object) -> None:
            if isinstance(val, str) and re.fullmatch(r"\d+\.\d+\.\d+\.\d+", val):
                candidates.append(val)
            elif isinstance(val, list):
                for v in val:
                    add(v)
            elif isinstance(val, dict):
                for v in val.values():
                    add(v)

        add(instance_doc.get("public_ip"))
        add(instance_doc.get("publicIp"))
        add(instance_doc.get("publicIpAddress"))
        add(instance_doc.get("ip"))
        add(instance_doc.get("ip_address"))
        add(instance_doc.get("network"))
        add(instance_doc.get("addresses"))

        candidates = _dedupe_preserve_order(candidates)
        return host, port, candidates

    def _normalize_instance_order(self, instances: Sequence[InstanceDoc]) -> list[InstanceDoc]:
        """Return instances in stable, user-expected order.

        Strategy:
          1. If names end with numeric suffix (e.g., 'job-0', 'job-1'), sort ascending.
          2. Otherwise, sort by created_at ascending (oldest first = node 0).
        """
        if not instances:
            return []

        docs = list(instances)

        def suffix_or_none(doc: InstanceDoc) -> int | None:
            name = str(doc.get("name") or doc.get("fid") or "")
            match = re.search(r"-(\d+)$", name)
            return int(match.group(1)) if match else None

        suffixes = [suffix_or_none(d) for d in docs]
        if all(s is not None for s in suffixes):
            paired = sorted(zip(suffixes, docs, strict=True), key=lambda x: x[0])  # type: ignore[arg-type]
            return [doc for _, doc in paired]

        def created_at(doc: InstanceDoc) -> datetime:
            ts = _safe_parse_iso8601(doc.get("created_at")) or _safe_parse_iso8601(
                doc.get("createdAt")
            )
            return ts or datetime.min

        return sorted(docs, key=created_at)
