"""Container management activities for Temporal workflows.

These activities manage K8s Deployments, Services, and KEDA ScaledObjects
for function containers.
"""

from __future__ import annotations

import logging

from flow.adapters.providers.builtin.serverless.temporal.workflows.inputs import (
    EnsureContainerInput,
)

try:
    from temporalio import activity
except ImportError:
    activity = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


async def _ensure_container_ready(input: EnsureContainerInput) -> str:
    """Ensure K8s Deployment exists and has at least 1 Ready pod.

    Returns the internal service endpoint URL.

    Steps:
        1. Check if deployment exists.
        2. If not, create Deployment + Service + KEDA ScaledObject.
        3. Wait for at least 1 Ready pod.

    Args:
        input: Container configuration including function name, image, GPU spec.

    Returns:
        Service endpoint URL (e.g. "http://flow-fn-myfunction.flow-serverless.svc.cluster.local:8080").
    """
    from flow.adapters.providers.builtin.serverless.k8s.resources import (
        build_function_manifests,
    )

    deployment_name = f"flow-fn-{input.function_name}"
    namespace = input.namespace

    # Generate K8s manifests for deployment + service + KEDA scaler.
    # In production, these are applied to K8s and readiness is awaited.
    build_function_manifests(
        name=deployment_name,
        image=input.image_ref,
        gpu=input.gpu,
        namespace=namespace,
        min_replicas=input.min_containers,
        max_replicas=input.max_containers,
        scaledown_seconds=input.scaledown_window,
    )

    logger.info(
        "Ensuring container ready: deployment=%s namespace=%s gpu=%s",
        deployment_name,
        namespace,
        input.gpu,
    )
    endpoint = f"http://{deployment_name}.{namespace}.svc.cluster.local:8080"
    return endpoint


if activity is not None:
    ensure_container_ready = activity.defn(_ensure_container_ready)
else:
    ensure_container_ready = _ensure_container_ready  # type: ignore[assignment]
