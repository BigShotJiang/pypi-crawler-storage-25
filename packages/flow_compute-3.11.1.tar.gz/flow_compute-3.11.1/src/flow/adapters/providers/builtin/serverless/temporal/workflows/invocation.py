"""FunctionInvocationWorkflow -- core workflow for a single .remote() call.

Orchestrates: image build -> container readiness -> request dispatch.
Each step is a Temporal activity with independent retry and timeout.
"""

from __future__ import annotations

from datetime import timedelta

from flow.adapters.providers.builtin.serverless.temporal.workflows.inputs import (
    DispatchInput,
    EnsureContainerInput,
    EnsureImageInput,
    FunctionInvocationInput,
)

__all__ = [
    "DispatchInput",
    "EnsureContainerInput",
    "EnsureImageInput",
    "FunctionInvocationInput",
    "FunctionInvocationWorkflow",
]

try:
    from temporalio import workflow

    with workflow.unsafe.imports_passed_through():
        from flow.adapters.providers.builtin.serverless.temporal.activities.container import (
            ensure_container_ready,
        )
        from flow.adapters.providers.builtin.serverless.temporal.activities.dispatch import (
            dispatch_request,
        )
        from flow.adapters.providers.builtin.serverless.temporal.activities.image import (
            ensure_image,
        )
except ImportError:
    # temporalio not installed; define stubs for import-time safety
    workflow = None  # type: ignore[assignment]


if workflow is not None:

    @workflow.defn
    class FunctionInvocationWorkflow:
        """Temporal workflow for a single function invocation.

        Steps:
            1. Ensure container image exists in registry (build if needed).
            2. Ensure K8s Deployment + Service + KEDA ScaledObject exist.
            3. Dispatch serialized function call to container via HTTP.
        """

        @workflow.run
        async def run(self, input: FunctionInvocationInput) -> bytes:
            # 1. Ensure container image exists
            image_ref = await workflow.execute_activity(
                ensure_image,
                EnsureImageInput(
                    image_spec=input.image_spec,
                    registry="",  # Filled by activity from context
                    project="",
                    function_name=input.function_name,
                ),
                start_to_close_timeout=timedelta(minutes=30),
            )

            # 2. Ensure K8s resources exist and at least 1 pod is ready
            endpoint = await workflow.execute_activity(
                ensure_container_ready,
                EnsureContainerInput(
                    function_name=input.function_name,
                    image_ref=image_ref,
                    gpu=input.instance_type,
                    namespace=input.namespace,
                    volume_ids=input.volume_ids,
                    min_containers=input.min_containers,
                    max_containers=input.max_containers,
                    scaledown_window=input.scaledown_window,
                ),
                start_to_close_timeout=timedelta(minutes=10),
            )

            # 3. Dispatch function call to container
            result = await workflow.execute_activity(
                dispatch_request,
                DispatchInput(
                    endpoint=endpoint,
                    function_name=input.function_name,
                    args_serialized=input.args_serialized,
                    timeout_seconds=input.timeout_seconds,
                ),
                start_to_close_timeout=timedelta(seconds=input.timeout_seconds),
            )

            return result

else:
    # Stub when temporalio is not installed
    class FunctionInvocationWorkflow:  # type: ignore[no-redef]
        """Stub workflow class when temporalio is not installed."""

        async def run(self, input: FunctionInvocationInput) -> bytes:
            raise ImportError(
                "The serverless backend requires 'temporalio'. "
                "Install it with: pip install 'flow-compute[serverless]'"
            )
