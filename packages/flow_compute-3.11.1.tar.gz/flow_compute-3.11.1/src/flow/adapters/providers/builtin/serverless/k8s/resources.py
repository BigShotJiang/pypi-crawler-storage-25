"""K8s manifest generation for serverless function deployments.

Generates Deployment + Service + KEDA ScaledObject manifests from function
configuration. All manifests are pure dicts -- no K8s client dependency at
generation time.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# GPU type to K8s resource mapping
_GPU_RESOURCE_MAP: dict[str, dict[str, str]] = {
    "a100": {"nvidia.com/gpu": "1"},
    "a100:2": {"nvidia.com/gpu": "2"},
    "a100:4": {"nvidia.com/gpu": "4"},
    "a100:8": {"nvidia.com/gpu": "8"},
    "h100": {"nvidia.com/gpu": "1"},
    "h100:2": {"nvidia.com/gpu": "2"},
    "h100:4": {"nvidia.com/gpu": "4"},
    "h100:8": {"nvidia.com/gpu": "8"},
    "l40s": {"nvidia.com/gpu": "1"},
    "t4": {"nvidia.com/gpu": "1"},
}


def _gpu_to_k8s_resource(gpu: str) -> dict[str, str]:
    """Map a GPU spec string to K8s resource limits.

    Args:
        gpu: GPU specification (e.g. "a100", "h100:8").

    Returns:
        K8s resource limits dict (e.g. {"nvidia.com/gpu": "1"}).
    """
    if not gpu:
        return {}

    normalized = gpu.lower().strip()
    if normalized in _GPU_RESOURCE_MAP:
        return _GPU_RESOURCE_MAP[normalized]

    # Parse "NxGPU" or "GPU:N" patterns
    if ":" in normalized:
        gpu_type, count = normalized.rsplit(":", 1)
        return {"nvidia.com/gpu": count}
    if "x" in normalized:
        count, gpu_type = normalized.split("x", 1)
        return {"nvidia.com/gpu": count}

    # Default: single GPU
    return {"nvidia.com/gpu": "1"}


def build_function_manifests(
    name: str,
    image: str,
    gpu: str,
    namespace: str,
    min_replicas: int = 0,
    max_replicas: int = 100,
    scaledown_seconds: int = 60,
    concurrency_target: int = 1,
    port: int = 8080,
) -> list[dict[str, Any]]:
    """Generate K8s Deployment + Service + KEDA ScaledObject for a function.

    Args:
        name: Deployment name (e.g. "flow-fn-my-function").
        image: Container image reference.
        gpu: GPU specification for resource limits.
        namespace: K8s namespace.
        min_replicas: Minimum replica count (0 = scale-to-zero).
        max_replicas: Maximum replica count.
        scaledown_seconds: KEDA cooldown period.
        concurrency_target: Target concurrent requests per replica.
        port: Container port for the function server.

    Returns:
        List of K8s resource dicts [Deployment, Service, ScaledObject].
    """
    gpu_resource = _gpu_to_k8s_resource(gpu)
    labels = {"flow.ai/function": name}

    deployment: dict[str, Any] = {
        "apiVersion": "apps/v1",
        "kind": "Deployment",
        "metadata": {
            "name": name,
            "namespace": namespace,
            "labels": labels,
        },
        "spec": {
            "replicas": max(min_replicas, 1),
            "selector": {"matchLabels": labels},
            "template": {
                "metadata": {"labels": labels},
                "spec": {
                    "containers": [
                        {
                            "name": "function",
                            "image": image,
                            "ports": [{"containerPort": port}],
                            "resources": {"limits": gpu_resource} if gpu_resource else {},
                            "readinessProbe": {
                                "httpGet": {"path": "/health", "port": port},
                                "initialDelaySeconds": 5,
                                "periodSeconds": 5,
                            },
                        }
                    ],
                    "tolerations": (
                        [
                            {
                                "key": "nvidia.com/gpu",
                                "operator": "Exists",
                                "effect": "NoSchedule",
                            }
                        ]
                        if gpu_resource
                        else []
                    ),
                },
            },
        },
    }

    service: dict[str, Any] = {
        "apiVersion": "v1",
        "kind": "Service",
        "metadata": {
            "name": name,
            "namespace": namespace,
        },
        "spec": {
            "selector": labels,
            "ports": [{"port": port, "targetPort": port}],
        },
    }

    scaled_object: dict[str, Any] = {
        "apiVersion": "keda.sh/v1alpha1",
        "kind": "ScaledObject",
        "metadata": {
            "name": f"{name}-scaler",
            "namespace": namespace,
        },
        "spec": {
            "scaleTargetRef": {"name": name},
            "minReplicaCount": min_replicas,
            "maxReplicaCount": max_replicas,
            "cooldownPeriod": scaledown_seconds,
            "triggers": [
                {
                    "type": "prometheus",
                    "metadata": {
                        "serverAddress": "http://prometheus.monitoring:9090",
                        "metricName": f"flow_fn_{name}_pending_requests",
                        "query": (f'sum(flow_function_pending_requests{{function="{name}"}})'),
                        "threshold": str(concurrency_target),
                    },
                }
            ],
        },
    }

    return [deployment, service, scaled_object]


def build_http_scaled_object(
    name: str,
    namespace: str,
    project: str,
    function_name: str,
    port: int = 8080,
    min_replicas: int = 0,
    max_replicas: int = 100,
    concurrency_target: int = 1,
    scaledown_seconds: int = 60,
) -> dict[str, Any]:
    """Generate KEDA HTTPScaledObject for web endpoints.

    Args:
        name: Deployment name.
        namespace: K8s namespace.
        project: Project ID for URL generation.
        function_name: Function name for URL generation.
        port: Container port.
        min_replicas: Minimum replica count.
        max_replicas: Maximum replica count.
        concurrency_target: Target concurrent requests per replica.
        scaledown_seconds: Cooldown period.

    Returns:
        K8s HTTPScaledObject resource dict.
    """
    return {
        "apiVersion": "http.keda.sh/v1alpha1",
        "kind": "HTTPScaledObject",
        "metadata": {
            "name": f"{name}-http",
            "namespace": namespace,
        },
        "spec": {
            "hosts": [f"{project}--{function_name}.flow.run"],
            "targetPendingRequests": concurrency_target,
            "scaleTargetRef": {
                "deployment": name,
                "service": name,
                "port": port,
            },
            "replicas": {
                "min": min_replicas,
                "max": max_replicas,
            },
            "scalingMetric": {
                "requestRate": {"targetValue": concurrency_target},
            },
            "scaledownPeriod": scaledown_seconds,
        },
    }
