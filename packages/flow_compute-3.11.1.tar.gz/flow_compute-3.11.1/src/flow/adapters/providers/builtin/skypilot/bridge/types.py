"""Bridge DTOs for SkyPilot integration.

These types are internal to the bridge and provider.
They translate SkyPilot types to Flow-compatible structures.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flow.sdk.models import TaskStatus


@dataclass(frozen=True)
class ClusterInfo:
    """Bridge DTO for cluster information.

    This is Flow's representation, NOT sky.ClusterStatus.
    """

    name: str
    status: TaskStatus
    cloud: str
    region: str
    instance_type: str
    ip_address: str | None
    ssh_user: str | None = None


@dataclass(frozen=True)
class LaunchResult:
    """Bridge DTO for task launch result.

    This is Flow's representation, NOT sky tuple return.
    """

    cluster_name: str
    job_id: int | None
    status: str


@dataclass(frozen=True)
class JobInfo:
    """Bridge DTO for job information."""

    job_id: int
    status: TaskStatus
    name: str | None
    start_time: str | None
    end_time: str | None


@dataclass(frozen=True)
class DevClusterInfo:
    """Bridge DTO for dev cluster (persistent VM) information.

    Dev clusters differ from ephemeral task clusters:
    - They persist after command completion
    - They can be stopped/started
    - They support interactive SSH and command execution
    """

    name: str
    status: TaskStatus
    ip_address: str | None
    cloud: str
    region: str
    instance_type: str
    ssh_user: str | None = None
    uptime_hours: float | None = None
    launched_at: str | None = None


@dataclass(frozen=True)
class ExecResult:
    """Result of executing a command on a dev cluster."""

    job_id: int
    status: str  # pending, running, completed, failed
    cluster_name: str


@dataclass(frozen=True)
class StorageInfo:
    """Bridge DTO for cloud storage information.

    SkyPilot uses cloud object storage (GCS, S3, Azure Blob) for persistent
    storage that survives cluster termination.
    """

    name: str
    store_type: str  # s3, gcs, azure, r2
    status: str  # ready, syncing, error
    source: str | None = None  # Local path synced to storage
    bucket_name: str | None = None  # Actual cloud bucket name
    region: str | None = None
