"""Selection facet - handles region and instance selection logic."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from flow.protocols.selection import PlacementDecision
from flow.sdk.models import TaskConfig

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.mithril.provider.context import MithrilContext

logger = logging.getLogger(__name__)


class SelectionFacet:
    """Handles region and instance selection logic."""

    def __init__(self, ctx: MithrilContext) -> None:
        self.ctx = ctx

    def select_region_and_instance(
        self, *, adjusted_config: TaskConfig, instance_type: str, instance_fid: str
    ) -> PlacementDecision:
        """Select optimal region and instance for task."""
        return self.ctx.bids.select_region_and_instance(adjusted_config, instance_type)

    def normalize_instance_request(
        self, gpu_count: int, gpu_type: str | None = None
    ) -> dict[str, Any]:
        """Normalize GPU request to standard format."""
        request = {"gpu_count": gpu_count}

        if gpu_type:
            gpu_type_lower = gpu_type.lower()

            gpu_aliases = {
                "a100": "a100",
                "a100-80": "a100.80gb",
                "a100-40": "a100.40gb",
                "h100": "h100",
                "h100-80": "h100.80gb",
                "a6000": "a6000",
                "a40": "a40",
                "l40": "l40",
                "l40s": "l40s",
            }

            normalized_type = gpu_aliases.get(gpu_type_lower, gpu_type)
            request["gpu_type"] = normalized_type

            if gpu_count == 1:
                request["instance_type"] = f"1x{normalized_type}"
            else:
                request["instance_type"] = f"{gpu_count}x{normalized_type}"

        return request

    def apply_instance_constraints(self, config: TaskConfig, instance_type: str) -> TaskConfig:
        """Apply provider-specific constraints based on instance type."""
        return config
