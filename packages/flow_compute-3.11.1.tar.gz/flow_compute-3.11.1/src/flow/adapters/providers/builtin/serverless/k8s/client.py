"""Default ``K8sClient`` implementation using the official ``kubernetes`` SDK.

All ``kubernetes`` imports happen lazily inside ``KubernetesApiClient`` to
keep cold-import of the ``flow`` package fast; the serverless extra is the
only install path that actually needs this module at runtime.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from flow.adapters.providers.builtin.serverless.k8s.client_protocol import (
    DeploymentStatus,
    K8sClient,
)

if TYPE_CHECKING:
    from kubernetes.client import AppsV1Api, CoreV1Api, CustomObjectsApi

logger = logging.getLogger(__name__)

_FIELD_MANAGER = "flow-serverless"

# KEDA custom-resource groups keyed by manifest apiVersion.
_CUSTOM_OBJECT_GROUPS: dict[str, tuple[str, str, str]] = {
    # (group, version, plural)
    "keda.sh/v1alpha1": ("keda.sh", "v1alpha1", "scaledobjects"),
    "http.keda.sh/v1alpha1": ("http.keda.sh", "v1alpha1", "httpscaledobjects"),
}


class KubernetesApiClient(K8sClient):
    """Production ``K8sClient`` backed by the official Python SDK.

    The three API handles (``AppsV1Api``, ``CoreV1Api``, ``CustomObjectsApi``)
    may be injected directly, which is how tests substitute mocks. When no
    handles are passed, configuration is loaded from the cluster (in-cluster
    service account) or the user's kubeconfig.

    Args:
        apps_api: AppsV1Api for Deployments.
        core_api: CoreV1Api for Services.
        custom_api: CustomObjectsApi for KEDA CRDs.
    """

    def __init__(
        self,
        apps_api: AppsV1Api | None = None,
        core_api: CoreV1Api | None = None,
        custom_api: CustomObjectsApi | None = None,
    ) -> None:
        if apps_api is None or core_api is None or custom_api is None:
            from kubernetes import client, config  # deferred heavy import

            try:
                config.load_incluster_config()
            except config.ConfigException:
                config.load_kube_config()
            self._apps = apps_api or client.AppsV1Api()
            self._core = core_api or client.CoreV1Api()
            self._custom = custom_api or client.CustomObjectsApi()
        else:
            self._apps = apps_api
            self._core = core_api
            self._custom = custom_api

    # -- K8sClient protocol --------------------------------------------------

    def apply_manifests(
        self,
        manifests: list[dict[str, object]],
        namespace: str,
        request_timeout_s: float = 30.0,
    ) -> None:
        for manifest in manifests:
            kind = manifest.get("kind")
            if not isinstance(kind, str):
                raise ValueError(f"manifest missing 'kind': {manifest!r}")  # noqa: TRY004
            ns = _effective_namespace(manifest, namespace)
            name = _manifest_name(manifest)
            logger.info("Applying %s/%s in %s", kind, name, ns)
            self._dispatch_apply(kind, manifest, ns, request_timeout_s)

    def delete_deployment(
        self,
        name: str,
        namespace: str,
        request_timeout_s: float = 30.0,
    ) -> None:
        from kubernetes.client.exceptions import ApiException

        delete_opts = _foreground_delete_options()
        try:
            self._apps.delete_namespaced_deployment(
                name=name,
                namespace=namespace,
                body=delete_opts,
                _request_timeout=request_timeout_s,
            )
        except ApiException as exc:
            if exc.status != 404:
                raise
            logger.info("Deployment %s/%s already absent", namespace, name)

        try:
            self._core.delete_namespaced_service(
                name=name,
                namespace=namespace,
                body=delete_opts,
                _request_timeout=request_timeout_s,
            )
        except ApiException as exc:
            if exc.status != 404:
                raise
            logger.info("Service %s/%s already absent", namespace, name)

    def wait_for_ready(
        self,
        name: str,
        namespace: str,
        timeout_s: int,
        poll_interval_s: float = 2.0,
    ) -> DeploymentStatus:
        if timeout_s <= 0:
            raise ValueError(f"timeout_s must be positive, got {timeout_s}")
        deadline = time.monotonic() + timeout_s
        last_status: DeploymentStatus | None = None
        while True:
            last_status = self.get_deployment_status(name, namespace)
            if last_status.is_ready:
                return last_status
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"deployment {namespace}/{name} not ready within "
                    f"{timeout_s}s; last status={last_status}"
                )
            time.sleep(poll_interval_s)

    def get_deployment_status(
        self,
        name: str,
        namespace: str,
        request_timeout_s: float = 30.0,
    ) -> DeploymentStatus:
        dep = self._apps.read_namespaced_deployment_status(
            name=name,
            namespace=namespace,
            _request_timeout=request_timeout_s,
        )
        return _deployment_status_from_api(dep, name=name, namespace=namespace)

    # -- Internals -----------------------------------------------------------

    def _dispatch_apply(
        self,
        kind: str,
        manifest: dict[str, object],
        namespace: str,
        timeout_s: float,
    ) -> None:
        """Route a manifest to the correct API method."""
        if kind == "Deployment":
            self._apply_namespaced(
                manifest,
                namespace,
                timeout_s,
                patch_fn=self._apps.patch_namespaced_deployment,
                create_fn=self._apps.create_namespaced_deployment,
            )
            return
        if kind == "Service":
            self._apply_namespaced(
                manifest,
                namespace,
                timeout_s,
                patch_fn=self._core.patch_namespaced_service,
                create_fn=self._core.create_namespaced_service,
            )
            return
        api_version = manifest.get("apiVersion")
        if isinstance(api_version, str) and api_version in _CUSTOM_OBJECT_GROUPS:
            self._apply_custom_object(api_version, manifest, namespace, timeout_s)
            return
        raise ValueError(f"unsupported manifest kind: {kind} (apiVersion={api_version})")

    def _apply_namespaced(
        self,
        manifest: dict[str, object],
        namespace: str,
        timeout_s: float,
        *,
        patch_fn: Callable[..., Any],
        create_fn: Callable[..., Any],
    ) -> None:
        """Server-side apply a namespaced resource, falling back to create on 404."""
        from kubernetes.client.exceptions import ApiException

        name = _manifest_name(manifest)
        try:
            patch_fn(
                name=name,
                namespace=namespace,
                body=manifest,
                field_manager=_FIELD_MANAGER,
                force=True,
                _content_type="application/apply-patch+yaml",
                _request_timeout=timeout_s,
            )
        except ApiException as exc:
            if exc.status == 404:
                create_fn(
                    namespace=namespace,
                    body=manifest,
                    _request_timeout=timeout_s,
                )
                return
            raise

    def _apply_custom_object(
        self,
        api_version: str,
        manifest: dict[str, object],
        namespace: str,
        timeout_s: float,
    ) -> None:
        from kubernetes.client.exceptions import ApiException

        group, version, plural = _CUSTOM_OBJECT_GROUPS[api_version]
        name = _manifest_name(manifest)
        shared_kwargs = {
            "group": group,
            "version": version,
            "namespace": namespace,
            "plural": plural,
            "body": manifest,
            "_request_timeout": timeout_s,
        }
        try:
            self._custom.patch_namespaced_custom_object(name=name, **shared_kwargs)
        except ApiException as exc:
            if exc.status == 404:
                self._custom.create_namespaced_custom_object(**shared_kwargs)
                return
            raise


# -- Helpers ----------------------------------------------------------------


def _manifest_name(manifest: dict[str, object]) -> str:
    metadata = manifest.get("metadata")
    if isinstance(metadata, dict):
        name = metadata.get("name")
        if isinstance(name, str) and name:
            return name
    raise ValueError(f"manifest missing metadata.name: {manifest!r}")


def _effective_namespace(manifest: dict[str, object], default: str) -> str:
    metadata = manifest.get("metadata")
    if isinstance(metadata, dict):
        ns = metadata.get("namespace")
        if isinstance(ns, str) and ns:
            return ns
    return default


def _foreground_delete_options() -> Any:
    """Build a foreground-propagation DeleteOptions object."""
    from kubernetes.client.models import V1DeleteOptions

    return V1DeleteOptions(propagation_policy="Foreground")


def _deployment_status_from_api(
    dep: Any,
    *,
    name: str,
    namespace: str,
) -> DeploymentStatus:
    """Translate an AppsV1 Deployment object to ``DeploymentStatus``."""
    spec = getattr(dep, "spec", None)
    status = getattr(dep, "status", None)
    metadata = getattr(dep, "metadata", None)
    replicas = _int_attr(spec, "replicas", default=0)
    ready_replicas = _int_attr(status, "ready_replicas", default=0)
    observed = _int_attr(status, "observed_generation", default=0)
    generation = _int_attr(metadata, "generation", default=0)
    raw_conditions = getattr(status, "conditions", None) or []
    conditions: list[dict[str, str]] = []
    for cond in raw_conditions:
        conditions.append(
            {
                "type": str(getattr(cond, "type", "") or ""),
                "status": str(getattr(cond, "status", "") or ""),
                "reason": str(getattr(cond, "reason", "") or ""),
                "message": str(getattr(cond, "message", "") or ""),
            }
        )
    return DeploymentStatus(
        name=name,
        namespace=namespace,
        replicas=replicas,
        ready_replicas=ready_replicas,
        observed_generation=observed,
        generation=generation,
        conditions=conditions,
    )


def _int_attr(obj: Any, attr: str, *, default: int) -> int:
    """Read an int-or-None attribute from a K8s model, falling back to default."""
    value = getattr(obj, attr, None)
    if value is None:
        return default
    return int(value)
