"""Mithril-specific pricing adapter.

Adapts the domain pricing service to work with Mithril's API,
handling provider-specific details while delegating core logic
to the domain service.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from flow.adapters.providers.builtin.mithril.api.client import MithrilApiClient
from flow.core.utils.pricing_cache import PricingCache
from flow.errors import InsufficientBidPriceError, ValidationAPIError

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.mithril.domain.catalog import CatalogService

logger = logging.getLogger(__name__)


class PricingService:
    """Mithril-specific pricing adapter."""

    def __init__(
        self,
        api: MithrilApiClient,
        *,
        catalog: CatalogService | None = None,
    ) -> None:
        self._api = api
        self._catalog = catalog
        self._parser = _SimplePriceParser()

    def set_catalog(self, catalog: CatalogService) -> None:
        """Attach CatalogService after construction (breaks init cycle)."""
        self._catalog = catalog

    def parse_price(self, price_str: str | None) -> float:
        """Parse a price string like "$10.00" to a float."""
        return self._parser.parse(price_str)

    def get_spot_price(
        self,
        instance_type_id: str,
        region: str,
        *,
        cache: PricingCache | None = None,
    ) -> float | None:
        """Get spot price with disk cache and structured API fallback.

        Resolution order:
            1. PricingCache disk lookup (~1ms)
            2. /v2/pricing/current endpoint (authoritative, structured)
            3. CatalogService snapshot fallback (no extra API call)
            4. Save to cache on any successful fetch
        """
        # 1. Cache hit
        if cache is not None:
            cached = cache.get(instance_type_id, region)
            if cached is not None:
                cents = cached.get("spot_price_cents")
                if isinstance(cents, int) and cents > 0:
                    return cents / 100.0

        # 2. Try /v2/pricing/current (structured endpoint)
        price = self._fetch_from_pricing_endpoint(instance_type_id, region)

        # 3. Fall back to CatalogService snapshot (no network call)
        if price is None and self._catalog is not None:
            price = self._get_price_from_catalog(instance_type_id, region)

        # 4. Save on success
        if price is not None and price > 0 and cache is not None:
            cache.save(
                instance_type_id,
                region,
                {"spot_price_cents": int(price * 100)},
            )

        return price

    def _fetch_from_pricing_endpoint(self, instance_type_id: str, region: str) -> float | None:
        """Fetch from /v2/pricing/current. Returns dollars or None."""
        try:
            resp = self._api.get_current_prices(instance_type_id, region=region)
            cents = resp.get("spot_price_cents") if isinstance(resp, dict) else None
            if isinstance(cents, int) and cents > 0:
                return cents / 100.0
        except Exception:  # noqa: BLE001
            logger.debug("Failed to fetch from /v2/pricing/current", exc_info=True)
        return None

    def _get_price_from_catalog(self, instance_type_id: str, region: str) -> float | None:
        """Read price from catalog snapshot. No API call."""
        if self._catalog is None:
            return None
        offerings = self._catalog.offerings_by_region(instance_type_id)
        offering = offerings.get(region)
        if offering is not None and offering.price_per_hour > 0:
            return offering.price_per_hour
        return None

    def get_current_market_price(self, instance_type_id: str, region: str) -> float | None:
        """Fetch current market price for an instance type in a region."""
        # Try catalog first (no API call)
        if self._catalog is not None:
            price = self._get_price_from_catalog(instance_type_id, region)
            if price is not None:
                return price

        # Fallback to pricing endpoint
        return self._fetch_from_pricing_endpoint(instance_type_id, region)

    def is_price_validation_error(self, error: ValidationAPIError) -> bool:
        """Detect whether a ValidationAPIError is price-related."""
        if not getattr(error, "validation_errors", None):
            return False
        price_keywords = ["price", "bid", "limit_price", "minimum", "insufficient"]
        for item in error.validation_errors:
            msg = str(item.get("msg", "")).lower()
            loc = item.get("loc", [])
            if any("price" in str(f).lower() for f in loc):
                return True
            if any(k in msg for k in price_keywords):
                return True
        return False

    def enhance_price_error(
        self,
        error: ValidationAPIError,
        *,
        instance_type_id: str,
        region: str,
        attempted_price: float | None,
        instance_display_name: str,
    ) -> InsufficientBidPriceError:
        """Augment a price validation error with current pricing and advice."""
        try:
            auctions = self._api.list_spot_availability(
                {"instance_type": instance_type_id, "region": region}
            )
            if not auctions:
                raise error
            auction = None
            if len(auctions) == 1:
                auction = auctions[0]
            else:
                for a in auctions:
                    if a.get("region") == region and a.get("instance_type") == instance_type_id:
                        auction = a
                        break
            auction = auction or auctions[0]
            current_price = self.parse_price(auction.get("last_instance_price"))
            min_bid_price = self.parse_price(auction.get("min_bid_price"))
            effective = max(v for v in [current_price, min_bid_price] if v is not None)
            recommended = effective * 1.5
            message = (
                f"Bid price ${attempted_price:.2f}/hour is too low for {instance_display_name} "
                f"in {region}. Current spot price is ${effective:.2f}/hour."
            )
            return InsufficientBidPriceError(
                message=message,
                current_price=effective,
                min_bid_price=min_bid_price or None,
                recommended_price=recommended,
                instance_type=instance_display_name,
                region=region,
                response=getattr(error, "response", None),
            )
        except (ValueError, TypeError, KeyError):
            raise error


class _SimplePriceParser:
    """Minimal price parser for dollar-formatted strings like "$10.00"."""

    def parse(self, price_str: str | None) -> float:
        if price_str is None:
            raise ValueError("price is None")
        s = str(price_str).strip()
        if not s:
            raise ValueError("empty price")
        if s.startswith("$"):
            s = s[1:]
        s = s.replace(",", "")
        return float(s)
