"""Container entrypoint for serverless function execution.

This module runs inside the user's container. It starts a lightweight HTTP
server (Starlette) that receives function invocations, deserializes arguments,
calls the user function, and returns serialized results.

The server supports:
- /invoke: Single function invocation (POST).
- /invoke_batch: Batched invocations for dynamic batching (POST).
- /health: Readiness probe (GET).

Environment variables:
- FLOW_FUNCTION_MODULE: Python module containing the function.
- FLOW_FUNCTION_NAME: Function name to import and call.
- FLOW_CLASS_NAME: Class name for @app.cls() functions (optional).
- FLOW_MAX_CONCURRENCY: Max concurrent invocations (default 1).
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import os
from concurrent.futures import ThreadPoolExecutor
from typing import Any

logger = logging.getLogger(__name__)

# Loaded at startup from env vars
_function: Any = None
_instance: Any = None
_executor: ThreadPoolExecutor | None = None
_semaphore: asyncio.Semaphore | None = None


def _load_function() -> None:
    """Import the user function from env-configured module and name."""
    global _function, _instance, _executor, _semaphore

    module_name = os.environ.get("FLOW_FUNCTION_MODULE", "")
    function_name = os.environ.get("FLOW_FUNCTION_NAME", "")
    class_name = os.environ.get("FLOW_CLASS_NAME", "")
    max_concurrency = int(os.environ.get("FLOW_MAX_CONCURRENCY", "1"))

    if not module_name or not function_name:
        logger.warning(
            "FLOW_FUNCTION_MODULE and FLOW_FUNCTION_NAME must be set; "
            "function will not be loadable until configured"
        )
        return

    module = importlib.import_module(module_name)

    if class_name:
        cls = getattr(module, class_name)
        _instance = cls()
        _function = getattr(_instance, function_name)
    else:
        _function = getattr(module, function_name)

    _executor = ThreadPoolExecutor(max_workers=max_concurrency)
    _semaphore = asyncio.Semaphore(max_concurrency)

    logger.info(
        "Loaded function %s.%s (concurrency=%d)",
        module_name,
        function_name,
        max_concurrency,
    )


def create_app() -> Any:
    """Create and return the Starlette application.

    Returns:
        Starlette app instance with routes configured.

    Raises:
        ImportError: If starlette is not installed.
    """
    try:
        from starlette.applications import Starlette
        from starlette.requests import Request
        from starlette.responses import Response
        from starlette.routing import Route
    except ImportError as e:
        raise ImportError(
            "Container runtime requires 'starlette'. "
            "Install it with: pip install 'flow-compute[serverless]'"
        ) from e

    import cloudpickle

    async def invoke(request: Request) -> Response:
        """Handle a single function invocation."""
        body = await request.body()
        args, kwargs = cloudpickle.loads(body) if body else ((), {})

        method_name = request.headers.get("X-Flow-Method")

        if _semaphore is not None:
            async with _semaphore:
                result = await _execute(args, kwargs, method_name)
        else:
            result = await _execute(args, kwargs, method_name)

        return Response(
            content=cloudpickle.dumps(result),
            media_type="application/octet-stream",
        )

    async def invoke_batch(request: Request) -> Response:
        """Handle a batched function invocation."""
        body = await request.body()
        batch = cloudpickle.loads(body) if body else []
        method_name = request.headers.get("X-Flow-Method")

        if method_name and _instance is not None:
            method = getattr(_instance, method_name)
            results = method(batch)
        elif _function is not None:
            results = _function(batch)
        else:
            raise RuntimeError("Function not loaded")

        return Response(
            content=cloudpickle.dumps(results),
            media_type="application/octet-stream",
        )

    async def health(request: Request) -> Response:
        """Readiness probe endpoint."""
        return Response("ok")

    # Load function on app startup
    _load_function()

    return Starlette(
        routes=[
            Route("/invoke", invoke, methods=["POST"]),
            Route("/invoke_batch", invoke_batch, methods=["POST"]),
            Route("/health", health, methods=["GET"]),
        ],
    )


async def _execute(
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    method_name: str | None = None,
) -> Any:
    """Execute the user function, handling both sync and async callables."""
    if method_name and _instance is not None:
        target = getattr(_instance, method_name)
    elif _function is not None:
        target = _function
    else:
        raise RuntimeError("Function not loaded")

    if asyncio.iscoroutinefunction(target):
        return await target(*args, **kwargs)

    # Run sync functions in thread pool to avoid blocking the event loop
    loop = asyncio.get_running_loop()
    if _executor is not None:
        return await loop.run_in_executor(_executor, lambda: target(*args, **kwargs))
    return await loop.run_in_executor(None, lambda: target(*args, **kwargs))
