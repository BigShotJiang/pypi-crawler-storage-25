"""Dev mode operations for SkyPilot.

Provides higher-level operations for persistent interactive VMs.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING

from flow.sdk.models import TaskStatus

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.skypilot.bridge import DevClusterInfo, SkyBridge
    from flow.sdk.models.task_config import TaskConfig

logger = logging.getLogger(__name__)

# Default prefix for dev cluster names
DEV_CLUSTER_PREFIX = "flow-dev-"


@dataclass
class DevSession:
    """Represents an active dev session.

    A dev session wraps a persistent SkyPilot cluster with
    Flow-specific metadata and operations.
    """

    cluster_name: str
    status: TaskStatus
    ip_address: str | None
    cloud: str
    region: str
    instance_type: str
    uptime_hours: float | None = None
    ssh_user: str | None = None

    @property
    def ssh_command(self) -> str | None:
        """Get SSH command to connect to this dev session."""
        if self.ip_address:
            user = self.ssh_user or "ubuntu"
            return f"ssh -o StrictHostKeyChecking=no {user}@{self.ip_address}"
        return None

    @property
    def is_running(self) -> bool:
        """Check if the dev session is running."""
        return self.status == TaskStatus.RUNNING

    @property
    def is_stopped(self) -> bool:
        """Check if the dev session is stopped (paused)."""
        return self.status == TaskStatus.PAUSED


def generate_dev_cluster_name(
    name: str | None = None,
    prefix: str = DEV_CLUSTER_PREFIX,
) -> str:
    """Generate a unique dev cluster name.

    Args:
        name: Optional user-provided name
        prefix: Prefix for the cluster name

    Returns:
        Unique cluster name
    """
    if name:
        # Sanitize user-provided name
        sanitized = name.lower().replace(" ", "-").replace("_", "-")
        if not sanitized.startswith(prefix):
            sanitized = f"{prefix}{sanitized}"
        return sanitized

    # Generate unique name
    suffix = uuid.uuid4().hex[:6]
    return f"{prefix}{suffix}"


def dev_cluster_info_to_session(info: DevClusterInfo) -> DevSession:
    """Convert DevClusterInfo to DevSession.

    Args:
        info: DevClusterInfo from bridge

    Returns:
        DevSession domain object
    """
    return DevSession(
        cluster_name=info.name,
        status=info.status,
        ip_address=info.ip_address,
        cloud=info.cloud,
        region=info.region,
        instance_type=info.instance_type,
        uptime_hours=info.uptime_hours,
        ssh_user=info.ssh_user,
    )


class DevModeService:
    """Service for managing dev mode operations.

    Provides high-level operations for:
    - Starting dev sessions
    - Executing commands on dev sessions
    - Stopping/resuming dev sessions
    - Listing active dev sessions
    """

    def __init__(self, bridge: SkyBridge) -> None:
        """Initialize the dev mode service.

        Args:
            bridge: SkyBridge instance for SkyPilot operations
        """
        self._bridge = bridge

    def start_session(
        self,
        config: TaskConfig,
        cloud: str | None = None,
        accelerators: dict[str, int] | None = None,
        region: str | None = None,
        use_spot: bool = False,
        name: str | None = None,
    ) -> DevSession:
        """Start a new dev session.

        Args:
            config: Task configuration
            cloud: Target cloud provider
            accelerators: GPU requirements
            region: Target region
            use_spot: Whether to use spot instances
            name: Optional session name

        Returns:
            DevSession with cluster details
        """
        cluster_name = generate_dev_cluster_name(name)

        # Default to no GPUs if not specified
        if accelerators is None:
            accelerators = {}

        info = self._bridge.launch_dev_cluster(
            config=config,
            cloud=cloud,
            accelerators=accelerators,
            region=region,
            use_spot=use_spot,
            cluster_name=cluster_name,
        )

        return dev_cluster_info_to_session(info)

    def exec_command(
        self,
        cluster_name: str,
        command: str,
        env: dict[str, str] | None = None,
        stream_logs: bool = True,
    ) -> int:
        """Execute a command on a dev session.

        Args:
            cluster_name: Name of the dev cluster
            command: Command to execute
            env: Environment variables
            stream_logs: Whether to stream logs

        Returns:
            Job ID for tracking
        """
        result = self._bridge.exec_on_dev_cluster(
            cluster_name=cluster_name,
            command=command,
            env=env,
            stream_logs=stream_logs,
        )
        return result.job_id

    def stop_session(self, cluster_name: str) -> None:
        """Stop a dev session (pause without terminating).

        Args:
            cluster_name: Name of the dev cluster
        """
        self._bridge.stop_cluster(cluster_name)

    def resume_session(self, cluster_name: str) -> None:
        """Resume a stopped dev session.

        Args:
            cluster_name: Name of the dev cluster
        """
        self._bridge.start_cluster(cluster_name)

    def terminate_session(self, cluster_name: str) -> None:
        """Terminate a dev session (destroy cluster).

        Args:
            cluster_name: Name of the dev cluster
        """
        self._bridge.terminate_cluster(cluster_name)

    def get_session(self, cluster_name: str) -> DevSession | None:
        """Get dev session info.

        Args:
            cluster_name: Name of the dev cluster

        Returns:
            DevSession if exists, None otherwise
        """
        info = self._bridge.get_dev_cluster_info(cluster_name)
        if info is None:
            return None
        return dev_cluster_info_to_session(info)

    def list_sessions(self) -> list[DevSession]:
        """List all active dev sessions.

        Returns:
            List of DevSession objects
        """
        infos = self._bridge.list_dev_clusters(name_prefix=DEV_CLUSTER_PREFIX)
        return [dev_cluster_info_to_session(info) for info in infos]
