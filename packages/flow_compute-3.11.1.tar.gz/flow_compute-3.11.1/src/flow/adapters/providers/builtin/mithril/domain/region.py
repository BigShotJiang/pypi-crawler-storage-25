"""Region selection policy for the Mithril provider."""

from __future__ import annotations

from flow.adapters.providers.builtin.mithril.domain.models import Auction
from flow.adapters.providers.builtin.mithril.domain.pricing import PricingService


class RegionSelector:
    """Choose regions for spot instances from pre-fetched availability."""

    def __init__(self, pricing: PricingService) -> None:
        self._pricing = pricing

    def select_best_region(
        self, availability: dict[str, Auction], preferred_region: str | None = None
    ) -> str | None:
        """Choose a region given availability and an optional preferred region.

        Policy:
          1. Honor preferred region if available.
          2. Otherwise pick highest capacity, then lowest price.
        """
        if not availability:
            return None
        if preferred_region and preferred_region in availability:
            return preferred_region

        best_region: str | None = None
        best_capacity_price = (-1, float("inf"))
        for region, auction in availability.items():
            capacity = auction.capacity or 0
            price = self._pricing.parse_price(auction.last_instance_price)
            score = (capacity, price)
            if score[0] > best_capacity_price[0] or (
                score[0] == best_capacity_price[0] and score[1] < best_capacity_price[1]
            ):
                best_capacity_price = score
                best_region = region
        return best_region
