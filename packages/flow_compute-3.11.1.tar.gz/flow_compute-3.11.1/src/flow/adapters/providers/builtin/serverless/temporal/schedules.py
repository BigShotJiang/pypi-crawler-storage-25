"""Temporal Schedule management for scheduled function execution.

Maps flow.Cron and flow.Period objects to Temporal Schedule primitives.
No custom cron daemon or polling loop -- Temporal handles scheduling natively.
"""

from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any

logger = logging.getLogger(__name__)


async def create_schedule(
    client: Any,
    schedule_id: str,
    function_name: str,
    image_spec: dict[str, Any],
    instance_type: str,
    cron_expression: str | None = None,
    interval: timedelta | None = None,
    task_queue: str = "flow-serverless",
    namespace: str = "flow-serverless",
) -> Any:
    """Create a Temporal Schedule that triggers FunctionInvocationWorkflow.

    Args:
        client: Connected Temporal client.
        schedule_id: Unique schedule identifier.
        function_name: Function to invoke on each tick.
        image_spec: Serialized image build steps.
        instance_type: GPU type for the function.
        cron_expression: Standard cron expression (mutually exclusive with interval).
        interval: Interval between invocations (mutually exclusive with cron_expression).
        task_queue: Temporal task queue name.
        namespace: K8s namespace for deployments.

    Returns:
        Temporal ScheduleHandle.

    Raises:
        ValueError: If neither cron_expression nor interval is specified.
        ImportError: If temporalio is not installed.
    """
    if not cron_expression and not interval:
        raise ValueError("Either cron_expression or interval must be specified")

    try:
        from temporalio.client import (
            Schedule,
            ScheduleActionStartWorkflow,
            ScheduleIntervalSpec,
            ScheduleOverlapPolicy,
            SchedulePolicy,
            ScheduleSpec,
        )
    except ImportError as e:
        raise ImportError(
            "The serverless backend requires 'temporalio'. "
            "Install it with: pip install 'flow-compute[serverless]'"
        ) from e

    from flow.adapters.providers.builtin.serverless.temporal.workflows.invocation import (
        FunctionInvocationInput,
        FunctionInvocationWorkflow,
    )

    if cron_expression:
        spec = ScheduleSpec(cron_expressions=[cron_expression])
    else:
        spec = ScheduleSpec(intervals=[ScheduleIntervalSpec(every=interval)])

    logger.info(
        "Creating schedule %s for function %s (cron=%s, interval=%s)",
        schedule_id,
        function_name,
        cron_expression,
        interval,
    )

    return await client.create_schedule(
        schedule_id,
        Schedule(
            action=ScheduleActionStartWorkflow(
                FunctionInvocationWorkflow.run,
                FunctionInvocationInput(
                    function_name=function_name,
                    image_spec=image_spec,
                    instance_type=instance_type,
                    namespace=namespace,
                ),
                id=f"scheduled-{function_name}",
                task_queue=task_queue,
            ),
            spec=spec,
            policy=SchedulePolicy(overlap=ScheduleOverlapPolicy.SKIP),
        ),
    )


async def delete_schedule(client: Any, schedule_id: str) -> None:
    """Delete a Temporal Schedule.

    Args:
        client: Connected Temporal client.
        schedule_id: Schedule identifier to delete.
    """
    handle = client.get_schedule_handle(schedule_id)
    await handle.delete()
    logger.info("Deleted schedule %s", schedule_id)


async def list_schedules(client: Any) -> list[dict[str, Any]]:
    """List all Temporal Schedules.

    Args:
        client: Connected Temporal client.

    Returns:
        List of schedule info dicts with id, function_name, spec.
    """
    schedules = []
    async for schedule in client.list_schedules():
        schedules.append(
            {
                "id": schedule.id,
                "info": schedule.info,
            }
        )
    return schedules
