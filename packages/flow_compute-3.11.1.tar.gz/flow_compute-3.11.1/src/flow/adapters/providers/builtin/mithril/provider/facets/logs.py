"""Logs facet - handles task log retrieval and streaming."""

from __future__ import annotations

import logging
import time
from collections import OrderedDict
from collections.abc import Callable, Iterator
from typing import TYPE_CHECKING

from flow.adapters.providers.builtin.mithril.adapters.remote import RemoteExecutionError
from flow.adapters.providers.builtin.mithril.api.handlers import handle_mithril_errors
from flow.errors import FlowError
from flow.errors.messages import TASK_INSTANCE_NOT_ACCESSIBLE, format_error
from flow.utils.paths import HOST_LOG_FILE

if TYPE_CHECKING:
    from flow.adapters.providers.builtin.mithril.provider.context import MithrilContext
    from flow.adapters.providers.builtin.mithril.provider.provider import MithrilProvider

logger = logging.getLogger(__name__)


class LogsFacet:
    """Handles log operations for tasks."""

    def __init__(
        self, ctx: MithrilContext, get_remote_ops: Callable, provider: MithrilProvider
    ) -> None:
        """Initialize logs facet.

        Args:
            ctx: Mithril context with all dependencies
            get_remote_ops: Callable to get remote operations handler
            provider: Mithril provider instance
        """
        self.ctx = ctx
        self._logger = getattr(ctx, "logger", logger)
        self.get_remote_ops = get_remote_ops
        self.provider = provider

        # Connect LogService to remote ops
        if hasattr(self.ctx.log_service, "_remote"):
            self.ctx.log_service._remote = None  # Clear legacy internal

    @handle_mithril_errors("Get task logs")
    def get_task_logs(
        self, task_id: str, tail: int = 100, log_type: str = "stdout", *, node: int | None = None
    ) -> str:
        """Get recent logs for a task.

        Args:
            task_id: Task ID
            tail: Number of lines to retrieve
            log_type: Type of logs ("stdout" or "stderr")
            node: Node index for multi-instance tasks (defaults to 0)

        Returns:
            Log contents as string
        """
        # For snapshot 'auto' requests, prefer container logs if the container
        # becomes available shortly. This avoids returning only startup output
        # for short-running tasks where the container appears a few seconds
        # after instance boot. The wait window is small and configurable via
        # FLOW_LOGS_CONTAINER_WAIT_SECS (default: 12 seconds).
        wait_secs = 12
        try:
            import os as _os

            v = _os.getenv("FLOW_LOGS_CONTAINER_WAIT_SECS")
            if v is not None:
                wait_secs = max(0, min(60, int(v)))
        except (ValueError, TypeError):
            wait_secs = 12

        if str(log_type).lower() == "auto" and wait_secs > 0:
            try:
                remote = self.get_remote_ops()
                if remote is not None:
                    # Check for Docker container OR host workload log file
                    check_cmd = (
                        "CN=$(docker ps -a --format '{{.Names}}' 2>/dev/null | head -n1 || "
                        "sudo -n docker ps -a --format '{{.Names}}' 2>/dev/null | head -n1); "
                        'if [ -n "$CN" ]; then echo "container:$CN"; '
                        f"elif [ -f {HOST_LOG_FILE} ]; then echo 'hostlog'; "
                        "else echo ''; fi"
                    )
                    deadline = time.time() + float(wait_secs)
                    poll_delay = 0.2
                    while time.time() < deadline:
                        try:
                            result = remote.execute_command(task_id, check_cmd, node=node)
                            if isinstance(result, bytes):
                                result = result.decode("utf-8", errors="ignore")
                            result = str(result).strip()
                            if result.startswith("container:") or result == "hostlog":
                                # Logs are available — use the auto command which
                                # handles both Docker and host log paths
                                cmd = self.ctx.log_service.build_command(task_id, tail, "auto")
                                output = remote.execute_command(task_id, cmd, node=node).strip()
                                self.ctx.log_service.set_cache(task_id, tail, "stdout", output)
                                return output if output else "No logs available"
                        except (OSError, TimeoutError, ConnectionError):
                            pass
                        time.sleep(poll_delay)
                        poll_delay = min(poll_delay * 1.5, 2.0)
            except (OSError, TimeoutError, ConnectionError):
                pass

        # Get bid data for status checking and gating (after the quick auto-wait)
        try:
            from flow.adapters.providers.builtin.mithril.provider.facets.tasks import TasksFacet

            tasks = TasksFacet(self.ctx, self.provider)
            bid = tasks.get_bid_dict(task_id)
        except (FlowError, AttributeError, TypeError) as e:
            logger.debug(f"Failed to get bid for task {task_id}: {e}")
            bid = None

        # Check if logs are available (handles pending/cancelled states)
        if hasattr(self.ctx.log_service, "get_recent"):
            gated = self.ctx.log_service.get_recent(
                task_id=task_id, bid=bid, tail=tail, log_type=log_type, execute=False
            )

            # If gated response indicates logs aren't available, return it
            if isinstance(gated, str) and (
                gated.startswith("Task ")
                or gated.startswith("Failed")
                or gated.endswith("available")
            ):
                return gated

        # Build log retrieval command (normal path)
        cmd = self.ctx.log_service.build_command(task_id, tail, log_type)

        # Check cache first
        cached = self.ctx.log_service.get_cached(task_id, tail, log_type)
        if cached is not None:
            return cached

        # Execute command to get logs
        try:
            remote = self.get_remote_ops()
            if remote is not None:
                output = remote.execute_command(task_id, cmd, node=node).strip()
            else:
                output = self.ctx.log_service.execute_via_remote(task_id, cmd).strip()

            # Cache the result
            self.ctx.log_service.set_cache(task_id, tail, log_type, output)

            return output if output else "No logs available"

        except RemoteExecutionError as e:
            msg = str(e).lower()
            # Treat common endpoint/SSH-not-ready signals as a not-accessible-yet case
            if (
                "no ssh access" in msg
                or "no public endpoint available" in msg
                or "ssh setup failed" in msg
                or "ssh connection error" in msg
            ):
                return format_error(TASK_INSTANCE_NOT_ACCESSIBLE, task_id=task_id)
            return f"Failed to retrieve logs: {e}"
        except (FlowError, OSError, TimeoutError, ConnectionError) as e:
            return f"Failed to retrieve logs: {e}"

    def _container_exists(self, task_id: str, node: int | None = None) -> bool:
        """Check if a container exists on the remote instance."""
        try:
            remote = self.get_remote_ops()
            if remote is None:
                return False
            check_cmd = (
                "docker ps -a --format '{{.Names}}' 2>/dev/null | head -n1 || "
                "sudo -n docker ps -a --format '{{.Names}}' 2>/dev/null | head -n1"
            )
            result = remote.execute_command(task_id, check_cmd, node=node)
            if isinstance(result, bytes):
                result = result.decode("utf-8", errors="ignore")
            return bool(str(result).strip())
        except (OSError, TimeoutError, ConnectionError):
            return False

    def _host_log_exists(self, task_id: str, node: int | None = None) -> bool:
        """Check if the host workload log file exists on the remote instance."""
        try:
            remote = self.get_remote_ops()
            if remote is None:
                return False
            result = remote.execute_command(
                task_id,
                f"[ -f {HOST_LOG_FILE} ] && echo yes || echo no",
                node=node,
            )
            if isinstance(result, bytes):
                result = result.decode("utf-8", errors="ignore")
            return str(result).strip() == "yes"
        except (OSError, TimeoutError, ConnectionError):
            return False

    def _ssh_ready(self, task_id: str, node: int | None = None) -> bool:
        """Check if SSH is ready on the remote instance."""
        try:
            remote = self.get_remote_ops()
            if remote is None:
                return False
            remote.execute_command(task_id, "echo ready", node=node)
            return True
        except (OSError, TimeoutError, ConnectionError):
            return False

    def stream_task_logs(
        self,
        task_id: str,
        log_type: str = "stdout",
        follow: bool = True,
        tail: int = 10,
        *,
        node: int | None = None,
    ) -> Iterator[str]:
        """Stream logs from a task, waiting for container if necessary.

        Args:
            task_id: Task ID
            log_type: Type of logs ("stdout", "stderr", "combined", "startup", "host", "auto")
            follow: Whether to follow log output
            tail: Initial number of lines to retrieve
            node: Node index for multi-instance tasks (defaults to 0)

        Yields:
            Log lines as they become available
        """
        # If not following, just return recent logs via snapshot helper
        if not follow:
            for line in self.get_task_logs(task_id, tail=tail, log_type=log_type, node=node).split(
                "\n"
            ):
                if line:
                    yield line
            return

        # For container-based log types, wait for container OR host log to exist
        container_types = {"stdout", "stderr", "combined", "container", "both", "auto"}
        needs_workload = str(log_type).lower() in container_types

        # Wait for SSH and workload logs (5 minute timeout)
        wait_timeout = 300
        deadline = time.time() + wait_timeout
        ssh_ready = False
        workload_ready = False
        last_status_time = 0.0

        while time.time() < deadline:
            if not ssh_ready:
                ssh_ready = self._ssh_ready(task_id, node)
                if not ssh_ready:
                    if time.time() - last_status_time >= 5.0:
                        yield "Waiting for instance to be ready..."
                        last_status_time = time.time()
                    time.sleep(2)
                    continue

            if needs_workload and not workload_ready:
                # Accept either Docker container or host workload log
                workload_ready = self._container_exists(task_id, node) or self._host_log_exists(
                    task_id, node
                )
                if not workload_ready:
                    if time.time() - last_status_time >= 5.0:
                        yield "Waiting for workload to start..."
                        last_status_time = time.time()
                    time.sleep(2)
                    continue

            break
        else:
            if not ssh_ready:
                yield "Timed out waiting for SSH. Instance may still be starting."
            elif needs_workload and not workload_ready:
                yield "Timed out waiting for workload. Use --source startup to view startup logs."
            return

        # Build a streaming-friendly remote command (includes initial tail)
        try:
            cmd = self.ctx.log_service.build_command(task_id, tail, log_type, follow=True)
        except (FlowError, AttributeError, TypeError) as e:
            # Fallback to simple polling if command construction fails
            logger.debug(f"Failed to build follow command for logs: {e}")
            initial_logs = self.get_task_logs(task_id, tail=tail, log_type=log_type, node=node)
            if initial_logs and not initial_logs.startswith("Failed"):
                for line in initial_logs.split("\n"):
                    if line:
                        yield line
            # Minimal polling loop with timeout matching the main wait window
            last_size = len(initial_logs) if initial_logs else 0
            poll_deadline = time.time() + wait_timeout
            while time.time() < poll_deadline:
                time.sleep(2)
                logs = self.get_task_logs(task_id, tail=1000, log_type=log_type, node=node)
                if not logs or logs.startswith("Failed"):
                    continue
                if len(logs) > last_size:
                    for line in logs[last_size:].split("\n"):
                        if line:
                            yield line
                    last_size = len(logs)
            return

        remote = self.get_remote_ops()
        if remote is None:
            yield "Unable to connect to instance."
            return

        # Bounded de-dupe using OrderedDict for O(1) lookup instead of O(n) deque scan
        recent: OrderedDict[str, None] = OrderedDict()
        recent_maxlen = max(10, tail)
        attempts = 0
        backoff = 1.0
        max_attempts = 4

        while True:
            try:
                any_output = False
                for line in remote.stream_command(task_id, cmd, node=node):
                    if line and line not in recent:
                        yield line
                        recent[line] = None
                        if len(recent) > recent_maxlen:
                            recent.popitem(last=False)
                        any_output = True

                if not any_output and needs_workload:
                    # Workload was confirmed ready before entering this loop.
                    # Brief pause then retry the stream (workload may still be starting).
                    time.sleep(2)
                    attempts = 0
                    continue

                return
            except KeyboardInterrupt:
                return
            except (OSError, TimeoutError, ConnectionError) as e:
                attempts += 1
                if attempts >= max_attempts:
                    yield f"Connection lost after {max_attempts} retries: {e}"
                    return
                yield f"Reconnecting (attempt {attempts}/{max_attempts})..."
                time.sleep(backoff)
                backoff = min(backoff * 2.0, 8.0)
