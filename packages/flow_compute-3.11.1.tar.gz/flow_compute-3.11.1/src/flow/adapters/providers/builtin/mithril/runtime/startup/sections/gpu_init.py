"""GPU initialization section for multi-GPU NVSwitch systems.

Ensures the ib_umad kernel module is loaded and nvidia-fabricmanager is
running before Docker starts containers.  Without this, B200 and other
NVSwitch-based instances fail with CUDA Error 802 (system not yet
initialized) because the fabric manager cannot communicate with NVSwitch
ASICs.
"""

from __future__ import annotations

from flow.adapters.providers.builtin.mithril.runtime.startup.sections.base import (
    ScriptContext,
    ScriptSection,
)


class GPUInitSection(ScriptSection):
    """Load GPU kernel modules and start fabric manager on NVSwitch systems."""

    @property
    def name(self) -> str:
        return "gpu_init"

    @property
    def priority(self) -> int:
        # After header (10) and environment (20), before Docker (40)
        return 35

    def should_include(self, context: ScriptContext) -> bool:
        return context.has_gpu

    def generate(self, context: ScriptContext) -> str:
        return "\n".join(
            [
                "# GPU initialization: kernel modules and fabric manager",
                'echo "Initializing GPU subsystem"',
                "",
                "# Load ib_umad kernel module (required for NVSwitch fabric manager).",
                "# Harmless no-op on systems without InfiniBand/NVSwitch hardware.",
                "modprobe ib_umad 2>/dev/null || true",
                "",
                "# Ensure nvidia-fabricmanager is running for multi-GPU NVSwitch",
                "# topologies (B200, H100 NVL, etc.). Without it CUDA cannot",
                "# initialize cross-GPU communication and reports Error 802.",
                "if command -v nvidia-fabricmanager >/dev/null 2>&1 || "
                "[ -f /usr/bin/nv-fabricmanager ]; then",
                "    if command -v systemctl >/dev/null 2>&1; then",
                "        systemctl enable nvidia-fabricmanager 2>/dev/null || true",
                "        systemctl restart nvidia-fabricmanager 2>/dev/null || true",
                "    elif command -v service >/dev/null 2>&1; then",
                "        service nvidia-fabricmanager restart 2>/dev/null || true",
                "    fi",
                "    # Wait briefly for fabric manager to initialize",
                "    sleep 2",
                "fi",
                "",
                "# Verify GPUs are visible after initialization",
                "if command -v nvidia-smi >/dev/null 2>&1; then",
                '    nvidia-smi --query-gpu=index,name,uuid --format=csv,noheader || echo "WARNING: nvidia-smi failed"',
                "fi",
            ]
        )

    def validate(self, context: ScriptContext) -> list[str]:
        return []


__all__ = ["GPUInitSection"]
