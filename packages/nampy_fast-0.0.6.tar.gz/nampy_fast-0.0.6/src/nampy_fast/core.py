import os
import warnings
import requests

# --- Warnings Suppression ---
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"

import google.generativeai as genai

# --- Configuration ---

# Gemini մոդելները (դասավորված ըստ առաջնահերթության)
GEMINI_MODELS = [
    "models/gemini-3.1-pro-preview",
    "models/gemini-3-pro-preview",
    "models/gemini-2.5-pro",
    "models/gemini-pro-latest",
    "models/gemini-3-flash-preview",
    "models/gemini-2.5-flash",
    "models/gemini-2.0-flash",
    "models/gemini-flash-latest"
]

DEFAULT_GEMINI_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyBEF7GUVbAEf-eJwt0HF8gJaJJpRvQiq7Q")
DEFAULT_MISTRAL_KEY = os.getenv("MISTRAL_API_KEY", "83m7bHL52JrfeG8mD910gy2PHxQ9wBRa")

def _get_api_key(provider="gemini", provided_key=None):
    if provided_key:
        return provided_key
    return DEFAULT_GEMINI_KEY if provider == "gemini" else DEFAULT_MISTRAL_KEY

def max(prompt, api_key=None):
    """
    Gemini հարցում ավտոմատ մոդելի փոփոխմամբ (fallback):
    Եթե մոդելի լիմիտը սպառվում է, անցնում է հաջորդին:
    """
    key = _get_api_key("gemini", api_key)
    genai.configure(api_key=key)
    
    for model_name in GEMINI_MODELS:
        try:
            model = genai.GenerativeModel(model_name)
            response = model.generate_content(prompt)
            # print(f"[Gemini] Օգտագործվեց: {model_name}")
            return response.text
        except Exception as e:
            err = str(e).lower()
            if any(kw in err for kw in ["429", "quota", "exhausted"]):
                # Լիմիտի սպառում, փորձում ենք հաջորդը
                continue
            return f"Gemini Սխալ ({model_name}): {str(e)}"
            
    return "Սխալ: Gemini-ի բոլոր մոդելների լիմիտները սպառվել են:"

def min(prompt, api_key=None):
    """
    Mistral AI հարցում:
    """
    url = "https://api.mistral.ai/v1/chat/completions"
    key = _get_api_key("mistral", api_key)
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}"
    }
    
    data = {
        "model": "mistral-large-latest",
        "messages": [{"role": "user", "content": prompt}]
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        if response.status_code == 200:
            return response.json()["choices"][0]["message"]["content"]
        else:
            return f"Mistral Սխալ {response.status_code}: {response.text}"
    except Exception as e:
        return f"Mistral-ի հետ կապի սխալ (հնարավոր է DNS խնդիր): {str(e)}"

def hello():
    return "Ողջույն nampy-ից: Պատրաստ եմ աշխատել max (Gemini) և min (Mistral) ֆունկցիաներով:"