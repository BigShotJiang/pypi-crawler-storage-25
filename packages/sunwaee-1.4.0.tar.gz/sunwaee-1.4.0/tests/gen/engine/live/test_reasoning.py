"""Live integration tests — reasoning ON / OFF per model.

Tests each reasoning-capable model with enable_reasoning=True and False,
verifying:
  - ON:  response is valid; always-reasoning raw models populate reasoning_content
  - OFF: response is valid; always-reasoning models with a non_reasoning_id swap
         to it; dynamic models produce no reasoning content

One model is chosen per reasoning category to keep API spend low:

  Category                  | Provider | Model
  --------------------------+----------+---------------------------
  dynamic, budget_tokens    | anthropic| claude-haiku-4-5
  dynamic, effort           | anthropic| claude-sonnet-4-6
  always, no swap           | deepseek | deepseek-reasoner
  dynamic, thinkingLevel    | google   | gemini-3-flash-preview
  dynamic, thinkingBudget   | google   | gemini-2.5-flash
  dynamic, disabled_payload | moonshot | kimi-k2.5
  dynamic, reasoning_effort | openai   | gpt-5.4-nano
  always, swaps on OFF      | xai      | grok-4-1-fast

Run:
    pytest -m live tests/gen/engine/live/test_reasoning.py
"""

from __future__ import annotations

# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.models import get_model
from sunwaee.modules.gen.engine.types import Message, Role, StopReason

from ._shared import (
    _assert_base_fields,
    _assert_usage_cost_perf,
    _key_for,
    _save,
    _to_dict,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# One model per reasoning category — cheapest available within each category.
REASONING_ENGINES: list[tuple[str, str]] = [
    ("anthropic", "claude-haiku-4-5"),  # dynamic, budget_tokens, raw tokens
    ("anthropic", "claude-sonnet-4-6"),  # dynamic, effort, raw tokens
    ("deepseek", "deepseek-reasoner"),  # always, no non_reasoning_id, raw tokens
    ("google", "gemini-3-flash-preview"),  # dynamic, thinkingLevel, summary tokens
    ("google", "gemini-2.5-flash"),  # dynamic, thinkingBudget, summary tokens
    ("moonshot", "kimi-k2.5"),  # dynamic, reasoning_disabled_payload, raw tokens
    ("openai", "gpt-5.4-nano"),  # dynamic, reasoning_effort, no tokens exposed
    ("xai", "grok-4-1-fast"),  # always, swaps to non_reasoning_id when OFF
]

_PROMPT = [Message(role=Role.USER, content="Respond with the single word 'ok'.")]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _assert_valid_response(response, *, provider: str, model: str) -> None:
    _assert_base_fields(response, streaming=False)
    _assert_usage_cost_perf(response)
    assert response.stop_reason == StopReason.END_TURN, f"{provider}/{model}: unexpected stop_reason {response.stop_reason}"
    assert response.content, f"{provider}/{model}: content must be non-empty"


# ---------------------------------------------------------------------------
# Tests — reasoning ON
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model", REASONING_ENGINES)
async def test_reasoning_on(provider: str, model: str) -> None:
    """enable_reasoning=True: response valid; always+raw models expose reasoning_content."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model, enable_reasoning=True)
    response = await engine.chat(_PROMPT)

    _save(_to_dict(response), f"reasoning_on_{provider}_{model}")
    _assert_valid_response(response, provider=provider, model=model)

    model_info = get_model(model)
    if model_info and model_info.reasoning_mode == "always" and model_info.reasoning_tokens_type == "raw":
        # always-reasoning models with raw token access must populate reasoning_content
        assert response.reasoning_content, f"{provider}/{model}: expected reasoning_content with enable_reasoning=True"


# ---------------------------------------------------------------------------
# Tests — reasoning OFF
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model", REASONING_ENGINES)
async def test_reasoning_off(provider: str, model: str) -> None:
    """enable_reasoning=False: response valid; always models swap; dynamic models don't reason."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model, enable_reasoning=False)
    response = await engine.chat(_PROMPT)

    _save(_to_dict(response), f"reasoning_off_{provider}_{model}")
    _assert_valid_response(response, provider=provider, model=model)

    model_info = get_model(model)
    if model_info is None:
        return

    if model_info.non_reasoning_id:
        # always-reasoning model with a non-reasoning variant — factory must have swapped
        assert response.model == model_info.non_reasoning_id, (
            f"{provider}/{model}: expected model swap to {model_info.non_reasoning_id!r}, " f"got {response.model!r}"
        )
        assert not response.reasoning_content, f"non-reasoning variant {model_info.non_reasoning_id!r} must not populate reasoning_content"

    elif model_info.reasoning_mode == "dynamic":
        # dynamic models: thinking is disabled — no reasoning content expected
        assert not response.reasoning_content, f"{provider}/{model}: dynamic model must not produce reasoning_content when disabled"

    # always-reasoning models with no non_reasoning_id (e.g. deepseek-reasoner) still
    # reason when enable_reasoning=False because they cannot be disabled — no assertion.
