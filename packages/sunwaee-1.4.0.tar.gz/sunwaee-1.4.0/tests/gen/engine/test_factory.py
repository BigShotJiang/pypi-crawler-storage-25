# standard
# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.providers.anthropic import AnthropicEngine
from sunwaee.modules.gen.engine.providers.google import GoogleEngine
from sunwaee.modules.gen.engine.providers.openai import OpenAIEngine

### HELPERS


def _monkeypatch_env(monkeypatch, provider: str, key: str = "env-key"):
    monkeypatch.setenv(f"{provider.upper()}_API_KEY", key)


def test_get_engine_anthropic():
    engine = get_engine("anthropic", "claude-3-5-haiku", "key")
    assert isinstance(engine, AnthropicEngine)
    assert engine.model == "claude-3-5-haiku"


def test_get_engine_google():
    engine = get_engine("google", "gemini-2.0-flash", "key")
    assert isinstance(engine, GoogleEngine)
    assert engine.model == "gemini-2.0-flash"


def test_get_engine_openai():
    engine = get_engine("openai", "gpt-4o", "key")
    assert isinstance(engine, OpenAIEngine)
    assert engine.base_url == "https://api.openai.com/v1"


def test_get_engine_deepseek():
    engine = get_engine("deepseek", "deepseek-reasoner", "key")
    assert isinstance(engine, OpenAIEngine)
    assert "deepseek" in engine.base_url


def test_get_engine_moonshot():
    engine = get_engine("moonshot", "moonshot-v1-8k", "key")
    assert isinstance(engine, OpenAIEngine)
    assert "moonshot" in engine.base_url


def test_get_engine_xai():
    engine = get_engine("xai", "grok-2", "key")
    assert isinstance(engine, OpenAIEngine)
    assert "x.ai" in engine.base_url


def test_get_engine_case_insensitive():
    engine = get_engine("Anthropic", "claude-3-5-haiku", "key")
    assert isinstance(engine, AnthropicEngine)

    engine = get_engine("GOOGLE", "gemini-2.0-flash", "key")
    assert isinstance(engine, GoogleEngine)


def test_get_engine_max_tokens():
    engine = get_engine("anthropic", "claude-3-5-haiku", "key", max_tokens=1024)
    assert engine.max_tokens == 1024


def test_get_engine_unknown_provider():
    with pytest.raises(ValueError, match="Unknown provider"):
        get_engine("banana", "some-model", "key")


### API KEY RESOLUTION


def test_get_engine_api_key_from_env(monkeypatch):
    _monkeypatch_env(monkeypatch, "anthropic")
    engine = get_engine("anthropic", "claude-3-5-haiku")
    assert isinstance(engine, AnthropicEngine)
    assert engine.api_key == "env-key"


def test_get_engine_explicit_key_takes_precedence(monkeypatch):
    _monkeypatch_env(monkeypatch, "anthropic", key="env-key")
    engine = get_engine("anthropic", "claude-3-5-haiku", api_key="explicit-key")
    assert engine.api_key == "explicit-key"


def test_get_engine_no_key_raises(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(ValueError, match="ANTHROPIC_API_KEY"):
        get_engine("anthropic", "claude-3-5-haiku")


### ENABLE_REASONING — model swapping


def test_enable_reasoning_false_swaps_always_model_to_non_reasoning():
    # grok-4-1-fast is always-reasoning; disable should swap to non-reasoning variant
    engine = get_engine("xai", "grok-4-1-fast", "key", enable_reasoning=False)
    assert engine.model == "grok-4-1-fast-non-reasoning"


def test_enable_reasoning_true_keeps_always_model():
    engine = get_engine("xai", "grok-4-1-fast", "key", enable_reasoning=True)
    assert engine.model == "grok-4-1-fast"


def test_enable_reasoning_true_swaps_non_reasoning_model_to_reasoning():
    # grok-4-1-fast-non-reasoning has reasoning_id → should swap when reasoning=True
    engine = get_engine("xai", "grok-4-1-fast-non-reasoning", "key", enable_reasoning=True)
    assert engine.model == "grok-4-1-fast"


def test_enable_reasoning_false_keeps_non_reasoning_model():
    engine = get_engine("xai", "grok-4-1-fast-non-reasoning", "key", enable_reasoning=False)
    assert engine.model == "grok-4-1-fast-non-reasoning"


def test_enable_reasoning_false_always_no_swap_when_no_non_reasoning_id():
    # grok-4 is always-reasoning but has no non_reasoning_id → stays as-is
    engine = get_engine("xai", "grok-4", "key", enable_reasoning=False)
    assert engine.model == "grok-4"


### ENABLE_REASONING — anthropic thinking params


def test_enable_reasoning_true_anthropic_effort_model_uses_effort():
    # claude-opus-4-7 has reasoning_efforts → should use effort="high"
    engine = get_engine("anthropic", "claude-opus-4-7", "key", enable_reasoning=True)
    assert isinstance(engine, AnthropicEngine)
    assert engine.effort == "high"
    assert engine.thinking_budget is None


def test_enable_reasoning_false_anthropic_effort_model_uses_low_effort():
    engine = get_engine("anthropic", "claude-opus-4-7", "key", enable_reasoning=False)
    assert engine.effort == "low"
    assert engine.thinking_budget is None


def test_enable_reasoning_true_anthropic_budget_model_sets_budget():
    # claude-haiku-4-5 has no reasoning_efforts → uses thinking_budget
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", max_tokens=4096, enable_reasoning=True)
    assert engine.thinking_budget == max(1024, 4096 - 1024)
    assert engine.effort is None


def test_enable_reasoning_false_anthropic_budget_model_no_thinking():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", enable_reasoning=False)
    assert engine.thinking_budget is None
    assert engine.effort is None


### ENABLE_REASONING — google thinking params


def test_enable_reasoning_true_gemini3_uses_thinking_level_high():
    # gemini-3-flash-preview has reasoning_efforts → thinkingLevel
    engine = get_engine("google", "gemini-3-flash-preview", "key", enable_reasoning=True)
    assert isinstance(engine, GoogleEngine)
    assert engine.thinking_level == "high"
    assert engine.thinking_budget is None


def test_enable_reasoning_false_gemini3_uses_minimal_level():
    engine = get_engine("google", "gemini-3-flash-preview", "key", enable_reasoning=False)
    assert engine.thinking_level == "minimal"
    assert engine.thinking_budget is None


def test_enable_reasoning_true_gemini25_uses_dynamic_budget():
    # gemini-2.5-flash has no reasoning_efforts → thinkingBudget=-1
    engine = get_engine("google", "gemini-2.5-flash", "key", enable_reasoning=True)
    assert engine.thinking_budget == -1
    assert engine.thinking_level is None


def test_enable_reasoning_false_gemini25_uses_budget_zero():
    engine = get_engine("google", "gemini-2.5-flash", "key", enable_reasoning=False)
    assert engine.thinking_budget == 0
    assert engine.thinking_level is None


def test_enable_reasoning_false_gemini25_pro_always_no_swap():
    # gemini-2.5-pro is always-reasoning, no non_reasoning_id → no explicit config
    engine = get_engine("google", "gemini-2.5-pro", "key", enable_reasoning=False)
    assert engine.model == "gemini-2.5-pro"
    assert engine.thinking_budget is None
    assert engine.thinking_level is None


### ENABLE_REASONING — openai-compat reasoning_effort


def test_enable_reasoning_true_openai_uses_effort_high():
    # gpt-5.4 has reasoning_efforts → reasoning_effort="high"
    engine = get_engine("openai", "gpt-5.4", "key", enable_reasoning=True)
    assert isinstance(engine, OpenAIEngine)
    assert engine.reasoning_effort == "high"


def test_enable_reasoning_false_openai_no_effort():
    engine = get_engine("openai", "gpt-5.4", "key", enable_reasoning=False)
    assert engine.reasoning_effort is None


def test_enable_reasoning_true_openai_no_reasoning_efforts_no_effort():
    # gpt-4.1 has no reasoning_efforts → no reasoning_effort sent
    engine = get_engine("openai", "gpt-4.1", "key", enable_reasoning=True)
    assert engine.reasoning_effort is None
