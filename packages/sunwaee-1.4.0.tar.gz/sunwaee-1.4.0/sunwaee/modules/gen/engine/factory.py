from __future__ import annotations

# standard
import asyncio
import os

# third party
import httpx

# custom
from .base import BaseEngine
from .models import get_model
from .providers.anthropic import AnthropicEngine
from .providers.google import GoogleEngine
from .providers.openai import OpenAIEngine

_OPENAI_COMPATIBLE: dict[str, str] = {
    "openai": "https://api.openai.com/v1",
    "deepseek": "https://api.deepseek.com/v1",
    "moonshot": "https://api.moonshot.ai/v1",
    "xai": "https://api.x.ai/v1",
}

# One persistent AsyncClient per (event_loop, base_url) — reuses TCP connections
# across requests within the same event loop. Keying by loop ID ensures tests
# (each with their own loop) never share a client across loops, which would cause
# "Event loop is closed" errors when a prior loop is torn down.
_HTTP_CLIENTS: dict[tuple[int, str], httpx.AsyncClient] = {}


def _get_client(base_url: str) -> httpx.AsyncClient:
    try:
        loop_id = id(asyncio.get_running_loop())
    except RuntimeError:
        loop_id = 0  # sync context fallback — unlikely in production
    key = (loop_id, base_url)
    if key not in _HTTP_CLIENTS:
        _HTTP_CLIENTS[key] = httpx.AsyncClient()
    return _HTTP_CLIENTS[key]


def get_engine(
    provider: str,
    model: str,
    api_key: str | None = None,
    max_tokens: int = 8192,
    enable_reasoning: bool = False,
) -> BaseEngine:
    """Return the correct engine instance for the given provider.

    ``api_key`` is used as-is when provided. Otherwise the env var
    ``<PROVIDER>_API_KEY`` (e.g. ``ANTHROPIC_API_KEY``) is tried.

    ``enable_reasoning`` gates reasoning/thinking for all providers:
    - always models: swap to non_reasoning_id when False (if available), else proceed
    - non-reasoning models: swap to reasoning_id when True (if available), else proceed
    - dynamic models: activate or deactivate reasoning via provider-specific params
    """
    p = provider.lower()

    resolved_key = api_key or os.environ.get(f"{p.upper()}_API_KEY")
    if not resolved_key:
        raise ValueError(f"No API key for provider '{provider}'. " f"Pass api_key= or set the {p.upper()}_API_KEY environment variable.")

    # --- model swapping -------------------------------------------------------
    model_info = get_model(model)
    if model_info is not None:
        if not enable_reasoning and model_info.reasoning_mode == "always":
            # always-reasoning model: swap to non-reasoning variant if one exists
            if model_info.non_reasoning_id:
                model = model_info.non_reasoning_id
                model_info = get_model(model)
        elif enable_reasoning and model_info.reasoning_mode is None:
            # non-reasoning model: swap to reasoning variant if one exists
            if model_info.reasoning_id:
                model = model_info.reasoning_id
                model_info = get_model(model)

    # --- provider routing -----------------------------------------------------
    if p in _OPENAI_COMPATIBLE:
        reasoning_effort: str | None = None
        if enable_reasoning and model_info is not None and model_info.reasoning_efforts:
            reasoning_effort = "high"

        return OpenAIEngine(
            provider=p,
            model=model,
            api_key=resolved_key,
            base_url=_OPENAI_COMPATIBLE[p],
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
            client=_get_client(_OPENAI_COMPATIBLE[p]),
        )

    if p == "anthropic":
        effort: str | None = None
        thinking_budget: int | None = None

        if model_info is not None and model_info.reasoning_efforts:
            # Newer models (Opus 4.7/4.6, Sonnet 4.6): effort + adaptive thinking
            effort = "high" if enable_reasoning else "low"
        elif enable_reasoning:
            # Older models (Opus 4.5, Haiku 4.5, Sonnet 4.5): explicit budget
            thinking_budget = max(1024, max_tokens - 1024)
        # else: enable_reasoning=False + older model → no thinking block sent

        return AnthropicEngine(
            model=model,
            api_key=resolved_key,
            max_tokens=max_tokens,
            thinking_budget=thinking_budget,
            effort=effort,
            client=_get_client(AnthropicEngine.BASE_URL),
        )

    if p == "google":
        thinking_budget_g: int | None = None
        thinking_level: str | None = None

        if model_info is not None:
            if model_info.reasoning_mode == "always" and model_info.non_reasoning_id is None:
                # Can't disable — let model use its natural default (no explicit config)
                pass
            elif model_info.reasoning_efforts:
                # Gemini 3 series: use thinkingLevel
                if enable_reasoning:
                    thinking_level = "high"
                else:
                    thinking_level = model_info.reasoning_efforts[0]  # "minimal" or "low"
            else:
                # Gemini 2.5 series: use thinkingBudget
                thinking_budget_g = -1 if enable_reasoning else 0

        return GoogleEngine(
            model=model,
            api_key=resolved_key,
            max_tokens=max_tokens,
            thinking_budget=thinking_budget_g,
            thinking_level=thinking_level,
            client=_get_client(GoogleEngine.BASE_URL),
        )

    raise ValueError(f"Unknown provider '{provider}'. " f"Supported: {', '.join(sorted({*_OPENAI_COMPATIBLE, 'anthropic', 'google'}))}")
