from __future__ import annotations

# standard
# third party
# custom
from ..model import Model

MODELS: list[Model] = [
    Model(
        name="kimi-k2.5",
        display_name="Kimi K2.5",
        provider="moonshot",
        context_window=262_144,
        max_output_tokens=262_144,
        input_price_per_mtok=0.6,
        output_price_per_mtok=3.0,
        cache_read_price_per_mtok=0.1,
        supports_vision=True,
        supports_tools=True,
        supports_reasoning=True,
        reasoning_mode="dynamic",
        reasoning_tokens_type="raw",
        reasoning_disabled_payload={"thinking": {"type": "disabled"}},
        cache_min_tokens=0,
        release_date="2026-01-27",
    ),
]
