"""
catalyst_brain.client
---------------------
Thin HTTP wrapper around the Catalyst edge worker that auto-injects
zero-overhead telemetry headers on every request:

    X-Catalyst-SDK-Version
    X-Catalyst-Endpoint-Intent
    X-Catalyst-Local-Latency       (milliseconds, float)
    X-Catalyst-Hardware            (e.g. Darwin-arm64, Linux-x86_64)

The worker captures these via ``ctx.wait_until`` and writes one Workers
Analytics Engine data point per request without touching the response
critical path. Latency for the user is unchanged whether telemetry is
enabled or not.

The wrapper uses ``urllib`` from the standard library so the SDK does
not pull in ``requests`` or ``httpx`` as transitive dependencies.

Example
-------
    from catalyst_brain import CatalystClient

    client = CatalystClient(api_key="sk_live_…")
    out = client.attention_compute(
        query_label="user_intent",
        key_labels=["action_a", "action_b"],
        value_labels=["route_x", "route_y"],
    )
"""
from __future__ import annotations

import json
import platform
import time
import urllib.error
import urllib.request
from typing import Any, Mapping

from catalyst_brain.telemetry import _sdk_version

_DEFAULT_BASE_URL = "https://catalyst-edge-worker.strategic-innovations.workers.dev"
_DEFAULT_TIMEOUT_S = 5.0


class CatalystClient:
    """HTTP client for the Catalyst edge worker with auto-injected telemetry headers."""

    def __init__(
        self,
        base_url: str = _DEFAULT_BASE_URL,
        *,
        api_key: str | None = None,
        timeout_s: float = _DEFAULT_TIMEOUT_S,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout_s
        self._hardware = f"{platform.system()}-{platform.machine()}"
        self._sdk_version = _sdk_version()

    def attention_compute(
        self,
        *,
        query_label: str,
        key_labels: list[str],
        value_labels: list[str],
        iterations: int = 32,
    ) -> dict[str, Any]:
        return self._post(
            "/attention/compute",
            intent="Quantum_Hybrid",
            body={
                "query_label": query_label,
                "key_labels": key_labels,
                "value_labels": value_labels,
                "iterations": iterations,
            },
        )

    def quantum_analyze(self, *, execution_mode: str, **params: Any) -> dict[str, Any]:
        return self._post(
            "/quantum/analyze",
            intent="HKVC_Context",
            body={"execution_mode": execution_mode, **params},
        )

    def _post(self, path: str, *, intent: str, body: Mapping[str, Any]) -> dict[str, Any]:
        local_t0 = time.perf_counter()
        payload = json.dumps(body).encode("utf-8")
        local_latency_ms = (time.perf_counter() - local_t0) * 1_000

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "X-Catalyst-SDK-Version": self._sdk_version,
            "X-Catalyst-Endpoint-Intent": intent,
            "X-Catalyst-Local-Latency": f"{local_latency_ms:.6f}",
            "X-Catalyst-Hardware": self._hardware,
        }
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        req = urllib.request.Request(
            self._base + path,
            data=payload,
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return {"error": str(e), "status": e.code}
