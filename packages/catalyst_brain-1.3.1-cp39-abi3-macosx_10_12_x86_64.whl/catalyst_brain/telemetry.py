"""
catalyst_brain.telemetry
------------------------
Lightweight, privacy-respecting telemetry for the Catalyst Brain SDK.

Data collected (all anonymous):
  - SDK version
  - Python version and OS/architecture
  - Which top-level class was instantiated (e.g. "PyHoloCPUScheduler")
  - Whether the call raised an exception (no message or traceback sent)

Data NOT collected:
  - Any user data, vectors, labels, or model outputs
  - IP addresses (Cloudflare strips these at the edge)
  - Any personally identifiable information

Opt-out:
  Set the environment variable CATALYST_NO_TELEMETRY=1 to disable completely.
  e.g.  export CATALYST_NO_TELEMETRY=1

Privacy policy: https://github.com/strategic-innovations-ai/catalyst-brain#privacy
"""

from __future__ import annotations

import os
import sys
import platform
import threading
import urllib.request
import json
import hashlib
import time
from typing import Optional

# ── Configuration ──────────────────────────────────────────────────────────────
_ENDPOINT = "https://catalyst-edge-worker.strategic-innovations.workers.dev/telemetry/record"
_TIMEOUT_S = 3  # Never block user code more than 3 seconds

# ── Opt-out check ──────────────────────────────────────────────────────────────
def _is_disabled() -> bool:
    return os.environ.get("CATALYST_NO_TELEMETRY", "").strip() not in ("", "0", "false", "False")

# ── Anonymous machine ID ────────────────────────────────────────────────────────
# One-way hash of platform info — cannot be reversed to identify the user.
def _machine_id() -> str:
    raw = f"{platform.node()}:{platform.machine()}:{sys.version}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]

# ── SDK version (graceful fallback) ────────────────────────────────────────────
def _sdk_version() -> str:
    try:
        from importlib.metadata import version
        return version("catalyst_brain")
    except Exception:
        return "unknown"

# ── Fire-and-forget send ───────────────────────────────────────────────────────
def _send(payload: dict) -> None:
    """Send telemetry in a background daemon thread — never blocks user code."""
    if _is_disabled():
        return

    def _post():
        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                _ENDPOINT,
                data=data,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=_TIMEOUT_S)
        except Exception:
            pass  # Telemetry is best-effort — never raise

    t = threading.Thread(target=_post, daemon=True)
    t.start()

# ── Public API ─────────────────────────────────────────────────────────────────
def record_usage(
    feature: str,
    *,
    latency_ms: Optional[int] = None,
    error: bool = False,
) -> None:
    """
    Record an anonymous SDK usage event.

    Parameters
    ----------
    feature : str
        Name of the class or function being used, e.g. "PyHoloCPUScheduler".
    latency_ms : int, optional
        Execution time in milliseconds if known.
    error : bool
        True if the call raised an exception (no details sent).
    """
    if _is_disabled():
        return

    payload = {
        "environment": {
            "sdk_version": _sdk_version(),
            "python_version": platform.python_version(),
            "os": platform.system(),
            "arch": platform.machine(),
            "machine_id": _machine_id(),   # anonymous, one-way hash
            "api_latency_ms": latency_ms or 0,
            "error_count": 1 if error else 0,
            "execution_mode": feature,
        },
        "events": [],
    }
    _send(payload)
