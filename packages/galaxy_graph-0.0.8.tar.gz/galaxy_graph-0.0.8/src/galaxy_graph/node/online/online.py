"""NodeIsOnline class container."""

from copy import deepcopy
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from galaxy_graph.exception import (
    ConnectionAlreadyInNodeError,
    ConnectionAlreadySetupError,
)

from .state import NodeOnlineState

if TYPE_CHECKING:
    from collections.abc import Callable

    from galaxy_graph.connection import Connection
    from galaxy_graph.graph import Graph
    from galaxy_graph.node import Node


@dataclass
class NodeIsOnline(NodeOnlineState):
    """The Node is in a Graph."""

    graph: Graph

    connections: set[Connection] = field(
        default_factory=set
    )  # all connections of this nodes

    def detach(self) -> Node:
        """Detach the node to its attached Graph."""
        from .offline import NodeIsOffline  # noqa: PLC0415

        node = self.state.node
        self.graph.internal_delete_node(node=node)
        node.state.online = NodeIsOffline(state=node.state)
        return node

    def connect(
        self, connection: Connection, destination: Node
    ) -> Connection:
        """
        Connect this node to another one with a specific connection.

        If the graph of the node is not directed, the other node will
        have the same connection.

        Parameters
        ----------
        connection: Connection
            Connection not already connected to nodes.
        destination: Node
            Node already in a Graph or not.

        """
        from galaxy_graph.connection import (  # noqa: PLC0415
            ConnectionNotSetup,
        )

        from .offline import NodeIsOffline  # noqa: PLC0415
        # Necessary for ty…

        if connection.state.is_setup():
            raise ConnectionAlreadySetupError(connection.identifier)
        if connection.identifier in {
            connection.identifier for connection in self.connections
        }:
            raise ConnectionAlreadyInNodeError(connection.identifier)

        if not destination.state.is_online():
            online_state = destination.state.online
            if not isinstance(online_state, NodeIsOffline):
                raise TypeError
            destination = online_state.attach(self.graph)
        else:
            # checks if the node is in this Graph
            _ = self.graph.get_by_id(destination.identifier)

        if not self.graph.is_directed:
            new_connection = deepcopy(connection)
            setup_state = new_connection.state.setup
            if not isinstance(setup_state, ConnectionNotSetup):
                raise TypeError
            new_connection = setup_state.setup(
                source=destination, destination=self.state.node
            )
            self.connections.add(new_connection)

        setup_state = connection.state.setup
        if not isinstance(setup_state, ConnectionNotSetup):
            raise TypeError
        connection = setup_state.setup(
            source=self.state.node, destination=destination
        )
        self.connections.add(connection)

        return connection

    def get_neighbors_by_connection_data(
        self, filter_: Callable[[Any], bool]
    ) -> set[Node]:
        """
        Get linked nodes with connections respecting a filter on data.

        The filter function will be applied to the data of every
        connections of this node. If the filter return true, the node
        associated to the connection is included in the returned set.

        Parameters
        ----------
        filter_: Callable[[Any], bool]
            Filter function, determine if the connected Node is kept.

        Examples
        --------
        >>> node = Node()
        >>> node_1 = Node()
        >>> node_2 = Node()
        >>> node.connect(Connection, node_1, 2)
        >>> node.connect(Connection, node_2, 14)
        >>> node.get_neighbors_by_connection_data(
        >>>     filter=lambda x: x < 10
        >>>     if isinstance(x, int) else False,
        >>> )
        { node_1 }

        """
        return {
            connection.state.setup.destination  # ty: ignore[unresolved-attribute]
            for connection in self.connections
            if filter_(connection.data)
        }

    def get_neighbors_by_connection_type(
        self, type_: type[Connection]
    ) -> set[Node]:
        """
        Get linked nodes with connections of the given types.

        Parameters
        ----------
        type_: type[Connection]
            Type of the connection to look at.

        """
        return {
            connection.state.setup.destination  # ty: ignore[unresolved-attribute]
            for connection in self.connections
            if isinstance(connection, type_)
        }

    def get_neighbors_by_node_data(
        self, filter_: Callable[[Any], bool]
    ) -> set[Node]:
        """
        Get linked nodes with data respecting a given filter.

        The filter function will be applied to the data of every nodes
        connected to this node. If the filter return true, the node is
        included in the returned set.

        Parameters
        ----------
        filter_: Callable[[Any], bool]
            Filter function, determine if the connected Node is kept.

        Examples
        --------
        >>> node = Node()
        >>> node_1 = Node(data=5)
        >>> node_2 = Node(data=12)
        >>> node.connect(Connection, node_1)
        >>> node.connect(Connection, node_2)
        >>> node.get_neighbors_by_node_data(
        >>>     filter=lambda x: x < 9 if isinstance(x, int) else False,
        >>> )
        { node_1 }

        """
        return {
            connection.state.setup.destination  # ty: ignore[unresolved-attribute]
            for connection in self.connections
            if filter_(connection.state.setup.destination.data)  # ty: ignore[unresolved-attribute]
        }

    def get_neighbors_by_node_type(
        self, type_: type[Node]
    ) -> set[Node]:
        """
        Get linked node with a given type.

        Parameters
        ----------
        type_: type[Node]
            Type of the node to look at.

        """
        return {
            connection.state.setup.destination  # ty: ignore[unresolved-attribute]
            for connection in self.connections
            if isinstance(connection.state.setup.destination, type_)  # ty: ignore[unresolved-attribute]
        }

    def is_online(self) -> bool:
        """Check if the Node is associated to a Graph."""
        return True
