# Galaxy graph

Edit and manage graph.

## Getting started

### Requirements

- Python >= 3.14

### Installation

To install this package in the current python environment, use:
`python -m pip install galaxy_graph`

### Usage

```py
from galaxy_graph import Graph, Node, Connection

graph = Graph()
house = Node("house")
graph.add(house)
house.connect(Connection(data="has room"), Node("bedroom"))
house.connect(Connection(data="has room"), Node("kitchen"))
house.connect(Connection(data="has room"), Node("bathroom"))

bedroom = graph.get_by_id("bedroom")
bedroom.connect(Connection(data="has area"), Node(data=9))
kitchen = graph.get_by_id("kitchen")
kitchen.connect(Connection(data="has area"), Node(data=7))
bathroom = graph.get_by_id("bathroom")
bathroom.connect(Connection(data="has area"), Node(data=6))

house.connect(
    Connection(data="has adress"),
    Node(data="1 Grande Rue, 0000, Saint Roustan"),
)

rooms = {node for node in house._state.online.get_neighbors_by_connection_data(filter_=lambda data: data == "has room")}
total_area = sum({
    sum({area.data for area in room._state.online.get_neighbors_by_connection_data(filter_=lambda data: data == "has area")})
    for room in rooms
})
number = len(rooms)

print(f"this house has {number} rooms with a total area of {total_area} m^2")
```

## Documentation

A complete documentation is available in the
[wiki](https://git.linarphy.net/linarphy/galaxy_graph/wiki).

## Development

### Requirements

This project use [mise](https://mise.jdx.dev) to manage development
tools.

> [!TIP]
> If [mise](https://mise.jdx.dev) is installed, and
> [mise.toml](mise.toml) is trusted with `mise trust`, all tools can be
> installed automatically with `mise install``

This project use the following tools:
- [just](https://just.system): command runner
- [hatch](https://hatch.pypa.io): project manager and package builder
- [uv](https://docs.astral.sh/uv): package installer
- [ruff](https://docs.astral.sh/ruff): python linter and formatter
- [ty](https://docs.astra.sh/ty): python type checker
- [jujutsu](https://jj-vcs.dev): version control

> [!NOTE]
> Tools used in the project consume and produce interoperable format to
> avoid vendor lock-in. This is the toolchain of the current maintener.

### Usage

[just](https://just.system) can be used to speed up development for an
identical toolchain.

Before making a commit, `just fix` will run all tests, format the code,
lint and type check. If you don’t want to modify the code, `just check`
will run all tests, lint and type check without any attempt to fix any
issue.

Before a version change, `just release` will push all local commits to
repository and publish the new package version.

All available commands can be listed with `just -l`.

## License

This project is licensed under the GNU GPL v3+.
See [license file](LICENSE) for more information.

## Acknowledgement

Thanks to all the people that worked on the tools used, like python,
neovim and mise.
