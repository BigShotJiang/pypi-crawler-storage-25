# flask-prometheus

This package name is reserved as a defensive registration to prevent the
name from being claimed by a third party who could distribute malicious
code under it.

## What this package does

Nothing. It is a no-op placeholder. Installing it has no effect; importing
it yields nothing useful.

## Why it exists

In 2026, this package name received an estimated 91,000 installation
attempts per year — but no package existed at this name on PyPI. Without
a defensive registration, an unrelated party could claim the name and
ship a payload that would execute on every install attempt.

[Defer](https://defer.sh) registered this name to prevent that scenario.

## Are you a maintainer who needs this name?

If you intend to publish a real package under this name, contact us at
<security@defer.sh>. We will mark this placeholder as deprecated and
document a transition path on this page. Per our defensive-registration
policy we do not transfer ownership directly — we deprecate the
placeholder, you publish under a different name, and we link the redirect
from here.

## Security

Report security issues to <security@defer.sh>.

## License

MIT — see [LICENSE](LICENSE). © 2026 Defer.
