from __future__ import annotations

import inspect
import wrapt

from typing import Callable
from opentelemetry import trace
from opentelemetry.trace import StatusCode

from .types.amint import AmintSpanAttributes


_tracer = trace.get_tracer(__name__)


def _get_span_name(func: Callable, name: str | None) -> str:
    return name if isinstance(name, str) else func.__name__


def _setup_span(span: trace.Span, kind: str, name: str):
    span.set_attribute(AmintSpanAttributes.SPAN_KIND, kind)
    span.set_attribute(AmintSpanAttributes.SPAN_NAME, name)


async def _async_execute_span(span, func, *args, **kwargs):
    try:
        result = await func(*args, **kwargs)
        span.set_status(StatusCode.OK)
        return result
    except Exception as e:
        span.set_status(StatusCode.ERROR, str(e))
        span.record_exception(e)
        raise


def _execute_span(span, func, *args, **kwargs):
    try:
        result = func(*args, **kwargs)
        span.set_status(StatusCode.OK)
        return result

    except Exception as e:
        span.set_status(StatusCode.ERROR, str(e))
        span.record_exception(e)
        raise


def _create_decorator(span_kind: str):
    def decorator(name: str | None = None):

        def _get_wrapper(func: Callable):
            span_name = _get_span_name(func, name)

            @wrapt.decorator
            async def async_wrapper(wrapped, instance, args, kwargs):
                with _tracer.start_as_current_span(span_name, record_exception=False) as span:
                    _setup_span(span, span_kind, span_name)
                    return await _async_execute_span(span, wrapped, *args, **kwargs)

            @wrapt.decorator
            def sync_wrapper(wrapped, instance, args, kwargs):
                with _tracer.start_as_current_span(span_name, record_exception=False) as span:
                    _setup_span(span, span_kind, span_name)
                    return _execute_span(span, wrapped, *args, **kwargs)

            wrapper = async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
            return wrapper(func)

        return _get_wrapper(name) if callable(name) else _get_wrapper
    return decorator


workflow = _create_decorator("workflow")
task = _create_decorator("task")