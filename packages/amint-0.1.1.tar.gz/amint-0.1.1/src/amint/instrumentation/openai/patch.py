from amint.types.openai import OpenAISpanName

from .utils import get_request_attributes


def responses_create(tracer):
    def traced_method(wrapped, instance, args, kwargs):
        span_name = OpenAISpanName.RESPONSES
        attributes = get_request_attributes(kwargs)

        with tracer.start_as_current_span(
            span_name,
            attributes=attributes
        ) as span:
            response = wrapped(*args, **kwargs)
            return response

    return traced_method