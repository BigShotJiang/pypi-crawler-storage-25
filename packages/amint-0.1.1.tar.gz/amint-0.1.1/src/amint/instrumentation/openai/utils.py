from opentelemetry.semconv._incubating.attributes import gen_ai_attributes as GenAIAttributes

from amint.types.instruments import Instruments
from amint.types.openai import OpenAIOperation


def get_request_attributes(kwargs: dict) -> dict:
    return {
        GenAIAttributes.GEN_AI_PROVIDER_NAME: Instruments.OPENAI,
        GenAIAttributes.GEN_AI_REQUEST_MODEL: kwargs.get("model"),
        GenAIAttributes.GEN_AI_OPERATION_NAME: OpenAIOperation.RESPONSES,
    }