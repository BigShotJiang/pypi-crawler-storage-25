from __future__ import annotations

import atexit

from dataclasses import dataclass, field
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, ConsoleSpanExporter, SimpleSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

from .instrumentation.openai.instrumentor import OpenAIInstrumentor
from .types.instruments import Instruments
from ._utils import is_package_installed


@dataclass
class TracerConfig:
    app_name: str = "amint-sdk"
    headers: dict[str, str] = field(default_factory=dict)
    endpoint: str = "https://api.amint.ai/v1/traces"


class TracerWrapper:
    _instance: TracerWrapper | None = None
    _provider: TracerProvider | None = None

    def __new__(cls, config: TracerConfig) -> TracerWrapper:
        if cls._instance is None:
            instance = super().__new__(cls)
            instance._provider = _init_tracer_provider(config)

            _add_span_processor(instance._provider, config)
            _init_instrumentations()

            cls._instance = instance
            atexit.register(instance.shutdown)
        return cls._instance

    def flush(self):
        if self._provider:
            self._provider.force_flush()

    def shutdown(self):
        if self._provider:
            self._provider.shutdown()
            self._provider = None


def _init_tracer_provider(config: TracerConfig) -> TracerProvider:
    resource = Resource.create({"service.name": config.app_name})

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)
    return provider


def _init_instrumentations():
    if is_package_installed(Instruments.OPENAI):
        OpenAIInstrumentor().instrument()


def _add_span_processor(provider: TracerProvider, config: TracerConfig):
    processor = _get_default_span_processor(config)
    provider.add_span_processor(processor)


def _get_default_span_processor(config: TracerConfig):
    span_exporter = _init_span_exporter(config)
    processor = SimpleSpanProcessor(span_exporter)
    return processor


def _init_span_exporter(config: TracerConfig) -> ConsoleSpanExporter:
    return ConsoleSpanExporter()

# def _init_span_exporter(config: TracerConfig):
#     return OTLPSpanExporter(
#         endpoint=config.endpoint,
#         headers=config.headers,
#     )