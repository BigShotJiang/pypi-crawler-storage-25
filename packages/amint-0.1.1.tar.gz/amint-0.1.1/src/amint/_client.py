from __future__ import annotations

from ._tracing import TracerWrapper, TracerConfig


class Amint:
    _instance: Amint | None = None

    def __init__(self, config: TracerConfig):
        self._tracer_wrapper = TracerWrapper(config=config)

    @staticmethod
    def init():
        if Amint._instance is not None:
            return

        config = TracerConfig(
            headers={}
        )

        Amint._instance = Amint(config=config)