from __future__ import annotations

from importlib.metadata import packages_distributions


_installed_packages = {pkg.lower() for pkg in packages_distributions()}


def is_package_installed(package: str) -> bool:
    return package.lower() in _installed_packages