from __future__ import annotations


class OpenAISpanName:
    RESPONSES = "openai.responses"


class OpenAIOperation:
    RESPONSES = "responses"