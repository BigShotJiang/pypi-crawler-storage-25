from __future__ import annotations


class Instruments:
    OPENAI = "openai"
    ANTHROPIC = "anthropic"