from __future__ import annotations


class AmintSpanAttributes:
    SPAN_NAME = "amint.span.name"
    SPAN_KIND = "amint.span.kind"


class AmintSpanKind:
    WORKFLOW = "workflow"
    AGENT = "agent"
    TASK = "task"
    TOOL = "tool"