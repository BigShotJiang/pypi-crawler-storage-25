class AmintError(Exception):
    pass