"""Antigravity conversation exporter — uses antigravity-history API directly."""

from __future__ import annotations

import hashlib
import json
import logging
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote

logger = logging.getLogger("collector.antigravity_export")

# Cache: cascade_id → content_hash
_last_hashes: dict[str, str] = {}
_ROLE_PREFIX_RE = re.compile(r"^\s*(?:[-*]\s*)?(user|assistant|ai|model|system)\s*:\s*(.*)$", re.I)
_TRANSCRIPT_KEYS = {"transcript", "conversation_transcript", "formatted_transcript"}
_CHAT_EXPORT_HEADER = "# Chat Conversation"
_CHAT_EXPORT_ACTION_RE = re.compile(r"^\*(.+?)\*\s*$")
_CHAT_EXPORT_SESSION_RE = re.compile(
    r"/\.gemini/antigravity/brain/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/",
    re.I,
)
_CHAT_EXPORT_FILE_URI_RE = re.compile(r"\(file://([^)]+)\)")
_TEXT_KEYS = (
    "response", "assistantResponse", "finalResponse", "outputText", "text",
    "content", "message", "renderedText", "renderedOutput", "full", "value",
)
_TIMESTAMP_KEYS = ("timestamp", "createdAt", "updatedAt", "lastModifiedTime")


def _format_tool_call(tool_name: str, args_json: str) -> tuple[str, str]:
    """Format a toolCall into human-readable (tool_input, content)."""
    try:
        args = json.loads(args_json) if isinstance(args_json, str) else args_json
    except (json.JSONDecodeError, TypeError):
        return (args_json, args_json)

    if not isinstance(args, dict):
        return (str(args), str(args))

    # write_to_file / multi_replace_file_content — show file path + content
    if tool_name in ("write_to_file", "multi_replace_file_content", "replace_file_content"):
        target = args.get("TargetFile", "")
        description = args.get("Description", "")
        code = args.get("CodeContent", args.get("ReplacementContent", ""))
        summary = args.get("ArtifactMetadata", {}).get("Summary", "")
        parts = []
        if description:
            parts.append(description)
        if summary:
            parts.append(f"*{summary}*")
        if code:
            lang = args.get("CodeMarkdownLanguage", "")
            parts.append(f"```{lang}\n{code}\n```")
        return (target or description, "\n".join(parts) if parts else description)

    # task_boundary — progress update
    if tool_name == "task_boundary":
        name = args.get("TaskName", "")
        status = args.get("TaskStatus", "")
        summary = args.get("TaskSummary", "")
        mode = args.get("Mode", "")
        if name == "%SAME%":
            name = ""
        parts = []
        if mode and mode != "%SAME%":
            parts.append(f"**[{mode}]**")
        if name:
            parts.append(f"**{name}**")
        if status:
            parts.append(status)
        if summary:
            parts.append(f"\n{summary}")
        return ("", "\n".join(parts) if parts else "")

    # find_by_name
    if tool_name in ("find_by_name", "find"):
        pattern = args.get("Pattern", args.get("pattern", ""))
        search_dir = args.get("SearchDirectory", args.get("searchDirectory", ""))
        return (f"{pattern} in {search_dir}", f"Find `{pattern}` in `{search_dir}`")

    # list_dir
    if tool_name in ("list_dir", "list_directory"):
        path = args.get("DirectoryPath", args.get("directoryPath", ""))
        return (path, f"`{path}`")

    # grep_search
    if tool_name in ("grep_search", "codebase_search"):
        query = args.get("Query", args.get("query", args.get("Pattern", "")))
        target = args.get("TargetDirectory", args.get("Directory", ""))
        return (query, f"Search `{query}`" + (f" in `{target}`" if target else ""))

    # view_file
    if tool_name in ("view_file", "read_file"):
        path = args.get("AbsolutePath", args.get("TargetFile", args.get("absolutePathUri", "")))
        return (path, f"`{path}`")

    # Generic: extract the most meaningful field
    for key in ("Description", "Summary", "description", "summary", "message", "text"):
        if args.get(key):
            return (args[key], args[key])
    display = args.get("DirectoryPath") or args.get("TargetFile") or args.get("Pattern") or ""
    if display:
        return (display, f"`{display}`")
    return ("", json.dumps(args, ensure_ascii=False, indent=2))


def _normalize_text(value: object, *, limit: int = 0) -> str:
    """Convert nested payloads into readable text. limit=0 means unlimited."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, list):
        parts = [_normalize_text(item) for item in value]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(value, dict):
        for key in ("text", "response", "content", "message", "output", "summary"):
            if key in value:
                text = _normalize_text(value.get(key))
                if text:
                    return text
        parts = [_normalize_text(item) for item in value.values()]
        return "\n".join(part for part in parts if part).strip()
    try:
        return json.dumps(value, ensure_ascii=False)
    except TypeError:
        return str(value)


def _normalize_role(value: object) -> str:
    text = str(value or "").strip().lower()
    if text in {"assistant", "ai", "model", "planner"}:
        return "assistant"
    if text in {"user", "human"}:
        return "user"
    if text in {"system"}:
        return "system"
    return ""


def _get_timestamp(node: dict, fallback: str = "") -> str:
    for key in _TIMESTAMP_KEYS:
        value = node.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return fallback


def _walk_nodes(value: object):
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from _walk_nodes(item)
    elif isinstance(value, list):
        for item in value:
            yield from _walk_nodes(item)


def _parse_transcript_messages(text: str, fallback_ts: str) -> list[dict]:
    """Parse a plain transcript into synthetic user/assistant/system messages."""
    messages: list[dict] = []
    current_role = ""
    current_lines: list[str] = []

    def flush() -> None:
        nonlocal current_role, current_lines
        if not current_role or not current_lines:
            current_role = ""
            current_lines = []
            return
        content = "\n".join(current_lines).strip()
        if content:
            messages.append({
                "type": current_role,
                "message": {"role": current_role, "content": [{"type": "text", "text": content}]},
                "timestamp": fallback_ts,
                "fallback_source": "transcript",
                "content_source": "transcript",
            })
        current_role = ""
        current_lines = []

    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if not line.strip():
            if current_lines:
                current_lines.append("")
            continue
        match = _ROLE_PREFIX_RE.match(line)
        if match:
            flush()
            role = _normalize_role(match.group(1))
            content = match.group(2).strip()
            if role:
                current_role = role
                current_lines = [content] if content else []
            continue
        if current_role:
            current_lines.append(line)

    flush()
    return messages


def _extract_generator_fallbacks(payload: object, fallback_ts: str) -> tuple[list[dict], dict]:
    """Recover assistant messages from generator metadata / transcript-like payloads."""
    messages: list[dict] = []
    transcript_count = 0
    metadata_count = 0
    messages_truncated = False
    seen_texts: set[str] = set()

    for node in _walk_nodes(payload):
        if not isinstance(node, dict):
            continue

        if node.get("messagesTruncated") is True:
            messages_truncated = True

        for key, value in node.items():
            if key in _TRANSCRIPT_KEYS and isinstance(value, str):
                for msg in _parse_transcript_messages(value, _get_timestamp(node, fallback_ts)):
                    content = _normalize_text(msg.get("message", {}).get("content", ""))
                    dedupe_key = "assistant:" + content
                    if msg["type"] == "assistant" and content and dedupe_key not in seen_texts:
                        seen_texts.add(dedupe_key)
                        messages.append(msg)
                        transcript_count += 1

        role = _normalize_role(
            node.get("role") or node.get("author") or node.get("speaker") or node.get("sender"),
        )
        if role != "assistant":
            continue

        text = ""
        for key in _TEXT_KEYS:
            if key in node:
                text = _normalize_text(node.get(key))
                if text:
                    break
        if not text:
            continue

        dedupe_key = "assistant:" + text
        if dedupe_key in seen_texts:
            continue
        seen_texts.add(dedupe_key)
        messages.append({
            "type": "assistant",
            "message": {"role": "assistant", "content": [{"type": "text", "text": text}]},
            "timestamp": _get_timestamp(node, fallback_ts),
            "response_text": text,
            "fallback_source": "generator_metadata",
            "content_source": "generator_metadata",
        })
        metadata_count += 1

    return messages, {
        "generator_metadata_messages": metadata_count,
        "transcript_messages": transcript_count,
        "messages_truncated": messages_truncated,
    }


def _dedupe_fallback_messages(
    candidates: list[dict], existing_texts: set[str],
) -> list[dict]:
    deduped: list[dict] = []
    for msg in candidates:
        content = _normalize_text(msg.get("message", {}).get("content", ""))
        if not content:
            continue
        key = f"{msg.get('type', 'assistant')}:{content}"
        if key in existing_texts:
            continue
        existing_texts.add(key)
        deduped.append(msg)
    return deduped


def _normalize_pb_fragment(raw: str) -> str:
    text = raw.strip()
    if not text:
        return ""

    try:
        text = text.encode().decode("unicode_escape").encode("latin1").decode("utf-8")
    except Exception:
        pass

    text = re.sub(r"[\x00-\x08\x0b-\x1f]+", " ", text).strip()
    if not text:
        return ""

    if text.startswith("{") or text.startswith("["):
        try:
            parsed = json.loads(text)
        except Exception:
            parsed = None
        if parsed is not None:
            normalized = _normalize_text(parsed)
            if normalized:
                return normalized

    return text


def _is_meaningful_pb_fragment(text: str) -> bool:
    compact = text.strip()
    if len(compact) < 24:
        return False
    if compact.startswith(("file://", "http://", "https://")):
        return False
    if "/antigravity/" in compact or "/.gemini/" in compact:
        return False
    if re.fullmatch(r"[A-Za-z0-9+/=]{60,}", compact):
        return False
    if re.fullmatch(r"[0-9a-f-]{32,}", compact, re.I):
        return False
    if compact.lower() in {"assistant", "user", "system", "planner"}:
        return False
    if " " not in compact and "\n" not in compact and len(compact) < 120:
        return False
    return True


def _build_pb_fallback_messages(strings: list[str], fallback_ts: str) -> tuple[list[dict], dict]:
    """Build approximate messages from offline protobuf string fragments."""
    messages: list[dict] = []
    seen_texts: set[str] = set()
    transcript_hits = 0
    fragment_hits = 0

    for raw in strings:
        normalized = _normalize_pb_fragment(raw)
        if not _is_meaningful_pb_fragment(normalized):
            continue

        parsed = _parse_transcript_messages(normalized, fallback_ts)
        if parsed:
            deduped = _dedupe_fallback_messages(parsed, seen_texts)
            if deduped:
                messages.extend(deduped)
                transcript_hits += len(deduped)
            continue

        key = f"assistant:{normalized}"
        if key in seen_texts:
            continue
        seen_texts.add(key)
        messages.append({
            "type": "assistant",
            "message": {"role": "assistant", "content": [{"type": "text", "text": normalized}]},
            "timestamp": fallback_ts,
            "response_text": normalized,
            "fallback_source": "offline_pb",
            "content_source": "offline_pb",
        })
        fragment_hits += 1
        # No limit on pb fallback messages

    return messages, {
        "offline_pb_transcript_messages": transcript_hits,
        "offline_pb_messages": fragment_hits,
        "offline_pb_total_messages": len(messages),
    }


def _extract_pb_fallback_messages(pb_path: Path, fallback_ts: str) -> tuple[list[dict], dict]:
    """Recover readable text from an offline Antigravity .pb cache file."""
    try:
        raw = pb_path.read_bytes()
    except OSError:
        return [], {
            "offline_pb_transcript_messages": 0,
            "offline_pb_messages": 0,
            "offline_pb_total_messages": 0,
        }

    try:
        from .antigravity_vscdb import _walk_strings
    except Exception:
        return [], {
            "offline_pb_transcript_messages": 0,
            "offline_pb_messages": 0,
            "offline_pb_total_messages": 0,
        }

    strings = _walk_strings(raw, max_depth=10)
    messages, diagnostics = _build_pb_fallback_messages(strings, fallback_ts)
    diagnostics["offline_pb_string_count"] = len(strings)
    return messages, diagnostics


def _endpoint_key(ep: dict) -> str:
    return f"{ep.get('port')}:{ep.get('csrf', '')}"


def _merge_summary(existing: dict | None, new: dict) -> dict:
    """Merge two trajectory summary records, keeping the richer one."""
    if existing is None:
        return dict(new)

    merged = dict(existing)
    existing_summary = str(merged.get("summary") or "").strip()
    new_summary = str(new.get("summary") or "").strip()
    for key in ("summary", "status", "createdTime", "lastModifiedTime"):
        if key == "summary":
            if (not existing_summary or existing_summary.startswith("[unindexed]")) and new_summary:
                merged[key] = new_summary
            continue
        if not merged.get(key) and new.get(key):
            merged[key] = new[key]

    new_steps = int(new.get("stepCount") or 0)
    old_steps = int(merged.get("stepCount") or 0)
    if new_steps > old_steps:
        merged["stepCount"] = new_steps

    if not merged.get("workspaces") and new.get("workspaces"):
        merged["workspaces"] = new["workspaces"]

    return merged


def _call_api_first_success(
    endpoints: list[dict],
    method: str,
    payload: dict,
    *,
    timeout: int,
    call_api,
) -> tuple[dict | None, dict | None]:
    """Try the same RPC against multiple endpoints until one succeeds."""
    for ep in endpoints:
        try:
            result = call_api(ep["port"], ep["csrf"], method, payload, timeout=timeout)
        except Exception:
            continue
        if result:
            return result, ep
    return None, None


def _summary_from_offline_session(session: dict) -> dict:
    workspace = session.get("workspace", "")
    workspaces = []
    if workspace:
        workspaces.append({"workspaceFolderAbsoluteUri": workspace})
    return {
        "summary": session.get("title", ""),
        "stepCount": len(session.get("messages", [])),
        "lastModifiedTime": session.get("lastModifiedTime", ""),
        "createdTime": session.get("createdTime", ""),
        "status": "offline_vscdb",
        "workspaces": workspaces,
    }


def _read_browser_highlight_count(metadata_path: Path) -> int:
    try:
        payload = json.loads(metadata_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 0
    highlights = payload.get("highlights")
    if isinstance(highlights, list):
        return len(highlights)
    return 0


def _collect_local_session_artifacts(antigravity_root: Path, cascade_id: str) -> dict[str, object]:
    conv_path = antigravity_root / "conversations" / f"{cascade_id}.pb"
    brain_dir = antigravity_root / "brain" / cascade_id
    browser_dir = antigravity_root / "browser_recordings" / cascade_id

    brain_file_count = 0
    if brain_dir.exists():
        brain_file_count = sum(1 for path in brain_dir.rglob("*") if path.is_file())

    browser_recording_frame_count = 0
    browser_recording_highlight_count = 0
    if browser_dir.exists():
        browser_recording_frame_count = sum(1 for path in browser_dir.glob("*.jpg") if path.is_file())
        metadata_path = browser_dir / "metadata.json"
        if metadata_path.exists():
            browser_recording_highlight_count = _read_browser_highlight_count(metadata_path)

    return {
        "pb_file_present": conv_path.exists(),
        "brain_file_count": brain_file_count,
        "browser_recording_frame_count": browser_recording_frame_count,
        "browser_recording_highlight_count": browser_recording_highlight_count,
    }


def _isoformat_timestamp(stamp: float) -> str:
    return datetime.fromtimestamp(stamp, tz=timezone.utc).isoformat().replace("+00:00", "Z")


def _strip_control_prefix(line: str) -> str:
    return re.sub(r"^[\x00-\x1f]+", "", line)


def _parse_chat_export_markdown(content: str, fallback_ts: str) -> list[dict]:
    """Parse Antigravity chat export markdown into user + assistant messages.

    Format: ### User Input / ### Planner Response sections, with *action* lines.
    """
    messages: list[dict] = []
    lines = [_strip_control_prefix(line.rstrip("\r")) for line in content.splitlines()]
    section_lines: list[str] = []
    current_role: str = ""  # "user" or "assistant"

    def flush_section() -> None:
        nonlocal section_lines, current_role
        if not section_lines or not current_role:
            section_lines = []
            return

        # Separate text content from *action* lines
        text_lines: list[str] = []
        for raw in section_lines:
            line = raw.strip()
            if not line:
                if text_lines:
                    text_lines.append("")  # Preserve paragraph breaks
                continue
            # Skip *action* lines (Edited relevant file, User accepted command, etc.)
            if _CHAT_EXPORT_ACTION_RE.match(line):
                continue
            text_lines.append(line)

        text = "\n".join(text_lines).strip()
        if text:
            messages.append({
                "type": current_role,
                "message": {"role": current_role, "content": [{"type": "text", "text": text}]},
                "timestamp": fallback_ts,
                "content_source": "chat_export",
            })

        section_lines = []

    for line in lines:
        stripped = line.strip()
        if stripped == "### User Input":
            flush_section()
            current_role = "user"
            section_lines = []
            continue
        if stripped == "### Planner Response":
            flush_section()
            current_role = "assistant"
            section_lines = []
            continue
        if stripped.startswith("### "):
            # Other section headers — flush and reset
            flush_section()
            current_role = ""
            continue
        if current_role:
            section_lines.append(line)

    flush_section()
    return messages


def _chat_export_workspace(content: str) -> str:
    for match in _CHAT_EXPORT_FILE_URI_RE.finditer(content):
        uri = unquote(match.group(1))
        if "/.gemini/antigravity/" in uri:
            continue
        if uri.startswith("/"):
            return "file://" + uri
    return ""


def _chat_export_title(path: Path) -> str:
    stem = path.stem
    if "_" in stem:
        return stem.split("_", 1)[1].strip()
    return stem


def _collect_chat_export_sessions(antigravity_root: Path) -> dict[str, dict]:
    sessions: dict[str, dict] = {}
    code_tracker_root = antigravity_root / "code_tracker" / "active"
    if not code_tracker_root.exists():
        return sessions

    for path in code_tracker_root.rglob("*.md"):
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if _CHAT_EXPORT_HEADER not in content:
            continue

        session_ids = sorted(set(_CHAT_EXPORT_SESSION_RE.findall(content)))
        if len(session_ids) != 1:
            continue
        session_id = session_ids[0]

        try:
            stat = path.stat()
            fallback_ts = _isoformat_timestamp(stat.st_mtime)
        except OSError:
            fallback_ts = ""

        messages = _parse_chat_export_markdown(content, fallback_ts)
        workspace = _chat_export_workspace(content)
        session = {
            "session_id": session_id,
            "title": _chat_export_title(path),
            "workspace": workspace,
            "project_name": workspace.rstrip("/").split("/")[-1] if workspace else "",
            "createdTime": fallback_ts,
            "lastModifiedTime": fallback_ts,
            "messages": messages,
            "source_path": str(path),
        }
        existing = sessions.get(session_id)
        if not existing or len(messages) > len(existing.get("messages", [])):
            sessions[session_id] = session

    return sessions


def _step_to_jsonl_line(step: dict, cascade_id: str, fallback_ts: str) -> dict | None:
    """Convert an Antigravity trajectory step to a JSONL message."""
    step_type = step.get("type", "")
    ts = step.get("metadata", {}).get("createdAt", "") or fallback_ts

    if step_type == "CORTEX_STEP_TYPE_USER_INPUT":
        text = step.get("userInput", {}).get("userResponse", "")
        if text:
            return {"type": "user", "message": {"role": "user", "content": text}, "timestamp": ts, "cwd": ""}

    elif step_type == "CORTEX_STEP_TYPE_PLANNER_RESPONSE":
        pr = step.get("plannerResponse", {})
        response_text = _normalize_text(
            pr.get("modifiedResponse", "") or pr.get("response", "")
        )
        thinking_text = _normalize_text(pr.get("thinking", ""))
        # If there's a real response (rare, Chat mode), emit as assistant
        if response_text:
            return {
                "type": "assistant",
                "message": {"role": "assistant", "content": [{"type": "text", "text": response_text}]},
                "timestamp": ts,
                "thinking_text": thinking_text,
                "content_source": "response",
            }
        # Otherwise, return thinking as a special type — caller will aggregate
        if thinking_text:
            return {
                "type": "_thinking",  # Not emitted directly; accumulated by caller
                "thinking_text": thinking_text,
                "timestamp": ts,
            }
        return None

    elif step_type == "CORTEX_STEP_TYPE_NOTIFY_USER":
        payload = step.get("notifyUser", {})
        # notificationContent is the actual AI reply shown to the user in Cascade mode
        text = (payload.get("notificationContent", "")
                or payload.get("message", "")
                or payload.get("text", ""))
        if text:
            return {
                "type": "assistant",
                "message": {"role": "assistant", "content": [{"type": "text", "text": text}]},
                "timestamp": ts,
                "content_source": "notify_user",
            }

    elif step_type == "CORTEX_STEP_TYPE_ERROR_MESSAGE":
        payload = step.get("errorMessage", {})
        text = payload.get("shortError") or payload.get("text") or ""
        if text:
            return {"type": "system", "message": {"role": "system", "content": text}, "timestamp": ts}

    elif step_type in ("CORTEX_STEP_TYPE_TASK_BOUNDARY", "CORTEX_STEP_TYPE_CHECKPOINT",
                        "CORTEX_STEP_TYPE_CONVERSATION_HISTORY", "CORTEX_STEP_TYPE_EPHEMERAL_MESSAGE"):
        # Task boundary: show as progress update (not skip)
        if step_type == "CORTEX_STEP_TYPE_TASK_BOUNDARY":
            meta = step.get("metadata", {})
            tool_call = meta.get("toolCall", {})
            args_json = tool_call.get("argumentsJson", "")
            if args_json:
                tool_input, content = _format_tool_call("task_boundary", args_json)
                if content:
                    return {"type": "system", "message": {"role": "system", "content": content}, "timestamp": ts}
        return None  # Skip other internal types

    else:
        # All tool-like steps: RUN_COMMAND, VIEW_FILE, CODE_ACTION, LIST_DIR, GREP, FIND, etc.
        # First try metadata.toolCall
        meta = step.get("metadata", {})
        tool_call = meta.get("toolCall", {})
        tool_name = tool_call.get("name", "")
        args_json = tool_call.get("argumentsJson", "")

        # Fallback for specific step types
        if not tool_name:
            if step_type == "CORTEX_STEP_TYPE_RUN_COMMAND":
                payload = step.get("runCommand", {})
                cmd = payload.get("command") or payload.get("commandLine") or ""
                output = payload.get("renderedOutput", {})
                out_text = output.get("full", "") if isinstance(output, dict) else str(output or "")
                if cmd:
                    return {"type": "tool", "role": "tool", "tool_name": "run_command", "tool_input": cmd, "content": out_text, "timestamp": ts}
                return None
            elif step_type == "CORTEX_STEP_TYPE_VIEW_FILE":
                payload = step.get("viewFile", {})
                path = payload.get("absolutePath") or payload.get("absolutePathUri") or ""
                if path:
                    return {"type": "tool", "role": "tool", "tool_name": "view_file", "tool_input": path, "content": f"`{path}`", "timestamp": ts}
                return None
            else:
                return None

        tool_input, content = _format_tool_call(tool_name, args_json)
        return {"type": "tool", "role": "tool", "tool_name": tool_name, "tool_input": tool_input, "content": content, "timestamp": ts}

    return None


def export_conversations() -> list[dict]:
    """Export Antigravity conversations as JSONL (compatible with conversation parser).

    Requires: pip install antigravity-history
    Requires: Antigravity IDE to be running

    Returns list of changed conversations with JSONL content.
    """
    discover_language_servers = None
    find_all_endpoints = None
    get_all_trajectories = None
    call_api = None
    try:
        from antigravity_history.discovery import discover_language_servers, find_all_endpoints
        from antigravity_history.api import get_all_trajectories, call_api
    except ImportError:
        logger.debug("antigravity-history not installed, using offline export only")

    home = Path.home()
    import platform
    if platform.system() == "Windows":
        import os
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        gemini_root = appdata / ".gemini" if (appdata / ".gemini").exists() else home / ".gemini"
    else:
        gemini_root = home / ".gemini"
    antigravity_root = gemini_root / "antigravity"
    conv_root = antigravity_root / "conversations"

    try:
        from .antigravity_vscdb import extract_agent_manager_sessions
        offline_sessions = extract_agent_manager_sessions()
    except Exception as e:
        logger.debug("Antigravity vscdb recovery unavailable: %s", e)
        offline_sessions = {}

    try:
        chat_export_sessions = _collect_chat_export_sessions(antigravity_root)
    except Exception as e:
        logger.debug("Antigravity chat export recovery unavailable: %s", e)
        chat_export_sessions = {}

    if discover_language_servers and find_all_endpoints and get_all_trajectories:
        try:
            servers = discover_language_servers()
            endpoints = find_all_endpoints(servers) if servers else []
        except Exception as e:
            logger.debug("Antigravity discovery failed: %s", e)
            endpoints = []
    else:
        endpoints = []

    conversations = []

    summaries: dict[str, dict] = {}
    cascade_eps: dict[str, list[dict]] = defaultdict(list)
    seen_endpoint_keys: dict[str, set[str]] = defaultdict(set)

    for ep in endpoints:
        try:
            live_summaries = get_all_trajectories(ep["port"], ep["csrf"])
        except Exception:
            live_summaries = {}
        for cascade_id, info in live_summaries.items():
            summaries[cascade_id] = _merge_summary(summaries.get(cascade_id), info)
            ep_key = _endpoint_key(ep)
            if ep_key not in seen_endpoint_keys[cascade_id]:
                cascade_eps[cascade_id].append(ep)
                seen_endpoint_keys[cascade_id].add(ep_key)

    if not endpoints and not conv_root.exists() and not offline_sessions and not chat_export_sessions:
        return []

    uuid_re = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
    pb_count = 0
    if conv_root.exists():
        for pb_file in conv_root.glob("*.pb"):
            cascade_id = pb_file.stem
            if not uuid_re.match(cascade_id):
                continue
            pb_count += 1
            if cascade_id not in summaries:
                summaries[cascade_id] = {
                    "summary": f"[unindexed] {cascade_id[:8]}...",
                    "stepCount": 0,
                    "lastModifiedTime": "",
                    "createdTime": "",
                    "status": "unindexed",
                    "workspaces": [],
                }
            for ep in endpoints:
                ep_key = _endpoint_key(ep)
                if ep_key not in seen_endpoint_keys[cascade_id]:
                    cascade_eps[cascade_id].append(ep)
                    seen_endpoint_keys[cascade_id].add(ep_key)

    if pb_count > 0:
        logger.info("Indexed %d Antigravity .pb sessions, %d unique cascades total", pb_count, len(summaries))

    if offline_sessions:
        for cascade_id, session in offline_sessions.items():
            summaries[cascade_id] = _merge_summary(
                summaries.get(cascade_id),
                _summary_from_offline_session(session),
            )
        logger.info(
            "Indexed %d Antigravity offline sessions from state.vscdb",
            len(offline_sessions),
        )

    if chat_export_sessions:
        for cascade_id, session in chat_export_sessions.items():
            summaries[cascade_id] = _merge_summary(
                summaries.get(cascade_id),
                _summary_from_offline_session(session),
            )
        logger.info(
            "Indexed %d Antigravity chat export sessions from code_tracker",
            len(chat_export_sessions),
        )

    for cascade_id, info in summaries.items():
        candidate_eps = cascade_eps.get(cascade_id) or list(endpoints)
        offline_session = offline_sessions.get(cascade_id)
        chat_export_session = chat_export_sessions.get(cascade_id)

        if candidate_eps and (
            not info.get("summary")
            or not info.get("createdTime")
            or not info.get("lastModifiedTime")
            or not info.get("workspaces")
            or not info.get("stepCount")
        ):
            trajectory_payload, _ = _call_api_first_success(
                candidate_eps,
                "GetCascadeTrajectory",
                {"cascadeId": cascade_id},
                timeout=30,
                call_api=call_api,
            )
            if trajectory_payload:
                trajectory = trajectory_payload.get("trajectory", trajectory_payload)
                info = _merge_summary(info, {
                    "summary": trajectory.get("summary", ""),
                    "stepCount": trajectory.get("stepCount") or len(trajectory.get("steps", [])),
                    "lastModifiedTime": trajectory.get("lastModifiedTime", ""),
                    "createdTime": trajectory.get("createdAt", trajectory.get("createdTime", "")),
                    "status": trajectory.get("status", ""),
                    "workspaces": trajectory.get("workspaces", []),
                })
                summaries[cascade_id] = info

        if offline_session:
            info = _merge_summary(info, _summary_from_offline_session(offline_session))
            summaries[cascade_id] = info
        if chat_export_session:
            info = _merge_summary(info, _summary_from_offline_session(chat_export_session))
            summaries[cascade_id] = info

        title = info.get("summary", cascade_id[:8])
        step_count = int(info.get("stepCount") or 0)
        last_modified = info.get("lastModifiedTime", "")
        created = info.get("createdTime", "")

        workspace = ""
        workspaces = info.get("workspaces", [])
        if workspaces and isinstance(workspaces[0], dict):
            workspace = workspaces[0].get("workspaceFolderAbsoluteUri", "")
        if not workspace and offline_session:
            workspace = str(offline_session.get("workspace", "") or "")
        if not workspace and chat_export_session:
            workspace = str(chat_export_session.get("workspace", "") or "")

        local_artifacts = _collect_local_session_artifacts(antigravity_root, cascade_id)

        summary_key = (
            f"v20:{cascade_id}:{step_count}:{last_modified}:{title}:"
            f"{int(bool(local_artifacts.get('pb_file_present')))}:"
            f"{int(local_artifacts.get('brain_file_count', 0))}:"
            f"{int(local_artifacts.get('browser_recording_frame_count', 0))}:"
            f"{int(local_artifacts.get('browser_recording_highlight_count', 0))}:"
            f"{chat_export_session.get('lastModifiedTime', '') if chat_export_session else ''}:"
            f"{len(chat_export_session.get('messages', [])) if chat_export_session else 0}"
        )
        content_hash = hashlib.sha256(summary_key.encode()).hexdigest()[:16]
        if _last_hashes.get(cascade_id) == content_hash:
            continue
        _last_hashes[cascade_id] = content_hash

        cwd = ""
        if workspace:
            cwd = unquote(workspace).replace("\\", "/")
            if cwd.startswith("file:///"):
                cwd = cwd[7:] if cwd[8:9] != ":" else cwd[8:]

        jsonl_lines = []
        existing_message_texts: set[str] = set()
        assistant_response_count = 0
        assistant_thinking_count = 0
        assistant_thinking_only_count = 0
        assistant_fallback_count = 0
        user_message_count = 0
        step_fetch_failed = False
        generator_diag: dict[str, object] = {
            "generator_metadata_messages": 0,
            "transcript_messages": 0,
            "messages_truncated": False,
        }
        pb_diag: dict[str, object] = {
            "offline_pb_transcript_messages": 0,
            "offline_pb_messages": 0,
            "offline_pb_total_messages": 0,
            "offline_pb_string_count": 0,
        }
        vscdb_diag: dict[str, object] = {
            "offline_vscdb_messages": 0,
            "offline_vscdb_assistant_messages": 0,
            "offline_vscdb_system_messages": 0,
        }
        chat_export_diag: dict[str, object] = {
            "chat_export_messages": 0,
            "chat_export_user_messages": 0,
            "chat_export_action_messages": 0,
        }

        jsonl_lines.append(json.dumps({
            "type": "session_meta",
            "timestamp": created,
            "payload": {
                "id": cascade_id,
                "timestamp": created,
                "cwd": cwd,
                "originator": "Antigravity",
                "model_provider": "google",
                "title": title,
                "step_count": step_count,
                "status": info.get("status", ""),
            },
        }, ensure_ascii=False))

        # Fetch all steps in one call — startIndex/endIndex are ignored by the API
        steps: list[dict] = []
        step_fetch_failed = False
        steps_response, _ = _call_api_first_success(
            candidate_eps,
            "GetCascadeTrajectorySteps",
            {"cascadeId": cascade_id, "verbosity": 1},
            timeout=120,
            call_api=call_api,
        )
        if not steps_response:
            step_fetch_failed = True
        else:
            steps = steps_response.get("steps", [])
        # Process steps: accumulate thinking, attach to next NOTIFY_USER
        pending_thinking: list[str] = []
        for step in steps:
            if step.get("type") == "CORTEX_STEP_TYPE_PLANNER_RESPONSE":
                planner_response = step.get("plannerResponse", {})
                thinking_text = _normalize_text(planner_response.get("thinking", ""))
                if thinking_text:
                    assistant_thinking_count += 1

            msg = _step_to_jsonl_line(step, cascade_id, last_modified)
            if not msg:
                continue

            # Accumulate thinking — don't emit as message
            if msg["type"] == "_thinking":
                pending_thinking.append(msg["thinking_text"])
                continue

            if msg["type"] == "user" and cwd and not msg.get("cwd"):
                msg["cwd"] = cwd
            if msg["type"] == "user":
                user_message_count += 1
                # Flush accumulated thinking before user message (as context)
                pending_thinking = []

            if msg["type"] == "assistant":
                assistant_response_count += 1
                # Attach accumulated thinking to assistant message
                if pending_thinking:
                    msg["thinking_text"] = "\n\n---\n\n".join(pending_thinking)
                    pending_thinking = []

            content = _normalize_text(msg.get("message", {}).get("content", msg.get("content", "")))
            if content:
                existing_message_texts.add(f"{msg.get('type', 'assistant')}:{content}")
            jsonl_lines.append(json.dumps(msg, ensure_ascii=False))

        # Always try generator metadata with offset-based pagination
        # (each page may hit 4MB limit, so paginate and retry without messages)
        all_generator_metadata: list[dict] = []
        gen_offset = 0
        while True:
            chunk_payload, _ = _call_api_first_success(
                candidate_eps,
                "GetCascadeTrajectoryGeneratorMetadata",
                {"cascadeId": cascade_id, "generatorMetadataOffset": gen_offset, "includeMessages": True},
                timeout=60,
                call_api=call_api,
            )
            if not chunk_payload:
                # Retry without includeMessages (avoids 4MB limit)
                chunk_payload, _ = _call_api_first_success(
                    candidate_eps,
                    "GetCascadeTrajectoryGeneratorMetadata",
                    {"cascadeId": cascade_id, "generatorMetadataOffset": gen_offset},
                    timeout=60,
                    call_api=call_api,
                )
            if not chunk_payload:
                break
            chunk = chunk_payload.get("generatorMetadata", [])
            if not chunk:
                break
            all_generator_metadata.extend(chunk)
            gen_offset += len(chunk)
            # Also check top-level fields (non-paginated responses)
            if "generatorMetadata" not in chunk_payload:
                all_generator_metadata.append(chunk_payload)
                break

        if all_generator_metadata:
            fallback_messages, generator_diag = _extract_generator_fallbacks(
                {"generatorMetadata": all_generator_metadata}, last_modified,
            )
            fallback_messages = _dedupe_fallback_messages(fallback_messages, existing_message_texts)
            assistant_fallback_count = len(fallback_messages)
            for msg in fallback_messages:
                jsonl_lines.append(json.dumps(msg, ensure_ascii=False))
        elif not all_generator_metadata:
            # Single non-paginated attempt as final fallback
            metadata_payload, _ = _call_api_first_success(
                candidate_eps,
                "GetCascadeTrajectoryGeneratorMetadata",
                {"cascadeId": cascade_id, "includeMessages": True},
                timeout=60,
                call_api=call_api,
            )
            if not metadata_payload:
                metadata_payload, _ = _call_api_first_success(
                    candidate_eps,
                    "GetCascadeTrajectoryGeneratorMetadata",
                    {"cascadeId": cascade_id},
                    timeout=60,
                    call_api=call_api,
                )
            if metadata_payload:
                fallback_messages, generator_diag = _extract_generator_fallbacks(metadata_payload, last_modified)
                fallback_messages = _dedupe_fallback_messages(fallback_messages, existing_message_texts)
                assistant_fallback_count = len(fallback_messages)
                for msg in fallback_messages:
                    jsonl_lines.append(json.dumps(msg, ensure_ascii=False))

        if offline_session and (len(jsonl_lines) == 1 or assistant_response_count == 0 or step_fetch_failed):
            vscdb_messages = _dedupe_fallback_messages(
                list(offline_session.get("messages", [])),
                existing_message_texts,
            )
            vscdb_diag["offline_vscdb_messages"] = len(vscdb_messages)
            vscdb_diag["offline_vscdb_assistant_messages"] = sum(
                1 for msg in vscdb_messages if msg.get("type") == "assistant"
            )
            vscdb_diag["offline_vscdb_system_messages"] = sum(
                1 for msg in vscdb_messages if msg.get("type") == "system"
            )
            for msg in vscdb_messages:
                jsonl_lines.append(json.dumps(msg, ensure_ascii=False))

        if chat_export_session and (len(jsonl_lines) == 1 or step_fetch_failed or user_message_count == 0):
            chat_export_messages = _dedupe_fallback_messages(
                list(chat_export_session.get("messages", [])),
                existing_message_texts,
            )
            chat_export_diag["chat_export_messages"] = len(chat_export_messages)
            chat_export_diag["chat_export_user_messages"] = sum(
                1 for msg in chat_export_messages if msg.get("type") == "user"
            )
            chat_export_diag["chat_export_action_messages"] = sum(
                1 for msg in chat_export_messages if msg.get("type") == "system"
            )
            for msg in chat_export_messages:
                jsonl_lines.append(json.dumps(msg, ensure_ascii=False))

        pb_path = conv_root / f"{cascade_id}.pb"
        if pb_path.exists() and (len(jsonl_lines) == 1 or assistant_response_count == 0):
            pb_messages, pb_diag = _extract_pb_fallback_messages(pb_path, last_modified or created)
            pb_messages = _dedupe_fallback_messages(pb_messages, existing_message_texts)
            for msg in pb_messages:
                jsonl_lines.append(json.dumps(msg, ensure_ascii=False))

        pb_shell_only = bool(
            local_artifacts.get("pb_file_present")
            and not candidate_eps
            and not offline_session
            and not chat_export_session
            and assistant_response_count == 0
            and assistant_fallback_count == 0
            and not pb_diag.get("offline_pb_total_messages")
        )

        if len(jsonl_lines) == 1:
            stub_reasons = []
            if step_fetch_failed:
                stub_reasons.append("live step RPC failed")
            if pb_shell_only:
                stub_reasons.append("only encrypted local .pb cache is available")
            if local_artifacts.get("brain_file_count"):
                stub_reasons.append(f"brain files={int(local_artifacts['brain_file_count'])}")
            if local_artifacts.get("browser_recording_frame_count"):
                stub_reasons.append(
                    f"browser frames={int(local_artifacts['browser_recording_frame_count'])}"
                )
            reason_suffix = f" ({'; '.join(stub_reasons)})" if stub_reasons else ""
            jsonl_lines.append(json.dumps({
                "type": "system",
                "message": {
                    "role": "system",
                    "content": (
                        "Conversation body unavailable from live Antigravity RPC. "
                        "This session was discovered from local cache or metadata only."
                        f"{reason_suffix}"
                    ),
                },
                "timestamp": last_modified or created,
                "fallback_source": "session_stub",
            }, ensure_ascii=False))

        content = "\n".join(jsonl_lines)

        project_name = cwd.rstrip("/").split("/")[-1] if cwd else None
        diagnostics = {
            "step_count": step_count,
            "assistant_response_count": assistant_response_count,
            "assistant_thinking_count": assistant_thinking_count,
            "assistant_thinking_only_count": assistant_thinking_only_count,
            "assistant_fallback_count": assistant_fallback_count,
            "user_message_count": user_message_count,
            "step_fetch_failed": step_fetch_failed,
            "endpoint_count": len(candidate_eps),
            "pb_shell_only": pb_shell_only,
            **generator_diag,
            **vscdb_diag,
            **chat_export_diag,
            **pb_diag,
            **local_artifacts,
        }

        if (
            assistant_thinking_only_count > 0
            or assistant_fallback_count > 0
            or generator_diag.get("messages_truncated")
            or step_fetch_failed
            or vscdb_diag.get("offline_vscdb_messages")
            or chat_export_diag.get("chat_export_messages")
            or pb_diag.get("offline_pb_total_messages")
            or pb_shell_only
        ):
            logger.warning(
                "Antigravity %s: user_messages=%d, planner responses=%d, thinking_only=%d, recovered=%d, transcript=%d, metadata=%d, offline_vscdb=%d, chat_export=%d, offline_pb=%d, pb_shell_only=%s, truncated=%s, step_fetch_failed=%s",
                cascade_id[:8],
                user_message_count,
                assistant_response_count,
                assistant_thinking_only_count,
                assistant_fallback_count,
                int(generator_diag.get("transcript_messages", 0)),
                int(generator_diag.get("generator_metadata_messages", 0)),
                int(vscdb_diag.get("offline_vscdb_messages", 0)),
                int(chat_export_diag.get("chat_export_messages", 0)),
                int(pb_diag.get("offline_pb_total_messages", 0)),
                pb_shell_only,
                bool(generator_diag.get("messages_truncated", False)),
                step_fetch_failed,
            )

        conversations.append({
            "title": title,
            "cascade_id": cascade_id,
            "workspace": workspace,
            "project_name": project_name,
            "size": len(content),
            "content": content,
            "content_hash": content_hash,
            "export_diagnostics": diagnostics,
        })

    if conversations:
        logger.info("Exported %d changed Antigravity conversations", len(conversations))
    return conversations
