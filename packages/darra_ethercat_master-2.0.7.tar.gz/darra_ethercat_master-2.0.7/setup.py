# -*- coding: utf-8 -*-
"""
DarraEtherCAT Python SDK 构建脚本
支持两种模式:
  1. 纯 Python 安装: pip install .
  2. Cython 编译安装: python setup.py build_ext --inplace

注意: 主要配置在 pyproject.toml 中, 此文件仅用于 Cython 扩展编译
"""

import os
import sys
from setuptools import setup, find_packages

# 读取版本号
# [2026-05-07] 包目录已重命名 ethercat → darra_ethercat (跟 NuGet/Java/Rust 命名统一)
version_file = os.path.join(os.path.dirname(__file__), "darra_ethercat", "VERSION")
with open(version_file, "r", encoding="utf-8") as f:
    VERSION = f.read().strip()


def get_extensions():
    """获取 Cython 扩展模块列表"""
    try:
        from Cython.Build import cythonize
    except ImportError:
        # 未安装 Cython 时跳过编译
        print("[警告] Cython 未安装, 跳过原生扩展编译")
        return []

    # 需要编译的模块 (__init__.py 不编译, 保留为入口)
    # [2026-05-07] ethercat/ → darra_ethercat/ 同步
    modules = [
        "darra_ethercat/core.py",
        "darra_ethercat/master.py",
        "darra_ethercat/slave.py",
    ]

    # 只编译存在的文件
    modules = [m for m in modules if os.path.exists(m)]

    if not modules:
        return []

    return cythonize(
        modules,
        compiler_directives={
            "language_level": "3",         # Python 3 语法
            "boundscheck": False,          # 关闭边界检查 (性能)
            "wraparound": False,           # 关闭负索引检查 (性能)
            "embedsignature": True,        # 保留函数签名
            "annotation_typing": True,     # 使用类型注解
        },
        build_dir="build/cython",
    )


# 仅在需要编译扩展时执行
if "build_ext" in sys.argv or "bdist_wheel" in sys.argv:
    ext_modules = get_extensions()
else:
    ext_modules = []

setup(
    # [2026-05-04] 改为 darra-ethercat-master, 与 NuGet/Java/Rust 命名风格统一.
    # 注: pyproject.toml 是主配置, 此处保留作 Cython 扩展兜底; 必须保持一致.
    name="Darra_EtherCAT_Master",
    version=VERSION,
    ext_modules=ext_modules,
)
