# -*- coding: utf-8 -*-
"""
工具模块
包含 DLL 加载、基础数据常量、启动配置验证、ESI、XML 等工具
"""

from .dll import (
    # 枚举
    EcState, EcLinkState, RingMode, EcErr,
    CiA402State, FsoEState, FsoEError,
    # 结构体
    DllVersionInfo, SlaveIdentity, SlaveEsmTimeouts,
    WatchdogConfig, WatchdogStatus, MasterIdentity, MasterDiagData,
    StartupParam, FoEOptions, EmcyRecord, TopologyNode,
    RedundancyStatus, CommunicationStats, EscPortErrorStats,
    FsoEConfig, FsoEStatus, SafeMdpConfig,
    # 启动参数常量
    TRANS_IP, TRANS_PS, TRANS_SO, TRANS_OS, TRANS_SP, TRANS_PI,
    TIMING_BEFORE, TIMING_AFTER,
    # 底层 DLL 接口
    DarraCoreDLL,
)

from .base_data import (
    EC_MAX_SLAVE, EC_MAX_GROUP, EC_MAX_MAILBOX_SIZE, EC_MAX_SDO_SIZE,
    EC_MAX_EEPROM_SIZE, EC_MAX_NAME, EC_MAX_PORTS, EC_MAX_FMMU, EC_MAX_SM,
    ip_to_int, int_to_ip, mac_to_bytes, bytes_to_mac,
    BaseData,
)

from .startup_verifier import (
    ExpectedSlaveConfig, SlaveVerifyDetail, VerificationResult,
    verify_configuration, verify_configuration_detailed,
    create_expected_configs_from_dict,
    create_expected_configs_from_xml, verify_configuration_with_dll,
)

from .help import convert_byte_array_to_string

from .esi import (
    ESIPhysicsPortType,
    calculate_eeprom_crc, validate_eeprom_crc,
    get_default_esi_path, find_esi_file,
)

from .version_info import (
    parse_version_string, format_version,
    check_version_compatibility,
)

from .xml import (
    MasterXMLConfiguration,
    load_xml_configuration,
)
