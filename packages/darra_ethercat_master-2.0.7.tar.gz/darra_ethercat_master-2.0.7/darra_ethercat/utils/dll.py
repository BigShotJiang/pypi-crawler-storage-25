# -*- coding: utf-8 -*-
"""
Darra.Core.dll 原生绑定层
通过 ctypes 加载 DLL 并声明所有函数签名
"""

import ctypes
import ctypes.util
import os
import sys
import struct
import marshal
import base64
from ctypes import (
    c_bool, c_byte, c_ubyte, c_short, c_ushort, c_int, c_uint,
    c_int16, c_uint16, c_uint32, c_uint64, c_float, c_double, c_char_p,
    c_void_p, c_size_t, POINTER, Structure, byref, cast, CFUNCTYPE,
    create_string_buffer,
)
from enum import IntEnum, IntFlag
from typing import Optional


# ===================== Opaque native command bridge =====================
# 这些常量是底层调度器 DarraCoreInvoke / DarraCoreInvokeText 的命令 id;
# 语义映射对发行版本不公开 (semantic mapping intentionally redacted).
# 名字保留 _NN 形式仅为兼容历史调用点, 不代表任何稳定的对外 ABI.
CORE_OP_21 = 0x44525421
CORE_OP_22 = 0x44525422
CORE_OP_23 = 0x44525423
CORE_OP_24 = 0x44525424
CORE_OP_25 = 0x44525425
CORE_OP_26 = 0x44525426
CORE_OP_27 = 0x44525427
CORE_OP_28 = 0x44525428
CORE_FLAG_01 = 0x00000001
CORE_FLAG_04 = 0x00000004
CORE_FLAG_08 = 0x00000008


# ===================== 枚举定义 =====================

class EcState(IntEnum):
    """EtherCAT 从站状态"""
    NONE = 0x00
    INIT = 0x01
    PRE_OP = 0x02
    BOOT = 0x03
    SAFE_OP = 0x04
    OP = 0x08
    ACK = 0x10
    ERROR = 0x10

    @property
    def base_state(self) -> 'EcState':
        """获取基础状态 (低4位)"""
        return EcState(self.value & 0x0F)

    @property
    def has_error(self) -> bool:
        """是否包含 Error 标志"""
        return bool(self.value & 0x10)

    def format(self) -> str:
        """格式化为可读字符串"""
        base = self.base_state
        names = {
            EcState.NONE: "None", EcState.INIT: "Init",
            EcState.PRE_OP: "PreOp", EcState.BOOT: "Boot",
            EcState.SAFE_OP: "SafeOp", EcState.OP: "OP",
        }
        name = names.get(base, f"0x{base.value:02X}")
        return f"{name}+Error" if self.has_error else name


class EcLinkState(IntEnum):
    """链路状态"""
    DISCONNECTED = 0
    CONNECTED = 1
    PRIMARY_ONLY = 3
    SECONDARY_ONLY = 4


class RingMode(IntEnum):
    """环拓扑冗余运行模式"""
    INACTIVE = 0    # 未激活
    DUAL = 1        # 双向冗余
    DEGRADED = 2    # 降级模式


class EcErr(IntEnum):
    """错误码"""
    OK = 0
    ALREADY_INITIALIZED = 1
    NOT_INITIALIZED = 2
    TIMEOUT = 3
    NO_SLAVES = 4
    NOK = 5


# ===================== 结构体定义 =====================

class DllVersionInfo(Structure):
    """DLL 版本信息"""
    _pack_ = 1
    _fields_ = [
        ("major", c_ushort),
        ("minor", c_ushort),
        ("patch", c_ushort),
        ("build", c_ushort),
        ("build_date", ctypes.c_char * 32),
    ]


class SiiGeneralInfoNative(Structure):
    """SII General Category (type=30) 结构化信息.
    对齐 Drive Core.h sii_general_info_t (Pack=1, 21 字节)
    与 C# DLL.SiiGeneralInfoNative 一致."""
    _pack_ = 1
    _fields_ = [
        ("group_idx", c_ubyte),
        ("image_idx", c_ubyte),
        ("order_idx", c_ubyte),
        ("name_idx", c_ubyte),
        ("coe_details", c_ubyte),
        ("foe_details", c_ubyte),
        ("eoe_details", c_ubyte),
        ("soe_details", c_ubyte),
        ("flags", c_ubyte),
        ("ebus_current_ma", ctypes.c_int16),
        ("physical_port", c_ushort),
        ("reserved", c_ubyte * 8),
    ]


class SlaveIdentity(Structure):
    """从站身份信息"""
    _fields_ = [
        ("vendor_id", c_uint),
        ("product_code", c_uint),
        ("revision_no", c_uint),
        ("serial_no", c_uint),
    ]


class SlaveEsmTimeouts(Structure):
    """ESM 超时配置"""
    _fields_ = [
        ("ip", c_uint), ("ps", c_uint), ("so", c_uint), ("os", c_uint),
        ("sp", c_uint), ("pi", c_uint), ("bi", c_uint), ("ib", c_uint),
    ]


class WatchdogConfig(Structure):
    """看门狗配置"""
    _fields_ = [
        ("wd_divider", c_ushort),
        ("wd_time_pdi", c_ushort),
        ("wd_time_pd", c_ushort),
    ]


class WatchdogStatus(Structure):
    """看门狗状态"""
    _fields_ = [
        ("wd_status", c_ubyte),
        ("wd_counter", c_ubyte),
        ("wd_divider", c_ushort),
        ("wd_time_pd", c_ushort),
    ]


class MasterIdentity(Structure):
    """主站身份信息"""
    _fields_ = [
        ("vendor_id", c_uint),
        ("product_code", c_uint),
        ("revision_no", c_uint),
        ("serial_no", c_uint),
        ("device_name", ctypes.c_char * 64),
        ("hw_version", ctypes.c_char * 32),
        ("sw_version", ctypes.c_char * 32),
    ]


class MasterDiagData(Structure):
    """主站诊断数据"""
    _fields_ = [
        ("cyclic_lost_frames", c_uint),
        ("acyclic_lost_frames", c_uint),
        ("cyclic_frames_per_sec", c_uint),
        ("acyclic_frames_per_sec", c_uint),
        ("master_state", c_ushort),
    ]


class StartupParam(Structure):
    """启动参数 (匹配 C DLL ec_startup_param_t)"""
    _pack_ = 1
    _fields_ = [
        ("index", c_ushort),
        ("sub_index", c_ubyte),
        ("data", c_ubyte * 256),
        ("data_len", c_ushort),
        ("transition", c_ubyte),    # 0=IP, 1=PS, 2=SO, 3=OS, 4=SP, 5=PI
        ("timing", c_ubyte),        # 0=Before, 1=After
        ("priority", c_ushort),
        ("complete_access", c_ubyte),
        ("is_register_write", c_ubyte),
    ]


class FoEOptions(Structure):
    """FoE 扩展选项 (匹配 C DLL ec_foe_options_t).

    [2026-05-09 修复 ABI 错位] Drive `foe_options_t` 是 #pragma pack(push, 1),
    Python 默认自然对齐会在 expected_crc (uint) 前插 1 字节填充, 字段全部错位 →
    expected_crc / pointer / reserved 接收方读到错值或悬空指针.
    必须 _pack_ = 1 与 Drive 一致.
    """
    _pack_ = 1
    _fields_ = [
        ("enable_crc", c_ubyte),
        ("strict_mode", c_ubyte),
        ("auto_append_crc", c_ubyte),
        ("expected_crc", c_uint),
        ("crc_progress_callback", c_void_p),
        ("crc_callback_userdata", c_void_p),
        ("reserved", c_uint * 8),
    ]


class RedundancyStatus(Structure):
    """冗余状态信息 (匹配 C DLL ec_redundancy_status_t)"""
    _fields_ = [
        ("state", c_int),
        ("primary_link_up", c_int),
        ("secondary_link_up", c_int),
        ("primary_tx_frames", c_uint),
        ("primary_rx_frames", c_uint),
        ("secondary_tx_frames", c_uint),
        ("secondary_rx_frames", c_uint),
        ("failover_count", c_uint),
        ("last_failover_time", c_uint),
    ]


class CommunicationStats(Structure):
    """通信统计信息 (匹配 C DLL ec_communication_stats_t)"""
    _fields_ = [
        ("total_cycles", c_uint),
        ("successful_cycles", c_uint),
        ("failed_cycles", c_uint),
        ("timeout_cycles", c_uint),
        ("average_cycle_time_us", c_double),
        ("max_cycle_time_us", c_double),
        ("min_cycle_time_us", c_double),
    ]


class PDOStats(Structure):
    """PDO 性能统计结构体 (对应 C# Structures.PDOStats, Pack=1, uint*5 + ulong*4)"""
    _pack_ = 1
    _fields_ = [
        ("read_count", c_uint),
        ("write_count", c_uint),
        ("error_count", c_uint),
        ("total_bytes_read", c_uint),
        ("total_bytes_written", c_uint),
        ("last_cycle_time_ns", c_uint64),
        ("min_cycle_time_ns", c_uint64),
        ("max_cycle_time_ns", c_uint64),
        ("avg_cycle_time_ns", c_uint64),
    ]


class FsoEState(IntEnum):
    """FSoE 状态机状态 (ETG.5100)"""
    RESET = 0x100       # 初始/重置状态
    SESSION = 0x101     # 会话建立
    CONNECTION = 0x102  # 连接建立
    PARAMETER = 0x103   # 参数下载
    DATA = 0x104        # 数据交换
    FAILSAFE = 0x105    # 失效安全


class FsoEError(IntEnum):
    """FSoE 错误代码 (ETG.5001.4)"""
    NONE = 0x0000               # 无错误
    WRONG_COMMAND = 0x0001      # 错误的命令
    UNKNOWN_COMMAND = 0x0002    # 未知命令
    WRONG_CONN_ID = 0x0003      # 连接ID不匹配
    CRC = 0x0004                # CRC校验失败
    WATCHDOG = 0x0005           # 看门狗超时
    WRONG_ADDRESS = 0x0006      # 错误的FSoE地址
    WRONG_DATA = 0x0007         # 无效数据
    COMM_PARAM_LENGTH = 0x0008  # 通信参数长度错误
    COMM_PARAM = 0x0009         # 通信参数错误
    APP_PARAM_LENGTH = 0x000A   # 应用参数长度错误
    APP_PARAM = 0x000B          # 应用参数错误
    UNEXPECTED_SESSION = 0x000C # 意外的会话命令
    FAILSAFE_DATA = 0x000D      # 收到失效安全数据
    NOT_INITIALIZED = 0x0100    # FSoE未初始化
    MAX_CONNECTIONS = 0x0101    # 达到最大连接数
    INVALID_STATE = 0x0102      # 无效状态转换


class CiA402State(IntEnum):
    """CiA 402 驱动状态"""
    NOT_READY = 0           # 未就绪
    SWITCH_ON_DISABLED = 1  # 使能关闭
    READY_TO_SWITCH_ON = 2  # 准备使能
    SWITCHED_ON = 3         # 已使能
    OPERATION_ENABLED = 4   # 运行
    QUICK_STOP_ACTIVE = 5   # 快速停止
    FAULT_REACTION = 6      # 故障反应中
    FAULT = 7               # 故障
    UNKNOWN = 99            # 未知


class EmcyRecord(Structure):
    """EMCY 紧急消息记录"""
    _pack_ = 1
    _fields_ = [
        ("error_code", c_ushort),
        ("error_register", c_ubyte),
        ("data", c_ubyte * 5),
        ("slave_index", c_ushort),
        ("timestamp_ms", c_uint),
    ]


class CoeDiagMetaNative(Structure):
    """
    CoE 0x10F3 诊断历史元数据 (非 DLL 结构, 仅 Python 容器用于 out 参数聚合).
    对应 DLL ``coe_diag_read_meta`` 回填的 4 个 out 参数 + abort code.
    """
    _pack_ = 1
    _fields_ = [
        ("max_messages", c_ubyte),
        ("newest_message", c_ubyte),
        ("newest_acknowledged", c_ubyte),
        ("flags", c_ushort),
        ("abort_code", c_uint),
    ]


class HotConnectGroupNative(Structure):
    """
    Hot-Connect 组原生结构 (匹配 C 端 ec_hotconnect_group_t / hotconnect.h struct hotconnect_group_s).

    与 C# DLL.HotConnectGroupNative 对齐 (Pack=1, 16 字节).
    """
    _pack_ = 1
    _fields_ = [
        ("group_id", c_ushort),            # 组 ID
        ("alias_address", c_ushort),       # 期望 Alias 地址
        ("vendor_id", c_uint),             # 期望 VendorID
        ("product_code", c_uint),          # 期望 ProductCode
        ("is_present", c_int),             # 是否在当前扫描中探测到 (BOOL=int)
        ("detected_slave_index", c_ushort),# 匹配的从站索引
        ("reserved", c_ushort),            # 对齐填充
    ]


class TopologyNode(Structure):
    """网络拓扑节点"""
    _pack_ = 1
    _fields_ = [
        ("slave_index", c_ushort),
        ("config_addr", c_ushort),
        ("parent_index", c_ushort),
        ("entry_port", c_ubyte),
        ("active_ports", c_ubyte),
        ("topology", c_ubyte),
        ("port_type", c_ubyte),
    ]


class EscPortErrorStats(Structure):
    """ESC 端口错误统计 (匹配 C DLL esc_port_error_stats_t, 16 字节)

    [2026-05-08] 与 C# DLL.cs ESCPortErrorStats 同步: 加 fwd_rx_error_count.
    C 端 esc_port_error_stats_t 共 16 字节: 4 段 c_ubyte * 4.
    之前只有 12 字节, 缺最后一段, 读取会比 C 少 4 字节, 后续指针偏移偏差.
    """
    _fields_ = [
        ("rx_error_count", c_ubyte * 4),       # 端口 0-3 的 RX 错误计数
        ("invalid_frame_count", c_ubyte * 4),   # 端口 0-3 的无效帧计数
        ("lost_link_count", c_ubyte * 4),       # 端口 0-3 的链路丢失计数
        ("fwd_rx_error_count", c_ubyte * 4),   # 端口 0-3 的转发 RX 错误计数 (Forwarded RX)
    ]


class FsoEConfig(Structure):
    """FSoE 连接配置 (匹配 C DLL fsoe_config_t)"""
    _fields_ = [
        ("connection_id", c_ushort),        # 唯一连接标识符
        ("safety_address", c_ushort),       # FSoE从站安全地址
        ("watchdog_time_ms", c_uint),       # 看门狗超时(毫秒)
        ("safe_input_size", c_ushort),      # 安全输入数据大小(字节)
        ("safe_output_size", c_ushort),     # 安全输出数据大小(字节)
        ("pdo_input_offset", c_uint),       # IOmap中输入偏移
        ("pdo_output_offset", c_uint),      # IOmap中输出偏移
    ]


class FsoEStatus(Structure):
    """FSoE 连接状态 (匹配 C DLL fsoe_status_t)"""
    _fields_ = [
        ("state", c_int),                  # 当前FSoE状态
        ("last_error", c_int),             # 最后的错误代码
        ("error_count", c_uint),           # 总错误计数
        ("frames_sent", c_uint),           # 发送帧数
        ("frames_received", c_uint),       # 接收有效帧数
        ("crc_errors", c_uint),            # CRC错误计数
        ("watchdog_errors", c_uint),       # 看门狗超时计数
        ("watchdog_expired", c_ubyte),     # 当前看门狗状态
        ("in_failsafe", c_ubyte),          # 是否处于失效安全模式
        ("toggle_bit", c_ubyte),           # 当前切换位值
        ("initialized", c_ubyte),          # 连接是否已初始化
    ]


class EcMbxStatsT(Structure):
    """
    邮箱协议统计 (对齐 C 层 ec_mbx_stats_t, x64 自然对齐 72 字节).

    字段含义:
      total_sent/total_received: 发送/接收事务累计
      total_timeout/total_mbx_error/total_proto_error/total_cancelled: 各类错误累计
      last_error_code: 最近一次错误码 (u32) + _pad1 (u32 对齐)
      last_error_time_us: 最近错误时间戳 (微秒)
      total_latency_us: 累计延迟 (微秒, 用于计算平均延迟)
    """
    _fields_ = [
        ("total_sent", c_uint64),
        ("total_received", c_uint64),
        ("total_timeout", c_uint64),
        ("total_mbx_error", c_uint64),
        ("total_proto_error", c_uint64),
        ("total_cancelled", c_uint64),
        ("last_error_code", c_uint32),
        ("_pad1", c_uint32),  # x64 自然对齐 padding, 保证后续 u64 在 8 字节边界
        ("last_error_time_us", c_uint64),
        ("total_latency_us", c_uint64),
    ]


class SafeMdpConfig(Structure):
    """FSoE MDP 多连接配置 (匹配 C DLL fsoe_mdp_config_t)"""
    _fields_ = [
        ("connection_id", c_ushort),        # 唯一连接标识符
        ("safety_address", c_ushort),       # FSoE从站安全地址
        ("watchdog_time_ms", c_uint),       # 看门狗超时(毫秒)
        ("safe_input_size", c_ushort),      # 安全输入数据大小(字节)
        ("safe_output_size", c_ushort),     # 安全输出数据大小(字节)
        ("pdo_input_offset", c_uint),       # IOmap中输入偏移
        ("pdo_output_offset", c_uint),      # IOmap中输出偏移
        ("module_number", c_ushort),        # 模块编号 (槽位号)
        ("module_profile", c_ushort),       # 模块配置文件
        ("axis_number", c_ushort),          # 轴编号
        ("connection_type", c_ushort),      # 连接类型: 0=Master, 1=Slave
    ]


# ===================== 回调类型定义 =====================

LogCallbackType = CFUNCTYPE(None, c_int, c_void_p)
ProcessDataCyclicCallbackType = CFUNCTYPE(None, c_ushort)
SlaveStateChangeCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_int, c_int)
EmergencyEventCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ushort, c_ushort, c_ubyte, c_ushort, c_ushort
)
SlaveDiscoveryCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_int)  # C BOOL = int
RedundancyModeChangedCallbackType = CFUNCTYPE(None, c_ushort, c_int, c_int)
InputDataChangedCallbackType = CFUNCTYPE(None, c_ushort, c_void_p, c_ushort)
FoEProgressCallbackType = CFUNCTYPE(None, c_ushort, c_int, c_int)
DCSyncLostCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_int)
CrashNotifyCallbackType = CFUNCTYPE(None, c_int, c_void_p)
PDOFrameLossCallbackType = CFUNCTYPE(None, c_ushort, c_ubyte, c_uint, c_uint)
SlavePreOpReconfigCallbackType = CFUNCTYPE(None, c_ushort, c_ushort)
# 从站身份不符回调 (v2 热插拔自修复):
# (master_index, slave_index, expected_vendor, expected_product, expected_revision,
#                              actual_vendor,   actual_product,   actual_revision)
SlaveIdentityMismatchCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_uint, c_uint, c_uint, c_uint, c_uint, c_uint
)
# 从站端口链路变化回调: (master_index, slave_index, port, is_up)
# port: 0-3 对应 P0/P1/P2/P3; is_up: 1=link 恢复, 0=link 断开 (C BOOL = int)
SlavePortLinkChangedCallbackType = CFUNCTYPE(None, c_ushort, c_ushort, c_ubyte, c_int)

# SoE Notification / Emergency 回调 (ETG.1020 OpCode=5/6)
# 对应 C# DLL.SoENotificationCallback / DLL.SoEEmergencyCallback.
# Notification: (master_index, slave_index, drive_no, idn, element_flags,
#                data_ptr, data_len); data 仅回调期间有效, 必要时立即复制。
# Emergency   : (master_index, slave_index, drive_no, error_code)
SoENotificationCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ubyte, c_ushort, c_ubyte, c_void_p, c_ushort
)
SoEEmergencyCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ubyte, c_ushort
)

# FoE BUSY 回调 (ETG.1000.6 Table 93 Done/Entire/BusyText)
# 对应 C# DLL.FoEBusyCallback:
#   (slave, done, entire, text_cstr_or_null, retry_idx)
FoEBusyCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_ushort, c_char_p, c_int
)

# EoE 异步接收 Hook 回调 (对齐 C# DLL.EOEFrameCallback).
#   (master_index, slave, frame_data_ptr, frame_size)
# data 仅回调期间有效, 必要时立即拷贝为 bytes.
EOEFrameCallbackType = CFUNCTYPE(
    None, c_ushort, c_ushort, c_void_p, c_int
)

# VoE 异步通知回调 (对齐 C# DLL.VoENotificationCallback).
#   (slave, vendor_id, vendor_type, data_ptr, data_size, user_data)
VoENotificationCallbackType = CFUNCTYPE(
    None, c_ushort, c_uint, c_ushort, c_void_p, c_uint, c_void_p
)


# ===================== 启动参数常量 =====================

TRANS_IP = 0  # Init → PreOp
TRANS_PS = 1  # PreOp → SafeOp
TRANS_SO = 2  # SafeOp → OP
TRANS_OS = 3  # OP → SafeOp
TRANS_SP = 4  # SafeOp → PreOp
TRANS_PI = 5  # PreOp → Init

TIMING_BEFORE = 0
TIMING_AFTER = 1


# ===================== Opaque ordinal lookup =====================
# 该映射表对发行版本不公开明文 (semantic names intentionally redacted).
# 编码方案: marshal -> XOR(_XK) -> base85; 仅运行时解码到内存字典, 源码层不可见.
# 调度器 DarraCoreInvoke / DarraCoreInvokeText 保留命名导出 (公开 ABI), 不在此映射内.
_XK = 0x5A


def _od():
    """运行时解出 ordinal 字典 (模块加载时一次性, 之后只读字典)."""
    raw = base64.b85decode(_ORDINAL_MAP_ENC)
    return marshal.loads(bytes(b ^ _XK for b in raw))


_ORDINAL_MAP_ENC = (
    b"p@2gOKRq)kE<Y$AA}%O99Vj&~Di=E{Dl;@aGqPD)T7XO$Ha|NkA0jR&I~^!BFDe&1Dk?KHJu|aeT"
    b"3Ucc9X~D!Hajdo6hA*cDG4q+C@wE52tPSBG(0msGq71&T7X0uHa|Nk2{t<{KNLSdJ}C(<J18zMDh"
    b"NM0H8eakJu|UcT3Ucg2|q3wC_5=K89O#MI6FBpGqzb;T7XvxKQ0M2J1jpPC^auCGq+h<T7Xv_KQ0"
    b"M2J1jpPC^auCGqhP+T7XUoKQ0|8H7_a|BRMud9y2U6K0hckwOLwPfKDAhE*&T}FDe-$IW|8YGb}S"
    b"cKPWS*Sz20vRS7>X9Vj&~DjzgEI5s~%GpkuzT7Xp@KQ0|8H7_b3G&?vpKRz?4Sz20vNgY2f9Vj&~"
    b"Djy;$KRGTxJ`E8WGpSixT7XL(KQ0|8H7_a~IW8|dHVqLOGp<=$T7Xs^KQ0|8H7_b2Gdn#quUT4Jf"
    b"Jq%cE*m*6Gb}$HC^auC88t67E;FoIT3Uce9X~D|C^auC2{t<{KN&SIG%ho(Sz20vP8~lk8!S6BHa"
    b"j>rKN%`788s+BDKny3T3Uck2|q3uJ1H(dC>bg*8$3KSG&3$EGox8rT7XXpKQ0O=H90>iDH$p+8$3"
    b"KSG&3$EGoV>oT7W?aKQ}cjKL|fNHZC(aKNTu2GdD9JJ1#RdG$}KoSz20vL>)ga2tPYEE;Bbj6)G+"
    b">H!~nRE;BVWDG4q+E-xuFrde8AfK3TME(#tM4l*b|J3bjIFB?2OGc+?UBQvL2T3Ucj9X~D#9u*EU"
    b"C_g(s87eOuJUlZrGcF@Dq*+>8fKLfOE*=>hFD^9+GBZ3bA2d5SHa|WyrCC~9fKMGiE*=>hFD^9+G"
    b"BZ3bA2d5SHa|WyT3%XOfIuEQC@4D&J2o>uJ1##CGdDjd8#y^IC_6bLGh1F-T7XmuKQ0zEJsCSTHa"
    b"I&uF*8_RT3Uco4k$Z0KNdATGg)3*T7XvxKQ0O$6&5u;Ju@^tGhSX=T7XLlKQ0$LGd4IiA{I40Ju@"
    b"^tGhbd>T7XpvKQ10WI4?aGH9b8uG(9t1URqj!R~a@nDL)=RI4?aGH9a$3URqj!e+WN4Gbt`VC<-V"
    b"wIX@{W9y=~O86!D1GdUSMHa0jrIWY+%G&wU;URqj!d<Z{1Gbt`VC<-VwIX@{W9y=~O86!D1GdUSM"
    b"Ha0jrIWZe4BQ!ZPQ(jtHfPM%+Ju@jTKPU+{J1jp5E;}wi88SOGJwF*cHa0jrIWY+%G&wU+URqj!e"
    b"+WN4Gbt`VC<!(@EI$b@J1##NGCMRqKN&kVHaI&uF&il(G&wU-URqj!L<m1UGbt`VC?7XJC_O(kIU"
    b"^q|KQt~GJ2o~rJ2^2kR$f|KfOrT$Ju@jTKPU+{J1jpQGbuSWEI%kC89O#MI6FBp2_rN)Ggn?(T7Y"
    b">7KRq)kE<Y#<Hajdo9y2L9H7q|UBN;n3HaI&uF&il(G&wU=URqj!MhHJWGbt`VC<-1G94I?CKNdA"
    b"9DH%I9HaI&uF*8+OT3UdA2tPeDDK0-K2tPhAG(I~tIU^S}K0g^UJ2X8%J{dbUHaI&uF*8bDT3Ud3"
    b"2tPeDDK0-K2{t<{KME*66)FfnIW;sqGd&qQHa0jrIWaR!URqj!e+WN4Gbt`VC<!(@EI$)IKQt~gE"
    b"+ZE+DK|SVIWieLHa0jrIWaRxURqj!dI&!~Gbt`VC=)a)FD@QCE;|`AJ2X8%J{dbUHaI&uF*8YCT3"
    b"Ud92tPeDDK0-K2{t<{KMFM{E*3L1F&Q#DG(A5)89O#MI6FBpGfrMwT7XU+KQ0O$6&xr#H$N6NDJc"
    b"mqJ1!|RPhMJDfJ_KKDL*a>9u*uYJ2yWTH7O|xE;}wMGfZAuT7Xa-C_g_JKQ}cfBQs52T3Ucr9X~D"
    b"!KPWRhHWV*6I6o*eLS9;0fL9$qE*?KDGdVvLJ2yWwLta{1fL0wpE)OX`C?7XFGd43oURqj!P8~lk"
    b"4Kp-8H7zL$C^bGWIW7@DBQrr>T3Uct9X~D}C^IZSC>Ap*E;B}6T3Ucl9X~D^H8(deG&4CnE;BVW2"
    b"`)P>DKkf2T3Ucj2tO%5E*Uj9H!n0ZIXf;hH8cq>J1!|RL|$52fItZ@J18y+KPWskC^tJaIX@RQG&"
    b"3$WC^IxYGeurnT7W|dE;T9&KPWskC^tJaIX@RQG&3$WC^IxYGkRWHT7XI&KQ0JAJ2oyeH$Mq3J1!"
    b"|RdtO>vfJF#DJu@jTKPU+`9~3n%GdwdnJ1#RdG#NWKHaI&uF*A5xT3Ucc2tPeDDK0-K2{j)dH$Ny"
    b"nKQuWb89O#MI6FBpGkIQGT7XswH6If`G#@lMH9kKxeqLHyfK~}L9}_+_9zQuXK0h;mURqj!RT~u_"
    b"9X~D>J1H(7C@3{3GkjiJT7XL%6(1QkKRYNEJ1H(7C@3{3GksoKT7XL%6(18cGcE}>J1jpGKQ0qKG"
    b"jd*9T7Xm=6(0ycJ3b94GcG?LA~SPdT3Uch8x<c3KQulZC_6njKQt~sJ~MD$T3Uch8x<c2KRGN2KR"
    b"YQYKQ}lwKQnP&T3Ucr8x<c4KR+=OG%PhSKNCJPc3xUqfI|sCE)7003O*G)JT^5uJ|7}3C_5b}H7_"
    b"bNcV1drfJYuPDLXheKMg)H3O*G)JT^5uJ|7}3C_5b}H7_bNbY5CofKCr8K07Wy4L&gqF*zS1DnB_"
    b"cKRz>cURqj!QyVxnC@u*(J2W$DURqj!R0uyQKQ0M5J2V?OH7G7KYhGGffJ_}fE*3i}E(;tO3O^_m"
    b"6B!9MJ1jpbGiY8~T7W?dFEcqY95XaN2tPhAG(I~tE($v{C>T2~IWjY8URqj!R2@Gq6hAI4H7GF?G"
    b"(0skZeChifJhxbE)+j5Ej1`HDGD_+G%i0VGjCp6T7XvxIXg57Hajdo6Er+EGi+X3T7XRnIXg57Ha"
    b"jdo88t67E(kw9FEl<oG%ho3URqj!RSPdOIWY+~J1jpLH7_(SGh$v^T7W_eFEcqY2{t<{KN&SIG%g"
    b"4~J})#rJ2WmcV_sTXfJ+@eE(kL;Jqb2DEI%1FFElPQU|w2UfJzH5GdVE{IXg5PHZ~L!87VViURqj"
    b"!R|r2lJ_$BEEI$)8JT)_BURqj!P8~lk2{}77G(SEGHajdo88t67E;DCdT3Ucf9X~D!IXg5oKRyXI"
    b"J1jpFG(0skWL{cYfKCZNE*Co~E<Y$985tuvHa`wCH$O9FURqj!ObI_O7dt5~KPVP8H7Xe+IW|8IG"
    b"dDjo8eUpjfL9$qE)Fv{Gc-LHH9kKx8(vykfJq5IE(s$vIT#}eHajdo6Er?QA~P6XT3Ucr9zQrQJq"
    b"b2DEI$%EDIOU!8D3gifJq5IE(tC>E<X)3E;0@?H$OEmE;AlpT3UcY2|q3gHajdo2`)P>KMgZ3G7d"
    b"90KQ%8dGap`BT7Xv_KQ0M2J1jp5E;}wiGaO!8T7XU+KQ0M2J1jpN76~ppE-xt=H9kKx9bQ^mfK4A"
    b"XJ2*B!6)!F-FD?lqG&vVLG&?;%C^HgXT3UcY9y2LBI5s~OFD@!CE(s$vITt%LJ3T)rGZS7~T7XC$"
    b"KQ0M2J1jpHDit&~BOEq6Ju?tqT3Ucg2|q3gHajdoA1Ej_C>uF3GZ9`|T7W?vKQ0M2J1jpQKP)pjK"
    b"OZ+QHajjeH8dPHJ3TWNURqj!NgY2f2{t<{KOZSK4l_4DH7_nHGZ$W3T7XFjKQ0M2J1jpRDK`!?H$"
    b"OEmE-5n<URqj!N*zBg2{t<{KNCJbG%hnPBQq6VT3Ucf3_mC{JR=D<J1jpFK0h=rGcF@D3SL@TfI<"
    b"vEC^I}G8#XoxHajdo6FxsQE;BAOKPfW{URqj!NDU}6E<Xu2J1jp4KRq)kE<Y$U2wqxRfJ+EJJ3a|"
    b"EJ1jp4KRq)kE<Y$U30_)SfJzN0GcG>~Hajdo9u^7}2o5t2URqj!RR}*jJ_$BEEI%F=3Ka+rGY?)`"
    b"T7XIjKRGolKPU+{J1jpAH5Cdo3|?AVfKC}TG(0msFDO3=BQ!Y|J2X2zKPWQ|URqj!R~a=lJTpBnC"
    b"_fw*7Y{Q6URqj!N(nzM2{t<{KNTu2Gc`0jHZucWT3Ucg9X~D!Hajdo6)G+>H8eXmGXP#%T7W?bKQ"
    b"0M2J1jp5FDfcEC@v`+C_6Vl2tO)6J1#Q;URqj!K^;FX2{t<{KM5}?Dm5rBDI6#}H$MnJDnC0eGX`"
    b"E-T7XIkKQ0M2J1jp9J1#jgJ~cfv2VPoQfJq5IE(ta}EI$f9GYvZ~IWj&qJu?JeT3Uci9X~D!Hajd"
    b"o4LdG5GCnmu88tLKGd(i}URqj!OdUTi2{t<{KMgxBIWj&qJqa#5E-xuFI$l~@fJq5IE*myB2{t<{"
    b"KMgxBIWj&qJu^FAT3Uci2|q3yHZ}=1J1jp6J~ItFE;%wjH9a#pURqj!OC3Kh7dt5~KPVGEKQt~gE"
    b"+aEJURqj!OC3Kh7dt5~KPVnEJ3SsdE;}<mURqj!NgF;s2`)P*E-xwyJ19FhKQ2EgGe2HhT7W_uK0"
    b"XO9J18zMDhfL&J2yWrKPVVGE;%wYJYHH_fJ_-SKRYN1E;}eLFDeQ<C_6VlE<Y$KGd*5fT7W_wKQ0"
    b"L_J18zMDhfL&J2yWrKPVYBFElPQGG1C*fJ_@IDmEhtE;}eLFDeQ<C_6VlE<Y$KGc#UVT7W|vDk?T"
    b"32`)P*E-xwyJ19FhKQ2EgDH}F6GcaCST7XFjKQ0L_J1##BGcGa-E;}eLFDf%JURqj!N(nzM2`)P>"
    b"KM6l8FF!OnKQlI7T3Ucq7BxFQ88tLKGd&O~H8e9fURqj!RU0oZH5oNDJTpBnC_f1oGc;aWT7X<1I"
    b"TJK9E;BV=T3UcqA2|~=GcFt`H8&hHHa{~eURqj!T^~6aHZ>_fGb>(NT7XL#GaGJdXax#8C@DV)E;"
    b"}wiGbmnKT7XR%GaGJdXayZVE*~^II5s~SH8(dqG(IyaURqj!R2efHZfa-+2|q3uH9kKxE?!z%fK("
    b"YX8*XZ71sy*w7d1XVGcR6RT7XX(GaGJdXaxvAJ3a|6J1#FN4K*k}Gb~<OT7XR%GaGJdXax-@GcG?"
    b"FH8d_LH8u@3C_XbSURqj!R~a)KZfa-+A2d5SHa{~WURqj!OBpj8Zfa-+96K*IE(kv<KQ1#PURqj!"
    b"K^Zd}Zfa-+9X~D(C_6MMGcGeVG#NEFH#;;wGaz1CT7W_sGaGJdXaxvAD=$AOE)FO=G$}JKGc`0bA"
    b"zoTqfKM4S8*XZ71sppsHZBN1DL*a=E<Y+WCSF=vfJYfK8*XZ71sy*w2`?%tH7G7WJ{~ADEI$`DK0"
    b"hflCtg}wfJ_-P8*XZ71rsS3H9kKHFDfcEC@w!fGbCPGT7W|tGaGJdXayZVE(<R+IWY+?H7XS<E;B"
    b"VWGbLVHT7W|tGaGJdXaxyBE(<R+IWY+?H7XS<E;BVWGumEST7W_sGaGJdXayZVE(tO(E<QCaG!-f"
    b"?Gc`0b+g@5)fI=BF8*XZ71qnYc2{JD(J~b^g6)G+>H8eBWURqj!dKohtZfa-+9X~D}GbuYbHa`_A"
    b"KPWpcGc`07DlRiMG&9*=T3Ud588aJhYG?%sKQ10KDLXheKNTuJC_64QH8d3}E;BVWGu~cWT7XU&G"
    b"aGJdXayZVE)qL7E)^;+Gc`0b-(Ff;fKC}R8*XZ71qnYc5<5076)G+>H8eBaURqj!M;S94Zfa-+9X"
    b"~D{J1;ga2tPYHE;BVW6)G+>H8eBbURqj!M;S94Zfa-+2|q3zJ1;ga2tPYHE;BVW6)G+>H8eBQURq"
    b"j!Nf|R6Zfa-+9X~D~C@3{388tpXGt*vLT7XO$GaGJdXayZVE*~f;H7F7@DK0fABQwxmT3UcY88aJ"
    b"hYG?%+Ha|NkA1Ej_C=xR%E;T44GtpjJT7XO$GaGJdXaxyBE)q32Gc-LHKQ1ygJ~P%{T3Uci88aJh"
    b"YG?%=KQ0nAH#0On7e6jCH9j-fURqj!dKohtZfa-+9X~D!FDfcEC@w!f5;Zq7G(8tTE;2PfDKpewT"
    b"3Ucd88aJhYG?%$DG4q+G(I~hJ`y!IGc-LHKQ1ygJ~P!`T3UcqA2&H89X~D-Gbt`LC?hk<URqj!N*"
    b"^~lBN;Y7J17z}DK0fABQwihT3UcsA2&H89X~D^H7_(SGss?AT7Xmv9u){bJ3bRMDlaY%Vl&BJT3U"
    b"cr3LX^*KRZ4XG%7DH6KiZU&R$wtfK>_}6$n2&J`*%5FD?&jY%|YZT3Ucr3LX^*KRZ4XG%7DH6KQB"
    b"O%wAerfK>_}6$n2&J`*%5FD?&hXfw@TT3Ucr3LX^*KRZ4XG%7DH9BF7X!d_ZhfJzD;6%8meE<Y77"
    b"E-EiB4`MUJURqj!O9~zp4Jb1%KNT-7DlaY*Yiu*XURqj!O9~zp4Jb1%KNT-7DlaY%Yiu*YURqj!O"
    b"9~zp4Jb1%KNT-7DlaY*X=pRXURqj!O9~zp4Jb1%KNT-7DlaY%X=pRYURqj!O9~zp4Jb1%KNT-7Dl"
    b"aY^X=pRVURqj!R}M8QH8wRpBN#6;Ha;`OURqj!Ne(qCH8wRpBOO0388S0AJ}5slGx}ayT7XIpH7Y"
    b"eWH9aF8KQ0J0H7+SL`(9dFfJhxbE(ta}EI%1FG(0ms8$LcLGx%OwT7XL(KQ0M2J1jpNHZwaZ8$Lc"
    b"LGx=UxT7XI&KQ0M2J1jp8KQulyC=)(2{$5&IfJq%cE(ta}EI$e;H9jvnE*UjGKQsScT3Ucg9X~D!"
    b"Hajdo2tO<{DKj-RGyGm!T7XU+KQ0M2J1jp5KPWRhHWV*6I6o*e{a#vHfJhxbE(ta}EI$=5E-EiB7"
    b"&9&@GxA<qT7XF%KQ0M2J1jpHFD@!CE*K*&KPfZwURqj!P8~lk2{t<{KNT-7DlaY-JUl5sE;I06T3"
    b"Uch9X~D!Hajdo6ErF>E*LW|DKqh2T3Uce9X~D!Hajdo6ErF>E*K*&KPfZzURqj!NgY2f2{t<{KNB"
    b"=6FD?~4JSjgeGxuIvT7XO)KQ0M2J1jpHFD@!CE(tC>C@vT?E;ICAT3Ucl9X~D!Hajdo6ErF>E(tC"
    b">C@vT?E;IFBT3Uck9X~D!Hajdo7dtaHI5i>)C^arMGwNPiT7W<uKQ0M2J1jpJJ2N&oH6jftGcG?C"
    b"KQuiqGBfL5T3UcW9X~D!Hajdo7dtaHI5i>-C^IfU6+ApCKQ1%qURqj!LmfXZ2{t<{KNmYQHaImR2"
    b"tPYM7C$sSE;2LeURqj!LmfXZ2{t<{KNmYQHaImR2tPYM6+ApCKQ1%wURqj!N*zBg2{t<{KNmP688"
    b"t67E;H|5T3Uct9X~D!Hajdo5<4j#88hr&T3Ucg9X~D!Hajdo9vK@sE;B4YGwohlT7XI&KQ0M2J1j"
    b"pQ85tuvHa}`J;$B)>fJz-dE(ta}EI%F@86!D1KWj7NURqj!RUJPr2{t<{KOPwgGBZ3bGvHoYT7Xm"
    b"?KQ0M2J1jpQ85BPvE;Hd?T3Uce9X~D!Hajdo9vKQKKP)pfFDWzTURqj!OdUTi2{t<{KOPwfKRG`$"
    b"EI$r2H$NLQ=U!S`fJ_}fE(ta}EI%F@2tPSLGb}$2GdDjNGvr=cT7XO)KQ0M2J1jpQ83;c)KQk;p4"
    b"l_4D88hWxT3Uci9X~D!Hajdo9vKKfIX^QjKMpfDKOQrhURqj!P8~lk2{t<{KOPwhJ19RiE($d$E;"
    b"E~6T3Uck9X~D!Hajdo3Nj-pGdVjp4kIc*GniglT7XU+KQ0M2J1jpAH7YeWH9aE^BPu^LnO<62fJ+"
    b"@eE(ta}EI%JKE+``kH7G7Ko?cp7fKMGiE(ta}EI%1FG$}7PKRyaIC@v{8pI%y8fK(knE(ta}EI$e"
    b"!KQ=ofGn`&pT7Xv_KQ0M2J1jpQE+Z;GGo4;qT7XI&KQ0M2J1jpKHZ?gh76=V9l3rR`fJz-dE(ta}"
    b"EI%JVDq<KTE<ZDqURqj!R2@Gq2{t<{KOa9T3LX<PkX~9^fK(knE(ta}EI$(|7Bwj@Gm&0eT7XF%K"
    b"Q0M2J1jpRI4>y~FDNKKG%hoiURqj!N*zBg2{t<{KM4~P6Er?QA~Tm>T3Uce9X~D!Hajdo88sgsKQ"
    b"22nHYqcdURqj!NF6^e2{t<{KO8k59zQNSGd3wRm0ns}fJhxbE(ta}EI%JLA09t0J2N&ZGm2hXT7X"
    b"C$KQ0M2J1jp5H6I>7E;}<eDKm>+T3Ucl9X~D!Hajdo92XZ4Y8)>#IW99bG&6`^T3Ucl9X~D!Hajd"
    b"o92XZ4YaA~$IW99bG&6}_T3Ucl9X~D!Hajdo92XZ4XdEvzIW99bG&7D~T3Ucl9X~D!Hajdo92XZ4"
    b"X&f&!IW99bG&7H0T3Ucs9X~D!Hajdo6gxLRGmKtZT7XC$KQ0M2J1jpQKP)pjKNLGRKQoP9T3Ucq9"
    b"X~D!Hajdo5<4j$DKj&IURqj!R2@Gq2{t<{KN34B7aj^TgI-!%fK>@UE(ta}EI%J9GaNHEKQn+{T3"
    b"Uce9X~D!HajdoA1N~oKPV|PH8eAUURqj!NF6^e2{t<{KMX%KJ~b#5J2yWwhF)4)fI%HUE(ta}EI$"
    b"Z8J})#rJ2W{X8#yjBEITegJ~M}2T3UcZ9X~D!Hajdo3Mex-J18R-Gc++6C^a!ZG&6)=T3UcX9X~D"
    b"!Hajdo2|qbCG(I~hBNj6>F&HQ{F+Vgjg<e`(fK4|zA_YA^E(IwrJ1!{&I3oo&J1H(dC^NcVT3UcZ"
    b"H#i~%C_gDbE(IwrJ1!{&I3oo&J1H(dC^NfWT3UcWH#i~%DK9uTGcE-?DI+vF1vn!GH#;dVKPWS}U"
    b"Rqj!NH;hl1uZ)>E(JIv1vfh>E<Y$Uxn5dYfKE3!A_X}+G&w&u1vn!GH#;dVKPWT4URqj!LN_=f1w"
    b"B751t>o$FE%a(I3oo&J1H(dC^NraT3Ucg9X~D!Hajdo2^SVWG(9ddGrV3}T7XLmC^a}g7ziE(8x|"
    b"=pJ1#FNGre9~T7XCjC^a}g90~{?1sfJAE;}wSDKoNOT3Uce3Me%=KO71O9t9p2DK0xMFDWy#URqj"
    b"!RSGCII6oW;2p$Cq7YIK+Gq7G-T7XO!9ts^lE*Uj6JTpBPH9jvkKNd47E;F%ST3UcY7aj^7KQ10W"
    b"E<ZUgKRy>VJ})*u7BeX>Gqzq@T7XFx9ts&UKRGcMH9jvkKNmYLIWjZ1URqj!N*5jq8!s+3A2csFK"
    b"PWpcKQpvmT3Ucn2@?|tKRZ4RH7GtawO(3UfK~|;6AdUcE<X)5C_Xc)URqj!O9>Mb2tPYM88tL6C^"
    b"a?+KRq+6URqj!Pze(g8#ya4GbleZs9suHfKUk&69_*xKRYQuGpSx$T7Xpv6B8UWG(H(SE<ZgrC?h"
    b"kjURqj!RS6Rl2tPYM89OdNJvAsJGp}A+T7XOm6B8daFE>9ZJ1##NJ1##xH7GMbDKo5IT3Uct2@?|"
    b"?KQ0L_C^IxYDKo8JT3Ucf2@?|?KQ0L_C^IxY7$XxjK0hKeqF!2BfJ+Gz6CFP;9X~WbC_6S2G(0sk"
    b"qh4BCfK3l7K07Wy3Me%yJ3TutGc`0GKQ=ofDKns6T3UcY9X~D!Hajdo3Me%yJ3TutGc`0GKQ=ofG"
    b"ofBuT7XO)KQ0$LA_^!qDmy(pE;BVW9zQlaBQvI6T3Uck8!s+389O#PFE%?aKOPwgGBZ3bGpAl!T7"
    b"Xm;H8eakJufIf9vK@pHZ!DNT3UcXA2d5SHa{6PG%hnVFEuYI7e6~GFDO4ZKQt~grCwTEfK4AXJ2*"
    b"B!9w;+BE*Uj9DnB$SJ1#RdG&5RXT3UcY9X~D!Hajdo2_rN)4Kp-8H7yA)J1#FNGh1I;T7XXpKQ0~"
    b"_2_rN)7Bwj@89O#MI6FBpGgx0*T7XOmKQ0L)G&v13G(I&g4l*b|DKa%SJ~LTgT3Uci9X~D!BQ!Y;"
    b"Gc-OmEe<j$KPfUbHa;_6Us_s#LkK@9KQ0M2J1jp5BQ!Y;Gc-OmEeS3=E-5o#Us_s#P8~lk7ds*eB"
    b"Q!Z4Gdw&$C_gkgKQmlkT3Ucr9X~D?J1H(dC>|LOGdDjoU0+&SfI%HUE(kw7KPW#mIX@XTH90W}Ha"
    b"jdo6Er?QA~RB7T3Uch6Db=uHVHO6EI%m|GzlX#IWtpVT3Ucl2|q3#Gdn#rH7PDLIVm4BJ2*B!J~L"
    b"2XT3Ucl9X~D}Gdn#rH7PDLIVm4BJ2*B!J~L5YT3UcZ4=O%8E<YYKJ3TZtDK0ZPDG4+?Dk(BGE;Ck"
    b"NT3Ucf2tPSBC_V}v6&WKrHa`h2J18zQS6^CMfKv!RIW;Ig4G|eLR9{+JfK(knE*~N)KRGTxJ`E8W"
    b"GgV(&T7Xv_KQ0O=GdDXZBMlK5GfH1tT7Xp@KQ0MBIW;ssJ18R!5g9W}Us_s#P8~lk4L&gnC^I)ZC"
    b"?gywJ2yWLA~Q%|T3Uck9X~D&J~0X?GdDXZBOE9@H$Mm>Gf7`sT7XO)KQ0YEF$q68H8eguC?gywJ2"
    b"yWLA~Q~3T3Uci9X~D&J~0VDIW;ssJ18R@C_6Vl2qH62Us_s#PaQul4L&gnJ~b0QA|5C;Dj78|G%h"
    b"ntUs_s#OC3Kh3OhM5KQ0zEDJcj$E<ZC(Us_s#N*zBg7CSCK94I?CKL|T6KQlsKT3Uch9y2>VG&Lz"
    b"d6f-#zKRY%qGBZP8T3Ucr3_mC{JR=k{ITAlRHZC$VKwnx~fK(eVE;R^0IW;UlC=@d}GeKWkT7Xp+"
    b"H90XKA}T*QE<ZjE5g9W^Us_s#OAj<QH90XKA}T*QE<ZjE5g9W_Us_s#Odm8nH7GehA0jG0IW9jw4"
    b"KX<uH90XeL|<B3fK&-TE*~N)KRGTxJ`E8WGeuuoT7XX-KQ10KJ3TZtDK0ZPDGD_+G%i0VGkRZIT7"
    b"XO)KQ10WE;}<eKRzBaJ3TZtDK0ZPDKmRtT3Ucg2tO%5E*>*GJv22bE;BhPGk9NGT7XF%KQ0M2J1j"
    b"pIGc+*^FFQ6fE+aE}Us_s#OC3Kh2`@J{J18RxH8V6WKPWSPUs_s#KnOoOJ_$BEEI$f0C@vo;C^aY"
    b"<H7_(SKPV|Pe_vW!fJX>FJ3bpWHVHO6EI$f0C@vo;C^aY<H7_(SKPV|Pd|z5xfJ_}fE(ta}EI$f0"
    b"C@vo;C^aYvE;}wMGksrLT7W?aKPf*h2{t<{KMFM{E*~f;H7FT1FElPcC@C{?Us_s#L=P%HJ1##SG"
    b"dn#rH7PDLIVlY@E;1hp86PMpH7F@Fb6;9ofK(knE*L03J2471Gc+zKGjLy8T7XO)KQ0M2J1jp6H7"
    b"G6?Gc+*?E;}wSDKl|jT3Uci9xpd42{t<{KM5`<FF7t1JUl5sE-5p1Us_s#Q5`=n4mBz@HZ?sXGk0"
    b"HFT7XF%KQ0M2J1jpNIW99SKMFM{E-5o~Us_s#R2@Gq2{t<{KMFf2KQt~gbzfRqfJhxbE(ta}EI$f"
    b"6C_gkV3N<J$GiqO2T7XX-KQ0M2J1jp6J19RiE(tC>E;BVWGizU3T7XU+KQ0M2J1jpQKQ22nHa|WS"
    b"G(0skXkS`dfI&GmKLtKBJ3R#|H8wT{G(Rl`J1jdhHaj>rKQn1xT3UceIW<28J~KN#1t>o|J_R>FE"
    b";}=BUs_s#PdPO|1wJ!7Jq0K~J3a+BKPf3YJwG#VUs_s#PB}F{1wJ!7Jq0^CF*G$THa|W+KQnA!T3"
    b"Uce90@fa6Erg}88tLCKRGTlH8eAAUs_s#NgN3^9~m|^DL)xCG&DasE;BVWGh$y_T7Xv^2{j)bKQ0"
    b"L_J1#FNGh<&`T7XI%2{j)GKPxXkDJ}^vJ1##nU|(8VfL0s{H6I;6E(tC>E<ZD2Us_s#Qyd939|%7"
    b"wKQ1$7Us_s#NgN3^9}OroE<Xu7JU<mLE-EiBGiP5~T7XL&2{j)GKRZ4NJ3K!VG%7DHGh|;{T7XO("
    b"2{j)cH7ztYH9I~EJ19FhKQ2EgDKlkXT3Ucl90@fa2|q3zJ2N&ZJ3K!XFD@!CE;AZmT3Uch90@fa8"
    b"8SaPF%3H|IWj&qJu@3$T3Ucg90@fa9X~D>J1H(7C@3{3GZ<f5T7Xm>2{j)XHa|NkA1Ej_C^H#fT3"
    b"Uce90@fa6DbKcJ1jpLJ1RRkHa{~SUs_s#OdJU{A00m~88tLCKRGTlH8dGDFElPQA75HpfJz(*H6I"
    b"EnH90>iDH$U<Ha{~QUs_s#PaFv~9~V9<6Erg}88tLCKRGTlH8e9FUs_s#OdJU{9~V9<88$U3KN&S"
    b"NG(R~mGc`0b5?@+cfJz(*H6Ir~Djh#A2`)P>FDWw<Us_s#NgN3^9~V9<2tO+?KPfH=E;}wiGZ0@|"
    b"T7Xp?2{j)VJ}MnQE(tC>E<ZC7Us_s#RvZa69~V9<2tO%5E;ANiT3Uci90@fa7d|QtC^IfU2|GML6"
    b")!F-FD^3|Us_s#P8<m}9~V9<2tPYM2|GML6ErF>E;AHgT3UcZ90@fa7d|Q;H7ztYH9I~EJ19FhKQ"
    b"2EgDKiycT3UcY90@fa7d|QpKQ0_QGd3wZJU<mLE-EiBGYVf?T7XU*2{j)VJ}Mb9KRGcCJ1#jgJ~c"
    b"fv3tw7VfJqz)H6Ir~Djh#A7CR{}A1Ej_C^HCOT3Uch90@fa7d|Q(Ha|NkA1Ej_C^HFPT3Uca90@f"
    b"a7d|Q-KQ0M2J1jpLH8eCoIW99bG#NE7G%hm^Us_s#LL3P-9~V9<9zQNWIW8GBG&DasE;BVWDKigW"
    b"T3Ucj90@fa7d|Q-KQ10WEHgPj8$LcLKPf3Q3}0GWfI}P!H6Ir~Djh#A7d1XFHa{6PH#Z79C_6VZ4"
    b"PRPXfI}P!H6Ir~Djh#A7d1XFHa{LSJ3TZtDKjZE0$*BMfJht(H6IK+HZwjuE<YJHG&B=FGXq~*T7"
    b"XDDIRz{`HZwjuE<Xi1H8eakJu?7bT3UceKRE>|KPWr}KO!nMC@uv#DJ(MqUs_s#QWqE<2`)P*E;9"
    b"yST3Ucz7Z@E0E;TAM2VYuRfL0e69TO=CFElhWG(9r}Us_s#Q5P5;9X~D!E;}wMGX-B-T7Xv<7##>"
    b"dDL*a=E;}wMGdf>dT7Xa&7#$ryE($d$E;Bn{T3Ucn7Z@E0E;}eL4mm0_IA2;?fKV409SJTqDh@d+"
    b"GdW*cT7Xp-7#$8dDibLPFElhWG(9suUs_s#R~Hx^9X~D(IVuV@C@wQUUs_s#P8S#*9X~D!KQ=!(E"
    b"<ZjOJ1H(dC^I}?T3Uck7Z@E0KQ0MBHa|HoKRy>bDK0-KGd*8gT7XCrH7*%7G&DasE*m~R9Vj&~Dl"
    b";-)T3Ucl5;ZOvH8eCoIW7o4H#ICj9Vj&~Dl;=*T3UcY5;ZOvH8eCoIW8SPE*&T}FDeNxJ1#FNGca"
    b"FTT7XFsH7*%7G&DasE*~^6H$NylE<ZCdUs_s#ND?(J88tLCKRGTLHa|Nk8#XpGHeXs=fK3uLE*Uj"
    b"6G(R~m9X~D|C^auC88t67E;Bb@T3Uca88aJhYG@ZVK0hf17d1XV4mAlcDk?Q7E<ZjPGcGeUUs_s#"
    b"dl@quZfa;3H9kKn1rsS3H9kKHFDfcEC@w!f6Eqh)DKRrOUs_s#MHw?2Zfa;3H9kKn1s@_RJ2XBCF"
    b"DfcEC@w!f7dt62Gb&$NT7XR%GaGJdXcsj;KPd$rKQ0$FK0g#YH$O8gUs_s#Lm4w0Zfa;3H9kKn1s"
    b"y*w7d1XV6gxLRA2c&4Us_s#L>V(1Zfa;3H9kKn1sy*w7d1XV9zQ8LC^IT9Gc`0bDPLMzfJPZJ8*X"
    b"Z77d1XVDFqWL86!D1GdT$(G&vVFK0h-qUs_s#Oc^s9Zfa;3H9kKn1qeSYFEc1VDIOU!FJD?(fOr`"
    b"*8*XZ77d1XVDFqWL2`)P{K07Er5;Zq7G(8tTE;2PfGb~?PT7X3vGaGJdXcsj;KPd$rKQ0nAH#0On"
    b"7e6jCH9izOH$O8iUs_s#Mj103Zfa;3H9kKn1sy*w5;Zq7G(8R|Gd(>&C^I5oT3Uca88aJhYG@ZVK"
    b"0hf19X~D-H8(RfJsvYCKRGTlH8e9LUs_s#e;G3yZfa;3H9kKn1r{?YE(tC>G(I~hJ`y!IGc-LHKQ"
    b"1ygJ}EOGUs_s#MjtsDH7_bQKPVGE1s*>xKRGTQKP)pjKMo@*KQkd;T3UclA2}H{FDf=aC=)&f6Db"
    b")rFDf=aC^IHsT3UciA2}H{FDf=aC=)&f6DbZqC^s`SJ2o>XUs_s#LmxRAH7_bQKPVGE1sy*w3_mn"
    b"JH7FE2H$O8ZUs_s#K_598H7_bQKPVGE1sy*w3_mnJH7FE2H$NXVGbLYIT7X9%IT<xCDmFhT6FvnU"
    b"KQ10WEHgPj4kIc*6gxLRGumHTT7W?xIT<xCDmFhT6FvnUKQ0+HFDf=aC>J$8KQ=SlUs_s#Kp#07H"
    b"7_bQKPVGE1sy*w3_mnJH7FT1FElPQ*k4*&fI}ZS88t5|Ha{p6J_Q{=E*~^5C?gp)FElPQ*<V^(fO"
    b"{V~9y2>V2`(rzG(9N=4mBz@HZ?sX9zQ8LC^IT9Gc`0b-d|c;fI=TR9y2>V2`(rzG(9N=4l_41G(8"
    b"tJK0h<xUs_s#MjtsIGdn#AE+{iJJt+kkC_g(fDm61SE)F9qKQr84T3UcaA2}W~J3R?5C^IxYDFqx"
    b"gC^tJU7$`qGF)B4PG%hpUUs_s#O&>QoBN;V5KLs5>E*?KAIVdwKE;BVWGtysLT7XL*H#s92H9kKD"
    b"9X~D^HajUPGt*yMT7XX<H#s92H9kKD9X~D^HajUP6gxLRGtggJT7X6$H#s92H9kKD95pC6J1!q6C"
    b"^aYuKRq)kE<Y$U(O+6xfJq-WIU^Z0K0gH$DF{C~H7q|UBQw@tT3UclA2}C0Gd4IiA_W~kE)F9qKN"
    b"LGRKQq@~T3UcjA2}C0Gd4IiA_W~kE)F9qKNLGRKOZzR)L&X!fJYxW7dtaHI5i>#9X~D~C@3{39zQ"
    b"8LC^IT9Gc`0b)n8g#fKMMe7dtaHI5i>#6h9&^88t67E<Y$U%3oSqfI}ZS2{j)D9X~D~C@3{39zQ8"
    b"LC^IT9Gc`0b%U@brfIuHP3O+R%H9kK%1s*#tI}Rf%KNvGE2{Rx+Gss_BT7XR-ISM{C88tpXIRzd&"
    b"E;|k*DnArEH$OAUUs_s#Paio7J~bINK0i4HA0jR&J2@^7Y;H5oUs_s#Paio7J~bINK0i4HA0jR&J"
    b"2@^BY;H5pUs_s#P9Hf6J~bINK0i4H6ErD5C@v3dZZphZT3UckA2|v>H5oNNKRE>xG$}tQE)#5SGt"
    b"FOGT7W_yISM{C88tpXIRzggE+{)WE(kw6Hfd-x!e3fifI=TR3O+R%H9kK%1s@_VC_6bW2tPYEY;H"
    b"5dUs_s#O&>W5J~bINK0i4H6ErD5C@u&;J2q)(Gr(V3T7XR-ISM{C88tpXIRz6mDL*JK2tPYEY;H5"
    b"bUs_s#K_58^J~bINK0i4H88t67E*m*6Gb}#}H7G7AGsa(9T7XO+ISM{C88tpXIRza*E)F#+H8wRp"
    b"BQwWeT3UcWA2|v>H5oNNKRE>*KQ0b6Dm6AWJtGu5H$OAPUs_s#Mjtr}J~bINK0i4H9X~D(H7YeWH"
    b"9aE~J2yWcG&99tT3UcjA2|v>H5oNNKRE>xDGD_xE*m*6Gb}$d`d?aFfK3S=6&pA;C@uvZKQ10WDL"
    b"E)JDlRiMG&B2OT3Uck2_6+2I5j9P1sy*w89OdNJvAsJGx%RxT7XUo9u*rnH7G6x6DbHkE+`{AI5s"
    b"~s`CnREfJzA-6&pA;C@uvZKQ0n8G%hp#Us_s#Paio6GcyGpKQ0+NE<ZgrC?ga*H$OA~Us_s#N*_5"
    b"1GcyGlH9sFTJ2*B!J~RAZT3UcgA2|s#GX)tnKM6iH6Er+EGyPv$T7XC&ISDf}1sOFz3O+R(DJe5O"
    b"G&AyFT3UceA2|s#GX)tnKMFoI88tLKGd(l&Us_s#LLWH^GcyGlH9rq3HZ?mw8!ibhJ18zMDl_n3T"
    b"3UcjA2|s#GX)tnKN&SQDmFhZKN~qYKPf3Q@n2e6fJz@Z2{SVV95p{5G&?vpKRz?|Us_s#N*_51Gc"
    b"yGrH9sFTJ2*B!J~Q`UT3UceA2|s#GX)$oG(H(SE<ZgrC?hlUUs_s#LmxQ_GcyGrG%q(lC_64c89O"
    b"dNJvAsZKPfZyUs_s#NFO-~GcyGWJ18kX9X~WbC_6SY>R(z~fKDGd2{SVV9X~D!E+{iJJsCAGG%hp"
    b"iUs_s#OdmN3GcyGpKQ0L_C^IxY7$XxjK0hKe=wDh|fI=TR2{SVV9X~D^H8eakJufIfJ{vYOJ1H~i"
    b"Us_s#OCLE2GcyGpKQ0VEG(I&b6FxKUUs_s#P9Hf5GcyGpKQ0O=H9jvnE*UjGKQr%NT3UchA2|s#G"
    b"X)(#E(kv?GbuAQG&Ag9T3UclA2|s#GX)(#E(t#<GdngEFE=<pC^PL}T3UcZA2|swJ1##36DbTkHZ"
    b"wjBC_6MMGcGeVG&AB~T3UcZA2|swJ1##39X~D(C_6MMGcGeVG!7#wKQrTBT3UcZA2|swJ1##39X~"
    b"D(C_6MMGcGeVGzvQ|GBe;`T3UcXA2|swJ1##36Db%qH7+SGC_5?$KPxXYC_g?k;a^%>fK?wk2`)P"
    b">KLs5>E)+XAKQrcET3UchA2|swJ1##39X~D<J2yWcG&AR4T3UcfA2|swJ1##35<4j$C@3{38#ysE"
    b"<X>7^fKMMe2`)P>KLrUcC^IS_C@3{38#ysE<zHG_fJPe@1qm)YE-xt=H9kKD9X~D}KPfpVGb%1KH"
    b"8eAtUs_s#LmL(a2`)P>FDV%{K0gH=KQ0MBEI%kSE+aFWUs_s#M;jIe2`)P>FDV%{K0gH=KQ0JAIW"
    b";UlC?gUxG%hokUs_s#L>m?b2`)P>FDV%{K0gH$DGWa}J~b!_DnB_hJTo~nnO|C3fL$CF9|%7?J~N"
    b"(QT3Uco92Fl8C^IfUGoN2tT7XC#6(0#dE($0$Jt#jZDH1g`F*BTBT3Uck92FlKHa|Nk3Me%_C_gD"
    b"F5;Zk3Go4>rT7Xj=6(0ycJ3b#GGm>9gT7Xa-6(0>KGcG?LA~Ta;T3Ucq92Fl4KQ0(ADI*d!H8C@g"
    b"Us_s#N*om*2tO+?KPfI5J2W{zHZzf5T3Ucq92FlKHa|Nk89OvNKQ=R#Us_s#QXdr`2|q3q3Nx2qT"
    b"3Uco9~B=RKQ0prGn8LiT7Xj@6(0#dE*BdaGnHRjT7Xj@6(1cxE*BdaGm2kYT7Xj@6(0#dE*=yKGm"
    b"BqZT7Xp_6(1cxE*vj5HVQi^J2x|kUs_s#RUZ`}2|q3zFE%y`J19FhGl^eXT7Xj@6(1cxE*=yKGmc"
    b"+cT7XF(6(0#dE*m~RC_gDF95Xg9KPWSgUs_s#Ngov-9X~D`K0YWvDJdK?HZDIXGmKwaT7Xs`6(0#"
    b"dG(H?CJ2yWwjbB<?fK?wA9|%7=KQk;p94I?CKQn?~T3Ucq9~B=7KQulZC_6VlA0jh@Us_s#O&=8>"
    b"2|q3yK0YWvDJdK?HZDIX94|IDGk{-OT7XL*6(0#dE(kw4KQk;p5;Zk3Gl5@PT7XF(6(1QkKRYN0K"
    b"RG`$EI$%8H8C@WUs_s#T?sWG2tPYMGlySVT7XgsH6INqGcG?fgkM@(fJ+HA9|%7?J{vABC^I-OE<"
    b"Y(Vg<o1)fKdrG9|%7?J`_7QKQp>tT3Ucn2{j)GKRZ4TG&3$UyI)#bfK&-J9|%7?J`)}k7BeX>Gq_"
    b"(`T7XvxH6I8+J3bdPG#5J}Gr3<{T7Xm=6(0#dG(H(MH#a*pJ~O^wT3Ucs8x<c2KRZ4RC^IfUGrwP"
    b"2T7XL%6(0ycJ3byiEHgPj6Er+EGrV6~T7Xs?6(0ycJ3a|6J1##ny<b{dfK?k69}OroE<YJHG%hGL"
    b"HZ!tcT3Uce8x<cLK0XvRE;BqcIXf;hH8eA`Us_s#NE;O&9zQk|H7+weGdVjhGc`0buwPnQfL0q79"
    b"|=D$88tLKGd(l0Us_s#RvQ%`9X~D^H8eakJu|jnT3Ucq3>6;}DG4tsDm5rBKRz?JUs_s#T?`c;2|"
    b"qMGGqhh?T7Xat6(0ycIX^QjKQpyoT3Ucm3>6;<KQulFJ1sM+Us_s#R}2*&2tPSLGb}#{J1sM-Us_"
    b"s#NemSq9X~D>J1H(7C@3{388tpXGpJu$T7X6j6(0#MJ18y`H7+weGdVjhGc`08Gbt`VG(RXasb5-"
    b"JfI$ou9|<lsDik#?GdwdnJ1#RdG!`={E<ZFsC^N2KT3UcW3>6;}DHJs>GdwdnJ1#RdG!`={E<ZFg"
    b"G(9t~Us_s#O$-$u2tPeDDK0-K6g4h0JTo~vE;BVWGpt`)T7W|g6(0{YC_g<jDK0-K6g4h0JTo~vE"
    b";BVWGp%1*T7X6y6(0#MJ18y`H7+weGdVjhGc`08Gbt`VG(RXaqF-8CfI%A-9|<lsDik#?GdwdnJ1"
    b"#RdG!`={E<ZFsC^Ms9T3UcW8x<cDDHJs>GdwdnJ1#RdG!`={E<ZFgG(9t*Us_s#O&b*-2tPeDDK0"
    b"-K6g4h0JTo~vE;BVWGofEvT7W|v6(0{YC_g<jDK0-K6g4h0JTo~vE;BVWGp1i!T7XO)KQ0MBIW;s"
    b"sJ18R-Gc+*?E;}wSDKn>ET3UcgA2d5SHa`eIJ})#rJ2W{XGo)WyT7XF%KQ0JAJ})#rJ2W{X2`)P>"
    b"FDWynUs_s#O&m2SIX?(LJ})#rJ2W{X96K{MH7q|UGg@3)T7XX(GCw&n2tPhAG(I~tIU^E3J2oydG"
    b"h19*T7XLlKQ0JAJ_;x`IX@{WK07WuGgw?&T7XL(KQ0JAJ_;x`IX@{WK07WuGg(|(T7XF(G&?vpKM"
    b"FHFJtH_fIWZnHJ3TXATv}RyOcN;zGd(>cI6FBp9y2>VA2d5SHa|WyUtC&RfKeSkE(kL;Jr^}TKQm"
    b"lhT3Ucm2|q3mJ}MVAK0h;ETv}RyP#r%m4?ZdvH9kKxQe0YEfK(GH4?ZdzEITtcJ2*B!GgDkzT7XU"
    b";G$}7AKOQJEEI%kI2ro1=Gc-LjP+VGCfKU@OGcGebHZveUGf`YxT7W_mG&3$UJ2o>QKM5*7IWs&n"
    b"ITt%AE<Y$UR$N+IfL$IlDJnH7KQmWcT3Ucm2|q3rKQ1jbC^0isTv}RyQVBmU2`)P>KQmQaT3Uct9"
    b"X~D>Gc+*?E;}wSDKko3T3Ucq9X~D?J1H(dC<!h*E<ZC%Tv}RyRT(uZBNsa<E<Y#<E;}wiGe}%oT7"
    b"XF%KQ0$LDK0-K2`)P>KN&kYGCwm(Tv}RyQXM}o2{t<{KQm5TT3Uc#9X~D;6*Es<T3Ucp7Bx9B6BR"
    b"c*Dl<%6T3Ucn4>UG4IWZFzH#;gbO<Y=9fJhxbE*CE@KOzb!H7-9nE;BVWGeTTiT7XIoC^IfU2{t<"
    b"{KNT-7DlaZGLtI)~fKCl4GcG>~Hajdo6)!F-FD@7(E<ZCsTv}RyP8~lk2{t<{KM5Wc7BeX>7&|F5"
    b"IWs|AT3Ucr9X~D!Hajdo2_6*|Gbt`JMqFB2fKDAhE*CF0E;9)>J1jp59u*cdDK0ZdTv}RyPaG&eK"
    b"Nl}HE;9)>J1jp59u*cdDK0ZaTv}RyNgY2f2{t<{KMFN7G%i0V1qmJ%GeullT7X0yKQ0M2J1jp6H8"
    b"V6WKPUwW9u)-*GcGa}9u_kxE;D*uT3UcZ9X~D!Hajdo3N<q{E<Y#*2_6*%3_CV2KQnt=T3Uca9X~"
    b"D!Hajdo3N<q{E<Y#*2_6*%6Er?QA`Ck=FF!MQTv}RyQVAXvEhsZCKQnn;T3Ucz2_6+FKRZ4%eq35"
    b"wfKUk@6(~PDJ_SD_Gk;uKT7Xdr9u+MpGcG>`KO!@HTv}RyRXH_31wB751vNeeHZv(MGksiIT7XG8"
    b"H9rMCKQ09|I50msE(Jb6DLFH8Tv}RyNI5k>1wB751wS+{C?f?vKPfpgb6i?lfK@p)KLtD}KR*REJ"
    b"~lHcE;DdkT3UcrIW<28JSaau1vNi5Gbt`Jaa>wjfKDGNHxnrqKRr7(4k$Y`DKjoJH8eAJTv}RyOd"
    b"lyX9X~D>KRr7(4k$Y`DKjoJH8d$RcU)RpfJ`4LHyuAN9zQ%gFE%a?GdDjqFD@4;Gjv>9T7XO+DK`"
    b"@-5i~U|G#fSvE;}wSDH%0BKQnb)T3UcjA1OB(HajUPGdv?3HVG~}E-xt=H9kKxYFt`cfJ+}KHyuA"
    b"N7dt5~KPVYCJ1HqMYg}4dfKC}QKRGcNFFZUyC=)a;KRqZjE+aE&Tv}RyNF6^e89O;LKMFN9HVG~}"
    b"E-xuFX<S-bfJz-dE*U#HGCvA6H8vMDK0h;VTv}RyN)ss=J2^5x3N<x02tPYMBQtMYT3Ucq95yd0G"
    b"8sELGCvA6H8wMBTv}RyOC3Kh89O;LKMFN9HXkS`H7GM}Tv}RyUkNTdC@wQ%Tv}RyUI{KWDl=nTT3"
    b"Ucl9X~D?J0cf5DK0-K6ErC<J2W{zDKlVPT3UcW8!9R`BM3h`HZC(aKNTu2GdD9JJ1#RdG$}J-Tv}"
    b"RyOC3Kh9yT@%KPV|PH8c}6JT)_BTv}RyNC`hK7cVY9A_^!qE<ZUgGc`0bXIxrZY5"
)
_ORDINAL_MAP = _od()
_SAFE_MDP_ORDINALS = {
    "SafeMdpInitConnection": 1351,
    "SafeMdpCloseConnection": 1352,
    "SafeMdpGetStatus": 1353,
    "SafeMdpRequestState": 1354,
    "SafeMdpGetState": 1355,
    "SafeMdpReset": 1356,
    "SafeMdpWriteSafeOutput": 1357,
    "SafeMdpReadSafeInput": 1358,
    "SafeMdpDownloadParameters": 1359,
    "SafeMdpSetFailsafeOutput": 1360,
    "SafeMdpCheckWatchdog": 1361,
    "SafeMdpGetLastError": 1362,
    "SafeMdpClearError": 1363,
    "SafeMdpGetSlaveConnectionCount": 1364,
    "SafeMdpDetectConnections": 1365,
    "SafeMdpGetDeviceAddress": 1366,
    "SafeMdpGetModuleCommParam": 1367,
    "SafeMdpGetModuleDiagnosis": 1368,
}

# 内核驱动可用性探测 (kernel_probe.h / KernelGuard) — 新增 ordinals.
# 已同步加进 ord_obfuscate.py 的 _SOURCE_MAP, 但 _ORDINAL_MAP_ENC 是 build-time
# 生成的不透明 blob, 不重新打 wheel 就不会含新条目;
# 这里再用运行时覆盖字典补齐, 让 _resolve_export 直接拿到 1629-1631.
_KERNEL_PROBE_ORDINALS = {
    "DarraEcat_KernelProbe": 1629,
    "DarraEcat_KernelStatusMessage": 1630,
    "DarraEcat_KernelInstallerUrl": 1631,
}

# [2026-05-09] CoE-H2 SDO Information Services 直读 OD (D_1575..D_1579).
# 同步于 C# DLL.CoE.cs:107-128. 添加为运行时覆盖, 不依赖 _ORDINAL_MAP_ENC blob 重打.
_COE_OD_ORDINALS = {
    "coe_get_od_list": 1575,
    "coe_get_object_desc": 1576,
    "coe_get_entry_desc": 1577,
    "coe_free_odlist": 1578,
    "coe_free_oelist": 1579,
}


def _resolve_export(real_dll, name):
    """根据语义名解析真实导出符号 (优先 D_<ordinal>, 兜底原名).

    返回 ctypes 函数对象, 或抛 AttributeError (调用方处理 missing).
    """
    ordinal = (_KERNEL_PROBE_ORDINALS.get(name)
               or _COE_OD_ORDINALS.get(name)
               or _SAFE_MDP_ORDINALS.get(name)
               or _ORDINAL_MAP.get(name))
    if ordinal is not None:
        try:
            return getattr(real_dll, "D_%d" % ordinal)
        except AttributeError:
            # ordinal 形式未导出, 兜底尝试原名 (用于过渡期/旧 DLL)
            pass
    return getattr(real_dll, name)


# ===================== DLL 加载与函数签名 =====================

class DarraCoreDLL:
    """
    Darra.Core.dll 原生函数封装
    负责加载 DLL 并定义所有 C 函数的 argtypes/restype
    """

    DLL_NAME = "Darra.Core.dll"

    def __init__(self, dll_path: Optional[str] = None):
        """
        加载 Darra.Core.dll

        参数:
            dll_path: DLL 文件路径。若为 None，按以下顺序搜索:
                      1. 当前工作目录
                      2. 本模块所在目录
                      3. 系统 PATH
        """
        self._dll = self._load_dll(dll_path)
        self._setup_functions()

    def _load_dll(self, dll_path: Optional[str]) -> ctypes.CDLL:
        """搜索并加载 DLL.

        Windows 上 Python 不再使用 PATH 解析 DLL 依赖, 必须用 os.add_dll_directory.
        额外搜索: DLL_PATH 环境变量 / PATH 中的目录 / 包同目录.

        策略: 收集多个候选 DLL, 按"修改时间最新"排序优先尝试 (确保最新构建优先).
        每个候选若加载失败, 记录原因并尝试下一个.
        """
        # 1) 收集候选 DLL 文件路径 (绝对路径, 去重)
        candidates = []
        seen = set()

        def _add_candidate(path):
            if not path:
                return
            ap = os.path.abspath(path)
            if ap in seen:
                return
            if os.path.isfile(ap):
                seen.add(ap)
                candidates.append(ap)

        # 显式参数最优先
        if dll_path:
            _add_candidate(dll_path)

        # 环境变量
        env_dir = os.environ.get('DLL_PATH')
        if env_dir and os.path.isdir(env_dir):
            _add_candidate(os.path.join(env_dir, self.DLL_NAME))

        # 当前目录 / 包同目录
        for d in (os.getcwd(), os.path.dirname(os.path.abspath(__file__))):
            _add_candidate(os.path.join(d, self.DLL_NAME))

        # PATH 中含 Darra.Core.dll 的目录
        for p in os.environ.get('PATH', '').split(os.pathsep):
            p = p.strip().strip('"')
            if p and os.path.isdir(p):
                _add_candidate(os.path.join(p, self.DLL_NAME))

        # 2) 收集所有 dll 搜索目录 (用于解析依赖)
        dep_dirs = set()
        for c in candidates:
            dep_dirs.add(os.path.dirname(c))
        # PATH 中含 VMProtectSDK64.dll 的目录也注册 (依赖)
        for p in os.environ.get('PATH', '').split(os.pathsep):
            p = p.strip().strip('"')
            if p and os.path.isdir(p) and os.path.isfile(os.path.join(p, 'VMProtectSDK64.dll')):
                dep_dirs.add(os.path.abspath(p))

        if hasattr(os, 'add_dll_directory'):
            for d in dep_dirs:
                try:
                    os.add_dll_directory(d)
                except (FileNotFoundError, OSError):
                    pass

        # 3) 按修改时间倒序排, 最新的 DLL 优先 (避免被旧版命中)
        try:
            candidates.sort(key=lambda c: os.path.getmtime(c), reverse=True)
        except OSError:
            pass

        # 4) 依次尝试加载, 失败则跳到下一个
        last_err = None
        for c in candidates:
            try:
                return ctypes.CDLL(c)
            except (OSError, FileNotFoundError) as e:
                last_err = (c, str(e))
                continue

        # 5) 最后兜底用系统路径名
        try:
            return ctypes.CDLL(self.DLL_NAME)
        except OSError as e:
            tried = '\n  '.join(f'{c}: {err}' for c, err in [(last_err[0], last_err[1])] if last_err)
            raise OSError(
                f"无法加载 {self.DLL_NAME}. 已尝试 {len(candidates)} 个候选.\n"
                f"最后错误: {tried or e}"
            )

    def _setup_functions(self):
        """声明所有 DLL 导出函数的参数类型和返回类型

        注: 由于 DLL 版本可能不同步, 若某些符号未导出, 不阻塞 import,
        改为生成一个调用时抛出 NotImplementedError 的占位 stub.
        """
        # 缺失符号集合 (供调用方诊断 / 跳过相应功能)
        self.missing_symbols = set()
        _real_dll = self._dll
        _missing_set = self.missing_symbols

        class _TolerantDllProxy:
            """对底层 DLL 进行容忍访问的代理: 缺失符号返回一个可被 _sig 设置签名的占位.

            语义名 -> ordinal D_NNNN 的转发由 _resolve_export 完成,
            缺失符号 (DLL 未导出) 返回 stub, 调用时报 NotImplementedError.
            """
            def __getattr__(self, name):
                try:
                    return _resolve_export(_real_dll, name)
                except AttributeError:
                    _missing_set.add(name)
                    # 返回一个具备 .restype/.argtypes 字段的 stub, 供 _sig 设置而不报错;
                    # 真正调用时抛 NotImplementedError.
                    class _Stub:
                        __name__ = name
                        restype = None
                        argtypes = None
                        def __call__(self, *_a, **_kw):
                            raise NotImplementedError(
                                f"DLL symbol '{name}' not exported by current Darra.Core.dll"
                            )
                    return _Stub()

        dll = _TolerantDllProxy()

        # ---- 内存管理 ----
        self._sig(dll.FreeMemory, None, [c_void_p])

        # ---- 版本信息 ----
        self._sig(dll.GetDllVersionInfo, c_void_p, [])

        # ---- 结构体对齐诊断 ----
        self._sig(dll.DumpSlaveStructOffsets, None, [])

        # ---- 初始化/销毁 ----
        self._sig(dll.Initialize, c_ushort, [])
        self._sig(dll.InitializeSpecificMaster, c_ushort, [c_ushort])
        self._sig(dll.Dispose, None, [c_ushort])

        # ---- CPU 亲和性 ----
        self._sig(dll.GetAvailableCpuCores, c_int, [])
        self._sig(dll.GetMaxMasterInstances, c_int, [])
        self._sig(dll.SetMasterCpuAffinity, c_bool, [c_ushort, c_int])
        self._sig(dll.SetProcessCpuAffinity, c_bool, [c_int])

        # ---- 周期与同步 ----
        self._sig(dll.SetMasterLoopCycleTime, None, [c_ushort, c_uint])
        self._sig(dll.SetSyncBySlaveIndex, None, [c_ushort, c_ushort, c_uint, c_uint, c_int])

        # ---- DC (ETG.1500 5.13) ----
        self._sig(dll.UpdatePropagationDelays, c_int, [c_ushort])
        self._sig(dll.AutoCalculateDCShift, c_int, [c_ushort])
        self._sig(dll.ConfigureDCAll, c_int, [c_ushort, c_uint, c_uint])
        self._sig(dll.GetSlavePropagationDelay, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetMaxPropagationDelay, c_int, [c_ushort])
        self._sig(dll.EnableContinuousMeasurement, None, [c_ushort, c_bool, c_uint])
        self._sig(dll.EnableDriftCompensation, None, [c_ushort, c_bool, c_int, c_int])

        # ---- DC 同步窗口 (ETG.1500 5.13.3) ----
        self._sig(dll.GetSlaveSyncWindowStatus, c_bool,
                  [c_ushort, c_ushort, POINTER(c_int), POINTER(c_int),
                   POINTER(c_int), POINTER(c_int), POINTER(c_uint)])  # BOOL* 用 c_int(4字节), 不能用 c_bool(1字节)
        self._sig(dll.SetSyncWindowThreshold, None, [c_ushort, c_int])
        self._sig(dll.GetSyncWindowThreshold, c_int, [c_ushort])
        self._sig(dll.ResetSlaveSyncWindowStats, None, [c_ushort, c_ushort])
        self._sig(dll.GetMaxSyncDifference, c_int, [c_ushort])
        self._sig(dll.IsAllSlavesInSync, c_bool, [c_ushort])
        self._sig(dll.SetDCSyncLostCallback, None, [DCSyncLostCallbackType])

        # ---- 通信统计 ----
        self._sig(dll.GetCommunicationStats, c_void_p, [c_ushort])
        self._sig(dll.ResetCommunicationStats, None, [c_ushort])
        self._sig(dll.GetSlaveDetailedInfo, c_void_p, [c_ushort, c_ushort])

        # ---- 日志 ----
        self._sig(dll.SetPDOLogging, None, [c_bool])
        self._sig(dll.SetMailboxLogging, None, [c_bool])
        self._sig(dll.SetDebugLogging, None, [c_bool])
        self._sig(dll.SetLogCallback, None, [LogCallbackType])
        self._sig(dll.SetCrashCallback, None, [CrashNotifyCallbackType])
        self._sig(dll.CloseDebugLog, None, [])

        # ---- 设备信息与授权 ----
        self._sig(dll.GetSerialNumber, c_void_p, [])
        self._sig(dll.GetDeviceName, c_void_p, [])
        self._sig(dll.GetUserEmail, c_void_p, [])
        self._sig(dll.GetWindowsProductKey, c_void_p, [])
        self._sig(dll.GetDriverList, c_void_p, [])
        self._sig(dll.CheckBufferIntegrity, c_int, [])
        self._sig(dll.FlushCachePool, None, [])
        self._sig(dll.IsCachePoolReady, c_bool, [])
        # 激活授权 — 内核 WSK 走驱动多 NIC 群发 (3s 超时), SDK 不走 HTTP
        # int LicenseActivate(const char* code, char* err_buf, int err_buf_len)
        self._sig(dll.LicenseActivate, c_int, [c_char_p, c_char_p, c_int])

        # ---- 内核驱动可用性探测 (kernel_probe.h / KernelGuard) ----
        # int  DarraEcat_KernelProbe(void)        -> DarraKernelStatus 枚举值
        # const char* DarraEcat_KernelStatusMessage(int status)  -> UTF-8 中文消息
        # const char* DarraEcat_KernelInstallerUrl(void)         -> 下载 URL
        # 旧 DLL 没导出, _sig 容忍缺失 (调用时返回 UnknownError / 默认 URL).
        self._sig(dll.DarraEcat_KernelProbe, c_int, [])
        self._sig(dll.DarraEcat_KernelStatusMessage, c_char_p, [c_int])
        self._sig(dll.DarraEcat_KernelInstallerUrl, c_char_p, [])

        # ---- 网络扫描 ----
        self._sig(dll.GetNetworkInfo, c_int, [c_bool, c_bool])
        self._sig(dll.GetNetworksPointer, c_void_p, [])
        self._sig(dll.QuickSlaveCount, c_int, [c_char_p])
        self._sig(dll.QuickSlaveCountRedundant, c_int, [c_char_p, c_char_p])
        self._sig(dll.ScanSlaveCount, c_int, [c_char_p])
        self._sig(dll.ScanSlaveCountRedundant, c_int, [c_char_p, c_char_p])
        self._sig(dll.GetRingSlaveCount, c_int, [])
        self._sig(dll.AbortScan, None, [])
        self._sig(dll.ResetScanAbort, None, [])
        self._sig(dll.AbortNetwork, None, [])
        self._sig(dll.ResetAbortNetwork, None, [])
        self._sig(dll.EmergencyCloseNics, None, [])

        # ---- 冗余模式 ----
        self._sig(dll.SetRedProcessdata, None, [c_int])
        self._sig(dll.GetRedProcessdata, c_int, [])

        # ---- 网络连接 ----
        self._sig(dll.SetNetwork, c_ushort, [c_ushort, c_char_p, c_char_p])

        # ---- 状态管理 ----
        self._sig(dll.GetMasterState, c_void_p, [c_ushort])
        self._sig(dll.GetMasterStateCache, c_void_p, [c_ushort])
        self._sig(dll.SetStateCacheUpdateInterval, None, [c_ushort, c_uint])
        self._sig(dll.GetStateCacheUpdateInterval, c_uint, [c_ushort])
        self._sig(dll.GetSlave, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.GetLinkStatus, c_int, [c_ushort])
        self._sig(dll.SetState, c_bool, [c_ushort, c_ubyte])
        self._sig(dll.SetStateWithTimeout, c_bool, [c_ushort, c_ubyte, c_uint])
        self._sig(dll.SetSlaveStateWithTimeout, c_bool, [c_ushort, c_ushort, c_ubyte, c_uint])
        self._sig(dll.SetStateWithStartup, c_bool, [c_ushort, c_ubyte, c_uint])
        self._sig(dll.SetStateSequence, c_bool, [c_ushort, c_ubyte, c_uint])

        # ---- IO ----
        self._sig(dll.GetIO, c_ubyte, [c_ushort, c_ushort,
                  POINTER(c_int), POINTER(c_void_p), POINTER(c_int), POINTER(c_void_p)])
        self._sig(dll.LockIOmap, None, [c_ushort])
        self._sig(dll.UnlockIOmap, None, [c_ushort])

        # ---- 启停 ----
        self._sig(dll.Start, None, [c_ushort])
        self._sig(dll.Stop, None, [c_ushort])

        # ---- SDO ----
        self._sig(dll.GetSlaveSDOList, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveSDOListBasic, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.GetSlavePointer_SDO_Value, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_ubyte, POINTER(c_int)])
        self._sig(dll.GetSlavePointer_SDO_IndexValue, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_ubyte, POINTER(c_int)])

        # ---- SDO 辅助 ----
        self._sig(dll.GetSlavePointer_SDO, c_void_p, [c_ushort, c_ushort, c_ushort])
        self._sig(dll.GetSlavePointer_SDO_WithODList, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_void_p])

        # ---- SDO 批量读取 ----
        self._sig(dll.GetMultiSlaveSDOList, c_int,
                  [c_ushort, POINTER(c_ushort), c_int, POINTER(c_void_p)])
        self._sig(dll.FreeMultiSlaveSDOList, None, [POINTER(c_void_p), c_int])

        # SDOwrite 使用 IntPtr 版本
        try:
            self._sig(dll.SDOwrite, c_bool,
                      [c_ushort, c_ushort, c_ushort, c_ubyte, c_bool, c_void_p, c_int])
        except AttributeError:
            pass

        self._sig(dll.SDOread, c_void_p,
                  [c_ushort, c_ushort, c_ushort, c_ubyte, c_bool, POINTER(c_int)])

        # ---- [2026-05-09] CoE-H2 SDO Information Services (D_1575..D_1579) ----
        try:
            self._sig(dll.coe_get_od_list, c_void_p, [c_ushort, c_ushort])
            self._sig(dll.coe_get_object_desc, c_void_p, [c_ushort, c_ushort, c_ushort])
            self._sig(dll.coe_get_entry_desc, c_void_p,
                      [c_ushort, c_ushort, c_ushort, c_ubyte])
            self._sig(dll.coe_free_odlist, None, [c_void_p])
            self._sig(dll.coe_free_oelist, None, [c_void_p])
        except AttributeError:
            pass

        # ---- 回调注册 ----
        self._sig(dll.RegisterProcessDataCyclicCallbackSync, None, [ProcessDataCyclicCallbackType])
        self._sig(dll.RegisterProcessDataCyclicCallbackAsync, None, [ProcessDataCyclicCallbackType])
        self._sig(dll.RegisterSlaveStateChangeCallbackSync, None, [SlaveStateChangeCallbackType])
        self._sig(dll.RegisterSlaveStateChangeCallbackAsync, None, [SlaveStateChangeCallbackType])
        self._sig(dll.RegisterEmergencyEventCallback, None, [EmergencyEventCallbackType])
        self._sig(dll.RegisterSlaveDiscoveryCallbackSync, None, [SlaveDiscoveryCallbackType])
        self._sig(dll.RegisterSlaveDiscoveryCallbackAsync, None, [SlaveDiscoveryCallbackType])
        self._sig(dll.RegisterRedundancyModeChangedCallback, None, [RedundancyModeChangedCallbackType])
        self._sig(dll.RegisterInputDataChangedCallback, None, [InputDataChangedCallbackType])
        self._sig(dll.RegisterPDOFrameLossCallback, None, [PDOFrameLossCallbackType])
        self._sig(dll.RegisterSlavePreOpReconfigCallback, None, [SlavePreOpReconfigCallbackType])
        # v2 热插拔: 从站身份不符回调 + 用户确认替换
        try:
            self._sig(dll.RegisterSlaveIdentityMismatchCallback, None, [SlaveIdentityMismatchCallbackType])
            self._sig(dll.AcknowledgeSlaveReplacement, c_bool, [c_ushort, c_ushort])
        except AttributeError:
            pass
        # 端口链路变化回调 (断线/恢复事件)
        try:
            self._sig(dll.RegisterSlavePortLinkChangedCallback, None, [SlavePortLinkChangedCallbackType])
        except AttributeError:
            pass
        # DL Port 端口控制 (故障注入 / 冗余诊断)
        try:
            self._sig(dll.WriteSlaveDLPORT, c_bool, [c_ushort, c_ushort, c_ubyte])
            self._sig(dll.ReadSlaveDLPORT, c_bool, [c_ushort, c_ushort, POINTER(c_ubyte)])
        except AttributeError:
            pass

        # ---- FoE ----
        self._sig(dll.FOERead, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.FOEWrite, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint, c_void_p, c_int, c_int])
        self._sig(dll.FOESetProgressHook, c_bool, [c_ushort, FoEProgressCallbackType])
        self._sig(dll.FOEClearProgressHook, c_bool, [c_ushort])
        # FoE 扩展 (带选项)
        self._sig(dll.FOEReadEx, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint,
                   POINTER(c_void_p), POINTER(c_int), c_int, POINTER(FoEOptions)])
        self._sig(dll.FOEWriteEx, c_bool,
                  [c_ushort, c_ushort, c_char_p, c_uint,
                   c_void_p, c_int, c_int, POINTER(FoEOptions)])

        # ---- SoE ----
        self._sig(dll.SoERead, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ubyte, c_ushort,
                   POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEWrite, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ubyte, c_ushort, c_void_p, c_int, c_int])
        self._sig(dll.SoEReadAttributes, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, POINTER(c_uint), c_int])
        self._sig(dll.SoEReadName, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEReadUnit, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEReadIDNList, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.SoEReadMinMax, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort,
                   POINTER(c_void_p), POINTER(c_int), POINTER(c_void_p), POINTER(c_int), c_int])

        # ---- EoE ----
        self._sig(dll.EOESetIP, c_bool, [c_ushort, c_ushort, c_ubyte, c_uint, c_uint, c_uint, c_int])
        self._sig(dll.EOEGetIP, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_uint), POINTER(c_uint), POINTER(c_uint), c_int])
        self._sig(dll.EOESendFrame, c_bool, [c_ushort, c_ushort, c_ubyte, c_void_p, c_int, c_int])
        self._sig(dll.EOEReceiveFrame, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_void_p), POINTER(c_int), c_int])
        # EoE MAC 地址
        self._sig(dll.EOESetMAC, c_bool, [c_ushort, c_ushort, c_ubyte, c_void_p, c_int])
        self._sig(dll.EOEGetMAC, c_bool, [c_ushort, c_ushort, c_ubyte, c_void_p, c_int])
        # EoE DNS
        self._sig(dll.EOESetDNS, c_bool, [c_ushort, c_ushort, c_ubyte, c_uint, c_char_p, c_int])
        self._sig(dll.EOEGetDNS, c_bool, [c_ushort, c_ushort, c_ubyte, POINTER(c_uint), c_char_p, c_int])
        # EoE 完整参数
        self._sig(dll.EOEGetFullParam, c_bool,
                  [c_ushort, c_ushort, c_ubyte,
                   POINTER(c_uint), POINTER(c_uint), POINTER(c_uint),
                   c_void_p, POINTER(c_uint), c_char_p, c_int])
        self._sig(dll.EOESetFullParam, c_bool,
                  [c_ushort, c_ushort, c_ubyte,
                   c_uint, c_uint, c_uint,
                   c_void_p, c_uint, c_char_p, c_int])
        # EoE 地址过滤
        self._sig(dll.EOESetAddressFilter, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ubyte, c_void_p, c_int])
        self._sig(dll.EOEGetAddressFilter, c_bool,
                  [c_ushort, c_ushort, c_ubyte, POINTER(c_ubyte), c_void_p, c_int, c_int])

        # ---- AoE ----
        self._sig(dll.AOESendCommand, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_ushort, c_void_p, c_uint,
                   POINTER(c_void_p), POINTER(c_uint), c_int])
        self._sig(dll.AOEReadWrite, c_bool,
                  [c_ushort, c_ushort, c_uint, c_uint, c_uint, c_uint, c_void_p,
                   POINTER(c_void_p), POINTER(c_uint), c_int])
        self._sig(dll.AOEReadDeviceInfo, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ubyte), POINTER(c_ubyte),
                   POINTER(c_ushort), c_void_p, c_int, c_int])
        self._sig(dll.AOEReadState, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ushort), POINTER(c_ushort), c_int])
        self._sig(dll.AOEWriteControl, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_ushort, c_void_p, c_int, c_int])
        # AoE 高级功能
        self._sig(dll.AOEAddNotification, c_bool,
                  [c_ushort, c_ushort, c_uint, c_uint, c_uint,
                   c_uint, c_uint, c_uint, POINTER(c_uint), c_int])
        self._sig(dll.AOEDelNotification, c_bool, [c_ushort, c_ushort, c_uint, c_int])
        self._sig(dll.AOESetConfig, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_ushort, c_void_p, c_ushort])
        self._sig(dll.AOEGetConfig, c_bool,
                  [c_ushort, c_ushort, c_void_p, POINTER(c_ushort), c_void_p, POINTER(c_ushort)])
        # AoE 通知监听
        self._sig(dll.AOEStartNotificationListener, c_bool, [c_ushort])
        self._sig(dll.AOEStopNotificationListener, c_bool, [])
        self._sig(dll.AOEIsNotificationListening, c_bool, [])
        self._sig(dll.AOERegisterNotification, c_int,
                  [c_ushort, c_uint, c_uint, c_uint, c_uint, c_void_p, c_void_p])
        self._sig(dll.AOEUnregisterNotification, c_bool, [c_int])

        # ---- VoE ----
        self._sig(dll.VOESend, c_bool,
                  [c_ushort, c_ushort, c_uint, c_ushort, c_void_p, c_int, c_int])
        self._sig(dll.VOEReceive, c_bool,
                  [c_ushort, c_ushort, POINTER(c_uint), POINTER(c_ushort),
                   POINTER(c_void_p), POINTER(c_int), c_int])
        self._sig(dll.VOEIsSupported, c_bool, [c_ushort, c_ushort])
        # VoE 原始帧收发
        self._sig(dll.VOESendRaw, c_bool, [c_ushort, c_ushort, c_void_p, c_int, c_int])
        self._sig(dll.VOEReceiveRaw, c_bool,
                  [c_ushort, c_ushort, POINTER(c_void_p), POINTER(c_int), c_int])

        # ---- PDO 直接读写 ----
        self._sig(dll.PDOReadDirect, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])
        self._sig(dll.PDOWriteDirect, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])

        # ---- PDO 批量读写 ----
        self._sig(dll.PDOBatchRead, c_uint,
                  [c_ushort, POINTER(c_ushort), c_uint,
                   POINTER(c_void_p), POINTER(c_uint), POINTER(c_uint)])
        self._sig(dll.PDOBatchWrite, c_uint,
                  [c_ushort, POINTER(c_ushort), c_uint,
                   POINTER(c_void_p), POINTER(c_uint)])

        # ---- PDO 监控 ----
        self._sig(dll.GetPDOStats, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.ResetPDOStats, None, [c_ushort, c_ushort])
        self._sig(dll.EnablePDOMonitoring, None, [c_bool])
        self._sig(dll.IsPDOMonitoringEnabled, c_bool, [])
        self._sig(dll.GetPDOAvgCycleTimeNs, c_uint64, [c_ushort])
        self._sig(dll.GetPDOErrorCount, c_uint, [c_ushort])
        self._sig(dll.IsPDOValid, c_int, [c_ushort])
        self._sig(dll.IsPDOChanged, c_int, [c_ushort])
        self._sig(dll.GetPDOExpectedSize, c_uint, [c_ushort])

        # ---- PDO 映射 ----
        self._sig(dll.GetPDOMapping, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])

        # ---- 定时器精度验证 ----
        self._sig(dll.DarraValidateTimerAccuracy, c_int, [c_uint32, c_uint32])

        # ---- 批量身份验证 ----
        self._sig(dll.VerifyAllSlaveIdentities, c_bool,
                  [c_ushort, POINTER(SlaveIdentity), c_uint, c_bool, c_bool, POINTER(c_uint64)])

        # ---- 组管理 ----
        self._sig(dll.SetSlaveGroup, c_bool, [c_ushort, c_ushort, c_ubyte])
        self._sig(dll.GetSlaveGroup, c_ubyte, [c_ushort, c_ushort])
        self._sig(dll.SetGroupCycleDivider, c_bool, [c_ushort, c_ubyte, c_ubyte])
        self._sig(dll.GetGroupCycleDivider, c_ubyte, [c_ushort, c_ubyte])
        self._sig(dll.SetGroupEnabled, c_bool, [c_ushort, c_ubyte, c_bool])
        self._sig(dll.GetGroupEnabled, c_bool, [c_ushort, c_ubyte])
        self._sig(dll.GetGroupExpectedWKC, c_ushort, [c_ushort, c_ubyte])
        self._sig(dll.GetActiveGroupCount, c_ubyte, [c_ushort])
        self._sig(dll.GetGroupSlaveCount, c_ushort, [c_ushort, c_ubyte])

        # ---- 启动参数管线 ----
        self._sig(dll.AddStartupParameter, c_int, [c_ushort, c_ushort, POINTER(StartupParam)])
        self._sig(dll.AddStartupParameterBatch, c_int, [c_ushort, c_ushort, POINTER(StartupParam), c_int])
        self._sig(dll.ClearStartupParameters, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetStartupParameterCount, c_int, [c_ushort, c_ushort])
        self._sig(dll.ApplyStartupParameters, c_int, [c_ushort, c_ushort, c_ubyte, c_ubyte])
        self._sig(dll.ApplyStartupParametersAll, c_int, [c_ushort, c_ubyte, c_ubyte])
        # Default PDO 自动发现 (协议下沉, 见 native default_pdo.c, 2026-05-02)
        # int EnumerateDefaultPdo(uint16 master, uint16 slave, int direction,
        #                         uint16* out_indices, int max_count)
        # direction: 0=RxPDO, 1=TxPDO; 返回写入数, -1=失败
        self._sig(dll.EnumerateDefaultPdo, c_int,
                  [c_ushort, c_ushort, c_int, POINTER(c_ushort), c_int])

        # DC SyncManager 同步类型配置 (协议下沉, 见 native dc_sync_mode.c, 2026-05-02)
        # SDK 公开层不再 SDOWrite 0x1C32/0x1C33; 由 native 处理 ETG.1020 §23.1.2 协议细节.
        # sync_type 编码: 0=FreeRun, 1=SmSynchron, 2=DcSynchron, 3=DcSynchron01
        try:
            self._sig(dll.SetDcSyncMode, c_bool,
                      [c_ushort, c_ushort, c_ubyte])
        except AttributeError:
            pass
        try:
            self._sig(dll.GetDcSyncMode, c_ubyte,
                      [c_ushort, c_ushort])
        except AttributeError:
            pass

        # ---- 看门狗 ----
        self._sig(dll.SetSlaveWatchdog, c_bool, [c_ushort, c_ushort, c_uint])
        self._sig(dll.SetSlavePdiWatchdog, c_bool, [c_ushort, c_ushort, c_uint])
        self._sig(dll.GetSlaveWatchdogConfig, c_bool, [c_ushort, c_ushort, POINTER(WatchdogConfig)])
        self._sig(dll.GetSlaveWatchdogStatus, c_bool, [c_ushort, c_ushort, POINTER(WatchdogStatus)])
        self._sig(dll.SetAllSlaveWatchdog, c_int, [c_ushort, c_uint])
        self._sig(dll.SetAllSlavePdiWatchdog, c_int, [c_ushort, c_uint])

        # ---- 配置验证 ----
        self._sig(dll.GetSlaveIdentity, c_bool, [c_ushort, c_ushort, POINTER(SlaveIdentity)])
        self._sig(dll.VerifySlaveIdentity, c_bool,
                  [c_ushort, c_ushort, POINTER(SlaveIdentity), c_bool, c_bool])

        # ---- 寄存器读写 ----
        self._sig(dll.WriteSlaveRegister, c_bool, [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.ReadSlaveRegister, c_bool, [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.ConfigureSyncManager, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_ushort, c_ushort, c_ubyte, c_bool])
        # FMMU 配置
        self._sig(dll.ConfigureFMMU, c_bool,
                  [c_ushort, c_ushort, c_ubyte, c_uint, c_ushort,
                   c_ubyte, c_ubyte, c_ushort, c_ubyte, c_ubyte, c_bool])

        # ---- SM/FMMU ----
        self._sig(dll.EnableOutputSyncManager, c_bool, [c_ushort, c_ushort])
        self._sig(dll.DisableOutputSyncManager, c_bool, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveOpOnlyFlag, c_bool, [c_ushort, c_ushort])
        self._sig(dll.SetSlaveErrorAck, c_bool, [c_ushort, c_ushort, c_bool])
        self._sig(dll.GetSlaveDeviceEmulationFlag, c_bool, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveEsmTimeouts, c_bool, [c_ushort, c_ushort, POINTER(SlaveEsmTimeouts)])
        self._sig(dll.SetSlaveEsmTimeouts, c_bool, [c_ushort, c_ushort, POINTER(SlaveEsmTimeouts)])

        # ---- 可选从站 ----
        self._sig(dll.SetSlaveOptional, c_bool, [c_ushort, c_ushort, c_bool])
        self._sig(dll.GetSlaveOptional, c_bool, [c_ushort, c_ushort])

        # ---- 帧重发支持 ----
        self._sig(dll.SetSlaveSupportsFrameRepeat, c_bool, [c_ushort, c_ushort, c_bool])
        self._sig(dll.GetSlaveSupportsFrameRepeat, c_bool, [c_ushort, c_ushort])

        # ---- 高级一步初始化 ----
        self._sig(dll.LoadConfigJson, c_int, [c_ushort, c_char_p])
        self._sig(dll.AutoConfigureSM, c_int, [c_ushort, c_ushort])
        self._sig(dll.EcInit, c_ushort, [c_char_p])
        self._sig(dll.EcInitFromFile, c_ushort, [c_char_p])
        self._sig(dll.EcClose, None, [c_ushort])
        self._sig(dll.DarraCoreInvoke, c_int, [c_ushort, c_uint, c_uint, c_uint, c_uint])
        self._sig(dll.DarraCoreInvokeText, c_int, [c_ushort, c_uint, c_char_p, c_uint, c_uint, c_uint])

        # ---- 主站诊断 ----
        self._sig(dll.GetMasterIdentity, c_bool, [c_ushort, POINTER(MasterIdentity)])
        self._sig(dll.GetMasterDiagData, c_bool, [c_ushort, POINTER(MasterDiagData)])

        # 获取详细诊断数据 (malloc 指针, 需要调用 FreeDetailedDiagnostics)
        self._sig(dll.GetDetailedDiagnostics, c_void_p, [c_ushort])
        self._sig(dll.FreeDetailedDiagnostics, None, [c_void_p])
        # 诊断开关
        self._sig(dll.SetDiagnosticsEnabled, None, [c_ushort, c_bool])
        self._sig(dll.GetDiagnosticsEnabled, c_bool, [c_ushort])
        # 获取诊断数据指针
        self._sig(dll.GetDiagnosticsPointer, c_void_p, [c_ushort])
        # 重置诊断
        self._sig(dll.ResetDiagnostics, None, [c_ushort])
        # 获取摘要数据指针
        self._sig(dll.GetSummaryPointer, c_void_p, [c_ushort])

        # 诊断数据采集
        self._sig(dll.GetExpectedWKC, c_uint16, [c_uint16])
        self._sig(dll.SetExpectedWKC, None, [c_uint16, c_uint16])
        # [2026-04-27] 唯一丢包率/过慢率源 (内核 5s 滑窗)
        self._sig(dll.GetPacketLossRate, c_float, [c_uint16])
        self._sig(dll.GetLateFrameRate, c_float, [c_uint16])
        self._sig(dll.GetSlaveLinkQuality, c_int16, [c_uint16, c_uint16])
        self._sig(dll.RecordCycleTime, None, [c_uint16, c_uint32])
        self._sig(dll.RecordPDOCycleStart, None, [c_uint16])
        self._sig(dll.RecordWKC, None, [c_uint16, c_uint16])
        self._sig(dll.UpdateDiagnosticsSnapshot, None, [c_uint16])
        self._sig(dll.ResetSlavePortErrorCounters, c_bool, [c_uint16, c_uint16])

        # ---- 冗余与故障 ----
        self._sig(dll.GetRingMode, c_int, [c_ushort])
        self._sig(dll.GetSecondaryLinkStatus, c_bool, [c_ushort])
        self._sig(dll.GetBreakPoints, c_int,
                  [c_ushort, POINTER(c_ushort), POINTER(c_ubyte), POINTER(c_ubyte), c_ushort])
        self._sig(dll.GetPrimaryWKC, c_ushort, [])
        self._sig(dll.GetSecondaryWKC, c_ushort, [])

        # ---- UDP ----
        self._sig(dll.SetUdpMode, c_bool, [c_ushort, c_bool])
        self._sig(dll.GetUdpMode, c_bool, [c_ushort])
        self._sig(dll.IsUdpAvailable, c_bool, [c_ushort])

        # ---- 实时优化 ----
        self._sig(dll.ApplyRealtimeOptimizations, c_bool, [])
        self._sig(dll.RemoveRealtimeOptimizations, c_bool, [])
        self._sig(dll.GetRealtimeOptimizationsStatus, c_bool, [])
        self._sig(dll.GetTimingMode, c_uint, [c_ushort])

        # ---- WDK 实时驱动 ----
        self._sig(dll.IsWdkAvailable, c_bool, [c_ushort])
        self._sig(dll.SetWdkMode, c_bool, [c_ushort, c_bool])
        self._sig(dll.GetWdkMode, c_bool, [c_ushort])
        self._sig(dll.StartWdkRT, c_bool, [c_ushort, c_uint, c_uint])
        self._sig(dll.StopWdkRT, c_bool, [c_ushort])

        # ---- DC 高级 ----
        self._sig(dll.SetDCAutoShiftEnabled, None, [c_ushort, c_bool])
        self._sig(dll.GetDCAutoShiftEnabled, c_bool, [c_ushort])
        self._sig(dll.SetMasterDCCycleTime, None, [c_ushort, c_uint])

        # ---- 冗余高级 ----
        self._sig(dll.EnableRedundancy, c_bool, [c_ushort, c_bool])
        self._sig(dll.GetRedundancyStatus, c_void_p, [c_ushort])
        self._sig(dll.ForceRedundancyFailover, c_bool, [c_ushort])
        self._sig(dll.CheckRedundancyHealth, c_bool, [c_ushort])

        # ---- 从站状态查询 ----
        self._sig(dll.GetSlaveState, c_ubyte, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveALStatusCode, c_ushort, [c_ushort, c_ushort])

        # ---- 从站 IO 信息查询 (slave_index=0 获取主站汇总) ----
        self._sig(dll.GetSlaveOutputBits, c_ushort, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveOutputBytes, c_uint, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveInputBits, c_ushort, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveInputBytes, c_uint, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveHasDC, c_bool, [c_ushort, c_ushort])

        # ---- 邮箱协议能力 (ETG.1000.6 SII mbx_proto bitfield) ----
        # bit 0=AoE, bit 1=EoE, bit 2=CoE, bit 3=FoE, bit 4=SoE, bit 5=VoE
        # 用于各协议 is_supported 属性检测从站邮箱能力.
        try:
            self._sig(dll.GetSlaveMailboxProto, c_ushort, [c_ushort, c_ushort])
        except AttributeError:
            pass

        # ---- 邮箱协议统计 (对齐 C# IMailboxProtocol.Statistics / ResetStatistics) ----
        # 按 (master_index, slave_index, protocol_type) 查询 / 重置各协议统计.
        # protocol_type 取 ECT_MBXT_* 位: CoE=3, FoE=4, SoE=5, AoE=1, EoE=2, VoE=0x0F, FSoE=8.
        # DLL 未导出时静默降级 (各协议类 statistics 会返回 empty, reset 无操作).
        try:
            self._sig(dll.mbx_get_stats_by_master, c_int,
                      [c_uint16, c_uint16, ctypes.c_uint8, POINTER(EcMbxStatsT)])
        except AttributeError:
            pass
        try:
            self._sig(dll.mbx_reset_stats_by_master, None,
                      [c_uint16, c_uint16, ctypes.c_uint8])
        except AttributeError:
            pass

        # ---- ESI / MDP / 厂商信息 ----
        self._sig(dll.GetSlaveHasEsi, c_int, [c_ushort, c_ushort])
        self._sig(dll.SetSlaveEsiFile, c_int, [c_ushort, c_ushort, c_char_p])
        self._sig(dll.GetSlaveEsiVersion, c_int, [c_ushort, c_ushort, c_void_p, c_int])
        self._sig(dll.GetSlaveHasMDP, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveVendorName, c_int, [c_ushort, c_ushort, c_void_p, c_int])

        # ---- 从站冗余状态 ----
        self._sig(dll.GetSlaveRedundancyActivated, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetSlavePrimaryLinkBroken, c_int, [c_ushort, c_ushort])
        self._sig(dll.GetSlaveSecondaryLinkBroken, c_int, [c_ushort, c_ushort])

        # ---- 无锁输出写入 ----
        self._sig(dll.WriteSlaveOutput, None, [c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.WriteSlaveOutputByte, None, [c_ushort, c_ushort, c_uint, c_ubyte])

        # ---- Mutex 保护 ----
        self._sig(dll.SetMutexProtection, None, [c_ushort, c_bool])
        self._sig(dll.GetMutexProtection, c_bool, [c_ushort])

        # ---- 网络扫描详细 ----
        self._sig(dll.ReadSlaveInfo, c_int, [c_char_p])
        self._sig(dll.GetScannedSlaveCount, c_int, [])
        self._sig(dll.GetScannedSlaveInfo, c_bool,
                  [c_int, POINTER(c_uint), POINTER(c_uint), POINTER(c_uint), POINTER(c_uint),
                   c_void_p, c_int, POINTER(c_ushort), POINTER(c_ushort),
                   POINTER(c_ushort), POINTER(c_ubyte), POINTER(c_ubyte),
                   POINTER(c_ubyte), POINTER(c_ubyte), POINTER(c_ubyte)])

        # ---- PDO 丢帧 ----
        self._sig(dll.GetPDOFrameLossStats, None,
                  [c_ushort, c_ubyte, POINTER(c_uint), POINTER(c_uint), POINTER(c_uint)])
        self._sig(dll.ResetPDOFrameLossStats, None, [c_ushort, c_ubyte])

        # ---- 热插拔 ----
        self._sig(dll.GetSlaveNeedsStartupReconfig, c_bool, [c_ushort, c_ushort])
        self._sig(dll.ClearSlaveNeedsStartupReconfig, None, [c_ushort, c_ushort])

        # ---- CiA 402 驱动协议 ----
        self._sig(dll.CiA402_ParseState, c_int, [c_ushort])
        self._sig(dll.CiA402_GetEnableCommand, c_ushort, [c_ushort])
        self._sig(dll.CiA402_SetMode, c_bool, [c_ushort, c_ushort, c_byte])
        self._sig(dll.CiA402_GetMode, c_byte, [c_ushort, c_ushort])
        self._sig(dll.CiA402_ReadStatusWord, c_ushort, [c_ushort, c_ushort])
        self._sig(dll.CiA402_WriteControlWord, c_bool, [c_ushort, c_ushort, c_ushort])
        self._sig(dll.CiA402_Enable, c_bool, [c_ushort, c_ushort, c_int])
        self._sig(dll.CiA402_FaultReset, c_bool, [c_ushort, c_ushort])

        # ---- EMCY 紧急消息历史 ----
        self._sig(dll.EmcyGetHistory, c_int, [c_ushort, c_ushort, POINTER(EmcyRecord), c_int])
        self._sig(dll.EmcyClearHistory, None, [c_ushort, c_ushort])
        self._sig(dll.EmcyGetCount, c_int, [c_ushort, c_ushort])

        # ---- CoE Diagnosis History 0x10F3 (ETG.1020 §16.2) ----
        # 4 个 DLL 导出函数, 对应 C# DLL.CoeDiag* P/Invoke.
        # DLL 未导出时静默降级 (协议类方法返回 False / None / 空字节).
        try:
            self._sig(dll.coe_diag_poll_new_available, c_int,
                      [c_ushort, c_ushort, POINTER(c_uint)])
        except AttributeError:
            pass
        try:
            self._sig(dll.coe_diag_read_meta, c_int,
                      [c_ushort, c_ushort,
                       POINTER(c_ubyte), POINTER(c_ubyte),
                       POINTER(c_ubyte), POINTER(c_ushort),
                       POINTER(c_uint)])
        except AttributeError:
            pass
        try:
            self._sig(dll.coe_diag_read_message, c_int,
                      [c_ushort, c_ushort, c_ubyte,
                       ctypes.POINTER(c_ubyte), c_int,
                       POINTER(c_int), POINTER(c_uint)])
        except AttributeError:
            pass
        try:
            self._sig(dll.coe_diag_acknowledge, c_int,
                      [c_ushort, c_ushort, c_ubyte, POINTER(c_uint)])
        except AttributeError:
            pass

        # ---- FSoE ConnID 校验 (ETG.5120 §5.2.3) ----
        # 对应 C# DLL.FSoEValidateConnId. 薄封装, 无状态, 返回 bool.
        try:
            self._sig(dll.FSoEValidateConnId, c_bool, [c_ushort])
        except AttributeError:
            pass

        # ---- DC 时间查询 (2026-04-24) ----
        # 对应 C# DLL.GetMasterDCTime / DLL.GetReferenceClockSlaveIndex.
        try:
            self._sig(dll.GetMasterDCTime, c_uint64, [c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.GetReferenceClockSlaveIndex, c_ushort, [c_ushort])
        except AttributeError:
            pass

        # ---- SoE Notification / Emergency 回调 (ETG.1020 OpCode=5/6) ----
        # 对应 C# DLL.RegisterSoENotificationCallback / RegisterSoEEmergencyCallback.
        try:
            self._sig(dll.RegisterSoENotificationCallback, None,
                      [SoENotificationCallbackType])
        except AttributeError:
            pass
        try:
            self._sig(dll.RegisterSoEEmergencyCallback, None,
                      [SoEEmergencyCallbackType])
        except AttributeError:
            pass

        # ---- FoE Cancel / BusyHook ----
        # 对应 C# DLL.FOERequestCancel / FOEClearCancel / FOESetBusyHook.
        try:
            self._sig(dll.FOERequestCancel, c_bool, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.FOEClearCancel, c_bool, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.FOESetBusyHook, c_bool, [c_ushort, FoEBusyCallbackType])
        except AttributeError:
            pass

        # ---- Hot-Connect (ETG.1020 §8) ----
        # 对应 C# DLL.HotConnectAddGroup / RemoveGroup / GetGroupStatus /
        # Enumerate / ClearAll / GetGroupCount. C 端在 hotconnect.h 中导出.
        # DLL 未导出时静默降级 (HotConnect 类方法返回 False / 空 / UNKNOWN).
        try:
            self._sig(dll.HotConnectAddGroup, c_int,
                      [c_ushort, c_ushort, c_ushort, c_uint, c_uint])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectRemoveGroup, c_int, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectGetGroupStatus, c_int, [c_ushort, c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectEnumerate, c_int,
                      [c_ushort, POINTER(HotConnectGroupNative), c_int])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectClearAll, None, [c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.HotConnectGetGroupCount, c_int, [c_ushort])
        except AttributeError:
            pass

        # ---- EoE 扩展 (TIME_APPEND 时间戳 + 异步接收 Hook) ----
        # 对应 C# DLL.EOESendFrameEx / EOESetReceiveHook / EOEClearReceiveHook.
        try:
            self._sig(dll.EOESendFrameEx, c_bool,
                      [c_ushort, c_ushort, c_ubyte, c_void_p, c_int,
                       c_ubyte, c_uint, c_int])
        except AttributeError:
            pass
        try:
            self._sig(dll.EOESetReceiveHook, c_bool,
                      [c_ushort, EOEFrameCallbackType])
        except AttributeError:
            pass
        try:
            self._sig(dll.EOEClearReceiveHook, c_bool, [c_ushort])
        except AttributeError:
            pass

        # ---- VoE 异步通知 (Vendor-initiated, 对应 C# VoE NotificationReceived) ----
        # DLL.VoE.cs 暴露 VOEStartNotificationListener / VOEStopNotificationListener /
        # VOEIsNotificationListening / VOERegisterNotification / VOEUnregisterNotification.
        try:
            self._sig(dll.VOEStartNotificationListener, c_bool, [c_ushort])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOEStopNotificationListener, c_bool, [])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOEIsNotificationListening, c_bool, [])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOERegisterNotification, c_int,
                      [c_ushort, c_uint, c_ushort,
                       VoENotificationCallbackType, c_void_p])
        except AttributeError:
            pass
        try:
            self._sig(dll.VOEUnregisterNotification, c_bool, [c_int])
        except AttributeError:
            pass

        # 注: SDO Block Transfer 绑定已按 ETG.1000.6 §5.6.2 audit 结论删除
        # (标准只定义 Expedited + Normal). Segmented Transfer 覆盖所有 >4 B 场景.

        # ---- PDO 类型化读写 ----
        self._sig(dll.PDOReadInputU8, c_ubyte, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputI16, c_short, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputU16, c_ushort, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputI32, c_int, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputU32, c_uint, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOReadInputF32, c_float, [c_ushort, c_ushort, c_uint32])
        self._sig(dll.PDOWriteOutputU8, c_bool, [c_ushort, c_ushort, c_uint32, c_ubyte])
        self._sig(dll.PDOWriteOutputI16, c_bool, [c_ushort, c_ushort, c_uint32, c_short])
        self._sig(dll.PDOWriteOutputU16, c_bool, [c_ushort, c_ushort, c_uint32, c_ushort])
        self._sig(dll.PDOWriteOutputI32, c_bool, [c_ushort, c_ushort, c_uint32, c_int])
        self._sig(dll.PDOWriteOutputU32, c_bool, [c_ushort, c_ushort, c_uint32, c_uint])
        self._sig(dll.PDOWriteOutputF32, c_bool, [c_ushort, c_ushort, c_uint32, c_float])

        # ---- PDO 类型化读写 (旧接口, 兼容) ----
        self._sig(dll.PdoWriteInt8, None, [c_ushort, c_ushort, c_uint, c_byte])
        self._sig(dll.PdoWriteInt16, None, [c_ushort, c_ushort, c_uint, c_short])
        self._sig(dll.PdoWriteInt32, None, [c_ushort, c_ushort, c_uint, c_int])
        self._sig(dll.PdoWriteUint8, None, [c_ushort, c_ushort, c_uint, c_ubyte])
        self._sig(dll.PdoWriteUint16, None, [c_ushort, c_ushort, c_uint, c_ushort])
        self._sig(dll.PdoWriteUint32, None, [c_ushort, c_ushort, c_uint, c_uint])
        self._sig(dll.PdoReadInt8, c_byte, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadInt16, c_short, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadInt32, c_int, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadUint8, c_ubyte, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadUint16, c_ushort, [c_ushort, c_ushort, c_uint])
        self._sig(dll.PdoReadUint32, c_uint, [c_ushort, c_ushort, c_uint])

        # ---- 网络拓扑 ----
        self._sig(dll.TopologyBuild, c_int, [c_ushort, POINTER(TopologyNode), c_int])
        self._sig(dll.TopologyGetChildren, c_int, [c_ushort, c_ushort, POINTER(c_ushort), c_int])
        self._sig(dll.TopologyGetRoots, c_int, [c_ushort, POINTER(c_ushort), c_int])
        # 获取拓扑信息
        self._sig(dll.GetTopology, c_int, [c_ushort, c_void_p, c_int])
        # 获取从站活动端口
        self._sig(dll.GetSlaveActivePorts, c_ubyte, [c_ushort, c_ushort])
        # 获取从站父节点索引
        self._sig(dll.GetSlaveParent, c_ushort, [c_ushort, c_ushort])

        # ---- ESC 端口错误诊断 (ETG.1000.4) ----
        self._sig(dll.ReadSlavePortErrorCounters, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ubyte), POINTER(c_ubyte), POINTER(c_ubyte)])
        self._sig(dll.ReadAllSlavePortErrorCounters, c_int, [c_ushort])
        self._sig(dll.GetSlavePortErrorStats, c_void_p, [c_ushort, c_ushort])
        self._sig(dll.UpdateDiagnosticsWithESCErrors, None, [c_ushort])

        # ---- PDO 线程 CPU 亲和性 ----
        self._sig(dll.SetPDOThreadCpuAffinity, c_bool, [c_ushort, c_int])
        self._sig(dll.GetPDOThreadCpuAffinity, c_int, [c_ushort])

        # ---- 冗余批量查找 ----
        self._sig(dll.QuickFindRedundantPairBatch, c_int,
                  [POINTER(c_char_p), c_int, POINTER(c_int), POINTER(c_int),
                   POINTER(c_int), POINTER(c_int)])

        # ---- 调试辅助 ----
        self._sig(dll.DebugSlaveHasDC, None, [c_ushort, c_ushort])

        # ---- 配置验证 (ETG.1500 5.5.2) ----
        self._sig(dll.ec_validate_config, c_int, [c_uint16])

        # ---- 性能统计导出 CSV ----
        self._sig(dll.ec_perf_export_csv, c_int, [c_uint16, c_char_p])

        # ---- FSoE 功能安全 (ETG.5100/5120) ----
        # FSoE 单连接 (16个函数)
        self._sig(dll.FSoEInitConnection, c_bool,
                  [c_ushort, c_ushort, POINTER(FsoEConfig)])
        self._sig(dll.FSoECloseConnection, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEGetStatus, c_bool,
                  [c_ushort, c_ushort, POINTER(FsoEStatus)])
        self._sig(dll.FSoERequestState, c_bool, [c_ushort, c_ushort, c_int])
        self._sig(dll.FSoEGetState, c_int, [c_ushort, c_ushort])
        self._sig(dll.FSoEReset, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEWriteSafeOutput, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.FSoEReadSafeInput, c_bool,
                  [c_ushort, c_ushort, c_void_p, POINTER(c_uint)])
        self._sig(dll.FSoEDownloadParameters, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])
        self._sig(dll.FSoESetFailsafeOutput, c_bool,
                  [c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.FSoECheckWatchdog, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEGetLastError, c_int, [c_ushort, c_ushort])
        self._sig(dll.FSoEClearError, None, [c_ushort, c_ushort])
        self._sig(dll.FSoEIsSlaveCapable, c_bool, [c_ushort, c_ushort])
        self._sig(dll.FSoEGetConnectionCount, c_ushort, [c_ushort])
        self._sig(dll.FSoEProcessCycle, None, [c_ushort])

        # FSoE MDP 多连接 (18个函数)
        self._sig(dll.SafeMdpInitConnection, c_bool,
                  [c_ushort, c_ushort, c_ushort, POINTER(SafeMdpConfig)])
        self._sig(dll.SafeMdpCloseConnection, c_bool,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.SafeMdpGetStatus, c_bool,
                  [c_ushort, c_ushort, c_ushort, POINTER(FsoEStatus)])
        self._sig(dll.SafeMdpRequestState, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_int])
        self._sig(dll.SafeMdpGetState, c_int,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.SafeMdpReset, c_bool,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.SafeMdpWriteSafeOutput, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.SafeMdpReadSafeInput, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, POINTER(c_uint)])
        self._sig(dll.SafeMdpDownloadParameters, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint, POINTER(c_uint)])
        self._sig(dll.SafeMdpSetFailsafeOutput, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, c_uint])
        self._sig(dll.SafeMdpCheckWatchdog, c_bool,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.SafeMdpGetLastError, c_int,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.SafeMdpClearError, None,
                  [c_ushort, c_ushort, c_ushort])
        self._sig(dll.SafeMdpGetSlaveConnectionCount, c_ushort,
                  [c_ushort, c_ushort])
        self._sig(dll.SafeMdpDetectConnections, c_ushort,
                  [c_ushort, c_ushort])
        self._sig(dll.SafeMdpGetDeviceAddress, c_bool,
                  [c_ushort, c_ushort, POINTER(c_ushort)])
        self._sig(dll.SafeMdpGetModuleCommParam, c_bool,
                  [c_ushort, c_ushort, c_ushort, c_void_p, POINTER(c_uint)])
        self._sig(dll.SafeMdpGetModuleDiagnosis, c_bool,
                  [c_ushort, c_ushort, c_ushort, POINTER(c_ushort), POINTER(c_ushort)])

        # ===================================================================
        # 协议解码 / 错误码表 (DLL 端 protocol/ec_*.{c,h}, VMP 保护)
        # 字符串返回值统一为 c_char_p (C 端是 UTF-8), 调用方用 .decode("utf-8") 解码
        # 78 个新函数: AL_StatusCode 4 / SDOAbort 4 / EmcyCode 5 / EcState 8 /
        #   EcPdoCodec 15 / CiA402Modes 13 / EcMailbox+SoE 5 / EcSii 19 /
        #   EcCouplerId 6 / EcDiagStrings 4 = 83 个函数 (C# DLL.cs 同步)
        # ===================================================================

        # --- AL_STATUS_CODE (ec_status_codes.h) - 4 ---
        self._sig(dll.AL_StatusCode_GetDescription, c_char_p, [c_uint16])
        self._sig(dll.AL_StatusCode_GetSeverity, c_int, [c_uint16])
        self._sig(dll.AL_StatusCode_GetRecoveryHint, c_char_p, [c_uint16])
        self._sig(dll.AL_StatusCode_IsVendorSpecific, c_int, [c_uint16])

        # --- SDO Abort Code (ec_sdo_abort.h) - 4 ---
        self._sig(dll.SDOAbort_GetDescription, c_char_p, [c_uint32])
        self._sig(dll.SDOAbort_GetCategory, c_int, [c_uint32])
        self._sig(dll.SDOAbort_IsRetryable, c_int, [c_uint32])
        self._sig(dll.SDOAbort_GetHint, c_char_p, [c_uint32])

        # --- EMCY Emergency Code (ec_emcy_codes.h) - 5 ---
        self._sig(dll.EmcyCode_GetDescription, c_char_p, [c_uint16])
        self._sig(dll.EmcyCode_GetClass, c_int, [c_uint16])
        self._sig(dll.EmcyCode_GetClassName, c_char_p, [c_int])
        self._sig(dll.EmcyCode_FormatErrorRegister, None,
                  [c_ubyte, POINTER(c_ubyte), c_int])
        self._sig(dll.EmcyCode_IsRecovery, c_int, [c_uint16])

        # --- ESM 状态合法性 (ec_state_validator.h) - 8 ---
        self._sig(dll.EcState_IsValidTransition, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcState_GetTransitionType, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcState_GetTransitionPath, c_int,
                  [c_uint16, c_uint16, POINTER(c_uint16), c_int])
        self._sig(dll.EcState_IsBootstrapRequired, c_int, [c_uint16])
        self._sig(dll.EcState_GetName, c_char_p, [c_uint16])
        self._sig(dll.EcState_GetNameEn, c_char_p, [c_uint16])
        self._sig(dll.EcState_HasErrorAck, c_int, [c_uint16])
        self._sig(dll.EcState_StripErrorAck, c_uint16, [c_uint16])

        # --- PDO Codec / 端口拓扑 (ec_pdo_codec.h) - 15 ---
        self._sig(dll.EcPdoCodec_DataTypeBitSize, c_int, [c_int])
        self._sig(dll.EcPdoCodec_DataTypeName, c_char_p, [c_int])
        self._sig(dll.EcPdoCodec_ExtractU64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, POINTER(c_uint64)])
        self._sig(dll.EcPdoCodec_ExtractI64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, POINTER(ctypes.c_int64)])
        self._sig(dll.EcPdoCodec_InsertU64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, c_uint64])
        self._sig(dll.EcPdoCodec_InsertI64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_int, ctypes.c_int64])
        self._sig(dll.EcPdoCodec_ExtractReal32, c_int,
                  [POINTER(c_ubyte), c_int, c_int, POINTER(c_float)])
        self._sig(dll.EcPdoCodec_ExtractReal64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, POINTER(c_double)])
        self._sig(dll.EcPdoCodec_InsertReal32, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_float])
        self._sig(dll.EcPdoCodec_InsertReal64, c_int,
                  [POINTER(c_ubyte), c_int, c_int, c_double])
        self._sig(dll.EcPdoCodec_CountActivePorts, c_int, [c_ubyte])
        self._sig(dll.EcPdoCodec_GetTopology, c_int, [c_ubyte])
        self._sig(dll.EcPdoCodec_GetTopologyName, c_char_p, [c_int])
        self._sig(dll.EcPdoCodec_GetTopologyNameEn, c_char_p, [c_int])
        self._sig(dll.EcPdoCodec_IsPortActive, c_int, [c_ubyte, c_int])

        # --- CiA402 模式 / 回零方法 (ec_cia402_modes.h) - 13 ---
        self._sig(dll.CiA402Modes_ModeToSupportedBit, c_int, [c_byte])
        self._sig(dll.CiA402Modes_IsModeSupportedInMask, c_int, [c_uint, c_byte])
        self._sig(dll.CiA402Modes_ExpandSupportedMask, c_int,
                  [c_uint, POINTER(c_byte), c_int])
        self._sig(dll.CiA402Modes_GetModeName, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_GetModeNameEn, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_GetModeDescription, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_IsCyclicSyncMode, c_int, [c_byte])
        self._sig(dll.CiA402Modes_RequiresDC, c_int, [c_byte])
        self._sig(dll.CiA402Modes_IsStandardHomingMethod, c_int, [c_byte])
        self._sig(dll.CiA402Modes_GetHomingMethodName, c_char_p, [c_byte])
        self._sig(dll.CiA402Modes_GetHomingTrigger, c_int, [c_byte])
        self._sig(dll.CiA402Modes_GetHomingDirection, c_int, [c_byte])
        self._sig(dll.CiA402Modes_ListStandardHomingMethods, c_int,
                  [POINTER(c_byte), c_int])

        # --- Mailbox 协议码 (ec_mailbox_codes.h) - 5 (含 SoE) ---
        self._sig(dll.EcMailbox_GetTypeName, c_char_p, [c_uint16])
        self._sig(dll.EcMailbox_GetTypeNameEn, c_char_p, [c_uint16])
        self._sig(dll.EcMailbox_GetErrorDescription, c_char_p, [c_uint16])
        self._sig(dll.EcMailbox_NextCounter, c_ubyte, [c_ubyte])
        self._sig(dll.EcSoE_GetErrorDescription, c_char_p, [c_uint16])

        # --- SII 解析 (ec_sii_parser.h) - 19 ---
        self._sig(dll.EcSii_FindCategory, c_int,
                  [POINTER(c_ubyte), c_int, c_uint16, POINTER(c_int)])
        self._sig(dll.EcSii_EnumerateCategories, c_int,
                  [POINTER(c_ubyte), c_int, POINTER(c_uint16), c_int])
        self._sig(dll.EcSii_GetStringByIndex, c_int,
                  [POINTER(c_ubyte), c_int, c_int, POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetStringCount, c_int,
                  [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetVendorId, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetProductCode, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetRevision, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetSerialNumber, c_uint, [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_GetConfiguredAlias, c_uint16,
                  [POINTER(c_ubyte), c_int])
        self._sig(dll.EcSii_CoeEnabled, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoeSdoInfo, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoePdoAssign, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoePdoConfig, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoeUploadAtStartup, c_int, [c_ubyte])
        self._sig(dll.EcSii_CoeCompleteAccess, c_int, [c_ubyte])
        self._sig(dll.EcSii_FoeEnabled, c_int, [c_ubyte])
        self._sig(dll.EcSii_EoeEnabled, c_int, [c_ubyte])

        # --- 耦合器识别 (ec_coupler_id.h) - 6 ---
        self._sig(dll.EcCouplerId_DetectDeviceType, c_int, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_IsCoupler, c_int, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_IsTerminal, c_int, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_GetVendorName, c_char_p, [c_uint])
        self._sig(dll.EcCouplerId_GetVendorNameEn, c_char_p, [c_uint])
        self._sig(dll.EcCouplerId_GetDeviceTypeName, c_char_p, [c_int])
        self._sig(dll.EcCouplerId_GetCouplerModel, c_char_p, [c_uint, c_uint])
        self._sig(dll.EcCouplerId_GetEntryCount, c_int, [])
        self._sig(dll.EcCouplerId_GetVendorCount, c_int, [])

        # --- ESI XML 解析 (ec_esi_parser.cpp) - 9 ---
        # DLL 内置 ESI XML 解析, 不再需要 C# 独占, 让其他语言能注册启动参数
        self._sig(dll.EcEsi_LoadFile, c_int, [c_char_p])
        self._sig(dll.EcEsi_LoadDirectory, c_int, [c_char_p])
        self._sig(dll.EcEsi_Clear, None, [])
        self._sig(dll.EcEsi_GetLoadedCount, c_int, [])
        self._sig(dll.EcEsi_BindToSlave, c_int, [c_uint16, c_uint16, c_char_p])
        self._sig(dll.EcEsi_AutoMatchAll, c_int, [c_uint16])
        self._sig(dll.EcEsi_RegisterStartupParameters, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcEsi_ApplyAllSlaves, c_int, [c_uint16])
        self._sig(dll.SetSlaveEsiFile, c_int, [c_uint16, c_uint16, c_char_p])

        # --- 诊断翻译 (ec_diag_strings.h) - 4 ---
        self._sig(dll.EcDiagStrings_TopologyDescription, c_char_p, [c_ubyte])
        self._sig(dll.EcDiagStrings_TimingMode, c_char_p, [c_uint])
        self._sig(dll.EcDiagStrings_BreakpointType, c_char_p, [c_ubyte])
        self._sig(dll.EcDiagStrings_FormatBreakpoint, None,
                  [c_uint16, c_ubyte, c_ubyte, POINTER(c_ubyte), c_int])

        # --- ESI Device 字段直读 API (Step 1, D_1603-1608) - 6 ---
        # 协议下沉: SDK 不再独立解析 ESI XML, 改 native 直接拿 Device 字段.
        # 全部 by (master_index, slave_index); Slave 必须先 EcEsi_BindToSlave / AutoMatchAll.
        self._sig(dll.EcEsi_GetDevicePdoIndices, c_int,
                  [c_uint16, c_uint16, c_int, POINTER(c_uint16), c_int])
        self._sig(dll.EcEsi_GetDevicePdoSizeBits, c_int, [c_uint16, c_uint16, c_uint16])
        self._sig(dll.EcEsi_GetDeviceSmInfo, c_int,
                  [c_uint16, c_uint16, c_ubyte,
                   POINTER(c_uint16), POINTER(c_uint16), POINTER(c_ubyte)])
        self._sig(dll.EcEsi_GetDeviceDcSyncMode, c_int, [c_uint16, c_uint16])
        self._sig(dll.EcEsi_GetDeviceMailboxTimeout, c_int,
                  [c_uint16, c_uint16, POINTER(c_int), POINTER(c_int)])
        self._sig(dll.EcEsi_GetDeviceIdentity, c_int,
                  [c_uint16, c_uint16, POINTER(c_uint32), POINTER(c_uint32),
                   POINTER(c_uint32), POINTER(c_ubyte), c_int])

    def _sig(self, func_or_name, restype, argtypes):
        """设置函数签名的辅助方法 (容忍 DLL 缺失符号).

        参数 func_or_name 可以是:
          - ctypes 函数对象 (按旧用法直接设置签名)
          - 字符串 (在 DLL 中按名查找, 找不到则记录到 missing_symbols 并安装一个 stub)
        """
        if isinstance(func_or_name, str):
            try:
                func = getattr(self._dll, func_or_name)
            except AttributeError:
                # DLL 没导出该符号, 记录, 不阻塞其他绑定
                if not hasattr(self, 'missing_symbols'):
                    self.missing_symbols = set()
                self.missing_symbols.add(func_or_name)
                return None
            func.restype = restype
            func.argtypes = argtypes
            return func
        # 旧用法: 直接传入 ctypes 函数对象
        func_or_name.restype = restype
        func_or_name.argtypes = argtypes
        return func_or_name

    def __getattr__(self, name):
        """代理到底层 DLL 函数 (缺失则抛 NotImplementedError 而非 AttributeError).

        语义名 (如 'Initialize') 自动转发到真实导出 D_NNNN (如 D_1547);
        调度器名 'DarraCoreInvoke'/'DarraCoreInvokeText' 直接按名访问.
        """
        # 先访问 _dll. 注: __getattr__ 只在常规查找失败后调用, 不会进入死循环.
        try:
            dll = object.__getattribute__(self, '_dll')
        except AttributeError:
            raise AttributeError(name)
        try:
            return _resolve_export(dll, name)
        except AttributeError:
            missing = getattr(self, 'missing_symbols', set())
            if name in missing or True:
                def _stub(*_a, **_kw):
                    raise NotImplementedError(
                        f"DLL symbol '{name}' not exported by current Darra.Core.dll"
                    )
                return _stub
