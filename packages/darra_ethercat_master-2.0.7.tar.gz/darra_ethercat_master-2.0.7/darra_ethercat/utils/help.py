# -*- coding: utf-8 -*-
"""
对应 C# 文件: Utils/Help.cs
字符串编码辅助工具

包含:
- convert_byte_array_to_string: 字节数组转字符串 (自动检测编码)
"""


def convert_byte_array_to_string(data: bytes) -> str:
    """
    将字节数组转换为字符串 (EtherCAT 设备字符串多编码兜底, 与 C# Help.ConvertByteArrayToString 一致)

    解码顺序:
    1. UTF-8 strict (现代 ESI/CoE 主流编码)
    2. ASCII strict (老 SII / SoE / 古早 ESI 字符串)
    3. Latin-1 1:1 兜底 (永不失败, 任意字节都能映射为 U+0000~U+00FF)

    参数:
        data: 字节数据 (设备名 / 厂商名 / SoE 名 / SII string 等)

    返回:
        解码后的字符串
    """
    if not data:
        return ""

    # 去除末尾 NUL (C 风格字符串)
    null_idx = data.find(b'\x00')
    if null_idx >= 0:
        data = data[:null_idx]

    if not data:
        return ""

    # 1. UTF-8 strict
    try:
        return data.decode('utf-8', errors='strict')
    except UnicodeDecodeError:
        pass

    # 2. ASCII strict
    try:
        return data.decode('ascii', errors='strict')
    except UnicodeDecodeError:
        pass

    # 3. Latin-1 (iso-8859-1) 1:1 字节兜底, 永不失败
    return data.decode('iso-8859-1', errors='strict')


# 向后兼容/简短别名 (对齐 C# Help.ConvertByteArrayToString)
decode_ethercat_string = convert_byte_array_to_string
