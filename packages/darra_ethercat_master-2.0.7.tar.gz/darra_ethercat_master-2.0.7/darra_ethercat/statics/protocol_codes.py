# -*- coding: utf-8 -*-
"""
协议常量解码 (转发到 DLL 端 ec_*.h 模块)

Python 友好的静态 API, 包装 78 个 DLL 协议解码函数:
- AL_StatusCode (4): EtherCAT 状态机错误码
- SDOAbort (4): SDO 中止码
- EmcyCode (5): CANopen Emergency 错误码
- EcState (8): 状态机转换合法性
- EcPdoCodec (15): PDO 数据编解码 + 端口拓扑
- CiA402Modes (13): CiA402 运动模式 + 回零方法
- EcMailbox (5): Mailbox 类型 / 错误 / SoE 错误
- EcSii (19): SII EEPROM 解析
- EcCouplerId (6): 耦合器/终端识别
- EcDiagStrings (4): 拓扑/时序/断点诊断翻译

使用:
    from ethercat.statics.protocol_codes import ProtocolCodes
    ProtocolCodes.set_dll(dll)  # 一次性注入
    desc = ProtocolCodes.al_status_description(0x001A)
    abort = ProtocolCodes.sdo_abort_description(0x06010000)
"""

from ctypes import (
    c_byte, c_ubyte, c_int, c_uint, c_uint16, c_uint64, c_int64,
    c_float, c_double, byref,
)
from typing import List, Optional, Tuple

from ..utils.dll import DarraCoreDLL


def _decode(p: Optional[bytes]) -> str:
    """C const char* (c_char_p) -> str. None/空返回空串."""
    if p is None:
        return ""
    try:
        return p.decode("utf-8", errors="replace")
    except Exception:
        return ""


class ProtocolCodes:
    """协议错误码 / 常量解码 静态类 (78 函数)"""

    _dll: Optional[DarraCoreDLL] = None

    @classmethod
    def set_dll(cls, dll: DarraCoreDLL) -> None:
        """注入 DLL 实例 (使用前必须调用一次)"""
        cls._dll = dll

    @classmethod
    def _ok(cls) -> bool:
        return cls._dll is not None

    # ==================================================================
    # AL_StatusCode (ec_status_codes.h) - 4
    # ==================================================================

    @classmethod
    def al_status_description(cls, code: int) -> str:
        """AL Status Code 中文描述"""
        if not cls._ok():
            return "未知错误"
        try:
            return _decode(cls._dll.AL_StatusCode_GetDescription(code & 0xFFFF)) or "未知错误"
        except Exception:
            return "未知错误"

    @classmethod
    def al_status_severity(cls, code: int) -> int:
        """AL Status Code 严重程度 (0=Info, 1=Warn, 2=Error, 3=Critical)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.AL_StatusCode_GetSeverity(code & 0xFFFF))
        except Exception:
            return 0

    @classmethod
    def al_status_recovery_hint(cls, code: int) -> str:
        """AL Status Code 恢复建议"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.AL_StatusCode_GetRecoveryHint(code & 0xFFFF))
        except Exception:
            return ""

    @classmethod
    def al_status_is_vendor_specific(cls, code: int) -> bool:
        """是否厂商私有错误码"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.AL_StatusCode_IsVendorSpecific(code & 0xFFFF))
        except Exception:
            return False

    # ==================================================================
    # SDO Abort Code (ec_sdo_abort.h) - 4
    # ==================================================================

    @classmethod
    def sdo_abort_description(cls, abort_code: int) -> str:
        """SDO Abort Code 描述"""
        if not cls._ok():
            return "未知中止码"
        try:
            return _decode(cls._dll.SDOAbort_GetDescription(abort_code & 0xFFFFFFFF)) or "未知中止码"
        except Exception:
            return "未知中止码"

    @classmethod
    def sdo_abort_category(cls, abort_code: int) -> int:
        """SDO Abort Code 分类"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.SDOAbort_GetCategory(abort_code & 0xFFFFFFFF))
        except Exception:
            return 0

    @classmethod
    def sdo_abort_is_retryable(cls, abort_code: int) -> bool:
        """该中止码是否值得重试"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.SDOAbort_IsRetryable(abort_code & 0xFFFFFFFF))
        except Exception:
            return False

    @classmethod
    def sdo_abort_hint(cls, abort_code: int) -> str:
        """SDO Abort 操作提示"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.SDOAbort_GetHint(abort_code & 0xFFFFFFFF))
        except Exception:
            return ""

    # ==================================================================
    # EMCY Emergency Code (ec_emcy_codes.h) - 5
    # ==================================================================

    @classmethod
    def emcy_description(cls, error_code: int) -> str:
        """EMCY 错误描述"""
        if not cls._ok():
            return "未知 EMCY"
        try:
            return _decode(cls._dll.EmcyCode_GetDescription(error_code & 0xFFFF)) or "未知 EMCY"
        except Exception:
            return "未知 EMCY"

    @classmethod
    def emcy_class(cls, error_code: int) -> int:
        """EMCY 错误类别 (CiA301 高字节)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EmcyCode_GetClass(error_code & 0xFFFF))
        except Exception:
            return 0

    @classmethod
    def emcy_class_name(cls, class_code: int) -> str:
        """EMCY 类别名称"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EmcyCode_GetClassName(int(class_code)))
        except Exception:
            return ""

    @classmethod
    def emcy_format_error_register(cls, error_register: int, buf_size: int = 256) -> str:
        """格式化 Error Register 字节为可读描述"""
        if not cls._ok():
            return ""
        try:
            buf = (c_ubyte * buf_size)()
            cls._dll.EmcyCode_FormatErrorRegister(
                int(error_register) & 0xFF, buf, buf_size)
            raw = bytes(buf).split(b'\x00', 1)[0]
            return raw.decode("utf-8", errors="replace")
        except Exception:
            return ""

    @classmethod
    def emcy_is_recovery(cls, error_code: int) -> bool:
        """是否为恢复 (Reset) 类 EMCY (低 4 位 == 0)"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.EmcyCode_IsRecovery(error_code & 0xFFFF))
        except Exception:
            return False

    # ==================================================================
    # ESM 状态合法性 (ec_state_validator.h) - 8
    # ==================================================================

    @classmethod
    def state_is_valid_transition(cls, frm: int, to: int) -> bool:
        """状态转换是否合法"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.EcState_IsValidTransition(frm & 0xFFFF, to & 0xFFFF))
        except Exception:
            return False

    @classmethod
    def state_get_transition_type(cls, frm: int, to: int) -> int:
        """转换类型 (IS/PI/PS/SO/...) 返回内部枚举"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EcState_GetTransitionType(frm & 0xFFFF, to & 0xFFFF))
        except Exception:
            return 0

    @classmethod
    def state_get_transition_path(cls, frm: int, to: int, capacity: int = 8) -> List[int]:
        """获取从 frm 到 to 的完整状态序列"""
        if not cls._ok():
            return []
        try:
            arr = (c_uint16 * capacity)()
            n = cls._dll.EcState_GetTransitionPath(frm & 0xFFFF, to & 0xFFFF, arr, capacity)
            if n < 0:
                return []
            return [int(arr[i]) for i in range(min(n, capacity))]
        except Exception:
            return []

    @classmethod
    def state_is_bootstrap_required(cls, state: int) -> bool:
        """目标状态是否要求经由 BOOT"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.EcState_IsBootstrapRequired(state & 0xFFFF))
        except Exception:
            return False

    @classmethod
    def state_get_name(cls, state: int) -> str:
        """状态中文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcState_GetName(state & 0xFFFF))
        except Exception:
            return ""

    @classmethod
    def state_get_name_en(cls, state: int) -> str:
        """状态英文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcState_GetNameEn(state & 0xFFFF))
        except Exception:
            return ""

    @classmethod
    def state_has_error_ack(cls, state: int) -> bool:
        """状态字节是否带 Error/Ack 位 (bit4)"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.EcState_HasErrorAck(state & 0xFFFF))
        except Exception:
            return False

    @classmethod
    def state_strip_error_ack(cls, state: int) -> int:
        """剥离 Error/Ack 位, 返回基础状态"""
        if not cls._ok():
            return state & 0x0F
        try:
            return int(cls._dll.EcState_StripErrorAck(state & 0xFFFF))
        except Exception:
            return state & 0x0F

    # ==================================================================
    # PDO Codec / 端口拓扑 (ec_pdo_codec.h) - 15
    # ==================================================================

    @classmethod
    def pdo_data_type_bit_size(cls, dt: int) -> int:
        """数据类型位宽 (BOOL=1/SINT=8/INT=16/.../REAL64=64)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EcPdoCodec_DataTypeBitSize(int(dt)))
        except Exception:
            return 0

    @classmethod
    def pdo_data_type_name(cls, dt: int) -> str:
        """数据类型名称"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcPdoCodec_DataTypeName(int(dt)))
        except Exception:
            return ""

    @classmethod
    def pdo_extract_u64(cls, src: bytes, bit_offset: int, bit_length: int) -> Tuple[int, int]:
        """从字节流提取无符号整数. 返回 (rc, value), rc=0 成功"""
        if not cls._ok():
            return (-1, 0)
        try:
            buf = (c_ubyte * len(src)).from_buffer_copy(src)
            v = c_uint64(0)
            rc = cls._dll.EcPdoCodec_ExtractU64(buf, len(src),
                                                int(bit_offset), int(bit_length), byref(v))
            return (int(rc), int(v.value))
        except Exception:
            return (-1, 0)

    @classmethod
    def pdo_extract_i64(cls, src: bytes, bit_offset: int, bit_length: int) -> Tuple[int, int]:
        """从字节流提取有符号整数"""
        if not cls._ok():
            return (-1, 0)
        try:
            buf = (c_ubyte * len(src)).from_buffer_copy(src)
            v = c_int64(0)
            rc = cls._dll.EcPdoCodec_ExtractI64(buf, len(src),
                                                int(bit_offset), int(bit_length), byref(v))
            return (int(rc), int(v.value))
        except Exception:
            return (-1, 0)

    @classmethod
    def pdo_insert_u64(cls, dst: bytearray, bit_offset: int, bit_length: int, value: int) -> int:
        """向字节流插入无符号整数. dst 会被原地修改, 返回 rc"""
        if not cls._ok():
            return -1
        try:
            buf = (c_ubyte * len(dst)).from_buffer(dst)
            rc = cls._dll.EcPdoCodec_InsertU64(buf, len(dst),
                                               int(bit_offset), int(bit_length), c_uint64(value))
            return int(rc)
        except Exception:
            return -1

    @classmethod
    def pdo_insert_i64(cls, dst: bytearray, bit_offset: int, bit_length: int, value: int) -> int:
        """向字节流插入有符号整数"""
        if not cls._ok():
            return -1
        try:
            buf = (c_ubyte * len(dst)).from_buffer(dst)
            rc = cls._dll.EcPdoCodec_InsertI64(buf, len(dst),
                                               int(bit_offset), int(bit_length), c_int64(value))
            return int(rc)
        except Exception:
            return -1

    @classmethod
    def pdo_extract_real32(cls, src: bytes, bit_offset: int) -> Tuple[int, float]:
        """提取 32 位浮点"""
        if not cls._ok():
            return (-1, 0.0)
        try:
            buf = (c_ubyte * len(src)).from_buffer_copy(src)
            v = c_float(0.0)
            rc = cls._dll.EcPdoCodec_ExtractReal32(buf, len(src), int(bit_offset), byref(v))
            return (int(rc), float(v.value))
        except Exception:
            return (-1, 0.0)

    @classmethod
    def pdo_extract_real64(cls, src: bytes, bit_offset: int) -> Tuple[int, float]:
        """提取 64 位浮点"""
        if not cls._ok():
            return (-1, 0.0)
        try:
            buf = (c_ubyte * len(src)).from_buffer_copy(src)
            v = c_double(0.0)
            rc = cls._dll.EcPdoCodec_ExtractReal64(buf, len(src), int(bit_offset), byref(v))
            return (int(rc), float(v.value))
        except Exception:
            return (-1, 0.0)

    @classmethod
    def pdo_insert_real32(cls, dst: bytearray, bit_offset: int, value: float) -> int:
        """插入 32 位浮点"""
        if not cls._ok():
            return -1
        try:
            buf = (c_ubyte * len(dst)).from_buffer(dst)
            rc = cls._dll.EcPdoCodec_InsertReal32(buf, len(dst), int(bit_offset), c_float(value))
            return int(rc)
        except Exception:
            return -1

    @classmethod
    def pdo_insert_real64(cls, dst: bytearray, bit_offset: int, value: float) -> int:
        """插入 64 位浮点"""
        if not cls._ok():
            return -1
        try:
            buf = (c_ubyte * len(dst)).from_buffer(dst)
            rc = cls._dll.EcPdoCodec_InsertReal64(buf, len(dst), int(bit_offset), c_double(value))
            return int(rc)
        except Exception:
            return -1

    @classmethod
    def pdo_count_active_ports(cls, active_ports: int) -> int:
        """活跃端口数 (active_ports 为 ESC 0x0110 ALSTATUSCODE.活跃端口位)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EcPdoCodec_CountActivePorts(int(active_ports) & 0xFF))
        except Exception:
            return 0

    @classmethod
    def pdo_get_topology(cls, active_ports: int) -> int:
        """获取拓扑枚举 (Line/Branch/Cross/...)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EcPdoCodec_GetTopology(int(active_ports) & 0xFF))
        except Exception:
            return 0

    @classmethod
    def pdo_topology_name(cls, topo: int) -> str:
        """拓扑中文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcPdoCodec_GetTopologyName(int(topo)))
        except Exception:
            return ""

    @classmethod
    def pdo_topology_name_en(cls, topo: int) -> str:
        """拓扑英文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcPdoCodec_GetTopologyNameEn(int(topo)))
        except Exception:
            return ""

    @classmethod
    def pdo_is_port_active(cls, active_ports: int, port: int) -> bool:
        """指定端口是否激活"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.EcPdoCodec_IsPortActive(int(active_ports) & 0xFF, int(port)))
        except Exception:
            return False

    # ==================================================================
    # CiA402 Modes / Homing (ec_cia402_modes.h) - 13
    # ==================================================================

    @classmethod
    def cia402_mode_to_supported_bit(cls, mode: int) -> int:
        """模式 -> 0x6502 SupportedDriveModes 位偏移"""
        if not cls._ok():
            return -1
        try:
            return int(cls._dll.CiA402Modes_ModeToSupportedBit(c_byte(mode)))
        except Exception:
            return -1

    @classmethod
    def cia402_is_mode_supported_in_mask(cls, mask: int, mode: int) -> bool:
        """0x6502 mask 中是否包含该模式"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.CiA402Modes_IsModeSupportedInMask(
                c_uint(mask & 0xFFFFFFFF), c_byte(mode)))
        except Exception:
            return False

    @classmethod
    def cia402_expand_supported_mask(cls, mask: int, capacity: int = 32) -> List[int]:
        """展开 0x6502 mask 为模式列表"""
        if not cls._ok():
            return []
        try:
            arr = (c_byte * capacity)()
            n = cls._dll.CiA402Modes_ExpandSupportedMask(
                c_uint(mask & 0xFFFFFFFF), arr, capacity)
            if n < 0:
                return []
            return [int(arr[i]) for i in range(min(n, capacity))]
        except Exception:
            return []

    @classmethod
    def cia402_mode_name(cls, mode: int) -> str:
        """模式中文名 (例: PP/CSP/CSV)"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.CiA402Modes_GetModeName(c_byte(mode)))
        except Exception:
            return ""

    @classmethod
    def cia402_mode_name_en(cls, mode: int) -> str:
        """模式英文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.CiA402Modes_GetModeNameEn(c_byte(mode)))
        except Exception:
            return ""

    @classmethod
    def cia402_mode_description(cls, mode: int) -> str:
        """模式详细描述"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.CiA402Modes_GetModeDescription(c_byte(mode)))
        except Exception:
            return ""

    @classmethod
    def cia402_is_cyclic_sync_mode(cls, mode: int) -> bool:
        """是否周期同步模式 (CSP/CSV/CST)"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.CiA402Modes_IsCyclicSyncMode(c_byte(mode)))
        except Exception:
            return False

    @classmethod
    def cia402_requires_dc(cls, mode: int) -> bool:
        """该模式是否要求 DC 同步"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.CiA402Modes_RequiresDC(c_byte(mode)))
        except Exception:
            return False

    @classmethod
    def cia402_is_standard_homing_method(cls, method: int) -> bool:
        """是否标准回零方法 (CiA402 1..35)"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.CiA402Modes_IsStandardHomingMethod(c_byte(method)))
        except Exception:
            return False

    @classmethod
    def cia402_homing_method_name(cls, method: int) -> str:
        """回零方法名称"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.CiA402Modes_GetHomingMethodName(c_byte(method)))
        except Exception:
            return ""

    @classmethod
    def cia402_homing_trigger(cls, method: int) -> int:
        """回零触发源 (0=None, 1=Index, 2=LimitSw, 3=HomeSw, ...)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.CiA402Modes_GetHomingTrigger(c_byte(method)))
        except Exception:
            return 0

    @classmethod
    def cia402_homing_direction(cls, method: int) -> int:
        """回零方向 (-1=Negative, +1=Positive, 0=N/A)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.CiA402Modes_GetHomingDirection(c_byte(method)))
        except Exception:
            return 0

    @classmethod
    def cia402_list_standard_homing_methods(cls, capacity: int = 64) -> List[int]:
        """枚举所有标准回零方法编号"""
        if not cls._ok():
            return []
        try:
            arr = (c_byte * capacity)()
            n = cls._dll.CiA402Modes_ListStandardHomingMethods(arr, capacity)
            if n < 0:
                return []
            return [int(arr[i]) for i in range(min(n, capacity))]
        except Exception:
            return []

    # ==================================================================
    # Mailbox / SoE (ec_mailbox_codes.h) - 5
    # ==================================================================

    @classmethod
    def mailbox_type_name(cls, mbx_type: int) -> str:
        """Mailbox 类型中文名 (CoE/SoE/EoE/FoE/VoE/AoE)"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcMailbox_GetTypeName(mbx_type & 0xFFFF))
        except Exception:
            return ""

    @classmethod
    def mailbox_type_name_en(cls, mbx_type: int) -> str:
        """Mailbox 类型英文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcMailbox_GetTypeNameEn(mbx_type & 0xFFFF))
        except Exception:
            return ""

    @classmethod
    def mailbox_error_description(cls, err_code: int) -> str:
        """Mailbox 错误码描述"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcMailbox_GetErrorDescription(err_code & 0xFFFF))
        except Exception:
            return ""

    @classmethod
    def mailbox_next_counter(cls, current: int) -> int:
        """Mailbox 计数器递增 (1..7 循环)"""
        if not cls._ok():
            return ((current + 1) & 0x07) or 1
        try:
            return int(cls._dll.EcMailbox_NextCounter(int(current) & 0xFF))
        except Exception:
            return ((current + 1) & 0x07) or 1

    @classmethod
    def soe_error_description(cls, soe_error: int) -> str:
        """SoE 错误码描述"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcSoE_GetErrorDescription(soe_error & 0xFFFF))
        except Exception:
            return ""

    # ==================================================================
    # SII Parser (ec_sii_parser.h) - 19
    # ==================================================================

    @staticmethod
    def _to_buf(data: bytes):
        return (c_ubyte * len(data)).from_buffer_copy(data)

    @classmethod
    def sii_find_category(cls, sii_data: bytes, cat_type: int) -> Tuple[int, int]:
        """查找指定 SII 类别. 返回 (offset_words, size_bytes), offset<0 表示未找到"""
        if not cls._ok():
            return (-1, 0)
        try:
            buf = cls._to_buf(sii_data)
            size = c_int(0)
            off = cls._dll.EcSii_FindCategory(buf, len(sii_data),
                                              cat_type & 0xFFFF, byref(size))
            return (int(off), int(size.value))
        except Exception:
            return (-1, 0)

    @classmethod
    def sii_enumerate_categories(cls, sii_data: bytes, capacity: int = 64) -> List[int]:
        """枚举 SII 中所有类别 ID"""
        if not cls._ok():
            return []
        try:
            buf = cls._to_buf(sii_data)
            arr = (c_uint16 * capacity)()
            n = cls._dll.EcSii_EnumerateCategories(buf, len(sii_data), arr, capacity)
            if n < 0:
                return []
            return [int(arr[i]) for i in range(min(n, capacity))]
        except Exception:
            return []

    @classmethod
    def sii_get_string_by_index(cls, cat_data: bytes, idx: int, buf_size: int = 256) -> str:
        """从 STRINGS (10) 类别按索引取字符串 (idx 从 1 起)"""
        if not cls._ok():
            return ""
        try:
            buf_in = cls._to_buf(cat_data)
            out = (c_ubyte * buf_size)()
            n = cls._dll.EcSii_GetStringByIndex(buf_in, len(cat_data),
                                                int(idx), out, buf_size)
            if n <= 0:
                return ""
            raw = bytes(out[:min(n, buf_size)]).split(b'\x00', 1)[0]
            return raw.decode("utf-8", errors="replace")
        except Exception:
            return ""

    @classmethod
    def sii_get_string_count(cls, cat_data: bytes) -> int:
        """STRINGS 类别字符串数量"""
        if not cls._ok():
            return 0
        try:
            buf = cls._to_buf(cat_data)
            return int(cls._dll.EcSii_GetStringCount(buf, len(cat_data)))
        except Exception:
            return 0

    @classmethod
    def sii_get_vendor_id(cls, sii_data: bytes) -> int:
        """SII 0x0008 Vendor ID"""
        if not cls._ok():
            return 0
        try:
            buf = cls._to_buf(sii_data)
            return int(cls._dll.EcSii_GetVendorId(buf, len(sii_data)))
        except Exception:
            return 0

    @classmethod
    def sii_get_product_code(cls, sii_data: bytes) -> int:
        """SII 0x000A Product Code"""
        if not cls._ok():
            return 0
        try:
            buf = cls._to_buf(sii_data)
            return int(cls._dll.EcSii_GetProductCode(buf, len(sii_data)))
        except Exception:
            return 0

    @classmethod
    def sii_get_revision(cls, sii_data: bytes) -> int:
        """SII 0x000C Revision Number"""
        if not cls._ok():
            return 0
        try:
            buf = cls._to_buf(sii_data)
            return int(cls._dll.EcSii_GetRevision(buf, len(sii_data)))
        except Exception:
            return 0

    @classmethod
    def sii_get_serial_number(cls, sii_data: bytes) -> int:
        """SII 0x000E Serial Number"""
        if not cls._ok():
            return 0
        try:
            buf = cls._to_buf(sii_data)
            return int(cls._dll.EcSii_GetSerialNumber(buf, len(sii_data)))
        except Exception:
            return 0

    @classmethod
    def sii_get_configured_alias(cls, sii_data: bytes) -> int:
        """SII 0x0004 Configured Station Alias"""
        if not cls._ok():
            return 0
        try:
            buf = cls._to_buf(sii_data)
            return int(cls._dll.EcSii_GetConfiguredAlias(buf, len(sii_data)))
        except Exception:
            return 0

    # CoE Details (位字段, 0x0040)
    @classmethod
    def sii_coe_enabled(cls, coe_details: int) -> bool:
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_CoeEnabled(int(coe_details) & 0xFF))
        except Exception: return False

    @classmethod
    def sii_coe_sdo_info(cls, coe_details: int) -> bool:
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_CoeSdoInfo(int(coe_details) & 0xFF))
        except Exception: return False

    @classmethod
    def sii_coe_pdo_assign(cls, coe_details: int) -> bool:
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_CoePdoAssign(int(coe_details) & 0xFF))
        except Exception: return False

    @classmethod
    def sii_coe_pdo_config(cls, coe_details: int) -> bool:
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_CoePdoConfig(int(coe_details) & 0xFF))
        except Exception: return False

    @classmethod
    def sii_coe_upload_at_startup(cls, coe_details: int) -> bool:
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_CoeUploadAtStartup(int(coe_details) & 0xFF))
        except Exception: return False

    @classmethod
    def sii_coe_complete_access(cls, coe_details: int) -> bool:
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_CoeCompleteAccess(int(coe_details) & 0xFF))
        except Exception: return False

    @classmethod
    def sii_foe_enabled(cls, foe_details: int) -> bool:
        """FoE 是否使能 (SII 0x0041)"""
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_FoeEnabled(int(foe_details) & 0xFF))
        except Exception: return False

    @classmethod
    def sii_eoe_enabled(cls, eoe_details: int) -> bool:
        """EoE 是否使能 (SII 0x0042)"""
        if not cls._ok(): return False
        try: return bool(cls._dll.EcSii_EoeEnabled(int(eoe_details) & 0xFF))
        except Exception: return False

    # ==================================================================
    # Coupler ID (ec_coupler_id.h) - 6
    # ==================================================================

    @classmethod
    def coupler_detect_device_type(cls, vendor_id: int, product_code: int) -> int:
        """检测设备类型 (耦合器/终端/驱动器/编码器/...)"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EcCouplerId_DetectDeviceType(
                vendor_id & 0xFFFFFFFF, product_code & 0xFFFFFFFF))
        except Exception:
            return 0

    @classmethod
    def coupler_is_coupler(cls, vendor_id: int, product_code: int) -> bool:
        """是否为耦合器 (EK1100/EK1110/...)"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.EcCouplerId_IsCoupler(
                vendor_id & 0xFFFFFFFF, product_code & 0xFFFFFFFF))
        except Exception:
            return False

    @classmethod
    def coupler_is_terminal(cls, vendor_id: int, product_code: int) -> bool:
        """是否为终端模块 (EL/EP 系列)"""
        if not cls._ok():
            return False
        try:
            return bool(cls._dll.EcCouplerId_IsTerminal(
                vendor_id & 0xFFFFFFFF, product_code & 0xFFFFFFFF))
        except Exception:
            return False

    @classmethod
    def coupler_vendor_name(cls, vendor_id: int) -> str:
        """厂商中文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcCouplerId_GetVendorName(vendor_id & 0xFFFFFFFF))
        except Exception:
            return ""

    @classmethod
    def coupler_vendor_name_en(cls, vendor_id: int) -> str:
        """厂商英文名"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcCouplerId_GetVendorNameEn(vendor_id & 0xFFFFFFFF))
        except Exception:
            return ""

    @classmethod
    def coupler_device_type_name(cls, type_code: int) -> str:
        """设备类型名称"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcCouplerId_GetDeviceTypeName(int(type_code)))
        except Exception:
            return ""

    @classmethod
    def coupler_get_model(cls, vendor_id: int, product_code: int) -> str:
        """耦合器型号 (vendor_id + product_code → 型号字符串)"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcCouplerId_GetCouplerModel(
                vendor_id & 0xFFFFFFFF, product_code & 0xFFFFFFFF))
        except Exception:
            return ""

    @classmethod
    def coupler_entry_count(cls) -> int:
        """耦合器/终端数据库条目总数"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EcCouplerId_GetEntryCount())
        except Exception:
            return 0

    @classmethod
    def coupler_vendor_count(cls) -> int:
        """已注册厂商数"""
        if not cls._ok():
            return 0
        try:
            return int(cls._dll.EcCouplerId_GetVendorCount())
        except Exception:
            return 0

    # ==================================================================
    # Diag Strings (ec_diag_strings.h) - 4
    # ==================================================================

    @classmethod
    def diag_topology_description(cls, topo: int) -> str:
        """诊断拓扑类型描述"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcDiagStrings_TopologyDescription(int(topo) & 0xFF))
        except Exception:
            return ""

    @classmethod
    def diag_timing_mode(cls, mode: int) -> str:
        """诊断时序模式描述"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcDiagStrings_TimingMode(int(mode) & 0xFFFFFFFF))
        except Exception:
            return ""

    @classmethod
    def diag_breakpoint_type(cls, bp: int) -> str:
        """诊断断点类型描述"""
        if not cls._ok():
            return ""
        try:
            return _decode(cls._dll.EcDiagStrings_BreakpointType(int(bp) & 0xFF))
        except Exception:
            return ""

    @classmethod
    def diag_format_breakpoint(cls, slave_idx: int, port: int, bp: int,
                               buf_size: int = 256) -> str:
        """格式化断点为可读描述 (slave_idx + port + 类型)"""
        if not cls._ok():
            return ""
        try:
            buf = (c_ubyte * buf_size)()
            cls._dll.EcDiagStrings_FormatBreakpoint(
                slave_idx & 0xFFFF, int(port) & 0xFF, int(bp) & 0xFF,
                buf, buf_size)
            raw = bytes(buf).split(b'\x00', 1)[0]
            return raw.decode("utf-8", errors="replace")
        except Exception:
            return ""


__all__ = ["ProtocolCodes"]
