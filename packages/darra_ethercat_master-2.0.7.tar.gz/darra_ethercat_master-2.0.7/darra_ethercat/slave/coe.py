# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/CoE.cs
CoE (CANopen over EtherCAT) 高级功能模块

包含:
- EcDataType: CoE 数据类型枚举
- ObjAccess / CoEObjectAccess: 对象访问权限标志
- ObjectEntry: 子索引条目 (类型化读写、访问权限检查)
- ObjectDictionary: 对象字典索引
- OEDictionary: ObjectEntry 的类字典容器
- ODList: 完整 OD 树遍历
- CoE_AccessDeniedException: 访问权限异常
- DiagnosticMessage: ETG.1510 诊断消息
"""

import asyncio
import ctypes
import struct
import threading
from concurrent.futures import ThreadPoolExecutor
from ctypes import c_int, c_uint, c_ushort, c_void_p, byref
from enum import IntEnum, IntFlag
from typing import Any, Dict, Iterator, List, Optional, Tuple

from ..utils.dll import DarraCoreDLL, EcMbxStatsT
from ..data.types import SDOError  # noqa: F401 - 重导出供用户使用
from .core import CoE
from ..abstractions import IMailboxProtocol, MailboxStatistics
from ..utils.help import convert_byte_array_to_string  # 多编码兜底解码 (UTF-8/ASCII/Latin-1)


# =============================================================================
# CoE 能力检测 (对齐 C# CoEInstance.IsSupported)
# =============================================================================
# 通过 DLL.GetSlaveMailboxProto 读 SII mbx_proto bit 2 (ECT_MBXPROT_COE = 0x04)
# 判断从站是否支持 CoE 邮箱. DLL 调用失败时保守返回 True (未知能力视为支持).

def _coe_is_supported(self) -> bool:
    """
    从站是否支持 CoE 邮箱协议 (对齐 C# CoEInstance.IsSupported).

    读取 SII mbx_proto 字段 bit 2 (ECT_MBXPROT_COE = 0x04) 判断支持情况.
    DLL 调用失败或 GetSlaveMailboxProto 不可用时保守返回 True.
    """
    try:
        mbx_proto = self._dll.GetSlaveMailboxProto(self._mi, self._si)
        return (mbx_proto & 0x04) != 0
    except Exception:
        return True


# 在 CoE 类上挂载 is_supported 属性 (不修改 core.py, 通过模块导入时注入)
CoE.is_supported = property(_coe_is_supported)


# =============================================================================
# last_sdo_error — Python 端缓存 abort code (托管实装, 对齐 Java getLastSdoError)
# =============================================================================
# 基础 CoE.last_sdo_error 属性已在 core.py 实现 (sdo_read/sdo_write 失败时
# 缓存 SDO Abort Code). 这里以 Java 的 FFI-then-fallback 模式覆盖一次:
#   1. 优先调 DLL.GetLastSdoError (DLL 端 thread-local abort, 跨调用线程精确)
#   2. DLL 未导出 → AttributeError, fallback 到 core.py 的 _last_sdo_error 缓存
# 各语言惯用法: Java 用 try/catch UnsatisfiedLinkError; Python 用 hasattr +
# 异常吞噬, 保守不破坏现有 sdo_read/sdo_write 错误流.
# DLL 端补齐 GetLastSdoError 后, 上层无需改动即可获得更精确的 thread-local abort.

def _coe_last_sdo_error_with_ffi(self):
    """
    最后一次 SDO 操作的错误码 (FFI-then-fallback, 对齐 Java getLastSdoError).

    优先尝试 DLL 端 thread-local abort (DLL.GetLastSdoError), DLL 未导出时
    fallback 到 core.py 的 _last_sdo_error 缓存. 保证至少返回缓存值, 不会
    因 DLL 缺失抛异常.
    """
    # 优先尝试 DLL FFI (Python utils/dll.py 当前未导出, 此处保留对齐入口)
    try:
        fn = getattr(self._dll, 'GetLastSdoError', None)
        if fn is not None:
            native_code = int(fn(self._mi, self._si))
            if native_code != 0:
                try:
                    return SDOError(native_code & 0xFFFFFFFF)
                except (ValueError, KeyError):
                    return SDOError.GENERAL_ERROR
    except Exception:
        pass
    # Fallback: 走 core.py sdo_read/sdo_write 设置的本实例缓存
    return getattr(self, '_last_sdo_error', SDOError.NO_ERROR)


# 覆盖基础 CoE.last_sdo_error 属性 (保留 setter 语义不变)
CoE.last_sdo_error = property(_coe_last_sdo_error_with_ffi)


# =============================================================================
# IMailboxProtocol 接口实现 (对齐 C# IMailboxProtocol)
# =============================================================================
# 通过模块导入时向 CoE 类注入 protocol_type / protocol_name /
# statistics / reset_statistics 属性与方法, 并用 ABC register() 把 CoE
# 注册为 IMailboxProtocol 的虚拟子类, 支持 isinstance 检查.

_COE_PROTOCOL_TYPE = 0x03  # ECT_MBXT_COE


def _coe_protocol_type(self) -> int:
    return _COE_PROTOCOL_TYPE


def _coe_protocol_name(self) -> str:
    return "CoE"


def _coe_statistics(self) -> MailboxStatistics:
    """读取 CoE 邮箱统计快照 (DLL 未导出时返回空)."""
    try:
        stats = EcMbxStatsT()
        rc = self._dll.mbx_get_stats_by_master(
            self._mi, self._si, _COE_PROTOCOL_TYPE, ctypes.byref(stats)
        )
        if rc == 1:  # SUCCESS
            avg = (stats.total_latency_us / stats.total_received
                   if stats.total_received > 0 else 0.0)
            t = None
            if stats.last_error_time_us > 0:
                from datetime import datetime, timezone
                t = datetime.fromtimestamp(
                    stats.last_error_time_us / 1_000_000, tz=timezone.utc
                )
            return MailboxStatistics(
                total_sent=stats.total_sent,
                total_received=stats.total_received,
                total_timeout=stats.total_timeout,
                total_mailbox_error=stats.total_mbx_error,
                total_protocol_error=stats.total_proto_error,
                total_cancelled=stats.total_cancelled,
                last_error_code=stats.last_error_code,
                last_error_time=t,
                average_latency_us=avg,
            )
    except Exception:
        pass
    return MailboxStatistics.empty()


def _coe_reset_statistics(self) -> None:
    """重置 CoE 邮箱统计 (DLL 未导出时静默忽略)."""
    try:
        self._dll.mbx_reset_stats_by_master(
            self._mi, self._si, _COE_PROTOCOL_TYPE
        )
    except Exception:
        pass


CoE.protocol_type = property(_coe_protocol_type)
CoE.protocol_name = property(_coe_protocol_name)
CoE.statistics = property(_coe_statistics)
CoE.reset_statistics = _coe_reset_statistics

# 虚拟子类注册: isinstance(coe, IMailboxProtocol) == True
IMailboxProtocol.register(CoE)


# =============================================================================
# 异步支持 (asyncio) — 对齐 C# CoEInstance 的 *Async 方法
# =============================================================================
# 采用 loop.run_in_executor + 模块级共享 ThreadPoolExecutor 策略,
# 把同步的 DLL 调用包装成 awaitable. 每个协议模块拥有独立线程池,
# 防止 CoE 的长 SDO 阻塞 FoE 的固件升级。

_coe_async_executor: Optional[ThreadPoolExecutor] = None
_coe_executor_lock = threading.Lock()


def _get_coe_executor() -> ThreadPoolExecutor:
    """懒创建 CoE 协议专用线程池 (对齐 C# ThreadPool 分离策略)"""
    global _coe_async_executor
    if _coe_async_executor is None:
        with _coe_executor_lock:
            if _coe_async_executor is None:
                _coe_async_executor = ThreadPoolExecutor(
                    max_workers=8, thread_name_prefix="darra-coe-async"
                )
    return _coe_async_executor


def shutdown_coe_async_executor(wait: bool = True) -> None:
    """关闭 CoE 异步线程池 (程序退出前调用, 释放后台线程)"""
    global _coe_async_executor
    with _coe_executor_lock:
        if _coe_async_executor is not None:
            _coe_async_executor.shutdown(wait=wait)
            _coe_async_executor = None


async def _run_coe_async(func, *args, timeout_ms: Optional[int] = None):
    """
    通用异步执行辅助: 在共享线程池中跑同步方法, 支持超时取消语义。

    注意: asyncio.CancelledError 或 wait_for 超时只能让 await 点返回,
    底层 DLL 的同步调用**无法真正中断**, 线程会继续跑到函数结束。
    这是 run_in_executor 的固有限制, 与 C# async 调用不可取消的 legacy 方法一致。
    """
    loop = asyncio.get_event_loop()
    fut = loop.run_in_executor(_get_coe_executor(), func, *args)
    if timeout_ms and timeout_ms > 0:
        return await asyncio.wait_for(fut, timeout=timeout_ms / 1000.0)
    return await fut


# =============================================================================
# CoE 数据类型枚举
# =============================================================================

class EcDataType(IntEnum):
    """CANopen / CoE 对象字典数据类型 (ETG.1000.6 表格)"""
    UNKNOWN        = 0x0000  # 未知类型
    BOOLEAN        = 0x0001  # 布尔型
    INTEGER8       = 0x0002  # 有符号 8 位整数
    INTEGER16      = 0x0003  # 有符号 16 位整数
    INTEGER32      = 0x0004  # 有符号 32 位整数
    UNSIGNED8      = 0x0005  # 无符号 8 位整数
    UNSIGNED16     = 0x0006  # 无符号 16 位整数
    UNSIGNED32     = 0x0007  # 无符号 32 位整数
    REAL32         = 0x0008  # 32 位浮点数
    VISIBLE_STRING = 0x0009  # 可见字符串
    OCTET_STRING   = 0x000A  # 字节串
    UNICODE_STRING = 0x000B  # Unicode 字符串
    TIME_OF_DAY    = 0x000C  # 日期时间
    TIME_DIFF      = 0x000D  # 时间差
    DOMAIN         = 0x000F  # 域对象
    INTEGER24      = 0x0010  # 有符号 24 位整数
    REAL64         = 0x0011  # 64 位浮点数
    INTEGER40      = 0x0012  # 有符号 40 位整数
    INTEGER48      = 0x0013  # 有符号 48 位整数
    INTEGER56      = 0x0014  # 有符号 56 位整数
    INTEGER64      = 0x0015  # 有符号 64 位整数
    UNSIGNED24     = 0x0016  # 无符号 24 位整数
    UNSIGNED40     = 0x0018  # 无符号 40 位整数
    UNSIGNED48     = 0x0019  # 无符号 48 位整数
    UNSIGNED56     = 0x001A  # 无符号 56 位整数
    UNSIGNED64     = 0x001B  # 无符号 64 位整数
    GUID           = 0x001D  # GUID
    BYTE           = 0x001E  # 字节
    WORD           = 0x001F  # 字 (16 位)
    DWORD          = 0x0020  # 双字 (32 位)
    BIT1           = 0x0030  # 1 位
    BIT2           = 0x0031  # 2 位
    BIT3           = 0x0032  # 3 位
    BIT4           = 0x0033  # 4 位
    BIT8           = 0x0037  # 8 位
    PDOMAPPING     = 0x0021  # PDO 映射参数
    IDENTITY       = 0x0023  # 身份对象
    COMMANDPAR     = 0x0025  # 命令参数
    PDOPAR         = 0x0027  # PDO 参数

    @property
    def byte_size(self) -> int:
        """返回该类型对应的字节大小 (不确定返回 0)"""
        _size_map = {
            EcDataType.BOOLEAN: 1,
            EcDataType.INTEGER8: 1,   EcDataType.UNSIGNED8: 1,  EcDataType.BYTE: 1,
            EcDataType.INTEGER16: 2,  EcDataType.UNSIGNED16: 2, EcDataType.WORD: 2,
            EcDataType.INTEGER24: 3,  EcDataType.UNSIGNED24: 3,
            EcDataType.INTEGER32: 4,  EcDataType.UNSIGNED32: 4,
            EcDataType.REAL32: 4,     EcDataType.DWORD: 4,
            EcDataType.INTEGER40: 5,  EcDataType.UNSIGNED40: 5,
            EcDataType.INTEGER48: 6,  EcDataType.UNSIGNED48: 6,
            EcDataType.INTEGER56: 7,  EcDataType.UNSIGNED56: 7,
            EcDataType.INTEGER64: 8,  EcDataType.UNSIGNED64: 8,
            EcDataType.REAL64: 8,
        }
        return _size_map.get(self, 0)

    @property
    def struct_fmt(self) -> Optional[str]:
        """返回 struct 格式字符串 (不支持的类型返回 None)"""
        _fmt_map = {
            EcDataType.BOOLEAN:   '<B',
            EcDataType.INTEGER8:  '<b',  EcDataType.UNSIGNED8:  '<B',
            EcDataType.INTEGER16: '<h',  EcDataType.UNSIGNED16: '<H',
            EcDataType.INTEGER32: '<i',  EcDataType.UNSIGNED32: '<I',
            EcDataType.REAL32:    '<f',
            EcDataType.INTEGER64: '<q',  EcDataType.UNSIGNED64: '<Q',
            EcDataType.REAL64:    '<d',
        }
        return _fmt_map.get(self)


# =============================================================================
# 对象访问权限标志 (对齐 C# CoEObjectAccess)
# =============================================================================

class ObjAccess(IntFlag):
    """CoE 对象访问权限标志 (ETG.1000.6 节 5.6.3.6)"""
    NONE      = 0x0000  # 无访问权限
    READ_PRE  = 0x0001  # PreOp 状态可读
    READ_SAFE = 0x0002  # SafeOp 状态可读
    READ_OP   = 0x0004  # OP 状态可读
    WRITE_PRE = 0x0008  # PreOp 状态可写
    WRITE_SAFE= 0x0010  # SafeOp 状态可写
    WRITE_OP  = 0x0020  # OP 状态可写
    MAPPABLE  = 0x0040  # 可映射到 PDO
    BACKUP    = 0x0080  # 备份参数 (存储在 EEPROM)
    SETTINGS  = 0x0100  # 配置参数

    # 组合标志
    READABLE  = READ_PRE | READ_SAFE | READ_OP    # 所有状态可读
    WRITABLE  = WRITE_PRE | WRITE_SAFE | WRITE_OP  # 所有状态可写

    @property
    def access_description(self) -> str:
        """
        获取访问权限的中文描述字符串
        对齐 C# GetAccessDescriptionChinese
        """
        can_read = bool(self & ObjAccess.READABLE)
        can_write = bool(self & ObjAccess.WRITABLE)
        if can_read and can_write:
            parts = []
            if self & ObjAccess.WRITE_PRE:
                parts.append("PreOP")
            if self & ObjAccess.WRITE_SAFE:
                parts.append("SafeOP")
            if self & ObjAccess.WRITE_OP:
                parts.append("OP")
            return f"读写({','.join(parts)}可写)" if parts else "读写"
        elif can_read:
            return "只读"
        elif can_write:
            parts = []
            if self & ObjAccess.WRITE_PRE:
                parts.append("PreOP")
            if self & ObjAccess.WRITE_SAFE:
                parts.append("SafeOP")
            if self & ObjAccess.WRITE_OP:
                parts.append("OP")
            return f"只写({','.join(parts)}可写)" if parts else "只写"
        return "无权限"


# 别名，与 C# CoEObjectAccess 对齐
CoEObjectAccess = ObjAccess


# =============================================================================
# CoE 访问权限异常 (对齐 C# CoE_AccessDeniedException)
# =============================================================================

class CoE_AccessDeniedException(Exception):
    """
    CoE 访问权限异常
    当尝试读取或写入不支持的操作时抛出
    """

    def __init__(self, index: int, sub_index: int, entry_name: str,
                 is_read_operation: bool, obj_access: int, message: str = ""):
        self.index = index
        self.sub_index = sub_index
        self.entry_name = entry_name
        self.is_read_operation = is_read_operation
        self.obj_access = obj_access

        if not message:
            operation = "读取" if is_read_operation else "写入"
            access_desc = ObjAccess(obj_access).access_description
            message = (f"对象条目 0x{index:04X}:{sub_index} ({entry_name}) "
                       f"不支持{operation}操作。访问权限: {access_desc}")
        super().__init__(message)

    @classmethod
    def create_with_custom_message(
        cls, index: int, sub_index: int, custom_message: str,
        is_read_operation: bool, obj_access: int
    ) -> 'CoE_AccessDeniedException':
        """创建带有自定义错误消息的异常实例 (对齐 C# CreateWithCustomMessage)"""
        return cls(index, sub_index, custom_message,
                   is_read_operation, obj_access, message=custom_message)


# =============================================================================
# 诊断消息 (对齐 C# DiagnosticMessage, ETG.1510)
# =============================================================================

class DiagnosticMessage:
    """ETG.1510 诊断消息"""

    def __init__(self, sub_index: int = 0, diag_code: int = 0,
                 flags: int = 0, text_index: int = 0,
                 raw_data: bytes = b''):
        self.sub_index = sub_index
        self.diag_code = diag_code
        self.flags = flags
        self.text_index = text_index
        self.raw_data = raw_data

    def __repr__(self) -> str:
        return f"Diag[{self.sub_index}]: Code=0x{self.diag_code:08X}, Flags=0x{self.flags:04X}"


# =============================================================================
# ObjectEntry (对齐 C# ObjectEntry)
# =============================================================================

class ObjectEntry:
    """
    CoE 对象字典中的子索引条目

    提供类型化读写接口, 访问权限检查, 优先通过 SDO 访问。
    """

    def __init__(self, coe: CoE, od_index: int, subindex: int,
                 data_type: EcDataType, bit_length: int,
                 obj_access: ObjAccess, name: str):
        """
        初始化对象条目

        参数:
            coe:        CoE 协议接口
            od_index:   对象字典索引
            subindex:   子索引
            data_type:  数据类型
            bit_length: 位长度
            obj_access: 访问权限
            name:       条目名称
        """
        self._coe = coe
        self._od_index = od_index
        self._subindex = subindex
        self._data_type = data_type
        self.bit_length = bit_length
        self._obj_access = obj_access
        self.name = name

    # ---- 属性 ----

    @property
    def od_index(self) -> int:
        """对象字典索引 (OD Index)，对齐 C# ODIndex"""
        return self._od_index

    # 别名
    ODIndex = od_index

    @property
    def index(self) -> int:
        """子索引 (SubIndex)"""
        return self._subindex

    @property
    def subindex(self) -> int:
        """子索引 (SubIndex)"""
        return self._subindex

    @property
    def data_type(self) -> EcDataType:
        """数据类型，对齐 C# Datatype / DataType"""
        return self._data_type

    # 别名
    Datatype = data_type
    DataType = data_type

    @property
    def byte_length(self) -> int:
        """字节长度 (向上取整)"""
        return (self.bit_length + 7) // 8

    @property
    def obj_access(self) -> ObjAccess:
        """对象访问权限 (ETG1000.6 Object Access)，对齐 C# ObjAccess"""
        return self._obj_access

    ObjAccess = obj_access

    # ---- 访问权限便捷属性 (对齐 C#) ----

    @property
    def can_read(self) -> bool:
        """是否有任何读取权限"""
        return bool(self._obj_access & ObjAccess.READABLE)

    @property
    def can_write(self) -> bool:
        """是否有任何写入权限"""
        return bool(self._obj_access & ObjAccess.WRITABLE)

    @property
    def is_read_only(self) -> bool:
        """是否为完全只读"""
        return self.can_read and not self.can_write

    @property
    def can_write_pre_op(self) -> bool:
        """PreOP 状态下是否可写"""
        return bool(self._obj_access & ObjAccess.WRITE_PRE)

    @property
    def can_write_safe_op(self) -> bool:
        """SafeOP 状态下是否可写 (包含 PreOP 继承)"""
        return bool(self._obj_access & (ObjAccess.WRITE_PRE | ObjAccess.WRITE_SAFE))

    @property
    def can_write_op(self) -> bool:
        """OP 状态下是否可写 (包含所有继承)"""
        return bool(self._obj_access & ObjAccess.WRITABLE)

    @property
    def access_description(self) -> str:
        """获取访问权限描述字符串，对齐 C# AccessDescription"""
        return self._obj_access.access_description

    # ---- SDO 原始读写 ----

    @property
    def bytes(self) -> bytes:
        """
        以字节数组形式读取参数值 (对齐 C# Bytes 属性)
        优先使用 Complete Access 模式，失败时自动回退
        """
        # 检查读取权限
        if not self.can_read:
            raise CoE_AccessDeniedException(
                self._od_index, self._subindex, self.name,
                True, int(self._obj_access))

        # 先尝试 Complete Access
        data = self._coe.sdo_read(self._od_index, self._subindex, complete_access=True)
        if data is not None and len(data) > 0:
            return data

        # 回退到普通模式
        data = self._coe.sdo_read(self._od_index, self._subindex, complete_access=False)
        return data if data else b''

    @bytes.setter
    def bytes(self, value: bytes):
        """写入原始字节 (对齐 C# Bytes setter)"""
        if not value:
            raise ValueError("写入数据不能为空")
        if not self.can_write:
            raise CoE_AccessDeniedException(
                self._od_index, self._subindex, self.name,
                False, int(self._obj_access))
        # 先尝试 Complete Access
        ok = self._coe.sdo_write(self._od_index, self._subindex, value, complete_access=True)
        if not ok:
            # 回退到普通模式
            ok = self._coe.sdo_write(self._od_index, self._subindex, value, complete_access=False)
        if not ok:
            raise CoE_AccessDeniedException.create_with_custom_message(
                self._od_index, self._subindex,
                f"写入 0x{self._od_index:04X}:{self._subindex} 失败",
                False, int(self._obj_access))

    Bytes = bytes  # 别名

    def _raw_read(self) -> Optional[bytes]:
        """通过 SDO 读取原始字节 (普通模式)"""
        return self._coe.sdo_read(self._od_index, self._subindex)

    def _raw_write(self, data: bytes) -> bool:
        """通过 SDO 写入原始字节"""
        return self._coe.sdo_write(self._od_index, self._subindex, data)

    def _unpack(self, fmt: str) -> Optional[Any]:
        """读取并按格式解包"""
        data = self._raw_read()
        if data is None:
            return None
        size = struct.calcsize(fmt)
        if len(data) < size:
            data = data.ljust(size, b'\x00')
        return struct.unpack(fmt, data[:size])[0]

    # ---- 类型化读取 ----

    def read_u8(self) -> Optional[int]:
        """读取无符号 8 位整数"""
        return self._unpack('<B')

    def read_u16(self) -> Optional[int]:
        """读取无符号 16 位整数"""
        return self._unpack('<H')

    def read_u32(self) -> Optional[int]:
        """读取无符号 32 位整数"""
        return self._unpack('<I')

    def read_u64(self) -> Optional[int]:
        """读取无符号 64 位整数"""
        return self._unpack('<Q')

    def read_i8(self) -> Optional[int]:
        """读取有符号 8 位整数"""
        return self._unpack('<b')

    def read_i16(self) -> Optional[int]:
        """读取有符号 16 位整数"""
        return self._unpack('<h')

    def read_i32(self) -> Optional[int]:
        """读取有符号 32 位整数"""
        return self._unpack('<i')

    def read_i64(self) -> Optional[int]:
        """读取有符号 64 位整数"""
        return self._unpack('<q')

    def read_f32(self) -> Optional[float]:
        """读取 32 位浮点数"""
        return self._unpack('<f')

    def read_f64(self) -> Optional[float]:
        """读取 64 位浮点数"""
        return self._unpack('<d')

    def read_string(self, encoding: str = 'utf-8') -> Optional[str]:
        """读取字符串 (自动去除末尾 NUL)"""
        data = self._raw_read()
        if data is None:
            return None
        return data.rstrip(b'\x00').decode(encoding, errors='replace')

    def read_typed(self) -> Optional[Any]:
        """根据数据类型自动解析并返回值"""
        fmt = self._data_type.struct_fmt
        if fmt is not None:
            return self._unpack(fmt)
        if self._data_type in (EcDataType.VISIBLE_STRING, EcDataType.UNICODE_STRING):
            return self.read_string()
        return self._raw_read()

    def get_value(self, target_type: type = None) -> Any:
        """
        获取值并转换为指定类型 (对齐 C# GetValue<T>)

        参数:
            target_type: 目标类型 (int, float, str, bool, bytes 等)，None 表示自动推断
        """
        raw = self.read_typed()
        if raw is None:
            return None
        if target_type is None:
            return raw
        try:
            return target_type(raw)
        except (TypeError, ValueError):
            return None

    # ---- 类型化写入 ----

    def write_u8(self, value: int) -> bool:
        """写入无符号 8 位整数"""
        return self._raw_write(struct.pack('<B', value))

    def write_u16(self, value: int) -> bool:
        """写入无符号 16 位整数"""
        return self._raw_write(struct.pack('<H', value))

    def write_u32(self, value: int) -> bool:
        """写入无符号 32 位整数"""
        return self._raw_write(struct.pack('<I', value))

    def write_u64(self, value: int) -> bool:
        """写入无符号 64 位整数"""
        return self._raw_write(struct.pack('<Q', value))

    def write_i8(self, value: int) -> bool:
        """写入有符号 8 位整数"""
        return self._raw_write(struct.pack('<b', value))

    def write_i16(self, value: int) -> bool:
        """写入有符号 16 位整数"""
        return self._raw_write(struct.pack('<h', value))

    def write_i32(self, value: int) -> bool:
        """写入有符号 32 位整数"""
        return self._raw_write(struct.pack('<i', value))

    def write_i64(self, value: int) -> bool:
        """写入有符号 64 位整数"""
        return self._raw_write(struct.pack('<q', value))

    def write_f32(self, value: float) -> bool:
        """写入 32 位浮点数"""
        return self._raw_write(struct.pack('<f', value))

    def write_f64(self, value: float) -> bool:
        """写入 64 位浮点数"""
        return self._raw_write(struct.pack('<d', value))

    def write_string(self, value: str, encoding: str = 'utf-8') -> bool:
        """写入字符串"""
        return self._raw_write(value.encode(encoding))

    # ---- 异步读写 (对齐 C# ObjectEntry *Async) ----

    async def read_bytes_async(self, timeout_ms: Optional[int] = None) -> bytes:
        """
        异步读取原始字节 (对齐 C# Bytes 属性的 *Async)

        参数:
            timeout_ms: 超时毫秒数, 触发 asyncio.TimeoutError
        返回:
            响应字节数组
        """
        def _do():
            return self.bytes  # type: ignore[attr-defined]
        return await _run_coe_async(_do, timeout_ms=timeout_ms)

    async def write_bytes_async(self, value: bytes,
                                timeout_ms: Optional[int] = None) -> None:
        """异步写入原始字节"""
        def _do():
            self.bytes = value  # type: ignore[misc]
        await _run_coe_async(_do, timeout_ms=timeout_ms)

    async def read_typed_async(self, timeout_ms: Optional[int] = None) -> Optional[Any]:
        """异步按数据类型解析读取"""
        return await _run_coe_async(self.read_typed, timeout_ms=timeout_ms)

    async def get_value_async(self, target_type: type = None,
                              timeout_ms: Optional[int] = None) -> Any:
        """异步读取并转换类型 (对齐 C# GetValueAsync<T>)"""
        return await _run_coe_async(self.get_value, target_type, timeout_ms=timeout_ms)

    def __str__(self) -> str:
        """字符串表示: OD索引:子索引 名称"""
        return f"OD[{self._od_index:#06x}:{self._subindex}] {self.name}"

    def __repr__(self) -> str:
        return (f"ObjectEntry(od=0x{self._od_index:04X}, sub={self._subindex}, "
                f"name={self.name!r}, type={self._data_type.name})")


# =============================================================================
# OEDictionary (对齐 C# OEDictionary)
# =============================================================================

class OEDictionary:
    """
    ObjectEntry 的类字典容器 (对齐 C# OEDictionary)

    支持按子索引访问、按名称查找、迭代
    """

    def __init__(self, entries: List[ObjectEntry]):
        self._entries = entries

    @property
    def count(self) -> int:
        """条目数量"""
        return len(self._entries)

    Count = count

    def __getitem__(self, key) -> ObjectEntry:
        """按子索引 (int) 或名称 (str) 获取条目"""
        if isinstance(key, int):
            for e in self._entries:
                if e.subindex == key:
                    return e
            raise KeyError(f"子索引 {key} 不存在")
        if isinstance(key, str):
            # 尝试解析为十六进制或十进制
            idx = self._try_parse_index(key)
            if idx is not None:
                return self[idx]
            for e in self._entries:
                if e.name and e.name.lower() == key.lower():
                    return e
            raise KeyError(f"名称 '{key}' 不存在")
        raise TypeError(f"不支持的索引类型: {type(key)}")

    def __contains__(self, key) -> bool:
        """检查子索引或名称是否存在 (对齐 C# ContainsKey)"""
        try:
            self[key]
            return True
        except (KeyError, TypeError):
            return False

    def contains_key(self, key) -> bool:
        """检查给定键是否存在 (对齐 C# ContainsKey)"""
        return key in self

    def get_by_position(self, position: int) -> ObjectEntry:
        """按列表位置获取 ObjectEntry (对齐 C# GetByPosition)"""
        if position < 0 or position >= len(self._entries):
            raise IndexError(f"位置 {position} 超出范围 (0-{len(self._entries) - 1})")
        return self._entries[position]

    def __len__(self) -> int:
        return len(self._entries)

    def __iter__(self) -> Iterator[ObjectEntry]:
        """迭代所有条目 (对齐 C# GetEnumerator)"""
        return iter(self._entries)

    @staticmethod
    def _try_parse_index(key: str) -> Optional[int]:
        """尝试将字符串解析为子索引"""
        try:
            if key.startswith('0x') or key.startswith('0X'):
                return int(key, 16)
            if len(key) <= 2 and all(c in '0123456789abcdefABCDEF' for c in key):
                return int(key, 16)
            return int(key)
        except ValueError:
            return None


# =============================================================================
# ObjectDictionary (对齐 C# ObjectDictionary)
# =============================================================================

class ObjectDictionary:
    """
    CoE 对象字典中的一个索引 (包含多个子索引条目)

    支持字典式按子索引访问:
        od[0x6041][0]   # 索引 0x6041 的子索引 0
    """

    def __init__(self, master_index: int, slave_index: int,
                 coe_instance: CoE = None):
        self._master_index = master_index
        self._slave_index = slave_index
        self._coe_instance = coe_instance
        self._oe_list: List[ObjectEntry] = []
        self.index: int = 0
        self.name: str = ""
        self.object_code: int = 0
        self.data_type: int = 0  # 原始 datatype 值
        self.max_sub: int = 0

    @property
    def oe_list(self) -> OEDictionary:
        """OEList 提供按子索引对 ObjectEntry 的类字典访问 (对齐 C# OEList)"""
        return OEDictionary(self._oe_list)

    OEList = oe_list

    @property
    def count(self) -> int:
        """子索引条目数量 (对齐 C# Count)"""
        return len(self._oe_list)

    Count = count

    @property
    def datatype(self) -> int:
        """主对象数据类型原始值 (对齐 C# Datatype)"""
        return self.data_type

    Datatype = datatype

    def __getitem__(self, key) -> ObjectEntry:
        """按子索引 (int) 或名称 (str) 获取条目"""
        return self.oe_list[key]

    def __contains__(self, key) -> bool:
        """检查子索引是否存在 (对齐 C# ContainsKey)"""
        return key in self.oe_list

    def contains_key(self, key) -> bool:
        """检查给定键是否存在 (对齐 C# ContainsKey)"""
        return key in self.oe_list

    def __len__(self) -> int:
        return len(self._oe_list)

    def __iter__(self) -> Iterator[ObjectEntry]:
        """按子索引顺序迭代所有条目"""
        return iter(self._oe_list)

    def add_entry(self, entry: ObjectEntry) -> None:
        """添加子索引条目"""
        self._oe_list.append(entry)

    def read_all(self) -> Dict[int, bytes]:
        """
        批量读取所有子索引的数据 (对齐 C# ReadAll)
        返回子索引到字节数据的字典映射
        """
        result = {}
        for entry in self._oe_list:
            try:
                data = entry.bytes
                if data and len(data) > 0:
                    result[entry.subindex] = data
            except Exception:
                pass  # 跳过读取失败的条目
        return result

    def copy(self) -> 'ObjectDictionary':
        """
        创建 ObjectDictionary 的缓存副本 (对齐 C# Copy)
        读取所有子索引的当前值并缓存
        """
        cp = ObjectDictionary(self._master_index, self._slave_index, self._coe_instance)
        cp.index = self.index
        cp.name = self.name
        cp.object_code = self.object_code
        cp.data_type = self.data_type
        cp.max_sub = self.max_sub

        for entry in self._oe_list:
            try:
                # 读取当前值
                cached_data = entry.bytes
            except Exception:
                cached_data = b''

            new_entry = ObjectEntry(
                entry._coe, entry.od_index, entry.subindex,
                entry.data_type, entry.bit_length, entry.obj_access, entry.name
            )
            # 通过一个标志标记为缓存模式 (简化实现)
            new_entry._cached_bytes = cached_data
            cp.add_entry(new_entry)

        return cp

    def sdo_write(self, data: bytes, sub_index: int = 0,
                  complete_access: bool = False) -> bool:
        """
        使用 SDO 协议写入数据 (对齐 C# SDOWrite)
        """
        if not data:
            return False
        return self._coe_instance.sdo_write(self.index, sub_index, data,
                                            complete_access=complete_access)

    @property
    def is_var(self) -> bool:
        """是否为 VAR 类型 (单值对象, ObjectCode=0x07)"""
        return self.object_code == 7

    @property
    def is_array(self) -> bool:
        """是否为 ARRAY 类型 (ObjectCode=0x08)"""
        return self.object_code == 8

    @property
    def is_record(self) -> bool:
        """是否为 RECORD 类型 (ObjectCode=0x09)"""
        return self.object_code == 9

    def __repr__(self) -> str:
        return (f"ObjectDictionary(index=0x{self.index:04X}, name={self.name!r}, "
                f"subs={len(self._oe_list)})")


# =============================================================================
# ODList (对齐 C# EcODList)
# =============================================================================

class ODList:
    """
    CoE 对象字典完整树

    通过 GetSlaveSDOList + GetSlavePointer_SDO_WithODList 加载从站 OD,
    提供字典式按索引访问和迭代。
    """

    # OD 列表内存布局偏移量
    _OD_OFFSET_SLAVE     = 0
    _OD_OFFSET_ENTRIES   = 2
    _OD_OFFSET_INDEX     = 4
    _OD_OFFSET_DATATYPE  = 2052
    _OD_OFFSET_OBJCODE   = 4100
    _OD_OFFSET_MAXSUB    = 5124
    _OD_OFFSET_NAME      = 6148
    _OD_NAME_SIZE        = 41

    # OE 列表内存布局偏移量
    _OE_OFFSET_ENTRIES   = 0
    _OE_OFFSET_VALUEINFO = 2
    _OE_OFFSET_DATATYPE  = 258
    _OE_OFFSET_BITLEN    = 770
    _OE_OFFSET_OBJACCESS = 1282
    _OE_OFFSET_NAME      = 1794
    _OE_NAME_SIZE        = 41

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 coe: CoE, auto_load: bool = True):
        """
        初始化 OD 列表

        参数:
            dll:          DLL 接口
            master_index: 主站索引
            slave_index:  从站索引
            coe:          CoE 协议接口
            auto_load:    是否自动加载
        """
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._coe = coe
        self._objects: Dict[int, ObjectDictionary] = {}
        self._full_list: List[ObjectDictionary] = []
        self._loaded = False
        self._loading = False

        if auto_load:
            self.load()

    @property
    def full_list(self) -> List[ObjectDictionary]:
        """返回完整对象列表 (对齐 C# FullList)"""
        return self._full_list

    def load(self) -> bool:
        """
        加载从站 OD 列表 (同步)

        返回:
            加载是否成功
        """
        self._objects.clear()
        self._full_list.clear()
        self._loaded = False
        od_ptr = None

        try:
            od_ptr = self._dll.GetSlaveSDOList(self._mi, self._si)
            if not od_ptr:
                return False

            # 读取条目数
            entries = ctypes.cast(od_ptr + self._OD_OFFSET_ENTRIES,
                                  ctypes.POINTER(c_ushort)).contents.value
            if entries == 0:
                return False  # finally 块会释放 od_ptr

            # 解析每个 OD 索引
            for i in range(min(entries, 1024)):
                idx = ctypes.cast(od_ptr + self._OD_OFFSET_INDEX + i * 2,
                                  ctypes.POINTER(c_ushort)).contents.value
                if idx == 0:
                    continue

                dt_raw = ctypes.cast(od_ptr + self._OD_OFFSET_DATATYPE + i * 2,
                                     ctypes.POINTER(c_ushort)).contents.value
                obj_code = ctypes.cast(od_ptr + self._OD_OFFSET_OBJCODE + i,
                                       ctypes.POINTER(ctypes.c_ubyte)).contents.value
                max_sub = ctypes.cast(od_ptr + self._OD_OFFSET_MAXSUB + i,
                                      ctypes.POINTER(ctypes.c_ubyte)).contents.value

                # 读取名称 (CoE OD 名: UTF-8 → ASCII → Latin-1 兜底, 与 C# Help.ConvertByteArrayToString 一致)
                name_offset = self._OD_OFFSET_NAME + i * self._OD_NAME_SIZE
                name_bytes = ctypes.string_at(od_ptr + name_offset, self._OD_NAME_SIZE)
                name = convert_byte_array_to_string(name_bytes)

                try:
                    dt = EcDataType(dt_raw)
                except ValueError:
                    dt = EcDataType.UNKNOWN

                od = ObjectDictionary(self._mi, self._si, self._coe)
                od.index = idx
                od.name = name
                od.object_code = obj_code
                od.data_type = dt_raw
                od.max_sub = max_sub

                # 加载子索引 (OE 列表)
                self._load_oe(od_ptr, i, idx, od)

                self._objects[idx] = od
                self._full_list.append(od)

            self._loaded = True
            return True

        except Exception:
            return False
        finally:
            if od_ptr:
                try:
                    self._dll.FreeMemory(od_ptr)
                except Exception:
                    pass

    def load_async(self) -> threading.Thread:
        """
        异步加载对象字典 (对齐 C# LoadODListAsync)
        返回后台线程对象，可检查 .is_alive() 判断是否完成
        """
        if self._loading:
            return None
        self._loading = True

        def _worker():
            try:
                self.load()
            finally:
                self._loading = False

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        return t

    async def load_awaitable(self, timeout_ms: Optional[int] = None) -> bool:
        """
        asyncio 风格的异步加载 (对齐 C# LoadODListAsync await 语义)

        参数:
            timeout_ms: 超时毫秒数 (None=无限等待)
        返回:
            加载是否成功
        异常:
            asyncio.TimeoutError: 超时
        """
        return await _run_coe_async(self.load, timeout_ms=timeout_ms)

    @property
    def is_loading(self) -> bool:
        """是否正在异步加载 (对齐 C# IsODListLoading)"""
        return self._loading

    def _load_oe(self, od_ptr, oe_index: int, od_index: int,
                 od: ObjectDictionary) -> None:
        """加载指定 OD 索引的子索引条目"""
        oe_ptr = None
        try:
            oe_ptr = self._dll.GetSlavePointer_SDO_WithODList(
                self._mi, self._si, oe_index, od_ptr
            )
            if not oe_ptr:
                return

            entries = ctypes.cast(oe_ptr + self._OE_OFFSET_ENTRIES,
                                  ctypes.POINTER(c_ushort)).contents.value

            for j in range(min(entries, 256)):
                dt_raw = ctypes.cast(oe_ptr + self._OE_OFFSET_DATATYPE + j * 2,
                                     ctypes.POINTER(c_ushort)).contents.value
                bit_len = ctypes.cast(oe_ptr + self._OE_OFFSET_BITLEN + j * 2,
                                      ctypes.POINTER(c_ushort)).contents.value
                access_raw = ctypes.cast(oe_ptr + self._OE_OFFSET_OBJACCESS + j * 2,
                                         ctypes.POINTER(c_ushort)).contents.value

                # 读取子索引名称 (CoE OE 名: UTF-8 → ASCII → Latin-1 兜底)
                name_offset = self._OE_OFFSET_NAME + j * self._OE_NAME_SIZE
                name_bytes = ctypes.string_at(oe_ptr + name_offset, self._OE_NAME_SIZE)
                name = convert_byte_array_to_string(name_bytes)

                try:
                    dt = EcDataType(dt_raw)
                except ValueError:
                    dt = EcDataType.UNKNOWN

                try:
                    access = ObjAccess(access_raw)
                except ValueError:
                    access = ObjAccess.NONE

                entry = ObjectEntry(self._coe, od_index, j, dt, bit_len, access, name)
                od.add_entry(entry)
        except Exception:
            pass
        finally:
            if oe_ptr:
                try:
                    self._dll.FreeMemory(oe_ptr)
                except Exception:
                    pass

    @property
    def loaded(self) -> bool:
        """是否已成功加载"""
        return self._loaded

    @property
    def count(self) -> int:
        """OD 对象数量 (对齐 C# Count)"""
        return len(self._full_list)

    Count = count

    def __getitem__(self, key) -> ObjectDictionary:
        """按 OD 索引 (int) 或名称 (str) 获取对象"""
        if isinstance(key, int):
            if key in self._objects:
                return self._objects[key]
            # 也支持位置索引
            if 0 <= key < len(self._full_list):
                return self._full_list[key]
            raise KeyError(f"OD 索引 0x{key:04X} 不存在")
        if isinstance(key, str):
            # 尝试解析为十六进制
            idx = self._try_parse_index(key)
            if idx is not None and idx in self._objects:
                return self._objects[idx]
            # 按名称查找
            for od in self._full_list:
                if od.name and od.name.lower() == key.lower():
                    return od
            raise KeyError(f"名称 '{key}' 不存在")
        raise TypeError(f"不支持的索引类型: {type(key)}")

    def __contains__(self, key) -> bool:
        """检查 OD 索引是否存在 (对齐 C# ContainsKey)"""
        try:
            self[key]
            return True
        except (KeyError, TypeError):
            return False

    def contains_key(self, key) -> bool:
        """检查给定键是否存在 (对齐 C# ContainsKey)"""
        return key in self

    def __len__(self) -> int:
        """返回 OD 索引数量"""
        return len(self._full_list)

    def __iter__(self) -> Iterator[ObjectDictionary]:
        """按索引排序迭代 (对齐 C# GetEnumerator, 返回 (index, od) 对)"""
        for od in self._full_list:
            yield od

    def items(self) -> Iterator[Tuple[int, ObjectDictionary]]:
        """返回 (index, ObjectDictionary) 对的迭代器"""
        for od in self._full_list:
            yield (od.index, od)

    def keys(self) -> List[int]:
        """返回所有 OD 索引列表 (已排序)"""
        return sorted(self._objects.keys())

    def get(self, index: int, default=None) -> Optional[ObjectDictionary]:
        """安全获取 OD 索引"""
        return self._objects.get(index, default)

    def copy(self) -> 'ODList':
        """
        创建 ODList 的缓存副本 (对齐 C# Copy)
        遍历所有对象并读取值
        """
        cp = ODList(self._dll, self._mi, self._si, self._coe, auto_load=False)
        for od in self._full_list:
            try:
                cached_od = od.copy()
                cp._objects[cached_od.index] = cached_od
                cp._full_list.append(cached_od)
            except Exception:
                pass
        cp._loaded = True
        return cp

    @staticmethod
    def _try_parse_index(key: str) -> Optional[int]:
        """尝试将字符串解析为索引"""
        try:
            if key.startswith('0x') or key.startswith('0X'):
                return int(key, 16)
            if len(key) <= 4 and all(c in '0123456789abcdefABCDEF' for c in key):
                return int(key, 16)
            return int(key)
        except ValueError:
            return None

    def __repr__(self) -> str:
        return f"ODList(slave={self._si}, objects={len(self._full_list)}, loaded={self._loaded})"


# =============================================================================
# CoEInstance 扩展方法 (对齐 C# CoEInstance 上的高级方法)
# =============================================================================

async def sdo_read_async(coe: CoE, index: int, subindex: int,
                         complete_access: bool = False,
                         timeout_ms: Optional[int] = None) -> Optional[bytes]:
    """
    异步 SDO 读 (对齐 C# CoEInstance.SDOReadAsync)

    参数:
        coe: CoE 实例 (来自 Slave.coe)
        index: SDO 索引
        subindex: 子索引
        complete_access: 完全访问模式 (读取整个对象)
        timeout_ms: 超时毫秒数, 触发 asyncio.TimeoutError
    返回:
        响应字节数组, DLL 失败返回 None
    异常:
        asyncio.TimeoutError: 超过 timeout_ms 未完成
        asyncio.CancelledError: 调用方取消 (底层同步调用无法真停, 等其自然结束)
    """
    return await _run_coe_async(
        coe.sdo_read, index, subindex, complete_access, timeout_ms=timeout_ms
    )


async def sdo_write_async(coe: CoE, index: int, subindex: int, data: bytes,
                          complete_access: bool = False,
                          timeout_ms: Optional[int] = None) -> bool:
    """
    异步 SDO 写 (对齐 C# CoEInstance.SDOWriteAsync)

    参数:
        coe: CoE 实例
        index: SDO 索引
        subindex: 子索引
        data: 要写入的字节数据
        complete_access: 完全访问模式
        timeout_ms: 超时毫秒数
    返回:
        写入是否成功
    """
    return await _run_coe_async(
        coe.sdo_write, index, subindex, data, complete_access,
        timeout_ms=timeout_ms,
    )


async def read_diagnostic_messages_async(coe: CoE,
                                         timeout_ms: Optional[int] = None
                                         ) -> List[DiagnosticMessage]:
    """异步读取诊断历史消息 (对齐 C# ReadDiagnosticMessagesAsync)"""
    return await _run_coe_async(
        read_diagnostic_messages, coe, timeout_ms=timeout_ms
    )


def read_diagnostic_messages(coe: CoE) -> List[DiagnosticMessage]:
    """
    读取诊断历史消息 (0x10F3, ETG.1510) (对齐 C# ReadDiagnosticMessages)
    从站通过此对象报告内部诊断信息。
    """
    messages = []
    try:
        count_data = coe.sdo_read(0x10F3, 0)
        if count_data is None or len(count_data) < 1:
            return messages
        count = count_data[0]
        for i in range(1, min(count, 20) + 1):
            data = coe.sdo_read(0x10F3, i)
            if data is None or len(data) < 8:
                continue
            msg = DiagnosticMessage(
                sub_index=i,
                diag_code=struct.unpack_from('<I', data, 0)[0],
                flags=struct.unpack_from('<H', data, 4)[0],
                text_index=struct.unpack_from('<H', data, 6)[0],
                raw_data=data,
            )
            messages.append(msg)
    except Exception:
        pass
    return messages


def parse_complete_access_data(ca_data: bytes, od_entries: list) -> dict:
    """
    解析 Complete Access 读取的原始字节数据，按子索引拆分。

    规则 (ETG.1000.6 §5.6.2):
    - SubIndex 0 始终填充到 16 位 (2字节)
    - BIT 类型连续打包，下一个非 BIT 类型从下一个字节边界开始

    参数:
        ca_data: Complete Access 读取的原始字节数据
        od_entries: 对象字典条目列表, 每个元素需包含:
                    - sub_index (int): 子索引号
                    - data_type (int): 数据类型原始值 (EcDataType)
                    - bit_length (int): 位长度

    返回:
        dict[int, bytes]: 按子索引拆分的字节数据 (key = 实际子索引号)
    """
    result = {}
    if not ca_data or not od_entries:
        return result

    bit_offset = 0

    # SubIndex 0 始终填充到 16 位 (2字节), 按 ETG 规范
    si0_bytes = 2
    if len(ca_data) >= si0_bytes:
        result[0] = ca_data[:si0_bytes]
    bit_offset = si0_bytes * 8

    # 解析后续子索引
    for i in range(1, len(od_entries)):
        oe = od_entries[i]
        dt = getattr(oe, 'data_type', 0)
        sub_idx = getattr(oe, 'sub_index', i)
        bl = getattr(oe, 'bit_length', 0)

        is_bit_type = (0x0030 <= dt <= 0x0037)

        if is_bit_type:
            bit_size = (dt - 0x0030) + 1  # BIT1=1, BIT2=2, ...
        else:
            bit_size = bl if bl > 0 else 8

        # 非 BIT 类型从下一个字节边界开始
        if not is_bit_type and (bit_offset % 8) != 0:
            bit_offset = ((bit_offset + 7) // 8) * 8

        byte_start = bit_offset // 8
        bytes_needed = (bit_size + 7) // 8

        if byte_start + bytes_needed <= len(ca_data):
            # 使用实际子索引值而非位置索引
            result[sub_idx] = ca_data[byte_start:byte_start + bytes_needed]

        bit_offset += bit_size

    return result


def get_device_profile(coe: CoE) -> int:
    """
    读取设备协议编号 (0x1000 Device Type 低 16 位)
    返回值示例: 402 (伺服驱动器), 401 (I/O 模块)
    """
    try:
        data = coe.sdo_read(0x1000, 0)
        if data is not None and len(data) >= 4:
            device_type = struct.unpack_from('<I', data, 0)[0]
            return device_type & 0xFFFF
    except Exception:
        pass
    return 0


# =============================================================================
# CoE Diagnosis History 0x10F3 原语 (ETG.1020 §16.2)
# =============================================================================
# 对齐 C# CoEInstance.PollHasNewDiagnostic / ReadDiagnosticMeta /
# ReadDiagnosticMessage / AcknowledgeDiagnostic (单次 SDO 原子访问,
# 比通用 sdo_read 走完整邮箱握手更轻量, 适合高频轮询).


from dataclasses import dataclass as _dc_diag  # noqa: E402
from ctypes import (  # noqa: E402
    c_ubyte as _c_ubyte, c_ushort as _c_ushort,
    c_uint as _c_uint, c_int as _c_int,
)


@_dc_diag
class DiagMeta:
    """
    0x10F3 诊断历史元数据 (ETG.1020 Table 48/49).

    对齐 C# CoE.DiagMeta:
      max_messages        — 0x10F3:01, 从站支持的最大消息数 (通常 <=250)
      newest_message      — 0x10F3:02, 最新消息所在 subindex
      newest_acknowledged — 0x10F3:03, 用户已确认的最新 subindex
      flags               — 0x10F3:05, bit4=Ring/Linear, bit5=Overrun
    """
    max_messages: int = 0
    newest_message: int = 0
    newest_acknowledged: int = 0
    flags: int = 0


def _coe_poll_has_new_diagnostic(self) -> int:
    """
    快速轮询 0x10F3:04 "NewAvailable" 标志 (ETG.1020 §16.2).

    对齐 C# CoEInstance.PollHasNewDiagnostic.
    Rapid poll of 0x10F3:04 "NewAvailable" flag for unread diagnostic events.

    Returns:
        1  = 有新消息 (new diagnostic available)
        0  = 无
       -1 = DLL 未导出 / 通信失败 (fallback to read_diagnostic_messages)
    """
    try:
        fn = getattr(self._dll, 'coe_diag_poll_new_available', None)
        if fn is None:
            return -1
        abort = _c_uint(0)
        rc = fn(self._mi, self._si, ctypes.byref(abort))
        return int(rc)
    except Exception:
        return -1


def _coe_read_diagnostic_meta(self) -> Optional[DiagMeta]:
    """
    读 0x10F3:01-05 元数据 (MaxMessages / Newest / Acked / Flags).

    对齐 C# CoEInstance.ReadDiagnosticMeta.
    Read the 0x10F3 metadata block. Returns None on failure.
    """
    try:
        fn = getattr(self._dll, 'coe_diag_read_meta', None)
        if fn is None:
            return None
        max_msgs = _c_ubyte(0)
        newest = _c_ubyte(0)
        acked = _c_ubyte(0)
        flags = _c_ushort(0)
        abort = _c_uint(0)
        rc = fn(self._mi, self._si,
                ctypes.byref(max_msgs), ctypes.byref(newest),
                ctypes.byref(acked), ctypes.byref(flags),
                ctypes.byref(abort))
        if rc == 1:
            return DiagMeta(
                max_messages=max_msgs.value,
                newest_message=newest.value,
                newest_acknowledged=acked.value,
                flags=flags.value,
            )
    except Exception:
        pass
    return None


def _coe_read_diagnostic_message(self, msg_subidx: int,
                                 buf_size: int = 1024) -> Optional[bytes]:
    """
    读 0x10F3:msg_subidx (6..255) 指定 Octet 诊断消息.

    对齐 C# CoEInstance.ReadDiagnosticMessage.
    Read one raw Octet-Diagnosis message from 0x10F3 ring buffer.

    Args:
        msg_subidx: subindex 范围 [6, 255] (ETG.1020)
        buf_size:   接收缓冲字节数, 默认 1024
    Returns:
        bytes (实际长度) / None 失败
    """
    try:
        fn = getattr(self._dll, 'coe_diag_read_message', None)
        if fn is None:
            return None
        if buf_size <= 0:
            buf_size = 1024
        buf = (_c_ubyte * buf_size)()
        out_len = _c_int(0)
        abort = _c_uint(0)
        rc = fn(self._mi, self._si, msg_subidx,
                buf, buf_size,
                ctypes.byref(out_len), ctypes.byref(abort))
        if rc == 1 and out_len.value > 0:
            return bytes(buf[:out_len.value])
    except Exception:
        pass
    return None


def _coe_acknowledge_diagnostic(self, msg_subidx: int) -> bool:
    """
    确认已处理消息, 写 0x10F3:03 = msg_subidx.

    对齐 C# CoEInstance.AcknowledgeDiagnostic.
    Acknowledge the specified subindex as processed (ring buffer advance).
    """
    try:
        fn = getattr(self._dll, 'coe_diag_acknowledge', None)
        if fn is None:
            return False
        abort = _c_uint(0)
        rc = fn(self._mi, self._si, msg_subidx, ctypes.byref(abort))
        return rc == 1
    except Exception:
        return False


# 挂载到 CoE 类 (保持基础 CoE.core.py 不变)
CoE.poll_has_new_diagnostic = _coe_poll_has_new_diagnostic
CoE.read_diagnostic_meta = _coe_read_diagnostic_meta
CoE.read_diagnostic_message = _coe_read_diagnostic_message
CoE.acknowledge_diagnostic = _coe_acknowledge_diagnostic

# 注: SDO Block Transfer 已按 ETG.1000.6 §5.6.2 audit 结论删除
# (标准只定义 Expedited + Normal, 无 Block Transfer). C DLL 侧 6 个 DLL_EXPORT
# 已撤除, Python 绑定与属性注入一并移除. Segmented Transfer 承担所有 >4 B SDO.


# ===================== [2026-05-09] CoE-H2 SDO Information 直读 OD =====================
# 通过 D_1575..D_1579 直接调 coe_get_od_list / coe_get_object_desc / coe_get_entry_desc,
# 不走 GetSlaveSDOList 缓存路径. 适合需要从从站实时拉 OD 树的场景.

# OD/OE 结构内存偏移 (与 ODList class 内常量一致, 复用以避免重复)
_DIRECT_OD_OFFSET_ENTRIES   = 2
_DIRECT_OD_OFFSET_INDEX     = 4
_DIRECT_OD_OFFSET_DATATYPE  = 2052
_DIRECT_OD_OFFSET_OBJCODE   = 4100
_DIRECT_OD_OFFSET_MAXSUB    = 5124
_DIRECT_OD_OFFSET_NAME      = 6148
_DIRECT_OD_NAME_SIZE        = 41

_DIRECT_OE_OFFSET_DATATYPE  = 258
_DIRECT_OE_OFFSET_BITLEN    = 770
_DIRECT_OE_OFFSET_OBJACCESS = 1282
_DIRECT_OE_OFFSET_NAME      = 1794
_DIRECT_OE_NAME_SIZE        = 41


def _coe_load_object_dictionary(self) -> Optional[List[ObjectDictionary]]:
    """直接通过 CoE SDO Information Service 加载 OD 列表 (D_1575+1577+1578+1579).
    每次实时从从站拉, 不走 GetSlaveSDOList 缓存. 失败返回 None."""
    dll = self._dll if hasattr(self, '_dll') else self.dll
    mi = self.master_index if hasattr(self, 'master_index') else self._mi
    si = self.slave_index if hasattr(self, 'slave_index') else self._si
    try:
        od_ptr = dll.coe_get_od_list(mi, si)
    except Exception:
        return None
    if not od_ptr:
        return None
    result: List[ObjectDictionary] = []
    try:
        entries = ctypes.cast(od_ptr + _DIRECT_OD_OFFSET_ENTRIES,
                              ctypes.POINTER(c_ushort)).contents.value
        if entries == 0 or entries > 1024:
            return result
        for i in range(entries):
            idx = ctypes.cast(od_ptr + _DIRECT_OD_OFFSET_INDEX + i * 2,
                              ctypes.POINTER(c_ushort)).contents.value
            if idx == 0:
                continue
            dt_raw = ctypes.cast(od_ptr + _DIRECT_OD_OFFSET_DATATYPE + i * 2,
                                 ctypes.POINTER(c_ushort)).contents.value
            obj_code = ctypes.cast(od_ptr + _DIRECT_OD_OFFSET_OBJCODE + i,
                                   ctypes.POINTER(ctypes.c_ubyte)).contents.value
            max_sub = ctypes.cast(od_ptr + _DIRECT_OD_OFFSET_MAXSUB + i,
                                  ctypes.POINTER(ctypes.c_ubyte)).contents.value
            name_bytes = ctypes.string_at(od_ptr + _DIRECT_OD_OFFSET_NAME + i * _DIRECT_OD_NAME_SIZE,
                                          _DIRECT_OD_NAME_SIZE)
            name = convert_byte_array_to_string(name_bytes)

            od = ObjectDictionary(mi, si, self)
            od.index = idx
            od.name = name
            od.object_code = obj_code
            od.data_type = dt_raw
            od.max_sub = max_sub

            # 拉每个 subindex 的 entry desc
            for s in range(max_sub + 1):
                try:
                    oe_ptr = dll.coe_get_entry_desc(mi, si, idx, s)
                except Exception:
                    continue
                if not oe_ptr:
                    continue
                try:
                    edt = ctypes.cast(oe_ptr + _DIRECT_OE_OFFSET_DATATYPE,
                                      ctypes.POINTER(c_ushort)).contents.value
                    bit_len = ctypes.cast(oe_ptr + _DIRECT_OE_OFFSET_BITLEN,
                                          ctypes.POINTER(c_ushort)).contents.value
                    access_raw = ctypes.cast(oe_ptr + _DIRECT_OE_OFFSET_OBJACCESS,
                                             ctypes.POINTER(c_ushort)).contents.value
                    ename_bytes = ctypes.string_at(oe_ptr + _DIRECT_OE_OFFSET_NAME,
                                                   _DIRECT_OE_NAME_SIZE)
                    ename = convert_byte_array_to_string(ename_bytes)
                    try:
                        edt_enum = EcDataType(edt)
                    except ValueError:
                        edt_enum = EcDataType.UNKNOWN
                    try:
                        access = ObjAccess(access_raw)
                    except ValueError:
                        access = ObjAccess.NONE
                    od.add_entry(ObjectEntry(self, idx, s, edt_enum, bit_len, access, ename))
                finally:
                    try:
                        dll.coe_free_oelist(oe_ptr)
                    except Exception:
                        pass
            result.append(od)
        return result
    except Exception:
        return None
    finally:
        try:
            dll.coe_free_odlist(od_ptr)
        except Exception:
            pass


def _coe_get_object_description(self, index: int) -> Optional[ObjectDictionary]:
    """直接读单个对象 Description (DataType/MaxSub/Name). 失败返回 None."""
    dll = self._dll if hasattr(self, '_dll') else self.dll
    mi = self.master_index if hasattr(self, 'master_index') else self._mi
    si = self.slave_index if hasattr(self, 'slave_index') else self._si
    try:
        p = dll.coe_get_object_desc(mi, si, index)
    except Exception:
        return None
    if not p:
        return None
    try:
        dt = ctypes.cast(p + _DIRECT_OD_OFFSET_DATATYPE,
                         ctypes.POINTER(c_ushort)).contents.value
        obj_code = ctypes.cast(p + _DIRECT_OD_OFFSET_OBJCODE,
                               ctypes.POINTER(ctypes.c_ubyte)).contents.value
        max_sub = ctypes.cast(p + _DIRECT_OD_OFFSET_MAXSUB,
                              ctypes.POINTER(ctypes.c_ubyte)).contents.value
        name_bytes = ctypes.string_at(p + _DIRECT_OD_OFFSET_NAME, _DIRECT_OD_NAME_SIZE)
        od = ObjectDictionary(mi, si, self)
        od.index = index
        od.name = convert_byte_array_to_string(name_bytes)
        od.object_code = obj_code
        od.data_type = dt
        od.max_sub = max_sub
        return od
    except Exception:
        return None
    finally:
        try:
            dll.coe_free_odlist(p)
        except Exception:
            pass


def _coe_get_entry_description(self, index: int, subindex: int) -> Optional[ObjectEntry]:
    """直接读单个 Entry Description (DataType/BitLength/ObjAccess/Name). 失败返回 None."""
    dll = self._dll if hasattr(self, '_dll') else self.dll
    mi = self.master_index if hasattr(self, 'master_index') else self._mi
    si = self.slave_index if hasattr(self, 'slave_index') else self._si
    try:
        p = dll.coe_get_entry_desc(mi, si, index, subindex)
    except Exception:
        return None
    if not p:
        return None
    try:
        edt = ctypes.cast(p + _DIRECT_OE_OFFSET_DATATYPE,
                          ctypes.POINTER(c_ushort)).contents.value
        bit_len = ctypes.cast(p + _DIRECT_OE_OFFSET_BITLEN,
                              ctypes.POINTER(c_ushort)).contents.value
        access_raw = ctypes.cast(p + _DIRECT_OE_OFFSET_OBJACCESS,
                                 ctypes.POINTER(c_ushort)).contents.value
        ename_bytes = ctypes.string_at(p + _DIRECT_OE_OFFSET_NAME, _DIRECT_OE_NAME_SIZE)
        try:
            edt_enum = EcDataType(edt)
        except ValueError:
            edt_enum = EcDataType.UNKNOWN
        try:
            access = ObjAccess(access_raw)
        except ValueError:
            access = ObjAccess.NONE
        return ObjectEntry(self, index, subindex, edt_enum, bit_len, access,
                           convert_byte_array_to_string(ename_bytes))
    except Exception:
        return None
    finally:
        try:
            dll.coe_free_oelist(p)
        except Exception:
            pass


CoE.load_object_dictionary = _coe_load_object_dictionary
CoE.get_object_description = _coe_get_object_description
CoE.get_entry_description = _coe_get_entry_description
