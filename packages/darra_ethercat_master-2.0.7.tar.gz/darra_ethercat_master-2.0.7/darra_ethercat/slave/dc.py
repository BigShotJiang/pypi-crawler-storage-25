# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/DC.cs
DC (Distributed Clock) 分布式时钟功能模块

包含:
- DcConfig: 从站级 DC 配置辅助类
- DcMaster: 主站级 DC 管理 (持续测量、漂移补偿、同步窗口监控)
- SyncWindowStatus: 同步窗口状态
"""

import ctypes
from ctypes import c_int, c_uint, c_bool, byref
from enum import IntEnum
from typing import Optional

from ..utils.dll import DarraCoreDLL


class DcSyncMode(IntEnum):
    """DC 同步模式 (根据 ETG.1020 和 ESI AssignActivate 定义)"""
    FreeRun      = 0   # 自由运行模式 - 不使用 DC 同步, AssignActivate = 0x0000
    SmSynchron   = 1   # SM 同步模式 - 使用 SM 事件触发, AssignActivate = 0x0000 (仅 SM 事件)
    DcSynchron   = 2   # DC 同步模式 - 仅 SYNC0 信号, 同步类型 0x0002
    DcSynchron01 = 3   # DC 同步模式 - SYNC0 + SYNC1 信号, 同步类型 0x0003


class SyncWindowStatus:
    """同步窗口状态"""

    def __init__(self, diff_ns: int = 0, max_diff_ns: int = 0,
                 min_diff_ns: int = 0, in_sync: bool = False,
                 out_of_sync_count: int = 0):
        self.diff_ns = diff_ns
        self.max_diff_ns = max_diff_ns
        self.min_diff_ns = min_diff_ns
        self.in_sync = in_sync
        self.out_of_sync_count = out_of_sync_count

    def __repr__(self) -> str:
        status = "同步" if self.in_sync else "未同步"
        return f"SyncWindow({status}, diff={self.diff_ns}ns, max={self.max_diff_ns}ns)"


class DcConfig:
    """
    DC 分布式时钟配置辅助类

    封装从站 DC 配置相关的 DLL 调用。
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int):
        """
        初始化 DC 配置

        参数:
            dll:          DLL 接口
            master_index: 主站索引
            slave_index:  从站索引
        """
        self._dll = dll
        self._mi = master_index
        self._si = slave_index

    def configure(self, sync0_cycle_ns: int, sync1_cycle_ns: int = 0,
                  shift_ns: Optional[int] = None) -> bool:
        """
        配置从站 DC 时钟同步

        参数:
            sync0_cycle_ns: SYNC0 周期 (纳秒)
            sync1_cycle_ns: SYNC1 周期 (纳秒, 0=禁用)
            shift_ns:       DC 偏移 (纳秒, None=自动)

        返回:
            配置是否成功
        """
        if shift_ns is not None:
            actual_shift = shift_ns
        else:
            # 自动计算偏移: 基于传播延迟差异 (参考 C# DC.cs / Rust dc.rs)
            actual_shift = 0
            try:
                self._dll.UpdatePropagationDelays(self._mi)
                max_delay = self._dll.GetMaxPropagationDelay(self._mi)
                slave_delay = self._dll.GetSlavePropagationDelay(self._mi, self._si)
                if max_delay > 0:
                    actual_shift = max_delay - slave_delay
            except Exception:
                actual_shift = 0
        self._dll.SetSyncBySlaveIndex(
            self._mi, self._si, sync0_cycle_ns, sync1_cycle_ns, actual_shift
        )
        return True

    def configure_mode(self, mode: DcSyncMode, sync0_cycle_ns: int = 0,
                       sync1_cycle_ns: int = 0, shift_ns: Optional[int] = None) -> bool:
        """
        按模式配置 DC (ETG.1020)

        参数:
            mode:           同步模式 (FreeRun/SmSynchron/DcSynchron/DcSynchron01)
            sync0_cycle_ns: SYNC0 周期 (纳秒)
            sync1_cycle_ns: SYNC1 周期 (纳秒, 仅 DcSynchron01 模式)
            shift_ns:       DC 偏移 (纳秒, None=自动)
        """
        # SM 同步类型协议数字已下沉到 native (dc_sync_mode.c), 此处仅保留模式分发逻辑

        if mode == DcSyncMode.FreeRun:
            # 自由运行: 禁用所有 DC 同步
            result = self.disable()
        elif mode == DcSyncMode.SmSynchron:
            # SM 同步: 禁用 DC 信号, 仅使用 SM 事件触发
            result = self.disable()
        elif mode == DcSyncMode.DcSynchron:
            # DC 同步: 仅 SYNC0 信号
            result = self.configure(sync0_cycle_ns, 0, shift_ns)
        elif mode == DcSyncMode.DcSynchron01:
            # DC 同步: SYNC0 + SYNC1 信号
            result = self.configure(sync0_cycle_ns, sync1_cycle_ns, shift_ns)
        else:
            return False

        # 通过 native 配置 SM 同步类型 (协议下沉到 Darra.Core.dll)
        self._configure_sm_sync_type(mode)
        return result

    def _configure_sm_sync_type(self, mode: DcSyncMode) -> None:
        """
        通过 native 接口配置从站同步类型 (协议算法已下沉到 Darra.Core.dll).
        SDO 0x1C32:01 / 0x1C33:01 编排在 native dc_sync_mode.c 中执行,
        SDK 公开代码不再出现 ETG.1020 §23.1.2 协议数字.

        某些从站不支持时 native 静默忽略, 此处再加一层异常兜底.
        """
        try:
            self._dll.SetDcSyncMode(self._mi, self._si, int(mode))
        except Exception:
            # 某些从站不支持 0x1C32/0x1C33, 仅忽略
            pass

    def disable(self) -> bool:
        """禁用从站 DC"""
        # 禁用 DC: sync0=0, sync1=0, shift=0
        self._dll.SetSyncBySlaveIndex(self._mi, self._si, 0, 0, 0)
        return True

    @property
    def propagation_delay(self) -> int:
        """传播延迟 (纳秒)"""
        return self._dll.GetSlavePropagationDelay(self._mi, self._si)

    @property
    def has_dc(self) -> bool:
        """
        从站是否启用 DC (ESC 硬件 bit, 对应 C# Slave.HasDC).
        与 ``slave/core.py`` 的 ``Slave.has_dc`` 同语义, 此处提供命名一致的便捷入口.
        """
        try:
            return bool(self._dll.GetSlaveHasDC(self._mi, self._si))
        except Exception:
            return False

    @property
    def has_esi_dc_sync(self) -> bool:
        """
        ESI 是否声明此从站使用 DC 同步 (对应 C# Slave.HasEsiDcSync).

        HasDC 仅反映 ESC 硬件 bit, 不代表应用层使用 DC. 启用 DC 前应
        同时检查 ``has_dc and has_esi_dc_sync``, 用于过滤例如 GCAN-8200
        这类 ESC 报 DC capable 但 ESI 未声明 DC OpMode 的从站.

        托管实装策略 (对齐 C# Slave.HasEsiDcSync 中的 dynamic 解析):
          1. 通过 GetSlaveIdentity 拿到 vendor_id/product_code/revision_no;
          2. 在 EsiManager 已加载的 ESI XML 中按 Vendor/Device 匹配定位;
          3. 解析 ``<Dc>/<OpMode>/<AssignActivate>`` 元素, 任一 != 0 视为
             声明 DC 同步;
          4. ESI 未加载 / 未找到 / 解析失败时, 保守 fallback 到 has_dc
             (与 Java hasEsiDcSync 同样保守, 不会强写 DCCUC 导致从站卡死).
        """
        try:
            from ..utils.esi import EsiManager
            from ..utils.dll import SlaveIdentity
            from ctypes import byref

            ident = SlaveIdentity()
            if not self._dll.GetSlaveIdentity(self._mi, self._si, byref(ident)):
                return self.has_dc

            vendor_id = int(ident.vendor_id)
            product_code = int(ident.product_code)
            revision_no = int(ident.revision_no)

            # ESI 未预加载 → 保守 fallback
            if not EsiManager.is_preloaded():
                return self.has_dc

            import xml.etree.ElementTree as ET

            def _parse_int(s: str) -> int:
                """ESI 数值: #x.. / 0x.. / 十进制"""
                if not s:
                    return 0
                s = s.strip()
                try:
                    if s.startswith('#x') or s.startswith('#X'):
                        return int(s[2:], 16)
                    if s.startswith('0x') or s.startswith('0X'):
                        return int(s, 16)
                    if s.startswith('#'):
                        return int(s[1:], 16)
                    return int(s)
                except (ValueError, TypeError):
                    return 0

            # 遍历已加载 ESI 文件, 按 Vendor/Device 定位匹配设备
            for fname, root in EsiManager._files.items():
                # Vendor 节点 (大小写无关)
                for vendor in root.iter():
                    tag = vendor.tag.split('}')[-1] if '}' in vendor.tag else vendor.tag
                    if tag != 'Vendor':
                        continue
                    vid_elem = vendor.find('Id')
                    if vid_elem is None:
                        continue
                    vid = _parse_int(vid_elem.text or '')
                    if vid != vendor_id:
                        continue

                    # Device 节点
                    for device in vendor.iter():
                        dtag = device.tag.split('}')[-1] if '}' in device.tag else device.tag
                        if dtag != 'Device':
                            continue
                        type_elem = device.find('Type')
                        if type_elem is None:
                            continue
                        pc = _parse_int(type_elem.get('ProductCode', ''))
                        if pc != product_code:
                            continue
                        # Revision 0 视为通配
                        if revision_no != 0:
                            rev = _parse_int(type_elem.get('RevisionNo', '0'))
                            if rev != 0 and rev != revision_no:
                                continue

                        # 解析 <Dc>/<OpMode>/<AssignActivate>
                        for dc_node in device.iter():
                            dctag = (dc_node.tag.split('}')[-1]
                                     if '}' in dc_node.tag else dc_node.tag)
                            if dctag != 'Dc':
                                continue
                            for op_mode in dc_node.iter():
                                otag = (op_mode.tag.split('}')[-1]
                                        if '}' in op_mode.tag else op_mode.tag)
                                if otag != 'OpMode':
                                    continue
                                aa_elem = op_mode.find('AssignActivate')
                                if aa_elem is None:
                                    continue
                                aa = _parse_int(aa_elem.text or '')
                                if aa != 0:
                                    return True
                        # 找到匹配 device 但无 DC OpMode → 不支持 DC 同步
                        return False
            # 未找到匹配设备 → 保守 fallback
            return self.has_dc
        except Exception:
            # 任何异常 → 保守 fallback (不强写 DCCUC)
            return self.has_dc

    def get_sync_window_status(self) -> Optional[SyncWindowStatus]:
        """获取同步窗口状态"""
        diff = c_int(0)
        max_diff = c_int(0)
        min_diff = c_int(0)
        in_sync = c_int(0)  # Windows BOOL 是 4 字节, 不能用 c_bool(1字节)
        ooc_count = c_uint(0)
        ok = self._dll.GetSlaveSyncWindowStatus(
            self._mi, self._si,
            byref(diff), byref(max_diff), byref(min_diff),
            byref(in_sync), byref(ooc_count)
        )
        if not ok:
            return None
        return SyncWindowStatus(
            diff_ns=diff.value,
            max_diff_ns=max_diff.value,
            min_diff_ns=min_diff.value,
            in_sync=in_sync.value,
            out_of_sync_count=ooc_count.value
        )

    def reset_sync_window_stats(self) -> None:
        """重置同步窗口统计"""
        self._dll.ResetSlaveSyncWindowStats(self._mi, self._si)

    def __repr__(self) -> str:
        return f"DcConfig(master={self._mi}, slave={self._si})"


class DcMaster:
    """
    主站级 DC 分布式时钟管理

    对应 C# DC.cs 中主站级别的 DC 方法:
    - 持续测量
    - 漂移补偿
    - 同步窗口监控
    - 全局 DC 配置
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_count_fn=None):
        """
        初始化主站级 DC 管理

        参数:
            dll:            DLL 接口
            master_index:   主站索引
            slave_count_fn: 获取从站数量的回调 (可选)
        """
        self._dll = dll
        self._mi = master_index
        self._slave_count_fn = slave_count_fn

    def enable_continuous_measurement(self, enable: bool = True,
                                      interval_sec: int = 0) -> None:
        """
        启用/禁用持续传播延迟测量 (ETG.1500 5.13.2)

        参数:
            enable:       是否启用
            interval_sec: 测量间隔 (秒), 0=使用默认值 (10秒) (对齐 C# intervalSec)
        """
        self._dll.EnableContinuousMeasurement(self._mi, enable, interval_sec)

    def enable_drift_compensation(self, enable: bool = True,
                                  max_drift_ns: int = 1000,
                                  correction_factor: int = 512) -> None:
        """
        启用/禁用 DC 漂移补偿

        参数:
            enable:            是否启用
            max_drift_ns:      漂移阈值 (纳秒), 超过此值才进行补偿
            correction_factor: 补偿增益 (0-1024, 表示 0.0-1.0)
        """
        self._dll.EnableDriftCompensation(
            self._mi, enable, max_drift_ns, correction_factor
        )

    def is_all_slaves_in_sync(self, threshold_ns: int = 0) -> bool:
        """
        检查所有 DC 从站是否都在同步窗口内

        参数:
            threshold_ns: 同步阈值 (纳秒), >0 时先设置阈值再检查

        返回:
            所有从站是否同步
        """
        if threshold_ns > 0:
            self._dll.SetSyncWindowThreshold(self._mi, threshold_ns)
        return bool(self._dll.IsAllSlavesInSync(self._mi))

    def get_max_sync_difference(self) -> int:
        """
        获取所有 DC 从站中的最大时间差 (纳秒)

        返回:
            最大同步差值 (纳秒), 失败返回 -1
        """
        return self._dll.GetMaxSyncDifference(self._mi)

    def reset_all_sync_window_stats(self) -> None:
        """重置所有从站的同步窗口统计"""
        count = self._slave_count_fn() if self._slave_count_fn else 0
        for i in range(1, count + 1):
            try:
                self._dll.ResetSlaveSyncWindowStats(self._mi, i)
            except Exception:
                pass

    def reset_sync_window_stats(self, slave_index: int) -> None:
        """
        重置指定从站的同步窗口统计

        参数:
            slave_index: 从站索引
        """
        self._dll.ResetSlaveSyncWindowStats(self._mi, slave_index)

    def configure_dc(self, sync0_cycle_ns: int, sync1_cycle_ns: int = 0,
                     shift_ns: int = 0) -> int:
        """
        一次性配置所有 DC 从站

        参数:
            sync0_cycle_ns: SYNC0 周期 (纳秒), 0=禁用
            sync1_cycle_ns: SYNC1 周期 (纳秒), 0=禁用
            shift_ns:       未使用 (DLL 内部自动计算偏移)

        返回:
            成功配置的 DC 从站数量
        """
        return self._dll.ConfigureDCAll(self._mi, sync0_cycle_ns, sync1_cycle_ns)

    def disable_dc(self, slave_index: int) -> None:
        """
        禁用指定从站的 DC 同步

        参数:
            slave_index: 从站索引
        """
        self._dll.SetSyncBySlaveIndex(self._mi, slave_index, 0, 0, 0)

    @property
    def master_dc_time(self) -> int:
        """
        主站最近一次 PDO 周期从参考时钟从站 FRMW 取回的 64-bit DC 系统时间.

        单位: 纳秒, 纪元 2000-01-01 00:00:00 UTC. 对应 C# DC.MasterDCTimeNs /
        DLL.GetMasterDCTime, Java getMasterDCTime, Rust master_dc_time.
        无 DC 从站 / 主站未运行 / DLL 未导出时返回 0.

        与 ``master/core.py`` 的 ``Master.master_dc_time`` 同源, 此处提供
        DC 命名空间下的便捷入口.
        """
        fn = getattr(self._dll, 'GetMasterDCTime', None)
        if fn is None:
            return 0
        try:
            return int(fn(self._mi))
        except Exception:
            return 0

    @property
    def reference_clock_slave_index(self) -> int:
        """
        当前参考时钟从站索引 (1-based, 对应 C# DC.ReferenceClockSlaveIndex /
        Java getReferenceClockSlaveIndex / Rust reference_clock_slave_index).

        由 DLL 在 configdc 阶段自动选为第一个 DC-capable 从站, 用户
        无需配置. 0 表示网络中无 DC 从站 / DLL 未导出.
        """
        fn = getattr(self._dll, 'GetReferenceClockSlaveIndex', None)
        if fn is None:
            return 0
        try:
            return int(fn(self._mi))
        except Exception:
            return 0

    def __repr__(self) -> str:
        return f"DcMaster(master={self._mi})"
