# -*- coding: utf-8 -*-
"""
从站模块
包含 EtherCAT 从站类及各协议接口
"""

from .core import Slave, CoE, SoE, EoE, AoE, FSoE, CiA402, ModeCiA402

# FoE 独立模块
from .foe import FoE

# VoE 独立模块
from .voe import VoE, VoEResponse

# CoE 高级功能 (OD 树遍历)
from .coe import EcDataType, ObjAccess, ObjectEntry, ObjectDictionary, ODList

# CoE EMCY 历史记录
from .coe_emcy import EmergencyMessage, CoEEmcyRecorder

# CiA402 高级功能 (PDO 映射扫描、状态机控制、运动参数等)
from .cia402 import (
    CiA402Advanced, StateCiA402 as StateCiA402Adv,
    ModeCiA402 as ModeCiA402Adv, parse_cia402_state,
)

# SoE 扩展类型
from .soe import (
    SoEAdvanced, ServoDriveManager,
    SoEParameter, SoEAttributes, SoEDataType,
    SoENotificationEventArgs, decode_soe_attributes,
)

# FSoE MDP 与 CRC
from .fsoe import SafeMdp, SafetyManager, fsoe_crc16, fsoe_crc16_fast

# MDP 模块发现
from .mdp import MdpModule, MdpSlotInfo, MdpModulePdoInfo, MdpDiscovery

# EoE 高级功能 (Ping、地址过滤、帧收发)
from .eoe import EoEPingResult, EoEAdvanced, EoEPinger

# AoE 订阅管理
from .aoe import AoESubscription, AoESubscriptionManager, AoETransmissionMode

# PDO 变化检测与统计
from .pdo import PDOWatcher, PDOMonitor, PDOManager

# DC 分布式时钟
from .dc import DcConfig, DcMaster, DcSyncMode, SyncWindowStatus

# 从站 PDO 数据访问
from .slave_pdo import SlavePdo

# 从站诊断
from .slave_stats import EscPortErrors, SyncWindowStatus, SlaveDCDiagnostics, SlaveDiagnostics

# CiA 401 I/O 模块
from .cia401 import CiA401, CiA401ErrorMode

# 启动参数
from .startup import StartupParameter, StartupParameterList

# 拓扑管理
from .topology import SlaveTopology

# ESI 加载器
from .esi import EsiLoader, EsiStartupParam, EsiDeviceInfo
