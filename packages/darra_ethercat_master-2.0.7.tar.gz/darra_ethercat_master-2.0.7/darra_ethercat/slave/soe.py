# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/SoE.cs
SoE (Servo over EtherCAT) 高级功能模块

包含:
- SoEAdvanced: 在基础 SoE 之上提供类型化读写方法
- SoEParameter: IDN 参数信息封装
- SoEAttributes: 属性位域解码
- SoEDataType: SoE 数据类型枚举
- SoENotificationEventArgs: 通知事件参数
"""

import asyncio
import struct
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from enum import IntEnum
from typing import Any, Callable, Dict, List, Optional, Tuple

import ctypes

from .core import SoE
from ..utils.dll import (
    EcMbxStatsT, SoENotificationCallbackType, SoEEmergencyCallbackType,
)
from ..abstractions import IMailboxProtocol, MailboxStatistics
from ..utils.help import convert_byte_array_to_string  # SoE 字符串多编码兜底


# =============================================================================
# SoE 能力检测 (对齐 C# SoEInstance.IsSupported)
# =============================================================================
# 通过 DLL.GetSlaveMailboxProto 读 SII mbx_proto bit 4 (ECT_MBXPROT_SOE = 0x10).
# DLL 调用失败时保守返回 True (未知能力视为支持, 不阻塞用户调用).

def _soe_is_supported(self) -> bool:
    """
    从站是否支持 SoE 邮箱协议 (对齐 C# SoEInstance.IsSupported).

    读取 SII mbx_proto bit 4 (ECT_MBXPROT_SOE = 0x10) 判断支持情况.
    DLL 调用失败时保守返回 True.
    """
    try:
        mbx_proto = self._dll.GetSlaveMailboxProto(self._mi, self._si)
        return (mbx_proto & 0x10) != 0
    except Exception:
        return True


# 在 SoE 类上挂载 is_supported 属性 (不修改 core.py)
SoE.is_supported = property(_soe_is_supported)


# =============================================================================
# IMailboxProtocol 接口实现 (对齐 C# IMailboxProtocol)
# =============================================================================

_SOE_PROTOCOL_TYPE = 0x05  # ECT_MBXT_SOE


def _soe_protocol_type(self) -> int:
    return _SOE_PROTOCOL_TYPE


def _soe_protocol_name(self) -> str:
    return "SoE"


def _soe_statistics(self) -> MailboxStatistics:
    """读取 SoE 邮箱统计快照."""
    try:
        stats = EcMbxStatsT()
        rc = self._dll.mbx_get_stats_by_master(
            self._mi, self._si, _SOE_PROTOCOL_TYPE, ctypes.byref(stats)
        )
        if rc == 1:
            avg = (stats.total_latency_us / stats.total_received
                   if stats.total_received > 0 else 0.0)
            t = None
            if stats.last_error_time_us > 0:
                from datetime import datetime, timezone
                t = datetime.fromtimestamp(
                    stats.last_error_time_us / 1_000_000, tz=timezone.utc
                )
            return MailboxStatistics(
                total_sent=stats.total_sent,
                total_received=stats.total_received,
                total_timeout=stats.total_timeout,
                total_mailbox_error=stats.total_mbx_error,
                total_protocol_error=stats.total_proto_error,
                total_cancelled=stats.total_cancelled,
                last_error_code=stats.last_error_code,
                last_error_time=t,
                average_latency_us=avg,
            )
    except Exception:
        pass
    return MailboxStatistics.empty()


def _soe_reset_statistics(self) -> None:
    """重置 SoE 邮箱统计."""
    try:
        self._dll.mbx_reset_stats_by_master(
            self._mi, self._si, _SOE_PROTOCOL_TYPE
        )
    except Exception:
        pass


SoE.protocol_type = property(_soe_protocol_type)
SoE.protocol_name = property(_soe_protocol_name)
SoE.statistics = property(_soe_statistics)
SoE.reset_statistics = _soe_reset_statistics

IMailboxProtocol.register(SoE)


# =============================================================================
# 异步支持 (asyncio) — 对齐 C# SoEInstance.*Async
# =============================================================================
# SoE 参数读写一般 < 100ms, 但批量 IDN 扫描可能累计较长。
# 使用独立线程池避免阻塞 CoE/FoE 通讯。

_soe_async_executor: Optional[ThreadPoolExecutor] = None
_soe_executor_lock = threading.Lock()


def _get_soe_executor() -> ThreadPoolExecutor:
    """懒创建 SoE 协议专用线程池"""
    global _soe_async_executor
    if _soe_async_executor is None:
        with _soe_executor_lock:
            if _soe_async_executor is None:
                _soe_async_executor = ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="darra-soe-async"
                )
    return _soe_async_executor


def shutdown_soe_async_executor(wait: bool = True) -> None:
    """关闭 SoE 异步线程池"""
    global _soe_async_executor
    with _soe_executor_lock:
        if _soe_async_executor is not None:
            _soe_async_executor.shutdown(wait=wait)
            _soe_async_executor = None


async def _run_soe_async(func, *args, timeout_ms: Optional[int] = None):
    """通用 SoE 异步执行辅助"""
    loop = asyncio.get_event_loop()
    fut = loop.run_in_executor(_get_soe_executor(), func, *args)
    if timeout_ms and timeout_ms > 0:
        return await asyncio.wait_for(fut, timeout=timeout_ms / 1000.0)
    return await fut


class SoEDataType(IntEnum):
    """SoE 数据类型枚举"""
    Binary      = 0
    UInt        = 1
    Int         = 2
    Hexadecimal = 3
    String      = 4
    IDN         = 5
    Float       = 6
    Parameter   = 7


# =============================================================================
# SoE Element Flags 枚举 (对齐 C# SoEElementFlags)
# =============================================================================
# ETG.1000.6 §5.11 SoEHeader 7 位位掩码; 多个位可 OR 组合一次读/写多项.

try:
    from enum import IntFlag as _IntFlag
except ImportError:  # pragma: no cover - Py2 不会到这
    _IntFlag = IntEnum  # 退化为普通枚举


class SoEElementFlags(_IntFlag):
    """SoE Element 位标志 (对齐 C# enum SoEElementFlags)."""
    NONE        = 0x00
    DATA_STATUS = 0x01   # 数据状态字 (valid/invalid/busy)
    NAME        = 0x02   # IDN 名称
    ATTRIBUTE   = 0x04   # 属性 (类型/长度/小数位等)
    UNIT        = 0x08   # 单位字符串
    MIN         = 0x10   # 最小值
    MAX         = 0x20   # 最大值
    VALUE       = 0x40   # 操作数据值 (最常用)
    DEFAULT     = 0x80   # 默认值


# =============================================================================
# SERCOS IDN 编/解码 (对齐 DLL utils.c:SoEIdnEncode / SoEIdnDecode)
# =============================================================================
# bit15 = 0 -> S 标准, 1 -> P 厂商; bit14..12 = Set (0..7); bit11..0 = Block.
# DLL 已实现但 dll.py 未暴露 P/Invoke; 这里以纯位运算自实现, 与 DLL 行为完全一致.

def encode_idn(is_standard: bool, parameter_set: int, data_block: int) -> int:
    """
    将 (Standard?, Set, Block) 三元组编码为 16 位 IDN.

    与 DLL ``SoEIdnEncode`` (utils.c:1438) 输出完全一致.
    """
    idn = 0
    if not is_standard:
        idn |= 0x8000
    idn |= (parameter_set & 0x07) << 12
    idn |= (data_block & 0x0FFF)
    return idn & 0xFFFF


def decode_idn(idn: int) -> Tuple[bool, int, int]:
    """
    将 16 位 IDN 解码为 ``(is_standard, parameter_set, data_block)`` 三元组.

    与 DLL ``SoEIdnDecode`` (utils.c:1448) 输出完全一致.
    """
    idn &= 0xFFFF
    is_standard = (idn & 0x8000) == 0
    parameter_set = (idn >> 12) & 0x07
    data_block = idn & 0x0FFF
    return is_standard, parameter_set, data_block


def try_parse_sercos_idn(text: str) -> Optional[int]:
    """
    解析 SERCOS IDN 字符串 ("S-0-0040" / "P-1-0123") 为 16 位 IDN, 失败返回 None.
    """
    if not text:
        return None
    parts = text.strip().split('-')
    if len(parts) != 3:
        return None
    head = parts[0].upper()
    if head == 'S':
        is_standard = True
    elif head == 'P':
        is_standard = False
    else:
        return None
    try:
        set_no = int(parts[1])
        block = int(parts[2])
    except ValueError:
        return None
    if not (0 <= set_no <= 7) or not (0 <= block <= 0x0FFF):
        return None
    return encode_idn(is_standard, set_no, block)


def format_sercos_idn(idn: int) -> str:
    """格式化 16 位 IDN 为 ``"S-x-xxxx"`` / ``"P-x-xxxx"`` 字符串."""
    is_standard, set_no, block = decode_idn(idn)
    prefix = 'S' if is_standard else 'P'
    return f"{prefix}-{set_no}-{block:04d}"


class SoEAttributes:
    """SoE 属性结构: 属性位域解码后的可读字段"""

    def __init__(self):
        self.evaluation_factor: int = 0
        self.length: int = 0
        self.is_list: bool = False
        self.is_command: bool = False
        self.data_type: SoEDataType = SoEDataType.Binary
        self.decimals: int = 0
        self.write_protected_preop: bool = False
        self.write_protected_safeop: bool = False
        self.write_protected_op: bool = False

    @property
    def is_read_only(self) -> bool:
        """参数是否只读"""
        return (self.write_protected_preop and
                self.write_protected_safeop and
                self.write_protected_op)

    @property
    def access_mode(self) -> str:
        """获取访问权限字符串"""
        if self.is_read_only:
            return "RO"
        elif (not self.write_protected_preop and
              not self.write_protected_safeop and
              not self.write_protected_op):
            return "RW"
        return "RW*"


class SoEParameter:
    """SoE IDN 参数信息封装"""

    def __init__(self, idn: int = 0):
        self.idn = idn
        self.name: str = ""
        self.unit: str = ""
        self.attributes = SoEAttributes()
        self.value: bytes = b''
        self.default_value: bytes = b''
        self.min_value: bytes = b''
        self.max_value: bytes = b''

    @property
    def sercos_idn(self) -> str:
        """获取 SERCOS IDN 格式字符串 (S-x-xxxx 或 P-x-xxxx)"""
        prefix = "S" if self.idn < 0x8000 else "P"
        stype = (self.idn >> 12) & 0x7
        number = self.idn & 0x0FFF
        return f"{prefix}-{stype}-{number:04d}"

    @property
    def category(self) -> str:
        """IDN 类别"""
        if self.idn < 0x8000:
            return "Standard"
        elif self.idn >= 0xC000:
            return "Vendor"
        return "Product"

    def __str__(self) -> str:
        """字符串表示: SERCOS IDN 格式 + 名称"""
        return f"{self.sercos_idn} {self.name}"

    def __repr__(self) -> str:
        return f"SoEParameter(idn=0x{self.idn:04X}, name={self.name!r})"


class SoENotificationEventArgs:
    """
    SoE 通知事件参数 (ETG.1020 / IEC 61800-7, OpCode=5 Notification).

    对齐 C# SoENotificationEventArgs. ``element_flags`` 标识本次通知
    携带了 IDN 的哪些 Element (0x40=Value / 0x02=Name / 0x04=Attribute ...).
    """

    def __init__(self, slave_index: int = 0, drive_number: int = 0,
                 idn: int = 0,
                 element_flags: int = 0,
                 new_value: Optional[bytes] = None,
                 old_value: Optional[bytes] = None):
        self.slave_index = slave_index
        self.drive_number = drive_number
        self.idn = idn
        self.element_flags = element_flags
        self.new_value = new_value
        self.old_value = old_value

    @property
    def sercos_idn(self) -> str:
        """获取 SERCOS IDN 格式字符串"""
        prefix = "S" if self.idn < 0x8000 else "P"
        stype = (self.idn >> 12) & 0x7
        number = self.idn & 0x0FFF
        return f"{prefix}-{stype}-{number:04d}"


class SoEEmergencyEventArgs:
    """
    SoE Emergency 事件参数 (ETG.1020 / IEC 61491, OpCode=6 Emergency).

    对齐 C# SoEEmergencyEventArgs. 由从站异步推送的致命错误帧,
    ``error_code`` 为 Sercos Emergency Error Code (2 字节).
    """

    def __init__(self, slave_index: int = 0, drive_number: int = 0,
                 error_code: int = 0,
                 timestamp: Optional[datetime] = None):
        from datetime import datetime as _dt, timezone as _tz
        self.slave_index = slave_index
        self.drive_number = drive_number
        self.error_code = error_code
        self.timestamp = timestamp or _dt.now(_tz.utc)

    def __repr__(self) -> str:
        return (f"SoEEmergency(slave={self.slave_index}, "
                f"drive={self.drive_number}, "
                f"error=0x{self.error_code:04X}, "
                f"t={self.timestamp:%H:%M:%S.%f})")


def decode_soe_attributes(attributes: int) -> SoEAttributes:
    """将 DLL 返回的属性位域解码为 SoEAttributes 结构"""
    attr = SoEAttributes()
    attr.evaluation_factor = attributes & 0xFFFF
    attr.length = (attributes >> 16) & 0x3
    attr.is_list = bool((attributes >> 18) & 0x1)
    attr.is_command = bool((attributes >> 19) & 0x1)
    try:
        attr.data_type = SoEDataType((attributes >> 20) & 0x7)
    except ValueError:
        attr.data_type = SoEDataType.Binary
    attr.decimals = (attributes >> 24) & 0xF
    attr.write_protected_preop = bool((attributes >> 28) & 0x1)
    attr.write_protected_safeop = bool((attributes >> 29) & 0x1)
    attr.write_protected_op = bool((attributes >> 30) & 0x1)
    return attr


class SoEAdvanced(SoE):
    """
    SoE 高级接口: 在基础 SoE 读写之上提供类型化方法

    继承自 SoE, 新增 read_i16/i32/u16/u32/f32/f64/string
    以及对应的 write_* 系列方法, 参数通知功能等。
    """

    def _read_typed(self, idn: int, fmt: str) -> Optional[Any]:
        """内部: 读取并按格式解包"""
        data = self.read(idn)
        if data is None:
            return None
        size = struct.calcsize(fmt)
        if len(data) < size:
            data = data.ljust(size, b'\x00')
        return struct.unpack(fmt, data[:size])[0]

    def _write_typed(self, idn: int, value: Any, fmt: str) -> bool:
        """内部: 打包并写入"""
        return self.write(idn, struct.pack(fmt, value))

    def read_i8(self, idn: int) -> Optional[int]:
        """读取有符号 8 位整数"""
        return self._read_typed(idn, '<b')

    def read_i16(self, idn: int) -> Optional[int]:
        """读取有符号 16 位整数"""
        return self._read_typed(idn, '<h')

    def read_i32(self, idn: int) -> Optional[int]:
        """读取有符号 32 位整数"""
        return self._read_typed(idn, '<i')

    def read_i64(self, idn: int) -> Optional[int]:
        """读取有符号 64 位整数"""
        return self._read_typed(idn, '<q')

    def read_u8(self, idn: int) -> Optional[int]:
        """读取无符号 8 位整数"""
        return self._read_typed(idn, '<B')

    def read_u16(self, idn: int) -> Optional[int]:
        """读取无符号 16 位整数"""
        return self._read_typed(idn, '<H')

    def read_u32(self, idn: int) -> Optional[int]:
        """读取无符号 32 位整数"""
        return self._read_typed(idn, '<I')

    def read_u64(self, idn: int) -> Optional[int]:
        """读取无符号 64 位整数"""
        return self._read_typed(idn, '<Q')

    def read_f32(self, idn: int) -> Optional[float]:
        """读取 32 位浮点数"""
        return self._read_typed(idn, '<f')

    def read_f64(self, idn: int) -> Optional[float]:
        """读取 64 位浮点数"""
        return self._read_typed(idn, '<d')

    def read_string(self, idn: int, encoding: str = 'utf-8') -> Optional[str]:
        """读取字符串 (自动去除末尾 NUL)"""
        data = self.read(idn)
        if data is None:
            return None
        return data.rstrip(b'\x00').decode(encoding, errors='replace')

    def write_i8(self, idn: int, value: int) -> bool:
        """写入有符号 8 位整数"""
        return self._write_typed(idn, value, '<b')

    def write_i16(self, idn: int, value: int) -> bool:
        """写入有符号 16 位整数"""
        return self._write_typed(idn, value, '<h')

    def write_i32(self, idn: int, value: int) -> bool:
        """写入有符号 32 位整数"""
        return self._write_typed(idn, value, '<i')

    def write_i64(self, idn: int, value: int) -> bool:
        """写入有符号 64 位整数"""
        return self._write_typed(idn, value, '<q')

    def write_u8(self, idn: int, value: int) -> bool:
        """写入无符号 8 位整数"""
        return self._write_typed(idn, value, '<B')

    def write_u16(self, idn: int, value: int) -> bool:
        """写入无符号 16 位整数"""
        return self._write_typed(idn, value, '<H')

    def write_u32(self, idn: int, value: int) -> bool:
        """写入无符号 32 位整数"""
        return self._write_typed(idn, value, '<I')

    def write_u64(self, idn: int, value: int) -> bool:
        """写入无符号 64 位整数"""
        return self._write_typed(idn, value, '<Q')

    def write_f32(self, idn: int, value: float) -> bool:
        """写入 32 位浮点数"""
        return self._write_typed(idn, value, '<f')

    def write_f64(self, idn: int, value: float) -> bool:
        """写入 64 位浮点数"""
        return self._write_typed(idn, value, '<d')

    def write_string(self, idn: int, value: str, encoding: str = 'utf-8') -> bool:
        """写入字符串"""
        return self.write(idn, value.encode(encoding))

    # ========== 类型化写入别名 (兼容 SDK 命名) ==========

    def write_int16(self, idn: int, value: int, drive_no: int = 0) -> bool:
        """写入有符号 16 位整数 (write_i16 别名)"""
        return self._write_typed(idn, value, '<h')

    def write_int32(self, idn: int, value: int, drive_no: int = 0) -> bool:
        """写入有符号 32 位整数 (write_i32 别名)"""
        return self._write_typed(idn, value, '<i')

    def write_uint16(self, idn: int, value: int, drive_no: int = 0) -> bool:
        """写入无符号 16 位整数 (write_u16 别名)"""
        return self._write_typed(idn, value, '<H')

    def write_uint32(self, idn: int, value: int, drive_no: int = 0) -> bool:
        """写入无符号 32 位整数 (write_u32 别名)"""
        return self._write_typed(idn, value, '<I')

    def write_float(self, idn: int, value: float, drive_no: int = 0) -> bool:
        """写入 32 位浮点数 (write_f32 别名)"""
        return self._write_typed(idn, value, '<f')

    def write_double(self, idn: int, value: float, drive_no: int = 0) -> bool:
        """写入 64 位浮点数 (write_f64 别名)"""
        return self._write_typed(idn, value, '<d')

    # ===================== 异步接口 (对齐 C# SoEInstance *Async) =====================

    async def read_async(self, idn: int, element_flags: int = 0x40,
                         timeout_ms: Optional[int] = None) -> Optional[bytes]:
        """异步读取 IDN 数据 (对齐 C# SoEInstance.ReadAsync)"""
        return await _run_soe_async(
            self.read, idn, element_flags, timeout_ms=timeout_ms
        )

    async def write_async(self, idn: int, data: bytes, element_flags: int = 0x40,
                          timeout_ms: Optional[int] = None) -> bool:
        """异步写入 IDN 数据 (对齐 C# SoEInstance.WriteAsync)"""
        return await _run_soe_async(
            self.write, idn, data, element_flags, timeout_ms=timeout_ms
        )

    async def read_typed_async(self, idn: int, fmt: str,
                               timeout_ms: Optional[int] = None) -> Optional[Any]:
        """异步按格式解包读取"""
        return await _run_soe_async(
            self._read_typed, idn, fmt, timeout_ms=timeout_ms
        )

    async def write_typed_async(self, idn: int, value: Any, fmt: str,
                                timeout_ms: Optional[int] = None) -> bool:
        """异步按格式打包写入"""
        return await _run_soe_async(
            self._write_typed, idn, value, fmt, timeout_ms=timeout_ms
        )

    async def get_parameter_info_async(self, idn: int,
                                       timeout_ms: Optional[int] = None
                                       ) -> 'SoEParameter':
        """异步获取 IDN 参数完整信息 (对齐 C# GetParameterInfoAsync)"""
        return await _run_soe_async(
            self.get_parameter_info, idn, timeout_ms=timeout_ms
        )

    async def execute_command_async(self, idn: int,
                                    timeout_ms: int = 5000,
                                    poll_interval_ms: int = 50) -> bool:
        """
        异步执行 SERCOS Procedure Command (对齐 C# ExecuteCommandAsync)

        注意: 内部是轮询循环, asyncio 取消可让 await 立即返回, 但线程仍在跑。
        """
        return await _run_soe_async(
            self.execute_command, idn, timeout_ms, poll_interval_ms,
            # poll 循环本身带 timeout, asyncio 多留 2x 余量
            timeout_ms=timeout_ms * 2,
        )

    async def poll_notifications_async(self, timeout_ms: int = 200) -> int:
        """异步轮询通知变化 (用于 asyncio 事件循环集成)"""
        return await _run_soe_async(self.poll_notifications, timeout_ms)

    def get_parameter_info(self, idn: int) -> SoEParameter:
        """
        获取指定 IDN 的详细参数信息

        参数:
            idn: IDN 编号

        返回:
            SoEParameter 对象
        """
        param = SoEParameter(idn)

        # 读取名称
        name = self.read_name(idn)
        if name:
            param.name = name

        # 读取单位
        unit = self.read_unit(idn)
        if unit:
            param.unit = unit

        # 读取属性
        attrs = self.read_attributes(idn)
        if attrs is not None:
            param.attributes = decode_soe_attributes(attrs)

        # 读取当前值
        value = self.read(idn, 0x40)
        if value:
            param.value = value

        # 读取最小最大值
        min_max = self.read_min_max(idn)
        if min_max:
            param.min_value, param.max_value = min_max

        # 读取默认值
        default = self.read(idn, 0x80)
        if default:
            param.default_value = default

        return param

    def execute_command(self, idn: int, timeout_ms: int = 5000,
                        poll_interval_ms: int = 50) -> bool:
        """
        执行 SoE 程序命令 (SERCOS Procedure Command)

        参数:
            idn:              命令 IDN 编号
            timeout_ms:       超时时间 (毫秒)
            poll_interval_ms: 轮询间隔 (毫秒)

        返回:
            成功返回 True
        """
        import time

        # 读取当前 Data State (Element 1, Flag 0x01)
        current_state = self.read(idn, 0x01)
        if current_state is None or len(current_state) < 2:
            return False

        # 设置 bit 0 = 1 (执行命令)
        state_value = struct.unpack('<H', current_state[:2])[0]
        state_value = (state_value & 0xFFFC) | 0x0001
        if not self.write(idn, struct.pack('<H', state_value), 0x01):
            return False

        # 轮询等待命令完成
        deadline = time.perf_counter() + timeout_ms / 1000.0
        while time.perf_counter() < deadline:
            time.sleep(poll_interval_ms / 1000.0)
            poll_state = self.read(idn, 0x01)
            if poll_state is None or len(poll_state) < 2:
                continue
            poll_value = struct.unpack('<H', poll_state[:2])[0]
            if poll_value & 0x0002:
                return False  # 命令执行错误
            if not (poll_value & 0x0001):
                return True   # 命令完成

        return False  # 超时

    # ===================== 标准 IDN 常量 =====================

    class StandardIDN:
        """SoE 标准 IDN 常量"""
        IDN_LIST = 0x0000
        AT_CONFIG = 0x0010
        MDT_CONFIG = 0x0018
        CYCLE_TIME = 0x0001
        NOTIFICATION_REQUEST = 0x007F

    # ===================== 映射信息 =====================

    def read_data_state(self, idn: int, timeout_ms: int = 500) -> Optional[int]:
        """
        读取 IDN 的 Data State 元素 (Element 1, Flag 0x01)

        参数:
            idn:        IDN 编号
            timeout_ms: 超时时间 (毫秒)

        返回:
            Data State 值, 失败返回 None
        """
        data = self.read(idn, 0x01)
        if data is not None and len(data) >= 2:
            return struct.unpack('<H', data[:2])[0]
        return None

    def read_default_value(self, idn: int, timeout_ms: int = 500) -> Optional[bytes]:
        """读取 IDN 参数默认值 (ElementFlag 0x80)"""
        return self.read(idn, 0x80)

    def read_min_value(self, idn: int, timeout_ms: int = 500) -> Optional[bytes]:
        """读取 IDN 参数最小值 (ElementFlag 0x10)"""
        return self.read(idn, 0x10)

    def read_max_value(self, idn: int, timeout_ms: int = 500) -> Optional[bytes]:
        """读取 IDN 参数最大值 (ElementFlag 0x20)"""
        return self.read(idn, 0x20)

    def get_idn_mapping(self, timeout_ms: int = 5000) -> 'ServoMappingInfo':
        """
        读取 AT/MDT (输入/输出) 映射配置

        参数:
            timeout_ms: 超时时间 (毫秒)

        返回:
            ServoMappingInfo 包含 AT 和 MDT 映射信息
        """
        mapping = ServoMappingInfo()

        # 读取 AT 配置 (IDN 0x0010)
        at_data = self.read(self.StandardIDN.AT_CONFIG, 0x40)
        if at_data and len(at_data) >= 4:
            mapping.at_bit_size = 16  # 状态字始终映射
            current_length = struct.unpack('<H', at_data[0:2])[0]
            idn_count = current_length // 2
            for i in range(idn_count):
                offset = 4 + i * 2
                if offset + 1 >= len(at_data):
                    break
                mapped_idn = struct.unpack('<H', at_data[offset:offset+2])[0]
                entry = ServoMappingEntry(idn=mapped_idn)
                # 尝试读取名称
                name = self.read_string(mapped_idn)
                entry.name = name if name else f"IDN 0x{mapped_idn:04X}"
                mapping.at_mapping.append(entry)

        # 读取 MDT 配置 (IDN 0x0018)
        mdt_data = self.read(self.StandardIDN.MDT_CONFIG, 0x40)
        if mdt_data and len(mdt_data) >= 4:
            mapping.mdt_bit_size = 16  # 命令字始终映射
            current_length = struct.unpack('<H', mdt_data[0:2])[0]
            idn_count = current_length // 2
            for i in range(idn_count):
                offset = 4 + i * 2
                if offset + 1 >= len(mdt_data):
                    break
                mapped_idn = struct.unpack('<H', mdt_data[offset:offset+2])[0]
                entry = ServoMappingEntry(idn=mapped_idn)
                name = self.read_string(mapped_idn)
                entry.name = name if name else f"IDN 0x{mapped_idn:04X}"
                mapping.mdt_mapping.append(entry)

        return mapping

    def get_all_drive_mappings(self, timeout_ms: int = 5000) -> Dict[int, 'ServoMappingInfo']:
        """
        获取所有驱动器的 AT/MDT 映射 (遍历最多 8 个驱动器)

        参数:
            timeout_ms: 超时时间 (毫秒)

        返回:
            驱动器编号到映射信息的字典
        """
        result: Dict[int, ServoMappingInfo] = {}
        for drive_no in range(8):
            try:
                mapping = self.get_idn_mapping(timeout_ms)
                if mapping.at_mapping or mapping.mdt_mapping:
                    result[drive_no] = mapping
            except Exception:
                pass
        return result

    # ===================== 委托到基类 SoE 的方法 =====================

    def get_available_idns(self) -> List[int]:
        """获取驱动器支持的所有 IDN 列表 (委托到基类 SoE)"""
        return super().get_available_idns()

    def get_monitored_idns(self) -> List[int]:
        """获取当前正在监控的 IDN 列表 (委托到基类 SoE)"""
        return super().get_monitored_idns()

    # ===================== 通知管理 =====================

    def __init_notifications(self):
        """初始化通知管理 (延迟初始化)"""
        if not hasattr(self, '_monitored_idns'):
            self._monitored_idns: Dict[int, Optional[bytes]] = {}
            self._monitor_lock = threading.Lock()
            self._notification_callbacks: List[Callable[[SoENotificationEventArgs], None]] = []

    def on_notification(self, callback: Callable[['SoENotificationEventArgs'], None]):
        """注册通知回调"""
        self.__init_notifications()
        self._notification_callbacks.append(callback)

    def enable_notification(self, idn: int, timeout_ms: int = 500) -> bool:
        """
        启用指定 IDN 的参数变化通知

        参数:
            idn:        要监控的 IDN 编号
            timeout_ms: 超时时间 (毫秒)

        返回:
            True 表示从站确认启用; False 表示回退到轮询模式
        """
        self.__init_notifications()
        hardware = False
        try:
            hardware = self.write(self.StandardIDN.NOTIFICATION_REQUEST,
                                  struct.pack('<H', idn), 0)
        except Exception:
            pass

        current_value = self.read(idn, 0x40)
        with self._monitor_lock:
            self._monitored_idns[idn] = current_value

        return hardware

    def disable_notification(self, idn: int):
        """禁用指定 IDN 的参数变化通知"""
        self.__init_notifications()
        with self._monitor_lock:
            self._monitored_idns.pop(idn, None)

    def disable_all_notifications(self):
        """禁用所有通知"""
        self.__init_notifications()
        with self._monitor_lock:
            self._monitored_idns.clear()

    def monitored_idns(self) -> List[int]:
        """获取当前正在监控的 IDN 列表"""
        self.__init_notifications()
        with self._monitor_lock:
            return list(self._monitored_idns.keys())

    def poll_notifications(self, timeout_ms: int = 200) -> int:
        """
        轮询检测所有已监控 IDN 的参数变化

        参数:
            timeout_ms: 每个 IDN 读取的超时时间 (毫秒)

        返回:
            检测到变化的 IDN 数量
        """
        self.__init_notifications()
        with self._monitor_lock:
            if not self._monitored_idns:
                return 0
            idns_to_check = list(self._monitored_idns.keys())

        changed_count = 0
        for idn in idns_to_check:
            try:
                new_value = self.read(idn, 0x40)
                with self._monitor_lock:
                    old_value = self._monitored_idns.get(idn)

                if new_value != old_value:
                    with self._monitor_lock:
                        if idn in self._monitored_idns:
                            self._monitored_idns[idn] = new_value

                    changed_count += 1
                    args = SoENotificationEventArgs(
                        slave_index=0,
                        drive_number=0,
                        idn=idn,
                        new_value=new_value,
                        old_value=old_value,
                    )
                    for cb in self._notification_callbacks:
                        try:
                            cb(args)
                        except Exception:
                            pass
            except Exception:
                pass

        return changed_count


# ===================== 映射数据类 =====================

class ServoMappingEntry:
    """SoE IDN 映射条目"""

    def __init__(self, idn: int = 0, name: str = "", bit_length: int = 0):
        self.idn = idn
        self.name = name
        self.bit_length = bit_length

    @property
    def byte_length(self) -> int:
        """数据长度 (字节)"""
        return (self.bit_length + 7) // 8


class ServoMappingInfo:
    """SoE AT/MDT 映射信息"""

    def __init__(self):
        self.at_mapping: List[ServoMappingEntry] = []
        self.mdt_mapping: List[ServoMappingEntry] = []
        self.at_bit_size: int = 0
        self.mdt_bit_size: int = 0

    @property
    def at_byte_size(self) -> int:
        """AT 总字节数"""
        return (self.at_bit_size + 7) // 8

    @property
    def mdt_byte_size(self) -> int:
        """MDT 总字节数"""
        return (self.mdt_bit_size + 7) // 8


# ===================== SoE 异常 =====================

class SoEException(Exception):
    """SoE 专用异常类型"""
    pass


# ===================== SoE 管理器 =====================

class ServoDriveManager:
    """
    SoE 参数管理器
    对应 C# ServoDriveManager 类
    提供批量读取、参数属性等封装

    需要一个 SoEAdvanced 实例来执行实际读写。
    如果未提供 soe_instance, 则仅返回带默认属性的参数对象。
    """

    # 标准 Sercos IDN 子集
    STANDARD_IDNS = [
        0x0000,  # IDN of all IDNs
        0x0001,  # Control unit cycle time
        0x0002,  # Position data scaling type
        0x0003,  # Position data scaling factor
        0x0004,  # Position data scaling exponent
        0x0010,  # Drive status
        0x0011,  # Position feedback value 1
        0x0012,  # Position command value
        0x0013,  # Velocity feedback value
        0x0014,  # Velocity command value
        0x0015,  # Torque/force feedback value
        0x0016,  # Torque/force command value
        0x0021,  # Positioning window
        0x0024,  # Maximum velocity
        0x0032,  # Drive control
        0x0033,  # Position command value from interpolator
        0x0040,  # Drive control word
        0x0047,  # Drive status word
    ]

    # 常见 IDN 名称映射
    _IDN_NAMES = {
        0x0000: "IDN List of all IDNs",
        0x0001: "Control Unit Cycle Time",
        0x0002: "Position Data Scaling Type",
        0x0003: "Position Data Scaling Factor",
        0x0004: "Position Data Scaling Exponent",
        0x0010: "Drive Status",
        0x0011: "Position Feedback Value 1",
        0x0012: "Position Command Value",
        0x0013: "Velocity Feedback Value",
        0x0014: "Velocity Command Value",
        0x0015: "Torque/Force Feedback Value",
        0x0016: "Torque/Force Command Value",
        0x0021: "Positioning Window",
        0x0024: "Maximum Velocity",
        0x0032: "Drive Control",
        0x0033: "Position Command Value from Interpolator",
        0x0040: "Drive Control Word",
        0x0047: "Drive Status Word",
    }

    def __init__(self, master_number: int, slave_index: int, drive_number: int = 0,
                 soe_instance: Optional['SoEAdvanced'] = None):
        self.master_number = master_number
        self.slave_index = slave_index
        self.drive_number = drive_number
        self._soe = soe_instance

    def read_all_parameters(self) -> List[SoEParameter]:
        """
        批量读取常见 SoE 参数 (对齐 C# ServoDriveManager.ReadAllParameters)

        遍历标准 Sercos IDN 子集, 跳过读取失败的条目。

        返回:
            成功读取到的参数列表
        """
        parameters: List[SoEParameter] = []
        for idn in self.STANDARD_IDNS:
            try:
                param = self.read_parameter(idn)
                parameters.append(param)
            except Exception:
                pass  # 跳过读取失败的 IDN
        return parameters

    def read_parameter(self, idn: int) -> SoEParameter:
        """
        读取单个 SoE 参数的元信息与当前值 (对齐 C# ServoDriveManager.ReadParameter)

        如果提供了 soe_instance, 使用 get_parameter_info 获取完整信息;
        否则返回带默认属性的参数对象。

        参数:
            idn: 参数 IDN

        返回:
            SoEParameter 实例
        """
        if self._soe is not None:
            return self._soe.get_parameter_info(idn)

        # 无 SoE 实例时返回带默认名称的参数对象
        param = SoEParameter(idn=idn)
        param.name = self._IDN_NAMES.get(idn, f"IDN 0x{idn:04X}")
        return param

    def get_parameter_info(self, idn: int, timeout_ms: int = 5000) -> SoEParameter:
        """获取参数信息 (对齐 C# ServoDriveManager.GetParameterInfo)"""
        return self.read_parameter(idn)

    def write_parameter(self, idn: int, value: bytes) -> bool:
        """
        写入 SoE 参数 (对齐 C# ServoDriveManager.WriteParameter)

        参数:
            idn:   参数 IDN
            value: 要写入的字节数据

        返回:
            写入成功返回 True

        异常:
            ValueError: value 为空时
        """
        if not value:
            raise ValueError("Value cannot be empty")

        if self._soe is not None:
            return self._soe.write(idn, value)

        # 无 SoE 实例时无法执行写入
        raise RuntimeError("SoE 实例未初始化, 无法执行写入操作")


def format_byte_array(data: bytes, attributes: Optional[SoEAttributes] = None) -> str:
    """
    字节数组格式化为十六进制字符串
    对应 C# FormatByteArray 方法

    根据 SoE 属性的数据类型进行智能格式化:
    - UInt/Int: 数值显示
    - Hexadecimal: 十六进制显示
    - String: 字符串显示
    - Float: 浮点数显示
    - 默认: 十六进制字节序列

    参数:
        data:       字节数组
        attributes: SoE 属性 (可选), 用于确定格式化方式
    返回:
        格式化后的字符串
    """
    if data is None or len(data) == 0:
        return ""

    if attributes is None:
        # 默认: 十六进制字节序列
        return ' '.join(f'{b:02X}' for b in data)

    dt = attributes.data_type

    if dt == SoEDataType.String:
        # 字符串类型: UTF-8 → ASCII → Latin-1 兜底 (与 C# 同步)
        try:
            return convert_byte_array_to_string(data)
        except Exception:
            return ' '.join(f'{b:02X}' for b in data)

    if dt == SoEDataType.UInt:
        # 无符号整数
        if len(data) == 1:
            return str(data[0])
        elif len(data) == 2:
            return str(int.from_bytes(data[:2], 'little', signed=False))
        elif len(data) == 4:
            return str(int.from_bytes(data[:4], 'little', signed=False))
        elif len(data) == 8:
            return str(int.from_bytes(data[:8], 'little', signed=False))

    if dt == SoEDataType.Int:
        # 有符号整数
        if len(data) == 1:
            return str(int.from_bytes(data[:1], 'little', signed=True))
        elif len(data) == 2:
            return str(int.from_bytes(data[:2], 'little', signed=True))
        elif len(data) == 4:
            return str(int.from_bytes(data[:4], 'little', signed=True))
        elif len(data) == 8:
            return str(int.from_bytes(data[:8], 'little', signed=True))

    if dt == SoEDataType.Float:
        import struct as st
        if len(data) == 4:
            return f"{st.unpack('<f', data[:4])[0]:.6g}"
        elif len(data) == 8:
            return f"{st.unpack('<d', data[:8])[0]:.10g}"

    if dt == SoEDataType.Hexadecimal:
        return '0x' + data.hex().upper()

    # 默认: 十六进制字节序列
    return ' '.join(f'{b:02X}' for b in data)


# =============================================================================
# SoE Notification / Emergency 全局回调 (ETG.1020 OpCode=5/6)
# =============================================================================
# 对齐 C# Events.cs 中 RegisterSoENotificationCallback /
# RegisterSoEEmergencyCallback 的封装层: DLL 触发的 notification/emergency
# 帧由此模块分发给用户注册的 Python 回调列表.
#
# 注意:
#   - DLL 回调在邮箱接收线程上下文中同步触发, 回调处理必须快速返回.
#   - data 指针指向驱动器临时缓冲, 仅回调期间有效; 用户回调若要持久化,
#     应立即 bytes() 复制.
#   - 全局单实例分发器 (DLL 只允许注册一个回调函数), 多个 Python 观察者
#     通过订阅列表复用.

_soe_notification_listeners: List[Callable[[SoENotificationEventArgs], None]] = []
_soe_emergency_listeners: List[Callable[[SoEEmergencyEventArgs], None]] = []
_soe_listener_lock = threading.Lock()
_soe_notification_cb_ref = None  # 防 GC
_soe_emergency_cb_ref = None


def _soe_dispatch_notification(master_index, slave_index, drive_no, idn,
                               element_flags, data_ptr, data_len):
    """内部: DLL 通知回调 trampoline, 转发给所有已注册的 Python listener."""
    try:
        buf = bytes(ctypes.string_at(data_ptr, data_len)) \
            if (data_ptr and data_len > 0) else None
    except Exception:
        buf = None
    args = SoENotificationEventArgs(
        slave_index=slave_index, drive_number=drive_no, idn=idn,
        element_flags=element_flags, new_value=buf,
    )
    # 快照复制, 避免回调内 add/remove 死锁
    with _soe_listener_lock:
        snapshot = list(_soe_notification_listeners)
    for cb in snapshot:
        try:
            cb(args)
        except Exception:
            pass


def _soe_dispatch_emergency(master_index, slave_index, drive_no, error_code):
    """内部: DLL 紧急回调 trampoline."""
    args = SoEEmergencyEventArgs(
        slave_index=slave_index, drive_number=drive_no, error_code=error_code,
    )
    with _soe_listener_lock:
        snapshot = list(_soe_emergency_listeners)
    for cb in snapshot:
        try:
            cb(args)
        except Exception:
            pass


def _ensure_soe_callbacks_registered(dll):
    """首次订阅时向 DLL 注册全局 trampoline (幂等)."""
    global _soe_notification_cb_ref, _soe_emergency_cb_ref
    if _soe_notification_cb_ref is None:
        fn = getattr(dll, 'RegisterSoENotificationCallback', None)
        if fn is not None:
            _soe_notification_cb_ref = SoENotificationCallbackType(
                _soe_dispatch_notification
            )
            try:
                fn(_soe_notification_cb_ref)
            except Exception:
                _soe_notification_cb_ref = None
    if _soe_emergency_cb_ref is None:
        fn = getattr(dll, 'RegisterSoEEmergencyCallback', None)
        if fn is not None:
            _soe_emergency_cb_ref = SoEEmergencyCallbackType(
                _soe_dispatch_emergency
            )
            try:
                fn(_soe_emergency_cb_ref)
            except Exception:
                _soe_emergency_cb_ref = None


def add_soe_notification_callback(
        callback: Callable[[SoENotificationEventArgs], None]) -> None:
    """
    注册 SoE Notification 回调 (对齐 C# Events.SoENotificationReceived +=).

    DLL 在邮箱接收线程同步触发. 回调应快速返回.
    """
    from ..utils.dll import DarraCoreDLL
    try:
        dll = DarraCoreDLL()
        _ensure_soe_callbacks_registered(dll._dll)
    except Exception:
        pass
    with _soe_listener_lock:
        if callback not in _soe_notification_listeners:
            _soe_notification_listeners.append(callback)


def remove_soe_notification_callback(
        callback: Callable[[SoENotificationEventArgs], None]) -> None:
    """移除已注册的 Notification 回调 (对齐 C# -=)."""
    with _soe_listener_lock:
        if callback in _soe_notification_listeners:
            _soe_notification_listeners.remove(callback)


def add_soe_emergency_callback(
        callback: Callable[[SoEEmergencyEventArgs], None]) -> None:
    """
    注册 SoE Emergency 回调 (对齐 C# Events.SoEEmergencyReceived +=).
    """
    from ..utils.dll import DarraCoreDLL
    try:
        dll = DarraCoreDLL()
        _ensure_soe_callbacks_registered(dll._dll)
    except Exception:
        pass
    with _soe_listener_lock:
        if callback not in _soe_emergency_listeners:
            _soe_emergency_listeners.append(callback)


def remove_soe_emergency_callback(
        callback: Callable[[SoEEmergencyEventArgs], None]) -> None:
    """移除已注册的 Emergency 回调 (对齐 C# -=)."""
    with _soe_listener_lock:
        if callback in _soe_emergency_listeners:
            _soe_emergency_listeners.remove(callback)


# 便利别名, 对齐任务清单要求的精确名字
def add_notification_callback(
        callback: Callable[[SoENotificationEventArgs], None]) -> None:
    """Alias of :func:`add_soe_notification_callback`."""
    add_soe_notification_callback(callback)


def add_emergency_callback(
        callback: Callable[[SoEEmergencyEventArgs], None]) -> None:
    """Alias of :func:`add_soe_emergency_callback`."""
    add_soe_emergency_callback(callback)


# 同时把方法挂到 SoE 类上, 供 slave.soe.add_notification_callback(cb) 调用
SoE.add_notification_callback = staticmethod(add_notification_callback)
SoE.add_emergency_callback = staticmethod(add_emergency_callback)
SoE.remove_notification_callback = staticmethod(remove_soe_notification_callback)
SoE.remove_emergency_callback = staticmethod(remove_soe_emergency_callback)

