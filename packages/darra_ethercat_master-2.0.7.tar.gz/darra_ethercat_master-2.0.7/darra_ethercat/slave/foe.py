# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/FoE.cs
FoE (File over EtherCAT) 协议接口
提供文件传输功能 (固件升级等)
"""

import asyncio
import ctypes
import threading
from concurrent.futures import ThreadPoolExecutor
from ctypes import c_int, c_void_p, byref
from typing import Optional, Callable

from dataclasses import dataclass
from datetime import datetime

from ..data.types import FoEErrorCode
from ..utils.dll import (
    DarraCoreDLL, FoEOptions, FoEProgressCallbackType, FoEBusyCallbackType,
    EcMbxStatsT,
)
from ..abstractions import IMailboxProtocol, MailboxStatistics


@dataclass
class FoEBusyEvent:
    """
    FoE BUSY 进度事件参数 (ETG.1000.6 Table 93 Done/Entire/BusyText).

    对齐 C# DLL.FoEBusyCallback 回调签名. 当从站 Flash 烧写过程中周期返回
    BUSY 帧时由 DLL 触发, 携带已完成量 / 总量 / 可选文本 / 重试序号.
    """
    slave_index: int = 0
    done: int = 0
    entire: int = 0
    text: str = ""
    retry_index: int = 0

    @property
    def percent(self) -> float:
        """完成百分比 (0..100). entire=0 时返回 0."""
        return (100.0 * self.done / self.entire) if self.entire > 0 else 0.0


# =============================================================================
# 异步支持 (asyncio) — 对齐 C# FoEInstance.DownloadAsync / UploadAsync
# =============================================================================
# FoE 传输耗时长 (固件升级常达分钟级), 单独使用一个线程池,
# 避免阻塞 CoE/SoE 等短时通讯操作。

_foe_async_executor: Optional[ThreadPoolExecutor] = None
_foe_executor_lock = threading.Lock()


def _get_foe_executor() -> ThreadPoolExecutor:
    """懒创建 FoE 协议专用线程池 (独立于 CoE)"""
    global _foe_async_executor
    if _foe_async_executor is None:
        with _foe_executor_lock:
            if _foe_async_executor is None:
                # FoE 传输并发通常不高 (多个从站固件同时升级), 4 线程足够
                _foe_async_executor = ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="darra-foe-async"
                )
    return _foe_async_executor


def shutdown_foe_async_executor(wait: bool = True) -> None:
    """关闭 FoE 异步线程池 (程序退出前调用)"""
    global _foe_async_executor
    with _foe_executor_lock:
        if _foe_async_executor is not None:
            _foe_async_executor.shutdown(wait=wait)
            _foe_async_executor = None


class FoE:
    """
    FoE (File over EtherCAT) 协议接口
    提供文件传输功能 (固件升级等)
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int, slave_index: int,
                 timeout: int = 30000):
        self._dll = dll
        self._mi = master_index
        self._si = slave_index
        self._timeout_ms = timeout  # 保存毫秒值用于属性访问
        self._timeout = timeout * 1000  # 毫秒转微秒, DLL 期望微秒
        self._progress_cb = None  # 防止回调被 GC
        self.last_error: Optional[FoEErrorCode] = None  # 最近一次FoE错误码
        self._default_password: int = 0
        self._total_packets: int = 0
        self._current_packet: int = 0
        self._on_progress: Optional[Callable[[int, int, int, int], None]] = None

    # ---- 属性 ----

    @property
    def is_supported(self) -> bool:
        """
        从站是否支持 FoE 邮箱协议 (对齐 C# FoEInstance.IsSupported).

        读取 SII mbx_proto bit 3 (ECT_MBXPROT_FOE = 0x08) 判断支持情况.
        DLL 调用失败时保守返回 True (未知能力视为支持).
        """
        try:
            mbx_proto = self._dll.GetSlaveMailboxProto(self._mi, self._si)
            return (mbx_proto & 0x08) != 0
        except Exception:
            return True

    @property
    def last_error_code(self) -> FoEErrorCode:
        """
        最近一次 FoE 操作的错误码 (对齐 C# FoEInstance.LastErrorCode)

        当 download/upload/read/write 失败时, 此属性包含具体的 FoE 错误码。
        成功操作后重置为 FoEErrorCode.NotDefined。
        """
        return self.last_error if self.last_error is not None else FoEErrorCode.NotDefined

    @property
    def default_timeout_ms(self) -> int:
        """默认超时时间（毫秒）"""
        return self._timeout_ms

    @default_timeout_ms.setter
    def default_timeout_ms(self, value: int):
        self._timeout_ms = value
        self._timeout = value * 1000

    @property
    def default_timeout_us(self) -> int:
        """默认超时时间（微秒）- default_timeout_ms 的微秒表示"""
        return self._timeout

    @default_timeout_us.setter
    def default_timeout_us(self, value: int):
        self._timeout = value
        self._timeout_ms = value // 1000

    @property
    def default_password(self) -> int:
        """FoE 操作的默认密码（默认：0）"""
        return self._default_password

    @default_password.setter
    def default_password(self, value: int):
        self._default_password = value

    # ---- 核心方法 ----

    def read(self, filename: str, password: int = 0) -> Optional[bytes]:
        """从从站读取文件"""
        file_ptr = c_void_p(0)
        file_size = c_int(0)
        ok = self._dll.FOERead(
            self._mi, self._si, filename.encode('utf-8'), password,
            byref(file_ptr), byref(file_size), self._timeout
        )
        if not ok or not file_ptr.value or file_size.value <= 0:
            # 读取失败, 记录错误码
            self.last_error = self._map_dll_foe_error(file_size.value) if file_size.value < 0 \
                else FoEErrorCode.NotDefined
            if file_ptr.value:
                self._dll.FreeMemory(file_ptr)
            return None
        try:
            self.last_error = None  # 成功时清除错误码
            return bytes(ctypes.string_at(file_ptr.value, file_size.value))
        finally:
            self._dll.FreeMemory(file_ptr)

    def write(self, filename: str, data: bytes, password: int = 0) -> bool:
        """向从站写入文件"""
        buf = ctypes.create_string_buffer(data)
        ok = bool(self._dll.FOEWrite(
            self._mi, self._si, filename.encode('utf-8'), password,
            ctypes.cast(buf, c_void_p), len(data), self._timeout
        ))
        if ok:
            self.last_error = None  # 成功时清除错误码
        else:
            self.last_error = FoEErrorCode.NotDefined
        return ok

    def download(self, filename: str, password: Optional[int] = None,
                 timeout_ms: Optional[int] = None,
                 enable_crc: bool = False) -> Optional[bytes]:
        """
        从从站设备下载（读取）文件
        对应 C# FoEInstance.Download

        参数:
            filename: 要下载的文件名
            password: FoE 密码（不指定则使用 default_password）
            timeout_ms: 超时时间（毫秒，不指定则使用 default_timeout_ms）
            enable_crc: 启用 CRC 校验

        返回:
            文件内容字节数组，若失败则返回 None
        """
        if not filename:
            raise ValueError("文件名不能为空")
        pwd = password if password is not None else self._default_password
        timeout = timeout_ms * 1000 if timeout_ms is not None else self._timeout

        # 自动管理进度回调
        auto_progress = self._on_progress is not None
        if auto_progress:
            self.enable_progress_hook(0)

        try:
            if enable_crc:
                return self.read_ex(filename, pwd, enable_crc=True,
                                    strict_mode=True)
            file_ptr = c_void_p(0)
            file_size = c_int(0)
            ok = self._dll.FOERead(
                self._mi, self._si, filename.encode('utf-8'), pwd,
                byref(file_ptr), byref(file_size), timeout
            )
            if not ok or not file_ptr.value or file_size.value <= 0:
                # 下载失败, 记录错误码
                self.last_error = self._map_dll_foe_error(file_size.value) if file_size.value < 0 \
                    else FoEErrorCode.NotDefined
                if file_ptr.value:
                    self._dll.FreeMemory(file_ptr)
                return None
            try:
                self.last_error = None  # 成功时清除错误码
                return bytes(ctypes.string_at(file_ptr.value, file_size.value))
            finally:
                self._dll.FreeMemory(file_ptr)
        finally:
            if auto_progress:
                self.disable_progress_hook()

    def upload(self, filename: str, file_data: bytes,
               password: Optional[int] = None,
               timeout_ms: Optional[int] = None,
               enable_crc: bool = False) -> bool:
        """
        上传（写入）文件到从站设备
        对应 C# FoEInstance.Upload

        参数:
            filename: 要上传的文件名
            file_data: 要写入的文件内容
            password: FoE 密码（不指定则使用 default_password）
            timeout_ms: 超时时间（毫秒，不指定则使用 default_timeout_ms）
            enable_crc: 启用 CRC 校验

        返回:
            若成功则返回 True，否则返回 False
        """
        if not filename:
            raise ValueError("文件名不能为空")
        if not file_data:
            raise ValueError("文件数据不能为空")
        pwd = password if password is not None else self._default_password
        timeout = timeout_ms * 1000 if timeout_ms is not None else self._timeout

        # 自动管理进度回调
        auto_progress = self._on_progress is not None
        if auto_progress:
            self.enable_progress_hook(self.estimate_packet_count(len(file_data)))

        try:
            if enable_crc:
                ok = self.write_ex(filename, file_data, pwd,
                                   enable_crc=True, strict_mode=True,
                                   auto_append_crc=True)
                if ok:
                    self.last_error = None
                else:
                    self.last_error = FoEErrorCode.NotDefined
                return ok
            buf = ctypes.create_string_buffer(file_data)
            ok = bool(self._dll.FOEWrite(
                self._mi, self._si, filename.encode('utf-8'), pwd,
                ctypes.cast(buf, c_void_p), len(file_data), timeout
            ))
            if ok:
                self.last_error = None  # 成功时清除错误码
            else:
                self.last_error = FoEErrorCode.NotDefined
            return ok
        finally:
            if auto_progress:
                self.disable_progress_hook()

    # ---- 异步接口 (对齐 C# FoEInstance *Async) ----

    async def download_async(self, filename: str,
                             password: Optional[int] = None,
                             timeout_ms: Optional[int] = None,
                             enable_crc: bool = False) -> Optional[bytes]:
        """
        异步下载文件 (对齐 C# FoEInstance.DownloadAsync)

        参数:
            filename: 要下载的文件名
            password: FoE 密码
            timeout_ms: 超时毫秒数 (同时用于 asyncio 超时与 DLL 内部超时)
            enable_crc: 启用 CRC 校验
        返回:
            文件字节, 失败返回 None
        异常:
            asyncio.TimeoutError: 超过 timeout_ms
        """
        loop = asyncio.get_event_loop()
        fut = loop.run_in_executor(
            _get_foe_executor(),
            self.download, filename, password, timeout_ms, enable_crc,
        )
        if timeout_ms and timeout_ms > 0:
            # asyncio 超时留 1.5x 余量, 让 DLL 内部超时先到
            return await asyncio.wait_for(fut, timeout=timeout_ms * 1.5 / 1000.0)
        return await fut

    async def upload_async(self, filename: str, file_data: bytes,
                           password: Optional[int] = None,
                           timeout_ms: Optional[int] = None,
                           enable_crc: bool = False) -> bool:
        """
        异步上传文件 (对齐 C# FoEInstance.UploadAsync)

        参数:
            filename: 要上传的文件名
            file_data: 文件内容
            password: FoE 密码
            timeout_ms: 超时毫秒数
            enable_crc: 启用 CRC 校验
        返回:
            上传是否成功
        """
        loop = asyncio.get_event_loop()
        fut = loop.run_in_executor(
            _get_foe_executor(),
            self.upload, filename, file_data, password, timeout_ms, enable_crc,
        )
        if timeout_ms and timeout_ms > 0:
            return await asyncio.wait_for(fut, timeout=timeout_ms * 1.5 / 1000.0)
        return await fut

    async def read_async(self, filename: str,
                         password: int = 0) -> Optional[bytes]:
        """异步原始读 (对齐 C# FoEInstance.ReadAsync)"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            _get_foe_executor(), self.read, filename, password
        )

    async def write_async(self, filename: str, data: bytes,
                          password: int = 0) -> bool:
        """异步原始写 (对齐 C# FoEInstance.WriteAsync)"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            _get_foe_executor(), self.write, filename, data, password
        )

    # ---- 进度回调 ----

    def set_progress_callback(self, callback: Optional[Callable[[int, int, int], None]]) -> bool:
        """
        设置 FoE 进度回调

        参数:
            callback: 回调函数 (slave, packet_number, data_size)，None 清除回调
        """
        if callback is None:
            self._progress_cb = None
            self._on_progress = None
            return bool(self._dll.FOEClearProgressHook(self._mi))

        @FoEProgressCallbackType
        def _cb(slave, packetnumber, datasize):
            callback(slave, packetnumber, datasize)

        self._progress_cb = _cb
        self._on_progress = callback
        return bool(self._dll.FOESetProgressHook(self._mi, _cb))

    def enable_progress_hook(self, estimated_total_packets: int = 0) -> bool:
        """
        启用 FoE 进度回调 Hook
        对应 C# FoEInstance.EnableProgressHook

        参数:
            estimated_total_packets: 估算的总数据包数（用于计算进度百分比，0=不估算）

        返回:
            成功返回 True
        """
        self._total_packets = estimated_total_packets
        self._current_packet = 0

        @FoEProgressCallbackType
        def _cb(slave, packetnumber, datasize):
            self._current_packet = packetnumber
            # 计算进度百分比
            if self._total_packets > 0:
                percent = min(100, int(packetnumber * 100.0 / self._total_packets))
            else:
                percent = min(99, packetnumber)
            if self._on_progress:
                self._on_progress(slave, packetnumber, datasize, percent)

        self._progress_cb = _cb
        return bool(self._dll.FOESetProgressHook(self._mi, _cb))

    def disable_progress_hook(self) -> bool:
        """
        禁用 FoE 进度回调 Hook
        对应 C# FoEInstance.DisableProgressHook

        返回:
            成功返回 True
        """
        result = bool(self._dll.FOEClearProgressHook(self._mi))
        self._progress_cb = None
        self._total_packets = 0
        self._current_packet = 0
        return result

    # ---- 取消 / 恢复 (对齐 C# DLL.FOERequestCancel / FOEClearCancel) ----

    def cancel(self) -> bool:
        """
        请求取消进行中的 FoE 传输 (透传 ec_foe.c 取消标志).

        对齐 C# DLL.FOERequestCancel. 下一次循环迭代起生效.
        DLL 未导出时返回 False (SDK 早期版本).
        """
        fn = getattr(self._dll, 'FOERequestCancel', None)
        if fn is None:
            return False
        try:
            return bool(fn(self._mi, self._si))
        except Exception:
            return False

    def clear_cancel(self) -> bool:
        """
        清除 FoE 取消标志 (异常复位用).

        对齐 C# DLL.FOEClearCancel. Read/Write 入口会自动清零, 通常不需手动调.
        """
        fn = getattr(self._dll, 'FOEClearCancel', None)
        if fn is None:
            return False
        try:
            return bool(fn(self._mi, self._si))
        except Exception:
            return False

    # ---- BUSY Hook (ETG.1000.6 Table 93, 对齐 C# DLL.FOESetBusyHook) ----

    def set_busy_hook(self,
                      callback: Optional[Callable[['FoEBusyEvent'], None]]
                      ) -> bool:
        """
        设置 FoE BUSY 回调. 从站 Flash 烧写过程中周期触发.

        对齐 C# DLL.FOESetBusyHook + FoE.BusyReceived 事件.

        Args:
            callback: 回调 ``fn(FoEBusyEvent)``. None = 清除 hook.

        Returns:
            DLL 操作是否成功. DLL 未导出时返回 False, callback 不会触发.
        """
        fn = getattr(self._dll, 'FOESetBusyHook', None)
        if fn is None:
            return False
        if callback is None:
            self._busy_cb = None
            try:
                return bool(fn(self._mi, None))
            except Exception:
                return False

        @FoEBusyCallbackType
        def _trampoline(slave, done, entire, text_ptr, retry_idx):
            try:
                text_str = text_ptr.decode('utf-8', errors='replace') \
                    if text_ptr else ""
            except Exception:
                text_str = ""
            evt = FoEBusyEvent(
                slave_index=slave, done=done, entire=entire,
                text=text_str, retry_index=retry_idx,
            )
            try:
                callback(evt)
            except Exception:
                pass

        self._busy_cb = _trampoline  # 防 GC
        try:
            return bool(fn(self._mi, _trampoline))
        except Exception:
            return False

    @staticmethod
    def estimate_packet_count(file_size: int, mailbox_size: int = 512) -> int:
        """
        估算文件传输所需的数据包数量
        对应 C# FoEInstance.EstimatePacketCount

        参数:
            file_size: 文件大小（字节）
            mailbox_size: 邮箱大小（字节，默认 512）

        返回:
            估算的数据包数量
        """
        if file_size <= 0 or mailbox_size <= 0:
            return 0
        # FoE 数据包头占用约 6 字节
        data_per_packet = mailbox_size - 6
        if data_per_packet <= 0:
            data_per_packet = 128
        return (file_size + data_per_packet - 1) // data_per_packet

    # ---- 错误码映射 ----

    @staticmethod
    def _map_dll_foe_error(dll_error_code: int) -> FoEErrorCode:
        """将DLL错误码映射到FoE错误码"""
        abs_code = abs(dll_error_code)
        _MAP = {
            5:  FoEErrorCode.NotDefined,          # EC_ERR_TYPE_FOE_ERROR
            6:  FoEErrorCode.NotDefined,           # EC_ERR_TYPE_FOE_BUF2SMALL
            7:  FoEErrorCode.PacketNumberWrong,    # EC_ERR_TYPE_FOE_PACKETNUMBER
            10: FoEErrorCode.NotFound,
            12: FoEErrorCode.AccessDenied,
            13: FoEErrorCode.DiskFull,
            14: FoEErrorCode.Illegal,
            15: FoEErrorCode.PacketNumberWrong,
            16: FoEErrorCode.AlreadyExists,
            17: FoEErrorCode.NoUser,
            18: FoEErrorCode.BootstrapOnly,
            19: FoEErrorCode.NotBootstrap,
            20: FoEErrorCode.NoRights,
            21: FoEErrorCode.ProgramError,
        }
        return _MAP.get(abs_code, FoEErrorCode.NotDefined)

    # ---- 扩展方法 ----

    def read_ex(self, filename: str, password: int = 0,
                enable_crc: bool = False, strict_mode: bool = False,
                expected_crc: int = 0) -> Optional[bytes]:
        """
        扩展文件读取 (支持 CRC 校验)

        参数:
            filename: 文件名
            password: 密码
            enable_crc: 启用 CRC 校验
            strict_mode: 严格模式 (CRC 不匹配时失败)
            expected_crc: 预期 CRC 值
        """
        opts = FoEOptions()
        opts.enable_crc = 1 if enable_crc else 0
        opts.strict_mode = 1 if strict_mode else 0
        opts.expected_crc = expected_crc
        file_ptr = c_void_p(0)
        file_size = c_int(0)
        ok = self._dll.FOEReadEx(
            self._mi, self._si, filename.encode('utf-8'), password,
            byref(file_ptr), byref(file_size), self._timeout, byref(opts)
        )
        if not ok or not file_ptr.value or file_size.value <= 0:
            if file_ptr.value:
                self._dll.FreeMemory(file_ptr)
            return None
        try:
            return bytes(ctypes.string_at(file_ptr.value, file_size.value))
        finally:
            self._dll.FreeMemory(file_ptr)

    def write_ex(self, filename: str, data: bytes, password: int = 0,
                 enable_crc: bool = False, strict_mode: bool = False,
                 auto_append_crc: bool = False) -> bool:
        """
        扩展文件写入 (支持 CRC 校验)

        参数:
            filename: 文件名
            data: 文件数据
            password: 密码
            enable_crc: 启用 CRC 校验
            strict_mode: 严格模式
            auto_append_crc: 自动附加 CRC 到文件名
        """
        opts = FoEOptions()
        opts.enable_crc = 1 if enable_crc else 0
        opts.strict_mode = 1 if strict_mode else 0
        opts.auto_append_crc = 1 if auto_append_crc else 0
        buf = ctypes.create_string_buffer(data)
        return bool(self._dll.FOEWriteEx(
            self._mi, self._si, filename.encode('utf-8'), password,
            ctypes.cast(buf, c_void_p), len(data), self._timeout, byref(opts)
        ))


    @staticmethod
    def get_error_description(error_code: FoEErrorCode) -> str:
        """
        获取 FoE 错误代码的中文描述文本 (对齐 C# GetErrorDescription)

        参数:
            error_code: 错误代码

        返回:
            错误描述字符串
        """
        _desc = {
            FoEErrorCode.NotDefined:       "未定义错误",
            FoEErrorCode.NotFound:         "文件未找到",
            FoEErrorCode.AccessDenied:     "访问被拒绝",
            FoEErrorCode.DiskFull:         "磁盘已满",
            FoEErrorCode.Illegal:          "非法操作",
            FoEErrorCode.PacketNumberWrong:"数据包序号错误",
            FoEErrorCode.AlreadyExists:    "文件已存在",
            FoEErrorCode.NoUser:           "无此用户",
            FoEErrorCode.BootstrapOnly:    "仅 Bootstrap 模式可用",
            FoEErrorCode.NotBootstrap:     "不在 Bootstrap 模式",
            FoEErrorCode.NoRights:         "权限不足",
            FoEErrorCode.ProgramError:     "程序错误",
        }
        return _desc.get(error_code, f"未知错误 (0x{int(error_code):04X})")


# =============================================================================
# IMailboxProtocol 接口实现 (对齐 C# IMailboxProtocol)
# =============================================================================

_FOE_PROTOCOL_TYPE = 0x04  # ECT_MBXT_FOE


def _foe_protocol_type(self) -> int:
    return _FOE_PROTOCOL_TYPE


def _foe_protocol_name(self) -> str:
    return "FoE"


def _foe_statistics(self) -> MailboxStatistics:
    """读取 FoE 邮箱统计快照."""
    try:
        stats = EcMbxStatsT()
        rc = self._dll.mbx_get_stats_by_master(
            self._mi, self._si, _FOE_PROTOCOL_TYPE, ctypes.byref(stats)
        )
        if rc == 1:
            avg = (stats.total_latency_us / stats.total_received
                   if stats.total_received > 0 else 0.0)
            t = None
            if stats.last_error_time_us > 0:
                from datetime import datetime, timezone
                t = datetime.fromtimestamp(
                    stats.last_error_time_us / 1_000_000, tz=timezone.utc
                )
            return MailboxStatistics(
                total_sent=stats.total_sent,
                total_received=stats.total_received,
                total_timeout=stats.total_timeout,
                total_mailbox_error=stats.total_mbx_error,
                total_protocol_error=stats.total_proto_error,
                total_cancelled=stats.total_cancelled,
                last_error_code=stats.last_error_code,
                last_error_time=t,
                average_latency_us=avg,
            )
    except Exception:
        pass
    return MailboxStatistics.empty()


def _foe_reset_statistics(self) -> None:
    """重置 FoE 邮箱统计."""
    try:
        self._dll.mbx_reset_stats_by_master(
            self._mi, self._si, _FOE_PROTOCOL_TYPE
        )
    except Exception:
        pass


FoE.protocol_type = property(_foe_protocol_type)
FoE.protocol_name = property(_foe_protocol_name)
FoE.statistics = property(_foe_statistics)
FoE.reset_statistics = _foe_reset_statistics

IMailboxProtocol.register(FoE)


__all__ = ['FoE']
