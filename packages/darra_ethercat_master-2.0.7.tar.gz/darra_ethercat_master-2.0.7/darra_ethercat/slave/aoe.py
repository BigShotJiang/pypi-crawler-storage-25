# -*- coding: utf-8 -*-
"""
对应 C# 文件: Slave/AoE.cs
AoE (ADS over EtherCAT) 高级功能模块

包含:
- AoETransmissionMode: 通知传输模式枚举
- AoESubscription: 通知订阅记录
- AoESubscriptionManager: 订阅管理器
"""

import asyncio
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Callable, Dict, List, Optional

import ctypes

from .core import AoE
from ..utils.dll import EcMbxStatsT
from ..abstractions import IMailboxProtocol, MailboxStatistics


# =============================================================================
# AoE 能力检测 (对齐 C# AoEInstance.IsSupported)
# =============================================================================
# 通过 DLL.GetSlaveMailboxProto 读 SII mbx_proto bit 0 (ECT_MBXPROT_AOE = 0x01).
# DLL 调用失败时保守返回 True (未知能力视为支持).

def _aoe_is_supported(self) -> bool:
    """
    从站是否支持 AoE 邮箱协议 (对齐 C# AoEInstance.IsSupported).

    读取 SII mbx_proto bit 0 (ECT_MBXPROT_AOE = 0x01) 判断支持情况.
    DLL 调用失败时保守返回 True.
    """
    try:
        mbx_proto = self._dll.GetSlaveMailboxProto(self._mi, self._si)
        return (mbx_proto & 0x01) != 0
    except Exception:
        return True


# 在 AoE 类上挂载 is_supported 属性 (不修改 core.py)
AoE.is_supported = property(_aoe_is_supported)


# =============================================================================
# IMailboxProtocol 接口实现 (对齐 C# IMailboxProtocol)
# =============================================================================

_AOE_PROTOCOL_TYPE = 0x01  # ECT_MBXT_AOE


def _aoe_protocol_type(self) -> int:
    return _AOE_PROTOCOL_TYPE


def _aoe_protocol_name(self) -> str:
    return "AoE"


def _aoe_statistics(self) -> MailboxStatistics:
    """读取 AoE 邮箱统计快照."""
    try:
        stats = EcMbxStatsT()
        rc = self._dll.mbx_get_stats_by_master(
            self._mi, self._si, _AOE_PROTOCOL_TYPE, ctypes.byref(stats)
        )
        if rc == 1:
            avg = (stats.total_latency_us / stats.total_received
                   if stats.total_received > 0 else 0.0)
            t = None
            if stats.last_error_time_us > 0:
                from datetime import datetime, timezone
                t = datetime.fromtimestamp(
                    stats.last_error_time_us / 1_000_000, tz=timezone.utc
                )
            return MailboxStatistics(
                total_sent=stats.total_sent,
                total_received=stats.total_received,
                total_timeout=stats.total_timeout,
                total_mailbox_error=stats.total_mbx_error,
                total_protocol_error=stats.total_proto_error,
                total_cancelled=stats.total_cancelled,
                last_error_code=stats.last_error_code,
                last_error_time=t,
                average_latency_us=avg,
            )
    except Exception:
        pass
    return MailboxStatistics.empty()


def _aoe_reset_statistics(self) -> None:
    """重置 AoE 邮箱统计."""
    try:
        self._dll.mbx_reset_stats_by_master(
            self._mi, self._si, _AOE_PROTOCOL_TYPE
        )
    except Exception:
        pass


AoE.protocol_type = property(_aoe_protocol_type)
AoE.protocol_name = property(_aoe_protocol_name)
AoE.statistics = property(_aoe_statistics)
AoE.reset_statistics = _aoe_reset_statistics

IMailboxProtocol.register(AoE)


# =============================================================================
# 异步支持 (asyncio) — 对齐 C# AoEInstance.*Async
# =============================================================================
# AoE (ADS over EtherCAT) 常用于 TwinCAT 互操作, 读写延迟中等 (10-50ms)。
# 订阅管理本身是本地操作, 但 add/del_notification 经过从站邮箱, 需异步化。

_aoe_async_executor: Optional[ThreadPoolExecutor] = None
_aoe_executor_lock = threading.Lock()


def _get_aoe_executor() -> ThreadPoolExecutor:
    """懒创建 AoE 协议专用线程池"""
    global _aoe_async_executor
    if _aoe_async_executor is None:
        with _aoe_executor_lock:
            if _aoe_async_executor is None:
                _aoe_async_executor = ThreadPoolExecutor(
                    max_workers=4, thread_name_prefix="darra-aoe-async"
                )
    return _aoe_async_executor


def shutdown_aoe_async_executor(wait: bool = True) -> None:
    """关闭 AoE 异步线程池"""
    global _aoe_async_executor
    with _aoe_executor_lock:
        if _aoe_async_executor is not None:
            _aoe_async_executor.shutdown(wait=wait)
            _aoe_async_executor = None


async def _run_aoe_async(func, *args, timeout_ms: Optional[int] = None):
    """通用 AoE 异步执行辅助"""
    loop = asyncio.get_event_loop()
    fut = loop.run_in_executor(_get_aoe_executor(), func, *args)
    if timeout_ms and timeout_ms > 0:
        return await asyncio.wait_for(fut, timeout=timeout_ms / 1000.0)
    return await fut


# =============================================================================
# 模块级异步封装 — 对齐 C# AoEInstance.ReadAsync / WriteAsync
# =============================================================================

async def read_async(aoe: AoE, index_group: int, index_offset: int,
                     length: int,
                     timeout_ms: Optional[int] = None) -> Optional[bytes]:
    """
    异步 ADS 读 (对齐 C# AoEInstance.ReadAsync)

    参数:
        aoe: AoE 实例
        index_group: ADS 索引组 (如 0x4020)
        index_offset: ADS 索引偏移
        length: 要读取的字节数
        timeout_ms: 超时毫秒数
    """
    return await _run_aoe_async(
        aoe.read, index_group, index_offset, length, timeout_ms=timeout_ms
    )


async def write_async(aoe: AoE, index_group: int, index_offset: int,
                      data: bytes,
                      timeout_ms: Optional[int] = None) -> bool:
    """异步 ADS 写 (对齐 C# AoEInstance.WriteAsync)"""
    return await _run_aoe_async(
        aoe.write, index_group, index_offset, data, timeout_ms=timeout_ms
    )


async def read_write_async(aoe: AoE, index_group: int, index_offset: int,
                           read_length: int, write_data: bytes,
                           timeout_ms: Optional[int] = None
                           ) -> Optional[bytes]:
    """异步 ADS ReadWrite (写+读) 操作 (对齐 C# ReadWriteAsync)"""
    # 有些实现名为 read_write, 否则降级为 write + read
    func = getattr(aoe, 'read_write', None)
    if func is not None:
        return await _run_aoe_async(
            func, index_group, index_offset, read_length, write_data,
            timeout_ms=timeout_ms,
        )
    # 降级: 先写再读
    ok = await write_async(aoe, index_group, index_offset, write_data,
                           timeout_ms=timeout_ms)
    if not ok:
        return None
    return await read_async(aoe, index_group, index_offset, read_length,
                            timeout_ms=timeout_ms)


# ===================== 传输模式枚举 (对应 C# AoETransmissionMode) =====================

class AoETransmissionMode(IntEnum):
    """AoE 通知传输模式 (对应 C# AoETransmissionMode)"""
    NO_TRANSMISSION = 0       # 无通知
    CYCLIC = 1                # 循环通知 - 按指定周期发送
    ON_CHANGE = 2             # 变化通知 - 数据变化时发送
    CYCLIC_IN_DEVICE = 3      # 设备端循环通知
    ON_CHANGE_IN_DEVICE = 4   # 设备端变化通知


# ===================== AoE 结果错误码 (ETG.1020 Table 16, 对齐 C# AoEResultCode) =====================

class AoEResultCode(IntEnum):
    """
    AoE 结果错误码 (ETG.1020 Table 16, 对应 C# AoEResultCode).

    数值与 C#/C++/Java/Rust 一致, 高字节 = 错误类 (0x0700=ADS device, 0x0740=client),
    低字节 = 具体错误码.
    """
    NO_ERROR                       = 0x0000  # 无错误
    INTERNAL_ERROR                 = 0x0001  # 内部错误
    NO_REALTIME                    = 0x0002  # 无实时
    ALLOCATION_LOCKED_MEMORY_ERROR = 0x0003  # 分配锁定内存错误
    INSERT_MAILBOX_ERROR           = 0x0004  # 邮箱满
    WRONG_RECEIVE_HMSG             = 0x0005  # 命令 ID 错误
    TARGET_PORT_NOT_FOUND          = 0x0006  # 目标端口未找到
    TARGET_MACHINE_NOT_FOUND       = 0x0007  # 目标设备未找到
    UNKNOWN_COMMAND_ID             = 0x0008  # 命令 ID 未知
    BAD_TASK_ID                    = 0x0009  # 无效 Task ID
    NO_IO                          = 0x000A  # 无 IO
    UNKNOWN_AMS_COMMAND            = 0x000B  # 未知 AMS 命令
    WIN32_ERROR                    = 0x000C  # Win32 错误
    PORT_NOT_CONNECTED             = 0x000D  # 端口未连接
    INVALID_AMS_LENGTH             = 0x000E  # 无效 AMS 长度
    INVALID_AMS_NET_ID             = 0x000F  # 无效 AMS Net ID
    LOW_INST_LEVEL                 = 0x0010  # 低安装等级
    NO_DEBUG_AVAILABLE             = 0x0011  # 无调试可用
    PORT_DISABLED                  = 0x0012  # 端口已禁用
    PORT_ALREADY_CONNECTED         = 0x0013  # 端口已连接
    AMS_SYNC_WIN32_ERROR           = 0x0014  # AMS 同步 Win32 错误
    AMS_SYNC_TIMEOUT               = 0x0015  # AMS 同步超时
    AMS_SYNC_AMS_ERROR             = 0x0016  # AMS 同步 AMS 错误
    AMS_SYNC_NO_INDEX_MAP          = 0x0017  # AMS 同步无索引映射
    INVALID_AMS_PORT               = 0x0018  # 无效 AMS 端口
    NO_MEMORY                      = 0x0019  # 无内存
    TCP_SEND_ERROR                 = 0x001A  # TCP 发送错误
    HOST_UNREACHABLE               = 0x001B  # 主机不可达
    INVALID_AMS_FRAGMENT           = 0x001C  # 无效 AMS 片段
    WSA_SERVICE_NOT_STARTED        = 0x274D  # 设备服务未启动
    DEVICE_INVALID_GROUP           = 0x0700  # 设备无效组
    DEVICE_INVALID_OFFSET          = 0x0701  # 设备无效偏移
    DEVICE_INVALID_ACCESS          = 0x0702  # 设备无效访问
    DEVICE_INVALID_SIZE            = 0x0703  # 设备无效大小
    DEVICE_INVALID_DATA            = 0x0704  # 设备无效数据
    DEVICE_NOT_READY               = 0x0705  # 设备未就绪
    DEVICE_BUSY                    = 0x0706  # 设备忙
    DEVICE_INVALID_CONTEXT         = 0x0707  # 设备无效上下文
    DEVICE_NOT_FOUND               = 0x0708  # 设备不存在
    DEVICE_ALREADY_EXISTS          = 0x0709  # 设备已存在
    DEVICE_SYMBOL_NOT_FOUND        = 0x070A  # 设备符号未找到
    DEVICE_SYMBOL_VERSION_INVALID  = 0x070B  # 设备符号版本无效
    DEVICE_INVALID_STATE           = 0x070C  # 设备状态无效
    DEVICE_TIMEOUT                 = 0x0712  # 设备超时
    DEVICE_NO_INTERFACE_QUERY      = 0x0713  # 设备接口查询不匹配
    DEVICE_INVALID_INTERFACE       = 0x0714  # 设备无效接口
    DEVICE_INVALID_CLASS_ID        = 0x0715  # 设备无效 Class ID
    DEVICE_INVALID_OBJECT_ID       = 0x0716  # 设备无效 Object ID
    DEVICE_PENDING                 = 0x0717  # 设备处于挂起状态
    DEVICE_ABORTED                 = 0x0718  # 设备已中止
    DEVICE_WARNING                 = 0x0719  # 设备警告
    DEVICE_INVALID_ARRAY_INDEX     = 0x071A  # 设备无效数组索引
    DEVICE_SYMBOL_NOT_ACTIVE       = 0x071B  # 设备符号未激活
    DEVICE_ACCESS_DENIED           = 0x071C  # 设备访问被拒绝
    CLIENT_ERROR                   = 0x0740  # 客户端错误
    CLIENT_INVALID_PARAM           = 0x0741  # 客户端无效参数
    CLIENT_LIST_EMPTY              = 0x0742  # 客户端列表为空
    CLIENT_VAR_ALREADY_IN_USE      = 0x0743  # 客户端变量已使用
    CLIENT_INVOKE_TIMEOUT          = 0x0744  # 客户端调用超时
    CLIENT_PORT_NOT_OPEN           = 0x0745  # 客户端端口未打开
    CLIENT_NOT_STARTED             = 0x0746  # 客户端未启动
    CLIENT_QUEUE_FULL              = 0x0750  # 客户端队列满


# ===================== 订阅数据类 (对应 C# AoESubscription) =====================

@dataclass
class AoESubscription:
    """
    AoE 通知订阅记录 (对应 C# AoESubscription)

    包含订阅的完整信息: 句柄、地址、传输模式等
    """
    handle: int
    slave_index: int
    index_group: int
    index_offset: int
    length: int
    callback: Optional[Callable[[bytes], None]] = None
    subscription_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    trans_mode: int = 0
    is_active: bool = True
    tag: object = None

    def __repr__(self) -> str:
        return (f"AoESubscription(id={self.subscription_id[:8]}..., "
                f"handle={self.handle}, slave={self.slave_index}, "
                f"group=0x{self.index_group:08X}, offset=0x{self.index_offset:08X})")


class AoESubscriptionManager:
    """
    AoE 通知订阅管理器 (对应 C# AoESubscriptionManager)

    支持按句柄和按订阅 ID 两种方式管理订阅
    """

    def __init__(self, aoe: AoE):
        self._aoe = aoe
        self._subscriptions: Dict[int, AoESubscription] = {}
        self._subscriptions_by_id: Dict[str, AoESubscription] = {}
        self._lock = threading.Lock()

    def subscribe(self, index_group: int, index_offset: int,
                  length: int,
                  trans_mode: int = AoETransmissionMode.ON_CHANGE,
                  max_delay_ms: int = 0, cycle_time_ms: int = 100,
                  callback: Optional[Callable[[bytes], None]] = None) -> Optional[str]:
        """
        订阅 AoE 通知 (对应 C# Subscribe)

        参数:
            index_group:   索引组
            index_offset:  索引偏移
            length:        数据长度
            trans_mode:    传输模式 (参考 AoETransmissionMode 枚举)
            max_delay_ms:  最大延迟 (毫秒)
            cycle_time_ms: 循环时间 (毫秒)
            callback:      数据通知回调 callback(data: bytes)

        返回:
            订阅 ID 字符串, 失败返回 None
        """
        handle = self._aoe.add_notification(
            index_group, index_offset, length,
            trans_mode, max_delay_ms * 10000,
            cycle_time_ms * 10000
        )
        if handle is None:
            return None
        sub = AoESubscription(
            handle=handle,
            slave_index=self._aoe._si,
            index_group=index_group,
            index_offset=index_offset,
            length=length,
            callback=callback,
            trans_mode=trans_mode,
            is_active=True,
        )
        with self._lock:
            self._subscriptions[handle] = sub
            self._subscriptions_by_id[sub.subscription_id] = sub
        return sub.subscription_id

    def unsubscribe(self, subscription_id: str) -> bool:
        """
        取消指定订阅 ID 的订阅 (对应 C# Unsubscribe)

        参数:
            subscription_id: 订阅 ID 字符串

        返回:
            是否成功取消
        """
        with self._lock:
            sub = self._subscriptions_by_id.pop(subscription_id, None)
            if sub is None:
                return False
            self._subscriptions.pop(sub.handle, None)
        sub.is_active = False
        return self._aoe.del_notification(sub.handle)

    def unsubscribe_by_handle(self, handle: int) -> bool:
        """
        取消指定句柄的订阅 (兼容旧接口)

        参数:
            handle: 通知句柄

        返回:
            是否成功取消
        """
        with self._lock:
            sub = self._subscriptions.pop(handle, None)
            if sub is None:
                return False
            self._subscriptions_by_id.pop(sub.subscription_id, None)
        sub.is_active = False
        return self._aoe.del_notification(handle)

    def unsubscribe_all(self) -> int:
        """
        取消所有订阅 (对应 C# UnsubscribeAll)

        返回:
            成功取消的数量
        """
        with self._lock:
            subs = list(self._subscriptions.values())
            self._subscriptions.clear()
            self._subscriptions_by_id.clear()
        count = 0
        for sub in subs:
            sub.is_active = False
            try:
                if self._aoe.del_notification(sub.handle):
                    count += 1
            except Exception:
                pass
        return count

    def get_subscription(self, handle: int) -> Optional[AoESubscription]:
        """
        按句柄获取订阅信息

        参数:
            handle: 通知句柄
        返回:
            订阅对象, 未找到返回 None
        """
        with self._lock:
            return self._subscriptions.get(handle)

    def get_subscription_by_id(self, subscription_id: str) -> Optional[AoESubscription]:
        """
        按订阅 ID 获取订阅信息

        参数:
            subscription_id: 订阅 ID
        返回:
            订阅对象, 未找到返回 None
        """
        with self._lock:
            return self._subscriptions_by_id.get(subscription_id)

    @property
    def active_count(self) -> int:
        """当前活跃订阅数量"""
        with self._lock:
            return len(self._subscriptions)

    @property
    def all_handles(self) -> List[int]:
        """所有活跃的通知句柄列表"""
        with self._lock:
            return list(self._subscriptions.keys())

    def get_active_subscriptions(self) -> List[AoESubscription]:
        """
        获取所有活跃的 AoE 订阅列表
        对应 C# GetActiveSubscriptions 方法

        返回:
            当前活跃订阅的列表副本
        """
        with self._lock:
            return list(self._subscriptions.values())

    def __repr__(self) -> str:
        return f"AoESubscriptionManager(active={self.active_count})"

    # ---- 异步订阅接口 (对齐 C# AoESubscriptionManager *Async) ----

    async def subscribe_async(self, index_group: int, index_offset: int,
                              length: int,
                              trans_mode: int = AoETransmissionMode.ON_CHANGE,
                              max_delay_ms: int = 0, cycle_time_ms: int = 100,
                              callback: Optional[Callable[[bytes], None]] = None,
                              timeout_ms: Optional[int] = None
                              ) -> Optional[str]:
        """
        异步订阅 AoE 通知 (对齐 C# SubscribeAsync)

        add_notification 需经从站邮箱, 属于阻塞 IO, 包装为 async。
        """
        return await _run_aoe_async(
            self.subscribe, index_group, index_offset, length,
            trans_mode, max_delay_ms, cycle_time_ms, callback,
            timeout_ms=timeout_ms,
        )

    async def unsubscribe_async(self, subscription_id: str,
                                timeout_ms: Optional[int] = None) -> bool:
        """异步取消订阅 (对齐 C# UnsubscribeAsync)"""
        return await _run_aoe_async(
            self.unsubscribe, subscription_id, timeout_ms=timeout_ms
        )

    async def unsubscribe_all_async(self,
                                    timeout_ms: Optional[int] = None) -> int:
        """异步取消所有订阅 (对齐 C# UnsubscribeAllAsync)"""
        return await _run_aoe_async(
            self.unsubscribe_all, timeout_ms=timeout_ms
        )


# ADS 状态码描述
_ADS_STATE_DESCRIPTIONS = {
    0: "无效",
    1: "空闲",
    2: "复位",
    3: "初始化",
    4: "启动",
    5: "运行",
    6: "停止",
    7: "保存配置",
    8: "加载配置",
    9: "关机",
    10: "暂停",
    11: "重新配置",
    15: "错误",
}


def get_ads_state_description(ads_state: int) -> str:
    """
    获取 ADS 状态码的描述字符串
    对应 C# GetAdsStateDescription 方法

    参数:
        ads_state: ADS 状态码
    返回:
        状态描述字符串
    """
    return _ADS_STATE_DESCRIPTIONS.get(ads_state, f"未知状态 ({ads_state})")
