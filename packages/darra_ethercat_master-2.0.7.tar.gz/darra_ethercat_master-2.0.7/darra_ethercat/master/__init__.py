# -*- coding: utf-8 -*-
"""
主站模块
包含 EtherCAT 主站类及其相关功能
"""

from .core import EtherCATMaster, ValidationResult
from .events import SlaveEvents, MasterEvents
from .events_emcy import record_emcy_to_slave
from .diagnostics import MasterDiagnosticsInfo, MasterPDODiagnostics, PDOFrameLossStats, DiagnosticsSnapshot
from .diagnostics_info import BreakPointInfo, SlaveErrorCounters
from .diagnostics_etg1510 import ALErrorClassifier, get_object_name
from .config import MasterConfig, ScanRevisionMatchMode, MailboxConfig
from .master_od import MasterObjectDictionary
from .mailbox_gateway import MailboxGatewayService
from .state import *  # noqa: F401,F403
from .other import (
    SlaveDiagnosticsData, get_slave_diagnostics, set_all_slave_watchdog,
    get_cpu_cores, set_cpu_affinity, apply_realtime_optimizations,
)
from .redundancy import (
    RedundancyState, RedundancyStatus, RedundancyStatusInfo, RedundancyManager,
)
from .hot_connect import HotConnectStatus, HotConnectGroup, HotConnect
