# -*- coding: utf-8 -*-
"""
EtherCAT 事件系统
对应 C# Events.cs / Events_EmcyRecorder.cs
提供主站级和从站级事件注册与分发
"""

import ctypes
import logging
import threading
import time
from dataclasses import dataclass
from ctypes import c_ushort, c_ubyte, c_uint, c_int, c_void_p, c_bool
from typing import Callable, List, Optional, Set


# ===================== Callback 异常上报 (节流) =====================
# 高频回调 (PDO 周期 1kHz / InputChanged) 中用户 callback 抛异常时, 直接 print(stderr)
# 会瞬间刷屏 (1000 行/秒) 并阻塞 RT 线程. 此处统一走 logging + 按异常类型节流.
_callback_logger = logging.getLogger("darra.ethercat.events")
_CALLBACK_ERROR_THROTTLE = 10  # 同类异常前 N 次完整输出, 之后静默累计
_callback_error_counts: dict = {}
_callback_error_lock = threading.Lock()


def _report_callback_error(exc: BaseException) -> None:
    """统一上报用户 callback 异常: logger.exception + 按异常类型节流, 防止高频回调刷屏."""
    try:
        key = type(exc).__name__
        with _callback_error_lock:
            cnt = _callback_error_counts.get(key, 0) + 1
            _callback_error_counts[key] = cnt
        if cnt <= _CALLBACK_ERROR_THROTTLE:
            _callback_logger.exception(
                "[Darra events] user callback failed (%s, count=%d)", key, cnt
            )
        elif cnt == _CALLBACK_ERROR_THROTTLE + 1:
            _callback_logger.warning(
                "[Darra events] %s 异常累计 > %d 次, 后续静默累计 (避免高频回调刷屏)",
                key, _CALLBACK_ERROR_THROTTLE,
            )
    except Exception:
        pass  # 上报本身不能再抛, 否则吞掉用户 callback 调用栈


from ..utils.dll import (
    DarraCoreDLL,
    ProcessDataCyclicCallbackType,
    SlaveStateChangeCallbackType,
    EmergencyEventCallbackType,
    SlaveDiscoveryCallbackType,
    RedundancyModeChangedCallbackType,
    InputDataChangedCallbackType,
    PDOFrameLossCallbackType,
    DCSyncLostCallbackType,
    SlavePreOpReconfigCallbackType,
    SlaveIdentityMismatchCallbackType,
    SlavePortLinkChangedCallbackType,
    LogCallbackType,
    CrashNotifyCallbackType,
    CORE_OP_26,
)


# ===================== 事件参数数据类 =====================

@dataclass(frozen=True)
class SlaveIdentityMismatchEventArgs:
    """
    从站身份不符事件参数 (v2 热插拔自修复)

    触发时机: 断电重插从站后 ident FSM 读取到的 Vendor/Product 与配置不匹配,
    或 Revision 低于配置 (向后兼容: actual >= configured 视为匹配)。
    处理: UI 弹出报警 -> 用户检查/更换设备 -> 调用 master.acknowledge_slave_replacement().
    """
    master_index: int
    slave_index: int
    expected_vendor: int
    expected_product: int
    expected_revision: int
    actual_vendor: int
    actual_product: int
    actual_revision: int


# ===================== 从站事件集合 =====================

class SlaveEvents:
    """
    从站事件集合 — 通过 slave.events 访问
    事件参数不含 master_index/slave_index，已自动过滤到当前从站
    """

    def __init__(self):
        # 从站状态变化 (old_state, new_state)
        self._on_state_changed: List[Callable[[int, int], None]] = []
        # 紧急事件 (error_code, error_reg, b1, w1, w2)
        self._on_emergency: List[Callable[[int, int, int, int, int], None]] = []
        # 从站离线
        self._on_offline: List[Callable[[], None]] = []
        # 从站上线
        self._on_online: List[Callable[[], None]] = []
        # DC 同步丢失 (diff_ns)
        self._on_dc_sync_lost: List[Callable[[int], None]] = []
        # 输入PDO数据变化
        self._on_input_changed: List[Callable[[], None]] = []
        # FSoE 状态变化 (old_state, new_state)
        self._on_fsoe_state_changed: List[Callable[[int, int], None]] = []
        # FSoE 错误 (error_code)
        self._on_fsoe_error: List[Callable[[int], None]] = []
        # FSoE 进入失效安全 ()
        self._on_fsoe_failsafe_triggered: List[Callable[[], None]] = []
        # FSoE 安全数据更新 (data: bytes)
        self._on_fsoe_safe_data_updated: List[Callable[[bytes], None]] = []
        # FSoE 数据交换 (input_data: bytes, output_data: bytes)
        self._on_fsoe_data_exchange: List[Callable[[bytes, bytes], None]] = []

    # ========== 注册方法 ==========

    def add_state_changed(self, callback: Callable[[int, int], None]):
        """注册从站状态变化监听 (old_state, new_state)"""
        self._on_state_changed.append(callback)

    def remove_state_changed(self, callback: Callable[[int, int], None]):
        """移除从站状态变化监听"""
        try:
            self._on_state_changed.remove(callback)
        except ValueError:
            pass

    def add_emergency(self, callback: Callable[[int, int, int, int, int], None]):
        """注册紧急事件监听 (error_code, error_reg, b1, w1, w2)"""
        self._on_emergency.append(callback)

    def remove_emergency(self, callback: Callable[[int, int, int, int, int], None]):
        """移除紧急事件监听"""
        try:
            self._on_emergency.remove(callback)
        except ValueError:
            pass

    def add_offline(self, callback: Callable[[], None]):
        """注册从站离线监听"""
        self._on_offline.append(callback)

    def remove_offline(self, callback: Callable[[], None]):
        """移除从站离线监听"""
        try:
            self._on_offline.remove(callback)
        except ValueError:
            pass

    def add_online(self, callback: Callable[[], None]):
        """注册从站上线监听"""
        self._on_online.append(callback)

    def remove_online(self, callback: Callable[[], None]):
        """移除从站上线监听"""
        try:
            self._on_online.remove(callback)
        except ValueError:
            pass

    def add_dc_sync_lost(self, callback: Callable[[int], None]):
        """注册 DC 同步丢失监听 (diff_ns)"""
        self._on_dc_sync_lost.append(callback)

    def remove_dc_sync_lost(self, callback: Callable[[int], None]):
        """移除 DC 同步丢失监听"""
        try:
            self._on_dc_sync_lost.remove(callback)
        except ValueError:
            pass

    def add_input_changed(self, callback: Callable[[], None]):
        """注册输入PDO数据变化监听"""
        self._on_input_changed.append(callback)

    def remove_input_changed(self, callback: Callable[[], None]):
        """移除输入PDO数据变化监听"""
        try:
            self._on_input_changed.remove(callback)
        except ValueError:
            pass

    # ========== FSoE 事件注册方法 ==========

    def add_fsoe_state_changed(self, callback: Callable[[int, int], None]):
        """注册 FSoE 状态变化监听 (old_state, new_state)"""
        self._on_fsoe_state_changed.append(callback)

    def remove_fsoe_state_changed(self, callback: Callable[[int, int], None]):
        """移除 FSoE 状态变化监听"""
        try:
            self._on_fsoe_state_changed.remove(callback)
        except ValueError:
            pass

    def add_fsoe_error(self, callback: Callable[[int], None]):
        """注册 FSoE 错误监听 (error_code)"""
        self._on_fsoe_error.append(callback)

    def remove_fsoe_error(self, callback: Callable[[int], None]):
        """移除 FSoE 错误监听"""
        try:
            self._on_fsoe_error.remove(callback)
        except ValueError:
            pass

    def add_fsoe_failsafe_triggered(self, callback: Callable[[], None]):
        """注册 FSoE 进入失效安全监听"""
        self._on_fsoe_failsafe_triggered.append(callback)

    def remove_fsoe_failsafe_triggered(self, callback: Callable[[], None]):
        """移除 FSoE 进入失效安全监听"""
        try:
            self._on_fsoe_failsafe_triggered.remove(callback)
        except ValueError:
            pass

    def add_fsoe_safe_data_updated(self, callback: Callable[[bytes], None]):
        """注册 FSoE 安全数据更新监听 (data)"""
        self._on_fsoe_safe_data_updated.append(callback)

    def remove_fsoe_safe_data_updated(self, callback: Callable[[bytes], None]):
        """移除 FSoE 安全数据更新监听"""
        try:
            self._on_fsoe_safe_data_updated.remove(callback)
        except ValueError:
            pass

    def add_fsoe_data_exchange(self, callback: Callable[[bytes, bytes], None]):
        """注册 FSoE 数据交换监听 (input_data, output_data)"""
        self._on_fsoe_data_exchange.append(callback)

    def remove_fsoe_data_exchange(self, callback: Callable[[bytes, bytes], None]):
        """移除 FSoE 数据交换监听"""
        try:
            self._on_fsoe_data_exchange.remove(callback)
        except ValueError:
            pass

    # ========== 清除方法 ==========

    def clear_all(self):
        """清除该从站的所有事件订阅，防止内存泄漏"""
        self._on_state_changed.clear()
        self._on_emergency.clear()
        self._on_offline.clear()
        self._on_online.clear()
        self._on_dc_sync_lost.clear()
        self._on_input_changed.clear()
        self._on_fsoe_state_changed.clear()
        self._on_fsoe_error.clear()
        self._on_fsoe_failsafe_triggered.clear()
        self._on_fsoe_safe_data_updated.clear()
        self._on_fsoe_data_exchange.clear()

    # ========== 内部触发方法 ==========

    def _trigger_state_changed(self, old_state: int, new_state: int):
        """内部: 触发从站状态变化事件"""
        for cb in self._on_state_changed:
            try:
                cb(old_state, new_state)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_emergency(self, error_code: int, error_reg: int,
                           b1: int, w1: int, w2: int):
        """内部: 触发紧急事件"""
        for cb in self._on_emergency:
            try:
                cb(error_code, error_reg, b1, w1, w2)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_offline(self):
        """内部: 触发从站离线事件"""
        for cb in self._on_offline:
            try:
                cb()
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_online(self):
        """内部: 触发从站上线事件"""
        for cb in self._on_online:
            try:
                cb()
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_dc_sync_lost(self, diff_ns: int):
        """内部: 触发 DC 同步丢失事件"""
        for cb in self._on_dc_sync_lost:
            try:
                cb(diff_ns)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_input_changed(self):
        """内部: 触发输入PDO数据变化事件"""
        for cb in self._on_input_changed:
            try:
                cb()
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_fsoe_state_changed(self, old_state: int, new_state: int):
        """内部: 触发 FSoE 状态变化事件"""
        for cb in self._on_fsoe_state_changed:
            try:
                cb(old_state, new_state)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_fsoe_error(self, error_code: int):
        """内部: 触发 FSoE 错误事件"""
        for cb in self._on_fsoe_error:
            try:
                cb(error_code)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_fsoe_failsafe_triggered(self):
        """内部: 触发 FSoE 进入失效安全事件"""
        for cb in self._on_fsoe_failsafe_triggered:
            try:
                cb()
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_fsoe_safe_data_updated(self, data: bytes):
        """内部: 触发 FSoE 安全数据更新事件"""
        for cb in self._on_fsoe_safe_data_updated:
            try:
                cb(data)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_fsoe_data_exchange(self, input_data: bytes, output_data: bytes):
        """内部: 触发 FSoE 数据交换事件"""
        for cb in self._on_fsoe_data_exchange:
            try:
                cb(input_data, output_data)
            except Exception as _e:
                _report_callback_error(_e)


# ===================== 主站事件集合 =====================

class MasterEvents:
    """
    主站事件集合 — 通过 master.events 访问
    所有 DLL 回调事件和主站级事件的统一入口
    """

    def __init__(self, master):
        """
        参数:
            master: EtherCATMaster 实例
        """
        self._master = master

        # 从站离线状态跟踪: 防止 SlaveOffline/SlaveOnline 事件重复触发
        self._offline_slaves: Set[int] = set()
        self._offline_lock = threading.Lock()

        # PDO 周期回调 - 异步模式
        self._on_pdo_cyclic_async: List[Callable[[int], None]] = []
        # PDO 周期回调 - 同步模式
        self._on_pdo_cyclic_sync: List[Callable[[int], None]] = []
        # 主站状态变化 (old_state, new_state)
        self._on_state_changed: List[Callable[[int, int], None]] = []
        # 从站状态变化 (master_index, slave_index, old_state, new_state)
        self._on_slave_state_changed: List[Callable[[int, int, int, int], None]] = []
        # 紧急事件 (master_index, slave_index, error_code, error_reg, b1, w1, w2)
        self._on_emergency: List[Callable[[int, int, int, int, int, int, int], None]] = []
        # 从站离线 (slave_index)
        self._on_slave_offline: List[Callable[[int], None]] = []
        # 从站上线 (slave_index)
        self._on_slave_online: List[Callable[[int], None]] = []
        # PDO 丢帧 (master_index, group, consecutive_lost, total_lost)
        self._on_pdo_frame_loss: List[Callable[[int, int, int, int], None]] = []
        # DC 同步丢失 (master_index, slave_index, diff_ns)
        self._on_dc_sync_lost: List[Callable[[int, int, int], None]] = []
        # 冗余模式变化 (master_index, old_mode, new_mode)
        self._on_redundancy_mode_changed: List[Callable[[int, int, int], None]] = []
        # 输入PDO数据变化 (master_index, slave_index)
        self._on_input_data_changed: List[Callable[[int, int], None]] = []
        # 从站身份不符 (SlaveIdentityMismatchEventArgs) - v2 热插拔自修复
        self._on_slave_identity_mismatch: List[Callable[[SlaveIdentityMismatchEventArgs], None]] = []
        # 从站端口链路变化 (master_index, slave_index, port, is_up)
        self._on_slave_port_link_changed: List[Callable[[int, int, int, bool], None]] = []

    # ========== 注册方法 ==========

    def add_pdo_cyclic_async(self, callback: Callable[[int], None]):
        """注册异步PDO周期回调 (master_index)"""
        self._on_pdo_cyclic_async.append(callback)

    def remove_pdo_cyclic_async(self, callback: Callable[[int], None]):
        """移除异步PDO周期回调"""
        try:
            self._on_pdo_cyclic_async.remove(callback)
        except ValueError:
            pass

    def add_pdo_cyclic_sync(self, callback: Callable[[int], None]):
        """注册同步PDO周期回调 (master_index)"""
        self._on_pdo_cyclic_sync.append(callback)

    def remove_pdo_cyclic_sync(self, callback: Callable[[int], None]):
        """移除同步PDO周期回调"""
        try:
            self._on_pdo_cyclic_sync.remove(callback)
        except ValueError:
            pass

    def add_state_changed(self, callback: Callable[[int, int], None]):
        """注册主站状态变化监听 (old_state, new_state)"""
        self._on_state_changed.append(callback)

    def remove_state_changed(self, callback: Callable[[int, int], None]):
        """移除主站状态变化监听"""
        try:
            self._on_state_changed.remove(callback)
        except ValueError:
            pass

    def add_slave_state_changed(self, callback: Callable[[int, int, int, int], None]):
        """注册从站状态变化监听 (master_index, slave_index, old_state, new_state)"""
        self._on_slave_state_changed.append(callback)

    def remove_slave_state_changed(self, callback: Callable[[int, int, int, int], None]):
        """移除从站状态变化监听"""
        try:
            self._on_slave_state_changed.remove(callback)
        except ValueError:
            pass

    def add_emergency(self, callback: Callable[[int, int, int, int, int, int, int], None]):
        """注册紧急事件监听 (mi, si, error_code, error_reg, b1, w1, w2)"""
        self._on_emergency.append(callback)

    def remove_emergency(self, callback: Callable[[int, int, int, int, int, int, int], None]):
        """移除紧急事件监听"""
        try:
            self._on_emergency.remove(callback)
        except ValueError:
            pass

    def add_slave_offline(self, callback: Callable[[int], None]):
        """注册从站离线监听 (slave_index)"""
        self._on_slave_offline.append(callback)

    def remove_slave_offline(self, callback: Callable[[int], None]):
        """移除从站离线监听"""
        try:
            self._on_slave_offline.remove(callback)
        except ValueError:
            pass

    def add_slave_online(self, callback: Callable[[int], None]):
        """注册从站上线监听 (slave_index)"""
        self._on_slave_online.append(callback)

    def remove_slave_online(self, callback: Callable[[int], None]):
        """移除从站上线监听"""
        try:
            self._on_slave_online.remove(callback)
        except ValueError:
            pass

    def add_pdo_frame_loss(self, callback: Callable[[int, int, int, int], None]):
        """注册PDO丢帧监听 (mi, group, consecutive, total)"""
        self._on_pdo_frame_loss.append(callback)

    def remove_pdo_frame_loss(self, callback: Callable[[int, int, int, int], None]):
        """移除PDO丢帧监听"""
        try:
            self._on_pdo_frame_loss.remove(callback)
        except ValueError:
            pass

    def add_dc_sync_lost(self, callback: Callable[[int, int, int], None]):
        """注册DC同步丢失监听 (mi, slave_index, diff_ns)"""
        self._on_dc_sync_lost.append(callback)

    def remove_dc_sync_lost(self, callback: Callable[[int, int, int], None]):
        """移除DC同步丢失监听"""
        try:
            self._on_dc_sync_lost.remove(callback)
        except ValueError:
            pass

    def add_redundancy_mode_changed(self, callback: Callable[[int, int, int], None]):
        """注册冗余模式变化监听 (mi, old_mode, new_mode)"""
        self._on_redundancy_mode_changed.append(callback)

    def remove_redundancy_mode_changed(self, callback: Callable[[int, int, int], None]):
        """移除冗余模式变化监听"""
        try:
            self._on_redundancy_mode_changed.remove(callback)
        except ValueError:
            pass

    def add_input_data_changed(self, callback: Callable[[int, int], None]):
        """注册输入PDO数据变化监听 (mi, slave_index)"""
        self._on_input_data_changed.append(callback)

    def remove_input_data_changed(self, callback: Callable[[int, int], None]):
        """移除输入PDO数据变化监听"""
        try:
            self._on_input_data_changed.remove(callback)
        except ValueError:
            pass

    def add_slave_identity_mismatch(self,
                                    callback: Callable[[SlaveIdentityMismatchEventArgs], None]):
        """
        注册从站身份不符监听 (v2 热插拔自修复)

        参数:
            callback: 回调函数, 接收一个 SlaveIdentityMismatchEventArgs 对象
        """
        self._on_slave_identity_mismatch.append(callback)

    def remove_slave_identity_mismatch(self,
                                       callback: Callable[[SlaveIdentityMismatchEventArgs], None]):
        """移除从站身份不符监听"""
        try:
            self._on_slave_identity_mismatch.remove(callback)
        except ValueError:
            pass

    def add_slave_port_link_changed(self,
                                    callback: Callable[[int, int, int, bool], None]):
        """
        注册从站端口链路变化监听 (断线/恢复事件)

        参数:
            callback: 回调函数 (master_index, slave_index, port, is_up)
                      - port: 0-3 对应 P0/P1/P2/P3
                      - is_up: True=link 恢复, False=link 断开
        """
        self._on_slave_port_link_changed.append(callback)

    def remove_slave_port_link_changed(self,
                                       callback: Callable[[int, int, int, bool], None]):
        """移除从站端口链路变化监听"""
        try:
            self._on_slave_port_link_changed.remove(callback)
        except ValueError:
            pass

    # ========== 清除方法 ==========

    def clear_all(self):
        """清除所有事件订阅，防止内存泄漏"""
        self._on_pdo_cyclic_async.clear()
        self._on_pdo_cyclic_sync.clear()
        self._on_state_changed.clear()
        self._on_slave_state_changed.clear()
        self._on_emergency.clear()
        self._on_slave_offline.clear()
        self._on_slave_online.clear()
        self._on_pdo_frame_loss.clear()
        self._on_dc_sync_lost.clear()
        self._on_redundancy_mode_changed.clear()
        self._on_input_data_changed.clear()
        self._on_slave_identity_mismatch.clear()
        self._on_slave_port_link_changed.clear()
        with self._offline_lock:
            self._offline_slaves.clear()

    # ========== 查询方法 ==========

    def is_slave_offline(self, slave_index: int) -> bool:
        """
        查询从站是否处于事件确认的离线状态

        参数:
            slave_index: 从站索引 (1-based)

        返回:
            True=从站已确认离线, False=从站在线或未知
        """
        with self._offline_lock:
            return slave_index in self._offline_slaves

    @property
    def offline_slaves(self) -> Set[int]:
        """获取当前离线从站索引集合 (只读副本)"""
        with self._offline_lock:
            return set(self._offline_slaves)

    # ========== 内部触发方法 ==========

    def _get_slave_events(self, slave_index: int) -> Optional[SlaveEvents]:
        """安全获取从站事件对象"""
        slaves = self._master._slaves
        if not slaves or slave_index not in slaves:
            return None
        slave = slaves[slave_index]
        return getattr(slave, '_events', None)

    def _trigger_pdo_cyclic_sync(self, master_index: int):
        """内部: 触发同步PDO周期回调"""
        for cb in self._on_pdo_cyclic_sync:
            try:
                cb(master_index)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_pdo_cyclic_async(self, master_index: int):
        """内部: 触发异步PDO周期回调"""
        for cb in self._on_pdo_cyclic_async:
            try:
                cb(master_index)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_state_changed(self, old_state: int, new_state: int):
        """内部: 触发主站状态变化事件"""
        for cb in self._on_state_changed:
            try:
                cb(old_state, new_state)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_slave_state_changed(self, master_index: int, slave_index: int,
                                     old_state: int, new_state: int):
        """内部: 触发从站状态变化事件"""
        for cb in self._on_slave_state_changed:
            try:
                cb(master_index, slave_index, old_state, new_state)
            except Exception as _e:
                _report_callback_error(_e)
        # 路由到从站事件
        se = self._get_slave_events(slave_index)
        if se:
            se._trigger_state_changed(old_state, new_state)

    def _trigger_emergency(self, master_index: int, slave_index: int,
                           error_code: int, error_reg: int,
                           b1: int, w1: int, w2: int):
        """内部: 触发紧急事件"""
        for cb in self._on_emergency:
            try:
                cb(master_index, slave_index, error_code, error_reg, b1, w1, w2)
            except Exception as _e:
                _report_callback_error(_e)
        # 路由到从站事件
        se = self._get_slave_events(slave_index)
        if se:
            se._trigger_emergency(error_code, error_reg, b1, w1, w2)

    def _trigger_slave_offline(self, slave_index: int):
        """内部: 触发从站离线事件 (去重)"""
        with self._offline_lock:
            if slave_index in self._offline_slaves:
                return  # 已经处于离线状态, 不重复触发
            self._offline_slaves.add(slave_index)

        for cb in self._on_slave_offline:
            try:
                cb(slave_index)
            except Exception as _e:
                _report_callback_error(_e)
        # 路由到从站事件
        se = self._get_slave_events(slave_index)
        if se:
            se._trigger_offline()

    def _trigger_slave_online(self, slave_index: int):
        """内部: 触发从站上线事件 (去重)"""
        with self._offline_lock:
            if slave_index not in self._offline_slaves:
                return  # 从站不在离线列表中, 不触发上线事件
            self._offline_slaves.discard(slave_index)

        for cb in self._on_slave_online:
            try:
                cb(slave_index)
            except Exception as _e:
                _report_callback_error(_e)
        # 路由到从站事件
        se = self._get_slave_events(slave_index)
        if se:
            se._trigger_online()

    def _trigger_pdo_frame_loss(self, master_index: int, group: int,
                                consecutive_lost: int, total_lost: int):
        """内部: 触发PDO丢帧事件"""
        for cb in self._on_pdo_frame_loss:
            try:
                cb(master_index, group, consecutive_lost, total_lost)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_dc_sync_lost(self, master_index: int, slave_index: int, diff_ns: int):
        """内部: 触发DC同步丢失事件"""
        for cb in self._on_dc_sync_lost:
            try:
                cb(master_index, slave_index, diff_ns)
            except Exception as _e:
                _report_callback_error(_e)
        # 路由到从站事件
        se = self._get_slave_events(slave_index)
        if se:
            se._trigger_dc_sync_lost(diff_ns)

    def _trigger_redundancy_mode_changed(self, master_index: int,
                                         old_mode: int, new_mode: int):
        """内部: 触发冗余模式变化事件"""
        for cb in self._on_redundancy_mode_changed:
            try:
                cb(master_index, old_mode, new_mode)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_input_data_changed(self, slave_index: int):
        """内部: 触发输入PDO数据变化事件"""
        mi = self._master._mi
        for cb in self._on_input_data_changed:
            try:
                cb(mi, slave_index)
            except Exception as _e:
                _report_callback_error(_e)
        # 路由到从站事件
        se = self._get_slave_events(slave_index)
        if se:
            se._trigger_input_changed()

    def _trigger_slave_identity_mismatch(self, args: SlaveIdentityMismatchEventArgs):
        """内部: 触发从站身份不符事件 (v2 热插拔)"""
        for cb in self._on_slave_identity_mismatch:
            try:
                cb(args)
            except Exception as _e:
                _report_callback_error(_e)

    def _trigger_slave_port_link_changed(self, master_index: int, slave_index: int,
                                         port: int, is_up: bool):
        """内部: 触发从站端口链路变化事件 (断线/恢复)"""
        for cb in self._on_slave_port_link_changed:
            try:
                cb(master_index, slave_index, port, is_up)
            except Exception as _e:
                _report_callback_error(_e)


# ===================== 静态回调注册管理 =====================

class _CallbackRegistry:
    """
    全局回调注册管理 (单例)
    保持 CFUNCTYPE 引用防止 GC 回收
    通过 master_index 查找主站实例进行事件分发
    """

    _instance = None
    _lock = threading.Lock()

    def __init__(self):
        self._registered = False
        self._masters = {}  # master_index -> EtherCATMaster
        # 保持 CFUNCTYPE 引用
        self._cb_refs = {}
        # 进程级回调 (无 master_index, 多 master 共享 fanout)
        # log_listeners: list[Callable[[int, str], None]]
        # crash_listeners: list[Callable[[int, str], None]]
        self._log_listeners = []
        self._crash_listeners = []
        self._listener_lock = threading.Lock()

    @classmethod
    def get(cls) -> '_CallbackRegistry':
        """获取单例"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def register_master(self, master_index: int, master):
        """注册主站实例"""
        self._masters[master_index] = master

    def unregister_master(self, master_index: int):
        """注销主站实例"""
        self._masters.pop(master_index, None)

    def get_master(self, master_index: int):
        """根据索引获取主站实例"""
        return self._masters.get(master_index)

    def initialize_callbacks(self, dll: DarraCoreDLL):
        """
        初始化所有 DLL 回调 (仅首次调用生效)

        参数:
            dll: DarraCoreDLL 实例
        """
        if self._registered:
            return

        with self._lock:
            if self._registered:
                return

            # 创建并保持回调引用
            cb_sync = ProcessDataCyclicCallbackType(self._on_pdo_sync)
            cb_async = ProcessDataCyclicCallbackType(self._on_pdo_async)
            cb_state = SlaveStateChangeCallbackType(self._on_slave_state_change)
            cb_emcy = EmergencyEventCallbackType(self._on_emergency)
            cb_disc = SlaveDiscoveryCallbackType(self._on_slave_discovery)
            cb_pdo_loss = PDOFrameLossCallbackType(self._on_pdo_frame_loss)
            cb_dc_lost = DCSyncLostCallbackType(self._on_dc_sync_lost)
            cb_red = RedundancyModeChangedCallbackType(self._on_redundancy_changed)
            cb_input = InputDataChangedCallbackType(self._on_input_changed)
            cb_reconfig = SlavePreOpReconfigCallbackType(self._on_preop_reconfig)
            cb_ident = SlaveIdentityMismatchCallbackType(self._on_slave_identity_mismatch)
            cb_port = SlavePortLinkChangedCallbackType(self._on_slave_port_link_changed)
            cb_log = LogCallbackType(self._on_log)
            cb_crash = CrashNotifyCallbackType(self._on_crash)

            self._cb_refs = {
                'pdo_sync': cb_sync,
                'pdo_async': cb_async,
                'state': cb_state,
                'emcy': cb_emcy,
                'disc': cb_disc,
                'pdo_loss': cb_pdo_loss,
                'dc_lost': cb_dc_lost,
                'red': cb_red,
                'input': cb_input,
                'reconfig': cb_reconfig,
                'ident': cb_ident,
                'port': cb_port,
                'log': cb_log,
                'crash': cb_crash,
            }

            # 注册到 DLL
            dll.RegisterProcessDataCyclicCallbackSync(cb_sync)
            dll.RegisterProcessDataCyclicCallbackAsync(cb_async)
            dll.RegisterSlaveStateChangeCallbackSync(cb_state)
            dll.RegisterEmergencyEventCallback(cb_emcy)
            dll.RegisterSlaveDiscoveryCallbackSync(cb_disc)
            dll.RegisterPDOFrameLossCallback(cb_pdo_loss)
            dll.SetDCSyncLostCallback(cb_dc_lost)
            dll.RegisterRedundancyModeChangedCallback(cb_red)
            dll.RegisterInputDataChangedCallback(cb_input)
            dll.RegisterSlavePreOpReconfigCallback(cb_reconfig)
            # v2 热插拔 / 端口链路
            try:
                dll.RegisterSlaveIdentityMismatchCallback(cb_ident)
            except AttributeError:
                pass
            try:
                dll.RegisterSlavePortLinkChangedCallback(cb_port)
            except AttributeError:
                pass
            # 进程级 log / crash 回调 (一次注册, 多 master 共享 fanout)
            try:
                dll.SetLogCallback(cb_log)
            except AttributeError:
                pass
            try:
                dll.SetCrashCallback(cb_crash)
            except AttributeError:
                pass

            self._registered = True

    # ========== 进程级 log / crash listener 管理 ==========

    def add_log_listener(self, callback):
        """添加日志监听器 (callback: (category:int, message:str) -> None)"""
        with self._listener_lock:
            if callback not in self._log_listeners:
                self._log_listeners.append(callback)

    def remove_log_listener(self, callback):
        """移除日志监听器"""
        with self._listener_lock:
            try:
                self._log_listeners.remove(callback)
            except ValueError:
                pass

    def add_crash_listener(self, callback):
        """添加崩溃通知监听器 (callback: (severity:int, message:str) -> None)"""
        with self._listener_lock:
            if callback not in self._crash_listeners:
                self._crash_listeners.append(callback)

    def remove_crash_listener(self, callback):
        """移除崩溃通知监听器"""
        with self._listener_lock:
            try:
                self._crash_listeners.remove(callback)
            except ValueError:
                pass

    def _on_log(self, category, msg_ptr):
        """日志回调 dispatcher (进程级)"""
        try:
            msg = ''
            if msg_ptr:
                msg = ctypes.string_at(msg_ptr).decode('utf-8', errors='replace')
            with self._listener_lock:
                listeners = list(self._log_listeners)
            for cb in listeners:
                try:
                    cb(category, msg)
                except Exception:
                    pass
        except Exception:
            pass

    def _on_crash(self, severity, msg_ptr):
        """崩溃通知回调 dispatcher (进程级)"""
        try:
            msg = ''
            if msg_ptr:
                msg = ctypes.string_at(msg_ptr).decode('utf-8', errors='replace')
            with self._listener_lock:
                listeners = list(self._crash_listeners)
            for cb in listeners:
                try:
                    cb(severity, msg)
                except Exception:
                    pass
        except Exception:
            pass

    # ========== 内部回调处理器 ==========

    def _on_pdo_sync(self, master_index):
        """同步PDO周期回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_pdo_cyclic_sync(master_index)
        except Exception:
            pass

    def _on_pdo_async(self, master_index):
        """异步PDO周期回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_pdo_cyclic_async(master_index)
        except Exception:
            pass

    def _on_slave_state_change(self, master_index, slave_index, old_state, new_state):
        """从站状态变化回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_slave_state_changed(
                    master_index, slave_index, old_state, new_state)
        except Exception:
            pass

    def _on_emergency(self, master_index, slave_index,
                      error_code, error_reg, b1, w1, w2):
        """紧急事件回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_emergency(
                    master_index, slave_index, error_code, error_reg, b1, w1, w2)
        except Exception:
            pass

    def _on_slave_discovery(self, master_index, slave_index, is_found):
        """从站发现/丢失回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                if is_found:
                    m._events_instance._trigger_slave_online(slave_index)
                else:
                    m._events_instance._trigger_slave_offline(slave_index)
        except Exception:
            pass

    def _on_pdo_frame_loss(self, master_index, group, consecutive, total):
        """PDO丢帧回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_pdo_frame_loss(
                    master_index, group, consecutive, total)
        except Exception:
            pass

    def _on_dc_sync_lost(self, master_index, slave_index, diff_ns):
        """DC同步丢失回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_dc_sync_lost(
                    master_index, slave_index, diff_ns)
        except Exception:
            pass

    def _on_redundancy_changed(self, master_index, old_mode, new_mode):
        """冗余模式变化回调"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_redundancy_mode_changed(
                    master_index, old_mode, new_mode)
        except Exception:
            pass

    def _on_input_changed(self, master_index, bits_ptr, count):
        """输入PDO数据变化回调 - 解析位图"""
        if count == 0 or not bits_ptr:
            return
        try:
            m = self.get_master(master_index)
            if m is None or not hasattr(m, '_events_instance') or not m._events_instance:
                return

            # 读取位图数据, 最大字节数 = (count + 7) // 8
            byte_count = (count + 7) // 8
            raw = ctypes.string_at(bits_ptr, byte_count)
            found = 0
            for byte_idx in range(len(raw)):
                b = raw[byte_idx]
                if b == 0:
                    continue
                for bit_idx in range(8):
                    if found >= count:
                        break
                    if b & (1 << bit_idx):
                        slave_index = byte_idx * 8 + bit_idx
                        m._events_instance._trigger_input_data_changed(slave_index)
                        found += 1
                if found >= count:
                    break
        except Exception:
            pass

    def _on_slave_identity_mismatch(self, master_index, slave_index,
                                    expected_vendor, expected_product, expected_revision,
                                    actual_vendor, actual_product, actual_revision):
        """从站身份不符回调 (v2 热插拔自修复)"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                args = SlaveIdentityMismatchEventArgs(
                    master_index=master_index,
                    slave_index=slave_index,
                    expected_vendor=expected_vendor,
                    expected_product=expected_product,
                    expected_revision=expected_revision,
                    actual_vendor=actual_vendor,
                    actual_product=actual_product,
                    actual_revision=actual_revision,
                )
                m._events_instance._trigger_slave_identity_mismatch(args)
        except Exception:
            pass

    def _on_slave_port_link_changed(self, master_index, slave_index, port, is_up):
        """从站端口链路变化回调 (断线/恢复)"""
        try:
            m = self.get_master(master_index)
            if m and hasattr(m, '_events_instance') and m._events_instance:
                m._events_instance._trigger_slave_port_link_changed(
                    master_index, slave_index, port, bool(is_up))
        except Exception:
            pass

    def _on_preop_reconfig(self, master_index, slave_index):
        """从站 PreOP 重配置回调 (热插拔断电重连)"""
        try:
            m = self.get_master(master_index)
            if m is None:
                return
            dll = m._dll
            if not dll.GetSlaveNeedsStartupReconfig(master_index, slave_index):
                return

            slaves = m._slaves
            if not slaves or slave_index not in slaves:
                return

            # 重新应用所有 Startup 参数
            from ..utils.dll import TRANS_IP, TRANS_PS, TRANS_SO, TIMING_BEFORE, TIMING_AFTER
            transition_mask = (1 << TRANS_IP) | (1 << TRANS_PS) | (1 << TRANS_SO)
            timing_mask = (1 << TIMING_BEFORE) | (1 << TIMING_AFTER)
            dll.DarraCoreInvoke(master_index, CORE_OP_26, slave_index, transition_mask, timing_mask)

            dll.ClearSlaveNeedsStartupReconfig(master_index, slave_index)
        except Exception:
            pass
