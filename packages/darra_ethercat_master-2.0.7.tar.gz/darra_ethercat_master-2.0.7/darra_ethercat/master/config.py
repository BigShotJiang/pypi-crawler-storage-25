# -*- coding: utf-8 -*-
"""
主站配置类 - 统一管理所有通信配置

通过 master.config 访问，对应 C# MasterConfig 类。
包含周期配置、网络传输、PDO 配置、看门狗、超时等。

部分属性通过 DLL 调用实现，部分通过 主站共享内存指针直接读写。
主站状态结构布局参考 C 端兼容头文件。
"""

import ctypes
import struct
from ctypes import c_void_p
from enum import IntEnum
from typing import Optional


class ScanRevisionMatchMode(IntEnum):
    """扫描从站时的版本匹配模式"""
    EXACT = 0              # 精确匹配 VendorID + ProductID + RevisionID
    COMPATIBLE_HIGHER = 1  # 兼容匹配: 扫描到的 RevisionID >= 配置的 RevisionID
    IGNORE_REVISION = 2    # 忽略 RevisionID, 仅匹配 VendorID + ProductID (默认)


# ========== 主站状态结构字段偏移量 ==========
# 对应 C 端兼容头文件中的 主站状态结构
# 偏移计算基于 C 结构体的自然对齐 (x64)

# State: uint16 (2) offset 0
# ALstatuscode: uint16 (2) offset 2
# slavecount: int (4) offset 4
# LoopCycle: uint32 (4) offset 8
# DcCycle: uint32 (4) offset 12
# DCtime: int64 (8) offset 16
# IOmap: uint8[65536] offset 24
# iomap_mutex: void* (8) offset 65560
# IOmap_buffer: uint8[65536] offset 65568
# buffer_version: uint32 (4) offset 131104
# buffer_dirty: uint8 (1) offset 131108
# mutex_protection: uint8 (1) offset 131109
# pdo_cpu_affinity: int8 (1) offset 131110
# dc_auto_shift_enabled: uint8 (1) offset 131111
# use_udp: uint8 (1) offset 131112
# adaptive_timeout_enabled: uint8 (1) offset 131113
# overlapping_groups: uint8 (1) offset 131114
# packed_mode: uint8 (1) offset 131115
# frame_high_priority: uint8 (1) offset 131116
# (padding 1 byte) offset 131117
# vlan_id: uint16 (2) offset 131118
# vlan_priority: uint8 (1) offset 131120
# (padding 3 bytes) offset 131121
# timeout_init_to_preop: uint32 (4) offset 131124
# timeout_preop_to_safeop: uint32 (4) offset 131128
# timeout_safeop_to_op: uint32 (4) offset 131132
# wd_pd_timeout_ms: uint16 (2) offset 131136
# wd_pdi_timeout_ms: uint16 (2) offset 131138
# filter_threshold: uint32 (4) offset 131140
# frame_repeat_count: uint8 (1) offset 131144

_OFF_LOOP_CYCLE = 8
_OFF_ADAPTIVE_TIMEOUT = 131113
_OFF_OVERLAPPING_GROUPS = 131114
_OFF_PACKED_MODE = 131115
_OFF_FRAME_HIGH_PRIORITY = 131116
_OFF_VLAN_ID = 131118
_OFF_VLAN_PRIORITY = 131120
_OFF_TIMEOUT_INIT_TO_PREOP = 131124
_OFF_TIMEOUT_PREOP_TO_SAFEOP = 131128
_OFF_TIMEOUT_SAFEOP_TO_OP = 131132
_OFF_WD_PD_TIMEOUT_MS = 131136
_OFF_WD_PDI_TIMEOUT_MS = 131138
_OFF_FILTER_THRESHOLD = 131140
_OFF_FRAME_REPEAT_COUNT = 131144


def _read_u8(ptr: int, offset: int) -> int:
    """从指针偏移位置读取 uint8"""
    return ctypes.c_uint8.from_address(ptr + offset).value


def _write_u8(ptr: int, offset: int, value: int):
    """向指针偏移位置写入 uint8"""
    ctypes.c_uint8.from_address(ptr + offset).value = value & 0xFF


def _read_u16(ptr: int, offset: int) -> int:
    """从指针偏移位置读取 uint16"""
    return ctypes.c_uint16.from_address(ptr + offset).value


def _write_u16(ptr: int, offset: int, value: int):
    """向指针偏移位置写入 uint16"""
    ctypes.c_uint16.from_address(ptr + offset).value = value & 0xFFFF


def _read_u32(ptr: int, offset: int) -> int:
    """从指针偏移位置读取 uint32"""
    return ctypes.c_uint32.from_address(ptr + offset).value


def _write_u32(ptr: int, offset: int, value: int):
    """向指针偏移位置写入 uint32"""
    ctypes.c_uint32.from_address(ptr + offset).value = value & 0xFFFFFFFF


class MasterConfig:
    """
    主站配置类 - 统一管理所有通信配置

    通过 master.config 访问::

        master.config.loop_cycle = 1000000  # 1ms
        master.config.frame_high_priority = True
        master.config.use_udp = False
    """

    def __init__(self, dll, master_index: int):
        """
        初始化主站配置

        参数:
            dll: DarraCoreDLL 实例
            master_index: 主站索引
        """
        self._dll = dll
        self._mi = master_index
        # 本地字段 (不通过 DLL 或共享内存)
        self._drift_compensation: bool = False
        self._scan_revision_match: ScanRevisionMatchMode = ScanRevisionMatchMode.IGNORE_REVISION

    def _get_state_ptr(self, cached: bool = True) -> Optional[int]:
        """获取 主站状态指针 (整数地址)"""
        if cached:
            ptr = self._dll.GetMasterStateCache(self._mi)
        else:
            ptr = self._dll.GetMasterState(self._mi)
        if not ptr:
            return None
        return ptr

    # ===================== 周期配置 =====================

    @property
    def loop_cycle(self) -> int:
        """
        获取 PDO 交换周期时间（纳秒）
        Windows 系统建议不低于 125,000ns (125us)
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 0
        return _read_u32(ptr, _OFF_LOOP_CYCLE)

    @loop_cycle.setter
    def loop_cycle(self, value: int):
        """设置 PDO 交换周期时间（纳秒）"""
        self._dll.SetMasterLoopCycleTime(self._mi, max(0, value))

    # ===================== 网络传输 =====================

    @property
    def frame_high_priority(self) -> bool:
        """
        获取帧高优先级配置（默认启用）
        WDK 驱动模式: 插入 802.1Q VLAN 标签 (PCP=6, VID=0)
        Npcap 模式: 仅标记 frameHighPriority 标志
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return False
        return _read_u8(ptr, _OFF_FRAME_HIGH_PRIORITY) != 0

    @frame_high_priority.setter
    def frame_high_priority(self, value: bool):
        """设置帧高优先级"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u8(ptr, _OFF_FRAME_HIGH_PRIORITY, 1 if value else 0)

    @property
    def use_udp(self) -> bool:
        """获取 UDP 帧模式 (ETG.1500 5.3.7)"""
        return bool(self._dll.GetUdpMode(self._mi))

    @use_udp.setter
    def use_udp(self, value: bool):
        """设置 UDP 帧模式"""
        self._dll.SetUdpMode(self._mi, value)

    @property
    def is_udp_available(self) -> bool:
        """检查 UDP 模式是否可用（双 Socket 是否初始化成功）"""
        return bool(self._dll.IsUdpAvailable(self._mi))

    @property
    def vlan_id(self) -> int:
        """
        获取 VLAN ID (IEEE 802.1Q)
        范围: 0-4095，0 = 禁用 VLAN 标签
        仅 WDK 驱动模式下生效
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 0
        return _read_u16(ptr, _OFF_VLAN_ID)

    @vlan_id.setter
    def vlan_id(self, value: int):
        """设置 VLAN ID"""
        if value < 0 or value > 4095:
            raise ValueError("VLAN ID 必须在 0-4095 范围内")
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u16(ptr, _OFF_VLAN_ID, value)

    @property
    def vlan_priority(self) -> int:
        """
        获取 VLAN 优先级 (PCP, IEEE 802.1Q)
        范围 0-7，7 为最高优先级
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 0
        return _read_u8(ptr, _OFF_VLAN_PRIORITY)

    @vlan_priority.setter
    def vlan_priority(self, value: int):
        """设置 VLAN 优先级"""
        if value < 0 or value > 7:
            raise ValueError("VLAN 优先级必须在 0-7 范围内")
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u8(ptr, _OFF_VLAN_PRIORITY, value)

    # ===================== PDO 配置 =====================

    @property
    def overlapping_groups(self) -> bool:
        """
        获取 PDO 通信优化开关 (Overlapping Groups)
        启用后输入和输出数据将重叠在同一内存区域
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return False
        return _read_u8(ptr, _OFF_OVERLAPPING_GROUPS) != 0

    @overlapping_groups.setter
    def overlapping_groups(self, value: bool):
        """设置 Overlapping Groups，仅在 INIT 或 PRE_OP 状态下设置"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u8(ptr, _OFF_OVERLAPPING_GROUPS, 1 if value else 0)

    @property
    def packed_mode(self) -> bool:
        """
        获取 Packed PDO 映射模式
        0 = 字节对齐默认, 1 = bit紧密映射
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return False
        return _read_u8(ptr, _OFF_PACKED_MODE) != 0

    @packed_mode.setter
    def packed_mode(self, value: bool):
        """设置 Packed PDO 映射模式，仅在 INIT 或 PRE_OP 状态下设置"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u8(ptr, _OFF_PACKED_MODE, 1 if value else 0)

    @property
    def filter_threshold(self) -> int:
        """
        获取判断滤波阈值
        达到连续丢帧阈值才触发 PDOFrameLoss 回调，默认值 3
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 3
        return _read_u32(ptr, _OFF_FILTER_THRESHOLD)

    @filter_threshold.setter
    def filter_threshold(self, value: int):
        """设置判断滤波阈值"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u32(ptr, _OFF_FILTER_THRESHOLD, max(0, value))

    # ===================== 帧重复 (ETG.1500 5.4.3) =====================

    @property
    def frame_repeat_count(self) -> int:
        """
        获取帧重复次数
        1 = 禁用（默认），2-3 = 每周期发送 N 次相同 PDO 帧
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 1
        return _read_u8(ptr, _OFF_FRAME_REPEAT_COUNT)

    @frame_repeat_count.setter
    def frame_repeat_count(self, value: int):
        """设置帧重复次数，范围 1-3"""
        if value < 1 or value > 3:
            raise ValueError("帧重复次数必须在 1-3 范围内")
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u8(ptr, _OFF_FRAME_REPEAT_COUNT, value)

    # ===================== 互斥锁保护 =====================

    @property
    def mutex_protection(self) -> bool:
        """
        获取互斥锁保护是否启用
        启用后（默认）自动互斥锁保护，确保线程安全
        """
        return bool(self._dll.GetMutexProtection(self._mi))

    @mutex_protection.setter
    def mutex_protection(self, enable: bool):
        """设置互斥锁保护"""
        self._dll.SetMutexProtection(self._mi, enable)

    # ===================== 看门狗配置 (ETG.1000.4) =====================

    @property
    def process_data_watchdog_ms(self) -> int:
        """
        获取过程数据看门狗超时（毫秒）
        0 = 使用从站默认值（通常 100ms）
        寄存器: 0x0400 (分频器), 0x0420 (SM 看门狗计数值)
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 0
        return _read_u16(ptr, _OFF_WD_PD_TIMEOUT_MS)

    @process_data_watchdog_ms.setter
    def process_data_watchdog_ms(self, value: int):
        """设置过程数据看门狗超时（毫秒），上限 6553"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u16(ptr, _OFF_WD_PD_TIMEOUT_MS, min(max(0, value), 6553))

    @property
    def pdi_watchdog_ms(self) -> int:
        """
        获取 PDI 看门狗超时（毫秒）
        0 = 使用从站默认值（通常 100ms）
        寄存器: 0x0400 (分频器), 0x0410 (PDI 看门狗计数值)
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 0
        return _read_u16(ptr, _OFF_WD_PDI_TIMEOUT_MS)

    @pdi_watchdog_ms.setter
    def pdi_watchdog_ms(self, value: int):
        """设置 PDI 看门狗超时（毫秒），上限 6553"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u16(ptr, _OFF_WD_PDI_TIMEOUT_MS, min(max(0, value), 6553))

    # ===================== 状态转换超时配置 (ETG.1020) =====================

    @property
    def timeout_init_to_preop(self) -> int:
        """
        获取 INIT->PREOP 状态转换超时 (毫秒, ETG.1020 默认 3000)
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 3000
        return _read_u32(ptr, _OFF_TIMEOUT_INIT_TO_PREOP)

    @timeout_init_to_preop.setter
    def timeout_init_to_preop(self, value: int):
        """设置 INIT->PREOP 状态转换超时（毫秒）"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u32(ptr, _OFF_TIMEOUT_INIT_TO_PREOP, max(0, value))

    @property
    def timeout_preop_to_safeop(self) -> int:
        """
        获取 PREOP->SAFEOP 状态转换超时 (毫秒, ETG.1020 默认 10000)
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 10000
        return _read_u32(ptr, _OFF_TIMEOUT_PREOP_TO_SAFEOP)

    @timeout_preop_to_safeop.setter
    def timeout_preop_to_safeop(self, value: int):
        """设置 PREOP->SAFEOP 状态转换超时（毫秒）"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u32(ptr, _OFF_TIMEOUT_PREOP_TO_SAFEOP, max(0, value))

    @property
    def timeout_safeop_to_op(self) -> int:
        """
        获取 SAFEOP->OP 状态转换超时 (毫秒, ETG.1020 默认 5000)
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return 5000
        return _read_u32(ptr, _OFF_TIMEOUT_SAFEOP_TO_OP)

    @timeout_safeop_to_op.setter
    def timeout_safeop_to_op(self, value: int):
        """设置 SAFEOP->OP 状态转换超时（毫秒）"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u32(ptr, _OFF_TIMEOUT_SAFEOP_TO_OP, max(0, value))

    # ===================== 自适应超时 =====================

    @property
    def adaptive_timeout_enabled(self) -> bool:
        """
        获取自适应超时功能（默认启用）
        启用后多次采样实际网络 RTT 取最大值，PDO 超时设为 4*maxRTT
        """
        ptr = self._get_state_ptr(cached=True)
        if ptr is None:
            return False
        return _read_u8(ptr, _OFF_ADAPTIVE_TIMEOUT) != 0

    @adaptive_timeout_enabled.setter
    def adaptive_timeout_enabled(self, value: bool):
        """设置自适应超时功能"""
        ptr = self._get_state_ptr(cached=False)
        if ptr is None:
            return
        _write_u8(ptr, _OFF_ADAPTIVE_TIMEOUT, 1 if value else 0)

    # ===================== 本地配置字段 =====================

    @property
    def drift_compensation(self) -> bool:
        """
        DC 漂移补偿开关 (默认关闭)
        启用后主站周期性检测 DC 系统时间偏差并写入补偿值 (0x0920)
        """
        return self._drift_compensation

    @drift_compensation.setter
    def drift_compensation(self, value: bool):
        """设置 DC 漂移补偿"""
        self._drift_compensation = value

    @property
    def scan_revision_match(self) -> ScanRevisionMatchMode:
        """
        扫描时从站版本匹配策略
        Exact: VendorID + ProductID + RevisionID 精确匹配
        CompatibleHigher: VendorID + ProductID 匹配, RevisionID >= 配置值
        IgnoreRevision: 仅匹配 VendorID + ProductID (默认)
        """
        return self._scan_revision_match

    @scan_revision_match.setter
    def scan_revision_match(self, value: ScanRevisionMatchMode):
        """设置扫描版本匹配策略"""
        self._scan_revision_match = ScanRevisionMatchMode(value)

    # ===================== 邮箱配置 =====================

    @property
    def mailbox_config(self) -> 'MailboxConfig':
        """
        获取邮箱配置子对象
        通过 master.config.mailbox_config 访问
        """
        if not hasattr(self, '_mailbox_config') or self._mailbox_config is None:
            self._mailbox_config = MailboxConfig(self._dll, self._mi)
        return self._mailbox_config

    def __str__(self) -> str:
        """字符串表示: 主要配置参数摘要"""
        cycle_us = self.loop_cycle / 1000.0
        return (f"MasterConfig(cycle={cycle_us:.0f}us, "
                f"udp={'on' if self.use_udp else 'off'}, "
                f"mutex={'on' if self.mutex_protection else 'off'})")

    def __repr__(self) -> str:
        return (
            f"MasterConfig("
            f"loop_cycle={self.loop_cycle}ns, "
            f"frame_high_priority={self.frame_high_priority}, "
            f"use_udp={self.use_udp}, "
            f"vlan_id={self.vlan_id}, "
            f"vlan_priority={self.vlan_priority}, "
            f"overlapping_groups={self.overlapping_groups}, "
            f"packed_mode={self.packed_mode}, "
            f"mutex_protection={self.mutex_protection}, "
            f"process_data_watchdog_ms={self.process_data_watchdog_ms}, "
            f"pdi_watchdog_ms={self.pdi_watchdog_ms})"
        )


class MailboxConfig:
    """
    邮箱配置子对象
    对应 C# MasterConfig.MailboxConfig
    通过 master.config.mailbox_config 访问

    包含邮箱通信超时、重试等配置。
    """

    def __init__(self, dll, master_index: int):
        self._dll = dll
        self._mi = master_index

    @property
    def timeout_ms(self) -> int:
        """
        邮箱通信超时 (毫秒)
        默认 5000ms
        """
        if hasattr(self._dll, 'GetMailboxTimeout'):
            return self._dll.GetMailboxTimeout(self._mi)
        return 5000

    @timeout_ms.setter
    def timeout_ms(self, value: int):
        """设置邮箱通信超时"""
        if hasattr(self._dll, 'SetMailboxTimeout'):
            self._dll.SetMailboxTimeout(self._mi, max(0, value))

    @property
    def retry_count(self) -> int:
        """
        邮箱通信重试次数
        默认 3 次
        """
        if hasattr(self._dll, 'GetMailboxRetryCount'):
            return self._dll.GetMailboxRetryCount(self._mi)
        return 3

    @retry_count.setter
    def retry_count(self, value: int):
        """设置邮箱通信重试次数"""
        if hasattr(self._dll, 'SetMailboxRetryCount'):
            self._dll.SetMailboxRetryCount(self._mi, max(0, value))

    def __repr__(self) -> str:
        return f"MailboxConfig(timeout_ms={self.timeout_ms}, retry_count={self.retry_count})"
