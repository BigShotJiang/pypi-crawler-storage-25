# -*- coding: utf-8 -*-
"""
EtherCAT 主站状态管理
对应 C# Master/State.cs
提供主站/从站状态切换、关闭、中止等功能
"""

from typing import Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from .core import EtherCATMaster

from ..utils.dll import DarraCoreDLL, EcState, CORE_OP_22


class MasterStateManager:
    """
    主站状态管理器

    通过 master.state_manager 访问，提供状态切换、中止、关闭等方法。
    大部分功能已在 EtherCATMaster 中直接暴露，此类提供额外的精细控制。
    """

    def __init__(self, dll: DarraCoreDLL, master_index: int):
        """
        初始化状态管理器

        参数:
            dll: DLL 接口实例
            master_index: 主站索引
        """
        self._dll = dll
        self._mi = master_index

    @property
    def state(self) -> EcState:
        """获取当前主站状态"""
        ptr = self._dll.GetMasterState(self._mi)
        if not ptr:
            return EcState.NONE
        import ctypes
        # 主站状态头部的第一个字段是 state (uint16)
        raw = ctypes.cast(ptr, ctypes.POINTER(ctypes.c_ushort))
        return EcState(raw[0]) if raw else EcState.NONE

    def set_state(self, target: EcState, timeout_ms: int = 10000) -> bool:
        """
        切换主站状态（单步）

        参数:
            target: 目标状态
            timeout_ms: 超时（毫秒）

        返回:
            是否成功
        """
        return bool(self._dll.SetStateWithTimeout(self._mi, int(target), timeout_ms))

    def set_state_sequence(self, target: EcState, timeout_ms: int = 10000) -> bool:
        """
        链式自动状态转换 (Init->PreOp->SafeOp->OP) + 自动执行启动参数

        参数:
            target: 目标状态
            timeout_ms: 超时（毫秒）

        返回:
            是否成功
        """
        return bool(self._dll.DarraCoreInvoke(self._mi, CORE_OP_22, int(target), timeout_ms, 0))

    def set_slave_state(self, slave_index: int, target: EcState,
                        timeout_ms: int = 10000) -> bool:
        """
        单个从站状态转换

        参数:
            slave_index: 从站索引 (1-based)
            target: 目标状态
            timeout_ms: 超时（毫秒）

        返回:
            是否成功
        """
        return bool(self._dll.SetSlaveStateWithTimeout(
            self._mi, slave_index, int(target), timeout_ms))

    def get_slave_state(self, slave_index: int) -> EcState:
        """
        获取从站状态

        参数:
            slave_index: 从站索引 (1-based)

        返回:
            从站状态
        """
        raw = self._dll.GetSlaveState(self._mi, slave_index)
        return EcState(raw) if raw else EcState.NONE

    def get_slave_al_status_code(self, slave_index: int) -> int:
        """
        获取从站 AL Status Code

        参数:
            slave_index: 从站索引 (1-based)

        返回:
            AL Status Code
        """
        return int(self._dll.GetSlaveALStatusCode(self._mi, slave_index))

    def get_link_status(self) -> int:
        """
        获取链路状态

        返回:
            链路状态码
        """
        return int(self._dll.GetLinkStatus(self._mi))

    def wait_for_state(self, target: EcState, timeout_ms: int = 10000,
                       poll_interval_ms: int = 50) -> bool:
        """
        轮询等待主站到达指定状态 (对齐 C# WaitForState / C++ master_state::WaitForState)
        不发起状态切换, 仅等待已请求的转换完成 / PDO 流稳定确认

        参数:
            target:           目标状态
            timeout_ms:       最大等待 (毫秒)
            poll_interval_ms: 轮询间隔 (毫秒)

        返回:
            是否到达目标状态
        """
        import time
        deadline = time.monotonic() + max(0, timeout_ms) / 1000.0
        interval = max(0.001, poll_interval_ms / 1000.0)
        while time.monotonic() < deadline:
            if self.state == target:
                return True
            time.sleep(interval)
        return self.state == target

    def wait_for_slave_state(self, slave_index: int, target: EcState,
                             timeout_ms: int = 10000,
                             poll_interval_ms: int = 50) -> bool:
        """
        轮询等待单个从站到达指定状态 (PDO 启动后状态确认场景)

        参数:
            slave_index:      从站编号 (1-based)
            target:           目标状态
            timeout_ms:       最大等待 (毫秒)
            poll_interval_ms: 轮询间隔 (毫秒)

        返回:
            是否到达目标状态
        """
        import time
        deadline = time.monotonic() + max(0, timeout_ms) / 1000.0
        interval = max(0.001, poll_interval_ms / 1000.0)
        tgt = int(target) & 0x0F
        while time.monotonic() < deadline:
            cur = int(self._dll.GetSlaveState(self._mi, slave_index)) & 0x0F
            if cur == tgt:
                return True
            time.sleep(interval)
        cur = int(self._dll.GetSlaveState(self._mi, slave_index)) & 0x0F
        return cur == tgt

    @staticmethod
    def abort(dll: DarraCoreDLL):
        """
        中断 DLL 层所有阻塞操作
        可安全地从任意线程调用
        """
        try:
            dll.AbortNetwork()
        except Exception:
            pass

    def verify_startup_configuration(self) -> dict:
        """
        验证启动配置 (对应 C# VerifyStartupConfiguration)

        检查从站状态、PDO 映射、DC 配置是否正确,
        返回验证结果字典。

        返回:
            验证结果字典:
            {
                'valid': bool,         # 整体是否有效
                'slave_count': int,    # 在线从站数
                'issues': list[str],   # 问题描述列表
            }
        """
        issues = []

        # 1. 检查主站状态
        state = self.state
        if state == EcState.NONE or state == EcState.INIT:
            issues.append("主站未处于 PreOP 或更高状态")

        # 2. 检查链路状态
        link = self.get_link_status()
        if link == 0:
            issues.append("链路未连接")

        # 3. 逐从站检查
        slave_count = 0
        try:
            # 遍历从站, 检查状态
            for si in range(1, 256):
                try:
                    s_state = self._dll.GetSlaveState(self._mi, si)
                    if s_state == 0:
                        break  # 无更多从站
                    slave_count += 1
                    base = s_state & 0x0F
                    if base < 2:  # 低于 PreOP
                        issues.append(f"从站 {si} 状态异常: 0x{s_state:02X}")
                    if s_state & 0x10:  # Error 标志
                        al_code = int(self._dll.GetSlaveALStatusCode(self._mi, si))
                        issues.append(f"从站 {si} 有 AL 错误: 0x{al_code:04X}")
                except Exception:
                    break
        except Exception:
            pass

        # 4. 检查配置验证 (ETG.1500)
        try:
            result = self._dll.ec_validate_config(self._mi)
            if result != 0:
                issues.append(f"配置验证失败: 错误码 {result}")
        except Exception:
            pass

        return {
            'valid': len(issues) == 0,
            'slave_count': slave_count,
            'issues': issues,
        }

    def close(self):
        """
        关闭主站并释放资源
        """
        try:
            self._dll.AbortNetwork()
        except Exception:
            pass
        try:
            self._dll.Stop(self._mi)
        except Exception:
            pass
        try:
            self._dll.Dispose(self._mi)
        except Exception:
            pass
