# -*- coding: utf-8 -*-
"""
日志管理器 - 接收DLL回调, 推送到 LogView

对应 C# Logging.cs。

使用示例::

    from ethercat import EtherCATMaster, LogManager, LogCategory

    # 获取日志管理器
    log_mgr = LogManager.instance()

    # 获取默认日志视图
    logs = log_mgr.default_view

    # 只看错误和警告
    logs.set_filter(LogCategory.ERROR, LogCategory.WARNING)

    # 监听数据变化
    logs.on_updated = lambda: print(f"日志更新, 共 {logs.count} 条")

    # 遍历日志
    for entry in logs:
        print(entry)
"""

import threading
from datetime import datetime
from enum import IntEnum
from dataclasses import dataclass
from typing import Optional, Callable, List, Set, Iterator


# ===================== 日志类别 =====================

class LogCategory(IntEnum):
    """日志类别枚举 - 与DLL中的LogCategory对应"""
    ERROR = 0      # 错误 - 系统错误和异常
    WARNING = 1    # 警告 - 潜在问题
    MESSAGE = 2    # 消息 - 一般信息
    MAILBOX = 3    # Mailbox - CoE/SoE/FoE/EoE通信
    PDO = 4        # PDO - 过程数据对象交换
    DEBUG = 5      # 调试 - 详细调试信息
    LOCAL = 6      # 本地 - 控制台输出捕获

    def label(self) -> str:
        """获取日志类别标签"""
        _labels = {
            0: "ERROR",
            1: "WARNING",
            2: "MESSAGE",
            3: "MAILBOX",
            4: "PDO",
            5: "DEBUG",
            6: "LOCAL",
        }
        return _labels.get(self.value, "UNKNOWN")


# ===================== 日志条目 =====================

@dataclass
class LogEntry:
    """日志条目 - 包含时间戳、类别和消息"""
    timestamp: datetime    # 日志时间戳
    category: LogCategory  # 日志类别
    message: str           # 日志消息内容

    def __str__(self) -> str:
        """格式化为可读字符串"""
        ts = self.timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        return f"[{ts}] [{self.category.label()}] {self.message}"


# ===================== 日志视图 =====================

class LogView:
    """
    实时日志视图 - 只读列表，由日志系统内部自动维护

    特点:
    1. 用户只读，数据由 LogManager 自动更新
    2. 支持按日志类别过滤 (set_filter)
    3. on_updated 回调通知数据变化
    4. 超过上限自动移除最旧条目
    """

    # 条目上限，超过时自动移除最旧的 20%
    _MAX_ENTRIES = 10000
    _TRIM_COUNT = 2000

    def __init__(self):
        self._all_entries: List[LogEntry] = []
        self._filtered_cache: List[LogEntry] = []
        self._cache_invalid = True
        self._lock = threading.Lock()
        # 默认显示所有类别
        self._filter: Set[LogCategory] = set(LogCategory)
        # 是否保留所有日志 (默认 False: 每次关键操作前自动清空)
        self._retain = False
        # 数据更新回调
        self.on_updated: Optional[Callable[[], None]] = None

    @property
    def retain(self) -> bool:
        """
        是否保留所有日志 (默认 False)
        False: 每次关键操作前自动清空旧日志，只保留当前操作的日志
        True: 所有日志累积保留，不自动清空
        """
        return self._retain

    @retain.setter
    def retain(self, value: bool):
        self._retain = value

    def set_filter(self, *categories: LogCategory):
        """
        设置过滤器 - 只显示指定类别的日志

        参数:
            *categories: 要显示的日志类别
        """
        with self._lock:
            self._filter = set(categories)
            self._cache_invalid = True
        self._notify()

    @property
    def count(self) -> int:
        """当前过滤后的日志条数"""
        with self._lock:
            return len(self._get_filtered())

    def __getitem__(self, index: int) -> LogEntry:
        """按索引获取日志条目 (只读)"""
        with self._lock:
            return self._get_filtered()[index]

    def __len__(self) -> int:
        """获取过滤后的日志条数"""
        return self.count

    def __iter__(self) -> Iterator[LogEntry]:
        """遍历过滤后的日志 (返回快照，线程安全)"""
        with self._lock:
            snapshot = list(self._get_filtered())
        return iter(snapshot)

    def get_all(self) -> List[LogEntry]:
        """获取所有日志条目 (无视过滤器, 用于导出或自定义过滤)"""
        with self._lock:
            return list(self._all_entries)

    def _get_filtered(self) -> List[LogEntry]:
        """获取过滤后的缓存列表 (调用方需持有 _lock)"""
        if self._cache_invalid:
            self._filtered_cache = [
                e for e in self._all_entries
                if e.category in self._filter
            ]
            self._cache_invalid = False
        return self._filtered_cache

    def _notify(self):
        """触发更新回调"""
        cb = self.on_updated
        if cb is not None:
            try:
                cb()
            except Exception:
                pass

    # ===== 内部方法 (由 LogManager 调用) =====

    def _add(self, entry: LogEntry):
        """添加日志条目 (内部使用)"""
        with self._lock:
            self._all_entries.append(entry)
            # 超过上限时移除最旧的条目
            if len(self._all_entries) > self._MAX_ENTRIES:
                del self._all_entries[:self._TRIM_COUNT]
            self._cache_invalid = True
        self._notify()

    def _clear(self):
        """清空所有条目 (内部使用)"""
        with self._lock:
            self._all_entries.clear()
            self._cache_invalid = True
        self._notify()


# ===================== 日志管理器 =====================

class LogManager:
    """
    日志管理器 - 接收DLL回调, 推送到 LogView

    使用方式::

        log_mgr = LogManager.instance()
        logs = log_mgr.default_view
        logs.set_filter(LogCategory.ERROR, LogCategory.WARNING)
        logs.on_updated = lambda: print("新日志")
        for entry in logs:
            print(entry)
    """

    _instance: Optional['LogManager'] = None
    _instance_lock = threading.Lock()

    def __init__(self):
        self._default_view = LogView()
        self._operation_depth = 0

    @classmethod
    def instance(cls) -> 'LogManager':
        """获取单例实例"""
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @property
    def default_view(self) -> LogView:
        """默认日志视图"""
        return self._default_view

    def begin_operation(self):
        """标记操作开始 - 首层操作且 retain=False 时自动清空日志"""
        self._operation_depth += 1
        if self._operation_depth == 1 and not self._default_view.retain:
            self._default_view._clear()

    def end_operation(self):
        """标记操作结束"""
        if self._operation_depth > 0:
            self._operation_depth -= 1

    def add_log(self, category: LogCategory, message: str):
        """
        添加日志条目 (由DLL回调或内部调用)

        参数:
            category: 日志类别
            message: 日志消息
        """
        entry = LogEntry(
            timestamp=datetime.now(),
            category=category,
            message=message or "",
        )
        self._default_view._add(entry)

    def clear(self):
        """清空所有日志"""
        self._default_view._clear()
