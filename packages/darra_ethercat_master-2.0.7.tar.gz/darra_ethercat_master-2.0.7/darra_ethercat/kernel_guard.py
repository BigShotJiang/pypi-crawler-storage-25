# -*- coding: utf-8 -*-
"""
内核驱动可用性门控. 用法:

    from darra_ethercat import kernel_guard, DarraKernelNotAvailableError
    try:
        kernel_guard.assert_available()
        # ... master.initialize() / master.set_network() ...
    except DarraKernelNotAvailableError as e:
        print(f"内核驱动不可用: {e}")
        print(f"安装链接: {e.installer_url}")
        kernel_guard.open_installer_website()  # 可选
        sys.exit(1)

设计要点 (跟 C# KernelGuard.cs / utils/kernel_probe.h 对齐):
- DLL 没加载或没导出新 ordinal 时, probe() 返回 DarraKernelStatus.UnknownError
  而不是抛异常 — 兼容旧 DLL, 应用代码不需要特别处理 DLL_NOT_FOUND.
- 中文 status message 来自 native, SDK 端不维护字符串表;
  native 缺失时退化为通用兜底 "EtherCAT 内核驱动状态未知".
- 默认 installer URL 由 native 提供, 部署可通过环境变量 DARRA_INSTALLER_URL
  在 native 层覆盖 — Python 端不维护 URL.
"""

import webbrowser
from enum import IntEnum
from typing import Optional

from .utils.dll import DarraCoreDLL


class DarraKernelStatus(IntEnum):
    """内核驱动 (DarraRT_Eth.sys) 可用性诊断码.

    与 utils/kernel_probe.h 中 DarraKernelStatus / C# DarraKernelStatus 一一对应.
    SDK 不依赖具体 int, 应用代码只需对照本枚举。
    """
    Ok = 0
    NotInstalled = 1
    Stopped = 2
    AccessDenied = 3
    SignatureFail = 4
    Blocked = 5
    DeviceMissing = 6
    Disabled = 7
    UnknownError = 99


class DarraKernelNotAvailableError(Exception):
    """缺内核驱动时由 SDK 抛出.

    字段:
        status:        DarraKernelStatus 枚举
        message:       从 DLL 拿到的中文可读说明
        installer_url: 安装包下载链接

    应用层 catch 后可弹窗 / 调 open_installer_website() 引导用户.
    """

    def __init__(self, status: 'DarraKernelStatus', message: str, installer_url: str):
        self.status = status
        self.message = message or "EtherCAT 内核驱动不可用"
        self.installer_url = installer_url or ""
        full = self.message
        if self.installer_url:
            full = full + "\n安装链接: " + self.installer_url
        super().__init__(full)


# ===================== 模块级 DLL 单例 =====================

_dll_instance: Optional[DarraCoreDLL] = None


def _get_dll() -> Optional[DarraCoreDLL]:
    """惰性加载 DarraCoreDLL 单例; DLL 缺失时返回 None, 让上层走兜底逻辑."""
    global _dll_instance
    if _dll_instance is None:
        try:
            _dll_instance = DarraCoreDLL()
        except Exception:
            # DLL_NOT_FOUND / 文件锁定 / 依赖缺失等, 全部退化为不可用
            _dll_instance = None
    return _dll_instance


_DEFAULT_INSTALLER_URL = "https://www.darrart.com/downloads/drivers"
_DEFAULT_UNKNOWN_MESSAGE = "EtherCAT 内核驱动状态未知"


# ===================== 公开 API =====================


def probe() -> DarraKernelStatus:
    """探测当前内核驱动状态. 不抛异常.

    返回:
        DarraKernelStatus 枚举. DLL 缺失 / 旧 DLL 没导出 ordinal 时返回 UnknownError.
    """
    dll = _get_dll()
    if dll is None:
        return DarraKernelStatus.UnknownError
    try:
        code = dll.DarraEcat_KernelProbe()
        try:
            return DarraKernelStatus(int(code))
        except ValueError:
            # native 返回了未知编码值, 不在枚举里, 走 UnknownError
            return DarraKernelStatus.UnknownError
    except NotImplementedError:
        # 旧 DLL 没导出 D_1629
        return DarraKernelStatus.UnknownError
    except Exception:
        return DarraKernelStatus.UnknownError


def get_status_message(status: DarraKernelStatus) -> str:
    """把状态码转成可读消息 (从 DLL 拿). 失败退化为通用兜底字符串."""
    dll = _get_dll()
    if dll is None:
        return _DEFAULT_UNKNOWN_MESSAGE
    try:
        raw = dll.DarraEcat_KernelStatusMessage(int(status))
        if not raw:
            return _DEFAULT_UNKNOWN_MESSAGE
        # ctypes c_char_p restype 已自动转 bytes, native 端是 UTF-8
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="replace")
        return str(raw)
    except NotImplementedError:
        return _DEFAULT_UNKNOWN_MESSAGE
    except Exception:
        return _DEFAULT_UNKNOWN_MESSAGE


def get_installer_url() -> str:
    """获取安装包下载链接 (默认 https://www.darrart.com/downloads/drivers,
    部署可在 native 层通过环境变量 DARRA_INSTALLER_URL 覆盖)."""
    dll = _get_dll()
    if dll is None:
        return _DEFAULT_INSTALLER_URL
    try:
        raw = dll.DarraEcat_KernelInstallerUrl()
        if not raw:
            return _DEFAULT_INSTALLER_URL
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="replace")
        return str(raw)
    except NotImplementedError:
        return _DEFAULT_INSTALLER_URL
    except Exception:
        return _DEFAULT_INSTALLER_URL


def assert_available() -> None:
    """探测内核状态; 若不可用直接抛 DarraKernelNotAvailableError.

    应用层应在 master.initialize() / set_network() 之前调用; SDK 内部门控
    也会再调一次防御.
    """
    status = probe()
    if status == DarraKernelStatus.Ok:
        return
    raise DarraKernelNotAvailableError(
        status,
        get_status_message(status),
        get_installer_url(),
    )


def open_installer_website() -> bool:
    """用默认浏览器打开安装链接.

    应用层在 catch DarraKernelNotAvailableError 后可调用此方法引导用户下载.
    失败不抛异常 (浏览器缺失等环境问题不应再次中断业务流).

    返回:
        True 表示成功调起浏览器, False 表示 URL 为空 / 调起失败.
    """
    try:
        url = get_installer_url()
        if not url:
            return False
        return bool(webbrowser.open(url))
    except Exception:
        return False
