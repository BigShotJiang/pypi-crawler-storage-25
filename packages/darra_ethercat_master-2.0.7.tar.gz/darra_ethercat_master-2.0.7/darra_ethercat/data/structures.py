# -*- coding: utf-8 -*-
"""
对应 C# 文件: Data/Structures.cs
EtherCAT 数据结构定义

包含:
- EtherCAT 常量
- PDO 统计/映射结构体
- 网络适配器信息结构体
- SyncManager / FMMU 结构体
- 从站结构体
- 主站状态结构
- 诊断数据结构体
- 启动/配置结构体
"""

import ctypes
from ctypes import Structure, c_uint, c_ushort, c_ubyte, c_int, c_uint64, c_double, c_byte
from ctypes import c_int64, c_int32, c_int16, c_void_p, c_uint32, c_uint16, c_uint8


# ===================== 增强型邮箱协议定义 =====================

ECT_MBXPROT_AOE = 0x0001
ECT_MBXPROT_EOE = 0x0002
ECT_MBXPROT_COE = 0x0004
ECT_MBXPROT_FOE = 0x0008
ECT_MBXPROT_SOE = 0x0010
ECT_MBXPROT_VOE = 0x0020

# CoE 详细定义
ECT_COEDET_SDO       = 0x01
ECT_COEDET_SDOINFO   = 0x02
ECT_COEDET_PDOASSIGN = 0x04
ECT_COEDET_PDOCONFIG = 0x08
ECT_COEDET_UPLOAD    = 0x10
ECT_COEDET_SDOCA     = 0x20


# ===================== PDO 性能统计结构体 =====================

class PDOStats(Structure):
    """PDO 性能统计结构体 (对应 C# Structures.PDOStats, Pack=1, uint*5 + ulong*4)"""
    _pack_ = 1
    _fields_ = [
        ('read_count', c_uint),
        ('write_count', c_uint),
        ('error_count', c_uint),
        ('total_bytes_read', c_uint),
        ('total_bytes_written', c_uint),
        ('last_cycle_time_ns', c_uint64),
        ('min_cycle_time_ns', c_uint64),
        ('max_cycle_time_ns', c_uint64),
        ('avg_cycle_time_ns', c_uint64),
    ]


# ===================== PDO 映射项结构体 =====================

class PDOMappingEntry(Structure):
    """PDO 映射项结构体"""
    _pack_ = 1
    _fields_ = [
        ('index', c_ushort),
        ('sub_index', c_ubyte),
        ('bit_length', c_ubyte),
        ('bit_offset', c_ushort),
        ('name', c_ubyte * 64),
        ('unit', c_ubyte * 16),
        ('readable', c_ubyte),
        ('writable', c_ubyte),
    ]


# ===================== 网络适配器信息结构体 =====================

class NetworkInfo(Structure):
    """
    网络适配器信息结构体 - 对应 C 端 ec_networkinfo_t
    必须与 Core.h 中的定义完全一致（Pack=1, 总大小260字节）
    """
    _pack_ = 1
    _fields_ = [
        ('name', c_ubyte * 128),    # EC_MAXLEN_ADAPTERNAME = 128
        ('desc', c_ubyte * 128),    # EC_MAXLEN_ADAPTERNAME = 128
        ('slave_num', c_int16),     # 从站数量
        ('redundant_slave_num', c_int16),  # 受冗余保护的从站数
    ]


# ===================== 通信统计信息结构体 =====================

class CommunicationStats(Structure):
    """通信统计信息结构体"""
    _pack_ = 1
    _fields_ = [
        ('total_cycles', c_uint),
        ('successful_cycles', c_uint),
        ('failed_cycles', c_uint),
        ('timeout_cycles', c_uint),
        ('average_cycle_time_us', c_double),
        ('max_cycle_time_us', c_double),
        ('min_cycle_time_us', c_double),
    ]


# ===================== 从站详细信息结构体 =====================

class SlaveInfo(Structure):
    """从站详细信息结构体"""
    _pack_ = 1
    _fields_ = [
        ('vendor_id', c_uint),
        ('product_code', c_uint),
        ('revision_number', c_uint),
        ('serial_number', c_uint),
        ('device_name', ctypes.c_char * 64),
        ('vendor_name', ctypes.c_char * 64),
        ('sync_manager_count', c_ushort),
        ('fmmu_count', c_ushort),
        ('supports_coe', ctypes.c_bool),
        ('supports_foe', ctypes.c_bool),
        ('supports_eoe', ctypes.c_bool),
        ('supports_soe', ctypes.c_bool),
    ]


# ===================== 实时统计信息结构体 =====================

class RealtimeStats(Structure):
    """实时统计信息结构体"""
    _pack_ = 1
    _fields_ = [
        ('current_cycle_time_us', c_double),
        ('jitter_us', c_double),
        ('lost_frames', c_uint),
        ('corrupted_frames', c_uint),
        ('bus_utilization', c_double),
    ]


# ===================== SyncManager 配置结构体 =====================

class EcSmt(Structure):
    """
    SyncManager 配置结构体 - 对应 C# ec_smt
    """
    _pack_ = 1
    _fields_ = [
        ('start_addr', c_ushort),   # SM 起始地址
        ('sm_length', c_ushort),    # SM 长度
        ('sm_flags', c_uint32),     # SM 标志
    ]


# ===================== FMMU 配置结构体 =====================

class EcFmmut(Structure):
    """
    FMMU 配置结构体 - 对应 C# ec_fmmut
    """
    _pack_ = 1
    _fields_ = [
        ('log_start', c_uint32),    # 逻辑起始地址
        ('log_length', c_ushort),   # 逻辑长度
        ('log_start_bit', c_ubyte), # 逻辑起始位
        ('log_end_bit', c_ubyte),   # 逻辑结束位
        ('phys_start', c_ushort),   # 物理起始地址
        ('phys_start_bit', c_ubyte), # 物理起始位
        ('fmmu_type', c_ubyte),     # FMMU 类型
        ('fmmu_active', c_ubyte),   # FMMU 激活
        ('unused1', c_ubyte),       # 保留
        ('unused2', c_ushort),      # 保留
    ]


# ===================== Slave I/O 描述符 (slave_io_desc_t) =====================

class SlaveIoDesc(Structure):
    """
    Slave I/O 描述符 - 对应 C 端 master.h 中 slave_io_desc_t

    原平面字段 obits/obytes/outputs/ooffset/ostartbit (×2 输入/输出) 收敛为 sub-struct.
    嵌入到 EcSlave 中段 (dtype 之后, sm 之前) 各 1 个 (output / input).
    自然对齐 (无 _pack_), 64 位下 24 字节: bits(2)+pad(2)+bytes(4)+ptr(8)+offset(4)+startbit(1)+pad(3).
    ctypes 自然对齐自动处理填充.
    """
    _fields_ = [
        ('bits', c_uint16),         # I/O 位数
        ('bytes', c_uint32),        # I/O 字节数
        ('ptr', c_void_p),          # I/O 指针 (IOmap 中, uint8_t*)
        ('offset', c_uint32),       # I/O 偏移 (IOmap 中)
        ('startbit', c_uint8),      # 第一个 I/O 字节的起始位
    ]


# ===================== Slave FSoE 子结构 (ETG.5100/5120) =====================

class SlaveFsoe(Structure):
    """
    Slave FSoE 子结构 - 对应 C 端 master.h 中 slave_fsoe_t

    嵌入到 EcSlave 中段 (eep_ser 之后, itype 之前), 自然对齐 (无 _pack_).
    64 位下: capable (1) + 7 字节隐式填充 + connection (8) + sm_context (8) +
             connection_id/safety_address/safe_input_size/safe_output_size (8) +
             pdo_input_offset/pdo_output_offset (8) = 40 字节.
    """
    _fields_ = [
        ('capable', c_uint8),                # FSoE 能力标志
        ('connection', c_void_p),            # FSoE 连接指针
        ('sm_context', c_void_p),            # FSoE 状态机上下文指针
        ('connection_id', c_uint16),         # FSoE 连接 ID
        ('safety_address', c_uint16),        # FSoE 安全地址
        ('safe_input_size', c_uint16),       # FSoE 安全输入大小（字节）
        ('safe_output_size', c_uint16),      # FSoE 安全输出大小（字节）
        ('pdo_input_offset', c_uint32),      # FSoE PDO 输入偏移
        ('pdo_output_offset', c_uint32),     # FSoE PDO 输出偏移
    ]


# ===================== Slave 邮箱子结构 (与 master.h slave_mailbox_t 一致) =====================

class SlaveMailbox(Structure):
    """
    Slave 邮箱子结构 - 对应 C 端 master.h 中 slave_mailbox_t

    原平面字段 mbx_l / mbx_wo / mbx_rl / mbx_ro / mbx_proto / mbx_cnt 收敛为 sub-struct.
    嵌入到 EcSlave 中段 (FMMU 函数之后, hasdc 之前), 自然对齐 (无 _pack_).
    64 位下: 5 × uint16 (10) + uint8 (1) + 1 字节隐式填充 = 12 字节.
    """
    _fields_ = [
        ('length', c_uint16),                # 写邮箱长度 (mbx_l)
        ('write_offset', c_uint16),          # 写邮箱偏移 (mbx_wo)
        ('read_length', c_uint16),           # 读邮箱长度 (mbx_rl)
        ('read_offset', c_uint16),           # 读邮箱偏移 (mbx_ro)
        ('supported_proto', c_uint16),       # 支持的邮箱协议 ECT_MBXPROT_* (mbx_proto)
        ('cnt', c_uint8),                    # 邮箱链路层协议计数器 (mbx_cnt)
    ]


# ===================== Slave EEPROM 配置子结构 (与 master.h slave_eeprom_config_t 一致) =====================

class SlaveEepromConfig(Structure):
    """
    Slave EEPROM 配置子结构 - 对应 C 端 master.h 中 slave_eeprom_config_t

    原平面字段 SIIindex / eep_8byte / eep_pdi 收敛为 sub-struct.
    嵌入到 EcSlave 中段 (dc_active 之后, coe_details 之前), 自然对齐 (无 _pack_).
    64 位下: uint16 (2) + uint8 (1) + uint8 (1) = 4 字节.
    """
    _fields_ = [
        ('sii_index', c_uint16),             # SII 配置索引 (SIIindex)
        ('read_8byte', c_uint8),             # 1=8字节读, 0=4字节读 (eep_8byte)
        ('pdi', c_uint8),                    # 0=EEPROM归主站, 1=归PDI (eep_pdi)
    ]


# ===================== Slave 邮箱处理器子结构 (与 master.h slave_handler_t 一致) =====================

class SlaveHandler(Structure):
    """
    Slave 邮箱处理器子结构 - 对应 C 端 master.h 中 slave_handler_t

    原平面字段 mbxhandlerstate / mbxrmpstate / mbxinstateex 收敛为 sub-struct.
    嵌入到 EcSlave 中段 (po2so_config 之后, coe_mbx_in 之前), 自然对齐 (无 _pack_).
    64 位下: int32 (4) + int32 (4) + uint16 (2) + 2 字节隐式填充 = 12 字节.
    """
    _fields_ = [
        ('state', c_int32),                  # 邮箱处理状态 (mbxhandlerstate, 0=no handler, 1=cyclic, 2=lost)
        ('rmp_state', c_int32),              # 邮箱 RMP 状态 (mbxrmpstate)
        ('instate_ex', c_uint16),            # 邮箱扩展状态 (mbxinstateex)
    ]


# ===================== Slave Identity 子结构 (与 master.h slave_identity_t 一致) =====================

class SlaveIdentity(Structure):
    """
    Slave Identity 子结构 - 对应 C 端 master.h 中 slave_identity_t

    原平面字段 eep_man / eep_id / eep_rev / eep_ser / Itype / Dtype 收敛为 sub-struct.
    嵌入到 SlaveMetadata 头部, 自然对齐 (无 _pack_).
    64 位下: 4×u32 (16) + 2×u16 (4) = 20 字节.
    """
    _fields_ = [
        ('vendor_id', c_uint32),             # 制造商 (eep_man)
        ('product_id', c_uint32),            # 产品 ID (eep_id)
        ('revision', c_uint32),              # 修订版本 (eep_rev)
        ('serial', c_uint32),                # 序列号 (eep_ser)
        ('itype', c_uint16),                 # 接口类型 (Itype)
        ('dtype', c_uint16),                 # 设备类型 (Dtype)
    ]


# ===================== Slave Metadata 子结构 (与 master.h slave_metadata_t 一致) =====================

class SlaveMetadata(Structure):
    """
    Slave Metadata 子结构 - 对应 C 端 master.h 中 slave_metadata_t

    Phase 2-D: 头部嵌入 identity (vendor_id / product_id / revision / serial / itype / dtype).
    原平面字段 group_name / device_name / sync_manager_count 跟随其后.
    嵌入到 EcSlave 中段 (mbx_status 之后), 自然对齐 (无 _pack_).
    64 位下: 20 (identity) + 41 + 41 + 2 + 隐式填充 ≈ 104 字节.
    """
    _fields_ = [
        ('identity', SlaveIdentity),         # 标识 (vendor_id/product_id/revision/serial/itype/dtype)
        ('group_name', c_ubyte * 41),        # 组名称 (EC_MAXNAME + 1)
        ('device_name', c_ubyte * 41),       # 设备名称 (EC_MAXNAME + 1)
        ('sm_count', c_uint16),              # SM 数量 (sync_manager_count)
    ]


# ===================== Slave Capabilities 子结构 (与 master.h slave_capabilities_t 一致) =====================

class SlaveCapabilities(Structure):
    """
    Slave Capabilities 子结构 - 对应 C 端 master.h 中 slave_capabilities_t

    Phase 2-D: 收敛 Darra 扩展字段 is_optional / supports_frame_repeat / mailbox_side
    + 协议详情 coe_details / foe_details / eoe_details / soe_details 共 7 字节 (含填充).
    C 端嵌入位置: SM_app_length[MAXSM] 之后, startup_queue 之前.
    SDK 端紧接 pdo_config 之后. 自然对齐 (无 _pack_).
    """
    _fields_ = [
        ('is_optional', c_uint8),            # 0=必须从站, 1=可选 (缺席不影响 WKC)
        ('supports_frame_repeat', c_uint8),  # 0=不支持, 1=支持 ETG.1500 帧重复
        ('mailbox_side', c_uint8),           # 0=auto/dual, 1=primary_only, 2=secondary_only
        ('coe_details', c_uint8),            # CoE 协议详情 (CoEdetails)
        ('foe_details', c_uint8),            # FoE 协议详情 (FoEdetails)
        ('eoe_details', c_uint8),            # EoE 协议详情 (EoEdetails)
        ('soe_details', c_uint8),            # SoE 协议详情 (SoEdetails)
    ]


# ===================== Slave Runtime 子结构 (与 master.h slave_runtime_t 一致) =====================

class SlaveRuntime(Structure):
    """
    Slave Runtime 子结构 - 对应 C 端 master.h 中 slave_runtime_t

    Phase 2-D: 原平面字段 Ebuscurrent / blockLRW / group / islost 收敛为 sub-struct.
    自然对齐 (无 _pack_).
    64 位下: int16 (2) + 3×u8 (3) + 隐式填充 ≈ 6 字节 (按 i16 对齐到 6).
    """
    _fields_ = [
        ('ebus_current', c_int16),           # E-bus 电流 (Ebuscurrent)
        ('block_lrw', c_uint8),              # 若 >0 禁止使用 LRW (blockLRW)
        ('group', c_uint8),                  # 分组 (group)
        ('is_lost', c_uint8),                # 从站是否丢失 (islost)
    ]


# ===================== Slave SM/FMMU 子结构 (与 master.h slave_sm_fmmu_t 一致) =====================

class SlaveSmFmmu(Structure):
    """
    Slave SM/FMMU 子结构 - 对应 C 端 master.h 中 slave_sm_fmmu_t

    Phase 2-D: 原平面 SMtype[8] / SM_app_length[8] / FMMU0..3func / FMMUunused 收敛.
    自然对齐 (无 _pack_).
    64 位下: 8×u8 (SMtype) + 8×u16 (SM_app_length, 对齐到 2) + 4×u8 (fmmu_func) + 1×u8 = 29 字节.
    """
    _fields_ = [
        ('sm_type', c_uint8 * 8),            # SM 类型 (SMtype)
        ('sm_app_length', c_uint16 * 8),     # SM 应用层长度 (SM_app_length)
        ('fmmu_func', c_uint8 * 4),          # FMMU 0-3 功能 (FMMU0..3func)
        ('fmmu_unused', c_uint8),            # 第一个未使用的 FMMU (FMMUunused)
    ]


# ===================== Slave 协议邮箱 sub-struct (与 master.h slave_proto_mbx_t 一致) =====================

class SlaveProtoMbx(Structure):
    """
    Slave 协议邮箱 sub-struct - 对应 C 端 master.h 中 slave_proto_mbx_t

    Phase 2-D: 原平面字段 coembxin / coembxinfull / coembxoverrun (× 6 协议) 收敛为 sub-struct.
    每个协议 (CoE/SoE/FoE/EoE/VoE/AoE) 各 1 个 SlaveProtoMbx.

    Python 注意: ctypes 字段名 `in` 是关键字, 改用 `in_ptr`. ABI 偏移与 C 一致, 字段名不影响 layout.
    自然对齐 (无 _pack_).
    64 位下: ptr (8) + bool (1) + 3 字节填充 + int (4) = 16 字节.
    """
    _fields_ = [
        ('in_ptr', c_void_p),                # 邮箱输入缓冲区指针 (C 端字段名 in)
        ('in_full', ctypes.c_bool),          # 邮箱输入是否满 (in_full)
        ('overrun', c_int32),                # 邮箱溢出计数 (overrun)
    ]


# ===================== Slave PDO 配置子结构 (与 master.h slave_pdo_config_t 一致) =====================

class SlavePdoConfig(Structure):
    """
    Slave PDO 配置子结构 - 对应 C 端 master.h 中 slave_pdo_config_t

    原平面字段 pdo_assignment_enabled / pdo_configuration_enabled / pdo_config_initialized /
    supports_complete_access 收敛为 sub-struct.
    嵌入到 EcSlave 中段 (mbx_status 之后, 跟 metadata 相邻), 自然对齐 (无 _pack_), 4 字节.
    """
    _fields_ = [
        ('assignment_enabled', c_uint8),       # 是否写入 PDO Assignment 0x1C12/0x1C13
        ('configuration_enabled', c_uint8),    # 是否写入 PDO Configuration
        ('config_initialized', c_uint8),       # PDO 配置是否已从 ESI 初始化
        ('supports_complete_access', c_uint8), # 是否支持 Complete Access
    ]


# ===================== Slave 拓扑子结构 (与 master.h slave_topology_t 一致) =====================

class SlaveTopology(Structure):
    """
    Slave 拓扑子结构 - 对应 C 端 master.h 中 slave_topology_t

    原平面字段 hasdc / ptype / topology / activeports / consumedports / parent / parentport /
    entryport 收敛为 sub-struct.
    嵌入到 EcSlave 中段 (mbx 之后, eeprom_config 之前), 自然对齐 (无 _pack_).
    64 位下: 5×u8 (5) + 1 字节填充 + u16 (2) + 2×u8 (2) = 10 字节.
    """
    _fields_ = [
        ('has_dc', c_uint8),                 # 是否支持 DC (hasdc)
        ('phy_type', c_uint8),               # 物理端口类型 (ptype)
        ('link_count', c_uint8),             # 拓扑类型 (topology)
        ('active_ports', c_uint8),           # 活动端口位图 (activeports)
        ('consumed_ports', c_uint8),         # 已使用端口位图 (consumedports)
        ('parent', c_uint16),                # 父从站站地址 (parent)
        ('parent_port', c_uint8),            # 父从站端口号 (parentport)
        ('entry_port', c_uint8),             # 入口端口号 (entryport)
    ]


# ===================== Slave DC 子结构 (与 master.h slave_dc_t 一致) =====================

class SlaveDc(Structure):
    """
    Slave DC 子结构 - 对应 C 端 master.h 中 slave_dc_t

    原平面字段 DCrtA..D / pdelay / DCnext / DCprevious / DCcycle / DCcycle1 / DCshift /
    DCactive 收敛为 sub-struct.
    嵌入到 EcSlave 中段 (topo 之后, eeprom_config 之前), 自然对齐 (无 _pack_).
    64 位下: int32[4] (16) + int32 (4) + 2×u16 (4) + 3×int32 (12) + u16 (2) +
             2 字节尾部填充 = 40 字节.
    """
    _fields_ = [
        ('recvtime', c_int32 * 4),           # 端口 A/B/C/D DC 接收时间 (纳秒) (DCrtA..D)
        ('propagation_delay', c_int32),      # 传播延迟 (纳秒) (pdelay)
        ('next', c_uint16),                  # DC 链中下一个从站 (DCnext)
        ('prev', c_uint16),                  # DC 链中上一个从站 (DCprevious)
        ('cycle0', c_int32),                 # DC SYNC0 周期 (纳秒) (DCcycle)
        ('cycle1', c_int32),                 # DC SYNC1 周期 (纳秒) (DCcycle1)
        ('shift', c_int32),                  # DC 相位偏移 (纳秒) (DCshift)
        ('active', c_uint16),                # DC AssignActivate 值, 0=禁用 (DCactive)
    ]


# ===================== 从站结构体 =====================

class EcSlave(Structure):
    """
    从站结构体 - 对应 C 端 master.h 中 slave_t (字节级一致)

    Phase 2-D 重构后, 字段排列严格匹配 DLL slave_t 顺序:
        state, ALstatuscode, configadr, aliasadr,
        fsoe (sub),
        output (slave_io_desc), input (slave_io_desc),
        SM[8], FMMU[4],
        sm_fmmu (sub: sm_type[8]/sm_app_length[8]/fmmu_func[4]/fmmu_unused),
        mbx (sub),
        topo (sub),
        dc (sub),
        eeprom_config (sub),
        runtime (sub: ebus_current/block_lrw/group/is_lost),
        PO2SOconfig (函数指针),
        handler (sub),
        coe, soe, foe, eoe, voe, aoe (各 SlaveProtoMbx),
        mbxstatus (uint8*),
        metadata (sub: identity{...} + group_name + device_name + sm_count),
        pdo_config (sub),
        capabilities (sub: is_optional/supports_frame_repeat/mailbox_side/coe_details/foe_details/eoe_details/soe_details),
        startup_queue (占位, 兼容内存对齐),
        mbx_lock_handle (void*),
        mbx_stats[16] (兼容预留, 仅保证 ABI 尾部不被截断).

    自然对齐 (无 _pack_), ctypes 会按字段对齐自动插入填充, 与 C 自然对齐结果一致.
    """
    _fields_ = [
        # ==================== 基本状态字段 ====================
        ('state', c_ushort),                 # 当前 EtherCAT 状态
        ('al_status_code', c_ushort),        # AL 状态码 (ALstatuscode)
        ('config_addr', c_ushort),           # 配置地址 (configadr)
        ('alias_addr', c_ushort),            # 别名地址 (aliasadr)

        # ==================== FSoE 子结构 (ETG.5100/5120) ====================
        # ctypes 自然对齐会在 alias_addr 后插入 4 字节填充, 把 fsoe 对齐到 8 字节边界.
        ('fsoe', SlaveFsoe),                 # FSoE 子状态 (40 字节)

        # ==================== I/O 描述符 sub-struct ====================
        ('output', SlaveIoDesc),             # 输出 (PDO Tx from master), 24 字节
        ('input', SlaveIoDesc),              # 输入 (PDO Rx to master), 24 字节

        # ==================== SM / FMMU 数组 ====================
        ('sm', EcSmt * 8),                   # 8 个 SyncManager 条目 (SM[MAXSM])
        ('fmmu', EcFmmut * 4),               # 4 个 FMMU 条目 (FMMU[MAXFMMU])

        # ==================== SM/FMMU sub-struct (Phase 2-D 收敛 SMtype/SM_app_length/FMMUxfunc/FMMUunused) ====================
        ('sm_fmmu', SlaveSmFmmu),

        # ==================== 邮箱配置 sub-struct ====================
        ('mbx', SlaveMailbox),               # 邮箱长度/偏移/协议/计数器

        # ==================== 拓扑 sub-struct ====================
        ('topo', SlaveTopology),             # 拓扑信息

        # ==================== DC sub-struct ====================
        ('dc', SlaveDc),                     # DC 信息

        # ==================== EEPROM 配置 sub-struct ====================
        ('eeprom_config', SlaveEepromConfig),# SII 索引/读宽度/PDI

        # ==================== Runtime sub-struct (Phase 2-D 收敛 Ebuscurrent/blockLRW/group/islost) ====================
        ('runtime', SlaveRuntime),

        # ==================== 函数指针 ====================
        ('po2so_config', c_void_p),          # PO->SO 配置函数指针 (PO2SOconfig)

        # ==================== 邮箱处理器 sub-struct ====================
        ('handler', SlaveHandler),           # 邮箱处理器状态

        # ==================== 6 个协议邮箱 (coe/soe/foe/eoe/voe/aoe) ====================
        # Phase 2-D 收敛 coembxin/coembxinfull/coembxoverrun ... 为 SlaveProtoMbx 各 1.
        ('coe', SlaveProtoMbx),
        ('soe', SlaveProtoMbx),
        ('foe', SlaveProtoMbx),
        ('eoe', SlaveProtoMbx),
        ('voe', SlaveProtoMbx),
        ('aoe', SlaveProtoMbx),

        # ==================== 邮箱状态缓冲区指针 ====================
        ('mbx_status', c_void_p),            # 邮箱状态寄存器缓冲区指针 (mbxstatus)

        # ==================== Metadata sub-struct (头部 identity + group_name/device_name/sm_count) ====================
        ('metadata', SlaveMetadata),

        # ==================== PDO 配置 sub-struct ====================
        ('pdo_config', SlavePdoConfig),

        # ==================== Capabilities sub-struct (含 coe_details/foe_details/eoe_details/soe_details) ====================
        ('capabilities', SlaveCapabilities),

        # ==================== Startup 队列 (C 端 startup_queue_t) ====================
        # 64 位下: ptr (8) + count u16 (2) + capacity u16 (2) + 4 字节尾部填充 = 16 字节.
        ('startup_queue_params', c_void_p),  # 动态参数数组指针
        ('startup_queue_count', c_uint16),   # 当前参数数量
        ('startup_queue_capacity', c_uint16),# 已分配容量
        ('_startup_queue_pad', c_uint32),    # 64 位对齐尾部填充

        # ==================== 邮箱锁柄 ====================
        ('mbx_lock_handle', c_void_p),       # CRITICAL_SECTION* / pthread_mutex_t* (mbx_lock_handle)

        # ==================== 邮箱事务统计数组 (16 槽 × 72 字节 = 1152 B, C 端 mbx_stats[16]) ====================
        # 每槽 struct mbx_stats: 6×u64 (48) + u32 last_error_code (4) + 4 字节填充 +
        #                       u64 last_error_time_us (8) + u64 total_latency_us (8) = 72 字节.
        # SDK 不直接读, 仅占位保证 sizeof(slave_t) 一致.
        ('mbx_stats_opaque', c_uint8 * (16 * 72)),
    ]


# ===================== 主站状态结构体 =====================

class EcState(Structure):
    """
    主站状态结构 - 对应 C# 主站状态结构
    所有主站配置属性都存储在此结构中
    通过 GetMasterState() 获取指针后直接读写字段
    """
    _fields_ = [
        # ==================== EtherCAT 状态 ====================
        ('state', c_ushort),                # 当前 EtherCAT 状态
        ('al_status_code', c_ushort),       # AL 状态码
        ('slave_count', c_int32),           # 网络中的从站数量

        # ==================== 时间配置 ====================
        ('loop_cycle', c_uint32),           # 循环周期时间（纳秒）
        ('dc_cycle', c_uint32),             # DC 诊断监控基准周期（纳秒）
        ('dc_time', c_int64),               # DC 时间（实时值）

        # ==================== PDO 数据缓冲区 ====================
        ('iomap', c_ubyte * 65536),         # IO 映射缓冲区
        ('iomap_mutex', c_void_p),          # IOmap 访问同步互斥锁

        # 双缓冲区支持
        ('iomap_buffer', c_ubyte * 65536),  # 双缓冲区
        ('buffer_version', c_uint32),       # 版本计数器
        ('buffer_dirty', c_ubyte),          # 脏标志

        # ==================== 互斥锁保护配置 ====================
        ('mutex_protection', c_ubyte),      # 1 = 自动锁定, 0 = 无自动锁定

        # ==================== CPU 亲和性配置 ====================
        ('pdo_cpu_affinity', c_byte),       # PDO 线程 CPU 核心绑定 (-1 = 未配置)

        # ==================== DC 自动偏移配置 ====================
        ('dc_auto_shift_enabled', c_ubyte), # 0 = 禁用, 1 = 启用

        # ==================== 网络配置 ====================
        ('use_udp', c_ubyte),               # 0 = 标准帧, 1 = UDP 帧

        # ==================== 可选功能开关 ====================
        ('adaptive_timeout_enabled', c_ubyte),  # 自适应超时 (0=禁用, 1=启用)

        # ==================== PDO 通信优化 ====================
        ('overlapping_groups', c_ubyte),    # 重叠组 (0=禁用, 1=启用)
        ('packed_mode', c_ubyte),            # Packed PDO 映射 (0=字节对齐, 1=bit紧密)

        # ==================== 帧优先级配置 ====================
        ('frame_high_priority', c_ubyte),   # 帧高优先级 (0=禁用, 1=启用)

        # ==================== VLAN 配置 ====================
        ('vlan_id', c_ushort),              # VLAN ID (0=禁用)
        ('vlan_priority', c_ubyte),         # VLAN 优先级 (0-7)

        # ==================== 状态转换超时 (ETG.1020) ====================
        ('timeout_init_to_preop', c_uint32),    # INIT->PREOP 超时 (ms)
        ('timeout_preop_to_safeop', c_uint32),  # PREOP->SAFEOP 超时 (ms)
        ('timeout_safeop_to_op', c_uint32),     # SAFEOP->OP 超时 (ms)

        # ==================== 看门狗配置 (ETG.1000.4) ====================
        ('wd_pd_timeout_ms', c_ushort),     # 过程数据看门狗超时 (ms)
        ('wd_pdi_timeout_ms', c_ushort),    # PDI 看门狗超时 (ms)

        ('filter_threshold', c_uint32),  # 判断滤波阈值

        # ==================== 帧重复 (ETG.1500 5.4.3) ====================
        ('frame_repeat_count', c_ubyte),    # 帧重复次数

        # ==================== 组配置 ====================
        ('active_group_count', c_ubyte),    # 活跃组数量
        ('_group_pad', c_ubyte * 2),        # 对齐填充
        ('group_config_raw', c_ubyte * 64), # 8组 x 8字节 = 64字节
    ]


# ===================== 已废弃 struct 占位 =====================
# [2026-05-08 已废弃, Phase 2-x 重构后无引用, 与 C# 同步删除]
#   - EcConfigListEnhanced / ConfigListEnhanced (从站配置列表)
#   - EcStartupListEnhanced / StartupListEnhanced (启动配置)
#   - EcDcListEnhanced / DcListEnhanced (DC 配置列表)
#   - EcAdapterEnhanced / AdapterEnhanced (网络适配器)
#   - EcStartupParam (legacy 启动参数, 与 utils/dll.py StartupParam Pack=1 正确版冲突)
# 启动参数请使用 darra_ethercat.utils.dll.StartupParam (256 字节缓冲, ABI 与 C 一致).


# ===================== 内部诊断数据结构体 =====================

class InternalDiagnostics(Structure):
    """
    内部诊断数据结构 - 对应 C 层 internal_diagnostics_t
    这是所有统计信息的唯一所有者
    使用 GetDiagnosticsPointer() 进行零拷贝访问
    注意：不使用 pack=1，因为 C 端也使用自然对齐
    """
    _fields_ = [
        # ==================== 实时性能数据 ====================
        ('cache_cnt', c_uint32),             # 当前秒内的周期计数
        ('rt_cnt', c_uint32),                # 上一秒的周期计数（频率Hz）
        ('cycle_count', c_uint32),           # 累计总周期数

        ('error_cache_cnt', c_uint32),       # 当前秒内的错误计数
        ('error_cnt', c_uint32),             # 上一秒的错误计数

        ('wkc', c_ushort),                   # 当前工作计数器
        ('expected_wkc', c_ushort),          # 期望工作计数器

        ('cycle_time_span', c_uint32),       # 最近一次周期耗时（微秒）

        # ==================== 帧错误统计（累计） ====================
        ('frame_errors', c_uint32),          # 总帧错误数
        ('lost_frames', c_uint32),           # 丢失帧数
        ('out_of_order_frames', c_uint32),   # 乱序帧数
        ('checksum_errors', c_uint32),       # 校验和错误数
        ('timeout_frames', c_uint32),        # 超时帧数

        # ==================== 从站级错误计数器 (EC_MAXSLAVE=512) ====================
        ('rx_error_count', c_uint32 * 512),       # 每个从站的接收错误计数
        ('tx_error_count', c_uint32 * 512),       # 每个从站的发送错误计数
        ('lost_link_count', c_ushort * 512),      # 每个从站的链路丢失计数
        ('invalid_frame_count', c_ushort * 512),  # 每个从站的无效帧计数

        # ==================== WKC 统计 ====================
        ('working_counter_errors', c_ushort),     # WKC 错误次数
        ('consecutive_wkc_errors', c_ushort),     # 连续 WKC 错误次数
        ('total_wkc_mismatches', c_uint32),       # WKC 不匹配总次数

        # ==================== 时间统计 ====================
        ('cycle_start_time', c_uint64),            # 周期开始时间戳（纳秒）
        ('cycle_time_accumulator', c_double),      # 周期时间累加器
        ('last_snapshot_time', c_uint64),          # 上次快照时间戳（秒）
        ('snapshot_cycle_count', c_uint32),        # 上次快照时的 cycle_count

        # ==================== 抖动统计 (1秒窗口) ====================
        ('last_cycle_time_us', c_double),          # 上一次周期时间（微秒）
        ('jitter_accumulator', c_double),          # 1秒内抖动累加器
        ('max_jitter_in_second', c_double),        # 1秒内最大抖动（微秒）
        ('jitter_sample_count', c_uint32),         # 1秒内抖动采样数

        # [2026-05-08 已删除 avg_jitter_us 之后的所有元素, 与 C# 同步]
        # 原因: C 端 internal_diagnostics_t 在 jitter_sample_count 之后偏移布局已变,
        #       avg_jitter_us / max_jitter_us / cycle_time_sample_count /
        #       primary_port_* / secondary_port_* / link_quality_percent /
        #       last_good_frame_time / initialized / enabled / win_* / win_head /
        #       win_filled 字段与 C 端不再对齐, 0 引用, 直接删除避免误读.
        # 主端口/副端口/抖动等 snapshot 数据请改读
        # darra_ethercat.master.diagnostics._NativeSummary (ec_diagnostics_summary_t).
    ]


# ===================== FoE 扩展选项结构体 =====================

class FoEOptionsStruct(Structure):
    """FoE 扩展选项结构"""
    _pack_ = 1
    _fields_ = [
        ('enable_crc', c_ubyte),
        ('strict_mode', c_ubyte),
        ('auto_append_crc', c_ubyte),
        ('expected_crc', c_uint),
        ('crc_progress_callback', c_void_p),
        ('crc_callback_userdata', c_void_p),
        ('reserved', c_uint * 8),
    ]

    @staticmethod
    def default():
        """初始化为默认值"""
        opts = FoEOptionsStruct()
        opts.enable_crc = 0
        opts.strict_mode = 1
        opts.auto_append_crc = 1
        opts.expected_crc = 0
        return opts


# ===================== 组配置辅助方法 =====================

class EcGroupConfigHelper:
    """
    组配置辅助方法

    对应 C# EcGroupConfigHelper
    操作 主站状态.group_config_raw 中每组 8 字节的配置数据。
    布局: [enabled:1][cycle_divider:1][expected_wkc:2][slave_count:2][frame_repeat_eligible:1][reserved:1]
    """

    GROUP_CONFIG_SIZE = 8

    @staticmethod
    def get_group_enabled(group_config_raw: bytes, group: int) -> bool:
        """获取组是否启用"""
        if group >= 8:
            return False
        return group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE] != 0

    @staticmethod
    def set_group_enabled(group_config_raw: bytearray, group: int, enabled: bool):
        """设置组启用状态"""
        if group >= 8:
            return
        group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE] = 1 if enabled else 0

    @staticmethod
    def get_group_cycle_divider(group_config_raw: bytes, group: int) -> int:
        """获取组周期分频器"""
        if group >= 8:
            return 0
        return group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 1]

    @staticmethod
    def set_group_cycle_divider(group_config_raw: bytearray, group: int, divider: int):
        """设置组周期分频器"""
        if group >= 8:
            return
        group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 1] = divider & 0xFF

    @staticmethod
    def get_group_expected_wkc(group_config_raw: bytes, group: int) -> int:
        """获取组期望 WKC"""
        if group >= 8:
            return 0
        off = group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 2
        return int.from_bytes(group_config_raw[off:off + 2], byteorder='little', signed=False)

    @staticmethod
    def get_group_slave_count(group_config_raw: bytes, group: int) -> int:
        """获取组从站数量"""
        if group >= 8:
            return 0
        off = group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 4
        return int.from_bytes(group_config_raw[off:off + 2], byteorder='little', signed=False)

    @staticmethod
    def get_group_frame_repeat_eligible(group_config_raw: bytes, group: int) -> bool:
        """获取组帧重复资格 (ETG.1500 5.4.3)"""
        if group >= 8:
            return False
        return group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 6] != 0

    @staticmethod
    def set_group_frame_repeat_eligible(group_config_raw: bytearray, group: int, eligible: bool):
        """设置组帧重复资格 (ETG.1500 5.4.3)"""
        if group >= 8:
            return
        group_config_raw[group * EcGroupConfigHelper.GROUP_CONFIG_SIZE + 6] = 1 if eligible else 0
