# -*- coding: utf-8 -*-
"""
darra_ethercat.sugar — Python 特有语法糖

主 SDK ``darra_ethercat`` 与 C# / Java / C++ / Rust SDK 一一对齐, 用法稳定.
本子包在主 SDK 之上**叠加** Python 特有的 dunder / async / functional API,
不修改主 SDK 任何文件.

启用方式:

    import darra_ethercat
    import darra_ethercat.sugar    # 一行激活全部语法糖

或按需:

    from darra_ethercat.sugar import SlaveIdentityKey
    from darra_ethercat.sugar.async_streams import EmergencyEvent

激活后追加的能力 (主 SDK 已有的不重复):

| 能力 | 来源 |
|------|------|
| ``slave in master`` 包含查询 | iter_helpers |
| ``master.where / select / first / group_by`` LINQ 风格 | iter_helpers |
| ``Slave.__eq__ / __hash__`` (可作 set/dict 元素) | iter_helpers |
| ``async with master:`` / ``master.session()`` / ``master.opening()`` | context |
| ``async for ev in master.state_changes()`` | async_streams |
| ``async for ev in master.slave_state_changes()`` | async_streams |
| ``async for ev in master.emergencies()`` | async_streams |
| ``async for raw in slave.coe.diagnostic_stream()`` | async_streams |
| ``Slave.summary() / Master.summary()`` 多行调试摘要 | repr_helpers |
| ``SlaveIdentityKey`` frozen dataclass + 元组解包 | identity |
| ``classify_state / is_running / is_error`` match-friendly | pattern_match |
| ``MasterLike / SlaveLike / CoELike`` Protocol (静态类型) | protocols |

主 SDK **已实现**, 本包**不重复**:
- ``with master:`` (Master 已有 ``__enter__/__exit__``)
- ``for slave in master`` (Master 已有 ``__iter__``)
- ``master[idx]`` (Master 已有 ``__getitem__``)
- ``len(master)`` (Master 已有 ``__len__``)
- ``str(slave) / repr(slave)`` (Slave 已有 ``__str__/__repr__``)
- ``str(master) / repr(master)`` (Master 已有 ``__str__/__repr__``)
"""

# 安装所有 monkey-patch (idempotent: 重复 import 不会重叠)
from . import iter_helpers as _iter_helpers
from . import context as _context
from . import async_streams as _async_streams
from . import repr_helpers as _repr_helpers

_iter_helpers.install()
_context.install()
_async_streams.install()
_repr_helpers.install()

# 公开符号
from .identity import SlaveIdentityKey
from .async_streams import EmergencyEvent, StateChange, SlaveStateChange
from .pattern_match import classify_state, is_running, is_error
from .protocols import CoELike, SlaveLike, MasterLike

__all__ = [
    "SlaveIdentityKey",
    "EmergencyEvent",
    "StateChange",
    "SlaveStateChange",
    "classify_state",
    "is_running",
    "is_error",
    "CoELike",
    "SlaveLike",
    "MasterLike",
]
