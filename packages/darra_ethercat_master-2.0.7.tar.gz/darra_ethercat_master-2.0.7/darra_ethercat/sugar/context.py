# -*- coding: utf-8 -*-
"""
sugar.context — 上下文管理增强

主 SDK ``EtherCATMaster`` 已实现 ``__enter__/__exit__`` (会调 close = Stop+Dispose).
本模块叠加:

1. ``async with master:`` 异步上下文支持 (``__aenter__/__aexit__``)
   把 close 放到 default executor, 防止 asyncio 主循环被 native dispose 阻塞.

2. ``with master.session(state=EcState.OP):``
   一行式启动: 进入时 ``set_state_sequence(state) + start()``, 退出时 stop+close.

3. ``opening(network)`` 类方法: 显式 ``EtherCATMaster.opening(nic)`` 工厂返回 cm.

不修改主 SDK __enter__/__exit__ 逻辑.
"""

import asyncio
from contextlib import asynccontextmanager, contextmanager
from typing import Optional


@contextmanager
def _master_session(self, state=None, network: Optional[str] = None):
    """
    一行启动+清理:

        with master.session(state=EcState.OP):
            ...   # 此时已 OP, 退出自动 stop+close

    参数:
        state:    EcState (None 跳过 set_state_sequence)
        network:  NIC 字符串 (None 跳过 set_network)
    """
    if network is not None:
        self.set_network(network)
    if state is not None:
        self.set_state_sequence(state)
    self.start()
    try:
        yield self
    finally:
        try:
            self.stop()
        except Exception:
            pass
        try:
            self.close()
        except Exception:
            pass


async def _master_aenter(self):
    """async with master: ..."""
    return self


async def _master_aexit(self, exc_type, exc, tb):
    """async with 退出: 用 executor 跑 close, 防止阻塞事件循环."""
    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(None, self.close)
    except Exception:
        pass
    return False


@classmethod
def _master_opening(cls, network: str, *, dll_path: Optional[str] = None,
                    state=None):
    """
    工厂方法 + 上下文管理器:

        with EtherCATMaster.opening(nic, state=EcState.OP) as master:
            for slave in master:
                ...
    """
    @contextmanager
    def _cm():
        m = cls(dll_path=dll_path)
        try:
            m.set_network(network)
            if state is not None:
                m.set_state_sequence(state)
            m.start()
            yield m
        finally:
            try:
                m.stop()
            except Exception:
                pass
            try:
                m.close()
            except Exception:
                pass

    return _cm()


def install():
    from ..master.core import EtherCATMaster

    if not hasattr(EtherCATMaster, "session"):
        EtherCATMaster.session = _master_session
    if not hasattr(EtherCATMaster, "__aenter__"):
        EtherCATMaster.__aenter__ = _master_aenter
    if not hasattr(EtherCATMaster, "__aexit__"):
        EtherCATMaster.__aexit__ = _master_aexit
    if not hasattr(EtherCATMaster, "opening"):
        EtherCATMaster.opening = _master_opening


__all__ = ["install"]
