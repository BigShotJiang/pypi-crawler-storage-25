# -*- coding: utf-8 -*-
"""
sugar.pattern_match — Python 3.10+ match/case 辅助

主 SDK 的 ``EcState`` 是基于 ctypes/IntEnum 的整数枚举, 直接支持 match.
本模块提供:

1. ``classify_state(state)`` — 把 EcState int 翻译为人类可读分类标签
2. ``StatePattern`` 命名常量集 — 给 match/case 用更语义化的名字

用法 (Python 3.10+):

    from darra_ethercat import EcState
    from darra_ethercat.sugar.pattern_match import classify_state

    match slave.state:
        case EcState.OP:
            ...
        case EcState.SAFE_OP | EcState.PRE_OP:
            ...
        case _:
            ...

或:

    label = classify_state(slave.state)  # "operational" / "pre-operational" / ...
"""

# 不直接 import EcState (避免循环), 用整数比较即可

# AL Status 标准定义 (ETG.1000.6)
_INIT = 0x01
_PREOP = 0x02
_BOOT = 0x03
_SAFEOP = 0x04
_OP = 0x08
_ACK = 0x10  # error ack 位


def classify_state(state: int) -> str:
    """
    把 EcState/AL Status int 分类为字符串标签.

    >>> classify_state(0x08)
    'operational'
    >>> classify_state(0x12)  # PreOp + Error
    'pre-operational/error'
    """
    base = state & 0x0F
    has_err = (state & _ACK) != 0

    if base == _INIT:
        label = "init"
    elif base == _PREOP:
        label = "pre-operational"
    elif base == _BOOT:
        label = "boot"
    elif base == _SAFEOP:
        label = "safe-operational"
    elif base == _OP:
        label = "operational"
    else:
        label = f"unknown(0x{state:02X})"

    if has_err and base != _OP:
        return f"{label}/error"
    if has_err:
        return f"{label}/ack-pending"
    return label


def is_running(state: int) -> bool:
    """SafeOp 或 Op 视为运行中."""
    return (state & 0x0F) in (_SAFEOP, _OP)


def is_error(state: int) -> bool:
    """ACK 位置 1 表示错误."""
    return (state & _ACK) != 0


__all__ = ["classify_state", "is_running", "is_error"]
