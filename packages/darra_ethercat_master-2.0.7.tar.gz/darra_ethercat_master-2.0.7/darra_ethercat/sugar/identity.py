# -*- coding: utf-8 -*-
"""
sugar.identity — 不可变身份元组

主 SDK 中 Slave.identity 返回 dict (vendor_id / product_code / revision_no / serial_no),
dict 不可哈希、无元组解包、不可作字典键. 本模块在 dict 之上再叠加一个不可变 dataclass:

    SlaveIdentityKey(vendor_id, product_code, revision_no, serial_no)

特性:
- frozen=True       不可变, 可 hash, 可作 dict key / set 元素
- 元组解包          vendor, product, rev, serial = key
- 等值判断          key1 == key2 走字段比较
- repr 友好         "SlaveIdentityKey(vendor=0x..., product=0x..., rev=..., serial=...)"

主 SDK 任何返回 identity dict 的地方都可包装:

    from darra_ethercat.sugar import SlaveIdentityKey
    key = SlaveIdentityKey.from_slave(slave)

不修改主 SDK 行为, 只是叠加一层语法糖.
"""

from dataclasses import dataclass, astuple, asdict
from typing import Optional, Tuple


@dataclass(frozen=True, eq=True)
class SlaveIdentityKey:
    """从站身份不可变元组 (Vendor / Product / Revision / Serial).

    对齐 ETG.1000.6 §SII Identity, 字段顺序与 SlaveIdentity 一致.
    """

    vendor_id: int
    product_code: int
    revision_no: int
    serial_no: int

    @classmethod
    def from_slave(cls, slave) -> Optional["SlaveIdentityKey"]:
        """从 Slave 实例提取身份 (None 表示读取失败)."""
        ident = slave.identity
        if not ident:
            return None
        return cls(
            vendor_id=int(ident.get("vendor_id", 0)),
            product_code=int(ident.get("product_code", 0)),
            revision_no=int(ident.get("revision_no", 0)),
            serial_no=int(ident.get("serial_no", 0)),
        )

    @classmethod
    def from_dict(cls, d: dict) -> "SlaveIdentityKey":
        """从 dict 构造 (兼容主 SDK identity 返回)."""
        return cls(
            vendor_id=int(d.get("vendor_id", 0)),
            product_code=int(d.get("product_code", 0)),
            revision_no=int(d.get("revision_no", 0)),
            serial_no=int(d.get("serial_no", 0)),
        )

    def to_tuple(self) -> Tuple[int, int, int, int]:
        """返回原生元组 (vendor, product, revision, serial)."""
        return astuple(self)

    def to_dict(self) -> dict:
        """返回与主 SDK identity 一致的 dict."""
        return asdict(self)

    def matches(self,
                other: "SlaveIdentityKey",
                check_revision: bool = True,
                check_serial: bool = False) -> bool:
        """与 SlaveIdentity 验证逻辑一致 (revision: actual >= configured 视为兼容)."""
        if self.vendor_id != other.vendor_id:
            return False
        if self.product_code != other.product_code:
            return False
        if check_revision and self.revision_no < other.revision_no:
            return False
        if check_serial and self.serial_no != other.serial_no:
            return False
        return True

    def __iter__(self):
        # 支持 vendor, product, rev, serial = key
        yield self.vendor_id
        yield self.product_code
        yield self.revision_no
        yield self.serial_no

    def __repr__(self) -> str:
        return (
            f"SlaveIdentityKey("
            f"vendor=0x{self.vendor_id:08X}, "
            f"product=0x{self.product_code:08X}, "
            f"rev=0x{self.revision_no:08X}, "
            f"serial=0x{self.serial_no:08X})"
        )


__all__ = ["SlaveIdentityKey"]
