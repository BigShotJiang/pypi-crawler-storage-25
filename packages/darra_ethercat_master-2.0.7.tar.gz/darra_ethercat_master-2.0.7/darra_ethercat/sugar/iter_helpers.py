# -*- coding: utf-8 -*-
"""
sugar.iter_helpers — 迭代/过滤语法糖

主 SDK 已经实现:
    for slave in master         (EtherCATMaster.__iter__)
    master[idx]                 (EtherCATMaster.__getitem__)
    len(master)                 (EtherCATMaster.__len__)

本模块叠加补丁:
    slave in master             (__contains__, 支持 Slave / int / SlaveIdentityKey)
    master.where(predicate)     LINQ 风格过滤, 返回 list[Slave]
    master.select(projector)    LINQ 风格投影, 返回 list[Any]
    master.first(predicate)     首个匹配 / None
    master.first_or_raise(p)    首个匹配 / KeyError
    master.group_by(keyfn)      按 key 分组, 返回 dict
    master.count_where(p)       计数

通过 monkey-patch 给 EtherCATMaster 与 Slave 追加方法, 不改源文件.
导入 darra_ethercat.sugar 时自动激活.
"""

from typing import Callable, List, Any, Optional, Dict, Iterable, TypeVar

T = TypeVar("T")


def _master_contains(self, item) -> bool:
    """支持 ``slave in master`` / ``index in master`` / ``identity_key in master``.

    item 类型分发:
      - int          → 是否存在该 slave_index
      - Slave        → identity 比较 (vendor + product 必须相等)
      - SlaveIdentityKey → 整网搜索匹配的从站
    """
    # 延迟 import 避免循环依赖
    from ..slave.core import Slave
    from .identity import SlaveIdentityKey

    if isinstance(item, int):
        return 1 <= item <= len(self)

    if isinstance(item, Slave):
        # 同一 master + 同一 si
        if item._mi == self._mi and 1 <= item._si <= len(self):
            return True
        # 跨 master 比较: 走 identity
        try:
            ident_a = SlaveIdentityKey.from_slave(item)
        except Exception:
            return False
        if ident_a is None:
            return False
        for s in self:
            ident_b = SlaveIdentityKey.from_slave(s)
            if ident_b and ident_a == ident_b:
                return True
        return False

    if isinstance(item, SlaveIdentityKey):
        for s in self:
            ident = SlaveIdentityKey.from_slave(s)
            if ident and item == ident:
                return True
        return False

    return False


def _master_where(self, predicate: Callable[[Any], bool]) -> List:
    """返回所有满足 predicate 的从站 (LINQ Where)."""
    return [s for s in self if predicate(s)]


def _master_select(self, projector: Callable[[Any], T]) -> List[T]:
    """对每个从站执行 projector, 返回投影列表 (LINQ Select)."""
    return [projector(s) for s in self]


def _master_first(self, predicate: Optional[Callable[[Any], bool]] = None):
    """返回首个匹配的从站. 无 predicate 时返回 slaves[0], 不存在返回 None."""
    if predicate is None:
        for s in self:
            return s
        return None
    for s in self:
        if predicate(s):
            return s
    return None


def _master_first_or_raise(self,
                           predicate: Optional[Callable[[Any], bool]] = None,
                           message: str = "no matching slave"):
    """同 first(), 但找不到抛 KeyError."""
    s = _master_first(self, predicate)
    if s is None:
        raise KeyError(message)
    return s


def _master_group_by(self, key_fn: Callable[[Any], Any]) -> Dict[Any, List]:
    """按 key_fn(slave) 分组, 返回 dict[key, list[Slave]]."""
    out: Dict[Any, List] = {}
    for s in self:
        k = key_fn(s)
        out.setdefault(k, []).append(s)
    return out


def _master_count_where(self, predicate: Callable[[Any], bool]) -> int:
    """计数满足条件的从站."""
    return sum(1 for s in self if predicate(s))


def _slave_eq(self, other) -> bool:
    """Slave 相等性: 同一 master_index + slave_index."""
    if not hasattr(other, "_mi") or not hasattr(other, "_si"):
        return NotImplemented
    return self._mi == other._mi and self._si == other._si


def _slave_hash(self) -> int:
    """Slave 哈希 (用于 set/dict). 基于 (master_index, slave_index)."""
    return hash((getattr(self, "_mi", 0), getattr(self, "_si", 0)))


def install():
    """把上述方法绑定到 EtherCATMaster 和 Slave 上 (idempotent)."""
    from ..master.core import EtherCATMaster
    from ..slave.core import Slave

    # 主站补丁: 不覆盖已有 __iter__/__len__/__getitem__
    if not hasattr(EtherCATMaster, "__contains__") or \
            getattr(EtherCATMaster.__contains__, "_sugar", False) is False:
        _master_contains._sugar = True
        EtherCATMaster.__contains__ = _master_contains

    for name, fn in (
        ("where", _master_where),
        ("select", _master_select),
        ("first", _master_first),
        ("first_or_raise", _master_first_or_raise),
        ("group_by", _master_group_by),
        ("count_where", _master_count_where),
    ):
        if not hasattr(EtherCATMaster, name):
            fn._sugar = True
            setattr(EtherCATMaster, name, fn)

    # 从站补丁: 加 __eq__/__hash__ (主 SDK 未实现)
    if "__eq__" not in Slave.__dict__:
        _slave_eq._sugar = True
        Slave.__eq__ = _slave_eq
    if "__hash__" not in Slave.__dict__:
        _slave_hash._sugar = True
        Slave.__hash__ = _slave_hash


__all__ = ["install"]
