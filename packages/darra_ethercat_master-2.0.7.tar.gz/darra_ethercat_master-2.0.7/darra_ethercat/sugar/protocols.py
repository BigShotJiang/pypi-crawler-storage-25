# -*- coding: utf-8 -*-
"""
sugar.protocols — 静态类型 Protocol (PEP 544)

(模块名故意避开 ``sugar.types`` — Python stdlib 已有 ``types`` 模块,
本地同名会在某些工作目录下导致 circular import.)

为静态类型检查 (mypy/pyright) 提供结构化协议.
运行时不强制, 只供 IDE/CI 类型推导.

用法:
    from darra_ethercat.sugar.protocols import SlaveLike, MasterLike

    def configure_drive(slave: SlaveLike) -> None:
        slave.coe.sdo_write_value(0x6060, 0, 8, dtype='u8')

注意:
- 不要继承 Protocol — 用结构化匹配, 任何具备同名方法的对象都自动适配
- 主 SDK 的 Slave / EtherCATMaster 自动满足这些 Protocol
- 无 Slave/Master class 实例的测试 mock 也可满足 (鸭子类型 + 静态可检)
"""

from typing import Any, Optional, Protocol, runtime_checkable


@runtime_checkable
class CoELike(Protocol):
    """CoE (CANopen over EtherCAT) 协议子集."""

    def sdo_read_value(self, index: int, subindex: int, dtype: str = ...) -> Any: ...
    def sdo_write_value(self, index: int, subindex: int, value: Any, dtype: str = ...) -> bool: ...


@runtime_checkable
class SlaveLike(Protocol):
    """Slave 协议子集 (静态类型用)."""

    @property
    def state(self) -> int: ...
    @property
    def name(self) -> str: ...
    @property
    def identity(self) -> Optional[dict]: ...
    @property
    def coe(self) -> CoELike: ...


@runtime_checkable
class MasterLike(Protocol):
    """EtherCATMaster 协议子集 (静态类型用)."""

    def __iter__(self): ...
    def __len__(self) -> int: ...
    def __getitem__(self, idx: int) -> SlaveLike: ...
    def start(self) -> Any: ...
    def stop(self) -> Any: ...
    def close(self) -> Any: ...


__all__ = ["CoELike", "SlaveLike", "MasterLike"]
