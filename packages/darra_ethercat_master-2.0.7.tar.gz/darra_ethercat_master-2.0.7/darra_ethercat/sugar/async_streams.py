# -*- coding: utf-8 -*-
"""
sugar.async_streams — 异步生成器 (asyncio 友好)

把主 SDK 的"回调注册"模式翻成"async for"流式 API:

    # 状态变化流 (master 级)
    async for old, new in master.state_changes():
        print(old, new)

    # 从站状态变化流
    async for si, old, new in master.slave_state_changes():
        ...

    # 紧急消息流
    async for ev in master.emergencies():
        print(ev.slave_index, ev.error_code)

    # CoE 0x10F3 诊断流 (per slave, polled)
    async for raw_msg in slave.coe.diagnostic_stream(poll_ms=50):
        ...

实现方式: 内部用 asyncio.Queue 做 callback → coroutine 桥接,
不修改主 SDK 任何文件.

注意:
- 这些 stream 是后台轮询/事件桥接, 在 ``async with stream:`` 退出时停止
- 在循环 ``break`` 后, 已注册的回调会在下一个 GC 周期清理 (best-effort)
- 必须在 asyncio 事件循环里使用
"""

import asyncio
import threading
import time
from dataclasses import dataclass
from typing import AsyncIterator, Optional, Tuple


@dataclass(frozen=True)
class EmergencyEvent:
    """主 SDK 紧急回调参数的不可变快照."""
    master_index: int
    slave_index: int
    error_code: int
    error_register: int
    byte1: int
    word1: int
    word2: int
    timestamp: float  # time.monotonic()


@dataclass(frozen=True)
class StateChange:
    """主站状态变化."""
    old_state: int
    new_state: int
    timestamp: float


@dataclass(frozen=True)
class SlaveStateChange:
    """从站状态变化."""
    master_index: int
    slave_index: int
    old_state: int
    new_state: int
    timestamp: float


# ===================== 主站级 streams =====================

async def _master_state_change_stream(self,
                                      maxsize: int = 256
                                      ) -> AsyncIterator[StateChange]:
    """
    主站状态变化 async generator.

    用法:
        async for change in master.state_changes():
            if change.new_state == EcState.OP:
                break
    """
    loop = asyncio.get_running_loop()
    q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)

    def _cb(old, new):
        ev = StateChange(old, new, time.monotonic())
        try:
            loop.call_soon_threadsafe(q.put_nowait, ev)
        except Exception:
            pass

    # 备份/恢复原回调以避免冲突
    prev = self.on_state_changed
    self.on_state_changed = _cb
    try:
        while True:
            ev = await q.get()
            yield ev
    finally:
        # 恢复
        try:
            self.on_state_changed = prev
        except Exception:
            pass


async def _master_slave_state_change_stream(self,
                                            maxsize: int = 256
                                            ) -> AsyncIterator[SlaveStateChange]:
    """
    全网从站状态变化 async generator.

    用法:
        async for change in master.slave_state_changes():
            print(f"slave {change.slave_index}: {change.old_state} -> {change.new_state}")
    """
    loop = asyncio.get_running_loop()
    q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)

    def _cb(mi, si, old, new):
        if si == 0:
            return  # master 级状态走另一个 stream
        try:
            loop.call_soon_threadsafe(
                q.put_nowait,
                SlaveStateChange(mi, si, old, new, time.monotonic())
            )
        except Exception:
            pass

    self.on_state_change(_cb, sync=True)
    try:
        while True:
            yield await q.get()
    finally:
        # SDK 没有提供 unregister, 只能让 callback 安静退出
        # _cb 闭包持有的 q 已经没 consumer, 后续 put_nowait 会抛 QueueFull 被忽略
        pass


async def _master_emergency_stream(self,
                                   maxsize: int = 512
                                   ) -> AsyncIterator[EmergencyEvent]:
    """
    紧急消息流.

    用法:
        async for ev in master.emergencies():
            log.error(f"slave {ev.slave_index} EMCY 0x{ev.error_code:04X}")
    """
    loop = asyncio.get_running_loop()
    q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)

    def _cb(mi, si, ec, er, b1, w1, w2):
        try:
            loop.call_soon_threadsafe(
                q.put_nowait,
                EmergencyEvent(mi, si, ec, er, b1, w1, w2, time.monotonic())
            )
        except Exception:
            pass

    self.on_emergency(_cb)
    try:
        while True:
            yield await q.get()
    finally:
        pass


# ===================== CoE 诊断流 (per slave, 轮询) =====================

async def _coe_diagnostic_stream(self,
                                 poll_ms: int = 50,
                                 buf_size: int = 1024
                                 ) -> AsyncIterator[bytes]:
    """
    ETG.1020 0x10F3 诊断历史 async stream.

    内部循环: poll_has_new_diagnostic → read_diagnostic_meta → read_diagnostic_message
    → acknowledge. 每条消息 yield 一次原始 Octet 字节.

    用法:
        async for raw in slave.coe.diagnostic_stream(poll_ms=20):
            text = raw[8:].decode('utf-8', errors='replace')
            print(text)

    参数:
        poll_ms: 轮询间隔 (毫秒). 太小压 CoE 邮箱, 建议 20-200.
        buf_size: 每条消息接收缓冲区.

    退出: ``break`` 即可, 不会泄露资源 (无外部回调).
    """
    last_ack: Optional[int] = None
    while True:
        await asyncio.sleep(poll_ms / 1000.0)
        try:
            has_new = self.poll_has_new_diagnostic()
        except Exception:
            continue
        if has_new != 1:
            continue

        meta = self.read_diagnostic_meta()
        if meta is None:
            continue

        # 从 newest_acknowledged + 1 读到 newest_message (按 ring 计算)
        if last_ack is None:
            last_ack = meta.newest_acknowledged
        newest = meta.newest_message
        max_msgs = max(meta.max_messages, 1)

        idx = last_ack
        # ring 推进; subindex >= 6 (ETG.1020)
        steps = 0
        while idx != newest and steps < max_msgs:
            steps += 1
            idx = idx + 1 if idx + 1 <= 5 + max_msgs else 6
            data = self.read_diagnostic_message(idx, buf_size=buf_size)
            if data is None:
                break
            self.acknowledge_diagnostic(idx)
            last_ack = idx
            yield data


# ===================== 安装 =====================

def install():
    """把 stream 方法挂到 EtherCATMaster / CoE."""
    from ..master.core import EtherCATMaster
    from ..slave.core import CoE

    if not hasattr(EtherCATMaster, "state_changes"):
        EtherCATMaster.state_changes = _master_state_change_stream
    if not hasattr(EtherCATMaster, "slave_state_changes"):
        EtherCATMaster.slave_state_changes = _master_slave_state_change_stream
    if not hasattr(EtherCATMaster, "emergencies"):
        EtherCATMaster.emergencies = _master_emergency_stream

    if not hasattr(CoE, "diagnostic_stream"):
        CoE.diagnostic_stream = _coe_diagnostic_stream


__all__ = [
    "EmergencyEvent",
    "StateChange",
    "SlaveStateChange",
    "install",
]
