# -*- coding: utf-8 -*-
"""
sugar.repr_helpers — repr 增强 (调试友好)

主 SDK 已实现 ``Slave.__str__/__repr__`` 与 ``EtherCATMaster.__str__/__repr__``,
本模块只增加 ``Slave.summary()`` 和 ``EtherCATMaster.summary()`` 方法 —
返回多行人类可读字符串, 适合日志/REPL 调试.

设计原则: ``__repr__`` 保持单行 (主 SDK 行为), ``summary()`` 是显式调用的多行版.
"""

from typing import Optional


def _slave_summary(self) -> str:
    """单从站多行摘要 (REPL 友好)."""
    lines = [f"Slave[{self._si}] @ master {self._mi}"]
    try:
        lines.append(f"  name        : {self.name}")
    except Exception:
        pass
    try:
        ident = self.identity or {}
        if ident:
            lines.append(
                f"  identity    : Vendor=0x{ident.get('vendor_id', 0):08X} "
                f"Product=0x{ident.get('product_code', 0):08X} "
                f"Rev=0x{ident.get('revision_no', 0):08X}"
            )
    except Exception:
        pass
    try:
        lines.append(f"  state       : {self.state}")
    except Exception:
        pass
    try:
        lines.append(f"  has_dc      : {self.has_dc}")
    except Exception:
        pass
    try:
        lines.append(f"  group       : {self.group}")
    except Exception:
        pass
    return "\n".join(lines)


def _master_summary(self) -> str:
    """主站多行摘要."""
    lines = [str(self)]
    try:
        lines.append(f"  state       : {self.state}")
    except Exception:
        pass
    try:
        lines.append(f"  loop_cycle  : {self.loop_cycle} ns")
    except Exception:
        pass
    try:
        lines.append(f"  slaves      : {self._slave_count}")
    except Exception:
        pass
    return "\n".join(lines)


def install():
    from ..master.core import EtherCATMaster
    from ..slave.core import Slave

    if not hasattr(Slave, "summary"):
        Slave.summary = _slave_summary
    if not hasattr(EtherCATMaster, "summary"):
        EtherCATMaster.summary = _master_summary


__all__ = ["install"]
