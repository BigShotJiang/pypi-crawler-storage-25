import re
from typing import Any

from .constants import LOOKUP_OPERATORS

# Pattern for valid field names: alphanumeric, underscores, dots (for nested fields)
# Must start with a letter or underscore
VALID_FIELD_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*)*$")

# Pattern for valid alias names: alphanumeric and underscores only
# Must start with a letter or underscore (like Python identifiers)
VALID_ALIAS_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

# Pattern for valid graph traversal paths: arrow-separated segments
# e.g. ->follows->User, <-follows<-User, ->follows->User->likes->Post
VALID_GRAPH_PATH_PATTERN = re.compile(r"^(<-|->)[a-zA-Z_][a-zA-Z0-9_]*((<-|->)[a-zA-Z_][a-zA-Z0-9_]*)*$")

# Pattern for valid record thing strings: table:id where both parts are safe
# ID part allows alphanumeric, underscores, and hyphens
VALID_THING_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*:[a-zA-Z0-9_`-]+$")

# Pattern for valid SurrealQL variable references: $variable_name
VALID_VARIABLE_REF_PATTERN = re.compile(r"^\$[a-zA-Z_][a-zA-Z0-9_]*$")


def remove_quotes_for_variables(query: str) -> str:
    # Regex to remove single quotes around variables ($)
    return re.sub(r"'(\$[a-zA-Z_]\w*)'", r"\1", query)


def validate_field_name(field: str, context: str = "field") -> None:
    """
    Validate a field name to prevent SQL injection.

    Args:
        field: The field name to validate.
        context: Description of where the field is used (for error messages).

    Raises:
        ValueError: If the field name contains invalid characters.
    """
    if not field or not field.strip():
        raise ValueError(f"{context} name cannot be empty")
    if not VALID_FIELD_PATTERN.match(field):
        raise ValueError(
            f"Invalid {context} name '{field}': must contain only alphanumeric characters, "
            "underscores, and dots (for nested fields), and start with a letter or underscore"
        )


def validate_alias_name(alias: str) -> None:
    """
    Validate an alias name to prevent SQL injection.

    Args:
        alias: The alias name to validate.

    Raises:
        ValueError: If the alias name contains invalid characters.
    """
    if not alias or not alias.strip():
        raise ValueError("alias name cannot be empty")
    if not VALID_ALIAS_PATTERN.match(alias):
        raise ValueError(
            f"Invalid alias name '{alias}': must contain only alphanumeric characters "
            "and underscores, and start with a letter or underscore"
        )


def validate_edge_name(edge: str) -> None:
    """
    Validate an edge (relation table) name to prevent injection.

    Args:
        edge: The edge/relation name to validate.

    Raises:
        ValueError: If the edge name contains invalid characters.
    """
    if not edge or not edge.strip():
        raise ValueError("edge name cannot be empty")
    if not VALID_ALIAS_PATTERN.match(edge):
        raise ValueError(
            f"Invalid edge name '{edge}': must contain only alphanumeric characters "
            "and underscores, and start with a letter or underscore"
        )


def validate_graph_path(path: str) -> None:
    """
    Validate a graph traversal path to prevent injection.

    Accepts paths like ``->follows->User``, ``<-follows<-User``,
    or mixed ``->follows->User->likes->Post``.

    Args:
        path: The graph traversal path to validate.

    Raises:
        ValueError: If the path contains invalid characters or structure.
    """
    if not path or not path.strip():
        raise ValueError("graph path cannot be empty")
    if not VALID_GRAPH_PATH_PATTERN.match(path):
        raise ValueError(
            f"Invalid graph path '{path}': must be arrow-separated segments starting with -> or <- (e.g. '->follows->User')"
        )


def validate_thing(thing: str) -> None:
    """
    Validate a ``table:id`` record identifier to prevent injection.

    Args:
        thing: The record identifier in ``table:id`` format.

    Raises:
        ValueError: If the thing string is not a valid ``table:id`` format.
    """
    if not thing or not thing.strip():
        raise ValueError("record identifier cannot be empty")
    if not VALID_THING_PATTERN.match(thing):
        raise ValueError(
            f"Invalid record identifier '{thing}': must be in 'table:id' format "
            "with only alphanumeric characters, underscores, and hyphens"
        )


def parse_lookup(key: str) -> tuple[str, str]:
    """
    Parse a filter key into field name and lookup type.

    Args:
        key: The filter key in the format ``field__lookup`` or just ``field``.

    Returns:
        A tuple of (field_name, lookup_type). Defaults to ``"exact"`` if no lookup is specified.
    """
    if "__" in key:
        field_name, lookup_name = key.split("__", 1)
    else:
        field_name, lookup_name = key, "exact"
    return field_name, lookup_name


def build_filter_condition(field: str, lookup: str, value: Any, counter: int) -> tuple[str, dict[str, Any], int]:
    """
    Build a single parameterized filter condition.

    Args:
        field: The field name.
        lookup: The lookup type (e.g. ``"exact"``, ``"gt"``, ``"in"``).
        value: The filter value.
        counter: The current variable counter for unique naming.

    Returns:
        A tuple of (sql_fragment, variables_dict, next_counter).

    Raises:
        ValueError: If the lookup type is not supported or the field name is invalid.
    """
    validate_field_name(field, "filter field")
    op = LOOKUP_OPERATORS.get(lookup)
    if op is None:
        raise ValueError(f"Unsupported lookup type: '{lookup}'")

    var_name = f"_f{counter}"

    if lookup == "isnull":
        if not isinstance(value, bool):
            raise ValueError(f"isnull lookup requires a boolean value, got {type(value).__name__}")
        if value:
            return f"{field} IS NULL", {}, counter
        else:
            return f"{field} IS NOT NULL", {}, counter
    elif lookup in ("in", "not_in", "containsall", "containsany"):
        if isinstance(value, (str, dict)) or not hasattr(value, "__iter__"):
            raise ValueError(f"'{lookup}' lookup requires an iterable (list, tuple, or set), got {type(value).__name__}")
        return f"{field} {op} ${var_name}", {var_name: list(value)}, counter + 1
    elif isinstance(value, str) and value.startswith("$"):
        # Backward compat: string values starting with $ are variable references
        if not VALID_VARIABLE_REF_PATTERN.match(value):
            raise ValueError(f"Invalid variable reference '{value}': must match $variable_name pattern")
        return f"{field} {op} {value}", {}, counter
    else:
        return f"{field} {op} ${var_name}", {var_name: value}, counter + 1
