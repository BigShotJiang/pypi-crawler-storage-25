# blinear/models.py

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input,
    Dense,
    Conv1D,
    GlobalAveragePooling1D,
    Flatten,
    Reshape,
    Activation
)

from .bilinear import HirotaBilinear
from .convbilinear import ConvHirotaBilinear
from .ogd import OGDlayer


# =========================================================
# COMPILE MODEL
# =========================================================
def compile_binary_model(model):
    model.compile(
        optimizer="adam",
        loss="binary_crossentropy",
        metrics=["accuracy"]
    )
    return model


def compile_multiclass_model(model):
    model.compile(
        optimizer="adam",
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


# =========================================================
# MODEL 1
# CNN + Hirota Bilinear
# =========================================================
def build_hirota_model(segment_len):
    inp = Input(shape=(segment_len, 1))

    x = Conv1D(
        64,
        kernel_size=3,
        padding="same",
        activation="relu"
    )(inp)

    x = GlobalAveragePooling1D()(x)

    f = Dense(
        256,
        activation="relu"
    )(x)

    g = Dense(
        256,
        activation="relu"
    )(x)

    h = HirotaBilinear(
        units=128,
        activation="relu"
    )([f, g])

    x = Dense(
        64,
        activation="relu"
    )(h)

    out = Dense(
        1,
        activation="sigmoid"
    )(x)

    model = Model(inp, out)
    return compile_binary_model(model)


# =========================================================
# MODEL 2
# ConvHirotaBilinear
# =========================================================
def build_conv_hirota_model(segment_len):
    inp = Input(shape=(segment_len, 1))

    x = ConvHirotaBilinear(
        bilinear_units=128,
        dense_units=512,
        final_units=64,
        activation="relu"
    )(inp)

    out = Dense(
        1,
        activation="sigmoid"
    )(x)

    model = Model(inp, out)
    return compile_binary_model(model)


# =========================================================
# MODEL 3
# Double Bilinear
# CNN → Hirota → Conv → Dense
# =========================================================
def build_double_bilinear(segment_len):
    inp = Input(shape=(segment_len, 1))

    x = Conv1D(
        64,
        kernel_size=3,
        padding="same",
        activation="relu"
    )(inp)

    x = Flatten()(x)

    f = Dense(
        256,
        activation="relu"
    )(x)

    g = Dense(
        256,
        activation="relu"
    )(x)

    h1 = HirotaBilinear(
        units=128,
        activation="relu"
    )([f, g])

    h2 = Reshape((128, 1))(h1)

    h2 = Conv1D(
        64,
        kernel_size=3,
        padding="same",
        activation="relu"
    )(h2)

    h2 = Conv1D(
        32,
        kernel_size=3,
        padding="same",
        activation="relu"
    )(h2)

    h2 = GlobalAveragePooling1D()(h2)

    x = Dense(
        64,
        activation="relu"
    )(h2)

    out = Dense(
        1,
        activation="sigmoid"
    )(x)

    model = Model(inp, out)
    return compile_binary_model(model)


# =========================================================
# MODEL 4
# ConvHirotaBilinear + OGD
# CNN → Hirota → Conv → OGD
# =========================================================
def build_conv_hirota_ogd(
    segment_len,
    num_classes
):
    inp = Input(shape=(segment_len, 1))

    logits = OGDlayer(
        num_classes=num_classes,
        bilinear_units=128,
        dense_units=512,
        final_units=256,
        dropout_rate=0.5,
        activation="relu"
    )(inp)

    out = Activation("softmax")(logits)

    model = Model(inp, out)
    return compile_multiclass_model(model)