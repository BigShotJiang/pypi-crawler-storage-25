# blinear/ogd.py

import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras.layers import (
    Dense,
    Dropout
)

from .convbilinear import ConvHirotaBilinear


# =========================================================
# OGD A1 LAYER
# =========================================================
class OGDA1Layer(layers.Layer):
    def __init__(self, num_classes, feat_dim, **kwargs):
        super().__init__(**kwargs)

        self.num_classes = num_classes
        self.feat_dim = feat_dim

    def build(self, input_shape):
        # bias term
        self.v = self.add_weight(
            name="bias",
            shape=(self.num_classes,),
            initializer="zeros",
            trainable=True
        )

        # projection matrix
        self.P = self.add_weight(
            name="projection",
            shape=(self.num_classes, self.feat_dim),
            initializer=tf.keras.initializers.RandomNormal(
                stddev=0.01
            ),
            trainable=True
        )

    def call(self, inputs):
        return tf.matmul(
            inputs,
            self.P,
            transpose_b=True
        ) + self.v


# =========================================================
# ConvHirota + OGD CLASS
# CNN → Hirota → Conv → OGD
# =========================================================
class OGDlayer(layers.Layer):
    def __init__(
        self,
        num_classes,
        bilinear_units=128,
        dense_units=512,
        final_units=256,
        dropout_rate=0.5,
        activation="relu"
    ):
        super().__init__()

        # =================================================
        # Conv Hirota Bilinear backbone
        # =================================================
        self.backbone = ConvHirotaBilinear(
            bilinear_units=bilinear_units,
            dense_units=dense_units,
            final_units=final_units,
            activation=activation
        )

        # =================================================
        # Dense refinement
        # =================================================
        self.fc = Dense(
            final_units,
            activation="relu"
        )

        self.dropout = Dropout(
            dropout_rate
        )

        # =================================================
        # OGD classifier
        # =================================================
        self.ogd = OGDA1Layer(
            num_classes=num_classes,
            feat_dim=final_units
        )

    def call(self, inputs):
        # Backbone feature extraction
        x = self.backbone(inputs)

        # Dense refinement
        x = self.fc(x)
        x = self.dropout(x)

        # OGD logits
        logits = self.ogd(x)

        return logits