# convbilinear.py

import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras.layers import (
    Conv1D,
    MaxPooling1D,
    Flatten,
    Dense,
    GlobalAveragePooling1D,
    Reshape
)


# =========================================================
# HIROTA BILINEAR LAYER
# =========================================================
class HirotaBilinear(layers.Layer):
    def __init__(self, units, r=32, activation=None):
        super().__init__()
        self.units = units
        self.r = r
        self.activation = tf.keras.activations.get(activation)

    def build(self, input_shape):
        d_f = int(input_shape[0][-1])
        d_g = int(input_shape[1][-1])

        self.W1 = self.add_weight(
            shape=(d_f, self.units),
            initializer="glorot_uniform",
            trainable=True,
            name="W1"
        )

        self.W2 = self.add_weight(
            shape=(d_g, self.units),
            initializer="glorot_uniform",
            trainable=True,
            name="W2"
        )

        self.W3 = self.add_weight(
            shape=(d_f, self.r),
            initializer="glorot_uniform",
            trainable=True,
            name="W3"
        )

        self.W4 = self.add_weight(
            shape=(d_g, self.r),
            initializer="glorot_uniform",
            trainable=True,
            name="W4"
        )

        self.V = self.add_weight(
            shape=(self.r, self.units),
            initializer="glorot_uniform",
            trainable=True,
            name="V"
        )

        self.b = self.add_weight(
            shape=(self.units,),
            initializer="zeros",
            trainable=True,
            name="b"
        )

    def call(self, inputs):
        f, g = inputs

        f = tf.cast(f, tf.float32)
        g = tf.cast(g, tf.float32)

        h = tf.matmul(f, self.W1) * tf.matmul(g, self.W2)

        b = tf.matmul(
            tf.matmul(f, self.W3) *
            tf.matmul(g, self.W4),
            self.V
        )

        out = h + b + self.b

        if self.activation:
            out = self.activation(out)

        return out


# =========================================================
# CONVOLUTIONAL HIROTA BILINEAR CLASS
# (CNN + Hirota + ConvBilinear in ONE class)
# =========================================================
class ConvHirotaBilinear(layers.Layer):
    def __init__(
        self,
        bilinear_units=128,
        dense_units=512,
        final_units=64,
        activation="relu"
    ):
        super().__init__()

        # CNN Block
        self.conv1 = Conv1D(
            32, 5,
            padding="same",
            activation="relu"
        )
        self.pool1 = MaxPooling1D(2)

        self.conv2 = Conv1D(
            64, 3,
            padding="same",
            activation="relu"
        )
        self.pool2 = MaxPooling1D(2)

        self.conv3 = Conv1D(
            128, 3,
            padding="same",
            activation="relu"
        )
        self.pool3 = MaxPooling1D(2)

        # Flatten + branch g
        self.flatten = Flatten()
        self.branch_g = Dense(
            dense_units,
            activation="relu"
        )

        # Hirota Bilinear
        self.hirota = HirotaBilinear(
            units=bilinear_units,
            activation=activation
        )

        # Conv after bilinear
        self.reshape = Reshape((bilinear_units, 1))

        self.post_conv1 = Conv1D(
            64,
            3,
            padding="same",
            activation="relu"
        )

        self.post_conv2 = Conv1D(
            32,
            3,
            padding="same",
            activation="relu"
        )

        self.gap = GlobalAveragePooling1D()

        # Final projection
        self.final_dense = Dense(
            final_units,
            activation="relu"
        )

    def call(self, inputs):
        # =================================================
        # CNN FEATURE EXTRACTION
        # =================================================
        x = self.conv1(inputs)
        x = self.pool1(x)

        x = self.conv2(x)
        x = self.pool2(x)

        x = self.conv3(x)
        x = self.pool3(x)

        # =================================================
        # FLATTEN
        # =================================================
        f = self.flatten(x)

        # =================================================
        # BRANCH g
        # =================================================
        g = self.branch_g(f)

        # =================================================
        # HIROTA BILINEAR
        # =================================================
        h = self.hirota([f, g])

        # =================================================
        # CONV AFTER BILINEAR
        # =================================================
        h = self.reshape(h)

        h = self.post_conv1(h)
        h = self.post_conv2(h)

        h = self.gap(h)

        # =================================================
        # FINAL OUTPUT FEATURE
        # =================================================
        out = self.final_dense(h)

        return out