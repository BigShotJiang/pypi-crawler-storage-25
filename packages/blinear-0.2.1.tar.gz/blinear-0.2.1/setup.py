# setup.py

from setuptools import setup, find_packages

setup(
    name="blinear",
    version="0.2.1",
    author="Nguyen Minh Tuan",
    author_email="minhtuan@ptit.edu.vn",
    description="Bilinear Neural Network Library with Hirota Bilinear and ConvBilinear Layers",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "tensorflow",
        "numpy"
    ],
    python_requires=">=3.8",
    license="MIT",
)