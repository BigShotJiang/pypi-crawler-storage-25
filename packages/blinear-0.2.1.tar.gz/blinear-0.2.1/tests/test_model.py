import torch
from blinear import BilinearLayer

def test_bilinear_forward():
    model = BilinearLayer(10, 10, 5)
    x1 = torch.randn(4, 10)
    x2 = torch.randn(4, 10)

    output = model(x1, x2)

    assert output.shape == (4, 5)