# README.md

# blinear

Bilinear Neural Network Library for Deep Learning.

This package provides:

- Hirota Bilinear Layer
- Convolutional Hirota Bilinear Layer
- CNN + Bilinear Models
- Double Bilinear Models
- Deep Learning for Biomedical Signal Classification

---

## Installation

```bash
pip install blinear