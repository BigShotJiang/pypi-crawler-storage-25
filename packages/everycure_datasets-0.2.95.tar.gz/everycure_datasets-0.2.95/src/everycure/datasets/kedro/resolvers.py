import subprocess
import logging

def name():
    try:
        name = subprocess.check_output(
            ["git", "config", "--get", "user.name"], text=True
        ).strip()
        return name
    except subprocess.CalledProcessError:
        return None


def git_sha():
    # grabs current git commit
    sha = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    # also print a warning to the user that uncommitted work won't be properly tracked
    is_uncommitted = subprocess.check_output(
        ["git", "status", "--porcelain"], text=True
    ).strip()
    if is_uncommitted:
        logging.warning(
            "Uncommitted work will not be properly tracked. Please commit your changes before running the pipeline."
        )
    return sha