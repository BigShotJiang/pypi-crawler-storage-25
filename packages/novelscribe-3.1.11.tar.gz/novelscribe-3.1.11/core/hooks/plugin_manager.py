"""External hook plugin manager with fail-closed validation."""

from __future__ import annotations

import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
from typing import Any, Callable

import yaml
from pydantic import BaseModel, Field

from .event_bus import HookEventBus
from .events import HookEventPayload
from .models import HookSubscription


class PluginManifest(BaseModel):
    """Manifest contract for an external hook plugin."""

    name: str
    version: str
    api_version: str
    entrypoint: str
    integrity: dict[str, str] = Field(default_factory=dict)


class PluginLoadResult(BaseModel):
    """Single plugin load result."""

    name: str
    loaded: bool
    reason: str = ""
    handler_name: str | None = None


class PluginLoadReport(BaseModel):
    """Aggregate plugin load report for one manager run."""

    loaded: list[PluginLoadResult] = Field(default_factory=list)
    rejected: list[PluginLoadResult] = Field(default_factory=list)


PluginHandler = Callable[[HookEventPayload, HookSubscription], dict[str, Any] | None]


def compute_integrity(file_path: Path) -> str:
    """Compute the SHA-256 hex digest of a file.

    Use this to compute the `integrity.sha256` value for a plugin manifest
    before installing or distributing the plugin.
    """
    return hashlib.sha256(file_path.read_bytes()).hexdigest()


def get_plugin_info(plugin_dir: Path) -> dict[str, Any] | None:
    """Load and return plugin manifest info from a plugin directory.

    Looks for manifest.json or manifest.yaml (or *.plugin.json/yaml) in the
    directory and returns its contents without loading the handler.

    Returns None if no manifest is found, or raises ValueError on malformed manifests.
    """
    for pattern in ("manifest.json", "manifest.yaml", "manifest.yml"):
        manifest_path = plugin_dir / pattern
        if manifest_path.exists():
            break
    else:
        for pattern in ("*.plugin.json", "*.plugin.yaml", "*.plugin.yml"):
            matches = list(plugin_dir.glob(pattern))
            if matches:
                manifest_path = matches[0]
                break
        else:
            return None

    raw_data = manifest_path.read_text(encoding="utf-8")
    if manifest_path.suffix == ".json":
        parsed = json.loads(raw_data)
    else:
        parsed = yaml.safe_load(raw_data)
    if not isinstance(parsed, dict):
        raise ValueError("Plugin manifest must be an object")

    manifest = PluginManifest(**parsed)
    return manifest.model_dump()


def get_installed_plugins() -> list[dict[str, Any]]:
    """Discover all installed plugins from standard plugin directories.

    Returns a list of plugin info dicts (from get_plugin_info) for each
    discovered plugin, grouped by directory.
    """
    from pathlib import Path

    results: list[dict[str, Any]] = []
    dirs: list[Path] = []

    user_plugin_dir = Path.home() / ".scribe" / "plugins"
    if user_plugin_dir.exists():
        dirs.append(user_plugin_dir)

    bundled_dir = Path(__file__).parent.parent / "hooks" / "plugins"
    if bundled_dir.exists():
        dirs.append(bundled_dir)

    for plugin_dir in dirs:
        if not plugin_dir.is_dir():
            continue
        for item in sorted(plugin_dir.iterdir()):
            if not item.is_dir():
                continue
            info = get_plugin_info(item)
            if info:
                info["_dir"] = str(item)
                results.append(info)

    return results


def validate_plugin_dir(plugin_dir: Path) -> list[str]:
    """Validate a plugin directory and return a list of error messages.

    Returns an empty list if the plugin is valid, or a list of descriptive
    error strings (not exceptions) for each validation failure.
    """
    errors: list[str] = []

    manifest_path: Path | None = None
    for pattern in ("manifest.json", "manifest.yaml", "manifest.yml"):
        candidate = plugin_dir / pattern
        if candidate.exists():
            manifest_path = candidate
            break

    if manifest_path is None:
        for pattern in ("*.plugin.json", "*.plugin.yaml", "*.plugin.yml"):
            matches = list(plugin_dir.glob(pattern))
            if matches:
                manifest_path = matches[0]
                break

    if manifest_path is None:
        errors.append("No manifest.json (or *.plugin.json/yaml) found in plugin directory")
        return errors

    raw_data = manifest_path.read_text(encoding="utf-8")
    try:
        if manifest_path.suffix == ".json":
            parsed = json.loads(raw_data)
        else:
            parsed = yaml.safe_load(raw_data)
    except Exception as exc:
        errors.append(f"Manifest parse error: {exc}")
        return errors

    if not isinstance(parsed, dict):
        errors.append("Manifest must be a JSON/YAML object")
        return errors

    try:
        manifest = PluginManifest(**parsed)
    except Exception as exc:
        errors.append(f"Manifest validation error: {exc}")
        return errors

    if manifest.api_version != "1":
        errors.append(f"Unsupported api_version '{manifest.api_version}', expected '1'")

    if ":" not in manifest.entrypoint:
        errors.append("Entrypoint must use '<file.py>:<function>' format")
    else:
        file_part, func_part = manifest.entrypoint.split(":", 1)
        if not file_part.endswith(".py"):
            errors.append("Entrypoint file must end with .py")
        if not func_part:
            errors.append("Entrypoint function name is required")

    expected_sha = manifest.integrity.get("sha256", "").strip()
    if not expected_sha:
        errors.append("Manifest integrity.sha256 is required")
    else:
        file_part, _ = manifest.entrypoint.split(":", 1)
        module_path = plugin_dir / file_part
        if not module_path.exists():
            errors.append(f"Plugin module file not found: {module_path}")
        else:
            actual_sha = compute_integrity(module_path)
            if actual_sha != expected_sha:
                errors.append(
                    f"Integrity check failed: sha256 mismatch "
                    f"(expected {expected_sha[:16]}..., got {actual_sha[:16]}...)"
                )

    return errors


def install_plugin(source_path: Path, target_dir: Path) -> dict[str, Any]:
    """Copy a plugin from source_path to target_dir and compute integrity.

    source_path must be a directory containing a manifest.json.
    target_dir is the destination (e.g. ~/.scribe/plugins/).

    Returns a dict with {status, plugin_name, target_path} on success,
    or raises ValueError on validation failure.
    """
    errors = validate_plugin_dir(source_path)
    if errors:
        raise ValueError(f"Plugin validation failed: {'; '.join(errors)}")

    manifest_path = None
    for pattern in ("manifest.json", "manifest.yaml", "manifest.yml"):
        candidate = source_path / pattern
        if candidate.exists():
            manifest_path = candidate
            break

    raw = manifest_path.read_text(encoding="utf-8")
    if manifest_path.suffix == ".json":
        manifest_data = json.loads(raw)
    else:
        import yaml

        manifest_data = yaml.safe_load(raw)

    plugin_name = manifest_data.get("name")
    if not plugin_name:
        raise ValueError("Plugin manifest missing 'name' field")

    dest_plugin_dir = target_dir / plugin_name
    dest_plugin_dir.mkdir(parents=True, exist_ok=True)

    for item in source_path.iterdir():
        if item.name in (".git", "__pycache__", ".pytest_cache"):
            continue
        if item.is_file():
            dest_file = dest_plugin_dir / item.name
            dest_file.write_bytes(item.read_bytes())
        elif item.is_dir() and item.name not in ("__pycache__",):
            import shutil

            dest_sub = dest_plugin_dir / item.name
            if dest_sub.exists():
                shutil.rmtree(dest_sub)
            shutil.copytree(item, dest_sub)

    entrypoint_file = manifest_data["entrypoint"].split(":")[0]
    entrypoint_path = source_path / entrypoint_file
    digest = compute_integrity(entrypoint_path)

    dest_manifest = dest_plugin_dir / "manifest.json"
    manifest_data["integrity"] = {"sha256": digest}
    dest_manifest.write_text(json.dumps(manifest_data, indent=2), encoding="utf-8")

    return {
        "status": "installed",
        "plugin_name": plugin_name,
        "target_path": str(dest_plugin_dir),
        "integrity_sha256": digest,
    }


class PluginManager:
    """Loads and registers external plugin handlers under strict validation."""

    SUPPORTED_API_VERSION = "1"

    def __init__(
        self,
        plugin_dirs: list[str | Path],
        *,
        fail_closed: bool = True,
    ) -> None:
        self._plugin_dirs = [Path(directory).resolve() for directory in plugin_dirs]
        self._fail_closed = fail_closed

    def discover_manifest_paths(self) -> list[Path]:
        """Discover plugin manifest files from configured directories."""
        patterns = ("*.plugin.json", "*.plugin.yaml", "*.plugin.yml")
        paths: list[Path] = []
        for directory in self._plugin_dirs:
            if not directory.exists():
                continue
            for pattern in patterns:
                paths.extend(sorted(directory.glob(pattern)))
        return paths

    def load_plugins(self, event_bus: HookEventBus) -> PluginLoadReport:
        """Load all discovered plugins and register them into event bus."""
        report = PluginLoadReport()
        for manifest_path in self.discover_manifest_paths():
            try:
                manifest = self._load_manifest(manifest_path)
                plugin_handler = self._load_callable(manifest_path.parent, manifest)
                handler_name = f"plugin.{manifest.name}"
                event_bus.register_handler(handler_name, plugin_handler)
                report.loaded.append(
                    PluginLoadResult(
                        name=manifest.name,
                        loaded=True,
                        handler_name=handler_name,
                    )
                )
            except Exception as exc:
                plugin_name = manifest_path.stem.split(".plugin")[0]
                report.rejected.append(
                    PluginLoadResult(
                        name=plugin_name,
                        loaded=False,
                        reason=str(exc),
                    )
                )
                if self._fail_closed:
                    continue
        return report

    def _load_manifest(self, manifest_path: Path) -> PluginManifest:
        """Load and validate plugin manifest from JSON/YAML."""
        raw_data = manifest_path.read_text(encoding="utf-8")
        if manifest_path.suffix == ".json":
            parsed = json.loads(raw_data)
        else:
            parsed = yaml.safe_load(raw_data)
        if not isinstance(parsed, dict):
            raise ValueError(f"Plugin manifest must be an object: {manifest_path.name}")

        manifest = PluginManifest(**parsed)
        self._validate_manifest(manifest)
        self._verify_integrity(manifest_path.parent, manifest)
        return manifest

    def _validate_manifest(self, manifest: PluginManifest) -> None:
        """Validate semantic rules beyond schema presence."""
        if manifest.api_version != self.SUPPORTED_API_VERSION:
            raise ValueError(
                f"Unsupported plugin api_version '{manifest.api_version}', "
                f"expected '{self.SUPPORTED_API_VERSION}'"
            )
        if ":" not in manifest.entrypoint:
            raise ValueError("Entrypoint must use '<relative_file.py>:<function>' format")
        file_part, func_part = manifest.entrypoint.split(":", 1)
        if not file_part.endswith(".py"):
            raise ValueError("Entrypoint file must end with .py")
        if not func_part:
            raise ValueError("Entrypoint function name is required")

    def _verify_integrity(self, plugin_root: Path, manifest: PluginManifest) -> None:
        """Verify plugin file integrity using sha256 when provided."""
        expected_sha = manifest.integrity.get("sha256", "").strip()
        if not expected_sha:
            raise ValueError("Manifest integrity.sha256 is required for fail-closed loading")
        file_part, _ = manifest.entrypoint.split(":", 1)
        module_path = (plugin_root / file_part).resolve()
        if not module_path.exists():
            raise FileNotFoundError(f"Plugin module file not found: {module_path}")
        digest = hashlib.sha256(module_path.read_bytes()).hexdigest()
        if digest != expected_sha:
            raise ValueError("Plugin integrity check failed: sha256 mismatch")

    def _load_callable(self, plugin_root: Path, manifest: PluginManifest) -> PluginHandler:
        """Load plugin callable and validate callable interface."""
        file_part, func_name = manifest.entrypoint.split(":", 1)
        module_path = (plugin_root / file_part).resolve()

        module_name = f"hooks_plugin_{manifest.name}_{manifest.version.replace('.', '_')}"
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ValueError(f"Unable to create import spec for plugin: {manifest.name}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        plugin_func = getattr(module, func_name, None)
        if not callable(plugin_func):
            raise ValueError(f"Plugin entrypoint function not callable: {func_name}")

        signature = inspect.signature(plugin_func)
        if len(signature.parameters) < 2:
            raise ValueError("Plugin function must accept at least (payload, subscription)")

        def _wrapped_handler(
            payload: HookEventPayload,
            subscription: HookSubscription,
        ) -> dict[str, Any] | None:
            output = plugin_func(payload, subscription)
            if output is None:
                return None
            if not isinstance(output, dict):
                raise ValueError("Plugin handler output must be dict or None")
            return output

        return _wrapped_handler
