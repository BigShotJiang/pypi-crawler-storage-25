"""Runtime guardrail engine for input/output/tool protection.

Extends the original regex-based guardrails with a plugin chain architecture.
Existing ``GuardrailConfig.blocked_*_patterns`` auto-migrate to
``RegexBlocklistPlugin`` instances for full backward compatibility.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from typing import Any, Literal

from pydantic import BaseModel, Field


class GuardrailMatch(BaseModel):
    """A single guardrail match within content."""

    pattern: str
    value: str
    start: int
    end: int


class GuardrailResult(BaseModel):
    """Result from a single guardrail plugin check."""

    passed: bool
    severity: Literal["warn", "block"] = "block"
    reason: str = ""
    matches: list[GuardrailMatch] = Field(default_factory=list)
    plugin_name: str = ""


class GuardrailConfig(BaseModel):
    """Configurable guardrail policies."""

    blocked_input_patterns: list[str] = Field(
        default_factory=lambda: [r"rm\s+-rf", r"ignore\s+all\s+previous\s+instructions"]
    )
    blocked_output_patterns: list[str] = Field(
        default_factory=lambda: [r"api[_-]?key", r"password"]
    )
    allowed_tool_permissions: set[str] = Field(default_factory=lambda: {"default", "system"})
    plugins: list[PluginConfig] = Field(default_factory=list)


class PluginConfig(BaseModel):
    """Configuration for a single guardrail plugin."""

    name: str
    enabled: bool = True
    severity: Literal["warn", "block"] = "block"
    options: dict[str, Any] = Field(default_factory=dict)


class GuardrailDecision(BaseModel):
    """Guardrail decision outcome — the public API consumed by runtime guards."""

    allowed: bool
    reason: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class GuardrailPlugin(ABC):
    """Abstract base class for guardrail plugins.

    Subclass and implement ``check()`` to create custom guardrails.
    Register with ``GuardrailEngine.register_plugin()``.
    """

    name: str = ""

    @abstractmethod
    def check(self, content: str, *, context: dict[str, Any] | None = None) -> GuardrailResult:
        """Check content and return a result.

        Args:
            content: The text to validate.
            context: Optional context dict (e.g. ``{"direction": "input"}``).

        Returns:
            ``GuardrailResult`` with ``passed=True`` if content is acceptable.
        """


class RegexBlocklistPlugin(GuardrailPlugin):
    """Block content matching configured regex patterns.

    This replaces the hardcoded pattern loops that were previously
    inline in ``GuardrailEngine.validate_input/output``.
    """

    name = "regex_blocklist"

    def __init__(
        self,
        patterns: list[str],
        severity: Literal["warn", "block"] = "block",
        direction: Literal["input", "output", "both"] = "both",
    ) -> None:
        self._patterns = patterns
        self._severity = severity
        self._direction = direction

    def check(self, content: str, *, context: dict[str, Any] | None = None) -> GuardrailResult:
        direction = (context or {}).get("direction", "both")
        if self._direction != "both" and direction != self._direction:
            return GuardrailResult(passed=True, plugin_name=self.name)

        matches: list[GuardrailMatch] = []
        for pattern in self._patterns:
            for m in re.finditer(pattern, content, flags=re.IGNORECASE):
                matches.append(
                    GuardrailMatch(
                        pattern=pattern,
                        value=m.group(),
                        start=m.start(),
                        end=m.end(),
                    )
                )

        if not matches:
            return GuardrailResult(passed=True, plugin_name=self.name)

        reasons = ", ".join(m.pattern for m in matches)
        direction_label = "Input" if self._direction == "input" else "Output"
        return GuardrailResult(
            passed=False,
            severity=self._severity,
            reason=f"{direction_label} blocked by guardrail pattern: {reasons}",
            matches=matches,
            plugin_name=self.name,
        )


class ContentLengthPlugin(GuardrailPlugin):
    """Validate content falls within configured length bounds."""

    name = "content_length"

    def __init__(
        self,
        min_length: int = 0,
        max_length: int = 0,
        severity: Literal["warn", "block"] = "block",
    ) -> None:
        self._min_length = min_length
        self._max_length = max_length
        self._severity = severity

    def check(self, content: str, *, context: dict[str, Any] | None = None) -> GuardrailResult:
        length = len(content)
        if self._min_length > 0 and length < self._min_length:
            return GuardrailResult(
                passed=False,
                severity=self._severity,
                reason=f"Content length {length} below minimum {self._min_length}",
                plugin_name=self.name,
            )
        if self._max_length > 0 and length > self._max_length:
            return GuardrailResult(
                passed=False,
                severity=self._severity,
                reason=f"Content length {length} exceeds maximum {self._max_length}",
                plugin_name=self.name,
            )
        return GuardrailResult(passed=True, plugin_name=self.name)


_PII_PATTERNS: dict[str, str] = {
    "email": r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b",
    "phone_us": r"\b\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b",
    "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
    "credit_card": r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b",
}


class PIIDetectionPlugin(GuardrailPlugin):
    """Heuristic PII detection via configurable regex patterns.

    Detects common PII patterns: email addresses, phone numbers,
    SSN-like sequences, and credit-card-like numbers. Each pattern
    type can be individually enabled/disabled. An allowlist suppresses
    false positives for known-safe values.
    """

    name = "pii_detection"

    def __init__(
        self,
        enabled_patterns: list[str] | None = None,
        severity: Literal["warn", "block"] = "warn",
        allowlist: list[str] | None = None,
    ) -> None:
        self._enabled_patterns = enabled_patterns or list(_PII_PATTERNS.keys())
        self._severity = severity
        self._allowlist = set(allowlist or [])

    def check(self, content: str, *, context: dict[str, Any] | None = None) -> GuardrailResult:
        matches: list[GuardrailMatch] = []
        for pattern_name in self._enabled_patterns:
            pattern = _PII_PATTERNS.get(pattern_name)
            if pattern is None:
                continue
            for m in re.finditer(pattern, content):
                value = m.group()
                if value in self._allowlist:
                    continue
                matches.append(
                    GuardrailMatch(
                        pattern=pattern_name,
                        value=value,
                        start=m.start(),
                        end=m.end(),
                    )
                )

        if not matches:
            return GuardrailResult(passed=True, plugin_name=self.name)

        types = sorted({m.pattern for m in matches})
        return GuardrailResult(
            passed=False,
            severity=self._severity,
            reason=f"PII detected: {', '.join(types)}",
            matches=matches,
            plugin_name=self.name,
        )


class GuardrailEngine:
    """Engine implementing input/output/tool guardrails via plugin chain.

    For backward compatibility, ``GuardrailConfig.blocked_input_patterns``
    and ``blocked_output_patterns`` are auto-migrated to
    ``RegexBlocklistPlugin`` instances on construction.
    """

    def __init__(self, config: GuardrailConfig | None = None) -> None:
        self.config = config or GuardrailConfig()
        self._plugins: list[GuardrailPlugin] = []
        self._migrate_legacy_config()

    def _migrate_legacy_config(self) -> None:
        if self.config.blocked_input_patterns:
            self._plugins.append(
                RegexBlocklistPlugin(
                    self.config.blocked_input_patterns,
                    direction="input",
                )
            )
        if self.config.blocked_output_patterns:
            self._plugins.append(
                RegexBlocklistPlugin(
                    self.config.blocked_output_patterns,
                    direction="output",
                )
            )

    def register_plugin(self, plugin: GuardrailPlugin) -> None:
        """Register a guardrail plugin to the check chain."""
        self._plugins.append(plugin)

    @property
    def plugins(self) -> list[GuardrailPlugin]:
        return list(self._plugins)

    def validate_input(self, user_input: str) -> GuardrailDecision:
        """Validate incoming user input before model invocation."""
        warnings: list[GuardrailResult] = []
        for plugin in self._plugins:
            result = plugin.check(user_input, context={"direction": "input"})
            if not result.passed:
                if result.severity == "block":
                    return GuardrailDecision(
                        allowed=False,
                        reason=result.reason,
                        metadata={
                            "layer": "input",
                            "plugin": result.plugin_name,
                            "matches": [m.model_dump() for m in result.matches],
                        },
                    )
                warnings.append(result)

        meta: dict[str, Any] = {"layer": "input"}
        if warnings:
            meta["warnings"] = [w.model_dump() for w in warnings]
        return GuardrailDecision(allowed=True, metadata=meta)

    def validate_output(self, output_text: str) -> GuardrailDecision:
        """Validate model output before returning result."""
        warnings: list[GuardrailResult] = []
        for plugin in self._plugins:
            result = plugin.check(output_text, context={"direction": "output"})
            if not result.passed:
                if result.severity == "block":
                    return GuardrailDecision(
                        allowed=False,
                        reason=result.reason,
                        metadata={
                            "layer": "output",
                            "plugin": result.plugin_name,
                            "matches": [m.model_dump() for m in result.matches],
                        },
                    )
                warnings.append(result)

        meta: dict[str, Any] = {"layer": "output"}
        if warnings:
            meta["warnings"] = [w.model_dump() for w in warnings]
        return GuardrailDecision(allowed=True, metadata=meta)

    def validate_tool_call(self, tool_name: str, permission: str) -> GuardrailDecision:
        """Validate tool call permission before execution."""
        if permission not in self.config.allowed_tool_permissions:
            return GuardrailDecision(
                allowed=False,
                reason=f"Tool permission denied: {permission}",
                metadata={
                    "layer": "tool",
                    "tool": tool_name,
                    "permission": permission,
                },
            )
        return GuardrailDecision(
            allowed=True,
            metadata={"layer": "tool", "tool": tool_name, "permission": permission},
        )

    def check_content(self, content: str, *, direction: str = "output") -> list[GuardrailResult]:
        """Run all plugins and return full results list (no short-circuit).

        Useful for ad-hoc validation (CLI/API check commands).
        """
        results: list[GuardrailResult] = []
        for plugin in self._plugins:
            result = plugin.check(content, context={"direction": direction})
            results.append(result)
        return results
