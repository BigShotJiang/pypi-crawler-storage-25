"""Plugin management commands for NovelScribe."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import click

from core.hooks.plugin_manager import (
    compute_integrity,
    get_installed_plugins,
    get_plugin_info,
    validate_plugin_dir,
)


@click.group()
def plugins() -> None:
    """Manage NovelScribe hook plugins."""
    pass


@plugins.command("list")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
)
def list_plugins(output_format: str) -> None:
    """List installed plugins from ~/.scribe/plugins/ and bundled plugins."""
    all_plugins = get_installed_plugins()

    if output_format == "json":
        result = {"count": len(all_plugins), "plugins": all_plugins}
        click.echo(json.dumps(result, indent=2))
        return

    if not all_plugins:
        click.echo("No plugins installed.")
        click.echo("  Bundled: ~/.scribe/plugins/ and core/hooks/plugins/")
        click.echo("  Use 'scribe plugins install <path>' to install a plugin.")
        return

    click.echo(f"Installed plugins ({len(all_plugins)}):")

    user_plugins: list[dict] = []
    bundled_plugins: list[dict] = []

    for plugin in all_plugins:
        plugin_dir = plugin.get("_dir", "")
        if ".scribe" in plugin_dir:
            user_plugins.append(plugin)
        else:
            bundled_plugins.append(plugin)

    if bundled_plugins:
        click.echo("\n  Bundled:")
        for plugin in bundled_plugins:
            click.echo(f"    {plugin['name']} v{plugin['version']}")

    if user_plugins:
        click.echo("\n  User-installed:")
        for plugin in user_plugins:
            click.echo(f"    {plugin['name']} v{plugin['version']}")
    else:
        click.echo("\n  User-installed: none")


@plugins.command("check")
@click.argument("name")
def check_plugin(name: str) -> None:
    """Validate a plugin's manifest and integrity without loading it."""
    user_plugin_dir = Path.home() / ".scribe" / "plugins" / name
    bundled_plugin_dir = (
        Path(__file__).resolve().parent.parent.parent / "core" / "hooks" / "plugins" / name
    )

    plugin_dir: Path | None = None
    for candidate in (user_plugin_dir, bundled_plugin_dir):
        if candidate.exists() and candidate.is_dir():
            plugin_dir = candidate
            break

    if plugin_dir is None:
        click.echo(f"Plugin '{name}' not found.", err=True)
        click.echo("  Searched: ~/.scribe/plugins/ and bundled plugins directory", err=True)
        sys.exit(1)

    errors = validate_plugin_dir(plugin_dir)

    if not errors:
        click.echo(f"✓ Plugin '{name}' is valid.")
        info = get_plugin_info(plugin_dir)
        if info:
            click.echo(f"  name: {info['name']}")
            click.echo(f"  version: {info['version']}")
            click.echo(f"  api_version: {info['api_version']}")
            click.echo(f"  entrypoint: {info['entrypoint']}")
            click.echo(f"  integrity: {info['integrity'].get('sha256', 'MISSING')[:16]}...")
        sys.exit(0)
    else:
        click.echo(f"✗ Plugin '{name}' has validation errors:", err=True)
        for error in errors:
            click.echo(f"  - {error}", err=True)
        sys.exit(1)


@plugins.command("install")
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
)
def install_plugin_cmd(path: Path, output_format: str) -> None:
    """Install a plugin from a local directory path.

    Copies the plugin to ~/.scribe/plugins/, validates its manifest,
    and computes the integrity digest for the entrypoint file.

    Example:
        scribe plugins install /path/to/my-plugin
    """
    source_dir = path.resolve()
    if not source_dir.is_dir():
        click.echo(f"Error: '{source_dir}' is not a directory.", err=True)
        sys.exit(1)

    errors = validate_plugin_dir(source_dir)
    if errors:
        click.echo("Plugin validation failed:", err=True)
        for error in errors:
            click.echo(f"  - {error}", err=True)
        sys.exit(1)

    target_dir = Path.home() / ".scribe" / "plugins"
    target_dir.mkdir(parents=True, exist_ok=True)

    manifest_path = None
    for pattern in ("manifest.json", "manifest.yaml", "manifest.yml"):
        candidate = source_dir / pattern
        if candidate.exists():
            manifest_path = candidate
            break

    if manifest_path is None:
        for pattern in ("*.plugin.json", "*.plugin.yaml", "*.plugin.yml"):
            matches = list(source_dir.glob(pattern))
            if matches:
                manifest_path = matches[0]
                break

    raw = manifest_path.read_text(encoding="utf-8")
    if manifest_path.suffix == ".json":
        manifest_data = json.loads(raw)
    else:
        import yaml

        manifest_data = yaml.safe_load(raw)

    plugin_name = manifest_data.get("name", source_dir.name)

    entrypoint_file = manifest_data["entrypoint"].split(":")[0]
    entrypoint_path = source_dir / entrypoint_file
    digest = compute_integrity(entrypoint_path)

    dest_plugin_dir = target_dir / plugin_name
    dest_plugin_dir.mkdir(parents=True, exist_ok=True)

    for item in source_dir.iterdir():
        if item.name in (".git", "__pycache__", ".pytest_cache"):
            continue
        if item.is_file():
            dest_file = dest_plugin_dir / item.name
            dest_file.write_bytes(item.read_bytes())
        elif item.is_dir() and item.name not in ("__pycache__",):
            dest_sub = dest_plugin_dir / item.name
            if dest_sub.exists():
                shutil.rmtree(dest_sub)
            shutil.copytree(item, dest_sub)

    dest_manifest = dest_plugin_dir / "manifest.json"
    manifest_data["integrity"] = {"sha256": digest}
    dest_manifest.write_text(json.dumps(manifest_data, indent=2), encoding="utf-8")

    if output_format == "json":
        result = {
            "status": "installed",
            "plugin_name": plugin_name,
            "target_path": str(dest_plugin_dir),
            "integrity_sha256": digest,
        }
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(f"✓ Plugin '{plugin_name}' installed to {dest_plugin_dir}")
        click.echo(f"  integrity.sha256: {digest}")
