"""Guardrail management and validation commands."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from core.runtime import GuardrailEngine


@click.group()
def guardrails() -> None:
    """Guardrail management and content validation."""
    pass


@guardrails.command("list")
@click.option("--format", "output_format", type=click.Choice(["text", "json"]), default="text")
def list_guardrails(output_format: str) -> None:
    """List configured guardrail plugins."""
    engine = GuardrailEngine()
    plugins = engine.plugins

    if output_format == "json":
        entries = []
        for p in plugins:
            entries.append({"name": p.name})
        click.echo(json.dumps({"count": len(entries), "plugins": entries}, indent=2))
        return

    click.echo(f"Configured guardrails ({len(plugins)}):")
    for p in plugins:
        click.echo(f"  • {p.name}")


@guardrails.command("check")
@click.argument("file", type=click.Path(exists=True))
@click.option("--direction", type=click.Choice(["input", "output"]), default="output")
@click.option("--format", "output_format", type=click.Choice(["text", "json"]), default="text")
def check_file(file: str, direction: str, output_format: str) -> None:
    """Validate file content against active guardrails."""
    content = Path(file).read_text()
    engine = GuardrailEngine()
    results = engine.check_content(content, direction=direction)

    passed = all(r.passed for r in results)

    if output_format == "json":
        click.echo(
            json.dumps(
                {
                    "file": file,
                    "direction": direction,
                    "passed": passed,
                    "results": [
                        {
                            "plugin": r.plugin_name,
                            "passed": r.passed,
                            "severity": r.severity,
                            "reason": r.reason,
                            "matches": [m.model_dump() for m in r.matches],
                        }
                        for r in results
                    ],
                },
                indent=2,
            )
        )
        return

    if passed:
        click.echo(f"✓ {file}: All guardrails passed")
    else:
        has_block = any(r.severity == "block" for r in results if not r.passed)
        if has_block:
            click.echo(f"✗ {file}: Guardrail violations detected", err=True)
            for r in results:
                if not r.passed:
                    click.echo(f"  [{r.severity.upper()}] {r.plugin_name}: {r.reason}")
                    for m in r.matches:
                        click.echo(f"    - {m.pattern}: '{m.value}' at {m.start}-{m.end}")
            sys.exit(1)
        else:
            click.echo(f"⚠ {file}: Warnings raised (no blocks)")
            for r in results:
                if not r.passed:
                    click.echo(f"  [{r.severity.upper()}] {r.plugin_name}: {r.reason}")
