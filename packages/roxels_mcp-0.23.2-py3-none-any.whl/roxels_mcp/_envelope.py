"""Canonical response envelope for all MCP tools.

Every tool response goes through one of `ok()`, `error()`, `not_found()`,
or `pending()`. The shape is predictable so agents can parse without reading
docstrings:

    {
      "status": "ok" | "error" | "pending" | "not_found",
      "action": "created" | "updated" | ...,
      "data": {...},
      "warnings": [{...}],
      "next_action": {"why": "...", "call": {"tool": "...", "args": {...}}, "call_string": "..."},
      "meta": {
        "mcp_version": "...",
        "loop_phase": "primary" | "secondary" | "setup" | "reference" | "utility" | "meta",
        "on_recommended_path": bool,   # when the tool is not the one get_next_action would recommend
        "template_state": {score, gaps_remaining, shape_status, has_live_sessions},
        "template_id": "..."
      }
    }

Error shape adds `error`, `details`, `hint`, and an optional `off_script_warning`
surfaced in data when `on_recommended_path=False`.

Design principles this enforces:
  P2 (ONE SHAPE)     — every response has the same keys.
  P3 (ONE THREAD)    — every response has an optional `next_action` that points
                        the agent at the next concrete call.
  P4 (WHERE-YOU-ARE) — every response labels which phase of the convergence
                        loop it belongs to (meta.loop_phase).
  P5 (OFF-SCRIPT)    — every response flags whether the agent is following the
                        recommended path (meta.on_recommended_path + visible
                        warning when False).
  P6 (STATE SNAPSHOT)— every template-scoped response carries live template
                        state so the agent never re-queries to know where
                        they are (meta.template_state).
"""
from __future__ import annotations

import json
from typing import Any, Callable, Literal


LoopPhase = Literal["primary", "secondary", "setup", "reference", "utility", "meta"]


def _mcp_version() -> str:
    try:
        from importlib.metadata import version as pkg_version
        return pkg_version("roxels-mcp")
    except Exception:
        return "unknown"


# ── Path-awareness hooks ──────────────────────────────────────────────────────
#
# Computing "which tool would get_next_action have recommended?" requires hitting
# the backend (for _collect_template_gaps), so it's fundamentally async. The
# envelope itself is sync. To avoid sync/async contortions:
#
#   Tools that want path-awareness compute (recommended_tool, template_state)
#   themselves via the async helper `compute_path_awareness(...)` and pass the
#   results into the envelope via the `recommended_tool` and `template_state`
#   kwargs. The envelope just formats.
#
# Backward-compat: old `register_path_recommender` kept as a no-op shim so
# existing tests don't crash during the V2 transition.


def register_path_recommender(fn: Callable[..., Any]) -> None:
    """DEPRECATED — path awareness now flows through explicit kwargs
    (recommended_tool + template_state). Tools compute state themselves.
    Kept as a no-op for backward compat with the V2-A transition tests.
    """
    global _PATH_RECOMMENDER_SHIM
    _PATH_RECOMMENDER_SHIM = fn


_PATH_RECOMMENDER_SHIM: Callable[..., Any] | None = None


def _compute_meta_extras(
    current_tool: str | None,
    loop_phase: LoopPhase | None,
    recommended_tool: str | None,
    template_state: dict | None,
) -> dict:
    """Assemble the dynamic meta.* fields."""
    extras: dict[str, Any] = {}
    if loop_phase is not None:
        extras["loop_phase"] = loop_phase
    # If tool_name + recommended_tool are both provided, compute on_recommended_path.
    if current_tool is not None and recommended_tool is not None:
        extras["on_recommended_path"] = (recommended_tool == current_tool)
        if recommended_tool != current_tool:
            extras["recommended_tool"] = recommended_tool
    # Back-compat: if a shim recommender was registered (V2-A transition tests),
    # consult it so those tests still pass. Swallow any exception.
    elif current_tool is not None and _PATH_RECOMMENDER_SHIM is not None:
        try:
            result = _PATH_RECOMMENDER_SHIM(current_tool, None)
        except Exception:
            result = None
        if result is not None:
            rec, state = result
            extras["on_recommended_path"] = (rec is None) or (rec == current_tool)
            if not extras["on_recommended_path"] and rec:
                extras["recommended_tool"] = rec
            if state is not None and template_state is None:
                extras["template_state"] = state
    if template_state is not None:
        extras["template_state"] = template_state
    return extras


def _off_script_warning(meta_extras: dict) -> str | None:
    """Build the visible off-script warning when the tool wasn't on the path."""
    if meta_extras.get("on_recommended_path") is False and meta_extras.get("recommended_tool"):
        return (
            f"You called a tool directly while `{meta_extras['recommended_tool']}` "
            f"was the recommended next call. Continuing anyway. Call "
            f"`get_next_action(template_id=...)` if you want the recommended chain."
        )
    return None


# ── Next-action builder ───────────────────────────────────────────────────────

def next_action(
    *,
    tool: str,
    args: dict[str, Any] | None = None,
    why: str = "",
    question: str | None = None,
) -> dict[str, Any]:
    """Build a canonical next_action block.

    Args:
        tool: The tool name the agent should call next.
        args: Dict of arguments to pass to the tool.
        why: One-sentence reason this is the next step.
        question: Optional clarifying question the agent should answer first
                  (from its own context — not forwarded to the user).

    Returns:
        A dict with `why`, `call`, `call_string`, and optional `question`.
    """
    args = args or {}

    def _fmt_arg(v: Any) -> str:
        if isinstance(v, str):
            return repr(v)
        if isinstance(v, (dict, list)):
            return json.dumps(v, default=str)
        return repr(v)

    call_string = f"{tool}({', '.join(f'{k}={_fmt_arg(v)}' for k, v in args.items())})"
    block: dict[str, Any] = {
        "why": why,
        "call": {"tool": tool, "args": args},
        "call_string": call_string,
    }
    if question:
        block["question"] = question
    return block


# ── Envelope builders ─────────────────────────────────────────────────────────

def ok(
    *,
    action: str | None = None,
    data: Any = None,
    warnings: list[dict] | None = None,
    next_action_block: dict | None = None,
    meta: dict | None = None,
    # V2 kwargs (all optional — existing callers unaffected):
    tool_name: str | None = None,
    loop_phase: LoopPhase | None = None,
    template_id_for_state: str | None = None,  # LEGACY: ignored in new path
    recommended_tool: str | None = None,       # V2: pre-computed by the tool
    template_state: dict | None = None,        # V2: pre-computed by the tool
) -> str:
    """Build a JSON-serialized success envelope.

    Args:
        action: Transition verb (created/updated/patched/etc.).
        data: The primary payload.
        warnings: List of {rule, message, severity} dicts.
        next_action_block: Output of `next_action(...)`.
        meta: Additional metadata (template_id, etc.) — mcp_version is auto-added.
        tool_name: Name of the calling tool. Combined with recommended_tool,
            enables `meta.on_recommended_path` + off-script warning.
        loop_phase: Which phase of the convergence loop this tool belongs to.
        recommended_tool: The tool that `get_next_action` would have suggested
            right now. When != tool_name, envelope sets on_recommended_path=False
            and adds the off_script_warning.
        template_state: {score, gaps_remaining, shape_status, has_live_sessions}
            snapshot computed by the calling tool (via compute_path_awareness).
        template_id_for_state: LEGACY, ignored. Kept to avoid breaking older tests.
    """
    envelope: dict[str, Any] = {"status": "ok"}
    if action is not None:
        envelope["action"] = action

    extras = _compute_meta_extras(tool_name, loop_phase, recommended_tool, template_state)
    warning_text = _off_script_warning(extras)

    final_data = data
    if warning_text:
        if isinstance(final_data, dict):
            final_data = {"off_script_warning": warning_text, **final_data}
        elif final_data is None:
            final_data = {"off_script_warning": warning_text}
        # else: data is a list/scalar — leave it alone, the meta still carries the signal

    if final_data is not None:
        envelope["data"] = final_data
    if warnings:
        envelope["warnings"] = warnings
    if next_action_block:
        envelope["next_action"] = next_action_block

    meta_out = {"mcp_version": _mcp_version(), **extras}
    if meta:
        meta_out.update(meta)
    envelope["meta"] = meta_out
    return json.dumps(envelope, indent=2, default=str)


def error(
    *,
    error_message: str,
    details: str | None = None,
    hint: str | None = None,
    next_action_block: dict | None = None,
    status: Literal["error", "not_found"] = "error",
    meta: dict | None = None,
    tool_name: str | None = None,
    loop_phase: LoopPhase | None = None,
    template_id_for_state: str | None = None,  # LEGACY
    recommended_tool: str | None = None,
    template_state: dict | None = None,
) -> str:
    """Build a JSON-serialized error envelope."""
    envelope: dict[str, Any] = {"status": status, "error": error_message}
    if details is not None:
        envelope["details"] = details
    if hint is not None:
        envelope["hint"] = hint
    if next_action_block:
        envelope["next_action"] = next_action_block

    extras = _compute_meta_extras(tool_name, loop_phase, recommended_tool, template_state)
    meta_out = {"mcp_version": _mcp_version(), **extras}
    if meta:
        meta_out.update(meta)
    envelope["meta"] = meta_out
    return json.dumps(envelope, indent=2, default=str)


def pending(
    *,
    message: str,
    next_action_block: dict | None = None,
    meta: dict | None = None,
    tool_name: str | None = None,
    loop_phase: LoopPhase | None = None,
    template_id_for_state: str | None = None,  # LEGACY
    recommended_tool: str | None = None,
    template_state: dict | None = None,
) -> str:
    """Build a JSON-serialized pending envelope (async operation in flight)."""
    envelope: dict[str, Any] = {"status": "pending", "message": message}
    if next_action_block:
        envelope["next_action"] = next_action_block

    extras = _compute_meta_extras(tool_name, loop_phase, recommended_tool, template_state)
    meta_out = {"mcp_version": _mcp_version(), **extras}
    if meta:
        meta_out.update(meta)
    envelope["meta"] = meta_out
    return json.dumps(envelope, indent=2, default=str)


def not_found(
    *,
    resource: str,
    identifier: str,
    hint: str | None = None,
    next_action_block: dict | None = None,
    meta: dict | None = None,
    tool_name: str | None = None,
    loop_phase: LoopPhase | None = None,
    template_id_for_state: str | None = None,  # LEGACY
    recommended_tool: str | None = None,
    template_state: dict | None = None,
) -> str:
    """Build a JSON-serialized not_found envelope.

    Preferred over error() for missing-resource cases so agents can branch.
    """
    return error(
        error_message=f"{resource} '{identifier}' not found.",
        hint=hint,
        next_action_block=next_action_block,
        status="not_found",
        meta=meta,
        tool_name=tool_name,
        loop_phase=loop_phase,
        recommended_tool=recommended_tool,
        template_state=template_state,
    )


# ── Helpers ───────────────────────────────────────────────────────────────────

def wrap_warnings(messages: list[str], *, rule: str, severity: str = "MEDIUM") -> list[dict]:
    """Convert a list of warning strings into the canonical warning shape."""
    return [
        {"rule": rule, "message": m, "severity": severity}
        for m in messages if m
    ]


def format_gap_as_next_action(gap: dict) -> dict | None:
    """Translate a legacy gap dict (from _collect_template_gaps) into a next_action block.

    Accepts the old shape with `field`, `problem`, `answer_this`, `then_call` and
    produces a structured next_action. Returns None if no actionable call is present.
    """
    if not isinstance(gap, dict):
        return None
    then_call = gap.get("then_call")
    if not then_call:
        return None
    # then_call is usually a pre-formatted string like "tool_name(args)"
    # Parse the tool name out; leave args as the raw string since gap strings
    # often include placeholder syntax like <goal_id>.
    tool_name = str(then_call).split("(", 1)[0].strip()
    return {
        "why": gap.get("problem") or "",
        "question": gap.get("answer_this"),
        "call": {"tool": tool_name, "args": {}},
        "call_string": str(then_call),
    }
