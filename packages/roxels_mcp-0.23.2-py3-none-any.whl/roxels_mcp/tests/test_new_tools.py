"""Unit tests for the new self-guiding tools added in v0.21.

Covers:
  - get_next_action (state-aware recommender)
  - get_mcp_index (categorized tool listing)
  - preview_webhook_payload (body_template interpolation dry-run)
"""
import json

import pytest
from unittest.mock import AsyncMock, MagicMock

from roxels_mcp.server import create_server
from roxels_mcp.client import RoxelsClient


def _get_tool(mcp, name: str):
    return mcp._tool_manager._tools[name].fn


def _make_client(template: dict) -> RoxelsClient:
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value=template)
    client.update_template = AsyncMock(return_value=template)
    client.list_templates = AsyncMock(return_value=[template])
    client._request = AsyncMock(return_value=[])
    return client


# ── get_mcp_index ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_mcp_index_returns_categorized_listing():
    client = _make_client({"id": "t1", "goals": [], "settings": {}})
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "get_mcp_index")
    result = json.loads(await tool_fn())
    assert result["status"] == "ok"
    categories = result["data"]["categories"]
    assert "Templates" in categories
    assert "Diagnostics" in categories
    assert any(t["tool"] == "check_template" for t in categories["Diagnostics"])
    assert any(t["tool"] == "get_next_action" for t in categories["Diagnostics"])


# ── get_next_action ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_next_action_without_template_id_suggests_list_or_create():
    client = _make_client({"id": "t1"})
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "get_next_action")
    result = json.loads(await tool_fn())
    assert result["status"] == "ok"
    na = result["next_action"]
    assert na["call"]["tool"] in ("list_templates", "create_template_interactive")


@pytest.mark.asyncio
async def test_get_next_action_with_gaps_points_at_highest_severity():
    template = {
        "id": "t1",
        "goals": [{"id": "g1", "label": "test"}],
        "settings": {
            "outputs": [{
                "type": "webhook",
                "config": {
                    "trigger_goal": "g1",
                    "commit_policy": "require_all_required",
                    "schema": {"name": "string"},  # no required_before_commit — HIGH gap
                },
            }]
        },
    }
    client = _make_client(template)
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "get_next_action")
    result = json.loads(await tool_fn(template_id="t1"))
    assert result["status"] == "ok"
    # The top next_action should point at update_webhook_schema
    na = result["next_action"]
    assert "update_webhook_schema" in na["call_string"]


@pytest.mark.asyncio
async def test_get_next_action_no_gaps_suggests_live_test():
    # Template with no outputs → no gaps beyond any org-level
    template = {"id": "t1", "goals": [], "settings": {}}
    client = _make_client(template)
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "get_next_action")
    result = json.loads(await tool_fn(template_id="t1"))
    assert result["status"] == "ok"
    # No gaps (or some low ones); next_action should still be set
    assert "next_action" in result


# ── verify(scope="webhook_preview") ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_verify_webhook_preview_with_body_template():
    template = {
        "id": "t1",
        "goals": [{"id": "g1"}],
        "settings": {
            "outputs": [{
                "type": "webhook",
                "config": {
                    "trigger_goal": "g1",
                    "body_template": {
                        "customer_id": "{{context.stripe_customer_id}}",
                        "name": "{{name}}",
                    },
                    "schema": {"name": "string"},
                    "body_encoding": "json",
                },
            }]
        },
    }
    client = _make_client(template)
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "verify")
    result = json.loads(await tool_fn(
        scope="webhook_preview",
        template_id="t1",
        trigger_goal="g1",
        sample_data={"context.stripe_customer_id": "cus_123", "name": "Acme"},
    ))
    assert result["status"] == "ok"
    body = result["data"]["body"]
    assert body["customer_id"] == "cus_123"
    assert body["name"] == "Acme"
    assert "context.stripe_customer_id" in result["data"]["resolved_context_keys"]


@pytest.mark.asyncio
async def test_verify_webhook_preview_unresolved_placeholders_surface():
    template = {
        "id": "t1",
        "goals": [{"id": "g1"}],
        "settings": {
            "outputs": [{
                "type": "webhook",
                "config": {
                    "trigger_goal": "g1",
                    "body_template": {"x": "{{context.missing_key}}"},
                    "schema": {},
                    "body_encoding": "json",
                },
            }]
        },
    }
    client = _make_client(template)
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "verify")
    result = json.loads(await tool_fn(
        scope="webhook_preview",
        template_id="t1",
        trigger_goal="g1",
    ))
    assert "context.missing_key" in result["data"]["unresolved_placeholders"]


@pytest.mark.asyncio
async def test_verify_webhook_preview_not_found_returns_not_found_status():
    template = {"id": "t1", "goals": [], "settings": {"outputs": []}}
    client = _make_client(template)
    mcp = create_server(client)
    tool_fn = _get_tool(mcp, "verify")
    result = json.loads(await tool_fn(
        scope="webhook_preview",
        template_id="t1",
        trigger_goal="nonexistent_goal",
    ))
    assert result["status"] == "not_found"


@pytest.mark.asyncio
async def test_integration_shape_propose_surfaces_draft_failure():
    """When the backend reports draft_failed, propose returns an error envelope
    with a next_action routing the agent to check_template (skip shape)."""
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value={"id": "t1", "settings": {}})
    client.extract_setup_intent_now = AsyncMock(return_value={
        "integration_shape_status": "draft_failed: LLM returned malformed JSON",
        "items_count": 0,
    })
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)
    tool = _get_tool(mcp, "integration_shape")
    result = json.loads(await tool(template_id="t1", action="propose"))
    assert result["status"] == "error"
    assert "draft failed" in result["error"].lower() or "draft_failed" in result["error"].lower()
    na = result.get("next_action", {})
    assert na.get("call", {}).get("tool") == "check_template"


@pytest.mark.asyncio
async def test_integration_shape_propose_surfaces_empty_response():
    """When backend returns no shape_status, propose returns an error envelope
    with a next_action routing the agent to check_template."""
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value={"id": "t1", "settings": {}})
    client.extract_setup_intent_now = AsyncMock(return_value={})
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)
    tool = _get_tool(mcp, "integration_shape")
    result = json.loads(await tool(template_id="t1", action="propose"))
    assert result["status"] == "error"
    na = result.get("next_action", {})
    assert na.get("call", {}).get("tool") == "check_template"


@pytest.mark.asyncio
async def test_integration_shape_propose_succeeds_with_template_fallback():
    """When backend reports transcript_available=False but produced a shape,
    propose succeeds and surfaces the fallback note."""
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value={"id": "t1", "settings": {}})
    client.extract_setup_intent_now = AsyncMock(return_value={
        "integration_shape_status": "proposed_by_roxels",
        "integration_shape_generation_ms": 1234,
        "items_count": 0,
        "transcript_available": False,
    })
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)
    tool = _get_tool(mcp, "integration_shape")
    result = json.loads(await tool(template_id="t1", action="propose"))
    assert result["status"] == "ok"
    assert result["action"] == "proposed"
    assert result["data"]["transcript_available"] is False
    assert result["data"]["note"]
    assert "template" in result["data"]["note"].lower()


def test_looks_like_raw_secret_exempts_template_placeholders():
    """The canonical auth form 'Bearer {{context.authToken}}' must NOT be flagged
    as a raw credential — it's a template placeholder, resolved at runtime."""
    from roxels_mcp.server import _looks_like_raw_secret
    # These are the canonical forms the docs recommend. Must all be accepted.
    for legit in [
        "Bearer {{context.authToken}}",
        "Bearer {{secret:abc-def-123}}",
        "Bearer {{args.customToken}}",
        "{{secret:uuid-here}}",
        "{{context.authToken}}",
    ]:
        assert _looks_like_raw_secret(legit) is False, f"false-positive on {legit!r}"
    # These are actual raw credentials — must still be rejected.
    for bad in [
        "Bearer sk_live_realtoken12345abcdef",
        "sk_live_abc123def456",
        "ghp_abc123xyz",
    ]:
        assert _looks_like_raw_secret(bad) is True, f"false-negative on {bad!r}"


@pytest.mark.asyncio
async def test_configure_output_accepts_canonical_jwt_headers():
    """configure_output must accept the canonical form our docs recommend."""
    client = MagicMock(spec=RoxelsClient)
    client.get_template = AsyncMock(return_value={"id": "t1", "settings": {"outputs": []}})
    client.update_template = AsyncMock(return_value={"id": "t1", "settings": {"outputs": []}})
    client._request = AsyncMock(return_value=[])
    mcp = create_server(client)
    tool = _get_tool(mcp, "configure_output")
    result = json.loads(await tool(
        template_id="t1",
        output_type="webhook",
        config={
            "url": "https://api.example.com/hook",
            "trigger_goal": "g1",
            "headers": {"Authorization": "Bearer {{context.authToken}}"},
        },
    ))
    assert result["status"] == "ok", (
        "configure_output rejected the canonical 'Bearer {{context.authToken}}' "
        "form. _looks_like_raw_secret regression."
    )


@pytest.mark.asyncio
async def test_verify_requires_scope_specific_args():
    """verify should return a crisp error envelope when required args are missing."""
    mcp = create_server(_make_client({"id": "t1", "goals": [], "settings": {}}))
    tool_fn = _get_tool(mcp, "verify")
    result = json.loads(await tool_fn(scope="data_source"))  # missing template_id + source_name
    assert result["status"] == "error"
    assert "source_name" in result.get("error", "") or "template_id" in result.get("error", "")
