"""Static reference constants exposed via MCP tools and resources.

These are the big human-readable reference blobs returned by:
  - get_reference(topic='template')        → TEMPLATE_SCHEMA_REFERENCE
  - get_reference(topic='data_source')     → DATA_SOURCE_REFERENCE
  - get_reference(topic='validation')      → VALIDATION_REFERENCE
  - get_reference(topic='embed')           → EMBED_CONFIG_REFERENCE
  - get_reference(topic='id_resolution')       → ID_RESOLUTION_GUIDANCE
  - get_reference(topic='canonical_spec')   → COMPLETE_TEMPLATE_SPEC

Separating these out keeps server.py focused on tool logic instead of
~1,300 lines of static text. They are plain dicts — mutate with care.
"""
EMBED_JS_URL = "https://app.roxels.ai/embed.js"

# ── Static reference data ──

TEMPLATE_SCHEMA_REFERENCE = {
    "goal_types": {
        "open": "Open-ended conversational goal — the AI explores a topic freely",
        "quantitative": "Extract specific numeric data points",
        "qualitative": "Extract opinions, feelings, subjective assessments",
        "structured": "Extract data matching a defined JSON schema",
        "context_dump": "User provides large amounts of context (docs, processes)",
        "walkthrough": "User walks through a process (often with screen sharing)",
    },
    "goal_fields": {
        "id": "string — unique ID for this goal. Required for goal-aware extraction (enables set_active_goal, onGoalTransition, per-goal understanding events).",
        "type": "string — one of the goal_types above",
        "prompt": "string — what the AI should explore/extract",
        "follow_up_depth": "string | null — how deep to probe",
        "schema": "deprecated — schema now lives on the webhook output (output.config.schema), not on the goal. Use update_webhook_schema or configure_output to set it.",
        "extraction_mode": "string | null — 'cumulative' for full-state snapshots on each event. Default: additive deltas (each event carries only the delta since the last). Before setting this, check whether your backend endpoint clears all existing records before saving (replace-all) or merges new data into existing records (delta). If it clears, set 'cumulative' so each webhook fires a complete snapshot. If it merges, leave this unset.",
        "probing_areas": "string[] | null — specific areas to probe",
    },
    "settings_fields": {
        "language": "string — language code: en, es, pt, fr, de",
        "tone": "string — e.g. 'friendly-professional'",
        "max_session_duration_minutes": "int — default 30",
        "allow_screen_share": "bool — default true",
        "suggest_screen_sharing": "bool — default false",
        "multi_session": "bool — allow multiple sessions per conversation, default true",
        "system_instructions": "string — custom instructions for the Roxels agent",
        "outputs": "array — output configurations (see output_types)",
        "speaker_skills": "string[] — skill UUIDs inlined into the speaker's system prompt (shapes how the conversation flows)",
        "speaker_skillsets": "string[] — skillset UUIDs expanded and inlined into the speaker's system prompt",
        "advisors": "string[] — advisor UUIDs; each advisor runs as one independent observer loop alongside the conversation",
        "skills": "[DEPRECATED — use speaker_skills] string[] — accepted during migration window, translated to speaker_skills automatically",
        "skill_execution_mode": "[DEPRECATED — use speaker_skills/advisors] string — 'observer' or 'inline'; accepted during migration window",
        "data_sources": "array — external lookup endpoints used to resolve free-text user input into structured objects (see configure_data_source and get_reference(topic='data_source'))",
        "embedded": "object — settings for the embedded widget: { skip_join_screen: bool (auto-join without showing the Join button, default true), auto_close: bool (close widget automatically after the conversation completes, default true), fab_anchor: 'viewport'|'container' (where the microphone FAB lives — 'viewport' floats fixed above everything, 'container' anchors inside a client-specified div, default 'viewport') }",
        "integration_shape": (
            "object — NEGOTIATED proposal for how each goal's committed data is delivered. "
            "Roxels drafts a first proposal from the onboarding conversation (see Phase 5 in "
            "backend/app/routes/webhooks.py); the client's coding agent revises it against the "
            "actual codebase via integration_shape(action='revise') and commits via integration_shape(action='confirm'). "
            "Until status='confirmed', check_template surfaces the shape-negotiation step "
            "at the top of its gap list. Shape does not change runtime behavior — it governs what "
            "the MCP validates as 'coverage.' Schema: "
            "{ version: int, status: 'proposed_by_roxels'|'under_revision'|'confirmed', "
            "proposed_by_roxels: <frozen original proposal>, "
            "current: { delivery: 'batch'|'per_goal'|'mixed', surfaces: ['webhook'|'frontend_callback'|'chained_api'], "
            "per_goal_expectations: {<goal_id>: {surfaces: [...], notes: '...'}}, "
            "rationale: '...', open_questions: ['...'] }, "
            "revision_log: [{at, by, reason, diff_keys, previous_snapshot}] }. "
            "Read via integration_shape(action='read'); negotiate via integration_shape(action='revise') + integration_shape(action='confirm')."
        ),
    },
    "schema_field_types": {
        "string": "Plain text value",
        "number": "Numeric value",
        "boolean": "True/false",
        "array": "List of values",
        "array of strings": "List of plain text values",
        "object": "Nested key-value structure",
        "resolved_reference": (
            "Special type — the AI extracts a plain string (e.g. 'Acme Corp'), then code automatically "
            "calls a configured data source to resolve it to a structured object "
            "(e.g. {accountId: 4712, name: 'Acme Corporation'}). Use when your webhook needs structured "
            "IDs that come from an external database. Requires a matching data source in settings.data_sources. "
            "See get_reference(topic='data_source').\n\n"
            "THIS IS TIER 3 of ID RESOLUTION — and the SAFE DEFAULT. For genuinely small, stable, "
            "user-agnostic lists you can step down to Tier 2 or Tier 1. Call get_reference(topic='id_resolution') "
            "for the full decision tree and the 'dropdown paranoia' rule (Tier 1: inline enum for ≤10 "
            "items; Tier 2: context options dict for ~10–100 flat dicts ≤5KB and identical per user; "
            "Tier 3: data source — everything else, including any dropdown/autocomplete/picker surface).\n\n"
            "Field spec options for resolved_reference fields:\n"
            "  data_source: (required) name matching a data source in settings.data_sources\n"
            "  require_resolved: true — blocks commits if this field is still a plain string "
            "(resolution failed). Use when your webhook rejects string values.\n"
            "  required_before_commit: true — blocks commits if the field is missing entirely.\n\n"
            "Note: schema fields do NOT declare DS query params. The conversational agent "
            "calls the data source directly (resolve_id) and passes any params it needs — "
            "e.g. {\"level\": \"metro\"} — as scope at call time. Document what params the "
            "source expects in the data source's `description` field; that text is shown to "
            "the agent verbatim."
        ),
    },
    "output_types": {
        "webhook": {
            "description": (
                "Send structured data to an HTTP endpoint during and after the conversation.\n\n"
                "━━━ READ FIRST — THE THREE PRIMITIVES OF A ROXELS INTEGRATION ━━━\n"
                "A Roxels embed uses exactly three surfaces between the host page and your\n"
                "back end. Understand how they fit together BEFORE configuring any webhook,\n"
                "because the answer to 'where should this behavior live' is almost always\n"
                "one of them:\n\n"
                "  1. EMBED INIT — the host page passes context when Roxels starts:\n"
                "       RoxelsEmbed.init({ templateKey: 'rk_...', authToken: '<JWT>', ... })\n"
                "     The authToken lands in {{context.authToken}} and is available in\n"
                "     every webhook header and url from that session onward. Any other\n"
                "     init values (tenantId, orgId, etc.) land as {{context.<name>}} too.\n\n"
                "  2. WEBHOOKS (this output type) — BACK-END writes. Fire at goal commits\n"
                "     (with trigger_goal set) to POST to your EXISTING back-end endpoints.\n"
                "     Auth: reference the JWT from init:\n"
                "       headers: {\"Authorization\": \"Bearer {{context.authToken}}\"}\n"
                "     Your back end sees the call as if the user made it — same auth,\n"
                "     same authorization, same audit trail. No new trust boundary.\n\n"
                "  3. JS CALLBACKS — FRONTEND reactions. Fire as the conversation progresses.\n"
                "     Wire them in the embed init to drive live UI changes WITHOUT a round-\n"
                "     trip through your back end:\n"
                "       onUnderstanding({data})     — each turn, with the fields the\n"
                "                                      agent just captured. Merge deltas\n"
                "                                      into page state; never replace.\n"
                "                                      Drive live form fills, live\n"
                "                                      previews, live validation.\n"
                "       onGoalTransition({from,to}) — navigate your UI to the step/section\n"
                "                                      that matches the new goal.\n"
                "       onComplete({summary, ...})  — final results, fires 5–15s after\n"
                "                                      session end once server processing\n"
                "                                      finishes. Use webhooks as the\n"
                "                                      reliable server-side fallback for\n"
                "                                      tab-close cases.\n"
                "       onClose, onError            — lifecycle.\n\n"
                "  DIVISION OF LABOR:\n"
                "    • WEBHOOKS  = things your BACK END needs to persist / trigger.\n"
                "    • CALLBACKS = things your PAGE needs to do (update UI, navigate,\n"
                "                  run client-side validation, animate a check mark).\n"
                "  Do not mix. If a goal's effect is 'save to the DB' it's a webhook; if\n"
                "  it's 'check the box in the modal,' it's a callback. Many templates use\n"
                "  both per goal — that's normal and canonical.\n\n"
                "  FRONT-END-FIRST BIAS: prefer callbacks for everything that doesn't\n"
                "  strictly need server-side persistence. Webhooks target EXISTING back-end\n"
                "  endpoints; avoid inventing new ones. Between these three primitives,\n"
                "  almost every integration can be built without new back-end code.\n\n"
                "━━━ AUTHENTICATION — STRONGLY PREFERRED: JWT FROM THE FRONTEND ━━━\n"
                "There are two supported ways to authenticate webhook calls. One is the\n"
                "strongly-preferred default; the other is a fallback for a specific case.\n\n"
                "  [A] DEFAULT — JWT passed from the frontend at embed init.\n"
                "      The host page is already holding a JWT for the logged-in user.\n"
                "      Pass it to Roxels:\n"
                "        RoxelsEmbed.init({ templateKey: 'rk_...', authToken: '<that JWT>' })\n"
                "      Reference it in every webhook that needs the user's identity:\n"
                "        headers: {\"Authorization\": \"Bearer {{context.authToken}}\"}\n"
                "      Why this is the default (and why 'strongly preferred' is not a polite\n"
                "      suggestion — it's architecturally better):\n"
                "        • Zero credential provisioning. The token the user already has\n"
                "          is reused; nothing to mint, store, or rotate on either side.\n"
                "        • User-scoped. Roxels calls your back end AS THE USER, so your\n"
                "          existing authorization middleware and audit trails just work.\n"
                "          No 'service account' layer to reason about.\n"
                "        • Ephemeral. Scope and expiry match the user's existing session.\n"
                "        • Works for both reads (data sources hitting your API) and writes\n"
                "          (webhooks posting to your API).\n\n"
                "  [B] FALLBACK — API key / service credential stored via secrets manager.\n"
                "      ONLY when the webhook represents a system action that is NOT tied\n"
                "      to a user session (admin pipelines, system notifications with no\n"
                "      user principal, third-party APIs like Stripe that need a service\n"
                "      key). Procedure:\n"
                "        1. store_secret(name='<descriptive>')  →  returns secret ref\n"
                "        2. Reference it in the header:\n"
                "             headers: {\"Authorization\": \"Bearer {{secret:sec_xxx}}\"}\n"
                "      Trade-offs vs [A]:\n"
                "        • Requires provisioning and rotation of a long-lived credential.\n"
                "        • Back end sees the call as 'service,' not as the user — you\n"
                "          lose per-user authorization and audit granularity.\n"
                "        • Adds a new trust boundary to reason about.\n\n"
                "  NEVER pass raw token values in headers. The API detects and rejects\n"
                "  them. If you're tempted, you almost certainly want path [A].\n\n"
                "━━━ PER-GOAL vs END-OF-SESSION — HOW TO CHOOSE ━━━\n"
                "  DEFAULT: ONE WEBHOOK PER GOAL. Configure one webhook output per goal, each with "
                "`trigger_goal` set to that goal's id. The webhook fires at commit time — the moment "
                "the agent captures that goal's data — giving you:\n"
                "    (a) Progressive delivery. Your back end receives data as it's captured, not only "
                "at the end of the conversation.\n"
                "    (b) Drop-off resilience. If the user leaves mid-session, already-committed goals "
                "are still delivered to your back end.\n"
                "    (c) Sequential flows. response_capture lets an earlier goal's webhook response "
                "feed the next goal's webhook body via {{context.*}}.\n"
                "    (d) Per-endpoint tuning. Each goal can have its own URL, schema, headers, "
                "commit_policy, invariants, and extraction_mode (cumulative vs delta).\n"
                "    (e) Faster UI feedback. JS callbacks and downstream views react to each commit "
                "immediately rather than after the whole session completes.\n"
                "  USE A SINGLE END-OF-SESSION WEBHOOK (no trigger_goal) ONLY WHEN: (i) the receiver "
                "genuinely needs one combined payload (e.g. 'save the final transcript/summary'), or "
                "(ii) the needed data is a cross-goal composition no individual goal can produce on "
                "its own. When in doubt, default to per-goal — it is strictly more general, and you "
                "can always compose goals server-side on receive.\n"
                "  REFUSE the shape 'one webhook at the end with a big blob of everything' unless the "
                "user's back end explicitly demands it. Per-goal is the canonical Roxels pattern.\n\n"
                "RETRY LOOP: commit-path webhooks (trigger_goal) run through a built-in retry loop "
                "(up to 3 attempts). On a 4xx response with a body, the platform reads the error and "
                "rewrites the payload via LLM before retrying — so misconfigured field names or missing "
                "required fields are often self-corrected without any manual intervention. "
                "Auth failures (401, 403) and 404s are immediately fatal and not retried.\n\n"
                "LEARNINGS: after each terminal outcome (success or give-up) the platform synthesizes "
                "do/don't rules from the observation and stores them on the template. These rules are "
                "automatically injected into attempt 1 of every future session — so a payload error that "
                "triggered a retry in session N is fixed before the first attempt in session N+1. "
                "Call get_runtime_learnings to see what has been learned and suggested_actions to bake "
                "rules into the template config permanently."
            ),
            "config": {
                "url": "string — webhook endpoint URL. Supports {{context.fieldName}} interpolation from per-session context. Must use HTTPS in production.",
                "method": "string — HTTP method. Default: 'POST'. Override for PATCH, PUT, DELETE, GET as needed by the target API.",
                "headers": "object — HTTP headers for auth, API versioning, etc. Values support {{context.fieldName}} interpolation (e.g. {\"Authorization\": \"Bearer {{context.authToken}}\"}).\n\nDo NOT set Content-Type here — set body_encoding instead. Content-Type is derived automatically from body_encoding and setting it manually without body_encoding will cause a mismatch (your body will be JSON but the header will claim form-encoded, and the server will reject it).",
                "body_encoding": (
                    "string — how the request body is serialized. Default: 'json'.\n"
                    "  'json'        — application/json (default, most modern APIs)\n"
                    "  'form'        — application/x-www-form-urlencoded, standard flat encoding\n"
                    "  'form-nested' — application/x-www-form-urlencoded, bracket notation for nested structures\n"
                    "                  (e.g. Stripe, Twilio: {items: [{price: 'x'}]} → items[0][price]=x)\n\n"
                    "Setting body_encoding automatically sets the correct Content-Type header — you never need to set Content-Type manually.\n\n"
                    "If you set Content-Type: application/x-www-form-urlencoded in headers without body_encoding, the encoding is inferred automatically (body will be form-encoded to match). But the recommended approach is to set body_encoding and leave Content-Type out of headers entirely."
                ),
                "schema": (
                    "object — extraction schema. Two forms are supported:\n\n"
                    "  FIELD-MAP (usual):  {field: 'type'}  or  {field: {type: '...', description: 'hint'}}\n"
                    "    Commits as an object: {field1: value1, field2: value2, ...}.\n"
                    "    With raw_payload=true this POSTs {field1: ..., field2: ...} (object body).\n\n"
                    "  TOP-LEVEL ARRAY:  {type: 'array', item_schema: {...}, description: '...'}\n"
                    "    Commits as an array: [{...}, {...}, ...].\n"
                    "    With raw_payload=true this POSTs a BARE JSON ARRAY as the body — use this\n"
                    "    when the target endpoint expects `[...]` and NOT `{key: [...]}` (Django DRF\n"
                    "    bulk-create views, Stripe-style collection APIs, etc.). The description\n"
                    "    should explicitly say 'This is a top-level array, NOT wrapped in an object'\n"
                    "    so the extraction model picks up the shape.\n\n"
                    "Valid field types (inside item_schema or a field-map): string, number, boolean, "
                    "array, array of strings, object, resolved_reference. Use resolved_reference when "
                    "the field needs a live lookup against an external API (e.g. account IDs, product "
                    "SKUs) — requires a matching entry in settings.data_sources. See get_reference(topic='data_source').\n\n"
                    "NOTE: The extraction model uses schema field descriptions for formatting, NOT "
                    "system_instructions."
                ),
                "streaming": "bool — if true, fires real-time events during the conversation",
                "trigger_goal": "string | null — the GOAL ID whose commit fires this webhook. Read as 'on commit of goal X, fire this webhook', NOT 'the goal that happens to have triggered this webhook record' — direction matters. Enables per-goal webhook routing (commit-path webhook). If this webhook has response_capture configured, the commit endpoint awaits the POST before returning — ensuring captured IDs are in context before the agent moves to the next goal.",
                "raw_payload": (
                    "bool — if true, sends just the extracted goal data as the payload instead of the "
                    "default envelope ({event, data, interview_id, timestamp}). Use when POSTing directly "
                    "to APIs that expect a specific shape.\n\n"
                    "Body shape depends on the webhook schema:\n"
                    "  field-map schema        →  object body, e.g. {routes: [...]}\n"
                    "  top-level array schema  →  BARE JSON ARRAY body, e.g. [{unitTypeId: 5, quantity: 3}, ...]\n"
                    "See the `schema` field above for the top-level array form."
                ),
                "response_capture": (
                    "object | null — after a successful POST, extract fields from the JSON response and merge them into the session's working context. "
                    "Keys are context variable names; values are dot-path selectors into the response JSON.\n\n"
                    "Selector syntax:\n"
                    "  'id'              — top-level field\n"
                    "  'data.customer.id' — nested field\n"
                    "  'items[0].price_id' — array index + nested field\n"
                    "  '$'               — entire response root\n\n"
                    "Example: {\"stripe_product_id\": \"id\", \"stripe_price_id\": \"default_price\"}\n"
                    "After capture, {{context.stripe_product_id}} is available in any later webhook's url, headers, or body_template.\n\n"
                    "IMPORTANT: When response_capture is set, the commit endpoint awaits this webhook's response before returning. "
                    "This ensures captured IDs are available in context before the agent fires the next goal's webhook. "
                    "Use this for sequential external API flows (e.g. Stripe: create product → capture ID → create price using that ID)."
                ),
                "body_template": (
                    "object | array | null — when set, this value is sent as the POST body instead of the auto-built envelope or raw_payload. "
                    "All string values (at any depth) are interpolated with {{context.fieldName}} placeholders.\n\n"
                    "Shape:\n"
                    "  Object body:       {\"product\": \"{{context.stripe_product_id}}\", \"amount\": \"{{context.unit_amount}}\"}\n"
                    "  Bare-array body:   [{\"unitTypeId\": \"{{context.unit_id}}\", \"quantity\": \"{{context.qty}}\"}]\n"
                    "Use the array form when the target endpoint expects `[...]` and not `{key: [...]}`. \n"
                    "Prefer raw_payload + a top-level array schema when the array CONTENT comes from a\n"
                    "goal's own extraction; use body_template with an array when you need to compose\n"
                    "it from {{context.*}} sources (e.g. fields captured by earlier webhooks).\n\n"
                    "Available {{context.x}} sources (in order of merge):\n"
                    "  1. Embed-init context provided when the session was created (e.g. auth tokens, tenant IDs)\n"
                    "  2. Fields captured via response_capture from earlier webhooks in the flow\n"
                    "  3. Fields extracted from the CURRENT goal's commit — every key in the webhook schema is auto-merged into\n"
                    "     context at commit time and is available in this same goal's body_template. Example: a goal that\n"
                    "     extracts {unit_amount, currency, interval} can reference {{context.unit_amount}} in its own webhook body.\n\n"
                    "Use body_template when you need precise control over the payload shape — especially in sequential webhook flows "
                    "where earlier goals/webhooks produced values this webhook needs in its body."
                ),
            },
            "info_to_gather_before_configuring": (
                "Before you call configure_output for a webhook, you must UNDERSTAND the target "
                "endpoint. A webhook configured from assumptions is a webhook that fails silently in "
                "production. Answer every question below — ask the user, read the codebase, read the "
                "API docs, or call the endpoint directly — then record what you learn on the webhook "
                "config using the storage mechanism listed next to each question.\n\n"
                "  1. HTTP METHOD — POST / PATCH / PUT / DELETE / GET?\n"
                "       STORE ON: config.method (default 'POST').\n"
                "  2. AUTHENTICATION — Bearer token, API key header, Basic auth, session cookie?\n"
                "       Is the credential per-user-session (comes in via embed-init context) or\n"
                "       per-org/service-wide (long-lived secret)?\n"
                "       STORE ON: config.headers, using {{context.authToken}} for session-scoped\n"
                "       auth or {{secret:ref}} for long-lived secrets (call store_secret first).\n"
                "  3. BODY ENCODING — JSON, form-urlencoded, form-nested (Stripe/Twilio style)?\n"
                "       STORE ON: config.body_encoding. NEVER set Content-Type in headers manually.\n"
                "  4. REQUEST PAYLOAD SHAPE — exact field names, types, nesting, required fields, AND\n"
                "       whether the body is an OBJECT {...} or a BARE ARRAY [...]. Do not skip the\n"
                "       array check — many APIs (Django DRF bulk views, some Stripe endpoints) expect\n"
                "       bare arrays and will 4xx anything wrapped.\n"
                "       STORE ON: config.schema (field-map for object body, or\n"
                "       {type:'array', item_schema:..., description:...} for bare array) paired with\n"
                "       raw_payload: true; or config.body_template (object OR list — list sends bare\n"
                "       array body) for precise payload composition using {{context.*}}.\n"
                "       If a field needs to be a structured object from a data source, declare it as\n"
                "       a resolved_reference in the schema AND configure the data source.\n"
                "  5. REQUIRED FIELDS — which inputs will the endpoint reject as missing?\n"
                "       STORE ON: commit_policy + invariants on the webhook (via\n"
                "       update_goal_commit_rules). Use 'require_all_required' + required_before_commit\n"
                "       invariants so the agent keeps probing until the field is captured.\n"
                "  6. RESPONSE SHAPE — what does success return? Does it include an ID or handle a\n"
                "       later goal's webhook will need?\n"
                "       STORE ON: config.response_capture (dot-paths into the response JSON) so IDs\n"
                "       land in {{context.*}} for downstream body_templates.\n"
                "  7. WRITE SEMANTICS — does the endpoint REPLACE all existing records per call, or\n"
                "       MERGE/APPEND? (Matters because Roxels defaults to delta streaming.)\n"
                "       STORE ON: goal.extraction_mode = 'cumulative' if the endpoint is replace-all,\n"
                "       leave unset for merge/append endpoints.\n"
                "  8. ERROR CODES — what do 4xx/5xx responses look like? Any special meanings\n"
                "       (409 = duplicate, 429 = rate-limit, 422 = validation)?\n"
                "       Auth failures (401, 403) are fatal-no-retry; 4xx-with-body triggers LLM\n"
                "       payload rewrite + retry. Knowing the error envelope lets you anticipate\n"
                "       rewrite behavior.\n"
                "  9. IDEMPOTENCY — is the endpoint safe to retry? Is there a dedupe key field?\n"
                "       If not idempotent, add the dedupe key to the schema and ensure it's populated\n"
                "       from a stable source (e.g. session id, a captured ID).\n"
                " 10. RATE LIMITS — any hard caps you need to stay under?\n\n"
                "If the user does not know an answer, ASK THEM. If they cannot provide it, make the\n"
                "best assumption, document it in the config's schema field descriptions, and call\n"
                "send_http_request to validate against reality. Never configure and move on silently."
            ),
            "setup_checklist": (
                "Before saving a webhook output, verify:\n"
                "  1. Method — does the target API expect POST, or something else (PATCH/PUT/DELETE/GET)?\n"
                "  2. Auth — did you add the required header (Bearer token, API key, Basic auth)?\n"
                "     Auth failures (401, 403) are immediately fatal — not retried. Get auth right first.\n"
                "  3. Body encoding — set body_encoding, not Content-Type. Most modern APIs: 'json' (default).\n"
                "     Stripe, Twilio, legacy APIs: 'form' (flat) or 'form-nested' (bracket notation).\n"
                "     NEVER set Content-Type in headers — body_encoding sets it automatically and they must match.\n"
                "  4. Body shape — does your body_template or schema match exactly what the API expects?\n"
                "     Check required fields, nesting depth, and field names against the API docs.\n"
                "     Note: 4xx errors with a body trigger automatic LLM rewrite + retry (up to 3 attempts),\n"
                "     but it's always better to get the shape right upfront than to rely on retry correction.\n"
                "  5. Response capture — if a later goal's webhook needs IDs from this response,\n"
                "     add response_capture now. Pair it with body_template on the downstream webhook.\n"
                "     See sequential_flow_hint for the full chained-webhook pattern.\n"
                "  6. Test it — call send_http_request with a sample payload to confirm the endpoint accepts\n"
                "     the request as configured. Read the response body to catch auth errors, wrong\n"
                "     content-type, missing required fields, etc. before the template goes live.\n"
                "  7. Run check_template(template_id) AFTER every update_template and configure_output call.\n"
                "     It surfaces gaps the coding agent cannot see from the config alone — orphaned\n"
                "     trigger_goals, missing schemas, required fields not declared, extraction_mode\n"
                "     drift, etc. Treat it as the convergence loop: configure → diagnose → fill gap\n"
                "     → repeat until it returns 'healthy'.\n"
                "     CRITICAL REPLACEMENT RULES: goals and settings are replaced WHOLESALE when passed\n"
                "     to update_template — omitted goals are deleted, omitted settings keys are wiped.\n"
                "     Webhook output schemas are the ONLY thing auto-preserved. For partial settings\n"
                "     changes: get_template → merge → pass full merged object.\n"
                "  8. After live sessions — call get_runtime_learnings to see synthesized do/don't rules\n"
                "     and apply suggested_actions to bake lessons into the template permanently."
            ),
            "sequential_flow_hint": (
                "Webhooks on the same goal fire in declaration order. If an earlier webhook has "
                "response_capture configured, its captured fields are available in the body_template "
                "of later webhooks on the same goal — use {{context.captured_key}} to reference them. "
                "This works within a single goal commit and across goals. "
                "To set up a chained flow: configure response_capture on the earlier webhook output "
                "and body_template (with {{context.captured_key}}) on the downstream webhook."
            ),
        },
        "structured": {
            "description": "Extract structured JSON matching a schema (stored in conversation results). At commit time a dedicated Commit Author LLM reads each schema field's `description` text to decide which resolved value goes where, and each data source's `description` text to understand what the resolved `type` values mean. Rich descriptions are load-bearing for commit reliability — not just human documentation.",
            "config": {
                "schema": (
                    "object — extraction schema. Same two forms as webhook output schemas: "
                    "field-map {field: 'type'} (commits as object) or top-level array "
                    "{type: 'array', item_schema: {...}, description: '...'} (commits as array). "
                    "See output_types.webhook.config.schema for the full reference."
                ),
            },
        },
        "report": {
            "description": "Generate a written report summarizing the conversation",
            "config": {},
        },
        "email": {
            "description": "Send conversation results via email",
            "config": {
                "to": "string — recipient email",
                "subject_template": "string — email subject",
            },
        },
        "excel": {
            "description": "Generate an Excel file with extracted data mapped to cells",
            "config": {
                "schema": "object — field names to types",
                "cell_mapping": "object — maps field names to Excel cell references",
            },
        },
    },
}

DATA_SOURCE_REFERENCE = {
    "concept": (
        "Data sources solve a specific problem: your webhook needs structured objects (IDs, typed records), "
        "but users speak in natural language ('Acme Corp', 'downtown branch', 'SKU-4872'). "
        "Without data sources the webhook receives the raw string. "
        "With data sources the agent calls your external lookup API in real time and replaces "
        "the string with the structured object your backend expects.\n\n"
        "Example:\n"
        "  Without: user says 'Acme Corp'  →  webhook receives 'Acme Corp'\n"
        "  With:    user says 'Acme Corp'  →  webhook receives {\"accountId\": 4712, \"name\": \"Acme Corporation\", \"tier\": \"enterprise\"}"
    ),
    "when_to_use": (
        "Only when ALL of these are true:\n"
        "1. Your webhook receiver needs a structured object (not just a string)\n"
        "2. That object requires a live lookup against an external database\n"
        "3. The database is too large to pass as session context (hundreds+ of entries)\n\n"
        "Good use cases: customer/account IDs, product catalog SKUs, geographic locations, "
        "any canonical entity the user names but your system needs an ID for.\n\n"
        "Not needed for: plain strings, numbers, booleans, small enum lists (use context instead), "
        "or fields where the user's exact phrasing is what you want."
    ),
    "how_it_works": [
        "1. The AI extracts the user's phrasing as a plain string ('Acme Corp')",
        "2. Code detects the field is typed 'resolved_reference' in the goal schema",
        "3. An LLM generates 2-3 search query variations from the phrase (handles typos, abbreviations). "
           "Synthesized do/don't rules from past sessions are automatically injected here.",
        "4. All queries fire in parallel against your data source endpoint",
        "5. Results are deduplicated by id and a second LLM call picks the best match",
        "6. If confident: the string is replaced with the structured object before the webhook fires",
        "7. If ambiguous: the agent asks the user to clarify, then retries",
        "8. If no results: the field retains the original string; webhook still fires",
    ],
    "config_shape": {
        "_overview": (
            "A data source has two layers:\n"
            "  - request: HOW to make the HTTP call (URL, auth, query params)\n"
            "  - Metadata: WHAT to do with the result (description, examples, output_schema, cache_key_fields, relaxable_params)\n\n"
            "The request block uses a typed params list so the engine knows exactly what to send — "
            "no prose-only contracts that only the LLM can read."
        ),
        "name": "string — unique identifier. Referenced by goal schema fields via 'data_source': 'name'",
        "type": "string — discriminator. Currently only 'api_call' is implemented. Omit to default to 'api_call'.",
        "request": {
            "_overview": "Describes the HTTP call the engine will make for each resolution attempt.",
            "method": "string — HTTP method. Default 'GET'.",
            "url": "string — endpoint URL. Supports {{context.X}} interpolation.",
            "auth": {
                "type": "string — only 'bearer' currently supported",
                "token": "string — token value. Supports {{context.X}} interpolation.",
            },
            "params": (
                "array — DECLARE EVERY QUERY PARAM THE API USES HERE. Each entry:\n"
                "  name        (string)  — query param name as the API expects it\n"
                "  in          (string)  — 'query' | 'header' | 'path' | 'body'\n"
                "  value_from  (string)  — where the value comes from:\n"
                "                           'phrase'  — the user's free-text phrase (search string)\n"
                "                           'args'    — per-call value supplied by the agent via resolve_id(args={...})\n"
                "                           'context' — from session context ({{context.X}})\n"
                "                           'literal' — hardcoded constant; provide a 'value' key\n"
                "  required    (boolean) — if true and value_from='args' but args not provided, engine\n"
                "                         refuses the call and tells the agent to retry with resolve_id(args={...})\n"
                "  type        (string)  — optional: 'enum' | 'string' | 'integer'\n"
                "  values      (array)   — REQUIRED when type='enum'. Lists valid values the agent can pick from.\n"
                "  description (string)  — REQUIRED when value_from='args'. Rendered into the agent's tool\n"
                "                         prompt so it knows what value to supply. Without this, the agent\n"
                "                         cannot make an informed choice and will guess or omit the param.\n"
                "  value       (any)     — REQUIRED when value_from='literal'. The hardcoded constant."
            ),
        },
        "description": (
            "string — STRONGLY RECOMMENDED. Plain-English description of what the endpoint contains "
            "and what search terms it accepts. Injected into the query-generation prompt. "
            "Example: 'Company account directory — search by legal name, DBA name, or ticker symbol.'"
        ),
        "examples": (
            "array — STRONGLY RECOMMENDED. Few-shot phrase → expected result mappings. "
            "Each entry: {\"phrase\": \"<user phrasing>\", \"expected_result\": {<object>}}. "
            "Include 2-5 examples covering common phrasings, abbreviations, and ambiguous cases."
        ),
        "canonicalization_rules": (
            "string — RECOMMENDED when ambiguity is predictable. Plain-English tie-breaking rules "
            "injected into the disambiguation prompt verbatim."
        ),
        "cache_key_fields": (
            "array of strings — REQUIRED when an args param changes which object is returned for the "
            "same phrase. Include every param name whose value should be part of the cache key. "
            "Without this, a phrase resolved with level=metro is returned from cache for level=state. "
            "Example: [\"level\"]"
        ),
        "relaxable_params": (
            "array of strings — param names that are safe to drop on a 0-results retry. "
            "The engine re-runs without these to widen the search. "
            "NEVER include tenancy/auth params. Only domain-narrowing filters like 'type', 'level'. "
            "Example: [\"level\"]"
        ),
        "output_schema": {
            "template": (
                "object — TRANSFORMATION MAP applied to each raw API result. NOT a JSON Schema. "
                "Keys are your webhook field names; values are:\n"
                "  '<api_field>'       — picks result['api_field']\n"
                "  '<nested.field>'    — picks result['nested']['field']\n"
                "  '<$params.name>'    — picks the request param value (e.g. level you sent)\n"
                "  literal value       — passes through as-is\n\n"
                "Example: {\"id\": \"<id>\", \"kind\": \"<$params.level>\", \"label\": \"<verbose_name>\"}\n"
                "Omit to pass the raw API result through unchanged."
            ),
        },
    },
    "substitution_vocabulary": {
        "_note": "Tokens you can use in request.url, auth.token, and param values:",
        "{{context.X}}": "Value from per-session context (prior webhook response_capture, session vars like authToken)",
        "{{args.X}}": "Per-call arg supplied by the agent via resolve_id(args={...}) — only valid for value_from='args' params",
        "{{phrase}}": "The user's free-text phrase — used internally as the search string",
        "{{secret:id}}": "Org secret by ID — existing mechanism, unchanged",
    },
    "field_spec": {
        "type": "'resolved_reference' — marks this field for data source resolution.",
        "data_source": "string — must exactly match a name in settings.data_sources",
        "require_resolved": "boolean — if true, blocks commit if the field is still a plain string",
        "_note": (
            "Schema fields do NOT declare query params — that belongs in the data source's request.params. "
            "The agent uses resolve_id(source, phrase, args={...}) at call time. "
            "Args-sourced params (like level, category) are surfaced to the agent from the declared params list "
            "— the agent reads type/values/description and picks the right value per phrase."
        ),
    },
    "array_of_resolved_references": {
        "description": (
            "Use item_type='resolved_reference' on an array field when each item should BE a resolved "
            "object (not a wrapper). data_source goes on the array field directly, not inside item_schema."
        ),
        "schema_example": {
            "destinations": {
                "type": "array",
                "item_type": "resolved_reference",
                "data_source": "location_search",
                "require_resolved": True,
            }
        },
        "produces": [{"id": 1, "type": "metro", "label": "Ciudad de México"}, {"id": 7, "type": "state", "label": "Jalisco"}],
    },
    "full_examples": {
        "simple_api_no_args_param": {
            "_description": "Simple account lookup — only a phrase param. No per-call args needed.",
            "configure_data_source_call": {
                "name": "account_lookup",
                "endpoint_url": "https://api.example.com/v1/accounts/search",
                "auth_type": "bearer",
                "auth_token": "{{context.authToken}}",
                "params": [
                    {"name": "search", "in": "query", "value_from": "phrase", "required": True}
                ],
                "description": "Company account directory — search by legal name, DBA name, or ticker symbol.",
                "examples": [
                    {"phrase": "Acme", "expected_result": {"id": 42, "name": "Acme Corporation"}},
                    {"phrase": "IBM", "expected_result": {"id": 7, "name": "International Business Machines"}},
                ],
                "output_template": {"accountId": "<id>", "name": "<display_name>", "tier": "<account_tier>"},
            },
            "goal_schema_field": {
                "account": {"type": "resolved_reference", "data_source": "account_lookup", "require_resolved": True}
            },
        },
        "complex_api_with_args_param": {
            "_description": (
                "Geographic location search with a required 'level' scope param. "
                "The API requires level=metro|state|municipality on every call. "
                "Declare it as value_from='args' so the agent supplies it per-phrase via resolve_id(args={'level': '...'})."
            ),
            "configure_data_source_call": {
                "name": "location_search",
                "endpoint_url": "https://api.example.com/v1/location-modal/",
                "auth_type": "bearer",
                "auth_token": "{{context.authToken}}",
                "params": [
                    {"name": "search", "in": "query", "value_from": "phrase", "required": True},
                    {
                        "name": "level",
                        "in": "query",
                        "value_from": "args",
                        "required": True,
                        "type": "enum",
                        "values": ["metro", "state", "municipality"],
                        "description": (
                            "Geographic scope. metro for cities/metro areas (most common default), "
                            "state for full states, municipality for specific municipalities. "
                            "Use world knowledge to pick the right scope for the place the user named."
                        ),
                    },
                ],
                "description": (
                    "Geographic locations in Mexico. Returns metros, states, or municipalities depending on level. "
                    "verbose_name is always present and is the safe display/match field."
                ),
                "examples": [
                    {"phrase": "Ciudad de México", "expected_result": {"id": 1, "verbose_name": "Ciudad de México"}, "level": "metro"},
                    {"phrase": "Jalisco", "expected_result": {"id": 14, "verbose_name": "Jalisco"}, "level": "state"},
                ],
                "cache_key_fields": ["level"],
                "relaxable_params": ["level"],
                "output_template": {"id": "<id>", "type": "<$params.level>", "label": "<verbose_name>"},
            },
            "agent_behavior": (
                "When the agent encounters an unresolved location, it calls:\n"
                "  resolve_id('location_search', 'Ciudad de México', args={\"level\": \"metro\"})\n"
                "The engine validates that 'level' is in args (required=True), then fires:\n"
                "  GET /location-modal/?search=Ciudad+de+México&level=metro\n"
                "A 400 error ('level parameter is required') will NOT happen because the param is declared."
            ),
            "_key_insight": (
                "Without declaring 'level' in params, the agent reads prose in 'description' and may or "
                "may not pass it. With the declaration, the engine enforces it and the agent sees the "
                "type/values/description in its tool prompt — no guessing, no silent 400s."
            ),
        },
    },
    "common_mistakes": [
        "1. PROSE-ONLY REQUIRED PARAMS — documenting 'always pass level' only in the description string. "
           "The engine doesn't read prose; only the LLM speaker does. Declare it in request.params with "
           "value_from='args', required=True, and a description. The engine then enforces it.",
        "2. WRONG type on field — using a text description instead of type='resolved_reference'. The lookup never triggers.",
        "3. WRONG output_template — writing a JSON Schema {\"type\": \"array\", \"description\": \"...\"}. "
           "That form is silently ignored. Use a transformation map {\"field\": \"<api_key>\"}.",
        "4. MISSING item_schema for arrays — putting resolved_reference fields under 'items' instead of 'item_schema'. "
           "The resolver only walks item_schema.",
        "5. MISSING description on args param — declared value_from='args' but no description. "
           "The agent has no basis for picking a value and will omit or guess it.",
        "6. MISSING values on enum args param — declared type='enum' but no values list. "
           "The agent cannot enumerate valid choices and picks arbitrarily.",
        "7. MISSING cache_key_fields when args param varies results — same phrase resolves differently "
           "for different arg values. Without cache_key_fields, first resolution is returned from cache for all.",
        "8. MISSING examples — without few-shot examples the query generator uses generic variations "
           "and the candidate picker has no precedent. Include 2-5 examples per source.",
        "9. MISSING require_resolved — resolved_reference fields can commit as plain strings if resolution fails. "
           "Set require_resolved: true on fields where your webhook needs a structured object.",
        "10. SOURCE NOT REGISTERED — referencing data_source='name' in a field spec without calling "
            "configure_data_source first. Resolution silently skips unknown source names.",
    ],
    "setup_steps": [
        "0. Read your endpoint docs or implementation. Verify exact field names returned per param value, "
           "which params are required vs. optional, and what the response looks like for edge cases. "
           "Do not write output_schema.template until you've seen a real response.",
        "1. Call configure_data_source with request.params declaring every query param the API uses "
           "(including required args params). Add description, examples, canonicalization_rules, "
           "cache_key_fields, relaxable_params.",
        "2. Call probe_data_source to verify auth and response shape. For args params, pass them via "
           "the args= argument: probe_data_source(..., args={'level': 'metro'}).",
        "3. Call update_webhook_schema with your webhook schema. For each resolved_reference field, "
           "include require_resolved: true if the webhook needs a structured object.",
        "4. Call update_goal_commit_rules to set commit_policy and invariants per goal.",
        "5. Call check_template to get a reliability checklist.",
        "6. Run a test conversation and check the webhook payload for resolved objects.",
    ],
}

VALIDATION_REFERENCE = {
    "concept": (
        "Layer 2 validation rules are template-level hard constraints that block a commit from firing "
        "if the extracted data doesn't meet the rules. They are expressed as data on the template "
        "(not as prose in system_instructions), so the code enforces them deterministically.\n\n"
        "All rules are opt-in and additive: a template without any validation rules behaves exactly "
        "as before. Rules only activate when explicitly set. Start with require_resolved on any "
        "resolved_reference field that must be a structured object when it reaches your webhook."
    ),
    "field_level_rules": {
        "require_resolved": (
            "boolean — set true on a resolved_reference field (or array with item_type='resolved_reference') "
            "to block the commit if that field is still a plain string (i.e., data source resolution failed or "
            "was ambiguous and the user didn't clarify). "
            "Without this, a field can commit as a raw string like 'Acme Corp' when the lookup "
            "found two candidates and never resolved. Your webhook would receive a string instead of "
            "the expected structured object.\n\n"
            "Set this on EVERY resolved_reference field whose webhook receiver expects an object. "
            "Example field spec:\n"
            "  {\"supplier\": {\"type\": \"resolved_reference\", \"data_source\": \"supplier_lookup\", "
            "\"require_resolved\": true}}"
        ),
        "required_before_commit": (
            "boolean — set true on any field (any type) that must be non-empty before committing. "
            "Blocks commits where the field is null, empty string, or empty list. "
            "Use for fields that are mandatory inputs to your webhook (required form fields). "
            "Example: {\"carrier_name\": {\"type\": \"string\", \"required_before_commit\": true}}"
        ),
    },
    "goal_level_rules": {
        "commit_policy": (
            "string — controls when the commit fires. One of:\n"
            "  'auto'               — default. Commits fire automatically after each extraction turn. "
            "No explicit user confirmation required.\n"
            "  'require_all_required' — auto-commits fire only when all required_before_commit fields "
            "are satisfied. User-confirmed commits always fire validation.\n"
            "  'human_confirm'      — auto-commits are suppressed entirely. Commit only fires when the "
            "user explicitly confirms via the two-phase propose → confirm flow.\n\n"
            "Set on the linked webhook output's config (not on the goal object or inside the schema). "
            "Example: webhook output config {\"trigger_goal\": \"save_route\", \"commit_policy\": \"require_all_required\", \"schema\": {...}}. "
            "Call update_goal_commit_rules to configure."
        ),
        "invariants": (
            "array — cross-field rules with multiple kinds.\n\n"
            "KIND 1: shape-match (default when 'kind' is omitted) — [{\"when\": {<field_path>: <value>}, \"then\": {<field_path>: <value>}}]. "
            "If the 'when' subset matches the committed payload, the 'then' subset must also hold. "
            "If it doesn't, the commit is blocked.\n\n"
            "KIND 2: type_agreement — declares that a set of resolved_reference fields "
            "must all agree on a key (default '.type'). Useful when multiple resolved fields point to "
            "the same data source and should logically resolve to the same category/level. Shape: "
            "{\"kind\": \"type_agreement\", \"paths\": [<json_path>, <json_path>, ...], \"key\": \"type\"}. "
            "Paths may use [*] and the validator groups resolved refs by their array context so each "
            "group is checked independently. Example for a routes-style goal: "
            "{\"kind\": \"type_agreement\", \"paths\": [\"routes[*].origin\", \"routes[*].destinations[*]\"], \"key\": \"type\"} "
            "— for each route item, origin.type and every destinations[i].type must be equal; otherwise the "
            "commit is blocked with a clear violation message. If the invariant is omitted the check simply "
            "does not run — it is opt-in and safe to leave off.\n\n"
            "FLAT OBJECT SCHEMAS — use dot-notation for nested fields:\n"
            "  [{\"when\": {\"order.status\": \"shipped\"}, \"then\": {\"order.tracking_id\": \"required\"}}]\n\n"
            "ARRAY SCHEMAS — when the goal schema produces an array of items (e.g., an orders array "
            "where each item has a category, product, and quantity), use [*] to express per-item rules. "
            "[*] means 'for each item in this array at the same index'. Both the 'when' and 'then' "
            "paths must reference the same array with [*]:\n"
            "  [{\"when\": {\"items[*].category\": \"hardware\"}, \"then\": {\"items[*].product.type\": \"hardware\"}}]\n"
            "This checks: for each item at index i, if items[i].category == 'hardware' then "
            "items[i].product.type must also be 'hardware'.\n\n"
            "LIMITATIONS:\n"
            "  - [*] may appear at most once per path (no nested array traversal)\n"
            "  - [*] in 'when' and 'then' must reference the same array key\n"
            "  - Mix of flat and [*] paths in the same invariant is not supported\n\n"
            "Set on the linked webhook output's config alongside commit_policy. "
            "Call update_goal_commit_rules to configure."
        ),
    },
    "how_it_works": [
        "1. commit fires → before sending to backend, _validate_commit_data() walks the snapshot",
        "2. For each field spec with require_resolved=true: if the value is still a string, it's a violation",
        "3. For each field spec with required_before_commit=true: if the value is empty, it's a violation",
        "4. For each invariant: if 'when' matches the snapshot, 'then' must also match (supports [*] for arrays)",
        "5. If any violations: a self-correction pass runs automatically before routing to the user:",
        "   Step A — re-resolve unresolved DS fields (re-triggers the full DS lookup for plain-string values)",
        "   Step B — LLM correction call: given transcript + current snapshot + violations, produce a corrected snapshot",
        "   If self-correction passes re-validation, the corrected snapshot commits without user involvement.",
        "6. If self-correction cannot fix the violations: commit is blocked, agent asks user for clarification.",
        "7. Once all violations are cleared, the commit fires normally.",
    ],
    "common_mistakes": [
        "Using flat dot-notation invariants on array-typed goals — use [*] syntax: "
        "{'when': {'items[*].category': 'hardware'}, 'then': {'items[*].product.type': 'hardware'}}",
        "Putting [*] in 'when' but not in 'then' (or vice versa) — both sides must use [*] for the same array",
        "Expecting invariants to fire when 'when' conditions don't match — if 'when' doesn't match, the 'then' block is not checked (no violation)",
    ],
    "setup_with_mcp": (
        "To set validation rules on a template:\n"
        "  1. Call update_webhook_schema with require_resolved: true on each resolved_reference field.\n"
        "  2. Call update_goal_commit_rules with commit_policy and invariants per goal.\n"
        "  3. Call check_template to get a checklist of remaining gaps.\n"
        "  4. Call get_reference(topic='validation') to read this full reference."
    ),
    "worked_example_array_invariants": {
        "description": "Goal whose schema is an array of order items — each item has a category, product (resolved), and quantity",
        "goal_object": {
            "id": "save_order_items",
            "type": "structured",
            "prompt": "Collect the items in this order",
            "commit_policy": "require_all_required",
            "invariants": [
                {"when": {"items[*].category": "hardware"}, "then": {"items[*].product.type": "hardware"}},
                {"when": {"items[*].category": "software"}, "then": {"items[*].product.type": "software"}},
            ],
            "schema": {
                "type": "array",
                "item_schema": {
                    "category": {"type": "string", "required_before_commit": True},
                    "product": {
                        "type": "resolved_reference",
                        "data_source": "product_catalog",
                        "require_resolved": True,
                        "required_before_commit": True,
                    },
                    "quantity": {"type": "number", "required_before_commit": True},
                },
            },
        },
        "what_it_prevents": [
            "order item committed with category='hardware' but product.type='software' (category/type mismatch per item)",
            "any order item missing category or product",
            "product left as a plain string instead of a resolved catalog object",
        ],
    },
    "worked_example": {
        "goal_object": {
            "id": "save_supplier_contact",
            "type": "structured",
            "prompt": "Collect the supplier and their primary contact",
            "commit_policy": "require_all_required",
            "invariants": [
                {"when": {"supplier.tier": "gold"}, "then": {"contact.priority": "high"}},
            ],
            "schema": {
                "supplier": {
                    "type": "resolved_reference",
                    "data_source": "supplier_lookup",
                    "require_resolved": True,
                    "required_before_commit": True,
                },
                "contact": {
                    "type": "resolved_reference",
                    "data_source": "contact_lookup",
                    "require_resolved": True,
                    "required_before_commit": True,
                },
            },
        },
        "what_it_prevents": [
            "supplier committed as 'Acme Corp' (string) instead of {id: 42, name: 'Acme Corporation', tier: 'gold'}",
            "commit firing before supplier or contact is collected",
            "gold-tier supplier paired with a low-priority contact (tier/priority mismatch)",
        ],
    },
}

EMBED_CONFIG_REFERENCE = {
    "js_sdk_url": EMBED_JS_URL,
    "init_options": {
        "templateKey": (
            "string — the publishable EMBED KEY returned by create_embed_key(template_id). "
            "Starts with 'rk_live_' or 'rk_test_'. Required.\n\n"
            "CRITICAL: this is NOT the template_id (UUID). Two different values:\n"
            "  - template_id   →  a UUID like '00000000-0000-0000-0000-000000000000'. "
            "Identifies the template server-side. You already have it; you cannot embed with it.\n"
            "  - templateKey   →  an 'rk_live_...' / 'rk_test_...' token returned by "
            "create_embed_key(template_id). Authorizes a host page to start sessions against the "
            "template. You MUST mint this via create_embed_key before embedding.\n\n"
            "If you pass a UUID here, session creation will reject it. 'I already have the "
            "template_id, so I don't need an embed key' is a common wrong assumption — embed keys "
            "are a separate authorization layer, not a synonym for the template's identifier."
        ),
        "onUnderstanding": "function — real-time data callback. Fires each conversation turn with extracted fields. Events are additive: merge keys into your state. Each event contains only fields that changed. A field can be overwritten by a later event but is never explicitly unset.",
        "onComplete": "function — final results: { summary, findings, duration_seconds, external_id }. Fires after backend processing completes (5-15 seconds after the conversation ends).",
        "onClose": "function — called when widget is closed by the user",
        "onError": "function — called with { error } on errors",
        "onGoalTransition": "function — called when the agent moves to a new goal. Receives { from_goal, to_goal }. Use this to navigate your UI to the corresponding form step.",
    },
    "open_options": {
        "mode": "string — 'modal' (centered dialog, 420x560px) or 'compact' (floating bottom-right panel). Default: 'modal'.",
        "personName": "string — name shown to the AI. Default: 'Guest'.",
        "externalId": "string — your identifier, echoed in all webhooks.",
        "sessionId": "string — pre-created session ID (advanced flow, skips session creation).",
        "context": "object — per-session reference data passed to the AI (e.g., valid equipment types, company-specific options). Max 64KB. The agent uses this to validate responses and suggest canonical values.",
    },
    "methods": ["Roxels.init(options)", "Roxels.open(options)", "Roxels.close()", "Roxels.destroy()", "Roxels.send(type, payload)"],
    "form_factors": {
        "modal": "Centered dialog (420x560px) with dimmed backdrop. Like a compact video call window.",
        "compact": "Floating panel in bottom-right corner. Non-obstructive. Collapses to a button when closed.",
    },
    "security_notes": [
        "Embed keys (rk_ prefix) are safe for client-side use — scoped to one template, can only create sessions.",
        "API keys (sk_) stay server-side — never put them in client code.",
        "The iframe loads from app.roxels.ai — no CORS configuration needed on your end.",
    ],
    "callback_notes": [
        "Callbacks use postMessage from an iframe. The widget DOM element must remain in the page for callbacks to fire.",
        "Cross-origin communication works automatically (uses '*' target origin).",
        "onComplete fires after server-side processing (5-15s after the conversation ends). If the user closes the browser tab before processing finishes, onComplete will not fire — use webhooks as a reliable server-side fallback.",
        "onUnderstanding events are additive: each event contains only the fields that changed. Merge them into your state object.",
    ],
}


# ──────────────────────────────────────────────────────────────────────────────
# COMPLETE_TEMPLATE_SPEC — the MCP's canonical opinion of "what a great Roxels
# template looks like." Returned by get_reference(topic='canonical_spec'). This is the
# single source of truth for our integration principles; all category-level
# checks in check_template should trace back to a principle in here.
# When adding a new reliability check, also add the underlying principle here
# so the coding agent can see what "done" looks like before it starts.
# ──────────────────────────────────────────────────────────────────────────────

# ──────────────────────────────────────────────────────────────────────────────
# ID_RESOLUTION_GUIDANCE — the three-tier decision framework for turning user
# speech into the structured IDs a back end expects. This is a LIVE tool's
# payload (get_reference(topic='id_resolution')), not an answer key — it returns the
# decision tree, not the answer for any specific integration. See the tool's
# docstring for when to call.
# ──────────────────────────────────────────────────────────────────────────────
ID_RESOLUTION_GUIDANCE = {
    "principle": (
        "Almost every back end stores records by ID. When an agent-collected "
        "value needs to land as an ID in a webhook payload, you MUST pick an ID "
        "resolution tier BEFORE going live. Otherwise the webhook either fires "
        "with a free-text string (receiver 400s), or the agent asks the user to "
        "say the ID (users don't know IDs). Three tiers escalate by list size "
        "and dynamism; pick the LOWEST that fits — but be strict about the "
        "cutoffs, especially Tier 2. Read dropdown_paranoia and byte_math FIRST."
    ),
    "dropdown_paranoia": (
        "TRIGGER WORDS — if the user describes a field using any of: 'dropdown', "
        "'autocomplete', 'select', 'typeahead', 'combobox', 'picker', 'catalog', "
        "'lookup' — treat it as a TIER 3 CANDIDATE FIRST. Tier 2 is only "
        "justifiable after you deliberately rule Tier 3 out. These surfaces "
        "routinely outgrow Tier 2's envelope in production even when dev data "
        "looks small.\n\n"
        "Two failure modes you will NOT see at configure time:\n"
        "  (a) The list looked small in dev data but production has N× rows.\n"
        "  (b) The list is per-org / per-user and you only saw the current user's\n"
        "      slice during setup — every other tenant has a different slice.\n\n"
        "Both fail silently later: the session join token gets rejected "
        "(silent handshake failure — status stuck at 'scheduled') OR the agent "
        "prompt bloats by thousands of tokens every turn. Neither produces an "
        "error at configure time.\n\n"
        "Rule of thumb: if you're arguing with yourself about whether a "
        "dropdown-shaped list 'probably stays under the cutoff,' use Tier 3."
    ),
    "byte_math": (
        "Context-options at embed init go into the session join token AND into "
        "every agent system prompt. Keep TOTAL serialized size WELL under ~10KB "
        "across all context-options combined (headroom for auth tokens, tenant "
        "IDs, per-turn prompt cache).\n\n"
        "Rough per-item serialized costs:\n"
        "  string:                         ~8 bytes/item\n"
        "  flat dict {id, name}:           ~30 bytes/item\n"
        "  flat dict {id, name, code}:     ~50 bytes/item\n"
        "  rich dict (5+ fields, ~80b):    ~100-200 bytes/item\n\n"
        "Strict practical cutoffs for a SINGLE list (prefer Tier 3 if close):\n"
        "  strings                → ~500 items\n"
        "  flat dicts (2-3 fields) → ~100 items\n"
        "  rich dicts (5+ fields) → ~30-50 items\n\n"
        "Lists that vary per-user or per-org → Tier 3 regardless of size. The "
        "data source fetches the right slice at runtime with auth context; "
        "embed-init can't do that."
    ),
    "failure_modes_for_oversized_tier_2": [
        "Session join token rejected at handshake — session status stuck at 'scheduled', zero turns, zero trace events. Looks indistinguishable from a user who never clicked join.",
        "Agent prompt bloats by N × tokens_per_item every turn → latency spike + cost + prompt-cache miss every session.",
        "Context-window pressure: long lists crowd out goal prompts, skill sections, transcript history → agent quality drops in ways that are hard to attribute.",
        "All three failures are silent: no error surfaces at configure time. Only symptom is runtime breakage that you won't notice until a user complains.",
    ],
    "when_this_applies": [
        "Webhook schema has a field that expects a structured reference "
        "(name ends in _id / _ref / _sku / _code / _uuid, or the receiver's API "
        "contract requires a specific format).",
        "integration_shape.per_goal_expectations['<goal>'].id_resolution_needs "
        "has at least one entry.",
        "check_template surfaced an id-resolution gap (data source "
        "missing, or schema field not shaped to its tier).",
    ],
    "decision_tree": [
        {
            "q": "Q1. Does the webhook receiver really need a structured ID (vs. free text)?",
            "branches": {
                "no": "Stop — leave the field as a plain string. Done.",
                "yes": "Continue to Q2.",
            },
        },
        {
            "q": "Q2. Roughly how many options are in the list? (STRICTER CUTOFFS — see byte_math below)",
            "branches": {
                "<=10 and stable":
                    "TIER 1 — inline enum on the schema.",
                "~10 to ~100 flat dicts (≤ ~5KB serialized), same for every user, stable":
                    "TIER 2 — context options dict. ONLY if all three conditions hold. When in doubt, use TIER 3.",
                "100+ items, OR rich dicts (5+ fields), OR >5KB serialized, OR per-user/per-org, OR grows over time, OR you can't prove it's stable":
                    "TIER 3 — data source with runtime lookup. This is the safe default.",
                "unknown":
                    "Default to TIER 3. It handles all list sizes; revise down only if you CAN PROVE the list is small, stable, and identical for every user.",
            },
        },
        {
            "q": "Q3. (Tier 2/3) Is the list the same for every user?",
            "branches": {
                "same for all":            "Inject options globally (Tier 2) or configure a shared endpoint (Tier 3).",
                "per-user or per-org":     "Pass options via session context (Tier 2) or use {{context.authToken}} for per-user auth (Tier 3).",
            },
        },
        {
            "q": "Q4. (Tier 3 only) Does the user usually know the exact name?",
            "branches": {
                "usually yes":             "Search by `phrase` only — no args params needed.",
                "often ambiguous/partial": "Add args params (e.g. category, level, type) the agent supplies from world knowledge. Declare them in request.params with value_from='args' and a description — that description is rendered into the agent's tool prompt.",
            },
        },
    ],
    "tiers": {
        "tier_1_inline_enum": {
            "when": "≤ ~10 options, stable, known at template-creation time.",
            "mechanism": "Declare the field's type as 'enum' with the values inline on the schema. LLM picks one from the visible list. No API call, zero latency, zero infra.",
            "example_schema_field": {
                "plan": {
                    "type": "enum",
                    "values": ["basic", "pro", "enterprise"],
                    "description": "The plan tier the user wants.",
                },
            },
            "limits": [
                "List must be ≤ ~10 items — prompt bloat and ambiguity grow fast above that.",
                "List is frozen at template-edit time — changing it requires a template update.",
                "Enum is global — can't vary per user or per session.",
            ],
        },
        "tier_2_context_options_dict": {
            "when": (
                "~10–100 flat dicts (≤ ~5KB serialized), same for every user, stable. "
                "STRICT: if the user called it a 'dropdown' / 'autocomplete' / 'select' / "
                "'picker', default to Tier 3 and justify Tier 2 deliberately. See "
                "dropdown_paranoia and byte_math at the top of this guidance."
            ),
            "mechanism": (
                "Pass an options dict in session context (e.g. via "
                "Roxels.open({ context: { products: [...] } }) at embed init, or "
                "the API request's context field). Reference it from the field's "
                "description so the LLM knows to pick from that list."
            ),
            "example_schema_field": {
                "product": {
                    "type": "string",
                    "description": "One of the products listed in {{context.products}}. Match the user's language to the closest entry and return the product's id.",
                },
            },
            "example_init": (
                "Roxels.open({ mode: 'modal', context: { products: "
                "[{id:'p1',name:'Widget A'},{id:'p2',name:'Widget B'}] } })"
            ),
            "limits": [
                "HARD LIMIT: >5KB serialized total across all context-options → join token may be rejected at handshake (silent failure).",
                "Prompt bloat even below the token limit — every turn carries the full list. ~100 items of flat dicts is already ~30% of a typical system prompt.",
                "Options are captured at init; later updates mid-session are not reflected.",
                "No search recovery — if the user says something unmatched, the LLM guesses rather than calls a lookup.",
                "Any variance per-user/per-org makes this tier wrong regardless of size — embed init can't parameterize on runtime auth context.",
            ],
        },
        "tier_3_data_source": {
            "when": (
                "100+ items, OR rich dicts (5+ fields), OR any list that varies per-user/per-org, "
                "OR grows over time, OR total serialized context-options >5KB, OR any field the user "
                "described as a 'dropdown' / 'autocomplete' / 'select' / 'picker' / 'catalog' / "
                "'lookup' / 'typeahead', OR when the agent needs search recovery (clarify on ambiguity, "
                "retry on 0 results). This is the safe default whenever you're unsure."
            ),
            "mechanism": (
                "Configure settings.data_sources[] with a real API endpoint. Add "
                "resolved_reference fields on the goal schema pointing at the "
                "data source by name. The agent calls resolve_id(source, phrase, "
                "args) during the conversation — LLM generates queries, hits "
                "the API in parallel, picks the best match, asks to clarify "
                "on ambiguity, does an enum sweep on 0 results. The webhook "
                "receives the full structured object."
            ),
            "example_data_source": {
                "name": "customer_lookup",
                "type": "api_call",
                "request": {
                    "method": "GET",
                    "url": "https://api.example.com/v1/customers/search",
                    "auth": {"type": "bearer", "token": "{{context.authToken}}"},
                    "params": [
                        {"name": "q", "in": "query", "value_from": "phrase", "required": True},
                    ],
                },
                "description": "Customer directory for this org — match by name, DBA, or account code.",
                "examples": [
                    {"phrase": "Acme", "expected_result": {"id": 42, "name": "Acme Corporation"}},
                ],
                "cache_key_fields": [],
                "output_schema": {"template": {"id": "<id>", "name": "<name>"}},
            },
            "example_schema_field": {
                "customer": {
                    "type": "resolved_reference",
                    "data_source": "customer_lookup",
                    "require_resolved": True,
                    "required_before_commit": True,
                },
            },
            "mcp_tools": [
                "configure_data_source — create/update the data source.",
                "get_reference(topic='data_source') — full config reference including args params, cache_key_fields, relaxable_params, examples, canonicalization_rules.",
                "probe_data_source — dry-run the lookup before going live.",
                "update_webhook_schema — declare the resolved_reference field on the goal.",
            ],
            "strongly_recommended": [
                "Set require_resolved=true on the field — otherwise a failed resolution silently leaks a free-text string to your webhook.",
                "Add 3-5 examples on the data source — few-shot anchors dramatically improve the first-turn match rate.",
                "If the endpoint accepts narrowing params (category, type, level), declare them in request.params with value_from='args' and a description — the agent reads the description to decide what to supply.",
                "Set cache_key_fields to any args whose value changes which record is correct for the same phrase.",
            ],
        },
    },
    "decision_trap": (
        "DO NOT skip to Tier 3 by default. If the list is small and stable, "
        "Tier 1 is strictly better — no latency, no auth, no failure modes. "
        "Tier 3 is powerful but has the most moving parts (endpoint, auth, "
        "args, cache keys, learned rules); every moving part is a place the "
        "integration can break."
    ),
    "when_to_revise_the_shape_instead": (
        "If Roxels proposed a tier that doesn't match what your codebase can "
        "actually do (e.g. proposed tier 3 data_source but your repo has no "
        "lookup endpoint, only a Redis-cached list), call "
        "integration_shape(action='revise') with recommended_tier set to what IS feasible "
        "and cite the file/endpoint you checked. Then implement that tier."
    ),
}

COMPLETE_TEMPLATE_SPEC = {
    "version": 1,
    "philosophy": (
        "A great Roxels template turns a live conversation into reliable, structured "
        "outcomes for the host application. It does this by being information-complete: "
        "every goal has a schema the engine can extract against, every external lookup "
        "has a data source with enough context to resolve ambiguity, every back-end "
        "write has a webhook shaped exactly like the receiver expects, and every piece "
        "of user-authored config is grounded in a specific, real back-end behavior — "
        "never in a guess. The engine is agnostic to what the template says; the "
        "template is responsible for saying the right thing."
    ),
    "convergence_loop": (
        "TWO LOOPS. PRIMARY (cheap, static): integration_shape(action='read') → revise/confirm → "
        "check_template → fix one gap → repeat, until status='healthy'. Target: "
        "readiness_score=100. SECONDARY (expensive, runtime): start_live_session (or real "
        "embed) → get_session_diagnostics(session_id) — every live test produces rich "
        "diagnostics; never re-test without reading them. Embedded deploys are expensive, "
        "so primary-loop convergence must be thorough before entering secondary. A "
        "successful save tells you the write happened; it says NOTHING about whether the "
        "config is correct, complete, or reliable. Only the diagnostics can."
    ),
    "integration_shape_negotiation": (
        "Shape is a proposal Roxels drafts from the setup conversation, which the coding "
        "agent revises against the real codebase. The FIRST task on any integration is "
        "integration_shape(action='read') → compare to codebase → integration_shape(action='revise') (with "
        "codebase-grounded reasons) or integration_shape(action='confirm'). Until shape is confirmed, "
        "coverage-gap checks (orphan goal, missing chain link, frontend subscription) stay "
        "dormant — the negotiation itself is the only HIGH gap. This prevents the MCP from "
        "grading a template on criteria the coding agent never agreed to."
    ),
    "when_in_doubt": (
        "Call ask_roxels(question, template_id?). It answers free-form questions with full "
        "context on the product, the spec, the template's current state, and (when linked) "
        "the onboarding transcript. Every answer ends with a concrete next action. Use it "
        "BEFORE asking the user a question — they may have already covered it during setup."
    ),
    "categories": {
        "goals_and_schemas": {
            "done_looks_like": [
                "Every goal has a stable `id` so webhook trigger_goal, skills, and JS callbacks can reference it.",
                "Every goal has a prompt rich enough for the speaker to understand what it's trying to capture.",
                "Every field on every goal schema has a type and — when not obvious from the name — a description. The commit author LLM uses descriptions to decide which extracted value goes where.",
                "Fields that require an external lookup (account IDs, product SKUs) are declared as `resolved_reference` with a matching entry in `settings.data_sources` and `require_resolved: true`.",
                "Fields the receiving endpoint requires are marked with `required_before_commit: true`.",
                "`commit_policy` is set on each per-goal webhook (usually `require_all_required`) so commits can't fire with missing required fields.",
                "`extraction_mode` is set to `cumulative` if the receiving endpoint replaces records; left unset for merge/append endpoints.",
            ],
            "common_gaps_detected_by_mcp": [
                "resolved_reference field with no matching data source",
                "required field not declared required",
                "missing extraction_mode on replace-all endpoints",
                "missing goal ids (breaks trigger_goal routing)",
            ],
            "mcp_tools": ["update_webhook_schema", "update_goal_commit_rules", "get_reference(topic='template')", "check_template"],
        },
        "id_resolution": {
            "principle": (
                "A back end that expects structured IDs needs an ID-resolution "
                "strategy. Pick the lowest tier that handles the list size and "
                "freshness needs — don't default to data sources. Call "
                "get_reference(topic='id_resolution') for the full decision tree."
            ),
            "tiers_summary": [
                "Tier 1 — inline enum on the schema. ≤ ~10 stable options. No API call.",
                "Tier 2 — context options dict passed at embed init. ~10–100 flat dicts, ≤ ~5KB serialized total, same for every user. STRICT cutoff — above this, join token may be rejected silently. Any 'dropdown/autocomplete/picker' surface → prefer Tier 3 by default.",
                "Tier 3 — data source with resolved_reference fields. 100+ items, OR rich dicts, OR any list >5KB serialized, OR dynamic, OR per-user/per-org, OR any dropdown/picker/autocomplete surface. Runtime lookup. This is the safe default when in doubt.",
            ],
            "done_looks_like": [
                "Every webhook field that expects a structured ID has a materialized tier — "
                "enum on the schema, context key referenced in the field description, or "
                "resolved_reference + data_source.",
                "Every integration_shape.per_goal_expectations[<g>].id_resolution_needs entry "
                "is materialized — recommended_tier has been verified against the codebase and "
                "the corresponding config exists (schema enum, embed init context, or data_source).",
                "Tier-3 fields have require_resolved=true so failed resolution blocks commit "
                "rather than leaking free text.",
            ],
            "common_gaps_detected_by_mcp": [
                "id_resolution_needs[recommended_tier='data_source'] with no matching data_source.",
                "webhook schema field named like an ID (_id/_ref/_sku/_code/_uuid) with no tier materialized.",
                "resolved_reference field without require_resolved=true.",
            ],
            "mcp_tools": ["get_reference(topic='id_resolution')", "configure_data_source", "update_webhook_schema"],
        },
        "data_sources": {
            "done_looks_like": [
                "Each data source has a rich `description` — the commit author reads it to understand what each resolved `type` means. Treat this like product copy, not a code comment.",
                "Each data source has realistic `examples` so the resolver knows how user phrases map to structured records.",
                "`cache_key_fields` reflect the sibling params that identify a unique lookup (critical for chained resolutions).",
                "Auth is via `{{secret:ref}}` or embed-init context, never raw tokens.",
                "Every data source is actually referenced by at least one schema field — orphan data sources are dead config.",
            ],
            "common_gaps_detected_by_mcp": [
                "data source missing output_template or response_shape",
                "data source auth misconfigured (raw tokens, missing secret)",
                "data source has auth_type=None but hits a non-public endpoint (silent 401 → resolve_id returns no match → webhooks get free-text strings instead of IDs)",
                "cache_key_fields don't match params names",
            ],
            "mcp_tools": ["configure_data_source", "probe_data_source", "check_template_config", "get_reference(topic='data_source')"],
        },
        "webhooks_and_outputs": {
            "done_looks_like": [
                "The integration uses all three primitives correctly: EMBED INIT passes the user's JWT as authToken (and any tenant/org context); WEBHOOKS post at goal commits to existing back-end endpoints for persistence; JS CALLBACKS (onUnderstanding, onGoalTransition, onComplete) drive live UI changes on the page. Anything the PAGE needs to do is a callback; anything the BACK END needs to persist is a webhook. Many goals use both.",
                "ONE WEBHOOK PER GOAL by default. Each webhook output has `trigger_goal=<goal_id>` so it fires at commit time for that goal. Single end-of-session webhooks are the exception, not the default — reserved for receivers that truly need one combined payload.",
                "Auth: STRONGLY PREFERRED is JWT from the frontend — the host page passes its existing user JWT as `authToken` in RoxelsEmbed.init(), and every webhook references it as `{\"Authorization\": \"Bearer {{context.authToken}}\"}`. The back end sees the call as the user, with existing authorization and audit intact. The stored-secret fallback (`{{secret:ref}}` via store_secret) is ONLY for webhooks that represent a system action with no user principal — not the default.",
                "Every per-goal webhook has either a `schema` (anchors extraction) or a `body_template` (precise payload shape) — ideally both when names differ between the extracted goal state and what the endpoint expects.",
                "When the target endpoint expects a bare JSON array (Django DRF bulk views, Stripe-style collection APIs, etc.), the webhook schema is `{type: 'array', item_schema: {...}, description: '... top-level array, NOT wrapped ...'}` and the webhook has `raw_payload: true`. This produces `[{...}, {...}]` as the body — no wrapping object. (Alternative for composing arrays from context values: `body_template: [{...{{context.*}}...}]`.)",
                "URL is real (not `https://example...`, not empty).",
                "`body_encoding` is set (`json` / `form` / `form-nested`). Content-Type is NOT set in headers manually.",
                "Sequential flows use `response_capture` on the upstream webhook and `{{context.KEY}}` in the downstream `body_template` — every captured key is actually consumed.",
                "Error-code handling is anticipated: 4xx-with-body triggers automatic LLM rewrite + retry; 401/403/404 are fatal.",
                "The author has gathered the 10 endpoint facts listed in TEMPLATE_SCHEMA_REFERENCE.output_types.webhook.info_to_gather_before_configuring BEFORE calling configure_output.",
            ],
            "common_gaps_detected_by_mcp": [
                "multi-goal template with only end-of-session webhooks (per-goal shape missing)",
                "per-goal webhook with no schema and no body_template",
                "orphan trigger_goal pointing at a non-existent goal id",
                "response_capture set but captured key never consumed by any downstream",
                "placeholder URL",
                "raw tokens in webhook headers (use {{context.authToken}} or {{secret:ref}} instead)",
            ],
            "mcp_tools": ["configure_output", "configure_output (merge-mode)", "send_http_request", "get_runtime_learnings", "store_secret"],
        },
        "js_callbacks": {
            "what_they_are": (
                "Callbacks wired in the host page's Roxels init call that fire as the "
                "conversation progresses. They are the FRONT-END counterpart to webhooks: "
                "use callbacks for anything the PAGE needs to do (update UI, navigate, "
                "animate a check mark, run client-side validation) and webhooks for anything "
                "the BACK END needs to persist. A typical goal uses BOTH."
            ),
            "done_looks_like": [
                "`onUnderstanding({data})` — merges DELTAS (fields the agent just learned) into page state. Never replace state — merge. Drives live form fills and previews without a back-end round-trip.",
                "`onGoalTransition({from_goal, to_goal})` — navigate the UI to the section/step that corresponds to the new goal. Pairs well with embedded modals that have multiple panes.",
                "`onComplete({summary, findings, ...})` — fires 5–15s after session end (after server processing). Use as the 'done, wrap up the UI' hook. Webhooks are the reliable server-side fallback for tab-close cases.",
                "`onClose`, `onError` — lifecycle.",
            ],
            "mcp_tools": ["get_reference(topic='embed')"],
        },
        "skills_and_advisors": {
            "done_looks_like": [
                "Skills that shape HOW the speaker talks live in `speaker_skills` or `speaker_skillsets`.",
                "Skills that observe and analyze (form validation, compliance, screen narration) live on an Advisor so they get a dedicated observer loop.",
                "Heavy-complexity skills don't bloat the speaker prompt unless they genuinely need to shape each turn.",
                "Reused skill bundles are packaged as named Skillsets so edits propagate across templates.",
                "Deprecated `settings.skills` / `settings.skill_execution_mode` have been migrated to the three-bucket model.",
            ],
            "common_gaps_detected_by_mcp": [
                "deprecated skill fields still in use",
                "advisor-recommended skills attached directly to speaker",
                "heavy skills inlined on speaker",
                "large speaker_skills list with no skillsets (refactor opportunity)",
            ],
            "mcp_tools": ["list_skills", "update_template"],
        },
        "embedding": {
            "done_looks_like": [
                "A publishable embed key has been minted via create_embed_key(template_id). The returned `rk_live_...` or `rk_test_...` token — NOT the template_id UUID — is what goes into `RoxelsEmbed.init({ templateKey: ... })` on the host page. template_id is a server-side identifier; embed key is a host-page authorization credential. Different concepts, different shapes, different places.",
                "The host page's Permissions-Policy allows microphone from app.roxels.ai. Verified via check_embed_permissions_policy BEFORE first live session — silent mic blocks are the #1 reason embeds appear not to work.",
                "The embed integration prefers FRONT-END ONLY wiring: webhooks hit existing back-end endpoints; JS callbacks (onUnderstanding, onGoalTransition, onComplete) drive UI reactions. No new back-end code unless truly required.",
                "`onUnderstanding` is treated as additive — downstream state merges deltas rather than replacing.",
            ],
            "common_gaps_detected_by_mcp": [
                "Permissions-Policy blocks microphone (host-side fix needed)",
                "host URL is a placeholder",
                "host code passes template_id UUID as `templateKey` instead of an embed key — session creation will reject it",
            ],
            "mcp_tools": ["get_reference(topic='embed')", "create_embed_key", "check_embed_permissions_policy"],
        },
        "testing_and_observability": {
            "done_looks_like": [
                "Every per-goal webhook has been hit at least once via send_http_request with a realistic payload, and the response body was read.",
                "At least one end-to-end live test session has run after reaching score=100.",
                "get_runtime_learnings has been reviewed and suggested_actions applied where they fit the template permanently.",
                "Data source resolutions observed in real sessions match expectations (no silent fallback to string commits).",
            ],
            "common_gaps_detected_by_mcp": [
                "outstanding runtime learnings with unapplied suggested_actions",
            ],
            "mcp_tools": ["send_http_request", "probe_data_source", "get_runtime_learnings", "get_session_diagnostics"],
        },
    },
    "final_gate_before_live": [
        "check_template(template_id) returns score=100 with no HIGH or MEDIUM gaps",
        "check_template_config(template_id) passes",
        "send_http_request(template_id, trigger_goal=<id>) has been called for every per-goal webhook, with a realistic payload, and returned a success status",
        "check_embed_permissions_policy(host_url) returns allowed (if embedded)",
        "one end-to-end live test session completed; get_runtime_learnings reviewed",
    ],
    "anti_patterns": [
        "Treating a successful configure_output save as 'done'. Saves mean the write happened, not that the config is correct.",
        "A single end-of-session webhook with a big blob of all goal data, when the receiver could accept per-goal calls. Loses progressive delivery, drop-off resilience, and sequential flows.",
        "Concluding 'Roxels can't send bare JSON arrays' when a target endpoint expects one. Roxels DOES support bare-array bodies via a top-level array schema (`{type: 'array', item_schema: {...}}`) + `raw_payload: true`, or via `body_template: [...]` (list at the top level). Asking the user to change their backend is only appropriate after verifying these options don't fit.",
        "Passing the template_id (UUID) as `templateKey` in `RoxelsEmbed.init`. The template_id identifies the template server-side; it is NOT the embed key. You must mint an embed key via `create_embed_key(template_id)` first — the returned `rk_live_...` / `rk_test_...` token is what goes into the host page's init call. The name `templateKey` invites the confusion; the values are different concepts.",
        "Passing a large list (100+ items, rich dicts, thousands of strings, anything >5KB serialized) as context options at embed init. The session join token may be rejected silently (handshake fails — status stuck at 'scheduled' forever, zero turns, zero errors). Even when it joins, every agent turn carries that list — latency, cost, prompt-cache miss. For any list this size — or per-user/per-org — use a data source (Tier 3).",
        "Configuring any 'dropdown' / 'autocomplete' / 'select' / 'picker' / 'catalog' / 'typeahead' surface as Tier 2 context options without a serious second look. These surfaces routinely grow past Tier 2 in production even when dev data looks small. The trigger words themselves should prompt paranoia — default to Tier 3; justify Tier 2 only if you can PROVE the list stays small AND stable AND identical for every user.",
        "Configuring a data source with auth_type=None because 'the call works when I test it.' Test calls usually work from the coding agent's machine with the user's own credentials. At runtime the resolver hits the endpoint WITHOUT those credentials — the endpoint 401s, resolve_id returns 'no match,' and the agent falls back to free-text world-knowledge guesses. Webhooks then post free-text strings instead of structured IDs, silently. auth_type=None is only correct for TRULY public endpoints; otherwise use `auth_type='bearer'` with `{{context.authToken}}` (preferred) or `{{secret:ref}}` (for service credentials).",
        "Raw tokens in header values. Rejected by the API.",
        "Hardcoding Content-Type instead of setting body_encoding.",
        "Configuring a webhook without first gathering the 10 endpoint facts (see webhook schema info_to_gather_before_configuring).",
        "Stopping when a gap is fixed without re-running the diagnostic. New gaps surface after each fix.",
    ],
}
