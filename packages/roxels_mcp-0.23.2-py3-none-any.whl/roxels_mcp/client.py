"""Roxels API client — thin httpx wrapper for the REST API."""

import httpx


class RoxelsClient:
    """Async HTTP client for the Roxels API."""

    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {api_key}"}

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._headers,
            timeout=30.0,
        )

    async def _request(self, method: str, path: str, **kwargs) -> dict | list:
        async with self._client() as client:
            resp = await client.request(method, path, **kwargs)
            resp.raise_for_status()
            return resp.json()

    # ── Auth ──

    async def whoami(self) -> dict:
        """Get org info for the configured API key. Uses GET /v1/templates as a
        lightweight auth check (returns org context via the API key)."""
        # The /v1/auth/me endpoint requires an internal secret, so we use
        # listing templates as a connectivity/auth test instead.
        templates = await self._request("GET", "/v1/templates")
        return {"authenticated": True, "template_count": len(templates)}

    # ── Templates ──

    async def list_templates(self) -> list:
        return await self._request("GET", "/v1/templates")

    async def get_template(self, template_id: str) -> dict:
        return await self._request("GET", f"/v1/templates/{template_id}")

    async def get_setup_conversation(self, template_id: str) -> dict:
        """Return the raw onboarding conversation (transcript, frames, attachments)
        that created this template, via the setup-assistant reverse link."""
        return await self._request(
            "GET", f"/v1/templates/{template_id}/setup-conversation"
        )

    async def ask_roxels(self, question: str, template_id: str | None = None) -> dict:
        """POST a question to the MCP Q&A backend. Answer is persisted server-side."""
        body: dict = {"question": question}
        if template_id:
            body["template_id"] = template_id
        return await self._request("POST", "/v1/ask", json=body)

    async def get_setup_intent(self, template_id: str) -> dict:
        """Return the structured setup intent captured during onboarding, if any."""
        return await self._request("GET", f"/v1/templates/{template_id}/setup-intent")

    async def extract_setup_intent_now(self, template_id: str) -> dict:
        """Admin/debug: replay Phase 4 intent extraction on an existing template."""
        return await self._request(
            "POST", f"/v1/templates/{template_id}/setup-intent/extract"
        )

    async def get_integration_shape(self, template_id: str) -> dict:
        """Return the negotiated integration_shape for a template (or status='no_integration_shape')."""
        return await self._request(
            "GET", f"/v1/templates/{template_id}/integration-shape"
        )

    async def revise_integration_shape(
        self, template_id: str, patch: dict, reason: str
    ) -> dict:
        """Merge a patch into integration_shape.current with a reason for revision_log."""
        return await self._request(
            "PATCH",
            f"/v1/templates/{template_id}/integration-shape",
            json={"patch": patch, "reason": reason},
        )

    async def confirm_integration_shape(self, template_id: str) -> dict:
        """Mark integration_shape as confirmed (unblocks coverage-gap HIGH escalation)."""
        return await self._request(
            "POST", f"/v1/templates/{template_id}/integration-shape/confirm"
        )

    async def create_template(self, data: dict) -> dict:
        return await self._request("POST", "/v1/templates", json=data)

    async def update_template(self, template_id: str, data: dict) -> dict:
        return await self._request("PATCH", f"/v1/templates/{template_id}", json=data)

    async def start_setup_assistant(self) -> dict:
        return await self._request("POST", "/v1/templates/setup-assistant")

    async def start_modify_assistant(self, template_id: str) -> dict:
        return await self._request(
            "POST", f"/v1/templates/{template_id}/modify-assistant"
        )

    async def validate_template(self, template_id: str) -> dict:
        """Return structural violations for a template. Empty violations = clean."""
        return await self._request("GET", f"/v1/templates/{template_id}/validate")

    async def start_live_session(self, template_id: str) -> dict:
        """Create a test conversation + session and return the join URL."""
        return await self._request("POST", f"/v1/templates/{template_id}/test")

    # ── Interviews ──

    async def list_interviews(
        self,
        template_id: str | None = None,
        person_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list:
        params: dict = {"limit": limit, "offset": offset}
        if template_id:
            params["template_id"] = template_id
        if person_id:
            params["person_id"] = person_id
        if status:
            params["status"] = status
        return await self._request("GET", "/v1/interviews", params=params)

    async def get_interview(self, interview_id: str) -> dict:
        return await self._request("GET", f"/v1/interviews/{interview_id}")

    # ── Persons ──

    async def list_persons(self) -> list:
        return await self._request("GET", "/v1/persons")

    async def create_person(self, data: dict) -> dict:
        return await self._request("POST", "/v1/persons", json=data)

    # ── Embed ──

    async def create_embed_key(
        self, template_id: str, allowed_domains: list[str] | None = None
    ) -> dict:
        body = {"allowed_domains": allowed_domains or []}
        return await self._request(
            "POST", f"/v1/embed/keys/{template_id}", json=body
        )

    async def list_embed_keys(self, template_id: str) -> list:
        return await self._request("GET", f"/v1/embed/keys/{template_id}")

    async def revoke_embed_key(self, key_id: str) -> dict:
        return await self._request("DELETE", f"/v1/embed/keys/{key_id}")

    # ── Testing ──

    async def simulate_output(self, template_id: str, output_index: int = 0) -> dict:
        return await self._request(
            "POST",
            f"/v1/templates/{template_id}/test-output",
            json={"output_index": output_index},
        )

    async def record_learning(self, template_id: str, data: dict) -> dict:
        return await self._request(
            "POST",
            f"/v1/templates/{template_id}/learnings/record",
            json=data,
        )

    # ── Diagnostics ──

    async def get_template_recent_sessions(self, template_id: str, limit: int = 10) -> list:
        return await self._request(
            "GET",
            f"/v1/diagnostics/templates/{template_id}/recent-sessions",
            params={"limit": limit},
        )

    async def get_session_diagnostics(self, session_id: str) -> dict:
        return await self._request("GET", f"/v1/diagnostics/sessions/{session_id}")

    # ── Events ──

    async def log_event(self, event_type: str, payload: dict | None = None) -> dict:
        """Fire a lifecycle event to the Roxels event stream."""
        return await self._request(
            "POST",
            "/v1/events",
            json={"event_type": event_type, "payload": payload or {}},
        )

    async def get_template_issues(self, template_id: str, since: str | None = None) -> dict:
        params = {}
        if since:
            params["since"] = since
        return await self._request(
            "GET",
            f"/v1/diagnostics/templates/{template_id}/issues",
            params=params,
        )
