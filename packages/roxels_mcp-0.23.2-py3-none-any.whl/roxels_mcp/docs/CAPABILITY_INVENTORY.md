# Capability Inventory — roxels-mcp 0.22.0

**Purpose.** Before collapsing the MCP to ~15 tools, enumerate every single thing an agent can do today, plus every guidance mechanism that drives convergence. This file is the acceptance test for the redesign: the new MCP ships only when every box below can still be checked.

**How to use this file.**
1. Before redesign: leave every box unchecked. Confirm the inventory is complete.
2. During redesign: as each capability maps cleanly to the new tool surface, note the mapping `(→ new_tool.arg)` next to the item but keep the box unchecked.
3. Post-redesign verification: run the mapped call, confirm behavior + response shape match, tick the box.
4. Ship when every box is ticked.

**Verification legend.**
- `[C]` = code-reading is enough (map old call → new call, confirm semantically equivalent)
- `[T]` = automated test required (stateful, subtle, or easy to miss)
- `[M]` = manual smoke test required (blocking tools, network-hitting tools, or tools that touch external state)

---

## Part A — Functional capabilities (what the MCP can DO)

### A1. Templates (CRUD + read)

- [ ] `[T]` List templates in the org (paginated, filtered).
- [ ] `[T]` Filter template list by status (e.g. "active", "archived").
- [ ] `[T]` Filter template list by name substring (case-insensitive).
- [ ] `[T]` Paginate template list with `limit` + `offset`.
- [ ] `[T]` Read a single template's full state (goals, settings, outputs, data_sources, schemas, learnings, integration_shape).
- [ ] `[T]` Read a single template with field projection (only named top-level keys in response).
- [ ] `[T]` Create a template programmatically from name + description + goals + settings.
- [ ] `[T]` Update a template (name, description, goals, settings, status) with REPLACEMENT semantics (goals/settings replaced wholesale when passed).
- [ ] `[T]` Update a template and have webhook output schemas auto-preserved across the replacement.
- [ ] `[T]` Update a template and get a deprecation warning if a goal has `schema` set directly on the goal (legacy shape — runtime ignores it).
- [ ] `[T]` Update a template and have raw credentials in webhook headers rejected with a next_action pointing at `store_secret`.
- [ ] `[M]` Create a template interactively via voice conversation (blocks up to 30 min, opens browser, returns created template on completion or timeout envelope). Uses trusted origin validation before opening browser.
- [ ] `[M]` Modify a template interactively via voice conversation (blocks up to 30 min, opens browser, polls status every 5s, handles `completed` / `processing_failed` / timeout).

### A2. Setup context & integration shape

- [ ] `[T]` Read the raw onboarding conversation transcript (verbatim turns, chat messages, frame captures, attachments) that created a template.
- [ ] `[T]` Handle templates with no seed conversation gracefully (`no_seed_interview` status, valid state not an error).
- [ ] `[T]` Read the structured setup intent (goals, desired outputs, constraints, product capabilities, integrations, open questions + free-form prose catch-all).
- [ ] `[T]` Handle setup intent status values: `no_setup_intent` / `pending` (extraction in-flight, 20-40s) / `ok` / `failed`.
- [ ] `[T]` Read the current integration shape (delivery surfaces, per-goal expectations, open_questions, revision_log, status).
- [ ] `[T]` Integration shape statuses: `confirmed` / `proposed_by_roxels` (HIGH priority) / `under_revision` (MEDIUM).
- [ ] `[T]` Delivery surfaces enum: `webhook`, `frontend_callback`, `chained_api`.
- [ ] `[T]` Revise the integration shape with a patch + mandatory `reason` (codebase-grounded justification, logged to revision_log).
- [ ] `[T]` Reject a revise call with no reason via explicit error + hint.
- [ ] `[T]` Reject a revise call with a non-dict patch via explicit error + hint.
- [ ] `[T]` After a revise, receive a next_steps response that either (a) lists remaining open_questions or (b) points at confirm.
- [ ] `[T]` Confirm the integration shape (flip status to confirmed; unlocks coverage-gap checks in check_template).
- [ ] `[T]` Re-propose (re-draft) the integration shape from scratch by replaying Phase 4 + Phase 5 extraction on the original onboarding transcript; resets revision log.
- [ ] `[T]` Before shape is confirmed, coverage-gap checks in `check_template` are deferred — shape negotiation is the only top gap.
- [ ] `[T]` Freeform Q&A via `ask_roxels(question, template_id?)` that returns an answer grounded in full product context + (optional) template state + onboarding transcript.
- [ ] `[T]` `ask_roxels` answers are persisted server-side (org-scoped) for product learning.
- [ ] `[T]` Read runtime learnings (synthesized do/don't rules from live sessions) for data sources + webhook outputs.
- [ ] `[T]` Runtime learnings include `suggested_actions` — concrete MCP calls to consider based on what has been learned.
- [ ] `[T]` Learnings are auto-injected into attempt 1 of next session (platform-side, but behavior is load-bearing and documented in the tool).
- [ ] `[T]` Clear all runtime learnings for a template.
- [ ] `[T]` Clear only data source learnings / only webhook learnings / one named data source's learnings.
- [ ] `[T]` `clear_runtime_learnings` does NOT clear the `examples` list inside `settings.data_sources` — must use update_template for that (surfaced in docstring).

### A3. Sessions & participants

- [ ] `[T]` List interviews (conversation-level records) with optional filters: template_id, person_id, status, limit, offset.
- [ ] `[T]` Interview status values accepted: `not_started`, `in_progress`, `processing`, `completed`, `processing_failed`.
- [ ] `[T]` Read one interview's full results (summary, findings, outputs, transcript, attached files).
- [ ] `[T]` List all persons in the organization.
- [ ] `[T]` Create a person record (name, email, phone, metadata).
- [ ] `[T]` Create person accepts metadata as object OR JSON string.

### A4. Outputs, schemas, data sources, embedding

#### Outputs
- [ ] `[T]` Add or replace an output on a template (webhook | structured | report | email | excel). `replace=True` wipes existing output of same type; `replace=False` adds alongside.
- [ ] `[T]` Webhook config fields supported: url, method, headers, body_encoding (json/form/form-nested), schema, streaming, trigger_goal, response_capture, body_template, raw_payload, commit_policy, invariants.
- [ ] `[T]` configure_output rejects raw credentials in webhook headers with next_action → `store_secret`.
- [ ] `[T]` configure_output response includes `convergence_rule` string reinforcing "saving ≠ done" + next_action → `check_template`.
- [ ] `[T]` Patch specific fields on an existing webhook output (url, headers, schema, streaming, raw_payload, response_capture, body_template) without rewriting the full config.
- [ ] `[T]` patch_output identifies target by `match_trigger_goal` OR by `output_type` for end-of-session outputs.
- [ ] `[T]` patch_output rejects raw credentials in headers.

#### Webhook extraction schemas
- [ ] `[T]` Update the extraction schema on a webhook output (`update_webhook_schema`); schema lives on `output.config.schema`.
- [ ] `[T]` Schema supports two forms: field-map `{field: 'type'}` (object body) OR top-level array `{type: 'array', item_schema: {...}, description: '...'}` (bare array body with raw_payload).
- [ ] `[T]` Field types: string, number, boolean, array, "array of strings", object, resolved_reference.
- [ ] `[T]` resolved_reference field options: `data_source` (required), `require_resolved` (blocks commit on fail), `required_before_commit` (blocks commit on missing).
- [ ] `[T]` Flat array of resolved references: `{type: 'array', item_type: 'resolved_reference', data_source: '...'}`.
- [ ] `[T]` Nested resolved_reference inside array items uses `item_schema` NOT `items` (bug-prone — backend validates).
- [ ] `[T]` update_webhook_schema validates goal exists (not_found envelope if missing).
- [ ] `[T]` update_webhook_schema validates a webhook output is linked to the goal (error envelope with next_action → `configure_output` if not).
- [ ] `[T]` update_webhook_schema returns reliability diagnosis (HIGH/MEDIUM gaps after save).

#### Goal commit rules
- [ ] `[T]` Set commit rules on a goal's webhook output (`update_goal_commit_rules`): `commit_policy` (auto | require_all_required | human_confirm), `invariants` (shape-match when/then rules).
- [ ] `[T]` update_goal_commit_rules warns (in canonical `warnings` array) when `require_all_required` is set but no `required_before_commit` fields exist on the schema (inert policy).
- [ ] `[T]` Invariants DSL: `[{"when": {"field.path": value}, "then": {"other.path": expected}}]`.

#### Data sources
- [ ] `[T]` Register a data source on a template (`configure_data_source`): name, endpoint_url, description, auth_type, auth_token, output_template, default_params, params (v2 list), method, examples, canonicalization_rules, cache_key_fields, relaxable_params.
- [ ] `[T]` Supports v1 `endpoint` block and v2 `request` block formats.
- [ ] `[T]` v2 params shape: `[{name, in, value_from: 'literal'|'args'|'phrase', required, description, type?, values?}]`.
- [ ] `[T]` `cache_key_fields` load-bearing for chained resolutions (sibling params identifying a unique lookup).
- [ ] `[T]` `relaxable_params` enables 0-result retry recovery cascade (params safe to drop on retry).
- [ ] `[T]` `canonicalization_rules` for tiebreakers on ambiguous candidates.
- [ ] `[T]` `examples` list (phrase → result) trains the resolver.
- [ ] `[T]` `output_template` is a transformation map `{field: '<api_result_key>'}` — NOT a JSON Schema `{type, description}` (wrong form silently ignored; backend flags).
- [ ] `[T]` configure_data_source rejects raw credentials in auth_token.
- [ ] `[T]` List a template's data sources.
- [ ] `[T]` Patch specific fields on an existing data source (including `params` for v2 schemas).
- [ ] `[T]` Remove a data source from a template (idempotent not_found envelope if source not present).
- [ ] `[M]` Probe a data source endpoint — real HTTP call.
- [ ] `[M]` probe_data_source supports v1 and v2 config formats.
- [ ] `[M]` probe_data_source interpolates `{{context.X}}`, `{{args.X}}`, `{{phrase}}` placeholders.
- [ ] `[M]` probe_data_source accepts `params` (overrides), `context` (for {{context.X}}), `args` (for {{args.X}}) arguments.
- [ ] `[M]` probe_data_source auto-applies declared params by `value_from`: phrase → phrase_param_name, literal → hardcoded, args → from parsed_args.
- [ ] `[M]` probe_data_source handles Bearer auth via `{{secret:uuid}}` interpolation.
- [ ] `[M]` probe_data_source reports `unresolved` placeholders not substituted.
- [ ] `[M]` probe_data_source on non-2xx error, pattern-matches error body ("X is required", "unknown X") and suggests adding that param with a concrete `configure_data_source` call.
- [ ] `[M]` probe_data_source writes back `_last_tested` metadata onto the data source on success (timestamp, status_code, result_count, verified).

#### Embedding
- [ ] `[T]` Read embed widget configuration reference (init options, callbacks, security notes).
- [ ] `[T]` Create an embed key (`rk_live_...` or `rk_test_...`) for a template with allowed_domains list (empty = all domains).
- [ ] `[T]` List embed keys for a template (with IDs, allowed_domains, revocation status).
- [ ] `[T]` Revoke an embed key by its UUID.
- [ ] `[T]` Generate a paste-ready HTML/JS embed snippet given an embed key + mode (modal | compact) + person_name + redirect_url.
- [ ] `[M]` Check a host URL's Permissions-Policy for microphone permission.
- [ ] `[M]` check_embed_permissions_policy inspects HTTP response headers `Permissions-Policy` + `Feature-Policy`.
- [ ] `[M]` check_embed_permissions_policy inspects `<meta http-equiv="Permissions-Policy">` tags in HTML.
- [ ] `[M]` check_embed_permissions_policy fingerprints hosting platform: Cloudflare, Vercel, Netlify, CloudFront, Fastly, nginx.
- [ ] `[M]` check_embed_permissions_policy returns verdict (`allowed`/`restricted`/`blocked`) + platform-specific guidance on where to change the policy.

### A5. Testing

- [ ] `[T]` Run structural integrity check on a template (`check_template_config`) — no network.
- [ ] `[T]` check_template_config delegates structural violations to backend validate endpoint (single source of truth for structural errors).
- [ ] `[T]` check_template_config detects `ds_items_vs_item_schema` mistake (using 'items' instead of 'item_schema' for nested resolved_reference).
- [ ] `[T]` check_template_config detects orphan data sources (registered but no schema field references them).
- [ ] `[T]` check_template_config detects untested data sources OR sources whose `_last_tested.verified=False`.
- [ ] `[T]` check_template_config suggests `relaxable_params` for narrowing filters without declared relaxables.
- [ ] `[T]` check_template_config surfaces unacted learned "don't" rules as suggestions pointing at `get_runtime_learnings`.
- [ ] `[T]` check_template_config returns structured errors + warnings + suggestions with fix calls.
- [ ] `[M]` Simulate a configured output with sample data (`simulate_output`) — identified by `trigger_goal` (preferred) or `output_index` (fallback).
- [ ] `[T]` simulate_output resolves trigger_goal → output_index internally.
- [ ] `[M]` simulate_output generates schema-matching sample data, POSTs to the real URL, returns status + response body.
- [ ] `[M]` Send a raw HTTP request (`send_http_request`) — not template-bound.
- [ ] `[T]` send_http_request supports body_encoding: `json` | `form` | `form-nested` (Stripe/Twilio bracket notation).
- [ ] `[T]` send_http_request auto-sets Content-Type based on body_encoding.
- [ ] `[T]` send_http_request returns response_headers + status_code + duration_ms + response_body in data.
- [ ] `[T]` send_http_request returns actionable hint on non-2xx responses.
- [ ] `[T]` send_http_request is a pure HTTP passthrough — zero template data access.
- [ ] `[M]` Start a live test session (`start_live_session`) — creates a real session with a test person, returns join_url.
- [ ] `[T]` start_live_session response includes structured next_action → `get_template_recent_sessions`.
- [ ] `[T]` start_live_session docstring carries the SECONDARY LOOP expensive warning.
- [ ] `[T]` Preview webhook payload (`preview_webhook_payload`) — dry-run `body_template` + `{{context.*}}` interpolation with sample data.
- [ ] `[T]` preview_webhook_payload returns rendered body + resolved_context_keys + unresolved_placeholders.
- [ ] `[T]` preview_webhook_payload not_found envelope when trigger_goal doesn't match any output.
- [ ] `[T]` preview_webhook_payload generates sample data from schema when no body_template configured.

### A6. Diagnostics

- [ ] `[T]` `check_template(template_id, format)` — score (0-100) + severity-weighted gap list + top next_action + interpretation string + unresolved_questions. The primary convergence tool.
- [ ] `[T]` check_template supports `format="score"` (score only), `"gaps"` (gaps only), `"both"` (default).
- [ ] `[T]` Gap dicts in check_template response have `next_action` and NO legacy `then_call` field.
- [ ] `[T]` check_template weights: HIGH=10, MEDIUM=3, LOW=1. Score = max(0, 100 - sum).
- [ ] `[T]` check_template interpretation strings: "Healthy" (100), "Close" (≥85), "Workable but brittle" (≥60), "Not ready" (<60).
- [ ] `[T]` check_template category_breakdown — gaps bucketed (skills_and_advisors, webhooks_and_outputs, goals_and_schemas, data_sources, other).
- [ ] `[T]` check_template unresolved_questions (from integration_shape.open_questions) appear as separate entries with their own next_action → `revise_integration_shape`.
- [ ] `[T]` Specific gap types detected by `_collect_template_gaps`:
  - [ ] Integration shape negotiation step (HIGH when proposed_by_roxels, MEDIUM/LOW when under_revision)
  - [ ] Advisor-recommended skill on speaker (MEDIUM)
  - [ ] Heavy complexity speaker_skill not placed-recommended as speaker (MEDIUM)
  - [ ] Many direct speaker_skills with no skillsets (LOW — grouping hint)
  - [ ] Multi-goal template with only end-of-session webhook(s) (HIGH)
  - [ ] Per-goal webhooks for some goals but not all (MEDIUM — coverage)
  - [ ] Orphan trigger_goal pointing at non-existent goal id (HIGH)
  - [ ] require_all_required + no required_before_commit fields (HIGH)
  - [ ] Data source checks from `_interrogate_source` (auth misconfig, missing output_template, missing cache_key_fields, etc.)
  - [ ] Schema field checks from `_interrogate_schema` (resolved_reference without data_source, missing require_resolved, missing description, array without item_schema, etc.)
- [ ] `[T]` List recent sessions for a template (`get_template_recent_sessions`) with health indicators + issue counts.
- [ ] `[T]` Read full diagnostics for one session (`get_session_diagnostics`) — committed goals, outgoing webhook calls, status, response bodies, suggested fixes.
- [ ] `[T]` get_session_diagnostics post-processes "never-committed" goals to return root-cause analysis (missing schema / missing required_before_commit / missing commit_policy).
- [ ] `[T]` get_session_diagnostics rewrites vague "check the URL" suggested_fix strings to point at schema/commit_policy causes.
- [ ] `[T]` get_session_diagnostics appends `uncommitted_goals_analysis` block when goals never committed (listing uncommitted_goal_ids + likely_causes + next_step).
- [ ] `[T]` Aggregate failure patterns across sessions (`get_template_issues`) grouped by endpoint + failure type, sorted by frequency. Supports optional `since` ISO 8601 timestamp.

### A7. Secrets

- [ ] `[M]` Store a secret interactively via terminal `getpass` (not passed as argument, hidden input, never in logs or conversation).
- [ ] `[M]` store_secret displays bordered "what happens to your secret" UI in terminal.
- [ ] `[M]` store_secret sends value over TLS to AWS Secrets Manager; returns `{{secret:uuid}}` reference.
- [ ] `[M]` store_secret handles non-TTY environments explicitly (fails with clear message, not silently).
- [ ] `[T]` List stored secrets for the org.
- [ ] `[T]` Update secret metadata (name, description) — NOT the value.
- [ ] `[M]` Rotate a secret's value (interactive terminal getpass for new value).
- [ ] `[T]` Delete a secret.

### A8. Skills, skillsets, advisors

- [ ] `[T]` List skills visible to the org. Returns `recommended_placement` (speaker/advisor/either), `complexity` (light/medium/heavy), `advisor_rationale`, `summary`. Full `prompt_section` omitted from list (available via get).
- [ ] `[T]` list_skills supports `include_system_defaults` (True default) to include system-wide defaults.
- [ ] `[T]` List skillsets visible to the org with `include_system_defaults` option.
- [ ] `[T]` List advisors owned by the org (advisors are org-scoped, no system defaults).
- [ ] `[T]` list_* response includes a `tip` field explaining how the attached-to-template usage works.

### A9. Reference tools

- [ ] `[T]` Get the full template schema reference (goal_types, goal_fields, settings_fields, schema_field_types, output_types with full webhook config documentation including the three primitives diagram).
- [ ] `[T]` Get the data source configuration reference (shape, fields, auth types, examples, response-shape inference).
- [ ] `[T]` Get the validation rules reference (Layer 2: require_resolved, required_before_commit, commit_policy, invariants).
- [ ] `[T]` Get the embed widget configuration reference (init options, callbacks, security notes, Permissions-Policy guidance).
- [ ] `[T]` Get the ID-resolution decision guide (three-tier escalation: inline enum ≤10 stable → context options ≤100 / ≤5KB → data source otherwise).
- [ ] `[T]` Get the canonical template spec (`get_canonical_template_spec`) — categorized "done looks like" + "common gaps" + "mcp_tools" per category + convergence_loop + integration_shape_negotiation + when_in_doubt.
- [ ] `[T]` Canonical spec exposes `EMBED_JS_URL` constant.

### A10. Self-guiding meta-tools

- [ ] `[T]` Get the single most impactful next call (`get_next_action(template_id?)`) — state-aware recommender with priority tiers.
- [ ] `[T]` Without a template_id, `get_next_action` suggests `list_templates` OR `create_template_interactive` with alternatives listed.
- [ ] `[T]` Priority 1: shape unconfirmed → next_action → `get_integration_shape`.
- [ ] `[T]` Priority 2: gaps exist → next_action = highest-severity gap's remediation.
- [ ] `[T]` Priority 3: no gaps → next_action → `start_live_session`.
- [ ] `[T]` Get a categorized index of every tool (`get_mcp_index`) with one-line summaries + entry-point hints.

### A11. Utility

- [ ] `[T]` Identify current org + MCP version (`whoami`) for connection verification.

---

## Part B — Guidance mechanisms (the self-guiding LOOP)

**These are load-bearing for convergence-in-one-shot. They must survive the redesign intact.**

### B1. Entry-point framing
- [ ] `[C]` FastMCP server constructed with `instructions=` banner that names entry-point tools.
- [ ] `[C]` Banner describes the response envelope shape + the `next_action` protocol.
- [ ] `[C]` Banner describes the PRIMARY LOOP explicitly (`configure → check → fix → repeat`, target=100).
- [ ] `[C]` Module docstring at top of `server.py` frames `ask_roxels` (or successor) as the "WHEN IN DOUBT — ASK" fallback.

### B2. The two-loop model
- [ ] `[C]` PRIMARY LOOP documented: `get_integration_shape → revise/confirm → check_template → fix one gap → repeat`, target=100 readiness.
- [ ] `[C]` SECONDARY LOOP documented: `start_live_session → get_session_diagnostics`. "Never re-test without reading diagnostics."
- [ ] `[C]` Secondary loop EXPENSIVE warning present on every tool that hits real endpoints / starts live sessions.
- [ ] `[C]` Canonical spec text explicitly states: "A successful save tells you the write happened; it says NOTHING about whether the config is correct, complete, or reliable."

### B3. `check_template` as primary convergence tool
- [ ] `[T]` check_template response includes a TOP-LEVEL `next_action` pointing at the highest-severity gap's remediation call.
- [ ] `[T]` Every gap dict in `data.gaps` has its own `next_action` block.
- [ ] `[T]` check_template score interpretations visible at every score range.
- [ ] `[T]` check_template at score=100 interpretation points the agent at the final-checks sequence (config check → probe data sources → send http requests → check_embed_permissions → start_live_session).

### B4. `get_next_action` as state-aware recommender
- [ ] `[T]` Priority tier 1: shape unconfirmed → next_action → `get_integration_shape`.
- [ ] `[T]` Priority tier 2: gaps exist → next_action = highest-severity gap's remediation.
- [ ] `[T]` Priority tier 3: no gaps → next_action → `start_live_session` with reasoning.
- [ ] `[T]` No template_id → next_action → `list_templates` with alternatives array.
- [ ] `[T]` Response always includes `reasoning` string explaining WHY this is the next best step.

### B5. Integration-shape negotiation as first-class
- [ ] `[C]` `revise_integration_shape` (or successor) requires mandatory `reason` argument; missing reason returns error envelope with hint.
- [ ] `[C]` Reasons logged to revision_log for drift detection.
- [ ] `[C]` Until shape confirmed, coverage-gap checks stay dormant in check_template.
- [ ] `[C]` Shape negotiation surfaces as the TOP gap in check_template while unconfirmed.
- [ ] `[C]` `confirm_integration_shape` (or successor) response explains what coverage checks become active.

### B6. `ask_roxels` fallback with full context
- [ ] `[T]` ask_roxels has product spec + template state + runtime learnings + onboarding transcript available when template_id supplied.
- [ ] `[C]` Docstring explicitly advises "check this BEFORE asking the user a question."
- [ ] `[T]` ask_roxels answers persist server-side for product learning.
- [ ] `[C]` Every answer ends with a concrete next_action.

### B7. Mutating tools return next_action
- [ ] `[T]` Every mutating tool response (create/update/patch/configure/remove/set/etc.) includes a next_action.
- [ ] `[T]` Most mutating tools' next_action points at `check_template` (the convergence-rule pattern).
- [ ] `[C]` "Saving is never final" message present in at least one mutating tool's response (prevents complacency).

### B8. Unresolved questions surfaced structurally
- [ ] `[T]` check_template response includes `unresolved_questions` array (from integration_shape.open_questions) while shape unconfirmed.
- [ ] `[T]` Each unresolved_question has: `question`, `why_we_need_to_know`, `answer_format`, its own `next_action` → `revise_integration_shape` (or successor).

### B9. Severity + score as a convergence signal
- [ ] `[T]` HIGH=10, MEDIUM=3, LOW=1 weighting preserved.
- [ ] `[T]` Gap → next_action conversion reusable across tools (via `_env_format_gap` or equivalent helper).
- [ ] `[T]` Severity categories bucketed in category_breakdown for progress tracking.

### B10. Runtime learnings loop
- [ ] `[T]` Data source learnings synthesized from live sessions are surfaced via `get_runtime_learnings`.
- [ ] `[T]` Webhook learnings similarly surfaced.
- [ ] `[T]` `suggested_actions` in learnings response contains concrete MCP calls (not narrative) that would bake learnings into template config.
- [ ] `[C]` Learnings are auto-injected into next session's attempt 1 (platform behavior, surfaced in docstring).
- [ ] `[T]` check_template_config surfaces learned "don't" rules as suggestions even when not directly actionable.

### B11. Reference blobs with prescriptive "done looks like"
- [ ] `[T]` Canonical spec includes `done_looks_like` checklist per category (goals_and_schemas, id_resolution, data_sources, webhooks_and_outputs, skills_and_advisors, embedding, testing_and_observability).
- [ ] `[T]` Canonical spec includes `common_gaps_detected_by_mcp` per category.
- [ ] `[T]` Canonical spec includes `mcp_tools` per category (which tools to call).
- [ ] `[T]` Canonical spec has explicit `convergence_loop` / `integration_shape_negotiation` / `when_in_doubt` sections.

### B12. Reject raw credentials with next_action
- [ ] `[T]` configure_output / patch_output / update_template / configure_data_source all reject raw credentials and return next_action → `store_secret`.
- [ ] `[T]` `_looks_like_raw_secret` pattern list unchanged (covers Bearer tokens, sk_/rk_ prefixes, GitHub PATs, base64-like strings).

### B13. Contextual error responses
- [ ] `[T]` Not-found errors include hint + next_action (e.g. "goal not found → call get_template to see goal ids").
- [ ] `[T]` Validation errors include hint explaining correct shape + next_action with example.
- [ ] `[T]` Probe errors include pattern-matched API-error interpretation.
- [ ] `[T]` Commit-policy warnings surface as structured `warnings[]` with severity, not narrative strings.

### B14. Open browser only to trusted origins
- [ ] `[T]` `_validate_join_url` refuses to open URLs outside `https://app.roxels.ai/` — prevents accidental agent phishing.

---

## Part C — Response envelope invariants

These must hold for every tool call after the redesign.

- [ ] `[T]` Every tool response parses as valid JSON.
- [ ] `[T]` Every response has a top-level `status` field in {ok, error, pending, not_found}.
- [ ] `[T]` Every response has a `meta` field with `mcp_version`.
- [ ] `[T]` Success responses may include `action` (verb), `data` (payload), `warnings` (list), `next_action` (block).
- [ ] `[T]` Error responses include `error` (human-readable), `hint` (actionable), optional `details`, optional `next_action`.
- [ ] `[T]` `not_found` responses inform which resource + identifier failed to resolve.
- [ ] `[T]` `pending` responses carry a `message` describing what's in-flight.
- [ ] `[T]` Every `next_action` block has `why`, `call: {tool, args}`, `call_string`.
- [ ] `[T]` No tool returns raw `json.dumps(...)` — all go through envelope helpers. (Enforced by `test_server_py_has_no_raw_json_dumps_returns`.)
- [ ] `[T]` No tool response uses legacy field names `then_call`, `next_steps`, `suggested_fix`, `next_best_action`. Only `next_action`.
- [ ] `[T]` Warnings shape: `{rule, message, severity}` with severity in {HIGH, MEDIUM, LOW}.

---

## Part D — Cohesion invariants (don't regress)

- [ ] `[T]` No raw `return json.dumps(` call remains in server.py (enforced by cohesion test).
- [ ] `[T]` No legacy `then_call` field in any gap dict returned by `check_template`.
- [ ] `[T]` Every `client.XXX(...)` call in server.py has a matching `async def XXX` on `RoxelsClient` (no mock-masked drift).
- [ ] `[T]` No deleted tool names remain registered: `set_goal_schema`, `test_webhook`, `validate_template_data_sources`, `test_output`, `test_data_source`, `start_test_session`, `template_readiness_score`, `guided_setup_questions`, `set_webhook_schema`, `set_goal_commit_rules`, `describe_complete_template`, `get_id_resolution_guidance`, `get_template_schema`, `get_data_source_schema`, `get_validation_schema`, `get_embed_config`.
- [ ] `[T]` No user-facing "AI interviewer" or "interviewees" in docstrings or string literals.
- [ ] `[T]` `trigger_goal` field still uses that name on the wire (not renamed to `commit_goal_id`); disambiguator lives in docstrings only.
- [ ] `[C]` `interview_id` STAYS on the wire as-is (500+ backend references + DB tables + routes make renaming a separate coordinated project, out of scope for this redesign). User-facing docstring prose says "conversation" consistently; code identifier stays `interview_id`.
- [ ] `[C]` `_translate_deprecated_skill_fields` is fully removed — backend rejects legacy `skills` / `skill_execution_mode` directly.

---

## Part E — Parameter / error shape invariants

- [ ] `[T]` `configure_output.output_type` (or successor patch key) is `Literal["webhook", "structured", "report", "email", "excel"]`.
- [ ] `[T]` `check_template.format` is `Literal["score", "gaps", "both"]`.
- [ ] `[T]` `clear_runtime_learnings.scope` is `Literal["all", "data_sources", "webhooks", "one_source"]`.
- [ ] `[T]` `clear_runtime_learnings` requires `data_source_name` when `scope="one_source"`; error envelope if missing.
- [ ] `[T]` `simulate_output` accepts `trigger_goal` (preferred) or `output_index` (fallback); resolves trigger_goal → index internally.
- [ ] `[T]` `patch_output` identifier is `match_trigger_goal`; no writable `goal_id` field.
- [ ] `[T]` `get_embed_code` parameter is `embed_key` (not `template_key`).
- [ ] `[T]` `revoke_embed_key` parameter is `embed_key_id` (not `key_id`).
- [ ] `[T]` `list_templates` supports `status`, `limit`, `offset`, `name_contains` filters.
- [ ] `[T]` `get_template` supports `fields=[...]` projection.
- [ ] `[T]` `patch_data_source` supports `params` parameter (v2 structured params).
- [ ] `[T]` Parameters accepting `dict | str` unions parse JSON strings automatically (metadata, config, schema, params, context, args, body, goals, settings, headers, body_template, response_capture, invariants, patch, fields, allowed_domains).

---

## Part F — Infrastructure / packaging

- [ ] `[C]` Package name: `roxels-mcp` on PyPI.
- [ ] `[C]` Version bumped for the redesign release.
- [ ] `[C]` `roxels_mcp/__main__.py` entry point still works: `python -m roxels_mcp`.
- [ ] `[C]` `roxels_mcp/_envelope.py` module (or equivalent) provides `ok`, `error`, `not_found`, `pending`, `next_action`, `wrap_warnings`, `format_gap_as_next_action`.
- [ ] `[C]` `roxels_mcp/_references.py` module exports the six reference constants + `EMBED_JS_URL`.
- [ ] `[C]` `roxels_mcp/client.py` methods match the tool names (no client/server drift).
- [ ] `[C]` Dormant `patterns.py` + `PATTERNS_ENABLED` gate DELETED (per user decision 2026-04-24).
- [ ] `[T]` Existing test suite (`tests/test_envelope.py`, `tests/test_cohesion.py`, `tests/test_mcp_fixes.py`, `tests/test_new_tools.py`) passes end-to-end against the new MCP.
- [ ] `[C]` Backend API endpoints consumed by the client unchanged (MCP is client to backend; the redesign does not alter the backend contract).

---

## Verification procedure

1. **Mapping phase (pre-redesign).** For each `[C]` / `[T]` / `[M]` item, write a one-line mapping: which new tool + args accomplishes this. If any item has no clean mapping, STOP — either expand the new tool surface or revise this inventory.

2. **Test-migration phase (during redesign).** Every `[T]` item that maps to a new tool gets a test in the new `tests/test_capability_inventory.py`. Run `pytest -v` — all must pass before PR.

3. **Smoke phase (post-redesign).** Every `[M]` item gets manually exercised once against a real template. Results noted in PR description.

4. **Cohesion phase (post-redesign).** Every Part-B guidance mechanism gets verified in a walk-through: create a fresh template, follow only the `next_action` chain, confirm convergence to score=100 without ever reading docstrings beyond the entry-point banner.

5. **Ship when:** every box ticked.

---

## Items explicitly OUT OF SCOPE for this redesign

- **Rename `interview_id` → `conversation_id`** — requires coordinated backend (435 code refs) + DB (2 tables + foreign keys) + URL routes + frontend (65 refs) change. Separate project. MCP keeps `interview_id` on the wire; docstrings say "conversation."
- **Dormant integration-patterns catalog** — removed entirely per user decision 2026-04-24. If re-needed, rebuild fresh.
- **Backend behavior changes** — redesign is MCP-surface only; backend API contract unchanged.

---

## Bottom line

If this inventory is complete, the redesign cannot silently lose functionality. The ~15-tool surface must serve every item here — otherwise it's an incomplete collapse and this file is the evidence.
