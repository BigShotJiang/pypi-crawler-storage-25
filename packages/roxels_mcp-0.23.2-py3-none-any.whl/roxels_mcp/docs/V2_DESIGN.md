# roxels-mcp V2 — Surface Design

**Target:** **43 tools** (down from 56), structured around minimizing decision points, not minimizing tool count. Every response carries state + loop-phase + on-path markers so the agent always knows where they are in the convergence loop.

**Optimization goal:** a client's coding agent, landing on this MCP for the first time, converges to a working Roxels template in ONE shot — without reading more than the entry-point banner.

**Reference:** this design maps 1:1 to `CAPABILITY_INVENTORY.md`. Every one of its 256 items maps to exactly one V2 tool+args combination.

---

## Design principles

### P1 — ONE LANGUAGE
Verbs follow a convention and every name reads as what it does:
- Writes use `create_*` / `update_*` / `configure_*` / `remove_*`
- Reads use `get_*` / `list_*`
- Diagnosis uses `check_*` / `verify`
- Orchestration uses `revise_*` / `confirm_*` / `propose_*` / `rotate_*`
- Meta uses `get_next_action` / `get_mcp_index`

### P2 — ONE SHAPE
Every response uses the canonical envelope:
```
{status, action, data, warnings?, next_action?, meta}
```
`meta` is ALWAYS populated with state-awareness markers (see Principles P4/P5/P6 below).

Errors:
```
{status, error, details?, hint, next_action?, meta}
```

### P3 — ONE THREAD
Every response either gives the next concrete call (`next_action`) or points at the state-aware recommender (`get_next_action`). Convergence is a chain of `next_action` blocks, not a tree of docstrings.

### P4 — WHERE-YOU-ARE MARKER (new in V2)
Every response includes `meta.loop_phase` indicating which phase of the convergence loop the call belongs to:
- `"primary"` — configure / check / fix cycle (pre-live)
- `"secondary"` — live test + diagnose cycle (post-live)
- `"setup"` — onboarding context / shape negotiation
- `"reference"` — pure read of static reference content
- `"utility"` — infrastructure/auth
- `"meta"` — guidance/indexing tools

An agent reading a response instantly knows whether they just did primary-loop work, secondary-loop work, or a side-quest.

### P5 — OFF-SCRIPT WARNING (new in V2)
Every tool except `get_next_action` computes `meta.on_recommended_path: bool` by running the same priority-tier logic as `get_next_action`. When the tool the agent called is NOT the one the recommender would have suggested, the response leads with:
> *"You called this directly. Your current state suggests `<recommended_tool>` first. Continuing anyway."*

This makes the cost of ignoring guidance visible without blocking the agent's autonomy.

### P6 — LIVE TEMPLATE STATE SNAPSHOT (new in V2)
Every response that carries a `template_id` in `meta` also includes `meta.template_state`:
```
{
  "score": 0-100,
  "gaps_remaining": {HIGH: n, MEDIUM: n, LOW: n},
  "shape_status": "confirmed" | "proposed_by_roxels" | "under_revision" | null,
  "has_live_sessions": bool
}
```
The agent never has to re-query `check_template` to know where they are — the state travels with every response.

---

## The 43 V2 tools

### Group 1 — Templates (4)

```
list_templates(status?, limit=50, offset=0, name_contains?)
get_template(template_id, fields?)
create_template(name, description?, goals?, settings?)
update_template(template_id, name?, description?, status?, goals?, settings?)
```

**Decisions:**
- Keep create/update split — different contracts, merging forces an ambiguous `id?` parameter.
- `update_template` retains REPLACEMENT semantics for goals/settings (documented) with webhook-schema auto-preservation.

**Inventory coverage:** A1 (13 items).

---

### Group 2 — Voice Setup (2) — blocking interactive

```
setup_by_voice(context?)              # was create_template_interactive
modify_by_voice(template_id)          # was modify_template_interactive
```

**Decisions:**
- Renamed — current names are verbose and hide intent.
- `[BLOCKING]` tag lives in docstring banner; dispatch wouldn't help here (they have different pre/post logic).

**Inventory coverage:** A1 (voice items).

---

### Group 3 — Setup Context & Shape (3)

```
get_setup_conversation(template_id)
get_setup_intent(template_id)
integration_shape(template_id, action, patch?, reason?)
    action: Literal["read", "revise", "confirm", "propose"]
```

**Big change #5 — 4 shape tools collapsed into 1 `integration_shape(action, ...)`.**

**Why this collapse IS worth it (was skeptical before):**
- An agent thinks "I'm doing shape work" — ONE tool, one docstring.
- `action` is a declarative selector, not a verb — easier for LLMs than picking between 4 similar verbs.
- Mandatory `reason` on `action="revise"` is enforced via dispatch (error envelope if missing). Same discipline, fewer tool names.
- The dispatch docstring makes the 4 actions visible in one read instead of 4 separate tool lookups.

**Trade-off accepted:** args-per-action vary (`"revise"` needs patch+reason; others take none). The cost is a slightly longer docstring; the benefit is one decision point instead of four.

**Keep `get_setup_conversation` and `get_setup_intent` separate.** Different data sources (transcript vs. structured extraction), genuinely distinct reads. Merging would force a `type=` dispatch for no benefit.

**Inventory coverage:** A2 (shape items).

---

### Group 4 — Runtime Context & Q&A (3)

```
get_runtime_learnings(template_id)
clear_runtime_learnings(template_id, scope="all", data_source_name?)
ask_roxels(question, template_id?)
```

**Decisions:**
- Kept distinct — each has a different side-effect profile (read / write / query).
- `ask_roxels` IS the "when in doubt" fallback; flagged explicitly in module docstring.

**Inventory coverage:** A2 (runtime + Q&A items).

---

### Group 5 — Sessions & Participants (4)

```
list_interviews(template_id?, person_id?, status?, limit=50, offset=0)
get_interview(interview_id)
list_persons()
create_person(name, email?, phone?, metadata?)
```

**Decisions:**
- `interview_id` stays on the wire (rename is out-of-scope per inventory D).
- Docstrings say "conversation" for the user-facing noun.

**Inventory coverage:** A3 fully.

---

### Group 6 — Output & Schema Configuration (3)

```
configure_output(template_id, output_type, config, match_trigger_goal?, replace=True)
update_webhook_schema(template_id, goal_id, schema)
update_goal_commit_rules(template_id, goal_id, commit_policy?, invariants?)
```

**Big change #2 — `patch_output` deleted, folded into `configure_output(match_trigger_goal, replace=False)`.**

**Why the other two stay distinct:**
- `update_webhook_schema` does goal+webhook validation and returns reliability diagnosis. Merging into `configure_output(config={"schema":...})` either loses that validation (bad) or adds schema-specific behavior to a generic tool (muddied contract).
- `update_goal_commit_rules` similarly has commit-policy-specific warning logic (inert `require_all_required` detection). Keeps its own crisp hint surface.

**Raw-credential rejection** is built into all three.

**Inventory coverage:** A4 (outputs, schemas, commit rules).

---

### Group 7 — Data Source Configuration (3)

```
configure_data_source(template_id, name, endpoint_url?, description?, auth_type?, auth_token?, output_template?, default_params?, params?, method?, examples?, canonicalization_rules?, cache_key_fields?, relaxable_params?)
list_data_sources(template_id)
remove_data_source(template_id, source_name)
```

**Big change #3 — `patch_data_source` deleted.** `configure_data_source` is already merge-semantic (preserves unchanged fields). Second tool is redundant.

**`probe_data_source` moves to Group 9 (`verify`).**

**Inventory coverage:** A4 (data source CRUD).

---

### Group 8 — Embedding (4)

```
create_embed_key(template_id, allowed_domains=[])
list_embed_keys(template_id)
revoke_embed_key(embed_key_id)
get_embed_code(embed_key, mode="modal", person_name="Guest", redirect_url="")
```

**Decisions:**
- `check_embed_permissions_policy` moves to Group 9 (`verify`) — it's a verification tool.
- These 4 are genuine CRUD + formatter on distinct resources.

**Inventory coverage:** A4 (embedding CRUD + code generation).

---

### Group 9 — Verify (1) ← **MAJOR COLLAPSE**

```
verify(scope, template_id?, url?, trigger_goal?, source_name?, output_index?,
       params?, context?, args?, method?, headers?, body?, body_encoding?,
       timeout_seconds?, sample_data?)

    scope: Literal[
        "template_config",      # structural check (was check_template_config)
        "data_source",          # probe DS with live HTTP (was probe_data_source)
        "output",               # simulate an output (was simulate_output)
        "http_endpoint",        # raw HTTP (was send_http_request)
        "webhook_preview",      # dry-run body_template interpolation (was preview_webhook_payload)
        "embed_permissions",    # check microphone policy (was check_embed_permissions_policy)
        "live_session",         # start a real test session (was start_live_session)
    ]
```

**Big change #4 — 6 testing tools + `check_embed_permissions_policy` collapsed into `verify(scope, ...)`.**

**Why this is the right collapse (reversed my earlier stance):**

- The agent's mental model is **"I want to verify X works."** `scope` is a declarative selector that matches this model directly.
- All 6 testing tools answer variants of the same question ("does this work?") with different side-effect costs.
- `scope` values are orderable by cost — the docstring lists them cheap-to-expensive so the agent can pick the minimal verification.
- Per-scope hints remain intact: `scope="http_endpoint"` response includes Stripe/Twilio bracket-notation hint; `scope="data_source"` response includes pattern-matched API-error diagnosis; `scope="live_session"` response carries the EXPENSIVE warning.
- `next_action` on the response always suggests the NEXT scope to verify (cheap→expensive cascade).

**What the docstring looks like (skeleton):**
```
verify(scope, ...) — Test one aspect of a template at the cheapest level that
still answers your question.

CHOOSE scope BY COST (cheapest first):
  "template_config"    — structural integrity. No network. Start here.
  "webhook_preview"    — dry-run body_template interpolation. No network.
  "data_source"        — hit a DS endpoint with test args. Real HTTP, no session.
  "output"             — fire a webhook with sample data. Real HTTP, no session.
  "http_endpoint"      — raw HTTP to any URL. Zero template binding.
  "embed_permissions"  — check microphone allowed on a host URL. Zero template binding.
  "live_session"       — start a real test conversation. EXPENSIVE. Only once score=100.

REQUIRED args by scope:
  template_config    → template_id
  webhook_preview    → template_id + trigger_goal (+ optional sample_data)
  data_source        → template_id + source_name (+ optional params/context/args)
  output             → template_id + trigger_goal (or output_index)
  http_endpoint      → url (+ optional method/headers/body/body_encoding/timeout)
  embed_permissions  → url
  live_session       → template_id

Every response includes:
  - pass/fail verdict
  - scope-specific diagnosis
  - next_action → either the next-cheaper scope to try, or fix-the-problem call
```

**Trade-off accepted:** the signature is wide (many optional args) because different scopes need different inputs. Mitigated by clear per-scope args documentation.

**Inventory coverage:** A5 (6 testing items) + A4 (embed_permissions).

---

### Group 10 — Diagnostics & Guidance (5)

```
check_template(template_id, format="both")                       # PRIMARY convergence tool
get_template_recent_sessions(template_id, limit=10)
get_session_diagnostics(session_id)
get_template_issues(template_id, since?)
get_next_action(template_id?)                                     # state-aware recommender
```

**Decisions:**
- 5 tools, 5 orthogonal questions — no collapse earns its keep:
  - `check_template` — "what's broken now?" (static, gap list, score)
  - `get_template_recent_sessions` — "which past sessions matter?" (list + health)
  - `get_session_diagnostics` — "what went wrong in THIS session?" (deep dive)
  - `get_template_issues` — "what's broken repeatedly?" (aggregate patterns)
  - `get_next_action` — "just tell me what to do next" (top recommendation)
- `get_next_action` is the meta-tool that P5 (off-script warning) uses to compute `on_recommended_path`.

**Inventory coverage:** A6 + A10.

---

### Group 11 — Secrets (5)

```
store_secret(name, description?)                # interactive TTY
list_secrets()
update_secret(secret_id, name?, description?)   # metadata only
rotate_secret(secret_id)                        # interactive TTY
delete_secret(secret_id)
```

**Decisions:** Security resources, crisp CRUD verbs, no collapse.

**Inventory coverage:** A7.

---

### Group 12 — Skills, Reference, Meta (5)

```
list_skills(include_system_defaults=True)
list_skillsets(include_system_defaults=True)
list_advisors()
get_reference(topic)                            # replaces 6 reference tools
get_mcp_index()                                 # categorized tool listing
```

**Big change #1 — 6 reference tools → `get_reference(topic)`.**

```
get_reference(topic: Literal[
    "template",         # was get_template_reference
    "data_source",      # was get_data_source_reference
    "validation",       # was get_validation_reference
    "embed",            # was get_embed_reference
    "id_resolution",    # was get_id_resolution_guide
    "canonical_spec",   # was get_canonical_template_spec
])
```

**Why this collapse is unambiguous.** All six are pure read-only string returns with zero side effects. "Which reference do I need?" is a perfect argument-dispatch use case.

**Keep 3 `list_*` for skills/skillsets/advisors** — three distinct data types, each carries a unique `tip` field. Collapsing into `list_org_resources(type)` gains nothing.

**Inventory coverage:** A8 + A9 + A10 (`get_mcp_index`).

---

### Group 13 — Utility (1)

```
whoami()
```

**Inventory coverage:** A11.

---

## Tool count summary

| Group | V1 (0.22) | V2 | Δ |
|---|---|---|---|
| Templates | 4 | 4 | 0 |
| Voice Setup | 2 | 2 | 0 (renamed) |
| Setup Context & Shape | 6 | 3 | **−3** (4 shape → 1 dispatch) |
| Runtime Context & Q&A | 3 | 3 | 0 |
| Sessions & Participants | 4 | 4 | 0 |
| Output & Schema | 4 | 3 | **−1** (delete `patch_output`) |
| Data Source | 5 | 3 | **−2** (probe moves, delete `patch_data_source`) |
| Embedding | 5 | 4 | **−1** (embed_permissions moves) |
| Verify | 6+1 | 1 | **−6** (6 testing + embed_permissions → 1 dispatch) |
| Diagnostics & Guidance | 5 | 5 | 0 |
| Secrets | 5 | 5 | 0 |
| Skills / Reference / Meta | 11 | 5 | **−6** (6 references → 1 dispatch) |
| Utility | 1 | 1 | 0 |
| **TOTAL** | **56** | **43** | **−13** |

---

## Behavioral nudges (the non-surface changes that matter most for one-shot)

### Nudge A — `meta.loop_phase` on every response
Computed per tool based on its group. Agent sees `"loop_phase": "primary"` vs `"secondary"` vs `"setup"` and immediately knows the shape of their current work.

### Nudge B — `meta.on_recommended_path: bool` + off-script warning
On every tool call (except `get_next_action`), the envelope helper runs the priority-tier logic and sets `on_recommended_path`. When false, the response leads with a visible banner in `data.off_script_warning`:
> *"You called `<tool>` directly. Based on current state, `get_next_action` would have suggested `<recommended_tool>`. Continuing anyway. Call `get_next_action(template_id)` if you want the recommended chain."*

This does NOT block the call — agents retain autonomy — but it makes ignoring guidance visible and attributable in logs.

### Nudge C — Sharpened instructions banner
Current banner (0.22.0):
```
ENTRY POINTS:
  - get_canonical_template_spec()
  - get_next_action(template_id?)
  - get_mcp_index()
  - ask_roxels(question, template_id?)

CONVERGENCE LOOP: configure → check_template → fix → repeat.
```

V2 banner:
```
Roxels MCP — build a working conversational AI integration in one shot.

HOW TO USE THIS MCP:
  1. Call get_next_action(template_id) — it tells you the SINGLE next call.
  2. Make that call. Read the response.
  3. The response contains `next_action` with the exact next call.
  4. Repeat until meta.template_state.score = 100.
  5. Then verify(scope="live_session", template_id=...) once.
  6. Then get_session_diagnostics(session_id) on the result.

DO NOT pick tools yourself unless you know exactly what you're doing —
get_next_action is cheaper and more reliable than scanning docstrings.

IF YOU'RE CONFUSED: ask_roxels(question, template_id) answers freeform
questions with full product + template context. Every answer ends with
a concrete next_action.

RESPONSE SHAPE: {status, action, data, warnings?, next_action?, meta}
Where meta always includes:
  loop_phase — which phase of the convergence loop this call belongs to
  on_recommended_path — true if this was the tool get_next_action suggested
  template_state — {score, gaps_remaining, shape_status, has_live_sessions}
```

### Nudge D — `meta.template_state` on every template-scoped response
Built via a cheap helper that hits `_collect_template_gaps` and returns the summary. Cached for the duration of one tool call. The agent never has to re-query state.

---

## Deleted / Renamed / Merged — full table

### Deleted outright
- `patch_output` — absorbed into `configure_output(match_trigger_goal, replace=False)`
- `patch_data_source` — `configure_data_source` is already merge-semantic
- `get_template_reference` — absorbed into `get_reference(topic="template")`
- `get_data_source_reference` — absorbed into `get_reference(topic="data_source")`
- `get_validation_reference` — absorbed into `get_reference(topic="validation")`
- `get_embed_reference` — absorbed into `get_reference(topic="embed")`
- `get_id_resolution_guide` — absorbed into `get_reference(topic="id_resolution")`
- `get_canonical_template_spec` — absorbed into `get_reference(topic="canonical_spec")`
- `check_template_config` — absorbed into `verify(scope="template_config")`
- `probe_data_source` — absorbed into `verify(scope="data_source")`
- `simulate_output` — absorbed into `verify(scope="output")`
- `send_http_request` — absorbed into `verify(scope="http_endpoint")`
- `preview_webhook_payload` — absorbed into `verify(scope="webhook_preview")`
- `check_embed_permissions_policy` — absorbed into `verify(scope="embed_permissions")`
- `start_live_session` — absorbed into `verify(scope="live_session")`
- `get_integration_shape` — absorbed into `integration_shape(action="read")`
- `revise_integration_shape` — absorbed into `integration_shape(action="revise", patch, reason)`
- `confirm_integration_shape` — absorbed into `integration_shape(action="confirm")`
- `propose_integration_shape` — absorbed into `integration_shape(action="propose")`

### Renamed
- `create_template_interactive` → `setup_by_voice`
- `modify_template_interactive` → `modify_by_voice`

### New (added)
- `verify(scope, ...)` — unified verification dispatch
- `integration_shape(action, ...)` — unified shape negotiation dispatch
- `get_reference(topic)` — unified reference dispatch

**Note:** `get_next_action`, `get_mcp_index`, `preview_webhook_payload` already exist in 0.22.0 — they're not new.

---

## Implementation plan (effort-agnostic — doing it right)

1. **Build new unified dispatch tools.**
   - `verify(scope, **args)` — routes to 7 internal handlers (one per scope). Each handler preserves the current tool's validation + response shape.
   - `integration_shape(action, **args)` — routes to 4 internal handlers with action-specific arg validation.
   - `get_reference(topic)` — trivial dispatch on 6 constants.

2. **Build behavioral-nudge infrastructure.**
   - Extend `_env_ok` / `_env_error` / `_env_not_found` / `_env_pending` to accept optional `loop_phase` and `template_id_for_state` args.
   - When `template_id_for_state` is passed, the helper computes `meta.template_state` via a lightweight `_collect_template_gaps` pass (cached within one request if possible).
   - When `loop_phase` is passed, it lands at `meta.loop_phase`.
   - A new helper `_compute_on_recommended_path(tool_name, template_id)` runs the same logic as `get_next_action` and returns bool. Called by every tool at the end of its logic; sets `meta.on_recommended_path` and optionally adds `data.off_script_warning`.
   - Instructions banner rewritten per Nudge C.

3. **Migrate every tool's return statement** to pass the new `loop_phase` / `template_id_for_state` args. (Most calls become 1-line changes.)

4. **Rename `create_template_interactive` / `modify_template_interactive`** → `setup_by_voice` / `modify_by_voice`.

5. **Delete absorbed tools.** (Pre-production: no deprecation aliases.)

6. **Rewrite tests** — add per-scope tests for `verify`, per-action tests for `integration_shape`, `meta.loop_phase` + `meta.on_recommended_path` + `meta.template_state` cohesion tests.

7. **Walk `CAPABILITY_INVENTORY.md`** end to end — tick every box. If any item can't be ticked, STOP and revise this design.

8. **Update `CAPABILITY_INVENTORY.md`** — mark the V2 mapping inline for each item, so future audits can verify.

9. **Bump version → 0.23.0**, build, publish to PyPI, commit, push, open PR.

10. **Manual smoke test:** cold-start a fresh template, follow only the `next_action` chain, verify convergence to score=100 without reading any docstring beyond the banner.

---

## Inventory coverage check

| Inventory section | Items | V2 tool(s) |
|---|---|---|
| A1 Templates | 13 | `list_templates` / `get_template` / `create_template` / `update_template` / `setup_by_voice` / `modify_by_voice` |
| A2 Setup context & shape | 21 | `get_setup_conversation` / `get_setup_intent` / `integration_shape` / `ask_roxels` / `get_runtime_learnings` / `clear_runtime_learnings` |
| A3 Sessions & participants | 6 | `list_interviews` / `get_interview` / `list_persons` / `create_person` |
| A4 Outputs/schemas/data sources/embedding | 50 | `configure_output` / `update_webhook_schema` / `update_goal_commit_rules` / `configure_data_source` / `list_data_sources` / `remove_data_source` / `create_embed_key` / `list_embed_keys` / `revoke_embed_key` / `get_embed_code` / `verify(scope="embed_permissions")` / `verify(scope="data_source")` |
| A5 Testing | 19 | `verify(scope=...)` — all 7 scopes |
| A6 Diagnostics | 24 | `check_template` / `get_template_recent_sessions` / `get_session_diagnostics` / `get_template_issues` |
| A7 Secrets | 8 | 5 secret tools |
| A8 Skills/skillsets/advisors | 5 | `list_skills` / `list_skillsets` / `list_advisors` |
| A9 Reference | 7 | `get_reference(topic)` — all 6 topics |
| A10 Self-guiding meta | 6 | `get_next_action` / `get_mcp_index` / `check_template` |
| A11 Utility | 1 | `whoami` |
| B guidance mechanisms | 43 | distributed across all tools + new nudges A/B/C/D |
| C envelope invariants | 11 | unchanged + 3 new `meta.*` fields |
| D cohesion invariants | 8 | unchanged |
| E parameter invariants | 11 | unchanged + new `verify.scope` / `integration_shape.action` / `get_reference.topic` Literals |
| F infrastructure | 8 | unchanged (patterns.py already deleted) |

**All 256 items covered.** Average 5.9 items per tool — realistic density.

---

## Honest trade-offs

**Collapsing `verify` and `integration_shape` into dispatch tools is NOT free.** Downsides I'm accepting:

1. **Wider signatures with optional args.** `verify` has ~13 parameters, most optional per scope. Agents may confuse which args go with which scope on first pass. **Mitigated by** per-scope args table in docstring + error envelope when required args are missing.
2. **Deeper docstrings.** `verify` needs to explain 7 scopes in one docstring. Longer read. **Mitigated by** scope ordering (cheap → expensive) + a one-line summary per scope.
3. **Harder to grep.** An agent searching for "send_http_request" won't find a tool by that name. **Mitigated by** `get_mcp_index` which shows all scopes, and the tool docstring itself including the old names as historical breadcrumbs.
4. **Per-scope response heterogeneity.** `verify(scope="template_config")` returns a different data shape than `verify(scope="live_session")`. **Accepted** — different scopes inherently produce different results; envelope `meta` is consistent.

**I'm accepting these trade-offs because** the decision-point reduction (6→1 for testing, 4→1 for shape) is the thing that actually drives one-shot convergence. The alternative — 6 separate `verify_*` tools — keeps the decision point and only saves on docstring length.

---

## What this design does NOT do

- **Rename `interview_id` → `conversation_id`.** Out of scope (500+ cross-repo refs).
- **Change backend contracts.** Pure MCP-surface work.
- **Split `check_template` and `verify(scope="template_config")`** into something unified — different cognitive model (one is "full convergence check with gaps + score + next_action"; the other is "just verify this one thing"). Keep distinct.

---

## Bottom line

56 → 43 tools + 4 behavioral nudges. The collapses are all on **dispatch-friendly families** (reference, verify, shape) where a declarative scope/action/topic selector beats 6+ verbs that all mean variations of the same thing. The behavioral nudges make the convergence loop self-announcing in every response — the agent never has to ask "where am I?" or "am I on the right track?"

Ship this as 0.23.0.
