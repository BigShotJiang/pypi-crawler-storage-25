# Termai package initialization
