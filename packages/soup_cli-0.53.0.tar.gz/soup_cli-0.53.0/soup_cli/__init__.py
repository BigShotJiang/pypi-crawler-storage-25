"""Soup CLI — Fine-tune LLMs in one command."""

__version__ = "0.53.0"
