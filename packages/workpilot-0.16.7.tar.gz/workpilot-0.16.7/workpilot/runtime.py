"""
WorkPilot Runtime — wires together config, providers, tools, agent,
channels, security, web server, skills, and scheduling.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot import __version__
from workpilot.agent.loop import AgentLoop
from workpilot.agent.tools.filesystem import (
    EditFileTool,
    ListDirTool,
    ReadFileTool,
    SearchFilesTool,
    WriteFileTool,
)
from workpilot.agent.tools.git import GitTool
from workpilot.agent.tools.notify import NotifyTool
from workpilot.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from workpilot.agent.tools.shell import ShellTool
from workpilot.agent.tools.web import HttpRequestTool, WebFetchTool, WebSearchTool
from workpilot.bus.queue import MessageBus
from workpilot.channels.cli import CLIChannel
from workpilot.channels.manager import ChannelManager
from workpilot.config.schema import AppConfig, ChannelType
from workpilot.hooks.manager import HookManager
from workpilot.providers.resolver import get_provider
from workpilot.security.audit import AuditLogger
from workpilot.security.rbac import PolicyEngine
from workpilot.security.sandbox import Sandbox
from workpilot.session.manager import SessionManager
from workpilot.skills.loader import SkillLoader
from workpilot.utils.helpers import get_data_dir, get_sessions_dir

if TYPE_CHECKING:
    from workpilot.cron.service import SchedulerService
    from workpilot.mcp.manager import MCPManager
    from workpilot.web.server import WebServer

_SHUTDOWN_TIMEOUT = 3  # seconds per cleanup step


async def _quiet_stop(coro: Any, label: str = "") -> None:
    """Await a shutdown coroutine with a bounded timeout.

    Logs warnings on timeout or unexpected errors so failures aren't silent,
    but never blocks shutdown for longer than ``_SHUTDOWN_TIMEOUT``.

    CancelledError is suppressed (not re-raised) so that subsequent cleanup
    steps still run when the event loop cancels tasks during Ctrl+C shutdown.
    """
    try:
        await asyncio.wait_for(coro, timeout=_SHUTDOWN_TIMEOUT)
    except TimeoutError:
        logger.warning("Shutdown step timed out ({}s): {}", _SHUTDOWN_TIMEOUT, label)
    except asyncio.CancelledError:
        logger.debug("Shutdown step cancelled: {}", label)
    except Exception:
        logger.opt(exception=True).warning("Shutdown step failed: {}", label)


class Runtime:
    """Main runtime orchestrator — wires all subsystems together."""

    def __init__(
        self,
        config: AppConfig,
        workspace: Path | None = None,
        config_local_path: Path | None = None,
    ) -> None:
        self.config = config
        self.workspace = (workspace or Path(config.workspace)).resolve()
        self._config_local_path = config_local_path

        # Configure logging
        self._setup_logging()

        # Core subsystems
        self.audit = AuditLogger(config.security.audit)

        # Initialize secret store with config BEFORE migration (so backend selection
        # respects security.secret_backend and singleton is set for all later callers)
        from workpilot.security.secrets import get_secret_store

        get_secret_store(config)

        # Auto-migrate plaintext secrets to encrypted form (before provider resolution)
        from workpilot.security.migrate import maybe_migrate_secrets

        maybe_migrate_secrets(config, self._config_local_path, self.audit)

        self.sandbox = Sandbox(
            self.workspace,
            shell_config=config.tools.shell,
            profile=config.security.profile,
            allowed_paths=config.security.allowed_paths,
            denied_paths=config.security.denied_paths,
        )
        self.bus = MessageBus()
        self.session_manager = SessionManager(get_sessions_dir())
        self.provider = get_provider(config.providers)
        # Token usage tracking (persistent JSONL)
        from workpilot.providers.usage import TokenUsageTracker

        self.usage_tracker = TokenUsageTracker(get_data_dir())
        if hasattr(self.provider, "set_usage_tracker"):
            self.provider.set_usage_tracker(self.usage_tracker)

        self.tool_registry = ToolRegistry(self.audit)
        self.tool_registry.set_output_config(config.tools.output)
        self.channel_manager = ChannelManager(self.bus)
        self._pre_cloud_channel: Any = None  # set by pre_acquire_cloud_token()
        self.hook_manager = HookManager()
        self.policy_engine = PolicyEngine(config.security)
        self.skill_loader = SkillLoader(self.workspace, tool_registry=self.tool_registry)

        # E-stop
        from workpilot.security.estop import EStop

        self.estop = EStop(events=self.bus.events, audit=self.audit)

        # Risk scorer (v2) — wired for ALL profiles.
        # The scorer always runs; the policy table decides the action per profile.
        self._scorer = None
        if self.provider:
            from workpilot.security.scorer import RiskScorer

            self._scorer = RiskScorer(
                self.provider,
                profile=config.security.profile,
                risk_context=getattr(config.security, "risk_context", None),
            )

        # Approval manager and allowlist for human-in-the-loop approval routing
        from workpilot.security.approval import ApprovalManager

        self.approval_manager = ApprovalManager(config.security.approval)

        self._allowlist = None
        if config.security.allowlist.enabled:
            from workpilot.security.allowlist import AllowlistManager

            # Allowlist persistence to workpilot.local.yaml
            def _persist_entry(entry_dict: dict) -> None:  # type: ignore[type-arg]
                try:
                    from workpilot.config.loader import append_local_config_list

                    append_local_config_list("security.allowlist.entries", entry_dict)
                except Exception as exc:
                    logger.warning("Failed to persist allowlist entry: {}", exc)

            def _remove_entry(index: int) -> None:
                try:
                    from workpilot.config.loader import remove_local_config_list

                    remove_local_config_list("security.allowlist.entries", index)
                except Exception as exc:
                    logger.warning("Failed to persist allowlist removal: {}", exc)

            self._allowlist = AllowlistManager(
                config.security.allowlist,
                persist_fn=_persist_entry,
                remove_fn=_remove_entry,
            )

        # Register built-in hook handlers
        # NOTE: Runtime wiring is tested via integration tests (not unit tests).
        from workpilot.hooks.handlers import register_builtin_handlers

        register_builtin_handlers(
            self.hook_manager,
            estop=self.estop,
            policy_engine=self.policy_engine,
            audit_logger=self.audit,
            scorer=self._scorer,
            approval_manager=self.approval_manager,
            allowlist=self._allowlist,
            bus=self.bus.events,
            channel_manager=self.channel_manager,
            session_manager=self.session_manager,
            auto_approve_timeout=config.security.approval.auto_approve_timeout,
            security_profile=config.security.profile,
        )

        # Wire APPROVAL_RESOLVED events directly to ApprovalManager.resolve().
        # This bypasses the inbound message queue to avoid deadlock — the agent
        # loop blocks in the pre_tool_use hook while waiting for approval.
        from workpilot.bus.events import EventType

        async def _on_approval_resolved(event_type: EventType, payload: dict) -> None:
            action = payload.get("action", "")
            request_id = payload.get("request_id", "")
            resolver = payload.get("resolver", "unknown")
            # Empty request_id = resolve whichever single pending approval exists
            # (used by plain-text keyword fast-path: "yes", "no", etc.)
            if not request_id:
                pending = self.approval_manager.get_pending()
                if len(pending) == 1:
                    request_id = pending[0].id
                else:
                    return
            try:
                approved = action in ("approve", "always")
                self.approval_manager.resolve(
                    request_id, approved=approved, resolver=resolver, action=action
                )
                if action == "always" and self._allowlist:
                    req = self.approval_manager.get_request(request_id)
                    if req:
                        self._allowlist.add(
                            req.tool_name, req.args, added_by=resolver, note="Added via always"
                        )
                # Persist the approval resolution to session history.
                # Append a new approval_resolved record (add_message persists to JSONL)
                # rather than mutating the in-memory cache directly.
                status = "approved" if approved else "denied"
                for sid, msgs in self.session_manager._sessions.items():
                    for m in msgs:
                        if m.get("role") != "approval_request":
                            continue
                        try:
                            data = json.loads(m.get("content", "{}"))
                        except Exception as exc:
                            logger.debug("Failed to parse approval_request content: {}", exc)
                            continue
                        if data.get("request_id") != request_id:
                            continue
                        try:
                            self.session_manager.add_message(
                                sid,
                                {
                                    "role": "approval_resolved",
                                    "content": json.dumps(
                                        {
                                            "request_id": request_id,
                                            "status": status,
                                            "resolver": resolver,
                                        }
                                    ),
                                },
                            )
                        except Exception as exc:
                            logger.warning("Failed to persist approval resolution: {}", exc)
                        return  # request_id is unique — stop after first match
            except (KeyError, ValueError) as exc:
                logger.warning("Approval resolve failed: {}", exc)

        self.bus.events.on(EventType.APPROVAL_RESOLVED, _on_approval_resolved)

        # E-stop → kill all background shell processes
        async def _on_estop(event_type: EventType, payload: dict) -> None:
            action = payload.get("action", "trigger")
            if action != "trigger":
                return  # ignore reset events
            reason = payload.get("reason", "E-stop event")
            actor = payload.get("actor", "system")
            if not self.estop.is_halted:
                self.estop.trigger(reason, actor=actor)
            shell_tool = self.tool_registry.get("shell")
            if shell_tool and hasattr(shell_tool, "kill_all_background"):
                killed = await shell_tool.kill_all_background()
                if killed:
                    logger.warning(f"E-stop: killed {killed} background shell processes")

        self.bus.events.on(EventType.SECURITY_ESTOP, _on_estop)

        # Scheduler (cron + interval + event + heartbeat)
        self.scheduler: SchedulerService | None = None
        if config.cron.enabled:
            from workpilot.cron.service import SchedulerService

            self.scheduler = SchedulerService(
                config.cron,
                bus=self.bus,
                active_channels_fn=self.channel_manager.active_channel_names,
            )

        # Optional subsystems (initialized lazily)
        self._web_server: WebServer | None = None
        self._mcp_manager: MCPManager | None = None
        self._copilot_service: Any = None  # set in _register_tools() if SDK available
        self._claude_code_service: Any = None  # set in _register_tools() if SDK importable

        # Shared memory (used by both AgentLoop and SearchHistoryTool)
        from workpilot.agent.memory import AgentMemory

        self._memory = AgentMemory()

        # Register built-in tools
        self._register_tools()

        # CronTool (agent self-scheduling — dynamically registered when cron.enabled)
        if self.scheduler:
            from workpilot.agent.tools.cron import CronTool

            self.tool_registry.register(CronTool(self.scheduler, self.tool_registry))

        # Merge built-in + user agents
        from workpilot.agents.builtin import get_builtin_agents, merge_agents

        self._all_agents = merge_agents(get_builtin_agents(), config.agents.agents)

        # Also apply explicit overrides from agents.default onto the merged
        # built-in default agent. This keeps backward compatibility for users
        # who configure default under agents.default in YAML.
        if "default" in self._all_agents:
            default_overlay = merge_agents(
                {"default": self._all_agents["default"]},
                {"default": config.agents.default},
            )
            self._all_agents["default"] = default_overlay["default"]

        # Auto-populate tools=None → all registered tool names.
        # The default agent sets tools=None meaning "all tools"; at this point
        # the registry has every built-in + conditional tool registered, so we
        # resolve None to a concrete list before any code iterates over it.
        all_tool_names = sorted(t.name for t in self.tool_registry.list_tools())
        self._auto_tools_agents: set[str] = set()  # agents that had tools=None
        for _name, _cfg in self._all_agents.items():
            if _cfg.tools is None:
                self._auto_tools_agents.add(_name)
                self._all_agents[_name] = _cfg.model_copy(update={"tools": list(all_tool_names)})

        # Create agent loop for entrypoint
        agent_config = self._all_agents.get("default", config.agents.default)
        if config.entrypoint != "default" and config.entrypoint in self._all_agents:
            agent_config = self._all_agents[config.entrypoint]

        # Inject available agent names into SpawnTool (registered before _all_agents was ready)
        spawn_tool = self.tool_registry.get("spawn")
        if spawn_tool and hasattr(spawn_tool, "set_available_agents"):
            spawn_tool.set_available_agents(list(self._all_agents.keys()))

        # Load skills and mark protected-name conflicts
        skills = self.skill_loader.load_all()
        for skill in skills:
            if skill.name in PROTECTED_TOOLS:
                logger.warning("Skill '{}' shadows a protected tool — hidden from LLM", skill.name)
                skill.disable_model_invocation = True

        self.agent = AgentLoop(
            config=agent_config,
            provider=self.provider,
            tool_registry=self.tool_registry,
            bus=self.bus,
            session_manager=self.session_manager,
            audit=self.audit,
            workspace=self.workspace,
            hooks=self.hook_manager,
            available_agents=self._all_agents,
            skill_loader=self.skill_loader,
            skills_config=self.config.skills,
            approval_manager=self.approval_manager,
            allowlist=self._allowlist,
            mcp_configs=self.config.tools.mcp_servers or None,
            memory=self._memory,
        )

        logger.debug(
            f"Runtime initialized: {config.name} v{__version__} "
            f"(profile={config.security.profile.value})"
        )

    def _setup_logging(self) -> None:
        import sys
        import warnings

        # Windows has no time.tzset(), so tzlocal cannot reconcile TZ env
        # with the system clock — it always warns on non-UTC machines.
        if sys.platform == "win32":
            warnings.filterwarnings(
                "ignore",
                message="Timezone offset does not match system offset",
                category=UserWarning,
                module=r"^tzlocal",
            )

        logger.remove()
        level = self.config.logging.level.value
        if self.config.logging.format == "json":
            logger.add(sys.stderr, level=level, serialize=True)
        else:
            logger.add(
                sys.stderr,
                level=level,
                format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}",
            )
        if self.config.logging.file:
            logger.add(self.config.logging.file, level=level, rotation="10 MB")

    @staticmethod
    def _load_config_schema() -> dict[str, Any]:
        """Load the bundled JSON Schema for config validation and lookup."""
        import json
        from importlib.resources import files

        try:
            text = (
                files("workpilot.defaults")
                .joinpath("workpilot-config.schema.json")
                .read_text(encoding="utf-8")
            )
            result: dict[str, Any] = json.loads(text)
            return result
        except Exception as exc:
            logger.warning("Failed to load bundled config schema: {}", exc)
            return {}

    def _register_tools(self) -> None:
        """Register all built-in tools.

        Registration order: core (alphabetical) → standard (alphabetical).
        This keeps list_tools() output naturally ordered for the common case.
        MCP and conditional tools (copilot, claude_code, cron) are registered
        dynamically and may appear out of order; list_tools_sorted() produces
        a stable display order (tier → category → name) when needed.
        """
        # ── Core tier (auto-activate, always in schema) ──────────────────
        self.tool_registry.register(
            EditFileTool(
                self.sandbox, max_file_size_bytes=self.config.tools.filesystem.max_file_size_bytes
            )
        )
        self.tool_registry.register(ListDirTool(self.sandbox))
        self.tool_registry.register(
            NotifyTool(
                self.bus,
                active_channels_fn=self.channel_manager.active_channel_names,
            )
        )
        self.tool_registry.register(ReadFileTool(self.sandbox))
        self.tool_registry.register(SearchFilesTool(self.sandbox))

        from workpilot.agent.tools.search_history import SearchHistoryTool

        self.tool_registry.register(SearchHistoryTool(self._memory))
        self.tool_registry.register(ShellTool(self.sandbox))

        # ── Standard tier (on-demand activation) ─────────────────────────
        if self.config.tools.browser.enabled:
            from workpilot.agent.tools.browser import BrowserTool

            self.tool_registry.register(BrowserTool(self.config.tools.browser))

        from workpilot.agent.tools.update import UpdateCheckTool

        self.tool_registry.register(UpdateCheckTool())

        from workpilot.agent.tools.config_workpilot import ConfigWorkpilotTool
        from workpilot.config.loader import _home_local_override

        local_path = self._config_local_path or _home_local_override()
        self.tool_registry.register(
            ConfigWorkpilotTool(self.config, local_path, self._load_config_schema(), runtime=self)
        )
        self.tool_registry.register(GitTool(self.sandbox))
        self.tool_registry.register(HttpRequestTool())

        from workpilot.agent.tools.spawn import SpawnTool

        self.tool_registry.register(SpawnTool(self._spawn_agent))
        self.tool_registry.register(WebFetchTool())
        self.tool_registry.register(WebSearchTool())
        self.tool_registry.register(
            WriteFileTool(
                self.sandbox, max_file_size_bytes=self.config.tools.filesystem.max_file_size_bytes
            )
        )

        # ── Conditional standard tools (depend on optional SDKs) ─────────
        # Copilot delegate tool (if enabled and copilot SDK is installed)
        if getattr(self.config.tools.copilot, "enabled", False):
            try:
                from workpilot.agent.tools.copilot import (
                    CopilotDelegateService,
                    CopilotDelegateTool,
                    CopilotModelsTool,
                    CopilotStatusTool,
                )

                gh_token = self.config.providers.github_copilot.token
                github_token = gh_token.get_secret_value() if gh_token else None
                self._copilot_service = CopilotDelegateService(
                    self.workspace,
                    self.bus,
                    config=self.config.tools.copilot,
                    github_token=github_token,
                )
                self.tool_registry.register(CopilotDelegateTool(self._copilot_service))
                self.tool_registry.register(CopilotStatusTool(self._copilot_service))
                self.tool_registry.register(CopilotModelsTool(self._copilot_service))
                logger.debug("CopilotDelegate tools registered (github-copilot-sdk found)")
            except ImportError:
                self._copilot_service = None
                logger.debug("github-copilot-sdk not installed — github_copilot tool disabled")
        else:
            logger.debug("CopilotDelegate tools disabled by configuration")

        # Claude Code delegate tool (if enabled and SDK + CLI available)
        if getattr(self.config.tools.claude_code, "enabled", False):
            try:
                import shutil

                import claude_agent_sdk  # noqa: F401

                # Verify the claude CLI binary is reachable (SDK bundles it,
                # but PATH issues can make it unavailable).
                cli_path = getattr(self.config.tools.claude_code, "cli_path", None)
                if not cli_path and not shutil.which("claude"):
                    raise FileNotFoundError(
                        "claude binary not found on PATH (sdk installed but CLI missing)"
                    )

                from workpilot.agent.tools.claude_code import (
                    ClaudeCodeService,
                    ClaudeCodeStatusTool,
                    ClaudeCodeTool,
                )

                self._claude_code_service = ClaudeCodeService(
                    self.workspace,
                    self.bus,
                    config=self.config.tools.claude_code,
                )
                self.tool_registry.register(ClaudeCodeTool(self._claude_code_service))
                self.tool_registry.register(ClaudeCodeStatusTool(self._claude_code_service))
                logger.debug("ClaudeCode tools registered (claude-agent-sdk + CLI found)")
            except ImportError:
                self._claude_code_service = None
                logger.debug("claude-agent-sdk not installed — claude_code tool disabled")
            except FileNotFoundError as exc:
                self._claude_code_service = None
                logger.debug(f"claude CLI not found — claude_code tool disabled: {exc}")
            except Exception as exc:
                self._claude_code_service = None
                logger.debug(f"ClaudeCode tools setup failed: {exc}")
        else:
            logger.debug("ClaudeCode tools disabled by configuration")

        # MCP manager — on-demand server connection (no eager startup)
        if self.config.tools.mcp_servers:
            from workpilot.mcp.manager import MCPManager as _MCPManager

            self._mcp_manager = _MCPManager(
                configs=self.config.tools.mcp_servers,
                registry=self.tool_registry,
                security_profile=self.config.security.profile.value,
                on_tools_registered=self._on_mcp_tools_registered,
                providers=self.config.providers,
                risk_policy=self.config.tools.mcp_risk_policy or None,
                risk_variables=self._build_risk_variables(),
            )
            self.tool_registry.set_mcp_manager(self._mcp_manager)

        # ── Core: tools meta-tool (registered last — needs MCP manager ref) ──
        from workpilot.agent.tools.tools import ToolsTool

        self.tool_registry.register(
            ToolsTool(
                registry=self.tool_registry,
                mcp_manager=self._mcp_manager,
                skill_loader=self.skill_loader,
            )
        )

        logger.debug(f"Registered {len(self.tool_registry.list_tools())} tools")

    def _build_risk_variables(self) -> dict[str, str]:
        """Build ${var} placeholders for MCP risk rule patterns from USER.md identity."""
        variables: dict[str, str] = {}
        user_file = getattr(self.config.agents.default, "user_file", None)
        try:
            from workpilot.utils.identity import _resolve_user_md

            user_md = _resolve_user_md(user_file)
            if user_md.exists():
                import re as _re

                text = user_md.read_text(encoding="utf-8")
                email_m = _re.search(r"^- Email:\s*(.+)$", text, _re.MULTILINE)
                org_m = _re.search(r"^- Organization:\s*(.+)$", text, _re.MULTILINE)
                if email_m:
                    variables["user_email"] = email_m.group(1).strip()
                if org_m:
                    variables["user_org"] = org_m.group(1).strip()
        except Exception:
            pass
        return variables

    def _on_mcp_tools_registered(self, tool_names: list[str]) -> None:
        """Callback: MCPManager registered new tools — expose them to the agent loop.

        Updates both the live agent config and ``_all_agents`` so that
        sub-agents spawned later also see the new MCP tools.
        """
        # Only expand the live agent's tools if it opted into auto-population.
        # Agents with explicit allowlists are not modified.
        entry = self.config.entrypoint or "default"
        if entry not in self._auto_tools_agents:
            logger.debug("Entrypoint has explicit tools — MCP tools not auto-added")
            return
        current = list(self.agent._config.tools or [])
        new = [t for t in tool_names if t not in current]
        if new:
            updated = current + new
            self.agent._config = self.agent._config.model_copy(update={"tools": updated})
            # Keep _all_agents in sync for agents that opted into auto-populated
            # tools (had tools=None at startup). Agents with explicit allowlists
            # are NOT updated — MCP tools must be added to their config manually.
            for agent_name in self._auto_tools_agents:
                if agent_name in self._all_agents:
                    agent_cfg = self._all_agents[agent_name]
                    agent_tools = agent_cfg.tools or []
                    missing = [t for t in tool_names if t not in agent_tools]
                    if missing:
                        self._all_agents[agent_name] = agent_cfg.model_copy(
                            update={"tools": agent_tools + missing}
                        )
            logger.info(f"Agent tool list updated: +{len(new)} MCP tools")

    async def _spawn_agent(
        self,
        agent_name: str,
        prompt: str,
        *,
        _depth: int = 1,
        _parent_session: str = "cli:local",
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Spawn a sub-agent with scoped tools, permissions, and depth tracking."""
        # Look up agent from merged agents (cached on self)
        agent_config = self._all_agents.get(agent_name)
        if not agent_config:
            available = [k for k, v in self._all_agents.items() if not v.metadata.get("internal")]
            return f"Error: unknown agent '{agent_name}'. Available: {', '.join(available)}"

        # Spawn depth enforcement
        parent_config = self._all_agents.get("default", self.config.agents.default)
        max_depth = parent_config.max_spawn_depth
        if _depth > max_depth:
            return (
                f"Spawn depth limit reached (depth {_depth}, max {max_depth}). "
                "Cannot delegate further — handle this task directly."
            )

        # Exclude notify + cron always. Exclude spawn at max depth.
        _ALWAYS_EXCLUDED = {"notify", "cron"}
        excluded = _ALWAYS_EXCLUDED.copy()
        if _depth >= max_depth:
            excluded.add("spawn")
        scoped_tools = [t for t in (agent_config.tools or []) if t not in excluded]

        # Create scoped tool registry. If spawn is allowed (depth < max),
        # register a depth-incremented spawn callback for sub-sub-agents.
        scoped_registry = self.tool_registry.scoped_copy(scoped_tools)
        if "spawn" in scoped_tools and scoped_registry.get("spawn") is not None:
            from workpilot.agent.tools.spawn import SpawnTool

            next_depth = _depth + 1

            async def _child_spawn(
                name: str, p: str, *, metadata: dict[str, Any] | None = None
            ) -> str:
                return await self._spawn_agent(
                    name,
                    p,
                    _depth=next_depth,
                    _parent_session=_parent_session,
                    metadata=metadata,
                )

            scoped_registry.unregister("spawn")
            scoped_registry.register(SpawnTool(_child_spawn))

        # Fork session for tracking (linked to parent)
        forked_session = self.session_manager.fork(_parent_session)

        sub_agent = AgentLoop(
            config=agent_config,
            provider=self.provider,
            tool_registry=scoped_registry,
            bus=self.bus,
            session_manager=self.session_manager,
            audit=self.audit,
            workspace=self.workspace,
            hooks=self.hook_manager,  # N4: sub-agents receive hooks
            prompt_mode="minimal",
            memory=self._memory,  # Share parent's AgentMemory (avoid SQLite connection leak)
        )
        return await sub_agent.run_once(prompt, session_id=forked_session, metadata=metadata)

    # ── Dynamic workspace ────────────────────────────────────────────────

    def switch_workspace(self, new_workspace: Path) -> None:
        """Switch workspace root. Safe because tool calls are sequential."""
        resolved = new_workspace.resolve()
        if not resolved.is_dir():
            raise ValueError(f"Not a directory: {resolved}")
        self.workspace = resolved
        self.sandbox.switch_workspace(resolved)
        self.skill_loader._workspace = resolved
        self.skill_loader.load_all()
        # Update AgentLoop + ContextBuilder (they cache workspace at init)
        if hasattr(self, "agent") and self.agent:
            self.agent._workspace = resolved
            if hasattr(self.agent, "_context") and self.agent._context:
                self.agent._context._workspace = resolved

    # ── Run modes ─────────────────────────────────────────────────────────

    @staticmethod
    def _check_teams_after_login() -> None:
        """Post-login hook: check Teams app installation (interactive only)."""
        try:
            from workpilot.cli.commands import _check_teams_after_cloud_login

            _check_teams_after_cloud_login()
        except Exception as exc:
            logger.debug("Teams post-login check failed; continuing startup: {}", exc)

    def pre_acquire_cloud_token(self, *, interactive: bool = True) -> None:
        """Pre-acquire cloud token on the **main thread** before ``asyncio.run()``.

        On macOS, ``pymsalruntime`` (WAM broker) requires
        ``acquire_token_interactive`` to run on the main thread — the SSO
        Extension uses AppKit APIs with that constraint.  Because
        ``CloudChannel.start()`` dispatches token acquisition to a thread-pool
        via ``run_in_executor``, broker auth always fails there.

        This method creates the ``CloudChannel`` early and calls
        ``pre_acquire_token()`` synchronously (still on the main thread).
        The pre-created channel is stored in ``self._pre_cloud_channel`` and
        reused by ``_start_cloud_if_enabled()`` so the token isn't acquired
        twice.

        On Windows / Linux this is also safe to call — it simply moves the
        (potentially interactive) auth step to before the event loop.

        Args:
            interactive: If *False*, only attempt silent token refresh (no
                login menu).  Defaults to *True* (full login flow).
        """
        from workpilot.channels.cloud import CloudChannel

        cloud_cfg = self.config.channels.cloud
        if not cloud_cfg.enabled:
            return
        if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
            return
        if not cloud_cfg.scope:
            cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"

        ch = CloudChannel(
            self.bus,
            url=cloud_cfg.url,
            tenant_id=cloud_cfg.tenant_id,
            client_id=cloud_cfg.client_id,
            scope=cloud_cfg.scope,
            login_method=cloud_cfg.login_method,
            login_port=cloud_cfg.login_port,
            allow_from=cloud_cfg.allow_from or None,
            auto_reconnect=cloud_cfg.auto_reconnect,
            reconnect_max=cloud_cfg.reconnect_max,
            enable_github=cloud_cfg.enable_github,
            require_relay_auth=cloud_cfg.require_relay_auth,
            bot_app_id=cloud_cfg.bot_app_id,
        )
        if not interactive and not ch.has_cached_credentials():
            logger.info(
                "Cloud relay: no cached credentials — run `workpilot cloud` once to authenticate"
            )
            return

        try:
            acquired = ch.pre_acquire_token(silent_only=not interactive)  # main thread
        except Exception as exc:
            logger.warning("Cloud token pre-acquisition failed: {}", exc)
            return

        if not acquired:
            return  # silent_only with no refreshable cache

        self._pre_cloud_channel = ch

    async def _start_cloud_if_enabled(self, *, interactive: bool = False) -> None:
        """Auto-connect the cloud channel on startup.

        interactive=False (default):
            Silent credentials only. Skips if no cached token so the user
            is not interrupted. Run `workpilot cloud` once first to cache a token.
            Called by run_web_server() only — run_chat() does NOT connect to cloud.

        interactive=True (run_web_server):
            Full login flow — triggers browser/device-code auth when needed,
            matching the behaviour of the explicit `workpilot cloud` command.

        If ``pre_acquire_cloud_token()`` was called before the event loop,
        the pre-created channel (with token already set) is reused here.
        """
        from workpilot.channels.cloud import CloudChannel

        cloud_cfg = self.config.channels.cloud
        if not cloud_cfg.enabled:
            return
        if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
            logger.warning("Cloud channel disabled — missing url/tenant_id/client_id in config")
            return
        if not cloud_cfg.scope:
            cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"
        if self.channel_manager.get(ChannelType.CLOUD) is not None:
            return  # already registered (e.g. by `workpilot cloud` command)

        # Reuse pre-created channel from pre_acquire_cloud_token() if available.
        ch = getattr(self, "_pre_cloud_channel", None)
        if ch is not None:
            self._pre_cloud_channel = None  # consume — one-shot
            ch.set_post_login_hook(self._check_teams_after_login if interactive else None)
        else:
            ch = CloudChannel(
                self.bus,
                url=cloud_cfg.url,
                tenant_id=cloud_cfg.tenant_id,
                client_id=cloud_cfg.client_id,
                scope=cloud_cfg.scope,
                login_method=cloud_cfg.login_method,
                login_port=cloud_cfg.login_port,
                allow_from=cloud_cfg.allow_from or None,
                auto_reconnect=cloud_cfg.auto_reconnect,
                reconnect_max=cloud_cfg.reconnect_max,
                on_post_login=self._check_teams_after_login if interactive else None,
                enable_github=cloud_cfg.enable_github,
                require_relay_auth=cloud_cfg.require_relay_auth,
                bot_app_id=cloud_cfg.bot_app_id,
            )
            if not interactive and not ch.has_cached_credentials():
                logger.info(
                    "Cloud relay: no cached credentials — run `workpilot cloud` once to authenticate"
                )
                return

        ch.set_runtime(self)  # allow admin relay to query Runtime APIs
        self.channel_manager.add(ch)
        try:
            await ch.start()
            logger.info("Cloud channel connected automatically")
        except Exception as exc:
            logger.warning("Cloud auto-connect failed: {}", exc)
            try:
                await ch.stop()
            except Exception:
                pass
            self.channel_manager.remove(ChannelType.CLOUD)

    def _resolve_web_owner_oid(self) -> None:
        """Resolve owner_oid for local web JWT enforcement.

        Priority:
        1. Manual config (already set in workpilot.yaml)
        2. Cloud channel authenticated OID
        3. Shared Entra app MSAL cache
        4. Any other Entra app MSAL cache (primary, legacy)
        5. Skip and warn
        """
        web_cfg = self.config.channels.web
        if web_cfg.owner_oid:
            logger.debug("owner_oid from config: {}", web_cfg.owner_oid)
            return

        # 2. Cloud channel
        cloud_ch = self.channel_manager.get(ChannelType.CLOUD)
        _cloud_oid = getattr(cloud_ch, "_local_oid", None) if cloud_ch else None
        if _cloud_oid:
            web_cfg.owner_oid = _cloud_oid
            logger.debug("owner_oid from cloud channel: {}", _cloud_oid)
            return

        # 3-5. MSAL caches: shared app → primary/legacy → Teams sideload
        def _oid_from_msal_cache(client_id: str, cache_path: Path | None = None) -> str | None:
            """Extract OID from an MSAL token cache file."""
            try:
                import msal

                if cache_path is None:
                    from workpilot.mcp.auth import _load_msal_cache

                    cache, _ = _load_msal_cache(client_id)
                else:
                    from workpilot.security.secrets import decrypt_at_rest

                    cache = msal.SerializableTokenCache()
                    if cache_path.exists():
                        raw = decrypt_at_rest(cache_path.read_bytes())
                        if raw:
                            cache.deserialize(raw.decode("utf-8"))

                app = msal.PublicClientApplication(
                    client_id,
                    authority="https://login.microsoftonline.com/organizations",
                    token_cache=cache,
                )
                accounts = app.get_accounts()
                if accounts:
                    oid_val: str | None = accounts[0].get("local_account_id")
                    return oid_val
            except Exception:
                pass
            return None

        from workpilot.mcp.defaults import SHARED_ENTRA_CLIENT_ID
        from workpilot.utils.helpers import get_auth_dir

        # 3. Shared app
        oid = _oid_from_msal_cache(SHARED_ENTRA_CLIENT_ID)
        if oid:
            web_cfg.owner_oid = oid
            logger.debug("owner_oid from shared app cache: {}", oid)
            return

        # 4a. Primary and legacy client IDs
        candidates = [web_cfg.entra_client_id, *web_cfg.entra_client_id_legacy]
        for cid in candidates:
            if not cid or cid == SHARED_ENTRA_CLIENT_ID:
                continue
            oid = _oid_from_msal_cache(cid)
            if oid:
                web_cfg.owner_oid = oid
                logger.debug("owner_oid from app {} cache: {}", cid[:8], oid)
                return

        # 4b. Teams sideload cache (new path, then legacy fallback)
        oid = _oid_from_msal_cache(
            "7ea7c24c-b1f6-4a20-9d11-9ae12e9e7ac0",
            cache_path=get_auth_dir() / "token_cache_7ea7c24c.bin",
        ) or _oid_from_msal_cache(
            "7ea7c24c-b1f6-4a20-9d11-9ae12e9e7ac0",
            cache_path=get_auth_dir() / "teams_sideload.bin",
        )
        if oid:
            web_cfg.owner_oid = oid
            logger.debug("owner_oid from Teams sideload cache: {}", oid)
            return

        # 5. None found
        logger.warning("No owner_oid resolved — local web JWT will accept any valid tenant user")

    def _schedule_startup_update_check(self) -> None:
        """Fire-and-forget background update check on startup.

        Respects the same throttle as heartbeat: skips if checked within
        18 hours. Logs result at INFO (no user notification).
        """

        async def _check() -> None:
            import time

            await asyncio.sleep(5)  # let startup settle
            try:
                from workpilot.utils.helpers import get_data_dir
                from workpilot.utils.update import check_update

                marker = get_data_dir() / ".last_update_check"
                if marker.exists():
                    age_hours = (time.time() - marker.stat().st_mtime) / 3600
                    if age_hours < 18:
                        return

                status = await asyncio.to_thread(check_update)
                # check_update() writes .last_update_check on success
                if not status.up_to_date:
                    logger.info("Update available: {}", status.summary.split("\n")[0])
            except Exception:
                pass  # best-effort, never block startup

        asyncio.create_task(_check(), name="startup-update-check")

    async def run_prompt(self, prompt: str, session_id: str | None = None) -> str:
        """Run a single prompt and return the response."""
        return await self.agent.run_once(prompt, session_id)

    async def run_chat(self) -> None:
        """Start interactive CLI chat (Agent Mode)."""
        cli = CLIChannel(
            self.bus,
            prompt=self.config.channels.cli.prompt,
            interrupt_fn=lambda sid: self.agent.interrupt(sid),
        )
        self.channel_manager.add(cli)
        await self.channel_manager.start_all()

        # Warm-up MCP servers in background (non-blocking)
        if self._mcp_manager:
            asyncio.create_task(self._mcp_manager.warm_up())

        # Start agent loop in background
        agent_task = asyncio.create_task(self.agent.start())
        self._schedule_startup_update_check()

        # Start scheduler if enabled
        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)
            await self.scheduler.start()

        try:
            await cli.run_repl()
        finally:
            if self.scheduler:
                await self.scheduler.stop()
            await self.agent.stop()
            await self.channel_manager.stop_all()
            agent_task.cancel()
            try:
                await agent_task
            except asyncio.CancelledError:
                pass

    async def run_web_server(self, on_started: Callable[[int], None] | None = None) -> None:
        """Start Web Server Mode (multi-channel HTTP server)."""
        from workpilot.channels.web import WebChannel
        from workpilot.web.server import WebServer

        # Create and register WebChannel with the bus
        web_channel = WebChannel(self.bus)
        self.channel_manager.add(web_channel)
        await web_channel.start()
        await self._start_cloud_if_enabled(interactive=True)

        # Resolve owner_oid for local web JWT enforcement.
        # Priority: 1) manual config  2) cloud channel  3) shared app cache
        #           4) other Entra app caches  5) skip + warn
        self._resolve_web_owner_oid()

        self._web_server = WebServer(self.config.channels.web, self, on_started=on_started)
        self._web_server.set_web_channel(web_channel)

        # Warm-up MCP servers in background (non-blocking)
        if self._mcp_manager:
            asyncio.create_task(self._mcp_manager.warm_up())

        agent_task = asyncio.create_task(self.agent.start())
        self._schedule_startup_update_check()

        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)
            await self.scheduler.start()

        try:
            await self._web_server.start()
        finally:
            if self.scheduler:
                await _quiet_stop(self.scheduler.stop(), "scheduler")
            await _quiet_stop(web_channel.stop(), "web_channel")
            await _quiet_stop(self.agent.stop(), "agent")
            if self._mcp_manager:
                await _quiet_stop(self._mcp_manager.disconnect_all(), "mcp")
            await _quiet_stop(self.channel_manager.stop_all(), "channels")
            agent_task.cancel()
            try:
                await asyncio.wait_for(agent_task, timeout=_SHUTDOWN_TIMEOUT)
            except (asyncio.CancelledError, TimeoutError):
                pass

    run_gateway = run_web_server  # deprecated alias

    async def run_cloud(self) -> None:
        """Cloud relay mode — cloud channel already started by the CLI command.

        Starts the agent loop and keeps the process alive until interrupted.
        The CloudChannel (registered via channel_manager.add before this call)
        handles WebSocket reconnection and message routing autonomously.
        """
        agent_task = asyncio.create_task(self.agent.start(), name="agent-loop")
        self._schedule_startup_update_check()

        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)
            await self.scheduler.start()

        logger.info("Agent loop running — waiting for messages from Cloud Gateway…")

        try:
            # Block until cancelled (Ctrl+C)
            await asyncio.Event().wait()
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        finally:
            if self.scheduler:
                await _quiet_stop(self.scheduler.stop(), "scheduler")
            await _quiet_stop(self.agent.stop(), "agent")
            if self._mcp_manager:
                await _quiet_stop(self._mcp_manager.disconnect_all(), "mcp")
            await _quiet_stop(self.channel_manager.stop_all(), "channels")
            agent_task.cancel()
            try:
                await asyncio.wait_for(agent_task, timeout=_SHUTDOWN_TIMEOUT)
            except (asyncio.CancelledError, TimeoutError):
                pass

    async def shutdown(self) -> None:
        """Graceful shutdown of all subsystems."""
        await self.agent.stop()
        await self.channel_manager.stop_all()
        if self._web_server:
            await self._web_server.stop()
        # Disconnect MCP servers
        if self._mcp_manager:
            await self._mcp_manager.disconnect_all()
        if self._copilot_service:
            await self._copilot_service.stop()
        if self._claude_code_service:
            await self._claude_code_service.stop()
        if self._memory:
            self._memory.close()
        logger.info("WorkPilot runtime shut down")
