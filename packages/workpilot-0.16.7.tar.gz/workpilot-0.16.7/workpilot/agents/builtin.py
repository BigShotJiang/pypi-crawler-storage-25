"""
Built-in agent configurations — default, explorer.

These are always available. Users can override any field via workpilot.yaml.
"""

from __future__ import annotations

import warnings

from workpilot.config.schema import AgentConfig, AgentPermissions
from workpilot.utils.defaults import load_default


def get_builtin_agents() -> dict[str, AgentConfig]:
    """Return the 2 built-in agent configs."""
    return {
        "default": _default_agent(),
        "explorer": _explorer_agent(),
    }


def _default_agent() -> AgentConfig:
    return AgentConfig(
        name="WorkPilot",
        description="General-purpose assistant. Handles direct user interaction, orchestrates sub-agents.",
        model="auto",
        max_iterations=40,
        timeout=1200,
        memory_writable=True,
        max_spawn_depth=2,
        max_concurrent_children=5,
        instructions="",
        tools=None,  # auto-populated from ToolRegistry at runtime
        permissions=AgentPermissions(
            allow_shell=True,
            allow_file_write=True,
            allow_file_read=True,
            allow_network=True,
            allow_browser=True,
            allow_spawn=True,
        ),
        metadata={"category": "orchestrator", "builtin": True},
    )


def _explorer_agent() -> AgentConfig:
    return AgentConfig(
        name="Explorer",
        description="Fast codebase search and file discovery. Read-only.",
        model="fast",
        max_iterations=15,
        timeout=120,
        memory_writable=False,
        instructions=load_default("EXPLORER.md"),
        tools=["read_file", "list_dir", "search_files"],
        permissions=AgentPermissions(
            allow_shell=False,
            allow_file_write=False,
            allow_file_read=True,
            allow_network=False,
            allow_browser=False,
            allow_spawn=False,
        ),
        metadata={"category": "development", "builtin": True},
    )


def merge_agents(
    builtin: dict[str, AgentConfig],
    user: dict[str, AgentConfig],
) -> dict[str, AgentConfig]:
    """Merge user-defined agents with built-in agents.

    User configs override built-in fields. Disabled agents (enabled=False)
    are excluded from the result.
    """
    # Build a reference default instance ONCE for comparison
    _defaults = AgentConfig()
    _default_data = _defaults.model_dump()

    merged = dict(builtin)
    for name, user_config in user.items():
        if name in merged:
            # Override built-in fields with user-specified values.
            # Compare against a default instance to detect user overrides
            # (works correctly for default_factory fields like tools, metadata).
            builtin_data = merged[name].model_dump()
            user_data = user_config.model_dump()
            for k, v in user_data.items():
                if v != _default_data.get(k):
                    if k == "instructions" and name in builtin:
                        if name == "explorer":
                            hint = "Use ~/.workpilot/EXPLORER.md or AGENTS.md instead."
                        else:
                            hint = "Use AGENTS.md instead."
                        warnings.warn(
                            f"agents.{name}.instructions in workpilot.yaml is deprecated. {hint}",
                            UserWarning,
                            stacklevel=2,
                        )
                    builtin_data[k] = v
            merged[name] = AgentConfig(**builtin_data)
        else:
            merged[name] = user_config

    # Remove disabled agents
    return {k: v for k, v in merged.items() if v.enabled}
