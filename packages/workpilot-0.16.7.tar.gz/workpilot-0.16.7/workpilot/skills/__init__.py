"""Skills subsystem — load and match markdown-based prompt skills."""

from workpilot.skills.loader import Skill, SkillLoader

__all__ = ["Skill", "SkillLoader"]
