"""
Cloud channel — outbound WebSocket relay to WorkPilot Cloud Gateway.

Connects to wss://<cloud-gateway>/connect using an Entra ID access token.
Supports two login methods:

  browser  — opens the default browser for interactive PKCE auth code flow
             (http://localhost callback, no redirect URI limitations).
  wam      — WAM broker (native OS auth dialog, no browser); falls back to
             browser PKCE if the app registration doesn't support broker.
             Requires msal[broker] on Windows.
  device   — device code flow (visit a URL + enter a code); works in
             headless / SSH / corporate environments that block browser launch.
             Only used when explicitly configured (many tenants disable this).
  auto     — (default) same as browser. WAM not attempted unless explicitly
             configured via login_method=wam.

Inbound  (server → client): connected, identity_registered, buffered_start/end, message, ping, error
Outbound (client → server): register_identity, response, chunk, pong
"""

from __future__ import annotations

import asyncio
import html as _html
import json
import re
import socket
import time
import webbrowser
from collections.abc import Callable
from pathlib import Path
from typing import Any, Literal

import msal
import websockets
import websockets.exceptions
from loguru import logger
from rich.console import Console
from rich.panel import Panel

from workpilot.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel
from workpilot.channels.conv_ref_store import ConvRefStore
from workpilot.config.schema import ChannelType
from workpilot.mcp.defaults import SHARED_ENTRA_CLIENT_ID
from workpilot.utils.helpers import get_auth_dir, webchat_url_from_connect
from workpilot.utils.html import html_to_markdown

# Microsoft Teams Toolkit's well-known first-party app — pre-authorized for the
# cloud scope in all tenants. Used only as an opportunistic silent fallback
# when its broker cache already exists (populated by `workpilot teams install`).
# Same value as workpilot/cli/teams.py::_TOOLKIT_CLIENT_ID; duplicated to avoid
# cross-module dependency from channels → cli.
TEAMS_TOOLKIT_CLIENT_ID = "7ea7c24c-b1f6-4a20-9d11-9ae12e9e7ac0"


def _id_token_aud_gateway_valid(client_id: str) -> bool:
    """True if the client's own id_token `aud` (= client_id) is accepted by
    the Gateway. Primary clients self-audit (their client_id is the Gateway's
    `AzureAd:ClientId`); Shared is in `LegacyAudiences`; Teams Toolkit is
    intentionally NOT — its `aud=7ea7c24c` is in neither list, so returning
    a Toolkit-issued id_token would just move the 401 one step later.
    """
    return client_id != TEAMS_TOOLKIT_CLIENT_ID


# MSAL error codes that indicate admin consent is required or the user
# cannot consent to the requested permissions.  When the primary app
# registration triggers one of these, we fall back to the shared Entra
# client ID (aebc6443 — VS Code / Agency) which is pre-consented in
# most enterprise tenants.
_CONSENT_ERROR_CODES = frozenset(
    {
        "AADSTS90094",  # admin consent required
        "AADSTS65001",  # user/admin has not consented
        "AADSTS70011",  # invalid scope (consent not granted)
        "AADSTS650052",  # app needs permissions that require admin consent
        "AADSTS700024",  # client assertion audience not allowed
    }
)

_console = Console()


class _CacheStore:
    """Encapsulates MSAL token cache storage for CloudChannel.

    All on-disk details — file naming, encryption at rest, directory
    resolution — live here. Callers interact via ``(client_id, broker=)``
    pairs and never hand-roll paths or touch ``decrypt_at_rest`` /
    ``encrypt_at_rest`` directly.

    The one exception: :meth:`path` returns a ``Path`` for legacy callers
    that have to hand a file path to external MSAL helpers (e.g. the
    shared ``_try_silent_broker`` utility). Everything else is path-free.
    """

    @staticmethod
    def path(client_id: str, *, broker: bool) -> Path:
        suffix = "_broker" if broker else ""
        return get_auth_dir() / f"token_cache_{client_id[:8]}{suffix}.bin"

    @staticmethod
    def exists(client_id: str, *, broker: bool) -> bool:
        return _CacheStore.path(client_id, broker=broker).exists()

    @staticmethod
    def load(client_id: str, *, broker: bool) -> msal.SerializableTokenCache:
        """Load a cache from disk; return an empty cache if missing/corrupt."""
        from workpilot.security.secrets import decrypt_at_rest

        cache = msal.SerializableTokenCache()
        p = _CacheStore.path(client_id, broker=broker)
        if not p.exists():
            return cache
        try:
            raw = decrypt_at_rest(p.read_bytes())
            if raw:
                cache.deserialize(raw.decode("utf-8"))
        except Exception as exc:
            logger.warning("Cannot load MSAL token cache at {} ({})", p, exc)
        return cache

    @staticmethod
    def has_session(client_id: str) -> bool:
        """True if any cache (broker or browser) has an MSAL account."""
        for broker in (True, False):
            try:
                cache = _CacheStore.load(client_id, broker=broker)
                app = msal.PublicClientApplication(client_id=client_id, token_cache=cache)
                if app.get_accounts():
                    return True
            except Exception:  # noqa: S112 — best-effort cache probe
                continue
        return False


class _SilentRefreshExhaustedError(RuntimeError):
    """Raised by ``_run_connection`` when the pre-connect refresh tried every
    silent path and failed. Signals ``_connect_loop`` to skip the generic-
    exception retry-with-refresh branch (which would immediately call
    ``_refresh_for_reconnect`` again and fail the same way)."""


def _token_near_expiry(token: str, skew_s: int = 60) -> bool:
    """Return True if the JWT's `exp` claim is within `skew_s` of now.

    Uses only the b64-decoded payload, no signature verification — we trust
    the token as an opaque credential and only inspect the expiry timestamp
    locally to decide whether to refresh before the server would reject it.
    Returns False on any parse error so callers fall back to server-driven
    refresh.
    """
    import base64

    try:
        payload_b64 = token.split(".")[1]
        payload_b64 += "=" * (-len(payload_b64) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload_b64))
        exp = claims.get("exp")
        # Missing / non-positive exp → can't judge, treat as "not expired"
        # and let the server tell us (otherwise we'd force refresh on every
        # connect for opaque tokens that have no exp claim).
        if not isinstance(exp, (int, float)) or exp <= 0:
            return False
        return int(exp) - time.time() < skew_s
    except Exception:
        return False


class CloudChannel(BaseChannel):
    """Outbound WebSocket relay to WorkPilot Cloud Gateway."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        url: str,
        tenant_id: str,
        client_id: str,
        scope: str,
        login_method: Literal["auto", "browser", "wam", "device"] = "auto",
        login_port: int = 49215,
        allow_from: list[str] | None = None,
        auto_reconnect: bool = True,
        reconnect_max: int = 60,
        open_browser_on_connect: bool = False,
        on_post_login: Callable[[], None] | None = None,
        enable_github: bool = True,
        require_relay_auth: bool = False,
        bot_app_id: str = "",
    ) -> None:
        super().__init__(bus, allow_from)
        self._on_post_login = on_post_login
        self._url = url
        self._tenant_id = tenant_id
        self._client_id = client_id
        self._scope = scope
        self._login_method = login_method
        self._login_port = login_port
        self._auto_reconnect = auto_reconnect
        self._reconnect_max = reconnect_max

        self._open_browser_on_connect = open_browser_on_connect
        self._token: str | None = None
        self._running = False
        self._ws_connected = False  # True only while WebSocket handshake is live
        self._send_queue: asyncio.Queue[str] = asyncio.Queue(maxsize=500)
        self._connect_task: asyncio.Task | None = None
        self._browser_opened = False  # open browser only on first successful connect
        self._runtime: Any = None  # set by Runtime after construction
        self._ping_count = 0  # monotonic counter for ping/pong log correlation
        self._push_deliveries: dict[
            str, dict[str, bool]
        ] = {}  # push_ack results keyed by request_id
        self._push_events: dict[str, asyncio.Event] = {}  # push_ack waiters
        self._local_oid: str | None = None  # set by _capture_identity after MSAL login
        self._local_tid: str | None = None
        self._local_upn: str | None = None  # set by _capture_identity (UPN / preferred_username)
        self._local_email: str | None = None  # set by _capture_identity (email claim)
        self._local_github_id: str | None = None  # set by _resolve_github_identity
        self._local_github_login: str | None = None
        self._enable_github = enable_github
        self._require_relay_auth = require_relay_auth
        self._bot_app_id = bot_app_id
        self._github_identity_attempted = False  # True after definitive resolution outcome
        self._github_resolve_task: asyncio.Task | None = None  # in-flight guard
        self._conv_ref_store = ConvRefStore()
        self._last_auth_expired: float = -600.0  # ensures first auth_expired always passes
        self._validator: Any = None  # set in start(); see RelayValidator
        self._using_shared_app = False  # set True after fallback to aebc6443 succeeds

        # MSAL PublicClientApplication — persists token cache across reconnects.
        # Cache lives under ~/.workpilot/auth/ (ACL-protected on Windows,
        # chmod 0o700 on POSIX). All on-disk details are encapsulated in
        # :class:`_CacheStore`; load failures are already logged there, and
        # we intentionally keep the file around so a later run with the
        # right encryption key (keyring unlock, env var set, …) can still
        # use it.
        self._cache_path: Path | None = _CacheStore.path(client_id, broker=False)
        self._broker_enabled = False
        self._token_cache = _CacheStore.load(client_id, broker=False)
        broker_kwargs: dict[str, Any] = {}
        if login_method == "wam":
            from workpilot.utils.auth import _broker_kwargs

            broker_kwargs = _broker_kwargs()
            if broker_kwargs:
                self._broker_enabled = True
                logger.debug("Broker enabled ({})", list(broker_kwargs.keys())[0])
            else:
                logger.warning("login_method=wam but msal[broker] not installed; using browser")
                self._login_method = "browser"

        self._msal_app = msal.PublicClientApplication(
            client_id=client_id,
            authority=f"https://login.microsoftonline.com/{tenant_id}",
            token_cache=self._token_cache,
            **broker_kwargs,
        )

    def set_runtime(self, runtime: Any) -> None:
        """Set the Runtime reference for admin relay queries."""
        self._runtime = runtime

    def set_post_login_hook(self, hook: Callable[[], None] | None) -> None:
        """Set (or clear) the callback invoked after successful token acquisition."""
        self._on_post_login = hook

    @property
    def name(self) -> str:
        return ChannelType.CLOUD

    @property
    def _scopes(self) -> list[str]:
        """MSAL scopes list — empty when no explicit scope configured."""
        return [self._scope] if self._scope else []

    def get_push_delivery(self, request_id: str) -> dict[str, bool] | None:
        """Return and clear accumulated push delivery results for *request_id*.

        Multiple push_ack frames for the same request_id are merged (OR):
        once a sub-channel is marked delivered, it stays delivered.

        Retrieval is one-shot: the stored delivery state for *request_id* is
        removed from the internal cache when this method is called.
        """
        self._push_events.pop(request_id, None)  # clean up waiter
        return self._push_deliveries.pop(request_id, None)

    def wait_push_delivery(self, request_id: str) -> asyncio.Event:
        """Return an ``asyncio.Event`` that is set when a push_ack arrives.

        The caller should ``await asyncio.wait_for(event.wait(), timeout=N)``
        then call ``get_push_delivery()`` to retrieve the results.
        """
        evt = self._push_events.get(request_id)
        if evt is None:
            evt = asyncio.Event()
            self._push_events[request_id] = evt
            # If ack already arrived before wait was registered, set immediately
            if request_id in self._push_deliveries:
                evt.set()
        return evt

    @property
    def is_connected(self) -> bool:
        """True only while the WebSocket handshake is live (not during reconnect backoff)."""
        return self._ws_connected

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def has_cached_credentials(self) -> bool:
        """Return True if a cached session likely exists (fast, no network).

        Used by the runtime to decide whether to auto-connect on startup.
        Checks broker + browser caches across every cloud-capable client
        (Primary / Shared / Teams Toolkit — same set as
        :meth:`_silent_fallback_chain`). No token refresh is attempted
        here; that happens in :meth:`_acquire_token_sync`.
        """
        return any(
            _CacheStore.has_session(cid)
            for cid in (self._client_id, SHARED_ENTRA_CLIENT_ID, TEAMS_TOOLKIT_CLIENT_ID)
        )

    def pre_acquire_token(self, *, silent_only: bool = False) -> bool:
        """Acquire token synchronously — call on the **main thread** before
        ``asyncio.run()`` so that macOS WAM broker can use native OS dialogs.

        On macOS, ``pymsalruntime`` requires ``acquire_token_interactive`` to
        run on the main thread (AppKit / SSO Extension constraint).  Because
        ``start()`` dispatches to a thread-pool via ``run_in_executor``, the
        broker always fails there.  Calling this method from the CLI entry
        point (before the event loop starts) side-steps the issue.

        After this call, ``start()`` detects ``self._token`` is already set
        and skips the executor-based acquisition.

        On Windows / Linux this is also safe to call — it simply moves the
        (potentially interactive) auth step to before the event loop.

        Args:
            silent_only: If *True*, only attempt cached/silent token refresh
                (no interactive login menu).  Use this for background auto-
                connect where interrupting the user is undesirable.

        Returns:
            *True* if a token was acquired, *False* otherwise.
        """
        if self._token:
            return True
        if silent_only:
            # Try cached credentials only — no interactive menu.
            self._token = self._try_silent_all()
        else:
            self._token = self._acquire_token_sync()
        return bool(self._token)

    async def start(self) -> None:
        if self._running:
            return  # already started — prevent duplicate connection tasks
        self._running = True

        # Acquire initial token — may raise RuntimeError("Cloud sign-in skipped")
        # if the user selects Skip in the interactive menu.
        #
        # When pre_acquire_token() was already called on the main thread
        # (required on macOS for WAM broker), self._token is set and we skip
        # the executor dispatch entirely.
        if not self._token:
            self._token = await asyncio.get_running_loop().run_in_executor(
                None, self._acquire_token_sync
            )

        # Post-login hook (e.g. Teams app installation check) — best-effort.
        # Runs on the main thread (not executor) because hooks may do
        # interactive terminal I/O (stdin key handling, ANSI cursor movement).
        if self._on_post_login:
            try:
                self._on_post_login()
            except Exception as exc:
                logger.debug("Post-login hook failed; continuing startup: {}", exc)

        # Create relay validator — reads identity dynamically from this channel
        from workpilot.security.relay_validator import RelayValidator

        self._validator = RelayValidator(
            channel=self,
            require=self._require_relay_auth,
        )

        # Subscribe to outbound bus messages
        self._bus.on_outbound(self._handle_outbound)

        # Launch connection loop as background task
        self._connect_task = asyncio.create_task(self._connect_loop(), name="cloud-channel-loop")
        logger.info("Cloud channel started -> {}", self._url)

    async def stop(self) -> None:
        self._running = False
        if self._connect_task and not self._connect_task.done():
            self._connect_task.cancel()
        if self._github_resolve_task and not self._github_resolve_task.done():
            self._github_resolve_task.cancel()
        self._github_resolve_task = None
        # Drain the send queue so callers aren't stuck
        while not self._send_queue.empty():
            try:
                self._send_queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        logger.info("Cloud channel stopped")

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Enqueue a response frame (called by ChannelManager).

        Approval cards are sent as ``notification`` frames so the gateway does
        NOT delete the reply context — the context must stay alive until the
        tool result is delivered after the user approves/denies.
        """
        # Approval cards use "notification" so the gateway keeps deleteContext=false,
        # preserving the reply context until the final tool result is delivered.
        # Callers pass keep_context=True (via kwargs) to opt in.
        frame_type = "notification" if kwargs.get("keep_context") else "response"

        # Non-routable channel_id (e.g. "scheduler:xxx") → send as a "push"
        # frame.  Push frames don't target a specific conversation; the gateway
        # broadcasts them to the connected user's active clients.
        _INTERNAL_PREFIXES = ("scheduler:", "agent-", "cron:", "copilot-", "claude-")
        is_non_routable = (
            any(channel_id.startswith(p) for p in _INTERNAL_PREFIXES)
            or channel_id == self.name  # bare "cloud" from notify tool without conversation context
        )

        if is_non_routable:
            data: dict[str, Any] = {
                "type": "push",
                "content": content,
                "format": kwargs.get("format", "markdown"),
            }
            push_target = kwargs.get("push_target")  # "teams" | "webchat" | None
            if push_target:
                data["target"] = push_target
            push_request_id = kwargs.get("push_request_id")
            if push_request_id:
                data["request_id"] = push_request_id
            title = kwargs.get("title")
            if title:
                data["title"] = title
            # Attach stored conv_ref for stateless Teams proactive messaging.
            # Skip when target is explicitly "webchat" (no Teams routing needed).
            if self._local_oid and push_target != "webchat":
                ref = self._conv_ref_store.get(self._local_oid)
                if ref:
                    data["conv_ref"] = ref
        else:
            data = {
                "type": frame_type,
                "channel_id": channel_id,
                "content": content,
                "format": kwargs.get("format", "markdown"),
            }
            thread_id = kwargs.get("thread_id")
            if thread_id:
                data["thread_id"] = thread_id

        frame = json.dumps(data, ensure_ascii=False)
        await self._send_queue.put(frame)

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:
        """Send a typing indicator via WebSocket."""
        frame = json.dumps({"type": "typing", "channel_id": channel_id}, ensure_ascii=False)
        await self._send_queue.put(frame)

    # ── Outbound bus handler ─────────────────────────────────────────────────

    async def _handle_outbound(self, msg: OutboundMessage | StreamingChunk) -> None:
        """Route streaming chunks from the agent → WebSocket send queue.

        OutboundMessage (non-streaming responses) are handled by ChannelManager
        which calls CloudChannel.send() — registering both handlers would send
        each response twice and cause reply_context_expired errors on the second.
        Only StreamingChunk is handled here because ChannelManager.send() has no
        streaming-chunk path.
        """
        if msg.channel != self.name:
            return

        if not isinstance(msg, StreamingChunk):
            return

        frame = json.dumps(
            {
                "type": "chunk",
                "channel_id": msg.channel_id,
                "content": msg.content,
                "chunk_type": msg.chunk_type,
                "done": msg.done,
            },
            ensure_ascii=False,
        )
        await self._send_queue.put(frame)

    # ── Connection loop ──────────────────────────────────────────────────────

    async def _connect_loop(self) -> None:
        """Main loop: connect → run → reconnect with exponential backoff."""
        backoff = 1
        while self._running:
            try:
                await self._run_connection()
                backoff = 1  # reset on clean close
            except asyncio.CancelledError:
                break
            except Exception as exc:
                if not self._running:
                    break

                # websockets follows HTTP redirects and raises InvalidURI when the
                # Location header has an https:// scheme (not wss://).  This happens
                # when the server redirects the WebSocket upgrade to an auth page
                # (e.g. /Account/AccessDenied) instead of returning 401/403.
                # Force interactive re-authentication in this case rather than
                # silently refreshing a token that the server is already rejecting.
                is_auth_redirect = isinstance(exc, websockets.exceptions.InvalidURI) and (
                    "AccessDenied" in str(exc) or "login" in str(exc).lower()
                )
                # websockets ≤13: RejectHandshake with exc.status_code
                # websockets ≥14: InvalidStatus with exc.response.status_code
                _status = getattr(exc, "status_code", None) or getattr(
                    getattr(exc, "response", None), "status_code", None
                )
                _rejection_types = (websockets.exceptions.InvalidStatus,)
                if hasattr(websockets.exceptions, "RejectHandshake"):
                    _rejection_types = (*_rejection_types, websockets.exceptions.RejectHandshake)  # type: ignore[assignment]
                is_auth_rejection = isinstance(exc, _rejection_types) and _status in (401, 403)

                if is_auth_redirect or is_auth_rejection:
                    logger.warning(
                        "Cloud gateway rejected connection (auth failure: {}). Re-authenticating…",
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, self._reconnect_max)
                    # Route through _refresh_for_reconnect which handles macOS
                    # main-thread constraint (WAM broker) and bypass-token mode.
                    try:
                        await self._refresh_for_reconnect()
                    except Exception as auth_err:
                        logger.error("Re-authentication failed: {}", auth_err)
                elif isinstance(exc, _SilentRefreshExhaustedError):
                    # Pre-connect refresh already exhausted every silent
                    # path and raised deliberately. Don't call refresh
                    # again — it would fail the same way. Just back off
                    # and retry; the stale-token check will raise again
                    # unless something external (broker PRT resync, user
                    # restart, etc.) changes the state.
                    logger.warning(
                        "Cloud silent refresh exhausted: {}. Waiting {}s before retry…",
                        exc,
                        backoff,
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, self._reconnect_max)
                else:
                    if isinstance(exc, TimeoutError):
                        logger.warning(
                            "Cloud gateway opening handshake timed out. "
                            "Check gateway reachability/DNS/proxy and IPv6 routing. "
                            "Reconnecting in {}s…",
                            backoff,
                        )
                    logger.warning(
                        "Cloud gateway connection lost: {}. Reconnecting in {}s…", exc, backoff
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, self._reconnect_max)

                    # Refresh token before reconnecting — handles macOS
                    # main-thread constraint for WAM broker silent refresh.
                    try:
                        await self._refresh_for_reconnect()
                    except Exception as auth_err:
                        logger.error("Token refresh failed: {}", auth_err)

    async def _run_connection(self) -> None:
        """Single WebSocket connection lifecycle."""
        # Proactive expiration check: WAM broker with `scopes=[]` returns the
        # cached id_token without triggering a PRT refresh, so expired tokens
        # can linger in self._token indefinitely and drive 401 loops. Parse
        # the JWT exp claim and force a real refresh when we're within 60s.
        if self._token and _token_near_expiry(self._token, skew_s=60):
            logger.debug("Cloud token near/past expiry — refreshing before connect")
            try:
                await self._refresh_for_reconnect()
            except Exception as auth_err:
                logger.warning("Pre-connect token refresh failed: {}", auth_err)

        # Guard against a missing or already-expired token before building
        # the Bearer header (`skew_s=0` — we only block on tokens that are
        # past their exp, not merely near it; near-expiry was already
        # refreshed above). Cases that land us here:
        #   • `auth_expired` frame handler cleared `self._token = None`
        #     (see `_dispatch`), and the follow-up refresh silently failed.
        #   • Pre-connect refresh above ran but every silent path was
        #     exhausted; `_refresh_for_reconnect` logs and returns without
        #     updating `self._token`, leaving the old (now past-exp) value.
        # In either case the handshake would be a guaranteed 401 — raise a
        # dedicated signal so `_connect_loop` just backs off instead of
        # re-running the same failing refresh.
        if not self._token or _token_near_expiry(self._token, skew_s=0):
            raise _SilentRefreshExhaustedError(
                "Cloud token unavailable or refresh exhausted; skipping "
                "handshake to avoid a guaranteed 401 loop. Restart the "
                "client and re-login to recover."
            )

        headers = {"Authorization": f"Bearer {self._token}"}

        async with websockets.connect(
            self._url,
            additional_headers=headers,
            ping_interval=None,  # server manages heartbeat via ping/pong frames
            happy_eyeballs_delay=0.25,  # race IPv6/IPv4 to avoid stalled single-stack attempts
            interleave=1,
            open_timeout=15,
            close_timeout=5,
        ) as ws:
            self._ws_connected = True
            logger.success("Connected to Cloud Gateway")
            self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})

            recv_task = asyncio.create_task(self._recv_loop(ws))
            send_task = asyncio.create_task(self._send_loop(ws))

            try:
                done, pending = await asyncio.wait(
                    [recv_task, send_task],
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass
                # Re-raise any exception from the completed task
                for task in done:
                    if not task.cancelled():
                        task.result()
            finally:
                self._ws_connected = False
                recv_task.cancel()
                send_task.cancel()

    async def _recv_loop(self, ws) -> None:
        """Process incoming frames from the gateway."""
        async for raw in ws:
            try:
                frame = json.loads(raw)
            except json.JSONDecodeError:
                logger.warning("Malformed frame from gateway: {!r:.100}", raw)
                continue

            await self._dispatch(frame)

    async def _send_loop(self, ws) -> None:
        """Drain send queue → write frames to WebSocket."""
        while True:
            frame = await self._send_queue.get()
            try:
                await ws.send(frame)
            except Exception:
                # Put it back so it's not lost on reconnect
                await self._send_queue.put(frame)
                raise

    # ── Frame dispatch ───────────────────────────────────────────────────────

    async def _dispatch(self, frame: dict[str, Any]) -> None:
        ftype = frame.get("type")

        if ftype == "connected":
            count = frame.get("buffered_count", 0)
            logger.debug("Gateway handshake complete. Buffered messages: {}", count)
            if self._open_browser_on_connect and not self._browser_opened:
                self._browser_opened = True
                web_url = webchat_url_from_connect(self._url)
                loop = asyncio.get_running_loop()
                loop.run_in_executor(None, webbrowser.open, web_url)
                logger.info("Opening web chat: {}", web_url)
            # Resolve GitHub identity and register — fire-and-forget so
            # frame processing (e.g., buffered replay) isn't blocked by
            # a potentially slow GitHub API call.
            if self._enable_github:
                if self._local_github_id:
                    await self._send_register_identity()
                elif not self._github_identity_attempted and not self._github_resolve_task:
                    self._github_resolve_task = asyncio.create_task(
                        self._resolve_and_register_github()
                    )

        elif ftype == "identity_registered":
            if frame.get("provider") != "github":
                return
            status = frame.get("status")
            if status == "ok":
                logger.info("GitHub identity registered with Gateway")
            else:
                reason = frame.get("reason", "unknown")
                logger.warning("GitHub identity rejected by Gateway: {}", reason)
                self._local_github_id = None
                self._local_github_login = None

        elif ftype == "message":
            if not self._validator.validate_message(frame):
                logger.warning("Rejected message: relay token validation failed")
                return
            await self._on_message(frame)

        elif ftype == "ping":
            self._ping_count += 1
            await self._send_queue.put(json.dumps({"type": "pong"}, ensure_ascii=False))
            logger.debug(
                "Ping #{} -> pong  [url={} queue_depth={}]",
                self._ping_count,
                self._url,
                self._send_queue.qsize(),
            )

        elif ftype == "buffered_start":
            logger.info("Replaying {} buffered message(s)…", frame.get("count", "?"))

        elif ftype == "buffered_end":
            logger.info("Buffered message replay complete")

        elif ftype == "admin_request":
            caller = self._validator.validate_admin(frame)
            if caller is None:
                logger.warning("Rejected admin_request: relay token validation failed")
                # Send 403 so the Gateway gets a fast error instead of a 30s timeout.
                # Use 403 (not 401) to avoid triggering SPA auth-reset logic.
                request_id = frame.get("request_id", "")
                if request_id:
                    body = {"error": "relay_auth_failed", "message": "Relay auth validation failed"}
                    err = json.dumps(
                        {
                            "type": "admin_response",
                            "request_id": request_id,
                            "status": 403,
                            "body": json.dumps(body, ensure_ascii=False),
                        },
                        ensure_ascii=False,
                    )
                    await self._send_queue.put(err)
                return
            # NOTE: not cryptographically verified in Step 1 (stub validator).
            # Step 3 adds real JWT verification for this value.
            frame["relay_caller_oid"] = caller
            await self._on_admin_request(frame)

        elif ftype == "approval_response":
            # This frame type is NOT generated by the gateway today —
            # WebChat approvals arrive as type=message ("/approve <id>").
            # Validating here is defense-in-depth against injection.
            if not self._validator.validate_message(frame):
                logger.warning("Rejected approval_response: relay token validation failed")
                return
            await self._on_approval_response(frame)

        elif ftype == "push_ack":
            rid = frame.get("request_id", "")
            if rid:
                existing = self._push_deliveries.get(rid, {})
                # Merge: once delivered, stays delivered (multiple pushes for same approval)
                existing["webchat"] = existing.get("webchat", False) or bool(
                    frame.get("webchat_delivered")
                )
                existing["teams"] = existing.get("teams", False) or bool(
                    frame.get("teams_delivered")
                )
                # Capture Teams card ActivityId for cross-channel card updates
                teams_activity_id = frame.get("teams_activity_id")
                if teams_activity_id:
                    existing["teams_activity_id"] = teams_activity_id
                self._push_deliveries[rid] = existing
                # Size cap: evict oldest entries on insert to prevent
                # unbounded growth from acks that are never retrieved.
                _MAX = 1000
                if len(self._push_deliveries) > _MAX:
                    for k in list(self._push_deliveries.keys())[
                        : len(self._push_deliveries) - _MAX
                    ]:
                        del self._push_deliveries[k]
                # Signal any waiter registered via wait_push_delivery()
                evt = self._push_events.get(rid)
                if evt:
                    evt.set()
                logger.debug(
                    "Push ack {}: webchat={} teams={}",
                    rid,
                    existing["webchat"],
                    existing["teams"],
                )

        elif ftype == "error":
            code = frame.get("code", "unknown")
            msg = frame.get("message", "")
            _AUTH_EXPIRED_COOLDOWN = 300  # seconds between accepted auth_expired frames

            # reply_context_expired is expected when a response arrives after the
            # Teams reply window closes (e.g. long-running tool). Log at DEBUG.
            if code == "reply_context_expired":
                logger.debug("Gateway error [{}]: {}", code, msg)
            elif code == "auth_expired":
                # Rate limit before logging to prevent log spam from injected frames.
                now = time.monotonic()
                if now - self._last_auth_expired < _AUTH_EXPIRED_COOLDOWN:
                    logger.debug("Ignoring rapid auth_expired (rate limited)")
                    return
                self._last_auth_expired = now
                logger.warning("Gateway error [{}]: {}", code, msg)
                # Force token refresh on next reconnect
                self._token = None
            else:
                logger.warning("Gateway error [{}]: {}", code, msg)

        elif ftype == "ticket_request":
            await self._on_ticket_request(frame)

        else:
            logger.debug("Unhandled frame type: {}", ftype)

    async def _on_ticket_request(self, frame: dict[str, Any]) -> None:
        """Generate a signing key for a WebChat E2E session."""
        request_id = frame.get("request_id")
        oid = frame.get("oid")
        if not isinstance(request_id, str) or not request_id or not isinstance(oid, str) or not oid:
            logger.warning("Malformed ticket_request: missing request_id or oid")
            return
        # Defense-in-depth: only mint keys for our own OID.
        if self._local_oid and oid != self._local_oid:
            logger.warning(
                "Rejecting ticket_request: oid mismatch (requested={} local={})",
                oid,
                self._local_oid,
            )
            return
        signing_key, key_id = self._validator.create_signing_key(oid)
        await self._send_queue.put(
            json.dumps(
                {
                    "type": "ticket_response",
                    "request_id": request_id,
                    "signing_key": signing_key,
                    "key_id": key_id,
                },
                ensure_ascii=False,
            )
        )
        logger.debug("Signing key issued: key_id={} oid={}", key_id, oid)

    async def _on_message(self, frame: dict[str, Any]) -> None:
        """Publish an inbound message frame to the bus."""
        content = frame.get("content", "")
        content_format = frame.get("content_format", "text").lower()

        # Strip <at>…</at> @mention XML BEFORE HTML→Markdown conversion,
        # otherwise html_to_markdown strips the tags but leaves the text.
        content = re.sub(r"<at>[^<]*</at>", "", content).strip()

        # Convert HTML rich text to Markdown
        if content_format == "html":
            content = html_to_markdown(content)
            content_format = "markdown"

        channel_id = frame.get("channel_id", "")
        sender_id = frame.get("sender_id", "")
        sender_name = frame.get("sender_name", sender_id)
        thread_id = frame.get("thread_id")
        session_key = frame.get("session_key")
        metadata = {**frame.get("metadata", {})}
        metadata["content_format"] = content_format

        # Allow-list check must happen before any approval fast-path
        # and before storing conv_ref (don't persist routing data from blocked senders).
        if not self.is_allowed(sender_id):
            logger.warning("Message blocked from {} (not in allow_from)", sender_id)
            return

        # Store conv_ref from Teams messages for proactive push later.
        conv_ref = metadata.get("conv_ref")
        if metadata.get("source") == "cloud_teams" and isinstance(conv_ref, dict):
            cr_surl = conv_ref.get("service_url", "")
            cr_cid = conv_ref.get("conversation_id", "")
            if cr_surl and cr_cid and sender_id:
                self._conv_ref_store.upsert(sender_id, cr_surl, cr_cid)

        # Metadata approval fast-path: Teams card button or slash command sends
        # approval_action in metadata — resolve directly, bypassing the blocked queue.
        approval_action = metadata.get("approval_action")
        approval_request_id = metadata.get("approval_request_id")
        if approval_action and approval_request_id:
            await self._on_approval_response(
                {
                    "action": approval_action,
                    "request_id": approval_request_id,
                    "sender_id": sender_id,
                }
            )
            logger.debug(
                "Cloud approval action={} request_id={}", approval_action, approval_request_id
            )
            return

        if not content:
            logger.debug("Cloud message with empty content from {} — ignored", sender_id)
            return

        # Approval keyword / slash-command fast-path — bypass the blocked agent queue.
        cl = content.lower()  # content already stripped via re.sub earlier
        action: str | None = None
        req_id = ""

        parts = content.split(maxsplit=1)
        # /approve <id> · /deny <id> · /always <id>  (with explicit request_id)
        if cl.startswith("/approve ") and len(parts) == 2:
            action, req_id = "approve", parts[1]
        elif cl.startswith("/deny ") and len(parts) == 2:
            action, req_id = "deny", parts[1]
        elif cl.startswith("/always ") and len(parts) == 2:
            action, req_id = "always", parts[1]
        # bare keyword (no id — runtime resolves any single pending approval)
        # Only intercept when there IS a pending approval; otherwise pass
        # through to the agent so "yes"/"no" in normal conversation works.
        elif cl in {"yes", "y", "approve", "/approve"}:
            action = "approve"
        elif cl in {"no", "n", "deny", "/deny"}:
            action = "deny"
        elif cl in {"always", "a", "/always"}:
            action = "always"

        if action and req_id:
            # Explicit /approve <id> — always route to approval
            pass
        elif action:
            # Bare keyword — only intercept if there's a pending approval.
            # Otherwise "yes"/"no" in normal conversation gets swallowed.
            has_pending = False
            if self._runtime and hasattr(self._runtime, "approval_manager"):
                has_pending = bool(self._runtime.approval_manager.get_pending())
            if not has_pending:
                action = None

        if action:
            await self._on_approval_response(
                {"action": action, "request_id": req_id, "sender_id": sender_id}
            )
            logger.debug("Cloud approval action={} request_id={}", action, req_id or "(any)")
            return

        # Interrupt fast-path: /cancel bypasses the inbound queue
        if cl == "/cancel":
            interrupted = False
            sid = session_key or f"cloud_{sender_id}"
            if self._runtime and hasattr(self._runtime, "agent"):
                interrupted = self._runtime.agent.interrupt(sid)
            logger.info(
                "Cloud interrupt for session_key={} interrupted={}", session_key, interrupted
            )
            if not interrupted:
                # Agent idle — send feedback so the user isn't left with silence
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=ChannelType.CLOUD,
                        channel_id=channel_id,
                        content="Nothing to interrupt.",
                        thread_id=thread_id,
                    )
                )
            # If interrupted: agent loop will deliver "Interrupted." response
            return

        msg = InboundMessage(
            channel=self.name,
            channel_id=channel_id,
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            content_format=content_format,
            thread_id=thread_id,
            session_key=session_key,
            timestamp=frame.get("timestamp"),
            metadata=metadata,
        )
        await self._bus.publish_inbound(msg)
        logger.debug(
            "Cloud message channel_id={} sender={} len={}", channel_id, sender_id, len(content)
        )

    async def _on_approval_response(self, frame: dict[str, Any]) -> None:
        """Resolve an approval request directly (bypasses inbound queue).

        Approval responses must NOT go through the inbound message queue
        because the agent loop is blocked in the pre_tool_use hook waiting
        for resolution — routing through the queue would deadlock.
        """
        action = frame.get("action", "")
        request_id = frame.get("request_id", "")
        if not action:
            logger.warning("Malformed approval_response frame: {}", frame)
            return
        # Empty request_id is valid — runtime resolves any single pending approval

        sender_id = frame.get("sender_id", "unknown")

        # Resolve directly via the approval manager on the bus event
        self._bus.events.emit(
            EventType.APPROVAL_RESOLVED,
            {
                "request_id": request_id,
                "action": action,
                "resolver": sender_id,
            },
        )
        logger.debug("Approval response: action={} request_id={}", action, request_id)

    async def _on_admin_request(self, frame: dict[str, Any]) -> None:
        """Handle an admin data query from the Cloud Gateway.

        Routes the request to the local WebServer's API handlers in-process
        and sends back an admin_response frame with the result.
        """
        request_id = frame.get("request_id", "")
        endpoint = frame.get("endpoint", "")
        if not request_id or not endpoint:
            logger.warning("Malformed admin_request frame: {}", frame)
            return

        status = 200
        body: Any = {"error": "not_found", "message": f"Unknown endpoint: {endpoint}"}

        try:
            result = await self._handle_admin_endpoint(endpoint, frame)
            if result is not None:
                status = result.get("status", 200)
                body = result.get("body", body)
            else:
                status = 404
        except Exception as exc:
            logger.error("Admin request error endpoint={}: {}", endpoint, exc)
            status = 500
            body = {"error": "internal_error", "message": str(exc)}

        response_frame = json.dumps(
            {
                "type": "admin_response",
                "request_id": request_id,
                "status": status,
                "body": json.dumps(body, ensure_ascii=False) if not isinstance(body, str) else body,
            },
            ensure_ascii=False,
        )
        await self._send_queue.put(response_frame)

    def _build_channels(self, rt: Any) -> list[dict[str, Any]]:
        """Build the channel list for /api/status — mirrors server.py logic."""
        from workpilot.utils.helpers import local_web_url, webchat_url_from_connect

        web_cfg = rt.config.channels.web
        web_url = local_web_url(web_cfg.host, web_cfg.port)

        channels: list[dict[str, Any]] = []
        for name in rt.channel_manager._channels:
            if name == ChannelType.CLOUD:
                continue
            if name in (ChannelType.WEB, "gateway"):
                channels.append({"name": name, "url": web_url, "connected": True})
            else:
                channels.append({"name": name, "url": None, "connected": True})

        cloud_cfg = rt.config.channels.cloud
        if cloud_cfg.enabled and cloud_cfg.url:
            try:
                wc_url: str | None = webchat_url_from_connect(cloud_cfg.url)
            except ValueError:
                wc_url = None
            channels.append(
                {"name": "Web Chat (Cloud)", "url": wc_url, "connected": self._ws_connected}
            )
            from workpilot.utils.helpers import teams_bot_url

            teams_url = teams_bot_url(cloud_cfg.bot_app_id) or None
            channels.append(
                {
                    "name": "Teams (Cloud)",
                    "url": teams_url,
                    "connected": self._ws_connected and bool(teams_url),
                }
            )
        return channels

    async def _handle_admin_endpoint(
        self, endpoint: str, frame: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Dispatch an admin request to the Runtime via shared handlers.

        Returns {"status": int, "body": dict|str} or None if not found.
        """
        rt = self._runtime
        if rt is None:
            return {"status": 503, "body": {"error": "runtime_unavailable"}}

        from workpilot.web.api_handlers import (
            handle_approval_resolve,
            handle_approvals,
            handle_audit,
            handle_config,
            handle_cost,
            handle_estop,
            handle_health,
            handle_memory,
            handle_models,
            handle_reset,
            handle_session_detail,
            handle_sessions,
            handle_skills,
            handle_status,
            handle_system_prompts,
            handle_tools,
            handle_user_settings,
        )

        method = frame.get("method", "GET")

        # ── GET ───────────────────────────────────────────────────────
        if method == "GET":
            routes: dict[str, Any] = {
                "/api/status": lambda: handle_status(rt, channels=self._build_channels(rt)),
                "/api/health": lambda: handle_health(rt),
                "/api/sessions": lambda: handle_sessions(rt),
                "/api/tools": lambda: handle_tools(rt),
                "/api/skills": lambda: handle_skills(rt),
                "/api/memory": lambda: handle_memory(rt),
                "/api/audit": lambda: handle_audit(rt),
                "/api/cost": lambda: handle_cost(rt),
                "/api/models": lambda: handle_models(rt),
                "/api/approvals": lambda: handle_approvals(rt),
                "/api/system-prompts": lambda: handle_system_prompts(rt),
                "/api/user-settings": lambda: handle_user_settings(rt),
            }
            if endpoint in routes:
                return {"status": 200, "body": routes[endpoint]()}

            if endpoint.startswith("/api/sessions/"):
                from urllib.parse import unquote

                session_id = unquote(endpoint[len("/api/sessions/") :])
                detail = handle_session_detail(rt, session_id)
                return (
                    {"status": 200, "body": detail}
                    if detail
                    else {"status": 404, "body": {"error": "not_found"}}
                )

            if endpoint == "/api/config":
                result = handle_config(rt)
                return (
                    {"status": 200, "body": result}
                    if result
                    else {"status": 500, "body": {"error": "Failed to serialize config."}}
                )

        # ── POST ──────────────────────────────────────────────────────
        if method == "POST":
            body_str = frame.get("body")
            body_data: dict[str, Any] = {}
            if body_str:
                try:
                    body_data = json.loads(body_str)
                except (json.JSONDecodeError, TypeError):
                    pass

            if endpoint == "/api/estop":
                return {
                    "status": 200,
                    "body": handle_estop(rt, body_data.get("reason", "admin dashboard")),
                }
            if endpoint == "/api/reset":
                return {"status": 200, "body": handle_reset(rt, body_data.get("actor", "admin"))}
            if endpoint.startswith("/api/approvals/") and endpoint.endswith("/resolve"):
                req_id = endpoint.split("/")[3] if len(endpoint.split("/")) >= 5 else ""
                code, body = handle_approval_resolve(
                    rt, req_id, body_data.get("approved", False), body_data.get("resolver", "admin")
                )
                return {"status": code, "body": body}

        return None

    # ── Auth ─────────────────────────────────────────────────────────────────

    def _acquire_token_sync(self) -> str:
        """Acquire token — silent if cached, then menu-driven interactive.

        Flow: try silent (broker or browser cache) → menu.
        """
        # 1. Try silent — check both broker and browser caches.
        token = self._try_silent_all()
        if token:
            return token

        # 2. Show login menu and execute the user's choice.
        return self._execute_login_choice()

    def _silent_fallback_chain(self) -> list[tuple[str, str, bool]]:
        """Build the ordered client chain for silent token refresh.

        Each entry is ``(client_id, authority, switch_to_shared_on_success)``.

        Normal case (``_using_shared_app=False``):
          1. Primary cloud client — tenant-specific authority.
          2. Shared MCP — success triggers a permanent switch so subsequent
             MCP flows keep working (MCP servers expect the shared
             client_id's consents).
          3. Teams Toolkit — appended when EITHER of its caches exists
             on disk (broker, populated out-of-band by
             ``workpilot teams install``; or browser, if the user has
             done a browser PKCE login with the Toolkit client). Both
             paths silently mint the cloud scope via pre-auth. One-off
             cloud token; never triggers a shared-app switch because
             Toolkit lacks MCP consents.

        After ``_switch_to_shared_app`` (``_using_shared_app=True``):
          ``_switch_to_shared_app`` updates ``self._cache_path`` and
          ``self._msal_app`` (to point at the shared client), but
          **intentionally leaves** ``self._client_id`` and ``self._scope``
          unchanged — the cloud scope stays constant across the session
          so every token has the same audience. The active app is
          therefore known only through the ``_using_shared_app`` flag.
          In this state the chain emits SHARED directly (with the
          ``organizations`` authority used by the switch), skips the
          primary retry entirely, then optionally adds Toolkit.
        """
        chain: list[tuple[str, str, bool]] = []
        if self._using_shared_app:
            chain.append(
                (
                    SHARED_ENTRA_CLIENT_ID,
                    "https://login.microsoftonline.com/organizations",
                    False,
                )
            )
        else:
            chain.append(
                (
                    self._client_id,
                    f"https://login.microsoftonline.com/{self._tenant_id}",
                    False,
                )
            )
            chain.append(
                (
                    SHARED_ENTRA_CLIENT_ID,
                    "https://login.microsoftonline.com/organizations",
                    True,
                )
            )
        # Include Toolkit when EITHER cache exists (broker or browser) — both
        # paths silently mint the cloud scope via pre-auth. Matches the set
        # that `has_cached_credentials` reports, so auto-connect and the
        # actual silent-refresh chain agree on Toolkit's availability.
        toolkit_available = _CacheStore.exists(
            TEAMS_TOOLKIT_CLIENT_ID, broker=True
        ) or _CacheStore.exists(TEAMS_TOOLKIT_CLIENT_ID, broker=False)
        if toolkit_available:
            chain.append(
                (
                    TEAMS_TOOLKIT_CLIENT_ID,
                    "https://login.microsoftonline.com/organizations",
                    False,
                )
            )
        return chain

    def _try_silent_all(self) -> str | None:
        """Try silent token acquisition across the full fallback chain.

        For each ``(cid, authority, switch_on_success)`` entry from
        :meth:`_silent_fallback_chain`, attempts broker (PRT refresh) then
        browser cache (refresh_token). First success wins.

        Design invariant: **every attempt requests the same
        ``self._scope``** — the configured cloud resource. This is what
        lets Primary / Shared / Toolkit all yield an access_token with
        the same audience (``aud = primary-cloud-client``); Shared and
        Toolkit work because they are pre-authorized on the Primary
        resource registration and PRT refresh bypasses user consent.
        Changing scope per-cid or per-state would produce tokens with
        inconsistent audiences and defeat the unified-aud guarantee.
        """
        from workpilot.utils.auth import _broker_kwargs

        bkw = _broker_kwargs()

        for cid, authority, switch_on_success in self._silent_fallback_chain():
            # Broker (WAM / PRT) path. A real resource scope is mandatory:
            # broker with `scopes=[]` returns the cached id_token without
            # contacting Entra, so expired tokens linger and drive 401 loops.
            # With a real scope, the broker does a PRT → Entra exchange that
            # returns a freshly signed access_token every time.
            if bkw and self._scope:
                token = self._try_silent_one(cid, authority, bkw, [self._scope])
                if token:
                    if switch_on_success:
                        self._switch_to_shared_app(enable_broker=True)
                    return token

            # Browser cache (refresh_token) path. Skip when no browser cache
            # exists for this client (Toolkit in practice — its broker is
            # populated by `workpilot teams install`, never browser).
            if _CacheStore.exists(cid, broker=False) and self._scope:
                token = self._try_silent_one(cid, authority, {}, [self._scope])
                if token:
                    if switch_on_success:
                        self._switch_to_shared_app()
                    return token

        return None

    def _try_silent_one(
        self,
        client_id: str,
        authority: str,
        broker_kwargs: dict[str, Any],
        scopes: list[str],
    ) -> str | None:
        """Try silent acquisition from one cached session.

        The cache file is resolved internally from ``(client_id,
        broker=bool(broker_kwargs))`` via :class:`_CacheStore`, so load
        and persist always target the same file — no room for caller
        mis-wiring.
        """
        from workpilot.utils.auth import _persist_cache, _try_silent_broker

        broker = bool(broker_kwargs)
        cache_path = _CacheStore.path(client_id, broker=broker)

        if broker:
            # Broker (WAM): PRT-based silent refresh via shared helper.
            result = _try_silent_broker(client_id, authority, broker_kwargs, cache_path, scopes)
            if result:
                self._capture_identity(result)
                # Prefer access_token: when broker refreshes across different
                # client_ids (primary / shared / Teams Toolkit) for the same
                # cloud scope, only the access_token has a consistent
                # `aud=389f98ef` that matches the Gateway's ValidAudiences.
                # The id_token's `aud` is the issuing client_id — Toolkit's
                # id_token would be rejected by the Gateway because its
                # client_id is not in AzureAd:LegacyAudiences.
                return str(result.get("access_token") or result.get("id_token", ""))
            return None

        # Browser path: acquire_token_silent with RefreshToken. Load goes
        # through `_CacheStore` so the naming convention stays encapsulated;
        # `_persist_cache` still takes a Path because it's shared with
        # `utils/auth.py`. Both target the same file via `cache_path` above.
        token_cache = _CacheStore.load(client_id, broker=False)
        app = msal.PublicClientApplication(client_id, authority=authority, token_cache=token_cache)
        accounts = app.get_accounts()
        if not accounts:
            return None

        # Try each account — caches occasionally accumulate stale entries
        # (e.g. an old identity-only login without a refresh_token lingers
        # beside the current full login). Hard-coding `accounts[0]` would
        # silent-fail whenever the stale account sorts first. Iterate and
        # take the first one that actually yields a token.
        browser_result: dict[str, Any] | None = None
        for account in accounts:
            candidate = app.acquire_token_silent(scopes, account=account)
            if candidate and "access_token" in candidate:
                browser_result = candidate
                break

        # Fallback for pre-migration caches: the refresh_token was issued
        # before this PR switched to the `api://…` cloud scope and Entra
        # refuses to exchange it for the new scope (missing consent or
        # scope-mapping mismatch). Do one more silent call with empty
        # scopes + force_refresh=True — MSAL bypasses the cached
        # access_token and uses the refresh_token to fetch a fresh
        # id_token via OIDC. Stays inside MSAL's public API, no cache
        # JSON poking. Toolkit is excluded — its `aud=7ea7c24c` is not
        # in the Gateway's ValidAudiences/LegacyAudiences, so returning
        # its id_token would just move the 401 one step later.
        if browser_result is None and _id_token_aud_gateway_valid(client_id):
            for account in accounts:
                try:
                    refreshed = app.acquire_token_silent([], account=account, force_refresh=True)
                except Exception as exc:
                    logger.debug("Empty-scope refresh failed for {}: {}", client_id[:8], exc)
                    continue
                id_tok = refreshed and refreshed.get("id_token")
                if id_tok:
                    logger.info(
                        "Cloud browser cache can't mint cloud access_token for {}; "
                        "fell back to OIDC-refresh id_token — user should re-login "
                        "to upgrade the cache.",
                        client_id[:8],
                    )
                    # Persist the fallback's cache updates (fresh id_token +
                    # refresh_token metadata) so subsequent starts don't
                    # re-run the network call.
                    _persist_cache(token_cache, cache_path)
                    # Capture oid/tid/upn from the fresh id_token so
                    # downstream oid-keyed routing (conv_ref_store,
                    # GitHub identity matching) is populated — the
                    # access_token path below already does this.
                    self._capture_identity(refreshed)
                    return str(id_tok)
        if not browser_result:
            return None

        _persist_cache(token_cache, cache_path)
        logger.debug("Token acquired silently (client={}, browser)", client_id[:8])
        self._capture_identity(browser_result)
        return self._pick_token(browser_result)

    def _execute_login_choice(self) -> str:
        """Show the login menu, execute the chosen sign-in path.

        After the interactive step completes (WAM or Browser PKCE), run one
        silent refresh against the cloud scope via :meth:`_try_silent_all`.
        Why: WAM login uses ``scopes=[]`` for a cleaner OIDC flow, so the
        interactive result carries a Graph-audience access_token that the
        Gateway would reject. The silent refresh does a PRT → Entra
        exchange for the real cloud scope and returns a Gateway-valid
        token. If silent refresh isn't available (e.g. browser cache had
        no refresh_token — shouldn't happen because Browser PKCE uses the
        real scope), fall back to the interactive result.
        """
        from workpilot.utils.auth import interactive_cloud_login

        has_primary = bool(self._msal_app and self._msal_app.get_accounts())
        interactive_token = interactive_cloud_login(
            tenant_id=self._tenant_id,
            client_id=self._client_id,
            scope=self._scope,
            login_port=self._login_port,
            has_primary_account=has_primary,
        )

        refreshed = self._try_silent_all()
        return refreshed or interactive_token

    def _try_shared_or_apikey(self) -> str:
        """Prompt for API key (local LLM), then try shared app for cloud."""
        # Primary app is unusable — ask for API key so local CLI works
        # regardless of whether cloud login succeeds.
        self._prompt_api_key()
        self._switch_to_shared_app()
        try:
            token = self._interactive_login()
            self._persist_cache()
            return token
        except Exception:
            raise RuntimeError("Cloud sign-in skipped")

    # Alias — reconnect path uses the same logic as initial acquisition.
    _refresh_token_sync = _acquire_token_sync

    def _try_broker_only(self) -> str | None:
        """Broker-only variant of :meth:`_try_silent_all` for the main-thread
        reconnect fast-path. Iterates the same fallback chain (primary →
        shared → Toolkit), but skips the browser-cache step. Must be called
        on the main thread (macOS WAM constraint).
        """
        from workpilot.utils.auth import _broker_kwargs

        bkw = _broker_kwargs()
        if not bkw or not self._scope:
            return None

        for cid, authority, switch_on_success in self._silent_fallback_chain():
            token = self._try_silent_one(cid, authority, bkw, [self._scope])
            if token:
                if switch_on_success:
                    self._switch_to_shared_app(enable_broker=True)
                return token
        return None

    async def _refresh_for_reconnect(self) -> None:
        """Refresh token during reconnect — **silent only**.

        After the initial startup login, the user is no longer at the prompt
        and cannot see interactive dialogs. This method exhausts every silent
        path before giving up:

        1. **Phase 1 — broker PRT on the event loop thread (main thread)**:
           Calls :meth:`_try_broker_only` synchronously (fast local IPC to
           OS SSO Extension, < 1 s).
        2. **Phase 2 — full silent fallback in executor**:
           Calls :meth:`_try_silent_all` (broker + browser cache across
           primary, shared MCP, and Teams Toolkit).

        If every silent path is exhausted, logs an error and leaves
        ``self._token`` unchanged. The reconnect loop will keep retrying;
        the user recovers by restarting the client and re-authenticating
        interactively.
        """
        token = self._try_broker_only()
        if token:
            self._token = token
            return

        token = await asyncio.get_running_loop().run_in_executor(None, self._try_silent_all)
        if token:
            self._token = token
            return

        logger.error(
            "Silent cloud token refresh exhausted all paths "
            "(primary / shared / toolkit, broker + browser). "
            "Restart the client and re-login to recover."
        )

    # ── Shared Entra ID fallback ────────────────────────────────────────────

    @staticmethod
    def _pick_token(result: dict) -> str:
        """Return the best token from an MSAL result.

        Prefer access_token (aud=resource app, typ=at+jwt) so that shared-app
        fallback tokens have the primary app audience.  Fall back to id_token
        (aud=client_id, typ=JWT) when no access_token is available.
        The Gateway accepts both typ=at+jwt and typ=JWT.
        """
        return str(result.get("access_token") or result["id_token"])

    @staticmethod
    def _is_consent_error(exc: Exception) -> bool:
        """True if the exception text contains a known consent error code."""
        msg = str(exc)
        return any(code in msg for code in _CONSENT_ERROR_CODES)

    @staticmethod
    def _is_timeout_error(exc: Exception) -> bool:
        """True if the MSAL interactive login timed out."""
        # MSAL raises BrowserInteractionTimeoutError with message
        # "User did not complete the flow in time".
        cls = type(exc).__name__
        if "Timeout" in cls:
            return True
        msg = str(exc).lower()
        return "timed out" in msg or "timeout" in msg or "not complete the flow in time" in msg

    @staticmethod
    def _prompt_api_key() -> None:
        """Prompt for a Web API key, confirm, and save to secret store + config.

        Skips if ``WEB_API_KEY`` is already configured.
        """
        import sys

        from workpilot.security.secrets import get_secret, set_secret

        if get_secret("WEB_API_KEY"):
            logger.debug("WEB_API_KEY already configured — skipping prompt")
            return
        if not sys.stdin.isatty():
            logger.debug("Non-interactive — skipping API key prompt")
            return
        _console.print(
            Panel(
                "[bold]Configure a Web API key[/bold] for the local web interface.\n"
                "Press [bold]Enter[/bold] to skip.",
                title="API Key",
                border_style="blue",
            )
        )
        try:
            from rich.prompt import Prompt

            key = Prompt.ask("  API Key", password=True, default="", show_default=False).strip()
            if not key:
                _console.print("  [dim]Skipped.[/dim]")
                return
            _console.print(f"  [dim]({len(key)} characters)[/dim]")
            confirm = Prompt.ask(
                "  Confirm API Key", password=True, default="", show_default=False
            ).strip()
            if key != confirm:
                _console.print("  [red]Keys do not match \u2014 skipped.[/red]")
                return
        except (EOFError, KeyboardInterrupt):
            _console.print("  [dim]Skipped.[/dim]")
            return
        set_secret("WEB_API_KEY", key)

        # Write SECRET[WEB_API_KEY] reference into workpilot.local.yaml so the
        # config loader resolves it at startup (same pattern as GITHUB_COPILOT_TOKEN).
        try:
            from workpilot.config.loader import set_local_config_value

            set_local_config_value("channels.web.api_key", "SECRET[WEB_API_KEY]")
        except Exception as exc:
            logger.warning("Failed to write api_key to local config: {}", exc)

        _console.print("  [green]\u2713[/green] Web API key saved.")

    def _switch_to_shared_app(self, *, enable_broker: bool = False) -> None:
        """Replace the MSAL app / cache with the shared Entra client ID.

        After this call, all existing auth paths (_acquire_token_sync,
        _interactive_login, _browser_flow, _device_code_flow) route
        through the shared client.

        ``self._scope`` is intentionally NOT overwritten — the cloud
        resource scope stays constant across primary / shared / toolkit
        fallback clients so every access_token has the same audience
        (Gateway's primary ``AzureAd:ClientId``). Shared and Toolkit
        are pre-authorized on the primary cloud resource, so they can
        silently mint tokens for that scope via PRT refresh.

        When *enable_broker* is True, WAM broker is enabled on the shared
        app so that ``_browser_flow(try_wam=True)`` works with it.
        """
        logger.info(
            "Switching to shared Entra app ({}) — scope unchanged",
            SHARED_ENTRA_CLIENT_ID[:8],
        )
        self._cache_path = _CacheStore.path(SHARED_ENTRA_CLIENT_ID, broker=False)
        self._token_cache = _CacheStore.load(SHARED_ENTRA_CLIENT_ID, broker=False)
        broker_kwargs: dict[str, Any] = {}
        if enable_broker:
            from workpilot.utils.auth import _broker_kwargs

            broker_kwargs = _broker_kwargs()
            self._broker_enabled = bool(broker_kwargs)
            if not broker_kwargs:
                logger.warning("msal[broker] not installed; broker disabled on shared app")
        else:
            self._broker_enabled = False
        self._msal_app = msal.PublicClientApplication(
            SHARED_ENTRA_CLIENT_ID,
            authority="https://login.microsoftonline.com/organizations",
            token_cache=self._token_cache,
            **broker_kwargs,
        )
        self._using_shared_app = True

    def _interactive_login(self, timeout: int = 300) -> str:
        """Dispatch to the configured login method.

        "auto" / "browser" — browser PKCE only (default, always works).
        "wam"              — WAM broker → browser PKCE fallback (opt-in).
        "device"           — device code only (opt-in, many tenants disable it).
        """
        if self._login_method == "device":
            return self._device_code_flow(timeout=timeout)
        if self._login_method == "wam":
            return self._browser_flow(try_wam=self._broker_enabled, timeout=timeout)
        # "auto" and "browser": browser PKCE only
        return self._browser_flow(try_wam=False, timeout=timeout)

    def _resolve_login_port(self) -> int:
        """Return a usable localhost port for the PKCE callback.

        Tries self._login_port first (the preferred/gateway port).
        If that port is already bound, asks the OS for any free port.
        """
        preferred = self._login_port
        for port in (preferred, 52813, 58729, 0):  # fixed high ports for AAD, then OS-assigned
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind(("localhost", port))
                    chosen = s.getsockname()[1]
                    if port != preferred:
                        logger.debug(
                            "Login port {} busy — using {} instead",
                            preferred,
                            chosen,
                        )
                    return int(chosen)
                except OSError:
                    continue
        # Should never reach here — port 0 always succeeds
        return preferred  # pragma: no cover

    @staticmethod
    def _wait_with_countdown(done: Any, timeout: int) -> bool:
        """Show a fallback countdown, listening for ESC to skip.

        Returns True if the user pressed ESC (skip), False if *done* was set
        (MSAL completed) or the countdown expired naturally.
        """

        from workpilot.utils.input import is_tty, read_key_nonblocking

        remaining = timeout
        while remaining > 0 and not done.is_set():
            _console.print(
                f"  Fallback in [yellow]{remaining}s[/yellow] [dim](ESC to skip)[/dim]\u2026",
                end="\r",
            )
            if is_tty():
                try:
                    key = read_key_nonblocking()
                    if key == "esc":
                        _console.print(" " * 60, end="\r")
                        return True
                except KeyboardInterrupt:
                    _console.print(" " * 60, end="\r")
                    raise
            if done.wait(1):
                break
            remaining -= 1
        _console.print(" " * 60, end="\r")
        return False

    def _browser_flow(self, *, try_wam: bool = False, timeout: int = 300) -> str:
        """Interactive browser-based auth (authorization code + PKCE).

        MSAL opens the default browser and starts a local HTTP server on
        login_port (default 49215 — high port to avoid conflicts) for the
        callback. The registered redirect URI is http://localhost which
        AAD matches against any http://localhost:{PORT} loopback address.
        """
        port = self._resolve_login_port()
        _console.print(
            Panel(
                "[bold]Opening browser for sign-in\u2026[/bold]\n\n"
                f"Callback : [cyan]http://localhost:{port}[/cyan]\n"
                f"Fallback : [dim]alternative sign-in offered after {timeout}s[/dim]\n"
                "Press [bold]Ctrl+C[/bold] to cancel.",
                title="Sign In",
                border_style="yellow",
            )
        )

        assert self._msal_app is not None

        # After the OAuth callback, redirect to the web chat — but only
        # for the primary app.  The shared-app fallback path should NOT
        # redirect because the user's primary app couldn't authenticate
        # and the web chat may not work with the fallback token.
        if self._using_shared_app:
            success_template = (
                "<!DOCTYPE html><html><head><title>WorkPilot</title></head>"
                "<body>Sign-in successful — you can close this tab.</body></html>"
            )
        else:
            web_url = webchat_url_from_connect(self._url)
            safe_url = _html.escape(web_url, quote=True)
            success_template = (
                "<!DOCTYPE html><html><head><title>WorkPilot</title>"
                f'<meta http-equiv="refresh" content="0;url={safe_url}"></head>'
                f'<body>Sign-in successful — <a href="{safe_url}">opening WorkPilot</a>…'
                "</body></html>"
            )

        wam_kwargs: dict[str, Any] = {}
        if try_wam:
            from workpilot.utils.auth import _get_foreground_window_handle

            wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(self._msal_app)

        import threading

        msal_result: dict[str, Any] = {}
        msal_error: BaseException | None = None
        done_event = threading.Event()

        msal_app = self._msal_app

        # WAM:     empty scopes — broker runs an OIDC-only flow (cleaner
        #          account picker, no resource consent prompt). The returned
        #          access_token is for Graph userinfo; `_execute_login_choice`
        #          upgrades it via a subsequent silent refresh that does a
        #          PRT exchange for the real cloud scope.
        # Browser: must request the real cloud scope — MSAL only includes
        #          `offline_access` (and issues a refresh_token) when the
        #          scope list is non-OIDC, otherwise silent refresh has no
        #          refresh_token to exchange.
        interactive_scopes = [] if try_wam else self._scopes

        def _msal_call() -> None:
            nonlocal msal_result, msal_error
            try:
                msal_result = msal_app.acquire_token_interactive(
                    scopes=interactive_scopes,
                    prompt="select_account",
                    port=port,
                    timeout=timeout,
                    success_template=success_template,
                    **wam_kwargs,
                )
            except BaseException as exc:
                msal_error = exc
            finally:
                done_event.set()

        msal_thread = threading.Thread(target=_msal_call, daemon=True)
        msal_thread.start()

        # Wait with countdown + ESC detection. ESC skips to fallback.
        skipped = self._wait_with_countdown(done_event, timeout)
        if skipped:
            # User pressed ESC — simulate timeout so caller triggers fallback
            raise TimeoutError("Sign-in skipped by user (ESC)")

        msal_thread.join(timeout=2)
        if msal_error is not None:
            raise msal_error
        result = msal_result

        # WAM broker failed — unconditionally retry with plain browser.
        # Common WAM errors: broker_error (redirect URI missing), admin consent
        # required (AADSTS65001), public client blocked (AADSTS7000218), etc.
        if try_wam and "error" in result:
            err = result.get("error", "")
            err_desc = result.get("error_description", "")
            logger.info("WAM broker failed ({}); falling back to browser PKCE", err)
            logger.debug("WAM error detail: {}", err_desc[:300])
            # Not passing parent_window_handle → MSAL uses browser PKCE.
            result = self._msal_app.acquire_token_interactive(
                scopes=self._scopes,
                prompt="select_account",
                port=port,
                timeout=timeout,
                success_template=success_template,
            )

        if "error" in result:
            raise RuntimeError(
                f"Browser login failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._capture_identity(result)
        self._save_identity(result)
        return self._pick_token(result)

    def _device_code_flow(self, timeout: int = 300) -> str:
        """Device code flow — visit a URL and enter a short code.

        Works in headless / SSH / corporate environments where browser
        pop-ups are blocked.  *timeout* is accepted for API consistency
        but device code flow uses its own server-side expiry.
        """
        assert self._msal_app is not None
        flow = self._msal_app.initiate_device_flow(scopes=self._scopes)
        if "error" in flow:
            raise RuntimeError(
                f"Device code flow failed to start: {flow.get('error_description', flow['error'])}"
            )

        _console.print(
            Panel(
                f"[bold]Sign in required[/bold]\n\n{flow['message']}",
                title="Device Code",
                border_style="yellow",
            )
        )

        result = self._msal_app.acquire_token_by_device_flow(flow)
        if "error" in result:
            raise RuntimeError(
                f"Device code flow failed: {result.get('error_description', result['error'])}"
            )

        self._log_authenticated(result)
        self._capture_identity(result)
        self._save_identity(result)
        return self._pick_token(result)

    def _persist_cache(self) -> None:
        """Write MSAL token cache to disk if it changed.

        Uses an atomic rename and mode 0o600 on POSIX. On Windows the parent
        auth/ directory is ACL-restricted via icacls (best-effort; see ensure_private_dir).
        """
        if self._cache_path is None or not self._token_cache.has_state_changed:
            return
        try:
            tmp = self._cache_path.with_suffix(".tmp")
            from workpilot.security.secrets import encrypt_at_rest, is_encrypted

            plaintext = self._token_cache.serialize().encode("utf-8")
            data = encrypt_at_rest(plaintext)
            # Avoid overwriting an encrypted cache with plaintext
            if data == plaintext and self._cache_path.exists():
                if is_encrypted(self._cache_path.read_bytes()):
                    logger.warning(
                        "MSAL cache not written: encryption key unavailable "
                        "and existing cache is encrypted"
                    )
                    return
            tmp.write_bytes(data)
            try:
                tmp.chmod(0o600)
            except (NotImplementedError, OSError):
                pass  # Windows/some filesystems: parent ACL governs access
            tmp.replace(self._cache_path)
            logger.debug("MSAL token cache saved to {}", self._cache_path)
        except Exception as exc:
            logger.warning("Failed to save MSAL token cache: {}", exc)

    @staticmethod
    def _log_authenticated(result: dict) -> None:
        claims = result.get("id_token_claims", {})
        name = claims.get("name") or claims.get("preferred_username", "unknown")
        oid = claims.get("oid", "unknown")
        _console.print(
            f"  [green]\u2713[/green] Authenticated as [bold]{name}[/bold] [dim](oid={oid})[/dim]"
        )
        logger.success("Authenticated as: {} (oid={})", name, oid)

    def _capture_identity(self, result: dict) -> None:
        """Extract oid/tid from an MSAL token result, if claims are present.

        Called on every acquisition path (silent, browser, device code).
        Best-effort: MSAL may omit ``id_token_claims`` on a pure cache hit,
        in which case this is a no-op and identity is captured on the next
        interactive login.
        """
        claims = result.get("id_token_claims", {})
        if claims.get("oid"):
            # If Entra account changed, reset GitHub identity — it was
            # verified against the previous account's emails.
            if self._local_oid and claims["oid"] != self._local_oid:
                self._local_github_id = None
                self._local_github_login = None
                self._local_upn = None
                self._local_email = None
                self._github_identity_attempted = False
            self._local_oid = claims["oid"]
        if claims.get("tid"):
            self._local_tid = claims["tid"]
        # UPN and email for GitHub identity matching.
        # UPN may not be an email (e.g., DOMAIN\user) — still store as
        # alias/username, but only use for email matching when it has @.
        upn = claims.get("preferred_username") or claims.get("upn") or ""
        if upn:
            self._local_upn = upn
        email = claims.get("email")
        if email and "@" in email:
            self._local_email = email
        elif "@" in upn:
            self._local_email = upn

    def _save_identity(self, result: dict) -> None:
        """Persist Entra ID claims to ~/.workpilot/USER.md."""
        if self._runtime is None:
            return
        from workpilot.utils.identity import save_identity

        save_identity(
            result.get("id_token_claims", {}),
            self._runtime.workspace,
            user_file=self._runtime.config.agents.default.user_file,
        )

    # ── GitHub identity registration ────────────────────────────────────────

    def _resolve_github_identity(self) -> None:
        """Resolve GitHub identity from existing Copilot token. Blocking.

        Matches by normalized email intersection between GitHub (/user email)
        and Entra (UPN + email claim). No manual configuration needed.
        """
        if not self._enable_github:
            return

        # Need at least one Entra email (UPN or email claim) to match against.
        # If neither is captured yet (e.g., MSAL pure cache hit), defer.
        has_upn = self._local_upn and "@" in self._local_upn
        has_email = self._local_email and "@" in self._local_email
        if not has_upn and not has_email:
            logger.debug("Skipping GitHub identity: no Entra email available yet")
            return  # don't set _attempted — retry when claims become available

        from workpilot.mcp.auth import _resolve_github_token
        from workpilot.security.github_auth import get_github_user

        token = _resolve_github_token()
        if not token:
            # No token configured — definitive, don't retry on reconnect.
            self._github_identity_attempted = True
            return

        user = get_github_user(token)
        if user is False:
            # Definitive failure (401) — token invalid/revoked, don't retry.
            self._github_identity_attempted = True
            return
        if not user:
            # Transient failure (network/5xx) — retry on next reconnect.
            return

        login = user.get("login", "")
        raw_id = user.get("id")
        if not login or not raw_id or not str(raw_id).isdigit():
            logger.warning("GitHub /user returned incomplete identity")
            return
        github_id = str(raw_id)
        github_email = user.get("email")

        # Match identity: at least one email from GitHub must match one
        # from Entra (UPN or email claim).  Normalized = lowercase + strip +tag.
        from workpilot.security.github_auth import _normalize_email

        entra_emails: set[str] = set()
        if self._local_upn and "@" in self._local_upn:
            entra_emails.add(_normalize_email(self._local_upn))
        if self._local_email and "@" in self._local_email:
            entra_emails.add(_normalize_email(self._local_email))

        github_emails: set[str] = set()
        if github_email and "@" in github_email:
            normalized = _normalize_email(github_email)
            domain = normalized.split("@", 1)[1]
            github_emails.add(normalized)

            # EMU: login prefix can be used as email alias only when the
            # login suffix (_microsoft) matches the email +tag (+microsoft).
            # Both are the enterprise short name; if they agree, the prefix
            # is a trusted alias → derive prefix@domain as second address.
            # If no +tag or mismatch → prefix is untrusted, skip derivation.
            if "_" in login:
                prefix, suffix = login.rsplit("_", 1)
                local_part = github_email.split("@", 1)[0]
                if "+" in local_part:
                    email_tag = local_part.split("+", 1)[1].lower()
                    if suffix.lower() == email_tag:
                        github_emails.add(f"{prefix.lower()}@{domain}")

        if not github_emails:
            logger.info(
                "GitHub identity: no public email set — "
                "set a company email in GitHub Settings > Emails to enable registration"
            )
            self._github_identity_attempted = True
            return
        if not entra_emails & github_emails:
            logger.warning("GitHub identity: no matching email found")
            self._github_identity_attempted = True
            return

        self._github_identity_attempted = True  # success — no need to retry
        self._local_github_id = github_id
        self._local_github_login = login
        logger.info("GitHub identity resolved: {} ({})", login, github_id)

    async def _resolve_and_register_github(self) -> None:
        """Background task: resolve GitHub identity then send registration."""
        try:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._resolve_github_identity)
            await self._send_register_identity()
        except Exception as exc:
            logger.debug("GitHub identity resolution failed: {}", exc)
        finally:
            self._github_resolve_task = None

    async def _send_register_identity(self) -> None:
        """Send register_identity frame to Gateway if GitHub identity is available."""
        if not self._local_github_id or not self._local_github_login:
            return
        import platform
        import re

        # Sanitize hostname: strip non-printable chars, truncate to 64 chars
        raw_name = platform.node() or ""
        client_name = re.sub(r"[^\x20-\x7e]", "", raw_name)[:64]

        frame = json.dumps(
            {
                "type": "register_identity",
                "provider": "github",
                "provider_id": self._local_github_id,
                "provider_login": self._local_github_login,
                "client_name": client_name or None,
            },
            ensure_ascii=False,
        )
        await self._send_queue.put(frame)
