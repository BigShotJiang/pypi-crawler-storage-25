"""workpilot chat — interactive agent REPL, with web server attach support."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from workpilot.runtime import Runtime

console = Console()


# ── Web server auth resolution ────────────────────────────────────────────────


def _resolve_web_auth(rt: Runtime) -> dict[str, str]:
    """Return WebSocket headers for web server auth.

    Priority: api_key > Entra token (web server config) > empty.
    """
    web_cfg = rt.config.channels.web
    if web_cfg.api_key:
        return {"X-API-Key": web_cfg.api_key.get_secret_value()}

    # Gate on gateway's own Entra config, not cloud channel defaults
    if web_cfg.entra_tenant_id and web_cfg.entra_client_id:
        try:
            from workpilot.utils.auth import acquire_entra_token

            token = acquire_entra_token(
                tenant_id=web_cfg.entra_tenant_id,
                client_id=web_cfg.entra_client_id,
            )
            if token:
                return {"Authorization": f"Bearer {token}"}
            console.print(
                "[yellow]Entra ID login cancelled or failed — connecting without auth.[/yellow]"
            )
        except Exception as exc:
            console.print(f"[yellow]Entra ID auth failed: {exc}[/yellow]")

    return {}


# ── WebSocket REPL (attach to running web server) ────────────────────────────


async def _ws_chat_repl(port: int, *, auth_headers: dict[str, str] | None = None) -> None:
    """Connect to a running web server via WebSocket and run an interactive REPL."""
    import json as _json

    import websockets  # type: ignore[import]

    url = f"ws://localhost:{port}/api/ws"
    console.print(
        f"[dim]Connected to running web server (port {port}). "
        f"Type /new to clear session, Ctrl+C to exit.[/dim]\n"
    )
    # Reuse prompt_toolkit session for history + autocomplete (fallback to input())
    try:
        import os

        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import FileHistory

        from workpilot.channels.cli import _SlashCompleter
        from workpilot.utils.helpers import get_data_dir

        _history_path = get_data_dir() / "cli_history"
        if os.name == "posix":
            try:
                if not _history_path.exists():
                    fd = os.open(_history_path, os.O_CREAT | os.O_WRONLY, 0o600)
                    os.close(fd)
                else:
                    os.chmod(_history_path, 0o600)
            except OSError:
                pass
        _ws_session: PromptSession[str] = PromptSession(
            "you> ",
            completer=_SlashCompleter(),
            complete_while_typing=True,
            history=FileHistory(str(_history_path)),
        )
        _get_input = lambda: _ws_session.prompt()  # noqa: E731
    except ImportError:
        console.print("[dim](basic input mode — autocomplete/history unavailable)[/dim]")
        _get_input = lambda: input("you> ")  # noqa: E731

    async with websockets.connect(url, additional_headers=auth_headers or {}) as ws:
        while True:
            try:
                prompt = await asyncio.get_running_loop().run_in_executor(None, _get_input)
            except (EOFError, KeyboardInterrupt):
                break

            if not prompt.strip():
                continue

            # Slash commands handled locally
            if prompt.strip() == "/exit":
                break

            await ws.send(_json.dumps({"prompt": prompt}, ensure_ascii=False))

            # Loop until we get the actual response — push frames can arrive first
            while True:
                data = _json.loads(await ws.recv())
                if "response" in data:
                    from rich.markdown import Markdown

                    console.print(Markdown(data["response"]))
                    break
                elif "type" in data and data["type"] == "push":
                    console.print(f"[dim][push] {data.get('content', '')}[/dim]")
                elif "error" in data:
                    console.print(f"[red]{data['error']}[/red]")
                    break


# ── Command entry point ──────────────────────────────────────────────────────


def chat(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Start an interactive agent REPL session.

    If 'workpilot serve' is already running, connects to it directly instead
    of starting a new Runtime instance.
    """
    from workpilot.cli.commands import _check_web_running, _get_runtime

    running = _check_web_running()
    if running:
        _, port = running
        console.print(f"[dim]Web server running on port {port} — connecting...[/dim]")
        try:
            rt = _get_runtime(config, profile)
            headers = _resolve_web_auth(rt)
            asyncio.run(_ws_chat_repl(port, auth_headers=headers))
        except KeyboardInterrupt:
            pass
        except Exception as exc:
            console.print(f"[red]Web server connection failed:[/red] {exc}")
            raise typer.Exit(1)
        console.print("\nGoodbye!")
        return

    try:
        rt = _get_runtime(config, profile)
        asyncio.run(rt.run_chat())
    except KeyboardInterrupt:
        console.print("\nGoodbye!")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
