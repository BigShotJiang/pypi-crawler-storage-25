"""WorkPilot CLI package."""
