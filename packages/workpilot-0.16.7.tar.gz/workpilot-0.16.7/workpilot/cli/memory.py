"""Memory CLI subcommands — workpilot memory show|search|clear|stats."""

from __future__ import annotations

import typer
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    memory_app,
)


@memory_app.command("show")
def memory_show(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show current MEMORY.md content and HistoryStore summary."""
    from workpilot.agent.memory import AgentMemory

    _load_config_safe(config)
    mem = AgentMemory()

    # Show agent memory (primary)
    agent_content = mem.read_memory()
    if agent_content.strip():
        from rich.markdown import Markdown

        console.print(Markdown(agent_content))
    else:
        console.print("[dim]Agent MEMORY.md is empty.[/dim]")

    # Show shared memory if different
    shared_content = mem.read_shared()
    if shared_content.strip() and shared_content != agent_content:
        from rich.markdown import Markdown as Md

        console.print("\n[bold]Shared Memory:[/bold]")
        console.print(Md(shared_content))

    count = mem.history.count()
    if count:
        console.print(f"\n[dim]HistoryStore: {count} entries (use 'memory search' to query)[/dim]")
    mem.close()


@memory_app.command("search")
def memory_search(
    query: str = typer.Argument(..., help="Search query"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Search memory and history via HistoryStore FTS5, with session fallback."""
    from workpilot.agent.memory import AgentMemory

    _load_config_safe(config)
    mem = AgentMemory()

    # Try HistoryStore FTS5 first
    results = mem.history.search(query, top_k=20)
    if results:
        table = Table(title=f"History Search: {query}")
        table.add_column("ID", style="dim")
        table.add_column("Category")
        table.add_column("Content")
        for r in results:
            snippet = r["content"][:120].replace("\n", " ")
            table.add_row(str(r["id"]), r.get("category", ""), snippet)
        console.print(table)
        mem.close()
        return

    mem.close()

    # Fallback to session JSONL scan
    import json as _json

    from workpilot.utils.helpers import get_sessions_dir

    sessions_dir = get_sessions_dir()
    hits: list[tuple[str, str, str]] = []

    for path in sorted(sessions_dir.glob("*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                msg = _json.loads(line)
            except Exception:  # noqa: S112
                continue
            content = msg.get("content") or ""
            if isinstance(content, list):
                content = " ".join(p.get("text", "") for p in content if isinstance(p, dict))
            if query.lower() in content.lower():
                snippet = content[:120].replace("\n", " ")
                hits.append((path.stem, msg.get("role", "?"), snippet))

    if not hits:
        console.print(f"[dim]No results for '{query}'.[/dim]")
        return

    table = Table(title=f"Session Search: {query}")
    table.add_column("Session", style="dim")
    table.add_column("Role")
    table.add_column("Snippet")
    for sid, role, snippet in hits[:50]:
        table.add_row(sid, role, snippet)
    console.print(table)
    if len(hits) > 50:
        console.print(f"[dim]... and {len(hits) - 50} more results.[/dim]")


@memory_app.command("clear")
def memory_clear(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Clear MEMORY.md facts and HistoryStore entries."""
    from workpilot.agent.memory import AgentMemory

    _load_config_safe(config)

    if not yes:
        typer.confirm("Clear all facts in MEMORY.md and HistoryStore?", abort=True)

    mem = AgentMemory()
    mem.write_memory("")
    mem.write_shared("")
    n = mem.history.clear_all()
    mem.close()
    console.print(
        f"  [green]\u2713[/green] MEMORY.md cleared. HistoryStore: {n} entries deleted.\n"
        "  [dim]HISTORY.md file retained (append-only audit log).[/dim]"
    )


@memory_app.command("stats")
def memory_stats(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show memory statistics."""
    from workpilot.agent.memory import AgentMemory
    from workpilot.utils.helpers import get_sessions_dir

    _load_config_safe(config)
    mem = AgentMemory()

    mem_content = mem.read_shared()
    mem_bytes = len(mem_content.encode())
    mem_lines = len([line for line in mem_content.splitlines() if line.strip()])

    agent_mem = mem.read_memory()
    agent_bytes = len(agent_mem.encode())

    history_path = mem.history.path
    history_bytes = history_path.stat().st_size if history_path.is_file() else 0
    archive_dir = mem.history.base_dir / "HISTORY"
    archive_files = sorted(archive_dir.glob("*.md")) if archive_dir.is_dir() else []
    archive_bytes = sum(f.stat().st_size for f in archive_files)

    history_count = mem.history.count()
    mem.close()

    sessions_dir = get_sessions_dir()
    session_files = list(sessions_dir.glob("*.jsonl"))
    total_session_bytes = sum(p.stat().st_size for p in session_files)

    table = Table(title="Memory Stats")
    table.add_column("Item", style="bold")
    table.add_column("Value")
    cap_pct = mem_bytes * 100 // 8192 if mem_bytes else 0
    table.add_row("Shared MEMORY.md", f"{mem_bytes:,} bytes ({cap_pct}% of 8KB cap)")
    table.add_row("Agent MEMORY.md", f"{agent_bytes:,} bytes")
    table.add_row("MEMORY.md lines", str(mem_lines))
    table.add_row("HISTORY.md", f"{history_bytes:,} bytes")
    if archive_files:
        table.add_row("HISTORY/ archives", f"{len(archive_files)} files, {archive_bytes:,} bytes")
    table.add_row("HistoryStore", f"{history_count} entries")
    table.add_row("Session files", str(len(session_files)))
    table.add_row("Session total size", f"{total_session_bytes / 1024:.1f} KB")
    console.print(table)
