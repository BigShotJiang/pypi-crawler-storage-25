"""Init CLI command — workpilot init."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

import typer
from rich.panel import Panel
from rich.table import Table

from workpilot.cli.commands import (
    app,
    console,
)

_TOTAL_STEPS = 5


# ── Modern interactive selection ──────────────────────────────────────────────


def _step_header(n: int, label: str) -> None:
    """Print step header: ``[1/5] Label``."""
    console.print(f"\n[bold cyan][{n}/{_TOTAL_STEPS}][/bold cyan] [bold]{label}[/bold]")


def _step_done(value: str) -> None:
    """Print a completed step result with green checkmark."""
    console.print(f"  [green]\u2713[/green] {value}")


def _is_tty() -> bool:
    """Return True if running in a real terminal (not piped/test)."""
    from workpilot.utils.input import is_tty

    return is_tty()


def _read_key() -> str:
    """Read a single keypress. Returns ``'up'``, ``'down'``, ``'enter'``, or the character."""
    from workpilot.utils.input import read_key_blocking

    return read_key_blocking()


def _select(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Show a selection menu and return the 1-based chosen index.

    Uses arrow-key navigation in a real terminal. Falls back to numbered
    input in non-TTY environments (tests, piped stdin).
    """
    if _is_tty():
        try:
            return _select_arrows(options, default=default - 1) + 1
        except Exception:
            pass
    return _select_numbered(options, default=default)


def _select_arrows(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
) -> int:
    """Inline arrow-key radio selector. Returns 0-based index.

    Renders options with ``\u25cf`` / ``\u25cb`` markers, then erases itself
    after the user presses Enter — leaving the cursor right below the
    step header so the caller can print a result line.
    """
    cur = default
    n = len(options)
    max_label = max(len(label) for label, _ in options)
    # lines rendered: blank + n options + blank + hint = n + 3
    total_lines = n + 3

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        out.write("\n")
        for i, (label, desc) in enumerate(options):
            pad = label.ljust(max_label)
            if i == cur:
                line = f"  \033[36m\u25cf\033[0m \033[1m{pad}\033[0m"
            else:
                line = f"  \033[90m\u25cb {pad}\033[0m"
            if desc:
                line += f"  \033[90m\u2014 {desc}\033[0m"
            out.write(f"\033[2K{line}\n")
        out.write("\n\033[2K  \033[2;90m\u2191\u2193 move  \u23ce Enter confirm  Esc skip\033[0m\n")
        out.flush()

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)
        while True:
            key = _read_key()
            if key in ("up", "k"):
                cur = (cur - 1) % n
                _render()
            elif key in ("down", "j"):
                cur = (cur + 1) % n
                _render()
            elif key == "enter":
                # Erase the rendered menu
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return cur
            elif key == "esc":
                # ESC = select last option (skip/default)
                cur = n - 1
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return cur
            elif key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < n:
                    cur = idx
                    _render()
    finally:
        sys.stdout.write("\033[?25h\033[0m")  # show cursor, reset attrs
        sys.stdout.flush()


def _select_numbered(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Numbered fallback for non-TTY (tests, piped input). Returns 1-based index."""
    for i, (label, desc) in enumerate(options, 1):
        marker = " *" if i == default else ""
        if desc:
            console.print(f"  [bold]{i}.[/bold] {label}  [dim]\u2014 {desc}[/dim]{marker}")
        else:
            console.print(f"  [bold]{i}.[/bold] {label}{marker}")
    while True:
        raw = typer.prompt(f"Select [1-{len(options)}]", default=str(default))
        try:
            choice = int(raw)
            if 1 <= choice <= len(options):
                return choice
        except ValueError:
            pass
        console.print(f"  [yellow]Please enter 1\u2013{len(options)}[/yellow]")


# ── Utilities ─────────────────────────────────────────────────────────────────


def _check_connectivity() -> bool:
    """Return True if github.com is reachable (quick HEAD check)."""
    try:
        import httpx

        with httpx.Client(timeout=5) as http:
            resp = http.head("https://github.com")
            return resp.status_code < 500
    except Exception:
        return False


def _detected_tools_line(shutil: Any) -> str:
    """Return a ``Detected tools: ...`` string, or empty if none are installed."""
    tools = ["git", "gh", "node", "az", "claude"]
    detected = [t for t in tools if shutil.which(t)]
    if not detected:
        return ""
    return f"[dim]Detected tools: {', '.join(detected)}[/dim]"


def _check_github_copilot_account(token: str) -> None:
    """Show the signed-in GitHub account; warn if it isn't a Microsoft EMU one.

    Microsoft Enterprise Managed Users have logins suffixed ``_microsoft``;
    tokens from personal/other-tenant accounts cannot reach WorkPilot's
    Copilot endpoints.  Network/transient failures are silently ignored.
    """
    try:
        from workpilot.security.github_auth import get_github_user

        user = get_github_user(token)
    except Exception:
        return
    if not isinstance(user, dict):
        return
    login = str(user.get("login", ""))
    if not login:
        return
    if login.lower().endswith("_microsoft"):
        console.print(f"  [green]\u2713[/green] Signed in as [bold]{login}[/bold]")
    else:
        console.print(
            f"  [yellow]\u26a0[/yellow]  Signed in as [bold]{login}[/bold] \u2014 "
            "please use a Microsoft Enterprise GitHub account "
            "[dim](login must end in `_microsoft`)[/dim]."
        )


def _cloud_login_if_needed(dir_path: Path) -> None:
    """If cloud is enabled but no MSAL account is cached, run the login menu.

    Called during ``init`` so the user can authenticate before first use.
    Resolves config against *dir_path* (the init target) rather than CWD, so
    ``wp init --dir <other>`` picks up the right tenant/client/scope instead
    of any unrelated ``workpilot.yaml`` that may sit in the shell's CWD.
    """
    from workpilot.config.loader import load_config
    from workpilot.mcp.auth import has_msal_account

    try:
        cfg = load_config(str(dir_path))
    except Exception:
        return

    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
        return
    if not cloud_cfg.scope:
        cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"

    # Check primary and shared app caches — skip if either has a cached account.
    if has_msal_account(cloud_cfg.client_id):
        console.print("  [green]\u2713[/green] Already signed in")
        return
    from workpilot.mcp.defaults import SHARED_ENTRA_CLIENT_ID

    if has_msal_account(SHARED_ENTRA_CLIENT_ID):
        console.print("  [green]\u2713[/green] Already signed in")
        return

    # No cached account — show login menu (it has its own privacy hint).
    try:
        from workpilot.utils.auth import interactive_cloud_login

        interactive_cloud_login(
            tenant_id=cloud_cfg.tenant_id,
            client_id=cloud_cfg.client_id,
            scope=cloud_cfg.scope,
            login_port=cloud_cfg.login_port,
        )
    except RuntimeError as exc:
        if "skipped" in str(exc).lower():
            console.print("  [dim]Cloud sign-in skipped.[/dim]")
        else:
            console.print(f"  [yellow]Warning:[/yellow] Cloud sign-in failed: {exc}")
    except KeyboardInterrupt:
        console.print("  [dim]Cloud sign-in skipped.[/dim]")
    except Exception as exc:
        console.print(f"  [yellow]Warning:[/yellow] Cloud sign-in failed: {exc}")


# ── Main init command ─────────────────────────────────────────────────────────


@app.command()
def init(
    directory: str | None = typer.Option(
        None, "--dir", "-d", help="Target directory (default: ~/.workpilot)"
    ),
    name: str | None = typer.Option(
        None, "--name", "-n", help="Project name (sets top-level 'name' in config)"
    ),
    quick: bool = typer.Option(False, "--quick", "-q", help="Accept all defaults, no prompts"),
) -> None:
    """Create or update the local config override (workpilot.local.yaml).

    By default this writes to ``~/.workpilot/workpilot.local.yaml``.
    Safe to run multiple times \u2014 existing values are shown as defaults
    so you only change what you want. Use --quick to accept all defaults.
    """
    import copy
    import shutil

    import yaml

    dir_path = (Path.home() / ".workpilot") if directory is None else Path(directory).resolve()
    dir_path.mkdir(parents=True, exist_ok=True)

    local_path = dir_path / "workpilot.local.yaml"

    # Load existing config to use as defaults
    existing: dict = {}
    is_update = local_path.exists()
    if is_update:
        try:
            loaded = yaml.safe_load(local_path.read_text(encoding="utf-8"))
            existing = loaded if isinstance(loaded, dict) else {}
        except Exception:
            existing = {}

    # ── Welcome / header ──────────────────────────────────────────────
    tools_line = _detected_tools_line(shutil)
    if quick:
        console.print("[dim]--quick mode: accepting all defaults[/dim]\n")
        if tools_line:
            console.print(f"  {tools_line}\n")
    else:
        if is_update:
            body = f"Updating config at [cyan]{local_path}[/cyan]"
        else:
            body = (
                "[bold]Welcome to WorkPilot![/bold]  "
                "[dim]\u2014 5 steps, about a minute[/dim]\n\n"
                "  [dim]1.[/dim] GitHub Copilot token\n"
                "  [dim]2.[/dim] Security profile\n"
                "  [dim]3.[/dim] Web UI\n"
                "  [dim]4.[/dim] Cloud connection\n"
                "  [dim]5.[/dim] MCP servers [dim](optional)[/dim]"
            )
        if tools_line:
            body = f"{body}\n\n{tools_line}"
        console.print(Panel(body, title="WorkPilot Setup", border_style="cyan"))

    # ── Extract prior state (used as defaults + inside _build) ──────
    raw_token: str = (existing.get("providers") or {}).get("github_copilot", {}).get(
        "token", ""
    ) or ""
    # `${GITHUB_TOKEN}` is the bootstrap placeholder `_build()` writes when no
    # token is configured; only treat it as real if the env var is actually set.
    uses_github_env_placeholder = raw_token == "${GITHUB_TOKEN}"
    has_github_env_token = bool(os.getenv("GITHUB_TOKEN"))
    # Defer SecretStore lookup — `get_secret_store()` under `secret_backend=auto`
    # runs a keyring write/read/delete probe. Only consult it when the YAML
    # token alone can't tell us whether a token is configured.
    if not raw_token or uses_github_env_placeholder:
        try:
            from workpilot.security.secrets import get_secret as _get_secret

            has_stored_secret: bool = bool(_get_secret("GITHUB_COPILOT_TOKEN"))
        except Exception:
            has_stored_secret = False
    else:
        has_stored_secret = False
    has_configured_token = (
        has_stored_secret
        or (bool(raw_token) and not uses_github_env_placeholder)
        or (uses_github_env_placeholder and has_github_env_token)
    )
    current_token = "" if raw_token.startswith(("${", "SECRET[")) else raw_token

    current_profile: str = (existing.get("security") or {}).get("profile", "standard") or "standard"
    current_gw: dict = (existing.get("channels") or {}).get("web") or existing.get("gateway") or {}
    current_gw_enabled: bool = bool(current_gw.get("enabled", True))
    current_cloud: dict = (existing.get("channels") or {}).get("cloud") or {}
    current_cloud_enabled: bool = bool(current_cloud.get("enabled", True))

    # ── Captured decisions (start at "keep existing") ────────────────
    github_token: str | None = None
    security_profile: str = current_profile
    enable_web: bool = current_gw_enabled
    enable_cloud: bool = current_cloud_enabled

    from workpilot.config.loader import save_yaml

    header = (
        "# WorkPilot local config override\n"
        "# This file is gitignored \u2014 use it for API keys, model preferences,\n"
        "# and local settings that should not be committed.\n"
        "# Values here are deep-merged on top of workpilot.yaml.\n"
        "\n"
    )

    def _build() -> dict:
        """Build local_config from captured closure state.

        May call ``set_secret`` (side effect) — intended to be called at most
        once per init run; idempotent otherwise.
        """
        lc = copy.deepcopy(existing)
        if name:
            lc["name"] = name
        lc.setdefault("providers", {}).setdefault("github_copilot", {})
        if github_token and not github_token.startswith("${"):
            try:
                from workpilot.security.secrets import set_secret

                set_secret("GITHUB_COPILOT_TOKEN", github_token)
                lc["providers"]["github_copilot"]["token"] = "SECRET[GITHUB_COPILOT_TOKEN]"
                console.print("  [green]\u2713[/green] Token stored in SecretStore")
            except Exception as exc:
                console.print(
                    f"  [yellow]Warning:[/yellow] SecretStore unavailable ({exc}).\n"
                    "  Token will be stored as plaintext in workpilot.local.yaml."
                )
                lc["providers"]["github_copilot"]["token"] = github_token
        elif github_token:
            lc["providers"]["github_copilot"]["token"] = github_token
        elif raw_token and raw_token != "${GITHUB_TOKEN}":
            # Preserve any user-set YAML token (plaintext, SECRET[OTHER], ${CUSTOM_ENV})
            # so a stored GITHUB_COPILOT_TOKEN doesn't silently overwrite it.
            lc["providers"]["github_copilot"]["token"] = raw_token
        elif has_stored_secret:
            lc["providers"]["github_copilot"]["token"] = "SECRET[GITHUB_COPILOT_TOKEN]"
        elif raw_token:
            lc["providers"]["github_copilot"]["token"] = raw_token
        else:
            lc["providers"]["github_copilot"]["token"] = "${GITHUB_TOKEN}"
        lc.setdefault("security", {})["profile"] = security_profile
        lc.setdefault("logging", {"level": "INFO", "format": "pretty"})
        gw = lc.setdefault("channels", {}).setdefault("web", {})
        gw["enabled"] = enable_web
        if enable_web:
            gw.setdefault("host", "localhost")
            gw.setdefault("port", current_gw.get("port", 3003))
        cloud_cfg = lc.setdefault("channels", {}).setdefault("cloud", {})
        cloud_cfg["enabled"] = enable_cloud
        return lc

    local_config: dict | None = None
    mcp_added: dict[str, Any] = {}

    try:
        # ── [1/5] GitHub token ────────────────────────────────────────
        if quick:
            if raw_token:
                github_token = None  # preserve existing reference as-is
            else:
                env_token = os.environ.get("GITHUB_TOKEN")
                if env_token:
                    console.print(
                        "  [dim]Found $GITHUB_TOKEN in environment \u2014 "
                        "storing in SecretStore.[/dim]"
                    )
                github_token = env_token or "${GITHUB_TOKEN}"
        elif current_token:
            _step_header(1, "GitHub Copilot (LLM Provider)")
            console.print("  [dim]WorkPilot uses GitHub Copilot as its AI engine.[/dim]")
            _GH_REAUTH_OPTS: list[tuple[str, str]] = [
                ("Keep current token", f"{current_token[:8]}..."),
                ("Re-authenticate with GitHub", "opens browser, paste a code to authorize"),
            ]
            choice = _select(_GH_REAUTH_OPTS, default=1)
            _step_done(_GH_REAUTH_OPTS[choice - 1][0])
            if choice == 2:
                with console.status("[bold cyan]Checking connectivity\u2026"):
                    online = _check_connectivity()
                if online:
                    from workpilot.security.github_auth import github_device_login

                    console.print(
                        "  [dim]Verify Enterprise access to WorkPilot: "
                        "https://github.com/gim-home/WorkPilot[/dim]"
                    )
                    try:
                        github_token = github_device_login(console=console)
                        if github_token:
                            _check_github_copilot_account(github_token)
                    except Exception as exc:
                        console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                        github_token = current_token
                else:
                    console.print(
                        "  [yellow]Cannot reach github.com \u2014 keeping current token[/yellow]"
                    )
                    github_token = current_token
            else:
                github_token = current_token
        else:
            _step_header(1, "GitHub Copilot (LLM Provider)")
            console.print("  [dim]WorkPilot uses GitHub Copilot as its AI engine.[/dim]")
            if has_stored_secret or raw_token.startswith("SECRET["):
                _skip_desc = "already configured (SecretStore)"
            elif uses_github_env_placeholder and not has_github_env_token:
                _skip_desc = "configure later \u2014 WorkPilot needs a token to run"
            elif raw_token.startswith("${"):
                _skip_desc = "configured via environment variable"
            elif raw_token:
                _skip_desc = "already configured"
            else:
                _skip_desc = "configure later \u2014 WorkPilot needs a token to run"
            _GH_NEW_OPTS: list[tuple[str, str]] = [
                ("Sign in with GitHub", "opens browser, paste a code to authorize"),
                ("Skip", _skip_desc),
            ]
            choice = _select(_GH_NEW_OPTS, default=2 if has_configured_token else 1)
            if choice == 2 and has_configured_token:
                _step_done(f"Skip \u2014 {_skip_desc}")
            else:
                _step_done(_GH_NEW_OPTS[choice - 1][0])
            if choice == 1:
                with console.status("[bold cyan]Checking connectivity\u2026"):
                    online = _check_connectivity()
                if online:
                    from workpilot.security.github_auth import github_device_login

                    console.print(
                        "  [dim]Verify Enterprise access to WorkPilot: "
                        "https://github.com/gim-home/WorkPilot[/dim]"
                    )
                    try:
                        github_token = github_device_login(console=console)
                        if github_token:
                            _check_github_copilot_account(github_token)
                    except Exception as exc:
                        console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                else:
                    console.print(
                        "  [yellow]Cannot reach github.com \u2014 "
                        "skipping GitHub auth.[/yellow]\n"
                        "  Run [bold]wp init[/bold] again when online."
                    )

        # ── [2/5] Security profile ────────────────────────────────────
        _PROFILES: list[tuple[str, str]] = [
            ("open", "AI runs freely, no confirmations needed"),
            ("standard", "AI asks before risky actions (recommended)"),
            ("controlled", "AI asks before most actions"),
            ("restricted", "AI asks before every action"),
        ]
        _PROFILE_NAMES = [p[0] for p in _PROFILES]
        if not quick:
            _step_header(2, "Security Profile")
            console.print("  [dim]Controls how much autonomy the AI agent has.[/dim]")
            default_idx = (
                (_PROFILE_NAMES.index(current_profile) + 1)
                if current_profile in _PROFILE_NAMES
                else 2
            )
            choice = _select(_PROFILES, default=default_idx)
            security_profile = _PROFILE_NAMES[choice - 1]
            _step_done(security_profile)

        # ── [3/5] Web channel (web server) ────────────────────────────
        if not quick:
            web_port = current_gw.get("port", 3003)
            _step_header(3, f"Web UI (localhost:{web_port})")
            console.print(f"  [dim]A local web chat interface at http://localhost:{web_port}[/dim]")
            _WEB_OPTS: list[tuple[str, str]] = [
                ("Enable", "access WorkPilot from your browser"),
                ("Disable", "CLI only, no web interface"),
            ]
            choice = _select(_WEB_OPTS, default=1 if current_gw_enabled else 2)
            enable_web = choice == 1
            _step_done("enabled" if enable_web else "disabled")

        # ── [4/5] Cloud channel (Teams, Web Chat) ─────────────────────
        if not quick:
            _step_header(4, "Cloud Connection (Teams, Web Chat)")
            console.print("  [dim]Connect to Microsoft Teams and Web Chat via cloud relay.[/dim]")
            _CLOUD_OPTS: list[tuple[str, str]] = [
                ("Enable", "chat with WorkPilot from Teams or browser"),
                ("Disable", "local only, no cloud connection"),
            ]
            choice = _select(_CLOUD_OPTS, default=1 if current_cloud_enabled else 2)
            enable_cloud = choice == 1
            _step_done("enabled" if enable_cloud else "disabled")

        # ── Checkpoint: persist steps 1-4 before cloud sign-in + MCP ──
        local_config = _build()
        save_yaml(local_path, local_config, header=header)

        # ── Cloud sub-step: sign-in only (Teams sideload deferred) ────
        if enable_cloud and not quick:
            console.print("  [cyan]\u2192[/cyan] [bold]Cloud sign-in[/bold]")
            _cloud_login_if_needed(dir_path)

        # ── [5/5] MCP Servers ─────────────────────────────────────────
        from workpilot.cli.mcp import _mcp_setup

        if quick:
            mcp_added = _mcp_setup(dir_path, local_config, select_all=True, quick=True, step=5)
        else:
            _step_header(5, "MCP Servers (external tools and data sources)")
            console.print(
                "  Press [bold cyan]Esc[/bold cyan] to skip "
                "[dim]\u2014 reconfigure anytime with[/dim] [bold]wp mcp setup[/bold]"
            )
            mcp_added = _mcp_setup(dir_path, local_config, step=5)

        # ── Final save (includes MCP mutations) ───────────────────────
        save_yaml(local_path, local_config, header=header)
    except KeyboardInterrupt:
        # Persist captured state so the next `wp init` picks up where we left off.
        if local_config is None:
            try:
                local_config = _build()
            except Exception:
                local_config = None
        if local_config is not None:
            try:
                save_yaml(local_path, local_config, header=header)
            except Exception:
                pass
        console.print(
            "\n[yellow]Cancelled.[/yellow] Progress saved \u2014 resume with [bold]wp init[/bold]."
        )
        raise SystemExit(130) from None

    assert local_config is not None  # success path guarantees this

    verb = "Updated" if is_update else "Created"
    console.print(f"\n  [green]\u2713[/green] [bold]{verb}[/bold] {local_path}")

    # ── Summary (always shown — both quick and interactive) ──────────
    token_ref = local_config.get("providers", {}).get("github_copilot", {}).get("token", "")
    if token_ref == "SECRET[GITHUB_COPILOT_TOKEN]":
        provider_desc = "GitHub Copilot [dim](SecretStore)[/dim]"
        token_ok = True
    elif token_ref.startswith("${"):
        var_name = token_ref.removeprefix("${").removesuffix("}")
        env_set = bool(var_name and os.environ.get(var_name))
        if env_set:
            provider_desc = f"GitHub Copilot [dim](env ${{{var_name}}})[/dim]"
        else:
            provider_desc = f"[yellow]GitHub Copilot \u2014 env ${{{var_name}}} not set[/yellow]"
        token_ok = env_set
    elif token_ref:
        provider_desc = "GitHub Copilot [dim](token set)[/dim]"
        token_ok = True
    else:
        provider_desc = "[yellow]not configured[/yellow]"
        token_ok = False

    # Cloud row: show signed-in state when enabled
    if enable_cloud:
        try:
            from workpilot.config.loader import load_config as _load_cfg
            from workpilot.mcp.auth import has_msal_account
            from workpilot.mcp.defaults import SHARED_ENTRA_CLIENT_ID

            _cfg = _load_cfg(str(dir_path))
            _client = _cfg.channels.cloud.client_id or ""
            _signed = (_client and has_msal_account(_client)) or has_msal_account(
                SHARED_ENTRA_CLIENT_ID
            )
            cloud_desc = (
                "enabled [dim](signed in)[/dim]"
                if _signed
                else "enabled [yellow](not signed in)[/yellow]"
            )
        except Exception:
            cloud_desc = "enabled"
    else:
        cloud_desc = "disabled"

    # MCP row: distinguish "just selected" vs "kept from previous config"
    prior_mcp = existing.get("tools", {}).get("mcp_servers") or {}
    prior_enabled = [
        n for n, v in prior_mcp.items() if isinstance(v, dict) and v.get("enabled", True)
    ]
    if mcp_added:
        mcp_desc = f"{len(mcp_added)} server(s) \u2014 [cyan]{', '.join(mcp_added)}[/cyan]"
    elif prior_enabled:
        mcp_desc = f"[dim]unchanged \u2014[/dim] [cyan]{', '.join(prior_enabled)}[/cyan]"
    else:
        mcp_desc = "[dim]none added[/dim]"

    summary = Table(show_header=False, box=None, padding=(0, 2))
    summary.add_column(style="bold")
    summary.add_column()
    summary.add_row("Provider", provider_desc)
    summary.add_row("Profile", security_profile)
    web_port = current_gw.get("port", 3003)
    summary.add_row("Web UI", f"enabled [dim](:{web_port})[/dim]" if enable_web else "disabled")
    summary.add_row("Cloud", cloud_desc)
    summary.add_row("MCP", mcp_desc)
    console.print(Panel(summary, title="Summary", border_style="cyan"))

    # ── Completion — next steps tailored to what was configured ───────
    lines: list[str] = ["[bold]Next steps:[/bold]"]
    if not token_ok:
        lines.append(
            "  [yellow]\u26a0[/yellow]  Store a token securely: "
            "[bold]wp secrets set GITHUB_COPILOT_TOKEN[/bold]"
        )
    cmds: list[tuple[str, str]] = []
    if enable_web or enable_cloud:
        cmds.append(("wp serve", "start server [dim](alias: wp s)[/dim]"))
    cmds.append(("wp chat", "chat in the terminal"))
    cmds.append(("wp doctor", "verify setup"))
    if enable_cloud:
        cmds.append(("wp teams install", "install the Teams app"))
    if not mcp_added and not prior_enabled:
        cmds.append(("wp mcp setup", "add external tools later"))
    # Pad command column so em-dashes align regardless of length
    pad = max(len(c) for c, _ in cmds)
    for cmd, desc in cmds:
        lines.append(f"  [bold]{cmd:<{pad}}[/bold]  \u2014 {desc}")

    console.print(
        Panel(
            "\n".join(lines),
            title="\u2728 Setup Complete",
            border_style="green",
        )
    )


# Backward-compat alias (hidden, not in help)
app.command("onboard", hidden=True)(init)
