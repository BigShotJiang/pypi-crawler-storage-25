"""Security CLI subcommands — workpilot security audit|credentials|roles|allowlist|status|estop|reset + secrets set|remove|test."""

from __future__ import annotations

import os
from pathlib import Path

import typer
from rich.panel import Panel
from rich.table import Table

from workpilot.cli.commands import (
    _get_runtime,
    _load_config_safe,
    console,
    secrets_app,
    security_app,
)

# ═══════════════════════════════════════════════════════════════════════════
# security sub-commands
# ═══════════════════════════════════════════════════════════════════════════


@security_app.command("audit")
def security_audit(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show security audit configuration and recent events."""
    cfg = _load_config_safe(config)

    console.print(Panel("[bold]Security Audit[/bold]", title="Audit", border_style="cyan"))

    table = Table(title="Audit Configuration")
    table.add_column("Setting", style="bold")
    table.add_column("Value")

    table.add_row(
        "Enabled", "[green]yes[/green]" if cfg.security.audit.enabled else "[red]no[/red]"
    )
    table.add_row(
        "Redact secrets",
        "[green]yes[/green]" if cfg.security.audit.redact_secrets else "[red]no[/red]",
    )
    table.add_row("Log file", cfg.security.audit.log_file or "[dim]stderr (default)[/dim]")

    console.print(table)

    # Show recent audit entries if a log file is configured
    audit_file = cfg.security.audit.log_file
    if audit_file:
        audit_path = Path(audit_file)
        if audit_path.exists():
            import json

            all_lines = audit_path.read_text(encoding="utf-8").splitlines()
            recent = all_lines[-10:]
            console.print(f"\n[bold]Recent audit events[/bold] (last {len(recent)}):")
            for line in recent:
                try:
                    entry = json.loads(line)
                    event = entry.get("event", "unknown")
                    ts = entry.get("ts", "")
                    console.print(f"  [{ts}] {event}")
                except json.JSONDecodeError:
                    continue
        else:
            console.print(f"\n[dim]Audit log file does not exist yet: {audit_path}[/dim]")

    # Sandbox summary
    console.print("\n[bold]Sandbox[/bold]")
    console.print(f"  Shell deny patterns:    {len(cfg.tools.shell.deny_patterns)}")
    console.print(f"  Shell timeout:          {cfg.tools.shell.timeout}s")
    console.print(f"  File size limit:        {cfg.tools.filesystem.max_file_size_bytes:,} bytes")
    console.print(f"  Workspace:              {cfg.workspace}")
    allowed_cfg = cfg.security.allowed_paths
    if not allowed_cfg:
        console.print("  Allowed paths:          (profile default)")
    else:
        console.print(
            f"  Allowed paths:          {'*' if '*' in allowed_cfg else len(allowed_cfg)}"
        )
    denied_cfg = cfg.security.denied_paths
    if not denied_cfg:
        console.print("  Denied paths:           (profile default)")
    else:
        console.print(f"  Denied paths:           {len(denied_cfg)}")


@security_app.command("credentials")
def security_credentials(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show credential provider status (never shows actual values)."""
    _load_config_safe(config)

    console.print(Panel("[bold]Credential Status[/bold]", border_style="cyan"))

    table = Table(title="Credentials")
    table.add_column("Credential", style="bold")
    table.add_column("Source")
    table.add_column("Status")

    creds_to_check = [
        ("GITHUB_TOKEN", "GitHub Copilot"),
        ("OPENAI_API_KEY", "OpenAI"),
        ("AZURE_API_KEY", "Azure (OpenAI / AI Foundry)"),
        ("AZURE_OPENAI_API_KEY", "Azure OpenAI (legacy)"),
        ("AZURE_AI_FOUNDRY_API_KEY", "Azure AI Foundry (legacy)"),
    ]

    for env_var, purpose in creds_to_check:
        val = os.environ.get(env_var, "")
        if val:
            table.add_row(env_var, purpose, "[green]set[/green]")
        else:
            table.add_row(env_var, purpose, "[dim]not set[/dim]")

    console.print(table)

    console.print("\n  Provider: [bold]env[/bold]")


@security_app.command("roles")
def security_roles(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show configured RBAC roles."""
    cfg = _load_config_safe(config)

    console.print(Panel("[bold]RBAC Roles[/bold]", border_style="cyan"))

    if not cfg.security.roles:
        console.print("[dim]No custom RBAC roles defined.[/dim]")
        console.print(f"  Default role: [bold]{cfg.security.default_role}[/bold]")
        console.print(f"  Require auth: {cfg.security.require_auth}")
        return

    table = Table(title="Roles")
    table.add_column("Role", style="bold")
    table.add_column("Allowed Tools")
    table.add_column("Denied Tools")
    table.add_column("Channels")
    table.add_column("Max Iter")

    for role_name, role in cfg.security.roles.items():
        is_default = " *" if role_name == cfg.security.default_role else ""
        table.add_row(
            role_name + is_default,
            ", ".join(role.allowed_tools),
            ", ".join(role.denied_tools) or "[dim]none[/dim]",
            ", ".join(role.allowed_channels),
            str(role.max_iterations),
        )

    console.print(table)
    console.print(f"\n  Default role: [bold]{cfg.security.default_role}[/bold]")
    console.print(f"  Require auth: {cfg.security.require_auth}")

    # Show security profile autonomy defaults
    try:
        from workpilot.security.rbac import PolicyEngine

        engine = PolicyEngine(cfg.security)
        profile_defaults = engine.PROFILE_DEFAULTS.get(cfg.security.profile, {})
        if profile_defaults:
            console.print(
                f"\n[bold]Profile '{cfg.security.profile.value}' autonomy defaults:[/bold]"
            )
            for category, level in profile_defaults.items():
                level_str = {0: "forbidden", 1: "approval", 2: "notify", 3: "autonomous"}.get(
                    level.value, str(level.value)
                )
                console.print(f"  {category:12s} -> {level_str}")
    except Exception:
        pass


@security_app.command("allowlist")
def security_allowlist(
    action: str = typer.Argument("list", help="Action: list, add, remove"),
    tool_name: str = typer.Option("", "--tool", "-t", help="Tool name (for add)"),
    pattern: str = typer.Option(
        "", "--pattern", "-p", help="Match pattern as key=regex (for add), e.g. command=npm.*"
    ),
    index: int = typer.Option(-1, "--index", "-i", help="Entry index (for remove)"),
    note: str = typer.Option("", "--note", "-n", help="Note (for add)"),
) -> None:
    """Manage the per-user tool approval allowlist."""
    from workpilot.config.loader import (
        append_local_config_list,
        load_config,
        remove_local_config_list,
    )
    from workpilot.security.allowlist import AllowlistManager

    def _persist_entry(entry_dict: dict) -> None:  # type: ignore[type-arg]
        append_local_config_list("security.allowlist.entries", entry_dict)

    def _remove_entry(index: int) -> None:
        remove_local_config_list("security.allowlist.entries", index)

    config = load_config()
    mgr = AllowlistManager(
        config.security.allowlist, persist_fn=_persist_entry, remove_fn=_remove_entry
    )

    if action == "list":
        entries = mgr.list_entries()
        if not entries:
            console.print("[dim]No allowlist entries.[/dim]")
            return
        table = Table(title="Tool Approval Allowlist")
        table.add_column("#", style="dim")
        table.add_column("Tool", style="bold")
        table.add_column("Match")
        table.add_column("Added By")
        table.add_column("Note")
        for i, entry in enumerate(entries):
            match_str = (
                " ".join(f"{k}={v}" for k, v in entry.match.items())
                if entry.match
                else "[dim]*[/dim]"
            )
            table.add_row(
                str(i),
                entry.tool,
                match_str,
                entry.added_by or "[dim]unknown[/dim]",
                entry.note or "",
            )
        console.print(table)

    elif action == "add":
        if not tool_name:
            console.print("[red]--tool is required for add[/red]")
            raise typer.Exit(1)
        match_override = None
        if pattern:
            # --pattern key=regex, e.g. --pattern "command=npm.*"
            if "=" in pattern:
                k, v = pattern.split("=", 1)
                match_override = {k.strip(): v.strip()}
            else:
                console.print("[yellow]--pattern should be key=regex (e.g. command=npm.*)[/yellow]")
                match_override = {"_pattern": pattern}
        entry = mgr.add(
            tool_name,
            match_override=match_override,
            added_by="cli",
            note=note,
        )
        match_str = " ".join(f"{k}={v}" for k, v in entry.match.items()) if entry.match else "*"
        console.print(
            f"  [green]\u2713[/green] Added [bold]{entry.tool}[/bold] (match={match_str})"
        )

    elif action == "remove":
        if index < 0:
            console.print("[red]--index is required for remove[/red]")
            raise typer.Exit(1)
        try:
            entry = mgr.remove(index)
            console.print(f"  [green]\u2713[/green] Removed [bold]{entry.tool}[/bold]")
        except IndexError:
            console.print(f"[red]Index {index} out of range[/red]")
            raise typer.Exit(1)

    else:
        console.print(f"[red]Unknown action: {action}. Use list, add, or remove.[/red]")
        raise typer.Exit(1)


@security_app.command("status")
def security_status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show security profile and E-stop state."""
    cfg = _load_config_safe(config)
    s = cfg.security

    table = Table(title="Security Status")
    table.add_column("Setting", style="bold")
    table.add_column("Value")
    table.add_row("Profile", s.profile.value)
    table.add_row("Audit enabled", "[green]yes[/green]" if s.audit.enabled else "[red]no[/red]")
    table.add_row(
        "Redact secrets", "[green]yes[/green]" if s.audit.redact_secrets else "[red]no[/red]"
    )
    table.add_row("E-stop on leak", "[green]yes[/green]" if s.estop.trigger_on_leak else "no")
    table.add_row("Require auth", "[green]yes[/green]" if s.require_auth else "no")
    console.print(table)
    console.print("\n[dim]To trigger E-stop: wp security estop[/dim]")


@security_app.command("estop")
def security_estop(
    reason: str = typer.Option("manual", "--reason", "-r", help="Reason for E-stop"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Trigger emergency stop — halts all agent activity."""
    if not yes:
        typer.confirm("[red]Trigger emergency stop?[/red] All tasks will be halted.", abort=True)
    rt = _get_runtime(config)
    rt.estop.trigger(reason, actor="cli-user")
    console.print(f"[red bold]E-stop triggered:[/red bold] {reason}")
    console.print("Run [cyan]wp security reset[/cyan] to resume.")


@security_app.command("reset")
def security_reset(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Reset E-stop and resume normal operation."""
    if not yes:
        typer.confirm("Reset E-stop and resume agent activity?", abort=True)
    rt = _get_runtime(config)
    rt.estop.reset(actor="cli-user")
    console.print("  [green]\u2713[/green] E-stop reset. Agent activity resumed.")


# ═══════════════════════════════════════════════════════════════════════════
# secrets sub-commands (set, get, remove, list, backend, test, encrypt/decrypt)
# ═══════════════════════════════════════════════════════════════════════════


def _get_store(config: str = "."):  # noqa: ANN202
    """Load config and return SecretStore."""
    from workpilot.security.secrets import get_secret_store

    cfg = _load_config_safe(config)
    return get_secret_store(cfg)


@secrets_app.command("set")
def secrets_set(
    name: str = typer.Argument(..., help="Secret name (e.g. GITHUB_TOKEN)"),
    from_env: str | None = typer.Option(None, "--from-env", help="Copy value from env var"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Set a secret in the local credential store."""
    store = _get_store(config)

    if from_env:
        value = os.environ.get(from_env)
        if not value:
            console.print(f"[red]Env var not set:[/red] {from_env}")
            raise typer.Exit(1)
        console.print(f"Copying {from_env} → credential store as {name}")
    else:
        from rich.prompt import Prompt

        value = Prompt.ask(
            f"Enter value for {name}",
            console=console,
            password=True,
            default="",
            show_default=False,
        )
        if not value:
            console.print("[red]Value cannot be empty.[/red]")
            raise typer.Exit(1)
        console.print(f"  [dim]({len(value)} characters)[/dim]")
        confirm = Prompt.ask(
            f"Confirm value for {name}",
            console=console,
            password=True,
            default="",
            show_default=False,
        )
        if value != confirm:
            console.print("[red]Values do not match.[/red]")
            raise typer.Exit(1)

    try:
        store.set(name, value)
    except Exception as exc:
        console.print(f"[red]Failed to store secret:[/red] {exc}")
        raise typer.Exit(1)

    info = store.backend_info()
    console.print(f"  [green]\u2713[/green] Secret stored: [bold]{name}[/bold]")
    console.print(f"  [dim]Backend: {info}[/dim]")

    # Auto-write SECRET[name] reference into workpilot.local.yaml for known keys
    from workpilot.security.migrate import SECRET_FIELD_PATHS

    config_path = next((p for p, s in SECRET_FIELD_PATHS.items() if s == name), None)
    if config_path:
        try:
            from workpilot.config.loader import set_local_config_value

            set_local_config_value(config_path, f"SECRET[{name}]")
            console.print(f"  [green]\u2713[/green] Config updated: [bold]{config_path}[/bold]")
        except Exception as exc:
            console.print(f"  [yellow]Warning:[/yellow] Could not update config: {exc}")

    # Warn only when the master key is actually sourced from a plain file
    from workpilot.security.secrets import (
        _try_master_key_from_env,
        _try_master_key_from_file,
        _try_master_key_from_keyring,
    )

    if (
        _try_master_key_from_file()
        and not _try_master_key_from_keyring()
        and not _try_master_key_from_env()
    ):
        from pathlib import Path

        key_file = Path.home() / ".workpilot" / "auth" / "master.key"
        console.print(
            f"[yellow]Note:[/yellow] Master key is stored as a plain file at {key_file}\n"
            "  For better security, install keyring: [bold]pip install keyring[/bold]"
        )


@secrets_app.command("get")
def secrets_get(
    name: str = typer.Argument(..., help="Secret name to retrieve"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Retrieve a secret value from the credential store."""
    store = _get_store(config)
    value = store.get(name)
    if value is None:
        console.print(f"[red]Secret not found:[/red] {name}")
        raise typer.Exit(1)
    masked = value[:4] + "***" + value[-4:] if len(value) > 8 else "***"
    console.print(f"[bold]{name}[/bold] = {masked}")


@secrets_app.command("remove")
def secrets_remove(
    name: str = typer.Argument(..., help="Secret name to remove"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Remove a secret from the local credential store."""
    store = _get_store(config)

    if not store.exists(name):
        console.print(f"[red]Secret not found:[/red] {name}")
        raise typer.Exit(1)

    if not yes:
        typer.confirm(f"Remove secret '{name}'?", abort=True)

    store.delete(name)
    console.print(f"  [green]\u2713[/green] Removed secret [bold]{name}[/bold]")

    # Auto-remove SECRET[name] reference from workpilot.local.yaml for known keys
    from workpilot.security.migrate import SECRET_FIELD_PATHS

    config_path = next((p for p, s in SECRET_FIELD_PATHS.items() if s == name), None)
    if config_path:
        try:
            from workpilot.config.loader import remove_local_config_value

            if remove_local_config_value(config_path):
                console.print(f"  [green]\u2713[/green] Config cleared: [bold]{config_path}[/bold]")
        except Exception as exc:
            console.print(f"  [yellow]Warning:[/yellow] Could not update config: {exc}")


@secrets_app.command("list")
def secrets_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List all stored secret names (never values)."""
    store = _get_store(config)
    names = store.list_names()
    if not names:
        console.print("[dim]No secrets stored.[/dim]")
        return
    table = Table(title="Stored Secrets")
    table.add_column("Name", style="bold")
    for n in sorted(names):
        table.add_row(n)
    console.print(table)


@secrets_app.command("backend")
def secrets_backend(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Display current secret store backend info."""
    import sys
    from pathlib import Path

    store = _get_store(config)
    console.print(f"[bold]Backend:[/bold] {store.backend_info()}")
    console.print(f"[bold]Platform:[/bold] {sys.platform}")

    # Master key status
    from workpilot.security.secrets import (
        _try_master_key_from_env,
        _try_master_key_from_file,
        _try_master_key_from_keyring,
    )

    if _try_master_key_from_keyring():
        console.print("[bold]Master key:[/bold] [green]OS keyring (secure)[/green]")
    elif _try_master_key_from_env():
        console.print("[bold]Master key:[/bold] [yellow]environment variable[/yellow]")
    elif _try_master_key_from_file():
        key_path = Path.home() / ".workpilot" / "auth" / "master.key"
        console.print(f"[bold]Master key:[/bold] [yellow]plain file ({key_path})[/yellow]")
    else:
        console.print("[bold]Master key:[/bold] [dim]not initialized[/dim]")

    # Keyring availability
    from workpilot.security.secrets import _keyring_available

    if _keyring_available():
        try:
            import keyring  # type: ignore[import]

            console.print(
                f"[bold]Keyring:[/bold] [green]{type(keyring.get_keyring()).__name__}[/green]"
            )
        except Exception:
            console.print("[bold]Keyring:[/bold] [green]available[/green]")
    else:
        console.print(
            "[bold]Keyring:[/bold] [dim]unavailable (install keyring for better security)[/dim]"
        )


@secrets_app.command("migrate-config")
def secrets_migrate_config(
    file: str | None = typer.Option(None, "--file", "-f", help="YAML config file"),
    all_fields: bool = typer.Option(
        False, "--all", help="Convert all SecretStr fields without prompting"
    ),
) -> None:
    """Move plaintext SecretStr values to SecretStore, replace with SECRET[name] in YAML."""
    from pathlib import Path

    import yaml

    from workpilot.security.migrate import _walk_yaml_secrets
    from workpilot.security.secrets import _atomic_write_file, get_secret_store

    store = get_secret_store()

    target = Path(file) if file else (Path.home() / ".workpilot" / "workpilot.local.yaml")
    if not target.is_file():
        console.print(f"[red]File not found:[/red] {target}")
        raise typer.Exit(1)

    content = target.read_text(encoding="utf-8")
    parsed = yaml.safe_load(content)
    if not isinstance(parsed, dict):
        console.print("[red]Invalid YAML.[/red]")
        raise typer.Exit(1)

    secrets_found = _walk_yaml_secrets(parsed)
    if not secrets_found:
        console.print("[dim]No plaintext secrets found to migrate.[/dim]")
        return

    # Interactive confirmation per field (unless --all)
    import re as _re

    new_content = content
    migrated_count = 0
    for yaml_path, store_key, plaintext in secrets_found:
        if not all_fields:
            if not typer.confirm(f"Move {yaml_path} → SECRET[{store_key}]?", default=True):
                continue
        store.set(store_key, plaintext)
        # Regex replace with count=1 to avoid replacing unrelated occurrences
        escaped = _re.escape(plaintext)
        pattern = _re.compile(r'(:\s*)"?' + escaped + r'"?\s*(?:#.*)?$', _re.MULTILINE)
        new_content = pattern.sub(rf'\1"SECRET[{store_key}]"', new_content, count=1)
        migrated_count += 1
        console.print(f"  {yaml_path} → SECRET[{store_key}]")

    if migrated_count == 0:
        console.print("[dim]No secrets migrated.[/dim]")
        return

    # Backup
    backup = target.with_suffix(target.suffix + ".pre-encrypt.bak")
    if not backup.exists():
        import shutil

        shutil.copy2(target, backup)
        console.print(f"[dim]Backup: {backup}[/dim]")

    _atomic_write_file(target, new_content)
    console.print(
        f"[green]Stored {migrated_count} secret(s) in SecretStore, updated {target}[/green]"
    )


@secrets_app.command("test")
def secrets_test(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Test configured secrets by making minimal API calls."""
    _load_config_safe(config)  # initializes SecretStore singleton

    results: list[tuple[str, str, str]] = []

    # GitHub token
    from workpilot.security.secrets import get_secret

    gh_token = (
        get_secret("GITHUB_COPILOT_TOKEN")
        or get_secret("GITHUB_TOKEN")
        or os.environ.get("GITHUB_TOKEN")
    )
    if gh_token:
        try:
            import urllib.request

            req = urllib.request.Request(
                "https://api.github.com/user",
                headers={"Authorization": f"Bearer {gh_token}", "User-Agent": "WorkPilot"},
            )
            with urllib.request.urlopen(req, timeout=5) as r:  # noqa: S310
                import json as _json

                user = _json.loads(r.read())["login"]
            results.append(("GITHUB_TOKEN", "[green]valid[/green]", f"@{user}"))
        except Exception as exc:
            results.append(("GITHUB_TOKEN", "[red]invalid[/red]", str(exc)[:60]))
    else:
        results.append(("GITHUB_TOKEN", "[dim]not set[/dim]", ""))

    # OpenAI
    oai_key = (
        get_secret("OPENAI_API_KEY")
        or get_secret("AZURE_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("AZURE_API_KEY")
    )
    if oai_key:
        try:
            import urllib.request

            req = urllib.request.Request(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {oai_key}"},
            )
            with urllib.request.urlopen(req, timeout=5) as r:  # noqa: S310
                pass
            results.append(("OPENAI_API_KEY", "[green]valid[/green]", ""))
        except Exception as exc:
            results.append(("OPENAI_API_KEY", "[red]invalid[/red]", str(exc)[:60]))
    else:
        results.append(("OPENAI_API_KEY", "[dim]not set[/dim]", ""))

    table = Table(title="Secrets Test")
    table.add_column("Secret", style="bold")
    table.add_column("Status")
    table.add_column("Info")
    for sname, status, info in results:
        table.add_row(sname, status, info)
    console.print(table)


@secrets_app.command("rotate-key")
def secrets_rotate_key(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Generate a new master key and re-encrypt all secrets."""
    from cryptography.fernet import Fernet

    from workpilot.security.secrets import (
        _KEYRING_SERVICE,
        _MASTER_KEY_KEYRING_NAME,
        _atomic_write_file,
        _keyring_available,
        _try_get_fernet,
        _try_master_key_from_env,
        decrypt_at_rest,
        encrypt_envelope,
        is_encrypted,
    )
    from workpilot.utils.helpers import get_auth_dir

    old_fernet = _try_get_fernet()
    if old_fernet is None:
        console.print("[red]No master key found. Nothing to rotate.[/red]")
        raise typer.Exit(1)

    # Refuse to rotate if key comes from env var — process would keep using old key
    if _try_master_key_from_env():
        console.print(
            "[red]Master key is currently provided via $WORKPILOT_MASTER_KEY.[/red]\n"
            "  Cannot safely rotate while this environment variable is set, because the\n"
            "  running process would continue using the old key and be unable to decrypt\n"
            "  newly re-encrypted data.\n"
            "  Please unset or update $WORKPILOT_MASTER_KEY to the new key before retrying."
        )
        raise typer.Exit(1)

    if not yes:
        typer.confirm("Rotate master key? This re-encrypts all secrets.", abort=True)

    new_key = Fernet.generate_key()
    new_fernet = Fernet(new_key)
    auth_dir = get_auth_dir()
    total = 0

    # 1. Rotate secrets.json.enc
    store = _get_store(config)
    from workpilot.security.secrets_fernet import FernetBackend

    if isinstance(store, FernetBackend):
        count = store.rotate_all(old_fernet, new_fernet)
        total += count
        console.print(f"  Rotated {count} secret(s) in store")

    # 2. SECRET[name] refs in YAML don't need rotation — they're just names.
    #    Only the SecretStore internal tokens (step 2) and MSAL caches need rotation.

    # 3. Rotate MSAL token caches
    msal_failures: list[str] = []
    for cache_file in auth_dir.glob("token_cache_*.bin"):
        try:
            raw = cache_file.read_bytes()
            if is_encrypted(raw):
                plaintext = decrypt_at_rest(raw)
                if not plaintext:
                    msal_failures.append(cache_file.name)
                    continue
                rotated = encrypt_envelope(new_fernet, plaintext)
                _atomic_write_file(cache_file, rotated)
                total += 1
                console.print(f"  Rotated {cache_file.name}")
        except Exception as exc:
            msal_failures.append(cache_file.name)
            console.print(f"  [yellow]Skip {cache_file.name}: {exc}[/yellow]")

    if msal_failures:
        console.print(
            f"[yellow]Warning: {len(msal_failures)} MSAL cache(s) could not be rotated.\n"
            "  They will be re-acquired on next login.[/yellow]"
        )
        # Delete unrotatable caches — MSAL re-acquires tokens automatically
        for name in msal_failures:
            (auth_dir / name).unlink(missing_ok=True)

    # 4. Persist new master key AFTER all rotation succeeds
    if _keyring_available():
        import keyring  # type: ignore[import]

        keyring.set_password(_KEYRING_SERVICE, _MASTER_KEY_KEYRING_NAME, new_key.decode())
        console.print("  New master key stored in OS keyring")
    else:
        key_path = auth_dir / "master.key"
        _atomic_write_file(key_path, new_key)
        console.print(f"  New master key stored at {key_path}")

    # Invalidate cached fernet so subsequent calls use the new key
    from workpilot.security.secrets import reset_secret_store

    reset_secret_store()

    console.print(f"[green]Key rotation complete:[/green] {total} item(s) re-encrypted")


@secrets_app.command("rollback-migration")
def secrets_rollback_migration(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Restore pre-migration backup files and reset migration state."""
    import json as _json
    from pathlib import Path

    from workpilot.utils.helpers import get_auth_dir

    state_file = get_auth_dir() / "migration.json"

    # Collect backup paths from migration.json state + filesystem scan
    backups: list[Path] = []
    if state_file.is_file():
        try:
            state = _json.loads(state_file.read_text(encoding="utf-8"))
            for _key, entry in state.items():
                if isinstance(entry, dict) and "backup" in entry:
                    bp = Path(entry["backup"])
                    if bp.is_file() and bp not in backups:
                        backups.append(bp)
        except Exception:
            pass

    # Also scan ~/.workpilot for any backups not tracked in state
    home = Path.home() / ".workpilot"
    for b in home.glob("*.pre-encrypt.bak"):
        if b not in backups:
            backups.append(b)

    if not backups and not state_file.is_file():
        console.print("[dim]No migration backups or state found. Nothing to rollback.[/dim]")
        return

    console.print(f"Found {len(backups)} backup file(s):")
    for b in backups:
        original = Path(str(b).replace(".pre-encrypt.bak", ""))
        console.print(f"  {b.name} → {original.name}")

    if not yes:
        typer.confirm("Restore all backup files and reset migration state?", abort=True)

    restored = 0
    for b in backups:
        original = Path(str(b).replace(".pre-encrypt.bak", ""))
        try:
            b.replace(original)
            restored += 1
            console.print(f"  [green]Restored:[/green] {original.name}")
        except Exception as exc:
            console.print(f"  [red]Failed:[/red] {b.name}: {exc}")

    if state_file.is_file():
        state_file.unlink()
        console.print("  [green]Reset:[/green] migration.json")

    console.print(f"[green]Rollback complete:[/green] {restored} file(s) restored")
