"""Agents CLI subcommands — workpilot agents list|add."""

from __future__ import annotations

import typer
import yaml
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    agents_app,
    console,
)
from workpilot.cli.commands import (
    resolve_config_path as _resolve_config_path,
)
from workpilot.cli.commands import (
    resolve_local_config_path as _resolve_local_config_path,
)


@agents_app.command("list")
def agents_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """List all configured agents."""
    cfg = _load_config_safe(config, profile)

    table = Table(title="Configured Agents")
    table.add_column("Name", style="bold")
    table.add_column("Model")
    table.add_column("Max Iter")
    table.add_column("Tools")
    table.add_column("Entrypoint")

    entry = cfg.entrypoint
    table.add_row(
        "default",
        cfg.agents.default.model,
        str(cfg.agents.default.max_iterations),
        "(all)" if cfg.agents.default.tools is None else ", ".join(cfg.agents.default.tools),
        "[green]yes[/green]" if entry == "default" else "",
    )
    for name, ag in cfg.agents.agents.items():
        table.add_row(
            name,
            ag.model,
            str(ag.max_iterations),
            "(all)" if ag.tools is None else ", ".join(ag.tools),
            "[green]yes[/green]" if entry == name else "",
        )
    console.print(table)


@agents_app.command("add")
def agents_add(
    name: str = typer.Argument(..., help="Agent name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add a new agent interactively (writes to workpilot.local.yaml)."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    # Interactive prompts for agent settings
    model: str = typer.prompt("Model", default="auto")
    instructions: str = typer.prompt("Instructions", default="You are a helpful assistant.")
    max_iterations: int = int(typer.prompt("Max iterations", default="25"))

    # Read local override to update (never touch the base workpilot.yaml)
    local_raw = (
        yaml.safe_load(local_path.read_text(encoding="utf-8")) if local_path.is_file() else {}
    )
    local_raw = local_raw or {}
    agents_section = local_raw.setdefault("agents", {})
    agents_section[name] = {
        "model": model,
        "instructions": instructions,
        "max_iterations": max_iterations,
        "tools": [
            "shell",
            "read_file",
            "write_file",
            "edit_file",
            "list_dir",
            "git",
            "http_request",
        ],
    }
    from workpilot.config.loader import save_yaml

    save_yaml(local_path, local_raw)
    console.print(f"  [green]\u2713[/green] Agent [bold]{name}[/bold] added to {local_path}")
