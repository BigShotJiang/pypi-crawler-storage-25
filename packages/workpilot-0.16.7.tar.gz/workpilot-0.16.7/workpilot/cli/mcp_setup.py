"""MCP setup — authenticate & verify with live animated status display.

Live display never stops. Auth menus are rendered inline. MSAL and
GitHub device code run in background threads so spinners keep animating.
"""

from __future__ import annotations

import sys
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any

from rich.console import Group as RenderGroup
from rich.spinner import Spinner
from rich.table import Table as RichTable
from rich.text import Text

from workpilot.cli.commands import _load_config_safe, console
from workpilot.utils.input import is_tty

# ── Data model ───────────────────────────────────────────────────────────────


class ServerPhase(Enum):
    QUEUED = auto()
    TESTING = auto()
    OK = auto()
    FAIL = auto()
    SKIPPED = auto()


class AuthGroupState(Enum):
    PENDING = auto()
    CACHED = auto()
    MENU_ACTIVE = auto()
    SIGNING_IN = auto()
    DONE = auto()
    FAILED = auto()


class AuthGroup(Enum):
    NONE = "no-auth"
    GITHUB = "GitHub"
    ENTRA = "Microsoft 365"


class InlineMenu:
    """Menu state rendered inside the Live display."""

    def __init__(
        self,
        title: str,
        options: list[tuple[str, str]],
        default: int = 0,
        error: str = "",
        hint: str = "",
    ) -> None:
        self.title = title
        self.options = options
        self.selected = default
        self.result: str | None = None
        self.dismissed = False
        self.error: str = error
        self.hint: str = hint

    def handle_key(self, key: str) -> None:
        if self.dismissed:
            return
        if key == "up":
            self.selected = (self.selected - 1) % len(self.options)
        elif key == "down":
            self.selected = (self.selected + 1) % len(self.options)
        elif key == "enter":
            self.result = self.options[self.selected][0]
            self.dismissed = True
        elif key == "esc":
            self.result = self.options[-1][0]
            self.dismissed = True

    def render(self) -> Text:
        lines: list[str] = []
        if self.error:
            lines.append(f"  [red]Sign-in failed:[/red] {self.error}")
        lines.append(f"  [bold]{self.title}[/bold]")
        for i, (_, label) in enumerate(self.options):
            marker = ">" if i == self.selected else " "
            if i == self.selected:
                lines.append(f"  [bold cyan]{marker} {label}[/bold cyan]")
            else:
                lines.append(f"  [white]{marker} {label}[/white]")
        if self.hint:
            lines.append(f"  [dim]{self.hint}[/dim]")
        lines.append("  [dim]\u2191\u2193 Up/Down switch  \u23ce Enter confirm  Esc skip[/dim]")
        return Text.from_markup("\n".join(lines))


@dataclass
class AuthGroupStatus:
    group: AuthGroup
    state: AuthGroupState
    servers: list[str] = field(default_factory=list)
    menu: InlineMenu | None = None
    auth_thread: threading.Thread | None = None
    auth_result: str | None = None  # token set by background thread
    auth_error: str = ""
    signing_in_method: str = ""  # "browser" or "native"
    # GitHub device code fields (shown in Live, used by poll thread).
    device_code_url: str = ""
    device_code_user_code: str = ""
    device_browser_opened: bool = False
    gh_client_id: str = ""
    gh_device_code: str = ""
    gh_interval: int = 5
    gh_expires_in: int = 900


# ── Pure render function ─────────────────────────────────────────────────────

_spinner = Spinner("dots")


def render_table(
    selected: list[str],
    server_phase: dict[str, ServerPhase],
    server_msg: dict[str, str],
    groups: dict[AuthGroup, AuthGroupStatus],
    active_group: AuthGroup | None,
) -> RenderGroup:
    """Build the Rich renderable from state snapshots. No side effects."""
    tbl = RichTable(box=None, show_header=False, padding=(0, 1))
    tbl.add_column(width=3)
    tbl.add_column(min_width=20)
    tbl.add_column()

    for name in selected:
        phase = server_phase.get(name, ServerPhase.QUEUED)
        msg = server_msg.get(name, "")
        if phase == ServerPhase.OK:
            tbl.add_row("  [green]\u2713[/green]", f"[bold]{name}[/bold]", Text(msg))
        elif phase == ServerPhase.FAIL:
            tbl.add_row("  [yellow]\u2717[/yellow]", f"[bold]{name}[/bold]", Text(msg))
        elif phase == ServerPhase.TESTING:
            tbl.add_row(_spinner, Text(name, style="bold"), Text("connecting...", style="dim"))
        elif phase == ServerPhase.SKIPPED:
            tbl.add_row("  [dim]-[/dim]", f"[dim]{name}[/dim]", Text("skipped", style="dim"))
        elif phase == ServerPhase.QUEUED:
            # Show signing-in status for queued servers in active auth group.
            grp = _find_group(name, groups)
            if grp and grp.state == AuthGroupState.SIGNING_IN:
                method = grp.signing_in_method or "..."
                tbl.add_row(
                    _spinner,
                    f"[dim]{name}[/dim]",
                    Text(f"signing in ({method})...", style="dim"),
                )
            elif grp and grp.state == AuthGroupState.FAILED:
                tbl.add_row(
                    "  [red]![/red]",
                    f"[dim]{name}[/dim]",
                    Text(f"needs {grp.group.value} login", style="dim"),
                )
            else:
                grp_label = grp.group.value if grp else "auth"
                tbl.add_row(
                    "  [dim]\u25cb[/dim]",
                    f"[dim]{name}[/dim]",
                    Text(f"needs {grp_label} login", style="dim"),
                )

    parts: list[Any] = [tbl]

    # Active auth group: show menu or device code info.
    if active_group:
        ag = groups.get(active_group)
        if ag:
            if ag.state == AuthGroupState.MENU_ACTIVE and ag.menu:
                parts.append(Text(""))
                parts.append(ag.menu.render())
            elif ag.state == AuthGroupState.SIGNING_IN and ag.group == AuthGroup.GITHUB:
                lines = [
                    "  [bold]GitHub[/bold] -- device code login",
                    f"  URL:  [cyan]{ag.device_code_url}[/cyan]",
                    f"  Code: [yellow bold]{ag.device_code_user_code}[/yellow bold]",
                ]
                if ag.device_browser_opened:
                    lines.append("  [dim]Browser opened -- waiting for authorization...[/dim]")
                else:
                    lines.append("  Press [bold]Enter[/bold] to open browser...")
                parts.append(Text.from_markup("\n".join(lines)))
            elif ag.state == AuthGroupState.SIGNING_IN and ag.group == AuthGroup.ENTRA:
                method = ag.signing_in_method or "..."
                if method == "native":
                    hint = (
                        "  [dim]An OS account picker should appear.\n"
                        "  If you don't see it, check behind this terminal window.[/dim]"
                    )
                else:
                    hint = (
                        "  [dim]A browser window should open.\n"
                        "  Please complete sign-in in the browser, then return here.[/dim]"
                    )
                parts.append(Text.from_markup(hint))

    return RenderGroup(*parts)


def _find_group(name: str, groups: dict[AuthGroup, AuthGroupStatus]) -> AuthGroupStatus | None:
    for ag in groups.values():
        if name in ag.servers:
            return ag
    return None


# ── Auth workers (background threads) ────────────────────────────────────────


def _entra_auth_worker(
    ag: AuthGroupStatus,
    client_id: str,
    scopes: list[str],
    use_wam: bool,
) -> None:
    """Run MSAL login in background thread. Sets ag.auth_result / ag.auth_error."""
    try:
        token = _direct_entra_login(client_id, scopes, use_wam=use_wam, quiet=True)
        ag.auth_result = token
        if not token:
            ag.auth_error = "login failed or cancelled"
    except Exception as exc:
        ag.auth_error = str(exc)


def _github_auth_worker(ag: AuthGroupStatus, stop_event: threading.Event) -> None:
    """Run GitHub device code polling in background. Sets ag.auth_result / ag.auth_error."""
    try:
        from workpilot.security.github_auth import github_poll_device_code

        token = github_poll_device_code(
            client_id=ag.gh_client_id,
            device_code=ag.gh_device_code,
            interval=ag.gh_interval,
            expires_in=ag.gh_expires_in,
            stop_event=stop_event,
        )
        ag.auth_result = token
        try:
            from workpilot.security.secrets import get_secret_store

            get_secret_store().set("GITHUB_TOKEN", token)
        except Exception:
            pass
    except Exception as exc:
        ag.auth_error = str(exc)


# ── Main entry point ─────────────────────────────────────────────────────────


def _has_broker_account(client_id: str) -> bool:
    """Check if the broker cache has a cached account (broker-only, not browser)."""
    try:
        import msal

        from workpilot.security.secrets import decrypt_at_rest
        from workpilot.utils.helpers import get_auth_dir

        path = get_auth_dir() / f"token_cache_{client_id[:8]}_broker.bin"
        if not path.exists():
            return False
        cache = msal.SerializableTokenCache()
        raw = decrypt_at_rest(path.read_bytes())
        if raw:
            cache.deserialize(raw.decode("utf-8"))
        return bool(list(cache.search(msal.TokenCache.CredentialType.ACCOUNT)))
    except Exception:
        return False


def auth_and_verify(
    selected: list[str],
    merged_servers: dict[str, Any],
    config_dir: Path,
    *,
    quick: bool = False,
) -> list[str]:
    """Authenticate and verify servers with live animated status.

    Live display runs continuously. Auth menus are rendered inline.
    MSAL and GitHub device code run in background threads.
    """
    from rich.live import Live

    from workpilot.mcp.auth import (
        _resolve_github_token,
        has_msal_browser_session,
    )
    from workpilot.mcp.defaults import SHARED_ENTRA_CLIENT_ID
    from workpilot.utils.auth import _broker_kwargs

    cfg = _load_config_safe(str(config_dir))

    # ── Classify servers ─────────────────────────────────────────────
    groups: dict[AuthGroup, AuthGroupStatus] = {}
    for name in selected:
        srv = merged_servers.get(name)
        if name == "github":
            groups.setdefault(
                AuthGroup.GITHUB, AuthGroupStatus(AuthGroup.GITHUB, AuthGroupState.PENDING)
            )
            groups[AuthGroup.GITHUB].servers.append(name)
        elif srv and srv.url and srv.auth.client_id and srv.auth.type in ("oauth", "implicit"):
            groups.setdefault(
                AuthGroup.ENTRA, AuthGroupStatus(AuthGroup.ENTRA, AuthGroupState.PENDING)
            )
            groups[AuthGroup.ENTRA].servers.append(name)
        else:
            groups.setdefault(AuthGroup.NONE, AuthGroupStatus(AuthGroup.NONE, AuthGroupState.DONE))
            groups[AuthGroup.NONE].servers.append(name)

    # ── Server-level state ───────────────────────────────────────────
    lock = threading.Lock()
    server_phase: dict[str, ServerPhase] = {}
    server_msg: dict[str, str] = {}
    for name in selected:
        grp = _find_group(name, groups)
        if grp and grp.group == AuthGroup.NONE:
            server_phase[name] = ServerPhase.TESTING
        else:
            server_phase[name] = ServerPhase.QUEUED

    threads: list[threading.Thread] = []
    github_stop = threading.Event()

    def _verify_one(name: str) -> None:
        with lock:
            server_phase[name] = ServerPhase.TESTING
        try:
            from workpilot.cli.mcp import _test_one_sync

            ok, msg, _ = _test_one_sync(name, cfg)
        except Exception as exc:
            ok, msg = False, str(exc)
        with lock:
            server_phase[name] = ServerPhase.OK if ok else ServerPhase.FAIL
            server_msg[name] = msg

    def _start_verify(names: list[str]) -> None:
        for n in names:
            if not cfg.tools.mcp_servers.get(n):
                with lock:
                    server_phase[n] = ServerPhase.FAIL
                    server_msg[n] = "not in config"
                continue
            t = threading.Thread(target=_verify_one, args=(n,), daemon=True)
            t.start()
            threads.append(t)

    def _mark_skipped(names: list[str]) -> None:
        with lock:
            for n in names:
                server_phase[n] = ServerPhase.SKIPPED

    def _snap() -> tuple[dict[str, ServerPhase], dict[str, str]]:
        with lock:
            return dict(server_phase), dict(server_msg)

    # ── Resolve cached auth (no menu needed) ─────────────────────────
    # No-auth: start immediately.
    if AuthGroup.NONE in groups:
        _start_verify(groups[AuthGroup.NONE].servers)

    # GitHub: check cached token.
    if AuthGroup.GITHUB in groups:
        gh_ag = groups[AuthGroup.GITHUB]
        if _resolve_github_token():
            gh_ag.state = AuthGroupState.CACHED
            _start_verify(gh_ag.servers)
        elif quick:
            gh_ag.state = AuthGroupState.DONE
            _mark_skipped(gh_ag.servers)
            selected = [n for n in selected if n not in gh_ag.servers]

    # Entra: check cached session.
    if AuthGroup.ENTRA in groups:
        en_ag = groups[AuthGroup.ENTRA]
        if has_msal_browser_session(SHARED_ENTRA_CLIENT_ID) or (
            _broker_kwargs() and _has_broker_account(SHARED_ENTRA_CLIENT_ID)
        ):
            en_ag.state = AuthGroupState.CACHED
            _start_verify(en_ag.servers)
        elif quick:
            en_ag.state = AuthGroupState.DONE
            _mark_skipped(en_ag.servers)
            selected = [n for n in selected if n not in en_ag.servers]

    # ── Build auth queue (groups still PENDING) ──────────────────────
    auth_queue = [
        g
        for g in [AuthGroup.GITHUB, AuthGroup.ENTRA]
        if g in groups and groups[g].state == AuthGroupState.PENDING
    ]
    active_group: AuthGroup | None = None

    def _activate_next() -> None:
        nonlocal active_group
        while auth_queue:
            ag_key = auth_queue.pop(0)
            ag = groups[ag_key]
            if ag.state != AuthGroupState.PENDING:
                continue
            active_group = ag_key
            if ag.group == AuthGroup.GITHUB:
                _activate_github(ag)
            elif ag.group == AuthGroup.ENTRA:
                _activate_entra(ag)
            return
        active_group = None

    # Build Entra menu options.
    # WAM broker works for MCP: PRT silently gets scoped tokens (no
    # refresh_token needed).  Login uses scopes=[] (creates PRT session);
    # MCP scopes are used later via _try_silent_broker.
    entra_options: list[tuple[str, str]] = []
    if _broker_kwargs():
        entra_options.append(("native", "OS account picker"))
    entra_options.extend(
        [
            ("browser", "Browser sign-in"),
            ("skip", "Skip for now"),
        ]
    )

    def _activate_github(ag: AuthGroupStatus) -> None:
        """Start GitHub device code flow: request code, then poll in background."""
        try:
            from workpilot.mcp.defaults import GH_CLI_CLIENT_ID, GH_MCP_SCOPE
            from workpilot.security.github_auth import github_request_device_code

            info = github_request_device_code(client_id=GH_CLI_CLIENT_ID, scope=GH_MCP_SCOPE)
            ag.device_code_url = str(info["verification_uri"])
            ag.device_code_user_code = str(info["user_code"])
            # Stash polling params for the worker thread.
            ag.gh_client_id = GH_CLI_CLIENT_ID
            ag.gh_device_code = str(info["device_code"])
            ag.gh_interval = int(info["interval"])
            ag.gh_expires_in = int(info["expires_in"])
            ag.state = AuthGroupState.SIGNING_IN
            t = threading.Thread(target=_github_auth_worker, args=(ag, github_stop), daemon=True)
            t.start()
            ag.auth_thread = t
        except Exception as exc:
            ag.auth_error = str(exc)
            ag.state = AuthGroupState.FAILED

    def _activate_entra(ag: AuthGroupStatus) -> None:
        ag.menu = InlineMenu(
            "Microsoft 365 sign-in (for Teams, Calendar, Mail, etc.):",
            entra_options,
            error=ag.auth_error,
            hint="Sign in with your work account to verify MCP server connectivity.",
        )
        ag.state = AuthGroupState.MENU_ACTIVE

    def _start_entra_login(ag: AuthGroupStatus, choice: str) -> None:
        """Spawn background thread for MSAL login."""
        use_wam = choice == "native"
        ag.signing_in_method = "native" if use_wam else "browser"
        ag.state = AuthGroupState.SIGNING_IN
        first_scope: list[str] = ["openid"]
        for name in ag.servers:
            _srv = merged_servers.get(name)
            if _srv and _srv.url and _srv.auth.scopes:
                first_scope = _srv.auth.scopes
                break
        t = threading.Thread(
            target=_entra_auth_worker,
            args=(ag, SHARED_ENTRA_CLIENT_ID, first_scope, use_wam),
            daemon=True,
        )
        t.start()
        ag.auth_thread = t

    # ── Non-TTY fast path ────────────────────────────────────────────
    if not is_tty():
        # No interactive menus. Skip all pending auth groups.
        for _skip_key in list(auth_queue):
            _skip_ag = groups[_skip_key]
            _skip_ag.state = AuthGroupState.DONE
            _mark_skipped(_skip_ag.servers)
            selected = [n for n in selected if n not in _skip_ag.servers]
        auth_queue.clear()

    # Activate first pending group.
    _activate_next()

    # ── Key reader thread ─────────────────────────────────────────────
    # read_key_nonblocking + setraw/restore per iteration is unreliable
    # on macOS: termios state toggling loses keystrokes and splits ESC
    # sequences.  Instead, a dedicated thread holds raw mode and uses
    # select with a short timeout so key_stop can break the loop.
    import queue as _queue

    key_queue: _queue.Queue[str | None] = _queue.Queue()
    key_stop = threading.Event()

    def _key_reader() -> None:
        """Read keys in raw mode with select-based polling.

        Uses select(0.2s) so key_stop is checked ~5×/s and the thread
        exits promptly on shutdown.  termios is restored in the finally
        block regardless of how the thread exits.
        """
        if sys.platform == "win32":
            # Windows: msvcrt doesn't need termios; poll with kbhit().
            import msvcrt

            while not key_stop.is_set():
                if msvcrt.kbhit():  # type: ignore[attr-defined]
                    try:
                        ch = msvcrt.getwch()  # type: ignore[attr-defined]
                        if ch == "\x03":
                            key_queue.put(None)
                            return
                        if ch in ("\x00", "\xe0"):
                            ch2 = msvcrt.getwch()  # type: ignore[attr-defined]
                            key_queue.put(
                                {"H": "up", "P": "down", "K": "left", "M": "right"}.get(ch2, "")
                            )
                        elif ch == "\r":
                            key_queue.put("enter")
                        elif ch == "\x1b":
                            key_queue.put("esc")
                        elif ch == " ":
                            key_queue.put("space")
                        elif ch == "\t":
                            key_queue.put("tab")
                        else:
                            key_queue.put(ch)
                    except (EOFError, OSError):
                        return
                else:
                    key_stop.wait(0.2)
            return

        import select
        import termios
        import tty

        from workpilot.utils.input import _parse_unix_key

        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            while not key_stop.is_set():
                if not select.select([fd], [], [], 0.2)[0]:
                    continue  # no input — check key_stop again
                try:
                    key_queue.put(_parse_unix_key(fd))
                except KeyboardInterrupt:
                    key_queue.put(None)  # Ctrl+C
                    return
        except (EOFError, OSError):
            pass
        finally:
            try:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
            except OSError:
                pass  # fd closed / invalid during shutdown

    _kt: threading.Thread | None = None
    if is_tty():
        _kt = threading.Thread(target=_key_reader, daemon=True)
        _kt.start()

    # ── Live loop ────────────────────────────────────────────────────
    live = Live(
        render_table(selected, *_snap(), groups, active_group),
        console=console,
        refresh_per_second=8,
    )
    live.start()

    try:
        while True:
            key: str | None = None
            try:
                key = key_queue.get_nowait()
                if key is None:  # Ctrl+C from reader thread
                    github_stop.set()
                    break
            except _queue.Empty:
                pass

            ag: AuthGroupStatus | None = groups.get(active_group) if active_group else None

            if ag:
                # ── MENU_ACTIVE: handle key input ────────────────────
                if ag.state == AuthGroupState.MENU_ACTIVE and ag.menu:
                    if key:
                        ag.menu.handle_key(key)
                    if ag.menu.dismissed:
                        choice = ag.menu.result or "skip"
                        ag.menu = None
                        if choice == "skip":
                            ag.state = AuthGroupState.DONE
                            _mark_skipped(ag.servers)
                            selected = [n for n in selected if n not in ag.servers]
                            _activate_next()
                        else:
                            _start_entra_login(ag, choice)

                # ── SIGNING_IN: check if thread finished ─────────────
                elif ag.state == AuthGroupState.SIGNING_IN:
                    # GitHub: Enter opens browser, ESC skips.
                    if ag.group == AuthGroup.GITHUB and key == "enter":
                        if not ag.device_browser_opened:
                            import webbrowser

                            webbrowser.open(ag.device_code_url)
                            ag.device_browser_opened = True
                    elif ag.group == AuthGroup.GITHUB and key == "esc":
                        github_stop.set()
                        ag.state = AuthGroupState.DONE
                        _mark_skipped(ag.servers)
                        selected = [n for n in selected if n not in ag.servers]
                        _activate_next()
                        continue

                    if ag.auth_thread and not ag.auth_thread.is_alive():
                        if ag.auth_result:
                            ag.state = AuthGroupState.DONE
                            _start_verify(ag.servers)
                            _activate_next()
                        else:
                            ag.state = AuthGroupState.FAILED

                # ── FAILED: transition back to menu ──────────────────
                elif ag.state == AuthGroupState.FAILED:
                    if ag.group == AuthGroup.ENTRA:
                        _activate_entra(ag)
                    elif ag.group == AuthGroup.GITHUB:
                        # GitHub device code can't easily retry inline.
                        ag.state = AuthGroupState.DONE
                        _mark_skipped(ag.servers)
                        selected = [n for n in selected if n not in ag.servers]
                        _activate_next()

            # Update display.
            phases, msgs = _snap()
            live.update(render_table(selected, phases, msgs, groups, active_group))

            # All done?
            if active_group is None:
                alive = [t for t in threads if t.is_alive()]
                if not alive:
                    break

            time.sleep(0.1)

    except KeyboardInterrupt:
        github_stop.set()
    finally:
        key_stop.set()  # signal key reader thread to exit
        if _kt is not None:
            _kt.join(timeout=1)  # wait for termios restore
        phases, msgs = _snap()
        live.update(render_table(selected, phases, msgs, groups, active_group))
        live.stop()

    return selected


# ── Direct MSAL login (called from background thread) ────────────────────────


def _direct_entra_login(
    client_id: str,
    scopes: list[str],
    *,
    use_wam: bool = False,
    quiet: bool = False,
) -> str | None:
    """Perform a direct MSAL interactive login (browser or WAM).

    When *quiet* is True, suppresses all console output (for background threads).
    """
    import msal

    from workpilot.utils.auth import _broker_kwargs, _persist_cache
    from workpilot.utils.helpers import get_auth_dir

    suffix = "_broker" if use_wam else ""
    cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}{suffix}.bin"
    cache = msal.SerializableTokenCache()
    if cache_path.exists():
        try:
            from workpilot.security.secrets import decrypt_at_rest

            raw = decrypt_at_rest(cache_path.read_bytes())
            if raw:
                cache.deserialize(raw.decode("utf-8"))
        except Exception:
            pass

    bkw = _broker_kwargs() if use_wam else {}
    app = msal.PublicClientApplication(
        client_id,
        authority="https://login.microsoftonline.com/organizations",
        token_cache=cache,
        **bkw,
    )

    wam_kwargs: dict[str, Any] = {}
    if use_wam and bkw:
        from workpilot.utils.auth import _get_foreground_window_handle

        wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(app)

    # WAM broker uses empty scopes for login (PRT session creation).
    # MCP-specific scopes are requested later via _try_silent_broker
    # (acquire_token_interactive with prompt="none").
    interactive_scopes = [] if (use_wam and bkw) else scopes

    result = app.acquire_token_interactive(
        scopes=interactive_scopes, prompt="select_account", **wam_kwargs
    )

    # WAM failed — fallback to browser.
    # Not passing parent_window_handle → MSAL uses browser PKCE.
    if use_wam and result and "error" in result:
        if not quiet:
            console.print(
                f"  [dim]Native failed ({result.get('error', '')}), trying browser...[/dim]"
            )
        result = app.acquire_token_interactive(scopes=scopes, prompt="select_account")

    token = (result.get("access_token") or result.get("id_token")) if result else None
    if token and "error" not in (result or {}):
        _persist_cache(cache, cache_path)
        if not quiet:
            claims = result.get("id_token_claims", {})
            name = claims.get("name") or claims.get("preferred_username", "unknown")
            console.print(f"  [green]\u2713[/green] Authenticated as [bold]{name}[/bold]")
        return str(token)

    return None
