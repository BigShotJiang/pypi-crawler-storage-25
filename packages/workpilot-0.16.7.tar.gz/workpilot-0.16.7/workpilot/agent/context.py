"""
Context builder — assembles the system prompt from ~/.workpilot/ files,
skills, memory, and runtime metadata.

Build order:
  1. SOUL.md (identity, values, principles)
  2. Config instructions (from workpilot.yaml)
  3. USER.md (user identity + preferences)
  4. AGENTS.md (delegation, memory, safety rules)
  5. TOOLS.md (operational guidelines)
  6. Inactive tools summary + MCP servers
  7. Long-term memory (MEMORY.md, capped at 8KB)
  8. Skills (always-loaded full + available summary)
  9. Sub-agent discovery table
  10. Environment + Workspace (metadata, last)
"""

from __future__ import annotations

import platform
import re
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from workpilot.config.schema import AgentConfig, ChannelType, SkillsConfig
from workpilot.utils.defaults import load_default

if TYPE_CHECKING:
    from workpilot.skills.loader import Skill, SkillLoader

_SECTION_SEPARATOR = "\n\n---\n\n"

# Separator injected before the user's actual text when skills or history
# context is prepended.  Shared with compaction.py (_strip_injected_context).
USER_MSG_SEPARATOR = "---\n[User Message]"

MEMORY_CAP = 8192  # 8KB cap for MEMORY.md content

PromptMode = Literal["full", "minimal"]


def _sanitize_tool_ordering(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Ensure every tool message has a matching assistant tool_calls entry and vice-versa.

    OpenAI requires:
    - Every ``role=tool`` message must follow an ``assistant`` with a
      matching ``tool_calls[].id``.
    - Every ``tool_calls[].id`` in an ``assistant`` message must have a
      corresponding ``tool`` result.

    History loaded from a previous session may violate this (crash
    mid-tool-call, compaction, or manual editing).  This function:

    1. Drops orphaned ``tool`` messages (no matching assistant).
    2. For assistant messages with ``tool_calls``: strips individual
       tool_call entries that have no result.  If all are stripped,
       converts the message to a plain assistant text message.
    """
    # Pass 1: collect tool_call IDs that have actual tool results
    answered_tc_ids: set[str] = set()
    for msg in messages:
        if msg.get("role") == "tool":
            tc_id = msg.get("tool_call_id", "")
            if tc_id:
                answered_tc_ids.add(tc_id)

    # Pass 2: collect valid tool_call IDs (only those with results)
    valid_tc_ids: set[str] = set()

    result: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role")

        if role == "assistant" and msg.get("tool_calls"):
            # Filter tool_calls to only those that have results
            original_tcs = msg["tool_calls"]
            kept_tcs = [tc for tc in original_tcs if tc.get("id", "") in answered_tc_ids]

            if not kept_tcs:
                # No tool_calls have results — convert to plain text message
                content = msg.get("content") or ""
                if content:
                    result.append({"role": "assistant", "content": content})
                # else drop entirely (no content, no valid tool_calls)
                continue

            if len(kept_tcs) < len(original_tcs):
                # Some tool_calls missing results — keep only answered ones
                msg = {**msg, "tool_calls": kept_tcs}

            for tc in kept_tcs:
                valid_tc_ids.add(tc.get("id", ""))
            result.append(msg)

        elif role == "tool":
            tc_id = msg.get("tool_call_id", "")
            if tc_id in valid_tc_ids:
                result.append(msg)
            # else: orphaned tool message — drop it

        else:
            result.append(msg)

    return result


class ContextBuilder:
    """Builds the system prompt for an agent from config + workspace files + skills."""

    def __init__(
        self,
        agent_config: AgentConfig,
        workspace: Path,
        skills: list[Any] | None = None,
        available_agents: dict[str, AgentConfig] | None = None,
        tool_registry: Any | None = None,
        mcp_configs: dict[str, Any] | None = None,
        memory: Any | None = None,
        skill_loader: SkillLoader | None = None,
        skills_config: SkillsConfig | None = None,
    ) -> None:
        self._config = agent_config
        self._workspace = workspace
        # Support both old skills list and new skill_loader parameter
        self._skill_loader: SkillLoader | None = skill_loader
        self._skills_config = skills_config or SkillsConfig()
        self._available_agents = available_agents or {}
        self._tool_registry = tool_registry
        self._mcp_configs = mcp_configs or {}
        self._memory = memory  # AgentMemory
        # Backward compat: keep _skills for legacy callers
        self._skills = skills or []
        # Cache for skill requirement checks (startup-stable, avoids repeated shutil.which)
        self._req_cache: dict[str, list[str]] = {}
        self._cached_system_tokens: int | None = None

    def set_skills(self, skills: list[Any]) -> None:
        """Update the loaded skills (backward compat)."""
        self._skills = skills

    def build_system_prompt(self, mode: PromptMode = "full") -> str:
        """Assemble the system prompt following priority order.

        Args:
            mode: ``"full"`` for the main agent (all sections),
                  ``"minimal"`` for sub-agents (identity + config + TOOLS.md only).
        """
        parts: list[str] = []

        if mode == "minimal":
            # Minimal mode: runtime + config instructions + TOOLS.md
            parts.append(self._build_identity())
            if self._config.instructions:
                parts.append(self._config.instructions)

            tools_content = self._load_tools_md()
            if tools_content:
                parts.append(tools_content)

            return _SECTION_SEPARATOR.join(parts)

        # ── Full mode: all sections ──────────────────────────────────────

        # ── Identity ───────────────────────────────────────────────────
        # 1. SOUL.md — who I am, how I work, principles
        content = self._load_identity_or_builtin(self._config.soul_file, "SOUL.md")
        if content:
            parts.append(content)

        # 2. Base instructions from config
        if self._config.instructions:
            parts.append(self._config.instructions)

        # ── Rules & Tools ─────────────────────────────────────────────
        # 3. AGENTS.md — delegation, memory, safety rules
        content = self._load_identity_or_builtin(self._config.agents_file, "AGENTS.md")
        if content:
            parts.append(content)

        # 4. TOOLS.md — operational guidelines
        tools_content = self._load_tools_md()
        if tools_content:
            parts.append(tools_content)

        # 5. Standard tools summary (progressive loading)
        if self._tool_registry and hasattr(self._tool_registry, "get_standard_tools_summary"):
            standard_summary = self._tool_registry.get_standard_tools_summary()
            if standard_summary and isinstance(standard_summary, str):
                parts.append(standard_summary)

        # 6. MCP servers
        mcp_summary = self._build_mcp_summary()
        if mcp_summary:
            parts.append(mcp_summary)

        # 7. Skills section (always-loaded full content + model-visible summary)
        skills_section = self._build_skills_section()
        if skills_section:
            parts.append(skills_section)

        # 8. Available sub-agents
        agent_table = self._build_agent_discovery()
        if agent_table:
            parts.append(agent_table)

        # 9. Environment + Workspace
        parts.append(self._build_identity())

        # ── User & Memory ─────────────────────────────────────────────
        # 10. USER.md — learned user preferences
        user_path = self._resolve_identity_file(self._config.user_file, "USER.md")
        if user_path and user_path.is_file():
            content = user_path.read_text(encoding="utf-8").strip()
            if content:
                parts.append(content)

        # 11. Persistent memory (via AgentMemory, capped at 8KB)
        if self._memory:
            shared = self._memory.read_shared("MEMORY.md").strip()
            if shared:
                parts.append(f"## Shared Memory\n\n{shared[:MEMORY_CAP]}")
            mem = self._memory.read_memory().strip()
            if mem:
                parts.append(f"## Memory\n\n{mem[:MEMORY_CAP]}")

        return _SECTION_SEPARATOR.join(parts)

    def estimate_system_prompt_tokens(self, mode: PromptMode = "full") -> int:
        """Estimate the token cost of the system prompt (cached).

        Safe to cache: system prompt content (SOUL/USER/TOOLS/MEMORY.md) is
        stable within a process lifecycle.
        """
        if self._cached_system_tokens is None:
            from workpilot.agent.compaction import _MSG_OVERHEAD, count_tokens

            prompt = self.build_system_prompt(mode=mode)
            self._cached_system_tokens = count_tokens(prompt) + _MSG_OVERHEAD
        return self._cached_system_tokens

    def build_user_content(
        self,
        user_message: str,
        *,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        injected_skills: list[Skill] | None = None,
    ) -> str:
        """Build user message content with runtime context and injected skills.

        Used by both ``build_messages()`` (legacy) and the native items path.
        Runtime context is prepended to the user message (not the system prompt)
        to avoid cache-busting the system prompt on every turn.
        """
        parts: list[str] = []
        runtime_ctx = self._build_runtime_context(channel=channel, channel_id=channel_id)
        if runtime_ctx:
            parts.append(runtime_ctx)
        history_ctx = self._build_history_context(user_message)
        if history_ctx:
            parts.append(history_ctx)

        # Inject matched skills as context blocks (track actually-injected for audit)
        self._last_injected_skill_names: list[str] = []
        if injected_skills:
            from html import escape as _esc

            budget = self._skills_config.inject_budget
            used = 0
            for skill in injected_skills:
                safe_name = _esc(skill.name, quote=True)
                safe_path = _esc(skill.source_path, quote=True) if skill.source_path else ""
                tag = (
                    f'<context type="skill" name="{safe_name}"'
                    f"{f' path={chr(34)}{safe_path}{chr(34)}' if safe_path else ''}>"
                    f"\n{skill.content}\n"
                    f"</context>"
                )
                if used + len(tag) > budget:
                    break
                parts.append(tag)
                used += len(tag)
                self._last_injected_skill_names.append(skill.name)

        # Separator before user message when extra context is injected (beyond runtime ctx)
        if len(parts) > 1:
            parts.append(USER_MSG_SEPARATOR)
        parts.append(user_message)
        return "\n\n".join(parts)

    def build_messages(
        self,
        history: list[dict[str, Any]],
        user_message: str,
        *,
        mode: PromptMode = "full",
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        injected_skills: list[Skill] | None = None,
    ) -> list[dict[str, Any]]:
        """Build the full message list for the LLM call.

        Runtime context is prepended to the user message (not the system prompt)
        to avoid cache-busting the system prompt on every turn.

        Args:
            injected_skills: Skills auto-matched to the user message, prepended
                as ``<context type="skill">`` blocks.
        """
        messages: list[dict[str, Any]] = []

        # System prompt
        system_prompt = self.build_system_prompt(mode=mode)
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        # Conversation history — sanitize tool message ordering
        # Note: _ts is kept for compaction's time-gap heuristic; stripped by provider
        # Strip other _-prefixed keys (e.g. _injected_skills) that are internal metadata
        sanitized = _sanitize_tool_ordering(history)
        messages.extend(
            {k: v for k, v in msg.items() if k == "_ts" or not k.startswith("_")}
            for msg in sanitized
        )

        content = self.build_user_content(
            user_message,
            channel=channel,
            channel_id=channel_id,
            injected_skills=injected_skills,
        )
        messages.append({"role": "user", "content": content})

        return messages

    # ── Private builders ──────────────────────────────────────────────────

    def _build_identity(self) -> str:
        """Build environment and workspace info block."""

        plat = platform.system()
        arch = platform.machine()
        py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

        data_dir = Path.home() / ".workpilot"
        return (
            f"## Environment\n\n"
            f"{plat} {arch}, Python {py_ver}\n"
            f"Workspace: {self._workspace}\n"
            f"WorkPilot_Dir: {data_dir} (USER.md, MEMORY.md, sessions, logs, skills, cron)\n"
        )

    def _build_mcp_summary(self) -> str:
        """Build MCP servers summary for system prompt.

        Lists enabled MCP servers with name and description.
        Servers with ``enabled: auto`` that were skipped (no cached token)
        are excluded — they are not usable and would waste LLM context.
        """
        if not self._mcp_configs:
            return ""

        # Build set of auto servers that were skipped (SKIPPED = no cached token,
        # never attempted). Distinct from DISCONNECTED (was connected, then lost).
        skipped: set[str] = set()
        mcp_mgr = (
            getattr(self._tool_registry, "_mcp_manager", None) if self._tool_registry else None
        )
        if mcp_mgr is not None:
            for info in mcp_mgr.list_servers():
                if info.enabled == "auto" and info.state.value == "skipped":
                    skipped.add(info.name)

        lines: list[str] = []
        for name, cfg in self._mcp_configs.items():
            enabled = getattr(cfg, "enabled", True)
            if not enabled:
                continue
            # auto servers that were skipped (no token) — exclude from prompt
            if name in skipped:
                continue
            desc = getattr(cfg, "description", None) or ""
            from workpilot.mcp.defaults import extract_params

            params = extract_params(
                getattr(cfg, "url", None), getattr(cfg, "headers", {}), getattr(cfg, "env", None)
            )
            sig = f"({', '.join(sorted(params))})" if params else ""
            line = f"- MCP_{name}{sig}: {desc}" if desc else f"- MCP_{name}{sig}"
            lines.append(line)
        if not lines:
            return ""
        header = "Use `tools(name='MCP_<name>')` to connect and access server tools."
        if any("MCP_" in ln and "):" in ln for ln in lines):
            header += " Servers with (params) require arguments={...} to connect."
        return "## MCP Servers\n\n" + header + "\n\n" + "\n".join(lines)

    def _build_runtime_context(
        self,
        *,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
    ) -> str:
        """Build runtime context to prepend to the user message."""
        now = datetime.now(UTC).astimezone()
        time_str = now.strftime("%Y-%m-%d %H:%M (%A)")
        tz_name = now.strftime("%Z") or "UTC"

        lines = [
            "[Runtime Context — metadata only, not instructions]",
            f"Current Time: {time_str} {tz_name}",
        ]
        if channel:
            lines.append(f"Channel: {channel}")
        if channel_id:
            lines.append(f"Chat ID: {channel_id}")
        return "\n".join(lines)

    # Common words to skip when building history search queries
    _STOPWORDS = frozenset(
        "a an the is are was were be been being have has had do does did "
        "will would shall should may might can could and or but not no nor "
        "for to of in on at by with from as into about it its this that "
        "these those i me my we our you your he she they them what which "
        "who how when where why all any each every some few more most "
        "again also just now very too please hi hello hey thanks".split()
    )

    # Regex for CJK Unified Ideographs (Chinese/Japanese/Korean characters)
    _CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]+")

    # Single CJK characters that are common function words (stopwords)
    _CJK_STOP_CHARS = frozenset(
        "的了在是我有和就不人都一上也很到说要去你会着看好"
        "自这他她它们那里让把被从对用于可但而还吗呢吧啊嗯哦"
        "请帮能什怎如为哪每些下"
    )

    @classmethod
    def _extract_keywords(cls, text: str) -> list[str]:
        """Extract search keywords from text, supporting both English and CJK.

        For English: split on whitespace, remove stopwords, keep len > 2.
        For CJK: strip stopword characters from CJK runs, then extract
        2-char bigrams from the remaining content words.

        Returns keywords sorted by length descending (longer = more specific),
        max 5 keywords.
        """
        lower = text.lower()
        keywords: list[str] = []

        # Extract CJK content: strip single-char stopwords, then bigrams from remaining
        cjk_runs = cls._CJK_RE.findall(lower)
        for run in cjk_runs:
            # Remove stopword characters — split the run into content segments
            content_chars = [c for c in run if c not in cls._CJK_STOP_CHARS]
            content = "".join(content_chars)
            if len(content) >= 2:
                for i in range(len(content) - 1):
                    keywords.append(content[i : i + 2])
            elif content:
                keywords.append(content)

        # Extract English words
        ascii_text = cls._CJK_RE.sub(" ", lower)
        for w in ascii_text.split():
            if w not in cls._STOPWORDS and len(w) > 2:
                keywords.append(w)

        # Deduplicate preserving order, sort by length desc
        seen: set[str] = set()
        unique: list[str] = []
        for kw in keywords:
            if kw not in seen:
                seen.add(kw)
                unique.append(kw)

        unique.sort(key=len, reverse=True)
        return unique[:5]

    def _build_history_context(self, user_message: str) -> str:
        """Search HistoryStore for high-relevance related history.

        Precision strategy (conservative — silence > noise):
        1. Skip slash commands and short messages (<8 CJK / <15 Latin chars)
        2. Extract keywords; require ≥2 CJK bigrams OR ≥3 Latin words
        3. Try NEAR query (words within 50 tokens) → high precision
        4. Fall back to AND (all words present anywhere) → medium precision
        5. Post-filter: ≥60% keyword overlap in content
        6. No results → inject nothing

        Fetches 10 candidates to allow temporal decay + MMR dedup to work
        well before selecting the final top 3.
        """
        if not self._memory or not user_message:
            return ""
        if user_message.startswith("/"):
            return ""
        # CJK text is denser — 8 chars ≈ a full sentence; Latin needs more
        has_cjk = bool(self._CJK_RE.search(user_message))
        min_len = 8 if has_cjk else 15
        if len(user_message) < min_len:
            return ""

        top_words = self._extract_keywords(user_message)

        # Fetch 10 candidates (not 3) — decay + MMR dedup then selects top 3
        fetch_k = 10

        # Separate CJK and non-CJK keywords for different search strategies
        # FTS5 porter unicode61 does NOT tokenize CJK — use SQL LIKE fallback
        cjk_words = [w for w in top_words if self._CJK_RE.match(w)]
        latin_words = [w for w in top_words if not self._CJK_RE.match(w)]

        # Require sufficient keywords per language bucket to avoid
        # false matches from mixed-language messages (e.g. a single CJK
        # char in an otherwise Latin message shouldn't relax the threshold)
        if len(cjk_words) < 2 and len(latin_words) < 3:
            return ""

        results = None
        if latin_words:
            # FTS5 search for Latin/English terms
            fts_terms = [f'"{w.replace(chr(34), "")}"' for w in latin_words]
            near_terms = " ".join(fts_terms)
            for query in [
                f"fts5:NEAR({near_terms}, 50)",  # co-occurrence
                "fts5:" + " AND ".join(fts_terms),  # all present
            ]:
                try:
                    results = self._memory.history.search(query, top_k=fetch_k)
                except Exception:
                    results = None
                if results:
                    break

        if not results and cjk_words:
            # Fallback: SQL LIKE search for CJK terms (FTS5 can't tokenize CJK)
            results = self._search_cjk_like(cjk_words, fetch_k)

        if not results:
            return ""

        # Apply temporal decay: re-score by recency (30-day half-life)
        from workpilot.agent.memory import apply_temporal_decay

        results = apply_temporal_decay(results)

        # Post-filter: content must share ≥60% of query keywords
        candidates = []
        for r in results:
            content_lower = r.get("content", "").lower()
            matched = sum(1 for w in top_words if w in content_lower)
            if matched >= len(top_words) * 0.6:
                candidates.append(r)

        if not candidates:
            return ""

        # MMR dedup: skip candidates too similar to already-selected results
        selected: list[str] = []
        for r in candidates:
            preview = r.get("content", "")[:200].replace("\n", " ")
            kw_cand = set(preview.lower().split())
            is_dup = False
            for sel in selected:
                kw_sel = set(sel.lower().split())
                union = kw_cand | kw_sel
                if union:
                    jaccard = len(kw_cand & kw_sel) / len(union)
                    if jaccard > 0.6:
                        is_dup = True
                        break
            if not is_dup:
                selected.append(preview)
            if len(selected) >= 3:
                break

        if not selected:
            return ""
        return "[Related History]\n" + "\n".join(selected)

    def _search_cjk_like(self, cjk_words: list[str], top_k: int) -> list[dict[str, Any]]:
        """Fallback search for CJK terms via HistoryStore.search_like()."""
        if not self._memory or not cjk_words:
            return []
        results: list[dict[str, Any]] = self._memory.history.search_like(cjk_words, top_k)
        return results

    def _load_tools_md(self) -> str:
        """Load TOOLS.md from ~/.workpilot or bundled default.

        Contains operational guidelines and tool usage tips.
        Users can override by creating ~/.workpilot/TOOLS.md.
        """
        content = load_default("TOOLS.md", allow_empty_override=True)
        if not content:
            return ""
        if content.startswith("#"):
            return content
        return f"## Guidelines\n\n{content}"

    def _build_skills_section(self) -> str:
        """Build combined skills section: always-loaded full content + model-visible summary.

        Uses the ``SkillLoader`` if available, otherwise falls back to the
        legacy ``_skills`` list for backward compatibility.
        """
        parts: list[str] = []
        always_budget = self._skills_config.always_budget
        summary_budget = self._skills_config.summary_budget

        # ── Always-loaded skills (full content) ──────────────────────────
        if self._skill_loader:
            always_skills = self._skill_loader.get_always_loaded()
        else:
            always_skills = [
                s
                for s in self._skills
                if hasattr(s, "mode") and s.mode == "always" and hasattr(s, "content")
            ]

        used = 0
        for skill in always_skills:
            content = getattr(skill, "content", "")
            block = f"## Skill: {skill.name}\n\n{content}"
            if used + len(block) > always_budget:
                break
            parts.append(block)
            used += len(block)

        # ── Model-visible skills summary ─────────────────────────────────
        if self._skill_loader:
            available = self._skill_loader.get_model_visible()
        else:
            available = [
                s
                for s in self._skills
                if hasattr(s, "mode") and s.mode == "available" and hasattr(s, "name")
            ]

        if available:
            lines = [
                "## Available Skills",
                "",
                "Use `tools(name='<skill>', action='skill')` to load a skill's full instructions.",
                "",
            ]
            line_budget = summary_budget
            for skill in available:
                # Only show skills whose requirements are met.
                # Cache result per skill name — requirements are startup-stable.
                # Note: supersession and platform checks are already handled by
                # get_model_visible() in the SkillLoader path.
                if hasattr(skill, "check_requirements"):
                    cache_key = skill.name
                    if cache_key not in self._req_cache:
                        self._req_cache[cache_key] = skill.check_requirements(self._tool_registry)
                    if self._req_cache[cache_key]:
                        continue  # ineligible
                desc = getattr(skill, "description", "") or ""
                line = f"- {skill.name}: {desc}"
                if line_budget - len(line) < 0:
                    break
                lines.append(line)
                line_budget -= len(line)
            parts.append("\n".join(lines))

        return _SECTION_SEPARATOR.join(parts) if parts else ""

    def _build_skills_summary(self) -> str:
        """Legacy: build skills summary. Delegates to :meth:`_build_skills_section`."""
        return self._build_skills_section()

    def _build_agent_discovery(self) -> str:
        """Build the Available Sub-Agents table for the default agent's context."""
        if not self._available_agents:
            return ""

        lines = [
            "## Available Sub-Agents",
            "",
            "You can delegate tasks using the `spawn` tool.",
            "",
            "| Agent | Description | Model | Tools | Budget |",
            "|-------|------------|-------|-------|--------|",
        ]
        for name, cfg in self._available_agents.items():
            # Skip internal agents (security) and self (default)
            if cfg.metadata.get("internal") or name == "default":
                continue
            if cfg.tools is None:
                tools_str = "(all)"
            else:
                tools_str = ", ".join(cfg.tools[:4])
                if len(cfg.tools) > 4:
                    tools_str += f" (+{len(cfg.tools) - 4})"
            lines.append(
                f"| {name} | {cfg.description} | {cfg.model} "
                f"| {tools_str} | {cfg.max_iterations} iter |"
            )

        # Only return if there are non-internal, non-default agents
        if len(lines) <= 6:  # just header, no rows
            return ""
        return "\n".join(lines)

    def _resolve_identity_file(self, config_path: str | None, default_name: str) -> Path | None:
        """Resolve an identity file path from config or ~/.workpilot default."""
        if config_path:
            p = Path(config_path).expanduser()
            if p.is_absolute():
                return p
            return self._workspace / p
        candidate = Path.home() / ".workpilot" / default_name
        if candidate.is_file():
            return candidate
        return None

    def _load_identity_or_builtin(self, config_path: str | None, default_name: str) -> str:
        """Load a configured/home-scoped identity file, else bundled template.

        Priority: explicit config path → ~/.workpilot/{name} → bundled default.
        """
        path = self._resolve_identity_file(config_path, default_name)
        if path and path.is_file():
            return path.read_text(encoding="utf-8").strip()
        return load_default(default_name)
