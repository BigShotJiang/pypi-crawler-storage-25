"""
InterruptController — per-session cooperative interrupt signaling.

Channels set the interrupt event; the agent loop checks it at cooperative
checkpoints (before LLM calls, before tool execution, during streaming).
Uses one asyncio.Event per session for non-blocking signaling within the
event loop.
"""

from __future__ import annotations

import asyncio

from loguru import logger


class InterruptController:
    """Per-session interrupt state management.

    Lifecycle:
      1. _process_message() calls get_or_create(session_id) at start
      2. Channels call signal(session_id) to request interrupt
      3. Agent loop calls check(session_id) at cooperative checkpoints
      4. _process_message() calls clear() + remove() in finally block
    """

    def __init__(self) -> None:
        self._events: dict[str, asyncio.Event] = {}

    def get_or_create(self, session_id: str) -> asyncio.Event:
        """Register a session for interrupt tracking. Returns the event."""
        if session_id not in self._events:
            self._events[session_id] = asyncio.Event()
        return self._events[session_id]

    def signal(self, session_id: str) -> bool:
        """Signal interrupt for a session.

        Returns True if the session was active (event existed and was set).
        Returns False if no active processing for this session.
        """
        event = self._events.get(session_id)
        if event is None:
            return False
        event.set()
        logger.info("Interrupt signaled for session {}", session_id)
        return True

    def check(self, session_id: str) -> bool:
        """Non-blocking check whether interrupt is pending."""
        event = self._events.get(session_id)
        return event is not None and event.is_set()

    def clear(self, session_id: str) -> None:
        """Reset the interrupt event (ready for next turn)."""
        event = self._events.get(session_id)
        if event:
            event.clear()

    def remove(self, session_id: str) -> None:
        """Unregister a session (cleanup after turn completes)."""
        self._events.pop(session_id, None)
