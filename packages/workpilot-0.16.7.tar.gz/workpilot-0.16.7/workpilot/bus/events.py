"""
Message bus event types — decoupled communication between channels and agent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from workpilot.config.schema import ChannelType

# ── Message types ────────────────────────────────────────────────────────────


@dataclass
class InboundMessage:
    """Message received from a channel, headed to the agent."""

    channel: ChannelType | str
    channel_id: str
    sender_id: str
    content: str
    content_format: str = "text"
    sender_name: str = ""
    thread_id: str | None = None
    session_id: str | None = None
    session_key: str | None = None
    attachments: list[Any] | None = None
    timestamp: str | None = None  # ISO format
    metadata: dict[str, Any] = field(default_factory=dict)
    # metadata may contain: source, tenant_id, injection, interrupt


@dataclass
class OutboundMessage:
    """Message from the agent, headed to a channel."""

    channel: ChannelType
    channel_id: str
    content: str
    thread_id: str | None = None
    reply_to: str | None = None
    attachments: list[Any] | None = None
    format: str = "markdown"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class StreamingChunk:
    """Incremental content fragment during streaming responses."""

    channel: ChannelType
    channel_id: str
    content: str
    chunk_type: str = "token"  # "token" | "tool_progress" | "status"
    done: bool = False


# ── Typed events for cross-subsystem coordination ───────────────────────────


class EventType(str, Enum):
    """Typed events emitted via EventBus for cross-subsystem coordination."""

    # Message lifecycle
    MESSAGE_RECEIVED = "message.received"
    MESSAGE_SENT = "message.sent"
    # Tool execution
    TOOL_EXECUTED = "tool.executed"
    TOOL_FAILED = "tool.failed"
    TOOL_APPROVED = "tool.approved"
    TOOL_DENIED = "tool.denied"
    # Approval workflow
    APPROVAL_REQUESTED = "approval.requested"
    APPROVAL_RESOLVED = "approval.resolved"
    # Security
    SECURITY_ALERT = "security.alert"
    SECURITY_ESTOP = "security.estop"
    SECURITY_LEAK = "security.leak"
    # Cost
    COST_WARNING = "cost.warning"
    # Health
    HEALTH_DEGRADED = "health.degraded"
    HEALTH_RECOVERED = "health.recovered"
    # Agent
    AGENT_ITERATION = "agent.iteration"
    AGENT_INTERRUPTED = "agent.interrupted"
    # Memory
    MEMORY_CONSOLIDATED = "memory.consolidated"
    # Session
    SESSION_CREATED = "session.created"
    # Channel lifecycle
    CHANNEL_CONNECTED = "channel.connected"
    # Typing indicators
    TYPING_STARTED = "typing.started"
    TYPING_STOPPED = "typing.stopped"
