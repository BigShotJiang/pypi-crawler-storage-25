"""
OpenAI-compatible unified provider.

Supports GitHub Copilot, OpenAI direct, and Azure OpenAI.

Routing (GitHub Copilot scope: gpt-5*, claude-*, gemini-*):
- gpt-5*                        → Responses API (fallback to Chat)
- gpt-5.4* on Copilot / codex / *-pro → Responses API only (no fallback)
- claude-*, gemini-*, others     → Chat Completions (fallback to Responses)

Design follows nanobot (HKUDS/nanobot) provider patterns:
- choices[0]-first content merge; tool_calls merged across all choices
- max_completion_tokens for gpt-5.x / o-series (not max_tokens)
- temperature suppressed for reasoning models (gpt-5.x, o-series, reasoning_effort)
- empty-content sanitization (None for assistant+tools, "(empty)" otherwise)
- reasoning_effort forwarded as {"effort": ...} on Responses API
- reasoning_content extracted from Responses API output items
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from loguru import logger

from workpilot.config.schema import ProvidersConfig
from workpilot.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest
from workpilot.providers.resolver import resolve_credentials, resolve_model_chain
from workpilot.providers.usage import TokenUsageTracker

# ── Routing ────────────────────────────────────────────────────────────────────

# GitHub Copilot-specific: gpt-5.4 family rejects /chat/completions entirely.
_GITHUB_COPILOT_RESPONSES_ONLY: tuple[str, ...] = ("gpt-5.4",)


def _api_model_name(resolved_model: str) -> str:
    for prefix in ("github_copilot/", "github/", "openai/", "azure/", "azure_ai/"):
        if resolved_model.startswith(prefix):
            return resolved_model.removeprefix(prefix)
    return resolved_model


def _requires_responses_api(model_name: str) -> bool:
    """True for models that ONLY work with /v1/responses (no Chat fallback).

    Applies to all *-codex variants and gpt-5.x-pro variants.
    """
    n = model_name.lower()
    return "codex" in n or (n.startswith("gpt-5") and n.endswith("-pro"))


def _must_use_responses_api(resolved_model: str) -> bool:
    """True when Chat Completions fallback is NOT allowed."""
    name = _api_model_name(resolved_model).lower()
    if _requires_responses_api(name):
        return True
    # gpt-5.4 family on Copilot endpoint rejects /chat/completions
    if resolved_model.startswith(("github/", "github_copilot/")) and name.startswith(
        _GITHUB_COPILOT_RESPONSES_ONLY
    ):
        return True
    return False


def _should_prefer_responses_api(resolved_model: str) -> bool:
    """True for gpt-5* models — prefer Responses API.

    claude-*, gemini-*, and others stay on Chat Completions
    with automatic fallback to Responses API on ``unsupported_api_for_model``.
    """
    if _must_use_responses_api(resolved_model):
        return True
    name = _api_model_name(resolved_model).lower()
    return name.startswith("gpt-5")


def _supports_server_compaction(resolved_model: str) -> bool:
    """True for models that support server-side compaction via context_management.

    Verified on GitHub Copilot (2026-04-06): gpt-5.4 family and gpt-5.3+ codex.
    """
    import re

    name = _api_model_name(resolved_model).lower()
    if name.startswith("gpt-5.4"):
        return True
    if "codex" in name:
        # Parse numeric minor version: gpt-5.3-codex → 3, gpt-5.10-codex → 10
        m = re.search(r"gpt-5\.(\d+)", name)
        if m and int(m.group(1)) >= 3:
            return True
    return False


def _is_chat_unsupported_error(exc: Exception) -> bool:
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        error = body.get("error", {})
        code = str(error.get("code", "")).lower()
        message = str(error.get("message", "")).lower()
        if code == "unsupported_api_for_model":
            return True
        if "/chat/completions" in message:
            return True
    text = str(exc).lower()
    return "unsupported_api_for_model" in text or "/chat/completions endpoint" in text


# ── Parameter helpers (nanobot patterns) ──────────────────────────────────────

# Model families that require max_completion_tokens instead of max_tokens.
_COMPLETION_TOKENS_FAMILIES: tuple[str, ...] = ("gpt-5", "o1", "o2", "o3", "o4")


def _uses_completion_tokens(model_name: str) -> bool:
    n = model_name.lower()
    return any(n.startswith(f) for f in _COMPLETION_TOKENS_FAMILIES)


def _supports_temperature(model_name: str, reasoning_effort: str | None) -> bool:
    """False for reasoning models — temperature is ignored or rejected."""
    if reasoning_effort and reasoning_effort != "none":
        return False
    n = model_name.lower()
    return not any(n.startswith(f) for f in ("gpt-5", "o1", "o2", "o3", "o4"))


# ── Message sanitization ───────────────────────────────────────────────────────


def _sanitize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize messages for OpenAI-compatible APIs.

    - Strip internal metadata keys (``_``-prefixed and ``is_error``)
    - Empty string content: None for assistant+tool_calls, "(empty)" otherwise
      (avoids 400 errors from providers that reject empty content)
    - tool_call arguments: dict → JSON string
    """
    out = []
    for msg in messages:
        msg = {k: v for k, v in msg.items() if not k.startswith("_") and k != "is_error"}
        role = msg.get("role")
        content = msg.get("content")

        if isinstance(content, str) and not content:
            msg["content"] = None if (role == "assistant" and msg.get("tool_calls")) else "(empty)"

        if msg.get("tool_calls"):
            fixed = []
            for tc in msg["tool_calls"]:
                tc = dict(tc)
                if "function" in tc:
                    fn = dict(tc["function"])
                    if isinstance(fn.get("arguments"), dict):
                        fn["arguments"] = json.dumps(fn["arguments"])
                    tc["function"] = fn
                fixed.append(tc)
            msg["tool_calls"] = fixed

        out.append(msg)
    return out


# ── Responses API helpers ──────────────────────────────────────────────────────


def _responses_input(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert chat-style messages to Responses API input items.

    - tool messages → function_call_output (preserves call_id for multi-turn)
    - assistant + tool_calls → function_call items (fixes "no tool call found" errors)
    """
    items: list[dict[str, Any]] = []
    for msg in _sanitize_messages(messages):
        role = msg.get("role", "user")
        content = msg.get("content") or ""
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False)

        if role == "tool":
            items.append(
                {
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": content,
                }
            )
            continue

        if role not in {"system", "user", "assistant"}:
            role = "user"

        if role == "assistant" and msg.get("tool_calls"):
            # Emit text content first (reasoning preamble from gpt-5.4 etc.),
            # then function_call items — Responses API supports this ordering.
            if content:
                items.append({"role": "assistant", "content": content})
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                args = fn.get("arguments", "{}")
                items.append(
                    {
                        "type": "function_call",
                        "call_id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "arguments": args if isinstance(args, str) else json.dumps(args),
                    }
                )
            continue

        items.append({"role": role, "content": content})

    return items


def _responses_tools(tools: list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
    if not tools:
        return None
    converted = []
    for tool in tools:
        if tool.get("type") != "function":
            continue
        fn = tool.get("function", {})
        converted.append(
            {
                "type": "function",
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {"type": "object", "properties": {}}),
            }
        )
    return converted


def _serialize_output(output_items: Any) -> list[dict[str, Any]]:
    """Convert SDK response output items to dicts safe for storage and re-send.

    Compaction items are stripped to ``{type, id, encrypted_content}`` only —
    other fields (e.g. ``created_by``) cause 400 errors when sent back.
    """
    result: list[dict[str, Any]] = []
    for item in output_items or []:
        if hasattr(item, "model_dump"):
            d = item.model_dump(exclude_none=True)
        elif isinstance(item, dict):
            d = dict(item)
        else:
            d = vars(item) if hasattr(item, "__dict__") else {"_raw": str(item)}
        if d.get("type") == "compaction":
            d = {k: d[k] for k in ("type", "id", "encrypted_content") if k in d}
        # Strip output-only fields from message content parts that cause
        # 400 errors when sent back as input (logprobs is output-only).
        if d.get("type") == "message" and isinstance(d.get("content"), list):
            d["content"] = [
                {k: v for k, v in part.items() if k != "logprobs"}
                if isinstance(part, dict)
                else part
                for part in d["content"]
            ]
        result.append(d)
    return result


_VALID_INPUT_ROLES = frozenset({"user", "assistant", "system", "developer"})
_VALID_INPUT_TYPES = frozenset(
    {"function_call", "function_call_output", "message", "reasoning", "compaction"}
)


def _prepare_items_for_api(
    items: list[dict[str, Any]],
    resolved_model: str = "",
) -> list[dict[str, Any]]:
    """Single-pass sanitization of items before any API call.

    Performs ALL cleaning in one place:
    1. Drop non-API items (``approval_request``, unknown types/roles)
    2. Strip internal metadata keys (``_ts``, ``is_error``, etc.)
    3. Normalize Chat-format items to Responses API native format
    4. Filter compaction items for models that don't support them
    5. Remove orphan ``function_call`` items (no matching ``function_call_output``)
    """
    # ── Pass 1: filter + strip + normalize ────────────────────────────────
    cleaned: list[dict[str, Any]] = []
    for item in items:
        role = item.get("role", "")
        item_type = item.get("type", "")

        # 1. Strip metadata keys + output-only fields from content parts.
        # is_error is stripped (not an API field) but the item is KEPT —
        # error context helps the LLM avoid retrying failed tools.
        d = {k: v for k, v in item.items() if not k.startswith("_") and k != "is_error"}
        if isinstance(d.get("content"), list):
            d["content"] = [
                {k: v for k, v in part.items() if k != "logprobs"}
                if isinstance(part, dict)
                else part
                for part in d["content"]
            ]

        # 2. Skip empty items (all keys were _-prefixed metadata)
        if not d:
            continue

        # 3. Normalize Chat items to native format (before role validation,
        #    since role:"tool" is not a valid Responses API role but needs conversion)
        if not item_type and (role == "tool" or d.get("tool_calls")):
            cleaned.extend(_responses_input([d]))
            continue

        # 4. Drop non-API items (approval_request, etc.)
        if role and role not in _VALID_INPUT_ROLES and not item_type:
            continue
        if item_type and item_type not in _VALID_INPUT_TYPES:
            continue

        # 5. Filter compaction for unsupported models
        if (
            item_type == "compaction"
            and resolved_model
            and not _supports_server_compaction(resolved_model)
        ):
            continue

        cleaned.append(d)

    # ── Pass 2: remove orphan function_calls ──────────────────────────────
    fc_ids = {i.get("call_id") for i in cleaned if i.get("type") == "function_call"}
    fco_ids = {i.get("call_id") for i in cleaned if i.get("type") == "function_call_output"}
    result: list[dict[str, Any]] = []
    for item in cleaned:
        if item.get("type") == "function_call" and (
            not item.get("call_id") or item.get("call_id") not in fco_ids
        ):
            continue  # orphan function_call — no matching output
        if item.get("type") == "function_call_output" and (
            not item.get("call_id") or item.get("call_id") not in fc_ids
        ):
            continue  # orphan function_call_output — no matching call
        result.append(item)

    # ── Pass 3: keep only the latest reasoning items ─────────────────────
    # Accumulated encrypted_content from multiple reasoning items causes 400
    # on the Copilot proxy. On restart, JSONL may contain many reasoning items
    # from prior turns. Keep only the last reasoning item (matches the in-loop
    # behavior of removing old reasoning before extending with new output).
    reasoning_indices = [i for i, item in enumerate(result) if item.get("type") == "reasoning"]
    if len(reasoning_indices) > 1:
        drop = set(reasoning_indices[:-1])
        result = [item for i, item in enumerate(result) if i not in drop]

    return result


def items_to_chat_messages(
    items: list[dict[str, Any]],
    instructions: str | None = None,
) -> list[dict[str, Any]]:
    """Convert Responses API native items to Chat Completions messages.

    Handles both native items (``type`` field) and legacy Chat items (``role`` field).
    Consecutive ``function_call`` items are batched into one assistant message.
    Preceding assistant commentary is merged into the tool_calls message.
    ``reasoning`` and ``compaction`` items are skipped (not representable).

    Orphan ``function_call`` / ``function_call_output`` items (no matching
    counterpart) are dropped — mirrors the Pass 2 logic in
    ``_prepare_items_for_api`` so the Chat Completions path never produces
    assistant ``tool_calls`` without corresponding ``tool`` messages.
    """
    # ── Pre-filter: drop orphan function_call / function_call_output ──
    # Collect paired call_ids first, then filter.  Empty/None ids are
    # excluded so they never accidentally "pair" with each other.
    _fc_ids: set[str] = set()
    _fco_ids: set[str] = set()
    for i in items:
        if i.get("type") == "function_call" and i.get("call_id"):
            _fc_ids.add(i["call_id"])
        elif i.get("type") == "function_call_output" and i.get("call_id"):
            _fco_ids.add(i["call_id"])
        # Also collect from Chat-format: assistant tool_calls ↔ role:"tool"
        if i.get("role") == "assistant" and i.get("tool_calls"):
            for tc in i["tool_calls"]:
                if tc.get("id"):
                    _fc_ids.add(tc["id"])
        if i.get("role") == "tool" and i.get("tool_call_id"):
            _fco_ids.add(i["tool_call_id"])
    _paired_ids = _fc_ids & _fco_ids

    filtered_items: list[dict[str, Any]] = []
    for i in items:
        if i.get("type") == "function_call":
            if not i.get("call_id") or i.get("call_id") not in _paired_ids:
                continue
        elif i.get("type") == "function_call_output":
            if not i.get("call_id") or i.get("call_id") not in _paired_ids:
                continue
        elif i.get("role") == "assistant" and i.get("tool_calls"):
            # Drop unpaired tool_calls from Chat-format assistant messages
            paired_tcs = [tc for tc in i["tool_calls"] if tc.get("id") in _paired_ids]
            if not paired_tcs:
                # All tool_calls orphaned — preserve assistant message
                # only if it has meaningful text (string or content parts)
                content = i.get("content")
                has_text = (isinstance(content, str) and content.strip()) or (
                    isinstance(content, list) and len(content) > 0
                )
                if has_text:
                    filtered_items.append({k: v for k, v in i.items() if k != "tool_calls"})
                continue
            if len(paired_tcs) < len(i["tool_calls"]):
                i = {**i, "tool_calls": paired_tcs}
        elif i.get("role") == "tool":
            if not i.get("tool_call_id") or i.get("tool_call_id") not in _paired_ids:
                continue
        filtered_items.append(i)

    messages: list[dict[str, Any]] = []
    if instructions:
        messages.append({"role": "system", "content": instructions})

    pending_tool_calls: list[dict[str, Any]] = []
    pending_content: str | None = None

    def _extract_text(item: dict[str, Any]) -> str:
        content = item.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for part in content:
                if isinstance(part, dict):
                    text = part.get("text", "") or part.get("refusal", "")
                    if text:
                        parts.append(text)
            return "".join(parts)
        return str(content) if content else ""

    def _flush() -> None:
        nonlocal pending_content
        if pending_tool_calls:
            msg: dict[str, Any] = {
                "role": "assistant",
                "content": pending_content or "",
                "tool_calls": [
                    {
                        "id": fc.get("call_id", fc.get("id", "")),
                        "type": "function",
                        "function": {
                            "name": fc.get("name", ""),
                            "arguments": fc.get("arguments", "{}"),
                        },
                    }
                    for fc in pending_tool_calls
                ],
            }
            messages.append(msg)
            pending_tool_calls.clear()
            pending_content = None
        elif pending_content is not None:
            messages.append({"role": "assistant", "content": pending_content})
            pending_content = None

    for item in filtered_items:
        t = item.get("type", "")
        role = item.get("role", "")

        # Skip non-API items (approval_request, etc.)
        if role and role not in _VALID_INPUT_ROLES and role != "tool" and not t:
            continue

        # Legacy Chat format items (no "type" field, have "role" + possibly "tool_calls")
        if not t and role:
            _flush()
            if role == "tool":
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": item.get("tool_call_id", ""),
                        "content": item.get("content", ""),
                    }
                )
            elif role == "assistant" and item.get("tool_calls"):
                messages.append(item)
            else:
                messages.append({"role": role, "content": item.get("content", "")})
            continue

        # Native Responses API items
        if role in ("user", "system", "developer"):
            _flush()
            messages.append({"role": role, "content": _extract_text(item)})

        elif t == "function_call":
            pending_tool_calls.append(item)

        elif t == "function_call_output":
            _flush()
            output = item.get("output", "")
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": item.get("call_id", ""),
                    "content": output
                    if isinstance(output, str)
                    else json.dumps(output, ensure_ascii=False),
                }
            )

        elif t == "message" and role == "assistant":
            _flush()  # flush any pending tool_calls or prior assistant content
            pending_content = _extract_text(item)

        # reasoning, compaction → skip

    _flush()
    return messages


def chat_response_to_items(response: Any) -> list[dict[str, Any]]:
    """Convert a Chat Completions response to Responses API native items."""
    if not response.choices:
        return []
    msg = response.choices[0].message
    result: list[dict[str, Any]] = []
    if msg.content:
        result.append({"role": "assistant", "content": msg.content})
    if getattr(msg, "tool_calls", None):
        for tc in msg.tool_calls:
            result.append(
                {
                    "type": "function_call",
                    "call_id": tc.id,
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                }
            )
    return result


# ── Provider ───────────────────────────────────────────────────────────────────


class OpenAIProvider(LLMProvider):
    """Unified provider for GitHub Copilot, OpenAI, and Azure OpenAI.

    Routing (scope: gpt-5*, claude-*, gemini-*):
    - gpt-5*                         → Responses API (fallback to Chat)
    - gpt-5.4* on Copilot / codex / *-pro → Responses API only (no fallback)
    - claude-*, gemini-*, others      → Chat Completions (fallback to Responses)
    """

    def __init__(self, providers: ProvidersConfig | None = None) -> None:
        self._providers = providers or ProvidersConfig()
        self._usage: TokenUsageTracker | None = None
        self._client_cache: dict[tuple[str, str | None, str | None, Any], Any] = {}

    def set_usage_tracker(self, tracker: TokenUsageTracker) -> None:
        """Attach a token usage tracker for cost monitoring."""
        self._usage = tracker

    # ── Request building ───────────────────────────────────────────────────────

    def _build_kwargs(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, Any], dict[str, Any]]:
        """Return (resolved_model, req_kwargs, creds)."""
        resolved_model = model
        creds = resolve_credentials(resolved_model, self._providers)
        model_name = _api_model_name(resolved_model)

        req_kwargs: dict[str, Any] = {
            "model": model_name,
            "messages": _sanitize_messages(messages),
        }

        # Temperature: suppressed for reasoning models (nanobot pattern)
        if temperature is not None and _supports_temperature(model_name, reasoning_effort):
            req_kwargs["temperature"] = temperature

        # max_tokens → max_completion_tokens for gpt-5.x / o-series
        if max_tokens is not None:
            param = "max_completion_tokens" if _uses_completion_tokens(model_name) else "max_tokens"
            req_kwargs[param] = max_tokens

        if tools:
            req_kwargs["tools"] = tools

        # reasoning_effort for chat/completions (gpt-5.x, o-series)
        if reasoning_effort and reasoning_effort != "none":
            req_kwargs["reasoning_effort"] = reasoning_effort

        return resolved_model, req_kwargs, creds

    def _build_client(self, resolved_model: str, creds: dict[str, Any]) -> Any:
        from openai import AsyncAzureOpenAI, AsyncOpenAI

        api_key = creds.get("api_key")
        if not api_key:
            raise ValueError(f"Missing API key for model '{resolved_model}'")

        api_base: str | None = creds.get("api_base")
        api_version: str | None = creds.get("api_version")
        extra_headers = creds.get("extra_headers")
        headers_key = (
            tuple(sorted(extra_headers.items()))
            if isinstance(extra_headers, dict)
            else extra_headers
        )
        cache_key = (api_key, api_base, api_version, headers_key)

        if cache_key in self._client_cache:
            return self._client_cache[cache_key]

        client: AsyncAzureOpenAI | AsyncOpenAI
        if resolved_model.startswith(("azure/", "azure_ai/")):
            if not api_base:
                raise ValueError("Azure OpenAI / Azure AI Foundry requires endpoint (api_base)")
            client = AsyncAzureOpenAI(
                api_key=api_key,
                azure_endpoint=api_base,
                api_version=api_version or "2024-10-21",
                default_headers=extra_headers,
            )
        else:
            client = AsyncOpenAI(
                api_key=api_key,
                base_url=api_base,
                default_headers=extra_headers,
            )

        self._client_cache[cache_key] = client
        return client

    # ── Response parsing ───────────────────────────────────────────────────────

    @staticmethod
    def _parse_chat_tool_calls(message: Any) -> list[ToolCallRequest]:
        if not getattr(message, "tool_calls", None):
            return []
        tool_calls = []
        for tc in message.tool_calls:
            args = tc.function.arguments
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            tool_calls.append(
                ToolCallRequest(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=args,
                )
            )
        return tool_calls

    @staticmethod
    def _merge_choices(response: Any) -> tuple[str, list[ToolCallRequest], str]:
        """Merge content and tool_calls across all choices (nanobot pattern).

        choices[0] is authoritative for content and finish_reason.
        Content from other choices is only used if choices[0] has none.
        Tool calls are merged from ALL choices (GitHub Copilot may split them).
        """
        if not response.choices:
            return "", [], "stop"

        primary = response.choices[0]
        content: str = primary.message.content or ""
        finish_reason: str = primary.finish_reason or "stop"

        all_tool_calls: list[ToolCallRequest] = []
        for choice in response.choices:
            tcs = OpenAIProvider._parse_chat_tool_calls(choice.message)
            all_tool_calls.extend(tcs)
            if not content and choice.message.content:
                content = choice.message.content
            if tcs and choice.finish_reason == "tool_calls":
                finish_reason = "tool_calls"

        if all_tool_calls and finish_reason != "tool_calls":
            finish_reason = "tool_calls"

        if len(response.choices) > 1:
            logger.debug(
                "Chat response has {} choices, merged {} tool_calls",
                len(response.choices),
                len(all_tool_calls),
            )

        return content, all_tool_calls, finish_reason

    @staticmethod
    def _parse_responses_result(
        response: Any,
    ) -> tuple[
        str, list[ToolCallRequest], str | None, int, int, list[dict[str, Any]], list[dict[str, Any]]
    ]:
        """Parse Responses API result.

        Returns (content, tool_calls, reasoning_content, prompt_tokens,
        completion_tokens, compaction_blobs, raw_output).
        """
        content: str = getattr(response, "output_text", "") or ""
        tool_calls: list[ToolCallRequest] = []
        reasoning_parts: list[str] = []
        compaction_blobs: list[dict[str, Any]] = []

        for item in getattr(response, "output", []) or []:
            item_type = getattr(item, "type", None)

            if item_type == "function_call":
                raw_args = getattr(item, "arguments", "{}") or "{}"
                if isinstance(raw_args, str):
                    try:
                        args = json.loads(raw_args)
                    except json.JSONDecodeError:
                        args = {"raw": raw_args}
                else:
                    args = raw_args
                tool_calls.append(
                    ToolCallRequest(
                        id=str(
                            getattr(item, "call_id", None)
                            or getattr(item, "id", None)
                            or "function_call"
                        ),
                        name=getattr(item, "name", ""),
                        arguments=args,
                    )
                )

            elif item_type == "reasoning":
                for part in getattr(item, "content", []) or []:
                    part_type = getattr(part, "type", None)
                    if part_type in ("thinking", "text"):
                        text = getattr(part, "thinking", None) or getattr(part, "text", "")
                        if text:
                            reasoning_parts.append(text)

            elif item_type == "compaction":
                compaction_blobs.append(
                    {
                        "type": "compaction",
                        "id": str(getattr(item, "id", "")),
                        "encrypted_content": str(getattr(item, "encrypted_content", "")),
                    }
                )

            elif item_type == "message" and not content:
                texts: list[str] = []
                for part in getattr(item, "content", []) or []:
                    if getattr(part, "type", None) in ("output_text", "text"):
                        text = getattr(part, "text", "")
                        if text:
                            texts.append(text)
                if texts:
                    content = "".join(texts)

        reasoning_content: str | None = "\n".join(reasoning_parts) if reasoning_parts else None

        usage = getattr(response, "usage", None)
        prompt_tokens = (
            int(getattr(usage, "input_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0)
            if usage
            else 0
        )
        completion_tokens = (
            int(getattr(usage, "output_tokens", 0) or getattr(usage, "completion_tokens", 0) or 0)
            if usage
            else 0
        )

        raw_output = _serialize_output(getattr(response, "output", None))

        return (
            content,
            tool_calls,
            reasoning_content,
            prompt_tokens,
            completion_tokens,
            compaction_blobs,
            raw_output,
        )

    # ── API call helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _build_responses_kwargs(
        req_kwargs: dict[str, Any],
        *,
        resolved_model: str = "",
        compact_threshold: int | None = None,
        native_items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
    ) -> dict[str, Any]:
        """Build Responses API request kwargs.

        Uses ``_prepare_items_for_api()`` for all sanitization (filtering,
        normalization, orphan removal).  Legacy ``messages`` path uses
        ``_responses_input()`` for Chat→native conversion.
        """
        if native_items is not None:
            input_items = _prepare_items_for_api(native_items, resolved_model)
        else:
            input_items = _responses_input(req_kwargs["messages"])

        # instructions: explicit param or extract first system message
        effective_instructions = instructions
        if effective_instructions is None:
            non_system: list[dict[str, Any]] = []
            for item in input_items:
                if effective_instructions is None and item.get("role") == "system":
                    effective_instructions = item.get("content", "")
                else:
                    non_system.append(item)
            input_items = non_system

        resp_kwargs: dict[str, Any] = {
            "model": req_kwargs.get("model", _api_model_name(resolved_model)),
            "input": input_items,
            "truncation": "auto",
        }

        if effective_instructions:
            resp_kwargs["instructions"] = effective_instructions

        # include reasoning encrypted_content for cross-turn fidelity
        if _should_prefer_responses_api(resolved_model or req_kwargs.get("model", "")):
            resp_kwargs["include"] = ["reasoning.encrypted_content"]

        if "temperature" in req_kwargs:
            resp_kwargs["temperature"] = req_kwargs["temperature"]
        if "max_completion_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_completion_tokens"]
        elif "max_tokens" in req_kwargs:
            resp_kwargs["max_output_tokens"] = req_kwargs["max_tokens"]
        if "reasoning_effort" in req_kwargs:
            resp_kwargs["reasoning"] = {"effort": req_kwargs["reasoning_effort"]}

        converted_tools = _responses_tools(req_kwargs.get("tools"))
        if converted_tools:
            resp_kwargs["tools"] = converted_tools

        # Server-side compaction
        if compact_threshold and _supports_server_compaction(resolved_model):
            resp_kwargs["context_management"] = [
                {"type": "compaction", "compact_threshold": max(compact_threshold, 1000)}
            ]

        return resp_kwargs

    async def _complete_via_responses(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
        native_items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> LLMResponse:
        resp_kwargs = self._build_responses_kwargs(
            req_kwargs,
            resolved_model=resolved_model,
            native_items=native_items,
            instructions=instructions,
            compact_threshold=compact_threshold,
        )

        start = time.monotonic()
        response = await client.responses.create(**resp_kwargs)
        elapsed_ms = (time.monotonic() - start) * 1000

        (
            content,
            tool_calls,
            reasoning_content,
            prompt_tokens,
            completion_tokens,
            compaction_blobs,
            raw_output,
        ) = self._parse_responses_result(response)

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            model=getattr(response, "model", None) or resolved_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=elapsed_ms,
            reasoning_content=reasoning_content,
            raw_output=raw_output,
            compaction_blobs=compaction_blobs,
        )

    async def _complete_via_chat(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
    ) -> LLMResponse:
        start = time.monotonic()
        response = await client.chat.completions.create(**req_kwargs)
        elapsed_ms = (time.monotonic() - start) * 1000

        content, tool_calls, finish_reason = self._merge_choices(response)
        usage = response.usage
        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            model=resolved_model,
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
            duration_ms=elapsed_ms,
        )

    async def _stream_via_responses(
        self,
        *,
        client: Any,
        resolved_model: str,
        req_kwargs: dict[str, Any],
        native_items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> AsyncIterator[LLMChunk]:
        """Stream via Responses API SSE events."""
        resp_kwargs = self._build_responses_kwargs(
            req_kwargs,
            resolved_model=resolved_model,
            native_items=native_items,
            instructions=instructions,
            compact_threshold=compact_threshold,
        )
        resp_kwargs["stream"] = True

        stream = await client.responses.create(**resp_kwargs)

        prompt_tokens = 0
        completion_tokens = 0

        async for event in stream:
            event_type = getattr(event, "type", "")

            if event_type == "response.output_text.delta":
                yield LLMChunk(
                    content=getattr(event, "delta", ""),
                    model=resolved_model,
                )

            elif event_type == "response.function_call_arguments.done":
                raw_args = getattr(event, "arguments", "{}")
                try:
                    args = json.loads(raw_args)
                except json.JSONDecodeError:
                    args = {"raw": raw_args}
                yield LLMChunk(
                    tool_calls=[
                        ToolCallRequest(
                            id=getattr(event, "call_id", "") or "",
                            name=getattr(event, "name", "") or "",
                            arguments=args,
                        )
                    ],
                    finish_reason="tool_calls",
                    model=resolved_model,
                )

            elif event_type == "response.completed":
                resp = getattr(event, "response", None)
                usage = getattr(resp, "usage", None) if resp else None
                if usage:
                    prompt_tokens = int(
                        getattr(usage, "input_tokens", 0) or getattr(usage, "prompt_tokens", 0) or 0
                    )
                    completion_tokens = int(
                        getattr(usage, "output_tokens", 0)
                        or getattr(usage, "completion_tokens", 0)
                        or 0
                    )
                # Extract compaction blobs and raw output from completed response
                if resp:
                    raw_output = _serialize_output(getattr(resp, "output", None))
                    blobs = [i for i in raw_output if i.get("type") == "compaction"]
                    if blobs or raw_output:
                        yield LLMChunk(
                            compaction_blobs=blobs,
                            raw_output=raw_output,
                            model=resolved_model,
                        )

        if self._usage:
            self._usage.record(
                model=resolved_model,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                duration_ms=0,
            )

    # ── Public API ─────────────────────────────────────────────────────────────

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
        items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> LLMResponse:
        if items is not None and messages:
            logger.warning(
                "Both items and messages provided; items takes precedence for Responses API"
            )
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. "
                "Configure GITHUB_TOKEN or OPENAI_API_KEY."
            )

        result: LLMResponse | None = None
        resolved_model = model
        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages or [],
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )
            try:
                client = self._build_client(resolved_model, creds)
                call_args: dict[str, Any] = dict(
                    client=client,
                    resolved_model=resolved_model,
                    req_kwargs=req_kwargs,
                )
                if items is not None:
                    call_args["native_items"] = items
                    call_args["instructions"] = instructions
                    call_args["compact_threshold"] = compact_threshold

                # Build Chat-safe kwargs (strip native-only params)
                chat_args = {
                    k: v
                    for k, v in call_args.items()
                    if k not in ("native_items", "instructions", "compact_threshold")
                }
                # If items were provided, always derive Chat messages from them
                # (items are the authoritative source; any pre-existing messages
                # may be stale or incomplete)
                if items is not None:
                    chat_args["req_kwargs"] = dict(req_kwargs)
                    chat_args["req_kwargs"]["messages"] = _sanitize_messages(
                        items_to_chat_messages(items, instructions=instructions)
                    )

                if _should_prefer_responses_api(resolved_model):
                    # Responses API first; fallback to Chat if not required
                    try:
                        result = await self._complete_via_responses(**call_args)
                    except Exception as resp_exc:
                        if _must_use_responses_api(resolved_model):
                            raise
                        logger.warning(
                            "Responses API failed for '{}'; trying Chat Completions: {}",
                            resolved_model,
                            resp_exc,
                        )
                        try:
                            result = await self._complete_via_chat(**chat_args)
                        except Exception:
                            raise resp_exc  # both failed; raise original
                else:
                    # Chat Completions first; fallback to Responses on unsupported
                    try:
                        result = await self._complete_via_chat(**chat_args)
                    except Exception as exc:
                        if _is_chat_unsupported_error(exc):
                            logger.warning(
                                "Model '{}' does not support /chat/completions; "
                                "switching to Responses API",
                                resolved_model,
                            )
                            result = await self._complete_via_responses(**call_args)
                        else:
                            raise

                if idx > 0:
                    logger.warning(
                        "LLM fallback succeeded: '{}' -> '{}'",
                        candidate_models[0],
                        resolved_model,
                    )
                break

            except Exception as exc:
                last_error = exc
                logger.error("LLM error ({}): {}", resolved_model, exc)

                # Token-limit errors: only try the next fallback if it has a
                # larger input limit (e.g. fast chain: gpt-5-mini 128K →
                # claude-haiku 136K).  Otherwise raise immediately so the
                # caller can compact and retry.
                from workpilot.utils.token_errors import is_token_limit_error

                if is_token_limit_error(exc):
                    if idx < len(candidate_models) - 1:
                        from workpilot.providers.model_catalog import get_max_input_tokens

                        current_limit = get_max_input_tokens(resolved_model)
                        next_limit = get_max_input_tokens(candidate_models[idx + 1])
                        if next_limit > current_limit:
                            logger.info(
                                "Token limit exceeded on {} ({}); trying {} ({}) with larger limit",
                                resolved_model,
                                current_limit,
                                candidate_models[idx + 1],
                                next_limit,
                            )
                            continue
                    raise

                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying LLM with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )

        if result is None:
            if last_error is not None:
                raise last_error
            raise RuntimeError("LLM completion failed without an exception")

        logger.debug(
            "LLM {}: {}+{} tokens, {:.0f}ms, {} tool calls{}",
            resolved_model,
            result.prompt_tokens,
            result.completion_tokens,
            result.duration_ms,
            len(result.tool_calls),
            " [reasoning]" if result.reasoning_content else "",
        )

        if self._usage:
            self._usage.record(
                model=resolved_model,
                prompt_tokens=result.prompt_tokens,
                completion_tokens=result.completion_tokens,
                duration_ms=result.duration_ms,
            )

        return result

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
        items: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        compact_threshold: int | None = None,
    ) -> AsyncIterator[LLMChunk]:
        if items is not None and messages:
            logger.warning(
                "Both items and messages provided; items takes precedence for Responses API"
            )
        candidate_models = resolve_model_chain(model, self._providers)
        if not candidate_models:
            raise ValueError(
                f"No model candidates resolved for alias '{model}'. "
                "Configure GITHUB_TOKEN or OPENAI_API_KEY."
            )

        last_error: Exception | None = None

        for idx, candidate in enumerate(candidate_models):
            resolved_model, req_kwargs, creds = self._build_kwargs(
                model=candidate,
                messages=messages or [],
                tools=tools,
                temperature=temperature,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
            )

            try:
                client = self._build_client(resolved_model, creds)
                call_args: dict[str, Any] = dict(
                    client=client,
                    resolved_model=resolved_model,
                    req_kwargs=req_kwargs,
                )
                if items is not None:
                    call_args["native_items"] = items
                    call_args["instructions"] = instructions
                    call_args["compact_threshold"] = compact_threshold

                # Chat-safe req_kwargs for fallback (convert items → messages + sanitize).
                # When items are provided, always derive from them (authoritative source).
                chat_req_kwargs = dict(req_kwargs)
                if items is not None:
                    chat_req_kwargs["messages"] = _sanitize_messages(
                        items_to_chat_messages(items, instructions=instructions)
                    )

                if _should_prefer_responses_api(resolved_model):
                    # Responses API streaming first
                    emitted_any = False
                    try:
                        async for chunk in self._stream_via_responses(**call_args):
                            emitted_any = True
                            yield chunk
                        if idx > 0:
                            logger.warning(
                                "LLM stream fallback succeeded: '{}' -> '{}'",
                                candidate_models[0],
                                resolved_model,
                            )
                        return
                    except Exception as resp_exc:
                        if _must_use_responses_api(resolved_model) or emitted_any:
                            raise
                        # Fallback to Chat Completions streaming
                        logger.warning(
                            "Responses API stream failed for '{}'; trying Chat Completions: {}",
                            resolved_model,
                            resp_exc,
                        )
                        try:
                            response = await client.chat.completions.create(
                                **chat_req_kwargs, stream=True
                            )
                            async for chunk in response:
                                if not chunk.choices:
                                    continue
                                choice = chunk.choices[0]
                                delta = choice.delta
                                yield LLMChunk(
                                    content=delta.content or "",
                                    finish_reason=choice.finish_reason,
                                    model=resolved_model,
                                )
                            return
                        except Exception:
                            raise resp_exc  # both failed; raise original

                else:
                    # Chat Completions streaming first
                    try:
                        response = await client.chat.completions.create(
                            **chat_req_kwargs, stream=True
                        )
                    except Exception as exc:
                        if _is_chat_unsupported_error(exc):
                            logger.warning(
                                "Model '{}' does not support /chat/completions; "
                                "switching to Responses API stream",
                                resolved_model,
                            )
                            async for chunk in self._stream_via_responses(**call_args):
                                yield chunk
                            return
                        raise

                    emitted_any = False
                    try:
                        async for chunk in response:
                            if not chunk.choices:
                                continue
                            emitted_any = True
                            choice = chunk.choices[0]
                            delta = choice.delta
                            yield LLMChunk(
                                content=delta.content or "",
                                finish_reason=choice.finish_reason,
                                model=resolved_model,
                            )
                        if idx > 0:
                            logger.warning(
                                "LLM stream fallback succeeded: '{}' -> '{}'",
                                candidate_models[0],
                                resolved_model,
                            )
                        return
                    except Exception as exc:
                        last_error = exc
                        logger.error(
                            "LLM stream iteration error ({}): {}",
                            resolved_model,
                            exc,
                        )
                        if emitted_any or idx >= len(candidate_models) - 1:
                            raise
                        logger.warning(
                            "Retrying stream with fallback model '{}' after early "
                            "stream failure in '{}'",
                            candidate_models[idx + 1],
                            resolved_model,
                        )

            except Exception as exc:
                last_error = exc
                logger.error("LLM stream error ({}): {}", resolved_model, exc)
                if idx < len(candidate_models) - 1:
                    logger.warning(
                        "Retrying stream with fallback model '{}' after '{}' failed",
                        candidate_models[idx + 1],
                        resolved_model,
                    )
                    continue
                raise

        if last_error is not None:
            raise last_error
        raise RuntimeError("LLM stream failed without an exception")
