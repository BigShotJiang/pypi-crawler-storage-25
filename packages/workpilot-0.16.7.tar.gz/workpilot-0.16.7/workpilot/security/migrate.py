"""
Auto-migration — encrypt plaintext secrets at startup.

Called by ``Runtime.__init__()`` when ``security.auto_migrate_secrets``
is enabled. Non-destructive (backups created), idempotent (state tracked in
``migration.json``), and fail-safe (errors don't block startup).
"""

from __future__ import annotations

import json
import shutil
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.security.secrets import (
    _atomic_write_file,
)
from workpilot.utils.helpers import get_auth_dir

if TYPE_CHECKING:
    from workpilot.config.schema import AppConfig
    from workpilot.security.audit import AuditLogger

# SecretStr field keys to scan in YAML.


def _collect_local_yamls(local_yaml_path: Path | None) -> list[Path]:
    """Collect all local YAML config files that may contain plaintext secrets."""
    candidates: list[Path] = []
    # 1. Explicit path from Runtime (workspace-local)
    if local_yaml_path and local_yaml_path.is_file():
        candidates.append(local_yaml_path)
    # 2. Home directory local override (~/.workpilot/workpilot.local.yaml)
    home_local = Path.home() / ".workpilot" / "workpilot.local.yaml"
    if home_local.is_file() and home_local.resolve() not in {p.resolve() for p in candidates}:
        candidates.append(home_local)
    return candidates


def maybe_migrate_secrets(
    config: AppConfig,
    local_yaml_path: Path | None,
    audit: AuditLogger,
) -> None:
    """Run auto-migration if enabled.  Called early in ``Runtime.__init__()``."""
    # Allow env var override: WORKPILOT_AUTO_MIGRATE_SECRETS=true
    import os

    env_override = os.environ.get("WORKPILOT_AUTO_MIGRATE_SECRETS", "").lower()
    if env_override in ("true", "1", "yes"):
        pass  # force migration regardless of config
    elif not config.security.auto_migrate_secrets:
        return

    from workpilot.security.secrets import get_secret_store

    try:
        store = get_secret_store()
    except Exception as exc:
        logger.warning("Auto-migration skipped: cannot initialize secret store: {}", exc)
        return

    # File lock to prevent concurrent migrations
    lock = _get_migration_lock()
    with lock:
        state = _load_state()

        try:
            for yaml_path in _collect_local_yamls(local_yaml_path):
                _migrate_config_yaml(yaml_path, store, state, audit)

            # Recover missing secrets from backups or re-auth
            _recover_missing_secrets(store, local_yaml_path)

            _migrate_msal_cache(get_auth_dir(), state, audit)
        except Exception as exc:
            logger.warning("Auto-migration error: {}", exc)
            audit.log_event(action="migration_error", data={"details": str(exc)})

        _save_state(state)


# ---------------------------------------------------------------------------
# Recovery — restore missing secrets from backups or interactive re-auth
# ---------------------------------------------------------------------------


def _recover_missing_secrets(store: Any, local_yaml_path: Path | None) -> None:
    """Check SECRET[name] refs in YAML and recover any missing from backups or re-auth."""
    import os

    import yaml

    for yaml_path in _collect_local_yamls(local_yaml_path):
        try:
            parsed = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.debug("Cannot parse {} for recovery: {}", yaml_path.name, exc)
            continue
        if not isinstance(parsed, dict):
            continue

        for path, store_key in SECRET_FIELD_PATHS.items():
            # Check if this YAML has a SECRET[name] ref at this path
            obj: Any = parsed
            for part in path.split("."):
                if isinstance(obj, dict) and part in obj:
                    obj = obj[part]
                else:
                    obj = None
                    break
            if not isinstance(obj, str) or not obj.startswith("SECRET["):
                continue
            # Parse the actual referenced name from SECRET[name] using same regex as loader
            import re

            _m = re.match(r"^SECRET\[([A-Za-z_][A-Za-z0-9_]*)\]$", obj)
            secret_name = _m.group(1) if _m else store_key
            # Check if store has the value
            if store.get(secret_name) is not None:
                continue

            # Missing — try backup recovery
            recovered = _recover_from_backup(secret_name, path, store)
            if recovered:
                continue

            # Try interactive re-auth for GitHub
            if secret_name in ("GITHUB_COPILOT_TOKEN", "GITHUB_TOKEN") and os.isatty(0):
                _try_github_reauth(secret_name, store)


def _recover_from_backup(store_key: str, yaml_path: str, store: Any) -> bool:
    """Try to recover a secret from .pre-encrypt.bak files. Returns True if recovered."""
    import yaml as _yaml

    for bak in (Path.home() / ".workpilot").glob("*.pre-encrypt.bak"):
        try:
            parsed = _yaml.safe_load(bak.read_text(encoding="utf-8"))
            if not isinstance(parsed, dict):
                continue
            obj: Any = parsed
            for part in yaml_path.split("."):
                if isinstance(obj, dict) and part in obj:
                    obj = obj[part]
                else:
                    obj = None
                    break
            if isinstance(obj, str) and not obj.startswith(("SECRET[", "${")):
                store.set(store_key, obj)
                logger.info("Recovered '{}' from backup {}", store_key, bak.name)
                return True
        except Exception:
            pass
    return False


def _try_github_reauth(store_key: str, store: Any) -> None:
    """Trigger GitHub device code login to recover a missing token."""
    logger.warning("GitHub token missing — starting device code login...")
    try:
        from workpilot.security.github_auth import github_device_login

        token = github_device_login()
        if token:
            store.set(store_key, token)
            logger.info("GitHub token stored as '{}'", store_key)
    except Exception as exc:
        logger.warning("GitHub re-auth failed: {}", exc)


# ---------------------------------------------------------------------------
# Migration flows
# ---------------------------------------------------------------------------


# Known SecretStr field paths and their store key names.
# Defined once — used by both auto-migration and CLI migrate-config.
# MCP server tokens are excluded — multiple servers would collide on one key.
# Users should manually: workpilot secrets set <name> + SECRET[<name>] in YAML.
SECRET_FIELD_PATHS: dict[str, str] = {
    "providers.openai.api_key": "OPENAI_API_KEY",
    "providers.github_copilot.token": "GITHUB_COPILOT_TOKEN",
    "channels.web.api_key": "WEB_API_KEY",
}


def _walk_yaml_secrets(data: Any, prefix: str = "") -> list[tuple[str, str, str]]:
    """Walk parsed YAML and find plaintext values at known SecretStr paths.

    Handles both dicts and lists (e.g., tools.mcp_servers can be either).
    For list items, the path uses the parent key without index so it matches
    SECRET_FIELD_PATHS entries.

    Returns list of (yaml_path, store_key, plaintext_value).
    """
    results: list[tuple[str, str, str]] = []
    if isinstance(data, dict):
        for key, value in data.items():
            path = f"{prefix}.{key}" if prefix else key
            if isinstance(value, (dict, list)):
                results.extend(_walk_yaml_secrets(value, path))
            elif isinstance(value, str) and value and not value.startswith(("SECRET[", "${")):
                store_key = SECRET_FIELD_PATHS.get(path)
                if store_key:
                    results.append((path, store_key, value))
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, (dict, list)):
                results.extend(_walk_yaml_secrets(item, prefix))
    return results


def _warn_manual_migration(parsed: dict) -> None:
    """Warn about MCP server secrets that require manual migration."""
    mcp_servers = parsed.get("tools", {}).get("mcp_servers")
    if mcp_servers is None:
        return

    # Normalize: mcp_servers can be a list or a dict keyed by server name
    servers: list[tuple[str, dict]] = []
    if isinstance(mcp_servers, list):
        for i, s in enumerate(mcp_servers):
            if isinstance(s, dict):
                servers.append((s.get("name", f"server[{i}]"), s))
    elif isinstance(mcp_servers, dict):
        for name, s in mcp_servers.items():
            if isinstance(s, dict):
                servers.append((name, s))
    else:
        return

    for name, server in servers:
        auth = server.get("auth", {})
        if not isinstance(auth, dict):
            continue
        for field in ("token", "client_secret"):
            val = auth.get(field)
            if isinstance(val, str) and val and not val.startswith(("SECRET[", "${")):
                logger.warning(
                    "MCP server '{}' has plaintext {} — migrate manually:\n"
                    "  workpilot secrets set MCP_{}_{}  \n"
                    '  Then set auth.{}: "SECRET[MCP_{}_{}]" in YAML',
                    name,
                    field,
                    name.upper().replace("-", "_"),
                    field.upper(),
                    field,
                    name.upper().replace("-", "_"),
                    field.upper(),
                )


def _migrate_config_yaml(
    path: Path,
    store: Any,
    state: dict,
    audit: AuditLogger,
) -> None:
    """Move plaintext SecretStr values to SecretStore, replace with SECRET[name] in YAML."""
    state_key = f"config_yaml:{path.resolve()}"
    if state.get(state_key, {}).get("status") == "completed":
        return
    if not path.is_file():
        return

    import yaml

    content = path.read_text(encoding="utf-8")
    parsed = yaml.safe_load(content)
    if not isinstance(parsed, dict):
        return

    # Find all plaintext secrets by walking the YAML structure
    secrets_found = _walk_yaml_secrets(parsed)

    # Warn about MCP secrets that can't be auto-migrated
    _warn_manual_migration(parsed)

    if not secrets_found:
        state[state_key] = {"status": "completed", "fields_migrated": []}
        return

    # Store each secret and replace only the exact YAML value occurrence
    import re as _re

    new_content = content
    fields: list[str] = []
    for _yaml_path, store_key, plaintext in secrets_found:
        store.set(store_key, plaintext)
        fields.append(store_key)
        # Match the field's value precisely: key: "value" or key: value (once only)
        escaped = _re.escape(plaintext)
        pattern = _re.compile(r'(:\s*)"?' + escaped + r'"?\s*(?:#.*)?$', _re.MULTILINE)
        new_content = pattern.sub(rf'\1"SECRET[{store_key}]"', new_content, count=1)

    # Backup original (with restrictive permissions)
    backup = path.with_suffix(path.suffix + ".pre-encrypt.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
        import stat
        import sys

        if sys.platform == "win32":
            from workpilot.security.secrets import _set_windows_acl

            _set_windows_acl(backup)
        else:
            backup.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600

    _atomic_write_file(path, new_content.encode("utf-8"))

    state[state_key] = {
        "status": "completed",
        "timestamp": datetime.now(UTC).isoformat(),
        "fields_migrated": fields,
        "backup": str(backup),
    }
    logger.info("Auto-migration: stored {} secret(s) from {}", len(fields), path.name)
    audit.log_event(
        action="migration_config_yaml", data={"fields_migrated": fields, "backup": str(backup)}
    )


def _migrate_msal_cache(
    auth_dir: Path,
    state: dict,
    audit: AuditLogger,
) -> None:
    """Encrypt plaintext MSAL token caches using unified encrypt_at_rest."""
    if state.get("msal_cache", {}).get("status") == "completed":
        return

    from workpilot.security.secrets import encrypt_at_rest, is_encrypted

    files_migrated: list[str] = []
    for cache_file in auth_dir.glob("token_cache_*.bin"):
        try:
            raw = cache_file.read_bytes()
            if is_encrypted(raw):
                continue  # already encrypted
            if not raw.strip():
                continue  # empty
            encrypted = encrypt_at_rest(raw)
            if encrypted != raw:  # encryption was applied
                _atomic_write_file(cache_file, encrypted)
                files_migrated.append(cache_file.name)
        except Exception as exc:
            logger.warning("Failed to encrypt {}: {}", cache_file.name, exc)

    # Only mark completed if encryption was applied or no plaintext caches remain
    has_plaintext = False
    for f in auth_dir.glob("token_cache_*.bin"):
        content = f.read_bytes()
        if content.strip() and not is_encrypted(content):
            has_plaintext = True
            break
    if files_migrated or not has_plaintext:
        state["msal_cache"] = {
            "status": "completed",
            "timestamp": datetime.now(UTC).isoformat(),
            "files": files_migrated,
        }
    if files_migrated:
        logger.info("Auto-migration: encrypted {} MSAL cache(s)", len(files_migrated))
        audit.log_event(action="migration_msal_cache", data={"files": files_migrated})


# ---------------------------------------------------------------------------
# Plaintext backup cleanup
# ---------------------------------------------------------------------------


def _delete_plaintext_backups(state: dict) -> None:
    """Delete .pre-encrypt.bak files referenced in migration state."""
    for _key, entry in state.items():
        if not isinstance(entry, dict):
            continue
        backup_path_str = entry.get("backup")
        if not backup_path_str:
            continue
        backup = Path(backup_path_str)
        if backup.is_file():
            try:
                backup.unlink()
                logger.info("Deleted plaintext backup: {}", backup)
            except OSError as exc:
                logger.warning("Failed to delete backup {}: {}", backup, exc)


# ---------------------------------------------------------------------------
# State persistence
# ---------------------------------------------------------------------------


def _state_path() -> Path:
    """Lazily compute migration state path (avoids directory creation at import time)."""
    return get_auth_dir() / "migration.json"


def _load_state() -> dict[str, object]:
    path = _state_path()
    if path.is_file():
        try:
            data: dict[str, object] = json.loads(path.read_text(encoding="utf-8"))
            return data
        except Exception:
            pass
    return {"version": 1}


def _save_state(state: dict) -> None:
    state["version"] = 1
    _atomic_write_file(_state_path(), json.dumps(state, indent=2, ensure_ascii=False))


def _get_migration_lock() -> Any:
    """Acquire file lock for migration (separate from FernetBackend's lock)."""
    lock_path = get_auth_dir() / "secrets.lock"
    try:
        from filelock import FileLock

        return FileLock(lock_path, timeout=10)
    except ImportError:
        from contextlib import nullcontext

        logger.warning(
            "filelock not installed — concurrent migration unprotected. pip install filelock"
        )
        return nullcontext()
