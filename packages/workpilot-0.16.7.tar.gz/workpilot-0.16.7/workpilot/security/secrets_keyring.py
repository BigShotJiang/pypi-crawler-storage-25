"""
KeyringBackend — OS-native credential store via the ``keyring`` library.

Uses Windows Credential Manager, macOS Keychain, or Linux Secret Service
depending on the platform.  ``keyring`` is included in base dependencies.

Values are Fernet-encrypted before storing.  Short encrypted values go into
the OS keyring (double protection: Fernet + DPAPI/Keychain).  Values that
exceed the keyring size limit after encryption are stored in the encrypted
file backend instead (same Fernet encryption, file-system permissions).

Maintains a local index file (``~/.workpilot/auth/keyring_index.json``)
to support ``list_names()`` since OS keyrings don't support enumeration.
"""

from __future__ import annotations

import json

from loguru import logger

from workpilot.security.secrets import (
    _KEYRING_SERVICE,
    SecretStore,
    SecretStoreError,
    decrypt_at_rest,
    encrypt_at_rest,
    is_encrypted,
)

# Windows Credential Manager limit: CRED_MAX_CREDENTIAL_BLOB_SIZE = 2560 bytes.
_KEYRING_MAX_BYTES = 2500  # leave headroom for keyring/Unicode overhead


class KeyringBackend(SecretStore):
    """OS keyring-backed secret store with Fernet encryption and file overflow."""

    def __init__(self) -> None:
        try:
            import keyring  # type: ignore[import]

            self._keyring = keyring
        except ImportError:
            raise SecretStoreError(  # noqa: B904
                "keyring not installed. Run: pip install keyring"
            )
        self._backend_name = type(self._keyring.get_keyring()).__name__
        from workpilot.utils.helpers import get_auth_dir

        self._index_path = get_auth_dir() / "keyring_index.json"
        self._index: set[str] | None = None
        # Lazy-initialized file backend for overflow secrets
        self._file_backend: SecretStore | None = None

    def _get_file_backend(self) -> SecretStore:
        if self._file_backend is None:
            from workpilot.security.secrets_fernet import FernetBackend

            self._file_backend = FernetBackend()
        return self._file_backend

    # ── Index management ──────────────────────────────────────────────────

    def _load_index(self) -> set[str]:
        if self._index is not None:
            return self._index
        if self._index_path.is_file():
            try:
                self._index = set(json.loads(self._index_path.read_text(encoding="utf-8")))
                return self._index
            except Exception:
                pass
        self._index = set()
        return self._index

    def _save_index(self) -> None:
        if self._index is None:
            return
        from workpilot.security.secrets import _atomic_write_file

        _atomic_write_file(self._index_path, json.dumps(sorted(self._index), indent=2))

    # ── Public API ────────────────────────────────────────────────────────

    def get(self, name: str) -> str | None:
        # Try keyring first
        try:
            value = self._keyring.get_password(_KEYRING_SERVICE, name)
            if value:
                raw = value.encode()
                if not is_encrypted(raw):
                    return value  # not encrypted — return as-is
                decrypted = decrypt_at_rest(raw)
                if not decrypted and raw:
                    return None  # decryption failed (non-empty input → empty output)
                return decrypted.decode()
        except Exception as exc:
            logger.warning("Keyring get '{}' failed: {}", name, exc)

        # Fallback: check file backend for overflow secrets
        return self._get_file_backend().get(name)

    def set(self, name: str, value: str) -> None:
        encrypted = encrypt_at_rest(value.encode(), strict=True).decode()

        if len(encrypted.encode()) <= _KEYRING_MAX_BYTES:
            # Fits in keyring — store there, clean up any file overflow
            try:
                self._keyring.set_password(_KEYRING_SERVICE, name, encrypted)
            except Exception as exc:
                raise SecretStoreError(f"Keyring set '{name}' failed: {exc}") from exc
            self._get_file_backend().delete(name)
        else:
            # Too large for keyring — store in file backend, clean up keyring
            logger.debug(
                "Secret '{}' encrypted to {} bytes, exceeds keyring limit — using file backend",
                name,
                len(encrypted.encode()),
            )
            self._get_file_backend().set(name, value)
            try:
                self._keyring.delete_password(_KEYRING_SERVICE, name)
            except Exception:
                pass

        self._load_index().add(name)
        self._save_index()

    def delete(self, name: str) -> None:
        try:
            self._keyring.delete_password(_KEYRING_SERVICE, name)
        except Exception:
            pass
        self._get_file_backend().delete(name)
        self._load_index().discard(name)
        self._save_index()

    def list_names(self) -> list[str]:
        return sorted(self._load_index())

    def backend_info(self) -> str:
        count = len(self._load_index())
        return (
            f"KeyringBackend (service={_KEYRING_SERVICE!r}, "
            f"backend={self._backend_name}, encryption=fernet, secrets={count})"
        )
