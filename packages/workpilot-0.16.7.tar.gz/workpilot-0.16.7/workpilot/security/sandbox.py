"""
Sandbox — enforces workspace boundaries and command restrictions.

Enterprise safety layer that prevents:
- Path traversal outside workspace
- Dangerous shell commands (rm -rf /, fork bombs, etc.)
- Access to sensitive system paths
"""

from __future__ import annotations

import re
from pathlib import Path

from loguru import logger

from workpilot.config.schema import SecurityProfile, ShellConfig

# ── Profile-linked defaults ──────────────────────────────────────────────────

_PROFILE_DEFAULTS: dict[str, dict[str, list[str]]] = {
    "open": {
        "allowed_paths": ["*"],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.gnupg",
        ],
    },
    "standard": {
        "allowed_paths": [],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.ssh",
            "~/.gnupg",
            "~/.aws/credentials",
        ],
    },
    "controlled": {
        "allowed_paths": [],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.ssh",
            "~/.gnupg",
            "~/.aws/credentials",
            "~/.config",
            "~/.local",
        ],
    },
    "restricted": {
        "allowed_paths": [],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.ssh",
            "~/.gnupg",
            "~/.aws/credentials",
            "~/.config",
            "~/.local",
        ],
    },
}


class CommandDeniedError(Exception):
    """Raised when a shell command is blocked by security rules."""


class PathDeniedError(Exception):
    """Raised when a file path is blocked by security rules."""


class Sandbox:
    """Workspace-scoped sandbox for file and command operations."""

    def __init__(
        self,
        workspace: Path,
        *,
        shell_config: ShellConfig | None = None,
        profile: SecurityProfile = SecurityProfile.STANDARD,
        allowed_paths: list[str] | None = None,
        denied_paths: list[str] | None = None,
    ) -> None:
        self._workspace = workspace.resolve()

        # Shell command rules
        shell = shell_config or ShellConfig()
        self._shell = shell
        self._deny_re = [re.compile(p, re.IGNORECASE) for p in shell.deny_patterns]
        self._allow_re = [re.compile(p, re.IGNORECASE) for p in shell.allow_patterns]

        # Path rules — merge profile defaults ∪ user config
        defaults = _PROFILE_DEFAULTS.get(profile.value, _PROFILE_DEFAULTS["standard"])

        effective_allowed = set(defaults["allowed_paths"]) | set(allowed_paths or [])
        effective_denied = set(defaults["denied_paths"]) | set(denied_paths or [])

        self._unrestricted = "*" in effective_allowed
        self._allowed = [Path(p).expanduser().resolve() for p in effective_allowed if p != "*"]
        self._denied = [Path(p).expanduser().resolve() for p in effective_denied]

        # Snapshot profile defaults for set_allowed_paths() reset
        self._profile_allowed_defaults = frozenset(defaults["allowed_paths"])

    # ── Command sandbox ──────────────────────────────────────────────────

    def match_deny_pattern(self, command: str) -> str | None:
        """Return the first matching deny pattern, or None if no match."""
        for pattern in self._deny_re:
            if pattern.search(command):
                return pattern.pattern
        return None

    def check_command(self, command: str) -> None:
        """Raise CommandDeniedError if the command matches a deny pattern."""
        matched = self.match_deny_pattern(command)
        if matched:
            logger.warning(f"Command blocked by deny pattern: {command!r}")
            raise CommandDeniedError(f"Command blocked by security policy (matched: {matched})")

        # If allow patterns are set, command must match at least one
        if self._allow_re:
            if not any(p.search(command) for p in self._allow_re):
                raise CommandDeniedError("Command not in allow list")

    # ── File sandbox ─────────────────────────────────────────────────────

    def resolve_path(self, path: str | Path) -> Path:
        """Resolve a path, enforcing denied_paths and workspace/allowed_paths fence.

        Check priority:
        1. denied_paths — highest priority, hard block
        2. ``"*"`` in allowed_paths — unrestricted mode, allow
        3. within workspace — primary fence
        4. within allowed_paths — explicit exceptions
        5. PathDeniedError
        """
        resolved = (self._workspace / Path(path).expanduser()).resolve()

        # 1. Deny list — highest priority
        if self.is_path_denied(resolved):
            raise PathDeniedError(f"Access denied to protected path: {path}")

        # 2. Unrestricted mode ("*")
        if self._unrestricted:
            return resolved

        # 3-4. Workspace + allowed paths fence
        if self._is_within(resolved, self._workspace):
            return resolved
        if any(self._is_within(resolved, p) for p in self._allowed):
            return resolved

        raise PathDeniedError(
            f"Path escapes workspace and is not in an allowed directory: {path} -> {resolved}"
        )

    def is_path_denied(self, resolved: Path) -> bool:
        """Check if a resolved path matches any entry in the deny list."""
        for deny_path in self._denied:
            if self._is_within(resolved, deny_path) or resolved == deny_path:
                return True
        return False

    # ── Dynamic operations ───────────────────────────────────────────────

    def switch_workspace(self, new_workspace: Path) -> None:
        """Switch workspace root. Safe because tool calls are sequential."""
        self._workspace = new_workspace.resolve()

    def set_allowed_paths(self, paths: list[str] | None) -> None:
        """Replace allowed paths, merging with profile defaults.

        If *paths* is ``None``, revert to profile defaults only.
        Otherwise, compute profile defaults ∪ paths (same as __init__).
        """
        effective = set(self._profile_allowed_defaults) | set(paths or [])
        self._unrestricted = "*" in effective
        self._allowed = [Path(p).expanduser().resolve() for p in effective if p != "*"]

    def add_allowed_path(self, path: Path) -> None:
        """Add a path to the allowed list at runtime."""
        resolved = path.expanduser().resolve()
        if resolved not in self._allowed:
            self._allowed.append(resolved)

    def remove_allowed_path(self, path: Path) -> None:
        """Remove a path from the runtime allowed list."""
        resolved = path.expanduser().resolve()
        self._allowed = [p for p in self._allowed if p != resolved]

    # ── Properties ───────────────────────────────────────────────────────

    @property
    def workspace(self) -> Path:
        return self._workspace

    @property
    def shell_timeout(self) -> int:
        return self._shell.timeout

    @staticmethod
    def _is_within(child: Path, parent: Path) -> bool:
        """Check if child path is within parent directory."""
        try:
            child.relative_to(parent)
            return True
        except ValueError:
            return False
