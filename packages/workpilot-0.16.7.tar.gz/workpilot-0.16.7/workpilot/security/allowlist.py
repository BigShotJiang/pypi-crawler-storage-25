"""
Per-user allowlist — skip approval prompts for known-safe tool calls.

Entries stored in ``workpilot.local.yaml`` under ``security.allowlist.entries``.
Each entry matches a tool name exactly and optionally checks specific arg
fields via per-field regex patterns (``match`` dict).  Fields not in
``match`` are ignored — content can vary freely.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from workpilot.config.schema import AllowlistConfig, AllowlistEntry


# ── Match derivation ─────────────────────────────────────────────────────────

# Tool-specific extractors: return {arg_key: value} for the stable target.
_MATCH_EXTRACTORS: dict[str, Any] = {
    "shell": lambda a: {"command": a.get("command", "")},
    "http_request": lambda a: {"method": a.get("method", "GET"), "url": a.get("url", "")},
    "git": lambda a: {"subcommand": a.get("subcommand", ""), "args": a.get("args", "")},
    "write_file": lambda a: {"path": a.get("path", "")},
    "edit_file": lambda a: {"path": a.get("path", "")},
    "read_file": lambda a: {"path": a.get("path", "")},
}

# Content keys — vary between invocations, excluded from auto-derived match.
_CONTENT_KEYS = frozenset(
    {
        "content",
        "message",
        "body",
        "text",
        "subject",
        "old_string",
        "new_string",
        "data",
        "payload",
        "prompt",
        "query",
    }
)


def _derive_match(tool_name: str, args: dict[str, Any]) -> dict[str, str]:
    """Auto-generate a ``match`` dict from the current tool call.

    Extracts target/identity fields and skips content fields.
    Each value is ``re.escape()``-d so the pattern matches exactly.
    Users can later edit patterns in ``workpilot.local.yaml`` to broaden.
    """
    if not args:
        return {}  # empty args → no match (full tool bypass)

    extractor = _MATCH_EXTRACTORS.get(tool_name)
    if extractor:
        raw = extractor(args)
    else:
        # Default: all args except content keys
        raw = {k: v for k, v in args.items() if k.lower() not in _CONTENT_KEYS and v}

    if not raw:
        return {}

    return {k: re.escape(str(v)) for k, v in raw.items() if v}


# ── Manager ────────────────────────────────────────────────────────────────────


class AllowlistManager:
    """Manages the per-user tool allowlist.

    Parameters
    ----------
    config:
        ``AllowlistConfig`` section from the loaded config.
    persist_fn:
        Callback to persist a new entry to ``workpilot.local.yaml``.
        Signature: ``(entry_dict) -> None``.  If ``None``, entries are
        kept in-memory only (useful for tests).
    """

    def __init__(
        self,
        config: AllowlistConfig,
        persist_fn: Any | None = None,
        remove_fn: Any | None = None,
    ) -> None:
        self._config = config
        self._persist_fn = persist_fn
        self._remove_fn = remove_fn
        self._entries: list[AllowlistEntry] = list(config.entries)
        logger.debug("AllowlistManager initialised — {} entries", len(self._entries))

    # ── Public API ────────────────────────────────────────────────────────

    def check(self, tool_name: str, args: dict[str, Any]) -> bool:
        """Return ``True`` if any entry matches the tool call."""
        return any(self._matches(entry, tool_name, args) for entry in self._entries)

    def add(
        self,
        tool_name: str,
        args: dict[str, Any] | None = None,
        *,
        match_override: dict[str, str] | None = None,
        added_by: str = "",
        note: str = "",
    ) -> AllowlistEntry:
        """Add a new allowlist entry with auto-derived match fields.

        Parameters
        ----------
        tool_name:
            Exact tool name to match.
        args:
            Current tool call args.  Used to derive ``match`` fields.
            ``None`` means no match (full tool bypass).
        match_override:
            Explicit match dict.  Overrides auto-derivation when provided
            (e.g. from CLI ``--match`` flag).
        added_by:
            Identity of the user creating this entry.
        note:
            Human-readable explanation.
        """
        from workpilot.config.schema import AllowlistEntry

        match = (
            match_override
            if match_override is not None
            else (_derive_match(tool_name, args) if args else {})
        )
        entry = AllowlistEntry(
            tool=tool_name,
            match=match,
            added_by=added_by,
            note=note,
        )
        self._entries.append(entry)

        if self._persist_fn:
            try:
                dump = entry.model_dump(exclude_none=True)
                if not dump.get("match"):
                    dump.pop("match", None)  # omit empty match from YAML
                self._persist_fn(dump)
            except Exception as exc:
                logger.error("Failed to persist allowlist entry: {}", exc)

        logger.info(
            "Allowlist entry added: tool={} match={} by={}",
            tool_name,
            match,
            added_by,
        )
        return entry

    def remove(self, index: int) -> AllowlistEntry:
        """Remove an entry by index and persist to config."""
        entry = self._entries.pop(index)
        if self._remove_fn:
            try:
                self._remove_fn(index)
            except Exception as exc:
                logger.error("Failed to persist allowlist removal: {}", exc)
        logger.info("Allowlist entry removed: tool={}", entry.tool)
        return entry

    def list_entries(self) -> list[AllowlistEntry]:
        """Return a copy of the current entries."""
        return list(self._entries)

    # ── Matching ──────────────────────────────────────────────────────────

    @staticmethod
    def _matches(entry: AllowlistEntry, tool_name: str, args: dict[str, Any]) -> bool:
        if entry.tool != tool_name:
            return False
        if not entry.match:
            return True  # no match fields → full tool bypass
        for key, pattern in entry.match.items():
            if key not in args:
                return False  # required key missing → no match
            value = str(args[key])
            try:
                if not re.search(pattern, value):
                    return False
            except re.error:
                logger.warning("Invalid allowlist regex for key '{}': {}", key, pattern)
                return False
        return True  # all match fields passed
