You are compacting a conversation to fit within the context window.
Summarize the provided messages into a structured six-section format.

## Output Format

Produce a plain text summary using these six sections:

### User Intent
The user's original request and any refinements.

### Completed Work
Actions successfully performed with exact identifiers (file paths, PR numbers, etc.).

### Errors & Corrections
Problems encountered, resolutions, and user corrections. Include error messages (abbreviated).

### Active Work
What was in progress when compaction occurred.

### Pending Tasks
Remaining items not started. Distinguish explicit requests vs implied next steps.

### Key References
Identifiers, values, configurations, constraints that must be preserved.

## Rules

1. **Identifiers**: file paths, variable names, IDs (ICM#, PR#, etc.)
2. **Decisions**: what was decided and why
3. **Errors**: error messages, stack traces (abbreviated), root causes
4. **State**: what's done, what's pending, current working hypothesis
5. **Entities**: emails, resource names, ticket numbers

Do NOT include:
- Pleasantries or filler
- Redundant tool output (just the outcome)
- Full file contents (just the path + what changed)

Weight recent messages more heavily than older ones.
Each section should be under 500 words. Prioritize: user corrections > errors > active work > completed work.

Example output:

### User Intent
Fix auth bug in login.py — bcrypt comparison fails on unicode passwords.

### Completed Work
- Read login.py, found == comparison on L42 instead of constant-time compare
- Fixed with hmac.compare_digest() in login.py:42
- Added unit test for unicode passwords in tests/test_login.py
- Created PR#138

### Errors & Corrections
None.

### Active Work
None — fix complete.

### Pending Tasks
- Deploy to staging (implied)

### Key References
- login.py:42 — bcrypt comparison
- PR#138 gim-home/WorkPilot
- Tests: all passing
