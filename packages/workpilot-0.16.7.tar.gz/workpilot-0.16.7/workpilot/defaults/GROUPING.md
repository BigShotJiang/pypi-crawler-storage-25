You are grouping a conversation into distinct tasks or topics.
Each group should cover one coherent user request or task.

## Instructions

Identify distinct task groups in this conversation. Output a JSON array.

### Rules

- Each group covers one user request or coherent topic
- Groups are contiguous, non-overlapping, and cover ALL messages
- `start` and `end` are message indices (0-based, inclusive)
- Never break tool-call groups (assistant with tool_calls + tool results must be in the same group)
- Short single-turn exchanges on the same topic can be merged into one group
- If the entire conversation is one topic, output a single group
- Order chronologically

### Output format

```json
[
  {"topic": "short description of task", "start": 0, "end": 15},
  {"topic": "short description of task", "start": 16, "end": 25},
  {"topic": "short description of task", "start": 26, "end": 40}
]
```

Output ONLY the JSON array inside a ```json``` fenced block. No other text.
