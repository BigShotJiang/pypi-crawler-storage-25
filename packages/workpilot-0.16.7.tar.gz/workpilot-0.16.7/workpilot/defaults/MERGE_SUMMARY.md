Merge these two conversation summaries into one concise summary
(target ~2000 chars). Summary A is chronologically earlier; Summary B
is more recent — weight B more heavily.

Preserve:
- Identifiers (file paths, variable names, IDs)
- Decisions and their rationale
- Errors and root causes
- Current state (done/pending/hypothesis)
- Entities (emails, resource names, ticket numbers)

Output a single plain text summary.
