"""HTML to Markdown conversion for rich text messages."""

from __future__ import annotations

import re
from functools import cache
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from markdownify import MarkdownConverter


@cache
def _converter_class() -> type[MarkdownConverter]:
    """Build a subclass of MarkdownConverter that drops redundant link metadata.

    Teams/ADO cards emit `<a href="URL" title="URL">text</a>` where the title
    duplicates the href — markdownify preserves the title verbatim, producing
    `[text](URL "URL")`. By removing the attribute before `convert_a` runs, we
    let markdownify's built-in `autolinks=True` collapse `<a href=url>url</a>`
    to `<url>` when display text also matches.
    """
    import markdownify

    class _Converter(markdownify.MarkdownConverter):  # type: ignore[misc]
        def convert_a(self, el: Any, text: str, parent_tags: Any) -> str:
            if el.get("title") and el.get("title") == el.get("href"):
                del el.attrs["title"]
            return super().convert_a(el, text, parent_tags)  # type: ignore[no-any-return,misc]

    return _Converter


def html_to_markdown(html: str) -> str:
    """Convert HTML to Markdown. Uses markdownify if available, else regex fallback."""
    try:
        return _converter_class()(strip=["img"]).convert(html).strip()
    except ImportError:
        pass
    except Exception as exc:
        from loguru import logger

        logger.debug("markdownify failed, using regex fallback: {}", exc)
    return _regex_fallback(html)


_LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")


def _collapse_self_referential_links(md: str) -> str:
    """Regex-fallback helper: `[url](url)` → `<url>` when display text equals href.

    Only used on the no-markdownify fallback path — the markdownify path gets
    autolink collapse natively via `autolinks=True`.
    """
    return _LINK_RE.sub(
        lambda m: f"<{m.group(2)}>" if m.group(1).strip() == m.group(2).strip() else m.group(0),
        md,
    )


def _regex_fallback(html: str) -> str:
    """Best-effort HTML->Markdown using regex (no external deps)."""
    import html as html_mod

    # Convert <a href="url">text</a> -> [text](url)
    text = re.sub(
        r'<a\s+[^>]*href=["\']([^"\']*)["\'][^>]*>(.*?)</a>',
        r"[\2](\1)",
        html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # <b>/<strong> -> ** (allow attributes)
    text = re.sub(
        r"<(b|strong)\b[^>]*>(.*?)</\1>", r"**\2**", text, flags=re.IGNORECASE | re.DOTALL
    )
    # <i>/<em> -> * (allow attributes)
    text = re.sub(r"<(i|em)\b[^>]*>(.*?)</\1>", r"*\2*", text, flags=re.IGNORECASE | re.DOTALL)
    # <br> -> newline
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    # <p>...</p> -> paragraph with blank line (allow attributes)
    text = re.sub(r"<p\b[^>]*>(.*?)</p>", r"\1\n\n", text, flags=re.IGNORECASE | re.DOTALL)
    # Strip remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    # Decode HTML entities, then strip any tags that unescape may have reintroduced
    text = html_mod.unescape(text)
    text = re.sub(r"<[^>]+>", "", text)
    # Clean up whitespace
    text = re.sub(r"\n{3,}", "\n\n", text)
    return _collapse_self_referential_links(text.strip())
