"""Unified terminal input — cross-platform key reading for interactive UIs.

Replaces duplicate implementations in init.py, mcp_setup.py, and auth.py.
Supports Windows (msvcrt) and Unix/macOS (termios).
"""

from __future__ import annotations

import sys


def is_tty() -> bool:
    """Return True if both stdin and stdout are real terminals."""
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def stdin_is_tty() -> bool:
    """Return True if stdin is a real terminal (can read keys)."""
    try:
        return sys.stdin.isatty()
    except Exception:
        return False


# ── Key names returned by read_key_* ────────────────────────────────────────
# "up", "down", "left", "right", "enter", "esc", "space", "tab",
# or the literal character (e.g. "a", "q", "1").


def read_key_blocking() -> str:
    """Read a single keypress (blocks until a key is pressed).

    Returns a named key string: ``"up"``, ``"down"``, ``"enter"``,
    ``"esc"``, ``"space"``, or the literal character.
    Raises ``KeyboardInterrupt`` on Ctrl+C.
    Raises ``EOFError`` if stdin is not a TTY.
    """
    if not stdin_is_tty():
        raise EOFError("stdin is not a TTY")
    if sys.platform == "win32":
        return _win32_read(blocking=True)  # type: ignore[return-value]
    return _unix_read(blocking=True)  # type: ignore[return-value]


def read_key_nonblocking() -> str | None:
    """Check for a keypress without blocking.

    Returns ``None`` if no input is ready or stdin is not a TTY;
    otherwise same as ``read_key_blocking()``.
    """
    if not stdin_is_tty():
        return None
    if sys.platform == "win32":
        return _win32_read(blocking=False)
    return _unix_read(blocking=False)


# ── Platform implementations ────────────────────────────────────────────────


def _win32_read(*, blocking: bool) -> str | None:  # type: ignore[return-value]
    """Windows key reading via msvcrt."""
    import msvcrt  # type: ignore[import-not-found]  # Windows-only

    if not blocking and not msvcrt.kbhit():  # type: ignore[attr-defined]
        return None

    ch: str = msvcrt.getwch()  # type: ignore[attr-defined]
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch in ("\x00", "\xe0"):
        # Arrow / function key prefix
        ch2: str = msvcrt.getwch()  # type: ignore[attr-defined]
        return {"H": "up", "P": "down", "K": "left", "M": "right"}.get(ch2, "")
    if ch == "\r":
        return "enter"
    if ch == "\x1b":
        return "esc"
    if ch == " ":
        return "space"
    if ch == "\t":
        return "tab"
    return ch


def _parse_unix_key(fd: int) -> str:
    """Translate one keypress from a raw-mode fd into a named key string.

    Assumes the fd is already in raw mode and at least one byte is ready.
    Shared by ``_unix_read`` (manages its own raw mode per call) and the
    persistent raw-mode key reader in ``mcp_setup.py``.

    Raises ``KeyboardInterrupt`` on Ctrl+C.
    """
    import os
    import select

    ch = os.read(fd, 1).decode("utf-8", errors="replace")
    if ch == "\x03":
        raise KeyboardInterrupt
    if ch in ("\r", "\n"):
        return "enter"
    if ch == " ":
        return "space"
    if ch == "\t":
        return "tab"
    if ch == "\x1b":
        # ESC: could be bare ESC or start of arrow sequence (\x1b[A).
        # Terminal emulators write escape sequences atomically, so after
        # \x1b the remaining bytes (e.g. "[A") arrive together.  One
        # select + one os.read is enough — no per-byte polling needed.
        if select.select([fd], [], [], 0.1)[0]:
            buf = os.read(fd, 2).decode("utf-8", errors="replace")
            if len(buf) >= 2 and buf[0] == "[":
                return {"A": "up", "B": "down", "C": "right", "D": "left"}.get(buf[1], "")
            return ""
        return "esc"
    return ch


def _unix_read(*, blocking: bool) -> str | None:
    """Unix/macOS key reading via termios.

    Uses ``os.read`` exclusively (not ``sys.stdin.read``) to avoid
    TextIOWrapper's internal buffer stealing bytes from the fd.
    """
    import select
    import termios  # type: ignore[attr-defined]  # Unix-only
    import tty  # type: ignore[attr-defined]  # Unix-only

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)  # type: ignore[attr-defined]
    try:
        tty.setraw(fd)  # type: ignore[attr-defined]

        if not blocking:
            if not select.select([fd], [], [], 0)[0]:
                return None

        return _parse_unix_key(fd)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)  # type: ignore[attr-defined]
