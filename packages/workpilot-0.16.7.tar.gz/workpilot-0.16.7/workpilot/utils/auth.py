"""Shared Entra ID token acquisition — used by CLI chat, init, and cloud channel."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from loguru import logger
from rich.console import Console


def acquire_entra_token(
    *,
    tenant_id: str,
    client_id: str,
    scopes: str | list[str] | None = None,
    interactive: bool = True,
) -> str | None:
    """Acquire an Entra ID token: silent from cache, then interactive.

    Args:
        scopes: Single scope string, list of scopes, or None (defaults to
                ``api://{client_id}/access_as_user``). The ``api://`` prefix
                is required so Entra matches the scope against the app's
                self-pre-authorization entry; the bare GUID form would
                return ``AADSTS65001`` / InteractionRequired.
        interactive: If True (default), show a Native/Browser menu and
                     perform interactive login when no cache is available.
                     If False, only try silent acquisition.

    Uses the same MSAL cache as CloudChannel so a prior ``workpilot cloud``
    login is reused automatically.

    Returns the access token string, or None on failure.
    """
    import msal

    from workpilot.utils.helpers import get_auth_dir

    if isinstance(scopes, list):
        effective_scopes = scopes
    elif scopes:
        effective_scopes = [scopes]
    else:
        # `api://` prefix is required so Entra matches against the app's
        # pre-authorization table (which stores scopes as full App ID URIs).
        # The bare GUID form falls through to user-consent resolution and
        # returns InteractionRequired even when self-pre-auth is configured.
        effective_scopes = [f"api://{client_id}/access_as_user"]
    auth_dir = get_auth_dir()
    authority = f"https://login.microsoftonline.com/{tenant_id}"

    # 1a. Try broker cache (WAM PRT — no RefreshToken, uses prompt="none")
    bkw = _broker_kwargs()
    if bkw:
        broker_path = auth_dir / f"token_cache_{client_id[:8]}_broker.bin"
        broker_result = _try_silent_broker(client_id, authority, bkw, broker_path, effective_scopes)
        if broker_result:
            return str(broker_result.get("access_token") or broker_result.get("id_token", ""))

    # 1b. Try browser cache (has RefreshToken)
    cache_path = auth_dir / f"token_cache_{client_id[:8]}.bin"
    cache = msal.SerializableTokenCache()
    if cache_path.exists():
        try:
            from workpilot.security.secrets import decrypt_at_rest

            raw = decrypt_at_rest(cache_path.read_bytes())
            if raw:
                cache.deserialize(raw.decode("utf-8"))
        except Exception as exc:
            logger.warning("Corrupted MSAL cache at {} ({}); starting fresh", cache_path, exc)
            cache_path.unlink(missing_ok=True)

    app = msal.PublicClientApplication(client_id, authority=authority, token_cache=cache)

    accounts = app.get_accounts()
    if accounts:
        result = app.acquire_token_silent(effective_scopes, account=accounts[0])
        if result and "access_token" in result:
            logger.debug("Entra token acquired silently (browser cache)")
            _persist_cache(cache, cache_path)
            return str(result["access_token"])

    if not interactive:
        return None

    # 2. Interactive — let user choose Native (WAM) or Browser.
    #    Loop back to menu on failure so user can retry a different method.
    while True:
        choice = prompt_native_or_browser(client_id)
        if choice == "skip":
            return None

        use_wam = choice == "native"
        bkw = _broker_kwargs() if use_wam else {}
        if use_wam and not bkw:
            use_wam = False  # broker not available, fall back

        # Recreate app only when broker kwargs change (WAM needs broker enabled,
        # browser does not). Avoids unnecessary object creation on browser retry.
        if bkw:
            app = msal.PublicClientApplication(
                client_id,
                authority=f"https://login.microsoftonline.com/{tenant_id}",
                token_cache=cache,
                **bkw,
            )

        if use_wam:
            _console.print(
                "  [dim]An OS account picker will appear.\n"
                "  If you don't see it, check behind this terminal window.[/dim]"
            )
        else:
            _console.print(
                "  [dim]Opening browser for sign-in...\n"
                "  Please complete sign-in in the browser, then return here.[/dim]"
            )

        wam_kwargs: dict[str, Any] = {}
        if use_wam:
            wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(app)

        # WAM can use custom scopes here — this function returns a one-shot
        # token (access_token or id_token). The "no refresh_token" WAM
        # limitation only matters for interactive_cloud_login which needs
        # refresh_token for reconnects.
        interactive_scopes = effective_scopes

        logger.debug("Entra ID interactive login required")
        try:
            result = app.acquire_token_interactive(
                interactive_scopes, prompt="select_account", **wam_kwargs
            )

            # WAM failed — auto-fallback to browser (no menu, no user action).
            # Not passing parent_window_handle → MSAL uses browser PKCE.
            if use_wam and result and "error" in result:
                err = result.get("error", "")
                _console.print(
                    f"  [dim]Native sign-in failed ({err}), falling back to browser...[/dim]"
                )
                result = app.acquire_token_interactive(effective_scopes, prompt="select_account")
        except KeyboardInterrupt:
            _console.print("\n  [dim]Sign-in cancelled.[/dim]")
            raise

        token_str = (result.get("access_token") or result.get("id_token")) if result else None
        if token_str and "error" not in (result or {}):
            _persist_cache(cache, cache_path)
            return str(token_str)

        error = (
            result.get("error_description", result.get("error", "unknown"))
            if result
            else "no result"
        )
        _console.print(f"  [red]Sign-in failed:[/red] {error}")
        _console.print("  [dim]Please try again or select Skip.[/dim]")


def _try_silent_broker(
    client_id: str,
    authority: str,
    broker_kwargs: dict[str, Any],
    cache_path: Path,
    scopes: list[str],
) -> dict[str, Any] | None:
    """Try silent token acquisition via WAM broker (PRT-based).

    Broker cache has no RefreshToken — acquire_token_silent cannot refresh.
    Uses acquire_token_interactive(prompt="none") to silently refresh via PRT.

    When *scopes* is non-empty, passes them to the broker so it returns an
    access_token for the requested resource.  When empty, the broker returns
    an id_token only (OIDC behavior, used by CloudChannel).

    Returns the full MSAL result dict, or None on failure.

    .. note:: macOS WAM broker constraint

       On macOS, ``pymsalruntime`` requires ``acquire_token_interactive``
       (even ``prompt="none"``) to execute on the main thread — the SSO
       Extension uses AppKit APIs that are main-thread-only.  When called
       from a thread-pool thread (e.g. ``run_in_executor`` during
       reconnect), this function returns ``None`` early so the caller
       falls through to the browser-cache path.
    """
    import msal

    if not cache_path.exists():
        return None

    # macOS WAM broker requires the main thread for acquire_token_interactive.
    # During reconnect, _acquire_token_sync runs via run_in_executor (thread
    # pool) — broker calls fail with ApiContractViolation.  Skip early and
    # let the caller fall through to the browser-cache silent path.
    if sys.platform == "darwin":
        import threading

        if threading.current_thread() is not threading.main_thread():
            logger.debug("Skipping broker silent refresh (macOS requires main thread)")
            return None
    try:
        from workpilot.security.secrets import decrypt_at_rest

        cache = msal.SerializableTokenCache()
        raw = decrypt_at_rest(cache_path.read_bytes())
        if raw:
            cache.deserialize(raw.decode("utf-8"))

        app = msal.PublicClientApplication(
            client_id, authority=authority, token_cache=cache, **broker_kwargs
        )
        if not app.get_accounts():
            return None

        result = app.acquire_token_interactive(
            scopes=scopes,
            parent_window_handle=_get_foreground_window_handle(app),
            prompt="none",
        )
        if not result or result.get("error"):
            return None
        if not (result.get("access_token") or result.get("id_token")):
            return None
        _persist_cache(cache, cache_path)
        logger.debug("Entra token acquired silently (broker PRT)")
        return dict(result)
    except Exception as exc:
        logger.debug("Broker silent refresh failed: {}", exc)
    return None


def _persist_cache(cache: Any, cache_path: Path) -> None:
    """Write MSAL cache to disk if changed, encrypting at rest."""
    if not (hasattr(cache, "has_state_changed") and cache.has_state_changed):
        return
    from workpilot.security.secrets import encrypt_at_rest, is_encrypted

    plaintext = cache.serialize().encode("utf-8")
    data = encrypt_at_rest(plaintext)
    # Don't overwrite encrypted cache with plaintext if key unavailable
    if data == plaintext and cache_path.exists():
        try:
            if is_encrypted(cache_path.read_bytes()):
                return
        except OSError:
            return  # can't read existing cache — don't risk overwriting
    from workpilot.security.secrets import _atomic_write_file

    _atomic_write_file(cache_path, data)


def _rebuild_browser_app(client_id: str, authority: str, decrypt_fn: Any) -> tuple[Any, Any, Path]:
    """Create a fresh MSAL app + cache for browser PKCE (no broker kwargs).

    Used when WAM broker fails and we fall back to browser.  Returns
    ``(PublicClientApplication, SerializableTokenCache, cache_path)``.
    """
    import msal

    from workpilot.utils.helpers import get_auth_dir

    cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.bin"
    token_cache = msal.SerializableTokenCache()
    if cache_path.exists():
        try:
            raw = decrypt_fn(cache_path.read_bytes())
            if raw:
                token_cache.deserialize(raw.decode("utf-8"))
        except Exception as exc:
            logger.warning("Failed to load browser token cache from {}: {}", cache_path, exc)
    app = msal.PublicClientApplication(client_id, authority=authority, token_cache=token_cache)
    return app, token_cache, cache_path


# ── Broker support ───────────────────────────────────────────────────────────


_broker_cache: dict[str, Any] | None = None


def _broker_kwargs() -> dict[str, Any]:
    """Return MSAL broker kwargs for the current platform, or empty dict.

    Checks that ``pymsalruntime`` is importable (required on all platforms).
    Result is cached after first call.
    """
    global _broker_cache  # noqa: PLW0603
    if _broker_cache is not None:
        return _broker_cache

    try:
        import pymsalruntime  # noqa: F401
    except Exception:
        # ImportError (not installed), OSError (missing native lib),
        # RuntimeError (SSO extension unavailable on macOS CI), etc.
        _broker_cache = {}
        return _broker_cache

    if sys.platform == "win32":
        _broker_cache = {"enable_broker_on_windows": True}
    elif sys.platform == "darwin":
        _broker_cache = {"enable_broker_on_mac": True}
    elif sys.platform == "linux":
        _broker_cache = {"enable_broker_on_linux": True}
    else:
        _broker_cache = {}
    return _broker_cache


def _get_foreground_window_handle(app: Any) -> Any:
    """Get the foreground window handle for WAM broker dialog.

    On Windows: ``GetForegroundWindow()`` (dialog appears on top of current terminal).
    On other platforms: ``app.CONSOLE_WINDOW_HANDLE`` (MSAL default).
    """
    if sys.platform == "win32":
        import ctypes

        return ctypes.windll.user32.GetForegroundWindow()  # type: ignore[attr-defined]
    return app.CONSOLE_WINDOW_HANDLE


# ── Interactive login menu ───────────────────────────────────────────────────

_console = Console()


def _arrow_menu(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
    title: str = "Sign In",
    subtitle: str | None = None,
) -> str:
    """Arrow-key menu shared by all login prompts.

    *options*: list of ``(key, label)`` tuples.
    Returns the ``key`` of the selected option.
    """
    selected = default

    # Hint uses dim + dark gray (very subtle, distinct from options)
    _hint = "\033[2;90m  \u2191\u2193 (Up/Down) switch  \u23ce (Enter) confirm  Esc skip\033[0m"

    def _draw(initial: bool = False) -> None:
        buf: list[str] = []
        if not initial:
            # +1 for the hint line below options
            buf.append(f"\r\033[{len(options) + 1}A")
        for i, (_, label) in enumerate(options):
            marker = ">" if i == selected else " "
            if i == selected:
                buf.append(f"\033[K  \033[1;36m{marker} {label}\033[0m\n")
            else:
                buf.append(f"\033[K  \033[37m{marker} {label}\033[0m\n")
        buf.append(f"\033[K{_hint}\n")
        sys.stdout.write("".join(buf))
        sys.stdout.flush()

    header = f"[bold]{title}[/bold]"
    if subtitle:
        header += f"\n{subtitle}"
    _console.print(f"  {header}")

    from workpilot.utils.input import is_tty, read_key_blocking

    if not is_tty():
        # Non-interactive (CI, piped stdin) → auto-select last option (Skip)
        # to avoid triggering interactive MSAL flows that would hang.
        selected = len(options) - 1
        _console.print(f"  [dim](non-interactive: defaulting to {options[selected][1]})[/dim]")
        return options[selected][0]

    sys.stdout.write("\033[?25l")  # hide cursor
    _draw(initial=True)

    try:
        while True:
            key = read_key_blocking()
            if key == "enter":
                break
            if key == "esc":
                selected = len(options) - 1
                break
            if key == "up":
                selected = (selected - 1) % len(options)
                _draw()
            elif key == "down":
                selected = (selected + 1) % len(options)
                _draw()
    except (EOFError, KeyboardInterrupt, OSError):
        selected = len(options) - 1
    finally:
        sys.stdout.write("\033[?25h")  # show cursor
        sys.stdout.flush()

    return options[selected][0]


def prompt_native_or_browser(client_id: str = "") -> str:
    """Show a simple Native / Browser / Skip menu.

    Returns one of: ``"native"``, ``"browser"``, ``"skip"``.
    Hides Native option when broker is not available.
    """
    has_broker = bool(_broker_kwargs())
    if has_broker:
        options: list[tuple[str, str]] = [
            ("native", "OS account picker"),
            ("browser", "Browser sign-in"),
            ("skip", "Skip for now"),
        ]
        default = 0
    else:
        options = [
            ("browser", "Browser sign-in"),
            ("skip", "Skip for now"),
        ]
        default = 0
    return _arrow_menu(
        options,
        default=default,
        title="Microsoft sign-in",
        subtitle="[dim]Sign in with your work account.\n"
        "  Credentials are encrypted locally and never uploaded."
        " Run 'wp secrets list' to manage.[/dim]",
    )


def prompt_login_method(*, has_primary_account: bool = False) -> str:
    """Show a login method menu and return the user's choice.

    Returns one of: ``"native_primary"``, ``"browser_primary"``,
    ``"native_compat"``, ``"browser_compat"``, ``"skip"``.
    WAM broker uses PRT for silent refresh (scopes=["openid"]).
    Browser PKCE uses refresh_token (scopes=[client_id/.default]).
    """
    has_broker = bool(_broker_kwargs())
    # "OS account picker (WorkPilot app)" is the forward-looking path; tag it
    # recommended but keep first-time default on Compatible until rollout is
    # validated (has_primary_account flips the default once the user has
    # signed in successfully with the primary app).
    if has_broker:
        options: list[tuple[str, str]] = [
            ("native_primary", "OS account picker (WorkPilot app) \u2014 recommended"),
            ("browser_primary", "Browser sign-in (WorkPilot app)"),
            ("native_compat", "OS account picker (Compatible)"),
            ("browser_compat", "Browser sign-in (Compatible)"),
            ("skip", "Skip for now"),
        ]
        default = 0 if has_primary_account else 2
    else:
        options = [
            ("browser_primary", "Browser sign-in (WorkPilot app)"),
            ("browser_compat", "Browser sign-in (Compatible)"),
            ("skip", "Skip for now"),
        ]
        default = 0 if has_primary_account else 1
    from rich.panel import Panel

    _console.print(
        Panel(
            "[bold]Choose how to sign in with your work account.[/bold]\n\n"
            "[dim]Credentials are encrypted locally and never uploaded.\n"
            "Run [cyan]wp secrets list[/cyan] to manage.[/dim]",
            title="Cloud Sign-in",
            border_style="cyan",
        )
    )
    return _arrow_menu(options, default=default)


def interactive_cloud_login(
    *,
    tenant_id: str,
    client_id: str,
    scope: str,
    login_port: int = 49215,
    has_primary_account: bool = False,
) -> str:
    """Show the login menu, authenticate, persist cache. Return token (id_token or access_token).

    Standalone function — no CloudChannel or MessageBus required.
    Used by ``workpilot init`` and ``CloudChannel._execute_login_choice``.
    Raises ``RuntimeError`` when the user selects *Skip*.
    """
    import socket

    import msal

    from workpilot.mcp.defaults import SHARED_ENTRA_CLIENT_ID
    from workpilot.utils.helpers import get_auth_dir

    success_template = (
        "<!DOCTYPE html><html><head><title>WorkPilot</title></head>"
        "<body>Sign-in successful - you can close this tab.</body></html>"
    )

    while True:
        choice = prompt_login_method(has_primary_account=has_primary_account)
        if choice == "skip":
            raise RuntimeError("Cloud sign-in skipped")

        # Determine effective app based on choice.
        use_shared = choice.endswith("_compat")
        use_wam = choice.startswith("native_")

        # Hint: tell the user what to expect.
        if use_wam:
            _console.print(
                "  [dim]An OS account picker will appear.\n"
                "  If you don't see it, check behind this terminal window.[/dim]"
            )
        else:
            _console.print(
                "  [dim]Opening browser for sign-in...\n"
                "  Please complete sign-in in the browser, then return here.[/dim]"
            )

        if use_shared:
            eff_client_id = SHARED_ENTRA_CLIENT_ID
            # Use the primary app's scope — pre-authorized for the shared app.
            # This ensures access_token audience matches the Gateway expectation.
            eff_scope = scope
            authority = "https://login.microsoftonline.com/organizations"
        else:
            eff_client_id = client_id
            eff_scope = scope
            authority = f"https://login.microsoftonline.com/{tenant_id}"

        # Check broker availability before deciding cache path.
        bkw = _broker_kwargs() if use_wam else {}
        if use_wam and not bkw:
            use_wam = False

        # Load token cache — broker and browser use separate files so they
        # don't interfere (broker has no refresh_token, browser does).
        suffix = "_broker" if use_wam else ""
        cache_path = get_auth_dir() / f"token_cache_{eff_client_id[:8]}{suffix}.bin"
        token_cache = msal.SerializableTokenCache()
        from workpilot.security.secrets import decrypt_at_rest

        if cache_path.exists():
            try:
                raw = decrypt_at_rest(cache_path.read_bytes())
                if raw:
                    token_cache.deserialize(raw.decode("utf-8"))
            except Exception as exc:
                logger.warning("Corrupted MSAL cache at {} ({}); starting fresh", cache_path, exc)

        app = msal.PublicClientApplication(
            eff_client_id,
            authority=authority,
            token_cache=token_cache,
            **bkw,
        )

        # Acquire token interactively.
        wam_kwargs: dict[str, Any] = {}
        if use_wam:
            wam_kwargs["parent_window_handle"] = _get_foreground_window_handle(app)

        port = login_port
        for candidate in (login_port, 52813, 58729, 0):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind(("localhost", candidate))
                    port = s.getsockname()[1]
                    break
                except OSError:
                    continue

        # WAM: empty scopes → broker uses OIDC defaults, returns id_token.
        # Browser: needs actual scope so access_token audience matches the app
        # (empty scopes → Graph token → Gateway rejects with 401).
        interactive_scopes = [] if use_wam else [eff_scope]

        # No explicit timeout — user can Ctrl+C if MSAL blocks (e.g. admin
        # consent page). The retry loop will re-show the menu.
        try:
            result = app.acquire_token_interactive(
                scopes=interactive_scopes,
                prompt="select_account",
                port=port,
                success_template=success_template,
                **wam_kwargs,
            )

            # WAM failed — retry with plain browser.
            # Rebuild MSAL app + cache without broker kwargs so the
            # refresh_token is persisted to the correct browser cache file.
            if use_wam and result and "error" in result:
                err = result.get("error", "")
                _console.print(
                    f"  [dim]Native sign-in failed ({err}), falling back to browser...[/dim]"
                )
                use_wam = False
                app, token_cache, cache_path = _rebuild_browser_app(
                    eff_client_id, authority, decrypt_at_rest
                )
                result = app.acquire_token_interactive(
                    scopes=[eff_scope],
                    prompt="select_account",
                    port=port,
                    success_template=success_template,
                )
        except KeyboardInterrupt:
            _console.print("\n  [dim]Sign-in cancelled.[/dim]")
            raise
        except Exception as wam_exc:
            # WAM broker may raise (not just return error) on macOS when
            # called from a non-main thread (e.g. run_in_executor during
            # reconnect).  Fall back to browser PKCE (see above).
            if not use_wam:
                raise
            logger.debug("WAM broker raised {}, falling back to browser", wam_exc)
            _console.print(
                f"  [dim]Native sign-in failed ({wam_exc}), falling back to browser...[/dim]"
            )
            use_wam = False
            app, token_cache, cache_path = _rebuild_browser_app(
                eff_client_id, authority, decrypt_at_rest
            )
            result = app.acquire_token_interactive(
                scopes=[eff_scope],
                prompt="select_account",
                port=port,
                success_template=success_template,
            )

        # WAM with empty scopes returns access_token for Graph (wrong audience).
        # Use id_token for WAM (aud=client_id), access_token for browser.
        if use_wam:
            token_str = result.get("id_token") or result.get("access_token")
        else:
            token_str = result.get("access_token") or result.get("id_token")
        if "error" not in result and token_str:
            # Success.
            claims = result.get("id_token_claims", {})
            name = claims.get("name") or claims.get("preferred_username", "unknown")
            oid = claims.get("oid", "unknown")
            _console.print(
                f"  [green]\u2713[/green] Authenticated as [bold]{name}[/bold] [dim](oid={oid})[/dim]"
            )
            logger.success("Authenticated as: {} (oid={})", name, oid)
            _persist_cache(token_cache, cache_path)
            return str(token_str)

        # Failed — show error and loop back to menu.
        if "error" in result:
            error = result.get("error_description", result["error"])
        else:
            error = "no token returned"
        _console.print(f"  [red]Sign-in failed:[/red] {error}")
        _console.print("  [dim]Please try again or select Skip.[/dim]")
