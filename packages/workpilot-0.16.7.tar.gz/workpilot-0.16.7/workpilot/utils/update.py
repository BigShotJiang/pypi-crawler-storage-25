"""Shared update-check logic — used by heartbeat tool and CLI.

Supports three install modes:
  - git   (editable install from a git clone)
  - uv    (installed via ``uv tool install workpilot``)
  - pypi  (plain ``pip install workpilot``)
"""

from __future__ import annotations

import re
import site
import subprocess
import sys
import sysconfig
from dataclasses import dataclass
from pathlib import Path

from workpilot import __version__

# Entry-point names defined in pyproject.toml [project.scripts]
ENTRY_POINTS = ("workpilot", "wp")


@dataclass
class UpdateStatus:
    """Result of an update check."""

    up_to_date: bool
    current: str = __version__
    latest: str | None = None
    commit_count: int = 0
    commit_log: str = ""  # oneline summaries (git only)
    install_mode: str = "unknown"  # "git" | "uv" | "pypi"
    error: str | None = None

    @property
    def summary(self) -> str:
        if self.error:
            return f"Update check failed: {self.error}"
        if self.up_to_date:
            if self.install_mode == "git":
                return f"WorkPilot v{self.current} is up to date (git)."
            mode = " (uv)" if self.install_mode == "uv" else ""
            return (
                f"WorkPilot v{self.current} is up to date{mode}"
                f" (latest: v{self.latest or self.current})."
            )
        if self.install_mode == "git":
            msg = f"WorkPilot update available: {self.commit_count} new commit(s).\nCurrent: v{self.current}"
            if self.commit_log:
                msg += f"\nLatest commits:\n{self.commit_log}"
            return msg + "\nRun `workpilot update` to install."
        return (
            f"WorkPilot update available: v{self.current} -> v{self.latest}\n"
            f"Run `workpilot update` to install, "
            f"or re-run the install script:\n  {install_script_cmd()}"
        )


def is_git_install() -> Path | None:
    """Return repo root if editable git install, else None."""
    repo_root = Path(__file__).resolve().parent.parent.parent
    return repo_root if (repo_root / ".git").exists() else None


def is_uv_install() -> bool:
    """Return True if the *currently running* workpilot was installed via ``uv tool``."""
    out = _run(["uv", "tool", "list"])
    if out is None:
        return False
    if not any(line.startswith("workpilot ") for line in out.splitlines()):
        return False
    # Confirm this process is actually running from the uv tool environment,
    # not a co-existing pip install.
    tool_dir = _run(["uv", "tool", "dir"])
    if not tool_dir:
        return False
    try:
        uv_root = Path(tool_dir.strip()).resolve()
        return Path(__file__).resolve().is_relative_to(uv_root)
    except (OSError, ValueError):
        return False


def scripts_dirs() -> list[Path]:
    """Return candidate scripts directories, ordered by priority.

    Order: current interpreter → user-level → nt_user → uv bin.
    The current interpreter's scripts dir comes first so that venv/conda
    environments are preferred over user installs; for a non-venv
    interpreter, it may also be the system-level scripts directory.
    """
    candidates: list[Path] = []

    def _add(p: Path) -> None:
        if p not in candidates:
            candidates.append(p)

    # 0. Current interpreter's scripts dir (venv / conda / system)
    try:
        _add(Path(sysconfig.get_path("scripts")))
    except Exception:
        pass

    # 1. User-level scripts (covers Microsoft Store Python + --user installs)
    try:
        _add(Path(site.getusersitepackages()).parent / "Scripts")
    except Exception:
        pass

    # 2. nt_user scheme (another way to get user scripts)
    try:
        _add(Path(sysconfig.get_path("scripts", "nt_user")))
    except Exception:
        pass

    # 3. uv tool bin directory
    uv_bin = _run(["uv", "tool", "dir", "--bin"])
    if uv_bin:
        _add(Path(uv_bin.strip()))

    return candidates


def find_entry_point_exes(scripts_dir: Path | None = None) -> list[Path]:
    """Find WorkPilot entry-point executables.

    When *scripts_dir* is given, only that directory is searched (use this
    when renaming/mutating to avoid touching exes from a different install).
    When omitted, all candidate directories are searched (safe for read-only
    operations like cleanup).
    """
    if sys.platform != "win32":
        return []

    dirs = [scripts_dir] if scripts_dir else scripts_dirs()
    found: list[Path] = []
    for d in dirs:
        for name in ENTRY_POINTS:
            exe = d / f"{name}.exe"
            if exe.exists():
                found.append(exe)
    return found


def pip_scripts_dir() -> Path | None:
    """Return the scripts directory for the current pip install, or None.

    Prefers the current interpreter's scripts dir (correct for venv/conda),
    falls back to user-level paths (MS Store Python). Excludes the uv tool
    bin directory to avoid picking a co-existing uv install.
    """
    if sys.platform != "win32":
        return None
    uv_dir = uv_bin_dir()
    for d in scripts_dirs():
        if uv_dir and d == uv_dir:
            continue
        if find_entry_point_exes(scripts_dir=d):
            return d
    return None


def uv_bin_dir() -> Path | None:
    """Return the uv tool bin directory, or None."""
    out = _run(["uv", "tool", "dir", "--bin"])
    return Path(out.strip()) if out else None


def parse_version(v: str) -> tuple[int, ...]:
    """Parse version string to comparable tuple (e.g. '0.7.0' -> (0, 7, 0))."""
    return tuple(int(x) for x in re.findall(r"\d+", v))


def get_uv_installed_version() -> str | None:
    """Return the installed workpilot version from ``uv tool list``, or None."""
    out = _run(["uv", "tool", "list"])
    if out is None:
        return None
    for line in out.splitlines():
        if line.startswith("workpilot "):
            parts = line.split()
            if len(parts) >= 2:
                return parts[1].removeprefix("v")
    return None


def get_pip_installed_version() -> str | None:
    """Return the installed workpilot version from ``pip show``, or None."""
    out = _run([sys.executable, "-m", "pip", "show", "workpilot"])
    if out is None:
        return None
    for line in out.splitlines():
        if line.startswith("Version:"):
            return line.split(":", 1)[1].strip()
    return None


def install_script_cmd() -> str:
    """Return the one-liner to re-run the platform installer."""
    if sys.platform == "win32":
        return "irm https://aka.ms/workpilot/install.ps1 | iex"
    return "curl -fsSL https://aka.ms/workpilot/install.sh | bash"


def _uv_tool_venv_python() -> Path | None:
    """Resolve the python.exe inside uv's tool venv for workpilot."""
    out = _run(["uv", "tool", "dir"])
    if not out:
        return None
    root = Path(out.strip()) / "workpilot"
    if sys.platform == "win32":
        candidates = [root / "Scripts" / "python.exe", root / "python.exe"]
    else:
        candidates = [root / "bin" / "python", root / "bin" / "python3"]
    for p in candidates:
        if p.exists():
            return p
    return None


def probe_via_venv() -> str | None:
    """Return workpilot's ``__version__`` as reported by the uv tool venv, or None.

    Bypasses the wp.exe / workpilot.exe shim entirely. If this returns a value,
    the venv has an intact workpilot package whose `__file__` lives *inside*
    the venv (not from a fallback like the base Python's site-packages, a
    developer's editable install, or the user's site).

    Returns None when:
      - uv is not on PATH / ``uv tool dir`` fails
      - the venv python does not exist
      - ``import workpilot`` fails
      - workpilot imported but from outside the venv (e.g. corrupted site-
        packages caused Python to fall back to base interpreter's modules)
    """
    py = _uv_tool_venv_python()
    if not py:
        return None
    try:
        r = subprocess.run(
            [
                str(py),
                "-c",
                # Emit version + __file__ separated by a pipe so we can verify
                # the module actually lives in the venv before trusting the version.
                "import workpilot,os,sys;"
                "sys.stdout.write(workpilot.__version__+'|'+os.path.abspath(workpilot.__file__))",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15,
        )
        if r.returncode != 0:
            return None
        out = (r.stdout or "").strip()
        if "|" not in out:
            return None
        version, wp_path = out.split("|", 1)
        if not version:
            return None
        # Verify the import came from the venv, not a base-Python fallback.
        # ``py.parent.parent`` == venv root (e.g. .../tools/workpilot/).
        venv_root = py.parent.parent
        try:
            Path(wp_path).resolve().relative_to(venv_root.resolve())
        except (OSError, ValueError):
            return None
        return version
    except Exception:
        return None


def find_exe_holders() -> list[tuple[int, str]]:
    """List processes currently holding wp.exe / workpilot.exe open (Windows only).

    Uses Windows RestartManager (rstrtmgr.dll) — same API used by Windows Installer.
    Returns ``[(pid, app_name), ...]``; empty list on non-Windows, API failure,
    or when no holders are found.
    """
    if sys.platform != "win32":
        return []
    exes = [str(p) for p in find_entry_point_exes()]
    if not exes:
        return []
    try:
        import ctypes
        from ctypes import wintypes

        rm = ctypes.windll.rstrtmgr  # type: ignore[attr-defined]
        session = wintypes.DWORD(0)
        key = ctypes.create_unicode_buffer(256)
        if rm.RmStartSession(ctypes.byref(session), 0, key) != 0:
            return []
        try:
            arr = (ctypes.c_wchar_p * len(exes))(*exes)
            if rm.RmRegisterResources(session, len(exes), arr, 0, None, 0, None) != 0:
                return []

            # Win32 RestartManager API struct names — kept verbatim from rstrtmgr.h
            # so the ctypes mapping stays obvious to anyone checking the docs.
            class RM_UNIQUE_PROCESS(ctypes.Structure):  # noqa: N801
                _fields_ = [
                    ("dwProcessId", wintypes.DWORD),
                    ("ProcessStartTime", wintypes.FILETIME),
                ]

            class RM_PROCESS_INFO(ctypes.Structure):  # noqa: N801
                _fields_ = [
                    ("Process", RM_UNIQUE_PROCESS),
                    ("strAppName", ctypes.c_wchar * 256),
                    ("strServiceShortName", ctypes.c_wchar * 64),
                    ("ApplicationType", ctypes.c_int),
                    ("AppStatus", wintypes.ULONG),
                    ("TSSessionId", wintypes.DWORD),
                    ("bRestartable", wintypes.BOOL),
                ]

            # Two-pass: ask with a 16-slot buffer; if RmGetList returns
            # ERROR_MORE_DATA (234), re-allocate to the size the API reported
            # in ``needed`` and retry. Skipping the rc check can leak
            # uninitialised entries from ``procs`` on truncation.
            ERROR_SUCCESS = 0
            ERROR_MORE_DATA = 234

            needed = wintypes.UINT(0)
            count = wintypes.UINT(16)
            procs: ctypes.Array = (RM_PROCESS_INFO * 16)()
            reasons = wintypes.DWORD(0)
            rc = rm.RmGetList(
                session,
                ctypes.byref(needed),
                ctypes.byref(count),
                procs,
                ctypes.byref(reasons),
            )
            if rc == ERROR_MORE_DATA and needed.value > 16:
                count = wintypes.UINT(needed.value)
                procs = (RM_PROCESS_INFO * needed.value)()
                rc = rm.RmGetList(
                    session,
                    ctypes.byref(needed),
                    ctypes.byref(count),
                    procs,
                    ctypes.byref(reasons),
                )
            if rc != ERROR_SUCCESS:
                return []
            return [
                (int(procs[i].Process.dwProcessId), str(procs[i].strAppName))
                for i in range(count.value)
            ]
        finally:
            rm.RmEndSession(session)
    except Exception:
        return []


def check_git(repo: Path) -> UpdateStatus:
    """Fetch and compare with upstream. Does NOT pull."""
    if _run(["git", "fetch"], cwd=repo) is None:
        return UpdateStatus(up_to_date=False, install_mode="git", error="git fetch failed")

    local = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    remote = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if not local or not remote:
        return UpdateStatus(
            up_to_date=False, install_mode="git", error="could not compare local/remote"
        )

    if local == remote:
        return UpdateStatus(up_to_date=True, install_mode="git")

    # Detect ahead/behind/diverged
    lr_out = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    behind = 0
    if lr_out:
        parts = lr_out.split()
        if len(parts) == 2:
            behind = int(parts[1])

    if behind == 0:
        # Ahead only or diverged with no upstream commits — no update available
        return UpdateStatus(up_to_date=True, install_mode="git")

    log_out = _run(["git", "log", "--oneline", "-5", f"{local}..{remote}"], cwd=repo) or ""

    return UpdateStatus(
        up_to_date=False,
        install_mode="git",
        commit_count=behind,
        commit_log=log_out,
    )


def _check_pypi_version(mode: str) -> UpdateStatus:
    """Check PyPI for a newer version (shared by pip and uv paths)."""
    latest = _fetch_pypi_version()
    if latest is None:
        return UpdateStatus(
            up_to_date=False, install_mode=mode, error="could not determine latest version"
        )

    if parse_version(__version__) >= parse_version(latest):
        return UpdateStatus(up_to_date=True, install_mode=mode, latest=latest)

    return UpdateStatus(up_to_date=False, install_mode=mode, latest=latest)


def check_pypi() -> UpdateStatus:
    """Check PyPI for a newer version (pip install mode)."""
    return _check_pypi_version("pypi")


def check_uv() -> UpdateStatus:
    """Check PyPI for a newer version (uv tool install mode)."""
    return _check_pypi_version("uv")


def check_update() -> UpdateStatus:
    """Auto-detect install mode and check for updates.

    Detection order: git (editable) → uv tool → pip (PyPI).
    Writes ``~/.workpilot/.last_update_check`` on success so heartbeat
    pre-flight and startup check share the same throttle marker.
    """
    repo = is_git_install()
    if repo:
        status = check_git(repo)
    elif is_uv_install():
        status = check_uv()
    else:
        status = check_pypi()

    if not status.error:
        _touch_marker()

    return status


def _touch_marker() -> None:
    """Update the shared throttle marker file."""
    import time

    try:
        from workpilot.utils.helpers import get_data_dir

        marker = get_data_dir() / ".last_update_check"
        marker.write_text(str(int(time.time())), encoding="utf-8")
    except OSError:
        pass


# ── Internal helpers ─────────────────────────────────────────────────────────


def _run(cmd: list[str], cwd: Path | None = None, timeout: int = 30) -> str | None:
    """Run a command, return stdout or None on failure."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:
        return None


def _fetch_pypi_version() -> str | None:
    """Get latest version from PyPI (httpx -> pip fallback)."""
    try:
        import httpx

        resp = httpx.get("https://pypi.org/pypi/workpilot/json", timeout=10)
        resp.raise_for_status()
        return str(resp.json()["info"]["version"])
    except Exception:
        pass
    out = _run([sys.executable, "-m", "pip", "index", "versions", "workpilot"], timeout=30)
    if out:
        m = re.search(r"\(([^)]+)\)", out.splitlines()[0])
        return m.group(1).split(",")[0].strip() if m else None
    return None
