"""Shared token-limit error detection and parsing utilities.

Used by the agent loop (emergency compaction), the LLM provider (fallback
decisions), and tool output compression (overflow recovery).
"""

from __future__ import annotations

import re

# Known error patterns indicating context-length-exceeded
TOKEN_LIMIT_PATTERNS: tuple[str, ...] = (
    "context_length_exceeded",
    "maximum context length",
    "too many tokens",
    "context window",
    "token limit",
    "prompt token count",
    "max_prompt_tokens_exceeded",
)

# Regex patterns for extracting (actual_tokens, limit_tokens) from error msgs.
# Example: "prompt token count of 274790 exceeds the limit of 272000"
# Example: "maximum context length is 128000 tokens. However, your messages resulted in 130542 tokens"
_OVERFLOW_PATTERNS: tuple[re.Pattern[str], ...] = (
    # "count of N exceeds the limit of M"
    re.compile(r"count\s+of\s+([\d,]+)\s.*?limit\s+of\s+([\d,]+)", re.IGNORECASE),
    # "resulted in N tokens ... maximum ... is M"
    re.compile(
        r"resulted\s+in\s+([\d,]+)\s+tokens.*?(?:maximum|limit)[^\d]*([\d,]+)",
        re.IGNORECASE | re.DOTALL,
    ),
    # "maximum context length is M ... N tokens" (limit first, actual second)
    re.compile(
        r"maximum\s+context\s+length\s+is\s+([\d,]+).*?([\d,]+)\s+tokens",
        re.IGNORECASE | re.DOTALL,
    ),
)


def is_token_limit_error(exc: Exception) -> bool:
    """Check if an exception is a context-length-exceeded error."""
    msg = str(exc).lower()
    return any(p in msg for p in TOKEN_LIMIT_PATTERNS)


def parse_token_overflow(exc: Exception) -> tuple[int, int] | None:
    """Extract (actual_tokens, limit_tokens) from a token-limit error.

    Returns ``None`` if the exception is not a token-limit error or the
    numbers cannot be parsed.
    """
    if not is_token_limit_error(exc):
        return None

    text = str(exc)

    # Try each pattern in order
    for i, pat in enumerate(_OVERFLOW_PATTERNS):
        m = pat.search(text)
        if m:
            a = int(m.group(1).replace(",", ""))
            b = int(m.group(2).replace(",", ""))
            if i == 2:
                # Pattern 3 captures (limit, actual) — swap
                a, b = b, a
            # Sanity: actual should exceed limit
            if a > b:
                return a, b
            # Maybe reversed — try the other order
            if b > a:
                return b, a

    return None
