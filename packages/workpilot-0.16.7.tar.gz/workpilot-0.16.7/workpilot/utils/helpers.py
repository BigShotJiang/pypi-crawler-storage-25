"""Common utilities."""

from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse, urlunparse


def ensure_dir(path: Path) -> Path:
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        from loguru import logger

        logger.warning("Cannot create directory {}: {}", path, exc)
    return path


def ensure_private_dir(path: Path) -> Path:
    """Create a directory restricted to the current user, SYSTEM, and Administrators.

    - **Windows**: removes inherited ACEs via ``icacls /inheritance:r``, then
      grants Full Control to the current user, SYSTEM, and Administrators.
      Logs a warning if ``icacls`` fails (directory may remain accessible).
    - **POSIX**: ``chmod 0o700`` (owner rwx, no access for group/others).
    """
    from loguru import logger

    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.warning("Cannot create private directory {}: {}", path, exc)
        return path  # return early — no point setting ACL on a missing dir
    if sys.platform == "win32":
        import getpass

        username = os.environ.get("USERNAME", "") or getpass.getuser()
        if username:
            # Detect already-qualified names (DOMAIN\user or user@domain)
            if "\\" in username or "@" in username:
                qualified = username
            else:
                domain = os.environ.get("USERDOMAIN", "")
                qualified = f"{domain}\\{username}" if domain else username
            try:
                # Reset ACL to a known state: remove all explicit + inherited ACEs,
                # then grant only the intended principals.
                reset = subprocess.run(
                    [
                        "icacls",
                        str(path),
                        "/reset",
                        "/t",
                        "/q",
                    ],
                    capture_output=True,
                    timeout=10,
                )
                if reset.returncode != 0:
                    stderr = reset.stderr.decode(errors="replace").strip()
                    logger.warning(
                        "icacls /reset failed for {} (rc={}): {}",
                        path,
                        reset.returncode,
                        stderr,
                    )
                result = subprocess.run(
                    [
                        "icacls",
                        str(path),
                        "/inheritance:r",
                        "/grant:r",
                        f"{qualified}:(OI)(CI)F",
                        "/grant:r",
                        "SYSTEM:(OI)(CI)F",
                        "/grant:r",
                        "BUILTIN\\Administrators:(OI)(CI)F",
                    ],
                    capture_output=True,
                    timeout=10,
                )
                if result.returncode != 0:
                    stderr = result.stderr.decode(errors="replace").strip()
                    logger.warning(
                        "icacls failed for {} (rc={}): {}",
                        path,
                        result.returncode,
                        stderr,
                    )
            except (OSError, subprocess.TimeoutExpired) as exc:
                logger.warning("Failed to set ACL on {}: {}", path, exc)
        else:
            logger.warning("Cannot determine Windows username — ACL not set for {}", path)
    else:
        try:
            path.chmod(0o700)
        except OSError as exc:
            logger.warning("chmod 0o700 failed for {}: {}", path, exc)
    return path


def get_data_dir() -> Path:
    """Default data directory: ~/.workpilot/"""
    return ensure_dir(Path.home() / ".workpilot")


def get_auth_dir() -> Path:
    """Private auth directory: ~/.workpilot/auth/ (restricted to current user)."""
    return ensure_private_dir(get_data_dir() / "auth")


def get_sessions_dir() -> Path:
    return ensure_dir(get_data_dir() / "sessions")


def get_skills_dir() -> Path:
    return ensure_dir(get_data_dir() / "skills")


def webchat_url_from_connect(connect_url: str) -> str:
    """Derive the web-chat URL from a WorkPilot cloud connect URL.

    wss://host/connect  →  https://host/chat
    ws://host/connect   →  http://host/chat

    Raises ValueError for unexpected schemes so callers can handle
    misconfiguration rather than silently propagating an invalid URL.
    """
    parsed = urlparse(connect_url)
    scheme_map = {"wss": "https", "ws": "http"}
    if parsed.scheme not in scheme_map:
        raise ValueError(
            f"webchat_url_from_connect: expected ws:// or wss:// URL, got {connect_url!r}"
        )
    http_scheme = scheme_map[parsed.scheme]
    path = re.sub(r"/connect$", "/chat", parsed.path) if parsed.path else "/chat"
    return urlunparse((http_scheme, parsed.netloc, path, "", "", ""))


def teams_bot_url(bot_app_id: str) -> str:
    """Build the Teams direct-chat URL from a bot app ID."""
    if not bot_app_id:
        return ""
    return f"https://teams.microsoft.com/l/chat/0/0?users=28:{bot_app_id}"


def local_web_url(host: str, port: int) -> str:
    """Build a navigable URL for the local self-hosted gateway.

    - Bind-all addresses (``0.0.0.0``, ``::``, empty) → ``localhost`` (those
      aren't navigable from a browser).
    - Pre-bracketed IPv6 input (``[::1]``) is unwrapped first so we don't
      double-bracket.
    - IPv6 literals are bracketed per RFC 3986 (``http://[::1]:3003``).
    - Zone identifiers (``fe80::1%en0``) have ``%`` percent-encoded to
      ``%25`` — required for RFC 6874 URL syntax.
    """
    host = host.strip()
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    if host in ("0.0.0.0", "::", ""):
        host = "localhost"
    if ":" in host:
        host = host.replace("%", "%25")
        host = f"[{host}]"
    return f"http://{host}:{port}"
