from __future__ import annotations

import array
import logging

import numpy as np

from ...config import (
    OPENAI_EMBEDDING_DIMENSIONS,
    OPENAI_EMBEDDING_MODEL,
    OPENAI_EMBEDDINGS_ENABLED,
)
from ._constants import FASTEMBED_CACHE_DIR
from ._cuda import _cuda_provider_is_available
from ._model import (
    FASTEMBED_MODEL,
    _get_model,
    warmup,
)
from ._openai import OpenAIEmbeddingDimensionError
from ._openai import embed_texts as _openai_embed_texts
from ._openai import get_embedding_dim as _openai_get_embedding_dim
from ._registry import _register_custom_model

logger = logging.getLogger(__name__)


def _numpy_to_array(embedding: np.ndarray) -> array.array[float]:
    if embedding.dtype != np.float32:
        embedding = embedding.astype(np.float32, copy=False)
    result = array.array("f")
    result.frombytes(embedding.tobytes())
    return result


def embed(text: str) -> array.array[float] | None:
    """Generate embedding, truncated to 8000 chars."""
    try:
        if OPENAI_EMBEDDINGS_ENABLED:
            return _openai_embed_texts([text])[0]

        model = _get_model()

        truncated = text[:8000]

        embeddings = list(model.embed([truncated]))
        if embeddings:
            return _numpy_to_array(embeddings[0])
        return None

    except OpenAIEmbeddingDimensionError:
        raise
    except Exception as e:
        logger.warning(f"Embedding failed: {e}")
        return None


def embed_batch(texts: list[str]) -> list[array.array[float] | None]:
    """Embed N texts in one model call.

    Amortizes ONNX Runtime overhead — critical for batch_smart_read where N files
    need embedding on first cache miss. Returns same-length list; None on failure.
    """
    if not texts:
        return []
    try:
        if OPENAI_EMBEDDINGS_ENABLED:
            return _openai_embed_texts(texts)

        model = _get_model()
        truncated = [t[:8000] for t in texts]
        results = list(model.embed(truncated))
        out: list[array.array[float] | None] = []
        for r in results:
            out.append(_numpy_to_array(r))
        return out
    except OpenAIEmbeddingDimensionError:
        raise
    except Exception as e:
        logger.warning(f"Batch embedding failed: {e}")
        return [None] * len(texts)


def embed_query(text: str) -> array.array[float] | None:
    """Embed a search query with the bge retrieval prefix."""
    try:
        if OPENAI_EMBEDDINGS_ENABLED:
            return _openai_embed_texts([text])[0]

        model = _get_model()

        # Official bge query instruction for retrieval tasks
        prefixed = f"Represent this sentence for searching relevant passages: {text[:8000]}"

        embeddings = list(model.embed([prefixed]))
        if embeddings:
            result = array.array("f")
            result.frombytes(embeddings[0].astype(np.float32).tobytes())
            return result
        return None

    except OpenAIEmbeddingDimensionError:
        raise
    except Exception as e:
        logger.warning(f"Query embedding failed: {e}")
        return None


def get_embedding_dim() -> int:
    """Return embedding dimension for the configured model, even before warmup.

    Priority: runtime dim (set by warmup) > model object attribute >
    fastembed registry > HuggingFace config.json. Never hardcodes a default.
    """
    import semantic_cache_mcp.core.embeddings._model as _m

    if OPENAI_EMBEDDINGS_ENABLED:
        return OPENAI_EMBEDDING_DIMENSIONS or _openai_get_embedding_dim()

    # 1. Already known from warmup
    if _m._embedding_dim > 0:
        return _m._embedding_dim

    # 2. Model object loaded — query its metadata
    if _m._embedding_model is not None:
        size = getattr(_m._embedding_model, "embedding_size", None)
        if size and size > 0:
            return int(size)

    # 3. Check fastembed's built-in model registry (no model loading)
    try:
        from fastembed import TextEmbedding  # noqa: PLC0415

        for info in TextEmbedding.list_supported_models():
            if info.get("model") == FASTEMBED_MODEL:
                dim = info.get("dim")
                if dim and dim > 0:
                    return int(dim)

        # 4. Custom model — read dim from HuggingFace config.json cache
        import json  # noqa: PLC0415

        from ._constants import FASTEMBED_CACHE_DIR  # noqa: PLC0415

        config_path = FASTEMBED_CACHE_DIR / "config.json"
        if not config_path.exists():
            # Try huggingface_hub cache layout
            for p in FASTEMBED_CACHE_DIR.rglob("config.json"):
                config_path = p
                break

        if config_path.exists():
            dim = json.loads(config_path.read_text()).get("hidden_size")
            if dim and dim > 0:
                return int(dim)
    except Exception:
        pass

    return 0


def get_model_info() -> dict[str, str | int]:
    """Return model name, dim, provider, cache_dir, and readiness flag."""
    import semantic_cache_mcp.core.embeddings._model as _m

    if OPENAI_EMBEDDINGS_ENABLED:
        dim = get_embedding_dim()
        return {
            "model": OPENAI_EMBEDDING_MODEL,
            "dim": dim,
            "cache_dir": "",
            "provider": "OpenAI",
            "ready": dim > 0,
        }

    return {
        "model": FASTEMBED_MODEL,
        "dim": _m._embedding_dim,
        "cache_dir": str(FASTEMBED_CACHE_DIR),
        "provider": _m._execution_provider,
        "ready": _m._model_ready,
    }


__all__ = [
    "embed",
    "embed_batch",
    "embed_query",
    "get_embedding_dim",
    "get_model_info",
    "warmup",
    # Private exports needed by tests and internal modules
    "_cuda_provider_is_available",
    "_register_custom_model",
    "_get_model",
    "FASTEMBED_MODEL",
    "FASTEMBED_CACHE_DIR",
]
