"""Private helpers and constants shared across the cache package."""

from __future__ import annotations

import asyncio
import bisect
import logging
import os
import shutil
import stat as stat_module
from dataclasses import dataclass, field
from pathlib import Path
from time import perf_counter

from ..core import count_tokens

logger = logging.getLogger(__name__)

# Size limits for DoS protection
MAX_WRITE_SIZE = 10 * 1024 * 1024  # 10MB max content size for write
MAX_EDIT_SIZE = 10 * 1024 * 1024  # 10MB max file size for edit
MAX_MATCHES = 10000  # Max occurrences for replace_all
MAX_RETURN_DIFF_TOKENS = 8000  # Hard cap for emitted diff payloads
MAX_DIFF_TO_FULL_RATIO = 0.9  # Suppress diff payloads near full-content size


# Formatter subprocess timeout. Honor SCMCP_FORMAT_TIMEOUT_S so users with
# slow formatters (e.g. eslint on monorepos) can extend it without recompiling.
# Bad values must not crash import; clamp to a sane minimum so a 0/negative
# override doesn't silently disable the timeout via asyncio.wait_for.
def _parse_format_timeout() -> float:
    raw = os.environ.get("SCMCP_FORMAT_TIMEOUT_S", "15")
    try:
        value = float(raw)
    except ValueError:
        logger.warning("Invalid SCMCP_FORMAT_TIMEOUT_S=%r; using default 15s", raw)
        return 15.0
    return max(1.0, value)


FORMAT_TIMEOUT_S: float = _parse_format_timeout()


@dataclass(slots=True)
class _PhaseTimer:
    """Tracks which phase a multi-step edit is currently in.

    Used so that when the outer asyncio.timeout fires, the error message
    can name the phase that was running (anchor_search, format_subprocess,
    etc.) instead of an opaque "timed out after 30s".
    """

    current_phase: str = "init"
    _t0: float = field(default_factory=perf_counter)

    def enter(self, phase: str) -> None:
        self.current_phase = phase

    def elapsed(self) -> float:
        return perf_counter() - self._t0


# Auto-format configuration: extension -> (command, args...)
# Command must accept file path as final argument
FORMATTERS: dict[str, tuple[str, ...]] = {
    ".py": ("ruff", "format"),
    ".pyi": ("ruff", "format"),
    ".js": ("prettier", "--write"),
    ".ts": ("prettier", "--write"),
    ".tsx": ("prettier", "--write"),
    ".jsx": ("prettier", "--write"),
    ".json": ("prettier", "--write"),
    ".css": ("prettier", "--write"),
    ".scss": ("prettier", "--write"),
    ".md": ("prettier", "--write"),
    ".yaml": ("prettier", "--write"),
    ".yml": ("prettier", "--write"),
    ".go": ("gofmt", "-w"),
    ".rs": ("rustfmt",),
}


async def _format_file(path: Path) -> bool:
    """Format file in-place using the appropriate formatter.

    Returns False if the formatter is absent or fails.
    Uses async subprocess to avoid blocking the event loop.
    """
    formatter = FORMATTERS.get(path.suffix.lower())
    if not formatter:
        return False

    cmd_name = formatter[0]
    # Check if formatter is installed
    if not shutil.which(cmd_name):
        logger.debug(f"Formatter not found: {cmd_name}")
        return False

    # Reject special files (char devices, pipes, /proc entries) before subprocess
    try:
        mode = path.stat().st_mode
        if not stat_module.S_ISREG(mode):
            logger.debug(f"Skipping non-regular file: {path}")
            return False
    except OSError:
        return False

    try:
        cmd = [*formatter, str(path)]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,  # formatters write in-place
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=FORMAT_TIMEOUT_S)
        except TimeoutError:
            proc.kill()
            # Bound the post-kill wait. SIGKILL is unstoppable so this should
            # return almost immediately, but guarding against a wedged child
            # (e.g. stuck in uninterruptible D-state) keeps the formatter call
            # from blocking the caller indefinitely.
            try:
                await asyncio.wait_for(proc.wait(), timeout=2.0)
            except TimeoutError:
                logger.warning(f"Formatter {cmd_name} did not exit after SIGKILL on {path}")
            logger.warning(f"Formatter {cmd_name} timed out on {path}")
            return False
        if proc.returncode == 0:
            logger.debug(f"Formatted {path} with {cmd_name}")
            return True
        else:
            logger.warning(f"Formatter {cmd_name} failed: {stderr.decode()[:200]}")
            return False
    except OSError as e:
        logger.warning(f"Failed to run {cmd_name}: {e}")
        return False


def _is_binary_content(data: bytes) -> bool:
    """Check if content is binary using multiple heuristics.

    Checks:
    0. Unicode BOMs (UTF-32/16/8) — text, not binary
    1. Null bytes (most reliable indicator)
    2. Common binary file magic numbers
    3. High ratio of non-printable characters
    """
    if not data:
        return False

    sample = data[:8192]

    # 0. Unicode BOMs — check 4-byte before 2-byte (UTF-32 LE shares prefix with UTF-16 LE)
    text_boms = (
        b"\xff\xfe\x00\x00",  # UTF-32 LE
        b"\x00\x00\xfe\xff",  # UTF-32 BE
        b"\xff\xfe",  # UTF-16 LE
        b"\xfe\xff",  # UTF-16 BE
        b"\xef\xbb\xbf",  # UTF-8 BOM
    )
    for bom in text_boms:
        if sample.startswith(bom):
            return False

    # 1. Null bytes - definitive binary indicator
    if b"\x00" in sample:
        return True

    # 2. Check for binary file magic numbers
    binary_signatures = (
        b"\x89PNG",  # PNG
        b"\xff\xd8\xff",  # JPEG
        b"GIF8",  # GIF
        b"PK\x03\x04",  # ZIP/DOCX/XLSX
        b"\x1f\x8b",  # GZIP
        b"BZ",  # BZIP2
        b"\x7fELF",  # ELF executable
        b"MZ",  # Windows executable
        b"%PDF",  # PDF (text header but binary content)
        b"\xd0\xcf\x11\xe0",  # MS Office OLE
    )
    for sig in binary_signatures:
        if sample.startswith(sig):
            return True

    # 3. High ratio of non-printable characters (>30% is suspicious)
    # Exclude common whitespace: tab(9), newline(10), carriage return(13)
    non_printable = sum(1 for b in sample if b < 32 and b not in (9, 10, 13))
    return len(sample) > 0 and non_printable / len(sample) > 0.3


def _find_match_line_numbers(content: str, search_string: str) -> list[int]:
    """Return 1-based line numbers for each occurrence of search_string. O(M log N)."""
    lines = content.splitlines(keepends=True)
    line_numbers: list[int] = []

    if not lines:
        return line_numbers

    # Build cumulative character positions for binary search
    char_pos = 0
    line_starts: list[int] = []
    for line in lines:
        line_starts.append(char_pos)
        char_pos += len(line)

    # Find all occurrences with O(log N) line lookup
    start = 0
    while True:
        idx = content.find(search_string, start)
        if idx == -1:
            break

        # Binary search for line number - O(log N) per match
        # bisect_right returns insertion point; -1 gives us the line containing idx
        line_num = bisect.bisect_right(line_starts, idx)
        line_numbers.append(line_num)  # Already 1-based due to bisect_right behavior
        start = idx + 1

    return line_numbers


def _extract_line_range(content: str, start_line: int, end_line: int) -> tuple[str, int, int]:
    """Return (substring, char_start, char_end) for a 1-based inclusive line range.

    Char offsets support direct splicing: content[:char_start] + new + content[char_end:]
    """
    lines = content.splitlines(keepends=True)
    total = len(lines)

    if total == 0:
        raise ValueError("Cannot extract line range from empty file")

    if start_line < 1:
        raise ValueError(f"start_line must be >= 1, got {start_line}")

    if end_line < start_line:
        raise ValueError(f"end_line ({end_line}) must be >= start_line ({start_line})")

    if start_line > total:
        raise ValueError(f"start_line ({start_line}) exceeds total lines ({total})")

    if end_line > total:
        raise ValueError(f"end_line ({end_line}) exceeds total lines ({total})")

    # Compute char offsets
    char_start = sum(len(lines[i]) for i in range(start_line - 1))
    char_end = sum(len(lines[i]) for i in range(end_line))

    substring = content[char_start:char_end]
    return substring, char_start, char_end


def _choose_min_token_content(options: dict[str, str]) -> tuple[str, str, int]:
    """Return (kind, content, tokens) for the option with the fewest tokens."""
    best_kind = ""
    best_content = ""
    best_tokens: int | None = None

    for kind, content in options.items():
        tokens = count_tokens(content)
        if best_tokens is None or tokens < best_tokens:
            best_kind = kind
            best_content = content
            best_tokens = tokens

    return best_kind, best_content, best_tokens or 0


def _suppress_large_diff(diff_content: str | None, full_tokens: int) -> str | None:
    """Return diff unchanged, a summary for diffs exceeding the token cap, or None if empty."""
    if not diff_content:
        return None

    diff_tokens = count_tokens(diff_content)
    full_tokens = max(full_tokens, 1)

    # Preserve diffs for small files where readability is more useful than suppression.
    if full_tokens <= 200:
        return diff_content

    should_suppress = diff_tokens > MAX_RETURN_DIFF_TOKENS or diff_tokens >= int(
        full_tokens * MAX_DIFF_TO_FULL_RATIO
    )
    if should_suppress:
        # Count added/removed lines and hunks from unified diff
        added = 0
        removed = 0
        hunks = 0
        for line in diff_content.splitlines():
            if line.startswith("+") and not line.startswith("+++"):
                added += 1
            elif line.startswith("-") and not line.startswith("---"):
                removed += 1
            elif line.startswith("@@"):
                hunks += 1
        return (
            f"[diff suppressed: {diff_tokens} tokens > cap] "
            f"+{added} -{removed} lines across {hunks} hunks"
        )

    return diff_content
