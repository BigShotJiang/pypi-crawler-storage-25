# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.12.0] - 2026-04-11

### Added

- **X88 (Nachtrag/Addendum) exchange phase** — Full support for claims and variations: enum values (`X88`, `D88`), file extension detection, parser recognition, phase-specific validation (quantity, price, description required; change order number recommended), and round-trip serialization.
- **Cross-phase validation: X86→X89 (contract→invoice)** — `CrossPhaseValidator.check()` now validates that invoice unit prices match the contract exactly, flags invented invoice items, and warns on missing executed quantities.
- **Cross-phase validation: X86→X88 (contract→addendum)** — Validates that new Nachtrag items have change order numbers (CONo) for traceability, and flags contract items modified without CONo.
- **Totals validation** — New `validate_totals()` checks XML-declared totals against computed subtotals at BoQ, lot, and category levels. Also detects when alternative/eventual items are incorrectly included in totals (VOB/A compliance).
- **GAEB precision limit validation** — `validate_numerics()` now enforces GAEB Fachdokumentation limits: unit price max 10 pre-decimal digits, total price max 11, quantity max 8 pre-decimal / 3 decimal places, and max 6 unit price components per item.
- **Writer `up_frac_dig` support** — `GAEBWriter` now formats unit prices to the correct number of decimal places when `UPFracDig` is set in the document's `PrjInfo` (e.g., 3 decimals when `UPFracDig=3`).
- **Explicit cross-phase methods** — `CrossPhaseValidator.check_tender_bid()`, `.check_contract_invoice()`, and `.check_contract_addendum()` for direct invocation without auto-dispatch.
- 92 new tests covering all gap fixes and coverage improvements across classifier, extractor, version compat, detector, and validation modules. Total test count: 927.

### Fixed

- **X80 phase validation false positives** — X80 (BoQ Catalogue) no longer incorrectly warns about missing quantities. X80 is a reusable item library without quantities or prices per the GAEB standard.
- **README version badge** — Updated from 1.7.0 to 1.11.0 (both English and German).

### Security

- **SQLiteCache file permissions** — Database files are now created with `0o600` permissions and cache directories with `0o700`, restricting access to the owning user. Classification results may contain business-sensitive construction data.

## [1.11.0] - 2026-03-24

### Added

- **Excel Export** — `to_excel()` exports any GAEB document to a structured Excel workbook (.xlsx) with hierarchy-aware layout and phase-specific columns.
- **Two export modes** — `mode="structured"` for a single hierarchy-aware sheet; `mode="full"` for a multi-sheet workbook (BoQ + Items + Summary + Info).
- **All document kinds** — Procurement (X80-X89), Trade (X93-X97), Cost (X50-X52), and Quantity Determination (X31) each get phase-appropriate columns.
- **Optional columns** — `include_long_text`, `include_classification`, and `include_bim_guid` flags add extra columns on demand.
- **Minimal formatting** — Bold headers, frozen panes, auto column widths, currency/quantity number formatting, bold subtotals.
- Optional dependency: `openpyxl` via `pip install pyGAEB[excel]`.
- New export: `to_excel` (top-level lazy import and via `pygaeb.convert`).
- 34 new tests covering all 4 phases, both modes, column flags, formatting, and edge cases.

## [1.10.0] - 2026-03-24

### Added

- **BoQ Builder API** — `BoQBuilder` provides programmatic construction of GAEB documents from scratch with a fluent, explicit-object API.
- **Auto OZ generation** — Ordinal numbers auto-generated from category `rno` + sequence (10, 20, 30...) when `oz` is omitted. Explicit OZ overrides supported.
- **Decimal convenience** — `int`, `float`, and `str` values auto-converted to `Decimal` for `qty`, `unit_price`, and `total_price`. Auto-computes `total_price` when missing.
- **Field name validation** — Unknown kwargs raise `ValueError` with `difflib` suggestions for likely typos (e.g., `'unit_prce'` → `Did you mean: 'unit_price'?`).
- **Phase-aware rules** — Warns or errors (strict mode) when items violate exchange phase semantics (e.g., prices in X80 blank BoQ, missing prices in X83 tender).
- **Version compatibility checks** — Detects fields incompatible with the target DA XML version (e.g., `bim_guid` in DA XML < 3.3) with warnings or strict errors.
- **Duplicate OZ detection** — Catches duplicate ordinal numbers within a lot at build time.
- **Auto totals & BoQBkdn** — Lot subtotals computed from item prices; breakdown structure inferred from hierarchy depth.
- **Implicit lot shortcut** — `builder.add_category()` creates a single implicit lot for simple documents.
- **ItemHandle** — Fluent post-construction for long text (`.set_long_text()`) and attachments (`.add_attachment()`).
- **Optional XSD validation** — `build(xsd_dir=...)` serializes to XML in memory and validates against official GAEB XSD schemas.
- **Full writer compatibility** — Built documents work directly with `GAEBWriter.write()` and `GAEBWriter.to_bytes()`.
- New export: `BoQBuilder` (top-level lazy import).
- 46 new tests covering basic construction, multi-lot, nested categories, auto OZ, Decimal conversion, field validation, typo detection, phase rules, version compatibility, strict mode, duplicate OZ, auto totals, round-trip serialization, and edge cases.

## [1.9.0] - 2026-03-24

### Added

- **Document Diff Engine** — `BoQDiff.compare(doc_a, doc_b)` performs a deterministic, field-by-field comparison of two GAEB procurement documents with structured results.
- **OZ-based item matching** — Lot-aware matching by OZ (ordinal number) with global fallback for items that moved between lots.
- **Field-level change detection** — Each changed field carries a `Significance` level (`CRITICAL`, `HIGH`, `MEDIUM`, `LOW`) based on construction context impact.
- **Structural diff** — Detects added, removed, and renamed sections (categories), as well as items that moved between categories or lots.
- **`DiffMode`** enum — `DEFAULT` (warnings for mismatched projects), `STRICT` (raises `ValueError`), `FORCE` (suppresses warnings).
- **`DiffResult`** Pydantic model — Complete comparison output with `summary`, `items`, `structure`, `metadata`, and `warnings` sections. Fully serializable to JSON.
- **Financial impact** — Automatic computation of net financial impact (`grand_total_b - grand_total_a`).
- **Match ratio & compatibility warnings** — Low match ratio detection, different project warnings, currency mismatch alerts, version difference notices.
- **Result filtering** — `ItemModified.filter_changes(min_significance)` and `ItemDiffSummary.filter_modified(min_significance)` for targeted reporting.
- New exports: `BoQDiff`, `DiffMode`, `DiffResult`, `DiffSummary`, `DiffDocInfo`, `Significance`, `FieldChange`, `ItemAdded`, `ItemRemoved`, `ItemModified`, `ItemMoved`, `ItemDiffSummary`, `MetadataChange`, `SectionChange`, `SectionRenamed`, `StructureDiffSummary`.
- 53 new tests covering item matching, field comparison, structural diff, integration, models, lazy imports, and edge cases.

## [1.8.0] - 2026-03-24

### Added

- **Read-only BoQ Tree API** — `BoQTree` adapter wraps an existing `BoQ` and builds a navigable node graph with parent references, depth tracking, and indexed lookups. The underlying Pydantic models are not modified.
- **`BoQNode`** — Lightweight tree node with O(1) `parent`, `children`, `depth`, `index`, `siblings`, `ancestors`, `path`, `next_sibling`, `prev_sibling`, `is_leaf`, `is_root` properties.
- **Type-safe model accessors** — `node.boq`, `node.lot`, `node.category`, `node.item` raise `TypeError` if accessed on the wrong node kind.
- **Unified convenience properties** — `node.label`, `node.rno`, `node.label_path` work across all node kinds (root, lot, category, item).
- **Subtree queries** — `node.iter_descendants()`, `node.iter_items()`, `node.iter_categories()`, `node.find(predicate)`, `node.find_all(predicate)`.
- **`BoQTree` lookups** — `tree.find_item(oz)` (O(1) via index), `tree.find_category(rno)`, `tree.find_all_categories(rno)`.
- **Tree traversal** — `tree.walk()` (depth-first) and `tree.walk_bfs()` (breadth-first) over all nodes.
- **`NodeKind`** enum — `ROOT`, `LOT`, `CATEGORY`, `ITEM` discriminator for node types.
- New exports: `BoQTree`, `BoQNode`, `NodeKind`.
- 87 new tests covering tree navigation, lookups, iteration, and multi-lot documents.

## [1.7.1] - 2026-03-15

### Fixed

- **Procurement long text parsing** — Items in DA XML 3.x procurement files (X80–X89) now correctly extract long text from the `<Description>/<CompleteText>/<DetailTxt>` structure.
- **OWN (owner/client) parsed from wrong element** — `<OWN>` is now correctly located as a child of `<Award>` instead of `<AwardInfo>`, producing a full `Address` with all `tgAddress` fields.

### Added

- **AwardInfo metadata** — 13 new fields on `AwardInfo`: `category`, `open_date`, `open_time`, `eval_end`, `submit_location`, `construction_start`, `construction_end`, `contract_no`, `contract_date`, `accept_type`, `warranty_duration`, `warranty_unit`, and `award_no`.
- **`AwardInfo.owner_address`** — Full `Address` model for the `<OWN>/<Address>` structure.
- **`Address` model extended to match `tgAddress` XSD** — Added `name3`, `name4`, `contact`, `iln`, and `vat_id` fields.
- **`_parse_address` consolidated** — Moved into `BaseV3Parser` so all phases share XSD-complete address parsing.
- Writer, German element map, and 48 new tests updated accordingly.

## [1.0.0] - 2026-03-14

### Added

- Unified domain model (GAEBDocument, Item, BoQ, AwardInfo) with Pydantic v2
- Format & version detection for DA XML 2.0–3.3
- Pre-parse encoding repair via ftfy + charset-normalizer
- Malformed XML recovery with two-pass strategy
- DA XML 3.x parser (3.0, 3.1, 3.2, 3.3)
- DA XML 2.x parser (2.0, 2.1) via German element mapping
- OZ resolver with BoQBkdn hierarchy breakdown
- Rich text parser for tgBoQText long texts (BeautifulSoup4 + lxml)
- Structural, item, numeric, and phase validation
- Cross-phase validation (source ↔ response compatibility)
- LLM classification via LiteLLM (100+ providers) + instructor (structured output)
- Async batch classifier with SQLite cache, deduplication, cost preview
- Sync convenience wrapper for classification
- Model fallback chains
- Progress reporting callbacks
- Manual override support with cache persistence
- Prompt versioning (v1)
- GAEB XML writer with round-trip support
- JSON and CSV export
- Multi-lot document navigation
- Configuration via pydantic-settings (env vars / .env)
- Comprehensive validation with lenient (default) and strict modes
