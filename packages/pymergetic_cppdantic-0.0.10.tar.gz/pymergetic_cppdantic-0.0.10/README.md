# cppdantic

Small demo that **builds against `pymergetic.easybind`** from PyPI (`pymergetic-easybind`). **PyPI distribution:** **`pymergetic-cppdantic`**. **Import:** **`pymergetic.cppdantic`**. The repo directory stays **`packages/cppdantic/`** in the os-sdk monorepo.

**PyPI:** [`pymergetic-cppdantic`](https://pypi.org/project/pymergetic-cppdantic/) (when published). Versioning and tags: **`RELEASING.md`**.

**Platforms:** CI publishes **manylinux** and **Windows amd64** wheels (CPython 3.11–3.14). Install with `pip install pymergetic-cppdantic` on those platforms once wheels exist for your release.

**Bumping `pymergetic-easybind~=…`:** **`pymergetic-pin-pyproject --project-root .`** (from **pymergetic-common** devtools on PyPI). Default = latest **`v*`** tag on **GitHub**. Use **`--from-pypi`** for PyPI’s published latest instead — see **`RELEASING.md`**.

## Build / test

You need **`pymergetic-easybind`** installed (matching the pin in **`pyproject.toml`**), plus CMake ≥ 3.25, Ninja, and a C++20 compiler on `PATH`:

```bash
python -m pip install -U pip
python -m pip install "pymergetic-easybind~=0.2.15"   # align with pyproject.toml
python -m pip install -e '.[test]'
python -m pytest tests -q
```

`CMake` loads **`easybind/cmake/easybind_pip.cmake`** from the installed **`pymergetic.easybind`** package. PyPI must ship the **`cmake/`** tree for the version you pin.

### os-sdk workspace (editable easybind)

From the **os-sdk repo root**:

```bash
uv sync
python -m pytest packages/cppdantic/tests -q
```

Or install only **pymergetic-cppdantic** after syncing **`pymergetic-common[easybind]`** in a venv with editable easybind (standalone checkout).

### uv

From the **cppdantic repo root**:

```bash
uv pip install "pymergetic-easybind~=0.2.15"
uv pip install -e ".[test]"
```

(`pyproject.toml` sets **`[tool.uv] no-build-isolation-package = ["pymergetic-cppdantic"]`** so editable builds use your venv.)

If **`uv pip install`** fails with **`Metadata mismatch in METADATA`** (setuptools-scm version differs between build phases), clear stale artifacts and install **pymergetic-easybind** first, then **pymergetic-cppdantic**:

```bash
rm -rf build dist *.egg-info src/pymergetic/cppdantic/*.egg-info
uv pip install -e ../easybind    # monorepo sibling, or pymergetic-easybind from PyPI
uv pip install -e ".[test]"
```

Ensure **`src/pymergetic/cppdantic/_version.py`** is not tracked by git (it is gitignored).

## Tagging

Create an annotated **`v*`** tag on **`main`** after your pins commit (see **`RELEASING.md`**).
