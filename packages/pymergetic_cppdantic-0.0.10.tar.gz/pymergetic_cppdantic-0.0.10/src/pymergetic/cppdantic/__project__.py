from importlib.metadata import version

__package_name__ = "pymergetic-cppdantic"
__package_module__ = "pymergetic.cppdantic"
__version__ = version(__package_name__)

__all__ = ["__package_name__", "__package_module__", "__version__"]
