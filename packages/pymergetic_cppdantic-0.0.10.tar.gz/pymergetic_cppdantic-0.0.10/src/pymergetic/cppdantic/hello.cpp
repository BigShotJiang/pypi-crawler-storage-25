#include <pymergetic/easybind/bind.hpp>

EASYBIND_NS_MODULE_SHARED_OBJECT(pymergetic::cppdantic, cppdantic, m, true, {
  m.doc() = "pymergetic.cppdantic hello-world (built against pymergetic.easybind)";
  m.def("hello", []() { return std::string("hello from pymergetic.cppdantic"); });
});
