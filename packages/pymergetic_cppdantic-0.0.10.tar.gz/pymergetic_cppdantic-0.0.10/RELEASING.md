# Releasing pymergetic-cppdantic to PyPI

**PyPI / pip:** **`pymergetic-cppdantic`**. **Import:** **`import pymergetic.cppdantic`**.

**Pins vs installs:** **`pymergetic-pin-pyproject --project-root .`** sets pins from the **latest `v*`** tag on **GitHub**. Wait until the pinned dependency exists on PyPI before isolated installs or CI (**`pymergetic-wait-pypi --project-root .`** in publish workflow).

## Renamed from `cppdantic` on PyPI

Older releases were published as **`cppdantic`** (`pypi.org/project/cppdantic/`). New releases use **`pymergetic-cppdantic`**. PyPI does not rename projects in place — the next **`v*`** tag creates/uploads under the new name automatically (same CI workflow; `[project].name` in `pyproject.toml` drives the target).

**Downstream pins:** change `cppdantic` / `import cppdantic` → `pymergetic-cppdantic` / `import pymergetic.cppdantic`. Optionally publish one final **`cppdantic`** metapackage release that depends on **`pymergetic-cppdantic==X.Y.Z`** for a soft migration window.

## End-to-end workflow (pymergetic-easybind → PyPI → bump → tag)

Do this in order.

### 1) Release **pymergetic-easybind**

```bash
cd /path/to/easybind   # e.g. ~/Devel/os-sdk/packages/easybind

pymergetic-release-tag --dry-run
pymergetic-release-tag
```

- Wait until GitHub **Publish to PyPI** on **easybind** finishes.
- Check PyPI: **https://pypi.org/project/pymergetic-easybind/** shows that version.

### 2) Bump **pymergetic-cppdantic** `pyproject.toml` pins (manual; not CI)

```bash
cd /path/to/cppdantic
python -m pip install -U "pymergetic-common[release]>=0.0.0"

pymergetic-pin-pyproject --project-root . --dry-run
pymergetic-pin-pyproject --project-root .

git add pyproject.toml
git commit -m "Bump pymergetic-easybind pins"
git push origin main
```

### 3) Tag **pymergetic-cppdantic**

```bash
cd /path/to/cppdantic
git fetch --tags
export TAG=v0.1.1   # choose the next version
git tag -a "$TAG" -m "pymergetic-cppdantic ${TAG#v}"
git push origin main
git push origin "$TAG"
```

**GitHub vs PyPI:** the tag can exist while the publish workflow fails; **`PYPI_API_TOKEN`** must be set on the **cppdantic** repo. CI uses **`pymergetic-wait-pypi --project-root .`**.

**CI wait:** the **Publish to PyPI** workflow installs **`pymergetic-common[release]`** from PyPI and runs **`pymergetic-wait-pypi --project-root .`**, which infers **`pymergetic-easybind`** from pins in **`pyproject.toml`**. Keep **`pymergetic-easybind~=…`** pins in sync when you bump.

---

## Order: pymergetic-easybind first, then bump pins

**pymergetic-cppdantic** builds against whatever **`pymergetic.easybind`** you install; CI and wheels must see a matching release on PyPI.

1. **easybind** repo: tag **`vA.B.C`**, push, wait until **`pymergetic-easybind==A.B.C`** is on PyPI.
2. **cppdantic** repo: bump **every** `pymergetic-easybind~=…` in **`pyproject.toml`**. Automate with:

   ```bash
   pymergetic-pin-pyproject --project-root . --dry-run
   pymergetic-pin-pyproject --project-root .
   ```

3. **Commit that bump on `main` before you create the tag.**

If you tag before the matching **pymergetic-easybind** wheel exists, isolated builds and cibuildwheel tests can fail.

## Version

Setuptools-scm reads the version from **`v*`** tags. Runtime: **`importlib.metadata.version("pymergetic-cppdantic")`**.

## CI publish

Pushing a tag **`v*`** runs **`.github/workflows/publish.yml`**: sdist, **cibuildwheel** (manylinux + Windows amd64), **twine check**, upload to PyPI.

Set the **`PYPI_API_TOKEN`** repository secret.

## Manual dry run

```bash
python -m pip install build twine
git fetch --tags
python -m build
twine check dist/*
# twine upload dist/*
```

## Notes

- **Runtime:** the extension expects **`pymergetic-easybind`** at the pinned version so **`libeasybind.so`** / **`easybind.dll`** and headers resolve under **`site-packages/pymergetic/easybind/`**.
