def test_hello():
    import pymergetic.cppdantic as cppdantic

    assert cppdantic.hello() == "hello from pymergetic.cppdantic"
