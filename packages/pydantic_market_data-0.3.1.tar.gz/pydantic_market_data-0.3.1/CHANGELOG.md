# Changelog

All notable changes to this project will be documented in this file.

## [0.3.1] - 2026-04-23

### Fixed
- **FIGI check digit algorithm**: The Luhn algorithm was incorrectly applied to the expanded individual-digit list instead of the character-value list. Letters were split into two digits (e.g. `S=28 → [2, 8]`) before Luhn processing, causing parity misalignment for FIGIs that mix digits and letters in certain positions. The fix applies Luhn directly to character values (0–35) and uses `val % 10 + val // 10` as the digit-sum contribution, matching the OMG FIGI standard. Real-world identifiers such as `BBG00KHY5S69` (Broadcom Inc) were incorrectly rejected before this fix.

### Chore
- Pinned `astral-sh/setup-uv` GitHub Action to `v8.1.0`.
- Updated GitHub Actions to Node.js 24-compatible versions.

## [0.3.0] - 2026-04-23

### Changed (Breaking)
- Renamed `SecurityCriteria` to `SecurityQuery`. No backward-compatibility alias.
- Removed `target_price: Price.Input | None` and `target_date: FlexibleDate | None` from `SecurityQuery`. Both fields are now expressed as a single `price_on: PriceOnDate | None` field.

### Added
- `PriceOnDate` model (`price: Price.Input`, `date: FlexibleDate`) — exported from the top-level package.
- `figi: FIGI.Input | None` field on `SecurityQuery` for resolving by Bloomberg Open FIGI.

## [0.2.1] - 2026-04-23

### Added
- `FIGI` Value Object with full format and Luhn check-digit validation, following the Namespace Pattern (`FIGI.Input`).
- `figi: FIGI.Input | None` field on `Security` for Bloomberg Open FIGI identifiers.

## [0.2.0] - 2026-04-14

### Changed (Breaking)
- **Symbol Migration**: Standardized naming to align with industrial standards.
    - Renamed `Ticker` (RootModel) to `Symbol`.
    - Renamed `Symbol` (BaseModel) to `Security`.
    - In `Security`: Renamed `ticker` field to `symbol`.
    - In `History`: Renamed `symbol` field to `security`.
    - In `SecurityCriteria`: Ensured `symbol` field uses `Symbol.Input`.
    - In `PriceVerificationError`: Renamed `ticker` field to `symbol`.
    - Updated `DataSource` protocol and CLI models to use `symbol` instead of `ticker`.

## [0.1.17] - 2026-04-04

### Fixed
- Added missing `asset_class` field to `SecurityCriteria` model (previously only available in `Symbol`).

## [0.1.16] - 2026-02-28

### Refactored
- Transition `PriceVerificationError` to use Value Objects (`Ticker`, `Price`) and improve string representation for better error reporting.

## [0.1.15] - 2026-02-25

### Changed
- Adopted the **Namespace Pattern** for strict-yet-flexible typing (e.g., `Ticker.Input` instead of `TickerInput`) across all models and interfaces to improve Developer Experience and Mypy compatibility.

## [0.1.14] - 2026-02-22

### Fixed
- Recovery release following PyPI name reuse error on v0.1.13. No functional changes from v0.1.13.

## [0.1.13] - 2026-02-22

### Added
- Dedicated `cli_models.py` with support for short flags (`-v`, `-vv`) and JSON schema printing.
- `Ticker`, `ISIN`, `Price`, and `CountryAlpha2` strict Value Objects.
- `PriceVerificationError` for detailed validation failures.
- Automatic country resolution from names to Alpha-2 codes during initialization.
- Strict-yet-flexible typing allowing primitives (strings/floats) in models during creation.

### Changed
- Refactored `Symbol` and `SecurityCriteria` to use new Value Objects and Input types.
- Updated `DataSource` protocol to use `TickerInput` and `PriceInput` for better DX.
- Enabled validation on assignment for `OHLCV` and `SecurityCriteria`.


## [0.1.11] - 2026-02-19

### Added
- `isin` field to `Symbol` model.

## [0.1.10] - 2026-02-19

### Added
- `exchange` field to `SecurityCriteria` for more precise resolution.

### Changed
- Updated internal dependencies.
- Improved docstrings in `interfaces.py`.

## [0.1.9] - 2026-02-14

### Changed
- Updated `requires-python` constraint to `>=3.10`.

## [0.1.8] - 2026-02-14

### Fixed
- Retired unnecessary files and cleaned up repository structure.

## [0.1.7] - 2026-02-09

### Changed
- Minor internal cleanups and formatting.
## [0.1.6] - 2026-02-09

### Added
- OSS release workflow configuration.
- Completed project structure with `src` layout.

### Changed
- Improved metadata in `pyproject.toml`.
