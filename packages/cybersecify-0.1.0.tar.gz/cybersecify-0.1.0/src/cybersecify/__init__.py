"""
cybersecify v0.1.0

CyberSecAI-maintained entry point for "cybersecify" on PyPI.
Canonical implementation: https://www.npmjs.com/package/cybersecify

(c) 2026 CyberSecAI Ltd. Apache 2.0.
"""

META = {
    "name": "cybersecify",
    "description": """Cybersecify namespace entry point on PyPI. Canonical: cybersecify on npm.""",
    "publisher": "CyberSecAI Ltd",
    "homepage": "https://agentpass.co.uk",
    "canonical_implementation": "https://www.npmjs.com/package/cybersecify",
    "standards": {
        "openapi_registry": "https://spec.openapis.org/registry/extension/x-agent-trust.html",
        "ietf_agent_payment": "https://datatracker.ietf.org/doc/draft-sharif-agent-payment-trust/",
        "ietf_mcps": "https://datatracker.ietf.org/doc/draft-sharif-mcps-secure-mcp/",
    },
}


def info():
    """Return package metadata."""
    return META


__version__ = "0.1.0"
__all__ = ["info", "META", "__version__"]
