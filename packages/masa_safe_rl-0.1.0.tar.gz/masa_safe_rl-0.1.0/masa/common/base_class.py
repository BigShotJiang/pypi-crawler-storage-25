from __future__ import annotations
from typing import Any, Optional, TypeVar, Union, List, Callable, Dict
from gymnasium import spaces
import gymnasium as gym
import jax.random as jr
from masa.common.metrics import RolloutLogger, StatsLogger, TrainLogger
from abc import ABC, abstractmethod
import tensorflow as tf
import math
from tqdm.auto import tqdm

def _allowed_names(allowed: tuple[type[spaces.Space], ...]) -> str:
    return ", ".join(t.__name__ for t in allowed)

class BaseAlgorithm(ABC):

    def __init__(
        self,
        env: gym.Env,
        tensorboard_logdir: Optional[str] = None,
        wandb_project: Optional[str] = None, # W&B project name (enables W&B if set)
        wandb_name: Optional[str] = None, # Specific name for this W&B run
        seed: Optional[int] = None,
        monitor: bool = True,
        device: str = "auto",
        verbose: int = 0,
        supported_action_spaces: Optional[tuple[type[spaces.Space], ...]] = None,
        supported_observation_spaces: Optional[tuple[type[spaces.Space], ...]] = None,
        env_fn: Optional[Callable[[], gym.Env]] = None,
        eval_env: Optional[gym.Env] = None, 
    ):

        self.env = env
        self.tensorboard_logdir = tensorboard_logdir
        self.wandb_project = wandb_project
        self.wandb_name = wandb_name
        self.seed = seed
        self.device = device
        self.verbose = verbose
        self.supported_action_spaces = supported_action_spaces
        self.supported_observation_spaces = supported_observation_spaces

        act_sp = getattr(env, "action_space", None)
        obs_sp = getattr(env, "observation_space", None)

        if act_sp is None or obs_sp is None:
            raise ValueError(
                f"{self.__class__.__name__}: env is missing action_space/observation_space."
            )

        if self.supported_action_spaces is not None and not isinstance(act_sp, self.supported_action_spaces):
            raise TypeError(
                f"{self.__class__.__name__} does not support action space { type(act_sp).__name__ }.\n"
                f"Allowed types: { _allowed_names(self.supported_action_spaces) }."
            )

        if self.supported_observation_spaces is not None and not isinstance(obs_sp, self.supported_observation_spaces):
            raise TypeError(
                f"{self.__class__.__name__} does not support observation space { type(obs_sp).__name__ }.\n"
                f"Allowed types: { _allowed_names(self.supported_observation_spaces) }."
            )

        self.observation_space = env.observation_space
        self.action_space = env.action_space

        self._env_fn = env_fn
        self._eval_env = eval_env

        self.key = jr.PRNGKey(0 if seed is None else seed)
        self.eval_key, self.key = jr.split(self.key)

    def train(
        self, 
        num_frames: int,
        num_eval_episodes: int = 0,
        eval_freq: int = 0,
        log_freq: int = 1,
        prefill: Optional[int] = None,
        save_freq: int = 0,
        stats_window_size: int = 100,
        stats_window_overrides: Optional[Dict[str, int]] = None
    ):

        if self.tensorboard_logdir is not None:
            summary_writer = tf.summary.create_file_writer(self.tensorboard_logdir)
        else:
            summary_writer = None

        if not stats_window_overrides:
            stats_window_overrides = {}

        use_wandb = self.wandb_project is not None

        if use_wandb:
            import wandb
            wandb_ctx = wandb.init(
                project=self.wandb_project,
                name=self.wandb_name,
                config=self._get_wandb_config(),
            )
        else:
            import contextlib
            wandb_ctx = contextlib.nullcontext()

        logger = TrainLogger(
            [("train/rollout", RolloutLogger), ("train/stats", StatsLogger), ("eval/rollout", RolloutLogger)],
            tensorboard=bool(summary_writer is not None),
            summary_writer=summary_writer,
            wandb=use_wandb,
            stats_window_size=[stats_window_size, stats_window_size, num_eval_episodes],
            stats_window_overrides=stats_window_overrides,
            prefix='',
        )

        total_steps = 0

        next_eval = eval_freq
        next_save = save_freq
        next_log = log_freq

        self._last_obs, _ = self.env.reset(seed=self.seed)

        with wandb_ctx, tqdm(
            total=num_frames,
            desc="frames",
            position=0,
            leave=True,
            dynamic_ncols=True,
        ) as iter_bar:

            for iteration in range(math.ceil((num_frames)/self.train_ratio)):
                self.rollout(total_steps, logger=logger)
                self.optimize(total_steps, logger=logger)

                iter_bar.update(self.train_ratio)
                total_steps += self.train_ratio

                if eval_freq and (total_steps >= next_eval):
                    next_eval += eval_freq
                    self.eval(num_eval_episodes, seed=total_steps, logger=logger)

                if save_freq and (total_steps >= next_save):
                    next_save += save_freq
                    self.save(total_steps)

                if log_freq and (total_steps >= next_log):
                    next_log += log_freq
                    logger.log(total_steps)

    def _get_wandb_config(self) -> dict:
        """Auto-capture serialisable instance attributes for wandb.config.

        Returns a dict of all public instance attributes whose values are
        JSON-serialisable primitives (int, float, str, bool, None).  Complex
        objects such as environments, policies, and JAX arrays are excluded.
        """
        return {
            k: v for k, v in self.__dict__.items()
            if not k.startswith('_')
            and isinstance(v, (int, float, str, bool, type(None)))
        }

    def _get_eval_env(self) -> gym.Env:
        if self._eval_env is not None:
            return self._eval_env
        if self._env_fn is not None:
            self._eval_env = self._env_fn()
            return self._eval_env
        raise RuntimeError(
                "Cannot construct eval env; please pass env_fn or eval_env."
            )

    def optimize(self, step: int, logger: Optional[TrainLogger] = None):
        """Optimizes the policy and other auxilliary models"""
        raise NotImplementedError

    def rollout(self, step: int, logger: Optional[TrainLogger] = None):
        """Collects rollouts/experience for the policy to learn from"""
        raise NotImplementedError

    def eval(self, num_episodes: int, seed: Optional[int] = None, logger: Optional[TrainLogger] = None) -> List[float]:
        eval_env = self._get_eval_env()
        base = 0 if self.seed is None else int(self.seed)
        eval_seed = base + 10_000 if seed is None else int(seed) + 10_000
        eval_key = jr.PRNGKey(eval_seed)
        returns = []

        with tqdm(
            total=num_episodes,
            desc="evaluation",
            position=1,
            leave=False,
            dynamic_ncols=True,
            colour="yellow"
        ) as pbar:

            for ep in range(num_episodes):
                obs, info = eval_env.reset(seed=eval_seed + ep)
                done = False
                ret = 0.0
                while not done:
                    eval_key, subkey = jr.split(eval_key)
                    action = self.act(subkey, obs, deterministic=False)
                    obs, rew, terminated, truncated, info = eval_env.step(action)
                    ret += float(rew)
                    done = terminated or truncated

                returns.append(ret)
                pbar.update(1)

                if logger is not None:
                    logger.add("eval/rollout", info)

        return returns

    def act(self, key: jax.Array, obs: Any, deterministic: bool = False) -> Any:
        """Implements the agent's policy: action selection (deterministic) or sampling"""
        raise NotImplementedError

    def save(self, step: int):
        """Save the relevant algorithm/model parameters"""
        raise NotImplementedError
    
    def load(self):
        """Load the relevant algorithm/model parameters"""
        raise NotImplementedError

    @property
    def train_ratio(self) -> int:
        """How often to do an update step during training"""
        raise NotImplementedError

class BaseJaxPolicy(ABC):

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Space,
    ):
        self.observation_space = observation_space
        self.action_space = action_space