"""Counter utilities for metrics tracking.

Status: Implemented

Provides simple atomic counters for tracking operations like
cache hits, fetches, evictions, etc.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class Counter:
    """A simple atomic counter with metadata."""
    name: str
    value: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def increment(self, n: int = 1) -> int:
        with self._lock:
            self.value += n
            return self.value

    def decrement(self, n: int = 1) -> int:
        with self._lock:
            self.value -= n
            return self.value

    def get(self) -> int:
        with self._lock:
            return self.value

    def reset(self) -> None:
        with self._lock:
            self.value = 0

    def snapshot(self) -> dict[str, Any]:
        return {"name": self.name, "value": self.get()}


class CounterGroup:
    """A named group of counters for subsystem metrics."""

    def __init__(self, prefix: str = "") -> None:
        self._prefix = prefix
        self._counters: dict[str, Counter] = {}
        self._lock = threading.Lock()

    def get_counter(self, name: str) -> Counter:
        with self._lock:
            full_name = f"{self._prefix}.{name}" if self._prefix else name
            if full_name not in self._counters:
                self._counters[full_name] = Counter(name=full_name)
            return self._counters[full_name]

    def increment(self, name: str, n: int = 1) -> int:
        return self.get_counter(name).increment(n)

    def get(self, name: str) -> int:
        return self.get_counter(name).get()

    def reset_all(self) -> None:
        with self._lock:
            for c in self._counters.values():
                c.reset()

    def snapshot(self) -> dict[str, int]:
        with self._lock:
            return {name: c.get() for name, c in self._counters.items()}

    def to_dict(self) -> dict[str, Any]:
        return {"prefix": self._prefix, "counters": self.snapshot()}
