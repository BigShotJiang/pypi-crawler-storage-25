"""Benchmark utilities for Rex.

Status: Implemented

Provides benchmark runner and result formatting.
"""

from __future__ import annotations

import json
import statistics
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


@dataclass
class BenchmarkResult:
    """Result of a single benchmark scenario."""
    scenario_name: str
    model_id: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    iterations: int = 0
    warmup_iterations: int = 0
    # Timing (ms)
    total_time_ms: float = 0.0
    avg_inference_ms: float = 0.0
    min_inference_ms: float = 0.0
    max_inference_ms: float = 0.0
    p50_inference_ms: float = 0.0
    p95_inference_ms: float = 0.0
    p99_inference_ms: float = 0.0
    # Chunk metrics
    total_chunks_fetched: int = 0
    total_cache_hits: int = 0
    total_cache_misses: int = 0
    total_bytes_fetched: int = 0
    avg_cache_hit_ratio: float = 0.0
    # Environment
    python_version: str = ""
    torch_version: str = ""
    platform: str = ""
    # Config
    chunk_size: int = 0
    cache_size_mb: int = 0
    cache_policy: str = ""
    prefetch_window: int = 0
    fetch_concurrency: int = 0
    simulated_latency_ms: float = 0.0
    simulated_bandwidth_mbps: float = 0.0
    # Per-iteration data
    raw_inference_times_ms: list[float] = field(default_factory=list)
    # Metadata
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


def run_benchmark(
    scenario_name: str,
    inference_fn: Any,
    num_iterations: int = 5,
    warmup_iterations: int = 1,
    config: Optional[dict] = None,
) -> BenchmarkResult:
    """Run a benchmark scenario.

    Args:
        scenario_name: Name of the scenario.
        inference_fn: Async callable that returns (output, InferenceMetrics).
        num_iterations: Number of measured iterations.
        warmup_iterations: Number of warmup iterations (not measured).
        config: Optional config dict for recording.

    Returns:
        BenchmarkResult with timing and metrics.
    """
    import platform
    import asyncio

    # Gather environment info
    result = BenchmarkResult(
        scenario_name=scenario_name,
        model_id=config.get("model_id", "unknown") if config else "unknown",
        iterations=num_iterations,
        warmup_iterations=warmup_iterations,
        python_version=platform.python_version(),
        platform=platform.platform(),
        chunk_size=config.get("chunk_size", 0) if config else 0,
        cache_size_mb=config.get("cache_size_mb", 0) if config else 0,
        cache_policy=config.get("cache_policy", "") if config else "",
        prefetch_window=config.get("prefetch_window", 0) if config else 0,
        fetch_concurrency=config.get("fetch_concurrency", 0) if config else 0,
        simulated_latency_ms=config.get("simulated_latency_ms", 0.0) if config else 0.0,
        simulated_bandwidth_mbps=config.get("simulated_bandwidth_mbps", 0.0) if config else 0.0,
    )

    try:
        import torch
        result.torch_version = torch.__version__
    except ImportError:
        pass

    async def _run_all():
        times: list[float] = []
        total_hits = 0
        total_misses = 0
        total_fetched = 0
        total_bytes = 0

        # Warmup
        for _ in range(warmup_iterations):
            try:
                await inference_fn()
            except Exception:
                pass

        # Measured iterations
        for _ in range(num_iterations):
            start = time.perf_counter()
            try:
                _, metrics = await inference_fn()
            except Exception as e:
                print(f"Benchmark iteration failed: {e}")
                continue
            elapsed = (time.perf_counter() - start) * 1000
            times.append(elapsed)

            total_hits += metrics.cache_hits
            total_misses += metrics.cache_misses
            total_fetched += metrics.chunks_fetched
            total_bytes += metrics.bytes_fetched_remote

        if not times:
            return

        result.raw_inference_times_ms = times
        result.total_time_ms = sum(times)
        result.avg_inference_ms = statistics.mean(times)
        result.min_inference_ms = min(times)
        result.max_inference_ms = max(times)
        times_sorted = sorted(times)
        result.p50_inference_ms = times_sorted[len(times_sorted) // 2]
        result.p95_inference_ms = times_sorted[int(len(times_sorted) * 0.95)]
        result.p99_inference_ms = times_sorted[int(len(times_sorted) * 0.99)]
        result.total_chunks_fetched = total_fetched
        result.total_cache_hits = total_hits
        result.total_cache_misses = total_misses
        result.total_bytes_fetched = total_bytes
        total_accesses = total_hits + total_misses
        result.avg_cache_hit_ratio = total_hits / total_accesses if total_accesses else 0.0

    asyncio.run(_run_all())
    return result


def format_benchmark_markdown(result: BenchmarkResult) -> str:
    """Format a BenchmarkResult as a markdown summary."""
    lines = [
        f"# Benchmark: {result.scenario_name}",
        f"",
        f"**Model:** {result.model_id}",
        f"**Iterations:** {result.iterations} (+ {result.warmup_iterations} warmup)",
        f"**Timestamp:** {result.timestamp}",
        f"",
        "## Results",
        "",
        f"| Metric | Value |",
        f"|--------|-------|",
        f"| Avg inference | {result.avg_inference_ms:.1f} ms |",
        f"| Min inference | {result.min_inference_ms:.1f} ms |",
        f"| Max inference | {result.max_inference_ms:.1f} ms |",
        f"| P50 inference | {result.p50_inference_ms:.1f} ms |",
        f"| P95 inference | {result.p95_inference_ms:.1f} ms |",
        f"| P99 inference | {result.p99_inference_ms:.1f} ms |",
        f"| Total time | {result.total_time_ms:.1f} ms |",
        f"",
        "## Chunk Metrics",
        "",
        f"| Metric | Value |",
        f"|--------|-------|",
        f"| Chunks fetched | {result.total_chunks_fetched} |",
        f"| Cache hits | {result.total_cache_hits} |",
        f"| Cache misses | {result.total_cache_misses} |",
        f"| Avg hit ratio | {result.avg_cache_hit_ratio:.1%} |",
        f"| Bytes fetched | {_fmt_bytes(result.total_bytes_fetched)} |",
        f"",
        "## Environment",
        "",
        f"- Python: {result.python_version}",
        f"- PyTorch: {result.torch_version or 'N/A'}",
        f"- Platform: {result.platform}",
        f"",
    ]
    return "\n".join(lines)


def _fmt_bytes(n: int) -> str:
    if n == 0:
        return "0 B"
    for unit in ["B", "KB", "MB", "GB"]:
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"
