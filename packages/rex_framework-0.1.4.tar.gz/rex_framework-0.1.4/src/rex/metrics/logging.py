"""Logging configuration for Rex.

Status: Implemented

Configures structlog for console and JSON output with
secret redaction and consistent formatting.
"""

from __future__ import annotations

import logging
import sys
from typing import Any, Optional

from rex.api.config import ObservabilityConfig


# Fields that should be redacted from logs
_SENSITIVE_KEYS = frozenset({
    "token", "password", "secret", "api_key", "auth_token",
    "authorization", "cookie", "access_token", "refresh_token",
})


def _redact_value(value: Any) -> str:
    """Redact a sensitive value, showing only last 4 chars."""
    s = str(value)
    if len(s) <= 8:
        return "***"
    return f"***{s[-4:]}"


def _redact_event(event: dict[str, Any]) -> dict[str, Any]:
    """Redact sensitive fields from a log event."""
    redacted = dict(event)
    for key in _SENSITIVE_KEYS:
        if key in redacted:
            redacted[key] = _redact_value(redacted[key])
    return redacted


def configure_logging(
    config: Optional[ObservabilityConfig] = None,
) -> None:
    """Configure structlog for Rex.

    Args:
        config: Observability config. If None, uses defaults.
    """
    if config is None:
        config = ObservabilityConfig()

    log_level = getattr(logging, config.log_level.upper(), logging.INFO)

    # Configure standard logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=log_level,
    )

    import structlog

    shared_processors = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    if config.redact_secrets:
        shared_processors.append(lambda logger, method_name, event_dict: (
            _redact_event(event_dict)
        ))

    if config.log_format == "json":
        renderer = structlog.processors.JSONRenderer()
    elif config.log_format == "quiet":
        renderer = structlog.dev.ConsoleRenderer(colors=False)
    else:
        renderer = structlog.dev.ConsoleRenderer()

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    # Remove default handler, add ours
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(log_level)


def get_logger(name: str = "rex") -> Any:
    """Get a structlog logger for a subsystem."""
    import structlog
    return structlog.get_logger(name)
