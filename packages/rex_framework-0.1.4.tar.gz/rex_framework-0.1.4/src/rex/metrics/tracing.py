"""Tracing utilities for Rex.

Status: Implemented

Provides simple span-based tracing for measuring chunk fetch
latency, cache operations, and layer execution timing.
"""

from __future__ import annotations

import time
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Iterator, Optional


@dataclass
class Span:
    """A single traced operation."""
    name: str
    start_time: float
    end_time: float = 0.0
    duration_ms: float = 0.0
    attributes: dict[str, Any] = field(default_factory=dict)
    children: list[Span] = field(default_factory=list)

    def finish(self) -> None:
        self.end_time = time.perf_counter()
        self.duration_ms = (self.end_time - self.start_time) * 1000


class Tracer:
    """Simple span-based tracer for Rex operations.

    Provides hierarchical tracing with attributes for observability.
    Not a full OpenTelemetry implementation; designed for debuggability.

    Args:
        enabled: Whether tracing is active.
    """

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled
        self._spans: list[Span] = []
        self._active: list[Span] = []

    @contextmanager
    def start_span(
        self,
        name: str,
        **attributes: Any,
    ) -> Iterator[Optional[Span]]:
        """Context manager for a traced operation.

        Args:
            name: Span name (e.g., "chunk.fetch", "layer.execute").
            **attributes: Key-value metadata attached to the span.

        Yields:
            Span instance (or None if tracing disabled).
        """
        if not self.enabled:
            yield None
            return

        span = Span(name=name, start_time=time.perf_counter(), attributes=attributes)

        if self._active:
            self._active[-1].children.append(span)

        self._active.append(span)
        try:
            yield span
        finally:
            span.finish()
            self._active.pop()

    def record_span(
        self,
        name: str,
        duration_ms: float,
        **attributes: Any,
    ) -> None:
        """Record a completed span directly."""
        if not self.enabled:
            return
        span = Span(
            name=name,
            start_time=time.perf_counter() - duration_ms / 1000,
            attributes=attributes,
        )
        span.finish()
        self._spans.append(span)

    def get_spans(self) -> list[Span]:
        """Get all completed spans."""
        return list(self._spans)

    def get_summary(self) -> dict[str, Any]:
        """Get aggregated timing summary by span name."""
        summary: dict[str, dict[str, Any]] = {}
        all_spans = list(self._spans)
        # Flatten children
        def _flatten(spans: list[Span]) -> list[Span]:
            result = []
            for s in spans:
                result.append(s)
                result.extend(_flatten(s.children))
            return result

        flat = _flatten(all_spans)
        by_name: dict[str, list[Span]] = defaultdict(list)
        for s in flat:
            by_name[s.name].append(s)

        for name, spans in by_name.items():
            durations = [s.duration_ms for s in spans]
            summary[name] = {
                "count": len(spans),
                "total_ms": sum(durations),
                "avg_ms": sum(durations) / len(durations),
                "min_ms": min(durations),
                "max_ms": max(durations),
            }
        return summary

    def reset(self) -> None:
        """Clear all recorded spans."""
        self._spans.clear()
        self._active.clear()

    def export_json(self) -> list[dict[str, Any]]:
        """Export spans as JSON-serializable list."""
        def _to_dict(span: Span) -> dict[str, Any]:
            return {
                "name": span.name,
                "duration_ms": span.duration_ms,
                "attributes": span.attributes,
                "children": [_to_dict(c) for c in span.children],
            }
        return [_to_dict(s) for s in self._spans]


# Global tracer instance
_global_tracer = Tracer(enabled=True)


def get_tracer() -> Tracer:
    """Get the global tracer instance."""
    return _global_tracer


def set_tracer(tracer: Tracer) -> None:
    """Replace the global tracer instance."""
    global _global_tracer
    _global_tracer = tracer
