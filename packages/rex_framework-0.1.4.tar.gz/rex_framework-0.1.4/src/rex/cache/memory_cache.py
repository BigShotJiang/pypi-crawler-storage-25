"""
In-memory LRU cache for chunk data with pluggable eviction policies.

Provides an asyncio-safe cache that tracks exact byte accounting,
supports configurable capacity limits, and integrates with the
eviction policy abstraction for flexible victim selection.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import structlog

from rex.cache.policies import CacheEntry, EvictionPolicy, LRUPolicy
from rex.core.invariants import InvariantChecker

logger = structlog.get_logger(__name__)


@dataclass
class CacheStats:
    """Statistics snapshot for the memory cache."""
    hit_count: int = 0
    miss_count: int = 0
    eviction_count: int = 0
    insertion_count: int = 0
    rejection_count: int = 0
    current_bytes: int = 0
    current_entries: int = 0
    max_bytes: int = 0

    @property
    def total_requests(self) -> int:
        return self.hit_count + self.miss_count

    @property
    def hit_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.hit_count / self.total_requests


class MemoryCache:
    """Async-safe in-memory cache for chunk data with pluggable eviction.

    Features:
        - Configurable max_bytes capacity with exact byte tracking.
        - Pluggable eviction policy (defaults to LRU).
        - Thread-safe via asyncio.Lock (designed for single-event-loop use).
        - Hit/miss/eviction statistics.
        - Automatic eviction when insertion would exceed capacity.

    Args:
        max_bytes: Maximum byte capacity of the cache.
        policy: Eviction policy instance. Defaults to LRUPolicy.
    """

    def __init__(
        self,
        max_bytes: int,
        policy: Optional[EvictionPolicy] = None,
        invariant_checker: Optional[InvariantChecker] = None,
        get_resident_bytes: Optional[Callable[[], int]] = None,
    ) -> None:
        if max_bytes <= 0:
            raise ValueError(f"max_bytes must be positive, got {max_bytes}")

        self._max_bytes = max_bytes
        self._policy = policy or LRUPolicy()
        self._invariant_checker = invariant_checker
        self._get_resident_bytes = get_resident_bytes
        self._entries: dict[str, CacheEntry] = {}
        self._current_bytes: int = 0
        self._lock = asyncio.Lock()
        self._log = logger.bind(component="memory_cache")

        # Statistics
        self._hit_count: int = 0
        self._miss_count: int = 0
        self._eviction_count: int = 0
        self._insertion_count: int = 0
        self._rejection_count: int = 0

    @property
    def max_bytes(self) -> int:
        """Maximum byte capacity of the cache."""
        return self._max_bytes

    @property
    def policy(self) -> EvictionPolicy:
        """Active eviction policy."""
        return self._policy

    @property
    def invariant_checker(self) -> Optional[InvariantChecker]:
        """Active invariant checker, or None if not configured."""
        return self._invariant_checker

    @property
    def lock(self) -> asyncio.Lock:
        """Expose the internal lock for external coordination if needed."""
        return self._lock

    def _run_invariant_check(self) -> None:
        """Run the invariant check with current byte counts if a checker is configured.

        Uses *get_resident_bytes* (if provided) for the resident portion of local bytes
        so that the check reflects the full local-residency picture, not just the
        in-memory cache tier.
        """
        if self._invariant_checker is None:
            return
        resident = self._get_resident_bytes() if self._get_resident_bytes is not None else 0
        self._invariant_checker.check_invariant(
            resident_bytes=resident,
            cached_bytes=self._current_bytes,
        )

    async def get(self, chunk_id: str) -> Optional[bytes]:
        """Retrieve a chunk from the cache.

        Updates access metadata (last_access_time, access_count) on hit.

        Args:
            chunk_id: Unique identifier for the chunk.

        Returns:
            The chunk data bytes, or None if not in cache.
        """
        async with self._lock:
            entry = self._entries.get(chunk_id)
            if entry is None:
                self._miss_count += 1
                self._log.debug("cache_miss", chunk_id=chunk_id)
                return None

            self._hit_count += 1
            self._policy.record_access(chunk_id, entry)
            self._log.debug("cache_hit", chunk_id=chunk_id, bytes=len(entry.data))
            return entry.data

    async def put(self, chunk_id: str, data: bytes) -> bool:
        """Insert a chunk into the cache.

        If the chunk already exists, it is updated (touch + replace data).
        If the insertion would exceed capacity, the eviction policy is used
        to make room. If the single item exceeds total capacity, the put
        is rejected.

        Args:
            chunk_id: Unique identifier for the chunk.
            data: Raw chunk data bytes.

        Returns:
            True if the chunk was inserted, False if rejected (item too large
            for cache even after eviction).
        """
        data_size = len(data)

        async with self._lock:
            # If chunk already present, update it
            if chunk_id in self._entries:
                old_entry = self._entries[chunk_id]
                size_delta = data_size - old_entry.bytes_size
                self._current_bytes += size_delta

                # Evict if we exceeded capacity after update
                await self._evict_until_fit()

                new_entry = CacheEntry(
                    chunk_id=chunk_id,
                    data=data,
                    last_access_time=time.monotonic(),
                    access_count=old_entry.access_count + 1,
                    prefetch_score=old_entry.prefetch_score,
                )
                self._entries[chunk_id] = new_entry
                self._insertion_count += 1
                self._log.debug(
                    "cache_updated",
                    chunk_id=chunk_id,
                    bytes_size=data_size,
                    size_delta=size_delta,
                    current_bytes=self._current_bytes,
                )
                self._run_invariant_check()
                return True

            # New insertion — check if single item fits
            if data_size > self._max_bytes:
                self._rejection_count += 1
                self._log.warning(
                    "cache_rejection_item_too_large",
                    chunk_id=chunk_id,
                    item_bytes=data_size,
                    max_bytes=self._max_bytes,
                )
                return False

            # Evict until there's room
            await self._evict_until_fit(target_free=data_size)

            entry = CacheEntry(
                chunk_id=chunk_id,
                data=data,
                last_access_time=time.monotonic(),
                access_count=1,
                prefetch_score=0.0,
            )
            self._entries[chunk_id] = entry
            self._current_bytes += data_size
            self._insertion_count += 1
            self._policy.on_insert(chunk_id, entry)
            self._log.debug(
                "cache_insert",
                chunk_id=chunk_id,
                bytes_size=data_size,
                current_bytes=self._current_bytes,
                entries=len(self._entries),
            )
            self._run_invariant_check()
            return True

    async def evict(self, chunk_id: str) -> bool:
        """Evict a specific chunk from the cache.

        Args:
            chunk_id: Unique identifier for the chunk.

        Returns:
            True if the chunk was found and evicted, False otherwise.
        """
        async with self._lock:
            entry = self._entries.pop(chunk_id, None)
            if entry is None:
                self._log.debug("evict_miss", chunk_id=chunk_id)
                return False

            self._current_bytes -= entry.bytes_size
            self._eviction_count += 1
            self._policy.on_evict(chunk_id)
            self._log.debug(
                "cache_evict",
                chunk_id=chunk_id,
                freed_bytes=entry.bytes_size,
                current_bytes=self._current_bytes,
            )
            return True

    async def contains(self, chunk_id: str) -> bool:
        """Check if a chunk is in the cache (without updating access time)."""
        async with self._lock:
            return chunk_id in self._entries

    async def get_stats(self) -> CacheStats:
        """Return a snapshot of cache statistics."""
        async with self._lock:
            return CacheStats(
                hit_count=self._hit_count,
                miss_count=self._miss_count,
                eviction_count=self._eviction_count,
                insertion_count=self._insertion_count,
                rejection_count=self._rejection_count,
                current_bytes=self._current_bytes,
                current_entries=len(self._entries),
                max_bytes=self._max_bytes,
            )

    async def clear(self) -> None:
        """Remove all entries and reset statistics."""
        async with self._lock:
            count = len(self._entries)
            self._entries.clear()
            self._current_bytes = 0
            self._log.info(
                "cache_cleared",
                entries_removed=count,
                bytes_freed=self._current_bytes,
            )

    async def _evict_until_fit(self, target_free: int = 0) -> None:
        """Evict entries until there is room for *target_free* additional bytes.

        This is called while the lock is already held.
        """
        available = self._max_bytes - self._current_bytes
        while available < target_free and len(self._entries) > 0:
            try:
                victim_id = self._policy.select_victim(self._entries)
            except ValueError:
                self._log.warning(
                    "eviction_policy_failed",
                    msg="No victims available but still need space",
                )
                break

            victim = self._entries.pop(victim_id, None)
            if victim is None:
                break

            self._current_bytes -= victim.bytes_size
            self._eviction_count += 1
            available = self._max_bytes - self._current_bytes
            self._policy.on_evict(victim_id)
            self._log.debug(
                "evicted_to_make_room",
                victim_chunk_id=victim_id,
                freed_bytes=victim.bytes_size,
                available_after=available,
                needed=target_free,
            )

    def set_prefetch_score(self, chunk_id: str, score: float) -> None:
        """Update the prefetch score for a cached entry (non-async, lock-free).

        This is safe to call from async context because we only update a
        float field; the entry dict reference is stable.

        Args:
            chunk_id: Chunk to update.
            score: New prefetch score (0.0–1.0).
        """
        entry = self._entries.get(chunk_id)
        if entry is not None:
            entry.prefetch_score = max(0.0, min(1.0, score))


if __name__ == "__main__":
    async def _demo() -> None:
        cache = MemoryCache(max_bytes=1024)

        # Insert
        ok = await cache.put("chunk_a", b"x" * 200)
        assert ok
        ok = await cache.put("chunk_b", b"y" * 300)
        assert ok
        ok = await cache.put("chunk_c", b"z" * 400)
        assert ok

        # Hit
        data = await cache.get("chunk_a")
        assert data == b"x" * 200

        # Miss
        data = await cache.get("chunk_d")
        assert data is None

        # Overflow — insert something that requires eviction
        ok = await cache.put("chunk_d", b"w" * 500)
        assert ok  # should evict one entry

        stats = await cache.get_stats()
        print(f"Stats: {stats}")
        print(f"Hit rate: {stats.hit_rate:.2%}")

        # Rejection — item too large
        ok = await cache.put("chunk_huge", b"!" * 2000)
        assert not ok

        # Evict specific
        evicted = await cache.evict("chunk_b")
        print(f"Evicted chunk_b: {evicted}")

        stats = await cache.get_stats()
        print(f"Final stats: {stats}")

    asyncio.run(_demo())
    print("MemoryCache demo completed successfully.")
