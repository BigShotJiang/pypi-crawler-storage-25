"""Disk cache implementation.

Status: Implemented

Persistent cache backed by local filesystem.
Chunks are stored as individual files with content-hash filenames.
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional

from rex.core.errors import CacheError


class DiskCache:
    """Filesystem-backed cache for chunk data.

    Stores chunks as individual files in a directory structure.
    Uses content-addressable storage (SHA-256 hash as filename)
    for deduplication and integrity.

    Args:
        cache_dir: Directory for cached chunks.
        max_bytes: Maximum total cache size in bytes. 0 = unlimited.
    """

    def __init__(self, cache_dir: str | Path, max_bytes: int = 0) -> None:
        self.cache_dir = Path(cache_dir)
        self.max_bytes = max_bytes
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._current_bytes = self._compute_total_bytes()

    def get(self, key: str) -> Optional[bytes]:
        """Get cached data by key.

        Args:
            key: Cache key (typically chunk_id).

        Returns:
            Cached bytes, or None if not found.
        """
        filepath = self._key_path(key)
        if not filepath.exists():
            return None
        try:
            return filepath.read_bytes()
        except OSError:
            return None

    def put(self, key: str, data: bytes) -> bool:
        """Store data in cache.

        Args:
            key: Cache key.
            data: Chunk data bytes.

        Returns:
            True if stored successfully.
        """
        filepath = self._key_path(key)
        try:
            filepath.write_bytes(data)
            self._current_bytes += len(data)
            self._enforce_limit()
            return True
        except OSError as e:
            raise CacheError(f"Failed to write to disk cache: {e}") from e

    def contains(self, key: str) -> bool:
        """Check if key is in cache."""
        return self._key_path(key).exists()

    def evict(self, key: str) -> bool:
        """Remove a key from cache.

        Returns:
            True if the key was found and removed.
        """
        filepath = self._key_path(key)
        if filepath.exists():
            size = filepath.stat().st_size
            filepath.unlink()
            self._current_bytes = max(0, self._current_bytes - size)
            return True
        return False

    def clear(self) -> None:
        """Remove all cached files."""
        for f in self.cache_dir.iterdir():
            if f.is_file():
                f.unlink()
        self._current_bytes = 0

    def size_bytes(self) -> int:
        """Current cache size in bytes."""
        return self._current_bytes

    def _key_path(self, key: str) -> Path:
        """Get file path for a cache key."""
        # Sanitize key for filesystem
        safe = key.replace("/", "__").replace("\\", "__").replace("..", "_")
        return self.cache_dir / f"{safe}.cache"

    def _compute_total_bytes(self) -> int:
        total = 0
        for f in self.cache_dir.iterdir():
            if f.is_file():
                total += f.stat().st_size
        return total

    def _enforce_limit(self) -> None:
        """Evict oldest files if over limit."""
        if self.max_bytes <= 0:
            return
        while self._current_bytes > self.max_bytes:
            oldest = self._find_oldest()
            if oldest is None:
                break
            self.evict(oldest)

    def _find_oldest(self) -> Optional[str]:
        """Find the oldest cached file."""
        oldest_path = None
        oldest_time = float("inf")
        for f in self.cache_dir.iterdir():
            if f.is_file():
                mtime = f.stat().st_mtime
                if mtime < oldest_time:
                    oldest_time = mtime
                    oldest_path = f.stem.replace(".cache", "")
        return oldest_path
