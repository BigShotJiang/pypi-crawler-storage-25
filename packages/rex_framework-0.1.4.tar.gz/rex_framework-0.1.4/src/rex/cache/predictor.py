"""Reuse prediction helpers for cache and prefetch planning.

Implements a small online predictor that mixes an exponential moving average
with a Beta posterior so the estimate stays well-behaved on sparse traces.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ReuseStats:
    chunk_id: str
    alpha: float = 1.0
    beta: float = 1.0
    ema_probability: float = 0.5
    observations: int = 0


class EMABayesianReusePredictor:
    """Estimate short-horizon chunk reuse probabilities online."""

    def __init__(
        self,
        ema_decay: float = 0.8,
        prior_alpha: float = 1.0,
        prior_beta: float = 1.0,
    ) -> None:
        self.ema_decay = ema_decay
        self.prior_alpha = prior_alpha
        self.prior_beta = prior_beta
        self._stats: dict[str, ReuseStats] = {}

    def _get(self, chunk_id: str) -> ReuseStats:
        if chunk_id not in self._stats:
            self._stats[chunk_id] = ReuseStats(
                chunk_id=chunk_id,
                alpha=self.prior_alpha,
                beta=self.prior_beta,
                ema_probability=self.prior_alpha / (self.prior_alpha + self.prior_beta),
            )
        return self._stats[chunk_id]

    def observe_insert(self, chunk_id: str) -> None:
        self._get(chunk_id)

    def observe_access(self, chunk_id: str, reused: bool) -> None:
        stats = self._get(chunk_id)
        if reused:
            stats.alpha += 1.0
        else:
            stats.beta += 1.0
        observed = 1.0 if reused else 0.0
        stats.ema_probability = (
            self.ema_decay * stats.ema_probability
            + (1.0 - self.ema_decay) * observed
        )
        stats.observations += 1

    def predict_reuse_probability(self, chunk_id: str, horizon: int = 1) -> float:
        stats = self._get(chunk_id)
        posterior_mean = stats.alpha / (stats.alpha + stats.beta)
        blended = 0.5 * posterior_mean + 0.5 * stats.ema_probability
        horizon = max(1, horizon)
        return max(0.0, min(1.0, blended ** (1.0 / horizon)))

    def confidence(self, chunk_id: str, max_observations: int = 10) -> float:
        """Return a confidence score (0-1) based on observation count.

        Args:
            chunk_id: Chunk identifier.
            max_observations: Observation count at which confidence reaches 1.0.

        Returns:
            Confidence in [0.0, 1.0].
        """
        stats = self._get(chunk_id)
        return min(1.0, stats.observations / max(1, max_observations))

    def feature_vector(self, chunk_id: str) -> dict:
        """Return a feature dictionary for the given chunk.

        Returns:
            Dict with keys: probability, confidence, observations,
            ema_probability, posterior_mean.
        """
        stats = self._get(chunk_id)
        posterior_mean = stats.alpha / (stats.alpha + stats.beta)
        return {
            "probability": self.predict_reuse_probability(chunk_id),
            "confidence": self.confidence(chunk_id),
            "observations": stats.observations,
            "ema_probability": stats.ema_probability,
            "posterior_mean": posterior_mean,
        }

    def snapshot(self) -> dict[str, ReuseStats]:
        return dict(self._stats)