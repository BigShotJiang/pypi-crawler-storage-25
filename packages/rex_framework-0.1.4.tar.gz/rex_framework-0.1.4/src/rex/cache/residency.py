"""
Residency accounting tracker for the Rex framework.

Tracks which chunks are currently resident in memory, cached on disk,
or present locally in any form. Provides byte accounting for invariant
enforcement and cache management decisions.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ResidencyRecord:
    """Record tracking the state and byte size of a single chunk."""
    chunk_id: str
    bytes_size: int
    is_resident: bool = False
    is_cached: bool = False


class ResidencyTracker:
    """Thread-safe tracker for chunk residency and caching state.

    Maintains an authoritative ledger of which chunks are resident in
    memory, which are cached, and total byte counts for each. This is
    the source of truth for the invariant checker and cache capacity
    management.

    All public methods are thread-safe via an internal lock.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._records: dict[str, ResidencyRecord] = {}
        self._resident_bytes: int = 0
        self._cached_bytes: int = 0
        self._log = logger.bind(component="residency_tracker")

    def record_resident(self, chunk_id: str, bytes_size: int) -> None:
        """Mark a chunk as resident in CPU/GPU memory.

        If the chunk is already resident, this updates the byte count.
        If the chunk was previously only cached, it becomes resident
        (and cached bytes are unchanged since the data remains cached
        as well).

        Args:
            chunk_id: Unique identifier for the chunk.
            bytes_size: Size of the chunk in bytes.
        """
        with self._lock:
            existing = self._records.get(chunk_id)
            if existing is not None and existing.is_resident:
                # Already resident — adjust byte count if size changed
                delta = bytes_size - existing.bytes_size
                if delta != 0:
                    self._resident_bytes += delta
                    existing.bytes_size = bytes_size
                self._log.debug(
                    "chunk_already_resident",
                    chunk_id=chunk_id,
                    bytes_size=bytes_size,
                )
                return

            if existing is not None and existing.is_cached:
                # Promote from cached to resident
                self._resident_bytes += bytes_size
                existing.is_resident = True
                # If cached size differs, update cached too
                cached_delta = bytes_size - existing.bytes_size
                if cached_delta != 0:
                    self._cached_bytes += cached_delta
                    existing.bytes_size = bytes_size
                self._log.debug(
                    "chunk_promoted_to_resident",
                    chunk_id=chunk_id,
                    bytes_size=bytes_size,
                )
                return

            # New chunk becoming resident
            self._records[chunk_id] = ResidencyRecord(
                chunk_id=chunk_id,
                bytes_size=bytes_size,
                is_resident=True,
                is_cached=False,
            )
            self._resident_bytes += bytes_size
            self._log.debug(
                "chunk_recorded_resident",
                chunk_id=chunk_id,
                bytes_size=bytes_size,
                total_resident_bytes=self._resident_bytes,
            )

    def record_cached(self, chunk_id: str, bytes_size: int) -> None:
        """Mark a chunk as present in local cache storage.

        Args:
            chunk_id: Unique identifier for the chunk.
            bytes_size: Size of the chunk data in bytes.
        """
        with self._lock:
            existing = self._records.get(chunk_id)
            if existing is not None and existing.is_cached:
                delta = bytes_size - existing.bytes_size
                if delta != 0:
                    self._cached_bytes += delta
                    existing.bytes_size = bytes_size
                self._log.debug(
                    "chunk_already_cached",
                    chunk_id=chunk_id,
                    bytes_size=bytes_size,
                )
                return

            if existing is not None and existing.is_resident:
                # Resident chunk is also being cached
                self._cached_bytes += bytes_size
                existing.is_cached = True
                self._log.debug(
                    "resident_chunk_also_cached",
                    chunk_id=chunk_id,
                    bytes_size=bytes_size,
                )
                return

            # New cached chunk (not resident)
            self._records[chunk_id] = ResidencyRecord(
                chunk_id=chunk_id,
                bytes_size=bytes_size,
                is_resident=False,
                is_cached=True,
            )
            self._cached_bytes += bytes_size
            self._log.debug(
                "chunk_recorded_cached",
                chunk_id=chunk_id,
                bytes_size=bytes_size,
                total_cached_bytes=self._cached_bytes,
            )

    def record_evicted(self, chunk_id: str) -> Optional[int]:
        """Remove a chunk from all local tracking (evicted from cache and memory).

        Args:
            chunk_id: Unique identifier for the chunk to evict.

        Returns:
            The byte size of the evicted chunk, or None if the chunk
            was not tracked.
        """
        with self._lock:
            record = self._records.pop(chunk_id, None)
            if record is None:
                self._log.warning("evict_unknown_chunk", chunk_id=chunk_id)
                return None

            bytes_freed = 0
            if record.is_resident:
                self._resident_bytes -= record.bytes_size
                bytes_freed += record.bytes_size
            if record.is_cached:
                self._cached_bytes -= record.bytes_size
                bytes_freed += record.bytes_size

            # Ensure we don't double-count if both resident and cached
            if record.is_resident and record.is_cached:
                bytes_freed = record.bytes_size

            self._log.debug(
                "chunk_evicted",
                chunk_id=chunk_id,
                bytes_freed=bytes_freed,
                total_resident_bytes=self._resident_bytes,
                total_cached_bytes=self._cached_bytes,
            )
            return record.bytes_size

    def demote_resident(self, chunk_id: str) -> Optional[int]:
        """Demote a resident chunk to cached-only (release from memory).

        The chunk stays in cache but is no longer occupying resident memory.

        Args:
            chunk_id: Unique identifier for the chunk.

        Returns:
            Bytes freed from resident memory, or None if not tracked.
        """
        with self._lock:
            record = self._records.get(chunk_id)
            if record is None or not record.is_resident:
                return None

            bytes_freed = record.bytes_size
            self._resident_bytes -= bytes_freed
            record.is_resident = False
            # If not cached, the chunk is now fully evicted — remove it
            if not record.is_cached:
                self._records.pop(chunk_id, None)

            self._log.debug(
                "chunk_demoted",
                chunk_id=chunk_id,
                bytes_freed=bytes_freed,
                still_cached=record.is_cached,
                total_resident_bytes=self._resident_bytes,
            )
            return bytes_freed

    def demote_cached(self, chunk_id: str) -> Optional[int]:
        """Remove a chunk from cache (but keep resident if applicable).

        Args:
            chunk_id: Unique identifier for the chunk.

        Returns:
            Bytes freed from cache, or None if not tracked.
        """
        with self._lock:
            record = self._records.get(chunk_id)
            if record is None or not record.is_cached:
                return None

            bytes_freed = record.bytes_size
            self._cached_bytes -= bytes_freed
            record.is_cached = False
            if not record.is_resident:
                self._records.pop(chunk_id, None)

            self._log.debug(
                "chunk_cache_removed",
                chunk_id=chunk_id,
                bytes_freed=bytes_freed,
                still_resident=record.is_resident,
                total_cached_bytes=self._cached_bytes,
            )
            return bytes_freed

    def get_resident_bytes(self) -> int:
        """Return total bytes of all chunks currently resident in memory."""
        with self._lock:
            return self._resident_bytes

    def get_cached_bytes(self) -> int:
        """Return total bytes of all chunks in local cache."""
        with self._lock:
            return self._cached_bytes

    def get_total_local_bytes(self) -> int:
        """Return total local bytes (resident ∪ cached, no double-counting)."""
        with self._lock:
            total = 0
            for record in self._records.values():
                if record.is_resident or record.is_cached:
                    total += record.bytes_size
            return total

    def get_resident_chunk_ids(self) -> set[str]:
        """Return set of chunk IDs currently resident in memory."""
        with self._lock:
            return {
                cid for cid, rec in self._records.items() if rec.is_resident
            }

    def get_cached_chunk_ids(self) -> set[str]:
        """Return set of chunk IDs currently in local cache."""
        with self._lock:
            return {
                cid for cid, rec in self._records.items() if rec.is_cached
            }

    def get_record(self, chunk_id: str) -> Optional[ResidencyRecord]:
        """Look up a single residency record."""
        with self._lock:
            return self._records.get(chunk_id)

    def clear(self) -> None:
        """Clear all tracking state. Used during shutdown or reset."""
        with self._lock:
            count = len(self._records)
            self._records.clear()
            self._resident_bytes = 0
            self._cached_bytes = 0
            self._log.info("residency_cleared", chunks_cleared=count)

    def summary(self) -> dict[str, int | float]:
        """Return a summary dict of current residency state."""
        with self._lock:
            total_unique = len(self._records)
            resident_count = sum(
                1 for r in self._records.values() if r.is_resident
            )
            cached_count = sum(
                1 for r in self._records.values() if r.is_cached
            )
            both_count = sum(
                1 for r in self._records.values()
                if r.is_resident and r.is_cached
            )
            total_local = sum(
                r.bytes_size
                for r in self._records.values()
                if r.is_resident or r.is_cached
            )
            return {
                "total_tracked_chunks": total_unique,
                "resident_chunks": resident_count,
                "cached_chunks": cached_count,
                "resident_and_cached_chunks": both_count,
                "resident_bytes": self._resident_bytes,
                "cached_bytes": self._cached_bytes,
                "total_local_bytes": total_local,
            }
