"""
Eviction policy implementations for the Rex cache subsystem.

Provides pluggable eviction strategies that select which cached chunk
to evict when the cache is full. Each policy implements a common
interface and can be swapped at runtime.
"""

from __future__ import annotations

import abc
import time
from dataclasses import dataclass, field
from typing import Optional

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class CacheEntry:
    """Represents a single entry in the cache with metadata for eviction decisions."""
    chunk_id: str
    data: bytes
    last_access_time: float = field(default_factory=time.monotonic)
    access_count: int = 1
    prefetch_score: float = 0.0

    @property
    def bytes_size(self) -> int:
        return len(self.data)

    def touch(self) -> None:
        """Update last access time and increment access count."""
        self.last_access_time = time.monotonic()
        self.access_count += 1


class EvictionPolicy(abc.ABC):
    """Abstract base class for cache eviction policies.

    Subclasses must implement :meth:`select_victim` to choose which
    chunk to evict from a set of candidates.
    """

    @abc.abstractmethod
    def select_victim(self, candidates: dict[str, CacheEntry]) -> str:
        """Select a chunk ID to evict from the given candidates.

        Args:
            candidates: Mapping of chunk_id to CacheEntry for all
                chunks currently in the cache.

        Returns:
            The chunk_id of the entry selected for eviction.

        Raises:
            ValueError: If candidates is empty.
        """
        ...

    def record_access(self, chunk_id: str, entry: CacheEntry) -> None:
        """Called when a cache entry is accessed. Default is a no-op.

        Subclasses may override to maintain internal state (e.g., frequency
        counters, decay timers).
        """
        entry.touch()

    def on_insert(self, chunk_id: str, entry: CacheEntry) -> None:
        """Called when a new entry is inserted. Default is a no-op."""
        entry.touch()

    def on_evict(self, chunk_id: str) -> None:
        """Called when an entry is evicted. Default is a no-op."""
        pass

    def policy_name(self) -> str:
        """Return a human-readable name for this policy."""
        return self.__class__.__name__


class LRUPolicy(EvictionPolicy):
    """Least Recently Used eviction policy.

    Evicts the chunk that was accessed least recently. This is the
    default and simplest policy, providing good general-purpose
    behavior for sequential access patterns.
    """

    def select_victim(self, candidates: dict[str, CacheEntry]) -> str:
        """Return the chunk_id with the oldest last_access_time."""
        if not candidates:
            raise ValueError("Cannot select victim from empty candidate set")

        victim_id = min(
            candidates,
            key=lambda cid: candidates[cid].last_access_time,
        )
        logger.debug(
            "lru_victim_selected",
            victim_chunk_id=victim_id,
            candidate_count=len(candidates),
        )
        return victim_id


class LFUPolicy(EvictionPolicy):
    """Least Frequently Used eviction policy.

    Evicts the chunk that has been accessed the fewest times. Ties
    are broken by least recently used (LRU) to avoid stale entries
    from persisting indefinitely.
    """

    def select_victim(self, candidates: dict[str, CacheEntry]) -> str:
        """Return the chunk_id with the lowest access_count, breaking ties by LRU."""
        if not candidates:
            raise ValueError("Cannot select victim from empty candidate set")

        victim_id = min(
            candidates,
            key=lambda cid: (
                candidates[cid].access_count,
                candidates[cid].last_access_time,
            ),
        )
        logger.debug(
            "lfu_victim_selected",
            victim_chunk_id=victim_id,
            candidate_count=len(candidates),
        )
        return victim_id


class WeightedUtilityPolicy(EvictionPolicy):
    """Weighted utility eviction policy.

    Computes a utility score for each candidate:

        score = alpha * recency + beta * frequency + gamma * prefetch_score

    where:
        - *recency* is the normalized time since last access (0 = just
          accessed, 1 = oldest in the set).
        - *frequency* is the normalized access count (0 = least accessed,
          1 = most accessed).
        - *prefetch_score* is a user-provided hint (0..1) indicating
          predicted future usefulness.

    The chunk with the **lowest** utility score is evicted.

    Args:
        alpha: Weight for recency component (higher = favor recent access).
        beta: Weight for frequency component (higher = favor popular items).
        gamma: Weight for prefetch score component (higher = trust prefetch hints).
    """

    def __init__(
        self,
        alpha: float = 0.5,
        beta: float = 0.3,
        gamma: float = 0.2,
    ) -> None:
        if alpha < 0 or beta < 0 or gamma < 0:
            raise ValueError("Weights must be non-negative")
        if alpha + beta + gamma == 0:
            raise ValueError("At least one weight must be positive")
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self._log = logger.bind(component="weighted_utility_policy")

    def select_victim(self, candidates: dict[str, CacheEntry]) -> str:
        """Return the chunk_id with the lowest weighted utility score."""
        if not candidates:
            raise ValueError("Cannot select victim from empty candidate set")

        now = time.monotonic()
        times = [e.last_access_time for e in candidates.values()]
        counts = [e.access_count for e in candidates.values()]
        prefetch_scores = [e.prefetch_score for e in candidates.values()]

        min_time = min(times)
        max_time = max(times)
        time_range = max_time - min_time if max_time != min_time else 1.0

        min_count = min(counts)
        max_count = max(counts)
        count_range = max_count - min_count if max_count != min_count else 1.0

        min_prefetch = min(prefetch_scores)
        max_prefetch = max(prefetch_scores)
        prefetch_range = (
            max_prefetch - min_prefetch if max_prefetch != min_prefetch else 1.0
        )

        def utility_score(entry: CacheEntry) -> float:
            recency = (now - entry.last_access_time) / time_range
            frequency = (entry.access_count - min_count) / count_range
            prefetch = (
                (entry.prefetch_score - min_prefetch) / prefetch_range
                if prefetch_range > 0
                else 0.0
            )
            return (
                self.alpha * recency
                + self.beta * (1.0 - frequency)
                + self.gamma * (1.0 - prefetch)
            )

        victim_id = min(candidates, key=lambda cid: utility_score(candidates[cid]))
        self._log.debug(
            "weighted_utility_victim_selected",
            victim_chunk_id=victim_id,
            candidate_count=len(candidates),
            alpha=self.alpha,
            beta=self.beta,
            gamma=self.gamma,
        )
        return victim_id

    def policy_name(self) -> str:
        return f"WeightedUtility(alpha={self.alpha}, beta={self.beta}, gamma={self.gamma})"


class ProbabilisticUtilityPolicy(EvictionPolicy):
    """Evict the chunk with the lowest expected future value density.

    This is the concrete implementation of the stochastic eviction rule from
    the redesign document. Expected future value is approximated as:

        reuse_probability * (latency_ms + decode_ms) / chunk_size

    When no predictor or cost model is supplied, the policy falls back to the
    entry's prefetch_score and byte size as a conservative heuristic.
    """

    def __init__(
        self,
        predictor: Optional[object] = None,
        cost_model: Optional[object] = None,
        default_reuse_probability: float = 0.1,
        confidence_threshold: float = 0.0,
    ) -> None:
        self.predictor = predictor
        self.cost_model = cost_model
        self.default_reuse_probability = default_reuse_probability
        self.confidence_threshold = confidence_threshold
        self._log = logger.bind(component="probabilistic_utility_policy")

    def _predict_probability(self, chunk_id: str, entry: CacheEntry) -> float:
        if self.predictor is not None and hasattr(self.predictor, "predict_reuse_probability"):
            value = self.predictor.predict_reuse_probability(chunk_id)
            return max(0.0, min(1.0, float(value)))
        return max(0.0, min(1.0, float(entry.prefetch_score or self.default_reuse_probability)))

    def _value_density(self, chunk_id: str, entry: CacheEntry) -> float:
        probability = self._predict_probability(chunk_id, entry)

        # Confidence-aware blending: fall back toward LRU when confidence is low
        if self.confidence_threshold > 0.0 and self.predictor is not None and hasattr(
            self.predictor, "confidence"
        ):
            conf = float(self.predictor.confidence(chunk_id))
            if conf < self.confidence_threshold:
                density = probability / max(1, entry.bytes_size)
                lru_score = 1.0 / max(1e-6, (time.monotonic() - entry.last_access_time + 1e-6))
                blended = conf * density + (1.0 - conf) * lru_score
                return blended

        if self.cost_model is not None and hasattr(self.cost_model, "value_density"):
            return float(self.cost_model.value_density(chunk_id, probability))
        return probability / max(1, entry.bytes_size)

    def select_victim(self, candidates: dict[str, CacheEntry]) -> str:
        if not candidates:
            raise ValueError("Cannot select victim from empty candidate set")

        victim_id = min(candidates, key=lambda cid: self._value_density(cid, candidates[cid]))
        self._log.debug(
            "probabilistic_utility_victim_selected",
            victim_chunk_id=victim_id,
            candidate_count=len(candidates),
        )
        return victim_id

    def record_access(self, chunk_id: str, entry: CacheEntry) -> None:
        entry.touch()
        if self.predictor is not None and hasattr(self.predictor, "observe_access"):
            self.predictor.observe_access(chunk_id, reused=True)

    def on_insert(self, chunk_id: str, entry: CacheEntry) -> None:
        entry.touch()
        if self.predictor is not None and hasattr(self.predictor, "observe_insert"):
            self.predictor.observe_insert(chunk_id)

    def policy_name(self) -> str:
        return "ProbabilisticUtility"


def create_policy(
    policy_name: str,
    alpha: float = 0.5,
    beta: float = 0.3,
    gamma: float = 0.2,
) -> EvictionPolicy:
    """Factory function to create an eviction policy by name.

    Args:
        policy_name: One of 'lru', 'lfu', 'weighted_utility', 'probabilistic_utility'.
        alpha: Weight for WeightedUtilityPolicy recency.
        beta: Weight for WeightedUtilityPolicy frequency.
        gamma: Weight for WeightedUtilityPolicy prefetch score.

    Returns:
        An EvictionPolicy instance.

    Raises:
        ValueError: If the policy name is unknown.
    """
    name_lower = policy_name.lower().strip()
    if name_lower == "lru":
        return LRUPolicy()
    elif name_lower == "lfu":
        return LFUPolicy()
    elif name_lower in ("weighted_utility", "weighted-utility", "wu"):
        return WeightedUtilityPolicy(alpha=alpha, beta=beta, gamma=gamma)
    elif name_lower in ("probabilistic_utility", "probabilistic-utility", "pu"):
        return ProbabilisticUtilityPolicy()
    else:
        raise ValueError(
            f"Unknown eviction policy '{policy_name}'. "
            f"Valid options: lru, lfu, weighted_utility, probabilistic_utility"
        )


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    print("Policies module loaded successfully.")

    # Quick sanity test
    entries = {
        "a": CacheEntry(chunk_id="a", data=b"x" * 100, access_count=10, prefetch_score=0.9),
        "b": CacheEntry(chunk_id="b", data=b"y" * 200, access_count=1, prefetch_score=0.1),
        "c": CacheEntry(chunk_id="c", data=b"z" * 150, access_count=5, prefetch_score=0.5),
    }
    # Make "a" old
    entries["a"].last_access_time = time.monotonic() - 100.0
    entries["c"].touch()  # "c" is most recent

    lru = LRUPolicy()
    print(f"LRU victim: {lru.select_victim(entries)}")  # should be "a"

    lfu = LFUPolicy()
    print(f"LFU victim: {lfu.select_victim(entries)}")  # should be "b"

    wu = WeightedUtilityPolicy(alpha=0.5, beta=0.3, gamma=0.2)
    print(f"WU victim: {wu.select_victim(entries)}")
