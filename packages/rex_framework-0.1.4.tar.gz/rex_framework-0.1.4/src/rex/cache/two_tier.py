"""
Two-tier (memory + disk) cache for the Rex framework.

Provides a unified cache interface that checks memory cache first,
then falls back to disk cache, and finally returns None if not found.
Writes go to both tiers.
"""

from __future__ import annotations

import abc
import time
from typing import Optional

import structlog

from rex.cache.disk_cache import DiskCache
from rex.cache.memory_cache import CacheStats, MemoryCache

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Target 5: Multi-Tier Control — explicit policy + third-tier abstraction
# ---------------------------------------------------------------------------

class TierControlPolicy(abc.ABC):
    """Abstract policy that decides whether a chunk should be promoted between tiers."""

    @abc.abstractmethod
    def should_promote(
        self,
        chunk_id: str,
        access_count: int,
        size_bytes: int,
    ) -> bool:
        """Return True if the chunk should be promoted to a higher tier.

        Args:
            chunk_id: Unique chunk identifier.
            access_count: Number of times the chunk has been accessed.
            size_bytes: Size of the chunk in bytes.
        """
        ...


class FrequencyBasedTierControlPolicy(TierControlPolicy):
    """Promote chunks that have been accessed at least ``min_accesses`` times.

    Args:
        min_accesses: Minimum access count required for promotion.
    """

    def __init__(self, min_accesses: int = 2) -> None:
        self.min_accesses = min_accesses

    def should_promote(self, chunk_id: str, access_count: int, size_bytes: int) -> bool:
        return access_count >= self.min_accesses


class AlwaysPromotePolicy(TierControlPolicy):
    """Always promote chunks to the higher tier."""

    def should_promote(self, chunk_id: str, access_count: int, size_bytes: int) -> bool:
        return True


class NeverPromotePolicy(TierControlPolicy):
    """Never promote chunks to the higher tier."""

    def should_promote(self, chunk_id: str, access_count: int, size_bytes: int) -> bool:
        return False


class ThirdTierBackend(abc.ABC):
    """Abstract interface for an optional third-tier cache (e.g. object storage).

    Implementations can back the cache with a slow but large storage layer
    beyond disk (e.g. S3-compatible store, NFS).
    """

    @abc.abstractmethod
    def get(self, chunk_id: str) -> Optional[bytes]:
        """Retrieve chunk data from the third tier.

        Returns:
            Chunk bytes, or ``None`` if not found.
        """
        ...

    @abc.abstractmethod
    def put(self, chunk_id: str, data: bytes) -> None:
        """Store chunk data in the third tier."""
        ...


class TwoTierCache:
    """Unified two-tier cache combining memory and disk storage.

    Provides the same async interface as :class:`MemoryCache` while
    transparently layering a persistent disk cache underneath.  Look-ups
    check the fast memory tier first; on a miss the disk tier is queried
    and, on a hit, the entry is promoted back into memory.  Writes go to
    both tiers so that data survives process restarts.

    Eviction operates **only** on the memory tier — the disk tier retains
    entries for persistence across restarts.  Call :meth:`clear_disk` to
    explicitly purge disk entries as well.

    Args:
        memory_cache: The underlying :class:`MemoryCache` instance.
        disk_cache: An optional :class:`DiskCache`.  When ``None`` the
            wrapper behaves as a thin pass-through to *memory_cache*.
    """

    def __init__(
        self,
        memory_cache: MemoryCache,
        disk_cache: Optional[DiskCache] = None,
        control_policy: Optional[TierControlPolicy] = None,
        third_tier: Optional[ThirdTierBackend] = None,
    ) -> None:
        self._memory_cache = memory_cache
        self._disk_cache = disk_cache
        self._control_policy = control_policy
        self._third_tier = third_tier
        self._log = logger.bind(component="two_tier_cache")

        # Access-count tracking for tier-control policy
        self._access_counts: dict[str, int] = {}

        # Counters for disk-tier interactions (memory stats live on MemoryCache)
        self._disk_hits: int = 0
        self._disk_misses: int = 0
        self._promotion_count: int = 0
        self._demotion_count: int = 0
        self._memory_get_ms: float = 0.0
        self._disk_get_ms: float = 0.0

    # -- public properties ---------------------------------------------------

    @property
    def max_bytes(self) -> int:
        """Maximum byte capacity of the memory tier."""
        return self._memory_cache.max_bytes

    @property
    def policy(self):
        """Active eviction policy of the memory tier."""
        return self._memory_cache.policy

    @property
    def lock(self):
        """Expose the memory tier's asyncio Lock."""
        return self._memory_cache.lock

    @property
    def disk_cache(self) -> Optional[DiskCache]:
        """The disk cache instance, or ``None`` if disk caching is disabled."""
        return self._disk_cache

    # -- async interface (matches MemoryCache) --------------------------------

    async def get(self, chunk_id: str) -> Optional[bytes]:
        """Retrieve a chunk, checking memory first then disk then third tier.

        If the entry is found on disk but not in memory it may be promoted
        into the memory tier based on the active :class:`TierControlPolicy`.
        Falls through to the third tier on a complete disk miss.

        Args:
            chunk_id: Unique identifier for the chunk.

        Returns:
            The chunk data bytes, or ``None`` if not found in any tier.
        """
        # Fast path: memory hit
        t0 = time.monotonic()
        data = await self._memory_cache.get(chunk_id)
        self._memory_get_ms += (time.monotonic() - t0) * 1000
        if data is not None:
            self._access_counts[chunk_id] = self._access_counts.get(chunk_id, 0) + 1
            return data

        # Slow path: check disk
        if self._disk_cache is not None:
            t0 = time.monotonic()
            disk_data = self._disk_cache.get(chunk_id)
            self._disk_get_ms += (time.monotonic() - t0) * 1000
            if disk_data is not None:
                self._disk_hits += 1
                self._access_counts[chunk_id] = self._access_counts.get(chunk_id, 0) + 1
                self._log.debug("disk_cache_hit", chunk_id=chunk_id)
                # Promote to memory if policy allows
                should_promote = True
                if self._control_policy is not None:
                    should_promote = self._control_policy.should_promote(
                        chunk_id=chunk_id,
                        access_count=self._access_counts[chunk_id],
                        size_bytes=len(disk_data),
                    )
                if should_promote:
                    self._promotion_count += 1
                    await self._memory_cache.put(chunk_id, disk_data)
                return disk_data
            self._disk_misses += 1
            self._log.debug("disk_cache_miss", chunk_id=chunk_id)

        # Third-tier fallback
        if self._third_tier is not None:
            third_data = self._third_tier.get(chunk_id)
            if third_data is not None:
                self._log.debug("third_tier_hit", chunk_id=chunk_id)
                self._access_counts[chunk_id] = self._access_counts.get(chunk_id, 0) + 1
                await self._memory_cache.put(chunk_id, third_data)
                return third_data

        return None

    async def put(self, chunk_id: str, data: bytes) -> bool:
        """Insert a chunk into both tiers.

        The memory tier is written first.  If the memory tier rejects
        the entry (e.g. single item exceeds capacity) the disk tier is
        still written so the data is not lost.

        Args:
            chunk_id: Unique identifier for the chunk.
            data: Raw chunk data bytes.

        Returns:
            ``True`` if the entry was accepted by the memory tier.
        """
        memory_ok = await self._memory_cache.put(chunk_id, data)

        # Write-through to disk regardless of memory outcome
        if self._disk_cache is not None:
            try:
                self._disk_cache.put(chunk_id, data)
                self._demotion_count += 1
            except Exception as exc:
                # Disk failure is non-fatal — memory tier is the primary.
                self._log.warning(
                    "disk_put_failed",
                    chunk_id=chunk_id,
                    error=str(exc),
                )

        return memory_ok

    async def evict(self, chunk_id: str) -> bool:
        """Evict a chunk from the **memory tier only**.

        The disk tier retains the entry for persistence.  Use
        :meth:`clear_disk` to remove disk entries.

        Args:
            chunk_id: Unique identifier for the chunk.

        Returns:
            ``True`` if the chunk was evicted from memory.
        """
        return await self._memory_cache.evict(chunk_id)

    async def contains(self, chunk_id: str) -> bool:
        """Check if a chunk exists in either tier."""
        if await self._memory_cache.contains(chunk_id):
            return True
        if self._disk_cache is not None:
            return self._disk_cache.contains(chunk_id)
        return False

    async def get_stats(self) -> CacheStats:
        """Return combined statistics from both tiers.

        The returned :class:`CacheStats` contains the memory tier's
        statistics augmented with disk-specific counters stored as
        extra attributes on the returned dataclass.
        """
        mem_stats = await self._memory_cache.get_stats()

        # Build an extended stats snapshot that includes disk info
        disk_bytes = self._disk_cache.size_bytes() if self._disk_cache else 0

        stats = CacheStats(
            hit_count=mem_stats.hit_count,
            miss_count=mem_stats.miss_count,
            eviction_count=mem_stats.eviction_count,
            insertion_count=mem_stats.insertion_count,
            rejection_count=mem_stats.rejection_count,
            current_bytes=mem_stats.current_bytes,
            current_entries=mem_stats.current_entries,
            max_bytes=mem_stats.max_bytes,
        )

        # Attach disk-specific fields as dynamic attributes
        stats.disk_hits = self._disk_hits  # type: ignore[attr-defined]
        stats.disk_misses = self._disk_misses  # type: ignore[attr-defined]
        stats.disk_bytes = disk_bytes  # type: ignore[attr-defined]
        stats.promotion_count = self._promotion_count  # type: ignore[attr-defined]
        stats.demotion_count = self._demotion_count  # type: ignore[attr-defined]
        stats.memory_get_ms = round(self._memory_get_ms, 3)  # type: ignore[attr-defined]
        stats.disk_get_ms = round(self._disk_get_ms, 3)  # type: ignore[attr-defined]

        return stats

    async def clear(self) -> None:
        """Clear the **memory tier only**.

        Disk entries are preserved.  Use :meth:`clear_disk` to also
        clear disk, or call both methods together.
        """
        await self._memory_cache.clear()

    async def clear_disk(self) -> None:
        """Clear the **disk tier** only.

        Memory entries are preserved.
        """
        if self._disk_cache is not None:
            self._disk_cache.clear()
            self._disk_hits = 0
            self._disk_misses = 0
            self._log.info("disk_cache_cleared")
