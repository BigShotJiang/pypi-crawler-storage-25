"""
Rex cache subsystem — Memory cache, eviction policies, and residency tracking.
"""
