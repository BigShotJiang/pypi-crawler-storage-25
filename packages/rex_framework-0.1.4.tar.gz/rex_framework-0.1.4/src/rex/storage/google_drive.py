"""
Google Drive storage backend — EXPERIMENTAL.

EXPERIMENTAL — requires a Google Cloud project with the Google Drive API
enabled and OAuth2 credentials configured.  Install the extra dependency
with ``pip install rex-framework[google-drive]``.

Credential setup:
    1. Create a Google Cloud project and enable the Drive API.
    2. Create OAuth2 credentials (desktop app type).
    3. Set ``GOOGLE_APPLICATION_CREDENTIALS`` to the path of the JSON
       credentials file, or set ``GOOGLE_DRIVE_TOKEN`` to an existing
       access token.

Limitations:
    - Google Drive API does not support multi-range requests.
    - Rate limits are more aggressive than generic HTTP object storage.
    - File IDs (not paths) are used as resource identifiers.
"""

from __future__ import annotations

from typing import Optional

import structlog

from rex.core.errors import (
    FetchError,
    StorageUnavailableError,
    UnsupportedBackendError,
)
from rex.storage.base import (
    BaseStorageBackend,
    BackendCapabilities,
    ResourceStat,
)

log = structlog.get_logger(__name__)

# Required optional packages
_GOOGLE_AVAILABLE = False
try:
    from google.auth.exceptions import GoogleAuthError  # type: ignore[import-untyped]
    from google.oauth2.credentials import Credentials  # type: ignore[import-untyped]
    from googleapiclient.discovery import Resource  # type: ignore[import-untyped]
    from googleapiclient.discovery import build as build_resource  # type: ignore[import-untyped]
    from googleapiclient.http import HttpRequest  # type: ignore[import-untyped]

    _GOOGLE_AVAILABLE = True
except ImportError:
    pass


class GoogleDriveBackend(BaseStorageBackend):
    """Fetch model weight chunks from Google Drive.

    EXPERIMENTAL — requires ``google-api-python-client`` and
    ``google-auth-oauthlib`` to be installed.

    Args:
        token: An existing OAuth2 access token.  If ``None``, credentials
            are loaded from ``GOOGLE_DRIVE_TOKEN`` env var or
            ``GOOGLE_APPLICATION_CREDENTIALS`` file.
        health_check_file_id: File ID used for health-check pings.
            Must be a file the authenticated user can access.
    """

    _BUILDERS = ("drive", "v3")

    def __init__(
        self,
        token: Optional[str] = None,
        *,
        health_check_file_id: str = "",
    ) -> None:
        if not _GOOGLE_AVAILABLE:
            raise UnsupportedBackendError(
                "google_drive",
                "Install google-api-python-client and google-auth-oauthlib: "
                "pip install rex-framework[google-drive]",
            )

        super().__init__()

        self._credentials: Optional[Credentials] = None
        self._service: Optional[Resource] = None
        self._health_check_file_id = health_check_file_id

        # Resolve credentials
        if token:
            self._credentials = Credentials(token=token)
            self._log.debug(
                "gdrive_token_provided",
            )
        else:
            self._credentials = self._load_credentials()

    def _load_credentials(self) -> Optional[Credentials]:
        """Try to load credentials from environment or ADC."""
        import os

        # 1. Direct token from env
        token = os.environ.get("GOOGLE_DRIVE_TOKEN")
        if token:
            self._log.debug("gdrive_credentials_from_env_token")
            return Credentials(token=token)

        # 2. Application Default Credentials
        try:
            import google.auth  # type: ignore[import-untyped]

            creds, _ = google.auth.default(
                scopes=["https://www.googleapis.com/auth/drive.readonly"]
            )
            self._log.debug("gdrive_credentials_from_adc")
            return creds  # type: ignore[return-value]
        except Exception:
            self._log.debug("gdrive_adc_not_available")

        return None

    def _ensure_service(self) -> Resource:
        """Lazily build the Drive API service object."""
        if self._service is None:
            if self._credentials is None:
                from rex.core.errors import AuthenticationError

                raise AuthenticationError(
                    "No Google Drive credentials configured. "
                    "Set GOOGLE_DRIVE_TOKEN or GOOGLE_APPLICATION_CREDENTIALS."
                )
            self._service = build_resource(
                "drive", "v3", credentials=self._credentials
            )
        return self._service

    # ── Core operations ───────────────────────────────────────────────────

    async def fetch_range(
        self,
        resource_id: str,
        start: int,
        end: int,
    ) -> bytes:
        """Fetch bytes ``[start, end)`` from a Google Drive file.

        *resource_id* must be the Google Drive **file ID** (not a path).

        Uses ``files.get`` with ``alt=media`` and a ``Range`` header.
        """
        if start < 0 or end <= start:
            raise ValueError(f"Invalid byte range: [{start}, {end})")

        service = self._ensure_service()

        try:
            import asyncio

            request: HttpRequest = service.files().get_media(
                fileId=resource_id,
            )
            # Add Range header
            request.headers["Range"] = f"bytes={start}-{end - 1}"

            # Execute in a thread to avoid blocking
            response = await asyncio.to_thread(request.execute)
            if isinstance(response, bytes):
                return response
            if isinstance(response, str):
                # google-api-python-client may decode media payloads to str in
                # some environments; latin-1 preserves raw byte values 0-255.
                return response.encode("latin-1")
            if isinstance(response, (list, tuple)) and all(
                isinstance(x, str) for x in response
            ):
                return "".join(response).encode("latin-1")
            return bytes(response)

        except GoogleAuthError as exc:
            from rex.core.errors import AuthenticationError

            raise AuthenticationError(
                f"Google Drive auth failed for file {resource_id}: {exc}"
            ) from exc
        except Exception as exc:
            raise FetchError(
                chunk_id=f"{resource_id}[{start}:{end}]",
                resource_id=resource_id,
                details={"error": str(exc)},
            ) from exc

    async def stat(self, resource_id: str) -> ResourceStat:
        """Retrieve file metadata from Google Drive."""
        service = self._ensure_service()

        try:
            import asyncio

            fields = "id,name,size,mimeType,modifiedTime,md5Checksum"
            request: HttpRequest = service.files().get(
                fileId=resource_id,
                fields=fields,
            )
            metadata = await asyncio.to_thread(request.execute)

            from datetime import datetime

            last_modified: Optional[float] = None
            mt = metadata.get("modifiedTime")
            if mt:
                try:
                    last_modified = datetime.fromisoformat(
                        mt.replace("Z", "+00:00")
                    ).timestamp()
                except ValueError:
                    pass

            return ResourceStat(
                size=int(metadata.get("size", 0)),
                etag=metadata.get("md5Checksum", ""),
                last_modified=last_modified,
                content_type=metadata.get("mimeType", ""),
            )

        except GoogleAuthError as exc:
            from rex.core.errors import AuthenticationError

            raise AuthenticationError(
                f"Google Drive auth failed for file {resource_id}: {exc}"
            ) from exc
        except Exception as exc:
            raise FetchError(
                chunk_id="stat",
                resource_id=resource_id,
                details={"error": str(exc)},
            ) from exc

    async def health_check(self) -> bool:
        """Ping a known file to verify connectivity and auth.

        If ``health_check_file_id`` was not provided, returns ``True`` if
        credentials are present (best-effort).
        """
        if not self._health_check_file_id:
            return self._credentials is not None

        try:
            await self.stat(self._health_check_file_id)
            return True
        except Exception:
            return False

    # ── Introspection ─────────────────────────────────────────────────────

    def auth_requirements(self) -> list[str]:
        """Return required credential names."""
        return ["GOOGLE_DRIVE_TOKEN or GOOGLE_APPLICATION_CREDENTIALS"]

    def capabilities(self) -> BackendCapabilities:
        """Return Google Drive capabilities."""
        return BackendCapabilities(
            supports_range_requests=True,
            supports_multi_range=False,
            max_concurrent_requests=10,
            max_request_size_bytes=0,
            rate_limit_rpm=0,  # Google manages rate limits server-side
        )

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def close(self) -> None:
        """Release resources (no-op for Google Drive — no persistent session)."""
        self._service = None
        self._credentials = None
