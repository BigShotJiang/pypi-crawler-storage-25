"""
Authentication utilities for Rex storage backends.

Provides helpers for loading authentication tokens from environment
variables and files, and for safely redacting tokens in log output.
"""

from __future__ import annotations

import os
from typing import Optional


class AuthError(Exception):
    """Base exception for authentication-related errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class TokenNotFoundError(AuthError):
    """The requested authentication token could not be found."""

    def __init__(self, source: str) -> None:
        super().__init__(f"Authentication token not found: {source}")
        self.source = source


class InvalidTokenError(AuthError):
    """The loaded token is empty or otherwise invalid."""

    def __init__(self, source: str, reason: str = "token is empty") -> None:
        super().__init__(f"Invalid token from {source}: {reason}")
        self.source = source
        self.reason = reason


def load_token_from_env(var_name: str = "REX_AUTH_TOKEN") -> Optional[str]:
    """Load an authentication token from an environment variable.

    Args:
        var_name: Name of the environment variable to read.

    Returns:
        The token string, or ``None`` if the variable is not set.

    Raises:
        InvalidTokenError: The variable is set but its value is empty/whitespace.
    """
    import structlog

    log = structlog.get_logger(__name__)

    value = os.environ.get(var_name)
    if value is None:
        log.debug("auth_token_env_not_set", var_name=var_name)
        return None
    value = value.strip()
    if not value:
        raise InvalidTokenError(
            f"env var {var_name!r}",
            reason="value is empty or whitespace",
        )
    log.debug("auth_token_loaded_from_env", var_name=var_name)
    return value


def load_token_from_file(path: str) -> str:
    """Load the first line of a file as an authentication token.

    Leading/trailing whitespace (including newlines) is stripped.  Blank
    lines at the start of the file are skipped.

    Args:
        path: Filesystem path to the token file.

    Returns:
        The token string.

    Raises:
        TokenNotFoundError: The file does not exist.
        InvalidTokenError: The file is empty or contains only whitespace.
        PermissionError: The file cannot be read.
    """
    import structlog

    log = structlog.get_logger(__name__)

    if not os.path.isfile(path):
        raise TokenNotFoundError(f"file not found: {path}")

    try:
        with open(path, encoding="utf-8") as fh:
            for raw_line in fh:
                token = raw_line.strip()
                if token:
                    log.debug("auth_token_loaded_from_file", path=path)
                    return token
    except PermissionError:
        log.error("auth_token_file_permission_denied", path=path)
        raise

    raise InvalidTokenError(
        f"file {path!r}",
        reason="file is empty or contains only whitespace",
    )


def redact_token(token: str, visible_chars: int = 4) -> str:
    """Return a redacted version of *token* safe for logging.

    Only the last *visible_chars* characters are shown; everything else is
    replaced with asterisks.

    Args:
        token: The raw token string.
        visible_chars: Number of trailing characters to leave visible.

    Returns:
        A redacted token string such as ``"********abcd"``.

    Raises:
        ValueError: *visible_chars* is negative.
    """
    if visible_chars < 0:
        raise ValueError(f"visible_chars must be >= 0, got {visible_chars}")
    if len(token) <= visible_chars:
        return token
    return "*" * (len(token) - visible_chars) + token[-visible_chars:]
