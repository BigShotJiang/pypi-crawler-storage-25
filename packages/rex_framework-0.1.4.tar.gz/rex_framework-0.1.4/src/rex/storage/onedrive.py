"""
OneDrive storage backend — EXPERIMENTAL.

EXPERIMENTAL — requires Microsoft Azure AD app registration with the
Microsoft Graph API ``Files.Read`` permission.  Install the extra
dependency with ``pip install rex-framework[onedrive]``.

Credential setup:
    1. Register an app in Azure AD (App Registrations).
    2. Add the ``Files.Read`` delegated permission.
    3. Set ``ONEDRIVE_CLIENT_ID`` and ``ONEDRIVE_CLIENT_SECRET``.
    4. Set ``ONEDRIVE_TENANT_ID`` for multi-tenant apps.

    Alternatively, provide a pre-acquired token via the ``token`` parameter
    or ``ONEDRIVE_ACCESS_TOKEN`` env var.

Limitations:
    - Microsoft Graph API does not support multi-range requests in a
      single call.
    - Resource identifiers must be OneDrive **item IDs**.
    - Rate limits are enforced server-side; the client should respect
      ``Retry-After`` headers.
"""

from __future__ import annotations

from typing import Optional

import structlog

from rex.core.errors import (
    AuthenticationError,
    FetchError,
    StorageUnavailableError,
    UnsupportedBackendError,
)
from rex.storage.base import (
    BaseStorageBackend,
    BackendCapabilities,
    ResourceStat,
)

log = structlog.get_logger(__name__)

_MSAL_AVAILABLE = False
try:
    import msal  # type: ignore[import-untyped]

    _MSAL_AVAILABLE = True
except ImportError:
    pass


class OneDriveBackend(BaseStorageBackend):
    """Fetch model weight chunks from Microsoft OneDrive via the Graph API.

    EXPERIMENTAL — requires ``msal`` to be installed.

    Args:
        token: A pre-acquired Microsoft Graph access token.  If ``None``,
            credentials are loaded from environment variables.
        client_id: Azure AD app client ID.
        client_secret: Azure AD app client secret.
        tenant_id: Azure AD tenant ID.
        health_check_item_id: Item ID used for health-check pings.
    """

    GRAPH_BASE = "https://graph.microsoft.com/v1.0"

    def __init__(
        self,
        token: Optional[str] = None,
        *,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        tenant_id: Optional[str] = None,
        health_check_item_id: str = "",
    ) -> None:
        if not _MSAL_AVAILABLE:
            raise UnsupportedBackendError(
                "onedrive",
                "Install msal: pip install rex-framework[onedrive]",
            )

        super().__init__()

        self._token: Optional[str] = None
        self._session = None  # type: ignore[no-any-unimported]
        self._health_check_item_id = health_check_item_id

        # Resolve token
        if token:
            self._token = token
            self._log.debug("onedrive_token_provided")
        else:
            self._token = self._load_token()

        # If no direct token, try MSAL client credentials flow
        if not self._token and client_id and client_secret:
            self._token = self._acquire_token(
                client_id=client_id,
                client_secret=client_secret,
                tenant_id=tenant_id or "common",
            )

    def _load_token(self) -> Optional[str]:
        """Attempt to load a token from the environment."""
        import os

        token = os.environ.get("ONEDRIVE_ACCESS_TOKEN")
        if token:
            self._log.debug("onedrive_token_from_env")
        return token

    def _acquire_token(
        self,
        client_id: str,
        client_secret: str,
        tenant_id: str,
    ) -> Optional[str]:
        """Acquire a token via MSAL client credentials flow."""
        try:
            authority = f"https://login.microsoftonline.com/{tenant_id}"
            app = msal.ConfidentialClientApplication(
                client_id,
                authority=authority,
                client_credential=client_secret,
            )
            result = app.acquire_token_for_client(
                scopes=["https://graph.microsoft.com/.default"]
            )
            token = result.get("access_token")
            if token:
                self._log.debug("onedrive_token_acquired_msal")
                return token
            error = result.get("error_description", "unknown error")
            self._log.warning("onedrive_msal_auth_failed", error=error)
            return None
        except Exception as exc:
            self._log.warning("onedrive_msal_error", error=str(exc))
            return None

    def _ensure_session(self):
        """Create an ``aiohttp.ClientSession`` with auth headers."""
        import aiohttp

        if self._session is None or self._session.closed:
            headers = {
                "Authorization": f"Bearer {self._token}",
                "User-Agent": "RexStorage/0.1.0",
            }
            self._session = aiohttp.ClientSession(
                base_url=self.GRAPH_BASE,
                headers=headers,
                raise_for_status=False,
            )
        return self._session

    def _check_auth(self) -> None:
        """Raise if no token is available."""
        if not self._token:
            raise AuthenticationError(
                "No OneDrive access token. Set ONEDRIVE_ACCESS_TOKEN, "
                "provide a token, or configure client credentials."
            )

    # ── Core operations ───────────────────────────────────────────────────

    async def fetch_range(
        self,
        resource_id: str,
        start: int,
        end: int,
    ) -> bytes:
        """Fetch bytes ``[start, end)`` from a OneDrive item.

        *resource_id* must be the OneDrive **item ID**.

        Uses the Microsoft Graph endpoint
        ``/me/drive/items/{id}/content`` with a ``Range`` header.
        """
        if start < 0 or end <= start:
            raise ValueError(f"Invalid byte range: [{start}, {end})")
        self._check_auth()

        session = self._ensure_session()
        url = f"/me/drive/items/{resource_id}/content"
        range_header = f"bytes={start}-{end - 1}"

        try:
            async with session.get(
                url,
                headers={"Range": range_header},
            ) as resp:
                if resp.status == 206:
                    return await resp.read()
                if resp.status == 401:
                    raise AuthenticationError(
                        f"OneDrive auth failed for item {resource_id} (HTTP 401)"
                    )
                if resp.status == 404:
                    raise FetchError(
                        chunk_id=f"{resource_id}[{start}:{end}]",
                        resource_id=resource_id,
                        status_code=404,
                    )
                if resp.status == 429:
                    from rex.core.errors import RateLimitError

                    retry_after = 0.0
                    ra = resp.headers.get("Retry-After")
                    if ra:
                        try:
                            retry_after = float(ra)
                        except ValueError:
                            pass
                    raise RateLimitError(
                        f"OneDrive rate limited for item {resource_id}",
                        retry_after_seconds=retry_after,
                    )
                if resp.status >= 500:
                    raise StorageUnavailableError(
                        f"OneDrive server error for item {resource_id} "
                        f"(HTTP {resp.status})"
                    )
                # Fallback: 200 without Range support
                if resp.status == 200:
                    body = await resp.read()
                    return body[start:end]
                raise FetchError(
                    chunk_id=f"{resource_id}[{start}:{end}]",
                    resource_id=resource_id,
                    status_code=resp.status,
                )

        except (AuthenticationError, FetchError, StorageUnavailableError):
            raise
        except Exception as exc:
            raise StorageUnavailableError(
                f"OneDrive request failed for item {resource_id}: {exc}"
            ) from exc

    async def stat(self, resource_id: str) -> ResourceStat:
        """Retrieve item metadata from OneDrive."""
        self._check_auth()
        session = self._ensure_session()
        url = f"/me/drive/items/{resource_id}"

        try:
            async with session.get(url) as resp:
                if resp.status != 200:
                    raise FetchError(
                        chunk_id="stat",
                        resource_id=resource_id,
                        status_code=resp.status,
                    )
                data = await resp.json()

                from datetime import datetime

                last_modified: Optional[float] = None
                mt = data.get("lastModifiedDateTime")
                if mt:
                    try:
                        last_modified = datetime.fromisoformat(
                            mt.replace("Z", "+00:00")
                        ).timestamp()
                    except ValueError:
                        pass

                return ResourceStat(
                    size=int(data.get("size", 0)),
                    etag=data.get("eTag", ""),
                    last_modified=last_modified,
                    content_type=data.get("file", {}).get("mimeType", ""),
                )

        except (AuthenticationError, FetchError):
            raise
        except Exception as exc:
            raise StorageUnavailableError(
                f"OneDrive stat failed for item {resource_id}: {exc}"
            ) from exc

    async def health_check(self) -> bool:
        """Ping a known item to verify connectivity.

        Falls back to a token-validity check if no item ID is configured.
        """
        if not self._health_check_item_id:
            return self._token is not None

        try:
            await self.stat(self._health_check_item_id)
            return True
        except Exception:
            return False

    # ── Introspection ─────────────────────────────────────────────────────

    def auth_requirements(self) -> list[str]:
        """Return required credential names."""
        return [
            "ONEDRIVE_ACCESS_TOKEN",
            "or (ONEDRIVE_CLIENT_ID + ONEDRIVE_CLIENT_SECRET + ONEDRIVE_TENANT_ID)",
        ]

    def capabilities(self) -> BackendCapabilities:
        """Return OneDrive capabilities."""
        return BackendCapabilities(
            supports_range_requests=True,
            supports_multi_range=False,
            max_concurrent_requests=10,
            max_request_size_bytes=0,
            rate_limit_rpm=0,  # Microsoft manages rate limits server-side
        )

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def close(self) -> None:
        """Close the underlying ``aiohttp`` session."""
        if self._session and not self._session.closed:
            await self._session.close()
            self._log.debug("onedrive_session_closed")
        self._session = None
        self._token = None
