"""
Local HTTP chunk server for development and testing.

Implements a lightweight ``aiohttp.web`` server that serves files from a
local directory with full HTTP Range support (RFC 7233), including
multi-range ``multipart/byteranges`` responses.  Designed for local
development, integration tests, and benchmarking with configurable
simulated latency, bandwidth caps, and fault injection.

The server can be used as a library or invoked directly::

    # Library usage
    from rex.storage.local_server import serve_chunks
    app = await serve_chunks("/path/to/chunks", port=8971)

    # CLI usage
    python -m rex.storage.local_server /path/to/chunks --port 8971

Typical ``chunk_dir`` layout::

    chunks/
    ├── model.safetensors
    ├── metadata.json
    └── layer_00_q_proj.bin
"""

from __future__ import annotations

import asyncio
import hashlib
import math
import mimetypes
import os
import random
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import aiohttp
from aiohttp import web
import structlog

log = structlog.get_logger(__name__)

# MIME type fallback
_DEFAULT_MIME = "application/octet-stream"


# ── Fault Injection ────────────────────────────────────────────────────────


@dataclass
class FaultInjector:
    """Configurable fault injection for simulating network issues.

    Each fault type has an independent probability (0.0–1.0) of being
    triggered on any given request.

    Attributes:
        timeout_rate: Probability of injecting a request timeout.
        error_rate: Probability of returning an error status code.
        error_status_code: HTTP status code to return when error triggers.
        throttle_rate: Probability of adding extra artificial latency.
        throttle_extra_delay_ms: Extra delay in milliseconds when throttle
            triggers.
        corruption_rate: Probability of corrupting response bytes.
    """

    timeout_rate: float = 0.0
    error_rate: float = 0.0
    error_status_code: int = 500
    throttle_rate: float = 0.0
    throttle_extra_delay_ms: float = 0.0
    corruption_rate: float = 0.0

    def inject_timeout(self) -> bool:
        """Return ``True`` if a timeout should be injected."""
        return random.random() < self.timeout_rate

    def inject_error(self) -> Optional[int]:
        """Return an error status code, or ``None`` if no error."""
        if random.random() < self.error_rate:
            return self.error_status_code
        return None

    def inject_throttle(self) -> float:
        """Return extra delay in seconds, or 0.0."""
        if random.random() < self.throttle_rate:
            return self.throttle_extra_delay_ms / 1000.0
        return 0.0

    def inject_corruption(self) -> bool:
        """Return ``True`` if corruption should be applied."""
        return random.random() < self.corruption_rate

    @classmethod
    def disabled(cls) -> FaultInjector:
        """Create a fault injector with all probabilities at zero."""
        return cls()


# ── Bandwidth Throttling ───────────────────────────────────────────────────


class BandwidthThrottler:
    """Limits the rate at which response bytes are written.

    Args:
        bandwidth_mbps: Maximum bandwidth in megabits per second (0 = unlimited).
    """

    def __init__(self, bandwidth_mbps: float = 0.0) -> None:
        self._bytes_per_second = (bandwidth_mbps * 1_000_000) / 8.0 if bandwidth_mbps > 0 else 0.0
        self._chunk_size = 8192  # 8 KiB write chunks

    @property
    def unlimited(self) -> bool:
        return self._bytes_per_second <= 0

    async def write(
        self,
        data: bytes,
        response: web.StreamResponse,
    ) -> None:
        """Write *data* to *response*, throttling if configured."""
        if self.unlimited or len(data) <= self._chunk_size:
            await response.write(data)
            return

        offset = 0
        while offset < len(data):
            chunk = data[offset : offset + self._chunk_size]
            await response.write(chunk)
            offset += self._chunk_size

            # Sleep to enforce bandwidth limit
            if self._bytes_per_second > 0:
                chunk_time = self._chunk_size / self._bytes_per_second
                await asyncio.sleep(chunk_time)


# ── Range Header Parsing ──────────────────────────────────────────────────


@dataclass
class RangeSpec:
    """Parsed representation of a single byte-range."""
    start: int
    end: int  # inclusive


def parse_range_header(
    range_header: str,
    file_size: int,
) -> list[RangeSpec]:
    """Parse an HTTP ``Range`` header into a list of :class:`RangeSpec`.

    Supports formats:
        - ``bytes=0-499``
        - ``bytes=500-999``
        - ``bytes=-500`` (last 500 bytes)
        - ``bytes=9500-`` (from offset 9500 to end)
        - ``bytes=0-0, -1`` (multiple ranges)

    Args:
        range_header: Raw value of the ``Range`` header.
        file_size: Total file size in bytes.

    Returns:
        List of parsed ranges.

    Raises:
        ValueError: If the header is malformed.
    """
    if not range_header.startswith("bytes="):
        raise ValueError(f"Unsupported range unit: {range_header}")

    range_value = range_header[6:]  # strip "bytes="
    ranges: list[RangeSpec] = []

    for part in range_value.split(","):
        part = part.strip()
        if not part:
            continue

        if part.startswith("-"):
            # Suffix range: -N means last N bytes
            suffix_len = int(part[1:])
            if suffix_len <= 0 or suffix_len > file_size:
                raise ValueError(f"Invalid suffix range: {part}")
            ranges.append(RangeSpec(
                start=file_size - suffix_len,
                end=file_size - 1,
            ))
        elif "-" in part:
            start_str, end_str = part.split("-", 1)
            if not start_str:
                raise ValueError(f"Invalid range: {part}")
            start = int(start_str)
            if start >= file_size:
                continue  # unsatisfiable — skip silently
            if end_str:
                end = int(end_str)
                end = min(end, file_size - 1)
            else:
                end = file_size - 1
            if end < start:
                raise ValueError(f"Invalid range: {part}")
            ranges.append(RangeSpec(start=start, end=end))
        else:
            raise ValueError(f"Invalid range spec: {part}")

    if not ranges:
        raise ValueError(f"No satisfiable ranges in: {range_header}")

    return ranges


# ── Server ─────────────────────────────────────────────────────────────────


@dataclass
class ServerConfig:
    """Configuration for the local chunk server.

    Attributes:
        host: Bind address.
        port: Bind port.
        chunk_dir: Directory to serve files from.
        simulated_latency_ms: Artificial delay added to every response.
        bandwidth_mbps: Simulated bandwidth cap.
        faults: Fault injection configuration.
    """

    host: str = "127.0.0.1"
    port: int = 8971
    chunk_dir: str = "."
    simulated_latency_ms: float = 0.0
    bandwidth_mbps: float = 0.0
    faults: FaultInjector = field(default_factory=FaultInjector.disabled)


def _resolve_path(chunk_dir: str, resource_id: str) -> str:
    """Safely resolve *resource_id* relative to *chunk_dir*.

    Prevents directory traversal attacks.

    Args:
        chunk_dir: Base directory.
        resource_id: Requested resource path.

    Returns:
        Absolute path to the file.

    Raises:
        web.HTTPNotFound: If the path is outside *chunk_dir* or the file
            doesn't exist.
    """
    # Normalise both paths
    base = os.path.realpath(chunk_dir)
    target = os.path.realpath(os.path.join(chunk_dir, resource_id))

    if not target.startswith(base + os.sep) and target != base:
        raise web.HTTPNotFound(reason="Path traversal not allowed")

    if not os.path.isfile(target):
        raise web.HTTPNotFound(reason=f"File not found: {resource_id}")

    return target


def _guess_mime(path: str) -> str:
    """Guess MIME type from file extension."""
    mime, _ = mimetypes.guess_type(path)
    return mime or _DEFAULT_MIME


def _generate_boundary() -> str:
    """Generate a unique MIME boundary for multipart responses."""
    return f"rex-boundary-{hashlib.md5(os.urandom(16)).hexdigest()}"


async def _handle_get(request: web.Request) -> web.StreamResponse:
    """Handle GET requests with full Range / multi-range support."""
    config: ServerConfig = request.app["config"]
    resource_id = request.match_info["resource_id"]

    # Fault injection: timeout
    if config.faults.inject_timeout():
        log.warning("fault_injection_timeout", resource_id=resource_id)
        await asyncio.sleep(config.timeout or 120)
        raise web.HTTPServiceUnavailable(reason="Simulated timeout")

    # Fault injection: error
    error_status = config.faults.inject_error()
    if error_status is not None:
        log.warning(
            "fault_injection_error",
            resource_id=resource_id,
            status=error_status,
        )
        return web.Response(
            status=error_status,
            text=f"Simulated error (HTTP {error_status})",
        )

    # Fault injection: extra throttle delay
    extra_delay = config.faults.inject_throttle()
    if extra_delay > 0:
        log.debug("fault_injection_throttle", delay_ms=extra_delay * 1000)
        await asyncio.sleep(extra_delay)

    # Resolve file path
    file_path = _resolve_path(config.chunk_dir, resource_id)
    file_size = os.path.getsize(file_path)
    content_type = _guess_mime(file_path)

    # Parse Range header
    range_header = request.headers.get("Range")
    throttler = BandwidthThrottler(config.bandwidth_mbps)

    if range_header is None:
        # Full file response
        return await _serve_full(request, file_path, file_size, content_type, config, throttler)

    # Parse ranges
    try:
        ranges = parse_range_header(range_header, file_size)
    except ValueError:
        raise web.HTTPRequestRangeNotSatisfiable(
            reason=f"Invalid range: {range_header}"
        )

    if len(ranges) == 1:
        # Single range — 206 Partial Content
        return await _serve_single_range(
            request, file_path, file_size, content_type, ranges[0], config, throttler
        )

    # Multi-range — multipart/byteranges
    return await _serve_multi_range(
        request, file_path, file_size, content_type, ranges, config, throttler
    )


async def _serve_full(
    request: web.Request,
    file_path: str,
    file_size: int,
    content_type: str,
    config: ServerConfig,
    throttler: BandwidthThrottler,
) -> web.StreamResponse:
    """Serve the complete file (200 OK)."""
    # Simulated latency
    if config.simulated_latency_ms > 0:
        await asyncio.sleep(config.simulated_latency_ms / 1000.0)

    resp = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": content_type,
            "Content-Length": str(file_size),
            "Accept-Ranges": "bytes",
        },
    )
    await resp.prepare(request)

    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(65536)  # 64 KiB reads
            if not chunk:
                break
            await throttler.write(chunk, resp)

    await resp.write_eof()
    return resp


async def _serve_single_range(
    request: web.Request,
    file_path: str,
    file_size: int,
    content_type: str,
    range_spec: RangeSpec,
    config: ServerConfig,
    throttler: BandwidthThrottler,
) -> web.StreamResponse:
    """Serve a single byte range (206 Partial Content)."""
    # Simulated latency
    if config.simulated_latency_ms > 0:
        await asyncio.sleep(config.simulated_latency_ms / 1000.0)

    start = range_spec.start
    end = range_spec.end
    length = end - start + 1

    resp = web.StreamResponse(
        status=206,
        headers={
            "Content-Type": content_type,
            "Content-Length": str(length),
            "Content-Range": f"bytes {start}-{end}/{file_size}",
            "Accept-Ranges": "bytes",
        },
    )
    await resp.prepare(request)

    with open(file_path, "rb") as f:
        f.seek(start)
        remaining = length
        while remaining > 0:
            to_read = min(65536, remaining)
            chunk = f.read(to_read)
            if not chunk:
                break

            # Fault injection: corruption
            if config.faults.inject_corruption():
                chunk = bytearray(chunk)
                pos = random.randint(0, len(chunk) - 1)
                chunk[pos] = (chunk[pos] + 1) % 256
                chunk = bytes(chunk)
                log.debug("fault_injection_corruption", position=pos)

            await throttler.write(chunk, resp)
            remaining -= len(chunk)

    await resp.write_eof()
    return resp


async def _serve_multi_range(
    request: web.Request,
    file_path: str,
    file_size: int,
    content_type: str,
    ranges: list[RangeSpec],
    config: ServerConfig,
    throttler: BandwidthThrottler,
) -> web.StreamResponse:
    """Serve multiple byte ranges (206 multipart/byteranges)."""
    # Simulated latency
    if config.simulated_latency_ms > 0:
        await asyncio.sleep(config.simulated_latency_ms / 1000.0)

    boundary = _generate_boundary()

    # Pre-compute the body to know Content-Length
    body_parts: list[bytes] = []
    with open(file_path, "rb") as f:
        for r in ranges:
            f.seek(r.start)
            length = r.end - r.start + 1
            part_data = f.read(length)

            # Fault injection: corruption
            if config.faults.inject_corruption():
                part_data = bytearray(part_data)
                pos = random.randint(0, len(part_data) - 1)
                part_data[pos] = (part_data[pos] + 1) % 256
                part_data = bytes(part_data)

            part_header = (
                f"\r\n--{boundary}\r\n"
                f"Content-Type: {content_type}\r\n"
                f"Content-Range: bytes {r.start}-{r.end}/{file_size}\r\n\r\n"
            ).encode("utf-8")
            body_parts.append(part_header)
            body_parts.append(part_data)

    body_parts.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    full_body = b"".join(body_parts)

    resp = web.Response(
        status=206,
        content_type=f"multipart/byteranges; boundary={boundary}",
        body=full_body,
        headers={
            "Accept-Ranges": "bytes",
        },
    )
    return resp


async def _handle_head(request: web.Request) -> web.Response:
    """Handle HEAD requests — return metadata without the body."""
    config: ServerConfig = request.app["config"]
    resource_id = request.match_info["resource_id"]

    file_path = _resolve_path(config.chunk_dir, resource_id)
    file_size = os.path.getsize(file_path)
    content_type = _guess_mime(file_path)

    # ETag from file size + mtime
    stat = os.stat(file_path)
    etag = f'"{stat.st_size}-{int(stat.st_mtime)}"'

    return web.Response(
        status=200,
        headers={
            "Content-Type": content_type,
            "Content-Length": str(file_size),
            "Accept-Ranges": "bytes",
            "ETag": etag,
            "Last-Modified": time.strftime(
                "%a, %d %b %Y %H:%M:%S GMT",
                time.gmtime(stat.st_mtime),
            ),
        },
    )


async def _handle_health(request: web.Request) -> web.Response:
    """Health-check endpoint."""
    config: ServerConfig = request.app["config"]
    healthy = os.path.isdir(config.chunk_dir)
    status = 200 if healthy else 503
    return web.json_response(
        {
            "status": "ok" if healthy else "error",
            "chunk_dir": config.chunk_dir,
            "exists": os.path.isdir(config.chunk_dir),
        },
        status=status,
    )


# ── Server lifecycle ───────────────────────────────────────────────────────

_server_runner: Optional[web.AppRunner] = None
_server_site: Optional[web.TCPSite] = None


def create_app(config: ServerConfig) -> web.Application:
    """Create and configure the ``aiohttp.web`` application.

    Args:
        config: Server configuration.

    Returns:
        Configured :class:`web.Application`.
    """
    app = web.Application()
    app["config"] = config

    app.router.add_get("/health", _handle_health)
    app.router.add_route("HEAD", "/{resource_id:.*}", _handle_head)
    app.router.add_route("GET", "/{resource_id:.*}", _handle_get)

    return app


async def start_server(
    host: str = "127.0.0.1",
    port: int = 8971,
    chunk_dir: str = ".",
    *,
    simulated_latency_ms: float = 0.0,
    bandwidth_mbps: float = 0.0,
    faults: Optional[FaultInjector] = None,
) -> web.Application:
    """Start the local chunk server.

    Args:
        host: Bind address (default ``127.0.0.1``).
        port: Bind port (default ``8971``).
        chunk_dir: Directory to serve files from.
        simulated_latency_ms: Artificial delay per response (ms).
        bandwidth_mbps: Simulated bandwidth cap.
        faults: Fault injection configuration.

    Returns:
        The running :class:`web.Application`.

    Raises:
        FileNotFoundError: If *chunk_dir* does not exist.
        RuntimeError: If the server is already running.
    """
    global _server_runner, _server_site

    if not os.path.isdir(chunk_dir):
        raise FileNotFoundError(f"Chunk directory does not exist: {chunk_dir}")

    if _server_runner is not None:
        raise RuntimeError("Local chunk server is already running")

    config = ServerConfig(
        host=host,
        port=port,
        chunk_dir=chunk_dir,
        simulated_latency_ms=simulated_latency_ms,
        bandwidth_mbps=bandwidth_mbps,
        faults=faults or FaultInjector.disabled(),
    )

    app = create_app(config)
    runner = web.AppRunner(app)
    await runner.setup()

    site = web.TCPSite(runner, host, port)
    await site.start()

    _server_runner = runner
    _server_site = site

    log.info(
        "local_chunk_server_started",
        host=host,
        port=port,
        chunk_dir=chunk_dir,
        url=f"http://{host}:{port}",
    )

    return app


async def stop_server() -> None:
    """Stop the local chunk server.

    Safe to call multiple times; subsequent calls are no-ops.
    """
    global _server_runner, _server_site

    if _server_runner is not None:
        log.info("local_chunk_server_stopping")
        await _server_runner.cleanup()
        _server_runner = None
        _server_site = None
        log.info("local_chunk_server_stopped")


async def serve_chunks(
    chunk_dir: str,
    host: str = "127.0.0.1",
    port: int = 8971,
    **kwargs: Any,
) -> web.Application:
    """Convenience function to start the chunk server.

    Accepts the same keyword arguments as :func:`start_server`
    (``simulated_latency_ms``, ``bandwidth_mbps``, ``faults``).

    Args:
        chunk_dir: Directory to serve files from.
        host: Bind address.
        port: Bind port.
        **kwargs: Forwarded to :func:`start_server`.

    Returns:
        The running application.
    """
    return await start_server(host=host, port=port, chunk_dir=chunk_dir, **kwargs)


# ── CLI entry point ────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Rex local chunk server for development and testing"
    )
    parser.add_argument(
        "chunk_dir",
        help="Directory to serve files from",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Bind address (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8971,
        help="Bind port (default: 8971)",
    )
    parser.add_argument(
        "--latency-ms",
        type=float,
        default=0.0,
        help="Simulated latency per response in milliseconds",
    )
    parser.add_argument(
        "--bandwidth-mbps",
        type=float,
        default=0.0,
        help="Simulated bandwidth cap in Mbps (0 = unlimited)",
    )
    parser.add_argument(
        "--fault-timeout-rate",
        type=float,
        default=0.0,
        help="Probability of injecting a timeout (0.0–1.0)",
    )
    parser.add_argument(
        "--fault-error-rate",
        type=float,
        default=0.0,
        help="Probability of injecting an error response (0.0–1.0)",
    )
    parser.add_argument(
        "--fault-error-status",
        type=int,
        default=500,
        help="HTTP status code for injected errors (default: 500)",
    )

    args = parser.parse_args()

    faults = FaultInjector(
        timeout_rate=args.fault_timeout_rate,
        error_rate=args.fault_error_rate,
        error_status_code=args.fault_error_status,
    )

    async def _run() -> None:
        await start_server(
            host=args.host,
            port=args.port,
            chunk_dir=args.chunk_dir,
            simulated_latency_ms=args.latency_ms,
            bandwidth_mbps=args.bandwidth_mbps,
            faults=faults,
        )
        # Keep running until interrupted
        try:
            while True:
                await asyncio.sleep(3600)
        except asyncio.CancelledError:
            pass
        finally:
            await stop_server()

    asyncio.run(_run())
