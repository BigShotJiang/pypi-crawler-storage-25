"""
Rex storage layer — remote backends for chunk-based weight fetching.

Provides pluggable storage backends that support HTTP Range requests
for efficient partial-file reads, along with retry logic, rate limiting,
and authentication utilities.

Available backends:
    - :class:`~rex.storage.http_range.HTTPRangeBackend` — Generic HTTP Range (RFC 7233)
    - :class:`~rex.storage.local_server.LocalChunkServer` — Local dev/test server
    - :class:`~rex.storage.google_drive.GoogleDriveBackend` — Google Drive (experimental)
    - :class:`~rex.storage.onedrive.OneDriveBackend` — OneDrive (experimental)

Example::

    from rex.storage.http_range import HTTPRangeBackend

    backend = HTTPRangeBackend(
        base_url="https://storage.example.com/models",
        auth_token="my-token",
    )
    data = await backend.fetch_range("model.safetensors", 0, 524288)
"""

from rex.storage.base import BaseStorageBackend, BackendCapabilities, ResourceStat

__all__ = [
    "BaseStorageBackend",
    "BackendCapabilities",
    "ResourceStat",
]
