"""
iCloud storage backend — UNSUPPORTED.

iCloud does not expose a public API with HTTP Range request support
suitable for Rex's chunk-based access pattern.  This module provides
a clear error message rather than silently failing.
"""

from __future__ import annotations

from rex.core.errors import UnsupportedBackendError
from rex.storage.base import BaseStorageBackend


class ICloudStorageBackend(BaseStorageBackend):
    """iCloud storage backend.

    **Status: UNSUPPORTED**

    iCloud does not expose a public API with HTTP Range request support
    suitable for Rex's chunk-based access pattern.  This stub exists to
    provide a clear error message rather than silently failing.

    Alternatives:
        - Use Google Drive (:class:`~rex.storage.google_drive.GoogleDriveBackend`).
        - Use OneDrive (:class:`~rex.storage.onedrive.OneDriveBackend`).
        - Use generic HTTP object storage (:class:`~rex.storage.http_range.HTTPRangeBackend`).

    Raises:
        UnsupportedBackendError: Always raised on instantiation.
    """

    def __init__(self, **kwargs: object) -> None:
        raise UnsupportedBackendError(
            "icloud",
            "iCloud does not provide a public HTTP Range-capable API. "
            "Use Google Drive, OneDrive, or generic HTTP object storage instead.",
        )

    # The remaining methods are unreachable (init always raises), but are
    # defined to satisfy the abstract base class contract for static
    # analysis tools.

    async def fetch_range(self, resource_id: str, start: int, end: int) -> bytes:
        """Unreachable — raises on ``__init__``."""
        raise NotImplementedError

    async def stat(self, resource_id: str) -> object:
        """Unreachable — raises on ``__init__``."""
        raise NotImplementedError

    async def health_check(self) -> bool:
        """Unreachable — raises on ``__init__``."""
        raise NotImplementedError

    def auth_requirements(self) -> list[str]:
        """Unreachable — raises on ``__init__``."""
        raise NotImplementedError

    def capabilities(self) -> object:
        """Unreachable — raises on ``__init__``."""
        raise NotImplementedError

    async def close(self) -> None:
        """Unreachable — raises on ``__init__``."""
        raise NotImplementedError
