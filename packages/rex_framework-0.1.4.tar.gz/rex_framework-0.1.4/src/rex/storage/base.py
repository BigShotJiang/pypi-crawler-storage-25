"""
Abstract base class for Rex storage backends.

Defines the contract that every storage backend must implement, including
range-based fetching, resource stat, health checking, and capability
reporting.  All storage backends in the Rex framework inherit from
:class:`BaseStorageBackend`.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class ResourceStat:
    """Metadata about a remote resource.

    Attributes:
        size: Total size of the resource in bytes.
        etag: Opaque entity tag for cache validation (may be empty).
        last_modified: Unix timestamp of the last modification time.
        content_type: MIME type reported by the server (may be empty).
    """

    size: int
    etag: str = ""
    last_modified: Optional[float] = None
    content_type: str = ""


@dataclass
class BackendCapabilities:
    """Describes what a storage backend supports.

    Used by the scheduler and fetch orchestrator to make informed decisions
    about concurrency, batching, and retry strategies.

    Attributes:
        supports_range_requests: Whether the backend honours ``Range`` headers.
        supports_multi_range: Whether the backend accepts multiple ranges in a
            single request (``multipart/byteranges`` responses).
        max_concurrent_requests: Maximum number of simultaneous in-flight
            requests the backend can handle (0 = unlimited).
        max_request_size_bytes: Maximum byte-range size for a single request
            (0 = unlimited).
        rate_limit_rpm: Requests per minute the backend enforces.  0 means
            unlimited (no client-side throttling).
    """

    supports_range_requests: bool = True
    supports_multi_range: bool = False
    max_concurrent_requests: int = 0
    max_request_size_bytes: int = 0
    rate_limit_rpm: int = 0


@dataclass
class RequestMetrics:
    """Per-request timing and byte-transfer metrics.

    Attributes:
        start_time: Monotonic timestamp when the request was initiated.
        end_time: Monotonic timestamp when the request completed.
        duration_ms: Wall-clock duration in milliseconds.
        bytes_transferred: Number of payload bytes received.
        status_code: HTTP status code (0 if not applicable).
        success: Whether the request succeeded.
        error: Human-readable error description on failure.
    """

    start_time: float = 0.0
    end_time: float = 0.0
    duration_ms: float = 0.0
    bytes_transferred: int = 0
    status_code: int = 0
    success: bool = False
    error: str = ""

    def finish(
        self,
        *,
        bytes_transferred: int = 0,
        status_code: int = 0,
        error: str = "",
    ) -> None:
        """Mark the request as finished and compute duration."""
        self.end_time = time.monotonic()
        self.duration_ms = (self.end_time - self.start_time) * 1000.0
        self.bytes_transferred = bytes_transferred
        self.status_code = status_code
        self.success = error == ""
        self.error = error

    def reset(self) -> None:
        """Reset metrics for reuse."""
        self.start_time = 0.0
        self.end_time = 0.0
        self.duration_ms = 0.0
        self.bytes_transferred = 0
        self.status_code = 0
        self.success = False
        self.error = ""

    @classmethod
    def create(cls) -> RequestMetrics:
        """Create a new metrics instance and record the start time."""
        m = cls()
        m.start_time = time.monotonic()
        return m


class BaseStorageBackend(ABC):
    """Abstract base class for all Rex storage backends.

    Subclasses must implement :meth:`fetch_range`, :meth:`stat`,
    :meth:`health_check`, :meth:`auth_requirements`, :meth:`capabilities`,
    and :meth:`close`.

    Lifecycle::

        backend = ConcreteBackend(...)
        await backend.health_check()       # verify connectivity
        data = await backend.fetch_range("model.bin", 0, 1024)
        info = await backend.stat("model.bin")
        await backend.close()              # clean up sessions, connections

    All public methods are ``async`` (except :meth:`capabilities` and
    :meth:`auth_requirements` which are synchronous introspection calls).
    """

    def __init__(self) -> None:
        import structlog

        self._log = structlog.get_logger(__name__)

    # ── Core operations ───────────────────────────────────────────────────

    @abstractmethod
    async def fetch_range(
        self,
        resource_id: str,
        start: int,
        end: int,
    ) -> bytes:
        """Fetch a half-open byte range ``[start, end)`` from *resource_id*.

        Args:
            resource_id: Backend-specific resource identifier (file path, URL
                slug, object key, etc.).
            start: Inclusive start byte offset.
            end: Exclusive end byte offset.

        Returns:
            The raw bytes in the requested range.

        Raises:
            FetchError: The server returned an error or the data could not be
                read.
            StorageUnavailableError: The backend is unreachable.
            RateLimitError: The backend signalled rate-limiting.
        """

    @abstractmethod
    async def stat(self, resource_id: str) -> ResourceStat:
        """Return metadata for *resource_id* without fetching the body.

        This is typically implemented via a ``HEAD`` request or an equivalent
        lightweight metadata API call.

        Args:
            resource_id: Backend-specific resource identifier.

        Returns:
            A :class:`ResourceStat` with size, etag, and other metadata.
        """

    @abstractmethod
    async def health_check(self) -> bool:
        """Verify that the backend is reachable and authenticated.

        Returns:
            ``True`` if the backend is healthy.
        """

    # ── Introspection ─────────────────────────────────────────────────────

    @abstractmethod
    def auth_requirements(self) -> list[str]:
        """Return a list of authentication credential names this backend needs.

        Example::

            ["AUTH_TOKEN", "API_KEY"]

        Used by the CLI and configuration validators to prompt the user.
        """

    @abstractmethod
    def capabilities(self) -> BackendCapabilities:
        """Return a :class:`BackendCapabilities` describing supported features."""

    # ── Lifecycle ─────────────────────────────────────────────────────────

    @abstractmethod
    async def close(self) -> None:
        """Release all resources held by this backend (sessions, connections).

        Safe to call multiple times; subsequent calls are no-ops.
        """

    # ── Optional helpers ──────────────────────────────────────────────────

    async def __aenter__(self) -> BaseStorageBackend:
        """Async context manager entry — runs :meth:`health_check`."""
        ok = await self.health_check()
        if not ok:
            from rex.core.errors import StorageUnavailableError

            raise StorageUnavailableError(
                "Storage backend health check failed on context entry"
            )
        return self

    async def __aexit__(
        self,
        exc_type: object,
        exc_val: object,
        exc_tb: object,
    ) -> None:
        """Async context manager exit — calls :meth:`close`."""
        await self.close()

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}>"
