"""
Retry logic with exponential backoff and jitter for Rex storage operations.

Provides a :class:`RetryPolicy` dataclass, an :func:`is_retryable` predicate,
a deterministic :func:`calculate_delay` function, and an :func:`async_retry`
wrapper for decorating arbitrary async callables.
"""

from __future__ import annotations

import asyncio
import functools
import random
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional, TypeVar

import structlog

from rex.core.errors import (
    RateLimitError,
    StorageUnavailableError,
)

log = structlog.get_logger(__name__)

T = TypeVar("T")

# Default set of HTTP status codes that are safe to retry.
_DEFAULT_RETRYABLE_STATUSES: frozenset[int] = frozenset({
    408,  # Request Timeout
    429,  # Too Many Requests
    500,  # Internal Server Error
    502,  # Bad Gateway
    503,  # Service Unavailable
    504,  # Gateway Timeout
})


@dataclass
class RetryPolicy:
    """Configuration for retry behaviour.

    Attributes:
        max_attempts: Maximum number of attempts (including the initial call).
            Set to ``1`` to disable retries.
        base_delay: Base delay in seconds before the first retry.
        max_delay: Upper bound for the calculated delay (cap).
        backoff_factor: Multiplier applied to the delay on each successive
            attempt.  With ``jitter=True`` the delay is randomised within
            ``[base_delay * factor^attempt, base_delay * factor^(attempt+1))``.
        jitter: Whether to add random jitter to prevent thundering-herd.
        retryable_statuses: Set of HTTP status codes that should trigger a
            retry.  Only applies when the caller propagates status codes
            via :exc:`RexError` details.
    """

    max_attempts: int = 3
    base_delay: float = 0.5
    max_delay: float = 30.0
    backoff_factor: float = 2.0
    jitter: bool = True
    retryable_statuses: frozenset[int] = field(
        default_factory=lambda: _DEFAULT_RETRYABLE_STATUSES
    )

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        if self.base_delay < 0:
            raise ValueError("base_delay must be >= 0")
        if self.max_delay < self.base_delay:
            raise ValueError("max_delay must be >= base_delay")


def is_retryable(exc: BaseException) -> bool:
    """Determine whether *exc* is worth retrying.

    The following are considered retryable:

    * :class:`~rex.core.errors.StorageUnavailableError`
    * :class:`~rex.core.errors.RateLimitError`
    * :class:`asyncio.TimeoutError`
    * :class:`aiohttp.ClientError` (connection / payload errors)
    * Any :class:`~rex.core.errors.RexError` whose ``details`` dict contains
      a ``status_code`` in the policy's ``retryable_statuses`` set.

    Args:
        exc: The exception to evaluate.

    Returns:
        ``True`` if the operation should be retried.
    """
    # Network / timeout errors
    if isinstance(exc, asyncio.TimeoutError):
        return True

    # aiohttp client errors
    try:
        if isinstance(exc, __import__("aiohttp").ClientError):
            return True
    except ImportError:
        pass

    # Rex-specific errors
    from rex.core.errors import RexError

    if isinstance(exc, RexError):
        if isinstance(exc, (StorageUnavailableError, RateLimitError)):
            return True
        # Check embedded status code
        status = exc.details.get("status_code")
        if status is not None and int(status) in _DEFAULT_RETRYABLE_STATUSES:
            return True

    return False


def calculate_delay(attempt: int, policy: RetryPolicy) -> float:
    """Compute the sleep delay for *attempt* (0-indexed) using *policy*.

    Formula (no jitter)::

        delay = min(base_delay * (backoff_factor ** attempt), max_delay)

    With jitter, the actual delay is uniformly sampled from
    ``[base_delay * factor^attempt, base_delay * factor^(attempt+1))``,
    capped at ``max_delay``.

    Args:
        attempt: 0-indexed retry attempt number (0 = first retry).
        policy: The :class:`RetryPolicy` to use.

    Returns:
        Delay in seconds (always >= 0).
    """
    delay = policy.base_delay * (policy.backoff_factor ** attempt)
    delay = min(delay, policy.max_delay)

    if policy.jitter:
        upper = min(
            policy.base_delay * (policy.backoff_factor ** (attempt + 1)),
            policy.max_delay,
        )
        delay = random.uniform(delay, upper)

    return max(0.0, delay)


async def async_retry(
    fn: Callable[..., Awaitable[T]],
    policy: Optional[RetryPolicy] = None,
) -> T:
    """Execute *fn* with retry logic according to *policy*.

    Args:
        fn: An async callable to execute.
        policy: Retry configuration.  Uses a default policy if ``None``.

    Returns:
        The return value of *fn* on the first successful attempt.

    Raises:
        The last exception raised by *fn* if all attempts are exhausted.
    """
    if policy is None:
        policy = RetryPolicy()

    last_exc: Optional[BaseException] = None

    for attempt in range(policy.max_attempts):
        try:
            return await fn()
        except Exception as exc:
            last_exc = exc
            is_last = attempt >= policy.max_attempts - 1

            if is_last or not is_retryable(exc):
                log.warning(
                    "retry_failed_final",
                    attempt=attempt + 1,
                    max_attempts=policy.max_attempts,
                    error=str(exc),
                )
                raise

            # Respect Retry-After from RateLimitError
            wait = 0.0
            if isinstance(exc, RateLimitError) and exc.retry_after_seconds > 0:
                wait = exc.retry_after_seconds
            else:
                wait = calculate_delay(attempt, policy)

            log.debug(
                "retry_attempt",
                attempt=attempt + 1,
                max_attempts=policy.max_attempts,
                wait_seconds=round(wait, 3),
                error=str(exc),
            )
            await asyncio.sleep(wait)

    # Should never reach here, but satisfy the type checker.
    raise last_exc  # type: ignore[misc]
