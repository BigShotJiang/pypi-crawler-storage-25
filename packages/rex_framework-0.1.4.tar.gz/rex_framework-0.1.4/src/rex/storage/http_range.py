"""
Generic HTTP Range-based storage backend (RFC 7233).

Fetches byte ranges from any HTTP server that supports the ``Range`` header.
Includes automatic retry with exponential backoff, client-side rate limiting,
persistent keep-alive sessions, and proper error mapping to Rex error types.

This is the primary backend for serving Rex model weights from HTTP object
storage (S3 presigned URLs, GCS, Cloudflare R2, Nginx, etc.).

Example::

    backend = HTTPRangeBackend(
        base_url="https://storage.example.com/rex-models",
        auth_token="Bearer sk-…",
        rate_limit_rpm=300,
    )
    data = await backend.fetch_range("llama-7b.bin", 0, 524_288)
"""

from __future__ import annotations

import asyncio
from typing import Any, Optional
from urllib.parse import urljoin

import aiohttp
import structlog

from rex.core.errors import (
    AuthenticationError,
    FetchError,
    RateLimitError,
    StorageError,
    StorageUnavailableError,
)
from rex.storage.auth import load_token_from_env, redact_token
from rex.storage.base import (
    BaseStorageBackend,
    BackendCapabilities,
    RequestMetrics,
    ResourceStat,
)
from rex.storage.retries import RetryPolicy, async_retry, calculate_delay, is_retryable
from rex.storage.throttling import TokenBucketRateLimiter

log = structlog.get_logger(__name__)


class HTTPRangeBackend(BaseStorageBackend):
    """Fetch byte ranges from any HTTP server supporting ``Range`` headers.

    Args:
        base_url: Prefix prepended to every *resource_id* to form the full
            URL.  Trailing slash is normalised.
        auth_token: Bearer token sent as ``Authorization`` header.  If
            ``"auto"``, the token is loaded from ``REX_AUTH_TOKEN`` env var.
        timeout_connect: Connection timeout in seconds.
        timeout_read: Per-read timeout in seconds.
        timeout_total: Total request timeout in seconds.
        max_attempts: Maximum retry attempts for transient errors.
        base_delay: Base retry delay in seconds (exponential backoff).
        max_delay: Maximum retry delay cap in seconds.
        backoff_factor: Exponential multiplier for retry delay.
        rate_limit_rpm: Client-side requests-per-minute cap (0 = unlimited).
        connector_limit: Maximum concurrent connections on the session pool.
        headers: Extra HTTP headers merged into every request.
    """

    def __init__(
        self,
        base_url: str,
        auth_token: Optional[str] = None,
        *,
        timeout_connect: float = 10.0,
        timeout_read: float = 30.0,
        timeout_total: float = 60.0,
        max_attempts: int = 3,
        base_delay: float = 0.5,
        max_delay: float = 30.0,
        backoff_factor: float = 2.0,
        rate_limit_rpm: int = 0,
        connector_limit: int = 100,
        headers: Optional[dict[str, str]] = None,
    ) -> None:
        super().__init__()

        # Normalise base_url — ensure trailing slash
        self._base_url = base_url.rstrip("/") + "/"
        self._extra_headers = headers or {}

        # Auth token resolution
        if auth_token == "auto":
            token = load_token_from_env()
            self._auth_token = token
        else:
            self._auth_token = auth_token

        if self._auth_token:
            self._log.debug(
                "http_backend_auth_configured",
                token_preview=redact_token(self._auth_token),
            )

        # Timeouts (aiohttp.ClientTimeout)
        self._timeout = aiohttp.ClientTimeout(
            total=timeout_total,
            connect=timeout_connect,
            sock_read=timeout_read,
        )

        # Retry policy
        self._retry_policy = RetryPolicy(
            max_attempts=max_attempts,
            base_delay=base_delay,
            max_delay=max_delay,
            backoff_factor=backoff_factor,
        )

        # Rate limiter
        self._limiter = TokenBucketRateLimiter(rpm=float(rate_limit_rpm))
        self._rate_limit_rpm = rate_limit_rpm

        # Connector settings
        self._connector_limit = connector_limit

        # Lazy session
        self._session: Optional[aiohttp.ClientSession] = None
        self._closed = False

    # ── Session management ────────────────────────────────────────────────

    def _ensure_session(self) -> aiohttp.ClientSession:
        """Create the ``ClientSession`` on first use (lazy initialisation).

        Returns:
            The existing or newly created session.

        Raises:
            RuntimeError: If the backend has already been closed.
        """
        if self._closed:
            raise RuntimeError("HTTPRangeBackend is closed; create a new instance")
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(limit=self._connector_limit)
            self._session = aiohttp.ClientSession(
                connector=connector,
                timeout=self._timeout,
                headers=self._build_default_headers(),
                raise_for_status=False,
            )
            self._log.debug(
                "http_session_created",
                limit=self._connector_limit,
            )
        return self._session

    def _build_default_headers(self) -> dict[str, str]:
        """Build the default headers sent with every request."""
        h: dict[str, str] = {
            "Accept": "*/*",
            "Accept-Encoding": "identity",
            "User-Agent": "RexStorage/0.1.0",
            "Connection": "keep-alive",
        }
        if self._auth_token:
            h["Authorization"] = f"Bearer {self._auth_token}"
        h.update(self._extra_headers)
        return h

    def _url_for(self, resource_id: str) -> str:
        """Build the full URL for *resource_id*."""
        return urljoin(self._base_url, resource_id)

    # ── Core operations ───────────────────────────────────────────────────

    async def fetch_range(
        self,
        resource_id: str,
        start: int,
        end: int,
    ) -> bytes:
        """Fetch bytes ``[start, end)`` using an HTTP Range request.

        Implements retry with exponential backoff on 5xx / timeout errors,
        client-side rate limiting, and respects ``Retry-After`` headers.
        """
        if start < 0 or end <= start:
            raise ValueError(f"Invalid byte range: [{start}, {end})")

        await self._limiter.acquire()

        metrics = RequestMetrics.create()

        last_exc: Optional[Exception] = None

        for attempt in range(self._retry_policy.max_attempts):
            try:
                data, status = await self._single_fetch(
                    resource_id, start, end
                )
                metrics.finish(
                    bytes_transferred=len(data),
                    status_code=status,
                )
                self._log.debug(
                    "fetch_range_success",
                    resource_id=resource_id,
                    start=start,
                    end=end,
                    bytes=len(data),
                    status=status,
                    duration_ms=round(metrics.duration_ms, 2),
                    attempt=attempt + 1,
                )
                return data

            except (StorageUnavailableError, RateLimitError, asyncio.TimeoutError) as exc:
                last_exc = exc
                is_last = attempt >= self._retry_policy.max_attempts - 1

                if is_last:
                    break

                # Respect Retry-After header
                wait: float
                if isinstance(exc, RateLimitError) and exc.retry_after_seconds > 0:
                    wait = exc.retry_after_seconds
                else:
                    wait = calculate_delay(attempt, self._retry_policy)

                self._log.warning(
                    "fetch_range_retry",
                    resource_id=resource_id,
                    attempt=attempt + 1,
                    max_attempts=self._retry_policy.max_attempts,
                    wait_seconds=round(wait, 3),
                    error=str(exc),
                )
                await asyncio.sleep(wait)

            except FetchError:
                raise  # Non-retryable fetch error

        # All retries exhausted
        metrics.finish(error=str(last_exc) if last_exc else "unknown")
        self._log.error(
            "fetch_range_exhausted",
            resource_id=resource_id,
            start=start,
            end=end,
            attempts=self._retry_policy.max_attempts,
            error=str(last_exc),
        )
        raise FetchError(
            chunk_id=f"{resource_id}[{start}:{end}]",
            resource_id=resource_id,
            details={
                "attempts": self._retry_policy.max_attempts,
                "last_error": str(last_exc),
            },
        )

    async def _single_fetch(
        self,
        resource_id: str,
        start: int,
        end: int,
    ) -> tuple[bytes, int]:
        """Execute a single HTTP GET with Range header.

        Returns:
            Tuple of (response_bytes, http_status_code).

        Raises:
            FetchError: On non-retryable HTTP errors.
            StorageUnavailableError: On connection failures.
            RateLimitError: On HTTP 429.
        """
        session = self._ensure_session()
        url = self._url_for(resource_id)
        range_header = f"bytes={start}-{end - 1}"

        try:
            async with session.get(
                url,
                headers={"Range": range_header},
            ) as resp:
                status = resp.status

                if status == 206:
                    body = await resp.read()
                    return body, status

                if status == 416:
                    # Requested Range Not Satisfiable
                    raise FetchError(
                        chunk_id=f"{resource_id}[{start}:{end}]",
                        resource_id=resource_id,
                        status_code=status,
                        details={
                            "content_range": resp.headers.get("Content-Range", ""),
                        },
                    )

                if status == 401 or status == 403:
                    raise AuthenticationError(
                        f"Authentication failed for {url} (HTTP {status})"
                    )

                if status == 429:
                    retry_after = 0.0
                    ra_header = resp.headers.get("Retry-After")
                    if ra_header:
                        try:
                            retry_after = float(ra_header)
                        except ValueError:
                            pass
                    raise RateLimitError(
                        f"Rate limited by {url} (HTTP 429)",
                        retry_after_seconds=retry_after,
                    )

                if status == 200:
                    # Server ignored Range header — read whole body (fallback)
                    self._log.warning(
                        "http_range_ignored",
                        resource_id=resource_id,
                        status=status,
                    )
                    body = await resp.read()
                    if end <= len(body):
                        return body[start:end], status
                    raise FetchError(
                        chunk_id=f"{resource_id}[{start}:{end}]",
                        resource_id=resource_id,
                        status_code=status,
                        details={"reason": "Response too short for requested range"},
                    )

                if 500 <= status <= 599:
                    raise StorageUnavailableError(
                        f"Server error from {url} (HTTP {status})"
                    )

                # Other 4xx errors — non-retryable
                raise FetchError(
                    chunk_id=f"{resource_id}[{start}:{end}]",
                    resource_id=resource_id,
                    status_code=status,
                )

        except aiohttp.ClientConnectorError as exc:
            raise StorageUnavailableError(
                f"Cannot connect to {url}: {exc}"
            ) from exc
        except asyncio.TimeoutError:
            raise StorageUnavailableError(
                f"Request to {url} timed out"
            )
        except (AuthenticationError, FetchError, StorageUnavailableError, RateLimitError):
            raise
        except aiohttp.ClientError as exc:
            raise StorageUnavailableError(
                f"HTTP client error for {url}: {exc}"
            ) from exc

    async def stat(self, resource_id: str) -> ResourceStat:
        """Retrieve resource metadata via HTTP HEAD.

        Falls back to GET if HEAD is not supported.
        """
        session = self._ensure_session()
        url = self._url_for(resource_id)

        await self._limiter.acquire()

        try:
            async with session.head(url) as resp:
                if resp.status in (404,):
                    raise FetchError(
                        chunk_id="stat",
                        resource_id=resource_id,
                        status_code=resp.status,
                    )
                if resp.status in (401, 403):
                    raise AuthenticationError(
                        f"Authentication failed for {url} (HTTP {resp.status})"
                    )
                if resp.status >= 500:
                    raise StorageUnavailableError(
                        f"Server error from {url} (HTTP {resp.status})"
                    )
                if resp.status == 405:
                    # HEAD not allowed — fall back to GET with Range 0-0
                    return await self._stat_via_get(resource_id)

                return self._parse_stat_headers(resp.headers, resource_id)

        except aiohttp.ClientConnectorError as exc:
            raise StorageUnavailableError(
                f"Cannot connect to {url}: {exc}"
            ) from exc
        except asyncio.TimeoutError:
            raise StorageUnavailableError(f"HEAD request to {url} timed out")
        except (AuthenticationError, FetchError, StorageUnavailableError):
            raise
        except aiohttp.ClientError as exc:
            raise StorageUnavailableError(
                f"HTTP client error for {url}: {exc}"
            ) from exc

    async def _stat_via_get(self, resource_id: str) -> ResourceStat:
        """Fallback: stat using a GET with Range: bytes=0-0."""
        session = self._ensure_session()
        url = self._url_for(resource_id)
        try:
            async with session.get(
                url,
                headers={"Range": "bytes=0-0"},
            ) as resp:
                if resp.status not in (206, 200):
                    raise FetchError(
                        chunk_id="stat",
                        resource_id=resource_id,
                        status_code=resp.status,
                    )
                return self._parse_stat_headers(resp.headers, resource_id)
        except aiohttp.ClientError as exc:
            raise StorageUnavailableError(f"GET stat for {url} failed: {exc}") from exc

    @staticmethod
    def _parse_stat_headers(
        headers: aiohttp.CIMultiDictProxy[str],
        resource_id: str,
    ) -> ResourceStat:
        """Parse common HTTP headers into a :class:`ResourceStat`."""
        size = int(headers.get("Content-Length", 0))
        etag = headers.get("ETag", "")
        content_type = headers.get("Content-Type", "")
        last_modified_str = headers.get("Last-Modified", "")
        last_modified: Optional[float] = None
        if last_modified_str:
            try:
                from email.utils import parsedate_to_datetime

                last_modified = parsedate_to_datetime(last_modified_str).timestamp()
            except (ValueError, ImportError):
                pass

        # If Content-Range is present, use the total size from it
        cr = headers.get("Content-Range", "")
        if cr and "/" in cr:
            try:
                total_str = cr.split("/")[-1].strip()
                if total_str != "*":
                    size = int(total_str)
            except ValueError:
                pass

        return ResourceStat(
            size=size,
            etag=etag,
            last_modified=last_modified,
            content_type=content_type,
        )

    async def health_check(self) -> bool:
        """Verify connectivity by issuing a HEAD to ``base_url``."""
        session = self._ensure_session()
        try:
            async with session.head(self._base_url) as resp:
                healthy = resp.status < 500
                self._log.debug(
                    "http_health_check",
                    url=self._base_url,
                    status=resp.status,
                    healthy=healthy,
                )
                return healthy
        except Exception:
            self._log.warning("http_health_check_failed", url=self._base_url)
            return False

    # ── Introspection ─────────────────────────────────────────────────────

    def auth_requirements(self) -> list[str]:
        """List required auth credentials."""
        reqs = []
        if self._auth_token:
            reqs.append("AUTH_TOKEN")
        return reqs

    def capabilities(self) -> BackendCapabilities:
        """Return this backend's capabilities."""
        return BackendCapabilities(
            supports_range_requests=True,
            supports_multi_range=False,
            max_concurrent_requests=self._connector_limit,
            max_request_size_bytes=0,  # no client-side limit
            rate_limit_rpm=self._rate_limit_rpm,
        )

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def close(self) -> None:
        """Close the underlying ``aiohttp.ClientSession``."""
        if self._session and not self._session.closed:
            await self._session.close()
            self._log.debug("http_session_closed")
        self._closed = True
