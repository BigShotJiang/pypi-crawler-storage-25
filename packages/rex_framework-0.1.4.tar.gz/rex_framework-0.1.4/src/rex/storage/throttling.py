"""
Token-bucket rate limiter for Rex storage backends.

Implements a classic token-bucket algorithm to cap outgoing request rates
and avoid triggering server-side rate limits.  Each :meth:`acquire` call
blocks (asynchronously) until a token is available.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional

import structlog

log = structlog.get_logger(__name__)


@dataclass
class ThrottleStats:
    """Snapshot of the rate limiter's current state.

    Attributes:
        rpm: Configured requests-per-minute limit.
        tokens_remaining: Approximate tokens currently in the bucket.
        bucket_capacity: Maximum tokens the bucket can hold.
        total_acquired: Cumulative number of successful acquisitions.
        total_waited: Cumulative time spent waiting (seconds).
        total_rejected: Number of calls that would have exceeded the limit
            if ``reject_instead_of_wait`` were enabled.
    """

    rpm: float = 0.0
    tokens_remaining: float = 0.0
    bucket_capacity: float = 0.0
    total_acquired: int = 0
    total_waited: float = 0.0
    total_rejected: int = 0


class TokenBucketRateLimiter:
    """Async token-bucket rate limiter.

    Tokens are replenished at a constant rate.  Each call to :meth:`acquire`
    consumes one token, blocking asynchronously if the bucket is empty.

    Args:
        rpm: Maximum number of requests per minute (0 = unlimited).
        burst: Maximum number of tokens that can accumulate (bucket capacity).
            Defaults to *rpm* if not specified, allowing a short burst.

    Example::

        limiter = TokenBucketRateLimiter(rpm=60)
        await limiter.acquire()  # blocks if rate exceeded
    """

    def __init__(
        self,
        rpm: float = 0.0,
        burst: Optional[float] = None,
    ) -> None:
        if rpm < 0:
            raise ValueError(f"rpm must be >= 0, got {rpm}")
        self._rpm = rpm
        self._burst = burst if burst is not None else rpm
        if self._burst <= 0 and rpm > 0:
            self._burst = rpm

        self._tokens: float = self._burst
        self._last_refill: float = time.monotonic()

        self._total_acquired: int = 0
        self._total_waited: float = 0.0
        self._total_rejected: int = 0

        self._lock = asyncio.Lock()

    @property
    def rpm(self) -> float:
        """Configured requests-per-minute limit."""
        return self._rpm

    @property
    def unlimited(self) -> bool:
        """``True`` if no rate limiting is configured."""
        return self._rpm <= 0

    def _refill(self) -> None:
        """Add tokens based on elapsed time since last refill."""
        if self.unlimited:
            return
        now = time.monotonic()
        elapsed = now - self._last_refill
        if elapsed > 0:
            tokens_to_add = (elapsed / 60.0) * self._rpm
            self._tokens = min(self._tokens + tokens_to_add, self._burst)
            self._last_refill = now

    def get_wait_time(self) -> float:
        """Return the number of seconds until the next token is available.

        Returns ``0.0`` immediately if a token is available or if the
        limiter is unlimited.

        Returns:
            Seconds to wait (may be 0.0).
        """
        if self.unlimited:
            return 0.0
        self._refill()
        if self._tokens >= 1.0:
            return 0.0
        deficit = 1.0 - self._tokens
        return (deficit / self._rpm) * 60.0

    async def acquire(self) -> None:
        """Consume one token, waiting if necessary.

        If the bucket is empty the coroutine sleeps until a token is
        replenished.  If the rate limiter is unlimited this returns
        immediately.
        """
        if self.unlimited:
            return

        async with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                self._total_acquired += 1
                return

            # Calculate how long to wait for one token
            wait = self.get_wait_time()
            log.debug(
                "rate_limiter_throttling",
                wait_seconds=round(wait, 3),
                tokens_remaining=self._tokens,
            )

        # Sleep *outside* the lock so other coroutines aren't blocked
        if wait > 0:
            await asyncio.sleep(wait)
            self._total_waited += wait

        # Re-acquire lock and consume token
        async with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                self._total_acquired += 1
            else:
                # Edge case: still no token after waiting — consume anyway
                # to avoid livelock under extreme contention.
                self._total_acquired += 1
                log.warning("rate_limiter_underflow", tokens=self._tokens)

    def stats(self) -> ThrottleStats:
        """Return a snapshot of the limiter's current metrics."""
        self._refill()
        return ThrottleStats(
            rpm=self._rpm,
            tokens_remaining=self._tokens,
            bucket_capacity=self._burst,
            total_acquired=self._total_acquired,
            total_waited=self._total_waited,
            total_rejected=self._total_rejected,
        )

    def reset(self) -> None:
        """Reset the limiter to its initial state."""
        self._tokens = self._burst
        self._last_refill = time.monotonic()
        self._total_acquired = 0
        self._total_waited = 0.0
        self._total_rejected = 0
