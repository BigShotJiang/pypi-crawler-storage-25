"""Async utilities for Rex."""
import asyncio
from typing import Any, Coroutine, TypeVar

T = TypeVar("T")


async def gather_with_concurrency(
    coros: list[Coroutine[Any, Any, T]],
    max_concurrent: int = 4,
) -> list[T]:
    """Run coroutines with bounded concurrency using a semaphore."""
    if not coros:
        return []

    sem = asyncio.Semaphore(max_concurrent)

    async def _wrap(coro: Coroutine[Any, Any, T]) -> T:
        async with sem:
            return await coro

    return await asyncio.gather(*[_wrap(c) for c in coros])


async def run_sync_in_executor(fn, *args, **kwargs):
    """Run a synchronous function in the default executor."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: fn(*args, **kwargs))
