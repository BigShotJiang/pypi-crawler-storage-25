"""IO utilities for Rex."""
from pathlib import Path
from typing import Union


def ensure_directory(path: Union[str, Path]) -> Path:
    """Ensure a directory exists, creating it if needed."""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def read_bytes(path: Union[str, Path]) -> bytes:
    """Read a file as bytes."""
    return Path(path).read_bytes()


def write_bytes(path: Union[str, Path], data: bytes) -> None:
    """Write bytes to a file."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)


def safe_json_load(path: Union[str, Path]) -> dict:
    """Load JSON from a file, returning empty dict on error."""
    import json
    try:
        return json.loads(Path(path).read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
