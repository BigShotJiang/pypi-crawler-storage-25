"""Memory utilities for Rex.

Status: Implemented
"""

import os
import sys
from typing import Optional


def get_memory_usage_bytes() -> int:
    """Get current process RSS memory in bytes."""
    try:
        import resource
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    except (ImportError, AttributeError):
        pass

    try:
        # Linux /proc
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
    except (FileNotFoundError, ValueError):
        pass

    return 0


def format_bytes(n: int) -> str:
    """Format byte count as human-readable string."""
    if n == 0:
        return "0 B"
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def available_memory_bytes() -> int:
    """Estimate available system memory in bytes."""
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    except (ValueError, OSError):
        return 0
