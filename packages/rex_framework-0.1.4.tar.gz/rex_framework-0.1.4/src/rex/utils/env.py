"""Environment variable utilities.

Status: Implemented
"""
import os
from typing import Optional


def get_env_bool(name: str, default: bool = False) -> bool:
    """Get a boolean from an environment variable."""
    val = os.environ.get(name, "").strip().lower()
    if val in ("1", "true", "yes", "on"):
        return True
    if val in ("0", "false", "no", "off"):
        return False
    return default


def get_env_int(name: str, default: int = 0) -> int:
    """Get an integer from an environment variable."""
    val = os.environ.get(name, "").strip()
    try:
        return int(val)
    except (ValueError, TypeError):
        return default


def get_env_float(name: str, default: float = 0.0) -> float:
    """Get a float from an environment variable."""
    val = os.environ.get(name, "").strip()
    try:
        return float(val)
    except (ValueError, TypeError):
        return default


def get_env_str(name: str, default: str = "") -> str:
    """Get a string from an environment variable."""
    return os.environ.get(name, default)
