"""Platform detection utilities.

Status: Implemented
"""
import platform
import sys
from dataclasses import dataclass
from typing import Optional


@dataclass
class PlatformInfo:
    """Detected platform information."""
    system: str
    machine: str
    python_version: str
    is_colab: bool = False
    is_kaggle: bool = False
    cuda_available: bool = False
    cuda_version: str = ""
    torch_version: str = ""
    processor_count: int = 0


def get_platform_info() -> PlatformInfo:
    """Detect the current platform and available hardware."""
    info = PlatformInfo(
        system=platform.system(),
        machine=platform.machine(),
        python_version=platform.python_version(),
        processor_count=os_cpu_count(),
    )

    # Detect Colab
    try:
        import google.colab
        info.is_colab = True
    except ImportError:
        info.is_colab = "COLAB_GPU" in os.environ or "DATALAB_SETTINGS" in os.environ

    # Detect Kaggle
    info.is_kaggle = "KAGGLE_KERNEL_RUN_TYPE" in os.environ

    # Detect CUDA
    try:
        import torch
        info.torch_version = getattr(torch, "__version__", "")
        info.cuda_available = torch.cuda.is_available()
        if info.cuda_available:
            info.cuda_version = str(torch.version.cuda or "")
    except ImportError:
        pass

    return info


def os_cpu_count() -> int:
    try:
        return os.cpu_count() or 1
    except AttributeError:
        return 1


import os
