"""
Cache invariant checker for the Rex framework.

Enforces the critical invariant that the total local bytes (resident + cached)
must not exceed max_local_fraction of total model bytes. This prevents the
entire model from being loaded locally, which would defeat the purpose of
remote execution.

The checker includes a configurable safety margin (default 5%) to ensure
the invariant is checked conservatively, avoiding edge-case violations
from race conditions or accounting drift.
"""

from __future__ import annotations

from dataclasses import dataclass

import structlog

from rex.core.errors import InvariantViolationError

logger = structlog.get_logger(__name__)

# Default safety margin: check as if 5% more bytes were used
DEFAULT_SAFETY_MARGIN_FRACTION: float = 0.05


@dataclass
class InvariantCheckResult:
    """Result of an invariant check."""
    is_valid: bool
    resident_bytes: int
    cached_bytes: int
    total_local_bytes: int
    effective_local_bytes: int  # after safety margin
    max_allowed_bytes: int
    total_model_bytes: int
    fraction_used: float
    max_fraction: float
    safety_margin_fraction: float

    def __str__(self) -> str:
        status = "PASS" if self.is_valid else "FAIL"
        return (
            f"InvariantCheck[{status}]: "
            f"{self.effective_local_bytes:,}/{self.max_allowed_bytes:,} bytes "
            f"({self.fraction_used:.1%}/{self.max_fraction:.1%})"
        )


class InvariantChecker:
    """Enforces the 'no full model local' invariant.

    After every cache insertion, this checker should be invoked to verify
    that total local bytes do not exceed the configured maximum fraction
    of total model bytes.

    A safety margin ensures that the check is conservative: the effective
    local bytes are computed as:

        effective = total_local / (1 - safety_margin_fraction)

    This means we trigger violations slightly before the hard limit,
    providing a buffer for concurrent operations.

    Args:
        total_model_bytes: Total size of the model in bytes.
        max_local_fraction: Maximum fraction of model allowed locally.
        safety_margin_fraction: Safety margin (0.0–0.5). Default 0.05 (5%).
    """

    def __init__(
        self,
        total_model_bytes: int,
        max_local_fraction: float = 0.4,
        safety_margin_fraction: float = DEFAULT_SAFETY_MARGIN_FRACTION,
    ) -> None:
        if total_model_bytes <= 0:
            raise ValueError(
                f"total_model_bytes must be positive, got {total_model_bytes}"
            )
        if not (0.0 < max_local_fraction <= 1.0):
            raise ValueError(
                f"max_local_fraction must be in (0, 1], got {max_local_fraction}"
            )
        if not (0.0 <= safety_margin_fraction < 0.5):
            raise ValueError(
                f"safety_margin_fraction must be in [0, 0.5), "
                f"got {safety_margin_fraction}"
            )

        self.total_model_bytes = total_model_bytes
        self.max_local_fraction = max_local_fraction
        self.safety_margin_fraction = safety_margin_fraction
        self.max_allowed_bytes = int(
            total_model_bytes * max_local_fraction
        )
        self._log = logger.bind(
            component="invariant_checker",
            total_model_bytes=total_model_bytes,
            max_local_fraction=max_local_fraction,
            max_allowed_bytes=self.max_allowed_bytes,
        )
        self._log.info(
            "invariant_checker_initialized",
            max_allowed_mb=self.max_allowed_bytes / (1024 * 1024),
        )

    def check_invariant(
        self,
        resident_bytes: int,
        cached_bytes: int,
        raise_on_violation: bool = True,
    ) -> InvariantCheckResult:
        """Check if the cache invariant is satisfied.

        Computes effective local bytes by applying the safety margin,
        then verifies the result is within the allowed maximum.

        Args:
            resident_bytes: Bytes of chunks currently resident in memory.
            cached_bytes: Bytes of chunks in local cache storage.
            raise_on_violation: If True, raise InvariantViolationError
                when the invariant is violated. If False, just return
                the result.

        Returns:
            InvariantCheckResult with detailed check information.

        Raises:
            InvariantViolationError: If invariant is violated and
                raise_on_violation is True.
        """
        total_local = resident_bytes + cached_bytes

        # Apply safety margin: treat as if we're using more than we are
        if self.safety_margin_fraction > 0:
            divisor = 1.0 - self.safety_margin_fraction
            effective_local = int(total_local / divisor)
        else:
            effective_local = total_local

        is_valid = effective_local <= self.max_allowed_bytes
        fraction_used = (
            effective_local / self.total_model_bytes
            if self.total_model_bytes > 0
            else 0.0
        )

        result = InvariantCheckResult(
            is_valid=is_valid,
            resident_bytes=resident_bytes,
            cached_bytes=cached_bytes,
            total_local_bytes=total_local,
            effective_local_bytes=effective_local,
            max_allowed_bytes=self.max_allowed_bytes,
            total_model_bytes=self.total_model_bytes,
            fraction_used=fraction_used,
            max_fraction=self.max_local_fraction,
            safety_margin_fraction=self.safety_margin_fraction,
        )

        if is_valid:
            self._log.debug("invariant_check_pass", result=str(result))
        else:
            self._log.error("invariant_check_fail", result=str(result))
            if raise_on_violation:
                raise InvariantViolationError(
                    resident_bytes=resident_bytes,
                    model_bytes=self.total_model_bytes,
                    fraction=fraction_used,
                    max_fraction=self.max_local_fraction,
                )

        return result

    def bytes_until_violation(
        self,
        resident_bytes: int,
        cached_bytes: int,
    ) -> int:
        """Compute how many more bytes can be stored before violation.

        Args:
            resident_bytes: Current resident bytes.
            cached_bytes: Current cached bytes.

        Returns:
            Number of additional bytes that can be stored, accounting
            for the safety margin. Returns 0 if already at or past limit.
        """
        total_local = resident_bytes + cached_bytes
        # Account for safety margin
        if self.safety_margin_fraction > 0:
            divisor = 1.0 - self.safety_margin_fraction
            effective_max = int(self.max_allowed_bytes * divisor)
        else:
            effective_max = self.max_allowed_bytes

        remaining = effective_max - total_local
        return max(0, remaining)

    def update_model_size(self, new_total_model_bytes: int) -> None:
        """Update the model size and recalculate allowed bytes.

        This is useful when the manifest is loaded after cache
        initialization.

        Args:
            new_total_model_bytes: New total model size in bytes.
        """
        if new_total_model_bytes <= 0:
            raise ValueError("new_total_model_bytes must be positive")

        self.total_model_bytes = new_total_model_bytes
        self.max_allowed_bytes = int(
            new_total_model_bytes * self.max_local_fraction
        )
        self._log.info(
            "invariant_checker_model_size_updated",
            new_total_mb=new_total_model_bytes / (1024 * 1024),
            new_max_allowed_mb=self.max_allowed_bytes / (1024 * 1024),
        )

    def __repr__(self) -> str:
        return (
            f"InvariantChecker("
            f"model_bytes={self.total_model_bytes}, "
            f"max_fraction={self.max_local_fraction}, "
            f"max_allowed={self.max_allowed_bytes}, "
            f"safety_margin={self.safety_margin_fraction})"
        )


if __name__ == "__main__":
    import asyncio

    # === Basic invariant check tests ===
    print("=== InvariantChecker Tests ===\n")

    # Test 1: Normal operation — well under limit
    print("Test 1: Well under limit")
    checker = InvariantChecker(
        total_model_bytes=1_000_000_000,
        max_local_fraction=0.4,
        safety_margin_fraction=0.05,
    )
    result = checker.check_invariant(
        resident_bytes=100_000_000,
        cached_bytes=100_000_000,
        raise_on_violation=False,
    )
    assert result.is_valid, f"Expected valid, got {result}"
    print(f"  Result: {result}")
    print(f"  Bytes until violation: {checker.bytes_until_violation(100_000_000, 100_000_000)}")

    # Test 2: At the boundary (should fail due to safety margin)
    print("\nTest 2: At boundary (with safety margin)")
    checker2 = InvariantChecker(
        total_model_bytes=1_000_000_000,
        max_local_fraction=0.4,
        safety_margin_fraction=0.05,
    )
    # 380M is under 400M but safety margin makes effective = 380M/0.95 ≈ 400M
    result2 = checker2.check_invariant(
        resident_bytes=200_000_000,
        cached_bytes=180_000_000,
        raise_on_violation=False,
    )
    print(f"  Result: {result2}")
    print(f"  Is valid: {result2.is_valid}")
    print(f"  Effective bytes: {result2.effective_local_bytes:,}")

    # Test 3: Over the limit — should raise
    print("\nTest 3: Over limit (should raise)")
    checker3 = InvariantChecker(
        total_model_bytes=1_000_000_000,
        max_local_fraction=0.4,
        safety_margin_fraction=0.05,
    )
    try:
        checker3.check_invariant(
            resident_bytes=250_000_000,
            cached_bytes=200_000_000,
            raise_on_violation=True,
        )
        print("  ERROR: Should have raised InvariantViolationError")
    except InvariantViolationError as e:
        print(f"  Caught expected error: {e}")

    # Test 4: Zero safety margin
    print("\nTest 4: Zero safety margin")
    checker4 = InvariantChecker(
        total_model_bytes=1_000_000_000,
        max_local_fraction=0.4,
        safety_margin_fraction=0.0,
    )
    result4 = checker4.check_invariant(
        resident_bytes=399_000_000,
        cached_bytes=0,
        raise_on_violation=False,
    )
    assert result4.is_valid, f"Expected valid, got {result4}"
    print(f"  399M/400M: {result4}")

    result5 = checker4.check_invariant(
        resident_bytes=401_000_000,
        cached_bytes=0,
        raise_on_violation=False,
    )
    assert not result5.is_valid, f"Expected invalid, got {result5}"
    print(f"  401M/400M: {result5}")

    # Test 5: Invalid construction
    print("\nTest 5: Invalid construction")
    try:
        InvariantChecker(total_model_bytes=0)
        print("  ERROR: Should have raised ValueError")
    except ValueError as e:
        print(f"  Caught: {e}")

    # Test 6: Update model size
    print("\nTest 6: Update model size")
    checker6 = InvariantChecker(
        total_model_bytes=1_000_000_000,
        max_local_fraction=0.4,
    )
    checker6.update_model_size(2_000_000_000)
    assert checker6.max_allowed_bytes == 800_000_000
    print(f"  Updated max allowed: {checker6.max_allowed_bytes:,}")

    # Test 7: bytes_until_violation
    print("\nTest 7: bytes_until_violation")
    remaining = checker.bytes_until_violation(0, 0)
    print(f"  From zero: {remaining:,} bytes")
    assert remaining > 0
    remaining = checker.bytes_until_violation(500_000_000, 0)
    print(f"  From 500M: {remaining:,} bytes")

    print("\n=== All tests passed! ===")
