"""Execution graph modeling utilities for Rex.

Phase 1 introduces explicit DAG abstractions that can be built from the
manifest execution order and chunk lookup metadata. The current runtime
continues to execute sequentially; this module provides analysis data for
future graph-aware scheduling paths.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Optional

from rex.core.types import ChunkAddress


# ---------------------------------------------------------------------------
# Target 6: Numerical optimization — blocked execution + operator fusion
# ---------------------------------------------------------------------------

@dataclass
class BlockedExecutionMetadata:
    """Metadata describing a tiled / blocked matrix execution plan.

    Attributes:
        block_size: Number of rows/columns per tile.
        num_blocks: Total number of blocks in the execution plan.
        block_overlap: Overlap between adjacent blocks (e.g. for convolutions).
    """
    block_size: int
    num_blocks: int
    block_overlap: int = 0


@dataclass
class OperatorFusionHook:
    """Describes a potential operator fusion opportunity.

    Attributes:
        fused_op_name: Name for the fused kernel.
        input_node_names: Ordered list of node names to be fused.
        output_dtype: Expected output dtype after fusion.
    """
    fused_op_name: str
    input_node_names: list[str]
    output_dtype: str = "float32"


@dataclass
class GraphNodeMetadata:
    """Optional extended metadata attached to a graph node.

    Stored separately from :class:`GraphNode` (which is frozen) in
    :attr:`ExecutionDAG.node_metadata`.
    """
    blocked_execution: Optional[BlockedExecutionMetadata] = None
    fusion_hook: Optional[OperatorFusionHook] = None


@dataclass(frozen=True)
class GraphNode:
    """A node in the execution DAG.

    Attributes:
        name: Unique node identifier (typically parameter/layer name).
        weight_chunk_ids: Set of chunk IDs required by this node.
        compute_cost_ms: Estimated compute cost in milliseconds.
        output_bytes: Estimated output tensor bytes.
    """

    name: str
    weight_chunk_ids: set[str] = field(default_factory=set)
    compute_cost_ms: float = 0.0
    output_bytes: int = 0


@dataclass(frozen=True)
class GraphEdge:
    """A directed edge in the execution DAG."""

    src: str
    dst: str
    activation_bytes: int = 0


@dataclass
class ExecutionDAG:
    """Execution DAG with lightweight analysis helpers."""

    nodes: dict[str, GraphNode]
    edges: list[GraphEdge]
    node_metadata: dict[str, GraphNodeMetadata] = field(default_factory=dict)
    """Optional extended metadata keyed by node name."""

    def __post_init__(self) -> None:
        missing = {
            n for e in self.edges for n in (e.src, e.dst)
            if n not in self.nodes
        }
        if missing:
            raise ValueError(f"Edges reference unknown nodes: {sorted(missing)}")

        self._succ: dict[str, list[str]] = defaultdict(list)
        self._pred: dict[str, list[str]] = defaultdict(list)
        self._indegree: dict[str, int] = {name: 0 for name in self.nodes}

        for edge in self.edges:
            self._succ[edge.src].append(edge.dst)
            self._pred[edge.dst].append(edge.src)
            self._indegree[edge.dst] += 1

    @classmethod
    def from_execution_order(
        cls,
        execution_order: list[str],
        chunk_lookup: dict[str, list[ChunkAddress]],
    ) -> ExecutionDAG:
        """Build a linearized DAG from an execution order list.

        The initial Phase 1 representation is a chain over execution order.
        Future phases can replace or augment this with true model graph edges.
        """
        nodes: dict[str, GraphNode] = {}
        edges: list[GraphEdge] = []

        for idx, name in enumerate(execution_order):
            chunk_ids = {addr.chunk_id for addr in chunk_lookup.get(name, [])}
            nodes[name] = GraphNode(name=name, weight_chunk_ids=chunk_ids)
            if idx > 0:
                edges.append(GraphEdge(src=execution_order[idx - 1], dst=name))

        return cls(nodes=nodes, edges=edges)

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def edge_count(self) -> int:
        return len(self.edges)

    def successors(self, node: str) -> list[str]:
        return list(self._succ.get(node, []))

    def predecessors(self, node: str) -> list[str]:
        return list(self._pred.get(node, []))

    def topological_order(self) -> list[str]:
        """Return a topological ordering using Kahn's algorithm."""
        indegree = dict(self._indegree)
        queue = deque([name for name, deg in indegree.items() if deg == 0])
        order: list[str] = []

        while queue:
            node = queue.popleft()
            order.append(node)
            for nxt in self._succ.get(node, []):
                indegree[nxt] -= 1
                if indegree[nxt] == 0:
                    queue.append(nxt)

        if len(order) != len(self.nodes):
            raise ValueError("Execution graph contains a cycle")
        return order

    def critical_path_cost_ms(self) -> float:
        """Compute longest path cost using node compute_cost_ms weights."""
        order = self.topological_order()
        dist: dict[str, float] = {name: float("-inf") for name in self.nodes}

        for name in order:
            if self._indegree[name] == 0:
                dist[name] = self.nodes[name].compute_cost_ms

            for nxt in self._succ.get(name, []):
                cand = dist[name] + self.nodes[nxt].compute_cost_ms
                if cand > dist[nxt]:
                    dist[nxt] = cand

        return max(dist.values()) if dist else 0.0

    def partition_by_cache_budget(
        self,
        cache_budget_bytes: int,
        chunk_size_lookup: dict[str, int],
        order: list[str] | None = None,
    ) -> list[list[str]]:
        """Greedily partition nodes while respecting chunk-byte budget.

        The partition cost uses unique chunk IDs inside each partition.
        """
        if cache_budget_bytes <= 0:
            raise ValueError("cache_budget_bytes must be > 0")

        seq = order or self.topological_order()
        partitions: list[list[str]] = []
        current_nodes: list[str] = []
        current_chunks: set[str] = set()

        for node_name in seq:
            node = self.nodes[node_name]
            candidate_chunks = current_chunks | node.weight_chunk_ids
            candidate_bytes = sum(chunk_size_lookup.get(cid, 0) for cid in candidate_chunks)

            if not current_nodes:
                if candidate_bytes > cache_budget_bytes:
                    raise ValueError(
                        f"Node '{node_name}' exceeds cache budget ({candidate_bytes} > {cache_budget_bytes})"
                    )
                current_nodes = [node_name]
                current_chunks = set(candidate_chunks)
                continue

            if candidate_bytes <= cache_budget_bytes:
                current_nodes.append(node_name)
                current_chunks = candidate_chunks
            else:
                partitions.append(current_nodes)
                node_bytes = sum(chunk_size_lookup.get(cid, 0) for cid in node.weight_chunk_ids)
                if node_bytes > cache_budget_bytes:
                    raise ValueError(
                        f"Node '{node_name}' exceeds cache budget ({node_bytes} > {cache_budget_bytes})"
                    )
                current_nodes = [node_name]
                current_chunks = set(node.weight_chunk_ids)

        if current_nodes:
            partitions.append(current_nodes)
        return partitions


def fusion_opportunities(dag: ExecutionDAG) -> list[OperatorFusionHook]:
    """Identify sequential node chains that are candidates for operator fusion.

    A fusion opportunity exists for a pair of consecutive nodes where:
    - The first node has exactly one successor.
    - The second node has exactly one predecessor.
    - Neither node branches to other nodes.

    Args:
        dag: The execution DAG to analyse.

    Returns:
        List of :class:`OperatorFusionHook` instances, one per fuseable chain.
    """
    order = dag.topological_order()
    visited: set[str] = set()
    hooks: list[OperatorFusionHook] = []

    for node_name in order:
        if node_name in visited:
            continue

        succs = dag.successors(node_name)
        if len(succs) != 1:
            continue

        # Walk forward while the chain is linear (1 successor, 1 predecessor)
        chain = [node_name]
        current = node_name
        while True:
            nexts = dag.successors(current)
            if len(nexts) != 1:
                break
            nxt = nexts[0]
            if len(dag.predecessors(nxt)) != 1:
                break
            chain.append(nxt)
            visited.add(nxt)
            current = nxt

        if len(chain) >= 2:
            fused_name = "_".join(chain) + "_fused"
            hooks.append(OperatorFusionHook(
                fused_op_name=fused_name,
                input_node_names=chain,
            ))
            visited.update(chain)

    return hooks
