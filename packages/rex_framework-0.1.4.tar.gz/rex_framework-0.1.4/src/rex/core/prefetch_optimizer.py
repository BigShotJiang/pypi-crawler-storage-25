"""Prefetch planning helpers.

Implements the budgeted greedy prefetch selection described in the redesign
document. Candidates are ranked by probability-to-latency utility and packed
under a byte budget.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from rex.core.cost_model import prefetch_utility


@dataclass(frozen=True)
class PrefetchCandidate:
    chunk_id: str
    size_bytes: int
    probability: float
    estimated_latency_ms: float

    @property
    def utility(self) -> float:
        return prefetch_utility(self.probability, self.estimated_latency_ms)


# ---------------------------------------------------------------------------
# Target 7: Transformer / MoE runtime priors
# ---------------------------------------------------------------------------

@dataclass
class AttentionLocalityPrior:
    """Prior that boosts prefetch probability for attention heads near the current head.

    Attributes:
        head_count: Total number of attention heads in the model.
        locality_window: Number of neighboring heads considered local.
    """
    head_count: int
    locality_window: int = 4


@dataclass
class MoEExpertPrefetchHint:
    """Routing hint for Mixture-of-Experts top-k expert prefetching.

    Attributes:
        expert_chunk_ids: Chunk IDs for each expert.
        routing_probabilities: Per-expert routing probability.
        top_k: Number of top experts to boost.
    """
    expert_chunk_ids: list[str]
    routing_probabilities: list[float]
    top_k: int = 2


def apply_attention_prior(
    candidates: list[PrefetchCandidate],
    prior: AttentionLocalityPrior,
    current_head_index: int = 0,
) -> list[PrefetchCandidate]:
    """Boost prefetch probability for candidates within locality_window heads.

    Candidates whose index (within the candidate list) falls within
    ``prior.locality_window`` of ``current_head_index`` receive a
    proportional probability boost.

    Args:
        candidates: Original prefetch candidates.
        prior: Attention locality prior.
        current_head_index: The attention head currently being executed.

    Returns:
        New list of candidates with boosted probabilities where applicable.
    """
    result: list[PrefetchCandidate] = []
    for idx, cand in enumerate(candidates):
        distance = abs(idx % max(1, prior.head_count) - current_head_index)
        if distance <= prior.locality_window:
            boost = 1.0 - distance / max(1, prior.locality_window + 1)
            new_prob = min(1.0, cand.probability * (1.0 + boost))
            cand = PrefetchCandidate(
                chunk_id=cand.chunk_id,
                size_bytes=cand.size_bytes,
                probability=new_prob,
                estimated_latency_ms=cand.estimated_latency_ms,
            )
        result.append(cand)
    return result


def apply_moe_prior(
    candidates: list[PrefetchCandidate],
    hint: MoEExpertPrefetchHint,
) -> list[PrefetchCandidate]:
    """Boost probability for the top-k expert chunks from MoE routing.

    Args:
        candidates: Original prefetch candidates.
        hint: MoE routing hint with expert chunk IDs and probabilities.

    Returns:
        New list of candidates with top-k expert chunks boosted.
    """
    if not hint.expert_chunk_ids or not hint.routing_probabilities:
        return list(candidates)

    # Identify top-k expert chunk IDs by routing probability
    paired = list(zip(hint.routing_probabilities, hint.expert_chunk_ids))
    paired.sort(key=lambda x: -x[0])
    top_k_ids = {cid for _, cid in paired[: hint.top_k]}

    result: list[PrefetchCandidate] = []
    for cand in candidates:
        if cand.chunk_id in top_k_ids:
            # Find the routing probability for this expert
            expert_prob = next(
                (p for p, cid in paired if cid == cand.chunk_id), 0.0
            )
            new_prob = min(1.0, cand.probability + expert_prob)
            cand = PrefetchCandidate(
                chunk_id=cand.chunk_id,
                size_bytes=cand.size_bytes,
                probability=new_prob,
                estimated_latency_ms=cand.estimated_latency_ms,
            )
        result.append(cand)
    return result


# ---------------------------------------------------------------------------
# Target 4: Horizon tuning + queue-state admission control
# ---------------------------------------------------------------------------

def plan_prefetch(
    candidates: list[PrefetchCandidate],
    budget_bytes: int,
    horizon: int = 1,
    decay_factor: float = 0.1,
    max_queue_depth: int = 0,
    queue_depth: int = 0,
) -> list[PrefetchCandidate]:
    """Select a high-utility subset of candidates under a byte budget.

    Args:
        candidates: Ranked prefetch candidates.
        budget_bytes: Maximum total bytes to prefetch.
        horizon: Look-ahead horizon; decays probability for distant items.
        decay_factor: Per-step probability decay applied across the horizon.
        max_queue_depth: If > 0 and queue_depth >= max_queue_depth, skip
            low-priority candidates (probability < 0.5).
        queue_depth: Current number of items already in the prefetch queue.

    Returns:
        Filtered and ordered list of candidates to prefetch.
    """
    if budget_bytes <= 0:
        return []

    horizon = max(1, horizon)

    # Apply horizon-based probability decay
    adjusted: list[PrefetchCandidate] = []
    for cand in candidates:
        if horizon > 1:
            decay = max(0.0, 1.0 - (horizon - 1) * decay_factor)
            new_prob = min(1.0, max(0.0, cand.probability * decay))
        else:
            new_prob = cand.probability

        # Queue-state admission: drop low-priority items when queue is full
        if max_queue_depth > 0 and queue_depth >= max_queue_depth and new_prob < 0.5:
            continue

        adjusted.append(
            PrefetchCandidate(
                chunk_id=cand.chunk_id,
                size_bytes=cand.size_bytes,
                probability=new_prob,
                estimated_latency_ms=cand.estimated_latency_ms,
            )
        )

    indexed_candidates = list(enumerate(adjusted))
    selected: list[tuple[int, PrefetchCandidate]] = []
    used = 0
    for index, candidate in sorted(
        indexed_candidates,
        key=lambda item: (-item[1].utility, item[1].size_bytes, item[1].chunk_id),
    ):
        if candidate.size_bytes <= 0:
            continue
        if used + candidate.size_bytes > budget_bytes:
            continue
        selected.append((index, candidate))
        used += candidate.size_bytes
    selected.sort(key=lambda item: item[0])
    return [candidate for _, candidate in selected]