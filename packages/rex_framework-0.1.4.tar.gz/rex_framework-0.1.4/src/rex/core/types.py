"""
Core type definitions for the Rex framework.

Status: Implemented
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Optional


class TensorState(enum.Enum):
    """State of a VirtualTensor in the local system."""
    REMOTE = "remote"
    """Data is not present locally; must be fetched from remote storage."""

    CACHED = "cached"
    """Compressed or serialized data is present in local cache storage."""

    RESIDENT = "resident"
    """Data is decompressed and available in CPU RAM or GPU VRAM."""


class CompressionCodec(enum.Enum):
    """Supported compression codecs for chunk storage."""
    NONE = "none"
    LZ4 = "lz4"
    ZSTD = "zstd"


class StorageBackendType(enum.Enum):
    """Supported remote storage backends."""
    HTTP_RANGE = "http_range"
    LOCAL_SERVER = "local_server"
    GOOGLE_DRIVE = "google_drive"
    ONEDRIVE = "onedrive"
    ICLOUD = "icloud"


class BackendStatus(enum.Enum):
    """Support status for a storage backend."""
    SUPPORTED = "supported"
    EXPERIMENTAL = "experimental"
    PARTIALLY_SUPPORTED = "partially_supported"
    UNSUPPORTED = "unsupported"


class CachePolicyName(enum.Enum):
    """Named cache eviction policies."""
    LRU = "lru"
    LFU = "lfu"
    WEIGHTED_UTILITY = "weighted_utility"
    PROBABILISTIC_UTILITY = "probabilistic_utility"


class ChunkPriority(enum.Enum):
    """Priority levels for prefetch scheduling."""
    HIGH = "high"
    """Chunk needed for the current or immediately next layer."""

    LOW = "low"
    """Chunk needed for a future layer within the look-ahead window."""

    BACKGROUND = "background"
    """Chunk may be useful; speculative prefetch."""


@dataclass(frozen=True)
class ByteRange:
    """A half-open byte range [start, end) in a remote file."""
    start: int
    end: int

    @property
    def size(self) -> int:
        return self.end - self.start

    def __post_init__(self) -> None:
        assert self.start >= 0, f"ByteRange start must be >= 0, got {self.start}"
        assert self.end > self.start, f"ByteRange end must be > start, got [{self.start}, {self.end})"

    def to_http_header(self) -> str:
        return f"bytes={self.start}-{self.end - 1}"


@dataclass(frozen=True)
class ChunkAddress:
    """Unique address of a single chunk in remote storage."""
    resource_id: str
    """Identifier for the remote resource (file ID, URL, etc.)."""

    byte_range: ByteRange
    """Byte range within the remote resource."""

    chunk_id: str
    """Logical chunk identifier (e.g. 'layer_00.q_proj.3')."""

    @property
    def size_bytes(self) -> int:
        return self.byte_range.size


@dataclass
class ChunkMetadata:
    """Metadata for a single weight chunk."""
    chunk_id: str
    resource_id: str
    byte_range: ByteRange
    checksum_sha256: str
    compression: CompressionCodec = CompressionCodec.NONE
    uncompressed_size: int = 0
    """Size of the chunk data after decompression (bytes)."""

    compressed_size: int = 0
    """Size of the chunk data as stored remotely (bytes)."""


@dataclass
class TensorDescriptor:
    """Metadata describing a single model parameter tensor."""
    name: str
    shape: tuple[int, ...]
    dtype: str
    num_chunks: int
    chunk_addresses: list[ChunkAddress] = field(default_factory=list)
    total_bytes: int = 0
    quantization: Optional[dict[str, Any]] = None


@dataclass
class RexManifest:
    """Top-level manifest for a Rex model.

    This is the source of truth for model metadata and chunk layout.
    It is a small file (typically < 1 MB for large models) that must be
    fetched first before any inference can proceed.
    """
    manifest_version: str
    model_id: str
    model_family: str
    source_framework: str
    parameters: dict[str, TensorDescriptor] = field(default_factory=dict)
    total_model_bytes: int = 0
    total_chunks: int = 0
    default_chunk_size: int = 524288  # 512 KB
    storage_backend: StorageBackendType = StorageBackendType.HTTP_RANGE
    compression: CompressionCodec = CompressionCodec.NONE
    provenance: dict[str, Any] = field(default_factory=dict)
    cache_constraints: CacheConstraints = field(default_factory=lambda: CacheConstraints())
    execution_graph: list[str] = field(default_factory=list)
    """Ordered list of parameter names in execution order."""

    backend_requirements: dict[str, Any] = field(default_factory=dict)
    feature_flags: dict[str, bool] = field(default_factory=lambda: {
        "compressed_chunks": False,
        "quantized_chunks": False,
        "adaptive_chunk_sizes": False,
        "disk_cache": False,
    })


@dataclass
class CacheConstraints:
    """Constraints on local caching behavior."""
    max_local_fraction_of_model: float = 0.4
    """Maximum fraction of total model bytes that may reside locally at any time."""

    max_memory_cache_bytes: int = 0
    """Maximum bytes for in-memory cache. 0 means auto (40% of model size)."""

    max_disk_cache_bytes: int = 0
    """Maximum bytes for disk cache. 0 means disabled."""

    enforce_invariant: bool = True
    """Whether to actively enforce the 'no full model local' invariant."""


@dataclass
class FetchResult:
    """Result of a single chunk fetch operation."""
    chunk_id: str
    success: bool
    data: Optional[bytes] = None
    duration_ms: float = 0.0
    error: Optional[str] = None
    from_cache: bool = False
    bytes_transferred: int = 0


@dataclass
class InferenceMetrics:
    """Metrics recorded during a single inference call."""
    total_time_ms: float = 0.0
    compute_time_ms: float = 0.0
    stall_time_ms: float = 0.0
    chunks_fetched: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    bytes_fetched_remote: int = 0
    bytes_served_from_cache: int = 0
    prefetch_actions: int = 0
    eviction_count: int = 0
    layers_executed: int = 0
    peak_memory_cache_bytes: int = 0
    invariant_violations: int = 0


@dataclass
class BenchmarkConfig:
    """Configuration for a benchmark run."""
    model_id: str
    storage_uri: str
    chunk_size: int = 524288
    cache_size_mb: int = 256
    cache_policy: CachePolicyName = CachePolicyName.LRU
    prefetch_window: int = 4
    fetch_concurrency: int = 4
    simulated_latency_ms: float = 0.0
    simulated_bandwidth_mbps: float = 0.0
    num_inferences: int = 5
    warmup_inferences: int = 1
    input_sequence_length: int = 32
