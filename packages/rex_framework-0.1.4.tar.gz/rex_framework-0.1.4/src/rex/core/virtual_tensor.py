"""
VirtualTensor abstraction for the Rex framework.

A VirtualTensor represents a model parameter tensor that may not be
materialized in local memory. It tracks the tensor's state (REMOTE,
CACHED, or RESIDENT) and provides methods for materialization,
partial materialization, and eviction with proper state transition
validation and checksum integrity checks.
"""

from __future__ import annotations

import hashlib
import time
from typing import Any, Callable, Optional, Union

import structlog

from rex.core.errors import (
    ChunkIntegrityError,
    InvalidStateTransitionError,
    MaterializationError,
)
from rex.core.types import (
    ByteRange,
    ChunkAddress,
    TensorState,
)

logger = structlog.get_logger(__name__)

# Type alias for tracing hooks
TracingHook = Callable[[str, dict[str, Any]], None]


class VirtualTensor:
    """A tensor with deferred materialization.

    VirtualTensors are the core abstraction for model parameters in
    Rex. They track the tensor's shape and dtype (always known) and
    manage state transitions between REMOTE, CACHED, and RESIDENT.

    State machine:
        REMOTE → CACHED → RESIDENT
        RESIDENT → CACHED → REMOTE

    Illegal transitions raise InvalidStateTransitionError.

    Args:
        name: Name of the tensor (e.g., 'layer_0.q_proj.weight').
        shape: Shape tuple (e.g., (768, 768)).
        dtype: Data type string (e.g., 'float32').
        chunk_addresses: List of ChunkAddress for each chunk of this tensor.
        checksums: Optional dict mapping chunk_id -> SHA-256 hex digest.
    """

    # Valid state transitions
    _VALID_TRANSITIONS: dict[TensorState, set[TensorState]] = {
        TensorState.REMOTE: {TensorState.CACHED},
        TensorState.CACHED: {TensorState.REMOTE, TensorState.RESIDENT},
        TensorState.RESIDENT: {TensorState.CACHED},
    }

    def __init__(
        self,
        name: str,
        shape: tuple[int, ...],
        dtype: str,
        chunk_addresses: list[ChunkAddress],
        quantization: Optional[dict[str, Any]] = None,
        checksums: Optional[dict[str, str]] = None,
    ) -> None:
        self.name = name
        self.shape = shape
        self.dtype = dtype
        self.chunk_addresses = chunk_addresses
        self.quantization = quantization
        self.checksums = checksums or {}
        self._state = TensorState.REMOTE

        # Cached chunk data: chunk_id -> bytes
        self._chunk_data: dict[str, bytes] = {}

        # Tracing hooks
        self._on_fetch_start: Optional[TracingHook] = None
        self._on_fetch_end: Optional[TracingHook] = None
        self._on_evict: Optional[TracingHook] = None

        self._log = logger.bind(tensor_name=name)

    @property
    def state(self) -> TensorState:
        """Current state of the virtual tensor."""
        return self._state

    @property
    def num_chunks(self) -> int:
        """Number of chunks in this tensor."""
        return len(self.chunk_addresses)

    @property
    def total_bytes(self) -> int:
        """Total bytes of the uncompressed tensor."""
        import numpy as np
        dtype_size = np.dtype(_dtype_to_numpy(self.dtype)).itemsize
        elements = 1
        for dim in self.shape:
            elements *= dim
        return elements * dtype_size

    @property
    def is_remote(self) -> bool:
        return self._state == TensorState.REMOTE

    @property
    def is_cached(self) -> bool:
        return self._state == TensorState.CACHED

    @property
    def is_resident(self) -> bool:
        return self._state == TensorState.RESIDENT

    def set_tracing_hooks(
        self,
        on_fetch_start: Optional[TracingHook] = None,
        on_fetch_end: Optional[TracingHook] = None,
        on_evict: Optional[TracingHook] = None,
    ) -> None:
        """Set tracing callbacks for lifecycle events.

        Each hook receives (event_name: str, context: dict).

        Args:
            on_fetch_start: Called before fetching chunk data.
            on_fetch_end: Called after fetching chunk data.
            on_evict: Called when the tensor is evicted.
        """
        self._on_fetch_start = on_fetch_start
        self._on_fetch_end = on_fetch_end
        self._on_evict = on_evict

    def _transition_to(self, target: TensorState) -> None:
        """Validate and execute a state transition.

        Args:
            target: Target state.

        Raises:
            InvalidStateTransitionError: If the transition is illegal.
        """
        valid_targets = self._VALID_TRANSITIONS.get(self._state, set())
        if target not in valid_targets:
            raise InvalidStateTransitionError(
                chunk_id=self.name,
                current=self._state.value,
                target=target.value,
            )

        old_state = self._state
        self._state = target
        self._log.debug(
            "state_transition",
            old_state=old_state.value,
            new_state=target.value,
        )

    def store_chunk_data(self, chunk_id: str, data: bytes) -> None:
        """Store raw chunk data (used by the fetch pipeline).

        Args:
            chunk_id: Chunk identifier.
            data: Raw chunk bytes.
        """
        self._chunk_data[chunk_id] = data

    def verify_chunk_checksum(self, chunk_id: str, data: bytes) -> bool:
        """Verify the SHA-256 checksum of chunk data.

        Args:
            chunk_id: Chunk identifier.
            data: Raw chunk data to verify.

        Returns:
            True if checksum matches or no checksum is recorded.

        Raises:
            ChunkIntegrityError: If the checksum does not match.
        """
        expected = self.checksums.get(chunk_id)
        if not expected:
            self._log.debug(
                "no_checksum_for_chunk",
                chunk_id=chunk_id,
            )
            return True

        actual = hashlib.sha256(data).hexdigest()
        if actual != expected:
            raise ChunkIntegrityError(
                chunk_id=chunk_id,
                expected=expected,
                actual=actual,
            )

        self._log.debug("checksum_verified", chunk_id=chunk_id)
        return True

    def materialize(
        self,
        fetch_func: Optional[Callable[[ChunkAddress], bytes]] = None,
    ) -> Any:
        """Materialize the full tensor into a numpy array or torch tensor.

        Fetches all chunks if not already resident, assembles them,
        verifies checksums, and returns the full tensor.

        Args:
            fetch_func: Callable that fetches a ChunkAddress and returns
                raw bytes. Required if the tensor is not already cached.

        Returns:
            A numpy ndarray (default) or torch tensor.

        Raises:
            MaterializationError: If materialization fails.
            ChunkIntegrityError: If a checksum verification fails.
        """
        if self._state == TensorState.RESIDENT:
            self._log.debug("already_resident", name=self.name)
            return self._assemble_tensor()

        # Fetch all chunks
        self._fire_hook("on_fetch_start", {
            "tensor_name": self.name,
            "num_chunks": self.num_chunks,
            "current_state": self._state.value,
        })

        start_time = time.monotonic()
        for addr in self.chunk_addresses:
            if addr.chunk_id not in self._chunk_data:
                if fetch_func is None:
                    raise MaterializationError(
                        f"No fetch function provided and chunk "
                        f"'{addr.chunk_id}' is not cached for tensor "
                        f"'{self.name}'"
                    )
                try:
                    data = fetch_func(addr)
                    self._chunk_data[addr.chunk_id] = data
                except Exception as exc:
                    raise MaterializationError(
                        f"Failed to fetch chunk '{addr.chunk_id}' "
                        f"for tensor '{self.name}': {exc}"
                    ) from exc

            # Verify checksum
            self.verify_chunk_checksum(
                addr.chunk_id, self._chunk_data[addr.chunk_id]
            )

        # Transition states
        if self._state == TensorState.REMOTE:
            self._transition_to(TensorState.CACHED)
        if self._state == TensorState.CACHED:
            self._transition_to(TensorState.RESIDENT)

        duration_ms = (time.monotonic() - start_time) * 1000

        self._fire_hook("on_fetch_end", {
            "tensor_name": self.name,
            "num_chunks": self.num_chunks,
            "duration_ms": duration_ms,
            "new_state": self._state.value,
        })

        return self._assemble_tensor()

    def partial_materialize(
        self,
        start_idx: int,
        end_idx: int,
        fetch_func: Optional[Callable[[ChunkAddress], bytes]] = None,
    ) -> Any:
        """Materialize a range of chunks and return the partial tensor.

        Args:
            start_idx: Starting chunk index (inclusive).
            end_idx: Ending chunk index (exclusive).
            fetch_func: Callable to fetch a ChunkAddress -> bytes.

        Returns:
            Numpy array or torch tensor for the requested chunk range.

        Raises:
            MaterializationError: If fetch fails.
            ValueError: If indices are out of range.
        """
        if start_idx < 0 or end_idx > self.num_chunks or start_idx >= end_idx:
            raise ValueError(
                f"Invalid chunk range [{start_idx}, {end_idx}) for "
                f"tensor with {self.num_chunks} chunks"
            )

        self._fire_hook("on_fetch_start", {
            "tensor_name": self.name,
            "chunk_range": [start_idx, end_idx],
            "current_state": self._state.value,
        })

        start_time = time.monotonic()
        addrs = self.chunk_addresses[start_idx:end_idx]

        for addr in addrs:
            if addr.chunk_id not in self._chunk_data:
                if fetch_func is None:
                    raise MaterializationError(
                        f"No fetch function and chunk '{addr.chunk_id}' "
                        f"not cached"
                    )
                data = fetch_func(addr)
                self._chunk_data[addr.chunk_id] = data

            self.verify_chunk_checksum(
                addr.chunk_id, self._chunk_data[addr.chunk_id]
            )

        # Update state to at least CACHED if we now have any data
        if self._state == TensorState.REMOTE:
            self._transition_to(TensorState.CACHED)

        duration_ms = (time.monotonic() - start_time)
        self._fire_hook("on_fetch_end", {
            "tensor_name": self.name,
            "chunk_range": [start_idx, end_idx],
            "duration_ms": duration_ms * 1000,
        })

        return self._assemble_partial_tensor(start_idx, end_idx)

    def evict(self) -> None:
        """Evict the tensor to REMOTE state, releasing all local data.

        Transitions through CACHED if necessary (RESIDENT → CACHED → REMOTE).

        Raises:
            InvalidStateTransitionError: If already REMOTE.
        """
        if self._state == TensorState.REMOTE:
            raise InvalidStateTransitionError(
                chunk_id=self.name,
                current=TensorState.REMOTE.value,
                target=TensorState.REMOTE.value,
            )

        self._fire_hook("on_evict", {
            "tensor_name": self.name,
            "old_state": self._state.value,
        })

        if self._state == TensorState.RESIDENT:
            self._transition_to(TensorState.CACHED)
        if self._state == TensorState.CACHED:
            self._transition_to(TensorState.REMOTE)

        self._chunk_data.clear()
        self._log.debug("tensor_evicted", name=self.name)

    def demote(self) -> None:
        """Demote from RESIDENT to CACHED (release memory but keep cache copy).

        Raises:
            InvalidStateTransitionError: If not RESIDENT.
        """
        if self._state != TensorState.RESIDENT:
            raise InvalidStateTransitionError(
                chunk_id=self.name,
                current=self._state.value,
                target=TensorState.CACHED.value,
            )
        self._transition_to(TensorState.CACHED)

    def _fire_hook(self, hook_name: str, context: dict[str, Any]) -> None:
        """Invoke a tracing hook if set."""
        hook = getattr(self, f"_{hook_name}", None)
        if hook is not None:
            try:
                hook(hook_name, context)
            except Exception:
                self._log.warning(
                    "tracing_hook_error",
                    hook_name=hook_name,
                    exc_info=True,
                )

    def _assemble_tensor(self) -> Any:
        """Assemble full tensor from chunk data."""
        from rex.convert.quantize import dequantize_tensor_from_bytes

        chunks = []
        for addr in self.chunk_addresses:
            data = self._chunk_data.get(addr.chunk_id)
            if data is None:
                raise MaterializationError(
                    f"Chunk '{addr.chunk_id}' data missing during assembly"
                )
            chunks.append(data)

        if self.quantization is not None:
            return dequantize_tensor_from_bytes(
                b"".join(chunks),
                self.quantization,
                self.shape,
            )

        return _chunks_to_tensor(chunks, self.shape, self.dtype)

    def _assemble_partial_tensor(
        self, start_idx: int, end_idx: int
    ) -> Any:
        """Assemble a partial tensor from a range of chunks."""
        import numpy as np
        from rex.convert.quantize import dequantize_tensor_from_bytes

        chunks = []
        for addr in self.chunk_addresses[start_idx:end_idx]:
            data = self._chunk_data.get(addr.chunk_id)
            if data is None:
                raise MaterializationError(
                    f"Chunk '{addr.chunk_id}' data missing during "
                    f"partial assembly"
                )
            chunks.append(data)

        if self.quantization is not None:
            # Partial assembly for packed quantized tensors is only exact when
            # the full tensor payload is available, so reconstruct then slice.
            full = dequantize_tensor_from_bytes(
                b"".join(
                    self._chunk_data[addr.chunk_id]
                    for addr in self.chunk_addresses
                    if addr.chunk_id in self._chunk_data
                ),
                self.quantization,
                self.shape,
            )
            return full.reshape(-1)

        dtype_np = _dtype_to_numpy(self.dtype)
        flat = np.concatenate([
            np.frombuffer(c, dtype=dtype_np) for c in chunks
        ])
        return flat

    def __repr__(self) -> str:
        return (
            f"VirtualTensor(name={self.name!r}, shape={self.shape}, "
            f"dtype={self.dtype!r}, state={self._state.value}, "
            f"chunks={self.num_chunks})"
        )


def _dtype_to_numpy(dtype: str) -> Any:
    """Convert a dtype string to a numpy dtype.

    Args:
        dtype: String like 'float32', 'float16', 'int32', etc.

    Returns:
        numpy dtype object.
    """
    import numpy as np

    dtype_map = {
        "float32": np.float32,
        "float64": np.float64,
        "float16": np.float16,
        "bfloat16": np.float32,  # fallback: numpy doesn't natively support bf16
        "int32": np.int32,
        "int64": np.int64,
        "int16": np.int16,
        "int8": np.int8,
        "uint8": np.uint8,
        "bool": np.bool_,
    }
    return dtype_map.get(dtype, np.float32)


def _chunks_to_tensor(
    chunks: list[bytes],
    shape: tuple[int, ...],
    dtype: str,
) -> Any:
    """Concatenate raw chunk bytes into a numpy array with given shape."""
    import numpy as np

    dtype_np = _dtype_to_numpy(dtype)
    flat = np.concatenate([np.frombuffer(c, dtype=dtype_np) for c in chunks])
    return flat.reshape(shape)


if __name__ == "__main__":
    from rex.core.types import ByteRange

    # === Create a virtual tensor ===
    print("=== VirtualTensor Tests ===\n")

    # Simulate tensor data: 2x2 float32 matrix = 16 bytes, split into 2 chunks
    import numpy as np
    original = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float32)
    original_bytes = original.tobytes()

    chunk_a = original_bytes[:8]   # first row
    chunk_b = original_bytes[8:]   # second row

    checksum_a = hashlib.sha256(chunk_a).hexdigest()
    checksum_b = hashlib.sha256(chunk_b).hexdigest()

    vt = VirtualTensor(
        name="test.weight",
        shape=(2, 2),
        dtype="float32",
        chunk_addresses=[
            ChunkAddress(
                chunk_id="test.weight.0",
                resource_id="test.bin",
                byte_range=ByteRange(start=0, end=8),
            ),
            ChunkAddress(
                chunk_id="test.weight.1",
                resource_id="test.bin",
                byte_range=ByteRange(start=8, end=16),
            ),
        ],
        checksums={
            "test.weight.0": checksum_a,
            "test.weight.1": checksum_b,
        },
    )

    assert vt.is_remote
    assert vt.state == TensorState.REMOTE
    print(f"Initial: {vt}")

    # Set tracing hooks
    trace_log: list[str] = []
    vt.set_tracing_hooks(
        on_fetch_start=lambda name, ctx: trace_log.append(f"fetch_start:{name}"),
        on_fetch_end=lambda name, ctx: trace_log.append(f"fetch_end:{name}"),
        on_evict=lambda name, ctx: trace_log.append(f"evict:{name}"),
    )

    # Materialize with fetch function
    def fetch_mock(addr: ChunkAddress) -> bytes:
        if addr.chunk_id == "test.weight.0":
            return chunk_a
        elif addr.chunk_id == "test.weight.1":
            return chunk_b
        raise RuntimeError(f"Unknown chunk: {addr.chunk_id}")

    result = vt.materialize(fetch_func=fetch_mock)
    assert vt.is_resident
    assert np.array_equal(result, original)
    print(f"Materialized: {result}")

    # Demote to cached
    vt.demote()
    assert vt.is_cached
    print(f"Demoted to cached")

    # Evict to remote
    vt.evict()
    assert vt.is_remote
    print(f"Evicted to remote")

    # Test invalid transitions
    try:
        vt.evict()  # already REMOTE
        print("ERROR: should have raised")
    except InvalidStateTransitionError as e:
        print(f"Caught expected error: {e}")

    # Test checksum failure
    vt2 = VirtualTensor(
        name="bad.weight",
        shape=(2, 2),
        dtype="float32",
        chunk_addresses=[
            ChunkAddress(
                chunk_id="bad.weight.0",
                resource_id="test.bin",
                byte_range=ByteRange(start=0, end=8),
            ),
        ],
        checksums={"bad.weight.0": "bad_checksum_0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"},
    )
    try:
        vt2.materialize(fetch_func=lambda a: b"corrupted!")
        print("ERROR: should have raised")
    except ChunkIntegrityError as e:
        print(f"Caught checksum error: {e}")

    # Test partial materialize
    vt3 = VirtualTensor(
        name="partial.weight",
        shape=(2, 2),
        dtype="float32",
        chunk_addresses=[
            ChunkAddress(chunk_id="p.0", resource_id="t.bin", byte_range=ByteRange(start=0, end=8)),
            ChunkAddress(chunk_id="p.1", resource_id="t.bin", byte_range=ByteRange(start=8, end=16)),
        ],
    )
    partial = vt3.partial_materialize(0, 1, fetch_func=lambda a: chunk_a)
    print(f"Partial materialized shape: {partial.shape}")

    # Check tracing hooks fired
    print(f"Trace events: {trace_log}")
    assert len(trace_log) >= 2  # at least fetch_start and fetch_end

    print("\n=== All tests passed! ===")
