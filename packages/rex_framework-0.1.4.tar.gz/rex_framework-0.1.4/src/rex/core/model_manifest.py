"""
Manifest loading, parsing, validation, and serialization for the Rex framework.

The manifest is the source of truth for model metadata and chunk layout.
It must be fetched first before any inference can proceed.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
from typing import Any, Optional, Union
from urllib.parse import urlparse

import structlog

from rex.core.errors import ManifestError, ManifestValidationError, ManifestVersionError
from rex.core.types import (
    ByteRange,
    CacheConstraints,
    ChunkAddress,
    CompressionCodec,
    RexManifest,
    StorageBackendType,
    TensorDescriptor,
)

logger = structlog.get_logger(__name__)

# Supported manifest versions
SUPPORTED_VERSIONS = {"0.1.0", "1.0.0", "1.1.0"}
DEFAULT_MANIFEST_VERSION = "1.0.0"

# SHA-256 hex digest length (lowercase)
SHA256_HEX_LEN = 64

# Regex for validating SHA-256 hex strings
SHA256_PATTERN = re.compile(r'^[0-9a-f]{64}$')


def _canonical_json_bytes(data: dict[str, Any]) -> bytes:
    """Serialize a dict to canonical (sorted keys, no whitespace) JSON bytes."""
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")


def serialize_manifest(manifest: RexManifest) -> bytes:
    """Serialize a RexManifest to JSON bytes.

    Args:
        manifest: The manifest to serialize.

    Returns:
        UTF-8 encoded JSON bytes.
    """
    data = _manifest_to_dict(manifest)
    return json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8")


def deserialize_manifest(data: bytes) -> RexManifest:
    """Deserialize JSON bytes into a RexManifest.

    Args:
        data: UTF-8 encoded JSON bytes.

    Returns:
        A populated RexManifest instance.

    Raises:
        ManifestError: If the data cannot be parsed as valid JSON.
        ManifestValidationError: If required fields are missing.
    """
    try:
        raw = json.loads(data.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ManifestError(f"Failed to parse manifest JSON: {exc}") from exc

    if not isinstance(raw, dict):
        raise ManifestValidationError("Manifest root must be a JSON object")

    return _dict_to_manifest(raw)


def validate_manifest(manifest: RexManifest) -> list[str]:
    """Validate a RexManifest and return a list of validation errors.

    Performs comprehensive validation including:
        - Required fields present
        - Version compatibility
        - Chunk address integrity
        - Checksum format
        - Execution graph consistency
        - Byte range validity
        - Tensor descriptor consistency

    Args:
        manifest: The manifest to validate.

    Returns:
        List of error strings. Empty list means the manifest is valid.
    """
    errors: list[str] = []

    # --- Version ---
    if not manifest.manifest_version:
        errors.append("manifest_version is required")
    elif manifest.manifest_version not in SUPPORTED_VERSIONS:
        errors.append(
            f"Unsupported manifest version '{manifest.manifest_version}'. "
            f"Supported: {sorted(SUPPORTED_VERSIONS)}"
        )

    # --- Model identity ---
    if not manifest.model_id:
        errors.append("model_id is required")
    if not manifest.model_family:
        errors.append("model_family is required")

    # --- Parameters ---
    if manifest.total_model_bytes <= 0:
        errors.append(
            f"total_model_bytes must be positive, got {manifest.total_model_bytes}"
        )

    if manifest.total_chunks <= 0:
        errors.append(
            f"total_chunks must be positive, got {manifest.total_chunks}"
        )

    # Validate each parameter descriptor
    actual_total_chunks = 0
    actual_total_bytes = 0
    for name, td in manifest.parameters.items():
        param_errors = _validate_tensor_descriptor(name, td)
        errors.extend(param_errors)
        actual_total_chunks += td.num_chunks
        actual_total_bytes += td.total_bytes

        # Validate chunk addresses
        for addr in td.chunk_addresses:
            addr_errors = _validate_chunk_address(name, addr)
            errors.extend(addr_errors)

    # Check chunk count consistency
    if manifest.total_chunks > 0 and actual_total_chunks != manifest.total_chunks:
        errors.append(
            f"total_chunks ({manifest.total_chunks}) does not match "
            f"sum of parameter chunks ({actual_total_chunks})"
        )

    # --- Execution graph ---
    if manifest.execution_graph:
        for layer_name in manifest.execution_graph:
            if layer_name not in manifest.parameters:
                errors.append(
                    f"execution_graph references unknown parameter '{layer_name}'"
                )

        # Check that all parameters used in execution_graph are accounted for
        graph_params = set(manifest.execution_graph)
        all_params = set(manifest.parameters.keys())
        if graph_params - all_params:
            errors.append(
                f"execution_graph has parameters not in manifest: "
                f"{graph_params - all_params}"
            )

    # --- Cache constraints ---
    cc = manifest.cache_constraints
    if not (0.0 < cc.max_local_fraction_of_model <= 1.0):
        errors.append(
            f"cache_constraints.max_local_fraction_of_model must be in (0, 1], "
            f"got {cc.max_local_fraction_of_model}"
        )

    # --- Feature flags ---
    if not isinstance(manifest.feature_flags, dict):
        errors.append("feature_flags must be a dict")

    return errors


def get_manifest_size_bytes(manifest: RexManifest) -> int:
    """Compute the serialized size of a manifest in bytes.

    Args:
        manifest: The manifest to measure.

    Returns:
        Size in bytes of the JSON serialization.
    """
    return len(serialize_manifest(manifest))


def pretty_print(manifest: RexManifest) -> str:
    """Produce a human-readable summary of the manifest.

    Args:
        manifest: The manifest to describe.

    Returns:
        Multi-line string summary.
    """
    lines: list[str] = []
    lines.append("╔══════════════════════════════════════════════╗")
    lines.append("║           Rex Model Manifest               ║")
    lines.append("╚══════════════════════════════════════════════╝")
    lines.append(f"  Model ID:            {manifest.model_id}")
    lines.append(f"  Model Family:        {manifest.model_family}")
    lines.append(f"  Version:             {manifest.manifest_version}")
    lines.append(f"  Source Framework:    {manifest.source_framework}")
    lines.append(f"  Storage Backend:     {manifest.storage_backend.value}")
    lines.append(f"  Compression:         {manifest.compression.value}")
    lines.append(f"  Total Model Bytes:   {manifest.total_model_bytes:,}")
    lines.append(f"  Total Chunks:        {manifest.total_chunks}")
    lines.append(f"  Default Chunk Size:  {manifest.default_chunk_size:,}")
    lines.append(f"  Parameters:          {len(manifest.parameters)}")
    lines.append(f"  Execution Graph:     {len(manifest.execution_graph)} layers")

    cc = manifest.cache_constraints
    lines.append(f"  Max Local Fraction:  {cc.max_local_fraction_of_model:.0%}")
    if cc.max_memory_cache_bytes > 0:
        lines.append(
            f"  Max Memory Cache:     {cc.max_memory_cache_bytes:,} bytes"
        )

    # Per-parameter info
    if manifest.parameters:
        lines.append("")
        lines.append("  Parameters:")
        for name, td in sorted(manifest.parameters.items()):
            shape_str = "×".join(str(d) for d in td.shape)
            lines.append(
                f"    • {name}: shape=[{shape_str}], dtype={td.dtype}, "
                f"chunks={td.num_chunks}, bytes={td.total_bytes:,}"
            )

    if manifest.feature_flags:
        lines.append("")
        lines.append("  Feature Flags:")
        for flag, enabled in manifest.feature_flags.items():
            status = "✓" if enabled else "✗"
            lines.append(f"    {status} {flag}")

    return "\n".join(lines)


async def load_manifest(path_or_url: str) -> RexManifest:
    """Load a manifest from a local file path or remote URL.

    For local paths, reads the file directly.
    For HTTP(S) URLs, uses aiohttp to fetch the content.

    Args:
        path_or_url: File path or HTTP(S) URL to the manifest JSON.

    Returns:
        A validated RexManifest.

    Raises:
        ManifestError: If loading or parsing fails.
        FileNotFoundError: If a local path does not exist.
    """
    parsed = urlparse(path_or_url)

    if parsed.scheme in ("http", "https"):
        return await _load_manifest_from_url(path_or_url)
    else:
        return _load_manifest_from_file(path_or_url)


def _load_manifest_from_file(path: str) -> RexManifest:
    """Load manifest from a local file path."""
    log = logger.bind(path=path)
    log.info("loading_manifest_from_file")

    if not os.path.isfile(path):
        raise FileNotFoundError(f"Manifest file not found: {path}")

    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError as exc:
        raise ManifestError(f"Failed to read manifest file: {exc}") from exc

    manifest = deserialize_manifest(data)

    # Validate
    errors = validate_manifest(manifest)
    if errors:
        error_str = "; ".join(errors)
        raise ManifestValidationError(
            f"Manifest validation failed: {error_str}"
        )

    log.info(
        "manifest_loaded",
        model_id=manifest.model_id,
        total_chunks=manifest.total_chunks,
        total_bytes=manifest.total_model_bytes,
    )
    return manifest


async def _load_manifest_from_url(url: str) -> RexManifest:
    """Load manifest from an HTTP(S) URL."""
    log = logger.bind(url=url)
    log.info("loading_manifest_from_url")

    try:
        import aiohttp
    except ImportError:
        raise ManifestError(
            "aiohttp is required for loading manifests from URLs. "
            "Install it with: pip install aiohttp"
        )

    try:
        timeout = aiohttp.ClientTimeout(total=30.0)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    raise ManifestError(
                        f"Failed to fetch manifest: HTTP {resp.status} "
                        f"from {url}"
                    )
                data = await resp.read()
    except aiohttp.ClientError as exc:
        raise ManifestError(
            f"Network error fetching manifest from {url}: {exc}"
        ) from exc

    manifest = deserialize_manifest(data)

    errors = validate_manifest(manifest)
    if errors:
        error_str = "; ".join(errors)
        raise ManifestValidationError(
            f"Manifest validation failed: {error_str}"
        )

    log.info(
        "manifest_loaded",
        model_id=manifest.model_id,
        total_chunks=manifest.total_chunks,
        total_bytes=manifest.total_model_bytes,
    )
    return manifest


# ── Internal conversion helpers ─────────────────────────────────────────────


def _manifest_to_dict(manifest: RexManifest) -> dict[str, Any]:
    """Convert a RexManifest to a JSON-serializable dict."""
    parameters: dict[str, Any] = {}
    for name, td in manifest.parameters.items():
        parameters[name] = {
            "shape": list(td.shape),
            "dtype": td.dtype,
            "num_chunks": td.num_chunks,
            "total_bytes": td.total_bytes,
            "chunk_addresses": [
                {
                    "chunk_id": addr.chunk_id,
                    "resource_id": addr.resource_id,
                    "byte_range": {
                        "start": addr.byte_range.start,
                        "end": addr.byte_range.end,
                    },
                }
                for addr in td.chunk_addresses
            ],
        }

    return {
        "manifest_version": manifest.manifest_version,
        "model_id": manifest.model_id,
        "model_family": manifest.model_family,
        "source_framework": manifest.source_framework,
        "parameters": parameters,
        "total_model_bytes": manifest.total_model_bytes,
        "total_chunks": manifest.total_chunks,
        "default_chunk_size": manifest.default_chunk_size,
        "storage_backend": manifest.storage_backend.value,
        "compression": manifest.compression.value,
        "cache_constraints": {
            "max_local_fraction_of_model": manifest.cache_constraints.max_local_fraction_of_model,
            "max_memory_cache_bytes": manifest.cache_constraints.max_memory_cache_bytes,
            "max_disk_cache_bytes": manifest.cache_constraints.max_disk_cache_bytes,
            "enforce_invariant": manifest.cache_constraints.enforce_invariant,
        },
        "execution_graph": manifest.execution_graph,
        "backend_requirements": manifest.backend_requirements,
        "feature_flags": manifest.feature_flags,
        "provenance": manifest.provenance,
    }


def _dict_to_manifest(data: dict[str, Any]) -> RexManifest:
    """Convert a parsed dict into a RexManifest."""
    cache_raw = data.get("cache_constraints", {})
    cache_constraints = CacheConstraints(
        max_local_fraction_of_model=cache_raw.get(
            "max_local_fraction_of_model", 0.4
        ),
        max_memory_cache_bytes=cache_raw.get("max_memory_cache_bytes", 0),
        max_disk_cache_bytes=cache_raw.get("max_disk_cache_bytes", 0),
        enforce_invariant=cache_raw.get("enforce_invariant", True),
    )

    parameters: dict[str, TensorDescriptor] = {}
    for name, param_raw in data.get("parameters", {}).items():
        chunk_addrs = []
        for ca_raw in param_raw.get("chunk_addresses", []):
            br = ca_raw.get("byte_range", {})
            chunk_addrs.append(
                ChunkAddress(
                    chunk_id=ca_raw.get("chunk_id", ""),
                    resource_id=ca_raw.get("resource_id", ""),
                    byte_range=ByteRange(
                        start=br.get("start", 0),
                        end=br.get("end", 0),
                    ),
                )
            )

        shape = tuple(param_raw.get("shape", ()))
        parameters[name] = TensorDescriptor(
            name=name,
            shape=shape,
            dtype=param_raw.get("dtype", "float32"),
            num_chunks=param_raw.get("num_chunks", 0),
            chunk_addresses=chunk_addrs,
            total_bytes=param_raw.get("total_bytes", 0),
        )

    try:
        backend = StorageBackendType(
            data.get("storage_backend", "http_range")
        )
    except ValueError:
        backend = StorageBackendType.HTTP_RANGE

    try:
        compression = CompressionCodec(
            data.get("compression", "none")
        )
    except ValueError:
        compression = CompressionCodec.NONE

    return RexManifest(
        manifest_version=data.get("manifest_version", DEFAULT_MANIFEST_VERSION),
        model_id=data.get("model_id", ""),
        model_family=data.get("model_family", ""),
        source_framework=data.get("source_framework", "unknown"),
        parameters=parameters,
        total_model_bytes=data.get("total_model_bytes", 0),
        total_chunks=data.get("total_chunks", 0),
        default_chunk_size=data.get("default_chunk_size", 524288),
        storage_backend=backend,
        compression=compression,
        cache_constraints=cache_constraints,
        execution_graph=data.get("execution_graph", []),
        backend_requirements=data.get("backend_requirements", {}),
        feature_flags=data.get("feature_flags", {}),
        provenance=data.get("provenance", {}),
    )


def _validate_tensor_descriptor(
    name: str,
    td: TensorDescriptor,
) -> list[str]:
    """Validate a single TensorDescriptor."""
    errors: list[str] = []

    if not td.name:
        errors.append(f"Parameter has empty name")

    if not td.shape or len(td.shape) == 0:
        errors.append(f"Parameter '{name}' has empty shape")

    if any(d <= 0 for d in td.shape):
        errors.append(
            f"Parameter '{name}' has invalid shape dimensions: {td.shape}"
        )

    if not td.dtype:
        errors.append(f"Parameter '{name}' has empty dtype")

    if td.num_chunks <= 0:
        errors.append(
            f"Parameter '{name}' has invalid num_chunks: {td.num_chunks}"
        )

    if td.total_bytes <= 0:
        errors.append(
            f"Parameter '{name}' has invalid total_bytes: {td.total_bytes}"
        )

    if td.num_chunks > 0 and len(td.chunk_addresses) != td.num_chunks:
        errors.append(
            f"Parameter '{name}': num_chunks ({td.num_chunks}) does not "
            f"match chunk_addresses count ({len(td.chunk_addresses)})"
        )

    return errors


def _validate_chunk_address(
    param_name: str,
    addr: ChunkAddress,
) -> list[str]:
    """Validate a single ChunkAddress."""
    errors: list[str] = []

    if not addr.chunk_id:
        errors.append(
            f"Parameter '{param_name}' has a chunk with empty chunk_id"
        )

    if not addr.resource_id:
        errors.append(
            f"Parameter '{param_name}' chunk '{addr.chunk_id}' has "
            f"empty resource_id"
        )

    if addr.byte_range.start < 0:
        errors.append(
            f"Chunk '{addr.chunk_id}' has negative byte_range start"
        )

    if addr.byte_range.end <= addr.byte_range.start:
        errors.append(
            f"Chunk '{addr.chunk_id}' has invalid byte_range "
            f"[{addr.byte_range.start}, {addr.byte_range.end})"
        )

    return errors


if __name__ == "__main__":
    import asyncio

    # === Build a test manifest ===
    manifest = RexManifest(
        manifest_version="1.0.0",
        model_id="test-model-v1",
        model_family="TestFamily",
        source_framework="pytorch",
        parameters={
            "layer_0.weight": TensorDescriptor(
                name="layer_0.weight",
                shape=(768, 768),
                dtype="float32",
                num_chunks=2,
                total_bytes=768 * 768 * 4,
                chunk_addresses=[
                    ChunkAddress(
                        chunk_id="layer_0.weight.0",
                        resource_id="file_001.bin",
                        byte_range=ByteRange(start=0, end=524288),
                    ),
                    ChunkAddress(
                        chunk_id="layer_0.weight.1",
                        resource_id="file_001.bin",
                        byte_range=ByteRange(start=524288, end=1048576),
                    ),
                ],
            ),
        },
        total_model_bytes=768 * 768 * 4,
        total_chunks=2,
        execution_graph=["layer_0.weight"],
        feature_flags={"compressed_chunks": True, "quantized_chunks": False},
    )

    # Validate
    errors = validate_manifest(manifest)
    assert not errors, f"Unexpected errors: {errors}"
    print("Validation passed for test manifest.")

    # Serialize and deserialize
    data = serialize_manifest(manifest)
    print(f"Serialized size: {len(data)} bytes")

    manifest2 = deserialize_manifest(data)
    assert manifest2.model_id == manifest.model_id
    assert manifest2.total_chunks == manifest.total_chunks
    print("Round-trip serialization successful.")

    # Pretty print
    print("\n" + pretty_print(manifest))

    # Test invalid manifest
    bad_manifest = RexManifest(
        manifest_version="99.0.0",
        model_id="",
        model_family="",
        source_framework="pytorch",
        total_model_bytes=-1,
        total_chunks=0,
    )
    errors = validate_manifest(bad_manifest)
    assert len(errors) > 0
    print(f"\nBad manifest has {len(errors)} validation errors:")
    for e in errors:
        print(f"  - {e}")

    print("\n=== All tests passed! ===")
