"""
Main RexRuntime class that ties all subsystems together.

Provides the top-level API for loading models and running inference,
initializing and coordinating storage, cache, scheduler, prefetcher,
and executor components.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import structlog

from rex.api.config import RexConfig
from rex.cache.disk_cache import DiskCache
from rex.cache.memory_cache import MemoryCache
from rex.cache.policies import create_policy
from rex.cache.two_tier import TwoTierCache
from rex.cache.residency import ResidencyTracker
from rex.core.chunk_index import ChunkIndex
from rex.core.graph_model import ExecutionDAG
from rex.core.graph_scheduler import GraphScheduler
from rex.core.executor import EvictionStrategy, ModelLayer, SequentialExecutor
from rex.core.invariants import InvariantChecker
from rex.core.model_manifest import (
    get_manifest_size_bytes,
    load_manifest,
    pretty_print,
    validate_manifest,
)
from rex.core.prefetcher import AsyncPrefetcher
from rex.core.scheduler import NetworkConditions, Scheduler
from rex.core.types import (
    ChunkAddress,
    CompressionCodec,
    InferenceMetrics,
    RexManifest,
    StorageBackendType,
    TensorState,
)
from rex.core.virtual_tensor import VirtualTensor

logger = structlog.get_logger(__name__)


class RexRuntime:
    """Top-level runtime that orchestrates all Rex subsystems.

    Manages the lifecycle of model loading, cache management,
    prefetch scheduling, and inference execution.

    Usage::

        runtime = RexRuntime(RexConfig())
        runtime.load_model("path/to/manifest.json")
        output, metrics = runtime.run_inference(input_data)
        runtime.shutdown()

    Args:
        config: Full runtime configuration.
    """

    def __init__(self, config: RexConfig) -> None:
        self._config = config
        self._log = logger.bind(component="runtime")

        # Core state
        self._manifest: Optional[RexManifest] = None
        self._chunk_index = ChunkIndex()
        self._execution_dag: Optional[ExecutionDAG] = None
        self._virtual_tensors: dict[str, VirtualTensor] = {}
        self._model_loaded = False

        # Backpressure tracking
        self._get_cache_stats_async: Optional[Any] = None
        self._last_known_cache_fill: float = 0.0

        # Subsystems (initialized during load_model)
        self._cache: Optional[MemoryCache | TwoTierCache] = None
        self._residency_tracker: Optional[ResidencyTracker] = None
        self._invariant_checker: Optional[InvariantChecker] = None
        self._scheduler: Optional[Scheduler] = None
        self._prefetcher: Optional[AsyncPrefetcher] = None
        self._executor: Optional[SequentialExecutor] = None
        self._http_backend: Optional[Any] = None
        self._model_layers: list[ModelLayer] = []
        self._cache_max_bytes: int = 0

        self._log.info(
            "runtime_created",
            cache_policy=config.cache.policy.value,
            prefetch_window=config.scheduler.prefetch_window,
        )

    @property
    def cache(self) -> Optional[MemoryCache | TwoTierCache]:
        """The cache instance, or None if not initialized."""
        return self._cache

    @property
    def prefetcher(self) -> Optional[AsyncPrefetcher]:
        """The prefetcher instance, or None if not initialized."""
        return self._prefetcher

    @property
    def storage(self) -> Optional[Any]:
        """The HTTP storage backend, or None if not initialized."""
        return self._http_backend

    @property
    def manifest(self) -> Optional[RexManifest]:
        """The loaded model manifest, or None if not loaded."""
        return self._manifest

    @property
    def execution_dag(self) -> Optional[ExecutionDAG]:
        """Execution DAG metadata, if built during model loading."""
        return self._execution_dag

    @property
    def is_model_loaded(self) -> bool:
        """Whether a model has been loaded."""
        return self._model_loaded

    async def load_model(self, manifest_path_or_url: str) -> None:
        """Load a model from a manifest path or URL.

        Initializes all subsystems: cache, residency tracker, invariant
        checker, chunk index, scheduler, prefetcher, and executor.

        Args:
            manifest_path_or_url: Path to manifest JSON or HTTP(S) URL.

        Raises:
            RuntimeError: If a model is already loaded.
        """
        if self._model_loaded:
            raise RuntimeError(
                "A model is already loaded. Call shutdown() first."
            )

        self._log.info("loading_model", path=manifest_path_or_url)
        start_time = time.monotonic()

        # Step 1: Load and validate manifest
        self._manifest = await load_manifest(manifest_path_or_url)
        manifest = self._manifest
        assert manifest is not None

        self._log.info(
            "manifest_loaded",
            model_id=manifest.model_id,
            model_family=manifest.model_family,
            total_bytes=manifest.total_model_bytes,
            total_chunks=manifest.total_chunks,
        )

        # Step 2: Build chunk index
        self._chunk_index.build_from_manifest(manifest)
        errors = self._chunk_index.validate_index()
        if errors:
            self._log.warning(
                "chunk_index_validation_issues",
                errors=errors,
            )

        # Step 3: Build virtual tensors
        self._virtual_tensors.clear()
        for param_name, td in manifest.parameters.items():
            vt = VirtualTensor(
                name=param_name,
                shape=td.shape,
                dtype=td.dtype,
                chunk_addresses=td.chunk_addresses,
                quantization=td.quantization,
            )
            self._virtual_tensors[param_name] = vt

        self._log.info(
            "virtual_tensors_created",
            count=len(self._virtual_tensors),
        )

        # Step 4: Initialize cache
        cache_max_bytes = self._config.cache.max_memory_cache_bytes
        if cache_max_bytes <= 0:
            # Auto: use cache constraint from manifest, or 40% of model
            cc = manifest.cache_constraints
            if cc.max_memory_cache_bytes > 0:
                cache_max_bytes = cc.max_memory_cache_bytes
            else:
                cache_max_bytes = int(
                    manifest.total_model_bytes * cc.max_local_fraction_of_model
                )

        policy = create_policy(
            self._config.cache.policy.value,
            alpha=self._config.cache.weighted_alpha,
            beta=self._config.cache.weighted_beta,
            gamma=self._config.cache.weighted_gamma,
        )
        self._cache = MemoryCache(max_bytes=cache_max_bytes, policy=policy)

        # Wrap in TwoTierCache if disk caching is configured
        if self._config.cache.max_disk_cache_bytes > 0:
            disk_cache = DiskCache(
                cache_dir=self._config.cache.disk_cache_path,
                max_bytes=self._config.cache.max_disk_cache_bytes,
            )
            self._cache = TwoTierCache(
                memory_cache=self._cache,
                disk_cache=disk_cache,
            )
            self._log.info(
                "two_tier_cache_enabled",
                disk_path=self._config.cache.disk_cache_path,
                disk_max_bytes=self._config.cache.max_disk_cache_bytes,
            )

        self._log.info(
            "cache_initialized",
            max_bytes=cache_max_bytes,
            max_mb=cache_max_bytes / (1024 * 1024),
            policy=policy.policy_name(),
        )

        # Step 5: Initialize residency tracker
        self._residency_tracker = ResidencyTracker()

        # Step 6: Initialize invariant checker
        self._invariant_checker = InvariantChecker(
            total_model_bytes=manifest.total_model_bytes,
            max_local_fraction=self._config.cache.max_local_fraction_of_model,
        )

        # Step 7: Build scheduling metadata
        execution_graph = manifest.execution_graph
        if not execution_graph:
            # Default: use parameter names in insertion order
            execution_graph = list(manifest.parameters.keys())

        chunk_lookup: dict[str, list[ChunkAddress]] = {}
        for param_name in execution_graph:
            td = manifest.parameters.get(param_name)
            if td is not None:
                chunk_lookup[param_name] = td.chunk_addresses

        scheduler_mode = self._config.scheduler.scheduler_mode.lower().strip()
        if scheduler_mode not in {"sequential", "graph"}:
            self._log.warning(
                "invalid_scheduler_mode",
                mode=self._config.scheduler.scheduler_mode,
                fallback="sequential",
            )
            scheduler_mode = "sequential"

        selected_execution_graph = execution_graph

        # Build DAG metadata for observability and graph-aware scheduling mode.
        # Graph mode uses topological order from the DAG, then falls back to
        # sequential order if DAG build/topo resolution fails.
        should_build_dag = (
            self._config.scheduler.build_execution_dag_metadata
            or scheduler_mode == "graph"
        )
        if should_build_dag:
            try:
                self._execution_dag = ExecutionDAG.from_execution_order(
                    execution_order=execution_graph,
                    chunk_lookup=chunk_lookup,
                )
                self._log.info(
                    "execution_dag_built",
                    nodes=self._execution_dag.node_count,
                    edges=self._execution_dag.edge_count,
                    mode=scheduler_mode,
                )
                if scheduler_mode == "graph":
                    selected_execution_graph = self._execution_dag.topological_order()
                    self._log.info(
                        "graph_scheduler_enabled",
                        layers=len(selected_execution_graph),
                    )
            except Exception as dag_exc:
                self._execution_dag = None
                self._log.warning(
                    "execution_dag_build_failed",
                    error=str(dag_exc),
                )
                if scheduler_mode == "graph":
                    self._log.warning(
                        "graph_scheduler_fallback",
                        fallback="sequential",
                    )

        if scheduler_mode == "graph" and self._execution_dag is not None:
            self._scheduler = GraphScheduler(
                dag=self._execution_dag,
                chunk_lookup=chunk_lookup,
                prefetch_window=self._config.scheduler.prefetch_window,
                adaptive_window=self._config.scheduler.adaptive_window,
            )
        else:
            self._scheduler = Scheduler(
                execution_graph=selected_execution_graph,
                chunk_lookup=chunk_lookup,
                prefetch_window=self._config.scheduler.prefetch_window,
                adaptive_window=self._config.scheduler.adaptive_window,
            )

        # Step 8: Build model layers
        self._model_layers = []
        for param_name in selected_execution_graph:
            self._model_layers.append(
                ModelLayer(
                    name=param_name,
                    param_names=[param_name],
                )
            )

        # Step 9: Initialize prefetcher
        base_url = self._config.storage.base_url
        if not base_url and manifest.provenance.get("base_url"):
            base_url = manifest.provenance["base_url"]

        self._prefetcher = AsyncPrefetcher(
            storage_base_url=base_url,
            max_concurrent_fetches=self._config.storage.max_concurrent_fetches,
            max_retries=self._config.storage.retry_max_attempts,
            base_delay_seconds=self._config.storage.retry_base_delay_seconds,
        )

        # Set cache callback for backpressure
        if self._cache is not None:
            # Store async cache stats getter for periodic backpressure checks
            async def _get_cache_stats() -> dict[str, Any]:
                stats = await self._cache.get_stats()
                return {
                    "current_bytes": stats.current_bytes,
                    "max_bytes": stats.max_bytes,
                }
            self._get_cache_stats_async = _get_cache_stats

            # Set a sync callback that reads the latest known fill level;
            # the runtime updates this after each layer via _check_backpressure.
            self._last_known_cache_fill = 0.0
            self._prefetcher.set_cache_callback(
                get_current_bytes=lambda: int(self._last_known_cache_fill * cache_max_bytes),
                cache_capacity_bytes=cache_max_bytes,
            )

            # Enable per-chunk decompression when the manifest indicates it
            if manifest.feature_flags.get("compressed_chunks", False):
                self._prefetcher.set_decompress_after_fetch(True)

        # Step 9b: Initialize storage backend based on config
        backend_type = self._config.storage.backend_type
        if backend_type in (
            StorageBackendType.HTTP_RANGE,
            StorageBackendType.LOCAL_SERVER,
        ):
            from rex.storage.http_range import HTTPRangeBackend

            effective_base_url = base_url or "http://localhost:8080"
            self._http_backend = HTTPRangeBackend(
                base_url=effective_base_url,
                max_attempts=self._config.storage.retry_max_attempts,
            )
            self._log.info(
                "storage_backend_initialized",
                backend=backend_type.value,
                base_url=effective_base_url,
            )
        elif backend_type == StorageBackendType.GOOGLE_DRIVE:
            from rex.storage.google_drive import GoogleDriveBackend

            health_check_file_id = str(
                manifest.provenance.get("health_check_file_id", "")
            )
            self._http_backend = GoogleDriveBackend(
                token=self._config.storage.auth_token,
                health_check_file_id=health_check_file_id,
            )
            self._log.info(
                "storage_backend_initialized",
                backend=backend_type.value,
                health_check_file_id=health_check_file_id,
            )
        else:
            raise ValueError(
                f"Storage backend '{backend_type.value}' is not supported in RexRuntime yet."
            )

        # Step 10: Initialize executor
        try:
            evict_strategy = EvictionStrategy(
                self._config.scheduler.eviction_strategy
            )
        except ValueError:
            evict_strategy = EvictionStrategy.RETAIN_N_LAYERS

        self._cache_max_bytes = cache_max_bytes
        self._executor = SequentialExecutor(
            cache=self._cache,
            prefetcher=self._prefetcher,
            retry_max_attempts=self._config.storage.retry_max_attempts,
            invariant_checker=self._invariant_checker,
            eviction_strategy=evict_strategy,
            retain_window=self._config.scheduler.retain_window,
            cache_max_bytes=cache_max_bytes,
        )

        load_duration = (time.monotonic() - start_time) * 1000
        self._model_loaded = True

        self._log.info(
            "model_loaded",
            model_id=manifest.model_id,
            load_duration_ms=round(load_duration, 1),
            cache_max_mb=cache_max_bytes / (1024 * 1024),
            total_layers=len(execution_graph),
            total_chunks=manifest.total_chunks,
        )

    async def run_inference(
        self,
        input_data: Any,
        compute_fn: Optional[Any] = None,
    ) -> tuple[Any, InferenceMetrics]:
        """Run inference on the loaded model.

        Executes layers sequentially, materializing chunks on demand
        and tracking comprehensive metrics.

        Args:
            input_data: Input tensor or data for the first layer.
            compute_fn: Optional custom compute function. If provided,
                it is set on all model layers. Signature:
                compute_fn(input_data, weights: dict[str, tensor]) -> output

        Returns:
            Tuple of (output_data, InferenceMetrics).

        Raises:
            RuntimeError: If no model is loaded.
        """
        if not self._model_loaded or self._manifest is None:
            raise RuntimeError("No model loaded. Call load_model() first.")

        if self._executor is None or self._scheduler is None:
            raise RuntimeError("Runtime subsystems not initialized.")

        self._log.info("inference_start")

        # Periodically check backpressure via cache stats
        await self._check_backpressure()

        # Reset scheduler to beginning for each inference run
        if self._scheduler is not None:
            self._scheduler.set_position(0)

        # Optionally inject compute function into layers
        if compute_fn is not None:
            for layer in self._model_layers:
                layer.compute_fn = compute_fn

        # Start prefetcher
        if self._prefetcher is not None:
            await self._prefetcher.start()

        # Schedule prefetch for initial window
        if self._scheduler is not None and self._prefetcher is not None:
            from rex.core.types import ChunkPriority
            current_chunks = self._scheduler.plan_next_step()
            ahead_chunks = self._scheduler.peek_ahead()

            for addr in current_chunks:
                self._prefetcher.enqueue(addr, priority=ChunkPriority.HIGH)
            for addr in ahead_chunks:
                priority = self._scheduler.get_priority(addr)
                self._prefetcher.enqueue(addr, priority=priority)

        # Create async storage fetch function using HTTP backend
        async def async_storage_fetch(addr: ChunkAddress) -> Optional[bytes]:
            """Fetch chunk data from remote HTTP storage."""
            try:
                # HTTP/local servers use flat chunk filenames while cloud backends
                # require resource IDs as-is (e.g., Google Drive file IDs).
                if self._config.storage.backend_type in (
                    StorageBackendType.HTTP_RANGE,
                    StorageBackendType.LOCAL_SERVER,
                ):
                    resource_id = Path(addr.resource_id).name
                else:
                    resource_id = addr.resource_id
                data = await self._http_backend.fetch_range(
                    resource_id,
                    addr.byte_range.start,
                    addr.byte_range.end,
                )
                return data
            except Exception as exc:
                self._log.error(
                    "storage_fetch_failed",
                    chunk_id=addr.chunk_id,
                    resource_id=addr.resource_id,
                    error=str(exc),
                )
                return None

        # Set async fetch function on executor
        if self._executor is not None:
            self._executor._async_storage_fetch_func = async_storage_fetch

        # Execute
        try:
            output, metrics = await self._executor.execute(
                model_layers=self._model_layers,
                input_data=input_data,
                scheduler=self._scheduler,
                chunk_index=self._chunk_index,
                virtual_tensors=self._virtual_tensors,
                storage_fetch_func=None,  # using async fetch func instead
            )
        finally:
            # Stop prefetcher
            if self._prefetcher is not None:
                await self._prefetcher.stop()

        self._log.info(
            "inference_complete",
            total_ms=round(metrics.total_time_ms, 1),
            compute_ms=round(metrics.compute_time_ms, 1),
            stall_ms=round(metrics.stall_time_ms, 1),
            cache_hits=metrics.cache_hits,
            cache_misses=metrics.cache_misses,
        )

        # Final backpressure release
        await self._check_backpressure()

        return output, metrics

    async def _check_backpressure(self) -> None:
        """Update backpressure on the prefetcher based on current cache fill.

        Computes cache fill fraction from async cache stats and calls
        ``prefetcher.update_backpressure()`` so the prefetch worker can
        pause/resume fetching accordingly.
        """
        if (
            self._get_cache_stats_async is None
            or self._prefetcher is None
            or self._cache_max_bytes <= 0
        ):
            return
        try:
            stats = await self._get_cache_stats_async()
            current = stats["current_bytes"]
            max_b = stats["max_bytes"]
            fill = current / max_b if max_b > 0 else 0.0
            self._last_known_cache_fill = fill
            self._prefetcher.update_backpressure(fill)
        except Exception as exc:
            self._log.debug(
                "backpressure_check_error", error=str(exc),
            )

    def get_cache_stats(self) -> dict[str, Any]:
        """Return current cache statistics.

        Returns:
            Dictionary with cache stats or empty dict if not initialized.
        """
        if self._cache is None:
            return {}

        # Stats are async; return last known values
        # For sync access, we use internal attributes
        return {
            "max_bytes": self._cache.max_bytes,
            "policy": self._cache.policy.policy_name(),
        }

    def get_model_info(self) -> dict[str, Any]:
        """Return information about the loaded model.

        Returns:
            Dictionary with model metadata or empty dict if not loaded.
        """
        if self._manifest is None:
            return {}

        m = self._manifest
        return {
            "model_id": m.model_id,
            "model_family": m.model_family,
            "manifest_version": m.manifest_version,
            "source_framework": m.source_framework,
            "total_model_bytes": m.total_model_bytes,
            "total_model_mb": round(m.total_model_bytes / (1024 * 1024), 2),
            "total_chunks": m.total_chunks,
            "default_chunk_size": m.default_chunk_size,
            "storage_backend": m.storage_backend.value,
            "compression": m.compression.value,
            "num_parameters": len(m.parameters),
            "execution_graph_layers": len(m.execution_graph),
            "manifest_size_bytes": get_manifest_size_bytes(m),
            "feature_flags": m.feature_flags,
            "cache_constraints": {
                "max_local_fraction": m.cache_constraints.max_local_fraction_of_model,
                "max_memory_cache_bytes": m.cache_constraints.max_memory_cache_bytes,
                "enforce_invariant": m.cache_constraints.enforce_invariant,
            },
        }

    def get_residency_summary(self) -> dict[str, Any]:
        """Return residency tracking summary.

        Returns:
            Dictionary with residency stats or empty dict if not initialized.
        """
        if self._residency_tracker is None:
            return {}
        return self._residency_tracker.summary()

    async def get_full_cache_stats(self) -> dict[str, Any]:
        """Return full async cache statistics.

        Returns:
            Dictionary with detailed cache stats.
        """
        if self._cache is None:
            return {}

        stats = await self._cache.get_stats()
        residency = self._residency_tracker.summary() if self._residency_tracker else {}

        return {
            "cache": {
                "max_bytes": stats.max_bytes,
                "current_bytes": stats.current_bytes,
                "current_entries": stats.current_entries,
                "hit_count": stats.hit_count,
                "miss_count": stats.miss_count,
                "eviction_count": stats.eviction_count,
                "insertion_count": stats.insertion_count,
                "rejection_count": stats.rejection_count,
                "hit_rate": round(stats.hit_rate, 4),
                "utilization": round(stats.current_bytes / stats.max_bytes, 4) if stats.max_bytes > 0 else 0.0,
                "policy": self._cache.policy.policy_name(),
            },
            "residency": residency,
        }

    async def get_scheduler_metrics(self) -> dict[str, Any]:
        """Return scheduler metrics.

        Returns:
            Dictionary with scheduler state.
        """
        if self._scheduler is None:
            return {}
        metrics = self._scheduler.get_metrics()
        return {
            "current_position": metrics.current_position,
            "total_positions": metrics.total_positions,
            "prefetch_window": metrics.prefetch_window,
            "chunks_needed_current": metrics.chunks_needed_current,
            "chunks_needed_ahead": metrics.chunks_needed_ahead,
            "high_priority_count": metrics.high_priority_count,
            "low_priority_count": metrics.low_priority_count,
            "background_priority_count": metrics.background_priority_count,
            "is_complete": self._scheduler.is_complete(),
        }

    async def get_prefetch_metrics(self) -> dict[str, Any]:
        """Return prefetch engine metrics.

        Returns:
            Dictionary with prefetch stats.
        """
        if self._prefetcher is None:
            return {}
        return self._prefetcher.emit_prefetch_metrics()

    def pretty_print_model(self) -> str:
        """Return a human-readable model summary.

        Returns:
            Pretty-printed manifest, or "No model loaded" if uninitialized.
        """
        if self._manifest is None:
            return "No model loaded."
        return pretty_print(self._manifest)

    async def shutdown(self) -> None:
        """Shut down all subsystems and release resources.

        Should be called when the runtime is no longer needed.
        """
        self._log.info("runtime_shutdown_start")

        # Stop prefetcher
        if self._prefetcher is not None:
            await self._prefetcher.stop()
            self._prefetcher = None

        # Clear cache
        if self._cache is not None:
            await self._cache.clear()
            self._cache = None

        # Clear residency
        if self._residency_tracker is not None:
            self._residency_tracker.clear()
            self._residency_tracker = None

        # Close HTTP storage backend
        if self._http_backend is not None:
            await self._http_backend.close()
            self._http_backend = None

        # Clear state
        self._virtual_tensors.clear()
        self._chunk_index.clear()
        self._model_layers.clear()
        self._execution_dag = None
        self._manifest = None
        self._scheduler = None
        self._executor = None
        self._model_loaded = False

        self._log.info("runtime_shutdown_complete")

    def __repr__(self) -> str:
        loaded = self._manifest.model_id if self._manifest else "none"
        return (
            f"RexRuntime(model={loaded!r}, loaded={self._model_loaded})"
        )


if __name__ == "__main__":
    import asyncio
    import json
    import tempfile
    import numpy as np
    from rex.core.types import ByteRange, ChunkAddress, TensorDescriptor

    async def _demo() -> None:
        print("=== RexRuntime Demo ===\n")

        # Create a temporary manifest file
        manifest = RexManifest(
            manifest_version="1.0.0",
            model_id="demo-model-v1",
            model_family="DemoFamily",
            source_framework="pytorch",
            parameters={
                "layer_0.weight": TensorDescriptor(
                    name="layer_0.weight",
                    shape=(4, 4),
                    dtype="float32",
                    num_chunks=1,
                    total_bytes=64,
                    chunk_addresses=[
                        ChunkAddress(
                            chunk_id="layer_0.weight.0",
                            resource_id="weights.bin",
                            byte_range=ByteRange(start=0, end=64),
                        ),
                    ],
                ),
                "layer_0.bias": TensorDescriptor(
                    name="layer_0.bias",
                    shape=(4,),
                    dtype="float32",
                    num_chunks=1,
                    total_bytes=16,
                    chunk_addresses=[
                        ChunkAddress(
                            chunk_id="layer_0.bias.0",
                            resource_id="weights.bin",
                            byte_range=ByteRange(start=64, end=80),
                        ),
                    ],
                ),
                "layer_1.weight": TensorDescriptor(
                    name="layer_1.weight",
                    shape=(4, 4),
                    dtype="float32",
                    num_chunks=1,
                    total_bytes=64,
                    chunk_addresses=[
                        ChunkAddress(
                            chunk_id="layer_1.weight.0",
                            resource_id="weights.bin",
                            byte_range=ByteRange(start=80, end=144),
                        ),
                    ],
                ),
            },
            total_model_bytes=144,
            total_chunks=3,
            execution_graph=["layer_0.weight", "layer_0.bias", "layer_1.weight"],
            feature_flags={"compressed_chunks": False},
        )

        # Serialize to temp file
        from rex.core.model_manifest import serialize_manifest
        manifest_data = serialize_manifest(manifest)

        with tempfile.NamedTemporaryFile(
            mode="wb", suffix=".json", delete=False
        ) as f:
            f.write(manifest_data)
            temp_path = f.name

        try:
            # Create runtime
            config = RexConfig()
            config.storage.base_url = "http://localhost:8080"
            config.cache.max_memory_cache_bytes = 1024 * 1024  # 1 MB
            config.scheduler.prefetch_window = 2

            runtime = RexRuntime(config)
            print(f"Runtime: {runtime}")

            # Load model
            await runtime.load_model(temp_path)
            assert runtime.is_model_loaded
            print(f"Model loaded: {runtime.manifest.model_id}")

            # Model info
            info = runtime.get_model_info()
            print(f"\nModel info:")
            for key, val in info.items():
                print(f"  {key}: {val}")

            # Pretty print
            print(f"\n{runtime.pretty_print_model()}")

            # Residency summary
            res = runtime.get_residency_summary()
            print(f"\nResidency: {res}")

            # Cache stats
            cache_stats = runtime.get_cache_stats()
            print(f"\nCache stats: {cache_stats}")

            # Full async stats
            full_stats = await runtime.get_full_cache_stats()
            print(f"\nFull cache stats: {full_stats}")

            # Scheduler metrics
            sched = await runtime.get_scheduler_metrics()
            print(f"\nScheduler: {sched}")

            # Shutdown
            await runtime.shutdown()
            assert not runtime.is_model_loaded
            print("\nRuntime shut down successfully.")

        finally:
            import os
            os.unlink(temp_path)

    asyncio.run(_demo())
    print("\n=== Demo completed! ===")
