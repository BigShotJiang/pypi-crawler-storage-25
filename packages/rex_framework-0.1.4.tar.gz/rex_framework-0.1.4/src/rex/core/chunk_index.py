"""
Chunk index management for the Rex framework.

The chunk index provides fast lookup of chunk metadata by chunk_id,
by layer name, and other access patterns. It can be built from a
RexManifest (embedded index) or loaded from a separate index file.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, Optional

import structlog

from rex.core.types import (
    ByteRange,
    ChunkAddress,
    ChunkMetadata,
    CompressionCodec,
    RexManifest,
    TensorDescriptor,
)

logger = structlog.get_logger(__name__)


@dataclass
class IndexStats:
    """Statistics about the chunk index."""
    total_chunks: int = 0
    total_remote_bytes: int = 0
    total_uncompressed_bytes: int = 0
    num_parameters: int = 0
    num_resources: int = 0
    chunks_per_parameter: dict[str, int] = field(default_factory=dict)


class ChunkIndex:
    """Fast-lookup index for chunk metadata.

    Supports two modes:
        1. **Embedded**: Built directly from a RexManifest's parameter
           descriptors and chunk addresses.
        2. **Separate file**: Loaded from an external JSON index file
           that contains ChunkMetadata entries keyed by chunk_id.

    The index provides O(1) lookup by chunk_id and O(k) lookup by
    layer/parameter name (where k = number of chunks per parameter).

    Attributes:
        built: Whether the index has been populated.
    """

    def __init__(self) -> None:
        self._chunks: dict[str, ChunkMetadata] = {}
        self._by_parameter: dict[str, list[str]] = {}
        self._by_resource: dict[str, list[str]] = {}
        self._stats = IndexStats()
        self._built = False
        self._log = logger.bind(component="chunk_index")

    @property
    def built(self) -> bool:
        """Whether the index has been populated."""
        return self._built

    def build_from_manifest(self, manifest: RexManifest) -> None:
        """Build the chunk index from a RexManifest.

        Iterates over all parameter descriptors and their chunk addresses
        to populate the index. Existing data is cleared first.

        Args:
            manifest: The RexManifest to build the index from.
        """
        self._chunks.clear()
        self._by_parameter.clear()
        self._by_resource.clear()

        total_remote = 0
        total_uncompressed = 0

        for param_name, td in manifest.parameters.items():
            self._by_parameter[param_name] = []
            for addr in td.chunk_addresses:
                chunk_id = addr.chunk_id
                metadata = ChunkMetadata(
                    chunk_id=chunk_id,
                    resource_id=addr.resource_id,
                    byte_range=addr.byte_range,
                    checksum_sha256="",  # Embedded manifests may not have checksums per chunk
                    compression=manifest.compression,
                    uncompressed_size=td.total_bytes // max(td.num_chunks, 1),
                    compressed_size=addr.size_bytes,
                )
                self._chunks[chunk_id] = metadata
                self._by_parameter[param_name].append(chunk_id)

                if addr.resource_id not in self._by_resource:
                    self._by_resource[addr.resource_id] = []
                self._by_resource[addr.resource_id].append(chunk_id)

                total_remote += addr.size_bytes
                total_uncompressed += metadata.uncompressed_size

        self._stats = IndexStats(
            total_chunks=len(self._chunks),
            total_remote_bytes=total_remote,
            total_uncompressed_bytes=total_uncompressed,
            num_parameters=len(self._by_parameter),
            num_resources=len(self._by_resource),
            chunks_per_parameter={
                name: len(ids) for name, ids in self._by_parameter.items()
            },
        )
        self._built = True
        self._log.info(
            "chunk_index_built",
            total_chunks=self._stats.total_chunks,
            total_remote_mb=total_remote / (1024 * 1024),
            num_parameters=self._stats.num_parameters,
        )

    def build_from_descriptors(
        self,
        descriptors: list[TensorDescriptor],
        default_compression: CompressionCodec = CompressionCodec.NONE,
    ) -> None:
        """Build the chunk index from a list of TensorDescriptors.

        This is the preferred method when building from a conversion
        pipeline or external source.

        Args:
            descriptors: List of TensorDescriptor instances.
            default_compression: Compression codec to assume if not specified.
        """
        self._chunks.clear()
        self._by_parameter.clear()
        self._by_resource.clear()

        total_remote = 0
        total_uncompressed = 0

        for td in descriptors:
            param_name = td.name
            self._by_parameter[param_name] = []

            bytes_per_chunk = td.total_bytes // max(td.num_chunks, 1)

            for addr in td.chunk_addresses:
                chunk_id = addr.chunk_id
                metadata = ChunkMetadata(
                    chunk_id=chunk_id,
                    resource_id=addr.resource_id,
                    byte_range=addr.byte_range,
                    checksum_sha256="",
                    compression=default_compression,
                    uncompressed_size=bytes_per_chunk,
                    compressed_size=addr.size_bytes,
                )
                self._chunks[chunk_id] = metadata
                self._by_parameter[param_name].append(chunk_id)

                if addr.resource_id not in self._by_resource:
                    self._by_resource[addr.resource_id] = []
                self._by_resource[addr.resource_id].append(chunk_id)

                total_remote += addr.size_bytes
                total_uncompressed += bytes_per_chunk

        self._stats = IndexStats(
            total_chunks=len(self._chunks),
            total_remote_bytes=total_remote,
            total_uncompressed_bytes=total_uncompressed,
            num_parameters=len(self._by_parameter),
            num_resources=len(self._by_resource),
            chunks_per_parameter={
                name: len(ids) for name, ids in self._by_parameter.items()
            },
        )
        self._built = True
        self._log.info(
            "chunk_index_built_from_descriptors",
            total_chunks=self._stats.total_chunks,
            num_parameters=self._stats.num_parameters,
        )

    def load_from_file(self, path: str) -> None:
        """Load a separate chunk index from a JSON file.

        The file format is a JSON object keyed by chunk_id, where each
        value is a ChunkMetadata-like dict.

        Args:
            path: Path to the JSON index file.
        """
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Chunk index file not found: {path}")

        with open(path, "rb") as f:
            data = json.loads(f.read().decode("utf-8"))

        self._chunks.clear()
        self._by_parameter.clear()
        self._by_resource.clear()

        total_remote = 0
        total_uncompressed = 0

        for chunk_id, raw in data.items():
            br = raw.get("byte_range", {})
            metadata = ChunkMetadata(
                chunk_id=chunk_id,
                resource_id=raw.get("resource_id", ""),
                byte_range=ByteRange(
                    start=br.get("start", 0),
                    end=br.get("end", 0),
                ),
                checksum_sha256=raw.get("checksum_sha256", ""),
                compression=CompressionCodec(
                    raw.get("compression", "none")
                ),
                uncompressed_size=raw.get("uncompressed_size", 0),
                compressed_size=raw.get("compressed_size", 0),
            )
            self._chunks[chunk_id] = metadata

            param_name = raw.get("parameter_name", "")
            if param_name:
                if param_name not in self._by_parameter:
                    self._by_parameter[param_name] = []
                self._by_parameter[param_name].append(chunk_id)

            resource_id = metadata.resource_id
            if resource_id and resource_id not in self._by_resource:
                self._by_resource[resource_id] = []
            if resource_id:
                self._by_resource[resource_id].append(chunk_id)

            total_remote += metadata.compressed_size
            total_uncompressed += metadata.uncompressed_size

        self._stats = IndexStats(
            total_chunks=len(self._chunks),
            total_remote_bytes=total_remote,
            total_uncompressed_bytes=total_uncompressed,
            num_parameters=len(self._by_parameter),
            num_resources=len(self._by_resource),
            chunks_per_parameter={
                name: len(ids) for name, ids in self._by_parameter.items()
            },
        )
        self._built = True
        self._log.info(
            "chunk_index_loaded_from_file",
            path=path,
            total_chunks=self._stats.total_chunks,
        )

    def lookup(self, chunk_id: str) -> Optional[ChunkMetadata]:
        """Look up a single chunk by its ID.

        Args:
            chunk_id: The unique chunk identifier.

        Returns:
            ChunkMetadata if found, None otherwise.
        """
        return self._chunks.get(chunk_id)

    def lookup_by_layer(self, layer_name: str) -> list[ChunkMetadata]:
        """Look up all chunks belonging to a parameter/layer.

        Args:
            layer_name: The parameter or layer name.

        Returns:
            List of ChunkMetadata for the layer, in manifest order.
            Empty list if the layer is not found.
        """
        chunk_ids = self._by_parameter.get(layer_name, [])
        return [self._chunks[cid] for cid in chunk_ids if cid in self._chunks]

    def lookup_by_resource(self, resource_id: str) -> list[ChunkMetadata]:
        """Look up all chunks stored in a given resource.

        Args:
            resource_id: The remote resource identifier.

        Returns:
            List of ChunkMetadata for the resource.
        """
        chunk_ids = self._by_resource.get(resource_id, [])
        return [self._chunks[cid] for cid in chunk_ids if cid in self._chunks]

    def get_all_chunk_ids(self) -> list[str]:
        """Return all chunk IDs in the index.

        Returns:
            Sorted list of all chunk_id strings.
        """
        return sorted(self._chunks.keys())

    def get_total_remote_bytes(self) -> int:
        """Return total compressed bytes across all chunks.

        Returns:
            Sum of compressed_size for all chunks.
        """
        return self._stats.total_remote_bytes

    def get_total_uncompressed_bytes(self) -> int:
        """Return total uncompressed bytes across all chunks."""
        return self._stats.total_uncompressed_bytes

    def get_stats(self) -> IndexStats:
        """Return index statistics."""
        return self._stats

    def get_parameter_names(self) -> list[str]:
        """Return all parameter/layer names in the index."""
        return sorted(self._by_parameter.keys())

    def validate_index(self) -> list[str]:
        """Validate the chunk index for internal consistency.

        Checks:
            - All chunk IDs are non-empty
            - All resource IDs are non-empty
            - Byte ranges are valid (start >= 0, end > start)
            - No duplicate chunk IDs
            - Parameter references point to existing chunks
            - Resource references point to existing chunks

        Returns:
            List of validation error strings. Empty if valid.
        """
        errors: list[str] = []

        if not self._built:
            errors.append("Index has not been built")
            return errors

        # Check each chunk
        for chunk_id, meta in self._chunks.items():
            if not chunk_id:
                errors.append("Chunk with empty chunk_id found")

            if not meta.resource_id:
                errors.append(
                    f"Chunk '{chunk_id}' has empty resource_id"
                )

            if meta.byte_range.start < 0:
                errors.append(
                    f"Chunk '{chunk_id}' has negative byte_range.start"
                )

            if meta.byte_range.end <= meta.byte_range.start:
                errors.append(
                    f"Chunk '{chunk_id}' has invalid byte_range "
                    f"[{meta.byte_range.start}, {meta.byte_range.end})"
                )

            if meta.compressed_size <= 0:
                errors.append(
                    f"Chunk '{chunk_id}' has invalid compressed_size: "
                    f"{meta.compressed_size}"
                )

        # Check parameter references
        for param_name, chunk_ids in self._by_parameter.items():
            for cid in chunk_ids:
                if cid not in self._chunks:
                    errors.append(
                        f"Parameter '{param_name}' references unknown "
                        f"chunk '{cid}'"
                    )

        # Check resource references
        for resource_id, chunk_ids in self._by_resource.items():
            for cid in chunk_ids:
                if cid not in self._chunks:
                    errors.append(
                        f"Resource '{resource_id}' references unknown "
                        f"chunk '{cid}'"
                    )

        # Cross-check totals
        actual_total = sum(
            m.compressed_size for m in self._chunks.values()
        )
        if actual_total != self._stats.total_remote_bytes:
            errors.append(
                f"Stats total_remote_bytes ({self._stats.total_remote_bytes}) "
                f"does not match actual sum ({actual_total})"
            )

        return errors

    def clear(self) -> None:
        """Clear all index data."""
        self._chunks.clear()
        self._by_parameter.clear()
        self._by_resource.clear()
        self._stats = IndexStats()
        self._built = False

    def __len__(self) -> int:
        return len(self._chunks)

    def __contains__(self, chunk_id: str) -> bool:
        return chunk_id in self._chunks

    def __repr__(self) -> str:
        return (
            f"ChunkIndex(chunks={len(self._chunks)}, "
            f"parameters={len(self._by_parameter)}, "
            f"resources={len(self._by_resource)})"
        )


if __name__ == "__main__":
    from rex.core.model_manifest import serialize_manifest, deserialize_manifest

    # === Build from manifest ===
    print("=== ChunkIndex Tests ===\n")

    from rex.core.types import ChunkAddress, ByteRange

    manifest = RexManifest(
        manifest_version="1.0.0",
        model_id="test-model",
        model_family="TestFamily",
        source_framework="pytorch",
        parameters={
            "layer_0.weight": TensorDescriptor(
                name="layer_0.weight",
                shape=(256, 256),
                dtype="float32",
                num_chunks=2,
                total_bytes=256 * 256 * 4,
                chunk_addresses=[
                    ChunkAddress(
                        chunk_id="layer_0.weight.0",
                        resource_id="weights.bin",
                        byte_range=ByteRange(start=0, end=131072),
                    ),
                    ChunkAddress(
                        chunk_id="layer_0.weight.1",
                        resource_id="weights.bin",
                        byte_range=ByteRange(start=131072, end=262144),
                    ),
                ],
            ),
            "layer_0.bias": TensorDescriptor(
                name="layer_0.bias",
                shape=(256,),
                dtype="float32",
                num_chunks=1,
                total_bytes=256 * 4,
                chunk_addresses=[
                    ChunkAddress(
                        chunk_id="layer_0.bias.0",
                        resource_id="weights.bin",
                        byte_range=ByteRange(start=262144, end=263168),
                    ),
                ],
            ),
        },
        total_model_bytes=256 * 256 * 4 + 256 * 4,
        total_chunks=3,
        execution_graph=["layer_0.weight", "layer_0.bias"],
    )

    index = ChunkIndex()
    index.build_from_manifest(manifest)
    assert index.built
    print(f"Index built: {index}")

    # Lookup
    meta = index.lookup("layer_0.weight.0")
    assert meta is not None
    print(f"Lookup 'layer_0.weight.0': {meta.chunk_id}, {meta.resource_id}")

    meta = index.lookup("nonexistent")
    assert meta is None
    print(f"Lookup 'nonexistent': {meta}")

    # By layer
    layer_chunks = index.lookup_by_layer("layer_0.weight")
    assert len(layer_chunks) == 2
    print(f"Layer 'layer_0.weight' has {len(layer_chunks)} chunks")

    # All IDs
    all_ids = index.get_all_chunk_ids()
    assert len(all_ids) == 3
    print(f"All chunk IDs: {all_ids}")

    # Total bytes
    print(f"Total remote bytes: {index.get_total_remote_bytes():,}")

    # Validate
    errors = index.validate_index()
    assert not errors, f"Validation errors: {errors}"
    print("Index validation passed.")

    # Stats
    stats = index.get_stats()
    print(f"Stats: chunks={stats.total_chunks}, params={stats.num_parameters}")

    # Build from descriptors
    index2 = ChunkIndex()
    index2.build_from_descriptors(list(manifest.parameters.values()))
    assert index2.built
    assert len(index2) == 3
    print(f"Built from descriptors: {index2}")

    # Clear
    index.clear()
    assert not index.built
    assert len(index) == 0
    print("Index cleared successfully.")

    print("\n=== All tests passed! ===")
