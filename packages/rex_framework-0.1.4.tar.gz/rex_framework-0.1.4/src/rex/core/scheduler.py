"""
Execution scheduler for the Rex framework.

Plans the order of chunk fetches and prioritizes prefetch operations
based on the execution graph and current position. Adapts prefetch
window size based on simulated network conditions.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

import structlog

from rex.core.errors import SchedulerError
from rex.core.types import ChunkAddress, ChunkPriority

logger = structlog.get_logger(__name__)


@dataclass
class SchedulingMetrics:
    """Metrics emitted by the scheduler."""
    chunks_needed_current: int = 0
    chunks_needed_ahead: int = 0
    lookahead_depth: int = 0
    current_position: int = 0
    total_positions: int = 0
    prefetch_window: int = 0
    high_priority_count: int = 0
    low_priority_count: int = 0
    background_priority_count: int = 0


@dataclass
class NetworkConditions:
    """Simulated or measured network conditions for adaptive scheduling."""
    latency_ms: float = 50.0
    bandwidth_mbps: float = 100.0
    packet_loss_rate: float = 0.0

    @property
    def estimated_chunk_fetch_ms(self, chunk_bytes: int = 524288) -> float:
        """Estimate time to fetch a chunk of given size.

        Args:
            chunk_bytes: Size of the chunk in bytes.

        Returns:
            Estimated fetch time in milliseconds.
        """
        transfer_time_ms = (chunk_bytes * 8) / (self.bandwidth_mbps * 1e6) * 1000
        return self.latency_ms + transfer_time_ms

    @property
    def quality_score(self) -> float:
        """Network quality score (0.0 = terrible, 1.0 = excellent)."""
        # Penalize high latency (>500ms is bad)
        latency_score = max(0.0, 1.0 - self.latency_ms / 1000.0)
        # Penalize low bandwidth (<10 Mbps is bad)
        bandwidth_score = min(1.0, self.bandwidth_mbps / 100.0)
        # Penalize packet loss
        loss_score = 1.0 - self.packet_loss_rate
        return (latency_score * 0.3 + bandwidth_score * 0.4 + loss_score * 0.3)


class Scheduler:
    """Execution scheduler that plans chunk fetches based on execution order.

    The scheduler maintains a position in the execution graph and provides:
        - Chunks needed for the current step
        - Chunks to prefetch for future steps
        - Priority assignments based on urgency
        - Adaptive prefetch window sizing

    Args:
        execution_graph: Ordered list of parameter/layer names.
        chunk_lookup: Callable mapping parameter_name -> list[ChunkAddress].
        prefetch_window: Default look-ahead window size.
        adaptive_window: Whether to dynamically adjust the window.
    """

    def __init__(
        self,
        execution_graph: list[str],
        chunk_lookup: dict[str, list[ChunkAddress]],
        prefetch_window: int = 4,
        adaptive_window: bool = True,
    ) -> None:
        if not execution_graph:
            raise SchedulerError("Execution graph must not be empty")
        if prefetch_window < 1:
            raise SchedulerError("prefetch_window must be >= 1")

        self._execution_graph = execution_graph
        self._chunk_lookup = chunk_lookup
        self._base_prefetch_window = prefetch_window
        self._prefetch_window = prefetch_window
        self._adaptive_window = adaptive_window
        self._current_position: int = 0
        self._network_conditions = NetworkConditions()
        self._log = logger.bind(
            component="scheduler",
            total_layers=len(execution_graph),
        )
        self._log.info(
            "scheduler_initialized",
            prefetch_window=prefetch_window,
            adaptive=adaptive_window,
        )

    @property
    def current_position(self) -> int:
        """Current execution position in the graph."""
        return self._current_position

    @property
    def total_positions(self) -> int:
        """Total number of positions in the execution graph."""
        return len(self._execution_graph)

    @property
    def prefetch_window(self) -> int:
        """Current prefetch window size."""
        return self._prefetch_window

    @property
    def execution_graph(self) -> list[str]:
        """Reference to the execution graph."""
        return self._execution_graph

    def set_position(self, pos: int) -> None:
        """Update the current execution position.

        Args:
            pos: Zero-based index into the execution graph.

        Raises:
            SchedulerError: If position is out of range.
        """
        if not (0 <= pos <= len(self._execution_graph)):
            raise SchedulerError(
                f"Position {pos} out of range [0, {len(self._execution_graph)}]"
            )
        old = self._current_position
        self._current_position = pos
        self._log.debug("position_updated", old=old, new=pos)

    def advance(self) -> bool:
        """Advance to the next position in the execution graph.

        Returns:
            True if advanced, False if already at the end.
        """
        if self._current_position >= len(self._execution_graph):
            return False
        self._current_position += 1
        return True

    def plan_next_step(self, current_position: Optional[int] = None) -> list[ChunkAddress]:
        """Get chunk addresses needed for the current execution step.

        Args:
            current_position: Override position (uses self._current_position if None).

        Returns:
            List of ChunkAddress needed for the layer at the given position.
        """
        pos = current_position if current_position is not None else self._current_position

        if pos < 0 or pos >= len(self._execution_graph):
            return []

        layer_name = self._execution_graph[pos]
        chunks = self._chunk_lookup.get(layer_name, [])

        self._log.debug(
            "plan_next_step",
            position=pos,
            layer_name=layer_name,
            num_chunks=len(chunks),
        )
        return chunks

    def peek_ahead(
        self,
        current_position: Optional[int] = None,
        k: Optional[int] = None,
    ) -> list[ChunkAddress]:
        """Get chunk addresses for future steps within the prefetch window.

        Does not include the current step's chunks (those come from
        plan_next_step).

        Args:
            current_position: Override position.
            k: Number of steps to look ahead. Uses prefetch_window if None.

        Returns:
            List of ChunkAddress for layers (current+1) through (current+k).
        """
        pos = current_position if current_position is not None else self._current_position
        window = k if k is not None else self._prefetch_window

        chunks: list[ChunkAddress] = []
        for i in range(1, window + 1):
            ahead_pos = pos + i
            if ahead_pos >= len(self._execution_graph):
                break
            layer_name = self._execution_graph[ahead_pos]
            layer_chunks = self._chunk_lookup.get(layer_name, [])
            chunks.extend(layer_chunks)

        self._log.debug(
            "peek_ahead",
            position=pos,
            window=window,
            chunks_found=len(chunks),
        )
        return chunks

    def get_priority(
        self,
        chunk_address: ChunkAddress,
        current_pos: Optional[int] = None,
    ) -> ChunkPriority:
        """Determine the priority of a chunk based on current position.

        Priority logic:
            - HIGH: chunk belongs to the current or next layer
            - LOW: chunk is within the prefetch window
            - BACKGROUND: chunk is beyond the prefetch window

        Args:
            chunk_address: The chunk to prioritize.
            current_pos: Override current position.

        Returns:
            ChunkPriority level.
        """
        pos = current_pos if current_pos is not None else self._current_position

        # Find which layer(s) this chunk belongs to
        for layer_idx, layer_name in enumerate(self._execution_graph):
            layer_chunks = self._chunk_lookup.get(layer_name, [])
            for addr in layer_chunks:
                if addr.chunk_id == chunk_address.chunk_id:
                    distance = layer_idx - pos
                    if distance <= 1:
                        return ChunkPriority.HIGH
                    elif distance <= self._prefetch_window:
                        return ChunkPriority.LOW
                    else:
                        return ChunkPriority.BACKGROUND

        return ChunkPriority.BACKGROUND

    def update_network_conditions(self, conditions: NetworkConditions) -> None:
        """Update network conditions and adapt prefetch window.

        When adaptive_window is enabled, the window is adjusted:
            - Increase window for good network (low latency, high bandwidth)
            - Decrease window for poor network

        Args:
            conditions: New network conditions.
        """
        self._network_conditions = conditions

        if self._adaptive_window:
            score = conditions.quality_score
            base = self._base_prefetch_window

            if score > 0.7:
                # Great network: increase window
                self._prefetch_window = min(base * 2, base + 8)
            elif score > 0.4:
                # Moderate network: use base window
                self._prefetch_window = base
            elif score > 0.2:
                # Poor network: reduce window
                self._prefetch_window = max(1, base // 2)
            else:
                # Terrible network: minimal window
                self._prefetch_window = 1

            self._log.info(
                "prefetch_window_adapted",
                network_quality=score,
                new_window=self._prefetch_window,
                base_window=base,
            )

    def get_metrics(self) -> SchedulingMetrics:
        """Compute and return scheduling metrics.

        Returns:
            SchedulingMetrics with current state information.
        """
        current_chunks = self.plan_next_step()
        ahead_chunks = self.peek_ahead()

        # Count priorities
        high = 0
        low = 0
        background = 0

        all_ahead = current_chunks + ahead_chunks
        for addr in all_ahead:
            p = self.get_priority(addr)
            if p == ChunkPriority.HIGH:
                high += 1
            elif p == ChunkPriority.LOW:
                low += 1
            else:
                background += 1

        return SchedulingMetrics(
            chunks_needed_current=len(current_chunks),
            chunks_needed_ahead=len(ahead_chunks),
            lookahead_depth=self._prefetch_window,
            current_position=self._current_position,
            total_positions=len(self._execution_graph),
            prefetch_window=self._prefetch_window,
            high_priority_count=high,
            low_priority_count=low,
            background_priority_count=background,
        )

    def get_remaining_layers(self) -> list[str]:
        """Return layers from current position to end of graph."""
        return self._execution_graph[self._current_position:]

    def get_completed_layers(self) -> list[str]:
        """Return layers that have been passed (before current position)."""
        return self._execution_graph[:self._current_position]

    def is_complete(self) -> bool:
        """Check if all layers have been executed."""
        return self._current_position >= len(self._execution_graph)

    def __repr__(self) -> str:
        return (
            f"Scheduler(position={self._current_position}/{len(self._execution_graph)}, "
            f"window={self._prefetch_window})"
        )


if __name__ == "__main__":
    from rex.core.types import ByteRange

    # === Build a simple execution scenario ===
    print("=== Scheduler Tests ===\n")

    execution_graph = [
        "layer_0.weight",
        "layer_0.bias",
        "layer_1.weight",
        "layer_1.bias",
        "layer_2.weight",
        "layer_2.bias",
    ]

    chunk_lookup: dict[str, list[ChunkAddress]] = {}
    for name in execution_graph:
        chunk_lookup[name] = [
            ChunkAddress(
                chunk_id=f"{name}.0",
                resource_id="model.bin",
                byte_range=ByteRange(start=0, end=1024),
            ),
        ]

    scheduler = Scheduler(
        execution_graph=execution_graph,
        chunk_lookup=chunk_lookup,
        prefetch_window=3,
        adaptive_window=True,
    )

    print(f"Scheduler: {scheduler}")

    # Plan current step
    current = scheduler.plan_next_step()
    assert len(current) == 1
    assert current[0].chunk_id == "layer_0.weight.0"
    print(f"Step 0 chunks: {[c.chunk_id for c in current]}")

    # Peek ahead
    ahead = scheduler.peek_ahead()
    print(f"Peek ahead: {[c.chunk_id for c in ahead]}")

    # Priorities
    for addr in ahead:
        p = scheduler.get_priority(addr)
        print(f"  {addr.chunk_id}: {p.value}")

    # Metrics
    metrics = scheduler.get_metrics()
    print(f"Metrics: chunks_needed={metrics.chunks_needed_current}, "
          f"ahead={metrics.chunks_needed_ahead}, "
          f"window={metrics.prefetch_window}")

    # Advance through the graph
    print("\nAdvancing through graph:")
    while not scheduler.is_complete():
        layer = scheduler.execution_graph[scheduler.current_position]
        metrics = scheduler.get_metrics()
        print(f"  pos={scheduler.current_position}: {layer} "
              f"(current={metrics.chunks_needed_current}, "
              f"ahead={metrics.chunks_needed_ahead})")
        scheduler.advance()

    print(f"  Execution complete at position {scheduler.current_position}")

    # Adaptive window
    print("\nAdaptive window test:")
    good_conditions = NetworkConditions(latency_ms=10, bandwidth_mbps=500)
    scheduler2 = Scheduler(
        execution_graph=execution_graph,
        chunk_lookup=chunk_lookup,
        prefetch_window=4,
        adaptive_window=True,
    )
    print(f"  Base window: {scheduler2.prefetch_window}")
    scheduler2.update_network_conditions(good_conditions)
    print(f"  After good network: {scheduler2.prefetch_window}")

    bad_conditions = NetworkConditions(latency_ms=800, bandwidth_mbps=1)
    scheduler2.update_network_conditions(bad_conditions)
    print(f"  After bad network: {scheduler2.prefetch_window}")

    # Error cases
    try:
        scheduler.set_position(-1)
    except SchedulerError as e:
        print(f"\nCaught expected error: {e}")

    try:
        Scheduler([], {})
    except SchedulerError as e:
        print(f"Caught expected error: {e}")

    print("\n=== All tests passed! ===")
