"""Graph-aware scheduling for Rex.

This scheduler implements a lightweight version of the memory-aware
topological algorithm from the redesign document. It computes a static order
up front using critical-path and miss-cost scoring, then delegates runtime
step tracking to the existing Scheduler interface.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Callable, Optional

from rex.core.cost_model import ChunkCostModel
from rex.core.graph_model import ExecutionDAG
from rex.core.scheduler import Scheduler
from rex.core.types import ChunkAddress


class GraphScheduler(Scheduler):
    """Memory-aware topological scheduler with Scheduler-compatible API."""

    def __init__(
        self,
        dag: ExecutionDAG,
        chunk_lookup: dict[str, list[ChunkAddress]],
        prefetch_window: int = 4,
        adaptive_window: bool = True,
        cost_model: Optional[ChunkCostModel] = None,
        cached_chunk_ids: Optional[Callable[[], set[str]]] = None,
        lambda_crit: float = 1.0,
        lambda_miss: float = 1.0,
        memory_budget_bytes: int = 0,
    ) -> None:
        self._dag = dag
        self._chunk_lookup = chunk_lookup
        self._cost_model = cost_model or ChunkCostModel()
        self._cached_chunk_ids = cached_chunk_ids or (lambda: set())
        self._lambda_crit = lambda_crit
        self._lambda_miss = lambda_miss
        self._memory_budget_bytes = memory_budget_bytes
        execution_graph = self._build_schedule()
        super().__init__(
            execution_graph=execution_graph,
            chunk_lookup=chunk_lookup,
            prefetch_window=prefetch_window,
            adaptive_window=adaptive_window,
        )

    @property
    def dag(self) -> ExecutionDAG:
        return self._dag

    def _critical_path_suffix(self) -> dict[str, float]:
        order = self._dag.topological_order()
        score: dict[str, float] = {}
        for node_name in reversed(order):
            node = self._dag.nodes[node_name]
            succ_scores = [score[succ] for succ in self._dag.successors(node_name)]
            score[node_name] = node.compute_cost_ms + (max(succ_scores) if succ_scores else 0.0)
        return score

    def _build_schedule(self) -> list[str]:
        indegree = {name: len(self._dag.predecessors(name)) for name in self._dag.nodes}
        ready = [name for name, degree in indegree.items() if degree == 0]
        next_ready: list[str] = []
        crit = self._critical_path_suffix()
        schedule: list[str] = []
        cached = set(self._cached_chunk_ids())

        while ready:
            scored: list[tuple[float, str]] = []
            for node_name in ready:
                node = self._dag.nodes[node_name]

                # Feasibility check: skip nodes that exceed the memory budget
                if self._memory_budget_bytes > 0:
                    chunk_size = self._cost_model.total_chunk_bytes(node.weight_chunk_ids)
                    if chunk_size > self._memory_budget_bytes:
                        continue

                miss_cost = self._cost_model.node_missing_cost_ms(
                    required_chunk_ids=node.weight_chunk_ids,
                    cached_chunk_ids=cached,
                )
                score = self._lambda_crit * crit.get(node_name, 0.0) - self._lambda_miss * miss_cost
                scored.append((score, node_name))

            if not scored:
                # No feasible nodes – fall back to scheduling everything
                for node_name in ready:
                    miss_cost = self._cost_model.node_missing_cost_ms(
                        required_chunk_ids=self._dag.nodes[node_name].weight_chunk_ids,
                        cached_chunk_ids=cached,
                    )
                    score = self._lambda_crit * crit.get(node_name, 0.0) - self._lambda_miss * miss_cost
                    scored.append((score, node_name))

            scored.sort(key=lambda item: (-item[0], item[1]))
            _, selected = scored[0]
            ready.remove(selected)
            schedule.append(selected)
            cached |= self._dag.nodes[selected].weight_chunk_ids

            for succ in self._dag.successors(selected):
                indegree[succ] -= 1
                if indegree[succ] == 0:
                    next_ready.append(succ)

            if not ready and next_ready:
                ready = next_ready
                next_ready = []

        return schedule

    def build_partitioned_schedule(
        self,
        cache_budget_bytes: int,
        chunk_size_lookup: dict[str, int],
    ) -> list[list[str]]:
        """Partition the execution schedule to reduce cross-partition cache reloads.

        Delegates to :meth:`ExecutionDAG.partition_by_cache_budget` using the
        scheduler's computed topological order as the base sequence.

        Args:
            cache_budget_bytes: Maximum unique-chunk bytes per partition.
            chunk_size_lookup: Mapping from chunk_id to byte size.

        Returns:
            List of partitions, each being a list of node names.
        """
        order = self._build_schedule()
        return self._dag.partition_by_cache_budget(
            cache_budget_bytes=cache_budget_bytes,
            chunk_size_lookup=chunk_size_lookup,
            order=order,
        )