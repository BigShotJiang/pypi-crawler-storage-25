"""
Execution engine for the Rex framework.

Orchestrates layer-by-layer inference with chunk management,
materialization, and comprehensive timing metrics.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import structlog

from rex.core.errors import ExecutionError, MaterializationError
from enum import Enum

from rex.core.types import (
    ChunkAddress,
    FetchResult,
    InferenceMetrics,
    TensorState,
)

logger = structlog.get_logger(__name__)


@dataclass
class LayerTiming:
    """Timing data for a single layer execution."""
    layer_name: str
    total_ms: float = 0.0
    materialize_ms: float = 0.0
    compute_ms: float = 0.0
    evict_ms: float = 0.0
    stall_ms: float = 0.0
    chunks_materialized: int = 0
    chunks_cache_hits: int = 0
    chunks_cache_misses: int = 0
    success: bool = True
    error: Optional[str] = None


@dataclass
class ModelLayer:
    """Represents a single executable layer with its parameter requirements."""
    name: str
    param_names: list[str] = field(default_factory=list)
    compute_fn: Optional[Callable[..., Any]] = None


class EvictionStrategy(Enum):
    """Strategy for evicting chunks after layer execution."""
    AGGRESSIVE = "aggressive"
    """Evict all chunks immediately after use (max memory savings, worst cache reuse)."""

    RETAIN_N_LAYERS = "retain_n_layers"
    """Keep chunks for the most recent N layers in cache (good warm performance)."""

    SMART = "smart"
    """Use lookahead to keep only chunks needed by upcoming layers."""

    NONE = "none"
    """Never evict (best warm performance, highest memory usage)."""


class SequentialExecutor:
    """Layer-by-layer sequential execution engine.

    For each layer in execution order:
        1. Ensure weight chunks are resident (materialize if needed).
        2. Run the layer computation.
        3. Evict/demote weights after execution (according to strategy).

    Tracks per-layer timing, stall time, cache interactions, and
    emits comprehensive InferenceMetrics.

    Args:
        cache: Memory cache for chunk data.
        prefetcher: Async prefetch engine (optional, for hinting).
        retry_max_attempts: Max retry attempts for failed chunk fetches.
        invariant_checker: Optional InvariantChecker for per-layer checks.
        eviction_strategy: How to manage chunks after layer execution.
            Defaults to RETAIN_N_LAYERS with retain_window=2.
        retain_window: Number of recent layers to keep in cache.
            Only used with RETAIN_N_LAYERS strategy.
    """

    def __init__(
        self,
        cache: Any,
        prefetcher: Optional[Any] = None,
        retry_max_attempts: int = 3,
        invariant_checker: Optional[Any] = None,
        eviction_strategy: EvictionStrategy = EvictionStrategy.RETAIN_N_LAYERS,
        retain_window: int = 2,
        cache_max_bytes: int = 0,
    ) -> None:
        self._cache = cache
        self._prefetcher = prefetcher
        self._retry_max = retry_max_attempts
        self._invariant_checker = invariant_checker
        self._eviction_strategy = eviction_strategy
        self._retain_window = retain_window
        self._cache_max_bytes = cache_max_bytes
        self._async_storage_fetch_func: Optional[Any] = None
        self._layer_timings: list[LayerTiming] = []
        self._recent_param_names: list[str] = []
        self._log = logger.bind(component="executor")

    async def execute(
        self,
        model_layers: list[ModelLayer],
        input_data: Any,
        scheduler: Any,
        chunk_index: Any,
        virtual_tensors: dict[str, Any],
        storage_fetch_func: Optional[Callable[[ChunkAddress], bytes]] = None,
    ) -> tuple[Any, InferenceMetrics]:
        """Execute inference through all model layers.

        Args:
            model_layers: Ordered list of ModelLayer to execute.
            input_data: Input tensor/data for the first layer.
            scheduler: Scheduler for chunk planning and priorities.
            chunk_index: ChunkIndex for chunk metadata lookup.
            virtual_tensors: Map of param_name -> VirtualTensor.
            storage_fetch_func: Optional async or sync function to fetch
                chunk data from remote storage.

        Returns:
            Tuple of (output_data, InferenceMetrics).

        Raises:
            ExecutionError: If a critical failure occurs during inference.
        """
        inference_start = time.monotonic()
        self._layer_timings.clear()

        metrics = InferenceMetrics()
        current_data = input_data
        peak_memory = 0

        self._log.info(
            "inference_start",
            total_layers=len(model_layers),
        )

        for layer_idx, layer in enumerate(model_layers):
            layer_start = time.monotonic()
            timing = LayerTiming(layer_name=layer.name)

            try:
                # Step 1: Ensure weight chunks are resident
                mat_start = time.monotonic()
                for param_name in layer.param_names:
                    vt = virtual_tensors.get(param_name)
                    if vt is None:
                        self._log.warning(
                            "missing_virtual_tensor",
                            param_name=param_name,
                        )
                        continue

                    # Check cache for each chunk
                    for addr in vt.chunk_addresses:
                        in_cache = await self._cache.contains(addr.chunk_id)
                        if in_cache:
                            timing.chunks_cache_hits += 1
                            metrics.cache_hits += 1
                        else:
                            timing.chunks_cache_misses += 1
                            metrics.cache_misses += 1

                            # Try to fetch and cache
                            stall_start = time.monotonic()
                            data = await self._fetch_chunk_with_retry(
                                addr, chunk_index, storage_fetch_func
                            )
                            stall_ms = (time.monotonic() - stall_start) * 1000
                            timing.stall_ms += stall_ms
                            metrics.stall_time_ms += stall_ms

                            if data is not None:
                                await self._cache.put(addr.chunk_id, data)
                                vt.store_chunk_data(addr.chunk_id, data)
                                metrics.chunks_fetched += 1
                                metrics.bytes_fetched_remote += len(data)

                    # Materialize the tensor if needed
                    if vt.state != TensorState.RESIDENT:
                        # Gather chunk data from cache
                        chunks_ready = all([
                            await self._cache.contains(addr.chunk_id)
                            for addr in vt.chunk_addresses
                        ])

                        if chunks_ready:
                            for addr in vt.chunk_addresses:
                                cached_data = await self._cache.get(addr.chunk_id)
                                if cached_data is not None:
                                    vt.store_chunk_data(addr.chunk_id, cached_data)

                            # Trigger state transition
                            if vt.state == TensorState.REMOTE:
                                from rex.core.errors import InvalidStateTransitionError
                                # Manual transition since we manage cache separately
                                pass  # VirtualTensor.materialize handles this

                            timing.chunks_materialized += vt.num_chunks

                timing.materialize_ms = (time.monotonic() - mat_start) * 1000

                # Step 2: Run layer computation
                compute_start = time.monotonic()

                if layer.compute_fn is not None:
                    # Gather materialized weights
                    weights = {}
                    for param_name in layer.param_names:
                        vt = virtual_tensors.get(param_name)
                        if vt is not None:
                            weights[param_name] = self._get_tensor_data(vt)

                    current_data = layer.compute_fn(current_data, weights)

                timing.compute_ms = (time.monotonic() - compute_start) * 1000
                metrics.layers_executed += 1

                # Step 3: Evict/demote weights after execution
                evict_start = time.monotonic()
                self._recent_param_names.extend(layer.param_names)

                for param_name in layer.param_names:
                    vt = virtual_tensors.get(param_name)
                    if vt is not None:
                        try:
                            if vt.is_resident:
                                vt.demote()
                        except Exception as exc:
                            self._log.warning(
                                "demote_error",
                                param_name=param_name,
                                error=str(exc),
                            )

                # Apply eviction strategy to cache
                await self._apply_eviction_strategy(
                    virtual_tensors, metrics
                )

                timing.evict_ms = (time.monotonic() - evict_start) * 1000

                # Update peak memory
                if hasattr(self._cache, "get_stats"):
                    stats = await self._cache.get_stats()
                    if stats.current_bytes > peak_memory:
                        peak_memory = stats.current_bytes

                # Advance scheduler
                scheduler.advance()

                # Step 4: Update backpressure on the prefetcher based
                # on the current cache fill fraction.
                await self._update_backpressure()

                # Step 5: Check cache invariant if checker is configured
                if self._invariant_checker is not None and hasattr(self._cache, "get_stats"):
                    try:
                        cache_stats = await self._cache.get_stats()
                        result = self._invariant_checker.check_invariant(
                            resident_bytes=0,
                            cached_bytes=cache_stats.current_bytes,
                            raise_on_violation=False,
                        )
                        if not result.is_valid:
                            metrics.invariant_violations += 1
                            self._log.warning(
                                "invariant_violation_detected",
                                layer=layer.name,
                                cached_bytes=cache_stats.current_bytes,
                                max_allowed=result.max_allowed_bytes,
                            )
                    except Exception as inv_exc:
                        self._log.warning(
                            "invariant_check_error",
                            layer=layer.name,
                            error=str(inv_exc),
                        )

            except Exception as exc:
                timing.success = False
                timing.error = str(exc)
                self._log.error(
                    "layer_execution_failed",
                    layer=layer.name,
                    error=str(exc),
                    exc_info=True,
                )
                # Continue to next layer or raise for critical failures
                if self._retry_max <= 0:
                    raise ExecutionError(
                        f"Layer '{layer.name}' failed: {exc}"
                    ) from exc

            timing.total_ms = (time.monotonic() - layer_start) * 1000
            self._layer_timings.append(timing)

            self._log.debug(
                "layer_completed",
                layer=layer.name,
                total_ms=round(timing.total_ms, 1),
                materialize_ms=round(timing.materialize_ms, 1),
                compute_ms=round(timing.compute_ms, 1),
            )

        # Compute final metrics
        total_time_ms = (time.monotonic() - inference_start) * 1000
        metrics.total_time_ms = total_time_ms
        metrics.compute_time_ms = sum(t.compute_ms for t in self._layer_timings)
        metrics.peak_memory_cache_bytes = peak_memory

        if self._prefetcher is not None:
            pf_metrics = self._prefetcher.emit_prefetch_metrics()
            metrics.prefetch_actions = pf_metrics.get("successful_fetches", 0)

        self._log.info(
            "inference_complete",
            total_ms=round(total_time_ms, 1),
            compute_ms=round(metrics.compute_time_ms, 1),
            stall_ms=round(metrics.stall_time_ms, 1),
            layers=metrics.layers_executed,
            cache_hits=metrics.cache_hits,
            cache_misses=metrics.cache_misses,
        )

        return current_data, metrics

    async def _fetch_chunk_with_retry(
        self,
        addr: ChunkAddress,
        chunk_index: Any,
        storage_fetch_func: Optional[Callable[[ChunkAddress], bytes]],
    ) -> Optional[bytes]:
        """Fetch a chunk with retry on transient failures.

        Args:
            addr: Chunk address to fetch.
            chunk_index: ChunkIndex for metadata.
            storage_fetch_func: Sync fetch callable (fallback).

        Returns:
            Chunk data bytes, or None if all retries failed.
        """
        last_error: Optional[str] = None

        for attempt in range(self._retry_max):
            if self._async_storage_fetch_func is not None:
                try:
                    data = await self._async_storage_fetch_func(addr)
                    if data is not None:
                        return data
                    last_error = "Async fetch returned None"
                except Exception as exc:
                    last_error = str(exc)
                    self._log.warning(
                        "async_chunk_fetch_failed",
                        chunk_id=addr.chunk_id,
                        attempt=attempt + 1,
                        error=str(exc),
                    )
            elif storage_fetch_func is not None:
                try:
                    data = storage_fetch_func(addr)
                    if data is not None:
                        return data
                    last_error = "Fetch returned None"
                except Exception as exc:
                    last_error = str(exc)
                    self._log.warning(
                        "chunk_fetch_failed",
                        chunk_id=addr.chunk_id,
                        attempt=attempt + 1,
                        error=str(exc),
                    )
            else:
                self._log.warning(
                    "no_storage_fetch_func",
                    chunk_id=addr.chunk_id,
                )
                return None

        self._log.error(
            "chunk_fetch_exhausted_retries",
            chunk_id=addr.chunk_id,
            last_error=last_error,
        )
        return None

    def _get_tensor_data(self, vt: Any) -> Any:
        """Get assembled tensor data from a VirtualTensor."""
        import numpy as np
        from rex.convert.quantize import dequantize_tensor_from_bytes

        chunks = []
        for addr in vt.chunk_addresses:
            data = vt._chunk_data.get(addr.chunk_id)
            if data is not None:
                chunks.append(data)

        if not chunks:
            return None

        raw_bytes = b"".join(chunks)

        if getattr(vt, "quantization", None):
            return dequantize_tensor_from_bytes(
                raw_bytes,
                vt.quantization,
                vt.shape,
            )

        dtype_map = {
            "float32": np.float32,
            "float64": np.float64,
            "float16": np.float16,
            "bfloat16": np.float32,
            "int32": np.int32,
            "int64": np.int64,
            "int16": np.int16,
            "int8": np.int8,
            "uint8": np.uint8,
            "uint32": np.uint32,
            "<u4": np.uint32,
        }
        dtype = dtype_map.get(vt.dtype, np.float32)
        flat = np.frombuffer(raw_bytes, dtype=dtype)
        return flat.reshape(vt.shape)

    async def _apply_eviction_strategy(
        self,
        virtual_tensors: dict[str, Any],
        metrics: InferenceMetrics,
    ) -> None:
        """Evict chunks from cache according to the configured strategy.

        Args:
            virtual_tensors: Map of param_name -> VirtualTensor.
            metrics: InferenceMetrics to update with eviction counts.
        """
        if self._eviction_strategy == EvictionStrategy.NONE:
            return

        if self._eviction_strategy == EvictionStrategy.AGGRESSIVE:
            # Evict everything except current layer
            params_to_keep = set()
            for name in self._recent_param_names:
                # Keep nothing in aggressive mode
                pass
            await self._evict_params_not_in(
                params_to_keep, virtual_tensors, metrics
            )
            return

        if self._eviction_strategy == EvictionStrategy.RETAIN_N_LAYERS:
            # Keep chunks for the most recent N layers
            cutoff = max(
                0, len(self._recent_param_names) - self._retain_window * 3
            )
            params_to_keep = set(self._recent_param_names[cutoff:])
            await self._evict_params_not_in(
                params_to_keep, virtual_tensors, metrics
            )
            return

        if self._eviction_strategy == EvictionStrategy.SMART:
            # Keep only chunks that appear in the upcoming execution graph
            # (handled externally via prefetch hints)
            # For now, behave like RETAIN_N_LAYERS with window=1
            cutoff = max(
                0, len(self._recent_param_names) - self._retain_window * 2
            )
            params_to_keep = set(self._recent_param_names[cutoff:])
            await self._evict_params_not_in(
                params_to_keep, virtual_tensors, metrics
            )
            return

    async def _evict_params_not_in(
        self,
        params_to_keep: set[str],
        virtual_tensors: dict[str, Any],
        metrics: InferenceMetrics,
    ) -> None:
        """Evict cache entries for params not in the keep set.

        Args:
            params_to_keep: Set of parameter names to retain.
            virtual_tensors: Map of param_name -> VirtualTensor.
            metrics: InferenceMetrics to update.
        """
        for param_name, vt in virtual_tensors.items():
            if param_name in params_to_keep:
                continue
            for addr in vt.chunk_addresses:
                evicted = await self._cache.evict(addr.chunk_id)
                if evicted:
                    metrics.eviction_count += 1

    async def _update_backpressure(self) -> None:
        """Check current cache fill and signal the prefetcher.

        After each layer execution the cache may have grown (new chunks
        materialised) or shrunk (eviction policy ran).  Computing the
        fill fraction here keeps the prefetcher's backpressure state
        in sync without an extra background task.
        """
        if (
            self._prefetcher is None
            or not hasattr(self._cache, "get_stats")
            or self._cache_max_bytes <= 0
        ):
            return
        try:
            stats = await self._cache.get_stats()
            fill = stats.current_bytes / self._cache_max_bytes if self._cache_max_bytes > 0 else 0.0
            self._prefetcher.update_backpressure(fill)
        except Exception as exc:
            self._log.debug("backpressure_update_error", error=str(exc))

    def get_layer_timings(self) -> list[LayerTiming]:
        """Return per-layer timing data from the last execution."""
        return list(self._layer_timings)

    def get_timing_summary(self) -> str:
        """Produce a human-readable timing summary."""
        lines: list[str] = ["Layer Execution Timings:"]
        lines.append(f"  {'Layer':<30} {'Total':>8} {'Mat':>8} {'Comp':>8} {'Evict':>8}")
        lines.append("  " + "-" * 66)

        for t in self._layer_timings:
            status = "" if t.success else " [FAILED]"
            lines.append(
                f"  {t.layer_name:<30} {t.total_ms:>7.1f}ms "
                f"{t.materialize_ms:>7.1f}ms {t.compute_ms:>7.1f}ms "
                f"{t.evict_ms:>7.1f}ms{status}"
            )

        return "\n".join(lines)


if __name__ == "__main__":
    import asyncio
    import numpy as np
    from rex.core.virtual_tensor import VirtualTensor
    from rex.cache.memory_cache import MemoryCache
    from rex.core.scheduler import Scheduler
    from rex.core.chunk_index import ChunkIndex
    from rex.core.types import ByteRange, ChunkAddress, TensorDescriptor

    async def _demo() -> None:
        print("=== SequentialExecutor Demo ===\n")

        # Build a simple 2-layer model
        import hashlib
        layer_names = ["layer_0.weight", "layer_0.bias", "layer_1.weight"]
        execution_graph = layer_names

        # Create chunk addresses and virtual tensors
        chunk_lookup: dict[str, list[ChunkAddress]] = {}
        virtual_tensors: dict[str, VirtualTensor] = {}

        for name in layer_names:
            addr = ChunkAddress(
                chunk_id=f"{name}.0",
                resource_id="model.bin",
                byte_range=ByteRange(start=0, end=1024),
            )
            chunk_lookup[name] = [addr]

            shape = (4, 4) if "weight" in name else (4,)
            vt = VirtualTensor(name=name, shape=shape, dtype="float32", chunk_addresses=[addr])
            virtual_tensors[name] = vt

        # Pre-populate chunk data
        for name, vt in virtual_tensors.items():
            dummy = np.zeros(vt.shape, dtype=np.float32).tobytes()
            vt.store_chunk_data(f"{name}.0", dummy)

        # Create components
        cache = MemoryCache(max_bytes=10 * 1024 * 1024)
        scheduler = Scheduler(execution_graph=execution_graph, chunk_lookup=chunk_lookup, prefetch_window=2)

        # Build model layers with simple compute functions
        def make_compute(layer_name: str):
            def compute_fn(input_data, weights):
                # Simple passthrough for demo
                return input_data
            return compute_fn

        model_layers = [
            ModelLayer(name="layer_0", param_names=["layer_0.weight", "layer_0.bias"], compute_fn=make_compute("layer_0")),
            ModelLayer(name="layer_1", param_names=["layer_1.weight"], compute_fn=make_compute("layer_1")),
        ]

        executor = SequentialExecutor(cache=cache, retry_max_attempts=1)

        # Execute
        input_data = np.zeros((1, 4), dtype=np.float32)
        output, metrics = await executor.execute(
            model_layers=model_layers,
            input_data=input_data,
            scheduler=scheduler,
            chunk_index=ChunkIndex(),
            virtual_tensors=virtual_tensors,
        )

        print(f"Layers executed: {metrics.layers_executed}")
        print(f"Total time: {metrics.total_time_ms:.1f}ms")
        print(f"\n{executor.get_timing_summary()}")

    asyncio.run(_demo())
    print("\n=== Demo completed! ===")
