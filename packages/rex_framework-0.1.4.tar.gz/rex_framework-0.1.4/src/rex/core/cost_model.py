"""Cost model utilities for graph-aware Rex planning.

These helpers are pure and side-effect-free so they can be reused by
schedulers, cache policies, and offline analysis tools.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ChunkCostModel:
    """Container for chunk-level latency/decode/size estimates."""

    latency_ms: dict[str, float] = field(default_factory=dict)
    decode_ms: dict[str, float] = field(default_factory=dict)
    size_bytes: dict[str, int] = field(default_factory=dict)
    default_latency_ms: float = 50.0
    default_decode_ms: float = 0.0

    def missing_cost_ms(self, chunk_id: str) -> float:
        """Expected miss cost (fetch + decode) for a chunk."""
        return self.latency_ms.get(chunk_id, self.default_latency_ms) + self.decode_ms.get(
            chunk_id, self.default_decode_ms
        )

    def node_missing_cost_ms(
        self,
        required_chunk_ids: set[str],
        cached_chunk_ids: set[str],
    ) -> float:
        """Total miss cost for required chunks that are not already cached."""
        return sum(self.missing_cost_ms(cid) for cid in required_chunk_ids if cid not in cached_chunk_ids)

    def expected_eviction_cost(self, chunk_id: str, reuse_probability: float) -> float:
        """Expected future cost if the chunk is evicted now."""
        p = min(1.0, max(0.0, reuse_probability))
        return p * self.missing_cost_ms(chunk_id)

    def value_density(self, chunk_id: str, reuse_probability: float) -> float:
        """Expected eviction cost per byte for eviction ranking."""
        size = max(1, self.size_bytes.get(chunk_id, 1))
        return self.expected_eviction_cost(chunk_id, reuse_probability) / size

    def total_chunk_bytes(self, chunk_ids: set[str]) -> int:
        """Total byte size for a set of chunk IDs."""
        return sum(self.size_bytes.get(cid, 0) for cid in chunk_ids)


def prefetch_utility(probability: float, estimated_latency_ms: float) -> float:
    """Utility proxy for prioritizing prefetch candidates.

    Uses probability-to-latency ratio as a simple score.
    """
    p = min(1.0, max(0.0, probability))
    denom = max(1e-6, estimated_latency_ms)
    return p / denom
