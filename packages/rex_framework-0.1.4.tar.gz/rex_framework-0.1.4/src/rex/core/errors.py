"""
Error definitions for the Rex framework.

Status: Implemented
"""

from __future__ import annotations

from typing import Any, Optional


class RexError(Exception):
    """Base exception for all Rex framework errors."""

    def __init__(self, message: str, *, details: Optional[dict[str, Any]] = None) -> None:
        super().__init__(message)
        self.details = details or {}


# ── Storage Errors ──────────────────────────────────────────────────────────

class StorageError(RexError):
    """Base class for storage backend errors."""


class FetchError(StorageError):
    """Failed to fetch a chunk from remote storage."""

    def __init__(
        self,
        chunk_id: str,
        resource_id: str,
        status_code: Optional[int] = None,
        *,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        self.chunk_id = chunk_id
        self.resource_id = resource_id
        self.status_code = status_code
        msg = f"Failed to fetch chunk '{chunk_id}' from resource '{resource_id}'"
        if status_code is not None:
            msg += f" (HTTP {status_code})"
        super().__init__(msg, details=details)


class StorageUnavailableError(StorageError):
    """The storage backend is not reachable or healthy."""


class AuthenticationError(StorageError):
    """Storage backend authentication failed."""


class RateLimitError(StorageError):
    """Storage backend rate limit has been exceeded.

    Attributes:
        retry_after_seconds: Suggested wait time before retrying.
    """
    def __init__(self, message: str, retry_after_seconds: float = 0.0) -> None:
        super().__init__(message, details={"retry_after_seconds": retry_after_seconds})
        self.retry_after_seconds = retry_after_seconds


class UnsupportedBackendError(StorageError):
    """The requested storage backend is not implemented or not supported."""

    def __init__(self, backend_name: str, reason: str = "") -> None:
        msg = f"Backend '{backend_name}' is not supported"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class ChunkIntegrityError(StorageError):
    """Checksum verification failed for a fetched chunk."""

    def __init__(self, chunk_id: str, expected: str, actual: str) -> None:
        self.chunk_id = chunk_id
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"Checksum mismatch for chunk '{chunk_id}': "
            f"expected {expected[:16]}..., got {actual[:16]}..."
        )


# ── Cache Errors ────────────────────────────────────────────────────────────

class CacheError(RexError):
    """Base class for cache-related errors."""


class CacheOverflowError(CacheError):
    """Insertion would violate cache capacity constraints."""


class InvariantViolationError(CacheError):
    """The 'no full model local' invariant has been violated.

    This is a critical error that should never occur in production if the
    cache eviction policy is functioning correctly.
    """

    def __init__(
        self,
        resident_bytes: int,
        model_bytes: int,
        fraction: float,
        max_fraction: float,
    ) -> None:
        self.resident_bytes = resident_bytes
        self.model_bytes = model_bytes
        self.fraction = fraction
        self.max_fraction = max_fraction
        super().__init__(
            f"Cache invariant violated: {resident_bytes} bytes resident "
            f"({fraction:.1%} of {model_bytes} byte model) "
            f"exceeds max fraction {max_fraction:.1%}"
        )


class InvalidStateTransitionError(RexError):
    """Attempted an illegal VirtualTensor state transition."""

    def __init__(self, chunk_id: str, current: str, target: str) -> None:
        super().__init__(
            f"Invalid state transition for chunk '{chunk_id}': "
            f"{current} -> {target}"
        )


# ── Manifest / Format Errors ────────────────────────────────────────────────

class ManifestError(RexError):
    """Error in manifest parsing or validation."""


class ManifestVersionError(ManifestError):
    """Unsupported or incompatible manifest version."""


class ManifestValidationError(ManifestError):
    """Manifest failed schema validation."""


# ── Conversion Errors ───────────────────────────────────────────────────────

class ConversionError(RexError):
    """Error during model conversion to Rex format."""


class UnsupportedModelError(ConversionError):
    """The given model architecture is not supported for conversion."""


# ── Execution Errors ────────────────────────────────────────────────────────

class ExecutionError(RexError):
    """Error during model execution / inference."""


class SchedulerError(ExecutionError):
    """Error in the scheduler component."""


class MaterializationError(ExecutionError):
    """Failed to materialize a virtual tensor into a physical tensor."""
