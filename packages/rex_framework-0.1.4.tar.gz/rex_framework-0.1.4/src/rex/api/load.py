"""Public API for loading Rex models.

Status: Implemented

Provides the rex.load_model() entry point.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

from rex.api.config import RexConfig
from rex.core.runtime import RexRuntime
from rex.formats.manifest import load_manifest


def load_model(
    manifest_path: str,
    config: Optional[RexConfig] = None,
    **kwargs,
) -> RexRuntime:
    """Load a Rex model from a manifest file.

    This loads only the manifest (small metadata file). Model weights
    are NOT downloaded; they remain on remote storage and are fetched
    on demand during inference.

    Args:
        manifest_path: Path to the manifest.json file.
        config: Optional RexConfig. If None, uses defaults.
        **kwargs: Override config fields (e.g., storage_url="http://...").

    Returns:
        RexRuntime instance ready for inference.

    Raises:
        FileNotFoundError: If manifest file does not exist.
        ManifestValidationError: If manifest is invalid.

    Example:
        runtime = rex.load_model("./rex_model/manifest.json")
        result = runtime.run_inference(input_tensor)
    """
    if config is None:
        config = RexConfig()

    # Apply kwargs overrides
    for key, value in kwargs.items():
        if key == "storage_url" and value:
            config.storage.base_url = value
        elif key == "cache_size_mb" and value:
            config.cache.max_memory_cache_bytes = int(value) * 1024 * 1024
        elif key == "auth_token" and value:
            config.storage.auth_token = value

    # Validate local manifest paths early; URL loading is handled by runtime.
    if not (manifest_path.startswith("http://") or manifest_path.startswith("https://")):
        _ = load_manifest(manifest_path)
        if not config.storage.base_url:
            config.storage.base_url = str(Path(manifest_path).parent)

    runtime = RexRuntime(config=config)

    async def _load() -> None:
        await runtime.load_model(manifest_path)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor() as pool:
            pool.submit(asyncio.run, _load()).result()
    else:
        asyncio.run(_load())

    return runtime


def inspect_manifest(manifest_path: str) -> str:
    """Load and pretty-print a Rex manifest.

    Args:
        manifest_path: Path to manifest.json.

    Returns:
        Human-readable manifest summary.
    """
    from rex.formats.manifest import pretty_print_manifest
    manifest = load_manifest(manifest_path)
    return pretty_print_manifest(manifest)


def validate_model(manifest_path: str) -> list[str]:
    """Validate a Rex manifest and return errors.

    Args:
        manifest_path: Path to manifest.json.

    Returns:
        List of validation error strings. Empty if valid.
    """
    from rex.formats.manifest import validate_manifest, load_manifest
    try:
        manifest = load_manifest(manifest_path)
    except Exception as e:
        return [f"Failed to load manifest: {e}"]

    return validate_manifest(manifest)
