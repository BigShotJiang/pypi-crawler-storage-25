"""
Configuration for the Rex runtime.

Status: Implemented
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Optional

from rex.core.types import (
    CachePolicyName,
    CompressionCodec,
    StorageBackendType,
)


@dataclass
class StorageConfig:
    """Configuration for the remote storage backend."""
    backend_type: StorageBackendType = StorageBackendType.HTTP_RANGE
    base_url: str = ""
    """Base URL or resource path for the HTTP range storage backend."""

    auth_token: Optional[str] = None
    """Bearer token for authenticated storage. Prefer env var REX_AUTH_TOKEN."""

    request_timeout_seconds: float = 30.0
    retry_max_attempts: int = 3
    retry_base_delay_seconds: float = 1.0
    retry_max_delay_seconds: float = 30.0
    max_concurrent_fetches: int = 4
    respect_rate_limits: bool = True
    adaptive_concurrency: bool = True
    """Dynamically adjust IO concurrency using Little's Law approximation."""


@dataclass
class CacheConfig:
    """Configuration for the caching subsystem."""
    policy: CachePolicyName = CachePolicyName.LRU
    max_memory_cache_bytes: int = 0
    """Max bytes for memory cache. 0 = auto (40% of model size)."""

    max_disk_cache_bytes: int = 0
    """Max bytes for disk cache. 0 = disabled."""

    disk_cache_path: str = ".rex_cache"
    max_local_fraction_of_model: float = 0.4
    """Hard cap: at most this fraction of the model may be cached locally."""

    enforce_invariant: bool = True
    weighted_alpha: float = 0.5
    weighted_beta: float = 0.3
    weighted_gamma: float = 0.2
    confidence_threshold: float = 0.2
    """Confidence level below which LRU blending is applied for stochastic eviction."""

    tier_control_policy: str = "frequency"
    """Policy for promoting entries between cache tiers: 'frequency', 'always', 'never'."""

    tier_control_min_accesses: int = 2
    """Minimum access count required for frequency-based tier promotion."""


@dataclass
class SchedulerConfig:
    """Configuration for the scheduler and prefetcher."""
    prefetch_window: int = 4
    """Number of future layers to prefetch ahead of current execution."""

    adaptive_window: bool = True
    """Dynamically adjust prefetch window based on network conditions."""

    enable_prefetch: bool = True
    prefetch_priority_decay: float = 0.1
    eviction_strategy: str = "retain_n_layers"
    """Eviction strategy: 'aggressive', 'retain_n_layers', 'smart', 'none'."""

    retain_window: int = 2
    """Number of recent layers to keep in cache (for retain_n_layers strategy)."""

    scheduler_mode: str = "graph"
    """Planning mode: 'graph' (default) or 'sequential'."""

    build_execution_dag_metadata: bool = True
    """Whether to build ExecutionDAG metadata during model load."""

    enable_graph_partitioning: bool = True
    """Partition execution graph to reduce cross-partition cache reloads."""

    graph_partition_budget_bytes: int = 0
    """Per-partition byte budget. 0 = auto-derived from cache size."""

    prefetch_horizon: int = 4
    """Prediction horizon for prefetch probability decay."""

    max_prefetch_queue_depth: int = 0
    """Max items in prefetch queue before low-priority items are dropped. 0 = unlimited."""

    enable_moe_priors: bool = True
    """Use MoE routing probabilities to prefetch top-k expert chunks."""

    enable_attention_priors: bool = True
    """Boost prefetch probability for attention heads within locality window."""


@dataclass
class ObservabilityConfig:
    """Configuration for logging, tracing, and metrics."""
    log_level: str = "INFO"
    log_format: str = "console"
    """'console', 'json', or 'quiet'."""

    enable_tracing: bool = True
    trace_export_path: Optional[str] = None
    redact_secrets: bool = True


@dataclass
class RexConfig:
    """Top-level configuration for the Rex runtime.

    Configuration is resolved from (in order of priority):
    1. Explicit constructor arguments
    2. Environment variables (REX_*)
    3. Built-in defaults

    Environment variables:
        REX_STORAGE_BACKEND   - StorageBackendType value
        REX_STORAGE_URL       - Base URL for storage
        REX_AUTH_TOKEN        - Authentication token
        REX_CACHE_SIZE_MB     - Memory cache size in MB
        REX_CACHE_POLICY      - CachePolicyName value
        REX_PREFETCH_WINDOW   - Look-ahead window size
        REX_LOG_LEVEL         - Logging level
        REX_MAX_LOCAL_FRAC    - Max local fraction of model (0.0-1.0)
    """
    storage: StorageConfig = field(default_factory=StorageConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    observability: ObservabilityConfig = field(default_factory=ObservabilityConfig)
    debug: bool = False

    def __post_init__(self) -> None:
        self._apply_env_overrides()

    def _apply_env_overrides(self) -> None:
        """Apply environment variable overrides to configuration."""
        env = os.environ

        if v := env.get("REX_STORAGE_BACKEND"):
            try:
                self.storage.backend_type = StorageBackendType(v)
            except ValueError:
                pass  # Invalid env value; keep default

        if v := env.get("REX_STORAGE_URL"):
            self.storage.base_url = v

        if v := env.get("REX_AUTH_TOKEN"):
            self.storage.auth_token = v

        if v := env.get("REX_CACHE_SIZE_MB"):
            try:
                self.cache.max_memory_cache_bytes = int(v) * 1024 * 1024
            except ValueError:
                pass

        if v := env.get("REX_CACHE_POLICY"):
            try:
                self.cache.policy = CachePolicyName(v)
            except ValueError:
                pass

        if v := env.get("REX_PREFETCH_WINDOW"):
            try:
                self.scheduler.prefetch_window = int(v)
            except ValueError:
                pass

        if v := env.get("REX_LOG_LEVEL"):
            self.observability.log_level = v.upper()

        if v := env.get("REX_MAX_LOCAL_FRAC"):
            try:
                frac = float(v)
                if 0.0 < frac <= 1.0:
                    self.cache.max_local_fraction_of_model = frac
            except ValueError:
                pass

        if v := env.get("REX_DEBUG"):
            self.debug = v.lower() in ("1", "true", "yes")

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> RexConfig:
        """Create config from a flat or nested dictionary."""
        config = cls()
        for key, value in d.items():
            if key.startswith("storage_"):
                setattr(config.storage, key[8:], value)
            elif key.startswith("cache_"):
                setattr(config.cache, key[6:], value)
            elif key.startswith("scheduler_"):
                setattr(config.scheduler, key[10:], value)
            elif key.startswith("observability_"):
                setattr(config.observability, key[14:], value)
            else:
                setattr(config, key, value)
        return config

    def to_dict(self) -> dict[str, Any]:
        """Serialize config to dictionary."""
        from dataclasses import asdict
        return asdict(self)
