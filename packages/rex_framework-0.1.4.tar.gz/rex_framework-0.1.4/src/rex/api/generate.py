"""Public API for running Rex inference.

Status: Implemented

Provides the rex.run_inference() entry point.
"""

from __future__ import annotations

from typing import Any, Optional, Union

from rex.api.config import RexConfig
from rex.api.load import load_model
from rex.core.runtime import RexRuntime
from rex.core.types import InferenceMetrics


async def run_inference(
    runtime: RexRuntime,
    input_data: Any,
) -> tuple[Any, InferenceMetrics]:
    """Run inference on a loaded Rex model.

    Args:
        runtime: RexRuntime instance from load_model().
        input_data: Input tensor or data for the model.

    Returns:
        Tuple of (model_output, inference_metrics).

    Example:
        runtime = rex.load_model("./rex_model/manifest.json")
        output, metrics = await rex.run_inference(runtime, input_tensor)
        print(f"Cache hits: {metrics.cache_hits}, misses: {metrics.cache_misses}")
    """
    return await runtime.run_inference(input_data)


def run_inference_sync(
    manifest_path: str,
    input_data: Any,
    config: Optional[RexConfig] = None,
    **kwargs,
) -> tuple[Any, InferenceMetrics]:
    """Synchronous wrapper for running inference.

    Convenience function that loads a model and runs inference in one call.

    Args:
        manifest_path: Path to manifest.json.
        input_data: Input tensor.
        config: Optional RexConfig.
        **kwargs: Additional config overrides.

    Returns:
        Tuple of (model_output, inference_metrics).

    Example:
        output, metrics = rex.run_inference_sync(
            "./rex_model/manifest.json", input_tensor
        )
    """
    import asyncio

    runtime = load_model(manifest_path, config, **kwargs)

    async def _run():
        return await runtime.run_inference(input_data)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return pool.submit(asyncio.run, _run()).result()
    else:
        return asyncio.run(_run())
