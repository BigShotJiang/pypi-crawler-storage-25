"""Tensor partitioning utilities.

Status: Implemented

Splits tensors into fixed-size chunks for Rex storage.
"""

from __future__ import annotations

from typing import Optional


def compute_num_chunks(total_bytes: int, chunk_size_bytes: int) -> int:
    """Compute the number of chunks needed for a given tensor size.

    Always returns at least 1 for non-empty tensors.
    """
    if total_bytes <= 0:
        return 0
    return max(1, (total_bytes + chunk_size_bytes - 1) // chunk_size_bytes)


def compute_chunk_byte_ranges(
    total_bytes: int,
    chunk_size_bytes: int,
) -> list[tuple[int, int]]:
    """Compute (start, end) byte ranges for each chunk.

    Returns a list of half-open [start, end) ranges.
    """
    if total_bytes <= 0:
        return []

    ranges = []
    offset = 0
    while offset < total_bytes:
        end = min(offset + chunk_size_bytes, total_bytes)
        ranges.append((offset, end))
        offset = end
    return ranges


def compute_element_ranges(
    total_elements: int,
    chunk_size_elements: int,
) -> list[tuple[int, int]]:
    """Compute (start, end) element index ranges for each chunk.

    Used when chunking by number of elements rather than bytes.
    """
    return compute_chunk_byte_ranges(total_elements, chunk_size_elements)


def recommend_chunk_size(
    model_size_bytes: int,
    target_num_chunks: int = 100,
    min_chunk_bytes: int = 65536,
    max_chunk_bytes: int = 4_194_304,
) -> int:
    """Recommend a chunk size based on model size.

    Aims for approximately target_num_chunks total, clamped to
    [min_chunk_bytes, max_chunk_bytes].

    Args:
        model_size_bytes: Total model size in bytes.
        target_num_chunks: Desired number of chunks.
        min_chunk_bytes: Minimum chunk size (64 KB).
        max_chunk_bytes: Maximum chunk size (4 MB).

    Returns:
        Recommended chunk size in bytes.
    """
    if model_size_bytes <= 0:
        return min_chunk_bytes

    recommended = model_size_bytes // target_num_chunks
    return max(min_chunk_bytes, min(max_chunk_bytes, recommended))
