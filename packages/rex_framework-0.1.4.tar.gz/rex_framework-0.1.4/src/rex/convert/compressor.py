"""Compression utilities for the conversion pipeline.

Status: Implemented

Thin wrapper around rex.formats.compression for converter-specific use.
"""

from __future__ import annotations

from rex.core.types import CompressionCodec
from rex.formats.compression import compress, decompress, compression_ratio


def compress_chunk(data: bytes, codec: CompressionCodec) -> bytes:
    """Compress a chunk of tensor data."""
    return compress(data, codec)


def decompress_chunk(data: bytes) -> tuple[bytes, CompressionCodec]:
    """Decompress a chunk, auto-detecting codec."""
    return decompress(data)


def estimate_compression_ratio(
    sample_data: bytes,
    codec: CompressionCodec,
) -> float:
    """Estimate compression ratio for a data sample.

    Returns original_size / compressed_size.
    """
    compressed = compress(sample_data, codec)
    return compression_ratio(len(sample_data), len(compressed))
