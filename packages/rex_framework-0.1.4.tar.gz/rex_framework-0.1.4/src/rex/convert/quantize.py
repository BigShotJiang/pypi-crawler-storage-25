"""Quantization utilities for Rex chunks.

Status: Implemented

Provides a small, deterministic quantization path that can be used by the
converter and runtime. The current implementation supports symmetric uniform
INT8/INT4/INT2 quantization with optional packed byte serialization for the
sub-byte modes.
"""

from __future__ import annotations

from typing import Any

import numpy as np

class QuantizeError(Exception):
    """Error during quantization."""


def _supported_float_dtypes() -> tuple[Any, ...]:
    dtypes: list[Any] = [np.float32, np.float16]
    if hasattr(np, "bfloat16"):
        dtypes.append(np.bfloat16)
    return tuple(dtypes)


def _pack_low_bit_values(values: np.ndarray, bits: int) -> bytes:
    if bits >= 8:
        return values.astype(np.int8, copy=False).tobytes()

    values_u8 = values.astype(np.uint8, copy=False).ravel()
    mask = (1 << bits) - 1
    packed = bytearray()
    buffer = 0
    buffered_bits = 0

    for value in values_u8:
        buffer |= (int(value) & mask) << buffered_bits
        buffered_bits += bits
        while buffered_bits >= 8:
            packed.append(buffer & 0xFF)
            buffer >>= 8
            buffered_bits -= 8

    if buffered_bits > 0:
        packed.append(buffer & 0xFF)

    return bytes(packed)


def _unpack_low_bit_values(data: bytes, bits: int, count: int) -> np.ndarray:
    if bits >= 8:
        return np.frombuffer(data, dtype=np.int8, count=count)

    mask = (1 << bits) - 1
    values = np.empty(count, dtype=np.uint8)
    buffer = 0
    buffered_bits = 0
    idx = 0

    for raw in data:
        buffer |= int(raw) << buffered_bits
        buffered_bits += 8
        while buffered_bits >= bits and idx < count:
            values[idx] = buffer & mask
            buffer >>= bits
            buffered_bits -= bits
            idx += 1

    if idx != count:
        raise QuantizeError(
            f"Packed tensor decode produced {idx} values, expected {count}"
        )

    return values


def quantize_tensor(
    array: np.ndarray,
    bits: int = 8,
) -> tuple[np.ndarray, dict]:
    """Quantize a tensor to lower precision.

    Uses symmetric uniform quantization: maps values to [-2^(bits-1), 2^(bits-1)-1].

    Args:
        array: Input float32/float16 array.
        bits: Target bit width (8 or 4).

    Returns:
        Tuple of (quantized_array, metadata_dict).
        Metadata contains scale, zero_point, original_dtype, original_shape.

    Raises:
        QuantizeError: If quantization fails.
    """
    if bits not in (8, 4, 2):
        raise QuantizeError(f"Unsupported bit width: {bits}. Supported: 8, 4, 2")

    if array.dtype not in _supported_float_dtypes():
        array = array.astype(np.float32)

    original_dtype = str(array.dtype)

    abs_max = np.max(np.abs(array))
    qmin = -(2 ** (bits - 1))
    qmax = 2 ** (bits - 1) - 1

    if abs_max == 0:
        quantized = np.zeros_like(array, dtype=np.int8 if bits == 8 else np.uint8)
        return quantized, {
            "scale": 0.0,
            "zero_point": 0,
            "original_dtype": original_dtype,
            "bits": bits,
            "packed": bits < 8,
            "num_values": int(array.size),
            "qmin": qmin,
            "scheme": "symmetric_uniform",
        }

    scale = abs_max / max(abs(qmin), abs(qmax))
    raw = np.round(array.astype(np.float32) / scale)
    raw = np.clip(raw, qmin, qmax)

    if bits == 8:
        quantized = raw.astype(np.int8)
    else:
        quantized = (raw.astype(np.int16) - qmin).astype(np.uint8)

    return quantized, {
        "scale": float(scale),
        "zero_point": 0,
        "original_dtype": original_dtype,
        "bits": bits,
        "packed": bits < 8,
        "num_values": int(array.size),
        "qmin": qmin,
        "scheme": "symmetric_uniform",
    }


def dequantize_tensor(
    quantized: np.ndarray,
    metadata: dict,
) -> np.ndarray:
    """Dequantize a tensor back to float32.

    Args:
        quantized: Quantized integer array.
        metadata: Dict with scale, zero_point, original_dtype.

    Returns:
        Dequantized float32 array.
    """
    scale = metadata["scale"]
    bits = int(metadata.get("bits", 8))
    qmin = int(metadata.get("qmin", -(2 ** (bits - 1))))
    zero_point = metadata.get("zero_point", 0)

    if bits < 8:
        values = quantized.astype(np.int16) + qmin
        return values.astype(np.float32) * scale

    return (quantized.astype(np.float32) - zero_point) * scale


def quantize_tensor_to_bytes(
    array: np.ndarray,
    bits: int = 8,
) -> tuple[bytes, dict[str, Any]]:
    """Quantize a tensor and serialize it to bytes for chunk writing."""
    quantized, metadata = quantize_tensor(array, bits=bits)
    return _pack_low_bit_values(quantized, bits=bits), metadata


def dequantize_tensor_from_bytes(
    data: bytes,
    metadata: dict[str, Any],
    shape: tuple[int, ...],
) -> np.ndarray:
    """Restore a quantized tensor from serialized chunk bytes."""
    bits = int(metadata.get("bits", 8))
    count = int(metadata.get("num_values", int(np.prod(shape))))
    quantized = _unpack_low_bit_values(data, bits=bits, count=count)
    restored = dequantize_tensor(quantized, metadata)
    try:
        dtype = np.dtype(metadata.get("original_dtype", "float32"))
    except TypeError:
        dtype = np.float32
    return restored.astype(dtype, copy=False).reshape(shape)


def quantization_compression_ratio(bits: int, original_bits: int = 32) -> float:
    """Theoretical compression ratio from quantization.

    For example, INT8 from FP32 gives ratio of 4.0.
    """
    return original_bits / bits


# ---------------------------------------------------------------------------
# Target 9: NF4 quantization + rate-distortion-driven precision selection
# ---------------------------------------------------------------------------

# NF4 quantization levels from the QLoRA paper (Dettmers et al., 2023).
# These 16 values span [-1, 1] with equal-area quantile placement.
NF4_LEVELS: list[float] = [
    -1.0, -0.6962, -0.5251, -0.3949, -0.2844,
    -0.1848, -0.0911, 0.0, 0.0796, 0.1609,
    0.2461, 0.3379, 0.4407, 0.5626, 0.7230, 1.0,
]


def quantize_nf4(array: np.ndarray) -> tuple[bytes, dict]:
    """Quantize a float array to NF4 (4-bit NormalFloat) format.

    Each element is mapped to the nearest of the 16 NF4 quantisation
    levels and stored as a 4-bit index in packed bytes.

    Args:
        array: Input float array. Will be normalised by its absolute maximum
               before mapping so that the range is clipped to [-1, 1].

    Returns:
        Tuple of (packed_bytes, metadata).
        Metadata contains abs_max, original_dtype, original_shape, bits=4,
        scheme="nf4".
    """
    if array.dtype not in _supported_float_dtypes():
        array = array.astype(np.float32)

    original_shape = array.shape
    original_dtype = str(array.dtype)
    flat = array.ravel().astype(np.float32)

    abs_max = float(np.max(np.abs(flat))) if flat.size > 0 else 1.0
    if abs_max == 0.0:
        abs_max = 1.0

    normalised = flat / abs_max

    levels = np.array(NF4_LEVELS, dtype=np.float32)
    # Map each element to the nearest NF4 level index (0-15)
    diffs = np.abs(normalised[:, None] - levels[None, :])  # (N, 16)
    indices = np.argmin(diffs, axis=1).astype(np.uint8)  # (N,) values in 0..15

    packed = _pack_low_bit_values(indices, bits=4)
    metadata = {
        "abs_max": abs_max,
        "original_dtype": original_dtype,
        "original_shape": list(original_shape),
        "bits": 4,
        "num_values": int(flat.size),
        "scheme": "nf4",
    }
    return packed, metadata


def dequantize_nf4(data: bytes, metadata: dict, shape: tuple[int, ...]) -> np.ndarray:
    """Dequantize an NF4-packed byte string back to float32.

    Args:
        data: Packed 4-bit index bytes from :func:`quantize_nf4`.
        metadata: Metadata dict returned by :func:`quantize_nf4`.
        shape: Desired output shape.

    Returns:
        Dequantised float32 array with the given shape.
    """
    num_values = int(metadata.get("num_values", int(np.prod(shape))))
    abs_max = float(metadata.get("abs_max", 1.0))
    indices = _unpack_low_bit_values(data, bits=4, count=num_values)
    levels = np.array(NF4_LEVELS, dtype=np.float32)
    restored = levels[indices.astype(np.int32)] * abs_max
    try:
        dtype = np.dtype(metadata.get("original_dtype", "float32"))
    except TypeError:
        dtype = np.float32
    return restored.astype(dtype, copy=False).reshape(shape)


def select_precision(
    array: np.ndarray,
    max_bits: int = 8,
    distortion_threshold: float = 0.01,
) -> tuple[int, str]:
    """Choose the lowest-bit format where relative L2 distortion is acceptable.

    Tries formats in order: NF4 (4-bit), INT4 (4-bit), INT8 (8-bit).
    The first format whose relative L2 reconstruction error is within
    ``distortion_threshold`` is returned.

    Args:
        array: Input float array to evaluate.
        max_bits: Maximum allowed bit width (4 or 8).
        distortion_threshold: Maximum relative L2 error (‖original − reconstructed‖ / ‖original‖).

    Returns:
        Tuple of (bits, scheme) e.g. (4, "nf4") or (8, "symmetric_uniform").
    """
    original = array.astype(np.float32).ravel()
    original_norm = float(np.linalg.norm(original))
    if original_norm == 0.0:
        return 4, "nf4"

    candidates: list[tuple[int, str]] = []
    if max_bits >= 4:
        candidates.append((4, "nf4"))
        candidates.append((4, "symmetric_uniform"))
    if max_bits >= 8:
        candidates.append((8, "symmetric_uniform"))

    for bits, scheme in candidates:
        try:
            if scheme == "nf4":
                packed, meta = quantize_nf4(array)
                recon = dequantize_nf4(packed, meta, array.shape).ravel().astype(np.float32)
            else:
                packed_bytes, meta = quantize_tensor_to_bytes(array, bits=bits)
                recon = dequantize_tensor_from_bytes(packed_bytes, meta, array.shape).ravel().astype(np.float32)
        except (QuantizeError, Exception):
            continue

        error = float(np.linalg.norm(original - recon)) / original_norm
        if error <= distortion_threshold:
            return bits, scheme

    # Fall back to the highest-bit format available
    return candidates[-1]
