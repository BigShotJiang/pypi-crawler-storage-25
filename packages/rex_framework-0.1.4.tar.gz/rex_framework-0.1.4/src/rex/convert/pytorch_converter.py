"""PyTorch model to Rex format converter.

Status: Implemented

Converts PyTorch state_dict/checkpoint files into Rex chunk format:
- Splits each parameter tensor into fixed-size chunks
- Computes per-chunk checksums
- Generates a Rex manifest JSON
- Produces a deterministic, reproducible output
- Supports per-chunk compression (lz4, zstd)

Supported model types (Phase A):
- Tiny demo transformer (provided in examples/)
- Simple MLP / feed-forward networks
- Any nn.Module with a standard state_dict

Unsupported (documented):
- Models with dynamic control flow
- Models with tied weights (manual deduplication needed)
- Runtime-aware low-bit kernels beyond converter/runtime dequantization support

Usage:
    from rex.convert.pytorch_converter import PyTorchConverter

    # CompressionCodec enum
    converter = PyTorchConverter(output_dir="./rex_model", compression=CompressionCodec.LZ4)
    manifest = converter.convert(state_dict, model_id="my-model")

    # Or string shorthand
    converter = PyTorchConverter(output_dir="./rex_model", compression="lz4")
    manifest = converter.convert_model(state_dict, model_id="my-model")
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import numpy as np

from rex.core.types import (
    ByteRange,
    CacheConstraints,
    ChunkAddress,
    ChunkMetadata,
    CompressionCodec,
    RexManifest,
    StorageBackendType,
    TensorDescriptor,
)
from rex.convert.quantize import quantize_tensor_to_bytes
from rex.formats.chunk_writer import ChunkWriter
from rex.formats.manifest import save_manifest, validate_manifest


@dataclass
class ConversionResult:
    """Result of converting a PyTorch model to Rex format."""
    manifest: RexManifest
    output_dir: Path
    total_original_bytes: int
    total_chunk_bytes: int
    num_parameters: int
    num_chunks: int
    conversion_time_seconds: float
    warnings: list[str] = field(default_factory=list)


class PyTorchConverter:
    """Converts PyTorch models to Rex chunk format.

    The converter takes a state_dict (dictionary of parameter name -> tensor)
    and produces:
    1. A directory of chunk files (*.bin)
    2. A manifest.json describing the model metadata and chunk layout

    The output is deterministic: the same input always produces
    the same chunk files and manifest.

    Args:
        output_dir: Directory to write Rex format output.
        chunk_size_bytes: Target chunk size (default 512 KB).
        compression: CompressionCodec enum or string ("lz4", "zstd", "none").
            When set, each chunk is individually compressed before writing.
        model_id: Identifier for the model (used in manifest).
        model_family: Model family name (e.g., "demo-transformer").
    """

    _COMPRESSION_MAP: dict[str, CompressionCodec] = {
        "none": CompressionCodec.NONE,
        "lz4": CompressionCodec.LZ4,
        "zstd": CompressionCodec.ZSTD,
    }

    def __init__(
        self,
        output_dir: str | Path,
        chunk_size_bytes: int = 524_288,
        compression: CompressionCodec | str = CompressionCodec.NONE,
        quantization_bits: int | None = None,
        model_id: str = "unknown",
        model_family: str = "unknown",
    ) -> None:
        # Normalise compression to enum
        if isinstance(compression, str):
            codec = self._COMPRESSION_MAP.get(compression.lower())
            if codec is None:
                raise ValueError(
                    f"Unknown compression codec: {compression!r}. "
                    f"Choose from: {list(self._COMPRESSION_MAP.keys())}"
                )
            compression = codec
        self.compression: CompressionCodec = compression
        self.output_dir = Path(output_dir)
        self.chunk_size_bytes = chunk_size_bytes
        if quantization_bits not in (None, 8, 4, 2):
            raise ValueError(
                f"Unsupported quantization_bits={quantization_bits!r}. "
                "Choose one of: None, 8, 4, 2"
            )
        self.quantization_bits = quantization_bits
        self.model_id = model_id
        self.model_family = model_family

        # Create subdirectories
        (self.output_dir / "weights").mkdir(parents=True, exist_ok=True)
        (self.output_dir / "metadata").mkdir(parents=True, exist_ok=True)

    def convert(
        self,
        state_dict: dict[str, Any],
        source_framework: str = "pytorch",
    ) -> ConversionResult:
        """Convert a PyTorch state_dict to Rex format.

        Args:
            state_dict: Dictionary mapping parameter names to tensors
                        (torch.Tensor or numpy arrays).
            source_framework: Framework identifier for provenance.

        Returns:
            ConversionResult with manifest and statistics.
        """
        import time
        start_time = time.time()
        warnings: list[str] = []

        writer = ChunkWriter(
            output_dir=self.output_dir / "weights",
            chunk_size_bytes=self.chunk_size_bytes,
            compression=self.compression,
            per_chunk_compression=True,
        )

        parameters: dict[str, TensorDescriptor] = {}
        execution_graph: list[str] = []
        total_original_bytes = 0
        total_chunk_bytes = 0
        total_chunks = 0

        for param_name, tensor in state_dict.items():
            # Convert to numpy if needed
            if hasattr(tensor, "numpy"):
                try:
                    if hasattr(tensor, "detach") and hasattr(tensor, "cpu"):
                        arr = tensor.detach().cpu().numpy()
                    else:
                        arr = tensor.numpy()
                except Exception:
                    # Some torch builds cannot expose NumPy views in certain
                    # environments; fall back to Python list conversion.
                    arr = np.asarray(tensor.tolist())
            elif hasattr(tensor, "tolist"):
                arr = np.array(tensor)
            else:
                arr = np.asarray(tensor)

            # Ensure contiguous
            arr = np.ascontiguousarray(arr)
            original_bytes = arr.nbytes
            quantization_metadata: dict[str, Any] | None = None
            tensor_bytes = arr.tobytes()

            if self.quantization_bits is not None:
                if arr.dtype.kind == "f":
                    tensor_bytes, quantization_metadata = quantize_tensor_to_bytes(
                        arr,
                        bits=self.quantization_bits,
                    )
                else:
                    warnings.append(
                        f"Parameter '{param_name}' skipped quantization because dtype {arr.dtype} is not floating-point"
                    )

            # Write as chunks (resource_id matches the flat file path)
            if quantization_metadata is None:
                result = writer.write_numpy(
                    param_name=param_name,
                    array=arr,
                )
            else:
                result = writer.write_tensor(
                    param_name=param_name,
                    data=tensor_bytes,
                )
                result.shape = tuple(arr.shape)
                result.dtype = str(arr.dtype)

            # Build chunk metadata
            chunk_addrs: list[ChunkAddress] = []
            for cr in result.chunks:
                chunk_addrs.append(ChunkAddress(
                    resource_id=cr.resource_id,
                    byte_range=ByteRange(start=cr.byte_range.start, end=cr.byte_range.end),
                    chunk_id=cr.chunk_id,
                ))
                total_chunk_bytes += cr.compressed_size

            td = TensorDescriptor(
                name=param_name,
                shape=tuple(arr.shape),
                dtype=str(arr.dtype),
                num_chunks=result.num_chunks,
                chunk_addresses=chunk_addrs,
                total_bytes=original_bytes,
                quantization=quantization_metadata,
            )
            parameters[param_name] = td
            execution_graph.append(param_name)
            total_original_bytes += original_bytes
            total_chunks += result.num_chunks

            # Warn about tied weights (same data, different names)
            if original_bytes == 0:
                warnings.append(f"Parameter '{param_name}' has 0 bytes")

        # Build manifest
        manifest = RexManifest(
            manifest_version="0.1.0",
            model_id=self.model_id,
            model_family=self.model_family,
            source_framework=source_framework,
            parameters=parameters,
            total_model_bytes=total_original_bytes,
            total_chunks=total_chunks,
            default_chunk_size=self.chunk_size_bytes,
            storage_backend=StorageBackendType.HTTP_RANGE,
            compression=self.compression,
            cache_constraints=CacheConstraints(
                max_local_fraction_of_model=0.4,
                enforce_invariant=True,
            ),
            execution_graph=execution_graph,
            provenance={
                "converter_version": "0.1.0",
                "converted_at": datetime.now(timezone.utc).isoformat(),
                "original_framework": source_framework,
            },
            feature_flags={
                "compressed_chunks": self.compression != CompressionCodec.NONE,
                "quantized_chunks": self.quantization_bits is not None,
                "adaptive_chunk_sizes": False,
                "disk_cache": False,
            },
        )

        # Validate before saving
        errors = validate_manifest(manifest)
        if errors:
            for e in errors:
                warnings.append(f"Manifest validation: {e}")

        # Save manifest
        save_manifest(manifest, self.output_dir / "manifest.json")

        elapsed = time.time() - start_time

        return ConversionResult(
            manifest=manifest,
            output_dir=self.output_dir,
            total_original_bytes=total_original_bytes,
            total_chunk_bytes=total_chunk_bytes,
            num_parameters=len(parameters),
            num_chunks=total_chunks,
            conversion_time_seconds=elapsed,
            warnings=warnings,
        )

    def convert_model(
        self,
        state_dict: dict[str, Any],
        compression: Optional[CompressionCodec | str] = None,
        source_framework: str = "pytorch",
    ) -> ConversionResult:
        """Convenience method to convert a model with optional compression override.

        This is the recommended entry-point when you want to specify
        compression as a string (e.g. ``"lz4"`` or ``"zstd"``) at
        conversion time.

        Args:
            state_dict: Dictionary mapping parameter names to tensors.
            compression: Optional compression override.  If *None*, the
                codec configured on the constructor is used.
            source_framework: Framework identifier for provenance.

        Returns:
            ConversionResult with manifest and statistics.
        """
        if compression is not None:
            if isinstance(compression, str):
                codec = self._COMPRESSION_MAP.get(compression.lower())
                if codec is None:
                    raise ValueError(
                        f"Unknown compression codec: {compression!r}. "
                        f"Choose from: {list(self._COMPRESSION_MAP.keys())}"
                    )
                self.compression = codec
            else:
                self.compression = compression
        return self.convert(state_dict, source_framework=source_framework)

    @staticmethod
    def _load_safetensors_state_dict(checkpoint_path: Path) -> dict[str, Any]:
        from safetensors import safe_open

        state_dict: dict[str, Any] = {}
        # Prefer torch backend for bfloat16 compatibility, but fall back to
        # numpy backend for tensors that torch cannot represent (e.g. uint32).
        with safe_open(str(checkpoint_path), framework="pt") as f_torch, safe_open(
            str(checkpoint_path), framework="np"
        ) as f_numpy:
            for key in f_torch.keys():
                try:
                    state_dict[key] = f_torch.get_tensor(key)
                except Exception as exc:
                    # Torch lacks some dtypes (notably uint32); retry in numpy.
                    if "uint32" not in str(exc):
                        raise
                    state_dict[key] = f_numpy.get_tensor(key)
        return state_dict

    @staticmethod
    def _load_pytorch_state_dict(checkpoint_path: Path) -> dict[str, Any]:
        import torch

        data = torch.load(str(checkpoint_path), map_location="cpu", weights_only=True)
        if isinstance(data, dict) and "state_dict" in data:
            return data["state_dict"]
        if isinstance(data, dict):
            first_val = next(iter(data.values()), None)
            if hasattr(first_val, "shape"):
                return data
            raise ValueError(
                f"Cannot parse checkpoint: dict has no 'state_dict' key "
                f"and values don't look like tensors. Keys: {list(data.keys())[:5]}"
            )
        raise ValueError(
            f"Cannot parse checkpoint: expected dict, got {type(data).__name__}"
        )

    @staticmethod
    def _load_npz_state_dict(checkpoint_path: Path) -> dict[str, Any]:
        npz = np.load(str(checkpoint_path), allow_pickle=False)
        return {key: np.asarray(npz[key]) for key in npz.files}

    @staticmethod
    def _load_tensorflow_h5_state_dict(checkpoint_path: Path) -> dict[str, Any]:
        try:
            import h5py
        except ImportError as exc:
            raise ImportError(
                "TensorFlow .h5/.keras conversion requires h5py (or tensorflow extra)."
            ) from exc

        state_dict: dict[str, Any] = {}
        with h5py.File(str(checkpoint_path), "r") as f:
            def visitor(name: str, obj: Any) -> None:
                if isinstance(obj, h5py.Dataset):
                    state_dict[name] = np.asarray(obj[()])

            f.visititems(visitor)
        if not state_dict:
            raise ValueError(f"No tensor datasets found in {checkpoint_path}")
        return state_dict

    @staticmethod
    def _load_tensorflow_checkpoint_state_dict(checkpoint_path: Path) -> dict[str, Any]:
        try:
            import tensorflow as tf
        except ImportError as exc:
            raise ImportError(
                "TensorFlow checkpoint conversion requires tensorflow extra."
            ) from exc

        base_path = checkpoint_path
        if checkpoint_path.suffix == ".index":
            base_path = checkpoint_path.with_suffix("")

        state_dict: dict[str, Any] = {}
        for var_name, _shape in tf.train.list_variables(str(base_path)):
            if var_name.startswith("_CHECKPOINTABLE_OBJECT_GRAPH"):
                continue
            state_dict[var_name] = tf.train.load_variable(str(base_path), var_name)
        if not state_dict:
            raise ValueError(f"No TensorFlow variables found in {checkpoint_path}")
        return state_dict

    @staticmethod
    def convert_file(
        checkpoint_path: str | Path,
        output_dir: str | Path,
        chunk_size_bytes: int = 524_288,
        compression: CompressionCodec = CompressionCodec.NONE,
        quantization_bits: int | None = None,
        model_id: str = "converted-model",
        model_family: str = "unknown",
        framework: str = "auto",
    ) -> ConversionResult:
        """Convenience method to convert from a checkpoint file.

        Supports:
        - PyTorch .pt / .pth files (state_dict or full checkpoint)
        - safetensors files

        Args:
            checkpoint_path: Path to the checkpoint file.
            output_dir: Output directory for Rex format.
            chunk_size_bytes: Target chunk size.
            compression: Compression codec.
            model_id: Model identifier.
            model_family: Model family name.

        Returns:
            ConversionResult.
        """
        p = Path(checkpoint_path)
        if not p.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

        framework = framework.lower()
        if framework not in {"auto", "pytorch", "safetensors", "jax", "tensorflow"}:
            raise ValueError(
                f"Unknown framework: {framework!r}. "
                "Choose one of: auto, pytorch, safetensors, jax, tensorflow"
            )

        inferred_framework = framework
        if framework == "auto":
            if p.suffix == ".safetensors":
                inferred_framework = "safetensors"
            elif p.suffix == ".npz":
                inferred_framework = "jax"
            elif p.suffix in {".h5", ".keras", ".index"}:
                inferred_framework = "tensorflow"
            elif p.suffix in {".pt", ".pth", ".ckpt", ".bin"}:
                inferred_framework = "pytorch"
            else:
                inferred_framework = "pytorch"

        if inferred_framework == "safetensors":
            state_dict = PyTorchConverter._load_safetensors_state_dict(p)
        elif inferred_framework == "jax":
            if p.suffix != ".npz":
                raise ValueError("JAX conversion currently supports .npz checkpoints.")
            state_dict = PyTorchConverter._load_npz_state_dict(p)
        elif inferred_framework == "tensorflow":
            if p.suffix in {".h5", ".keras"}:
                state_dict = PyTorchConverter._load_tensorflow_h5_state_dict(p)
            elif p.suffix in {".ckpt", ".index"}:
                state_dict = PyTorchConverter._load_tensorflow_checkpoint_state_dict(p)
            elif p.suffix == ".npz":
                # Utility path for exported TensorFlow weights.
                state_dict = PyTorchConverter._load_npz_state_dict(p)
            else:
                raise ValueError(
                    "TensorFlow conversion supports .h5, .keras, .ckpt/.index, and .npz"
                )
        else:
            state_dict = PyTorchConverter._load_pytorch_state_dict(p)

        converter = PyTorchConverter(
            output_dir=output_dir,
            chunk_size_bytes=chunk_size_bytes,
            compression=compression,
            quantization_bits=quantization_bits,
            model_id=model_id,
            model_family=model_family,
        )
        return converter.convert(state_dict, source_framework=inferred_framework)
