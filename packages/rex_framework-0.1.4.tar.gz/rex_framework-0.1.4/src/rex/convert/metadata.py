"""Metadata utilities for the conversion pipeline.

Status: Implemented

Provides helpers for building and validating conversion metadata.
"""

from __future__ import annotations

import hashlib
import platform
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional


@dataclass
class ConversionMetadata:
    """Metadata recorded during model conversion."""
    converter_version: str = "0.1.0"
    converted_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    python_version: str = field(default_factory=platform.python_version)
    platform: str = field(default_factory=platform.platform)
    torch_version: str = ""
    source_framework: str = "pytorch"
    source_path: str = ""
    model_id: str = ""
    model_family: str = ""
    chunk_size_bytes: int = 524288
    compression: str = "none"
    num_parameters: int = 0
    num_chunks: int = 0
    original_size_bytes: int = 0
    chunked_size_bytes: int = 0
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "converter_version": self.converter_version,
            "converted_at": self.converted_at,
            "python_version": self.python_version,
            "platform": self.platform,
            "torch_version": self.torch_version,
            "source_framework": self.source_framework,
            "source_path": self.source_path,
            "model_id": self.model_id,
            "model_family": self.model_family,
            "chunk_size_bytes": self.chunk_size_bytes,
            "compression": self.compression,
            "num_parameters": self.num_parameters,
            "num_chunks": self.num_chunks,
            "original_size_bytes": self.original_size_bytes,
            "chunked_size_bytes": self.chunked_size_bytes,
            "warnings": self.warnings,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ConversionMetadata:
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


def get_torch_version() -> str:
    """Get PyTorch version, or empty string if not installed."""
    try:
        import torch
        return torch.__version__
    except ImportError:
        return ""


def compute_state_dict_fingerprint(state_dict: dict) -> str:
    """Compute a stable fingerprint of a state_dict for change detection.

    Uses parameter names + shapes + first/last 64 bytes of each tensor.
    Not cryptographically secure, but stable across identical models.
    """
    h = hashlib.sha256()
    for name in sorted(state_dict.keys()):
        h.update(name.encode())
        tensor = state_dict[name]
        if hasattr(tensor, "shape"):
            h.update(str(tuple(tensor.shape)).encode())
            if hasattr(tensor, "numpy"):
                arr = tensor.detach().cpu().numpy()
            else:
                arr = tensor
            flat = arr.flatten()
            if len(flat) > 0:
                # Hash first and last 64 bytes
                raw = flat.tobytes()
                h.update(raw[:64])
                if len(raw) > 64:
                    h.update(raw[-64:])
    return h.hexdigest()[:16]
