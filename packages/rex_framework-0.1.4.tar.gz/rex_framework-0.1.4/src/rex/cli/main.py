"""CLI entry points for Rex.

Status: Implemented

Provides the rex-run-demo command and shared CLI utilities.
"""

import sys
from pathlib import Path

import click


@click.group()
@click.version_option(package_name="rex-framework")
def cli():
    """Rex Framework CLI — Remote Executable eXecution.

    Manage model conversion, validation, serving, and benchmarking
    for Rex remote-weight inference.
    """
    pass


@cli.command(name="run-demo")
@click.option(
    "--output-dir", "-o",
    default="./rex_demo_output",
    help="Output directory for demo artifacts.",
)
@click.option(
    "--chunk-size",
    default=524288,
    help="Chunk size in bytes (default: 524288 = 512 KB).",
)
@click.option(
    "--compression",
    type=click.Choice(["none", "lz4", "zstd"]),
    default="none",
    help="Compression codec for chunks.",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Enable verbose logging.",
)
def run_demo(output_dir: str, chunk_size: int, compression: str, verbose: bool):
    """Run the end-to-end Rex demo.

    Creates a tiny PyTorch model, converts it to Rex format,
    starts a local chunk server, and runs inference through Rex.

    Example:
        rex-run-demo --output-dir ./my_demo
    """
    from rex.metrics.logging import configure_logging
    from rex.api.config import RexConfig, ObservabilityConfig

    log_config = ObservabilityConfig(
        log_level="DEBUG" if verbose else "INFO",
    )
    configure_logging(log_config)

    # Lazy imports to avoid loading torch unless needed
    import asyncio
    import torch
    import tempfile

    from rex.convert.pytorch_converter import PyTorchConverter
    from rex.core.types import CompressionCodec
    from rex.storage.local_server import serve_chunks
    from rex.core.runtime import RexRuntime
    from rex.formats.manifest import load_manifest, pretty_print_manifest

    click.echo("=" * 60)
    click.echo("Rex Framework — End-to-End Demo")
    click.echo("=" * 60)
    click.echo()

    # Step 1: Create a tiny model
    click.echo("[1/5] Creating tiny demo model...")
    model = _create_demo_model()
    sd = model.state_dict()
    click.echo(f"  Model parameters: {len(sd)}")
    for k, v in sd.items():
        click.echo(f"    {k}: {v.shape} ({v.numel()} elements)")
    click.echo()

    # Step 2: Convert to Rex format
    click.echo("[2/5] Converting to Rex format...")
    codec = CompressionCodec(compression)
    converter = PyTorchConverter(
        output_dir=output_dir,
        chunk_size_bytes=chunk_size,
        compression=codec,
        model_id="demo-tiny-transformer",
        model_family="demo",
    )
    result = converter.convert(sd)
    click.echo(f"  Output: {output_dir}")
    click.echo(f"  Chunks: {result.num_chunks}")
    click.echo(f"  Original: {_fmt_bytes(result.total_original_bytes)}")
    click.echo(f"  Chunked:  {_fmt_bytes(result.total_chunk_bytes)}")
    if result.warnings:
        for w in result.warnings:
            click.echo(f"  WARNING: {w}")
    click.echo()

    # Step 3: Start local chunk server
    click.echo("[3/5] Starting local chunk server...")
    import threading
    import time

    chunks_dir = str(Path(output_dir) / "weights")

    async def _start_and_serve():
        await serve_chunks(
            chunk_dir=chunks_dir,
            host="127.0.0.1",
            port=18971,
        )
        # Keep server alive
        while True:
            await asyncio.sleep(3600)

    server_thread = threading.Thread(
        target=lambda: asyncio.run(_start_and_serve()),
        daemon=True,
    )
    server_thread.start()
    time.sleep(1.0)  # Give server time to start
    base_url = "http://127.0.0.1:18971"
    click.echo(f"  Server running at {base_url}")
    click.echo()

    # Step 4: Load manifest
    click.echo("[4/5] Loading Rex manifest...")
    manifest = load_manifest(str(Path(output_dir) / "manifest.json"))
    click.echo(pretty_print_manifest(manifest))
    click.echo()

    # Step 5: Run inference
    click.echo("[5/5] Running inference through Rex...")
    config = RexConfig()
    config.storage.base_url = base_url

    runtime = RexRuntime(config=config)

    # Create dummy input
    input_tensor = torch.randn(1, 16)

    async def _do_inference():
        await runtime.load_model(str(Path(output_dir) / "manifest.json"))
        return await runtime.run_inference(input_tensor)

    try:
        output, metrics = asyncio.run(_do_inference())
        click.echo(f"  Output shape: {output.shape if hasattr(output, 'shape') else 'N/A'}")
        click.echo(f"  Inference time: {metrics.total_time_ms:.1f} ms")
        click.echo(f"  Chunks fetched: {metrics.chunks_fetched}")
        click.echo(f"  Cache hits: {metrics.cache_hits}")
        click.echo(f"  Cache misses: {metrics.cache_misses}")
        click.echo(f"  Bytes fetched: {_fmt_bytes(metrics.bytes_fetched_remote)}")
        click.echo(f"  Layers executed: {metrics.layers_executed}")
        click.echo(f"  Invariant violations: {metrics.invariant_violations}")
    except Exception as e:
        click.echo(f"  ERROR: {e}", err=True)
        sys.exit(1)

    click.echo()
    click.echo("Demo completed successfully!")
    click.echo(f"Artifacts saved to: {output_dir}")


def _create_demo_model():
    """Create the tiny demo transformer model."""
    import torch
    import torch.nn as nn

    class TinyTransformer(nn.Module):
        def __init__(self, d_model=16, n_heads=2, d_ff=32, n_layers=2, vocab_size=100):
            super().__init__()
            self.embedding = nn.Linear(vocab_size, d_model, bias=False)
            self.layers = nn.ModuleList()
            for _ in range(n_layers):
                self.layers.append(nn.ModuleDict({
                    "attention_w_q": nn.Linear(d_model, d_model, bias=False),
                    "attention_w_k": nn.Linear(d_model, d_model, bias=False),
                    "attention_w_v": nn.Linear(d_model, d_model, bias=False),
                    "attention_w_o": nn.Linear(d_model, d_model, bias=False),
                    "ffn_fc1": nn.Linear(d_model, d_ff, bias=False),
                    "ffn_fc2": nn.Linear(d_ff, d_model, bias=False),
                    "norm1": nn.LayerNorm(d_model),
                    "norm2": nn.LayerNorm(d_model),
                }))
            self.output = nn.Linear(d_model, vocab_size, bias=False)

        def forward(self, x):
            return x  # Not used for Rex inference

    return TinyTransformer()


def _fmt_bytes(n: int) -> str:
    if n == 0:
        return "0 B"
    for unit in ["B", "KB", "MB", "GB"]:
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


if __name__ == "__main__":
    cli()
