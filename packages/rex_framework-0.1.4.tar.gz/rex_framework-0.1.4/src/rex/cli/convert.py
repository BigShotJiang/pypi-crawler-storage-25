"""rex-convert CLI command.

Status: Implemented
"""

import sys
from pathlib import Path

import click


@click.command()
@click.argument("checkpoint_path", type=click.Path(exists=True))
@click.option(
    "--output-dir", "-o",
    default="./rex_output",
    help="Output directory for Rex format files.",
    required=True,
)
@click.option(
    "--model-id", "-m",
    default="converted-model",
    help="Model identifier for the manifest.",
)
@click.option(
    "--model-family",
    default="unknown",
    help="Model family name.",
)
@click.option(
    "--chunk-size",
    default=524288,
    help="Chunk size in bytes (default: 512 KB).",
)
@click.option(
    "--compression", "-c",
    type=click.Choice(["none", "lz4", "zstd"]),
    default="none",
    help="Compression codec.",
)
@click.option(
    "--framework",
    type=click.Choice(["auto", "pytorch", "safetensors", "jax", "tensorflow"]),
    default="auto",
    show_default=True,
    help="Input checkpoint framework type.",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Verbose output.",
)
@click.option(
    "--quantize-bits",
    type=click.Choice(["8", "4", "2"]),
    default=None,
    help="Optional symmetric quantization bit width for floating-point tensors.",
)
@click.option(
    "--json", "output_json",
    is_flag=True,
    help="Output result as JSON.",
)
def cli(
    checkpoint_path,
    output_dir,
    model_id,
    model_family,
    chunk_size,
    compression,
    framework,
    verbose,
    quantize_bits,
    output_json,
):
    """Convert a model checkpoint to Rex format.

    Supports PyTorch (.pt/.pth/.ckpt/.bin), safetensors (.safetensors),
    JAX numpy archives (.npz), and TensorFlow checkpoints (.h5/.keras/.ckpt/.index).

    \b
    Examples:
        rex-convert model.pt -o ./rex_model -m my-model
        rex-convert model.safetensors -c lz4 --chunk-size 1048576
    """
    from rex.metrics.logging import configure_logging
    configure_logging(ObservabilityConfig(log_level="DEBUG" if verbose else "INFO"))

    from rex.convert.pytorch_converter import PyTorchConverter
    from rex.core.types import CompressionCodec

    codec = CompressionCodec(compression)

    try:
        result = PyTorchConverter.convert_file(
            checkpoint_path=checkpoint_path,
            output_dir=output_dir,
            chunk_size_bytes=chunk_size,
            compression=codec,
            quantization_bits=int(quantize_bits) if quantize_bits else None,
            model_id=model_id,
            model_family=model_family,
            framework=framework,
        )
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Conversion failed: {e}", err=True)
        sys.exit(1)

    if output_json:
        import json
        click.echo(json.dumps({
            "status": "success",
            "output_dir": str(result.output_dir),
            "num_parameters": result.num_parameters,
            "num_chunks": result.num_chunks,
            "original_size": result.total_original_bytes,
            "chunked_size": result.total_chunk_bytes,
            "conversion_time_s": result.conversion_time_seconds,
            "warnings": result.warnings,
        }, indent=2))
    else:
        click.echo(f"Conversion successful!")
        click.echo(f"  Output:    {result.output_dir}")
        click.echo(f"  Params:    {result.num_parameters}")
        click.echo(f"  Chunks:    {result.num_chunks}")
        click.echo(f"  Original:  {_fmt(result.total_original_bytes)}")
        click.echo(f"  Chunked:   {_fmt(result.total_chunk_bytes)}")
        click.echo(f"  Time:      {result.conversion_time_seconds:.2f}s")
        if result.warnings:
            click.echo("  Warnings:")
            for w in result.warnings:
                click.echo(f"    - {w}")


def _fmt(n: int) -> str:
    if n == 0:
        return "0 B"
    for u in ["B", "KB", "MB", "GB"]:
        if abs(n) < 1024:
            return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} TB"


from rex.api.config import ObservabilityConfig
