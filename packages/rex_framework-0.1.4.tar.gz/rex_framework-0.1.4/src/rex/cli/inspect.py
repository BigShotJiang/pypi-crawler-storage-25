"""rex-inspect CLI command.

Inspects a Rex manifest and displays comprehensive model information
including parameters, chunks, execution graph, cache constraints,
feature flags, and storage backend details.

Supports human-readable and JSON output modes.

Status: Implemented
"""

from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path
from typing import Any

import click


def _load_raw_manifest(manifest_path: str) -> dict[str, Any]:
    """Load raw JSON from a manifest file."""
    try:
        with open(manifest_path, "rb") as f:
            return json.loads(f.read().decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise click.ClickException(f"Invalid JSON in manifest: {exc}")
    except OSError as exc:
        raise click.ClickException(f"Cannot read manifest file: {exc}")


def _fmt_bytes(n: int) -> str:
    """Format byte count as human-readable string."""
    if n == 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(n)
    while size >= 1024.0 and i < len(units) - 1:
        size /= 1024.0
        i += 1
    return f"{size:.1f} {units[i]}"


def _fmt_number(n: int) -> str:
    """Format integer with thousands separator."""
    return f"{n:,}"


def _estimate_parameters(shape: list[int], dtype: str) -> int:
    """Estimate the number of scalar parameters from shape and dtype."""
    if not shape:
        return 0
    numel = 1
    for d in shape:
        numel *= d
    return numel


def _dtype_bytes(dtype: str) -> int:
    """Return bytes per element for a given dtype."""
    mapping = {
        "float32": 4, "fp32": 4, "f32": 4,
        "float16": 2, "fp16": 2, "f16": 2,
        "bfloat16": 2, "bf16": 2,
        "float64": 8, "fp64": 8, "f64": 8,
        "int8": 1, "i8": 1,
        "int16": 2, "i16": 2,
        "int32": 4, "i32": 4,
        "int64": 8, "i64": 8,
        "uint8": 1, "u8": 1,
        "bool": 1,
    }
    return mapping.get(dtype.lower(), 4)  # default to float32


def _build_inspection(raw_data: dict[str, Any], verbose: bool = False) -> dict[str, Any]:
    """Build a comprehensive inspection dict from raw manifest data."""
    parameters = raw_data.get("parameters", {})
    exec_graph = raw_data.get("execution_graph", [])
    cache_constraints = raw_data.get("cache_constraints", {})
    feature_flags = raw_data.get("feature_flags", {})
    backend_reqs = raw_data.get("backend_requirements", {})
    provenance = raw_data.get("provenance", {})

    # Compute totals
    total_chunks = 0
    total_bytes = 0
    total_params = 0
    param_details = []

    for pname, pdata in sorted(parameters.items()):
        shape = pdata.get("shape", [])
        dtype = pdata.get("dtype", "unknown")
        num_chunks = pdata.get("num_chunks", 0)
        param_bytes = pdata.get("total_bytes", 0)
        chunk_addrs = pdata.get("chunk_addresses", [])
        n_params = _estimate_parameters(shape, dtype)

        total_chunks += num_chunks
        total_bytes += param_bytes
        total_params += n_params

        detail: dict[str, Any] = {
            "name": pname,
            "shape": shape,
            "dtype": dtype,
            "num_chunks": num_chunks,
            "total_bytes": param_bytes,
            "total_bytes_human": _fmt_bytes(param_bytes),
            "estimated_parameters": n_params,
            "shape_str": "x".join(str(d) for d in shape) if shape else "scalar",
        }

        if verbose:
            detail["chunk_addresses"] = []
            for ca in chunk_addrs:
                ca_detail = {
                    "chunk_id": ca.get("chunk_id", ""),
                    "resource_id": ca.get("resource_id", ""),
                }
                br = ca.get("byte_range", {})
                ca_detail["byte_range"] = {
                    "start": br.get("start", 0),
                    "end": br.get("end", 0),
                    "size": br.get("end", 0) - br.get("start", 0),
                }
                detail["chunk_addresses"].append(ca_detail)

        param_details.append(detail)

    # Execution graph details
    graph_details = []
    for i, layer_name in enumerate(exec_graph):
        layer_detail: dict[str, Any] = {
            "index": i,
            "name": layer_name,
            "has_parameter": layer_name in parameters,
        }
        if layer_name in parameters:
            td = parameters[layer_name]
            layer_detail["shape"] = td.get("shape", [])
            layer_detail["chunks"] = td.get("num_chunks", 0)
        graph_details.append(layer_detail)

    inspection = {
        "model": {
            "model_id": raw_data.get("model_id", ""),
            "model_family": raw_data.get("model_family", ""),
            "version": raw_data.get("manifest_version", ""),
            "source_framework": raw_data.get("source_framework", "unknown"),
        },
        "size": {
            "total_model_bytes": total_bytes,
            "total_model_bytes_human": _fmt_bytes(total_bytes),
            "total_chunks": total_chunks,
            "total_parameters": total_params,
            "total_parameters_human": _fmt_number(total_params),
            "default_chunk_size": raw_data.get("default_chunk_size", 524288),
            "default_chunk_size_human": _fmt_bytes(raw_data.get("default_chunk_size", 524288)),
            "num_parameters": len(parameters),
        },
        "parameters": param_details,
        "execution_graph": {
            "num_layers": len(exec_graph),
            "layers": graph_details,
        },
        "cache_constraints": {
            "max_local_fraction": cache_constraints.get("max_local_fraction_of_model", 0.4),
            "max_local_fraction_human": f"{cache_constraints.get('max_local_fraction_of_model', 0.4):.0%}",
            "max_memory_cache_bytes": cache_constraints.get("max_memory_cache_bytes", 0),
            "max_memory_cache_bytes_human": _fmt_bytes(cache_constraints.get("max_memory_cache_bytes", 0)),
            "max_disk_cache_bytes": cache_constraints.get("max_disk_cache_bytes", 0),
            "max_disk_cache_bytes_human": _fmt_bytes(cache_constraints.get("max_disk_cache_bytes", 0)),
            "enforce_invariant": cache_constraints.get("enforce_invariant", True),
            "effective_cache_bytes": int(total_bytes * cache_constraints.get("max_local_fraction_of_model", 0.4)),
            "effective_cache_bytes_human": _fmt_bytes(int(total_bytes * cache_constraints.get("max_local_fraction_of_model", 0.4))),
        },
        "feature_flags": feature_flags,
        "storage": {
            "backend": raw_data.get("storage_backend", "http_range"),
            "compression": raw_data.get("compression", "none"),
        },
        "backend_requirements": backend_reqs,
        "provenance": provenance,
    }

    return inspection


def _print_human_readable(inspection: dict[str, Any], verbose: bool) -> None:
    """Print inspection results in human-readable format."""
    model = inspection["model"]
    size = inspection["size"]
    cache = inspection["cache_constraints"]
    storage = inspection["storage"]

    # Header
    click.echo(click.style("=" * 64, fg="white"))
    click.echo(click.style("  Rex Model Inspection Report", fg="white", bold=True))
    click.echo(click.style("=" * 64, fg="white"))
    click.echo()

    # Model identity
    click.echo(click.style("  Model Identity", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 40, fg="cyan"))
    click.echo(f"    Model ID:          {model['model_id']}")
    click.echo(f"    Model Family:      {model['model_family']}")
    click.echo(f"    Version:           {model['version']}")
    click.echo(f"    Source Framework:  {model['source_framework']}")
    click.echo()

    # Size summary
    click.echo(click.style("  Size Summary", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 40, fg="cyan"))
    click.echo(f"    Total Parameters:  {size['total_parameters_human']}")
    click.echo(f"    Model Size:        {size['total_model_bytes_human']}")
    click.echo(f"    Total Chunks:      {size['total_chunks']}")
    click.echo(f"    Default Chunk:     {size['default_chunk_size_human']}")
    click.echo(f"    Num Parameters:    {size['num_parameters']}")
    click.echo()

    # Per-parameter details
    click.echo(click.style("  Parameters", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 40, fg="cyan"))
    for p in inspection["parameters"]:
        name = p["name"]
        shape_str = p["shape_str"]
        dtype = p["dtype"]
        nbytes = p["total_bytes_human"]
        nchunks = p["num_chunks"]
        nparams = p["estimated_parameters"]
        click.echo(
            f"    {name}"
        )
        click.echo(
            f"      shape={shape_str}  dtype={dtype}  "
            f"params={_fmt_number(nparams)}  "
            f"size={nbytes}  chunks={nchunks}"
        )
        if verbose and p.get("chunk_addresses"):
            click.echo(f"      Chunks:")
            for ca in p["chunk_addresses"]:
                br = ca["byte_range"]
                click.echo(
                    f"        [{br['start']:,} - {br['end']:,}) "
                    f"({br['size']:,} bytes)  "
                    f"id={ca['chunk_id']}  "
                    f"resource={ca['resource_id']}"
                )
    click.echo()

    # Execution graph
    graph = inspection["execution_graph"]
    click.echo(click.style("  Execution Graph", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 40, fg="cyan"))
    click.echo(f"    Layers: {graph['num_layers']}")
    for layer in graph["layers"]:
        idx = layer["index"]
        name = layer["name"]
        if layer["has_parameter"]:
            shape_str = "x".join(str(d) for d in layer.get("shape", []))
            click.echo(
                f"    [{idx:3d}] {name:<50s}  {shape_str}"
            )
        else:
            click.echo(
                f"    [{idx:3d}] {name:<50s}  "
                + click.style("(not in parameters)", fg="yellow")
            )
    click.echo()

    # Cache constraints
    click.echo(click.style("  Cache Constraints", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 40, fg="cyan"))
    click.echo(f"    Max Local Fraction:   {cache['max_local_fraction_human']}")
    click.echo(f"    Effective Cache:      {cache['effective_cache_bytes_human']}")
    click.echo(f"    Max Memory Cache:     {cache['max_memory_cache_bytes_human']}")
    click.echo(f"    Max Disk Cache:       {cache['max_disk_cache_bytes_human']}")
    click.echo(f"    Enforce Invariant:    {'yes' if cache['enforce_invariant'] else 'no'}")
    click.echo()

    # Feature flags
    ff = inspection["feature_flags"]
    click.echo(click.style("  Feature Flags", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 40, fg="cyan"))
    if ff:
        for flag, enabled in ff.items():
            if enabled:
                click.echo(f"    {click.style('ON ', fg='green', bold=True)}  {flag}")
            else:
                click.echo(f"    {click.style('OFF', fg='bright_black')}  {flag}")
    else:
        click.echo("    (none defined)")
    click.echo()

    # Storage backend
    click.echo(click.style("  Storage Backend", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 40, fg="cyan"))
    click.echo(f"    Backend:      {storage['backend']}")
    click.echo(f"    Compression:  {storage['compression']}")
    click.echo()


@click.command()
@click.argument("manifest_path", type=click.Path(exists=True))
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output inspection results as JSON.",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Show extra detail: chunk addresses, byte ranges.",
)
def cli(
    manifest_path: str,
    output_json: bool,
    verbose: bool,
) -> None:
    """Inspect a Rex manifest and display model information.

    Prints a comprehensive summary of the model including parameters,
    chunks, execution graph, cache constraints, and feature flags.

    \b
    Examples:
        rex-inspect ./rex_model/manifest.json
        rex-inspect ./rex_model/manifest.json --json
        rex-inspect ./rex_model/manifest.json --verbose
    """
    # Load raw manifest
    raw_data = _load_raw_manifest(manifest_path)

    # Build inspection
    inspection = _build_inspection(raw_data, verbose=verbose)

    # Output
    if output_json:
        click.echo(json.dumps(inspection, indent=2))
    else:
        _print_human_readable(inspection, verbose)


if __name__ == "__main__":
    cli()
