"""rex-benchmark CLI command.

Runs inference benchmarks on a Rex model served from a local chunk server.
Measures timing, cache performance, and chunk fetch metrics across
multiple iterations with warmup support.

Uses RexRuntime for loading and executing the model.

Status: Implemented
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import click


def _fmt_bytes(n: int) -> str:
    """Format byte count as human-readable string."""
    if n == 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(n)
    while size >= 1024.0 and i < len(units) - 1:
        size /= 1024.0
        i += 1
    return f"{size:.1f} {units[i]}"


def _fmt_ms(ms: float) -> str:
    """Format milliseconds for display."""
    if ms < 1.0:
        return f"{ms * 1000:.0f} us"
    elif ms < 1000.0:
        return f"{ms:.1f} ms"
    else:
        return f"{ms / 1000:.2f} s"


@dataclass
class IterationResult:
    """Result from a single benchmark iteration."""
    iteration: int
    is_warmup: bool
    total_time_ms: float = 0.0
    compute_time_ms: float = 0.0
    stall_time_ms: float = 0.0
    chunks_fetched: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    bytes_fetched: int = 0
    layers_executed: int = 0
    invariant_violations: int = 0
    error: Optional[str] = None


@dataclass
class BenchmarkSummary:
    """Aggregated benchmark results."""
    model_id: str = ""
    manifest_path: str = ""
    base_url: str = ""
    eviction_strategy: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    warmup_runs: int = 0
    inference_runs: int = 0
    iterations: list[IterationResult] = field(default_factory=list)
    # Aggregated stats
    avg_total_ms: float = 0.0
    min_total_ms: float = 0.0
    max_total_ms: float = 0.0
    median_total_ms: float = 0.0
    p95_total_ms: float = 0.0
    p99_total_ms: float = 0.0
    total_time_ms: float = 0.0
    # Chunk metrics (sum of measured runs only)
    total_chunks_fetched: int = 0
    total_cache_hits: int = 0
    total_cache_misses: int = 0
    total_bytes_fetched: int = 0
    avg_cache_hit_ratio: float = 0.0
    # Environment
    python_version: str = ""
    platform: str = ""

    def to_dict(self) -> dict[str, Any]:
        import statistics
        return {
            "model_id": self.model_id,
            "manifest_path": self.manifest_path,
            "base_url": self.base_url,
            "eviction_strategy": self.eviction_strategy,
            "timestamp": self.timestamp,
            "warmup_runs": self.warmup_runs,
            "inference_runs": self.inference_runs,
            "summary": {
                "avg_total_ms": round(self.avg_total_ms, 3),
                "min_total_ms": round(self.min_total_ms, 3),
                "max_total_ms": round(self.max_total_ms, 3),
                "median_total_ms": round(self.median_total_ms, 3),
                "p95_total_ms": round(self.p95_total_ms, 3),
                "p99_total_ms": round(self.p99_total_ms, 3),
                "total_time_ms": round(self.total_time_ms, 3),
                "total_chunks_fetched": self.total_chunks_fetched,
                "total_cache_hits": self.total_cache_hits,
                "total_cache_misses": self.total_cache_misses,
                "total_bytes_fetched": self.total_bytes_fetched,
                "avg_cache_hit_ratio": round(self.avg_cache_hit_ratio, 4),
            },
            "iterations": [
                {
                    "iteration": it.iteration,
                    "is_warmup": it.is_warmup,
                    "total_time_ms": round(it.total_time_ms, 3),
                    "compute_time_ms": round(it.compute_time_ms, 3),
                    "stall_time_ms": round(it.stall_time_ms, 3),
                    "chunks_fetched": it.chunks_fetched,
                    "cache_hits": it.cache_hits,
                    "cache_misses": it.cache_misses,
                    "bytes_fetched": it.bytes_fetched,
                    "layers_executed": it.layers_executed,
                    "invariant_violations": it.invariant_violations,
                    "error": it.error,
                }
                for it in self.iterations
            ],
            "environment": {
                "python_version": self.python_version,
                "platform": self.platform,
            },
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


def _compute_aggregates(summary: BenchmarkSummary) -> None:
    """Compute aggregated statistics from measured iteration results."""
    import statistics

    measured = [it for it in summary.iterations if not it.is_warmup and it.error is None]
    if not measured:
        return

    times = [it.total_time_ms for it in measured]
    summary.avg_total_ms = statistics.mean(times)
    summary.min_total_ms = min(times)
    summary.max_total_ms = max(times)
    summary.total_time_ms = sum(times)

    sorted_times = sorted(times)
    n = len(sorted_times)
    summary.median_total_ms = sorted_times[n // 2]
    summary.p95_total_ms = sorted_times[int(n * 0.95)] if n > 1 else sorted_times[-1]
    summary.p99_total_ms = sorted_times[int(n * 0.99)] if n > 1 else sorted_times[-1]

    summary.total_chunks_fetched = sum(it.chunks_fetched for it in measured)
    summary.total_cache_hits = sum(it.cache_hits for it in measured)
    summary.total_cache_misses = sum(it.cache_misses for it in measured)
    summary.total_bytes_fetched = sum(it.bytes_fetched for it in measured)

    total_accesses = summary.total_cache_hits + summary.total_cache_misses
    summary.avg_cache_hit_ratio = (
        summary.total_cache_hits / total_accesses if total_accesses > 0 else 0.0
    )


def _print_summary_table(summary: BenchmarkSummary) -> None:
    """Print a formatted benchmark summary table."""
    measured = [it for it in summary.iterations if not it.is_warmup]
    warmup = [it for it in summary.iterations if it.is_warmup]

    click.echo()
    click.echo(click.style("=" * 72, fg="white"))
    click.echo(click.style("  Rex Inference Benchmark Results", fg="white", bold=True))
    click.echo(click.style("=" * 72, fg="white"))
    click.echo()
    click.echo(f"  Model:              {summary.model_id}")
    click.echo(f"  Base URL:           {summary.base_url}")
    click.echo(f"  Eviction Strategy:  {summary.eviction_strategy}")
    click.echo(f"  Timestamp:          {summary.timestamp}")
    click.echo()

    # Per-run table
    click.echo(click.style("  Per-Run Timing", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 64, fg="cyan"))

    # Header
    click.echo(
        f"  {'Run':>4s}  {'Type':>7s}  {'Total':>10s}  {'Compute':>10s}  "
        f"{'Stall':>10s}  {'Chunks':>7s}  {'Hits':>6s}  {'Miss':>6s}"
    )

    for it in summary.iterations:
        run_type = "warmup" if it.is_warmup else "meas"
        if it.error:
            click.echo(
                f"  {it.iteration:>4d}  {run_type:>7s}  "
                + click.style(f"  ERROR: {it.error}", fg="red")
            )
        else:
            total_str = f"{it.total_time_ms:>8.1f} ms"
            compute_str = f"{it.compute_time_ms:>8.1f} ms"
            stall_str = f"{it.stall_time_ms:>8.1f} ms"
            hit_ratio = (
                f"{it.cache_hits}/{it.cache_hits + it.cache_misses}"
                if (it.cache_hits + it.cache_misses) > 0
                else "0/0"
            )
            click.echo(
                f"  {it.iteration:>4d}  {run_type:>7s}  {total_str}  "
                f"{compute_str}  {stall_str}  "
                f"{it.chunks_fetched:>7d}  {hit_ratio:>6s}"
            )

    click.echo()

    # Aggregated results
    measured_ok = [it for it in measured if it.error is None]
    if measured_ok:
        click.echo(click.style("  Aggregated Statistics", fg="cyan", bold=True))
        click.echo(click.style("  " + "-" * 64, fg="cyan"))

        click.echo(f"  {'Metric':<30s}  {'Value':>20s}")
        click.echo(f"  {'-' * 30}  {'-' * 20}")
        click.echo(f"  {'Measured iterations':<30s}  {len(measured_ok):>20d}")
        click.echo(f"  {'Avg total time':<30s}  {_fmt_ms(summary.avg_total_ms):>20s}")
        click.echo(f"  {'Min total time':<30s}  {_fmt_ms(summary.min_total_ms):>20s}")
        click.echo(f"  {'Max total time':<30s}  {_fmt_ms(summary.max_total_ms):>20s}")
        click.echo(f"  {'Median total time':<30s}  {_fmt_ms(summary.median_total_ms):>20s}")
        click.echo(f"  {'P95 total time':<30s}  {_fmt_ms(summary.p95_total_ms):>20s}")
        click.echo(f"  {'P99 total time':<30s}  {_fmt_ms(summary.p99_total_ms):>20s}")
        click.echo(f"  {'Total benchmark time':<30s}  {_fmt_ms(summary.total_time_ms):>20s}")
        click.echo()

        click.echo(click.style("  Chunk & Cache Metrics", fg="cyan", bold=True))
        click.echo(click.style("  " + "-" * 64, fg="cyan"))
        click.echo(f"  {'Metric':<30s}  {'Value':>20s}")
        click.echo(f"  {'-' * 30}  {'-' * 20}")
        click.echo(f"  {'Total chunks fetched':<30s}  {summary.total_chunks_fetched:>20d}")
        click.echo(f"  {'Total cache hits':<30s}  {summary.total_cache_hits:>20d}")
        click.echo(f"  {'Total cache misses':<30s}  {summary.total_cache_misses:>20d}")
        click.echo(
            f"  {'Avg cache hit ratio':<30s}  "
            f"{summary.avg_cache_hit_ratio:>19.1%}"
        )
        click.echo(
            f"  {'Total bytes fetched':<30s}  "
            f"{_fmt_bytes(summary.total_bytes_fetched):>20s}"
        )

    click.echo()

    # Environment
    click.echo(click.style("  Environment", fg="cyan", bold=True))
    click.echo(click.style("  " + "-" * 64, fg="cyan"))
    click.echo(f"    Python:    {summary.python_version}")
    click.echo(f"    Platform:  {summary.platform}")
    click.echo()


@click.command()
@click.option(
    "--manifest", "-m",
    "manifest_path",
    required=True,
    type=click.Path(exists=True),
    help="Path to the Rex manifest.json file.",
)
@click.option(
    "--base-url",
    default="http://localhost:8080",
    help="Base URL for chunk storage (default: http://localhost:8080).",
)
@click.option(
    "--inferences", "-n",
    default=5,
    type=int,
    help="Number of inference runs to measure (default: 5).",
)
@click.option(
    "--warmup",
    default=1,
    type=int,
    help="Number of warmup runs (default: 1).",
)
@click.option(
    "--eviction-strategy",
    default="retain_n_layers",
    type=click.Choice(["aggressive", "retain_n_layers", "smart", "none"]),
    help="Cache eviction strategy (default: retain_n_layers).",
)
@click.option(
    "--output", "-o",
    "output_path",
    default=None,
    type=click.Path(),
    help="Write JSON results to this file.",
)
@click.option(
    "--cache-size-mb",
    default=256,
    type=int,
    help="Memory cache size in MB (default: 256).",
)
@click.option(
    "--prefetch-window",
    default=4,
    type=int,
    help="Prefetch look-ahead window size (default: 4).",
)
def cli(
    manifest_path: str,
    base_url: str,
    inferences: int,
    warmup: int,
    eviction_strategy: str,
    output_path: Optional[str],
    cache_size_mb: int,
    prefetch_window: int,
) -> None:
    """Run benchmarks on a Rex model.

    Loads a Rex model from a manifest, connects to a chunk server,
    and runs inference benchmarks. Reports per-run timing and
    aggregated statistics.

    \b
    Examples:
        rex-benchmark --manifest ./model/manifest.json
        rex-benchmark -m ./model/manifest.json --base-url http://localhost:9090
        rex-benchmark -m ./model/manifest.json -n 10 --warmup 3
        rex-benchmark -m ./model/manifest.json --output results.json
    """
    import platform

    summary = BenchmarkSummary(
        manifest_path=manifest_path,
        base_url=base_url,
        eviction_strategy=eviction_strategy,
        warmup_runs=warmup,
        inference_runs=inferences,
        python_version=platform.python_version(),
        platform=platform.platform(),
    )

    click.echo(click.style("  Rex Inference Benchmark", fg="white", bold=True))
    click.echo()
    click.echo(f"  Manifest:           {manifest_path}")
    click.echo(f"  Base URL:           {base_url}")
    click.echo(f"  Inferences:         {inferences} (+ {warmup} warmup)")
    click.echo(f"  Eviction Strategy:  {eviction_strategy}")
    click.echo(f"  Cache Size:         {cache_size_mb} MB")
    click.echo(f"  Prefetch Window:    {prefetch_window}")
    click.echo()
    click.echo("  Loading model...", nl=False)

    async def _run_benchmark() -> None:
        from rex.api.config import RexConfig
        from rex.core.runtime import RexRuntime

        config = RexConfig()
        config.storage.base_url = base_url
        config.cache.max_memory_cache_bytes = cache_size_mb * 1024 * 1024
        config.scheduler.eviction_strategy = eviction_strategy
        config.scheduler.prefetch_window = prefetch_window

        runtime = RexRuntime(config=config)

        # Load model
        try:
            await runtime.load_model(manifest_path)
        except Exception as exc:
            click.echo(click.style(f" FAILED", fg="red"))
            click.echo(f"  Error loading model: {exc}", err=True)
            sys.exit(1)

        manifest = runtime.manifest
        if manifest is None:
            click.echo(click.style(f" FAILED", fg="red"))
            click.echo("  Manifest is None after loading", err=True)
            sys.exit(1)

        summary.model_id = manifest.model_id
        click.echo(click.style(f" OK", fg="green"))
        click.echo(f"  Model ID:           {manifest.model_id}")
        click.echo(f"  Model Family:       {manifest.model_family}")
        click.echo(f"  Total Chunks:       {manifest.total_chunks}")
        click.echo(f"  Total Parameters:   {len(manifest.parameters)}")
        click.echo(f"  Model Size:         {_fmt_bytes(manifest.total_model_bytes)}")
        click.echo()

        # Create a dummy input tensor
        # Try to get a reasonable shape from the first parameter
        first_param = next(iter(manifest.parameters.values()), None)
        if first_param and first_param.shape:
            # Use the first parameter's first dimension as input dim
            seq_len = max(16, first_param.shape[0] if first_param.shape[0] > 1 else 16)
        else:
            seq_len = 16

        # Use a simple numpy array or a dict as input
        import numpy as np
        input_data = np.random.randn(1, seq_len).astype(np.float32)

        # Register iteration counter
        run_num = 0

        # Warmup phase
        if warmup > 0:
            click.echo(f"  Running {warmup} warmup iteration(s)...")
            for i in range(warmup):
                run_num += 1
                try:
                    _, metrics = await runtime.run_inference(input_data)
                    summary.iterations.append(IterationResult(
                        iteration=run_num,
                        is_warmup=True,
                        total_time_ms=metrics.total_time_ms,
                        compute_time_ms=metrics.compute_time_ms,
                        stall_time_ms=metrics.stall_time_ms,
                        chunks_fetched=metrics.chunks_fetched,
                        cache_hits=metrics.cache_hits,
                        cache_misses=metrics.cache_misses,
                        bytes_fetched=metrics.bytes_fetched_remote,
                        layers_executed=metrics.layers_executed,
                        invariant_violations=metrics.invariant_violations,
                    ))
                    click.echo(
                        f"    Warmup {i + 1}/{warmup}: "
                        f"{metrics.total_time_ms:.1f} ms"
                    )
                except Exception as exc:
                    summary.iterations.append(IterationResult(
                        iteration=run_num,
                        is_warmup=True,
                        error=str(exc),
                    ))
                    click.echo(
                        f"    Warmup {i + 1}/{warmup}: "
                        + click.style(f"ERROR: {exc}", fg="red")
                    )
            click.echo()

        # Measured phase
        click.echo(f"  Running {inferences} measured iteration(s)...")
        for i in range(inferences):
            run_num += 1
            try:
                start = time.perf_counter()
                _, metrics = await runtime.run_inference(input_data)
                elapsed = (time.perf_counter() - start) * 1000

                summary.iterations.append(IterationResult(
                    iteration=run_num,
                    is_warmup=False,
                    total_time_ms=elapsed,
                    compute_time_ms=metrics.compute_time_ms,
                    stall_time_ms=metrics.stall_time_ms,
                    chunks_fetched=metrics.chunks_fetched,
                    cache_hits=metrics.cache_hits,
                    cache_misses=metrics.cache_misses,
                    bytes_fetched=metrics.bytes_fetched_remote,
                    layers_executed=metrics.layers_executed,
                    invariant_violations=metrics.invariant_violations,
                ))
                click.echo(
                    f"    Run {i + 1}/{inferences}: "
                    f"{elapsed:.1f} ms "
                    f"(compute: {metrics.compute_time_ms:.1f} ms, "
                    f"stall: {metrics.stall_time_ms:.1f} ms, "
                    f"chunks: {metrics.chunks_fetched})"
                )
            except Exception as exc:
                summary.iterations.append(IterationResult(
                    iteration=run_num,
                    is_warmup=False,
                    error=str(exc),
                ))
                click.echo(
                    f"    Run {i + 1}/{inferences}: "
                    + click.style(f"ERROR: {exc}", fg="red")
                )

        # Shutdown runtime
        await runtime.shutdown()

    # Run the benchmark
    asyncio.run(_run_benchmark())

    # Compute aggregates
    _compute_aggregates(summary)

    # Print results
    _print_summary_table(summary)

    # Write JSON output if requested
    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(summary.to_json())
        click.echo(f"  Results saved to: {output_path}")
        click.echo()


if __name__ == "__main__":
    cli()
