"""rex-serve CLI command.

Starts a local HTTP chunk server for serving Rex model weight files
with full HTTP Range support (RFC 7233).

Uses the local_server module from rex.storage.

Status: Implemented
"""

from __future__ import annotations

import asyncio
import os
import signal
import sys
from pathlib import Path

import click


@click.command()
@click.option(
    "--dir", "-d",
    "chunk_dir",
    default=".",
    type=click.Path(exists=True, file_okay=False),
    help="Directory containing chunk files to serve (default: current directory).",
)
@click.option(
    "--host",
    default="0.0.0.0",
    help="Bind host (default: 0.0.0.0).",
)
@click.option(
    "--port", "-p",
    default=8080,
    type=int,
    help="Bind port (default: 8080).",
)
@click.option(
    "--latency",
    default=0.0,
    type=float,
    help="Simulated latency in ms per response (default: 0).",
)
@click.option(
    "--bandwidth",
    default=0.0,
    type=float,
    help="Simulated bandwidth cap in Mbps (default: unlimited).",
)
@click.option(
    "--fault-timeout-rate",
    default=0.0,
    type=float,
    help="Probability of injecting a timeout (0.0-1.0).",
)
@click.option(
    "--fault-error-rate",
    default=0.0,
    type=float,
    help="Probability of injecting an error response (0.0-1.0).",
)
@click.option(
    "--fault-error-status",
    default=500,
    type=int,
    help="HTTP status code for injected errors (default: 500).",
)
def cli(
    chunk_dir: str,
    host: str,
    port: int,
    latency: float,
    bandwidth: float,
    fault_timeout_rate: float,
    fault_error_rate: float,
    fault_error_status: int,
) -> None:
    """Serve Rex chunk files via HTTP with Range support.

    Starts a local HTTP server that serves model weight chunk files
    with full HTTP Range support (RFC 7233), suitable for development,
    testing, and benchmarking.

    \b
    Examples:
        rex-serve --dir ./rex_model/weights
        rex-serve --dir ./chunks --port 9090
        rex-serve --dir ./chunks --latency 50 --bandwidth 10
    """
    # Resolve to absolute path
    abs_dir = str(Path(chunk_dir).resolve())

    if not os.path.isdir(abs_dir):
        click.echo(f"Error: Directory does not exist: {abs_dir}", err=True)
        sys.exit(1)

    # Count files for info
    file_count = 0
    total_size = 0
    for root, _dirs, files in os.walk(abs_dir):
        for f in files:
            fp = os.path.join(root, f)
            file_count += 1
            total_size += os.path.getsize(fp)

    # Build server kwargs
    serve_kwargs: dict = {}
    if latency > 0:
        serve_kwargs["simulated_latency_ms"] = latency
    if bandwidth > 0:
        serve_kwargs["bandwidth_mbps"] = bandwidth

    # Fault injection
    faults = None
    if fault_timeout_rate > 0 or fault_error_rate > 0:
        from rex.storage.local_server import FaultInjector
        faults = FaultInjector(
            timeout_rate=fault_timeout_rate,
            error_rate=fault_error_rate,
            error_status_code=fault_error_status,
        )
        serve_kwargs["faults"] = faults

    # Print startup banner
    click.echo()
    click.echo(click.style("=" * 56, fg="white"))
    click.echo(click.style("  Rex Chunk Server", fg="white", bold=True))
    click.echo(click.style("=" * 56, fg="white"))
    click.echo()
    click.echo(f"  Serving directory:  {abs_dir}")
    click.echo(f"  Host:               {host}")
    click.echo(f"  Port:               {port}")
    click.echo(f"  URL:                http://{host}:{port}")
    click.echo(f"  Files indexed:      {file_count}")
    click.echo(f"  Total size:         {_fmt_bytes(total_size)}")

    if latency > 0:
        click.echo(f"  Simulated latency: {latency} ms")
    if bandwidth > 0:
        click.echo(f"  Bandwidth cap:      {bandwidth} Mbps")
    if faults and (fault_timeout_rate > 0 or fault_error_rate > 0):
        click.echo(f"  Fault injection:    enabled")
        if fault_timeout_rate > 0:
            click.echo(f"    Timeout rate:     {fault_timeout_rate:.1%}")
        if fault_error_rate > 0:
            click.echo(f"    Error rate:       {fault_error_rate:.1%} (HTTP {fault_error_status})")

    click.echo()
    click.echo(click.style("  Health check:", fg="bright_black"))
    click.echo(f"    GET http://{host}:{port}/health")
    click.echo()
    click.echo(click.style("  Press Ctrl+C to stop.", fg="bright_black"))
    click.echo()

    # Start the server
    async def _run() -> None:
        from rex.storage.local_server import start_server, stop_server

        try:
            await start_server(
                host=host,
                port=port,
                chunk_dir=abs_dir,
                **serve_kwargs,
            )
            click.echo(click.style(
                f"  Server started on http://{host}:{port}",
                fg="green",
                bold=True,
            ))
            click.echo()

            # Keep alive until interrupted
            try:
                while True:
                    await asyncio.sleep(3600)
            except asyncio.CancelledError:
                pass
        except KeyboardInterrupt:
            click.echo()
        except FileNotFoundError as exc:
            click.echo(f"Error: {exc}", err=True)
            sys.exit(1)
        except Exception as exc:
            click.echo(f"Error starting server: {exc}", err=True)
            sys.exit(1)
        finally:
            click.echo(click.style("  Shutting down...", fg="yellow"))
            await stop_server()
            click.echo(click.style("  Server stopped.", fg="yellow"))

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        click.echo()
        click.echo(click.style("  Server stopped.", fg="yellow"))


def _fmt_bytes(n: int) -> str:
    """Format byte count as human-readable string."""
    if n == 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(n)
    while size >= 1024.0 and i < len(units) - 1:
        size /= 1024.0
        i += 1
    return f"{size:.1f} {units[i]}"


if __name__ == "__main__":
    cli()
