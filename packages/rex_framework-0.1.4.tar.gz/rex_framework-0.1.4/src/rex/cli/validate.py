"""rex-validate CLI command.

Validates a Rex manifest file with comprehensive checks including:
- Required field presence
- Version compatibility
- Chunk address integrity
- Execution graph consistency
- Byte range validity
- Tensor descriptor consistency
- Optional JSON schema validation

Status: Implemented
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any

import click


@dataclass
class ValidationCheck:
    """A single validation check result."""
    name: str
    status: str  # "PASS", "FAIL", "WARN"
    message: str = ""
    details: str = ""


@dataclass
class ValidationResult:
    """Aggregated result of all validation checks."""
    checks: list[ValidationCheck] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return all(c.status != "FAIL" for c in self.checks)

    @property
    def has_warnings(self) -> bool:
        return any(c.status == "WARN" for c in self.checks)

    def to_dict(self) -> dict[str, Any]:
        return {
            "valid": self.is_valid,
            "has_warnings": self.has_warnings,
            "errors": self.errors,
            "warnings": self.warnings,
            "checks": [
                {
                    "name": c.name,
                    "status": c.status,
                    "message": c.message,
                    "details": c.details,
                }
                for c in self.checks
            ],
        }


def _load_raw_manifest(manifest_path: str) -> dict[str, Any]:
    """Load raw JSON from a manifest file without validation."""
    try:
        with open(manifest_path, "rb") as f:
            return json.loads(f.read().decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise click.ClickException(f"Invalid JSON in manifest: {exc}")
    except OSError as exc:
        raise click.ClickException(f"Cannot read manifest file: {exc}")


def _validate_json_schema(
    raw_data: dict[str, Any],
    schema_path: str | None,
) -> tuple[list[str], list[str]]:
    """Validate raw manifest data against a JSON schema.

    Returns (errors, warnings).
    """
    errors: list[str] = []
    warnings: list[str] = []

    if schema_path is None:
        # Prefer schema bundled inside the installed package.
        bundled_schema = resources.files("rex").joinpath("schemas/rex-manifest.schema.json")
        if bundled_schema.is_file():
            schema_path = str(bundled_schema)
        else:
            # Fallback for repository checkouts.
            project_root = Path(__file__).resolve().parents[3]  # src/rex/cli/ -> project root
            default_schema = project_root / "schemas" / "rex-manifest.schema.json"
            if default_schema.exists():
                schema_path = str(default_schema)
            else:
                warnings.append(
                    "No JSON schema file found in the installed package or repository checkout; "
                    "skipping schema validation"
                )
                return errors, warnings

    try:
        import jsonschema
    except ImportError:
        warnings.append(
            "jsonschema package not installed; skipping schema validation. "
            "Install with: pip install jsonschema"
        )
        return errors, warnings

    try:
        with open(schema_path, "r") as f:
            schema = json.load(f)

        validator_cls = jsonschema.Draft7Validator
        validator = validator_cls(schema)
        schema_errors = sorted(validator.iter_errors(raw_data), key=lambda e: list(e.path))

        if schema_errors:
            for err in schema_errors:
                path_str = ".".join(str(p) for p in err.absolute_path) if err.absolute_path else "(root)"
                errors.append(f"Schema validation: [{path_str}] {err.message}")
        else:
            return errors, warnings

    except FileNotFoundError:
        warnings.append(f"Schema file not found: {schema_path}")
    except json.JSONDecodeError as exc:
        errors.append(f"Invalid JSON in schema file: {exc}")
    except Exception as exc:
        warnings.append(f"Schema validation error: {exc}")

    return errors, warnings


def _validate_manifest_comprehensive(
    raw_data: dict[str, Any],
) -> ValidationResult:
    """Run comprehensive manifest validation using core model_manifest module.

    Parses the manifest and runs all built-in validators, returning
    per-check results.
    """
    result = ValidationResult()

    # ── Check 1: JSON parseability (already done by caller) ──
    result.checks.append(ValidationCheck(
        name="json_parse",
        status="PASS",
        message="Manifest is valid JSON",
    ))

    # ── Check 2: Root structure ──
    if not isinstance(raw_data, dict):
        result.checks.append(ValidationCheck(
            name="root_structure",
            status="FAIL",
            message="Manifest root must be a JSON object",
        ))
        result.errors.append("Manifest root must be a JSON object")
        return result
    result.checks.append(ValidationCheck(
        name="root_structure",
        status="PASS",
        message="Root is a JSON object",
    ))

    # ── Check 3: Required fields ──
    required_fields = [
        "manifest_version", "model_id", "model_family", "source_framework",
    ]
    missing = [f for f in required_fields if f not in raw_data or not raw_data[f]]
    if missing:
        msg = f"Missing required fields: {', '.join(missing)}"
        result.checks.append(ValidationCheck(
            name="required_fields",
            status="FAIL",
            message=msg,
        ))
        result.errors.append(msg)
    else:
        result.checks.append(ValidationCheck(
            name="required_fields",
            status="PASS",
            message="All required fields present",
        ))

    # ── Check 4: Version compatibility ──
    version = raw_data.get("manifest_version", "")
    from rex.core.model_manifest import SUPPORTED_VERSIONS
    if version not in SUPPORTED_VERSIONS:
        msg = (
            f"Unsupported manifest version '{version}'. "
            f"Supported: {sorted(SUPPORTED_VERSIONS)}"
        )
        result.checks.append(ValidationCheck(
            name="version_compatibility",
            status="FAIL",
            message=msg,
        ))
        result.errors.append(msg)
    else:
        result.checks.append(ValidationCheck(
            name="version_compatibility",
            status="PASS",
            message=f"Version {version} is supported",
        ))

    # ── Check 5: Parameters section ──
    parameters = raw_data.get("parameters", {})
    if not isinstance(parameters, dict):
        msg = "'parameters' must be a JSON object"
        result.checks.append(ValidationCheck(
            name="parameters_section",
            status="FAIL",
            message=msg,
        ))
        result.errors.append(msg)
    elif len(parameters) == 0:
        msg = "'parameters' is empty; model has no parameters"
        result.checks.append(ValidationCheck(
            name="parameters_section",
            status="WARN",
            message=msg,
        ))
        result.warnings.append(msg)
    else:
        result.checks.append(ValidationCheck(
            name="parameters_section",
            status="PASS",
            message=f"{len(parameters)} parameter(s) defined",
        ))

    # ── Check 6: Per-parameter validation ──
    if isinstance(parameters, dict):
        param_errors = 0
        for pname, pdata in parameters.items():
            if not isinstance(pdata, dict):
                param_errors += 1
                result.errors.append(f"Parameter '{pname}' is not a JSON object")
                continue
            # shape
            shape = pdata.get("shape", [])
            if not shape or not isinstance(shape, list) or any(d <= 0 for d in shape):
                param_errors += 1
                result.errors.append(f"Parameter '{pname}' has invalid shape: {shape}")
            # dtype
            dtype = pdata.get("dtype", "")
            if not dtype:
                param_errors += 1
                result.errors.append(f"Parameter '{pname}' has empty dtype")
            # num_chunks vs chunk_addresses
            num_chunks = pdata.get("num_chunks", 0)
            chunk_addrs = pdata.get("chunk_addresses", [])
            if num_chunks <= 0:
                param_errors += 1
                result.errors.append(
                    f"Parameter '{pname}' has invalid num_chunks: {num_chunks}"
                )
            elif num_chunks != len(chunk_addrs):
                param_errors += 1
                result.errors.append(
                    f"Parameter '{pname}': num_chunks ({num_chunks}) != "
                    f"chunk_addresses count ({len(chunk_addrs)})"
                )
            # total_bytes
            total_bytes = pdata.get("total_bytes", 0)
            if total_bytes <= 0:
                param_errors += 1
                result.errors.append(
                    f"Parameter '{pname}' has invalid total_bytes: {total_bytes}"
                )
            # Validate individual chunk addresses
            for i, ca in enumerate(chunk_addrs):
                if not isinstance(ca, dict):
                    param_errors += 1
                    result.errors.append(
                        f"Parameter '{pname}' chunk {i} is not a JSON object"
                    )
                    continue
                cid = ca.get("chunk_id", "")
                rid = ca.get("resource_id", "")
                if not cid:
                    param_errors += 1
                    result.errors.append(
                        f"Parameter '{pname}' chunk {i} has empty chunk_id"
                    )
                if not rid:
                    param_errors += 1
                    result.errors.append(
                        f"Parameter '{pname}' chunk {i} has empty resource_id"
                    )
                br = ca.get("byte_range", {})
                if isinstance(br, dict):
                    start = br.get("start", 0)
                    end = br.get("end", 0)
                    if start < 0:
                        param_errors += 1
                        result.errors.append(
                            f"Parameter '{pname}' chunk {i} has negative byte_range start"
                        )
                    if end <= start:
                        param_errors += 1
                        result.errors.append(
                            f"Parameter '{pname}' chunk {i} has invalid byte_range "
                            f"[{start}, {end})"
                        )

        if param_errors == 0 and parameters:
            result.checks.append(ValidationCheck(
                name="parameter_integrity",
                status="PASS",
                message=f"All {len(parameters)} parameter(s) are valid",
            ))
        elif param_errors > 0:
            result.checks.append(ValidationCheck(
                name="parameter_integrity",
                status="FAIL",
                message=f"{param_errors} parameter error(s) found",
            ))

    # ── Check 7: Chunk count consistency ──
    if isinstance(parameters, dict):
        declared_chunks = raw_data.get("total_chunks", 0)
        actual_chunks = sum(
            p.get("num_chunks", 0) for p in parameters.values() if isinstance(p, dict)
        )
        if declared_chunks > 0 and declared_chunks != actual_chunks:
            msg = (
                f"total_chunks ({declared_chunks}) does not match "
                f"sum of parameter chunks ({actual_chunks})"
            )
            result.checks.append(ValidationCheck(
                name="chunk_count_consistency",
                status="FAIL",
                message=msg,
            ))
            result.errors.append(msg)
        else:
            result.checks.append(ValidationCheck(
                name="chunk_count_consistency",
                status="PASS",
                message=f"Total chunks consistent ({actual_chunks})",
            ))

    # ── Check 8: Model size consistency ──
    if isinstance(parameters, dict):
        declared_bytes = raw_data.get("total_model_bytes", 0)
        actual_bytes = sum(
            p.get("total_bytes", 0) for p in parameters.values() if isinstance(p, dict)
        )
        if declared_bytes > 0 and declared_bytes != actual_bytes:
            msg = (
                f"total_model_bytes ({declared_bytes:,}) does not match "
                f"sum of parameter bytes ({actual_bytes:,})"
            )
            result.checks.append(ValidationCheck(
                name="model_size_consistency",
                status="FAIL",
                message=msg,
            ))
            result.errors.append(msg)
        elif declared_bytes <= 0 and actual_bytes > 0:
            msg = (
                f"total_model_bytes is 0 but parameters sum to "
                f"{actual_bytes:,} bytes"
            )
            result.checks.append(ValidationCheck(
                name="model_size_consistency",
                status="WARN",
                message=msg,
            ))
            result.warnings.append(msg)
        else:
            result.checks.append(ValidationCheck(
                name="model_size_consistency",
                status="PASS",
                message=f"Total model bytes consistent ({actual_bytes:,})",
            ))

    # ── Check 9: Execution graph ──
    exec_graph = raw_data.get("execution_graph", [])
    if isinstance(parameters, dict):
        param_names = set(parameters.keys())
        if exec_graph:
            if not isinstance(exec_graph, list):
                msg = "execution_graph must be a list"
                result.checks.append(ValidationCheck(
                    name="execution_graph",
                    status="FAIL",
                    message=msg,
                ))
                result.errors.append(msg)
            else:
                unknown_refs = [s for s in exec_graph if s not in param_names]
                if unknown_refs:
                    msg = (
                        f"execution_graph references unknown parameters: "
                        f"{unknown_refs}"
                    )
                    result.checks.append(ValidationCheck(
                        name="execution_graph",
                        status="FAIL",
                        message=msg,
                    ))
                    result.errors.append(msg)
                else:
                    result.checks.append(ValidationCheck(
                        name="execution_graph",
                        status="PASS",
                        message=f"{len(exec_graph)} layer(s) in graph, all valid",
                    ))
        else:
            msg = "execution_graph is empty; execution order is undefined"
            result.checks.append(ValidationCheck(
                name="execution_graph",
                status="WARN",
                message=msg,
            ))
            result.warnings.append(msg)

    # ── Check 10: Cache constraints ──
    cc = raw_data.get("cache_constraints", {})
    if isinstance(cc, dict):
        frac = cc.get("max_local_fraction_of_model", 0.4)
        if not (0.0 < frac <= 1.0):
            msg = (
                f"max_local_fraction_of_model must be in (0, 1], got {frac}"
            )
            result.checks.append(ValidationCheck(
                name="cache_constraints",
                status="FAIL",
                message=msg,
            ))
            result.errors.append(msg)
        else:
            result.checks.append(ValidationCheck(
                name="cache_constraints",
                status="PASS",
                message=f"Cache fraction {frac:.0%} is valid",
            ))
    else:
        result.checks.append(ValidationCheck(
            name="cache_constraints",
            status="PASS",
            message="Using default cache constraints",
        ))

    # ── Check 11: Feature flags ──
    ff = raw_data.get("feature_flags", {})
    if not isinstance(ff, dict):
        msg = "feature_flags must be a JSON object"
        result.checks.append(ValidationCheck(
            name="feature_flags",
            status="FAIL",
            message=msg,
        ))
        result.errors.append(msg)
    else:
        result.checks.append(ValidationCheck(
            name="feature_flags",
            status="PASS",
            message=f"{len(ff)} feature flag(s) defined",
        ))

    # ── Check 12: Storage backend ──
    backend = raw_data.get("storage_backend", "http_range")
    valid_backends = ["http_range", "local_server", "google_drive", "onedrive", "icloud"]
    if backend not in valid_backends:
        msg = f"Unknown storage backend '{backend}'; expected one of {valid_backends}"
        result.checks.append(ValidationCheck(
            name="storage_backend",
            status="WARN",
            message=msg,
        ))
        result.warnings.append(msg)
    else:
        result.checks.append(ValidationCheck(
            name="storage_backend",
            status="PASS",
            message=f"Storage backend: {backend}",
        ))

    # ── Check 13: Compression codec ──
    compression = raw_data.get("compression", "none")
    valid_codecs = ["none", "lz4", "zstd"]
    if compression not in valid_codecs:
        msg = f"Unknown compression codec '{compression}'; expected one of {valid_codecs}"
        result.checks.append(ValidationCheck(
            name="compression_codec",
            status="WARN",
            message=msg,
        ))
        result.warnings.append(msg)
    else:
        result.checks.append(ValidationCheck(
            name="compression_codec",
            status="PASS",
            message=f"Compression: {compression}",
        ))

    # ── Also run the core validator for additional checks ──
    try:
        from rex.core.model_manifest import deserialize_manifest, validate_manifest
        manifest = deserialize_manifest(json.dumps(raw_data).encode("utf-8"))
        core_errors = validate_manifest(manifest)
        # Only add errors not already captured
        existing = set(result.errors)
        for err in core_errors:
            if err not in existing:
                result.errors.append(err)
    except Exception as exc:
        result.errors.append(f"Core validation error: {exc}")

    return result


@click.command()
@click.argument("manifest_path", type=click.Path(exists=True))
@click.option(
    "--schema",
    "schema_path",
    default=None,
    type=click.Path(exists=False),
    help="Path to JSON schema file. If omitted, tries schemas/rex-manifest.schema.json",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output validation results as JSON.",
)
@click.option(
    "--strict",
    is_flag=True,
    help="Fail (exit 1) if any warnings are present.",
)
def cli(
    manifest_path: str,
    schema_path: str | None,
    output_json: bool,
    strict: bool,
) -> None:
    """Validate a Rex manifest file.

    Runs comprehensive validation checks on a Rex manifest, including
    required field presence, version compatibility, chunk integrity,
    execution graph consistency, and more.

    \b
    Examples:
        rex-validate ./rex_model/manifest.json
        rex-validate ./rex_model/manifest.json --schema my-schema.json
        rex-validate ./rex_model/manifest.json --json
        rex-validate ./rex_model/manifest.json --strict
    """
    # Load raw manifest
    try:
        raw_data = _load_raw_manifest(manifest_path)
    except click.ClickException:
        raise

    # Run comprehensive validation
    result = _validate_manifest_comprehensive(raw_data)

    # Optionally run JSON schema validation
    if schema_path or True:  # Always try schema validation
        effective_schema = schema_path
        schema_errors, schema_warnings = _validate_json_schema(
            raw_data, effective_schema
        )
        result.errors.extend(schema_errors)
        result.warnings.extend(schema_warnings)

        if schema_errors:
            result.checks.append(ValidationCheck(
                name="json_schema",
                status="FAIL",
                message=f"{len(schema_errors)} schema error(s)",
            ))
        elif schema_warnings and any("not found" in w or "not installed" in w for w in schema_warnings):
            pass  # Don't add a check if schema wasn't found
        else:
            result.checks.append(ValidationCheck(
                name="json_schema",
                status="PASS",
                message="Manifest validates against JSON schema",
            ))

    # Determine exit condition
    should_fail = not result.is_valid
    if strict and result.has_warnings:
        should_fail = True

    # Output
    if output_json:
        click.echo(json.dumps(result.to_dict(), indent=2))
    else:
        _print_human_readable(result, manifest_path)

    if should_fail:
        sys.exit(1)


def _print_human_readable(result: ValidationResult, path: str) -> None:
    """Print a human-readable validation report."""
    click.echo(click.style("=" * 60, fg="white"))
    click.echo(click.style("  Rex Manifest Validation", fg="white", bold=True))
    click.echo(click.style("=" * 60, fg="white"))
    click.echo(f"  File: {path}")
    click.echo()

    # Print each check
    for check in result.checks:
        if check.status == "PASS":
            icon = click.style("  PASS", fg="green")
        elif check.status == "FAIL":
            icon = click.style("  FAIL", fg="red", bold=True)
        else:
            icon = click.style("  WARN", fg="yellow")

        name_str = click.style(check.name, bold=True)
        click.echo(f"  {icon}  {name_str}: {check.message}")
        if check.details:
            click.echo(f"        {check.details}")

    click.echo()

    # Summary
    total = len(result.checks)
    passed = sum(1 for c in result.checks if c.status == "PASS")
    failed = sum(1 for c in result.checks if c.status == "FAIL")
    warned = sum(1 for c in result.checks if c.status == "WARN")

    if result.is_valid and not result.has_warnings:
        click.echo(
            click.style(
                f"  Validation passed: {passed}/{total} checks passed",
                fg="green",
                bold=True,
            )
        )
    elif result.is_valid and result.has_warnings:
        click.echo(
            click.style(
                f"  Validation passed with warnings: "
                f"{passed} passed, {warned} warning(s)",
                fg="yellow",
                bold=True,
            )
        )
    else:
        click.echo(
            click.style(
                f"  Validation FAILED: {failed} error(s), "
                f"{passed} passed, {warned} warning(s)",
                fg="red",
                bold=True,
            )
        )

    # Print errors
    if result.errors:
        click.echo()
        click.echo(click.style("  Errors:", fg="red", bold=True))
        for err in result.errors:
            click.echo(click.style(f"    - {err}", fg="red"))

    # Print warnings
    if result.warnings:
        click.echo()
        click.echo(click.style("  Warnings:", fg="yellow", bold=True))
        for warn in result.warnings:
            click.echo(click.style(f"    - {warn}", fg="yellow"))

    click.echo()


if __name__ == "__main__":
    cli()
