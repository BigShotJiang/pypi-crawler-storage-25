"""Chunk writer for Rex format.

Status: Implemented

Writes model parameter tensors as fixed-size chunks to disk,
producing a deterministic binary layout with per-chunk checksums.
"""

from __future__ import annotations

import os
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, BinaryIO, Optional

import numpy as np

from rex.formats.compression import compress, CompressionCodec
from rex.formats.hashing import compute_chunk_id, compute_sha256
from rex.core.types import (
    ByteRange,
    ChunkAddress,
    ChunkMetadata,
    CompressionCodec as TCCompressionCodec,
)


@dataclass
class ChunkWriteResult:
    """Result of writing a single chunk."""
    chunk_id: str
    resource_id: str
    byte_range: ByteRange
    checksum_sha256: str
    uncompressed_size: int
    compressed_size: int
    compression: TCCompressionCodec


@dataclass
class TensorWriteResult:
    """Result of writing all chunks for a single tensor."""
    param_name: str
    shape: tuple[int, ...]
    dtype: str
    num_chunks: int
    chunks: list[ChunkWriteResult] = field(default_factory=list)
    total_bytes: int = 0


class ChunkWriter:
    """Writes model parameters as fixed-size chunks to a directory.

    Each parameter tensor is written as one or more fixed-size binary files.
    Chunks are named: {sanitized_param_name}.{chunk_index:04d}.bin

    The writer produces deterministic output: the same input always
    produces the same output files and checksums.

    Args:
        output_dir: Directory to write chunk files into.
        chunk_size_bytes: Target size for each chunk in bytes (default 512 KB).
        compression: Compression codec to apply.
        per_chunk_compression: If True, chunk first then compress each chunk
            individually (enables per-chunk decompression on fetch).  If False
            (default), compress the full tensor then chunk the compressed stream.
    """

    def __init__(
        self,
        output_dir: str | Path,
        chunk_size_bytes: int = 524_288,  # 512 KB
        compression: TCCompressionCodec = TCCompressionCodec.NONE,
        per_chunk_compression: bool = False,
    ) -> None:
        self.output_dir = Path(output_dir)
        self.chunk_size_bytes = chunk_size_bytes
        self.compression = compression
        self.per_chunk_compression = per_chunk_compression
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def write_tensor(
        self,
        param_name: str,
        data: bytes,
        resource_id_prefix: str = "",
    ) -> TensorWriteResult:
        """Write a parameter tensor as chunks.

        Args:
            param_name: Name of the parameter (e.g., "layers.0.w_q").
            data: Raw bytes of the tensor (row-major, numpy-compatible).
            resource_id_prefix: Prefix for resource IDs (e.g., directory path).

        Returns:
            TensorWriteResult with metadata for all chunks written.
        """
        chunks: list[ChunkWriteResult] = []
        total_size = len(data)

        if total_size == 0:
            return TensorWriteResult(
                param_name=param_name,
                shape=(),
                dtype="",
                num_chunks=0,
                total_bytes=0,
            )

        # Apply compression to full data first, then chunk
        # This is simpler than per-chunk compression and produces
        # deterministic output. Per-chunk compression is a future option.
        if self.per_chunk_compression and self.compression != TCCompressionCodec.NONE:
            # Per-chunk mode: chunk first, then compress each chunk
            num_chunks = max(1, (total_size + self.chunk_size_bytes - 1) // self.chunk_size_bytes)
        elif self.compression != TCCompressionCodec.NONE:
            # Full-tensor mode: compress first, then chunk the compressed stream
            full_compressed = compress(data, self.compression)
            num_chunks = max(1, (len(full_compressed) + self.chunk_size_bytes - 1) // self.chunk_size_bytes)
        else:
            full_compressed = None
            num_chunks = max(1, (total_size + self.chunk_size_bytes - 1) // self.chunk_size_bytes)

        safe_name = param_name.replace("/", "__").replace("\\", "__")

        for i in range(num_chunks):
            offset = i * self.chunk_size_bytes
            if self.per_chunk_compression and self.compression != TCCompressionCodec.NONE:
                # Per-chunk: extract raw slice, then compress
                end = min(offset + self.chunk_size_bytes, total_size)
                raw_chunk = data[offset:end]
                chunk_data = compress(raw_chunk, self.compression)
            elif self.compression != TCCompressionCodec.NONE:
                # Full-tensor: slice from the compressed stream
                end = min(offset + self.chunk_size_bytes, len(full_compressed))
                chunk_data = full_compressed[offset:end]
            else:
                end = min(offset + self.chunk_size_bytes, total_size)
                chunk_data = data[offset:end]

            chunk_id = compute_chunk_id(param_name, i, num_chunks)
            filename = f"{safe_name}.{i:04d}.bin"
            filepath = self.output_dir / filename
            resource_id = str(filepath) if not resource_id_prefix else f"{resource_id_prefix}/{filename}"

            filepath.write_bytes(chunk_data)

            # Checksum is of the raw chunk file contents (which may be compressed)
            checksum = compute_sha256(chunk_data)

            chunk_result = ChunkWriteResult(
                chunk_id=chunk_id,
                resource_id=resource_id,
                byte_range=ByteRange(start=0, end=len(chunk_data)),
                checksum_sha256=checksum,
                uncompressed_size=(
                    (end - offset) if not self.per_chunk_compression
                    or self.compression == TCCompressionCodec.NONE
                    else (end - offset)
                ),
                compressed_size=len(chunk_data),
                compression=self.compression,
            )
            chunks.append(chunk_result)

        # For compressed data: first chunk stores the full uncompressed size,
        # other chunks store 0 (the decompressor handles reconstruction).
        # For per-chunk compression each chunk already has its own size.
        if self.compression == TCCompressionCodec.NONE:
            for i, chunk in enumerate(chunks):
                chunk.uncompressed_size = chunk.compressed_size
        elif self.per_chunk_compression:
            # Each chunk's uncompressed_size is already set correctly above
            pass
        else:
            # Full-tensor compression: only first chunk has total size
            for i, chunk in enumerate(chunks):
                chunk.uncompressed_size = total_size if i == 0 else 0

        return TensorWriteResult(
            param_name=param_name,
            shape=(),
            dtype="",
            num_chunks=num_chunks,
            chunks=chunks,
            total_bytes=total_size,
        )

    def write_numpy(
        self,
        param_name: str,
        array: np.ndarray,
        resource_id_prefix: str = "",
    ) -> TensorWriteResult:
        """Write a numpy array as chunks.

        The array is serialized in C-contiguous (row-major) order.

        Args:
            param_name: Name of the parameter.
            array: numpy array to write.
            resource_id_prefix: Prefix for resource IDs.

        Returns:
            TensorWriteResult with shape and dtype metadata.
        """
        # Ensure C-contiguous for deterministic output
        arr = np.ascontiguousarray(array)
        data = arr.tobytes()

        result = self.write_tensor(param_name, data, resource_id_prefix)
        result.shape = tuple(arr.shape)
        result.dtype = str(arr.dtype)
        return result
