"""Compression utilities for Rex chunk storage.

Status: Implemented

Supports:
- NONE: no compression
- LZ4: fast block compression (recommended for development)
- ZSTD: higher ratio compression (recommended for production)
"""

from __future__ import annotations

import struct
from enum import Enum
from typing import Optional

from rex.core.errors import RexError
from rex.core.types import CompressionCodec


class CompressionError(RexError):
    """Error during compression or decompression."""


# Magic bytes prefix: 2-byte codec ID + 4-byte uncompressed length
_HEADER_FORMAT = ">2sI"  # 2-char codec + uint32
_HEADER_SIZE = struct.calcsize(_HEADER_FORMAT)

_CODEC_MAGIC = {
    CompressionCodec.NONE: b"NZ",
    CompressionCodec.LZ4: b"L4",
    CompressionCodec.ZSTD: b"ZS",
}
_MAGIC_CODEC = {v: k for k, v in _CODEC_MAGIC.items()}


def compress(data: bytes, codec: CompressionCodec = CompressionCodec.NONE) -> bytes:
    """Compress data with the specified codec.

    Output format: [2-byte magic][4-byte uncompressed_len][compressed_payload]

    Args:
        data: Raw bytes to compress.
        codec: Compression codec to use.

    Returns:
        Compressed bytes with header.

    Raises:
        CompressionError: If compression fails.
    """
    if codec == CompressionCodec.NONE or len(data) == 0:
        header = struct.pack(_HEADER_FORMAT, _CODEC_MAGIC[CompressionCodec.NONE], len(data))
        return header + data

    try:
        if codec == CompressionCodec.LZ4:
            import lz4.block
            compressed = lz4.block.compress(data, store_size=False)
        elif codec == CompressionCodec.ZSTD:
            import zstandard as zstd
            cctx = zstd.ZstdCompressor(level=3)
            compressed = cctx.compress(data)
        else:
            raise CompressionError(f"Unsupported codec: {codec}")
    except ImportError as e:
        raise CompressionError(
            f"Codec {codec.value} requires additional package: {e}. "
            f"Install with: pip install rex-framework[{codec.value}]"
        ) from e
    except Exception as e:
        raise CompressionError(f"Compression with {codec.value} failed: {e}") from e

    header = struct.pack(_HEADER_FORMAT, _CODEC_MAGIC[codec], len(data))
    return header + compressed


def decompress(data: bytes) -> tuple[bytes, CompressionCodec]:
    """Decompress data, auto-detecting codec from header.

    Args:
        data: Compressed bytes with header.

    Returns:
        Tuple of (decompressed_bytes, codec_used).

    Raises:
        CompressionError: If decompression fails or format is unrecognized.
    """
    if len(data) < _HEADER_SIZE:
        raise CompressionError(
            f"Data too short for compression header: {len(data)} < {_HEADER_SIZE}"
        )

    magic_raw, uncompressed_len = struct.unpack(_HEADER_FORMAT, data[:_HEADER_SIZE])
    codec = _MAGIC_CODEC.get(magic_raw)
    if codec is None:
        raise CompressionError(f"Unrecognized compression magic: {magic_raw!r}")

    payload = data[_HEADER_SIZE:]

    if codec == CompressionCodec.NONE:
        if len(payload) != uncompressed_len:
            raise CompressionError(
                f"Length mismatch: header says {uncompressed_len}, got {len(payload)}"
            )
        return payload, codec

    try:
        if codec == CompressionCodec.LZ4:
            import lz4.block
            result = lz4.block.decompress(payload, uncompressed_size=uncompressed_len)
        elif codec == CompressionCodec.ZSTD:
            import zstandard as zstd
            dctx = zstd.ZstdDecompressor()
            result = dctx.decompress(payload, max_output_size=uncompressed_len + 1024)
        else:
            raise CompressionError(f"Cannot decompress codec: {codec}")
    except Exception as e:
        if isinstance(e, CompressionError):
            raise
        raise CompressionError(f"Decompression with {codec.value} failed: {e}") from e

    if len(result) != uncompressed_len:
        raise CompressionError(
            f"Decompressed size mismatch: expected {uncompressed_len}, got {len(result)}"
        )
    return result, codec


def detect_codec(data: bytes) -> Optional[CompressionCodec]:
    """Detect compression codec from data header without decompressing.

    Returns None if data is too short or has unrecognized header.
    """
    if len(data) < _HEADER_SIZE:
        return None
    magic_raw = struct.unpack(_HEADER_FORMAT, data[:_HEADER_SIZE])[0]
    return _MAGIC_CODEC.get(magic_raw)


def compression_ratio(original_size: int, compressed_size: int) -> float:
    """Calculate compression ratio (original / compressed).

    Returns 1.0 if compressed_size is 0 to avoid division by zero.
    """
    if compressed_size == 0:
        return 1.0
    return original_size / compressed_size
