"""Checksum utilities for Rex chunk integrity verification.

Status: Implemented

Uses SHA-256 as the primary checksum algorithm. All chunk integrity
verification uses SHA-256 hashes stored in the manifest.
"""

from __future__ import annotations

import hashlib
from typing import Optional


def compute_sha256(data: bytes) -> str:
    """Compute SHA-256 hex digest of data.

    Args:
        data: Raw bytes to hash.

    Returns:
        64-character lowercase hex string.
    """
    return hashlib.sha256(data).hexdigest()


def verify_sha256(data: bytes, expected: str) -> bool:
    """Verify data against an expected SHA-256 hex digest.

    Args:
        data: Raw bytes to verify.
        expected: Expected 64-character hex digest.

    Returns:
        True if digest matches.

    Raises:
        ValueError: If expected is not a valid hex digest.
    """
    if len(expected) != 64:
        raise ValueError(
            f"Expected SHA-256 digest to be 64 hex chars, got {len(expected)}"
        )
    try:
        int(expected, 16)
    except ValueError as e:
        raise ValueError(f"Invalid hex digest: {expected}") from e

    actual = compute_sha256(data)
    return actual == expected


def compute_chunk_id(
    param_name: str,
    chunk_index: int,
    total_chunks: int,
) -> str:
    """Generate a deterministic chunk ID from parameter name and index.

    Format: {param_name}.{chunk_index:04d}

    This is human-readable and sortable. The total_chunks parameter
    is not used in the ID but is kept for API consistency.

    Args:
        param_name: Name of the model parameter (e.g., "layers.0.attention.w_q").
        chunk_index: Zero-based index of this chunk within the parameter.
        total_chunks: Total number of chunks for this parameter.

    Returns:
        Deterministic chunk ID string.
    """
    return f"{param_name}.{chunk_index:04d}"
