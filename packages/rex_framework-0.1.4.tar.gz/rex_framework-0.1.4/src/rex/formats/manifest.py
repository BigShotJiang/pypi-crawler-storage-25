"""Manifest format implementation for Rex.

Status: Implemented

Handles serialization/deserialization of RexManifest to/from JSON,
with schema validation and version compatibility checking.

Design Decision (ADR-0002):
The manifest uses JSON for human readability and debuggability.
A future binary manifest format may be added for performance, but
the JSON format is the canonical interchange format for v0.1.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from rex.core.errors import ManifestValidationError, ManifestVersionError
from rex.core.types import (
    BackendStatus,
    ByteRange,
    CacheConstraints,
    ChunkAddress,
    ChunkMetadata,
    CompressionCodec,
    RexManifest,
    StorageBackendType,
    TensorDescriptor,
)


# Supported manifest versions (in order of precedence)
SUPPORTED_VERSIONS = ["0.1.0"]
CURRENT_VERSION = "0.1.0"


class ManifestSerializer:
    """Serialize and deserialize RexManifest to/from JSON.

    Handles conversion between dataclass types and JSON-compatible
    dicts, including nested structures and enums.
    """

    @staticmethod
    def to_dict(manifest: RexManifest) -> dict[str, Any]:
        """Convert manifest to JSON-serializable dict."""
        params = {}
        for name, td in manifest.parameters.items():
            params[name] = {
                "name": td.name,
                "shape": list(td.shape),
                "dtype": td.dtype,
                "num_chunks": td.num_chunks,
                "total_bytes": td.total_bytes,
                "quantization": td.quantization,
                "chunk_addresses": [
                    {
                        "resource_id": ca.resource_id,
                        "byte_range": {
                            "start": ca.byte_range.start,
                            "end": ca.byte_range.end,
                        },
                        "chunk_id": ca.chunk_id,
                    }
                    for ca in td.chunk_addresses
                ],
            }

        return {
            "manifest_version": manifest.manifest_version,
            "model_id": manifest.model_id,
            "model_family": manifest.model_family,
            "source_framework": manifest.source_framework,
            "parameters": params,
            "total_model_bytes": manifest.total_model_bytes,
            "total_chunks": manifest.total_chunks,
            "default_chunk_size": manifest.default_chunk_size,
            "storage_backend": manifest.storage_backend.value,
            "compression": manifest.compression.value,
            "cache_constraints": {
                "max_local_fraction_of_model": manifest.cache_constraints.max_local_fraction_of_model,
                "max_memory_cache_bytes": manifest.cache_constraints.max_memory_cache_bytes,
                "max_disk_cache_bytes": manifest.cache_constraints.max_disk_cache_bytes,
                "enforce_invariant": manifest.cache_constraints.enforce_invariant,
            },
            "execution_graph": manifest.execution_graph,
            "backend_requirements": manifest.backend_requirements,
            "feature_flags": manifest.feature_flags,
            "provenance": manifest.provenance,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

    @staticmethod
    def from_dict(data: dict[str, Any]) -> RexManifest:
        """Convert JSON dict to RexManifest.

        Raises:
            ManifestValidationError: If required fields are missing or invalid.
        """
        # Validate required fields
        required = ["manifest_version", "model_id", "model_family", "source_framework"]
        for field_name in required:
            if field_name not in data:
                raise ManifestValidationError(
                    f"Missing required manifest field: {field_name}"
                )

        # Parse parameters
        parameters: dict[str, TensorDescriptor] = {}
        for name, pdata in data.get("parameters", {}).items():
            chunk_addrs = []
            for ca_data in pdata.get("chunk_addresses", []):
                br = ca_data["byte_range"]
                chunk_addrs.append(ChunkAddress(
                    resource_id=ca_data["resource_id"],
                    byte_range=ByteRange(start=br["start"], end=br["end"]),
                    chunk_id=ca_data["chunk_id"],
                ))

            parameters[name] = TensorDescriptor(
                name=name,
                shape=tuple(pdata["shape"]),
                dtype=pdata["dtype"],
                num_chunks=pdata["num_chunks"],
                chunk_addresses=chunk_addrs,
                total_bytes=pdata.get("total_bytes", 0),
                quantization=pdata.get("quantization"),
            )

        # Parse cache constraints
        cc_data = data.get("cache_constraints", {})
        cache_constraints = CacheConstraints(
            max_local_fraction_of_model=cc_data.get(
                "max_local_fraction_of_model", 0.4
            ),
            max_memory_cache_bytes=cc_data.get("max_memory_cache_bytes", 0),
            max_disk_cache_bytes=cc_data.get("max_disk_cache_bytes", 0),
            enforce_invariant=cc_data.get("enforce_invariant", True),
        )

        # Parse enums with fallback
        try:
            backend = StorageBackendType(data.get("storage_backend", "http_range"))
        except ValueError:
            backend = StorageBackendType.HTTP_RANGE

        try:
            compression = CompressionCodec(data.get("compression", "none"))
        except ValueError:
            compression = CompressionCodec.NONE

        return RexManifest(
            manifest_version=data["manifest_version"],
            model_id=data["model_id"],
            model_family=data["model_family"],
            source_framework=data["source_framework"],
            parameters=parameters,
            total_model_bytes=data.get("total_model_bytes", 0),
            total_chunks=data.get("total_chunks", 0),
            default_chunk_size=data.get("default_chunk_size", 524288),
            storage_backend=backend,
            compression=compression,
            cache_constraints=cache_constraints,
            execution_graph=data.get("execution_graph", []),
            backend_requirements=data.get("backend_requirements", {}),
            feature_flags=data.get("feature_flags", {}),
            provenance=data.get("provenance", {}),
        )

    @staticmethod
    def serialize(manifest: RexManifest) -> bytes:
        """Serialize manifest to JSON bytes."""
        return json.dumps(
            ManifestSerializer.to_dict(manifest), indent=2, ensure_ascii=False
        ).encode("utf-8")

    @staticmethod
    def deserialize(data: bytes | str) -> RexManifest:
        """Deserialize manifest from JSON bytes or string."""
        if isinstance(data, bytes):
            text = data.decode("utf-8")
        else:
            text = data
        return ManifestSerializer.from_dict(json.loads(text))


def validate_manifest(manifest: RexManifest) -> list[str]:
    """Validate a manifest and return a list of error messages.

    Returns an empty list if the manifest is valid.

    Checks:
    - Version compatibility
    - Required fields present
    - Parameter shapes are valid
    - Execution graph references valid parameters
    - Chunk addresses are internally consistent
    """
    errors: list[str] = []

    # Version check
    if manifest.manifest_version not in SUPPORTED_VERSIONS:
        errors.append(
            f"Unsupported manifest version '{manifest.manifest_version}'. "
            f"Supported: {SUPPORTED_VERSIONS}"
        )

    # Parameter consistency
    total_param_bytes = 0
    total_chunks = 0
    for name, td in manifest.parameters.items():
        if not td.shape:
            errors.append(f"Parameter '{name}' has empty shape")
        if td.num_chunks == 0:
            errors.append(f"Parameter '{name}' has 0 chunks")
        if len(td.chunk_addresses) != td.num_chunks:
            errors.append(
                f"Parameter '{name}': {len(td.chunk_addresses)} chunk addresses "
                f"but num_chunks={td.num_chunks}"
            )
        # Verify byte ranges are non-empty
        for ca in td.chunk_addresses:
            if ca.byte_range.size <= 0:
                errors.append(
                    f"Parameter '{name}', chunk '{ca.chunk_id}': "
                    f"empty byte range {ca.byte_range.start}-{ca.byte_range.end}"
                )
        total_param_bytes += td.total_bytes
        total_chunks += td.num_chunks

    # Byte total consistency
    if manifest.total_model_bytes > 0 and manifest.total_model_bytes != total_param_bytes:
        errors.append(
            f"total_model_bytes ({manifest.total_model_bytes}) does not match "
            f"sum of parameter bytes ({total_param_bytes})"
        )
    if manifest.total_chunks > 0 and manifest.total_chunks != total_chunks:
        errors.append(
            f"total_chunks ({manifest.total_chunks}) does not match "
            f"sum of parameter chunks ({total_chunks})"
        )

    # Execution graph references
    param_names = set(manifest.parameters.keys())
    for step_name in manifest.execution_graph:
        if step_name not in param_names:
            errors.append(
                f"Execution graph references unknown parameter: '{step_name}'"
            )

    # Cache constraints
    cc = manifest.cache_constraints
    if not (0.0 < cc.max_local_fraction_of_model <= 1.0):
        errors.append(
            f"max_local_fraction_of_model must be in (0, 1], "
            f"got {cc.max_local_fraction_of_model}"
        )

    return errors


def load_manifest(path: str | Path) -> RexManifest:
    """Load a manifest from a JSON file.

    Args:
        path: Path to the manifest JSON file.

    Returns:
        Parsed RexManifest.

    Raises:
        FileNotFoundError: If the manifest file does not exist.
        ManifestValidationError: If validation fails.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Manifest not found: {path}")

    data = p.read_bytes()
    manifest = ManifestSerializer.deserialize(data)

    errors = validate_manifest(manifest)
    if errors:
        raise ManifestValidationError(
            f"Manifest validation failed with {len(errors)} errors:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    return manifest


def save_manifest(manifest: RexManifest, path: str | Path) -> None:
    """Save a manifest to a JSON file.

    Args:
        manifest: The manifest to save.
        path: Output file path.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(ManifestSerializer.serialize(manifest))


def pretty_print_manifest(manifest: RexManifest) -> str:
    """Generate a human-readable summary of a manifest."""
    lines = [
        f"Rex Manifest v{manifest.manifest_version}",
        f"  Model ID:        {manifest.model_id}",
        f"  Model Family:    {manifest.model_family}",
        f"  Source:          {manifest.source_framework}",
        f"  Storage:         {manifest.storage_backend.value}",
        f"  Compression:     {manifest.compression.value}",
        f"  Total Size:      {_fmt_bytes(manifest.total_model_bytes)}",
        f"  Total Chunks:    {manifest.total_chunks}",
        f"  Chunk Size:      {_fmt_bytes(manifest.default_chunk_size)}",
        f"  Parameters:      {len(manifest.parameters)}",
        f"  Exec Graph:      {len(manifest.execution_graph)} steps",
        f"  Cache Limit:     {manifest.cache_constraints.max_local_fraction_of_model:.0%} local",
        "",
        "  Parameters:",
    ]

    for name, td in sorted(manifest.parameters.items()):
        chunks_str = f"{td.num_chunks} chunks" if td.num_chunks > 0 else "no chunks"
        lines.append(
            f"    {name:<40s}  {str(td.shape):<20s}  {td.dtype:<10s}  "
            f"{_fmt_bytes(td.total_bytes):>10s}  {chunks_str}"
        )

    lines.extend([
        "",
        "  Feature Flags:",
    ])
    for flag, enabled in manifest.feature_flags.items():
        status = "ON" if enabled else "OFF"
        lines.append(f"    {flag:<30s}  {status}")

    return "\n".join(lines)


def _fmt_bytes(n: int) -> str:
    """Format byte count as human-readable string."""
    if n == 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(n)
    while size >= 1024.0 and i < len(units) - 1:
        size /= 1024.0
        i += 1
    return f"{size:.1f} {units[i]}"
