"""Chunk reader for Rex format.

Status: Implemented

Reads and reassembles chunked model parameter data from disk or
from fetched byte ranges. Handles decompression and integrity verification.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Optional

import numpy as np

from rex.core.errors import ChunkIntegrityError
from rex.core.types import ChunkMetadata, CompressionCodec
from rex.formats.compression import decompress, detect_codec, CompressionError
from rex.formats.hashing import verify_sha256


@dataclass
class ChunkReadResult:
    """Result of reading a single chunk."""
    chunk_id: str
    data: bytes
    decompressed_size: int
    from_cache: bool = False


class ChunkReader:
    """Reads and reassembles chunked tensor data.

    Supports reading individual chunks from local files and
    reassembling full tensors from multiple chunks.

    Args:
        verify_checksums: If True, verify SHA-256 on every read.
    """

    def __init__(self, verify_checksums: bool = True) -> None:
        self.verify_checksums = verify_checksums

    def read_chunk_file(
        self,
        filepath: str | Path,
        metadata: Optional[ChunkMetadata] = None,
    ) -> bytes:
        """Read a single chunk file from disk.

        Args:
            filepath: Path to the chunk file.
            metadata: Optional metadata for checksum verification.

        Returns:
            Raw chunk bytes.

        Raises:
            FileNotFoundError: If chunk file does not exist.
            ChunkIntegrityError: If checksum verification fails.
            CompressionError: If decompression fails.
        """
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"Chunk file not found: {filepath}")

        data = path.read_bytes()

        if metadata and self.verify_checksums:
            if not verify_sha256(data, metadata.checksum_sha256):
                actual = __import__("hashlib").sha256(data).hexdigest()
                raise ChunkIntegrityError(metadata.chunk_id, metadata.checksum_sha256, actual)

        return data

    def read_chunk_bytes(
        self,
        data: bytes,
        metadata: Optional[ChunkMetadata] = None,
    ) -> bytes:
        """Process raw chunk bytes (from storage backend or cache).

        Handles checksum verification. Note: compression is handled
        at a higher level (during tensor reassembly), not per-chunk,
        since our current format compresses the full tensor then chunks.

        Args:
            data: Raw chunk bytes.
            metadata: Optional metadata for checksum verification.

        Returns:
            Verified chunk bytes.

        Raises:
            ChunkIntegrityError: If checksum verification fails.
        """
        if metadata and self.verify_checksums:
            if not verify_sha256(data, metadata.checksum_sha256):
                actual = __import__("hashlib").sha256(data).hexdigest()
                raise ChunkIntegrityError(metadata.chunk_id, metadata.checksum_sha256, actual)

        return data

    def reassemble_tensor(
        self,
        chunks: list[bytes],
        metadata_chunks: Optional[list[ChunkMetadata]] = None,
        compression: CompressionCodec = CompressionCodec.NONE,
        dtype: Optional[str] = None,
        shape: Optional[tuple[int, ...]] = None,
    ) -> bytes:
        """Reassemble a full tensor from chunk data.

        Concatenates chunks in order and applies decompression if needed.

        Args:
            chunks: Ordered list of chunk byte arrays.
            metadata_chunks: Optional metadata for each chunk (for checksums).
            compression: Compression codec used (if any).
            dtype: Target numpy dtype (for numpy output).
            shape: Target shape (for numpy output).

        Returns:
            Reassembled tensor as bytes (or numpy array if dtype+shape given).

        Raises:
            ChunkIntegrityError: If any chunk fails checksum verification.
            CompressionError: If decompression fails.
        """
        if not chunks:
            raise ValueError("Cannot reassemble tensor from empty chunk list")

        # Verify checksums if metadata provided
        if metadata_chunks and self.verify_checksums:
            if len(chunks) != len(metadata_chunks):
                raise ValueError(
                    f"Chunk count mismatch: {len(chunks)} chunks vs "
                    f"{len(metadata_chunks)} metadata entries"
                )
            for i, (chunk_data, meta) in enumerate(zip(chunks, metadata_chunks)):
                if not verify_sha256(chunk_data, meta.checksum_sha256):
                    actual = __import__("hashlib").sha256(chunk_data).hexdigest()
                    raise ChunkIntegrityError(
                        meta.chunk_id, meta.checksum_sha256, actual
                    )

        # Concatenate all chunks
        full_data = b"".join(chunks)

        # Decompress if needed
        if compression != CompressionCodec.NONE and len(full_data) > 0:
            full_data, detected_codec = decompress(full_data)
            if detected_codec != compression:
                raise CompressionError(
                    f"Compression codec mismatch: expected {compression}, "
                    f"detected {detected_codec}"
                )

        return full_data

    def reassemble_numpy(
        self,
        chunks: list[bytes],
        metadata_chunks: Optional[list[ChunkMetadata]] = None,
        compression: CompressionCodec = CompressionCodec.NONE,
        dtype: str = "float32",
        shape: Optional[tuple[int, ...]] = None,
    ) -> np.ndarray:
        """Reassemble chunks into a numpy array.

        Args:
            chunks: Ordered list of chunk byte arrays.
            metadata_chunks: Optional per-chunk metadata.
            compression: Compression codec used.
            dtype: Target numpy dtype string.
            shape: Target array shape. If None, attempts to infer.

        Returns:
            numpy array with the reassembled data.

        Raises:
            ValueError: If data size doesn't match shape.
        """
        raw = self.reassemble_tensor(chunks, metadata_chunks, compression)
        np_dtype = np.dtype(dtype)
        arr = np.frombuffer(raw, dtype=np_dtype)

        if shape is not None:
            expected_elements = 1
            for s in shape:
                expected_elements *= s
            if len(arr) != expected_elements:
                raise ValueError(
                    f"Data size mismatch: {len(arr)} elements vs "
                    f"shape {shape} ({expected_elements} elements)"
                )
            arr = arr.reshape(shape)

        return arr.copy()  # Make writable copy
