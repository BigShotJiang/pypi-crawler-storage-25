"""
Rex Framework — Remote Executable eXecution.

Inference with remotely-stored model weights.
"""

__version__ = "0.1.2"
__status__ = "Alpha"

from rex.api.config import RexConfig

__all__ = [
    "RexConfig",
]
