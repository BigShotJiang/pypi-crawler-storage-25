"""Tensor materializer for Rex PyTorch integration.

Status: Implemented

Handles converting VirtualTensors back into PyTorch tensors
for execution, including chunk assembly, decompression, and
device placement.
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np

from rex.core.errors import MaterializationError
from rex.core.types import (
    ChunkMetadata,
    CompressionCodec,
    TensorDescriptor,
)
from rex.formats.chunk_reader import ChunkReader
from rex.formats.compression import (
    CompressionCodec as FmtCompressionCodec,
    CompressionError,
    decompress,
    detect_codec,
)


class TensorMaterializer:
    """Materializes VirtualTensors into PyTorch tensors for execution.

    Fetches chunk data from cache/storage, reassembles, decompresses,
    and converts to torch.Tensor on the target device.

    The materializer supports two decompression modes:

    * **Full-tensor compression**: all chunks are concatenated first,
      then the combined blob is decompressed once.  This is the
      legacy ChunkWriter mode.
    * **Per-chunk compression**: each chunk is individually
      decompressed before concatenation.  Enabled when the manifest
      sets ``feature_flags["compressed_chunks"]`` to ``True``.

    Args:
        chunk_reader: ChunkReader for data reassembly.
        device: Target torch device (default: "cpu").
        per_chunk_decompression: If True, decompress each chunk
            individually before concatenation.
    """

    def __init__(
        self,
        chunk_reader: Optional[ChunkReader] = None,
        device: str = "cpu",
        per_chunk_decompression: bool = False,
    ) -> None:
        self.chunk_reader = chunk_reader or ChunkReader(verify_checksums=True)
        self.device = device
        self.per_chunk_decompression = per_chunk_decompression

    def materialize(
        self,
        descriptor: TensorDescriptor,
        chunk_data: dict[str, bytes],
        compression: CompressionCodec = CompressionCodec.NONE,
    ) -> Any:
        """Materialize a tensor from chunk data.

        Args:
            descriptor: Tensor metadata (shape, dtype, chunks).
            chunk_data: Dict mapping chunk_id -> raw bytes.
            compression: Compression codec used.

        Returns:
            torch.Tensor on the target device.

        Raises:
            MaterializationError: If materialization fails.
        """
        import torch

        if not chunk_data:
            raise MaterializationError(
                f"No chunk data provided for tensor '{descriptor.name}'"
            )

        # Order chunks by their position in the chunk address list
        ordered_chunks: list[bytes] = []

        for ca in descriptor.chunk_addresses:
            data = chunk_data.get(ca.chunk_id)
            if data is None:
                raise MaterializationError(
                    f"Missing chunk '{ca.chunk_id}' for tensor "
                    f"'{descriptor.name}'"
                )
            ordered_chunks.append(data)

        # ── Per-chunk decompression ───────────────────────────────────
        if self.per_chunk_decompression and len(ordered_chunks) > 0:
            decompressed_chunks: list[bytes] = []
            for i, chunk in enumerate(ordered_chunks):
                if len(chunk) == 0:
                    decompressed_chunks.append(chunk)
                    continue
                try:
                    raw, codec = decompress(chunk)
                    decompressed_chunks.append(raw)
                except Exception as exc:
                    # If the chunk has no compression header, use it raw
                    codec_detected = detect_codec(chunk)
                    if codec_detected is None:
                        decompressed_chunks.append(chunk)
                    else:
                        raise MaterializationError(
                            f"Failed to decompress chunk {i} for tensor "
                            f"'{descriptor.name}': {exc}"
                        ) from exc
            ordered_chunks = decompressed_chunks

        # ── Full reassembly (handles both compressed & uncompressed) ──
        try:
            raw = self.chunk_reader.reassemble_tensor(
                chunks=ordered_chunks,
                compression=compression,
            )
        except Exception as e:
            raise MaterializationError(
                f"Failed to reassemble tensor '{descriptor.name}': {e}"
            ) from e

        # ── Convert to numpy then torch ───────────────────────────────
        try:
            np_dtype = np.dtype(descriptor.dtype)
            arr = np.frombuffer(raw, dtype=np_dtype)
            arr = arr.reshape(descriptor.shape)
            tensor = torch.from_numpy(arr.copy())
        except Exception as e:
            raise MaterializationError(
                f"Failed to convert tensor '{descriptor.name}' to torch: {e}"
            ) from e

        return tensor.to(self.device)

    def materialize_virtual_tensor(
        self,
        vt: Any,
        cache: Any,
        compression: CompressionCodec = CompressionCodec.NONE,
    ) -> Any:
        """Materialize a VirtualTensor using cached chunk data.

        This is a convenience wrapper that collects chunk data from the
        provided cache (async or sync) and delegates to :meth:`materialize`.

        Args:
            vt: The VirtualTensor to materialize.
            cache: Cache instance with a ``get(chunk_id)`` method.
            compression: Compression codec used.

        Returns:
            torch.Tensor on the target device.
        """
        chunk_data: dict[str, bytes] = {}
        for addr in vt.chunk_addresses:
            data = vt._chunk_data.get(addr.chunk_id)
            if data is not None:
                chunk_data[addr.chunk_id] = data

        if not chunk_data:
            # Try to pull from the cache
            get_fn = getattr(cache, "get", None)
            if get_fn is not None:
                for addr in vt.chunk_addresses:
                    data = get_fn(addr.chunk_id)
                    if data is not None:
                        chunk_data[addr.chunk_id] = data

        # Build a synthetic TensorDescriptor from the VirtualTensor
        desc = TensorDescriptor(
            name=vt.name,
            shape=vt.shape,
            dtype=vt.dtype,
            num_chunks=vt.num_chunks,
            chunk_addresses=vt.chunk_addresses,
            total_bytes=vt.total_bytes,
        )

        return self.materialize(desc, chunk_data, compression=compression)

    def materialize_partial(
        self,
        descriptor: TensorDescriptor,
        chunk_data: dict[str, bytes],
        element_start: int,
        element_end: int,
        compression: CompressionCodec = CompressionCodec.NONE,
    ) -> Any:
        """Materialize a slice of a tensor.

        Only fetches chunks needed for the requested element range.

        Args:
            descriptor: Tensor metadata.
            chunk_data: Available chunk data.
            element_start: Start element index.
            element_end: End element index (exclusive).
            compression: Compression codec.

        Returns:
            Partial torch.Tensor.
        """
        import torch

        # Full materialization for now; partial is an optimization
        # TODO: Implement true partial materialization that only
        # fetches relevant chunks (Phase B)
        full_tensor = self.materialize(descriptor, chunk_data, compression)
        flat = full_tensor.flatten()
        return flat[element_start:element_end].reshape(
            *full_tensor.shape[:1], element_end - element_start,
            *full_tensor.shape[1:]
        )
