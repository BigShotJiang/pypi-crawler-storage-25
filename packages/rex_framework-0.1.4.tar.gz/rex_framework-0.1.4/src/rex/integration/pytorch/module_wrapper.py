"""PyTorch module wrapper for Rex integration.

Status: Implemented

Wraps a PyTorch nn.Module to use Rex-managed weight loading.
The wrapper intercepts weight access and redirects through the
Rex virtual tensor system.
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np
import torch
import torch.nn as nn


class RexModuleWrapper(nn.Module):
    """Wraps a model architecture for Rex execution.

    Creates a shadow copy of the model where all parameter tensors
    are replaced with Rex-managed VirtualTensors. During forward
    pass, weights are materialized just-in-time from the Rex cache.

    Status: Implemented for sequential, layer-by-layer models.
    Does NOT support arbitrary dynamic graphs.

    Args:
        model_class: The nn.Module class to wrap.
        runtime: RexRuntime for weight access, cache, and storage.
        compute_fn: Optional custom compute function with signature
            ``compute_fn(input_data, weights: dict[str, tensor]) -> output``.
            If *None* a default ``F.linear`` function is used for each layer.

    Example:
        class MyModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.fc1 = nn.Linear(64, 128)
                self.fc2 = nn.Linear(128, 10)

        wrapper = RexModuleWrapper(MyModel, runtime=runtime)
        output = await wrapper.forward(input_tensor)
    """

    def __init__(
        self,
        model_class: type[nn.Module],
        runtime: Any,
        compute_fn: Optional[Any] = None,
    ) -> None:
        super().__init__()
        self.model_class = model_class
        self.runtime = runtime
        self._custom_compute_fn = compute_fn
        self._model: Optional[nn.Module] = None

        # Load the model from the runtime if a manifest is already loaded
        self.manifest = getattr(runtime, "manifest", None)

    def build_model(self) -> nn.Module:
        """Build the model with dummy weights.

        The model is created with correct shapes but zero/placeholder
        weights. Real weights are injected during Rex execution.
        """
        # Build model to get structure
        self._model = self.model_class()
        return self._model

    def get_layer_function(self, layer_name: str) -> Any:
        """Get the execution function for a named layer.

        Returns the custom compute function if one was provided to
        the constructor, otherwise returns a simple linear function.

        Args:
            layer_name: Name of the layer/parameter.

        Returns:
            Callable that performs the layer computation.
        """
        if self._custom_compute_fn is not None:
            return self._custom_compute_fn

        # Default: return a linear function
        def linear_fn(x, weight=None, bias=None):
            return torch.nn.functional.linear(x, weight, bias)

        return linear_fn

    async def forward(self, input_data: torch.Tensor) -> torch.Tensor:
        """Run inference through all layers with Rex weight management.

        Materialises weights via the Rex pipeline (cache + prefetch) for
        each layer in execution order, executes the compute function, and
        returns the final output tensor.

        Args:
            input_data: Input tensor.

        Returns:
            Output tensor.

        Raises:
            RuntimeError: If the runtime has no model loaded.
            ExecutionError: If any layer fails.
        """
        from rex.core.errors import ExecutionError
        from rex.integration.pytorch.layer_runner import LayerRunner
        from rex.integration.pytorch.tensor_materializer import TensorMaterializer
        from rex.formats.chunk_reader import ChunkReader

        if self.manifest is None:
            raise RuntimeError(
                "No manifest loaded on the runtime. "
                "Call runtime.load_model() first."
            )

        # Ensure input is a torch tensor on CPU (the runtime is CPU-only)
        if not isinstance(input_data, torch.Tensor):
            input_data = torch.as_tensor(input_data, dtype=torch.float32)

        device = input_data.device

        materializer = TensorMaterializer(
            chunk_reader=ChunkReader(verify_checksums=True),
            device=str(device),
        )

        runner = LayerRunner(
            materializer=materializer,
            cache=self.runtime.cache,
            storage=self.runtime.storage,
            prefetcher=self.runtime.prefetcher,
        )

        current = input_data

        for param_name in self.manifest.execution_graph:
            desc = self.manifest.parameters.get(param_name)
            if desc is None:
                continue

            # Determine the layer function
            layer_fn = self.get_layer_function(param_name)

            # Collect weight descriptors for this layer.
            # For simple parameter-level execution each param is a layer.
            weights = {param_name: desc}

            result = await runner.run_layer(
                layer_name=param_name,
                layer_fn=lambda x, **kw: layer_fn(
                    x, kw.get(param_name)
                ),
                input_data=current,
                weight_descriptors=weights,
                compression=self.manifest.compression,
            )

            current = result

        return current

    async def run(self, input_data: torch.Tensor) -> torch.Tensor:
        """Alias for :meth:`forward`."""
        return await self.forward(input_data)
