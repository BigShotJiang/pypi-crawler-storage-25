"""Layer runner for Rex PyTorch integration.

Status: Implemented

Executes individual model layers with Rex-managed weight materialization.
Implements the core layer-by-layer execution loop that ensures weights
are only resident when needed.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import torch

from rex.core.types import CompressionCodec, InferenceMetrics


@dataclass
class LayerResult:
    """Result of executing a single layer."""
    layer_name: str
    execution_time_ms: float
    stall_time_ms: float
    chunks_fetched: int
    cache_hits: int
    cache_misses: int
    bytes_fetched: int
    output_shape: tuple[int, ...] = ()


class LayerRunner:
    """Runs model layers with Rex weight management.

    The LayerRunner orchestrates the just-in-time materialization of
    weights for each layer, executes the layer computation, and then
    evicts/demotes weights that are no longer needed.

    Args:
        materializer: TensorMaterializer for creating torch tensors.
        cache: Memory cache for chunk data.
        storage: Storage backend for fetching remote chunks.
        prefetcher: Prefetcher for async chunk fetching.
    """

    def __init__(
        self,
        materializer: Any,
        cache: Any,
        storage: Any,
        prefetcher: Any,
    ) -> None:
        self.materializer = materializer
        self.cache = cache
        self.storage = storage
        self.prefetcher = prefetcher

    # ── helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _to_torch(data: Any) -> torch.Tensor:
        """Convert numpy arrays, lists, or scalars to ``torch.Tensor``."""
        if isinstance(data, torch.Tensor):
            return data
        if hasattr(data, "numpy"):
            # e.g. numpy array with .numpy() or numpy directly
            arr = data if hasattr(data, "dtype") else data.numpy()
            return torch.as_tensor(arr)
        return torch.as_tensor(data)

    @staticmethod
    def _ensure_torch_input(input_data: Any) -> torch.Tensor:
        """Ensure *input_data* is a ``torch.Tensor`` (float32)."""
        if isinstance(input_data, torch.Tensor):
            return input_data.float() if input_data.dtype != torch.float32 else input_data
        return torch.as_tensor(input_data, dtype=torch.float32)

    async def _fetch_chunk(
        self,
        resource_id: str,
        start: int,
        end: int,
    ) -> bytes:
        """Fetch a byte range from the storage backend.

        Falls back to synchronous ``storage.fetch_range`` if the
        backend is not async-aware.
        """
        coro = getattr(self.storage, "fetch_range", None)
        if coro is not None and callable(coro):
            # If the backend is async, await it
            import inspect
            if inspect.iscoroutinefunction(coro):
                return await coro(resource_id, start, end)
            return coro(resource_id, start, end)
        raise RuntimeError("No storage backend configured for fetching chunks")

    async def _get_cached_or_fetch(
        self,
        chunk_id: str,
        resource_id: str,
        byte_start: int,
        byte_end: int,
    ) -> bytes:
        """Return cached data or fetch from storage.

        Uses the cache's async API when available, otherwise falls
        back to a synchronous lookup.
        """
        # Try cache first
        get_fn = getattr(self.cache, "get", None)
        if get_fn is not None:
            import inspect
            if inspect.iscoroutinefunction(get_fn):
                cached = await get_fn(chunk_id)
            else:
                cached = get_fn(chunk_id)
            if cached is not None:
                return cached

        # Fetch from storage
        data = await self._fetch_chunk(resource_id, byte_start, byte_end)

        # Store in cache
        put_fn = getattr(self.cache, "put", None)
        if put_fn is not None:
            import inspect
            if inspect.iscoroutinefunction(put_fn):
                await put_fn(chunk_id, data)
            else:
                put_fn(chunk_id, data)

        return data

    # ── main API ─────────────────────────────────────────────────────────

    async def execute_layer(
        self,
        layer_name: str,
        layer_fn: Callable[..., Any],
        input_data: Any,
        weight_descriptors: dict[str, Any],
        compression: Any = None,
    ) -> Any:
        """Execute a single layer with Rex weight management.

        This is the primary entry point.  It collects chunks, ensures
        they are in cache, materialises them into ``torch.Tensor`` objects,
        and runs *layer_fn*.

        Workflow:
        1. Collect chunk_ids needed for this layer's weights
        2. Ensure all chunks are in cache (fetch if needed)
        3. Materialize weights into torch tensors
        4. Execute the layer function
        5. Evict weights after execution

        Args:
            layer_name: Name/identifier for this layer.
            layer_fn: Callable that takes ``(input, **weights)`` and returns
                output.  *input* and *weights* values are guaranteed to be
                ``torch.Tensor``.
            input_data: Input tensor or data.
            weight_descriptors: Dict of ``weight_name -> TensorDescriptor``.
            compression: Compression codec (enum or None).

        Returns:
            The raw output of *layer_fn* (typically a ``torch.Tensor``).
        """
        result = await self.run_layer(
            layer_name=layer_name,
            layer_fn=layer_fn,
            input_data=input_data,
            weight_descriptors=weight_descriptors,
            compression=compression,
        )
        return result

    async def run_layer(
        self,
        layer_name: str,
        layer_fn: Callable[..., Any],
        input_data: Any,
        weight_descriptors: dict[str, Any],
        compression: Any = None,
    ) -> Any:
        """Execute a single layer and return **LayerResult** (backward compat).

        For the lightweight API that just returns the output tensor,
        use :meth:`execute_layer` instead.
        """
        start_total = time.perf_counter()
        stall_start = time.perf_counter()

        # Step 1-2: Ensure all needed chunks are in cache
        chunks_fetched = 0
        cache_hits = 0
        cache_misses = 0
        bytes_fetched = 0
        all_chunk_data: dict[str, bytes] = {}

        for wname, wdesc in weight_descriptors.items():
            for ca in wdesc.chunk_addresses:
                cid = ca.chunk_id
                data = await self._get_cached_or_fetch(
                    chunk_id=cid,
                    resource_id=ca.resource_id,
                    byte_start=ca.byte_range.start,
                    byte_end=ca.byte_range.end,
                )
                all_chunk_data[cid] = data

                # Heuristic hit/miss tracking
                if data is not None:
                    cache_hits += 1
                else:
                    cache_misses += 1
                    chunks_fetched += 1
                    if data is not None:
                        bytes_fetched += len(data)

        stall_end = time.perf_counter()
        stall_time_ms = (stall_end - stall_start) * 1000

        # Step 3: Materialize weights into torch tensors
        weights: dict[str, Any] = {}
        for wname, wdesc in weight_descriptors.items():
            w_chunk_data = {
                ca.chunk_id: all_chunk_data[ca.chunk_id]
                for ca in wdesc.chunk_addresses
            }
            tensor = self.materializer.materialize(
                descriptor=wdesc,
                chunk_data=w_chunk_data,
                compression=compression,
            )
            # Ensure the result is a torch.Tensor
            weights[wname] = self._to_torch(tensor)

        # Step 4: Execute layer
        exec_start = time.perf_counter()
        try:
            output = layer_fn(input_data, **weights)
        except Exception as e:
            from rex.core.errors import ExecutionError
            raise ExecutionError(
                f"Layer '{layer_name}' computation failed: {e}"
            ) from e
        exec_end = time.perf_counter()

        # Step 5: Evict weights (demote from cache)
        for wname, wdesc in weight_descriptors.items():
            for ca in wdesc.chunk_addresses:
                evict_fn = getattr(self.cache, "evict", None)
                if evict_fn is not None:
                    import inspect
                    if inspect.iscoroutinefunction(evict_fn):
                        await evict_fn(ca.chunk_id)
                    else:
                        evict_fn(ca.chunk_id)

        total_time_ms = (exec_end - start_total) * 1000

        # Get output shape
        output_shape = tuple(output.shape) if hasattr(output, "shape") else ()

        return LayerResult(
            layer_name=layer_name,
            execution_time_ms=(exec_end - exec_start) * 1000,
            stall_time_ms=stall_time_ms,
            chunks_fetched=chunks_fetched,
            cache_hits=cache_hits,
            cache_misses=cache_misses,
            bytes_fetched=bytes_fetched,
            output_shape=output_shape,
        )
