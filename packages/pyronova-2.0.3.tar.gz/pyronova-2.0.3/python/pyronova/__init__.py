"""Pyronova — A high-performance Python web framework powered by Rust."""

from pyronova.engine import PyronovaApp, Request, Response, WebSocket, SharedState, Stream, get_gil_metrics, init_logger, emit_python_log
from pyronova.app import Pyronova
from pyronova.rpc import RPCClient
from pyronova.cookies import get_cookies, get_cookie, set_cookie, delete_cookie
from pyronova.uploads import parse_multipart, UploadFile


def redirect(url: str, status_code: int = 302) -> Response:
    """Return a redirect response.

    Usage::

        @app.get("/old")
        def old_page(req):
            return redirect("/new")

        @app.get("/permanent")
        def moved(req):
            return redirect("/new-home", status_code=301)
    """
    return Response(
        body="",
        status_code=status_code,
        headers={"location": url},
    )

__all__ = ["Pyronova", "PyronovaApp", "Request", "Response", "WebSocket", "SharedState", "Stream", "get_gil_metrics", "init_logger", "emit_python_log"]
try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("pyronova")
except Exception:
    __version__ = "dev"
