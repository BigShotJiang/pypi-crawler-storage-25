"""Multi-provider support for codrninja — not just Ollama!"""

import json
import os
import warnings
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Tuple

import requests

from .auth import OAuthFlow, TokenManager

# Suppress SSL verification warnings for Codex endpoint (OAuth only)
warnings.filterwarnings('ignore', message='Unverified HTTPS request')


class BaseProvider(ABC):
    """Abstract base class for AI providers."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    @abstractmethod
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        """Send chat messages and return response."""
        pass

    @abstractmethod
    def list_models(self) -> List[str]:
        """List available models."""
        pass

    @abstractmethod
    def get_default_model(self) -> str:
        """Get default model for this provider."""
        pass


class OllamaProvider(BaseProvider):
    """Ollama provider for local models."""

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        url = self.config.get("url", "http://localhost:11434")
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "http://" + url
        model = model or self.config.get("model", "codellama")
        reasoning = self.config.get("reasoning_level", "medium")
        num_ctx_map = {"none": 4096, "low": 8192, "medium": 16384, "high": 32768}
        num_ctx = self.config.get("num_ctx", None) or num_ctx_map.get(reasoning, 16384)

        try:
            response = requests.post(
                f"{url}/api/chat",
                json={
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "temperature": self.config.get("temperature", 0.7),
                        "num_predict": self.config.get("max_tokens", 16384),
                        "num_ctx": num_ctx,
                    },
                },
                timeout=300,
            )
            response.raise_for_status()
            data = response.json()
            return {
                "content": data.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": data.get("prompt_eval_count", 0),
                "tokens_output": data.get("eval_count", 0),
                "done": True,
            }
        except requests.exceptions.Timeout:
            return {"error": "Request timed out", "content": ""}
        except requests.exceptions.ConnectionError:
            return {"error": f"Cannot connect to Ollama at {url}", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}

    def list_models(self) -> List[str]:
        url = self.config.get("url", "http://localhost:11434")
        try:
            response = requests.get(f"{url}/api/tags", timeout=10)
            data = response.json()
            return [m["name"] for m in data.get("models", [])]
        except Exception:
            return ["codellama", "llama2", "mistral"]

    def get_default_model(self) -> str:
        return self.config.get("model", "codellama")


class OAuthCapableProvider(BaseProvider):
    oauth_env_var: str = ""

    def _auth_headers(self) -> Dict[str, str]:
        access_token = self.config.get("access_token")
        if access_token:
            return {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
            }
        api_key = self.config.get("api_key") or os.environ.get(self.oauth_env_var)
        if not api_key:
            return {}
        return self._api_key_headers(api_key)

    @abstractmethod
    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        pass


class OpenAIProvider(OAuthCapableProvider):
    """OpenAI provider for GPT models."""

    oauth_env_var = "OPENAI_API_KEY"

    @staticmethod
    def _get_model_config(model_id: str) -> Dict[str, Any]:
        """getResponsesModelConfig() -- per opencode openai-responses-language-model.ts."""
        if (
            (model_id.startswith("gpt-5") and not model_id.startswith("gpt-5-chat"))
            or model_id.startswith("o")
            or model_id.startswith("codex-")
            or model_id.startswith("computer-use")
        ):
            if model_id.startswith("o1-mini") or model_id.startswith("o1-preview"):
                return {"is_reasoning": True, "system_mode": "remove"}
            return {"is_reasoning": True, "system_mode": "developer"}
        return {"is_reasoning": False, "system_mode": "system"}

    @staticmethod
    def _convert_messages_to_responses_input(
        messages: List[Dict[str, Any]], model: str
    ) -> Tuple[List[Dict[str, Any]], str]:
        """convertToOpenAIResponsesInput() -- per opencode.
        System messages in developer mode become instructions, NOT input array items.
        """
        config = OpenAIProvider._get_model_config(model)
        mode = config["system_mode"]
        input_arr: List[Dict[str, Any]] = []
        instructions = ""
        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "") if isinstance(msg.get("content"), str) else ""
            if role == "system":
                if mode == "developer":
                    # gpt-5.x: system-prompt → instructions field (NOT in input array!)
                    instructions = content
                elif mode == "system":
                    input_arr.append({"role": "system", "content": content})
                # mode == "remove" → ignore
            elif role == "user":
                input_arr.append(
                    {
                        "role": "user",
                        "content": (
                            [{"type": "input_text", "text": content}]
                            if isinstance(content, str)
                            else content
                        ),
                    }
                )
            elif role == "assistant":
                input_arr.append(
                    {
                        "role": "assistant",
                        "content": (
                            [{"type": "output_text", "text": content}]
                            if isinstance(content, str)
                            else content
                        ),
                    }
                )
        return input_arr, instructions

    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        headers = self._auth_headers()
        if not headers:
            return {"error": "OpenAI API key or OAuth token not set", "content": ""}

        model = model or self.config.get("model", "gpt-4o")

        # Detect OAuth vs API Key
        auth_header = headers.get("Authorization", "")
        is_oauth = not auth_header.startswith("Bearer sk-")

        if is_oauth:
            # ── OAuth Flow → Codex Responses API ──────────────────────
            codex_headers = {
                "Content-Type": "application/json",
                "authorization": auth_header.replace("Bearer ", ""),
                "originator": "opencode",
                "User-Agent": f"codrninja/0.8.50 ({os.uname().sysname if hasattr(os, 'uname') else 'unknown'})",
            }
            # Add account_id if available from OAuth tokens
            from .auth import TokenManager
            tm = TokenManager()
            tokens = tm.get_tokens("openai")
            if tokens and tokens.get("account_id"):
                codex_headers["ChatGPT-Account-Id"] = tokens["account_id"]

            # Convert messages to Responses API input format per opencode spec
            input_arr, instructions = self._convert_messages_to_responses_input(messages, model)
            config = self._get_model_config(model)

            payload: Dict[str, Any] = {
                "model": model,
                "input": input_arr,
                "instructions": instructions or "You are a helpful assistant.",  # REQUIRED by Codex endpoint
                "store": False,
                "stream": True,
            }
            # Reasoning models: omit max_output_tokens (codex.ts chat.params hook sets undefined)
            if not config["is_reasoning"]:
                payload["max_output_tokens"] = self.config.get("max_tokens", 8192)

            url = "https://chatgpt.com/backend-api/codex/responses"
            if os.environ.get("CODRNINJA_DEBUG"):
                print(f"[DEBUG] Codex request: POST {url}")
                print(f"[DEBUG] Model: {model}")
                print(f"[DEBUG] Headers: { {k: (v[:20] + '...' if len(str(v)) > 20 else v) for k, v in codex_headers.items()} }")
                print(f"[DEBUG] Payload keys: {list(payload.keys())}")
                print(f"[DEBUG] Input messages: {len(input_arr)}")
            try:
                response = requests.post(
                    url,
                    headers=codex_headers,
                    json=payload,
                    timeout=300,
                    verify=False,
                    stream=True,
                )
                if os.environ.get("CODRNINJA_DEBUG"):
                    print(f"[DEBUG] Response status: {response.status_code}")
                    print(f"[DEBUG] Response headers: {dict(response.headers)}")
                if response.status_code >= 400:
                    try:
                        err_body = response.json()
                        err_detail = err_body.get('detail', err_body.get('error', err_body))
                    except Exception:
                        err_detail = response.text[:500]
                    return {"error": f"Codex API error {response.status_code}: {err_detail}", "content": ""}

                full_text = ""
                for line in response.iter_lines():
                    if not line:
                        continue
                    line_str = line.decode("utf-8") if isinstance(line, bytes) else line
                    if not line_str.startswith("data: "):
                        continue
                    data = line_str[6:]
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                        if os.environ.get("CODRNINJA_DEBUG"):
                            print(f"[DEBUG] SSE chunk type: {chunk.get('type', 'unknown')}")
                        t = chunk.get("type", "")
                        if t == "response.output_text.delta":
                            delta = chunk.get("delta", "")
                            if delta:
                                full_text += delta
                        elif t in ("response.completed", "response.incomplete"):
                            break
                        elif t == "error":
                            return {"error": f"Stream error: {chunk}", "content": full_text}
                    except json.JSONDecodeError:
                        continue

                return {
                    "content": full_text,
                    "model": model,
                    "tokens_input": 0,
                    "tokens_output": 0,
                    "done": True,
                }
            except requests.exceptions.Timeout:
                return {"error": "Request timed out", "content": ""}
            except Exception as e:
                return {"error": f"Codex API error: {e}", "content": ""}
        else:
            # ── API Key Flow → Standard OpenAI ───────────────────────
            try:
                response = requests.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers=headers,
                    json={
                        "model": model,
                        "messages": messages,
                        "temperature": self.config.get("temperature", 0.7),
                        "max_tokens": self.config.get("max_tokens", 4096),
                    },
                    timeout=300,
                )
                response.raise_for_status()
                data = response.json()
                choice = data.get("choices", [{}])[0]
                usage = data.get("usage", {})
                return {
                    "content": choice.get("message", {}).get("content", ""),
                    "model": model,
                    "tokens_input": usage.get("prompt_tokens", 0),
                    "tokens_output": usage.get("completion_tokens", 0),
                    "done": True,
                }
            except requests.exceptions.Timeout:
                return {"error": "Request timed out", "content": ""}
            except Exception as e:
                return {"error": str(e), "content": ""}

    def list_models(self) -> List[str]:
        return ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-4", "gpt-3.5-turbo"]

    def get_default_model(self) -> str:
        return self.config.get("model", "gpt-4o")


class AnthropicProvider(OAuthCapableProvider):
    """Anthropic provider for Claude models."""

    oauth_env_var = "ANTHROPIC_API_KEY"

    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        return {
            "x-api-key": api_key,
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01",
        }

    def _auth_headers(self) -> Dict[str, str]:
        headers = super()._auth_headers()
        if headers.get("Authorization"):
            headers["anthropic-version"] = "2023-06-01"
        return headers

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        headers = self._auth_headers()
        if not headers:
            return {"error": "Anthropic API key or OAuth token not set", "content": ""}

        model = model or self.config.get("model", "claude-3-sonnet-20240229")
        system_msg = ""
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                user_messages.append(msg)

        try:
            response = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers=headers,
                json={
                    "model": model,
                    "max_tokens": self.config.get("max_tokens", 4096),
                    "temperature": self.config.get("temperature", 0.7),
                    "system": system_msg,
                    "messages": [{"role": m["role"], "content": m["content"]} for m in user_messages],
                },
                timeout=300,
            )
            response.raise_for_status()
            data = response.json()
            usage = data.get("usage", {})
            content = data.get("content", [{}])
            text = content[0].get("text", "") if content else ""
            return {
                "content": text,
                "model": model,
                "tokens_input": usage.get("input_tokens", 0),
                "tokens_output": usage.get("output_tokens", 0),
                "done": True,
            }
        except requests.exceptions.Timeout:
            return {"error": "Request timed out", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}

    def list_models(self) -> List[str]:
        return ["claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"]

    def get_default_model(self) -> str:
        return self.config.get("model", "claude-3-sonnet-20240229")


class OpenRouterProvider(BaseProvider):
    """OpenRouter provider for multiple models."""

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        api_key = self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY")
        if not api_key:
            return {"error": "OpenRouter API key not set", "content": ""}
        model = model or self.config.get("model", "openai/gpt-4o")
        try:
            response = requests.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": messages,
                    "temperature": self.config.get("temperature", 0.7),
                    "max_tokens": self.config.get("max_tokens", 4096),
                },
                timeout=300,
            )
            response.raise_for_status()
            data = response.json()
            choice = data.get("choices", [{}])[0]
            usage = data.get("usage", {})
            return {
                "content": choice.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "done": True,
            }
        except Exception as e:
            return {"error": str(e), "content": ""}

    def list_models(self) -> List[str]:
        return ["openai/gpt-4o", "openai/gpt-4o-mini", "anthropic/claude-3-opus", "google/gemini-pro"]

    def get_default_model(self) -> str:
        return self.config.get("model", "openai/gpt-4o")


class ProviderManager:
    """Manages all AI providers."""

    PROVIDERS = {
        "ollama": OllamaProvider,
        "openai": OpenAIProvider,
        "anthropic": AnthropicProvider,
        "openrouter": OpenRouterProvider,
    }

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.current_provider = config.get("provider", "ollama")
        self._provider_instance = None
        self.token_manager = TokenManager()
        self.oauth_buffer_minutes = int(config.get("oauth", {}).get("refresh_buffer_minutes", 5))

    def _provider_config(self, provider_name: str) -> Dict[str, Any]:
        return dict(self.config.get("providers", {}).get(provider_name, {}))

    def _inject_oauth(self, provider_name: str, provider_config: Dict[str, Any]) -> Dict[str, Any]:
        if provider_name not in {"openai", "anthropic"}:
            return provider_config
        tokens = self.token_manager.get_tokens(provider_name)
        if not tokens:
            return provider_config
        if self.token_manager.is_token_expired(tokens, buffer_minutes=self.oauth_buffer_minutes):
            refresh_token = tokens.get("refresh_token")
            if refresh_token:
                flow = OAuthFlow(provider_name)
                refreshed = flow.refresh(refresh_token, metadata=tokens.get("metadata"))
                if not refreshed.get("refresh_token"):
                    refreshed["refresh_token"] = refresh_token
                self.token_manager.store_tokens(provider_name, refreshed)
                tokens = refreshed
        if tokens.get("access_token"):
            provider_config["access_token"] = tokens["access_token"]
            provider_config["use_oauth"] = True
        return provider_config

    def get_provider(self, name: Optional[str] = None) -> BaseProvider:
        provider_name = name or self.current_provider
        if provider_name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {provider_name}. Available: {list(self.PROVIDERS.keys())}")
        provider_config = self._inject_oauth(provider_name, self._provider_config(provider_name))
        return self.PROVIDERS[provider_name](provider_config)

    def set_provider(self, name: str):
        if name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {name}")
        self.current_provider = name

    def list_providers(self) -> List[str]:
        return list(self.PROVIDERS.keys())

    def list_models(self, provider: Optional[str] = None) -> List[str]:
        return self.get_provider(provider).list_models()
