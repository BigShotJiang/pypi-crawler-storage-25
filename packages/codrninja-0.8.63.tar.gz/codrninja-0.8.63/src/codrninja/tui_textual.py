"""Textual TUI for CodrNinja."""

from __future__ import annotations

import json
import os
import shlex
import threading
import urllib.request
from queue import Queue
from typing import Any, Optional

from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from textual import on, work
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, ListItem, ListView, RichLog, Static

from .agent import Agent, AgentMode
from .auth import OAuthFlow, TokenManager
from .core import AICode
from .mcp import MCPManager
from .oauth_providers import AnthropicOAuth, OpenAIOAuth
from .permissions import PermissionRule
from .skills import SkillRegistry
from .todo import TodoManager, format_todo_item
from .tools import ToolRegistry

SLASH_COMMANDS = {
    "/build": "Implement a task in build mode",
    "/clear": "Clear messages",
    "/commit": "Git commit changes",
    "/context": "Show project context",
    "/exec": "Execute shell command",
    "/exit": "Exit codrninja",
    "/explain": "Explain code or concept",
    "/fetch": "Fetch and clean a web page",
    "/files": "List files in directory",
    "/help": "Show detailed help",
    "/mcp": "Manage MCP servers and tools",
    "/maxsteps": "Set max steps limit",
    "/model": "Show or change AI configuration",
    "/permissions": "Manage permission rules",
    "/plan": "Plan a feature or task",
    "/reasoning": "Set reasoning level (none/low/medium/high)",
    "/read": "Read file",
    "/review": "Review code for issues",
    "/search": "Search the web",
    "/session": "Show session info",
    "/skills": "List installed skills",
    "/subagents": "List active subagents",
    "/test": "Run tests",
    "/todo": "Manage session todos",
}

BUILTIN_SUBAGENTS = {
    "general": AgentMode.BUILD,
    "explore": AgentMode.PLAN,
}

PROVIDERS = {
    "ollama": {
        "name": "Ollama (local or cloud subscription)",
        "models": [],
        "needs_key": False,
        "default_url": "http://localhost:11434",
        "can_custom_url": True,
    },
    "openai": {
        "name": "OpenAI (GPT-4, GPT-3.5)",
        "models": ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"],
        "needs_key": True,
        "env_var": "OPENAI_API_KEY",
    },
    "anthropic": {
        "name": "Anthropic (Claude)",
        "models": ["claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"],
        "needs_key": True,
        "env_var": "ANTHROPIC_API_KEY",
    },
    "openrouter": {
        "name": "OpenRouter (all models)",
        "models": ["openai/gpt-4", "anthropic/claude-3-opus", "google/gemini-pro"],
        "needs_key": True,
        "env_var": "OPENROUTER_API_KEY",
    },
}

CONFIG_DIR = os.path.expanduser("~/.config/codrninja")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def _format_tool_args(tool_name: str, args: dict[str, Any]) -> str:
    if tool_name == "bash":
        return str(args.get("command", ""))[:80]
    if tool_name == "execute_command":
        return str(args.get("command", ""))[:80]
    if tool_name in ("read_file", "write_file", "edit_file"):
        return str(args.get("path", args.get("file_path", "")))
    if tool_name in ("search", "search_files", "grep"):
        return str(args.get("pattern", args.get("query", "")))
    return str(args)[:80]


def _extract_reasoning(response: str) -> tuple[Optional[str], str]:
    import re

    patterns = [
        r"<thinking>(.*?)</thinking>",
        r"<reasoning>(.*?)</reasoning>",
        r"Reasoning:(.*?)(?=\n\n|$)",
        r"### Reasoning\n(.*?)(?=\n###|\Z)",
    ]
    reasoning_parts = []
    cleaned = response
    for pattern in patterns:
        for match in re.finditer(pattern, cleaned, re.DOTALL | re.IGNORECASE):
            part = match.group(1).strip()
            if part:
                reasoning_parts.append(part)
        cleaned = re.sub(pattern, "", cleaned, flags=re.DOTALL | re.IGNORECASE)
    reasoning = "\n\n".join(reasoning_parts).strip() or None
    return reasoning, cleaned.strip()


class MessageTimeline(RichLog):
    def on_mount(self) -> None:
        self._assistant_buffers: dict[str, str] = {}
        self._reasoning_buffers: dict[str, str] = {}
        self._tool_indices: dict[str, int] = {}

    def add_user_message(self, text: str) -> None:
        self.write(
            Panel(
                Text(text, style="white"),
                title="[bold cyan]you[/bold cyan]",
                border_style="cyan",
                padding=(0, 1),
            )
        )

    def add_reasoning_message(self, full_text: str, model: str, message_id: str = "reasoning") -> None:
        self._reasoning_buffers[message_id] = full_text
        self.write(
            Panel(
                self._render_content(full_text),
                title=f"[dim]reasoning[/dim] [dim]{model}[/dim]",
                border_style="dim",
                padding=(0, 1),
            )
        )

    def add_assistant_message(self, full_text: str, model: str, message_id: str = "assistant") -> None:
        self._assistant_buffers[message_id] = full_text
        renderable = self._render_content(full_text)
        self.write(
            Panel(
                renderable,
                title=f"[bold green]assistant[/bold green] [dim]{model}[/dim]",
                border_style="green",
                padding=(0, 1),
            )
        )

    def add_tool_start(self, tool_name: str, args: dict[str, Any]) -> None:
        args_str = _format_tool_args(tool_name, args)
        self._tool_indices[tool_name] = self._tool_indices.get(tool_name, 0) + 1
        self.write(
            Panel(
                Text(args_str, style="yellow"),
                title=f"[bold yellow]{tool_name}[/bold yellow] [dim]running[/dim]",
                border_style="yellow dim",
                padding=(0, 1),
            )
        )

    def add_tool_result(self, tool_name: str, output: str, success: bool = True) -> None:
        color = "green" if success else "red"
        state = "done" if success else "failed"
        preview = output[:500] + ("..." if len(output) > 500 else "")

        if output.strip().startswith(("{", "[")):
            content = Syntax(preview, "json", theme="monokai", line_numbers=False)
        else:
            content = Text(preview, style="dim")

        self.write(
            Panel(
                content,
                title=f"[{color}]{tool_name} {state}[/{color}]",
                border_style=f"{color} dim",
                padding=(0, 1),
            )
        )

    def add_error(self, error: str) -> None:
        self.write(
            Panel(
                Text(error, style="red"),
                title="[bold red]error[/bold red]",
                border_style="red",
            )
        )

    def add_system_message(self, text: str, title: str = "system") -> None:
        self.write(
            Panel(
                self._render_content(text),
                title=f"[bold white]{title}[/bold white]",
                border_style="#555555",
                padding=(0, 1),
            )
        )

    def _render_content(self, text: str):
        stripped = text.strip()
        if stripped.startswith("```") and stripped.endswith("```"):
            parts = stripped.split("\n")
            lang = parts[0].strip("`").strip() or "text"
            code = "\n".join(parts[1:-1])
            return Syntax(code, lang, theme="monokai", line_numbers=False)
        return Markdown(text or "")


class StatusBar(Label):
    def update_status(self, model: str, steps: int, max_steps: int, status: str, tokens: int) -> None:
        color = {"ready": "green", "thinking": "yellow", "running": "cyan", "error": "red"}.get(status, "green")
        self.update(
            f"[bold]{model}[/bold] [[bold]{steps}/{max_steps}[/bold]] [{color}]{status}[/{color}] [dim]{tokens} tokens[/dim]"
        )


class PermissionPromptScreen(ModalScreen[str]):
    CSS = """
    PermissionPromptScreen {
        align: center middle;
    }
    #permission-dialog {
        width: 80;
        height: auto;
        background: $surface;
        border: round $accent;
        padding: 1 2;
    }
    #permission-buttons {
        height: auto;
        margin-top: 1;
    }
    Button {
        margin-right: 1;
    }
    """

    def __init__(self, tool_name: str, params: dict[str, Any], action: str, target: str) -> None:
        super().__init__()
        self.tool_name = tool_name
        self.params = params
        self.action = action
        self.target = target

    def compose(self) -> ComposeResult:
        formatted = json.dumps(self.params, indent=2, ensure_ascii=False)
        with Container(id="permission-dialog"):
            yield Static(f"Permission Request\n\nTool: {self.tool_name}\nAction: {self.action}\nTarget: {self.target or '(none)'}\n\nParameters:\n{formatted}")
            with Horizontal(id="permission-buttons"):
                yield Button("Allow", id="allow", variant="success")
                yield Button("Deny", id="deny", variant="error")
                yield Button("Always Allow", id="always", variant="primary")

    @on(Button.Pressed)
    def handle_button(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id or "deny")


class SelectionScreen(ModalScreen[Optional[str]]):
    CSS = """
    SelectionScreen {
        align: center middle;
    }
    #selection-dialog {
        width: 80;
        height: 28;
        background: $surface;
        border: round $accent;
        padding: 1;
    }
    ListView {
        height: 1fr;
        border: solid #444;
    }
    """

    def __init__(self, title: str, options: list[str]) -> None:
        super().__init__()
        self.dialog_title = title
        self.options = options

    def compose(self) -> ComposeResult:
        with Container(id="selection-dialog"):
            yield Label(self.dialog_title)
            lv = ListView(*[ListItem(Label(opt)) for opt in self.options], id="selection-list")
            yield lv
            yield Label("enter select • esc cancel", classes="dim")

    def on_mount(self) -> None:
        list_view = self.query_one(ListView)
        list_view.focus()
        if self.options:
            list_view.index = 0
            list_view.scroll_visible()

    @on(ListView.Selected)
    def select_item(self, event: ListView.Selected) -> None:
        idx = event.list_view.index or 0
        self.dismiss(self.options[idx])


class CodrninjaTUI(App[None]):
    CSS = """
    Screen {
        background: #0d0d0d;
    }
    StatusBar {
        height: 1;
        background: #1a1a1a;
        color: #888;
        padding: 0 2;
        border-bottom: solid #333;
    }
    MessageTimeline {
        border: none;
        padding: 1 2;
        background: #0d0d0d;
    }
    #input-container {
        height: 4;
        border-top: solid #333;
        background: #111;
        padding: 0 1;
    }
    Input {
        background: #111;
        border: none;
        color: white;
        padding: 1 1;
    }
    Input:focus {
        border: solid #444;
    }
    #bottom-bar {
        height: 1;
        background: #1a1a1a;
        color: #555;
        padding: 0 2;
    }
    """

    BINDINGS = [
        ("ctrl+c", "quit", "Quit"),
        ("ctrl+l", "clear", "Clear"),
        ("escape", "cancel", "Cancel"),
    ]

    model = reactive("codellama")
    is_busy = reactive(False)
    current_status = reactive("ready")

    def __init__(self, ai: AICode, session_name: Optional[str] = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.ai = ai
        self.session_name = session_name
        self.console_tools = ToolRegistry()
        self.mcp = MCPManager()
        self.skill_registry = SkillRegistry()
        self.skill_registry.discover()
        self.skill_registry.register_tools(self.console_tools)
        self.agent: Optional[Agent] = None
        self.last_tokens = 0
        self.pending_agent: Optional[Agent] = None
        self.model = self.ai.config.default_model
        self.current_steps = 0
        self.current_max_steps = int(os.environ.get("CODRNINJA_MAX_STEPS", "50"))
        self._progress_queue: Queue[tuple[str, dict[str, Any]]] = Queue()

    def compose(self) -> ComposeResult:
        yield StatusBar("ready", id="status")
        yield MessageTimeline(id="timeline", highlight=True, markup=True)
        with Vertical(id="input-container"):
            yield Input(placeholder=" Type a message or /command...", id="prompt")
            yield Label("[dim]enter send ctrl+l clear ctrl+c quit[/dim]", id="bottom-bar")

    def on_mount(self) -> None:
        if self.session_name is None:
            self.session_name = self._ensure_session()
        if self.session_name and not self.ai.get_session(self.session_name):
            self.ai.create_session(self.session_name)
        if self.session_name:
            self.agent = Agent(self.ai, self.session_name)
            self.current_max_steps = self.agent.max_steps
        self.query_one("#prompt", Input).focus()
        self.set_interval(0.1, self._drain_progress_queue)
        self._set_status("ready")
        timeline = self.query_one("#timeline", MessageTimeline)
        timeline.add_system_message(
            f"Session: {self.session_name}\nProvider: {self.ai.config.default_provider}\nType /help for commands.",
            title="codrninja",
        )

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if not event.value.strip() or self.is_busy:
            return
        msg = event.value.strip()
        event.input.value = ""
        if msg.startswith("/"):
            self.handle_command(msg)
            return
        if self._handle_subagent_mention(msg):
            return
        self.run_agent_task(msg, AgentMode.BUILD)

    @work(exclusive=True)
    async def handle_command(self, message: str) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        timeline.add_user_message(message)
        if message.strip() == "/model":
            await self._interactive_model_flow()
            self.query_one("#prompt", Input).focus()
            return
        keep_running = self._execute_command(message)
        if not keep_running:
            self.exit()
        self.query_one("#prompt", Input).focus()

    @work(thread=True, exclusive=True)
    def run_agent_task(self, message: str, mode: str) -> None:
        self.call_from_thread(self._begin_task_ui, message)
        try:
            self.agent = Agent(self.ai, self.session_name, mode=mode)
            self.pending_agent = self.agent
            self.current_steps = 0
            self.current_max_steps = self.agent.max_steps
            self.agent.on_progress = self._on_agent_progress
            self.agent.permission_handler = self._handle_permission_request
            final_result: Optional[dict[str, Any]] = None
            for event in self.agent.stream_run(message, auto_approve=False):
                event_type = event.get("type")
                if event_type == "assistant_chunk":
                    self._progress_queue.put(("assistant_chunk", {"text": event.get("text", "")}))
                elif event_type == "result":
                    final_result = event.get("result")
                elif event_type in {"tool_start", "tool_result", "status"}:
                    self._progress_queue.put((event_type, event))
            if final_result is not None:
                self.call_from_thread(self._render_agent_result, final_result)
        except Exception as exc:
            self.call_from_thread(self.query_one("#timeline", MessageTimeline).add_error, str(exc))
            self.call_from_thread(self._set_status, "error")
        finally:
            self.pending_agent = None
            self.is_busy = False
            self.call_from_thread(self.query_one("#prompt", Input).focus)

    def _begin_task_ui(self, message: str) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        self.is_busy = True
        timeline.add_user_message(message)
        self._set_status("thinking")

    def _render_agent_result(self, result: dict[str, Any]) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        self.current_steps = int(result.get("tool_calls", self.current_steps))
        self.current_max_steps = int(result.get("max_steps", self.current_max_steps))
        if not result.get("success"):
            timeline.add_error(str(result.get("error", "Unknown error")))
            self._set_status("error")
            return
        response = str(result.get("response", ""))
        reasoning, cleaned = _extract_reasoning(response)
        self.last_tokens = int(result.get("tokens", {}).get("output", 0) or len(cleaned) // 4)
        if reasoning:
            timeline.add_reasoning_message(reasoning, self.model)
        if cleaned:
            timeline.add_assistant_message(cleaned, self.model)
        self._set_status("ready", self.last_tokens)

    def _on_agent_progress(self, event: dict[str, Any]) -> None:
        event_type = event.get("type", "status")
        if event_type == "tool_start":
            self.current_steps = int(event.get("step", self.current_steps))
        self._progress_queue.put((event_type, event))

    def _drain_progress_queue(self) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        while not self._progress_queue.empty():
            event, payload = self._progress_queue.get()
            if event == "tool_start":
                timeline.add_tool_start(payload["tool"], payload["args"])
                self._set_status("running")
            elif event == "tool_result":
                timeline.add_tool_result(payload["tool"], payload["output"], payload["success"])
                self._set_status("thinking")
            elif event == "assistant_chunk":
                reasoning, cleaned = _extract_reasoning(payload["text"])
                if reasoning:
                    timeline.add_reasoning_message(reasoning, self.model, payload.get("id", "reasoning"))
                if cleaned:
                    timeline.add_assistant_message(cleaned, self.model, payload.get("id", "assistant"))
            elif event == "status":
                self._set_status("thinking")

    def _handle_permission_request(self, tool_name: str, params: dict[str, Any], action: str, target: str) -> str:
        result = threading.Event()
        decision_holder: dict[str, str] = {}

        def _show() -> None:
            async def _push() -> None:
                decision = await self.push_screen_wait(PermissionPromptScreen(tool_name, params, action, target))
                decision_holder["v"] = decision or "deny"
                result.set()

            self.call_later(_push)

        self.call_from_thread(_show)
        result.wait(timeout=300)
        return decision_holder.get("v", "deny")
-            elif event == "status":
-                self._set_status("thinking")
            elif event == "status":
                self._set_status("thinking")

    def _execute_command(self, message: str) -> bool:
        parts = shlex.split(message)
        if not parts:
            return True
        cmd = parts[0].lower()
        args = parts[1:]
        timeline = self.query_one("#timeline", MessageTimeline)

        if cmd == "/exit":
            timeline.add_system_message("Goodbye.")
            return False
        if cmd == "/clear":
            self.action_clear()
            return True
        if cmd == "/help":
            lines = [f"{name:14} {desc}" for name, desc in SLASH_COMMANDS.items()]
            timeline.add_system_message("\n".join(lines), title="help")
            return True
        if cmd == "/session":
            self._show_session_info()
            return True
        if cmd == "/context":
            self._show_context()
            return True
        if cmd == "/maxsteps":
            self._set_maxsteps(args)
            return True
        if cmd == "/model":
            self._show_model_info(args)
            return True
        if cmd == "/files":
            self._list_files(args)
            return True
        if cmd == "/read":
            self._read_file(args)
            return True
        if cmd == "/exec":
            self._exec_command(args)
            return True
        if cmd == "/search":
            self._search_web(args)
            return True
        if cmd == "/fetch":
            self._fetch_page(args)
            return True
        if cmd == "/build":
            self.run_agent_task(" ".join(args), AgentMode.BUILD)
            return True
        if cmd == "/plan":
            self.run_agent_task(" ".join(args), AgentMode.PLAN)
            return True
        if cmd == "/review":
            self.run_agent_task(f"Review this code:\n\n{' '.join(args)}", AgentMode.PLAN)
            return True
        if cmd == "/explain":
            self.run_agent_task(f"Explain: {' '.join(args)}", AgentMode.PLAN)
            return True
        if cmd == "/test":
            self._run_tests(args)
            return True
        if cmd == "/commit":
            self._commit_changes(args)
            return True
        if cmd == "/reasoning":
            self._set_reasoning(args)
            return True
        if cmd == "/todo":
            self._handle_todo(args)
            return True
        if cmd == "/permissions":
            self._handle_permissions(args)
            return True
        if cmd == "/mcp":
            self._handle_mcp_command(args)
            return True
        if cmd == "/skills":
            self._show_skills()
            return True
        if cmd == "/subagents":
            self._list_subagents()
            return True

        timeline.add_error(f"Unknown command: {cmd}")
        return True

    def _handle_subagent_mention(self, message: str) -> bool:
        if not message.startswith("@"):
            return False
        parts = message.split(None, 1)
        name = parts[0][1:]
        task = parts[1] if len(parts) > 1 else ""
        mode = BUILTIN_SUBAGENTS.get(name.lower(), AgentMode.BUILD)
        self.run_agent_task(task, mode)
        return True

    def _ensure_session(self) -> str:
        existing = os.environ.get("CODRNINJA_SESSION")
        if existing:
            return existing
        sessions = self.ai.list_sessions()
        if sessions:
            return sessions[0].get("name", "default")
        return "default"

    def _show_session_info(self) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        if not self.session_name:
            timeline.add_error("No active session")
            return
        history = self.ai.get_history(self.session_name)
        if not history:
            timeline.add_error(f"Session '{self.session_name}' not found")
            return
        messages = history.get("messages", [])
        timeline.add_system_message(
            f"Name: {self.session_name}\nMessages: {len(messages)}\nCreated: {history.get('created_at', 'Unknown')}",
            title="session",
        )

    def _show_context(self) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        steps = self.agent.step_count if self.agent else self.current_steps
        max_steps = self.agent.max_steps if self.agent else self.current_max_steps
        lines = [
            f"Model: {self.ai.config.default_model}",
            f"Provider: {self.ai.config.default_provider}",
            f"Steps: {steps}/{max_steps}",
        ]
        if self.agent and hasattr(self.agent, "last_result"):
            tokens = self.agent.last_result.get("tokens", {})
            if tokens:
                lines.append(f"Tokens: {tokens.get('input', 0)} in / {tokens.get('output', 0)} out")
        timeline.add_system_message("\n".join(lines), title="context")

    async def _interactive_model_flow(self) -> None:
        provider_names = [info["name"] for info in PROVIDERS.values()]
        provider_keys = list(PROVIDERS.keys())
        chosen_provider_name = await self.push_screen_wait(SelectionScreen("Select AI provider", provider_names))
        if chosen_provider_name is None:
            return
        provider_key = provider_keys[provider_names.index(chosen_provider_name)]
        provider_info = PROVIDERS[provider_key]

        if provider_info.get("needs_key"):
            auth_done = await self._maybe_authenticate_provider(provider_key, provider_info)
            if auth_done is False:
                return

        ollama_url = None
        if provider_key == "ollama":
            config = self._load_config()
            ollama_url = config.get("ollama_url", provider_info.get("default_url", "http://localhost:11434"))

        models = self._fetch_provider_models(provider_key, provider_info, ollama_url)
        if not models:
            models = provider_info.get("models", [])
        model_choice = await self.push_screen_wait(SelectionScreen("Select model", models or [self.ai.config.default_model]))
        if model_choice is None:
            return
        self._apply_model_config(provider_key, model_choice, ollama_url)
        self.query_one("#timeline", MessageTimeline).add_system_message(
            f"Provider set to {provider_key}\nModel set to {model_choice}", title="model"
        )

    async def _maybe_authenticate_provider(self, provider_key: str, provider_info: dict[str, Any]) -> Optional[bool]:
        env_var = provider_info.get("env_var", "")
        existing = os.environ.get(env_var, "")
        auth_options = ["API Key"]
        if provider_key == "anthropic":
            auth_options.append("Claude CLI (reuse login)")
        elif provider_key == "openai":
            auth_options.append("OpenAI OAuth (ChatGPT Plus/Pro)")
        auth_options.append("Skip")
        choice = await self.push_screen_wait(SelectionScreen("Authentication method", auth_options))
        if choice is None or choice == "Skip":
            return True
        timeline = self.query_one("#timeline", MessageTimeline)
        if choice == "API Key":
            timeline.add_system_message(
                f"Set {env_var} in your environment or config, then rerun /model.", title="auth"
            )
            return True
        if choice.startswith("Claude CLI"):
            try:
                creds = AnthropicOAuth()._read_claude_cli_credentials()
                if creds:
                    os.environ[env_var] = creds["access_token"]
                    timeline.add_system_message("Claude CLI credentials loaded.", title="auth")
                    return True
            except Exception as exc:
                timeline.add_error(str(exc))
                return False
        if choice.startswith("OpenAI OAuth"):
            try:
                flow = OAuthFlow("openai", provider=OpenAIOAuth(), callback_port=1455)
                success, msg = flow.run(open_browser=True)
                if success:
                    tokens = TokenManager().get_tokens("openai")
                    if tokens and tokens.get("access_token"):
                        os.environ[env_var] = tokens["access_token"]
                    timeline.add_system_message(msg, title="auth")
                    return True
                timeline.add_error(msg)
                return False
            except Exception as exc:
                timeline.add_error(str(exc))
                return False
        return True

    def _fetch_provider_models(self, provider_key: str, provider_info: dict[str, Any], ollama_url: Optional[str]) -> list[str]:
        try:
            if provider_key == "ollama":
                url = ollama_url or provider_info.get("default_url", "http://localhost:11434")
                req = urllib.request.Request(f"{url}/api/tags")
                with urllib.request.urlopen(req, timeout=5) as response:
                    data = json.loads(response.read().decode())
                    return [m["name"] for m in data.get("models", [])]
            if provider_key == "openai":
                api_key = os.environ.get("OPENAI_API_KEY", "")
                if api_key and not api_key.startswith("sk-"):
                    all_models = [
                        "gpt-5.5", "gpt-5.4", "gpt-5.4-mini", "gpt-5.3-codex", "gpt-5.3-codex-spark",
                        "gpt-5.2", "gpt-5", "gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-4", "gpt-3.5-turbo",
                    ]
                    allowed = {"gpt-5.5", "gpt-5.2", "gpt-5.3-codex", "gpt-5.3-codex-spark", "gpt-5.4", "gpt-5.4-mini"}
                    return [m for m in all_models if m in allowed or (m.startswith("gpt-") and m.split("-")[1].replace(".", "", 1).isdigit())]
        except Exception:
            pass
        return list(provider_info.get("models", []))

    def _apply_model_config(self, provider: str, model: str, ollama_url: Optional[str]) -> None:
        config = self._load_config()
        config["provider"] = provider
        config["model"] = model
        if provider == "ollama" and ollama_url:
            config["ollama_url"] = ollama_url
            config["url"] = ollama_url
        self._save_config(config)
        self.ai.config.default_provider = provider
        self.ai.config.default_model = model
        if provider == "ollama" and ollama_url:
            self.ai.config.ollama_url = ollama_url
            os.environ["OLLAMA_URL"] = ollama_url
        self.ai.refresh_provider()
        self.model = model
        self._set_status("ready", self.last_tokens)

    def _show_model_info(self, args: list[str]) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        config = self._load_config()
        if not args:
            lines = [
                f"Provider: {config.get('provider', self.ai.config.default_provider)}",
                f"Model: {config.get('model', self.ai.config.default_model)}",
            ]
            if config.get("ollama_url"):
                lines.append(f"Ollama URL: {config['ollama_url']}")
            timeline.add_system_message("\n".join(lines), title="model")
            timeline.add_system_message("Use /model for interactive selection.", title="model")
            return
        provider = args[0].lower()
        if provider not in PROVIDERS:
            timeline.add_error(f"Unknown provider: {provider}")
            return
        model = args[1] if len(args) > 1 else (PROVIDERS[provider]["models"][0] if PROVIDERS[provider].get("models") else self.ai.config.default_model)
        ollama_url = args[2] if provider == "ollama" and len(args) > 2 else None
        self._apply_model_config(provider, model, ollama_url)
        timeline.add_system_message(f"Provider set to {provider}\nModel set to {model}", title="model")

    def _list_files(self, args: list[str]) -> None:
        path = args[0] if args else "."
        result = self.ai.tools.list_files(path)
        self._render_tool_output(f"files: {path}", result)

    def _read_file(self, args: list[str]) -> None:
        if not args:
            self.query_one("#timeline", MessageTimeline).add_error("Usage: /read <file>")
            return
        result = self.ai.tools.read_file(args[0])
        self._render_tool_output(args[0], result)

    def _exec_command(self, args: list[str]) -> None:
        if not args:
            self.query_one("#timeline", MessageTimeline).add_error("Usage: /exec <command>")
            return
        cmd = " ".join(args)
        result = self.ai.tools.execute_command(cmd)
        self._render_tool_output(f"$ {cmd}", result)

    def _search_web(self, args: list[str]) -> None:
        if not args:
            self.query_one("#timeline", MessageTimeline).add_error("Usage: /search <query>")
            return
        query = " ".join(args)
        result = self.ai.tools.web_search(query)
        self._render_tool_output(f"search: {query}", result)

    def _fetch_page(self, args: list[str]) -> None:
        if not args:
            self.query_one("#timeline", MessageTimeline).add_error("Usage: /fetch <url>")
            return
        result = self.ai.tools.web_fetch(args[0])
        self._render_tool_output(args[0], result)

    def _run_tests(self, args: list[str]) -> None:
        cmd = " ".join(args) if args else "pytest -q"
        result = self.ai.tools.execute_command(cmd)
        self._render_tool_output(f"test: {cmd}", result)

    def _commit_changes(self, args: list[str]) -> None:
        if not args:
            self.query_one("#timeline", MessageTimeline).add_error("Usage: /commit <message>")
            return
        message = " ".join(args)
        self.ai.tools.execute_command("git add -A")
        result = self.ai.tools.execute_command(f"git commit -m {shlex.quote(message)}")
        self._render_tool_output(f"commit: {message}", result)

    def _set_reasoning(self, args: list[str]) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        if not args:
            timeline.add_system_message(f"Current reasoning level: {self.ai.config.reasoning_level}", title="reasoning")
            return
        level = args[0].lower()
        if level not in ["none", "low", "medium", "high"]:
            timeline.add_error("Invalid level. Use: none, low, medium, high")
            return
        self.ai.config.reasoning_level = level
        config = self._load_config()
        config["reasoning_level"] = level
        self._save_config(config)
        timeline.add_system_message(f"Reasoning level set to: {level}", title="reasoning")

    def _handle_todo(self, args: list[str]) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        manager = TodoManager()
        if not args:
            todos = manager.list(self.session_name)
            if not todos:
                timeline.add_system_message("No todos", title="todo")
                return
            timeline.add_system_message("\n".join(format_todo_item(todo) for todo in todos), title="todo")
            return
        action = args[0].lower()
        if action == "add":
            if len(args) < 2:
                timeline.add_error("Usage: /todo add <task>")
                return
            manager.add(" ".join(args[1:]), self.session_name)
            timeline.add_system_message("Todo added", title="todo")
        elif action == "done":
            if len(args) < 2:
                timeline.add_error("Usage: /todo done <id>")
                return
            manager.complete(args[1])
            timeline.add_system_message("Todo marked as done", title="todo")
        elif action == "remove":
            if len(args) < 2:
                timeline.add_error("Usage: /todo remove <id>")
                return
            manager.remove(args[1])
            timeline.add_system_message("Todo removed", title="todo")
        else:
            timeline.add_error("Usage: /todo [add|done|remove] <...>")

    def _set_maxsteps(self, args: list[str]) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        if not args:
            current = self.agent.max_steps if self.agent else self.current_max_steps
            timeline.add_system_message(f"Current max steps: {current}", title="maxsteps")
            return
        try:
            new_limit = int(args[0])
        except ValueError:
            timeline.add_error("Invalid number. Usage: /maxsteps <number>")
            return
        if new_limit < 1:
            timeline.add_error("Max steps must be at least 1")
            return
        if self.agent:
            self.agent.max_steps = new_limit
            self.agent.safety.config.max_steps = new_limit
        self.current_max_steps = new_limit
        os.environ["CODRNINJA_MAX_STEPS"] = str(new_limit)
        timeline.add_system_message(f"Max steps set to: {new_limit}", title="maxsteps")
        self._set_status(self.current_status)

    def _handle_permissions(self, args: list[str]) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        if not self.agent:
            self.agent = Agent(self.ai, self.session_name)
        if not args:
            timeline.add_system_message(f"Current mode: {self.agent.permissions.mode}", title="permissions")
            return
        action = args[0].lower()
        if action == "mode":
            if len(args) < 2:
                timeline.add_error("Usage: /permissions mode <none|ask|auto|strict|relaxed|custom>")
                return
            new_mode = args[1].lower()
            self.agent.permissions.set_mode(new_mode)
            self.agent.permissions.save_config()
            config = self._load_config()
            config["permissions_mode"] = new_mode
            self._save_config(config)
            self.ai.config.permissions_mode = new_mode
            timeline.add_system_message(f"Permission mode set to: {new_mode}", title="permissions")
            return
        if action == "add":
            if len(args) < 4:
                timeline.add_error("Usage: /permissions add <tool> <action> <allow|deny>")
                return
            self.agent.permissions.add_rule(PermissionRule(args[1], args[3], args[2]))
            timeline.add_system_message("Permission rule added", title="permissions")
            return
        if action == "remove":
            if len(args) < 2:
                timeline.add_error("Usage: /permissions remove <index>")
                return
            self.agent.permissions.remove_rule(args[1])
            timeline.add_system_message("Permission rule removed", title="permissions")
            return
        timeline.add_error("Usage: /permissions [mode|add|remove] <...>")

    def _list_subagents(self) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        if not self.agent or not self.agent.subagent_manager:
            timeline.add_system_message("No subagents active", title="subagents")
            return
        subagents = self.agent.subagent_manager.list()
        if not subagents:
            timeline.add_system_message("No active subagents", title="subagents")
            return
        lines = [f"- {s['name']} [{s['status']}]" for s in subagents]
        timeline.add_system_message("\n".join(lines), title="subagents")

    def _handle_mcp_command(self, args: list[str]) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        action = args[0].lower() if args else "list"
        if action == "list":
            self.console_tools.refresh_mcp_tools(force=True)
            servers = self.mcp.list_servers()
            if not servers:
                timeline.add_system_message("No MCP servers configured.", title="mcp")
                return
            lines = [f"- {server.name} [{server.type}] {'enabled' if server.enabled else 'disabled'} ({len(server.tools)} tools)" for server in servers]
            timeline.add_system_message("\n".join(lines), title="mcp")
            return
        if action in {"enable", "disable"}:
            if len(args) < 2:
                timeline.add_error(f"Usage: /mcp {action} <server>")
                return
            ok = self.mcp.enable(args[1]) if action == "enable" else self.mcp.disable(args[1])
            if ok:
                self.console_tools.refresh_mcp_tools(force=True)
                timeline.add_system_message(f"MCP server {action}d: {args[1]}", title="mcp")
            else:
                timeline.add_error(f"Unknown MCP server: {args[1]}")
            return
        if action == "add":
            if len(args) < 2:
                timeline.add_error("Usage: /mcp add <json-config>")
                return
            try:
                config = json.loads(" ".join(args[1:]))
                self.mcp.add_server(config)
                self.console_tools.refresh_mcp_tools(force=True)
                timeline.add_system_message(f"Added MCP server: {config['name']}", title="mcp")
            except Exception as exc:
                timeline.add_error(f"Failed to add MCP server: {exc}")
            return
        timeline.add_error("Usage: /mcp [list|add|enable|disable]")

    def _show_skills(self) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        self.skill_registry.discover()
        skills = self.skill_registry.list_skills()
        if not skills:
            timeline.add_system_message("No skills installed.", title="skills")
            return
        lines = [f"- {skill['name']}: {skill['description']}" for skill in skills]
        timeline.add_system_message("\n".join(lines), title="skills")

    def _render_tool_output(self, title: str, result) -> None:
        timeline = self.query_one("#timeline", MessageTimeline)
        if result.success:
            timeline.add_system_message(str(result.output), title=title)
        else:
            timeline.add_error(str(result.error or result.output))

    def _set_status(self, status: str, tokens: Optional[int] = None) -> None:
        self.current_status = status
        self.query_one("#status", StatusBar).update_status(
            self.model,
            self.current_steps,
            self.current_max_steps,
            status,
            self.last_tokens if tokens is None else tokens,
        )

    def action_clear(self) -> None:
        self.query_one("#timeline", MessageTimeline).clear()

    def action_cancel(self) -> None:
        self.is_busy = False
        self._set_status("ready", self.last_tokens)

    def _load_config(self) -> dict[str, Any]:
        if not os.path.exists(CONFIG_FILE):
            return {}
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)

    def _save_config(self, config: dict[str, Any]) -> None:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)


def main_tui() -> None:
    session_name = os.environ.get("CODRNINJA_SESSION")
    ai = AICode()
    app = CodrninjaTUI(ai=ai, session_name=session_name)
    app.run()


if __name__ == "__main__":
    main_tui()
