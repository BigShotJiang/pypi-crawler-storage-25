"""
This module provides the SDK interface for Pupil functions.

Pupil is a Skill Group of the Telekinesis Agentic Skill Library for image processing. Use this module to access and interact with Pupil-related features programmatically.
"""

import requests
import os
import uuid
from cgi import parse_header
from requests_toolbelt.multipart import decoder
from loguru import logger
import numpy as np
from datatypes import datatypes, serializer
from typing import Optional

_PUPIL_API_BASE_URL = "https://api.telekinesis.ai/pupil/v1/"


def _load_api_key() -> str:
    """
    Load the Telekinesis API key from the environment variable.

    Returns:
        The API key
    """

    api_key = os.getenv("TELEKINESIS_API_KEY")
    if not api_key:
        raise RuntimeError(
            "Telekinesis API key not found.\n\n"
            "Set the TELEKINESIS_API_KEY environment variable."
        )

    return api_key


def _send_request(endpoint: str, input_data: dict) -> dict:
    """
    Send Telekinesis datatypes via multipart/mixed,
    each part = one Arrow IPC stream.
    """
    API_KEY = _load_api_key()

    def write_multipart_request(parts: dict[str, bytes]) -> tuple[bytes, str]:
        boundary = uuid.uuid4().hex
        body = bytearray()

        for name, payload in parts.items():
            body.extend(
                f"--{boundary}\r\n"
                f"Content-Type: application/vnd.apache.arrow.stream\r\n"
                f'Content-Disposition: inline; name="{name}"\r\n\r\n'.encode()
            )
            body.extend(payload)
            body.extend(b"\r\n")

        body.extend(f"--{boundary}--\r\n".encode())
        return bytes(body), boundary

    # ---------- BUILD REQUEST ----------
    fields = {}
    for name, value in input_data.items():
        arrow_bytes = serializer.serialize_to_pyarrow_ipc(value)
        fields[name] = arrow_bytes

    body, boundary = write_multipart_request(fields)

    headers = {
        "X-API-Key": API_KEY,
        "Content-Type": f"multipart/mixed; boundary={boundary}",
        "Content-Length": str(len(body)),
    }

    # ---------- HTTP ----------
    try:
        response = requests.post(
            f"{_PUPIL_API_BASE_URL}{endpoint}",
            data=body,
            headers=headers,
            timeout=130,
            stream=True,
        )

        response_content = response.content  # force full download

    except requests.RequestException as e:
        logger.error(f"Request failed: {e}")
        raise

    # ---------- error handling ----------

    if not response.ok:
        content_type = response.headers.get("Content-Type", "")
        error = (
            response.json()
            if "application/json" in content_type
            else response.text
        )
        raise RuntimeError(f"Request failed [{response.status_code}]: {error}")

    # ---------- PARSE RESPONSE ----------
    content_type = response.headers.get("Content-Type", "")
    if "multipart/" not in content_type:
        raise RuntimeError("Expected multipart response from server")

    decoded_data = decoder.MultipartDecoder.from_response(response)

    output_data = {}
    for part in decoded_data.parts:
        cd = part.headers.get(b"Content-Disposition", b"").decode()
        _, params = parse_header(cd)
        name = params.get("name")
        if not name:
            raise RuntimeError("Missing name in multipart response part")

        output_data[name] = serializer.deserialize_from_pyarrow_ipc(
            part.content
        )

    return output_data


# ===================== Morphology =====================


def filter_image_using_morphological_erode(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies erosion to shrink bright regions and remove small noise.

    Erosion removes pixels from object boundaries, useful for removing small bright
    spots and shrinking objects.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Increasing removes larger
            features but may shrink objects more. Typical range: 3-15. Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times erosion is applied. Increasing applies more
            erosion. Typical range: 1-10. Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the eroded image.
    """

    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )

    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    # Prepare input data
    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
    }

    # Call the API
    end_point = "filter_image_using_morphological_erode"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_morphological_dilate(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies dilation to expand bright regions and fill holes.

    Dilation adds pixels to object boundaries, useful for filling gaps and expanding
    objects.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Increasing expands objects
            more. Typical range: 3-15. Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times dilation is applied. Increasing applies more
            dilation. Typical range: 1-10. Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.0
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the dilated image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    # Prepare input data
    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
    }

    # Call the API
    end_point = "filter_image_using_morphological_dilate"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_morphological_close(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies morphological closing (dilation followed by erosion).

    Closing fills small holes and gaps, useful for connecting nearby components
    while preserving overall shape.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Increasing fills larger
            holes. Typical range: 3-15. Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times closing is applied. Typical range: 1-10.
            Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.0.
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the closed image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
        "morphology_type": datatypes.String("close"),
    }

    end_point = "filter_image_using_morphological"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_morphological_open(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies morphological opening (erosion followed by dilation).

    Opening removes small objects and noise while preserving the overall shape.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Increasing fills larger
            holes. Typical range: 3-15. Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times opening is applied. Typical range: 1-10.
            Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the opened image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
        "morphology_type": datatypes.String("open"),
    }

    end_point = "filter_image_using_morphological"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_morphological_gradient(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies morphological gradient (dilation followed by erosion).

    Morphological gradient highlights boundaries by computing the difference between
    dilation and erosion.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Increasing fills larger
            holes. Typical range: 3-15. Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times gradient is applied. Typical range: 1-10.
            Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the gradient image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
        "morphology_type": datatypes.String("gradient"),
    }

    end_point = "filter_image_using_morphological"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_morphological_tophat(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies morphological tophat (dilation followed by erosion).

    Morphological tophat highlights bright features by computing the difference between
    dilation and erosion.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Increasing fills larger
            holes. Typical range: 3-15. Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times tophat is applied. Typical range: 1-10.
            Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the tophat image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
        "morphology_type": datatypes.String("tophat"),
    }

    end_point = "filter_image_using_morphological"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_morphological_blackhat(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies morphological blackhat (dilation followed by erosion).

    Morphological blackhat highlights dark features by computing the difference between
    dilation and erosion.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Increasing fills larger
            holes. Typical range: 3-15. Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times blackhat is applied. Typical range: 1-10.
            Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the blackhat image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
        "morphology_type": datatypes.String("blackhat"),
    }

    end_point = "filter_image_using_morphological"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_morphological_hitmiss(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    kernel_shape: Optional[datatypes.String | str] = "ellipse",
    iterations: Optional[datatypes.Int | int] = 1,
    border_type: Optional[datatypes.String | str] = "default",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies morphological hit-miss transform for pattern matching.

    Hit-miss detects specific patterns in binary images by matching foreground
    and background pixels simultaneously. Useful for corner detection, thinning,
    and finding custom shapes.

    Args:
        image: The input image to process. Recommended to use a binary image/mask Image object(H, W).
        kernel_size: The size of the structuring element. Typical range: 3-15.
            Default: 3.
        kernel_shape: The shape of the structuring element.
                - "ellipse" (default): Ellipse or circle when kernel is square. Smoother, more isotropic; good for natural shapes and general use.
                - "rectangle": Axis-aligned rectangle. Good for general-purpose morphology; fast and isotropic in rows/columns.
                - "cross": Plus-shaped cross. Thinner than rectangle/ellipse; useful for directional sensitivity and line-like structures.
                - "diamond": Diamond shape. Good for hit-miss and pattern detection; symmetric along diagonals.
            Default: "ellipse".
        iterations: The number of times hit-miss is applied. Typical range: 1-10.
            Default: 1.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".
        border_value: The value to use for "constant" border. Default: 0.
            Only used if border_type is "constant". Value can be negative based on the image dtype.

    Raises:
        TypeError: If image, kernel_size, kernel_shape, iterations, border_type, or border_value has an invalid type.

    Returns:
        A Image object containing the hit-miss filtered image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(kernel_shape, (datatypes.String, str)):
        raise TypeError(
            f"kernel_shape must be a String or str, class received: {type(kernel_shape).__name__}"
        )
    if not isinstance(iterations, (datatypes.Int, int)):
        raise TypeError(
            f"iterations must be an Int or int, class received: {type(iterations).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (int, float)):
        raise TypeError(
            f"border_value must be an int or float, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(kernel_shape, str):
        kernel_shape = datatypes.String(kernel_shape)
    if isinstance(iterations, int):
        iterations = datatypes.Int(iterations)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (int, float)):
        border_value = datatypes.Float(border_value)

    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "kernel_shape": kernel_shape,
        "iterations": iterations,
        "border_type": border_type,
        "border_value": border_value,
        "morphology_type": datatypes.String("hitmiss"),
    }

    end_point = "filter_image_using_morphological"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Ridge / Vesselness =====================


def filter_image_using_frangi(
    image: datatypes.Image | np.ndarray,
    scale_start: Optional[datatypes.Int | int] = 1,
    scale_end: Optional[datatypes.Int | int] = 10,
    scale_step: Optional[datatypes.Int | int] = 2,
    alpha: Optional[datatypes.Float | float | int] = 0.5,
    beta: Optional[datatypes.Float | float | int] = 0.5,
    gamma: Optional[datatypes.Float | float | int] = None,
    detect_black_ridges: Optional[datatypes.Bool | bool] = True,
    border_type: Optional[datatypes.String | str] = "reflect",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies Frangi vesselness filter to enhance tubular structures.

    Frangi filter is designed to detect vessel-like structures in medical images,
    fingerprints, and other images with elongated features.

    Args:
        image: The input image to filter. Should be a grayscale Image object(H, W)
            normalized to 0-1 range.
        scale_start: The minimum scale (sigma) for structure detection.
            Typical range: 1-5. Default: 1.
        scale_end: The maximum scale (sigma) for structure detection.
            Typical range: 5-20. Default: 10.
        scale_step: The step size between scales. Smaller steps provide
            finer scale resolution but are slower. Typical range: 1-5. Default: 2.
        alpha: The weight for the blobness measure. Increasing emphasizes blob-like
            structures. Typical range: 0.1-2.0. Default: 0.5.
        beta: The weight for the second-order structureness. Increasing emphasizes
            tubular structures. Typical range: 0.1-2.0. Default: 0.5.
        gamma: Controls sensitivity to areas of high variance.
            Default (None) sets it to half of the maximum Hessian norm.
        detect_black_ridges: Whether to detect dark ridges (vessels) instead of bright.
            Default: True.
        border_type: The border handling mode.
                - "constant": Pads with a constant value (border_value). Use for black/white borders.
                - "reflect" (default): Reflects image at the border. Good for avoiding edge artifacts in ridge detection.
                - "wrap": Wraps the image around (treats as periodic). Use when image content is periodic.
                - "nearest": Extends with the nearest pixel. Similar to replicate.
                - "mirror": Mirrors (symmetric reflection). Slightly different from reflect at the edge.
            Default: "reflect".
        border_value: The value used for constant padding mode.
            Default: 0.0.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the vesselness-filtered image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(scale_start, (datatypes.Int, int)):
        raise TypeError(
            f"scale_start must be an Int or int, class received: {type(scale_start).__name__}"
        )
    if not isinstance(scale_end, (datatypes.Int, int)):
        raise TypeError(
            f"scale_end must be an Int or int, class received: {type(scale_end).__name__}"
        )
    if not isinstance(scale_step, (datatypes.Int, int)):
        raise TypeError(
            f"scale_step must be an Int or int, class received: {type(scale_step).__name__}"
        )
    if not isinstance(alpha, (datatypes.Float, float, int)):
        raise TypeError(
            f"alpha must be a Float, float, or int, class received: {type(alpha).__name__}"
        )
    if not isinstance(beta, (datatypes.Float, float, int)):
        raise TypeError(
            f"beta must be a Float, float, or int, class received: {type(beta).__name__}"
        )
    if gamma is not None and not isinstance(
        gamma, (datatypes.Float, float, int)
    ):
        raise TypeError(
            f"gamma must be a Float, float, or int, class received: {type(gamma).__name__}"
        )
    if not isinstance(detect_black_ridges, (datatypes.Bool, bool)):
        raise TypeError(
            f"detect_black_ridges must be a Bool or bool, class received: {type(detect_black_ridges).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (datatypes.Float, float, int)):
        raise TypeError(
            f"border_value must be a Float, float, or int, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(scale_start, int):
        scale_start = datatypes.Int(scale_start)
    if isinstance(scale_end, int):
        scale_end = datatypes.Int(scale_end)
    if isinstance(scale_step, int):
        scale_step = datatypes.Int(scale_step)
    if isinstance(alpha, (float, int)):
        alpha = datatypes.Float(alpha)
    if isinstance(beta, (float, int)):
        beta = datatypes.Float(beta)
    if isinstance(detect_black_ridges, bool):
        detect_black_ridges = datatypes.Bool(detect_black_ridges)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (float, int)):
        border_value = datatypes.Float(border_value)

    # Prepare input data
    input_data = {
        "image": image,
        "scale_start": scale_start,
        "scale_end": scale_end,
        "scale_step": scale_step,
        "alpha": alpha,
        "beta": beta,
        "detect_black_ridges": detect_black_ridges,
        "border_type": border_type,
        "border_value": border_value,
    }

    # Add gamma to input data if it is not None
    if gamma is not None:
        input_data["gamma"] = gamma

    # Call the API
    end_point = "filter_image_using_frangi"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_hessian(
    image: datatypes.Image | np.ndarray,
    scale_start: Optional[datatypes.Int | int] = 1,
    scale_end: Optional[datatypes.Int | int] = 10,
    scale_step: Optional[datatypes.Int | int] = 2,
    alpha: Optional[datatypes.Float | float | int] = 0.5,
    beta: Optional[datatypes.Float | float | int] = 0.5,
    gamma: Optional[datatypes.Float | float | int] = 15.0,
    detect_black_ridges: Optional[datatypes.Bool | bool] = True,
    border_type: Optional[datatypes.String | str] = "reflect",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies Hessian-based vesselness filter for tubular structure detection.

    Hessian filter uses eigenvalue analysis to detect vessel-like structures, similar
    to Frangi but with different vesselness measure.

    Args:
        image: The input image to filter. Should be a grayscale Image object(H, W)
            normalized to 0-1 range.
        scale_start: The starting scale (sigma) for multi-scale detection.
            Typical range: 1-5. Default: 1.
        scale_end: The ending scale (sigma) for multi-scale detection.
            Typical range: 5-20. Default: 10.
        scale_step: The step size between scales. Typical range: 1-5. Default: 2.
        alpha: The weight for the blobness measure. Increasing emphasizes blob-like
            structures. Typical range: 0.1-2.0. Default: 0.5.
        beta: The weight for the second-order structureness. Increasing emphasizes
            tubular structures. Typical range: 0.1-2.0. Default: 0.5.
        gamma: The weight for the Hessian norm.Default: 15.0.
        detect_black_ridges: Whether to detect dark ridges instead of bright.
            Default: True.
        border_type: The border handling mode.
                - "constant": Pads with a constant value (border_value). Use for black/white borders.
                - "reflect" (default): Reflects image at the border. Good for avoiding edge artifacts in ridge detection.
                - "wrap": Wraps the image around (treats as periodic). Use when image content is periodic.
                - "nearest": Extends with the nearest pixel. Similar to replicate.
                - "mirror": Mirrors (symmetric reflection). Slightly different from reflect at the edge.
            Default: "reflect".
        border_value: The value used for constant padding mode. Default: 0.0.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the vesselness-filtered image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(scale_start, (datatypes.Int, int)):
        raise TypeError(
            f"scale_start must be an Int or int, class received: {type(scale_start).__name__}"
        )
    if not isinstance(scale_end, (datatypes.Int, int)):
        raise TypeError(
            f"scale_end must be an Int or int, class received: {type(scale_end).__name__}"
        )
    if not isinstance(scale_step, (datatypes.Int, int)):
        raise TypeError(
            f"scale_step must be an Int or int, class received: {type(scale_step).__name__}"
        )
    if not isinstance(alpha, (datatypes.Float, float, int)):
        raise TypeError(
            f"alpha must be a Float, float, or int, class received: {type(alpha).__name__}"
        )
    if not isinstance(beta, (datatypes.Float, float, int)):
        raise TypeError(
            f"beta must be a Float, float, or int, class received: {type(beta).__name__}"
        )
    if gamma is not None and not isinstance(
        gamma, (datatypes.Float, float, int)
    ):
        raise TypeError(
            f"gamma must be a Float, float, or int, class received: {type(gamma).__name__}"
        )
    if not isinstance(detect_black_ridges, (datatypes.Bool, bool)):
        raise TypeError(
            f"detect_black_ridges must be a Bool or bool, class received: {type(detect_black_ridges).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (datatypes.Float, float, int)):
        raise TypeError(
            f"border_value must be a Float, float, or int, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(scale_start, int):
        scale_start = datatypes.Int(scale_start)
    if isinstance(scale_end, int):
        scale_end = datatypes.Int(scale_end)
    if isinstance(scale_step, int):
        scale_step = datatypes.Int(scale_step)
    if isinstance(alpha, (float, int)):
        alpha = datatypes.Float(alpha)
    if isinstance(beta, (float, int)):
        beta = datatypes.Float(beta)
    if isinstance(gamma, (float, int)):
        gamma = datatypes.Float(gamma)
    if isinstance(detect_black_ridges, bool):
        detect_black_ridges = datatypes.Bool(detect_black_ridges)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (float, int)):
        border_value = datatypes.Float(border_value)

    # Prepare input data
    input_data = {
        "image": image,
        "scale_start": scale_start,
        "scale_end": scale_end,
        "scale_step": scale_step,
        "alpha": alpha,
        "beta": beta,
        "detect_black_ridges": detect_black_ridges,
        "border_type": border_type,
        "border_value": border_value,
    }

    # Add gamma to input data if it is not None
    if gamma is not None:
        input_data["gamma"] = gamma

    # Call the API
    end_point = "filter_image_using_hessian"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_sato(
    image: datatypes.Image | np.ndarray,
    scale_start: Optional[datatypes.Int | int] = 1,
    scale_end: Optional[datatypes.Int | int] = 10,
    scale_step: Optional[datatypes.Int | int] = 2,
    detect_black_ridges: Optional[datatypes.Bool | bool] = True,
    border_type: Optional[datatypes.String | str] = "reflect",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies Sato filter for multi-scale ridge detection.

    Sato filter is designed to detect ridges and valleys at multiple scales, useful
    for detecting fine structures like vessels or fibers.

    Args:
        image: The input image to filter. Should be a grayscale Image object(H, W)
            normalized to 0-1 range.
        scale_start: The minimum scale (sigma) for structure detection.
            Typical range: 1-5. Default: 1.
        scale_end: The maximum scale (sigma) for structure detection.
            Typical range: 5-20. Default: 10.
        scale_step: The step size between scales. Typical range: 1-5.
            Default: 2.
        detect_black_ridges: Whether to detect dark ridges instead of bright.
            Default: True.
        border_type: The border handling mode.
                - "constant": Pads with a constant value (border_value). Use for black/white borders.
                - "reflect" (default): Reflects image at the border. Good for avoiding edge artifacts in ridge detection.
                - "wrap": Wraps the image around (treats as periodic). Use when image content is periodic.
                - "nearest": Extends with the nearest pixel. Similar to replicate.
                - "mirror": Mirrors (symmetric reflection). Slightly different from reflect at the edge.
            Default: "reflect".
        border_value: The value used for constant padding mode. Default: 0.0.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the ridge-filtered image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(scale_start, (datatypes.Int, int)):
        raise TypeError(
            f"scale_start must be an Int or int, class received: {type(scale_start).__name__}"
        )
    if not isinstance(scale_end, (datatypes.Int, int)):
        raise TypeError(
            f"scale_end must be an Int or int, class received: {type(scale_end).__name__}"
        )
    if not isinstance(scale_step, (datatypes.Int, int)):
        raise TypeError(
            f"scale_step must be an Int or int, class received: {type(scale_step).__name__}"
        )
    if not isinstance(detect_black_ridges, (datatypes.Bool, bool)):
        raise TypeError(
            f"detect_black_ridges must be a Bool or bool, class received: {type(detect_black_ridges).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (datatypes.Float, float, int)):
        raise TypeError(
            f"border_value must be a Float, float, or int, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(scale_start, int):
        scale_start = datatypes.Int(scale_start)
    if isinstance(scale_end, int):
        scale_end = datatypes.Int(scale_end)
    if isinstance(scale_step, int):
        scale_step = datatypes.Int(scale_step)
    if isinstance(detect_black_ridges, bool):
        detect_black_ridges = datatypes.Bool(detect_black_ridges)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (float, int)):
        border_value = datatypes.Float(border_value)

    # Prepare input data
    input_data = {
        "image": image,
        "scale_start": scale_start,
        "scale_end": scale_end,
        "scale_step": scale_step,
        "detect_black_ridges": detect_black_ridges,
        "border_type": border_type,
        "border_value": border_value,
    }

    # Call the API
    end_point = "filter_image_using_sato"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_meijering(
    image: datatypes.Image | np.ndarray,
    scale_start: Optional[datatypes.Int | int] = 1,
    scale_end: Optional[datatypes.Int | int] = 10,
    scale_step: Optional[datatypes.Int | int] = 2,
    detect_black_ridges: Optional[datatypes.Bool | bool] = True,
    border_type: Optional[datatypes.String | str] = "reflect",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Applies Meijering filter for neurite detection.

    Meijering filter is optimized for detecting neurites and similar branching
    structures in biomedical images.

    Args:
        image: The input image to filter. Should be a grayscale Image object(H, W)
            normalized to 0-1 range.
        scale_start: The minimum scale (sigma) for structure detection.
            Typical range: 1-5. Default: 1.
        scale_end: The maximum scale (sigma) for structure detection.
            Typical range: 5-20. Default: 10.
        scale_step: The step size between scales. Typical range: 1-5.
            Default: 2.
        detect_black_ridges: Whether to detect dark ridges instead of bright.
            Default: True.
        border_type: The border handling mode.
                - "constant": Pads with a constant value (border_value). Use for black/white borders.
                - "reflect" (default): Reflects image at the border. Good for avoiding edge artifacts in ridge detection.
                - "wrap": Wraps the image around (treats as periodic). Use when image content is periodic.
                - "nearest": Extends with the nearest pixel. Similar to replicate.
                - "mirror": Mirrors (symmetric reflection). Slightly different from reflect at the edge.
            Default: "reflect".
        border_value: The value used for constant padding mode. Typical range:
            0.0-1.0. Default: 0.0.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the neurite-filtered image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(scale_start, (datatypes.Int, int)):
        raise TypeError(
            f"scale_start must be an Int or int, class received: {type(scale_start).__name__}"
        )
    if not isinstance(scale_end, (datatypes.Int, int)):
        raise TypeError(
            f"scale_end must be an Int or int, class received: {type(scale_end).__name__}"
        )
    if not isinstance(scale_step, (datatypes.Int, int)):
        raise TypeError(
            f"scale_step must be an Int or int, class received: {type(scale_step).__name__}"
        )
    if not isinstance(detect_black_ridges, (datatypes.Bool, bool)):
        raise TypeError(
            f"detect_black_ridges must be a Bool or bool, class received: {type(detect_black_ridges).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (datatypes.Float, float, int)):
        raise TypeError(
            f"border_value must be a Float, float, or int, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(scale_start, int):
        scale_start = datatypes.Int(scale_start)
    if isinstance(scale_end, int):
        scale_end = datatypes.Int(scale_end)
    if isinstance(scale_step, int):
        scale_step = datatypes.Int(scale_step)
    if isinstance(detect_black_ridges, bool):
        detect_black_ridges = datatypes.Bool(detect_black_ridges)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (float, int)):
        border_value = datatypes.Float(border_value)

    # Prepare input data
    input_data = {
        "image": image,
        "scale_start": scale_start,
        "scale_end": scale_end,
        "scale_step": scale_step,
        "detect_black_ridges": detect_black_ridges,
        "border_type": border_type,
        "border_value": border_value,
    }

    # Call the API
    end_point = "filter_image_using_meijering"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Sharpening / Gradients =====================


def filter_image_using_laplacian(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 1,
    output_format: Optional[datatypes.String | str] = "same as input",
    scale: Optional[datatypes.Float | float | int] = 1.0,
    delta: Optional[datatypes.Float | float | int] = 0.0,
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies Laplacian filter for edge detection using second derivatives.

    Laplacian operator detects edges by finding regions where the second derivative is
    zero or changes sign.

    Args:
        image: The input image to filter. Recommended to be a grayscale Image object(H, W).
        output_format: The output bit depth. Options: "8bit", "16bitS", "16bitU", "32bit", "64bit", "same as input".
            Must be compatible with input image dtype. "16bitS" is signed 16-bit, "16bitU" is unsigned 16-bit.
            Default: "same as input".
        kernel_size: The size of the Laplacian kernel. Increasing
            kernels detect larger edges. Typical values: 1, 3, 5, 7. Default: 1.
            Must be odd and greater than 0.
        scale: The scale factor for the computed Laplacian values. Increasing amplifies
            edge responses. Typical range: 0.1-10.0. Use 0.1-1.0 for subtle edges,
            1.0-5.0 for normal, 5.0-10.0 for strong. Default: 1.0.
        delta: The offset added to the output. Useful for visualization.
            Typical range: -128.0 to 128.0. Default: 0.0.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the edge-detected image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(output_format, (datatypes.String, str)):
        raise TypeError(
            f"output_format must be a String or str, class received: {type(output_format).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(scale, (datatypes.Float, float, int)):
        raise TypeError(
            f"scale must be a Float, float, or int, class received: {type(scale).__name__}"
        )
    if not isinstance(delta, (datatypes.Float, float, int)):
        raise TypeError(
            f"delta must be a Float, float, or int, class received: {type(delta).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(scale, (float, int)):
        scale = datatypes.Float(scale)
    if isinstance(delta, (float, int)):
        delta = datatypes.Float(delta)
    if isinstance(output_format, str):
        output_format = datatypes.String(output_format)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "scale": scale,
        "delta": delta,
        "output_format": output_format,
        "border_type": border_type,
    }

    # Call the API
    end_point = "filter_image_using_laplacian"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_sobel(
    image: datatypes.Image | np.ndarray,
    dx: Optional[datatypes.Int | int] = 1,
    dy: Optional[datatypes.Int | int] = 0,
    kernel_size: Optional[datatypes.Int | int] = 3,
    scale: Optional[datatypes.Float | float | int] = 1.0,
    delta: Optional[datatypes.Float | float | int] = 0.0,
    output_format: Optional[datatypes.String | str] = "same as input",
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies Sobel filter for directional edge detection.

    Sobel operator computes gradients in X and Y directions, useful for detecting edges
    and their orientation.

    Args:
        image: The input image to filter. Recommended to be a grayscale Image object(H, W).
        output_format: The output bit depth. Options: "8bit", "16bitS", "16bitU", "32bit", "64bit", "same as input".
            Must be compatible with input image dtype. "16bitS" is signed 16-bit, "16bitU" is unsigned 16-bit.
            Default: "same as input".
        dx: The order of the derivative in X direction. 0 means no
            derivative, 1 means first derivative (edge detection), 2 means second
            derivative. Typical values: 0, 1, 2. Default: 1.
        dy: The order of the derivative in Y direction. Typical values:
            0, 1, 2. Default: 0.
        kernel_size: The size of the Sobel kernel. Must be 1, 3, 5, 7, or 9. Larger
            kernels detect larger edges. Typical values: 1, 3, 5, 7, 9. Default: 3.
        scale: The scale factor for the computed derivative values. Increasing amplifies
            edge responses. Typical range: 0.1-10.0. Default: 1.0.
        delta: The offset added to the output. Typical range: -128.0 to 128.0.
            Default: 0.0.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the edge-detected image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(output_format, (datatypes.String, str)):
        raise TypeError(
            f"output_format must be a String or str, class received: {type(output_format).__name__}"
        )
    if not isinstance(dx, (datatypes.Int, int)):
        raise TypeError(
            f"dx must be an Int or int, class received: {type(dx).__name__}"
        )
    if not isinstance(dy, (datatypes.Int, int)):
        raise TypeError(
            f"dy must be an Int or int, class received: {type(dy).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(scale, (datatypes.Float, float, int)):
        raise TypeError(
            f"scale must be a Float, float, or int, class received: {type(scale).__name__}"
        )
    if not isinstance(delta, (datatypes.Float, float, int)):
        raise TypeError(
            f"delta must be a Float, float, or int, class received: {type(delta).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(dx, int):
        dx = datatypes.Int(dx)
    if isinstance(dy, int):
        dy = datatypes.Int(dy)
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(scale, (float, int)):
        scale = datatypes.Float(scale)
    if isinstance(delta, (float, int)):
        delta = datatypes.Float(delta)
    if isinstance(output_format, str):
        output_format = datatypes.String(output_format)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "dx": dx,
        "dy": dy,
        "kernel_size": kernel_size,
        "scale": scale,
        "delta": delta,
        "output_format": output_format,  # API still uses desired_depth
        "border_type": border_type,
    }

    # Call the API
    end_point = "filter_image_using_sobel"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_scharr(
    image: datatypes.Image | np.ndarray,
    dx: Optional[datatypes.Int | int] = 1,
    dy: Optional[datatypes.Int | int] = 0,
    scale: Optional[datatypes.Float | float | int] = 1.0,
    delta: Optional[datatypes.Float | float | int] = 0.0,
    output_format: Optional[datatypes.String | str] = "same as input",
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies Scharr filter for improved edge detection accuracy.

    Scharr operator is similar to Sobel but with better rotation invariance and more
    accurate gradient estimation.

    Args:
        image: The input image to filter. Recommended to be a grayscale Image object(H, W).
        output_format: The output bit depth. Options: "8bit", "16bitS", "16bitU", "32bit", "64bit", "same as input".
            Must be compatible with input image dtype. "16bitS" is signed 16-bit, "16bitU" is unsigned 16-bit.
            Default: "same as input".
        dx: The order of the derivative in X direction. Typical values:
            0, 1. Default: 1.
        dy: The order of the derivative in Y direction. Typical values:
            0, 1. Default: 0.
        scale: The scale factor for the computed derivative values. Typical range:
            0.1-10.0. Default: 1.0.
        delta: The offset added to the output. Typical range: -128.0 to 128.0.
            Default: 0.0.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the edge-detected image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(output_format, (datatypes.String, str)):
        raise TypeError(
            f"output_format must be a String or str, class received: {type(output_format).__name__}"
        )
    if not isinstance(dx, (datatypes.Int, int)):
        raise TypeError(
            f"dx must be an Int or int, class received: {type(dx).__name__}"
        )
    if not isinstance(dy, (datatypes.Int, int)):
        raise TypeError(
            f"dy must be an Int or int, class received: {type(dy).__name__}"
        )
    if not isinstance(scale, (datatypes.Float, float, int)):
        raise TypeError(
            f"scale must be a Float, float, or int, class received: {type(scale).__name__}"
        )
    if not isinstance(delta, (datatypes.Float, float, int)):
        raise TypeError(
            f"delta must be a Float, float, or int, class received: {type(delta).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)

    # Validate output_format against input image dtype
    image_np = image.to_numpy()

    if isinstance(dx, int):
        dx = datatypes.Int(dx)
    if isinstance(dy, int):
        dy = datatypes.Int(dy)
    if isinstance(scale, (float, int)):
        scale = datatypes.Float(scale)
    if isinstance(delta, (float, int)):
        delta = datatypes.Float(delta)
    if isinstance(output_format, str):
        output_format = datatypes.String(output_format)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "dx": dx,
        "dy": dy,
        "scale": scale,
        "delta": delta,
        "output_format": output_format,  # API still uses desired_depth
        "border_type": border_type,
    }

    # Call the API
    end_point = "filter_image_using_scharr"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_gabor(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 19,
    standard_deviation: Optional[datatypes.Float | float | int] = 3.0,
    orientation: Optional[datatypes.Float | float | int] = 0.0,
    wavelength: Optional[datatypes.Float | float | int] = 6.0,
    aspect_ratio: Optional[datatypes.Float | float | int] = 0.5,
    phase_offset: Optional[datatypes.Float | float | int] = 90.0,
    delta: Optional[datatypes.Float | float | int] = 0.0,
    output_format: Optional[datatypes.String | str] = "same as input",
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies Gabor filter for texture analysis and feature detection.

    Gabor filters are useful for detecting oriented features and textures at specific
    scales and orientations.

    Args:
        image: The input image to filter. Recommended to be a grayscale Image object(H, W).
        kernel_size: The size of the Gabor kernel. Must be odd. Increasing captures
            larger features. Typical range: 5-51. Use 5-15 for fine textures, 15-31
            for medium, 31-51 for coarse. Default: 19.
            Typically the kernel size is 5xsigma + 1, where sigma is the standard deviation.
        standard_deviation: The standard deviation of the Gaussian envelope. Increasing
            creates a wider filter. Typical range: 1.0-20.0. Default: 3.0.
        orientation: The orientation of the filter in degrees. 0° is horizontal,
            90° is vertical. Typical range: 0.0-180.0. Default: 0.0.
        wavelength: The wavelength of the sinusoidal component. Decreasing detects
            finer features. Typical range: 2.0-50.0. Default: 6.0.
        aspect_ratio: The aspect ratio of the filter (width/height). 1.0 is circular,
            <1.0 is elongated. Typical range: 0.1-1.0. Default: 0.5.
        phase_offset: The phase offset of the sinusoidal component in degrees.
            Typical range: 0.0-360.0. Default: 90.0.
        delta: The offset added to the output. Typical range: -128.0 to 128.0.
            Default: 0.0.
        output_format: The output bit depth. Options: "8bit", "16bitS", "16bitU", "32bit", "64bit", "same as input".
            Must be compatible with input image dtype. "16bitS" is signed 16-bit, "16bitU" is unsigned 16-bit.
            Default: "same as input".
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the filtered image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(standard_deviation, (datatypes.Float, float, int)):
        raise TypeError(
            f"standard_deviation must be a Float, float, or int, class received: {type(standard_deviation).__name__}"
        )
    if not isinstance(orientation, (datatypes.Float, float, int)):
        raise TypeError(
            f"orientation must be a Float, float, or int, class received: {type(orientation).__name__}"
        )
    if not isinstance(wavelength, (datatypes.Float, float, int)):
        raise TypeError(
            f"wavelength must be a Float, float, or int, class received: {type(wavelength).__name__}"
        )
    if not isinstance(aspect_ratio, (datatypes.Float, float, int)):
        raise TypeError(
            f"aspect_ratio must be a Float, float, or int, class received: {type(aspect_ratio).__name__}"
        )
    if not isinstance(phase_offset, (datatypes.Float, float, int)):
        raise TypeError(
            f"phase_offset must be a Float, float, or int, class received: {type(phase_offset).__name__}"
        )
    if not isinstance(delta, (datatypes.Float, float, int)):
        raise TypeError(
            f"delta must be a Float, float, or int, class received: {type(delta).__name__}"
        )
    if not isinstance(output_format, (datatypes.String, str)):
        raise TypeError(
            f"output_format must be a String or str, class received: {type(output_format).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(standard_deviation, (float, int)):
        standard_deviation = datatypes.Float(standard_deviation)
    if isinstance(orientation, (float, int)):
        orientation = datatypes.Float(orientation)
    if isinstance(wavelength, (float, int)):
        wavelength = datatypes.Float(wavelength)
    if isinstance(aspect_ratio, (float, int)):
        aspect_ratio = datatypes.Float(aspect_ratio)
    if isinstance(phase_offset, (float, int)):
        phase_offset = datatypes.Float(phase_offset)
    if isinstance(delta, (float, int)):
        delta = datatypes.Float(delta)
    if isinstance(output_format, str):
        output_format = datatypes.String(output_format)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "standard_deviation": standard_deviation,
        "orientation": orientation,
        "wavelength": wavelength,
        "aspect_ratio": aspect_ratio,
        "phase_offset": phase_offset,
        "delta": delta,
        "output_format": output_format,
        "border_type": border_type,
    }

    # Call the API
    end_point = "filter_image_using_gabor"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Smoothing =====================


def filter_image_using_bilateral(
    image: datatypes.Image | np.ndarray,
    neighborhood_diameter: Optional[datatypes.Int | int] = 9,
    color_intensity_sigma: Optional[datatypes.Float | float | int] = 75.0,
    spatial_sigma: Optional[datatypes.Float | float | int] = 75.0,
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies a bilateral filter to reduce noise while preserving edges.

    Bilateral filtering is effective for noise reduction while maintaining edge sharpness.
    It considers both spatial proximity and color similarity.

    Args:
        image: The input image to filter. Should be a Image object(H, W) or (H, W, C).
        neighborhood_diameter: The size of the kernel for spatial filtering. Must be odd. Increasing
            increases the spatial smoothing area but is slower. Decreasing is faster but
            less effective at smoothing. Typical range: 3-15. Use 3-5 for small images,
            5-9 for medium, 9-15 for large. Default: 9.
        spatial_sigma: The spatial standard deviation in pixels. Increasing makes
            the filter consider pixels farther away, creating more smoothing. Decreasing
            focuses on nearby pixels only. Typical range: 10.0-150.0. Use 10.0-50.0 for
            fine details, 50.0-100.0 for balanced, 100.0-150.0 for strong smoothing.
            Default: 75.0.
        color_intensity_sigma: The color/intensity standard deviation. Increasing allows
            larger color differences to be smoothed, merging more regions. Decreasing
            preserves more color boundaries. Typical range: 10.0-150.0. Use 10.0-50.0
            for strict color preservation, 50.0-100.0 for balanced, 100.0-150.0 for
            more color blending. Default: 75.0.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the filtered image with the same shape as input.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(neighborhood_diameter, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(neighborhood_diameter).__name__}"
        )
    if not isinstance(color_intensity_sigma, (datatypes.Float, float, int)):
        raise TypeError(
            f"spatial_sensitivity must be a Float, float, or int, class received: {type(color_intensity_sigma).__name__}"
        )
    if not isinstance(spatial_sigma, (datatypes.Float, float, int)):
        raise TypeError(
            f"color_sensitivity must be a Float, float, or int, class received: {type(spatial_sigma).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )

    if isinstance(neighborhood_diameter, int):
        neighborhood_diameter = datatypes.Int(neighborhood_diameter)
    if isinstance(color_intensity_sigma, (float, int)):
        color_intensity_sigma = datatypes.Float(color_intensity_sigma)
    if isinstance(spatial_sigma, (float, int)):
        spatial_sigma = datatypes.Float(spatial_sigma)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "spatial_sigma": spatial_sigma,
        "color_intensity_sigma": color_intensity_sigma,
        "neighborhood_diameter": neighborhood_diameter,
        "border_type": border_type,
    }

    # Call the API
    end_point = "filter_image_using_bilateral"
    response_data = _send_request(endpoint=end_point, input_data=input_data)

    # _run_arrow_filter default output_key is "filtered_image"
    filtered_image = response_data["filtered_image"]
    return filtered_image


def filter_image_using_box(
    image: datatypes.Image | np.ndarray,
    output_format: Optional[datatypes.String | str] = "same as input",
    kernel_size: Optional[datatypes.Int | int] = 3,
    normalize: Optional[datatypes.Bool | bool] = True,
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies a normalized box filter with configurable depth and normalization.

    Box filter performs normalized averaging within a kernel region. Useful for basic
    smoothing operations.

    Args:
        image: The input image to filter. Should be a Image object(H, W) or (H, W, C).
        output_format: The output bit depth. Options: "8bit", "16bitS", "16bitU", "32bit", "64bit", "same as input".
            Must be compatible with input image dtype. "16bitS" is signed 16-bit, "16bitU" is unsigned 16-bit.
            Higher depth preserves more precision but uses more memory.
            Default: "same as input".
        kernel_size: The size of the box kernel. Must be odd. Increasing creates larger
            averaging area. Typical range: 3-15. Default: 3.
        normalize: Whether to normalize the kernel so the sum equals 1. When True,
            preserves average brightness. When False, may brighten or darken the image.
            Default: True.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the filtered image with the same shape as input.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(output_format, (datatypes.String, str)):
        raise TypeError(
            f"output_format must be a String or str, class received: {type(output_format).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(normalize, (datatypes.Bool, bool)):
        raise TypeError(
            f"normalize_kernel must be a Bool or bool, class received: {type(normalize).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )

    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(normalize, bool):
        normalize = datatypes.Bool(normalize)
    if isinstance(output_format, str):
        output_format = datatypes.String(output_format)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "border_type": border_type,
        "normalize": normalize,
        "output_format": output_format,
    }

    # Call the API
    end_point = "filter_image_using_box"
    response_data = _send_request(endpoint=end_point, input_data=input_data)

    # _run_arrow_filter default output_key is "filtered_image"
    filtered_image = response_data["filtered_image"]
    return filtered_image


def filter_image_using_gaussian_blur(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    sigma_x: Optional[datatypes.Float | float | int] = 0.0,
    sigma_y: Optional[datatypes.Float | float | int] = 0.0,
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies Gaussian blur for smooth noise reduction.

    Gaussian blur uses a Gaussian kernel for weighted averaging, providing natural-looking
    blur with better edge preservation than simple blur.

    Args:
        image: The input image to filter. Should be a Image object(H, W) or (H, W, C).
        kernel_size: The size of the Gaussian kernel. Must be odd. Increasing creates
            more blur. Typical range: 3-31. Use 3-7 for light blur, 7-15 for moderate,
            15-31 for heavy blur. Default: 3.
        sigma_x: The standard deviation in the X direction. Increasing creates
            more horizontal blur. When 0, computed from kernel_size. Typical range: 0.0-10.0.
            Use 0.0 for auto, 1.0-3.0 for light, 3.0-7.0 for moderate, 7.0-10.0 for heavy.
            Default: 0.0.
        sigma_y: The standard deviation in the Y direction. Increasing creates
            more vertical blur. When 0, computed from kernel_size. Typical range: 0.0-10.0.
            Use 0.0 for auto, 1.0-3.0 for light, 3.0-7.0 for moderate, 7.0-10.0 for heavy.
            Default: 0.0.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the blurred image with the same shape as input.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(sigma_x, (datatypes.Float, float, int)):
        raise TypeError(
            f"sigma_x must be a Float, float, or int, class received: {type(sigma_x).__name__}"
        )
    if not isinstance(sigma_y, (datatypes.Float, float, int)):
        raise TypeError(
            f"sigma_y must be a Float, float, or int, class received: {type(sigma_y).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )

    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(sigma_x, (float, int)):
        sigma_x = datatypes.Float(sigma_x)
    if isinstance(sigma_y, (float, int)):
        sigma_y = datatypes.Float(sigma_y)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "sigma_x": sigma_x,
        "sigma_y": sigma_y,
        "border_type": border_type,
    }

    # Call the API
    end_point = "filter_image_using_gaussian_blur"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_median_blur(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
) -> datatypes.Image:
    """
    Applies median blur to reduce salt-and-pepper noise.

    Median blur replaces each pixel with the median of its neighborhood, effectively
    removing impulse noise while preserving edges.

    Args:
        image: The input image to filter. Should be a Image object(H, W) or (H, W, C).
        kernel_size: The size of the median filter kernel. Must be odd. Increasing removes
            larger noise spots but may blur fine details. Typical range: 3-15. Use 3-5
            for small noise, 5-9 for moderate, 9-15 for heavy noise. Default: 3.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the filtered image with the same shape as input.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )

    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)

    # Prepare input data
    input_data = {"image": image, "kernel_size": kernel_size}

    # Call the API
    end_point = "filter_image_using_median_blur"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def filter_image_using_blur(
    image: datatypes.Image | np.ndarray,
    kernel_size: Optional[datatypes.Int | int] = 3,
    border_type: Optional[datatypes.String | str] = "default",
) -> datatypes.Image:
    """
    Applies a simple box blur filter to an image.

    Box blur is a basic smoothing operation that averages pixel values within a kernel.
    Fast but can blur edges.

    Args:
        image: The input image to filter. Should be a Image object(H, W) or (H, W, C).
        kernel_size: The size of the blur kernel. Must be odd. Increasing creates more
            blur but is slower. Decreasing is faster but less blur. Typical range: 3-31.
            Use 3-7 for light blur, 7-15 for moderate, 15-31 for heavy blur.
            Default: 3.
        border_type: The border handling mode.
                - "default" (default): Same as reflect 101. Library's default for most operations.
                - "constant": Pads with a constant value. Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "default".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the blurred image with the same shape as input.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(kernel_size, (datatypes.Int, int)):
        raise TypeError(
            f"kernel_size must be an Int or int, class received: {type(kernel_size).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )

    if isinstance(kernel_size, int):
        kernel_size = datatypes.Int(kernel_size)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)

    # Prepare input data
    input_data = {
        "image": image,
        "kernel_size": kernel_size,
        "border_type": border_type,
    }

    # Call the API
    end_point = "filter_image_using_blur"
    response_data = _send_request(endpoint=end_point, input_data=input_data)

    # _run_arrow_filter default output_key is "filtered_image"
    filtered_image = response_data["filtered_image"]
    return filtered_image


# ===================== Enhancement =====================


def enhance_image_using_auto_gamma_correction(
    image: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Applies gamma correction for brightness adjustment.

    Gamma correction adjusts image brightness non-linearly, useful for display
    calibration and contrast enhancement.

    Args:
        image: The input image to process. Should be a Image object(H, W) or
            (H, W, C).

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the gamma-corrected image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)

    # Prepare input data
    input_data = {"image": image}

    # Call the API
    end_point = "enhance_image_using_auto_gamma_correction"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def enhance_image_using_white_balance(
    image: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Applies white balance correction to adjust color temperature.

    White balance removes color casts caused by lighting conditions, making images
    appear more natural.

    Args:
        image: The input image to process. Should be a Image object(H, W, C) with
            color channels.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the white-balanced image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)

    # Prepare input data
    input_data = {"image": image}

    # Call the API
    end_point = "enhance_image_using_white_balance"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Contrast =====================


def enhance_image_using_clahe(
    image: datatypes.Image | np.ndarray,
    clip_limit: Optional[datatypes.Float | float | int] = 2.0,
    tile_grid_size: Optional[datatypes.Int | int] = 8,
    color_space: Optional[datatypes.String | str] = "gray",
) -> datatypes.Image:
    """
    Applies Contrast Limited Adaptive Histogram Equalization.

    CLAHE enhances local contrast adaptively, preventing over-amplification of noise
    in uniform regions.

    Args:
        image: The input image to process. Should be a Image object(H, W) or
            (H, W, C).
        clip_limit: The contrast limiting threshold. Increasing allows more contrast
            enhancement but may amplify noise. Typical range: 1.0-8.0. Use 1.0-2.0
            for subtle enhancement, 2.0-4.0 for moderate, 4.0-8.0 for strong.
            Default: 2.0.
        tile_grid_size: The size of the grid for adaptive processing.
            Internally converted to (tile_grid_size, tile_grid_size).
            Increasing tile_grid_size processes larger regions but may lose local detail.
            processes larger regions but may lose local detail. Typical range: 2-16.
            Use 2-4 for fine detail, 4-8 for balanced, 8-16 for coarse. Default: 8.

        color_space: The color space to process. Options: "gray", "lab".
            Default: "gray".

    Note:
        - All images are internally converted to uint8 and unint16 types before processing.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the CLAHE-enhanced image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(clip_limit, (datatypes.Float, float, int)):
        raise TypeError(
            f"clip_limit must be a Float, float, or int, class received: {type(clip_limit).__name__}"
        )
    if not isinstance(tile_grid_size, (datatypes.Int, int)):
        raise TypeError(
            f"tile_grid_size must be an Int or int, class received: {type(tile_grid_size).__name__}"
        )
    if not isinstance(color_space, (datatypes.String, str)):
        raise TypeError(
            f"color_space must be a String or str, class received: {type(color_space).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(clip_limit, (float, int)):
        clip_limit = datatypes.Float(clip_limit)
    if isinstance(tile_grid_size, int):
        tile_grid_size = datatypes.Int(tile_grid_size)
    if isinstance(color_space, str):
        color_space = datatypes.String(color_space)

    # Prepare input point clouds
    input_data = {
        "image": image,
        "clip_limit": clip_limit,
        "tile_grid_size": tile_grid_size,
        "color_space": color_space,
    }

    # Call the API
    end_point = "enhance_image_using_clahe"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Pyramid =====================


def transform_image_using_pyramid_downsampling(
    image: datatypes.Image | np.ndarray,
    scale_factor: Optional[datatypes.Float | float | int] = 0.5,
) -> datatypes.Image:
    """
    Downsamples an image using Gaussian pyramid.

    Pyramid down reduces image resolution, useful for multi-scale analysis and
    efficient processing.

    Args:
        image: The input image to downsample. Should be a Image object(H, W) or
            (H, W, C).
        scale_factor: The scale factor for downsampling. Must be between 0 and 1.
            Decreasing creates smaller output. Typical range: 0.1-0.9. Use 0.5 for
            half size, 0.25 for quarter size. Default: 0.5.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the downsampled image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(scale_factor, (datatypes.Float, float, int)):
        raise TypeError(
            f"scale_factor must be a Float, float, or int, class received: {type(scale_factor).__name__}"
        )

    if isinstance(scale_factor, (float, int)):
        scale_factor = datatypes.Float(scale_factor)

    # Prepare input data
    input_data = {"image": image, "scale_factor": scale_factor}

    # Call the API
    end_point = "transform_image_using_pyramid_downsampling"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def transform_image_using_pyramid_upsampling(
    image: datatypes.Image | np.ndarray,
    scale_factor: Optional[datatypes.Float | float | int] = 2.0,
) -> datatypes.Image:
    """
    Upsamples an image using Gaussian pyramid.

    Pyramid up increases image resolution, useful for image enlargement and
    multi-scale reconstruction.

    Args:
        image: The input image to upsample. Should be a Image object(H, W) or
            (H, W, C).
        scale_factor: The scale factor for upsampling. Must be greater than 1.
            Increasing creates larger output. Typical range: 1.1-4.0. Use 2.0 for
            double size, 4.0 for quadruple size. Default: 2.0.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the upsampled image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(scale_factor, (datatypes.Float, float, int)):
        raise TypeError(
            f"scale_factor must be a Float, float, or int, class received: {type(scale_factor).__name__}"
        )

    if isinstance(scale_factor, (float, int)):
        scale_factor = datatypes.Float(scale_factor)

    # Prepare input data
    input_data = {"image": image, "scale_factor": scale_factor}

    # Call the API
    end_point = "transform_image_using_pyramid_upsampling"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Thinning =====================


def transform_mask_using_blob_thinning(
    image: datatypes.Image | np.ndarray,
    thinning_type: Optional[datatypes.String | str] = "thinning zhangsuen",
) -> datatypes.Image:
    """
    Applies skeletonization (thinning) to binary images.

    Thinning reduces binary objects to their skeletons, useful for shape analysis
    and feature extraction.

    Args:
        image: The input binary image to process. Should be a grayscale numpy array
            (H, W) with values 0 and 255.
        thinning_type: The thinning algorithm to use.
            Options: "thinning zhangsuen", "thinning guohall".
            Default: "thinning zhangsuen".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the skeletonized image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(thinning_type, (datatypes.String, str)):
        raise TypeError(
            f"thinning_type must be a String or str, class received: {type(thinning_type).__name__}"
        )
    if isinstance(thinning_type, str):
        thinning_type = datatypes.String(thinning_type)

    # Prepare input data
    input_data = {"image": image, "thinning_type": thinning_type}

    # Call the API
    end_point = "transform_mask_using_blob_thinning"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Geometry =====================


def calculate_image_pca(
    image: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Computes PCA (Principal Component Analysis) on a binary mask and returns a visualization.

    PCA finds the centroid, eigenvectors, eigenvalues, and principal angle of the mask.
    The output image shows the mask with the centroid and principal axis overlaid.

    Args:
        image: The input image to process. Should be a grayscale or binary Image object (H, W).

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A tuple of (centroid, eigenvectors, eigenvalues, principal_angle).
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)

    input_data = {"image": image}

    end_point = "calculate_image_pca"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    result = (
        response_data["centroid"],
        response_data["eigenvectors"],
        response_data["eigenvalues"],
        response_data["principal_angle"],
    )

    return result


def calculate_image_centroid(
    mask: datatypes.Image | np.ndarray,
) -> datatypes.Position2D:
    """
    Calculates the centroid of non-zero pixels in a binary mask.

    The centroid (cx, cy) is the center of mass of all non-zero pixels.
    Raises ValueError if the mask has no non-zero pixels.

    Args:
        mask: The input binary mask. Should be a Image object or ndarray (H, W)
            with non-zero values indicating the region of interest.

    Raises:
        TypeError: If any parameter has an invalid type.
    Returns:
        A Position2D object containing the centroid coordinates (cx, cy).
    """
    if not isinstance(mask, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"mask must be a Image object or numpy ndarray, class received: {type(mask).__name__}"
        )
    if isinstance(mask, np.ndarray):
        mask = datatypes.Image(mask)

    input_data = {"mask": mask}

    end_point = "calculate_image_centroid"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["centroid"]


# ===================== Color =====================


def convert_image_color_space(
    image: datatypes.Image | np.ndarray,
    source_color_space: datatypes.String | str,
    target_color_space: datatypes.String | str,
) -> datatypes.Image:
    """
    Converts an image between color spaces.

    Args:
        image: The input image to convert. Should be a Image object (H, W) or (H, W, C).
        source_color_space: The source color space.
                Options: "RGB", "BGR", "HSV", "GRAY", "LAB", "YCRCB", "XYZ", "RGBA", "BGRA".
        target_color_space: The target color space.
                Options: "RGB", "BGR", "HSV", "GRAY", "LAB", "YCRCB", "XYZ", "RGBA", "BGRA".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the converted image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(source_color_space, (datatypes.String, str)):
        raise TypeError(
            f"source_color_space must be a String or str, class received: {type(source_color_space).__name__}"
        )
    if not isinstance(target_color_space, (datatypes.String, str)):
        raise TypeError(
            f"target_color_space must be a String or str, class received: {type(target_color_space).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(source_color_space, str):
        source_color_space = datatypes.String(source_color_space)
    if isinstance(target_color_space, str):
        target_color_space = datatypes.String(target_color_space)

    input_data = {
        "image": image,
        "source_color_space": source_color_space,
        "target_color_space": target_color_space,
    }

    end_point = "convert_image_color_space"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["converted_image"]


def normalize_image_intensity(
    image: datatypes.Image | np.ndarray,
    alpha: Optional[datatypes.Float | float | int] = 0.0,
    beta: Optional[datatypes.Float | float | int] = 255.0,
    normalization_method: Optional[datatypes.String | str] = "minmax",
    output_format: Optional[datatypes.String | str] = "same as input",
) -> datatypes.Image:
    """
    Normalizes image intensity values.

    Args:
        image: The input image to normalize. Should be a Image object (H, W) or (H, W, C).
        alpha: Value to normalize to or the lower range boundary in case of the range normalization. Default: 0.0.
        beta: Upper range boundary in case of the range normalization; it is not used for the norm normalization. Default: 255.0.
        normalization_method: The normalization type.
                - "minmax" (default): Scales values to [alpha, beta] range. Best for general image intensity normalization.
                - "inf": L-infinity (maximum absolute value) norm. Good for peak-based scaling.
                - "l1": L1 (sum of absolute values) norm. Preserves total magnitude. Use along with output_format greater than 8bit, else image will be black.
                - "l2": L2 (Euclidean) norm. Common for vector normalization. Use along with output_format greater than 8bit, else image will be black.
            Default: "minmax".
        output_format: Output format - "8bit", "16bitS", "16bitU", "32bit", "64bit", "same as input".
            Default: "same as input".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the normalized image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(alpha, (datatypes.Float, float, int)):
        raise TypeError(
            f"alpha must be a Float, float, or int, class received: {type(alpha).__name__}"
        )
    if not isinstance(beta, (datatypes.Float, float, int)):
        raise TypeError(
            f"beta must be a Float, float, or int, class received: {type(beta).__name__}"
        )
    if not isinstance(normalization_method, (datatypes.String, str)):
        raise TypeError(
            f"normalization_method must be a String or str, class received: {type(normalization_method).__name__}"
        )
    if not isinstance(output_format, (datatypes.String, str)):
        raise TypeError(
            f"output_format must be a String or str, class received: {type(output_format).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(alpha, (float, int)):
        alpha = datatypes.Float(alpha)
    if isinstance(beta, (float, int)):
        beta = datatypes.Float(beta)
    if isinstance(normalization_method, str):
        normalization_method = datatypes.String(normalization_method)
    if isinstance(output_format, str):
        output_format = datatypes.String(output_format)

    input_data = {
        "image": image,
        "alpha": alpha,
        "beta": beta,
        "normalization_method": normalization_method,
        "output_format": output_format,
    }

    end_point = "normalize_image_intensity"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["normalized_image"]


def generate_image_with_solid_color(
    image: datatypes.Image | np.ndarray,
    color: datatypes.String | str = "gray",
) -> datatypes.Image:
    """
    Generates a solid color image with the same dimensions as the reference image.

    Args:
        image: The reference image for dimensions. Should be a Image object (H, W) or (H, W, C).
        color: The color name. Options: "red", "green", "blue", "white", "black", "gray". Default: "gray".

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the solid color image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(color, (datatypes.String, str)):
        raise TypeError(
            f"color must be a String or str, class received: {type(color).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(color, str):
        color = datatypes.String(color)

    input_data = {"image": image, "color": color}

    end_point = "generate_image_with_solid_color"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["generated_image"]


def split_image_into_channels(
    image: datatypes.Image | np.ndarray,
) -> datatypes.ListOfImages:
    """
    Splits an image into its color channels, by default in the same order as the input image.
    For RGB images, the order is (R, G, B).
    For RGBA images, the order is (R, G, B, A).
    For BGR images, the order is (B, G, R).

    Args:
        image: The input image to split. Should be a Image object (H, W, C).
            Grayscale images are converted to BGR before splitting.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A ListOfImages object containing the split channels.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)

    input_data = {"image": image}

    end_point = "split_image_into_channels"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["split_channel_images"]


def merge_image_from_channels(
    channels: datatypes.ListOfImages | list[datatypes.Image] | list[np.ndarray],
) -> datatypes.Image:
    """
    Merges single-channel images into a multi-channel image.

    Args:
        channels:
            Channels to merge. Supported inputs:
                - ListOfImages
                - list[Image]
                - list[np.ndarray]

            Each channel must be of shape (H, W).

    Raises:
        TypeError: If any parameter has an invalid type.
        ValueError: If channels list is empty.

    Returns:
        Image:
            A Image object containing the merged multi-channel image.
    """

    # -----------------------------
    # Normalize input to ListOfImages
    # -----------------------------
    if isinstance(channels, datatypes.ListOfImages):
        channels_list = channels

    elif isinstance(channels, list):
        if len(channels) == 0:
            raise ValueError("channels list cannot be empty")

        image_list = []

        for ch in channels:
            if isinstance(ch, datatypes.Image):
                image_list.append(ch)

            elif isinstance(ch, np.ndarray):
                image_list.append(datatypes.Image(ch))

            else:
                raise TypeError(
                    "channels must contain Image or np.ndarray objects"
                )

        channels_list = datatypes.ListOfImages(image_list=image_list)

    else:
        raise TypeError(
            f"channels must be ListOfImages or list, received {type(channels).__name__}"
        )

    # -----------------------------
    # Send request
    # -----------------------------
    input_data = {"channels": channels_list}

    end_point = "merge_image_from_channels"
    response_data = _send_request(endpoint=end_point, input_data=input_data)

    return response_data["merged_image"]


# ===================== Transform =====================


def resize_image(
    image: datatypes.Image | np.ndarray,
    scale_factor: Optional[datatypes.Float | float | int] = None,
    resize_width: Optional[datatypes.Int | int] = None,
    resize_height: Optional[datatypes.Int | int] = None,
    interpolation_method: Optional[datatypes.String | str] = "linear",
) -> datatypes.Image:
    """
    Resizes an image by a scale factor or to specified dimensions.

    Provide either scale_factor or both resize_width and resize_height.
    - scale_factor: Scales uniformly (preserves aspect ratio).
    - resize_width + resize_height: Resizes to exact dimensions (may stretch/squash).

    Args:
        image: The input image to resize. Should be a Image object (H, W) or (H, W, C).
        scale_factor: Scale factor (e.g., 0.5 for half, 2.0 for double). Mutually exclusive with resize_width/resize_height.
        resize_width: Target width in pixels. Must be used with resize_height.
        resize_height: Target height in pixels. Must be used with resize_width.
        interpolation_method: Interpolation method options:
                - "nearest": Fastest, blocky. Use for masks/labels, depth indices, segmentation maps, binary images (anything discrete where averaging is wrong).
                - "linear" (default): Default for most geometric warps. Good quality vs. speed trade-off. Use for typical images (RGB/gray), small rotations/translations, mild scaling.
                - "cubic": Sharper than linear, slower. Good for 2-4x upscaling or when you want a bit more detail at the cost of time.
                - "area": Designed for downscaling; gives better aliasing behavior than linear when shrinking.
                - "lanczos4": High-quality (internally using windowed sinc filter) resampling. Great for significant upscaling and precise resizes; slower.
                    You might see faint "ripples" or halos around sharp edges, especially if there's high contrast (black-white transitions).
                - "linear exact": More numerically exact linear interpolation (slightly different rounding behavior). If available in your OpenCV build, think of it as linear but stricter.
                - "nearest exact": Like nearest, but exact rounding rules. Useful to ensure deterministic nearest behavior across platforms.

    Raises:
        TypeError: If any parameter has an invalid type.
        ValueError: If both scale_factor and resize dimensions are provided, or neither.

    Returns:
        A Image object containing the resized image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )

    if not isinstance(interpolation_method, (datatypes.String, str)):
        raise TypeError(
            f"interpolation_method must be a String or str, class received: {type(interpolation_method).__name__}"
        )

    if (resize_width is None) != (resize_height is None):
        raise ValueError(
            "Both resize_width and resize_height must be provided together or neither."
        )

    has_scale = scale_factor is not None
    has_dimensions = resize_width is not None and resize_height is not None

    if has_scale and has_dimensions:
        raise ValueError(
            "Provide either scale_factor or both resize_width and resize_height, not both."
        )
    if not has_scale and not has_dimensions:
        raise ValueError(
            "Provide either scale_factor or both resize_width and resize_height."
        )

    if has_scale:
        if not isinstance(scale_factor, (datatypes.Float, float, int)):
            raise TypeError(
                f"scale_factor must be a Float, float, or int, class received: {type(scale_factor).__name__}"
            )
        if isinstance(scale_factor, (float, int)):
            scale_factor = datatypes.Float(scale_factor)
    else:
        if not isinstance(resize_width, (datatypes.Int, int)):
            raise TypeError(
                f"resize_width must be an Int or int, class received: {type(resize_width).__name__}"
            )
        if not isinstance(resize_height, (datatypes.Int, int)):
            raise TypeError(
                f"resize_height must be an Int or int, class received: {type(resize_height).__name__}"
            )
        if isinstance(resize_width, int):
            resize_width = datatypes.Int(resize_width)
        if isinstance(resize_height, int):
            resize_height = datatypes.Int(resize_height)

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(interpolation_method, str):
        interpolation_method = datatypes.String(interpolation_method)

    input_data = {
        "image": image,
        "interpolation_method": interpolation_method,
    }
    if has_scale:
        input_data["scale_factor"] = scale_factor
    else:
        input_data["resize_width"] = resize_width
        input_data["resize_height"] = resize_height

    end_point = "resize_image"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["resized_image"]


def resize_image_with_aspect_fit(
    image: datatypes.Image | np.ndarray,
    resize_width: datatypes.Int | int,
    resize_height: datatypes.Int | int,
    pad_color: Optional[datatypes.Array | np.ndarray | list | tuple] = (
        128,
        128,
        128,
    ),
    interpolation_method: Optional[datatypes.String | str] = "linear",
) -> datatypes.Image:
    """
    Resizes an image to fit within target dimensions while preserving aspect ratio.

    The image is scaled to fit inside the target width and height, with padding
    applied to reach the exact target size. Useful for preparing images for
    fixed-size inputs without distortion.

    Args:
        image: The input image to resize. Should be a Image object (H, W) or (H, W, C).
        resize_width: Target width in pixels.
        resize_height: Target height in pixels.
        pad_color: Padding color as [r, g, b] when image has fewer channels than pad_color.
            If grayscale image, first element is used for padding.
            Default: (128, 128, 128).
        interpolation_method: Interpolation method options:
                - "nearest": Fastest, blocky. Use for masks/labels, depth indices, segmentation maps, binary images (anything discrete where averaging is wrong).
                - "linear" (default): Default for most geometric warps. Good quality vs. speed trade-off. Use for typical images (RGB/gray), small rotations/translations, mild scaling.
                - "cubic": Sharper than linear, slower. Good for 2-4x upscaling or when you want a bit more detail at the cost of time.
                - "area": Designed for downscaling; gives better aliasing behavior than linear when shrinking.
                - "lanczos4": High-quality (internally using windowed sinc filter) resampling. Great for significant upscaling and precise resizes; slower.
                    You might see faint "ripples" or halos around sharp edges, especially if there's high contrast (black-white transitions).
                - "linear exact": More numerically exact linear interpolation (slightly different rounding behavior). If available in your OpenCV build, think of it as linear but stricter.
                - "nearest exact": Like nearest, but exact rounding rules. Useful to ensure deterministic nearest behavior across platforms.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the resized image with aspect fit and padding.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(resize_width, (datatypes.Int, int)):
        raise TypeError(
            f"resize_width must be an Int or int, class received: {type(resize_width).__name__}"
        )
    if not isinstance(resize_height, (datatypes.Int, int)):
        raise TypeError(
            f"resize_height must be an Int or int, class received: {type(resize_height).__name__}"
        )
    if not isinstance(interpolation_method, (datatypes.String, str)):
        raise TypeError(
            f"interpolation_method must be a String or str, class received: {type(interpolation_method).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(resize_width, int):
        resize_width = datatypes.Int(resize_width)
    if isinstance(resize_height, int):
        resize_height = datatypes.Int(resize_height)
    if isinstance(pad_color, (list, tuple, np.ndarray)):
        pad_color = datatypes.Array(value=pad_color)
    if isinstance(interpolation_method, str):
        interpolation_method = datatypes.String(interpolation_method)

    input_data = {
        "image": image,
        "resize_width": resize_width,
        "resize_height": resize_height,
        "pad_color": pad_color,
        "interpolation_method": interpolation_method,
    }

    end_point = "resize_image_with_aspect_fit"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["resized_image"]


def rotate_image(
    image: datatypes.Image | np.ndarray,
    angle_in_deg: datatypes.Float | float | int,
    interpolation_method: Optional[datatypes.String | str] = "linear",
    keep_image_size: Optional[datatypes.Bool | bool] = False,
) -> datatypes.Image:
    """
    Rotates an image by an angle in degrees.

    Args:
        image: The input image to rotate. Should be a Image object (H, W) or (H, W, C).
        angle_in_deg: Rotation angle in degrees (positive = counter-clockwise).
        interpolation_method: Interpolation method options:
                - "nearest": Fastest, blocky. Use for masks/labels, depth indices, segmentation maps, binary images (anything discrete where averaging is wrong).
                - "linear" (default): Default for most geometric warps. Good quality vs. speed trade-off. Use for typical images (RGB/gray), small rotations/translations, mild scaling.
                - "cubic": Sharper than linear, slower. Good for 2-4x upscaling or when you want a bit more detail at the cost of time.
                - "area": Designed for downscaling; gives better aliasing behavior than linear when shrinking.
                - "lanczos4": High-quality (internally using windowed sinc filter) resampling. Great for significant upscaling and precise resizes; slower.
                    You might see faint "ripples" or halos around sharp edges, especially if there's high contrast (black-white transitions).
                - "linear exact": More numerically exact linear interpolation (slightly different rounding behavior). If available in your OpenCV build, think of it as linear but stricter.
                - "nearest exact": Like nearest, but exact rounding rules. Useful to ensure deterministic nearest behavior across platforms.
        keep_image_size: Whether to keep the original image size.   Default: False.
                If True, the rotated image is cropped to the original dimensions, which may cut off corners.
                If False, the output image size is adjusted to fit the entire rotated image.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the rotated image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(angle_in_deg, (datatypes.Float, float, int)):
        raise TypeError(
            f"angle_in_deg must be a Float, float, or int, class received: {type(angle_in_deg).__name__}"
        )
    if not isinstance(interpolation_method, (datatypes.String, str)):
        raise TypeError(
            f"interpolation_method must be a String or str, class received: {type(interpolation_method).__name__}"
        )
    if not isinstance(keep_image_size, (datatypes.Bool, bool)):
        raise TypeError(
            f"keep_image_size must be a Bool or bool, class received: {type(keep_image_size).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(angle_in_deg, (float, int)):
        angle_in_deg = datatypes.Float(angle_in_deg)
    if isinstance(interpolation_method, str):
        interpolation_method = datatypes.String(interpolation_method)
    if isinstance(keep_image_size, bool):
        keep_image_size = datatypes.Bool(keep_image_size)

    input_data = {
        "image": image,
        "angle_in_deg": angle_in_deg,
        "interpolation_method": interpolation_method,
        "keep_image_size": keep_image_size,
    }

    end_point = "rotate_image"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["rotated_image"]


def translate_image(
    image: datatypes.Image | np.ndarray,
    dx: datatypes.Float | float | int,
    dy: datatypes.Float | float | int,
    border_type: Optional[datatypes.String | str] = "constant",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
    interpolation_method: Optional[datatypes.String | str] = "linear",
) -> datatypes.Image:
    """
    Translates (shifts) an image by dx and dy pixels.

    Args:
        image: The input image. Should be a Image object (H, W) or (H, W, C).
        dx: Horizontal shift in pixels (positive = right).
        dy: Vertical shift in pixels (positive = down).
        border_type: The border handling mode.
                - "default": Same as reflect 101. Library's default for most operations.
                - "constant" (default): Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "constant".
        border_value: Fill value for "constant" border. Scalar or [r, g, b]. Default: 0.
        interpolation_method: Interpolation method options:
                - "nearest": Fastest, blocky. Use for masks/labels, depth indices, segmentation maps, binary images (anything discrete where averaging is wrong).
                - "linear" (default): Default for most geometric warps. Good quality vs. speed trade-off. Use for typical images (RGB/gray), small rotations/translations, mild scaling.
                - "cubic": Sharper than linear, slower. Good for 2-4x upscaling or when you want a bit more detail at the cost of time.
                - "area": Designed for downscaling; gives better aliasing behavior than linear when shrinking.
                - "lanczos4": High-quality (internally using windowed sinc filter) resampling. Great for significant upscaling and precise resizes; slower.
                    You might see faint "ripples" or halos around sharp edges, especially if there's high contrast (black-white transitions).
                - "linear exact": More numerically exact linear interpolation (slightly different rounding behavior). If available in your OpenCV build, think of it as linear but stricter.
                - "nearest exact": Like nearest, but exact rounding rules. Useful to ensure deterministic nearest behavior across platforms.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the translated image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(dx, (datatypes.Float, float, int)):
        raise TypeError(
            f"dx must be a Float, float, or int, class received: {type(dx).__name__}"
        )
    if not isinstance(dy, (datatypes.Float, float, int)):
        raise TypeError(
            f"dy must be a Float, float, or int, class received: {type(dy).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (datatypes.Float, float, int)):
        raise TypeError(
            f"border_value must be a Float, float, or int, class received: {type(border_value).__name__}"
        )
    if not isinstance(interpolation_method, (datatypes.String, str)):
        raise TypeError(
            f"interpolation_method must be a String or str, class received: {type(interpolation_method).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(dx, (float, int)):
        dx = datatypes.Float(dx)
    if isinstance(dy, (float, int)):
        dy = datatypes.Float(dy)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (float, int)):
        border_value = datatypes.Float(border_value)
    if isinstance(interpolation_method, str):
        interpolation_method = datatypes.String(interpolation_method)

    input_data = {
        "image": image,
        "dx": dx,
        "dy": dy,
        "border_type": border_type,
        "interpolation_method": interpolation_method,
        "border_value": border_value,
    }
    end_point = "translate_image"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["translated_image"]


def pad_image(
    image: datatypes.Image | np.ndarray,
    top: datatypes.Int | int,
    bottom: datatypes.Int | int,
    left: datatypes.Int | int,
    right: datatypes.Int | int,
    border_type: Optional[datatypes.String | str] = "constant",
    border_value: Optional[datatypes.Float | float | int] = 0.0,
) -> datatypes.Image:
    """
    Pads an image on top, bottom, left, and right.

    Args:
        image: The input image. Should be a Image object (H, W) or (H, W, C).
        top: Padding in pixels on top.
        bottom: Padding in pixels on bottom.
        left: Padding in pixels on left.
        right: Padding in pixels on right.
        border_type: The border handling mode.
                - "default": Same as reflect 101. Library's default for most operations.
                - "constant" (default): Pads with a constant value (border_value). Use for black/white borders or when you need a known fill.
                - "replicate": Replicates the edge pixel. Good for natural-looking edges when the border is similar to the image boundary.
                - "reflect": Reflects image without repeating the edge pixel. Smoother than replicate for some filters.
                - "reflect 101": Reflects with the edge pixel repeated. Often best for avoiding dark borders in convolution.
            Default: "constant".
        border_value: Fill value for "constant" border. Scalar or [r, g, b]. Default: 0.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the padded image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(top, (datatypes.Int, int)):
        raise TypeError(
            f"top must be an Int or int, class received: {type(top).__name__}"
        )
    if not isinstance(bottom, (datatypes.Int, int)):
        raise TypeError(
            f"bottom must be an Int or int, class received: {type(bottom).__name__}"
        )
    if not isinstance(left, (datatypes.Int, int)):
        raise TypeError(
            f"left must be an Int or int, class received: {type(left).__name__}"
        )
    if not isinstance(right, (datatypes.Int, int)):
        raise TypeError(
            f"right must be an Int or int, class received: {type(right).__name__}"
        )
    if not isinstance(border_type, (datatypes.String, str)):
        raise TypeError(
            f"border_type must be a String or str, class received: {type(border_type).__name__}"
        )
    if not isinstance(border_value, (datatypes.Float, float, int)):
        raise TypeError(
            f"border_value must be a Float, float, or int, class received: {type(border_value).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(top, int):
        top = datatypes.Int(top)
    if isinstance(bottom, int):
        bottom = datatypes.Int(bottom)
    if isinstance(left, int):
        left = datatypes.Int(left)
    if isinstance(right, int):
        right = datatypes.Int(right)
    if isinstance(border_type, str):
        border_type = datatypes.String(border_type)
    if isinstance(border_value, (float, int)):
        border_value = datatypes.Float(border_value)

    input_data = {
        "image": image,
        "top": top,
        "bottom": bottom,
        "left": left,
        "right": right,
        "border_type": border_type,
        "border_value": border_value,
    }

    end_point = "pad_image"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["padded_image"]


def crop_image_center(
    image: datatypes.Image | np.ndarray,
    crop_width: datatypes.Int | int,
    crop_height: datatypes.Int | int,
    pad_color: Optional[datatypes.Array | np.ndarray | list | tuple] = (
        128,
        128,
        128,
    ),
) -> datatypes.Image:
    """
    Crops an image to the specified dimensions.

    If the image is smaller than crop_width x crop_height, padding is applied.

    Args:
        image: The input image. Should be a Image object (H, W) or (H, W, C).
        crop_width: Target width of the crop.
        crop_height: Target height of the crop.
        pad_color: Padding value when image is smaller than crop size. Scalar or [r, g, b].
            If grayscale image, first element is used for padding.
            Default: (128, 128, 128).

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the center-cropped image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(crop_width, (datatypes.Int, int)):
        raise TypeError(
            f"crop_width must be an Int or int, class received: {type(crop_width).__name__}"
        )
    if not isinstance(crop_height, (datatypes.Int, int)):
        raise TypeError(
            f"crop_height must be an Int or int, class received: {type(crop_height).__name__}"
        )

    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(crop_width, int):
        crop_width = datatypes.Int(crop_width)
    if isinstance(crop_height, int):
        crop_height = datatypes.Int(crop_height)
    if isinstance(pad_color, (np.ndarray, list, tuple)):
        pad_color = datatypes.Array(value=pad_color)

    input_data = {
        "image": image,
        "crop_width": crop_width,
        "crop_height": crop_height,
        "pad_color": pad_color,
    }

    end_point = "crop_image_center"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["cropped_image"]


def crop_image_using_bounding_boxes(
    image: datatypes.Image | np.ndarray,
    bounding_boxes: datatypes.Boxes2D | np.ndarray | list,
    retain_coordinates: Optional[datatypes.Bool | bool] = False,
    strict_bounds: Optional[datatypes.Bool | bool] = False,
) -> datatypes.ListOfImages:
    """
    Crops an image using multiple bounding boxes.

    Args:
        image: The input image to crop. Should be a Image object (H, W) or (H, W, C).
        bounding_boxes: Array of bounding boxes with format: [x, y, width, height]. Shape (N, 4).
        retain_coordinates: Whether to retain coordinate system. Default: False.
        strict_bounds: Whether to strictly enforce bounding box bounds. Default: False.
    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        List of cropped Image objects.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(bounding_boxes, (datatypes.Boxes2D, np.ndarray, list)):
        raise TypeError(
            f"bounding_boxes must be a list, tuple, or numpy array, class received: {type(bounding_boxes).__name__}"
        )
    if not isinstance(retain_coordinates, (datatypes.Bool, bool)):
        raise TypeError(
            f"retain_coordinates must be a Bool or bool, class received: {type(retain_coordinates).__name__}"
        )
    if not isinstance(strict_bounds, (datatypes.Bool, bool)):
        raise TypeError(
            f"strict_bounds must be a Bool or bool, class received: {type(strict_bounds).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)

    if isinstance(bounding_boxes, (list, tuple, np.ndarray)):
        bounding_boxes = datatypes.Boxes2D(
            arrays=bounding_boxes, array_format="XYWH"
        )

    if isinstance(retain_coordinates, bool):
        retain_coordinates = datatypes.Bool(retain_coordinates)

    if isinstance(strict_bounds, bool):
        strict_bounds = datatypes.Bool(strict_bounds)

    input_data = {
        "image": image,
        "bounding_boxes": bounding_boxes,
        "retain_coordinates": retain_coordinates,
        "strict_bounds": strict_bounds,
    }

    end_point = "crop_image_using_bounding_boxes"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["cropped_image"]


def crop_image_using_polygon(
    image: datatypes.Image | np.ndarray,
    polygon_vertices: datatypes.Array | np.ndarray | list,
) -> datatypes.Image:
    """
    Crops an image using a polygon mask.

    Args:
        image: The input image to crop. Should be a Image object (H, W) or (H, W, C).
        polygon_vertices: Polygon vertices as array of (x, y) points. Shape (N, 2) or flat list.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the cropped image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if not isinstance(polygon_vertices, (datatypes.Array, np.ndarray, list)):
        raise TypeError(
            f"polygon_vertices must be a Array, np.ndarray, or list, class received: {type(polygon_vertices).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)
    if isinstance(polygon_vertices, (np.ndarray, list)):
        polygon_vertices = datatypes.Array(value=polygon_vertices)

    input_data = {
        "image": image,
        "polygon_vertices": polygon_vertices,
    }

    end_point = "crop_image_using_polygon"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["cropped_image"]


# ===================== Operations (Bitwise / Overlay) =====================


def bitwise_and_images(
    image_a: datatypes.Image | np.ndarray,
    image_b: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Performs bitwise AND between two images and masks (binary images).

    Args:
        image_a: First input image. Should be a Image object (H, W) or (H, W, C).
        image_b: Second input image. Must have same shape as image_a.

    Raises:
        TypeError: If any parameter has an invalid type.
        ValueError: If image_a and image_b have different width or height.

    Returns:
        A Image object containing the bitwise AND result.
    """
    if not isinstance(image_a, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_a must be a Image object or numpy ndarray, class received: {type(image_a).__name__}"
        )
    if not isinstance(image_b, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_b must be a Image object or numpy ndarray, class received: {type(image_b).__name__}"
        )
    if isinstance(image_a, np.ndarray):
        image_a = datatypes.Image(image_a)
    if isinstance(image_b, np.ndarray):
        image_b = datatypes.Image(image_b)

    input_data = {
        "image_a": image_a,
        "image_b": image_b,
    }

    end_point = "bitwise_and_images"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def bitwise_or_images(
    image_a: datatypes.Image | np.ndarray,
    image_b: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Performs bitwise OR between two images.

    Args:
        image_a: First input image. Should be a Image object (H, W) or (H, W, C).
        image_b: Second input image. Must have same shape as image_a.

    Raises:
        TypeError: If any parameter has an invalid type.
        ValueError: If image_a and image_b have different width or height.

    Returns:
        A Image object containing the bitwise OR result.
    """
    if not isinstance(image_a, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_a must be a Image object or numpy ndarray, class received: {type(image_a).__name__}"
        )
    if not isinstance(image_b, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_b must be a Image object or numpy ndarray, class received: {type(image_b).__name__}"
        )
    if isinstance(image_a, np.ndarray):
        image_a = datatypes.Image(image_a)
    if isinstance(image_b, np.ndarray):
        image_b = datatypes.Image(image_b)

    input_data = {
        "image_a": image_a,
        "image_b": image_b,
    }

    end_point = "bitwise_or_images"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def bitwise_xor_images(
    image_a: datatypes.Image | np.ndarray,
    image_b: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Performs bitwise XOR between two images.

    Args:
        image_a: First input image. Should be a Image object (H, W) or (H, W, C).
        image_b: Second input image. Must have same shape as image_a.

    Raises:
        TypeError: If any parameter has an invalid type.
        ValueError: If image_a and image_b have different width or height.

    Returns:
        A Image object containing the bitwise XOR result.
    """
    if not isinstance(image_a, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_a must be a Image object or numpy ndarray, class received: {type(image_a).__name__}"
        )
    if not isinstance(image_b, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_b must be a Image object or numpy ndarray, class received: {type(image_b).__name__}"
        )
    if isinstance(image_a, np.ndarray):
        image_a = datatypes.Image(image_a)
    if isinstance(image_b, np.ndarray):
        image_b = datatypes.Image(image_b)

    input_data = {
        "image_a": image_a,
        "image_b": image_b,
    }

    end_point = "bitwise_xor_images"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def bitwise_difference_images(
    image_a: datatypes.Image | np.ndarray,
    image_b: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Performs bitwise difference (absolute difference) between two images.

    Args:
        image_a: First input image. Should be a Image object (H, W) or (H, W, C).
        image_b: Second input image. Must have same shape as image_a.

    Raises:
        TypeError: If any parameter has an invalid type.
        ValueError: If image_a and image_b have different width or height.

    Returns:
        A Image object containing the difference result.
    """
    if not isinstance(image_a, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_a must be a Image object or numpy ndarray, class received: {type(image_a).__name__}"
        )
    if not isinstance(image_b, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_b must be a Image object or numpy ndarray, class received: {type(image_b).__name__}"
        )
    if isinstance(image_a, np.ndarray):
        image_a = datatypes.Image(image_a)
    if isinstance(image_b, np.ndarray):
        image_b = datatypes.Image(image_b)

    input_data = {
        "image_a": image_a,
        "image_b": image_b,
    }

    end_point = "bitwise_difference_images"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def bitwise_not_image(
    image: datatypes.Image | np.ndarray,
) -> datatypes.Image:
    """
    Performs bitwise NOT (inversion) on an image.

    Args:
        image: The input image to invert. Should be a Image object (H, W) or (H, W, C).

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Image object containing the inverted image.
    """
    if not isinstance(image, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image must be a Image object or numpy ndarray, class received: {type(image).__name__}"
        )
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image)

    input_data = {
        "image": image,
    }

    end_point = "bitwise_not_image"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


def overlay_images_using_weighted_overlay(
    image_a: datatypes.Image | np.ndarray,
    image_b: datatypes.Image | np.ndarray,
    weight_a: Optional[datatypes.Float | float | int] = 0.5,
    weight_b: Optional[datatypes.Float | float | int] = 0.5,
) -> datatypes.Image:
    """
    Blends two images using weighted overlay.

    Args:
        image_a: First input image. Should be a Image object (H, W) or (H, W, C).
        image_b: Second input image. Must have same shape as image_a.
        weight_a: Weight for first image. Default: 0.5.
        weight_b: Weight for second image. Default: 0.5.

    Raises:
        TypeError: If any parameter has an invalid type.
        ValueError: If image_a and image_b have different width or height.

    Returns:
        A Image object containing the blended image.
    """
    if not isinstance(image_a, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_a must be a Image object or numpy ndarray, class received: {type(image_a).__name__}"
        )
    if not isinstance(image_b, (datatypes.Image, np.ndarray)):
        raise TypeError(
            f"image_b must be a Image object or numpy ndarray, class received: {type(image_b).__name__}"
        )

    if not isinstance(weight_a, (datatypes.Float, float, int)):
        raise TypeError(
            f"weight_a must be a Float, float, or int, class received: {type(weight_a).__name__}"
        )
    if not isinstance(weight_b, (datatypes.Float, float, int)):
        raise TypeError(
            f"weight_b must be a Float, float, or int, class received: {type(weight_b).__name__}"
        )
    if isinstance(image_a, np.ndarray):
        image_a = datatypes.Image(image_a)
    if isinstance(image_b, np.ndarray):
        image_b = datatypes.Image(image_b)
    if isinstance(weight_a, (float, int)):
        weight_a = datatypes.Float(weight_a)
    if isinstance(weight_b, (float, int)):
        weight_b = datatypes.Float(weight_b)

    input_data = {
        "image_a": image_a,
        "image_b": image_b,
        "weight_a": weight_a,
        "weight_b": weight_b,
    }

    end_point = "overlay_images_using_weighted_overlay"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["filtered_image"]


# ===================== Projection =====================


def project_pixel_to_camera_point(
    camera_intrinsics: datatypes.Mat3X3 | np.ndarray | list,
    distortion_coefficients: datatypes.Array | np.ndarray | list,
    pixel: datatypes.Position2D | np.ndarray | list,
    depth: datatypes.Float | float | int,
    theta: Optional[datatypes.Float | float | int] = None,
) -> datatypes.Mat4X4:
    """
    Projects a pixel and depth to a 3D point in camera coordinates.

    Args:
        camera_intrinsics: 3x3 camera intrinsic matrix (fx, fy, cx, cy, etc.).
            Accepts Mat3X3, numpy ndarray (3,3), or list.
        distortion_coefficients: Lens distortion coefficients (e.g., k1, k2, p1, p2, k3).
            Accepts Array, numpy ndarray, or list.
        pixel: Pixel coordinates (x, y) as array or list of length 2.
            Accepts Position2D, numpy ndarray, or list.
        depth: Depth value at the pixel (in same units as camera).
        theta: Optional angle parameter. Default: None.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Mat4X4 object representing the camera-to-point transformation (camera_T_point).
    """
    if not isinstance(camera_intrinsics, (datatypes.Mat3X3, np.ndarray, list)):
        raise TypeError(
            f"camera_intrinsics must be a Mat3X3, np.ndarray, or list, class received: {type(camera_intrinsics).__name__}"
        )
    if not isinstance(
        distortion_coefficients, (datatypes.Array, np.ndarray, list)
    ):
        raise TypeError(
            f"distortion_coefficients must be a Array, np.ndarray, or list, class received: {type(distortion_coefficients).__name__}"
        )
    if not isinstance(pixel, (datatypes.Position2D, np.ndarray, list)):
        raise TypeError(
            f"pixel must be a Position2D, np.ndarray, or list, class received: {type(pixel).__name__}"
        )
    if not isinstance(depth, (datatypes.Float, float, int)):
        raise TypeError(
            f"depth must be a Float, float, or int, class received: {type(depth).__name__}"
        )
    if theta is not None and not isinstance(
        theta, (datatypes.Float, float, int)
    ):
        raise TypeError(
            f"theta must be a Float, float, or int, class received: {type(theta).__name__}"
        )

    if isinstance(camera_intrinsics, (np.ndarray, list)):
        camera_intrinsics = datatypes.Mat3X3(
            matrix=np.asarray(camera_intrinsics, dtype=np.float32)
        )
    if isinstance(distortion_coefficients, (np.ndarray, list)):
        distortion_coefficients = datatypes.Array(
            value=np.asarray(distortion_coefficients, dtype=np.float64)
        )
    if isinstance(pixel, (np.ndarray, list)):
        pixel = datatypes.Position2D(xy=np.asarray(pixel, dtype=np.float32))
    if isinstance(depth, (float, int)):
        depth = datatypes.Float(depth)

    input_data = {
        "camera_intrinsics": camera_intrinsics,
        "distortion_coefficients": distortion_coefficients,
        "pixel": pixel,
        "depth": depth,
    }
    if theta is not None:
        if isinstance(theta, (float, int)):
            theta = datatypes.Float(theta)
        input_data["theta"] = theta
    else:
        input_data["theta"] = datatypes.Float(0.0)

    end_point = "project_pixel_to_camera_point"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["camera_T_point"]


def project_camera_point_to_pixel(
    camera_intrinsics: datatypes.Mat3X3 | np.ndarray | list,
    distortion_coefficients: datatypes.Array | np.ndarray | list,
    point: datatypes.Position3D | np.ndarray | list,
) -> datatypes.Position2D:
    """
    Projects a 3D point in camera coordinates to pixel coordinates.

    Args:
        camera_intrinsics: 3x3 camera intrinsic matrix.
            Accepts Mat3X3, numpy ndarray (3,3), or list.
        distortion_coefficients: Lens distortion coefficients.
            Accepts Array, numpy ndarray, or list.
        point: 3D point (x, y, z) in camera coordinates.
            Accepts Position3D, numpy ndarray, or list.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Position2D object containing the projected pixel coordinates.
    """
    if not isinstance(camera_intrinsics, (datatypes.Mat3X3, np.ndarray, list)):
        raise TypeError(
            f"camera_intrinsics must be a Mat3X3, np.ndarray, or list, class received: {type(camera_intrinsics).__name__}"
        )
    if not isinstance(
        distortion_coefficients, (datatypes.Array, np.ndarray, list)
    ):
        raise TypeError(
            f"distortion_coefficients must be a Array, np.ndarray, or list, class received: {type(distortion_coefficients).__name__}"
        )
    if not isinstance(point, (datatypes.Position3D, np.ndarray, list)):
        raise TypeError(
            f"point must be a Position3D, np.ndarray, or list, class received: {type(point).__name__}"
        )

    if isinstance(camera_intrinsics, (np.ndarray, list)):
        camera_intrinsics = datatypes.Mat3X3(
            matrix=np.asarray(camera_intrinsics, dtype=np.float32)
        )
    if isinstance(distortion_coefficients, (np.ndarray, list)):
        distortion_coefficients = datatypes.Array(
            value=np.asarray(distortion_coefficients, dtype=np.float64)
        )
    if isinstance(point, (np.ndarray, list)):
        point = datatypes.Position3D(xyz=np.asarray(point, dtype=np.float32))

    input_data = {
        "camera_intrinsics": camera_intrinsics,
        "distortion_coefficients": distortion_coefficients,
        "point": point,
    }

    end_point = "project_camera_point_to_pixel"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["pixel"]


def project_pixel_to_world_point(
    camera_intrinsics: datatypes.Mat3X3 | np.ndarray | list,
    distortion_coefficients: datatypes.Array | np.ndarray | list,
    pixel: datatypes.Position2D | np.ndarray | list,
    depth: datatypes.Float | float | int,
    world_T_camera: datatypes.Mat4X4 | np.ndarray | list,
) -> datatypes.Mat4X4:
    """
    Projects a pixel and depth to a 3D point in world coordinates.

    Args:
        camera_intrinsics: 3x3 camera intrinsic matrix.
            Accepts Mat3X3, numpy ndarray (3,3), or list.
        distortion_coefficients: Lens distortion coefficients.
            Accepts Array, numpy ndarray, or list.
        pixel: Pixel coordinates (x, y) as array or list of length 2.
            Accepts Position2D, numpy ndarray, or list.
        depth: Depth value at the pixel.
        world_T_camera: 4x4 transformation matrix from camera to world coordinates.
            Accepts Mat4X4, numpy ndarray (4,4), or list.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Mat4X4 object representing the world-to-point transformation (world_T_point).
    """
    if not isinstance(camera_intrinsics, (datatypes.Mat3X3, np.ndarray, list)):
        raise TypeError(
            f"camera_intrinsics must be a Mat3X3, np.ndarray, or list, class received: {type(camera_intrinsics).__name__}"
        )
    if not isinstance(
        distortion_coefficients, (datatypes.Array, np.ndarray, list)
    ):
        raise TypeError(
            f"distortion_coefficients must be a Array, np.ndarray, or list, class received: {type(distortion_coefficients).__name__}"
        )
    if not isinstance(pixel, (datatypes.Position2D, np.ndarray, list)):
        raise TypeError(
            f"pixel must be a Position2D, np.ndarray, or list, class received: {type(pixel).__name__}"
        )
    if not isinstance(depth, (datatypes.Float, float, int)):
        raise TypeError(
            f"depth must be a Float, float, or int, class received: {type(depth).__name__}"
        )
    if not isinstance(world_T_camera, (datatypes.Mat4X4, np.ndarray, list)):
        raise TypeError(
            f"world_T_camera must be a Mat4X4, np.ndarray, or list, class received: {type(world_T_camera).__name__}"
        )

    if isinstance(camera_intrinsics, (np.ndarray, list)):
        camera_intrinsics = datatypes.Mat3X3(
            matrix=np.asarray(camera_intrinsics, dtype=np.float32)
        )
    if isinstance(distortion_coefficients, (np.ndarray, list)):
        distortion_coefficients = datatypes.Array(
            value=np.asarray(distortion_coefficients, dtype=np.float64)
        )
    if isinstance(pixel, (np.ndarray, list)):
        pixel = datatypes.Position2D(xy=np.asarray(pixel, dtype=np.float32))
    if isinstance(depth, (float, int)):
        depth = datatypes.Float(depth)
    if isinstance(world_T_camera, (np.ndarray, list)):
        world_T_camera = datatypes.Mat4X4(
            matrix=np.asarray(world_T_camera, dtype=np.float32)
        )

    input_data = {
        "camera_intrinsics": camera_intrinsics,
        "distortion_coefficients": distortion_coefficients,
        "pixel": pixel,
        "depth": depth,
        "world_T_camera": world_T_camera,
    }

    end_point = "project_pixel_to_world_point"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["world_T_point"]


def project_world_point_to_pixel(
    camera_intrinsics: datatypes.Mat3X3 | np.ndarray | list,
    distortion_coefficients: datatypes.Array | np.ndarray | list,
    point: datatypes.Position3D | np.ndarray | list,
    world_T_camera: datatypes.Mat4X4 | np.ndarray | list,
) -> datatypes.Position2D:
    """
    Projects a 3D point in world coordinates to pixel coordinates.

    Args:
        camera_intrinsics: 3x3 camera intrinsic matrix.
            Accepts Mat3X3, numpy ndarray (3,3), or list.
        distortion_coefficients: Lens distortion coefficients.
            Accepts Array, numpy ndarray, or list.
        point: 3D point (x, y, z) in world coordinates.
            Accepts Position3D, numpy ndarray, or list.
        world_T_camera: 4x4 transformation matrix from camera to world coordinates.
            Accepts Mat4X4, numpy ndarray (4,4), or list.

    Raises:
        TypeError: If any parameter has an invalid type.

    Returns:
        A Position2D object containing the projected pixel coordinates.
    """
    if not isinstance(camera_intrinsics, (datatypes.Mat3X3, np.ndarray, list)):
        raise TypeError(
            f"camera_intrinsics must be a Mat3X3, np.ndarray, or list, class received: {type(camera_intrinsics).__name__}"
        )
    if not isinstance(
        distortion_coefficients, (datatypes.Array, np.ndarray, list)
    ):
        raise TypeError(
            f"distortion_coefficients must be a Array, np.ndarray, or list, class received: {type(distortion_coefficients).__name__}"
        )
    if not isinstance(point, (datatypes.Position3D, np.ndarray, list)):
        raise TypeError(
            f"point must be a Position3D, np.ndarray, or list, class received: {type(point).__name__}"
        )
    if not isinstance(world_T_camera, (datatypes.Mat4X4, np.ndarray, list)):
        raise TypeError(
            f"world_T_camera must be a Mat4X4, np.ndarray, or list, class received: {type(world_T_camera).__name__}"
        )

    if isinstance(camera_intrinsics, (np.ndarray, list)):
        camera_intrinsics = datatypes.Mat3X3(
            matrix=np.asarray(camera_intrinsics, dtype=np.float32)
        )
    if isinstance(distortion_coefficients, (np.ndarray, list)):
        distortion_coefficients = datatypes.Array(
            value=np.asarray(distortion_coefficients, dtype=np.float64)
        )
    if isinstance(point, (np.ndarray, list)):
        point = datatypes.Position3D(xyz=np.asarray(point, dtype=np.float32))
    if isinstance(world_T_camera, (np.ndarray, list)):
        world_T_camera = datatypes.Mat4X4(
            matrix=np.asarray(world_T_camera, dtype=np.float32)
        )

    input_data = {
        "camera_intrinsics": camera_intrinsics,
        "distortion_coefficients": distortion_coefficients,
        "point": point,
        "world_T_camera": world_T_camera,
    }

    end_point = "project_world_point_to_pixel"
    response_data = _send_request(endpoint=end_point, input_data=input_data)
    return response_data["pixel"]
