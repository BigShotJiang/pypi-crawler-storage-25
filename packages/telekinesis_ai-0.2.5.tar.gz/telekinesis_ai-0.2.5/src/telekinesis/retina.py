"""Retina SDK functions for image object detection.

Retina is a skill group in the Telekinesis agentic skill library for image
object detection. Use this module to call Retina endpoints and deserialize
typed results.
"""

import numpy as np
import requests
import os
from requests_toolbelt.multipart import decoder
import uuid
from cgi import parse_header
from loguru import logger
from datatypes import datatypes, serializer

_RETINA_API_BASE_URL = "https://api.telekinesis.ai/retina/v1/"


def _load_api_key() -> str:
    """Load the Telekinesis API key from the environment.

    Returns:
      str: The value of the `TELEKINESIS_API_KEY` environment variable.

    Raises:
        RuntimeError: If `TELEKINESIS_API_KEY` is not set.
    """
    api_key = os.getenv("TELEKINESIS_API_KEY")
    if not api_key:
        raise RuntimeError(
            "Telekinesis API key not found.\n\n"
            "Set the TELEKINESIS_API_KEY environment variable."
        )

    return api_key


def _send_request(endpoint: str, input_data: dict) -> dict:
    """Send a multipart/mixed request to the Retina API.

    Serializes `input_data` values to Arrow IPC and posts them to `endpoint`.
    Parses a multipart response and deserializes each part back into Telekinesis
    datatypes.

    Args:
        endpoint: API endpoint name under the Retina base URL.
        input_data: Mapping of field name to serializable Telekinesis datatype.

    Returns:
      dict: A mapping of response part name to deserialized value.

    Raises:
        RuntimeError: If the API key is missing, the response is not multipart,
            or a response part has no name.
        requests.RequestException: If the HTTP request fails.
    """
    API_KEY = _load_api_key()

    def write_multipart_request(parts: dict[str, bytes]) -> tuple[bytes, str]:
        boundary = uuid.uuid4().hex
        body = bytearray()

        for name, payload in parts.items():
            body.extend(
                f"--{boundary}\r\n"
                f"Content-Type: application/vnd.apache.arrow.stream\r\n"
                f'Content-Disposition: inline; name="{name}"\r\n\r\n'.encode()
            )
            body.extend(payload)
            body.extend(b"\r\n")

        body.extend(f"--{boundary}--\r\n".encode())
        return bytes(body), boundary

    # ---------- BUILD REQUEST ----------
    fields = {}
    for name, value in input_data.items():
        arrow_bytes = serializer.serialize_to_pyarrow_ipc(value)
        fields[name] = arrow_bytes

    body, boundary = write_multipart_request(fields)

    headers = {
        "X-API-Key": API_KEY,
        "Content-Type": f"multipart/mixed; boundary={boundary}",
        "Content-Length": str(len(body)),
    }

    # ---------- HTTP ----------
    try:
        response = requests.post(
            f"{_RETINA_API_BASE_URL}{endpoint}",
            data=body,
            headers=headers,
            timeout=400,
            stream=True,
        )

        response_content = response.content  # force full download

    except requests.RequestException as e:
        logger.error(f"Request failed: {e}")
        raise

    # ---------- error handling ----------

    if not response.ok:
        content_type = response.headers.get("Content-Type", "")
        error = (
            response.json()
            if "application/json" in content_type
            else response.text
        )
        raise RuntimeError(f"Request failed [{response.status_code}]: {error}")

    # ---------- PARSE RESPONSE ----------
    content_type = response.headers.get("Content-Type", "")
    if "multipart/" not in content_type:
        raise RuntimeError("Expected multipart response from server")

    decoded_data = decoder.MultipartDecoder.from_response(response)

    output_data = {}
    for part in decoded_data.parts:
        cd = part.headers.get(b"Content-Disposition", b"").decode()
        _, params = parse_header(cd)
        name = params.get("name")
        if not name:
            raise RuntimeError("Missing name in multipart response part")

        output_data[name] = serializer.deserialize_from_pyarrow_ipc(
            part.content
        )

    return output_data


# -------------------------
# Circle examples
# -------------------------


def detect_circle_using_classic_hough(
    image: datatypes.Image | np.ndarray | list,
    inverse_resolution_ratio: datatypes.Float | float | int,
    min_distance: datatypes.Int | int,
    min_radius: datatypes.Int | int,
    max_radius: datatypes.Int | int,
    canny_detector_upper_threshold: datatypes.Int | int,
    accumulator_threshold: datatypes.Int | int,
) -> datatypes.GeometryDetectionAnnotations:
    """Detect circles using the classic Hough transform.

    Runs gradient-based Hough circle detector on the input image and returns
    COCO-like annotations. Each annotation includes a bounding box and circle
    geometry (center and radius).

    Args:
        image: Input image to process.
        inverse_resolution_ratio: Inverse ratio of accumulator resolution to image
            resolution (OpenCV `dp`). Increasing reduces accumulator resolution.
        min_distance: Minimum distance between detected circle centers (pixels).
        min_radius: Minimum circle radius to detect (pixels).
        max_radius: Maximum circle radius to detect (pixels).
        canny_detector_upper_threshold: Upper threshold for the internal Canny edge
            detector.
        accumulator_threshold: Accumulator threshold for circle centers. Increasing
            makes detection stricter (fewer circles).

    Returns:
      datatypes.GeometryDetectionAnnotations: Detected circle annotations in
      COCO-style format.
    """

    # Type checks
    if not isinstance(image, (datatypes.Image, np.ndarray, list)):
        raise TypeError(
            "image must be of type datatypes.Image or np.ndarray or list"
        )
    if not isinstance(inverse_resolution_ratio, (datatypes.Float, float, int)):
        raise TypeError(
            "inverse_resolution_ratio must be of type datatypes.Float or float or int"
        )
    if not isinstance(min_distance, (datatypes.Int, int)):
        raise TypeError("min_distance must be of type datatypes.Int or int")
    if not isinstance(min_radius, (datatypes.Int, int)):
        raise TypeError("min_radius must be of type datatypes.Int or int")
    if not isinstance(max_radius, (datatypes.Int, int)):
        raise TypeError("max_radius must be of type datatypes.Int or int")
    if not isinstance(canny_detector_upper_threshold, (datatypes.Int, int)):
        raise TypeError(
            "canny_detector_upper_threshold must be of type datatypes.Int or int"
        )
    if not isinstance(accumulator_threshold, (datatypes.Int, int)):
        raise TypeError(
            "accumulator_threshold must be of type datatypes.Int or int"
        )

    # Convert native types to datatypes
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    elif isinstance(image, list):
        image = datatypes.Image(image=np.array(image))
    if isinstance(inverse_resolution_ratio, (float, int)):
        inverse_resolution_ratio = datatypes.Float(inverse_resolution_ratio)
    if isinstance(min_distance, int):
        min_distance = datatypes.Int(value=min_distance)
    if isinstance(min_radius, int):
        min_radius = datatypes.Int(value=min_radius)
    if isinstance(max_radius, int):
        max_radius = datatypes.Int(value=max_radius)
    if isinstance(canny_detector_upper_threshold, int):
        canny_detector_upper_threshold = datatypes.Int(
            value=canny_detector_upper_threshold
        )
    if isinstance(accumulator_threshold, int):
        accumulator_threshold = datatypes.Int(value=accumulator_threshold)

    # Prepare data
    input_data = {
        "image": image,
        "inverse_resolution_ratio": inverse_resolution_ratio,
        "min_distance": min_distance,
        "min_radius": min_radius,
        "max_radius": max_radius,
        "canny_detector_upper_threshold": canny_detector_upper_threshold,
        "accumulator_threshold": accumulator_threshold,
    }

    # Call the API
    end_point = "detect_circle_using_classic_hough"
    response_data = _send_request(end_point, input_data)

    return response_data["annotations"]


# -------------------------
# Edge examples
# -------------------------


def detect_contours(
    image: datatypes.Image | np.ndarray | list,
    retrieval_mode: datatypes.String | str,
    approx_method: datatypes.String | str,
    min_area: datatypes.Int | int,
    max_area: datatypes.Int | int,
) -> datatypes.GeometryDetectionAnnotations:
    """Detect contours using a contour-based detector.

    Extracts contours from the input image using contour retrieval
    and approximation methods, with optional area filtering.

    Args:
        image: Input image to process.
        retrieval_mode: Contour retrieval mode.
        approx_method: Contour approximation method.
        min_area: Minimum contour area to keep.
        max_area: Maximum contour area to keep.

    Returns:
      datatypes.GeometryDetectionAnnotations: Detected contour annotations in
      COCO-style format.
    """

    # Type checks
    if not isinstance(image, (datatypes.Image, np.ndarray, list)):
        raise TypeError(
            "image must be of type datatypes.Image or np.ndarray or list"
        )
    if not isinstance(retrieval_mode, (datatypes.String, str)):
        raise TypeError(
            "retrieval_mode must be of type datatypes.String or str"
        )
    if not isinstance(approx_method, (datatypes.String, str)):
        raise TypeError("approx_method must be of type datatypes.String or str")
    if not isinstance(min_area, (datatypes.Int, int)):
        raise TypeError("min_area must be of type datatypes.Int or int")
    if not isinstance(max_area, (datatypes.Int, int)):
        raise TypeError("max_area must be of type datatypes.Int or int")

    # Convert native types to datatypes
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    elif isinstance(image, list):
        image = datatypes.Image(image=np.array(image))

    if isinstance(retrieval_mode, str):
        retrieval_mode = datatypes.String(value=retrieval_mode)
    if isinstance(approx_method, str):
        approx_method = datatypes.String(value=approx_method)
    if isinstance(min_area, int):
        min_area = datatypes.Int(value=min_area)
    if isinstance(max_area, int):
        max_area = datatypes.Int(value=max_area)

    # Prepare data
    input_data = {
        "image": image,
        "retrieval_mode": retrieval_mode,
        "approx_method": approx_method,
        "min_area": min_area,
        "max_area": max_area,
    }

    # Call the API
    end_point = "detect_contours"
    response_data = _send_request(end_point, input_data)

    return response_data["annotations"]


# -------------------------
# Neural Network examples
# -------------------------


def detect_objects_using_yolox(
    image: datatypes.Image | np.ndarray | list,
    score_threshold: datatypes.Float | float | int = 0.25,
    nms_threshold: datatypes.Float | float | int = 0.45,
) -> tuple[datatypes.ObjectDetectionAnnotations, datatypes.Categories]:
    """Detect objects using YOLOX (via Triton Inference Server).

    The model variant and input size are configured on the Triton server
    side, so only the image and filtering thresholds are required here.

    Args:
        image: Input image. Supported shapes are (H, W), (H, W, 1), or (H, W, 3).
            4-channel images are not supported.
        score_threshold: Confidence threshold for detections (default: 0.25).
        nms_threshold: IoU threshold for Non-Maximum Suppression (default: 0.45).

    Returns:
      tuple[datatypes.ObjectDetectionAnnotations, datatypes.Categories]: A tuple
      (annotations, categories), where `annotations` are COCO-style detections
      and `categories` are the corresponding COCO classes.

    Raises:
        ValueError: If `image` shape is unsupported, or if thresholds are out of
            range.
        TypeError: If input types are incorrect.
    """

    # Type checks
    if not isinstance(image, (datatypes.Image, np.ndarray, list)):
        raise TypeError(
            "image must be of type datatypes.Image or np.ndarray or list"
        )
    if not isinstance(score_threshold, (datatypes.Float, float, int)):
        raise TypeError(
            "score_threshold must be of type datatypes.Float or float or int"
        )
    if not isinstance(nms_threshold, (datatypes.Float, float, int)):
        raise TypeError(
            "nms_threshold must be of type datatypes.Float or float or int"
        )

    # Convert native types to datatypes
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    elif isinstance(image, list):
        image = datatypes.Image(image=np.array(image))

    if isinstance(score_threshold, (float, int)):
        score_threshold = datatypes.Float(value=float(score_threshold))
    if isinstance(nms_threshold, (float, int)):
        nms_threshold = datatypes.Float(value=float(nms_threshold))

    # Logical checks
    image_np = image.to_numpy()
    if image_np.ndim == 2:
        pass
    elif image_np.ndim == 3 and image_np.shape[2] in (1, 3):
        pass
    elif image_np.ndim == 3 and image_np.shape[2] == 4:
        raise ValueError(
            "4-channel images with alpha are not supported by "
            "detect_objects_using_yolox. "
            "Please load the image with keep_alpha=False."
        )
    else:
        raise ValueError(
            f"Unsupported image shape {image_np.shape}. "
            "Expected (H, W), (H, W, 1), or (H, W, 3)."
        )
    if score_threshold and not (0.0 <= score_threshold.value <= 1.0):
        raise ValueError("score_threshold must be between 0.0 and 1.0")
    if nms_threshold and not (0.0 <= nms_threshold.value <= 1.0):
        raise ValueError("nms_threshold must be between 0.0 and 1.0")

    # Prepare data
    input_data = {
        "image": image,
        "score_threshold": score_threshold,
        "nms_threshold": nms_threshold,
    }

    # Call the API
    end_point = "detect_objects_using_yolox"
    response_data = _send_request(end_point, input_data)

    return response_data["annotations"], response_data["categories"]


def detect_objects_using_rfdetr(
    image: datatypes.Image | np.ndarray | list,
    score_threshold: datatypes.Float | float | int = 0.5,
) -> tuple[datatypes.ObjectDetectionAnnotations, datatypes.Categories]:
    """Detect objects using RF-DETR (via Triton Inference Server).

    RF-DETR is a real-time transformer detector using a DINOv2 backbone.
    The model variant is configured on the Triton server side, so only
    the image and score threshold are required here.

    Args:
        image: Input image. Supported shapes are (H, W), (H, W, 1), or (H, W, 3).
            4-channel images are not supported.
        score_threshold: Confidence threshold for detections (default: 0.5).

    Returns:
      tuple[datatypes.ObjectDetectionAnnotations, datatypes.Categories]: A tuple
      (annotations, categories), where `annotations` are COCO-style detections
      and `categories` are the corresponding COCO classes.

    Raises:
        ValueError: If `image` shape is unsupported, or if `score_threshold` is
            out of range.
        TypeError: If input types are incorrect.
    """

    # Type checks
    if not isinstance(image, (datatypes.Image, np.ndarray, list)):
        raise TypeError(
            "image must be of type datatypes.Image or np.ndarray or list"
        )
    if not isinstance(score_threshold, (datatypes.Float, float, int)):
        raise TypeError(
            "score_threshold must be of type datatypes.Float or float or int"
        )

    # Convert native types to datatypes
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    elif isinstance(image, list):
        image = datatypes.Image(image=np.array(image))

    if isinstance(score_threshold, (float, int)):
        score_threshold = datatypes.Float(value=float(score_threshold))

    # Logical checks
    image_np = image.to_numpy()
    if image_np.ndim == 2:
        pass
    elif image_np.ndim == 3 and image_np.shape[2] in (1, 3):
        pass
    elif image_np.ndim == 3 and image_np.shape[2] == 4:
        raise ValueError(
            "4-channel images with alpha are not supported by "
            "detect_objects_using_rfdetr. "
            "Please load the image with keep_alpha=False."
        )
    else:
        raise ValueError(
            f"Unsupported image shape {image_np.shape}. "
            "Expected (H, W), (H, W, 1), or (H, W, 3)."
        )
    if score_threshold and not (0.0 <= score_threshold.value <= 1.0):
        raise ValueError("score_threshold must be between 0.0 and 1.0")

    # Prepare data
    input_data = {
        "image": image,
        "score_threshold": score_threshold,
    }

    # Call the API
    end_point = "detect_objects_using_rfdetr"
    response_data = _send_request(end_point, input_data)

    return response_data["annotations"], response_data["categories"]


# -------------------------
# VLM examples
# -------------------------


def detect_objects_using_qwen(
    image: datatypes.Image | np.ndarray | list,
    prompt: datatypes.String | str,
) -> datatypes.ObjectDetectionAnnotations:
    """Detect objects using Qwen3-VL and return COCO-style annotations.

    This wraps the backend `ObjectQWENDetector`.

    Args:
        image: Input image. Supported shapes are (H, W), (H, W, 1), or (H, W, 3).
            4-channel images are not supported.
        prompt: Comma-separated or natural language description of
            objects to detect (e.g. "person, car" or "all screws").

    Returns:
      datatypes.ObjectDetectionAnnotations: Detected object annotations in
      COCO-style format.

    Raises:
        ValueError: If `image` shape is unsupported.
        TypeError: If input types are incorrect.
    """

    # Type checks
    if not isinstance(image, (datatypes.Image, np.ndarray, list)):
        raise TypeError(
            "image must be of type datatypes.Image or np.ndarray or list"
        )
    if not isinstance(prompt, (datatypes.String, str)):
        raise TypeError("prompt must be of type datatypes.String or str")
    # Convert native types to datatypes
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    elif isinstance(image, list):
        image = datatypes.Image(image=np.array(image))

    if isinstance(prompt, str):
        prompt = datatypes.String(prompt)

    # Logical checks
    image_np = image.to_numpy()
    if image_np.ndim == 2:
        pass
    elif image_np.ndim == 3 and image_np.shape[2] in (1, 3):
        pass
    elif image_np.ndim == 3 and image_np.shape[2] == 4:
        raise ValueError(
            "4-channel images with alpha are not supported by "
            "detect_objects_using_qwen. "
            "Please load the image with keep_alpha=False."
        )
    else:
        raise ValueError(
            f"Unsupported image shape {image_np.shape}. "
            "Expected (H, W), (H, W, 1), or (H, W, 3)."
        )

    # Prepare data
    input_data = {
        "image": image,
        "prompt": prompt,
    }

    # Call the API
    end_point = "detect_objects_using_qwen"
    response_data = _send_request(end_point, input_data)

    return response_data["annotations"]


def detect_objects_using_grounding_dino(
    image: datatypes.Image | np.ndarray | list,
    prompt: datatypes.String | str,
    box_threshold: datatypes.Float | float | int = 0.25,
    text_threshold: datatypes.Float | float | int = 0.25,
) -> tuple[datatypes.ObjectDetectionAnnotations, datatypes.Categories]:
    """Detect objects from a text prompt using Grounding DINO (via Triton).

    Args:
        image: Input image. Supported shapes are (H, W), (H, W, 1), or (H, W, 3).
            4-channel images are not supported.
        prompt: Dot-separated, lowercase text queries (for example,
            `"a crack . a spall ."`).
        box_threshold: Minimum confidence for bounding-box predictions
            (default: 0.25).
        text_threshold: Minimum confidence for text/label matching (default:
            0.25).

    Returns:
      tuple[datatypes.ObjectDetectionAnnotations, datatypes.Categories]: A tuple
      (annotations, categories), where `annotations` are COCO-style detections
      and `categories` are the corresponding COCO classes.

    Raises:
        ValueError: If `prompt` does not end with a dot, or if thresholds are out
            of range.
        TypeError: If input types are incorrect.
    """

    # Type checks
    if not isinstance(image, (datatypes.Image, np.ndarray, list)):
        raise TypeError(
            "image must be of type datatypes.Image or np.ndarray or list"
        )
    if not isinstance(prompt, (datatypes.String, str)):
        raise TypeError("prompt must be of type datatypes.String or str")
    if not isinstance(box_threshold, (datatypes.Float, float, int)):
        raise TypeError(
            "box_threshold must be of type datatypes.Float or float or int"
        )
    if not isinstance(text_threshold, (datatypes.Float, float, int)):
        raise TypeError(
            "text_threshold must be of type datatypes.Float or float or int"
        )

    # Convert native types to datatypes
    if isinstance(image, np.ndarray):
        image = datatypes.Image(image=image)
    elif isinstance(image, list):
        image = datatypes.Image(image=np.array(image))

    if isinstance(prompt, str):
        prompt = datatypes.String(prompt)
    if isinstance(box_threshold, (float, int)):
        box_threshold = datatypes.Float(value=float(box_threshold))
    if isinstance(text_threshold, (float, int)):
        text_threshold = datatypes.Float(value=float(text_threshold))

    # Logical checks
    image_np = image.to_numpy()
    if image_np.ndim == 2:
        pass
    elif image_np.ndim == 3 and image_np.shape[2] in (1, 3):
        pass
    elif image_np.ndim == 3 and image_np.shape[2] == 4:
        raise ValueError(
            "4-channel images with alpha are not supported by "
            "detect_objects_using_grounding_dino. "
            "Please load the image with keep_alpha=False."
        )
    else:
        raise ValueError(
            f"Unsupported image shape {image_np.shape}. "
            "Expected (H, W), (H, W, 1), or (H, W, 3)."
        )
    
    if prompt and not prompt.value.strip().endswith("."):
        raise ValueError(
            "Prompt must end with a dot (.) to separate object queries"
        )
    if box_threshold and not (0.0 <= box_threshold.value <= 1.0):
        raise ValueError("box_threshold must be between 0.0 and 1.0")
    if text_threshold and not (0.0 <= text_threshold.value <= 1.0):
        raise ValueError("text_threshold must be between 0.0 and 1.0")

    # Prepare data
    input_data = {
        "image": image,
        "prompt": prompt,
        "box_threshold": box_threshold,
        "text_threshold": text_threshold,
    }

    # Call the API
    end_point = "detect_objects_using_grounding_dino"
    response_data = _send_request(end_point, input_data)

    return response_data["annotations"], response_data["categories"]
