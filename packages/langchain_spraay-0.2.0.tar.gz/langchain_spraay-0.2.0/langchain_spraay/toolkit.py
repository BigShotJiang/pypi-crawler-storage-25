"""Spraay toolkit for LangChain agents.

Provides a convenient way to load all Spraay tools at once for use
with LangChain agents and LangGraph.
"""

from __future__ import annotations

from typing import List

from langchain_core.tools import BaseTool

from langchain_spraay.gateway import (
    SpraayAIInferenceTool,
    SpraayBatchPaymentTool,
    SpraayGatewayTool,
    SpraayPriceOracleTool,
)


class SpraayToolkit:
    """Toolkit that provides all Spraay tools for LangChain agents.

    Loads gateway tools by default. Set ``include_onchain=True`` to also
    include direct smart contract tools (requires ``web3``).

    Example:
        .. code-block:: python

            from langchain_spraay import SpraayToolkit

            # Gateway tools only (default)
            toolkit = SpraayToolkit()
            tools = toolkit.get_tools()

            # Include on-chain tools
            toolkit = SpraayToolkit(include_onchain=True)
            tools = toolkit.get_tools()

            # Use with a LangChain agent
            from langchain.agents import create_tool_calling_agent
            agent = create_tool_calling_agent(llm, tools, prompt)
    """

    def __init__(self, include_onchain: bool = False) -> None:
        self.include_onchain = include_onchain

    def get_tools(self) -> List[BaseTool]:
        """Return list of Spraay tools."""
        tools: List[BaseTool] = [
            SpraayGatewayTool(),
            SpraayBatchPaymentTool(),
            SpraayAIInferenceTool(),
            SpraayPriceOracleTool(),
        ]

        if self.include_onchain:
            from langchain_spraay.onchain import (
                SpraayBatchSendETH,
                SpraayBatchSendETHVariable,
                SpraayBatchSendToken,
                SpraayBatchSendTokenVariable,
            )

            tools.extend(
                [
                    SpraayBatchSendETH(),
                    SpraayBatchSendETHVariable(),
                    SpraayBatchSendToken(),
                    SpraayBatchSendTokenVariable(),
                ]
            )

        return tools
