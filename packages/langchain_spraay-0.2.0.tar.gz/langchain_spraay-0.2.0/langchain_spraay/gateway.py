"""Spraay x402 Gateway tools for LangChain.

HTTP-based tools that interact with the Spraay x402 payment gateway
at gateway.spraay.app. Agents pay USDC per request on Base — no API
keys, no accounts required.

Gateway supports 76+ endpoints across 13+ chains and 19+ categories
including batch payments, AI inference, DeFi, price oracles, payroll,
and more.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Type

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

DEFAULT_GATEWAY_URL = "https://gateway.spraay.app"


def _make_gateway_request(
    endpoint: str,
    payload: Optional[Dict[str, Any]] = None,
    method: str = "POST",
) -> Dict[str, Any]:
    """Make a request to the Spraay x402 gateway.

    The gateway uses x402 payment protocol — the first request returns
    a 402 Payment Required response with payment details. The caller
    must complete USDC payment on Base, then retry with the payment proof.

    For automated agent usage, set SPRAAY_PRIVATE_KEY to enable
    automatic x402 payment handling.
    """
    import requests

    gateway_url = os.environ.get("SPRAAY_GATEWAY_URL", DEFAULT_GATEWAY_URL)
    url = f"{gateway_url}{endpoint}"

    headers = {"Content-Type": "application/json"}

    # If private key is set, include it for automatic x402 payment
    private_key = os.environ.get("SPRAAY_PRIVATE_KEY")
    if private_key:
        headers["X-Private-Key"] = private_key

    if method.upper() == "GET":
        response = requests.get(url, headers=headers, timeout=30)
    else:
        response = requests.post(
            url, headers=headers, json=payload or {}, timeout=30
        )

    if response.status_code == 402:
        # Return payment required details so the agent can handle payment
        return {
            "status": "payment_required",
            "payment_details": response.json(),
            "message": (
                "x402 payment required. Send USDC on Base to complete "
                "this request. See payment_details for amount and address."
            ),
        }

    response.raise_for_status()
    return response.json()


# --- Input Schemas ---


class GatewayInput(BaseModel):
    """Input for the generic gateway tool."""

    endpoint: str = Field(
        description=(
            "Gateway API endpoint path (e.g. '/batch/eth', '/ai/chat', "
            "'/price/eth', '/defi/swap')"
        )
    )
    payload: Optional[Dict[str, Any]] = Field(
        default=None,
        description="JSON payload for the request body",
    )
    method: str = Field(
        default="POST",
        description="HTTP method — POST (default) or GET",
    )


class BatchPaymentInput(BaseModel):
    """Input for batch payment via gateway."""

    chain: str = Field(
        default="base",
        description=(
            "Target chain: base, ethereum, arbitrum, polygon, bnb, "
            "avalanche, optimism, solana, bitcoin, xrp, bittensor, "
            "stacks, bob"
        ),
    )
    token: str = Field(
        default="ETH",
        description="Token to send: ETH, USDC, USDT, or any ERC-20 address",
    )
    recipients: List[str] = Field(
        description="List of recipient addresses (max 200)"
    )
    amounts: List[str] = Field(
        description="Amounts to send to each recipient",
    )


class AIInferenceInput(BaseModel):
    """Input for AI inference via gateway."""

    prompt: str = Field(description="The prompt or message to send")
    model: str = Field(
        default="gpt-4o-mini",
        description=(
            "Model to use. 200+ models available via OpenRouter, "
            "43+ via BlockRun, 43+ via Bittensor/Chutes. "
            "Examples: gpt-4o-mini, claude-3-haiku, llama-3-70b"
        ),
    )
    provider: str = Field(
        default="openrouter",
        description="Provider: openrouter, blockrun, or bittensor",
    )


class PriceOracleInput(BaseModel):
    """Input for price oracle queries."""

    asset: str = Field(
        description="Asset symbol (e.g. 'ETH', 'BTC', 'SOL', 'USDC')"
    )
    currency: str = Field(
        default="USD",
        description="Quote currency (default: USD)",
    )


# --- Tools ---


class SpraayGatewayTool(BaseTool):  # type: ignore[override]
    """Generic tool for any Spraay x402 gateway endpoint.

    Provides access to all 76+ gateway endpoints across batch payments,
    AI inference, DeFi, price oracles, payroll, and more. Agents pay
    USDC per request on Base via x402 — no API keys needed.

    Setup:
        .. code-block:: bash

            pip install langchain-spraay
            export SPRAAY_PRIVATE_KEY="your-private-key"

    Example:
        .. code-block:: python

            from langchain_spraay import SpraayGatewayTool

            tool = SpraayGatewayTool()

            # Batch payment
            result = tool.invoke({
                "endpoint": "/batch/eth",
                "payload": {
                    "recipients": ["0xAbc...", "0xDef..."],
                    "amountPerRecipient": "0.01"
                }
            })

            # AI inference
            result = tool.invoke({
                "endpoint": "/ai/chat",
                "payload": {"prompt": "Hello!", "model": "gpt-4o-mini"}
            })

            # Price check
            result = tool.invoke({
                "endpoint": "/price/eth",
                "method": "GET"
            })
    """

    name: str = "spraay_gateway"
    description: str = (
        "Access any Spraay x402 gateway endpoint. Supports 76+ paid endpoints "
        "across 13+ chains: batch payments, AI inference (200+ models), DeFi "
        "swaps, price oracles, payroll, bridging, and more. Agents pay USDC "
        "per request on Base. Input: endpoint path, optional JSON payload, "
        "and HTTP method."
    )
    args_schema: Type[BaseModel] = GatewayInput

    def _run(
        self,
        endpoint: str,
        payload: Optional[Dict[str, Any]] = None,
        method: str = "POST",
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        try:
            result = _make_gateway_request(endpoint, payload, method)
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {e!s}"


class SpraayBatchPaymentTool(BaseTool):  # type: ignore[override]
    """Tool for multi-chain batch payments via the Spraay gateway.

    Send tokens to up to 200 recipients across 13+ chains in a single
    request. Supports ETH, USDC, USDT, and any ERC-20 token.

    Setup:
        .. code-block:: bash

            pip install langchain-spraay
            export SPRAAY_PRIVATE_KEY="your-private-key"

    Example:
        .. code-block:: python

            from langchain_spraay import SpraayBatchPaymentTool

            tool = SpraayBatchPaymentTool()
            result = tool.invoke({
                "chain": "base",
                "token": "USDC",
                "recipients": ["0xAbc...", "0xDef..."],
                "amounts": ["100", "250"]
            })
    """

    name: str = "spraay_batch_payment"
    description: str = (
        "Send tokens to multiple recipients across 13+ chains via Spraay "
        "gateway. Supports ETH, USDC, USDT, and ERC-20 tokens. Up to 200 "
        "recipients per transaction with ~80% gas savings. Input: chain, "
        "token, list of recipients, and amounts."
    )
    args_schema: Type[BaseModel] = BatchPaymentInput

    def _run(
        self,
        chain: str = "base",
        token: str = "ETH",
        recipients: List[str] = [],
        amounts: List[str] = [],
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        try:
            endpoint = f"/batch/{chain}/{token.lower()}"
            payload = {
                "recipients": recipients,
                "amounts": amounts,
            }
            result = _make_gateway_request(endpoint, payload)
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {e!s}"


class SpraayAIInferenceTool(BaseTool):  # type: ignore[override]
    """Tool for AI inference via the Spraay x402 gateway.

    Access 200+ AI models through the gateway. Pay per request in USDC
    on Base — no API keys needed. Supports OpenRouter, BlockRun, and
    Bittensor/Chutes providers.

    Setup:
        .. code-block:: bash

            pip install langchain-spraay
            export SPRAAY_PRIVATE_KEY="your-private-key"

    Example:
        .. code-block:: python

            from langchain_spraay import SpraayAIInferenceTool

            tool = SpraayAIInferenceTool()
            result = tool.invoke({
                "prompt": "Explain quantum computing",
                "model": "gpt-4o-mini",
                "provider": "openrouter"
            })
    """

    name: str = "spraay_ai_inference"
    description: str = (
        "Run AI inference through Spraay gateway. Access 200+ models from "
        "OpenRouter, BlockRun, and Bittensor. Pay per request in USDC on "
        "Base — no API keys needed. Input: prompt, model name, and provider."
    )
    args_schema: Type[BaseModel] = AIInferenceInput

    def _run(
        self,
        prompt: str,
        model: str = "gpt-4o-mini",
        provider: str = "openrouter",
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        try:
            if provider == "bittensor":
                endpoint = "/bittensor/v1/chat/completions"
            else:
                endpoint = f"/ai/{provider}/chat"

            payload = {
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
            }
            result = _make_gateway_request(endpoint, payload)
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {e!s}"


class SpraayPriceOracleTool(BaseTool):  # type: ignore[override]
    """Tool for crypto price lookups via the Spraay gateway.

    Get real-time prices for any cryptocurrency or token.

    Setup:
        .. code-block:: bash

            pip install langchain-spraay
            export SPRAAY_PRIVATE_KEY="your-private-key"

    Example:
        .. code-block:: python

            from langchain_spraay import SpraayPriceOracleTool

            tool = SpraayPriceOracleTool()
            result = tool.invoke({"asset": "ETH", "currency": "USD"})
    """

    name: str = "spraay_price_oracle"
    description: str = (
        "Get real-time crypto prices via Spraay gateway. Input: asset "
        "symbol (ETH, BTC, SOL, etc.) and optional quote currency."
    )
    args_schema: Type[BaseModel] = PriceOracleInput

    def _run(
        self,
        asset: str,
        currency: str = "USD",
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        try:
            endpoint = f"/price/{asset.lower()}"
            result = _make_gateway_request(endpoint, method="GET")
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {e!s}"
