"""LangChain tools for Spraay — multi-chain batch payments and x402 gateway.

Spraay provides two integration modes:

1. **On-chain tools** — Direct smart contract interaction for batch payments
   on Base. Requires `web3` (install with `pip install langchain-spraay[onchain]`).

2. **Gateway tools** — HTTP-based x402 payment gateway supporting 76+ endpoints
   across 13+ chains and 19+ categories. No web3 dependency needed — agents pay
   USDC per request via the x402 protocol.

Quick start (gateway):

    from langchain_spraay import SpraayGatewayTool

    tool = SpraayGatewayTool()
    result = tool.invoke({
        "endpoint": "/batch/eth",
        "payload": {"recipients": ["0xAbc..."], "amountPerRecipient": "0.01"}
    })

Quick start (on-chain):

    from langchain_spraay import SpraayBatchSendETH

    tool = SpraayBatchSendETH()
    result = tool.invoke({
        "recipients": ["0xAbc...", "0xDef..."],
        "amount_per_recipient_eth": "0.01"
    })
"""

from langchain_spraay.gateway import (
    SpraayGatewayTool,
    SpraayBatchPaymentTool,
    SpraayAIInferenceTool,
    SpraayPriceOracleTool,
)
from langchain_spraay.onchain import (
    SpraayBatchSendETH,
    SpraayBatchSendETHVariable,
    SpraayBatchSendToken,
    SpraayBatchSendTokenVariable,
)
from langchain_spraay.toolkit import SpraayToolkit

__all__ = [
    # Gateway tools (x402)
    "SpraayGatewayTool",
    "SpraayBatchPaymentTool",
    "SpraayAIInferenceTool",
    "SpraayPriceOracleTool",
    # On-chain tools
    "SpraayBatchSendETH",
    "SpraayBatchSendETHVariable",
    "SpraayBatchSendToken",
    "SpraayBatchSendTokenVariable",
    # Toolkit
    "SpraayToolkit",
]

__version__ = "0.2.0"
