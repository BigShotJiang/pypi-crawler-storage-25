"""Tests for langchain-spraay package."""

import pytest
from unittest.mock import patch, MagicMock

from langchain_spraay import (
    SpraayGatewayTool,
    SpraayBatchPaymentTool,
    SpraayAIInferenceTool,
    SpraayPriceOracleTool,
    SpraayToolkit,
)


def test_gateway_tool_schema():
    """Test SpraayGatewayTool has correct schema."""
    tool = SpraayGatewayTool()
    assert tool.name == "spraay_gateway"
    assert "x402" in tool.description
    schema = tool.args_schema.model_json_schema()
    assert "endpoint" in schema["properties"]
    assert "payload" in schema["properties"]


def test_batch_payment_tool_schema():
    """Test SpraayBatchPaymentTool has correct schema."""
    tool = SpraayBatchPaymentTool()
    assert tool.name == "spraay_batch_payment"
    schema = tool.args_schema.model_json_schema()
    assert "chain" in schema["properties"]
    assert "recipients" in schema["properties"]
    assert "amounts" in schema["properties"]


def test_ai_inference_tool_schema():
    """Test SpraayAIInferenceTool has correct schema."""
    tool = SpraayAIInferenceTool()
    assert tool.name == "spraay_ai_inference"
    schema = tool.args_schema.model_json_schema()
    assert "prompt" in schema["properties"]
    assert "model" in schema["properties"]
    assert "provider" in schema["properties"]


def test_price_oracle_tool_schema():
    """Test SpraayPriceOracleTool has correct schema."""
    tool = SpraayPriceOracleTool()
    assert tool.name == "spraay_price_oracle"
    schema = tool.args_schema.model_json_schema()
    assert "asset" in schema["properties"]


def test_toolkit_gateway_only():
    """Test toolkit returns gateway tools by default."""
    toolkit = SpraayToolkit()
    tools = toolkit.get_tools()
    assert len(tools) == 4
    names = [t.name for t in tools]
    assert "spraay_gateway" in names
    assert "spraay_batch_payment" in names
    assert "spraay_ai_inference" in names
    assert "spraay_price_oracle" in names


def test_toolkit_with_onchain():
    """Test toolkit includes on-chain tools when requested."""
    toolkit = SpraayToolkit(include_onchain=True)
    tools = toolkit.get_tools()
    assert len(tools) == 8
    names = [t.name for t in tools]
    assert "spraay_batch_send_eth" in names
    assert "spraay_batch_send_token" in names
    assert "spraay_batch_send_eth_variable" in names
    assert "spraay_batch_send_token_variable" in names


@patch("requests.get")
def test_gateway_tool_run(mock_get):
    """Test gateway tool makes correct HTTP request."""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"status": "ok", "price": "3500.00"}
    mock_response.raise_for_status = MagicMock()
    mock_get.return_value = mock_response

    tool = SpraayGatewayTool()
    result = tool.invoke({
        "endpoint": "/price/eth",
        "method": "GET",
    })

    assert "3500" in result
    mock_get.assert_called_once()


def test_version():
    """Test package version is set."""
    from langchain_spraay import __version__
    assert __version__ == "0.2.0"
