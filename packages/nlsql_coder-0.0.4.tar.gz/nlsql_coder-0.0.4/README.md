# NLSQL Internal Coding Agent

NLSQL's internal coding agent is a private, tool-driven, workspace-aware AI system designed to help with both internal and client-based development tasks in the NLSQL ecosystem.

# Features

- User-friendly command line interface.
- Wide array of LLM/provider support acorss many cloud ecosystems.
- Primary privacy & security focus.
- Parallel tool calling ability for speed and efficency.

# How it Works

The agent operates using a ReAct-style loop. A user submits a prompt, and the agent processes it by reasoning about the task, performing actions using available tools, and evaluating the results.

If the outcome is insufficient or incomplete, the agent continues this cycle, refining its approach and taking further actions until it can produce a final response.

# Usage

To use the application, follow the steps below:

1. Clone this repo to your local system: `git clone <repo-link-here>`
2. Make sure you are at `cd internal-coding-agent`
3. Create a virtual environment: `python3 -m venv .venv`
4. Activate the venv: `source .venv/bin/activate`
6. Install requirements: (if venv is activated correctly you should see "(venv)" in your terminal) `pip install -r requirements.txt`
7. Add .env file into `cd internal-coding-agent` root folder
8. Run the application: `python3 run.py -u --workspace path/to/your/project`

## Arguments

| Short | Long | Description | Defaults to | Required |
|-|-|-|-|-|
| `-w` | `--workspace` | The root directory of the project you want to work on. | `.` | ✔ |
| `-u` | `--usage` | Displays usage data after each conversation turn (input & output tokens) | `False` | ✗ |
