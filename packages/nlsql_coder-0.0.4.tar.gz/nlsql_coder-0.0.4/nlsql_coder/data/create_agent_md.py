from nlsql_coder.app.agent.helpers.project_details import Project
from nlsql_coder.app.cli.arg_parsing import args
from nlsql_coder.app.agent.helpers.get_agent import llm
from nlsql_coder.app.agent.model.agent import Agent
from pathlib import Path

# Get relevant project files for context
def create_md():
    try:
        if not llm:
            raise EnvironmentError("Environment variables not present or incorrect.")
            return
        root = Path(args.workspace)
        if Path(root, "AGENTS.md").exists():
            return "exists"
        patterns = ["README*", "readme*", "requirements*", "package.json", "*.md", "*.txt", "main.*", "run.*", "Dockerfile", "*compose*.yml", "*compose*.yaml", "index.html"]
        exclude_dirs = {".venv", "node_modules", ".git", "__pycache__"}

        files = []
        for pattern in patterns:
            for f in root.rglob(pattern):
                if not any(part in exclude_dirs for part in f.parts):
                    files.append(f)
        if not files:
            return "empty"

        project = Project(args.workspace)

        project_tree = project.generate_tree()

        overview_creator_prompt = """
        # Role
        You are a coding project summerizer

        # Task
        Summarize the project based on the given context and extract any important information for the development agent's context.

        Your summary should include:
        - Brief overview of the project (i.e. name, what it does, who it's for.)
        - Commands/steps to buidl and run the application (if applicable)
        - Project archetecture (i.e. main components, frontend, backend, languages used)
        - Any other relevant observations or notes

        # Response rules
        - Respond ONLY with the project summary
        - Respond in Markdown format
        - Keep the summary consice and on-topic
        """
        overview_creator = Agent(llm, overview_creator_prompt)

        file_contents = ""
        for file in files:
            with open(Path(root, file), "r") as f:
                file_contents += f"{str(file)}:\n{f.read()}"

        context_message = f"""
        CONTEXT:
        {file_contents}
        """
        accumulated = ""
        response = overview_creator.chat(context_message)
        for chunk in response:
            if isinstance(chunk, str):
                accumulated += chunk

        md = f"""
        # Project Tree
        ```
        {project_tree}
        ```
        {accumulated}
        """

        with open(Path(root, "AGENTS.md"), "w") as f:
            f.write(md)
        
        return "created"
    except Exception as e:
        return False