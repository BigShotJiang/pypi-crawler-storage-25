"""
Tool specifications & provider convertion functions
Current tools:
    file_tools.py
        read_file(file_path: str, from_line: int = 0, to_line: int = 100)
"""
from nlsql_coder.app.providers.base import ToolSpecification, ToolSchema, ToolProperty


############### Tools Specifications ###################

read_file_spec = ToolSpecification(
    name="read_file",
    description="Reads a given file starting at from_line ending at to_line and returns its contents.",
    schema=ToolSchema(
        type="object",
        properties={
            "file_path": ToolProperty(
                type="string",
                description="Path to the file to read (relative to the workspace root)."
            ),
            "from_line": ToolProperty(
                type="integer",
                description="Line number to start reading from (1-indexed). Defaults to 1.",
                default=1
            ),
            "to_line": ToolProperty(
                type="integer",
                description="Line number to stop reading at (inclusive). Defaults to 100.",
                default=100
            )
        },
        required=["file_path"]
    )
)

write_file_spec = ToolSpecification(
    name="write_file",
    description="Writes the contents to a new file at the given location",
    schema=ToolSchema(
        type="object",
        properties={
            "file_path": ToolProperty(
                type="string",
                description="Path to the file to write (relative to the workspace root (must include file name))."
            ),
            "content": ToolProperty(
                type="string",
                description="The content to write to the file.",
            ),
        },
        required=["file_path", "content"]
    )
)

edit_file_spec = ToolSpecification(
    name="edit_file",
    description="Apply one or more edits to a file.",
    schema=ToolSchema(
        properties={
            "file_path": ToolProperty(
                type="string",
                description="File path"
            ),
            "edits": ToolProperty(
                type="array",
                description="List of edits",
                items=ToolProperty(
                    type="object",
                    description="Single edit",
                    properties={
                        "search": ToolProperty(
                            type="string",
                            description="Text to find"
                        ),
                        "replace": ToolProperty(
                            type="string",
                            description="Replacement text"
                        ),
                    },
                    required=["search", "replace"]
                )
            )
        },
        required=["file_path", "edits"]
    )
)

insert_to_file_spec = ToolSpecification(
    name="insert_to_file",
    description="Insert code into a file by appending or prepending it.",
    schema=ToolSchema(
        properties={
            "file_path": ToolProperty(
                type="string",
                description="Path to the file"
            ),
            "code": ToolProperty(
                type="string",
                description="Code to insert into the file"
            ),
            "mode": ToolProperty(
                type="string",
                description="Where to insert the code: append or prepend",
            )
        },
        required=["file_path", "code", "mode"]
    )
)

insert_relative_spec = ToolSpecification(
    name="insert_relative",
    description="Insert code before or after a matching anchor line in a file.",
    schema=ToolSchema(
        properties={
            "file_path": ToolProperty(
                type="string",
                description="Path to the file"
            ),
            "anchor": ToolProperty(
                type="string",
                description="Text to search for in a line (anchor point)"
            ),
            "code": ToolProperty(
                type="string",
                description="Code to insert"
            ),
            "position": ToolProperty(
                type="string",
                description="Where to insert relative to anchor: before or after",
            )
        },
        required=["file_path", "anchor", "code", "position"]
    )
)

get_project_tree_spec = ToolSpecification(
    name="get_project_tree",
    description="Gets the current project's file tree.",
    schema=ToolSchema(
        type="object",
        properties={},
        required=[]
    )
)

#################################################


########### Conversion functions ##################

def tool_aws_bedrock(tool: ToolSpecification):
    return {
        "toolSpec": {
            "name": tool.name,
            "description": tool.description,
            "inputSchema": {
                "json": tool.schema.serialize()
            }
        }
    }
