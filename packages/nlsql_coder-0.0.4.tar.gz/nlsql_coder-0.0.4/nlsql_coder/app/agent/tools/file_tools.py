from nlsql_coder.app.agent.helpers.project_details import Project
from pathlib import Path
from nlsql_coder.app.cli.arg_parsing import args

FILE_TOOL_REGISTRY = {}

project = Project(args.workspace)

def get_project_tree():
    """
    Get's the current project's file tree
    """
    return project.generate_tree()


def read_file(file_path: str, from_line: int = 1, to_line: int = 100):
    """
    Reads a given file starting at from_line ending at to_line and returns its contents.
    """
    try:
        root_path = Path(project.root).resolve()
        target_path = (root_path / file_path).resolve()

        if not str(target_path).startswith(str(root_path)):
            return "error: access outside workspace is not allowed."
        if from_line > to_line:
            return "error: from_line must be less than or equal to to_line."
        
        contents = []
        with open(target_path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f, start=1):
                if i > to_line:
                    break
                if i >= from_line:
                    contents.append(line)
        return "".join(contents)
    except FileNotFoundError:
        return "error: the file does not exist."
    except IsADirectoryError:
        return f"error: {file_path} is a directory."
    except PermissionError:
        return "error: you do not have permission to read this file."
    

def write_file(file_path: str, content: str):
    """
    Writes the given content to a new file at the specified file path.
    """
    try:
        if not file_path:
            return "error: file_path not given."
        if not content:
            return "error: no content given."
        root_path = Path(project.root).resolve()
        target_path = (root_path / file_path).resolve()
        if not str(target_path).startswith(str(root_path)):
            return "error: access outside workspace is not allowed."
        with open(target_path, "w") as f:
            f.write(content)
        return "success"
    except PermissionError:
        return "error: you do not have permission to write to this file."
    except Exception as e:
        return f"error: there was an error writing the file: {e}"


def edit_file(file_path: str, edits: list[dict[str, str]]):
    """Apply the given edits to a file."""
    # TODO: This tool needs work, using replace will replace all instances (it's dangerous)
    try:
        root_path = Path(project.root).resolve()
        target_path = (root_path / file_path).resolve()
        contents = ""
        with open(target_path, "r") as f:
            contents = f.read()
        for edit in edits:
            if not edit["search"].endswith("\n"):
                edit["search"] += "\n"
            contents = contents.replace(edit["search"], edit["replace"])
        with open(target_path, "w") as f:
            f.write(contents)
        return "success"
    except FileNotFoundError:
        return "error: the file does not exist."
    except IsADirectoryError:
        return f"error: {file_path} is a directory."
    except PermissionError:
        return "error: you do not have permission to edit this file."
    

def insert_to_file(file_path: str, code: str, mode: str = "append"):
    """
    mode:
      - append
      - prepend
    """
    root_path = Path(project.root).resolve()
    target_path = (root_path / file_path).resolve()

    with open(target_path, "r") as f:
        contents = f.read()

    if mode == "append":
        contents = contents.rstrip() + "\n\n" + code + "\n"
    elif mode == "prepend":
        contents = code.rstrip() + "\n\n" + contents
    else:
        raise ValueError("Invalid mode")

    with open(target_path, "w") as f:
        f.write(contents)

    return "success"


def insert_relative(file_path: str, anchor: str, code: str, position: str = "after"):
    root_path = Path(project.root).resolve()
    target_path = (root_path / file_path).resolve()

    with open(target_path, "r") as f:
        lines = f.readlines()

    for i, line in enumerate(lines):
        if anchor in line:
            if position == "after":
                lines.insert(i + 1, code + "\n")
            elif position == "before":
                lines.insert(i, code + "\n")
            else:
                raise ValueError("position must be before or after")
            break
    else:
        raise ValueError("Anchor not found")

    with open(target_path, "w") as f:
        f.writelines(lines)

    return "success"



FILE_TOOL_REGISTRY["read_file"] = read_file
FILE_TOOL_REGISTRY["write_file"] = write_file
FILE_TOOL_REGISTRY["get_project_tree"] = get_project_tree
FILE_TOOL_REGISTRY["edit_file"] = edit_file
FILE_TOOL_REGISTRY["insert_to_file"] = insert_to_file
FILE_TOOL_REGISTRY["insert_relative"] = insert_relative
