from pathlib import Path
from nlsql_coder.app.providers.config import ProviderConfig
from nlsql_coder.app.agent.model.agent import Agent
from nlsql_coder.app.agent.tools.tool_specs import read_file_spec, write_file_spec, get_project_tree_spec, edit_file_spec, insert_relative_spec, insert_to_file_spec
from nlsql_coder.app.cli.arg_parsing import args
from importlib import resources


provider_config = ProviderConfig()
agent = None
llm = None
prompt_path = resources.files("nlsql_coder.app.agent.helpers") / "system_prompt.md"
system_prompt = prompt_path.read_text()
agents_md = Path(args.workspace, "AGENTS.md").resolve()
if agents_md.exists():
    with open(agents_md, "r") as f:
        content = f.read()
    system_prompt += content
tools = [read_file_spec, write_file_spec, get_project_tree_spec, edit_file_spec, insert_to_file_spec, insert_relative_spec]

if provider_config.model_provider == "aws":
    from nlsql_coder.app.providers.aws.provider import AWSBedrockProvider
    model_id = provider_config.model_name
    llm = AWSBedrockProvider(model_id)
    agent = Agent(llm, system_prompt, tools)