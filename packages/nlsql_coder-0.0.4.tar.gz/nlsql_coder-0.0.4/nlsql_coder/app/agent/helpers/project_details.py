import os
from pathlib import Path


class Project:
    """
    Project class to gather context about the current project.
    """
    def __init__(self, root):
        self.root = root
        self.ignore_paths = [".venv", "venv", "__pycache__", ".git"]


    def generate_tree(self, path: Path = None, indent: str = "", lines=None):
        if lines is None:
            lines = []
            path = Path(self.root)
            lines.append(f"{path.name}/")

        try:
            items = sorted([i for i in os.listdir(path) if i not in self.ignore_paths])
            for item in items:
                full_path = path / item
                if full_path.is_dir():
                    lines.append(f"{indent}    {item}/")
                    self.generate_tree(full_path, indent + "    ", lines)
                else:
                    lines.append(f"{indent}    {item}")
        except PermissionError:
            lines.append(f"{indent}    [Access Denied]")
        return "\n".join(lines)

