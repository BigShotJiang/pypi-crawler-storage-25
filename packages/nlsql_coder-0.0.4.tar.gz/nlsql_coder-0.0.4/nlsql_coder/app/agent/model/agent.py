"""
Planner agent class.
Implements the functionallity for the planner agent.
"""
from nlsql_coder.app.providers.base import BaseProvider, Message
from typing import Type, Iterator

from nlsql_coder.app.agent.tools.tool_specs import ToolSpecification

class Agent:
    """
    Main agent class, highest level class - first point of call for user messages.
    Responsible for planning the steps involved in completing the give task and invoking other agents if needed.
    """
    def __init__(self, provider_class: Type[BaseProvider], system_prompt: str, tools: list[ToolSpecification] = None):
        self.llm = provider_class
        self.messages = []

        self.kwargs = {
            "system_prompt": system_prompt,
            "tools": tools
        }
        if not tools:
            self.kwargs.pop("tools")

    def chat(self, message: str | list) -> Iterator[str | dict]:
        if not message:
            raise ValueError("Message is empty.")
        
        # results = []
        if isinstance(message, str):
            user_message = Message(role="user", content=message)
            self.messages.append(self.llm.form_message(user_message))
        elif isinstance(message, list):
            tool_result_messages = self.llm.form_message(message)
            # content = tool_result_messages["content"]
            # for item in content:
            #     results.append((item["toolResult"]["toolUseId"], item["toolResult"]["content"]))
            self.messages.append(tool_result_messages)

        response = self.llm.stream_chat(self.messages, **self.kwargs)

        accumulated = ""
        tools_used = []
        usage_data = None
        for chunk in response:
            if isinstance(chunk, str):
                if not "**Using tool:**" in chunk:
                    accumulated += chunk
                yield chunk
            elif isinstance(chunk, dict):
                if chunk.get("input_tokens"):
                    usage_data = chunk
                else:
                    for v in chunk.values():
                        tools_used.append(v)
        
        if accumulated:
            assistant_message = Message(role="assistant", content=accumulated.strip())
            self.messages.append(self.llm.form_message(assistant_message))
        if tools_used:
            tool_message = {
                "role": "assistant",
                "content": [{"toolUse": tool} for tool in tools_used]
            }
            self.messages.append(tool_message)
            yield tools_used
            # else:
            #     assistant_message = Message(role="assistant", content=accumulated.strip())
            #     self.messages.append(self.llm.form_message(assistant_message))

        # if results:
        #     kwargs = {
        #         "system_prompt": "You specialize in writing the shortest possible summaries of tool call results, respond ONLY with the summary and no other text."
        #     }

        #     for tool_id, result in results:
        #         msg = Message(role="user", content=f"Summarize the following tool result: {result}")
        #         msg = self.llm.form_message(msg)

        #         summary_stream = self.llm.stream_chat([msg], **kwargs)

        #         summary_text = ""
        #         for chunk in summary_stream:
        #             if isinstance(chunk, str):
        #                 summary_text += chunk

        #         summary_text = summary_text.strip()

        #         # Replace the original tool result content with the summary
        #         for m in self.messages:
        #             if m["role"] == "user":
        #                 for item in m.get("content", []):
        #                     tool_result = item.get("toolResult")
        #                     if tool_result and tool_result["toolUseId"] == tool_id:
        #                         tool_result["content"] = [{"text": summary_text}]

        if usage_data:
            yield usage_data
