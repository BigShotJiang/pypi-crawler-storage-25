from nlsql_coder.app.agent.tools.file_tools import FILE_TOOL_REGISTRY

def call_tools(tool_calls: list[dict]) -> list[dict]:
    tool_results = []
    for tool in tool_calls:
        tool_id = tool["toolUseId"]
        tool_name = tool["name"]
        tool_input = tool["input"]

        tool_function = FILE_TOOL_REGISTRY.get(tool_name)

        if tool_function:
            tool_results.append({
                "toolUseId": tool_id,
                "name": tool_name,
                "result": tool_function(**tool_input),
                "status": "success"
            })
        else:
            tool_results.append({
                "toolUseId": tool_id,
                "name": tool_name,
                "result": "error: Unknown tool.",
                "status": "error"
            })
            
    return tool_results
