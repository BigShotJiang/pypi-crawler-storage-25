import argparse

arg_parser = argparse.ArgumentParser()

arg_parser.add_argument(
    "command",
    nargs="?",
    default=None
)

arg_parser.add_argument(
    "-w",
    "--workspace",
    default=".",
    help="Path to the target project's workspace."
)

arg_parser.add_argument(
    "-u",
    "--usage",
    action="store_true",
    help="Displayed usage data after each conversation turn."
)

args = arg_parser.parse_args()

if args.command == "init":
    args.workspace = "."