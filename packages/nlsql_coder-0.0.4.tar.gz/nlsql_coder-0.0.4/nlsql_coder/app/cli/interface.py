from nlsql_coder.app.agent.helpers.get_agent import agent
from nlsql_coder.app.cli.tool_calling import call_tools
from nlsql_coder.app.cli.arg_parsing import args

from rich.console import Console
from rich.markdown import Markdown
from rich.live import Live
from rich.align import Align
from nlsql_coder.data.create_agent_md import create_md
import time
import os


console = Console()

welcome_message = """[blue bold]\n
Welcome      _   _  _      ____   ___  _     
            | \ | || |    / ___| / _ \| |    
       to   |  \| || |    \___ \| | | | |    
            | |\  || |___  ___) | |_| | |___ 
            |_| \_||_____||____/ \__\_\_____|   Coder\n\n[/blue bold]
"""

def get_envs():
    console.print("[bold]To start, we need to set up your environment variables...[/bold]")
    os.environ["MODEL_PROVIDER"] = "aws"
    model_name = console.input("\n[bold blue][Model name]:[/bold blue] ")
    access_key_id = console.input("\n[bold blue][Access Key ID]:[/bold blue] ")
    secret_key = console.input("\n[bold blue][Secret Access Key]:[/bold blue] ")
    region = console.input("\n[bold blue][Region]:[/bold blue] ")
    os.environ["MODEL_NAME"] = model_name
    os.environ["AWS_ACCESS_KEY_ID"] = access_key_id
    os.environ["AWS_SECRET_ACCESS_KEY"] = secret_key
    os.environ["AWS_DEFAULT_REGION"] = region


def main_loop():
    try:
        console.clear()
        console.print(Align.center(welcome_message))
        get_envs()
        usage_data = {}
        console.clear()
        with console.status("[bold]Creating AGENTS.md file...\n[/bold]", spinner="dots"):
            success = create_md()
        if success == "created":
            console.print("[bold]AGENTS.md file created at project root.\n[/bold]")
        elif success == "exists":
            console.print("[bold]AGENTS.md file already exists at project root.\n[/bold]")
        elif success == "empty":
            console.print("[bold]Starting from scratch!\n[/bold]")
        else:
            console.print("[bold]Failed to create AGENTS.md file.\n[/bold]")
        time.sleep(2)
        console.clear()
        console.print(Align.center(welcome_message))
        while True:

            if args.usage and usage_data:
                table = (
                    "| Input Tokens | Output Tokens | Total Tokens |\n"
                    "|--------------|---------------|---------------|\n"
                    f"| {usage_data.get('input_tokens')} | {usage_data.get('output_tokens')} | {usage_data.get('total_tokens')} |\n"
                )
                console.print("[bold]\n\nUsage Data[/bold]")
                console.print(Markdown(table))

            messages = console.input("\n[bold green][You]:[/bold green] ")

            if messages.lower() in ["quit", "exit"]:
                console.print("\n\n[bold purple]Goodbye[/bold purple]\n")
                break

            console.print("\n[bold cyan][Assistant]:[/bold cyan]")

            while True:
                usage_data = {}

                found_tool_calls = False
                buffer = ""
                with Live(console=console, refresh_per_second=1) as live:
                    for chunk in agent.chat(messages):
                        if isinstance(chunk, str):
                            # Chat message chunk
                            buffer += chunk
                            live.update(Markdown(buffer))
                        elif isinstance(chunk, list):
                            # Tool execution
                            found_tool_calls = True
                            tool_results = call_tools(chunk)
                            messages = tool_results
                        elif isinstance(chunk, dict):
                            # Usage data
                            if args.usage:
                                if not usage_data:
                                    usage_data["input_tokens"] = chunk["input_tokens"]
                                    usage_data["output_tokens"] = chunk["output_tokens"]
                                    usage_data["total_tokens"] = chunk["total_tokens"]
                                else:
                                    usage_data["input_tokens"] += chunk["input_tokens"]
                                    usage_data["output_tokens"] += chunk["output_tokens"]
                                    usage_data["total_tokens"] += chunk["total_tokens"]


                if not found_tool_calls:
                    break
    except KeyboardInterrupt:
        console.print("\n\n[bold purple]Goodbye[/bold purple]\n")
    except Exception as e:
        console.print(f"\n\n[bold red]Oh no! Something went wrong. Here's the error:\n\n{e}[/bold red]\n")
