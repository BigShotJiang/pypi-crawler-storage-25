"""
Base provider class.
Normalizes LLM interaction and responses amoung the different LLM providers.
"""
from abc import ABC, abstractmethod
from typing import Iterator, Literal, Dict, Optional, Any, List
from dataclasses import dataclass, field

@dataclass
class Message:
    role: Literal["user", "assistant", "system"]
    content: str | dict


@dataclass
class ToolProperty:
    type: str
    description: str
    default: Optional[Any] = None
    items: Optional["ToolProperty"] = None
    properties: Optional[Dict[str, "ToolProperty"]] = None
    required: Optional[List[str]] = None

@dataclass
class ToolSchema:
    type: str = "object"
    properties: Dict[str, ToolProperty] = field(default_factory=dict)
    required: List[str] = field(default_factory=list)

    def serialize(self):
        return serialize_schema(self)

@dataclass
class ToolSpecification:
    name: str
    description: str
    schema: ToolSchema


def serialize_property(prop: ToolProperty):
    result = {
        "type": prop.type,
        "description": prop.description
    }

    if prop.default is not None:
        result["default"] = prop.default

    if prop.type == "array" and prop.items:
        result["items"] = serialize_property(prop.items)

    if prop.type == "object" and prop.properties:
        result["properties"] = {
            k: serialize_property(v) for k, v in prop.properties.items()
        }
        result["required"] = prop.required or []
        result["additionalProperties"] = False

    return result

def serialize_schema(schema: ToolSchema):
    result = {
        "type": schema.type,
        "properties": {
            k: serialize_property(v)
            for k, v in schema.properties.items()
        },
        "required": schema.required or [],
        "additionalProperties": False
    }
    return result


class BaseProvider(ABC):
    @abstractmethod
    def stream_chat(self, messages: list[Message], **kwargs) -> Iterator[str]:
        pass

    @abstractmethod
    def form_message(self, message: Message):
        pass
