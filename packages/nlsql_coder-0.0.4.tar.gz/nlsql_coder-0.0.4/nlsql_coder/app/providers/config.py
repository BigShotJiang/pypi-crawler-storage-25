"""
Provider configuration.
"""
from dataclasses import dataclass
from dotenv import load_dotenv
import os

load_dotenv()

# Provider & Model config
@dataclass
class ProviderConfig:
    model_provider: str = os.getenv("MODEL_PROVIDER", "")
    model_name: str = os.getenv("MODEL_NAME", "")


# AWS Config
@dataclass
class AWSConfig:
    access_key_id: str = os.getenv("AWS_ACCESS_KEY_ID", "")
    secret_access_key: str = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    region: str = os.getenv("AWS_DEFAULT_REGION", "")
