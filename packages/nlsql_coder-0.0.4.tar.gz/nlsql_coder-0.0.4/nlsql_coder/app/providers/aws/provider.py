from nlsql_coder.app.providers.base import BaseProvider, Message
from typing import Iterator
from nlsql_coder.app.providers.config import AWSConfig
from nlsql_coder.app.agent.tools.tool_specs import ToolSpecification, tool_aws_bedrock
import boto3
import json


class AWSBedrockProvider(BaseProvider):
    
    def __init__(self, model_id: str):
        config = AWSConfig()

        self.model_id = model_id
        self.client = boto3.client(
            "bedrock-runtime",
            region_name=config.region,
            aws_access_key_id=config.access_key_id,
            aws_secret_access_key=config.secret_access_key,
        )

    def form_message(self, message: Message | list[dict]) -> dict:
        if isinstance(message, Message):
            if isinstance(message.content, str): # Standard chat message
                return {"role": message.role, "content": [{"text": message.content}]}
            if isinstance(message.content, dict): 
                if message.content["type"] == "tool_use":
                    return {"role": message.role, "content": [{"toolUse": message.content}]} # Tool call message
        else:
            results = {
                "role": "user", 
                "content": [
                    {
                        "toolResult": {
                            "toolUseId": m["toolUseId"], 
                            "content": [{"text": m["result"]}], 
                            "status": m["status"]
                        }
                    } 
                    for m in message
                ]
            }
            return results
                    

    def stream_chat(self, messages: list[Message], 
                    max_tokens: int = 8192, 
                    temperature: float = 0.7,
                    system_prompt: str = "",
                    tools: list[ToolSpecification] | None = None) -> Iterator[str]:

        system_message = [{"text": system_prompt}]
        inference_config = {"maxTokens": max_tokens}
        
        if not "opus-4-7" in self.model_id:
            inference_config["temperature"] = temperature

        kwargs = {
            "modelId": self.model_id,
            "messages": messages,
            "system": system_message,
            "inferenceConfig": inference_config,
        }

        if tools:
            tools = [tool_aws_bedrock(tool) for tool in tools]
            kwargs["toolConfig"] = {"tools": tools}
        
        response = self.client.converse_stream(**kwargs)

        tool_calls = {}
        usage_data = {}

        for event in response["stream"]:
            if "contentBlockStart" in event:
                idx = event["contentBlockStart"]["contentBlockIndex"]
                start_event = event["contentBlockStart"]["start"]
                if "toolUse" in start_event:
                    tool_use = start_event['toolUse']
                    tool_calls[idx] = {
                        "toolUseId": tool_use["toolUseId"] ,
                        "name": tool_use["name"],
                        "input": "",
                        "type": tool_use["type"]
                    }
                    yield f"\n\n**Using tool:** {tool_use['name']}\n" # User-facing tool call message
            
            if "contentBlockDelta" in event:
                delta_event = event["contentBlockDelta"]
                idx = delta_event["contentBlockIndex"]
                if "delta" in delta_event:
                    delta = delta_event["delta"]
                    if "text" in delta:
                        yield delta["text"] # Message chunk output
                    if "toolUse" in delta:
                        tool_input_chunk = delta["toolUse"]["input"] # Tool input chunks
                        if idx in tool_calls:
                            tool_calls[idx]["input"] += tool_input_chunk

            if "contentBlockStop" in event:
                idx = event["contentBlockStop"]["contentBlockIndex"]
                if tool_calls:
                    # Turn tool input json string to dict
                    for v in tool_calls.values():
                        if isinstance(v.get("input"), str):
                            raw_val = v["input"].strip()
                            if raw_val:
                                try:
                                    v["input"] = json.loads(raw_val)
                                    if v.get("name") == "read_file":
                                        yield f"**Reading {v['input'].get('file_path')}**\n\n"
                                    if v.get("name") in ["edit_file", "insert_to_file", "insert_relative"]:
                                        yield f"**Editing {v['input'].get('file_path')}**\n\n"
                                    if v.get("name") == "write_file":
                                        yield f"**Writing {v['input'].get('file_path')}**\n\n"
                                except json.JSONDecodeError:
                                    v["input"] = {}
                            else:
                                v["input"] = {}

            if "metadata" in event:
                metadata = event["metadata"]
                if "usage" in metadata:
                    usage = metadata["usage"]
                    usage_data = {
                        "input_tokens": usage["inputTokens"],
                        "output_tokens": usage["outputTokens"],
                        "total_tokens": usage["totalTokens"]
                    }

        # If tools were called yield the calls and execute them in the agent class
        if tool_calls:
            yield tool_calls
        if usage_data:
            yield usage_data
    


    