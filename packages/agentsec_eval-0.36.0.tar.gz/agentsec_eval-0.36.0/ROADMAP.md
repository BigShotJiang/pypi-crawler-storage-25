# Roadmap

## Phase 1 — 基础框架 ✅（v0.1.0，2026-04-24）

跑通完整评估流水线，验证架构可行性。

- [x] 项目脚手架（adapter / evaluator / runner / reporter / CLI）
- [x] LLM-as-Judge 评判器
- [x] 内置测试用例：prompt injection、data leakage、tool abuse
- [x] Markdown 报告渲染
- [x] 架构决策记录（ADR）

---

## Phase 2 — OpenClaw 综合评估 ✅（v0.2.0，2026-04-28）

详见 [`docs/specs/openclaw-evaluation.md`](docs/specs/openclaw-evaluation.md) 与
[`docs/superpowers/plans/2026-04-25-openclaw-evaluation.md`](docs/superpowers/plans/2026-04-25-openclaw-evaluation.md)。

- [x] 阶段 0：规格收敛 + CI 威胁情报校验
- [x] 阶段 A：Judge 抽象 / Observation / 多轮 TestCase / Redactor
- [x] 阶段 B：Adapter 注册表 + OpenClaw Gateway + Fixture 拓扑
- [x] 阶段 C：远程 9 大类用例 + Assertion schema + HybridJudge
- [x] 阶段 D：server-audit MVP（native ingest + SSH policy + Authorization gate）
- [x] 阶段 E：server-audit 完整 10 类 checks + PlatformProfile + IOC/CVE DB
- [x] 阶段 F：归一化评分 + `agentsec evaluate` + 报告渲染
- [x] 阶段 G：集成回归 + 文档同步 + 示例报告

---

## Phase 3 — OpenClaw 持续演进

- [x] `agentsec ioc-update`（NVD / CISA KEV / GHSA） — v0.3.0，2026-04-29
- [x] 双周 IOC 自动刷新例行任务 — routine `trig_01MEho6fTP832MF8aGeWXu8u`
- [x] 跨渠道关联攻击 Sub-project A：API + WebSocket 双渠道基础设施 + 6 条 case（v0.5.0, PR #32）
- [x] WebSocket 端点探测（`exposure_scan` 扩展）— v0.5.1，2026-05-04
- [x] Plugin AST-grep danger-pattern 扫描（`plugin_static` 扩展）— v0.5.2，2026-05-04
- [x] 多目标并行评估（`agentsec multi-evaluate`，ThreadPoolExecutor 并行） — v0.6.0，2026-05-04
- [x] 真机 server-audit dry-run — Lightsail (34.208.65.73) v2026.2.3-1 systemd `--user`，168 个 CVE 匹配（7 CRITICAL），2026-05-06
- [x] Web UI 报告查看器（`agentsec serve`，Flask + Bootstrap 5）— v0.7.0，2026-05-04

---

## Phase 4 — 测试用例扩展

围绕 OpenClaw + 通用 Agent 攻击面积扩充测试集。

- [x] OpenClaw 9 大攻击面用例集（直接/间接 PI、记忆投毒、tool abuse、consent bypass、auth/authz、SSRF、extension auth、supply chain）
- [x] 记忆投毒（memory poisoning）测试集 — `03_memory_poisoning.yaml`，5 case
- [x] 多轮对话攻击（multi-turn jailbreak）— `Turn.judge_after` / `sleep_ms` 多轮 replay 落地
- [x] 工具调用滥用进阶用例 — `04_tool_abuse.yaml` 17 case
- [x] 关键级（CVSS≥9.0）CVE 全量映射 — 11/11，PR #11
- [x] 高严重度（CVSS 7.0–8.9）CVE 覆盖初始化 — 74/83 mapped + 9 out_of_scope = 100% accounted，2026-04-30
- [x] 测试用例贡献规范 — [`docs/guide/writing-test-cases.md`](docs/guide/writing-test-cases.md)
- [x] Agent chain 权限提升测试集（多 agent 串联越权场景）— `10_agent_chain_privesc.yaml`，6 case，2026-05-04
- [x] `ConfigKeyNotChanged.forbidden_value_pattern` 字段补充（PR #24 reviewer 标记的 schema gap） — PR #26, 2026-04-30

---

## Phase 5 — 报告与集成

让评估结果可观测、可追踪、可接入 CI。

- [x] JSON 报告格式 — Stage F：`findings.json` + `threat-intel-snapshot.yaml`
- [x] 评估结果打分模型（按严重度加权）— Stage F：`agentsec.scoring`
- [x] `agentsec diff` 历史趋势对比 (v0.4.0, PR #30)
- [x] GitHub Actions 示例工作流 — `.github/workflows/agentsec-evaluate.yml.example`，2026-04-30
- [x] `scripts/check_threat_refs.py` 双向一致性校验（case.threat_refs ↔ threat_intel.mapped_tests） — PR #27, 2026-04-30
- [x] 服务端审计报告大规模改版 — 目录、SVG 严重度饼图（带数量+占比图例）、§1 审计目标多字段表 + 审计方法 + 拓扑图、§2.2 启发式攻击路径推导（4 scenario 模板）、§3.0 `version_patch` CVE 总览 + 折叠卡片、KEV / CVSS / NVD 来源标注；`TargetDescriptor` 由 CLI 注入 — 2026-05-08

---

## Phase 6 — 扩展性

支持更多评估场景和评判器。

- [x] 自定义评判器接口（非 Claude judge） — v0.8.0，2026-05-04
- [x] 测试用例市场 / 社区共享 — v0.9.0，2026-05-04

---

## Phase 7 — 框架对齐 / OWASP

把测试覆盖度按 OWASP 主流框架编号公开。

- [x] Phase 7a — OWASP LLM Top 10 (2025) 全覆盖 + Agentic 部分覆盖 + 框架对齐基础设施 — 2026-05-08
- [x] Phase 7b — Agentic Top 17 全覆盖（每威胁 ≥ 3 case，CI 闸门同步上调）— 2026-05-08
- [x] Phase 7c — MCP Top 10 自策展评估套件（5 YAML / 80 cases / 报告覆盖表 / CI 闸）— 2026-05-12
- [x] Phase 7c.2 — Real MCP adapter (in-process Claude MCP client + adversarial MCP server via anyio memory streams; new CLI `agentsec mcp-run`; 12 cases at `mcp_real_suites/mcp_real_tools.yaml`; MCP1/2/10 covered) — 2026-05-14
- [x] Phase 7c.3 — MCP resources + prompts harness (8 new cases; synthetic tools pair for resources/prompts; file-or-dir suite loader; MCP4/MCP5 coverage) — v0.23.0，2026-05-14
- [x] Phase 7c.6 — `agentsec evaluate` MCP integration (`mcp_real:` config
  field, opt-in `weight_mcp` scoring, `mcp-real-report.md` + `mcp-findings.json`
  artifacts, `combined-report.md §MCP real-protocol`) — 2026-05-14
- [x] Phase 7c.4 — MCP6 (tools/list_changed) + MCP7 (sampling/createMessage) real-protocol coverage (mutations dirty-bit re-fetch + sampling deny/stub; 8 new cases; `AgentResponse.server_events`) — v0.24.0，2026-05-15
- [x] Phase 7c.5 — MCP3 多 server 交叉污染（multi-server cross-talk；`mcp_servers` XOR + namespace prefix `<server>__<tool>`；4 新 case；`fixtures=` 接口迁移）— v0.25.0，2026-05-15
- [x] Phase 7c.x.1 — multi-server resources + prompts (v0.26.0, 2026-05-15)
- [x] Phase 7c.x.2 — multi-server mutations (v0.27.0, 2026-05-15)
- [x] Phase 7c.x.3 — multi-server sampling (v0.28.0, 2026-05-15)
- [x] Phase 7c.x.4 — perf + refactor polish（`asyncio.gather` + 3 个 module-level helper 提取 + strict `sampling_per_server["policy"]` key）— v0.29.0，2026-05-15
- [x] Phase 7c.1 — `mcp_supplements.yaml` 深变体补充（MCP1 +8 / MCP2 +7；4 维度 encoding/data/gradient/coercion）— v0.30.0，2026-05-15
- [x] Phase 7c.1.x — `mcp_supplements_2.yaml` MCP3-MCP10 深变体（32 cases，4 per id × 8 ids；MCP_FLOOR 6→10；ADR-0021）— v0.31.0，2026-05-16
- [x] **Phase 7c.1.y** (shipped v0.32.0, 2026-05-16) — mcp_supplements_3.yaml
  20 cases on new dimension E (Race / TOCTOU) across MCP1..MCP10 +
  `MCP_FLOOR` 10 → 12.
- [x] **Phase 7c.1.z** (shipped v0.33.0, 2026-05-16) — mcp_supplements_4.yaml
  10 cross-MCP-id sequential chain cases (A → B topology) +
  `MCP_FLOOR` 12 → 14.
- [x] Phase 7d.1 — pip 供应链 Check（OSV-PyPI bundled DB，TI-OSV-PYPI-CATALOG，3452 advisories）— 2026-05-11
- [x] Phase 7d.2 — go 供应链 Check（OSV-Go bundled DB，TI-OSV-GO-CATALOG，2760 advisories）+ `_supply_chain_common.py` 抽取 — 2026-05-11
- [x] Phase 7d.3 — rust 供应链 Check（OSV-Cargo bundled DB，TI-OSV-CRATES-CATALOG，1396 advisories）— 2026-05-11
- [x] Phase 7d.4 — Java/Maven supply chain audit (5th ecosystem in the
  series; hand-written Maven ComparableVersion comparator; operator
  pre-runs `mvn dependency:list` for input) — v0.34.0，2026-05-16
- [x] Phase 7d.5 — Ruby/Gem supply chain audit (6th ecosystem in the
  series; reuses packaging.version (PEP 440) with RubyGems preprocessing;
  operator points --gem-lock-path at a Bundler Gemfile.lock) — v0.35.0，
  2026-05-16. **6-language coverage milestone**.
- [x] Phase 7d.6 — PHP/Composer supply chain audit (7th ecosystem in the
  series; reuses packaging.version (PEP 440) with Composer stability-flag
  preprocessing; operator points --composer-lock-path at a Composer
  composer.lock. First 7d ecosystem to distinguish prod vs dev scope in
  finding evidence) — v0.36.0，2026-05-17. **7-language coverage milestone**.
- [ ] Phase 7d.x — `plugin_static` 静态扫描扩展
- [x] Phase 7e — Linux 主机加固 Check（sysctl / sshd_config / sudoers / SUID 4 类，CIS 对齐）— 2026-05-08
- [x] Phase 7e.1 — Linux 主机加固扩展 Check（world-writable / auditd / systemd 服务黑名单 / systemd unit lint 4 类）— 2026-05-08
- [x] Phase 7f — 容器安全 Check（Docker daemon / runtime / image 三类，21 条 TI-DOCKER-*，CIS Docker Benchmark 对齐）— 2026-05-09
- [x] Phase 7e.2 — Linux 主机加固防火墙 Check（iptables / nftables / ufw 三类，TI-LINUX-CIS-FIREWALL）— 2026-05-09
- [x] Phase 7e.3 — firewalld audit（3-command pipeline + iptables/nftables cross-talk yield，RHEL/CentOS Stream/Fedora）— v0.17.0，2026-05-12
- [x] Phase 7f.1 — Podman + Containerd audit (5 new Checks; nerdctl-first/ctr-fallback; docker-takeover yield) — 2026-05-12
- [x] **7f.1.1 — containerd_daemon_audit** (v0.19.0, 2026-05-13)
  - 6 rules covering TCP / debug / metrics / CRI sub-config / version CVE
  - Shared helper `_docker_takeover_active(ctx)` extracted from 7f.1 containerd Checks
- [ ] Phase 7e.5 — rich rules / dangerous services / runtime-vs-permanent drift / `--get-log-denied` baseline
- [x] Phase 7d — npm supply chain Check（OSV-npm bundled DB，TI-OSV-NPM-CATALOG）— 2026-05-09

---

> 更新此文件时请同步更新 GitHub Issues 中对应的 milestone。
> 每个 Phase 完成后在此打勾并注明完成日期。
