#!/usr/bin/env python3
"""CI guard for src/agentsec/audit/ioc/osv_rubygems.json.

Validates the bundled OSV-RubyGems advisory DB:
  - File exists
  - Valid JSON (top-level list of advisory dicts)
  - File size <= 15 MB hard cap

Usage:
    python scripts/check_osv_rubygems.py [--check]

Exits 0 on success, 1 on failure.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "src/agentsec/audit/ioc/osv_rubygems.json"
SIZE_CAP_BYTES = 15 * 1024 * 1024  # 15 MB


def main() -> int:
    if not DB_PATH.exists():
        print(f"FAIL: {DB_PATH} does not exist", file=sys.stderr)
        return 1

    size = DB_PATH.stat().st_size
    if size > SIZE_CAP_BYTES:
        print(
            f"FAIL: {DB_PATH} is {size:,} bytes, exceeds cap "
            f"{SIZE_CAP_BYTES:,} bytes",
            file=sys.stderr,
        )
        return 1

    try:
        data = json.loads(DB_PATH.read_text())
    except json.JSONDecodeError as exc:
        print(f"FAIL: {DB_PATH} is not valid JSON: {exc}", file=sys.stderr)
        return 1

    if not isinstance(data, list):
        print(
            f"FAIL: {DB_PATH} top-level must be a list, got {type(data).__name__}",
            file=sys.stderr,
        )
        return 1

    print(
        f"OK — {DB_PATH.name} contains {len(data):,} advisories, "
        f"{size:,} bytes (cap {SIZE_CAP_BYTES:,})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
