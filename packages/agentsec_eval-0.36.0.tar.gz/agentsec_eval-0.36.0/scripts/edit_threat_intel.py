"""Round-trip editor for threat_intel.yaml mapped_tests field.

Usage:
    python scripts/edit_threat_intel.py --map-tests <csv> [--intel <path>] [--in-place]

CSV format: two columns `cve_id,test_id`. Multiple rows per cve_id append.

Guarantees:
    - Only `mapped_tests` is mutated. Every other field is byte-equal.
    - If any cve_id in the CSV is missing from the intel file, the helper
      exits 1 and writes nothing.
    - Adding new test_ids to an existing entry is always allowed (set semantics).
    - Idempotent: running the same CSV twice yields the same file.
"""

from __future__ import annotations

import argparse
import csv as csvmod
import sys
from collections import defaultdict
from pathlib import Path

# Allow importing the renderer without making this script package-aware.
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from agentsec.audit.ioc_update.cli import _load_existing_intel  # noqa: E402
from agentsec.audit.ioc_update.renderer import render_proposed_yaml  # noqa: E402


class EditError(RuntimeError):
    """Raised on any pre-write validation failure."""


def _read_csv(csv_path: Path) -> dict[str, list[str]]:
    out: dict[str, list[str]] = defaultdict(list)
    with csv_path.open() as f:
        reader = csvmod.DictReader(f)
        if reader.fieldnames != ["cve_id", "test_id"]:
            raise EditError(
                f"csv header must be 'cve_id,test_id', got {reader.fieldnames!r}"
            )
        for row in reader:
            cve_id = row["cve_id"].strip()
            test_id = row["test_id"].strip()
            if not cve_id or not test_id:
                raise EditError(f"empty cve_id or test_id in row {row!r}")
            if test_id not in out[cve_id]:
                out[cve_id].append(test_id)
    return dict(out)


def apply(intel_path: Path, csv_path: Path, in_place: bool) -> str:
    """Apply mapped_tests updates from the CSV to the intel file.

    Returns the rendered YAML. Writes back if in_place=True.
    """
    targets = _read_csv(csv_path)
    entries = _load_existing_intel(intel_path)

    by_id = {e.id: e for e in entries}

    # Validate every cve_id exists.
    missing = [cid for cid in targets if cid not in by_id]
    if missing:
        raise EditError(f"unknown cve(s): {missing}")

    for cid, wanted in targets.items():
        existing = list(by_id[cid].mapped_tests or [])
        # Merge: union, preserving ordering of wanted then any pre-existing.
        # No conflict check — adding new test_ids to an entry is always allowed
        # (set-semantic field). The helper never overwrites; idempotent reapplies
        # produce byte-equal output.
        merged: list[str] = []
        for t in wanted:
            if t not in merged:
                merged.append(t)
        for t in existing:
            if t not in merged:
                merged.append(t)
        by_id[cid].mapped_tests = merged

    out = render_proposed_yaml(list(by_id.values()))

    if in_place:
        intel_path.write_text(out)
    return out


def _main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--map-tests", required=True, type=Path,
                   help="CSV with header 'cve_id,test_id'")
    p.add_argument(
        "--intel", type=Path,
        default=ROOT / "src" / "agentsec" / "audit" / "ioc" / "threat_intel.yaml",
    )
    p.add_argument("--in-place", action="store_true",
                   help="Write back to --intel; otherwise print to stdout.")
    args = p.parse_args()
    try:
        text = apply(args.intel, args.map_tests, in_place=args.in_place)
    except EditError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if not args.in_place:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
