#!/usr/bin/env python3
"""CI guard for src/agentsec/audit/ioc/osv_go.json.

Validates JSON well-formedness and a 15 MB hard cap on file size.
Exits 0 on success; 1 on any failure.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_DEFAULT_DB = Path("src/agentsec/audit/ioc/osv_go.json")
# ~3x current actual; trips long before pathological growth lands
_MAX_BYTES = 3 * 1024 * 1024


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", type=Path, default=_DEFAULT_DB)
    parser.add_argument(
        "--check", action="store_true",
        help="(no-op flag for parity with check_osv_npm.py / check_osv_pypi.py)",
    )
    args = parser.parse_args()

    db: Path = args.db
    if not db.exists():
        print(f"ERR: {db} does not exist", file=sys.stderr)
        return 1

    size = db.stat().st_size
    if size > _MAX_BYTES:
        size_mb = size / (1024 * 1024)
        print(
            f"ERR: {db} is {size_mb:.1f} MB, exceeds 3 MB cap",
            file=sys.stderr,
        )
        return 1

    try:
        data = json.loads(db.read_text())
    except json.JSONDecodeError as e:
        print(f"ERR: {db} is not valid JSON: {e}", file=sys.stderr)
        return 1

    if not isinstance(data, list):
        print(f"ERR: {db} top-level must be a JSON list", file=sys.stderr)
        return 1

    print(f"OK: {db} ({size / 1024:.1f} KB, {len(data)} entries)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
