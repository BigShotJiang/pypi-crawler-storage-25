#!/usr/bin/env python3
"""Validate threat-intel references end-to-end.

Three layers of checks:
  1. Every TI-* reference in docs/, test_suites/, src/ resolves to an entry in
     `src/agentsec/audit/ioc/threat_intel.yaml`.
  2. Every threat_intel entry has all required fields
     (source, url, observed_at, claim, confidence).
  3. **Bidirectional case ↔ TI consistency** for CVE-specific entries
     (id matches `TI-*-CVE-YYYY-N`):
       - case.threat_refs lists T  ⇒  T.mapped_tests must list case.id
       - T.mapped_tests lists case ⇒  case.threat_refs must list T.id
     Taxonomy entries (TI-OWASP-*, TI-LAKERA-*) are exempted from layer 3 —
     they are 1-to-many by design and only enforce layer 1.

Exit 0 = clean; non-zero = at least one failure. Designed to run from the
repo root.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import yaml

ROOT = Path.cwd()
YAML_PATH = ROOT / "src" / "agentsec" / "audit" / "ioc" / "threat_intel.yaml"
SCAN_DIRS = [ROOT / "docs", ROOT / "test_suites", ROOT / "src"]
SUITES_DIR = ROOT / "test_suites"
# superpowers plans contain inline test-code samples and aren't authoritative TI- sources.
EXCLUDE_DIRS = {(ROOT / "docs" / "superpowers").resolve()}
SCAN_EXTS = {".md", ".yaml", ".yml", ".py"}
REQUIRED_FIELDS = ("source", "url", "observed_at", "claim", "confidence")
# Negative lookahead skips namespace-glob references like `TI-OPENCLAW-CVE-*`
# in docs (those denote a prefix, not a specific entry). Possessive `++`
# prevents backtracking from emitting truncated matches like `TI-MS-`.
TI_RE = re.compile(r"\bTI-[A-Z0-9][A-Z0-9_\-]++\b(?!-?\*)")
# Bidirectional consistency only applies to CVE-shaped IDs. Taxonomy tags
# (TI-OWASP-*, TI-LAKERA-*) are 1-to-many by intent.
CVE_ID_RE = re.compile(r"^TI-[A-Z0-9_-]+-CVE-\d{4}-\d+$")


def _load_intel() -> tuple[dict[str, dict], list[str]]:
    if not YAML_PATH.exists():
        return {}, [f"missing intel file: {YAML_PATH}"]
    raw = yaml.safe_load(YAML_PATH.read_text()) or []
    intel: dict[str, dict] = {}
    errors: list[str] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            errors.append(f"entry is not a mapping: {entry!r}")
            continue
        eid = entry.get("id")
        if not eid:
            errors.append(f"entry at index {i} missing required field `id`")
            continue
        if eid in intel:
            errors.append(f"duplicate id: {eid}")
        intel[eid] = entry
        for field in REQUIRED_FIELDS:
            if not entry.get(field):
                errors.append(f"{eid}: missing required field `{field}`")
    return intel, errors


def _scan_refs() -> set[tuple[str, Path]]:
    refs: set[tuple[str, Path]] = set()
    for d in SCAN_DIRS:
        if not d.exists():
            continue
        for path in d.rglob("*"):
            if path.suffix not in SCAN_EXTS or not path.is_file():
                continue
            if any(ex in path.resolve().parents for ex in EXCLUDE_DIRS):
                continue
            if path.resolve() == YAML_PATH.resolve():
                continue
            try:
                text = path.read_text(errors="ignore")
            except OSError:
                continue
            for m in TI_RE.finditer(text):
                refs.add((m.group(0), path.relative_to(ROOT)))
    return refs


def _load_cases() -> tuple[dict[str, dict], list[str]]:
    """Parse every YAML in test_suites/ and return {case_id: {threat_refs, file}}.

    Suite files are flat lists of case dicts; non-conforming files are skipped
    quietly (Stage B's `_stage_b_smoke.yaml` follows the same shape).
    """
    cases: dict[str, dict] = {}
    errors: list[str] = []
    if not SUITES_DIR.exists():
        return cases, errors
    for path in SUITES_DIR.rglob("*.yaml"):
        try:
            raw = yaml.safe_load(path.read_text())
        except yaml.YAMLError as exc:
            errors.append(f"{path.relative_to(ROOT)}: yaml parse error: {exc}")
            continue
        if not isinstance(raw, list):
            continue
        for entry in raw:
            if not isinstance(entry, dict):
                continue
            cid = entry.get("id")
            if not cid:
                continue
            if cid in cases:
                errors.append(
                    f"duplicate case id {cid} in "
                    f"{path.relative_to(ROOT)} (also in {cases[cid]['file']})"
                )
            cases[cid] = {
                "threat_refs": entry.get("threat_refs") or [],
                "file": path.relative_to(ROOT),
            }
    return cases, errors


def _check_bidirectional(
    intel: dict[str, dict], cases: dict[str, dict]
) -> list[str]:
    """Asymmetries between case.threat_refs and TI.mapped_tests for CVE TIs.

    Layer-1 unresolved refs are reported elsewhere; here we only consider TI
    IDs that exist in `intel`. Cases referenced by TI.mapped_tests but not
    present in any suite are reported as a separate `[asymmetry-orphan]`
    line."""
    errors: list[str] = []

    for cid, info in cases.items():
        for tref in info["threat_refs"]:
            if not CVE_ID_RE.match(tref) or tref not in intel:
                continue
            mapped = intel[tref].get("mapped_tests") or []
            if cid not in mapped:
                errors.append(
                    f"[asymmetry] case {cid} ({info['file']}) references "
                    f"{tref} but {tref}.mapped_tests does not list {cid}"
                )

    for tid, entry in intel.items():
        if not CVE_ID_RE.match(tid):
            continue
        for cid in entry.get("mapped_tests") or []:
            if cid not in cases:
                errors.append(
                    f"[asymmetry-orphan] {tid}.mapped_tests lists {cid} "
                    f"but no test case with id {cid} exists in test_suites/"
                )
                continue
            refs = cases[cid]["threat_refs"]
            if tid not in refs:
                errors.append(
                    f"[asymmetry] {tid}.mapped_tests lists {cid} but "
                    f"{cases[cid]['file']}:{cid}.threat_refs does not list {tid}"
                )

    return errors


def main() -> int:
    intel, intel_errors = _load_intel()
    refs = _scan_refs()
    cases, case_errors = _load_cases()
    asymmetries = _check_bidirectional(intel, cases)
    unresolved: list[tuple[str, Path]] = [(rid, p) for rid, p in refs if rid not in intel]

    for err in intel_errors:
        print(f"[intel] {err}")
    for err in case_errors:
        print(f"[cases] {err}")
    for rid, path in sorted(unresolved):
        print(f"[unresolved] {rid} -> {path}")
    for err in sorted(asymmetries):
        print(err)

    if intel_errors or case_errors or unresolved or asymmetries:
        return 1

    unique_ids = {rid for rid, _ in refs}
    cve_intel = sum(1 for tid in intel if CVE_ID_RE.match(tid))
    print(
        f"OK: {len(unique_ids)} unique TI-* IDs "
        f"({len(refs)} file references) resolved against {len(intel)} intel "
        f"entries; bidirectional consistency validated across "
        f"{cve_intel} CVE entries / {len(cases)} test cases"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
