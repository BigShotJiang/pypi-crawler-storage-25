"""Project TI-*-CVE-* entries from threat_intel.yaml into cve_database.json.

Watches cve_db_include in watchlist.yaml to determine which vendors' CVEs are included.
Idempotent. CI runs `--check` to ensure the committed file is up to date.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml


def _included_prefixes(watchlist_path: Path) -> list[str]:
    """Read watchlist.yaml and return TI-prefix-CVE- strings for cve_db_include: true entries.

    Args:
        watchlist_path: Path to watchlist.yaml

    Returns:
        List of prefix strings like ["TI-OPENCLAW-CVE-"]
    """
    watchlist = yaml.safe_load(watchlist_path.read_text()) or []
    prefixes = []
    for entry in watchlist:
        if entry.get("cve_db_include", False):
            ti_prefix = entry.get("ti_prefix", "")
            if ti_prefix:
                prefixes.append(f"TI-{ti_prefix}-CVE-")
    return prefixes


def build(intel_path: Path, watchlist_path: Path) -> list[dict]:
    """Build CVE database by filtering intel entries whose IDs match included prefixes.

    Args:
        intel_path: Path to threat_intel.yaml
        watchlist_path: Path to watchlist.yaml

    Returns:
        Sorted list of CVE entries with id, source, url, claim, confidence, cvss,
        affected_versions, fixed_in.
    """
    prefixes = _included_prefixes(watchlist_path)
    intel = yaml.safe_load(intel_path.read_text()) or []
    out: list[dict] = []
    for entry in intel:
        eid = entry.get("id", "")
        # Include if ID starts with any of the included prefixes
        if any(eid.startswith(p) for p in prefixes):
            out.append({
                "id": eid,
                "source": entry.get("source", ""),
                "url": entry.get("url", ""),
                "claim": entry.get("claim", ""),
                "confidence": entry.get("confidence", ""),
                "cvss": entry.get("cvss"),
                "affected_versions": entry.get("affected_versions"),
                "fixed_in": entry.get("fixed_in"),
            })
    out.sort(key=lambda e: e["id"])
    return out


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--intel", default="src/agentsec/audit/ioc/threat_intel.yaml")
    p.add_argument("--watchlist", default="src/agentsec/audit/ioc/watchlist.yaml")
    p.add_argument("--out",   default="src/agentsec/audit/ioc/cve_database.json")
    p.add_argument("--check", action="store_true",
                   help="exit non-zero if --out differs from a fresh build")
    args = p.parse_args(argv)

    fresh = (
        json.dumps(
            build(Path(args.intel), Path(args.watchlist)), indent=2, sort_keys=False
        )
        + "\n"
    )
    out_path = Path(args.out)
    if args.check:
        existing = out_path.read_text() if out_path.exists() else ""
        if existing != fresh:
            sys.stderr.write(
                f"{args.out} is out of date. Run: python scripts/build_cve_db.py\n"
            )
            return 1
        return 0
    out_path.write_text(fresh)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
