"""CI gate — fail when OWASP framework coverage drops below threshold.

Three parallel checks:
- OWASP LLM Top 10 (2025): at least 1 case per category (ADR-0006).
- OWASP Agentic v1.1: at least 3 cases per threat (ADR-0007).
- MCP curated v1: at least 14 cases per threat (ADR-0016 → ADR-0021 → ADR-0022 → ADR-0023).

Usage:
    python scripts/check_owasp_coverage.py [suite-root]

When `suite-root` is omitted, defaults to `test_suites/` relative to the
repository root. The script walks the suite root *recursively*: every
`*.yaml` / `*.yml` file under `suite-root` (and any subdirectory) is
loaded as a test suite and contributes its cases to the coverage count.

Exit codes:
    0 — every LLM Top 10 entry has >= 1 case tagged
    1 — at least one entry has 0 cases (or load failed / validation error)
"""

from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path


def main(argv: list[str]) -> int:
    suite_root = Path(argv[1]) if len(argv) > 1 else Path("test_suites")
    if not suite_root.exists():
        print(f"suite root not found: {suite_root}", file=sys.stderr)
        return 1

    # Make `agentsec` importable when run from a checkout.
    repo_root = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(repo_root / "src"))

    try:
        from agentsec.reports.owasp_coverage import AGENTIC_THREATS, LLM_TOP10_2025, MCP_THREATS
        from agentsec.tests.loader import load_test_suite
    except Exception as exc:
        print(f"import error: {exc}", file=sys.stderr)
        return 1

    # `load_test_suite` accepts a single file or a directory of YAMLs but
    # does not recurse. Walk every directory that contains *.yaml so we
    # cover both `test_suites/*.yaml` and `test_suites/openclaw/*.yaml`
    # (and any future sibling subdir).
    seen_ids: dict[str, object] = {}
    yaml_files = sorted(
        {p.parent for p in suite_root.rglob("*.yaml")}
        | {p.parent for p in suite_root.rglob("*.yml")}
    )
    try:
        for d in yaml_files:
            for case in load_test_suite(d):
                seen_ids[case.id] = case
    except Exception as exc:
        print(f"load error: {exc}", file=sys.stderr)
        return 1

    counts: Counter[str] = Counter()
    for case in seen_ids.values():
        for ref in getattr(case, "owasp_refs", []) or []:
            counts[ref] += 1

    # LLM Top 10 ≥ 1 per category (Phase 7a floor).
    missing: list[str] = []
    for entry in LLM_TOP10_2025:
        if counts.get(entry.id, 0) == 0:
            missing.append(f"{entry.id} ({entry.title})")

    # Agentic v1.1 ≥ 3 per category (ADR-0007).
    AGENTIC_FLOOR = 3
    underspec: list[str] = []
    for entry in AGENTIC_THREATS:
        n = counts.get(entry.id, 0)
        if n < AGENTIC_FLOOR:
            underspec.append(
                f"{entry.id} ({entry.title}) — {n} case(s), "
                f"below threshold {AGENTIC_FLOOR}"
            )

    # MCP curated v1 ≥ 14 per threat (ADR-0016 → ADR-0021 → ADR-0022 → ADR-0023).
    MCP_FLOOR = 14
    mcp_underspec: list[str] = []
    for entry in MCP_THREATS:
        n = counts.get(entry.id, 0)
        if n < MCP_FLOOR:
            mcp_underspec.append(
                f"{entry.id} ({entry.title}) — {n} case(s), "
                f"below threshold {MCP_FLOOR}"
            )

    if missing or underspec or mcp_underspec:
        if missing:
            print("OWASP coverage gate FAILED — no cases tagged for:",
                  file=sys.stderr)
            for m in missing:
                print(f"  - {m}", file=sys.stderr)
        if underspec:
            print("OWASP Agentic coverage gate FAILED — categories below "
                  "threshold:", file=sys.stderr)
            for m in underspec:
                print(f"  - {m}", file=sys.stderr)
        if mcp_underspec:
            print("OWASP MCP curated v1 coverage gate FAILED — categories "
                  "below threshold:", file=sys.stderr)
            for m in mcp_underspec:
                print(f"  - {m}", file=sys.stderr)
        return 1

    print(
        "OK — every LLM Top 10 (2025) category has at least one case, "
        f"every Agentic v1.1 threat has at least {AGENTIC_FLOOR} cases, "
        f"and every MCP curated v1 threat has at least {MCP_FLOOR} cases."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
