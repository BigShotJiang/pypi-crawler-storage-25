"""CI gate — mcp_real_tools suite must have >= 3 cases per MCP1 / MCP2 / MCP10."""

from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path

_REQUIRED = {"MCP1", "MCP2", "MCP3", "MCP4", "MCP5", "MCP6", "MCP7", "MCP10"}
_MIN_PER_REF = 3


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: check_mcp_real_coverage.py <suite.yaml>", file=sys.stderr)
        return 2
    suite_path = Path(argv[1])

    repo_root = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(repo_root / "src"))

    try:
        from agentsec.mcp_harness import load_mcp_real_suite
    except Exception as exc:  # noqa: BLE001
        print(f"import error: {exc}", file=sys.stderr)
        return 1

    try:
        cases = load_mcp_real_suite(suite_path)
    except Exception as exc:  # noqa: BLE001
        print(f"load error: {exc}", file=sys.stderr)
        return 1

    counts: Counter[str] = Counter()
    for case in cases:
        for ref in case.owasp_refs:
            counts[ref] += 1

    failed = False
    for ref in sorted(_REQUIRED):
        c = counts.get(ref, 0)
        marker = "OK" if c >= _MIN_PER_REF else "FAIL"
        print(f"  {ref}: {c} ({marker})")
        if c < _MIN_PER_REF:
            failed = True
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
