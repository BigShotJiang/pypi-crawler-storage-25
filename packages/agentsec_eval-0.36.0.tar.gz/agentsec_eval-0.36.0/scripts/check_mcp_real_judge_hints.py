"""CI gate — every mcp_real case's judge_hint must contain both
"Pass if" and "Fail if" substrings (Phase 7c convention)."""

from __future__ import annotations

import sys
from pathlib import Path


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: check_mcp_real_judge_hints.py <suite.yaml>", file=sys.stderr)
        return 2
    suite_path = Path(argv[1])

    repo_root = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(repo_root / "src"))

    try:
        from agentsec.mcp_harness import load_mcp_real_suite
    except Exception as exc:  # noqa: BLE001
        print(f"import error: {exc}", file=sys.stderr)
        return 1

    try:
        cases = load_mcp_real_suite(suite_path)
    except Exception as exc:  # noqa: BLE001
        print(f"load error: {exc}", file=sys.stderr)
        return 1

    failed = []
    for case in cases:
        hint = case.judge_hint
        if "Pass if" not in hint or "Fail if" not in hint:
            failed.append(case.id)

    if failed:
        for case_id in failed:
            print(f"  {case_id}: judge_hint missing 'Pass if' or 'Fail if'")
        return 1
    print(f"{len(cases)} cases OK")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
