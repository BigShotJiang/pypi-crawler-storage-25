#!/usr/bin/env python3
"""Static check for src/agentsec/suite_registry/community-suites.yaml.

Runs in CI on every PR. Validates:
  - file parses as YAML
  - every entry validates as RegistryFile (extra="forbid")
  - registry key matches NAME_REGEX
  - no duplicate (repo, subdir) pairs across entries

Exits 1 on any violation; exits 0 on success.
"""

import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from agentsec.suite_registry.manifest import NAME_REGEX, RegistryFile  # noqa: E402

INDEX_PATH = ROOT / "src" / "agentsec" / "suite_registry" / "community-suites.yaml"


def main() -> int:
    text = INDEX_PATH.read_text()
    try:
        raw = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        print(f"FAIL: {INDEX_PATH} is not valid YAML: {exc}")
        return 1

    try:
        rf = RegistryFile.model_validate(raw)
    except Exception as exc:
        print(f"FAIL: schema error in {INDEX_PATH}: {exc}")
        return 1

    seen: dict[tuple[str, str], str] = {}
    for name, entry in rf.suites.items():
        if not NAME_REGEX.fullmatch(name):
            print(f"FAIL: registry key {name!r} does not match {NAME_REGEX.pattern}")
            return 1
        key = (entry.repo, entry.subdir)
        if key in seen:
            print(f"FAIL: duplicate (repo, subdir) {key} between {seen[key]!r} and {name!r}")
            return 1
        seen[key] = name

    print(f"OK: {len(rf.suites)} entries valid")
    return 0


if __name__ == "__main__":
    sys.exit(main())
