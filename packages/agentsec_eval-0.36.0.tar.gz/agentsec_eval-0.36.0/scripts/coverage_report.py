"""Print CVSS-bucketed mapped_tests coverage of threat_intel.yaml."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_INTEL = ROOT / "src" / "agentsec" / "audit" / "ioc" / "threat_intel.yaml"

_BUCKETS = (
    ("critical", 9.0, 10.1),
    ("high", 7.0, 9.0),
    ("medium", 4.0, 7.0),
    ("low", 0.0, 4.0),
)

_BUCKETS_LABEL = {
    "critical": ">=9.0",
    "high": "7.0-8.9",
    "medium": "4.0-6.9",
    "low": "<4.0",
}


@dataclass
class BucketRow:
    bucket: str
    total: int
    mapped: int
    out_of_scope: int


def _bucket_for(cvss: float | None) -> str | None:
    if cvss is None:
        return None
    for name, lo, hi in _BUCKETS:
        if lo <= cvss < hi:
            return name
    return None


def compute(intel_path: Path) -> list[BucketRow]:
    raw = yaml.safe_load(intel_path.read_text()) or []
    counts: dict[str, dict[str, int]] = {
        b: {"total": 0, "mapped": 0, "oos": 0} for b, _, _ in _BUCKETS
    }
    for e in raw:
        b = _bucket_for(e.get("cvss"))
        if b is None:
            continue
        counts[b]["total"] += 1
        mt = e.get("mapped_tests") or []
        note = e.get("note") or ""
        if mt:
            counts[b]["mapped"] += 1
        elif "out_of_scope" in note:
            counts[b]["oos"] += 1
    return [
        BucketRow(bucket=b, total=c["total"], mapped=c["mapped"], out_of_scope=c["oos"])
        for b, c in counts.items()
    ]


def render(rows: list[BucketRow]) -> str:
    lines = []
    for r in rows:
        pct = (100.0 * r.mapped / r.total) if r.total else 0.0
        lines.append(
            f"{r.bucket:8} ({_BUCKETS_LABEL[r.bucket]}): "
            f"{r.mapped} / {r.total} mapped ({pct:.0f}%, {r.out_of_scope} out_of_scope)"
        )
    return "\n".join(lines)


def _main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--intel", type=Path, default=DEFAULT_INTEL)
    p.add_argument("--severity", choices=("critical", "high", "medium", "low", "all"),
                   default="all")
    args = p.parse_args()
    rows = compute(args.intel)
    if args.severity != "all":
        rows = [r for r in rows if r.bucket == args.severity]
    print(render(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
