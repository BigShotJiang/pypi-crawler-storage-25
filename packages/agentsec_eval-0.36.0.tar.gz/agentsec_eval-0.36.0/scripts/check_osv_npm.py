#!/usr/bin/env python3
"""CI guard for src/agentsec/audit/ioc/osv_npm.json (Phase 7d).

Validates: file is valid JSON, is a list, total size ≤ 15 MB. Mirrors
scripts/build_cve_db.py --check semantics: exit 0 = OK, exit 1 = fail.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DB_PATH = REPO_ROOT / "src" / "agentsec" / "audit" / "ioc" / "osv_npm.json"
# ~3x current actual; trips long before pathological growth lands
SIZE_LIMIT = 3 * 1024 * 1024


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--check", action="store_true",
                   help="validate the committed file (CI mode)")
    p.add_argument("--db-path", type=Path, default=DEFAULT_DB_PATH,
                   help="alternate DB path (testing only)")
    args = p.parse_args()

    if not args.check:
        print("usage: check_osv_npm.py --check [--db-path PATH]", file=sys.stderr)
        return 2

    db_path: Path = args.db_path
    if not db_path.exists():
        print(f"osv_npm.json not found at {db_path}", file=sys.stderr)
        return 1

    size = db_path.stat().st_size
    if size > SIZE_LIMIT:
        print(
            f"osv_npm.json size {size} exceeds {SIZE_LIMIT} hard cap (3 MB). "
            "Tighten fetcher filters or split into a separate package.",
            file=sys.stderr,
        )
        return 1

    try:
        data = json.loads(db_path.read_text())
    except json.JSONDecodeError as e:
        print(f"osv_npm.json invalid JSON: {e}", file=sys.stderr)
        return 1

    if not isinstance(data, list):
        print(
            f"osv_npm.json top level must be a list, got {type(data).__name__}",
            file=sys.stderr,
        )
        return 1

    print(f"OK: {len(data)} advisories, {size} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
