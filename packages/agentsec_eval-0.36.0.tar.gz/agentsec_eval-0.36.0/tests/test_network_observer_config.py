import pytest
from pydantic import ValidationError

from agentsec.observability.network_observer import (
    FixtureOnlyObserver,
    NetworkObserverConfig,
    domain_matches_pattern,
    target_is_controlled,
)


def test_default_mode_is_fixture_only_with_no_domains():
    c = NetworkObserverConfig()
    assert c.mode == "fixture_only"
    assert c.controlled_domains == []
    assert c.proxy_url == ""


def test_unknown_mode_rejected():
    with pytest.raises(ValidationError):
        NetworkObserverConfig(mode="weird")


@pytest.mark.parametrize("pattern,host,expected", [
    ("*.agentsec.test", "exfil.agentsec.test", True),
    ("*.agentsec.test", "deep.exfil.agentsec.test", True),
    ("*.agentsec.test", "agentsec.test", False),  # bare apex not matched
    ("*.agentsec.test", "agentsec.example", False),
    ("exact.agentsec.test", "exact.agentsec.test", True),
    ("exact.agentsec.test", "x.exact.agentsec.test", False),
    # Port suffix in host is stripped before matching (Host header carries port)
    ("*.agentsec.test", "exfil.agentsec.test:8080", True),
    ("metrics.local", "metrics.local:9000", True),
])
def test_domain_matches_pattern(pattern, host, expected):
    assert domain_matches_pattern(pattern, host) is expected


def test_target_is_controlled_uses_pattern_set():
    c = NetworkObserverConfig(controlled_domains=["*.agentsec.test", "metrics.local"])
    assert target_is_controlled("exfil.agentsec.test", c) is True
    assert target_is_controlled("metrics.local", c) is True
    assert target_is_controlled("attacker.example.com", c) is False


def test_target_is_controlled_with_empty_domains_rejects_all():
    c = NetworkObserverConfig(controlled_domains=[])
    assert target_is_controlled("anything.example.com", c) is False
    assert target_is_controlled("", c) is False


def test_fixture_only_observer_records_and_resets():
    obs = FixtureOnlyObserver()
    assert obs.fixture_events() == []
    obs.record(method="GET", path="/x", remote_addr="127.0.0.1",
               headers={"host": "fixture.local:1"})
    events = obs.fixture_events()
    assert len(events) == 1
    assert events[0].method == "GET" and events[0].path == "/x"
    outbound = obs.outbound_requests()
    assert len(outbound) == 1
    assert outbound[0].target_host == "fixture.local:1"
    assert outbound[0].url == "http://fixture.local:1/x"
    obs.reset()
    assert obs.fixture_events() == []


def test_fixture_only_observer_lowercases_header_keys():
    """record() normalises header keys so caller doesn't have to."""
    obs = FixtureOnlyObserver()
    obs.record(method="GET", path="/y", remote_addr="127.0.0.1",
               headers={"Host": "FIXTURE.LOCAL:1", "X-Trace": "1"})
    events = obs.fixture_events()
    assert "host" in events[0].headers
    assert "x-trace" in events[0].headers
    # Host header value is preserved as-is (only key is normalised).
    assert events[0].headers["host"] == "FIXTURE.LOCAL:1"
