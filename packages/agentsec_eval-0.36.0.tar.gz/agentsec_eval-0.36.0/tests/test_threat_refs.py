"""CI guard: every TI-* reference in docs/test_suites/src must resolve in threat_intel.yaml."""

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / "scripts" / "check_threat_refs.py"


def _run(cwd: Path | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(SCRIPT)],
        cwd=cwd or REPO_ROOT,
        capture_output=True,
        text=True,
    )


def test_repo_threat_refs_all_resolve():
    result = _run()
    assert result.returncode == 0, f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"


def test_unknown_ref_fails(tmp_path: Path):
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "bad.md").write_text("references TI-DOES-NOT-EXIST-9999\n")
    yaml_path = tmp_path / "src" / "agentsec" / "audit" / "ioc" / "threat_intel.yaml"
    yaml_path.parent.mkdir(parents=True)
    yaml_path.write_text(
        "- id: TI-OPENCLAW-CVE-2026-25253\n"
        "  source: x\n"
        "  url: https://example/\n"
        "  observed_at: 2026-04-25\n"
        "  claim: y\n"
        "  confidence: high\n"
    )
    result = _run(cwd=tmp_path)
    assert result.returncode != 0
    assert "TI-DOES-NOT-EXIST-9999" in result.stdout + result.stderr


def test_missing_required_field_fails(tmp_path: Path):
    yaml_path = tmp_path / "src" / "agentsec" / "audit" / "ioc" / "threat_intel.yaml"
    yaml_path.parent.mkdir(parents=True)
    # Missing `claim`
    yaml_path.write_text(
        "- id: TI-FOO\n"
        "  source: x\n"
        "  url: https://example/\n"
        "  observed_at: 2026-04-25\n"
        "  confidence: high\n"
    )
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "x.md").write_text("see TI-FOO\n")
    result = _run(cwd=tmp_path)
    assert result.returncode != 0
    assert "claim" in (result.stdout + result.stderr).lower()


# ---------------------------------------------------------------------------
# Bidirectional case ↔ TI consistency (PR #18-#24 follow-up)
# ---------------------------------------------------------------------------

_VALID_TI_ENTRY = (
    "  source: nvd\n"
    "  url: https://example/\n"
    "  observed_at: 2026-04-25\n"
    "  claim: y\n"
    "  confidence: high\n"
)


def _bootstrap_layout(tmp_path: Path, intel_yaml: str, suites: dict[str, str]) -> None:
    """Write a minimal repo layout: threat_intel.yaml + test_suites/*.yaml."""
    yaml_path = tmp_path / "src" / "agentsec" / "audit" / "ioc" / "threat_intel.yaml"
    yaml_path.parent.mkdir(parents=True)
    yaml_path.write_text(intel_yaml)
    suites_dir = tmp_path / "test_suites"
    suites_dir.mkdir()
    for filename, content in suites.items():
        (suites_dir / filename).write_text(content)


def test_forward_asymmetry_case_lists_ti_but_ti_omits_case(tmp_path: Path):
    """case.threat_refs lists TI but TI.mapped_tests is empty → fail."""
    _bootstrap_layout(
        tmp_path,
        intel_yaml=(
            "- id: TI-OPENCLAW-CVE-2026-99999\n"
            f"{_VALID_TI_ENTRY}"
            "  mapped_tests: []\n"
        ),
        suites={
            "01.yaml": (
                "- id: oc-foo-01\n"
                "  category: x\n"
                "  threat_refs: [TI-OPENCLAW-CVE-2026-99999]\n"
            ),
        },
    )
    result = _run(cwd=tmp_path)
    assert result.returncode != 0
    out = result.stdout + result.stderr
    assert "[asymmetry]" in out
    assert "oc-foo-01" in out and "TI-OPENCLAW-CVE-2026-99999" in out


def test_reverse_asymmetry_ti_lists_case_but_case_omits_ti(tmp_path: Path):
    """TI.mapped_tests lists case but case.threat_refs omits TI → fail."""
    _bootstrap_layout(
        tmp_path,
        intel_yaml=(
            "- id: TI-OPENCLAW-CVE-2026-99998\n"
            f"{_VALID_TI_ENTRY}"
            "  mapped_tests:\n"
            "  - oc-foo-02\n"
        ),
        suites={
            "01.yaml": (
                "- id: oc-foo-02\n"
                "  category: x\n"
                "  threat_refs: []\n"
            ),
        },
    )
    result = _run(cwd=tmp_path)
    assert result.returncode != 0
    out = result.stdout + result.stderr
    assert "[asymmetry]" in out
    assert "oc-foo-02" in out and "TI-OPENCLAW-CVE-2026-99998" in out


def test_orphan_mapped_test_id_fails(tmp_path: Path):
    """TI.mapped_tests names a case that does not exist in any suite → fail."""
    _bootstrap_layout(
        tmp_path,
        intel_yaml=(
            "- id: TI-OPENCLAW-CVE-2026-99997\n"
            f"{_VALID_TI_ENTRY}"
            "  mapped_tests:\n"
            "  - oc-ghost-99\n"
        ),
        suites={"01.yaml": "[]\n"},
    )
    result = _run(cwd=tmp_path)
    assert result.returncode != 0
    out = result.stdout + result.stderr
    assert "[asymmetry-orphan]" in out
    assert "oc-ghost-99" in out


def test_taxonomy_ti_exempted_from_bidirectional(tmp_path: Path):
    """Taxonomy IDs (not matching the CVE shape) are 1-to-many; case may
    reference a taxonomy entry without it listing the case back."""
    _bootstrap_layout(
        tmp_path,
        intel_yaml=(
            "- id: TI-OWASP-LLM-2026-LLM01\n"
            f"{_VALID_TI_ENTRY}"
            "  mapped_tests: []\n"
        ),
        suites={
            "01.yaml": (
                "- id: oc-foo-03\n"
                "  category: x\n"
                "  threat_refs: [TI-OWASP-LLM-2026-LLM01]\n"
            ),
        },
    )
    result = _run(cwd=tmp_path)
    assert result.returncode == 0


def test_symmetric_case_ti_pair_passes(tmp_path: Path):
    _bootstrap_layout(
        tmp_path,
        intel_yaml=(
            "- id: TI-OPENCLAW-CVE-2026-99996\n"
            f"{_VALID_TI_ENTRY}"
            "  mapped_tests:\n"
            "  - oc-foo-04\n"
        ),
        suites={
            "01.yaml": (
                "- id: oc-foo-04\n"
                "  category: x\n"
                "  threat_refs: [TI-OPENCLAW-CVE-2026-99996]\n"
            ),
        },
    )
    result = _run(cwd=tmp_path)
    assert result.returncode == 0
