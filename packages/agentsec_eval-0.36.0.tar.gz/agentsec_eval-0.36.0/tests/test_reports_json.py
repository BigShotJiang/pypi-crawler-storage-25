import json

import yaml

from agentsec.audit.findings import Finding
from agentsec.reports.json_report import (
    write_findings_json,
    write_threat_intel_snapshot,
)


def _f(check: str, sev: str, refs: list[str]) -> Finding:
    return Finding(
        check=check, severity=sev, title="t", description="d",
        evidence={"k": 1}, remediation="r", threat_refs=refs,
    )


def test_write_findings_json_round_trip(tmp_path):
    out = tmp_path / "findings.json"
    findings = [
        _f("c1", "high", ["TI-OPENCLAW-CVE-2026-25253"]),
        _f("c2", "low",  []),
    ]
    write_findings_json(findings, out)
    body = json.loads(out.read_text())
    assert isinstance(body, list)
    assert len(body) == 2
    assert body[0]["check"] == "c1"
    assert body[0]["fingerprint"]
    assert body[0]["threat_refs"] == ["TI-OPENCLAW-CVE-2026-25253"]


def test_write_findings_json_keys_are_sorted(tmp_path):
    out = tmp_path / "findings.json"
    findings = [_f("c1", "high", [])]
    write_findings_json(findings, out)
    text = out.read_text()
    # sorted-keys output: "check" appears before "description"
    check_idx = text.find('"check"')
    desc_idx = text.find('"description"')
    assert check_idx >= 0 and desc_idx > check_idx


def test_write_threat_intel_snapshot_only_referenced_rows(tmp_path):
    ti = tmp_path / "threat_intel.yaml"
    ti.write_text(
        '- id: TI-A\n  source: nvd\n  url: https://x\n'
        '  observed_at: 2026-01-01\n  claim: "a"\n  confidence: high\n'
        '  mapped_tests: []\n'
        '- id: TI-B\n  source: nvd\n  url: https://y\n'
        '  observed_at: 2026-01-02\n  claim: "b"\n  confidence: medium\n'
        '  mapped_tests: []\n'
    )
    out = tmp_path / "snap.yaml"
    write_threat_intel_snapshot({"TI-A"}, ti, out)
    body = yaml.safe_load(out.read_text())
    assert isinstance(body, list)
    assert len(body) == 1
    assert body[0]["id"] == "TI-A"


def test_write_threat_intel_snapshot_empty_refs_writes_empty_list(tmp_path):
    ti = tmp_path / "threat_intel.yaml"
    ti.write_text(
        '- id: TI-A\n  source: nvd\n  url: https://x\n'
        '  observed_at: 2026-01-01\n  claim: "a"\n  confidence: high\n'
        '  mapped_tests: []\n'
    )
    out = tmp_path / "snap.yaml"
    write_threat_intel_snapshot(set(), ti, out)
    body = yaml.safe_load(out.read_text())
    assert body == []


def test_write_threat_intel_snapshot_unknown_ref_is_silently_skipped(tmp_path):
    """A finding can reference a TI id that no longer exists in the source
    table (e.g. removed during cleanup). The snapshot writer should not
    crash — the run still succeeded; the operator sees the missing id in the
    finding's `threat_refs` and the audit log."""
    ti = tmp_path / "threat_intel.yaml"
    ti.write_text(
        '- id: TI-A\n  source: nvd\n  url: https://x\n'
        '  observed_at: 2026-01-01\n  claim: "a"\n  confidence: high\n'
        '  mapped_tests: []\n'
    )
    out = tmp_path / "snap.yaml"
    write_threat_intel_snapshot({"TI-A", "TI-DOES-NOT-EXIST"}, ti, out)
    body = yaml.safe_load(out.read_text())
    assert {row["id"] for row in body} == {"TI-A"}
