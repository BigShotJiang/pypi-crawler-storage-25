"""detect_docker helper 测试。"""

from __future__ import annotations

from pathlib import Path

import pytest

from agentsec.audit.checks._docker_common import (
    _docker_takeover_active,
    _evaluate_image_tag,
    _evaluate_inspect,
    _parse_ctr_info,
    detect_containerd_bin,
    detect_containerd_runtime,
    detect_ctr,
    detect_docker,
    detect_nerdctl,
    detect_podman,
)
from agentsec.audit.checks.base import CheckContext
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult

_FIXTURES_CONTAINER = Path(__file__).parent / "fixtures" / "container"


class _StubExecutor:
    def __init__(self, found_path: str | None):
        self._found_path = found_path

    def run(self, argv, *, role=None):
        argv = list(argv)
        # detect_docker 调用 stat -c %n <path>；返回路径即"找到"
        if argv[:3] == ["stat", "-c", "%n"] and argv[3] == self._found_path:
            return RunResult(
                stdout=self._found_path + "\n", stderr="", exit_code=0,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            )
        return RunResult(
            stdout="", stderr="No such file", exit_code=1,
            rejected=False, reject_reason=None, argv=argv,
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        )


class _AllRejectedExecutor:
    def run(self, argv, *, role=None):
        return RunResult(
            stdout="", stderr="", exit_code=0,
            rejected=True, reject_reason="policy",
            argv=list(argv), command_sha256="0" * 64,
            duration_ms=0.0, bytes_out=0,
        )


class _MultiPathStubExecutor:
    """Returns exit_code=0 for `stat -c %n <path>` if path ∈ paths; else exit 1."""

    def __init__(self, paths: tuple[str, ...]):
        self._paths = set(paths)

    def run(self, argv, *, role=None):
        argv = list(argv)
        if argv[:3] == ["stat", "-c", "%n"] and argv[3] in self._paths:
            return RunResult(
                stdout=argv[3] + "\n", stderr="", exit_code=0,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            )
        return RunResult(
            stdout="", stderr="No such file", exit_code=1,
            rejected=False, reject_reason=None, argv=argv,
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        )


def _ctx(executor):
    profile = materialize_paths(LINUX, "/home/u")
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=None, profile=profile, log_review_config=None,
    )


def test_detect_docker_finds_usr_bin():
    ctx = _ctx(_StubExecutor("/usr/bin/docker"))
    assert detect_docker(ctx) == "/usr/bin/docker"


def test_detect_docker_finds_homebrew():
    ctx = _ctx(_StubExecutor("/opt/homebrew/bin/docker"))
    assert detect_docker(ctx) == "/opt/homebrew/bin/docker"


def test_detect_docker_finds_usr_local():
    ctx = _ctx(_StubExecutor("/usr/local/bin/docker"))
    assert detect_docker(ctx) == "/usr/local/bin/docker"


def test_detect_docker_returns_none_when_absent():
    ctx = _ctx(_StubExecutor(None))
    assert detect_docker(ctx) is None


def test_detect_docker_returns_none_when_stat_rejected():
    """If CommandPolicy rejects every stat call, detect_docker returns None
    (not the rejected path). Covers the `not result.rejected` branch."""
    ctx = _ctx(_AllRejectedExecutor())
    assert detect_docker(ctx) is None


# ---- detect_podman ----

def test_detect_podman_finds_usr_bin():
    assert detect_podman(_ctx(_StubExecutor("/usr/bin/podman"))) == "/usr/bin/podman"


def test_detect_podman_finds_usr_local_bin():
    assert detect_podman(_ctx(_StubExecutor("/usr/local/bin/podman"))) == "/usr/local/bin/podman"


def test_detect_podman_returns_none_when_absent():
    assert detect_podman(_ctx(_StubExecutor(None))) is None


def test_detect_podman_returns_none_when_all_rejected():
    assert detect_podman(_ctx(_AllRejectedExecutor())) is None


# ---- detect_nerdctl ----

def test_detect_nerdctl_finds_usr_local_bin():
    assert detect_nerdctl(_ctx(_StubExecutor("/usr/local/bin/nerdctl"))) == "/usr/local/bin/nerdctl"


def test_detect_nerdctl_returns_none_when_absent():
    assert detect_nerdctl(_ctx(_StubExecutor(None))) is None


# ---- detect_ctr ----

def test_detect_ctr_finds_usr_bin():
    assert detect_ctr(_ctx(_StubExecutor("/usr/bin/ctr"))) == "/usr/bin/ctr"


def test_detect_ctr_returns_none_when_absent():
    assert detect_ctr(_ctx(_StubExecutor(None))) is None


# ---- detect_containerd_bin ----

def test_detect_containerd_bin_usr_bin_first():
    executor = _MultiPathStubExecutor(("/usr/bin/containerd",))
    ctx = CheckContext(
        executor=executor, redactor=None, ioc_dir=None,
        profile=materialize_paths(LINUX, "/home/u"),
    )
    assert detect_containerd_bin(ctx) == "/usr/bin/containerd"


def test_detect_containerd_bin_usr_local_bin_fallback():
    executor = _MultiPathStubExecutor(("/usr/local/bin/containerd",))
    ctx = CheckContext(
        executor=executor, redactor=None, ioc_dir=None,
        profile=materialize_paths(LINUX, "/home/u"),
    )
    assert detect_containerd_bin(ctx) == "/usr/local/bin/containerd"


def test_detect_containerd_bin_none_when_missing():
    executor = _MultiPathStubExecutor(())
    ctx = CheckContext(
        executor=executor, redactor=None, ioc_dir=None,
        profile=materialize_paths(LINUX, "/home/u"),
    )
    assert detect_containerd_bin(ctx) is None


# ---- detect_containerd_runtime ----

def test_detect_containerd_runtime_prefers_nerdctl():
    """When both nerdctl and ctr are present + containerd.sock exists,
    return ("path-to-nerdctl", "nerdctl")."""
    paths = (
        "/usr/local/bin/nerdctl",
        "/usr/bin/ctr",
        "/run/containerd/containerd.sock",
    )
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == ("/usr/local/bin/nerdctl", "nerdctl")


def test_detect_containerd_runtime_falls_back_ctr():
    """nerdctl absent, ctr + socket present → ("path-to-ctr", "ctr")."""
    paths = ("/usr/bin/ctr", "/run/containerd/containerd.sock")
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == ("/usr/bin/ctr", "ctr")


def test_detect_containerd_runtime_none_when_socket_absent():
    """nerdctl present but socket absent → (None, None)."""
    paths = ("/usr/local/bin/nerdctl",)
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == (None, None)


def test_detect_containerd_runtime_none_when_no_frontend():
    """Socket present but no nerdctl/ctr → (None, None)."""
    paths = ("/run/containerd/containerd.sock",)
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == (None, None)


# ---- _evaluate_inspect ----

_RUNTIME_RULES_FIXTURE = [
    {
        "id": "runtime-privileged",
        "severity": "critical",
        "title": "容器以 --privileged 运行",
        "description": "privileged 容器…",
        "remediation": "移除 --privileged",
        "threat_refs_template": "{prefix}-RUNTIME-PRIVILEGED",
    },
    {
        "id": "runtime-host-net",
        "severity": "high",
        "title": "容器使用 host network",
        "description": "NetworkMode=host…",
        "remediation": "使用 bridge",
        "threat_refs_template": "{prefix}-RUNTIME-HOST-NET",
    },
    {
        "id": "runtime-root-user",
        "severity": "medium",
        "title": "容器以 root 用户运行",
        "description": "Config.User 为 root…",
        "remediation": "显式 USER 1000:1000",
        "threat_refs_template": "{prefix}-RUNTIME-ROOT-USER",
    },
]


def test_evaluate_inspect_privileged_emits_finding():
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "1000:1000"},
        "HostConfig": {"Privileged": True, "NetworkMode": "bridge",
                       "Binds": [], "CapAdd": None,
                       "SecurityOpt": ["no-new-privileges:true"]},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="podman", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    privileged = [f for f in findings if f["evidence"].get("rule_id") == "runtime-privileged"]
    assert len(privileged) == 1
    assert privileged[0]["severity"] == "critical"
    assert privileged[0]["evidence"]["runtime"] == "podman"
    assert privileged[0]["threat_refs"] == ["TI-PODMAN-RUNTIME-PRIVILEGED"]


def test_evaluate_inspect_host_net_emits_finding():
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "1000:1000"},
        "HostConfig": {"Privileged": False, "NetworkMode": "host",
                       "Binds": [], "CapAdd": None, "SecurityOpt": []},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="containerd", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    host_net = [f for f in findings if f["evidence"].get("rule_id") == "runtime-host-net"]
    assert len(host_net) == 1
    assert host_net[0]["evidence"]["runtime"] == "containerd"
    assert host_net[0]["threat_refs"] == ["TI-CONTAINERD-RUNTIME-HOST-NET"]


def test_evaluate_inspect_rootless_root_user_downgrade():
    """Container running as root, but podman info says rootless=true →
    severity downgrade medium → low."""
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "root"},
        "HostConfig": {"Privileged": False, "NetworkMode": "bridge",
                       "Binds": [], "CapAdd": None, "SecurityOpt": []},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="podman", rootless=True,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    root_user = [f for f in findings if f["evidence"].get("rule_id") == "runtime-root-user"]
    assert len(root_user) == 1
    assert root_user[0]["severity"] == "low"


def test_evaluate_inspect_compliant_zero_findings():
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "1000:1000"},
        "HostConfig": {"Privileged": False, "NetworkMode": "bridge",
                       "Binds": [], "CapAdd": None,
                       "SecurityOpt": ["no-new-privileges:true"]},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="podman", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    assert findings == []


# ---- _evaluate_image_tag ----

_IMAGE_PATTERNS_FIXTURE = [
    {
        "pattern": "*:latest",
        "severity": "medium",
        "title": "镜像未固定版本",
        "description": ":latest 不可重复",
        "remediation": "锁定 sha256 digest",
        "threat_refs_template": "{prefix}-IMAGE-LATEST",
    },
    {
        "pattern": "python:2.*",
        "severity": "high",
        "title": "Python 2 镜像（EOL）",
        "description": "Python 2 EOL",
        "remediation": "升级 python:3.11",
        "threat_refs_template": "{prefix}-IMAGE-PYTHON2-EOL",
    },
]


def test_evaluate_image_tag_match_latest():
    findings = _evaluate_image_tag(
        repo="nginx", tag="latest",
        runtime="podman",
        baseline_image_patterns=_IMAGE_PATTERNS_FIXTURE,
    )
    assert len(findings) == 1
    assert findings[0]["evidence"]["runtime"] == "podman"
    # image_patterns TIs are SHARED across runtimes per spec §4.2; use TI-CONTAINER
    assert findings[0]["threat_refs"] == ["TI-CONTAINER-IMAGE-LATEST"]


def test_evaluate_image_tag_match_python2():
    findings = _evaluate_image_tag(
        repo="python", tag="2.7",
        runtime="containerd",
        baseline_image_patterns=_IMAGE_PATTERNS_FIXTURE,
    )
    assert len(findings) == 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["evidence"]["runtime"] == "containerd"
    assert findings[0]["threat_refs"] == ["TI-CONTAINER-IMAGE-PYTHON2-EOL"]


def test_evaluate_image_tag_no_match():
    findings = _evaluate_image_tag(
        repo="nginx", tag="1.25.4",
        runtime="podman",
        baseline_image_patterns=_IMAGE_PATTERNS_FIXTURE,
    )
    assert findings == []


# ---- _parse_ctr_info ----

def test_parse_ctr_info_privileged():
    text = (_FIXTURES_CONTAINER / "containerd_ctr_info_privileged.txt").read_text()
    parsed = _parse_ctr_info(text)
    assert parsed["root_user_uid"] == 0
    assert "CAP_SYS_ADMIN" in parsed["capabilities"]
    assert "CAP_NET_ADMIN" in parsed["capabilities"]
    assert parsed["privileged"] is True  # All 3 dangerous caps present
    assert parsed["host_network"] is True  # network namespace path set


def test_parse_ctr_info_clean():
    text = (_FIXTURES_CONTAINER / "containerd_ctr_info_clean.txt").read_text()
    parsed = _parse_ctr_info(text)
    assert parsed["root_user_uid"] == 1000
    assert parsed["capabilities"] == []
    assert parsed["privileged"] is False
    assert parsed["host_network"] is False


def test_parse_ctr_info_malformed_raises():
    with pytest.raises(ValueError):
        _parse_ctr_info("{not valid json")


# ---- _evaluate_inspect edge-case regression tests (Phase 7f.1 final review) ----

def test_evaluate_inspect_user_null_no_crash():
    """Config.User: null (common when no USER directive) must not crash.
    The user is treated as empty → counts as root-ish for the root-user rule."""
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": None},
        "HostConfig": {"Privileged": False, "NetworkMode": "bridge",
                       "Binds": [], "CapAdd": None, "SecurityOpt": []},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="podman", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    # User=None → user="" → root-user rule fires
    root_user = [f for f in findings if f["evidence"].get("rule_id") == "runtime-root-user"]
    assert len(root_user) == 1


def test_evaluate_inspect_empty_list_returns_empty():
    """Empty inspect list (container removal race) must not crash."""
    findings = _evaluate_inspect(
        [], runtime="podman", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    assert findings == []


# ---- _docker_takeover_active ----

def test_docker_takeover_active_when_docker_and_socket_present():
    """detect_docker hits + /var/run/docker.sock exists → True."""
    ctx_executor = _MultiPathStubExecutor((
        "/usr/bin/docker",
        "/var/run/docker.sock",
    ))
    ctx = CheckContext(
        executor=ctx_executor, redactor=None, ioc_dir=None,
        profile=materialize_paths(LINUX, "/home/u"),
    )
    assert _docker_takeover_active(ctx) is True


def test_docker_takeover_active_false_when_docker_missing():
    """No docker binary → False (regardless of socket)."""
    ctx_executor = _MultiPathStubExecutor(("/var/run/docker.sock",))
    ctx = CheckContext(
        executor=ctx_executor, redactor=None, ioc_dir=None,
        profile=materialize_paths(LINUX, "/home/u"),
    )
    assert _docker_takeover_active(ctx) is False


def test_docker_takeover_active_false_when_socket_missing():
    """docker binary present but no /var/run/docker.sock → False."""
    ctx_executor = _MultiPathStubExecutor(("/usr/bin/docker",))
    ctx = CheckContext(
        executor=ctx_executor, redactor=None, ioc_dir=None,
        profile=materialize_paths(LINUX, "/home/u"),
    )
    assert _docker_takeover_active(ctx) is False
