"""3-axis combined_score (Phase 7c.6) — verifies backward compat + new axis."""

from agentsec.scoring import CombinedScore, combined_score


def test_two_axis_legacy_signature_still_works():
    """Old (remote, server) callers must keep identical numeric behavior."""
    c = combined_score(remote=80.0, server=60.0, w_r=0.5, w_s=0.5)
    assert c.score == 70.0
    assert c.weight_remote_used == 0.5
    assert c.weight_server_used == 0.5
    assert c.weight_mcp_used == 0.0


def test_three_axis_all_present():
    c = combined_score(
        remote=80.0, server=60.0, mcp=90.0,
        w_r=0.4, w_s=0.4, w_m=0.2,
    )
    # (80*0.4 + 60*0.4 + 90*0.2) / (0.4+0.4+0.2) = 74.0
    assert c.score == 74.0
    assert c.weight_mcp_used == 0.2


def test_mcp_none_with_nonzero_weight_renormalizes():
    """mcp=None drops that axis; remote+server reweighted to 1.0."""
    c = combined_score(
        remote=80.0, server=60.0, mcp=None,
        w_r=0.4, w_s=0.4, w_m=0.2,
    )
    # (80*0.4 + 60*0.4) / 0.8 = 70.0
    assert c.score == 70.0
    assert c.weight_mcp_used == 0.0


def test_mcp_score_present_but_weight_zero():
    """mcp scored but operator opted out via w_m=0 → mcp not in score."""
    c = combined_score(
        remote=80.0, server=60.0, mcp=10.0,
        w_r=0.5, w_s=0.5, w_m=0.0,
    )
    assert c.score == 70.0
    assert c.weight_mcp_used == 0.0


def test_all_none_returns_score_none():
    c = combined_score(remote=None, server=None, mcp=None)
    assert c.score is None
    assert c.weight_mcp_used == 0.0
    assert c.note is not None


def test_combined_score_model_has_weight_mcp_used():
    """Sanity check the model field exists."""
    assert "weight_mcp_used" in CombinedScore.model_fields
