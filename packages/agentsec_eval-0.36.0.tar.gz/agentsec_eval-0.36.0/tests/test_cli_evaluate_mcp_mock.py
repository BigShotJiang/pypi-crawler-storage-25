"""agentsec evaluate produces mcp-findings.json + mcp-real-report.md when
mcp_real is configured (Phase 7c.6)."""

import json
from pathlib import Path

from typer.testing import CliRunner

from agentsec.cli import app

_SUITE_YAML = """
- id: t-01
  category: mcp_real_tools
  description: stub
  user_prompt: hi
  mcp_server:
    name: s
    tools:
      - {name: t, description: d, input_schema: {type: object}, result: ok}
  expected_behavior: refusal
  severity: high
  judge_type: llm
  owasp_refs: [MCP1]
  judge_hint: "Pass if. Fail if."
"""


def _make_config(tmp_path: Path, suite_path: Path, out_dir: Path) -> Path:
    yaml = f"""
name: t
mcp_real:
  suite: {suite_path}
output:
  dir: {out_dir}
"""
    cfg = tmp_path / "config.yaml"
    cfg.write_text(yaml)
    return cfg


def test_evaluate_with_mcp_real_only(tmp_path: Path, monkeypatch):
    suite = tmp_path / "suite.yaml"
    suite.write_text(_SUITE_YAML)
    out = tmp_path / "report"
    cfg_path = _make_config(tmp_path, suite, out)

    import agentsec.mcp_harness as harness_pkg
    from agentsec.adapters.base import AgentResponse
    from agentsec.mcp_harness import adapter as adapter_mod

    class _Stub:
        name = "stub"
        def __init__(self, **_): pass
        async def send(self, message, session_id):  # noqa: ARG002
            return AgentResponse(content="ok")
        async def reset(self, session_id):  # noqa: ARG002
            pass
    monkeypatch.setattr(adapter_mod, "ClaudeMcpAdapter", _Stub)
    monkeypatch.setattr(harness_pkg, "ClaudeMcpAdapter", _Stub)

    from agentsec.evaluator import base as jb
    from agentsec.evaluator import judge as judge_mod

    class _PassJudge(jb.Judge):
        async def evaluate(self, test_case, observation):
            return jb.JudgeVerdict(
                passed=True, reasoning="ok",
                evidence={"raw": ""}, judge_type="llm",
            )
    monkeypatch.setattr(judge_mod, "LLMJudge", lambda *a, **kw: _PassJudge())

    monkeypatch.setenv("ANTHROPIC_API_KEY", "fake")

    res = CliRunner().invoke(app, ["evaluate", "--config", str(cfg_path)])
    assert res.exit_code == 0, res.stdout

    # Two new artifacts present
    assert (out / "mcp-real-report.md").exists()
    assert (out / "mcp-findings.json").exists()

    # mcp-findings.json shape
    data = json.loads((out / "mcp-findings.json").read_text())
    assert data["meta"]["total"] == 1
    assert data["meta"]["passed"] == 1
    assert data["findings"][0]["case_id"] == "t-01"
