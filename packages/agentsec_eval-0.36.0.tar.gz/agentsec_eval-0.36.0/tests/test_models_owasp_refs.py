import pytest
from pydantic import ValidationError

from agentsec.tests.models import TestCase
from agentsec.tests.owasp_refs import (
    OWASP_REF_PATTERN,
    validate_owasp_refs,
)


def _minimal_case(**overrides):
    base = dict(
        id="x-1", category="prompt_injection",
        description="d", attack="hello",
        expected_behavior="refusal", severity="low",
    )
    base.update(overrides)
    return TestCase(**base)


def test_pattern_accepts_llm_top10_2025():
    for i in range(1, 11):
        ref = f"LLM{i:02d}:2025"
        assert OWASP_REF_PATTERN.match(ref), ref


def test_pattern_accepts_agentic_t1_through_t17():
    for i in range(1, 18):
        ref = f"AGENTIC-T{i}"
        assert OWASP_REF_PATTERN.match(ref), ref


def test_pattern_rejects_unknown_prefixes_and_typos():
    bad = [
        "LLM5:2025",        # zero-padding required
        "LLM01",            # year suffix required
        "LLM01:2024",       # only 2025 is valid
        "AGENTIC-T18",      # T17 is the last threat in v1.1
        "Agentic-T1",       # case-sensitive
        "MCP",              # MCP requires a numeric suffix
        "owasp-llm-01",     # legacy / wrong scheme
        "",
    ]
    for ref in bad:
        assert not OWASP_REF_PATTERN.match(ref), ref


def test_validator_rejects_duplicates():
    with pytest.raises(ValueError, match="duplicate"):
        validate_owasp_refs(["LLM01:2025", "LLM01:2025"])


def test_validator_returns_input_unchanged_on_success():
    refs = ["LLM06:2025", "AGENTIC-T2"]
    assert validate_owasp_refs(refs) == refs


def test_test_case_default_owasp_refs_empty():
    case = _minimal_case()
    assert case.owasp_refs == []


def test_test_case_accepts_valid_refs():
    case = _minimal_case(owasp_refs=["LLM01:2025", "AGENTIC-T6"])
    assert case.owasp_refs == ["LLM01:2025", "AGENTIC-T6"]


def test_test_case_rejects_invalid_ref():
    with pytest.raises(ValidationError):
        _minimal_case(owasp_refs=["LLM01"])
