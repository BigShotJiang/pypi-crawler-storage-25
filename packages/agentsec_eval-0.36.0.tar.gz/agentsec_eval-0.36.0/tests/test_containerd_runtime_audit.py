"""ContainerdRuntimeAuditCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.containerd_runtime_audit import ContainerdRuntimeAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"

_NERDCTL_BIN = "/usr/local/bin/nerdctl"
_CTR_BIN = "/usr/bin/ctr"
_DOCKER_BIN = "/usr/bin/docker"
_SOCKET = "/run/containerd/containerd.sock"
_DOCKER_SOCKET = "/var/run/docker.sock"

_NERDCTL_PS = ("nerdctl", "ps", "--format", "{{json .}}", "--no-trunc")
_CTR_LIST = ("ctr", "--namespace", "default", "containers", "list", "-q")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False):
    return RunResult(stdout=stdout, stderr=stderr, exit_code=exit_code,
                     rejected=rejected, reject_reason="policy" if rejected else None,
                     argv=[], command_sha256="0"*64, duration_ms=0.0,
                     bytes_out=len(stdout.encode()))


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []

    def run(self, argv, *, role=None):
        self.calls.append(list(argv))
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=list(argv),
                      command_sha256="0"*64, duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_responses(present: tuple[str, ...]) -> dict[tuple, RunResult]:
    """Return stat responses with the given paths marked exit=0, others exit=1."""
    # Cover all paths we probe: docker, podman, nerdctl, ctr, socket
    all_paths = [
        "/usr/bin/docker", "/usr/local/bin/docker", "/opt/homebrew/bin/docker",
        "/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman",
        "/usr/local/bin/nerdctl", "/usr/bin/nerdctl",
        "/usr/bin/ctr", "/usr/local/bin/ctr",
        "/run/containerd/containerd.sock",
        "/var/run/docker.sock",
    ]
    out = {}
    for p in all_paths:
        if p in present:
            out[("stat", "-c", "%n", p)] = _runresult(stdout=p+"\n")
        else:
            out[("stat", "-c", "%n", p)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_not_applicable_no_containerd():
    """No nerdctl, no ctr, no socket → not_applicable."""
    ctx = _ctx(_RecordingExecutor(_stat_responses(present=())))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_docker_takeover_yield():
    """docker + docker.sock active → not_applicable."""
    responses = _stat_responses(present=(
        _DOCKER_BIN, _DOCKER_SOCKET, _NERDCTL_BIN, _SOCKET,
    ))
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "docker" in (ctx.status.not_applicable_reason or "").lower()


def test_nerdctl_mode_compliant():
    inspect = (
        '[{"Id":"k8sabc","Config":{"User":"1000"},"HostConfig":'
        '{"Privileged":false,"NetworkMode":"bridge","Binds":[],'
        '"CapAdd":null,"SecurityOpt":["no-new-privileges:true"]}}]'
    )
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout='{"ID":"k8sabc"}\n')
    responses[("nerdctl", "inspect", "k8sabc")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []


def test_nerdctl_mode_privileged():
    inspect = (_FIXTURES / "containerd_nerdctl_inspect_privileged.json").read_text()
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout='{"ID":"k8sabc"}\n')
    responses[("nerdctl", "inspect", "k8sabc")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    priv = [f for f in findings if f.evidence.get("rule_id") == "runtime-privileged"]
    assert len(priv) == 1
    assert priv[0].evidence["runtime"] == "containerd"


def test_ctr_mode_privileged():
    info = (_FIXTURES / "containerd_ctr_info_privileged.txt").read_text()
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[_CTR_LIST] = _runresult(stdout="ctrabc1234\n")
    _ctr_info_key = ("ctr", "--namespace", "default", "containers", "info", "ctrabc1234")
    responses[_ctr_info_key] = _runresult(stdout=info)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    priv = [f for f in findings if f.evidence.get("rule_id") == "runtime-privileged"]
    assert len(priv) == 1
    assert priv[0].evidence["coverage"] == "partial"
    assert priv[0].evidence["mode"] == "ctr"


def test_ctr_mode_partial_coverage_finding():
    """ctr mode emits a TI-CONTAINERD-COVERAGE-PARTIAL info finding."""
    info = (_FIXTURES / "containerd_ctr_info_clean.txt").read_text()
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[_CTR_LIST] = _runresult(stdout="ctrdef5678\n")
    _ctr_info_key = ("ctr", "--namespace", "default", "containers", "info", "ctrdef5678")
    responses[_ctr_info_key] = _runresult(stdout=info)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    partial = [f for f in findings if "TI-CONTAINERD-COVERAGE-PARTIAL" in f.threat_refs]
    assert len(partial) == 1
    assert partial[0].severity == "info"


def test_ctr_mode_parse_failure_skips_container():
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[_CTR_LIST] = _runresult(stdout="ctrabc1234\n")
    _ctr_info_key = ("ctr", "--namespace", "default", "containers", "info", "ctrabc1234")
    responses[_ctr_info_key] = _runresult(stdout="{malformed")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    # The container is skipped; only the partial-coverage info finding remains
    rule_findings = [f for f in findings if f.evidence.get("rule_id")]
    assert rule_findings == []


def test_ps_empty_no_findings():
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout="")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []


def test_inspect_failure_partial_scan():
    inspect = (_FIXTURES / "containerd_nerdctl_inspect_privileged.json").read_text()
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout='{"ID":"k8sabc"}\n{"ID":"k8sdef"}\n')
    responses[("nerdctl", "inspect", "k8sabc")] = _runresult(stdout=inspect)
    responses[("nerdctl", "inspect", "k8sdef")] = _runresult(
        stderr="No such container", exit_code=1
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    skipped_info = [f for f in findings if f.evidence.get("skipped_container_ids")]
    assert len(skipped_info) == 1
    assert "k8sdef" in skipped_info[0].evidence["skipped_container_ids"]
