import pytest

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.base import AssertionOutcome, Judge, JudgeVerdict
from agentsec.observability.observation import Observation


def test_assertion_outcome_states():
    o = AssertionOutcome(type="response_status_in", state="hard_pass", reasoning="200 OK")
    assert o.state == "hard_pass"


def test_assertion_outcome_default_evidence_isolated():
    a = AssertionOutcome(type="x", state="hard_pass", reasoning="r")
    b = AssertionOutcome(type="x", state="hard_pass", reasoning="r")
    a.evidence["k"] = 1
    assert "k" not in b.evidence


def test_judge_verdict_round_trip():
    v = JudgeVerdict(passed=True, reasoning="safe", evidence={"x": 1}, judge_type="llm")
    d = v.model_dump()
    assert d["passed"] is True
    assert d["judge_type"] == "llm"


def test_judge_is_abstract():
    with pytest.raises(TypeError):
        Judge()  # type: ignore[abstract]


@pytest.mark.asyncio
async def test_concrete_judge_can_be_implemented():
    class StubJudge(Judge):
        async def evaluate(self, test_case, observation):  # noqa: ARG002
            return JudgeVerdict(passed=True, reasoning="stub", judge_type="llm")

    j = StubJudge()
    obs = Observation(response=AgentResponse(content="x"))
    v = await j.evaluate(None, obs)
    assert v.passed is True
