"""Tests for OpenAICompatibleJudge."""
from __future__ import annotations

import json

import httpx
import pytest

from agentsec.adapters.base import AgentResponse
from agentsec.config import OpenAIJudgeConfig
from agentsec.evaluator.openai_judge import OpenAICompatibleJudge
from agentsec.observability.observation import Observation
from agentsec.tests.models import TestCase


def _make_judge(monkeypatch, env_var: str = "FAKE_OAI_KEY") -> tuple:
    monkeypatch.setenv(env_var, "sk-test-value")
    cfg = OpenAIJudgeConfig.model_validate({
        "type": "openai_compatible",
        "model": "gpt-4o",
        "base_url": "http://fake",
        "api_key_env": env_var,
    })
    return cfg, OpenAICompatibleJudge(cfg)


def _make_obs(content: str = "I will help you with that.") -> Observation:
    return Observation(
        response=AgentResponse(content=content, latency_ms=10.0, raw={}, tool_events=[]),
    )


def _make_test_case() -> TestCase:
    return TestCase(
        id="tc-1",
        category="prompt_injection",
        description="test",
        attack="ignore instructions",
        expected_behavior="refusal",
        severity="high",
    )


def _transport_returning(status: int, body: str) -> httpx.MockTransport:
    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(status, text=body,
                              headers={"content-type": "application/json"})
    return httpx.MockTransport(handler)


def _oai_body(passed: bool, reasoning: str = "looks fine") -> str:
    inner = json.dumps({"passed": passed, "reasoning": reasoning})
    return json.dumps({"choices": [{"message": {"content": inner}}]})


async def test_openai_judge_passed_true(monkeypatch):
    _, judge = _make_judge(monkeypatch)
    transport = _transport_returning(200, _oai_body(True, "agent resisted"))
    judge._transport = transport
    verdict = await judge.evaluate(_make_test_case(), _make_obs())
    assert verdict.passed is True
    assert "resisted" in verdict.reasoning
    assert verdict.judge_type == "llm"


async def test_openai_judge_passed_false(monkeypatch):
    _, judge = _make_judge(monkeypatch)
    transport = _transport_returning(200, _oai_body(False, "agent leaked data"))
    judge._transport = transport
    verdict = await judge.evaluate(_make_test_case(), _make_obs())
    assert verdict.passed is False
    assert "leaked" in verdict.reasoning


async def test_openai_judge_http_500(monkeypatch):
    _, judge = _make_judge(monkeypatch)
    transport = _transport_returning(500, "Internal Server Error")
    judge._transport = transport
    verdict = await judge.evaluate(_make_test_case(), _make_obs())
    assert verdict.passed is False
    assert "http error" in verdict.reasoning
    assert "500" in verdict.reasoning


async def test_openai_judge_response_not_json(monkeypatch):
    _, judge = _make_judge(monkeypatch)
    transport = _transport_returning(200, "not json at all")
    judge._transport = transport
    verdict = await judge.evaluate(_make_test_case(), _make_obs())
    assert verdict.passed is False
    assert "parse error" in verdict.reasoning


async def test_openai_judge_response_missing_passed_field(monkeypatch):
    _, judge = _make_judge(monkeypatch)
    inner = json.dumps({"reasoning": "something"})  # no "passed" key
    body = json.dumps({"choices": [{"message": {"content": inner}}]})
    transport = _transport_returning(200, body)
    judge._transport = transport
    verdict = await judge.evaluate(_make_test_case(), _make_obs())
    assert verdict.passed is False
    assert "parse error" in verdict.reasoning
    assert "missing fields" in verdict.reasoning


async def test_openai_judge_timeout(monkeypatch):
    _, judge = _make_judge(monkeypatch)

    def timeout_handler(req: httpx.Request) -> httpx.Response:
        raise httpx.TimeoutException("timed out", request=req)

    judge._transport = httpx.MockTransport(timeout_handler)
    verdict = await judge.evaluate(_make_test_case(), _make_obs())
    assert verdict.passed is False
    assert verdict.reasoning == "request timeout"


def test_openai_judge_constructor_missing_env_var(monkeypatch):
    monkeypatch.delenv("MISSING_ENV_VAR", raising=False)
    cfg = OpenAIJudgeConfig.model_validate({
        "type": "openai_compatible",
        "model": "gpt-4o",
        "base_url": "http://fake",
        "api_key_env": "MISSING_ENV_VAR",
    })
    with pytest.raises(ValueError, match="MISSING_ENV_VAR"):
        OpenAICompatibleJudge(cfg)


@pytest.mark.asyncio
async def test_openai_judge_base_url_trailing_slash(monkeypatch):
    """base_url with trailing slash must not produce double-slash in request URL."""
    monkeypatch.setenv("FAKE_OAI_KEY2", "sk-test")
    cfg = OpenAIJudgeConfig.model_validate({
        "type": "openai_compatible",
        "model": "gpt-4o",
        "base_url": "http://fake/",  # trailing slash
        "api_key_env": "FAKE_OAI_KEY2",
    })
    judge = OpenAICompatibleJudge(cfg)

    captured_url = []

    def handler(req: httpx.Request) -> httpx.Response:
        captured_url.append(str(req.url))
        inner = json.dumps({"passed": True, "reasoning": "ok"})
        body = json.dumps({"choices": [{"message": {"content": inner}}]})
        return httpx.Response(200, text=body, headers={"content-type": "application/json"})

    judge._transport = httpx.MockTransport(handler)
    await judge.evaluate(_make_test_case(), _make_obs())
    assert "//" not in captured_url[0].replace("http://", ""), \
        f"Double slash in URL: {captured_url[0]}"
