from typer.testing import CliRunner

from agentsec.cli import app


def test_uncontrolled_outbound_assertion_rejected_at_load(tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text("""
- id: t1
  category: ipi
  description: d
  attack: a
  expected_behavior: refusal
  severity: high
  assertions:
    - type: outbound_request_not_to
      target: "attacker.example.com"
""")
    runner = CliRunner()
    res = runner.invoke(
        app,
        [
            "run", str(suite),
            "--target", "http://x",
            "--observer-mode", "fixture_only",
            "--controlled-domain", "*.agentsec.test",
        ],
        catch_exceptions=False,
    )
    assert res.exit_code != 0
    assert "attacker.example.com" in res.output


def test_controlled_outbound_assertion_accepted_at_load(monkeypatch, tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text("""
- id: t1
  category: ipi
  description: d
  attack: a
  expected_behavior: refusal
  severity: high
  assertions:
    - type: outbound_request_not_to
      target: "exfil.agentsec.test"
""")

    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["observer_class"] = type(kwargs["observer"]).__name__
        captured["same_host"] = kwargs["evaluator_and_target_same_host"]
        captured["suite_root"] = kwargs["suite_root"]
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        [
            "run", str(suite),
            "--target", "http://x",
            "--observer-mode", "fixture_only",
            "--controlled-domain", "*.agentsec.test",
            "--same-host",
        ],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output
    assert captured["observer_class"] == "FixtureOnlyObserver"
    assert captured["same_host"] is True


def test_controlled_domain_option_repeatable(monkeypatch, tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text("""
- id: t1
  category: ipi
  description: d
  attack: a
  expected_behavior: refusal
  severity: high
  assertions:
    - type: outbound_request_not_to
      target: "metrics.local"
    - type: outbound_request_not_to
      target: "exfil.agentsec.test"
""")

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        [
            "run", str(suite),
            "--target", "http://x",
            "--controlled-domain", "*.agentsec.test",
            "--controlled-domain", "metrics.local",
        ],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output


def test_default_observer_mode_is_fixture_only(monkeypatch, tmp_path):
    """No --observer-mode given: default is fixture_only."""
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: t1\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )

    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["observer_class"] = type(kwargs["observer"]).__name__
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x"],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output
    assert captured["observer_class"] == "FixtureOnlyObserver"
