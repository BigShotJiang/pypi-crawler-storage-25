"""Unit tests for ServerAuditConfig.gem_lock_paths validator (Phase 7d.5)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentsec.config import ServerAuditConfig


def _config(**overrides) -> dict:
    """Minimal valid ServerAuditConfig dict."""
    return {
        "host": "test.example",
        "user": "ubuntu",
        "key": "/home/ubuntu/.ssh/id_rsa",
        **overrides,
    }


def test_empty_gem_lock_paths_is_valid() -> None:
    cfg = ServerAuditConfig.model_validate(_config())
    assert cfg.gem_lock_paths == []


def test_accepts_valid_gemfile_lock_path() -> None:
    cfg = ServerAuditConfig.model_validate(_config(
        gem_lock_paths=[
            "/opt/myapp/Gemfile.lock",
            "~/projects/rails-app/Gemfile.lock",
        ]
    ))
    assert len(cfg.gem_lock_paths) == 2


def test_rejects_relative_path() -> None:
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["Gemfile.lock"]
        ))


def test_rejects_shell_metachar() -> None:
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/app;rm/Gemfile.lock"]
        ))


def test_rejects_non_canonical_basename() -> None:
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/myapp/gemfile.lock"]  # lowercase wrong
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/myapp/Gemfile"]  # missing .lock
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/myapp/Gemfile.lock.bak"]  # suffix wrong
        ))
