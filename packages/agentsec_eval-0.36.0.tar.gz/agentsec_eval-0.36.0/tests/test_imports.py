"""Guard against the agentsec.tests.models ↔ agentsec.evaluator.judge cycle.

Each import below was at one point broken by a different ordering of package
loads. Running them as standalone subprocesses catches regressions even when
sys.modules is warm from another test file.
"""

import subprocess
import sys


def _import_in_subprocess(stmt: str) -> None:
    res = subprocess.run(
        [sys.executable, "-c", stmt],
        capture_output=True,
        text=True,
        check=False,
    )
    assert res.returncode == 0, f"{stmt!r} failed:\nstdout={res.stdout}\nstderr={res.stderr}"


def test_runtime_imports_cleanly():
    _import_in_subprocess("from agentsec.observability.runtime import FixtureRuntime")


def test_loader_imports_cleanly():
    _import_in_subprocess("from agentsec.tests.loader import load_test_suite")


def test_models_import_cleanly():
    _import_in_subprocess("from agentsec.tests.models import Fixture, TestCase")


def test_judge_still_reachable_via_lazy_init():
    _import_in_subprocess(
        "from agentsec.evaluator import LLMJudge; assert LLMJudge.__name__ == 'LLMJudge'"
    )
