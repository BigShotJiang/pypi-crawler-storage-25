"""Unit tests for _evaluate_one_target exception handling."""

from pathlib import Path

from agentsec.reports.multi_summary import TargetResult


def test_evaluate_one_target_converts_runtime_error_to_target_result_error(
    tmp_path, monkeypatch
):
    """_evaluate_one_target must never raise — RuntimeError becomes TargetResult.error."""
    import agentsec.cli as cli_mod

    def _boom(cfg, api_key, out):
        raise RuntimeError("network timeout")

    monkeypatch.setattr(cli_mod, "_evaluate_remote", _boom)

    from agentsec.config import (
        AuthorizationConfig,
        OpenClawTargetConfig,
        OutputConfig,
        RemoteConfig,
        ScoringConfig,
    )

    cfg = OpenClawTargetConfig(
        name="test-target",
        remote=RemoteConfig(adapter="http", target="http://x", test_suites=[]),
        output=OutputConfig(dir=tmp_path / "out"),
        authorization=AuthorizationConfig(consent_file=Path("./AUTHORIZATION.txt")),
        scoring=ScoringConfig(),
    )
    result = cli_mod._evaluate_one_target(cfg, api_key=None, output_base=tmp_path)
    assert isinstance(result, TargetResult)
    assert result.error == "network timeout"
    assert result.score is None
    assert result.name == "test-target"


def test_evaluate_one_target_converts_typer_exit_to_target_result_error(
    tmp_path, monkeypatch
):
    """_evaluate_one_target must convert typer.Exit to a descriptive error string."""
    import typer

    import agentsec.cli as cli_mod

    def _exit_2(cfg, api_key, out):
        raise typer.Exit(code=2)

    monkeypatch.setattr(cli_mod, "_evaluate_remote", _exit_2)

    from agentsec.config import (
        AuthorizationConfig,
        OpenClawTargetConfig,
        OutputConfig,
        RemoteConfig,
        ScoringConfig,
    )

    cfg = OpenClawTargetConfig(
        name="exit-target",
        remote=RemoteConfig(adapter="http", target="http://x", test_suites=[]),
        output=OutputConfig(dir=tmp_path / "out"),
        authorization=AuthorizationConfig(consent_file=Path("./AUTHORIZATION.txt")),
        scoring=ScoringConfig(),
    )
    result = cli_mod._evaluate_one_target(cfg, api_key=None, output_base=tmp_path)
    assert isinstance(result, TargetResult)
    assert result.error is not None
    assert "2" in result.error  # exit code preserved in message
    assert result.score is None
