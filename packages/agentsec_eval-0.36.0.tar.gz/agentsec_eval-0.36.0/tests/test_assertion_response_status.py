"""response_status_in — hard_fail when AgentResponse.status_code is outside the
allowed set; hard_pass otherwise. Inconclusive when the adapter never reported a
status (e.g. transport error or non-HTTP adapter)."""

import pytest
from pydantic import ValidationError

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.assertions.response_status_in import ResponseStatusIn
from agentsec.observability.observation import Observation


def _obs(status: int | None) -> Observation:
    return Observation(response=AgentResponse(content="", status_code=status))


def test_status_in_set_is_hard_pass():
    a = ResponseStatusIn(statuses=[401, 403])
    out = a.evaluate(_obs(401))
    assert out.state == "hard_pass"


def test_status_outside_set_is_hard_fail():
    a = ResponseStatusIn(statuses=[401, 403])
    out = a.evaluate(_obs(200))
    assert out.state == "hard_fail"
    assert out.evidence["actual"] == 200


def test_missing_status_is_inconclusive():
    a = ResponseStatusIn(statuses=[401, 403])
    out = a.evaluate(_obs(None))
    assert out.state == "inconclusive"


def test_empty_statuses_rejected():
    with pytest.raises(ValidationError):
        ResponseStatusIn(statuses=[])
