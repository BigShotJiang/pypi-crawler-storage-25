"""container_baseline.yaml schema 校验。"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

_BASELINE = (
    Path(__file__).resolve().parents[1]
    / "src" / "agentsec" / "audit" / "checks" / "container_baseline.yaml"
)


def _load():
    return yaml.safe_load(_BASELINE.read_text())


def test_baseline_has_three_sections():
    data = _load()
    assert {"daemon", "runtime", "image_patterns"} <= set(data.keys())
    # daemon_podman added in Phase 7f.1; daemon_containerd added in Phase 7f.1.1
    allowed = {"daemon", "runtime", "image_patterns", "daemon_podman", "daemon_containerd"}
    assert set(data.keys()) <= allowed


def test_daemon_rules_have_required_fields():
    data = _load()
    for rule in data["daemon"]:
        assert {"id", "severity", "title", "description", "remediation",
                "threat_refs"} <= set(rule.keys())
        assert rule["severity"] in ("critical", "high", "medium", "low", "info")
        assert all(ref.startswith("TI-DOCKER-") for ref in rule["threat_refs"])


def test_runtime_rules_have_required_fields():
    data = _load()
    for rule in data["runtime"]:
        assert {"id", "severity", "title", "description", "remediation",
                "threat_refs"} <= set(rule.keys())
        assert rule["severity"] in ("critical", "high", "medium", "low", "info")
        assert all(ref.startswith("TI-DOCKER-") for ref in rule["threat_refs"])


def test_image_patterns_have_required_fields():
    data = _load()
    assert len(data["image_patterns"]) >= 8
    assert len(data["image_patterns"]) <= 12
    for entry in data["image_patterns"]:
        assert {"pattern", "severity", "title", "description", "remediation",
                "threat_refs"} <= set(entry.keys())
        # fnmatch 兼容 — 不应包含正则元字符（除了 * ? [ ]）
        assert not re.search(r"[(){}+\\^$|]", entry["pattern"]), \
            f"pattern {entry['pattern']!r} 含非 fnmatch 字符"
        assert all(ref.startswith("TI-CONTAINER-IMAGE-") for ref in entry["threat_refs"])


def test_runtime_includes_seven_canonical_rules():
    data = _load()
    ids = {r["id"] for r in data["runtime"]}
    assert {"runtime-privileged", "runtime-host-net", "runtime-sock-mount",
            "runtime-host-fs-mount", "runtime-root-user",
            "runtime-cap-dangerous", "runtime-no-new-priv-missing"} <= ids


def test_daemon_includes_six_canonical_rules():
    data = _load()
    ids = {r["id"] for r in data["daemon"]}
    assert {"daemon-tls-exposed", "daemon-userns-off",
            "daemon-no-new-priv", "daemon-live-restore",
            "daemon-log-unbounded", "daemon-version-cve"} <= ids


def test_all_rule_ids_unique():
    data = _load()
    ids = (
        [r["id"] for r in data["daemon"]]
        + [r["id"] for r in data["runtime"]]
        + [r["id"] for r in data.get("daemon_podman", [])]
        + [r["id"] for r in data.get("daemon_containerd", [])]
    )
    assert len(ids) == len(set(ids)), \
        f"duplicate ids found: {[i for i in ids if ids.count(i) > 1]}"
