"""Shared CATEGORY_FILES for both test_openclaw_suite_loadable and
test_openclaw_stage_c_smoke. Each entry is (filename, minimum_cases).
The minimum reflects the spec-driven attack-vector coverage per category —
most categories have 5+ vectors; supply_chain and extension_auth have 2
(CVE-2026-32922 and CVE-2026-28446 each have two distinct vectors).
"""

CATEGORY_FILES = [
    ("01_direct_prompt_injection.yaml", 5),
    ("02_indirect_prompt_injection.yaml", 5),
    ("03_memory_poisoning.yaml", 5),
    ("04_tool_abuse.yaml", 17),
    ("05_consent_bypass.yaml", 6),
    ("06_auth_authz_bypass.yaml", 11),
    ("07_ssrf.yaml", 7),
    ("08_extension_auth.yaml", 5),
    ("09_supply_chain.yaml", 2),
    ("10_agent_chain_privesc.yaml", 6),
    ("11_cross_channel.yaml", 6),
]
