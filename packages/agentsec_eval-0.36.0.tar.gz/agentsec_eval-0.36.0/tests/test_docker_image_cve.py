"""DockerImageCveCheck 单元测试（Phase 7f）。"""

from __future__ import annotations

import asyncio

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.docker_image_cve import DockerImageCveCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult


def _runresult(stdout="", exit_code=0, rejected=False, stderr="") -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr or ("err" if exit_code != 0 else ""),
        exit_code=exit_code, rejected=rejected,
        reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _Executor:
    def __init__(self, responses):
        self._responses = responses

    def run(self, argv, *, role=None):
        return self._responses.get(tuple(argv), _runresult(exit_code=1))


def _ctx(executor):
    profile = materialize_paths(LINUX, "/home/u")
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=None, profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


PS_ARGV = ("docker", "ps", "--format", "{{json .}}", "--no-trunc")


def test_no_docker_marks_not_applicable():
    ctx = _ctx(_Executor({}))
    findings = _run(DockerImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_latest_tag_emits_medium():
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _runresult(stdout="/usr/bin/docker\n"),
        PS_ARGV: _runresult(
            stdout='{"ID":"a1b2c3d4e5f6","Image":"myapp:latest","Names":"app"}\n',
        ),
    }
    findings = _run(DockerImageCveCheck(), _ctx(_Executor(responses)))
    assert any(f.evidence.get("pattern") == "*:latest"
               and f.severity == "medium" for f in findings)


def test_python2_emits_high():
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _runresult(stdout="/usr/bin/docker\n"),
        PS_ARGV: _runresult(
            stdout='{"ID":"a1b2c3d4e5f6","Image":"python:2.7-slim","Names":"legacy"}\n',
        ),
    }
    findings = _run(DockerImageCveCheck(), _ctx(_Executor(responses)))
    py2 = [f for f in findings if f.evidence.get("pattern") == "python:2.*"]
    assert len(py2) == 1
    assert py2[0].severity == "high"
    assert "TI-CONTAINER-IMAGE-PYTHON2-EOL" in py2[0].threat_refs


def test_node_eol_emits_high():
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _runresult(stdout="/usr/bin/docker\n"),
        PS_ARGV: _runresult(
            stdout=(
                '{"ID":"a1","Image":"node:14-alpine","Names":"app1"}\n'
                '{"ID":"a2","Image":"node:12","Names":"app2"}\n'
                '{"ID":"a3","Image":"node:20","Names":"healthy"}\n'
            ),
        ),
    }
    findings = _run(DockerImageCveCheck(), _ctx(_Executor(responses)))
    node_eol = [f for f in findings
                if f.evidence.get("pattern") == "node:1[0-4]*"]
    assert len(node_eol) == 2   # node:14 + node:12; node:20 not matched


def test_image_matches_multiple_patterns_emits_separate_findings():
    """两个容器各命中不同 pattern — 产生多个 finding，fingerprint 各不相同。"""
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _runresult(stdout="/usr/bin/docker\n"),
        PS_ARGV: _runresult(
            stdout=(
                '{"ID":"a1","Image":"ubuntu:latest","Names":"web"}\n'
                '{"ID":"a2","Image":"python:2.7","Names":"legacy"}\n'
            ),
        ),
    }
    findings = _run(DockerImageCveCheck(), _ctx(_Executor(responses)))
    matches = [f.evidence["pattern"] for f in findings]
    assert "*:latest" in matches
    assert "python:2.*" in matches
    assert len({f.fingerprint for f in findings}) == len(findings)


def test_clean_image_emits_zero_findings():
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _runresult(stdout="/usr/bin/docker\n"),
        PS_ARGV: _runresult(
            stdout='{"ID":"a1b2","Image":"myapp:1.2.3","Names":"healthy"}\n',
        ),
    }
    findings = _run(DockerImageCveCheck(), _ctx(_Executor(responses)))
    assert findings == []


def test_docker_ps_failure_marks_skipped():
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _runresult(stdout="/usr/bin/docker\n"),
        PS_ARGV: _runresult(exit_code=1, stderr="error"),
    }
    ctx = _ctx(_Executor(responses))
    findings = _run(DockerImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
