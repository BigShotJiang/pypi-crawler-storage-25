"""ContainerdDaemonAuditCheck 单元测试（Phase 7f.1.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.containerd_daemon_audit import ContainerdDaemonAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_BIN = "/usr/bin/containerd"
_CONFIG = ("cat", "/etc/containerd/config.toml")
_VERSION = ("containerd", "--version")
_DOCKER_SOCKET_STAT = ("stat", "-c", "%n", "/var/run/docker.sock")

_DETECT_CONTAINERD_HIT = ("stat", "-c", "%n", _BIN)
_DETECT_CONTAINERD_FALLBACK = ("stat", "-c", "%n", "/usr/local/bin/containerd")
_DETECT_DOCKER_USR = ("stat", "-c", "%n", "/usr/bin/docker")
_DETECT_DOCKER_LOCAL = ("stat", "-c", "%n", "/usr/local/bin/docker")
_DETECT_DOCKER_BREW = ("stat", "-c", "%n", "/opt/homebrew/bin/docker")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="No such file", exit_code=1, rejected=False,
                reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=Path("/tmp"), profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_present(path: str) -> dict[tuple, RunResult]:
    return {("stat", "-c", "%n", path): _runresult(stdout=path + "\n")}


def _stat_absent(path: str) -> dict[tuple, RunResult]:
    return {("stat", "-c", "%n", path): _runresult(stderr="No such file", exit_code=1)}


def _detect_containerd_present() -> dict[tuple, RunResult]:
    """Return responses where /usr/bin/containerd is present and others absent."""
    return {
        _DETECT_CONTAINERD_HIT: _runresult(stdout=_BIN + "\n"),
        _DETECT_CONTAINERD_FALLBACK: _runresult(stderr="No such file", exit_code=1),
    }


def _docker_takeover_absent() -> dict[tuple, RunResult]:
    """Responses for detect_docker probes (all 3) returning miss + docker.sock absent."""
    return {
        _DETECT_DOCKER_USR: _runresult(stderr="No such file", exit_code=1),
        _DETECT_DOCKER_LOCAL: _runresult(stderr="No such file", exit_code=1),
        _DETECT_DOCKER_BREW: _runresult(stderr="No such file", exit_code=1),
        _DOCKER_SOCKET_STAT: _runresult(stderr="No such file", exit_code=1),
    }


# ---- Gating tests ----

def test_not_applicable_on_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True


def test_not_applicable_when_no_containerd_bin():
    responses = {
        _DETECT_CONTAINERD_HIT: _runresult(stderr="No such file", exit_code=1),
        _DETECT_CONTAINERD_FALLBACK: _runresult(stderr="No such file", exit_code=1),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True
    assert "containerd" in ctx.status.not_applicable_reason


def test_yields_when_docker_takeover():
    """docker present + /var/run/docker.sock present → not_applicable."""
    responses = {
        **_detect_containerd_present(),
        _DETECT_DOCKER_USR: _runresult(stdout="/usr/bin/docker\n"),
        _DOCKER_SOCKET_STAT: _runresult(stdout="/var/run/docker.sock\n"),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True
    assert "docker" in ctx.status.not_applicable_reason.lower()


# ---- 3-tier semantics ----

def test_config_missing_emits_info_finding_and_runs_version():
    """config.toml ENOENT → 1 info finding; version-cve still runs."""
    responses = {
        **_detect_containerd_present(),
        **_docker_takeover_absent(),
        _CONFIG: _runresult(stderr="No such file or directory", exit_code=1),
        _VERSION: _runresult(
            stdout="containerd github.com/containerd/containerd v1.7.13 abc\n"
        ),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    # 1 info finding for missing config + 0 version-cve (1.7.13 is patched)
    assert len(findings) == 1
    assert findings[0].severity == "info"
    assert "config.toml" in findings[0].title
    assert ctx.status.is_skipped is False  # not skipped, partial run


def test_permission_denied_skipped():
    responses = {
        **_detect_containerd_present(),
        **_docker_takeover_absent(),
        _CONFIG: _runresult(stderr="cat: /etc/containerd/config.toml: Permission denied",
                            exit_code=1),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "NOPASSWD" in ctx.status.skip_reason or "权限" in ctx.status.skip_reason


def test_toml_decode_fail_skipped():
    responses = {
        **_detect_containerd_present(),
        **_docker_takeover_absent(),
        _CONFIG: _runresult(stdout="[this is not = valid toml\n"),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True


def test_config_missing_plus_vulnerable_version_emits_two():
    """config.toml absent AND version is in known_bad → info + version-cve."""
    responses = {
        **_detect_containerd_present(),
        **_docker_takeover_absent(),
        _CONFIG: _runresult(stderr="No such file or directory", exit_code=1),
        _VERSION: _runresult(
            stdout="containerd github.com/containerd/containerd v1.7.10 abc\n"
        ),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_ids = {f.evidence.get("rule_id") for f in findings}
    assert rule_ids == {"containerd-config-missing", "containerd-version-cve"}
    assert ctx.status.is_skipped is False


# ---- Rule: tcp-exposed ----

def _config_with(*toml_body: str, version: str = "1.7.13") -> dict[tuple, RunResult]:
    return {
        **_detect_containerd_present(),
        **_docker_takeover_absent(),
        _CONFIG: _runresult(stdout="\n".join(toml_body) + "\n"),
        _VERSION: _runresult(
            stdout=f"containerd github.com/containerd/containerd v{version} abc\n"
        ),
    }


def test_tcp_exposed_critical():
    responses = _config_with(
        "[grpc]",
        'tcp_address = "0.0.0.0:2375"',
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_findings = [f for f in findings if f.evidence.get("rule_id") == "containerd-tcp-exposed"]
    assert len(rule_findings) == 1
    assert rule_findings[0].severity == "critical"
    assert rule_findings[0].evidence["grpc_tcp_address"] == "0.0.0.0:2375"


def test_tcp_not_exposed_when_unset():
    responses = _config_with("[grpc]")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert all(f.evidence.get("rule_id") != "containerd-tcp-exposed" for f in findings)


# ---- Rule: debug-socket-exposed ----

def test_debug_socket_tcp_form_high():
    responses = _config_with(
        "[debug]",
        'address = "0.0.0.0:1234"',
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_findings = [f for f in findings
                     if f.evidence.get("rule_id") == "containerd-debug-socket-exposed"]
    assert len(rule_findings) == 1
    assert rule_findings[0].severity == "high"


def test_debug_socket_unix_world_writable_high():
    """Unix socket path mode 0666 should flag debug-socket-exposed."""
    responses = _config_with(
        "[debug]",
        'address = "/run/containerd/debug.sock"',
    )
    responses[("stat", "-c", "%a", "/run/containerd/debug.sock")] = _runresult(stdout="666\n")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_findings = [f for f in findings
                     if f.evidence.get("rule_id") == "containerd-debug-socket-exposed"]
    assert len(rule_findings) == 1
    assert rule_findings[0].evidence["debug_perm"] == "666"


def test_debug_socket_unix_safe_perms_no_finding():
    """Unix socket mode 0600 should not flag."""
    responses = _config_with(
        "[debug]",
        'address = "/run/containerd/debug.sock"',
    )
    responses[("stat", "-c", "%a", "/run/containerd/debug.sock")] = _runresult(stdout="600\n")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert all(f.evidence.get("rule_id") != "containerd-debug-socket-exposed" for f in findings)


# ---- Rule: metrics-exposed ----

def test_metrics_localhost_not_flagged():
    for addr in ("127.0.0.1:9090", "[::1]:9090", "::1", "localhost:9090",
                 "unix:/tmp/m.sock"):
        responses = _config_with("[metrics]", f'address = "{addr}"')
        ctx = _ctx(_RecordingExecutor(responses))
        findings = _run(ContainerdDaemonAuditCheck(), ctx)
        assert all(f.evidence.get("rule_id") != "containerd-metrics-exposed"
                   for f in findings), f"{addr} unexpectedly flagged"


def test_metrics_public_addr_flagged_medium():
    for addr in ("0.0.0.0:9090", "[::]:9090", "1.2.3.4:9090"):
        responses = _config_with("[metrics]", f'address = "{addr}"')
        ctx = _ctx(_RecordingExecutor(responses))
        findings = _run(ContainerdDaemonAuditCheck(), ctx)
        rule_findings = [f for f in findings
                         if f.evidence.get("rule_id") == "containerd-metrics-exposed"]
        assert len(rule_findings) == 1, f"{addr} should flag exactly once"
        assert rule_findings[0].severity == "medium"


# ---- Rule: cri disable_apparmor + no_pivot ----

def test_cri_disable_apparmor_high():
    responses = _config_with(
        '[plugins."io.containerd.grpc.v1.cri"]',
        "disable_apparmor = true",
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_findings = [f for f in findings
                     if f.evidence.get("rule_id") == "containerd-cri-disable-apparmor"]
    assert len(rule_findings) == 1
    assert rule_findings[0].severity == "high"


def test_cri_no_pivot_medium():
    responses = _config_with(
        '[plugins."io.containerd.grpc.v1.cri".containerd]',
        "no_pivot = true",
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_findings = [f for f in findings
                     if f.evidence.get("rule_id") == "containerd-cri-no-pivot"]
    assert len(rule_findings) == 1
    assert rule_findings[0].severity == "medium"


def test_cri_defaults_no_findings():
    responses = _config_with('[plugins."io.containerd.grpc.v1.cri"]')
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    cri_rules = {"containerd-cri-disable-apparmor", "containerd-cri-no-pivot"}
    assert all(f.evidence.get("rule_id") not in cri_rules for f in findings)


# ---- Rule: version-cve ----


@pytest.mark.parametrize("version,hits", [
    ("1.7.10", True),
    ("1.7.11", False),
    ("1.6.27", True),
    ("1.6.28", False),
    ("1.5.0", True),    # falls under <1.6.28 branch
    ("1.8.0", False),
    ("2.0.0", False),   # future major — no known_bad_versions for major=2
])
def test_version_cve_dual_branch(version, hits):
    responses = _config_with(version=version)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_findings = [f for f in findings
                     if f.evidence.get("rule_id") == "containerd-version-cve"]
    if hits:
        assert len(rule_findings) == 1, f"v{version} should hit"
        assert rule_findings[0].severity == "high"
        assert rule_findings[0].evidence["version"] == version
    else:
        assert rule_findings == [], f"v{version} should not hit"


def test_version_cve_unparseable_no_finding():
    responses = _config_with(version="garbage")
    responses[_VERSION] = _runresult(stdout="containerd no-version-here\n")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    assert all(f.evidence.get("rule_id") != "containerd-version-cve" for f in findings)


# ---- Combined: all six rules together ----

def test_all_six_rules_together():
    responses = _config_with(
        "[grpc]",
        'tcp_address = "0.0.0.0:2375"',
        "[debug]",
        'address = "0.0.0.0:1234"',
        "[metrics]",
        'address = "0.0.0.0:9090"',
        '[plugins."io.containerd.grpc.v1.cri"]',
        "disable_apparmor = true",
        '[plugins."io.containerd.grpc.v1.cri".containerd]',
        "no_pivot = true",
        version="1.7.10",
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_ids = sorted({f.evidence.get("rule_id") for f in findings})
    assert rule_ids == sorted([
        "containerd-tcp-exposed",
        "containerd-debug-socket-exposed",
        "containerd-metrics-exposed",
        "containerd-cri-disable-apparmor",
        "containerd-cri-no-pivot",
        "containerd-version-cve",
    ])


def test_threat_refs_resolvable():
    """Every finding's threat_refs are non-empty (validates baseline wiring)."""
    responses = _config_with(
        "[grpc]",
        'tcp_address = "0.0.0.0:2375"',
        version="1.7.10",
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdDaemonAuditCheck(), ctx)
    rule_findings = [f for f in findings
                     if f.evidence.get("rule_id", "").startswith("containerd-")]
    for f in rule_findings:
        if f.severity == "info":
            continue
        assert f.threat_refs, f"finding {f.evidence['rule_id']} has no threat_refs"
        for ref in f.threat_refs:
            assert ref.startswith("TI-CONTAINERD-DAEMON-"), ref
