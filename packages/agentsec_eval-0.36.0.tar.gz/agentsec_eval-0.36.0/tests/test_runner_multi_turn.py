import asyncio

import pytest

from agentsec.adapters.base import AgentAdapter, AgentResponse
from agentsec.evaluator.base import Judge, JudgeVerdict
from agentsec.runner import run_suite
from agentsec.tests.models import TestCase, Turn


class _RecordingAdapter(AgentAdapter):
    def __init__(self):
        self.sent: list[tuple[str, str]] = []

    async def send(self, message, session_id):
        self.sent.append((session_id, message))
        return AgentResponse(content=f"echo:{message}", status_code=200)


class _StubJudge(Judge):
    async def evaluate(self, test, observation):
        return JudgeVerdict(passed=True, reasoning="stub", judge_type="llm")


@pytest.mark.asyncio
async def test_all_turns_are_replayed_in_order_for_one_test():
    adapter = _RecordingAdapter()
    test = TestCase(
        id="multi-1",
        category="multi_turn",
        description="d",
        turns=[
            Turn(attack="hello"),
            Turn(attack="follow up", sleep_ms=1),
            Turn(attack="finally"),
        ],
        expected_behavior="refusal",
        severity="medium",
    )
    results = await run_suite(adapter, _StubJudge(), [test], concurrency=1)
    assert len(results) == 1
    sent_messages = [m for _, m in adapter.sent]
    assert sent_messages == ["hello", "follow up", "finally"]
    sessions = {sid for sid, _ in adapter.sent}
    assert len(sessions) == 1


@pytest.mark.asyncio
async def test_judge_after_calls_judge_per_turn():
    calls: list[str] = []

    class _CountingJudge(Judge):
        async def evaluate(self, test, observation):
            calls.append(observation.response.content)
            return JudgeVerdict(passed=True, reasoning="ok", judge_type="llm")

    adapter = _RecordingAdapter()
    test = TestCase(
        id="judge-after",
        category="multi_turn",
        description="d",
        turns=[
            Turn(attack="t1", judge_after=True),
            Turn(attack="t2"),
            Turn(attack="t3", judge_after=True),
        ],
        expected_behavior="refusal",
        severity="medium",
    )
    await run_suite(adapter, _CountingJudge(), [test], concurrency=1)
    # judge fires after t1 and t3 only — t3 is also the final turn so it counts
    # once, not twice.
    assert calls == ["echo:t1", "echo:t3"]


@pytest.mark.asyncio
async def test_sleep_ms_is_honored(monkeypatch):
    sleeps: list[float] = []
    real_sleep = asyncio.sleep

    async def fake_sleep(d):
        sleeps.append(d)
        await real_sleep(0)

    monkeypatch.setattr("agentsec.runner.asyncio.sleep", fake_sleep)
    adapter = _RecordingAdapter()
    test = TestCase(
        id="sleep",
        category="multi_turn",
        description="d",
        turns=[Turn(attack="a", sleep_ms=250), Turn(attack="b")],
        expected_behavior="refusal",
        severity="low",
    )
    await run_suite(adapter, _StubJudge(), [test], concurrency=1)
    assert 0.25 in sleeps


@pytest.mark.asyncio
async def test_single_attack_case_still_runs_unchanged_after_loader_expansion():
    """Loader auto-expands `attack` to `turns=[Turn(attack=...)]`; this test
    constructs the post-expansion shape directly."""
    adapter = _RecordingAdapter()
    test = TestCase(
        id="single",
        category="basic",
        description="d",
        turns=[Turn(attack="lone")],
        expected_behavior="refusal",
        severity="low",
    )
    results = await run_suite(adapter, _StubJudge(), [test], concurrency=1)
    assert len(results) == 1
    assert results[0].status == "passed"
    assert [m for _, m in adapter.sent] == ["lone"]
