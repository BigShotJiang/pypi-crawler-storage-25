"""Unit tests for SysctlAuditCheck (Phase 7e)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.sysctl_audit import SysctlAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult


class _StubExecutor:
    def __init__(self, response: RunResult):
        self._response = response
        self.last_argv: list[str] | None = None

    def run(self, argv, *, role=None):
        self.last_argv = list(argv)
        return self._response


def _runresult(stdout: str = "", exit_code: int = 0,
               rejected: bool = False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr="", exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, *, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def test_compliant_system_emits_no_findings():
    # Baseline expects 8 sysctl values; provide all-compliant defaults
    # in the same order as the baseline yaml.
    sysctl_output = "\n".join(["1", "2", "0", "1", "0", "0", "0", "1"]) + "\n"
    executor = _StubExecutor(_runresult(stdout=sysctl_output))
    findings = _run(SysctlAuditCheck(), _ctx(executor))
    assert findings == []
    assert executor.last_argv is not None
    assert executor.last_argv[0] == "sysctl"
    assert "-n" in executor.last_argv
    keys_in_argv = [a for a in executor.last_argv if "." in a]
    assert len(keys_in_argv) == 8


def test_violations_emit_one_finding_per_key():
    # All 8 keys return "0". Baseline:
    #   kernel.dmesg_restrict expected "1"  → violation
    #   kernel.kptr_restrict   expected "2"  → violation
    #   fs.suid_dumpable       expected "0"  → COMPLIANT
    #   net.ipv4.conf.all.rp_filter expected "1" → violation
    #   net.ipv4.conf.all.send_redirects expected "0" → compliant
    #   net.ipv4.conf.all.accept_redirects expected "0" → compliant
    #   net.ipv4.conf.all.accept_source_route expected "0" → compliant
    #   net.ipv4.tcp_syncookies expected "1" → violation
    sysctl_output = "\n".join(["0"] * 8) + "\n"
    executor = _StubExecutor(_runresult(stdout=sysctl_output))
    findings = _run(SysctlAuditCheck(), _ctx(executor))
    assert len(findings) == 4
    titles = [f.title for f in findings]
    assert any("kernel.dmesg_restrict" in t for t in titles)
    assert any("net.ipv4.tcp_syncookies" in t for t in titles)


def test_skip_on_macos_profile():
    executor = _StubExecutor(_runresult())
    ctx = _ctx(executor, profile_name="macos")
    findings = _run(SysctlAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "Linux" in (ctx.status.not_applicable_reason or "")


def test_skip_on_executor_rejection():
    executor = _StubExecutor(_runresult(rejected=True))
    ctx = _ctx(executor)
    findings = _run(SysctlAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
