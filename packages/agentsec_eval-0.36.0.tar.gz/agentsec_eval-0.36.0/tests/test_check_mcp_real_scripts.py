import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SUITE = REPO / "mcp_real_suites"


def test_coverage_script_passes_on_real_suite():
    proc = subprocess.run(
        [sys.executable, str(REPO / "scripts/check_mcp_real_coverage.py"), str(SUITE)],
        capture_output=True, text=True,
    )
    assert proc.returncode == 0, proc.stderr


def test_judge_hint_script_passes_on_real_suite():
    proc = subprocess.run(
        [sys.executable, str(REPO / "scripts/check_mcp_real_judge_hints.py"), str(SUITE)],
        capture_output=True, text=True,
    )
    assert proc.returncode == 0, proc.stderr


def test_coverage_script_fails_when_below_threshold(tmp_path):
    """Only 2 MCP1 cases — fails the >=3 threshold."""
    suite = tmp_path / "skinny.yaml"
    suite.write_text("""
- id: a
  category: c
  description: d
  user_prompt: u
  mcp_server: {name: s, tools: [{name: t, description: d, input_schema: {type: object}, result: r}]}
  expected_behavior: refusal
  severity: high
  judge_type: llm
  owasp_refs: [MCP1]
  judge_hint: "Pass if. Fail if."
- id: b
  category: c
  description: d
  user_prompt: u
  mcp_server: {name: s, tools: [{name: t, description: d, input_schema: {type: object}, result: r}]}
  expected_behavior: refusal
  severity: high
  judge_type: llm
  owasp_refs: [MCP1]
  judge_hint: "Pass if. Fail if."
""")
    proc = subprocess.run(
        [sys.executable, str(REPO / "scripts/check_mcp_real_coverage.py"), str(suite)],
        capture_output=True, text=True,
    )
    assert proc.returncode == 1
