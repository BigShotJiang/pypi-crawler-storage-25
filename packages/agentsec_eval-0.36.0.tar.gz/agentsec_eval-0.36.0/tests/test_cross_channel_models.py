"""Unit tests for Turn.channel and TestCase cross-channel WS fields."""
import pytest
from pydantic import ValidationError

from agentsec.tests.models import TestCase, Turn

# --- Turn.channel ---

def test_turn_channel_defaults_to_http():
    t = Turn(attack="x")
    assert t.channel == "http"


def test_turn_channel_accepts_ws():
    t = Turn(attack="x", channel="ws")
    assert t.channel == "ws"


def test_turn_channel_rejects_invalid():
    with pytest.raises(ValidationError):
        Turn(attack="x", channel="ssh")


# --- TestCase.ws_concurrent_observe ---

def _base_case(**overrides):
    defaults = dict(
        id="t1",
        category="cross_channel",
        description="test",
        attack="payload",
        expected_behavior="refusal",
        severity="high",
    )
    defaults.update(overrides)
    return defaults


def test_testcase_ws_concurrent_observe_defaults_false():
    tc = TestCase(**_base_case())
    assert tc.ws_concurrent_observe is False


def test_testcase_ws_listen_duration_s_default():
    tc = TestCase(**_base_case())
    assert tc.ws_listen_duration_s == 5.0


def test_testcase_ws_listen_duration_s_custom():
    tc = TestCase(**_base_case(), ws_concurrent_observe=True, ws_listen_duration_s=8.0)
    assert tc.ws_listen_duration_s == 8.0


# --- Mutual-exclusion validator ---

def test_ws_concurrent_observe_with_ws_channel_turn_raises():
    """ws_concurrent_observe=True + channel='ws' turn is forbidden."""
    with pytest.raises(ValidationError, match="ws_concurrent_observe"):
        TestCase(
            id="t2",
            category="cross_channel",
            description="test",
            turns=[
                {"attack": "payload", "channel": "ws", "judge_after": True},
            ],
            expected_behavior="refusal",
            severity="high",
            ws_concurrent_observe=True,
        )


def test_ws_concurrent_observe_with_http_only_turns_ok():
    tc = TestCase(
        id="t3",
        category="cross_channel",
        description="test",
        turns=[{"attack": "payload", "judge_after": True}],
        expected_behavior="refusal",
        severity="high",
        ws_concurrent_observe=True,
    )
    assert tc.ws_concurrent_observe is True


def test_ws_concurrent_observe_with_mixed_channel_turns_raises():
    """Mixed http+ws turns with ws_concurrent_observe=True is also forbidden."""
    with pytest.raises(ValidationError, match="ws_concurrent_observe"):
        TestCase(
            id="t4",
            category="cross_channel",
            description="test",
            turns=[
                {"attack": "http payload", "channel": "http"},
                {"attack": "ws payload", "channel": "ws", "judge_after": True},
            ],
            expected_behavior="refusal",
            severity="high",
            ws_concurrent_observe=True,
        )


def test_ws_concurrent_observe_with_single_attack_field_ok():
    """ws_concurrent_observe=True is valid with the single-turn attack= field."""
    tc = TestCase(
        id="t5",
        category="cross_channel",
        description="test",
        attack="http payload",
        expected_behavior="refusal",
        severity="high",
        ws_concurrent_observe=True,
    )
    assert tc.ws_concurrent_observe is True
