"""Stage C exit gate: every category file under test_suites/openclaw/ loads
cleanly and references known TI-* IDs."""

from pathlib import Path

import pytest
import yaml

from agentsec.observability.network_observer import NetworkObserverConfig
from agentsec.tests.loader import load_test_suite
from tests._openclaw_categories import CATEGORY_FILES

SUITE_DIR = Path("test_suites/openclaw")
THREAT_INTEL = Path("src/agentsec/audit/ioc/threat_intel.yaml")


def _known_ti_ids() -> set[str]:
    items = yaml.safe_load(THREAT_INTEL.read_text())
    return {item["id"] for item in items}


@pytest.mark.parametrize("filename,min_cases", CATEGORY_FILES)
def test_category_file_loads(filename: str, min_cases: int):
    path = SUITE_DIR / filename
    if not path.exists():
        pytest.skip(f"{filename} not yet authored")
    cfg = NetworkObserverConfig(
        mode="fixture_only",
        controlled_domains=["*.agentsec.test", "*.openclaw.test", "169.254.169.254", "127.0.0.1"],
    )
    cases = load_test_suite(path, observer_config=cfg)
    assert len(cases) >= min_cases, f"{filename} must have at least {min_cases} cases"


@pytest.mark.parametrize("filename,min_cases", CATEGORY_FILES)
def test_threat_refs_are_known(filename: str, min_cases: int):
    path = SUITE_DIR / filename
    if not path.exists():
        pytest.skip(f"{filename} not yet authored")
    known = _known_ti_ids()
    cases = load_test_suite(
        path,
        observer_config=NetworkObserverConfig(
            mode="fixture_only",
            controlled_domains=[
                "*.agentsec.test",
                "*.openclaw.test",
                "169.254.169.254",
                "127.0.0.1",
            ],
        ),
    )
    for c in cases:
        for ref in c.threat_refs:
            assert ref in known, f"{c.id} references unknown TI id {ref}"
