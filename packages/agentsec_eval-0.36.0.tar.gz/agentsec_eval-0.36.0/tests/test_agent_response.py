from agentsec.adapters.base import AgentResponse


def test_defaults():
    r = AgentResponse(content="hi")
    assert r.content == "hi"
    assert r.raw == {}
    assert r.latency_ms == 0.0
    assert r.status_code is None
    assert r.headers == {}
    assert r.request_url is None
    assert r.error is None
    assert r.tool_events == []


def test_distinct_default_dicts_per_instance():
    a = AgentResponse(content="a")
    b = AgentResponse(content="b")
    a.raw["x"] = 1
    a.headers["h"] = "v"
    a.tool_events.append({"tool": "shell.exec", "args": "ls"})
    assert "x" not in b.raw
    assert "h" not in b.headers
    assert b.tool_events == []


def test_full_population():
    r = AgentResponse(
        content="ok",
        raw={"k": 1},
        latency_ms=12.5,
        status_code=503,
        headers={"content-type": "application/json"},
        request_url="https://example/v1/chat/completions",
        error="upstream 503",
    )
    assert r.status_code == 503
    assert r.error == "upstream 503"
    assert r.request_url.endswith("/completions")
