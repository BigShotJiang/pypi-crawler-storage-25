"""Unit tests for SuidAuditCheck (Phase 7e)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.suid_audit import SuidAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult


class _StubExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        key = tuple(argv)
        return self._responses.get(
            key,
            RunResult(
                stdout="", stderr="", exit_code=0,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _runresult(stdout="") -> RunResult:
    return RunResult(
        stdout=stdout, stderr="", exit_code=0,
        rejected=False, reject_reason=None, argv=[],
        command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def test_only_whitelisted_suid_no_findings():
    responses = {
        ("find", "/usr/bin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"):
            _runresult(stdout="/usr/bin/su\n/usr/bin/sudo\n/usr/bin/passwd\n"),
        ("find", "/usr/sbin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"):
            _runresult(stdout="/usr/sbin/unix_chkpwd\n"),
    }
    findings = _run(SuidAuditCheck(), _ctx(_StubExecutor(responses)))
    assert findings == []


def test_unknown_suid_emits_finding_per_binary():
    responses = {
        ("find", "/usr/bin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"):
            _runresult(stdout="/usr/bin/su\n/usr/bin/evil_backdoor\n"),
        ("find", "/usr/sbin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"):
            _runresult(stdout="/usr/sbin/another_unknown\n"),
    }
    findings = _run(SuidAuditCheck(), _ctx(_StubExecutor(responses)))
    titles = [f.title for f in findings]
    assert len(findings) == 2
    assert any("/usr/bin/evil_backdoor" in t for t in titles)
    assert any("/usr/sbin/another_unknown" in t for t in titles)
    assert all(f.severity == "high" for f in findings)


def test_macos_skips():
    ctx = _ctx(_StubExecutor({}), profile_name="macos")
    findings = _run(SuidAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_find_failure_skips_check():
    """If both find calls fail, the check skips with a clear reason."""
    responses = {
        ("find", "/usr/bin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"):
            RunResult(
                stdout="", stderr="permission denied", exit_code=1,
                rejected=False, reject_reason=None, argv=[],
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        ("find", "/usr/sbin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"):
            RunResult(
                stdout="", stderr="permission denied", exit_code=1,
                rejected=False, reject_reason=None, argv=[],
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
    }
    ctx = _ctx(_StubExecutor(responses))
    findings = _run(SuidAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
