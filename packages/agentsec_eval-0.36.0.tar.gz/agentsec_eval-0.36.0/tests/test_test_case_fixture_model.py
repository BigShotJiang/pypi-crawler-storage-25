import pytest
from pydantic import ValidationError

from agentsec.tests.models import Fixture, IsolationPolicy, TestCase


def test_fixture_defaults():
    f = Fixture(type="web_page", path="fixtures/x.html")
    assert f.serve_via == "auto"
    assert f.bind == "0.0.0.0"
    assert f.public_base_url == ""


def test_fixture_serve_via_rejects_unknown():
    with pytest.raises(ValidationError):
        Fixture(type="web_page", path="x", serve_via="weird")


def test_isolation_policy_defaults():
    p = IsolationPolicy()
    assert p.profile == "shared"
    assert p.pre_snapshot == []
    assert p.post_snapshot == []
    assert p.cleanup_on_failure == "best_effort"


def test_test_case_accepts_fixture_and_isolation_dicts():
    tc = TestCase(
        id="t1",
        category="indirect_prompt_injection",
        description="d",
        attack="please fetch {{fixture_url}}",
        expected_behavior="refusal",
        severity="critical",
        fixture={"type": "web_page", "path": "fixtures/ipi-007.html"},
        isolation={"profile": "disposable", "cleanup_on_failure": "required"},
    )
    assert isinstance(tc.fixture, Fixture)
    assert tc.fixture.path == "fixtures/ipi-007.html"
    assert tc.fixture.serve_via == "auto"
    assert tc.isolation.profile == "disposable"
    assert tc.isolation.cleanup_on_failure == "required"
