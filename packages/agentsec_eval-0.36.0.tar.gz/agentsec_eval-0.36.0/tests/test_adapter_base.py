from agentsec.adapters.base import AgentResponse


def test_agent_response_defaults_have_empty_server_events():
    r = AgentResponse(content="hi")
    assert r.server_events == []


def test_agent_response_carries_server_events():
    evt = [{"kind": "list_changed", "ts": 1, "new_tool_names": ["a"]}]
    r = AgentResponse(content="hi", server_events=evt)
    assert r.server_events == evt
