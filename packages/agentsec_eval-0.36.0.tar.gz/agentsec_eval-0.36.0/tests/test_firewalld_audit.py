"""FirewalldAuditCheck unit tests (Phase 7e.3)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.firewalld_audit import (
    FirewalldAuditCheck,
    ZoneInfo,
    parse_firewalld_zones,
)
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "firewall"


def test_parse_default_only_active():
    text = (_FIXTURES / "firewalld_list_all_default_only.txt").read_text()
    zones = parse_firewalld_zones(text, default_zone="public")
    by_name = {z.name: z for z in zones}
    assert by_name["public"] == ZoneInfo(
        name="public", target="default", is_active=True, is_default=True
    )
    assert by_name["block"].is_active is False
    assert by_name["block"].target == "%%REJECT%%"
    assert by_name["dmz"].is_active is False
    assert by_name["drop"].target == "DROP"
    assert by_name["trusted"].target == "ACCEPT"
    assert by_name["trusted"].is_active is False  # no interfaces, no sources


def test_parse_marks_active_via_interfaces_when_no_marker():
    """firewalld < 0.6 may omit the (active) header marker but still bind
    interfaces. The parser must fall back to the interfaces line."""
    text = (
        "home\n"
        "  target: default\n"
        "  interfaces: wlan0\n"
        "  sources: \n"
    )
    zones = parse_firewalld_zones(text, default_zone="public")
    assert zones[0].name == "home"
    assert zones[0].is_active is True
    assert zones[0].is_default is False


def test_parse_marks_active_via_sources():
    text = (
        "trusted\n"
        "  target: ACCEPT\n"
        "  interfaces: \n"
        "  sources: 10.0.0.0/8\n"
    )
    zones = parse_firewalld_zones(text, default_zone="public")
    assert zones[0].is_active is True


def test_parse_empty_returns_empty_list():
    assert parse_firewalld_zones("", default_zone="public") == []


def test_parse_zone_without_target_emits_empty_target():
    text = (
        "weird\n"
        "  interfaces: eth9\n"
    )
    zones = parse_firewalld_zones(text, default_zone="public")
    assert zones[0].target == ""


# ---------------------------------------------------------------------------
# FirewalldAuditCheck entry tests (T5)
# ---------------------------------------------------------------------------

_BIN = "/usr/bin/firewall-cmd"
_STATE = ("firewall-cmd", "--state")
_GET_DEFAULT = ("firewall-cmd", "--get-default-zone")
_LIST_ALL = ("firewall-cmd", "--list-all-zones")


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=1, rejected=False,
                reject_reason=None, argv=argv, command_sha256="0" * 64,
                duration_ms=0.0, bytes_out=0,
            ),
        )


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=Path("/tmp"), profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found_path: str | None) -> dict[tuple, RunResult]:
    candidates = ("/usr/bin/firewall-cmd", "/bin/firewall-cmd")
    out: dict[tuple, RunResult] = {}
    for c in candidates:
        if c == found_path:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c + "\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True


def test_not_applicable_no_binary():
    ctx = _ctx(_RecordingExecutor(_detect_responses(None)))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True


def test_critical_when_service_stopped():
    text = (_FIXTURES / "firewalld_state_stopped.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout=text, exit_code=252)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert len(findings) == 1
    assert findings[0].severity == "critical"
    assert "未启用" in findings[0].title
    # Should NOT have called --get-default-zone or --list-all-zones
    called = {tuple(c) for c in ctx.executor.calls}
    assert _GET_DEFAULT not in called
    assert _LIST_ALL not in called


def test_skipped_when_state_perm_denied():
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(
        stderr="Authorization failed: Permission denied", exit_code=126,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "sudoers" in (ctx.status.skip_reason or "").lower() or \
           "root" in (ctx.status.skip_reason or "").lower()


def test_skipped_when_get_default_zone_empty():
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout="running\n", exit_code=0)
    responses[_GET_DEFAULT] = _runresult(stdout="", exit_code=0)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True


def test_skipped_when_list_all_rejected():
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout="running\n", exit_code=0)
    responses[_GET_DEFAULT] = _runresult(stdout="public\n", exit_code=0)
    responses[_LIST_ALL] = _runresult(rejected=True)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "策略拒绝" in (ctx.status.skip_reason or "")


# ---------------------------------------------------------------------------
# FirewalldAuditCheck happy-path matrix (T6)
# ---------------------------------------------------------------------------


def _three_cmd_responses(*, default_zone: str, list_all_text: str):
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout="running\n", exit_code=0)
    responses[_GET_DEFAULT] = _runresult(stdout=default_zone + "\n", exit_code=0)
    responses[_LIST_ALL] = _runresult(stdout=list_all_text, exit_code=0)
    return responses


def test_clean_default_only_active():
    text = (_FIXTURES / "firewalld_list_all_default_only.txt").read_text()
    responses = _three_cmd_responses(default_zone="public", list_all_text=text)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    # public is active+default+target=default → no finding
    # trusted is target=ACCEPT but NOT active and NOT default → no finding
    assert findings == []


def test_critical_default_zone_accept():
    text = (_FIXTURES / "firewalld_list_all_default_accept.txt").read_text()
    responses = _three_cmd_responses(default_zone="public", list_all_text=text)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert len(findings) == 1
    f = findings[0]
    assert f.severity == "critical"
    assert f.evidence["is_default"] is True
    assert f.evidence["zone"] == "public"
    assert f.evidence["target"] == "ACCEPT"


def test_high_non_default_active_accept():
    text = (_FIXTURES / "firewalld_list_all_multi_active_mixed.txt").read_text()
    responses = _three_cmd_responses(default_zone="public", list_all_text=text)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert len(findings) == 1
    f = findings[0]
    assert f.severity == "high"
    assert f.evidence["is_default"] is False
    assert f.evidence["zone"] == "dmz"


def test_empty_list_all_skipped():
    """Zero-byte --list-all-zones output → `not la.stdout.strip()` triggers
    the skipped branch (matches spec §6 row 'Cmd #3 stdout 空 → skipped').
    Distinct from the "valid blob, parses to zero zones" set_ok branch,
    which is covered by the parser unit test test_parse_empty_returns_empty_list."""
    text = (_FIXTURES / "firewalld_list_all_empty.txt").read_text()
    assert text == ""  # fixture sanity
    responses = _three_cmd_responses(default_zone="public", list_all_text=text)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "输出为空" in (ctx.status.skip_reason or "")


# ---------------------------------------------------------------------------
# FirewalldAuditCheck — cmd #2 / cmd #3 error-path coverage (M9)
# ---------------------------------------------------------------------------


def test_get_default_zone_perm_denied_skipped():
    """Cmd #2 (--get-default-zone) exit_code=126 + perm-denied stderr → skipped."""
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout="running\n", exit_code=0)
    responses[_GET_DEFAULT] = _runresult(
        stderr="Authorization failed: Permission denied", exit_code=126,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "权限不足" in (ctx.status.skip_reason or "")


def test_get_default_zone_nonzero_skipped():
    """Cmd #2 (--get-default-zone) non-zero, non-perm-denied exit → skipped with exit code."""
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout="running\n", exit_code=0)
    responses[_GET_DEFAULT] = _runresult(
        stderr="Unknown error occurred", exit_code=2,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "退出码 2" in (ctx.status.skip_reason or "")


def test_list_all_zones_perm_denied_skipped():
    """Cmd #3 (--list-all-zones) exit_code=126 + perm-denied stderr → skipped."""
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout="running\n", exit_code=0)
    responses[_GET_DEFAULT] = _runresult(stdout="public\n", exit_code=0)
    responses[_LIST_ALL] = _runresult(
        stderr="Permission denied", exit_code=126,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "权限不足" in (ctx.status.skip_reason or "")


def test_list_all_zones_nonzero_skipped():
    """Cmd #3 (--list-all-zones) non-zero, non-perm-denied exit → skipped with exit code."""
    responses = _detect_responses(_BIN)
    responses[_STATE] = _runresult(stdout="running\n", exit_code=0)
    responses[_GET_DEFAULT] = _runresult(stdout="public\n", exit_code=0)
    responses[_LIST_ALL] = _runresult(
        stderr="Failed to connect to firewalld", exit_code=3,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(FirewalldAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "退出码 3" in (ctx.status.skip_reason or "")
