"""render_combined_report includes MCP section when score.mcp is present
(Phase 7c.6)."""

from agentsec.mcp_harness.scoring import McpCategoryScore, McpScore
from agentsec.reports.markdown import render_combined_report
from agentsec.scoring import (
    CombinedScore,
    CoverageTriple,
    EvaluationScore,
)


def _eval_score(*, mcp: McpScore | None) -> EvaluationScore:
    return EvaluationScore(
        category_scores=[],
        remote_score=None,
        server_score=None,
        mcp=mcp,
        combined=CombinedScore(
            score=80.0,
            weight_remote_used=0.4,
            weight_server_used=0.4,
            weight_mcp_used=0.2,
            note=None,
        ),
        coverage=CoverageTriple(
            planned=0, executed=0, scored=0, error=0,
            execution_coverage=0.0, verdict_coverage=0.0, error_rate=None,
        ),
        low_coverage=False,
        grade="B",
        deduped_findings=[],
    )


def test_combined_report_has_weight_mcp_meta():
    mcp = McpScore(
        score=90.0,
        categories=[McpCategoryScore("MCP1", 4, 4, 1.0)],
        coverage=CoverageTriple(
            planned=4, executed=4, scored=4, error=0,
            execution_coverage=1.0, verdict_coverage=1.0, error_rate=0.0,
        ),
        note=None,
    )
    md = render_combined_report(
        "t", _eval_score(mcp=mcp),
        remote_present=False, server_present=False, mcp_present=True,
    )
    assert "weight_mcp_used" in md


def test_combined_report_has_mcp_section():
    mcp = McpScore(
        score=75.0,
        categories=[
            McpCategoryScore("MCP1", 3, 4, 0.75),
            McpCategoryScore("MCP2", 4, 4, 1.0),
        ],
        coverage=CoverageTriple(
            planned=8, executed=8, scored=8, error=0,
            execution_coverage=1.0, verdict_coverage=1.0, error_rate=0.0,
        ),
        note=None,
    )
    md = render_combined_report(
        "t", _eval_score(mcp=mcp),
        remote_present=False, server_present=False, mcp_present=True,
    )
    assert "MCP real-protocol" in md
    assert "MCP1" in md
    assert "MCP2" in md
    assert "3 / 4" in md
    assert "4 / 4" in md


def test_combined_report_no_mcp_section_when_score_mcp_none():
    md = render_combined_report(
        "t", _eval_score(mcp=None),
        remote_present=False, server_present=False, mcp_present=False,
    )
    assert "MCP real-protocol" not in md
    assert "mcp-real-report" not in md


def test_combined_report_links_to_mcp_real_report_when_present():
    mcp = McpScore(score=80.0, categories=[], coverage=CoverageTriple(
        planned=1, executed=1, scored=1, error=0,
        execution_coverage=1.0, verdict_coverage=1.0, error_rate=0.0,
    ), note=None)
    md = render_combined_report(
        "t", _eval_score(mcp=mcp),
        remote_present=False, server_present=False, mcp_present=True,
    )
    assert "./mcp-real-report.md" in md
