from typer.testing import CliRunner

from agentsec.cli import app


def test_unknown_adapter_exits_with_error_listing_known(tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: x\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )
    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x", "--adapter", "nope"],
        catch_exceptions=False,
    )
    assert res.exit_code != 0
    assert "nope" in res.output
    assert "http" in res.output  # lists available


def test_default_adapter_is_http(monkeypatch, tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: x\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )

    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["adapter_class"] = type(adapter).__name__
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x"],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output
    assert captured["adapter_class"] == "HttpAgentAdapter"


def test_openclaw_adapter_selected_by_name(monkeypatch, tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: x\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )

    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["adapter_class"] = type(adapter).__name__
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x", "--adapter", "openclaw-gateway"],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output
    assert captured["adapter_class"] == "OpenClawGatewayAdapter"


def test_token_env_injects_authorization_header(monkeypatch, tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: x\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )
    monkeypatch.setenv("OC_TOKEN_TEST", "supersecret")

    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["headers"] = dict(adapter._headers)
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x", "--token-env", "OC_TOKEN_TEST"],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output
    assert captured["headers"].get("Authorization") == "Bearer supersecret"
    # Token value never appears in CLI output.
    assert "supersecret" not in res.output


def test_token_env_unset_exits_with_error(monkeypatch, tmp_path):
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: x\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )
    monkeypatch.delenv("OC_TOKEN_TEST_MISSING", raising=False)

    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x",
         "--token-env", "OC_TOKEN_TEST_MISSING"],
        catch_exceptions=False,
    )
    assert res.exit_code == 2
    assert "OC_TOKEN_TEST_MISSING" in res.output


def test_ws_url_passed_to_run_suite(monkeypatch, tmp_path):
    """--ws-url creates a WebSocketAgentAdapter and passes it to run_suite."""
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: x\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )
    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["ws_adapter"] = kwargs.get("ws_adapter")
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x", "--ws-url", "ws://localhost/ws"],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output
    assert captured["ws_adapter"] is not None
    assert captured["ws_adapter"]._ws_url == "ws://localhost/ws"


def test_no_ws_url_passes_none_to_run_suite(monkeypatch, tmp_path):
    """Without --ws-url, ws_adapter=None is passed to run_suite."""
    suite = tmp_path / "s.yaml"
    suite.write_text(
        "- id: x\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )
    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["ws_adapter"] = kwargs.get("ws_adapter")
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setattr("agentsec.cli.build_default_judge_from_env", lambda: object())

    runner = CliRunner()
    res = runner.invoke(
        app,
        ["run", str(suite), "--target", "http://x"],
        catch_exceptions=False,
    )
    assert res.exit_code == 0, res.output
    assert captured["ws_adapter"] is None
