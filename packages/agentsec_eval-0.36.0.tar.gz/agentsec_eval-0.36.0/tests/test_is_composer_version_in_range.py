"""Unit tests for _is_composer_version_in_range (Phase 7d.6)."""

from __future__ import annotations

import pytest

from agentsec.audit.checks._supply_chain_common import (
    _is_composer_version_in_range,
    _normalize_composer_version,
    _safe_parse_composer_version,
)


@pytest.mark.parametrize(
    "version,introduced,fixed,expected",
    [
        # Standard semver
        ("1.5.0", "1.0", "2.0", True),
        ("0.9.0", "1.0", "2.0", False),
        ("2.0.0", "1.0", "2.0", False),  # fixed exclusive
        ("1.0.0", "1.0", "2.0", True),  # introduced inclusive
        # v-prefix stripping
        ("v1.5.0", "1.0", "2.0", True),
        # Composer stability flags
        ("1.0.0-dev", "0", "1.0.0", True),
        ("1.0.0", "0", "1.0.0-dev", False),  # stable > dev
        ("1.0.0-alpha", "0", "1.0.0-beta", True),  # alpha < beta
        ("1.0.0-beta", "0", "1.0.0-alpha", False),
        ("1.0.0-alpha2", "1.0.0-alpha", "1.0.0-alpha3", True),
        ("1.0.0-RC1", "0", "1.0.0", True),
        ("1.0.0-p1", "1.0.0", None, True),  # patch > stable
        # Missing bounds
        ("1.5.0", None, "2.0", True),
        ("3.0.0", None, "2.0", False),
        ("1.5.0", "1.0", None, True),
        ("0.5.0", "1.0", None, False),
        ("1.5.0", None, None, True),  # all versions vulnerable
        # Unparseable returns False (Composer dev-branch aliases)
        ("dev-master", "1.0", "2.0", False),
        ("1.x-dev", "1.0", "2.0", False),
        ("not-a-version", "1.0", "2.0", False),
    ],
)
def test_is_composer_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
    expected: bool,
) -> None:
    assert _is_composer_version_in_range(version, introduced, fixed) is expected


def test_normalize_strips_v_prefix() -> None:
    assert _normalize_composer_version("v1.2.3") == "1.2.3"
    assert _normalize_composer_version("V1.2.3") == "1.2.3"
    assert _normalize_composer_version("1.2.3") == "1.2.3"


def test_normalize_stability_mapping() -> None:
    assert _normalize_composer_version("1.0.0-dev") == "1.0.0.dev0"
    assert _normalize_composer_version("1.0.0-alpha") == "1.0.0a0"
    assert _normalize_composer_version("1.0.0-alpha2") == "1.0.0a2"
    assert _normalize_composer_version("1.0.0-beta") == "1.0.0b0"
    assert _normalize_composer_version("1.0.0-RC1") == "1.0.0rc1"
    assert _normalize_composer_version("1.0.0-p1") == "1.0.0.post1"


def test_safe_parse_handles_invalid() -> None:
    assert _safe_parse_composer_version("") is None
    assert _safe_parse_composer_version(None) is None  # type: ignore
    assert _safe_parse_composer_version("dev-master") is None
    assert _safe_parse_composer_version("1.x-dev") is None


def test_safe_parse_handles_stability_forms() -> None:
    assert _safe_parse_composer_version("1.0.0-dev") is not None
    assert _safe_parse_composer_version("1.0.0-alpha2") is not None
    assert _safe_parse_composer_version("1.0.0-RC1") is not None
    assert _safe_parse_composer_version("1.0.0-p1") is not None


def test_safe_parse_handles_build_metadata() -> None:
    assert _safe_parse_composer_version("1.0.0+20210101") is not None
