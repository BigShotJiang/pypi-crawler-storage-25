"""Unit tests for cross-channel routing in run_suite."""
import pytest

from agentsec.adapters.base import AgentAdapter, AgentResponse
from agentsec.adapters.ws_adapter import MockWebSocketAdapter
from agentsec.evaluator.deterministic_judge import DeterministicJudge
from agentsec.evaluator.judge_router import JudgeRouter
from agentsec.evaluator.no_op_judge import NoOpJudge
from agentsec.runner import run_suite
from agentsec.tests.models import TestCase


def _make_judge():
    noop = NoOpJudge()
    return JudgeRouter(llm=noop, deterministic=DeterministicJudge(), hybrid=noop)


class FixedAdapter(AgentAdapter):
    """Returns a fixed content string on every send()."""
    def __init__(self, reply: str = "safe response"):
        self.reply = reply
        self.calls: list[tuple[str, str]] = []

    async def send(self, message: str, session_id: str) -> AgentResponse:
        self.calls.append((message, session_id))
        return AgentResponse(content=self.reply, raw={})


def _http_only_case(case_id: str = "t1") -> TestCase:
    return TestCase(
        id=case_id,
        category="cross_channel",
        description="plain HTTP test",
        attack="test payload",
        expected_behavior="refusal",
        severity="high",
        judge_type="deterministic",
    )


def _alternating_case() -> TestCase:
    return TestCase(
        id="alt-01",
        category="cross_channel",
        description="alternating http+ws",
        turns=[
            {"attack": "http message", "channel": "http"},
            {"attack": "ws message", "channel": "ws", "judge_after": True},
        ],
        expected_behavior="refusal",
        severity="high",
        judge_type="deterministic",
    )


def _concurrent_case() -> TestCase:
    return TestCase(
        id="obs-01",
        category="cross_channel",
        description="concurrent observe",
        turns=[{"attack": "http attack", "judge_after": True}],
        expected_behavior="refusal",
        severity="high",
        judge_type="deterministic",
        ws_concurrent_observe=True,
        ws_listen_duration_s=5.0,
    )


@pytest.mark.asyncio
async def test_ws_case_skipped_when_no_ws_adapter():
    """A test needing WS is marked SKIP when ws_adapter=None."""
    tc = _alternating_case()
    http_adapter = FixedAdapter()
    results = await run_suite(http_adapter, _make_judge(), [tc], ws_adapter=None)
    assert len(results) == 1
    assert results[0].status == "skipped"
    assert results[0].skipped_reason is not None
    assert "ws" in results[0].skipped_reason.lower()


@pytest.mark.asyncio
async def test_concurrent_observe_case_skipped_when_no_ws_adapter():
    """ws_concurrent_observe case is SKIP when ws_adapter=None."""
    tc = _concurrent_case()
    results = await run_suite(FixedAdapter(), _make_judge(), [tc], ws_adapter=None)
    assert results[0].status == "skipped"


@pytest.mark.asyncio
async def test_http_only_case_unaffected_without_ws_adapter():
    """Plain HTTP case still runs when ws_adapter=None."""
    tc = _http_only_case()
    results = await run_suite(FixedAdapter("safe response"), _make_judge(), [tc], ws_adapter=None)
    assert results[0].status in ("passed", "failed")  # not skipped


@pytest.mark.asyncio
async def test_alternating_mode_routes_ws_turn_to_ws_adapter():
    """WS turns are sent to ws_adapter, HTTP turns to the HTTP adapter."""
    http_adapter = FixedAdapter("http-reply")
    ws_adapter = MockWebSocketAdapter(send_reply="ws-reply")
    tc = _alternating_case()
    await run_suite(http_adapter, _make_judge(), [tc], ws_adapter=ws_adapter)
    assert len(http_adapter.calls) == 1
    assert http_adapter.calls[0][0] == "http message"
    assert len(ws_adapter.send_calls) == 1
    assert ws_adapter.send_calls[0][0] == "ws message"


@pytest.mark.asyncio
async def test_alternating_mode_same_session_id_across_channels():
    """Both adapters receive the same session_id."""
    http_adapter = FixedAdapter()
    ws_adapter = MockWebSocketAdapter(send_reply="ok")
    tc = _alternating_case()
    await run_suite(http_adapter, _make_judge(), [tc], ws_adapter=ws_adapter)
    assert http_adapter.calls[0][1] == ws_adapter.send_calls[0][1]


@pytest.mark.asyncio
async def test_concurrent_observe_merges_ws_content_into_response():
    """WS messages appear in the observation response after '--- WS ---'."""
    http_adapter = FixedAdapter("http-content")
    ws_adapter = MockWebSocketAdapter(listen_data="ws-observation")
    tc = _concurrent_case()
    results = await run_suite(http_adapter, _make_judge(), [tc], ws_adapter=ws_adapter)
    obs = results[0].observations
    assert obs, "should have at least one observation"
    merged = obs[-1]["response"]["content"]
    assert "http-content" in merged
    assert "ws-observation" in merged
    assert "--- WS ---" in merged


@pytest.mark.asyncio
async def test_concurrent_observe_calls_listen_not_send_on_ws_adapter():
    """In concurrent-observe mode, ws_adapter.listen() is called, not send()."""
    ws_adapter = MockWebSocketAdapter(listen_data="data")
    tc = _concurrent_case()
    await run_suite(FixedAdapter(), _make_judge(), [tc], ws_adapter=ws_adapter)
    assert len(ws_adapter.listen_calls) == 1
    assert ws_adapter.send_calls == []


@pytest.mark.asyncio
async def test_concurrent_observe_adapter_failure_returns_error():
    """Adapter failure in concurrent-observe mode returns error, not runtime error."""
    class FailingAdapter(AgentAdapter):
        async def send(self, message: str, session_id: str) -> AgentResponse:
            raise RuntimeError("simulated adapter failure")

    ws_adapter = MockWebSocketAdapter(listen_data="ws-data")
    tc = _concurrent_case()
    results = await run_suite(FailingAdapter(), _make_judge(), [tc], ws_adapter=ws_adapter)
    assert results[0].status == "error"
    assert "adapter" in results[0].error.lower()
