from agentsec.audit.checks.base import CheckStatus
from agentsec.audit.findings import Finding
from agentsec.audit.server_audit import ServerAuditReport
from agentsec.reports.attack_paths import (
    AttackPath,
    AttackPathStep,
    derive_attack_paths,
)
from agentsec.reports.markdown import (
    TargetDescriptor,
    render_combined_report,
    render_remote_report,
    render_server_audit_report,
)
from agentsec.scoring import (
    CategoryScore,
    CombinedScore,
    CoverageTriple,
    EvaluationScore,
)
from agentsec.tests.models import Severity, TestResult


def _trivial_score(*, low_coverage: bool = False) -> EvaluationScore:
    return EvaluationScore(
        category_scores=[
            CategoryScore(
                category="ssrf", score=80.0, severity_weight_factor=1.0,
                passed=4, failed=1, worst_failed_severity=None, is_scored=True,
            ),
        ],
        remote_score=80.0, server_score=92,
        combined=CombinedScore(
            score=86.0, weight_remote_used=0.5,
            weight_server_used=0.5, note=None,
        ),
        coverage=CoverageTriple(
            planned=5, executed=5, scored=5, error=0,
            execution_coverage=1.0, verdict_coverage=1.0, error_rate=0.0,
        ) if not low_coverage else CoverageTriple(
            planned=10, executed=2, scored=2, error=0,
            execution_coverage=0.2, verdict_coverage=0.2, error_rate=0.0,
        ),
        low_coverage=low_coverage,
        grade="B" if not low_coverage else "INSUFFICIENT_COVERAGE",
        deduped_findings=[],
    )


def test_render_remote_report_summary_failures_and_score(tmp_path):
    results = [
        TestResult(
            test_id="pi-001", category="prompt_injection", severity=Severity.high,
            status="passed",
            verdict={"passed": True, "reasoning": "safe", "evidence": {}, "judge_type": "llm"},
            observations=[{"response": {"content": "I will not."}}],
        ),
        TestResult(
            test_id="dl-003", category="data_leakage", severity=Severity.critical,
            status="failed",
            verdict={
                "passed": False, "reasoning": "leaked credentials",
                "evidence": {}, "judge_type": "llm",
            },
            observations=[{"response": {"content": "Here is sk-ant-..."}}],
        ),
    ]
    md = render_remote_report("openclaw-prod", results, _trivial_score())
    assert "openclaw-prod" in md
    assert "通过：1" in md and "失败：1" in md
    assert "dl-003" in md
    assert "## 评分" in md            # new section vs Stage E
    assert "远程套件得分：80.0" in md
    assert "等级：B" in md
    assert "ssrf" in md.lower()        # category breakdown table


def test_render_remote_report_low_coverage_banner():
    md = render_remote_report("x", [], _trivial_score(low_coverage=True))
    assert "LOW_COVERAGE" in md
    assert "INSUFFICIENT_COVERAGE" in md


def test_render_server_audit_report_lifts_inline_renderer():
    f = Finding(
        check="exposure_scan", severity="high", title="port 8443 open",
        description="d", evidence={"port": 8443}, remediation="r", threat_refs=[],
    )
    statuses = {"native_audit": CheckStatus()}
    statuses["native_audit"].not_applicable("uname is freebsd")
    report = ServerAuditReport(findings=[f], statuses=statuses, errors={})

    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/home/u",
        low_assurance=True, server_score=92,
    )
    # Header + section structure
    assert "# 服务器安全审计报告" in md
    assert "## 1. 报告概览" in md
    assert "## 2. 执行摘要" in md
    assert "### 2.1 风险态势" in md
    assert "### 2.2 攻击路径" in md  # new section between 2.1 and the priority list
    assert "### 2.3 最高优先级修复" in md
    assert "## 3. 详细发现" in md
    assert "## 4. 未执行 / 不适用的检查" in md
    assert "## 5. 错误" in md
    assert "## 附录 A：机读元数据" in md
    # Concrete finding rendered with full detail
    assert "exposure_scan" in md
    assert "port 8443 open" in md
    assert "**检查项**：`exposure_scan`" in md
    # Score + low-assurance banner
    assert "服务器审计得分 | **92**" in md
    assert "LOW_ASSURANCE" in md
    # Machine-readable anchors preserved in appendix
    assert "<!-- meta:profile value:linux -->" in md
    assert "<!-- meta:remote_home value:/home/u -->" in md
    assert "<!-- meta:findings_high count:1 -->" in md
    assert "<!-- check:native_audit status:not_applicable" in md


def test_render_combined_report_links_to_other_two():
    md = render_combined_report(
        "openclaw-prod", _trivial_score(),
        remote_present=True, server_present=True,
    )
    assert "综合评估报告" in md
    assert "等级：B" in md
    assert "remote-report.md" in md
    assert "server-audit-report.md" in md


def _vp_finding(cve: str, severity: str, fixed: str, **extra) -> Finding:
    """Build a synthetic version_patch finding shaped like real NVD-seeded data."""
    evidence = {
        "running_version": "2026.2.3.post1",
        "affected_versions": [f"<{fixed}"],
        "fixed_in": fixed,
        "cve_db_url": f"https://nvd.nist.gov/vuln/detail/{cve}",
        "cve_db_confidence": "medium",
        **extra,
    }
    return Finding(
        check="version_patch",
        severity=severity,
        title=f"TI-OPENCLAW-{cve}：当前版本 2026.2.3.post1 受影响",
        description=(
            f"OpenClaw versions prior to {fixed} contain a serious bug that "
            "allows escalation. (seeded from NVD; please review)"
        ),
        evidence=evidence,
        remediation=f"升级到 {fixed} 或更高版本",
        threat_refs=[f"TI-OPENCLAW-{cve}"],
    )


def test_server_audit_report_includes_table_of_contents():
    f = Finding(
        check="exposure_scan", severity="medium", title="port open",
        description="d", evidence={"port": 80}, remediation="r", threat_refs=[],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    assert "## 目录" in md
    assert "[报告概览](#1-报告概览)" in md
    assert "[详细发现](#3-详细发现)" in md
    assert "[附录 A：机读元数据](#附录-a机读元数据)" in md


def test_server_audit_report_renders_severity_pie_when_findings_exist():
    f = Finding(
        check="exposure_scan", severity="high", title="port", description="d",
        evidence={}, remediation="r", threat_refs=[],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    assert '<svg xmlns="http://www.w3.org/2000/svg"' in md
    assert '<title>严重度分布</title>' in md
    assert 'fill="#ea580c"' in md  # high → orange


def test_server_audit_report_skips_pie_when_no_findings():
    report = ServerAuditReport(findings=[], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=100,
    )
    assert "<svg" not in md
    assert "_本次审计未发现任何 finding。所有已执行 check 均通过。_" in md


def test_server_audit_report_aggregates_version_patch_overview():
    findings = [
        _vp_finding("CVE-2026-1001", "critical", "2026.3.1"),
        _vp_finding("CVE-2026-1002", "high", "2026.3.2"),
        _vp_finding("CVE-2026-1003", "medium", "2026.3.3"),
        # one non-version_patch finding to confirm it lands in §3.x not §3.0
        Finding(
            check="exposure_scan", severity="medium", title="port 80 open",
            description="d", evidence={"port": 80}, remediation="r", threat_refs=[],
        ),
    ]
    report = ServerAuditReport(findings=findings, statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=50,
    )
    # §3.0 overview table appears with row count
    assert "### 3.0 version_patch — CVE 总览（3 条）" in md
    assert "当前运行版本：`2026.2.3.post1`" in md
    # CVE id column entries
    assert "`CVE-2026-1001`" in md
    assert "`CVE-2026-1002`" in md
    assert "`CVE-2026-1003`" in md
    # Per-CVE detail cards live inside <details>; non-vp finding does not
    assert "<details>" in md
    assert "</details>" in md
    # Localised title for version_patch — raw TI prefix should not leak into
    # the detail card title.
    assert "[CVE-2026-1001] OpenClaw 版本受影响（受影响 <2026.3.1，已修复 2026.3.1）" in md
    assert "TI-OPENCLAW-CVE-2026-1001：当前版本" not in md
    # exposure_scan finding goes into §3.x (not §3.0). Note that the attack
    # path scenario 外网暴露+CVE may also reference its title in §2.2, so we
    # only assert it appears in §3.x and never inside the §3.0 <details>.
    assert "port 80 open" in md
    detail_block = md.split("<details>", 1)[1].split("</details>", 1)[0]
    assert "port 80 open" not in detail_block


def test_server_audit_report_priority_list_lists_all_critical():
    findings = [
        _vp_finding(f"CVE-2026-{1000 + i:04d}", "critical", "2026.3.1")
        for i in range(8)
    ]
    findings += [
        _vp_finding(f"CVE-2026-{2000 + i:04d}", "high", "2026.3.1")
        for i in range(15)
    ]
    report = ServerAuditReport(findings=findings, statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=20,
    )
    assert "### 2.3 最高优先级修复" in md
    # All 8 critical enumerated
    assert "**严重（critical） —— 全部 8 条：**" in md
    # High capped at 10/15 with tail count
    assert "**高（high） —— top 10 / 15：**" in md
    assert "… 还有 5 条 high 详见 §3。" in md


def test_server_audit_report_renders_check_distribution_table():
    findings = [
        _vp_finding("CVE-2026-9001", "high", "2026.3.1"),
        Finding(
            check="exposure_scan", severity="medium", title="port",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
        Finding(
            check="native_audit", severity="critical", title="native crit",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
    ]
    report = ServerAuditReport(findings=findings, statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=40,
    )
    assert "### 2.4 Check 维度分布" in md
    assert "| `version_patch` | 1 |" in md
    assert "| `exposure_scan` | 1 |" in md
    assert "| `native_audit` | 1 |" in md


def test_server_audit_report_skips_check_distribution_for_single_check():
    f = Finding(
        check="exposure_scan", severity="high", title="t", description="d",
        evidence={}, remediation="r", threat_refs=[],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    assert "### 2.4 Check 维度分布" not in md


def test_finding_block_promotes_kev_and_cvss_into_badge_line():
    f = Finding(
        check="version_patch", severity="critical",
        title="TI-OPENCLAW-CVE-2026-9999：当前版本 X 受影响",
        description="seeded text",
        evidence={
            "fixed_in": "2026.3.1",
            "running_version": "2026.2.0",
            "affected_versions": ["<2026.3.1"],
            "kev": True,
            "cvss": 9.8,
            "cve_db_url": "https://example/CVE-2026-9999",
            "cve_db_confidence": "high",
        },
        remediation="r", threat_refs=["TI-OPENCLAW-CVE-2026-9999"],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=10,
    )
    # Badge line carries CVSS + KEV; it must not appear inside `证据`.
    assert "**CVSS 9.8**" in md
    assert "**🚨 CISA KEV**" in md
    # Redundant evidence keys are stripped from the evidence bullet block.
    # We search for the rendered bullet form (`  - \`<key>\`：`) rather than
    # the bare backticked key, because the scenario id `kev` is allowed to
    # appear elsewhere (e.g. in attack-path metadata).
    assert "  - `kev`：" not in md
    assert "  - `cvss`：" not in md
    assert "  - `cve_db_url`：" not in md
    # The cve_db_url shows up as a [↗] link next to the title once
    assert "[↗](https://example/CVE-2026-9999)" in md


def test_finding_block_quotes_nvd_seeded_descriptions():
    f = Finding(
        check="version_patch", severity="high",
        title="TI-OPENCLAW-CVE-2026-1234：当前版本 受影响",
        description="OpenClaw before 2026.3 is bad. (seeded from NVD; please review)",
        evidence={"fixed_in": "2026.3", "affected_versions": ["<2026.3"]},
        remediation="r", threat_refs=["TI-OPENCLAW-CVE-2026-1234"],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=50,
    )
    assert "**描述**（来源：NVD seed，未经本地翻译）：" in md
    assert "> OpenClaw before 2026.3 is bad." in md
    # Trailing "(seeded from NVD; please review)" tag stripped from quoted body
    assert "(seeded from NVD" not in md


def test_finding_block_fingerprint_no_ellipsis():
    f = Finding(
        check="exposure_scan", severity="high", title="t", description="d",
        evidence={}, remediation="r", threat_refs=[],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    # 16 hex chars, mono-quoted, no trailing ellipsis
    assert "`" + f.fingerprint[:16] + "`" in md
    assert f.fingerprint[:16] + "…" not in md


def test_score_block_rounds_long_tail_floats():
    score = _trivial_score().model_copy(update={
        "remote_score": 33.333333333333336,
        "combined": CombinedScore(
            score=62.16666666666667, weight_remote_used=0.5,
            weight_server_used=0.5, note=None,
        ),
    })
    md = render_combined_report(
        "x", score, remote_present=True, server_present=True,
    )
    # Visible bullets round to one decimal — raw long-tail bytes must not
    # leak into the human-readable section. (The <!-- meta:... --> machine
    # anchors keep the unrounded value for downstream parsers.)
    assert "- 远程套件得分：33.3" in md
    assert "- 综合得分：62.2" in md
    assert "- 远程套件得分：33.333333333333336" not in md
    assert "- 综合得分：62.16666666666667" not in md


def test_severity_pie_uses_severity_palette():
    """Pie slice colours are written directly into SVG `fill` attributes —
    no mermaid theme indirection that some renderers ignore."""
    findings = [
        Finding(
            check="exposure_scan", severity="critical", title="t",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
        Finding(
            check="exposure_scan", severity="medium", title="t",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
    ]
    report = ServerAuditReport(findings=findings, statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    # Inline SVG, not mermaid
    assert '<svg xmlns="http://www.w3.org/2000/svg"' in md
    assert "</svg>" in md
    # First non-empty slice (critical) → red; second (medium) → yellow.
    assert 'fill="#dc2626"' in md
    assert 'fill="#eab308"' in md
    # Order matters for clockwise sweep — critical path comes before medium.
    assert md.index('fill="#dc2626"') < md.index('fill="#eab308"')


def test_severity_pie_legend_lists_every_slice_with_count_and_percent():
    """Every severity present must appear in the SVG legend with both the
    raw count and percentage — including small slices that don't fit an
    in-pie label."""
    findings: list[Finding] = []
    # 92 medium, 5 high, 2 low → low is ~2 % (well below the in-pie threshold)
    for _ in range(92):
        findings.append(Finding(
            check="version_patch", severity="medium", title="t",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ))
    for _ in range(5):
        findings.append(Finding(
            check="exposure_scan", severity="high", title="t",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ))
    for _ in range(2):
        findings.append(Finding(
            check="exposure_scan", severity="low", title="t",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ))
    report = ServerAuditReport(findings=findings, statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=50,
    )
    # Every visible severity has a `<rect fill="...">` color box and a
    # legend `<text>` entry with name + count + percentage.
    # total = 99 → medium 92.9 % / high 5.1 % / low 2.0 %
    assert '中 · 92 (92.9%)' in md
    assert '高 · 5 (5.1%)' in md
    assert '低 · 2 (2.0%)' in md   # small slice — must still surface
    # Severities with zero findings don't appear in the legend
    assert '严重 ·' not in md
    assert '信息 ·' not in md


def test_severity_pie_renders_single_slice_as_full_circle():
    """One severity present → SVG `<circle>` rather than a degenerate arc."""
    findings = [
        Finding(
            check="exposure_scan", severity="high", title="t",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
    ] * 3
    report = ServerAuditReport(findings=findings, statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    assert '<circle' in md
    assert 'fill="#ea580c"' in md  # all-high → orange
    # Degenerate `<path d=...A...0,0 Z>` (zero-area arc) must not be emitted
    assert '<path d="M' not in md


def test_overview_renders_target_descriptor_fields():
    descriptor = TargetDescriptor(
        host="34.208.65.73",
        user="ubuntu",
        key_path="~/.ssh/id_rsa",
        auth_file="./openclaw-target/AUTHORIZATION.txt",
        openclaw_bin="/home/ubuntu/.local/bin/openclaw",
        openclaw_version="2026.2.3.post1",
        checks_run=("native_audit", "version_patch", "exposure_scan"),
    )
    report = ServerAuditReport(findings=[], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/home/ubuntu",
        low_assurance=False, server_score=92,
        target=descriptor,
    )
    # §1.1 table rows
    assert "### 1.1 审计目标" in md
    assert "| 目标主机 | `34.208.65.73` |" in md
    assert "| SSH 登录用户 | `ubuntu` |" in md
    assert "| SSH 私钥路径 | `~/.ssh/id_rsa` |" in md
    assert "| OpenClaw 版本 | `2026.2.3.post1` |" in md
    assert "| OpenClaw 安装路径 | `/home/ubuntu/.local/bin/openclaw` |" in md
    assert "| AUTHORIZATION 文件 | `./openclaw-target/AUTHORIZATION.txt` |" in md
    # §1.2 method block
    assert "### 1.2 审计方法" in md
    assert "本次执行 3 项 check" in md
    assert "`native_audit`" in md
    # §1.3 topology
    assert "### 1.3 审计逻辑拓扑" in md
    assert "```mermaid" in md
    assert "flowchart LR" in md
    assert "34.208.65.73" in md


def test_overview_falls_back_when_descriptor_absent():
    """No descriptor → §1 still renders the minimal set (profile / home /
    score / total / timestamp), but no §1.2 / §1.3."""
    f = Finding(
        check="exposure_scan", severity="high", title="t",
        description="d", evidence={}, remediation="r", threat_refs=[],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    assert "### 1.1 审计目标" in md
    assert "| 平台 profile | `linux` |" in md
    # §1.2 / §1.3 rely on descriptor and must be skipped
    assert "### 1.2 审计方法" not in md
    assert "### 1.3 审计逻辑拓扑" not in md


def test_overview_auto_fills_openclaw_version_from_findings():
    """version_patch findings always carry running_version → renderer can
    pre-populate the descriptor row even when the caller didn't pass it."""
    f = _vp_finding("CVE-2026-7777", "high", "2026.3.1")
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
        target=TargetDescriptor(host="x", user="u", key_path="k"),
    )
    assert "| OpenClaw 版本 | `2026.2.3.post1` |" in md


def test_attack_paths_section_always_renders_with_disclaimer():
    """Even when no scenario triggers, §2.2 still appears with a stub so
    readers know the heuristic ran."""
    f = Finding(
        check="exposure_scan", severity="medium", title="t",
        description="d", evidence={}, remediation="r", threat_refs=[],
    )
    report = ServerAuditReport(findings=[f], statuses={}, errors={})
    md = render_server_audit_report(
        report, profile_name="linux", remote_home="/h",
        low_assurance=False, server_score=80,
    )
    assert "### 2.2 攻击路径" in md
    # Heuristic disclaimer
    assert "启发式推断" in md
    # No scenarios triggered for a single exposure_scan finding
    assert "_当前 finding 集合不满足任一内置攻击路径模板的触发条件_" in md


def test_attack_paths_external_attacker_scenario():
    """exposure_scan + high-severity version_patch ⇒ scenario A triggers."""
    findings = [
        Finding(
            check="exposure_scan", severity="medium",
            title="未在白名单的监听端口：8443/tcp",
            description="d", evidence={"port": 8443},
            remediation="r", threat_refs=[],
        ),
        _vp_finding("CVE-2026-22172", "critical", "2026.3.12"),
        _vp_finding("CVE-2026-26316", "high", "2026.2.13"),
    ]
    paths = derive_attack_paths(findings)
    titles = [p.title for p in paths]
    assert any("未授权端口" in t for t in titles)
    # At least one scenario references the exposed port + a CVE id
    ext = next(p for p in paths if "未授权端口" in p.title)
    refs = [r for s in ext.steps for r in s.evidence_refs]
    assert any("CVE-2026-22172" in r or "CVE-2026-26316" in r for r in refs)


def test_attack_paths_kev_scenario_priority():
    """KEV findings win the top slot regardless of other data."""
    findings = [
        Finding(
            check="version_patch", severity="critical",
            title="TI-OPENCLAW-CVE-2026-9001：当前版本 受影响",
            description="d", evidence={"kev": True, "running_version": "1.0"},
            remediation="r", threat_refs=["TI-OPENCLAW-CVE-2026-9001"],
        ),
        Finding(
            check="exposure_scan", severity="high", title="port",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
        _vp_finding("CVE-2026-26316", "high", "2026.2.13"),
    ]
    paths = derive_attack_paths(findings)
    # KEV scenario is emitted first
    assert paths[0].scenario_id == "kev"
    refs = [r for s in paths[0].steps for r in s.evidence_refs]
    assert "CVE-2026-9001" in refs


def test_attack_paths_returns_empty_for_unrelated_findings():
    """A single check class with no cross-condition match → no scenarios."""
    findings = [
        Finding(
            check="exposure_scan", severity="medium", title="t",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
    ]
    paths = derive_attack_paths(findings)
    assert paths == []


def test_attack_path_step_object_shape():
    """Smoke: AttackPath/AttackPathStep are immutable dataclasses with the
    expected attribute surface."""
    step = AttackPathStep(
        description="x", evidence_refs=("CVE-1",), leveraged_check="version_patch",
    )
    p = AttackPath(
        title="t", summary="s", steps=(step,),
        scenario_id="x", severity_floor="high",
    )
    assert p.steps[0].leveraged_check == "version_patch"


def test_render_combined_report_remote_only_omits_server_link():
    score = _trivial_score()
    # Pretend server-side was not run.
    score = score.model_copy(update={
        "server_score": None,
        "combined": CombinedScore(
            score=80.0, weight_remote_used=1.0, weight_server_used=0.0,
            note="server-side score unavailable; remote weighted 100%",
        ),
    })
    md = render_combined_report(
        "x", score, remote_present=True, server_present=False,
    )
    assert "remote-report.md" in md
    assert "server-audit-report.md" not in md
    # server-side note is preserved verbatim from CombinedScore.note (English in this fixture)
    assert "server-side score unavailable" in md


def test_remote_report_renders_owasp_coverage_section():
    from agentsec.tests.models import Severity as S
    from agentsec.tests.models import TestCase, TestResult
    cases = [
        TestCase(id="pi-1", category="prompt_injection", description="d",
                 attack="a", expected_behavior="refusal", severity=S.medium,
                 owasp_refs=["LLM01:2025"]),
        TestCase(id="ta-1", category="tool_abuse", description="d",
                 attack="a", expected_behavior="refusal", severity=S.high,
                 owasp_refs=["LLM06:2025", "AGENTIC-T2"]),
    ]
    results = [
        TestResult(test_id="pi-1", category="prompt_injection",
                   severity=S.medium, status="passed", observations=[]),
        TestResult(test_id="ta-1", category="tool_abuse",
                   severity=S.high, status="failed", observations=[]),
    ]
    md = render_remote_report("agent-x", results, _trivial_score(), cases=cases)
    assert "## OWASP 框架覆盖" in md
    assert "### OWASP Top 10 for LLM Applications (2025)" in md
    assert "| LLM01:2025 | Prompt Injection | 1 | 1 | 0 | 0 | 0 |" in md
    assert "| LLM06:2025 | Excessive Agency | 1 | 0 | 1 | 0 | 0 |" in md
    # LLM10 not covered → still has a 0-row
    assert "| LLM10:2025 | Unbounded Consumption | 0 | 0 | 0 | 0 | 0 |" in md
    assert "### OWASP Agentic AI Threats (v1.1)" in md
    assert "| AGENTIC-T2 | Tool Misuse | 1 | 0 | 1 | 0 | 0 |" in md
    assert "### OWASP MCP Top 10 (AgentSec curated v1)" in md
    for i in range(1, 11):
        assert f"| MCP{i} " in md or f"| MCP{i}|" in md


def test_combined_report_renders_owasp_coverage_section():
    from agentsec.tests.models import Severity as S
    from agentsec.tests.models import TestCase, TestResult
    cases = [
        TestCase(id="pi-1", category="prompt_injection", description="d",
                 attack="a", expected_behavior="refusal", severity=S.medium,
                 owasp_refs=["LLM01:2025"]),
    ]
    results = [
        TestResult(test_id="pi-1", category="prompt_injection",
                   severity=S.medium, status="passed", observations=[]),
    ]
    md = render_combined_report(
        "x", _trivial_score(),
        remote_present=True, server_present=False,
        cases=cases, results=results,
    )
    assert "## OWASP 框架覆盖" in md
    assert "| LLM01:2025 | Prompt Injection | 1 | 1 | 0 | 0 | 0 |" in md
    assert "### OWASP MCP Top 10 (AgentSec curated v1)" in md
    for i in range(1, 11):
        assert f"| MCP{i} " in md or f"| MCP{i}|" in md


def test_combined_report_omits_owasp_section_when_no_cases():
    md = render_combined_report(
        "x", _trivial_score(),
        remote_present=True, server_present=False,
    )
    # Without cases= argument, the section should not be emitted.
    assert "## OWASP 框架覆盖" not in md
