"""PodmanRuntimeAuditCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.podman_runtime_audit import PodmanRuntimeAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"
_BIN = "/usr/bin/podman"
_INFO = ("podman", "info", "--format", "{{json .}}")
_PS = ("podman", "ps", "--format", "{{json .}}", "--no-trunc")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=argv, command_sha256="0"*64,
                      duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found):
    out = {}
    for c in ("/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman"):
        if c == found:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c + "\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_not_applicable_no_podman():
    ctx = _ctx(_RecordingExecutor(_detect_responses(None)))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_ps_empty_no_findings():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout="")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []


def test_inspect_compliant_zero_findings():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_line = '{"Id":"abc1234567890","Image":"nginx:1.25","Names":["web"]}'
    inspect = (_FIXTURES / "podman_inspect_compliant.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []


def test_inspect_privileged_critical():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_line = '{"Id":"abc1234567890","Image":"nginx:1.25","Names":["web"]}'
    inspect = (_FIXTURES / "podman_inspect_privileged.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    privileged = [f for f in findings if f.evidence.get("rule_id") == "runtime-privileged"]
    assert len(privileged) == 1
    assert privileged[0].severity == "critical"
    assert privileged[0].evidence["runtime"] == "podman"


def test_inspect_host_net_and_sock_mount():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_line = '{"Id":"abc1234567890"}'
    inspect = (_FIXTURES / "podman_inspect_host_net_sock_mount.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    rule_ids = {f.evidence["rule_id"] for f in findings}
    assert "runtime-host-net" in rule_ids
    assert "runtime-sock-mount" in rule_ids


def test_inspect_caps_user_multi():
    # rootful → root user normal severity
    info = (_FIXTURES / "podman_info_rootful.json").read_text()
    ps_line = '{"Id":"abc1234567890"}'
    inspect = (_FIXTURES / "podman_inspect_caps_user.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    cap_findings = [f for f in findings if f.evidence.get("rule_id") == "runtime-cap-dangerous"]
    user_findings = [f for f in findings if f.evidence.get("rule_id") == "runtime-root-user"]
    assert len(cap_findings) == 2  # SYS_ADMIN + NET_ADMIN
    assert len(user_findings) == 1
    assert user_findings[0].severity == "medium"  # rootful → not downgraded


def test_rootless_root_user_downgrade():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()  # rootless = True
    ps_line = '{"Id":"abc1234567890"}'
    inspect = (_FIXTURES / "podman_inspect_caps_user.json").read_text()  # User=root
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    user_findings = [f for f in findings if f.evidence.get("rule_id") == "runtime-root-user"]
    assert len(user_findings) == 1
    assert user_findings[0].severity == "low"  # downgraded


def test_inspect_failure_partial_scan():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_lines = (
        '{"Id":"abc1234567890"}\n'
        '{"Id":"def9876543210"}'
    )
    inspect = (_FIXTURES / "podman_inspect_compliant.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_lines)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    responses[("podman", "inspect", "def9876543210")] = _runresult(
        stderr="No such container", exit_code=1,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    skipped_info = [f for f in findings
                    if f.evidence.get("skipped_container_ids")]
    assert len(skipped_info) == 1
    assert "def9876543210" in skipped_info[0].evidence["skipped_container_ids"]
