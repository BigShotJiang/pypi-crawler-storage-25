"""RustSupplyChainAuditCheck — _safe_parse_cargo_version edge cases (Phase 7d.cleanup M2)."""

from __future__ import annotations

from agentsec.audit.checks.rust_supply_chain_audit import _safe_parse_cargo_version

# ---- _safe_parse_cargo_version defensive edge cases (M2) ----

def test_safe_parse_cargo_version_empty_string():
    """Empty string must return None without raising."""
    assert _safe_parse_cargo_version("") is None


def test_safe_parse_cargo_version_bare_prefix():
    """Bare 'v' is not valid semver 2.0 (Cargo has no v prefix) → None."""
    assert _safe_parse_cargo_version("v") is None


def test_safe_parse_cargo_version_double_prefix():
    """'vv1.2.3' is not valid semver 2.0 → None."""
    assert _safe_parse_cargo_version("vv1.2.3") is None


def test_safe_parse_cargo_version_long_garbage():
    """1000-char garbage string must return None without raising."""
    assert _safe_parse_cargo_version("x" * 1000) is None
