import pytest

from agentsec.observability.network_observer import FixtureOnlyObserver
from agentsec.observability.runtime import (
    FixtureRuntime,
    resolve_serve_via,
    substitute_fixture_url,
)
from agentsec.tests.models import Fixture


def test_resolve_auto_picks_reachable_when_public_base_url_set():
    fx = Fixture(
        type="web_page",
        path="x",
        serve_via="auto",
        public_base_url="http://eval.lan:{port}",
    )
    assert resolve_serve_via(fx, evaluator_and_target_same_host=False) == "reachable-url"


def test_resolve_auto_picks_loopback_when_same_host_and_no_public_url():
    fx = Fixture(type="web_page", path="x", serve_via="auto")
    assert resolve_serve_via(fx, evaluator_and_target_same_host=True) == "same-host-loopback"


def test_resolve_auto_fails_fast_when_neither_applies():
    fx = Fixture(type="web_page", path="x", serve_via="auto")
    with pytest.raises(ValueError) as exc:
        resolve_serve_via(fx, evaluator_and_target_same_host=False)
    assert "public_base_url" in str(exc.value)


def test_resolve_explicit_value_passes_through():
    fx = Fixture(type="web_page", path="x", serve_via="ssh-port-forward")
    assert resolve_serve_via(fx, evaluator_and_target_same_host=True) == "ssh-port-forward"


def test_substitute_fixture_url_replaces_placeholder():
    out = substitute_fixture_url("hit {{fixture_url}}/page.html", "http://x:1")
    assert out == "hit http://x:1/page.html"


def test_substitute_fixture_url_no_placeholder_returns_unchanged():
    assert substitute_fixture_url("plain text", "http://x:1") == "plain text"


@pytest.mark.asyncio
async def test_runtime_lifecycle_for_loopback(tmp_path):
    (tmp_path / "p.html").write_text("ok")
    fx = Fixture(type="web_page", path="p.html", serve_via="same-host-loopback")
    rt = FixtureRuntime(
        fixture=fx,
        suite_root=tmp_path,
        observer=FixtureOnlyObserver(),
        evaluator_and_target_same_host=True,
    )
    async with rt.active() as base_url:
        assert base_url.startswith("http://127.0.0.1:")


@pytest.mark.asyncio
async def test_runtime_ssh_requires_transport(tmp_path):
    fx = Fixture(type="web_page", path="x", serve_via="ssh-port-forward")
    rt = FixtureRuntime(
        fixture=fx,
        suite_root=tmp_path,
        observer=FixtureOnlyObserver(),
        evaluator_and_target_same_host=False,
    )
    with pytest.raises(ValueError) as exc:
        async with rt.active():
            pass
    assert "ssh_transport" in str(exc.value) or "ssh-port-forward" in str(exc.value)
