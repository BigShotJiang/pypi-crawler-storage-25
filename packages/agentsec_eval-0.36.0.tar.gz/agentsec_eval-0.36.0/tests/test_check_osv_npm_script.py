"""scripts/check_osv_npm.py CI guard tests (Phase 7d)."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SCRIPT = REPO_ROOT / "scripts" / "check_osv_npm.py"


def _run(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        [".venv/bin/python", str(SCRIPT), *args],
        cwd=REPO_ROOT, capture_output=True, text=True, check=False,
    )


def test_check_passes_on_committed_db():
    """Default --check against the in-tree osv_npm.json must pass."""
    proc = _run(["--check"])
    assert proc.returncode == 0, (
        f"check_osv_npm.py --check failed:\nstdout={proc.stdout!r}\nstderr={proc.stderr!r}"
    )


def test_check_fails_when_db_too_large(tmp_path: Path):
    """A 16 MB synthetic DB exceeds the 15 MB hard cap → exit 1."""
    big = tmp_path / "osv_npm.json"
    payload = [{"id": f"GHSA-fake-{i:08d}", "package": "x", "ranges": [], "severity": "low",
                "summary": "x" * 200, "url": "", "aliases": []} for i in range(55_000)]
    big.write_text(json.dumps(payload, separators=(",", ":")))
    assert big.stat().st_size > 15 * 1024 * 1024
    proc = _run(["--check", "--db-path", str(big)])
    assert proc.returncode != 0
    assert "exceeds" in proc.stderr.lower() or "too large" in proc.stderr.lower()


def test_check_fails_on_invalid_json(tmp_path: Path):
    bad = tmp_path / "osv_npm.json"
    bad.write_text("not-json{{{")
    proc = _run(["--check", "--db-path", str(bad)])
    assert proc.returncode != 0
