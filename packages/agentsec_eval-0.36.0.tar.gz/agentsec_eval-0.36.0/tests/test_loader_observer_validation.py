import pytest

from agentsec.observability.network_observer import NetworkObserverConfig
from agentsec.tests.loader import load_test_suite


def _suite_with_outbound_assertion(tmp_path, target):
    p = tmp_path / "s.yaml"
    p.write_text(f"""
- id: t1
  category: ipi
  description: d
  attack: a
  expected_behavior: refusal
  severity: high
  assertions:
    - type: outbound_request_not_to
      target: "{target}"
""")
    return p


def test_uncontrolled_target_rejected_in_fixture_only(tmp_path):
    p = _suite_with_outbound_assertion(tmp_path, "attacker.example.com")
    cfg = NetworkObserverConfig(
        mode="fixture_only",
        controlled_domains=["*.agentsec.test"],
    )
    with pytest.raises(ValueError) as exc:
        load_test_suite(p, observer_config=cfg)
    assert "attacker.example.com" in str(exc.value)
    assert "controlled_domains" in str(exc.value)


def test_controlled_target_accepted_in_fixture_only(tmp_path):
    p = _suite_with_outbound_assertion(tmp_path, "exfil.agentsec.test")
    cfg = NetworkObserverConfig(
        mode="fixture_only",
        controlled_domains=["*.agentsec.test"],
    )
    cases = load_test_suite(p, observer_config=cfg)
    assert len(cases) == 1


def test_no_observer_config_skips_validation(tmp_path):
    """Backward-compat: existing callers that don't pass observer_config still work."""
    p = _suite_with_outbound_assertion(tmp_path, "attacker.example.com")
    cases = load_test_suite(p)
    assert len(cases) == 1


def test_non_fixture_only_mode_skips_validation(tmp_path):
    """In reverse_proxy / dns_sink / egress_log modes, the observer can see
    arbitrary domains, so the load-time guard is fixture_only-specific."""
    p = _suite_with_outbound_assertion(tmp_path, "attacker.example.com")
    cfg = NetworkObserverConfig(mode="reverse_proxy", controlled_domains=[])
    cases = load_test_suite(p, observer_config=cfg)
    assert len(cases) == 1
