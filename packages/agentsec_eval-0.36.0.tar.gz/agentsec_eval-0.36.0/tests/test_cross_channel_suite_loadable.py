"""Schema validation for the cross-channel correlated attack suite."""
from pathlib import Path

from agentsec.observability.network_observer import NetworkObserverConfig
from agentsec.tests.loader import load_test_suite

SUITE_PATH = Path("test_suites/openclaw/11_cross_channel.yaml")
_OBS_CFG = NetworkObserverConfig(
    mode="fixture_only",
    controlled_domains=["*.agentsec.test", "*.openclaw.test", "169.254.169.254", "127.0.0.1"],
)

_EXPECTED_IDS = {
    "cc-alt-01", "cc-alt-02", "cc-alt-03",
    "cc-obs-01", "cc-obs-02", "cc-obs-03",
}
_ALTERNATING_IDS = {"cc-alt-01", "cc-alt-02", "cc-alt-03"}
_CONCURRENT_IDS = {"cc-obs-01", "cc-obs-02", "cc-obs-03"}


def test_suite_has_six_cases():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    assert len(cases) == 6


def test_all_case_ids_present():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    assert {c.id for c in cases} == _EXPECTED_IDS


def test_all_cases_are_cross_channel_category():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        assert c.category == "cross_channel", f"{c.id} has wrong category"


def test_all_cases_use_hybrid_judge():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        assert c.judge_type == "hybrid", f"{c.id} must use hybrid judge"


def test_alternating_cases_have_channel_fields():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        if c.id in _ALTERNATING_IDS:
            channels = {t.channel for t in (c.turns or [])}
            assert "ws" in channels, f"{c.id} must have at least one ws turn"


def test_concurrent_cases_have_ws_concurrent_observe():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        if c.id in _CONCURRENT_IDS:
            assert c.ws_concurrent_observe is True, (
                f"{c.id} must have ws_concurrent_observe=true"
            )


def test_cc_obs_03_has_custom_listen_duration():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    obs03 = next(c for c in cases if c.id == "cc-obs-03")
    assert obs03.ws_listen_duration_s == 8.0


def test_all_cases_reference_owasp_a5():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        assert "TI-OWASP-AGENTIC-2026-A5" in c.threat_refs, (
            f"{c.id} must reference TI-OWASP-AGENTIC-2026-A5"
        )


def test_obs02_references_cve_32915():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    obs02 = next(c for c in cases if c.id == "cc-obs-02")
    assert "TI-OPENCLAW-CVE-2026-32915" in obs02.threat_refs


def test_obs_cases_reference_cve_32918():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        if c.id in {"cc-obs-01", "cc-obs-03"}:
            assert "TI-OPENCLAW-CVE-2026-32918" in c.threat_refs, (
                f"{c.id} must reference TI-OPENCLAW-CVE-2026-32918"
            )
