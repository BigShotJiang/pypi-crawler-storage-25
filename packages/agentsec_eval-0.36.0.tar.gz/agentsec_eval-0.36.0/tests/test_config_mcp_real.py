"""McpRealConfig + OpenClawTargetConfig/TargetEntry mcp_real (Phase 7c.6)."""

from pathlib import Path

import pytest
from pydantic import ValidationError

from agentsec.config import (
    AuthorizationConfig,
    McpRealConfig,
    OpenClawTargetConfig,
    OutputConfig,
    ScoringConfig,
    TargetEntry,
)


def test_mcp_real_config_minimal():
    c = McpRealConfig(suite=Path("mcp_real_suites/x.yaml"))
    assert c.suite == Path("mcp_real_suites/x.yaml")
    assert c.model is None
    assert c.concurrency == 3
    assert c.max_iterations == 10


def test_mcp_real_config_extra_forbidden():
    with pytest.raises(ValidationError):
        McpRealConfig(suite=Path("x.yaml"), unknown="boom")  # type: ignore[call-arg]


def test_mcp_real_config_concurrency_min():
    with pytest.raises(ValidationError):
        McpRealConfig(suite=Path("x.yaml"), concurrency=0)


def test_mcp_real_config_max_iterations_min():
    with pytest.raises(ValidationError):
        McpRealConfig(suite=Path("x.yaml"), max_iterations=0)


def test_scoring_config_weight_mcp_default_zero():
    sc = ScoringConfig()
    assert sc.weight_mcp == 0.0


def test_scoring_config_weight_mcp_negative_rejected():
    with pytest.raises(ValidationError):
        ScoringConfig(weight_mcp=-0.1)


def test_openclaw_target_config_with_only_mcp_real():
    cfg = OpenClawTargetConfig(
        name="t",
        mcp_real=McpRealConfig(suite=Path("x.yaml")),
        output=OutputConfig(dir=Path("/tmp/x")),
        authorization=AuthorizationConfig(),
    )
    assert cfg.mcp_real is not None
    assert cfg.remote is None
    assert cfg.server_audit is None


def test_openclaw_target_config_all_three_absent_rejected():
    with pytest.raises(ValidationError, match="at least one"):
        OpenClawTargetConfig(
            name="t",
            output=OutputConfig(dir=Path("/tmp/x")),
            authorization=AuthorizationConfig(),
        )


def test_target_entry_with_only_mcp_real():
    te = TargetEntry(
        name="t",
        mcp_real=McpRealConfig(suite=Path("x.yaml")),
    )
    converted = te.to_openclaw_config(output_base=Path("/tmp"))
    assert converted.mcp_real is not None
    assert converted.mcp_real.suite == Path("x.yaml")


def test_target_entry_all_three_absent_rejected():
    with pytest.raises(ValidationError, match="at least one"):
        TargetEntry(name="t")
