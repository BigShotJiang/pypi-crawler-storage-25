"""Unit tests for SystemdUnitLintCheck (Phase 7e.1)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.systemd_unit_lint import (
    SystemdUnitLintCheck,
    _extract_service_section,
)
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult

UNIT_FIXTURES = Path(__file__).parent / "fixtures" / "linux_hardening" / "unit_files"

_FIND_ARGV = (
    "find", "/etc/systemd/system", "-maxdepth", "1",
    "-name", "*.service", "-type", "f",
)


def _build_responses(unit_paths: list[str]) -> dict[tuple, RunResult]:
    """find 返回列出的路径；每个 cat 返回对应 fixture 内容。"""
    listing = "\n".join(unit_paths) + ("\n" if unit_paths else "")
    responses: dict[tuple, RunResult] = {
        _FIND_ARGV: RunResult(
            stdout=listing, stderr="", exit_code=0,
            rejected=False, reject_reason=None, argv=list(_FIND_ARGV),
            command_sha256="0" * 64, duration_ms=0.0,
            bytes_out=len(listing.encode()),
        ),
    }
    for p in unit_paths:
        fixture = UNIT_FIXTURES / Path(p).name
        body = fixture.read_text() if fixture.exists() else ""
        responses[("cat", p)] = RunResult(
            stdout=body, stderr="", exit_code=0,
            rejected=False, reject_reason=None, argv=["cat", p],
            command_sha256="0" * 64, duration_ms=0.0,
            bytes_out=len(body.encode()),
        )
    return responses


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=0, rejected=False,
                reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name not in ("linux", "linux_user_mode"):
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def test_extract_service_section_returns_only_service_block():
    text = (UNIT_FIXTURES / "clean.service").read_text()
    section = _extract_service_section(text)
    assert "[Service]" not in section          # marker line stripped
    assert "ExecStart=/usr/local/bin" in section
    assert "[Install]" not in section
    assert "WantedBy=" not in section


def test_clean_unit_zero_findings():
    responses = _build_responses(["/etc/systemd/system/clean.service"])
    findings = _run(SystemdUnitLintCheck(), _ctx(_RecordingExecutor(responses)))
    assert findings == []


def test_writable_execstart_emits_high():
    responses = _build_responses(["/etc/systemd/system/writable_execstart.service"])
    findings = _run(SystemdUnitLintCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert findings[0].severity == "high"
    assert "writable_execstart" in findings[0].evidence["rules"]


def test_shellwrap_execstart_emits_high():
    responses = _build_responses(["/etc/systemd/system/shellwrap.service"])
    findings = _run(SystemdUnitLintCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert findings[0].severity == "high"
    assert "shellwrap_execstart" in findings[0].evidence["rules"]


def test_root_writable_combo_upgrades_to_critical():
    responses = _build_responses(["/etc/systemd/system/root_writable_combo.service"])
    findings = _run(SystemdUnitLintCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert findings[0].severity == "critical"
    assert "root_writable_combo" in findings[0].evidence["rules"]


def test_multiple_units_each_emit_independently():
    responses = _build_responses([
        "/etc/systemd/system/clean.service",
        "/etc/systemd/system/writable_execstart.service",
        "/etc/systemd/system/root_writable_combo.service",
    ])
    findings = _run(SystemdUnitLintCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 2  # clean has zero
    severities = sorted(f.severity for f in findings)
    assert severities == ["critical", "high"]


def test_skips_on_macos_profile():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(SystemdUnitLintCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_find_rejected_marks_skipped():
    responses = {
        _FIND_ARGV: RunResult(
            stdout="", stderr="", exit_code=0,
            rejected=True, reject_reason="policy", argv=list(_FIND_ARGV),
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        ),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(SystemdUnitLintCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_individual_cat_failure_skips_only_that_file():
    """find 列两文件；一个 cat 失败；另一个仍 emit finding。"""
    responses: dict[tuple, RunResult] = _build_responses(
        ["/etc/systemd/system/writable_execstart.service"]
    )
    listing = (
        "/etc/systemd/system/writable_execstart.service\n"
        "/etc/systemd/system/missing.service\n"
    )
    responses[_FIND_ARGV] = RunResult(
        stdout=listing, stderr="", exit_code=0,
        rejected=False, reject_reason=None, argv=list(_FIND_ARGV),
        command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(listing.encode()),
    )
    responses[("cat", "/etc/systemd/system/missing.service")] = RunResult(
        stdout="", stderr="No such file", exit_code=1,
        rejected=False, reject_reason=None,
        argv=["cat", "/etc/systemd/system/missing.service"],
        command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(SystemdUnitLintCheck(), ctx)
    assert len(findings) == 1   # 只有 writable_execstart 命中
    assert ctx.status.is_skipped is False
