"""Per-command args schema validation (spec §6.1)."""

import pytest

from agentsec.audit.args_schema import validate_args
from agentsec.audit.path_matcher import AllowedPath, PathMatcher


@pytest.fixture
def matcher(tmp_path):
    (tmp_path / "openclaw").mkdir()
    (tmp_path / "openclaw" / "MEMORY.md").write_text("")
    return PathMatcher([AllowedPath(kind="prefix", path=str(tmp_path / "openclaw"))]), tmp_path


def test_cat_positional_path_required(matcher):
    m, root = matcher
    schema = {"args_schema": [
        {"role": "positional", "kind": "path", "must_match_allowed_paths": True},
    ]}
    assert validate_args("cat", ["cat", str(root / "openclaw" / "MEMORY.md")], schema, m) is None
    assert validate_args("cat", ["cat", "/etc/shadow"], schema, m) is not None


def test_grep_blacklisted_recursive_flag_rejected(matcher):
    m, root = matcher
    schema = {"args_schema": [
        {"role": "flags", "allowed": ["-i", "-n", "-E", "-F", "-c"],
         "forbidden": ["-r", "-R", "--include", "--exclude", "-f"]},
        {"role": "positional", "kind": "pattern"},
        {"role": "positional", "kind": "path", "must_match_allowed_paths": True},
    ]}
    assert validate_args(
        "grep", ["grep", "-r", "secret", str(root / "openclaw")], schema, m,
    ) is not None


def test_find_predicate_blacklist_blocks_exec(matcher):
    m, root = matcher
    schema = {"args_schema": [
        {"role": "positional", "kind": "path", "must_match_allowed_paths": True, "required": True},
        {"role": "predicate_pairs",
         "allowed_predicates": ["-maxdepth", "-mindepth", "-type", "-name", "-iname"],
         "forbidden_predicates": ["-exec", "-execdir", "-ok", "-okdir", "-delete"]},
    ]}
    assert validate_args(
        "find", ["find", str(root / "openclaw"), "-name", "*.md"], schema, m,
    ) is None
    assert validate_args(
        "find", ["find", str(root / "openclaw"), "-exec", "rm", "{}", ";"], schema, m,
    ) is not None
    assert validate_args(
        "find", ["find", str(root / "openclaw"), "-delete"], schema, m,
    ) is not None


def test_allowed_argv_exact_match():
    schema = {"allowed_argv": [
        ["uname", "-s"], ["uname", "-r"], ["uname", "-a"],
    ]}
    assert validate_args("uname", ["uname", "-s"], schema, None) is None
    assert validate_args("uname", ["uname", "-x"], schema, None) is not None


def test_allowed_argv_with_placeholder_already_substituted(matcher):
    """allowed_argv may contain <allowed_path> placeholders; by the time the
    args_schema validator runs, the placeholder MUST already be substituted
    with a real path. The validator just checks shape."""
    m, root = matcher
    schema = {"allowed_argv": [
        ["openssl", "x509", "-in", "<allowed_path>", "-noout", "-text"],
    ]}
    real = str(root / "openclaw" / "MEMORY.md")
    assert validate_args(
        "openssl", ["openssl", "x509", "-in", real, "-noout", "-text"], schema, m,
    ) is None
    assert validate_args(
        "openssl", ["openssl", "x509", "-in", "/etc/shadow", "-noout", "-text"], schema, m,
    ) is not None


def test_unknown_command_rejected(matcher):
    m, _ = matcher
    assert validate_args("rm", ["rm", "-rf", "/"], {}, m) is not None


def test_value_taking_flag_consumes_next_token(matcher):
    """`head -n 5 /file` must validate: `-n` is a value-taking flag, so
    `5` is its value, not a positional. Without value_taking the loop
    would stop at `5` (doesn't start with `-`) and the next schema entry
    would try to PathMatcher.match("5") and reject with the misleading
    'path "5" not in allowed_paths'.
    """
    m, root = matcher
    schema = {"args_schema": [
        {"role": "flags", "allowed": ["-n", "-c"], "value_taking": ["-n", "-c"]},
        {"role": "positional", "kind": "path", "must_match_allowed_paths": True},
    ]}
    target = str(root / "openclaw" / "MEMORY.md")
    assert validate_args("head", ["head", "-n", "5", target], schema, m) is None
    assert validate_args("head", ["head", "-c", "1024", target], schema, m) is None
    assert validate_args("tail", ["tail", "-n", "100", target], schema, m) is None


def test_value_taking_flag_with_non_numeric_value(matcher):
    """`stat -c %y /file` is the natural shape; %y is the value of -c."""
    m, root = matcher
    schema = {"args_schema": [
        {"role": "flags", "allowed": ["--format", "-c"], "value_taking": ["--format", "-c"]},
        {"role": "positional", "kind": "path", "must_match_allowed_paths": True},
    ]}
    target = str(root / "openclaw" / "MEMORY.md")
    assert validate_args("stat", ["stat", "-c", "%y", target], schema, m) is None
    assert validate_args("stat", ["stat", "--format", "%n", target], schema, m) is None


def test_value_taking_flag_at_end_of_argv_rejected(matcher):
    """`head -n` (no value, no path) must reject with a clear message
    rather than silently treating the missing value as a positional."""
    m, _ = matcher
    schema = {"args_schema": [
        {"role": "flags", "allowed": ["-n"], "value_taking": ["-n"]},
        {"role": "positional", "kind": "path", "must_match_allowed_paths": True},
    ]}
    reason = validate_args("head", ["head", "-n"], schema, m)
    assert reason is not None
    assert "value" in reason.lower()


def test_flags_without_value_taking_still_work_for_boolean_flags(matcher):
    """Backward compat: a flags entry with no value_taking key behaves
    exactly as before (e.g. `ls -l -a /path`)."""
    m, root = matcher
    schema = {"args_schema": [
        {"role": "flags", "allowed": ["-l", "-a", "-h", "-1"]},
        {"role": "positional", "kind": "path", "must_match_allowed_paths": True},
    ]}
    target = str(root / "openclaw")
    assert validate_args("ls", ["ls", "-l", "-a", target], schema, m) is None


def test_journalctl_unit_placeholder_accepts_valid_unit():
    schema = {"allowed_argv": [
        ["journalctl", "--user", "--no-pager", "--output=cat",
         "-u", "<unit>", "--since", "<since>", "--lines", "<lines>"],
    ]}
    argv = ["journalctl", "--user", "--no-pager", "--output=cat",
            "-u", "openclaw-gateway.service",
            "--since", "24 hours ago",
            "--lines", "10000"]
    assert validate_args("journalctl", argv, schema, None) is None


@pytest.mark.parametrize("bad_unit", [
    "openclaw-gateway",                   # missing .service
    "openclaw gateway.service",           # space
    "../escape.service",                  # traversal
    "openclaw;rm -rf /.service",          # metachar
    "x" * 200 + ".service",               # length
    "",                                   # empty
])
def test_journalctl_rejects_bad_unit(bad_unit):
    schema = {"allowed_argv": [
        ["journalctl", "--user", "--no-pager", "--output=cat",
         "-u", "<unit>", "--since", "<since>", "--lines", "<lines>"],
    ]}
    argv = ["journalctl", "--user", "--no-pager", "--output=cat",
            "-u", bad_unit,
            "--since", "24 hours ago",
            "--lines", "10000"]
    assert validate_args("journalctl", argv, schema, None) is not None


@pytest.mark.parametrize("bad_since", [
    "0 hours ago",
    "12 minutes ago",
    "24 days ago",                        # days branch deliberately not allowed
    "24 hours;ls",
    "24 hours ago && ls",
    "10000 hours ago",                    # 5 digits, > 9999
    "two hours ago",
])
def test_journalctl_rejects_bad_since(bad_since):
    schema = {"allowed_argv": [
        ["journalctl", "--user", "--no-pager", "--output=cat",
         "-u", "<unit>", "--since", "<since>", "--lines", "<lines>"],
    ]}
    argv = ["journalctl", "--user", "--no-pager", "--output=cat",
            "-u", "openclaw-gateway.service",
            "--since", bad_since,
            "--lines", "10000"]
    assert validate_args("journalctl", argv, schema, None) is not None


@pytest.mark.parametrize("bad_lines", ["0", "9", "-1", "10.0", "1000000", "abc"])
def test_journalctl_rejects_bad_lines(bad_lines):
    schema = {"allowed_argv": [
        ["journalctl", "--user", "--no-pager", "--output=cat",
         "-u", "<unit>", "--since", "<since>", "--lines", "<lines>"],
    ]}
    argv = ["journalctl", "--user", "--no-pager", "--output=cat",
            "-u", "openclaw-gateway.service",
            "--since", "24 hours ago",
            "--lines", bad_lines]
    assert validate_args("journalctl", argv, schema, None) is not None


def test_container_id_kind_accepts_valid_hex():
    """`docker inspect <12-64 hex chars>` 通过校验。"""
    schema = {
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ]
    }
    reason = validate_args(
        "docker", ["docker", "inspect", "a1b2c3d4e5f6"], schema, matcher=None,
    )
    assert reason is None


def test_container_id_kind_rejects_short_hex():
    schema = {
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ]
    }
    # 11 字符（少于下限 12）
    reason = validate_args(
        "docker", ["docker", "inspect", "a1b2c3d4e5f"], schema, matcher=None,
    )
    assert reason is not None
    assert "container_id" in reason


def test_container_id_kind_rejects_uppercase():
    schema = {
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ]
    }
    reason = validate_args(
        "docker", ["docker", "inspect", "A1B2C3D4E5F6"], schema, matcher=None,
    )
    assert reason is not None
    assert "container_id" in reason


def test_container_id_kind_rejects_metacharacters():
    schema = {
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ]
    }
    reason = validate_args(
        "docker", ["docker", "inspect", "a1b2c3d4e5f6;rm"], schema, matcher=None,
    )
    assert reason is not None


def test_subcommand_role_rejects_unknown_subcommand():
    schema = {
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ]
    }
    reason = validate_args(
        "docker", ["docker", "exec", "a1b2c3d4e5f6"], schema, matcher=None,
    )
    assert reason is not None
    assert "subcommand" in reason or "exec" in reason


def test_validate_args_allowed_argv_match_short_circuits():
    """Both keys present, allowed_argv matches → returns None without consulting args_schema."""
    schema = {
        "allowed_argv": [["docker", "version", "--format", "{{json .}}"]],
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ],
    }
    reason = validate_args(
        "docker",
        ["docker", "version", "--format", "{{json .}}"],
        schema, matcher=None,
    )
    assert reason is None


def test_validate_args_falls_through_to_args_schema_when_both_keys_present():
    """allowed_argv miss + args_schema match → returns None via fall-through."""
    schema = {
        "allowed_argv": [["docker", "version", "--format", "{{json .}}"]],
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ],
    }
    reason = validate_args(
        "docker",
        ["docker", "inspect", "a1b2c3d4e5f6"],
        schema, matcher=None,
    )
    assert reason is None


def test_validate_args_returns_args_schema_reason_when_both_fail():
    """allowed_argv miss + args_schema miss → returns args_schema's reason (not allowed_argv's)."""
    schema = {
        "allowed_argv": [["docker", "version", "--format", "{{json .}}"]],
        "args_schema": [
            {"role": "subcommand", "allowed": ["inspect"]},
            {"role": "positional", "kind": "container_id", "required": True},
        ],
    }
    reason = validate_args(
        "docker", ["docker", "exec", "a1b2c3d4e5f6"], schema, matcher=None,
    )
    assert reason is not None
    # The error originates from args_schema's subcommand check, not from allowed_argv
    assert "subcommand" in reason or "exec" in reason
