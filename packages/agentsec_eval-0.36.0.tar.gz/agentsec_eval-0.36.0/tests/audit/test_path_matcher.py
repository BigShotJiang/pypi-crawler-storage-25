"""PathMatcher — boundary-aware path matching (OE-AUD4-001).

Tricky cases:
  - /tmp/openclaw2/secret must NOT match prefix /tmp/openclaw
  - symlink that resolves outside allowed_paths must reject
  - ~/.openclaw/foo must match prefix ~/.openclaw/
  - relative path traversal (~/.openclaw/../etc/shadow) must reject
"""

import logging

import pytest

from agentsec.audit.path_matcher import AllowedPath, PathMatcher


@pytest.fixture
def tmp_openclaw(tmp_path):
    root = tmp_path / "openclaw"
    root.mkdir()
    (root / "MEMORY.md").write_text("hi")
    (tmp_path / "openclaw2").mkdir()
    (tmp_path / "openclaw2" / "secret").write_text("don't read")
    return tmp_path


def test_prefix_match_inside_root(tmp_openclaw):
    rules = [AllowedPath(kind="prefix", path=str(tmp_openclaw / "openclaw"))]
    m = PathMatcher(rules)
    assert m.matches(str(tmp_openclaw / "openclaw" / "MEMORY.md")) is None


def test_prefix_does_not_match_sibling_with_shared_prefix(tmp_openclaw):
    rules = [AllowedPath(kind="prefix", path=str(tmp_openclaw / "openclaw"))]
    m = PathMatcher(rules)
    reason = m.matches(str(tmp_openclaw / "openclaw2" / "secret"))
    assert reason is not None  # /tmp/openclaw2/secret must NOT match /tmp/openclaw


def test_prefix_rejects_symlink_escape(tmp_openclaw):
    target = tmp_openclaw / "outside.txt"
    target.write_text("nope")
    link = tmp_openclaw / "openclaw" / "link"
    link.symlink_to(target)
    rules = [AllowedPath(kind="prefix", path=str(tmp_openclaw / "openclaw"))]
    m = PathMatcher(rules)
    assert m.matches(str(link)) is not None


def test_exact_match(tmp_path):
    f = tmp_path / "openclaw.service"
    f.write_text("")
    rules = [AllowedPath(kind="exact", path=str(f))]
    m = PathMatcher(rules)
    assert m.matches(str(f)) is None
    assert m.matches(str(tmp_path / "other.service")) is not None


def test_glob_match_within_pattern_parent(tmp_path):
    sysd = tmp_path / "systemd-system"
    sysd.mkdir()
    (sysd / "openclaw@worker1.service").write_text("")
    rules = [AllowedPath(kind="glob", pattern=str(sysd / "openclaw@*.service"))]
    m = PathMatcher(rules)
    assert m.matches(str(sysd / "openclaw@worker1.service")) is None


def test_glob_rejects_realpath_outside_parent(tmp_path):
    sysd = tmp_path / "systemd-system"
    sysd.mkdir()
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()
    real = elsewhere / "openclaw@evil.service"
    real.write_text("")
    link = sysd / "openclaw@evil.service"
    link.symlink_to(real)
    rules = [AllowedPath(kind="glob", pattern=str(sysd / "openclaw@*.service"))]
    m = PathMatcher(rules)
    assert m.matches(str(link)) is not None


def test_relative_traversal_rejected(tmp_openclaw):
    rules = [AllowedPath(kind="prefix", path=str(tmp_openclaw / "openclaw"))]
    m = PathMatcher(rules)
    bad = str(tmp_openclaw / "openclaw" / ".." / "openclaw2" / "secret")
    assert m.matches(bad) is not None


def test_prefix_rule_warns_when_root_missing(tmp_path, caplog):
    rules = [AllowedPath(kind="prefix", path=str(tmp_path / "does-not-exist"))]
    with caplog.at_level(logging.WARNING, logger="agentsec.audit.path_matcher"):
        PathMatcher(rules)  # spec §6.1 requires a load-time warning
    assert any("does-not-exist" in r.message for r in caplog.records)


def test_path_matcher_remote_home_replaces_tilde_expansion():
    rules = [AllowedPath(kind="prefix", path="~/.openclaw/")]
    matcher = PathMatcher(rules, remote_home="/home/ubuntu")
    # candidate uses the remote-side absolute path
    assert matcher.matches("/home/ubuntu/.openclaw/notes.txt") is None
    # evaluator-side home should NOT match (we are NOT calling expanduser any more)
    assert matcher.matches("/Users/roger/.openclaw/notes.txt") is not None


def test_path_matcher_no_remote_home_keeps_legacy_expanduser():
    """Default behavior unchanged — preserves existing test compatibility."""
    rules = [AllowedPath(kind="prefix", path="~/.openclaw/")]
    matcher = PathMatcher(rules)  # no remote_home
    # We don't assert against a specific evaluator home (varies by machine);
    # we just assert the matcher constructs cleanly.
    assert matcher is not None
