"""Canonicalization + HMAC must be byte-stable per spec §6.4.

The canonical fixture and its HMAC are recomputed by hand below — DO NOT
regenerate from the implementation. Any drift means the implementation is
broken, not the test.
"""

import base64
import hashlib
import hmac

from agentsec.audit.authorization import Authorization, canonical_message


def _expected_canonical():
    # field order: target_host, authorized_by, identity_provider, identity_assertion,
    # valid_from, valid_until, ",".join(sorted(scope)), report_output_path_prefix
    parts = [
        "openclaw.example.com",
        "roger@example.com",
        "okta-saml",
        "eyJhbGciOiJIUzI1NiJ9.fake.payload",
        "2026-04-25T00:00:00+00:00",
        "2026-05-25T00:00:00+00:00",
        "remote-evaluation,server-audit",  # sorted ASCII
        "./report-2026-04-25/",
    ]
    return "\n".join(parts)


def test_canonical_message_byte_stable():
    auth = Authorization.model_validate({
        "target_host": "openclaw.example.com",
        "authorized_by": "roger@example.com",
        "identity_provider": "okta-saml",
        "identity_assertion": "eyJhbGciOiJIUzI1NiJ9.fake.payload",
        "valid_from": "2026-04-25T00:00:00Z",
        "valid_until": "2026-05-25T00:00:00Z",
        # scope intentionally given out of order to prove sort
        "scope": ["server-audit", "remote-evaluation"],
        "report_output_path_prefix": "./report-2026-04-25/",
        "signature_mode": "none",
    })
    assert canonical_message(auth) == _expected_canonical()


def test_hmac_matches_handcomputed():
    msg = _expected_canonical()
    key = b"super-secret-test-key"
    expected = base64.b64encode(
        hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()
    ).decode("ascii")
    auth = Authorization.model_validate({
        "target_host": "openclaw.example.com",
        "authorized_by": "roger@example.com",
        "identity_provider": "okta-saml",
        "identity_assertion": "eyJhbGciOiJIUzI1NiJ9.fake.payload",
        "valid_from": "2026-04-25T00:00:00Z",
        "valid_until": "2026-05-25T00:00:00Z",
        "scope": ["remote-evaluation", "server-audit"],
        "report_output_path_prefix": "./report-2026-04-25/",
        "signature_mode": "hmac_sha256",
        "signature_key_env": "TEST_KEY_ENV",
    })
    assert auth.compute_signature(key) == expected
