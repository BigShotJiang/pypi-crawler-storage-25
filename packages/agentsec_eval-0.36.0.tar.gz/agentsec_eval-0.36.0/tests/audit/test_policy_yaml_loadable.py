"""ssh_policy.yaml is the source of truth for SSH command authorization.

This test only confirms it parses and contains the structural keys we need;
deep validation lives with command_policy tests.
"""

from pathlib import Path

import yaml

POLICY = Path(__file__).resolve().parents[2] / "src" / "agentsec" / "audit" / "ssh_policy.yaml"


def test_policy_file_exists():
    assert POLICY.exists(), f"missing {POLICY}"


def test_policy_top_level_shape():
    data = yaml.safe_load(POLICY.read_text())
    assert isinstance(data, dict)
    for key in ("allowed_paths", "max_output_bytes", "default_timeout_sec",
                "redact_before_log", "commands", "write_operations"):
        assert key in data, f"policy missing top-level key: {key}"


def test_policy_write_operations_disabled_in_v1():
    data = yaml.safe_load(POLICY.read_text())
    assert data["write_operations"]["enabled"] is False, (
        "v1 must ship with write_operations.enabled=False (OE-AUD3-005)"
    )


def test_policy_lists_required_commands():
    data = yaml.safe_load(POLICY.read_text())
    cmds = data["commands"]
    for required in ("cat", "ls", "grep", "find", "stat", "head", "tail", "wc",
                     "uname", "ps", "ss", "lsof", "systemctl", "launchctl",
                     "openssl", "openclaw"):
        assert required in cmds, f"policy missing command: {required}"


def test_openclaw_audit_argv_is_in_policy():
    data = yaml.safe_load(POLICY.read_text())
    allowed = data["commands"]["openclaw"]["allowed_argv"]
    assert ["openclaw", "security", "audit", "--json"] in allowed
