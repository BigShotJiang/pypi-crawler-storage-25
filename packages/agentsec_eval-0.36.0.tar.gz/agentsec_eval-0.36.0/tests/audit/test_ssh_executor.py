"""SSHExecutor — paramiko wrapper, audit-log.jsonl, policy enforcement.

We stub paramiko via SSHExecutor's `transport` injection point so the test
never opens a real SSH connection.
"""

import hashlib
import json
import shlex
from pathlib import Path

import pytest

from agentsec.audit.command_policy import CommandPolicy
from agentsec.audit.redactor import Redactor
from agentsec.audit.ssh import SSHExecutor

POLICY_PATH = Path(__file__).resolve().parents[2] / "src" / "agentsec" / "audit" / "ssh_policy.yaml"


class FakeChannel:
    def __init__(self, exit_code=0):
        self._exit_code = exit_code

    def recv_exit_status(self):
        return self._exit_code


class FakeTransport:
    def __init__(self, stdout=b"", stderr=b"", exit_code=0):
        self._stdout = stdout
        self._stderr = stderr
        self._channel = FakeChannel(exit_code)
        self.last_command = None
        self.last_get_pty = None
        self.last_environment = None
        self.last_timeout = None

    def exec_command(self, command, *, get_pty=False, environment=None, timeout=None):
        self.last_command = command
        self.last_get_pty = get_pty
        self.last_environment = environment
        self.last_timeout = timeout
        return None, _StreamWrapper(self._stdout, self._channel), _StreamWrapper(self._stderr)


class _StreamWrapper:
    def __init__(self, data, channel=None):
        self._data = data
        self._cursor = 0
        if channel is not None:
            self.channel = channel

    def read(self, size: int = -1):
        if size is None or size < 0:
            chunk = self._data[self._cursor:]
            self._cursor = len(self._data)
            return chunk
        chunk = self._data[self._cursor:self._cursor + size]
        self._cursor += len(chunk)
        return chunk


@pytest.fixture
def policy(tmp_path):
    p = CommandPolicy.from_yaml(POLICY_PATH)
    p.add_allowed_path_prefix(tmp_path)
    (tmp_path / "MEMORY.md").write_text("hello")
    return p, tmp_path


def test_run_uname_happy_path(policy, tmp_path):
    p, _ = policy
    transport = FakeTransport(stdout=b"Linux\n")
    log = tmp_path / "audit-log.jsonl"
    ex = SSHExecutor(policy=p, redactor=Redactor(), audit_log_path=log, transport=transport)
    result = ex.run(["uname", "-s"])
    assert result.exit_code == 0
    assert result.stdout == "Linux\n"
    assert result.rejected is False
    assert transport.last_command == "uname -s"
    assert transport.last_get_pty is False
    assert transport.last_environment is None
    assert transport.last_timeout == p.default_timeout_sec


def test_run_path_outside_allowed_rejected_without_calling_transport(policy, tmp_path):
    p, _ = policy
    transport = FakeTransport()
    log = tmp_path / "audit-log.jsonl"
    ex = SSHExecutor(policy=p, redactor=Redactor(), audit_log_path=log, transport=transport)
    result = ex.run(["cat", "/etc/shadow"])
    assert result.rejected is True
    assert transport.last_command is None  # never reached the transport


def test_audit_log_records_sha256_not_raw_command(policy, tmp_path):
    p, root = policy
    transport = FakeTransport(stdout=b"hi\n")
    log = tmp_path / "audit-log.jsonl"
    ex = SSHExecutor(policy=p, redactor=Redactor(), audit_log_path=log, transport=transport)
    ex.run(["cat", str(root / "MEMORY.md")])
    line = json.loads(log.read_text().strip().splitlines()[-1])
    assert "command_sha256" in line
    rendered = "cat " + shlex.quote(str(root / "MEMORY.md"))
    assert line["command_sha256"] == hashlib.sha256(rendered.encode()).hexdigest()
    assert rendered not in json.dumps(line)
    # argv carries the same parameter content that the SHA-256 design was
    # meant to keep out of the log; on the success path it must be absent
    # so the documented contract holds.
    assert "argv" not in line


def test_audit_log_records_argv_for_rejected_call(policy, tmp_path):
    p, _ = policy
    transport = FakeTransport()
    log = tmp_path / "audit-log.jsonl"
    ex = SSHExecutor(policy=p, redactor=Redactor(), audit_log_path=log, transport=transport)
    ex.run(["cat", "/etc/shadow"])
    line = json.loads(log.read_text().strip().splitlines()[-1])
    assert line["rejected"] is True
    assert line["argv"] == ["cat", "/etc/shadow"]
    assert "shadow" in line["reject_reason"] or "allowed_paths" in line["reject_reason"]


def test_stdout_and_stderr_are_capped_at_read_time(policy, tmp_path):
    """The audited host can be hostile (CLAUDE.md). A bare stdout.read()
    would buffer the full payload before max_output_bytes was applied,
    letting a target stream gigabytes within the timeout window and
    exhaust evaluator RAM. Both streams must stop at `cap` bytes, and
    stderr — which previously had no bound at all — must respect the
    same cap as stdout.
    """
    p, _ = policy
    cap = p.max_output_bytes
    transport = FakeTransport(
        stdout=b"A" * (cap + 50_000),
        stderr=b"B" * (cap + 50_000),
    )
    log = tmp_path / "audit-log.jsonl"
    ex = SSHExecutor(policy=p, redactor=Redactor(), audit_log_path=log, transport=transport)
    result = ex.run(["uname", "-s"])
    assert result.rejected is False
    assert len(result.stdout.encode("utf-8")) == cap
    assert len(result.stderr.encode("utf-8")) == cap
    assert result.bytes_out == cap


def test_audit_log_redacts_stderr(policy, tmp_path):
    p, _ = policy
    transport = FakeTransport(
        stdout=b"",
        stderr=b"error: token sk-ant-AAAAABBBBBCCCCCDDDDDEEEEEFFFFF leaked",
        exit_code=1,
    )
    log = tmp_path / "audit-log.jsonl"
    ex = SSHExecutor(policy=p, redactor=Redactor(), audit_log_path=log, transport=transport)
    ex.run(["uname", "-s"])
    line = json.loads(log.read_text().strip().splitlines()[-1])
    assert "sk-ant" not in json.dumps(line)
