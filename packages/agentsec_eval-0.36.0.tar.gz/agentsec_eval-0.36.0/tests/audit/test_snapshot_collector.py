"""SnapshotCollector — produces {"files": [...], "config": {...}} via SSHExecutor.

We use the same fake transport pattern as test_ssh_executor.py so no real SSH is needed.
"""

import json
from pathlib import Path

import pytest

from agentsec.audit.command_policy import CommandPolicy
from agentsec.audit.redactor import Redactor
from agentsec.audit.snapshot import SnapshotCollector
from agentsec.audit.ssh import SSHExecutor

POLICY_PATH = Path(__file__).resolve().parents[2] / "src" / "agentsec" / "audit" / "ssh_policy.yaml"


class _ScriptedTransport:
    """Returns canned outputs keyed by the rendered command."""

    def __init__(self, table: dict[str, tuple[bytes, bytes, int]]):
        self.table = table
        self.calls: list[str] = []

    def exec_command(self, command, *, get_pty, environment, timeout):
        self.calls.append(command)
        out, err, code = self.table.get(command, (b"", b"", 0))

        class _Channel:
            def __init__(self, c):
                self._c = c

            def recv_exit_status(self):
                return self._c

        class _StreamWithChannel:
            def __init__(self, b, c):
                self._b = b
                self._cursor = 0
                self.channel = _Channel(c)

            def read(self, size: int = -1):
                if size is None or size < 0:
                    chunk = self._b[self._cursor:]
                    self._cursor = len(self._b)
                    return chunk
                chunk = self._b[self._cursor:self._cursor + size]
                self._cursor += len(chunk)
                return chunk

        class _Stream:
            def __init__(self, b):
                self._b = b
                self._cursor = 0

            def read(self, size: int = -1):
                if size is None or size < 0:
                    chunk = self._b[self._cursor:]
                    self._cursor = len(self._b)
                    return chunk
                chunk = self._b[self._cursor:self._cursor + size]
                self._cursor += len(chunk)
                return chunk

        return None, _StreamWithChannel(out, code), _Stream(err)


@pytest.fixture
def executor(tmp_path):
    policy = CommandPolicy.from_yaml(POLICY_PATH)
    policy.add_allowed_path_prefix(tmp_path)
    (tmp_path / "MEMORY.md").write_text("")
    return policy, tmp_path


def test_collect_files_uses_find(executor, tmp_path):
    policy, root = executor
    transport = _ScriptedTransport({
        f"find {root.as_posix()} -name MEMORY.md": (b"./MEMORY.md\n", b"", 0),
    })
    ex = SSHExecutor(
        policy=policy, redactor=Redactor(),
        audit_log_path=tmp_path / "log.jsonl",
        transport=transport,
    )
    sc = SnapshotCollector(ex, paths={"memory_file": str(root / "MEMORY.md")})
    snap = sc.collect(items=["memory_file"])
    assert "files" in snap
    assert any(p.endswith("MEMORY.md") for p in snap["files"])


def test_collect_config_via_openclaw_show(executor, tmp_path):
    policy, _ = executor
    config_payload = {"agent": {"execution": {"require_approval": True}}}
    transport = _ScriptedTransport({
        "openclaw config show --json": (json.dumps(config_payload).encode(), b"", 0),
    })
    ex = SSHExecutor(
        policy=policy, redactor=Redactor(),
        audit_log_path=tmp_path / "log.jsonl",
        transport=transport,
    )
    sc = SnapshotCollector(ex, paths={})
    snap = sc.collect(items=["config"])
    assert snap["config"] == config_payload


def test_collect_unknown_item_raises(executor, tmp_path):
    policy, _ = executor
    transport = _ScriptedTransport({})
    ex = SSHExecutor(
        policy=policy, redactor=Redactor(),
        audit_log_path=tmp_path / "log.jsonl",
        transport=transport,
    )
    sc = SnapshotCollector(ex, paths={})
    with pytest.raises(ValueError, match="unknown snapshot item"):
        sc.collect(items=["nonsense"])
