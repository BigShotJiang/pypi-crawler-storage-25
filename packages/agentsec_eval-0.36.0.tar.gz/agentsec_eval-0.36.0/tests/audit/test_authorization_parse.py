from pathlib import Path

import pytest

from agentsec.audit.authorization import Authorization, AuthorizationError

FIXTURES = Path(__file__).parent / "fixtures"


def test_parse_minimal_authorization():
    auth = Authorization.load(FIXTURES / "auth_minimal.txt")
    assert auth.target_host == "openclaw.example.com"
    assert auth.scope == ["server-audit"]
    assert auth.signature_mode == "none"
    assert auth.signature is None
    assert auth.signature_key_env is None


def test_parse_full_authorization():
    auth = Authorization.load(FIXTURES / "auth_full.txt")
    assert auth.identity_provider == "okta-saml"
    assert auth.signature_mode == "hmac_sha256"
    assert auth.signature == "PLACEHOLDER_BASE64_SIG"
    assert auth.signature_key_env == "AGENTSEC_AUTH_SIGNING_KEY"


def test_parse_missing_required_field_raises():
    bad = FIXTURES / "auth_bad.txt"
    bad.write_text("target_host: x\n")
    try:
        with pytest.raises(AuthorizationError):
            Authorization.load(bad)
    finally:
        bad.unlink()


def test_parse_unreadable_file_raises():
    with pytest.raises(AuthorizationError):
        Authorization.load(FIXTURES / "does_not_exist.txt")
