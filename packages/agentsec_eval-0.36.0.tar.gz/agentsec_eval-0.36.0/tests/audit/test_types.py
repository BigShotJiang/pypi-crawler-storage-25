"""RunResult dataclass — typed return from SSHExecutor.run()."""

from agentsec.audit.types import RunResult


def test_run_result_fields_and_defaults():
    r = RunResult(
        argv=["uname", "-s"],
        command_sha256="a" * 64,
        exit_code=0,
        stdout="Linux\n",
        stderr="",
        duration_ms=12.0,
        bytes_out=6,
        rejected=False,
        reject_reason=None,
    )
    assert r.argv == ["uname", "-s"]
    assert r.exit_code == 0
    assert r.rejected is False
    assert r.reject_reason is None


def test_run_result_rejected_shape():
    r = RunResult(
        argv=["cat", "/etc/shadow"],
        command_sha256="",
        exit_code=-1,
        stdout="",
        stderr="",
        duration_ms=0.0,
        bytes_out=0,
        rejected=True,
        reject_reason="path /etc/shadow not in allowed_paths",
    )
    assert r.rejected is True
    assert "allowed_paths" in r.reject_reason
