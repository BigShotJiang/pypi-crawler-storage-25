import pytest

from agentsec.audit.platform_profile import LINUX, MACOS


def test_linux_profile_has_required_logical_paths():
    assert LINUX.name == "linux"
    for key in ("openclaw_home", "memory_file", "log_dir", "systemd_unit"):
        assert key in LINUX.paths, f"Linux profile missing path: {key}"
    assert LINUX.services["list"] == [
        ["systemctl", "list-units", "--type=service", "openclaw.service"],
    ]
    assert LINUX.listening_check == [["ss", "-tlnp"], ["ss", "-ulnp"]]


def test_macos_profile_has_required_logical_paths():
    assert MACOS.name == "macos"
    for key in ("openclaw_home", "memory_file", "log_dir", "launch_daemon"):
        assert key in MACOS.paths, f"macOS profile missing path: {key}"
    # macOS uses launchctl, not systemctl
    assert MACOS.services["list"] == [["launchctl", "list"]]
    assert MACOS.listening_check == [["lsof", "-i", "-n", "-P"]]


def test_profile_is_frozen():
    """Profiles are shared singletons; mutating them would break checks."""
    import pydantic
    with pytest.raises((pydantic.ValidationError, TypeError)):
        LINUX.name = "macos"  # type: ignore[misc]


def test_detect_platform_routes_uname_output():
    from agentsec.audit.platform_profile import detect_platform
    assert detect_platform("Linux\n") is LINUX
    assert detect_platform("Darwin") is MACOS
    assert detect_platform("  linux  ") is LINUX
    with pytest.raises(ValueError, match="unsupported platform"):
        detect_platform("FreeBSD")


def test_materialize_paths_replaces_tilde_prefix():
    from agentsec.audit.platform_profile import LINUX, materialize_paths
    materialized = materialize_paths(LINUX, "/home/ubuntu")
    assert materialized.paths["openclaw_home"] == "/home/ubuntu/.openclaw/"
    assert materialized.paths["memory_file"] == "/home/ubuntu/.openclaw/MEMORY.md"
    # absolute paths pass through unchanged
    assert materialized.paths["log_dir"] == LINUX.paths["log_dir"]
    # services / listening_check unchanged
    assert materialized.services == LINUX.services
    assert materialized.listening_check == LINUX.listening_check


def test_materialize_paths_idempotent_on_absolute_profile():
    from agentsec.audit.platform_profile import PlatformProfile, materialize_paths
    abs_profile = PlatformProfile(
        name="linux",
        paths={"openclaw_home": "/srv/openclaw/"},
        services={"list": [["systemctl", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
    )
    out = materialize_paths(abs_profile, "/home/ubuntu")
    assert out == abs_profile


def test_materialize_paths_strips_trailing_slash_on_remote_home():
    from agentsec.audit.platform_profile import LINUX, materialize_paths
    out = materialize_paths(LINUX, "/home/ubuntu/")  # trailing slash
    assert out.paths["openclaw_home"] == "/home/ubuntu/.openclaw/"


def test_file_log_source_validates():
    from agentsec.audit.platform_profile import FileLogSource
    src = FileLogSource(log_dir="~/Library/Logs/openclaw/")
    assert src.kind == "files"
    assert src.log_dir == "~/Library/Logs/openclaw/"


def test_journald_log_source_requires_at_least_one_unit():
    import pydantic

    from agentsec.audit.platform_profile import JournaldLogSource
    src = JournaldLogSource(user=True, units=("openclaw-gateway.service",))
    assert src.kind == "journald"
    assert src.user is True
    with pytest.raises(pydantic.ValidationError):
        JournaldLogSource(user=True, units=())


def test_linux_profile_has_file_log_source():
    from agentsec.audit.platform_profile import LINUX, FileLogSource
    assert isinstance(LINUX.log_source, FileLogSource)
    assert LINUX.log_source.log_dir == "/var/log/openclaw/"


def test_linux_user_mode_has_journald_log_source():
    from agentsec.audit.platform_profile import (
        LINUX_USER_MODE,
        JournaldLogSource,
    )
    src = LINUX_USER_MODE.log_source
    assert isinstance(src, JournaldLogSource)
    assert src.user is True
    assert src.units == (
        "openclaw-gateway.service",
        "openclaw-node.service",
    )


def test_macos_profile_has_file_log_source():
    from agentsec.audit.platform_profile import MACOS, FileLogSource
    assert isinstance(MACOS.log_source, FileLogSource)
    assert MACOS.log_source.log_dir == "~/Library/Logs/openclaw/"


def test_materialize_paths_expands_file_log_source_tilde():
    from agentsec.audit.platform_profile import MACOS, materialize_paths
    out = materialize_paths(MACOS, "/Users/alice")
    assert out.log_source.kind == "files"
    assert out.log_source.log_dir == "/Users/alice/Library/Logs/openclaw/"


def test_materialize_paths_passthrough_for_journald():
    from agentsec.audit.platform_profile import LINUX_USER_MODE, materialize_paths
    out = materialize_paths(LINUX_USER_MODE, "/home/ubuntu")
    assert out.log_source == LINUX_USER_MODE.log_source  # frozen, unchanged


def test_platform_profile_model_copy_preserves_log_source():
    """Regression: cli.py rebuilds PlatformProfile after bin-path resolution
    via model_copy(update=...); log_source must survive the round-trip."""
    from agentsec.audit.platform_profile import LINUX_USER_MODE
    new_paths = dict(LINUX_USER_MODE.paths)
    new_paths["openclaw_bin"] = "/home/ubuntu/.npm-global/bin/openclaw"
    rebuilt = LINUX_USER_MODE.model_copy(update={"paths": new_paths})
    assert rebuilt.log_source == LINUX_USER_MODE.log_source
    assert rebuilt.paths["openclaw_bin"] == "/home/ubuntu/.npm-global/bin/openclaw"
