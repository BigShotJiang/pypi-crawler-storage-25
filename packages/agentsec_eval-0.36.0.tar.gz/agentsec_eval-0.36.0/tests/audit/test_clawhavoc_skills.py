import json
import re

from agentsec.audit.ioc import IOC_DIR

_SHA256_RE = re.compile(r"^[a-f0-9]{64}$")


def test_clawhavoc_skills_schema():
    db = json.loads((IOC_DIR / "clawhavoc_skills.json").read_text())
    assert isinstance(db, list)
    assert len(db) >= 5, "v0.2.0 seed requires ≥5 ClawHavoc skill entries"
    seen_names = set()
    for entry in db:
        for required in ("name", "sha256", "published_after", "claim", "threat_refs"):
            assert required in entry, f"missing {required}: {entry}"
        assert entry["name"] not in seen_names, f"duplicate name: {entry['name']}"
        seen_names.add(entry["name"])
        if entry["sha256"] is not None:
            assert _SHA256_RE.match(entry["sha256"]), f"bad sha256: {entry}"
        # ISO date YYYY-MM-DD
        assert re.match(r"^\d{4}-\d{2}-\d{2}$", entry["published_after"]), entry
        assert isinstance(entry["threat_refs"], list)
        assert "TI-CLAWHAVOC-OVERVIEW" in entry["threat_refs"]
