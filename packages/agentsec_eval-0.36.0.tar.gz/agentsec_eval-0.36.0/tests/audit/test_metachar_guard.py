"""Shell-metachar guard runs on the FINAL argv (after placeholder substitution)."""

import pytest

from agentsec.audit.metachar_guard import contains_shell_metachar


@pytest.mark.parametrize("token", [
    "foo|bar", "foo;bar", "foo&bar", "foo`bar`", "foo$(bar)",
    "foo<bar", "foo>bar", "foo\nbar",
])
def test_metachar_tokens_rejected(token):
    assert contains_shell_metachar([token]) is not None


@pytest.mark.parametrize("argv", [
    ["uname", "-s"],
    ["openclaw", "security", "audit", "--json"],
    ["cat", "/var/log/openclaw/app.log"],
    ["find", "~/.openclaw/", "-name", "MEMORY.md", "-mtime", "-7"],
])
def test_safe_argv_passes(argv):
    assert contains_shell_metachar(argv) is None


def test_grep_E_pipe_rejected():
    # OE-AUD4-002: this is intentional — grep -E "foo|bar" gets rejected.
    assert contains_shell_metachar(["grep", "-E", "foo|bar", "x.log"]) is not None
