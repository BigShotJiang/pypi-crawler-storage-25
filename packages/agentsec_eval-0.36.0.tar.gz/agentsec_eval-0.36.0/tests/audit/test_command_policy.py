"""CommandPolicy.validate(argv) — four-step chain end-to-end."""

import shlex
from pathlib import Path

import pytest

from agentsec.audit.command_policy import CommandPolicy

POLICY_PATH = Path(__file__).resolve().parents[2] / "src" / "agentsec" / "audit" / "ssh_policy.yaml"


@pytest.fixture
def policy(tmp_path):
    p = CommandPolicy.from_yaml(POLICY_PATH)
    p.add_allowed_path_prefix(tmp_path)
    (tmp_path / "MEMORY.md").write_text("")
    return p, tmp_path


def test_validate_accepts_allowed_argv(policy):
    p, _ = policy
    result = p.validate(["uname", "-s"])
    assert result.ok is True
    assert result.rendered == "uname -s"


def test_validate_rejects_metachar_in_final_argv(policy):
    p, _ = policy
    result = p.validate(["grep", "-E", "foo|bar", "/var/log/openclaw/app.log"])
    assert result.ok is False
    assert "metachar" in result.reason.lower()


def test_validate_rejects_path_outside_allowed(policy):
    p, _ = policy
    result = p.validate(["cat", "/etc/shadow"])
    assert result.ok is False


def test_validate_substitutes_placeholder_in_allowed_argv(policy):
    p, root = policy
    result = p.validate(
        ["openssl", "x509", "-in", str(root / "MEMORY.md"), "-noout", "-text"],
    )
    assert result.ok is True


def test_validate_renders_via_shlex_quote(policy):
    p, root = policy
    weird_path = root / "with space.md"
    weird_path.write_text("")
    result = p.validate(["cat", str(weird_path)])
    assert result.ok is True
    assert result.rendered == f"cat {shlex.quote(str(weird_path))}"


def test_validate_rejects_unknown_command(policy):
    p, _ = policy
    result = p.validate(["rm", "-rf", "/"])
    assert result.ok is False
    assert "policy" in result.reason.lower()


def test_validate_substitution_runs_before_metachar_check(policy):
    """Per OE-AUD3-008: placeholder substitution happens FIRST. If a caller
    passes a value containing metachars to fill an <allowed_path> slot, the
    metachar guard runs against the SUBSTITUTED argv and rejects."""
    p, root = policy
    bad_value = str(root / "MEMORY.md") + "; rm -rf /"
    result = p.validate(["openssl", "x509", "-in", bad_value, "-noout", "-text"])
    assert result.ok is False
    assert "metachar" in result.reason.lower()


def test_policy_accepts_journalctl_user_mode(policy):
    p, _ = policy
    result = p.validate([
        "journalctl", "--user", "--no-pager", "--output=cat",
        "-u", "openclaw-gateway.service",
        "--since", "24 hours ago",
        "--lines", "10000",
    ])
    assert result.ok, result.reason


def test_policy_accepts_journalctl_system_mode(policy):
    p, _ = policy
    result = p.validate([
        "journalctl", "--no-pager", "--output=cat",
        "-u", "openclaw.service",
        "--since", "1 hours ago",
        "--lines", "100",
    ])
    assert result.ok, result.reason


def test_policy_rejects_journalctl_with_grep_flag(policy):
    p, _ = policy
    result = p.validate([
        "journalctl", "--user", "--no-pager", "--output=cat",
        "-u", "openclaw-gateway.service",
        "--grep", "secret",
        "--since", "24 hours ago",
        "--lines", "10000",
    ])
    assert not result.ok


def test_docker_version_argv_allowed(policy):
    p, _ = policy
    result = p.validate(["docker", "version", "--format", "{{json .}}"])
    assert result.ok, result.reason


def test_docker_info_argv_allowed(policy):
    p, _ = policy
    result = p.validate(["docker", "info", "--format", "{{json .}}"])
    assert result.ok, result.reason


def test_docker_ps_argv_allowed(policy):
    p, _ = policy
    result = p.validate(["docker", "ps", "--format", "{{json .}}", "--no-trunc"])
    assert result.ok, result.reason


def test_docker_ps_all_argv_allowed(policy):
    p, _ = policy
    result = p.validate(
        ["docker", "ps", "--format", "{{json .}}", "--no-trunc", "-a"],
    )
    assert result.ok, result.reason


def test_docker_inspect_argv_allowed(policy):
    p, _ = policy
    result = p.validate(["docker", "inspect", "a1b2c3d4e5f6"])
    assert result.ok, result.reason


def test_docker_exec_argv_rejected(policy):
    p, _ = policy
    result = p.validate(["docker", "exec", "a1b2c3d4e5f6", "sh"])
    assert not result.ok


def test_docker_pull_argv_rejected(policy):
    p, _ = policy
    result = p.validate(["docker", "pull", "alpine"])
    assert not result.ok


def test_docker_run_argv_rejected(policy):
    p, _ = policy
    result = p.validate(["docker", "run", "alpine"])
    assert not result.ok


def test_docker_inspect_invalid_id_rejected(policy):
    p, _ = policy
    result = p.validate(["docker", "inspect", "../etc/passwd"])
    assert not result.ok


def test_daemon_json_path_allowed(policy):
    p, _ = policy
    result = p.validate(["cat", "/etc/docker/daemon.json"])
    assert result.ok, result.reason


def test_add_runtime_allowed_paths_exact_kind():
    policy = CommandPolicy.from_yaml(
        POLICY_PATH,
        remote_home="/home/ubuntu",
    )
    target = "/srv/myservice/requirements.txt"
    # Before: cat target should be rejected (path not in allowed list)
    result_before = policy.validate(["cat", target])
    assert result_before.ok is False

    policy.add_runtime_allowed_paths([target], kind="exact")

    result_after = policy.validate(["cat", target])
    assert result_after.ok is True


def test_firewall_cmd_state_argv_allowed(policy):
    p, _ = policy
    result = p.validate(["firewall-cmd", "--state"])
    assert result.ok, f"unexpected reject: {result.reason}"


def test_firewall_cmd_get_default_zone_argv_allowed(policy):
    p, _ = policy
    result = p.validate(["firewall-cmd", "--get-default-zone"])
    assert result.ok, f"unexpected reject: {result.reason}"


def test_firewall_cmd_list_all_zones_argv_allowed(policy):
    p, _ = policy
    result = p.validate(["firewall-cmd", "--list-all-zones"])
    assert result.ok, f"unexpected reject: {result.reason}"


def test_firewall_cmd_add_service_rejected(policy):
    p, _ = policy
    result = p.validate(["firewall-cmd", "--add-service=ssh"])
    assert not result.ok


# ---- Phase 7f.1: podman / nerdctl / ctr ----


def test_podman_version_allowed(policy):
    p, _ = policy
    result = p.validate(["podman", "version", "--format", "{{json .}}"])
    assert result.ok, result.reason


def test_podman_info_allowed(policy):
    p, _ = policy
    result = p.validate(["podman", "info", "--format", "{{json .}}"])
    assert result.ok, result.reason


def test_podman_ps_allowed(policy):
    p, _ = policy
    result = p.validate(["podman", "ps", "--format", "{{json .}}", "--no-trunc"])
    assert result.ok, result.reason


def test_podman_images_allowed(policy):
    p, _ = policy
    result = p.validate(["podman", "images", "--format", "{{json .}}"])
    assert result.ok, result.reason


def test_podman_exec_rejected(policy):
    p, _ = policy
    result = p.validate(["podman", "exec", "a1b2c3d4e5f6", "sh"])
    assert not result.ok


def test_podman_build_rejected(policy):
    p, _ = policy
    result = p.validate(["podman", "build", "."])
    assert not result.ok


def test_nerdctl_ps_allowed(policy):
    p, _ = policy
    result = p.validate(["nerdctl", "ps", "--format", "{{json .}}", "--no-trunc"])
    assert result.ok, result.reason


def test_nerdctl_inspect_allowed(policy):
    p, _ = policy
    result = p.validate(["nerdctl", "inspect", "a1b2c3d4e5f6"])
    assert result.ok, result.reason


def test_nerdctl_images_allowed(policy):
    p, _ = policy
    result = p.validate(["nerdctl", "images", "--format", "{{json .}}"])
    assert result.ok, result.reason


def test_nerdctl_pull_rejected(policy):
    p, _ = policy
    result = p.validate(["nerdctl", "pull", "alpine"])
    assert not result.ok


def test_ctr_containers_list_allowed(policy):
    p, _ = policy
    result = p.validate(["ctr", "--namespace", "default", "containers", "list", "-q"])
    assert result.ok, result.reason


def test_ctr_containers_info_allowed(policy):
    p, _ = policy
    result = p.validate(
        ["ctr", "--namespace", "default", "containers", "info", "a1b2c3d4e5f6"]
    )
    assert result.ok, result.reason


def test_ctr_images_list_allowed(policy):
    p, _ = policy
    result = p.validate(["ctr", "--namespace", "default", "images", "list", "-q"])
    assert result.ok, result.reason


def test_ctr_containers_start_rejected(policy):
    p, _ = policy
    result = p.validate(
        ["ctr", "--namespace", "default", "containers", "start", "a1b2c3d4e5f6"]
    )
    assert not result.ok


def test_cat_containers_conf_allowed(policy):
    p, _ = policy
    result = p.validate(["cat", "/etc/containers/containers.conf"])
    assert result.ok, result.reason


# ---- Phase 7f.1.1: containerd_daemon_audit ----


def test_containerd_version_allowed(policy):
    p, _ = policy
    result = p.validate(["containerd", "--version"])
    assert result.ok is True


def test_containerd_other_subcommands_rejected(policy):
    p, _ = policy
    # config dump / events / pprof must not be reachable through policy
    for argv in (
        ["containerd", "config", "dump"],
        ["containerd", "events"],
        ["containerd", "pprof"],
    ):
        result = p.validate(argv)
        assert result.ok is False, f"{argv} should be rejected"


def test_containerd_config_toml_path_allowed(policy):
    p, _ = policy
    result = p.validate(["cat", "/etc/containerd/config.toml"])
    assert result.ok is True


def test_containerd_binary_paths_allowed(policy):
    p, _ = policy
    for path in ("/usr/bin/containerd", "/usr/local/bin/containerd"):
        result = p.validate(["stat", "-c", "%n", path])
        assert result.ok is True, f"{path} stat must be allowed"
