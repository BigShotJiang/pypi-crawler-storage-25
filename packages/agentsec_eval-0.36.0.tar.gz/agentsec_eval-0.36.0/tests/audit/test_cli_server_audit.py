"""`agentsec server-audit` end-to-end with stubbed SSHExecutor + tunnel.

Verifies CLI:
- rejects when AUTHORIZATION.txt fails validation,
- prints LOW_ASSURANCE banner when applicable,
- writes server-audit-report.md, findings.json, audit-log.jsonl to --output dir.
"""

import json
from pathlib import Path

from typer.testing import CliRunner

from agentsec.audit.types import RunResult
from agentsec.cli import app

runner = CliRunner()


def _write_auth(path: Path, *, signature_mode: str = "none", out_dir: Path | None = None) -> None:
    out = out_dir or (path.parent / "out")
    body = f"""
target_host: openclaw.example.com
authorized_by: roger@example.com
identity_provider: ""
identity_assertion: ""
valid_from: 2026-01-01T00:00:00Z
valid_until: 2099-01-01T00:00:00Z
scope: [server-audit]
report_output_path_prefix: {out}/
signature_mode: {signature_mode}
"""
    path.write_text(body)


def _make_canned_dict() -> dict:
    """Return a canned RunResult dict that covers all checks including uname."""
    return {
        ("uname", "-s"): RunResult(
            argv=["uname", "-s"],
            command_sha256="a" * 64, exit_code=0,
            stdout="Linux\n", stderr="", duration_ms=0.0,
            bytes_out=0, rejected=False, reject_reason=None,
        ),
        ("openclaw", "security", "audit", "--json"): RunResult(
            argv=["openclaw", "security", "audit", "--json"],
            command_sha256="x" * 64, exit_code=0,
            stdout='{"findings": []}', stderr="", duration_ms=0.0,
            bytes_out=0, rejected=False, reject_reason=None,
        ),
        ("openclaw", "config", "show", "--json"): RunResult(
            argv=["openclaw", "config", "show", "--json"],
            command_sha256="x" * 64, exit_code=0,
            stdout=(
                '{"agent": {"execution": {"require_approval": true}}, '
                '"network": {"allow_outbound": false}, '
                '"skills": {"autoload_untrusted": false}}'
            ),
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("openclaw", "version", "--json"): RunResult(
            argv=["openclaw", "version", "--json"],
            command_sha256="x" * 64, exit_code=0,
            stdout='{"version": "9999.0.0"}',
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # FilesystemCheck (E.1.b): find world-writable files — clean tree in CI
        # Path is materialized: ~/ → /home/ubuntu/ for --user ubuntu (ADR-0004, E.0.f)
        (
            "find", "/home/ubuntu/.openclaw/",
            "-maxdepth", "4", "-type", "f", "-perm", "/o+w",
        ): RunResult(
            argv=[
                "find", "/home/ubuntu/.openclaw/",
                "-maxdepth", "4", "-type", "f", "-perm", "/o+w",
            ],
            command_sha256="f" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # CredentialAuditCheck (E.1.d): no credential files present → 0 findings
        # Path is materialized: ~/ → /home/ubuntu/ for --user ubuntu (ADR-0004, E.0.f)
        **{
            ("stat", "-c", "%a %U %G %n", f"/home/ubuntu/.openclaw/{cred_name}"): RunResult(
                argv=["stat", "-c", "%a %U %G %n", f"/home/ubuntu/.openclaw/{cred_name}"],
                command_sha256="x"*64, exit_code=1, stdout="",
                stderr="No such file", duration_ms=0.0, bytes_out=0,
                rejected=False, reject_reason=None,
            )
            for cred_name in (
                "gateway.token", "signing.key", "openai.token", "id_rsa", "id_ed25519"
            )
        },
        # PluginStaticCheck (E.3.a): empty installed skills → 0 IOC findings
        ("openclaw", "skills", "list", "--json"): RunResult(
            argv=["openclaw", "skills", "list", "--json"],
            command_sha256="x"*64, exit_code=0,
            stdout='{"skills": []}',
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # PluginStaticCheck (E.3.a): no skill .py files → 0 AST findings
        # Path materialized: ~/.openclaw/skills/ → /home/ubuntu/.openclaw/skills/
        ("find", "/home/ubuntu/.openclaw/skills/", "-type", "f", "-name", "*.py"): RunResult(
            argv=["find", "/home/ubuntu/.openclaw/skills/", "-type", "f", "-name", "*.py"],
            command_sha256="x"*64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # LogReviewCheck (E.3.b): no log files found → no grep needed → 0 findings
        ("find", "/var/log/openclaw/", "-maxdepth", "2", "-type", "f", "-name", "*.log"): RunResult(
            argv=["find", "/var/log/openclaw/", "-maxdepth", "2", "-type", "f", "-name", "*.log"],
            command_sha256="x"*64, exit_code=0,
            stdout="",  # no logs found → no grep needed
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # ProcessForensicsCheck (E.1.c): empty listeners + empty ps → 0 findings
        ("ss", "-tlnp"): RunResult(
            argv=["ss", "-tlnp"], command_sha256="e" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("ss", "-ulnp"): RunResult(
            argv=["ss", "-ulnp"], command_sha256="e" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("ps", "-eo", "user,pid,ppid,cmd"): RunResult(
            argv=["ps", "-eo", "user,pid,ppid,cmd"], command_sha256="e" * 64, exit_code=0,
            stdout="USER PID PPID CMD\n", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SysctlAuditCheck (Phase 7e): 9 baseline keys → all match baseline
        ("sysctl", "-n", "kernel.dmesg_restrict", "kernel.kptr_restrict",
         "fs.suid_dumpable", "net.ipv4.conf.all.rp_filter",
         "net.ipv4.conf.all.send_redirects", "net.ipv4.conf.all.accept_redirects",
         "net.ipv4.conf.all.accept_source_route", "net.ipv4.tcp_syncookies"): RunResult(
            argv=["sysctl", "-n", "kernel.dmesg_restrict", "kernel.kptr_restrict",
                  "fs.suid_dumpable", "net.ipv4.conf.all.rp_filter",
                  "net.ipv4.conf.all.send_redirects", "net.ipv4.conf.all.accept_redirects",
                  "net.ipv4.conf.all.accept_source_route", "net.ipv4.tcp_syncookies"],
            command_sha256="s" * 64, exit_code=0,
            stdout="1\n2\n0\n1\n0\n0\n0\n1\n",
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SshdConfigAuditCheck (Phase 7e): sshd -T → all match baseline
        ("sshd", "-T"): RunResult(
            argv=["sshd", "-T"],
            command_sha256="h" * 64, exit_code=0,
            stdout=(
                "permitrootlogin no\n"
                "pubkeyauthentication yes\n"
                "passwordauthentication no\n"
                "permituserenvironment no\n"
            ),
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SudoersAuditCheck (Phase 7e): find /etc/sudoers.d → no files found
        ("find", "/etc/sudoers.d", "-maxdepth", "1", "-type", "f"): RunResult(
            argv=["find", "/etc/sudoers.d", "-maxdepth", "1", "-type", "f"],
            command_sha256="d" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SudoersAuditCheck (Phase 7e): cat /etc/sudoers → clean (no risky patterns)
        ("cat", "/etc/sudoers"): RunResult(
            argv=["cat", "/etc/sudoers"],
            command_sha256="d" * 64, exit_code=0,
            stdout=(
                "%wheel ALL=(wheel) /usr/bin/ls\n"
                "Defaults !visiblepw\n"
                "Defaults use_pty\n"
            ),
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SuidAuditCheck (Phase 7e): find /usr/bin SUID → canonical whitelisted binaries only
        ("find", "/usr/bin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"): RunResult(
            argv=["find", "/usr/bin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"],
            command_sha256="u" * 64, exit_code=0,
            stdout="/usr/bin/sudo\n/usr/bin/passwd\n",
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SuidAuditCheck (Phase 7e): find /usr/sbin SUID → canonical whitelisted binaries only
        ("find", "/usr/sbin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"): RunResult(
            argv=["find", "/usr/sbin", "-maxdepth", "1", "-type", "f", "-perm", "/4000"],
            command_sha256="u" * 64, exit_code=0,
            stdout="/usr/sbin/unix_chkpwd\n/usr/sbin/usernetctl\n",
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # WorldWritableCheck (Phase 7e.1): dynamic profile paths (materialized)
        (
            "find", "/home/ubuntu/.openclaw/",
            "-maxdepth", "4", "-type", "f", "-perm", "/002",
        ): RunResult(
            argv=[
                "find", "/home/ubuntu/.openclaw/",
                "-maxdepth", "4", "-type", "f", "-perm", "/002",
            ],
            command_sha256="w" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("find", "/var/log/openclaw/", "-maxdepth", "4", "-type", "f", "-perm", "/002"): RunResult(
            argv=["find", "/var/log/openclaw/", "-maxdepth", "4", "-type", "f", "-perm", "/002"],
            command_sha256="w" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # WorldWritableCheck (Phase 7e.1): static baseline paths
        ("find", "/tmp/openclaw", "-maxdepth", "4", "-type", "f", "-perm", "/002"): RunResult(
            argv=["find", "/tmp/openclaw", "-maxdepth", "4", "-type", "f", "-perm", "/002"],
            command_sha256="w" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("find", "/etc/cron.d", "-maxdepth", "4", "-type", "f", "-perm", "/002"): RunResult(
            argv=["find", "/etc/cron.d", "-maxdepth", "4", "-type", "f", "-perm", "/002"],
            command_sha256="w" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("find", "/etc/cron.daily", "-maxdepth", "4", "-type", "f", "-perm", "/002"): RunResult(
            argv=["find", "/etc/cron.daily", "-maxdepth", "4", "-type", "f", "-perm", "/002"],
            command_sha256="w" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("find", "/etc/cron.weekly", "-maxdepth", "4", "-type", "f", "-perm", "/002"): RunResult(
            argv=["find", "/etc/cron.weekly", "-maxdepth", "4", "-type", "f", "-perm", "/002"],
            command_sha256="w" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("find", "/etc/cron.monthly", "-maxdepth", "4", "-type", "f", "-perm", "/002"): RunResult(
            argv=["find", "/etc/cron.monthly", "-maxdepth", "4", "-type", "f", "-perm", "/002"],
            command_sha256="w" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # AuditdRulesCheck (Phase 7e.1): auditd installed + enabled + all baseline rules present
        ("auditctl", "-s"): RunResult(
            argv=["auditctl", "-s"],
            command_sha256="a" * 64, exit_code=0,
            stdout="enabled 1\nfailure 1\n",
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        ("auditctl", "-l"): RunResult(
            argv=["auditctl", "-l"],
            command_sha256="a" * 64, exit_code=0,
            stdout=(
                "-w /etc/passwd -p wa -k identity\n"
                "-w /etc/shadow -p wa -k identity\n"
                "-w /etc/group -p wa -k identity\n"
                "-w /etc/sudoers -p wa -k scope\n"
                "-w /etc/sudoers.d -p wa -k scope\n"
                "-w /var/log/lastlog -p wa -k logins\n"
                "-w /var/run/utmp -p wa -k session\n"
                "-a always,exit -F arch=b64 -S execve -k execve\n"
            ),
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SystemdServiceBlacklistCheck (Phase 7e.1): no blacklisted services enabled
        ("systemctl", "list-unit-files", "--type=service,socket",
         "--state=enabled", "--no-legend", "--plain"): RunResult(
            argv=["systemctl", "list-unit-files", "--type=service,socket",
                  "--state=enabled", "--no-legend", "--plain"],
            command_sha256="b" * 64, exit_code=0,
            stdout=(
                "cron.service                       enabled\n"
                "ssh.service                        enabled\n"
            ),
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # SystemdUnitLintCheck (Phase 7e.1): no custom unit files → 0 findings
        ("find", "/etc/systemd/system", "-maxdepth", "1",
         "-name", "*.service", "-type", "f"): RunResult(
            argv=["find", "/etc/systemd/system", "-maxdepth", "1",
                  "-name", "*.service", "-type", "f"],
            command_sha256="l" * 64, exit_code=0,
            stdout="", stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # DockerDaemonAuditCheck / DockerRuntimeAuditCheck / DockerImageCveCheck (Phase 7f):
        # docker binary absent on test host → not_applicable, 0 findings, 0 errors.
        **{
            ("stat", "-c", "%n", path): RunResult(
                argv=["stat", "-c", "%n", path],
                command_sha256="d" * 64, exit_code=1,
                stdout="", stderr="No such file", duration_ms=0.0, bytes_out=0,
                rejected=False, reject_reason=None,
            )
            for path in (
                "/usr/bin/docker",
                "/usr/local/bin/docker",
                "/opt/homebrew/bin/docker",
            )
        },
        # PodmanDaemonAuditCheck / PodmanRuntimeAuditCheck / PodmanImageCveCheck (Phase 7f.1):
        # podman binary absent on test host → not_applicable, 0 findings, 0 errors.
        **{
            ("stat", "-c", "%n", path): RunResult(
                argv=["stat", "-c", "%n", path],
                command_sha256="p" * 64, exit_code=1,
                stdout="", stderr="No such file", duration_ms=0.0, bytes_out=0,
                rejected=False, reject_reason=None,
            )
            for path in (
                "/usr/bin/podman",
                "/usr/local/bin/podman",
                "/opt/homebrew/bin/podman",
            )
        },
        # ContainerdDaemonAuditCheck (Phase 7f.1.1) +
        # ContainerdRuntimeAuditCheck / ContainerdImageCveCheck (Phase 7f.1):
        # containerd socket + binaries (daemon + admin CLIs) absent on test host →
        # not_applicable for all three Checks.
        **{
            ("stat", "-c", "%n", path): RunResult(
                argv=["stat", "-c", "%n", path],
                command_sha256="c" * 64, exit_code=1,
                stdout="", stderr="No such file", duration_ms=0.0, bytes_out=0,
                rejected=False, reject_reason=None,
            )
            for path in (
                "/run/containerd/containerd.sock",
                "/usr/bin/containerd",
                "/usr/local/bin/containerd",
                "/usr/local/bin/nerdctl",
                "/usr/bin/nerdctl",
                "/usr/bin/ctr",
                "/usr/local/bin/ctr",
            )
        },
        # SupplyChainAuditCheck (Phase 7d): clean lock file → 0 findings.
        # Path materialized: ~/.npm-global/... → /home/ubuntu/.npm-global/... (ADR-0004)
        ("cat", "/home/ubuntu/.npm-global/lib/node_modules/openclaw/package-lock.json"): RunResult(
            argv=["cat", "/home/ubuntu/.npm-global/lib/node_modules/openclaw/package-lock.json"],
            command_sha256="n" * 64, exit_code=0,
            stdout=(
                '{"name":"openclaw","lockfileVersion":3,"packages":'
                '{"":{"name":"openclaw","version":"1.0.0"},'
                '"node_modules/safe-pkg":{"version":"2.0.0"}}}'
            ),
            stderr="", duration_ms=0.0, bytes_out=0,
            rejected=False, reject_reason=None,
        ),
        # IptablesAuditCheck / NftablesAuditCheck / UfwAuditCheck (Phase 7e.2)
        # + FirewalldAuditCheck (Phase 7e.3):
        # firewall binaries absent on test host → not_applicable, 0 findings, 0 errors.
        **{
            ("stat", "-c", "%n", path): RunResult(
                argv=["stat", "-c", "%n", path],
                command_sha256="f" * 64, exit_code=1,
                stdout="", stderr="No such file", duration_ms=0.0, bytes_out=0,
                rejected=False, reject_reason=None,
            )
            for path in (
                "/usr/sbin/iptables",
                "/sbin/iptables",
                "/usr/bin/iptables",
                "/usr/sbin/nft",
                "/sbin/nft",
                "/usr/bin/nft",
                "/usr/sbin/ufw",
                "/sbin/ufw",
                "/usr/bin/ufw",
                "/usr/bin/firewall-cmd",
                "/bin/firewall-cmd",
            )
        },
    }


def _scripted_run(monkeypatch, tmp_path, canned: dict):
    """Invoke server-audit with stubbed SSHExecutor.run returning canned results.

    Returns (result, out_dir) where result is the CliRunner result.
    """
    auth = tmp_path / "AUTHORIZATION.txt"
    out = tmp_path / "out"
    _write_auth(auth, out_dir=out)

    def _fake_run(self, argv):
        return canned[tuple(argv)]

    monkeypatch.setattr("agentsec.audit.ssh.SSHExecutor.run", _fake_run)
    monkeypatch.setattr(
        "agentsec.cli.open_local_forward",
        lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("no tunnel in CI")),
    )

    result = runner.invoke(app, [
        "server-audit",
        "--host", "openclaw.example.com",
        "--user", "ubuntu",
        "--key", "/dev/null",
        "--consent-file", str(auth),
        "--output", str(out),
    ])
    return result, out


def test_server_audit_writes_three_artifacts(tmp_path, monkeypatch):
    canned = _make_canned_dict()

    result, out = _scripted_run(monkeypatch, tmp_path, canned)
    assert result.exit_code == 0, result.output
    assert "LOW_ASSURANCE" in result.output
    assert (out / "server-audit-report.md").exists()
    assert (out / "findings.json").exists()
    assert (out / "audit-log.jsonl").exists()
    payload = json.loads((out / "findings.json").read_text())
    assert isinstance(payload, list)
    report_text = (out / "server-audit-report.md").read_text()
    assert "<!-- meta:errors count:0 -->" in report_text, (
        f"Expected no errors in happy-path report, got:\n{report_text}"
    )
    assert "<!-- meta:remote_home value:/home/ubuntu -->" in report_text, (
        f"Expected remote_home meta tag in report, got:\n{report_text}"
    )


def test_server_audit_rejects_expired_authorization(tmp_path):
    auth = tmp_path / "AUTHORIZATION.txt"
    out = tmp_path / "out"
    auth.write_text(f"""
target_host: openclaw.example.com
authorized_by: roger@example.com
identity_provider: ""
identity_assertion: ""
valid_from: 2020-01-01T00:00:00Z
valid_until: 2020-06-01T00:00:00Z
scope: [server-audit]
report_output_path_prefix: {out}/
signature_mode: none
""")
    result = runner.invoke(app, [
        "server-audit",
        "--host", "openclaw.example.com",
        "--user", "u", "--key", "/dev/null",
        "--consent-file", str(auth),
        "--output", str(out),
    ])
    assert result.exit_code != 0
    assert "valid" in result.output.lower() or "expired" in result.output.lower()


# ---- Three new tests for E.0.e ----

def test_cli_server_audit_loads_linux_profile_from_uname(tmp_path, monkeypatch):
    """uname -s must be the FIRST argv called, and 'linux' appears in the report."""
    call_order = []
    canned = _make_canned_dict()

    def _fake_run_ordered(self, argv):
        call_order.append(tuple(argv))
        return canned[tuple(argv)]

    auth = tmp_path / "AUTHORIZATION.txt"
    out = tmp_path / "out"
    _write_auth(auth, out_dir=out)

    monkeypatch.setattr("agentsec.audit.ssh.SSHExecutor.run", _fake_run_ordered)
    monkeypatch.setattr(
        "agentsec.cli.open_local_forward",
        lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("no tunnel in CI")),
    )

    result = runner.invoke(app, [
        "server-audit",
        "--host", "openclaw.example.com",
        "--user", "ubuntu",
        "--key", "/dev/null",
        "--consent-file", str(auth),
        "--output", str(out),
    ])

    assert result.exit_code == 0, result.output
    assert call_order[0] == ("uname", "-s"), (
        f"Expected first call to be ('uname', '-s'), got {call_order[0]!r}"
    )
    report_text = (out / "server-audit-report.md").read_text()
    assert "<!-- meta:profile value:linux -->" in report_text, (
        f"Expected '<!-- meta:profile value:linux -->' in report, got:\n{report_text}"
    )


def test_cli_server_audit_skip_flag_is_removed(tmp_path):
    """Passing --skip-active-test must be rejected by the CLI (option removed)."""
    auth = tmp_path / "AUTHORIZATION.txt"
    out = tmp_path / "out"
    _write_auth(auth, out_dir=out)

    result = runner.invoke(app, [
        "server-audit",
        "--host", "openclaw.example.com",
        "--user", "ubuntu",
        "--key", "/dev/null",
        "--consent-file", str(auth),
        "--output", str(out),
        "--skip-active-test",
    ])
    assert result.exit_code != 0
    assert (
        "no such option" in result.output.lower()
        or "unexpected" in result.output.lower()
        or (result.exception is not None and "no such option" in str(result.exception).lower())
    ), f"Expected CLI rejection of --skip-active-test, got: {result.output!r}"


def test_cli_server_audit_active_test_skipped_when_tunnel_fails(tmp_path, monkeypatch):
    """When the tunnel factory raises, active_test should appear as skipped in the report."""
    canned = _make_canned_dict()

    result, out = _scripted_run(monkeypatch, tmp_path, canned)

    assert result.exit_code == 0, result.output
    report_text = (out / "server-audit-report.md").read_text()
    # The report should mention active_test (as a check) and skipped status
    assert "active_test" in report_text, (
        f"Expected 'active_test' in report, got:\n{report_text}"
    )
    assert "skipped" in report_text.lower(), (
        f"Expected 'skipped' in report, got:\n{report_text}"
    )
