"""Finding model + fingerprint stability."""

from agentsec.audit.findings import Finding


def test_finding_required_fields():
    f = Finding(
        check="native_audit",
        severity="high",
        title="OpenClaw skill has unsafe filesystem write",
        description="Skill X writes to /etc",
        evidence={"skill": "X", "path": "/etc/foo"},
        remediation="Disable skill X",
        threat_refs=["TI-OPENCLAW-CVE-2026-0001"],
    )
    assert f.fingerprint  # auto-derived
    assert len(f.fingerprint) == 64  # sha256 hex


def test_finding_fingerprint_stable_across_evidence_key_order():
    a = Finding(check="c", severity="low", title="t", description="d",
                evidence={"x": 1, "y": 2}, remediation="r", threat_refs=[])
    b = Finding(check="c", severity="low", title="t", description="d",
                evidence={"y": 2, "x": 1}, remediation="r", threat_refs=[])
    assert a.fingerprint == b.fingerprint


def test_finding_fingerprint_changes_with_title():
    a = Finding(check="c", severity="low", title="t1", description="d",
                evidence={}, remediation="r", threat_refs=[])
    b = Finding(check="c", severity="low", title="t2", description="d",
                evidence={}, remediation="r", threat_refs=[])
    assert a.fingerprint != b.fingerprint


def test_finding_severity_enum():
    import pytest
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        Finding(check="c", severity="extreme", title="t", description="d",
                evidence={}, remediation="r", threat_refs=[])
