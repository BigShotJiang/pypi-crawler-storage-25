import json
import subprocess
import sys
from pathlib import Path

from agentsec.audit.ioc import IOC_DIR


def test_cve_database_is_an_array_keyed_by_cve_id():
    db = json.loads((IOC_DIR / "cve_database.json").read_text())
    assert isinstance(db, list)
    ids = [e["id"] for e in db]
    assert ids == sorted(set(ids)), "cve_database.json must be sorted + deduped"
    assert len(ids) >= 1, "expected at least one TI-OPENCLAW-CVE-* entry"
    for entry in db:
        assert entry["id"].startswith("TI-OPENCLAW-CVE-")
        for required in ("id", "claim", "confidence"):
            assert required in entry, f"missing {required}: {entry}"


def test_cve_database_matches_threat_intel_yaml(tmp_path):
    """Build the DB fresh into a temp file; assert it equals the committed copy."""
    out = tmp_path / "cve_database.json"
    repo_root = Path(__file__).resolve().parents[2]
    subprocess.check_call([
        sys.executable, str(repo_root / "scripts" / "build_cve_db.py"),
        "--intel", str(repo_root / "src" / "agentsec" / "audit" / "ioc" / "threat_intel.yaml"),
        "--out", str(out),
    ])
    committed = (IOC_DIR / "cve_database.json").read_text()
    fresh = out.read_text()
    assert fresh == committed, (
        "cve_database.json is out of sync with threat_intel.yaml; run "
        "`python scripts/build_cve_db.py` and commit the result."
    )
