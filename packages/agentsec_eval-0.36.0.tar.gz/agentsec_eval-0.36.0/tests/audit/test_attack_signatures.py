import yaml

from agentsec.audit.ioc import IOC_DIR

# Same metachar set the policy rejects in final argv
_FORBIDDEN = set("|&;`$<>\n")


def test_attack_signatures_schema_and_no_metachars():
    sigs = yaml.safe_load((IOC_DIR / "attack_signatures.yaml").read_text())
    assert isinstance(sigs, list)
    assert len(sigs) >= 5, "v0.2.0 seed requires ≥5 signatures"
    seen_ids = set()
    for s in sigs:
        for required in ("id", "pattern", "severity", "claim", "threat_refs"):
            assert required in s, f"missing {required}: {s}"
        assert s["id"] not in seen_ids
        seen_ids.add(s["id"])
        # Pattern must NOT contain any shell metachar; the policy would reject
        # the resulting `grep` argv even before the channel runs.
        bad = _FORBIDDEN & set(s["pattern"])
        assert not bad, f"signature {s['id']} pattern contains metachars {bad!r}"
        assert s["severity"] in {"critical", "high", "medium", "low", "info"}
        assert isinstance(s["threat_refs"], list)
