"""config_audit check — diffs `openclaw config show --json` against baseline."""

import asyncio
import json
from unittest.mock import MagicMock

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.config_audit import ConfigAuditCheck
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult


def _ctx(config_payload: dict, exit_code: int = 0, rejected: bool = False):
    executor = MagicMock()
    body = json.dumps(config_payload)
    executor.run = MagicMock(return_value=RunResult(
        argv=["openclaw", "config", "show", "--json"],
        command_sha256="x" * 64, exit_code=exit_code,
        stdout=body, stderr="", duration_ms=1.0, bytes_out=len(body),
        rejected=rejected, reject_reason="rej" if rejected else None,
    ))
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=None, profile=LINUX, status=CheckStatus(),
    )


def test_no_findings_when_config_matches_baseline():
    ctx = _ctx({
        "agent": {"execution": {"require_approval": True}},
        "network": {"allow_outbound": False},
        "skills": {"autoload_untrusted": False},
    })
    findings = asyncio.run(ConfigAuditCheck().run(ctx))
    assert findings == []


def test_finding_emitted_when_require_approval_disabled():
    ctx = _ctx({
        "agent": {"execution": {"require_approval": False}},
        "network": {"allow_outbound": False},
        "skills": {"autoload_untrusted": False},
    })
    findings = asyncio.run(ConfigAuditCheck().run(ctx))
    assert len(findings) == 1
    assert findings[0].severity == "high"
    assert "require_approval" in findings[0].title


def test_three_findings_when_all_three_keys_violated():
    ctx = _ctx({
        "agent": {"execution": {"require_approval": False}},
        "network": {"allow_outbound": True},
        "skills": {"autoload_untrusted": True},
    })
    findings = asyncio.run(ConfigAuditCheck().run(ctx))
    severities = sorted(f.severity for f in findings)
    assert severities == ["critical", "high", "medium"]


def test_skipped_when_command_rejected():
    ctx = _ctx({}, rejected=True)
    findings = asyncio.run(ConfigAuditCheck().run(ctx))
    assert findings == []
    assert ctx.status.is_skipped is True
