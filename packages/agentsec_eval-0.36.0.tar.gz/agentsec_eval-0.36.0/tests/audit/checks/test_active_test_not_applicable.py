"""active_test: platform-agnostic — empty _REQUIRED_PATHS, services sanity check."""

from agentsec.audit.platform_profile import LINUX


def test_linux_profile_has_services_list_for_active_test():
    assert LINUX.services.get("list"), "active_test relies on this being populated"
