import pytest
import yaml

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.log_review import LogReviewCheck
from agentsec.audit.ioc import IOC_DIR
from agentsec.audit.platform_profile import LINUX, PlatformProfile
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult


def _ok(argv, stdout, exit_code=0):
    return RunResult(
        argv=argv, command_sha256="x"*64, exit_code=exit_code, stdout=stdout, stderr="",
        duration_ms=1.0, bytes_out=len(stdout.encode()),
        rejected=False, reject_reason=None,
    )


@pytest.mark.asyncio
async def test_log_review_emits_finding_per_signature_match():
    sigs = yaml.safe_load((IOC_DIR / "attack_signatures.yaml").read_text())
    pattern = sigs[0]["pattern"]
    sig_id = sigs[0]["id"]

    list_argv = ["find", "/var/log/openclaw/", "-maxdepth", "2", "-type", "f", "-name", "*.log"]
    log_path = "/var/log/openclaw/gateway.log"
    grep_argv = ["grep", "-i", "-c", "-F", pattern, log_path]

    class _Executor:
        def __init__(self): self.calls = []
        def run(self, argv):
            self.calls.append(argv)
            if argv == list_argv:
                return _ok(list_argv, log_path + "\n")
            if argv == grep_argv:
                return _ok(grep_argv, "3\n")  # 3 matches
            return _ok(argv, "0\n", exit_code=1)

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await LogReviewCheck().run(ctx)
    matching = [f for f in findings if f.evidence.get("signature_id") == sig_id]
    assert len(matching) == 1
    assert matching[0].evidence["match_count"] == 3
    assert matching[0].evidence["log_path"] == log_path


@pytest.mark.asyncio
async def test_log_review_clean_when_no_logs_match():
    """No log files found -> 0 findings, no skip."""
    list_argv = ["find", "/var/log/openclaw/", "-maxdepth", "2", "-type", "f", "-name", "*.log"]

    class _Executor:
        def run(self, argv):
            if argv == list_argv:
                return _ok(list_argv, "")
            return _ok(argv, "0\n", exit_code=1)

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await LogReviewCheck().run(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_log_review_caps_fan_out_and_emits_truncation_finding():
    """bug_005: log dir with >200 files should scan first 200 and emit one
    severity=info Finding documenting the truncation (no silent partial sweep)."""
    list_argv = ["find", "/var/log/openclaw/", "-maxdepth", "2", "-type", "f", "-name", "*.log"]
    log_paths = [f"/var/log/openclaw/log-{i:04d}.log" for i in range(250)]

    grep_calls: list[list[str]] = []

    class _Executor:
        def run(self, argv):
            if argv == list_argv:
                return _ok(list_argv, "\n".join(log_paths) + "\n")
            if argv[0] == "grep":
                grep_calls.append(argv)
                return _ok(argv, "0\n")
            return _ok(argv, "", exit_code=1)

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await LogReviewCheck().run(ctx)

    truncation = [f for f in findings if f.severity == "info"]
    assert len(truncation) == 1
    assert truncation[0].evidence["scanned"] == 200
    assert truncation[0].evidence["skipped"] == 50

    # Each grep call must target one of the first 200 log paths — log-0200..0249
    # must never appear.
    grepped_paths = {call[-1] for call in grep_calls}
    assert "/var/log/openclaw/log-0199.log" in grepped_paths
    assert "/var/log/openclaw/log-0200.log" not in grepped_paths
    assert "/var/log/openclaw/log-0249.log" not in grepped_paths


@pytest.mark.asyncio
async def test_log_review_not_applicable_when_log_dir_missing():
    """Profile lacking log_dir -> not_applicable, executor never called."""
    profile = PlatformProfile(
        name="linux",
        paths={"openclaw_home": "/home/u/.openclaw/"},
        services={"list": [["systemctl", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
    )

    class _Executor:
        def run(self, argv):
            raise AssertionError("log_review should not call executor when not_applicable")

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
    )
    findings = await LogReviewCheck().run(ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


@pytest.mark.asyncio
async def test_log_review_journald_single_unit_match():
    """LINUX_USER_MODE → one journalctl call per unit; pattern hits become Findings."""
    from agentsec.audit.platform_profile import (
        JournaldLogSource,
        PlatformProfile,
    )
    from agentsec.config import LogReviewConfig

    sigs = yaml.safe_load((IOC_DIR / "attack_signatures.yaml").read_text())
    pattern = sigs[0]["pattern"]
    sig_id = sigs[0]["id"]

    journal_text = (
        "2026-05-07 some startup line\n"
        f"2026-05-07 hit: {pattern}\n"
        "2026-05-07 unrelated\n"
        f"2026-05-07 another {pattern.upper()} occurrence\n"
    )
    expected_argv = [
        "journalctl", "--user", "--no-pager", "--output=cat",
        "-u", "openclaw-gateway.service",
        "--since", "24 hours ago",
        "--lines", "10000",
    ]

    class _Executor:
        def __init__(self): self.calls = []
        def run(self, argv):
            self.calls.append(argv)
            if argv == expected_argv:
                return _ok(argv, journal_text)
            return _ok(argv, "", exit_code=1)

    profile = PlatformProfile(
        name="linux",
        paths={"openclaw_home": "/home/u/.openclaw/"},
        services={"list": [["systemctl", "--user", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
        log_source=JournaldLogSource(
            user=True, units=("openclaw-gateway.service",),
        ),
    )
    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
        log_review_config=LogReviewConfig(),
    )
    findings = await LogReviewCheck().run(ctx)
    matching = [f for f in findings if f.evidence.get("signature_id") == sig_id]
    assert len(matching) == 1
    assert matching[0].evidence["match_count"] == 2  # case-insensitive
    assert matching[0].evidence["unit"] == "openclaw-gateway.service"
    # Config-level params must NOT appear on per-signature findings (fingerprint
    # stability: tweaking journald_since_hours / journald_max_lines must not
    # cause agentsec diff to report all signature findings as "drifted").
    assert "journald_user" not in matching[0].evidence
    assert "since_hours" not in matching[0].evidence
    assert "lines_cap" not in matching[0].evidence


@pytest.mark.asyncio
async def test_log_review_journald_no_config_uses_defaults():
    """Missing log_review_config → fall back to LogReviewConfig() defaults
    so the check is robust to construction sites that forget to wire it."""
    from agentsec.audit.platform_profile import (
        JournaldLogSource,
        PlatformProfile,
    )

    journal_text = "2026-05-07 quiet line\n"
    seen_argv: list[list[str]] = []

    class _Executor:
        def run(self, argv):
            seen_argv.append(argv)
            return _ok(argv, journal_text)

    profile = PlatformProfile(
        name="linux", paths={"openclaw_home": "/home/u/.openclaw/"},
        services={"list": [["systemctl", "--user", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
        log_source=JournaldLogSource(user=True, units=("x.service",)),
    )
    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
        # log_review_config intentionally omitted → defaults to None
    )
    await LogReviewCheck().run(ctx)
    # Default since=24h, lines=10000
    assert seen_argv == [[
        "journalctl", "--user", "--no-pager", "--output=cat",
        "-u", "x.service",
        "--since", "24 hours ago",
        "--lines", "10000",
    ]]


@pytest.mark.asyncio
async def test_log_review_journald_skips_failed_unit_continues_others():
    """unit A succeeds, unit B fails → A still produces findings; B silently skipped."""
    from agentsec.audit.platform_profile import (
        JournaldLogSource,
        PlatformProfile,
    )
    from agentsec.config import LogReviewConfig

    sigs = yaml.safe_load((IOC_DIR / "attack_signatures.yaml").read_text())
    pattern = sigs[0]["pattern"]

    class _Executor:
        def run(self, argv):
            unit_idx = argv.index("-u") + 1
            unit = argv[unit_idx]
            if unit == "openclaw-gateway.service":
                return _ok(argv, f"hit: {pattern}\n")
            return _ok(argv, "", exit_code=1)  # Unit not found

    profile = PlatformProfile(
        name="linux", paths={"openclaw_home": "/h/.openclaw/"},
        services={"list": [["systemctl", "--user", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
        log_source=JournaldLogSource(
            user=True,
            units=("openclaw-gateway.service", "openclaw-node.service"),
        ),
    )
    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
        log_review_config=LogReviewConfig(),
    )
    findings = await LogReviewCheck().run(ctx)
    units_with_findings = {f.evidence["unit"] for f in findings if "unit" in f.evidence}
    assert units_with_findings == {"openclaw-gateway.service"}
    # Status should remain non-skipped (at least one unit succeeded).
    assert not ctx.status.is_skipped


@pytest.mark.asyncio
async def test_log_review_journald_all_units_fail_skips_check():
    from agentsec.audit.platform_profile import (
        JournaldLogSource,
        PlatformProfile,
    )
    from agentsec.config import LogReviewConfig

    class _Executor:
        def run(self, argv):
            return _ok(argv, "", exit_code=1)

    profile = PlatformProfile(
        name="linux", paths={"openclaw_home": "/h/.openclaw/"},
        services={"list": [["systemctl", "--user", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
        log_source=JournaldLogSource(
            user=True,
            units=("a.service", "b.service"),
        ),
    )
    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
        log_review_config=LogReviewConfig(),
    )
    findings = await LogReviewCheck().run(ctx)
    assert findings == []
    assert ctx.status.is_skipped
    assert "所有 unit" in (ctx.status.skip_reason or "")


@pytest.mark.asyncio
async def test_log_review_journald_lines_cap_emits_truncation_finding():
    from agentsec.audit.platform_profile import (
        JournaldLogSource,
        PlatformProfile,
    )
    from agentsec.config import LogReviewConfig

    cfg = LogReviewConfig(journald_max_lines=100)
    text = "\n".join(f"line-{i}" for i in range(100)) + "\n"  # exactly 100 lines

    class _Executor:
        def run(self, argv):
            return _ok(argv, text)

    profile = PlatformProfile(
        name="linux", paths={"openclaw_home": "/h/.openclaw/"},
        services={"list": [["systemctl", "--user", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
        log_source=JournaldLogSource(user=True, units=("x.service",)),
    )
    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
        log_review_config=cfg,
    )
    findings = await LogReviewCheck().run(ctx)
    truncs = [f for f in findings if f.severity == "info" and "覆盖" in f.title]
    assert len(truncs) == 1
    assert truncs[0].evidence["reason"] == "lines_cap"


@pytest.mark.asyncio
async def test_log_review_journald_byte_cap_emits_truncation_finding():
    from agentsec.audit.platform_profile import (
        JournaldLogSource,
        PlatformProfile,
    )
    from agentsec.config import LogReviewConfig

    cfg = LogReviewConfig(journald_max_lines=100_000)
    # max_output_bytes default in policy is 1 MiB. 0.96 MiB worth of lines
    # crosses the 0.95 threshold.
    bigline = "x" * 100
    n_lines = int(1_048_576 * 0.96 / (len(bigline) + 1))
    text = ("\n".join([bigline] * n_lines)) + "\n"

    class _Executor:
        def run(self, argv):
            res = _ok(argv, text)
            return res

    profile = PlatformProfile(
        name="linux", paths={"openclaw_home": "/h/.openclaw/"},
        services={"list": [["systemctl", "--user", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
        log_source=JournaldLogSource(user=True, units=("x.service",)),
    )
    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
        log_review_config=cfg,
    )
    findings = await LogReviewCheck().run(ctx)
    truncs = [f for f in findings if f.severity == "info" and "覆盖" in f.title]
    assert len(truncs) == 1
    assert truncs[0].evidence["reason"] == "byte_cap"


@pytest.mark.asyncio
async def test_log_review_journald_dual_truncation_emits_only_one_finding():
    """Both signals fire on the same unit → still 1 truncation finding."""
    from agentsec.audit.platform_profile import (
        JournaldLogSource,
        PlatformProfile,
    )
    from agentsec.config import LogReviewConfig

    cfg = LogReviewConfig(journald_max_lines=10_000)
    bigline = "x" * 110
    n_lines = max(int(1_048_576 * 0.96 / (len(bigline) + 1)), 10_000)
    text = ("\n".join([bigline] * n_lines)) + "\n"

    class _Executor:
        def run(self, argv):
            return _ok(argv, text)

    profile = PlatformProfile(
        name="linux", paths={"openclaw_home": "/h/.openclaw/"},
        services={"list": [["systemctl", "--user", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
        log_source=JournaldLogSource(user=True, units=("x.service",)),
    )
    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=profile, status=CheckStatus(),
        log_review_config=cfg,
    )
    findings = await LogReviewCheck().run(ctx)
    truncs = [f for f in findings if f.severity == "info" and "覆盖" in f.title]
    assert len(truncs) == 1
