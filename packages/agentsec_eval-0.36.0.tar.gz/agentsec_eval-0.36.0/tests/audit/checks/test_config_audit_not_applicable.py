"""config_audit not_applicable semantics — paths.openclaw_home guard."""

import pytest

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.config_audit import ConfigAuditCheck
from agentsec.audit.platform_profile import PlatformProfile
from agentsec.audit.redactor import Redactor


def _executor_that_must_not_be_called():
    class _E:
        def run(self, argv):
            raise AssertionError(
                "config_audit must not call executor when not_applicable"
            )
    return _E()


@pytest.mark.asyncio
async def test_config_audit_not_applicable_when_profile_lacks_openclaw_home():
    profile = PlatformProfile(
        name="linux",
        paths={"log_dir": "/var/log/openclaw/"},  # no openclaw_home
        services={"list": [["systemctl", "list-units"]]},
        listening_check=[["ss", "-tlnp"]],
    )
    ctx = CheckContext(
        executor=_executor_that_must_not_be_called(),
        redactor=Redactor(),
        ioc_dir=None,
        profile=profile,
        status=CheckStatus(),
    )
    findings = await ConfigAuditCheck().run(ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "paths.openclaw_home" in (ctx.status.not_applicable_reason or "")
