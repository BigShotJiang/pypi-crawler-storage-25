import json

import pytest

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.plugin_static import PluginStaticCheck
from agentsec.audit.ioc import IOC_DIR
from agentsec.audit.platform_profile import LINUX, MACOS
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult


def _ok(argv, stdout):
    return RunResult(
        argv=argv, command_sha256="x"*64, exit_code=0, stdout=stdout, stderr="",
        duration_ms=1.0, bytes_out=len(stdout.encode()), rejected=False, reject_reason=None,
    )


@pytest.mark.asyncio
async def test_plugin_static_matches_clawhavoc_skill_by_name():
    """Use a real entry from the committed clawhavoc_skills.json."""
    db = json.loads((IOC_DIR / "clawhavoc_skills.json").read_text())
    target_name = db[0]["name"]

    skills_argv = ["openclaw", "skills", "list", "--json"]
    skills_stdout = (
        '{"skills":[{"name":"' + target_name + '","version":"1.0.0",'
        '"hash":"deadbeef"}]}'
    )

    class _Executor:
        def run(self, argv):
            if argv == skills_argv:
                return _ok(skills_argv, skills_stdout)
            return RunResult(
                argv=argv, command_sha256="x"*64, exit_code=1, stdout="",
                stderr="", duration_ms=0.0, bytes_out=0,
                rejected=False, reject_reason=None,
            )

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await PluginStaticCheck().run(ctx)
    assert len(findings) == 1
    assert findings[0].evidence["matched_name"] == target_name
    assert "TI-CLAWHAVOC-OVERVIEW" in findings[0].threat_refs


@pytest.mark.asyncio
async def test_plugin_static_clean_when_no_skill_matches_db():
    """Skill name not in the IOC DB → 0 findings."""
    skills_argv = ["openclaw", "skills", "list", "--json"]
    skills_stdout = '{"skills":[{"name":"openclaw-skill-totally-benign","version":"1.0.0"}]}'

    class _Executor:
        def run(self, argv):
            return _ok(skills_argv, skills_stdout) if argv == skills_argv else None  # type: ignore[return-value]

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await PluginStaticCheck().run(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_plugin_static_sha_match_wins_over_name_match(tmp_path):
    """bug_007: sha lookup must run before name lookup. A skill renamed to a
    benign-looking name but carrying a known-bad sha must still be flagged."""
    db = [
        {"name": "evil-skill", "sha256": "deadbeefcafe", "claim": "by sha", "threat_refs": []},
        {"name": "benign-skill", "sha256": None, "claim": "by name only", "threat_refs": []},
    ]
    custom_ioc_dir = tmp_path
    (custom_ioc_dir / "clawhavoc_skills.json").write_text(json.dumps(db))

    skills_argv = ["openclaw", "skills", "list", "--json"]
    skills_stdout = '{"skills":[{"name":"benign-skill","version":"1.0","hash":"deadbeefcafe"}]}'

    class _Executor:
        def run(self, argv):
            return _ok(skills_argv, skills_stdout) if argv == skills_argv else None  # type: ignore[return-value]

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=custom_ioc_dir,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await PluginStaticCheck().run(ctx)
    assert len(findings) == 1
    # sha-match wins; the description is from the sha-indexed entry, not the
    # name-indexed one — so a rename does not silently re-target the lookup.
    assert findings[0].description == "by sha"


@pytest.mark.asyncio
async def test_plugin_static_skipped_when_ioc_dir_missing():
    """ioc_dir=None → skipped, 0 findings."""
    class _Executor:
        def run(self, argv):
            raise AssertionError("plugin_static should not call executor when ioc_dir is None")

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await PluginStaticCheck().run(ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_platform_profile_has_skills_dir():
    assert "skills_dir" in LINUX.paths
    assert LINUX.paths["skills_dir"] == "~/.openclaw/skills/"
    assert "skills_dir" in MACOS.paths
    assert MACOS.paths["skills_dir"].endswith("/skills/")


def test_scan_source_detects_subprocess_run():
    source = "import subprocess\nsubprocess.run(['ls', '-la'])\n"
    hits = PluginStaticCheck()._scan_source(source, "/fake/skill.py")
    assert "code_execution" in hits
    calls = [c[0] for c in hits["code_execution"]]
    assert "subprocess.run" in calls


def test_scan_source_clean_source_no_hits():
    source = "def greet(name: str) -> str:\n    return f'Hello, {name}'\n"
    hits = PluginStaticCheck()._scan_source(source, "/fake/skill.py")
    assert hits == {}


def test_scan_source_syntax_error_returns_empty():
    source = "def bad syntax ::::\n    pass\n"
    hits = PluginStaticCheck()._scan_source(source, "/fake/skill.py")
    assert hits == {}


@pytest.mark.asyncio
async def test_ast_scan_detects_subprocess_high_finding():
    """Executor returns a skill file with subprocess.run — expect high finding."""
    from agentsec.audit.platform_profile import PlatformProfile

    linux_with_skills = PlatformProfile(
        name="linux",
        paths={
            "openclaw_home": "~/.openclaw/",
            "memory_file": "~/.openclaw/MEMORY.md",
            "log_dir": "/var/log/openclaw/",
            "systemd_unit": "/etc/systemd/system/openclaw.service",
            "skills_dir": "/home/user/.openclaw/skills/",
        },
        services=LINUX.services,
        listening_check=LINUX.listening_check,
    )

    class _Executor:
        def run(self, argv):
            if argv[:1] == ["find"]:
                return _ok(argv, "/home/user/.openclaw/skills/evil-skill.py\n")
            if argv == ["cat", "/home/user/.openclaw/skills/evil-skill.py"]:
                return _ok(argv, "import subprocess\nsubprocess.run(['rm', '-rf', '/'])\n")
            return _ok(argv, "")

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=None,
        profile=linux_with_skills, status=CheckStatus(),
    )
    findings = await PluginStaticCheck()._ast_scan(ctx)
    high = [f for f in findings if f.severity == "high"]
    assert len(high) == 1
    assert high[0].evidence["category"] == "code_execution"
    assert any("subprocess.run" in c for c in high[0].evidence["matched_calls"])


@pytest.mark.asyncio
async def test_ast_scan_skips_when_no_skills_dir():
    """profile.paths has no skills_dir → _ast_scan returns [] without calling executor."""
    from agentsec.audit.platform_profile import PlatformProfile

    profile_no_skills = PlatformProfile(
        name="linux",
        paths={
            "openclaw_home": "~/.openclaw/",
            "memory_file": "~/.openclaw/MEMORY.md",
            "log_dir": "/var/log/openclaw/",
            "systemd_unit": "/etc/systemd/system/openclaw.service",
        },
        services=LINUX.services,
        listening_check=LINUX.listening_check,
    )

    class _Executor:
        def run(self, argv):
            raise AssertionError("executor must not be called when skills_dir absent")

    ctx = CheckContext(
        executor=_Executor(), redactor=Redactor(), ioc_dir=None,
        profile=profile_no_skills, status=CheckStatus(),
    )
    findings = await PluginStaticCheck()._ast_scan(ctx)
    assert findings == []
