"""Check ABC contract — subclasses declare id and implement async run(ctx)."""

import asyncio

import pytest

from agentsec.audit.checks.base import Check, CheckContext, CheckStatus
from agentsec.audit.findings import Finding
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor


class _NoOpCheck(Check):
    id = "noop"

    async def run(self, ctx: CheckContext) -> list[Finding]:
        return []


def test_check_subclass_must_set_id():
    class _Bad(Check):
        async def run(self, ctx):
            return []

    with pytest.raises(TypeError, match="id"):
        _Bad()


def test_no_op_check_returns_empty_list():
    c = _NoOpCheck()
    findings = asyncio.run(c.run(CheckContext(
        executor=None, redactor=None, ioc_dir=None, profile=LINUX, status=CheckStatus(),
    )))
    assert findings == []


def test_check_status_can_mark_skipped():
    s = CheckStatus()
    s.skipped("ssh tunnel down")
    assert s.is_skipped is True
    assert s.skip_reason == "ssh tunnel down"


def test_check_status_can_mark_not_applicable():
    s = CheckStatus()
    s.not_applicable("macOS-only check")
    assert s.is_not_applicable is True


def test_make_finding_redacts_title_description_remediation_and_string_evidence():
    """bug_002+003: every operator-visible string field must pass through
    ctx.redactor before reaching the report. Non-string evidence values
    (ints, None) are preserved as-is."""
    ctx = CheckContext(
        executor=None, redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    f = _NoOpCheck().make_finding(
        ctx,
        severity="high",
        title="leaked sk-ant-12345678901234567890 in title",
        description="leaked sk-ant-12345678901234567890 in description",
        evidence={
            "leaky_str": "sk-ant-12345678901234567890",
            "port": 8080,
            "user": "alice",
            "absent": None,
        },
        remediation="rotate sk-ant-12345678901234567890 immediately",
        threat_refs=[],
    )
    assert "sk-ant-" not in f.title
    assert "sk-ant-" not in f.description
    assert "sk-ant-" not in f.remediation
    assert "sk-ant-" not in f.evidence["leaky_str"]
    assert f.evidence["port"] == 8080
    assert f.evidence["user"] == "alice"
    assert f.evidence["absent"] is None
