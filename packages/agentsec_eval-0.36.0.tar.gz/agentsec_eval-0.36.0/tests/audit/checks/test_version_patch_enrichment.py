# tests/audit/checks/test_version_patch_enrichment.py
import json

import pytest

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.version_patch import VersionPatchCheck
from agentsec.audit.ioc import IOC_DIR
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult


@pytest.mark.asyncio
async def test_version_patch_finding_includes_cve_db_link():
    """When a CVE in cve_database.json matches the running version, the
    Finding evidence carries the DB-side url for traceability."""
    db = json.loads((IOC_DIR / "cve_database.json").read_text())
    # Pick the first DB entry that has affected_versions populated
    target = next(e for e in db if e.get("affected_versions"))
    target_id = target["id"]

    # Choose a version that the entry's specifier should match.
    test_version = "0.0.1"

    argv = ["openclaw", "version", "--json"]

    class _E:
        def run(self, a):
            assert a == argv
            return RunResult(
                argv=argv, command_sha256="x"*64, exit_code=0,
                stdout=json.dumps({"version": test_version}),
                stderr="", duration_ms=1.0, bytes_out=20,
                rejected=False, reject_reason=None,
            )

    ctx = CheckContext(
        executor=_E(), redactor=Redactor(), ioc_dir=IOC_DIR,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await VersionPatchCheck().run(ctx)
    matching = [f for f in findings if target_id in f.threat_refs]
    assert matching, f"expected a Finding for {target_id} given test_version={test_version}"
    assert "cve_db_url" in matching[0].evidence, "cve_database link missing"
    assert matching[0].evidence["cve_db_url"] == target["url"]
