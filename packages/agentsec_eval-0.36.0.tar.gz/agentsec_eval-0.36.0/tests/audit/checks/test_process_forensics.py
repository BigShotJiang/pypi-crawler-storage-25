import pytest

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.process_forensics import ProcessForensicsCheck
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult


def _ok(argv, stdout):
    return RunResult(
        argv=argv, command_sha256="x"*64, exit_code=0, stdout=stdout, stderr="",
        duration_ms=1.0, bytes_out=len(stdout.encode()), rejected=False, reject_reason=None,
    )


class _Executor:
    def __init__(self, mapping): self.mapping = mapping
    def run(self, argv):
        for expected, r in self.mapping:
            if expected == argv:
                return r
        raise AssertionError(f"unexpected argv: {argv}")


@pytest.mark.asyncio
async def test_process_forensics_flags_listener_owned_by_non_openclaw_process():
    """ss reports a listener on :18800 whose pid resolves to a process whose
    cmd does not contain 'openclaw' — that's a Finding."""
    ss_tlnp = ["ss", "-tlnp"]
    ss_ulnp = ["ss", "-ulnp"]
    ps = ["ps", "-eo", "user,pid,ppid,cmd"]
    executor = _Executor([
        (ss_tlnp, _ok(ss_tlnp,
            "LISTEN 0 128 0.0.0.0:18800 0.0.0.0:* "
            "users:((\"strange-daemon\",pid=4711,fd=5))\n")),
        (ss_ulnp, _ok(ss_ulnp, "")),
        (ps, _ok(ps,
            "USER PID PPID CMD\nroot 4711 1 /usr/local/bin/strange-daemon --secret\n")),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await ProcessForensicsCheck().run(ctx)
    assert len(findings) == 1
    assert findings[0].evidence["port"] == 18800
    assert findings[0].evidence["cmd"] == "/usr/local/bin/strange-daemon --secret"


@pytest.mark.asyncio
async def test_process_forensics_quiet_when_only_openclaw_listens():
    ss_tlnp = ["ss", "-tlnp"]
    ss_ulnp = ["ss", "-ulnp"]
    ps = ["ps", "-eo", "user,pid,ppid,cmd"]
    executor = _Executor([
        (ss_tlnp, _ok(ss_tlnp,
            "LISTEN 0 128 127.0.0.1:18789 0.0.0.0:* "
            "users:((\"openclaw\",pid=2345,fd=7))\n")),
        (ss_ulnp, _ok(ss_ulnp, "")),
        (ps, _ok(ps,
            "USER PID PPID CMD\nopenclaw 2345 1 /usr/local/bin/openclaw serve\n")),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await ProcessForensicsCheck().run(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_process_forensics_redacts_secrets_in_cmd():
    """A backdoor process's argv may contain tokens; the cmd must pass
    through Redactor before landing in evidence/description."""
    ss_tlnp = ["ss", "-tlnp"]
    ss_ulnp = ["ss", "-ulnp"]
    ps = ["ps", "-eo", "user,pid,ppid,cmd"]
    leaky_cmd = (
        "/usr/bin/curl --header "
        "Authorization: Bearer sk-ant-api03-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    )
    executor = _Executor([
        (ss_tlnp, _ok(ss_tlnp,
            "LISTEN 0 128 0.0.0.0:18800 0.0.0.0:* "
            "users:((\"strange-daemon\",pid=4711,fd=5))\n")),
        (ss_ulnp, _ok(ss_ulnp, "")),
        (ps, _ok(ps, f"USER PID PPID CMD\nroot 4711 1 {leaky_cmd}\n")),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await ProcessForensicsCheck().run(ctx)
    assert len(findings) == 1
    cmd = findings[0].evidence["cmd"]
    assert "sk-ant-api03-AAAA" not in cmd
    assert "sk-ant-api03-AAAAAAAAAAAA" not in cmd
    # description likewise
    assert "sk-ant-api03-AAAA" not in findings[0].description


@pytest.mark.asyncio
async def test_process_forensics_skipped_when_all_listening_probes_fail():
    ss_tlnp = ["ss", "-tlnp"]
    ss_ulnp = ["ss", "-ulnp"]
    executor = _Executor([
        (ss_tlnp, RunResult(argv=ss_tlnp, command_sha256="x"*64, exit_code=0,
                            stdout="", stderr="", duration_ms=1.0, bytes_out=0,
                            rejected=True, reject_reason="policy denied")),
        (ss_ulnp, RunResult(argv=ss_ulnp, command_sha256="x"*64, exit_code=0,
                            stdout="", stderr="", duration_ms=1.0, bytes_out=0,
                            rejected=True, reject_reason="policy denied")),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await ProcessForensicsCheck().run(ctx)
    assert findings == []
    assert ctx.status.is_skipped
    assert "所有监听端口探测均失败" in (ctx.status.skip_reason or "")
