"""Tests for _supply_chain_common (check-side helpers extracted in 7d.2)."""

import json

from agentsec.audit.checks._supply_chain_common import load_advisory_db


def test_load_advisory_db_indexes_by_package(tmp_path):
    db_file = tmp_path / "osv.json"
    db_file.write_text(json.dumps([
        {"id": "GHSA-a", "package": "django", "ranges": [], "severity": "high",
         "summary": "x", "url": "u", "aliases": []},
        {"id": "GHSA-b", "package": "django", "ranges": [], "severity": "low",
         "summary": "y", "url": "u", "aliases": []},
        {"id": "GHSA-c", "package": "requests", "ranges": [], "severity": "critical",
         "summary": "z", "url": "u", "aliases": []},
    ]))
    by_pkg = load_advisory_db(db_file)
    assert set(by_pkg.keys()) == {"django", "requests"}
    assert len(by_pkg["django"]) == 2
    assert len(by_pkg["requests"]) == 1


def test_load_advisory_db_empty_list(tmp_path):
    db_file = tmp_path / "osv.json"
    db_file.write_text("[]")
    by_pkg = load_advisory_db(db_file)
    assert by_pkg == {}


def test_load_advisory_db_severity_re_export():
    """severity_from_cvss_score is re-exported for Check-layer convenience."""
    from agentsec.audit.checks._supply_chain_common import severity_from_cvss_score
    assert severity_from_cvss_score(9.5) == "critical"
