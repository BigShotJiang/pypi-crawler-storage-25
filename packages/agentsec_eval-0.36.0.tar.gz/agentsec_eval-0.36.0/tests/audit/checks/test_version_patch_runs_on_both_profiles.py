"""version_patch: positive path — runs on both LINUX and MACOS profiles.

Verifies that version_patch runs on both LINUX and MACOS profiles without
short-circuiting (empty _REQUIRED_PATHS tuple → the loop is a no-op).
"""

import asyncio
import json
from pathlib import Path
from unittest.mock import MagicMock

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.version_patch import VersionPatchCheck
from agentsec.audit.platform_profile import LINUX, MACOS
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

IOC_DIR = Path(__file__).resolve().parents[3] / "src" / "agentsec" / "audit" / "ioc"


def _ctx(profile, version_payload: dict):
    body = json.dumps(version_payload)
    executor = MagicMock()
    executor.run = MagicMock(return_value=RunResult(
        argv=["openclaw", "version", "--json"],
        command_sha256="x" * 64, exit_code=0,
        stdout=body, stderr="", duration_ms=1.0, bytes_out=len(body),
        rejected=False, reject_reason=None,
    ))
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=IOC_DIR, profile=profile, status=CheckStatus(),
    )


def test_version_patch_runs_on_linux_profile():
    ctx = _ctx(LINUX, {"version": "9999.0.0"})
    asyncio.run(VersionPatchCheck().run(ctx))
    ctx.executor.run.assert_called_once()
    assert not ctx.status.is_not_applicable


def test_version_patch_runs_on_macos_profile():
    ctx = _ctx(MACOS, {"version": "9999.0.0"})
    asyncio.run(VersionPatchCheck().run(ctx))
    ctx.executor.run.assert_called_once()
    assert not ctx.status.is_not_applicable
