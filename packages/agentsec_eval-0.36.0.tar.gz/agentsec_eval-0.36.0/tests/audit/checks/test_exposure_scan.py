import socket
from contextlib import asynccontextmanager

import pytest
from websockets.asyncio.server import serve as ws_serve

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.exposure_scan import ExposureScanCheck
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor


def _listen_on(port: int, addr: str = "127.0.0.1") -> socket.socket:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((addr, port))
    s.listen(1)
    return s


@pytest.mark.asyncio
async def test_exposure_scan_flags_unexpected_listening_port():
    s = _listen_on(0)  # any free port
    port = s.getsockname()[1]
    try:
        check = ExposureScanCheck(host="127.0.0.1", ports=[port], allowlist=[18789])
        ctx = CheckContext(
            executor=None,            # exposure_scan does NOT use SSH
            redactor=Redactor(),
            ioc_dir=None,
            profile=LINUX,
            status=CheckStatus(),
        )
        findings = await check.run(ctx)
    finally:
        s.close()
    assert len(findings) == 1
    assert findings[0].check == "exposure_scan"
    assert findings[0].evidence["port"] == port


@pytest.mark.asyncio
async def test_exposure_scan_no_findings_when_only_allowlisted_port_open():
    """Open the API port (in the allowlist) — no finding."""
    s = _listen_on(0)
    port = s.getsockname()[1]
    try:
        check = ExposureScanCheck(host="127.0.0.1", ports=[port], allowlist=[port])
        ctx = CheckContext(
            executor=None, redactor=Redactor(), ioc_dir=None,
            profile=LINUX, status=CheckStatus(),
        )
        findings = await check.run(ctx)
    finally:
        s.close()
    assert findings == []


@pytest.mark.asyncio
async def test_exposure_scan_quiet_when_no_ports_open():
    check = ExposureScanCheck(host="127.0.0.1", ports=[1])  # port 1 is privileged + not bound
    ctx = CheckContext(
        executor=None, redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await check.run(ctx)
    assert findings == []


@asynccontextmanager
async def _ws_server(host: str = "127.0.0.1"):
    """Start a no-auth WS server on a random port; yield the port."""
    async def _handler(ws):
        pass  # accept and immediately close

    async with ws_serve(_handler, host, 0) as server:
        port = server.sockets[0].getsockname()[1]
        yield port


@pytest.mark.asyncio
async def test_ws_probe_unauthenticated_high_finding():
    async with _ws_server() as port:
        check = ExposureScanCheck(
            host="127.0.0.1",
            ports=[port],
            allowlist=[],
            ws_paths=["/ws"],
        )
        ctx = CheckContext(
            executor=None, redactor=Redactor(), ioc_dir=None,
            profile=LINUX, status=CheckStatus(),
        )
        findings = await check.run(ctx)

    ws_findings = [f for f in findings if f.evidence.get("transport") == "ws"]
    assert len(ws_findings) == 1
    assert ws_findings[0].severity == "high"
    assert ws_findings[0].evidence["path"] == "/ws"
    assert ws_findings[0].evidence["port"] == port


@pytest.mark.asyncio
async def test_ws_probe_no_finding_when_port_closed():
    check = ExposureScanCheck(
        host="127.0.0.1",
        ports=[1],          # privileged port, not bound
        allowlist=[],
        ws_paths=["/ws"],
    )
    ctx = CheckContext(
        executor=None, redactor=Redactor(), ioc_dir=None,
        profile=LINUX, status=CheckStatus(),
    )
    findings = await check.run(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_ws_probe_disabled():
    async with _ws_server() as port:
        check = ExposureScanCheck(
            host="127.0.0.1",
            ports=[port],
            allowlist=[],
            ws_paths=["/ws"],
            ws_probe_enabled=False,
        )
        ctx = CheckContext(
            executor=None, redactor=Redactor(), ioc_dir=None,
            profile=LINUX, status=CheckStatus(),
        )
        findings = await check.run(ctx)

    ws_findings = [f for f in findings if f.evidence.get("transport") == "ws"]
    assert ws_findings == []
    # TCP finding still present
    tcp_findings = [f for f in findings if f.evidence.get("transport") == "tcp"]
    assert len(tcp_findings) == 1


@pytest.mark.asyncio
async def test_ws_probe_no_finding_when_tcp_only():
    """Plain TCP socket (non-WS) — upgrade is refused, no WS finding."""
    s = _listen_on(0)
    port = s.getsockname()[1]
    try:
        check = ExposureScanCheck(
            host="127.0.0.1",
            ports=[port],
            allowlist=[port],   # suppress TCP finding; we only care about WS
            ws_paths=["/ws"],
        )
        ctx = CheckContext(
            executor=None, redactor=Redactor(), ioc_dir=None,
            profile=LINUX, status=CheckStatus(),
        )
        findings = await check.run(ctx)
    finally:
        s.close()

    assert findings == []


@pytest.mark.asyncio
async def test_ws_probe_fires_even_on_allowlisted_port():
    """allowlist only suppresses TCP finding; WS probe still runs on allowlisted ports."""
    async with _ws_server() as port:
        check = ExposureScanCheck(
            host="127.0.0.1",
            ports=[port],
            allowlist=[port],
            ws_paths=["/ws"],
        )
        ctx = CheckContext(
            executor=None, redactor=Redactor(), ioc_dir=None,
            profile=LINUX, status=CheckStatus(),
        )
        findings = await check.run(ctx)

    tcp_findings = [f for f in findings if f.evidence.get("transport") == "tcp"]
    ws_findings = [f for f in findings if f.evidence.get("transport") == "ws"]
    assert tcp_findings == []
    assert len(ws_findings) == 1
    assert ws_findings[0].severity == "high"
