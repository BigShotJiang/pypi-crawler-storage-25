"""active_test check — runs a canary case via paramiko local-forward.

We stub paramiko's port-forwarding by injecting a `tunnel_factory` that
returns a context manager exposing a local port number.
"""

from contextlib import contextmanager
from unittest.mock import AsyncMock, MagicMock

import pytest

from agentsec.audit.checks.active_test import ActiveTestCheck
from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor


@contextmanager
def _ok_tunnel():
    yield 51789


@contextmanager
def _failing_tunnel():
    raise RuntimeError("ssh -L failed: connection refused")
    yield  # unreachable


@pytest.mark.asyncio
async def test_canary_runs_through_tunnel(monkeypatch):
    fake_runner = AsyncMock(return_value=[
        MagicMock(status="passed", test_id="oc-active-canary-01"),
    ])
    monkeypatch.setattr("agentsec.audit.checks.active_test._run_canary", fake_runner)

    ctx = CheckContext(
        executor=MagicMock(), redactor=Redactor(),
        ioc_dir=None, profile=LINUX, status=CheckStatus(),
    )
    check = ActiveTestCheck(tunnel_factory=lambda host, user, key: _ok_tunnel())
    findings = await check.run(ctx)
    assert findings == []
    fake_runner.assert_awaited_once()


@pytest.mark.asyncio
async def test_failed_canary_emits_finding(monkeypatch):
    fake_runner = AsyncMock(return_value=[
        MagicMock(
            status="failed", test_id="oc-active-canary-01",
            error="response leaked OK literal",
        ),
    ])
    monkeypatch.setattr("agentsec.audit.checks.active_test._run_canary", fake_runner)

    ctx = CheckContext(
        executor=MagicMock(), redactor=Redactor(),
        ioc_dir=None, profile=LINUX, status=CheckStatus(),
    )
    check = ActiveTestCheck(tunnel_factory=lambda host, user, key: _ok_tunnel())
    findings = await check.run(ctx)
    assert len(findings) == 1
    assert findings[0].severity in {"low", "medium"}
    assert "oc-active-canary-01" in findings[0].title


@pytest.mark.asyncio
async def test_tunnel_failure_skips_check_no_fallback():
    ctx = CheckContext(
        executor=MagicMock(), redactor=Redactor(),
        ioc_dir=None, profile=LINUX, status=CheckStatus(),
    )
    check = ActiveTestCheck(tunnel_factory=lambda host, user, key: _failing_tunnel())
    findings = await check.run(ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "SSH 隧道" in ctx.status.skip_reason
