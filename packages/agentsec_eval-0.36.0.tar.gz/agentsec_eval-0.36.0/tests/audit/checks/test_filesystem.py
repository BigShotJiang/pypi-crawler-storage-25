import pytest

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.filesystem import FilesystemCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

# ADR-0004: production checks always see paths after `materialize_paths`,
# so unit-test fixtures must run argv assertions against the absolute
# form (/home/u/.openclaw/...) rather than the unmaterialized "~/...".
_PROFILE = materialize_paths(LINUX, "/home/u")
_HOME = _PROFILE.paths["openclaw_home"]


class _ScriptedExecutor:
    """Plays back stdout from a list of (argv → RunResult) entries."""
    def __init__(self, scripted: list[tuple[list[str], RunResult]]):
        self._script = list(scripted)
        self.calls: list[list[str]] = []

    def run(self, argv):
        self.calls.append(argv)
        for expected_argv, result in self._script:
            if expected_argv == argv:
                return result
        raise AssertionError(f"unexpected argv: {argv}")


@pytest.mark.asyncio
async def test_filesystem_emits_finding_for_world_writable_file():
    find_argv = ["find", _HOME, "-maxdepth", "4", "-type", "f", "-perm", "/o+w"]
    target = f"{_HOME}notes.txt"
    stat_argv = ["stat", "-c", "%a %U %G %n", target]
    executor = _ScriptedExecutor([
        (find_argv, RunResult(
            argv=find_argv, command_sha256="x"*64, exit_code=0,
            stdout=f"{target}\n",
            stderr="", duration_ms=1.0, bytes_out=20, rejected=False, reject_reason=None,
        )),
        (stat_argv, RunResult(
            argv=stat_argv, command_sha256="y"*64, exit_code=0,
            stdout=f"666 alice users {target}\n",
            stderr="", duration_ms=1.0, bytes_out=24, rejected=False, reject_reason=None,
        )),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=_PROFILE, status=CheckStatus(),
    )
    findings = await FilesystemCheck().run(ctx)
    assert len(findings) == 1
    assert "世界可写文件" in findings[0].title
    assert findings[0].evidence["mode"] == "666"
    assert findings[0].evidence["path"] == target


@pytest.mark.asyncio
async def test_filesystem_no_findings_on_clean_tree():
    find_argv = ["find", _HOME, "-maxdepth", "4", "-type", "f", "-perm", "/o+w"]
    executor = _ScriptedExecutor([
        (find_argv, RunResult(
            argv=find_argv, command_sha256="x"*64, exit_code=0,
            stdout="", stderr="", duration_ms=1.0, bytes_out=0,
            rejected=False, reject_reason=None,
        )),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=_PROFILE, status=CheckStatus(),
    )
    findings = await FilesystemCheck().run(ctx)
    assert findings == []
