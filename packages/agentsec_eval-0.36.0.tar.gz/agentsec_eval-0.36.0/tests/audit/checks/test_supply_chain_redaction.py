"""Verify all 3 supply-chain Checks route Finding through the Redactor.

Phase 7d.2 follow-up to 7d.1 final-review #5: Finding evidence may carry
operator-derived strings (lock_path) and OSV-derived strings (summary);
make_finding routes them through ctx.redactor.redact so future patterns
automatically cover supply-chain findings without per-Check changes.
"""

import asyncio
import json
import re
from dataclasses import dataclass
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.go_supply_chain_audit import GoSupplyChainAuditCheck
from agentsec.audit.checks.pip_supply_chain_audit import PipSupplyChainAuditCheck
from agentsec.audit.checks.rust_supply_chain_audit import RustSupplyChainAuditCheck
from agentsec.audit.checks.supply_chain_audit import SupplyChainAuditCheck
from agentsec.audit.platform_profile import LINUX, PlatformProfile


@dataclass
class _ExecResult:
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    rejected: bool = False
    reject_reason: str = ""


class _StubExecutor:
    def __init__(self, files: dict[str, str]):
        self._files = files

    def run(self, argv: list[str]) -> _ExecResult:
        path = argv[1] if len(argv) >= 2 else ""
        if path not in self._files:
            return _ExecResult(stderr="No such file", exit_code=1)
        return _ExecResult(stdout=self._files[path])


class _SecretReplacingRedactor:
    """Replaces 'SECRET-XYZ-...' tokens with [REDACTED] in any string passed."""
    _PAT = re.compile(r"SECRET-XYZ-[A-Z0-9]+")

    def redact(self, s: str) -> str:
        if not isinstance(s, str):
            return s
        return self._PAT.sub("[REDACTED]", s)


_PIP_FIXTURE_DB = Path("tests/fixtures/supply_chain_pypi/osv_pypi_subset.json")
_GO_FIXTURE_DB = Path("tests/fixtures/supply_chain_go/osv_go_subset.json")


def test_pip_check_routes_through_redactor():
    """Verify a finding's evidence has secret-like substring redacted."""
    check = PipSupplyChainAuditCheck(db_path=_PIP_FIXTURE_DB)
    ctx = CheckContext(
        executor=_StubExecutor({
            # The lock_path itself contains a secret-looking token; redactor scrubs it
            "/srv/SECRET-XYZ-ABC123/requirements.txt": "django==3.2.0\n",
        }),
        redactor=_SecretReplacingRedactor(),
        ioc_dir=Path("/x"), profile=LINUX,
        pip_lock_paths=("/srv/SECRET-XYZ-ABC123/requirements.txt",),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert "SECRET-XYZ" not in findings[0].evidence["lock_path"]
    assert "[REDACTED]" in findings[0].evidence["lock_path"]


def test_go_check_routes_through_redactor():
    check = GoSupplyChainAuditCheck(db_path=_GO_FIXTURE_DB)
    ctx = CheckContext(
        executor=_StubExecutor({
            "/srv/SECRET-XYZ-DEF456/go.sum":
                "github.com/foo/bar v1.2.0 h1:abc==\n",
        }),
        redactor=_SecretReplacingRedactor(),
        ioc_dir=Path("/x"), profile=LINUX,
        go_lock_paths=("/srv/SECRET-XYZ-DEF456/go.sum",),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert "SECRET-XYZ" not in findings[0].evidence["lock_path"]
    assert "[REDACTED]" in findings[0].evidence["lock_path"]


def test_npm_check_routes_through_redactor(tmp_path):
    """SupplyChainAuditCheck reads from npm_root path (PlatformProfile-based);
    its evidence['npm_root'] must be redacted if the path contains a secret pattern."""
    npm_lock_content = json.dumps({
        "lockfileVersion": 3,
        "packages": {
            "node_modules/lodash": {"version": "4.17.20"},
        },
    })

    # Patch the LINUX profile's npm_root to contain a secret-like substring
    profile = PlatformProfile(
        name="linux",
        paths={
            **LINUX.paths,
            "npm_root": "/srv/SECRET-XYZ-NPMNODE/openclaw",
        },
        services=LINUX.services,
        listening_check=LINUX.listening_check,
        log_source=LINUX.log_source,
    )

    # Use a fixture DB with lodash advisory
    fixture_db = tmp_path / "osv_npm_subset.json"
    fixture_db.write_text(json.dumps([
        {"id": "GHSA-loda-xxxx", "package": "lodash",
         "ranges": [{"introduced": "0", "fixed": "4.17.21"}],
         "severity": "high", "summary": "Prototype pollution",
         "url": "u", "aliases": []}
    ]))

    check = SupplyChainAuditCheck(db_path=fixture_db)
    ctx = CheckContext(
        executor=_StubExecutor({
            "/srv/SECRET-XYZ-NPMNODE/openclaw/package-lock.json": npm_lock_content,
        }),
        redactor=_SecretReplacingRedactor(),
        ioc_dir=Path("/x"), profile=profile,
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert "SECRET-XYZ" not in findings[0].evidence["lock_path"]
    assert "[REDACTED]" in findings[0].evidence["lock_path"]


# ---- rust (Phase 7d.3) ----

_CARGO_FIXTURE_DB = Path("tests/fixtures/supply_chain_cargo/osv_cargo_subset.json")


def test_rust_check_routes_through_redactor():
    check = RustSupplyChainAuditCheck(db_path=_CARGO_FIXTURE_DB)
    cargo_lock_with_serde = '''\
[[package]]
name = "serde"
version = "1.0.100"
source = "registry+https://github.com/rust-lang/crates.io-index"
'''
    ctx = CheckContext(
        executor=_StubExecutor({
            "/srv/SECRET-XYZ-GHI789/Cargo.lock": cargo_lock_with_serde,
        }),
        redactor=_SecretReplacingRedactor(),
        ioc_dir=Path("/x"), profile=LINUX,
        cargo_lock_paths=("/srv/SECRET-XYZ-GHI789/Cargo.lock",),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert "SECRET-XYZ" not in findings[0].evidence["lock_path"]
    assert "[REDACTED]" in findings[0].evidence["lock_path"]
