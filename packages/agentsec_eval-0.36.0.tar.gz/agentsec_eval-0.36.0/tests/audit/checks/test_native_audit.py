"""native_audit check — parses `openclaw security audit --json` into Findings."""

import asyncio
import json
from pathlib import Path
from unittest.mock import MagicMock

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.native_audit import NativeAuditCheck
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

SAMPLE = (Path(__file__).parent / "fixtures" / "openclaw_audit_sample.json").read_text()


def _ctx_with_stdout(stdout: str, exit_code: int = 0):
    executor = MagicMock()
    executor.run = MagicMock(return_value=RunResult(
        argv=["openclaw", "security", "audit", "--json"],
        command_sha256="x" * 64,
        exit_code=exit_code,
        stdout=stdout,
        stderr="",
        duration_ms=1.0,
        bytes_out=len(stdout.encode()),
        rejected=False,
        reject_reason=None,
    ))
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=None, profile=LINUX, status=CheckStatus(),
    )


def test_parses_findings_from_native_json():
    ctx = _ctx_with_stdout(SAMPLE)
    findings = asyncio.run(NativeAuditCheck().run(ctx))
    assert len(findings) == 2
    high = next(f for f in findings if f.severity == "high")
    assert "web_fetch" in high.title
    assert high.threat_refs == ["TI-OWASP-AGENTIC-2026-A2"]


def test_invokes_correct_argv():
    ctx = _ctx_with_stdout(SAMPLE)
    asyncio.run(NativeAuditCheck().run(ctx))
    ctx.executor.run.assert_called_once_with(["openclaw", "security", "audit", "--json"])


def test_evidence_passes_through_redactor():
    payload = {"findings": [{
        "id": "X", "severity": "low", "title": "t", "description": "d",
        "remediation": "r",
        "evidence": {"openclaw_token": "sk-ant-AAAAABBBBBCCCCCDDDDDEEEEEFFFFF"},
    }]}
    ctx = _ctx_with_stdout(json.dumps(payload))
    findings = asyncio.run(NativeAuditCheck().run(ctx))
    assert "sk-ant" not in json.dumps(findings[0].evidence)


def test_title_description_remediation_pass_through_redactor():
    """Vulnerability scanners typically embed the offending value in the
    human-readable text fields rather than under a structured evidence key
    — `title="API key sk-ant-… found in MEMORY.md"` is the realistic
    shape. Those fields land in server-audit-report.md, the artifact a
    customer sees, so they must redact symmetrically with `evidence`.
    """
    anthropic_key = "sk-ant-AAAAABBBBBCCCCCDDDDDEEEEEFFFFF"
    aws_key = "AKIAIOSFODNN7EXAMPLE"
    jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3OCJ9.fake_signature_payload_here"
    payload = {"findings": [{
        "id": "X", "severity": "high",
        "title": f"Anthropic API key {anthropic_key} found in MEMORY.md",
        "description": f"Configuration leaks AWS key {aws_key} in plaintext",
        "remediation": f"Rotate the leaked JWT {jwt} immediately",
        "evidence": {"path": "~/.openclaw/MEMORY.md"},
    }]}
    ctx = _ctx_with_stdout(json.dumps(payload))
    [finding] = asyncio.run(NativeAuditCheck().run(ctx))
    assert anthropic_key not in finding.title
    assert aws_key not in finding.description
    assert jwt not in finding.remediation


def test_skipped_when_native_command_rejected_by_policy():
    executor = MagicMock()
    executor.run = MagicMock(return_value=RunResult(
        argv=["openclaw", "security", "audit", "--json"],
        command_sha256="", exit_code=-1, stdout="", stderr="",
        duration_ms=0.0, bytes_out=0,
        rejected=True, reject_reason="not in allowed_argv",
    ))
    ctx = CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=None, profile=LINUX, status=CheckStatus(),
    )
    findings = asyncio.run(NativeAuditCheck().run(ctx))
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "策略拒绝" in ctx.status.skip_reason


def test_invalid_json_returns_zero_findings_and_skips():
    ctx = _ctx_with_stdout("<<<not json>>>")
    findings = asyncio.run(NativeAuditCheck().run(ctx))
    assert findings == []
    assert ctx.status.is_skipped is True
