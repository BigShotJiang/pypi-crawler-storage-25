from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.platform_profile import LINUX


def test_check_context_pip_lock_paths_default_empty():
    ctx = CheckContext(
        executor=object(), redactor=object(),
        ioc_dir=Path("/x"), profile=LINUX,
    )
    assert ctx.pip_lock_paths == ()


def test_check_context_pip_lock_paths_assignable():
    ctx = CheckContext(
        executor=object(), redactor=object(),
        ioc_dir=Path("/x"), profile=LINUX,
        pip_lock_paths=("/srv/req.txt",),
    )
    assert ctx.pip_lock_paths == ("/srv/req.txt",)


def test_check_context_go_lock_paths_default_empty():
    ctx = CheckContext(
        executor=object(), redactor=object(),
        ioc_dir=Path("/x"), profile=LINUX,
    )
    assert ctx.go_lock_paths == ()


def test_check_context_go_lock_paths_assignable():
    ctx = CheckContext(
        executor=object(), redactor=object(),
        ioc_dir=Path("/x"), profile=LINUX,
        go_lock_paths=("/srv/go.sum",),
    )
    assert ctx.go_lock_paths == ("/srv/go.sum",)


def test_check_context_cargo_lock_paths_default_empty():
    ctx = CheckContext(
        executor=object(), redactor=object(),
        ioc_dir=Path("/x"), profile=LINUX,
    )
    assert ctx.cargo_lock_paths == ()


def test_check_context_cargo_lock_paths_assignable():
    ctx = CheckContext(
        executor=object(), redactor=object(),
        ioc_dir=Path("/x"), profile=LINUX,
        cargo_lock_paths=("/srv/Cargo.lock",),
    )
    assert ctx.cargo_lock_paths == ("/srv/Cargo.lock",)
