"""Tests for parser, matcher, version parser in rust_supply_chain_audit."""

import asyncio
from dataclasses import dataclass
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.rust_supply_chain_audit import (
    RustSupplyChainAuditCheck,
    _safe_parse_cargo_version,
    parse_cargo_lock,
    version_in_any_cargo_range,
)
from agentsec.audit.platform_profile import LINUX

# ---- _safe_parse_cargo_version ----

def test_safe_parse_simple_semver():
    v = _safe_parse_cargo_version("1.0.150")
    assert v is not None
    assert str(v) == "1.0.150"


def test_safe_parse_pre_release():
    v = _safe_parse_cargo_version("0.4.0-beta.1")
    assert v is not None


def test_safe_parse_garbage_returns_none():
    assert _safe_parse_cargo_version("not a version") is None
    assert _safe_parse_cargo_version("v1.2.3") is None   # Cargo doesn't use v prefix
    assert _safe_parse_cargo_version("") is None


# ---- parse_cargo_lock ----

_CARGO_LOCK_SIMPLE = '''\
version = 3

[[package]]
name = "serde"
version = "1.0.150"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "abcdef"
'''


def test_parse_simple_crate():
    assert parse_cargo_lock(_CARGO_LOCK_SIMPLE) == [("serde", "1.0.150")]


def test_parse_skip_workspace_local():
    """A package with no `source` field is workspace-local; skip it."""
    src = '''\
[[package]]
name = "my-local-crate"
version = "0.1.0"
'''
    assert parse_cargo_lock(src) == []


def test_parse_skip_git_source():
    src = '''\
[[package]]
name = "git-dep"
version = "0.5.0"
source = "git+https://github.com/foo/bar"
'''
    assert parse_cargo_lock(src) == []


def test_parse_skip_alternate_registry():
    src = '''\
[[package]]
name = "private-dep"
version = "0.1.0"
source = "registry+https://other.io/index"
'''
    assert parse_cargo_lock(src) == []


def test_parse_pre_release_version():
    src = '''\
[[package]]
name = "alpha-crate"
version = "0.4.0-beta.1"
source = "registry+https://github.com/rust-lang/crates.io-index"
'''
    assert parse_cargo_lock(src) == [("alpha-crate", "0.4.0-beta.1")]


def test_parse_invalid_toml_returns_empty():
    assert parse_cargo_lock("{not toml") == []


def test_parse_multiple_packages():
    src = '''\
[[package]]
name = "serde"
version = "1.0.150"
source = "registry+https://github.com/rust-lang/crates.io-index"

[[package]]
name = "tokio"
version = "1.30.0"
source = "registry+https://github.com/rust-lang/crates.io-index"

[[package]]
name = "local"
version = "0.1.0"
'''
    assert parse_cargo_lock(src) == [
        ("serde", "1.0.150"),
        ("tokio", "1.30.0"),
    ]


# ---- version_in_any_cargo_range ----

def test_match_exact_inside_range():
    ranges = [{"introduced": "1.0.0", "fixed": "2.0.0"}]
    assert version_in_any_cargo_range("1.5.0", ranges) is True


def test_match_at_introduced_boundary():
    ranges = [{"introduced": "1.0.0", "fixed": "2.0.0"}]
    assert version_in_any_cargo_range("1.0.0", ranges) is True


def test_match_at_fixed_boundary_excluded():
    ranges = [{"introduced": "1.0.0", "fixed": "2.0.0"}]
    assert version_in_any_cargo_range("2.0.0", ranges) is False


def test_match_pre_release_in_range():
    ranges = [{"introduced": "0", "fixed": "1.0.0"}]
    assert version_in_any_cargo_range("0.4.0-beta.1", ranges) is True


def test_match_unparseable_returns_false():
    ranges = [{"introduced": "1.0.0", "fixed": "2.0.0"}]
    assert version_in_any_cargo_range("garbage", ranges) is False


def test_match_multiple_ranges_or():
    ranges = [
        {"introduced": "1.0.0", "fixed": "1.5.0"},
        {"introduced": "2.0.0", "fixed": "2.5.0"},
    ]
    assert version_in_any_cargo_range("2.3.0", ranges) is True
    assert version_in_any_cargo_range("1.7.0", ranges) is False


def test_match_fail_closed_on_unparseable_introduced():
    """Upstream OSV occasionally ships non-strict-semver bounds (e.g., '0.16'
    instead of '0.16.0'). Fail-open on this would drop the lower bound and
    flag clearly-older versions as vulnerable; fail-closed skips the range.

    Real example: GHSA-f67q-wr6w-23jq has introduced='0.16' fixed='0.19.0'.
    """
    ranges = [{"introduced": "0.16", "fixed": "0.19.0"}]
    assert version_in_any_cargo_range("0.1.0", ranges) is False


def test_match_fail_closed_on_unparseable_fixed():
    """If `fixed` is malformed semver, the affected range must be skipped."""
    ranges = [{"introduced": "0", "fixed": "not.a.version"}]
    assert version_in_any_cargo_range("100.0.0", ranges) is False


# ---- RustSupplyChainAuditCheck e2e ----

_FIXTURE_DB = Path("tests/fixtures/supply_chain_cargo/osv_cargo_subset.json")


@dataclass
class _ExecResult:
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    rejected: bool = False
    reject_reason: str = ""


class _StubExecutor:
    def __init__(self, files: dict[str, str], rejected_paths: set[str] = frozenset()):
        self._files = files
        self._rejected = rejected_paths

    def run(self, argv: list[str]) -> _ExecResult:
        assert argv[0] == "cat"
        path = argv[1]
        if path in self._rejected:
            return _ExecResult(rejected=True, reject_reason="not in allowed_paths")
        if path not in self._files:
            return _ExecResult(stderr="No such file", exit_code=1)
        return _ExecResult(stdout=self._files[path])


class _NoOpRedactor:
    def redact(self, s: str) -> str:
        return s


def _ctx(*, cargo_lock_paths: tuple[str, ...], executor) -> CheckContext:
    return CheckContext(
        executor=executor, redactor=_NoOpRedactor(),
        ioc_dir=Path("/x"), profile=LINUX,
        cargo_lock_paths=cargo_lock_paths,
    )


_VULN_LOCK = '''\
[[package]]
name = "serde"
version = "1.0.100"
source = "registry+https://github.com/rust-lang/crates.io-index"
'''

_CLEAN_LOCK = '''\
[[package]]
name = "serde"
version = "1.0.200"
source = "registry+https://github.com/rust-lang/crates.io-index"
'''


def test_check_empty_config_not_applicable():
    check = RustSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(cargo_lock_paths=(), executor=_StubExecutor({}))
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "未配置" in ctx.status.not_applicable_reason


def test_check_single_lockfile_one_hit():
    check = RustSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        cargo_lock_paths=("/srv/Cargo.lock",),
        executor=_StubExecutor({"/srv/Cargo.lock": _VULN_LOCK}),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    f = findings[0]
    assert f.check == "rust_supply_chain_audit"
    assert f.severity == "high"
    assert "serde@1.0.100" in f.title
    assert f.evidence["advisory_id"] == "GHSA-rust-aaaa-bbbb"
    assert f.evidence["fixed_in"] == "1.0.150"
    assert f.evidence["lock_path"] == "/srv/Cargo.lock"
    assert f.threat_refs == ["TI-OSV-CRATES-CATALOG"]


def test_check_multi_lockfile_mixed():
    check = RustSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        cargo_lock_paths=("/a/Cargo.lock", "/b/Cargo.lock", "/missing/Cargo.lock"),
        executor=_StubExecutor({
            "/a/Cargo.lock": _VULN_LOCK,
            "/b/Cargo.lock": _CLEAN_LOCK,  # > 1.0.150, no hit
        }),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert findings[0].evidence["lock_path"] == "/a/Cargo.lock"
    assert findings[0].severity == "high"


def test_check_all_paths_unreadable_skipped():
    check = RustSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        cargo_lock_paths=("/x/Cargo.lock", "/y/Cargo.lock"),
        executor=_StubExecutor({}, rejected_paths={"/x/Cargo.lock", "/y/Cargo.lock"}),
    )
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_skipped
    assert "n=2" in ctx.status.skip_reason


def test_check_unparseable_version_low_finding():
    check = RustSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    bad_lock = '''\
[[package]]
name = "weird-crate"
version = "not-a-version"
source = "registry+https://github.com/rust-lang/crates.io-index"
'''
    ctx = _ctx(
        cargo_lock_paths=("/req/Cargo.lock",),
        executor=_StubExecutor({"/req/Cargo.lock": bad_lock}),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert findings[0].severity == "low"
    assert "无法解析 semver" in findings[0].title


def test_check_non_linux_not_applicable():
    from agentsec.audit.platform_profile import MACOS
    check = RustSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = CheckContext(
        executor=_StubExecutor({}), redactor=_NoOpRedactor(),
        ioc_dir=Path("/x"), profile=MACOS,
        cargo_lock_paths=("/x/Cargo.lock",),
    )
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "非 Linux" in ctx.status.not_applicable_reason
