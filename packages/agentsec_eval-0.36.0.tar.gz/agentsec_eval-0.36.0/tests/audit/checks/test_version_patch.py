"""version_patch check — `openclaw version --json` ↔ CVE entries."""

import asyncio
import json
from pathlib import Path
from unittest.mock import MagicMock

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.version_patch import VersionPatchCheck
from agentsec.audit.platform_profile import LINUX
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

IOC_DIR = Path(__file__).resolve().parents[3] / "src" / "agentsec" / "audit" / "ioc"


def _ctx(version_payload: dict, exit_code: int = 0, rejected: bool = False):
    body = json.dumps(version_payload)
    executor = MagicMock()
    executor.run = MagicMock(return_value=RunResult(
        argv=["openclaw", "version", "--json"],
        command_sha256="x" * 64, exit_code=exit_code,
        stdout=body, stderr="", duration_ms=1.0, bytes_out=len(body),
        rejected=rejected, reject_reason="rej" if rejected else None,
    ))
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=IOC_DIR, profile=LINUX, status=CheckStatus(),
    )


def test_no_findings_when_version_is_above_all_fixed_versions():
    ctx = _ctx({"version": "9999.0.0"})
    findings = asyncio.run(VersionPatchCheck().run(ctx))
    assert findings == []


def test_finding_emitted_when_version_in_affected_range():
    ctx = _ctx({"version": "0.0.1"})
    findings = asyncio.run(VersionPatchCheck().run(ctx))
    assert len(findings) >= 1
    assert all(f.check == "version_patch" for f in findings)


def test_skipped_when_version_command_rejected():
    ctx = _ctx({}, rejected=True)
    findings = asyncio.run(VersionPatchCheck().run(ctx))
    assert findings == []
    assert ctx.status.is_skipped is True


def test_skipped_when_no_version_field_in_payload():
    ctx = _ctx({"unrelated": "x"})
    findings = asyncio.run(VersionPatchCheck().run(ctx))
    assert findings == []
    assert ctx.status.is_skipped is True


def test_severity_falls_back_to_confidence_when_cvss_is_null():
    """bug_006: a TI entry with cvss: null and confidence: medium must
    emit Findings with severity="medium" (not the old "high" default), so
    Finding.severity and evidence.cve_db_confidence cannot disagree."""
    from agentsec.audit.checks.version_patch import _severity_from_cvss_or_confidence
    assert _severity_from_cvss_or_confidence(None, "high") == "high"
    assert _severity_from_cvss_or_confidence(None, "medium") == "medium"
    assert _severity_from_cvss_or_confidence(None, "low") == "low"
    assert _severity_from_cvss_or_confidence(None, None) == "medium"
    assert _severity_from_cvss_or_confidence(None, "MEDIUM") == "medium"
    # CVSS still wins when present.
    assert _severity_from_cvss_or_confidence(9.5, "low") == "critical"
    assert _severity_from_cvss_or_confidence(7.0, "low") == "high"
    assert _severity_from_cvss_or_confidence(4.0, "high") == "medium"
    assert _severity_from_cvss_or_confidence(1.0, "high") == "low"
