"""Tests for parser, matcher, normalizer in pip_supply_chain_audit."""

import asyncio
from dataclasses import dataclass
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.pip_supply_chain_audit import (
    PipSupplyChainAuditCheck,
    _safe_parse_pep440,
    normalize_pep503,
    parse_pip_requirements,
    version_in_any_pep440_range,
)

# ---- normalize_pep503 ----

def test_normalize_underscore_to_hyphen_lower():
    assert normalize_pep503("Foo_Bar") == "foo-bar"
    assert normalize_pep503("Pillow") == "pillow"
    assert normalize_pep503("zope.interface") == "zope-interface"
    assert normalize_pep503("a.b_c-d") == "a-b-c-d"


# ---- _safe_parse_pep440 ----

def test_safe_parse_returns_none_on_garbage():
    assert _safe_parse_pep440("not a version") is None
    assert _safe_parse_pep440("git+https://x") is None


def test_safe_parse_accepts_local_version():
    assert _safe_parse_pep440("1.0.0+cuda118") is not None


# ---- version_in_any_pep440_range ----

def test_match_exact_inside_range():
    ranges = [{"introduced": "1.0", "fixed": "2.0"}]
    assert version_in_any_pep440_range("1.5", ranges) is True


def test_match_at_introduced_boundary():
    ranges = [{"introduced": "1.0", "fixed": "2.0"}]
    assert version_in_any_pep440_range("1.0", ranges) is True


def test_match_at_fixed_boundary_excluded():
    ranges = [{"introduced": "1.0", "fixed": "2.0"}]
    assert version_in_any_pep440_range("2.0", ranges) is False


def test_match_just_below_fixed():
    ranges = [{"introduced": "1.0", "fixed": "2.0"}]
    assert version_in_any_pep440_range("1.99", ranges) is True


def test_match_pre_release_in_range():
    ranges = [{"introduced": "0", "fixed": "1.0.0"}]
    assert version_in_any_pep440_range("1.0.0a1", ranges) is True


def test_match_local_version_ignored_in_compare():
    # PEP-440: local version is dropped in ordering for comparison
    ranges = [{"introduced": "0", "fixed": "1.0.0"}]
    assert version_in_any_pep440_range("1.0.0+cuda", ranges) is False


def test_match_unparseable_returns_false():
    ranges = [{"introduced": "1.0", "fixed": "2.0"}]
    assert version_in_any_pep440_range("garbage", ranges) is False


def test_match_multiple_ranges_or():
    ranges = [
        {"introduced": "1.0", "fixed": "1.5"},
        {"introduced": "2.0", "fixed": "2.5"},
    ]
    assert version_in_any_pep440_range("2.3", ranges) is True
    assert version_in_any_pep440_range("1.7", ranges) is False


# ---- parse_pip_requirements ----


def test_parse_simple_eq():
    assert parse_pip_requirements("django==4.2.0\n") == [("django", "4.2.0")]


def test_parse_with_extras():
    assert parse_pip_requirements("requests[security,socks]==2.31.0\n") == [
        ("requests", "2.31.0"),
    ]


def test_parse_with_marker():
    src = 'django==4.2.0 ; python_version >= "3.10"\n'
    assert parse_pip_requirements(src) == [("django", "4.2.0")]


def test_parse_continuation_hash():
    src = (
        "django==4.2.0 \\\n"
        "    --hash=sha256:abcdef \\\n"
        "    --hash=sha256:123456\n"
    )
    assert parse_pip_requirements(src) == [("django", "4.2.0")]


def test_parse_pep503_keeps_raw_name():
    # Parser keeps the raw name; normalization happens at lookup time
    assert parse_pip_requirements("Pillow==10.0.0\n") == [("Pillow", "10.0.0")]


def test_parse_local_version():
    assert parse_pip_requirements("torch==2.0.0+cu118\n") == [
        ("torch", "2.0.0+cu118"),
    ]


def test_parse_skip_editable():
    src = "-e .\n-e git+https://github.com/x/y\n"
    assert parse_pip_requirements(src) == []


def test_parse_skip_vcs_url():
    src = "django @ git+https://github.com/django/django\n"
    assert parse_pip_requirements(src) == []


def test_parse_skip_recursive_and_constraint():
    src = "-r other.txt\n-c constraints.txt\n"
    assert parse_pip_requirements(src) == []


def test_parse_silently_skips_non_eq():
    src = "django>=4.0\nrequests~=2.30\nflask<3.0\n"
    assert parse_pip_requirements(src) == []


def test_parse_skips_comments_and_blanks():
    src = "# top\n\ndjango==4.2.0\n# trailing\n"
    assert parse_pip_requirements(src) == [("django", "4.2.0")]


# ---- PipSupplyChainAuditCheck e2e tests ----


_FIXTURE_DB = Path("tests/fixtures/supply_chain_pypi/osv_pypi_subset.json")


@dataclass
class _ExecResult:
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    rejected: bool = False
    reject_reason: str = ""


class _StubExecutor:
    def __init__(self, files: dict[str, str], rejected_paths: set[str] = frozenset()):
        self._files = files
        self._rejected = rejected_paths

    def run(self, argv: list[str]) -> _ExecResult:
        # Only `cat <path>` form; argv == ["cat", path]
        assert argv[0] == "cat"
        path = argv[1]
        if path in self._rejected:
            return _ExecResult(rejected=True, reject_reason="not in allowed_paths")
        if path not in self._files:
            return _ExecResult(stderr="No such file", exit_code=1)
        return _ExecResult(stdout=self._files[path])


class _NoOpRedactor:
    def redact(self, s: str) -> str:
        return s


def _ctx(*, pip_lock_paths: tuple[str, ...], executor) -> CheckContext:
    from agentsec.audit.platform_profile import LINUX
    return CheckContext(
        executor=executor, redactor=_NoOpRedactor(),
        ioc_dir=Path("/x"), profile=LINUX,
        pip_lock_paths=pip_lock_paths,
    )


def test_check_empty_config_not_applicable():
    check = PipSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(pip_lock_paths=(), executor=_StubExecutor({}))
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "未配置" in ctx.status.not_applicable_reason


def test_check_single_lockfile_one_hit():
    check = PipSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        pip_lock_paths=("/srv/req.txt",),
        executor=_StubExecutor({"/srv/req.txt": "django==3.2.0\n"}),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    f = findings[0]
    assert f.check == "pip_supply_chain_audit"
    assert f.severity == "high"
    assert "django@3.2.0" in f.title
    assert f.evidence["advisory_id"] == "GHSA-xxxx-yyyy-zzzz"
    assert f.evidence["fixed_in"] == "3.2.18"
    assert f.evidence["lock_path"] == "/srv/req.txt"
    assert f.threat_refs == ["TI-OSV-PYPI-CATALOG"]


def test_check_multi_lockfile_mixed():
    check = PipSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        pip_lock_paths=("/a.txt", "/b.txt", "/missing.txt"),
        executor=_StubExecutor({
            "/a.txt": "requests==2.30.0\n",
            "/b.txt": "django==4.2.0\n",  # > 3.2.18, no hit
        }),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert findings[0].evidence["lock_path"] == "/a.txt"
    assert findings[0].severity == "critical"


def test_check_all_paths_unreadable_skipped():
    check = PipSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        pip_lock_paths=("/x.txt", "/y.txt"),
        executor=_StubExecutor({}, rejected_paths={"/x.txt", "/y.txt"}),
    )
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_skipped
    assert "n=2" in ctx.status.skip_reason


def test_check_unparseable_pep440_low_finding():
    check = PipSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        pip_lock_paths=("/req.txt",),
        executor=_StubExecutor({"/req.txt": "weird-pkg==not-a-version\n"}),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert findings[0].severity == "low"
    assert "无法解析 PEP-440" in findings[0].title


def test_check_non_linux_not_applicable():
    from agentsec.audit.platform_profile import MACOS
    check = PipSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = CheckContext(
        executor=_StubExecutor({}), redactor=_NoOpRedactor(),
        ioc_dir=Path("/x"), profile=MACOS,
        pip_lock_paths=("/x.txt",),
    )
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "非 Linux" in ctx.status.not_applicable_reason
