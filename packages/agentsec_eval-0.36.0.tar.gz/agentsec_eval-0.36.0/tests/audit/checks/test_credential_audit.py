import pytest

from agentsec.audit.checks.base import CheckContext, CheckStatus
from agentsec.audit.checks.credential_audit import CredentialAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

# ADR-0004: production checks always see paths after `materialize_paths`,
# so unit-test fixtures pin argv keys to the absolute form rather than
# the unmaterialized "~/..." (otherwise the test passes while production
# emits something the canned dict no longer matches — the C1 trap).
_PROFILE = materialize_paths(LINUX, "/home/u")
_HOME = _PROFILE.paths["openclaw_home"]


def _ok(argv, stdout):
    return RunResult(
        argv=argv, command_sha256="x"*64, exit_code=0, stdout=stdout, stderr="",
        duration_ms=1.0, bytes_out=len(stdout.encode()), rejected=False, reject_reason=None,
    )


def _missing(argv):
    return RunResult(
        argv=argv, command_sha256="x"*64, exit_code=1, stdout="", stderr="No such file",
        duration_ms=1.0, bytes_out=0, rejected=False, reject_reason=None,
    )


class _Executor:
    def __init__(self, mapping): self.mapping = mapping
    def run(self, argv):
        for expected, r in self.mapping:
            if expected == argv:
                return r
        # Default: file does not exist.
        return _missing(argv)


@pytest.mark.asyncio
async def test_credential_audit_flags_world_readable_token():
    """Token file with mode 644 (world-readable) → critical finding."""
    target = f"{_HOME}gateway.token"
    argv = ["stat", "-c", "%a %U %G %n", target]
    executor = _Executor([
        (argv, _ok(argv, f"644 alice users {target}\n")),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=_PROFILE, status=CheckStatus(),
    )
    findings = await CredentialAuditCheck(ssh_user="alice").run(ctx)
    matching = [f for f in findings if f.evidence.get("path") == target]
    assert len(matching) == 1
    assert matching[0].evidence["mode"] == "644"
    assert matching[0].severity == "critical"
    # Description names the over-broad permission category.
    assert "world(其他用户)" in matching[0].description
    assert "group(同组)" in matching[0].description


@pytest.mark.asyncio
async def test_credential_audit_silent_when_file_missing():
    """Missing token files are not a finding (operator may not have one)."""
    ctx = CheckContext(
        executor=_Executor([]), redactor=Redactor(), ioc_dir=None,
        profile=_PROFILE, status=CheckStatus(),
    )
    findings = await CredentialAuditCheck(ssh_user="alice").run(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_credential_audit_flags_owner_mismatch():
    """File owned by a different user → critical finding."""
    target = f"{_HOME}signing.key"
    argv = ["stat", "-c", "%a %U %G %n", target]
    executor = _Executor([
        (argv, _ok(argv, f"600 root root {target}\n")),
    ])
    ctx = CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=None,
        profile=_PROFILE, status=CheckStatus(),
    )
    findings = await CredentialAuditCheck(ssh_user="alice").run(ctx)
    matching = [f for f in findings if "signing.key" in f.evidence.get("path", "")]
    assert len(matching) == 1
    assert "owner=root" in matching[0].description
    assert "SSH 登录用户为 alice" in matching[0].description


def test_credential_audit_constructor_requires_ssh_user():
    """ssh_user is a required keyword argument."""
    with pytest.raises(TypeError):
        CredentialAuditCheck()  # type: ignore[call-arg]
