"""Tests for parser, matcher, version normalizer in go_supply_chain_audit."""

import asyncio
from dataclasses import dataclass
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.go_supply_chain_audit import (
    GoSupplyChainAuditCheck,
    _safe_parse_go_version,
    parse_go_sum,
    version_in_any_go_range,
)
from agentsec.audit.platform_profile import LINUX

# ---- _safe_parse_go_version ----

def test_safe_parse_strips_v_prefix():
    v = _safe_parse_go_version("v1.2.3")
    assert v is not None
    assert str(v) == "1.2.3"


def test_safe_parse_strips_incompatible_suffix():
    v = _safe_parse_go_version("v1.2.3+incompatible")
    assert v is not None
    assert str(v) == "1.2.3"


def test_safe_parse_pseudo_version():
    """v0.0.0-20210101120000-abcdef parses as semver pre-release."""
    v = _safe_parse_go_version("v0.0.0-20210101120000-abcdef123456")
    assert v is not None


def test_safe_parse_garbage_returns_none():
    assert _safe_parse_go_version("not a version") is None
    assert _safe_parse_go_version("v1") is None     # missing patch
    assert _safe_parse_go_version("v1.0") is None   # missing patch


def test_safe_parse_keeps_non_incompatible_build_metadata():
    """+cuda118 is build metadata, not +incompatible — should NOT be stripped.

    Note: semver lib's `Version.parse` may or may not accept '+cuda118' build
    metadata depending on the lib version. If it raises, the test should still
    pass (None return). If it parses, the version is comparable. Either is OK
    — the point is non-+incompatible suffixes don't get stripped.
    """
    v = _safe_parse_go_version("v1.0.0+cuda118")
    # Either None (semver rejects build metadata) or a Version object —
    # both are acceptable; the key behavior is we didn't strip the suffix
    # before parsing.
    assert v is None or v is not None  # tautology — just ensure no crash


# ---- parse_go_sum ----

def test_parse_simple_line():
    src = "github.com/foo/bar v1.2.3 h1:abcdef==\n"
    assert parse_go_sum(src) == [("github.com/foo/bar", "v1.2.3")]


def test_parse_skip_go_mod_suffix():
    """The /go.mod-suffixed line duplicates the main entry; skip it to avoid double-finding."""
    src = (
        "github.com/foo/bar v1.2.3 h1:abc==\n"
        "github.com/foo/bar v1.2.3/go.mod h1:def==\n"
    )
    assert parse_go_sum(src) == [("github.com/foo/bar", "v1.2.3")]


def test_parse_keep_v_prefix():
    """Parser preserves raw version exactly; no stripping at parse time."""
    src = "pkg v1.2.3 h1:abc==\n"
    assert parse_go_sum(src) == [("pkg", "v1.2.3")]


def test_parse_keep_incompatible_suffix():
    src = "pkg v1.2.3+incompatible h1:abc==\n"
    assert parse_go_sum(src) == [("pkg", "v1.2.3+incompatible")]


def test_parse_pseudo_version():
    src = "golang.org/x/text v0.0.0-20210101120000-abcdef h1:xyz==\n"
    assert parse_go_sum(src) == [
        ("golang.org/x/text", "v0.0.0-20210101120000-abcdef"),
    ]


def test_parse_module_path_with_slash():
    src = "github.com/owner/repo/v2 v2.5.0 h1:abc==\n"
    assert parse_go_sum(src) == [("github.com/owner/repo/v2", "v2.5.0")]


def test_parse_blank_lines_skipped():
    src = "\n\ngithub.com/foo/bar v1.2.3 h1:abc==\n\n"
    assert parse_go_sum(src) == [("github.com/foo/bar", "v1.2.3")]


def test_parse_invalid_field_count_skipped():
    src = (
        "incomplete-line\n"
        "github.com/foo/bar v1.2.3 h1:ok==\n"
        "too many fields here extra\n"
    )
    assert parse_go_sum(src) == [("github.com/foo/bar", "v1.2.3")]


def test_parse_multiple_versions_same_module():
    src = (
        "github.com/foo/bar v1.0.0 h1:a==\n"
        "github.com/foo/bar v2.0.0 h1:b==\n"
    )
    assert parse_go_sum(src) == [
        ("github.com/foo/bar", "v1.0.0"),
        ("github.com/foo/bar", "v2.0.0"),
    ]


def test_parse_local_build_metadata():
    src = "pkg v1.0.0+cuda118 h1:abc==\n"
    assert parse_go_sum(src) == [("pkg", "v1.0.0+cuda118")]


# ---- version_in_any_go_range ----

def test_match_exact_inside_range():
    ranges = [{"introduced": "v1.0.0", "fixed": "v2.0.0"}]
    assert version_in_any_go_range("v1.5.0", ranges) is True


def test_match_at_introduced_boundary():
    ranges = [{"introduced": "v1.0.0", "fixed": "v2.0.0"}]
    assert version_in_any_go_range("v1.0.0", ranges) is True


def test_match_at_fixed_boundary_excluded():
    ranges = [{"introduced": "v1.0.0", "fixed": "v2.0.0"}]
    assert version_in_any_go_range("v2.0.0", ranges) is False


def test_match_just_below_fixed():
    ranges = [{"introduced": "v1.0.0", "fixed": "v2.0.0"}]
    assert version_in_any_go_range("v1.99.0", ranges) is True


def test_match_pseudo_version_in_range():
    ranges = [{"introduced": "0", "fixed": "v1.0.0"}]
    # pseudo-version sorts as pre-release < 1.0.0
    assert version_in_any_go_range(
        "v0.0.0-20210101120000-abc", ranges,
    ) is True


def test_match_unparseable_returns_false():
    ranges = [{"introduced": "v1.0.0", "fixed": "v2.0.0"}]
    assert version_in_any_go_range("garbage", ranges) is False


def test_match_multiple_ranges_or():
    ranges = [
        {"introduced": "v1.0.0", "fixed": "v1.5.0"},
        {"introduced": "v2.0.0", "fixed": "v2.5.0"},
    ]
    assert version_in_any_go_range("v2.3.0", ranges) is True
    assert version_in_any_go_range("v1.7.0", ranges) is False


def test_match_incompatible_stripped_at_compare():
    """v1.2.3+incompatible compared as 1.2.3 — falls into [v1.0.0, v2.0.0)."""
    ranges = [{"introduced": "v1.0.0", "fixed": "v2.0.0"}]
    assert version_in_any_go_range("v1.2.3+incompatible", ranges) is True


# ---- GoSupplyChainAuditCheck end-to-end ----

_FIXTURE_DB = Path("tests/fixtures/supply_chain_go/osv_go_subset.json")


@dataclass
class _ExecResult:
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    rejected: bool = False
    reject_reason: str = ""


class _StubExecutor:
    def __init__(self, files: dict[str, str], rejected_paths: set[str] = frozenset()):
        self._files = files
        self._rejected = rejected_paths

    def run(self, argv: list[str]) -> _ExecResult:
        assert argv[0] == "cat"
        path = argv[1]
        if path in self._rejected:
            return _ExecResult(rejected=True, reject_reason="not in allowed_paths")
        if path not in self._files:
            return _ExecResult(stderr="No such file", exit_code=1)
        return _ExecResult(stdout=self._files[path])


class _NoOpRedactor:
    def redact(self, s: str) -> str:
        return s


def _ctx(*, go_lock_paths: tuple[str, ...], executor) -> CheckContext:
    return CheckContext(
        executor=executor, redactor=_NoOpRedactor(),
        ioc_dir=Path("/x"), profile=LINUX,
        go_lock_paths=go_lock_paths,
    )


def test_check_empty_config_not_applicable():
    check = GoSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(go_lock_paths=(), executor=_StubExecutor({}))
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "未配置" in ctx.status.not_applicable_reason


def test_check_single_lockfile_one_hit():
    check = GoSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        go_lock_paths=("/srv/go.sum",),
        executor=_StubExecutor({
            "/srv/go.sum": "github.com/foo/bar v1.2.0 h1:abc==\n",
        }),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    f = findings[0]
    assert f.check == "go_supply_chain_audit"
    assert f.severity == "high"
    assert "github.com/foo/bar@v1.2.0" in f.title
    assert f.evidence["advisory_id"] == "GHSA-go-aaaa-bbbb"
    assert f.evidence["fixed_in"] == "v1.5.0"
    assert f.evidence["lock_path"] == "/srv/go.sum"
    assert f.threat_refs == ["TI-OSV-GO-CATALOG"]


def test_check_multi_lockfile_mixed():
    check = GoSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        go_lock_paths=("/a.sum", "/b.sum", "/missing.sum"),
        executor=_StubExecutor({
            "/a.sum": "golang.org/x/text v0.3.0 h1:abc==\n",
            "/b.sum": "github.com/foo/bar v2.0.0 h1:def==\n",  # > 1.5.0, no hit
        }),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert findings[0].evidence["lock_path"] == "/a.sum"
    assert findings[0].severity == "critical"


def test_check_all_paths_unreadable_skipped():
    check = GoSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        go_lock_paths=("/x.sum", "/y.sum"),
        executor=_StubExecutor({}, rejected_paths={"/x.sum", "/y.sum"}),
    )
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_skipped
    assert "n=2" in ctx.status.skip_reason


def test_check_unparseable_version_low_finding():
    check = GoSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = _ctx(
        go_lock_paths=("/req.sum",),
        executor=_StubExecutor({
            "/req.sum": "weird-pkg garbage-version h1:abc==\n",
        }),
    )
    findings = asyncio.run(check.run(ctx))
    assert len(findings) == 1
    assert findings[0].severity == "low"
    assert "无法解析 Go 版本" in findings[0].title


def test_check_non_linux_not_applicable():
    from agentsec.audit.platform_profile import MACOS
    check = GoSupplyChainAuditCheck(db_path=_FIXTURE_DB)
    ctx = CheckContext(
        executor=_StubExecutor({}), redactor=_NoOpRedactor(),
        ioc_dir=Path("/x"), profile=MACOS,
        go_lock_paths=("/x.sum",),
    )
    findings = asyncio.run(check.run(ctx))
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "非 Linux" in ctx.status.not_applicable_reason
