"""server_audit.run() — runs all checks, dedupes within a single pass."""

import asyncio
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from agentsec.audit.checks.base import Check
from agentsec.audit.findings import Finding
from agentsec.audit.server_audit import ServerAuditReport, run_server_audit


class _StubCheck(Check):
    def __init__(self, _id: str, findings: list[Finding]):
        type(self).id = _id  # set per-instance id by mutating class — fine for tests
        super().__init__()
        self._findings = findings

    async def run(self, ctx):
        return list(self._findings)


def _f(check, title, severity="low", evidence=None):
    return Finding(
        check=check, severity=severity, title=title, description="",
        evidence=evidence or {}, remediation="r", threat_refs=[],
    )


@pytest.mark.asyncio
async def test_runs_all_checks_in_order():
    a = _StubCheck("a", [_f("a", "ta")])
    b = _StubCheck("b", [_f("b", "tb")])
    report = await run_server_audit(checks=[a, b], ctx=MagicMock())
    assert isinstance(report, ServerAuditReport)
    assert {f.check for f in report.findings} == {"a", "b"}


@pytest.mark.asyncio
async def test_dedupes_identical_findings_within_one_pass():
    same = _f("x", "duplicate", evidence={"k": "v"})
    chk = _StubCheck("x", [same, same])
    report = await run_server_audit(checks=[chk], ctx=MagicMock())
    assert len(report.findings) == 1


@pytest.mark.asyncio
async def test_collects_check_status_metadata():
    class _SkipCheck(Check):
        id = "skipcheck"

        async def run(self, ctx):
            ctx.status.skipped("ssh tunnel down")
            return []

    report = await run_server_audit(checks=[_SkipCheck()], ctx=MagicMock())
    assert report.statuses["skipcheck"].is_skipped is True


@pytest.mark.asyncio
async def test_check_exception_recorded_as_error_not_propagated():
    class _BoomCheck(Check):
        id = "boom"

        async def run(self, ctx):
            raise RuntimeError("kaboom")

    report = await run_server_audit(checks=[_BoomCheck()], ctx=MagicMock())
    assert "RuntimeError" in report.errors["boom"]
    assert "kaboom" in report.errors["boom"]


@pytest.mark.asyncio
async def test_orchestrator_passes_platform_profile_into_context():
    from agentsec.audit.checks.base import Check, CheckContext
    from agentsec.audit.platform_profile import LINUX
    from agentsec.audit.redactor import Redactor

    seen: list[str] = []

    class _ProfileSeenCheck(Check):
        id = "profile_seen"
        async def run(self, ctx):
            seen.append(ctx.profile.name)
            return []

    ctx = CheckContext(
        executor=MagicMock(),
        redactor=Redactor(),
        ioc_dir=None,
        profile=LINUX,
    )
    await run_server_audit(checks=[_ProfileSeenCheck()], ctx=ctx)
    assert seen == ["linux"]


@pytest.mark.asyncio
async def test_run_server_audit_propagates_log_review_config():
    """Per-check ctx clone must carry log_review_config."""
    from agentsec.audit.checks.base import Check, CheckContext
    from agentsec.audit.platform_profile import LINUX
    from agentsec.config import LogReviewConfig

    captured: dict = {}

    class _Probe(Check):
        id = "probe"
        async def run(self, ctx):
            captured["log_review_config"] = ctx.log_review_config
            return []

    cfg = LogReviewConfig(journald_since_hours=72)
    parent_ctx = CheckContext(
        executor=MagicMock(),
        redactor=None,
        ioc_dir=None,
        profile=LINUX,
        log_review_config=cfg,
    )
    await run_server_audit(checks=[_Probe()], ctx=parent_ctx)
    assert captured["log_review_config"] is cfg


@pytest.mark.asyncio
async def test_run_server_audit_propagates_pip_lock_paths():
    """Per-check ctx clone must carry pip_lock_paths."""
    from agentsec.audit.checks.base import Check, CheckContext
    from agentsec.audit.platform_profile import LINUX

    class _CapturePipPathsCheck(Check):
        id = "capture_pip"

        def __init__(self):
            super().__init__()
            self.captured: tuple[str, ...] | None = None

        async def run(self, ctx: CheckContext) -> list:
            self.captured = ctx.pip_lock_paths
            return []

    parent_ctx = CheckContext(
        executor=MagicMock(),
        redactor=None,
        ioc_dir=None,
        profile=LINUX,
        pip_lock_paths=("/srv/a.txt", "~/b.lock"),
    )
    cap = _CapturePipPathsCheck()
    await run_server_audit(checks=[cap], ctx=parent_ctx)
    assert cap.captured == ("/srv/a.txt", "~/b.lock")


@pytest.mark.asyncio
async def test_run_server_audit_propagates_go_lock_paths():
    """Per-check ctx clone must carry go_lock_paths."""
    from agentsec.audit.checks.base import Check, CheckContext
    from agentsec.audit.platform_profile import LINUX

    class _CaptureGoPathsCheck(Check):
        id = "capture_go"

        def __init__(self):
            super().__init__()
            self.captured: tuple[str, ...] | None = None

        async def run(self, ctx: CheckContext) -> list:
            self.captured = ctx.go_lock_paths
            return []

    parent_ctx = CheckContext(
        executor=MagicMock(),
        redactor=None,
        ioc_dir=None,
        profile=LINUX,
        go_lock_paths=("/srv/a.sum", "~/b.sum"),
    )
    cap = _CaptureGoPathsCheck()
    await run_server_audit(checks=[cap], ctx=parent_ctx)
    assert cap.captured == ("/srv/a.sum", "~/b.sum")


def test_run_server_audit_propagates_cargo_lock_paths():
    from agentsec.audit.checks.base import Check, CheckContext
    from agentsec.audit.platform_profile import LINUX

    class _CaptureCargoPathsCheck(Check):
        id = "capture_cargo"

        def __init__(self):
            super().__init__()
            self.captured: tuple[str, ...] | None = None

        async def run(self, ctx: CheckContext) -> list[Finding]:
            self.captured = ctx.cargo_lock_paths
            return []

    parent_ctx = CheckContext(
        executor=object(), redactor=object(),
        ioc_dir=Path("/x"), profile=LINUX,
        cargo_lock_paths=("/srv/a/Cargo.lock", "~/b/Cargo.lock"),
    )
    cap = _CaptureCargoPathsCheck()
    asyncio.run(run_server_audit(checks=[cap], ctx=parent_ctx))
    assert cap.captured == ("/srv/a/Cargo.lock", "~/b/Cargo.lock")
