"""Tests for _supply_chain_common (fetcher-side helpers extracted in 7d.2)."""

from datetime import UTC, datetime, timedelta

from agentsec.audit.ioc_update.fetchers._supply_chain_common import (
    MEDIUM_LOW_MAX_AGE_DAYS,
    _extract_severity,
    _is_within_age,
    _parse_cvss_score,
    severity_from_cvss_score,
)


def test_severity_from_cvss_score_buckets():
    assert severity_from_cvss_score(9.5) == "critical"
    assert severity_from_cvss_score(7.0) == "high"
    assert severity_from_cvss_score(4.0) == "medium"
    assert severity_from_cvss_score(3.5) == "low"
    assert severity_from_cvss_score(None) == "medium"


def test_parse_cvss_score_v3_vector():
    score = _parse_cvss_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H")
    assert score is not None
    assert 9.0 <= score <= 10.0


def test_parse_cvss_score_garbage_returns_none():
    assert _parse_cvss_score("not a vector") is None
    assert _parse_cvss_score("") is None


def test_is_within_age_recent_returns_true():
    now = datetime.now(UTC)
    recent = (now - timedelta(days=30)).isoformat().replace("+00:00", "Z")
    assert _is_within_age(recent, MEDIUM_LOW_MAX_AGE_DAYS) is True


def test_is_within_age_old_returns_false():
    now = datetime.now(UTC)
    old = (now - timedelta(days=3 * 365)).isoformat().replace("+00:00", "Z")
    assert _is_within_age(old, MEDIUM_LOW_MAX_AGE_DAYS, now=now) is False


def test_is_within_age_unparseable_keeps():
    """fail-open: unparseable timestamps return True so we don't silently drop on bad data."""
    assert _is_within_age("not-a-date", MEDIUM_LOW_MAX_AGE_DAYS) is True


def test_extract_severity_picks_cvss_v3():
    sev_list = [{"type": "CVSS_V3",
                 "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}]
    label, had = _extract_severity(sev_list)
    assert label == "critical"
    assert had is True


def test_extract_severity_no_cvss_v3_returns_unhad():
    label, had = _extract_severity([{"type": "CVSS_V4", "score": "..."}])
    assert had is False
