import asyncio
import io
import json
import zipfile
from pathlib import Path

import httpx

from agentsec.audit.ioc_update.fetchers.base import FetcherContext
from agentsec.audit.ioc_update.fetchers.osv_cargo import (
    OsvCargoFetcher,
    normalize_osv_cargo_entry,
)

_FIX = Path("tests/fixtures/osv/cargo")


def _load(name: str) -> dict:
    return json.loads((_FIX / name).read_text())


def test_normalize_normal_entry():
    out = normalize_osv_cargo_entry(_load("normal.json"))
    assert out is not None
    assert isinstance(out, list)
    assert len(out) == 1
    rec = out[0]
    assert rec["id"] == "GHSA-norm-aaaa-bbbb"
    assert rec["package"] == "serde"   # no normalization
    assert rec["severity"] == "critical"
    assert rec["ranges"] == [{"introduced": "0", "fixed": "1.0.150"}]
    assert "RUSTSEC-2025-0001" in rec["aliases"]


def test_normalize_filters_withdrawn():
    assert normalize_osv_cargo_entry(_load("withdrawn.json")) is None


def test_normalize_filters_no_cargo_affected():
    assert normalize_osv_cargo_entry(_load("no-cargo.json")) is None


def test_normalize_filters_no_range():
    assert normalize_osv_cargo_entry(_load("no-range.json")) is None


def test_normalize_filters_no_cvss():
    assert normalize_osv_cargo_entry(_load("no-cvss.json")) is None


def test_normalize_drops_old_medium_low():
    entry = _load("normal.json")
    entry["severity"] = [{
        "type": "CVSS_V3",
        "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
    }]
    entry["published"] = "2020-01-01T00:00:00Z"
    assert normalize_osv_cargo_entry(entry) is None


def test_normalize_keeps_old_critical():
    entry = _load("normal.json")
    entry["published"] = "2020-01-01T00:00:00Z"
    out = normalize_osv_cargo_entry(entry)
    assert out is not None and len(out) == 1
    assert out[0]["severity"] == "critical"


def test_normalize_multi_affected_expansion():
    out = normalize_osv_cargo_entry(_load("multi-affected.json"))
    assert out is not None
    assert len(out) == 2
    pkgs = sorted(r["package"] for r in out)
    assert pkgs == ["fork-a", "fork-b"]
    assert {r["id"] for r in out} == {"GHSA-multi-aaaa-bbbb"}


def _make_zip(entries: dict[str, dict]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, payload in entries.items():
            zf.writestr(name, json.dumps(payload))
    return buf.getvalue()


def test_fetch_success_one_zip():
    payload = _make_zip({
        "GHSA-norm-aaaa-bbbb.json": _load("normal.json"),
        "GHSA-with-aaaa-bbbb.json": _load("withdrawn.json"),  # filtered
    })

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=payload)

    fetcher = OsvCargoFetcher()
    fetcher._client_factory = lambda: httpx.AsyncClient(
        transport=httpx.MockTransport(handler),
    )

    ctx = FetcherContext(offline=False)
    results = asyncio.run(fetcher.run(ctx, []))
    assert "_osv_cargo_full" in results
    r = results["_osv_cargo_full"]
    assert r.records is not None
    assert len(r.records) == 1
    assert r.records[0]["id"] == "GHSA-norm-aaaa-bbbb"


def test_fetch_retry_exhaustion_degraded():
    call_count = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        return httpx.Response(503)

    fetcher = OsvCargoFetcher()
    fetcher._client_factory = lambda: httpx.AsyncClient(
        transport=httpx.MockTransport(handler),
    )
    fetcher._sleep = lambda _s: asyncio.sleep(0)

    ctx = FetcherContext(offline=False)
    results = asyncio.run(fetcher.run(ctx, []))
    r = results["_osv_cargo_full"]
    assert r.degraded is not None
    assert call_count["n"] == 4
