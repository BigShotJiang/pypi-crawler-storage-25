import pytest

from agentsec.audit.platform_profile import LINUX, MACOS
from agentsec.audit.remote_home import resolve_remote_home


@pytest.mark.parametrize("user, profile, expected", [
    ("ubuntu", LINUX, "/home/ubuntu"),
    ("root",   LINUX, "/root"),
    ("alice",  MACOS, "/Users/alice"),
    ("root",   MACOS, "/var/root"),
])
def test_resolve_remote_home_uses_platform_convention(user, profile, expected):
    assert resolve_remote_home(user, profile) == expected


@pytest.mark.parametrize("user", [
    "",                  # empty
    "../../etc",         # path traversal — would yield /home/../../etc
    "..",
    ".hidden",           # leading dot
    "~root",             # leading tilde
    "/absolute",         # leading slash
    "with/slash",
    "with\\backslash",
    "with space",
    "trailing\n",
    "with\ttab",
    "with\rcarriage",
    "with\x00null",
])
def test_resolve_remote_home_rejects_unsafe_user(user):
    with pytest.raises(ValueError):
        resolve_remote_home(user, LINUX)
    with pytest.raises(ValueError):
        resolve_remote_home(user, MACOS)
