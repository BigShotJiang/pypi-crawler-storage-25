from pathlib import Path

import pytest
from pydantic import ValidationError

from agentsec.config import ServerAuditConfig


def test_pip_lock_paths_default_empty():
    sa = ServerAuditConfig(host="h", user="u", key=Path("/k"))
    assert sa.pip_lock_paths == []


def test_pip_lock_paths_accepts_absolute_and_tilde():
    sa = ServerAuditConfig(
        host="h", user="u", key=Path("/k"),
        pip_lock_paths=[
            "/srv/myservice/requirements.txt",
            "~/python-mcp/requirements-prod.txt",
            "/var/lib/foo/lock.in",
            "/opt/poetry-export.lock",
            "/srv/another/requirements-prod",
        ],
    )
    assert len(sa.pip_lock_paths) == 5


def test_pip_lock_paths_rejects_relative():
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            pip_lock_paths=["./requirements.txt"],
        )


def test_pip_lock_paths_rejects_shell_metachar():
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            pip_lock_paths=["/srv/$(whoami)/requirements.txt"],
        )


def test_pip_lock_paths_rejects_bad_suffix():
    with pytest.raises(ValidationError, match="suffix"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            pip_lock_paths=["/etc/shadow"],
        )


def test_pip_lock_paths_rejects_requirements_cfg():
    """requirements.cfg is pip's own config file (may carry creds), not a lockfile."""
    with pytest.raises(ValidationError, match="suffix"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            pip_lock_paths=["/srv/requirements.cfg"],
        )


def test_go_lock_paths_default_empty():
    sa = ServerAuditConfig(host="h", user="u", key=Path("/k"))
    assert sa.go_lock_paths == []


def test_go_lock_paths_accepts_absolute_and_tilde():
    sa = ServerAuditConfig(
        host="h", user="u", key=Path("/k"),
        go_lock_paths=[
            "/srv/myservice/go.sum",
            "~/projects/foo/go.sum",
        ],
    )
    assert len(sa.go_lock_paths) == 2


def test_go_lock_paths_rejects_relative():
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            go_lock_paths=["./go.sum"],
        )


def test_go_lock_paths_rejects_shell_metachar():
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            go_lock_paths=["/srv/$(whoami)/go.sum"],
        )


def test_go_lock_paths_rejects_non_go_sum_basename():
    with pytest.raises(ValidationError, match="basename"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            go_lock_paths=["/srv/go.mod"],
        )


def test_go_lock_paths_rejects_go_sum_with_suffix():
    """basename must equal exactly 'go.sum' — backups must be renamed first."""
    with pytest.raises(ValidationError, match="basename"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            go_lock_paths=["/srv/go.sum.bak"],
        )


def test_cargo_lock_paths_default_empty():
    sa = ServerAuditConfig(host="h", user="u", key=Path("/k"))
    assert sa.cargo_lock_paths == []


def test_cargo_lock_paths_accepts_absolute_and_tilde():
    sa = ServerAuditConfig(
        host="h", user="u", key=Path("/k"),
        cargo_lock_paths=[
            "/srv/myservice/Cargo.lock",
            "~/projects/foo/Cargo.lock",
        ],
    )
    assert len(sa.cargo_lock_paths) == 2


def test_cargo_lock_paths_rejects_relative():
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            cargo_lock_paths=["./Cargo.lock"],
        )


def test_cargo_lock_paths_rejects_shell_metachar():
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            cargo_lock_paths=["/srv/$(whoami)/Cargo.lock"],
        )


def test_cargo_lock_paths_rejects_non_cargo_lock_basename():
    with pytest.raises(ValidationError, match="basename"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            cargo_lock_paths=["/srv/Cargo.toml"],
        )


def test_cargo_lock_paths_rejects_lowercase_cargo_lock():
    """basename is case-sensitive — 'cargo.lock' must be rejected (Cargo uses Cargo.lock)."""
    with pytest.raises(ValidationError, match="basename"):
        ServerAuditConfig(
            host="h", user="u", key=Path("/k"),
            cargo_lock_paths=["/srv/cargo.lock"],
        )
