"""Authorization.validate() — happy path + each rejection branch (spec §6.4)."""

from datetime import UTC, datetime

import pytest

from agentsec.audit.authorization import Authorization, AuthorizationError


def _make(**overrides):
    base = {
        "target_host": "openclaw.example.com",
        "authorized_by": "roger@example.com",
        "identity_provider": "okta-saml",
        "identity_assertion": "eyJhbGciOiJIUzI1NiJ9.fake.payload",
        "valid_from": "2026-04-25T00:00:00Z",
        "valid_until": "2026-05-25T00:00:00Z",
        "scope": ["server-audit", "remote-evaluation"],
        "report_output_path_prefix": "./report-2026-04-25/",
        "signature_mode": "none",
    }
    base.update(overrides)
    return Authorization.model_validate(base)


def test_validate_happy_path_signed(monkeypatch):
    key = b"super-secret-test-key"
    monkeypatch.setenv("TEST_KEY_ENV", key.decode("ascii"))
    auth = _make(signature_mode="hmac_sha256", signature_key_env="TEST_KEY_ENV")
    auth.signature = auth.compute_signature(key)
    auth.validate(
        target_host="openclaw.example.com",
        report_output_path_prefix="./report-2026-04-25/",
        required_scopes=["server-audit"],
        now=datetime(2026, 5, 1, tzinfo=UTC),
    )
    assert auth.low_assurance is False


def test_validate_host_mismatch_rejected():
    auth = _make()
    with pytest.raises(AuthorizationError, match="target_host"):
        auth.validate(
            target_host="other.example.com",
            report_output_path_prefix="./report-2026-04-25/",
            required_scopes=["server-audit"],
            now=datetime(2026, 5, 1, tzinfo=UTC),
        )


def test_validate_window_expired_rejected():
    auth = _make()
    with pytest.raises(AuthorizationError, match="valid"):
        auth.validate(
            target_host="openclaw.example.com",
            report_output_path_prefix="./report-2026-04-25/",
            required_scopes=["server-audit"],
            now=datetime(2026, 6, 1, tzinfo=UTC),
        )


def test_validate_scope_missing_rejected():
    auth = _make(scope=["server-audit"])
    with pytest.raises(AuthorizationError, match="scope"):
        auth.validate(
            target_host="openclaw.example.com",
            report_output_path_prefix="./report-2026-04-25/",
            required_scopes=["fixture-write"],
            now=datetime(2026, 5, 1, tzinfo=UTC),
        )


def test_validate_output_prefix_mismatch_rejected():
    auth = _make()
    with pytest.raises(AuthorizationError, match="report_output_path_prefix"):
        auth.validate(
            target_host="openclaw.example.com",
            report_output_path_prefix="./other-dir/",
            required_scopes=["server-audit"],
            now=datetime(2026, 5, 1, tzinfo=UTC),
        )


@pytest.mark.parametrize(
    "requested",
    [
        "./report-2026-04-25/",  # byte-exact form from the example file
        "./report-2026-04-25",   # CLI passes Path() which strips trailing slash
        "report-2026-04-25/",     # ./ stripped
        "report-2026-04-25",      # both stripped (what str(Path("./x/")) returns)
    ],
)
def test_validate_output_prefix_normalizes_dot_slash_and_trailing_slash(requested):
    """The documented invocation is `--output ./report-2026-04-27/`, but
    Typer parses that into Path() which strips both `./` and the trailing
    slash. The validator must normalize via Path equality so the example
    AUTHORIZATION.txt actually works on first try.
    """
    auth = _make()
    auth.validate(
        target_host="openclaw.example.com",
        report_output_path_prefix=requested,
        required_scopes=["server-audit"],
        now=datetime(2026, 5, 1, tzinfo=UTC),
    )


def test_validate_signature_tampered_rejected(monkeypatch):
    key = b"super-secret-test-key"
    monkeypatch.setenv("TEST_KEY_ENV", key.decode("ascii"))
    auth = _make(signature_mode="hmac_sha256", signature_key_env="TEST_KEY_ENV")
    auth.signature = auth.compute_signature(key)
    bad = list(auth.signature)
    bad[0] = "X" if bad[0] != "X" else "Y"
    auth.signature = "".join(bad)
    with pytest.raises(AuthorizationError, match="signature"):
        auth.validate(
            target_host="openclaw.example.com",
            report_output_path_prefix="./report-2026-04-25/",
            required_scopes=["server-audit"],
            now=datetime(2026, 5, 1, tzinfo=UTC),
        )


def test_validate_low_assurance_when_signature_mode_none():
    auth = _make()
    auth.validate(
        target_host="openclaw.example.com",
        report_output_path_prefix="./report-2026-04-25/",
        required_scopes=["server-audit"],
        now=datetime(2026, 5, 1, tzinfo=UTC),
    )
    assert auth.low_assurance is True


def test_validate_low_assurance_when_identity_assertion_empty(monkeypatch):
    key = b"k"
    monkeypatch.setenv("TEST_KEY_ENV", key.decode("ascii"))
    auth = _make(
        identity_assertion="",
        signature_mode="hmac_sha256",
        signature_key_env="TEST_KEY_ENV",
    )
    auth.signature = auth.compute_signature(key)
    auth.validate(
        target_host="openclaw.example.com",
        report_output_path_prefix="./report-2026-04-25/",
        required_scopes=["server-audit"],
        now=datetime(2026, 5, 1, tzinfo=UTC),
    )
    assert auth.low_assurance is True


def test_validate_signature_key_env_missing_rejected(monkeypatch):
    monkeypatch.delenv("TEST_KEY_ENV", raising=False)
    auth = _make(signature_mode="hmac_sha256", signature_key_env="TEST_KEY_ENV")
    auth.signature = "anything"
    with pytest.raises(AuthorizationError, match="key"):
        auth.validate(
            target_host="openclaw.example.com",
            report_output_path_prefix="./report-2026-04-25/",
            required_scopes=["server-audit"],
            now=datetime(2026, 5, 1, tzinfo=UTC),
        )


_NAIVE_FROM_YAML = """\
target_host: openclaw.example.com
authorized_by: roger@example.com
identity_provider: okta-saml
identity_assertion: assertion
valid_from: 2026-04-25T00:00:00
valid_until: 2026-05-25T00:00:00Z
scope: [server-audit]
report_output_path_prefix: ./out/
signature_mode: none
"""

_NAIVE_UNTIL_YAML = """\
target_host: openclaw.example.com
authorized_by: roger@example.com
identity_provider: okta-saml
identity_assertion: assertion
valid_from: 2026-04-25T00:00:00Z
valid_until: 2026-05-25T00:00:00
scope: [server-audit]
report_output_path_prefix: ./out/
signature_mode: none
"""


@pytest.mark.parametrize(
    ("yaml_text", "field"),
    [(_NAIVE_FROM_YAML, "valid_from"), (_NAIVE_UNTIL_YAML, "valid_until")],
)
def test_load_rejects_naive_datetimes_with_authorization_error(
    tmp_path, yaml_text, field,
):
    """A user-edited AUTHORIZATION.txt that drops the trailing `Z` produces
    a naive datetime. Pydantic v2 keeps it naive, so without this guard the
    aware-vs-naive comparison in validate() would raise a bare TypeError —
    which the CLI doesn't catch, surfacing a stack trace instead of the
    friendly `authorization rejected: …` line every other branch produces.
    """
    p = tmp_path / "AUTHORIZATION.txt"
    p.write_text(yaml_text)
    with pytest.raises(AuthorizationError, match=field):
        Authorization.load(p)
