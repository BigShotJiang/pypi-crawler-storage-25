"""tunnel.open_local_forward should bridge a local socket → SSH direct-tcpip
channel. We can't exercise a real SSHD in unit tests, so the test injects a
fake transport_factory whose .open_channel() returns a paramiko-channel-shaped
object backed by an in-memory bytes pipe."""

from __future__ import annotations

import socket

import pytest

from agentsec.audit import tunnel


class _FakeChannel:
    """Bidirectional bytes pipe mimicking enough of paramiko.Channel.

    Supports send / recv / close; backed by a `socket.socketpair` so the
    bridging thread sees normal socket semantics.
    """
    def __init__(self):
        self._a, self._b = socket.socketpair()
        self.closed = False

    # paramiko-Channel surface used by the bridging thread:
    def recv(self, n: int) -> bytes:
        return self._a.recv(n)

    def send(self, data: bytes) -> int:
        return self._a.send(data)

    def close(self) -> None:
        self.closed = True
        try:
            self._a.close()
        except OSError:
            pass

    # Test helper: counterpart-side socket
    def peer_socket(self) -> socket.socket:
        return self._b


class _FakeTransport:
    def __init__(self):
        self.channels: list[_FakeChannel] = []
        self.opened: list[tuple] = []

    def open_channel(self, kind: str, dest_addr, src_addr):
        assert kind == "direct-tcpip"
        ch = _FakeChannel()
        self.channels.append(ch)
        self.opened.append((kind, tuple(dest_addr), tuple(src_addr)))
        return ch


class _FakeClient:
    def __init__(self, transport: _FakeTransport):
        self._t = transport
        self.closed = False

    def get_transport(self) -> _FakeTransport:
        return self._t

    def close(self) -> None:
        self.closed = True


def test_open_local_forward_bridges_bytes_in_both_directions(monkeypatch):
    transport = _FakeTransport()
    client = _FakeClient(transport)
    monkeypatch.setattr(tunnel, "_build_ssh_client", lambda h, u, k: client)

    with tunnel.open_local_forward("h", "u", "/key.pem", remote_port=18789) as local_port:
        assert local_port > 0
        s = socket.create_connection(("127.0.0.1", local_port), timeout=2.0)
        s.sendall(b"hello-from-local")
        # First (and only) connection → first channel
        # Wait for handler to open a channel; loop briefly.
        import time
        deadline = time.time() + 2.0
        while not transport.channels and time.time() < deadline:
            time.sleep(0.01)
        assert len(transport.channels) == 1
        peer = transport.channels[0].peer_socket()
        peer.settimeout(2.0)
        assert peer.recv(64) == b"hello-from-local"
        # Send the reply before closing the write-end of the local socket.
        # Once we shutdown(SHUT_WR) below, _pump(local→channel) will see EOF
        # and call channel.close() via the new finally block; doing it *after*
        # the reply is already received avoids a race with _pump closing the
        # channel's internal socket before peer.sendall() completes.
        peer.sendall(b"hello-from-remote")
        peer.shutdown(socket.SHUT_WR)
        assert s.recv(64) == b"hello-from-remote"
        # Now close the local write-end; _pump(local→channel) exits and the
        # finally block closes the channel.
        s.shutdown(socket.SHUT_WR)
        s.close()
        # Wait for bridge to close the channel
        deadline = time.time() + 2.0
        while not transport.channels[0].closed and time.time() < deadline:
            time.sleep(0.01)

    assert transport.channels[0].closed
    assert client.closed
    assert transport.opened[0][0] == "direct-tcpip"
    assert transport.opened[0][1] == ("127.0.0.1", 18789)
    # src_addr is the client_address tuple; sanity-check shape only
    assert isinstance(transport.opened[0][2], tuple)
    assert len(transport.opened[0][2]) == 2


def test_open_local_forward_handler_drops_connection_when_open_channel_fails(monkeypatch, capfd):
    """If transport.open_channel raises (e.g., forwarding denied), the
    handler should drop the local connection without printing a traceback
    to stderr. active_test sees a connection error and translates it into
    a finding/skip."""
    class _Boom(Exception):
        pass

    class _BadTransport:
        def open_channel(self, kind, dest_addr, src_addr):
            raise _Boom("forwarding denied")

    class _Client:
        def __init__(self):
            self.closed = False

        def get_transport(self):
            return _BadTransport()

        def close(self):
            self.closed = True

    client = _Client()
    monkeypatch.setattr(tunnel, "_build_ssh_client", lambda h, u, k: client)

    with tunnel.open_local_forward("h", "u", "/key.pem", remote_port=18789) as local_port:
        s = socket.create_connection(("127.0.0.1", local_port), timeout=2.0)
        # Server accepted; handler will try open_channel, which raises,
        # then return. Local socket gets closed by socketserver.
        # We just need to confirm the client side gets EOF, not a traceback.
        s.settimeout(2.0)
        try:
            data = s.recv(64)
        except OSError:
            data = b""
        assert data == b""
        s.close()

    # capfd captures both stdout and stderr. The traceback would land in stderr
    # via socketserver.BaseServer.handle_error. We require it stays clean.
    captured = capfd.readouterr()
    assert "Traceback" not in captured.err, (
        f"handler leaked a traceback to stderr:\n{captured.err}"
    )
    assert client.closed


def test_open_local_forward_propagates_handshake_failure(monkeypatch):
    """If `_build_ssh_client` raises (auth failure, network), the context
    manager surfaces the exception so `active_test` can mark `skipped`."""
    class _Boom(Exception):
        pass

    def _bad_client(h, u, k):
        raise _Boom("auth denied")

    monkeypatch.setattr(tunnel, "_build_ssh_client", _bad_client)

    with pytest.raises(_Boom, match="auth denied"):
        with tunnel.open_local_forward("h", "u", "/key.pem", remote_port=18789):
            pytest.fail("should not enter the with-block")
