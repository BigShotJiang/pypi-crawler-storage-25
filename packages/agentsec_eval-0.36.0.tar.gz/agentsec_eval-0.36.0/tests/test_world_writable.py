"""Unit tests for WorldWritableCheck (Phase 7e.1)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.world_writable import WorldWritableCheck
from agentsec.audit.platform_profile import LINUX, LINUX_USER_MODE, materialize_paths
from agentsec.audit.types import RunResult


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        key = tuple(argv)
        if key in self._responses:
            return self._responses[key]
        return RunResult(
            stdout="", stderr="", exit_code=0,
            rejected=False, reject_reason=None, argv=argv,
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        )


def _runresult(stdout="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr="", exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux", remote_home="/home/u",
         user_mode=False):
    base = LINUX_USER_MODE if user_mode else LINUX
    profile = materialize_paths(base, remote_home)
    if profile_name not in ("linux", "linux_user_mode"):
        # Force a non-Linux profile name for negative tests
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _find_argv(path: str) -> tuple:
    return ("find", path, "-maxdepth", "4", "-type", "f", "-perm", "/002")


def test_no_world_writable_files_zero_findings():
    """All find calls return empty stdout → 0 findings."""
    findings = _run(WorldWritableCheck(), _ctx(_RecordingExecutor({})))
    assert findings == []


def test_cron_d_hit_emits_critical():
    """A file under /etc/cron.d hits → critical severity."""
    responses = {
        _find_argv("/etc/cron.d"): _runresult(stdout="/etc/cron.d/evil_job\n"),
    }
    findings = _run(WorldWritableCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert findings[0].severity == "critical"
    assert "/etc/cron.d/evil_job" in findings[0].title


def test_log_dir_hit_emits_high_via_profile():
    """Hits under profile.paths['log_dir'] (= /var/log/openclaw on LINUX) → high."""
    log_dir_argv = _find_argv("/var/log/openclaw/")  # LINUX profile literal
    responses = {
        log_dir_argv: _runresult(stdout="/var/log/openclaw/audit.log\n/var/log/openclaw/data\n"),
    }
    findings = _run(WorldWritableCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 2
    assert all(f.severity == "high" for f in findings)


def test_openclaw_home_path_from_profile():
    """OpenClaw home path comes from profile.paths['openclaw_home']
    (materialized to absolute via remote_home="/home/u" → /home/u/.openclaw)."""
    home_argv = _find_argv("/home/u/.openclaw/")
    responses = {
        home_argv: _runresult(stdout="/home/u/.openclaw/credentials.txt\n"),
    }
    findings = _run(WorldWritableCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert findings[0].severity == "high"
    assert "/home/u/.openclaw/credentials.txt" in findings[0].title


def test_user_mode_skips_log_dir_gracefully():
    """LINUX_USER_MODE profile lacks 'log_dir' key → check should not call find on it."""
    executor = _RecordingExecutor({})
    ctx = _ctx(executor, user_mode=True)
    findings = _run(WorldWritableCheck(), ctx)
    assert findings == []
    # Verify no `find /var/log/openclaw ...` call was made
    log_dir_calls = [c for c in executor.calls if len(c) > 1 and "log/openclaw" in c[1]]
    assert log_dir_calls == []
    # But /home/u/.openclaw must have been called (openclaw_home is in user-mode profile)
    home_calls = [c for c in executor.calls if len(c) > 1 and "/.openclaw" in c[1]]
    assert len(home_calls) == 1


def test_per_path_rejection_skips_only_that_path():
    """One path rejected; others fine → no overall skipped, just no findings on that path."""
    responses = {
        _find_argv("/etc/cron.d"): _runresult(rejected=True),
        _find_argv("/etc/cron.daily"): _runresult(stdout="/etc/cron.daily/bad\n"),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(WorldWritableCheck(), ctx)
    assert len(findings) == 1
    assert "/etc/cron.daily/bad" in findings[0].title
    assert ctx.status.is_skipped is False


def test_all_paths_fail_marks_skipped():
    """Every find call exit 1 → overall skipped."""
    # Static (5) + dynamic (2: openclaw_home + log_dir on LINUX) = 7 paths
    static = ["/tmp/openclaw", "/etc/cron.d", "/etc/cron.daily",
              "/etc/cron.weekly", "/etc/cron.monthly"]
    dynamic = ["/home/u/.openclaw/", "/var/log/openclaw/"]
    responses = {
        _find_argv(p): _runresult(exit_code=1)
        for p in static + dynamic
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(WorldWritableCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_skips_on_macos_profile():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(WorldWritableCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
