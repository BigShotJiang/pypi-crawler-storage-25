"""Runner distinguishes adapter errors from judge errors via the TestResult.error prefix."""

import pytest

from agentsec.adapters.base import AgentAdapter, AgentResponse
from agentsec.evaluator.base import Judge, JudgeVerdict
from agentsec.observability.observation import Observation
from agentsec.runner import run_suite
from agentsec.tests.models import Severity, TestCase, Turn


class _RaisingAdapter(AgentAdapter):
    name = "raising"

    async def send(self, message: str, session_id: str) -> AgentResponse:
        raise RuntimeError("network down")


class _OkAdapter(AgentAdapter):
    name = "ok"

    async def send(self, message: str, session_id: str) -> AgentResponse:
        return AgentResponse(content="ok")


class _RaisingJudge(Judge):
    async def evaluate(self, test_case: TestCase, observation: Observation) -> JudgeVerdict:
        raise RuntimeError("judge broken")


class _OkJudge(Judge):
    async def evaluate(self, test_case: TestCase, observation: Observation) -> JudgeVerdict:
        return JudgeVerdict(passed=True, reasoning="x", judge_type="llm")


def _case() -> TestCase:
    return TestCase(
        id="t-1", category="x", description="d",
        turns=[Turn(attack="a")],
        expected_behavior="refusal", severity=Severity.low,
    )


@pytest.mark.asyncio
async def test_adapter_failure_prefixes_error_with_adapter():
    results = await run_suite(_RaisingAdapter(), _OkJudge(), [_case()], concurrency=1)
    assert results[0].status == "error"
    assert results[0].error.startswith("adapter:")
    # Adapter failed before any meaningful response: no observation in trail.
    assert results[0].observations == []


@pytest.mark.asyncio
async def test_judge_failure_prefixes_error_with_judge():
    results = await run_suite(_OkAdapter(), _RaisingJudge(), [_case()], concurrency=1)
    assert results[0].status == "error"
    assert results[0].error.startswith("judge:")
    # Judge failed AFTER the response was captured: partial observation preserved.
    assert len(results[0].observations) == 1
