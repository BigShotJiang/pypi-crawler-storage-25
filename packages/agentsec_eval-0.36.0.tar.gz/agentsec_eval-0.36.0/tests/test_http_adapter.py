import httpx
import pytest

from agentsec.adapters.http import HttpAgentAdapter


@pytest.mark.asyncio
async def test_http_adapter_populates_status_and_headers():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"reply": "hello"}, headers={"x-trace": "abc"})

    adapter = HttpAgentAdapter(name="t", base_url="http://example.test")
    adapter._client_factory = lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler))
    r = await adapter.send("ping", "sess-1")
    assert r.content == "hello"
    assert r.status_code == 200
    assert r.headers["x-trace"] == "abc"
    assert r.request_url == "http://example.test/chat"
    assert r.error is None


@pytest.mark.asyncio
async def test_http_adapter_returns_response_on_5xx_without_raising():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, text="upstream down")

    adapter = HttpAgentAdapter(name="t", base_url="http://example.test")
    adapter._client_factory = lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler))
    r = await adapter.send("ping", "sess-1")
    assert r.status_code == 503
    assert r.error is not None
    assert "503" in r.error or "upstream" in r.error.lower()


@pytest.mark.asyncio
async def test_http_adapter_path_param_overrides_default():
    captured: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return httpx.Response(200, json={"reply": "ok"})

    adapter = HttpAgentAdapter(
        name="t", base_url="http://example.test", path="/v1/chat/completions"
    )
    adapter._client_factory = lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler))
    await adapter.send("ping", "sess-1")
    assert captured["url"].endswith("/v1/chat/completions")
