from pathlib import Path

import pytest

from agentsec.tests.loader import load_test_suite

REPO = Path(__file__).resolve().parent.parent


def test_canonical_root_test_suite_loads_cleanly():
    cases = load_test_suite(REPO / "test_suites")
    # Phase 7a added 5 new YAML files (25 cases); maintain >= 11 floor to catch removals.
    assert len(cases) >= 11, f"Expected at least 11 cases, got {len(cases)}"
    ids = {c.id for c in cases}
    # Core categories must be present.
    assert {"pi-001", "dl-001", "ta-001"}.issubset(ids)
    # All cases must be well-formed.
    for c in cases:
        assert c.id, "Case must have non-empty id"
        assert c.category, "Case must have non-empty category"
        assert c.severity, "Case must have non-empty severity"
        assert c.turns is not None, f"Case {c.id} turns is None"
        assert len(c.turns) == 1, f"Case {c.id} should have exactly 1 turn after expansion"
        assert c.turns[0].attack, f"Case {c.id} turn 0 must have attack"
        assert c.attack is None, f"Case {c.id} original attack should be None after expansion"


def test_loader_rejects_duplicate_ids(tmp_path: Path):
    a = tmp_path / "a.yaml"
    b = tmp_path / "b.yaml"
    yaml_body = (
        "- id: dup\n  category: c\n  description: d\n  attack: a\n"
        "  expected_behavior: refusal\n  severity: low\n"
    )
    a.write_text(yaml_body)
    b.write_text(yaml_body)
    with pytest.raises(ValueError) as ei:
        load_test_suite(tmp_path)
    assert "duplicate" in str(ei.value).lower()


def test_native_turns_yaml_loads(tmp_path: Path):
    p = tmp_path / "mt.yaml"
    p.write_text(
        "- id: mt-1\n  category: multi_turn\n  description: d\n"
        "  turns:\n    - attack: t1\n    - attack: t2\n      judge_after: true\n"
        "  expected_behavior: refusal\n  severity: medium\n"
    )
    cases = load_test_suite(p)
    assert len(cases) == 1
    assert cases[0].attack is None
    assert len(cases[0].turns) == 2
    assert cases[0].turns[1].judge_after is True
