"""container_baseline.yaml — schema sanity for daemon_containerd segment."""

from pathlib import Path

import pytest
import yaml

_BASELINE = (
    Path(__file__).resolve().parents[1]
    / "src" / "agentsec" / "audit" / "checks" / "container_baseline.yaml"
)


@pytest.fixture(scope="module")
def baseline():
    return yaml.safe_load(_BASELINE.read_text())


def test_daemon_containerd_present(baseline):
    assert "daemon_containerd" in baseline, "daemon_containerd segment must exist"


def test_daemon_containerd_rule_count(baseline):
    assert len(baseline["daemon_containerd"]) == 6


def test_daemon_containerd_rule_ids(baseline):
    ids = {r["id"] for r in baseline["daemon_containerd"]}
    assert ids == {
        "containerd-tcp-exposed",
        "containerd-debug-socket-exposed",
        "containerd-metrics-exposed",
        "containerd-cri-disable-apparmor",
        "containerd-cri-no-pivot",
        "containerd-version-cve",
    }


def test_daemon_containerd_required_fields(baseline):
    required = {"id", "severity", "title", "description", "remediation", "threat_refs"}
    for rule in baseline["daemon_containerd"]:
        missing = required - set(rule.keys())
        assert not missing, f"rule {rule.get('id')} missing fields {missing}"


def test_daemon_containerd_severity_values(baseline):
    sevs = {r["id"]: r["severity"] for r in baseline["daemon_containerd"]}
    assert sevs == {
        "containerd-tcp-exposed": "critical",
        "containerd-debug-socket-exposed": "high",
        "containerd-metrics-exposed": "medium",
        "containerd-cri-disable-apparmor": "high",
        "containerd-cri-no-pivot": "medium",
        "containerd-version-cve": "high",
    }


def test_daemon_containerd_version_cve_known_bad(baseline):
    rules = {r["id"]: r for r in baseline["daemon_containerd"]}
    assert rules["containerd-version-cve"]["known_bad_versions"] == ["<1.6.28", "<1.7.11"]


def test_daemon_containerd_threat_refs(baseline):
    expected = {
        "containerd-tcp-exposed": ["TI-CONTAINERD-DAEMON-TCP-EXPOSED"],
        "containerd-debug-socket-exposed": ["TI-CONTAINERD-DAEMON-DEBUG-SOCKET"],
        "containerd-metrics-exposed": ["TI-CONTAINERD-DAEMON-METRICS-EXPOSED"],
        "containerd-cri-disable-apparmor": ["TI-CONTAINERD-DAEMON-DISABLE-APPARMOR"],
        "containerd-cri-no-pivot": ["TI-CONTAINERD-DAEMON-NO-PIVOT"],
        "containerd-version-cve": ["TI-CONTAINERD-DAEMON-VERSION-CVE"],
    }
    rules = {r["id"]: r for r in baseline["daemon_containerd"]}
    for rid, refs in expected.items():
        assert rules[rid]["threat_refs"] == refs
