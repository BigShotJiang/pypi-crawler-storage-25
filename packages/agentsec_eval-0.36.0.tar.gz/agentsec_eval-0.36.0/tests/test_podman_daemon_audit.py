"""PodmanDaemonAuditCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.podman_daemon_audit import PodmanDaemonAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"

_BIN = "/usr/bin/podman"
_CONF_ETC = ("cat", "/etc/containers/containers.conf")
_CONF_USR = ("cat", "/usr/share/containers/containers.conf")
_VERSION = ("podman", "version", "--format", "{{json .}}")
_INFO = ("podman", "info", "--format", "{{json .}}")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=1, rejected=False,
                reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=Path("/tmp"), profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found_path: str | None) -> dict[tuple, RunResult]:
    candidates = ("/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman")
    out: dict[tuple, RunResult] = {}
    for c in candidates:
        if c == found_path:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c + "\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def _full_responses(*, conf_text: str, version_json: str, info_json: str,
                    found_podman: str = _BIN) -> dict[tuple, RunResult]:
    responses = _detect_responses(found_podman)
    responses[_CONF_ETC] = _runresult(stdout=conf_text)
    responses[_VERSION] = _runresult(stdout=version_json)
    responses[_INFO] = _runresult(stdout=info_json)
    return responses


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True


def test_not_applicable_no_podman():
    ctx = _ctx(_RecordingExecutor(_detect_responses(None)))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True


def test_compliant_zero_findings():
    conf = (_FIXTURES / "podman_containers_conf_compliant.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []


def test_rootful_emits_high():
    conf = (_FIXTURES / "podman_containers_conf_compliant.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootful.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert len(findings) == 1
    assert findings[0].severity == "high"
    assert findings[0].evidence["rule_id"] == "podman-rootful-mode"


def test_userns_host_emits_medium():
    conf = (_FIXTURES / "podman_containers_conf_userns_host.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-userns-default-host"
               and f.severity == "medium" for f in findings)


def test_userns_missing_emits_medium():
    """containers.conf 缺 userns 字段 → 视为 host"""
    conf = "[containers]\nno_new_privileges = true\n"
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-userns-default-host" for f in findings)


def test_no_new_priv_off_emits_medium():
    conf = (_FIXTURES / "podman_containers_conf_no_new_priv_off.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-no-new-priv-off"
               and f.severity == "medium" for f in findings)


def test_version_cve_emits_high():
    conf = (_FIXTURES / "podman_containers_conf_compliant.toml").read_text()
    version = (_FIXTURES / "podman_version_cve.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-version-cve"
               and f.severity == "high" for f in findings)


def test_containers_conf_missing_falls_back_distro():
    """/etc/containers/containers.conf missing → fall back to /usr/share/..."""
    distro_conf = "[containers]\nuserns = \"auto\"\nno_new_privileges = true\n"
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_CONF_ETC] = _runresult(stderr="No such file", exit_code=1)
    responses[_CONF_USR] = _runresult(stdout=distro_conf)
    responses[_VERSION] = _runresult(stdout=version)
    responses[_INFO] = _runresult(stdout=info)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []  # distro defaults are compliant


def test_podman_info_perm_denied_skipped():
    responses = _detect_responses(_BIN)
    responses[_CONF_ETC] = _runresult(stdout="")
    responses[_INFO] = _runresult(stderr="Permission denied", exit_code=126)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
