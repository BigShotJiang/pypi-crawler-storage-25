import pytest
from pydantic import ValidationError

from agentsec.tests.models import IsolationPolicy, TestCase, Turn


def test_single_attack_is_valid():
    tc = TestCase(
        id="x-1",
        category="prompt_injection",
        description="d",
        attack="payload",
        expected_behavior="refusal",
        severity="high",
    )
    assert tc.attack == "payload"
    assert tc.turns is None
    assert tc.judge_type == "llm"
    assert tc.threat_refs == []
    assert tc.isolation.profile == "shared"


def test_multi_turn_is_valid():
    tc = TestCase(
        id="x-2",
        category="multi_turn",
        description="d",
        turns=[Turn(attack="a"), Turn(attack="b", judge_after=True, sleep_ms=500)],
        expected_behavior="refusal",
        severity="medium",
    )
    assert tc.attack is None
    assert len(tc.turns) == 2
    assert tc.turns[1].sleep_ms == 500


def test_both_attack_and_turns_rejected():
    with pytest.raises(ValidationError) as ei:
        TestCase(
            id="x-3", category="x", description="d",
            attack="a", turns=[Turn(attack="t")],
            expected_behavior="refusal", severity="low",
        )
    assert "exactly one" in str(ei.value).lower()


def test_neither_attack_nor_turns_rejected():
    with pytest.raises(ValidationError) as ei:
        TestCase(
            id="x-4", category="x", description="d",
            expected_behavior="refusal", severity="low",
        )
    assert "exactly one" in str(ei.value).lower()


def test_isolation_default_factory_is_distinct_per_instance():
    a = TestCase(id="a", category="c", description="d", attack="x",
                 expected_behavior="refusal", severity="low")
    b = TestCase(id="b", category="c", description="d", attack="x",
                 expected_behavior="refusal", severity="low")
    assert a.isolation is not b.isolation


def test_threat_refs_and_assertions_optional():
    from agentsec.evaluator.assertions import ResponseStatusIn

    tc = TestCase(
        id="x-5", category="c", description="d",
        attack="x", expected_behavior="refusal", severity="low",
        threat_refs=["TI-OPENCLAW-CVE-2026-25253"],
        assertions=[{"type": "response_status_in", "statuses": [200, 401]}],
    )
    assert tc.threat_refs == ["TI-OPENCLAW-CVE-2026-25253"]
    assert len(tc.assertions) == 1
    assert isinstance(tc.assertions[0], ResponseStatusIn)
    assert tc.assertions[0].statuses == [200, 401]


def test_isolation_policy_fields():
    p = IsolationPolicy(profile="disposable", pre_snapshot=["memory_file"],
                       post_snapshot=["memory_file"], cleanup_on_failure="required")
    assert p.profile == "disposable"
    assert p.cleanup_on_failure == "required"
