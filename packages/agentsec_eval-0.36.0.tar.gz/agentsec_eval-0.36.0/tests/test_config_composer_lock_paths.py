"""Unit tests for ServerAuditConfig.composer_lock_paths validator (Phase 7d.6)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentsec.config import ServerAuditConfig


def _config(**overrides) -> dict:
    """Minimal valid ServerAuditConfig dict."""
    return {
        "host": "test.example",
        "user": "ubuntu",
        "key": "/home/ubuntu/.ssh/id_rsa",
        **overrides,
    }


def test_empty_composer_lock_paths_is_valid() -> None:
    cfg = ServerAuditConfig.model_validate(_config())
    assert cfg.composer_lock_paths == []


def test_accepts_valid_composer_lock_path() -> None:
    cfg = ServerAuditConfig.model_validate(_config(
        composer_lock_paths=[
            "/opt/myapp/composer.lock",
            "~/projects/laravel-app/composer.lock",
        ]
    ))
    assert len(cfg.composer_lock_paths) == 2


def test_rejects_relative_path() -> None:
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["composer.lock"]
        ))


def test_rejects_shell_metachar() -> None:
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/app;rm/composer.lock"]
        ))


def test_rejects_non_canonical_basename() -> None:
    # Must be exactly "composer.lock" (lowercase)
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/myapp/Composer.lock"]  # capital wrong
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/myapp/composer.lock.bak"]  # suffix wrong
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/myapp/composer.json"]  # not lockfile
        ))
