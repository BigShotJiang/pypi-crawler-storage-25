"""JudgeRouter dispatches by TestCase.judge_type."""

from unittest.mock import AsyncMock

import pytest

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.base import Judge, JudgeVerdict
from agentsec.evaluator.judge_router import JudgeRouter
from agentsec.observability.observation import Observation
from agentsec.tests.models import Severity, TestCase


def _case(judge_type: str) -> TestCase:
    return TestCase(
        id="t-1", category="x", description="d", attack="a",
        expected_behavior="refusal", severity=Severity.low,
        judge_type=judge_type,
    )


def _stub(name: str) -> Judge:
    j = AsyncMock(spec=Judge)
    j.evaluate.return_value = JudgeVerdict(
        passed=True, reasoning=f"from {name}", judge_type=name,  # type: ignore[arg-type]
    )
    return j


@pytest.mark.asyncio
async def test_routes_to_llm():
    llm, det, hyb = _stub("llm"), _stub("deterministic"), _stub("hybrid")
    r = JudgeRouter(llm=llm, deterministic=det, hybrid=hyb)
    obs = Observation(response=AgentResponse(content=""))
    v = await r.evaluate(_case("llm"), obs)
    assert v.reasoning == "from llm"
    llm.evaluate.assert_awaited_once()
    det.evaluate.assert_not_awaited()
    hyb.evaluate.assert_not_awaited()


@pytest.mark.asyncio
async def test_routes_to_deterministic():
    llm, det, hyb = _stub("llm"), _stub("deterministic"), _stub("hybrid")
    r = JudgeRouter(llm=llm, deterministic=det, hybrid=hyb)
    obs = Observation(response=AgentResponse(content=""))
    v = await r.evaluate(_case("deterministic"), obs)
    assert v.reasoning == "from deterministic"
    det.evaluate.assert_awaited_once()


@pytest.mark.asyncio
async def test_routes_to_hybrid():
    llm, det, hyb = _stub("llm"), _stub("deterministic"), _stub("hybrid")
    r = JudgeRouter(llm=llm, deterministic=det, hybrid=hyb)
    obs = Observation(response=AgentResponse(content=""))
    v = await r.evaluate(_case("hybrid"), obs)
    assert v.reasoning == "from hybrid"
    hyb.evaluate.assert_awaited_once()
