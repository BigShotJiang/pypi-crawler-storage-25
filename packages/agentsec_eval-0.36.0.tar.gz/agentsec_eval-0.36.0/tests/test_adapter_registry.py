import pytest

from agentsec.adapters import registry as r
from agentsec.adapters.base import AgentAdapter
from agentsec.adapters.http import HttpAgentAdapter


@pytest.fixture
def isolated_registry():
    """Snapshot/restore _REGISTRY around mutating tests so they don't leak names."""
    snapshot = dict(r._REGISTRY)
    try:
        yield
    finally:
        r._REGISTRY.clear()
        r._REGISTRY.update(snapshot)


def test_builtin_http_adapter_is_registered():
    factory = r.get("http")
    adapter = factory(name="x", base_url="http://localhost")
    assert isinstance(adapter, HttpAgentAdapter)


def test_get_unknown_adapter_raises_keyerror():
    with pytest.raises(KeyError) as exc:
        r.get("does-not-exist")
    assert "does-not-exist" in str(exc.value)
    assert "http" in str(exc.value)  # error names available adapters


def test_register_then_get_returns_same_factory(isolated_registry):
    class Dummy(AgentAdapter):
        async def send(self, message, session_id):  # pragma: no cover
            ...

    factory = lambda **kw: Dummy()  # noqa: E731
    r.register("dummy-success", factory)
    assert r.get("dummy-success") is factory


def test_register_duplicate_raises(isolated_registry):
    class Dummy(AgentAdapter):
        async def send(self, message, session_id):  # pragma: no cover
            ...

    r.register("dummy-uniq", lambda **kw: Dummy())
    with pytest.raises(ValueError):
        r.register("dummy-uniq", lambda **kw: Dummy())


def test_available_lists_all_registered_names():
    names = r.available()
    assert "http" in names
    assert "openclaw-gateway" in names
