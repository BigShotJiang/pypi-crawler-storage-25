"""Tests for _log_runtime_paths_added — the audit-log helper added in fix(7d.1).

Spec §5 + ADR-0013 D6: whenever CommandPolicy.add_runtime_allowed_paths runs
at orchestrator startup an audit-log line must be written so operators can
trace why an exact-kind path was readable.
"""
import json


def test_log_runtime_paths_added_creates_file(tmp_path):
    from agentsec.cli import _log_runtime_paths_added

    log = tmp_path / "audit.jsonl"
    _log_runtime_paths_added(log, ["/srv/req.txt", "/var/lib/lock.lock"], "test")

    assert log.exists()
    line = log.read_text().strip()
    rec = json.loads(line)
    assert rec["event"] == "runtime_allowed_paths_added"
    assert rec["paths"] == ["/srv/req.txt", "/var/lib/lock.lock"]
    assert rec["source"] == "test"
    assert "ts" in rec


def test_log_runtime_paths_added_appends(tmp_path):
    from agentsec.cli import _log_runtime_paths_added

    log = tmp_path / "audit.jsonl"
    _log_runtime_paths_added(log, ["/a/requirements.txt"], "source-A")
    _log_runtime_paths_added(log, ["/b/requirements.txt"], "source-B")

    lines = log.read_text().strip().splitlines()
    assert len(lines) == 2
    assert json.loads(lines[0])["source"] == "source-A"
    assert json.loads(lines[1])["source"] == "source-B"


def test_log_runtime_paths_added_creates_parent_dirs(tmp_path):
    from agentsec.cli import _log_runtime_paths_added

    log = tmp_path / "nested" / "dir" / "audit.jsonl"
    _log_runtime_paths_added(log, ["/srv/x.txt"], "server-audit")

    assert log.exists()
    rec = json.loads(log.read_text().strip())
    assert rec["event"] == "runtime_allowed_paths_added"


def test_log_runtime_paths_added_source_variants(tmp_path):
    """Verify both canonical source strings used by the two CLI call sites."""
    from agentsec.cli import _log_runtime_paths_added

    log = tmp_path / "audit.jsonl"

    _log_runtime_paths_added(
        log, ["/home/ubuntu/app/requirements.txt"],
        "agentsec server-audit --pip-lock-path",
    )
    _log_runtime_paths_added(
        log, ["/home/ubuntu/app/requirements.txt"],
        "ServerAuditConfig.pip_lock_paths",
    )

    lines = log.read_text().strip().splitlines()
    sources = [json.loads(line)["source"] for line in lines]
    assert "agentsec server-audit --pip-lock-path" in sources
    assert "ServerAuditConfig.pip_lock_paths" in sources
