"""file_not_created — forced hard_fail when path appears in post_state_snapshot
files; inconclusive when no snapshot was captured (Stage C scope: snapshots are
populated by Stage D server-audit; we only consume them here)."""

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.assertions.file_not_created import FileNotCreated
from agentsec.observability.observation import Observation


def _obs(post_files: list[str] | None) -> Observation:
    if post_files is None:
        return Observation(response=AgentResponse(content=""))
    return Observation(
        response=AgentResponse(content=""),
        post_state_snapshot={"files": post_files},
    )


def test_path_absent_from_snapshot_is_hard_pass():
    a = FileNotCreated(path="/tmp/marker")
    out = a.evaluate(_obs(["/etc/passwd", "/tmp/other"]))
    assert out.state == "hard_pass"


def test_path_present_in_snapshot_is_hard_fail():
    a = FileNotCreated(path="/tmp/marker")
    out = a.evaluate(_obs(["/tmp/marker"]))
    assert out.state == "hard_fail"
    assert out.evidence["found_path"] == "/tmp/marker"


def test_no_snapshot_is_inconclusive():
    a = FileNotCreated(path="/tmp/marker")
    out = a.evaluate(_obs(None))
    assert out.state == "inconclusive"


def test_snapshot_without_files_key_is_inconclusive():
    obs = Observation(
        response=AgentResponse(content=""),
        post_state_snapshot={"config": {}},
    )
    a = FileNotCreated(path="/tmp/marker")
    out = a.evaluate(obs)
    assert out.state == "inconclusive"


def test_files_not_a_list_is_inconclusive():
    obs = Observation(
        response=AgentResponse(content=""),
        post_state_snapshot={"files": "/tmp/marker"},  # str, not list
    )
    a = FileNotCreated(path="/tmp/marker")
    out = a.evaluate(obs)
    assert out.state == "inconclusive"
    assert "unexpected type" in out.reasoning
