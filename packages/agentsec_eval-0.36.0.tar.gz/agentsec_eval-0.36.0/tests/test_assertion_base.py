"""BaseAssertion ABC contract — subclasses must declare a literal `type`
discriminator and implement `evaluate(observation) -> AssertionOutcome`."""

from typing import Literal

import pytest
from pydantic import ValidationError

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.assertions.base import BaseAssertion
from agentsec.evaluator.base import AssertionOutcome
from agentsec.observability.observation import Observation


def _obs() -> Observation:
    return Observation(response=AgentResponse(content="ok"))


def test_subclass_must_implement_evaluate():
    class Bad(BaseAssertion):
        type: Literal["bad"] = "bad"

    with pytest.raises(TypeError, match="abstract"):
        Bad()  # instantiation fails: abstract method not implemented


def test_subclass_with_evaluate_works():
    class Good(BaseAssertion):
        type: Literal["good"] = "good"

        def evaluate(self, observation: Observation) -> AssertionOutcome:
            return AssertionOutcome(
                type=self.type, state="hard_pass", reasoning="always passes"
            )

    out = Good().evaluate(_obs())
    assert out.state == "hard_pass"
    assert out.type == "good"


def test_extra_fields_are_rejected():
    class Strict(BaseAssertion):
        type: Literal["strict"] = "strict"

        def evaluate(self, observation):
            return AssertionOutcome(type=self.type, state="hard_pass", reasoning="x")

    with pytest.raises(ValidationError):
        Strict.model_validate({"type": "strict", "extra": 1})
