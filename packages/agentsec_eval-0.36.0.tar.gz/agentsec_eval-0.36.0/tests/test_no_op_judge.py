import pytest

from agentsec.evaluator.base import Judge
from agentsec.evaluator.no_op_judge import NoOpJudge, NoOpJudgeInvoked


def test_no_op_judge_is_a_judge_subclass():
    assert issubclass(NoOpJudge, Judge)


@pytest.mark.asyncio
async def test_no_op_judge_raises_when_invoked():
    judge = NoOpJudge()
    with pytest.raises(NoOpJudgeInvoked, match="LLM judge is not configured"):
        await judge.evaluate(test_case=None, observation=None)  # type: ignore[arg-type]


def test_no_op_judge_invoked_is_runtime_error_subclass():
    # Lets callers catch it as RuntimeError without importing the typed class.
    assert issubclass(NoOpJudgeInvoked, RuntimeError)
