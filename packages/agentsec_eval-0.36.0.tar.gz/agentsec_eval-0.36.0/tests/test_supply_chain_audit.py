"""SupplyChainAuditCheck unit tests (Phase 7d)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.supply_chain_audit import (
    SupplyChainAuditCheck,
    _safe_parse_semver,
    parse_npm_lock,
    severity_from_cvss_score,
    version_in_any_range,
)
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

# ---- parse_npm_lock ----

def test_parse_lock_v3_basic():
    lock = """
    {
      "name": "openclaw", "lockfileVersion": 3,
      "packages": {
        "": {"name": "openclaw", "version": "1.0.0"},
        "node_modules/lodash": {"version": "4.17.21"},
        "node_modules/express": {"version": "4.18.2"}
      }
    }
    """
    pkgs = parse_npm_lock(lock)
    assert ("lodash", "4.17.21") in pkgs
    assert ("express", "4.18.2") in pkgs
    assert ("openclaw", "1.0.0") not in pkgs   # root entry skipped


def test_parse_lock_skips_link_entries():
    lock = """
    {"lockfileVersion": 3, "packages": {
      "node_modules/local-pkg": {"link": true, "resolved": "../local"}
    }}
    """
    assert parse_npm_lock(lock) == []


def test_parse_lock_scoped_packages():
    lock = """
    {"lockfileVersion": 3, "packages": {
      "node_modules/@scope/pkg": {"version": "2.0.0"}
    }}
    """
    pkgs = parse_npm_lock(lock)
    assert pkgs == [("@scope/pkg", "2.0.0")]


def test_parse_lock_nested_node_modules():
    """A deeply nested transitive dep at node_modules/express/node_modules/qs."""
    lock = """
    {"lockfileVersion": 3, "packages": {
      "node_modules/express/node_modules/qs": {"version": "6.11.0"}
    }}
    """
    pkgs = parse_npm_lock(lock)
    assert pkgs == [("qs", "6.11.0")]


def test_parse_lock_v1_returns_empty():
    """Lockfile v1 puts deps under top-level 'dependencies' key, not 'packages'.
    We don't support v1; should silently return []."""
    lock = """
    {"lockfileVersion": 1, "dependencies": {"lodash": {"version": "4.17.15"}}}
    """
    assert parse_npm_lock(lock) == []


def test_parse_lock_entry_without_version():
    """Workspace placeholder or partial entry → skip cleanly."""
    lock = """
    {"lockfileVersion": 3, "packages": {
      "node_modules/no-version": {}
    }}
    """
    assert parse_npm_lock(lock) == []


# ---- version_in_any_range ----

def test_version_in_range_lower_bound():
    """introduced=4.17.0, fixed=4.17.21 → 4.17.15 is vulnerable, 3.99 is not."""
    ranges = [{"introduced": "4.17.0", "fixed": "4.17.21"}]
    assert version_in_any_range("4.17.15", ranges) is True
    assert version_in_any_range("3.99.0", ranges) is False


def test_version_in_range_upper_bound_fixed():
    """version >= fixed is safe."""
    ranges = [{"introduced": "0", "fixed": "4.17.21"}]
    assert version_in_any_range("4.17.20", ranges) is True
    assert version_in_any_range("4.17.21", ranges) is False
    assert version_in_any_range("5.0.0", ranges) is False


def test_version_in_range_last_affected():
    """OSV uses last_affected (inclusive) for some entries."""
    ranges = [{"introduced": "1.0.0", "last_affected": "1.2.5"}]
    assert version_in_any_range("1.2.5", ranges) is True
    assert version_in_any_range("1.2.6", ranges) is False


def test_version_in_range_multiple_disjoint():
    """If any range matches, return True."""
    ranges = [
        {"introduced": "1.0.0", "fixed": "1.0.5"},
        {"introduced": "2.0.0", "fixed": "2.0.3"},
    ]
    assert version_in_any_range("1.0.4", ranges) is True
    assert version_in_any_range("2.0.2", ranges) is True
    assert version_in_any_range("1.5.0", ranges) is False


def test_version_in_range_invalid_semver_returns_false():
    """Non-semver version (e.g., 'file:../x') silently returns False."""
    ranges = [{"introduced": "0", "fixed": "4.17.21"}]
    assert version_in_any_range("file:../x", ranges) is False


# ---- severity_from_cvss_score ----

def test_severity_critical():
    assert severity_from_cvss_score(9.8) == "critical"
    assert severity_from_cvss_score(9.0) == "critical"


def test_severity_high():
    assert severity_from_cvss_score(8.5) == "high"
    assert severity_from_cvss_score(7.0) == "high"


def test_severity_medium():
    assert severity_from_cvss_score(6.5) == "medium"
    assert severity_from_cvss_score(4.0) == "medium"


def test_severity_low():
    assert severity_from_cvss_score(3.9) == "low"
    assert severity_from_cvss_score(0.1) == "low"


def test_severity_none_defaults_medium():
    """No CVSS available → default to medium (conservative; not low)."""
    assert severity_from_cvss_score(None) == "medium"


# ---- SupplyChainAuditCheck (integration via stub executor) ----

_FIXTURES = Path(__file__).parent / "fixtures" / "supply_chain"
_STUB_DB = _FIXTURES / "osv_npm_subset.json"
_LOCK_PATH = "/home/u/.npm-global/lib/node_modules/openclaw/package-lock.json"
_CAT_KEY = ("cat", _LOCK_PATH)


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=1,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, *, profile_name="linux", with_npm_root=True):
    profile = materialize_paths(LINUX, "/home/u")
    if not with_npm_root:
        new_paths = {k: v for k, v in profile.paths.items() if k != "npm_root"}
        profile = profile.model_copy(update={"paths": new_paths})
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=Redactor(), ioc_dir=Path("/tmp"),
        profile=profile, log_review_config=None,
    )


def _check() -> SupplyChainAuditCheck:
    return SupplyChainAuditCheck(db_path=_STUB_DB)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def test_check_non_linux_profile_not_applicable():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    assert _run(_check(), ctx) == []
    assert ctx.status.is_not_applicable is True


def test_check_npm_root_missing_not_applicable():
    ctx = _ctx(_RecordingExecutor({}), with_npm_root=False)
    assert _run(_check(), ctx) == []
    assert ctx.status.is_not_applicable is True


def test_check_lock_file_missing_not_applicable():
    """cat exit_code != 0 with no perm-denied stderr → not_applicable
    (NOT skipped — equivalent to 'this host doesn't have OpenClaw npm-installed')."""
    responses = {_CAT_KEY: _runresult(stderr="No such file", exit_code=1)}
    ctx = _ctx(_RecordingExecutor(responses))
    assert _run(_check(), ctx) == []
    assert ctx.status.is_not_applicable is True


def test_check_command_rejected_skipped():
    responses = {_CAT_KEY: _runresult(rejected=True)}
    ctx = _ctx(_RecordingExecutor(responses))
    assert _run(_check(), ctx) == []
    assert ctx.status.is_skipped is True


def test_check_empty_stdout_skipped():
    responses = {_CAT_KEY: _runresult(stdout="")}
    ctx = _ctx(_RecordingExecutor(responses))
    assert _run(_check(), ctx) == []
    assert ctx.status.is_skipped is True


def test_check_invalid_json_skipped():
    responses = {_CAT_KEY: _runresult(stdout="not-json{{{")}
    ctx = _ctx(_RecordingExecutor(responses))
    assert _run(_check(), ctx) == []
    assert ctx.status.is_skipped is True


def test_check_lockfile_v1_zero_findings():
    """Old npm v1 lock has different shape; parser returns []; 0 findings, status=ok."""
    lock = '{"lockfileVersion": 1, "dependencies": {"lodash": {"version": "4.17.15"}}}'
    responses = {_CAT_KEY: _runresult(stdout=lock)}
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(_check(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is False
    assert ctx.status.is_not_applicable is False


def test_check_clean_lock_zero_findings():
    lock = (_FIXTURES / "package-lock-clean.json").read_text()
    responses = {_CAT_KEY: _runresult(stdout=lock)}
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(_check(), ctx)
    assert findings == []


def test_check_vulnerable_lock_emits_findings():
    lock = (_FIXTURES / "package-lock-vulnerable.json").read_text()
    responses = {_CAT_KEY: _runresult(stdout=lock)}
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(_check(), ctx)
    advisory_ids = sorted(f.evidence["advisory_id"] for f in findings
                          if f.evidence.get("advisory_id"))
    assert "GHSA-jf85-cpcp-j695" in advisory_ids
    assert "GHSA-vh95-rmgr-6w4m" in advisory_ids
    assert "GHSA-test-multi-1" in advisory_ids
    sevs = [f.severity for f in findings]
    assert "critical" in sevs
    assert "high" in sevs
    assert "medium" in sevs


def test_check_unparseable_semver_emits_low_audit_finding():
    """A package whose version doesn't parse → 1 low finding noting it,
    so the operator knows we couldn't audit that entry."""
    lock = '{"lockfileVersion": 3, "packages": {"node_modules/x": {"version": "file:../bad"}}}'
    responses = {_CAT_KEY: _runresult(stdout=lock)}
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(_check(), ctx)
    assert len(findings) == 1
    assert findings[0].severity == "low"
    assert "无法解析" in findings[0].title or "unparseable" in findings[0].title.lower()


def test_check_finding_evidence_shape():
    """Verify the evidence dict on a real finding contains all expected keys."""
    lock = (_FIXTURES / "package-lock-vulnerable.json").read_text()
    responses = {_CAT_KEY: _runresult(stdout=lock)}
    findings = _run(_check(), _ctx(_RecordingExecutor(responses)))
    lodash_findings = [f for f in findings
                       if f.evidence.get("package") == "lodash"]
    assert lodash_findings, "expected at least 1 lodash finding"
    f = lodash_findings[0]
    for key in ("package", "version", "advisory_id", "aliases", "fixed_in", "url", "lock_path"):
        assert key in f.evidence, f"missing evidence key: {key}"
    assert f.evidence["package"] == "lodash"
    assert f.evidence["version"] == "4.17.15"
    assert f.threat_refs == ["TI-OSV-NPM-CATALOG"]


def test_check_remediation_includes_fixed_version():
    lock = (_FIXTURES / "package-lock-vulnerable.json").read_text()
    responses = {_CAT_KEY: _runresult(stdout=lock)}
    findings = _run(_check(), _ctx(_RecordingExecutor(responses)))
    lodash_finding = next(
        f for f in findings
        if f.evidence.get("package") == "lodash"
        and f.evidence.get("advisory_id") == "GHSA-jf85-cpcp-j695"
    )
    assert "4.17.21" in lodash_finding.remediation


# ---- _safe_parse_semver defensive edge cases (M2) ----

def test_safe_parse_semver_empty_string():
    """Empty string must return None without raising."""
    assert _safe_parse_semver("") is None


def test_safe_parse_semver_bare_prefix():
    """Bare 'v' with no numeric body is not valid semver → None."""
    assert _safe_parse_semver("v") is None


def test_safe_parse_semver_double_prefix():
    """'vv1.2.3' has two v prefixes; only one stripping pass is supported → None."""
    assert _safe_parse_semver("vv1.2.3") is None


def test_safe_parse_semver_long_garbage():
    """1000-char garbage string must return None without raising."""
    assert _safe_parse_semver("x" * 1000) is None
