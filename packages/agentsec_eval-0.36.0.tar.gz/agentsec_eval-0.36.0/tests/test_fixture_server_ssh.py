import pytest

from agentsec.observability.fixture_server import SshPortForwardFixtureServer
from agentsec.observability.network_observer import FixtureOnlyObserver


class _FakeTransport:
    """Mimics the subset of paramiko.Transport that
    SshPortForwardFixtureServer touches."""

    def __init__(self):
        self.forwarded: tuple | None = None
        self.cancelled: tuple | None = None
        self.closed = False

    def request_port_forward(self, address, port, handler):
        self.forwarded = (address, port, handler)
        # paramiko returns the bound port (echoes the requested one when nonzero,
        # otherwise picks one). 12345 is a sentinel for tests.
        return port or 12345

    def cancel_port_forward(self, address, port):
        self.cancelled = (address, port)

    def is_active(self):
        return not self.closed

    def close(self):
        self.closed = True


@pytest.mark.asyncio
async def test_ssh_forward_lifecycle_uses_transport(tmp_path):
    transport = _FakeTransport()
    server = SshPortForwardFixtureServer(
        root=tmp_path,
        observer=FixtureOnlyObserver(),
        transport=transport,
    )
    async with server.serving() as base_url:
        assert base_url == "http://127.0.0.1:12345"
        assert transport.forwarded is not None
        assert transport.forwarded[0] == "127.0.0.1"
        # remote_port=0 means "let SSH choose"; the fake echoes 12345.
        assert transport.forwarded[1] == 0
        # handler is callable (bridges channel <-> local fixture port)
        assert callable(transport.forwarded[2])
    assert transport.cancelled == ("127.0.0.1", 12345)


@pytest.mark.asyncio
async def test_ssh_forward_cleanup_runs_on_exception(tmp_path):
    transport = _FakeTransport()
    server = SshPortForwardFixtureServer(
        root=tmp_path,
        observer=FixtureOnlyObserver(),
        transport=transport,
    )
    with pytest.raises(RuntimeError):
        async with server.serving():
            raise RuntimeError("boom")
    assert transport.cancelled is not None


@pytest.mark.asyncio
async def test_ssh_forward_honors_explicit_remote_port(tmp_path):
    transport = _FakeTransport()
    server = SshPortForwardFixtureServer(
        root=tmp_path,
        observer=FixtureOnlyObserver(),
        transport=transport,
        remote_port=8443,
    )
    async with server.serving() as base_url:
        assert base_url == "http://127.0.0.1:8443"
        assert transport.forwarded[1] == 8443
