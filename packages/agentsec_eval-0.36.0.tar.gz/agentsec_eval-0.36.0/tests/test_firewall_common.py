"""_firewall_common helper tests (Phase 7e.2)."""

from __future__ import annotations

from pathlib import Path

from agentsec.audit.checks._firewall_common import (
    detect_firewalld,
    detect_iptables,
    detect_nft,
    detect_ufw,
    output_managed_by_firewalld,
    output_managed_by_ufw,
)
from agentsec.audit.checks.base import CheckContext
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult


class _StubExecutor:
    """Returns exit_code=0 for `stat -c %n <found_path>`; exit 1 otherwise."""

    def __init__(self, found_path: str | None):
        self._found_path = found_path

    def run(self, argv, *, role=None):
        argv = list(argv)
        if argv[:3] == ["stat", "-c", "%n"] and argv[3] == self._found_path:
            return RunResult(
                stdout=self._found_path + "\n", stderr="", exit_code=0,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            )
        return RunResult(
            stdout="", stderr="No such file", exit_code=1,
            rejected=False, reject_reason=None, argv=argv,
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        )


class _AllRejectedExecutor:
    def run(self, argv, *, role=None):
        return RunResult(
            stdout="", stderr="", exit_code=0,
            rejected=True, reject_reason="policy", argv=list(argv),
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        )


def _ctx(executor):
    profile = materialize_paths(LINUX, "/home/u")
    return CheckContext(
        executor=executor, redactor=None, ioc_dir=Path("/tmp"),
        profile=profile, log_review_config=None,
    )


# ---- detect_iptables ----

def test_detect_iptables_finds_usr_sbin():
    assert detect_iptables(_ctx(_StubExecutor("/usr/sbin/iptables"))) == "/usr/sbin/iptables"


def test_detect_iptables_finds_sbin():
    assert detect_iptables(_ctx(_StubExecutor("/sbin/iptables"))) == "/sbin/iptables"


def test_detect_iptables_finds_usr_bin():
    assert detect_iptables(_ctx(_StubExecutor("/usr/bin/iptables"))) == "/usr/bin/iptables"


def test_detect_iptables_returns_none_when_absent():
    assert detect_iptables(_ctx(_StubExecutor(None))) is None


def test_detect_iptables_returns_none_when_all_rejected():
    assert detect_iptables(_ctx(_AllRejectedExecutor())) is None


# ---- detect_nft ----

def test_detect_nft_finds_usr_sbin():
    assert detect_nft(_ctx(_StubExecutor("/usr/sbin/nft"))) == "/usr/sbin/nft"


def test_detect_nft_returns_none_when_absent():
    assert detect_nft(_ctx(_StubExecutor(None))) is None


# ---- detect_ufw ----

def test_detect_ufw_finds_usr_sbin():
    assert detect_ufw(_ctx(_StubExecutor("/usr/sbin/ufw"))) == "/usr/sbin/ufw"


def test_detect_ufw_returns_none_when_absent():
    assert detect_ufw(_ctx(_StubExecutor(None))) is None


# ---- output_managed_by_ufw ----

def test_output_managed_by_ufw_iptables_self_chain():
    s = "-N ufw-before-input\n-A INPUT -j ACCEPT\n"
    assert output_managed_by_ufw(s, backend="iptables") is True


def test_output_managed_by_ufw_iptables_hook_line():
    s = "-A INPUT -j ufw-before-input\n"
    assert output_managed_by_ufw(s, backend="iptables") is True


def test_output_managed_by_ufw_iptables_comment_tag():
    s = '-A INPUT -m comment --comment "[ufw allow ssh]"\n'
    assert output_managed_by_ufw(s, backend="iptables") is True


def test_output_managed_by_ufw_iptables_clean():
    s = "-P INPUT DROP\n-A INPUT -j ACCEPT\n"
    assert output_managed_by_ufw(s, backend="iptables") is False


def test_output_managed_by_ufw_nftables_table_name():
    s = '{"nftables": [{"table": {"family": "inet", "name": "ufw"}}]}'
    assert output_managed_by_ufw(s, backend="nftables") is True


def test_output_managed_by_ufw_nftables_clean():
    s = '{"nftables": [{"table": {"family": "inet", "name": "filter"}}]}'
    assert output_managed_by_ufw(s, backend="nftables") is False


# ---- detect_firewalld ----

def test_detect_firewalld_finds_usr_bin():
    assert detect_firewalld(_ctx(_StubExecutor("/usr/bin/firewall-cmd"))) == "/usr/bin/firewall-cmd"


def test_detect_firewalld_finds_bin():
    assert detect_firewalld(_ctx(_StubExecutor("/bin/firewall-cmd"))) == "/bin/firewall-cmd"


def test_detect_firewalld_returns_none_when_absent():
    assert detect_firewalld(_ctx(_StubExecutor(None))) is None


def test_detect_firewalld_returns_none_when_all_rejected():
    assert detect_firewalld(_ctx(_AllRejectedExecutor())) is None


# ---- output_managed_by_firewalld ----

def test_output_managed_by_firewalld_iptables_in_zone():
    s = "-P INPUT ACCEPT\n-N IN_public\n-N IN_public_allow\n"
    assert output_managed_by_firewalld(s, backend="iptables") is True


def test_output_managed_by_firewalld_iptables_fwdi():
    s = "-P FORWARD ACCEPT\n-N FWDI_public\n"
    assert output_managed_by_firewalld(s, backend="iptables") is True


def test_output_managed_by_firewalld_iptables_clean():
    s = "-P INPUT DROP\n-A INPUT -j ACCEPT\n"
    assert output_managed_by_firewalld(s, backend="iptables") is False


def test_output_managed_by_firewalld_nftables_table():
    s = '{"nftables": [{"table": {"family": "inet", "name": "firewalld"}}]}'
    assert output_managed_by_firewalld(s, backend="nftables") is True


def test_output_managed_by_firewalld_nftables_clean():
    s = '{"nftables": [{"table": {"family": "inet", "name": "filter"}}]}'
    assert output_managed_by_firewalld(s, backend="nftables") is False


def test_output_managed_by_firewalld_unknown_backend_raises():
    import pytest
    with pytest.raises(ValueError):
        output_managed_by_firewalld("", backend="bogus")
