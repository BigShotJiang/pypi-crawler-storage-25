"""UfwAuditCheck unit tests (Phase 7e.2)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.ufw_audit import UfwAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "firewall"
_BIN = "/usr/sbin/ufw"
_UFW_STATUS = ("ufw", "status", "verbose")


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=1, rejected=False,
                reject_reason=None, argv=argv, command_sha256="0" * 64,
                duration_ms=0.0, bytes_out=0,
            ),
        )


def _runresult(stdout="", stderr="", exit_code=0, rejected=False):
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=None, ioc_dir=Path("/tmp"),
                        profile=profile, log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found_path):
    out = {}
    for c in ("/usr/sbin/ufw", "/sbin/ufw", "/usr/bin/ufw"):
        if c == found_path:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c + "\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_non_linux_profile_not_applicable():
    findings = _run(UfwAuditCheck(), _ctx(_RecordingExecutor({}), profile_name="macos"))
    assert findings == []


def test_ufw_not_installed_not_applicable():
    findings = _run(UfwAuditCheck(), _ctx(_RecordingExecutor(_detect_responses(None))))
    assert findings == []


def test_compliant_active_deny_zero_findings():
    text = (_FIXTURES / "ufw_active_default_deny.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_UFW_STATUS] = _runresult(stdout=text)
    findings = _run(UfwAuditCheck(), _ctx(_RecordingExecutor(responses)))
    assert findings == []


def test_inactive_emits_one_critical():
    text = (_FIXTURES / "ufw_inactive.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_UFW_STATUS] = _runresult(stdout=text)
    findings = _run(UfwAuditCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert findings[0].severity == "critical"
    assert "未启用" in findings[0].title or "inactive" in findings[0].title.lower()


def test_active_default_allow_emits_critical_and_high():
    text = (_FIXTURES / "ufw_active_default_allow.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_UFW_STATUS] = _runresult(stdout=text)
    findings = _run(UfwAuditCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 2
    severities = sorted(f.severity for f in findings)
    assert severities == ["critical", "high"]


def test_command_rejected_skipped():
    responses = _detect_responses(_BIN)
    responses[_UFW_STATUS] = _runresult(rejected=True)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(UfwAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True


def test_permission_denied_skipped():
    responses = _detect_responses(_BIN)
    responses[_UFW_STATUS] = _runresult(stderr="ERROR: You need to be root", exit_code=1)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(UfwAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "root" in (ctx.status.skip_reason or "").lower() or \
           "sudoers" in (ctx.status.skip_reason or "").lower()


def test_empty_stdout_skipped():
    responses = _detect_responses(_BIN)
    responses[_UFW_STATUS] = _runresult(stdout="")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(UfwAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True


def test_active_but_default_line_missing_skipped():
    """Status: active without a parseable Default line → skipped, not silently compliant."""
    responses = _detect_responses(_BIN)
    responses[_UFW_STATUS] = _runresult(stdout="Status: active\nLogging: on (low)\n")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(UfwAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "Default" in (ctx.status.skip_reason or "") or \
           "默认策略" in (ctx.status.skip_reason or "")
