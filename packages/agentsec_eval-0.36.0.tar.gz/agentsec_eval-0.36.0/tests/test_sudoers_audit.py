"""Unit tests for SudoersAuditCheck (Phase 7e)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.sudoers_audit import SudoersAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult


class _RecordingExecutor:
    """Returns a per-argv canned response. argv keyed via tuple(argv)."""
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        key = tuple(argv)
        if key in self._responses:
            return self._responses[key]
        return RunResult(
            stdout="", stderr="", exit_code=0,
            rejected=False, reject_reason=None, argv=argv,
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        )


def _runresult(stdout="", exit_code=0) -> RunResult:
    return RunResult(
        stdout=stdout, stderr="", exit_code=exit_code,
        rejected=False, reject_reason=None, argv=[],
        command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


CLEAN_SUDOERS = """\
# Cleanup sudoers
root  ALL=(ALL:ALL) ALL
%admin ALL=(ALL) NOPASSWD: /usr/bin/systemctl restart nginx
"""

DIRTY_SUDOERS = """\
# Risky entries
root  ALL=(ALL:ALL) ALL
deploy ALL=(ALL) NOPASSWD: ALL
%wheel ALL=(ALL:ALL) ALL
"""


def test_clean_sudoers_emits_only_root_baseline_finding():
    """root  ALL=(ALL:ALL) ALL fires the world_writable_runas pattern,
    plus admin's command-scoped NOPASSWD does NOT fire (pattern requires
    NOPASSWD ALL, not NOPASSWD <command>)."""
    responses = {
        ("cat", "/etc/sudoers"): _runresult(stdout=CLEAN_SUDOERS),
        ("find", "/etc/sudoers.d", "-maxdepth", "1", "-type", "f"):
            _runresult(stdout=""),
    }
    executor = _RecordingExecutor(responses)
    findings = _run(SudoersAuditCheck(), _ctx(executor))
    titles = [f.title for f in findings]
    # `(ALL:ALL) ALL` line matches world_writable_runas pattern (root entry).
    assert any("world_writable_runas" in t for t in titles)
    # admin's command-scoped NOPASSWD must NOT match nopasswd_all.
    assert not any("nopasswd_all" in t for t in titles)


def test_dirty_sudoers_emits_critical_findings():
    responses = {
        ("cat", "/etc/sudoers"): _runresult(stdout=DIRTY_SUDOERS),
        ("find", "/etc/sudoers.d", "-maxdepth", "1", "-type", "f"):
            _runresult(stdout=""),
    }
    executor = _RecordingExecutor(responses)
    findings = _run(SudoersAuditCheck(), _ctx(executor))
    severities = [f.severity for f in findings]
    assert "critical" in severities
    titles = [f.title for f in findings]
    assert any("nopasswd_all" in t for t in titles)


def test_sudoers_d_drop_in_files_scanned():
    """When find returns drop-in files, each is cat'd + scanned."""
    responses = {
        ("cat", "/etc/sudoers"): _runresult(stdout="# main empty\n"),
        ("find", "/etc/sudoers.d", "-maxdepth", "1", "-type", "f"):
            _runresult(stdout="/etc/sudoers.d/deploy\n"),
        ("cat", "/etc/sudoers.d/deploy"): _runresult(
            stdout="deploy ALL=(ALL) NOPASSWD: ALL\n",
        ),
    }
    executor = _RecordingExecutor(responses)
    findings = _run(SudoersAuditCheck(), _ctx(executor))
    titles = [f.title for f in findings]
    assert any("nopasswd_all" in t for t in titles)
    # Verify the evidence carries the drop-in file path.
    nopasswd = [f for f in findings if "nopasswd_all" in f.title]
    assert any(
        f.evidence.get("file") == "/etc/sudoers.d/deploy" for f in nopasswd
    )


def test_macos_skips():
    executor = _RecordingExecutor({})
    ctx = _ctx(executor, profile_name="macos")
    findings = _run(SudoersAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
