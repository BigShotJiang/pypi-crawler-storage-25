"""GoSupplyChainAuditCheck — _safe_parse_go_version defensive edge cases (Phase 7d.cleanup M2)."""

from __future__ import annotations

from agentsec.audit.checks.go_supply_chain_audit import _safe_parse_go_version

# ---- _safe_parse_go_version defensive edge cases (M2) ----

def test_safe_parse_go_version_empty_string():
    """Empty string must return None without raising."""
    assert _safe_parse_go_version("") is None


def test_safe_parse_go_version_bare_prefix():
    """Bare 'v' — after stripping 'v' produces '' which is invalid semver → None."""
    assert _safe_parse_go_version("v") is None


def test_safe_parse_go_version_double_prefix():
    """'vv1.2.3' — after stripping one 'v' produces 'v1.2.3' which is not valid semver → None."""
    assert _safe_parse_go_version("vv1.2.3") is None


def test_safe_parse_go_version_long_garbage():
    """1000-char garbage string must return None without raising."""
    assert _safe_parse_go_version("x" * 1000) is None
