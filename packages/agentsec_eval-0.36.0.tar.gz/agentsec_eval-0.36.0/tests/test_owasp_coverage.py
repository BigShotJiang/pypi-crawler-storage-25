from agentsec.reports.owasp_coverage import (
    AGENTIC_THREATS,
    LLM_TOP10_2025,
    MCP_THREATS,
    build_coverage_matrix,
)
from agentsec.tests.models import Severity, TestCase, TestResult


def _case(test_id: str, refs: list[str]) -> TestCase:
    return TestCase(
        id=test_id, category="x", description="d",
        attack="a", expected_behavior="refusal",
        severity=Severity.medium, owasp_refs=refs,
    )


def _result(test_id: str, status: str) -> TestResult:
    return TestResult(
        test_id=test_id, category="x", severity=Severity.medium,
        status=status, observations=[], verdict=None,
    )


def test_canonical_lists_are_complete():
    assert LLM_TOP10_2025[0].id == "LLM01:2025"
    assert LLM_TOP10_2025[-1].id == "LLM10:2025"
    assert len(LLM_TOP10_2025) == 10
    assert AGENTIC_THREATS[0].id == "AGENTIC-T1"
    assert AGENTIC_THREATS[-1].id == "AGENTIC-T17"
    assert len(AGENTIC_THREATS) == 17


def test_matrix_aggregates_by_framework():
    cases = [
        _case("c1", ["LLM01:2025"]),
        _case("c2", ["LLM01:2025"]),
        _case("c3", ["LLM06:2025", "AGENTIC-T2"]),
    ]
    results = [
        _result("c1", "passed"),
        _result("c2", "failed"),
        _result("c3", "passed"),
    ]
    matrix = build_coverage_matrix(cases, results)

    llm01 = matrix.row("LLM01:2025")
    assert llm01.total == 2 and llm01.passed == 1 and llm01.failed == 1

    llm06 = matrix.row("LLM06:2025")
    assert llm06.total == 1 and llm06.passed == 1

    agentic_t2 = matrix.row("AGENTIC-T2")
    assert agentic_t2.total == 1 and agentic_t2.passed == 1


def test_matrix_includes_zero_rows_for_missing_categories():
    """Even when no case is tagged for an LLM Top 10 entry, the matrix
    still emits a row with total=0 — the coverage *gap* is the headline."""
    matrix = build_coverage_matrix([], [])
    llm10 = matrix.row("LLM10:2025")
    assert llm10.total == 0 and llm10.passed == 0


def test_matrix_only_counts_runs_for_tagged_cases():
    """A result for a case without owasp_refs doesn't pollute any row."""
    cases = [_case("c1", [])]
    results = [_result("c1", "passed")]
    matrix = build_coverage_matrix(cases, results)
    for row in matrix.llm_rows():
        assert row.total == 0


def test_matrix_handles_skipped_and_error_status():
    cases = [
        _case("c1", ["LLM01:2025"]),
        _case("c2", ["LLM01:2025"]),
    ]
    results = [
        _result("c1", "skipped"),
        _result("c2", "error"),
    ]
    row = build_coverage_matrix(cases, results).row("LLM01:2025")
    assert row.total == 2
    assert row.passed == 0 and row.failed == 0
    assert row.skipped == 1 and row.errored == 1


def test_mcp_threats_list_has_ten_entries():
    assert len(MCP_THREATS) == 10
    ids = [entry.id for entry in MCP_THREATS]
    assert ids == [f"MCP{i}" for i in range(1, 11)]
    titles = [entry.title for entry in MCP_THREATS]
    assert all(titles)  # no empty titles


def test_matrix_includes_mcp_rows():
    case = _case("c1", ["MCP1", "LLM01:2025"])
    matrix = build_coverage_matrix([case], results=[])
    mcp_rows = matrix.mcp_rows()
    assert len(mcp_rows) == 10
    by_id = {r.id: r for r in mcp_rows}
    assert by_id["MCP1"].total == 1
    assert by_id["MCP2"].total == 0  # zero-fill preserved
