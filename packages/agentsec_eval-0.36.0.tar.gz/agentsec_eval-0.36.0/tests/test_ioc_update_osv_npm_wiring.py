"""ioc-update CLI must invoke OsvNpmFetcher and write proposed-osv_npm.json (Phase 7d)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from agentsec.audit.ioc_update.cli import _run_osv_npm
from agentsec.audit.ioc_update.fetchers.base import FetcherContext, FetchResult


@pytest.mark.asyncio
async def test_run_osv_npm_writes_proposed_file(tmp_path: Path):
    """_run_osv_npm should invoke the fetcher and dump records as JSON."""
    fake_records = [
        {"id": "GHSA-x", "package": "p", "ranges": [{"introduced": "0", "fixed": "1.0.0"}],
         "severity": "high", "summary": "x", "url": "u", "aliases": []}
    ]
    with patch(
        "agentsec.audit.ioc_update.cli.OsvNpmFetcher"
    ) as MockFetcher:
        async def fake_run(ctx, entries):
            return {"_osv_npm_full": FetchResult.ok(records=fake_records)}
        MockFetcher.return_value.run.side_effect = fake_run

        ctx = FetcherContext(offline=False)
        out_path = await _run_osv_npm(ctx, tmp_path)

    assert out_path == tmp_path / "proposed-osv_npm.json"
    assert out_path.exists()
    payload = json.loads(out_path.read_text())
    assert payload == fake_records


@pytest.mark.asyncio
async def test_run_osv_npm_handles_degraded_fetch(tmp_path: Path):
    """If the fetcher returns a degraded result, we write [] and surface the issue."""
    with patch(
        "agentsec.audit.ioc_update.cli.OsvNpmFetcher"
    ) as MockFetcher:
        async def fake_run(ctx, entries):
            return {"_osv_npm_full": FetchResult.from_degraded(
                reason="HTTP 503", fetcher="osv_npm",
            )}
        MockFetcher.return_value.run.side_effect = fake_run

        ctx = FetcherContext(offline=False)
        out_path = await _run_osv_npm(ctx, tmp_path)

    assert out_path is None  # signals degraded; no file written
