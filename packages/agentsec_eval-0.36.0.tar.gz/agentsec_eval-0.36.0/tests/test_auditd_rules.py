"""Unit tests for AuditdRulesCheck (Phase 7e.1)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.auditd_rules import AuditdRulesCheck
from agentsec.audit.checks.base import CheckContext
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult

FIXTURES = Path(__file__).parent / "fixtures" / "linux_hardening"


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=0,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _rr(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name not in ("linux", "linux_user_mode"):
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def test_compliant_rule_set_no_findings():
    compliant = (FIXTURES / "auditctl_l_compliant.txt").read_text()
    responses = {
        ("auditctl", "-s"): _rr(stdout="enabled 1\nfailure 1\n"),
        ("auditctl", "-l"): _rr(stdout=compliant),
    }
    findings = _run(AuditdRulesCheck(), _ctx(_RecordingExecutor(responses)))
    assert findings == []


def test_partial_rules_emits_one_finding_per_missing():
    partial = (FIXTURES / "auditctl_l_partial.txt").read_text()
    responses = {
        ("auditctl", "-s"): _rr(stdout="enabled 1\nfailure 1\n"),
        ("auditctl", "-l"): _rr(stdout=partial),
    }
    findings = _run(AuditdRulesCheck(), _ctx(_RecordingExecutor(responses)))
    # Missing: watch_sudoers (high), watch_sudoersd (high), syscall_execve (medium)
    assert len(findings) == 3
    severities = sorted(f.severity for f in findings)
    assert severities == ["high", "high", "medium"]


def test_disabled_emits_high_finding_then_continues():
    """auditctl -s 显示 enabled=0 → 1 high finding；规则比对继续。"""
    compliant = (FIXTURES / "auditctl_l_compliant.txt").read_text()
    responses = {
        ("auditctl", "-s"): _rr(stdout="enabled 0\nfailure 1\n"),
        ("auditctl", "-l"): _rr(stdout=compliant),
    }
    findings = _run(AuditdRulesCheck(), _ctx(_RecordingExecutor(responses)))
    # 1 high disabled finding + 0 missing-rule（合规规则集）
    assert len(findings) == 1
    assert findings[0].severity == "high"
    assert "enabled" in findings[0].title


def test_command_not_found_marks_not_applicable():
    """auditctl 未装：exit 127 + stderr 含 'command not found' → not_applicable。"""
    responses = {
        ("auditctl", "-s"): _rr(
            stderr="bash: auditctl: command not found", exit_code=127,
        ),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(AuditdRulesCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "未安装" in (ctx.status.not_applicable_reason or "")


def test_status_failed_for_other_reason_marks_skipped():
    """非 127 退出码 → skipped（短暂故障，非未装）。"""
    responses = {
        ("auditctl", "-s"): _rr(stderr="permission denied", exit_code=1),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(AuditdRulesCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
    assert ctx.status.is_not_applicable is False


def test_skips_on_macos_profile():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(AuditdRulesCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_status_rejected_marks_skipped():
    responses = {("auditctl", "-s"): _rr(rejected=True)}
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(AuditdRulesCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_empty_rules_emits_all_baseline_missing():
    """auditctl -l 空 → 所有 8 条 baseline 缺失。"""
    responses = {
        ("auditctl", "-s"): _rr(stdout="enabled 1\n"),
        ("auditctl", "-l"): _rr(stdout=""),
    }
    findings = _run(AuditdRulesCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 8


def test_disabled_plus_partial_emits_combined_findings():
    """enabled=0 + 缺三条规则 → 1 (disabled high) + 3 (missing) = 4 findings。"""
    partial = (FIXTURES / "auditctl_l_partial.txt").read_text()
    responses = {
        ("auditctl", "-s"): _rr(stdout="enabled 0\n"),
        ("auditctl", "-l"): _rr(stdout=partial),
    }
    findings = _run(AuditdRulesCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 4
    severities = sorted(f.severity for f in findings)
    # 1 high (disabled) + 2 high (sudoers/sudoersd) + 1 medium (execve)
    assert severities == ["high", "high", "high", "medium"]


def test_sudoers_missing_but_sudoersd_present_emits_finding():
    """缺 sudoers 但有 sudoers.d 时（前缀子串碰撞场景）必须 emit watch_sudoers finding。"""
    only_sudoersd = (
        "-w /etc/passwd -p wa -k identity\n"
        "-w /etc/shadow -p wa -k identity\n"
        "-w /etc/group -p wa -k identity\n"
        "-w /etc/sudoers.d -p wa -k scope\n"
        "-w /var/log/lastlog -p wa -k logins\n"
        "-w /var/run/utmp -p wa -k session\n"
        "-a always,exit -F arch=b64 -S execve -k execve\n"
    )
    responses = {
        ("auditctl", "-s"): _rr(stdout="enabled 1\n"),
        ("auditctl", "-l"): _rr(stdout=only_sudoersd),
    }
    findings = _run(AuditdRulesCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert findings[0].evidence["rule_id"] == "watch_sudoers"
    assert findings[0].severity == "high"
