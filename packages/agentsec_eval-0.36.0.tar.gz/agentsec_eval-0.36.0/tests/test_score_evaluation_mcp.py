"""score_evaluation accepts mcp_score (Phase 7c.6)."""

from pathlib import Path

from agentsec.config import (
    AuthorizationConfig,
    OpenClawTargetConfig,
    OutputConfig,
    ScoringConfig,
)
from agentsec.mcp_harness.scoring import McpScore
from agentsec.scoring import CoverageTriple, score_evaluation


def _empty_coverage() -> CoverageTriple:
    return CoverageTriple(
        planned=0, executed=0, scored=0, error=0,
        execution_coverage=0.0, verdict_coverage=0.0, error_rate=None,
    )


def test_score_evaluation_accepts_mcp_score():
    """score_evaluation passes mcp_score through to EvaluationScore."""
    mcp = McpScore(
        score=75.0, categories=[],
        coverage=_empty_coverage(), note=None,
    )
    cfg = OpenClawTargetConfig.model_construct(
        name="t",
        remote=None, server_audit=None, mcp_real=None,
        output=OutputConfig(dir=Path("/tmp/x")),
        authorization=AuthorizationConfig(),
        scoring=ScoringConfig(),
    )
    score = score_evaluation(
        remote_results=[],
        server_findings=[],
        mcp_score=mcp,
        planned_count=0,
        config=cfg,
    )
    assert score.mcp is mcp
    assert score.combined.weight_mcp_used == 0.0


def test_score_evaluation_mcp_with_weight():
    mcp = McpScore(
        score=80.0, categories=[],
        coverage=_empty_coverage(), note=None,
    )
    cfg = OpenClawTargetConfig.model_construct(
        name="t",
        remote=None, server_audit=None, mcp_real=None,
        output=OutputConfig(dir=Path("/tmp/x")),
        authorization=AuthorizationConfig(),
        scoring=ScoringConfig(
            weight_remote=0.0, weight_server=0.0, weight_mcp=1.0,
        ),
    )
    score = score_evaluation(
        remote_results=[], server_findings=[],
        mcp_score=mcp,
        planned_count=0, config=cfg,
    )
    assert score.combined.score == 80.0
    assert score.combined.weight_mcp_used == 1.0


def test_score_evaluation_mcp_none_default():
    cfg = OpenClawTargetConfig.model_construct(
        name="t",
        remote=None, server_audit=None, mcp_real=None,
        output=OutputConfig(dir=Path("/tmp/x")),
        authorization=AuthorizationConfig(),
        scoring=ScoringConfig(),
    )
    score = score_evaluation(
        remote_results=[], server_findings=[],
        planned_count=0, config=cfg,
    )
    assert score.mcp is None
    assert score.combined.weight_mcp_used == 0.0
