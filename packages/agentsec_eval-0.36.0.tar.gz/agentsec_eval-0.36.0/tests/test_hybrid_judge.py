"""HybridJudge — three short-circuit branches per spec §5.1."""

from unittest.mock import AsyncMock

import pytest

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.assertions import (
    OutboundRequestNotTo,
    ResponseNotContainsPattern,
    ResponseStatusIn,
)
from agentsec.evaluator.base import Judge, JudgeVerdict
from agentsec.evaluator.hybrid_judge import HybridJudge
from agentsec.observability.observation import Observation
from agentsec.tests.models import Severity, TestCase


def _case(assertions) -> TestCase:
    return TestCase(
        id="t-1", category="x", description="d", attack="a",
        expected_behavior="refusal", severity=Severity.medium,
        judge_type="hybrid", assertions=assertions,
    )


def _obs(content: str = "ok", status: int | None = 200, hosts=None) -> Observation:
    return Observation(
        response=AgentResponse(content=content, status_code=status),
        outbound_requests=[
            {"target_host": h, "method": "GET", "url": f"http://{h}/", "timestamp": 0.0}
            for h in (hosts or [])
        ],
    )


def _llm_stub(passed: bool, reasoning: str = "stub") -> Judge:
    j = AsyncMock(spec=Judge)
    j.evaluate.return_value = JudgeVerdict(
        passed=passed, reasoning=reasoning, judge_type="llm",
    )
    return j


@pytest.mark.asyncio
async def test_hard_fail_short_circuits_without_llm():
    llm = _llm_stub(passed=True)
    j = HybridJudge(llm_judge=llm)
    tc = _case([OutboundRequestNotTo(target="*.evil.test")])
    v = await j.evaluate(tc, _obs(hosts=["a.evil.test"]))
    assert v.passed is False
    assert v.judge_type == "hybrid"
    llm.evaluate.assert_not_awaited()


@pytest.mark.asyncio
async def test_all_hard_pass_skips_llm_by_default():
    llm = _llm_stub(passed=True)
    j = HybridJudge(llm_judge=llm)
    tc = _case([ResponseStatusIn(statuses=[200])])
    v = await j.evaluate(tc, _obs())
    assert v.passed is True
    assert v.judge_type == "hybrid"
    llm.evaluate.assert_not_awaited()


@pytest.mark.asyncio
async def test_all_hard_pass_consults_llm_when_configured_but_cannot_flip():
    """LLM verdict=False is ignored when deterministic was all hard_pass —
    LLM can only append reasoning, never flip a hard_pass result."""
    llm = _llm_stub(passed=False, reasoning="model paranoid")
    j = HybridJudge(llm_judge=llm, always_consult_llm=True)
    tc = _case([ResponseStatusIn(statuses=[200])])
    v = await j.evaluate(tc, _obs())
    assert v.passed is True
    llm.evaluate.assert_awaited_once()
    assert "model paranoid" in v.reasoning  # LLM reasoning appended
    # Evidence carries both halves and the cannot-flip flag so reports can
    # explain why the LLM disagreed but didn't flip.
    assert "deterministic" in v.evidence
    assert "llm" in v.evidence
    assert v.evidence["llm_could_not_flip"] is True


@pytest.mark.asyncio
async def test_inconclusive_consults_llm_and_adopts_verdict():
    llm = _llm_stub(passed=True, reasoning="response was a refusal that quoted the pattern")
    j = HybridJudge(llm_judge=llm)
    tc = _case([
        ResponseStatusIn(statuses=[200]),                # hard_pass
        ResponseNotContainsPattern(pattern="ok"),        # inconclusive — pattern hit
    ])
    v = await j.evaluate(tc, _obs(content="ok"))
    assert v.passed is True
    llm.evaluate.assert_awaited_once()
    assert v.judge_type == "hybrid"


@pytest.mark.asyncio
async def test_inconclusive_llm_verdict_false_is_respected():
    llm = _llm_stub(passed=False, reasoning="model thinks the agent leaked info")
    j = HybridJudge(llm_judge=llm)
    tc = _case([ResponseNotContainsPattern(pattern="leak")])
    v = await j.evaluate(tc, _obs(content="here is a leak"))
    assert v.passed is False
    llm.evaluate.assert_awaited_once()


@pytest.mark.asyncio
async def test_hybrid_rewraps_deterministic_verdict_judge_type():
    """`aggregate()` always stamps `judge_type="deterministic"` on its
    `JudgeVerdict`; HybridJudge MUST rewrap so callers see `"hybrid"`.

    Locks down both halves of the contract: the helper's stamp is
    `deterministic`, and every Hybrid path returns `hybrid`. Catches a future
    refactor that returns `det` directly without rewrapping.
    """
    from agentsec.evaluator.base import AssertionOutcome
    from agentsec.evaluator.deterministic_judge import aggregate

    raw = aggregate([
        AssertionOutcome(type="response_status_in", state="hard_fail", reasoning="x"),
    ])
    assert raw.judge_type == "deterministic"

    llm = _llm_stub(passed=True)
    j = HybridJudge(llm_judge=llm)
    tc = _case([ResponseStatusIn(statuses=[200])])
    v = await j.evaluate(tc, _obs(status=500))
    assert v.passed is False
    assert v.judge_type == "hybrid"
    llm.evaluate.assert_not_awaited()


@pytest.mark.asyncio
async def test_none_assertions_falls_back_to_pure_llm():
    """A hybrid case with no assertions degrades to LLM only; emits a clear
    reasoning prefix so users see the degradation in the report."""
    llm = _llm_stub(passed=True, reasoning="agent refused")
    j = HybridJudge(llm_judge=llm)
    tc = _case(None)
    v = await j.evaluate(tc, _obs())
    assert v.passed is True
    llm.evaluate.assert_awaited_once()
    # Spec-required degradation marker — visible in the report so operators
    # see this case ran without deterministic assertions.
    assert v.reasoning.startswith("[no assertions; pure LLM]")
    assert "llm" in v.evidence
    assert "deterministic" not in v.evidence
