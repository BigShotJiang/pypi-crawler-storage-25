"""Cross-file invariants for the Phase 7c MCP test suites.

Validates that the 5 mcp_*.yaml files together honour the contract in
docs/superpowers/specs/2026-05-12-phase-7c-mcp-top10-design.md:

- Total case count is exactly 80.
- Per-file case counts match the design.
- Every case has at least one MCP[1-10] entry in owasp_refs.
- Every MCP[1-10] id is tagged on at least 6 cases (matches CI floor).
- Global ID uniqueness across every YAML file under test_suites/.
- judge_hint contains contiguous 'Pass if' and 'Fail if' substrings.
- category matches the file stem.
"""
from __future__ import annotations

import re
from collections import Counter
from pathlib import Path

import pytest

from agentsec.tests.loader import load_test_suite

ROOT = Path(__file__).resolve().parents[1]
SUITE_DIR = ROOT / "test_suites"

EXPECTED_PER_FILE = {
    "mcp_injection.yaml":           28,
    "mcp_cross_server.yaml":        16,
    "mcp_resource_smuggling.yaml":  16,
    "mcp_capability_abuse.yaml":    14,
    "mcp_supply_chain.yaml":         6,
}
EXPECTED_TOTAL = sum(EXPECTED_PER_FILE.values())  # 80

# CI floor — matches scripts/check_owasp_coverage.py MCP_FLOOR after
# Task 10 lands. Per-id over-counts (via cross-refs) are tolerated.
MIN_PER_MCP_ID = 6

MCP_ID_RE = re.compile(r"^MCP([1-9]|10)$")


@pytest.fixture(scope="module")
def mcp_cases():
    cases = []
    for fname in EXPECTED_PER_FILE:
        cases.extend(load_test_suite(SUITE_DIR / fname))
    return cases


def test_total_case_count(mcp_cases):
    assert len(mcp_cases) == EXPECTED_TOTAL


def test_per_file_case_count():
    for fname, expected in EXPECTED_PER_FILE.items():
        cases = list(load_test_suite(SUITE_DIR / fname))
        assert len(cases) == expected, (
            f"{fname}: expected {expected}, got {len(cases)}"
        )


def test_every_case_has_mcp_ref(mcp_cases):
    offenders = [
        c.id for c in mcp_cases
        if not any(MCP_ID_RE.match(r) for r in c.owasp_refs)
    ]
    assert not offenders, f"cases missing MCP[1-10] ref: {offenders}"


def test_each_mcp_id_meets_floor(mcp_cases):
    counts: Counter[str] = Counter()
    for c in mcp_cases:
        for ref in c.owasp_refs:
            if MCP_ID_RE.match(ref):
                counts[ref] += 1
    underspec = {
        f"MCP{i}": counts.get(f"MCP{i}", 0)
        for i in range(1, 11)
        if counts.get(f"MCP{i}", 0) < MIN_PER_MCP_ID
    }
    assert not underspec, (
        f"MCP ids below floor {MIN_PER_MCP_ID}: {underspec}"
    )


def test_category_matches_file_stem():
    for fname in EXPECTED_PER_FILE:
        stem = fname.removesuffix(".yaml")
        for c in load_test_suite(SUITE_DIR / fname):
            assert c.category == stem, (
                f"{c.id} in {fname}: expected category={stem}, got {c.category}"
            )


def test_judge_hint_pass_fail_branches(mcp_cases):
    bad = [
        c.id for c in mcp_cases
        if "Pass if" not in (c.judge_hint or "")
        or "Fail if" not in (c.judge_hint or "")
    ]
    assert not bad, (
        f"cases missing contiguous 'Pass if' / 'Fail if' in judge_hint: {bad}"
    )


def test_ids_globally_unique_across_all_suites():
    """Walks every YAML directly under test_suites/ (mirroring the
    OWASP coverage script's traversal pattern) and asserts no id
    collides across files."""
    seen: dict[str, str] = {}
    yaml_dirs = sorted(
        {p.parent for p in SUITE_DIR.rglob("*.yaml")}
        | {p.parent for p in SUITE_DIR.rglob("*.yml")}
    )
    for d in yaml_dirs:
        for case in load_test_suite(d):
            if case.id in seen:
                pytest.fail(
                    f"duplicate id {case.id!r}: "
                    f"first in {seen[case.id]}, again in {d}"
                )
            seen[case.id] = str(d)
