"""Unit tests for ServerAuditConfig.maven_lock_paths validator (Phase 7d.4)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentsec.config import ServerAuditConfig


def _config(**overrides) -> dict:
    """Minimal valid ServerAuditConfig dict."""
    return {
        "host": "test.example",
        "user": "ubuntu",
        "key": "/home/ubuntu/.ssh/id_rsa",
        **overrides,
    }


def test_empty_maven_lock_paths_is_valid() -> None:
    cfg = ServerAuditConfig.model_validate(_config())
    assert cfg.maven_lock_paths == []


def test_accepts_valid_paths() -> None:
    cfg = ServerAuditConfig.model_validate(_config(
        maven_lock_paths=[
            "/opt/myapp/mvn-deps.txt",
            "~/projects/foo/dependency-list.txt",
            "/srv/app/deps.list",
            "/var/build/maven-list.txt",
        ]
    ))
    assert len(cfg.maven_lock_paths) == 4


def test_rejects_relative_path() -> None:
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig.model_validate(_config(
            maven_lock_paths=["mvn-deps.txt"]
        ))


def test_rejects_shell_metachar() -> None:
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig.model_validate(_config(
            maven_lock_paths=["/opt/app;rm /mvn-deps.txt"]
        ))


def test_rejects_unrecognized_extension() -> None:
    with pytest.raises(ValidationError, match="basename must end with"):
        ServerAuditConfig.model_validate(_config(
            maven_lock_paths=["/opt/myapp/pom.xml"]
        ))
