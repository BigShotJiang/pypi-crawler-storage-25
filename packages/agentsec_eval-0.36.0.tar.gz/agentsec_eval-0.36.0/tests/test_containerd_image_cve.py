"""ContainerdImageCveCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.containerd_image_cve import ContainerdImageCveCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"
_NERDCTL_BIN = "/usr/local/bin/nerdctl"
_CTR_BIN = "/usr/bin/ctr"
_SOCKET = "/run/containerd/containerd.sock"
_DOCKER_BIN = "/usr/bin/docker"
_DOCKER_SOCKET = "/var/run/docker.sock"


def _runresult(stdout="", stderr="", exit_code=0, rejected=False):
    return RunResult(stdout=stdout, stderr=stderr, exit_code=exit_code,
                     rejected=rejected, reject_reason="policy" if rejected else None,
                     argv=[], command_sha256="0"*64, duration_ms=0.0,
                     bytes_out=len(stdout.encode()))


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []
    def run(self, argv, *, role=None):
        self.calls.append(list(argv))
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=list(argv),
                      command_sha256="0"*64, duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_responses(present):
    all_paths = [
        "/usr/bin/docker", "/usr/local/bin/docker", "/opt/homebrew/bin/docker",
        "/usr/local/bin/nerdctl", "/usr/bin/nerdctl",
        "/usr/bin/ctr", "/usr/local/bin/ctr",
        "/run/containerd/containerd.sock",
        "/var/run/docker.sock",
    ]
    out = {}
    for p in all_paths:
        if p in present:
            out[("stat", "-c", "%n", p)] = _runresult(stdout=p+"\n")
        else:
            out[("stat", "-c", "%n", p)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(ContainerdImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_docker_takeover_yield():
    responses = _stat_responses(present=(
        _DOCKER_BIN, _DOCKER_SOCKET, _NERDCTL_BIN, _SOCKET,
    ))
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_nerdctl_mode_images():
    images = (_FIXTURES / "containerd_nerdctl_images.json").read_text()
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[("nerdctl", "images", "--format", "{{json .}}")] = _runresult(stdout=images)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    # redis:7 → 0, node:14 → 1 (node:1[0-4]* EOL), alpine:3.18 → 1 (alpine:3.1[0-9])
    assert len(findings) == 2
    assert all(f.evidence["runtime"] == "containerd" for f in findings)


def test_ctr_mode_images():
    refs = (_FIXTURES / "containerd_ctr_images_list_q.txt").read_text()
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[("ctr", "--namespace", "default", "images", "list", "-q")] = _runresult(stdout=refs)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    # docker.io/library/redis:7 → 0
    # docker.io/library/node:14 → 1 (node:1[0-4]* EOL)
    # docker.io/library/alpine:3.18 → 1 (alpine:3.1[0-9])
    assert len(findings) == 2


def test_ctr_mode_unparseable_ref():
    """An image ref without ':' is silently skipped."""
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[("ctr", "--namespace", "default", "images", "list", "-q")] = _runresult(
        stdout="docker.io/library/node\nbad-ref-no-colon\ndocker.io/library/node:14\n"
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    # Only node:14 matches; bad refs silently skipped
    assert len(findings) == 1


def test_images_failure_skipped():
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[("nerdctl", "images", "--format", "{{json .}}")] = _runresult(
        stderr="Permission denied", exit_code=126,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
