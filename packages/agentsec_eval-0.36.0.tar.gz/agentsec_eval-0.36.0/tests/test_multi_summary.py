from pathlib import Path

from agentsec.reports.multi_summary import TargetResult, render_multi_summary
from agentsec.scoring import CombinedScore, CoverageTriple, EvaluationScore


def _make_score(
    grade: str = "A",
    combined: float | None = 90.0,
    remote: float | None = 88.0,
    server: int | None = 92,
    findings: list | None = None,
) -> EvaluationScore:
    return EvaluationScore(
        category_scores=[],
        remote_score=remote,
        server_score=server,
        combined=CombinedScore(
            score=combined, weight_remote_used=0.5,
            weight_server_used=0.5, note=None,
        ),
        coverage=CoverageTriple(
            planned=5, executed=5, scored=5, error=0,
            execution_coverage=1.0, verdict_coverage=1.0, error_rate=0.0,
        ),
        low_coverage=False,
        grade=grade,
        deduped_findings=findings or [],
    )


def test_render_two_success_targets():
    results = [
        TargetResult("prod", Path("./out/prod"), _make_score(), None, 272.0),
        TargetResult(
            "staging", Path("./out/staging"),
            _make_score(grade="C", combined=61.2),
            None, 198.0,
        ),
    ]
    md = render_multi_summary(results, generated_at="2026-05-04T12:00:00Z")
    assert "# 多目标评估汇总" in md
    assert "成功 2" in md
    assert "错误 0" in md
    assert "| prod |" in md
    assert "| staging |" in md
    assert "prod/combined-report.md" in md
    assert "staging/combined-report.md" in md


def test_render_one_success_one_error():
    results = [
        TargetResult("prod", Path("./out/prod"), _make_score(), None, 272.0),
        TargetResult("dev", Path("./out/dev"), None, "SSH connection refused", 5.0),
    ]
    md = render_multi_summary(results, generated_at="2026-05-04T12:00:00Z")
    assert "成功 1" in md
    assert "错误 1" in md
    assert "| dev | ERROR |" in md
    assert "SSH connection refused" in md
    # error target must not appear in Reports section
    assert "dev/combined-report.md" not in md


def test_insufficient_coverage_grade_abbreviated():
    results = [
        TargetResult(
            "prod", Path("./out/prod"),
            _make_score(grade="INSUFFICIENT_COVERAGE"),
            None, 60.0,
        ),
    ]
    md = render_multi_summary(results, generated_at="2026-05-04T12:00:00Z")
    assert "LOW_COV" in md
    assert "INSUFFICIENT_COVERAGE" not in md


def test_finding_counts_in_table():
    from agentsec.audit.findings import Finding
    findings = [
        Finding(
            check="x", title="c1", severity="critical",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
        Finding(
            check="x", title="h1", severity="high",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
        Finding(
            check="x", title="h2", severity="high",
            description="d", evidence={}, remediation="r", threat_refs=[],
        ),
    ]
    results = [
        TargetResult("prod", Path("./out/prod"), _make_score(findings=findings), None, 60.0),
    ]
    md = render_multi_summary(results, generated_at="2026-05-04T12:00:00Z")
    row = next(line for line in md.splitlines() if line.startswith("| prod |"))
    cells = [c.strip() for c in row.split("|")]
    # | Target | Grade | Score | Remote | Server | Critical | High | Elapsed |
    # cells[0]="" [1]=prod [2]=grade [3]=score [4]=remote
    # cells[5]=server [6]=critical [7]=high [8]=elapsed
    assert cells[6] == "1"  # critical
    assert cells[7] == "2"  # high


def test_elapsed_formatting():
    results = [
        TargetResult("prod", Path("./out/prod"), _make_score(), None, 272.0),  # 4m32s
    ]
    md = render_multi_summary(results, generated_at="2026-05-04T12:00:00Z")
    assert "4m32s" in md


def test_generated_at_defaults_when_empty():
    results = [
        TargetResult("prod", Path("./out/prod"), _make_score(), None, 10.0),
    ]
    md = render_multi_summary(results)
    assert "生成时间：" in md


def test_not_scored_shows_dash():
    results = [
        TargetResult(
            "prod", Path("./out/prod"),
            _make_score(grade="NOT_SCORED", combined=None, remote=None, server=None),
            None, 10.0,
        ),
    ]
    md = render_multi_summary(results, generated_at="2026-05-04T12:00:00Z")
    row = next(line for line in md.splitlines() if line.startswith("| prod |"))
    cells = [c.strip() for c in row.split("|")]
    # | "" | prod | grade | score | remote | server | critical | high | elapsed |
    assert "NOT_SCORED" in cells[2]  # grade
    assert cells[3] == "—"   # score
    assert cells[4] == "—"   # remote
    assert cells[5] == "—"   # server
