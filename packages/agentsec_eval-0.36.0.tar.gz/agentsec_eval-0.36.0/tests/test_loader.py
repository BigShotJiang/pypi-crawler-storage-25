"""Smoke tests for test case loading and model validation."""

from pathlib import Path

from agentsec.tests.loader import load_test_suite


def test_load_prompt_injection_suite():
    path = Path(__file__).parent.parent / "test_suites" / "prompt_injection.yaml"
    cases = load_test_suite(path)
    assert len(cases) > 0
    assert all(c.id for c in cases)


def test_load_full_suite_directory():
    path = Path(__file__).parent.parent / "test_suites"
    cases = load_test_suite(path)
    ids = [c.id for c in cases]
    # No duplicate IDs across files
    assert len(ids) == len(set(ids))
