"""PodmanImageCveCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.podman_image_cve import PodmanImageCveCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"
_BIN = "/usr/bin/podman"
_IMAGES = ("podman", "images", "--format", "{{json .}}")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False):
    return RunResult(stdout=stdout, stderr=stderr, exit_code=exit_code,
                     rejected=rejected, reject_reason="policy" if rejected else None,
                     argv=[], command_sha256="0"*64, duration_ms=0.0,
                     bytes_out=len(stdout.encode()))


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []
    def run(self, argv, *, role=None):
        self.calls.append(list(argv))
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=list(argv),
                      command_sha256="0"*64, duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found):
    out = {}
    for c in ("/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman"):
        if c == found:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c+"\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_not_applicable_no_podman():
    ctx = _ctx(_RecordingExecutor(_detect_responses(None)))
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_images_zero_findings():
    responses = _detect_responses(_BIN)
    responses[_IMAGES] = _runresult(stdout="[]")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []


def test_images_mixed():
    images = (_FIXTURES / "podman_images_mixed.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_IMAGES] = _runresult(stdout=images)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanImageCveCheck(), ctx)
    # nginx:latest → 1 (latest pattern)
    # python:2.7 → 1
    # node:14 → 1 (node:1[0-4]* pattern)
    # ubuntu:22.04 + debian:12 → 0
    assert len(findings) == 3
    for f in findings:
        assert f.evidence["runtime"] == "podman"


def test_images_perm_denied_skipped():
    responses = _detect_responses(_BIN)
    responses[_IMAGES] = _runresult(stderr="Permission denied", exit_code=126)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
