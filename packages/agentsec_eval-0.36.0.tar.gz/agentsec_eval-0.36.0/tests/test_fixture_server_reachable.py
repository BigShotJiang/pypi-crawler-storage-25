import httpx
import pytest

from agentsec.observability.fixture_server import ReachableFixtureServer
from agentsec.observability.network_observer import FixtureOnlyObserver


@pytest.mark.asyncio
async def test_reachable_binds_address_and_returns_public_url(tmp_path):
    (tmp_path / "x.txt").write_text("hi")
    server = ReachableFixtureServer(
        root=tmp_path,
        observer=FixtureOnlyObserver(),
        bind="127.0.0.1",
        public_base_url="http://my-evaluator.lan:{port}",
    )
    async with server.serving() as base_url:
        # public_base_url has the chosen port substituted
        assert base_url.startswith("http://my-evaluator.lan:")
        # Pull the port out and verify the local listener works against it
        local_port = int(base_url.rsplit(":", 1)[1])
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"http://127.0.0.1:{local_port}/x.txt")
        assert resp.status_code == 200
        assert resp.text == "hi"


def test_reachable_requires_public_base_url(tmp_path):
    with pytest.raises(ValueError) as exc:
        ReachableFixtureServer(
            root=tmp_path,
            observer=FixtureOnlyObserver(),
            bind="0.0.0.0",
            public_base_url="",
        )
    assert "public_base_url" in str(exc.value)


@pytest.mark.asyncio
async def test_reachable_substitutes_port_placeholder_only_once(tmp_path):
    """If `public_base_url` lacks a {port} placeholder, the substitution
    is a no-op and the URL is returned verbatim. Operator may pin a port
    via DNS/proxy in front of us."""
    (tmp_path / "x.txt").write_text("hi")
    server = ReachableFixtureServer(
        root=tmp_path,
        observer=FixtureOnlyObserver(),
        bind="127.0.0.1",
        public_base_url="https://stable.evaluator.lan/fixtures",
    )
    async with server.serving() as base_url:
        assert base_url == "https://stable.evaluator.lan/fixtures"
