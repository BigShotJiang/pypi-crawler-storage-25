"""json_path_equals — hard_pass on equal, inconclusive on mismatch or absent."""

import pytest
from pydantic import ValidationError

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.assertions.json_path_equals import JsonPathEquals
from agentsec.observability.observation import Observation


def _obs(raw: dict) -> Observation:
    return Observation(response=AgentResponse(content="", raw=raw))


def test_equal_value_is_hard_pass():
    a = JsonPathEquals(path="$.choices[0].message.role", value="assistant")
    out = a.evaluate(_obs({"choices": [{"message": {"role": "assistant"}}]}))
    assert out.state == "hard_pass"


def test_mismatch_value_is_inconclusive():
    a = JsonPathEquals(path="$.choices[0].message.role", value="assistant")
    out = a.evaluate(_obs({"choices": [{"message": {"role": "system"}}]}))
    assert out.state == "inconclusive"
    assert out.evidence["actual"] == "system"


def test_path_absent_is_inconclusive():
    a = JsonPathEquals(path="$.missing", value=42)
    out = a.evaluate(_obs({}))
    assert out.state == "inconclusive"


def test_invalid_path_rejected_at_construction():
    with pytest.raises(ValidationError):
        JsonPathEquals(path="$.[unparseable", value=1)
