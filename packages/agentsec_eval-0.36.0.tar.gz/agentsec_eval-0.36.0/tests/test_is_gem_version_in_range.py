"""Unit tests for _is_gem_version_in_range (Phase 7d.5)."""

from __future__ import annotations

import pytest

from agentsec.audit.checks._supply_chain_common import (
    _is_gem_version_in_range,
    _safe_parse_gem_version,
)


@pytest.mark.parametrize(
    "version,introduced,fixed,expected",
    [
        # Standard PEP 440 / semver-like
        ("1.5.0", "1.0", "2.0", True),
        ("0.9.0", "1.0", "2.0", False),
        ("2.0.0", "1.0", "2.0", False),  # fixed exclusive
        ("1.0.0", "1.0", "2.0", True),  # introduced inclusive
        # RubyGems pre-release suffix .pre.N
        ("1.0.0.pre.1", "0", "1.0.0", True),
        ("1.0.0", "0", "1.0.0.pre.1", False),  # release > prerelease
        # .rc suffix
        ("2.0.0.rc1", "0", "2.0.0", True),
        # .beta / .alpha
        ("1.0.0.beta", "0", "1.0.0", True),
        # Missing bounds
        ("1.5.0", None, "2.0", True),
        ("3.0.0", None, "2.0", False),
        ("1.5.0", "1.0", None, True),
        ("0.5.0", "1.0", None, False),
        # Both missing → all versions vulnerable
        ("1.5.0", None, None, True),
        # Unparseable returns False
        ("not-a-version", "1.0", "2.0", False),
    ],
)
def test_is_gem_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
    expected: bool,
) -> None:
    assert _is_gem_version_in_range(version, introduced, fixed) is expected


def test_safe_parse_handles_invalid() -> None:
    assert _safe_parse_gem_version("") is None
    assert _safe_parse_gem_version(None) is None  # type: ignore
    assert _safe_parse_gem_version("garbage-string") is None


def test_safe_parse_handles_pre_release_forms() -> None:
    assert _safe_parse_gem_version("1.0.0.pre.1") is not None
    assert _safe_parse_gem_version("1.0.0.rc1") is not None
    assert _safe_parse_gem_version("1.0.0.beta") is not None
