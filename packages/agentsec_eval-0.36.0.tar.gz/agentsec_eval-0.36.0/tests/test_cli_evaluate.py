"""Smoke test for `agentsec evaluate` — feeds a 1-case fixture through a
stubbed adapter + stubbed SSH transport, asserts on artifact filenames.

Note: SSHExecutor.__init__ is lazy — it only touches the audit-log file on
construction; the paramiko connection is opened in _ensure_transport() which is
called from run(). Monkeypatching SSHExecutor.run is therefore sufficient to
prevent any real SSH connection.
"""

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from agentsec.audit.types import RunResult
from agentsec.cli import app

runner = CliRunner()


@pytest.fixture
def cfg_dir(tmp_path: Path) -> Path:
    suite = tmp_path / "suite.yaml"
    suite.write_text(
        '- id: t-1\n'
        '  category: ssrf\n'
        '  description: deterministic case\n'
        '  attack: "boom"\n'
        '  expected_behavior: refusal\n'
        '  severity: low\n'
        '  judge_type: deterministic\n'
        '  assertions:\n'
        '    - type: response_not_contains_pattern\n'
        '      pattern: "secret"\n'
    )
    auth = tmp_path / "AUTHORIZATION.txt"
    auth.write_text(
        "target_host: stub-host\n"
        "authorized_by: agentsec-test\n"
        "valid_from: 2026-01-01T00:00:00Z\n"
        "valid_until: 2030-01-01T00:00:00Z\n"
        "scope: [server-audit]\n"
        f"report_output_path_prefix: {tmp_path / 'out'}\n"
    )
    cfg = tmp_path / "cfg.yaml"
    cfg.write_text(
        "name: stub-eval\n"
        "remote:\n"
        "  adapter: stub-adapter-evaluate\n"
        "  target: https://stub\n"
        f"  test_suites: [{suite}]\n"
        "server_audit:\n"
        "  host: stub-host\n"
        "  user: u\n"
        f"  key: {tmp_path / 'fake_key'}\n"
        "authorization:\n"
        f"  consent_file: {auth}\n"
        f"output:\n"
        f"  dir: {tmp_path / 'out'}\n"
    )
    (tmp_path / "fake_key").write_text("fake")
    return cfg


def test_evaluate_writes_six_artifacts(cfg_dir, monkeypatch):
    out_dir = cfg_dir.parent / "out"
    from agentsec.adapters import registry
    from agentsec.adapters.base import AgentAdapter, AgentResponse

    class _StubAdapter(AgentAdapter):
        def __init__(self, **_kw): pass
        async def send(self, message, session_id):
            return AgentResponse(content="ok", latency_ms=0.0, raw={}, tool_events=[])

    registry.register("stub-adapter-evaluate", _StubAdapter)

    canned: dict[tuple, RunResult] = {}

    def _fake_run(self, argv, *, role=None):  # type: ignore[no-untyped-def]
        key = tuple(argv)
        if key == ("uname", "-s"):
            return RunResult(
                argv=list(argv), command_sha256="", duration_ms=0.0, bytes_out=0,
                stdout="Linux\n", stderr="", exit_code=0,
                rejected=False, reject_reason=None,
            )
        return canned.get(
            key,
            RunResult(
                argv=list(argv), command_sha256="", duration_ms=0.0, bytes_out=0,
                stdout="", stderr="", exit_code=0,
                rejected=False, reject_reason=None,
            ),
        )

    monkeypatch.setattr("agentsec.audit.ssh.SSHExecutor.run", _fake_run)
    monkeypatch.setattr("agentsec.audit.ssh.SSHExecutor.close", lambda self: None)

    try:
        result = runner.invoke(app, ["evaluate", "--config", str(cfg_dir)])
    finally:
        registry._REGISTRY.pop("stub-adapter-evaluate", None)

    assert result.exit_code == 0, result.stdout
    assert (out_dir / "remote-report.md").exists()
    assert (out_dir / "server-audit-report.md").exists()
    assert (out_dir / "combined-report.md").exists()
    assert (out_dir / "findings.json").exists()
    assert (out_dir / "threat-intel-snapshot.yaml").exists()
    assert (out_dir / "audit-log.jsonl").exists()

    findings = json.loads((out_dir / "findings.json").read_text())
    assert isinstance(findings, list)

    combined = (out_dir / "combined-report.md").read_text()
    assert "综合评估报告" in combined
    assert "remote-report.md" in combined
