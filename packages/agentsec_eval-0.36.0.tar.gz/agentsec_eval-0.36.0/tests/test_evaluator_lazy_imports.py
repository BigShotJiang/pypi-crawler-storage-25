"""evaluator/__init__.py exposes judges via __getattr__ to break a model↔judge
import cycle. Tests confirm the four documented names resolve and unknown
names raise AttributeError so we don't silently regress to a fall-through."""

import pytest

from agentsec.evaluator.deterministic_judge import DeterministicJudge as _DJ
from agentsec.evaluator.hybrid_judge import HybridJudge as _HJ
from agentsec.evaluator.judge import LLMJudge as _LLM
from agentsec.evaluator.judge_router import JudgeRouter as _JR


def test_lazy_export_llm_judge():
    import agentsec.evaluator as ev
    assert ev.LLMJudge is _LLM


def test_lazy_export_deterministic_judge():
    import agentsec.evaluator as ev
    assert ev.DeterministicJudge is _DJ


def test_lazy_export_hybrid_judge():
    import agentsec.evaluator as ev
    assert ev.HybridJudge is _HJ


def test_lazy_export_judge_router():
    import agentsec.evaluator as ev
    assert ev.JudgeRouter is _JR


def test_unknown_attribute_raises_attribute_error():
    import agentsec.evaluator as ev
    with pytest.raises(AttributeError, match="no attribute 'BogusJudge'"):
        _ = ev.BogusJudge
