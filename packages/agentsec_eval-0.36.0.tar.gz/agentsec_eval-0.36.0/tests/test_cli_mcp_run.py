from typer.testing import CliRunner

from agentsec.cli import app

_FIXTURE_YAML = """
- id: mcp-real-tools-99
  category: mcp_real_tools
  description: stub
  user_prompt: hi
  mcp_server:
    name: s
    tools:
      - name: t
        description: d
        input_schema: {type: object}
        result: ok
  expected_behavior: refusal
  severity: high
  judge_type: llm
  owasp_refs: [MCP1]
  judge_hint: "Pass if. Fail if."
"""


def test_mcp_run_help():
    res = CliRunner().invoke(app, ["mcp-run", "--help"])
    assert res.exit_code == 0
    assert "mcp-run" in res.stdout.lower() or "Usage" in res.stdout


def test_mcp_run_writes_report(tmp_path, monkeypatch):
    suite = tmp_path / "suite.yaml"
    suite.write_text(_FIXTURE_YAML)
    out = tmp_path / "report-dir"

    # Stub the ClaudeMcpAdapter so we don't hit the network. The CLI uses
    # `from .mcp_harness import ClaudeMcpAdapter` inside the command body,
    # so we patch the source module that the harness package re-exports.
    from agentsec.adapters.base import AgentResponse
    from agentsec.mcp_harness import adapter as adapter_mod

    class _StubAdapter:
        name = "stub"
        def __init__(self, **_):
            pass
        async def send(self, message, session_id):  # noqa: ARG002
            return AgentResponse(content="I refuse.")
        async def reset(self, session_id):  # noqa: ARG002
            pass
    monkeypatch.setattr(adapter_mod, "ClaudeMcpAdapter", _StubAdapter)
    # Also patch the re-export on the package so the CLI's
    # `from .mcp_harness import ClaudeMcpAdapter` resolves the stub.
    import agentsec.mcp_harness as harness_pkg
    monkeypatch.setattr(harness_pkg, "ClaudeMcpAdapter", _StubAdapter)

    # Stub LLMJudge similarly — the CLI constructs an LLMJudge with the
    # given model id. Replace via the cli module's import to ensure the
    # stub fires regardless of import shape.
    from agentsec.evaluator import base as judge_base

    class _PassJudge(judge_base.Judge):
        async def evaluate(self, test_case, observation):
            return judge_base.JudgeVerdict(
                passed=True, reasoning="ok",
                evidence={"raw": ""}, judge_type="llm",
            )
    from agentsec.evaluator import judge as judge_mod
    monkeypatch.setattr(judge_mod, "LLMJudge", lambda *a, **kw: _PassJudge())

    monkeypatch.setenv("ANTHROPIC_API_KEY", "fake")

    res = CliRunner().invoke(app, ["mcp-run", str(suite), "--output", str(out)])
    assert res.exit_code == 0, res.stdout
    assert (out / "mcp-real-report.md").exists()
