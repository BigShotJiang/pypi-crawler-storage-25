"""Unit tests for PhpSupplyChainAuditCheck (Phase 7d.6)."""

from __future__ import annotations

import json
from unittest.mock import MagicMock

import pytest

from agentsec.audit.checks.php_supply_chain_audit import (
    PhpSupplyChainAuditCheck,
    _match_composer_advisories,
)


def test_match_returns_advisory_when_in_range() -> None:
    db = {
        "monolog/monolog": [
            {"id": "GHSA-x", "ranges": [
                {"introduced": "1.0", "fixed": "2.0"}
            ]}
        ]
    }
    matches = _match_composer_advisories("monolog/monolog", "1.5", db)
    assert len(matches) == 1
    assert matches[0]["id"] == "GHSA-x"


def test_match_skips_when_version_above_fixed() -> None:
    db = {
        "monolog/monolog": [
            {"id": "GHSA-x", "ranges": [
                {"introduced": "1.0", "fixed": "2.0"}
            ]}
        ]
    }
    matches = _match_composer_advisories("monolog/monolog", "2.0", db)
    assert matches == []


def test_match_skips_when_package_not_in_db() -> None:
    db = {"symfony/console": [{"id": "x", "ranges": [{"fixed": "1.0"}]}]}
    matches = _match_composer_advisories("monolog/monolog", "0.5", db)
    assert matches == []


def test_match_returns_multiple_advisories_for_same_pkg() -> None:
    db = {
        "monolog/monolog": [
            {"id": "GHSA-1", "ranges": [{"introduced": "0", "fixed": "1.5"}]},
            {"id": "GHSA-2", "ranges": [{"introduced": "0", "fixed": "1.8"}]},
        ]
    }
    matches = _match_composer_advisories("monolog/monolog", "1.0", db)
    assert {m["id"] for m in matches} == {"GHSA-1", "GHSA-2"}


@pytest.mark.asyncio
async def test_check_returns_not_applicable_on_empty_paths() -> None:
    check = PhpSupplyChainAuditCheck()
    ctx = MagicMock()
    ctx.composer_lock_paths = []
    ctx.status = MagicMock()
    findings = await check.run(ctx)
    assert findings == []
    ctx.status.not_applicable.assert_called_once()


@pytest.mark.asyncio
async def test_scope_distinguishes_prod_and_dev(tmp_path: pytest.TempPathFactory) -> None:
    """Same (package, version) in both packages and packages-dev must emit
    two distinct findings with evidence.scope = 'prod' and 'dev'."""
    advisory = {
        "id": "GHSA-scope-test",
        "package": "symfony/console",
        "ranges": [{"introduced": "3.0.0", "fixed": "4.0.0"}],
        "severity": "high",
        "summary": "scope test advisory",
        "url": "https://example.com",
        "aliases": [],
    }
    db_path = tmp_path / "osv_packagist.json"
    db_path.write_text(json.dumps([advisory]))

    lock_content = json.dumps({
        "packages": [
            {"name": "symfony/console", "version": "3.5.0"}
        ],
        "packages-dev": [
            {"name": "symfony/console", "version": "3.5.0"}
        ],
    })

    check = PhpSupplyChainAuditCheck(db_path=db_path)

    ctx = MagicMock()
    ctx.profile.name = "linux"
    ctx.composer_lock_paths = ["/app/composer.lock"]
    # redactor.redact must return a real str for Finding Pydantic validation
    ctx.redactor.redact = lambda s: s

    result_mock = MagicMock()
    result_mock.rejected = False
    result_mock.exit_code = 0
    result_mock.stdout = lock_content
    ctx.executor.run.return_value = result_mock
    ctx.status = MagicMock()

    findings = await check.run(ctx)

    assert len(findings) == 2
    scopes = {f.evidence["scope"] for f in findings}
    assert scopes == {"prod", "dev"}
