"""Unit tests for Maven ComparableVersion comparator (Phase 7d.4)."""

from __future__ import annotations

import pytest

from agentsec.audit.checks._supply_chain_common import (
    _compare_maven_version,
    _is_maven_version_in_range,
)


@pytest.mark.parametrize(
    "v1,v2,expected",
    [
        # Trailing-zero normalization
        ("1.0", "1.0.0", 0),
        ("1.0.0.0", "1.0", 0),
        # Numeric comparison
        ("2.0", "1.99", 1),
        ("1.10", "1.9", 1),
        # SNAPSHOT < release
        ("1.0-SNAPSHOT", "1.0", -1),
        ("1.0", "1.0-SNAPSHOT", 1),
        # Qualifier order: alpha < beta < milestone < rc < snapshot < "" < sp
        ("1.0-alpha-1", "1.0-beta-1", -1),
        ("1.0-beta-1", "1.0-rc-1", -1),
        ("1.0-rc-1", "1.0-SNAPSHOT", -1),
        ("1.0-SNAPSHOT", "1.0-final", -1),
        ("1.0-final", "1.0-SP1", -1),
        # Unknown qualifier > sp
        ("1.0-foo", "1.0-SP1", 1),
        ("1.0-foo", "1.0", 1),
        # Nested numeric within qualifier
        ("1.0-alpha-1", "1.0-alpha-2", -1),
        ("1.0-alpha-2", "1.0-alpha-10", -1),
        # Alpha shorthand: 1.0a1 == 1.0-alpha-1
        ("1.0a1", "1.0-alpha-1", 0),
        ("1.0b2", "1.0-beta-2", 0),
        ("1.0m3", "1.0-milestone-3", 0),
        # 1.0a1 < 1.0
        ("1.0a1", "1.0", -1),
        # Equality
        ("1.2.3", "1.2.3", 0),
    ],
)
def test_compare_maven_version(v1: str, v2: str, expected: int) -> None:
    assert _compare_maven_version(v1, v2) == expected


@pytest.mark.parametrize(
    "version,introduced,fixed,expected",
    [
        # Standard range hits
        ("1.5.0", "1.0", "2.0", True),
        ("0.9", "1.0", "2.0", False),
        ("2.0", "1.0", "2.0", False),  # fixed is exclusive
        ("1.0", "1.0", "2.0", True),  # introduced is inclusive
        # SNAPSHOT in range
        ("1.0-SNAPSHOT", "1.0-alpha", "1.0", True),
        # Missing bounds
        ("1.5.0", None, "2.0", True),  # no introduced
        ("3.0", None, "2.0", False),
        ("1.5.0", "1.0", None, True),  # no fixed
        ("0.5.0", "1.0", None, False),
        ("1.5.0", None, None, True),  # both missing → vulnerable to all
    ],
)
def test_is_maven_version_in_range(
    version: str, introduced: str | None, fixed: str | None, expected: bool
) -> None:
    assert _is_maven_version_in_range(version, introduced, fixed) is expected
