"""ioc-update CLI must invoke OsvCargoFetcher and write proposed-osv_cargo.json (Phase 7d.3)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from agentsec.audit.ioc_update.cli import _run_osv_cargo
from agentsec.audit.ioc_update.fetchers.base import FetcherContext, FetchResult


@pytest.mark.asyncio
async def test_run_osv_cargo_writes_proposed_file(tmp_path: Path):
    fake_records = [
        {"id": "GHSA-w", "package": "serde",
         "ranges": [{"introduced": "0", "fixed": "1.0.0"}],
         "severity": "high", "summary": "x", "url": "u", "aliases": []}
    ]
    with patch(
        "agentsec.audit.ioc_update.cli.OsvCargoFetcher"
    ) as MockFetcher:
        async def fake_run(ctx, entries):
            return {"_osv_cargo_full": FetchResult.ok(records=fake_records)}
        MockFetcher.return_value.run.side_effect = fake_run

        ctx = FetcherContext(offline=False)
        out_path = await _run_osv_cargo(ctx, tmp_path)

    assert out_path == tmp_path / "proposed-osv_cargo.json"
    assert out_path.exists()
    payload = json.loads(out_path.read_text())
    assert payload == fake_records


@pytest.mark.asyncio
async def test_run_osv_cargo_handles_degraded_fetch(tmp_path: Path):
    with patch(
        "agentsec.audit.ioc_update.cli.OsvCargoFetcher"
    ) as MockFetcher:
        async def fake_run(ctx, entries):
            return {"_osv_cargo_full": FetchResult.from_degraded(
                reason="HTTP 503", fetcher="osv_cargo",
            )}
        MockFetcher.return_value.run.side_effect = fake_run

        ctx = FetcherContext(offline=False)
        out_path = await _run_osv_cargo(ctx, tmp_path)

    assert out_path is None
