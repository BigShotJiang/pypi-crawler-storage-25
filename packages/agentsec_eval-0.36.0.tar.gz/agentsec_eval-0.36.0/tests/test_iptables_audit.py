"""IptablesAuditCheck unit tests (Phase 7e.2)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.iptables_audit import IptablesAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "firewall"

_BIN = "/usr/sbin/iptables"
_STAT_OK = ("stat", "-c", "%n", _BIN)
_IPTABLES_S = ("iptables", "-S")
_IP6TABLES_S = ("ip6tables", "-S")


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=1,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None, ioc_dir=Path("/tmp"),
        profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_hit_at(path: str) -> RunResult:
    return _runresult(stdout=path + "\n")


def _stat_miss() -> RunResult:
    return _runresult(stderr="No such file", exit_code=1)


def _detect_responses(found_path: str | None) -> dict[tuple, RunResult]:
    """Stub the three iptables stat probes; return responses dict."""
    candidates = ("/usr/sbin/iptables", "/sbin/iptables", "/usr/bin/iptables")
    out: dict[tuple, RunResult] = {}
    for c in candidates:
        if c == found_path:
            out[("stat", "-c", "%n", c)] = _stat_hit_at(c)
        else:
            out[("stat", "-c", "%n", c)] = _stat_miss()
    return out


def test_non_linux_profile_not_applicable():
    findings = _run(IptablesAuditCheck(), _ctx(_RecordingExecutor({}), profile_name="macos"))
    assert findings == []


def test_iptables_not_installed_not_applicable():
    findings = _run(IptablesAuditCheck(), _ctx(_RecordingExecutor(_detect_responses(None))))
    assert findings == []


def test_compliant_default_drop_zero_findings():
    v4 = (_FIXTURES / "iptables_default_drop_v4.txt").read_text()
    v6 = (_FIXTURES / "iptables_default_drop_v4.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_IPTABLES_S] = _runresult(stdout=v4)
    responses[_IP6TABLES_S] = _runresult(stdout=v6)
    findings = _run(IptablesAuditCheck(), _ctx(_RecordingExecutor(responses)))
    assert findings == []


def test_default_accept_v4_emits_two_findings():
    v4 = (_FIXTURES / "iptables_default_accept_v4.txt").read_text()
    v6 = (_FIXTURES / "iptables_default_accept_v4.txt").read_text()  # same shape
    responses = _detect_responses(_BIN)
    responses[_IPTABLES_S] = _runresult(stdout=v4)
    responses[_IP6TABLES_S] = _runresult(stdout=v6)
    findings = _run(IptablesAuditCheck(), _ctx(_RecordingExecutor(responses)))
    # v4 INPUT (critical) + v4 FORWARD (high) + v6 INPUT (critical) + v6 FORWARD (critical) = 4
    assert len(findings) == 4
    sev_count = {"critical": 0, "high": 0}
    for f in findings:
        sev_count[f.severity] = sev_count.get(f.severity, 0) + 1
    assert sev_count["critical"] == 3  # v4 INPUT, v6 INPUT, v6 FORWARD
    assert sev_count["high"] == 1       # v4 FORWARD


def test_ufw_chains_detected_not_applicable():
    text = (_FIXTURES / "iptables_with_ufw_chains.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_IPTABLES_S] = _runresult(stdout=text)
    responses[_IP6TABLES_S] = _runresult(stdout=text)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(IptablesAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True
    assert "ufw" in (ctx.status.not_applicable_reason or "").lower()


def test_command_rejected_skipped():
    responses = _detect_responses(_BIN)
    responses[_IPTABLES_S] = _runresult(rejected=True)
    responses[_IP6TABLES_S] = _runresult(rejected=True)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(IptablesAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True


def test_permission_denied_skipped():
    responses = _detect_responses(_BIN)
    responses[_IPTABLES_S] = _runresult(stderr="iptables: Permission denied", exit_code=4)
    responses[_IP6TABLES_S] = _runresult(stderr="iptables: Permission denied", exit_code=4)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(IptablesAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
    assert "sudoers" in (ctx.status.skip_reason or "").lower() or \
           "root" in (ctx.status.skip_reason or "").lower()


def test_v4_ok_v6_failed_emits_v4_only():
    v4 = (_FIXTURES / "iptables_default_accept_v4.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_IPTABLES_S] = _runresult(stdout=v4)
    responses[_IP6TABLES_S] = _runresult(exit_code=1, stderr="ip6tables: not found")
    findings = _run(IptablesAuditCheck(), _ctx(_RecordingExecutor(responses)))
    # v4 only: 1 critical INPUT + 1 high FORWARD = 2
    assert len(findings) == 2
    assert all(f.evidence["family"] == "ipv4" for f in findings)


def test_firewalld_chains_detected_not_applicable():
    text = (_FIXTURES / "iptables_with_firewalld.txt").read_text()
    responses = _detect_responses(_BIN)
    responses[_IPTABLES_S] = _runresult(stdout=text)
    responses[_IP6TABLES_S] = _runresult(stdout=text)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(IptablesAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True
    assert "firewalld" in (ctx.status.not_applicable_reason or "").lower()
