"""Schema validation for the agent-chain privilege escalation suite."""
from pathlib import Path

from agentsec.observability.network_observer import NetworkObserverConfig
from agentsec.tests.loader import load_test_suite

SUITE_PATH = Path("test_suites/openclaw/10_agent_chain_privesc.yaml")
_OBS_CFG = NetworkObserverConfig(
    mode="fixture_only",
    controlled_domains=["*.agentsec.test", "*.openclaw.test", "169.254.169.254", "127.0.0.1"],
)

_EXPECTED_IDS = {
    "oc-chain-01", "oc-chain-02", "oc-chain-03",
    "oc-chain-04", "oc-chain-05", "oc-chain-06",
}


def test_suite_has_six_cases():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    assert len(cases) == 6


def test_all_case_ids_present():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    assert {c.id for c in cases} == _EXPECTED_IDS


def test_all_cases_are_agent_chain_privesc_category():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        assert c.category == "agent_chain_privesc", f"{c.id} has wrong category"


def test_all_cases_use_hybrid_judge():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        assert c.judge_type == "hybrid", f"{c.id} must use hybrid judge"


def test_multi_turn_cases_use_disposable_isolation():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    multi_turn_ids = {"oc-chain-02", "oc-chain-04", "oc-chain-06"}
    for c in cases:
        if c.id in multi_turn_ids:
            assert c.isolation.profile == "disposable", (
                f"{c.id} is multi-turn and must use disposable isolation"
            )


def test_all_cases_reference_owasp_a5():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        assert "TI-OWASP-AGENTIC-2026-A5" in c.threat_refs, (
            f"{c.id} must reference TI-OWASP-AGENTIC-2026-A5"
        )


def test_cve_32915_cases_reference_ti():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        if c.id in {"oc-chain-03", "oc-chain-04"}:
            assert "TI-OPENCLAW-CVE-2026-32915" in c.threat_refs, (
                f"{c.id} must reference TI-OPENCLAW-CVE-2026-32915"
            )


def test_cve_32918_cases_reference_ti():
    cases = load_test_suite(SUITE_PATH, observer_config=_OBS_CFG)
    for c in cases:
        if c.id in {"oc-chain-05", "oc-chain-06"}:
            assert "TI-OPENCLAW-CVE-2026-32918" in c.threat_refs, (
                f"{c.id} must reference TI-OPENCLAW-CVE-2026-32918"
            )
