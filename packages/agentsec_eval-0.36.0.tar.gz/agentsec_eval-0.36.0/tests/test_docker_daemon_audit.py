"""DockerDaemonAuditCheck 单元测试（Phase 7f）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks._docker_common import detect_docker  # noqa
from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.docker_daemon_audit import DockerDaemonAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"


def _runresult(stdout="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr="" if exit_code == 0 else "err",
        exit_code=exit_code, rejected=rejected,
        reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        key = tuple(argv)
        if key in self._responses:
            return self._responses[key]
        return _runresult(stdout="", exit_code=1)


def _ctx(executor):
    profile = materialize_paths(LINUX, "/home/u")
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=None, profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_response(path):
    return _runresult(stdout=path + "\n", exit_code=0)


def test_no_docker_binary_marks_not_applicable():
    """detect_docker 全失败 → not_applicable。"""
    ctx = _ctx(_RecordingExecutor({}))
    findings = _run(DockerDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "docker" in ctx.status.not_applicable_reason.lower()


def test_tls_exposed_emits_critical():
    """daemon.json 含 tcp:// 且 tlsverify=false → critical finding。"""
    daemon_json = (_FIXTURES / "daemon-json-tls-exposed.json").read_text()
    version_json = (_FIXTURES / "docker-version-24.0.7.json").read_text()
    info_json = (_FIXTURES / "docker-info-userns-enabled.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_response("/usr/bin/docker"),
        ("cat", "/etc/docker/daemon.json"): _runresult(stdout=daemon_json),
        ("docker", "version", "--format", "{{json .}}"): _runresult(stdout=version_json),
        ("docker", "info", "--format", "{{json .}}"): _runresult(stdout=info_json),
    }
    findings = _run(DockerDaemonAuditCheck(), _ctx(_RecordingExecutor(responses)))
    tls_findings = [f for f in findings if f.title.startswith("Docker daemon 暴露未认证")]
    assert len(tls_findings) == 1
    assert tls_findings[0].severity == "critical"
    assert "TI-DOCKER-DAEMON-TLS-DISABLED" in tls_findings[0].threat_refs


def test_default_daemon_emits_multiple_low_severity():
    """daemon-json-default 缺所有加固项 + version 24.0.7 (合规) →
    至少 emit userns / no-new-priv / live-restore / log-unbounded 四条。"""
    daemon_json = (_FIXTURES / "daemon-json-default.json").read_text()
    version_json = (_FIXTURES / "docker-version-24.0.7.json").read_text()
    info_json = (_FIXTURES / "docker-info-userns-disabled.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_response("/usr/bin/docker"),
        ("cat", "/etc/docker/daemon.json"): _runresult(stdout=daemon_json),
        ("docker", "version", "--format", "{{json .}}"): _runresult(stdout=version_json),
        ("docker", "info", "--format", "{{json .}}"): _runresult(stdout=info_json),
    }
    findings = _run(DockerDaemonAuditCheck(), _ctx(_RecordingExecutor(responses)))
    rule_ids_emitted = {f.evidence.get("rule_id") for f in findings}
    assert "daemon-userns-off" in rule_ids_emitted
    assert "daemon-no-new-priv" in rule_ids_emitted
    assert "daemon-live-restore" in rule_ids_emitted
    assert "daemon-log-unbounded" in rule_ids_emitted


def test_old_docker_version_emits_high():
    """docker version 23.0.0 落入 known_bad <24.0.7 → high finding。"""
    daemon_json = (_FIXTURES / "daemon-json-tls-exposed.json").read_text()
    version_json = (_FIXTURES / "docker-version-23.0.0.json").read_text()
    info_json = (_FIXTURES / "docker-info-userns-enabled.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_response("/usr/bin/docker"),
        ("cat", "/etc/docker/daemon.json"): _runresult(stdout=daemon_json),
        ("docker", "version", "--format", "{{json .}}"): _runresult(stdout=version_json),
        ("docker", "info", "--format", "{{json .}}"): _runresult(stdout=info_json),
    }
    findings = _run(DockerDaemonAuditCheck(), _ctx(_RecordingExecutor(responses)))
    version_findings = [f for f in findings
                        if f.evidence.get("rule_id") == "daemon-version-cve"]
    assert len(version_findings) == 1
    assert version_findings[0].severity == "high"


def test_missing_daemon_json_emits_info():
    """daemon.json 不存在 → emit info finding（不是错误，仍 completed）。"""
    version_json = (_FIXTURES / "docker-version-24.0.7.json").read_text()
    info_json = (_FIXTURES / "docker-info-userns-enabled.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_response("/usr/bin/docker"),
        ("cat", "/etc/docker/daemon.json"): _runresult(exit_code=1),
        ("docker", "version", "--format", "{{json .}}"): _runresult(stdout=version_json),
        ("docker", "info", "--format", "{{json .}}"): _runresult(stdout=info_json),
    }
    findings = _run(DockerDaemonAuditCheck(), _ctx(_RecordingExecutor(responses)))
    info_findings = [f for f in findings if f.severity == "info"]
    assert any("daemon.json" in f.title for f in info_findings)


def test_all_subcalls_fail_marks_skipped():
    """三个 docker subcall 全部失败 → skipped。"""
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_response("/usr/bin/docker"),
        ("cat", "/etc/docker/daemon.json"): _runresult(exit_code=1),
        ("docker", "version", "--format", "{{json .}}"): _runresult(exit_code=1),
        ("docker", "info", "--format", "{{json .}}"): _runresult(exit_code=1),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(DockerDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_rc_version_does_not_trigger_cve():
    """24.0.7-rc1 不应误判为 <24.0.7 CVE。"""
    daemon_json = (_FIXTURES / "daemon-json-tls-exposed.json").read_text()
    info_json = (_FIXTURES / "docker-info-userns-enabled.json").read_text()
    rc_version_json = '{"Server": {"Version": "24.0.7-rc1"}, "Client": {"Version": "24.0.7-rc1"}}'
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_response("/usr/bin/docker"),
        ("cat", "/etc/docker/daemon.json"): _runresult(stdout=daemon_json),
        ("docker", "version", "--format", "{{json .}}"): _runresult(stdout=rc_version_json),
        ("docker", "info", "--format", "{{json .}}"): _runresult(stdout=info_json),
    }
    findings = _run(DockerDaemonAuditCheck(), _ctx(_RecordingExecutor(responses)))
    version_findings = [f for f in findings
                        if f.evidence.get("rule_id") == "daemon-version-cve"]
    assert version_findings == []   # rc1 的 numeric prefix 24.0.7 == 24.0.7，不命中 <24.0.7
