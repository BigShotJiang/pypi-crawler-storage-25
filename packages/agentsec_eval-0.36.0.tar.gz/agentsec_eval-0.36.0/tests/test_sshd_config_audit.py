"""Unit tests for SshdConfigAuditCheck (Phase 7e)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.sshd_config_audit import SshdConfigAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult


class _StubExecutor:
    def __init__(self, response: RunResult):
        self._response = response
        self.last_argv: list[str] | None = None

    def run(self, argv, *, role=None):
        self.last_argv = list(argv)
        return self._response


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


COMPLIANT_SSHD_OUTPUT = """\
permitrootlogin no
passwordauthentication no
permitemptypasswords no
x11forwarding no
protocol 2
maxauthtries 4
"""

VIOLATION_SSHD_OUTPUT = """\
permitrootlogin yes
passwordauthentication yes
permitemptypasswords no
x11forwarding yes
protocol 2
maxauthtries 6
"""


def test_compliant_sshd_emits_no_findings():
    executor = _StubExecutor(_runresult(stdout=COMPLIANT_SSHD_OUTPUT))
    findings = _run(SshdConfigAuditCheck(), _ctx(executor))
    assert findings == []


def test_violations_emit_findings_per_key():
    executor = _StubExecutor(_runresult(stdout=VIOLATION_SSHD_OUTPUT))
    findings = _run(SshdConfigAuditCheck(), _ctx(executor))
    titles = [f.title for f in findings]
    assert len(findings) == 4
    assert any("permitrootlogin" in t for t in titles)
    assert any("passwordauthentication" in t for t in titles)
    crit = [f for f in findings if "permitrootlogin" in f.title]
    assert crit[0].severity == "critical"


def test_macos_profile_skips():
    executor = _StubExecutor(_runresult())
    ctx = _ctx(executor, profile_name="macos")
    findings = _run(SshdConfigAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_sshd_t_unavailable_falls_back_to_skipped():
    executor = _StubExecutor(_runresult(
        stderr="sshd: unknown option -- T",
        exit_code=1,
    ))
    ctx = _ctx(executor)
    findings = _run(SshdConfigAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
