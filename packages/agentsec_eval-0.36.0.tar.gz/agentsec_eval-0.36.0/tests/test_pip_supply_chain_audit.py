"""PipSupplyChainAuditCheck — _safe_parse_pep440 defensive edge cases (Phase 7d.cleanup M2)."""

from __future__ import annotations

from agentsec.audit.checks.pip_supply_chain_audit import _safe_parse_pep440

# ---- _safe_parse_pep440 defensive edge cases (M2) ----

def test_safe_parse_pep440_empty_string():
    """Empty string must return None without raising."""
    assert _safe_parse_pep440("") is None


def test_safe_parse_pep440_bare_prefix():
    """Bare '==' operator with no version is not valid PEP 440 → None."""
    assert _safe_parse_pep440("==") is None


def test_safe_parse_pep440_double_prefix():
    """'1.2..3' (double-dot release segment) is invalid PEP 440 → None."""
    assert _safe_parse_pep440("1.2..3") is None


def test_safe_parse_pep440_long_garbage():
    """1000-char garbage string must return None without raising."""
    assert _safe_parse_pep440("x" * 1000) is None
