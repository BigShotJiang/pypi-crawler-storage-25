"""Unit tests for GemSupplyChainAuditCheck (Phase 7d.5)."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from agentsec.audit.checks.gem_supply_chain_audit import (
    GemSupplyChainAuditCheck,
    _match_gem_advisories,
)


def test_match_returns_advisory_when_in_range() -> None:
    db = {
        "rails": [
            {"id": "GHSA-x", "ranges": [
                {"introduced": "1.0", "fixed": "2.0"}
            ]}
        ]
    }
    matches = _match_gem_advisories("rails", "1.5", db)
    assert len(matches) == 1
    assert matches[0]["id"] == "GHSA-x"


def test_match_skips_when_version_above_fixed() -> None:
    db = {
        "rails": [
            {"id": "GHSA-x", "ranges": [
                {"introduced": "1.0", "fixed": "2.0"}
            ]}
        ]
    }
    matches = _match_gem_advisories("rails", "2.0", db)
    assert matches == []


def test_match_skips_when_package_not_in_db() -> None:
    db = {"nokogiri": [{"id": "x", "ranges": [{"fixed": "1.0"}]}]}
    matches = _match_gem_advisories("rails", "0.5", db)
    assert matches == []


def test_match_returns_multiple_advisories_for_same_pkg() -> None:
    db = {
        "rails": [
            {"id": "GHSA-1", "ranges": [{"introduced": "0", "fixed": "1.5"}]},
            {"id": "GHSA-2", "ranges": [{"introduced": "0", "fixed": "1.8"}]},
        ]
    }
    matches = _match_gem_advisories("rails", "1.0", db)
    assert {m["id"] for m in matches} == {"GHSA-1", "GHSA-2"}


@pytest.mark.asyncio
async def test_check_returns_not_applicable_on_empty_paths() -> None:
    check = GemSupplyChainAuditCheck()
    ctx = MagicMock()
    ctx.gem_lock_paths = []
    ctx.status = MagicMock()
    findings = await check.run(ctx)
    assert findings == []
    ctx.status.not_applicable.assert_called_once()
