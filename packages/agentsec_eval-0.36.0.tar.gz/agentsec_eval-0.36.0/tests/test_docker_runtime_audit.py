"""DockerRuntimeAuditCheck 单元测试（Phase 7f）。"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.docker_runtime_audit import DockerRuntimeAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"


def _runresult(stdout="", exit_code=0, rejected=False, stderr="") -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr or ("err" if exit_code != 0 else ""),
        exit_code=exit_code, rejected=rejected,
        reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(tuple(argv), _runresult(exit_code=1))


def _ctx(executor):
    profile = materialize_paths(LINUX, "/home/u")
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=None, profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_docker():
    return _runresult(stdout="/usr/bin/docker\n")


PS_ARGV = ("docker", "ps", "--format", "{{json .}}", "--no-trunc")


def _ps_output() -> str:
    return (_FIXTURES / "docker-ps-3-containers.json").read_text()


def test_no_docker_binary_marks_not_applicable():
    ctx = _ctx(_RecordingExecutor({}))
    findings = _run(DockerRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_docker_ps_permission_denied_marks_skipped():
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(exit_code=1, stderr="permission denied"),
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(DockerRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_privileged_container_emits_critical():
    inspect_priv = (_FIXTURES / "inspect-privileged.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(stdout=_ps_output()),
        ("docker", "inspect", "a1b2c3d4e5f6"): _runresult(stdout=inspect_priv),
        ("docker", "inspect", "b2c3d4e5f6a1"): _runresult(exit_code=1),
        ("docker", "inspect", "c3d4e5f6a1b2"): _runresult(exit_code=1),
    }
    findings = _run(DockerRuntimeAuditCheck(), _ctx(_RecordingExecutor(responses)))
    priv = [f for f in findings
            if f.evidence.get("rule_id") == "runtime-privileged"]
    assert len(priv) == 1
    assert priv[0].severity == "critical"
    assert "TI-DOCKER-RUNTIME-PRIVILEGED" in priv[0].threat_refs


def test_host_net_emits_high():
    inspect_host = (_FIXTURES / "inspect-host-net.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(stdout=_ps_output()),
        ("docker", "inspect", "a1b2c3d4e5f6"): _runresult(exit_code=1),
        ("docker", "inspect", "b2c3d4e5f6a1"): _runresult(stdout=inspect_host),
        ("docker", "inspect", "c3d4e5f6a1b2"): _runresult(exit_code=1),
    }
    findings = _run(DockerRuntimeAuditCheck(), _ctx(_RecordingExecutor(responses)))
    host_net = [f for f in findings
                if f.evidence.get("rule_id") == "runtime-host-net"]
    assert len(host_net) == 1
    assert host_net[0].severity == "high"


def test_sock_mount_emits_critical():
    inspect_sock = (_FIXTURES / "inspect-sock-mount.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(stdout=_ps_output()),
        ("docker", "inspect", "a1b2c3d4e5f6"): _runresult(exit_code=1),
        ("docker", "inspect", "b2c3d4e5f6a1"): _runresult(exit_code=1),
        ("docker", "inspect", "c3d4e5f6a1b2"): _runresult(stdout=inspect_sock),
    }
    findings = _run(DockerRuntimeAuditCheck(), _ctx(_RecordingExecutor(responses)))
    sock = [f for f in findings if f.evidence.get("rule_id") == "runtime-sock-mount"]
    assert len(sock) == 1
    assert sock[0].severity == "critical"
    cap = [f for f in findings if f.evidence.get("rule_id") == "runtime-cap-dangerous"]
    assert len(cap) == 1   # SYS_ADMIN single cap
    root_user = [f for f in findings if f.evidence.get("rule_id") == "runtime-root-user"]
    assert len(root_user) == 1


def test_secrets_env_not_in_evidence():
    """Assert: Config.Env entirely dropped from evidence — even with mock secrets."""
    inspect_secret = (_FIXTURES / "inspect-with-secrets-env.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(
            stdout='{"ID":"e5f6a1b2c3d4","Image":"app:latest","Names":"secret-app"}\n',
        ),
        ("docker", "inspect", "e5f6a1b2c3d4"): _runresult(stdout=inspect_secret),
    }
    findings = _run(DockerRuntimeAuditCheck(), _ctx(_RecordingExecutor(responses)))
    full_evidence = json.dumps([f.evidence for f in findings])
    assert "AKIA1234567890ABCDEF" not in full_evidence
    assert "DATABASE_URL" not in full_evidence
    assert "SECRET_TOKEN" not in full_evidence
    assert "verysecret123" not in full_evidence


def test_multi_cap_emits_three_findings():
    inspect_multi = (_FIXTURES / "inspect-multi-cap.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(
            stdout='{"ID":"f6a1b2c3d4e5","Image":"tool:latest","Names":"multi-cap"}\n',
        ),
        ("docker", "inspect", "f6a1b2c3d4e5"): _runresult(stdout=inspect_multi),
    }
    findings = _run(DockerRuntimeAuditCheck(), _ctx(_RecordingExecutor(responses)))
    cap_findings = [f for f in findings
                    if f.evidence.get("rule_id") == "runtime-cap-dangerous"]
    assert len(cap_findings) == 3
    caps_seen = {f.evidence["cap"] for f in cap_findings}
    assert caps_seen == {"SYS_ADMIN", "NET_ADMIN", "SYS_PTRACE"}
    fingerprints = {f.fingerprint for f in cap_findings}
    assert len(fingerprints) == 3   # all unique


def test_inspect_partial_failure_continues():
    """3 containers, 2 inspect fail 1 succeeds → Check completes; only emit
    findings for the success."""
    inspect_clean = (_FIXTURES / "inspect-clean.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(stdout=_ps_output()),
        ("docker", "inspect", "a1b2c3d4e5f6"): _runresult(stdout=inspect_clean),
        # other two not provided → exit 1
    }
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(DockerRuntimeAuditCheck(), ctx)
    assert not ctx.status.is_skipped
    assert not ctx.status.is_not_applicable
    inspect_attempts = [c for c in ctx.executor.calls
                        if len(c) == 3 and c[0] == "docker" and c[1] == "inspect"]
    assert len(inspect_attempts) == 3   # all 3 containers were attempted
    # inspect-clean has no violations → 0 findings
    assert findings == []


def test_etc_subdir_bind_emits_host_fs_mount():
    """Bind source under /etc → runtime-host-fs-mount finding (boundary match)."""
    inspect_etc = (_FIXTURES / "inspect-etc-bind.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(
            stdout='{"ID":"1234567890ab","Image":"leaker:1.0","Names":"etc-leak"}\n',
        ),
        ("docker", "inspect", "1234567890ab"): _runresult(stdout=inspect_etc),
    }
    findings = _run(DockerRuntimeAuditCheck(), _ctx(_RecordingExecutor(responses)))
    fs_mount = [f for f in findings
                if f.evidence.get("rule_id") == "runtime-host-fs-mount"]
    assert len(fs_mount) == 1
    assert fs_mount[0].severity == "high"
    # "/" is the first sensitive_host_path in container_baseline.yaml;
    # is_path_under matches it before "/etc".
    assert fs_mount[0].evidence["sensitive_root"] == "/"
    assert "/etc/secrets:/data:ro" in fs_mount[0].evidence["hit_value"]


def test_clean_container_emits_zero_findings():
    inspect_clean = (_FIXTURES / "inspect-clean.json").read_text()
    responses = {
        ("stat", "-c", "%n", "/usr/bin/docker"): _stat_docker(),
        PS_ARGV: _runresult(
            stdout='{"ID":"d4e5f6a1b2c3","Image":"myapp:1.0","Names":"healthy-app"}\n',
        ),
        ("docker", "inspect", "d4e5f6a1b2c3"): _runresult(stdout=inspect_clean),
    }
    findings = _run(DockerRuntimeAuditCheck(), _ctx(_RecordingExecutor(responses)))
    assert findings == []
