from agentsec.audit.redactor import Redactor


def _r(text: str) -> str:
    return Redactor().redact(text)


def test_generic_key_value_quoted_json():
    out = _r('{"api_key": "supersecretvalueXYZ12345"}')
    assert "supersecret" not in out
    assert "<REDACTED>" in out


def test_generic_key_value_kebab_case_unquoted():
    out = _r("api-key=ABCDEFGHIJKLMNOP")
    assert "ABCDEFGHIJKLMNOP" not in out
    assert "<REDACTED>" in out


def test_openai_classic_key():
    out = _r("Authorization: sk-abcdefghijklmnopqrstuvwxyz")
    assert "<REDACTED OPENAI KEY>" in out


def test_openai_proj_key():
    out = _r("OPENAI_API_KEY=sk-proj-abcdefghijklmnopqrstuvwxyz1234567890")
    assert "<REDACTED OPENAI KEY>" in out


def test_anthropic_key():
    out = _r("ANTHROPIC_API_KEY=sk-ant-abcdefghijklmnopqrstuvwxyz")
    assert "<REDACTED ANTHROPIC KEY>" in out


def test_aws_access_key_id():
    out = _r("aws=AKIAIOSFODNN7EXAMPLE")
    assert "<REDACTED AWS ACCESS KEY ID>" in out


def test_aws_sts_key_id():
    out = _r("aws=ASIAIOSFODNN7EXAMPLE")
    assert "<REDACTED AWS STS KEY ID>" in out


def test_aws_secret_access_key_env_assignment():
    # Real AWS docs example. 40-char base64-ish. Labelled redaction must
    # win over the generic catch-all so the type is preserved in scrubbed logs.
    out = _r("AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
    assert "<REDACTED AWS SECRET ACCESS KEY>" in out
    assert "wJalrXUtnFEMI" not in out


def test_aws_secret_access_key_kebab_quoted_yaml():
    out = _r('aws-secret-access-key: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"')
    assert "<REDACTED AWS SECRET ACCESS KEY>" in out
    assert "wJalrXUtnFEMI" not in out


def test_aws_secret_access_key_short_value_falls_through_to_catchall():
    # Wrong-length value is not the AWS-specific pattern, but the generic
    # catch-all still scrubs it as a `secret*` field.
    out = _r("aws_secret_access_key=tooshort1234")
    assert "tooshort1234" not in out


def test_github_pat():
    out = _r("token=ghp_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert "<REDACTED GITHUB PAT>" in out


def test_github_app_token():
    out = _r("token=ghs_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert "<REDACTED GITHUB APP TOKEN>" in out


def test_github_oauth_token():
    out = _r("token=gho_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert "<REDACTED GITHUB OAUTH TOKEN>" in out


def test_github_user_to_server_token():
    out = _r("token=ghu_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert "<REDACTED GITHUB USER-TO-SERVER TOKEN>" in out


def test_github_refresh_token():
    out = _r("token=ghr_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert "<REDACTED GITHUB REFRESH TOKEN>" in out


def test_github_fine_grained_pat():
    # github_pat_<22 ID chars>_<59 secret chars> = 93 total chars.
    pat = "github_pat_" + "A" * 22 + "_" + "B" * 59
    assert len(pat) == 93
    out = _r(f"export GITHUB_TOKEN={pat}")
    assert "<REDACTED GITHUB FINE-GRAINED PAT>" in out
    assert "AAAA" not in out


def test_github_fine_grained_pat_wrong_length_not_matched_specifically():
    # 81 trailing chars instead of 82 → fine-grained pattern doesn't fire.
    # The catch-all may still match because the line has `token=` shape.
    short = "github_pat_" + "A" * 81
    out = _r(short)
    assert "<REDACTED GITHUB FINE-GRAINED PAT>" not in out


def test_slack_token():
    out = _r("hook=xoxb-1234567890-abcdef")
    assert "<REDACTED SLACK TOKEN>" in out


def test_discord_bot_token():
    out = _r("DISCORD=Mzk1MjEzNzAyNTYxMzcxNTIw.GxYZab.abcdefghijklmnopqrstuvwxyz12345")
    assert "<REDACTED DISCORD TOKEN>" in out


def test_telegram_bot_token():
    out = _r("TELEGRAM=123456789:ABCDEFghijklmnopQRSTUVwxyz0123456789")
    assert "<REDACTED TELEGRAM BOT TOKEN>" in out


def test_google_api_key():
    out = _r("g=AIzaSyA-1234567890abcdefghijklmnopqrstuvw")
    assert "<REDACTED GOOGLE API KEY>" in out


def test_bearer_header():
    out = _r("Authorization: Bearer abcdef.ghijkl.mnopqr")
    assert "Bearer <REDACTED>" in out


def test_private_key_block():
    out = _r("-----BEGIN RSA PRIVATE KEY-----\nabcdef\n-----END RSA PRIVATE KEY-----")
    assert "<REDACTED PRIVATE KEY>" in out


def test_ssh_public_key():
    long_blob = "A" * 200
    out = _r(f"ssh-rsa {long_blob}== user@host")
    assert "<REDACTED SSH PUBLIC KEY>" in out


def test_jwt():
    out = _r("token=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dQw4w9WgXcQabcdef123")
    assert "<REDACTED JWT>" in out


def test_safe_text_unchanged():
    safe = "this is a normal log line with version 2026.1.29"
    assert _r(safe) == safe


def test_extra_patterns_appended():
    r = Redactor(extra_patterns=[(r"\bopenclaw-tok-[A-Z0-9]{8}\b", "<REDACTED OPENCLAW TOKEN>")])
    assert "<REDACTED OPENCLAW TOKEN>" in r.redact("hi openclaw-tok-ABCD1234")


def test_redactor_is_pure_function():
    r = Redactor()
    inp = "api_key=ABCDEFGHIJKL1234"
    out1 = r.redact(inp)
    out2 = r.redact(inp)
    assert out1 == out2
