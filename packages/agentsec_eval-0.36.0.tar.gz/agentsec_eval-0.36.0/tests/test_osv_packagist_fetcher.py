"""Unit tests for OsvPackagistFetcher (Phase 7d.6)."""

from __future__ import annotations

import asyncio
import io
import json
import zipfile

import httpx
import pytest

from agentsec.audit.ioc_update.fetchers.base import FetcherContext
from agentsec.audit.ioc_update.fetchers.osv_packagist import (
    OsvPackagistFetcher,
    normalize_osv_packagist_entry,
)


def _make_zip(entries: list[dict]) -> bytes:
    """Pack OSV entries into a zip the fetcher can read."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for entry in entries:
            zf.writestr(f"{entry['id']}.json", json.dumps(entry))
    return buf.getvalue()


def test_normalize_keeps_critical_packagist_entry() -> None:
    entry = {
        "id": "GHSA-test-1",
        "summary": "Critical RCE in monolog",
        "published": "2025-01-01T00:00:00Z",
        "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        "affected": [
            {"package": {"ecosystem": "Packagist", "name": "monolog/monolog"},
             "ranges": [{"type": "ECOSYSTEM", "events": [
                 {"introduced": "0"}, {"fixed": "2.0.0"}
             ]}]}
        ],
        "references": [{"url": "https://example.com/CVE-2025-0001"}],
    }
    records = normalize_osv_packagist_entry(entry)
    assert records is not None
    assert len(records) == 1
    assert records[0]["package"] == "monolog/monolog"
    assert records[0]["severity"] == "critical"
    assert records[0]["ranges"] == [{"introduced": "0", "fixed": "2.0.0"}]


def test_normalize_drops_non_packagist_affected() -> None:
    entry = {
        "id": "GHSA-x",
        "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        "affected": [
            {"package": {"ecosystem": "npm", "name": "lodash"},
             "ranges": [{"type": "ECOSYSTEM", "events": [{"fixed": "1.0"}]}]}
        ],
    }
    assert normalize_osv_packagist_entry(entry) is None


def test_normalize_drops_withdrawn() -> None:
    entry = {
        "id": "x",
        "withdrawn": "2024-01-01T00:00:00Z",
        "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        "affected": [
            {"package": {"ecosystem": "Packagist", "name": "symfony/console"},
             "ranges": [{"type": "ECOSYSTEM", "events": [{"fixed": "1.0"}]}]}
        ],
    }
    assert normalize_osv_packagist_entry(entry) is None


@pytest.mark.asyncio
async def test_fetcher_pulls_zip_and_dedups() -> None:
    _cvss_high = (
        "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
    )
    entries = [
        {
            "id": "GHSA-A",
            "summary": "RCE",
            "published": "2025-01-01T00:00:00Z",
            "severity": [{"type": "CVSS_V3", "score": _cvss_high}],
            "affected": [
                {
                    "package": {"ecosystem": "Packagist", "name": "monolog/monolog"},
                    "ranges": [{"type": "ECOSYSTEM", "events": [
                        {"introduced": "0"}, {"fixed": "2.0.0"},
                    ]}],
                }
            ],
            "references": [{"url": "https://example.com/A"}],
        },
        {
            "id": "GHSA-B",
            "summary": "Path traversal",
            "published": "2025-02-01T00:00:00Z",
            "severity": [{"type": "CVSS_V3", "score": _cvss_high}],
            "affected": [
                {
                    "package": {"ecosystem": "Packagist", "name": "symfony/console"},
                    "ranges": [{"type": "ECOSYSTEM", "events": [
                        {"introduced": "0"}, {"fixed": "6.0.0"},
                    ]}],
                }
            ],
            "references": [{"url": "https://example.com/B"}],
        },
    ]
    zip_bytes = _make_zip(entries)

    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=zip_bytes)

    transport = httpx.MockTransport(handler)
    fetcher = OsvPackagistFetcher()
    fetcher._client_factory = lambda: httpx.AsyncClient(transport=transport)
    fetcher._sleep = lambda s: asyncio.sleep(0)

    ctx = FetcherContext(offline=False)
    results = await fetcher.run(ctx, entries=[])
    assert "_osv_packagist_full" in results
    records = results["_osv_packagist_full"].records
    assert len(records) == 2
    packages = {r["package"] for r in records}
    assert packages == {"monolog/monolog", "symfony/console"}
