"""Tests for PluginJudge — dynamic plugin loading."""
from __future__ import annotations

from pathlib import Path

import pytest

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.plugin_judge import PluginJudge
from agentsec.observability.observation import Observation
from agentsec.tests.models import TestCase


def _make_obs() -> Observation:
    return Observation(
        response=AgentResponse(content="ok", latency_ms=5.0, raw={}, tool_events=[]),
        outbound_requests=[],
        fixture_events=[],
    )


def _make_test_case() -> TestCase:
    return TestCase(
        id="tc-plugin",
        category="prompt_injection",
        description="plugin test",
        attack="pwn",
        expected_behavior="refusal",
        severity="medium",
    )


def _write_valid_plugin(tmp_path: Path) -> Path:
    p = tmp_path / "my_judge.py"
    p.write_text(
        "from agentsec.evaluator.base import Judge, JudgeVerdict\n"
        "\n"
        "class MyJudge(Judge):\n"
        "    async def evaluate(self, test_case, observation):\n"
        "        return JudgeVerdict(passed=True, reasoning='plugin ok', judge_type='llm')\n"
    )
    return p


async def test_plugin_judge_valid_delegates(tmp_path):
    plugin_path = _write_valid_plugin(tmp_path)
    judge = PluginJudge(plugin_path)
    verdict = await judge.evaluate(_make_test_case(), _make_obs())
    assert verdict.passed is True
    assert verdict.reasoning == "plugin ok"


def test_plugin_judge_file_not_found(tmp_path):
    with pytest.raises(ValueError, match="not found"):
        PluginJudge(tmp_path / "missing.py")


def test_plugin_judge_no_subclass(tmp_path):
    p = tmp_path / "empty.py"
    p.write_text("x = 1\n")
    with pytest.raises(ValueError, match="no Judge subclass found"):
        PluginJudge(p)


def test_plugin_judge_ambiguous(tmp_path):
    p = tmp_path / "two.py"
    p.write_text(
        "from agentsec.evaluator.base import Judge, JudgeVerdict\n"
        "\n"
        "class JudgeA(Judge):\n"
        "    async def evaluate(self, test_case, observation):\n"
        "        return JudgeVerdict(passed=True, reasoning='a', judge_type='llm')\n"
        "\n"
        "class JudgeB(Judge):\n"
        "    async def evaluate(self, test_case, observation):\n"
        "        return JudgeVerdict(passed=True, reasoning='b', judge_type='llm')\n"
    )
    with pytest.raises(ValueError, match="ambiguous"):
        PluginJudge(p)
