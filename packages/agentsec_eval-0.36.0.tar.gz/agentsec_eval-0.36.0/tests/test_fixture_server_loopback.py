import httpx
import pytest

from agentsec.observability.fixture_server import LoopbackFixtureServer
from agentsec.observability.network_observer import FixtureOnlyObserver


@pytest.mark.asyncio
async def test_loopback_serves_file_and_records_event(tmp_path):
    fixture_dir = tmp_path / "fx"
    fixture_dir.mkdir()
    (fixture_dir / "page.html").write_text("<h1>hello fixture</h1>")

    observer = FixtureOnlyObserver()
    server = LoopbackFixtureServer(root=fixture_dir, observer=observer)

    async with server.serving() as base_url:
        assert base_url.startswith("http://127.0.0.1:")
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{base_url}/page.html")
        assert resp.status_code == 200
        assert "hello fixture" in resp.text

    events = observer.fixture_events()
    assert len(events) == 1
    assert events[0].method == "GET"
    assert events[0].path == "/page.html"


@pytest.mark.asyncio
async def test_loopback_returns_404_for_missing_file(tmp_path):
    fixture_dir = tmp_path / "fx"
    fixture_dir.mkdir()
    server = LoopbackFixtureServer(root=fixture_dir, observer=FixtureOnlyObserver())
    async with server.serving() as base_url:
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{base_url}/nope")
        assert resp.status_code == 404


@pytest.mark.asyncio
async def test_loopback_path_traversal_rejected(tmp_path):
    """A `..`-laden URL must NOT escape the fixture root, even if a sibling
    file exists outside it. The handler resolves and verifies containment."""
    import asyncio
    import socket

    fixture_dir = tmp_path / "fx"
    fixture_dir.mkdir()
    (tmp_path / "secret").write_text("nope")
    server = LoopbackFixtureServer(root=fixture_dir, observer=FixtureOnlyObserver())
    async with server.serving() as base_url:
        # httpx normalises `..` client-side; bypass that by talking raw HTTP.
        # Run blocking socket I/O in a thread so the asyncio event loop stays
        # free to process the incoming request — otherwise recv deadlocks.
        host_port = base_url.replace("http://", "")
        host, port = host_port.split(":")

        def _raw_request() -> str:
            s = socket.create_connection((host, int(port)))
            s.sendall(b"GET /../secret HTTP/1.0\r\nHost: x\r\n\r\n")
            s.settimeout(5)
            data = b""
            try:
                while True:
                    chunk = s.recv(4096)
                    if not chunk:
                        break
                    data += chunk
            finally:
                s.close()
            return data.decode()

        data = await asyncio.get_event_loop().run_in_executor(None, _raw_request)
        assert "200 OK" not in data
        # Either 400 (bad path) or 404 (not found relative to root) is acceptable.
        assert "400" in data or "404" in data


@pytest.mark.asyncio
async def test_loopback_observer_captures_host_header(tmp_path):
    (tmp_path / "x.txt").write_text("ok")
    observer = FixtureOnlyObserver()
    server = LoopbackFixtureServer(root=tmp_path, observer=observer)
    async with server.serving() as base_url:
        async with httpx.AsyncClient() as client:
            await client.get(f"{base_url}/x.txt")
    outbound = observer.outbound_requests()
    assert len(outbound) == 1
    # target_host comes from Host header which httpx fills with 127.0.0.1:PORT.
    assert outbound[0].target_host.startswith("127.0.0.1:")
