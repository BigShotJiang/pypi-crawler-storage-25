"""ioc-update CLI must invoke OsvPyPIFetcher and write proposed-osv_pypi.json (Phase 7d.1)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from agentsec.audit.ioc_update.cli import _run_osv_pypi
from agentsec.audit.ioc_update.fetchers.base import FetcherContext, FetchResult


@pytest.mark.asyncio
async def test_run_osv_pypi_writes_proposed_file(tmp_path: Path):
    fake_records = [
        {"id": "GHSA-y", "package": "django",
         "ranges": [{"introduced": "0", "fixed": "3.2.18"}],
         "severity": "high", "summary": "x", "url": "u", "aliases": []}
    ]
    with patch(
        "agentsec.audit.ioc_update.cli.OsvPyPIFetcher"
    ) as MockFetcher:
        async def fake_run(ctx, entries):
            return {"_osv_pypi_full": FetchResult.ok(records=fake_records)}
        MockFetcher.return_value.run.side_effect = fake_run

        ctx = FetcherContext(offline=False)
        out_path = await _run_osv_pypi(ctx, tmp_path)

    assert out_path == tmp_path / "proposed-osv_pypi.json"
    assert out_path.exists()
    payload = json.loads(out_path.read_text())
    assert payload == fake_records


@pytest.mark.asyncio
async def test_run_osv_pypi_handles_degraded_fetch(tmp_path: Path):
    with patch(
        "agentsec.audit.ioc_update.cli.OsvPyPIFetcher"
    ) as MockFetcher:
        async def fake_run(ctx, entries):
            return {"_osv_pypi_full": FetchResult.from_degraded(
                reason="HTTP 503", fetcher="osv_pypi",
            )}
        MockFetcher.return_value.run.side_effect = fake_run

        ctx = FetcherContext(offline=False)
        out_path = await _run_osv_pypi(ctx, tmp_path)

    assert out_path is None
