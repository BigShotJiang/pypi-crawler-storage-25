"""Unit tests for SystemdServiceBlacklistCheck (Phase 7e.1)."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.systemd_service_blacklist import (
    SystemdServiceBlacklistCheck,
)
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.types import RunResult

FIXTURES = Path(__file__).parent / "fixtures" / "linux_hardening"

_LIST_ARGV = (
    "systemctl", "list-unit-files", "--type=service,socket", "--state=enabled",
    "--no-legend", "--plain",
)


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=0, rejected=False,
                reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _rr(stdout="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr="", exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name not in ("linux", "linux_user_mode"):
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=None,
        ioc_dir=Path("/tmp"), profile=profile,
        log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def test_blacklist_hits_emit_findings():
    fixture = (FIXTURES / "systemctl_list_unit_files.txt").read_text()
    responses = {_LIST_ARGV: _rr(stdout=fixture)}
    findings = _run(SystemdServiceBlacklistCheck(), _ctx(_RecordingExecutor(responses)))
    units = sorted(f.evidence["unit"] for f in findings)
    assert units == [
        "avahi-daemon.service", "cups.service", "nfs-server.service",
        "rpcbind.service", "xinetd.service",
    ]


def test_no_blacklist_hits_zero_findings():
    """Real-world clean Ubuntu: only benign services enabled."""
    clean = (
        "accounts-daemon.service                            enabled\n"
        "apparmor.service                                   enabled\n"
        "ssh.service                                        enabled\n"
    )
    responses = {_LIST_ARGV: _rr(stdout=clean)}
    findings = _run(SystemdServiceBlacklistCheck(), _ctx(_RecordingExecutor(responses)))
    assert findings == []


def test_critical_severity_for_legacy_protocols():
    """telnet.socket / rsh.socket 等 critical severity。"""
    responses = {
        _LIST_ARGV: _rr(stdout="telnet.socket  enabled\nrsh.socket  enabled\n"),
    }
    findings = _run(SystemdServiceBlacklistCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 2
    assert all(f.severity == "critical" for f in findings)


def test_skips_on_macos_profile():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(SystemdServiceBlacklistCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_command_rejected_marks_skipped():
    responses = {_LIST_ARGV: _rr(rejected=True)}
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(SystemdServiceBlacklistCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_command_failure_marks_skipped():
    responses = {_LIST_ARGV: _rr(exit_code=1)}
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(SystemdServiceBlacklistCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped


def test_unparseable_lines_skipped_silently():
    """格式异常行被静默跳过；正常行仍 emit。"""
    responses = {
        _LIST_ARGV: _rr(stdout="garbage line\navahi-daemon.service  enabled\n"),
    }
    findings = _run(SystemdServiceBlacklistCheck(), _ctx(_RecordingExecutor(responses)))
    assert len(findings) == 1
    assert "avahi-daemon" in findings[0].title
