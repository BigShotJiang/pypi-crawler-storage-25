"""Unit tests for Maven dependency:list parser (Phase 7d.4)."""

from __future__ import annotations

from agentsec.audit.checks._supply_chain_common import parse_maven_dependency_list


def test_parses_standard_dependency_list_output() -> None:
    text = """[INFO]
[INFO] --- maven-dependency-plugin:2.8:list ---
[INFO]
[INFO]    org.apache.commons:commons-lang3:jar:3.12.0:compile
[INFO]    com.google.guava:guava:jar:31.1-jre:compile
[INFO]    org.springframework:spring-core:jar:5.3.20:provided
[INFO]
[INFO] BUILD SUCCESS
"""
    deps = parse_maven_dependency_list(text)
    assert deps == [
        ("org.apache.commons:commons-lang3", "3.12.0"),
        ("com.google.guava:guava", "31.1-jre"),
        ("org.springframework:spring-core", "5.3.20"),
    ]


def test_includes_test_scope_but_skips_system() -> None:
    text = """[INFO]    org.junit.jupiter:junit-jupiter-api:jar:5.8.2:test
[INFO]    com.sun.tools:tools:jar:1.8.0:system
[INFO]    org.example:lib:jar:1.0:compile
"""
    deps = parse_maven_dependency_list(text)
    coords = [c for c, _ in deps]
    assert "org.junit.jupiter:junit-jupiter-api" in coords  # test included
    assert "com.sun.tools:tools" not in coords  # system skipped
    assert "org.example:lib" in coords  # compile included


def test_handles_no_info_prefix() -> None:
    text = """org.apache.commons:commons-lang3:jar:3.12.0:compile
com.google.guava:guava:jar:31.1-jre:compile
"""
    deps = parse_maven_dependency_list(text)
    assert deps == [
        ("org.apache.commons:commons-lang3", "3.12.0"),
        ("com.google.guava:guava", "31.1-jre"),
    ]


def test_skips_malformed_lines() -> None:
    text = """[INFO] --- header ---
[INFO]    not.a.valid.coord
[INFO]    too:few:segments
[INFO]    org.example:lib:jar:1.0:compile
[INFO]    a:b:c:d:e:f:g
[INFO] random text
"""
    deps = parse_maven_dependency_list(text)
    assert deps == [("org.example:lib", "1.0")]


def test_empty_input_returns_empty() -> None:
    assert parse_maven_dependency_list("") == []
    assert parse_maven_dependency_list("\n\n\n") == []
