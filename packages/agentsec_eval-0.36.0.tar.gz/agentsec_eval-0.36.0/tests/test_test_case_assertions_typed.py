"""TestCase.assertions becomes list[Assertion] — typo at load time is fatal."""

import pytest
from pydantic import ValidationError

from agentsec.evaluator.assertions import (
    OutboundRequestNotTo,
    ResponseStatusIn,
)
from agentsec.tests.models import TestCase


def _base() -> dict:
    return {
        "id": "x-1", "category": "x", "description": "x",
        "attack": "x", "expected_behavior": "refusal", "severity": "low",
    }


def test_assertions_parsed_into_typed_subclasses():
    tc = TestCase.model_validate({
        **_base(),
        "assertions": [
            {"type": "response_status_in", "statuses": [200]},
            {"type": "outbound_request_not_to", "target": "*.evil.test"},
        ],
    })
    assert isinstance(tc.assertions[0], ResponseStatusIn)
    assert isinstance(tc.assertions[1], OutboundRequestNotTo)


def test_unknown_assertion_type_rejected_at_load():
    with pytest.raises(ValidationError):
        TestCase.model_validate({
            **_base(),
            "assertions": [{"type": "made_up", "x": 1}],
        })


def test_assertion_extra_field_rejected_at_load():
    with pytest.raises(ValidationError):
        TestCase.model_validate({
            **_base(),
            "assertions": [{"type": "response_status_in", "statuses": [200], "bogus": 1}],
        })


def test_assertions_omitted_is_none():
    tc = TestCase.model_validate(_base())
    assert tc.assertions is None


def test_empty_assertions_list_is_allowed():
    """Empty list is distinct from None — explicit "no assertions to run"."""
    tc = TestCase.model_validate({**_base(), "assertions": []})
    assert tc.assertions == []
