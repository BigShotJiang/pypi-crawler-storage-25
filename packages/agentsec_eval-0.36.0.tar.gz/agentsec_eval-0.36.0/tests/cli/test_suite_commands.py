"""Typer surface tests for `agentsec suite ...`."""

import io
import tarfile
from pathlib import Path

import httpx
import pytest
from typer.testing import CliRunner

from agentsec.cli import app
from agentsec.suite_registry.hashing import canonical_hash

runner = CliRunner()


_VALID_MANIFEST = """\
schema_version: 1
name: foo-suite
version: 1.0.0
description: A test bundle
authors: [{name: jdoe}]
license: MIT
agentsec_min_version: 0.0.0
threat_refs_required: []
case_count: 1
"""

_MISMATCH_MANIFEST = """\
schema_version: 1
name: foo-suite
version: 1.0.0
description: A test bundle with a wrong case_count
authors: [{name: jdoe}]
license: MIT
agentsec_min_version: 0.0.0
threat_refs_required: []
case_count: 5
"""

_VALID_CASE = """\
- id: foo-001
  category: prompt_injection
  description: x
  severity: low
  attack: hi
  expected_behavior: refusal
"""


def _build_bundle_dir(tmp_path: Path, *, manifest_text: str) -> Path:
    bundle = tmp_path / "build" / "foo-suite"
    (bundle / "cases").mkdir(parents=True)
    (bundle / "manifest.yaml").write_text(manifest_text)
    (bundle / "cases" / "01.yaml").write_text(_VALID_CASE)
    return bundle


def _tar_bytes(bundle: Path) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        for p in sorted(bundle.rglob("*")):
            if p.is_file():
                rel = p.relative_to(bundle)
                tf.add(str(p), arcname=f"extras-1.0.0/suites/foo/{rel.as_posix()}")
    return buf.getvalue()


def _install_handler(index_yaml: str, tarball: bytes):
    def handler(req: httpx.Request) -> httpx.Response:
        url = str(req.url)
        if "community-suites.yaml" in url or url.endswith("/index"):
            return httpx.Response(200, text=index_yaml)
        if "codeload.github.com" in url:
            return httpx.Response(200, content=tarball)
        return httpx.Response(404)
    return handler


def _patch_httpx(monkeypatch, handler) -> None:
    import agentsec.suite_registry.fetcher as _fetcher
    import agentsec.suite_registry.registry as _registry
    real_client_cls = httpx.Client

    def patched_client(*args, **kwargs):
        kwargs["transport"] = httpx.MockTransport(handler)
        kwargs.pop("follow_redirects", None)
        return real_client_cls(*args, **kwargs)

    monkeypatch.setattr(_fetcher.httpx, "Client", patched_client)
    monkeypatch.setattr(_registry.httpx, "Client", patched_client)


@pytest.fixture
def fake_registry_url(tmp_path: Path, monkeypatch) -> str:
    """Spin up a fake registry index served via patched HttpRegistry transport."""
    bundle = _build_bundle_dir(tmp_path, manifest_text=_VALID_MANIFEST)
    sha = canonical_hash(bundle)
    tarball = _tar_bytes(bundle)
    index_yaml = (
        "schema_version: 1\n"
        "suites:\n"
        "  foo-suite:\n"
        "    source: github\n"
        "    repo: jdoe/extras\n"
        "    ref: v1.0.0\n"
        "    subdir: suites/foo\n"
        f"    sha256: {sha}\n"
        "    summary: Test bundle\n"
    )
    _patch_httpx(monkeypatch, _install_handler(index_yaml, tarball))
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    return "https://example.test/community-suites.yaml"


@pytest.fixture
def fake_registry_url_mismatch(tmp_path: Path, monkeypatch) -> str:
    """Same fixture but the manifest declares case_count=5 vs 1 actually shipped."""
    bundle = _build_bundle_dir(tmp_path, manifest_text=_MISMATCH_MANIFEST)
    sha = canonical_hash(bundle)
    tarball = _tar_bytes(bundle)
    index_yaml = (
        "schema_version: 1\n"
        "suites:\n"
        "  foo-suite:\n"
        "    source: github\n"
        "    repo: jdoe/extras\n"
        "    ref: v1.0.0\n"
        "    subdir: suites/foo\n"
        f"    sha256: {sha}\n"
        "    summary: Test bundle (mismatch)\n"
    )
    _patch_httpx(monkeypatch, _install_handler(index_yaml, tarball))
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    return "https://example.test/community-suites.yaml"


def test_suite_list_empty(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    res = runner.invoke(app, ["suite", "list"])
    assert res.exit_code == 0
    assert "No suites" in res.stdout


def test_suite_list_with_registry(fake_registry_url):
    res = runner.invoke(app, ["suite", "list", "--registry-url", fake_registry_url])
    assert res.exit_code == 0
    assert "foo-suite" in res.stdout


def test_suite_install_success(fake_registry_url, tmp_path):
    res = runner.invoke(
        app, ["suite", "install", "foo-suite", "--registry-url", fake_registry_url]
    )
    assert res.exit_code == 0, res.stdout
    assert "installed" in res.stdout.lower()
    assert (Path(tmp_path / "home") / ".agentsec" / "suites" / "foo-suite").is_dir()


def test_suite_install_not_in_registry(fake_registry_url):
    res = runner.invoke(
        app, ["suite", "install", "ghost", "--registry-url", fake_registry_url]
    )
    assert res.exit_code == 1
    assert "not in registry" in res.stdout.lower()


def test_suite_info(fake_registry_url, tmp_path):
    res = runner.invoke(app, ["suite", "install", "foo-suite", "--registry-url", fake_registry_url])
    assert res.exit_code == 0, res.stdout
    res = runner.invoke(app, ["suite", "info", "foo-suite"])
    assert res.exit_code == 0
    assert "foo-suite" in res.stdout
    assert "1.0.0" in res.stdout


def test_suite_uninstall(fake_registry_url, tmp_path):
    res = runner.invoke(app, ["suite", "install", "foo-suite", "--registry-url", fake_registry_url])
    assert res.exit_code == 0, res.stdout
    res = runner.invoke(app, ["suite", "uninstall", "foo-suite"])
    assert res.exit_code == 0
    assert not (Path(tmp_path / "home") / ".agentsec" / "suites" / "foo-suite").exists()


def test_suite_hash(tmp_path):
    bundle = tmp_path / "b"
    bundle.mkdir()
    (bundle / "manifest.yaml").write_text("name: x\n")
    res = runner.invoke(app, ["suite", "hash", str(bundle)])
    assert res.exit_code == 0
    line = res.stdout.strip()
    assert len(line) == 64
    assert all(c in "0123456789abcdef" for c in line)


def test_suite_install_warns_on_case_count_mismatch(fake_registry_url_mismatch, tmp_path):
    """spec §4.1: case_count mismatch is a warning at CLI surface, not fatal."""
    res = runner.invoke(
        app, ["suite", "install", "foo-suite", "--registry-url", fake_registry_url_mismatch]
    )
    assert res.exit_code == 0, res.stdout
    assert "warning" in res.stdout.lower()
    # Tight substrings tied to the actual format string in
    # cli.py:_emit_case_count_warning so this can't be satisfied by
    # incidental "5" or "1" appearing elsewhere in stdout.
    assert "case_count=5" in res.stdout
    assert "1 cases were loaded" in res.stdout


def test_run_with_suite_flag_resolves_to_local_path(fake_registry_url, tmp_path, monkeypatch):
    res = runner.invoke(
        app, ["suite", "install", "foo-suite", "--registry-url", fake_registry_url]
    )
    assert res.exit_code == 0, res.stdout

    captured: dict = {}

    async def fake_run_suite(adapter, judge, tests, concurrency=3, **kwargs):
        captured["cases"] = tests
        captured["adapter_name"] = getattr(adapter, "name", None)
        captured["suite_root"] = kwargs.get("suite_root")
        return []

    monkeypatch.setattr("agentsec.cli.run_suite", fake_run_suite)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "fake-key-for-test")

    out_path = tmp_path / "out.md"
    res = runner.invoke(
        app,
        [
            "run",
            "--suite", "foo-suite",
            "--target", "http://localhost:9999",
            "--name", "test-target",
            "--output", str(out_path),
        ],
    )
    assert res.exit_code == 0, res.stdout
    assert len(captured.get("cases", [])) >= 1
    # suite_root must point at the bundle root (sibling of cases/), NOT
    # at cases/ itself — fixture.path entries are resolved against the
    # bundle root and the installer lays out cases/ and fixtures/ as
    # siblings under <store>/<name>/.
    suite_root = Path(captured["suite_root"])
    assert suite_root.name == "foo-suite", (
        f"suite_root should be the bundle root, got {suite_root}"
    )
    assert (suite_root / "cases").is_dir()


def test_run_with_suite_and_path_is_rejected(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    res = runner.invoke(
        app,
        [
            "run",
            "some/path",
            "--suite", "foo",
            "--target", "http://localhost",
        ],
    )
    assert res.exit_code != 0
    assert "mutually exclusive" in res.stdout.lower()


def test_run_with_unknown_suite_errors(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    res = runner.invoke(
        app,
        [
            "run",
            "--suite", "ghost",
            "--target", "http://localhost",
        ],
    )
    assert res.exit_code != 0
    assert "not installed" in res.stdout.lower()
