"""Unit tests for parse_composer_lock (Phase 7d.6)."""

from __future__ import annotations

import json

from agentsec.audit.checks._supply_chain_common import parse_composer_lock


def _lock(packages=None, packages_dev=None) -> str:
    obj = {}
    if packages is not None:
        obj["packages"] = packages
    if packages_dev is not None:
        obj["packages-dev"] = packages_dev
    return json.dumps(obj)


def test_parses_packages_and_packages_dev() -> None:
    text = _lock(
        packages=[
            {"name": "monolog/monolog", "version": "2.9.1", "source": {"type": "git"}},
            {"name": "psr/log", "version": "3.0.0", "source": {"type": "git"}},
        ],
        packages_dev=[
            {"name": "phpunit/phpunit", "version": "9.6.13", "source": {"type": "git"}},
        ],
    )
    deps = parse_composer_lock(text)
    assert deps == [
        ("monolog/monolog", "2.9.1", "prod"),
        ("psr/log", "3.0.0", "prod"),
        ("phpunit/phpunit", "9.6.13", "dev"),
    ]


def test_only_packages_array() -> None:
    text = _lock(packages=[
        {"name": "symfony/console", "version": "6.3.0", "source": {"type": "git"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [("symfony/console", "6.3.0", "prod")]


def test_only_packages_dev_array() -> None:
    text = _lock(packages_dev=[
        {"name": "vimeo/psalm", "version": "5.15.0", "source": {"type": "git"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [("vimeo/psalm", "5.15.0", "dev")]


def test_empty_json_returns_empty() -> None:
    assert parse_composer_lock("{}") == []
    assert parse_composer_lock("") == []
    assert parse_composer_lock("not-json") == []


def test_skips_source_type_path() -> None:
    text = _lock(packages=[
        {"name": "vendor/published", "version": "1.0.0", "source": {"type": "git"}},
        {"name": "vendor/local", "version": "0.1.0", "source": {"type": "path"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [("vendor/published", "1.0.0", "prod")]


def test_case_folds_names_and_strips_v_prefix() -> None:
    text = _lock(packages=[
        {"name": "Laravel/Framework", "version": "v10.34.2", "source": {"type": "git"}},
        {"name": "GuzzleHTTP/Guzzle", "version": "V7.8.1", "source": {"type": "git"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [
        ("laravel/framework", "10.34.2", "prod"),
        ("guzzlehttp/guzzle", "7.8.1", "prod"),
    ]
