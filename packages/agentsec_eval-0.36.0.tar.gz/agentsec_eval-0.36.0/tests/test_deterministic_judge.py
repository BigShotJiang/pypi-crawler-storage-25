"""DeterministicJudge — aggregates assertion outcomes per spec §5.1."""

import pytest

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.assertions import (
    OutboundRequestNotTo,
    ResponseNotContainsPattern,
    ResponseStatusIn,
)
from agentsec.evaluator.deterministic_judge import DeterministicJudge
from agentsec.observability.observation import Observation
from agentsec.tests.models import Severity, TestCase


def _case(assertions) -> TestCase:
    return TestCase(
        id="t-1", category="x", description="d", attack="a",
        expected_behavior="refusal", severity=Severity.medium,
        judge_type="deterministic", assertions=assertions,
    )


def _obs(content: str = "ok", status: int | None = 200, hosts: list[str] | None = None
         ) -> Observation:
    return Observation(
        response=AgentResponse(content=content, status_code=status),
        outbound_requests=[
            {"target_host": h, "method": "GET", "url": f"http://{h}/", "timestamp": 0.0}
            for h in (hosts or [])
        ],
    )


@pytest.mark.asyncio
async def test_all_hard_pass_returns_passed_true():
    j = DeterministicJudge()
    tc = _case([
        ResponseStatusIn(statuses=[200]),
        ResponseNotContainsPattern(pattern="never-matches"),
    ])
    v = await j.evaluate(tc, _obs())
    assert v.passed is True
    assert v.judge_type == "deterministic"


@pytest.mark.asyncio
async def test_any_hard_fail_short_circuits_passed_false():
    j = DeterministicJudge()
    tc = _case([
        ResponseStatusIn(statuses=[200]),  # hard_pass
        OutboundRequestNotTo(target="*.evil.test"),  # hard_fail
        ResponseNotContainsPattern(pattern="never-matches"),  # hard_pass
    ])
    v = await j.evaluate(tc, _obs(hosts=["a.evil.test"]))
    assert v.passed is False
    # reasoning mentions hard_fail
    assert "hard_fail" in v.reasoning or "outbound_request_not_to" in v.reasoning
    # all outcomes recorded in evidence
    assert len(v.evidence["outcomes"]) == 3


@pytest.mark.asyncio
async def test_inconclusive_without_hard_fail_is_failed_with_reason():
    j = DeterministicJudge()
    tc = _case([
        ResponseStatusIn(statuses=[200]),  # hard_pass
        ResponseNotContainsPattern(pattern="ok"),  # inconclusive — pattern hit
    ])
    v = await j.evaluate(tc, _obs(content="ok"))
    assert v.passed is False
    assert "inconclusive" in v.reasoning


@pytest.mark.asyncio
async def test_empty_assertions_list_is_inconclusive():
    j = DeterministicJudge()
    tc = _case([])
    v = await j.evaluate(tc, _obs())
    assert v.passed is False
    assert "inconclusive" in v.reasoning


@pytest.mark.asyncio
async def test_none_assertions_raises():
    j = DeterministicJudge()
    tc = _case(None)
    with pytest.raises(ValueError):
        await j.evaluate(tc, _obs())
