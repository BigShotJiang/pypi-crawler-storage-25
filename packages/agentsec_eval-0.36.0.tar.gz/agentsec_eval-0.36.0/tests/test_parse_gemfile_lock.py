"""Unit tests for parse_gemfile_lock (Phase 7d.5)."""

from __future__ import annotations

from agentsec.audit.checks._supply_chain_common import parse_gemfile_lock


def test_parses_standard_gem_section() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    actionmailer (7.0.4)
      actionpack (= 7.0.4)
      actionview (= 7.0.4)
    activesupport (7.0.4)
      i18n (>= 1.6, < 2)
    rails (7.0.4)
      actioncable (= 7.0.4)

PLATFORMS
  ruby

DEPENDENCIES
  rails (~> 7.0.0)
"""
    deps = parse_gemfile_lock(text)
    assert deps == [
        ("actionmailer", "7.0.4"),
        ("activesupport", "7.0.4"),
        ("rails", "7.0.4"),
    ]


def test_skips_git_and_path_sections() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    rails (7.0.4)

GIT
  remote: https://github.com/example/gem.git
  revision: abc123
  specs:
    private-gem (1.0.0)

PATH
  remote: vendor/local-gem
  specs:
    local-gem (0.1.0)
"""
    deps = parse_gemfile_lock(text)
    coords = [name for name, _ in deps]
    assert coords == ["rails"]
    assert "private-gem" not in coords
    assert "local-gem" not in coords


def test_case_folds_gem_names() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    ActiveRecord (7.0.4)
    MyGem (1.0.0)
"""
    deps = parse_gemfile_lock(text)
    assert deps == [("activerecord", "7.0.4"), ("mygem", "1.0.0")]


def test_skips_transitive_constraints() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    rails (7.0.4)
      actioncable (= 7.0.4)
      actionmailer (= 7.0.4)
      activerecord (= 7.0.4)
    sidekiq (6.5.0)
      connection_pool (>= 2.2.5)
"""
    deps = parse_gemfile_lock(text)
    assert deps == [("rails", "7.0.4"), ("sidekiq", "6.5.0")]


def test_empty_or_no_gem_section_returns_empty() -> None:
    assert parse_gemfile_lock("") == []
    assert parse_gemfile_lock("PLATFORMS\n  ruby\n\nDEPENDENCIES\n  rails\n") == []
