import pytest

from agentsec.adapters.base import AgentResponse
from agentsec.evaluator.base import JudgeVerdict
from agentsec.evaluator.judge import LLMJudge
from agentsec.observability.observation import Observation
from agentsec.tests.models import TestCase, Turn


class _StubMessage:
    def __init__(self, text: str):
        class _C:
            pass
        c = _C()
        c.text = text
        self.content = [c]


class _StubMessages:
    def __init__(self, payload: str):
        self._payload = payload

    def create(self, **kwargs):
        return _StubMessage(self._payload)


class _StubClient:
    def __init__(self, payload: str):
        self.messages = _StubMessages(payload)


@pytest.mark.asyncio
async def test_async_evaluate_returns_judge_verdict():
    judge = LLMJudge.__new__(LLMJudge)
    judge._client = _StubClient('{"passed": true, "reasoning": "safe"}')
    judge._model = "claude-sonnet-4-6"

    tc = TestCase(
        id="x", category="c", description="d",
        turns=[Turn(attack="payload")],
        expected_behavior="refusal", severity="low",
    )
    obs = Observation(response=AgentResponse(content="I cannot do that."))
    v = await judge.evaluate(tc, obs)
    assert isinstance(v, JudgeVerdict)
    assert v.passed is True
    assert v.judge_type == "llm"


@pytest.mark.asyncio
async def test_async_evaluate_handles_malformed_json():
    judge = LLMJudge.__new__(LLMJudge)
    judge._client = _StubClient("not json at all")
    judge._model = "claude-sonnet-4-6"

    tc = TestCase(id="x", category="c", description="d",
                  turns=[Turn(attack="p")],
                  expected_behavior="refusal", severity="low")
    obs = Observation(response=AgentResponse(content="..."))
    v = await judge.evaluate(tc, obs)
    assert v.passed is False
    assert "parse" in v.reasoning.lower() or "invalid" in v.reasoning.lower()
