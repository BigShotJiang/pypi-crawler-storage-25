from agentsec.adapters.base import AgentResponse
from agentsec.observability.observation import Observation


def test_defaults_use_factories():
    r = AgentResponse(content="x")
    a = Observation(response=r)
    b = Observation(response=r)
    a.outbound_requests.append({"u": 1})
    a.fixture_events.append({"p": "/x"})
    a.tool_events.append({"t": "shell.exec"})
    assert b.outbound_requests == []
    assert b.fixture_events == []
    assert b.tool_events == []
    assert b.pre_state_snapshot is None
    assert b.post_state_snapshot is None


def test_round_trips_through_dict():
    r = AgentResponse(content="x", status_code=200)
    obs = Observation(
        response=r,
        outbound_requests=[{"url": "https://exfil.agentsec.test/"}],
        pre_state_snapshot={"memory": "before"},
        post_state_snapshot={"memory": "after"},
    )
    d = obs.model_dump()
    assert d["response"]["status_code"] == 200
    assert d["pre_state_snapshot"]["memory"] == "before"
