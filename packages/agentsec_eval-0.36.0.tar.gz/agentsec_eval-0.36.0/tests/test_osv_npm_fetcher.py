"""OsvNpmFetcher normalization tests (Phase 7d). No live HTTP."""

from __future__ import annotations

import json
from pathlib import Path

from agentsec.audit.ioc_update.fetchers.osv_npm import normalize_osv_entry

_FIXTURES = Path(__file__).parent / "fixtures" / "osv" / "npm"


def _load(name: str) -> dict:
    return json.loads((_FIXTURES / f"{name}.json").read_text())


def test_normalize_normal_cvss_entry():
    entry = _load("normal-cvss")
    out_list = normalize_osv_entry(entry)
    assert isinstance(out_list, list) and len(out_list) == 1
    out = out_list[0]
    assert out["id"] == "GHSA-jf85-cpcp-j695"
    assert out["package"] == "lodash"
    assert out["ranges"] == [{"introduced": "0", "fixed": "4.17.21"}]
    assert out["severity"] == "critical"  # CVSS 3.1 base score 9.8 → critical
    assert out["aliases"] == ["CVE-2019-10744"]
    assert "lodash" in out["summary"].lower()
    assert "GHSA-jf85-cpcp-j695" in out["url"]


def test_normalize_withdrawn_returns_none():
    entry = _load("withdrawn")
    assert normalize_osv_entry(entry) is None


def test_normalize_cross_ecosystem_takes_npm_only():
    entry = _load("cross-ecosystem")
    out_list = normalize_osv_entry(entry)
    assert isinstance(out_list, list) and len(out_list) == 1
    out = out_list[0]
    assert out["package"] == "django-bridge"
    assert out["ranges"] == [{"introduced": "0", "fixed": "2.0.0"}]


def test_normalize_no_npm_affected_returns_none():
    entry = _load("no-npm-affected")
    assert normalize_osv_entry(entry) is None


def test_normalize_git_range_no_semver_returns_none():
    entry = _load("git-range-no-semver")
    assert normalize_osv_entry(entry) is None


def test_normalize_cvss_missing_dropped():
    """No CVSS at all → dropped (avoids ~190K unscored noise in real OSV)."""
    entry = _load("cvss-missing")
    assert normalize_osv_entry(entry) is None


def test_normalize_old_medium_filtered_out():
    entry = _load("old-medium")
    assert normalize_osv_entry(entry) is None


def test_normalize_old_critical_kept():
    entry = _load("old-critical")
    out_list = normalize_osv_entry(entry)
    assert isinstance(out_list, list) and len(out_list) == 1
    out = out_list[0]
    assert out["severity"] == "critical"


def test_normalize_osv_npm_multi_affected_expansion():
    entry = {
        "id": "GHSA-multi-npm-aaaa",
        "published": "2025-06-01T00:00:00Z",
        "summary": "Affects two npm packages",
        "affected": [
            {
                "package": {"ecosystem": "npm", "name": "pkg-a"},
                "ranges": [{"type": "SEMVER",
                           "events": [{"introduced": "0"}, {"fixed": "1.0.0"}]}],
            },
            {
                "package": {"ecosystem": "npm", "name": "pkg-b"},
                "ranges": [{"type": "SEMVER",
                           "events": [{"introduced": "0"}, {"fixed": "2.0.0"}]}],
            },
        ],
        "severity": [{"type": "CVSS_V3",
                      "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
    }
    out = normalize_osv_entry(entry)
    assert isinstance(out, list)
    assert len(out) == 2
    pkgs = sorted(r["package"] for r in out)
    assert pkgs == ["pkg-a", "pkg-b"]
    assert {r["id"] for r in out} == {"GHSA-multi-npm-aaaa"}
