from pathlib import Path

import pytest
from pydantic import ValidationError

from agentsec.config import OpenAIJudgeConfig, OpenClawTargetConfig, PluginJudgeConfig

_FIXTURE_DIR = Path(__file__).parent / "fixtures"


def _example_yaml() -> str:
    return (_FIXTURE_DIR / "openclaw-target.example.yaml").read_text()


def test_round_trip_full_example(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(_example_yaml())
    cfg = OpenClawTargetConfig.from_yaml(p)
    assert cfg.name == "openclaw-prod"
    assert cfg.remote is not None and cfg.server_audit is not None
    assert cfg.remote.adapter == "openclaw-gateway"
    assert cfg.remote.target.startswith("https://")
    assert cfg.remote.test_suites == [Path("test_suites/openclaw/")]
    assert cfg.server_audit.host == "openclaw.example.com"
    assert cfg.scoring.severity_aggregation == "worst"
    assert cfg.scoring.category_weights == {}
    assert cfg.output.dir == Path("./report-2026-04-28/")
    assert "markdown" in cfg.output.formats and "json" in cfg.output.formats
    assert cfg.output.redactor_extra_patterns == Path("./redactor-extra.yaml")
    assert cfg.scoring.weight_remote == 0.5
    assert cfg.scoring.weight_server == 0.5


def test_remote_only(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: remote-only\n"
        "remote:\n"
        "  adapter: openclaw-gateway\n"
        "  target: https://x:18789\n"
        "  test_suites: [test_suites/openclaw/]\n"
        "output:\n"
        "  dir: ./out/\n"
    )
    cfg = OpenClawTargetConfig.from_yaml(p)
    assert cfg.remote is not None
    assert cfg.server_audit is None


def test_server_audit_only(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: audit-only\n"
        "server_audit:\n"
        "  host: h\n"
        "  user: u\n"
        "  key: ~/.ssh/id_rsa\n"
        "authorization:\n"
        "  consent_file: ./AUTHORIZATION.txt\n"
        "output:\n"
        "  dir: ./out/\n"
    )
    cfg = OpenClawTargetConfig.from_yaml(p)
    assert cfg.remote is None
    assert cfg.server_audit is not None and cfg.server_audit.host == "h"


def test_rejects_unknown_top_level_key(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: x\n"
        "totally_made_up_field: 1\n"
        "output:\n"
        "  dir: ./out/\n"
    )
    with pytest.raises(ValidationError, match="totally_made_up_field"):
        OpenClawTargetConfig.from_yaml(p)


def test_rejects_unknown_nested_key(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: x\n"
        "remote:\n"
        "  adapter: openclaw-gateway\n"
        "  target: https://x:18789\n"
        "  test_suites: [test_suites/openclaw/]\n"
        "  unknown_remote_key: 1\n"
        "output:\n"
        "  dir: ./out/\n"
    )
    with pytest.raises(ValidationError, match="unknown_remote_key"):
        OpenClawTargetConfig.from_yaml(p)


def test_requires_at_least_one_of_remote_or_server_audit(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: empty\n"
        "output:\n"
        "  dir: ./out/\n"
    )
    with pytest.raises(ValidationError, match="at least one of"):
        OpenClawTargetConfig.from_yaml(p)


def test_severity_aggregation_literal(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: x\n"
        "remote:\n"
        "  adapter: http\n"
        "  target: https://x\n"
        "  test_suites: [test_suites/openclaw/]\n"
        "output:\n"
        "  dir: ./out/\n"
        "scoring:\n"
        "  severity_aggregation: not_a_real_mode\n"
    )
    with pytest.raises(ValidationError, match="severity_aggregation"):
        OpenClawTargetConfig.from_yaml(p)


@pytest.mark.parametrize(
    "submodel_yaml, unknown_key",
    [
        # FixtureConfig
        (
            "name: x\n"
            "remote:\n"
            "  adapter: a\n  target: https://x\n  test_suites: []\n"
            "  fixture: {bad_fixture_field: 1}\n"
            "output: {dir: ./o/}\n",
            "bad_fixture_field",
        ),
        # NetworkObserverConfigSection
        (
            "name: x\n"
            "remote:\n"
            "  adapter: a\n  target: https://x\n  test_suites: []\n"
            "  network_observer: {bad_observer_field: 1}\n"
            "output: {dir: ./o/}\n",
            "bad_observer_field",
        ),
        # ServerAuditConfig
        (
            "name: x\n"
            "server_audit:\n"
            "  host: h\n  user: u\n  key: ~/.ssh/k\n"
            "  bad_audit_field: 1\n"
            "output: {dir: ./o/}\n",
            "bad_audit_field",
        ),
        # OutputConfig
        (
            "name: x\n"
            "remote:\n"
            "  adapter: a\n  target: https://x\n  test_suites: []\n"
            "output: {dir: ./o/, bad_output_field: 1}\n",
            "bad_output_field",
        ),
        # AuthorizationConfig
        (
            "name: x\n"
            "remote:\n"
            "  adapter: a\n  target: https://x\n  test_suites: []\n"
            "output: {dir: ./o/}\n"
            "authorization: {bad_auth_field: 1}\n",
            "bad_auth_field",
        ),
        # ScoringConfig
        (
            "name: x\n"
            "remote:\n"
            "  adapter: a\n  target: https://x\n  test_suites: []\n"
            "output: {dir: ./o/}\n"
            "scoring: {bad_scoring_field: 1}\n",
            "bad_scoring_field",
        ),
    ],
    ids=[
        "fixture", "network_observer", "server_audit", "output",
        "authorization", "scoring",
    ],
)
def test_extra_forbid_on_every_submodel(tmp_path, submodel_yaml, unknown_key):
    """Each Pydantic sub-model must carry `extra="forbid"`. A typo in any
    nested section must surface as a ValidationError that mentions the
    offending key, so a future refactor can't silently relax this guarantee
    on one sub-model."""
    p = tmp_path / "cfg.yaml"
    p.write_text(submodel_yaml)
    with pytest.raises(ValidationError, match=unknown_key):
        OpenClawTargetConfig.from_yaml(p)


# ── MultiTargetConfig ────────────────────────────────────────────────────────

from agentsec.config import (  # noqa: E402
    MultiTargetConfig,
    OutputConfig,
    RemoteConfig,
    TargetEntry,
)


def test_multi_target_config_parse_two_targets():
    cfg = MultiTargetConfig.model_validate({
        "output_base": "./multi-report/",
        "targets": [
            {
                "name": "prod",
                "remote": {"adapter": "http", "target": "http://prod:8080", "test_suites": []},
            },
            {
                "name": "staging",
                "remote": {"adapter": "http", "target": "http://staging:8080", "test_suites": []},
            },
        ],
    })
    assert len(cfg.targets) == 2
    assert cfg.effective_max_parallel == 2  # default = len(targets)


def test_multi_target_config_explicit_max_parallel():
    cfg = MultiTargetConfig.model_validate({
        "output_base": "./out/",
        "max_parallel": 1,
        "targets": [
            {"name": "a", "remote": {"adapter": "http", "target": "http://a", "test_suites": []}},
            {"name": "b", "remote": {"adapter": "http", "target": "http://b", "test_suites": []}},
        ],
    })
    assert cfg.effective_max_parallel == 1


def test_multi_target_config_missing_output_base():
    with pytest.raises(ValidationError):
        MultiTargetConfig.model_validate({
            "targets": [
                {
                    "name": "a",
                    "remote": {"adapter": "http", "target": "http://a", "test_suites": []},
                },
            ],
        })


def test_multi_target_config_duplicate_names_rejected():
    with pytest.raises(ValidationError, match="duplicate target names"):
        MultiTargetConfig.model_validate({
            "output_base": "./out/",
            "targets": [
                {
                    "name": "prod",
                    "remote": {"adapter": "http", "target": "http://a", "test_suites": []},
                },
                {
                    "name": "prod",
                    "remote": {"adapter": "http", "target": "http://b", "test_suites": []},
                },
            ],
        })


def test_multi_target_config_empty_targets_rejected():
    with pytest.raises(ValidationError):
        MultiTargetConfig.model_validate({"output_base": "./out/", "targets": []})


def test_multi_target_config_from_yaml(tmp_path):
    p = tmp_path / "multi.yaml"
    p.write_text(
        "output_base: ./multi-report/\n"
        "targets:\n"
        "  - name: prod\n"
        "    remote:\n"
        "      adapter: http\n"
        "      target: http://prod\n"
        "      test_suites: []\n"
    )
    cfg = MultiTargetConfig.from_yaml(p)
    assert cfg.targets[0].name == "prod"
    assert cfg.output_base == Path("./multi-report/")


# ── TargetEntry ───────────────────────────────────────────────────────────────

def test_target_entry_output_resolves_from_output_base():
    entry = TargetEntry(
        name="prod",
        remote=RemoteConfig(adapter="http", target="http://x", test_suites=[]),
    )
    openclaw_cfg = entry.to_openclaw_config(Path("./multi-report/"))
    assert openclaw_cfg.output.dir == Path("./multi-report/prod")


def test_target_entry_explicit_output_preserved():
    entry = TargetEntry(
        name="prod",
        remote=RemoteConfig(adapter="http", target="http://x", test_suites=[]),
        output=OutputConfig(dir=Path("/custom/out/")),
    )
    openclaw_cfg = entry.to_openclaw_config(Path("./multi-report/"))
    assert openclaw_cfg.output.dir == Path("/custom/out/")


def test_target_entry_rejects_neither_remote_nor_server_audit():
    with pytest.raises(ValidationError, match="at least one of"):
        TargetEntry(name="empty")


def test_target_entry_rejects_empty_name():
    with pytest.raises(ValidationError):
        TargetEntry(
            name="",
            remote=RemoteConfig(adapter="http", target="http://x", test_suites=[]),
        )


def test_multi_target_config_rejects_unknown_key():
    with pytest.raises(ValidationError, match="bad_key"):
        MultiTargetConfig.model_validate({
            "output_base": "./out/",
            "bad_key": 1,
            "targets": [
                {
                    "name": "a",
                    "remote": {"adapter": "http", "target": "http://a", "test_suites": []},
                },
            ],
        })


# ── Custom judge config tests ──────────────────────────────────────────────


def test_openai_judge_config_valid():
    cfg = OpenAIJudgeConfig.model_validate({
        "type": "openai_compatible",
        "model": "gpt-4o",
        "base_url": "https://api.openai.com/v1",
        "api_key_env": "OPENAI_API_KEY",
    })
    assert cfg.model == "gpt-4o"
    assert cfg.timeout == 30  # default


def test_openai_judge_config_missing_model():
    with pytest.raises(ValidationError):
        OpenAIJudgeConfig.model_validate({
            "type": "openai_compatible",
            "base_url": "https://api.openai.com/v1",
            "api_key_env": "OPENAI_API_KEY",
        })


def test_plugin_judge_config_valid():
    cfg = PluginJudgeConfig.model_validate({
        "type": "plugin",
        "path": "./my_judge.py",
    })
    assert cfg.path == Path("my_judge.py")


def test_openclaw_target_config_with_openai_judge(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: t\n"
        "remote:\n"
        "  adapter: openclaw-gateway\n"
        "  target: https://x\n"
        "  test_suites: [test_suites/openclaw/]\n"
        "output:\n"
        "  dir: ./out/\n"
        "judge:\n"
        "  type: openai_compatible\n"
        "  model: gpt-4o\n"
        "  base_url: https://api.openai.com/v1\n"
        "  api_key_env: MY_KEY\n"
    )
    cfg = OpenClawTargetConfig.from_yaml(p)
    assert isinstance(cfg.judge, OpenAIJudgeConfig)
    assert cfg.judge.model == "gpt-4o"


def test_openclaw_target_config_with_plugin_judge(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: t\n"
        "remote:\n"
        "  adapter: openclaw-gateway\n"
        "  target: https://x\n"
        "  test_suites: [test_suites/openclaw/]\n"
        "output:\n"
        "  dir: ./out/\n"
        "judge:\n"
        "  type: plugin\n"
        "  path: ./my_judge.py\n"
    )
    cfg = OpenClawTargetConfig.from_yaml(p)
    assert isinstance(cfg.judge, PluginJudgeConfig)
    assert cfg.judge.path == Path("my_judge.py")


def test_openclaw_target_config_unknown_judge_type(tmp_path):
    p = tmp_path / "cfg.yaml"
    p.write_text(
        "name: t\n"
        "remote:\n"
        "  adapter: openclaw-gateway\n"
        "  target: https://x\n"
        "  test_suites: [test_suites/openclaw/]\n"
        "output:\n"
        "  dir: ./out/\n"
        "judge:\n"
        "  type: nonexistent\n"
        "  model: gpt-4o\n"
    )
    with pytest.raises(ValidationError):
        OpenClawTargetConfig.from_yaml(p)


def test_target_entry_to_openclaw_config_forwards_judge(tmp_path):
    from agentsec.config import OpenAIJudgeConfig, TargetEntry
    entry = TargetEntry.model_validate({
        "name": "t",
        "remote": {
            "adapter": "openclaw-gateway",
            "target": "https://x",
            "test_suites": ["test_suites/openclaw/"],
        },
        "judge": {
            "type": "openai_compatible",
            "model": "gpt-4o",
            "base_url": "https://api.openai.com/v1",
            "api_key_env": "MY_KEY",
        },
    })
    cfg = entry.to_openclaw_config(tmp_path)
    assert isinstance(cfg.judge, OpenAIJudgeConfig)
    assert cfg.judge.model == "gpt-4o"


def test_target_entry_to_openclaw_config_sets_config_path(tmp_path):
    from agentsec.config import TargetEntry
    entry = TargetEntry.model_validate({
        "name": "t",
        "remote": {
            "adapter": "openclaw-gateway",
            "target": "https://x",
            "test_suites": ["test_suites/openclaw/"],
        },
    })
    fake_path = tmp_path / "multi.yaml"
    cfg = entry.to_openclaw_config(tmp_path, config_path=fake_path)
    assert cfg._config_path == fake_path


# ── LogReviewConfig ──────────────────────────────────────────────────────────

def test_log_review_config_defaults():
    from agentsec.config import LogReviewConfig
    cfg = LogReviewConfig()
    assert cfg.journald_since_hours == 24
    assert cfg.journald_max_lines == 10_000


def test_log_review_config_bounds():
    from agentsec.config import LogReviewConfig
    with pytest.raises(ValidationError):
        LogReviewConfig(journald_since_hours=0)
    with pytest.raises(ValidationError):
        LogReviewConfig(journald_since_hours=200)  # > 168
    with pytest.raises(ValidationError):
        LogReviewConfig(journald_max_lines=99)
    with pytest.raises(ValidationError):
        LogReviewConfig(journald_max_lines=200_000)


def test_log_review_config_forbids_extra():
    from agentsec.config import LogReviewConfig
    with pytest.raises(ValidationError):
        LogReviewConfig(unknown_field=1)


def test_server_audit_config_has_log_review_default():
    from pathlib import Path

    from agentsec.config import ServerAuditConfig
    sa = ServerAuditConfig(host="h", user="u", key=Path("/k"))
    assert sa.log_review.journald_since_hours == 24
