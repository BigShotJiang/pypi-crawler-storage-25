"""Discriminated Assertion union — `parse_assertion(dict) -> Assertion`
returns the concrete subclass or raises ValidationError."""

import pytest
from pydantic import TypeAdapter, ValidationError

from agentsec.evaluator.assertions import (
    Assertion,
    ConfigKeyNotChanged,
    FileNotCreated,
    JsonPathEquals,
    OutboundRequestNotTo,
    ResponseNotContainsPattern,
    ResponseStatusIn,
    ToolEventNotInvoked,
    parse_assertion,
)


def test_parse_response_status_in():
    a = parse_assertion({"type": "response_status_in", "statuses": [200, 401]})
    assert isinstance(a, ResponseStatusIn)
    assert a.statuses == [200, 401]


def test_parse_response_not_contains_pattern():
    a = parse_assertion({
        "type": "response_not_contains_pattern", "pattern": r"ssh-rsa\s+AAAA"
    })
    assert isinstance(a, ResponseNotContainsPattern)


def test_parse_outbound_request_not_to():
    a = parse_assertion({"type": "outbound_request_not_to", "target": "*.evil.test"})
    assert isinstance(a, OutboundRequestNotTo)


def test_parse_json_path_equals():
    a = parse_assertion(
        {"type": "json_path_equals", "path": "$.x", "value": 1}
    )
    assert isinstance(a, JsonPathEquals)


def test_unknown_type_raises_validation_error():
    with pytest.raises(ValidationError):
        parse_assertion({"type": "made_up", "x": 1})


def test_missing_required_field_raises():
    with pytest.raises(ValidationError):
        parse_assertion({"type": "response_status_in"})  # missing statuses


def test_extra_field_raises():
    with pytest.raises(ValidationError):
        parse_assertion(
            {"type": "response_status_in", "statuses": [200], "bogus": True}
        )


def test_assertion_type_alias_works_as_standalone_type_adapter():
    """The `Assertion` `Annotated` alias must keep its discriminator metadata
    when callers wrap it in their own TypeAdapter (the loader will do this in
    a future task, so it must not silently lose validation)."""
    ta = TypeAdapter(Assertion)
    a = ta.validate_python(
        {"type": "response_status_in", "statuses": [200]}
    )
    assert isinstance(a, ResponseStatusIn)


@pytest.mark.parametrize("payload,expected", [
    ({"type": "response_not_contains_pattern", "pattern": "x"}, ResponseNotContainsPattern),
    ({"type": "response_status_in", "statuses": [200]}, ResponseStatusIn),
    ({"type": "json_path_equals", "path": "$.x", "value": 1}, JsonPathEquals),
    ({"type": "outbound_request_not_to", "target": "x.test"}, OutboundRequestNotTo),
    ({"type": "file_not_created", "path": "/tmp/x"}, FileNotCreated),
    ({"type": "config_key_not_changed", "key": "x"}, ConfigKeyNotChanged),
    ({"type": "tool_event_not_invoked", "tool_name": "shell.exec"}, ToolEventNotInvoked),
])
def test_all_seven_types_round_trip_through_parse(payload, expected):
    """Every member of the Assertion union must be reachable via
    parse_assertion. Catches accidental drops from registry's Union list."""
    a = parse_assertion(payload)
    assert isinstance(a, expected)
    assert a.type == payload["type"]
