import subprocess
import sys
from pathlib import Path

SCRIPT = Path("scripts/check_owasp_coverage.py").resolve()


def _run(suite_dir: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(SCRIPT), str(suite_dir)],
        capture_output=True, text=True,
    )


def _write_case(path: Path, case_id: str, refs: list[str]) -> None:
    path.write_text(
        f"- id: {case_id}\n"
        "  category: x\n"
        "  description: d\n"
        "  attack: a\n"
        "  expected_behavior: refusal\n"
        "  severity: low\n"
        f"  owasp_refs: {refs}\n"
    )


def _fill_agentic(suite: Path, prefix: str = "ag") -> None:
    """Write 3 cases for each of the 17 Agentic v1.1 threats."""
    for i in range(1, 18):
        ref = f"AGENTIC-T{i}"
        for j in range(3):
            _write_case(suite / f"{prefix}_t{i}_{j}.yaml", f"{prefix}-{i}-{j}", [ref])


def test_passes_when_all_llm_top10_have_at_least_one_case(tmp_path):
    suite = tmp_path / "suite"
    suite.mkdir()
    for i in range(1, 11):
        ref = f"LLM{i:02d}:2025"
        _write_case(suite / f"f{i}.yaml", f"c-{i}", [ref])
    _fill_agentic(suite)
    _fill_mcp(suite)
    r = _run(suite)
    assert r.returncode == 0, r.stderr
    assert "OK" in r.stdout


def test_fails_when_a_llm_top10_category_has_zero_cases(tmp_path):
    suite = tmp_path / "suite"
    suite.mkdir()
    # Only LLM01 covered.
    _write_case(suite / "f.yaml", "c-1", ["LLM01:2025"])
    r = _run(suite)
    assert r.returncode != 0
    # at minimum complains about a missing category beyond LLM01
    assert "LLM02:2025" in r.stderr
    assert "LLM10:2025" in r.stderr


def test_fails_on_invalid_owasp_ref(tmp_path):
    suite = tmp_path / "suite"
    suite.mkdir()
    # Invalid prefix — loader will raise during validation.
    _write_case(suite / "f.yaml", "c-1", ["LLM01"])
    r = _run(suite)
    assert r.returncode != 0


def test_recurses_into_subdirectories(tmp_path):
    """Real test_suites tree has openclaw/ subdir; the script must walk it."""
    suite = tmp_path / "suite"
    suite.mkdir()
    _write_case(suite / "top.yaml", "top-1", ["LLM01:2025"])
    sub = suite / "subdir"
    sub.mkdir()
    for i in range(2, 11):
        ref = f"LLM{i:02d}:2025"
        _write_case(sub / f"f{i}.yaml", f"sub-{i}", [ref])
    _fill_agentic(suite)
    _fill_mcp(suite)
    r = _run(suite)
    assert r.returncode == 0, f"stderr={r.stderr}\nstdout={r.stdout}"


def test_passes_when_all_agentic_have_at_least_three_cases(tmp_path):
    suite = tmp_path / "suite"
    suite.mkdir()
    # Cover every LLM Top 10 with one case each (existing floor).
    for i in range(1, 11):
        ref = f"LLM{i:02d}:2025"
        _write_case(suite / f"llm{i}.yaml", f"llm-{i}", [ref])
    # Cover every Agentic threat with three cases each.
    for i in range(1, 18):
        ref = f"AGENTIC-T{i}"
        for j in range(3):
            _write_case(suite / f"a{i}_{j}.yaml", f"a-{i}-{j}", [ref])
    _fill_mcp(suite)
    r = _run(suite)
    assert r.returncode == 0, r.stderr
    assert "OK" in r.stdout


def test_fails_when_an_agentic_threat_has_under_three_cases(tmp_path):
    suite = tmp_path / "suite"
    suite.mkdir()
    # LLM Top 10 fully covered.
    for i in range(1, 11):
        ref = f"LLM{i:02d}:2025"
        _write_case(suite / f"llm{i}.yaml", f"llm-{i}", [ref])
    # Most Agentic threats covered with 3, but T6 only has 2.
    for i in range(1, 18):
        ref = f"AGENTIC-T{i}"
        n = 2 if i == 6 else 3
        for j in range(n):
            _write_case(suite / f"a{i}_{j}.yaml", f"a-{i}-{j}", [ref])
    r = _run(suite)
    assert r.returncode != 0
    assert "AGENTIC-T6" in r.stderr
    assert "below threshold" in r.stderr or "3" in r.stderr


def _fill_mcp(suite: Path, prefix: str = "mcp", count: int = 14) -> None:
    """Write `count` cases for each of the 10 MCP curated v1 threats."""
    for m in range(1, 11):
        ref = f"MCP{m}"
        for n in range(count):
            _write_case(suite / f"{prefix}_m{m}_{n}.yaml", f"{prefix}-{m}-{n}", [ref])


def test_fails_when_mcp_threat_below_floor(tmp_path):
    """Provide minimal LLM + Agentic coverage to clear those floors,
    but only 13 cases for MCP1 — below MCP floor of 14."""
    suite = tmp_path / "suite"
    suite.mkdir()
    # 1 case per LLM Top 10 (LLM floor = 1)
    for i in range(1, 11):
        _write_case(suite / f"llm{i}.yaml", f"llm-{i}", [f"LLM{i:02d}:2025"])
    # 3 cases per AGENTIC-T1..T17 (Agentic floor = 3)
    _fill_agentic(suite)
    # Cover MCP2..MCP10 with 14 each (meet floor), MCP1 only 13 (BELOW floor)
    for m in range(2, 11):
        for n in range(14):
            _write_case(suite / f"mcp_m{m}_{n}.yaml", f"mcp-{m}-{n}", [f"MCP{m}"])
    for n in range(13):
        _write_case(suite / f"mcp_m1_{n}.yaml", f"mcp-1-{n}", ["MCP1"])

    result = _run(suite)
    assert result.returncode == 1, result.stdout
    assert "MCP1" in result.stderr


def test_passes_when_all_floors_met(tmp_path):
    suite = tmp_path / "suite"
    suite.mkdir()
    # 1 case per LLM Top 10
    for i in range(1, 11):
        _write_case(suite / f"llm{i}.yaml", f"llm-{i}", [f"LLM{i:02d}:2025"])
    # 3 cases per Agentic threat
    _fill_agentic(suite)
    # 10 cases per MCP threat
    _fill_mcp(suite)

    result = _run(suite)
    assert result.returncode == 0, result.stderr
    assert "OK" in result.stdout
