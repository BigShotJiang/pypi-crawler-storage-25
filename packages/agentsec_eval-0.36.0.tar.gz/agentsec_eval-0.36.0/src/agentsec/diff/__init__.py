"""Two-input diff for `agentsec evaluate` reports — Phase 5 v0.4.0.

See `docs/superpowers/specs/2026-04-30-agentsec-diff-design.md`.
"""

from .findings_delta import (
    DriftPair,
    FindingsDelta,
    SeverityChange,
    diff_findings,
)
from .loader import (
    LoaderError,
    ReportData,
    load_findings,
    load_report_dir,
)
from .renderer import render_diff_report
from .score_delta import (
    ScoreDelta,
    ScoreMeta,
    ScoreRow,
    diff_scores,
)

__all__ = [
    "DriftPair",
    "FindingsDelta",
    "LoaderError",
    "ReportData",
    "ScoreDelta",
    "ScoreMeta",
    "ScoreRow",
    "SeverityChange",
    "diff_findings",
    "diff_scores",
    "load_findings",
    "load_report_dir",
    "render_diff_report",
]
