"""Loader for `agentsec evaluate` report directories. Spec §6.1."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from pydantic import ValidationError

from agentsec.audit.findings import Finding

from .score_delta import ScoreMeta


class LoaderError(Exception):
    """Loader-side input error (raised; cli.py converts to exit 1)."""


@dataclass(frozen=True)
class ReportData:
    findings: list[Finding]
    score_meta: ScoreMeta | None
    label: str
    date: str | None


_FINDINGS_MAX_BYTES = 50 * 1024 * 1024  # 50 MB cap on findings.json

_DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")
_META_RE = re.compile(r"<!--\s*meta:(\w+)\s+value:([^ ]+)\s*-->")
_COVERAGE_VERDICT_RE = re.compile(r"verdict_coverage=(\d+(?:\.\d+)?%|N/A)")
_COVERAGE_ERROR_RE = re.compile(r"error_rate=(\d+(?:\.\d+)?%|N/A)")

_REQUIRED_META_KEYS = {"remote_score", "server_score", "combined_score", "grade"}


def _parse_score_value(raw: str) -> float | None:
    if raw == "None":
        return None
    return float(raw)


def _parse_pct(raw: str) -> float | None:
    if raw == "N/A":
        return None
    # raw is like "100.00%"
    return float(raw.rstrip("%")) / 100.0


def _parse_score_meta(text: str) -> ScoreMeta | None:
    head = text[:8000]  # first ~200 lines is enough; cap for safety
    found: dict[str, str] = {m.group(1): m.group(2) for m in _META_RE.finditer(head)}
    if not _REQUIRED_META_KEYS.issubset(found):
        return None

    try:
        remote = _parse_score_value(found["remote_score"])
        server = _parse_score_value(found["server_score"])
        combined = _parse_score_value(found["combined_score"])
    except ValueError:
        return None
    grade = found["grade"]

    vc_match = _COVERAGE_VERDICT_RE.search(text)
    er_match = _COVERAGE_ERROR_RE.search(text)
    verdict_coverage = _parse_pct(vc_match.group(1)) if vc_match else None
    error_rate = _parse_pct(er_match.group(1)) if er_match else None

    return ScoreMeta(
        remote_score=remote, server_score=server, combined_score=combined,
        grade=grade, verdict_coverage=verdict_coverage, error_rate=error_rate,
    )


def load_findings(path: Path) -> list[Finding]:
    if not path.exists():
        raise LoaderError(f"{path} not found")
    size = path.stat().st_size
    if size > _FINDINGS_MAX_BYTES:
        raise LoaderError(
            f"{path} too large ({size} bytes; max {_FINDINGS_MAX_BYTES})"
        )
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise LoaderError(f"{path} malformed JSON: {e}") from e
    if not isinstance(raw, list):
        raise LoaderError(f"{path} expected JSON array, got {type(raw).__name__}")
    try:
        return [Finding(**item) for item in raw]
    except ValidationError as e:
        raise LoaderError(f"{path} malformed Finding: {e}") from e


def load_report_dir(path: Path) -> ReportData:
    try:
        path = path.resolve(strict=True)
    except (FileNotFoundError, RuntimeError) as e:
        raise LoaderError(f"directory not found: {path}") from e
    if not path.is_dir():
        raise LoaderError(f"not a directory: {path}")
    findings = load_findings(path / "findings.json")
    label = path.name
    m = _DATE_RE.search(label)
    date = m.group(1) if m else None

    score_meta: ScoreMeta | None = None
    combined_md = path / "combined-report.md"
    if combined_md.exists():
        score_meta = _parse_score_meta(combined_md.read_text(encoding="utf-8"))

    return ReportData(findings=findings, score_meta=score_meta,
                      label=label, date=date)
