"""Score / coverage / grade delta with regression flagging. Spec §6."""

from __future__ import annotations

from dataclasses import dataclass, field

REGRESSION_THRESHOLD: float = 5.0

LOW_COVERAGE_THRESHOLD: float = 0.7
HIGH_ERROR_RATE_THRESHOLD: float = 0.1


_GRADE_RANK: dict[str, int] = {"A": 4, "B": 3, "C": 2, "D": 1, "F": 0}


@dataclass(frozen=True)
class ScoreMeta:
    remote_score: float | None
    server_score: float | None
    combined_score: float | None
    grade: str
    verdict_coverage: float | None
    error_rate: float | None


@dataclass(frozen=True)
class ScoreRow:
    metric: str
    baseline_value: str
    current_value: str
    delta_label: str
    is_regression: bool
    is_improvement: bool


@dataclass(frozen=True)
class ScoreDelta:
    rows: list[ScoreRow] = field(default_factory=list)
    has_regression: bool = False


def _fmt_score(v: float | None) -> str:
    return "n/a" if v is None else f"{v:.1f}"


def _numeric_row(metric: str, b: float | None, c: float | None) -> ScoreRow:
    if b is None or c is None:
        return ScoreRow(
            metric=metric,
            baseline_value=_fmt_score(b),
            current_value=_fmt_score(c),
            delta_label="—",
            is_regression=False,
            is_improvement=False,
        )
    delta = c - b
    if delta < -REGRESSION_THRESHOLD:
        label = f"**REGRESSION: {delta:+.1f}**"
        return ScoreRow(
            metric=metric,
            baseline_value=_fmt_score(b),
            current_value=_fmt_score(c),
            delta_label=label,
            is_regression=True,
            is_improvement=False,
        )
    if delta > REGRESSION_THRESHOLD:
        label = f"**IMPROVED: {delta:+.1f}**"
        return ScoreRow(
            metric=metric,
            baseline_value=_fmt_score(b),
            current_value=_fmt_score(c),
            delta_label=label,
            is_regression=False,
            is_improvement=True,
        )
    if delta == 0:
        return ScoreRow(
            metric=metric,
            baseline_value=_fmt_score(b),
            current_value=_fmt_score(c),
            delta_label="—",
            is_regression=False,
            is_improvement=False,
        )
    return ScoreRow(
        metric=metric,
        baseline_value=_fmt_score(b),
        current_value=_fmt_score(c),
        delta_label=f"{delta:+.1f}",
        is_regression=False,
        is_improvement=False,
    )


def _grade_rank(grade: str) -> int | None:
    if grade == "INSUFFICIENT_COVERAGE":
        return -1
    if grade == "NOT_SCORED":
        return None
    return _GRADE_RANK.get(grade)  # None for unknown letters (A- etc.)


def _grade_render(grade: str) -> str:
    """Per spec §6.2: NOT_SCORED renders as 'n/a'; unknown letters render as-is."""
    return "n/a" if grade == "NOT_SCORED" else grade


def _grade_row(b: str, c: str) -> ScoreRow:
    rb = _grade_rank(b)
    rc = _grade_rank(c)
    if rb is None or rc is None:
        rb_str = _grade_render(b)
        rc_str = _grade_render(c)
        return ScoreRow(
            metric="grade",
            baseline_value=rb_str,
            current_value=rc_str,
            delta_label="—" if b == c else f"{rb_str} → {rc_str}",
            is_regression=False,
            is_improvement=False,
        )
    if rc < rb:
        return ScoreRow(
            metric="grade",
            baseline_value=b,
            current_value=c,
            delta_label=f"**REGRESSION: {b} → {c}**",
            is_regression=True,
            is_improvement=False,
        )
    if rc > rb:
        return ScoreRow(
            metric="grade",
            baseline_value=b,
            current_value=c,
            delta_label=f"**IMPROVED: {b} → {c}**",
            is_regression=False,
            is_improvement=True,
        )
    return ScoreRow(
        metric="grade",
        baseline_value=b,
        current_value=c,
        delta_label="—",
        is_regression=False,
        is_improvement=False,
    )


def _fmt_pct(v: float | None) -> str:
    return "n/a" if v is None else f"{v:.2%}"


def _coverage_row(b: float | None, c: float | None) -> ScoreRow:
    if b is None or c is None:
        return ScoreRow(
            metric="verdict_coverage",
            baseline_value=_fmt_pct(b),
            current_value=_fmt_pct(c),
            delta_label="—",
            is_regression=False,
            is_improvement=False,
        )
    was_low = b < LOW_COVERAGE_THRESHOLD
    is_low = c < LOW_COVERAGE_THRESHOLD
    if not was_low and is_low:
        return ScoreRow(
            metric="verdict_coverage",
            baseline_value=_fmt_pct(b),
            current_value=_fmt_pct(c),
            delta_label="**REGRESSION: low coverage**",
            is_regression=True,
            is_improvement=False,
        )
    if was_low and not is_low:
        return ScoreRow(
            metric="verdict_coverage",
            baseline_value=_fmt_pct(b),
            current_value=_fmt_pct(c),
            delta_label="**IMPROVED: coverage restored**",
            is_regression=False,
            is_improvement=True,
        )
    return ScoreRow(
        metric="verdict_coverage",
        baseline_value=_fmt_pct(b),
        current_value=_fmt_pct(c),
        delta_label="—",
        is_regression=False,
        is_improvement=False,
    )


def _error_rate_row(b: float | None, c: float | None) -> ScoreRow:
    if b is None or c is None:
        return ScoreRow(
            metric="error_rate",
            baseline_value=_fmt_pct(b),
            current_value=_fmt_pct(c),
            delta_label="—",
            is_regression=False,
            is_improvement=False,
        )
    was_high = b > HIGH_ERROR_RATE_THRESHOLD
    is_high = c > HIGH_ERROR_RATE_THRESHOLD
    if not was_high and is_high:
        return ScoreRow(
            metric="error_rate",
            baseline_value=_fmt_pct(b),
            current_value=_fmt_pct(c),
            delta_label="**REGRESSION: high error rate**",
            is_regression=True,
            is_improvement=False,
        )
    if was_high and not is_high:
        return ScoreRow(
            metric="error_rate",
            baseline_value=_fmt_pct(b),
            current_value=_fmt_pct(c),
            delta_label="**IMPROVED: error rate normalized**",
            is_regression=False,
            is_improvement=True,
        )
    return ScoreRow(
        metric="error_rate",
        baseline_value=_fmt_pct(b),
        current_value=_fmt_pct(c),
        delta_label="—",
        is_regression=False,
        is_improvement=False,
    )


def diff_scores(baseline: ScoreMeta, current: ScoreMeta) -> ScoreDelta:
    rows: list[ScoreRow] = [
        _numeric_row("combined_score", baseline.combined_score, current.combined_score),
        _grade_row(baseline.grade, current.grade),
        _numeric_row("remote_score", baseline.remote_score, current.remote_score),
        _numeric_row("server_score", baseline.server_score, current.server_score),
        _coverage_row(baseline.verdict_coverage, current.verdict_coverage),
        _error_rate_row(baseline.error_rate, current.error_rate),
    ]
    has_regression = any(r.is_regression for r in rows)
    return ScoreDelta(rows=rows, has_regression=has_regression)
