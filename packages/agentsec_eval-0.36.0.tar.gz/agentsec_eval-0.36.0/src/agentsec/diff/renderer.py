"""Markdown renderer for diff reports. Spec §7."""

from __future__ import annotations

import json as _json

from agentsec.audit.findings import Finding

from .findings_delta import DriftPair, FindingsDelta, SeverityChange
from .loader import ReportData
from .score_delta import diff_scores


def _md_cell(s: str) -> str:
    """Sanitize a string for safe interpolation into a Markdown table cell or
    inline span. Neutralizes the table-separator pipe, backticks (which would
    open inline code), control chars (newline / CR), and angle brackets (which
    would render as raw HTML in some Markdown viewers). Spec §7.2."""
    return (
        s.replace("\\", "\\\\")
        .replace("`", "\\`")
        .replace("|", "\\|")
        .replace("\r", " ")
        .replace("\n", " ")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def render_diff_report(
    *,
    baseline: ReportData,
    current: ReportData,
    findings_delta: FindingsDelta,
) -> str:
    lines: list[str] = [f"# AgentSec 报告差异：{baseline.label} → {current.label}", ""]
    lines.append(f"**基线**：{baseline.label}{_date_suffix(baseline)}")
    lines.append(f"**当前**：{current.label}{_date_suffix(current)}")
    lines.append("")

    # When both sides are LOW_COVERAGE we surface a single banner naming
    # `current`; the score table itself shows both grades so duplicating the
    # warning adds noise.
    if _is_low_coverage(current) or _is_low_coverage(baseline):
        side = "当前" if _is_low_coverage(current) else "基线"
        lines.append(
            f"> **警告**：{side}报告 LOW_COVERAGE —— 评分差异结果可能不可靠。"
        )
        lines.append("")

    lines += _score_section(baseline, current)
    lines += [""]
    lines += _findings_section(findings_delta)
    return "\n".join(lines).rstrip() + "\n"


def _date_suffix(data: ReportData) -> str:
    return f" ({data.date})" if data.date else ""


def _is_low_coverage(data: ReportData) -> bool:
    return data.score_meta is not None and data.score_meta.grade == "INSUFFICIENT_COVERAGE"


def _score_section(baseline: ReportData, current: ReportData) -> list[str]:
    if baseline.score_meta is None and current.score_meta is None:
        return [
            "## 评分差异", "",
            f"{baseline.label} 和 {current.label} 的评分均不可用"
            "（combined-report.md 缺失或格式错误）",
        ]
    if baseline.score_meta is None or current.score_meta is None:
        # Use the label (directory basename) rather than literal "baseline" /
        # "current" so multi-run digests can disambiguate which file is missing.
        missing = baseline.label if baseline.score_meta is None else current.label
        return [
            "## 评分差异", "",
            f"{missing} 的评分不可用"
            "（combined-report.md 缺失或格式错误）",
        ]
    sd = diff_scores(baseline.score_meta, current.score_meta)
    out = ["## 评分差异", "",
           "| 指标 | 基线 | 当前 | Δ |",
           "|------|------|------|---|"]
    for r in sd.rows:
        out.append(
            f"| {r.metric} | {r.baseline_value} | "
            f"{r.current_value} | {r.delta_label} |"
        )
    return out


def _findings_section(delta: FindingsDelta) -> list[str]:
    if not _has_any(delta):
        return ["## Findings 差异", "", "两侧均无 findings。"]

    out = [
        "## Findings 差异", "",
        f"**新增：{len(delta.added)}** | "
        f"**移除：{len(delta.removed)}** | "
        f"**稳定：{len(delta.stable)}** | "
        f"**严重度变化：{len(delta.severity_changed)}** | "
        f"**证据漂移：{len(delta.evidence_drifted)}**",
        "",
    ]
    if delta.added:
        out += _findings_table("新增 findings", delta.added)
    if delta.removed:
        out += _findings_table("移除 findings", delta.removed)
    if delta.severity_changed:
        out += _severity_table(delta.severity_changed)
    if delta.evidence_drifted:
        out += _drift_section(delta.evidence_drifted)
    if delta.stable:
        out += _stable_section(delta.stable)
    return out


_SEVERITY_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def _findings_table(heading: str, fs: list[Finding]) -> list[str]:
    out = [f"### {heading}（{len(fs)}）", "",
           "| 严重度 | Check | 标题 | Fingerprint |",
           "|--------|-------|------|-------------|"]
    for f in fs:
        out.append(
            f"| {f.severity} | {_md_cell(f.check)} | {_md_cell(f.title)} | "
            f"`{f.fingerprint[:8]}` |"
        )
    out.append("")
    return out


def _severity_table(scs: list[SeverityChange]) -> list[str]:
    out = [f"### 严重度变化（{len(scs)}）", "",
           "| 旧 → 新 | Check | 标题 | Fingerprint |",
           "|---------|-------|------|-------------|"]
    for s in scs:
        old_rank = _SEVERITY_RANK.get(s.old_severity, 99)
        new_rank = _SEVERITY_RANK.get(s.new_severity, 99)
        new_cell = (f"**{s.new_severity}**" if new_rank < old_rank
                    else s.new_severity)
        out.append(
            f"| {s.old_severity} → {new_cell} | {_md_cell(s.check)} | {_md_cell(s.title)} | "
            f"`{s.fingerprint[:8]}` |"
        )
    out.append("")
    return out


def _drift_section(pairs: list[DriftPair]) -> list[str]:
    out = [f"### 证据漂移（{len(pairs)}）", ""]
    for p in pairs:
        out += [
            f"**`{_md_cell(p.check)}` —— {_md_cell(p.title)}**"
            " *(可能是同一问题，证据发生变化)*", "",
            "基线：", "```json",
            _json.dumps(p.baseline.evidence, indent=2, sort_keys=True),
            "```", "",
            "当前：", "```json",
            _json.dumps(p.current.evidence, indent=2, sort_keys=True),
            "```", "",
        ]
    return out


def _stable_section(stable: list[Finding]) -> list[str]:
    out = [
        "<details>",
        f"<summary>稳定：{len(stable)} 条 findings（两次运行无变化）</summary>",
        "",
        "| 严重度 | Check | 标题 | Fingerprint |",
        "|--------|-------|------|-------------|",
    ]
    for f in stable:
        out.append(
            f"| {f.severity} | {_md_cell(f.check)} | {_md_cell(f.title)} | "
            f"`{f.fingerprint[:8]}` |"
        )
    out += ["", "</details>", ""]
    return out


def _has_any(delta: FindingsDelta) -> bool:
    return bool(delta.added or delta.removed or delta.stable
                or delta.severity_changed or delta.evidence_drifted)
