"""Fingerprint-based findings diff with second-pass (check, title) drift
clustering. Spec §5."""

from __future__ import annotations

from dataclasses import dataclass, field

from agentsec.audit.findings import Finding


@dataclass(frozen=True)
class SeverityChange:
    fingerprint: str
    title: str
    check: str
    old_severity: str
    new_severity: str


@dataclass(frozen=True)
class DriftPair:
    check: str
    title: str
    baseline: Finding
    current: Finding


@dataclass(frozen=True)
class FindingsDelta:
    added: list[Finding] = field(default_factory=list)
    removed: list[Finding] = field(default_factory=list)
    stable: list[Finding] = field(default_factory=list)
    severity_changed: list[SeverityChange] = field(default_factory=list)
    evidence_drifted: list[DriftPair] = field(default_factory=list)


_SEVERITY_RANK: dict[str, int] = {
    "critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4,
}


def _finding_sort_key(f: Finding) -> tuple[int, str, str, str]:
    return (_SEVERITY_RANK.get(f.severity, 99), f.check, f.title, f.fingerprint)


def _severity_change_sort_key(s: SeverityChange) -> tuple[int, str, str]:
    return (_SEVERITY_RANK.get(s.new_severity, 99), s.check, s.title)


def _drift_sort_key(p: DriftPair) -> tuple[int, str, str]:
    return (_SEVERITY_RANK.get(p.current.severity, 99), p.check, p.title)


def diff_findings(baseline: list[Finding], current: list[Finding]) -> FindingsDelta:
    baseline_by_fp = {f.fingerprint: f for f in baseline}
    current_by_fp = {f.fingerprint: f for f in current}

    added_initial = [f for fp, f in current_by_fp.items() if fp not in baseline_by_fp]
    removed_initial = [f for fp, f in baseline_by_fp.items() if fp not in current_by_fp]

    stable: list[Finding] = []
    severity_changed: list[SeverityChange] = []
    for fp in baseline_by_fp.keys() & current_by_fp.keys():
        b = baseline_by_fp[fp]
        c = current_by_fp[fp]
        if b.severity == c.severity:
            stable.append(c)
        else:
            severity_changed.append(
                SeverityChange(
                    fingerprint=fp,
                    title=c.title,
                    check=c.check,
                    old_severity=b.severity,
                    new_severity=c.severity,
                )
            )

    # Second pass — pair leftover added×removed by (check, title).
    removed_by_ct: dict[tuple[str, str], Finding] = {}
    for f in removed_initial:
        removed_by_ct[(f.check, f.title)] = f  # last write wins (§5.3 caveat)

    drifted: list[DriftPair] = []
    remaining_added: list[Finding] = []
    paired_baseline_ids: set[int] = set()  # id() to avoid Finding hash issues
    for f in added_initial:
        key = (f.check, f.title)
        baseline_pair = removed_by_ct.get(key)
        if baseline_pair is not None and id(baseline_pair) not in paired_baseline_ids:
            drifted.append(
                DriftPair(check=f.check, title=f.title,
                          baseline=baseline_pair, current=f)
            )
            paired_baseline_ids.add(id(baseline_pair))
            removed_by_ct.pop(key, None)
        else:
            remaining_added.append(f)

    remaining_removed = [
        f for f in removed_initial if id(f) not in paired_baseline_ids
    ]

    return FindingsDelta(
        added=sorted(remaining_added, key=_finding_sort_key),
        removed=sorted(remaining_removed, key=_finding_sort_key),
        stable=sorted(stable, key=_finding_sort_key),
        severity_changed=sorted(severity_changed, key=_severity_change_sort_key),
        evidence_drifted=sorted(drifted, key=_drift_sort_key),
    )
