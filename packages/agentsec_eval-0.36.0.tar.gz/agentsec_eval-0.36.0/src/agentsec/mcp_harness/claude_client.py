"""Claude MCP client — runs the Anthropic tool_use loop against an in-memory
adversarial MCP server (spec §3–§4, §7).

Architecture (Phase 7c.3):
  1. Connect to the server via `mcp.shared.memory.create_connected_server_and_client_session`.
  2. Fetch tools via `tools/list`; convert MCP Tool → Anthropic tool spec.
  3. Probe `resources/list` and `prompts/list`. If the server advertises
     either capability (probe succeeds with non-empty result), append the
     corresponding synthetic tool specs (list_resources/read_resource and/or
     list_prompts/get_prompt) to the Anthropic tools list.
  4. Send user_prompt + tools to `messages.create`.
  5. Loop: if stop_reason=="tool_use", for each tool_use block dispatch:
        - synthetic name → translate to ClientSession method, serialize
          response to JSON text for tool_result content
        - other name → ClientSession.call_tool(name, args)
  6. Stop on stop_reason!="tool_use" or `max_iterations` reached.
"""

from __future__ import annotations

import asyncio
import contextlib
import copy
import json
from dataclasses import dataclass, field
from functools import partial
from typing import Any

import anyio
import mcp.types as _mcp_types
from mcp.server.lowlevel import Server
from mcp.shared.memory import create_connected_server_and_client_session

_SYNTHETIC_RESOURCE_TOOLS: list[dict[str, Any]] = [
    {
        "name": "list_resources",
        "description": (
            "List all MCP resources exposed by the connected server. "
            "Returns a JSON array of {uri, name, description, mime_type}."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    },
    {
        "name": "read_resource",
        "description": (
            "Read an MCP resource by URI. Returns the resource body text "
            "as advertised by the server."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"uri": {"type": "string"}},
            "required": ["uri"],
            "additionalProperties": False,
        },
    },
]

_SYNTHETIC_PROMPT_TOOLS: list[dict[str, Any]] = [
    {
        "name": "list_prompts",
        "description": (
            "List all MCP prompt templates exposed by the connected server. "
            "Returns a JSON array of {name, description}."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    },
    {
        "name": "get_prompt",
        "description": (
            "Fetch an MCP prompt template by name. Returns a JSON array of "
            "messages: [{role, content: {type, text}}, ...]."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
            "additionalProperties": False,
        },
    },
]

def _prefixed_synthetic_tools(
    tools: list[dict[str, Any]], server_name: str
) -> list[dict[str, Any]]:
    """Return deep copies of synthetic tool specs with names prefixed
    by `{server_name}__`.

    Required because _SYNTHETIC_RESOURCE_TOOLS and _SYNTHETIC_PROMPT_TOOLS
    are module-level constants — direct mutation would pollute every
    subsequent run.
    """
    result: list[dict[str, Any]] = []
    for t in tools:
        new = copy.deepcopy(t)
        new["name"] = f"{server_name}__{t['name']}"
        result.append(new)
    return result


_SYNTHETIC_NAMES = frozenset(
    {"list_resources", "read_resource", "list_prompts", "get_prompt"}
)

_SERVER_EVENT_CAP = 50

# Error sentinels surfaced as tool_result.content when multi-server dispatch
# cannot route a tool_use. The exact wording is part of the wire contract
# — case yaml judge_hints may reference these strings (e.g.
# `mcp-real-xs-mcp3-04` anchors on "unknown tool prefix"). Update with care.
_ERR_MALFORMED_NAME = "malformed tool name: {name}"
_ERR_UNKNOWN_PREFIX = "unknown tool prefix: {prefix}"


@dataclass
class ClaudeOutcome:
    final_text: str = ""
    tool_events: list[dict[str, str]] = field(default_factory=list)
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    server_events: list[dict[str, Any]] = field(default_factory=list)
    error: str | None = None
    iterations: int = 0


def _build_sampling_callback(
    *,
    server_name: str,
    policy: str,
    stub_response: str | None,
    events: list[dict[str, Any]],
    ts_counter: list[int],
):
    """Factory: returns an async sampling callback bound to a single
    server's policy + response. Each session gets its own callback
    closure capturing `server_name` (mirror 7c.x.2 _build_message_handler).

    The emitted sampling event payload always carries a `server` field
    (set to `server_name`). The field is injected BEFORE the try block
    so the exception path (`response.policy == "error"`) also carries
    correct server attribution.
    """

    async def _callback(ctx, params):  # noqa: ANN001
        evt: dict[str, Any] = {"kind": "sampling", "server": server_name}
        try:
            request_messages: list[str] = []
            for m in params.messages:
                content = m.content
                blocks = content if isinstance(content, list) else [content]
                for b in blocks:
                    t = getattr(b, "text", None)
                    if isinstance(t, str):
                        request_messages.append(t)
            ts_counter[0] += 1
            evt["ts"] = ts_counter[0]
            evt["request"] = {
                "messages": request_messages,
                "system_prompt": getattr(params, "systemPrompt", None),
                "max_tokens": getattr(params, "maxTokens", None),
            }
            if len(events) < _SERVER_EVENT_CAP - 1:
                events.append(evt)
            else:
                _record_overflow(events)

            if policy == "stub":
                text = stub_response or ""
                evt["response"] = {"text": text, "policy": "stub"}
                return _mcp_types.CreateMessageResult(
                    role="assistant",
                    content=_mcp_types.TextContent(type="text", text=text),
                    model="stub",
                    stopReason="endTurn",
                )
            # deny path
            evt["response"] = {"text": None, "policy": "deny"}
            return _mcp_types.ErrorData(
                code=_mcp_types.INVALID_REQUEST,
                message="Sampling denied by host policy",
            )
        except Exception as exc:  # noqa: BLE001 — defensive; "shouldn't happen"
            evt["response"] = {"text": None, "policy": "error", "error": str(exc)}
            if evt not in events and len(events) < _SERVER_EVENT_CAP - 1:
                events.append(evt)
            return _mcp_types.ErrorData(
                code=_mcp_types.INTERNAL_ERROR,
                message=f"sampling_callback internal error: {exc}",
            )

    return _callback


def _record_overflow(events: list[dict[str, Any]]) -> None:
    """Append (or update) a sentinel overflow entry; idempotent counter.

    The sentinel is appended when the (cap-1)-th slot is claimed; subsequent
    events increment `dropped`.  Using `dropped=0` on initial append means
    the counter equals the number of events lost *after* the sentinel was
    placed — consistent with ``len(events) == _SERVER_EVENT_CAP`` invariant.
    """
    if events and events[-1].get("kind") == "overflow":
        events[-1]["dropped"] = events[-1].get("dropped", 0) + 1
    else:
        events.append({"kind": "overflow", "dropped": 0})


def _resolve_sampling_per_server(
    servers: list[Server],
    sampling_per_server: dict[str, dict[str, Any]] | None,
    sampling_policy: str,
    sampling_response: str | None,
) -> dict[str, dict[str, Any]]:
    """Build per-server sampling config from the dict-or-scalar inputs.

    Strict on the ``policy`` key — a typo'd config dict raises
    ``KeyError`` immediately instead of silently defaulting to deny.
    ``response`` stays ``.get("response")`` because ``None`` is a valid
    value (deny policy needs no response text).

    7c.x.4: replaces the ~14-line inline block previously sitting at the
    top of ``ClaudeMcpClient.run``.
    """
    effective: dict[str, dict[str, Any]] = {}
    for srv in servers:
        if (
            sampling_per_server is not None
            and srv.name in sampling_per_server
        ):
            cfg = sampling_per_server[srv.name]
            effective[srv.name] = {
                "policy": cfg["policy"],
                "response": cfg.get("response"),
            }
        else:
            effective[srv.name] = {
                "policy": sampling_policy,
                "response": sampling_response,
            }
    return effective


def _build_message_handler(
    *,
    server_name: str,
    events: list[dict[str, Any]],
    dirty: list[bool],
    dirty_servers: set[str],
    ts_counter: list[int],
):
    """Factory: returns an async message handler that:
    - flips `dirty[0]=True` on tools/list_changed notifications
    - adds `server_name` to `dirty_servers`
    - appends a skeleton list_changed event tagged with `server`
      (`new_tool_names=[]` placeholder)
    - ignores every other notification kind

    NOTE: we do NOT call `session.list_tools()` from inside the handler.
    The handler runs on the ClientSession's internal receive task; issuing
    a new request from there would deadlock the receive loop. The main
    loop in `run()` populates `new_tool_names` after the dirty re-fetch
    succeeds.

    7c.x.2: per-session handler — each session gets its own handler with
    `server_name` captured in closure; events carry the originating server.

    Parallel to :func:`_build_sampling_callback` (7c.x.3): both factories
    take `server_name` and build per-session closures with the same
    `(events, ts_counter)` plumbing; updates to one usually have a
    matching change in the other.
    """
    async def _handler(message):
        method = ""
        if hasattr(message, "root"):
            method = getattr(message.root, "method", "")
        if method != "notifications/tools/list_changed":
            return
        dirty[0] = True
        dirty_servers.add(server_name)
        ts_counter[0] += 1
        evt = {
            "kind": "list_changed",
            "ts": ts_counter[0],
            "server": server_name,
            "new_tool_names": [],
        }
        if len(events) < _SERVER_EVENT_CAP - 1:
            events.append(evt)
        else:
            _record_overflow(events)

    return _handler


class ClaudeMcpClient:
    """Drives an Anthropic Claude client through one MCP tool_use loop."""

    def __init__(
        self,
        *,
        anthropic_client: Any,
        model: str,
        max_tokens: int = 1024,
        max_iterations: int = 10,
    ) -> None:
        self._client = anthropic_client
        self._model = model
        self._max_tokens = max_tokens
        self._max_iterations = max_iterations

    async def run(
        self,
        server: Server | list[Server],
        user_prompt: str,
        *,
        sampling_policy: str = "deny",
        sampling_response: str | None = None,
        sampling_per_server: dict[str, dict[str, Any]] | None = None,
    ) -> ClaudeOutcome:
        outcome = ClaudeOutcome()
        ts_counter: list[int] = [0]
        dirty: list[bool] = [False]
        dirty_servers: set[str] = set()

        servers: list[Server] = (
            list(server) if isinstance(server, list) else [server]
        )
        add_prefix = len(servers) > 1

        # 7c.x.4: per-session sampling policy resolution extracted to
        # module-level helper. `policy` key is strict (KeyError on typo).
        effective_per_server = _resolve_sampling_per_server(
            servers,
            sampling_per_server,
            sampling_policy,
            sampling_response,
        )

        try:
            async with contextlib.AsyncExitStack() as stack:
                sessions: list[tuple[str, Any]] = []
                for srv in servers:
                    cfg = effective_per_server[srv.name]
                    per_sampling = _build_sampling_callback(
                        server_name=srv.name,
                        policy=cfg["policy"],
                        stub_response=cfg["response"],
                        events=outcome.server_events,
                        ts_counter=ts_counter,
                    )
                    per_handler = _build_message_handler(
                        server_name=srv.name,
                        events=outcome.server_events,
                        dirty=dirty,
                        dirty_servers=dirty_servers,
                        ts_counter=ts_counter,
                    )
                    sess = await stack.enter_async_context(
                        create_connected_server_and_client_session(
                            srv,
                            sampling_callback=per_sampling,
                            message_handler=per_handler,
                        )
                    )
                    sessions.append((srv.name, sess))
                session_by_prefix = {n: s for n, s in sessions}
                # Single-server convenience binding; unused (None) when
                # add_prefix=True. All `not add_prefix` paths reference this.
                only_sess: Any = sessions[0][1] if not add_prefix else None

                # 7c.x.4: capability probes first (need server_capabilities
                # for synthetic stitching inside _rebuild_tools_spec), then
                # the canonical builder for the initial tools_spec.
                server_capabilities = await _probe_server_capabilities(
                    sessions
                )
                tools_spec, _ = await _rebuild_tools_spec(
                    sessions, server_capabilities, add_prefix,
                )

                messages: list[dict[str, Any]] = [
                    {"role": "user", "content": user_prompt},
                ]

                for iteration in range(self._max_iterations):
                    outcome.iterations = iteration + 1

                    # 7c.x.2 dirty re-fetch — α strategy: any server's
                    # list_changed triggers a full re-fetch across all
                    # sessions and a tools_spec rebuild (with prefix +
                    # synthetic stitching). Single- and multi-server modes
                    # share the same path.
                    if dirty[0]:
                        dirty[0] = False
                        triggered_servers = sorted(dirty_servers)
                        dirty_servers.clear()
                        try:
                            tools_spec, refreshed_by_server = await (
                                _rebuild_tools_spec(
                                    sessions, server_capabilities, add_prefix,
                                )
                            )
                            for srv_name in triggered_servers:
                                for evt in reversed(outcome.server_events):
                                    if (
                                        evt.get("kind") == "list_changed"
                                        and evt.get("server") == srv_name
                                        and evt.get("new_tool_names") == []
                                    ):
                                        evt["new_tool_names"] = (
                                            refreshed_by_server[srv_name]
                                        )
                                        break
                        except Exception as exc:  # noqa: BLE001
                            outcome.error = f"tools_relist_failed: {exc}"

                    create_call = partial(
                        self._client.messages.create,
                        model=self._model,
                        max_tokens=self._max_tokens,
                        messages=messages,
                        tools=tools_spec,
                    )
                    msg = await anyio.to_thread.run_sync(create_call)

                    assistant_content = []
                    tool_use_blocks: list[Any] = []
                    for block in msg.content:
                        btype = getattr(block, "type", None)
                        if btype == "text":
                            assistant_content.append(
                                {"type": "text", "text": getattr(block, "text", "")}
                            )
                            outcome.final_text = getattr(block, "text", "")
                        elif btype == "tool_use":
                            assistant_content.append({
                                "type": "tool_use",
                                "id": getattr(block, "id", ""),
                                "name": getattr(block, "name", ""),
                                "input": getattr(block, "input", {}) or {},
                            })
                            tool_use_blocks.append(block)
                    messages.append({"role": "assistant", "content": assistant_content})

                    if getattr(msg, "stop_reason", "") != "tool_use":
                        return outcome

                    user_tool_results: list[dict[str, Any]] = []
                    for tu in tool_use_blocks:
                        name = getattr(tu, "name", "")
                        args = getattr(tu, "input", {}) or {}
                        outcome.tool_events.append({
                            "tool": name,
                            "args": json.dumps(args, sort_keys=True),
                        })
                        if add_prefix:
                            prefix, sep, real_tool = name.partition("__")
                            if not sep:
                                tool_text = _ERR_MALFORMED_NAME.format(name=name)
                                is_error = True
                            elif prefix not in session_by_prefix:
                                tool_text = _ERR_UNKNOWN_PREFIX.format(prefix=prefix)
                                is_error = True
                            elif real_tool in _SYNTHETIC_NAMES:
                                # 7c.x.1: prefixed synthetic — route to that
                                # server's session.
                                tool_text, is_error = await _dispatch_synthetic(
                                    session_by_prefix[prefix], real_tool, args
                                )
                            else:
                                try:
                                    call_result = await session_by_prefix[prefix].call_tool(
                                        real_tool, args
                                    )
                                    text_parts = [
                                        getattr(c, "text", "") for c in call_result.content
                                        if getattr(c, "type", None) == "text"
                                    ]
                                    tool_text = "\n".join(text_parts) or ""
                                    is_error = bool(getattr(call_result, "isError", False))
                                except Exception as exc:  # noqa: BLE001
                                    tool_text = f"tool error: {exc}"
                                    is_error = True
                        elif name in _SYNTHETIC_NAMES:
                            tool_text, is_error = await _dispatch_synthetic(
                                only_sess, name, args
                            )
                        else:
                            try:
                                call_result = await only_sess.call_tool(name, args)
                                text_parts = [
                                    getattr(c, "text", "") for c in call_result.content
                                    if getattr(c, "type", None) == "text"
                                ]
                                tool_text = "\n".join(text_parts) or ""
                                is_error = bool(getattr(call_result, "isError", False))
                            except Exception as exc:  # noqa: BLE001
                                tool_text = f"tool error: {exc}"
                                is_error = True
                        outcome.tool_results.append({
                            "name": name, "text": tool_text, "is_error": is_error,
                        })
                        user_tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": getattr(tu, "id", ""),
                            "content": tool_text,
                            "is_error": is_error,
                        })
                    messages.append({"role": "user", "content": user_tool_results})
                else:
                    outcome.error = "max_iterations_exceeded"
                    return outcome
        except BaseExceptionGroup as group:  # noqa: F821
            inner = _first_leaf(group)
            outcome.error = f"{type(inner).__name__}: {inner}"
        except Exception as exc:  # noqa: BLE001
            outcome.error = f"{type(exc).__name__}: {exc}"
        return outcome


async def _server_has_resources(session: Any) -> bool:
    try:
        result = await session.list_resources()
    except Exception as exc:  # noqa: BLE001
        if "Method not found" not in str(exc):
            raise
        return False
    return bool(getattr(result, "resources", None))


async def _server_has_prompts(session: Any) -> bool:
    try:
        result = await session.list_prompts()
    except Exception as exc:  # noqa: BLE001
        if "Method not found" not in str(exc):
            raise
        return False
    return bool(getattr(result, "prompts", None))


async def _probe_server_capabilities(
    sessions: list[tuple[str, Any]],
) -> dict[str, dict[str, bool]]:
    """Concurrently probe every session for resources / prompts
    capability. Each individual probe (`_server_has_resources` /
    `_server_has_prompts`) tolerates a "Method not found" reply by
    returning False — non-tolerated errors propagate.

    7c.x.4: replaces the previous sequential `for srv_name, sess in
    sessions: await _server_has_resources(sess); await
    _server_has_prompts(sess)` loop with one `asyncio.gather` round.
    Result-dict keys cover every server name in `sessions`, in the
    same order.
    """
    probes: list[Any] = []
    for _, sess in sessions:
        probes.append(_server_has_resources(sess))
        probes.append(_server_has_prompts(sess))
    results = await asyncio.gather(*probes)
    capabilities: dict[str, dict[str, bool]] = {}
    for i, (srv_name, _sess) in enumerate(sessions):
        capabilities[srv_name] = {
            "resources": results[i * 2],
            "prompts": results[i * 2 + 1],
        }
    return capabilities


async def _rebuild_tools_spec(
    sessions: list[tuple[str, Any]],
    server_capabilities: dict[str, dict[str, bool]],
    add_prefix: bool,
) -> tuple[list[dict[str, Any]], dict[str, list[str]]]:
    """Concurrently `list_tools` every session and rebuild the full
    Anthropic-shape tools spec with `<server>__<tool>` prefix (when
    ``add_prefix`` is True) plus per-server synthetic resource/prompt
    tool registration via :func:`_prefixed_synthetic_tools`.

    Returns ``(new_tools_spec, refreshed_by_server)``. The latter maps
    each server name to the sorted bare tool-name list — used by the
    dirty re-fetch block to populate ``new_tool_names`` on the matching
    ``list_changed`` server_events entries.

    Used at BOTH the initial run() setup AND the dirty re-fetch block —
    single canonical implementation.

    7c.x.4: concurrent via ``asyncio.gather(return_exceptions=True)``.
    A per-session "Method not found" error is silently treated as an
    empty tools list (matches the previous per-session try/except path
    used at initial setup). Any other exception is re-raised so the
    caller's top-level handler can record it.
    """
    refresh_results = await asyncio.gather(
        *[sess.list_tools() for _, sess in sessions],
        return_exceptions=True,
    )
    new_tools_spec: list[dict[str, Any]] = []
    refreshed_by_server: dict[str, list[str]] = {}
    for (srv_name, _sess), refresh in zip(
        sessions, refresh_results, strict=True
    ):
        if isinstance(refresh, BaseException):
            if "Method not found" in str(refresh):
                refreshed_by_server[srv_name] = []
            else:
                raise refresh
        else:
            refreshed_by_server[srv_name] = sorted(
                t.name for t in refresh.tools
            )
            for t in refresh.tools:
                tool_name = (
                    f"{srv_name}__{t.name}" if add_prefix else t.name
                )
                new_tools_spec.append({
                    "name": tool_name,
                    "description": t.description or "",
                    "input_schema": t.inputSchema,
                })
        # Synthetic-tool stitching runs regardless of whether list_tools
        # succeeded or raised "Method not found" — the server may still
        # advertise resources / prompts even with no tools registered.
        caps = server_capabilities[srv_name]
        if caps["resources"]:
            new_tools_spec.extend(
                _prefixed_synthetic_tools(
                    _SYNTHETIC_RESOURCE_TOOLS, srv_name
                )
                if add_prefix
                else _SYNTHETIC_RESOURCE_TOOLS
            )
        if caps["prompts"]:
            new_tools_spec.extend(
                _prefixed_synthetic_tools(
                    _SYNTHETIC_PROMPT_TOOLS, srv_name
                )
                if add_prefix
                else _SYNTHETIC_PROMPT_TOOLS
            )
    return new_tools_spec, refreshed_by_server


async def _dispatch_synthetic(
    session: Any, name: str, args: dict[str, Any]
) -> tuple[str, bool]:
    try:
        if name == "list_resources":
            result = await session.list_resources()
            payload = [
                {
                    "uri": str(r.uri),
                    "name": r.name,
                    "description": r.description or "",
                    "mime_type": r.mimeType or "text/plain",
                }
                for r in result.resources
            ]
            return json.dumps(payload), False
        if name == "read_resource":
            uri = args.get("uri", "")
            result = await session.read_resource(uri)
            texts: list[str] = []
            for c in result.contents:
                text = getattr(c, "text", None)
                if isinstance(text, str):
                    texts.append(text)
            return ("\n".join(texts) if texts else ""), False
        if name == "list_prompts":
            result = await session.list_prompts()
            payload = [
                {"name": p.name, "description": p.description or ""}
                for p in result.prompts
            ]
            return json.dumps(payload), False
        if name == "get_prompt":
            prompt_name = args.get("name", "")
            result = await session.get_prompt(prompt_name)
            payload = [
                {
                    "role": m.role,
                    "content": {
                        "type": getattr(m.content, "type", "text"),
                        "text": getattr(m.content, "text", ""),
                    },
                }
                for m in result.messages
            ]
            return json.dumps(payload), False
    except Exception as exc:  # noqa: BLE001
        return f"synthetic tool error: {exc}", True
    return f"unknown synthetic tool: {name}", True


def _first_leaf(group: BaseExceptionGroup) -> BaseException:  # noqa: F821
    """Walk into a (possibly nested) ExceptionGroup and return the first leaf."""
    for exc in group.exceptions:
        if isinstance(exc, BaseExceptionGroup):
            return _first_leaf(exc)
        return exc
    return group
