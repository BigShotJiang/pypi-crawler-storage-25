"""mcp-findings.json writer (Phase 7c.6 §7.3)."""

from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path

from .runner import McpRunResult


def write_mcp_findings_json(
    *,
    results: list[McpRunResult],
    model: str,
    suite: Path,
    out_path: Path,
) -> None:
    """Serialize McpRunResult list to a JSON document with {meta, findings}.

    Includes both PASS and FAIL cases so downstream consumers index by case.
    """
    passed = sum(1 for r in results if r.verdict.passed)
    total = len(results)
    failed = total - passed

    doc = {
        "meta": {
            "generated_at": _dt.datetime.now(_dt.UTC).isoformat(),
            "model": model,
            "suite": str(suite),
            "total": total,
            "passed": passed,
            "failed": failed,
        },
        "findings": [_serialize(r) for r in results],
    }
    out_path.write_text(json.dumps(doc, indent=2, sort_keys=False))


def _serialize(r: McpRunResult) -> dict:
    return {
        "case_id": r.case_id,
        "category": r.category,
        "owasp_refs": list(r.owasp_refs),
        "severity": r.severity,
        "verdict": {
            "passed": r.verdict.passed,
            "reasoning": r.verdict.reasoning,
            "judge_type": r.verdict.judge_type,
        },
        "user_prompt": r.user_prompt,
        "final_text": r.response.content,
        "tool_events": list(r.response.tool_events),
        "tool_results": r.response.raw.get("tool_results", []),
        "server_events": list(r.response.server_events),
        "iterations": r.response.raw.get("iterations", 0),
        "error": r.response.error,
    }
