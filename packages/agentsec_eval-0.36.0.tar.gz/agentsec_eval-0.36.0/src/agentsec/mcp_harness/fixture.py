"""Pydantic models for the adversarial MCP server fixture (spec §5)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

_SYNTHETIC_TOOL_NAMES = frozenset(
    {"list_resources", "read_resource", "list_prompts", "get_prompt"}
)


class McpSamplingDirective(BaseModel):
    """Server-initiated `sampling/createMessage` attached to a tool call.

    When set on a tool, the adversarial server's `call_tool` handler issues
    `request_context.session.create_message(...)` BEFORE returning the tool
    result. The sampling result text is appended to the tool result body
    behind a literal `<<<SAMPLED:>>>` marker. When client policy is `deny`,
    a `<<<SAMPLING_DENIED:>>>` marker is used instead.
    """

    model_config = ConfigDict(extra="forbid")

    messages: list[str] = Field(min_length=1)
    system_prompt: str | None = None
    max_tokens: int = Field(default=256, ge=1, le=4096)


class McpToolMutation(BaseModel):
    """One server-side mutation fired after a tool call.

    v1 set: `add_tool` only. The added tool joins the live tool set; the
    server then emits `notifications/tools/list_changed`.
    """

    model_config = ConfigDict(extra="forbid")

    add_tool: McpToolFixture


class McpToolFixture(BaseModel):
    """One tool exposed by the adversarial MCP server.

    `description` is the MCP1 injection surface; `result` is MCP2's;
    `mutations` is the MCP6 surface; `sampling` is the MCP7 surface.
    """

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    description: str = Field(min_length=1)
    input_schema: dict[str, Any]
    result: str
    mutations: list[McpToolMutation] = Field(default_factory=list)
    sampling: McpSamplingDirective | None = None


# resolve forward reference McpToolMutation.add_tool -> McpToolFixture
McpToolMutation.model_rebuild()


class McpResourceFixture(BaseModel):
    """MCP4 injection surfaces."""

    model_config = ConfigDict(extra="forbid")

    uri: str = Field(min_length=1)
    name: str = Field(min_length=1)
    description: str
    mime_type: str = "text/plain"
    content: str


class McpPromptFixture(BaseModel):
    """MCP5 injection surfaces."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    description: str
    messages: list[str] = Field(min_length=1)


class McpServerFixture(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    tools: list[McpToolFixture] = Field(default_factory=list)
    resources: list[McpResourceFixture] = Field(default_factory=list)
    prompts: list[McpPromptFixture] = Field(default_factory=list)
    sampling_policy: Literal["deny", "stub"] = "deny"
    sampling_response: str | None = None

    @model_validator(mode="after")
    def _validate(self) -> McpServerFixture:
        # Existing: at-least-one primitive
        if not (self.tools or self.resources or self.prompts):
            raise ValueError(
                "fixture must declare at least one of tools/resources/prompts"
            )
        # Existing: tool name uniqueness + synthetic reserved guard
        seen_tools: set[str] = set()
        for tool in self.tools:
            if tool.name in _SYNTHETIC_TOOL_NAMES:
                raise ValueError(
                    f"tool name {tool.name!r} collides with a synthetic MCP "
                    "tool name reserved by the harness; please rename"
                )
            if tool.name in seen_tools:
                raise ValueError(f"duplicate tool name in fixture: {tool.name!r}")
            seen_tools.add(tool.name)
        seen_uris: set[str] = set()
        for res in self.resources:
            if res.uri in seen_uris:
                raise ValueError(f"duplicate resource uri in fixture: {res.uri!r}")
            seen_uris.add(res.uri)
        seen_prompts: set[str] = set()
        for prompt in self.prompts:
            if prompt.name in seen_prompts:
                raise ValueError(
                    f"duplicate prompt name in fixture: {prompt.name!r}"
                )
            seen_prompts.add(prompt.name)

        # 7c.4: sampling policy / response coherence
        if self.sampling_policy == "stub":
            if not (isinstance(self.sampling_response, str) and self.sampling_response):
                raise ValueError(
                    "sampling_policy='stub' requires a non-empty sampling_response"
                )
        else:  # deny
            if self.sampling_response is not None:
                raise ValueError(
                    "sampling_policy='deny' must not set sampling_response "
                    "(dead config rejected)"
                )

        # 7c.4: mutation add_tool name collisions
        # Allowed names = existing tools ∪ synthetic reserved ∪ already-seen mutations
        seen_muts: set[str] = set()
        for tool in self.tools:
            for mut in tool.mutations:
                nm = mut.add_tool.name
                if nm in seen_tools:
                    raise ValueError(
                        f"mutation.add_tool {nm!r} collides with an existing "
                        "fixture tool name"
                    )
                if nm in _SYNTHETIC_TOOL_NAMES:
                    raise ValueError(
                        f"mutation.add_tool {nm!r} collides with a synthetic "
                        "MCP tool name reserved by the harness"
                    )
                if nm in seen_muts:
                    raise ValueError(
                        f"two mutations declare add_tool with the same name: {nm!r}"
                    )
                seen_muts.add(nm)
        return self
