"""McpRunner — bounded-concurrency runner for `McpRealCase` lists, integrating
the existing `LLMJudge` (spec §6).
"""

from __future__ import annotations

import asyncio
import uuid
from collections.abc import Callable
from dataclasses import dataclass

from ..adapters.base import AgentAdapter, AgentResponse
from ..evaluator.base import Judge, JudgeVerdict
from ..observability.observation import Observation
from ..tests.models import TestCase
from .case import McpRealCase

AdapterFactory = Callable[..., AgentAdapter]


@dataclass
class McpRunResult:
    case_id: str
    category: str
    severity: str
    owasp_refs: list[str]
    user_prompt: str
    response: AgentResponse
    verdict: JudgeVerdict


def _synthesize_test_case(case: McpRealCase) -> TestCase:
    """Build a TestCase view of an McpRealCase for the existing LLMJudge.

    The judge only consumes a subset of TestCase: `attack`, `expected_behavior`,
    `judge_type`, `judge_hint`, `severity`. We mirror those; everything else
    gets a safe default.
    """
    return TestCase(
        id=case.id,
        category=case.category,
        description=case.description,
        attack=case.user_prompt,
        expected_behavior=case.expected_behavior,
        severity=case.severity,
        judge_type=case.judge_type,
        judge_hint=case.judge_hint,
        owasp_refs=list(case.owasp_refs),
    )


async def _run_one(
    case: McpRealCase,
    judge: Judge,
    adapter_factory: AdapterFactory,
    model: str,
    sem: asyncio.Semaphore,
) -> McpRunResult:
    async with sem:
        adapter = adapter_factory(fixtures=case.effective_servers(), model=model)
        response = await adapter.send(case.user_prompt, str(uuid.uuid4()))
        observation = Observation(response=response, tool_events=list(response.tool_events))
        verdict = await judge.evaluate(_synthesize_test_case(case), observation)
        return McpRunResult(
            case_id=case.id,
            category=case.category,
            severity=case.severity,
            owasp_refs=list(case.owasp_refs),
            user_prompt=case.user_prompt,
            response=response,
            verdict=verdict,
        )


async def run_mcp_suite(
    *,
    cases: list[McpRealCase],
    judge: Judge,
    adapter_factory: AdapterFactory,
    model: str = "claude-haiku-4-5-20251001",
    concurrency: int = 3,
) -> list[McpRunResult]:
    sem = asyncio.Semaphore(concurrency)
    tasks = [_run_one(c, judge, adapter_factory, model, sem) for c in cases]
    return await asyncio.gather(*tasks)
