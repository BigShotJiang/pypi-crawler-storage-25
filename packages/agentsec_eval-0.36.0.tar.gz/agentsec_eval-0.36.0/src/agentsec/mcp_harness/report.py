"""Markdown report for `agentsec mcp-run` (spec §9)."""

from __future__ import annotations

import datetime as _dt
from collections import Counter

from .runner import McpRunResult

_HEADER = "# AgentSec MCP Real-Protocol Report"


def _coverage_table(results: list[McpRunResult]) -> str:
    by_ref_total: Counter[str] = Counter()
    by_ref_pass: Counter[str] = Counter()
    for r in results:
        for ref in r.owasp_refs:
            by_ref_total[ref] += 1
            if r.verdict.passed:
                by_ref_pass[ref] += 1
    if not by_ref_total:
        return "_(no OWASP refs)_\n"
    lines = ["| OWASP ref | Passed / Total |", "|---|---|"]
    for ref in sorted(by_ref_total):
        lines.append(f"| {ref} | {by_ref_pass[ref]} / {by_ref_total[ref]} |")
    return "\n".join(lines) + "\n"


def _case_row(r: McpRunResult) -> str:
    status = "PASS" if r.verdict.passed else "FAIL"
    return f"| {r.case_id} | {r.category} | {r.severity} | {','.join(r.owasp_refs)} | {status} |"


def _failure_dump(r: McpRunResult) -> str:
    parts = [
        f"### {r.case_id} — FAIL\n",
        f"- **OWASP refs**: {', '.join(r.owasp_refs)}",
        f"- **Severity**: {r.severity}",
        f"- **User prompt**: {r.user_prompt}",
        f"- **Final text**: {r.response.content!r}",
        f"- **Tool events**: {r.response.tool_events}",
        f"- **Tool results**: {r.response.raw.get('tool_results', [])}",
        f"- **Judge reasoning**: {r.verdict.reasoning}",
    ]
    if r.response.server_events:
        parts.append("")
        parts.append("##### Server events")
        parts.append("")
        for evt in r.response.server_events:
            parts.append(_format_server_event(evt))
        parts.append("")
    parts.append("")
    return "\n".join(parts)


def _format_server_event(evt: dict) -> str:
    kind = evt.get("kind", "?")
    ts = evt.get("ts", "?")
    if kind == "list_changed":
        names = evt.get("new_tool_names", [])
        server = evt.get("server")
        if server:
            return f"- [{ts}] list_changed (server={server}) → live tools: {names}"
        return f"- [{ts}] list_changed → live tools: {names}"
    if kind == "sampling":
        req = evt.get("request", {})
        resp = evt.get("response", {})
        policy = resp.get("policy", "?")
        server = evt.get("server")
        text = resp.get("text")
        text_display = f" → response: {text!r}" if text else " → response: (denied)"
        prefix = f"sampling ({policy})"
        if server:
            prefix = f"sampling (server={server}, policy={policy})"
        return (
            f"- [{ts}] {prefix} → request: "
            f"messages={req.get('messages')!r}, systemPrompt={req.get('system_prompt')!r}, "
            f"max_tokens={req.get('max_tokens')!r}{text_display}"
        )
    if kind == "overflow":
        return f"- [overflow] {evt.get('dropped', 0)} events dropped after cap"
    return f"- [{ts}] {kind}: {evt!r}"


def render_mcp_real_report(
    results: list[McpRunResult],
    *,
    model: str,
    generated_at: _dt.datetime | None = None,
) -> str:
    when = (generated_at or _dt.datetime.now(_dt.UTC)).isoformat()
    passed = sum(1 for r in results if r.verdict.passed)
    failed = len(results) - passed

    parts = [
        _HEADER, "",
        f"- Generated at: {when}",
        f"- Claude model: {model}",
        f"- Total cases: {len(results)}",
        f"- Passed: {passed}",
        f"- Failed: {failed}",
        "",
        "## OWASP MCP coverage", "",
        _coverage_table(results),
        "",
        "## Cases", "",
        "| ID | Category | Severity | OWASP | Verdict |",
        "|---|---|---|---|---|",
    ]
    parts.extend(_case_row(r) for r in results)
    parts.append("")

    failures = [r for r in results if not r.verdict.passed]
    if failures:
        parts.append("## Failure evidence")
        parts.append("")
        for r in failures:
            parts.append(_failure_dump(r))

    return "\n".join(parts)
