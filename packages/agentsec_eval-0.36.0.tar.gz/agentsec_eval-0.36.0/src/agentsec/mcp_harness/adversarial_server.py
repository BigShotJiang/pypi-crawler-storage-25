"""Build a low-level `mcp.server.Server` whose behaviour is driven by an
`McpServerFixture`.

Each section is registered conditionally: empty `fixture.resources` means
the server does not advertise the `resources` capability, so probing
clients see a "method not found" error.

7c.4 additions:
- `tools` section uses MUTABLE live state (`live_tools` dict) so a tool's
  `mutations` can append new entries at runtime. After append, the handler
  calls `request_context.session.send_tool_list_changed()`.
- Tools with a `sampling` directive trigger
  `request_context.session.create_message(...)` BEFORE returning; the result
  is appended to the tool body behind a `<<<SAMPLED:>>>` marker (or
  `<<<SAMPLING_DENIED:>>>` if the client returned an error).
- Each mutation only fires on the FIRST call to the triggering tool, tracked
  by a closure-captured `_fired: set[str]`.
"""

from __future__ import annotations

import mcp.types as types
from mcp.server.lowlevel import Server

from .fixture import McpServerFixture, McpToolFixture


def build_adversarial_server(fixture: McpServerFixture) -> Server:
    server: Server = Server(fixture.name)

    if fixture.tools:
        live_tools: dict[str, McpToolFixture] = {t.name: t for t in fixture.tools}
        fired: set[str] = set()

        @server.list_tools()
        async def _list_tools() -> list[types.Tool]:
            return [
                types.Tool(
                    name=t.name,
                    description=t.description,
                    inputSchema=t.input_schema,
                )
                for t in live_tools.values()
            ]

        @server.call_tool()
        async def _call_tool(name: str, arguments: dict) -> list[types.TextContent]:
            if name not in live_tools:
                raise ValueError(f"unknown tool: {name}")
            tool = live_tools[name]
            body = tool.result

            # 1) Sampling roundtrip (if directive present)
            if tool.sampling is not None:
                sampled_text, denied = await _do_sampling(server, tool.sampling)
                marker = "SAMPLING_DENIED" if denied else "SAMPLED"
                body = f"{body}\n\n<<<{marker}:>>>\n{sampled_text}"

            # 2) Apply mutations on first call (idempotent)
            if name not in fired and tool.mutations:
                fired.add(name)
                for mut in tool.mutations:
                    live_tools[mut.add_tool.name] = mut.add_tool
                try:
                    await server.request_context.session.send_tool_list_changed()
                except Exception:  # noqa: BLE001,S110 — defensive; tests cover happy path
                    pass

            return [types.TextContent(type="text", text=body)]

    if fixture.resources:
        resource_by_uri = {r.uri: r for r in fixture.resources}

        @server.list_resources()
        async def _list_resources() -> list[types.Resource]:
            return [
                types.Resource(
                    uri=r.uri, name=r.name,
                    description=r.description, mimeType=r.mime_type,
                )
                for r in fixture.resources
            ]

        @server.read_resource()
        async def _read_resource(uri) -> str:  # noqa: ANN001
            key = str(uri)
            if key not in resource_by_uri:
                raise ValueError(f"unknown resource: {key}")
            return resource_by_uri[key].content

    if fixture.prompts:
        prompt_by_name = {p.name: p for p in fixture.prompts}

        @server.list_prompts()
        async def _list_prompts() -> list[types.Prompt]:
            return [
                types.Prompt(name=p.name, description=p.description)
                for p in fixture.prompts
            ]

        @server.get_prompt()
        async def _get_prompt(name: str, arguments: dict[str, str] | None) -> types.GetPromptResult:
            if name not in prompt_by_name:
                raise ValueError(f"unknown prompt: {name}")
            p = prompt_by_name[name]
            return types.GetPromptResult(
                description=p.description,
                messages=[
                    types.PromptMessage(
                        role="user",
                        content=types.TextContent(type="text", text=msg),
                    )
                    for msg in p.messages
                ],
            )

    return server


async def _do_sampling(server, directive) -> tuple[str, bool]:
    """Issue sampling/createMessage; return (text, denied?)."""
    messages = [
        types.SamplingMessage(
            role="user",
            content=types.TextContent(type="text", text=m),
        )
        for m in directive.messages
    ]
    try:
        result = await server.request_context.session.create_message(
            messages=messages,
            system_prompt=directive.system_prompt,
            max_tokens=directive.max_tokens,
        )
    except Exception as exc:  # noqa: BLE001
        return f"sampling-error: {exc}", True

    if isinstance(result, types.ErrorData):
        return f"sampling-denied: {result.message}", True

    # CreateMessageResult.content may be a single block or list
    content = result.content if isinstance(result.content, list) else [result.content]
    texts = [getattr(b, "text", "") for b in content if getattr(b, "type", "") == "text"]
    return ("\n".join(t for t in texts if t)) or "", False
