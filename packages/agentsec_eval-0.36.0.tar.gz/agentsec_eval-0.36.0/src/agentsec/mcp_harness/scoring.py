"""McpScore + compute_mcp_score (Phase 7c.6).

Mirrors `agentsec.scoring` shape so the existing `EvaluationScore` /
`combined_score` machinery can splice MCP results into the same report
pipeline as remote + server.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

from ..scoring import CoverageTriple
from .runner import McpRunResult


@dataclass(frozen=True)
class McpCategoryScore:
    """Per-OWASP-ref pass / total summary."""
    owasp_ref: str
    passed: int
    total: int
    pass_rate: float


@dataclass(frozen=True)
class McpScore:
    """Phase 7c.6 mcp-half score (parallel to RemoteScore / server_score).

    `score` is the overall pass percentage (0–100). `None` when no cases
    ran (e.g. pipeline `not_run`) or every case errored without verdict.
    """
    score: float | None
    categories: list[McpCategoryScore] = field(default_factory=list)
    coverage: CoverageTriple = field(default_factory=lambda: _empty_coverage())
    note: str | None = None

    @classmethod
    def not_run(cls, *, reason: str) -> McpScore:
        return cls(
            score=None, categories=[],
            coverage=_empty_coverage(),
            note=reason,
        )


def _empty_coverage() -> CoverageTriple:
    return CoverageTriple(
        planned=0, executed=0, scored=0, error=0,
        execution_coverage=0.0, verdict_coverage=0.0, error_rate=None,
    )


def compute_mcp_score(results: list[McpRunResult]) -> McpScore:
    """Compute overall pass-rate score + per-OWASP-ref breakdown."""
    if not results:
        return McpScore(score=None, categories=[], coverage=_empty_coverage())

    total = len(results)
    passed = sum(1 for r in results if r.verdict.passed)
    error = sum(1 for r in results if r.response.error is not None)
    scored = total - error  # cases with usable verdict

    per_ref_total: Counter[str] = Counter()
    per_ref_pass: Counter[str] = Counter()
    for r in results:
        for ref in r.owasp_refs:
            per_ref_total[ref] += 1
            if r.verdict.passed:
                per_ref_pass[ref] += 1

    categories = sorted(
        (
            McpCategoryScore(
                owasp_ref=ref,
                passed=per_ref_pass[ref],
                total=per_ref_total[ref],
                pass_rate=(per_ref_pass[ref] / per_ref_total[ref]) if per_ref_total[ref] else 0.0,
            )
            for ref in per_ref_total
        ),
        key=lambda c: c.owasp_ref,
    )

    coverage = CoverageTriple(
        planned=total,
        executed=total,
        scored=scored,
        error=error,
        execution_coverage=1.0,
        verdict_coverage=(scored / total) if total else 0.0,
        error_rate=(error / total) if total else None,
    )

    score = (passed / total) * 100.0 if total else None

    return McpScore(
        score=score, categories=categories, coverage=coverage, note=None,
    )


# When this module is imported *first*, agentsec.scoring's bottom-of-file
# attempt to resolve the "McpScore | None" forward ref on EvaluationScore
# fails (partial-import ImportError caught there). Resolve it here now that
# McpScore is defined.
from ..scoring import EvaluationScore as _EvaluationScore  # noqa: E402

_EvaluationScore.model_rebuild()
