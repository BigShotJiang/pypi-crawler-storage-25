"""`McpRealCase` model and yaml loader (spec §5–§6, extended in 7c.5)."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .fixture import McpServerFixture

_MCP_REF_RE = re.compile(r"^MCP([1-9]|10)$")


class McpRealCase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1)
    category: str = Field(min_length=1)
    description: str = Field(min_length=1)
    user_prompt: str = Field(min_length=1)
    mcp_server: McpServerFixture | None = None
    mcp_servers: list[McpServerFixture] | None = None
    expected_behavior: Literal["refusal", "no_leak", "custom"]
    severity: Literal["critical", "high", "medium", "low"]
    judge_type: Literal["llm"] = "llm"
    owasp_refs: list[str] = Field(min_length=1)
    judge_hint: str = Field(min_length=1)

    @field_validator("owasp_refs")
    @classmethod
    def _refs_are_mcp(cls, v: list[str]) -> list[str]:
        for ref in v:
            if not _MCP_REF_RE.match(ref):
                raise ValueError(
                    f"owasp_refs entry {ref!r} must match MCP1..MCP10 (v1 scope)"
                )
        return v

    @model_validator(mode="after")
    def _validate_servers(self) -> McpRealCase:
        # XOR: exactly one of mcp_server / mcp_servers must be set
        if (self.mcp_server is None) == (self.mcp_servers is None):
            raise ValueError(
                "exactly one of mcp_server / mcp_servers must be set"
            )
        if self.mcp_servers is not None:
            if len(self.mcp_servers) < 2:
                raise ValueError(
                    "mcp_servers must contain at least 2 servers "
                    "(use mcp_server for single-server cases)"
                )
            # 7c.x.3: all multi-server scope guards lifted
            # (resources/prompts via 7c.x.1, mutations via 7c.x.2,
            # sampling via 7c.x.3). Multi-server v1 is now
            # capability-equivalent to single-server v1.
            names = [s.name for s in self.mcp_servers]
            if len(set(names)) != len(names):
                raise ValueError(f"duplicate server names: {names}")
            for n in names:
                if "__" in n:
                    raise ValueError(
                        f"server name {n!r}: must not contain '__' "
                        "(reserved as harness namespace separator)"
                    )
        return self

    def effective_servers(self) -> list[McpServerFixture]:
        """Return the list of fixtures regardless of single/multi mode."""
        if self.mcp_servers is not None:
            return list(self.mcp_servers)
        if self.mcp_server is None:  # pragma: no cover
            raise RuntimeError("McpRealCase invariant violated: no server set")
        return [self.mcp_server]


def _load_one(path: Path) -> list[McpRealCase]:
    raw = yaml.safe_load(path.read_text()) or []
    if not isinstance(raw, list):
        raise ValueError(f"{path}: top-level must be a list")
    return [McpRealCase.model_validate(item) for item in raw]


def load_mcp_real_suite(path: Path | str) -> list[McpRealCase]:
    """Load a yaml file or a directory of yaml files."""
    p = Path(path)
    if p.is_dir():
        yaml_files = sorted(p.glob("*.yaml"))
        if not yaml_files:
            raise ValueError(f"{p}: directory contains no .yaml files")
        cases: list[McpRealCase] = []
        for f in yaml_files:
            cases.extend(_load_one(f))
    else:
        cases = _load_one(p)
    seen: set[str] = set()
    for case in cases:
        if case.id in seen:
            raise ValueError(f"{p}: duplicate id {case.id!r}")
        seen.add(case.id)
    return cases
