"""In-process MCP harness — Anthropic SDK Claude client + adversarial MCP
server wired via anyio in-memory streams (Phase 7c.2 + 7c.3).
"""

from .adapter import ClaudeMcpAdapter
from .case import McpRealCase, load_mcp_real_suite
from .findings import write_mcp_findings_json
from .fixture import (
    McpPromptFixture,
    McpResourceFixture,
    McpServerFixture,
    McpToolFixture,
)
from .runner import run_mcp_suite
from .scoring import McpCategoryScore, McpScore, compute_mcp_score

__all__ = [
    "ClaudeMcpAdapter",
    "McpCategoryScore",
    "McpPromptFixture",
    "McpRealCase",
    "McpResourceFixture",
    "McpScore",
    "McpServerFixture",
    "McpToolFixture",
    "compute_mcp_score",
    "load_mcp_real_suite",
    "run_mcp_suite",
    "write_mcp_findings_json",
]
