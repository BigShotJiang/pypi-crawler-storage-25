"""ClaudeMcpAdapter — orchestrates one case end-to-end (spec §6, 7c.4 + 7c.5 + 7c.x.3)."""

from __future__ import annotations

from typing import Any

from ..adapters.base import AgentAdapter, AgentResponse
from .adversarial_server import build_adversarial_server
from .claude_client import ClaudeMcpClient
from .fixture import McpServerFixture


class ClaudeMcpAdapter(AgentAdapter):
    name = "claude-mcp"

    def __init__(
        self,
        *,
        fixtures: list[McpServerFixture],
        anthropic_client: Any,
        model: str,
        max_iterations: int = 10,
    ) -> None:
        if not fixtures:
            raise ValueError("fixtures must contain at least one McpServerFixture")
        self._fixtures = list(fixtures)
        self._client = ClaudeMcpClient(
            anthropic_client=anthropic_client,
            model=model,
            max_iterations=max_iterations,
        )

    async def send(self, message: str, session_id: str) -> AgentResponse:  # noqa: ARG002
        servers = [build_adversarial_server(f) for f in self._fixtures]
        # Pass single Server when len==1 (preserves wire format), or list[Server]
        # when len > 1.
        target: Any = servers[0] if len(servers) == 1 else servers
        # 7c.x.3: per-server sampling policy resolution. Build a dict from
        # fixtures; client.run() picks per-session policy at session-enter time.
        # Single-server case still uses a one-entry dict — the per-session
        # callback construction is uniform.
        sampling_per_server = {
            f.name: {
                "policy": f.sampling_policy,
                "response": f.sampling_response,
            }
            for f in self._fixtures
        }
        outcome = await self._client.run(
            target,
            user_prompt=message,
            sampling_per_server=sampling_per_server,
        )
        return AgentResponse(
            content=outcome.final_text,
            tool_events=list(outcome.tool_events),
            server_events=list(outcome.server_events),
            raw={
                "tool_results": list(outcome.tool_results),
                "iterations": outcome.iterations,
            },
            error=outcome.error,
        )
