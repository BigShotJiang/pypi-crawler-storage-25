"""Async orchestrator. Runs tests with bounded concurrency, replays multi-turn
attacks, and threads fixture/observer state into Observation."""

import asyncio
import contextlib
import dataclasses
import uuid
from collections.abc import AsyncIterator
from pathlib import Path

from .adapters.base import AgentAdapter, AgentResponse
from .adapters.ws_adapter import WebSocketAgentAdapter
from .evaluator.base import Judge, JudgeVerdict
from .observability.network_observer import FixtureOnlyObserver, NetworkObserver
from .observability.observation import Observation
from .observability.runtime import FixtureRuntime, substitute_fixture_url
from .tests.models import TestCase, TestResult, Turn


@contextlib.asynccontextmanager
async def _null_fixture() -> AsyncIterator[None]:
    yield None


async def run_suite(
    adapter: AgentAdapter,
    judge: Judge,
    tests: list[TestCase],
    concurrency: int = 3,
    *,
    observer: NetworkObserver | None = None,
    suite_root: Path | None = None,
    evaluator_and_target_same_host: bool = False,
    ws_adapter: "WebSocketAgentAdapter | None" = None,
) -> list[TestResult]:
    semaphore = asyncio.Semaphore(concurrency)
    results: list[TestResult] = []

    async def _run_one(test: TestCase) -> TestResult:
        async with semaphore:
            session_id = str(uuid.uuid4())
            local_observer = (
                observer if observer is not None else FixtureOnlyObserver()
            )
            # Mirror the loader's single-attack expansion so callers that bypass
            # the loader (e.g. unit tests) still work correctly.
            if test.attack is not None and not test.turns:
                turns = [Turn(attack=test.attack)]
                # When assertions were not provided for a deterministic/hybrid
                # case, treat it as an empty list rather than letting the judge
                # raise — the aggregate([]) path returns passed=False with
                # reasoning "inconclusive: no assertions to run". This only
                # applies to the runner-level attack expansion path; callers that
                # go directly to DeterministicJudge still get the ValueError.
                if test.assertions is None and test.judge_type in ("deterministic", "hybrid"):
                    test = test.model_copy(update={"assertions": []})
            else:
                turns = test.turns or []

            needs_ws = test.ws_concurrent_observe or any(
                t.channel == "ws" for t in turns
            )
            if needs_ws and ws_adapter is None:
                return TestResult(
                    test_id=test.id,
                    category=test.category,
                    severity=test.severity,
                    status="skipped",
                    skipped_reason="ws_adapter required: pass --ws-url to agentsec run",
                )

            observations: list[Observation] = []
            last_verdict: JudgeVerdict | None = None
            last_latency = 0.0

            try:
                # TODO(stage D): when a non-FixtureOnlyObserver lands (reverse_proxy
                # / dns_sink / egress_log), fixture hits are recorded on a throwaway
                # observer here while the per-turn snapshot below reads from the
                # caller's observer — the throwaway events are lost. Snapshot both,
                # or push fixture events through the caller's observer interface.
                fixture_cm = (
                    FixtureRuntime(
                        fixture=test.fixture,
                        suite_root=suite_root or Path("."),
                        observer=local_observer
                        if isinstance(local_observer, FixtureOnlyObserver)
                        else FixtureOnlyObserver(),
                        evaluator_and_target_same_host=evaluator_and_target_same_host,
                    ).active()
                    if test.fixture is not None
                    else _null_fixture()
                )
                async with fixture_cm as fixture_url:
                    if test.ws_concurrent_observe:
                        # Filtered above: needs_ws ⇒ ws_adapter is not None.
                        assert ws_adapter is not None  # noqa: S101
                        async def _http_turns_concurrent():
                            resp = None
                            for turn in turns:
                                message = (
                                    substitute_fixture_url(turn.attack, fixture_url)
                                    if fixture_url is not None
                                    else turn.attack
                                )
                                if turn.sleep_ms:
                                    await asyncio.sleep(turn.sleep_ms / 1000)
                                try:
                                    resp = await adapter.send(message, session_id)
                                except Exception as exc:  # noqa: BLE001
                                    err = f"adapter: {type(exc).__name__}: {exc}"
                                    return AgentResponse(content="", error=err)
                            return resp

                        http_resp, raw_ws = await asyncio.gather(
                            _http_turns_concurrent(),
                            ws_adapter.listen(session_id, test.ws_listen_duration_s),
                        )
                        if http_resp and http_resp.error and http_resp.error.startswith("adapter:"):
                            return TestResult(
                                test_id=test.id,
                                category=test.category,
                                severity=test.severity,
                                status="error",
                                error=http_resp.error,
                            )
                        if http_resp:
                            last_latency = http_resp.latency_ms
                        # TestCase model_validator rejects empty turns, so
                        # _http_turns_concurrent() always returns a response
                        # (or short-circuited above on adapter error).
                        assert http_resp is not None  # noqa: S101
                        merged_content = (
                            http_resp.content + "\n--- WS ---\n" + raw_ws
                        )
                        merged_resp = dataclasses.replace(http_resp, content=merged_content)
                        obs = Observation(
                            response=merged_resp,
                            outbound_requests=[
                                dataclasses.asdict(r)
                                for r in local_observer.outbound_requests()
                            ],
                            fixture_events=[
                                dataclasses.asdict(e)
                                for e in local_observer.fixture_events()
                            ],
                            tool_events=list(merged_resp.tool_events),
                        )
                        observations.append(obs)
                        try:
                            last_verdict = await judge.evaluate(test, obs)
                        except Exception as exc:  # noqa: BLE001
                            return TestResult(
                                test_id=test.id,
                                category=test.category,
                                severity=test.severity,
                                status="error",
                                error=f"judge: {type(exc).__name__}: {exc}",
                                observations=[o.model_dump() for o in observations],
                            )
                    else:
                        for idx, turn in enumerate(turns):
                            message = (
                                substitute_fixture_url(turn.attack, fixture_url)
                                if fixture_url is not None
                                else turn.attack
                            )
                            if turn.sleep_ms:
                                await asyncio.sleep(turn.sleep_ms / 1000)

                            active_adapter: AgentAdapter | WebSocketAgentAdapter
                            if turn.channel == "ws":
                                # Filtered above: any ws turn ⇒ needs_ws ⇒ ws_adapter is not None.
                                assert ws_adapter is not None  # noqa: S101
                                active_adapter = ws_adapter
                            else:
                                active_adapter = adapter
                            try:
                                response = await active_adapter.send(message, session_id)
                            except Exception as exc:  # noqa: BLE001
                                return TestResult(
                                    test_id=test.id,
                                    category=test.category,
                                    severity=test.severity,
                                    status="error",
                                    error=f"adapter: {type(exc).__name__}: {exc}",
                                )

                            last_latency = response.latency_ms
                            # Each turn's snapshot is cumulative since the test
                            # started: the observer is not reset between turns, so
                            # `outbound_requests` / `fixture_events` for turn N
                            # include everything from turn 0 through turn N. Stage C
                            # assertions reason about cumulative state.
                            obs = Observation(
                                response=response,
                                outbound_requests=[
                                    dataclasses.asdict(r)
                                    for r in local_observer.outbound_requests()
                                ],
                                fixture_events=[
                                    dataclasses.asdict(e)
                                    for e in local_observer.fixture_events()
                                ],
                                # Adapter-extracted tool invocations (e.g. OpenAI
                                # `tool_calls`) propagate to the assertion layer
                                # so `tool_event_not_invoked` actually fires.
                                tool_events=list(response.tool_events),
                            )
                            observations.append(obs)
                            is_last = idx == len(turns) - 1
                            if turn.judge_after or is_last:
                                try:
                                    last_verdict = await judge.evaluate(test, obs)
                                except Exception as exc:  # noqa: BLE001 — surface judge failure with partial observations preserved
                                    return TestResult(
                                        test_id=test.id,
                                        category=test.category,
                                        severity=test.severity,
                                        status="error",
                                        error=f"judge: {type(exc).__name__}: {exc}",
                                        observations=[o.model_dump() for o in observations],
                                    )
            except Exception as exc:  # noqa: BLE001 — fixture runtime / unexpected
                return TestResult(
                    test_id=test.id,
                    category=test.category,
                    severity=test.severity,
                    status="error",
                    error=f"runtime: {type(exc).__name__}: {exc}",
                )

            if last_verdict is None:
                # TestCase model_validator rejects empty turns, so this fires
                # only if a caller hand-constructed a TestCase past validation.
                raise RuntimeError(
                    f"test {test.id!r}: turns produced no verdict "
                    "(TestCase invariant violated)"
                )
            return TestResult(
                test_id=test.id,
                category=test.category,
                severity=test.severity,
                status="passed" if last_verdict.passed else "failed",
                verdict=last_verdict.model_dump(),
                observations=[o.model_dump() for o in observations],
                latency_ms=last_latency,
            )

    tasks = [asyncio.create_task(_run_one(t)) for t in tests]
    for coro in asyncio.as_completed(tasks):
        results.append(await coro)
    return results
