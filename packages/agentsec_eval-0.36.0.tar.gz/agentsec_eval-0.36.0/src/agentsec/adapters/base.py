from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class AgentResponse:
    """Response from a target agent.

    Adapters MUST NOT raise on non-2xx HTTP; populate `status_code` / `error`
    and let the judge / assertions decide pass/fail (spec §4, OE-AUD2-002).

    `tool_events` carries adapter-extracted tool invocations in a uniform
    `[{"tool": str, "args": str}, ...]` shape so `tool_event_not_invoked`
    can fire on whatever the underlying agent reports — OpenAI-compatible
    `choices[].message.tool_calls` for `OpenClawGatewayAdapter`, future
    SSH/native-audit observers for Stage D adapters.
    """
    content: str
    raw: dict = field(default_factory=dict)
    latency_ms: float = 0.0
    status_code: int | None = None
    headers: dict[str, str] = field(default_factory=dict)
    request_url: str | None = None
    error: str | None = None
    tool_events: list[dict] = field(default_factory=list)
    server_events: list[dict] = field(default_factory=list)


class AgentAdapter(ABC):
    """Base interface every target-agent adapter must implement."""

    name: str = "unnamed"

    @abstractmethod
    async def send(self, message: str, session_id: str) -> AgentResponse:
        """Send a message to the agent and return its response."""

    async def reset(self, session_id: str) -> None:  # noqa: B027 — intentional no-op default; subclasses override only if their target supports session reset
        """Reset / clear the agent's session state. Override if supported."""
