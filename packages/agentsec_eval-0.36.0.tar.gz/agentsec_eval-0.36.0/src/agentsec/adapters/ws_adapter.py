"""WebSocket agent adapter — sends messages and listens for responses over WS.

Session correlation: the session_id is appended as a query parameter so the
server can tie the WS connection to the same logical session as HTTP calls.

MockWebSocketAdapter overrides send() and listen() without importing websockets,
so tests run without a real WebSocket server.
"""

import asyncio
import time

from .base import AgentAdapter, AgentResponse


class WebSocketAgentAdapter(AgentAdapter):
    """Adapter that communicates with an agent over WebSocket.

    URL convention: ws_url?session_id=<session_id>
    Send payload:   {"message": "<text>"}
    Receive:        first text frame is the agent reply
    """

    name = "websocket"

    def __init__(
        self,
        ws_url: str,
        extra_headers: dict[str, str] | None = None,
        connect_timeout: float = 10.0,
        recv_timeout: float = 30.0,
    ):
        self._ws_url = ws_url.rstrip("/")
        self._extra_headers = extra_headers or {}
        self._connect_timeout = connect_timeout
        self._recv_timeout = recv_timeout

    def _session_url(self, session_id: str) -> str:
        sep = "&" if "?" in self._ws_url else "?"
        return f"{self._ws_url}{sep}session_id={session_id}"

    async def send(self, message: str, session_id: str) -> AgentResponse:
        import json

        import websockets  # lazy import — only needed for real connections

        url = self._session_url(session_id)
        start = time.monotonic()
        try:
            async with asyncio.timeout(self._connect_timeout + self._recv_timeout):
                async with websockets.connect(url, additional_headers=self._extra_headers) as ws:
                    await ws.send(json.dumps({"message": message}))
                    raw_text = await asyncio.wait_for(ws.recv(), timeout=self._recv_timeout)
        except TimeoutError:
            return AgentResponse(content="", error="ws_timeout",
                                 latency_ms=(time.monotonic() - start) * 1000)
        except Exception as exc:  # noqa: BLE001
            return AgentResponse(content="", error=f"ws_connect_failed: {exc}",
                                 latency_ms=(time.monotonic() - start) * 1000)

        return AgentResponse(
            content=raw_text if isinstance(raw_text, str) else raw_text.decode(),
            latency_ms=(time.monotonic() - start) * 1000,
        )

    async def listen(self, session_id: str, duration_s: float) -> str:
        """Connect and collect all incoming WS messages for `duration_s` seconds."""
        import websockets  # lazy import

        url = self._session_url(session_id)
        messages: list[str] = []
        try:
            async with asyncio.timeout(duration_s + self._connect_timeout):
                async with websockets.connect(url, additional_headers=self._extra_headers) as ws:
                    loop = asyncio.get_running_loop()
                    deadline = loop.time() + duration_s
                    while True:
                        remaining = deadline - loop.time()
                        if remaining <= 0:
                            break
                        try:
                            frame = await asyncio.wait_for(ws.recv(), timeout=remaining)
                            messages.append(frame if isinstance(frame, str) else frame.decode())
                        except TimeoutError:
                            break
        except Exception:  # noqa: BLE001,S110 — connection errors produce empty output by design
            pass
        return "\n".join(messages)


class MockWebSocketAdapter(WebSocketAgentAdapter):
    """Test double — no real WebSocket connection.

    Usage:
        mock = MockWebSocketAdapter(send_reply="Safe response", listen_data="no leak")
        result = await mock.send("attack", "session-1")
        assert result.content == "Safe response"
    """

    def __init__(
        self,
        send_reply: str = "",
        listen_data: str = "",
        send_error: str | None = None,
    ):
        super().__init__(ws_url="ws://mock.invalid")
        self._send_reply = send_reply
        self._listen_data = listen_data
        self._send_error = send_error
        self.send_calls: list[tuple[str, str]] = []
        self.listen_calls: list[tuple[str, float]] = []

    async def send(self, message: str, session_id: str) -> AgentResponse:
        self.send_calls.append((message, session_id))
        return AgentResponse(
            content=self._send_reply,
            error=self._send_error,
        )

    async def listen(self, session_id: str, duration_s: float) -> str:
        self.listen_calls.append((session_id, duration_s))
        return self._listen_data
