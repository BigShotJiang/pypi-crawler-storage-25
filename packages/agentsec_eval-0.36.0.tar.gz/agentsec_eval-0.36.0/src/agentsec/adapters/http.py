"""Generic HTTP adapter — covers agents that expose a simple chat REST API."""

import time
from collections.abc import Callable

import httpx

from .base import AgentAdapter, AgentResponse


class HttpAgentAdapter(AgentAdapter):
    """
    Adapter for agents that expose a JSON-over-HTTP chat endpoint.

    Default contract:
      POST {base_url}{path}
      Body: {"session_id": "...", "message": "..."}
      Response: {"reply": "..."}

    Subclasses override `_build_request` / `_parse_response` for non-standard
    schemas. The `path` parameter (default `/chat`) lets the OpenClaw gateway
    adapter target `/v1/chat/completions` without rewriting `send` (spec §5.2).

    Per OE-AUD2-002: 4xx/5xx do NOT raise; status_code/error are populated
    and the judge decides whether the response is a failure.
    """

    def __init__(
        self,
        name: str,
        base_url: str,
        path: str = "/chat",
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ):
        self.name = name
        self._base_url = base_url.rstrip("/")
        self._path = path if path.startswith("/") else "/" + path
        self._headers = headers or {}
        self._timeout = timeout
        self._client_factory: Callable[[], httpx.AsyncClient] | None = None

    def _build_request(self, message: str, session_id: str) -> dict:
        return {"session_id": session_id, "message": message}

    def _parse_response(self, data: dict) -> str:
        return data.get("reply") or data.get("content") or data.get("message") or str(data)

    def _parse_tool_events(self, data: dict) -> list[dict]:
        """Subclass hook: extract tool invocations from the parsed JSON body
        into the uniform `[{"tool": str, "args": str}, ...]` shape consumed by
        `tool_event_not_invoked`. Default returns `[]` since the generic body
        schema is content-only."""
        return []

    def _make_client(self) -> httpx.AsyncClient:
        if self._client_factory is not None:
            return self._client_factory()
        return httpx.AsyncClient(timeout=self._timeout)

    async def send(self, message: str, session_id: str) -> AgentResponse:
        url = f"{self._base_url}{self._path}"
        start = time.monotonic()
        status: int | None = None
        headers: dict[str, str] = {}
        data: dict = {}
        content: str = ""
        error: str | None = None
        tool_events: list[dict] = []
        try:
            async with self._make_client() as client:
                resp = await client.post(
                    url,
                    json=self._build_request(message, session_id),
                    headers=self._headers or None,
                )
                status = resp.status_code
                headers = dict(resp.headers)
                if 200 <= resp.status_code < 300:
                    try:
                        data = resp.json()
                        content = self._parse_response(data)
                        tool_events = self._parse_tool_events(data)
                    except ValueError as exc:
                        error = f"non-JSON 2xx body: {exc}"
                        content = resp.text
                else:
                    error = f"HTTP {resp.status_code}: {resp.text[:200]}"
                    content = resp.text
        except httpx.HTTPError as exc:
            error = f"{type(exc).__name__}: {exc}"
        return AgentResponse(
            content=content,
            raw=data,
            latency_ms=(time.monotonic() - start) * 1000,
            status_code=status,
            headers=headers,
            request_url=url,
            error=error,
            tool_events=tool_events,
        )
