"""Adapter registry — resolves CLI/config `adapter` strings to factory callables.

Why: keeping construction in a registry means new adapters need no CLI edits and
can be tested in isolation. Spec §5.2.
"""

from collections.abc import Callable

from .base import AgentAdapter

AdapterFactory = Callable[..., AgentAdapter]

_REGISTRY: dict[str, AdapterFactory] = {}


def register(name: str, factory: AdapterFactory) -> None:
    if name in _REGISTRY:
        raise ValueError(f"adapter {name!r} is already registered")
    _REGISTRY[name] = factory


def get(name: str) -> AdapterFactory:
    if name not in _REGISTRY:
        raise KeyError(
            f"unknown adapter {name!r}; available: {sorted(_REGISTRY)}"
        )
    return _REGISTRY[name]


def available() -> list[str]:
    return sorted(_REGISTRY)


def _register_builtins() -> None:
    # Imports kept local to avoid circular imports at module load.
    from .http import HttpAgentAdapter
    from .openclaw_gateway import OpenClawGatewayAdapter

    register("http", HttpAgentAdapter)
    register("openclaw-gateway", OpenClawGatewayAdapter)


_register_builtins()
