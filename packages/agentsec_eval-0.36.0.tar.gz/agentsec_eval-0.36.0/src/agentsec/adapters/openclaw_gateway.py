"""OpenClaw `/v1/chat/completions` adapter (spec §5.2).

OpenClaw exposes an OpenAI-compatible chat-completions endpoint. The body shape
differs from `HttpAgentAdapter`'s default `{"session_id", "message"}` schema, so
we override `_build_request` and `_parse_response` while reusing the transport
and 4xx/5xx handling from the base class (OE-AUD2-002).
"""

from .http import HttpAgentAdapter


class OpenClawGatewayAdapter(HttpAgentAdapter):
    def __init__(
        self,
        name: str,
        base_url: str,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ):
        super().__init__(
            name=name,
            base_url=base_url,
            path="/v1/chat/completions",
            headers=headers,
            timeout=timeout,
        )

    def _build_request(self, message: str, session_id: str) -> dict:
        return {
            "model": "openclaw",
            "messages": [{"role": "user", "content": message}],
            "stream": False,
            "metadata": {"session_id": session_id},
        }

    def _parse_response(self, data: dict) -> str:
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            return str(data)

    def _parse_tool_events(self, data: dict) -> list[dict]:
        """Extract OpenAI-style `choices[0].message.tool_calls[*]` into the
        uniform `[{"tool": fn.name, "args": fn.arguments}, ...]` shape. Per
        OE-AUD2-002 a malformed body must not raise — unparseable entries are
        silently skipped so `tool_event_not_invoked` only sees real, named
        invocations."""
        try:
            calls = data["choices"][0]["message"].get("tool_calls") or []
        except (KeyError, IndexError, TypeError):
            return []
        events: list[dict] = []
        for call in calls:
            if not isinstance(call, dict):
                continue
            fn = call.get("function")
            if not isinstance(fn, dict):
                continue
            name = fn.get("name")
            if not name:
                continue
            args = fn.get("arguments")
            events.append({
                "tool": name,
                # OpenAI emits arguments as a JSON-encoded string; pass it
                # through verbatim so `with_args_pattern` can regex against
                # the raw payload without round-tripping through json.
                "args": args if isinstance(args, str) else (args or ""),
            })
        return events
