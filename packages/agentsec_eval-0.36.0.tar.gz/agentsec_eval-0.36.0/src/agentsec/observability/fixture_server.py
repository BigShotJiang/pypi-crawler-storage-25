"""Fixture HTTP server — three v1 topologies (spec §7.2 / OE-AUD3-002).

The `target-local-http` mode was removed (OE-AUD3-002): launching short-lived
HTTP servers on the target side requires a remote-process-start authorization
mechanism we do not introduce in v1.

Each topology shares the same aiohttp request handler (`_make_app`) and
differs only in *where* and *how* the listener is exposed. v1 implements
`same-host-loopback` here; B.7 adds `reachable-url`; B.8 adds
`ssh-port-forward`.
"""

from __future__ import annotations

import contextlib
import socket
from collections.abc import AsyncIterator
from pathlib import Path

from aiohttp import web

from .network_observer import FixtureOnlyObserver


def _pick_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _make_app(root: Path, observer: FixtureOnlyObserver) -> web.Application:
    root_resolved = root.resolve()

    async def handler(request: web.Request) -> web.StreamResponse:
        observer.record(
            method=request.method,
            path=request.path_qs,
            remote_addr=request.remote or "",
            headers={k: v for k, v in request.headers.items()},
        )
        # Strip leading slash, resolve, then verify containment under root.
        rel = request.path.lstrip("/")
        if not rel:
            return web.Response(status=404)
        try:
            target = (root_resolved / rel).resolve(strict=False)
        except OSError:
            return web.Response(status=400)
        try:
            target.relative_to(root_resolved)
        except ValueError:
            return web.Response(status=400)
        if not target.is_file():
            return web.Response(status=404)
        return web.FileResponse(target)

    app = web.Application()
    app.router.add_route("*", "/{tail:.*}", handler)
    return app


class ReachableFixtureServer:
    """`reachable-url`: binds `bind` (default 0.0.0.0); `public_base_url` is
    what the target agent dials. The literal `{port}` placeholder, if present,
    is substituted with the chosen port (so callers don't need to fix the port
    in advance).
    """

    def __init__(
        self,
        root: Path,
        observer: FixtureOnlyObserver,
        bind: str = "0.0.0.0",  # noqa: S104 — see FixtureConfig.bind in config.py
        public_base_url: str = "",
    ):
        if not public_base_url:
            raise ValueError(
                "ReachableFixtureServer requires public_base_url "
                "(set fixture.public_base_url in the suite config)"
            )
        self._root = Path(root)
        self._observer = observer
        self._bind = bind
        self._public_base_url = public_base_url

    @contextlib.asynccontextmanager
    async def serving(self) -> AsyncIterator[str]:
        port = _pick_free_port()
        runner = web.AppRunner(_make_app(self._root, self._observer))
        await runner.setup()
        site = web.TCPSite(runner, self._bind, port)
        await site.start()
        try:
            yield self._public_base_url.replace("{port}", str(port))
        finally:
            await runner.cleanup()


class LoopbackFixtureServer:
    """`same-host-loopback`: binds 127.0.0.1:RAND. Used when evaluator and
    target run on the same host (CI, local dev)."""

    def __init__(self, root: Path, observer: FixtureOnlyObserver):
        self._root = Path(root)
        self._observer = observer

    @contextlib.asynccontextmanager
    async def serving(self) -> AsyncIterator[str]:
        port = _pick_free_port()
        runner = web.AppRunner(_make_app(self._root, self._observer))
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", port)
        await site.start()
        try:
            yield f"http://127.0.0.1:{port}"
        finally:
            await runner.cleanup()


class SshPortForwardFixtureServer:
    """`ssh-port-forward`: opens an SSH `-R` reverse tunnel so the target
    machine sees the fixture at its own `127.0.0.1:RAND`.

    The Transport is injected so tests can mock paramiko; production callers
    (Stage D) supply a real `paramiko.Transport`. v1 forwards to a local
    aiohttp listener bound on 127.0.0.1.
    """

    def __init__(
        self,
        root: Path,
        observer: FixtureOnlyObserver,
        transport,  # paramiko.Transport-like; typed loosely to avoid hard import
        remote_address: str = "127.0.0.1",
        remote_port: int = 0,
    ):
        self._root = Path(root)
        self._observer = observer
        self._transport = transport
        self._remote_address = remote_address
        self._remote_port = remote_port

    def _make_handler(self, local_port: int):
        # paramiko handler signature: (channel, src_addr, dest_addr) -> None.
        # We bridge the channel into our local aiohttp listener via a TCP
        # socket; the simplest two-thread pump that works for HTTP fetches.
        import socket as _socket
        import threading as _threading

        def _handler(channel, src_addr, dest_addr):
            sock = _socket.create_connection(("127.0.0.1", local_port))

            def _pump(src, dst):
                try:
                    while True:
                        data = src.recv(4096)
                        if not data:
                            break
                        dst.sendall(data)
                finally:
                    src.close()
                    dst.close()

            _threading.Thread(target=_pump, args=(channel, sock), daemon=True).start()
            _threading.Thread(target=_pump, args=(sock, channel), daemon=True).start()

        return _handler

    @contextlib.asynccontextmanager
    async def serving(self) -> AsyncIterator[str]:
        # Local aiohttp listener (loopback only — exposed via SSH).
        local_port = _pick_free_port()
        runner = web.AppRunner(_make_app(self._root, self._observer))
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", local_port)
        await site.start()
        bound_remote_port = self._transport.request_port_forward(
            self._remote_address,
            self._remote_port,
            self._make_handler(local_port),
        )
        try:
            yield f"http://{self._remote_address}:{bound_remote_port}"
        finally:
            try:
                self._transport.cancel_port_forward(
                    self._remote_address, bound_remote_port
                )
            finally:
                await runner.cleanup()
