"""NetworkObserver — observes outbound traffic from the target agent.

Spec §5.4 / OE-AUD2-006. Only fixture_only is implemented in v1; the other
modes (reverse_proxy, dns_sink, egress_log) keep the interface ready for v1.x.

Why split this from fixture_server: a fixture is a *content source* the target
fetches; an observer is the *witness* recording what was fetched and where it
came from.
"""

from __future__ import annotations

import fnmatch
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel, Field

ObserverMode = Literal["fixture_only", "reverse_proxy", "dns_sink", "egress_log"]


class NetworkObserverConfig(BaseModel):
    mode: ObserverMode = "fixture_only"
    controlled_domains: list[str] = Field(default_factory=list)
    proxy_url: str = ""  # only meaningful when mode=reverse_proxy


def domain_matches_pattern(pattern: str, host: str) -> bool:
    """Match `*.example.com`-style patterns against a hostname.

    `*.example.com` matches `a.example.com` and `a.b.example.com` but NOT bare
    `example.com` (apex). Exact strings match exactly. Any port suffix on
    `host` (e.g. `example.com:8080`) is stripped before matching, since the
    Host header carries the port for non-default services and the pattern
    syntax only addresses hostnames.
    """
    host = host.split(":", 1)[0]
    if pattern == host:
        return True
    if pattern.startswith("*."):
        suffix = pattern[1:]  # ".example.com"
        return host.endswith(suffix) and host != suffix.lstrip(".")
    return fnmatch.fnmatchcase(host, pattern)


def target_is_controlled(target: str, cfg: NetworkObserverConfig) -> bool:
    return any(domain_matches_pattern(p, target) for p in cfg.controlled_domains)


@dataclass
class FixtureEvent:
    """Recorded GET/POST against the evaluator-controlled fixture server."""

    method: str
    path: str
    remote_addr: str
    timestamp: float
    headers: dict[str, str] = field(default_factory=dict)


@dataclass
class OutboundRequest:
    """Recorded outbound HTTP from the target agent (mode-specific)."""

    target_host: str
    method: str
    url: str
    timestamp: float


class NetworkObserver(ABC):
    """ABC. Implementations buffer events; runner snapshots them per turn."""

    @abstractmethod
    def fixture_events(self) -> list[FixtureEvent]: ...

    @abstractmethod
    def outbound_requests(self) -> list[OutboundRequest]: ...

    @abstractmethod
    def reset(self) -> None: ...


class FixtureOnlyObserver(NetworkObserver):
    """Records only what hit the evaluator-controlled fixture HTTP server.

    A `FixtureEvent` is automatically projected into an `OutboundRequest` whose
    `target_host` is the Host header — that lets `outbound_request_not_to`
    fire when the target agent fetched the fixture under a controlled domain.
    """

    def __init__(self) -> None:
        # threading.Lock (not asyncio.Lock) so record() stays safe when called
        # from non-asyncio contexts — e.g. paramiko port-forward callbacks in
        # B.8's ssh-port-forward bridge run on background threads. Never await
        # inside the lock: the critical sections here are all synchronous list
        # appends/copies.
        self._lock = threading.Lock()
        self._events: list[FixtureEvent] = []

    def record(
        self,
        *,
        method: str,
        path: str,
        remote_addr: str,
        headers: dict[str, str],
    ) -> None:
        # Lowercase header keys defensively so the `Host` lookup in
        # outbound_requests() always sees the same key regardless of caller.
        normalized = {k.lower(): v for k, v in headers.items()}
        with self._lock:
            self._events.append(FixtureEvent(
                method=method,
                path=path,
                remote_addr=remote_addr,
                timestamp=time.time(),
                headers=normalized,
            ))

    def fixture_events(self) -> list[FixtureEvent]:
        with self._lock:
            return list(self._events)

    def outbound_requests(self) -> list[OutboundRequest]:
        # v1 fixture is plaintext HTTP only (spec §7.2); revisit when reverse_proxy
        # mode supports TLS.
        with self._lock:
            return [
                OutboundRequest(
                    target_host=ev.headers.get("host", ""),
                    method=ev.method,
                    url=f"http://{ev.headers.get('host', '')}{ev.path}",
                    timestamp=ev.timestamp,
                )
                for ev in self._events
            ]

    def reset(self) -> None:
        with self._lock:
            self._events.clear()
