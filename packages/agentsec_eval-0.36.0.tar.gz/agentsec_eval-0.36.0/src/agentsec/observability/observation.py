"""Observation collected by the runner before the judge sees a test result.

Per spec §4 / OE-AUD4-003: every list/dict default uses Field(default_factory=...)
to avoid shared mutable state across instances.
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from ..adapters.base import AgentResponse


class Observation(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    response: AgentResponse
    outbound_requests: list[dict[str, Any]] = Field(default_factory=list)
    fixture_events: list[dict[str, Any]] = Field(default_factory=list)
    tool_events: list[dict[str, Any]] = Field(default_factory=list)
    pre_state_snapshot: dict[str, Any] | None = None
    post_state_snapshot: dict[str, Any] | None = None
