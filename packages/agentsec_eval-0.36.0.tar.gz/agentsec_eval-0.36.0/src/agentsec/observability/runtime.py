"""Fixture runtime: resolves `serve_via: auto`, manages lifecycle, substitutes
`{{fixture_url}}` into turn payloads. Spec §7.2."""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from pathlib import Path

from agentsec.tests.models import Fixture, ServeVia

from .fixture_server import (
    LoopbackFixtureServer,
    ReachableFixtureServer,
    SshPortForwardFixtureServer,
)
from .network_observer import FixtureOnlyObserver


def resolve_serve_via(
    fixture: Fixture,
    *,
    evaluator_and_target_same_host: bool,
) -> ServeVia:
    if fixture.serve_via != "auto":
        return fixture.serve_via
    if fixture.public_base_url:
        return "reachable-url"
    if evaluator_and_target_same_host:
        return "same-host-loopback"
    raise ValueError(
        "fixture.serve_via=auto could not pick a topology: set "
        "fixture.public_base_url (reachable-url) or run on the same host "
        "as the target (same-host-loopback)"
    )


def substitute_fixture_url(text: str, base_url: str) -> str:
    return text.replace("{{fixture_url}}", base_url)


class FixtureRuntime:
    """Per-test fixture lifecycle. `active()` yields the base URL the target
    should fetch; the underlying server is torn down on exit (including on
    exception)."""

    def __init__(
        self,
        fixture: Fixture,
        suite_root: Path,
        observer: FixtureOnlyObserver,
        *,
        evaluator_and_target_same_host: bool,
        ssh_transport=None,
    ):
        self._fixture = fixture
        self._suite_root = Path(suite_root)
        self._observer = observer
        self._same_host = evaluator_and_target_same_host
        self._ssh_transport = ssh_transport

    @contextlib.asynccontextmanager
    async def active(self) -> AsyncIterator[str]:
        mode = resolve_serve_via(
            self._fixture,
            evaluator_and_target_same_host=self._same_host,
        )
        # fixture.path is relative to suite root; serve its parent directory so
        # the file lives at /<path.name> on the fixture URL.
        fixture_path = Path(self._fixture.path)
        root = self._suite_root / fixture_path.parent
        if mode == "same-host-loopback":
            server = LoopbackFixtureServer(root=root, observer=self._observer)
            async with server.serving() as url:
                yield url
        elif mode == "reachable-url":
            server = ReachableFixtureServer(
                root=root,
                observer=self._observer,
                bind=self._fixture.bind,
                public_base_url=self._fixture.public_base_url,
            )
            async with server.serving() as url:
                yield url
        elif mode == "ssh-port-forward":
            if self._ssh_transport is None:
                raise ValueError(
                    "ssh-port-forward requires an ssh_transport (paramiko); "
                    "wired in stage D"
                )
            server = SshPortForwardFixtureServer(
                root=root,
                observer=self._observer,
                transport=self._ssh_transport,
            )
            async with server.serving() as url:
                yield url
        else:  # pragma: no cover -- ServeVia is exhaustive
            raise ValueError(f"unknown serve_via: {mode}")
