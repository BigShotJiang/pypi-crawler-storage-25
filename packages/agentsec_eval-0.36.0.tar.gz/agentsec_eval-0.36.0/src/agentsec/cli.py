"""CLI entry point: agentsec run <tests_dir> --target <url> [--adapter NAME]"""

import asyncio
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import UTC, datetime
from pathlib import Path

import typer
from rich.console import Console

from .adapters import registry as adapter_registry
from .adapters.ws_adapter import WebSocketAgentAdapter
from .audit import Redactor
from .audit.authorization import Authorization, AuthorizationError
from .audit.checks.active_test import ActiveTestCheck
from .audit.checks.auditd_rules import AuditdRulesCheck
from .audit.checks.base import CheckContext
from .audit.checks.config_audit import ConfigAuditCheck
from .audit.checks.containerd_daemon_audit import ContainerdDaemonAuditCheck
from .audit.checks.containerd_image_cve import ContainerdImageCveCheck
from .audit.checks.containerd_runtime_audit import ContainerdRuntimeAuditCheck
from .audit.checks.credential_audit import CredentialAuditCheck
from .audit.checks.docker_daemon_audit import DockerDaemonAuditCheck
from .audit.checks.docker_image_cve import DockerImageCveCheck
from .audit.checks.docker_runtime_audit import DockerRuntimeAuditCheck
from .audit.checks.exposure_scan import ExposureScanCheck
from .audit.checks.filesystem import FilesystemCheck
from .audit.checks.firewalld_audit import FirewalldAuditCheck
from .audit.checks.go_supply_chain_audit import GoSupplyChainAuditCheck
from .audit.checks.iptables_audit import IptablesAuditCheck
from .audit.checks.log_review import LogReviewCheck
from .audit.checks.native_audit import NativeAuditCheck
from .audit.checks.nftables_audit import NftablesAuditCheck
from .audit.checks.pip_supply_chain_audit import PipSupplyChainAuditCheck
from .audit.checks.plugin_static import PluginStaticCheck
from .audit.checks.podman_daemon_audit import PodmanDaemonAuditCheck
from .audit.checks.podman_image_cve import PodmanImageCveCheck
from .audit.checks.podman_runtime_audit import PodmanRuntimeAuditCheck
from .audit.checks.process_forensics import ProcessForensicsCheck
from .audit.checks.rust_supply_chain_audit import RustSupplyChainAuditCheck
from .audit.checks.sshd_config_audit import SshdConfigAuditCheck
from .audit.checks.sudoers_audit import SudoersAuditCheck
from .audit.checks.suid_audit import SuidAuditCheck
from .audit.checks.supply_chain_audit import SupplyChainAuditCheck
from .audit.checks.sysctl_audit import SysctlAuditCheck
from .audit.checks.systemd_service_blacklist import SystemdServiceBlacklistCheck
from .audit.checks.systemd_unit_lint import SystemdUnitLintCheck
from .audit.checks.ufw_audit import UfwAuditCheck
from .audit.checks.version_patch import VersionPatchCheck
from .audit.checks.world_writable import WorldWritableCheck
from .audit.command_policy import CommandPolicy
from .audit.path_matcher import expand_tilde
from .audit.platform_profile import (
    LINUX_USER_MODE,
    detect_platform,
    materialize_paths,
)
from .audit.remote_home import resolve_remote_home
from .audit.runtime_probe import probe_systemd_user_mode, resolve_openclaw_bin
from .audit.server_audit import run_server_audit
from .audit.ssh import SSHExecutor
from .audit.tunnel import open_local_forward
from .config import (
    LogReviewConfig,
    MultiTargetConfig,
    OpenAIJudgeConfig,
    OpenClawTargetConfig,
    PluginJudgeConfig,
    ServerAuditConfig,
)
from .evaluator.base import Judge
from .evaluator.deterministic_judge import DeterministicJudge
from .evaluator.hybrid_judge import HybridJudge
from .evaluator.judge_factory import build_default_judge_from_env
from .evaluator.judge_router import JudgeRouter
from .evaluator.no_op_judge import NoOpJudge
from .evaluator.openai_judge import OpenAICompatibleJudge
from .evaluator.plugin_judge import PluginJudge
from .observability.network_observer import FixtureOnlyObserver, NetworkObserverConfig
from .reports.json_report import write_findings_json, write_threat_intel_snapshot
from .reports.markdown import (
    TargetDescriptor,
    render_combined_report,
    render_remote_report,
    render_server_audit_report,
)
from .reports.multi_summary import TargetResult, render_multi_summary
from .runner import run_suite
from .scoring import score_evaluation
from .suite_registry import (
    DefaultRegistry,
    HttpRegistry,
    Registry,
    Store,
    SuiteAlreadyInstalled,
    SuiteError,
    SuiteHashMismatch,
    canonical_hash,
)
from .suite_registry import install as suite_install
from .tests.loader import load_test_suite
from .tests.models import TestCase

app = typer.Typer(help="AgentSec — AI agent security assessment tool")
console = Console()


# WHY: Typer 0.24 collapses single-command apps to root level — the no-op
# callback forces subcommand mode so `agentsec run ...` routes correctly.
@app.callback()
def _main() -> None:
    """AgentSec — AI agent security assessment tool."""


suite_app = typer.Typer(help="Manage community-contributed test suites.")
app.add_typer(suite_app, name="suite")


def _resolve_registry(registry_url: str | None) -> Registry:
    return HttpRegistry(registry_url) if registry_url else DefaultRegistry()



def _log_runtime_paths_added(audit_log: Path, paths: list[str], source: str) -> None:
    """Write an audit-log entry when CommandPolicy.add_runtime_allowed_paths runs.

    Spec §5 + ADR-0013 D6: operators must be able to trace why an exact-kind
    path was permitted at runtime.
    """
    audit_log.parent.mkdir(parents=True, exist_ok=True)
    with audit_log.open("a") as f:
        f.write(json.dumps({
            "ts": datetime.now(UTC).isoformat(),
            "event": "runtime_allowed_paths_added",
            "paths": paths,
            "source": source,
        }) + "\n")


def _emit_case_count_warning(suite_dir: Path) -> None:
    """Spec §4.1: case_count mismatch is a warning at CLI surface, not fatal.

    Read manifest.yaml back from the installed location and flat-count cases
    via the loader. The installer already validated both sides so anything
    that raises here is unexpected — swallow it rather than fail the install.
    """
    try:
        import yaml as _yaml
        manifest_data = _yaml.safe_load((suite_dir / "manifest.yaml").read_text()) or {}
        declared = manifest_data.get("case_count")
        actual = len(load_test_suite(suite_dir / "cases"))
    except Exception:  # noqa: BLE001 — never block the success path on a warning
        return
    if isinstance(declared, int) and declared != actual:
        console.print(
            f"[yellow]warning:[/yellow] manifest case_count={declared} but "
            f"{actual} cases were loaded — please update the manifest."
        )


@suite_app.command("list")
def suite_list_cmd(
    registry_url: str = typer.Option(
        None, "--registry-url", hidden=True,
        help="Override registry source (dev/test).",
    ),
) -> None:
    """List suites available in the registry plus their installed status."""
    try:
        registry = _resolve_registry(registry_url)
        available = registry.all_entries()
    except SuiteError as exc:
        console.print(f"[red]Failed to load registry:[/red] {exc}")
        raise typer.Exit(1) from exc
    store = Store()
    installed = {s.name: s for s in store.list_installed()}
    if not available and not installed:
        console.print(
            "No suites in registry. Submit one via PR — see "
            "docs/guide/contributing-a-suite.md."
        )
        return
    console.print("[bold]Available suites[/bold]")
    for name, entry in sorted(available.items()):
        local = installed.get(name)
        status = (
            f"installed v{local.version}" if local and not local.corrupted else "—"
        )
        summary = (entry.summary or "")[:60]
        console.print(f"  {name:30s} {summary:60s} [{status}]")
    extras = sorted(set(installed) - set(available))
    if extras:
        console.print("\n[bold]Installed (not in current registry)[/bold]")
        for name in extras:
            local = installed[name]
            tag = "corrupted" if local.corrupted else f"v{local.version}"
            console.print(f"  {name:30s} [{tag}]")


@suite_app.command("info")
def suite_info_cmd(name: str) -> None:
    """Print manifest details for an installed suite."""
    store = Store()
    if not store.is_installed(name):
        console.print(
            f"[red]Suite {name!r} is not installed.[/red] Run "
            f"[bold]agentsec suite install {name}[/bold] first."
        )
        raise typer.Exit(1)
    suite_dir = store.root / name
    console.print((suite_dir / "manifest.yaml").read_text())
    readme = suite_dir / "README.md"
    if readme.exists():
        first_para = readme.read_text().split("\n\n", 1)[0]
        console.print(f"\n[bold]README:[/bold]\n{first_para}")


@suite_app.command("install")
def suite_install_cmd(
    name: str,
    force: bool = typer.Option(False, "--force", help="Overwrite an existing install."),
    registry_url: str = typer.Option(None, "--registry-url", hidden=True),
) -> None:
    """Install a community suite by name."""
    try:
        registry = _resolve_registry(registry_url)
        result = suite_install(name, registry=registry, store=Store(), force=force)
    except SuiteHashMismatch as exc:
        console.print(f"[red bold]{exc}[/red bold]")
        raise typer.Exit(2) from exc
    except SuiteAlreadyInstalled as exc:
        console.print(f"[yellow]{exc}[/yellow]")
        raise typer.Exit(1) from exc
    except SuiteError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc
    suite_dir = Store().root / result.name
    console.print(
        f"[green]✓[/green] Suite {result.name!r} installed (v{result.version}) at {suite_dir}"
    )
    _emit_case_count_warning(suite_dir)


@suite_app.command("uninstall")
def suite_uninstall_cmd(name: str) -> None:
    """Remove a locally installed suite."""
    store = Store()
    removed = store.remove(name)
    if removed:
        console.print(f"[green]✓[/green] Removed {name!r}")
    else:
        console.print(f"Suite {name!r} was not installed (no-op)")


@suite_app.command("hash", hidden=True)
def suite_hash_cmd(path: Path) -> None:
    """Compute the canonical hash of a local bundle directory."""
    if not path.is_dir():
        console.print(f"[red]Not a directory:[/red] {path}")
        raise typer.Exit(1)
    typer.echo(canonical_hash(path))


@app.command()
def run(
    tests: Path = typer.Argument(None, help="YAML test file or directory (omit if using --suite)"),
    target: str = typer.Option(..., help="Base URL of the target agent"),
    name: str = typer.Option("target-agent", help="Human-readable agent name"),
    suite: str = typer.Option(
        None, "--suite",
        help="Run an installed community suite by name "
             "(mutually exclusive with the positional path)",
    ),
    # NOTE: available() is snapshotted at import time; if plugin loading is
    # introduced (spec §5.2 hint), defer this to a dynamic help renderer.
    adapter: str = typer.Option(
        "http",
        help=f"Adapter name (one of: {', '.join(adapter_registry.available())})",
    ),
    token_env: str = typer.Option(
        None,
        help="Env var holding the bearer token sent to the target agent",
    ),
    observer_mode: str = typer.Option(
        "fixture_only",
        help="Network observer mode (fixture_only|reverse_proxy|dns_sink|egress_log)",
    ),
    controlled_domain: list[str] = typer.Option(
        [],
        help="Domain pattern (e.g. *.agentsec.test) considered evaluator-controlled. "
             "Repeat to add more.",
    ),
    same_host: bool = typer.Option(
        False,
        help="Evaluator and target run on the same host (enables same-host-loopback fixture)",
    ),
    output: Path = typer.Option(Path("report.md"), help="Output report path"),
    concurrency: int = typer.Option(3, help="Max parallel test sessions"),
    api_key: str = typer.Option(
        None,
        envvar=["AGENTSEC_LLM_API_KEY", "AGENTSEC_JUDGE_API_KEY"],
        help="LLM judge API key. Anthropic by default; switch providers via "
             "AGENTSEC_LLM_PROVIDER + AGENTSEC_LLM_BASE_URL + AGENTSEC_LLM_MODEL.",
    ),
    ws_url: str = typer.Option(
        None,
        help="WebSocket URL for cross-channel tests (e.g. ws://localhost:8080/ws)",
    ),
):
    if suite is not None and tests is not None:
        console.print(
            "[red]--suite and the positional <tests> path are mutually exclusive.[/red]"
        )
        raise typer.Exit(code=2)
    suite_root: Path
    if suite is not None:
        resolved = Store().resolve(suite)
        if resolved is None:
            console.print(
                f"[red]Suite {suite!r} is not installed. Run "
                f"[bold]agentsec suite install {suite}[/bold] first.[/red]"
            )
            raise typer.Exit(code=1)
        # `Store.resolve` returns the cases/ subdir (loader entry point),
        # but suite_root for fixture resolution must point at the bundle
        # root — fixture.path values are relative to the bundle, and the
        # installer lays out cases/ and fixtures/ as siblings.
        tests = resolved
        suite_root = resolved.parent
    elif tests is None:
        console.print("[red]Either pass a test path or use --suite.[/red]")
        raise typer.Exit(code=2)
    else:
        suite_root = tests if tests.is_dir() else tests.parent

    try:
        factory = adapter_registry.get(adapter)
    except KeyError as exc:
        console.print(f"[red]error:[/red] {exc}")
        raise typer.Exit(code=2) from exc

    headers: dict[str, str] = {}
    if token_env:
        token = os.environ.get(token_env)
        if not token:
            console.print(f"[red]error:[/red] env var {token_env!r} is empty")
            raise typer.Exit(code=2)
        headers["Authorization"] = f"Bearer {token}"

    obs_cfg = NetworkObserverConfig(
        mode=observer_mode,
        controlled_domains=controlled_domain,
    )
    try:
        test_cases = load_test_suite(tests, observer_config=obs_cfg)
    except ValueError as exc:
        console.print(f"[red]error:[/red] {exc}")
        raise typer.Exit(code=2) from exc
    observer = FixtureOnlyObserver()
    console.print(f"[bold]Loaded {len(test_cases)} test cases[/bold]")

    adapter_obj = factory(name=name, base_url=target, headers=headers or None)

    ws_adapter: WebSocketAgentAdapter | None = (
        WebSocketAgentAdapter(ws_url) if ws_url else None
    )

    needs_llm = any(tc.judge_type in {"llm", "hybrid"} for tc in test_cases)
    if needs_llm:
        if api_key:
            os.environ["AGENTSEC_LLM_API_KEY"] = api_key
        try:
            llm = build_default_judge_from_env()
        except Exception as exc:  # noqa: BLE001 — surface a friendly CLI error
            console.print(
                f"[red]error:[/red] suite includes llm/hybrid cases but the "
                f"judge could not be constructed: {exc}\n"
                "Configure one of:\n"
                "  • Anthropic Claude (default): export ANTHROPIC_API_KEY=...\n"
                "  • OpenAI-compatible: export AGENTSEC_LLM_PROVIDER=openai "
                "AGENTSEC_LLM_BASE_URL=... AGENTSEC_LLM_MODEL=... "
                "AGENTSEC_LLM_API_KEY=...\n"
                "  • Or restrict the suite to judge_type=deterministic."
            )
            raise typer.Exit(code=2) from exc
    else:
        # Deterministic-only suite: NoOpJudge fills the LLM slot. JudgeRouter
        # never dispatches to it (closes Stage C M4 — was `_UnreachableLLM`).
        llm = NoOpJudge()

    judge = JudgeRouter(
        llm=llm,
        deterministic=DeterministicJudge(),
        hybrid=HybridJudge(llm_judge=llm),
    )

    results = asyncio.run(run_suite(
        adapter_obj, judge, test_cases, concurrency,
        observer=observer,
        suite_root=suite_root,
        evaluator_and_target_same_host=same_host,
        ws_adapter=ws_adapter,
    ))

    counts = {s: sum(1 for r in results if r.status == s)
              for s in ("passed", "failed", "skipped", "error", "not_applicable")}
    console.print(
        f"[green]Passed: {counts['passed']}[/green]  "
        f"[red]Failed: {counts['failed']}[/red]  "
        f"[yellow]Skipped: {counts['skipped']}[/yellow]  "
        f"[red]Errors: {counts['error']}[/red]  "
        f"[dim]N/A: {counts['not_applicable']}[/dim]"
    )

    # `agentsec run` is the no-config one-shot path — there's no scoring intent.
    # Call `render_remote_report` directly with a placeholder EvaluationScore.
    from .scoring import (
        CombinedScore,
        CoverageTriple,
        EvaluationScore,
    )
    placeholder_score = EvaluationScore(
        category_scores=[],
        remote_score=None, server_score=None,
        combined=CombinedScore(
            score=None, weight_remote_used=0.0,
            weight_server_used=0.0,
            note="legacy `agentsec run` flow (no scoring intent)",
        ),
        coverage=CoverageTriple(
            planned=max(1, len(results)),
            executed=len([r for r in results if r.status != "not_applicable"]),
            scored=len([r for r in results if r.status in ("passed", "failed")]),
            error=len([r for r in results if r.status == "error"]),
            execution_coverage=1.0, verdict_coverage=1.0, error_rate=None,
        ),
        low_coverage=False, grade="NOT_SCORED",
        deduped_findings=[],
    )
    report = render_remote_report(name, results, placeholder_score, cases=test_cases)
    output.write_text(report)
    console.print(f"Report written to [bold]{output}[/bold]")


@app.command("server-audit")
def server_audit(
    host: str = typer.Option(..., help="SSH target hostname"),
    user: str = typer.Option(..., help="SSH login user"),
    key: str = typer.Option(..., help="Path to SSH private key"),
    consent_file: Path = typer.Option(..., help="Path to AUTHORIZATION.txt"),
    output: Path = typer.Option(..., help="Output directory for artifacts"),
    policy_path: Path = typer.Option(
        Path(__file__).parent / "audit" / "ssh_policy.yaml",
        help="Path to ssh_policy.yaml",
    ),
    pip_lock_paths: list[str] = typer.Option(
        [], "--pip-lock-path",
        help="Repeat for each requirements.txt to scan; absolute or ~/-rooted.",
    ),
    go_lock_paths: list[str] = typer.Option(
        [], "--go-lock-path",
        help="Repeat for each go.sum to scan; absolute or ~/-rooted.",
    ),
    cargo_lock_paths: list[str] = typer.Option(
        [], "--cargo-lock-path",
        help="Repeat for each Cargo.lock to scan; absolute or ~/-rooted.",
    ),
    maven_lock_paths: list[str] = typer.Option(
        [],
        "--maven-lock-path",
        help="Path on remote host to `mvn dependency:list -DoutputFile=...` "
             "output (repeatable; multiple paths checked).",
    ),
    gem_lock_paths: list[str] = typer.Option(
        [],
        "--gem-lock-path",
        help="Path on remote host to a Bundler Gemfile.lock file "
             "(repeatable; multiple paths checked).",
    ),
    composer_lock_paths: list[str] = typer.Option(
        [],
        "--composer-lock-path",
        help="Path on remote host to a Composer composer.lock file "
             "(repeatable; multiple paths checked).",
    ),
):
    output.mkdir(parents=True, exist_ok=True)
    audit_log = output / "audit-log.jsonl"

    try:
        auth = Authorization.load(consent_file)
        auth.validate(
            target_host=host,
            report_output_path_prefix=str(output),
            required_scopes=["server-audit"],
        )
    except AuthorizationError as e:
        console.print(f"[red]authorization rejected:[/red] {e}")
        raise typer.Exit(code=2) from e

    if auth.low_assurance:
        console.print(
            "[yellow]LOW_ASSURANCE: signature_mode=none or identity_assertion blank[/yellow]"
        )

    policy = CommandPolicy.from_yaml(policy_path)
    redactor = Redactor()
    executor = SSHExecutor(
        policy=policy, redactor=redactor, audit_log_path=audit_log,
        host=host, user=user, key_filename=key,
    )

    # Detect platform before any check runs (spec §6.3 / E.0.e).
    uname_result = executor.run(["uname", "-s"])
    if uname_result.rejected or uname_result.exit_code != 0:
        reason = (
            uname_result.reject_reason
            if uname_result.rejected
            else (uname_result.stderr or "").strip()
        )
        console.print(
            f"[red]uname -s failed:[/red] rejected={uname_result.rejected} "
            f"exit={uname_result.exit_code} reason={reason!r}"
        )
        raise typer.Exit(code=2)
    profile = detect_platform(uname_result.stdout)
    remote_home = resolve_remote_home(user, profile)
    profile = materialize_paths(profile, remote_home)

    # Close the first executor before rebuilding with materialized paths to
    # prevent SSH connection leak (E.0.f code review).
    executor.close()

    # Rebuild policy + executor with the resolved home so PathMatcher expands
    # `~/` to the remote $HOME (not the evaluator's $HOME). shlex.quote inside
    # CommandPolicy.validate will produce single-quoted absolute paths that the
    # remote shell and find(1) both accept (ADR-0004).
    policy = CommandPolicy.from_yaml(policy_path, remote_home=remote_home)
    if pip_lock_paths:
        # Validate via the same Pydantic validator as evaluate-mode
        ServerAuditConfig.model_validate({
            "host": "validation-only",
            "user": "validation-only",
            "key": "/dev/null",
            "pip_lock_paths": pip_lock_paths,
        })
        expanded = [expand_tilde(p, remote_home) for p in pip_lock_paths]
        policy.add_runtime_allowed_paths(expanded, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded, "agentsec server-audit --pip-lock-path"
        )
    if go_lock_paths:
        ServerAuditConfig.model_validate({
            "host": "validation-only",
            "user": "validation-only",
            "key": "/dev/null",
            "go_lock_paths": go_lock_paths,
        })
        expanded_go = [expand_tilde(p, remote_home) for p in go_lock_paths]
        policy.add_runtime_allowed_paths(expanded_go, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_go,
            "agentsec server-audit --go-lock-path",
        )
    if cargo_lock_paths:
        ServerAuditConfig.model_validate({
            "host": "validation-only",
            "user": "validation-only",
            "key": "/dev/null",
            "cargo_lock_paths": cargo_lock_paths,
        })
        expanded_cargo = [expand_tilde(p, remote_home) for p in cargo_lock_paths]
        policy.add_runtime_allowed_paths(expanded_cargo, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_cargo,
            "agentsec server-audit --cargo-lock-path",
        )
    if maven_lock_paths:
        ServerAuditConfig.model_validate({
            "host": "validation-only",
            "user": "validation-only",
            "key": "/dev/null",
            "maven_lock_paths": maven_lock_paths,
        })
        expanded_maven = [expand_tilde(p, remote_home) for p in maven_lock_paths]
        policy.add_runtime_allowed_paths(expanded_maven, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_maven,
            "agentsec server-audit --maven-lock-path",
        )
    if gem_lock_paths:
        ServerAuditConfig.model_validate({
            "host": "validation-only",
            "user": "validation-only",
            "key": "/dev/null",
            "gem_lock_paths": gem_lock_paths,
        })
        expanded_gem = [expand_tilde(p, remote_home) for p in gem_lock_paths]
        policy.add_runtime_allowed_paths(expanded_gem, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_gem,
            "agentsec server-audit --gem-lock-path",
        )
    if composer_lock_paths:
        ServerAuditConfig.model_validate({
            "host": "validation-only",
            "user": "validation-only",
            "key": "/dev/null",
            "composer_lock_paths": composer_lock_paths,
        })
        expanded_composer = [expand_tilde(p, remote_home) for p in composer_lock_paths]
        policy.add_runtime_allowed_paths(expanded_composer, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_composer,
            "agentsec server-audit --composer-lock-path",
        )
    executor = SSHExecutor(
        policy=policy, redactor=redactor, audit_log_path=audit_log,
        host=host, user=user, key_filename=key,
    )

    # D3 — switch to user-mode profile if systemd --user OpenClaw deployment.
    if profile.name == "linux" and probe_systemd_user_mode(executor, remote_home):
        profile = materialize_paths(LINUX_USER_MODE, remote_home)
        console.print("[dim]systemd --user mode detected; using LINUX_USER_MODE profile[/dim]")

    # D1 — resolve openclaw binary path (paramiko non-login shell PATH gap).
    bin_path = resolve_openclaw_bin(executor, profile, remote_home)
    if bin_path != "openclaw":
        new_paths = dict(profile.paths)
        new_paths["openclaw_bin"] = bin_path
        profile = profile.model_copy(update={"paths": new_paths})
        console.print(f"[dim]openclaw bin: {bin_path}[/dim]")

    gateway_token = os.environ.get("OPENCLAW_GATEWAY_TOKEN")

    def _real_tunnel_factory(host_, user_, key_):
        return open_local_forward(host_, user_, key_, remote_port=18789)

    checks = [
        NativeAuditCheck(),
        ConfigAuditCheck(),
        VersionPatchCheck(),
        ActiveTestCheck(
            tunnel_factory=_real_tunnel_factory,
            host=host, user=user, key=key,
            bearer_token=gateway_token,
        ),
        ExposureScanCheck(host=host),
        FilesystemCheck(),
        ProcessForensicsCheck(),
        CredentialAuditCheck(ssh_user=user),
        PluginStaticCheck(),
        LogReviewCheck(),
        SysctlAuditCheck(),
        SshdConfigAuditCheck(),
        SudoersAuditCheck(),
        SuidAuditCheck(),
        WorldWritableCheck(),
        AuditdRulesCheck(),
        SystemdServiceBlacklistCheck(),
        SystemdUnitLintCheck(),
        IptablesAuditCheck(),
        NftablesAuditCheck(),
        UfwAuditCheck(),
        FirewalldAuditCheck(),
        DockerDaemonAuditCheck(),
        DockerRuntimeAuditCheck(),
        DockerImageCveCheck(),
        PodmanDaemonAuditCheck(),
        PodmanRuntimeAuditCheck(),
        PodmanImageCveCheck(),
        ContainerdDaemonAuditCheck(),
        ContainerdRuntimeAuditCheck(),
        ContainerdImageCveCheck(),
        SupplyChainAuditCheck(),
        PipSupplyChainAuditCheck(),
        GoSupplyChainAuditCheck(),
        RustSupplyChainAuditCheck(),
    ]

    ctx = CheckContext(
        executor=executor, redactor=redactor,
        ioc_dir=Path(__file__).parent / "audit" / "ioc",
        profile=profile,
        log_review_config=LogReviewConfig(),
        pip_lock_paths=tuple(expand_tilde(p, remote_home) for p in pip_lock_paths),
        go_lock_paths=tuple(expand_tilde(p, remote_home) for p in go_lock_paths),
        cargo_lock_paths=tuple(expand_tilde(p, remote_home) for p in cargo_lock_paths),
        maven_lock_paths=tuple(expand_tilde(p, remote_home) for p in maven_lock_paths),
        gem_lock_paths=tuple(expand_tilde(p, remote_home) for p in gem_lock_paths),
        composer_lock_paths=tuple(expand_tilde(p, remote_home) for p in composer_lock_paths),
    )

    report = asyncio.run(run_server_audit(checks=checks, ctx=ctx))

    write_findings_json(report.findings, output / "findings.json")
    target_descriptor = TargetDescriptor(
        host=host,
        user=user,
        key_path=key,
        auth_file=str(consent_file),
        openclaw_bin=bin_path if bin_path != "openclaw" else None,
        checks_run=tuple(c.id for c in checks),
    )
    (output / "server-audit-report.md").write_text(
        render_server_audit_report(
            report,
            profile_name=profile.name,
            remote_home=remote_home,
            low_assurance=auth.low_assurance,
            server_score=None,  # one-shot server-audit doesn't compute a score
            target=target_descriptor,
        )
    )

    executor.close()
    console.print(f"[green]wrote[/green] {output}")


def _run_mcp_real(cfg):
    """Sync entry-point for evaluate. Wraps _run_mcp_real_async in
    asyncio.run; tests should target _run_mcp_real_async directly."""
    return asyncio.run(_run_mcp_real_async(cfg))


async def _run_mcp_real_async(cfg):
    """Phase 7c.6 §5.2 — run the mcp_real pipeline inside evaluate.

    Returns ([], McpScore.not_run(...)) when the pipeline cannot run;
    never raises. Mirrors _evaluate_remote / _evaluate_server contract.
    """
    import os

    import anthropic
    import yaml
    from pydantic import ValidationError

    from .evaluator.judge import LLMJudge
    from .mcp_harness import (
        ClaudeMcpAdapter,
        load_mcp_real_suite,
        run_mcp_suite,
    )
    from .mcp_harness.scoring import McpScore, compute_mcp_score

    if "ANTHROPIC_API_KEY" not in os.environ:
        console.print(
            "[yellow]mcp_real configured but ANTHROPIC_API_KEY missing; "
            "skipping mcp_real pipeline[/yellow]"
        )
        return [], McpScore.not_run(reason="missing_api_key")

    try:
        cases = load_mcp_real_suite(cfg.mcp_real.suite)
    except FileNotFoundError as exc:
        return [], McpScore.not_run(reason=f"suite_load_error: {exc}")
    except yaml.YAMLError as exc:
        return [], McpScore.not_run(reason=f"suite_load_error: {exc}")
    except (ValueError, ValidationError) as exc:
        return [], McpScore.not_run(reason=f"schema_error: {exc}")

    model = cfg.mcp_real.model or os.environ.get(
        "AGENTSEC_MCP_MODEL", "claude-haiku-4-5-20251001"
    )
    client = anthropic.Anthropic()
    max_iter = cfg.mcp_real.max_iterations

    def _factory(*, fixtures, model):
        return ClaudeMcpAdapter(
            fixtures=fixtures,
            anthropic_client=client,
            model=model,
            max_iterations=max_iter,
        )

    try:
        results = await run_mcp_suite(
            cases=cases,
            judge=LLMJudge(model=model),
            adapter_factory=_factory,
            model=model,
            concurrency=cfg.mcp_real.concurrency,
        )
    except Exception as exc:  # noqa: BLE001 — pipeline-level fail
        return [], McpScore.not_run(reason=f"pipeline_error: {exc}")

    return results, compute_mcp_score(results)


@app.command()
def evaluate(
    config: Path = typer.Option(..., help="Path to openclaw-target.yaml (spec §8.2)"),
    output: Path = typer.Option(
        None,
        help="Output directory (overrides config.output.dir; spec §8.1)",
    ),
    api_key: str = typer.Option(
        None, envvar="AGENTSEC_JUDGE_API_KEY",
        help="Anthropic API key for LLM/hybrid judges",
    ),
):
    """End-to-end OpenClaw evaluation: remote suite + server-audit + scoring."""
    try:
        cfg = OpenClawTargetConfig.from_yaml(config)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]config error:[/red] {exc}")
        raise typer.Exit(code=2) from exc

    # Spec §8.1 example: `agentsec evaluate --config <yaml> --output <dir>`.
    # CLI flag overrides cfg.output.dir when provided; authorization gate
    # validates against the resolved path so the AUTHORIZATION.txt prefix
    # must match whichever the operator actually used.
    out = output if output is not None else cfg.output.dir
    out.mkdir(parents=True, exist_ok=True)

    remote_results, planned_count, remote_cases = (
        _evaluate_remote(cfg, api_key, out) if cfg.remote is not None
        else ([], 0, [])
    )
    try:
        server_findings, server_meta = (
            _evaluate_server(cfg, out) if cfg.server_audit is not None
            else ([], None)
        )
    except AuthorizationError as e:
        console.print(f"[red]authorization rejected:[/red] {e}")
        raise typer.Exit(code=2) from e

    mcp_results, mcp_score = (
        _run_mcp_real(cfg) if cfg.mcp_real is not None else ([], None)
    )

    # planned_count==0 (server-audit-only run) is handled inside score_evaluation;
    # don't `max(..., 1)` here — that would inflate execution_coverage and
    # spuriously trigger low_coverage on a clean audit-only config.
    score = score_evaluation(
        remote_results=remote_results,
        server_findings=server_findings,
        mcp_score=mcp_score,
        planned_count=planned_count,
        config=cfg,
    )

    if cfg.remote is not None:
        (out / "remote-report.md").write_text(
            render_remote_report(cfg.name, remote_results, score, cases=remote_cases)
        )
    if cfg.server_audit is not None and server_meta is not None:
        (out / "server-audit-report.md").write_text(
            render_server_audit_report(
                server_meta["report"], profile_name=server_meta["profile_name"],
                remote_home=server_meta["remote_home"],
                low_assurance=server_meta["low_assurance"],
                server_score=score.server_score,
                target=server_meta.get("target_descriptor"),
            )
        )
    (out / "combined-report.md").write_text(
        render_combined_report(
            cfg.name, score,
            remote_present=cfg.remote is not None,
            server_present=cfg.server_audit is not None,
            mcp_present=cfg.mcp_real is not None,
            cases=remote_cases if cfg.remote is not None else None,
            results=remote_results if cfg.remote is not None else None,
        )
    )
    if cfg.mcp_real is not None:
        from .mcp_harness import write_mcp_findings_json
        from .mcp_harness.report import render_mcp_real_report

        mcp_model = cfg.mcp_real.model or os.environ.get(
            "AGENTSEC_MCP_MODEL", "claude-haiku-4-5-20251001"
        )
        (out / "mcp-real-report.md").write_text(
            render_mcp_real_report(mcp_results, model=mcp_model)
        )
        write_mcp_findings_json(
            results=mcp_results, model=mcp_model,
            suite=cfg.mcp_real.suite,
            out_path=out / "mcp-findings.json",
        )
    write_findings_json(score.deduped_findings, out / "findings.json")

    referenced_refs: set[str] = set()
    for f in score.deduped_findings:
        referenced_refs.update(f.threat_refs)
    threat_intel_path = (cfg.server_audit.ioc_db / "threat_intel.yaml") \
        if cfg.server_audit is not None \
        else Path(__file__).parent / "audit" / "ioc" / "threat_intel.yaml"
    write_threat_intel_snapshot(
        referenced_refs, threat_intel_path, out / "threat-intel-snapshot.yaml"
    )

    # audit-log.jsonl: SSHExecutor writes it during _evaluate_server. When the
    # server half was skipped, ensure the file exists so consumers that always
    # look for it don't crash.
    (out / "audit-log.jsonl").touch(exist_ok=True)
    console.print(f"[green]wrote[/green] {out} (grade: {score.grade})")


def _build_llm_judge(cfg: OpenClawTargetConfig, api_key: str | None) -> Judge:
    """Return the appropriate LLM-slot judge based on the target config."""
    judge_cfg = cfg.judge
    if judge_cfg is None:
        # No yaml judge: fall through to env-driven factory (provider can be
        # Anthropic, OpenAI-compatible, or anything else `judge_factory`
        # supports). The CLI's --api-key flag normalises into
        # AGENTSEC_LLM_API_KEY before we reach here.
        if api_key:
            os.environ["AGENTSEC_LLM_API_KEY"] = api_key
        return build_default_judge_from_env()
    if isinstance(judge_cfg, OpenAIJudgeConfig):
        return OpenAICompatibleJudge(judge_cfg)
    if isinstance(judge_cfg, PluginJudgeConfig):
        # `_config_path` is populated by `OpenClawTargetConfig.from_yaml` and
        # `TargetEntry.to_openclaw_config`. A PluginJudgeConfig only exists
        # when the user wrote a `judge:` block in the yaml, so the yaml-load
        # path must have run — meaning `_config_path` is set.
        if cfg._config_path is None:
            raise RuntimeError(
                "PluginJudge requires _config_path; load OpenClawTargetConfig "
                "via from_yaml or pass config_path to to_openclaw_config"
            )
        resolved = (cfg._config_path.parent / judge_cfg.path).resolve()
        return PluginJudge(resolved)
    raise AssertionError(f"unhandled judge config type: {type(judge_cfg)}")


def _evaluate_remote(
    cfg: OpenClawTargetConfig, api_key: str | None, out: Path,
) -> tuple[list, int, list[TestCase]]:
    # Caller-checked; assert is type-narrowing for mypy / runtime guard only.
    assert cfg.remote is not None  # noqa: S101
    factory = adapter_registry.get(cfg.remote.adapter)

    headers: dict[str, str] = {}
    if cfg.remote.token_env:
        token = os.environ.get(cfg.remote.token_env)
        if not token:
            console.print(f"[red]error:[/red] env var {cfg.remote.token_env!r} is empty")
            raise typer.Exit(code=2)
        headers["Authorization"] = f"Bearer {token}"

    obs_cfg = NetworkObserverConfig(
        mode=cfg.remote.network_observer.mode,
        controlled_domains=cfg.remote.network_observer.controlled_domains,
    )
    test_cases = []
    for suite_path in cfg.remote.test_suites:
        test_cases.extend(load_test_suite(suite_path, observer_config=obs_cfg))
    planned = len(test_cases)
    observer = FixtureOnlyObserver()

    adapter_obj = factory(
        name=cfg.name, base_url=cfg.remote.target, headers=headers or None,
    )

    needs_llm = any(tc.judge_type in {"llm", "hybrid"} for tc in test_cases)
    if needs_llm:
        try:
            llm = _build_llm_judge(cfg, api_key)
        except ValueError as exc:
            console.print(f"[red]error:[/red] {exc}")
            raise typer.Exit(code=1) from exc
    else:
        llm = NoOpJudge()
    judge = JudgeRouter(
        llm=llm,
        deterministic=DeterministicJudge(),
        hybrid=HybridJudge(llm_judge=llm),
    )

    if cfg.remote.test_suites:
        first_path = cfg.remote.test_suites[0]
        suite_root = first_path if first_path.is_dir() else first_path.parent
    else:
        suite_root = Path(".")

    results = asyncio.run(run_suite(
        adapter_obj, judge, test_cases, cfg.remote.concurrency,
        observer=observer, suite_root=suite_root,
    ))
    return results, planned, test_cases


def _evaluate_server(
    cfg: OpenClawTargetConfig, out: Path,
) -> tuple[list, dict]:
    sa = cfg.server_audit
    # Caller-checked; assert is type-narrowing for mypy / runtime guard only.
    assert sa is not None  # noqa: S101
    audit_log = out / "audit-log.jsonl"

    auth = Authorization.load(cfg.authorization.consent_file)
    auth.validate(
        target_host=sa.host,
        report_output_path_prefix=str(out),
        required_scopes=["server-audit"],
    )

    policy = CommandPolicy.from_yaml(sa.ssh_policy)
    redactor = Redactor()
    executor = SSHExecutor(
        policy=policy, redactor=redactor, audit_log_path=audit_log,
        host=sa.host, user=sa.user, key_filename=str(sa.key),
    )

    uname_result = executor.run(["uname", "-s"])
    if uname_result.rejected or uname_result.exit_code != 0:
        executor.close()
        reason = (
            uname_result.reject_reason
            if uname_result.rejected
            else (uname_result.stderr or "").strip()
        )
        console.print(
            f"[red]uname -s failed:[/red] rejected={uname_result.rejected} "
            f"exit={uname_result.exit_code} reason={reason!r}"
        )
        raise typer.Exit(code=2)
    profile = detect_platform(uname_result.stdout)
    remote_home = resolve_remote_home(sa.user, profile)
    profile = materialize_paths(profile, remote_home)

    executor.close()
    policy = CommandPolicy.from_yaml(sa.ssh_policy, remote_home=remote_home)
    if sa.pip_lock_paths:
        expanded = [expand_tilde(p, remote_home) for p in sa.pip_lock_paths]
        policy.add_runtime_allowed_paths(expanded, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded, "ServerAuditConfig.pip_lock_paths"
        )
    if sa.go_lock_paths:
        expanded_go = [expand_tilde(p, remote_home) for p in sa.go_lock_paths]
        policy.add_runtime_allowed_paths(expanded_go, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_go,
            "ServerAuditConfig.go_lock_paths",
        )
    if sa.cargo_lock_paths:
        expanded_cargo = [expand_tilde(p, remote_home) for p in sa.cargo_lock_paths]
        policy.add_runtime_allowed_paths(expanded_cargo, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_cargo,
            "ServerAuditConfig.cargo_lock_paths",
        )
    if sa.maven_lock_paths:
        expanded_maven = [expand_tilde(p, remote_home) for p in sa.maven_lock_paths]
        policy.add_runtime_allowed_paths(expanded_maven, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_maven,
            "ServerAuditConfig.maven_lock_paths",
        )
    if sa.gem_lock_paths:
        expanded_gem = [expand_tilde(p, remote_home) for p in sa.gem_lock_paths]
        policy.add_runtime_allowed_paths(expanded_gem, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_gem,
            "ServerAuditConfig.gem_lock_paths",
        )
    if sa.composer_lock_paths:
        expanded_composer = [expand_tilde(p, remote_home) for p in sa.composer_lock_paths]
        policy.add_runtime_allowed_paths(expanded_composer, kind="exact")
        _log_runtime_paths_added(
            audit_log, expanded_composer,
            "ServerAuditConfig.composer_lock_paths",
        )
    executor = SSHExecutor(
        policy=policy, redactor=redactor, audit_log_path=audit_log,
        host=sa.host, user=sa.user, key_filename=str(sa.key),
    )

    # D3 — switch to user-mode profile if systemd --user OpenClaw deployment.
    if profile.name == "linux" and probe_systemd_user_mode(executor, remote_home):
        profile = materialize_paths(LINUX_USER_MODE, remote_home)

    # D1 — resolve openclaw binary path (paramiko non-login shell PATH gap).
    bin_path = resolve_openclaw_bin(executor, profile, remote_home)
    if bin_path != "openclaw":
        new_paths = dict(profile.paths)
        new_paths["openclaw_bin"] = bin_path
        profile = profile.model_copy(update={"paths": new_paths})

    gateway_token = os.environ.get("OPENCLAW_GATEWAY_TOKEN")

    def _real_tunnel_factory(host_, user_, key_):
        return open_local_forward(host_, user_, key_, remote_port=18789)

    checks = [
        NativeAuditCheck(),
        ConfigAuditCheck(),
        VersionPatchCheck(),
        ActiveTestCheck(
            tunnel_factory=_real_tunnel_factory,
            host=sa.host, user=sa.user, key=str(sa.key),
            bearer_token=gateway_token,
        ),
        ExposureScanCheck(host=sa.host),
        FilesystemCheck(),
        ProcessForensicsCheck(),
        CredentialAuditCheck(ssh_user=sa.user),
        PluginStaticCheck(),
        LogReviewCheck(),
        SysctlAuditCheck(),
        SshdConfigAuditCheck(),
        SudoersAuditCheck(),
        SuidAuditCheck(),
        WorldWritableCheck(),
        AuditdRulesCheck(),
        SystemdServiceBlacklistCheck(),
        SystemdUnitLintCheck(),
        IptablesAuditCheck(),
        NftablesAuditCheck(),
        UfwAuditCheck(),
        FirewalldAuditCheck(),
        DockerDaemonAuditCheck(),
        DockerRuntimeAuditCheck(),
        DockerImageCveCheck(),
        PodmanDaemonAuditCheck(),
        PodmanRuntimeAuditCheck(),
        PodmanImageCveCheck(),
        ContainerdDaemonAuditCheck(),
        ContainerdRuntimeAuditCheck(),
        ContainerdImageCveCheck(),
        SupplyChainAuditCheck(),
        PipSupplyChainAuditCheck(),
        GoSupplyChainAuditCheck(),
        RustSupplyChainAuditCheck(),
    ]
    ctx = CheckContext(
        executor=executor, redactor=redactor,
        ioc_dir=sa.ioc_db, profile=profile,
        log_review_config=sa.log_review,
        pip_lock_paths=tuple(expand_tilde(p, remote_home) for p in sa.pip_lock_paths),
        go_lock_paths=tuple(expand_tilde(p, remote_home) for p in sa.go_lock_paths),
        cargo_lock_paths=tuple(expand_tilde(p, remote_home) for p in sa.cargo_lock_paths),
        maven_lock_paths=tuple(expand_tilde(p, remote_home) for p in sa.maven_lock_paths),
        gem_lock_paths=tuple(expand_tilde(p, remote_home) for p in sa.gem_lock_paths),
        composer_lock_paths=tuple(expand_tilde(p, remote_home) for p in sa.composer_lock_paths),
    )
    report = asyncio.run(run_server_audit(checks=checks, ctx=ctx))
    executor.close()

    return list(report.findings), {
        "report": report,
        "profile_name": profile.name,
        "remote_home": remote_home,
        "low_assurance": auth.low_assurance,
        "target_descriptor": TargetDescriptor(
            host=sa.host,
            user=sa.user,
            key_path=str(sa.key),
            auth_file=str(cfg.authorization.consent_file),
            openclaw_bin=bin_path if bin_path != "openclaw" else None,
            checks_run=tuple(c.id for c in checks),
        ),
    }


def _evaluate_one_target(
    cfg: OpenClawTargetConfig,
    api_key: str | None,
    output_base: Path,
) -> TargetResult:
    """Run a full evaluate pipeline for one target. Safe to call from a thread.

    `output_base` is accepted for caller context but output resolves from cfg.output.dir,
    which is already materialized by to_openclaw_config(output_base) at the call site.
    Never raises — all exceptions are caught and surfaced in TargetResult.error.
    """
    out = cfg.output.dir
    out.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    try:
        remote_results, planned_count, remote_cases = (
            _evaluate_remote(cfg, api_key, out) if cfg.remote is not None
            else ([], 0, [])
        )
        try:
            server_findings, server_meta = (
                _evaluate_server(cfg, out) if cfg.server_audit is not None
                else ([], None)
            )
        except AuthorizationError as exc:
            raise RuntimeError(f"authorization rejected: {exc}") from exc

        mcp_results, mcp_score = (
            _run_mcp_real(cfg) if cfg.mcp_real is not None else ([], None)
        )

        score = score_evaluation(
            remote_results=remote_results,
            server_findings=server_findings,
            mcp_score=mcp_score,
            planned_count=planned_count,
            config=cfg,
        )

        if cfg.remote is not None:
            (out / "remote-report.md").write_text(
                render_remote_report(cfg.name, remote_results, score, cases=remote_cases)
            )
        if cfg.server_audit is not None and server_meta is not None:
            (out / "server-audit-report.md").write_text(
                render_server_audit_report(
                    server_meta["report"],
                    profile_name=server_meta["profile_name"],
                    remote_home=server_meta["remote_home"],
                    low_assurance=server_meta["low_assurance"],
                    server_score=score.server_score,
                    target=server_meta.get("target_descriptor"),
                )
            )
        (out / "combined-report.md").write_text(
            render_combined_report(
                cfg.name, score,
                remote_present=cfg.remote is not None,
                server_present=cfg.server_audit is not None,
                mcp_present=cfg.mcp_real is not None,
                cases=remote_cases if cfg.remote is not None else None,
                results=remote_results if cfg.remote is not None else None,
            )
        )
        if cfg.mcp_real is not None:
            from .mcp_harness import write_mcp_findings_json
            from .mcp_harness.report import render_mcp_real_report

            mcp_model = cfg.mcp_real.model or os.environ.get(
                "AGENTSEC_MCP_MODEL", "claude-haiku-4-5-20251001"
            )
            (out / "mcp-real-report.md").write_text(
                render_mcp_real_report(mcp_results, model=mcp_model)
            )
            write_mcp_findings_json(
                results=mcp_results, model=mcp_model,
                suite=cfg.mcp_real.suite,
                out_path=out / "mcp-findings.json",
            )
        write_findings_json(score.deduped_findings, out / "findings.json")

        referenced_refs: set[str] = set()
        for f in score.deduped_findings:
            referenced_refs.update(f.threat_refs)
        threat_intel_path = (
            (cfg.server_audit.ioc_db / "threat_intel.yaml")
            if cfg.server_audit is not None
            else Path(__file__).parent / "audit" / "ioc" / "threat_intel.yaml"
        )
        write_threat_intel_snapshot(
            referenced_refs, threat_intel_path, out / "threat-intel-snapshot.yaml"
        )
        # audit-log.jsonl: SSHExecutor writes it during _evaluate_server. When the
        # server half was skipped, ensure the file exists so consumers that always
        # look for it don't crash.
        (out / "audit-log.jsonl").touch(exist_ok=True)

        return TargetResult(
            name=cfg.name, output_dir=out, score=score,
            error=None, elapsed_seconds=time.monotonic() - start,
        )
    except typer.Exit as exc:
        return TargetResult(
            name=cfg.name, output_dir=out, score=None,
            error=f"aborted (exit code {exc.exit_code})",
            elapsed_seconds=time.monotonic() - start,
        )
    except Exception as exc:  # noqa: BLE001
        return TargetResult(
            name=cfg.name, output_dir=out, score=None,
            error=str(exc) or repr(exc),
            elapsed_seconds=time.monotonic() - start,
        )


@app.command("multi-evaluate")
def multi_evaluate(
    config: Path = typer.Option(..., help="Path to multi-target.yaml"),
    output_base: Path = typer.Option(
        None, "--output-base",
        help="Output base directory (overrides config.output_base)",
    ),
    api_key: str = typer.Option(
        None, envvar="AGENTSEC_JUDGE_API_KEY",
        help="Anthropic API key for LLM/hybrid judges",
    ),
) -> None:
    """Evaluate multiple OpenClaw targets in parallel."""
    try:
        cfg = MultiTargetConfig.from_yaml(config)
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]config error:[/red] {exc}")
        raise typer.Exit(code=2) from exc

    base = output_base if output_base is not None else cfg.output_base
    base.mkdir(parents=True, exist_ok=True)

    target_cfgs = [t.to_openclaw_config(base, config_path=Path(config)) for t in cfg.targets]
    max_w = cfg.effective_max_parallel
    console.print(
        f"[bold]multi-evaluate:[/bold] {len(target_cfgs)} targets, "
        f"max_parallel={max_w}"
    )

    results_map: dict[str, TargetResult] = {}
    with ThreadPoolExecutor(max_workers=max_w) as pool:
        futures = {
            pool.submit(_evaluate_one_target, tc, api_key, base): tc.name
            for tc in target_cfgs
        }
        for future in as_completed(futures):
            name = futures[future]
            result = future.result()
            results_map[name] = result
            elapsed = (
                f"{int(result.elapsed_seconds) // 60}m"
                f"{int(result.elapsed_seconds) % 60:02d}s"
            )
            if result.error is None:
                # Invariant: TargetResult.__post_init__ rejects (error=None, score=None).
                assert result.score is not None  # noqa: S101
                console.print(
                    f"  [green]done[/green] {name} "
                    f"(grade={result.score.grade}, {elapsed})"
                )
            else:
                console.print(f"  [red]ERROR[/red] {name}: {result.error}")

    ordered = [results_map[tc.name] for tc in target_cfgs]
    generated_at = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    (base / "summary.md").write_text(render_multi_summary(ordered, generated_at=generated_at))

    error_count = sum(1 for r in ordered if r.error is not None)
    console.print(
        f"[green]wrote[/green] {base}/summary.md "
        f"({len(ordered) - error_count}/{len(ordered)} succeeded)"
    )
    if error_count == len(ordered):
        raise typer.Exit(code=2)


@app.command()
def diff(
    baseline: Path = typer.Argument(..., help="Baseline report directory"),
    current: Path = typer.Argument(..., help="Current report directory"),
    output: Path | None = typer.Option(
        None, "--output", help="Write markdown to file instead of stdout"
    ),
) -> None:
    """Compare two `agentsec evaluate` report directories."""
    from .diff.findings_delta import diff_findings
    from .diff.loader import LoaderError, load_report_dir
    from .diff.renderer import render_diff_report

    try:
        baseline_data = load_report_dir(baseline)
        current_data = load_report_dir(current)
    except LoaderError as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=1) from e

    if baseline_data.score_meta is None:
        typer.echo(
            f"warn: {baseline} has no readable combined-report.md "
            "meta; score delta will be degraded",
            err=True,
        )
    if current_data.score_meta is None:
        typer.echo(
            f"warn: {current} has no readable combined-report.md "
            "meta; score delta will be degraded",
            err=True,
        )

    findings_delta = diff_findings(baseline_data.findings, current_data.findings)
    md = render_diff_report(
        baseline=baseline_data,
        current=current_data,
        findings_delta=findings_delta,
    )

    if output is not None:
        if not output.parent.exists():
            typer.echo(f"error: parent directory does not exist: {output.parent}",
                       err=True)
            raise typer.Exit(code=1)
        if output.is_symlink():
            typer.echo(
                f"error: refusing to write through symlink: {output}",
                err=True,
            )
            raise typer.Exit(code=1)
        output.write_text(md, encoding="utf-8")
    else:
        typer.echo(md, nl=False)


@app.command()
def serve(
    output_dir: Path = typer.Argument(..., help="Report output directory (single or multi-target)"),
    port: int = typer.Option(8080, "--port", help="TCP port"),
    host: str = typer.Option("127.0.0.1", "--host", help="Bind address"),
) -> None:
    """Serve an agentsec evaluate report directory as a local web dashboard."""
    from .serve.app import create_app

    try:
        app_instance = create_app(output_dir)
    except ValueError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    typer.echo(f"Serving AgentSec report at http://{host}:{port}")
    typer.echo("Press Ctrl+C to stop.")
    app_instance.run(host=host, port=port, use_reloader=False)


@app.command("ioc-update")
def ioc_update(
    watchlist: Path | None = typer.Option(
        None,
        help="Path to watchlist.yaml (defaults to the bundled package copy)",
    ),
    intel: Path | None = typer.Option(
        None,
        help="Path to existing threat_intel.yaml (defaults to the bundled package copy)",
    ),
    output_dir: Path | None = typer.Option(
        None,
        "--output-dir",
        help="Output directory (default .cache/ioc-update-<date>/)",
    ),
    feeds: list[str] = typer.Option(
        ["nvd", "kev", "ghsa"],
        help="Feeds to query (nvd|kev|ghsa|all)",
    ),
    mode: str = typer.Option("both", help="discover|refresh|both"),
    offline: bool = typer.Option(False, help="Read from --fixture-dir instead of network"),
    fixture_dir: Path | None = typer.Option(None, help="Offline fixture directory"),
    nvd_api_key: str | None = typer.Option(None, help="NVD API key (or env NVD_API_KEY)"),
    github_token: str | None = typer.Option(None, help="GitHub token (or env GITHUB_TOKEN)"),
    user_agent: str = typer.Option("agentsec-ioc-update/0.3.0", help="HTTP User-Agent header"),
    force: bool = typer.Option(False, help="Overwrite non-empty output dir"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose logging"),
):
    """Pull CVE/threat-intel feeds and propose updates."""
    from .audit.ioc_update.cli import run_ioc_update
    bundled_ioc = Path(__file__).parent / "audit" / "ioc"
    if watchlist is None:
        watchlist = bundled_ioc / "watchlist.yaml"
    if intel is None:
        intel = bundled_ioc / "threat_intel.yaml"
    code = run_ioc_update(
        watchlist=watchlist,
        intel=intel,
        output_dir=output_dir,
        feeds=feeds,
        mode=mode,
        offline=offline,
        fixture_dir=fixture_dir,
        nvd_api_key=nvd_api_key,
        github_token=github_token,
        user_agent=user_agent,
        force=force,
        verbose=verbose,
    )
    if code != 0:
        raise typer.Exit(code=code)


@app.command("mcp-run")
def mcp_run(
    suite: Path = typer.Argument(..., help="Path to mcp_real_*.yaml suite file"),
    output: Path = typer.Option(
        None, "--output", "-o",
        help="Output directory; defaults to ./mcp-run-<timestamp>/",
    ),
    concurrency: int = typer.Option(3, help="Bounded concurrency for runner"),
    model: str = typer.Option(
        None,
        help="Claude model id; falls back to env AGENTSEC_MCP_MODEL "
             "then claude-haiku-4-5-20251001",
    ),
) -> None:
    """Run a real-protocol MCP suite (Phase 7c.2)."""
    import asyncio
    import datetime as _dt
    import os

    import anthropic as _anthropic

    from .evaluator.judge import LLMJudge
    from .mcp_harness import (
        ClaudeMcpAdapter,
        load_mcp_real_suite,
        run_mcp_suite,
    )
    from .mcp_harness.report import render_mcp_real_report

    if "ANTHROPIC_API_KEY" not in os.environ:
        console.print(
            "[red]ANTHROPIC_API_KEY env var is required for mcp-run[/red]"
        )
        raise typer.Exit(1)

    model_id = model or os.environ.get(
        "AGENTSEC_MCP_MODEL", "claude-haiku-4-5-20251001"
    )

    cases = load_mcp_real_suite(suite)
    if not cases:
        console.print(f"[yellow]No cases in {suite}[/yellow]")
        raise typer.Exit(0)

    anthropic_client = _anthropic.Anthropic()
    judge = LLMJudge(model=model_id)

    def _factory(*, fixtures, model):
        return ClaudeMcpAdapter(
            fixtures=fixtures,
            anthropic_client=anthropic_client,
            model=model,
        )

    results = asyncio.run(run_mcp_suite(
        cases=cases, judge=judge,
        adapter_factory=_factory,
        model=model_id, concurrency=concurrency,
    ))

    out_dir = output or Path(
        f"./mcp-run-{_dt.datetime.now().strftime('%Y-%m-%d-%H%M%S')}"
    )
    out_dir.mkdir(parents=True, exist_ok=True)
    md = render_mcp_real_report(results, model=model_id)
    (out_dir / "mcp-real-report.md").write_text(md)

    passed = sum(1 for r in results if r.verdict.passed)
    console.print(
        f"[bold]MCP run complete[/bold] — "
        f"{passed}/{len(results)} passed; report at "
        f"{out_dir / 'mcp-real-report.md'}"
    )


if __name__ == "__main__":
    app()
