"""AgentSec — Security assessment framework for AI agents."""
