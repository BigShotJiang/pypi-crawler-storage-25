"""Test-case data model. Spec §5.3 / OE-AUD-006 migration: `attack` becomes
optional and is mutually exclusive with `turns`; loader expands single-attack
cases to a one-element `turns` list before runner consumption.

Stage C tightens `assertions` from `list[dict]` to `list[Assertion]` (the
discriminated union from `evaluator.assertions`); unknown types and extra
fields are rejected at load time.
"""

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

# JudgeType is owned by evaluator.base (the Judge ABC's natural home);
# re-export here so YAML loaders can validate the literal without depending on
# the evaluator package layout. evaluator.base does not import this module at
# runtime (TestCase is referenced under TYPE_CHECKING), so no circular import.
from ..evaluator.assertions import Assertion
from ..evaluator.base import JudgeType
from .owasp_refs import validate_owasp_refs


class Severity(str, Enum):  # noqa: UP042 — see MergeState; renderer.py uses f"{severity}" directly

    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"
    info = "info"


ResultStatus = Literal["passed", "failed", "skipped", "error", "not_applicable"]


class Turn(BaseModel):
    attack: str
    judge_after: bool = False
    sleep_ms: int = 0
    channel: Literal["http", "ws"] = "http"


class IsolationPolicy(BaseModel):
    profile: Literal["disposable", "shared"] = "shared"
    pre_snapshot: list[str] = Field(default_factory=list)
    post_snapshot: list[str] = Field(default_factory=list)
    cleanup_on_failure: Literal["required", "best_effort", "none"] = "best_effort"


ServeVia = Literal["auto", "same-host-loopback", "reachable-url", "ssh-port-forward"]


class Fixture(BaseModel):
    type: str  # e.g. "web_page", "tool_response"
    path: str  # path on disk relative to suite root
    serve_via: ServeVia = "auto"
    # 0.0.0.0 default mirrors FixtureConfig.bind; see config.py for rationale.
    bind: str = "0.0.0.0"  # noqa: S104 — only meaningful when serve_via=reachable-url
    public_base_url: str = ""  # required when serve_via=reachable-url


class TestCase(BaseModel):
    id: str
    category: str
    description: str
    attack: str | None = None
    turns: list[Turn] | None = None
    expected_behavior: Literal["refusal", "no_leak", "custom"]
    severity: Severity
    judge_type: JudgeType = "llm"
    judge_hint: str = ""
    assertions: list[Assertion] | None = None
    fixture: Fixture | None = None
    isolation: IsolationPolicy = Field(default_factory=IsolationPolicy)
    threat_refs: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    owasp_refs: list[str] = Field(default_factory=list)

    @field_validator("owasp_refs")
    @classmethod
    def _check_owasp_refs(cls, v: list[str]) -> list[str]:
        return validate_owasp_refs(v)

    ws_concurrent_observe: bool = False
    ws_listen_duration_s: float = Field(default=5.0, gt=0)

    @model_validator(mode="after")
    def _attack_or_turns(self):
        # Spec §5.3 uses bool() so empty-string attack is treated as missing.
        has_attack = bool(self.attack)
        has_turns = self.turns is not None and len(self.turns) > 0
        if has_attack == has_turns:
            raise ValueError("exactly one of `attack` or `turns` is required")
        return self

    @model_validator(mode="after")
    def _ws_observe_and_ws_channel_mutex(self):
        if self.ws_concurrent_observe and self.turns:
            ws_turns = [t for t in self.turns if t.channel == "ws"]
            if ws_turns:
                raise ValueError(
                    "ws_concurrent_observe=True is incompatible with turns that have "
                    "channel='ws'; use alternating mode (ws_concurrent_observe=False) instead"
                )
        return self


# --- TestResult migration (spec §4, OE-AUD2-011) ---

class TestResult(BaseModel):
    test_id: str
    category: str
    severity: Severity
    status: ResultStatus
    # verdict / observations are dict[str, Any] today to avoid the
    # tests.models ↔ evaluator.base import cycle that Stage A's lazy re-export
    # shielded. Stage F (`agentsec evaluate` + scoring) takes typed JudgeVerdict /
    # Observation as input and is the right place to tighten these fields.
    verdict: dict[str, Any] | None = None
    observations: list[dict[str, Any]] = Field(default_factory=list)
    latency_ms: float = 0.0
    error: str | None = None
    skipped_reason: str | None = None

    @property
    def passed(self) -> bool:
        """Compatibility shim for legacy callers / report renderer."""
        return self.status == "passed"
