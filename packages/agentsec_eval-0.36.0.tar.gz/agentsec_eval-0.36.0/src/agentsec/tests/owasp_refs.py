"""Strict-regex validator for `TestCase.owasp_refs`.

Allowed prefixes are derived from the canonical OWASP framework lists
referenced in ADR-0006:

  - LLM01:2025 ... LLM10:2025  (Top 10 for LLM Applications, 2025)
  - AGENTIC-T1 ... AGENTIC-T17 (Agentic AI Threats and Mitigations v1.1)
  - MCP\\d+                    (reserved; populated in Phase 7c)

The regex is intentionally strict — typos like `Agentic-T1` or `LLM5:2025`
fail at YAML load time so we never silently lose coverage.
"""

from __future__ import annotations

import re

# Each alternative is its own anchored group so a malformed token (e.g.
# `LLM01:2024`) cannot be partially matched.
OWASP_REF_PATTERN = re.compile(
    r"^("
    r"LLM(0[1-9]|10):2025"
    r"|AGENTIC-T(1[0-7]|[1-9])"
    r"|MCP[1-9]\d*"
    r")$"
)


def validate_owasp_refs(values: list[str]) -> list[str]:
    """Validate a list of owasp_refs and return it unchanged on success.

    Raises:
        ValueError: if any entry doesn't match the canonical pattern, or if
            the list contains duplicates.
    """
    seen: set[str] = set()
    for v in values:
        if not OWASP_REF_PATTERN.match(v):
            raise ValueError(
                f"unknown owasp_refs entry {v!r}: expected one of "
                "LLM01:2025..LLM10:2025 / AGENTIC-T1..AGENTIC-T17 / MCP<n>"
            )
        if v in seen:
            raise ValueError(f"duplicate owasp_refs entry {v!r}")
        seen.add(v)
    return values
