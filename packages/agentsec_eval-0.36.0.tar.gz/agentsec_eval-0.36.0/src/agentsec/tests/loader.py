from pathlib import Path
from typing import TYPE_CHECKING

import yaml

from .models import TestCase, Turn

if TYPE_CHECKING:
    from agentsec.observability.network_observer import NetworkObserverConfig


def load_test_suite(
    path: str | Path,
    observer_config: "NetworkObserverConfig | None" = None,
) -> list[TestCase]:
    """Load test cases from a YAML file or directory of YAML files.

    Globally unique IDs are enforced (spec §3 / CLAUDE.md). Single-attack cases
    are expanded to `turns=[Turn(attack=...)]` so the runner can treat all
    cases uniformly (spec §5.3 / OE-AUD-006).

    When `observer_config.mode == "fixture_only"`, any `outbound_request_not_to`
    assertion whose `target` is not covered by `controlled_domains` is rejected
    here so we fail fast on suites that would produce false signals
    (spec §5.4 / OE-AUD2-006).
    """
    path = Path(path)
    files = sorted(path.glob("*.yaml")) + sorted(path.glob("*.yml")) if path.is_dir() else [path]
    cases: list[TestCase] = []
    seen: dict[str, Path] = {}
    for f in files:
        raw = yaml.safe_load(f.read_text())
        items = raw if isinstance(raw, list) else [raw]
        for item in items:
            tc = TestCase.model_validate(item)
            if tc.id in seen:
                raise ValueError(
                    f"duplicate test id {tc.id!r}: {seen[tc.id]} vs {f}"
                )
            seen[tc.id] = f
            if tc.attack is not None and tc.turns is None:
                tc = tc.model_copy(update={
                    "turns": [Turn(attack=tc.attack)],
                    "attack": None,
                })
            cases.append(tc)
    _reject_loopback_self_trip(cases)
    if observer_config is not None:
        _validate_outbound_assertions(cases, observer_config)
    return cases


_LOOPBACK_FIXTURE_MODES = {"same-host-loopback", "ssh-port-forward"}


def _is_loopback_target(target: str) -> bool:
    t = target.strip().lower()
    if t in {"localhost", "::1"}:
        return True
    return t.startswith("127.")


def _reject_loopback_self_trip(cases) -> None:
    """A fixture served on the target's loopback interface plus an
    `outbound_request_not_to` whose target is a loopback literal would
    self-trip — the fixture's own callback fires the assertion. Reject at
    load time (memory item I5).
    """
    from agentsec.evaluator.assertions import OutboundRequestNotTo

    for case in cases:
        if case.fixture is None or case.fixture.serve_via not in _LOOPBACK_FIXTURE_MODES:
            continue
        for assertion in (case.assertions or []):
            if not isinstance(assertion, OutboundRequestNotTo):
                continue
            if _is_loopback_target(assertion.target):
                raise ValueError(
                    f"test {case.id!r}: outbound_request_not_to.target "
                    f"{assertion.target!r} would self-trip against fixture.serve_via"
                    f"={case.fixture.serve_via!r} (the fixture's own callback hits "
                    f"loopback). Either point the assertion at the exfil domain or "
                    f"move the fixture off loopback."
                )


def _validate_outbound_assertions(cases, observer_config) -> None:
    from agentsec.evaluator.assertions import OutboundRequestNotTo
    from agentsec.observability.network_observer import target_is_controlled

    if observer_config.mode != "fixture_only":
        return
    for case in cases:
        for assertion in (case.assertions or []):
            if not isinstance(assertion, OutboundRequestNotTo):
                continue
            if not target_is_controlled(assertion.target, observer_config):
                raise ValueError(
                    f"test {case.id!r}: outbound_request_not_to.target "
                    f"{assertion.target!r} is not in network_observer.controlled_domains "
                    f"{observer_config.controlled_domains!r}; either add the "
                    f"domain or switch observer mode away from fixture_only"
                )
