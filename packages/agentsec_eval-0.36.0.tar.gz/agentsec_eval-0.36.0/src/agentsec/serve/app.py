"""Flask app factory for agentsec report viewer."""
from __future__ import annotations

import dataclasses
from pathlib import Path

from flask import Flask, abort, jsonify, redirect, render_template, url_for

from .reader import (
    TargetSummary,
    detect_mode,
    list_targets,
    load_findings_raw,
    parse_scores,
    render_markdown_file,
)

_ALLOWED_REPORTS = frozenset({
    "combined-report.md",
    "remote-report.md",
    "server-audit-report.md",
})


def create_app(output_dir: Path) -> Flask:
    output_dir = output_dir.resolve()
    mode = detect_mode(output_dir)
    if mode is None:
        raise ValueError(
            f"{output_dir}: no findings.json found "
            "(neither directly nor in subdirectories)"
        )

    app = Flask(__name__, template_folder="templates")
    app.config["SERVE_OUTPUT_DIR"] = output_dir
    app.config["SERVE_MODE"] = mode
    app.config["SERVE_TARGETS"] = {
        t.name: t for t in list_targets(output_dir, mode)
    }

    @app.route("/")
    def index():
        targets = list(app.config["SERVE_TARGETS"].values())
        if app.config["SERVE_MODE"] == "single":
            return redirect(url_for("target_detail", name=targets[0].name))
        return render_template("dashboard.html", targets=targets)

    @app.route("/target/<name>")
    def target_detail(name: str):
        t: TargetSummary | None = app.config["SERVE_TARGETS"].get(name)
        if t is None:
            abort(404)
        # Pyright doesn't see flask.abort() as NoReturn in stub-less mode.
        assert t is not None  # noqa: S101
        findings = load_findings_raw(t.output_dir)
        scores = parse_scores(t.output_dir)
        report_links = sorted(
            f for f in _ALLOWED_REPORTS if (t.output_dir / f).exists()
        )
        return render_template(
            "target.html",
            target=t,
            findings=findings,
            scores=scores,
            report_links=report_links,
        )

    @app.route("/target/<name>/report/<filename>")
    def target_report(name: str, filename: str):
        if filename not in _ALLOWED_REPORTS:
            abort(400)
        t: TargetSummary | None = app.config["SERVE_TARGETS"].get(name)
        if t is None:
            abort(404)
        # Pyright doesn't see flask.abort() as NoReturn in stub-less mode.
        assert t is not None  # noqa: S101
        html = render_markdown_file(t.output_dir, filename)
        if html is None:
            abort(404)
        return render_template(
            "report.html", target=t, filename=filename, content=html
        )

    @app.route("/api/targets")
    def api_targets():
        targets = list(app.config["SERVE_TARGETS"].values())
        return jsonify([_target_to_dict(t) for t in targets])

    @app.route("/api/targets/<name>/findings")
    def api_findings(name: str):
        t: TargetSummary | None = app.config["SERVE_TARGETS"].get(name)
        if t is None:
            abort(404)
        # Pyright doesn't see flask.abort() as NoReturn in stub-less mode.
        assert t is not None  # noqa: S101
        return jsonify(load_findings_raw(t.output_dir))

    @app.route("/api/targets/<name>/score")
    def api_score(name: str):
        t: TargetSummary | None = app.config["SERVE_TARGETS"].get(name)
        if t is None:
            abort(404)
        # Pyright doesn't see flask.abort() as NoReturn in stub-less mode.
        assert t is not None  # noqa: S101
        scores = parse_scores(t.output_dir)
        if scores is None:
            return jsonify({"grade": "UNKNOWN"})
        return jsonify(dataclasses.asdict(scores))

    return app


def _target_to_dict(t: TargetSummary) -> dict:
    return {
        "name": t.name,
        "grade": t.grade,
        "combined_score": t.combined_score,
        "remote_score": t.remote_score,
        "server_score": t.server_score,
        "critical_count": t.critical_count,
        "high_count": t.high_count,
        "has_findings": t.has_findings,
    }
