"""Pure I/O helpers for reading agentsec evaluate output directories."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import markdown as _md

from agentsec.diff.score_delta import ScoreMeta

_META_RE = re.compile(r"<!--\s*meta:(\w+)\s+value:([^ ]+)\s*-->")
_COVERAGE_VERDICT_RE = re.compile(r"verdict_coverage=(\d+(?:\.\d+)?%|N/A)")
_COVERAGE_ERROR_RE = re.compile(r"error_rate=(\d+(?:\.\d+)?%|N/A)")
_REQUIRED_META = frozenset({"remote_score", "server_score", "combined_score", "grade"})


def _parse_pct(s: str) -> float | None:
    if s == "N/A":
        return None
    return float(s.rstrip("%")) / 100


def _parse_score_value(v: str) -> float | None:
    return None if v == "None" else float(v)


@dataclass
class TargetSummary:
    name: str
    output_dir: Path
    grade: str
    combined_score: float | None
    remote_score: float | None
    server_score: float | None
    critical_count: int
    high_count: int
    has_findings: bool


def detect_mode(base: Path) -> Literal["single", "multi"] | None:
    try:
        if (base / "findings.json").exists():
            return "single"
        subdirs = [d for d in base.iterdir() if d.is_dir()]
        if any((d / "findings.json").exists() for d in subdirs):
            return "multi"
    except OSError:
        pass
    return None


def list_targets(base: Path, mode: str) -> list[TargetSummary]:
    if mode == "single":
        return [_summarise(base, base.name)]
    dirs = sorted(
        d for d in base.iterdir()
        if d.is_dir()
        and not d.name.startswith(".")
        and not (d.name.startswith("__") and d.name.endswith("__"))
    )
    return [_summarise(d, d.name) for d in dirs]


def _summarise(target_dir: Path, name: str) -> TargetSummary:
    has_findings = (target_dir / "findings.json").exists()
    raw = load_findings_raw(target_dir)
    critical = sum(1 for f in raw if f.get("severity") == "critical")
    high = sum(1 for f in raw if f.get("severity") == "high")
    scores = parse_scores(target_dir)
    return TargetSummary(
        name=name,
        output_dir=target_dir,
        grade=scores.grade if scores else "UNKNOWN",
        combined_score=scores.combined_score if scores else None,
        remote_score=scores.remote_score if scores else None,
        server_score=scores.server_score if scores else None,
        critical_count=critical,
        high_count=high,
        has_findings=has_findings,
    )


def load_findings_raw(target_dir: Path) -> list[dict[str, Any]]:
    path = target_dir / "findings.json"
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def parse_scores(target_dir: Path) -> ScoreMeta | None:
    path = target_dir / "combined-report.md"
    if not path.exists():
        return None
    text = path.read_text(encoding="utf-8")
    found: dict[str, str] = {m.group(1): m.group(2) for m in _META_RE.finditer(text)}
    if not _REQUIRED_META.issubset(found):
        return None
    try:
        remote = _parse_score_value(found["remote_score"])
        server = _parse_score_value(found["server_score"])
        combined = _parse_score_value(found["combined_score"])
    except ValueError:
        return None
    vc_m = _COVERAGE_VERDICT_RE.search(text)
    er_m = _COVERAGE_ERROR_RE.search(text)
    return ScoreMeta(
        remote_score=remote,
        server_score=server,
        combined_score=combined,
        grade=found["grade"],
        verdict_coverage=_parse_pct(vc_m.group(1)) if vc_m else None,
        error_rate=_parse_pct(er_m.group(1)) if er_m else None,
    )


def render_markdown_file(target_dir: Path, filename: str) -> str | None:
    path = target_dir / filename
    if not path.exists():
        return None
    return _md.markdown(path.read_text(encoding="utf-8"), extensions=["tables"])
