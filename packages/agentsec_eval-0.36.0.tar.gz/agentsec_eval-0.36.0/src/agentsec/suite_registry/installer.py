"""Installer — orchestrates fetch + verify + land for a single suite.

Flow per spec §6 of the design doc. All error paths leave the local store
in a clean state. The atomic rename + rollback in step 10 ensures that an
interrupted --force overwrite either fully succeeds or restores the prior
version.
"""

import io
import os
import shutil
import tarfile
import tempfile
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version
from importlib.resources import files
from pathlib import Path

import httpx
import yaml
from packaging.version import Version
from pydantic import ValidationError

from .errors import (
    SuiteAlreadyInstalled,
    SuiteHashMismatch,
    SuiteManifestError,
    SuiteNotInRegistry,
    SuiteTIRefMissing,
    SuiteValidationError,
)
from .fetcher import fetch_tarball
from .hashing import canonical_hash
from .manifest import SuiteManifest
from .registry import Registry
from .store import InstalledSuite, Store

_THREAT_INTEL_RESOURCE = "audit/ioc/threat_intel.yaml"


def _load_threat_intel_ids() -> set[str]:
    text = files("agentsec").joinpath(_THREAT_INTEL_RESOURCE).read_text()
    raw = yaml.safe_load(text) or []
    return {entry["id"] for entry in raw if isinstance(entry, dict) and "id" in entry}


# PyPI distribution name. "agentsec" is the legacy name kept for editable
# installs that pre-date the v0.9.1 rename; the live PyPI release is
# "agentsec-eval".
_DIST_CANDIDATES = ("agentsec-eval", "agentsec")


def _agentsec_version() -> str:
    for dist in _DIST_CANDIDATES:
        try:
            return _pkg_version(dist)
        except PackageNotFoundError:
            continue
    return "0.0.0"


def install(
    name: str,
    *,
    registry: Registry,
    store: Store,
    force: bool = False,
    http_client: httpx.Client | None = None,
) -> InstalledSuite:
    """Install community suite `name`.

    Args:
        name: registry key
        registry: source of truth for entries
        store: local store sink
        force: overwrite existing install
        http_client: optional injected httpx.Client (used by tests)
    """
    # Step 1 — registry lookup
    entry = registry.lookup(name)
    if entry is None:
        raise SuiteNotInRegistry(
            f'Suite "{name}" not in registry. Run "agentsec suite list" to see available entries.'
        )

    # Step 2 — already-installed check
    if store.is_installed(name) and not force:
        existing = store.get(name)
        version_str = existing.version if existing else "unknown"
        raise SuiteAlreadyInstalled(
            f'Suite "{name}" already installed (v{version_str}). Use --force to overwrite.'
        )

    # Step 3 — fetch
    tarball = fetch_tarball(entry.repo, entry.ref, client=http_client)

    with tempfile.TemporaryDirectory() as tmp_str:
        tmp = Path(tmp_str)

        # Step 4 — extract with PEP-706 data filter
        try:
            with tarfile.open(fileobj=io.BytesIO(tarball), mode="r:gz") as tf:
                tf.extractall(tmp, filter="data")
        except (tarfile.TarError, OSError) as exc:
            raise SuiteValidationError(f"failed to extract tarball: {exc}") from exc

        # Step 5 — locate bundle root
        # GitHub tarballs unpack into a single top-level directory `<repo>-<ref>/`.
        roots = [p for p in tmp.iterdir() if p.is_dir()]
        if len(roots) != 1:
            raise SuiteValidationError(
                "unexpected tarball layout: expected exactly one top-level"
                f" directory, got {len(roots)}"
            )
        archive_root = roots[0]
        bundle_root = archive_root / entry.subdir
        if not (bundle_root / "manifest.yaml").is_file():
            raise SuiteValidationError(
                f"entry.subdir {entry.subdir!r} not present in archive (no manifest.yaml found)"
            )

        # Step 6 — canonical hash check
        computed = canonical_hash(bundle_root)
        if computed != entry.sha256:
            raise SuiteHashMismatch(
                f'HASH MISMATCH for "{name}". Expected {entry.sha256}, got {computed}. '
                f"The upstream archive does not match the registry's audited version. "
                f"Refusing to install."
            )

        # Step 7 — manifest validation
        try:
            manifest = SuiteManifest.model_validate(
                yaml.safe_load((bundle_root / "manifest.yaml").read_text())
            )
        except (ValidationError, yaml.YAMLError) as exc:
            raise SuiteManifestError(f"manifest.yaml invalid for {name}: {exc}") from exc
        if manifest.name != name:
            raise SuiteManifestError(
                f"manifest.name ({manifest.name!r}) does not match registry entry key ({name!r})"
            )
        if Version(manifest.agentsec_min_version) > Version(_agentsec_version()):
            raise SuiteManifestError(
                f"suite requires AgentSec >= {manifest.agentsec_min_version}, "
                f"but this install is {_agentsec_version()}"
            )

        # Step 8 — TI strict check
        ti_present = _load_threat_intel_ids()
        missing = set(manifest.threat_refs_required) - ti_present
        if missing:
            raise SuiteTIRefMissing(missing)

        # Step 9 — loader test
        from agentsec.tests.loader import load_test_suite
        cases_dir = bundle_root / "cases"
        if not cases_dir.is_dir():
            raise SuiteValidationError("bundle missing required cases/ directory")
        try:
            load_test_suite(cases_dir)
        except (ValueError, ValidationError, yaml.YAMLError) as exc:
            raise SuiteValidationError(
                f"test cases in {name} failed loader validation: {exc}"
            ) from exc

        # Step 10 — atomic landing with rollback
        store.root.mkdir(parents=True, exist_ok=True)
        target = store.root / name
        pid = os.getpid()
        staging = store.root / f".{name}.installing-{pid}"
        backup = store.root / f".{name}.old-{pid}"

        if staging.exists():
            shutil.rmtree(staging)
        if backup.exists():
            shutil.rmtree(backup)
        shutil.copytree(bundle_root, staging)

        try:
            if target.exists():
                target.rename(backup)
                try:
                    staging.rename(target)
                except OSError:
                    # Rollback: restore the prior version
                    backup.rename(target)
                    raise
                shutil.rmtree(backup, ignore_errors=True)
            else:
                staging.rename(target)
        except OSError:
            # Whatever rename path failed, the staging dotfile must not leak
            # into store.root.
            shutil.rmtree(staging, ignore_errors=True)
            raise

        # Step 11 — receipt
        store.write_receipt(name, version=manifest.version, ref=entry.ref, sha256=entry.sha256)

    return store.get(name)  # type: ignore[return-value]
