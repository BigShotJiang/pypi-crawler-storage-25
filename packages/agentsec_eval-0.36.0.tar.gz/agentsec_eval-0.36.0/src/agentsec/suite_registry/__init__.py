"""Community test-suite registry — install, list, run third-party suites.

See docs/superpowers/specs/2026-05-04-community-suite-marketplace-design.md.
"""

from .errors import (
    SuiteAlreadyInstalled,
    SuiteError,
    SuiteFetchError,
    SuiteHashMismatch,
    SuiteManifestError,
    SuiteNotInRegistry,
    SuiteTIRefMissing,
    SuiteValidationError,
)
from .fetcher import fetch_tarball
from .hashing import canonical_hash
from .installer import install
from .manifest import (
    NAME_REGEX,
    SPDX_LICENSES,
    Author,
    IndexEntry,
    RegistryFile,
    SuiteManifest,
)
from .registry import DefaultRegistry, HttpRegistry, Registry
from .store import DEFAULT_STORE_ROOT, InstalledSuite, Store

__all__ = [
    "SuiteAlreadyInstalled",
    "SuiteError",
    "SuiteFetchError",
    "SuiteHashMismatch",
    "SuiteManifestError",
    "SuiteNotInRegistry",
    "SuiteTIRefMissing",
    "SuiteValidationError",
    "Author",
    "IndexEntry",
    "NAME_REGEX",
    "RegistryFile",
    "SPDX_LICENSES",
    "SuiteManifest",
    "DefaultRegistry",
    "HttpRegistry",
    "Registry",
    "DEFAULT_STORE_ROOT",
    "InstalledSuite",
    "Store",
    "fetch_tarball",
    "canonical_hash",
    "install",
]
