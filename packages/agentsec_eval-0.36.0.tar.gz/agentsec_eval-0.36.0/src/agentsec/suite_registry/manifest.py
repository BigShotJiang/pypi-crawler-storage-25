"""Pydantic models for SuiteManifest, IndexEntry, and the registry file."""

import re
from importlib.resources import files
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator, model_validator

NAME_REGEX = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
_SHA256_REGEX = re.compile(r"[0-9a-f]{64}")
_SEMVER_REGEX = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?"
    r"(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$"
)
_REPO_REGEX = re.compile(
    r"^[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?/"
    r"[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?$"
)
_TI_ID_REGEX = re.compile(r"^TI-[A-Z0-9_-]+$")

_FORBID = ConfigDict(extra="forbid")


def _load_spdx_licenses() -> frozenset[str]:
    text = files("agentsec.suite_registry").joinpath("spdx_licenses.txt").read_text()
    return frozenset(line.strip() for line in text.splitlines() if line.strip())


SPDX_LICENSES: frozenset[str] = _load_spdx_licenses()


class Author(BaseModel):
    model_config = _FORBID
    name: str = Field(min_length=1)
    url: HttpUrl | None = None


class SuiteManifest(BaseModel):
    """Bundle-side manifest.yaml."""

    model_config = _FORBID

    schema_version: Literal[1]
    name: str
    version: str
    description: str = Field(min_length=1)
    authors: list[Author] = Field(min_length=1)
    license: str
    agentsec_min_version: str
    threat_refs_required: list[str] = Field(default_factory=list)
    case_count: int = Field(ge=0)
    homepage: HttpUrl | None = None
    tags: list[str] = Field(default_factory=list)

    @field_validator("name")
    @classmethod
    def _name_must_match_regex(cls, v: str) -> str:
        if not NAME_REGEX.fullmatch(v):
            raise ValueError(f"name {v!r} must match {NAME_REGEX.pattern}")
        return v

    @field_validator("version", "agentsec_min_version")
    @classmethod
    def _must_be_semver(cls, v: str) -> str:
        if not _SEMVER_REGEX.match(v):
            raise ValueError(f"{v!r} is not a valid SemVer 2.0 string")
        return v

    @field_validator("license")
    @classmethod
    def _license_in_spdx_subset(cls, v: str) -> str:
        if v not in SPDX_LICENSES:
            raise ValueError(
                f"license {v!r} is not in the AgentSec SPDX subset; "
                f"see src/agentsec/suite_registry/spdx_licenses.txt"
            )
        return v

    @field_validator("threat_refs_required")
    @classmethod
    def _ti_ids_match_pattern(cls, v: list[str]) -> list[str]:
        for ti in v:
            if not _TI_ID_REGEX.match(ti):
                raise ValueError(f"TI ID {ti!r} must match {_TI_ID_REGEX.pattern}")
        return v


class IndexEntry(BaseModel):
    """One entry in `community-suites.yaml` under `suites:`."""

    model_config = _FORBID

    source: Literal["github"]
    repo: str
    ref: str = Field(min_length=1)
    subdir: str = Field(min_length=1)
    sha256: str
    summary: str = Field(min_length=1)

    @field_validator("repo")
    @classmethod
    def _repo_must_be_owner_repo(cls, v: str) -> str:
        if not _REPO_REGEX.fullmatch(v):
            raise ValueError(f"repo {v!r} must be of the form owner/name")
        return v

    @field_validator("subdir")
    @classmethod
    def _subdir_must_be_relative(cls, v: str) -> str:
        if v.startswith("/") or ".." in v.split("/"):
            raise ValueError(f"subdir {v!r} must be relative and not contain '..'")
        return v

    @field_validator("sha256")
    @classmethod
    def _sha256_must_be_64_hex(cls, v: str) -> str:
        if not _SHA256_REGEX.fullmatch(v):
            raise ValueError(f"sha256 {v!r} must be 64 lowercase hex chars")
        return v


class RegistryFile(BaseModel):
    """The full `community-suites.yaml` document."""

    model_config = _FORBID

    schema_version: Literal[1]
    suites: dict[str, IndexEntry] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _suite_keys_must_match_name_regex(self) -> "RegistryFile":
        for key in self.suites:
            if not NAME_REGEX.fullmatch(key):
                raise ValueError(
                    f"registry suite key {key!r} must match {NAME_REGEX.pattern}"
                )
        return self
