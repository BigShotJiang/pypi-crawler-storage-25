"""Canonical Merkle hash for suite bundles.

GitHub tarballs are not byte-stable across downloads (gzip metadata, mtimes).
We therefore hash the *extracted* tree by SHA-256ing each file's content and
folding the (sorted relpath, content hash) pairs into a top-level digest.

Properties:
- Insensitive to mtime, packing order, gzip compression
- Sensitive to any file content change or path rename
"""

import hashlib
from pathlib import Path


def canonical_hash(bundle_root: Path) -> str:
    """Return SHA-256 hex digest of the bundle tree at `bundle_root`.

    Walks every regular file under `bundle_root` (symlinks are excluded — they
    are also stripped by the installer's PEP-706 data filter, so including them
    here would cause silent hash divergence), sorts by relative path (POSIX
    form, lexicographic bytes), and hashes:
        for rel, content in sorted_pairs:
            h.update(b"\\x00" + rel_utf8 + b"\\x00")
            h.update(sha256(content).digest())
    """
    h = hashlib.sha256()
    files = sorted(
        (
            p.relative_to(bundle_root)
            for p in bundle_root.rglob("*")
            if p.is_file() and not p.is_symlink()
        ),
        key=lambda p: p.as_posix().encode("utf-8"),
    )
    for rel in files:
        rel_bytes = rel.as_posix().encode("utf-8")
        h.update(b"\x00" + rel_bytes + b"\x00")
        h.update(hashlib.sha256((bundle_root / rel).read_bytes()).digest())
    return h.hexdigest()
