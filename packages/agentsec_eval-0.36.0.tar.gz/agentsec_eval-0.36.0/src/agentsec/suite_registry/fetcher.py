"""Fetch a bundle tarball from GitHub.

GitHub serves any ref as a gzipped tar via codeload.github.com — no
authentication required for public repos. We use httpx (already a project
dependency) instead of git so users do not need git on their PATH.
"""

import httpx

from .errors import SuiteFetchError

GITHUB_TARBALL_URL = "https://codeload.github.com/{repo}/tar.gz/{ref}"
DEFAULT_TIMEOUT_SECONDS = 60.0


def fetch_tarball(
    repo: str,
    ref: str,
    *,
    client: httpx.Client | None = None,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> bytes:
    """Download `repo`@`ref` as gzipped tarball bytes.

    The `timeout` parameter is only applied when `client` is None (i.e.
    the function creates its own client). When a `client` is supplied,
    the caller is responsible for its timeout and redirect configuration.

    Raises:
        SuiteFetchError on any HTTP failure or network error.
    """
    url = GITHUB_TARBALL_URL.format(repo=repo, ref=ref)
    active_client: httpx.Client = (
        client if client is not None
        else httpx.Client(timeout=timeout, follow_redirects=True)
    )
    owns_client = client is None
    try:
        try:
            response = active_client.get(url)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise SuiteFetchError(
                f"GitHub returned {exc.response.status_code} for {repo}@{ref}: {url}"
            ) from exc
        except httpx.HTTPError as exc:
            raise SuiteFetchError(f"failed to fetch {repo}@{ref}: {exc}") from exc
        return response.content
    finally:
        if owns_client:
            active_client.close()
