"""Typed exceptions for the community suite registry.

All install failures inherit from `SuiteError`. The CLI catches the base
class and maps to user-facing messages plus the appropriate exit code.
"""


class SuiteError(Exception):
    """Base for all suite registry errors."""


class SuiteNotInRegistry(SuiteError):
    """The requested name is not in the registry index."""


class SuiteAlreadyInstalled(SuiteError):
    """A suite with this name is already installed and --force was not set."""


class SuiteFetchError(SuiteError):
    """Failed to download the bundle tarball."""


class SuiteHashMismatch(SuiteError):
    """The fetched bundle's canonical hash does not match the registry entry.

    Exit code is 2 (distinct from generic install failure) because this signals
    upstream tampering or a moved tag — the operator should investigate before
    retrying.
    """


class SuiteManifestError(SuiteError):
    """The bundle's manifest.yaml is invalid or incompatible."""


class SuiteTIRefMissing(SuiteError):
    """Bundle references TI rows not present in main repo's threat_intel.yaml."""

    def __init__(self, missing: set[str]) -> None:
        self.missing = sorted(missing)
        super().__init__(
            f"Suite requires TI rows not in main repo: {self.missing}. "
            f"Submit a PR adding these to src/agentsec/audit/ioc/threat_intel.yaml first."
        )


class SuiteValidationError(SuiteError):
    """Bundle structure is malformed or test cases fail loader validation."""
