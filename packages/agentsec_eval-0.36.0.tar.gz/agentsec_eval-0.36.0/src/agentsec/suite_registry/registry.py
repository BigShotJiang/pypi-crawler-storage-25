"""Registry — the source of truth for what suites exist.

`DefaultRegistry` reads the wheel-bundled `community-suites.yaml`. This is
the production path; everyone who installs AgentSec gets the same index.

`HttpRegistry` reads the same schema from a URL. Used by the hidden
`--registry-url` flag for local testing or dev-time experimentation. It is
NOT a recommended deployment path — the trust anchor for production usage
is the main-repo PR review process, which can only audit the in-wheel file.
"""

from importlib.resources import files
from typing import Protocol

import httpx
import yaml
from pydantic import ValidationError

from .errors import SuiteValidationError
from .manifest import IndexEntry, RegistryFile

_DEFAULT_INDEX_RESOURCE = "community-suites.yaml"


class Registry(Protocol):
    def lookup(self, name: str) -> IndexEntry | None: ...
    def all_entries(self) -> dict[str, IndexEntry]: ...


def _parse_index(text: str, source_label: str) -> dict[str, IndexEntry]:
    try:
        raw = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise SuiteValidationError(f"{source_label}: invalid YAML: {exc}") from exc
    try:
        rf = RegistryFile.model_validate(raw)
    except ValidationError as exc:
        raise SuiteValidationError(f"{source_label}: schema error: {exc}") from exc
    return rf.suites


class DefaultRegistry:
    """Read the wheel-bundled community-suites.yaml via importlib.resources."""

    def __init__(self) -> None:
        text = files("agentsec.suite_registry").joinpath(_DEFAULT_INDEX_RESOURCE).read_text()
        self._entries = _parse_index(text, source_label="(bundled community-suites.yaml)")

    def lookup(self, name: str) -> IndexEntry | None:
        return self._entries.get(name)

    def all_entries(self) -> dict[str, IndexEntry]:
        return dict(self._entries)


class HttpRegistry:
    """Read community-suites.yaml from an HTTP(S) URL.

    Fetches lazily on first access. Successful parses are cached for the
    lifetime of the instance; on fetch or parse failure, the next call
    retries (appropriate for transient HTTP failures, but means a malformed
    server response will be re-fetched on every call).
    """

    def __init__(self, url: str, client: httpx.Client | None = None) -> None:
        self._url = url
        self._client = client or httpx.Client(timeout=30.0)
        self._owns_client = client is None
        self._entries: dict[str, IndexEntry] | None = None

    def _load(self) -> dict[str, IndexEntry]:
        if self._entries is None:
            try:
                response = self._client.get(self._url)
                response.raise_for_status()
            except httpx.HTTPError as exc:
                raise SuiteValidationError(
                    f"failed to fetch registry from {self._url}: {exc}"
                ) from exc
            self._entries = _parse_index(response.text, source_label=self._url)
        return self._entries

    def lookup(self, name: str) -> IndexEntry | None:
        return self._load().get(name)

    def all_entries(self) -> dict[str, IndexEntry]:
        return dict(self._load())

    def __del__(self) -> None:  # pragma: no cover
        if self._owns_client:
            try:
                self._client.close()
            except Exception:  # noqa: BLE001,S110 — destructor must never raise
                pass
