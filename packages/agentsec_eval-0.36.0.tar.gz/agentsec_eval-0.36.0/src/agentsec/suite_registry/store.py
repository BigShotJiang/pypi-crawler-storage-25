"""Local store for installed community suites at ~/.agentsec/suites/."""

import json
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path


def _default_store_root() -> Path:
    # Resolved per-call so a HOME change between commands (or test
    # monkeypatching) is honored.
    return Path.home() / ".agentsec" / "suites"


DEFAULT_STORE_ROOT = _default_store_root()


@dataclass(frozen=True)
class InstalledSuite:
    name: str
    version: str | None       # None when corrupted
    ref: str | None
    sha256: str | None
    installed_at: str | None
    corrupted: bool = False


class Store:
    """Local installed-suite store, default ~/.agentsec/suites/."""

    def __init__(self, root: Path | None = None) -> None:
        self.root = root if root is not None else _default_store_root()

    def list_installed(self) -> list[InstalledSuite]:
        if not self.root.exists():
            return []
        out: list[InstalledSuite] = []
        for child in sorted(self.root.iterdir(), key=lambda c: c.name):
            if not child.is_dir():
                continue
            if child.name.startswith("."):
                # staging or backup leftover; ignore
                continue
            out.append(self._read_one(child))
        return out

    def is_installed(self, name: str) -> bool:
        target = self.root / name
        return target.is_dir() and (target / ".install-receipt.json").exists()

    def get(self, name: str) -> InstalledSuite | None:
        target = self.root / name
        if not target.is_dir():
            return None
        return self._read_one(target)

    def resolve(self, name: str) -> Path | None:
        """Return the cases/ directory for `name`, or None if not installed."""
        cases = self.root / name / "cases"
        return cases if cases.is_dir() else None

    def remove(self, name: str) -> bool:
        """Delete `name` from the store. Returns True if anything was removed."""
        target = self.root / name
        if not target.is_dir():
            return False
        shutil.rmtree(target)
        return True

    def write_receipt(self, name: str, *, version: str, ref: str, sha256: str) -> None:
        suite_dir = self.root / name
        if not suite_dir.is_dir():
            raise FileNotFoundError(
                f"Cannot write receipt: suite directory does not exist: {suite_dir}"
            )
        receipt = {
            "name": name,
            "version": version,
            "ref": ref,
            "sha256": sha256,
            "installed_at": datetime.now(UTC).isoformat(timespec="seconds"),
        }
        (suite_dir / ".install-receipt.json").write_text(json.dumps(receipt, indent=2))

    @staticmethod
    def _read_one(suite_dir: Path) -> InstalledSuite:
        receipt_path = suite_dir / ".install-receipt.json"
        if not receipt_path.exists():
            return InstalledSuite(
                name=suite_dir.name, version=None, ref=None, sha256=None,
                installed_at=None, corrupted=True,
            )
        try:
            data = json.loads(receipt_path.read_text())
        except (json.JSONDecodeError, OSError):
            return InstalledSuite(
                name=suite_dir.name, version=None, ref=None, sha256=None,
                installed_at=None, corrupted=True,
            )
        return InstalledSuite(
            name=data.get("name", suite_dir.name),
            version=data.get("version"),
            ref=data.get("ref"),
            sha256=data.get("sha256"),
            installed_at=data.get("installed_at"),
            corrupted=False,
        )
