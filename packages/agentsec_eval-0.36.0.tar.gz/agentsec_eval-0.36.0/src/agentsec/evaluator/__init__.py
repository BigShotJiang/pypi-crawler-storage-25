"""Lazy re-exports — concrete judges are loaded on attribute access so that
`from agentsec.evaluator.base import JudgeType` (used by tests.models) does
not transitively import the LLM client and trip the models ↔ judge cycle.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    # Static-analysis-only imports so type checkers see the names listed in
    # __all__; at runtime they're resolved lazily by __getattr__ below.
    from .deterministic_judge import DeterministicJudge
    from .hybrid_judge import HybridJudge
    from .judge import LLMJudge
    from .judge_router import JudgeRouter

__all__ = ["DeterministicJudge", "HybridJudge", "JudgeRouter", "LLMJudge"]


def __getattr__(name: str):
    if name == "LLMJudge":
        from .judge import LLMJudge

        return LLMJudge
    if name == "DeterministicJudge":
        from .deterministic_judge import DeterministicJudge

        return DeterministicJudge
    if name == "HybridJudge":
        from .hybrid_judge import HybridJudge

        return HybridJudge
    if name == "JudgeRouter":
        from .judge_router import JudgeRouter

        return JudgeRouter
    raise AttributeError(f"module 'agentsec.evaluator' has no attribute {name!r}")
