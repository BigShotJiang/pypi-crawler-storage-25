"""Judge ABC + verdict + assertion-outcome models (spec §4, §5.1)."""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, Field

from ..observability.observation import Observation

if TYPE_CHECKING:
    from ..tests.models import TestCase


JudgeType = Literal["llm", "deterministic", "hybrid"]
AssertionState = Literal["hard_pass", "hard_fail", "inconclusive"]


class AssertionOutcome(BaseModel):
    """Per-assertion outcome with three-state semantics (OE-AUD2-007).

    Aggregation rules (spec §5.1):
      - any hard_fail -> verdict.passed = False (LLM cannot override)
      - all hard_pass -> verdict.passed = True (LLM may add reasoning only)
      - inconclusive without hard_fail -> HybridJudge consults the LLM;
        DeterministicJudge fails with reasoning="inconclusive".
    """
    type: str
    state: AssertionState
    reasoning: str
    evidence: dict[str, Any] = Field(default_factory=dict)


class JudgeVerdict(BaseModel):
    passed: bool
    reasoning: str
    evidence: dict[str, Any] = Field(default_factory=dict)
    judge_type: JudgeType


class Judge(ABC):
    """Async judge interface. Implementations: LLMJudge, DeterministicJudge,
    HybridJudge (added in stage C)."""

    @abstractmethod
    async def evaluate(self, test_case: "TestCase", observation: Observation) -> JudgeVerdict:
        ...
