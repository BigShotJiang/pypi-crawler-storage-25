"""HybridJudge — Deterministic + LLM combiner per spec §5.1.

Short-circuit table:
  - any hard_fail   -> hybrid returns Determ verdict; LLM never called
  - all hard_pass   -> default: hybrid returns Determ verdict.
                       always_consult_llm=True: hybrid calls LLM, appends LLM
                       reasoning to verdict, but cannot flip passed.
  - inconclusive    -> hybrid calls LLM and adopts its verdict.
  - assertions=None -> hybrid degrades to pure LLM with a "no-assertions"
                       reasoning prefix so the report shows the degradation.
"""

from __future__ import annotations

from ..observability.observation import Observation
from ..tests.models import TestCase
from .base import AssertionOutcome, Judge, JudgeVerdict
from .deterministic_judge import aggregate


class HybridJudge(Judge):
    def __init__(self, llm_judge: Judge, *, always_consult_llm: bool = False):
        self._llm = llm_judge
        self._always_consult_llm = always_consult_llm

    async def evaluate(self, test_case: TestCase, observation: Observation) -> JudgeVerdict:
        if test_case.assertions is None:
            llm_verdict = await self._llm.evaluate(test_case, observation)
            return JudgeVerdict(
                passed=llm_verdict.passed,
                reasoning=f"[no assertions; pure LLM] {llm_verdict.reasoning}",
                evidence={"llm": llm_verdict.model_dump()},
                judge_type="hybrid",
            )

        # Assertion is `Annotated[Union[...]]` with no Protocol visible to mypy;
        # every concrete member inherits BaseAssertion.evaluate, so the call is
        # safe at runtime — the union-attr suppression covers the static gap.
        outcomes: list[AssertionOutcome] = [
            a.evaluate(observation) for a in test_case.assertions  # type: ignore[union-attr]
        ]
        det = aggregate(outcomes)
        assert det.judge_type == "deterministic", "aggregate() contract violated"  # noqa: S101 — internal contract assertion

        # Branch 1: hard_fail → short-circuit, never call LLM.
        if any(o.state == "hard_fail" for o in outcomes):
            return JudgeVerdict(
                passed=False,
                reasoning=det.reasoning,
                evidence={"deterministic": det.model_dump()},
                judge_type="hybrid",
            )

        inconclusives = [o for o in outcomes if o.state == "inconclusive"]

        # Branch 2: all hard_pass — return immediately unless asked to consult LLM.
        if not inconclusives:
            if not self._always_consult_llm:
                return JudgeVerdict(
                    passed=True,
                    reasoning=det.reasoning,
                    evidence={"deterministic": det.model_dump()},
                    judge_type="hybrid",
                )
            llm_verdict = await self._llm.evaluate(test_case, observation)
            return JudgeVerdict(
                passed=True,  # LLM cannot flip a hard_pass — spec §5.1
                reasoning=f"{det.reasoning}; LLM: {llm_verdict.reasoning}",
                evidence={
                    "deterministic": det.model_dump(),
                    "llm": llm_verdict.model_dump(),
                    "llm_could_not_flip": True,
                },
                judge_type="hybrid",
            )

        # Branch 3: ≥1 inconclusive, no hard_fail → consult LLM and adopt verdict.
        llm_verdict = await self._llm.evaluate(test_case, observation)
        return JudgeVerdict(
            passed=llm_verdict.passed,
            reasoning=f"{det.reasoning}; LLM: {llm_verdict.reasoning}",
            evidence={
                "deterministic": det.model_dump(),
                "llm": llm_verdict.model_dump(),
            },
            judge_type="hybrid",
        )
