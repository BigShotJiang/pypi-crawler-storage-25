"""OpenAI-compatible LLM judge — calls any OpenAI-format /chat/completions endpoint."""
from __future__ import annotations

import json
import os

import httpx

from ..config import OpenAIJudgeConfig
from ..observability.observation import Observation
from ..tests.models import TestCase
from .base import Judge, JudgeVerdict
from .judge import _SYSTEM


class OpenAICompatibleJudge(Judge):
    """Judge that calls an OpenAI-compatible /chat/completions endpoint."""

    def __init__(
        self,
        config: OpenAIJudgeConfig,
        _transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        api_key = os.environ.get(config.api_key_env)
        if api_key is None:
            raise ValueError(
                f"environment variable {config.api_key_env!r} is not set"
            )
        self._config = config
        self._api_key = api_key
        self._transport = _transport

    def _build_user(self, test: TestCase, obs: Observation) -> str:
        attack = test.turns[-1].attack if test.turns else (test.attack or "")
        return (
            f"Attack payload:\n{attack}\n\n"
            f"Agent response:\n{obs.response.content}\n\n"
            f"Expected behavior: {test.expected_behavior}\n"
            + (f"Hint: {test.judge_hint}" if test.judge_hint else "")
        )

    async def evaluate(self, test_case: TestCase, observation: Observation) -> JudgeVerdict:
        user = self._build_user(test_case, observation)
        try:
            async with httpx.AsyncClient(
                timeout=self._config.timeout,
                transport=self._transport,
            ) as client:
                resp = await client.post(
                    f"{self._config.base_url.rstrip('/')}/chat/completions",
                    headers={"Authorization": f"Bearer {self._api_key}"},
                    json={
                        "model": self._config.model,
                        "messages": [
                            {"role": "system", "content": _SYSTEM},
                            {"role": "user", "content": user},
                        ],
                        "temperature": 0,
                    },
                )
        except httpx.TimeoutException:
            return JudgeVerdict(
                passed=False, reasoning="request timeout", judge_type="llm"
            )
        except httpx.TransportError as exc:
            return JudgeVerdict(
                passed=False, reasoning=f"request error: {exc}", judge_type="llm"
            )

        if not resp.is_success:
            return JudgeVerdict(
                passed=False,
                reasoning=f"http error {resp.status_code}: {resp.text[:200]}",
                judge_type="llm",
            )

        try:
            body = resp.json()
            content = body["choices"][0]["message"]["content"]
        except Exception:
            return JudgeVerdict(
                passed=False, reasoning="parse error: malformed response body", judge_type="llm"
            )

        try:
            parsed = json.loads(content)
        except json.JSONDecodeError as exc:
            return JudgeVerdict(
                passed=False, reasoning=f"parse error: {exc}", judge_type="llm"
            )

        try:
            return JudgeVerdict(
                passed=bool(parsed["passed"]),
                reasoning=str(parsed["reasoning"]),
                judge_type="llm",
            )
        except (KeyError, TypeError):
            return JudgeVerdict(
                passed=False, reasoning="parse error: missing fields", judge_type="llm"
            )
