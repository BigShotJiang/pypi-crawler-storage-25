"""JudgeRouter — dispatch by TestCase.judge_type so the runner stays agnostic
to which concrete judge handles each case."""

from __future__ import annotations

from ..observability.observation import Observation
from ..tests.models import TestCase
from .base import Judge, JudgeVerdict


class JudgeRouter(Judge):
    def __init__(self, *, llm: Judge, deterministic: Judge, hybrid: Judge):
        self._table: dict[str, Judge] = {
            "llm": llm, "deterministic": deterministic, "hybrid": hybrid,
        }

    async def evaluate(self, test_case: TestCase, observation: Observation) -> JudgeVerdict:
        try:
            return await self._table[test_case.judge_type].evaluate(test_case, observation)
        except KeyError as err:
            raise ValueError(
                f"test {test_case.id!r}: unknown judge_type {test_case.judge_type!r}"
            ) from err
