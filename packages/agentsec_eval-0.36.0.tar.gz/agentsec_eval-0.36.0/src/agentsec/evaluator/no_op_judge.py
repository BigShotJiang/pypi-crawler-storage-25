"""No-op judge — populates the LLM slot of a JudgeRouter when no Anthropic
key is available because the suite is deterministic-only.

JudgeRouter dispatches per `TestCase.judge_type`: a deterministic-only suite
never reaches this branch. NoOpJudgeInvoked therefore fires only when:
  - a hand-built TestCase has `judge_type="llm"` in a deterministic-only run, or
  - JudgeRouter has a dispatch bug.

Both cases are programmer errors, so the typed RuntimeError subclass surfaces
the failure with a useful message instead of silently passing.

Closes Stage C M4 carryover (the `_UnreachableLLM` inline class in cli.py).
"""

from typing import TYPE_CHECKING

from ..observability.observation import Observation
from .base import Judge, JudgeVerdict

if TYPE_CHECKING:
    from ..tests.models import TestCase


class NoOpJudgeInvoked(RuntimeError):
    """Raised when NoOpJudge.evaluate() is dispatched to. See module docstring."""


class NoOpJudge(Judge):
    async def evaluate(
        self, test_case: "TestCase", observation: Observation
    ) -> JudgeVerdict:
        raise NoOpJudgeInvoked(
            "LLM judge is not configured (NoOpJudge is in the LLM slot). "
            "This means a deterministic-only suite somehow routed a case "
            "with judge_type=llm — set AGENTSEC_JUDGE_API_KEY or fix the "
            "test case's judge_type."
        )
