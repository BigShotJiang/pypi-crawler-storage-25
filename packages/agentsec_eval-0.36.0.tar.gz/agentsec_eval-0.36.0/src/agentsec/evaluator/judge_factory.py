"""Build a Judge from environment variables — provider-agnostic LLM config.

Lets users plug in any major LLM provider without writing a yaml `judge:`
block. The yaml-driven path (`OpenClawTargetConfig.judge`) is unchanged and
takes precedence; this factory only fills in the default when no yaml judge
is configured.

Variables (all optional; sensible defaults):

    AGENTSEC_LLM_PROVIDER     anthropic | openai      (default: anthropic;
                                                       auto-set to openai when
                                                       AGENTSEC_LLM_BASE_URL
                                                       is present)
    AGENTSEC_LLM_API_KEY      provider API key
    AGENTSEC_LLM_BASE_URL     OpenAI-compatible /v1 base URL
    AGENTSEC_LLM_MODEL        model name
    AGENTSEC_LLM_TIMEOUT      request timeout in seconds (openai only;
                              default 30)

Backward compatibility:

- When provider=anthropic and AGENTSEC_LLM_API_KEY is unset, the Anthropic
  SDK's native ANTHROPIC_API_KEY lookup still applies.
- AGENTSEC_JUDGE_API_KEY is recognised by the CLI's `--api-key` flag for
  the older flow; the CLI normalises it into AGENTSEC_LLM_API_KEY before
  this factory runs.
"""
from __future__ import annotations

import os

from ..config import OpenAIJudgeConfig
from .base import Judge
from .judge import LLMJudge
from .openai_judge import OpenAICompatibleJudge

_REQUIRED_OPENAI_VARS = (
    "AGENTSEC_LLM_MODEL",
    "AGENTSEC_LLM_BASE_URL",
    "AGENTSEC_LLM_API_KEY",
)


def _resolve_provider() -> str:
    explicit = (os.environ.get("AGENTSEC_LLM_PROVIDER") or "").strip().lower()
    if explicit:
        return explicit
    # Auto-detect: a base_url implies an OpenAI-compatible endpoint.
    if os.environ.get("AGENTSEC_LLM_BASE_URL"):
        return "openai"
    return "anthropic"


def build_default_judge_from_env() -> Judge:
    """Construct the LLM-slot judge based on AGENTSEC_LLM_* environment vars.

    Raises:
        ValueError: when the chosen provider's required vars are missing or
            an unknown provider name is given. Anthropic SDK errors (e.g.
            missing ANTHROPIC_API_KEY) propagate from `LLMJudge.__init__`.
    """
    provider = _resolve_provider()

    if provider == "anthropic":
        model = os.environ.get("AGENTSEC_LLM_MODEL") or "claude-sonnet-4-6"
        api_key = os.environ.get("AGENTSEC_LLM_API_KEY")
        return LLMJudge(model=model, api_key=api_key)

    if provider == "openai":
        missing = [v for v in _REQUIRED_OPENAI_VARS if not os.environ.get(v)]
        if missing:
            raise ValueError(
                "AGENTSEC_LLM_PROVIDER=openai requires the following "
                f"environment variable(s) to be set: {', '.join(missing)}"
            )
        timeout_str = os.environ.get("AGENTSEC_LLM_TIMEOUT") or "30"
        try:
            timeout = int(timeout_str)
        except ValueError as exc:
            raise ValueError(
                f"AGENTSEC_LLM_TIMEOUT must be an integer (seconds), "
                f"got {timeout_str!r}"
            ) from exc
        cfg = OpenAIJudgeConfig(
            type="openai_compatible",
            model=os.environ["AGENTSEC_LLM_MODEL"],
            base_url=os.environ["AGENTSEC_LLM_BASE_URL"],
            api_key_env="AGENTSEC_LLM_API_KEY",
            timeout=timeout,
        )
        return OpenAICompatibleJudge(cfg)

    raise ValueError(
        f"unknown AGENTSEC_LLM_PROVIDER={provider!r}; "
        "expected 'anthropic' or 'openai'"
    )
