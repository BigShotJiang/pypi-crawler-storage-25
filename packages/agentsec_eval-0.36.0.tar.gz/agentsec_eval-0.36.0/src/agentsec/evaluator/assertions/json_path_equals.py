"""json_path_equals — read a value out of `AgentResponse.raw` via JSONPath and
compare. Mismatch is inconclusive (spec §5.1: not in forced hard_fail list)."""

from typing import Any, Literal

from jsonpath_ng import parse as jp_parse
from pydantic import PrivateAttr, field_validator

from ...observability.observation import Observation
from ..base import AssertionOutcome
from .base import BaseAssertion


class JsonPathEquals(BaseAssertion):
    type: Literal["json_path_equals"] = "json_path_equals"
    path: str
    value: Any

    _expr: Any = PrivateAttr()

    @field_validator("path")
    @classmethod
    def _parseable(cls, v: str) -> str:
        try:
            jp_parse(v)
        except Exception as exc:  # noqa: BLE001 — jsonpath-ng raises plain Exception subclasses
            raise ValueError(f"invalid jsonpath {v!r}: {exc}") from exc
        return v

    def model_post_init(self, __context: Any) -> None:
        # `path` is already validated; cache the compiled expression so we
        # don't re-invoke the PLY parser on every evaluate() call.
        self._expr = jp_parse(self.path)

    def evaluate(self, observation: Observation) -> AssertionOutcome:
        matches = [m.value for m in self._expr.find(observation.response.raw)]
        if not matches:
            return AssertionOutcome(
                type=self.type,
                state="inconclusive",
                reasoning=f"jsonpath {self.path!r} matched nothing in response.raw",
            )
        actual = matches[0]
        if actual == self.value:
            return AssertionOutcome(
                type=self.type,
                state="hard_pass",
                reasoning=f"{self.path}={actual!r} as expected",
            )
        return AssertionOutcome(
            type=self.type,
            state="inconclusive",
            reasoning=f"{self.path}={actual!r}, expected {self.value!r}",
            evidence={"actual": actual, "expected": self.value},
        )
