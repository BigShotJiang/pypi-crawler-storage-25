"""tool_event_not_invoked — forced hard_fail when Observation.tool_events
contains an invocation of `tool_name` (optionally filtered by
`with_args_pattern`)."""

import re
from typing import Any, Literal

from pydantic import PrivateAttr, field_validator

from ...observability.observation import Observation
from ..base import AssertionOutcome
from .base import BaseAssertion


class ToolEventNotInvoked(BaseAssertion):
    type: Literal["tool_event_not_invoked"] = "tool_event_not_invoked"
    tool_name: str
    with_args_pattern: str | None = None

    _compiled_pattern: Any = PrivateAttr(default=None)

    @field_validator("with_args_pattern")
    @classmethod
    def _compilable(cls, v: str | None) -> str | None:
        if v is None:
            return None
        try:
            re.compile(v)
        except re.error as exc:
            raise ValueError(f"invalid regex {v!r}: {exc}") from exc
        return v

    def model_post_init(self, __context: Any) -> None:
        if self.with_args_pattern is not None:
            self._compiled_pattern = re.compile(self.with_args_pattern)

    def evaluate(self, observation: Observation) -> AssertionOutcome:
        regex = self._compiled_pattern
        matched: list[dict] = []
        for ev in observation.tool_events:
            if ev.get("tool") != self.tool_name:
                continue
            # Collapse missing-key, None, and "" to a uniform empty string so
            # `args=None` doesn't render as the literal "None" and falsely
            # match a pattern like `r"None"`.
            args_repr = str(ev.get("args") or "")
            if regex is not None and not regex.search(args_repr):
                continue
            matched.append(ev)
        if not matched:
            return AssertionOutcome(
                type=self.type,
                state="hard_pass",
                reasoning=(
                    f"no tool invocations matched {self.tool_name!r}"
                    + (f" with args pattern {self.with_args_pattern!r}"
                       if self.with_args_pattern else "")
                ),
            )
        return AssertionOutcome(
            type=self.type,
            state="hard_fail",
            reasoning=f"{len(matched)} tool invocation(s) of {self.tool_name!r} matched",
            evidence={"matched": matched, "tool_name": self.tool_name},
        )
