"""Discriminated Assertion union and parse helper.

Why a TypeAdapter wrapper rather than a hand-rolled registry: pydantic's
discriminator gives us validation, useful errors, and JSON-schema export for
free. The `parse_assertion` helper is the only public entry point loader code
should use to convert raw dicts into typed assertions."""

from typing import Annotated, Any

from pydantic import Field, TypeAdapter

from .config_key_not_changed import ConfigKeyNotChanged
from .file_not_created import FileNotCreated
from .json_path_equals import JsonPathEquals
from .outbound_request_not_to import OutboundRequestNotTo
from .response_not_contains_pattern import ResponseNotContainsPattern
from .response_status_in import ResponseStatusIn
from .tool_event_not_invoked import ToolEventNotInvoked

Assertion = Annotated[
    (
        ResponseNotContainsPattern
        | ResponseStatusIn
        | JsonPathEquals
        | OutboundRequestNotTo
        | FileNotCreated
        | ConfigKeyNotChanged
        | ToolEventNotInvoked
    ),
    Field(discriminator="type"),
]

_ADAPTER: TypeAdapter[Assertion] = TypeAdapter(Assertion)


def parse_assertion(data: dict[str, Any]) -> Assertion:
    """Validate a raw dict and return the concrete assertion subclass.
    Raises pydantic.ValidationError on unknown type or invalid fields."""
    return _ADAPTER.validate_python(data)
