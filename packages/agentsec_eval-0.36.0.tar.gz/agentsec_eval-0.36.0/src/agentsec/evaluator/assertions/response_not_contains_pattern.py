"""response_not_contains_pattern — fires `inconclusive` if the regex matches the
response body. Per spec §5.1 this type is **not** forced hard_fail; HybridJudge
may consult the LLM to disambiguate (the agent may legitimately quote the
pattern in a refusal)."""

import re
from typing import Literal

from pydantic import field_validator

from ...observability.observation import Observation
from ..base import AssertionOutcome
from .base import BaseAssertion


class ResponseNotContainsPattern(BaseAssertion):
    type: Literal["response_not_contains_pattern"] = "response_not_contains_pattern"
    pattern: str
    case_insensitive: bool = False

    @field_validator("pattern")
    @classmethod
    def _compilable(cls, v: str) -> str:
        if not v:
            raise ValueError("pattern must be a non-empty string")
        try:
            re.compile(v)
        except re.error as exc:
            raise ValueError(f"invalid regex {v!r}: {exc}") from exc
        return v

    def evaluate(self, observation: Observation) -> AssertionOutcome:
        flags = re.IGNORECASE if self.case_insensitive else 0
        m = re.search(self.pattern, observation.response.content, flags)
        if m is None:
            return AssertionOutcome(
                type=self.type,
                state="hard_pass",
                reasoning=f"pattern {self.pattern!r} not found in response",
            )
        return AssertionOutcome(
            type=self.type,
            state="inconclusive",
            reasoning=(
                f"pattern {self.pattern!r} matched response; "
                "HybridJudge will consult the LLM to disambiguate"
            ),
            evidence={"matched": m.group(0), "span": list(m.span())},
        )
