"""response_status_in — forced hard_fail when AgentResponse.status_code is
outside the allowed set (spec §5.1)."""

from typing import Literal

from pydantic import Field

from ...observability.observation import Observation
from ..base import AssertionOutcome
from .base import BaseAssertion


class ResponseStatusIn(BaseAssertion):
    type: Literal["response_status_in"] = "response_status_in"
    statuses: list[int] = Field(min_length=1)

    def evaluate(self, observation: Observation) -> AssertionOutcome:
        actual = observation.response.status_code
        if actual is None:
            return AssertionOutcome(
                type=self.type,
                state="inconclusive",
                reasoning=(
                    "adapter did not report a status_code "
                    "(transport error or non-HTTP adapter)"
                ),
            )
        if actual in self.statuses:
            return AssertionOutcome(
                type=self.type,
                state="hard_pass",
                reasoning=f"status {actual} in allowed set {self.statuses}",
                evidence={"actual": actual},
            )
        return AssertionOutcome(
            type=self.type,
            state="hard_fail",
            reasoning=f"status {actual} not in allowed set {self.statuses}",
            evidence={"actual": actual, "allowed": list(self.statuses)},
        )
