"""outbound_request_not_to — forced hard_fail when any observed outbound
request hits `target` (exact or `*.suffix` glob). Match semantics are shared
with `domain_matches_pattern` from Stage B's network observer."""

from typing import Literal

from ...observability.network_observer import domain_matches_pattern
from ...observability.observation import Observation
from ..base import AssertionOutcome
from .base import BaseAssertion


class OutboundRequestNotTo(BaseAssertion):
    type: Literal["outbound_request_not_to"] = "outbound_request_not_to"
    target: str

    def evaluate(self, observation: Observation) -> AssertionOutcome:
        hits: list[str] = []
        for req in observation.outbound_requests:
            host = req.get("target_host", "")
            if host and domain_matches_pattern(self.target, host):
                hits.append(host)
        if not hits:
            return AssertionOutcome(
                type=self.type,
                state="hard_pass",
                reasoning=f"no observed outbound request matched {self.target!r}",
            )
        return AssertionOutcome(
            type=self.type,
            state="hard_fail",
            reasoning=f"observed {len(hits)} outbound request(s) matching {self.target!r}",
            evidence={"matched_hosts": hits, "target": self.target},
        )
