"""file_not_created — forced hard_fail if path appears in
`Observation.post_state_snapshot["files"]`. Absent snapshot → inconclusive
(no signal). Stage D's server-audit is responsible for populating the
snapshot; Stage C consumes what is there."""

from typing import Literal

from ...observability.observation import Observation
from ..base import AssertionOutcome
from .base import BaseAssertion


class FileNotCreated(BaseAssertion):
    type: Literal["file_not_created"] = "file_not_created"
    path: str

    def evaluate(self, observation: Observation) -> AssertionOutcome:
        snap = observation.post_state_snapshot
        if snap is None or "files" not in snap:
            return AssertionOutcome(
                type=self.type,
                state="inconclusive",
                reasoning=(
                    "no post_state_snapshot.files captured; "
                    "configure isolation.post_snapshot to include files"
                ),
            )
        files = snap["files"]
        if not isinstance(files, list):
            return AssertionOutcome(
                type=self.type,
                state="inconclusive",
                reasoning=(
                    f"post_state_snapshot.files has unexpected type "
                    f"{type(files).__name__!r}; expected list"
                ),
            )
        if self.path in files:
            return AssertionOutcome(
                type=self.type,
                state="hard_fail",
                reasoning=f"file {self.path!r} was created during the test",
                evidence={"found_path": self.path},
            )
        return AssertionOutcome(
            type=self.type,
            state="hard_pass",
            reasoning=f"file {self.path!r} not present in post-state snapshot",
        )
