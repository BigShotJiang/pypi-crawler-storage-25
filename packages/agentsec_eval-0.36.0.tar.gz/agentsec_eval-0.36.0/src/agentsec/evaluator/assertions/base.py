"""Base class for assertions (spec §5.4)."""

from abc import ABC, abstractmethod

from pydantic import BaseModel, ConfigDict

from ...observability.observation import Observation
from ..base import AssertionOutcome


class BaseAssertion(BaseModel, ABC):
    """Pydantic ABC. Subclasses declare a `type: Literal["..."]` discriminator
    and implement `evaluate`. `extra="forbid"` keeps YAML typos loud rather
    than silently dropped."""

    model_config = ConfigDict(extra="forbid")

    @abstractmethod
    def evaluate(self, observation: Observation) -> AssertionOutcome:
        ...
