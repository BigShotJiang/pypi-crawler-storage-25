"""Assertion package — discriminated Pydantic union of per-type assertions.

Public API: `Assertion` (the union type), `parse_assertion(dict) -> Assertion`,
and the seven concrete subclasses for direct construction in tests.
"""

from .base import BaseAssertion
from .config_key_not_changed import ConfigKeyNotChanged
from .file_not_created import FileNotCreated
from .json_path_equals import JsonPathEquals
from .outbound_request_not_to import OutboundRequestNotTo
from .registry import Assertion, parse_assertion
from .response_not_contains_pattern import ResponseNotContainsPattern
from .response_status_in import ResponseStatusIn
from .tool_event_not_invoked import ToolEventNotInvoked

__all__ = [
    "Assertion",
    "BaseAssertion",
    "ConfigKeyNotChanged",
    "FileNotCreated",
    "JsonPathEquals",
    "OutboundRequestNotTo",
    "ResponseNotContainsPattern",
    "ResponseStatusIn",
    "ToolEventNotInvoked",
    "parse_assertion",
]
