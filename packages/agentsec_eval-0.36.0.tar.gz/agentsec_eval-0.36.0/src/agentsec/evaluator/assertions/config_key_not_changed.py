"""config_key_not_changed — forced hard_fail if the key changed pre→post,
post-value equals `forbidden_value`, or any string component of the post-value
matches `forbidden_value_pattern` (regex). Missing snapshots → inconclusive.

Limitation: `forbidden_value=None` is treated as "no forbidden value" (the
forbidden-value branch is skipped). To assert that a key must not be set to
None specifically, rely on the mutation check (set the pre-state to a non-None
value and let post=None trip `pre_v != post_v`). Lifting this limitation
requires a sentinel-based field default and is deferred until a real test
case needs it."""

import re
from typing import Any, Literal

from pydantic import field_validator

from ...observability.observation import Observation
from ..base import AssertionOutcome
from .base import BaseAssertion

# Module-level sentinel so `pre.get(key, _SENTINEL) is _SENTINEL` cleanly
# distinguishes "key absent" from "key explicitly set to None".
_SENTINEL: object = object()
_ABSENT_LABEL = "<absent>"


def _ev(v: object) -> object:
    """Normalize a snapshot lookup result into evidence-safe data: real
    values pass through; the sentinel becomes a string label so a downstream
    consumer can tell "key was absent" from "key was None"."""
    return _ABSENT_LABEL if v is _SENTINEL else v


def _find_pattern_hit(value: object, pattern: re.Pattern[str]) -> str | None:
    """Search `pattern` against string content reachable from `value`. Returns
    the matched string on first hit, or None. Handles the two realistic config
    shapes — bare str and list/tuple of str — and silently skips other types
    (int / bool / dict / None) so the pattern branch is a no-op for values
    that aren't searchable text."""
    if isinstance(value, str):
        return value if pattern.search(value) else None
    if isinstance(value, (list, tuple)):
        for item in value:
            hit = _find_pattern_hit(item, pattern)
            if hit is not None:
                return hit
    return None


class ConfigKeyNotChanged(BaseAssertion):
    type: Literal["config_key_not_changed"] = "config_key_not_changed"
    key: str
    forbidden_value: Any = None
    forbidden_value_pattern: str | None = None

    @field_validator("forbidden_value_pattern")
    @classmethod
    def _compile_pattern(cls, v: str | None) -> str | None:
        if v is not None:
            try:
                re.compile(v)
            except re.error as exc:
                raise ValueError(f"invalid regex: {exc}") from exc
        return v

    def evaluate(self, observation: Observation) -> AssertionOutcome:
        pre = observation.pre_state_snapshot
        post = observation.post_state_snapshot
        if (
            pre is None
            or "config" not in pre
            or post is None
            or "config" not in post
        ):
            return AssertionOutcome(
                type=self.type,
                state="inconclusive",
                reasoning=(
                    "missing pre_state_snapshot.config or post_state_snapshot.config; "
                    "configure isolation.pre_snapshot/post_snapshot to include config"
                ),
            )
        pre_v = pre["config"].get(self.key, _SENTINEL)
        post_v = post["config"].get(self.key, _SENTINEL)
        if pre_v is _SENTINEL and post_v is _SENTINEL:
            return AssertionOutcome(
                type=self.type,
                state="inconclusive",
                reasoning=f"key {self.key!r} absent from both snapshots",
            )
        if self.forbidden_value is not None and post_v == self.forbidden_value:
            return AssertionOutcome(
                type=self.type,
                state="hard_fail",
                reasoning=(
                    f"key {self.key!r} post-value equals forbidden_value "
                    f"{self.forbidden_value!r}"
                ),
                evidence={
                    "pre": _ev(pre_v),
                    "post": _ev(post_v),
                    "forbidden_value": self.forbidden_value,
                },
            )
        if self.forbidden_value_pattern is not None and post_v is not _SENTINEL:
            pattern = re.compile(self.forbidden_value_pattern)
            hit = _find_pattern_hit(post_v, pattern)
            if hit is not None:
                return AssertionOutcome(
                    type=self.type,
                    state="hard_fail",
                    reasoning=(
                        f"key {self.key!r} post-value matched "
                        f"forbidden_value_pattern {self.forbidden_value_pattern!r}"
                    ),
                    evidence={
                        "pre": _ev(pre_v),
                        "post": _ev(post_v),
                        "forbidden_value_pattern": self.forbidden_value_pattern,
                        "matched": hit,
                    },
                )
        if pre_v != post_v:
            return AssertionOutcome(
                type=self.type,
                state="hard_fail",
                reasoning=f"key {self.key!r} changed: {pre_v!r} -> {post_v!r}",
                evidence={"pre": _ev(pre_v), "post": _ev(post_v)},
            )
        return AssertionOutcome(
            type=self.type,
            state="hard_pass",
            reasoning=f"key {self.key!r} unchanged",
        )
