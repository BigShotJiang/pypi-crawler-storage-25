"""PluginJudge — loads a user-supplied .py file and delegates to the Judge subclass inside."""
from __future__ import annotations

import importlib.util
from pathlib import Path

from ..observability.observation import Observation
from ..tests.models import TestCase
from .base import Judge, JudgeVerdict


class PluginJudge(Judge):
    """Wraps a dynamically loaded user Judge subclass."""

    def __init__(self, path: Path) -> None:
        if not path.exists():
            raise ValueError(f"{path}: file not found")

        spec = importlib.util.spec_from_file_location("_agentsec_plugin_judge", path)
        module = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
        spec.loader.exec_module(module)  # type: ignore[union-attr]

        subclasses = [
            obj
            for obj in vars(module).values()
            if isinstance(obj, type) and issubclass(obj, Judge) and obj is not Judge
        ]

        if len(subclasses) == 0:
            raise ValueError(f"{path}: no Judge subclass found")
        if len(subclasses) > 1:
            names = ", ".join(c.__name__ for c in subclasses)
            raise ValueError(f"{path}: ambiguous — found: {names}")

        self._delegate: Judge = subclasses[0]()

    async def evaluate(self, test_case: TestCase, observation: Observation) -> JudgeVerdict:
        return await self._delegate.evaluate(test_case, observation)
