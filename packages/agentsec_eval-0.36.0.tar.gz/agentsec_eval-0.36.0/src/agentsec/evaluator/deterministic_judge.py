"""DeterministicJudge — runs every assertion in `TestCase.assertions` against
the last `Observation`, aggregates per spec §5.1.

Aggregation rules:
  - any hard_fail  -> verdict.passed = False (LLM cannot override; HybridJudge
                       short-circuits the same way)
  - all hard_pass  -> verdict.passed = True
  - otherwise      -> verdict.passed = False, reasoning="inconclusive"

The `evidence` dict carries the per-assertion outcomes so HybridJudge can pick
out the inconclusive ones for LLM consultation.
"""

from __future__ import annotations

from ..observability.observation import Observation
from ..tests.models import TestCase
from .base import AssertionOutcome, Judge, JudgeVerdict


def aggregate(outcomes: list[AssertionOutcome]) -> JudgeVerdict:
    """Pure aggregation rule per spec §5.1. Used by both DeterministicJudge
    and HybridJudge so the matrix lives in one place.

    Contract: returns ``judge_type="deterministic"`` unconditionally — callers
    that wrap this function (HybridJudge) MUST rewrap the verdict with their
    own judge_type before returning. The aggregation matrix is shared between
    DeterministicJudge and HybridJudge but the *judge_type* field reflects
    which judge produced the final verdict, not which helper computed it.
    """
    if not outcomes:
        return JudgeVerdict(
            passed=False,
            reasoning="inconclusive: no assertions to run",
            evidence={"outcomes": []},
            judge_type="deterministic",
        )
    hard_fails = [o for o in outcomes if o.state == "hard_fail"]
    if hard_fails:
        names = ", ".join(o.type for o in hard_fails)
        return JudgeVerdict(
            passed=False,
            reasoning=f"hard_fail on: {names}",
            evidence={"outcomes": [o.model_dump() for o in outcomes]},
            judge_type="deterministic",
        )
    inconclusives = [o for o in outcomes if o.state == "inconclusive"]
    if inconclusives:
        names = ", ".join(o.type for o in inconclusives)
        return JudgeVerdict(
            passed=False,
            reasoning=f"inconclusive on: {names}",
            evidence={"outcomes": [o.model_dump() for o in outcomes]},
            judge_type="deterministic",
        )
    return JudgeVerdict(
        passed=True,
        reasoning="all assertions hard_pass",
        evidence={"outcomes": [o.model_dump() for o in outcomes]},
        judge_type="deterministic",
    )


class DeterministicJudge(Judge):
    async def evaluate(self, test_case: TestCase, observation: Observation) -> JudgeVerdict:
        if test_case.assertions is None:
            raise ValueError(
                f"test {test_case.id!r}: DeterministicJudge requires "
                "TestCase.assertions to be a list (use judge_type=llm if you "
                "have no assertions)"
            )
        # Assertion is `Annotated[Union[...]]` with no Protocol visible to mypy;
        # every concrete member inherits BaseAssertion.evaluate, so the call is
        # safe at runtime — the union-attr suppression covers the static gap.
        outcomes: list[AssertionOutcome] = [
            a.evaluate(observation) for a in test_case.assertions  # type: ignore[union-attr]
        ]
        return aggregate(outcomes)
