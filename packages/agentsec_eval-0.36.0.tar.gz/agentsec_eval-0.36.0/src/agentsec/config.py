"""OpenClaw target configuration model (spec §8.2).

This is the only module that knows the shape of `openclaw-target.yaml`. The
CLI's `evaluate` command loads through `OpenClawTargetConfig.from_yaml(path)`;
every field is validated up front so partial-execution failures (server-audit
runs, then config is wrong, then SSH connections leak) are impossible.

Both `remote` and `server_audit` are optional; at least one must be present.
This lets the same config-driven flow handle "remote-only" and "audit-only"
deployments without a second config schema.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, field_validator, model_validator

from .audit.metachar_guard import contains_shell_metachar

_FORBID = ConfigDict(extra="forbid")


class OpenAIJudgeConfig(BaseModel):
    model_config = _FORBID
    type: Literal["openai_compatible"]
    model: str
    base_url: str
    api_key_env: str
    timeout: int = Field(default=30, ge=1)


class PluginJudgeConfig(BaseModel):
    model_config = _FORBID
    type: Literal["plugin"]
    path: Path


JudgeConfig = Annotated[
    OpenAIJudgeConfig | PluginJudgeConfig,
    Field(discriminator="type"),
]


class FixtureConfig(BaseModel):
    model_config = _FORBID
    serve_via: Literal["auto", "same-host-loopback", "reachable-url", "ssh-port-forward"] = "auto"
    bind: str = "0.0.0.0"  # noqa: S104 — fixture must be reachable from a remote target agent; operators override per-deployment
    public_base_url: str = ""


class NetworkObserverConfigSection(BaseModel):
    model_config = _FORBID
    mode: Literal["fixture_only", "reverse_proxy", "dns_sink", "egress_log"] = "fixture_only"
    controlled_domains: list[str] = Field(default_factory=list)
    # spec §8.2 / §5.4: required when mode=reverse_proxy; v0.2.0 only implements
    # fixture_only so this field is accepted (avoids extra="forbid" rejection
    # for spec-conformant configs) but unused.
    proxy_url: str = ""


class RemoteConfig(BaseModel):
    model_config = _FORBID
    adapter: str
    target: str
    token_env: str | None = None
    test_suites: list[Path] = Field(default_factory=list)
    concurrency: int = Field(default=3, ge=1)
    fixture: FixtureConfig = Field(default_factory=FixtureConfig)
    network_observer: NetworkObserverConfigSection = Field(
        default_factory=NetworkObserverConfigSection
    )


class LogReviewConfig(BaseModel):
    model_config = _FORBID
    journald_since_hours: int = Field(default=24, ge=1, le=168)
    journald_max_lines: int = Field(default=10_000, ge=100, le=100_000)


_PIP_LOCK_SUFFIXES = (".txt", ".lock", ".in")


def _has_allowed_suffix(path: str) -> bool:
    p = path.lower()
    if any(p.endswith(s) for s in _PIP_LOCK_SUFFIXES):
        return True
    name = p.rsplit("/", 1)[-1]
    # Bare `requirements` / `requirements-prod` etc. — name starts with
    # `requirements` and has no extension. `requirements.cfg` is rejected
    # because pip's own config file uses that name and may carry creds.
    return name.startswith("requirements") and "." not in name


class ServerAuditConfig(BaseModel):
    model_config = _FORBID
    host: str
    user: str
    key: Path
    checks: Literal["all"] | list[str] = "all"
    ioc_db: Path = Path("./src/agentsec/audit/ioc/")
    ssh_audit_log: Path = Path("./audit-log.jsonl")
    ssh_policy: Path = Path("./src/agentsec/audit/ssh_policy.yaml")
    native_audit_argv: list[str] = Field(
        default_factory=lambda: ["openclaw", "security", "audit", "--json"]
    )
    log_review: LogReviewConfig = Field(default_factory=LogReviewConfig)
    pip_lock_paths: list[str] = Field(default_factory=list)
    go_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("pip_lock_paths")
    @classmethod
    def _validate_pip_lock_paths(cls, v: list[str]) -> list[str]:
        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"pip_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar([p]) is not None:
                raise ValueError(
                    f"pip_lock_paths entry {p!r} contains shell metacharacter"
                )
            if not _has_allowed_suffix(p):
                raise ValueError(
                    f"pip_lock_paths entry {p!r} must end with one of "
                    "{requirements*, *.txt, *.lock, *.in} suffix"
                )
        return v

    @field_validator("go_lock_paths")
    @classmethod
    def _validate_go_lock_paths(cls, v: list[str]) -> list[str]:
        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"go_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar([p]) is not None:
                raise ValueError(
                    f"go_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if basename != "go.sum":
                raise ValueError(
                    f"go_lock_paths entry {p!r} basename must equal 'go.sum' "
                    "(backups / variants must be renamed before audit)"
                )
        return v

    cargo_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("cargo_lock_paths")
    @classmethod
    def _validate_cargo_lock_paths(cls, v: list[str]) -> list[str]:
        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"cargo_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar([p]) is not None:
                raise ValueError(
                    f"cargo_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if basename != "Cargo.lock":
                raise ValueError(
                    f"cargo_lock_paths entry {p!r} basename must equal 'Cargo.lock' "
                    "(case-sensitive; variants must be renamed before audit)"
                )
        return v

    maven_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("maven_lock_paths")
    @classmethod
    def _validate_maven_lock_paths(cls, v: list[str]) -> list[str]:
        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"maven_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar([p]) is not None:
                raise ValueError(
                    f"maven_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if not (
                basename.endswith(".txt")
                or basename.endswith(".list")
                or basename.endswith("-deps.txt")
                or basename.endswith("-list.txt")
                or basename == "dependency-list.txt"
            ):
                raise ValueError(
                    f"maven_lock_paths entry {p!r} basename must end with "
                    f".txt, .list, -deps.txt, -list.txt, or be 'dependency-list.txt'"
                )
        return v

    gem_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("gem_lock_paths")
    @classmethod
    def _validate_gem_lock_paths(cls, v: list[str]) -> list[str]:
        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"gem_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar([p]) is not None:
                raise ValueError(
                    f"gem_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if basename != "Gemfile.lock":
                raise ValueError(
                    f"gem_lock_paths entry {p!r} basename must equal 'Gemfile.lock' "
                    f"(strict, mirrors Cargo.lock convention)"
                )
        return v

    composer_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("composer_lock_paths")
    @classmethod
    def _validate_composer_lock_paths(cls, v: list[str]) -> list[str]:
        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"composer_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar([p]) is not None:
                raise ValueError(
                    f"composer_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if basename != "composer.lock":
                raise ValueError(
                    f"composer_lock_paths entry {p!r} basename must equal 'composer.lock' "
                    f"(strict, mirrors Cargo.lock/Gemfile.lock convention)"
                )
        return v


class OutputConfig(BaseModel):
    model_config = _FORBID
    dir: Path
    formats: list[Literal["markdown", "json"]] = Field(
        default_factory=lambda: ["markdown", "json"]
    )
    redactor_extra_patterns: Path | None = None


class AuthorizationConfig(BaseModel):
    model_config = _FORBID
    consent_file: Path = Path("./AUTHORIZATION.txt")
    target_marker_path: Path | None = None


class McpRealConfig(BaseModel):
    """Spec 7c.6 §4.1 — opt-in real-protocol MCP pipeline."""
    model_config = _FORBID
    suite: Path
    model: str | None = None
    concurrency: int = Field(default=3, ge=1)
    max_iterations: int = Field(default=10, ge=1)


class ScoringConfig(BaseModel):
    model_config = _FORBID
    severity_aggregation: Literal["worst", "weighted_mean"] = "worst"
    category_weights: dict[str, float] = Field(default_factory=dict)
    # Combined-score weights — sum need not equal 1; the scorer normalizes.
    # Stage F additions (not in spec §8.2 example); negatives would corrupt
    # the weighted average so we reject at parse time.
    weight_remote: float = Field(default=0.5, ge=0.0)
    weight_server: float = Field(default=0.5, ge=0.0)
    weight_mcp: float = Field(default=0.0, ge=0.0)


class OpenClawTargetConfig(BaseModel):
    model_config = _FORBID
    name: str
    remote: RemoteConfig | None = None
    server_audit: ServerAuditConfig | None = None
    mcp_real: McpRealConfig | None = None
    output: OutputConfig
    authorization: AuthorizationConfig = Field(default_factory=AuthorizationConfig)
    scoring: ScoringConfig = Field(default_factory=ScoringConfig)
    judge: JudgeConfig | None = None
    # Populated by `from_yaml`; needed so PluginJudge resolution can be
    # relative to the config file's directory rather than CWD.
    _config_path: Path | None = PrivateAttr(default=None)

    @model_validator(mode="after")
    def _at_least_one_half(self) -> OpenClawTargetConfig:
        if (
            self.remote is None
            and self.server_audit is None
            and self.mcp_real is None
        ):
            raise ValueError(
                "at least one of `remote` / `server_audit` / `mcp_real` "
                "must be configured"
            )
        return self

    @classmethod
    def from_yaml(cls, path: Path | str) -> OpenClawTargetConfig:
        path = Path(path)
        text = path.read_text(encoding="utf-8")
        data = yaml.safe_load(text)
        if not isinstance(data, dict):
            raise ValueError(
                f"{path}: config must be a YAML mapping, got {type(data).__name__}"
            )
        obj = cls.model_validate(data)
        object.__setattr__(obj, "_config_path", path)
        return obj


class TargetEntry(BaseModel):
    """Single target within a multi-evaluate config.

    Like OpenClawTargetConfig but `output` is optional; MultiTargetConfig
    resolves it to output_base/<name>/ when absent.
    """

    model_config = _FORBID
    name: str = Field(min_length=1)
    remote: RemoteConfig | None = None
    server_audit: ServerAuditConfig | None = None
    mcp_real: McpRealConfig | None = None
    output: OutputConfig | None = None
    authorization: AuthorizationConfig = Field(default_factory=AuthorizationConfig)
    scoring: ScoringConfig = Field(default_factory=ScoringConfig)
    judge: JudgeConfig | None = None

    @model_validator(mode="after")
    def _at_least_one_half(self) -> TargetEntry:
        if (
            self.remote is None
            and self.server_audit is None
            and self.mcp_real is None
        ):
            raise ValueError(
                f"target {self.name!r}: at least one of `remote` / "
                "`server_audit` / `mcp_real` must be configured"
            )
        return self

    def to_openclaw_config(
        self, output_base: Path, config_path: Path | None = None
    ) -> OpenClawTargetConfig:
        resolved = self.output or OutputConfig(dir=output_base / self.name)
        obj = OpenClawTargetConfig(
            name=self.name,
            remote=self.remote,
            server_audit=self.server_audit,
            mcp_real=self.mcp_real,
            output=resolved,
            authorization=self.authorization,
            scoring=self.scoring,
            judge=self.judge,
        )
        if config_path is not None:
            object.__setattr__(obj, "_config_path", config_path)
        return obj


class MultiTargetConfig(BaseModel):
    model_config = _FORBID
    output_base: Path
    max_parallel: int = Field(default=0, ge=0)
    targets: list[TargetEntry] = Field(min_length=1)

    @model_validator(mode="after")
    def _unique_names(self) -> MultiTargetConfig:
        names = [t.name for t in self.targets]
        seen: set[str] = set()
        dupes: set[str] = set()
        for n in names:
            (dupes if n in seen else seen).add(n)
        if dupes:
            raise ValueError(f"duplicate target names: {sorted(dupes)}")
        return self

    @classmethod
    def from_yaml(cls, path: Path | str) -> MultiTargetConfig:
        text = Path(path).read_text(encoding="utf-8")
        data = yaml.safe_load(text)
        if not isinstance(data, dict):
            raise ValueError(
                f"{path}: config must be a YAML mapping, got {type(data).__name__}"
            )
        return cls.model_validate(data)

    @property
    def effective_max_parallel(self) -> int:
        return self.max_parallel if self.max_parallel > 0 else len(self.targets)
