"""Global redactor — strips secrets before they reach reports / audit logs.

Patterns grouped per spec §6.2 (OE-AUD2-008): generic key=value, provider
tokens, and private-key/cert material. Stateless, pure function for testability.
"""

from __future__ import annotations

import re
from collections.abc import Iterable

DEFAULT_PATTERNS: list[tuple[str, str]] = [
    # Order matters: more-specific provider/private patterns run first so the
    # generic key=value catch-all doesn't preemptively replace e.g.
    # `ANTHROPIC_API_KEY=sk-ant-...` with `<REDACTED>` before we can label it.

    # ----- B. Provider tokens -----
    (r'\bsk-ant-[A-Za-z0-9_\-]{20,}\b', '<REDACTED ANTHROPIC KEY>'),
    (r'\bsk-(?:proj-)?[A-Za-z0-9_\-]{20,}\b', '<REDACTED OPENAI KEY>'),
    (r'\bAKIA[0-9A-Z]{16}\b', '<REDACTED AWS ACCESS KEY ID>'),
    # Spec §6.2 wrote `asia` lowercase; real AWS STS keys are uppercase ASIA — corrected here.
    (r'\bASIA[0-9A-Z]{16}\b', '<REDACTED AWS STS KEY ID>'),
    # AWS Secret Access Key (40 chars base64-ish). Bare 40-char values false-
    # positive on hashes / unrelated base64 data, so we anchor on a labelled
    # field name and only redact the value portion. Order matters: this must
    # run before the generic key/value catch-all so the AWS label wins.
    (
        r'(?i)(aws[_-]?secret[_-]?access[_-]?key["\']?\s*[:=]\s*["\']?)'
        r'([A-Za-z0-9/+=]{40})\b',
        r'\1<REDACTED AWS SECRET ACCESS KEY>',
    ),
    (r'\bghp_[A-Za-z0-9]{36}\b', '<REDACTED GITHUB PAT>'),
    (r'\bghs_[A-Za-z0-9]{36}\b', '<REDACTED GITHUB APP TOKEN>'),
    (r'\bgho_[A-Za-z0-9]{36}\b', '<REDACTED GITHUB OAUTH TOKEN>'),
    (r'\bghu_[A-Za-z0-9]{36}\b', '<REDACTED GITHUB USER-TO-SERVER TOKEN>'),
    (r'\bghr_[A-Za-z0-9]{36}\b', '<REDACTED GITHUB REFRESH TOKEN>'),
    # Fine-grained PAT: github_pat_<22 ID chars>_<59 secret chars>; 82 total
    # post-prefix, charset is alphanumeric + underscore.
    (r'\bgithub_pat_[A-Za-z0-9_]{82}\b', '<REDACTED GITHUB FINE-GRAINED PAT>'),
    (r'\bxox[abprs]-[A-Za-z0-9\-]{10,}\b', '<REDACTED SLACK TOKEN>'),
    (r'\b[MN][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27,}\b', '<REDACTED DISCORD TOKEN>'),
    (r'\b\d{8,10}:[A-Za-z0-9_-]{35,}\b', '<REDACTED TELEGRAM BOT TOKEN>'),
    (r'\bAIza[0-9A-Za-z_\-]{35,}', '<REDACTED GOOGLE API KEY>'),
    (r'(?i)Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Bearer <REDACTED>'),

    # ----- C. Private keys / certificates -----
    (
        r'-----BEGIN (?:RSA |OPENSSH |EC |DSA |ENCRYPTED |PGP )?PRIVATE KEY-----'
        r'[\s\S]*?-----END[\s\S]*?-----',
        '<REDACTED PRIVATE KEY>',
    ),
    (r'ssh-(?:rsa|ed25519|ecdsa-sha2-\w+)\s+[A-Za-z0-9+/=]{100,}', '<REDACTED SSH PUBLIC KEY>'),
    (r'\beyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]{10,}\b', '<REDACTED JWT>'),

    # ----- A. Generic key/value (KEY=VALUE | "key": "value" | key: value) -----
    # Catch-all — runs last so labelled provider redactions above survive.
    (
        r'(?i)(["\']?(?:api[_-]?key|access[_-]?key|secret(?:[_-]?key)?|password|passwd|token|auth[_-]?token|bot[_-]?token|client[_-]?secret|gateway[_-]?token|openclaw[_-]?token)["\']?\s*[:=]\s*)["\']?([A-Za-z0-9_\-\.\+/]{8,})["\']?',
        r'\1"<REDACTED>"',
    ),
]


class Redactor:
    def __init__(self, extra_patterns: Iterable[tuple[str, str]] | None = None):
        patterns = list(DEFAULT_PATTERNS) + list(extra_patterns or [])
        self._compiled: list[tuple[re.Pattern[str], str]] = [
            (re.compile(p), repl) for p, repl in patterns
        ]

    def redact(self, text: str) -> str:
        if not text:
            return text
        for pat, repl in self._compiled:
            text = pat.sub(repl, text)
        return text
