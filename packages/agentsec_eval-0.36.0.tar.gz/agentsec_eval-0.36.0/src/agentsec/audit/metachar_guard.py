"""Shell-metachar guard for the SSH command policy (spec §6.1).

Runs on the FINAL argv (after placeholder substitution, before render). Any
token containing a shell metacharacter is rejected. By design this rejects
useful-looking patterns like `grep -E "foo|bar"` (OE-AUD4-002): the trade-off
is that we never have to reason about whether `shlex.quote` would defang the
character once it's inside an exec_command string.
"""

from __future__ import annotations

_FORBIDDEN = ("|", "&", ";", "`", "$(", "<", ">", "\n")


def contains_shell_metachar(argv: list[str]) -> str | None:
    """Return None if all tokens are clean; else return a human-readable reason."""
    for i, tok in enumerate(argv):
        for bad in _FORBIDDEN:
            if bad in tok:
                return f"argv[{i}]={tok!r} contains forbidden shell metachar {bad!r}"
    return None
