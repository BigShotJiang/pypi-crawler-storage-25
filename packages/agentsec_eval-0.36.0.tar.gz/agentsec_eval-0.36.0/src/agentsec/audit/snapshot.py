"""SnapshotCollector — produces pre/post_state_snapshot for IsolationPolicy.

Schema: {"files": list[str], "config": dict[str, Any]}.
Stage D ships this module unwired. Stage E will call collect() before/after
each multi-turn / poisoning test from the runner.
"""

from __future__ import annotations

import json
import os
from typing import Any

from .ssh import SSHExecutor

ITEM_BUILDERS: dict[str, str] = {
    "memory_file": "files",
    "config": "config",
}


class SnapshotCollector:
    def __init__(self, executor: SSHExecutor, *, paths: dict[str, str]):
        self._executor = executor
        self._paths = paths

    def collect(self, *, items: list[str]) -> dict[str, Any]:
        snap: dict[str, Any] = {"files": [], "config": {}}
        for item in items:
            if item not in ITEM_BUILDERS:
                raise ValueError(f"unknown snapshot item: {item!r}")
            slot = ITEM_BUILDERS[item]
            if slot == "files":
                path = self._paths.get(item)
                if not path:
                    continue
                parent = os.path.dirname(path)
                name = os.path.basename(path)
                r = self._executor.run(["find", parent, "-name", name])
                if r.rejected or r.exit_code != 0:
                    continue
                for line in r.stdout.splitlines():
                    line = line.strip()
                    if line:
                        snap["files"].append(line)
            elif slot == "config":
                r = self._executor.run(["openclaw", "config", "show", "--json"])
                if r.rejected or r.exit_code != 0:
                    continue
                try:
                    snap["config"] = json.loads(r.stdout)
                except json.JSONDecodeError:
                    snap["config"] = {}
        return snap
