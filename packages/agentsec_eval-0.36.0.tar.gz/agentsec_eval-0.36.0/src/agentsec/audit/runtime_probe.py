"""Runtime probes that resolve target-specific runtime configuration.

Two responsibilities:
  - `resolve_openclaw_bin` (D1): the npm user-prefix install puts `openclaw`
    at `~/.npm-global/bin/openclaw`, but paramiko's non-login `exec_command`
    PATH does not include that. Probe a small set of candidates so checks
    can call the binary by absolute path.
  - `probe_systemd_user_mode` (D3): OpenClaw's documented deployment is
    `systemd --user`, not system-level. Probe for the user unit file so the
    orchestrator can swap to `LINUX_USER_MODE` before checks run.

All probes go through the policy-validated `SSHExecutor`, so the candidate
paths must already be allowed in `ssh_policy.yaml.allowed_paths`.
"""

from __future__ import annotations

from typing import Any

from .platform_profile import PlatformProfile

_LINUX_BIN_CANDIDATES: tuple[str, ...] = (
    "{home}/.npm-global/bin/openclaw",
    "/usr/local/bin/openclaw",
    "/usr/bin/openclaw",
)

_MACOS_BIN_CANDIDATES: tuple[str, ...] = (
    "/opt/homebrew/bin/openclaw",
    "/usr/local/bin/openclaw",
    "{home}/.npm-global/bin/openclaw",
)

_USER_UNIT_PROBE_PATH = "{home}/.config/systemd/user/openclaw-gateway.service"


def bin_candidates_for(profile: PlatformProfile, remote_home: str) -> list[str]:
    """Return the ordered candidate-path list for the given platform."""
    home = remote_home.rstrip("/")
    raw = _LINUX_BIN_CANDIDATES if profile.name == "linux" else _MACOS_BIN_CANDIDATES
    return [c.format(home=home) for c in raw]


def _stat_exists(executor: Any, path: str) -> bool:
    """Return True iff `stat -c '%a'` confirms `path` exists.

    Validates the response shape (an octal mode like ``755`` / ``0644``)
    rather than just exit code, so a permissive stub that returns empty or
    JSON-shaped stdout for unknown commands is not mistaken for a hit. The
    real `stat` always emits a numeric mode for a present file. Robust to
    unexpected transport failures.
    """
    try:
        result = executor.run(["stat", "-c", "%a", path])
    except Exception:
        return False
    if result.rejected or result.exit_code != 0:
        return False
    stdout = (result.stdout or "").strip()
    # Accept an octal mode token: 3-4 octal digits.
    return stdout.isdigit() and 3 <= len(stdout) <= 4


def resolve_openclaw_bin(executor: Any, profile: PlatformProfile, remote_home: str) -> str:
    """Probe candidates in order; return the first whose `stat` succeeds.

    Returns the bare string `"openclaw"` as a last resort — callers fall back
    to PATH lookup, which still fails on non-login shells but at least keeps
    the existing exit-127 behavior rather than masking the issue.
    """
    for candidate in bin_candidates_for(profile, remote_home):
        if _stat_exists(executor, candidate):
            return candidate
    return "openclaw"


def probe_systemd_user_mode(executor: Any, remote_home: str) -> bool:
    """Return True if the target uses systemd --user mode.

    Detected by presence of `~/.config/systemd/user/openclaw-gateway.service`,
    which is OpenClaw's documented user-mode deployment shape.
    """
    home = remote_home.rstrip("/")
    path = _USER_UNIT_PROBE_PATH.format(home=home)
    return _stat_exists(executor, path)
