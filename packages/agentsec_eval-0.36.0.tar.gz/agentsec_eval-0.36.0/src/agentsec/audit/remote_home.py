"""Resolve the remote SSH user's absolute $HOME without an extra round-trip.

Per ADR-0004, v0.2.0 uses a hardcoded convention table indexed by
PlatformProfile.name and the SSH login user. vNext may upgrade to a
dedicated `getent passwd` policy entry to support nonstandard homes.
"""

from __future__ import annotations

from .platform_profile import PlatformProfile

# Reject any user string whose substitution into the convention table would
# escape the intended /home (or /Users) prefix or smuggle shell control bytes
# downstream. paramiko also rejects most exotic strings during connect, but we
# fail fast here so a typo can't silently retarget every check at /etc/.openclaw/.
_FORBIDDEN_USER_CHARS = frozenset("/\\\n\r\t\0 ")


def _validate_user(user: str) -> None:
    if not user:
        raise ValueError("ssh user must be non-empty")
    if user[0] in (".", "~"):
        raise ValueError(f"ssh user must not start with {user[0]!r}: {user!r}")
    bad = sorted({c for c in user if c in _FORBIDDEN_USER_CHARS})
    if bad:
        raise ValueError(
            f"ssh user contains forbidden character(s) {bad!r}: {user!r}"
        )


def resolve_remote_home(user: str, profile: PlatformProfile) -> str:
    _validate_user(user)
    if profile.name == "linux":
        return "/root" if user == "root" else f"/home/{user}"
    if profile.name == "macos":
        return "/var/root" if user == "root" else f"/Users/{user}"
    raise ValueError(f"unsupported profile for home resolution: {profile.name!r}")
