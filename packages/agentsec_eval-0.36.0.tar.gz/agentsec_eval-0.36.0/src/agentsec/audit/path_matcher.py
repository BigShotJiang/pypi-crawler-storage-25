"""Boundary-aware path matching for SSH command policy (spec §6.1, OE-AUD4-001).

Three rule kinds: `prefix`, `exact`, `glob`. ALL kinds resolve the candidate
through expanduser → realpath before matching. Prefix matching uses
os.path.commonpath (NOT str.startswith) to prevent /tmp/openclaw2/secret
from sneaking past a /tmp/openclaw rule.
"""

from __future__ import annotations

import fnmatch
import logging
import os
from dataclasses import dataclass
from typing import Literal

logger = logging.getLogger(__name__)

PathRejectReason = str  # human-readable; None means "matched"


@dataclass(frozen=True)
class AllowedPath:
    kind: Literal["prefix", "exact", "glob"]
    path: str | None = None      # for prefix / exact
    pattern: str | None = None   # for glob


def _resolve(p: str) -> str:
    """Module-level resolver kept for any direct importers (thin wrapper)."""
    return os.path.realpath(os.path.expanduser(p))


def expand_tilde(path: str, remote_home: str | None) -> str:
    """Expand `~/foo` against `remote_home` if set; absolute paths and
    non-tilde paths pass through. Falls back to os.path.expanduser for
    `~user` syntax when no remote_home is given.

    Centralizes the tilde expansion logic used by both the CLI orchestrator
    (where remote_home is always known) and PathMatcher (where it may be
    None for local-mode use)."""
    if remote_home and path.startswith("~/"):
        return f"{remote_home.rstrip('/')}/{path[2:]}"
    return os.path.expanduser(path)


class PathMatcher:
    def __init__(self, rules: list[AllowedPath], *, remote_home: str | None = None):
        self._rules = rules
        self._remote_home = remote_home.rstrip("/") if remote_home else None
        for r in rules:
            if r.kind == "prefix":
                root = self._resolve(r.path or "")
                if not os.path.isdir(root):
                    logger.warning("ssh_policy: prefix root does not exist: %s", root)

    def _expanduser(self, p: str) -> str:
        return expand_tilde(p, self._remote_home)

    def _resolve(self, p: str) -> str:
        return os.path.realpath(self._expanduser(p))

    def matches(self, candidate: str) -> PathRejectReason | None:
        cand = self._resolve(candidate)
        for rule in self._rules:
            if self._try_rule(rule, candidate, cand) is None:
                return None
        return f"path {candidate!r} not in allowed_paths"

    def _try_rule(self, rule: AllowedPath, original: str, cand: str) -> PathRejectReason | None:
        if rule.kind == "exact":
            if cand == self._resolve(rule.path or ""):
                return None
            return f"not exact match for {rule.path}"
        if rule.kind == "prefix":
            root = self._resolve(rule.path or "")
            try:
                common = os.path.commonpath([root, cand])
            except ValueError:
                return f"different drives: {root} vs {cand}"
            if common == root:
                return None
            return f"not under prefix {root}"
        if rule.kind == "glob":
            pattern = rule.pattern or ""
            expanded_pattern = self._expanduser(pattern)
            if not fnmatch.fnmatch(original, expanded_pattern) and \
               not fnmatch.fnmatch(cand, expanded_pattern):
                return f"glob {pattern} does not match"
            parent = self._resolve(os.path.dirname(expanded_pattern))
            try:
                common = os.path.commonpath([parent, cand])
            except ValueError:
                return f"different drives for glob: {parent} vs {cand}"
            if common != parent:
                return f"glob realpath {cand} escapes parent {parent}"
            return None
        return f"unknown rule kind {rule.kind!r}"
