"""Per-command args-schema validation (spec §6.1).

Four role types in args_schema entries:
  - "flags": list of allowed/forbidden short/long flags. Flags listed in
            ``value_taking`` consume the next argv token as their value
            (e.g. ``-n 5`` for ``head``); without ``value_taking`` the
            value falls through to the next schema entry and gets matched
            as a positional path.
  - "positional": one positional arg with kind={path, pattern, container_id}
  - "predicate_pairs": (used by find) -name VALUE / -mtime VALUE pairs
  - "subcommand": consumes one positional token and validates it against an
                  ``allowed`` set (e.g. ``inspect`` for ``docker``)

Plus an alternative top-level form `allowed_argv: list[list[str]]` for
commands whose entire invocation is enumerated explicitly (uname, ps, etc.).

When both `allowed_argv` and `args_schema` are declared on the same
command, `allowed_argv` is tried first; if a fixed-form template matches,
validation short-circuits with success. Otherwise validation falls
through to `args_schema`. Used by Phase 7f's `docker:` block -- fixed-form
`version` / `info` / `ps` are listed in `allowed_argv`, and the
variable-shape `inspect <container_id>` is handled by `args_schema`.

When a schema entry has must_match_allowed_paths=True, the corresponding
token is checked through the PathMatcher.
"""

from __future__ import annotations

import re
from typing import Any

from .path_matcher import PathMatcher

_PLACEHOLDER_PATTERNS: dict[str, re.Pattern[str]] = {
    "<unit>":        re.compile(r"^[A-Za-z0-9._@-]{1,128}\.service$"),
    "<since>":       re.compile(r"^[1-9][0-9]{0,3} hours? ago$"),
    "<lines>":       re.compile(r"^[1-9][0-9]{1,5}$"),
    "<sysctl_key>":  re.compile(r"^[a-z][a-z0-9._]{0,127}$"),
}

_CONTAINER_ID_RE = re.compile(r"^[a-f0-9]{12,64}$")


def validate_args(
    command: str,
    argv: list[str],
    schema: dict[str, Any],
    matcher: PathMatcher | None,
) -> str | None:
    """Return None if argv satisfies the schema; else return a reason string."""
    if not schema:
        return f"command {command!r} not in policy"

    # Try allowed_argv first; if a fixed-form match exists, return None.
    if "allowed_argv" in schema:
        argv_reason = _check_allowed_argv(
            command, argv, schema["allowed_argv"], matcher,
        )
        if argv_reason is None:
            return None
        # Fall through to args_schema if both are declared.
        if "args_schema" not in schema:
            return argv_reason

    if "args_schema" in schema:
        return _check_args_schema(command, argv, schema["args_schema"], matcher)

    return f"policy entry for {command!r} has neither allowed_argv nor args_schema"


def _check_allowed_argv(
    command: str,
    argv: list[str],
    allowed: list[list[str]],
    matcher: PathMatcher | None,
) -> str | None:
    for template in allowed:
        if len(template) != len(argv):
            continue
        ok = True
        for tmpl_tok, real_tok in zip(template, argv, strict=True):
            if tmpl_tok == "<allowed_path>":
                if matcher is None or matcher.matches(real_tok) is not None:
                    ok = False
                    break
            elif tmpl_tok in _PLACEHOLDER_PATTERNS:
                if not _PLACEHOLDER_PATTERNS[tmpl_tok].fullmatch(real_tok):
                    ok = False
                    break
            elif tmpl_tok != real_tok:
                ok = False
                break
        if ok:
            return None
    return f"argv {argv!r} does not match any allowed_argv for {command!r}"


def _check_args_schema(
    command: str,
    argv: list[str],
    schema: list[dict[str, Any]],
    matcher: PathMatcher | None,
) -> str | None:
    if not argv or argv[0] != command:
        return f"argv[0]={argv[0]!r} does not match command {command!r}"
    rest = argv[1:]
    cursor = 0

    for entry in schema:
        role = entry.get("role")
        if role == "flags":
            allowed = set(entry.get("allowed", []))
            forbidden = set(entry.get("forbidden", []))
            value_taking = set(entry.get("value_taking", []))
            while cursor < len(rest) and rest[cursor].startswith("-"):
                tok = rest[cursor]
                if tok in forbidden:
                    return f"flag {tok!r} is forbidden for {command!r}"
                if tok not in allowed:
                    return f"flag {tok!r} is not in allowed list for {command!r}"
                cursor += 1
                if tok in value_taking:
                    # Consume the flag's value (e.g. "5" after "-n", "%y"
                    # after "-c"). Without this branch the value would
                    # fall through to the next schema entry and get
                    # matched as a positional path, producing a
                    # misleading "path '5' not in allowed_paths" reject.
                    if cursor >= len(rest):
                        return (
                            f"flag {tok!r} requires a value but argv ended for {command!r}"
                        )
                    cursor += 1
        # subcommand always requires one token; no `required: False` form
        # (added in Phase 7f for docker).
        elif role == "subcommand":
            allowed = set(entry.get("allowed", []))
            if cursor >= len(rest):
                return f"missing required subcommand for {command!r}"
            tok = rest[cursor]
            cursor += 1
            if tok not in allowed:
                return f"subcommand {tok!r} not in allowed list for {command!r}"
        elif role == "positional":
            if cursor >= len(rest):
                if entry.get("required", False):
                    return f"missing required positional for {command!r}"
                continue
            tok = rest[cursor]
            cursor += 1
            kind = entry.get("kind")
            if kind == "path" and entry.get("must_match_allowed_paths"):
                if matcher is None:
                    return "matcher required for path positional"
                reason = matcher.matches(tok)
                if reason is not None:
                    return reason
            elif kind == "container_id":
                if not _CONTAINER_ID_RE.fullmatch(tok):
                    return (
                        f"positional {tok!r} is not a valid container_id "
                        f"(expected 12-64 lowercase hex chars) for {command!r}"
                    )
        elif role == "predicate_pairs":
            allowed = set(entry.get("allowed_predicates", []))
            forbidden = set(entry.get("forbidden_predicates", []))
            while cursor < len(rest):
                pred = rest[cursor]
                if pred in forbidden:
                    return f"predicate {pred!r} is forbidden for {command!r}"
                if pred not in allowed:
                    return f"predicate {pred!r} is not allowed for {command!r}"
                cursor += 1
                if cursor >= len(rest):
                    return f"predicate {pred!r} missing value"
                cursor += 1  # consume the value
        else:
            return f"unknown args_schema role {role!r}"

    if cursor != len(rest):
        return f"unexpected trailing argv tokens: {rest[cursor:]!r}"
    return None
