"""PlatformProfile — Linux / macOS path & command differences (spec §6.3).

Profiles hold *logical* names → structured argv lists. A check that needs the
service-list command on the running platform uses
`ctx.profile.services["list"]` instead of branching on `sys.platform`.

Profiles are loaded once per server-audit run (see `detect_platform()` in this
module). On a platform whose profile lacks a logical name a check requires,
the check sets `ctx.status.not_applicable(...)` and returns `[]` — Stage F's
scorer drops `not_applicable` from the denominator (spec §9.1).
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

Argv = list[str]


class FileLogSource(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["files"] = "files"
    log_dir: str


class JournaldLogSource(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["journald"] = "journald"
    user: bool
    units: tuple[str, ...] = Field(min_length=1)


LogSource = Annotated[
    FileLogSource | JournaldLogSource,
    Field(discriminator="kind"),
]


class PlatformProfile(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: Literal["linux", "macos"]
    paths: dict[str, str]
    services: dict[str, list[Argv]]
    listening_check: list[Argv]
    log_source: LogSource | None = None


LINUX = PlatformProfile(
    name="linux",
    paths={
        "openclaw_home": "~/.openclaw/",
        "memory_file": "~/.openclaw/MEMORY.md",
        # Kept for transition only (v0.10.0 removes it — spec §3).
        # Canonical reading path is now log_source.log_dir.
        "log_dir": "/var/log/openclaw/",
        "systemd_unit": "/etc/systemd/system/openclaw.service",
        "skills_dir": "~/.openclaw/skills/",
        # Default bin path; bin_resolver overrides at orchestrator startup
        # if the binary lives elsewhere (npm user-prefix, /usr/local/bin, …).
        "openclaw_bin": "openclaw",
        "npm_root": "~/.npm-global/lib/node_modules/openclaw",
    },
    services={
        "list":   [["systemctl", "list-units", "--type=service", "openclaw.service"]],
        "status": [["systemctl", "status", "openclaw.service"]],
        "show":   [["systemctl", "show", "openclaw.service"]],
    },
    listening_check=[["ss", "-tlnp"], ["ss", "-ulnp"]],
    log_source=FileLogSource(log_dir="/var/log/openclaw/"),
)


# systemd --user mode variant (OpenClaw's documented deployment shape).
# Differs from LINUX only in service-management + log surface; openclaw_home
# and skills_dir are identical.
LINUX_USER_MODE = PlatformProfile(
    name="linux",
    paths={
        "openclaw_home": "~/.openclaw/",
        "memory_file": "~/.openclaw/MEMORY.md",
        # No log_dir in user-mode — logs go to journald, which log_review
        # does not yet read. Absence flips log_review to not_applicable.
        "systemd_unit": "~/.config/systemd/user/openclaw-gateway.service",
        "skills_dir": "~/.openclaw/skills/",
        "openclaw_bin": "openclaw",
        "npm_root": "~/.npm-global/lib/node_modules/openclaw",
    },
    services={
        "list":   [["systemctl", "--user", "list-units",
                    "--type=service", "openclaw-gateway.service"]],
        "status": [["systemctl", "--user", "status", "openclaw-gateway.service"]],
        "show":   [["systemctl", "--user", "show", "openclaw-gateway.service"]],
    },
    listening_check=[["ss", "-tlnp"], ["ss", "-ulnp"]],
    log_source=JournaldLogSource(
        user=True,
        units=("openclaw-gateway.service", "openclaw-node.service"),
    ),
)


MACOS = PlatformProfile(
    name="macos",
    paths={
        "openclaw_home": "~/Library/Application Support/openclaw/",
        "memory_file": "~/Library/Application Support/openclaw/MEMORY.md",
        # Kept for transition only (v0.10.0 removes it — spec §3).
        # Canonical reading path is now log_source.log_dir.
        "log_dir": "~/Library/Logs/openclaw/",
        "launch_daemon": "/Library/LaunchDaemons/ai.openclaw.gateway.plist",
        "skills_dir": "~/Library/Application Support/openclaw/skills/",
        "openclaw_bin": "openclaw",
    },
    services={
        "list":  [["launchctl", "list"]],
        "print": [["launchctl", "print", "system/ai.openclaw.gateway"]],
    },
    listening_check=[["lsof", "-i", "-n", "-P"]],
    log_source=FileLogSource(log_dir="~/Library/Logs/openclaw/"),
)


def detect_platform(uname_s_output: str) -> PlatformProfile:
    """Pick a profile from `uname -s` stdout. Caller is responsible for
    running `["uname", "-s"]` through the policy-allowed executor and passing
    the trimmed stdout. Anything other than Linux / Darwin raises.
    """
    s = uname_s_output.strip().lower()
    if s == "linux":
        return LINUX
    if s == "darwin":
        return MACOS
    raise ValueError(f"unsupported platform from uname: {uname_s_output!r}")


def materialize_paths(profile: PlatformProfile, remote_home: str) -> PlatformProfile:
    """Return a new profile whose `paths` have any leading `~/` replaced with
    `<remote_home>/`. Other fields pass through unchanged. Idempotent on
    profiles whose paths are already absolute."""
    home = remote_home.rstrip("/")

    def _expand(p: str) -> str:
        if p.startswith("~/"):
            return f"{home}/{p[2:]}"
        return p

    new_paths = {k: _expand(v) for k, v in profile.paths.items()}
    new_log_source = profile.log_source
    if isinstance(new_log_source, FileLogSource):
        new_log_source = FileLogSource(log_dir=_expand(new_log_source.log_dir))
    return PlatformProfile(
        name=profile.name,
        paths=new_paths,
        services=profile.services,
        listening_check=profile.listening_check,
        log_source=new_log_source,
    )
