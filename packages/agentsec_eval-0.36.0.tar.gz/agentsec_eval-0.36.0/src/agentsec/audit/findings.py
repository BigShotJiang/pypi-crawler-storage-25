"""Finding model — output of every server-audit check.

Per spec §9.2 the fingerprint = sha256(check + title + canonical(evidence_subset))
is used by the Stage F scoring layer to dedupe identical findings emitted by
different runs (or by different platforms in the CI matrix).
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Literal

from pydantic import BaseModel, Field, computed_field

Severity = Literal["critical", "high", "medium", "low", "info"]


class Finding(BaseModel):
    check: str
    severity: Severity
    title: str
    description: str
    evidence: dict[str, Any] = Field(default_factory=dict)
    remediation: str
    threat_refs: list[str] = Field(default_factory=list)

    @computed_field  # type: ignore[misc]
    @property
    def fingerprint(self) -> str:
        canonical_evidence = json.dumps(
            self.evidence, sort_keys=True, separators=(",", ":"), default=str,
        )
        material = f"{self.check}|{self.title}|{canonical_evidence}"
        return hashlib.sha256(material.encode("utf-8")).hexdigest()
