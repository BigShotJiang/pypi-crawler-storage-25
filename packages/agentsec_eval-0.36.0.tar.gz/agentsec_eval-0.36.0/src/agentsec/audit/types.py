"""Typed return values for the audit module.

Defined here (not on individual modules) so SSH, command policy, and check code
can share without circular imports.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RunResult:
    argv: list[str]
    command_sha256: str
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: float
    bytes_out: int
    rejected: bool
    reject_reason: str | None
