"""AUTHORIZATION.txt parser + validator (spec §6.4).

This file is the only thing standing between AgentSec and unauthorized
execution against a real OpenClaw deployment. Any change must keep the
canonicalization byte-for-byte consistent with the spec — a one-character
drift breaks every previously-signed AUTHORIZATION.txt in the wild.
"""

from __future__ import annotations

import base64
import hashlib
import hmac as _hmac
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field

SignatureMode = Literal["hmac_sha256", "none"]


class AuthorizationError(Exception):
    """Raised when AUTHORIZATION.txt is malformed, missing fields, or fails validation."""


class Authorization(BaseModel):
    target_host: str
    authorized_by: str
    identity_provider: str = ""
    identity_assertion: str = ""
    valid_from: datetime
    valid_until: datetime
    scope: list[str]
    report_output_path_prefix: str
    signature_mode: SignatureMode = "none"
    signature: str | None = None
    signature_key_env: str | None = None

    low_assurance: bool = Field(default=False, exclude=True)

    def compute_signature(self, key: bytes) -> str:
        msg = canonical_message(self).encode("utf-8")
        return base64.b64encode(_hmac.new(key, msg, hashlib.sha256).digest()).decode("ascii")

    def validate(
        self,
        *,
        target_host: str,
        report_output_path_prefix: str,
        required_scopes: list[str],
        now: datetime | None = None,
    ) -> None:
        """Run the seven-step chain from spec §6.4. Raises AuthorizationError on
        the first failing step. On success, sets self.low_assurance based on
        signature_mode and identity_assertion presence.

        Steps 1-2 (file readable, YAML parses) ran in `load()`; this method
        covers steps 3-7.
        """
        if self.target_host != target_host:
            raise AuthorizationError(
                f"target_host mismatch: AUTHORIZATION.txt={self.target_host!r}, "
                f"requested={target_host!r}"
            )
        now = now or datetime.now(UTC)
        if not (self.valid_from <= now <= self.valid_until):
            raise AuthorizationError(
                f"current time {now.isoformat()} outside valid window "
                f"[{self.valid_from.isoformat()}, {self.valid_until.isoformat()}]"
            )
        missing = [s for s in required_scopes if s not in self.scope]
        if missing:
            raise AuthorizationError(f"scope missing required capabilities: {missing}")
        # Path-equality compare so `./report-2026-04-27/` (the form documented
        # in AUTHORIZATION.txt.example and CLAUDE.md) matches the prefix the
        # CLI builds from a Path-typed --output flag, which normalizes away
        # `./` and the trailing slash.
        if Path(self.report_output_path_prefix) != Path(report_output_path_prefix):
            raise AuthorizationError(
                f"report_output_path_prefix mismatch: "
                f"AUTHORIZATION.txt={self.report_output_path_prefix!r}, "
                f"requested={report_output_path_prefix!r}"
            )
        if self.signature_mode == "hmac_sha256":
            if not self.signature_key_env:
                raise AuthorizationError(
                    "signature_mode=hmac_sha256 requires signature_key_env"
                )
            key_str = os.environ.get(self.signature_key_env)
            if not key_str:
                raise AuthorizationError(
                    f"env var {self.signature_key_env!r} for signing key is empty"
                )
            if not self.signature:
                raise AuthorizationError(
                    "signature_mode=hmac_sha256 requires signature field"
                )
            expected = self.compute_signature(key_str.encode("utf-8"))
            if not _hmac.compare_digest(expected, self.signature):
                raise AuthorizationError("signature does not match (HMAC verification failed)")

        self.low_assurance = (
            self.signature_mode == "none" or not self.identity_assertion
        )

    @classmethod
    def load(cls, path: Path | str) -> Authorization:
        p = Path(path)
        try:
            raw = p.read_text(encoding="utf-8")
        except OSError as e:
            raise AuthorizationError(f"cannot read {p}: {e}") from e
        try:
            data = yaml.safe_load(raw)
        except yaml.YAMLError as e:
            raise AuthorizationError(f"cannot parse {p} as YAML: {e}") from e
        if not isinstance(data, dict):
            raise AuthorizationError(f"{p}: top level must be a mapping")
        try:
            auth = cls.model_validate(data)
        except Exception as e:
            raise AuthorizationError(f"{p}: {e}") from e
        # Pydantic v2 leaves datetimes without a tz suffix naive; comparing
        # naive ↔ aware in validate() then raises a bare TypeError that the
        # CLI doesn't catch, so a missing `Z` would surface as a Python
        # stack trace instead of the friendly AuthorizationError every other
        # rejection branch produces. Reject early with a clear message.
        for field in ("valid_from", "valid_until"):
            value = getattr(auth, field)
            if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
                raise AuthorizationError(
                    f"{p}: {field} must include a UTC offset "
                    f"(e.g. 2026-04-27T00:00:00Z), got naive datetime "
                    f"{value.isoformat()}"
                )
        return auth


def canonical_message(auth: Authorization) -> str:
    """Build the canonical-form string for HMAC signing (spec §6.4).

    Field order is FIXED. Datetimes are serialized as ISO-8601 with explicit
    timezone offset (the spec uses 'Z' but datetime.isoformat() emits
    '+00:00'; both are equivalent and the spec's wording allows either as
    long as the implementation is consistent — we standardize on '+00:00'
    so all signatures verify against the same canonical bytes).
    """
    return "\n".join([
        auth.target_host,
        auth.authorized_by,
        auth.identity_provider,
        auth.identity_assertion,
        auth.valid_from.isoformat(),
        auth.valid_until.isoformat(),
        ",".join(sorted(auth.scope)),
        auth.report_output_path_prefix,
    ])
