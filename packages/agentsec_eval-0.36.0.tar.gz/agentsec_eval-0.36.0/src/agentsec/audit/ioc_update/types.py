"""Internal data shapes for the ioc-update pipeline (spec §6.1)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal

Source = Literal["nvd", "kev", "github_advisory"]
Confidence = Literal["high", "medium", "low"]


@dataclass(frozen=True)
class NormalizedRecord:
    """One CVE/advisory after raw → canonical normalization, before merge."""
    source: Source
    cve_id: str | None              # e.g. "CVE-2026-50012"; None if GHSA-only
    ghsa_id: str | None             # e.g. "GHSA-xxxx-xxxx-xxxx"; None if CVE
    url: str
    description: str                # raw description from feed (becomes seed claim)
    cvss: float | None
    cvss_source: Source | None
    affected_versions: list[str]    # PEP-440 specifier strings
    fixed_in: str | None
    kev: bool                       # KEV catalog flag (always known if KEV ok)


@dataclass
class CanonicalEntry:
    """A threat_intel.yaml entry in canonical form (spec §5.1 field order)."""
    id: str
    source: str
    url: str
    observed_at: str                # YYYY-MM-DD
    claim: str
    cvss: float | None = None
    cvss_source: str | None = None
    affected_versions: list[str] | str | None = None
    fixed_in: str | None = None
    kev: bool | None = None         # absent (None) if not in KEV; True if listed
    confidence: Confidence = "medium"
    mapped_tests: list[str] = field(default_factory=list)
    auto_refresh: bool | None = None  # absent (None) means default True
    note: str | None = None

    def with_updates(self, **kwargs) -> CanonicalEntry:
        from dataclasses import replace
        return replace(self, **kwargs)


class MergeState(str, Enum):  # noqa: UP042 — keep (str, Enum) mixin; StrEnum changes str() repr semantics across Python versions and breaks markdown rendering

    NEW = "new"
    REFRESH = "refresh"
    UNCHANGED = "unchanged"
    SKIP = "skip"


@dataclass
class MergeOutcome:
    state: MergeState
    entry: CanonicalEntry
    diff_fields: dict[str, tuple[object, object]] = field(default_factory=dict)
    # for SKIP entries that still got KEV-only refresh:
    kev_only_refresh: bool = False


@dataclass
class FetcherDegraded:
    """Reason for a fetcher returning empty / partial results."""
    fetcher: str
    reason: str
    http_status: int | None = None
    body_excerpt: str | None = None  # first 256 bytes
