"""Deterministic TI-id generation (spec §6.3)."""

from __future__ import annotations

from .types import NormalizedRecord
from .watchlist import WatchlistEntry


def mint_ti_id(entry: WatchlistEntry, record: NormalizedRecord) -> str:
    """Generate a stable TI-id from a watchlist entry + normalized record.

    Rules:
    - If record.cve_id present: TI-{ti_prefix}-CVE-{YEAR}-{SEQ}
    - Else if record.ghsa_id: TI-{ti_prefix}-{GHSA-...}
    - Else: ValueError
    """
    if record.cve_id:
        suffix = record.cve_id.removeprefix("CVE-")
        return f"TI-{entry.ti_prefix}-CVE-{suffix}"
    if record.ghsa_id:
        return f"TI-{entry.ti_prefix}-{record.ghsa_id}"
    raise ValueError("record has neither cve_id nor ghsa_id")
