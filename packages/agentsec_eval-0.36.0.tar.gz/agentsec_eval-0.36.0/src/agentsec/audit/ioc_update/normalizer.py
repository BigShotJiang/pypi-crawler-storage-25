"""Raw fetcher output → NormalizedRecord (spec §6.1, §6.4)."""

from __future__ import annotations

from .types import NormalizedRecord, Source


def normalize_nvd(raw: dict) -> NormalizedRecord:
    cve = raw.get("cve", {})
    cve_id = cve.get("id")
    descriptions = cve.get("descriptions") or []
    description = ""
    for d in descriptions:
        if d.get("lang") == "en":
            description = d.get("value", "")
            break

    cvss, cvss_src = _extract_cvss(cve)
    affected, fixed = _extract_versions(cve)

    return NormalizedRecord(
        source="nvd",
        cve_id=cve_id,
        ghsa_id=None,
        url=f"https://nvd.nist.gov/vuln/detail/{cve_id}" if cve_id else "",
        description=description,
        cvss=cvss,
        cvss_source=cvss_src,
        affected_versions=affected,
        fixed_in=fixed,
        kev=False,
    )


def _extract_cvss(cve: dict) -> tuple[float | None, Source | None]:
    metrics = cve.get("metrics") or {}
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        bucket = metrics.get(key) or []
        if bucket:
            score = bucket[0].get("cvssData", {}).get("baseScore")
            if isinstance(score, (int, float)):
                return float(score), "nvd"
    return None, None


def _extract_versions(cve: dict) -> tuple[list[str], str | None]:
    affected: list[str] = []
    fixed: str | None = None
    for cfg in cve.get("configurations", []) or []:
        for node in cfg.get("nodes", []) or []:
            for match in node.get("cpeMatch", []) or []:
                if not match.get("vulnerable"):
                    continue
                end_excl = match.get("versionEndExcluding")
                start_incl = match.get("versionStartIncluding")
                end_incl = match.get("versionEndIncluding")
                start_excl = match.get("versionStartExcluding")
                spec_parts: list[str] = []
                if start_incl:
                    spec_parts.append(f">={start_incl}")
                if start_excl:
                    spec_parts.append(f">{start_excl}")
                if end_excl:
                    spec_parts.append(f"<{end_excl}")
                    if fixed is None:
                        fixed = end_excl
                if end_incl:
                    spec_parts.append(f"<={end_incl}")
                if spec_parts:
                    affected.append(",".join(spec_parts))
    return affected, fixed


def normalize_kev(raw: dict) -> NormalizedRecord:
    cve_id = raw.get("cveID")
    return NormalizedRecord(
        source="kev",
        cve_id=cve_id,
        ghsa_id=None,
        url=f"https://nvd.nist.gov/vuln/detail/{cve_id}" if cve_id else "",
        description=raw.get("shortDescription", ""),
        cvss=None,
        cvss_source=None,
        affected_versions=[],
        fixed_in=None,
        kev=True,
    )


def normalize_ghsa(raw: dict) -> NormalizedRecord:
    ghsa_id = raw.get("ghsaId")
    cve_id = None
    for ident in raw.get("identifiers") or []:
        if ident.get("type") == "CVE":
            cve_id = ident.get("value")
            break
    return NormalizedRecord(
        source="github_advisory",
        cve_id=cve_id,
        ghsa_id=ghsa_id,
        url=raw.get("permalink", ""),
        description=raw.get("summary", ""),
        cvss=None,
        cvss_source=None,
        affected_versions=[],
        fixed_in=None,
        kev=False,
    )
