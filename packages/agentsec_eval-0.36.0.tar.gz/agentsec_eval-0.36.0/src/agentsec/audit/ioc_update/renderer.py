"""Three-artifact renderer (spec §5)."""

from __future__ import annotations

import json
from datetime import datetime

import yaml

from .merger import MergeReport
from .types import CanonicalEntry, FetcherDegraded, MergeState

_FIELD_ORDER = (
    "id",
    "source",
    "url",
    "observed_at",
    "claim",
    "cvss",
    "cvss_source",
    "affected_versions",
    "fixed_in",
    "kev",
    "confidence",
    "mapped_tests",
    "auto_refresh",
    "note",
)


class _QuotedStr(str):
    """yaml dump marker: render as single-quoted string."""


def _quoted_str_representer(dumper, data):
    return dumper.represent_scalar("tag:yaml.org,2002:str", str(data), style="'")


yaml.SafeDumper.add_representer(_QuotedStr, _quoted_str_representer)


def _entry_to_dict(e: CanonicalEntry) -> dict:
    out: dict = {}
    for fld in _FIELD_ORDER:
        v = getattr(e, fld)
        if v is None:
            continue
        if fld == "mapped_tests" and v == []:
            out[fld] = []
            continue
        if fld == "kev" and v is False:
            continue
        if fld == "auto_refresh" and v is None:
            continue  # already handled by `v is None: continue` above; defensive
        if fld == "affected_versions":
            if isinstance(v, list):
                out[fld] = [_QuotedStr(s) for s in v]
            else:
                out[fld] = _QuotedStr(v)
            continue
        if fld == "fixed_in" and isinstance(v, str):
            out[fld] = _QuotedStr(v)
            continue
        out[fld] = v
    return out


def render_proposed_yaml(entries: list[CanonicalEntry]) -> str:
    sorted_entries = sorted(entries, key=lambda e: e.id)
    docs = [_entry_to_dict(e) for e in sorted_entries]
    return yaml.dump(
        docs,
        Dumper=yaml.SafeDumper,
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
        width=10_000,
    )


def render_report_md(
    merge_report: MergeReport,
    watchlist_count: int,
    fetched_counts: dict[str, int],
    existing_count: int,
    feeds_degraded: list[FetcherDegraded],
    run_started: datetime,
    run_finished: datetime,
    proposed_yaml_sha: str,
    nvd_api_key_used: bool,
    github_token_used: bool,
    mode: str = "both",
    feeds: list[str] | None = None,
    offline: bool = False,
) -> str:
    feeds = feeds or list(fetched_counts.keys())
    after_count = len(merge_report.final_entries)
    status = "ok" if not feeds_degraded else "degraded"
    new_outcomes = sorted(
        [o for o in merge_report.outcomes.values() if o.state == MergeState.NEW],
        key=lambda o: o.entry.id,
    )
    refresh_outcomes = sorted(
        [o for o in merge_report.outcomes.values() if o.state == MergeState.REFRESH],
        key=lambda o: o.entry.id,
    )
    skip_outcomes = sorted(
        [o for o in merge_report.outcomes.values() if o.state == MergeState.SKIP],
        key=lambda o: o.entry.id,
    )

    parts: list[str] = []
    parts.append(f"# IoC 更新报告 —— {run_started.date().isoformat()}")
    parts.append("")
    feed_str = ", ".join(feeds)
    fetched_str = "、".join(f"{c} 条 {f.upper()} 记录" for f, c in fetched_counts.items())
    parts.append(
        f"**运行模式：** `{mode}`  |  **数据源：** `{feed_str}`  |  **状态：** `{status}`"
        + ("  |  **运行：** 离线（fixture 数据）" if offline else "")
    )
    parts.append(f"**Watchlist：** {watchlist_count} 条")
    parts.append(f"**本次拉取：** {fetched_str}")
    parts.append(f"**现有 TI：** {existing_count} 条 → 合并后：{after_count} 条")
    parts.append("")

    parts.append(f"## 🆕 新发现（{len(new_outcomes)}）")
    parts.append("")
    for o in new_outcomes:
        parts.append(_render_new_block(o))
    if not new_outcomes:
        parts.append("（无）")
    parts.append("")

    parts.append(f"## 🔄 已刷新（{len(refresh_outcomes)}）")
    parts.append("")
    for o in refresh_outcomes:
        parts.append(_render_refresh_block(o))
    if not refresh_outcomes:
        parts.append("（无）")
    parts.append("")

    parts.append(f"## ⏭️ 已跳过（auto_refresh: false）（{len(skip_outcomes)}）")
    parts.append("")
    for o in skip_outcomes:
        parts.append(_render_skip_block(o))
    if not skip_outcomes:
        parts.append("（无）")
    parts.append("")

    parts.append(f"## ⚠️ 降级数据源（{len(feeds_degraded)}）")
    parts.append("")
    if feeds_degraded:
        for d in feeds_degraded:
            line = f"- **{d.fetcher}**：{d.reason}"
            if d.http_status is not None:
                line += f"（HTTP {d.http_status}）"
            parts.append(line)
    else:
        parts.append("（无 —— 所有数据源均成功返回）")
    parts.append("")

    parts.append("## 审计元数据")
    parts.append("")
    parts.append(f"- **运行开始：** {run_started.isoformat()}")
    parts.append(f"- **运行结束：** {run_finished.isoformat()}")
    parts.append(f"- **使用 NVD API key：** {'是' if nvd_api_key_used else '否'}")
    parts.append(f"- **使用 GitHub token：** {'是' if github_token_used else '否'}")
    determinism_line = (
        f"- **确定性校验：** 稳定哈希 `sha256:{proposed_yaml_sha}` "
        f"（proposed-threat_intel.yaml）"
    )
    parts.append(determinism_line)
    parts.append("")
    return "\n".join(parts)


def _render_new_block(o) -> str:
    e = o.entry
    kev_tag = "  *(KEV 已收录)*" if e.kev else ""
    aff = e.affected_versions or "(未知)"
    if isinstance(aff, list):
        aff_str = "、".join(f"`{s}`" for s in aff)
    else:
        aff_str = f"`{aff}`"
    return (
        f"### {e.id}{kev_tag}\n"
        f"- **来源：** {e.source}\n"
        f"- **CVSS：** {e.cvss if e.cvss is not None else '未知'}\n"
        f"- **影响版本：** {aff_str}  |  **修复版本：** `{e.fixed_in or '未知'}`\n"
        f"- **描述：** \"{e.claim}\"\n"
        f"- **参考链接：** {e.url}\n"
    )


def _render_refresh_block(o) -> str:
    e = o.entry
    kev_only_tag = "  *(仅 KEV 状态刷新 —— auto_refresh: false)*" if o.kev_only_refresh else ""
    rows = ["| 字段 | 旧值 | 新值 |", "|------|------|------|"]
    for k, (old, new) in sorted(o.diff_fields.items()):
        rows.append(f"| `{k}` | {old!r} | {new!r} |")
    table = "\n".join(rows)
    return (
        f"### {e.id}{kev_only_tag}\n"
        f"{table}\n"
        f"*(原有 claim、confidence、mapped_tests、note 已保留。)*\n"
    )


def _render_skip_block(o) -> str:
    e = o.entry
    return f"- `{e.id}` —— auto_refresh: false，已锁定手工值。\n"


def render_audit_log(events: list[dict]) -> str:
    return "\n".join(json.dumps(ev, separators=(",", ":"), sort_keys=True) for ev in events) + "\n"
