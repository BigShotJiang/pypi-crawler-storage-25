"""Operator-maintained watchlist of vendor / product entries (spec §4)."""

from __future__ import annotations

import re
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, ValidationError, field_validator

_TI_PREFIX_RE = re.compile(r"^[A-Z0-9][A-Z0-9-]*$")


class WatchlistError(ValueError):
    """Raised when watchlist.yaml fails to parse or validate."""


class GHSAPackage(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ecosystem: str
    name: str


class WatchlistEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ti_prefix: str
    vendor: str
    product: str
    cpe_pattern: str | None = None
    aliases: list[str] = []
    ghsa_packages: list[GHSAPackage] = []
    cve_db_include: bool = False

    @field_validator("ti_prefix")
    @classmethod
    def _ti_prefix_uppercase_alnum_dash(cls, v: str) -> str:
        if not _TI_PREFIX_RE.match(v):
            raise ValueError(
                f"ti_prefix must match {_TI_PREFIX_RE.pattern!r}, got {v!r}"
            )
        return v


def load_watchlist(path: Path) -> list[WatchlistEntry]:
    """Load and validate watchlist YAML. Raises WatchlistError on failure."""
    raw = yaml.safe_load(path.read_text()) or []
    if not isinstance(raw, list):
        raise WatchlistError(
            f"{path}: top level must be a list, got {type(raw).__name__}"
        )
    out: list[WatchlistEntry] = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise WatchlistError(f"{path}[{i}]: entry must be a mapping")
        try:
            out.append(WatchlistEntry(**item))
        except ValidationError as e:
            raise WatchlistError(f"{path}[{i}]: {e}") from e
    return out
