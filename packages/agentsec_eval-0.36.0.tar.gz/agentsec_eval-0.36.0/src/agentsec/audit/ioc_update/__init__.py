"""ioc-update — automated CVE / threat-intel feed pull (spec §1)."""
