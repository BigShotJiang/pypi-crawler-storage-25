"""NVD CVE API 2.0 fetcher (spec §7.2)."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

import httpx

from ..watchlist import WatchlistEntry
from .base import (
    Fetcher,
    FetcherContext,
    FetchResult,
    OfflineFixtureNotFound,
    hash_response,
    read_offline_fixture,
)

NVD_BASE = "https://services.nvd.nist.gov/rest/json/cves/2.0"

# 4 retries → 5 total attempts (initial + 4 backoffs)
RETRY_BACKOFFS = [1, 2, 4, 8]


class NVDFetcher(Fetcher):
    """Async fetcher for the NVD CVE API 2.0."""

    name = "nvd"
    _client_factory: Callable[[], httpx.AsyncClient]

    def __init__(self) -> None:
        self._client_factory = lambda: httpx.AsyncClient(
            timeout=httpx.Timeout(connect=10, read=30, write=10, pool=10),
        )
        self._sleep = asyncio.sleep

    async def run(
        self,
        ctx: FetcherContext,
        entries: list[WatchlistEntry],
    ) -> dict[str, FetchResult]:
        results: dict[str, FetchResult] = {}
        for entry in entries:
            results[entry.ti_prefix] = await self._fetch_one(ctx, entry)
        return results

    async def _fetch_one(
        self,
        ctx: FetcherContext,
        entry: WatchlistEntry,
    ) -> FetchResult:
        if ctx.offline:
            return self._read_offline(ctx, entry)

        throttle = 0.6 if ctx.nvd_api_key else 6.0
        params = self._build_params(entry)
        headers = self._build_headers(ctx)

        last_result: FetchResult | None = None

        for attempt, backoff in enumerate([0, *RETRY_BACKOFFS]):
            # On attempt 0: throttle delay. On retries: backoff delay.
            sleep_secs = throttle if attempt == 0 else backoff
            await self._sleep(sleep_secs)

            try:
                async with self._client_factory() as client:
                    response = await client.get(NVD_BASE, params=params, headers=headers)
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                last_result = FetchResult.from_degraded(
                    reason=f"transport error: {exc}",
                    fetcher=self.name,
                )
                continue

            if response.status_code == 200:
                body = response.content
                sha = hash_response(body)
                data: dict[str, Any] = response.json()
                vulns: list[dict] = data.get("vulnerabilities", [])
                return FetchResult.ok(
                    records=vulns,
                    http_status=200,
                    response_sha256=sha,
                )
            elif response.status_code == 429 or response.status_code >= 500:
                last_result = FetchResult.from_degraded(
                    reason=f"HTTP {response.status_code}",
                    fetcher=self.name,
                    http_status=response.status_code,
                )
                # continue to next retry
            else:
                # 4xx non-429: no retry
                excerpt = response.text[:256]
                return FetchResult.from_degraded(
                    reason=f"HTTP {response.status_code} (no retry)",
                    fetcher=self.name,
                    http_status=response.status_code,
                    body_excerpt=excerpt,
                )

        # All retries exhausted
        if last_result is not None:
            return last_result
        return FetchResult.from_degraded(
            reason="retries exhausted",
            fetcher=self.name,
        )

    def _read_offline(
        self,
        ctx: FetcherContext,
        entry: WatchlistEntry,
    ) -> FetchResult:
        if ctx.fixture_dir is None:
            return FetchResult.from_degraded(
                reason="offline mode requires fixture_dir",
                fetcher=self.name,
            )
        try:
            payload: dict[str, Any] = read_offline_fixture(
                ctx.fixture_dir, "nvd", entry.vendor
            )
        except OfflineFixtureNotFound:
            return FetchResult.ok(records=[])
        return FetchResult.ok(records=payload.get("vulnerabilities", []))

    @staticmethod
    def _build_params(entry: WatchlistEntry) -> dict[str, str]:
        if entry.cpe_pattern:
            # NVD's `cpeName` requires a fully-qualified CPE 2.3 name without
            # wildcards; watchlist patterns end in `:*` and must use
            # `virtualMatchString`, the documented partial-match parameter.
            return {"virtualMatchString": entry.cpe_pattern, "resultsPerPage": "200"}
        terms = [entry.vendor, entry.product] + list(entry.aliases)
        return {"keywordSearch": " ".join(terms), "resultsPerPage": "200"}

    @staticmethod
    def _build_headers(ctx: FetcherContext) -> dict[str, str]:
        headers: dict[str, str] = {"User-Agent": ctx.user_agent}
        if ctx.nvd_api_key:
            headers["apiKey"] = ctx.nvd_api_key
        return headers
