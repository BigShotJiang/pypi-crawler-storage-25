"""OSV-npm full ecosystem fetcher (Phase 7d).

Pulls https://osv-vulnerabilities.storage.googleapis.com/npm/all.zip
and normalizes the included OSV entries to the compact schema
consumed by SupplyChainAuditCheck. Differs from per-watchlist
fetchers (NVD/KEV/GHSA) in shape — emits a single FetchResult
keyed under '_osv_npm_full' rather than per-entry results.

Bundle-size filter (two-axis, 797f471 follow-up):
  1. Drop entries with no CVSS score — the OSV "unscored → medium" bucket
     was ~190K of the 208K total; operators can't act on them anyway.
  2. For scored medium/low: use 'published' (stable) not 'modified'
     (OSV refreshes modified timestamps constantly, defeating age filters).
  Critical/high are always kept regardless of age.
"""

from __future__ import annotations

import asyncio
import io
import json
import zipfile
from collections.abc import Callable

import httpx

from ..watchlist import WatchlistEntry
from ._supply_chain_common import (
    MEDIUM_LOW_MAX_AGE_DAYS,
    _extract_severity,
    _is_within_age,
)
from .base import Fetcher, FetcherContext, FetchResult, hash_response

OSV_NPM_URL = "https://osv-vulnerabilities.storage.googleapis.com/npm/all.zip"
RETRY_BACKOFFS = [2, 4, 8]
_HTTP_TIMEOUT = 60  # seconds; the zip is ~10 MB and gcs is fast


def _extract_semver_ranges(ranges: list[dict]) -> list[dict]:
    """Convert OSV 'ranges' (events: [{introduced}, {fixed}, ...])
    into our compact form [{'introduced': '0', 'fixed': '4.17.21'}].
    """
    out: list[dict] = []
    for r in ranges:
        if r.get("type") not in ("SEMVER", "ECOSYSTEM"):
            continue
        intro: str | None = None
        fixed: str | None = None
        last: str | None = None
        for ev in r.get("events", []):
            if "introduced" in ev:
                intro = ev["introduced"]
            elif "fixed" in ev:
                fixed = ev["fixed"]
            elif "last_affected" in ev:
                last = ev["last_affected"]
        if intro is None and fixed is None and last is None:
            continue
        entry: dict[str, str] = {}
        if intro is not None:
            entry["introduced"] = intro
        if fixed is not None:
            entry["fixed"] = fixed
        if last is not None:
            entry["last_affected"] = last
        out.append(entry)
    return out


def normalize_osv_entry(osv_entry: dict) -> list[dict] | None:
    """Return [compact-schema dict, ...], one per npm affected pkg, or
    None if filtered out by bundle-size policy.

    Pre-fix: returned a single dict from affected_npm[0]; multi-pkg
    advisories were truncated. Post-fix: each affected npm package
    expands to its own record (mirrors osv_pypi behavior).

    Filter rules (Phase 7d, revised after 797f471):
      - withdrawn → drop
      - no npm affected → drop
      - no semver range → drop (per-pkg; if no pkg has any range, return None)
      - no CVSS scoring at all → drop (operator can't act on unscored;
        avoids ~190K noise entries in OSV's default-medium bucket)
      - severity in {medium, low} AND published > MEDIUM_LOW_MAX_AGE_DAYS old → drop
        (use 'published' — stable; 'modified' is refreshed by OSV constantly)
      - else → keep
    """
    if osv_entry.get("withdrawn"):
        return None
    affected_npm = [
        a
        for a in osv_entry.get("affected", [])
        if (a.get("package") or {}).get("ecosystem") == "npm"
    ]
    if not affected_npm:
        return None

    severity, had_cvss = _extract_severity(osv_entry.get("severity", []))
    if not had_cvss:
        return None  # drop unscored: avoids ~190K noise entries
    # Age filter — only for medium/low. Critical/high always kept.
    # Prefer 'published' (stable); fall back to 'modified' when absent.
    if severity in ("medium", "low") and not _is_within_age(
        osv_entry.get("published", "") or osv_entry.get("modified", ""),
        MEDIUM_LOW_MAX_AGE_DAYS,
    ):
        return None

    out: list[dict] = []
    for aff in affected_npm:
        ranges = _extract_semver_ranges(aff.get("ranges", []))
        if not ranges:
            continue
        pkg = aff["package"]["name"]
        out.append({
            "id": osv_entry["id"],
            "package": pkg,
            "ranges": ranges,
            "severity": severity,
            "summary": osv_entry.get("summary", "")[:200],
            "url": f"https://github.com/advisories/{osv_entry['id']}",
            "aliases": osv_entry.get("aliases", []),
        })
    return out if out else None


class OsvNpmFetcher(Fetcher):
    """Single-source full-ecosystem fetcher for OSV-npm.

    Doesn't take per-entry watchlist input — npm is a single ecosystem
    and we pull everything in one shot. Returns a single FetchResult
    keyed under '_osv_npm_full' for the cli.py orchestrator.
    """

    name = "osv_npm"
    _client_factory: Callable[[], httpx.AsyncClient]

    def __init__(self) -> None:
        self._client_factory = lambda: httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=10, read=_HTTP_TIMEOUT, write=10, pool=10
            ),
        )
        self._sleep = asyncio.sleep

    async def run(
        self,
        ctx: FetcherContext,
        entries: list[WatchlistEntry],  # ignored — full ecosystem fetch
    ) -> dict[str, FetchResult]:
        if ctx.offline:
            return {
                "_osv_npm_full": FetchResult.from_degraded(
                    reason="offline mode without OSV-npm fixture support",
                    fetcher=self.name,
                )
            }
        try:
            return await self._fetch_and_normalize(ctx)
        except (httpx.HTTPError, zipfile.BadZipFile) as e:
            return {
                "_osv_npm_full": FetchResult.from_degraded(
                    reason=f"OSV-npm fetch failed: {e}",
                    fetcher=self.name,
                )
            }

    async def _fetch_and_normalize(
        self, ctx: FetcherContext
    ) -> dict[str, FetchResult]:
        body: bytes | None = None
        last_status: int | None = None
        async with self._client_factory() as client:
            for delay in [0, *RETRY_BACKOFFS]:
                if delay:
                    await self._sleep(delay)
                resp = await client.get(
                    OSV_NPM_URL, headers={"User-Agent": ctx.user_agent}
                )
                last_status = resp.status_code
                if resp.status_code == 200:
                    body = resp.content
                    break
        if body is None:
            return {
                "_osv_npm_full": FetchResult.from_degraded(
                    reason="OSV-npm: all retries exhausted",
                    fetcher=self.name,
                    http_status=last_status,
                )
            }

        normalized: list[dict] = []
        seen_keys: set[tuple[str, str]] = set()
        with zipfile.ZipFile(io.BytesIO(body)) as zf:
            for name in zf.namelist():
                if not name.endswith(".json"):
                    continue
                try:
                    raw = json.loads(zf.read(name))
                except (json.JSONDecodeError, KeyError):
                    continue
                norm = normalize_osv_entry(raw)
                if norm is None:
                    continue
                for rec in norm:
                    key = (rec["id"], rec["package"])
                    if key in seen_keys:
                        continue
                    seen_keys.add(key)
                    normalized.append(rec)
        normalized.sort(key=lambda x: (x["id"], x["package"]))
        return {
            "_osv_npm_full": FetchResult.ok(
                records=normalized,
                http_status=200,
                response_sha256=hash_response(body),
                raw_record_count=len(normalized),
            ),
        }
