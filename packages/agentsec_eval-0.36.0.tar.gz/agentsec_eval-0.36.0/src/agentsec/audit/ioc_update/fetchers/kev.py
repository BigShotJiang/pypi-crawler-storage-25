"""CISA Known-Exploited-Vulnerabilities catalog fetcher (spec §7.2)."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

import httpx

from ..watchlist import WatchlistEntry
from .base import (
    Fetcher,
    FetcherContext,
    FetchResult,
    OfflineFixtureNotFound,
    hash_response,
    read_offline_fixture,
)

KEV_URL = (
    "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
)

# [2, 4, 8] — no first-attempt throttle since KEV is one global GET
RETRY_BACKOFFS = [2, 4, 8]


class KEVFetcher(Fetcher):
    """Async fetcher for the CISA KEV catalog (single-URL, ~1 MB JSON download)."""

    name = "kev"
    _client_factory: Callable[[], httpx.AsyncClient]

    def __init__(self) -> None:
        self._client_factory = lambda: httpx.AsyncClient(
            timeout=httpx.Timeout(connect=10, read=60, write=10, pool=10),
        )
        self._sleep = asyncio.sleep

    async def run(
        self,
        ctx: FetcherContext,
        entries: list[WatchlistEntry],
    ) -> dict[str, FetchResult]:
        if ctx.offline:
            result = self._read_offline(ctx)
        else:
            result = await self._fetch(ctx)
        # All entries share the same FetchResult; merger filters by CVE id later.
        return {entry.ti_prefix: result for entry in entries}

    async def _fetch(self, ctx: FetcherContext) -> FetchResult:
        headers = {"User-Agent": ctx.user_agent}
        last_result: FetchResult | None = None

        for backoff in [0, *RETRY_BACKOFFS]:
            if backoff:
                await self._sleep(backoff)

            try:
                async with self._client_factory() as client:
                    response = await client.get(KEV_URL, headers=headers)
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                last_result = FetchResult.from_degraded(
                    reason=f"transport error: {exc}",
                    fetcher=self.name,
                )
                continue

            if response.status_code == 200:
                body = response.content
                sha = hash_response(body)
                data: dict[str, Any] = response.json()
                vulns: list[dict] = data.get("vulnerabilities", [])
                return FetchResult.ok(
                    records=vulns,
                    http_status=200,
                    response_sha256=sha,
                )
            elif response.status_code >= 500:
                last_result = FetchResult.from_degraded(
                    reason=f"HTTP {response.status_code}",
                    fetcher=self.name,
                    http_status=response.status_code,
                )
                # continue to next retry
            else:
                # 4xx: no retry
                excerpt = response.text[:256]
                return FetchResult.from_degraded(
                    reason=f"HTTP {response.status_code} (no retry)",
                    fetcher=self.name,
                    http_status=response.status_code,
                    body_excerpt=excerpt,
                )

        # All retries exhausted
        if last_result is not None:
            return last_result
        return FetchResult.from_degraded(
            reason="retries exhausted",
            fetcher=self.name,
        )

    def _read_offline(self, ctx: FetcherContext) -> FetchResult:
        if ctx.fixture_dir is None:
            return FetchResult.from_degraded(
                reason="offline mode requires fixture_dir",
                fetcher=self.name,
            )
        try:
            payload: dict[str, Any] = read_offline_fixture(
                ctx.fixture_dir, "kev", "catalog"
            )
        except OfflineFixtureNotFound:
            # KEV missing is a real failure — the catalog is mandatory
            return FetchResult.from_degraded(
                reason="offline fixture not found: kev/catalog.json",
                fetcher=self.name,
            )
        return FetchResult.ok(records=payload.get("vulnerabilities", []))
