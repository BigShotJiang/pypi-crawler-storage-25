"""OSV-Cargo full ecosystem fetcher (Phase 7d.3).

Pulls https://osv-vulnerabilities.storage.googleapis.com/crates.io/all.zip
and normalizes the included OSV entries to the compact schema
consumed by RustSupplyChainAuditCheck. Returns a single FetchResult
keyed under '_osv_cargo_full' for the cli.py orchestrator.
"""

from __future__ import annotations

import asyncio
import io
import json
import zipfile
from collections.abc import Callable

import httpx

from ..watchlist import WatchlistEntry
from ._supply_chain_common import (
    MEDIUM_LOW_MAX_AGE_DAYS,
    _extract_severity,
    _is_within_age,
)
from .base import Fetcher, FetcherContext, FetchResult, hash_response

OSV_CARGO_URL = (
    "https://osv-vulnerabilities.storage.googleapis.com/crates.io/all.zip"
)
RETRY_BACKOFFS = [2, 4, 8]
_HTTP_TIMEOUT = 60


def _extract_cargo_ranges(ranges: list[dict]) -> list[dict]:
    """OSV-Cargo uses ECOSYSTEM type with strict semver 2.0 strings."""
    out: list[dict] = []
    for r in ranges:
        if r.get("type") not in ("SEMVER", "ECOSYSTEM"):
            continue
        intro: str | None = None
        fixed: str | None = None
        last: str | None = None
        for ev in r.get("events", []):
            if "introduced" in ev:
                intro = ev["introduced"]
            elif "fixed" in ev:
                fixed = ev["fixed"]
            elif "last_affected" in ev:
                last = ev["last_affected"]
        if intro is None and fixed is None and last is None:
            continue
        entry: dict[str, str] = {}
        if intro is not None:
            entry["introduced"] = intro
        if fixed is not None:
            entry["fixed"] = fixed
        if last is not None:
            entry["last_affected"] = last
        out.append(entry)
    return out


def normalize_osv_cargo_entry(osv_entry: dict) -> list[dict] | None:
    """Return [compact-schema dict, ...] (one per crates.io affected pkg),
    or None if the entry is unusable / filtered out by bundle-size policy.

    Filter rules (5 axes): withdrawn, no-crates.io-affected, no-range, no-CVSS,
    medium/low > 2 years old.
    """
    if osv_entry.get("withdrawn"):
        return None
    affected_cargo = [
        a for a in osv_entry.get("affected", [])
        if (a.get("package") or {}).get("ecosystem") == "crates.io"
    ]
    if not affected_cargo:
        return None

    severity, had_cvss = _extract_severity(osv_entry.get("severity", []))
    if not had_cvss:
        return None

    if severity in ("medium", "low") and not _is_within_age(
        osv_entry.get("published", "") or osv_entry.get("modified", ""),
        MEDIUM_LOW_MAX_AGE_DAYS,
    ):
        return None

    out: list[dict] = []
    for aff in affected_cargo:
        ranges = _extract_cargo_ranges(aff.get("ranges", []))
        if not ranges:
            continue
        pkg = aff["package"]["name"]
        out.append({
            "id": osv_entry["id"],
            "package": pkg,
            "ranges": ranges,
            "severity": severity,
            "summary": osv_entry.get("summary", "")[:200],
            "url": f"https://github.com/advisories/{osv_entry['id']}",
            "aliases": osv_entry.get("aliases", []),
        })
    return out if out else None


class OsvCargoFetcher(Fetcher):
    """Single-source full-ecosystem fetcher for OSV-Cargo.

    Doesn't take per-entry watchlist input — crates.io is one ecosystem
    and we pull everything in one shot. Returns a single FetchResult
    keyed under '_osv_cargo_full' for cli.py orchestration.
    """

    name = "osv_cargo"
    _client_factory: Callable[[], httpx.AsyncClient]

    def __init__(self) -> None:
        self._client_factory = lambda: httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=10, read=_HTTP_TIMEOUT, write=10, pool=10,
            ),
        )
        self._sleep = asyncio.sleep

    async def run(
        self,
        ctx: FetcherContext,
        entries: list[WatchlistEntry],   # ignored — full ecosystem fetch
    ) -> dict[str, FetchResult]:
        if ctx.offline:
            return {
                "_osv_cargo_full": FetchResult.from_degraded(
                    reason="offline mode without OSV-Cargo fixture support",
                    fetcher=self.name,
                )
            }
        try:
            return await self._fetch_and_normalize(ctx)
        except (httpx.HTTPError, zipfile.BadZipFile) as e:
            return {
                "_osv_cargo_full": FetchResult.from_degraded(
                    reason=f"OSV-Cargo fetch failed: {e}",
                    fetcher=self.name,
                )
            }

    async def _fetch_and_normalize(
        self, ctx: FetcherContext,
    ) -> dict[str, FetchResult]:
        body: bytes | None = None
        last_status: int | None = None
        async with self._client_factory() as client:
            for delay in [0, *RETRY_BACKOFFS]:
                if delay:
                    await self._sleep(delay)
                resp = await client.get(
                    OSV_CARGO_URL, headers={"User-Agent": ctx.user_agent},
                )
                last_status = resp.status_code
                if resp.status_code == 200:
                    body = resp.content
                    break
        if body is None:
            return {
                "_osv_cargo_full": FetchResult.from_degraded(
                    reason="OSV-Cargo: all retries exhausted",
                    fetcher=self.name,
                    http_status=last_status,
                )
            }

        normalized: list[dict] = []
        seen_keys: set[tuple[str, str]] = set()
        with zipfile.ZipFile(io.BytesIO(body)) as zf:
            for name in zf.namelist():
                if not name.endswith(".json"):
                    continue
                try:
                    raw = json.loads(zf.read(name))
                except (json.JSONDecodeError, KeyError):
                    continue
                norm = normalize_osv_cargo_entry(raw)
                if norm is None:
                    continue
                for rec in norm:
                    key = (rec["id"], rec["package"])
                    if key in seen_keys:
                        continue
                    seen_keys.add(key)
                    normalized.append(rec)
        normalized.sort(key=lambda x: (x["id"], x["package"]))
        return {
            "_osv_cargo_full": FetchResult.ok(
                records=normalized,
                http_status=200,
                response_sha256=hash_response(body),
                raw_record_count=len(normalized),
            ),
        }
