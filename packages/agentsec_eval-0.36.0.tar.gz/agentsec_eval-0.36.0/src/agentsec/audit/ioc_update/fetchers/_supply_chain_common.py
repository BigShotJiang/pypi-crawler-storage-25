"""Shared OSV bundle filter / severity helpers used by all 3 ecosystem fetchers.

Extracted in Phase 7d.2 (rule of three: npm + pip + go all need the same
CVSS scoring, age filter, severity-list parser, and 2-year cutoff constant).
"""

from __future__ import annotations

from typing import Literal

Severity = Literal["critical", "high", "medium", "low"]

MEDIUM_LOW_MAX_AGE_DAYS = 2 * 365


def severity_from_cvss_score(score: float | None) -> Severity:
    """CVSS v3 base-score → AgentSec severity label.

    None → 'medium' (conservative; not 'low' so unscored entries aren't
    underreported).
    """
    if score is None:
        return "medium"
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    return "low"


def _parse_cvss_score(vector: str) -> float | None:
    """Parse a CVSS v3 vector string and return the base score.

    Returns None on any parse failure (cvss lib raises various opaque errors).
    """
    try:
        from cvss import CVSS3  # noqa: PLC0415
        c = CVSS3(vector)
        return float(c.base_score) if c.base_score is not None else None
    except Exception:  # noqa: BLE001 — cvss may raise opaque errors
        return None


def _is_within_age(modified_iso: str, max_age_days: int, now=None) -> bool:
    """Return True iff `modified_iso` is within max_age_days of `now`.

    Unparseable timestamps return True (fail open — don't silently drop on bad data).
    """
    from datetime import UTC, datetime, timedelta  # noqa: PLC0415

    if not modified_iso:
        return True
    try:
        ts = datetime.fromisoformat(modified_iso.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return True
    if now is None:
        now = datetime.now(UTC)
    return (now - ts) <= timedelta(days=max_age_days)


def _extract_severity(severity_list: list[dict]) -> tuple[str, bool]:
    """Prefer CVSS_V3. Returns (label, had_cvss).

    had_cvss=False means OSV didn't supply a v3 vector — caller should drop
    the entry entirely (the default 'medium' bucket for unscored entries
    creates ~190K noise rows in a real OSV-npm pull). CVSS_V4 ignored for
    now (cvss lib has no v4 support yet).
    """
    for item in severity_list:
        if item.get("type") == "CVSS_V3":
            score = _parse_cvss_score(item.get("score", ""))
            if score is not None:
                return severity_from_cvss_score(score), True
    return severity_from_cvss_score(None), False
