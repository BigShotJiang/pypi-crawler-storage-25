"""GitHub Security Advisories fetcher (spec §7.2)."""

from __future__ import annotations

import asyncio
from collections.abc import Callable

import httpx

from ..watchlist import WatchlistEntry
from .base import (
    Fetcher,
    FetcherContext,
    FetchResult,
    OfflineFixtureNotFound,
    hash_response,
    read_offline_fixture,
)

GHSA_URL = "https://api.github.com/graphql"
RETRY_BACKOFFS = [2, 4, 8]
THROTTLE_S = 1.0

_QUERY = """
query($q: String!) {
  securityAdvisories(
    first: 100,
    classifications: [GENERAL, MALWARE],
    identifier: {type: CVE, value: $q}
  ) {
    nodes {
      ghsaId
      summary
      permalink
      identifiers { type value }
    }
  }
}
"""


class GHSAFetcher(Fetcher):
    name = "ghsa"
    _client_factory: Callable[[], httpx.AsyncClient]

    def __init__(self) -> None:
        self._client_factory = lambda: httpx.AsyncClient(
            timeout=httpx.Timeout(connect=10, read=30, write=10, pool=10),
        )
        self._sleep = asyncio.sleep

    async def run(
        self,
        ctx: FetcherContext,
        entries: list[WatchlistEntry],
    ) -> dict[str, FetchResult]:
        out: dict[str, FetchResult] = {}
        for entry in entries:
            out[entry.ti_prefix] = await self._fetch_one(ctx, entry)
        return out

    async def _fetch_one(
        self, ctx: FetcherContext, entry: WatchlistEntry
    ) -> FetchResult:
        if ctx.offline:
            return self._read_offline(ctx, entry)
        headers = {"User-Agent": ctx.user_agent}
        if ctx.github_token:
            headers["Authorization"] = f"Bearer {ctx.github_token}"
        # GHSA query: search advisories whose identifier mentions the vendor/product.
        # We use vendor as a heuristic; refine in a follow-up.
        body = {"query": _QUERY, "variables": {"q": entry.vendor}}

        for attempt, backoff in enumerate([0, *RETRY_BACKOFFS]):
            await self._sleep(backoff if backoff else THROTTLE_S)
            try:
                async with self._client_factory() as client:
                    resp = await client.post(GHSA_URL, json=body, headers=headers)
            except (httpx.TimeoutException, httpx.TransportError) as e:
                if attempt == len(RETRY_BACKOFFS):
                    return FetchResult.from_degraded(reason=f"transport: {e!r}", fetcher="ghsa")
                continue
            if resp.status_code == 200:
                content = resp.content
                payload = resp.json()
                # GraphQL signals failures inside a 200 response — surface them
                # as degraded so operators see the rate-limit / query error
                # instead of a silently empty result.
                if payload.get("errors"):
                    msg = payload["errors"][0].get("message", "unknown")
                    return FetchResult.from_degraded(
                        reason=f"graphql error: {msg[:128]}",
                        fetcher="ghsa",
                        http_status=200,
                        body_excerpt=resp.text[:256],
                    )
                records = _extract_nodes(payload)
                return FetchResult.ok(
                    records=records,
                    http_status=200,
                    response_sha256=hash_response(content),
                    raw_record_count=len(records),
                )
            if resp.status_code in (401, 403):
                return FetchResult.from_degraded(
                    reason=f"auth: HTTP {resp.status_code}",
                    fetcher="ghsa",
                    http_status=resp.status_code,
                    body_excerpt=resp.text[:256],
                )
            if resp.status_code in (429, 500, 502, 503, 504):
                if attempt == len(RETRY_BACKOFFS):
                    return FetchResult.from_degraded(
                        reason=f"exhausted retries (last={resp.status_code})",
                        fetcher="ghsa",
                        http_status=resp.status_code,
                    )
                continue
            return FetchResult.from_degraded(
                reason=f"HTTP {resp.status_code}",
                fetcher="ghsa",
                http_status=resp.status_code,
                body_excerpt=resp.text[:256],
            )
        return FetchResult.from_degraded(reason="loop exited", fetcher="ghsa")

    def _read_offline(self, ctx: FetcherContext, entry: WatchlistEntry) -> FetchResult:
        if ctx.fixture_dir is None:
            return FetchResult.from_degraded(reason="offline without fixture_dir", fetcher="ghsa")
        try:
            payload = read_offline_fixture(ctx.fixture_dir, "ghsa", entry.vendor)
        except OfflineFixtureNotFound:
            return FetchResult.ok(records=[], raw_record_count=0)
        records = _extract_nodes(payload)
        return FetchResult.ok(records=records, raw_record_count=len(records))


def _extract_nodes(payload: dict) -> list[dict]:
    """Pull `data.securityAdvisories.nodes` defensively.

    The GraphQL response can have `securityAdvisories: null` when the API
    returns a partial error or rate-limits — chained `.get(..., {})` would
    crash on `None.get(...)`.
    """
    data = payload.get("data") or {}
    advisories = data.get("securityAdvisories") or {}
    return advisories.get("nodes", []) or []
