"""Fetcher ABC + offline fixture reader (spec §7, §8)."""

from __future__ import annotations

import abc
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

from ..types import FetcherDegraded
from ..watchlist import WatchlistEntry


class OfflineFixtureNotFound(FileNotFoundError):
    """No fixture file at the expected path under --fixture-dir."""


def read_offline_fixture(fixture_dir: Path, feed: str, basename: str) -> dict:
    """Read fixture_dir/{feed}/{basename}.json. Raises OfflineFixtureNotFound.

    `basename` is operator-controlled (typically `entry.vendor` from watchlist).
    Resolve the final path and reject anything that escapes `fixture_dir` so a
    malicious watchlist row cannot read arbitrary filesystem paths.
    """
    fixture_root = fixture_dir.resolve()
    path = (fixture_dir / feed / f"{basename}.json").resolve()
    if not path.is_relative_to(fixture_root):
        raise OfflineFixtureNotFound(str(path))
    if not path.exists():
        raise OfflineFixtureNotFound(str(path))
    return json.loads(path.read_text())


@dataclass(frozen=True)
class FetchResult:
    """Output of a single fetcher run for a single watchlist entry."""
    records: list[dict]                 # raw records; normalizer turns into NormalizedRecord
    degraded: FetcherDegraded | None = None         # None = ok
    http_status: int | None = None
    response_sha256: str | None = None
    raw_record_count: int = 0                       # before normalization filtering

    @classmethod
    def ok(
        cls,
        records: list[dict],
        http_status: int = 200,
        response_sha256: str | None = None,
        raw_record_count: int | None = None,
    ) -> FetchResult:
        return cls(
            records=records,
            degraded=None,
            http_status=http_status,
            response_sha256=response_sha256,
            raw_record_count=raw_record_count if raw_record_count is not None else len(records),
        )

    @classmethod
    def from_degraded(
        cls,
        reason: str,
        fetcher: str = "",
        http_status: int | None = None,
        body_excerpt: str | None = None,
    ) -> FetchResult:
        return cls(
            records=[],
            degraded=FetcherDegraded(
                fetcher=fetcher,
                reason=reason,
                http_status=http_status,
                body_excerpt=body_excerpt,
            ),
            http_status=http_status,
        )


def hash_response(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


@dataclass
class FetcherContext:
    """Runtime context passed to every fetcher.run()."""
    offline: bool = False
    fixture_dir: Path | None = None
    nvd_api_key: str | None = None
    github_token: str | None = None
    user_agent: str = "agentsec-ioc-update/0.3.0"


class Fetcher(abc.ABC):
    """Abstract fetcher. One instance per feed, called per watchlist entry."""

    name: str = ""  # subclass sets

    @abc.abstractmethod
    async def run(
        self,
        ctx: FetcherContext,
        entries: list[WatchlistEntry],
    ) -> dict[str, FetchResult]:
        """Return one FetchResult per entry, keyed by entry.ti_prefix."""
        ...
