"""4-state classification + field-level merge (spec §6.1, §6.2, §6.4)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date

from .id_minter import mint_ti_id
from .types import CanonicalEntry, MergeOutcome, MergeState, NormalizedRecord
from .watchlist import WatchlistEntry

EVOLVING_FIELDS: tuple[str, ...] = (
    "url",
    "observed_at",
    "cvss",
    "cvss_source",
    "affected_versions",
    "fixed_in",
    "kev",
)

NEW_DEFAULT_CONFIDENCE: dict[str, str] = {
    "nvd": "medium",
    "github_advisory": "medium",  # tightened to high in normalizer if reviewed bit set
    "kev": "high",
}


@dataclass
class MergeReport:
    outcomes: dict[str, MergeOutcome] = field(default_factory=dict)
    final_entries: list[CanonicalEntry] = field(default_factory=list)


class Merger:
    """Classify NormalizedRecords against existing CanonicalEntry list."""

    def __init__(
        self,
        watchlist: list[WatchlistEntry],
        existing: list[CanonicalEntry],
        kev_available: bool = True,
    ) -> None:
        self.watchlist = watchlist
        self.existing_by_id = {e.id: e for e in existing}
        self.kev_available = kev_available

    def merge(
        self,
        records: list[NormalizedRecord | tuple[NormalizedRecord, list[WatchlistEntry]]],
    ) -> MergeReport:
        outcomes: dict[str, MergeOutcome] = {}
        # Group records by minted id; multi-source records merge into one outcome.
        by_id: dict[str, list[NormalizedRecord]] = {}
        for item in records:
            if isinstance(item, tuple):
                rec, attribution = item
            else:
                rec = item
                attribution = self._attribute(rec)
            if not attribution:
                continue
            wl = attribution[0]  # multi-match: first watchlist entry wins
            ti_id = mint_ti_id(wl, rec)
            by_id.setdefault(ti_id, []).append(rec)

        for ti_id, recs in by_id.items():
            wl = self._watchlist_for_id(ti_id)
            existing = self.existing_by_id.get(ti_id)
            if existing is None:
                outcomes[ti_id] = self._classify_new(ti_id, recs, wl)
            else:
                outcomes[ti_id] = self._classify_existing(existing, recs)

        # Existing entries with no incoming record: UNCHANGED
        for ti_id, existing in self.existing_by_id.items():
            if ti_id not in outcomes:
                outcomes[ti_id] = MergeOutcome(state=MergeState.UNCHANGED, entry=existing)

        final = sorted([o.entry for o in outcomes.values()], key=lambda e: e.id)
        return MergeReport(outcomes=outcomes, final_entries=final)

    def _attribute(self, rec: NormalizedRecord) -> list[WatchlistEntry]:
        """Return watchlist entries that match this record. KEV uses CVE id only."""
        # For NVD/GHSA: caller is expected to pass attribution explicitly.
        # KEV records: match by CVE id presence in any existing entry whose id
        # starts with one of our prefixes — pick that entry's prefix.
        if rec.source == "kev" and rec.cve_id:
            for prefix in [w.ti_prefix for w in self.watchlist]:
                trial = f"TI-{prefix}-CVE-{rec.cve_id.removeprefix('CVE-')}"
                if trial in self.existing_by_id:
                    return [w for w in self.watchlist if w.ti_prefix == prefix]
            # KEV-only discovery: no match anywhere → first watchlist entry that
            # has the same vendor as the KEV vendorProject (heuristic). For the
            # MVP, KEV-only-discovery falls back to the first watchlist entry
            # matching the cve_id's prefix; if none, drop the record.
            return []
        # NVD / GHSA without explicit attribution: match by CVE id against
        # existing entries (same logic as KEV). If no existing entry matches,
        # fall back to the first watchlist entry (NEW discovery path).
        if rec.cve_id:
            for prefix in [w.ti_prefix for w in self.watchlist]:
                trial = f"TI-{prefix}-CVE-{rec.cve_id.removeprefix('CVE-')}"
                if trial in self.existing_by_id:
                    return [w for w in self.watchlist if w.ti_prefix == prefix]
            # No existing match → NEW discovery; use first watchlist entry.
            return self.watchlist[:1]
        if rec.ghsa_id:
            return self.watchlist[:1]
        return []

    def _watchlist_for_id(self, ti_id: str) -> WatchlistEntry:
        """Find the watchlist entry whose ti_prefix is the prefix of ti_id."""
        # Strip "TI-" then match longest prefix to handle ANTHROPIC-CLAUDE etc.
        body = ti_id.removeprefix("TI-")
        candidates = sorted(
            [w for w in self.watchlist if body.startswith(f"{w.ti_prefix}-")],
            key=lambda w: -len(w.ti_prefix),
        )
        if not candidates:
            raise ValueError(f"no watchlist entry matches {ti_id!r}")
        return candidates[0]

    def _classify_new(
        self, ti_id: str, recs: list[NormalizedRecord], wl: WatchlistEntry
    ) -> MergeOutcome:
        primary = self._pick_primary(recs)
        kev_flag = any(r.kev for r in recs)
        entry = CanonicalEntry(
            id=ti_id,
            source=primary.source,
            url=primary.url,
            observed_at=date.today().isoformat(),
            claim=self._seed_claim(primary),
            cvss=primary.cvss,
            cvss_source=primary.cvss_source,
            affected_versions=primary.affected_versions or None,
            fixed_in=primary.fixed_in,
            kev=True if kev_flag else None,
            confidence=NEW_DEFAULT_CONFIDENCE.get(primary.source, "medium"),  # type: ignore[arg-type]
            mapped_tests=[],
        )
        return MergeOutcome(state=MergeState.NEW, entry=entry)

    def _classify_existing(
        self, existing: CanonicalEntry, recs: list[NormalizedRecord]
    ) -> MergeOutcome:
        kev_flag = self._kev_flag(existing, recs)
        is_locked = existing.auto_refresh is False

        if is_locked:
            # Only KEV state + observed_at can change.
            if kev_flag != (existing.kev is True):
                new_entry = existing.with_updates(
                    kev=True if kev_flag else None,
                    observed_at=date.today().isoformat(),
                )
                diff: dict[str, tuple[object, object]] = {
                    "kev": (existing.kev, new_entry.kev),
                    "observed_at": (existing.observed_at, new_entry.observed_at),
                }
                return MergeOutcome(
                    state=MergeState.REFRESH,
                    entry=new_entry,
                    diff_fields=diff,
                    kev_only_refresh=True,
                )
            return MergeOutcome(state=MergeState.SKIP, entry=existing)

        # Healthy refresh
        primary = self._pick_primary(recs)
        candidate_kev: bool | None = True if kev_flag else None
        new_entry = existing.with_updates(
            url=primary.url or existing.url,
            cvss=primary.cvss if primary.cvss is not None else existing.cvss,
            cvss_source=primary.cvss_source or existing.cvss_source,
            affected_versions=primary.affected_versions or existing.affected_versions,
            fixed_in=primary.fixed_in or existing.fixed_in,
            kev=candidate_kev,
            observed_at=date.today().isoformat(),
        )
        diff = self._compute_diff(existing, new_entry)
        # Filter observed_at-only diff into UNCHANGED
        material_diff = {k: v for k, v in diff.items() if k != "observed_at"}
        if not material_diff:
            return MergeOutcome(state=MergeState.UNCHANGED, entry=existing)
        return MergeOutcome(state=MergeState.REFRESH, entry=new_entry, diff_fields=diff)

    def _kev_flag(
        self, existing: CanonicalEntry, recs: list[NormalizedRecord]
    ) -> bool:
        if not self.kev_available:
            return existing.kev is True  # preserve existing
        return any(r.kev for r in recs)

    def _pick_primary(self, recs: list[NormalizedRecord]) -> NormalizedRecord:
        """Prefer NVD > GHSA > KEV for evolving fields."""
        priority = {"nvd": 0, "github_advisory": 1, "kev": 2}
        return sorted(recs, key=lambda r: priority.get(r.source, 99))[0]

    @staticmethod
    def _seed_claim(rec: NormalizedRecord) -> str:
        # Collapse all whitespace runs (incl. newlines/tabs) to single spaces.
        # Without this, an upstream description with embedded \n could break out
        # of the Markdown list-item context in report.md and inject arbitrary
        # headings/lists/code blocks into the rendered artifact.
        body = re.sub(r"\s+", " ", (rec.description or "")).strip()
        if len(body) > 240:
            body = body[:237] + "..."
        return f"{body} (seeded from {rec.source.upper()}; please review)"

    @staticmethod
    def _compute_diff(
        old: CanonicalEntry, new: CanonicalEntry
    ) -> dict[str, tuple[object, object]]:
        out: dict[str, tuple[object, object]] = {}
        for field_name in EVOLVING_FIELDS:
            o = getattr(old, field_name)
            n = getattr(new, field_name)
            if o != n:
                out[field_name] = (o, n)
        return out
