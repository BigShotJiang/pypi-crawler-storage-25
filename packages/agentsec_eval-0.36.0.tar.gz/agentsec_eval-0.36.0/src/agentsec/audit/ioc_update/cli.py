"""ioc-update CLI orchestrator (spec §3, §7)."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sys
from datetime import date, datetime
from pathlib import Path

import yaml

from . import normalizer
from .fetchers.base import FetcherContext, FetchResult
from .fetchers.ghsa import GHSAFetcher
from .fetchers.kev import KEVFetcher
from .fetchers.nvd import NVDFetcher
from .fetchers.osv_cargo import OsvCargoFetcher
from .fetchers.osv_go import OsvGoFetcher
from .fetchers.osv_maven import OsvMavenFetcher
from .fetchers.osv_npm import OsvNpmFetcher
from .fetchers.osv_packagist import OsvPackagistFetcher
from .fetchers.osv_pypi import OsvPyPIFetcher
from .fetchers.osv_rubygems import OsvRubyGemsFetcher
from .merger import Merger
from .renderer import render_audit_log, render_proposed_yaml, render_report_md
from .types import CanonicalEntry, NormalizedRecord
from .watchlist import WatchlistEntry, WatchlistError, load_watchlist


def run_ioc_update(
    *,
    watchlist: Path,
    intel: Path,
    output_dir: Path | None,
    feeds: list[str],
    mode: str,
    offline: bool,
    fixture_dir: Path | None,
    nvd_api_key: str | None,
    github_token: str | None,
    user_agent: str,
    force: bool,
    verbose: bool,
) -> int:
    """Synchronous entry point. Returns exit code (0/1/2)."""
    return asyncio.run(_run_async(
        watchlist_path=watchlist,
        intel_path=intel,
        output_dir=output_dir,
        feeds_arg=feeds,
        mode=mode,
        offline=offline,
        fixture_dir=fixture_dir,
        nvd_api_key=nvd_api_key,
        github_token=github_token,
        user_agent=user_agent,
        force=force,
        verbose=verbose,
    ))


_VALID_FEEDS = {"nvd", "kev", "ghsa", "all"}
_VALID_MODES = {"discover", "refresh", "both"}


async def _run_async(
    *,
    watchlist_path: Path,
    intel_path: Path,
    output_dir: Path | None,
    feeds_arg: list[str],
    mode: str,
    offline: bool,
    fixture_dir: Path | None,
    nvd_api_key: str | None,
    github_token: str | None,
    user_agent: str,
    force: bool,
    verbose: bool,
) -> int:
    started = datetime.now().astimezone()

    # 0. Validate enum-shaped inputs (the argparse plan source had `choices=`;
    # the Typer adaptation accepts open strings, so we gate at the orchestrator
    # boundary so tests calling run_ioc_update directly get the same protection).
    bad_feeds = [f for f in feeds_arg if f not in _VALID_FEEDS]
    if bad_feeds:
        print(
            f"error: unknown feed(s) {bad_feeds}; valid: {sorted(_VALID_FEEDS)}",
            file=sys.stderr,
        )
        return 1
    if mode not in _VALID_MODES:
        print(
            f"error: unknown mode {mode!r}; valid: {sorted(_VALID_MODES)}",
            file=sys.stderr,
        )
        return 1

    # 1. Load + validate inputs
    try:
        watchlist = load_watchlist(watchlist_path)
    except (WatchlistError, FileNotFoundError) as e:
        print(f"error: invalid watchlist: {e}", file=sys.stderr)
        return 1

    try:
        existing = _load_existing_intel(intel_path)
    except FileNotFoundError as e:
        print(f"error: threat_intel.yaml not found: {e}", file=sys.stderr)
        return 1
    except (yaml.YAMLError, KeyError, TypeError) as e:
        print(f"error: invalid threat_intel.yaml: {e}", file=sys.stderr)
        return 1

    out_dir = _resolve_output_dir(output_dir)
    if out_dir.exists() and any(out_dir.iterdir()) and not force:
        print(f"error: output dir {out_dir} is non-empty (use --force)", file=sys.stderr)
        return 1
    out_dir.mkdir(parents=True, exist_ok=True)

    # 2. Build fetcher context
    fctx = FetcherContext(
        offline=offline,
        fixture_dir=fixture_dir,
        nvd_api_key=nvd_api_key or os.environ.get("NVD_API_KEY"),
        github_token=github_token or os.environ.get("GITHUB_TOKEN"),
        user_agent=user_agent,
    )
    feeds = ["nvd", "kev", "ghsa"] if "all" in feeds_arg else feeds_arg

    # 3. Run fetchers
    audit_events: list[dict] = []
    fetcher_results = await _run_fetchers(feeds, fctx, watchlist, audit_events)

    # 3b. OSV side pipelines (independent of per-watchlist-entry flow; run in parallel)
    (
        osv_npm_path,
        osv_pypi_path,
        osv_go_path,
        osv_cargo_path,
        osv_maven_path,
        osv_rubygems_path,
        osv_packagist_path,
    ) = await asyncio.gather(
        _run_osv_npm(fctx, out_dir),
        _run_osv_pypi(fctx, out_dir),
        _run_osv_go(fctx, out_dir),
        _run_osv_cargo(fctx, out_dir),
        _run_osv_maven(fctx, out_dir),
        _run_osv_rubygems(fctx, out_dir),
        _run_osv_packagist(fctx, out_dir),
    )
    if osv_npm_path is not None:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_npm_written",
            "path": str(osv_npm_path),
            "records": len(json.loads(osv_npm_path.read_text())),
        })
    else:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_npm_degraded",
            "note": "OSV-npm fetch failed or skipped; existing osv_npm.json unchanged",
        })
    if osv_pypi_path is not None:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_pypi_written",
            "path": str(osv_pypi_path),
            "records": len(json.loads(osv_pypi_path.read_text())),
        })
    else:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_pypi_degraded",
            "note": "OSV-PyPI fetch failed or skipped; existing osv_pypi.json unchanged",
        })
    if osv_go_path is not None:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_go_written",
            "path": str(osv_go_path),
            "records": len(json.loads(osv_go_path.read_text())),
        })
    else:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_go_degraded",
            "note": "OSV-Go fetch failed or skipped; existing osv_go.json unchanged",
        })
    if osv_cargo_path is not None:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_cargo_written",
            "path": str(osv_cargo_path),
            "records": len(json.loads(osv_cargo_path.read_text())),
        })
    else:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_cargo_degraded",
            "note": "OSV-Cargo fetch failed or skipped; existing osv_cargo.json unchanged",
        })
    if osv_maven_path is not None:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_maven_written",
            "path": str(osv_maven_path),
            "records": len(json.loads(osv_maven_path.read_text())),
        })
    else:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_maven_degraded",
            "note": "OSV-Maven fetch failed or skipped; existing osv_maven.json unchanged",
        })
    if osv_rubygems_path is not None:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_rubygems_written",
            "path": str(osv_rubygems_path),
            "records": len(json.loads(osv_rubygems_path.read_text())),
        })
    else:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_rubygems_degraded",
            "note": "OSV-RubyGems fetch failed or skipped; existing osv_rubygems.json unchanged",
        })
    if osv_packagist_path is not None:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_packagist_written",
            "path": str(osv_packagist_path),
            "records": len(json.loads(osv_packagist_path.read_text())),
        })
    else:
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "osv_packagist_degraded",
            "note": "OSV-Packagist fetch failed or skipped; existing osv_packagist.json unchanged",
        })

    # 4. Normalize + attribute
    typed_records = _normalize_and_attribute(fetcher_results, watchlist)

    # 5. Merge
    kev_available = (
        "kev" in fetcher_results
        and bool(watchlist)
        and fetcher_results["kev"].get(watchlist[0].ti_prefix) is not None
        and fetcher_results["kev"][watchlist[0].ti_prefix].degraded is None
    )
    merger = Merger(watchlist=watchlist, existing=existing, kev_available=kev_available)
    merge_report = merger.merge(typed_records)
    audit_events.append({
        "ts": datetime.now().isoformat(),
        "event": "merge_summary",
        "new": sum(1 for o in merge_report.outcomes.values() if o.state.value == "new"),
        "refresh": sum(1 for o in merge_report.outcomes.values() if o.state.value == "refresh"),
        "unchanged": sum(1 for o in merge_report.outcomes.values() if o.state.value == "unchanged"),
        "skipped": sum(1 for o in merge_report.outcomes.values() if o.state.value == "skip"),
    })

    # 6. Render artifacts
    degraded_list = _collect_degraded(fetcher_results)
    # all_degraded: literally every (feed, watchlist_entry) result has a
    # degraded marker. Counting "feeds with at least one degradation" is
    # wrong with a multi-entry watchlist — N entries each contributing one
    # degraded result would falsely trigger the no-yaml safeguard even when
    # every feed had a successful entry too. Spec §7.4 talks about
    # "all-fetcher failure" which we read as "no usable upstream data".
    all_degraded = bool(fetcher_results) and not any(
        fr.degraded is None
        for feed_results in fetcher_results.values()
        for fr in feed_results.values()
    )

    if all_degraded:
        # Don't write proposed YAML on total failure (spec §7.4 safeguard)
        proposed_yaml = ""
        proposed_sha = ""
    else:
        proposed_yaml = render_proposed_yaml(merge_report.final_entries)
        proposed_sha = hashlib.sha256(proposed_yaml.encode("utf-8")).hexdigest()[:16]
        (out_dir / "proposed-threat_intel.yaml").write_text(proposed_yaml)

    finished = datetime.now().astimezone()
    fetched_counts = {f: _records_count(fetcher_results.get(f, {})) for f in feeds}
    md = render_report_md(
        merge_report=merge_report,
        watchlist_count=len(watchlist),
        fetched_counts=fetched_counts,
        existing_count=len(existing),
        feeds_degraded=degraded_list,
        run_started=started,
        run_finished=finished,
        proposed_yaml_sha=proposed_sha,
        nvd_api_key_used=fctx.nvd_api_key is not None,
        github_token_used=fctx.github_token is not None,
        mode=mode,
        feeds=feeds,
        offline=offline,
    )
    (out_dir / "report.md").write_text(md)

    audit_events.append({
        "ts": datetime.now().isoformat(),
        "event": "render_complete",
        "artifacts": ["proposed-threat_intel.yaml", "report.md", "audit-log.jsonl"]
                     if not all_degraded else ["report.md", "audit-log.jsonl"],
        "offline": offline,
    })
    (out_dir / "audit-log.jsonl").write_text(render_audit_log(audit_events))

    if all_degraded:
        return 1
    if degraded_list:
        return 2
    return 0


def _resolve_output_dir(output_dir: Path | None) -> Path:
    if output_dir is not None:
        return output_dir
    return Path(".cache") / f"ioc-update-{date.today().isoformat()}"


def _load_existing_intel(path: Path) -> list[CanonicalEntry]:
    raw = yaml.safe_load(path.read_text()) or []
    out: list[CanonicalEntry] = []
    for item in raw:
        # pyyaml turns unquoted ISO dates (`observed_at: 2026-04-25`) into
        # datetime.date objects. Coerce to ISO-string so the diff table /
        # determinism hash treat both sides uniformly. Production
        # threat_intel.yaml has used unquoted dates since Stage 0.
        obs = item.get("observed_at")
        observed_at = obs.isoformat() if hasattr(obs, "isoformat") else (obs or "")
        out.append(CanonicalEntry(
            id=item["id"],
            source=item.get("source", ""),
            url=item.get("url", ""),
            observed_at=observed_at,
            claim=item.get("claim", ""),
            cvss=item.get("cvss"),
            cvss_source=item.get("cvss_source"),
            affected_versions=item.get("affected_versions"),
            fixed_in=item.get("fixed_in"),
            kev=item.get("kev"),
            confidence=item.get("confidence", "medium"),
            mapped_tests=item.get("mapped_tests", []),
            auto_refresh=item.get("auto_refresh"),
            note=item.get("note"),
        ))
    return out


async def _run_fetchers(
    feeds: list[str], ctx: FetcherContext, watchlist: list[WatchlistEntry],
    audit_events: list,
) -> dict:
    fetchers = {"nvd": NVDFetcher(), "kev": KEVFetcher(), "ghsa": GHSAFetcher()}
    out: dict[str, dict] = {}
    for feed in feeds:
        fetcher = fetchers.get(feed)
        if fetcher is None:
            continue
        audit_events.append({
            "ts": datetime.now().isoformat(),
            "event": "fetch_start",
            "feed": feed,
        })
        result = await fetcher.run(ctx, watchlist)
        out[feed] = result
        for prefix, fr in result.items():
            audit_events.append({
                "ts": datetime.now().isoformat(),
                "event": "fetch_ok" if fr.degraded is None else "fetch_failed",
                "feed": feed,
                "watchlist_entry": prefix,
                "records": fr.raw_record_count,
                "http_status": fr.http_status,
                "response_sha256": fr.response_sha256,
                "reason": fr.degraded.reason if fr.degraded else None,
            })
    return out


async def _run_osv_npm(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    """Side pipeline: pull OSV-npm, write proposed-osv_npm.json.

    Independent of _run_fetchers because OSV-npm is a single full
    ecosystem dump (not per-watchlist-entry), and its output is a
    standalone DB file (not merged into threat_intel.yaml).

    Returns the written file path on success, None on degraded fetch.
    """
    fetcher = OsvNpmFetcher()
    results = await fetcher.run(ctx, entries=[])
    result = results.get("_osv_npm_full")
    if result is None or result.degraded is not None:
        return None
    out_path = cache_dir / "proposed-osv_npm.json"
    out_path.write_text(
        json.dumps(result.records, separators=(",", ":"), sort_keys=False)
    )
    return out_path


async def _run_osv_pypi(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    """Side pipeline: pull OSV-PyPI, write proposed-osv_pypi.json.

    Mirrors _run_osv_npm. Runs in parallel with _run_osv_npm via
    asyncio.gather in the main entry point.

    Returns the written file path on success, None on degraded fetch.
    """
    fetcher = OsvPyPIFetcher()
    results = await fetcher.run(ctx, entries=[])
    result = results.get("_osv_pypi_full")
    if result is None or result.degraded is not None:
        return None
    out_path = cache_dir / "proposed-osv_pypi.json"
    out_path.write_text(
        json.dumps(result.records, separators=(",", ":"), sort_keys=False)
    )
    return out_path


async def _run_osv_go(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    """Side pipeline: pull OSV-Go, write proposed-osv_go.json.

    Mirrors _run_osv_npm / _run_osv_pypi. Runs in parallel with both via
    asyncio.gather in the main entry point.

    Returns the written file path on success, None on degraded fetch.
    """
    fetcher = OsvGoFetcher()
    results = await fetcher.run(ctx, entries=[])
    result = results.get("_osv_go_full")
    if result is None or result.degraded is not None:
        return None
    out_path = cache_dir / "proposed-osv_go.json"
    out_path.write_text(
        json.dumps(result.records, separators=(",", ":"), sort_keys=False)
    )
    return out_path


async def _run_osv_cargo(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    """Side pipeline: pull OSV-Cargo, write proposed-osv_cargo.json.

    Mirrors _run_osv_npm / _run_osv_pypi / _run_osv_go. Runs in parallel
    with all three via asyncio.gather in the main entry point.

    Returns the written file path on success, None on degraded fetch.
    """
    fetcher = OsvCargoFetcher()
    results = await fetcher.run(ctx, [])
    result = results.get("_osv_cargo_full")
    if result is None or result.degraded is not None:
        return None
    out_path = cache_dir / "proposed-osv_cargo.json"
    out_path.write_text(json.dumps(result.records, indent=2, sort_keys=True))
    return out_path


async def _run_osv_maven(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    """Side pipeline: pull OSV-Maven, write proposed-osv_maven.json.

    Mirrors _run_osv_npm / _run_osv_pypi / _run_osv_go / _run_osv_cargo. Runs in
    parallel with all four via asyncio.gather in the main entry point.

    Returns the written file path on success, None on degraded fetch.
    """
    fetcher = OsvMavenFetcher()
    results = await fetcher.run(ctx, [])
    result = results.get("_osv_maven_full")
    if result is None or result.degraded is not None:
        return None
    out_path = cache_dir / "proposed-osv_maven.json"
    out_path.write_text(json.dumps(result.records, indent=2, sort_keys=True))
    return out_path


async def _run_osv_rubygems(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    """Side pipeline: pull OSV-RubyGems, write proposed-osv_rubygems.json.

    Mirrors _run_osv_npm / _run_osv_pypi / _run_osv_go / _run_osv_cargo / _run_osv_maven.
    Runs in parallel with all five via asyncio.gather in the main entry point.

    Returns the written file path on success, None on degraded fetch.
    """
    fetcher = OsvRubyGemsFetcher()
    results = await fetcher.run(ctx, [])
    result = results.get("_osv_rubygems_full")
    if result is None or result.degraded is not None:
        return None
    out_path = cache_dir / "proposed-osv_rubygems.json"
    out_path.write_text(json.dumps(result.records, indent=2, sort_keys=True))
    return out_path


async def _run_osv_packagist(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    """Side pipeline: pull OSV-Packagist, write proposed-osv_packagist.json.

    Mirrors _run_osv_npm / _run_osv_pypi / _run_osv_go / _run_osv_cargo /
    _run_osv_maven / _run_osv_rubygems. Runs in parallel with all six via
    asyncio.gather in the main entry point.

    Returns the written file path on success, None on degraded fetch.
    """
    fetcher = OsvPackagistFetcher()
    results = await fetcher.run(ctx, [])
    result = results.get("_osv_packagist_full")
    if result is None or result.degraded is not None:
        return None
    out_path = cache_dir / "proposed-osv_packagist.json"
    out_path.write_text(json.dumps(result.records, indent=2, sort_keys=True))
    return out_path


def _normalize_and_attribute(
    fetcher_results: dict, watchlist: list[WatchlistEntry],
) -> list[NormalizedRecord | tuple[NormalizedRecord, list[WatchlistEntry]]]:
    """Convert raw fetcher dicts into typed records for the merger.

    NVD/GHSA records carry explicit (record, [watchlist_entry]) attribution
    tuples. KEV records flow as bare NormalizedRecord; the merger's
    _attribute() handles their CVE-id-based prefix lookup against existing
    threat_intel entries.
    """
    typed: list[NormalizedRecord | tuple[NormalizedRecord, list[WatchlistEntry]]] = []
    by_id: dict[str, list[tuple[NormalizedRecord, WatchlistEntry]]] = {}

    for entry in watchlist:
        for raw in fetcher_results.get("nvd", {}).get(entry.ti_prefix, _empty()).records:
            rec = normalizer.normalize_nvd(raw)
            if rec.cve_id:
                by_id.setdefault(rec.cve_id, []).append((rec, entry))
        for raw in fetcher_results.get("ghsa", {}).get(entry.ti_prefix, _empty()).records:
            rec = normalizer.normalize_ghsa(raw)
            if rec.cve_id or rec.ghsa_id:
                key = rec.cve_id or rec.ghsa_id
                # The if-guard above ensures at least one of the two is truthy.
                assert key is not None  # noqa: S101
                by_id.setdefault(key, []).append((rec, entry))

    for items in by_id.values():
        # First watchlist entry by file order wins (spec §6.4)
        first = items[0]
        wl_first = first[1]
        typed.append((first[0], [wl_first]))

    # KEV records flow through merger._attribute (uses cve_id) without explicit attribution.
    for entry in watchlist:
        kev_result = fetcher_results.get("kev", {}).get(entry.ti_prefix)
        if kev_result is None or kev_result.degraded is not None:
            continue
        for raw in kev_result.records:
            rec = normalizer.normalize_kev(raw)
            if rec.cve_id:
                typed.append(rec)
        break  # KEV catalog is global; only iterate once

    return typed


def _empty() -> FetchResult:
    return FetchResult.ok(records=[], raw_record_count=0)


def _collect_degraded(fetcher_results: dict) -> list:
    out = []
    for result in fetcher_results.values():
        for fr in result.values():
            if fr.degraded is not None:
                out.append(fr.degraded)
                break  # one entry per feed for the report
    return out


def _records_count(per_entry: dict) -> int:
    return sum(fr.raw_record_count for fr in per_entry.values())
