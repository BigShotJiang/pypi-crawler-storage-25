"""server_audit orchestrator — runs each Check, collects findings + status."""

from __future__ import annotations

from dataclasses import dataclass, field

from .checks.base import Check, CheckContext, CheckStatus
from .findings import Finding


@dataclass
class ServerAuditReport:
    findings: list[Finding] = field(default_factory=list)
    statuses: dict[str, CheckStatus] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)


async def run_server_audit(*, checks: list[Check], ctx: CheckContext) -> ServerAuditReport:
    report = ServerAuditReport()
    seen_fingerprints: set[str] = set()
    for check in checks:
        check_ctx = CheckContext(
            executor=ctx.executor,
            redactor=ctx.redactor,
            ioc_dir=ctx.ioc_dir,
            profile=ctx.profile,
            status=CheckStatus(),
            log_review_config=ctx.log_review_config,
            pip_lock_paths=ctx.pip_lock_paths,
            go_lock_paths=ctx.go_lock_paths,
            cargo_lock_paths=ctx.cargo_lock_paths,
            maven_lock_paths=ctx.maven_lock_paths,
            gem_lock_paths=ctx.gem_lock_paths,
            composer_lock_paths=ctx.composer_lock_paths,
        )
        try:
            findings = await check.run(check_ctx)
        except Exception as e:
            report.errors[check.id] = f"{type(e).__name__}: {e}"
            report.statuses[check.id] = check_ctx.status
            continue
        for f in findings:
            if f.fingerprint in seen_fingerprints:
                continue
            seen_fingerprints.add(f.fingerprint)
            report.findings.append(f)
        report.statuses[check.id] = check_ctx.status
    return report
