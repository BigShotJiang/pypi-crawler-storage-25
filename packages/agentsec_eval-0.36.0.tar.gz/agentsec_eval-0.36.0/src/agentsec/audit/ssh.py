"""SSHExecutor — sole I/O surface for the SSH command policy.

Every call goes through CommandPolicy.validate(); rejected calls return a
RunResult with rejected=True and never touch the transport.

Audit-log shape (audit-log.jsonl, one JSON object per line):
  - On success: SHA-256 of the rendered command, never the rendered
    string itself or the argv list — both can carry sensitive parameters
    even after redaction. exit_code, duration_ms, bytes_out, and
    Redactor-filtered stderr are recorded.
  - On rejection: argv is included alongside reject_reason so an
    operator triaging a reject can see what was attempted. Rejected
    calls never reached the transport, and the policy already constrained
    the argv shape before this point.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Protocol

import paramiko

from .command_policy import CommandPolicy
from .redactor import Redactor
from .types import RunResult


class _Transport(Protocol):
    def exec_command(
        self,
        command: str,
        *,
        get_pty: bool,
        environment: dict | None,
        timeout: int,
    ) -> tuple[object, object, object]: ...


def _read_capped(stream, cap: int) -> bytes:
    """Read bytes from a paramiko ChannelFile (or duck-compatible) until the
    cap is reached or EOF, whichever comes first. Bounds in-memory buffering
    at ``cap`` bytes, unlike a bare ``stream.read()`` which would accumulate
    until the remote channel closed.
    """
    buf = bytearray()
    while len(buf) < cap:
        remaining = cap - len(buf)
        chunk = stream.read(min(8192, remaining))
        if not chunk:
            break
        buf.extend(chunk)
    return bytes(buf)


class SSHExecutor:
    def __init__(
        self,
        *,
        policy: CommandPolicy,
        redactor: Redactor,
        audit_log_path: Path | str,
        transport: _Transport | None = None,
        host: str | None = None,
        user: str | None = None,
        key_filename: str | None = None,
    ):
        self._policy = policy
        self._redactor = redactor
        self._log_path = Path(audit_log_path)
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        # Ensure the file exists from the moment the executor is constructed.
        # If the test stubs out `run` (which would otherwise create it on first
        # call), downstream artifact checks still see the file.
        self._log_path.touch(exist_ok=True)
        self._transport = transport
        self._host = host
        self._user = user
        self._key = key_filename
        self._client: paramiko.SSHClient | None = None

    def _ensure_transport(self) -> _Transport:
        if self._transport is not None:
            return self._transport
        if self._client is None:
            # Caller invariant: when no pre-built `transport` was passed, the
            # `host` / `user` / `key_filename` triple must be supplied so that
            # paramiko can dial the box. Bare `assert` because reaching this
            # branch with any of them None is a programmer error (config layer
            # is responsible for populating them before constructing the executor).
            assert self._host is not None, "SSHExecutor needs host when no transport is preset"  # noqa: S101
            assert self._user is not None, "SSHExecutor needs user when no transport is preset"  # noqa: S101
            client = paramiko.SSHClient()
            client.load_system_host_keys()
            client.set_missing_host_key_policy(paramiko.RejectPolicy())
            client.connect(
                hostname=self._host,
                username=self._user,
                key_filename=self._key,
                allow_agent=False,
                look_for_keys=False,
            )
            self._client = client
        return self._client

    def run(self, argv: list[str]) -> RunResult:
        policy_result = self._policy.validate(argv)
        if not policy_result.ok:
            result = RunResult(
                argv=list(argv),
                command_sha256="",
                exit_code=-1,
                stdout="",
                stderr="",
                duration_ms=0.0,
                bytes_out=0,
                rejected=True,
                reject_reason=policy_result.reason,
            )
            self._append_audit(result)
            return result

        rendered = policy_result.rendered or ""
        sha256 = hashlib.sha256(rendered.encode("utf-8")).hexdigest()

        transport = self._ensure_transport()
        t0 = time.monotonic()
        _stdin, stdout, stderr = transport.exec_command(
            rendered,
            get_pty=False,
            environment=None,
            timeout=self._policy.default_timeout_sec,
        )
        # Stream stdout/stderr in chunks bounded by max_output_bytes, instead
        # of buffering the full payload into memory and slicing afterwards.
        # The audit module is intended for hosts that may be compromised
        # (CLAUDE.md), so a target streaming gigabytes within the timeout
        # would otherwise exhaust evaluator RAM long before the post-hoc
        # slice ran. Apply the cap symmetrically to stderr (which previously
        # had no bound at all).
        cap = self._policy.max_output_bytes
        out_bytes = _read_capped(stdout, cap)
        err_bytes = _read_capped(stderr, cap)
        duration_ms = (time.monotonic() - t0) * 1000.0

        # `_Transport.exec_command` returns three opaque `object`s (the protocol
        # is intentionally narrow). Real paramiko ChannelFiles expose `.channel`;
        # test stubs typically do not. getattr keeps both paths well-typed.
        channel = getattr(stdout, "channel", None)
        exit_code = channel.recv_exit_status() if channel is not None else 0

        out_str = out_bytes.decode("utf-8", errors="replace")
        err_str = err_bytes.decode("utf-8", errors="replace")

        result = RunResult(
            argv=list(argv),
            command_sha256=sha256,
            exit_code=exit_code,
            stdout=out_str,
            stderr=err_str,
            duration_ms=duration_ms,
            bytes_out=len(out_bytes),
            rejected=False,
            reject_reason=None,
        )
        self._append_audit(result)
        return result

    def _append_audit(self, r: RunResult) -> None:
        line = {
            "ts": time.time(),
            "command_sha256": r.command_sha256,
            "exit_code": r.exit_code,
            "duration_ms": r.duration_ms,
            "bytes_out": r.bytes_out,
            "rejected": r.rejected,
            "reject_reason": r.reject_reason,
            "stderr_redacted": self._redactor.redact(r.stderr) if r.stderr else "",
        }
        # argv carries the same sensitive parameters the SHA-256 design was
        # meant to keep out of the log, so omit it on the success path. On
        # rejection we keep argv: it never reached the transport, the policy
        # already constrained its shape, and an operator triaging a reject
        # needs to see what was attempted alongside reject_reason.
        if r.rejected:
            line["argv"] = r.argv
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(line, ensure_ascii=False) + "\n")

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None
