"""IOC data for the audit module.

- cve_database.json: generated from threat_intel.yaml by scripts/build_cve_db.py
- clawhavoc_skills.json: hand-curated seed (vNext: feed-driven update)
- attack_signatures.yaml: hand-curated seed (vNext: feed-driven update)
"""
from pathlib import Path

IOC_DIR: Path = Path(__file__).parent
