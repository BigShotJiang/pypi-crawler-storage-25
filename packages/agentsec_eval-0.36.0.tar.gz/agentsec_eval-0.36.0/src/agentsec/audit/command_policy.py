"""CommandPolicy — the four-step validation chain (spec §6.1).

Order is non-negotiable (OE-AUD3-008):
  1. placeholder substitution (already done by caller — argv arrives substituted)
  2. shell-metachar reject on final argv
  3. per-command args_schema / allowed_argv check
  4. render via shlex.quote — only after all checks pass

The single public method is .validate(argv). Render is internal: callers
read PolicyResult.rendered and pass that string to paramiko.exec_command.
"""

from __future__ import annotations

import os
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .args_schema import validate_args
from .metachar_guard import contains_shell_metachar
from .path_matcher import AllowedPath, PathMatcher


@dataclass
class PolicyReject:
    reason: str
    stage: str  # "metachar" | "args_schema" | "render"


@dataclass
class PolicyResult:
    ok: bool
    rendered: str | None = None
    reason: str | None = None
    stage: str | None = None


class CommandPolicy:
    def __init__(
        self,
        allowed_paths: list[AllowedPath],
        commands: dict[str, Any],
        max_output_bytes: int,
        default_timeout_sec: int,
        redact_before_log: bool,
        write_operations: dict[str, Any],
        *,
        remote_home: str | None = None,
    ):
        self._allowed_paths = list(allowed_paths)
        self._commands = commands
        self.max_output_bytes = max_output_bytes
        self.default_timeout_sec = default_timeout_sec
        self.redact_before_log = redact_before_log
        self.write_operations = write_operations
        self._remote_home = remote_home
        self._matcher = PathMatcher(self._allowed_paths, remote_home=remote_home)

    @classmethod
    def from_yaml(cls, path: Path | str, *, remote_home: str | None = None) -> CommandPolicy:
        data = yaml.safe_load(Path(path).read_text())
        rules = []
        for raw in data.get("allowed_paths", []):
            rules.append(AllowedPath(
                kind=raw["kind"],
                path=raw.get("path"),
                pattern=raw.get("pattern"),
            ))
        return cls(
            allowed_paths=rules,
            commands=data.get("commands", {}),
            max_output_bytes=int(data.get("max_output_bytes", 1_048_576)),
            default_timeout_sec=int(data.get("default_timeout_sec", 15)),
            redact_before_log=bool(data.get("redact_before_log", True)),
            write_operations=data.get("write_operations", {"enabled": False}),
            remote_home=remote_home,
        )

    def add_allowed_path_prefix(self, path: Path | str) -> None:
        """Test-only seam: extend allowed_paths at runtime. Production code
        loads the full set from ssh_policy.yaml and never mutates."""
        self._allowed_paths.append(AllowedPath(kind="prefix", path=str(path)))
        self._matcher = PathMatcher(self._allowed_paths, remote_home=self._remote_home)

    def add_runtime_allowed_paths(
        self, paths: list[str], *, kind: str = "exact",
    ) -> None:
        """Append operator-supplied paths to allowed_paths at runtime.

        Used by Phase 7d.1 pip_supply_chain_audit to honor
        ServerAuditConfig.pip_lock_paths without editing ssh_policy.yaml.
        Operator's config entry == consent.

        `kind` must be one of {"exact", "prefix"}; "exact" recommended for
        individual file paths so a directory entry can't accidentally
        expand the read scope.
        """
        if kind not in ("exact", "prefix"):
            raise ValueError(f"kind must be exact|prefix, got {kind!r}")
        for p in paths:
            self._allowed_paths.append(AllowedPath(kind=kind, path=p))
        self._matcher = PathMatcher(
            self._allowed_paths, remote_home=self._remote_home,
        )

    def validate(self, argv: list[str]) -> PolicyResult:
        if not argv:
            return PolicyResult(ok=False, reason="empty argv", stage="args_schema")
        meta_reason = contains_shell_metachar(argv)
        if meta_reason is not None:
            return PolicyResult(ok=False, reason=meta_reason, stage="metachar")
        # Allow argv[0] to be either a bare command name (e.g. "openclaw") or
        # an absolute path whose basename is a known command (e.g.
        # "/home/ubuntu/.npm-global/bin/openclaw"). Absolute argv[0] is required
        # when the binary lives outside paramiko's non-login PATH (D1).
        command = (
            os.path.basename(argv[0])
            if os.path.isabs(argv[0])
            else argv[0]
        )
        schema = self._commands.get(command, {})
        # Pass a normalized argv (basename in slot 0) so args_schema's
        # argv[0] == command equality check still works. The original argv —
        # with absolute path intact — is what gets shlex-rendered for the wire.
        normalized_argv = [command, *argv[1:]] if command != argv[0] else argv
        schema_reason = validate_args(command, normalized_argv, schema, self._matcher)
        if schema_reason is not None:
            return PolicyResult(ok=False, reason=schema_reason, stage="args_schema")
        rendered = " ".join(shlex.quote(t) for t in argv)
        return PolicyResult(ok=True, rendered=rendered)
