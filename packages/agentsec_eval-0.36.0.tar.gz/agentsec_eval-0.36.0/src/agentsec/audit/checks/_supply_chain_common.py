"""Shared advisory-DB load helper used by all 3 ecosystem Checks.

Extracted in Phase 7d.2 (rule of three). Re-exports
severity_from_cvss_score / Severity so Check files don't need to reach
into the fetchers/ subtree directly.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from ..ioc_update.fetchers._supply_chain_common import (
    Severity,
    severity_from_cvss_score,
)

__all__ = ["Severity", "severity_from_cvss_score", "load_advisory_db", "extract_severity_label"]


def load_advisory_db(path: Path) -> dict[str, list[dict]]:
    """Load OSV bundle JSON file and index advisories by package name."""
    raw = json.loads(path.read_text())
    by_pkg: dict[str, list[dict]] = {}
    for adv in raw:
        by_pkg.setdefault(adv["package"], []).append(adv)
    return by_pkg


def extract_severity_label(adv: dict) -> Severity:
    """Read the compact-schema 'severity' field; fall back to 'medium'."""
    sev = adv.get("severity")
    if sev in ("critical", "high", "medium", "low"):
        return sev
    return "medium"


# ── Maven ComparableVersion + dependency:list parser (Phase 7d.4) ─────────

# Apache Maven qualifier rank table.
# Known qualifiers get fixed rank; unknown qualifiers rank as (2, lowercase)
# meaning they sort after "sp" (rank 1) lexicographically.
_MAVEN_QUALIFIERS: dict[str, int] = {
    "alpha": -5, "a": -5,
    "beta": -4, "b": -4,
    "milestone": -3, "m": -3,
    "rc": -2, "cr": -2,
    "snapshot": -1,
    "": 0, "final": 0, "ga": 0, "release": 0,
    "sp": 1,
}


def _maven_qualifier_rank(s: str) -> tuple[int, str]:
    """Return (rank, key) for a qualifier string."""
    s = s.lower()
    if s in _MAVEN_QUALIFIERS:
        return (_MAVEN_QUALIFIERS[s], "")
    return (2, s)


# Item types: ("int", int) | ("str", str) | ("list", list)


def _maven_item_is_zero(item) -> bool:
    """Item counts as 'zero' for trailing-zero normalization."""
    kind, val = item
    if kind == "int":
        return val == 0
    if kind == "str":
        return _maven_qualifier_rank(val) == (0, "")
    if kind == "list":
        return not val or all(_maven_item_is_zero(it) for it in val)
    return False


def _tokenize_maven_version(v: str) -> list:
    """Tokenize a Maven version string into a (possibly nested) item list.

    Apache ComparableVersion behavior:
      - '.' is a same-level separator
      - '-' opens a new nested sub-list
      - digit↔alpha transitions implicitly open a new nested sub-list
      - trailing zero items are trimmed at every level (normalize)
    """
    v = (v or "").lower().strip()
    if not v:
        return []

    root: list = []
    stack: list[list] = [root]
    last_kind: str | None = None  # "int" | "str" | None

    i = 0
    n = len(v)
    while i < n:
        c = v[i]
        if c == ".":
            last_kind = None
            i += 1
            continue
        if c == "-":
            new_list: list = []
            stack[-1].append(("list", new_list))
            stack.append(new_list)
            last_kind = None
            i += 1
            continue
        if c.isdigit():
            if last_kind == "str":
                new_list = []
                stack[-1].append(("list", new_list))
                stack.append(new_list)
            j = i
            while j < n and v[j].isdigit():
                j += 1
            stack[-1].append(("int", int(v[i:j])))
            last_kind = "int"
            i = j
            continue
        if c.isalpha():
            if last_kind == "int":
                new_list = []
                stack[-1].append(("list", new_list))
                stack.append(new_list)
            j = i
            while j < n and v[j].isalpha():
                j += 1
            stack[-1].append(("str", v[i:j]))
            last_kind = "str"
            i = j
            continue
        # Unknown character — skip
        i += 1

    # Recursively trim trailing zero items at every level
    def _normalize(items: list) -> None:
        for item in items:
            if item[0] == "list":
                _normalize(item[1])
        while items and _maven_item_is_zero(items[-1]):
            items.pop()

    _normalize(root)
    return root


def _compare_maven_items(a, b) -> int:
    """Compare two items (or one item against None for padding)."""
    if a is None and b is None:
        return 0
    if a is None:
        return -_compare_maven_items(b, None)
    if b is None:
        ak, av = a
        if ak == "int":
            return (av > 0) - (av < 0)
        if ak == "str":
            r, _ = _maven_qualifier_rank(av)
            return (r > 0) - (r < 0)
        if ak == "list":
            return _compare_maven_lists(av, [])
        return 0

    ak, av = a
    bk, bv = b

    if ak == "int" and bk == "int":
        return (av > bv) - (av < bv)
    if ak == "int" and bk == "str":
        return 1
    if ak == "str" and bk == "int":
        return -1
    if ak == "int" and bk == "list":
        return 1
    if ak == "list" and bk == "int":
        return -1
    if ak == "list" and bk == "str":
        return 1
    if ak == "str" and bk == "list":
        return -1
    if ak == "str" and bk == "str":
        ra, ka = _maven_qualifier_rank(av)
        rb, kb = _maven_qualifier_rank(bv)
        if ra != rb:
            return (ra > rb) - (ra < rb)
        return (ka > kb) - (ka < kb)
    if ak == "list" and bk == "list":
        return _compare_maven_lists(av, bv)
    return 0


def _compare_maven_lists(a: list, b: list) -> int:
    """Compare two item lists with padding for shorter one."""
    la, lb = len(a), len(b)
    n = max(la, lb)
    for i in range(n):
        ai = a[i] if i < la else None
        bi = b[i] if i < lb else None
        c = _compare_maven_items(ai, bi)
        if c != 0:
            return c
    return 0


def _compare_maven_version(v1: str, v2: str) -> int:
    """Compare two Maven versions per Apache ComparableVersion semantics.

    Returns -1, 0, or 1 for v1 < v2, v1 == v2, v1 > v2.
    """
    items1 = _tokenize_maven_version(v1)
    items2 = _tokenize_maven_version(v2)
    return _compare_maven_lists(items1, items2)


def _is_maven_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
) -> bool:
    """True iff version satisfies introduced <= version < fixed.

    Either bound may be None: missing introduced means "from 0";
    missing fixed means "no upper bound" (still vulnerable).
    """
    if introduced is not None and _compare_maven_version(introduced, version) > 0:
        return False
    if fixed is not None and _compare_maven_version(version, fixed) >= 0:
        return False
    return True


# Maven dependency:list parser

_MAVEN_DEP_LINE = re.compile(
    r"""
    ^
    (?:\[INFO\]\s*)?       # optional [INFO] prefix
    \s*                     # optional leading whitespace
    ([a-zA-Z0-9._-]+)       # groupId
    :
    ([a-zA-Z0-9._-]+)       # artifactId
    :
    ([a-zA-Z0-9._-]+)       # type (jar/pom/war/...)
    :
    ([a-zA-Z0-9._+-]+)      # version
    :
    (compile|runtime|provided|test|system)   # scope
    \s*$
    """,
    re.VERBOSE,
)

_MAVEN_SCOPE_INCLUDED = {"compile", "runtime", "provided", "test"}


def parse_maven_dependency_list(text: str) -> list[tuple[str, str]]:
    """Parse `mvn dependency:list -DoutputFile=...` text format.

    Returns a list of (coordinate, version) tuples where coordinate
    is `groupId:artifactId` (case-sensitive). Skips lines that don't
    match the 5-segment colon format, or whose scope is `system`/`none`.
    """
    out: list[tuple[str, str]] = []
    for raw_line in text.splitlines():
        m = _MAVEN_DEP_LINE.match(raw_line)
        if not m:
            continue
        group_id, artifact_id, _type, version, scope = m.groups()
        if scope not in _MAVEN_SCOPE_INCLUDED:
            continue
        coord = f"{group_id}:{artifact_id}"
        out.append((coord, version))
    return out


# ── Gemfile.lock parser + PEP 440 version range matcher (Phase 7d.5) ──────

_GEM_DEP_LINE = re.compile(r"^    ([a-zA-Z0-9._-]+) \(([^)]+)\)\s*$")


def parse_gemfile_lock(text: str) -> list[tuple[str, str]]:
    """Parse a Bundler-generated Gemfile.lock.

    Walks the `GEM > specs:` section only. Skips GIT / PATH / PLATFORMS /
    DEPENDENCIES sections (the first two are out-of-OSV-scope sources; the
    last two don't list resolved versions).

    Within `GEM > specs:`, 4-space-indented lines are resolved
    dependencies (`    gem_name (version)`); 6-space-indented lines are
    transitive version constraints — skipped.

    Gem names are case-folded to lowercase (RubyGems is case-insensitive).
    """
    out: list[tuple[str, str]] = []
    in_gem_section = False
    in_specs = False

    for raw in text.splitlines():
        # Section header detection (no leading whitespace)
        if raw and not raw[0].isspace():
            header = raw.strip()
            in_gem_section = header == "GEM"
            in_specs = False
            continue

        if not in_gem_section:
            continue

        stripped = raw.strip()
        if stripped == "specs:":
            in_specs = True
            continue

        if not in_specs:
            continue

        # Resolved gem entry: exactly 4 leading spaces
        m = _GEM_DEP_LINE.match(raw)
        if m:
            gem_name, version = m.groups()
            out.append((gem_name.lower(), version))

    return out


def _normalize_gem_version(s: str) -> str:
    """Convert a RubyGems version string into a PEP 440-compatible form.

    RubyGems uses suffixes like `1.0.0.pre.1`, `2.0.0.rc1`, `1.0.0.beta`.
    PEP 440's packaging.version.Version accepts `1.0.0a1`, `2.0.0rc1`,
    `1.0.0b0` etc. This helper applies minimal string substitutions to
    bridge the two; best-effort, may leave exotic strings unparseable
    (returned None from `_safe_parse_gem_version`).
    """
    if not s:
        return s
    # `.pre.N` (e.g. 1.0.0.pre.1) → `aN`
    s = re.sub(r"\.pre\.(\d+)", r"a\1", s)
    # `.pre` standalone (e.g. 1.0.0.pre) → `a0`
    s = re.sub(r"\.pre$", "a0", s)
    # `.beta.N` / `.alpha.N` → `bN` / `aN`
    s = re.sub(r"\.beta\.(\d+)", r"b\1", s)
    s = re.sub(r"\.alpha\.(\d+)", r"a\1", s)
    # Standalone `.beta` / `.alpha` → `b0` / `a0`
    s = re.sub(r"\.beta$", "b0", s)
    s = re.sub(r"\.alpha$", "a0", s)
    return s


def _safe_parse_gem_version(s: str):
    """Parse a RubyGems version into packaging.Version, or None on failure."""
    from packaging.version import InvalidVersion, Version
    if not s:
        return None
    try:
        return Version(_normalize_gem_version(s))
    except (InvalidVersion, TypeError):
        return None


def _is_gem_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
) -> bool:
    """True iff version satisfies introduced <= version < fixed.

    Either bound may be None: missing introduced means "from 0";
    missing fixed means "no upper bound" (still vulnerable).
    Returns False if the version string cannot be parsed.
    """
    v = _safe_parse_gem_version(version)
    if v is None:
        return False
    if introduced is not None:
        intro = _safe_parse_gem_version(introduced)
        if intro is not None and intro > v:
            return False
    if fixed is not None:
        fix = _safe_parse_gem_version(fixed)
        if fix is not None and v >= fix:
            return False
    return True


# ── composer.lock parser + PEP 440 version range matcher (Phase 7d.6) ─────

_COMPOSER_STABILITY_RE = re.compile(
    r"-(dev|alpha|beta|RC|p)(\d*)\b", re.IGNORECASE
)

_COMPOSER_STABILITY_MAP = {
    "dev": ".dev",
    "alpha": "a",
    "beta": "b",
    "rc": "rc",
    "p": ".post",
}


def parse_composer_lock(text: str) -> list[tuple[str, str, str]]:
    """Parse a Composer-generated composer.lock JSON file.

    Returns a list of (package_name, version, scope) tuples where scope
    is "prod" for entries from the `packages` array and "dev" for
    `packages-dev`. Both arrays are walked.

    Filters out `source.type == "path"` entries (local references —
    OSV cannot cover them). All other source types (git / hg / svn /
    missing) are admitted; private-server packages will naturally fail
    to match the OSV-Packagist catalog.

    Package names are case-folded to lowercase (Packagist is
    case-insensitive). Versions have any leading `v` stripped
    (Composer allows `v1.2.3` and `1.2.3` interchangeably).

    Returns [] if JSON parsing fails or both arrays are absent.
    """
    import json as _json

    try:
        data = _json.loads(text)
    except (_json.JSONDecodeError, TypeError):
        return []
    if not isinstance(data, dict):
        return []

    out: list[tuple[str, str, str]] = []
    for scope_key, scope_tag in (("packages", "prod"), ("packages-dev", "dev")):
        entries = data.get(scope_key) or []
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name")
            version = entry.get("version")
            if not isinstance(name, str) or not isinstance(version, str):
                continue
            source = entry.get("source") or {}
            if isinstance(source, dict) and source.get("type") == "path":
                continue
            normalized_version = version[1:] if version[:1] in ("v", "V") else version
            out.append((name.lower(), normalized_version, scope_tag))

    return out


def _normalize_composer_version(s: str) -> str:
    """Convert a Composer version string into a PEP 440-compatible form.

    Composer stability flags map to PEP 440 as follows:
      -dev  → .devN  (default N=0)
      -alpha → aN
      -beta → bN
      -RC   → rcN
      -p    → .postN  (Composer "patch" stability)

    Leading `v` / `V` is stripped (e.g. `v1.2.3` → `1.2.3`).
    Build metadata (`+local`) is preserved — PEP 440 accepts local
    segments and compares by base version.
    """
    if not s:
        return s
    if s[:1] in ("v", "V"):
        s = s[1:]

    def _sub(m: re.Match[str]) -> str:
        flag = m.group(1).lower()
        num = m.group(2) or "0"
        return f"{_COMPOSER_STABILITY_MAP[flag]}{num}"

    return _COMPOSER_STABILITY_RE.sub(_sub, s)


def _safe_parse_composer_version(s: str):
    """Parse a Composer version into packaging.Version, or None on failure."""
    from packaging.version import InvalidVersion, Version
    if not s:
        return None
    try:
        return Version(_normalize_composer_version(s))
    except (InvalidVersion, TypeError):
        return None


def _is_composer_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
) -> bool:
    """True iff version satisfies introduced <= version < fixed.

    Either bound may be None: missing introduced means "from 0";
    missing fixed means "no upper bound" (still vulnerable).
    Returns False if the version string cannot be parsed (this
    includes Composer dev-branch aliases like `dev-master` /
    `1.x-dev` which are not real version numbers).
    """
    v = _safe_parse_composer_version(version)
    if v is None:
        return False
    if introduced is not None:
        intro = _safe_parse_composer_version(introduced)
        if intro is not None and intro > v:
            return False
    if fixed is not None:
        fix = _safe_parse_composer_version(fixed)
        if fix is not None and v >= fix:
            return False
    return True
