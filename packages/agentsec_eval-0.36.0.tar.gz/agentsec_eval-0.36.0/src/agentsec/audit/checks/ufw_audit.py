"""ufw 默认策略审计（Phase 7e.2）。

Pulls 'ufw status verbose'; emits 1 critical when inactive, otherwise
inspects the 'Default:' line and emits findings for non-deny incoming
(critical) and non-deny forward (high). IPv6 detection is deferred to
7e.5 because 'ufw status verbose' does not surface that field.
"""

from __future__ import annotations

import re

from ..findings import Finding
from ._firewall_common import detect_ufw, looks_like_perm_denied
from .base import Check, CheckContext

_DEFAULT_LINE = re.compile(
    r"^Default:\s*"
    r"(?P<incoming>\S+)\s*\(incoming\)"
    r",\s*(?P<outgoing>\S+)\s*\(outgoing\)"
    r"(?:,\s*(?P<routed>\S+)\s*\(routed\))?",
    re.M,
)


def parse_ufw_status(stdout: str) -> dict:
    """Returns {'status': 'active'|'inactive'|'unknown', 'incoming': str|None,
       'outgoing': str|None, 'routed': str|None}."""
    out = {"status": "unknown", "incoming": None, "outgoing": None, "routed": None}
    for line in stdout.splitlines():
        s = line.strip()
        if s.lower().startswith("status:"):
            value = s.split(":", 1)[1].strip().lower()
            if value in ("active", "inactive"):
                out["status"] = value
    m = _DEFAULT_LINE.search(stdout)
    if m:
        out["incoming"] = m.group("incoming")
        out["outgoing"] = m.group("outgoing")
        out["routed"] = m.group("routed")
    return out


class UfwAuditCheck(Check):
    id = "ufw_audit"

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_ufw(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 ufw 二进制"
            )
            return []

        result = ctx.executor.run(["ufw", "status", "verbose"])

        if result.rejected:
            ctx.status.skipped(
                f"{self.id}：ufw 命令被策略拒绝 ({result.reject_reason})"
            )
            return []
        if result.exit_code != 0:
            if looks_like_perm_denied(result.stderr):
                ctx.status.skipped(
                    f"{self.id}：权限不足，需 root 或 NOPASSWD sudoers"
                )
            else:
                ctx.status.skipped(f"{self.id}：ufw 退出码 {result.exit_code}")
            return []
        if not result.stdout.strip():
            ctx.status.skipped(f"{self.id}：ufw status 输出为空")
            return []

        parsed = parse_ufw_status(result.stdout)
        findings: list[Finding] = []

        if parsed["status"] == "inactive":
            findings.append(Finding(
                check=self.id, severity="critical",
                title="ufw 已安装但未启用",
                description=(
                    "默认接收策略 / 后端未激活 / IPv6 平行漏洞 — "
                    "CIS Linux 加固基线"
                ),
                evidence={
                    "status": "inactive",
                    "default_incoming": parsed["incoming"],
                    "default_forward": parsed["routed"],
                    "default_outgoing": parsed["outgoing"],
                },
                remediation="启用 ufw：`sudo ufw enable`；事先确认默认策略为 deny incoming",
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            ))
            return findings

        if parsed["status"] != "active":
            ctx.status.skipped(f"{self.id}：无法解析 'Status:' 字段")
            return []

        if parsed["incoming"] is None:
            ctx.status.skipped(
                f"{self.id}：'Default:' 行无法解析（active 状态但缺少默认策略字段）"
            )
            return []

        evidence = {
            "status": "active",
            "default_incoming": parsed["incoming"],
            "default_forward": parsed["routed"],
            "default_outgoing": parsed["outgoing"],
        }
        if parsed["incoming"] and parsed["incoming"].lower() not in ("deny", "reject"):
            findings.append(Finding(
                check=self.id, severity="critical",
                title="ufw 启用但默认 incoming 策略非 deny/reject",
                description="默认接收策略 — CIS Linux 加固基线",
                evidence=evidence,
                remediation="`sudo ufw default deny incoming`",
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            ))
        if parsed["routed"] and parsed["routed"].lower() not in ("deny", "reject", "disabled"):
            findings.append(Finding(
                check=self.id, severity="high",
                title="ufw 启用但默认 forward(routed) 策略非 deny/reject/disabled",
                description="默认转发策略 — CIS Linux 加固基线",
                evidence=evidence,
                remediation="`sudo ufw default deny routed`",
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            ))
        return findings
