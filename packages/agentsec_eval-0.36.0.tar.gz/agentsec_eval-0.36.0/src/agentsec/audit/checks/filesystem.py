"""filesystem check (spec §3.2 #5).

Walk OpenClaw's home dir (`ctx.profile.paths["openclaw_home"]`, materialized
to an absolute path per ADR-0004) for files with permissions wider than
0700 — anything granting world or group write is a Finding. Then `stat`
each hit to record its mode/owner/group as evidence.

The plain-stat strategy (one stat per find-hit) is intentional in v0.2.0:
the ssh_policy doesn't allow `find -printf` (which would print mode + path
in one call), and we'd rather pay an extra round-trip per finding than
relax the policy.
"""

from __future__ import annotations

from ..findings import Finding
from .base import Check, CheckContext


class FilesystemCheck(Check):
    id = "filesystem"
    _REQUIRED_PATHS: tuple[str, ...] = ("openclaw_home",)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not self.check_required_paths(ctx):
            return []

        home = ctx.profile.paths["openclaw_home"]
        find_argv = ["find", home, "-maxdepth", "4", "-type", "f", "-perm", "/o+w"]
        result = ctx.executor.run(find_argv)
        if result.rejected:
            ctx.status.skipped(f"filesystem find 被拒绝：{result.reject_reason}")
            return []
        if result.exit_code not in (0, 1):  # find returns 1 when no match
            ctx.status.skipped(f"filesystem find 退出码 {result.exit_code}")
            return []

        findings: list[Finding] = []
        for path in (line.strip() for line in result.stdout.splitlines() if line.strip()):
            stat_argv = ["stat", "-c", "%a %U %G %n", path]
            stat_res = ctx.executor.run(stat_argv)
            if stat_res.rejected or stat_res.exit_code != 0 or not stat_res.stdout:
                continue
            parts = stat_res.stdout.strip().split(maxsplit=3)
            if len(parts) != 4:
                continue
            mode, owner, group, _name = parts
            findings.append(self.make_finding(
                ctx,
                severity="high",
                title=f"世界可写文件（位于 {home} 下）：{path}",
                description=(
                    f"{path} 的权限位为 {mode}（owner={owner}，group={group}）。"
                    f"位于 {home} 下的文件应为 0600（目录 0700）；"
                    f"世界可写是同主机攻击者发起 prompt 注入的常见载体。"
                ),
                evidence={"path": path, "mode": mode, "owner": owner, "group": group},
                remediation=f"执行 `chmod 0600 {path}`（目录改 0700）。",
                threat_refs=[],
            ))
        return findings
