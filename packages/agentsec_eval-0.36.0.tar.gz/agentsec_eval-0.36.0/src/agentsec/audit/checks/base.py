"""Check ABC + CheckContext.

Each P0 check is a small Check subclass. The runner instantiates the
CheckContext once (with the SSHExecutor + Redactor + IOC paths), then
awaits each check's run().
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ..findings import Finding, Severity
from ..platform_profile import PlatformProfile

if TYPE_CHECKING:
    from ...config import LogReviewConfig


@dataclass
class CheckStatus:
    is_skipped: bool = False
    skip_reason: str | None = None
    is_not_applicable: bool = False
    not_applicable_reason: str | None = None

    def skipped(self, reason: str) -> None:
        self.is_skipped = True
        self.skip_reason = reason

    def not_applicable(self, reason: str) -> None:
        self.is_not_applicable = True
        self.not_applicable_reason = reason


@dataclass
class CheckContext:
    executor: Any  # SSHExecutor; typed Any to avoid import cycles in tests
    redactor: Any  # Redactor
    ioc_dir: Path | None
    profile: PlatformProfile
    status: CheckStatus = field(default_factory=CheckStatus)
    log_review_config: LogReviewConfig | None = None
    pip_lock_paths: tuple[str, ...] = ()
    go_lock_paths: tuple[str, ...] = ()
    cargo_lock_paths: tuple[str, ...] = ()
    maven_lock_paths: tuple[str, ...] = ()
    gem_lock_paths: tuple[str, ...] = ()
    composer_lock_paths: tuple[str, ...] = ()


class Check(ABC):
    id: str = ""  # subclass must override
    _REQUIRED_PATHS: tuple[str, ...] = ()

    def __init__(self):
        if not type(self).id:
            raise TypeError(
                f"Check subclass {type(self).__name__} must set class attribute `id`"
            )

    def check_required_paths(self, ctx: CheckContext) -> bool:
        """Returns True if the active profile has every key in _REQUIRED_PATHS;
        otherwise sets ctx.status.not_applicable(...) and returns False so the
        caller can early-return without running side effects."""
        for key in self._REQUIRED_PATHS:
            if key not in ctx.profile.paths:
                ctx.status.not_applicable(
                    f"{self.id}：profile {ctx.profile.name} 上缺少 paths.{key}"
                )
                return False
        return True

    def make_finding(
        self,
        ctx: CheckContext,
        *,
        severity: Severity,
        title: str,
        description: str,
        evidence: dict[str, Any],
        remediation: str,
        threat_refs: list[str],
    ) -> Finding:
        """Build a Finding with title / description / remediation and any
        string-valued evidence entries passed through `ctx.redactor.redact()`.

        Stage D's bug_006 mandated that every operator-visible string field
        carrying remote-stdout-derived bytes be redacted before leaving the
        check. Use this helper instead of constructing `Finding(...)`
        directly so a future provider-token pattern automatically covers
        every check.
        """
        redact = ctx.redactor.redact
        redacted_evidence = {
            k: (redact(v) if isinstance(v, str) else v)
            for k, v in evidence.items()
        }
        return Finding(
            check=self.id,
            severity=severity,
            title=redact(title),
            description=redact(description),
            evidence=redacted_evidence,
            remediation=redact(remediation),
            threat_refs=list(threat_refs),
        )

    @abstractmethod
    async def run(self, ctx: CheckContext) -> list[Finding]:
        ...
