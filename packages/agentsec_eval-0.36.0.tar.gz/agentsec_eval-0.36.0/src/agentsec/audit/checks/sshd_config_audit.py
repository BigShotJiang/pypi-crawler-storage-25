"""sshd_config baseline audit (Phase 7e).

Runs `sshd -T` to capture effective config (with defaults applied), parses
`key value` lines, compares against baseline, emits one Finding per
non-compliant key.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ..findings import Finding
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)


class SshdConfigAuditCheck(Check):
    id = "sshd_config_audit"

    def __init__(self):
        super().__init__()
        self._rules = yaml.safe_load(_BASELINE_PATH.read_text())["sshd"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"sshd_config_audit：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []
        result = ctx.executor.run(["sshd", "-T"])
        if result.rejected:
            ctx.status.skipped(
                f"sshd_config_audit 被策略拒绝：{result.reject_reason}"
            )
            return []
        if result.exit_code != 0:
            ctx.status.skipped(
                f"sshd_config_audit `sshd -T` 退出码 {result.exit_code}"
            )
            return []
        actual: dict[str, str] = {}
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            actual[parts[0].lower()] = parts[1].strip()
        findings: list[Finding] = []
        for rule in self._rules:
            key = rule["key"]
            current = actual.get(key)
            if current is None:
                continue
            if current != rule["must_equal"]:
                findings.append(Finding(
                    check=self.id,
                    severity=rule["severity"],
                    title=(
                        f"sshd_config {key} = {current!r}，"
                        f"基线要求 {rule['must_equal']!r}"
                    ),
                    description=rule["rationale"],
                    evidence={
                        "key": key,
                        "actual": current,
                        "expected": rule["must_equal"],
                    },
                    remediation=rule["remediation"],
                    threat_refs=["TI-LINUX-CIS-SSHD"],
                ))
        return findings
