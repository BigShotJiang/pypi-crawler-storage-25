"""Containerd 镜像 CVE 审计（Phase 7f.1）。

nerdctl 优先 / ctr 回退；docker 接管 containerd 时让位 docker_image_cve。
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import (
    _docker_takeover_active,
    _evaluate_image_tag,
    detect_containerd_runtime,
)
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"

_PERM_DENIED_SUBSTRINGS = ("permission denied", "operation not permitted")


def _looks_perm_denied(stderr: str) -> bool:
    s = stderr.lower()
    return any(needle in s for needle in _PERM_DENIED_SUBSTRINGS)


class ContainerdImageCveCheck(Check):
    id = "containerd_image_cve"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._patterns = baseline["image_patterns"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if _docker_takeover_active(ctx):
            ctx.status.not_applicable(
                f"{self.id}：检出 docker 后端为 containerd，由 docker_image_cve 评估"
            )
            return []
        bin_path, mode = detect_containerd_runtime(ctx)
        if mode is None:
            ctx.status.not_applicable(
                f"{self.id}：containerd 不可见"
            )
            return []
        if mode == "nerdctl":
            return self._run_nerdctl(ctx)
        else:
            return self._run_ctr(ctx)

    def _run_nerdctl(self, ctx: CheckContext) -> list[Finding]:
        result = ctx.executor.run(
            ["nerdctl", "images", "--format", "{{json .}}"]
        )
        if result.rejected or result.exit_code != 0:
            if _looks_perm_denied(result.stderr):
                ctx.status.skipped(f"{self.id}：权限不足")
            else:
                ctx.status.skipped(
                    f"{self.id}：nerdctl images 退出码 {result.exit_code}"
                )
            return []
        try:
            images = json.loads(result.stdout) if result.stdout.strip() else []
        except json.JSONDecodeError:
            ctx.status.skipped(f"{self.id}：nerdctl images 输出非 JSON")
            return []
        findings: list[Finding] = []
        for img in images:
            repo = img.get("Repository") or ""
            tag = img.get("Tag") or ""
            if not repo or not tag:
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_image_tag(
                    repo, tag, runtime="containerd",
                    baseline_image_patterns=self._patterns,
                )
            )
        return findings

    def _run_ctr(self, ctx: CheckContext) -> list[Finding]:
        result = ctx.executor.run(
            ["ctr", "--namespace", "default", "images", "list", "-q"]
        )
        if result.rejected or result.exit_code != 0:
            if _looks_perm_denied(result.stderr):
                ctx.status.skipped(f"{self.id}：权限不足")
            else:
                ctx.status.skipped(
                    f"{self.id}：ctr images list 退出码 {result.exit_code}"
                )
            return []
        findings: list[Finding] = []
        for line in result.stdout.splitlines():
            ref = line.strip()
            if not ref or ":" not in ref:
                continue
            # Split into repo:tag from the rightmost colon.
            # Full registry refs like docker.io/library/node:14 are common;
            # extract the short image name (last path component) so patterns
            # like "node:1[0-4]*" match regardless of registry prefix.
            repo_full, tag = ref.rsplit(":", 1)
            repo = repo_full.split("/")[-1]
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_image_tag(
                    repo, tag, runtime="containerd",
                    baseline_image_patterns=self._patterns,
                )
            )
        return findings
