"""Phase 7f Docker Check 共享 helper。"""

from __future__ import annotations

import fnmatch
import json
import os

from .base import CheckContext

_DOCKER_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/docker",
    "/usr/local/bin/docker",
    "/opt/homebrew/bin/docker",
)

_PODMAN_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/podman",
    "/usr/local/bin/podman",
    "/opt/homebrew/bin/podman",
)

_NERDCTL_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/local/bin/nerdctl",
    "/usr/bin/nerdctl",
)

_CTR_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/ctr",
    "/usr/local/bin/ctr",
)

_CONTAINERD_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/containerd",
    "/usr/local/bin/containerd",
)

_CONTAINERD_SOCKET = "/run/containerd/containerd.sock"


def _stat_probe(ctx: CheckContext, candidates: tuple[str, ...]) -> str | None:
    """Try each candidate path via `stat -c %n`; return first hit, None on all-miss."""
    for path in candidates:
        result = ctx.executor.run(["stat", "-c", "%n", path])
        if not result.rejected and result.exit_code == 0:
            return path
    return None


def detect_docker(ctx: CheckContext) -> str | None:
    """探测被审主机 docker 二进制路径。"""
    return _stat_probe(ctx, _DOCKER_BIN_CANDIDATES)


def detect_podman(ctx: CheckContext) -> str | None:
    """探测 podman 二进制路径；首个 stat 命中即返。"""
    return _stat_probe(ctx, _PODMAN_BIN_CANDIDATES)


def detect_nerdctl(ctx: CheckContext) -> str | None:
    """探测 nerdctl 二进制路径；首个 stat 命中即返。"""
    return _stat_probe(ctx, _NERDCTL_BIN_CANDIDATES)


def detect_ctr(ctx: CheckContext) -> str | None:
    """探测 ctr 二进制路径；首个 stat 命中即返。"""
    return _stat_probe(ctx, _CTR_BIN_CANDIDATES)


def detect_containerd_bin(ctx: CheckContext) -> str | None:
    """探测 containerd daemon 二进制路径。

    与 detect_ctr 区分开：detect_ctr 探 admin CLI，本函数探 daemon binary。
    containerd_daemon_audit 用此决定是否启动审计。
    """
    return _stat_probe(ctx, _CONTAINERD_BIN_CANDIDATES)


def detect_containerd_runtime(
    ctx: CheckContext,
) -> tuple[str | None, str | None]:
    """探测 containerd 运行时；nerdctl 优先，ctr 回退。

    同时检查 /run/containerd/containerd.sock 存在，避免装了 nerdctl
    但 containerd 未起的开发机误报。

    Returns (frontend_bin, mode) where mode ∈ {"nerdctl", "ctr", None}.
    """
    socket_present = ctx.executor.run(
        ["stat", "-c", "%n", _CONTAINERD_SOCKET]
    )
    if socket_present.rejected or socket_present.exit_code != 0:
        return (None, None)
    nerdctl_bin = detect_nerdctl(ctx)
    if nerdctl_bin is not None:
        return (nerdctl_bin, "nerdctl")
    ctr_bin = detect_ctr(ctx)
    if ctr_bin is not None:
        return (ctr_bin, "ctr")
    return (None, None)


def is_path_under(child: str, parent: str) -> bool:
    """Whether `child` equals or is located under `parent`.

    Uses os.path.commonpath for boundary matching (NEVER bare startswith,
    per OE-AUD4-001 — /etc/secrets must not match /etcother).
    """
    try:
        return os.path.commonpath([child, parent]) == parent
    except ValueError:
        return False


# Maps runtime name → TI namespace (without the leading "TI-").
# Kept without the literal "TI-" prefix so that check_threat_refs.py regex
# does not treat these mapping values as resolvable TI IDs.
_RUNTIME_NS_BY_RUNTIME = {
    "docker": "DOCKER",
    "podman": "PODMAN",
    "containerd": "CONTAINERD",
}


def _resolve_threat_ref(rule: dict, runtime: str) -> list[str]:
    """Build the threat_refs list for `runtime`. Two paths:
    1. rule has `threat_refs_template` (new helper-driven style) — render with prefix
    2. rule has `threat_refs` (legacy 7f docker style) — return as-is
    """
    if "threat_refs_template" in rule:
        ns = _RUNTIME_NS_BY_RUNTIME[runtime]
        prefix = "TI-" + ns
        return [rule["threat_refs_template"].format(prefix=prefix)]
    return list(rule.get("threat_refs", []))


def _evaluate_inspect(
    inspect_json: list[dict] | dict,
    *,
    runtime: str,
    rootless: bool = False,
    baseline_runtime_rules: list[dict],
) -> list[dict]:
    """Apply runtime baseline rules to docker-compat inspect JSON.

    Returns a list of Finding kwarg dicts. Caller wraps with `make_finding`.
    `evidence.runtime` and `threat_refs` populated per `runtime` arg.
    rule `runtime-root-user` severity downgraded medium → low when rootless=True.
    """
    if isinstance(inspect_json, list):
        if not inspect_json:
            return []
        container = inspect_json[0]
    else:
        container = inspect_json
    cfg = container.get("Config") or {}
    host_cfg = container.get("HostConfig") or {}
    findings: list[dict] = []

    rules_by_id = {r["id"]: r for r in baseline_runtime_rules}

    def _emit(rule_id: str, evidence_extra: dict, severity_override: str | None = None):
        rule = rules_by_id.get(rule_id)
        if rule is None:
            return
        severity = severity_override or rule["severity"]
        findings.append({
            "severity": severity,
            "title": rule["title"],
            "description": rule["description"],
            "evidence": {
                "runtime": runtime,
                "rule_id": rule_id,
                "container_id": container.get("Id", "")[:12],
                **evidence_extra,
            },
            "remediation": rule["remediation"],
            "threat_refs": _resolve_threat_ref(rule, runtime),
        })

    if host_cfg.get("Privileged"):
        _emit("runtime-privileged", {"privileged": True})

    if host_cfg.get("NetworkMode") == "host":
        _emit("runtime-host-net", {"network_mode": "host"})

    user = (cfg.get("User") or "").strip()
    if user in ("", "root", "0"):
        sev = "low" if rootless else None
        _emit("runtime-root-user", {"user": user}, severity_override=sev)

    binds = host_cfg.get("Binds") or []
    for bind in binds:
        if "/var/run/docker.sock" in bind:
            _emit("runtime-sock-mount", {"bind": bind})

    sensitive_paths = ["/", "/etc", "/root", "/proc", "/sys"]
    for bind in binds:
        if ":" not in bind:
            continue
        src = bind.split(":", 1)[0]
        for sensitive in sensitive_paths:
            if is_path_under(src, sensitive):
                _emit("runtime-host-fs-mount", {"bind": bind, "sensitive_path": sensitive})
                break

    dangerous_caps = {"SYS_ADMIN", "NET_ADMIN", "SYS_PTRACE"}
    cap_add = host_cfg.get("CapAdd") or []
    for cap in cap_add:
        cap_name = cap.replace("CAP_", "")
        if cap_name in dangerous_caps:
            _emit("runtime-cap-dangerous", {"cap": cap_name})

    security_opt = host_cfg.get("SecurityOpt") or []
    no_new_priv = any("no-new-privileges:true" in opt for opt in security_opt)
    if not no_new_priv and user in ("", "root", "0"):
        _emit("runtime-no-new-priv-missing", {"security_opt": list(security_opt)})

    return findings


def _evaluate_image_tag(
    repo: str,
    tag: str,
    *,
    runtime: str,
    baseline_image_patterns: list[dict],
) -> list[dict]:
    """fnmatch image_patterns against `<repo>:<tag>`. Returns Finding kwargs.

    Per spec §4.2, image_patterns TI refs are SHARED across runtimes (image
    content is runtime-agnostic). Uses "TI-" + "CONTAINER" prefix when
    threat_refs_template uses {prefix}, regardless of `runtime` arg —
    `runtime` field still populated in evidence for cross-runtime dedupe.

    Note: prefix is computed at call time via string concatenation ("TI-" + "CONTAINER")
    so check_threat_refs.py does not treat the construction site as a resolvable ID.
    """
    # Split to avoid static scanner treating the prefix itself as a TI ID ref.
    _image_ti_prefix = "TI-" + "CONTAINER"
    image_ref = f"{repo}:{tag}"
    findings: list[dict] = []
    for pattern_rule in baseline_image_patterns:
        if fnmatch.fnmatch(image_ref, pattern_rule["pattern"]):
            template = pattern_rule.get("threat_refs_template", "")
            if template:
                threat_refs = [template.format(prefix=_image_ti_prefix)]
            else:
                threat_refs = list(pattern_rule.get("threat_refs", []))
            findings.append({
                "severity": pattern_rule["severity"],
                "title": pattern_rule["title"],
                "description": pattern_rule["description"],
                "evidence": {
                    "runtime": runtime,
                    "image": image_ref,
                    "pattern_matched": pattern_rule["pattern"],
                },
                "remediation": pattern_rule["remediation"],
                "threat_refs": threat_refs,
            })
    return findings


_DOCKER_SOCKET_PATH = "/var/run/docker.sock"


def _docker_takeover_active(ctx: CheckContext) -> bool:
    """containerd 主机上 docker 是否接管？

    True 当 docker 二进制可见 AND /var/run/docker.sock 存在。containerd_*
    Check 用此判断是否让位 docker_* Check，避免双报。Phase 7f.1.1 从
    containerd_runtime_audit / containerd_image_cve 两处内联表达式提取。
    """
    if detect_docker(ctx) is None:
        return False
    result = ctx.executor.run(["stat", "-c", "%n", _DOCKER_SOCKET_PATH])
    return not result.rejected and result.exit_code == 0


def _parse_ctr_info(text: str) -> dict:
    """`ctr containers info <id>` JSON-shaped text → structured dict.

    Returns:
        {
            "privileged": bool,         # any of SYS_ADMIN/NET_ADMIN/SYS_PTRACE in caps
            "host_network": bool,        # network namespace has `path` field set
            "capabilities": list[str],   # effective caps with CAP_ prefix
            "root_user_uid": int,        # process.user.uid
            "no_new_privileges": bool,   # process.noNewPrivileges
        }

    Raises ValueError on JSON decode failure.
    """
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"ctr info not parseable: {e}") from e

    spec = data.get("Spec") or {}
    if not isinstance(spec, dict):
        spec = {}
    process = spec.get("process") or {}
    if not isinstance(process, dict):
        process = {}
    linux = spec.get("linux") or {}
    if not isinstance(linux, dict):
        linux = {}

    user = process.get("user") or {}
    if not isinstance(user, dict):
        user = {}
    uid = user.get("uid", 0)

    caps_section = process.get("capabilities") or {}
    if not isinstance(caps_section, dict):
        caps_section = {}
    capabilities = list(caps_section.get("effective", []))

    no_new_priv = bool(process.get("noNewPrivileges", False))

    # Privileged = any dangerous cap present
    dangerous = {"CAP_SYS_ADMIN", "CAP_NET_ADMIN", "CAP_SYS_PTRACE"}
    privileged = any(cap in dangerous for cap in capabilities)

    # Host network = network namespace has path (not just type)
    namespaces = linux.get("namespaces", []) or []
    host_network = any(
        ns.get("type") == "network" and ns.get("path")
        for ns in namespaces
    )

    return {
        "privileged": privileged,
        "host_network": host_network,
        "capabilities": capabilities,
        "root_user_uid": uid,
        "no_new_privileges": no_new_priv,
    }
