"""credential_audit check (spec §3.2 #9).

For each candidate credential file under the OpenClaw home dir, run
`stat -c "%a %U %G %n"`. If mode is wider than 0600 OR owner != ssh_user,
emit a Finding. Missing files are silently skipped (operator may not have
that credential type).

Two source-of-candidates:
  - `SENSITIVE_FILES` — historical hardcoded list at the top of `openclaw_home`.
  - `~/.openclaw/credentials/` — directory enumeration via `find`. This is the
    OpenClaw-recommended layout for per-provider tokens (Gemini key, Discord
    bot token, etc.) and was completely missed by the old hardcoded list (D4).

All evidence is Redactor-filtered before being attached to the Finding —
the file's contents are never read here, but the mode/owner output is.
"""

from __future__ import annotations

from ..findings import Finding
from .base import Check, CheckContext

# logical-name → relative path within ctx.profile.paths["openclaw_home"]
SENSITIVE_FILES = (
    "gateway.token",
    "signing.key",
    "openai.token",
    "id_rsa",
    "id_ed25519",
)

CREDENTIALS_SUBDIR = "credentials"


class CredentialAuditCheck(Check):
    id = "credential_audit"
    _REQUIRED_PATHS: tuple[str, ...] = ("openclaw_home",)

    def __init__(self, *, ssh_user: str):
        super().__init__()
        self._user = ssh_user

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not self.check_required_paths(ctx):
            return []

        home = ctx.profile.paths["openclaw_home"].rstrip("/") + "/"
        candidate_paths = [home + name for name in SENSITIVE_FILES]
        candidate_paths.extend(self._enumerate_credentials_dir(ctx, home))

        findings: list[Finding] = []
        seen: set[str] = set()
        for path in candidate_paths:
            if path in seen:
                continue
            seen.add(path)
            finding = self._stat_one(ctx, path)
            if finding is not None:
                findings.append(finding)
        return findings

    def _enumerate_credentials_dir(
        self, ctx: CheckContext, home: str,
    ) -> list[str]:
        """Return absolute paths of files directly under `<home>/credentials/`.

        Empty list when the directory does not exist, the executor blows up,
        or `find` returns anything other than success/no-such-dir — operators
        without per-provider credentials should not see findings.
        """
        creds_dir = home + CREDENTIALS_SUBDIR + "/"
        try:
            res = ctx.executor.run([
                "find", creds_dir, "-maxdepth", "1", "-type", "f",
            ])
        except Exception:
            return []
        if res.rejected or res.exit_code not in (0, 1) or not res.stdout:
            return []
        return [line.strip() for line in res.stdout.splitlines() if line.strip()]

    def _stat_one(self, ctx: CheckContext, path: str) -> Finding | None:
        res = ctx.executor.run(["stat", "-c", "%a %U %G %n", path])
        if res.rejected or res.exit_code != 0 or not res.stdout:
            return None
        parts = res.stdout.strip().split(maxsplit=3)
        if len(parts) != 4:
            return None
        mode, owner, group, _name = parts
        try:
            mode_oct = int(mode, 8)
        except ValueError:
            return None
        issues: list[str] = []
        exposed = []
        if mode_oct & 0o007:
            exposed.append("world(其他用户)")
        if mode_oct & 0o070:
            exposed.append("group(同组)")
        if exposed:
            issues.append(f"权限位 {mode} 允许 {' + '.join(exposed)} 访问")
        if owner != self._user:
            issues.append(f"owner={owner}，但 SSH 登录用户为 {self._user}")
        if not issues:
            return None
        return self.make_finding(
            ctx,
            severity="critical",
            title=f"凭据文件权限不安全：{path}",
            description=(
                f"{path} mode={mode} owner={owner} group={group}；问题："
                + "；".join(issues)
            ),
            evidence={"path": path, "mode": mode, "owner": owner, "group": group},
            remediation=f"执行 `chmod 0600 {path} && chown {self._user} {path}`",
            threat_refs=[],
        )
