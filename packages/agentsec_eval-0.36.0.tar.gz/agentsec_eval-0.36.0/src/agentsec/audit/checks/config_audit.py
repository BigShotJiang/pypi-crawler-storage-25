"""config_audit check (spec §3.2 #2).

Reads OpenClaw's running config via `openclaw config show --json`, compares
each baseline rule, emits one Finding per violation.

The `--json` flag is not present in OpenClaw v2026.2.x; the older CLI prints
human-readable output. We detect that via stderr (R2) and mark the check
not_applicable with a clear version-skew note rather than emitting a
generic "exit 1" skip. Parsing the legacy output shape is a follow-up.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from ..findings import Finding
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "config_baseline.yaml"

# Stderr fragments that signal "this CLI version doesn't recognize --json".
# Lower-cased; substring match.
_OLD_CLI_STDERR_FRAGMENTS: tuple[str, ...] = (
    "unknown option",
    "unrecognized option",
    "invalid option",
    "unknown command",
)


def _is_unsupported_cli(stderr: str) -> bool:
    s = (stderr or "").lower()
    return any(frag in s for frag in _OLD_CLI_STDERR_FRAGMENTS)


class ConfigAuditCheck(Check):
    id = "config_audit"
    _SUFFIX = ["config", "show", "--json"]
    _REQUIRED_PATHS: tuple[str, ...] = ("openclaw_home",)

    def __init__(self):
        super().__init__()
        self._rules = yaml.safe_load(_BASELINE_PATH.read_text())["rules"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not self.check_required_paths(ctx):
            return []
        bin_path = ctx.profile.paths.get("openclaw_bin", "openclaw")
        result = ctx.executor.run([bin_path, *self._SUFFIX])
        if result.rejected:
            ctx.status.skipped(f"config_audit 被策略拒绝：{result.reject_reason}")
            return []
        if result.exit_code != 0:
            if _is_unsupported_cli(result.stderr):
                ctx.status.not_applicable(
                    "config_audit：当前 OpenClaw 版本不支持 "
                    "`config show --json`（旧版人类可读输出尚未解析）"
                )
            else:
                ctx.status.skipped(f"config_audit 退出码 {result.exit_code}")
            return []
        try:
            config = json.loads(result.stdout)
        except json.JSONDecodeError as e:
            ctx.status.skipped(f"config_audit JSON 解析失败：{e}")
            return []

        findings: list[Finding] = []
        for rule in self._rules:
            actual = _get_dotted(config, rule["key"])
            expected = rule.get("must_equal")
            if actual != expected:
                findings.append(Finding(
                    check=self.id,
                    severity=rule["severity"],
                    title=rule["title"],
                    description=(
                        f"配置项 {rule['key']} 当前值为 {actual!r}，"
                        f"安全基线要求 must_equal={expected!r}"
                    ),
                    evidence={"key": rule["key"], "actual": actual, "expected": expected},
                    remediation=rule["remediation"],
                    threat_refs=[],
                ))
        return findings


def _get_dotted(obj: Any, dotted: str) -> Any:
    cur: Any = obj
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur
