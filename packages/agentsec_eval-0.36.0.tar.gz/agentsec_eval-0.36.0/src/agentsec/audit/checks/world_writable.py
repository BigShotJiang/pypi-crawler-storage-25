"""World-writable file scan (Phase 7e.1).

Scans static cron/tmp paths from baseline YAML plus dynamic OpenClaw paths
from `ctx.profile.paths` for files with world-writable bits set. Emits one
Finding per hit. The OpenClaw paths (openclaw_home, log_dir) are sourced
from the profile so they materialize to absolute paths at runtime — required
because non-interactive SSH shells do not expand ~ literals.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ..findings import Finding, Severity
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)
# Profile keys (and their severities) that contribute additional scan paths
# at runtime.  Order matters for finding emission ordering.
_PROFILE_PATH_KEYS: tuple[tuple[str, Severity], ...] = (
    ("openclaw_home", "high"),
    ("log_dir", "high"),
)


class WorldWritableCheck(Check):
    id = "world_writable_audit"
    # 不使用 `_REQUIRED_PATHS` —— 个别 path（如 LINUX_USER_MODE 的
    # log_dir）缺失是允许的，仅跳过该路径继续扫其它路径，整体仍
    # 产出 finding。`_REQUIRED_PATHS` 的 not_applicable 语义太粗。

    def __init__(self):
        super().__init__()
        section = yaml.safe_load(_BASELINE_PATH.read_text())["world_writable"]
        self._static_paths = section["scan_paths"]
        self._rationale = section["rationale"]
        self._remediation = section["remediation"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"world_writable_audit：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []

        scan_entries: list[tuple[str, Severity]] = []
        # Profile-injected dynamic paths first (high severity OpenClaw roots).
        for key, severity in _PROFILE_PATH_KEYS:
            value = ctx.profile.paths.get(key)
            if value:
                scan_entries.append((value, severity))
        # Static paths from baseline YAML.
        for entry in self._static_paths:
            scan_entries.append((entry["path"], entry["severity"]))

        findings: list[Finding] = []
        all_failed = True
        for path, severity in scan_entries:
            argv = ["find", path, "-maxdepth", "4", "-type", "f", "-perm", "/002"]
            result = ctx.executor.run(argv)
            if result.rejected or result.exit_code != 0:
                continue
            all_failed = False
            for line in result.stdout.splitlines():
                hit = line.strip()
                if not hit:
                    continue
                findings.append(Finding(
                    check=self.id,
                    severity=severity,
                    title=f"world-writable: {hit}",
                    description=self._rationale,
                    evidence={"path": hit, "scan_root": path},
                    remediation=self._remediation,
                    threat_refs=["TI-LINUX-CIS-WORLDWRITABLE"],
                ))
        if all_failed:
            ctx.status.skipped(
                "world_writable_audit 全部 find 调用失败（路径不存在或权限不足）"
            )
        return findings
