"""version_patch check (spec §3.2 #8).

Loads OpenClaw CVE entries from threat_intel.yaml (ids prefixed with
`{TI}-{OPENCLAW}-{CVE}-`); for each entry whose affected_versions specifier
matches the running OpenClaw version, emits a Finding with severity from the
entry and remediation pointing at fixed_in.

`affected_versions` may be a single PEP-440 specifier string or a list of them.
Entries without `affected_versions` are skipped (the CVE has no version range
yet, so we cannot make a confident match).

Version-string acquisition (R3): newer OpenClaw exposes
`openclaw version --json` returning `{"version": "X.Y.Z"}`. v2026.2.x has no
`version` subcommand; we fall back to `openclaw --version` which prints a
bare version string. Either path returns a Version-parseable string; if both
fail the check skips with a clear reason.
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml
from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version

from ..findings import Finding, Severity
from .base import Check, CheckContext

# Built at runtime so `scripts/check_threat_refs.py` (which scans source text
# for `TI-…` literals) doesn't flag this prefix as an unresolved reference.
_OPENCLAW_CVE_PREFIX = "-".join(["TI", "OPENCLAW", "CVE"]) + "-"


_CONFIDENCE_TO_SEVERITY: dict[str, Severity] = {
    "high": "high",
    "medium": "medium",
    "low": "low",
}


def _severity_from_cvss_or_confidence(
    cvss: float | None,
    confidence: str | None,
) -> Severity:
    """Pick a Finding severity for a TI entry. CVSS wins when present —
    spec §3.2 #8 mandates the score-driven mapping. When CVSS is null the
    bug_006 fallback is the entry's `confidence` so the Finding's severity
    cannot disagree with the same-row confidence reported in evidence.
    Defaults to "medium" so a row that's both null-CVSS and null-confidence
    doesn't silently inflate to high.
    """
    if cvss is not None:
        if cvss >= 9.0:
            return "critical"
        if cvss >= 7.0:
            return "high"
        if cvss >= 4.0:
            return "medium"
        return "low"
    if confidence:
        return _CONFIDENCE_TO_SEVERITY.get(confidence.lower(), "medium")
    return "medium"


class VersionPatchCheck(Check):
    id = "version_patch"
    _SUFFIX = ["version", "--json"]
    _REQUIRED_PATHS: tuple[str, ...] = ()  # works on both platforms; no not_applicable branch

    def __init__(self) -> None:
        super().__init__()
        self._db_index: dict[str, dict] = {}

    def _load_db(self, ctx: CheckContext) -> None:
        """Lazy-load cve_database.json once. Silently skip if unavailable."""
        if self._db_index:
            return
        if ctx.ioc_dir is None:
            return
        db_path = ctx.ioc_dir / "cve_database.json"
        if not db_path.exists():
            return
        try:
            rows: list[dict] = json.loads(db_path.read_text())
            self._db_index = {row["id"]: row for row in rows if "id" in row}
        except Exception:  # noqa: BLE001,S110 — best-effort load; falls back to empty index if file is malformed
            pass

    @staticmethod
    def _looks_like_unsupported_subcommand(stderr: str) -> bool:
        s = (stderr or "").lower()
        return any(
            frag in s for frag in (
                "unknown command", "unknown option",
                "unrecognized", "invalid option",
            )
        )

    def _read_version(self, ctx: CheckContext, bin_path: str) -> Version | None:
        """Return the running OpenClaw version, or None on failure (with
        ctx.status set). Tries `<bin> version --json` first; falls back to
        `<bin> --version` for v2026.2.x and earlier (R3)."""
        # Modern path: structured JSON.
        result = ctx.executor.run([bin_path, *self._SUFFIX])
        if result.rejected:
            ctx.status.skipped(f"version_patch 被策略拒绝：{result.reject_reason}")
            return None
        if result.exit_code == 0:
            try:
                payload = json.loads(result.stdout)
                version_str = payload.get("version")
                if version_str:
                    return self._parse_version(ctx, version_str)
            except json.JSONDecodeError:
                pass  # fall through to legacy path
            # exit 0 but no parseable version → fall through too

        # Legacy path: bare `--version` flag (e.g. v2026.2.x).
        if self._looks_like_unsupported_subcommand(result.stderr) or result.exit_code != 0:
            legacy = ctx.executor.run([bin_path, "--version"])
            if not legacy.rejected and legacy.exit_code == 0 and legacy.stdout.strip():
                return self._parse_version(ctx, legacy.stdout.strip())

        ctx.status.skipped(
            f"version_patch：无法确定 OpenClaw 版本"
            f"（json 退出码 {result.exit_code}，--version 不可用）"
        )
        return None

    @staticmethod
    def _parse_version(ctx: CheckContext, version_str: str) -> Version | None:
        # Strip a leading "openclaw " label that some CLIs prepend.
        s = version_str.strip()
        if " " in s:
            s = s.split()[-1]
        # PEP-440 doesn't accept `2026.2.3-1` literally; the dash form is a
        # post-release marker only when followed by digits with no separator.
        # Translate `X-N` → `X.postN` so older OpenClaw labels parse.
        if "-" in s:
            head, _, tail = s.rpartition("-")
            if tail.isdigit():
                s = f"{head}.post{tail}"
        try:
            return Version(s)
        except InvalidVersion as e:
            ctx.status.skipped(
                f"version_patch：无法解析版本字符串 {version_str!r}：{e}"
            )
            return None

    async def run(self, ctx: CheckContext) -> list[Finding]:
        self._load_db(ctx)
        bin_path = ctx.profile.paths.get("openclaw_bin", "openclaw")

        running = self._read_version(ctx, bin_path)
        if running is None:
            return []  # _read_version sets ctx.status with the reason

        intel_path = (
            (ctx.ioc_dir or Path(__file__).resolve().parents[1] / "ioc")
            / "threat_intel.yaml"
        )
        intel = yaml.safe_load(intel_path.read_text()) or []
        findings: list[Finding] = []
        for entry in intel:
            eid = entry.get("id", "")
            if not eid.startswith(_OPENCLAW_CVE_PREFIX):
                continue
            specs = entry.get("affected_versions")
            if not specs:
                continue
            spec_list = [specs] if isinstance(specs, str) else list(specs)
            try:
                if not any(running in SpecifierSet(s) for s in spec_list):
                    continue
            except InvalidSpecifier:
                continue
            evidence: dict = {
                "running_version": str(running),
                "affected_versions": spec_list,
                "fixed_in": entry.get("fixed_in"),
            }
            db_row = self._db_index.get(eid)
            if db_row is not None:
                evidence["cve_db_url"] = db_row.get("url")
                evidence["cve_db_confidence"] = db_row.get("confidence")
            severity = _severity_from_cvss_or_confidence(
                entry.get("cvss"), entry.get("confidence"),
            )
            if entry.get("kev") is True:
                severity = "critical"
                evidence["kev"] = True
            findings.append(Finding(
                check=self.id,
                severity=severity,
                title=f"{eid}：当前版本 {running} 受影响",
                description=entry.get("claim", ""),
                evidence=evidence,
                remediation=f"升级到 {entry.get('fixed_in', '<参见 CVE 详情>')} 或更高版本",
                threat_refs=[eid],
            ))
        return findings
