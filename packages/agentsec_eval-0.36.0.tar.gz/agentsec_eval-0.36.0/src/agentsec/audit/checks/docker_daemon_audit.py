"""Docker daemon 配置审计（Phase 7f）。

读 /etc/docker/daemon.json + `docker version --format json` +
`docker info --format json`，按 container_baseline.yaml:daemon 段规则
emit findings。
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import detect_docker
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"


def _version_falls_in_range(version: str, ranges: list[str]) -> bool:
    """Naive < 比较；version 形如 '24.0.7'。"""
    def _key(v: str) -> tuple[int, ...]:
        parts = []
        for p in v.split("."):
            m = re.match(r"^(\d+)", p)
            parts.append(int(m.group(1)) if m else 0)
        return tuple(parts)

    for r in ranges:
        r = r.strip()
        if r.startswith("<"):
            if _key(version) < _key(r[1:]):
                return True
    return False


class DockerDaemonAuditCheck(Check):
    id = "docker_daemon_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._rules = {r["id"]: r for r in baseline["daemon"]}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if detect_docker(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 docker 二进制（/usr/bin /usr/local/bin "
                "/opt/homebrew/bin 三处均无）"
            )
            return []

        daemon_result = ctx.executor.run(["cat", "/etc/docker/daemon.json"])
        version_result = ctx.executor.run(
            ["docker", "version", "--format", "{{json .}}"],
        )
        info_result = ctx.executor.run(
            ["docker", "info", "--format", "{{json .}}"],
        )

        daemon_ok = (not daemon_result.rejected) and daemon_result.exit_code == 0
        version_ok = (not version_result.rejected) and version_result.exit_code == 0
        info_ok = (not info_result.rejected) and info_result.exit_code == 0

        if not (daemon_ok or version_ok or info_ok):
            ctx.status.skipped(
                f"{self.id}：daemon.json + docker version + docker info 三调用全部失败"
            )
            return []

        findings: list[Finding] = []

        # daemon.json 解析（不存在视为全默认）
        daemon_cfg: dict = {}
        if daemon_ok and daemon_result.stdout.strip():
            try:
                daemon_cfg = json.loads(daemon_result.stdout)
            except json.JSONDecodeError:
                daemon_cfg = {}
        else:
            findings.append(self.make_finding(
                ctx, severity="info",
                title="Docker daemon.json 不存在或无法读取",
                description="daemon.json 缺失意味所有配置走默认值。",
                evidence={"rule_id": "daemon-json-missing", "path": "/etc/docker/daemon.json"},
                remediation="如需自定义安全策略，创建 /etc/docker/daemon.json。",
                threat_refs=[],
            ))

        # daemon-tls-exposed
        hosts = daemon_cfg.get("hosts") or []
        tlsverify = daemon_cfg.get("tlsverify", False)
        if any(isinstance(h, str) and h.startswith("tcp://") for h in hosts) and not tlsverify:
            findings.append(self._emit(ctx, "daemon-tls-exposed", evidence={
                "hosts": hosts, "tlsverify": tlsverify,
            }))

        # daemon-userns-off — 仅当字段缺失或为空字符串视为关闭
        userns = daemon_cfg.get("userns-remap")
        if not userns:
            findings.append(self._emit(ctx, "daemon-userns-off", evidence={
                "userns-remap": userns or "(unset)",
            }))

        # daemon-no-new-priv
        if not daemon_cfg.get("no-new-privileges", False):
            findings.append(self._emit(ctx, "daemon-no-new-priv", evidence={
                "no-new-privileges": daemon_cfg.get("no-new-privileges", False),
            }))

        # daemon-live-restore：先取 daemon.json；仅当键不存在时回退到 docker info LiveRestoreEnabled
        live_restore = daemon_cfg.get("live-restore")
        if live_restore is None and info_ok and info_result.stdout.strip():
            try:
                info_cfg = json.loads(info_result.stdout)
                live_restore = info_cfg.get("LiveRestoreEnabled", False)
            except json.JSONDecodeError:
                live_restore = False
        if not live_restore:
            findings.append(self._emit(ctx, "daemon-live-restore", evidence={
                "live-restore": bool(live_restore),
            }))

        # daemon-log-unbounded
        log_driver = daemon_cfg.get("log-driver", "json-file")
        log_opts = daemon_cfg.get("log-opts", {})
        if log_driver == "json-file" and "max-size" not in log_opts:
            findings.append(self._emit(ctx, "daemon-log-unbounded", evidence={
                "log-driver": log_driver, "log-opts": log_opts,
            }))

        # daemon-version-cve
        if version_ok and version_result.stdout.strip():
            try:
                version_cfg = json.loads(version_result.stdout)
                server_version = version_cfg.get("Server", {}).get("Version", "")
                rule = self._rules["daemon-version-cve"]
                known_bad = rule.get("known_bad_versions", [])
                if server_version and _version_falls_in_range(server_version, known_bad):
                    findings.append(self._emit(ctx, "daemon-version-cve", evidence={
                        "server_version": server_version,
                        "known_bad_ranges": known_bad,
                    }))
            except json.JSONDecodeError:
                pass

        return findings

    def _emit(self, ctx: CheckContext, rule_id: str, *, evidence: dict) -> Finding:
        rule = self._rules[rule_id]
        evidence_with_id = {"rule_id": rule_id, **evidence}
        return self.make_finding(
            ctx,
            severity=rule["severity"],
            title=rule["title"],
            description=rule["description"],
            evidence=evidence_with_id,
            remediation=rule["remediation"],
            threat_refs=list(rule["threat_refs"]),
        )
