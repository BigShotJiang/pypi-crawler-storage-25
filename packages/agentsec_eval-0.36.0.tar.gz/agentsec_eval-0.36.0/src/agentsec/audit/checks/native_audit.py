"""native_audit check (spec §3.2 #0): consume `openclaw security audit --json`.

Each entry in the native JSON output becomes one Finding tagged
check="native_audit". The remote `openclaw` may itself be compromised
(that's the whole point of running an external audit), so every text
field — evidence, title, description, remediation — flows through the
Redactor before being stored. Vulnerability scanners typically embed
offending values directly in the human-readable message rather than
under a structured evidence key, so symmetry matters here.

Severity normalization (R1): different OpenClaw versions emit different
severity vocabularies (e.g. v2026.2.x uses "warn"; later versions use
"medium"). Foreign values are mapped to the closest Finding Literal
rather than dropped — losing a finding to a string mismatch is worse
than approximating its severity.
"""

from __future__ import annotations

import json
from typing import Any

from ..findings import Finding, Severity
from .base import Check, CheckContext

_VALID_SEVERITIES: frozenset[Severity] = frozenset({
    "critical", "high", "medium", "low", "info",
})

_SEVERITY_ALIASES: dict[str, Severity] = {
    "warn": "medium",
    "warning": "medium",
    "error": "high",
    "fatal": "critical",
    "severe": "critical",
    "notice": "info",
    "debug": "info",
    "informational": "info",
}


def _normalize_severity(raw: str) -> Severity:
    """Coerce a foreign severity string into the Finding Literal set.

    Direct match → as-is; known alias → mapped value; unknown → "medium"
    (loud-but-not-loudest default so the finding survives review)."""
    if not raw:
        return "medium"
    s = raw.strip().lower()
    if s in _VALID_SEVERITIES:
        # `s` was checked against the Severity literal frozenset; the cast is
        # safe but pyright can't narrow `str` through frozenset membership.
        return s  # pyright: ignore[reportReturnType]
    return _SEVERITY_ALIASES.get(s, "medium")


class NativeAuditCheck(Check):
    id = "native_audit"
    _SUFFIX = ["security", "audit", "--json"]
    _REQUIRED_PATHS: tuple[str, ...] = ("openclaw_home",)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not self.check_required_paths(ctx):
            return []
        bin_path = ctx.profile.paths.get("openclaw_bin", "openclaw")
        result = ctx.executor.run([bin_path, *self._SUFFIX])
        if result.rejected:
            ctx.status.skipped(f"native_audit 被策略拒绝：{result.reject_reason}")
            return []
        if result.exit_code != 0:
            ctx.status.skipped(f"native_audit 退出码 {result.exit_code}")
            return []
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError as e:
            ctx.status.skipped(f"native_audit JSON 解析失败：{e}")
            return []

        findings: list[Finding] = []
        for entry in payload.get("findings", []):
            evidence = self._redact_dict(ctx.redactor, entry.get("evidence", {}))
            findings.append(Finding(
                check=self.id,
                severity=_normalize_severity(entry.get("severity", "")),
                title=ctx.redactor.redact(entry.get("title", "<missing>")),
                description=ctx.redactor.redact(entry.get("description", "")),
                evidence=evidence,
                remediation=ctx.redactor.redact(entry.get("remediation", "")),
                threat_refs=list(entry.get("threat_refs", [])),
            ))
        return findings

    @staticmethod
    def _redact_dict(redactor, d: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for k, v in d.items():
            if isinstance(v, str):
                out[k] = redactor.redact(v)
            elif isinstance(v, dict):
                out[k] = NativeAuditCheck._redact_dict(redactor, v)
            elif isinstance(v, list):
                out[k] = [
                    redactor.redact(item) if isinstance(item, str) else item
                    for item in v
                ]
            else:
                out[k] = v
        return out
