"""firewalld 主机防火墙审计（Phase 7e.3）。

Pulls 'firewall-cmd --state' + '--get-default-zone' + '--list-all-zones'
and emits one Finding per ACCEPT-target zone (default zone = critical,
other active zones = high). Service-stopped emits 1 critical and returns
without running the remaining commands. Cross-talk yield: when iptables
or nftables Checks see firewalld-injected chains/tables they go
not_applicable; this Check is the canonical evaluator for firewalld
hosts.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from ..findings import Finding
from ._firewall_common import detect_firewalld, looks_like_perm_denied
from .base import Check, CheckContext


@dataclass(frozen=True)
class ZoneInfo:
    name: str
    target: str
    is_active: bool
    is_default: bool


_ZONE_HEADER = re.compile(r"^(\S+)(?:\s+\(active\))?\s*$")
_INDENTED_TARGET = re.compile(r"^\s+target:\s+(\S+)\s*$")
_INDENTED_INTERFACES = re.compile(r"^\s+interfaces:\s*(.*)$")
_INDENTED_SOURCES = re.compile(r"^\s+sources:\s*(.*)$")


def parse_firewalld_zones(stdout: str, *, default_zone: str) -> list[ZoneInfo]:
    """Slice 'firewall-cmd --list-all-zones' output into per-zone records.

    Each zone block starts with a header line that has NO leading
    whitespace and contains the zone name (optionally followed by
    '(active)'). Subsequent indented lines carry the zone's fields.
    'target:' is captured directly; 'is_active' is True if the header
    has the (active) marker OR if 'interfaces:' / 'sources:' is non-empty
    (fallback for ancient firewalld versions that omit the marker).
    """
    zones: list[ZoneInfo] = []
    current_name: str | None = None
    current_target: str = ""
    current_active: bool = False

    def _flush() -> None:
        if current_name is None:
            return
        zones.append(ZoneInfo(
            name=current_name,
            target=current_target,
            is_active=current_active,
            is_default=(current_name == default_zone),
        ))

    for raw in stdout.splitlines():
        if not raw.strip():
            continue
        if not raw[0].isspace():
            # zone header
            _flush()
            m = _ZONE_HEADER.match(raw)
            if m is None:
                current_name = None
                continue
            current_name = m.group(1)
            current_target = ""
            current_active = "(active)" in raw
            continue
        # indented line
        m = _INDENTED_TARGET.match(raw)
        if m:
            current_target = m.group(1)
            continue
        m = _INDENTED_INTERFACES.match(raw)
        if m and m.group(1).strip():
            current_active = True
            continue
        m = _INDENTED_SOURCES.match(raw)
        if m and m.group(1).strip():
            current_active = True
            continue

    _flush()
    return zones


class FirewalldAuditCheck(Check):
    id = "firewalld_audit"

    def _skip_if_rejected_or_perm_denied(
        self,
        ctx: CheckContext,
        result: object,
        *,
        cmd_label: str,
    ) -> bool:
        """Check `rejected` and stderr-perm-denied paths. Returns True if status
        was set (caller should return []). Otherwise False."""
        if getattr(result, "rejected", False):
            ctx.status.skipped(
                f"{self.id}：{cmd_label} 被策略拒绝 ({result.reject_reason})"  # type: ignore[attr-defined]
            )
            return True
        exit_code = getattr(result, "exit_code", 0)
        stderr = getattr(result, "stderr", "")
        if exit_code != 0 and looks_like_perm_denied(stderr):
            ctx.status.skipped(
                f"{self.id}：权限不足，需 root 或 NOPASSWD sudoers "
                "（在该主机为执行用户配置 NOPASSWD sudoers，"
                "或以 root 身份运行 agentsec server-audit）"
            )
            return True
        return False

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_firewalld(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 firewall-cmd 二进制"
            )
            return []

        # Cmd #1: --state
        state = ctx.executor.run(["firewall-cmd", "--state"])
        if self._skip_if_rejected_or_perm_denied(
            ctx, state, cmd_label="firewall-cmd --state"
        ):
            return []
        if state.exit_code != 0:
            return [self.make_finding(
                ctx,
                severity="critical",
                title="firewalld 已安装但未启用",
                description=(
                    "firewalld 未运行，主机防火墙策略未加载 — "
                    "CIS Linux 加固基线"
                ),
                evidence={"state_exit_code": state.exit_code,
                          "state_stdout": state.stdout.strip()},
                remediation="`sudo systemctl enable --now firewalld`",
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            )]

        # Cmd #2: --get-default-zone
        dz = ctx.executor.run(["firewall-cmd", "--get-default-zone"])
        if self._skip_if_rejected_or_perm_denied(
            ctx, dz, cmd_label="firewall-cmd --get-default-zone"
        ):
            return []
        if dz.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：firewall-cmd --get-default-zone 退出码 {dz.exit_code}"
            )
            return []
        if not dz.stdout.strip():
            ctx.status.skipped(
                f"{self.id}：firewall-cmd --get-default-zone 输出为空"
            )
            return []
        default_zone = dz.stdout.strip().split()[0]

        # Cmd #3: --list-all-zones
        la = ctx.executor.run(["firewall-cmd", "--list-all-zones"])
        if self._skip_if_rejected_or_perm_denied(
            ctx, la, cmd_label="firewall-cmd --list-all-zones"
        ):
            return []
        if la.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：firewall-cmd --list-all-zones 退出码 {la.exit_code}"
            )
            return []
        if not la.stdout.strip():
            ctx.status.skipped(
                f"{self.id}：firewall-cmd --list-all-zones 输出为空"
            )
            return []

        zones = parse_firewalld_zones(la.stdout, default_zone=default_zone)
        candidates = [z for z in zones if z.is_active or z.is_default]

        findings: list[Finding] = []
        blob_sha = hashlib.sha256(la.stdout.encode("utf-8")).hexdigest()
        for z in candidates:
            if z.target != "ACCEPT":
                continue
            severity = "critical" if z.is_default else "high"
            title = (
                f"firewalld 默认 zone {z.name} target=ACCEPT（应为 default/DROP/REJECT）"
                if z.is_default else
                f"firewalld active zone {z.name} target=ACCEPT"
            )
            findings.append(self.make_finding(
                ctx,
                severity=severity,
                title=title,
                description=(
                    "默认接收策略 / 后端未激活 / IPv6 平行漏洞 — "
                    "CIS Linux 加固基线"
                ),
                evidence={
                    "zone": z.name,
                    "target": z.target,
                    "is_default": z.is_default,
                    "is_active": z.is_active,
                    "blob_sha256": blob_sha,
                },
                remediation=(
                    f"`sudo firewall-cmd --permanent --zone={z.name} "
                    f"--set-target=default && sudo firewall-cmd --reload`"
                ),
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            ))
        return findings
