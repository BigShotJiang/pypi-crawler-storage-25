"""log_review check (spec §3.2 #4).

Scans OpenClaw logs for attack-signature matches. Two backends:

* Files (LINUX, MACOS): list `paths.log_dir`, then `grep -i -c -F` each
  signature against each file. Output: 1 finding per (signature, log_path).
* Journald (LINUX_USER_MODE): `journalctl --no-pager --output=cat -u <unit>
  --since "<N> hours ago" --lines <N>` for each unit, then run fixed-string
  matching locally (no remote `--grep` — that is ERE regex and breaks the
  -F semantics; no remote pipe — policy rejects shell metacharacters).

Both backends return at most one severity=info "truncation" finding per
run when the scan is incomplete (file count cap / line cap / byte cap).
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ...config import LogReviewConfig
from ..findings import Finding
from ..platform_profile import FileLogSource, JournaldLogSource
from .base import Check, CheckContext

_MAX_LOG_FILES = 200
_MAX_OUTPUT_BYTES = 1_048_576    # mirrors ssh_policy.yaml max_output_bytes
_BYTE_TRUNCATION_THRESHOLD = 0.95  # ≥95% of cap is treated as truncated


class LogReviewCheck(Check):
    id = "log_review"
    _REQUIRED_PATHS: tuple[str, ...] = ()  # gate moves to log_source dispatch

    async def run(self, ctx: CheckContext) -> list[Finding]:
        src = ctx.profile.log_source
        if src is None:
            ctx.status.not_applicable("log_review:当前平台未暴露日志源")
            return []
        sigs = self._load_signatures(ctx)
        if sigs is None:
            return []  # _load_signatures already set ctx.status
        if isinstance(src, FileLogSource):
            return await self._scan_files(ctx, src, sigs)
        if isinstance(src, JournaldLogSource):
            return await self._scan_journald(ctx, src, sigs)
        # Defensive — discriminated union only allows the two above.
        ctx.status.skipped(f"log_review:未知 log_source kind {type(src).__name__}")
        return []

    def _load_signatures(self, ctx: CheckContext) -> list[dict] | None:
        if ctx.ioc_dir is None:
            ctx.status.skipped("log_review:ioc_dir 未配置")
            return None
        sigs_path = Path(ctx.ioc_dir) / "attack_signatures.yaml"
        if not sigs_path.exists():
            ctx.status.skipped(f"log_review:{sigs_path} 缺失")
            return None
        return yaml.safe_load(sigs_path.read_text()) or []

    async def _scan_files(
        self, ctx: CheckContext, src: FileLogSource, sigs: list[dict],
    ) -> list[Finding]:
        log_dir = src.log_dir
        list_res = ctx.executor.run([
            "find", log_dir, "-maxdepth", "2", "-type", "f", "-name", "*.log",
        ])
        if list_res.rejected or list_res.exit_code not in (0, 1):
            ctx.status.skipped(f"log_review:日志列表 find 退出码 {list_res.exit_code}")
            return []
        all_log_paths = [
            line.strip() for line in list_res.stdout.splitlines() if line.strip()
        ]
        truncated = max(0, len(all_log_paths) - _MAX_LOG_FILES)
        log_paths = all_log_paths[:_MAX_LOG_FILES]

        findings: list[Finding] = []
        if truncated:
            findings.append(self.make_finding(
                ctx,
                severity="info",
                title=(
                    f"log_review 仅扫描了 {log_dir} 下 {len(all_log_paths)} 个日志文件"
                    f"中的前 {_MAX_LOG_FILES} 个"
                ),
                description=(
                    f"`{log_dir}` 共 {len(all_log_paths)} 个日志文件，本次仅扫描了"
                    f"前 {_MAX_LOG_FILES} 个，{truncated} 个被跳过。`find` 调用的 1 MiB"
                    f" stdout 上限可能在更上游已截断列表 —— 请把 log_dir 收窄到更小的"
                    f"子目录，或把更早的日志轮转出审计范围以获得完整覆盖。"
                ),
                evidence={
                    "log_dir": log_dir,
                    "scanned": _MAX_LOG_FILES,
                    "skipped": truncated,
                },
                remediation=(
                    "将 log_dir 收窄到更小的子目录（如仅当天日志），"
                    "或将更早的日志轮转出审计范围。"
                ),
                threat_refs=[],
            ))
        for sig in sigs:
            for log_path in log_paths:
                res = ctx.executor.run([
                    "grep", "-i", "-c", "-F", sig["pattern"], log_path,
                ])
                if res.rejected:
                    continue
                try:
                    count = int(res.stdout.strip() or "0")
                except ValueError:
                    continue
                if count <= 0:
                    continue
                findings.append(self.make_finding(
                    ctx,
                    severity=sig["severity"],
                    title=f"攻击特征 {sig['id']} 在 {log_path} 命中 {count} 次",
                    description=sig["claim"],
                    evidence={
                        "signature_id": sig["id"],
                        "log_path": log_path,
                        "match_count": count,
                    },
                    remediation=(
                        "查阅相关日志条目，结合时间线进行关联分析；"
                        "如涉及任何凭据，请考虑轮换。"
                    ),
                    threat_refs=list(sig.get("threat_refs", [])),
                ))
        return findings

    async def _scan_journald(
        self, ctx: CheckContext, src: JournaldLogSource, sigs: list[dict],
    ) -> list[Finding]:
        cfg = ctx.log_review_config or LogReviewConfig()
        since = f"{cfg.journald_since_hours} hours ago"
        lines_cap = cfg.journald_max_lines

        findings: list[Finding] = []
        successes = 0
        truncation_reason: str | None = None  # "lines_cap" or "byte_cap"
        truncation_unit: str | None = None
        for unit in src.units:
            argv = [
                "journalctl",
                *(["--user"] if src.user else []),
                "--no-pager", "--output=cat",
                "-u", unit,
                "--since", since,
                "--lines", str(lines_cap),
            ]
            res = ctx.executor.run(argv)
            if res.rejected or res.exit_code != 0:
                continue
            successes += 1
            text = res.stdout

            # Truncation signal: track first observed reason; later units do
            # not overwrite (one info finding per run is enough).
            if truncation_reason is None:
                line_count = text.count("\n")
                # Prefer the executor's actual cap so we don't drift from
                # ssh_policy.yaml.  Fall back to the module constant when the
                # executor doesn't expose a policy (e.g. test stubs).
                cap = getattr(
                    getattr(ctx.executor, "_policy", None),
                    "max_output_bytes",
                    _MAX_OUTPUT_BYTES,
                )
                byte_count = res.bytes_out
                if line_count >= lines_cap:
                    truncation_reason = "lines_cap"
                    truncation_unit = unit
                elif byte_count >= int(cap * _BYTE_TRUNCATION_THRESHOLD):
                    truncation_reason = "byte_cap"
                    truncation_unit = unit

            findings.extend(self._match_journal_text(
                ctx, src=src, unit=unit, text=text, sigs=sigs,
            ))

        if successes == 0:
            ctx.status.skipped("log_review:所有 unit 均不可读")
            return []

        if truncation_reason is not None:
            findings.append(self.make_finding(
                ctx,
                severity="info",
                title=(
                    f"log_review journald 扫描覆盖不全（{truncation_reason}）"
                ),
                description=(
                    f"unit `{truncation_unit}` 的 journald 输出在本次扫描中"
                    f"撞到{'行数' if truncation_reason == 'lines_cap' else '字节'}"
                    f"上限，意味着窗口内可能有更早的日志条目未被读到。"
                    f"请提高 `journald_max_lines` 或缩短 `journald_since_hours`，"
                    f"或拆分到多个时间段重跑。"
                ),
                evidence={
                    "reason": truncation_reason,
                    "unit": truncation_unit,
                    "since_hours": cfg.journald_since_hours,
                    "lines_cap": lines_cap,
                },
                remediation=(
                    "调整 server_audit.log_review.journald_since_hours 或 "
                    "journald_max_lines，必要时分段扫描。"
                ),
                threat_refs=[],
            ))
        return findings

    def _match_journal_text(
        self, ctx: CheckContext, *,
        src: JournaldLogSource, unit: str, text: str,
        sigs: list[dict],
    ) -> list[Finding]:
        """Run case-insensitive fixed-string matching on `text` for every
        signature. Mirrors `grep -i -c -F` semantics so file-backed and
        journald-backed scans produce comparable findings.

        Evidence is kept minimal (signature_id, unit, match_count) so that
        fingerprints remain stable across config changes (journald_since_hours,
        journald_max_lines). Config-level params belong on the truncation info
        finding, not on per-signature findings.
        """
        lowered_lines = [line.lower() for line in text.splitlines()]
        out: list[Finding] = []
        for sig in sigs:
            needle = sig["pattern"].lower()
            count = sum(1 for ln in lowered_lines if needle in ln)
            if count <= 0:
                continue
            out.append(self.make_finding(
                ctx,
                severity=sig["severity"],
                title=f"攻击特征 {sig['id']} 在 unit {unit} 命中 {count} 次",
                description=sig["claim"],
                evidence={
                    "signature_id": sig["id"],
                    "unit": unit,
                    "match_count": count,
                },
                remediation=(
                    "查阅相关 journald 条目（journalctl --user -u <unit>），"
                    "结合时间线进行关联分析；如涉及任何凭据，请考虑轮换。"
                ),
                threat_refs=list(sig.get("threat_refs", [])),
            ))
        return out
