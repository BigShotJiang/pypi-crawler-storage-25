"""Podman 镜像 CVE 审计（Phase 7f.1）。

`podman images --format json` → 逐 image 调 `_evaluate_image_tag` 套
image_patterns 段 fnmatch 规则。

流程：
1. profile gating — 仅 linux / linux_user_mode；macOS → not_applicable
2. detect_podman gating — 未检出二进制 → not_applicable
3. 运行 `podman images --format {{json .}}`
   - rejected 或 exit≠0 → skipped（权限拒绝时特殊提示）
   - JSONDecodeError → skipped("输出非 JSON")
4. 对每条 image 记录读取 Repository + Tag，任一缺失则跳过
5. 调 _evaluate_image_tag(repo, tag, runtime="podman", ...) → Finding 列表
6. 全部 Finding 经 make_finding → Redactor 过滤后返回
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import _evaluate_image_tag, detect_podman
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"

_PERM_DENIED_SUBSTRINGS = ("permission denied", "operation not permitted")


def _looks_perm_denied(stderr: str) -> bool:
    s = stderr.lower()
    return any(needle in s for needle in _PERM_DENIED_SUBSTRINGS)


class PodmanImageCveCheck(Check):
    id = "podman_image_cve"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._patterns = baseline["image_patterns"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_podman(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 podman 二进制"
            )
            return []

        result = ctx.executor.run(["podman", "images", "--format", "{{json .}}"])
        if result.rejected or result.exit_code != 0:
            if _looks_perm_denied(result.stderr):
                ctx.status.skipped(f"{self.id}：权限不足")
            else:
                ctx.status.skipped(
                    f"{self.id}：podman images 退出码 {result.exit_code}"
                )
            return []

        try:
            images = json.loads(result.stdout) if result.stdout.strip() else []
        except json.JSONDecodeError:
            ctx.status.skipped(f"{self.id}：podman images 输出非 JSON")
            return []

        findings: list[Finding] = []
        for img in images:
            repo = img.get("Repository") or ""
            tag = img.get("Tag") or ""
            if not repo or not tag:
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_image_tag(
                    repo, tag,
                    runtime="podman",
                    baseline_image_patterns=self._patterns,
                )
            )
        return findings
