"""process_forensics check (spec §3.2 #7).

Joins listening-socket output (`ss -tlnp` / `lsof -i -n -P`) with `ps` output
to flag any TCP/UDP listener whose owning process is *not* OpenClaw. The join
happens in Python (no shell pipes — the policy bans them).

`ss` and `lsof` formats differ between Linux and macOS, so we parse both.
The Finding evidence carries the port, pid, user, and (Redactor-filtered) cmd.
"""

from __future__ import annotations

import re

from ..findings import Finding
from .base import Check, CheckContext

_SS_PID_RE = re.compile(r'pid=(\d+)')
_SS_PORT_RE = re.compile(r'\S+:(\d+)\s+\S+:\*')
_LSOF_LINE_RE = re.compile(
    r'^\S+\s+(\d+)\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+TCP\s+\S*:(\d+)\s+\(LISTEN\)'
)


class ProcessForensicsCheck(Check):
    id = "process_forensics"
    _REQUIRED_PATHS: tuple[str, ...] = ()  # platform-agnostic; probes from profile.listening_check

    async def run(self, ctx: CheckContext) -> list[Finding]:
        listeners = []  # list of (port, pid)
        any_probe_ok = False
        for argv in ctx.profile.listening_check:
            res = ctx.executor.run(argv)
            if res.rejected or res.exit_code != 0:
                continue
            any_probe_ok = True
            listeners.extend(self._parse_listeners(argv, res.stdout))
        if not any_probe_ok:
            ctx.status.skipped("process_forensics：所有监听端口探测均失败")
            return []

        ps_res = ctx.executor.run(["ps", "-eo", "user,pid,ppid,cmd"])
        if ps_res.rejected or ps_res.exit_code != 0:
            ctx.status.skipped("process_forensics：ps 命令不可用")
            return []

        ps_index: dict[int, dict] = {}
        for line in ps_res.stdout.splitlines()[1:]:  # skip header
            parts = line.split(maxsplit=3)
            if len(parts) != 4:
                continue
            user, pid_s, _ppid, cmd = parts
            try:
                ps_index[int(pid_s)] = {"user": user, "cmd": cmd}
            except ValueError:
                continue

        findings: list[Finding] = []
        for port, pid in listeners:
            proc = ps_index.get(pid)
            if proc is None:
                continue
            if "openclaw" in proc["cmd"].lower():
                continue
            findings.append(self.make_finding(
                ctx,
                severity="high",
                title=f"非 OpenClaw 进程占用监听端口 {port}",
                description=(
                    f"PID {pid}（{proc['cmd']}）占用了端口 {port} 的 LISTEN socket，"
                    f"但其命令名不含 'openclaw'。请排查是否存在旁挂进程、后门或"
                    f"供应链植入。"
                ),
                evidence={"port": port, "pid": pid, "user": proc["user"], "cmd": proc["cmd"]},
                remediation=(
                    "确认该进程是否合法；若非法请终止进程并轮换相关凭据。"
                ),
                threat_refs=[],
            ))
        return findings

    @staticmethod
    def _parse_listeners(argv: list[str], stdout: str) -> list[tuple[int, int]]:
        out: list[tuple[int, int]] = []
        if argv[0] == "ss":
            for line in stdout.splitlines():
                if "LISTEN" not in line and "UNCONN" not in line:
                    continue
                m_port = _SS_PORT_RE.search(line)
                m_pid = _SS_PID_RE.search(line)
                if not (m_port and m_pid):
                    continue
                try:
                    out.append((int(m_port.group(1)), int(m_pid.group(1))))
                except ValueError:
                    continue
        elif argv[0] == "lsof":
            for line in stdout.splitlines():
                m = _LSOF_LINE_RE.match(line)
                if not m:
                    continue
                try:
                    out.append((int(m.group(2)), int(m.group(1))))
                except ValueError:
                    continue
        return out
