"""plugin_static check (spec §3.2 #6).

Inventories installed OpenClaw skills via `openclaw skills list --json` and
matches each against `clawhavoc_skills.json`. Also scans skill Python source
files under `profile.paths["skills_dir"]` for dangerous API calls using the
evaluator-side Python ast module.

Lookup order is sha256-first, name-second (bug_007): a non-null sha is the
strong signal — name is what the gateway reports and may have been changed
by an attacker after the IOC was published. v0.2.0's seeded
`clawhavoc_skills.json` rows all carry `sha256: null` (no public sha
available at seed time), so today the sha index is effectively empty and
matches fall through to the name index. As soon as a real sha is added,
hostile renames stop evading detection.
"""

from __future__ import annotations

import json
from pathlib import Path

from ..findings import Finding
from .base import Check, CheckContext

# Call-based danger patterns: matched via ast.Call nodes only.
# Keys are human-readable category names used in finding evidence.
_DANGER_CALLS: dict[str, set[tuple[str, str]]] = {
    "code_execution": {
        ("subprocess", "run"), ("subprocess", "Popen"),
        ("subprocess", "call"), ("subprocess", "check_output"),
        ("os", "system"), ("os", "popen"),
    },
    "dynamic_eval": {
        ("builtins", "eval"), ("builtins", "exec"),
    },
    "network_exfiltration": {
        ("requests", "get"), ("requests", "post"), ("requests", "request"),
        ("urllib.request", "urlopen"),
        ("httpx", "get"), ("httpx", "post"), ("httpx", "request"),
    },
    "raw_socket": {
        ("socket", "connect"), ("socket", "create_connection"),
    },
}

# Attribute-access danger patterns: matched via bare ast.Attribute nodes.
# Separate from _DANGER_CALLS to avoid double-counting (ast.walk visits both
# a Call node and the Attribute inside its func).
_DANGER_ATTRS: dict[str, set[tuple[str, str]]] = {
    "env_access": {
        ("os", "environ"),
    },
}


class PluginStaticCheck(Check):
    id = "plugin_static"
    _SUFFIX = ["skills", "list", "--json"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        findings: list[Finding] = []
        findings.extend(self._ioc_scan(ctx))
        # _ioc_scan sets ctx.status.skipped when basic prerequisites are
        # absent (no ioc_dir, no DB file). Skip AST scan too — if the check
        # environment isn't configured, AST results are not meaningful.
        if not ctx.status.is_skipped:
            findings.extend(await self._ast_scan(ctx))
        return findings

    # ------------------------------------------------------------------
    # IOC fingerprint scan (unchanged from v0.2.0)
    # ------------------------------------------------------------------

    def _ioc_scan(self, ctx: CheckContext) -> list[Finding]:
        if ctx.ioc_dir is None:
            ctx.status.skipped("plugin_static：ioc_dir 未配置")
            return []
        db_path = Path(ctx.ioc_dir) / "clawhavoc_skills.json"
        if not db_path.exists():
            ctx.status.skipped(f"plugin_static：{db_path} 缺失")
            return []
        try:
            db = json.loads(db_path.read_text())
        except json.JSONDecodeError as e:
            ctx.status.skipped(f"plugin_static：clawhavoc 数据库格式错误：{e}")
            return []
        ioc_by_name = {entry.get("name"): entry for entry in db if entry.get("name")}
        ioc_by_sha = {entry["sha256"]: entry for entry in db if entry.get("sha256")}

        bin_path = ctx.profile.paths.get("openclaw_bin", "openclaw")
        res = ctx.executor.run([bin_path, *self._SUFFIX])
        if res.rejected:
            ctx.status.skipped(f"plugin_static：{res.reject_reason}")
            return []
        if res.exit_code != 0:
            ctx.status.skipped(f"plugin_static：skills list 退出码 {res.exit_code}")
            return []
        try:
            payload = json.loads(res.stdout)
        except json.JSONDecodeError as e:
            ctx.status.skipped(f"plugin_static：skills JSON 解析失败：{e}")
            return []

        findings: list[Finding] = []
        for skill in payload.get("skills", []):
            name = skill.get("name", "")
            sha = skill.get("hash") or skill.get("sha256")
            ioc = (ioc_by_sha.get(sha) if sha else None) or ioc_by_name.get(name)
            if ioc is None:
                continue
            findings.append(self.make_finding(
                ctx,
                severity="critical",
                title=f"已安装 skill 命中 ClawHavoc IOC：{name}",
                description=ioc.get("claim", ""),
                evidence={
                    "matched_name": name,
                    "installed_version": skill.get("version"),
                    "installed_hash": sha,
                    "ioc_published_after": ioc.get("published_after"),
                },
                remediation=(
                    f"卸载 skill {name}，并轮换该 skill 可能访问过的所有凭据。"
                ),
                threat_refs=list(ioc.get("threat_refs", [])),
            ))
        return findings

    # ------------------------------------------------------------------
    # AST danger-pattern scan (new in v0.5.2)
    # ------------------------------------------------------------------

    async def _ast_scan(self, ctx: CheckContext) -> list[Finding]:
        """Scan skill Python files for dangerous API calls via ast analysis."""
        skills_dir = ctx.profile.paths.get("skills_dir")
        if not skills_dir:
            return []

        find_argv = ["find", skills_dir, "-type", "f", "-name", "*.py"]
        res = ctx.executor.run(find_argv)
        if res is None or res.rejected or res.exit_code != 0 or not res.stdout.strip():
            return []

        findings: list[Finding] = []
        for skill_path in res.stdout.splitlines():
            skill_path = skill_path.strip()
            if not skill_path:
                continue
            cat_res = ctx.executor.run(["cat", skill_path])
            if cat_res is None or cat_res.rejected or cat_res.exit_code != 0:
                continue
            hits = self._scan_source(cat_res.stdout, skill_path)
            skill_name = skill_path.rsplit("/", 1)[-1]
            for category, matches in hits.items():
                findings.append(self.make_finding(
                    ctx,
                    severity="high",
                    title=f"Skill {skill_name} 使用了危险 API：{category}",
                    description=(
                        f"Skill 文件 {skill_path} 使用了 {category} 类 API"
                        f"（首次出现于第 {matches[0][1]} 行）。"
                    ),
                    evidence={
                        "skill_path": skill_path,
                        "category": category,
                        "matched_calls": [f"{m[0]}:{m[1]}" for m in matches],
                    },
                    remediation=(
                        f"审查 {skill_path} 中所有 {category} 用法，"
                        "在上线前移除或为每处提供合理理由。"
                    ),
                    threat_refs=["TI-CLAWHAVOC-OVERVIEW"],
                ))
        return findings

    def _scan_source(
        self, source: str, skill_path: str
    ) -> dict[str, list[tuple[str, int]]]:
        """Return {category: [(call_repr, lineno), ...]} for danger matches.

        Uses two separate pattern dicts to avoid double-counting: ast.walk
        visits both a Call node and the Attribute inside its func, so call
        patterns are matched only in the Call handler and attribute-access
        patterns only in the Attribute handler.
        """
        import ast as _ast

        try:
            tree = _ast.parse(source)
        except SyntaxError:
            return {}

        hits: dict[str, list[tuple[str, int]]] = {}
        for node in _ast.walk(tree):
            if isinstance(node, _ast.Call):
                func = node.func
                if isinstance(func, _ast.Attribute) and isinstance(func.value, _ast.Name):
                    key = (func.value.id, func.attr)
                    for cat, patterns in _DANGER_CALLS.items():
                        if key in patterns:
                            hits.setdefault(cat, []).append((
                                f"{func.value.id}.{func.attr}",
                                getattr(node, "lineno", 0),
                            ))
                elif isinstance(func, _ast.Name):
                    key = ("builtins", func.id)
                    for cat, patterns in _DANGER_CALLS.items():
                        if key in patterns:
                            hits.setdefault(cat, []).append((
                                func.id,
                                getattr(node, "lineno", 0),
                            ))
            elif (
                isinstance(node, _ast.Attribute)
                and isinstance(node.value, _ast.Name)
            ):
                key = (node.value.id, node.attr)
                for cat, patterns in _DANGER_ATTRS.items():
                    if key in patterns:
                        hits.setdefault(cat, []).append((
                            f"{node.value.id}.{node.attr}",
                            getattr(node, "lineno", 0),
                        ))
        return hits
