"""containerd daemon 配置审计（Phase 7f.1.1）。

读 /etc/containerd/config.toml + `containerd --version`，按
container_baseline.yaml:daemon_containerd 段 6 条规则 emit findings。

跨运行时让位：docker 接管 containerd 时 not_applicable。
配置缺失三档语义：absent (走默认) / permission denied / parse fail。
"""

from __future__ import annotations

import ipaddress
import re
import tomllib
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import _docker_takeover_active, detect_containerd_bin
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"
_CONFIG_PATH = "/etc/containerd/config.toml"
_PERM_DENIED_SUBSTRINGS = ("permission denied", "operation not permitted",
                           "must be root", "you need to be root")


def _looks_perm_denied(stderr: str) -> bool:
    s = stderr.lower()
    return any(needle in s for needle in _PERM_DENIED_SUBSTRINGS)


def _looks_not_found(stderr: str) -> bool:
    s = stderr.lower()
    return "no such file" in s or "not found" in s


class ContainerdDaemonAuditCheck(Check):
    id = "containerd_daemon_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._rules = {r["id"]: r for r in baseline["daemon_containerd"]}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_containerd_bin(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 containerd 二进制（"
                "/usr/bin /usr/local/bin 两处均无）"
            )
            return []
        if _docker_takeover_active(ctx):
            ctx.status.not_applicable(
                f"{self.id}：检出 docker 后端为 containerd，由 docker_daemon_audit 评估"
            )
            return []

        # --- 3-tier config read ---
        config_result = ctx.executor.run(["cat", _CONFIG_PATH])
        config_present = False
        config_data: dict = {}
        if config_result.rejected:
            ctx.status.skipped(
                f"{self.id}：cat 被 policy 拒绝（{config_result.reject_reason}）"
            )
            return []
        if config_result.exit_code != 0:
            if _looks_perm_denied(config_result.stderr):
                ctx.status.skipped(
                    f"{self.id}：读 config.toml 权限不足，需 root 或 NOPASSWD sudoers"
                )
                return []
            if _looks_not_found(config_result.stderr):
                config_present = False  # absent — emit info, continue with version
            else:
                ctx.status.skipped(
                    f"{self.id}：cat config.toml 退出码 {config_result.exit_code}"
                )
                return []
        else:
            config_present = True
            try:
                config_data = tomllib.loads(config_result.stdout)
            except tomllib.TOMLDecodeError:
                ctx.status.skipped(
                    f"{self.id}：config.toml 不是合法 TOML"
                )
                return []

        # --- Version read (always attempted) ---
        version_result = ctx.executor.run(["containerd", "--version"])
        version_str = ""
        if not version_result.rejected and version_result.exit_code == 0:
            m = re.search(r"v(\d+\.\d+\.\d+)", version_result.stdout)
            if m:
                version_str = m.group(1)

        findings: list[Finding] = []
        if not config_present:
            findings.append(self._emit_config_missing(ctx))

        # version-cve is the only rule reachable when config is absent.
        findings.extend(self._evaluate_version(ctx, version_str))

        if config_present:
            findings.extend(self._evaluate_grpc(ctx, config_data))
            findings.extend(self._evaluate_debug(ctx, config_data))
            findings.extend(self._evaluate_metrics(ctx, config_data))
            findings.extend(self._evaluate_cri(ctx, config_data))

        return findings

    def _emit_config_missing(self, ctx: CheckContext) -> Finding:
        return self.make_finding(
            ctx, severity="info",
            title="containerd config.toml 不存在或为空（走默认值）",
            description=(
                "/etc/containerd/config.toml 不存在或为空。containerd 在此情况下"
                "使用编译时默认值。本 Check 仅 version-cve 规则在该状态下可触发，"
                "其余 5 条按 config 内容判定的规则被跳过。"
            ),
            evidence={"rule_id": "containerd-config-missing",
                      "path": _CONFIG_PATH},
            remediation=(
                "如需自定义 grpc / metrics / debug 参数请创建 /etc/containerd/config.toml。"
            ),
            threat_refs=[],
        )

    def _evaluate_version(self, ctx: CheckContext, version_str: str) -> list[Finding]:
        if not version_str:
            return []
        rule = self._rules.get("containerd-version-cve")
        if rule is None:
            return []
        known_bad = rule.get("known_bad_versions", [])
        if not self._version_in_any_range(version_str, known_bad):
            return []
        return [self._emit_rule(
            ctx, "containerd-version-cve",
            evidence={"version": version_str, "known_bad_ranges": known_bad},
        )]

    @staticmethod
    def _version_in_any_range(version: str, ranges: list[str]) -> bool:
        """True iff `version` is vulnerable per any `<X.Y.Z` dual-branch constraint.

        Branch-aware semantics scoped to the same major: a `<X.Y.Z` range covers
        versions whose major equals X and whose minor == Y but full version < X.Y.Z,
        AND versions whose major equals X but minor is strictly smaller than every
        known-fixed minor for that major (older unsupported branch). Versions on a
        future or unrelated major are never matched.
        """
        def _key(v: str) -> tuple[int, ...]:
            parts = []
            for p in v.split("."):
                m = re.match(r"^(\d+)", p)
                parts.append(int(m.group(1)) if m else 0)
            return tuple(parts)

        v_key = _key(version)
        if len(v_key) < 2:
            return False
        v_major = v_key[0]
        v_minor = v_key[1]

        # Parse all ranges into (major, minor, full_key)
        parsed: list[tuple[int, int, tuple[int, ...]]] = []
        for r in ranges:
            r = r.strip()
            if not r.startswith("<"):
                continue
            rk = _key(r[1:])
            if len(rk) >= 2:
                parsed.append((rk[0], rk[1], rk))

        # Only consider ranges that share the version's major.
        same_major = [(rmin, rk) for (rmaj, rmin, rk) in parsed if rmaj == v_major]
        if not same_major:
            return False

        # 1. Same-minor-branch match: version < range when minor matches.
        for r_minor, r_key in same_major:
            if r_minor == v_minor and v_key < r_key:
                return True

        # 2. Old unsupported branch (same major, minor smaller than every known-fixed minor).
        if not any(r_minor == v_minor for (r_minor, _) in same_major):
            min_fixed_minor = min(rm for (rm, _) in same_major)
            if v_minor < min_fixed_minor:
                return True

        return False

    def _evaluate_grpc(self, ctx: CheckContext, config_data: dict) -> list[Finding]:
        out: list[Finding] = []
        grpc = config_data.get("grpc") or {}
        tcp_addr = grpc.get("tcp_address")
        if tcp_addr:
            out.append(self._emit_rule(
                ctx, "containerd-tcp-exposed",
                evidence={"grpc_tcp_address": tcp_addr},
            ))
        return out

    def _evaluate_debug(self, ctx: CheckContext, config_data: dict) -> list[Finding]:
        out: list[Finding] = []
        debug = config_data.get("debug") or {}
        addr = debug.get("address")
        if not addr:
            return out
        if not addr.startswith("/"):
            # Looks like host:port — flag
            out.append(self._emit_rule(
                ctx, "containerd-debug-socket-exposed",
                evidence={"debug_address": addr},
            ))
            return out
        # Unix-socket path — flag if permission is wider than owner-only.
        # 664/0664 (group-writable) is included because containerd debug
        # control via the socket lets any group member invoke arbitrary
        # plugin commands, and operator-administered groups (e.g. `docker`,
        # `containerd`) are not a security boundary.
        result = ctx.executor.run(["stat", "-c", "%a", addr])
        if result.rejected or result.exit_code != 0:
            return out
        perm = result.stdout.strip()
        unsafe = {"666", "664", "667", "777", "0666", "0664", "0667", "0777"}
        if perm in unsafe:
            out.append(self._emit_rule(
                ctx, "containerd-debug-socket-exposed",
                evidence={"debug_address": addr, "debug_perm": perm},
            ))
        return out

    def _evaluate_metrics(self, ctx: CheckContext, config_data: dict) -> list[Finding]:
        out: list[Finding] = []
        metrics = config_data.get("metrics") or {}
        addr = metrics.get("address")
        if not addr:
            return out
        if self._is_loopback_addr(addr):
            return out
        out.append(self._emit_rule(
            ctx, "containerd-metrics-exposed",
            evidence={"metrics_address": addr},
        ))
        return out

    def _is_loopback_addr(self, addr: str) -> bool:
        """True iff addr is unix:, localhost, 127.0.0.1, ::1 (with or without [])."""
        if addr.startswith("unix:"):
            return True
        # Strip optional URI scheme tcp://
        if "://" in addr:
            addr = addr.split("://", 1)[1]
        # Strip optional port. Try bracketed IPv6 first.
        if addr.startswith("["):
            end = addr.find("]")
            if end == -1:
                return False
            host = addr[1:end]
        elif addr.count(":") >= 2:
            # bare IPv6 without brackets, may or may not have port
            # Heuristic: take everything as host
            host = addr
        elif ":" in addr:
            host = addr.rsplit(":", 1)[0]
        else:
            host = addr
        if host in ("localhost",):
            return True
        try:
            ip = ipaddress.ip_address(host)
        except ValueError:
            return False
        return ip.is_loopback

    def _evaluate_cri(self, ctx: CheckContext, config_data: dict) -> list[Finding]:
        out: list[Finding] = []
        plugins = config_data.get("plugins") or {}
        cri = plugins.get("io.containerd.grpc.v1.cri") or {}
        if cri.get("disable_apparmor") is True:
            out.append(self._emit_rule(
                ctx, "containerd-cri-disable-apparmor",
                evidence={"disable_apparmor": True},
            ))
        cri_containerd = cri.get("containerd") or {}
        if cri_containerd.get("no_pivot") is True:
            out.append(self._emit_rule(
                ctx, "containerd-cri-no-pivot",
                evidence={"no_pivot": True},
            ))
        return out

    def _emit_rule(self, ctx: CheckContext, rule_id: str,
                   *, evidence: dict) -> Finding:
        rule = self._rules[rule_id]
        return self.make_finding(
            ctx, severity=rule["severity"],
            title=rule["title"], description=rule["description"],
            evidence={"runtime": "containerd", "rule_id": rule_id, **evidence},
            remediation=rule["remediation"],
            threat_refs=list(rule["threat_refs"]),
        )
