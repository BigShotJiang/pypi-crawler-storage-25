"""pip / PyPI 供应链漏洞审计（Phase 7d.1）。

Reads operator-configured requirements.txt files on the audited host,
parses frozen `pkg==ver` lines, normalizes package names per PEP-503,
and matches each (name, version) against a bundled OSV-PyPI advisory
subset using PEP-440 comparison. Emits one Finding per matching
(pkg, version, advisory) tuple.

DB schema (src/agentsec/audit/ioc/osv_pypi.json):
  [{"id": "GHSA-xxxx", "package": "django",
    "ranges": [{"introduced": "0", "fixed": "3.2.18"}],
    "severity": "critical|high|medium|low", "summary": "...",
    "url": "...", "aliases": ["CVE-..."]}, ...]
"""

from __future__ import annotations

import re
from pathlib import Path

from packaging.version import InvalidVersion, Version

from ..findings import Finding
from ._supply_chain_common import (
    extract_severity_label,
    load_advisory_db,
)
from .base import Check, CheckContext


def normalize_pep503(name: str) -> str:
    """PEP-503 name normalization: lowercase + collapse [-_.]+ to single hyphen."""
    return re.sub(r"[-_.]+", "-", name).lower()


def _safe_parse_pep440(s: str) -> Version | None:
    """Return packaging.version.Version or None on parse failure."""
    try:
        return Version(s)
    except (InvalidVersion, TypeError):
        return None


def version_in_any_pep440_range(version: str, ranges: list[dict]) -> bool:
    """True iff `version` falls into at least one OSV range entry.

    Range entry shape (PyPI subset):
      {"introduced": "0", "fixed": "3.2.18"}
      {"introduced": "1.0", "last_affected": "1.2.5"}

    Non-PEP-440 versions return False (caller treats as 'cannot match').
    pre-release versions are included by default; local-version segments
    (`1.0+cuda`) are dropped in comparison per PEP-440.
    """
    v = _safe_parse_pep440(version)
    if v is None:
        return False
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last = r.get("last_affected")

        if intro != "0":
            intro_v = _safe_parse_pep440(intro)
            if intro_v is not None and v < intro_v:
                continue
        if fixed is not None:
            fixed_v = _safe_parse_pep440(fixed)
            if fixed_v is not None and v >= fixed_v:
                continue
        if last is not None:
            last_v = _safe_parse_pep440(last)
            if last_v is not None and v > last_v:
                continue
        return True
    return False


_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_pypi.json"


class PipSupplyChainAuditCheck(Check):
    id = "pip_supply_chain_audit"

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        path = db_path if db_path is not None else _OSV_DB_PATH
        self._advisories_by_pkg = load_advisory_db(path)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(f"{self.id}：非 Linux profile")
            return []
        if not ctx.pip_lock_paths:
            ctx.status.not_applicable(f"{self.id}：未配置 pip_lock_paths")
            return []

        findings: list[Finding] = []
        n_skipped = 0
        for lock_path in ctx.pip_lock_paths:
            result = ctx.executor.run(["cat", lock_path])
            if result.rejected:
                n_skipped += 1
                continue
            if result.exit_code != 0:
                n_skipped += 1
                continue
            if not result.stdout.strip():
                n_skipped += 1
                continue
            findings.extend(self._scan_lockfile(ctx, lock_path, result.stdout))
        if not findings and n_skipped == len(ctx.pip_lock_paths):
            ctx.status.skipped(
                f"{self.id}：所有 pip_lock_paths 均不可读 (n={n_skipped})"
            )
        return findings

    def _scan_lockfile(self, ctx: CheckContext, lock_path: str, stdout: str) -> list[Finding]:
        pkgs = parse_pip_requirements(stdout)
        findings: list[Finding] = []
        for pkg, version in pkgs:
            norm = normalize_pep503(pkg)
            if _safe_parse_pep440(version) is None:
                findings.append(self._unparseable_finding(ctx, pkg, version, lock_path))
                continue
            for adv in self._advisories_by_pkg.get(norm, []):
                if version_in_any_pep440_range(version, adv["ranges"]):
                    findings.append(
                        self._advisory_finding(ctx, pkg, version, adv, lock_path)
                    )
        return findings

    def _advisory_finding(
        self, ctx: CheckContext, pkg: str, version: str, adv: dict, lock_path: str,
    ) -> Finding:
        sev = extract_severity_label(adv)
        adv_id = adv["id"]
        fixed_in = next(
            (r["fixed"] for r in adv["ranges"] if r.get("fixed")),
            "(no fixed version)",
        )
        return self.make_finding(
            ctx,
            severity=sev,
            title=f"pip {pkg}@{version} 命中 {adv_id}（severity={sev}）",
            description=adv.get("summary", "")[:200],
            evidence={
                "package": pkg,
                "version": version,
                "advisory_id": adv_id,
                "aliases": adv.get("aliases", []),
                "fixed_in": fixed_in,
                "url": adv.get("url", ""),
                "lock_path": lock_path,
            },
            remediation=f"pip install -U {pkg}=={fixed_in}",
            threat_refs=["TI-OSV-PYPI-CATALOG"],
        )

    def _unparseable_finding(
        self, ctx: CheckContext, pkg: str, version: str, lock_path: str,
    ) -> Finding:
        return self.make_finding(
            ctx,
            severity="low",
            title=f"无法解析 PEP-440: {pkg}@{version}",
            description="非标准版本字符串（如 git URL pin），无法对照 OSV 数据库",
            evidence={
                "package": pkg, "version": version, "lock_path": lock_path,
            },
            remediation="改为 PEP-440 合规版本（pip 发布版）",
            threat_refs=["TI-OSV-PYPI-CATALOG"],
        )


# ---- requirements.txt parser ----

# `pkg[extras]==version` — extras / version-specifier splits before marker
_REQ_LINE_RE = re.compile(
    r"^([A-Za-z0-9][A-Za-z0-9._-]*)"   # 1: package name
    r"(?:\[[^\]]*\])?"                  # optional extras (discarded)
    r"\s*==\s*"                         # operator (only `==` accepted)
    r"([^\s;]+)"                        # 2: version (up to whitespace or `;` marker)
)


def parse_pip_requirements(stdout: str) -> list[tuple[str, str]]:
    """Return [(pkg_name, version)] from frozen requirements.txt content.

    Recognizes only `pkg==version` lines (with optional [extras] and
    `; marker`). Silently skips:
      - comments / blank lines
      - `-e ...` editable installs
      - `-r ...` / `-c ...` recursive includes
      - `pkg @ url` direct VCS / file references
      - `pkg>=`, `~=`, `<` non-exact specifiers
      - any line that doesn't match the canonical form

    Continuation lines (`\\` at EOL) are joined; subsequent `--hash=...`
    lines belong to the previous requirement and are absorbed.
    """
    # Join continuation lines first
    joined: list[str] = []
    buf = ""
    for raw in stdout.splitlines():
        if buf:
            line = buf + " " + raw.lstrip()
        else:
            line = raw
        if line.rstrip().endswith("\\"):
            buf = line.rstrip()[:-1].rstrip()
            continue
        joined.append(line)
        buf = ""
    if buf:
        joined.append(buf)

    out: list[tuple[str, str]] = []
    for line in joined:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith(("-e ", "-r ", "-c ", "--")):
            continue
        if " @ " in s:   # direct URL form
            continue
        m = _REQ_LINE_RE.match(s)
        if not m:
            continue
        pkg, version = m.group(1), m.group(2)
        out.append((pkg, version))
    return out
