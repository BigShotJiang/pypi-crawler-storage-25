"""systemd unit-file lint (Phase 7e.1).

枚举 /etc/systemd/system/*.service，cat 每个文件，对 [Service] 段做 3 类 regex 扫描：
- writable_execstart：ExecStart 指向 /tmp / /var/tmp / /dev/shm / /home
- shellwrap_execstart：ExecStart 含 sh -c / curl|sh / wget|sh download-and-exec 模式
- root_writable_combo：以上任一命中且 User=root 或 User= 缺失 → 升级 critical（合并一条 finding）

注意：regex 仅匹配单行 ExecStart=...，不展开 systemd 反斜杠续行
（`ExecStart=/usr/bin/wrapper \\\n  /tmp/payload`）。续行中的可写路径
不会被命中——这是 v1 的已知 gap，留待后续按真实部署 false-negative
率决定是否升级到多行扫描。
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from ..findings import Finding, Severity
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)

_RE_EXEC_WRITABLE = re.compile(
    r'^ExecStart\s*=\s*([^\n]*\s)?(/tmp/|/var/tmp/|/dev/shm/|/home/)',
    re.MULTILINE,
)
_RE_EXEC_SHELL_WRAP = re.compile(
    r'^ExecStart\s*=\s*.*'
    r'(\b(?:bash|sh)\b\s+-c\s|'
    r'curl\s+[^|\n]*\|\s*(?:bash|sh)|'
    r'wget\s+[^|\n]*\|\s*(?:bash|sh))',
    re.MULTILINE,
)
_RE_USER_DECLARED = re.compile(r'^User\s*=', re.MULTILINE)
_RE_USER_ROOT = re.compile(r'^User\s*=\s*root\s*$', re.MULTILINE)

_SEVERITY_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def _severity_rank(s: str) -> int:
    return _SEVERITY_RANK.get(s, 0)


def _extract_service_section(text: str) -> str:
    """返回首个 [Service] 块的 body（不含头行），到下一个 [Section] 或 EOF 为止。
    若没有 [Service]，返回空字符串。"""
    in_service = False
    out: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            if stripped == "[Service]":
                in_service = True
                continue
            if in_service:
                break
            continue
        if in_service:
            out.append(line)
    return "\n".join(out)


class SystemdUnitLintCheck(Check):
    id = "systemd_unit_lint"

    def __init__(self):
        super().__init__()
        ul = yaml.safe_load(_BASELINE_PATH.read_text())["systemd"]["unit_lint"]
        self._rules = {r["id"]: r for r in ul["rules"]}
        self._remediation = ul["remediation"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"systemd_unit_lint：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []

        find_argv = [
            "find", "/etc/systemd/system", "-maxdepth", "1",
            "-name", "*.service", "-type", "f",
        ]
        find_result = ctx.executor.run(find_argv)
        if find_result.rejected:
            ctx.status.skipped(
                f"systemd_unit_lint find 被策略拒绝：{find_result.reject_reason}"
            )
            return []
        if find_result.exit_code != 0:
            ctx.status.skipped(
                f"systemd_unit_lint find 退出码 {find_result.exit_code}"
            )
            return []

        findings: list[Finding] = []
        for line in find_result.stdout.splitlines():
            unit_path = line.strip()
            if not unit_path:
                continue
            cat_result = ctx.executor.run(["cat", unit_path])
            if cat_result.rejected or cat_result.exit_code != 0:
                continue
            section = _extract_service_section(cat_result.stdout)
            if not section:
                continue
            hits: list[str] = []
            if _RE_EXEC_WRITABLE.search(section):
                hits.append("writable_execstart")
            if _RE_EXEC_SHELL_WRAP.search(section):
                hits.append("shellwrap_execstart")
            if not hits:
                continue
            user_root_or_default = (
                bool(_RE_USER_ROOT.search(section))
                or not _RE_USER_DECLARED.search(section)
            )
            severity: Severity
            if user_root_or_default:
                hits.append("root_writable_combo")
                severity = "critical"
            else:
                severity = max(
                    (self._rules[h]["severity"] for h in hits),
                    key=_severity_rank,
                )
            snippet_match = (
                _RE_EXEC_WRITABLE.search(section)
                or _RE_EXEC_SHELL_WRAP.search(section)
            )
            snippet = (snippet_match.group(0) if snippet_match else "")[:200]
            findings.append(Finding(
                check=self.id,
                severity=severity,
                title=f"systemd unit 风险：{unit_path}",
                description=" / ".join(self._rules[h]["rationale"] for h in hits),
                evidence={
                    "file": unit_path,
                    "rules": hits,
                    "snippet": snippet,
                },
                remediation=self._remediation,
                threat_refs=["TI-LINUX-CIS-SYSTEMD"],
            ))
        return findings
