"""Linux kernel sysctl baseline audit (Phase 7e).

Pulls 8 baseline keys via a single `sysctl -n key1 key2 ...` call and
emits one Finding per key whose runtime value differs from baseline.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ..findings import Finding
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)


class SysctlAuditCheck(Check):
    id = "sysctl_audit"

    def __init__(self):
        super().__init__()
        self._rules = yaml.safe_load(_BASELINE_PATH.read_text())["sysctl"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"sysctl_audit：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []
        keys = [r["key"] for r in self._rules]
        argv = ["sysctl", "-n", *keys]
        result = ctx.executor.run(argv)
        if result.rejected:
            ctx.status.skipped(
                f"sysctl_audit 被策略拒绝：{result.reject_reason}"
            )
            return []
        if result.exit_code != 0:
            ctx.status.skipped(
                f"sysctl_audit 退出码 {result.exit_code}"
            )
            return []
        actual_values = result.stdout.strip().splitlines()
        if len(actual_values) != len(keys):
            ctx.status.skipped(
                f"sysctl_audit 输出行数 {len(actual_values)} 与 "
                f"key 数 {len(keys)} 不匹配"
            )
            return []
        findings: list[Finding] = []
        for rule, actual in zip(self._rules, actual_values, strict=False):
            if actual.strip() != rule["must_equal"]:
                findings.append(Finding(
                    check=self.id,
                    severity=rule["severity"],
                    title=(
                        f"sysctl {rule['key']} = {actual.strip()!r}，"
                        f"基线要求 {rule['must_equal']!r}"
                    ),
                    description=rule["rationale"],
                    evidence={
                        "key": rule["key"],
                        "actual": actual.strip(),
                        "expected": rule["must_equal"],
                    },
                    remediation=rule["remediation"],
                    threat_refs=["TI-LINUX-CIS-SYSCTL"],
                ))
        return findings
