"""rust / crates.io 供应链漏洞审计（Phase 7d.3）。

Reads operator-configured Cargo.lock files on the audited host, parses
the TOML, filters to crates.io-registry packages, and matches each
(crate, version) against a bundled OSV-Cargo advisory subset using
strict semver 2.0. Emits one Finding per matching (crate, version,
advisory) tuple.

DB schema (src/agentsec/audit/ioc/osv_cargo.json):
  [{"id": "GHSA-xxxx", "package": "serde",
    "ranges": [{"introduced": "0", "fixed": "1.0.150"}],
    "severity": "critical|high|medium|low", "summary": "...",
    "url": "...", "aliases": ["CVE-...", "RUSTSEC-..."]}, ...]
"""

from __future__ import annotations

import tomllib
from pathlib import Path

import semver

from ..findings import Finding
from ._supply_chain_common import (
    extract_severity_label,
    load_advisory_db,
)
from .base import Check, CheckContext

_CRATES_IO_REGISTRY = "registry+https://github.com/rust-lang/crates.io-index"


def _safe_parse_cargo_version(s: str) -> semver.Version | None:
    """Cargo uses strict semver 2.0 — no v prefix, no +incompatible.

    Returns None on parse failure.
    """
    if not s:
        return None
    try:
        return semver.Version.parse(s)
    except (ValueError, TypeError):
        return None


def version_in_any_cargo_range(version: str, ranges: list[dict]) -> bool:
    """True iff `version` falls into at least one OSV range entry.

    Non-parseable input versions return False. Range bounds that don't
    parse as strict semver (e.g., upstream OSV data like "0.16" instead
    of "0.16.0") cause the affected range to be skipped (fail-closed) —
    fail-open would silently drop the bound and flag clearly-older
    versions as vulnerable.
    """
    v = _safe_parse_cargo_version(version)
    if v is None:
        return False
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last = r.get("last_affected")
        if intro != "0":
            intro_v = _safe_parse_cargo_version(intro)
            if intro_v is None:
                continue
            if v.compare(intro_v) < 0:
                continue
        if fixed is not None:
            fixed_v = _safe_parse_cargo_version(fixed)
            if fixed_v is None:
                continue
            if v.compare(fixed_v) >= 0:
                continue
        if last is not None:
            last_v = _safe_parse_cargo_version(last)
            if last_v is None:
                continue
            if v.compare(last_v) > 0:
                continue
        return True
    return False


def parse_cargo_lock(stdout: str) -> list[tuple[str, str]]:
    """Return [(crate_name, version)] from Cargo.lock TOML.

    Filters to packages whose `source` field equals the official crates.io
    registry URL. Workspace-local (no source) / git / path / alternate
    registry deps are silently skipped — only canonical crates.io
    packages are auditable against OSV-Cargo.
    """
    try:
        data = tomllib.loads(stdout)
    except tomllib.TOMLDecodeError:
        return []
    out: list[tuple[str, str]] = []
    for pkg in data.get("package", []):
        if not isinstance(pkg, dict):
            continue
        if pkg.get("source") != _CRATES_IO_REGISTRY:
            continue
        name = pkg.get("name")
        version = pkg.get("version")
        if not name or not version:
            continue
        out.append((name, version))
    return out


# --- Check class ---


_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_cargo.json"


class RustSupplyChainAuditCheck(Check):
    id = "rust_supply_chain_audit"

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        path = db_path if db_path is not None else _OSV_DB_PATH
        self._advisories_by_pkg = load_advisory_db(path)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(f"{self.id}：非 Linux profile")
            return []
        if not ctx.cargo_lock_paths:
            ctx.status.not_applicable(f"{self.id}：未配置 cargo_lock_paths")
            return []

        findings: list[Finding] = []
        n_skipped = 0
        for lock_path in ctx.cargo_lock_paths:
            result = ctx.executor.run(["cat", lock_path])
            if result.rejected:
                n_skipped += 1
                continue
            if result.exit_code != 0:
                n_skipped += 1
                continue
            if not result.stdout.strip():
                n_skipped += 1
                continue
            findings.extend(self._scan_lockfile(ctx, lock_path, result.stdout))
        if not findings and n_skipped == len(ctx.cargo_lock_paths):
            ctx.status.skipped(
                f"{self.id}：所有 cargo_lock_paths 均不可读 (n={n_skipped})"
            )
        return findings

    def _scan_lockfile(
        self, ctx: CheckContext, lock_path: str, stdout: str,
    ) -> list[Finding]:
        crates = parse_cargo_lock(stdout)
        findings: list[Finding] = []
        for name, version in crates:
            if _safe_parse_cargo_version(version) is None:
                findings.append(
                    self._unparseable_finding(ctx, name, version, lock_path)
                )
                continue
            for adv in self._advisories_by_pkg.get(name, []):
                if version_in_any_cargo_range(version, adv["ranges"]):
                    findings.append(
                        self._advisory_finding(ctx, name, version, adv, lock_path)
                    )
        return findings

    def _advisory_finding(
        self, ctx: CheckContext, name: str, version: str,
        adv: dict, lock_path: str,
    ) -> Finding:
        sev = extract_severity_label(adv)
        adv_id = adv["id"]
        fixed_in = next(
            (r["fixed"] for r in adv["ranges"] if r.get("fixed")),
            "(no fixed version)",
        )
        return self.make_finding(
            ctx,
            severity=sev,
            title=f"rust {name}@{version} 命中 {adv_id}（severity={sev}）",
            description=adv.get("summary", "")[:200],
            evidence={
                "package": name,
                "version": version,
                "advisory_id": adv_id,
                "aliases": adv.get("aliases", []),
                "fixed_in": fixed_in,
                "url": adv.get("url", ""),
                "lock_path": lock_path,
            },
            remediation=f"cargo update -p {name} --precise {fixed_in}",
            threat_refs=["TI-OSV-CRATES-CATALOG"],
        )

    def _unparseable_finding(
        self, ctx: CheckContext, name: str, version: str, lock_path: str,
    ) -> Finding:
        return self.make_finding(
            ctx,
            severity="low",
            title=f"无法解析 semver: {name}@{version}",
            description=(
                "非标准 semver 版本字符串；Cargo 应该不会出现，"
                "可能是手改 Cargo.lock"
            ),
            evidence={
                "package": name, "version": version, "lock_path": lock_path,
            },
            remediation="跑 `cargo update` 重生成 Cargo.lock",
            threat_refs=["TI-OSV-CRATES-CATALOG"],
        )
