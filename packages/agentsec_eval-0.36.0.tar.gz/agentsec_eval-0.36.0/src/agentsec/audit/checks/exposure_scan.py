"""exposure_scan check (spec §3.2 #3).

TCP connect-scan from the evaluator side against `host` for an explicit list
of ports. Each LISTEN that is not on the allowlist becomes one Finding.

WebSocket probe: after TCP scan, each open port is probed with a bare WS
upgrade (no credentials) at each path in `ws_paths`. A 101 response means
the endpoint is unauthenticated — Finding(severity="high"). Per-port timeout
`timeout_sec` applies to both TCP connect and WS handshake.

`exposure_scan` does **not** use SSH; it observes the target's exposed
network surface from wherever the evaluator is running. Authorization is
already enforced at the orchestrator level by `Authorization.scope`
containing `server-audit` (which implies external network observation of
the consenting target).

Note: the allowlist only suppresses TCP findings; the WS probe still runs
on allowlisted ports, because allowlisting a port does not imply its WS
endpoint is authenticated.
"""

from __future__ import annotations

import asyncio
import socket
from collections.abc import Iterable

from ..findings import Finding
from .base import Check, CheckContext

DEFAULT_PORTS: tuple[int, ...] = (18789, 18790, 8443, 80, 443, 22)
DEFAULT_ALLOWLIST: tuple[int, ...] = (18789, 22)
DEFAULT_WS_PATHS: tuple[str, ...] = ("/ws", "/v1/ws", "/")


class ExposureScanCheck(Check):
    id = "exposure_scan"

    def __init__(
        self,
        *,
        host: str,
        ports: Iterable[int] = DEFAULT_PORTS,
        allowlist: Iterable[int] = DEFAULT_ALLOWLIST,
        timeout_sec: float = 0.5,
        ws_paths: Iterable[str] = DEFAULT_WS_PATHS,
        ws_probe_enabled: bool = True,
    ):
        super().__init__()
        self._host = host
        self._ports = list(ports)
        self._allow = set(allowlist)
        self._timeout = timeout_sec
        self._ws_paths = list(ws_paths)
        self._ws_probe_enabled = ws_probe_enabled

    async def run(self, ctx: CheckContext) -> list[Finding]:
        open_ports = [p for p in self._ports if self._is_listening(p)]
        findings: list[Finding] = []

        for port in open_ports:
            if port in self._allow:
                continue
            findings.append(Finding(
                check=self.id,
                severity="medium",
                title=f"未在白名单的监听端口：{port}/tcp（{self._host}）",
                description=(
                    f"{self._host} 的 {port}/tcp 端口接受了来自评估方的 TCP 连接，"
                    f"且不在白名单 {sorted(self._allow)} 中。"
                ),
                evidence={"host": self._host, "port": port, "transport": "tcp"},
                remediation=(
                    f"若 {port} 端口确为预期暴露，请将其加入 "
                    f"`exposure_scan.allowlist`；否则请关闭该端口，或在防火墙上"
                    f"屏蔽来自评估方网络位置的访问。"
                ),
                threat_refs=["TI-OPENCLAW-EXPOSURE"],
            ))

        if self._ws_probe_enabled:
            for port in open_ports:
                for path in await self._ws_probe(port):
                    findings.append(Finding(
                        check=self.id,
                        severity="high",
                        title=(
                            f"未鉴权的 WebSocket 端点："
                            f"{self._host}:{port}{path}"
                        ),
                        description=(
                            f"{self._host}:{port} 上路径 {path} 的 WebSocket 升级握手"
                            f"在评估方网络位置发起的请求中被无凭据接受。"
                        ),
                        evidence={
                            "host": self._host,
                            "port": port,
                            "path": path,
                            "transport": "ws",
                        },
                        remediation=(
                            "在接受 WebSocket 升级握手前要求鉴权"
                            "（例如 token query 参数或 Authorization 头）。"
                        ),
                        threat_refs=["TI-OPENCLAW-EXPOSURE"],
                    ))

        return findings

    def _is_listening(self, port: int) -> bool:
        try:
            with socket.create_connection((self._host, port), timeout=self._timeout):
                return True
        except (TimeoutError, OSError):
            return False

    async def _ws_probe(self, port: int) -> list[str]:
        """Return paths where unauthenticated WS upgrade was accepted (101)."""
        import websockets
        import websockets.exceptions

        accepted: list[str] = []
        for path in self._ws_paths:
            url = f"ws://{self._host}:{port}{path}"
            try:
                async with asyncio.timeout(self._timeout):
                    async with websockets.connect(url) as _ws:
                        accepted.append(path)
            except (OSError, TimeoutError, websockets.exceptions.WebSocketException):
                pass
        return accepted
