"""active_test check (spec §3.2 #1 / §7.2).

Establishes a paramiko local-port-forward (evaluator localhost:RAND →
remote 127.0.0.1:18789), runs the canary suite through the existing remote
runner pointed at http://127.0.0.1:RAND/. Tunnel failure → status=skipped,
no write-mode fallback.

Outcome categorization (R4): the canary uses a deterministic
`response_status_in: [200]` assertion, so a 405 / 501 (chat endpoint
disabled, common in OpenClaw deployments where `gateway.http.endpoints.
chatCompletions.enabled` is left default-off) used to surface as a
low-severity "canary failed" finding. That conflated configuration
state with prompt-injection signal. Now: pre-2xx HTTP status codes
that signal endpoint shape (404 / 405 / 501 / 502 / 503) are emitted
as info-severity "endpoint not exposed" findings; only a 2xx response
that still failed assertions remains a low-severity injection signal.
"""

from __future__ import annotations

from collections.abc import Callable
from contextlib import AbstractContextManager
from pathlib import Path

from ...adapters.openclaw_gateway import OpenClawGatewayAdapter
from ...evaluator.deterministic_judge import DeterministicJudge
from ...evaluator.judge_router import JudgeRouter
from ...evaluator.no_op_judge import NoOpJudge
from ...runner import run_suite
from ...tests.loader import load_test_suite
from ..findings import Finding
from .base import Check, CheckContext

# HTTP statuses that mean "endpoint shape", not "model behavior".
_ENDPOINT_SHAPE_STATUSES: frozenset[int] = frozenset({404, 405, 501, 502, 503})

# Ship the canary inside the package so wheel installs find it. The
# previous `parents[4]` walk pointed at repo-root/test_suites/, which
# hatchling excluded from the wheel — every non-editable install hit
# FileNotFoundError once Stage E lands a real local-forward.
CANARY_PATH = Path(__file__).parent / "data" / "active-test-canary.yaml"


async def _run_canary(adapter, suite, judge):
    """Indirection so tests can monkey-patch without touching `run_suite`."""
    return await run_suite(adapter, judge, suite, concurrency=1)


class ActiveTestCheck(Check):
    id = "active_test"
    _REQUIRED_PATHS: tuple[str, ...] = ()  # platform-agnostic; tunnel goes to localhost on target

    def __init__(
        self,
        *,
        tunnel_factory: Callable[[str, str, str], AbstractContextManager],
        host: str = "",
        user: str = "",
        key: str = "",
        bearer_token: str | None = None,
    ):
        super().__init__()
        self._tunnel_factory = tunnel_factory
        self._host = host
        self._user = user
        self._key = key
        self._bearer_token = bearer_token

    async def run(self, ctx: CheckContext) -> list[Finding]:
        try:
            tunnel_cm = self._tunnel_factory(self._host, self._user, self._key)
        except Exception as e:
            ctx.status.skipped(f"active_test：SSH 隧道建立失败：{e}")
            return []

        try:
            with tunnel_cm as local_port:
                headers = (
                    {"Authorization": f"Bearer {self._bearer_token}"}
                    if self._bearer_token else None
                )
                adapter = OpenClawGatewayAdapter(
                    name="active-test-canary",
                    base_url=f"http://127.0.0.1:{local_port}",
                    headers=headers,
                )
                suite = load_test_suite(CANARY_PATH)
                # Canary suite is deterministic-only; NoOpJudge fills the llm /
                # hybrid slots so the JudgeRouter contract stays well-typed and
                # any accidental dispatch raises a typed NoOpJudgeInvoked error.
                judge = JudgeRouter(
                    llm=NoOpJudge(),
                    deterministic=DeterministicJudge(),
                    hybrid=NoOpJudge(),
                )
                results = await _run_canary(adapter, suite, judge)
        except Exception as e:
            ctx.status.skipped(f"active_test：SSH 隧道运行时错误：{e}")
            return []

        findings: list[Finding] = []
        for tr in results:
            if tr.status != "failed":
                continue
            status_code = self._first_status_code(tr)
            if status_code in _ENDPOINT_SHAPE_STATUSES:
                findings.append(Finding(
                    check=self.id,
                    severity="info",
                    title=(
                        f"active_test canary {tr.test_id}：chat 端点返回 "
                        f"HTTP {status_code}（端点未对外暴露）"
                    ),
                    description=(
                        f"审计目标的 OpenClaw chat-completions 端点返回 "
                        f"HTTP {status_code}，意味着该端点未对外暴露"
                        f"（例如 `gateway.http.endpoints.chatCompletions.enabled`"
                        f"保持默认关闭）。canary 无法通过关闭的端点评估模型行为；"
                        f"这是部署形态记录，不是 prompt 注入信号。"
                    ),
                    evidence={
                        "test_id": tr.test_id,
                        "via": "ssh-local-forward",
                        "status_code": status_code,
                    },
                    remediation=(
                        "若 chat-completions 端点关闭是预期行为，无需处理。"
                        "如希望启用 active_test 覆盖，请在 openclaw.json 里设置 "
                        "`gateway.http.endpoints.chatCompletions.enabled = true`。"
                    ),
                    threat_refs=[],
                ))
            else:
                findings.append(Finding(
                    check=self.id,
                    severity="low",
                    title=f"active_test canary {tr.test_id} 通过本地端口转发失败",
                    description=getattr(tr, "error", "") or "",
                    evidence={
                        "test_id": tr.test_id,
                        "via": "ssh-local-forward",
                        "status_code": status_code,
                    },
                    remediation="排查目标 gateway 在该 canary 下的行为。",
                    threat_refs=[],
                ))
        return findings

    @staticmethod
    def _first_status_code(tr) -> int | None:
        """Pull the HTTP status code from the first observation, if any.

        Observations are dicts (model_dump'd) with shape
        {"response": {"status_code": int, …}, …}. Tolerant of missing keys.
        """
        for obs in getattr(tr, "observations", None) or []:
            if not isinstance(obs, dict):
                continue
            resp = obs.get("response")
            if isinstance(resp, dict) and isinstance(resp.get("status_code"), int):
                return resp["status_code"]
        return None
