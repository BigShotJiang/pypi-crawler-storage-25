"""Podman 运行时容器审计（Phase 7f.1）。

`podman ps` 列出运行中容器；逐个 `podman inspect <id>` 解析 HostConfig +
Config，复用 _docker_common._evaluate_inspect 应用 container_baseline.yaml
runtime 段的 7 条规则。rootless 模式下 runtime-root-user 严重性降一档。
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import _evaluate_inspect, detect_podman
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"
_MAX_CONTAINERS = 200
_MAX_SKIPPED_IDS = 20


class PodmanRuntimeAuditCheck(Check):
    id = "podman_runtime_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._runtime_rules = baseline["runtime"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_podman(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 podman 二进制"
            )
            return []

        info_result = ctx.executor.run(
            ["podman", "info", "--format", "{{json .}}"]
        )
        rootless = False
        if not info_result.rejected and info_result.exit_code == 0:
            try:
                info_data = json.loads(info_result.stdout)
                rootless = info_data.get("host", {}).get("security", {}).get("rootless", False)
            except json.JSONDecodeError:
                pass

        ps_result = ctx.executor.run(
            ["podman", "ps", "--format", "{{json .}}", "--no-trunc"]
        )
        if ps_result.rejected or ps_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：podman ps 退出码 {ps_result.exit_code}"
            )
            return []

        container_ids: list[str] = []
        for line in ps_result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                cid = obj.get("Id") or obj.get("ID")
                if cid:
                    container_ids.append(cid)
            except json.JSONDecodeError:
                continue

        findings: list[Finding] = []
        skipped_ids: list[str] = []

        if len(container_ids) > _MAX_CONTAINERS:
            container_ids = container_ids[:_MAX_CONTAINERS]

        for cid in container_ids:
            inspect_result = ctx.executor.run(["podman", "inspect", cid])
            if inspect_result.rejected or inspect_result.exit_code != 0:
                skipped_ids.append(cid)
                continue
            try:
                inspect_json = json.loads(inspect_result.stdout)
            except json.JSONDecodeError:
                skipped_ids.append(cid)
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_inspect(
                    inspect_json,
                    runtime="podman",
                    rootless=rootless,
                    baseline_runtime_rules=self._runtime_rules,
                )
            )

        if skipped_ids:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"{self.id}：{len(skipped_ids)} 个容器的 inspect 失败",
                description="部分容器扫描失败；finding 列表仅含成功扫描部分。",
                evidence={
                    "skipped_container_ids": skipped_ids[:_MAX_SKIPPED_IDS],
                    "truncated": len(skipped_ids) > _MAX_SKIPPED_IDS,
                },
                remediation="检查 podman 状态或运行用户权限。",
                threat_refs=[],
            ))

        return findings
