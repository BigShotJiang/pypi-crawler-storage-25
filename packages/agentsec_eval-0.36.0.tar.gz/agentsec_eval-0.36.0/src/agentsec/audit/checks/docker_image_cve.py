"""Docker 镜像 CVE / EOL 检测（Phase 7f）。

`docker ps --format json` 拉运行中容器列表（与 docker_runtime_audit 不
共享缓存，保持 Check 独立性），对每个 image 字段按
container_baseline.yaml:image_patterns fnmatch 匹配，命中即 emit。
"""

from __future__ import annotations

import fnmatch
import json
from pathlib import Path

import yaml

from ._docker_common import detect_docker
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"


class DockerImageCveCheck(Check):
    id = "docker_image_cve"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._patterns = baseline["image_patterns"]

    async def run(self, ctx: CheckContext) -> list:
        if detect_docker(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 docker 二进制"
            )
            return []

        ps_result = ctx.executor.run(
            ["docker", "ps", "--format", "{{json .}}", "--no-trunc"],
        )
        if ps_result.rejected or ps_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：docker ps 调用失败"
            )
            return []

        images: list[tuple[str, str, str]] = []   # (id, image, names)
        for line in ps_result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                images.append((
                    obj.get("ID", "")[:12],
                    obj.get("Image", ""),
                    obj.get("Names", ""),
                ))
            except json.JSONDecodeError:
                continue

        findings = []
        for cid, image, names in images:
            if not image:
                continue
            for entry in self._patterns:
                if fnmatch.fnmatchcase(image, entry["pattern"]):
                    findings.append(self.make_finding(
                        ctx,
                        severity=entry["severity"],
                        title=f"{entry['title']}（{image}）",
                        description=entry["description"],
                        evidence={
                            "container_id": cid,
                            "image": image,
                            "names": names,
                            "pattern": entry["pattern"],
                        },
                        remediation=entry["remediation"],
                        threat_refs=list(entry["threat_refs"]),
                    ))
        return findings
