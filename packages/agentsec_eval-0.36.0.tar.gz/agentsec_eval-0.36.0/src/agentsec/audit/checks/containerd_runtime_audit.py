"""Containerd 运行时容器审计（Phase 7f.1）。

nerdctl 优先 / ctr 回退分派；docker 接管 containerd 时 not_applicable
让位 docker_runtime_audit。复用 _docker_common._evaluate_inspect（nerdctl
模式）或自实现 ctr 模式 4/7 部分覆盖判定。
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import (
    _docker_takeover_active,
    _evaluate_inspect,
    _parse_ctr_info,
    detect_containerd_runtime,
)
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"
_MAX_CONTAINERS = 200
_MAX_SKIPPED_IDS = 20

_CTR_UNCOVERED_RULES = [
    "runtime-host-fs-mount",
    "runtime-sock-mount",
    "runtime-no-new-priv-missing",
]


class ContainerdRuntimeAuditCheck(Check):
    id = "containerd_runtime_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._runtime_rules = baseline["runtime"]
        self._rules_by_id = {r["id"]: r for r in self._runtime_rules}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        # Docker takeover yield
        if _docker_takeover_active(ctx):
            ctx.status.not_applicable(
                f"{self.id}：检出 docker 后端为 containerd，由 docker_runtime_audit 评估"
            )
            return []
        bin_path, mode = detect_containerd_runtime(ctx)
        if mode is None:
            ctx.status.not_applicable(
                f"{self.id}：containerd 不可见（nerdctl / ctr 均未装或 socket 缺失）"
            )
            return []
        if mode == "nerdctl":
            return self._run_nerdctl(ctx)
        else:
            return self._run_ctr(ctx)

    def _run_nerdctl(self, ctx: CheckContext) -> list[Finding]:
        ps_result = ctx.executor.run(
            ["nerdctl", "ps", "--format", "{{json .}}", "--no-trunc"]
        )
        if ps_result.rejected or ps_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：nerdctl ps 退出码 {ps_result.exit_code}"
            )
            return []
        container_ids: list[str] = []
        for line in ps_result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                cid = obj.get("ID") or obj.get("Id")
                if cid:
                    container_ids.append(cid)
            except json.JSONDecodeError:
                continue
        findings: list[Finding] = []
        skipped_ids: list[str] = []
        for cid in container_ids[:_MAX_CONTAINERS]:
            ir = ctx.executor.run(["nerdctl", "inspect", cid])
            if ir.rejected or ir.exit_code != 0:
                skipped_ids.append(cid)
                continue
            try:
                inspect_json = json.loads(ir.stdout)
            except json.JSONDecodeError:
                skipped_ids.append(cid)
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_inspect(
                    inspect_json, runtime="containerd", rootless=False,
                    baseline_runtime_rules=self._runtime_rules,
                )
            )
        if skipped_ids:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"{self.id}：{len(skipped_ids)} 个容器的 inspect 失败",
                description="部分容器扫描失败；finding 列表仅含成功扫描部分。",
                evidence={"skipped_container_ids": skipped_ids[:_MAX_SKIPPED_IDS],
                          "mode": "nerdctl",
                          "truncated": len(skipped_ids) > _MAX_SKIPPED_IDS},
                remediation="检查 containerd 状态或运行用户权限。",
                threat_refs=[],
            ))
        return findings

    def _run_ctr(self, ctx: CheckContext) -> list[Finding]:
        list_result = ctx.executor.run(
            ["ctr", "--namespace", "default", "containers", "list", "-q"]
        )
        if list_result.rejected or list_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：ctr containers list 退出码 {list_result.exit_code}"
            )
            return []
        container_ids = [
            line.strip() for line in list_result.stdout.splitlines() if line.strip()
        ]
        findings: list[Finding] = []
        skipped_ids: list[str] = []

        for cid in container_ids[:_MAX_CONTAINERS]:
            info_result = ctx.executor.run(
                ["ctr", "--namespace", "default", "containers", "info", cid]
            )
            if info_result.rejected or info_result.exit_code != 0:
                skipped_ids.append(cid)
                continue
            try:
                parsed = _parse_ctr_info(info_result.stdout)
            except ValueError:
                skipped_ids.append(cid)
                continue
            findings.extend(self._ctr_findings(ctx, cid, parsed))

        # Always emit partial-coverage info finding in ctr mode (even with 0 containers)
        findings.append(self.make_finding(
            ctx, severity="info",
            title=f"{self.id}：ctr 模式部分覆盖",
            description=(
                "未检出 nerdctl，回退到 ctr containers info 解析。"
                "host-fs-mount / sock-mount / no-new-privileges 三条规则"
                "在该模式下不可达，已跳过；其余 4 条（privileged / host-net "
                "/ cap-dangerous / root-user）正常评估。"
            ),
            evidence={
                "mode": "ctr",
                "uncovered_rules": _CTR_UNCOVERED_RULES,
            },
            remediation="安装 nerdctl 提升保真度：dnf install nerdctl",
            threat_refs=["TI-CONTAINERD-COVERAGE-PARTIAL"],
        ))

        if skipped_ids:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"{self.id}：{len(skipped_ids)} 个容器的 ctr info 失败",
                description="部分容器扫描失败；finding 列表仅含成功扫描部分。",
                evidence={"skipped_container_ids": skipped_ids[:_MAX_SKIPPED_IDS],
                          "mode": "ctr",
                          "truncated": len(skipped_ids) > _MAX_SKIPPED_IDS},
                remediation="检查 containerd 状态或运行用户权限。",
                threat_refs=[],
            ))
        return findings

    def _ctr_findings(
        self, ctx: CheckContext, cid: str, parsed: dict,
    ) -> list[Finding]:
        out: list[Finding] = []
        ev_base = {"runtime": "containerd", "container_id": cid[:12],
                   "coverage": "partial", "mode": "ctr"}

        # Split prefix construction so the static TI scanner does not treat
        # the prefix fragment as a standalone unresolvable ID.
        _prefix = "TI-" + "CONTAINERD"

        def emit(rule_id: str, extra: dict):
            rule = self._rules_by_id[rule_id]
            template = rule.get("threat_refs_template", "")
            refs = ([template.format(prefix=_prefix)] if template
                    else list(rule.get("threat_refs", [])))
            out.append(self.make_finding(
                ctx, severity=rule["severity"],
                title=rule["title"], description=rule["description"],
                evidence={**ev_base, "rule_id": rule_id, **extra},
                remediation=rule["remediation"],
                threat_refs=refs,
            ))

        if parsed["privileged"]:
            emit("runtime-privileged", {"privileged": True})
        if parsed["host_network"]:
            emit("runtime-host-net", {"network_mode": "host"})
        if parsed["root_user_uid"] == 0:
            emit("runtime-root-user", {"user": "root"})
        dangerous = {"CAP_SYS_ADMIN", "CAP_NET_ADMIN", "CAP_SYS_PTRACE"}
        for cap in parsed["capabilities"]:
            if cap in dangerous:
                emit("runtime-cap-dangerous", {"cap": cap.replace("CAP_", "")})
        return out
