"""Podman 配置审计（Phase 7f.1）。

无 daemon process（podman 是 daemonless），审计目标为 podman 的全局
配置文件 /etc/containers/containers.conf + `podman version/info` 输出。
4 条规则：rootful 模式 / userns / no_new_privileges / 版本 CVE。
"""

from __future__ import annotations

import json
import re
import tomllib
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import detect_podman
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"

_PERM_DENIED_SUBSTRINGS = ("permission denied", "operation not permitted")


def _looks_perm_denied(stderr: str) -> bool:
    s = stderr.lower()
    return any(needle in s for needle in _PERM_DENIED_SUBSTRINGS)


def _version_in_range(version: str, ranges: list[str]) -> bool:
    """Naive '< X.Y.Z' check."""
    def _key(v: str) -> tuple[int, ...]:
        return tuple(int(re.match(r"^(\d+)", p).group(1) or "0")
                     for p in v.split(".") if re.match(r"^(\d+)", p))
    for r in ranges:
        r = r.strip()
        if r.startswith("<") and _key(version) < _key(r[1:]):
            return True
    return False


class PodmanDaemonAuditCheck(Check):
    id = "podman_daemon_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._rules = {r["id"]: r for r in baseline["daemon_podman"]}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_podman(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 podman 二进制"
            )
            return []

        conf_etc = ctx.executor.run(["cat", "/etc/containers/containers.conf"])
        conf_text = ""
        if not conf_etc.rejected and conf_etc.exit_code == 0:
            conf_text = conf_etc.stdout
        else:
            conf_usr = ctx.executor.run(
                ["cat", "/usr/share/containers/containers.conf"]
            )
            if not conf_usr.rejected and conf_usr.exit_code == 0:
                conf_text = conf_usr.stdout
        try:
            conf_data = tomllib.loads(conf_text) if conf_text else {}
        except tomllib.TOMLDecodeError:
            conf_data = {}
        containers_section = conf_data.get("containers", {}) or {}

        version_result = ctx.executor.run(
            ["podman", "version", "--format", "{{json .}}"]
        )
        info_result = ctx.executor.run(
            ["podman", "info", "--format", "{{json .}}"]
        )
        if info_result.rejected or info_result.exit_code != 0:
            if _looks_perm_denied(info_result.stderr):
                ctx.status.skipped(
                    f"{self.id}：权限不足，需 root 或 NOPASSWD sudoers"
                )
            else:
                ctx.status.skipped(
                    f"{self.id}：podman info 退出码 {info_result.exit_code}"
                )
            return []

        try:
            info_data = json.loads(info_result.stdout)
        except json.JSONDecodeError:
            ctx.status.skipped(f"{self.id}：podman info 输出非 JSON")
            return []

        version_str = ""
        if not version_result.rejected and version_result.exit_code == 0:
            try:
                version_data = json.loads(version_result.stdout)
                version_str = version_data.get("Client", {}).get("Version", "")
            except json.JSONDecodeError:
                pass

        findings: list[Finding] = []

        rootless = info_data.get("host", {}).get("security", {}).get("rootless", False)
        if not rootless:
            rule = self._rules["podman-rootful-mode"]
            findings.append(self.make_finding(
                ctx, severity=rule["severity"], title=rule["title"],
                description=rule["description"],
                evidence={"runtime": "podman", "rule_id": "podman-rootful-mode",
                          "rootless": False},
                remediation=rule["remediation"],
                threat_refs=list(rule["threat_refs"]),
            ))

        userns = containers_section.get("userns")
        if userns in ("host", None):
            rule = self._rules["podman-userns-default-host"]
            findings.append(self.make_finding(
                ctx, severity=rule["severity"], title=rule["title"],
                description=rule["description"],
                evidence={"runtime": "podman", "rule_id": "podman-userns-default-host",
                          "userns": userns or "missing"},
                remediation=rule["remediation"],
                threat_refs=list(rule["threat_refs"]),
            ))

        nnp = containers_section.get("no_new_privileges", False)
        if not nnp:
            rule = self._rules["podman-no-new-priv-off"]
            findings.append(self.make_finding(
                ctx, severity=rule["severity"], title=rule["title"],
                description=rule["description"],
                evidence={"runtime": "podman", "rule_id": "podman-no-new-priv-off",
                          "no_new_privileges": nnp},
                remediation=rule["remediation"],
                threat_refs=list(rule["threat_refs"]),
            ))

        if version_str:
            rule = self._rules["podman-version-cve"]
            bad_versions = rule.get("known_bad_versions", [])
            if _version_in_range(version_str, bad_versions):
                findings.append(self.make_finding(
                    ctx, severity=rule["severity"], title=rule["title"],
                    description=rule["description"],
                    evidence={"runtime": "podman", "rule_id": "podman-version-cve",
                              "version": version_str},
                    remediation=rule["remediation"],
                    threat_refs=list(rule["threat_refs"]),
                ))

        return findings
