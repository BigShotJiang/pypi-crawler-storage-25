"""nftables 默认策略审计（Phase 7e.2）。

Pulls 'nft -j list ruleset' (JSON) and emits one Finding per hooked
chain (hook=input/forward) whose policy is neither 'drop' nor 'reject'.
Empty ruleset → 1 critical finding (nft installed but unused).
"""

from __future__ import annotations

import hashlib
import json

from ..findings import Finding
from ._firewall_common import (
    detect_nft,
    looks_like_perm_denied,
    output_managed_by_firewalld,
    output_managed_by_ufw,
)
from .base import Check, CheckContext


class NftablesAuditCheck(Check):
    id = "nftables_audit"

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_nft(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 nft 二进制"
            )
            return []

        result = ctx.executor.run(["nft", "-j", "list", "ruleset"])

        if result.rejected:
            ctx.status.skipped(
                f"{self.id}：nft 命令被策略拒绝 ({result.reject_reason})"
            )
            return []
        if result.exit_code != 0:
            if looks_like_perm_denied(result.stderr):
                ctx.status.skipped(
                    f"{self.id}：权限不足，需 root 或 NOPASSWD sudoers"
                )
            else:
                ctx.status.skipped(
                    f"{self.id}：nft 退出码 {result.exit_code}"
                )
            return []
        if not result.stdout.strip():
            ctx.status.skipped(f"{self.id}：nft 输出为空")
            return []

        if output_managed_by_ufw(result.stdout, backend="nftables"):
            ctx.status.not_applicable(
                f"{self.id}：检出 ufw 表，由 ufw_audit 评估"
            )
            return []
        if output_managed_by_firewalld(result.stdout, backend="nftables"):
            ctx.status.not_applicable(
                f"{self.id}：检出 firewalld 接管的 nftables 表，由 firewalld_audit 评估"
            )
            return []

        try:
            parsed = json.loads(result.stdout)
        except json.JSONDecodeError:
            ctx.status.skipped(f"{self.id}：nft -j 输出非 JSON")
            return []

        items = parsed.get("nftables", [])
        ruleset_sha = hashlib.sha256(result.stdout.encode("utf-8")).hexdigest()

        if not items:
            return [Finding(
                check=self.id, severity="critical",
                title="nftables ruleset 为空且 nft 已安装，等同未启用过滤",
                description=(
                    "默认接收策略 / 后端未激活 / IPv6 平行漏洞 — "
                    "CIS Linux 加固基线"
                ),
                evidence={"ruleset_sha256": ruleset_sha},
                remediation=(
                    "装载 nftables 规则集并 enable nftables 服务；或改用 ufw"
                ),
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            )]

        findings: list[Finding] = []
        for entry in items:
            chain = entry.get("chain")
            if not chain:
                continue
            hook = chain.get("hook")
            if hook not in ("input", "forward"):
                continue
            policy = chain.get("policy")
            if policy in ("drop", "reject"):
                continue
            family = chain.get("family", "?")
            table = chain.get("table", "?")
            name = chain.get("name", "?")
            severity = "critical" if hook == "input" else "high"
            findings.append(Finding(
                check=self.id, severity=severity,
                title=(
                    f"nftables {family} 表 {table} 链 {name} (hook={hook}) "
                    f"默认策略为 {policy}"
                ),
                description=(
                    "默认接收策略 / 后端未激活 / IPv6 平行漏洞 — "
                    "CIS Linux 加固基线"
                ),
                evidence={
                    "family": family, "table": table, "chain": name,
                    "hook": hook, "policy": policy,
                    "ruleset_sha256": ruleset_sha,
                },
                remediation=(
                    "将 hooked chain 默认策略改为 drop/reject；"
                    "或显式 add rule … reject"
                ),
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            ))
        return findings
