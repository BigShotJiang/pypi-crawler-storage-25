"""Docker 运行时容器审计（Phase 7f）。

`docker ps --format json` 列出运行中容器；逐个 `docker inspect <id>`
解析 HostConfig + Config，按 container_baseline.yaml:runtime 段 emit
findings。Config.Env 在解析阶段直接丢弃（不进 evidence、不进
audit-log）。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from ..findings import Finding
from ._docker_common import detect_docker, is_path_under
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"
_MAX_CONTAINERS = 200


class DockerRuntimeAuditCheck(Check):
    id = "docker_runtime_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._rules = {r["id"]: r for r in baseline["runtime"]}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if detect_docker(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 docker 二进制"
            )
            return []

        ps_result = ctx.executor.run(
            ["docker", "ps", "--format", "{{json .}}", "--no-trunc"],
        )
        if ps_result.rejected or ps_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：docker ps 调用失败（exit_code={ps_result.exit_code}, "
                f"stderr={ps_result.stderr[:80]!r}）"
            )
            return []

        # docker ps each line one JSON object
        containers: list[dict] = []
        for line in ps_result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                containers.append(json.loads(line))
            except json.JSONDecodeError:
                continue

        findings: list[Finding] = []

        if len(containers) > _MAX_CONTAINERS:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"容器数量异常多：{len(containers)} 个，仅遍历前 {_MAX_CONTAINERS}",
                description="本次审计因容器数量超过阈值已截断。",
                evidence={
                    "rule_id": "runtime-container-count-truncated",
                    "total_count": len(containers),
                    "scanned_count": _MAX_CONTAINERS,
                },
                remediation="减少同主机容器数量，或在 issue 中反馈调高阈值。",
                threat_refs=[],
            ))
            containers = containers[:_MAX_CONTAINERS]

        for c in containers:
            container_id = c.get("ID", "")
            if not container_id:
                continue
            inspect_result = ctx.executor.run(
                ["docker", "inspect", container_id],
            )
            if inspect_result.rejected or inspect_result.exit_code != 0:
                continue   # partial failure: skip this container, don't escalate skipped
            try:
                inspect_data = json.loads(inspect_result.stdout)
                if not isinstance(inspect_data, list) or not inspect_data:
                    continue
                detail = inspect_data[0]
            except (json.JSONDecodeError, IndexError):
                continue

            findings.extend(self._evaluate_container(ctx, c, detail))

        return findings

    def _evaluate_container(
        self, ctx: CheckContext, summary: dict[str, Any], detail: dict[str, Any],
    ) -> list[Finding]:
        # ★ Security first: drop Config.Env (secret leak risk)
        config = detail.get("Config", {})
        config.pop("Env", None)
        host_config = detail.get("HostConfig", {})

        meta = {
            "container_id": summary.get("ID", "")[:12],
            "image": summary.get("Image", ""),
            "names": summary.get("Names", ""),
        }
        out: list[Finding] = []

        # runtime-privileged
        if host_config.get("Privileged"):
            out.append(self._emit(ctx, "runtime-privileged", meta, {
                "hit_field": "HostConfig.Privileged", "hit_value": True,
            }))

        # runtime-host-net
        if host_config.get("NetworkMode") == "host":
            out.append(self._emit(ctx, "runtime-host-net", meta, {
                "hit_field": "HostConfig.NetworkMode", "hit_value": "host",
            }))

        # runtime-sock-mount + runtime-host-fs-mount
        binds = host_config.get("Binds") or []
        sensitive_paths = self._rules["runtime-host-fs-mount"]["sensitive_host_paths"]
        for bind in binds:
            if not isinstance(bind, str):
                continue
            src = bind.split(":", 1)[0]
            if src == "/var/run/docker.sock":
                out.append(self._emit(ctx, "runtime-sock-mount", meta, {
                    "hit_field": "HostConfig.Binds", "hit_value": bind,
                }))
                continue   # sock mount already emitted, don't duplicate as host-fs
            for sensitive in sensitive_paths:
                if is_path_under(src, sensitive):
                    out.append(self._emit(ctx, "runtime-host-fs-mount", meta, {
                        "hit_field": "HostConfig.Binds",
                        "hit_value": bind,
                        "sensitive_root": sensitive,
                    }))
                    break

        # runtime-root-user
        user = config.get("User", "")
        if user in ("", "root", "0"):
            out.append(self._emit(ctx, "runtime-root-user", meta, {
                "hit_field": "Config.User", "hit_value": user or "(empty)",
            }))

        # runtime-cap-dangerous (multi-cap each emit)
        cap_add = host_config.get("CapAdd") or []
        dangerous = self._rules["runtime-cap-dangerous"]["dangerous_caps"]
        for cap in cap_add:
            if cap in dangerous:
                out.append(self._emit(ctx, "runtime-cap-dangerous", meta, {
                    "hit_field": "HostConfig.CapAdd",
                    "hit_value": cap,
                    "cap": cap,
                }))

        # runtime-no-new-priv-missing
        security_opt = host_config.get("SecurityOpt") or []
        has_no_new_priv = any(
            isinstance(s, str) and "no-new-privileges:true" in s
            for s in security_opt
        )
        # Only flag when user is root: non-root containers are less of a setuid risk;
        # this matches the runtime-no-new-priv-missing rule semantics in container_baseline.yaml.
        if not has_no_new_priv and user in ("", "root", "0"):
            out.append(self._emit(ctx, "runtime-no-new-priv-missing", meta, {
                "hit_field": "HostConfig.SecurityOpt",
                "hit_value": security_opt,
            }))

        return out

    def _emit(
        self, ctx: CheckContext, rule_id: str, meta: dict[str, Any], extra: dict[str, Any],
    ) -> Finding:
        rule = self._rules[rule_id]
        evidence = {"rule_id": rule_id, **meta, **extra}
        return self.make_finding(
            ctx,
            severity=rule["severity"],
            title=f"{rule['title']}（{meta.get('image', '')} / {meta.get('names', '')}）",
            description=rule["description"],
            evidence=evidence,
            remediation=rule["remediation"],
            threat_refs=list(rule["threat_refs"]),
        )
