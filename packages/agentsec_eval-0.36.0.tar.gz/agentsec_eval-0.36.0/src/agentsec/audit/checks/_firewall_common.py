"""Phase 7e.2 firewall Check 共享 helper。"""

from __future__ import annotations

import json

from .base import CheckContext

_IPTABLES_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/sbin/iptables",
    "/sbin/iptables",
    "/usr/bin/iptables",
)

_NFT_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/sbin/nft",
    "/sbin/nft",
    "/usr/bin/nft",
)

_UFW_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/sbin/ufw",
    "/sbin/ufw",
    "/usr/bin/ufw",
)

# firewalld has no sbin variant (RHEL/CentOS install at /usr/bin only;
# /bin/ is a compatibility symlink on RHEL 8+).
_FIREWALLD_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/firewall-cmd",
    "/bin/firewall-cmd",
)

PERM_DENIED_SUBSTRINGS: tuple[str, ...] = (
    "permission denied",
    "operation not permitted",
    "must be root",
    "you need to be root",
)


def looks_like_perm_denied(stderr: str) -> bool:
    """子串匹配 stderr 是否表明权限不足（best-effort 策略，详见 spec §3.5）。"""
    s = stderr.lower()
    return any(needle in s for needle in PERM_DENIED_SUBSTRINGS)


def _stat_probe(ctx: CheckContext, candidates: tuple[str, ...]) -> str | None:
    for path in candidates:
        result = ctx.executor.run(["stat", "-c", "%n", path])
        if not result.rejected and result.exit_code == 0:
            return path
    return None


def detect_iptables(ctx: CheckContext) -> str | None:
    """探测 iptables 二进制路径；首个 stat 命中即返，全失败返 None。"""
    return _stat_probe(ctx, _IPTABLES_BIN_CANDIDATES)


def detect_nft(ctx: CheckContext) -> str | None:
    """探测 nft 二进制路径；首个 stat 命中即返，全失败返 None。"""
    return _stat_probe(ctx, _NFT_BIN_CANDIDATES)


def detect_ufw(ctx: CheckContext) -> str | None:
    """探测 ufw 二进制路径；首个 stat 命中即返，全失败返 None。"""
    return _stat_probe(ctx, _UFW_BIN_CANDIDATES)


def detect_firewalld(ctx: CheckContext) -> str | None:
    """探测 firewall-cmd 二进制路径；首个 stat 命中即返，全失败返 None。"""
    return _stat_probe(ctx, _FIREWALLD_BIN_CANDIDATES)


def output_managed_by_firewalld(stdout: str, *, backend: str) -> bool:
    """检测目标后端 dump 是否被 firewalld 接管，避免 iptables/nft Check
    与 firewalld_audit 双报。

    backend="iptables"：扫两类 firewalld 独有自建链前缀（任一命中即真）：
      1. 含 '-N IN_' 行（per-zone input chain）
      2. 含 '-N FWDI_' 行（per-zone forward-in chain）
      iptables 默认配置不会出现这两个前缀。

    backend="nftables"：JSON 解析后只看顶层 table.name == "firewalld"
      （现代 firewalld 默认以 nftables 为后端，建一个 inet 家族的
      `firewalld` 表）。解析失败回退 False（让上层 JSONDecodeError
      走自己的 skipped 分支）。
    """
    if backend == "iptables":
        if "-N IN_" in stdout or "-N FWDI_" in stdout:
            return True
        return False
    if backend == "nftables":
        try:
            parsed = json.loads(stdout)
        except json.JSONDecodeError:
            return False
        for entry in parsed.get("nftables", []):
            table = entry.get("table")
            if isinstance(table, dict) and table.get("name") == "firewalld":
                return True
        return False
    raise ValueError(f"unknown backend {backend!r}")


def output_managed_by_ufw(stdout: str, *, backend: str) -> bool:
    """检测目标后端的 dump 是否被 ufw 接管，避免 iptables/nftables Check
    与 ufw_audit 双报。

    backend="iptables"：扫三种痕迹（自建链 / hook 行 / [ufw 注释 tag）。
    backend="nftables"：JSON 解析后只看顶层 table.name == "ufw"，避免
    被链或注释里碰巧含 "ufw" 字面量的情况误判。解析失败回退为 False
    （让上层 JSONDecodeError 走自己的 skipped 分支）。
    """
    if backend == "iptables":
        if "-N ufw-" in stdout or "-A ufw-" in stdout:
            return True
        if "-j ufw-before-input" in stdout or "-j ufw-reject-input" in stdout:
            return True
        if "[ufw" in stdout:
            return True
        return False
    if backend == "nftables":
        try:
            parsed = json.loads(stdout)
        except json.JSONDecodeError:
            return False
        for entry in parsed.get("nftables", []):
            table = entry.get("table")
            if isinstance(table, dict) and table.get("name") == "ufw":
                return True
        return False
    raise ValueError(f"unknown backend {backend!r}")
