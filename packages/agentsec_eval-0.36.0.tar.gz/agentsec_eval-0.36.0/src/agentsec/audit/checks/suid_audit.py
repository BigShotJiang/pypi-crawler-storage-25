"""SUID/SGID whitelist drift audit (Phase 7e).

Enumerates SUID files under /usr/bin and /usr/sbin via find, compares each
against a baseline whitelist, emits one Finding per non-whitelist entry.
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ..findings import Finding
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)
_SCAN_DIRS: tuple[str, ...] = ("/usr/bin", "/usr/sbin")


class SuidAuditCheck(Check):
    id = "suid_audit"

    def __init__(self):
        super().__init__()
        section = yaml.safe_load(_BASELINE_PATH.read_text())["suid"]
        self._whitelist = set(section["expected"])
        self._severity = section["unexpected_severity"]
        self._rationale = section["rationale"]
        self._remediation = section["remediation"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"suid_audit：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []
        all_failed = True
        suid_paths: list[str] = []
        for d in _SCAN_DIRS:
            result = ctx.executor.run([
                "find", d, "-maxdepth", "1", "-type", "f",
                "-perm", "/4000",
            ])
            if result.rejected:
                continue
            if result.exit_code != 0:
                continue
            all_failed = False
            for line in result.stdout.splitlines():
                line = line.strip()
                if line:
                    suid_paths.append(line)
        if all_failed:
            ctx.status.skipped(
                "suid_audit 全部 find 调用失败（可能权限不足）"
            )
            return []
        findings: list[Finding] = []
        for path in suid_paths:
            if path in self._whitelist:
                continue
            findings.append(Finding(
                check=self.id,
                severity=self._severity,
                title=f"非白名单 SUID/SGID 二进制：{path}",
                description=self._rationale,
                evidence={"path": path},
                remediation=self._remediation,
                threat_refs=["TI-LINUX-CIS-SUID"],
            ))
        return findings
