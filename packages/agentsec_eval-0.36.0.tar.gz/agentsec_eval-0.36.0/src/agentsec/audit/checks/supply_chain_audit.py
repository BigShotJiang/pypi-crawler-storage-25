"""npm 供应链漏洞审计（Phase 7d）。

Reads OpenClaw's npm package-lock.json on the audited host, walks the
transitive dependency tree, and matches each (name, version) against a
bundled OSV-npm advisory subset. Emits one Finding per matching
(pkg, version, advisory) tuple.

DB schema (src/agentsec/audit/ioc/osv_npm.json):
  [{"id": "GHSA-xxxx", "package": "lodash",
    "ranges": [{"introduced": "0", "fixed": "4.17.21"}],
    "severity": "critical|high|medium|low", "summary": "...",
    "url": "...", "aliases": ["CVE-..."]}, ...]
"""

from __future__ import annotations

import json
from pathlib import Path

import semver

from ..findings import Finding
from ._supply_chain_common import (
    Severity,
    extract_severity_label,
    load_advisory_db,
    severity_from_cvss_score,
)
from .base import Check, CheckContext

__all__ = [
    "SupplyChainAuditCheck",
    "Severity",
    "severity_from_cvss_score",
    "parse_npm_lock",
    "version_in_any_range",
]


def parse_npm_lock(stdout: str) -> list[tuple[str, str]]:
    """Return [(pkg_name, version)] from package-lock.json v2/v3.

    Skips the root entry (path key=='') and 'link' entries (workspace
    symlinks have no real version). lockfileVersion 1 silently returns
    [] (deps live under a different key shape we don't support).
    """
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError:
        return []
    pkgs: list[tuple[str, str]] = []
    for path_key, entry in data.get("packages", {}).items():
        if path_key == "":
            continue
        if not isinstance(entry, dict):
            continue
        if entry.get("link"):
            continue
        version = entry.get("version")
        if not version:
            continue
        # path_key 'node_modules/foo/node_modules/bar' → bar
        # 'node_modules/@scope/pkg' → @scope/pkg
        parts = path_key.split("node_modules/")
        name = parts[-1]
        if not name:
            continue
        pkgs.append((name, version))
    return pkgs


def _safe_parse_semver(s: str) -> semver.Version | None:
    """Return semver.Version or None on parse failure."""
    try:
        return semver.Version.parse(s)
    except (ValueError, TypeError):
        return None


def version_in_any_range(version: str, ranges: list[dict]) -> bool:
    """True iff `version` falls into at least one OSV range entry.

    Range entry shape (npm subset):
      {"introduced": "0", "fixed": "4.17.21"}
      {"introduced": "1.0.0", "last_affected": "1.2.5"}

    Non-semver versions return False (caller treats as 'cannot match').
    """
    v = _safe_parse_semver(version)
    if v is None:
        return False
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last = r.get("last_affected")

        intro_v = _safe_parse_semver(intro) if intro != "0" else None
        if intro_v is not None and v.compare(intro_v) < 0:
            continue   # version < introduced

        if fixed is not None:
            fixed_v = _safe_parse_semver(fixed)
            if fixed_v is not None and v.compare(fixed_v) >= 0:
                continue   # version >= fixed → safe

        if last is not None:
            last_v = _safe_parse_semver(last)
            if last_v is not None and v.compare(last_v) > 0:
                continue   # version > last_affected → outside

        return True
    return False


# ---- Check class (orchestrates the helpers above) ----

_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_npm.json"


class SupplyChainAuditCheck(Check):
    id = "supply_chain_audit"
    _REQUIRED_PATHS = ("npm_root",)

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        path = db_path if db_path is not None else _OSV_DB_PATH
        self._advisories_by_pkg = load_advisory_db(path)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(f"{self.id}：非 Linux profile")
            return []
        if not self.check_required_paths(ctx):
            return []

        npm_root = ctx.profile.paths["npm_root"]
        lock_path = f"{npm_root}/package-lock.json"
        result = ctx.executor.run(["cat", lock_path])

        if result.rejected:
            ctx.status.skipped(
                f"{self.id}：cat 被策略拒绝 ({result.reject_reason})"
            )
            return []
        if result.exit_code != 0:
            stderr_l = (result.stderr or "").lower()
            if "permission denied" in stderr_l:
                ctx.status.skipped(f"{self.id}：权限不足读 lock 文件")
            else:
                ctx.status.not_applicable(
                    f"{self.id}：{lock_path} 不可读（npm 安装路径不在 npm_root 候选）"
                )
            return []
        if not result.stdout.strip():
            ctx.status.skipped(f"{self.id}：lock 文件为空")
            return []

        try:
            json.loads(result.stdout)
        except json.JSONDecodeError as e:
            ctx.status.skipped(f"{self.id}：package-lock.json 非合法 JSON：{e}")
            return []

        pkgs = parse_npm_lock(result.stdout)
        findings: list[Finding] = []
        for pkg, version in pkgs:
            if _safe_parse_semver(version) is None:
                findings.append(self.make_finding(
                    ctx,
                    severity="low",
                    title=f"无法解析 semver: {pkg}@{version}",
                    description="非标准版本字符串（如 file:、git: 引用），无法对照 OSV 数据库",
                    evidence={
                        "package": pkg, "version": version,
                        "lock_path": lock_path,
                    },
                    remediation="如需审计该包，改为发布的 semver 版本（npm publish）",
                    threat_refs=["TI-OSV-NPM-CATALOG"],
                ))
                continue
            for adv in self._advisories_by_pkg.get(pkg, []):
                if version_in_any_range(version, adv["ranges"]):
                    findings.append(self._make_advisory_finding(
                        ctx, pkg, version, adv, lock_path,
                    ))
        return findings

    def _make_advisory_finding(
        self, ctx: CheckContext, pkg: str, version: str, adv: dict, lock_path: str,
    ) -> Finding:
        sev = extract_severity_label(adv)
        adv_id = adv["id"]
        fixed_in = next(
            (r["fixed"] for r in adv["ranges"] if r.get("fixed")),
            "(no fixed version)",
        )
        return self.make_finding(
            ctx,
            severity=sev,
            title=f"npm {pkg}@{version} 命中 {adv_id}（severity={sev}）",
            description=adv.get("summary", "")[:200],
            evidence={
                "package": pkg,
                "version": version,
                "advisory_id": adv_id,
                "aliases": adv.get("aliases", []),
                "fixed_in": fixed_in,
                "url": adv.get("url", ""),
                "lock_path": lock_path,
            },
            remediation=f"npm upgrade {pkg}@{fixed_in}（或更高版本）",
            threat_refs=["TI-OSV-NPM-CATALOG"],
        )
