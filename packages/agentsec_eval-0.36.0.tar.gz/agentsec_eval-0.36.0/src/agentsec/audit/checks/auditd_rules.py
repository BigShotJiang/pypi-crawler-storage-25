"""auditd rules audit (Phase 7e.1).

`auditctl -s` 探测状态：exit 127 → not_applicable；
enabled=0 → 1 high finding；其它非 0 退出码 → skipped。
然后 `auditctl -l` 拉规则列表，按 8 条 CIS baseline 做 stable-substring 匹配，
每条缺失 emit 1 finding。
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ..findings import Finding
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)


class AuditdRulesCheck(Check):
    id = "auditd_rules_audit"

    def __init__(self):
        super().__init__()
        section = yaml.safe_load(_BASELINE_PATH.read_text())["auditd"]
        self._required_rules = section["required_rules"]
        self._status_disabled_severity = section["status_disabled_severity"]
        self._rationale = section["rationale"]
        self._remediation = section["remediation"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"auditd_rules_audit：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []

        status_result = ctx.executor.run(["auditctl", "-s"])
        if status_result.rejected:
            ctx.status.skipped(
                f"auditd_rules_audit 被策略拒绝：{status_result.reject_reason}"
            )
            return []
        if status_result.exit_code == 127:
            ctx.status.not_applicable("auditd 未安装（auditctl 不可用）")
            return []
        if status_result.exit_code != 0:
            ctx.status.skipped(
                f"auditd_rules_audit `auditctl -s` 退出码 "
                f"{status_result.exit_code}（非 not-installed）"
            )
            return []

        findings: list[Finding] = []
        if "enabled 0" in status_result.stdout:
            findings.append(Finding(
                check=self.id,
                severity=self._status_disabled_severity,
                title="auditd 已安装但 enabled=0（审计子系统已禁用）",
                description=self._rationale,
                evidence={"status_dump": status_result.stdout.strip()},
                remediation=self._remediation,
                threat_refs=["TI-LINUX-CIS-AUDITD"],
            ))

        # 注意：此分支可能与上面 `enabled 0` Finding 共存——`auditctl -s`
        # 成功后我们已经 emit 1 条 high finding，但 `auditctl -l` 失败时
        # 仍 mark skipped 并返回部分 findings。这是有意为之：partial info
        # 优于 no info；reporter 端把 status=skipped 与 finding 并列展示。
        rules_result = ctx.executor.run(["auditctl", "-l"])
        if rules_result.rejected:
            ctx.status.skipped(
                f"auditd_rules_audit `auditctl -l` 被策略拒绝："
                f"{rules_result.reject_reason}"
            )
            return findings
        if rules_result.exit_code != 0:
            ctx.status.skipped(
                f"auditd_rules_audit `auditctl -l` 退出码 "
                f"{rules_result.exit_code}"
            )
            return findings

        rule_text = rules_result.stdout
        for rule in self._required_rules:
            if rule["match"] not in rule_text:
                findings.append(Finding(
                    check=self.id,
                    severity=rule["severity"],
                    title=(
                        f"auditd 缺失规则 {rule['id']!r}："
                        f"期望子串 {rule['match']!r}"
                    ),
                    description=self._rationale,
                    evidence={
                        "rule_id": rule["id"],
                        "expected_match": rule["match"],
                    },
                    remediation=self._remediation,
                    threat_refs=["TI-LINUX-CIS-AUDITD"],
                ))
        return findings
