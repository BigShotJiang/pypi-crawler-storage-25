"""PHP / Packagist 供应链漏洞审计（Phase 7d.6）。

Reads operator-configured composer.lock files on the audited host, parses
each (package, version, scope) tuple, and matches against a bundled
OSV-Packagist advisory subset using packaging.version (PEP 440) ranges with
Composer→PEP 440 preprocessing. Emits one Finding per matching
(package, version, advisory) tuple.

DB schema (src/agentsec/audit/ioc/osv_packagist.json):
  [{"id": "GHSA-xxxx", "package": "symfony/console",
    "ranges": [{"introduced": "1.0", "fixed": "2.0"}],
    "severity": "critical|high|medium|low", "summary": "...",
    "url": "...", "aliases": ["CVE-..."]}, ...]
"""

from __future__ import annotations

from pathlib import Path

from ..findings import Finding
from ._supply_chain_common import (
    _is_composer_version_in_range,
    extract_severity_label,
    load_advisory_db,
    parse_composer_lock,
)
from .base import Check, CheckContext

_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_packagist.json"


def _match_composer_advisories(
    package: str,
    version: str,
    advisories_by_pkg: dict[str, list[dict]],
) -> list[dict]:
    """Return all advisory entries that match (package, version).

    package is a lowercase Packagist package name (case-insensitive).
    Matching uses PEP 440 ranges with Composer→PEP 440 preprocessing
    via `_is_composer_version_in_range`.
    """
    matched: list[dict] = []
    for adv in advisories_by_pkg.get(package, []):
        for r in adv.get("ranges", []):
            introduced = r.get("introduced")
            fixed = r.get("fixed")
            if _is_composer_version_in_range(version, introduced, fixed):
                matched.append(adv)
                break
    return matched


# --- Check class ---


class PhpSupplyChainAuditCheck(Check):
    id = "php_supply_chain_audit"

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        path = db_path if db_path is not None else _OSV_DB_PATH
        try:
            self._advisories_by_pkg = load_advisory_db(path)
        except FileNotFoundError:
            # DB not yet built (Task 9 builds osv_packagist.json). Return empty
            # dict so unit tests and pre-build environments don't crash.
            self._advisories_by_pkg = {}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(f"{self.id}：非 Linux profile")
            return []
        if not ctx.composer_lock_paths:
            ctx.status.not_applicable(f"{self.id}：未配置 composer_lock_paths")
            return []

        findings: list[Finding] = []
        n_skipped = 0
        for lock_path in ctx.composer_lock_paths:
            result = ctx.executor.run(["cat", lock_path])
            if result.rejected:
                n_skipped += 1
                continue
            if result.exit_code != 0:
                n_skipped += 1
                continue
            if not result.stdout.strip():
                n_skipped += 1
                continue
            findings.extend(self._scan_lockfile(ctx, lock_path, result.stdout))
        if not findings and n_skipped == len(ctx.composer_lock_paths):
            ctx.status.skipped(
                f"{self.id}：所有 composer_lock_paths 均不可读 (n={n_skipped})"
            )
        return findings

    def _scan_lockfile(
        self, ctx: CheckContext, lock_path: str, stdout: str,
    ) -> list[Finding]:
        deps = parse_composer_lock(stdout)
        findings: list[Finding] = []
        for package, version, scope in deps:
            for adv in _match_composer_advisories(package, version, self._advisories_by_pkg):
                findings.append(
                    self._advisory_finding(ctx, package, version, scope, adv, lock_path)
                )
        return findings

    def _advisory_finding(
        self, ctx: CheckContext, package: str, version: str, scope: str,
        adv: dict, lock_path: str,
    ) -> Finding:
        sev = extract_severity_label(adv)
        adv_id = adv["id"]
        fixed_in = next(
            (r["fixed"] for r in adv.get("ranges", []) if r.get("fixed")),
            "(no fixed version)",
        )
        return self.make_finding(
            ctx,
            severity=sev,
            title=f"php {package}@{version} 命中 {adv_id}（severity={sev}）",
            description=adv.get("summary", "")[:200],
            evidence={
                "package": package,
                "version": version,
                "scope": scope,
                "advisory_id": adv_id,
                "aliases": adv.get("aliases", []),
                "fixed_in": fixed_in,
                "url": adv.get("url", ""),
                "lock_path": lock_path,
            },
            remediation=(
                f"在 composer.json 中将 {package} 升级到 {fixed_in}"
            ),
            threat_refs=["TI-OSV-PACKAGIST-CATALOG"],
        )
