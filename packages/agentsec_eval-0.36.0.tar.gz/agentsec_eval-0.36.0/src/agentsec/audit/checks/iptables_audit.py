"""iptables / ip6tables 默认策略审计（Phase 7e.2）。

Pulls 'iptables -S' + 'ip6tables -S' and emits one Finding per chain
(INPUT/FORWARD) whose default policy is neither DROP nor REJECT.
v4 / v6 are independent: v6 failure does not poison v4 reporting and
vice versa. Whole-Check status is set only if BOTH families failed.
"""

from __future__ import annotations

import hashlib

from ..findings import Finding
from ._firewall_common import (
    detect_iptables,
    looks_like_perm_denied,
    output_managed_by_firewalld,
    output_managed_by_ufw,
)
from .base import Check, CheckContext

# Sentinel return values from _evaluate_family — used only inside this module.
_SKIPPED = object()
_PERM_DENIED = object()
_UFW_TAKEOVER = object()
_FIREWALLD_TAKEOVER = object()


def parse_iptables_default_policies(stdout: str) -> dict[str, str]:
    """从 'iptables -S' 输出抓 -P <CHAIN> <POLICY> 行。"""
    out: dict[str, str] = {}
    for line in stdout.splitlines():
        line = line.strip()
        if not line.startswith("-P "):
            continue
        parts = line.split()
        if len(parts) >= 3:
            out[parts[1]] = parts[2]
    return out


class IptablesAuditCheck(Check):
    id = "iptables_audit"

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_iptables(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 iptables 二进制"
            )
            return []

        v4_result = ctx.executor.run(["iptables",  "-S"])
        v6_result = ctx.executor.run(["ip6tables", "-S"])

        v4_findings = self._evaluate_family(v4_result, family="ipv4")
        v6_findings = self._evaluate_family(v6_result, family="ipv6")

        # ufw 接管（任一 family 命中即整体 not_applicable，避免双报）。
        # Note: corner case — ufw with IPV6=no would leave v6 unmanaged.
        # 7e.2 takes the simpler approach (defer entirely); revisit in 7e.5.
        if v4_findings is _UFW_TAKEOVER or v6_findings is _UFW_TAKEOVER:
            ctx.status.not_applicable(
                f"{self.id}：检出 ufw 注入链，由 ufw_audit 评估"
            )
            return []
        if v4_findings is _FIREWALLD_TAKEOVER or v6_findings is _FIREWALLD_TAKEOVER:
            ctx.status.not_applicable(
                f"{self.id}：检出 firewalld 注入链，由 firewalld_audit 评估"
            )
            return []

        v4_ok = isinstance(v4_findings, list)
        v6_ok = isinstance(v6_findings, list)

        # If neither family produced parseable output → skipped.
        if not v4_ok and not v6_ok:
            if v4_findings is _PERM_DENIED or v6_findings is _PERM_DENIED:
                ctx.status.skipped(
                    f"{self.id}：权限不足，需 root 或 NOPASSWD sudoers "
                    "（在该主机为执行用户配置 NOPASSWD sudoers，"
                    "或以 root 身份运行 agentsec server-audit）"
                )
            else:
                reason = (
                    self._skip_reason(v4_result)
                    or self._skip_reason(v6_result)
                    or f"{self.id} 命令全部失败"
                )
                ctx.status.skipped(reason)
            return []

        result: list[Finding] = []
        if v4_ok:
            result.extend(v4_findings)  # type: ignore[arg-type]
        if v6_ok:
            result.extend(v6_findings)  # type: ignore[arg-type]
        return result

    def _skip_reason(self, r: object) -> str | None:
        if getattr(r, "rejected", False):
            reject_reason = getattr(r, "reject_reason", None)
            return f"{self.id}：iptables 命令被策略拒绝 ({reject_reason})"
        stderr = getattr(r, "stderr", "")
        if looks_like_perm_denied(stderr):
            return (
                f"{self.id}：权限不足，需 root 或 NOPASSWD sudoers "
                "（在该主机为执行用户配置 NOPASSWD sudoers，"
                "或以 root 身份运行 agentsec server-audit）"
            )
        exit_code = getattr(r, "exit_code", 0)
        if exit_code != 0:
            return f"{self.id}：iptables 退出码 {exit_code}"
        return None

    def _evaluate_family(self, result: object, *, family: str) -> object:
        if getattr(result, "rejected", False):
            return _SKIPPED
        exit_code = getattr(result, "exit_code", 0)
        stderr = getattr(result, "stderr", "")
        stdout = getattr(result, "stdout", "")
        if exit_code != 0:
            if looks_like_perm_denied(stderr):
                return _PERM_DENIED
            return _SKIPPED
        if not stdout.strip():
            return _SKIPPED
        if output_managed_by_ufw(stdout, backend="iptables"):
            return _UFW_TAKEOVER
        if output_managed_by_firewalld(stdout, backend="iptables"):
            return _FIREWALLD_TAKEOVER
        policies = parse_iptables_default_policies(stdout)
        findings: list[Finding] = []
        dump_sha = hashlib.sha256(stdout.encode("utf-8")).hexdigest()
        for chain in ("INPUT", "FORWARD"):
            policy = policies.get(chain)
            if policy is None:
                continue
            if policy in ("DROP", "REJECT"):
                continue
            severity = "critical" if (chain == "INPUT" or family == "ipv6") else "high"
            findings.append(Finding(
                check=self.id, severity=severity,
                title=(
                    f"iptables {family} {chain} 默认策略为 {policy}（应为 DROP/REJECT）"
                ),
                description=(
                    "默认接收策略 / 后端未激活 / IPv6 平行漏洞 — "
                    "CIS Linux 加固基线"
                ),
                evidence={
                    "family": family, "chain": chain, "policy": policy,
                    "dump_sha256": dump_sha,
                },
                remediation=(
                    "设置 INPUT/FORWARD 默认策略为 DROP/REJECT；"
                    "如使用 ufw / nftables 前端，请通过对应工具配置"
                ),
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            ))
        return findings
