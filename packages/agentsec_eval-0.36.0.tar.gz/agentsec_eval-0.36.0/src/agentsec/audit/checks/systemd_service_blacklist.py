"""systemd service blacklist (Phase 7e.1).

Enumerates enabled systemd services and sockets via
`systemctl list-unit-files --type=service,socket --state=enabled --no-legend
--plain`，对照 baseline 黑名单（10 条 telnet/rsh/rlogin/rexec/tftp/nfs/rpcbind/
avahi/cups/xinetd），命中即 emit 一条 Finding。
"""

from __future__ import annotations

from pathlib import Path

import yaml

from ..findings import Finding
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)


class SystemdServiceBlacklistCheck(Check):
    id = "systemd_service_blacklist"

    def __init__(self):
        super().__init__()
        sb = yaml.safe_load(_BASELINE_PATH.read_text())["systemd"]["service_blacklist"]
        self._index = {s["name"]: s for s in sb["services"]}
        self._remediation = sb["remediation"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"systemd_service_blacklist：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []

        argv = [
            "systemctl", "list-unit-files", "--type=service,socket",
            "--state=enabled", "--no-legend", "--plain",
        ]
        result = ctx.executor.run(argv)
        if result.rejected:
            ctx.status.skipped(
                f"systemd_service_blacklist 被策略拒绝：{result.reject_reason}"
            )
            return []
        if result.exit_code != 0:
            ctx.status.skipped(
                f"systemd_service_blacklist 退出码 {result.exit_code}"
            )
            return []

        findings: list[Finding] = []
        for line in result.stdout.splitlines():
            parts = line.strip().split()
            if len(parts) < 2:
                continue
            unit, state = parts[0], parts[1]
            if state != "enabled":
                continue
            entry = self._index.get(unit)
            if entry is None:
                continue
            findings.append(Finding(
                check=self.id,
                severity=entry["severity"],
                title=f"高风险服务已启用：{unit}",
                description=entry["rationale"],
                evidence={"unit": unit, "state": state},
                remediation=self._remediation,
                threat_refs=["TI-LINUX-CIS-SYSTEMD"],
            ))
        return findings
