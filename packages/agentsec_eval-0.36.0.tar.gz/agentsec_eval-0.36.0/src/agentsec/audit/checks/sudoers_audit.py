"""sudoers risky-pattern audit (Phase 7e).

Reads /etc/sudoers and every file under /etc/sudoers.d/, scans each line
against baseline forbidden regex patterns, emits one Finding per match.
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from ..findings import Finding
from .base import Check, CheckContext

_BASELINE_PATH = (
    Path(__file__).parent / "linux_hardening_baseline.yaml"
)


class SudoersAuditCheck(Check):
    id = "sudoers_audit"

    def __init__(self):
        super().__init__()
        rules = yaml.safe_load(_BASELINE_PATH.read_text())["sudoers"]
        self._rules = [
            {**r, "compiled": re.compile(r["pattern"])} for r in rules
        ]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"sudoers_audit：当前 profile {ctx.profile.name!r} "
                "不是 Linux，主机加固检查跳过"
            )
            return []
        files: list[str] = ["/etc/sudoers"]
        find_result = ctx.executor.run([
            "find", "/etc/sudoers.d", "-maxdepth", "1", "-type", "f",
        ])
        if not find_result.rejected and find_result.exit_code == 0:
            for line in find_result.stdout.splitlines():
                line = line.strip()
                if line and line != "/etc/sudoers.d":
                    files.append(line)
        findings: list[Finding] = []
        for path in files:
            cat_result = ctx.executor.run(["cat", path])
            if cat_result.rejected or cat_result.exit_code != 0:
                continue
            content = cat_result.stdout
            for rule in self._rules:
                for match in rule["compiled"].finditer(content):
                    snippet = match.group(0).strip()
                    if len(snippet) > 200:
                        snippet = snippet[:200] + "…"
                    findings.append(Finding(
                        check=self.id,
                        severity=rule["severity"],
                        title=(
                            f"sudoers 风险模式 {rule['id']!r} "
                            f"匹配 {path}"
                        ),
                        description=rule["rationale"],
                        evidence={
                            "file": path,
                            "rule": rule["id"],
                            "snippet": snippet,
                        },
                        remediation=rule["remediation"],
                        threat_refs=["TI-LINUX-CIS-SUDOERS"],
                    ))
        return findings
