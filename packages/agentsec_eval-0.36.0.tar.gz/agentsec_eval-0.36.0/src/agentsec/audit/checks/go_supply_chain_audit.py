"""go / OSV-Go 供应链漏洞审计（Phase 7d.2）。

Reads operator-configured go.sum files on the audited host, parses each
entry, matches each (module_path, version) against a bundled OSV-Go
advisory subset using semver-with-Go-prefix-stripping. Emits one
Finding per matching (module, version, advisory) tuple.

DB schema (src/agentsec/audit/ioc/osv_go.json):
  [{"id": "GHSA-xxxx", "package": "github.com/foo/bar",
    "ranges": [{"introduced": "0", "fixed": "v1.2.3"}],
    "severity": "critical|high|medium|low", "summary": "...",
    "url": "...", "aliases": ["CVE-..."]}, ...]
"""

from __future__ import annotations

from pathlib import Path

import semver

from ..findings import Finding
from ._supply_chain_common import (
    extract_severity_label,
    load_advisory_db,
)
from .base import Check, CheckContext

# --- Version handling ---


def _safe_parse_go_version(s: str) -> semver.Version | None:
    """Strip Go-version conventions (v prefix, +incompatible) and parse as semver.

    Pseudo-versions (v0.0.0-20210101120000-abcdef) parse as semver pre-release
    where the timestamp segment provides natural lexicographic ordering.

    Returns None on parse failure.
    """
    if not s:
        return None
    cleaned = s
    if cleaned.startswith("v"):
        cleaned = cleaned[1:]
    if cleaned.endswith("+incompatible"):
        cleaned = cleaned[: -len("+incompatible")]
    try:
        return semver.Version.parse(cleaned)
    except (ValueError, TypeError):
        return None


def version_in_any_go_range(version: str, ranges: list[dict]) -> bool:
    """True iff `version` falls into at least one OSV range entry.

    Range entry shape (Go subset, ECOSYSTEM type with v-prefixed strings):
      {"introduced": "v1.0.0", "fixed": "v2.0.0"}

    Non-parseable versions return False (caller treats as 'cannot match').
    """
    v = _safe_parse_go_version(version)
    if v is None:
        return False
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last = r.get("last_affected")

        if intro != "0":
            intro_v = _safe_parse_go_version(intro)
            if intro_v is not None and v.compare(intro_v) < 0:
                continue
        if fixed is not None:
            fixed_v = _safe_parse_go_version(fixed)
            if fixed_v is not None and v.compare(fixed_v) >= 0:
                continue
        if last is not None:
            last_v = _safe_parse_go_version(last)
            if last_v is not None and v.compare(last_v) > 0:
                continue
        return True
    return False


# --- go.sum parser ---


def parse_go_sum(stdout: str) -> list[tuple[str, str]]:
    """Return [(module_path, version)] from go.sum content.

    Each go.sum line has shape '<module> <version> <hash>' (3 whitespace-
    separated fields). Lines whose version field ends with '/go.mod' duplicate
    the main entries with a different hash flavor and are skipped. Versions
    are kept raw (with 'v' prefix and any '+incompatible' suffix); cleanup
    happens at compare time in _safe_parse_go_version.
    """
    out: list[tuple[str, str]] = []
    for line in stdout.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split()
        if len(parts) != 3:
            continue
        module, version, _hash = parts
        if version.endswith("/go.mod"):
            continue
        out.append((module, version))
    return out


# --- Check class ---


_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_go.json"


class GoSupplyChainAuditCheck(Check):
    id = "go_supply_chain_audit"

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        path = db_path if db_path is not None else _OSV_DB_PATH
        self._advisories_by_pkg = load_advisory_db(path)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(f"{self.id}：非 Linux profile")
            return []
        if not ctx.go_lock_paths:
            ctx.status.not_applicable(f"{self.id}：未配置 go_lock_paths")
            return []

        findings: list[Finding] = []
        n_skipped = 0
        for lock_path in ctx.go_lock_paths:
            result = ctx.executor.run(["cat", lock_path])
            if result.rejected:
                n_skipped += 1
                continue
            if result.exit_code != 0:
                n_skipped += 1
                continue
            if not result.stdout.strip():
                n_skipped += 1
                continue
            findings.extend(self._scan_lockfile(ctx, lock_path, result.stdout))
        if not findings and n_skipped == len(ctx.go_lock_paths):
            ctx.status.skipped(
                f"{self.id}：所有 go_lock_paths 均不可读 (n={n_skipped})"
            )
        return findings

    def _scan_lockfile(
        self, ctx: CheckContext, lock_path: str, stdout: str,
    ) -> list[Finding]:
        modules = parse_go_sum(stdout)
        findings: list[Finding] = []
        for module, version in modules:
            if _safe_parse_go_version(version) is None:
                findings.append(
                    self._unparseable_finding(ctx, module, version, lock_path)
                )
                continue
            for adv in self._advisories_by_pkg.get(module, []):
                if version_in_any_go_range(version, adv["ranges"]):
                    findings.append(
                        self._advisory_finding(ctx, module, version, adv, lock_path)
                    )
        return findings

    def _advisory_finding(
        self, ctx: CheckContext, module: str, version: str,
        adv: dict, lock_path: str,
    ) -> Finding:
        sev = extract_severity_label(adv)
        adv_id = adv["id"]
        fixed_in = next(
            (r["fixed"] for r in adv["ranges"] if r.get("fixed")),
            "(no fixed version)",
        )
        return self.make_finding(
            ctx,
            severity=sev,
            title=f"go {module}@{version} 命中 {adv_id}（severity={sev}）",
            description=adv.get("summary", "")[:200],
            evidence={
                "package": module,
                "version": version,
                "advisory_id": adv_id,
                "aliases": adv.get("aliases", []),
                "fixed_in": fixed_in,
                "url": adv.get("url", ""),
                "lock_path": lock_path,
            },
            remediation=f"go get {module}@{fixed_in}",
            threat_refs=["TI-OSV-GO-CATALOG"],
        )

    def _unparseable_finding(
        self, ctx: CheckContext, module: str, version: str, lock_path: str,
    ) -> Finding:
        return self.make_finding(
            ctx,
            severity="low",
            title=f"无法解析 Go 版本: {module}@{version}",
            description=(
                "非标准 Go module 版本（应为 vX.Y.Z 或 v0.0.0-timestamp-hash 形式）"
            ),
            evidence={
                "package": module, "version": version, "lock_path": lock_path,
            },
            remediation="升级到合法 vX.Y.Z 版本",
            threat_refs=["TI-OSV-GO-CATALOG"],
        )
