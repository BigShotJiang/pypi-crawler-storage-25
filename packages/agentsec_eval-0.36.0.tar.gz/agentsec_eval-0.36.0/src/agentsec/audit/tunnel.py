"""SSH local-port-forward — paramiko direct-tcpip wrapper (spec §7.2).

`open_local_forward(host, user, key, *, remote_port)` returns a context
manager yielding the bound local TCP port. While the context is open, all
bytes written to `127.0.0.1:<local_port>` traverse a paramiko `direct-tcpip`
channel into the SSH transport and emerge on the remote side at
`127.0.0.1:remote_port` (and vice versa).

One channel per local connection — the safer paramiko pattern.

Used by `active_test` to point a local `OpenClawGatewayAdapter` at the
target's localhost-bound OpenClaw API without exposing it to the network.

Tunnel failure (auth, forwarding denied, network) propagates as the
caller's exception so `active_test` can mark the check `skipped` per
spec §7.2 — there is no write-mode fallback.
"""

from __future__ import annotations

import socket
import socketserver
import threading
from collections.abc import Iterator
from contextlib import contextmanager

import paramiko


def _build_ssh_client(host: str, user: str, key: str) -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    client.connect(
        hostname=host,
        username=user,
        key_filename=key,
        allow_agent=False,
        look_for_keys=False,
    )
    return client


def _bridge(local_sock: socket.socket, channel) -> None:
    """Shuttle bytes both ways until either side closes. Two threads (one per
    direction) so a half-closed local socket does not deadlock the return
    path."""
    def _pump(src, dst):
        try:
            while True:
                data = src.recv(4096)
                if not data:
                    break
                dst.send(data)
        except (OSError, EOFError):  # noqa: S110 — socket teardown errors during forwarding are expected
            pass
        finally:
            try:
                dst.close()
            except Exception:  # noqa: BLE001,S110 — best-effort socket teardown
                pass

    t1 = threading.Thread(target=_pump, args=(local_sock, channel), daemon=True)
    t2 = threading.Thread(target=_pump, args=(channel, local_sock), daemon=True)
    t1.start()
    t2.start()
    t1.join()
    t2.join()


@contextmanager
def open_local_forward(
    host: str,
    user: str,
    key: str,
    *,
    remote_port: int,
) -> Iterator[int]:
    client = _build_ssh_client(host, user, key)
    transport = client.get_transport()
    if transport is None:
        # paramiko returns None until SSHClient.connect() succeeds; _build_ssh_client
        # is responsible for connecting, so a None here means a stubbed/broken builder.
        raise RuntimeError("SSH client returned no transport — cannot open forward")
    server: socketserver.ThreadingTCPServer | None = None
    server_thread: threading.Thread | None = None

    try:
        class _Handler(socketserver.BaseRequestHandler):
            def handle(self):
                try:
                    chan = transport.open_channel(
                        "direct-tcpip",
                        dest_addr=("127.0.0.1", remote_port),
                        src_addr=self.client_address,
                    )
                except Exception:
                    # forwarding denied / transport closed → drop this connection
                    # silently. active_test will see the connection error.
                    return
                try:
                    _bridge(self.request, chan)
                finally:
                    try:
                        chan.close()
                    except Exception:  # noqa: BLE001,S110 — best-effort cleanup of forwarded channel
                        pass

        server = socketserver.ThreadingTCPServer(("127.0.0.1", 0), _Handler)
        server.daemon_threads = True
        local_port = server.server_address[1]
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()

        yield local_port

    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        client.close()
