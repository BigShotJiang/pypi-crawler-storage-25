"""Pure-functional aggregation of test results by OWASP framework reference.

Inputs come from the loader (`list[TestCase]`) and the runner (`list[TestResult]`).
Output is an `OwaspCoverageMatrix` that the markdown renderer turns into the
"OWASP 框架覆盖" report section. This module imports nothing from `markdown.py`
so it can be reused by `scripts/check_owasp_coverage.py` without dragging in
report rendering.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..tests.models import TestCase, TestResult


@dataclass(frozen=True)
class FrameworkEntry:
    id: str
    title: str


# Source-of-truth canonical lists. Kept in sync with ADR-0006 and the
# regex in `src/agentsec/tests/owasp_refs.py`.
LLM_TOP10_2025: tuple[FrameworkEntry, ...] = (
    FrameworkEntry("LLM01:2025", "Prompt Injection"),
    FrameworkEntry("LLM02:2025", "Sensitive Information Disclosure"),
    FrameworkEntry("LLM03:2025", "Supply Chain"),
    FrameworkEntry("LLM04:2025", "Data and Model Poisoning"),
    FrameworkEntry("LLM05:2025", "Improper Output Handling"),
    FrameworkEntry("LLM06:2025", "Excessive Agency"),
    FrameworkEntry("LLM07:2025", "System Prompt Leakage"),
    FrameworkEntry("LLM08:2025", "Vector and Embedding Weaknesses"),
    FrameworkEntry("LLM09:2025", "Misinformation"),
    FrameworkEntry("LLM10:2025", "Unbounded Consumption"),
)
AGENTIC_THREATS: tuple[FrameworkEntry, ...] = (
    FrameworkEntry("AGENTIC-T1",  "Memory Poisoning"),
    FrameworkEntry("AGENTIC-T2",  "Tool Misuse"),
    FrameworkEntry("AGENTIC-T3",  "Privilege Compromise"),
    FrameworkEntry("AGENTIC-T4",  "Resource Overload"),
    FrameworkEntry("AGENTIC-T5",  "Cascading Hallucination Attacks"),
    FrameworkEntry("AGENTIC-T6",  "Intent Breaking & Goal Manipulation"),
    FrameworkEntry("AGENTIC-T7",  "Misaligned & Deceptive Behaviors"),
    FrameworkEntry("AGENTIC-T8",  "Repudiation & Untraceability"),
    FrameworkEntry("AGENTIC-T9",  "Identity Spoofing & Impersonation"),
    FrameworkEntry("AGENTIC-T10", "Overwhelming Human in the Loop"),
    FrameworkEntry("AGENTIC-T11", "Unexpected RCE and Code Attacks"),
    FrameworkEntry("AGENTIC-T12", "Agent Communication Poisoning"),
    FrameworkEntry("AGENTIC-T13", "Rogue Agents in Multi-Agent Systems"),
    FrameworkEntry("AGENTIC-T14", "Human Attacks on Multi-Agent Systems"),
    FrameworkEntry("AGENTIC-T15", "Human Manipulation"),
    FrameworkEntry("AGENTIC-T16", "Insecure Inter-Agent Protocol Abuse"),
    FrameworkEntry("AGENTIC-T17", "Supply Chain Compromise"),
)
MCP_THREATS: tuple[FrameworkEntry, ...] = (
    FrameworkEntry("MCP1",  "Tool Description Injection"),
    FrameworkEntry("MCP2",  "Tool Result Injection"),
    FrameworkEntry("MCP3",  "Cross-Server Confused Deputy"),
    FrameworkEntry("MCP4",  "Resource URI Smuggling"),
    FrameworkEntry("MCP5",  "Prompt Template Injection"),
    FrameworkEntry("MCP6",  "Shadow Tool / Capability Drift"),
    FrameworkEntry("MCP7",  "Sampling Abuse"),
    FrameworkEntry("MCP8",  "Consent Bypass"),
    FrameworkEntry("MCP9",  "Server Supply Chain"),
    FrameworkEntry("MCP10", "Tool-Argument Exfiltration"),
)


@dataclass(frozen=True)
class OwaspCoverageRow:
    id: str
    title: str
    total: int = 0
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    errored: int = 0


@dataclass
class OwaspCoverageMatrix:
    rows: dict[str, OwaspCoverageRow] = field(default_factory=dict)

    def row(self, ref_id: str) -> OwaspCoverageRow:
        return self.rows[ref_id]

    def llm_rows(self) -> list[OwaspCoverageRow]:
        return [self.rows[entry.id] for entry in LLM_TOP10_2025]

    def agentic_rows(self) -> list[OwaspCoverageRow]:
        return [self.rows[entry.id] for entry in AGENTIC_THREATS]

    def mcp_rows(self) -> list[OwaspCoverageRow]:
        return [self.rows[entry.id] for entry in MCP_THREATS]


def build_coverage_matrix(
    cases: list[TestCase],
    results: list[TestResult],
) -> OwaspCoverageMatrix:
    by_id = {r.test_id: r for r in results}

    counters: dict[str, dict[str, int]] = defaultdict(
        lambda: {"total": 0, "passed": 0, "failed": 0, "skipped": 0, "errored": 0},
    )
    for case in cases:
        result = by_id.get(case.id)
        for ref in case.owasp_refs:
            counter = counters[ref]
            counter["total"] += 1
            if result is None:
                continue
            if result.status == "passed":
                counter["passed"] += 1
            elif result.status == "failed":
                counter["failed"] += 1
            elif result.status == "skipped":
                counter["skipped"] += 1
            elif result.status == "error":
                counter["errored"] += 1

    matrix = OwaspCoverageMatrix()
    for entry in (*LLM_TOP10_2025, *AGENTIC_THREATS, *MCP_THREATS):
        c = counters.get(entry.id, {"total": 0, "passed": 0, "failed": 0,
                                     "skipped": 0, "errored": 0})
        matrix.rows[entry.id] = OwaspCoverageRow(
            id=entry.id, title=entry.title, total=c["total"],
            passed=c["passed"], failed=c["failed"],
            skipped=c["skipped"], errored=c["errored"],
        )
    return matrix
