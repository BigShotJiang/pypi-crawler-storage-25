"""Cross-target summary renderer for `agentsec multi-evaluate`."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agentsec.scoring import EvaluationScore


@dataclass
class TargetResult:
    name: str
    output_dir: Path
    score: EvaluationScore | None
    error: str | None
    elapsed_seconds: float

    def __post_init__(self) -> None:
        if self.error is None and self.score is None:
            raise ValueError(
                f"TargetResult '{self.name}': error and score cannot both be None"
            )


def render_multi_summary(
    results: list[TargetResult],
    generated_at: str = "",
) -> str:
    if not generated_at:
        generated_at = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    total = len(results)
    success_count = sum(1 for r in results if r.error is None)
    error_count = total - success_count

    lines: list[str] = [
        "# 多目标评估汇总",
        "",
        f"生成时间：{generated_at}  ",
        f"目标数：{total}（成功 {success_count}，错误 {error_count}）",
        "",
        "## 评分一览",
        "",
        "| 目标 | 等级 | 综合得分 | 远程 | 服务器 | 严重 | 高 | 耗时 |",
        "|------|------|----------|------|--------|------|----|------|",
    ]

    for r in results:
        if r.error is not None:
            lines.append(
                f"| {r.name} | ERROR | — | — | — "
                f"| — | — | {_fmt_elapsed(r.elapsed_seconds)} |"
            )
        else:
            # Invariant: TargetResult.__post_init__ rejects (error=None, score=None).
            assert r.score is not None  # noqa: S101
            s = r.score
            grade = "LOW_COV" if s.grade == "INSUFFICIENT_COVERAGE" else s.grade
            combined = f"{s.combined.score:.1f}" if s.combined.score is not None else "—"
            remote = f"{s.remote_score:.1f}" if s.remote_score is not None else "—"
            server = str(s.server_score) if s.server_score is not None else "—"
            critical = sum(1 for f in s.deduped_findings if f.severity == "critical")
            high = sum(1 for f in s.deduped_findings if f.severity == "high")
            lines.append(
                f"| {r.name} | {grade} | {combined} | {remote} | {server} "
                f"| {critical} | {high} | {_fmt_elapsed(r.elapsed_seconds)} |"
            )

    success_results = [r for r in results if r.error is None]
    if success_results:
        lines += ["", "## 详细报告", ""]
        for r in success_results:
            lines.append(f"- [{r.name}]({r.name}/combined-report.md)")

    error_results = [r for r in results if r.error is not None]
    if error_results:
        lines += ["", "## 错误", ""]
        for r in error_results:
            lines += [f"### {r.name}", "", r.error, ""]

    return "\n".join(lines) + "\n"


def _fmt_elapsed(seconds: float) -> str:
    m = int(seconds) // 60
    s = int(seconds) % 60
    return f"{m}m{s:02d}s"
