"""JSON / YAML report writers (spec §9.3).

These are the only two non-Markdown artifacts the `agentsec evaluate` command
emits. They are split off from `markdown.py` so a future "machine-only"
output mode can disable Markdown rendering and keep just these.

Findings are assumed already redacted (see Stage D `Check.make_finding` and
Stage E `Redactor` flow) — this module does NOT redact again. A double-pass
would mask the redactor's idempotency bug if one ever existed.
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..audit.findings import Finding


def write_findings_json(findings: list[Finding], path: Path) -> None:
    """Pretty-printed, sorted-keys JSON dump. Sorted keys give CI-friendly
    diffs across runs and let consumers rely on stable structural ordering.

    `Finding.fingerprint` is a `@computed_field`, so `model_dump(mode="json")`
    includes it (the "schema stability" assertion in tests checks this).
    """
    payload = [f.model_dump(mode="json") for f in findings]
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def write_threat_intel_snapshot(
    referenced_refs: set[str], threat_intel_path: Path, out_path: Path,
) -> None:
    """Project the `threat_intel.yaml` rows whose `id` was referenced this
    run. Unknown refs are silently dropped (a finding can outlive a TI row's
    removal — the operator still sees the dangling id in the finding itself
    and in `audit-log.jsonl`).
    """
    raw = yaml.safe_load(threat_intel_path.read_text(encoding="utf-8")) or []
    if not isinstance(raw, list):
        raise ValueError(
            f"{threat_intel_path}: top-level must be a list of TI rows, "
            f"got {type(raw).__name__}"
        )
    snapshot = [row for row in raw if isinstance(row, dict) and row.get("id") in referenced_refs]
    out_path.write_text(
        yaml.safe_dump(snapshot, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
