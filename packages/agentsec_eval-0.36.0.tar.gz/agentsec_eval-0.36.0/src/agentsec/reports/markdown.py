"""Markdown report renderers (spec §9.3).

Three renderers, all read-only (no I/O):

  - render_remote_report — adds a "Score" section driven by `EvaluationScore`.
  - render_server_audit_report — lifts the inline string-builder out of
    `cli.py:server_audit` so it can be unit-tested.
  - render_combined_report — top-level grade + links into the two halves.

`<!-- meta:... -->` HTML comments give downstream consumers (the eventual
web viewer, CI metric scrapers) stable selectors that survive copy edits.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from dataclasses import replace as _dc_replace
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from ..tests.models import Severity, TestResult
from .attack_paths import derive_attack_paths
from .owasp_coverage import (
    OwaspCoverageMatrix,
    OwaspCoverageRow,
    build_coverage_matrix,
)

if TYPE_CHECKING:
    from ..audit.findings import Finding
    from ..audit.server_audit import ServerAuditReport
    from ..scoring import EvaluationScore
    from ..tests.models import TestCase


@dataclass(frozen=True)
class TargetDescriptor:
    """Display-side metadata about the audit target. All fields optional —
    callers that pass `TargetDescriptor()` (or omit the parameter entirely)
    fall back to the v1 minimal overview."""

    host: str | None = None
    user: str | None = None
    key_path: str | None = None
    auth_file: str | None = None
    openclaw_bin: str | None = None
    openclaw_version: str | None = None
    checks_run: tuple[str, ...] = field(default_factory=tuple)
    evaluator_label: str = "评估方（本机）"


_SEVERITY_ORDER = [Severity.critical, Severity.high, Severity.medium, Severity.low, Severity.info]
_EMOJI = {
    Severity.critical: "C", Severity.high: "H", Severity.medium: "M",
    Severity.low: "L", Severity.info: "I",
}


def _fmt_score(value: float | int | None) -> str:
    """Render a score / coverage float without long-tail noise (33.333…)."""
    if value is None:
        return "N/A"
    if isinstance(value, int):
        return str(value)
    return f"{value:.1f}"


def _response_excerpt(r: TestResult) -> str:
    if not r.observations:
        return ""
    first = r.observations[0]
    resp = first.get("response", {}) if isinstance(first, dict) else {}
    text = resp.get("content", "") if isinstance(resp, dict) else ""
    return text[:300] + ("…" if len(text) > 300 else "")


def _verdict_reasoning(r: TestResult) -> str:
    if not r.verdict:
        return ""
    return str(r.verdict.get("reasoning", ""))


def _mcp_score_section(mcp_score) -> list[str]:
    """Render §MCP real-protocol score section (Phase 7c.6)."""
    from ..mcp_harness.scoring import McpScore  # local import to avoid cycle

    assert isinstance(mcp_score, McpScore)  # noqa: S101 — defensive type guard
    lines = [
        "## MCP real-protocol",
        "",
    ]
    if mcp_score.score is None:
        lines.append(f"- 状态：{mcp_score.note or '未运行'}")
        return lines
    lines += [
        f"- 总通过率：{mcp_score.score:.1f} / 100",
        "",
        "### 各类覆盖",
        "",
        "| OWASP ref | Passed / Total | Pass rate |",
        "|---|---|---|",
    ]
    for c in mcp_score.categories:
        lines.append(
            f"| {c.owasp_ref} | {c.passed} / {c.total} | "
            f"{c.pass_rate:.0%} |"
        )
    return lines


def _score_block(score: EvaluationScore) -> list[str]:
    lines = [
        "## 评分",
        "",
        f"<!-- meta:remote_score value:{score.remote_score} -->",
        f"<!-- meta:server_score value:{score.server_score} -->",
        f"<!-- meta:combined_score value:{score.combined.score} -->",
        f"<!-- meta:weight_remote_used value:{score.combined.weight_remote_used} -->",
        f"<!-- meta:weight_server_used value:{score.combined.weight_server_used} -->",
        f"<!-- meta:weight_mcp_used value:{score.combined.weight_mcp_used} -->",
        f"<!-- meta:grade value:{score.grade} -->",
        "",
        f"- 远程套件得分：{_fmt_score(score.remote_score)}",
        f"- 服务器审计得分：{_fmt_score(score.server_score)}",
        f"- MCP 实测得分：{_fmt_score(score.mcp.score) if score.mcp else 'N/A'}",
        f"- 综合得分：{_fmt_score(score.combined.score)}",
        f"- 等级：{score.grade}",
    ]
    if score.combined.note:
        lines.append(f"- 备注：{score.combined.note}")
    if score.low_coverage:
        lines += [
            "",
            "**LOW_COVERAGE**：verdict_coverage<0.7 或 error_rate>0.1"
            " —— 等级被降为 INSUFFICIENT_COVERAGE。",
        ]
    cov = score.coverage
    exec_pct = f"{cov.execution_coverage:.2%}"
    verdict_pct = f"{cov.verdict_coverage:.2%}"
    error_suffix = (
        f"（error_rate={cov.error_rate:.2%}）"
        if cov.error_rate is not None
        else "（error_rate=N/A）"
    )
    lines += [
        "",
        "### 覆盖率",
        "",
        f"- 计划测试数：{cov.planned}",
        f"- 已执行：{cov.executed}（execution_coverage={exec_pct}）",
        f"- 已评分：{cov.scored}（verdict_coverage={verdict_pct}）",
        f"- 错误数：{cov.error}{error_suffix}",
    ]
    if score.category_scores:
        lines += [
            "",
            "### 分类得分",
            "",
            "| 类别 | 通过 | 失败 | 最差严重度 | 权重因子 | 得分 |",
            "|------|------|------|------------|----------|------|",
        ]
        for c in score.category_scores:
            score_cell = f"{c.score:.1f}" if c.score is not None else "N/A"
            worst = c.worst_failed_severity or "—"
            lines.append(
                f"| {c.category} | {c.passed} | {c.failed} | {worst} | "
                f"{c.severity_weight_factor:.2f} | {score_cell} |"
            )
    return lines


def _render_owasp_coverage_section(matrix: OwaspCoverageMatrix) -> list[str]:
    """Render the OWASP framework coverage section.

    Two sub-tables: LLM Top 10 (2025) and Agentic Threats (v1.1). Each row
    surfaces total / passed / failed / skipped / errored. Rows with total=0
    are kept (the gap is the headline)."""

    def _table(title: str, rows: list[OwaspCoverageRow]) -> list[str]:
        out = [
            f"### {title}",
            "",
            "| ID | Title | 总数 | 通过 | 失败 | 跳过 | 错误 |",
            "|----|-------|------|------|------|------|------|",
        ]
        for r in rows:
            out.append(
                f"| {r.id} | {r.title} | {r.total} | {r.passed} | "
                f"{r.failed} | {r.skipped} | {r.errored} |"
            )
        out.append("")
        return out

    md: list[str] = ["## OWASP 框架覆盖", ""]
    md += _table("OWASP Top 10 for LLM Applications (2025)", matrix.llm_rows())
    md += _table("OWASP Agentic AI Threats (v1.1)", matrix.agentic_rows())
    md += _table(
        "OWASP MCP Top 10 (AgentSec curated v1)", matrix.mcp_rows(),
    )
    return md


def render_remote_report(
    agent_name: str,
    results: list[TestResult],
    score: EvaluationScore,
    *,
    cases: list[TestCase] | None = None,
) -> str:
    total = len(results)
    by_status = {s: [r for r in results if r.status == s]
                 for s in ("passed", "failed", "skipped", "error", "not_applicable")}
    counts = {k: len(v) for k, v in by_status.items()}

    lines: list[str] = [
        f"# 安全评估报告 —— {agent_name}",
        f"**生成时间**：{datetime.now(UTC).strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**测试总数**：{total}  |  通过：{counts['passed']}  |  失败：{counts['failed']}"
        f"  |  跳过：{counts['skipped']}  |  错误：{counts['error']}"
        f"  |  不适用：{counts['not_applicable']}",
        "",
        "## 按严重度汇总",
        "",
        "| 严重度 | 总数 | 失败 | 错误 |",
        "|--------|------|------|------|",
    ]

    for sev in _SEVERITY_ORDER:
        sev_results = [r for r in results if r.severity == sev]
        if not sev_results:
            continue
        sev_failed = sum(1 for r in sev_results if r.status == "failed")
        sev_errors = sum(1 for r in sev_results if r.status == "error")
        lines.append(
            f"| {_EMOJI[sev]} {sev.value} | {len(sev_results)} | "
            f"{sev_failed} | {sev_errors} |"
        )

    lines += [""] + _score_block(score)

    if cases:
        matrix = build_coverage_matrix(cases, results)
        lines += [""] + _render_owasp_coverage_section(matrix)

    lines += ["", "## 失败的测试", ""]
    failed_results = by_status["failed"]
    if not failed_results:
        lines.append("_无失败。_")
    else:
        for r in sorted(failed_results, key=lambda r: _SEVERITY_ORDER.index(r.severity)):
            lines += [
                f"### [{r.severity.value.upper()}] {r.test_id}",
                f"**类别**：{r.category}  ",
                f"**Agent 响应**：{_response_excerpt(r)}  ",
                f"**评判推理**：{_verdict_reasoning(r)}",
                "",
            ]

    lines += ["", "## 错误", ""]
    err_results = by_status["error"]
    if not err_results:
        lines.append("_无错误。_")
    else:
        for r in err_results:
            lines += [
                f"### [{r.severity.value.upper()}] {r.test_id}",
                f"**类别**：{r.category}  ",
                f"**错误**：{r.error}",
                "",
            ]

    return "\n".join(lines) + "\n"


_SERVER_SEVERITY_ORDER: tuple[str, ...] = ("critical", "high", "medium", "low", "info")
_SERVER_SEVERITY_LABEL: dict[str, str] = {
    "critical": "🔴 严重",
    "high": "🟠 高",
    "medium": "🟡 中",
    "low": "🔵 低",
    "info": "⚪ 信息",
}
_SERVER_SEVERITY_DOT: dict[str, str] = {
    "critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵", "info": "⚪",
}
_HIGH_PRIORITY_TOP_N = 10

# Evidence keys promoted to the finding header (KEV / CVSS / link / confidence)
# so they don't render twice — once in the badge line, once in the evidence
# bullet list.
_REDUNDANT_EVIDENCE_KEYS = frozenset({
    "cve_db_url", "cve_db_confidence", "kev", "cvss",
})

_NVD_TAIL_PATTERN = re.compile(r"\s*\(seeded from NVD[^)]*\)\s*$")
# Matches version_patch finding titles of the form
# "TI-OPENCLAW-CVE-2026-22172：当前版本 X 受影响" so we can rebuild a
# more natural Chinese title at render time without changing the
# underlying Finding (the raw title participates in the fingerprint).
_TI_TITLE_PATTERN = re.compile(r"^TI-OPENCLAW-(CVE-\d{4}-\d+)：")
_CVE_PATTERN = re.compile(r"(CVE-\d{4}-\d+)")


def _filter_evidence(evidence: dict) -> dict:
    """Strip evidence keys already shown in the finding header."""
    return {k: v for k, v in evidence.items() if k not in _REDUNDANT_EVIDENCE_KEYS}


def _format_evidence_lines(evidence: dict) -> list[str]:
    """Render an evidence dict as a Markdown bullet list, preserving order
    and skipping empty / None values for readability. Long string values
    truncate to 300 chars + ellipsis so a stray multi-KB blob does not
    explode the report."""
    out: list[str] = []
    for key, value in evidence.items():
        if value is None or value == "" or value == [] or value == {}:
            continue
        if isinstance(value, str) and len(value) > 300:
            value = value[:300] + "…"
        elif isinstance(value, (list, tuple)):
            value = ", ".join(str(v) for v in value) if value else "—"
        elif isinstance(value, dict):
            value = "、".join(f"{k}={v}" for k, v in value.items())
        out.append(f"  - `{key}`：{value}")
    return out


def _extract_cve_id(finding) -> str | None:
    """Return the CVE id surfaced by a finding, looking first at the structured
    threat_refs list and then falling back to a regex over the title."""
    for ref in finding.threat_refs:
        m = _CVE_PATTERN.search(ref)
        if m:
            return m.group(1)
    m = _CVE_PATTERN.search(finding.title)
    return m.group(1) if m else None


def _localize_finding_title(finding) -> str:
    """Rewrite version_patch titles into plain Chinese while preserving
    fingerprint stability (the rewrite is render-only)."""
    if finding.check != "version_patch":
        return finding.title
    m = _TI_TITLE_PATTERN.match(finding.title)
    if not m:
        return finding.title
    cve_id = m.group(1)
    fixed = finding.evidence.get("fixed_in")
    affected = finding.evidence.get("affected_versions")
    affected_str = (
        ", ".join(str(a) for a in affected)
        if isinstance(affected, list) and affected
        else None
    )
    parts: list[str] = []
    if affected_str:
        parts.append(f"受影响 {affected_str}")
    if fixed:
        parts.append(f"已修复 {fixed}")
    suffix = f"（{'，'.join(parts)}）" if parts else ""
    return f"[{cve_id}] OpenClaw 版本受影响{suffix}"


def _format_badges(finding) -> str:
    """One-line badge list (CVSS / KEV / NVD confidence) — empty string when none apply."""
    parts: list[str] = []
    cvss = finding.evidence.get("cvss")
    if isinstance(cvss, (int, float)):
        parts.append(f"**CVSS {float(cvss):.1f}**")
    if finding.evidence.get("kev") is True:
        parts.append("**🚨 CISA KEV**")
    conf = finding.evidence.get("cve_db_confidence")
    if isinstance(conf, str):
        parts.append(f"NVD 置信度 `{conf}`")
    return " · ".join(parts)


def _format_description_lines(finding) -> list[str]:
    """Render the description, wrapping NVD-seeded English paragraphs in a
    blockquote with explicit attribution so the reader knows the prose is
    upstream NVD copy, not project-authored."""
    if not finding.description:
        return []
    desc = finding.description
    if _NVD_TAIL_PATTERN.search(desc):
        cleaned = _NVD_TAIL_PATTERN.sub("", desc).rstrip()
        quoted = "\n> ".join(cleaned.splitlines())
        return [
            "",
            "**描述**（来源：NVD seed，未经本地翻译）：",
            "",
            f"> {quoted}",
        ]
    return ["", f"**描述**：{desc}"]


def _render_finding_block(idx: str, finding) -> list[str]:
    """Render a single finding under section heading `idx` (e.g. "3.1.1")."""
    threat = "、".join(finding.threat_refs) if finding.threat_refs else "—"
    title = _localize_finding_title(finding)
    cve_url = finding.evidence.get("cve_db_url")
    title_link = f" [↗]({cve_url})" if isinstance(cve_url, str) and cve_url else ""
    out: list[str] = [
        f"#### {idx} [{finding.severity.upper()}] {title}{title_link}",
        "",
    ]
    badges = _format_badges(finding)
    if badges:
        out += [badges, ""]
    out += [
        f"- **检查项**：`{finding.check}`",
        f"- **威胁引用**：{threat}",
        f"- **指纹**：`{finding.fingerprint[:16]}`",
    ]
    out.extend(_format_description_lines(finding))
    if finding.evidence:
        ev_lines = _format_evidence_lines(_filter_evidence(finding.evidence))
        if ev_lines:
            out += ["", "**证据**：", *ev_lines]
    if finding.remediation:
        out += ["", f"**修复建议**：{finding.remediation}"]
    out += ["", "---", ""]
    return out


def _render_target_overview_table(
    descriptor: TargetDescriptor,
    profile_name: str,
    remote_home: str,
    timestamp: str,
    server_score: int | None,
    total_findings: int,
    low_assurance: bool,
) -> list[str]:
    """§1.1 概览表 —— descriptor 为空时仍输出最小表。

    Always emits profile / remote_home / score / total / timestamp;
    descriptor-driven rows (host / user / key path / OpenClaw version /
    auth file) only render when the matching field is populated.
    """
    rows: list[str] = []

    def _row(label: str, value: str | None) -> None:
        if value is None or value == "":
            return
        rows.append(f"| {label} | {value} |")

    _row("目标主机", f"`{descriptor.host}`" if descriptor.host else None)
    _row("SSH 登录用户", f"`{descriptor.user}`" if descriptor.user else None)
    _row("SSH 私钥路径", f"`{descriptor.key_path}`" if descriptor.key_path else None)
    _row("平台 profile", f"`{profile_name}`")
    _row("远端 $HOME", f"`{remote_home}`")
    _row(
        "OpenClaw 版本",
        f"`{descriptor.openclaw_version}`" if descriptor.openclaw_version else None,
    )
    _row(
        "OpenClaw 安装路径",
        f"`{descriptor.openclaw_bin}`" if descriptor.openclaw_bin else None,
    )
    _row(
        "AUTHORIZATION 文件",
        f"`{descriptor.auth_file}`" if descriptor.auth_file else None,
    )
    _row("信任级别", "**LOW_ASSURANCE**" if low_assurance else "标准（HMAC + 身份断言）")
    if server_score is not None:
        _row("服务器审计得分", f"**{server_score}** / 100")
    _row("Finding 总数", f"**{total_findings}**")
    _row("报告生成时间", timestamp)

    out = [
        "### 1.1 审计目标",
        "",
        "| 字段 | 值 |",
        "|------|------|",
        *rows,
        "",
    ]
    return out


def _render_audit_method_block(descriptor: TargetDescriptor) -> list[str]:
    """§1.2 审计方法 —— TargetDescriptor 至少有 checks_run 时渲染。"""
    if not descriptor.checks_run:
        return []
    checks_inline = "、".join(f"`{c}`" for c in descriptor.checks_run)
    return [
        "### 1.2 审计方法",
        "",
        "- **远程通道**：通过 SSH 仅以白名单 argv 调用只读命令；"
        "每条 argv 必须通过 `CommandPolicy.validate(argv)` —— "
        "`ssh_policy.yaml` 列举每个 check 允许的命令模板，"
        "参数与路径由 `PathMatcher` 校验",
        "- **审计日志**：每条调用的 SHA-256 + 拒绝原因写入 "
        "`audit-log.jsonl`，命令字面值与 argv 中的敏感参数不持久化",
        "- **HMAC 授权**：`AUTHORIZATION.txt` 用 HMAC-SHA256 + "
        "身份断言绑定本次目标主机与输出路径，确保审计执行链可溯源",
        f"- **本次执行 {len(descriptor.checks_run)} 项 check**：{checks_inline}",
        "",
    ]


def _render_topology_diagram(
    descriptor: TargetDescriptor,
    profile_name: str,
    remote_home: str,
) -> list[str]:
    """§1.3 审计逻辑拓扑 mermaid flowchart。

    需要 host + user + key_path 同时具备才有意义，否则跳过 —— 节点
    标签会全是占位符，画出来并不传达任何信息。
    """
    if not (descriptor.host and descriptor.user and descriptor.key_path):
        return []
    target_label = f"目标 {descriptor.host} ({profile_name})"
    oc_node = (
        f'OC["OpenClaw {descriptor.openclaw_version}<br/>'
        f'{descriptor.openclaw_bin or "openclaw (PATH)"}'
        f'"]'
        if descriptor.openclaw_version or descriptor.openclaw_bin
        else 'OC["OpenClaw 实例"]'
    )
    auth_label = (
        f"AUTHORIZATION<br/>{descriptor.auth_file}"
        if descriptor.auth_file
        else "AUTHORIZATION<br/>HMAC + 身份断言"
    )
    return [
        "### 1.3 审计逻辑拓扑",
        "",
        "```mermaid",
        "flowchart LR",
        f'    Op["{descriptor.evaluator_label}"]',
        f'    Op -->|"SSH 仅只读<br/>用户 {descriptor.user}<br/>'
        f'key {descriptor.key_path}"| TargetIngress',
        f'    Op -.->|"{auth_label}"| TargetIngress',
        "",
        f'    subgraph Target["{target_label}"]',
        "        TargetIngress[sshd]",
        f"        {oc_node}",
        f'        Logs["{remote_home}/.openclaw/<br/>journald / /var/log/openclaw/"]',
        "        TargetIngress -.- OC",
        "        OC -.- Logs",
        "    end",
        "",
        '    TargetIngress --> Policy["CommandPolicy<br/>argv 白名单"]',
        f'    Policy --> Checks["{len(descriptor.checks_run) or "N"} 项只读 check"]',
        '    Checks --> Out["findings.json<br/>audit-log.jsonl<br/>server-audit-report.md"]',
        "```",
        "",
    ]


def _render_attack_paths_section(findings: list[Finding]) -> list[str]:
    """§2.2 攻击路径 —— 没触发任何 scenario 时仍打 stub，避免读者怀疑章节被吞掉。"""
    paths = derive_attack_paths(findings)
    out = [
        "### 2.2 攻击路径",
        "",
        "> 以下攻击路径来自当前 finding 集合的启发式推断（基于 check 类型 +"
        "严重度 + KEV 标记的组合规则），需结合实际网络可达性与运维上下文"
        "复核后才能视为可执行的威胁场景。",
        "",
    ]
    if not paths:
        out += [
            "_当前 finding 集合不满足任一内置攻击路径模板的触发条件_"
            "（如缺少暴露端口 + 高严重度 CVE 的组合）。",
            "",
        ]
        return out

    for i, p in enumerate(paths, 1):
        out += [
            f"#### 2.2.{i} {p.title}",
            "",
            f"_（场景 ID：`{p.scenario_id}` · 严重度下限：**{p.severity_floor}**）_",
            "",
            f"**概述**：{p.summary}",
            "",
            "**步骤**：",
            "",
        ]
        for step_idx, step in enumerate(p.steps, 1):
            refs_part = ""
            if step.evidence_refs:
                quoted = "、".join(f"`{r}`" for r in step.evidence_refs)
                refs_part = f"  \n  　脆弱性：{quoted}"
            check_part = (
                f"  \n  　来源 check：`{step.leveraged_check}`"
                if step.leveraged_check else ""
            )
            out.append(f"{step_idx}. {step.description}{refs_part}{check_part}")
        out.append("")
    return out


_SEVERITY_PIE_PALETTE: tuple[tuple[str, str], ...] = (
    ("critical", "#dc2626"),  # red-600
    ("high",     "#ea580c"),  # orange-600
    ("medium",   "#eab308"),  # yellow-500
    ("low",      "#3b82f6"),  # blue-500
    ("info",     "#9ca3af"),  # gray-400 — visible on light + dark bg
)
_SEVERITY_PIE_LEGEND_LABEL: dict[str, str] = {
    "critical": "严重", "high": "高", "medium": "中", "low": "低", "info": "信息",
}


def _render_severity_pie(counts: dict[str, int]) -> list[str]:
    """Inline SVG pie of finding severity distribution.

    Each slice's `fill` is the severity colour directly (red / orange / yellow
    / blue / gray) — no mermaid theme indirection that some renderers
    (older mermaid, custom viewers) silently drop. Slices are emitted in
    source order critical → high → medium → low → info, traversed clockwise
    from the 12 o'clock position; the SVG sweep flag is `1` so y-flipped
    SVG coordinates render that ordering as a visually-clockwise sweep.

    Layout: 540 × 320 — pie on the left (cx=160, r=130), legend column on
    the right (x=340 onward). The legend is part of the same SVG so every
    slice — including ones too small to fit an in-pie label — has a visible
    "色块 + 名称 · N (X%)" entry. Slices ≥ 10 % additionally get an N (X%)
    label centred on the slice for visual emphasis.

    Returns `[]` when there are zero findings.
    """
    total = sum(counts.values())
    if total == 0:
        return []

    slices = [
        (sev, color, counts[sev])
        for sev, color in _SEVERITY_PIE_PALETTE
        if counts.get(sev, 0) > 0
    ]

    width, height = 540, 320
    cx, cy, r = 160, 160, 130
    legend_x = 340
    entry_h = 30
    legend_total_h = len(slices) * entry_h
    legend_top = (height - legend_total_h) // 2

    out: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'viewBox="0 0 {width} {height}" width="{width}" height="{height}" '
        'role="img" aria-label="严重度分布饼图">',
        "  <title>严重度分布</title>",
    ]

    # ----- pie -----
    if len(slices) == 1:
        sev, color, n = slices[0]
        out.append(
            f'  <circle cx="{cx}" cy="{cy}" r="{r}" fill="{color}" '
            'stroke="white" stroke-width="2"/>'
        )
        out.append(
            f'  <text x="{cx}" y="{cy}" text-anchor="middle" '
            f'dominant-baseline="central" fill="white" font-size="22" '
            f'font-weight="bold">{n} (100%)</text>'
        )
    else:
        cumulative = 0
        for _sev, color, n in slices:
            t1 = cumulative / total
            t2 = (cumulative + n) / total
            cumulative += n
            x1 = cx + r * math.sin(2 * math.pi * t1)
            y1 = cy - r * math.cos(2 * math.pi * t1)
            x2 = cx + r * math.sin(2 * math.pi * t2)
            y2 = cy - r * math.cos(2 * math.pi * t2)
            large_arc = 1 if (t2 - t1) > 0.5 else 0
            out.append(
                f'  <path d="M{cx},{cy} L{x1:.2f},{y1:.2f} '
                f'A{r},{r} 0 {large_arc},1 {x2:.2f},{y2:.2f} Z" '
                f'fill="{color}" stroke="white" stroke-width="2"/>'
            )
            pct = n * 100.0 / total
            if pct >= 10:
                mid = (t1 + t2) / 2
                lx = cx + (r * 0.62) * math.sin(2 * math.pi * mid)
                ly = cy - (r * 0.62) * math.cos(2 * math.pi * mid)
                out.append(
                    f'  <text x="{lx:.2f}" y="{ly:.2f}" text-anchor="middle" '
                    f'dominant-baseline="central" fill="white" font-size="16" '
                    f'font-weight="bold">{n} ({pct:.0f}%)</text>'
                )

    # ----- legend (every slice, including <10%) -----
    for i, (sev, color, n) in enumerate(slices):
        pct = n * 100.0 / total
        row_y = legend_top + i * entry_h
        # `currentColor` lets the legend text inherit the markdown viewer's
        # foreground colour, so the entries stay readable on both light and
        # dark backgrounds.
        out.append(
            f'  <rect x="{legend_x}" y="{row_y}" width="20" height="20" '
            f'fill="{color}" stroke="white" stroke-width="1"/>'
        )
        out.append(
            f'  <text x="{legend_x + 30}" y="{row_y + 10}" '
            f'fill="currentColor" font-size="15" dominant-baseline="central">'
            f'{_SEVERITY_PIE_LEGEND_LABEL[sev]} · {n} ({pct:.1f}%)</text>'
        )

    out.append("</svg>")
    return out


def _render_check_distribution(findings: list) -> list[str]:
    """Per-check finding totals broken down by severity. Skipped when only one
    check produced findings (table would be a single row)."""
    by_check: dict[str, dict[str, int]] = {}
    for f in findings:
        bucket = by_check.setdefault(f.check, {s: 0 for s in _SERVER_SEVERITY_ORDER})
        bucket[f.severity] += 1
    if len(by_check) <= 1:
        return []
    rows = sorted(
        by_check.items(),
        key=lambda kv: sum(kv[1].values()),
        reverse=True,
    )
    out = [
        "### 2.4 Check 维度分布",
        "",
        "| Check | 总数 | 🔴 | 🟠 | 🟡 | 🔵 | ⚪ |",
        "|-------|------|----|----|----|----|----|",
    ]
    for check, sev_map in rows:
        total = sum(sev_map.values())
        cells = " | ".join(
            str(sev_map[s]) if sev_map[s] else "—" for s in _SERVER_SEVERITY_ORDER
        )
        out.append(f"| `{check}` | {total} | {cells} |")
    out.append("")
    return out


def _render_priority_list(findings: list) -> list[str]:
    """Replace the v1 fixed-5 list with: all critical + top-N high + counts.

    Critical is fully enumerated because every critical is meant to be fixed;
    high gets a top-N excerpt with a tail count so the reader knows the rest
    live in §3.
    """
    by_sev: dict[str, list] = {s: [] for s in _SERVER_SEVERITY_ORDER}
    for f in findings:
        by_sev[f.severity].append(f)
    critical = by_sev["critical"]
    high = by_sev["high"]
    medium = by_sev["medium"]
    out: list[str] = ["### 2.3 最高优先级修复", ""]
    if critical:
        out += [f"**严重（critical） —— 全部 {len(critical)} 条：**", ""]
        for i, f in enumerate(critical, 1):
            out.append(
                f"{i}. **[CRITICAL]** `{f.check}` — {_localize_finding_title(f)}"
            )
        out.append("")
    if high:
        shown = high[:_HIGH_PRIORITY_TOP_N]
        label = (
            f"**高（high） —— 全部 {len(high)} 条："
            if len(high) <= _HIGH_PRIORITY_TOP_N
            else f"**高（high） —— top {len(shown)} / {len(high)}："
        )
        out += [label + "**", ""]
        for i, f in enumerate(shown, 1):
            out.append(
                f"{i}. **[HIGH]** `{f.check}` — {_localize_finding_title(f)}"
            )
        if len(high) > _HIGH_PRIORITY_TOP_N:
            out.append("")
            out.append(f"… 还有 {len(high) - _HIGH_PRIORITY_TOP_N} 条 high 详见 §3。")
        out.append("")
    if medium:
        out += [f"**中（medium）**：{len(medium)} 条详见 §3。", ""]
    if not (critical or high or medium):
        out += ["_无严重 / 高 / 中级 finding。_", ""]
    return out


def _render_version_patch_overview(findings: list) -> list[str]:
    """Aggregate version_patch findings into one overview table + a collapsed
    detail block. Ten plus per-CVE 10-line cards become one compact table."""
    if not findings:
        return []
    sev_idx = {s: i for i, s in enumerate(_SERVER_SEVERITY_ORDER)}
    findings = sorted(findings, key=lambda f: (sev_idx[f.severity], f.title))
    running = next(
        (f.evidence.get("running_version") for f in findings
         if f.evidence.get("running_version")),
        None,
    )
    out = [
        f"### 3.0 version_patch — CVE 总览（{len(findings)} 条）",
        "",
    ]
    if running:
        out += [f"> 当前运行版本：`{running}`", ""]
    out += [
        "| 严重度 | CVE | 受影响 | 修复版本 | KEV / CVSS | 链接 |",
        "|--------|-----|--------|----------|------------|------|",
    ]
    for f in findings:
        cve_id = _extract_cve_id(f) or "—"
        affected = f.evidence.get("affected_versions") or []
        affected_str = (
            ", ".join(str(a) for a in affected)
            if isinstance(affected, list) and affected
            else "—"
        )
        fixed = f.evidence.get("fixed_in") or "—"
        kc_parts: list[str] = []
        cvss = f.evidence.get("cvss")
        if isinstance(cvss, (int, float)):
            kc_parts.append(f"CVSS {float(cvss):.1f}")
        if f.evidence.get("kev") is True:
            kc_parts.append("🚨 KEV")
        kc_str = " · ".join(kc_parts) if kc_parts else "—"
        url = f.evidence.get("cve_db_url")
        link = f"[↗]({url})" if isinstance(url, str) and url else "—"
        out.append(
            f"| {_SERVER_SEVERITY_DOT[f.severity]} {f.severity} | `{cve_id}` | "
            f"{affected_str} | {fixed} | {kc_str} | {link} |"
        )
    out += [
        "",
        "<details>",
        f"<summary>展开 {len(findings)} 个 CVE 详细描述（NVD 原文 + 证据）</summary>",
        "",
    ]
    for i, f in enumerate(findings, 1):
        out += _render_finding_block(f"3.0.{i}", f)
    out += ["</details>", ""]
    return out


def render_server_audit_report(
    report: ServerAuditReport,
    *,
    profile_name: str,
    remote_home: str,
    low_assurance: bool,
    server_score: int | None = None,
    target: TargetDescriptor | None = None,
) -> str:
    findings = list(report.findings)
    counts = {sev: sum(1 for f in findings if f.severity == sev)
              for sev in _SERVER_SEVERITY_ORDER}
    total = sum(counts.values())
    timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")

    descriptor = target or TargetDescriptor()
    # Auto-fill openclaw_version from version_patch evidence if the caller
    # didn't supply one — version_patch always emits running_version.
    if not descriptor.openclaw_version:
        running = next(
            (f.evidence.get("running_version") for f in findings
             if f.evidence.get("running_version")),
            None,
        )
        if running:
            descriptor = _dc_replace(descriptor, openclaw_version=running)

    md: list[str] = [
        "# 服务器安全审计报告",
        "",
    ]

    # ---- 目录 ----
    # GitHub anchor algorithm: lowercase, drop dots, replace whitespace runs
    # with a single hyphen. Anchors below pre-compute that mapping so the TOC
    # stays clickable when the report is viewed on github.com / gh pr view.
    md += [
        "## 目录",
        "",
        "1. [报告概览](#1-报告概览)",
        "2. [执行摘要](#2-执行摘要)",
        "3. [详细发现](#3-详细发现)",
        "4. [未执行 / 不适用的检查](#4-未执行--不适用的检查)",
        "5. [错误](#5-错误)",
        "6. [附录 A：机读元数据](#附录-a机读元数据)",
        "",
    ]

    # ---- §1 报告概览 ----
    md += ["## 1. 报告概览", ""]
    md += _render_target_overview_table(
        descriptor=descriptor,
        profile_name=profile_name,
        remote_home=remote_home,
        timestamp=timestamp,
        server_score=server_score,
        total_findings=total,
        low_assurance=low_assurance,
    )
    if low_assurance:
        md += [
            "> ⚠️ **LOW_ASSURANCE**：本次审计 AUTHORIZATION.txt 的 "
            "`signature_mode=none` 或 `identity_assertion` 为空，"
            "信任链强度低于 HMAC + 身份断言双因素的标准模式。",
            "",
        ]
    md += _render_audit_method_block(descriptor)
    md += _render_topology_diagram(descriptor, profile_name, remote_home)

    # ---- §2 执行摘要 ----
    md += [
        "## 2. 执行摘要",
        "",
        "### 2.1 风险态势",
        "",
    ]
    pie = _render_severity_pie(counts)
    if pie:
        md += pie + [""]
    md += [
        "| 严重度 | 数量 |",
        "|--------|------|",
    ]
    for sev in _SERVER_SEVERITY_ORDER:
        md.append(f"| {_SERVER_SEVERITY_LABEL[sev]} | {counts[sev]} |")
    md += [f"| **合计** | **{total}** |", ""]

    md += _render_attack_paths_section(findings)

    if total == 0:
        md += [
            "_本次审计未发现任何 finding。所有已执行 check 均通过。_",
            "",
        ]
    else:
        md += _render_priority_list(findings)
        md += _render_check_distribution(findings)

    # ---- §3 详细发现 ----
    md += ["## 3. 详细发现", ""]
    if total == 0:
        md += ["_无发现，跳过本节。_", ""]
    else:
        version_patch_findings = [f for f in findings if f.check == "version_patch"]
        rest = [f for f in findings if f.check != "version_patch"]
        md += _render_version_patch_overview(version_patch_findings)
        section_idx = 0
        for sev in _SERVER_SEVERITY_ORDER:
            sev_findings = [f for f in rest if f.severity == sev]
            if not sev_findings:
                continue
            section_idx += 1
            md += [
                f"### 3.{section_idx} {_SERVER_SEVERITY_LABEL[sev]}（{sev}）"
                f" —— {len(sev_findings)} 条",
                "",
            ]
            for j, f in enumerate(sev_findings, 1):
                md += _render_finding_block(f"3.{section_idx}.{j}", f)

    # ---- §4 未执行的检查 ----
    skipped = [(cid, s) for cid, s in report.statuses.items() if s.is_skipped]
    not_applicable = [
        (cid, s) for cid, s in report.statuses.items() if s.is_not_applicable
    ]
    md += ["## 4. 未执行 / 不适用的检查", ""]
    if not skipped and not not_applicable:
        md += ["_所有 check 均已执行。_", ""]
    else:
        md += [
            "| 检查项 | 状态 | 原因 |",
            "|--------|------|------|",
        ]
        for cid, s in not_applicable:
            md.append(f"| `{cid}` | not_applicable | {s.not_applicable_reason} |")
        for cid, s in skipped:
            md.append(f"| `{cid}` | skipped | {s.skip_reason} |")
        md.append("")

    # ---- §5 错误 ----
    md += ["## 5. 错误", ""]
    if report.errors:
        md += [
            "| 检查项 | 错误信息 |",
            "|--------|----------|",
        ]
        for cid, err in report.errors.items():
            err_one_line = err.replace("\n", " ").replace("|", "\\|")
            md.append(f"| `{cid}` | {err_one_line} |")
        md.append("")
    else:
        md += ["_本次运行未产生 check 级错误。_", ""]

    # ---- 附录：机读元数据 ----
    md += ["## 附录 A：机读元数据", ""]
    md.append(f"<!-- meta:profile value:{profile_name} -->")
    md.append(f"<!-- meta:remote_home value:{remote_home} -->")
    if server_score is not None:
        md.append(f"<!-- meta:server_score value:{server_score} -->")
    for cid, s in report.statuses.items():
        if s.is_skipped:
            md.append(f"<!-- check:{cid} status:skipped reason:{s.skip_reason} -->")
        elif s.is_not_applicable:
            md.append(
                f"<!-- check:{cid} status:not_applicable "
                f"reason:{s.not_applicable_reason} -->"
            )
    md.append(f"<!-- meta:errors count:{len(report.errors)} -->")
    md.append(f"<!-- meta:findings_total count:{total} -->")
    for sev in _SERVER_SEVERITY_ORDER:
        md.append(f"<!-- meta:findings_{sev} count:{counts[sev]} -->")
    md.append("")

    return "\n".join(md) + "\n"


def render_combined_report(
    agent_name: str,
    score: EvaluationScore,
    *,
    remote_present: bool,
    server_present: bool,
    mcp_present: bool = False,
    cases: list[TestCase] | None = None,
    results: list[TestResult] | None = None,
) -> str:
    lines = [
        f"# 综合评估报告 —— {agent_name}",
        f"**生成时间**：{datetime.now(UTC).strftime('%Y-%m-%d %H:%M UTC')}  ",
        "",
    ]
    lines += _score_block(score)
    lines += ["", "## 关联报告", ""]
    if remote_present:
        lines.append("- [远程套件报告 remote-report.md](./remote-report.md)")
    if server_present:
        lines.append("- [服务器审计报告 server-audit-report.md](./server-audit-report.md)")
    if mcp_present:
        lines.append("- [MCP 真实协议报告 mcp-real-report.md](./mcp-real-report.md)")
        lines.append("- [MCP findings JSON mcp-findings.json](./mcp-findings.json)")
    if cases is not None and results is not None:
        matrix = build_coverage_matrix(cases, results)
        lines += [""] + _render_owasp_coverage_section(matrix)
    if score.mcp is not None:
        lines += [""] + _mcp_score_section(score.mcp)
    return "\n".join(lines) + "\n"
