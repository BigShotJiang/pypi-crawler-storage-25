"""Heuristic attack-path derivation from a server-audit finding set.

Operators reading a 180-finding report want to know "if these were exploited
together, what does the attacker do step-by-step". A full kill-chain inference
from raw findings is out of scope, so this module ships a small set of
hand-crafted scenario templates: each scenario declares the finding shapes it
needs (e.g. "any exposure_scan finding AND any high+ version_patch finding"),
and only fires when the data actually supports it. Each emitted path enumerates
the findings the attacker would chain together so the reader can pivot back
into §3 detail.

The module is intentionally pure: input = list of `Finding` model objects,
output = list of `AttackPath` value objects. The Markdown renderer in
`markdown.py` consumes the result; this module knows nothing about Markdown.
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..audit.findings import Finding


_SEV_RANK: dict[str, int] = {
    "critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0,
}
_CVE_PATTERN = re.compile(r"(CVE-\d{4}-\d+)")


@dataclass(frozen=True)
class AttackPathStep:
    """One stage in an attack chain. `evidence_refs` are short tags
    (CVE id, finding title excerpt) that link the step back to §3."""
    description: str
    evidence_refs: tuple[str, ...] = ()
    leveraged_check: str | None = None


@dataclass(frozen=True)
class AttackPath:
    """A derived attack chain: ordered steps + a one-line summary."""
    title: str
    summary: str
    steps: tuple[AttackPathStep, ...]
    scenario_id: str = ""
    severity_floor: str = "high"  # the worst severity any step depends on


def _extract_cve_id(finding: Finding) -> str | None:
    for ref in finding.threat_refs:
        m = _CVE_PATTERN.search(ref)
        if m:
            return m.group(1)
    m = _CVE_PATTERN.search(finding.title)
    return m.group(1) if m else None


def _evidence_tag(finding: Finding) -> str:
    """Compact reference tag for use in attack-path steps. Prefers the CVE id
    when one is available so multiple version_patch findings show as
    `CVE-2026-22172` instead of the longer raw title."""
    cve = _extract_cve_id(finding)
    if cve:
        return cve
    title = finding.title
    return title if len(title) <= 60 else title[:57] + "…"


def _bucketize(findings: list[Finding]) -> dict[str, list[Finding]]:
    buckets: dict[str, list[Finding]] = defaultdict(list)
    for f in findings:
        buckets[f.check].append(f)
    for chs in buckets.values():
        chs.sort(key=lambda f: -_SEV_RANK[f.severity])
    return buckets


def _at_least(buckets: dict[str, list[Finding]], check: str, severity: str,
              limit: int = 3) -> list[Finding]:
    """Top-N findings for a check at or above the given severity floor."""
    out = [f for f in buckets.get(check, []) if _SEV_RANK[f.severity] >= _SEV_RANK[severity]]
    return out[:limit]


def derive_attack_paths(findings: list[Finding]) -> list[AttackPath]:
    """Inspect findings and return scenario-driven attack paths.

    Order of scenarios in the returned list is roughly worst-first
    (KEV → external-attacker → internal-privesc → cred-persist) so the reader
    sees the most pressing chain at the top.
    """
    if not findings:
        return []
    buckets = _bucketize(findings)
    paths: list[AttackPath] = []

    # Scenario K — CISA KEV exploit available in the wild.
    # KEV findings are objective fact: someone is already exploiting this CVE
    # somewhere, so the chain is "open browser → pull PoC → run".
    kev = [f for f in findings if f.evidence.get("kev") is True]
    if kev:
        kev.sort(key=lambda f: -_SEV_RANK[f.severity])
        kev = kev[:3]
        paths.append(AttackPath(
            scenario_id="kev",
            severity_floor="critical",
            title="CISA KEV：野外已被利用的漏洞",
            summary=(
                "目标存在已经被 CISA KEV 收录的 CVE。攻击者无需自研 PoC —— 公开"
                "在野利用工具即可直接打。这是当前 finding 集合中时间窗口最紧迫"
                "的一组。"
            ),
            steps=(
                AttackPathStep(
                    description="侦察：识别 OpenClaw 运行版本（NVD 已确认受影响）",
                    leveraged_check="version_patch",
                    evidence_refs=tuple(_evidence_tag(f) for f in kev),
                ),
                AttackPathStep(
                    description="利用：调用现成 KEV PoC 触发漏洞",
                    leveraged_check="version_patch",
                    evidence_refs=tuple(_evidence_tag(f) for f in kev),
                ),
                AttackPathStep(
                    description="后果：根据 CVE 性质（认证绕过 / RCE / 越权）",
                    leveraged_check=None,
                ),
            ),
        ))

    # Scenario A — 外网未授权端口 + 高严重度 CVE 链
    expose = _at_least(buckets, "exposure_scan", "low", limit=4)
    cve_high = _at_least(buckets, "version_patch", "high", limit=3)
    if expose and cve_high:
        paths.append(AttackPath(
            scenario_id="external_exposure_to_cve",
            severity_floor="high",
            title="外网攻击者：未授权端口 → 未修复 CVE",
            summary=(
                "目标在公网/评估方网络位置上暴露了不在白名单的监听端口，且"
                "运行版本对一组高严重度 CVE 未打补丁。攻击者可从外部直接触达"
                "API，再借未修复 CVE 取得控制权。"
            ),
            steps=(
                AttackPathStep(
                    description="侦察：从外部网络位置触达非白名单端口",
                    leveraged_check="exposure_scan",
                    evidence_refs=tuple(
                        _evidence_tag(f) for f in expose
                    ),
                ),
                AttackPathStep(
                    description=(
                        "利用：在已确认的运行版本下利用未修复的高严重度 CVE"
                        "（详见 §3.0 总览表）"
                    ),
                    leveraged_check="version_patch",
                    evidence_refs=tuple(_evidence_tag(f) for f in cve_high),
                ),
                AttackPathStep(
                    description=(
                        "后果：取得有效会话 / 工具调用上下文，进入下一阶段"
                        "（横向访问 / 数据出域）"
                    ),
                    leveraged_check=None,
                ),
            ),
        ))

    # Scenario B — 配置弱点（已认证视角）+ 严重 CVE 提权
    native_crit = [f for f in buckets.get("native_audit", []) if f.severity == "critical"]
    cve_crit = _at_least(buckets, "version_patch", "critical", limit=3)
    if native_crit and cve_crit:
        paths.append(AttackPath(
            scenario_id="config_weakness_to_privesc",
            severity_floor="critical",
            title="已认证用户：配置弱点 → 严重 CVE 提权",
            summary=(
                "目标存在严重级别配置弱点（如开放的 groupPolicy / 工具白名单"
                "过宽）以及多枚严重 CVE。已认证的低权限身份可借配置漏洞触达本"
                "不应公开的工具或路径，再触发严重 CVE 进行提权或逃逸。"
            ),
            steps=(
                AttackPathStep(
                    description="进入：通过常规登录通道获得低权限会话",
                    leveraged_check=None,
                ),
                AttackPathStep(
                    description="访问：利用配置弱点抵达本不应公开的工具/接口",
                    leveraged_check="native_audit",
                    evidence_refs=tuple(_evidence_tag(f) for f in native_crit[:3]),
                ),
                AttackPathStep(
                    description="提权：触发严重 CVE 进一步逃逸或取得管理员能力",
                    leveraged_check="version_patch",
                    evidence_refs=tuple(_evidence_tag(f) for f in cve_crit),
                ),
            ),
        ))

    # Scenario C — 凭据滥用 → 持久化
    cred = buckets.get("credential_audit", [])
    persist = buckets.get("process_forensics", [])
    if cred and persist:
        cred_top = sorted(cred, key=lambda f: -_SEV_RANK[f.severity])[:2]
        persist_top = sorted(persist, key=lambda f: -_SEV_RANK[f.severity])[:2]
        paths.append(AttackPath(
            scenario_id="credential_to_persistence",
            severity_floor=cred_top[0].severity,
            title="凭据访问 → 持久化",
            summary=(
                "credential_audit 与 process_forensics 同时触发。攻击者可窃取"
                "凭据后在目标机上保留长期立足点。"
            ),
            steps=(
                AttackPathStep(
                    description="凭据访问：利用 credential_audit 暴露的弱点窃取/枚举凭据",
                    leveraged_check="credential_audit",
                    evidence_refs=tuple(_evidence_tag(f) for f in cred_top),
                ),
                AttackPathStep(
                    description="持久化：通过异常进程 / 自启动条目维持访问",
                    leveraged_check="process_forensics",
                    evidence_refs=tuple(_evidence_tag(f) for f in persist_top),
                ),
            ),
        ))

    return paths
