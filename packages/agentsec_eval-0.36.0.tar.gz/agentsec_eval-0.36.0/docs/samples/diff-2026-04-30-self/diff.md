# AgentSec 报告差异：report-2026-04-28 → report-2026-04-28

**基线**：report-2026-04-28 (2026-04-28)
**当前**：report-2026-04-28 (2026-04-28)

## 评分差异

| 指标 | 基线 | 当前 | Δ |
|------|------|------|---|
| combined_score | 62.2 | 62.2 | — |
| grade | C | C | — |
| remote_score | 33.3 | 33.3 | — |
| server_score | 91.0 | 91.0 | — |
| verdict_coverage | 100.00% | 100.00% | — |
| error_rate | 0.00% | 0.00% | — |

## Findings 差异

**新增：0** | **移除：0** | **稳定：2** | **严重度变化：0** | **证据漂移：0**

<details>
<summary>稳定：2 条 findings（两次运行无变化）</summary>

| 严重度 | Check | 标题 | Fingerprint |
|--------|-------|------|-------------|
| high | native_audit | host: open management port 8443 | `85a59ae4` |
| low | native_audit | outdated subcomponent skill_loader | `52cfce61` |

</details>
