# 服务器安全审计报告

## 目录

1. [报告概览](#1-报告概览)
2. [执行摘要](#2-执行摘要)
3. [详细发现](#3-详细发现)
4. [未执行 / 不适用的检查](#4-未执行--不适用的检查)
5. [错误](#5-错误)
6. [附录 A：机读元数据](#附录-a机读元数据)

## 1. 报告概览

### 1.1 审计目标

| 字段 | 值 |
|------|------|
| 目标主机 | `34.208.65.73` |
| SSH 登录用户 | `ubuntu` |
| SSH 私钥路径 | `~/.ssh/lightsail-prod.pem` |
| 平台 profile | `linux` |
| 远端 $HOME | `/home/ubuntu` |
| OpenClaw 版本 | `2026.2.3.post1` |
| OpenClaw 安装路径 | `/home/ubuntu/.local/bin/openclaw` |
| AUTHORIZATION 文件 | `./AUTHORIZATION-lightsail-prod.txt` |
| 信任级别 | **LOW_ASSURANCE** |
| Finding 总数 | **183** |
| 报告生成时间 | 2026-05-08 01:27 UTC |

> ⚠️ **LOW_ASSURANCE**：本次审计 AUTHORIZATION.txt 的 `signature_mode=none` 或 `identity_assertion` 为空，信任链强度低于 HMAC + 身份断言双因素的标准模式。

### 1.2 审计方法

- **远程通道**：通过 SSH 仅以白名单 argv 调用只读命令；每条 argv 必须通过 `CommandPolicy.validate(argv)` —— `ssh_policy.yaml` 列举每个 check 允许的命令模板，参数与路径由 `PathMatcher` 校验
- **审计日志**：每条调用的 SHA-256 + 拒绝原因写入 `audit-log.jsonl`，命令字面值与 argv 中的敏感参数不持久化
- **HMAC 授权**：`AUTHORIZATION.txt` 用 HMAC-SHA256 + 身份断言绑定本次目标主机与输出路径，确保审计执行链可溯源
- **本次执行 10 项 check**：`native_audit`、`config_audit`、`version_patch`、`active_test`、`exposure_scan`、`filesystem`、`process_forensics`、`credential_audit`、`plugin_static`、`log_review`

### 1.3 审计逻辑拓扑

```mermaid
flowchart LR
    Op["评估方（本机）"]
    Op -->|"SSH 仅只读<br/>用户 ubuntu<br/>key ~/.ssh/lightsail-prod.pem"| TargetIngress
    Op -.->|"AUTHORIZATION<br/>./AUTHORIZATION-lightsail-prod.txt"| TargetIngress

    subgraph Target["目标 34.208.65.73 (linux)"]
        TargetIngress[sshd]
        OC["OpenClaw 2026.2.3.post1<br/>/home/ubuntu/.local/bin/openclaw"]
        Logs["/home/ubuntu/.openclaw/<br/>journald / /var/log/openclaw/"]
        TargetIngress -.- OC
        OC -.- Logs
    end

    TargetIngress --> Policy["CommandPolicy<br/>argv 白名单"]
    Policy --> Checks["10 项只读 check"]
    Checks --> Out["findings.json<br/>audit-log.jsonl<br/>server-audit-report.md"]
```

## 2. 执行摘要

### 2.1 风险态势

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 320" width="540" height="320" role="img" aria-label="严重度分布饼图">
  <title>严重度分布</title>
  <path d="M160,160 L160.00,30.00 A130,130 0 0,1 203.76,37.59 Z" fill="#dc2626" stroke="white" stroke-width="2"/>
  <path d="M160,160 L203.76,37.59 A130,130 0 0,1 214.10,278.21 Z" fill="#ea580c" stroke="white" stroke-width="2"/>
  <text x="240.53" y="156.54" text-anchor="middle" dominant-baseline="central" fill="white" font-size="16" font-weight="bold">69 (38%)</text>
  <path d="M160,160 L214.10,278.21 A130,130 0 1,1 107.94,40.88 Z" fill="#eab308" stroke="white" stroke-width="2"/>
  <text x="86.42" y="192.91" text-anchor="middle" dominant-baseline="central" fill="white" font-size="16" font-weight="bold">92 (50%)</text>
  <path d="M160,160 L107.94,40.88 A130,130 0 0,1 151.08,30.31 Z" fill="#3b82f6" stroke="white" stroke-width="2"/>
  <path d="M160,160 L151.08,30.31 A130,130 0 0,1 160.00,30.00 Z" fill="#9ca3af" stroke="white" stroke-width="2"/>
  <rect x="340" y="85" width="20" height="20" fill="#dc2626" stroke="white" stroke-width="1"/>
  <text x="370" y="95" fill="currentColor" font-size="15" dominant-baseline="central">严重 · 10 (5.5%)</text>
  <rect x="340" y="115" width="20" height="20" fill="#ea580c" stroke="white" stroke-width="1"/>
  <text x="370" y="125" fill="currentColor" font-size="15" dominant-baseline="central">高 · 69 (37.7%)</text>
  <rect x="340" y="145" width="20" height="20" fill="#eab308" stroke="white" stroke-width="1"/>
  <text x="370" y="155" fill="currentColor" font-size="15" dominant-baseline="central">中 · 92 (50.3%)</text>
  <rect x="340" y="175" width="20" height="20" fill="#3b82f6" stroke="white" stroke-width="1"/>
  <text x="370" y="185" fill="currentColor" font-size="15" dominant-baseline="central">低 · 10 (5.5%)</text>
  <rect x="340" y="205" width="20" height="20" fill="#9ca3af" stroke="white" stroke-width="1"/>
  <text x="370" y="215" fill="currentColor" font-size="15" dominant-baseline="central">信息 · 2 (1.1%)</text>
</svg>

| 严重度 | 数量 |
|--------|------|
| 🔴 严重 | 10 |
| 🟠 高 | 69 |
| 🟡 中 | 92 |
| 🔵 低 | 10 |
| ⚪ 信息 | 2 |
| **合计** | **183** |

### 2.2 攻击路径

> 以下攻击路径来自当前 finding 集合的启发式推断（基于 check 类型 +严重度 + KEV 标记的组合规则），需结合实际网络可达性与运维上下文复核后才能视为可执行的威胁场景。

#### 2.2.1 外网攻击者：未授权端口 → 未修复 CVE

_（场景 ID：`external_exposure_to_cve` · 严重度下限：**high**）_

**概述**：目标在公网/评估方网络位置上暴露了不在白名单的监听端口，且运行版本对一组高严重度 CVE 未打补丁。攻击者可从外部直接触达API，再借未修复 CVE 取得控制权。

**步骤**：

1. 侦察：从外部网络位置触达非白名单端口  
  　脆弱性：`未在白名单的监听端口：18790/tcp（34.208.65.73）`、`未在白名单的监听端口：8443/tcp（34.208.65.73）`、`未在白名单的监听端口：80/tcp（34.208.65.73）`、`未在白名单的监听端口：443/tcp（34.208.65.73）`  
  　来源 check：`exposure_scan`
2. 利用：在已确认的运行版本下利用未修复的高严重度 CVE（详见 §3.0 总览表）  
  　脆弱性：`CVE-2026-22172`、`CVE-2026-27002`、`CVE-2026-28363`  
  　来源 check：`version_patch`
3. 后果：取得有效会话 / 工具调用上下文，进入下一阶段（横向访问 / 数据出域）

#### 2.2.2 已认证用户：配置弱点 → 严重 CVE 提权

_（场景 ID：`config_weakness_to_privesc` · 严重度下限：**critical**）_

**概述**：目标存在严重级别配置弱点（如开放的 groupPolicy / 工具白名单过宽）以及多枚严重 CVE。已认证的低权限身份可借配置漏洞触达本不应公开的工具或路径，再触发严重 CVE 进行提权或逃逸。

**步骤**：

1. 进入：通过常规登录通道获得低权限会话
2. 访问：利用配置弱点抵达本不应公开的工具/接口  
  　脆弱性：`Open groupPolicy with elevated tools enabled`、`Discord security warning`  
  　来源 check：`native_audit`
3. 提权：触发严重 CVE 进一步逃逸或取得管理员能力  
  　脆弱性：`CVE-2026-22172`、`CVE-2026-27002`、`CVE-2026-28363`  
  　来源 check：`version_patch`

### 2.3 最高优先级修复

**严重（critical） —— 全部 10 条：**

1. **[CRITICAL]** `native_audit` — Open groupPolicy with elevated tools enabled
2. **[CRITICAL]** `native_audit` — Discord security warning
3. **[CRITICAL]** `version_patch` — [CVE-2026-22172] OpenClaw 版本受影响（受影响 <2026.3.12，已修复 2026.3.12）
4. **[CRITICAL]** `version_patch` — [CVE-2026-27002] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15）
5. **[CRITICAL]** `version_patch` — [CVE-2026-28363] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23）
6. **[CRITICAL]** `version_patch` — [CVE-2026-28466] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14）
7. **[CRITICAL]** `version_patch` — [CVE-2026-30741] OpenClaw 版本受影响（受影响 <=2026.2.6）
8. **[CRITICAL]** `version_patch` — [CVE-2026-32038] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24）
9. **[CRITICAL]** `version_patch` — [CVE-2026-32913] OpenClaw 版本受影响（受影响 <2026.3.7，已修复 2026.3.7）
10. **[CRITICAL]** `version_patch` — [CVE-2026-32922] OpenClaw 版本受影响（受影响 <2026.3.11，已修复 2026.3.11）

**高（high） —— top 10 / 69：**

1. **[HIGH]** `version_patch` — [CVE-2026-22171] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19）
2. **[HIGH]** `version_patch` — [CVE-2026-22175] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23）
3. **[HIGH]** `version_patch` — [CVE-2026-22179] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22）
4. **[HIGH]** `version_patch` — [CVE-2026-22181] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2）
5. **[HIGH]** `version_patch` — [CVE-2026-26316] OpenClaw 版本受影响（受影响 <2026.2.13，已修复 2026.2.13）
6. **[HIGH]** `version_patch` — [CVE-2026-26317] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14）
7. **[HIGH]** `version_patch` — [CVE-2026-26319] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14）
8. **[HIGH]** `version_patch` — [CVE-2026-26321] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14）
9. **[HIGH]** `version_patch` — [CVE-2026-26322] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14）
10. **[HIGH]** `version_patch` — [CVE-2026-26323] OpenClaw 版本受影响（受影响 >=2026.1.8,<2026.2.14，已修复 2026.2.14）

… 还有 59 条 high 详见 §3。

**中（medium）**：92 条详见 §3。

### 2.4 Check 维度分布

| Check | 总数 | 🔴 | 🟠 | 🟡 | 🔵 | ⚪ |
|-------|------|----|----|----|----|----|
| `version_patch` | 174 | 8 | 69 | 87 | 10 | — |
| `native_audit` | 4 | 2 | — | 1 | — | 1 |
| `exposure_scan` | 4 | — | — | 4 | — | — |
| `active_test` | 1 | — | — | — | — | 1 |

## 3. 详细发现

### 3.0 version_patch — CVE 总览（174 条）

> 当前运行版本：`2026.2.3.post1`

| 严重度 | CVE | 受影响 | 修复版本 | KEV / CVSS | 链接 |
|--------|-----|--------|----------|------------|------|
| 🔴 critical | `CVE-2026-22172` | <2026.3.12 | 2026.3.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22172) |
| 🔴 critical | `CVE-2026-27002` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27002) |
| 🔴 critical | `CVE-2026-28363` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28363) |
| 🔴 critical | `CVE-2026-28466` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28466) |
| 🔴 critical | `CVE-2026-30741` | <=2026.2.6 | — | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-30741) |
| 🔴 critical | `CVE-2026-32038` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32038) |
| 🔴 critical | `CVE-2026-32913` | <2026.3.7 | 2026.3.7 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32913) |
| 🔴 critical | `CVE-2026-32922` | <2026.3.11 | 2026.3.11 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32922) |
| 🟠 high | `CVE-2026-22171` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22171) |
| 🟠 high | `CVE-2026-22175` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22175) |
| 🟠 high | `CVE-2026-22179` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22179) |
| 🟠 high | `CVE-2026-22181` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22181) |
| 🟠 high | `CVE-2026-26316` | <2026.2.13 | 2026.2.13 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26316) |
| 🟠 high | `CVE-2026-26317` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26317) |
| 🟠 high | `CVE-2026-26319` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26319) |
| 🟠 high | `CVE-2026-26321` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26321) |
| 🟠 high | `CVE-2026-26322` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26322) |
| 🟠 high | `CVE-2026-26323` | >=2026.1.8,<2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26323) |
| 🟠 high | `CVE-2026-26324` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26324) |
| 🟠 high | `CVE-2026-26325` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26325) |
| 🟠 high | `CVE-2026-27001` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27001) |
| 🟠 high | `CVE-2026-27487` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27487) |
| 🟠 high | `CVE-2026-27488` | <=2026.2.17 | — | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27488) |
| 🟠 high | `CVE-2026-27566` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27566) |
| 🟠 high | `CVE-2026-28392` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28392) |
| 🟠 high | `CVE-2026-28393` | >=2026.1.4,<2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28393) |
| 🟠 high | `CVE-2026-28451` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28451) |
| 🟠 high | `CVE-2026-28453` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28453) |
| 🟠 high | `CVE-2026-28456` | >=2026.1.5,<2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28456) |
| 🟠 high | `CVE-2026-28459` | <2026.2.12 | 2026.2.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28459) |
| 🟠 high | `CVE-2026-28460` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28460) |
| 🟠 high | `CVE-2026-28461` | <2026.3.1 | 2026.3.1 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28461) |
| 🟠 high | `CVE-2026-28462` | <2026.2.13 | 2026.2.13 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28462) |
| 🟠 high | `CVE-2026-28463` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28463) |
| 🟠 high | `CVE-2026-28468` | >=2026.1.29,<2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28468) |
| 🟠 high | `CVE-2026-28469` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28469) |
| 🟠 high | `CVE-2026-28476` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28476) |
| 🟠 high | `CVE-2026-28477` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28477) |
| 🟠 high | `CVE-2026-28478` | <2026.2.13 | 2026.2.13 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28478) |
| 🟠 high | `CVE-2026-28479` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28479) |
| 🟠 high | `CVE-2026-28482` | <2026.2.12 | 2026.2.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28482) |
| 🟠 high | `CVE-2026-29609` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29609) |
| 🟠 high | `CVE-2026-29610` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29610) |
| 🟠 high | `CVE-2026-29611` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29611) |
| 🟠 high | `CVE-2026-31989` | <2026.3.1 | 2026.3.1 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31989) |
| 🟠 high | `CVE-2026-31992` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31992) |
| 🟠 high | `CVE-2026-31994` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31994) |
| 🟠 high | `CVE-2026-32000` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32000) |
| 🟠 high | `CVE-2026-32011` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32011) |
| 🟠 high | `CVE-2026-32013` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32013) |
| 🟠 high | `CVE-2026-32014` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32014) |
| 🟠 high | `CVE-2026-32015` | >=2026.1.21,<2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32015) |
| 🟠 high | `CVE-2026-32016` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32016) |
| 🟠 high | `CVE-2026-32017` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32017) |
| 🟠 high | `CVE-2026-32019` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32019) |
| 🟠 high | `CVE-2026-32023` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32023) |
| 🟠 high | `CVE-2026-32025` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32025) |
| 🟠 high | `CVE-2026-32030` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32030) |
| 🟠 high | `CVE-2026-32032` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32032) |
| 🟠 high | `CVE-2026-32034` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32034) |
| 🟠 high | `CVE-2026-32048` | <2026.3.1 | 2026.3.1 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32048) |
| 🟠 high | `CVE-2026-32049` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32049) |
| 🟠 high | `CVE-2026-32051` | <2026.3.1 | 2026.3.1 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32051) |
| 🟠 high | `CVE-2026-32055` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32055) |
| 🟠 high | `CVE-2026-32056` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32056) |
| 🟠 high | `CVE-2026-32057` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32057) |
| 🟠 high | `CVE-2026-32059` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32059) |
| 🟠 high | `CVE-2026-32060` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32060) |
| 🟠 high | `CVE-2026-32062` | <2026.2.22, <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32062) |
| 🟠 high | `CVE-2026-32063` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32063) |
| 🟠 high | `CVE-2026-32064` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32064) |
| 🟠 high | `CVE-2026-32302` | <2026.3.11 | 2026.3.11 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32302) |
| 🟠 high | `CVE-2026-32846` | <=2026.3.23 | — | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32846) |
| 🟠 high | `CVE-2026-32914` | <2026.3.12 | 2026.3.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32914) |
| 🟠 high | `CVE-2026-32915` | <2026.3.11 | 2026.3.11 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32915) |
| 🟠 high | `CVE-2026-32918` | <2026.3.11 | 2026.3.11 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32918) |
| 🟠 high | `CVE-2026-41349` | <2026.3.28 | 2026.3.28 | — | [↗](https://www.redpacketsecurity.com/cve-alert-cve-2026-41349-openclaw-openclaw/) |
| 🟡 medium | `CVE-2026-22168` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22168) |
| 🟡 medium | `CVE-2026-22169` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22169) |
| 🟡 medium | `CVE-2026-22170` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22170) |
| 🟡 medium | `CVE-2026-22174` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22174) |
| 🟡 medium | `CVE-2026-22176` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22176) |
| 🟡 medium | `CVE-2026-22177` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22177) |
| 🟡 medium | `CVE-2026-22178` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22178) |
| 🟡 medium | `CVE-2026-22180` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22180) |
| 🟡 medium | `CVE-2026-26326` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26326) |
| 🟡 medium | `CVE-2026-26327` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26327) |
| 🟡 medium | `CVE-2026-26328` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26328) |
| 🟡 medium | `CVE-2026-26329` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26329) |
| 🟡 medium | `CVE-2026-26972` | >=2026.1.12,<2026.2.13 | 2026.2.13 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26972) |
| 🟡 medium | `CVE-2026-27003` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27003) |
| 🟡 medium | `CVE-2026-27004` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27004) |
| 🟡 medium | `CVE-2026-27008` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27008) |
| 🟡 medium | `CVE-2026-27009` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27009) |
| 🟡 medium | `CVE-2026-27183` | <2026.3.7 | 2026.3.7 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27183) |
| 🟡 medium | `CVE-2026-27484` | <=2026.2.17 | — | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27484) |
| 🟡 medium | `CVE-2026-27485` | <=2026.2.17 | — | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27485) |
| 🟡 medium | `CVE-2026-27486` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27486) |
| 🟡 medium | `CVE-2026-27522` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27522) |
| 🟡 medium | `CVE-2026-27523` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27523) |
| 🟡 medium | `CVE-2026-27524` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27524) |
| 🟡 medium | `CVE-2026-27545` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27545) |
| 🟡 medium | `CVE-2026-27576` | <=2026.2.17 | — | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27576) |
| 🟡 medium | `CVE-2026-27646` | <2026.3.7 | 2026.3.7 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27646) |
| 🟡 medium | `CVE-2026-27670` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27670) |
| 🟡 medium | `CVE-2026-28394` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28394) |
| 🟡 medium | `CVE-2026-28395` | >=2026.1.14-1,<2026.2.12 | 2026.2.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28395) |
| 🟡 medium | `CVE-2026-28449` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28449) |
| 🟡 medium | `CVE-2026-28450` | <2026.2.12 | 2026.2.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28450) |
| 🟡 medium | `CVE-2026-28452` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28452) |
| 🟡 medium | `CVE-2026-28457` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28457) |
| 🟡 medium | `CVE-2026-28464` | <2026.2.12 | 2026.2.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28464) |
| 🟡 medium | `CVE-2026-28475` | <2026.2.13 | 2026.2.13 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28475) |
| 🟡 medium | `CVE-2026-28480` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28480) |
| 🟡 medium | `CVE-2026-28486` | >=2026.1.20,<2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28486) |
| 🟡 medium | `CVE-2026-29606` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29606) |
| 🟡 medium | `CVE-2026-29607` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29607) |
| 🟡 medium | `CVE-2026-29612` | <2026.2.14 | 2026.2.14 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29612) |
| 🟡 medium | `CVE-2026-29613` | <2026.2.12 | 2026.2.12 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29613) |
| 🟡 medium | `CVE-2026-31990` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31990) |
| 🟡 medium | `CVE-2026-31993` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31993) |
| 🟡 medium | `CVE-2026-31995` | >=2026.1.21,<2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31995) |
| 🟡 medium | `CVE-2026-31996` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31996) |
| 🟡 medium | `CVE-2026-31997` | <2026.3.1 | 2026.3.1 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31997) |
| 🟡 medium | `CVE-2026-32001` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32001) |
| 🟡 medium | `CVE-2026-32002` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32002) |
| 🟡 medium | `CVE-2026-32003` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32003) |
| 🟡 medium | `CVE-2026-32004` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32004) |
| 🟡 medium | `CVE-2026-32005` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32005) |
| 🟡 medium | `CVE-2026-32007` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32007) |
| 🟡 medium | `CVE-2026-32008` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32008) |
| 🟡 medium | `CVE-2026-32009` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32009) |
| 🟡 medium | `CVE-2026-32010` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32010) |
| 🟡 medium | `CVE-2026-32021` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32021) |
| 🟡 medium | `CVE-2026-32022` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32022) |
| 🟡 medium | `CVE-2026-32024` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32024) |
| 🟡 medium | `CVE-2026-32026` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32026) |
| 🟡 medium | `CVE-2026-32027` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32027) |
| 🟡 medium | `CVE-2026-32028` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32028) |
| 🟡 medium | `CVE-2026-32029` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32029) |
| 🟡 medium | `CVE-2026-32031` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32031) |
| 🟡 medium | `CVE-2026-32033` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32033) |
| 🟡 medium | `CVE-2026-32035` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32035) |
| 🟡 medium | `CVE-2026-32036` | <2026.2.6 | 2026.2.6 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32036) |
| 🟡 medium | `CVE-2026-32037` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32037) |
| 🟡 medium | `CVE-2026-32039` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32039) |
| 🟡 medium | `CVE-2026-32040` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32040) |
| 🟡 medium | `CVE-2026-32041` | <2026.3.1 | 2026.3.1 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32041) |
| 🟡 medium | `CVE-2026-32043` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32043) |
| 🟡 medium | `CVE-2026-32044` | <2026.3.2 | 2026.3.2 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32044) |
| 🟡 medium | `CVE-2026-32045` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32045) |
| 🟡 medium | `CVE-2026-32046` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32046) |
| 🟡 medium | `CVE-2026-32052` | <2026.2.24 | 2026.2.24 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32052) |
| 🟡 medium | `CVE-2026-32053` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32053) |
| 🟡 medium | `CVE-2026-32054` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32054) |
| 🟡 medium | `CVE-2026-32061` | <2026.2.17 | 2026.2.17 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32061) |
| 🟡 medium | `CVE-2026-32065` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32065) |
| 🟡 medium | `CVE-2026-32895` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32895) |
| 🟡 medium | `CVE-2026-32896` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32896) |
| 🟡 medium | `CVE-2026-32898` | <2026.2.23 | 2026.2.23 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32898) |
| 🟡 medium | `CVE-2026-32899` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32899) |
| 🟡 medium | `CVE-2026-32919` | <2026.3.11 | 2026.3.11 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32919) |
| 🟡 medium | `CVE-2026-32923` | <2026.3.11 | 2026.3.11 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32923) |
| 🟡 medium | `CVE-2026-4039` | <2026.2.21 | 2026.2.21 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-4039) |
| 🔵 low | `CVE-2026-27007` | <2026.2.15 | 2026.2.15 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27007) |
| 🔵 low | `CVE-2026-31991` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31991) |
| 🔵 low | `CVE-2026-32006` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32006) |
| 🔵 low | `CVE-2026-32018` | <2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32018) |
| 🔵 low | `CVE-2026-32020` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32020) |
| 🔵 low | `CVE-2026-32050` | <2026.2.25 | 2026.2.25 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32050) |
| 🔵 low | `CVE-2026-32058` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32058) |
| 🔵 low | `CVE-2026-32067` | <2026.2.26 | 2026.2.26 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32067) |
| 🔵 low | `CVE-2026-32897` | <2026.2.22 | 2026.2.22 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32897) |
| 🔵 low | `CVE-2026-4040` | >=2026.2.0,<2026.2.19 | 2026.2.19 | — | [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-4040) |

<details>
<summary>展开 174 个 CVE 详细描述（NVD 原文 + 证据）</summary>

#### 3.0.1 [CRITICAL] [CVE-2026-22172] OpenClaw 版本受影响（受影响 <2026.3.12，已修复 2026.3.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22172)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22172
- **指纹**：`f447bc4162cd658a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.12 contain an authorization bypass vulnerability in the WebSocket connect path that allows shared-token or password-authenticated connections to self-declare elevated scopes without server-side binding. ...

**证据**：
  - `affected_versions`：<2026.3.12
  - `fixed_in`：2026.3.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.12 或更高版本

---

#### 3.0.2 [CRITICAL] [CVE-2026-27002] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27002)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27002
- **指纹**：`dc8601cade243cf0`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.15, a configuration injection issue in the Docker tool sandbox could allow dangerous Docker options (bind mounts, host networking, unconfined profiles) to be applied, enabling ...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.3 [CRITICAL] [CVE-2026-28363] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28363)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28363
- **指纹**：`1abb221f7ef28e62`

**描述**（来源：NVD seed，未经本地翻译）：

> In OpenClaw before 2026.2.23, tools.exec.safeBins validation for sort could be bypassed via GNU long-option abbreviations (such as --compress-prog) in allowlist mode, leading to approval-free execution paths that were intended to require...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.4 [CRITICAL] [CVE-2026-28466] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28466)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28466
- **指纹**：`eff9dda402c30040`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a vulnerability in the gateway in which it fails to sanitize internal approval fields in node.invoke parameters, allowing authenticated clients to bypass exec approval gating for system.run co...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.5 [CRITICAL] [CVE-2026-30741] OpenClaw 版本受影响（受影响 <=2026.2.6） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-30741)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-30741
- **指纹**：`d5e87380590cc00c`

**描述**（来源：NVD seed，未经本地翻译）：

> A remote code execution (RCE) vulnerability in OpenClaw Agent Platform v2026.2.6 allows attackers to execute arbitrary code via a Request-Side prompt injection attack.

**证据**：
  - `affected_versions`：<=2026.2.6
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 <参见 CVE 详情> 或更高版本

---

#### 3.0.6 [CRITICAL] [CVE-2026-32038] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32038)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32038
- **指纹**：`adf1e827b054967b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw before 2026.2.24 contains a sandbox network isolation bypass vulnerability that allows trusted operators to join another container's network namespace. Attackers can configure the docker.network parameter with container:<id> val...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.7 [CRITICAL] [CVE-2026-32913] OpenClaw 版本受影响（受影响 <2026.3.7，已修复 2026.3.7） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32913)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32913
- **指纹**：`85358c6827bfb373`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw before 2026.3.7 contains an improper header validation vulnerability in fetchWithSsrFGuard that forwards custom authorization headers across cross-origin redirects. Attackers can trigger redirects to different origins to interce...

**证据**：
  - `affected_versions`：<2026.3.7
  - `fixed_in`：2026.3.7
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.7 或更高版本

---

#### 3.0.8 [CRITICAL] [CVE-2026-32922] OpenClaw 版本受影响（受影响 <2026.3.11，已修复 2026.3.11） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32922)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32922
- **指纹**：`9ea8e6642f69eb93`

**描述**：OpenClaw remote code execution via malformed skill manifest

**证据**：
  - `affected_versions`：<2026.3.11
  - `fixed_in`：2026.3.11
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.11 或更高版本

---

#### 3.0.9 [HIGH] [CVE-2026-22171] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22171)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22171
- **指纹**：`b49920743c6e26e1`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 contain a path traversal vulnerability in the Feishu media download flow where untrusted media keys are interpolated directly into temporary file paths in extensions/feishu/src/media.ts. An attacker w...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.10 [HIGH] [CVE-2026-22175] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22175)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22175
- **指纹**：`060d9d9b0b41f499`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.23 contain an exec approval bypass vulnerability in allowlist mode where allow-always grants could be circumvented through unrecognized multiplexer shell wrappers like busybox and toybox sh -c commands. ...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.11 [HIGH] [CVE-2026-22179] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22179)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22179
- **指纹**：`7d5cddb848fc7fed`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 in macOS node-host system.run contain an allowlist bypass vulnerability that allows remote attackers to execute non-allowlisted commands by exploiting improper parsing of command substitution tokens. ...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.12 [HIGH] [CVE-2026-22181] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22181)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22181
- **指纹**：`256db33d4561a2d3`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 contain a DNS pinning bypass vulnerability in strict URL fetch paths that allows attackers to circumvent SSRF guards when environment proxy variables are configured. When HTTP_PROXY, HTTPS_PROXY, or AL...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.13 [HIGH] [CVE-2026-26316] OpenClaw 版本受影响（受影响 <2026.2.13，已修复 2026.2.13） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26316)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26316
- **指纹**：`e82d823c31c1e570`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to 2026.2.13, the optional BlueBubbles iMessage channel plugin could accept webhook requests as authenticated based only on the TCP peer address being loopback (`127.0.0.1`, `::1`, `::ffff:127.0...

**证据**：
  - `affected_versions`：<2026.2.13
  - `fixed_in`：2026.2.13
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.13 或更高版本

---

#### 3.0.14 [HIGH] [CVE-2026-26317] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26317)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26317
- **指纹**：`279f82cfbef3c330`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to 2026.2.14, browser-facing localhost mutation routes accepted cross-origin browser requests without explicit Origin/Referer validation. Loopback binding reduces remote exposure but does not pr...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.15 [HIGH] [CVE-2026-26319] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26319)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26319
- **指纹**：`9a21b1493be1d423`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Versions 2026.2.13 and below allow the optional @openclaw/voice-call plugin Telnyx webhook handler to accept unsigned inbound webhook requests when telnyx.publicKey is not configured, enabling unauthe...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.16 [HIGH] [CVE-2026-26321] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26321)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26321
- **指纹**：`632787f1424a278d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to OpenClaw version 2026.2.14, the Feishu extension previously allowed `sendMediaFeishu` to treat attacker-controlled `mediaUrl` values as local filesystem paths and read them directly. If an at...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.17 [HIGH] [CVE-2026-26322] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26322)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26322
- **指纹**：`bb3679ded61362a5`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to OpenClaw version 2026.2.14, the Gateway tool accepted a tool-supplied `gatewayUrl` without sufficient restrictions, which could cause the OpenClaw host to attempt outbound WebSocket connectio...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.18 [HIGH] [CVE-2026-26323] OpenClaw 版本受影响（受影响 >=2026.1.8,<2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26323)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26323
- **指纹**：`4726b067178562aa`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Versions 2026.1.8 through 2026.2.13 have a command injection in the maintainer/dev script `scripts/update-clawtributors.ts`. The issue affects contributors/maintainers (or CI) who run `bun scripts/upd...

**证据**：
  - `affected_versions`：>=2026.1.8,<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.19 [HIGH] [CVE-2026-26324] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26324)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26324
- **指纹**：`0d09a3bf66c66eaf`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.14, OpenClaw's SSRF protection could be bypassed using full-form IPv4-mapped IPv6 literals such as `0:0:0:0:0:ffff:7f00:1` (which is `127.0.0.1`). This could allow requests tha...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.20 [HIGH] [CVE-2026-26325] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26325)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26325
- **指纹**：`ded25a1c46cabf4b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.14, a mismatch between `rawCommand` and `command[]` in the node host `system.run` handler could cause allowlist/approval evaluation to be performed on one command while executi...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.21 [HIGH] [CVE-2026-27001] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27001)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27001
- **指纹**：`70a5f852fc2d9b60`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.15, OpenClaw embedded the current working directory (workspace path) into the agent system prompt without sanitization. If an attacker can cause OpenClaw to run inside a direct...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.22 [HIGH] [CVE-2026-27487] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27487)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27487
- **指纹**：`d2b6df85cfd18df2`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. In versions 2026.2.13 and below, when using macOS, the Claude CLI keychain credential refresh path constructed a shell command to write the updated JSON blob into Keychain via security add-generic-pas...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.23 [HIGH] [CVE-2026-27488] OpenClaw 版本受影响（受影响 <=2026.2.17） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27488)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27488
- **指纹**：`1d1918ce2739d84e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. In versions 2026.2.17 and below, Cron webhook delivery in src/gateway/server-cron.ts uses fetch() directly, so webhook targets can reach private/metadata/internal endpoints without SSRF policy checks....

**证据**：
  - `affected_versions`：<=2026.2.17
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 <参见 CVE 详情> 或更高版本

---

#### 3.0.24 [HIGH] [CVE-2026-27566] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27566)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27566
- **指纹**：`bb5a839c1055fe82`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an allowlist bypass vulnerability in system.run exec analysis that fails to unwrap env and shell-dispatch wrapper chains. Attackers can route execution through wrapper binaries like env bash t...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.25 [HIGH] [CVE-2026-28392] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28392)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28392
- **指纹**：`6c4e21549a52f9df`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a privilege escalation vulnerability in the Slack slash-command handler that incorrectly authorizes any direct message sender when dmPolicy is set to open (must be configured). Attackers can e...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.26 [HIGH] [CVE-2026-28393] OpenClaw 版本受影响（受影响 >=2026.1.4,<2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28393)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28393
- **指纹**：`3fa432544ecccb96`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions 2.0.0-beta3 prior to 2026.2.14 contain a path traversal vulnerability in hook transform module loading that allows arbitrary JavaScript execution. The hooks.mappings[].transform.module parameter accepts absolute paths a...

**证据**：
  - `affected_versions`：>=2026.1.4,<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.27 [HIGH] [CVE-2026-28451] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28451)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28451
- **指纹**：`73676d4398a27cc5`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain server-side request forgery vulnerabilities in the Feishu extension that allow attackers to fetch attacker-controlled remote URLs without SSRF protections via sendMediaFeishu function and mark...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.28 [HIGH] [CVE-2026-28453] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28453)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28453
- **指纹**：`a22e1c77bec914ab`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 fail to validate TAR archive entry paths during extraction, allowing path traversal sequences to write files outside the intended directory. Attackers can craft malicious archives with traversal seque...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.29 [HIGH] [CVE-2026-28456] OpenClaw 版本受影响（受影响 >=2026.1.5,<2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28456)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28456
- **指纹**：`18238d26a5eabfac`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions 2026.1.5 prior to 2026.2.14 contain a vulnerability in the Gateway in which it does not sufficiently constrain configured hook module paths before passing them to dynamic import(), allowing code execution. An attacker w...

**证据**：
  - `affected_versions`：>=2026.1.5,<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.30 [HIGH] [CVE-2026-28459] OpenClaw 版本受影响（受影响 <2026.2.12，已修复 2026.2.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28459)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28459
- **指纹**：`b79d3acbd70511de`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.12 fail to validate the sessionFile path parameter, allowing authenticated gateway clients to write transcript data to arbitrary locations on the host filesystem. Attackers can supply a sessionFile path ...

**证据**：
  - `affected_versions`：<2026.2.12
  - `fixed_in`：2026.2.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.12 或更高版本

---

#### 3.0.31 [HIGH] [CVE-2026-28460] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28460)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28460
- **指纹**：`29f833214e8f93ea`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an allowlist bypass vulnerability in system.run that allows attackers to execute non-allowlisted commands by splitting command substitution using shell line-continuation characters. Attackers ...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.32 [HIGH] [CVE-2026-28461] OpenClaw 版本受影响（受影响 <2026.3.1，已修复 2026.3.1） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28461)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28461
- **指纹**：`98aa92f3396dbdd7`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.1 contain an unbounded memory growth vulnerability in the Zalo webhook endpoint that allows unauthenticated attackers to trigger in-memory key accumulation by varying query strings. Remote attackers can ...

**证据**：
  - `affected_versions`：<2026.3.1
  - `fixed_in`：2026.3.1
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.1 或更高版本

---

#### 3.0.33 [HIGH] [CVE-2026-28462] OpenClaw 版本受影响（受影响 <2026.2.13，已修复 2026.2.13） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28462)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28462
- **指纹**：`8e3a01a170aba7b5`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.13 contain a vulnerability in the browser control API in which it accepts user-supplied output paths for trace and download files without consistently constraining writes to temporary directories. Attack...

**证据**：
  - `affected_versions`：<2026.2.13
  - `fixed_in`：2026.2.13
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.13 或更高版本

---

#### 3.0.34 [HIGH] [CVE-2026-28463] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28463)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28463
- **指纹**：`4b54bb3f1167e483`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain an arbitrary file read vulnerability in the exec-approvals allowlist validation that checks pre-expansion argv tokens but executes using real shell expansion. Attackers with authorization or t...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.35 [HIGH] [CVE-2026-28468] OpenClaw 版本受影响（受影响 >=2026.1.29,<2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28468)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28468
- **指纹**：`82b058a3094c1047`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions 2026.1.29-beta.1 prior to 2026.2.14 contain a vulnerability in the sandbox browser bridge server in which it accepts requests without requiring gateway authentication, allowing local attackers to access browser control ...

**证据**：
  - `affected_versions`：>=2026.1.29,<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.36 [HIGH] [CVE-2026-28469] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28469)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28469
- **指纹**：`3074a48152c4e599`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a webhook routing vulnerability in the Google Chat monitor component that allows cross-account policy context misrouting when multiple webhook targets share the same HTTP path. Attackers can e...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.37 [HIGH] [CVE-2026-28476] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28476)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28476
- **指纹**：`af578c92611f973d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a server-side request forgery vulnerability in the optional Tlon Urbit extension that accepts user-provided base URLs for authentication without proper validation. Attackers who can influence ...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.38 [HIGH] [CVE-2026-28477] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28477)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28477
- **指纹**：`0791539601f048df`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain an oauth state validation bypass vulnerability in the manual Chutes login flow that allows attackers to bypass CSRF protection. An attacker can convince a user to paste attacker-controlled OAu...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.39 [HIGH] [CVE-2026-28478] OpenClaw 版本受影响（受影响 <2026.2.13，已修复 2026.2.13） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28478)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28478
- **指纹**：`fa40acbac8385fe8`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.13 contain a denial of service vulnerability in webhook handlers that buffer request bodies without strict byte or time limits. Remote unauthenticated attackers can send oversized JSON payloads or slow u...

**证据**：
  - `affected_versions`：<2026.2.13
  - `fixed_in`：2026.2.13
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.13 或更高版本

---

#### 3.0.40 [HIGH] [CVE-2026-28479] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28479)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28479
- **指纹**：`a372ca58b326296e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.15 use SHA-1 to hash sandbox identifier cache keys for Docker and browser sandbox configurations, which is deprecated and vulnerable to collision attacks. An attacker can exploit SHA-1 collisions to caus...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.41 [HIGH] [CVE-2026-28482] OpenClaw 版本受影响（受影响 <2026.2.12，已修复 2026.2.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28482)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28482
- **指纹**：`e84a6afc7433288f`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.12 construct transcript file paths using unsanitized sessionId parameters and sessionFile paths without enforcing directory containment. Authenticated attackers can exploit path traversal sequences like ...

**证据**：
  - `affected_versions`：<2026.2.12
  - `fixed_in`：2026.2.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.12 或更高版本

---

#### 3.0.42 [HIGH] [CVE-2026-29609] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29609)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-29609
- **指纹**：`3140da10f758c1c2`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a denial of service vulnerability in the fetchWithGuard function that allocates entire response payloads in memory before enforcing maxBytes limits. Remote attackers can trigger memory exhaust...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.43 [HIGH] [CVE-2026-29610] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29610)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-29610
- **指纹**：`9642157c2eddb334`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a command hijacking vulnerability that allows attackers to execute unintended binaries by manipulating PATH environment variables through node-host execution or project-local bootstrapping. At...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.44 [HIGH] [CVE-2026-29611] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29611)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-29611
- **指纹**：`1ab2492ce4cfd45d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a local file inclusion vulnerability in BlueBubbles extension (must be installed and enabled) media path handling that allows attackers to read arbitrary files from the local filesystem. The s...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.45 [HIGH] [CVE-2026-31989] OpenClaw 版本受影响（受影响 <2026.3.1，已修复 2026.3.1） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31989)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31989
- **指纹**：`f5a113b196fe3c5a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.1 contain a server-side request forgery vulnerability in web_search citation redirect resolution that uses a private-network-allowing SSRF policy. An attacker who can influence citation redirect targets ...

**证据**：
  - `affected_versions`：<2026.3.1
  - `fixed_in`：2026.3.1
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.1 或更高版本

---

#### 3.0.46 [HIGH] [CVE-2026-31992] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31992)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31992
- **指纹**：`6bfe02d478ef4bd2`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.23 contain an allowlist bypass vulnerability in system.run guardrails that allows authenticated operators to execute unintended commands. When /usr/bin/env is allowlisted, attackers can use env -S to byp...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.47 [HIGH] [CVE-2026-31994] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31994)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31994
- **指纹**：`e55b068fa5ac2f5b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 contain a local command injection vulnerability in Windows scheduled task script generation due to unsafe handling of cmd metacharacters and expansion-sensitive characters in gateway.cmd files. Local ...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.48 [HIGH] [CVE-2026-32000] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32000)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32000
- **指纹**：`653f9bb0b2a09f4d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 contain a command injection vulnerability in the Lobster extension tool execution that uses Windows shell fallback with shell: true after spawn failures. Attackers can inject shell metacharacters in c...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.49 [HIGH] [CVE-2026-32011] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32011)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32011
- **指纹**：`d1c34094529040b7`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 contain a denial of service vulnerability in webhook handlers for BlueBubbles and Google Chat that parse request bodies before performing authentication and signature validation. Unauthenticated attack...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.50 [HIGH] [CVE-2026-32013] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32013)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32013
- **指纹**：`680c02383e9f57a9`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 contain a symlink traversal vulnerability in the agents.files.get and agents.files.set methods that allows reading and writing files outside the agent workspace. Attackers can exploit symlinked allowl...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.51 [HIGH] [CVE-2026-32014] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32014)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32014
- **指纹**：`d76f63b2eb0578b0`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contain a metadata spoofing vulnerability where reconnect platform and deviceFamily fields are accepted from the client without being bound into the device-auth signature. An attacker with a paired no...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.52 [HIGH] [CVE-2026-32015] OpenClaw 版本受影响（受影响 >=2026.1.21,<2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32015)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32015
- **指纹**：`4a60d3198ad4ca89`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions 2026.1.21 prior to 2026.2.19 contain a path hijacking vulnerability in tools.exec.safeBins that allows attackers to bypass allowlist checks by controlling process PATH resolution. Attackers who can influence the gateway...

**证据**：
  - `affected_versions`：>=2026.1.21,<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.53 [HIGH] [CVE-2026-32016] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32016)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32016
- **指纹**：`3a7d6e6fb4631489`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 on macOS contain a path validation bypass vulnerability in the exec-approval allowlist mode that allows local attackers to execute unauthorized binaries by exploiting basename-only allowlist entries. ...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.54 [HIGH] [CVE-2026-32017] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32017)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32017
- **指纹**：`824c85a9f395b484`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 contain an allowlist bypass vulnerability in the exec safeBins policy that allows attackers to write arbitrary files using short-option payloads. Attackers can bypass argument validation by attaching ...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.55 [HIGH] [CVE-2026-32019] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32019)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32019
- **指纹**：`a7c05d7dd07a8b31`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain incomplete IPv4 special-use range validation in the isPrivateIpv4() function, allowing requests to RFC-reserved ranges to bypass SSRF policy checks. Attackers with network reachability to spec...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.56 [HIGH] [CVE-2026-32023] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32023)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32023
- **指纹**：`e3635fbe556fec1a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.24 contain an approval gating bypass vulnerability in system.run allowlist mode where nested transparent dispatch wrappers can suppress shell-wrapper detection. Attackers can exploit this by chaining mul...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.57 [HIGH] [CVE-2026-32025] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32025)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32025
- **指纹**：`19e1c5b85f354dd2`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 contain an authentication hardening gap in browser-origin WebSocket clients that allows attackers to bypass origin checks and auth throttling on loopback deployments. An attacker can trick a user into...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.58 [HIGH] [CVE-2026-32030] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32030)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32030
- **指纹**：`b337f4e52431ab47`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 contain a path traversal vulnerability in the stageSandboxMedia function that accepts arbitrary absolute paths when iMessage remote attachment fetching is enabled. An attacker who can tamper with atta...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.59 [HIGH] [CVE-2026-32032] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32032)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32032
- **指纹**：`e1de0a8afebb032b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an arbitrary shell execution vulnerability in shell environment fallback that trusts the unvalidated SHELL path from the host environment. An attacker with local environment access can inject ...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.60 [HIGH] [CVE-2026-32034] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32034)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32034
- **指纹**：`6bb3120c0248570b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 contain an authentication bypass vulnerability in the Control UI when allowInsecureAuth is explicitly enabled and the gateway is exposed over plaintext HTTP, allowing attackers to bypass device identi...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.61 [HIGH] [CVE-2026-32048] OpenClaw 版本受影响（受影响 <2026.3.1，已修复 2026.3.1） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32048)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32048
- **指纹**：`cb4870054da1955c`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.1 fail to enforce sandbox inheritance during cross-agent sessions_spawn operations, allowing sandboxed sessions to create child processes under unsandboxed agents. An attacker with a sandboxed session ca...

**证据**：
  - `affected_versions`：<2026.3.1
  - `fixed_in`：2026.3.1
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.1 或更高版本

---

#### 3.0.62 [HIGH] [CVE-2026-32049] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32049)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32049
- **指纹**：`0cf5b92889685448`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 fail to consistently enforce configured inbound media byte limits before buffering remote media across multiple channel ingestion paths. Remote attackers can send oversized media payloads to trigger e...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.63 [HIGH] [CVE-2026-32051] OpenClaw 版本受影响（受影响 <2026.3.1，已修复 2026.3.1） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32051)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32051
- **指纹**：`3534112505e0756d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.1 contain an authorization mismatch vulnerability that allows authenticated callers with operator.write scope to invoke owner-only tool surfaces including gateway and cron through agent runs in scoped-to...

**证据**：
  - `affected_versions`：<2026.3.1
  - `fixed_in`：2026.3.1
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.1 或更高版本

---

#### 3.0.64 [HIGH] [CVE-2026-32055] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32055)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32055
- **指纹**：`651ee04acab70a0e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contain a path traversal vulnerability in workspace boundary validation that allows attackers to write files outside the workspace through in-workspace symlinks pointing to non-existent out-of-root ta...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.65 [HIGH] [CVE-2026-32056] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32056)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32056
- **指纹**：`81e8410dbe9b5602`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 fail to sanitize shell startup environment variables HOME and ZDOTDIR in the system.run function, allowing attackers to bypass command allowlist protections. Remote attackers can inject malicious star...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.66 [HIGH] [CVE-2026-32057] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32057)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32057
- **指纹**：`7bde148c4591314b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 contain an authentication bypass vulnerability in the trusted-proxy Control UI pairing mechanism that accepts client.id=control-ui without proper device identity verification. An authenticated node ro...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.67 [HIGH] [CVE-2026-32059] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32059)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32059
- **指纹**：`c1494a8b8c79c222`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw version 2026.2.22-2 prior to 2026.2.23 tools.exec.safeBins validation for sort command fails to properly validate GNU long-option abbreviations, allowing attackers to bypass denied-flag checks via abbreviated options. Remote att...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.68 [HIGH] [CVE-2026-32060] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32060)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32060
- **指纹**：`7531f79dced05fe2`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a path traversal vulnerability in apply_patch that allows attackers to write or delete files outside the configured workspace directory. When apply_patch is enabled without filesystem sandbox ...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.69 [HIGH] [CVE-2026-32062] OpenClaw 版本受影响（受影响 <2026.2.22, <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32062)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32062
- **指纹**：`e15f150197651ba8`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions2026.2.21-2 prior to 2026.2.22 and @openclaw/voice-call versions 2026.2.21 prior to 2026.2.22 accept media-stream WebSocket upgrades before stream validation, allowing unauthenticated clients to establish connections. Re...

**证据**：
  - `affected_versions`：<2026.2.22, <2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.70 [HIGH] [CVE-2026-32063] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32063)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32063
- **指纹**：`7173b0b8e7a82770`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw version 2026.2.19-2 prior to 2026.2.21 contains a command injection vulnerability in systemd unit file generation where attacker-controlled environment values are not validated for CR/LF characters, allowing newline injection to...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.71 [HIGH] [CVE-2026-32064] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32064)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32064
- **指纹**：`7b588e8de894a1db`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 sandbox browser entrypoint launches x11vnc without authentication for noVNC observer sessions, allowing unauthenticated access to the VNC interface. Remote attackers on the host loopback interface can...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.72 [HIGH] [CVE-2026-32302] OpenClaw 版本受影响（受影响 <2026.3.11，已修复 2026.3.11） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32302)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32302
- **指纹**：`43c793f024559b77`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to 2026.3.11, browser-originated WebSocket connections could bypass origin validation when gateway.auth.mode was set to trusted-proxy and the request arrived with proxy headers. A page served fr...

**证据**：
  - `affected_versions`：<2026.3.11
  - `fixed_in`：2026.3.11
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.11 或更高版本

---

#### 3.0.73 [HIGH] [CVE-2026-32846] OpenClaw 版本受影响（受影响 <=2026.3.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32846)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32846
- **指纹**：`4dc01d742c6ef601`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw through 2026.3.23 (fixed in commit 4797bbc) contains a path traversal vulnerability in media parsing that allows attackers to read arbitrary files by bypassing path validation in the isLikelyLocalPath() and isValidMedia() functi...

**证据**：
  - `affected_versions`：<=2026.3.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 <参见 CVE 详情> 或更高版本

---

#### 3.0.74 [HIGH] [CVE-2026-32914] OpenClaw 版本受影响（受影响 <2026.3.12，已修复 2026.3.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32914)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32914
- **指纹**：`da1843a83de3bcfe`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw before 2026.3.12 contains an insufficient access control vulnerability in the /config and /debug command handlers that allows command-authorized non-owners to access owner-only surfaces. Attackers with command authorization can ...

**证据**：
  - `affected_versions`：<2026.3.12
  - `fixed_in`：2026.3.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.12 或更高版本

---

#### 3.0.75 [HIGH] [CVE-2026-32915] OpenClaw 版本受影响（受影响 <2026.3.11，已修复 2026.3.11） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32915)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32915
- **指纹**：`b9328e8943554f04`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw before 2026.3.11 contains a sandbox boundary bypass vulnerability allowing leaf subagents to access the subagents control surface and resolve against parent requester scope instead of their own session tree. A low-privilege sand...

**证据**：
  - `affected_versions`：<2026.3.11
  - `fixed_in`：2026.3.11
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.11 或更高版本

---

#### 3.0.76 [HIGH] [CVE-2026-32918] OpenClaw 版本受影响（受影响 <2026.3.11，已修复 2026.3.11） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32918)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32918
- **指纹**：`c3342080db0dd45d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw before 2026.3.11 contains a session sandbox escape vulnerability in the session_status tool that allows sandboxed subagents to access parent or sibling session state. Attackers can supply arbitrary sessionKey values to read or m...

**证据**：
  - `affected_versions`：<2026.3.11
  - `fixed_in`：2026.3.11
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.11 或更高版本

---

#### 3.0.77 [HIGH] [CVE-2026-41349] OpenClaw 版本受影响（受影响 <2026.3.28，已修复 2026.3.28） [↗](https://www.redpacketsecurity.com/cve-alert-cve-2026-41349-openclaw-openclaw/)

NVD 置信度 `high`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-41349
- **指纹**：`6e65ecbd6b78d75b`

**描述**：config.patch silently disables execution approval

**证据**：
  - `affected_versions`：<2026.3.28
  - `fixed_in`：2026.3.28
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.28 或更高版本

---

#### 3.0.78 [MEDIUM] [CVE-2026-22168] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22168)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22168
- **指纹**：`64aedf1df7ba3203`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 contain an approval-integrity mismatch vulnerability in system.run that allows authenticated operators to execute arbitrary trailing arguments after cmd.exe /c while approval text reflects only a beni...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.79 [MEDIUM] [CVE-2026-22169] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22169)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22169
- **指纹**：`09de3ea47a431cf9`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an allowlist bypass vulnerability in the safeBins configuration that allows attackers to invoke external helpers through the compress-program option. When sort is explicitly added to tools.exe...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.80 [MEDIUM] [CVE-2026-22170] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22170)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22170
- **指纹**：`470ee15b550a98fe`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 with the optional BlueBubbles plugin contain an access control bypass vulnerability where empty allowFrom configuration causes dmPolicy pairing and allowlist restrictions to be ineffective. Remote att...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.81 [MEDIUM] [CVE-2026-22174] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22174)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22174
- **指纹**：`16073fd6ecb42fda`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 inject the x-OpenClaw-relay-token header into Chrome CDP probe traffic on loopback interfaces, allowing local processes to capture the Gateway authentication token. An attacker controlling a loopback ...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.82 [MEDIUM] [CVE-2026-22176] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22176)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22176
- **指纹**：`19b4d45ce5256662`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 contain a command injection vulnerability in Windows Scheduled Task script generation where environment variables are written to gateway.cmd using unquoted set KEY=VALUE assignments, allowing shell me...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.83 [MEDIUM] [CVE-2026-22177] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22177)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22177
- **指纹**：`d8e766b74d8b3571`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 fail to filter dangerous process-control environment variables from config env.vars, allowing startup-time code execution. Attackers can inject variables like NODE_OPTIONS or LD_* through configuratio...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.84 [MEDIUM] [CVE-2026-22178] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22178)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22178
- **指纹**：`706519b9d76d8e27`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 construct RegExp objects directly from unescaped Feishu mention metadata in the stripBotMention function, allowing regex injection and denial of service. Attackers can craft nested-quantifier patterns...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.85 [MEDIUM] [CVE-2026-22180] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-22180)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-22180
- **指纹**：`18482f1f89995af4`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 contain a path-confinement bypass vulnerability in browser output handling that allows writes outside intended root directories. Attackers can exploit insufficient canonical path-boundary validation in...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.86 [MEDIUM] [CVE-2026-26326] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26326)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26326
- **指纹**：`154e7e79a379ee84`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.14, `skills.status` could disclose secrets to `operator.read` clients by returning raw resolved config values in `configChecks` for skill `requires.config` paths. Version 2026....

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.87 [MEDIUM] [CVE-2026-26327] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26327)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26327
- **指纹**：`0e53d29187067b7d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Discovery beacons (Bonjour/mDNS and DNS-SD) include TXT records such as `lanHost`, `tailnetDns`, `gatewayPort`, and `gatewayTlsSha256`. TXT records are unauthenticated. Prior to version 2026.2.14, som...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.88 [MEDIUM] [CVE-2026-26328] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26328)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26328
- **指纹**：`bf3b7c2779876dde`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.14, under iMessage `groupPolicy=allowlist`, group authorization could be satisfied by sender identities coming from the DM pairing store, broadening DM trust into group context...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.89 [MEDIUM] [CVE-2026-26329] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26329)

NVD 置信度 `high`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26329
- **指纹**：`c0315e1db6102716`

**描述**：OpenClaw privilege escalation via crafted skill package

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.90 [MEDIUM] [CVE-2026-26972] OpenClaw 版本受影响（受影响 >=2026.1.12,<2026.2.13，已修复 2026.2.13） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-26972)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-26972
- **指纹**：`6ea57ec6519f30ef`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. In versions 2026.1.12 through 2026.2.12, OpenClaw browser download helpers accepted an unsanitized output path. When invoked via the browser control gateway routes, this allowed path traversal to writ...

**证据**：
  - `affected_versions`：>=2026.1.12,<2026.2.13
  - `fixed_in`：2026.2.13
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.13 或更高版本

---

#### 3.0.91 [MEDIUM] [CVE-2026-27003] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27003)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27003
- **指纹**：`8829e0fb4ac18b73`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Telegram bot tokens can appear in error messages and stack traces (for example, when request URLs include `https://api.telegram.org/bot<token>/...`). Prior to version 2026.2.15, OpenClaw logged these ...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.92 [MEDIUM] [CVE-2026-27004] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27004)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27004
- **指纹**：`8f25857189ae7dc0`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.15, in some shared-agent deployments, OpenClaw session tools (`sessions_list`, `sessions_history`, `sessions_send`) allowed broader session targeting than some operators intend...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.93 [MEDIUM] [CVE-2026-27008] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27008)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27008
- **指纹**：`064d3d0f99616672`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.15, a bug in `download` skill installation allowed `targetDir` values from skill frontmatter to resolve outside the per-skill tools directory if not strictly validated. In the ...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.94 [MEDIUM] [CVE-2026-27009] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27009)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27009
- **指纹**：`9a482287af8716fe`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.15, a atored XSS issue in the OpenClaw Control UI when rendering assistant identity (name/avatar) into an inline `<script>` tag without script-context-safe escaping. A crafted ...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.95 [MEDIUM] [CVE-2026-27183] OpenClaw 版本受影响（受影响 <2026.3.7，已修复 2026.3.7） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27183)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27183
- **指纹**：`9a10ca37b6917f1c`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.7 contain a shell approval gating bypass vulnerability in system.run dispatch-wrapper handling that allows attackers to skip shell wrapper approval requirements. The approval classifier and execution pla...

**证据**：
  - `affected_versions`：<2026.3.7
  - `fixed_in`：2026.3.7
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.7 或更高版本

---

#### 3.0.96 [MEDIUM] [CVE-2026-27484] OpenClaw 版本受影响（受影响 <=2026.2.17） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27484)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27484
- **指纹**：`1ca156db53c8ac80`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. In versions 2026.2.17 and below, the Discord moderation action handling (timeout, kick, ban) uses sender identity from request parameters in tool-driven flows, instead of trusted runtime sender contex...

**证据**：
  - `affected_versions`：<=2026.2.17
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 <参见 CVE 详情> 或更高版本

---

#### 3.0.97 [MEDIUM] [CVE-2026-27485] OpenClaw 版本受影响（受影响 <=2026.2.17） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27485)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27485
- **指纹**：`0502babbb827cae3`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. In versions 2026.2.17 and below, skills/skill-creator/scripts/package_skill.py (a local helper script used when authors package skills) previously followed symlinks while building .skill archives. If ...

**证据**：
  - `affected_versions`：<=2026.2.17
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 <参见 CVE 详情> 或更高版本

---

#### 3.0.98 [MEDIUM] [CVE-2026-27486] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27486)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27486
- **指纹**：`f3e49d518108fa57`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. In versions 2026.2.13 and below of the OpenClaw CLI, the process cleanup uses system-wide process enumeration and pattern matching to terminate processes without verifying if they are owned by the cur...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.99 [MEDIUM] [CVE-2026-27522] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27522)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27522
- **指纹**：`33c1136f8932a5e6`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.24 contain a local media root bypass vulnerability in sendAttachment and setGroupIcon message actions when sandboxRoot is unset. Attackers can hydrate media from local absolute paths to read arbitrary ho...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.100 [MEDIUM] [CVE-2026-27523] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27523)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27523
- **指纹**：`406f0ed2a530ca92`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.24 contain a sandbox bind validation vulnerability allowing attackers to bypass allowed-root and blocked-path checks via symlinked parent directories with non-existent leaf paths. Attackers can craft bin...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.101 [MEDIUM] [CVE-2026-27524] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27524)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27524
- **指纹**：`e2b2ff9957e275b1`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 accept prototype-reserved keys in runtime /debug set override object values, allowing prototype pollution attacks. Authorized /debug set callers can inject __proto__, constructor, or prototype keys to...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.102 [MEDIUM] [CVE-2026-27545] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27545)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27545
- **指纹**：`693465f0cef5986e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contain an approval bypass vulnerability in system.run execution that allows attackers to execute commands from unintended filesystem locations by rebinding writable parent symlinks in the current wor...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.103 [MEDIUM] [CVE-2026-27576] OpenClaw 版本受影响（受影响 <=2026.2.17） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27576)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27576
- **指纹**：`1308fafc7c15162b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. In versions 2026.2.17 and below, the ACP bridge accepts very large prompt text blocks and can assemble oversized prompt payloads before forwarding them to chat.send. Because ACP runs over local stdio,...

**证据**：
  - `affected_versions`：<=2026.2.17
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 <参见 CVE 详情> 或更高版本

---

#### 3.0.104 [MEDIUM] [CVE-2026-27646] OpenClaw 版本受影响（受影响 <2026.3.7，已修复 2026.3.7） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27646)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27646
- **指纹**：`32e6e9d255e4fc2b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.7 contain a sandbox escape vulnerability in the /acp spawn command that allows authorized sandboxed sessions to initialize host-side ACP runtime. Attackers can bypass sandbox restrictions by invoking the...

**证据**：
  - `affected_versions`：<2026.3.7
  - `fixed_in`：2026.3.7
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.7 或更高版本

---

#### 3.0.105 [MEDIUM] [CVE-2026-27670] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27670)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27670
- **指纹**：`e33650b2abb8a303`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 contain a race condition vulnerability in ZIP extraction that allows local attackers to write files outside the intended destination directory. Attackers can exploit a time-of-check-time-of-use race be...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.106 [MEDIUM] [CVE-2026-28394] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28394)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28394
- **指纹**：`12d189099bd670f3`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.15 contain a denial of service vulnerability in the web_fetch tool that allows attackers to crash the Gateway process through memory exhaustion by parsing oversized or deeply nested HTML responses. Remot...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.107 [MEDIUM] [CVE-2026-28395] OpenClaw 版本受影响（受影响 >=2026.1.14-1,<2026.2.12，已修复 2026.2.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28395)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28395
- **指纹**：`b95a7aa3629f8dc8`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw version 2026.1.14-1 prior to 2026.2.12 contain an improper network binding vulnerability in the Chrome extension (must be installed and enabled) relay server that treats wildcard hosts as loopback addresses, allowing the relay H...

**证据**：
  - `affected_versions`：>=2026.1.14-1,<2026.2.12
  - `fixed_in`：2026.2.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.12 或更高版本

---

#### 3.0.108 [MEDIUM] [CVE-2026-28449] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28449)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28449
- **指纹**：`770c75084d59f6d9`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 lack durable replay state for Nextcloud Talk webhook events, allowing valid signed webhook requests to be replayed without suppression. Attackers can capture and replay previously valid signed webhook...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.109 [MEDIUM] [CVE-2026-28450] OpenClaw 版本受影响（受影响 <2026.2.12，已修复 2026.2.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28450)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28450
- **指纹**：`e9ba8ddd258f2f64`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.12 with the optional Nostr plugin enabled expose unauthenticated HTTP endpoints at /api/channels/nostr/:accountId/profile and /api/channels/nostr/:accountId/profile/import that allow reading and modifyin...

**证据**：
  - `affected_versions`：<2026.2.12
  - `fixed_in`：2026.2.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.12 或更高版本

---

#### 3.0.110 [MEDIUM] [CVE-2026-28452] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28452)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28452
- **指纹**：`5dd6009c05411ece`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a denial of service vulnerability in the extractArchive function within src/infra/archive.ts that allows attackers to consume excessive CPU, memory, and disk resources through high-expansion Z...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.111 [MEDIUM] [CVE-2026-28457] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28457)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28457
- **指纹**：`9e1399b9e74cd074`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a path traversal vulnerability in sandbox skill mirroring (must be enabled) that uses the skill frontmatter name parameter unsanitized when copying skills into the sandbox workspace. Attackers...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.112 [MEDIUM] [CVE-2026-28464] OpenClaw 版本受影响（受影响 <2026.2.12，已修复 2026.2.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28464)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28464
- **指纹**：`369c83610eaf9179`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.12 use non-constant-time string comparison for hook token validation, allowing attackers to infer tokens through timing measurements. Remote attackers with network access to the hooks endpoint can exploi...

**证据**：
  - `affected_versions`：<2026.2.12
  - `fixed_in`：2026.2.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.12 或更高版本

---

#### 3.0.113 [MEDIUM] [CVE-2026-28475] OpenClaw 版本受影响（受影响 <2026.2.13，已修复 2026.2.13） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28475)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28475
- **指纹**：`c81a44ff719b2c99`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.13 use non-constant-time string comparison for hook token validation, allowing attackers to infer tokens through timing measurements. Remote attackers with network access to the hooks endpoint can exploi...

**证据**：
  - `affected_versions`：<2026.2.13
  - `fixed_in`：2026.2.13
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.13 或更高版本

---

#### 3.0.114 [MEDIUM] [CVE-2026-28480] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28480)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28480
- **指纹**：`464097f171dba26c`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain an authorization bypass vulnerability where Telegram allowlist matching accepts mutable usernames instead of immutable numeric sender IDs. Attackers can spoof identity by obtaining recycled us...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.115 [MEDIUM] [CVE-2026-28486] OpenClaw 版本受影响（受影响 >=2026.1.20,<2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-28486)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-28486
- **指纹**：`b4dda2379b914554`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions 2026.1.16-2 prior to 2026.2.14 contain a path traversal vulnerability in archive extraction during installation commands that allows arbitrary file writes outside the intended directory. Attackers can craft malicious ar...

**证据**：
  - `affected_versions`：>=2026.1.20,<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.116 [MEDIUM] [CVE-2026-29606] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29606)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-29606
- **指纹**：`8a15f54180cb5d8a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 contain a webhook signature-verification bypass in the voice-call extension that allows unauthenticated requests when the tunnel.allowNgrokFreeTierLoopbackBypass option is explicitly enabled. An exter...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.117 [MEDIUM] [CVE-2026-29607] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29607)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-29607
- **指纹**：`af118c359885330b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an authorization bypass vulnerability in allow-always wrapper persistence that allows attackers to bypass approval checks by persisting wrapper-level allowlist entries instead of validating in...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.118 [MEDIUM] [CVE-2026-29612] OpenClaw 版本受影响（受影响 <2026.2.14，已修复 2026.2.14） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29612)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-29612
- **指纹**：`1f7ce6dbae576324`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.14 decode base64-backed media inputs into buffers before enforcing decoded-size budget limits, allowing attackers to trigger large memory allocations. Remote attackers can supply oversized base64 payload...

**证据**：
  - `affected_versions`：<2026.2.14
  - `fixed_in`：2026.2.14
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.14 或更高版本

---

#### 3.0.119 [MEDIUM] [CVE-2026-29613] OpenClaw 版本受影响（受影响 <2026.2.12，已修复 2026.2.12） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-29613)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-29613
- **指纹**：`1a983d6447af1e1f`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.12 contain a vulnerability in the BlueBubbles (optional plugin) webhook handler in which it authenticates requests based solely on loopback remoteAddress without validating forwarding headers, allowing b...

**证据**：
  - `affected_versions`：<2026.2.12
  - `fixed_in`：2026.2.12
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.12 或更高版本

---

#### 3.0.120 [MEDIUM] [CVE-2026-31990] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31990)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31990
- **指纹**：`848e3203edb4c559`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 contain a vulnerability in the stageSandboxMedia function in which it fails to validate destination symlinks during media staging, allowing writes to follow symlinks outside the sandbox workspace. Atta...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.121 [MEDIUM] [CVE-2026-31993] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31993)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31993
- **指纹**：`d4e85b1c1f7d0c25`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an allowlist parsing mismatch vulnerability in the macOS companion app that allows authenticated operators to bypass exec approval checks. Attackers with operator.write privileges and a paired...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.122 [MEDIUM] [CVE-2026-31995] OpenClaw 版本受影响（受影响 >=2026.1.21,<2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31995)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31995
- **指纹**：`20028d8baacf0deb`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions 2026.1.21 prior to 2026.2.19 contain a command injection vulnerability in the Lobster extension's Windows shell fallback mechanism that allows attackers to inject arbitrary commands through tool-provided arguments. When...

**证据**：
  - `affected_versions`：>=2026.1.21,<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.123 [MEDIUM] [CVE-2026-31996] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31996)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31996
- **指纹**：`b54488ffaa0839ef`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 tools.exec.safeBins contains an input validation bypass vulnerability that allows attackers to execute unintended filesystem operations through sort output flags or recursive grep flags. Attackers wit...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.124 [MEDIUM] [CVE-2026-31997] OpenClaw 版本受影响（受影响 <2026.3.1，已修复 2026.3.1） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31997)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31997
- **指纹**：`26b6122d16b0f778`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.1 fail to pin executable identity for non-path-like argv[0] tokens in system.run approvals, allowing post-approval executable rebind attacks. Attackers can modify PATH resolution after approval to execut...

**证据**：
  - `affected_versions`：<2026.3.1
  - `fixed_in`：2026.3.1
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.1 或更高版本

---

#### 3.0.125 [MEDIUM] [CVE-2026-32001] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32001)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32001
- **指纹**：`4d9f3f6c05a8689b`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an authentication bypass vulnerability that allows clients authenticated with a shared gateway token to connect as role=node without device identity verification. Attackers can exploit this by...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.126 [MEDIUM] [CVE-2026-32002] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32002)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32002
- **指纹**：`74e256b17b353fd1`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.23 contain a sandbox bypass vulnerability in the sandboxed image tool that fails to enforce tools.fs.workspaceOnly restrictions on mounted sandbox paths, allowing attackers to read out-of-workspace files...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.127 [MEDIUM] [CVE-2026-32003] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32003)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32003
- **指纹**：`37c782820f2b40b4`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an environment variable injection vulnerability in the system.run function that allows attackers to bypass command allowlist restrictions via SHELLOPTS and PS4 environment variables. An attack...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.128 [MEDIUM] [CVE-2026-32004] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32004)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32004
- **指纹**：`379b30e180e8d5ec`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 contain an authentication bypass vulnerability in the /api/channels route classification due to canonicalization depth mismatch between auth-path classification and route-path canonicalization. Attacke...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.129 [MEDIUM] [CVE-2026-32005] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32005)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32005
- **指纹**：`c3c5cd4b84765af0`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 fail to enforce sender authorization checks for interactive callbacks including block_action, view_submission, and view_closed in shared workspace deployments. Unauthorized workspace members can bypas...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.130 [MEDIUM] [CVE-2026-32007] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32007)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32007
- **指纹**：`8b4066fd0fe3c331`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.23 contain a path traversal vulnerability in the experimental apply_patch tool that allows attackers with sandbox access to modify files outside the workspace directory by exploiting inconsistent enforce...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.131 [MEDIUM] [CVE-2026-32008] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32008)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32008
- **指纹**：`39df8f929a12122c`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 contain an improper URL scheme validation vulnerability in the assertBrowserNavigationAllowed() function that allows authenticated users with browser-tool access to navigate to file:// URLs. Attackers...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.132 [MEDIUM] [CVE-2026-32009] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32009)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32009
- **指纹**：`a8f6629ebcacb44e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.24 contain a policy bypass vulnerability in the safeBins allowlist evaluation that trusts static default directories including writable package-manager paths like /opt/homebrew/bin and /usr/local/bin. An...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.133 [MEDIUM] [CVE-2026-32010] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32010)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32010
- **指纹**：`5f764cfb1e5b73b3`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an allowlist bypass vulnerability in the safe-bin configuration when sort is manually added to tools.exec.safeBins. Attackers can invoke sort with the --compress-program flag to execute arbitr...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.134 [MEDIUM] [CVE-2026-32021] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32021)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32021
- **指纹**：`0c32fbcbca811a12`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an authorization bypass vulnerability in the Feishu allowFrom allowlist implementation that accepts mutable sender display names instead of enforcing ID-only matching. An attacker can set a di...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.135 [MEDIUM] [CVE-2026-32022] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32022)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32022
- **指纹**：`abd2b98addae6d69`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 contain a stdin-only policy bypass vulnerability in the grep tool within tools.exec.safeBins that allows attackers to read arbitrary files by supplying a pattern via the -e flag parameter. Attackers c...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.136 [MEDIUM] [CVE-2026-32024] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32024)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32024
- **指纹**：`17cfeb6f614af764`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain a symlink traversal vulnerability in avatar handling that allows attackers to read arbitrary files outside the configured workspace boundary. Remote attackers can exploit this by requesting av...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.137 [MEDIUM] [CVE-2026-32026] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32026)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32026
- **指纹**：`dc9a1c91af9feefb`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.24 contain an improper path validation vulnerability in sandbox media handling that allows absolute paths under the host temporary directory outside the active sandbox root. Attackers can exploit this by...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.138 [MEDIUM] [CVE-2026-32027] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32027)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32027
- **指纹**：`17a6e083ec85b98a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contain an authorization bypass vulnerability where DM pairing-store identities are incorrectly eligible for group allowlist authorization checks. Attackers can exploit this cross-context authorizatio...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.139 [MEDIUM] [CVE-2026-32028] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32028)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32028
- **指纹**：`0408ffb4672a9393`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 fail to enforce dmPolicy and allowFrom authorization checks on Discord direct-message reaction notifications, allowing non-allowlisted users to enqueue reaction-derived system events. Attackers can ex...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.140 [MEDIUM] [CVE-2026-32029] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32029)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32029
- **指纹**：`340decd5c13262cc`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 improperly parse the left-most X-Forwarded-For header value when requests originate from configured trusted proxies, allowing attackers to spoof client IP addresses. In proxy chains that append or pre...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.141 [MEDIUM] [CVE-2026-32031] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32031)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32031
- **指纹**：`58aa715fdee69aff`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 server-http contains an authentication bypass vulnerability in gateway authentication for plugin channel endpoints due to path canonicalization mismatch between the gateway guard and plugin handler ro...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.142 [MEDIUM] [CVE-2026-32033] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32033)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32033
- **指纹**：`8e288cbca8448382`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.24 contain a path traversal vulnerability where @-prefixed absolute paths bypass workspace-only file-system boundary validation due to canonicalization mismatch. Attackers can exploit this by crafting @-...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.143 [MEDIUM] [CVE-2026-32035] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32035)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32035
- **指纹**：`bee11dd40f43d67a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 fail to pass the senderIsOwner flag when processing Discord voice transcripts in agentCommand, causing the flag to default to true. Non-owner voice participants can exploit this omission to access owne...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.144 [MEDIUM] [CVE-2026-32036] OpenClaw 版本受影响（受影响 <2026.2.6，已修复 2026.2.6） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32036)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32036
- **指纹**：`12942ebe58ffa5a2`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw gateway plugin versions prior to 2026.2.26 contain a path traversal vulnerability that allows remote attackers to bypass route authentication checks by manipulating /api/channels paths with encoded dot-segment traversal sequence...

**证据**：
  - `affected_versions`：<2026.2.6
  - `fixed_in`：2026.2.6
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.6 或更高版本

---

#### 3.0.145 [MEDIUM] [CVE-2026-32037] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32037)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32037
- **指纹**：`b30c1088fcabc505`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 fail to consistently validate redirect chains against configured mediaAllowHosts allowlists during MSTeams media downloads. Attackers can supply or influence attachment URLs to force redirects to non-...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.146 [MEDIUM] [CVE-2026-32039] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32039)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32039
- **指纹**：`a40a16df0014a646`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain an authorization bypass vulnerability in the toolsBySender group policy matching that allows attackers to inherit elevated tool permissions through identifier collision attacks. Attackers can ...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.147 [MEDIUM] [CVE-2026-32040] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32040)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32040
- **指纹**：`653578298f386d6e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.23 contain an html injection vulnerability in the HTML session exporter that allows attackers to execute arbitrary javascript by injecting malicious mimeType values in image content blocks. Attackers can...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.148 [MEDIUM] [CVE-2026-32041] OpenClaw 版本受影响（受影响 <2026.3.1，已修复 2026.3.1） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32041)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32041
- **指纹**：`542c8d9200f41b58`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.1 fail to properly handle authentication bootstrap errors during startup, allowing browser-control routes to remain accessible without authentication. Local processes or loopback-reachable SSRF paths can...

**证据**：
  - `affected_versions`：<2026.3.1
  - `fixed_in`：2026.3.1
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.1 或更高版本

---

#### 3.0.149 [MEDIUM] [CVE-2026-32043] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32043)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32043
- **指纹**：`b86282730426061e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 contain a time-of-check-time-of-use vulnerability in approval-bound system.run execution where the cwd parameter is validated at approval time but resolved at execution time. Attackers can retarget a ...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.150 [MEDIUM] [CVE-2026-32044] OpenClaw 版本受影响（受影响 <2026.3.2，已修复 2026.3.2） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32044)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32044
- **指纹**：`e9d9cf85507b76d8`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.3.2 contain an archive extraction vulnerability in the tar.bz2 installer path that bypasses safety checks enforced on other archive formats. Attackers can craft malicious tar.bz2 skill archives to bypass s...

**证据**：
  - `affected_versions`：<2026.3.2
  - `fixed_in`：2026.3.2
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.2 或更高版本

---

#### 3.0.151 [MEDIUM] [CVE-2026-32045] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32045)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32045
- **指纹**：`fefd311d9ddb7e3e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 incorrectly apply tokenless Tailscale header authentication to HTTP gateway routes, allowing bypass of token and password requirements. Attackers on trusted networks can exploit this misconfiguration ...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.152 [MEDIUM] [CVE-2026-32046] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32046)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32046
- **指纹**：`52cfa8be9796aef1`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 contain an improper sandbox configuration vulnerability that allows attackers to execute arbitrary code by exploiting renderer-side vulnerabilities without requiring a sandbox escape. Attackers can le...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.153 [MEDIUM] [CVE-2026-32052] OpenClaw 版本受影响（受影响 <2026.2.24，已修复 2026.2.24） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32052)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32052
- **指纹**：`bb755f7c128f5799`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.24 contain a command injection vulnerability in the system.run shell-wrapper that allows attackers to execute hidden commands by injecting positional argv carriers after inline shell payloads. Attackers ...

**证据**：
  - `affected_versions`：<2026.2.24
  - `fixed_in`：2026.2.24
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.24 或更高版本

---

#### 3.0.154 [MEDIUM] [CVE-2026-32053] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32053)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32053
- **指纹**：`557899f808678f7d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.23 contain a vulnerability in Twilio webhook event deduplication where normalized event IDs are randomized per parse, allowing replay events to bypass manager dedupe checks. Attackers can replay Twilio w...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.155 [MEDIUM] [CVE-2026-32054] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32054)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32054
- **指纹**：`ba70e96bb5ce3266`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 contain a symlink traversal vulnerability in browser trace and download output path handling that allows local attackers to escape the managed temp root directory. An attacker with local access can cr...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.156 [MEDIUM] [CVE-2026-32061] OpenClaw 版本受影响（受影响 <2026.2.17，已修复 2026.2.17） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32061)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32061
- **指纹**：`85d2189e58ee7df5`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.17 contain a path traversal vulnerability in the $include directive resolution that allows reading arbitrary local files outside the config directory boundary. Attackers with config modification capabili...

**证据**：
  - `affected_versions`：<2026.2.17
  - `fixed_in`：2026.2.17
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.17 或更高版本

---

#### 3.0.157 [MEDIUM] [CVE-2026-32065] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32065)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32065
- **指纹**：`dae20cb911ba4255`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 contain an approval-integrity bypass vulnerability in system.run where rendered command text is used as approval identity while trimming argv token whitespace, but runtime execution uses raw argv. An ...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.158 [MEDIUM] [CVE-2026-32895] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32895)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32895
- **指纹**：`27330c9634491a2a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 fail to enforce sender authorization in member and message subtype system event handlers, allowing unauthorized events to be enqueued. Attackers can bypass Slack DM allowlists and per-channel user all...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.159 [MEDIUM] [CVE-2026-32896] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32896)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32896
- **指纹**：`c1764822037fddaf`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.21 BlueBubbles webhook handler contains a passwordless fallback authentication path that allows unauthenticated webhook events in certain reverse-proxy or local routing configurations. Attackers can bypa...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.160 [MEDIUM] [CVE-2026-32898] OpenClaw 版本受影响（受影响 <2026.2.23，已修复 2026.2.23） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32898)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32898
- **指纹**：`98e1ae983942be43`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.23 contain an authorization bypass vulnerability in the ACP client that auto-approves tool calls based on untrusted toolCall.kind metadata and permissive name heuristics. Attackers can bypass interactive...

**证据**：
  - `affected_versions`：<2026.2.23
  - `fixed_in`：2026.2.23
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.23 或更高版本

---

#### 3.0.161 [MEDIUM] [CVE-2026-32899] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32899)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32899
- **指纹**：`12389a7edaebc1b0`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 fail to consistently apply sender-policy checks to reaction_* and pin_* non-message events before adding them to system-event context. Attackers can bypass configured DM policies and channel user allo...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.162 [MEDIUM] [CVE-2026-32919] OpenClaw 版本受影响（受影响 <2026.3.11，已修复 2026.3.11） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32919)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32919
- **指纹**：`6089fa3e3db480e8`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw before 2026.3.11 contains an authorization bypass vulnerability allowing write-scoped callers to reach admin-only session reset logic. Attackers with operator.write scope can issue agent requests containing /new or /reset slash ...

**证据**：
  - `affected_versions`：<2026.3.11
  - `fixed_in`：2026.3.11
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.11 或更高版本

---

#### 3.0.163 [MEDIUM] [CVE-2026-32923] OpenClaw 版本受影响（受影响 <2026.3.11，已修复 2026.3.11） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32923)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32923
- **指纹**：`f519f81e543ffe6e`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw before 2026.3.11 contains an authorization bypass vulnerability in Discord guild reaction ingestion that fails to enforce member users and roles allowlist checks. Non-allowlisted guild members can trigger reaction events accepte...

**证据**：
  - `affected_versions`：<2026.3.11
  - `fixed_in`：2026.3.11
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.3.11 或更高版本

---

#### 3.0.164 [MEDIUM] [CVE-2026-4039] OpenClaw 版本受影响（受影响 <2026.2.21，已修复 2026.2.21） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-4039)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-4039
- **指纹**：`de4b7d22cbfdff30`

**描述**（来源：NVD seed，未经本地翻译）：

> A vulnerability was determined in OpenClaw 2026.2.19-2. This vulnerability affects the function applySkillConfigenvOverrides of the component Skill Env Handler. Executing a manipulation can lead to code injection. It is possible to launc...

**证据**：
  - `affected_versions`：<2026.2.21
  - `fixed_in`：2026.2.21
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.21 或更高版本

---

#### 3.0.165 [LOW] [CVE-2026-27007] OpenClaw 版本受影响（受影响 <2026.2.15，已修复 2026.2.15） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-27007)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-27007
- **指纹**：`635ca4bfac8ccbce`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw is a personal AI assistant. Prior to version 2026.2.15, `normalizeForHash` in `src/agents/sandbox/config-hash.ts` recursively sorted arrays that contained only primitive values. This made order-sensitive sandbox configuration ar...

**证据**：
  - `affected_versions`：<2026.2.15
  - `fixed_in`：2026.2.15
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.15 或更高版本

---

#### 3.0.166 [LOW] [CVE-2026-31991] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-31991)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-31991
- **指纹**：`0751abe1fcec00c4`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contain an authorization bypass vulnerability where Signal group allowlist policy incorrectly accepts sender identities from DM pairing-store approvals. Attackers can exploit this boundary weakness by...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.167 [LOW] [CVE-2026-32006] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32006)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32006
- **指纹**：`c32ac2271c8e6ed7`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contain an authorization bypass vulnerability where DM pairing-store identities are incorrectly treated as group allowlist identities when dmPolicy=pairing and groupPolicy=allowlist. Remote attackers ...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.168 [LOW] [CVE-2026-32018] OpenClaw 版本受影响（受影响 <2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32018)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32018
- **指纹**：`f3cf23e1ae05d16a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.19 contain a race condition vulnerability in concurrent updateRegistry and removeRegistryEntry operations for sandbox containers and browsers. Attackers can exploit unsynchronized read-modify-write opera...

**证据**：
  - `affected_versions`：<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

#### 3.0.169 [LOW] [CVE-2026-32020] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32020)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32020
- **指纹**：`555046c76939374a`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 contain a path traversal vulnerability in the static file handler that follows symbolic links, allowing out-of-root file reads. Attackers can place symlinks under the Control UI root directory to bypa...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.170 [LOW] [CVE-2026-32050] OpenClaw 版本受影响（受影响 <2026.2.25，已修复 2026.2.25） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32050)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32050
- **指纹**：`f4668984a380bfad`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.25 contain an access control vulnerability in signal reaction notification handling that allows unauthorized senders to enqueue status events before authorization checks are applied. Attackers can exploi...

**证据**：
  - `affected_versions`：<2026.2.25
  - `fixed_in`：2026.2.25
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.25 或更高版本

---

#### 3.0.171 [LOW] [CVE-2026-32058] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32058)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32058
- **指纹**：`38bd95e65d8a204d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contain an approval context-binding weakness in system.run execution flows with host=node that allows reuse of previously approved requests with modified environment variables. Attackers with access t...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.172 [LOW] [CVE-2026-32067] OpenClaw 版本受影响（受影响 <2026.2.26，已修复 2026.2.26） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32067)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32067
- **指纹**：`6d73bae46bdd5153`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.26 contains an authorization bypass vulnerability in the pairing-store access control for direct message pairing policy that allows attackers to reuse pairing approvals across multiple accounts. An attac...

**证据**：
  - `affected_versions`：<2026.2.26
  - `fixed_in`：2026.2.26
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.26 或更高版本

---

#### 3.0.173 [LOW] [CVE-2026-32897] OpenClaw 版本受影响（受影响 <2026.2.22，已修复 2026.2.22） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-32897)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-32897
- **指纹**：`99c7cfe237a8859d`

**描述**（来源：NVD seed，未经本地翻译）：

> OpenClaw versions prior to 2026.2.22 reuse gateway.auth.token as a fallback hash secret for owner-ID prompt obfuscation when commands.ownerDisplay is set to hash and commands.ownerDisplaySecret is unset, creating dual-use of authenticati...

**证据**：
  - `affected_versions`：<2026.2.22
  - `fixed_in`：2026.2.22
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.22 或更高版本

---

#### 3.0.174 [LOW] [CVE-2026-4040] OpenClaw 版本受影响（受影响 >=2026.2.0,<2026.2.19，已修复 2026.2.19） [↗](https://nvd.nist.gov/vuln/detail/CVE-2026-4040)

NVD 置信度 `medium`

- **检查项**：`version_patch`
- **威胁引用**：TI-OPENCLAW-CVE-2026-4040
- **指纹**：`6aed17c95ae55a68`

**描述**（来源：NVD seed，未经本地翻译）：

> A vulnerability was identified in OpenClaw up to 2026.2.17. This issue affects the function tools.exec.safeBins of the component File Existence Handler. The manipulation leads to information exposure through discrepancy. The attack needs...

**证据**：
  - `affected_versions`：>=2026.2.0,<2026.2.19
  - `fixed_in`：2026.2.19
  - `running_version`：2026.2.3.post1

**修复建议**：升级到 2026.2.19 或更高版本

---

</details>

### 3.1 🔴 严重（critical） —— 2 条

#### 3.1.1 [CRITICAL] Open groupPolicy with elevated tools enabled

- **检查项**：`native_audit`
- **威胁引用**：—
- **指纹**：`793f928447a7e03d`

**修复建议**：Set groupPolicy="allowlist" and keep elevated allowlists extremely tight.

---

#### 3.1.2 [CRITICAL] Discord security warning

- **检查项**：`native_audit`
- **威胁引用**：—
- **指纹**：`bdf29b5b578ceefb`

---

### 3.2 🟡 中（medium） —— 5 条

#### 3.2.1 [MEDIUM] Reverse proxy headers are not trusted

- **检查项**：`native_audit`
- **威胁引用**：—
- **指纹**：`def71f6163c875a8`

**修复建议**：Set gateway.trustedProxies to your proxy IPs or keep the Control UI local-only.

---

#### 3.2.2 [MEDIUM] 未在白名单的监听端口：18790/tcp（34.208.65.73）

- **检查项**：`exposure_scan`
- **威胁引用**：TI-OPENCLAW-EXPOSURE
- **指纹**：`433261e50adb29fa`

**描述**：34.208.65.73 的 18790/tcp 端口接受了来自评估方的 TCP 连接，且不在白名单 [22, 18789] 中。

**证据**：
  - `host`：34.208.65.73
  - `port`：18790
  - `transport`：tcp

**修复建议**：若 18790 端口确为预期暴露，请将其加入 `exposure_scan.allowlist`；否则请关闭该端口，或在防火墙上屏蔽来自评估方网络位置的访问。

---

#### 3.2.3 [MEDIUM] 未在白名单的监听端口：8443/tcp（34.208.65.73）

- **检查项**：`exposure_scan`
- **威胁引用**：TI-OPENCLAW-EXPOSURE
- **指纹**：`f0b4a5253dda7c5c`

**描述**：34.208.65.73 的 8443/tcp 端口接受了来自评估方的 TCP 连接，且不在白名单 [22, 18789] 中。

**证据**：
  - `host`：34.208.65.73
  - `port`：8443
  - `transport`：tcp

**修复建议**：若 8443 端口确为预期暴露，请将其加入 `exposure_scan.allowlist`；否则请关闭该端口，或在防火墙上屏蔽来自评估方网络位置的访问。

---

#### 3.2.4 [MEDIUM] 未在白名单的监听端口：80/tcp（34.208.65.73）

- **检查项**：`exposure_scan`
- **威胁引用**：TI-OPENCLAW-EXPOSURE
- **指纹**：`862494da0d246d21`

**描述**：34.208.65.73 的 80/tcp 端口接受了来自评估方的 TCP 连接，且不在白名单 [22, 18789] 中。

**证据**：
  - `host`：34.208.65.73
  - `port`：80
  - `transport`：tcp

**修复建议**：若 80 端口确为预期暴露，请将其加入 `exposure_scan.allowlist`；否则请关闭该端口，或在防火墙上屏蔽来自评估方网络位置的访问。

---

#### 3.2.5 [MEDIUM] 未在白名单的监听端口：443/tcp（34.208.65.73）

- **检查项**：`exposure_scan`
- **威胁引用**：TI-OPENCLAW-EXPOSURE
- **指纹**：`e8f41064707f9ada`

**描述**：34.208.65.73 的 443/tcp 端口接受了来自评估方的 TCP 连接，且不在白名单 [22, 18789] 中。

**证据**：
  - `host`：34.208.65.73
  - `port`：443
  - `transport`：tcp

**修复建议**：若 443 端口确为预期暴露，请将其加入 `exposure_scan.allowlist`；否则请关闭该端口，或在防火墙上屏蔽来自评估方网络位置的访问。

---

### 3.3 ⚪ 信息（info） —— 2 条

#### 3.3.1 [INFO] Attack surface summary

- **检查项**：`native_audit`
- **威胁引用**：—
- **指纹**：`2ce507454dcc40cf`

---

#### 3.3.2 [INFO] active_test canary oc-active-canary-01：chat 端点返回 HTTP 405（端点未对外暴露）

- **检查项**：`active_test`
- **威胁引用**：—
- **指纹**：`ad7255792afac2b0`

**描述**：审计目标的 OpenClaw chat-completions 端点返回 HTTP 405，意味着该端点未对外暴露（例如 `gateway.http.endpoints.chatCompletions.enabled`保持默认关闭）。canary 无法通过关闭的端点评估模型行为；这是部署形态记录，不是 prompt 注入信号。

**证据**：
  - `status_code`：405
  - `test_id`：oc-active-canary-01
  - `via`：ssh-local-forward

**修复建议**：若 chat-completions 端点关闭是预期行为，无需处理。如希望启用 active_test 覆盖，请在 openclaw.json 里设置 `gateway.http.endpoints.chatCompletions.enabled = true`。

---

## 4. 未执行 / 不适用的检查

| 检查项 | 状态 | 原因 |
|--------|------|------|
| `config_audit` | not_applicable | config_audit：当前 OpenClaw 版本不支持 `config show --json`（旧版人类可读输出尚未解析） |

## 5. 错误

_本次运行未产生 check 级错误。_

## 附录 A：机读元数据

<!-- meta:profile value:linux -->
<!-- meta:remote_home value:/home/ubuntu -->
<!-- check:config_audit status:not_applicable reason:config_audit：当前 OpenClaw 版本不支持 `config show --json`（旧版人类可读输出尚未解析） -->
<!-- meta:errors count:0 -->
<!-- meta:findings_total count:183 -->
<!-- meta:findings_critical count:10 -->
<!-- meta:findings_high count:69 -->
<!-- meta:findings_medium count:92 -->
<!-- meta:findings_low count:10 -->
<!-- meta:findings_info count:2 -->

