# Real-machine sample — Lightsail prod, 2026-05-07

This directory holds the artifacts of an `agentsec server-audit` run
against the Lightsail prod instance hosting OpenClaw `2026.2.3.post1`.
It complements [`docs/samples/report-2026-04-28/`](../report-2026-04-28/)
(mock pipeline) by showing what the renderer produces under realistic
**183-finding** scale — including the §3.0 `version_patch` CVE
overview table, the SVG severity pie + legend, the heuristic attack
paths, and the multi-CVE priority list. Useful as a reviewer
reference when the renderer evolves.

## What was evaluated

- **Target:** `34.208.65.73` (Lightsail prod), Linux, OpenClaw running
  under `systemd --user` (`LINUX_USER_MODE`); `openclaw 2026.2.3.post1`.
- **Authorization:** `signature_mode: none` → run flagged
  `LOW_ASSURANCE`.
- **Checks executed:** all 10 (`native_audit`, `config_audit`,
  `version_patch`, `active_test`, `exposure_scan`, `filesystem`,
  `process_forensics`, `credential_audit`, `plugin_static`,
  `log_review`); `config_audit` reported `not_applicable` (the running
  OpenClaw version doesn't expose `config show --json`).
- **Result:** 183 findings — 10 critical / 69 high / 92 medium /
  10 low / 2 info. 174 of those are `version_patch` CVE matches
  against the unpatched 2026.2.3.post1 build.

## Files

| File | Purpose |
|------|---------|
| `server-audit-report.md` | The full Markdown report (4150 lines) — §1 audit target + topology, §2 risk pie + attack paths + priority list + check matrix, §3 details with `version_patch` CVE overview folded in `<details>`. |
| `findings.json` | Machine-readable findings (one entry per finding, with `check` / `severity` / `title` / `description` / `evidence` / `remediation` / `threat_refs` / `fingerprint`). |
| `audit-log.jsonl` | One JSON line per non-rejected SSH command — sha256 of rendered argv only, no raw command strings (spec §6.1). |

## How to regenerate the report from `findings.json`

Run renderer changes against this committed `findings.json` to see how
they look on real-scale data without re-running SSH:

```python
import json
from pathlib import Path
from agentsec.audit.findings import Finding
from agentsec.audit.checks.base import CheckStatus
from agentsec.audit.server_audit import ServerAuditReport
from agentsec.reports.markdown import render_server_audit_report, TargetDescriptor

raw = json.loads(Path("docs/samples/report-prod-2026-05-07/findings.json").read_text())
findings = [Finding(**f) for f in raw]
statuses = {"config_audit": CheckStatus()}
statuses["config_audit"].not_applicable(
    "config_audit：当前 OpenClaw 版本不支持 `config show --json`（旧版人类可读输出尚未解析）"
)
report = ServerAuditReport(findings=findings, statuses=statuses, errors={})
target = TargetDescriptor(
    host="34.208.65.73", user="ubuntu",
    key_path="~/.ssh/lightsail-prod.pem",
    auth_file="./AUTHORIZATION-lightsail-prod.txt",
    openclaw_bin="/home/ubuntu/.local/bin/openclaw",
    checks_run=("native_audit", "config_audit", "version_patch",
                "active_test", "exposure_scan", "filesystem",
                "process_forensics", "credential_audit",
                "plugin_static", "log_review"),
)
print(render_server_audit_report(
    report, profile_name="linux", remote_home="/home/ubuntu",
    low_assurance=True, target=target,
))
```

This sample is **not** under the drift-guard test (unlike
`report-2026-04-28/`) — it's intentionally a snapshot of one specific
real run, refreshed manually when something interesting changes about
the target.

## What's deliberately NOT redacted

- **Target IP / SSH user / key path / OpenClaw bin path / report
  generation timestamp** — already public-equivalent metadata for a
  short-lived dev instance the project owner controls.
- **CVE list and version_patch verdict** — these are public NVD CVEs
  applicable to the fixed `2026.2.3.post1` running version; nothing
  beyond what the NVD entries already say.
- **Audit log SHA-256 hashes** — the spec §6.1 design assumption is
  that hashes are safe to ship.
