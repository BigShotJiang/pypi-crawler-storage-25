# 服务器安全审计报告

## 目录

1. [报告概览](#1-报告概览)
2. [执行摘要](#2-执行摘要)
3. [详细发现](#3-详细发现)
4. [未执行 / 不适用的检查](#4-未执行--不适用的检查)
5. [错误](#5-错误)
6. [附录 A：机读元数据](#附录-a机读元数据)

## 1. 报告概览

### 1.1 审计目标

| 字段 | 值 |
|------|------|
| 目标主机 | `stub-host` |
| SSH 登录用户 | `u` |
| SSH 私钥路径 | `<tmp>/fake_key` |
| 平台 profile | `linux` |
| 远端 $HOME | `/home/u` |
| AUTHORIZATION 文件 | `<tmp>/AUTHORIZATION.txt` |
| 信任级别 | **LOW_ASSURANCE** |
| 服务器审计得分 | **91** / 100 |
| Finding 总数 | **2** |
| 报告生成时间 | <stripped> |

> ⚠️ **LOW_ASSURANCE**：本次审计 AUTHORIZATION.txt 的 `signature_mode=none` 或 `identity_assertion` 为空，信任链强度低于 HMAC + 身份断言双因素的标准模式。

### 1.2 审计方法

- **远程通道**：通过 SSH 仅以白名单 argv 调用只读命令；每条 argv 必须通过 `CommandPolicy.validate(argv)` —— `ssh_policy.yaml` 列举每个 check 允许的命令模板，参数与路径由 `PathMatcher` 校验
- **审计日志**：每条调用的 SHA-256 + 拒绝原因写入 `audit-log.jsonl`，命令字面值与 argv 中的敏感参数不持久化
- **HMAC 授权**：`AUTHORIZATION.txt` 用 HMAC-SHA256 + 身份断言绑定本次目标主机与输出路径，确保审计执行链可溯源
- **本次执行 35 项 check**：`native_audit`、`config_audit`、`version_patch`、`active_test`、`exposure_scan`、`filesystem`、`process_forensics`、`credential_audit`、`plugin_static`、`log_review`、`sysctl_audit`、`sshd_config_audit`、`sudoers_audit`、`suid_audit`、`world_writable_audit`、`auditd_rules_audit`、`systemd_service_blacklist`、`systemd_unit_lint`、`iptables_audit`、`nftables_audit`、`ufw_audit`、`firewalld_audit`、`docker_daemon_audit`、`docker_runtime_audit`、`docker_image_cve`、`podman_daemon_audit`、`podman_runtime_audit`、`podman_image_cve`、`containerd_daemon_audit`、`containerd_runtime_audit`、`containerd_image_cve`、`supply_chain_audit`、`pip_supply_chain_audit`、`go_supply_chain_audit`、`rust_supply_chain_audit`

### 1.3 审计逻辑拓扑

```mermaid
flowchart LR
    Op["评估方（本机）"]
    Op -->|"SSH 仅只读<br/>用户 u<br/>key <tmp>/fake_key"| TargetIngress
    Op -.->|"AUTHORIZATION<br<tmp>/AUTHORIZATION.txt"| TargetIngress

    subgraph Target["目标 stub-host (linux)"]
        TargetIngress[sshd]
        OC["OpenClaw 实例"]
        Logs["/home/u/.openclaw/<br/>journald / /var/log/openclaw/"]
        TargetIngress -.- OC
        OC -.- Logs
    end

    TargetIngress --> Policy["CommandPolicy<br/>argv 白名单"]
    Policy --> Checks["35 项只读 check"]
    Checks --> Out["findings.json<br/>audit-log.jsonl<br/>server-audit-report.md"]
```

## 2. 执行摘要

### 2.1 风险态势

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 320" width="540" height="320" role="img" aria-label="严重度分布饼图">
  <title>严重度分布</title>
  <path d="M160,160 L160.00,30.00 A130,130 0 0,1 160.00,290.00 Z" fill="#ea580c" stroke="white" stroke-width="2"/>
  <text x="240.60" y="160.00" text-anchor="middle" dominant-baseline="central" fill="white" font-size="16" font-weight="bold">1 (50%)</text>
  <path d="M160,160 L160.00,290.00 A130,130 0 0,1 160.00,30.00 Z" fill="#3b82f6" stroke="white" stroke-width="2"/>
  <text x="79.40" y="160.00" text-anchor="middle" dominant-baseline="central" fill="white" font-size="16" font-weight="bold">1 (50%)</text>
  <rect x="340" y="130" width="20" height="20" fill="#ea580c" stroke="white" stroke-width="1"/>
  <text x="370" y="140" fill="currentColor" font-size="15" dominant-baseline="central">高 · 1 (50.0%)</text>
  <rect x="340" y="160" width="20" height="20" fill="#3b82f6" stroke="white" stroke-width="1"/>
  <text x="370" y="170" fill="currentColor" font-size="15" dominant-baseline="central">低 · 1 (50.0%)</text>
</svg>

| 严重度 | 数量 |
|--------|------|
| 🔴 严重 | 0 |
| 🟠 高 | 1 |
| 🟡 中 | 0 |
| 🔵 低 | 1 |
| ⚪ 信息 | 0 |
| **合计** | **2** |

### 2.2 攻击路径

> 以下攻击路径来自当前 finding 集合的启发式推断（基于 check 类型 +严重度 + KEV 标记的组合规则），需结合实际网络可达性与运维上下文复核后才能视为可执行的威胁场景。

_当前 finding 集合不满足任一内置攻击路径模板的触发条件_（如缺少暴露端口 + 高严重度 CVE 的组合）。

### 2.3 最高优先级修复

**高（high） —— 全部 1 条：**

1. **[HIGH]** `native_audit` — host: open management port 8443

## 3. 详细发现

### 3.1 🟠 高（high） —— 1 条

#### 3.1.1 [HIGH] host: open management port 8443

- **检查项**：`native_audit`
- **威胁引用**：TI-OPENCLAW-CVE-2026-25253
- **指纹**：`85a59ae43e5600ee`

**描述**：OpenClaw admin port reachable from public network.

**证据**：
  - `port`：8443
  - `interface`：0.0.0.0

**修复建议**：Bind to 127.0.0.1 or restrict via firewall.

---

### 3.2 🔵 低（low） —— 1 条

#### 3.2.1 [LOW] outdated subcomponent skill_loader

- **检查项**：`native_audit`
- **威胁引用**：—
- **指纹**：`52cfce61fd981424`

**描述**：Version 1.2.3 has a non-exploitable advisory.

**证据**：
  - `component`：skill_loader
  - `version`：1.2.3

**修复建议**：Upgrade to 1.2.4 at next maintenance window.

---

## 4. 未执行 / 不适用的检查

| 检查项 | 状态 | 原因 |
|--------|------|------|
| `iptables_audit` | not_applicable | iptables_audit：被审主机未检出 iptables 二进制 |
| `nftables_audit` | not_applicable | nftables_audit：被审主机未检出 nft 二进制 |
| `ufw_audit` | not_applicable | ufw_audit：被审主机未检出 ufw 二进制 |
| `firewalld_audit` | not_applicable | firewalld_audit：被审主机未检出 firewall-cmd 二进制 |
| `docker_daemon_audit` | not_applicable | docker_daemon_audit：被审主机未检出 docker 二进制（/usr/bin /usr/local/bin /opt/homebrew/bin 三处均无） |
| `docker_runtime_audit` | not_applicable | docker_runtime_audit：被审主机未检出 docker 二进制 |
| `docker_image_cve` | not_applicable | docker_image_cve：被审主机未检出 docker 二进制 |
| `podman_daemon_audit` | not_applicable | podman_daemon_audit：被审主机未检出 podman 二进制 |
| `podman_runtime_audit` | not_applicable | podman_runtime_audit：被审主机未检出 podman 二进制 |
| `podman_image_cve` | not_applicable | podman_image_cve：被审主机未检出 podman 二进制 |
| `containerd_runtime_audit` | not_applicable | containerd_runtime_audit：containerd 不可见（nerdctl / ctr 均未装或 socket 缺失） |
| `containerd_image_cve` | not_applicable | containerd_image_cve：containerd 不可见 |
| `pip_supply_chain_audit` | not_applicable | pip_supply_chain_audit：未配置 pip_lock_paths |
| `go_supply_chain_audit` | not_applicable | go_supply_chain_audit：未配置 go_lock_paths |
| `rust_supply_chain_audit` | not_applicable | rust_supply_chain_audit：未配置 cargo_lock_paths |
| `version_patch` | skipped | version_patch：无法确定 OpenClaw 版本（json 退出码 0，--version 不可用） |
| `active_test` | skipped | active_test：SSH 隧道建立失败：active_test tunnel stubbed in mock |
| `containerd_daemon_audit` | skipped | containerd_daemon_audit：config.toml 不是合法 TOML |

## 5. 错误

_本次运行未产生 check 级错误。_

## 附录 A：机读元数据

<!-- meta:profile value:linux -->
<!-- meta:remote_home value:/home/u -->
<!-- meta:server_score value:91 -->
<!-- check:version_patch status:skipped reason:version_patch：无法确定 OpenClaw 版本（json 退出码 0，--version 不可用） -->
<!-- check:active_test status:skipped reason:active_test：SSH 隧道建立失败：active_test tunnel stubbed in mock -->
<!-- check:iptables_audit status:not_applicable reason:iptables_audit：被审主机未检出 iptables 二进制 -->
<!-- check:nftables_audit status:not_applicable reason:nftables_audit：被审主机未检出 nft 二进制 -->
<!-- check:ufw_audit status:not_applicable reason:ufw_audit：被审主机未检出 ufw 二进制 -->
<!-- check:firewalld_audit status:not_applicable reason:firewalld_audit：被审主机未检出 firewall-cmd 二进制 -->
<!-- check:docker_daemon_audit status:not_applicable reason:docker_daemon_audit：被审主机未检出 docker 二进制（/usr/bin /usr/local/bin /opt/homebrew/bin 三处均无） -->
<!-- check:docker_runtime_audit status:not_applicable reason:docker_runtime_audit：被审主机未检出 docker 二进制 -->
<!-- check:docker_image_cve status:not_applicable reason:docker_image_cve：被审主机未检出 docker 二进制 -->
<!-- check:podman_daemon_audit status:not_applicable reason:podman_daemon_audit：被审主机未检出 podman 二进制 -->
<!-- check:podman_runtime_audit status:not_applicable reason:podman_runtime_audit：被审主机未检出 podman 二进制 -->
<!-- check:podman_image_cve status:not_applicable reason:podman_image_cve：被审主机未检出 podman 二进制 -->
<!-- check:containerd_daemon_audit status:skipped reason:containerd_daemon_audit：config.toml 不是合法 TOML -->
<!-- check:containerd_runtime_audit status:not_applicable reason:containerd_runtime_audit：containerd 不可见（nerdctl / ctr 均未装或 socket 缺失） -->
<!-- check:containerd_image_cve status:not_applicable reason:containerd_image_cve：containerd 不可见 -->
<!-- check:pip_supply_chain_audit status:not_applicable reason:pip_supply_chain_audit：未配置 pip_lock_paths -->
<!-- check:go_supply_chain_audit status:not_applicable reason:go_supply_chain_audit：未配置 go_lock_paths -->
<!-- check:rust_supply_chain_audit status:not_applicable reason:rust_supply_chain_audit：未配置 cargo_lock_paths -->
<!-- meta:errors count:0 -->
<!-- meta:findings_total count:2 -->
<!-- meta:findings_critical count:0 -->
<!-- meta:findings_high count:1 -->
<!-- meta:findings_medium count:0 -->
<!-- meta:findings_low count:1 -->
<!-- meta:findings_info count:0 -->

