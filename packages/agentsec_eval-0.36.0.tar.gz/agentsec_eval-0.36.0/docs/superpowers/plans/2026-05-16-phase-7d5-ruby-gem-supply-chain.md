# Phase 7d.5 — Ruby/Gem Supply Chain Audit Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a 6th ecosystem to the supply chain audit series — Ruby/Gem. Implement `GemSupplyChainAuditCheck`, `OsvRubyGemsFetcher`, Gemfile.lock parser, RubyGems version comparator via `packaging.version`, OSV-RubyGems DB build pipeline, CLI flag, ADR-0025, v0.35.0 docs.

**Architecture:** Mirror Phase 7d.4 (java/maven). Two RubyGems-specific deltas: (1) parse Bundler's `Gemfile.lock` text format (walk `GEM > specs:` section); (2) version comparison via `packaging.version.Version` with simple RubyGems→PEP 440 string preprocessing (zero new deps). No new third-party deps.

**Tech Stack:** Python; existing `packaging` (already pulled in by pip ecosystem), `httpx`, `pydantic`, `pytest`, `ruff`.

**Baseline:** main `eb3ca97`; 1756 tests pass / 9 skipped. Target version: `v0.35.0`.

**Reference spec:** `docs/superpowers/specs/2026-05-16-phase-7d5-ruby-gem-supply-chain-design.md`

**Reference precedent:** Phase 7d.4 (java/maven), shipped at commits `b923479..9972306`. The implementer should `git show <sha>` on those commits as canonical templates — 7d.5 mirrors that structure with ruby-specific deltas.

---

## File Structure

| File | Role | Touch |
|---|---|---|
| `src/agentsec/audit/checks/_supply_chain_common.py` | Add `parse_gemfile_lock` + `_safe_parse_gem_version` + `_is_gem_version_in_range` | Modify |
| `src/agentsec/audit/checks/gem_supply_chain_audit.py` | New `GemSupplyChainAuditCheck` | **Create** |
| `src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py` | New `OsvRubyGemsFetcher` | **Create** |
| `src/agentsec/audit/ioc_update/cli.py` | Add `_run_osv_rubygems` + 6-way gather | Modify |
| `src/agentsec/audit/ioc/osv_rubygems.json` | Bundled DB (built in Task 9) | **Create** |
| `src/agentsec/audit/ioc/threat_intel.yaml` | Add `TI-OSV-RUBYGEMS-CATALOG` entry | Modify |
| `src/agentsec/audit/ioc/cve_database.json` | Regenerated after threat_intel.yaml change | Modify |
| `scripts/check_osv_rubygems.py` | CI guard | **Create** |
| `src/agentsec/config.py` | Add `gem_lock_paths` field + validator | Modify |
| `src/agentsec/audit/checks/base.py` | Add `gem_lock_paths` to CheckContext | Modify |
| `src/agentsec/audit/server_audit.py` | Wire `gem_lock_paths` into CheckContext construction | Modify |
| `src/agentsec/cli.py` | Add `--gem-lock-path` to `server-audit` + `_evaluate_server` | Modify |
| `tests/test_parse_gemfile_lock.py` | Unit tests | **Create** |
| `tests/test_is_gem_version_in_range.py` | Unit tests | **Create** |
| `tests/test_gem_supply_chain_audit.py` | Unit tests | **Create** |
| `tests/test_osv_rubygems_fetcher.py` | Unit tests | **Create** |
| `tests/test_config_gem_lock_paths.py` | Unit tests | **Create** |
| `docs/adr/0025-phase-7d5-ruby-gem-supply-chain.md` | New ADR | **Create** |
| `CHANGELOG.md` | v0.35.0 entry | Modify |
| `ROADMAP.md` | Mark 7d.5 shipped | Modify |
| `CLAUDE.md` | Add `## Ruby/Gem supply chain audit (Phase 7d.5, v0.35.0)` section | Modify |
| `pyproject.toml` | 0.34.0 → 0.35.0 | Modify |

---

## Task 1: parse_gemfile_lock + version helpers + tests

**Files:**
- Modify: `src/agentsec/audit/checks/_supply_chain_common.py` (append helpers)
- Create: `tests/test_parse_gemfile_lock.py`
- Create: `tests/test_is_gem_version_in_range.py`

- [ ] **Step 1.1: Append helpers to `_supply_chain_common.py`**

Append to `src/agentsec/audit/checks/_supply_chain_common.py`:

```python


# ── Gemfile.lock parser + PEP 440 version range matcher (Phase 7d.5) ──────

_GEM_DEP_LINE = re.compile(r"^    ([a-zA-Z0-9._-]+) \(([^)]+)\)\s*$")


def parse_gemfile_lock(text: str) -> list[tuple[str, str]]:
    """Parse a Bundler-generated Gemfile.lock.

    Walks the `GEM > specs:` section only. Skips GIT / PATH / PLATFORMS /
    DEPENDENCIES sections (the first two are out-of-OSV-scope sources; the
    last two don't list resolved versions).

    Within `GEM > specs:`, 4-space-indented lines are resolved
    dependencies (`    gem_name (version)`); 6-space-indented lines are
    transitive version constraints — skipped.

    Gem names are case-folded to lowercase (RubyGems is case-insensitive).
    """
    out: list[tuple[str, str]] = []
    in_gem_section = False
    in_specs = False

    for raw in text.splitlines():
        # Section header detection (no leading whitespace)
        if raw and not raw[0].isspace():
            header = raw.strip()
            in_gem_section = header == "GEM"
            in_specs = False
            continue

        if not in_gem_section:
            continue

        stripped = raw.strip()
        if stripped == "specs:":
            in_specs = True
            continue

        if not in_specs:
            continue

        # Resolved gem entry: exactly 4 leading spaces
        m = _GEM_DEP_LINE.match(raw)
        if m:
            gem_name, version = m.groups()
            out.append((gem_name.lower(), version))

    return out


def _normalize_gem_version(s: str) -> str:
    """Convert a RubyGems version string into a PEP 440-compatible form.

    RubyGems uses suffixes like `1.0.0.pre.1`, `2.0.0.rc1`, `1.0.0.beta`.
    PEP 440's packaging.version.Version accepts `1.0.0a1`, `2.0.0rc1`,
    `1.0.0b0` etc. This helper applies minimal string substitutions to
    bridge the two; best-effort, may leave exotic strings unparseable
    (returned None from `_safe_parse_gem_version`).
    """
    if not s:
        return s
    # `.pre.N` (e.g. 1.0.0.pre.1) → `aN`
    s = re.sub(r"\.pre\.(\d+)", r"a\1", s)
    # `.pre` standalone (e.g. 1.0.0.pre) → `a0`
    s = re.sub(r"\.pre$", "a0", s)
    # `.beta.N` / `.alpha.N` → `bN` / `aN`
    s = re.sub(r"\.beta\.(\d+)", r"b\1", s)
    s = re.sub(r"\.alpha\.(\d+)", r"a\1", s)
    # Standalone `.beta` / `.alpha` → `b0` / `a0`
    s = re.sub(r"\.beta$", "b0", s)
    s = re.sub(r"\.alpha$", "a0", s)
    return s


def _safe_parse_gem_version(s: str):
    """Parse a RubyGems version into packaging.Version, or None on failure."""
    from packaging.version import InvalidVersion, Version
    if not s:
        return None
    try:
        return Version(_normalize_gem_version(s))
    except (InvalidVersion, TypeError):
        return None


def _is_gem_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
) -> bool:
    """True iff version satisfies introduced <= version < fixed.

    Either bound may be None: missing introduced means "from 0";
    missing fixed means "no upper bound" (still vulnerable).
    Returns False if the version string cannot be parsed.
    """
    v = _safe_parse_gem_version(version)
    if v is None:
        return False
    if introduced is not None:
        intro = _safe_parse_gem_version(introduced)
        if intro is not None and intro > v:
            return False
    if fixed is not None:
        fix = _safe_parse_gem_version(fixed)
        if fix is not None and v >= fix:
            return False
    return True
```

Verify `import re` is already at top of `_supply_chain_common.py` (it was added in Phase 7d.4 Task 1). If not, add it.

- [ ] **Step 1.2: Create `tests/test_parse_gemfile_lock.py`**

```python
"""Unit tests for parse_gemfile_lock (Phase 7d.5)."""

from __future__ import annotations

from agentsec.audit.checks._supply_chain_common import parse_gemfile_lock


def test_parses_standard_gem_section() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    actionmailer (7.0.4)
      actionpack (= 7.0.4)
      actionview (= 7.0.4)
    activesupport (7.0.4)
      i18n (>= 1.6, < 2)
    rails (7.0.4)
      actioncable (= 7.0.4)

PLATFORMS
  ruby

DEPENDENCIES
  rails (~> 7.0.0)
"""
    deps = parse_gemfile_lock(text)
    assert deps == [
        ("actionmailer", "7.0.4"),
        ("activesupport", "7.0.4"),
        ("rails", "7.0.4"),
    ]


def test_skips_git_and_path_sections() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    rails (7.0.4)

GIT
  remote: https://github.com/example/gem.git
  revision: abc123
  specs:
    private-gem (1.0.0)

PATH
  remote: vendor/local-gem
  specs:
    local-gem (0.1.0)
"""
    deps = parse_gemfile_lock(text)
    coords = [name for name, _ in deps]
    assert coords == ["rails"]
    assert "private-gem" not in coords
    assert "local-gem" not in coords


def test_case_folds_gem_names() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    ActiveRecord (7.0.4)
    MyGem (1.0.0)
"""
    deps = parse_gemfile_lock(text)
    assert deps == [("activerecord", "7.0.4"), ("mygem", "1.0.0")]


def test_skips_transitive_constraints() -> None:
    text = """GEM
  remote: https://rubygems.org/
  specs:
    rails (7.0.4)
      actioncable (= 7.0.4)
      actionmailer (= 7.0.4)
      activerecord (= 7.0.4)
    sidekiq (6.5.0)
      connection_pool (>= 2.2.5)
"""
    deps = parse_gemfile_lock(text)
    # Only the 4-space-indented entries; 6-space-indented constraints skipped
    assert deps == [("rails", "7.0.4"), ("sidekiq", "6.5.0")]


def test_empty_or_no_gem_section_returns_empty() -> None:
    assert parse_gemfile_lock("") == []
    assert parse_gemfile_lock("PLATFORMS\n  ruby\n\nDEPENDENCIES\n  rails\n") == []
```

- [ ] **Step 1.3: Create `tests/test_is_gem_version_in_range.py`**

```python
"""Unit tests for _is_gem_version_in_range (Phase 7d.5)."""

from __future__ import annotations

import pytest

from agentsec.audit.checks._supply_chain_common import (
    _is_gem_version_in_range,
    _safe_parse_gem_version,
)


@pytest.mark.parametrize(
    "version,introduced,fixed,expected",
    [
        # Standard PEP 440 / semver-like
        ("1.5.0", "1.0", "2.0", True),
        ("0.9.0", "1.0", "2.0", False),
        ("2.0.0", "1.0", "2.0", False),  # fixed exclusive
        ("1.0.0", "1.0", "2.0", True),  # introduced inclusive
        # RubyGems pre-release suffix .pre.N
        ("1.0.0.pre.1", "0", "1.0.0", True),
        ("1.0.0", "0", "1.0.0.pre.1", False),  # release > prerelease
        # .rc suffix
        ("2.0.0.rc1", "0", "2.0.0", True),
        # .beta / .alpha
        ("1.0.0.beta", "0", "1.0.0", True),
        # Missing bounds
        ("1.5.0", None, "2.0", True),
        ("3.0.0", None, "2.0", False),
        ("1.5.0", "1.0", None, True),
        ("0.5.0", "1.0", None, False),
        # Both missing → all versions vulnerable
        ("1.5.0", None, None, True),
        # Unparseable returns False
        ("not-a-version", "1.0", "2.0", False),
    ],
)
def test_is_gem_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
    expected: bool,
) -> None:
    assert _is_gem_version_in_range(version, introduced, fixed) is expected


def test_safe_parse_handles_invalid() -> None:
    assert _safe_parse_gem_version("") is None
    assert _safe_parse_gem_version(None) is None  # type: ignore
    assert _safe_parse_gem_version("garbage-string") is None


def test_safe_parse_handles_pre_release_forms() -> None:
    assert _safe_parse_gem_version("1.0.0.pre.1") is not None
    assert _safe_parse_gem_version("1.0.0.rc1") is not None
    assert _safe_parse_gem_version("1.0.0.beta") is not None
```

- [ ] **Step 1.4: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_parse_gemfile_lock.py tests/test_is_gem_version_in_range.py -v
```
Expected: all pass (~22 parametrize + 7 def = ~22 unique test cases counting parametrize).

If FAIL: read carefully. Common gotchas:
- `.pre.N` → `aN` substitution must come BEFORE `.pre` standalone substitution (order in `_normalize_gem_version`)
- `parse_gemfile_lock` must track section state across lines; the `GIT > specs:` section also has `specs:`, so the `in_gem_section` flag is what gates `in_specs`

- [ ] **Step 1.5: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/checks/_supply_chain_common.py tests/test_parse_gemfile_lock.py tests/test_is_gem_version_in_range.py
```

- [ ] **Step 1.6: Full pytest (no regression)**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: 1756 + ~22 = ~1778 PASS / 9 skipped.

- [ ] **Step 1.7: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/checks/_supply_chain_common.py tests/test_parse_gemfile_lock.py tests/test_is_gem_version_in_range.py && git commit -m "$(cat <<'EOF'
feat(7d.5): Gemfile.lock parser + RubyGems version range matcher

parse_gemfile_lock walks the GEM > specs: section of a Bundler
lockfile, skipping GIT/PATH sources and transitive version
constraints. Gem names are case-folded to lowercase per RubyGems
convention.

_is_gem_version_in_range bridges RubyGems version semantics to
packaging.version.Version (PEP 440) via simple string preprocessing:
.pre.N → aN, .beta.N → bN, etc. Zero new deps (packaging already
pulled in by pip ecosystem). Tests cover .pre / .rc / .beta forms
and unparseable fallback.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: ServerAuditConfig.gem_lock_paths + CheckContext + tests

**Files:**
- Modify: `src/agentsec/config.py` (add field+validator after `maven_lock_paths`)
- Modify: `src/agentsec/audit/checks/base.py` (add CheckContext field)
- Modify: `src/agentsec/audit/server_audit.py` (wire field into CheckContext construction)
- Create: `tests/test_config_gem_lock_paths.py`

REFERENCE: Phase 7d.4 Task 2 pattern (commit 97dc4c0). Inspect:
```
git show 97dc4c0 -- src/agentsec/config.py src/agentsec/audit/checks/base.py src/agentsec/audit/server_audit.py | head -100
```

- [ ] **Step 2.1: Add `gem_lock_paths` to `ServerAuditConfig`**

In `src/agentsec/config.py`, immediately after the `maven_lock_paths` field+validator (added in 7d.4 Task 2), add:

```python

    gem_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("gem_lock_paths")
    @classmethod
    def _validate_gem_lock_paths(cls, v: list[str]) -> list[str]:
        from .audit.metachar_guard import contains_shell_metachar

        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"gem_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar(p):
                raise ValueError(
                    f"gem_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if basename != "Gemfile.lock":
                raise ValueError(
                    f"gem_lock_paths entry {p!r} basename must equal 'Gemfile.lock' "
                    f"(strict, mirrors Cargo.lock convention)"
                )
        return v
```

- [ ] **Step 2.2: Add field to `CheckContext`**

In `src/agentsec/audit/checks/base.py`, find `maven_lock_paths` (added in 7d.4 Task 2). Add `gem_lock_paths` right after with identical pattern (likely `tuple[str, ...] = ()`).

- [ ] **Step 2.3: Wire into `server_audit.py`**

In `src/agentsec/audit/server_audit.py`, find where `maven_lock_paths` is passed to `CheckContext(...)` construction. Add `gem_lock_paths=ctx.gem_lock_paths` (or equivalent — mirror the exact maven line).

- [ ] **Step 2.4: Create `tests/test_config_gem_lock_paths.py`**

```python
"""Unit tests for ServerAuditConfig.gem_lock_paths validator (Phase 7d.5)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentsec.config import ServerAuditConfig


def _config(**overrides) -> dict:
    """Minimal valid ServerAuditConfig dict.

    The actual minimal fields depend on ServerAuditConfig schema —
    inspect existing test_config_maven_lock_paths.py for the shape.
    """
    return {
        "host": "test.example",
        "user": "ubuntu",
        "key": "~/.ssh/id_rsa",
        **overrides,
    }


def test_empty_gem_lock_paths_is_valid() -> None:
    cfg = ServerAuditConfig.model_validate(_config())
    assert cfg.gem_lock_paths == []


def test_accepts_valid_gemfile_lock_path() -> None:
    cfg = ServerAuditConfig.model_validate(_config(
        gem_lock_paths=[
            "/opt/myapp/Gemfile.lock",
            "~/projects/rails-app/Gemfile.lock",
        ]
    ))
    assert len(cfg.gem_lock_paths) == 2


def test_rejects_relative_path() -> None:
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["Gemfile.lock"]
        ))


def test_rejects_shell_metachar() -> None:
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/$INJECT/Gemfile.lock"]
        ))


def test_rejects_non_canonical_basename() -> None:
    # Must be exactly "Gemfile.lock"
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/myapp/gemfile.lock"]  # lowercase wrong
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/myapp/Gemfile"]  # missing .lock
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            gem_lock_paths=["/opt/myapp/Gemfile.lock.bak"]  # suffix wrong
        ))
```

NOTE: If `_config()` minimal dict differs (e.g., `consent_file` vs `key`), inspect `tests/test_config_maven_lock_paths.py` (created in 7d.4 Task 2) and copy its exact minimal config shape.

- [ ] **Step 2.5: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_config_gem_lock_paths.py -v
```
Expected: 5 PASS (counting the third test's 3 sub-checks via `with pytest.raises`).

- [ ] **Step 2.6: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ~1778 + 5 = ~1783 PASS / 9 skipped.

- [ ] **Step 2.7: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/config.py src/agentsec/audit/checks/base.py src/agentsec/audit/server_audit.py tests/test_config_gem_lock_paths.py
```

- [ ] **Step 2.8: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/config.py src/agentsec/audit/checks/base.py src/agentsec/audit/server_audit.py tests/test_config_gem_lock_paths.py && git commit -m "$(cat <<'EOF'
feat(7d.5): add gem_lock_paths to ServerAuditConfig + CheckContext

Operator-configured paths to Gemfile.lock files, mirrors
maven_lock_paths / cargo_lock_paths. Validator: must start with / or
~/, no shell metachars, basename must equal 'Gemfile.lock' (strict,
mirrors Cargo.lock convention).

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: OsvRubyGemsFetcher + mock httpx tests

**Files:**
- Create: `src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py`
- Create: `tests/test_osv_rubygems_fetcher.py`

REFERENCE: Phase 7d.4 Task 3 commit `71e7a6d` shipped `osv_maven.py`. Mirror line-for-line; only differences are URL, ecosystem string, fetcher name, function name.

```
git show 71e7a6d -- src/agentsec/audit/ioc_update/fetchers/osv_maven.py
```

- [ ] **Step 3.1: Create `osv_rubygems.py`**

Copy `src/agentsec/audit/ioc_update/fetchers/osv_maven.py` as the template, then apply these substitutions throughout:

| Maven version | RubyGems version |
|---|---|
| `OSV_MAVEN_URL` | `OSV_RUBYGEMS_URL` |
| `"https://...Maven/all.zip"` | `"https://osv-vulnerabilities.storage.googleapis.com/RubyGems/all.zip"` |
| `_extract_maven_ranges` | `_extract_rubygems_ranges` |
| `normalize_osv_maven_entry` | `normalize_osv_rubygems_entry` |
| `OsvMavenFetcher` | `OsvRubyGemsFetcher` |
| `_osv_maven_full` | `_osv_rubygems_full` |
| ecosystem check `== "Maven"` | `== "RubyGems"` |
| docstring "OSV-Maven" → "OSV-RubyGems" | (same shape, replace string) |
| Comments mentioning "java" / "Maven" / "Cargo" → "ruby" / "RubyGems" | |

The 5-axis filter chain logic, ZIP parse, retry/backoff, dedup-on-(id,package) — all identical to maven, no changes.

- [ ] **Step 3.2: Create `tests/test_osv_rubygems_fetcher.py`**

Copy `tests/test_osv_rubygems_fetcher.py` template structure from `tests/test_osv_maven_fetcher.py` (shipped in 7d.4 Task 3 at commit 71e7a6d). Substitute:
- Ecosystem `"Maven"` → `"RubyGems"`
- Package names: change from `org.apache.commons:commons-lang3` form to plain gem names like `rails` / `rack` / `nokogiri`
- Function name `normalize_osv_maven_entry` → `normalize_osv_rubygems_entry`
- Class name `OsvMavenFetcher` → `OsvRubyGemsFetcher`
- Result key `_osv_maven_full` → `_osv_rubygems_full`

Reference test file shape:
```
git show 71e7a6d -- tests/test_osv_maven_fetcher.py
```

Apply the substitutions; the test logic (zip mocking, normalize round-trip, dedup, drop withdrawn / drop non-ecosystem) is identical.

- [ ] **Step 3.3: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_osv_rubygems_fetcher.py -v
```
Expected: 4 PASS (matching the 4 maven tests).

- [ ] **Step 3.4: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py tests/test_osv_rubygems_fetcher.py
```

- [ ] **Step 3.5: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ~1783 + 4 = ~1787 PASS / 9 skipped.

- [ ] **Step 3.6: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py tests/test_osv_rubygems_fetcher.py && git commit -m "$(cat <<'EOF'
feat(7d.5): OsvRubyGemsFetcher — pull OSV-RubyGems full ecosystem dump

Mirrors OsvMavenFetcher: pulls
https://osv-vulnerabilities.storage.googleapis.com/RubyGems/all.zip,
walks every JSON entry, applies the 5-axis filter chain (drop
withdrawn / no RubyGems affected / no range / no CVSS / scored
medium-low > 2y), expands multi-affected packages, dedups on
(id, package). Tests use httpx.MockTransport.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: scripts/check_osv_rubygems.py CI guard

**Files:**
- Create: `scripts/check_osv_rubygems.py`

- [ ] **Step 4.1: Create the script**

```python
#!/usr/bin/env python3
"""CI guard for src/agentsec/audit/ioc/osv_rubygems.json.

Validates the bundled OSV-RubyGems advisory DB:
  - File exists
  - Valid JSON (top-level list of advisory dicts)
  - File size <= 15 MB hard cap

Usage:
    python scripts/check_osv_rubygems.py [--check]

Exits 0 on success, 1 on failure.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "src/agentsec/audit/ioc/osv_rubygems.json"
SIZE_CAP_BYTES = 15 * 1024 * 1024  # 15 MB


def main() -> int:
    if not DB_PATH.exists():
        print(f"FAIL: {DB_PATH} does not exist", file=sys.stderr)
        return 1

    size = DB_PATH.stat().st_size
    if size > SIZE_CAP_BYTES:
        print(
            f"FAIL: {DB_PATH} is {size:,} bytes, exceeds cap "
            f"{SIZE_CAP_BYTES:,} bytes",
            file=sys.stderr,
        )
        return 1

    try:
        data = json.loads(DB_PATH.read_text())
    except json.JSONDecodeError as exc:
        print(f"FAIL: {DB_PATH} is not valid JSON: {exc}", file=sys.stderr)
        return 1

    if not isinstance(data, list):
        print(
            f"FAIL: {DB_PATH} top-level must be a list, got {type(data).__name__}",
            file=sys.stderr,
        )
        return 1

    print(
        f"OK — {DB_PATH.name} contains {len(data):,} advisories, "
        f"{size:,} bytes (cap {SIZE_CAP_BYTES:,})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 4.2: Make executable + verify FAIL (DB not built yet)**

```bash
cd /Users/roger/Work/AgentSec && chmod +x scripts/check_osv_rubygems.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_rubygems.py
```
Expected: FAIL `does not exist`. Exit code 1. This is EXPECTED — Task 9 builds the DB.

- [ ] **Step 4.3: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check scripts/check_osv_rubygems.py
```

- [ ] **Step 4.4: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add scripts/check_osv_rubygems.py && git commit -m "$(cat <<'EOF'
feat(7d.5): scripts/check_osv_rubygems.py CI guard

Validates osv_rubygems.json exists, is valid JSON list, and is
under 15 MB cap. Mirrors check_osv_maven.py / check_osv_cargo.py /
check_osv_pypi.py / check_osv_go.py / check_osv_npm.py. Fails until
Task 9 builds the bundled DB.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: ioc-update CLI _run_osv_rubygems + 6-way gather

**Files:**
- Modify: `src/agentsec/audit/ioc_update/cli.py`

REFERENCE: Phase 7d.4 Task 5 commit `2056ce6` added `_run_osv_maven` to the gather. Mirror that change.

- [ ] **Step 5.1: Add import**

In `src/agentsec/audit/ioc_update/cli.py`, find the import line `from .fetchers.osv_maven import OsvMavenFetcher` (added in 7d.4). Add immediately after:

```python
from .fetchers.osv_rubygems import OsvRubyGemsFetcher
```

- [ ] **Step 5.2: Add `_run_osv_rubygems` function**

Find `_run_osv_maven` in the file. Add a copy of that function immediately after, with these substitutions:
- Function name: `_run_osv_maven` → `_run_osv_rubygems`
- Fetcher: `OsvMavenFetcher()` → `OsvRubyGemsFetcher()`
- Result key: `_osv_maven_full` → `_osv_rubygems_full`
- Output filename: `proposed-osv_maven.json` → `proposed-osv_rubygems.json`
- Log/audit event names: `osv_maven_written` → `osv_rubygems_written`, etc.

- [ ] **Step 5.3: Extend `asyncio.gather` to 6-way**

Find the gather call site (added 5-way in 7d.4 Task 5). Add `_run_osv_rubygems(...)` as the 6th argument with the same call signature as the maven call. Also extend any tuple unpacking (e.g., `osv_npm_path, osv_pypi_path, osv_go_path, osv_cargo_path, osv_maven_path, osv_rubygems_path = await asyncio.gather(...)`).

- [ ] **Step 5.4: Add audit_events for rubygems**

If 7d.4 added `osv_maven_written` / `osv_maven_degraded` audit_events, add the analogous `osv_rubygems_written` / `osv_rubygems_degraded` block.

- [ ] **Step 5.5: Lint + existing ioc-update integration tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/ioc_update/cli.py
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/integration/test_ioc_update_offline.py tests/integration/test_ioc_update_mock_http.py -v 2>&1 | tail -10
```
Expected: lint PASS; ioc-update integration tests PASS.

- [ ] **Step 5.6: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc_update/cli.py && git commit -m "$(cat <<'EOF'
feat(7d.5): ioc-update — wire OsvRubyGemsFetcher into 6-way gather

Add _run_osv_rubygems() and include it in the asyncio.gather call
that fans out OSV fetches across npm/pypi/go/cargo/maven/rubygems.
Output written to .cache/ioc-update-<date>/proposed-osv_rubygems.json.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: threat_intel.yaml + cve_database.json

**Files:**
- Modify: `src/agentsec/audit/ioc/threat_intel.yaml`
- Modify: `src/agentsec/audit/ioc/cve_database.json`

- [ ] **Step 6.1: Inspect existing TI-OSV-MAVEN-CATALOG entry shape**

```
cd /Users/roger/Work/AgentSec && grep -n -B 1 -A 12 "TI-OSV-MAVEN-CATALOG" src/agentsec/audit/ioc/threat_intel.yaml
```

This shows the exact yaml shape used by 7d.4 Task 6 — match it. Earlier 7d.4 implementer used:

```yaml
  - id: TI-OSV-MAVEN-CATALOG
    source: osv
    url: https://osv.dev/list?ecosystem=Maven
    observed_at: 2026-05-16
    claim: |
      ...
    confidence: high
    mapped_tests: []
    note: |
      ...
    auto_refresh: false
```

Mirror this exact field shape (not the spec's slightly different field set — defer to what's actually in the file).

- [ ] **Step 6.2: Add TI-OSV-RUBYGEMS-CATALOG entry**

Add immediately after `TI-OSV-MAVEN-CATALOG`, matching its exact indentation:

```yaml
  - id: TI-OSV-RUBYGEMS-CATALOG
    source: osv
    url: https://osv.dev/list?ecosystem=RubyGems
    observed_at: 2026-05-16
    claim: |
      Aggregated CVE catalog for RubyGems (Ruby) packages, sourced from OSV.
      Umbrella TI; per-CVE advisory id surfaces directly in finding evidence.
    confidence: high
    mapped_tests: [gem_supply_chain_audit]
    note: |
      Umbrella TI for all RubyGems CVE matches surfaced by
      gem_supply_chain_audit. Refresh via `agentsec ioc-update`.
    auto_refresh: false
```

- [ ] **Step 6.3: Verify YAML parses**

```
cd /Users/roger/Work/AgentSec && .venv/bin/python -c "
import yaml
with open('src/agentsec/audit/ioc/threat_intel.yaml') as f:
    data = yaml.safe_load(f)
entries = data if isinstance(data, list) else data.get('entries', data)
ids = [e['id'] for e in entries if isinstance(e, dict) and 'id' in e]
print('TI-OSV-RUBYGEMS-CATALOG present:', 'TI-OSV-RUBYGEMS-CATALOG' in ids)
print('TI-OSV-MAVEN-CATALOG present:', 'TI-OSV-MAVEN-CATALOG' in ids)
print('total entries:', len(ids))
"
```
Expected: both present True.

- [ ] **Step 6.4: Regenerate cve_database.json**

```
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/build_cve_db.py
```

- [ ] **Step 6.5: Verify CI guard passes**

```
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/build_cve_db.py --check
```
Expected: PASS.

- [ ] **Step 6.6: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: no change to test count (~1787 PASS / 9 skipped).

- [ ] **Step 6.7: Commit (both files)**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc/threat_intel.yaml src/agentsec/audit/ioc/cve_database.json && git commit -m "$(cat <<'EOF'
feat(7d.5): threat_intel.yaml — add TI-OSV-RUBYGEMS-CATALOG umbrella

New umbrella TI entry for RubyGems CVE matches; mapped_tests =
[gem_supply_chain_audit]. auto_refresh: false (per-CVE advisory
ids live in finding evidence, not TI). Regenerate cve_database.json.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: GemSupplyChainAuditCheck + tests

**Files:**
- Create: `src/agentsec/audit/checks/gem_supply_chain_audit.py`
- Create: `tests/test_gem_supply_chain_audit.py`

REFERENCE: Phase 7d.4 Task 7 commit `bf3b6a6` shipped `java_supply_chain_audit.py`. Mirror line-for-line; only differences are:

- DB filename: `osv_maven.json` → `osv_rubygems.json`
- Check id: `java_supply_chain_audit` → `gem_supply_chain_audit`
- Class: `JavaSupplyChainAuditCheck` → `GemSupplyChainAuditCheck`
- ctx field: `ctx.maven_lock_paths` → `ctx.gem_lock_paths`
- Helper: `parse_maven_dependency_list` → `parse_gemfile_lock`
- Helper: `_is_maven_version_in_range` → `_is_gem_version_in_range`
- threat_refs: `["TI-OSV-MAVEN-CATALOG"]` → `["TI-OSV-RUBYGEMS-CATALOG"]`
- Coord variable: `coord` → `gem` (single string, not `groupId:artifactId`)
- _match function name: `_match_maven_advisories` → `_match_gem_advisories`
- Description docstring: "Maven" → "RubyGems", "Java" → "Ruby"
- evidence key: `coord` → `gem`

The DB-load fail-safe (`try/except FileNotFoundError` in `__init__`) is also needed since `osv_rubygems.json` doesn't exist until Task 9.

- [ ] **Step 7.1: Create `gem_supply_chain_audit.py`**

Copy `git show bf3b6a6 -- src/agentsec/audit/checks/java_supply_chain_audit.py` as template; apply substitutions above.

- [ ] **Step 7.2: Create `tests/test_gem_supply_chain_audit.py`**

Copy `git show bf3b6a6 -- tests/test_java_supply_chain_audit.py` as template; apply substitutions:
- Import `_match_gem_advisories` (not `_match_maven_advisories`)
- Use `JavaSupplyChainAuditCheck` → `GemSupplyChainAuditCheck`
- Package names in test fixtures: `org.example:lib` → `rails`, `org.other:lib` → `nokogiri`, etc.
- ctx field: `ctx.maven_lock_paths` → `ctx.gem_lock_paths`

The test logic (match in range / skip when above fixed / skip when not in DB / multi-advisory / not_applicable) is identical.

- [ ] **Step 7.3: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_gem_supply_chain_audit.py -v
```
Expected: 5 PASS (matching java).

- [ ] **Step 7.4: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/checks/gem_supply_chain_audit.py tests/test_gem_supply_chain_audit.py
```

- [ ] **Step 7.5: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ~1787 + 5 = ~1792 PASS / 9 skipped.

- [ ] **Step 7.6: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/checks/gem_supply_chain_audit.py tests/test_gem_supply_chain_audit.py && git commit -m "$(cat <<'EOF'
feat(7d.5): GemSupplyChainAuditCheck — match Ruby gems against OSV

Mirror JavaSupplyChainAuditCheck. Read operator-configured
Gemfile.lock files via SSH, parse with parse_gemfile_lock, match
each (gem, version) against bundled osv_rubygems.json using
packaging.version (PEP 440) ranges with RubyGems→PEP 440
preprocessing. Emit one Finding per matching tuple.
threat_refs = [TI-OSV-RUBYGEMS-CATALOG].

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 8: CLI --gem-lock-path flag

**Files:**
- Modify: `src/agentsec/cli.py` (add to both `server-audit` and `_evaluate_server`)

REFERENCE: Phase 7d.4 Task 8 commit `5b38c97` added `--maven-lock-path`. Mirror exactly.

- [ ] **Step 8.1: Inspect existing maven plumbing**

```
cd /Users/roger/Work/AgentSec && grep -n "maven_lock_paths" src/agentsec/cli.py
```

This locates:
- typer.Option declaration in `server_audit` signature
- if-block body in `server_audit` (config update + expand_tilde + CheckContext)
- if-block body in `_evaluate_server`
- CheckContext construction lines in both

- [ ] **Step 8.2: Add `gem_lock_paths` typer.Option**

In `server_audit` command signature, immediately after `maven_lock_paths`:

```python
    gem_lock_paths: list[str] = typer.Option(
        [],
        "--gem-lock-path",
        help="Path on remote host to a Bundler Gemfile.lock file "
             "(repeatable; multiple paths checked).",
    ),
```

- [ ] **Step 8.3: Mirror maven's body wiring**

In the `server_audit` body, find the `if maven_lock_paths:` block. Add an analogous `if gem_lock_paths:` block immediately after, with identical structure (config dict update, expand_tilde, allowed_paths injection, CheckContext field).

- [ ] **Step 8.4: Mirror in `_evaluate_server`**

In the `_evaluate_server` function, find the `if sa.maven_lock_paths:` block. Add analogous `if sa.gem_lock_paths:` block immediately after.

- [ ] **Step 8.5: Add to CheckContext constructions**

In both `server_audit` and `_evaluate_server`, find the CheckContext(...) construction. Add `gem_lock_paths=tuple(...)` right after the `maven_lock_paths=tuple(...)` line.

- [ ] **Step 8.6: Smoke-test CLI help**

```
cd /Users/roger/Work/AgentSec && .venv/bin/agentsec server-audit --help 2>&1 | grep -A 1 -i gem
```
Expected: `--gem-lock-path` appears in help.

- [ ] **Step 8.7: Lint + pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/cli.py
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ruff PASS; ~1792 PASS / 9 skipped.

- [ ] **Step 8.8: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/cli.py && git commit -m "$(cat <<'EOF'
feat(7d.5): CLI — add --gem-lock-path to server-audit (+ evaluate)

Repeatable typer Option mirroring --maven-lock-path. Operator
points --gem-lock-path at a Bundler Gemfile.lock on the audited
host. CheckContext wiring + expand_tilde + config override all
mirror the maven path.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 9: Live agentsec ioc-update build osv_rubygems.json

**Files:**
- Create: `src/agentsec/audit/ioc/osv_rubygems.json`

This task requires internet access. OSV-RubyGems is public Google Cloud Storage; no auth tokens.

- [ ] **Step 9.1: Source env if present**

```bash
test -f ~/.config/agentsec/env && source ~/.config/agentsec/env
```

- [ ] **Step 9.2: Run live ioc-update**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/agentsec ioc-update 2>&1 | tail -30
```
Expected: produces `.cache/ioc-update-<YYYY-MM-DD>/proposed-osv_rubygems.json`. May reuse today's cache directory if already populated (the previous 7d.4 ioc-update created `.cache/ioc-update-2026-05-16/`); in that case re-running may or may not refresh — that's OK as long as `proposed-osv_rubygems.json` exists with non-zero size.

- [ ] **Step 9.3: Verify proposed file produced**

```bash
cd /Users/roger/Work/AgentSec && ls -lh .cache/ioc-update-*/proposed-osv_rubygems.json | tail -3
```
Expected: file exists, size 200 KB - 2 MB typically.

If MISSING: re-run ioc-update with stderr captured to debug. STOP BLOCKED if persistent failure.

- [ ] **Step 9.4: Inspect briefly**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python -c "
import json, glob
paths = sorted(glob.glob('.cache/ioc-update-*/proposed-osv_rubygems.json'))
if not paths:
    print('MISSING')
    raise SystemExit(1)
path = paths[-1]
data = json.loads(open(path).read())
print(f'path: {path}')
print(f'entries: {len(data):,}')
if data:
    sample = data[0]
    print(f'sample keys: {sorted(sample.keys())}')
    print(f'sample package: {sample.get(\"package\")}')
"
```
Expected: entries > 200; sample has `id`, `package`, `ranges`, `severity` keys.

- [ ] **Step 9.5: Copy to bundled location**

```bash
cd /Users/roger/Work/AgentSec && cp $(ls -t .cache/ioc-update-*/proposed-osv_rubygems.json | head -1) src/agentsec/audit/ioc/osv_rubygems.json
```

- [ ] **Step 9.6: CI guard PASS**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_rubygems.py
```
Expected: PASS, prints entry count and size.

- [ ] **Step 9.7: Full pytest**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -5
```
Expected: ~1792 PASS / 9 skipped (no change — bundled DB is data).

- [ ] **Step 9.8: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc/osv_rubygems.json && git commit -m "$(cat <<'EOF'
feat(7d.5): bundle osv_rubygems.json — first OSV-RubyGems advisory DB

Built via \`agentsec ioc-update\` against live OSV-RubyGems dump.
After the 5-axis filter chain (drop withdrawn / no RubyGems
affected / no range / no CVSS / scored medium-low > 2y), the
bundled DB contains the curated subset for GemSupplyChainAuditCheck.
Refresh periodically via \`agentsec ioc-update\` + replace this file.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 10: ADR-0025 + v0.35.0 docs single commit

**Files:**
- Create: `docs/adr/0025-phase-7d5-ruby-gem-supply-chain.md`
- Modify: `CHANGELOG.md`
- Modify: `ROADMAP.md`
- Modify: `CLAUDE.md`
- Modify: `pyproject.toml`

- [ ] **Step 10.1: Create ADR-0025**

```markdown
# ADR-0025: Phase 7d.5 — Ruby/Gem supply chain audit

* **Status**: Accepted
* **Date**: 2026-05-16
* **Phase**: 7d.5

## Context

7d series (npm / pip / go / rust/cargo / java/maven) shipped 5
OSV-backed supply chain Checks. Ruby/Gem (RubyGems) is one of the
six major server-language ecosystems; adding it completes a
"6-language" milestone (JavaScript / Python / Go / Rust / Java /
Ruby).

Ruby has two notable differences from prior ecosystems:

1. **Lockfile is Bundler's `Gemfile.lock`** — Bundler is the de
   facto standard for Ruby dependency management. The lockfile is a
   text format (not JSON / TOML), with sections like `GEM`, `GIT`,
   `PATH`, `PLATFORMS`, `DEPENDENCIES`. Resolved transitive deps
   live in `GEM > specs:`.

2. **Version semantics are RubyGems-style** — similar to PEP 440 in
   handling pre-release suffixes (`1.0.0.pre.1`, `2.0.0.rc1`,
   `1.0.0.beta`), but not identical. Java/Maven needed a hand-
   written comparator; Ruby is close enough to PEP 440 that we can
   reuse `packaging.version` with simple string preprocessing.

## Decision

1. **Parse `Gemfile.lock` only**. We walk the `GEM > specs:`
   section, skipping `GIT` / `PATH` source sections (out-of-OSV-scope)
   and 6-space-indented transitive constraint lines (not resolved
   deps themselves). Gem names are case-folded to lowercase per
   RubyGems convention.

2. **Reuse `packaging.version` with RubyGems→PEP 440 preprocessing**.
   `_normalize_gem_version` applies simple regex substitutions
   (`.pre.N` → `aN`, `.beta.N` → `bN`, etc.) before delegating to
   `packaging.version.Version`. Zero new dependencies.

3. **Strict basename validator**: `gem_lock_paths` entries must end
   in exactly `Gemfile.lock` (mirrors Cargo.lock strict convention,
   not Maven's loose suffix match — because Bundler enforces this
   canonical filename).

4. **Mirror 7d.4 (java/maven) for everything else**: `OsvRubyGemsFetcher`
   pulling OSV-RubyGems dump, 5-axis filter chain, dedup on
   (id, package), bundled `osv_rubygems.json`, `TI-OSV-RUBYGEMS-CATALOG`
   umbrella TI, CI guard at 15 MB cap.

## Why parse Gemfile.lock and not `gem list --local`

- Gemfile.lock is the canonical Bundler artifact, present in every
  modern Ruby app's git repo.
- `gem list --local` shows the user's globally-installed gems, not
  the app's resolved dependencies. Often a superset including dev
  tools; less precise for app-level CVE audit.
- Bundler's `Gemfile.lock` enforces version pinning and includes
  transitive deps, mirroring Cargo.lock semantics.

## Why packaging.version (PEP 440) and not hand-written comparator

- RubyGems pre-release suffixes (`1.0.0.pre.1` / `.beta` / `.rc1`)
  map cleanly to PEP 440 (`1.0.0a1` / `b0` / `rc1`) via 5 lines of
  regex substitution.
- `packaging` is already a dependency (pulled in for pip ecosystem
  in Phase 7d.1).
- Edge cases (rare RubyGems version strings like `.git.20250101`
  build metadata) are silently dropped (return False from range
  check), which is the safer fallback for a security audit (false
  negative on weird versions is preferable to wrong vulnerability
  attribution).

## Consequences

- New Check (`gem_supply_chain_audit`); total Checks 36 → **37**.
- New bundled DB (`osv_rubygems.json`, expected 200 KB - 2 MB).
- Future RubyGems CVE refresh = re-run `agentsec ioc-update` and
  re-commit `osv_rubygems.json`.
- 6-language milestone reached (JS / Python / Go / Rust / Java /
  Ruby). Future ecosystems (.NET/nuget, swift/spm, php/composer) can
  be added with the same 7d template.

## Alternatives considered

- **Parse `gem list --local` output**: rejected, not the app's
  resolved dep set (see above).
- **Hand-write RubyGems version comparator**: rejected, `packaging`
  already covers 99% of real-world cases with minimal bridging.
- **Strict `pkg ==N` form (à la pip)**: rejected, Bundler's
  Gemfile.lock is the natural Ruby equivalent.

## References

- Spec: `docs/superpowers/specs/2026-05-16-phase-7d5-ruby-gem-supply-chain-design.md`
- Plan: `docs/superpowers/plans/2026-05-16-phase-7d5-ruby-gem-supply-chain.md`
- ADR-0012: Phase 7d npm
- ADR-0013: Phase 7d.1 pip
- ADR-0014: Phase 7d.2 go
- ADR-0015: Phase 7d.3 rust/cargo
- ADR-0024: Phase 7d.4 java/maven
- OSV RubyGems ecosystem: https://osv.dev/list?ecosystem=RubyGems
- Bundler Gemfile.lock format: https://bundler.io/v2.4/man/gemfile.5.html
```

- [ ] **Step 10.2: Update pyproject.toml**

Find `version = "0.34.0"`, replace with `version = "0.35.0"`.

- [ ] **Step 10.3: Add CHANGELOG entry**

At top of `CHANGELOG.md`, above v0.34.0:

```markdown
## v0.35.0 — 2026-05-16

**Phase 7d.5 — Ruby/Gem supply chain audit (6th ecosystem; completes
6-language coverage milestone).**

- New Check `gem_supply_chain_audit` —
  `src/agentsec/audit/checks/gem_supply_chain_audit.py`. Reads
  operator-configured Gemfile.lock files (via `--gem-lock-path` /
  `server_audit.gem_lock_paths` config), matches each (gem, version)
  against bundled `osv_rubygems.json` using `packaging.version`
  (PEP 440) ranges with RubyGems→PEP 440 string preprocessing.
  Total Checks: 36 → **37**.
- New `OsvRubyGemsFetcher` —
  `src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py`. Pulls
  https://osv-vulnerabilities.storage.googleapis.com/RubyGems/all.zip,
  5-axis filter chain, runs in parallel with the other 5 OSV
  fetchers via `asyncio.gather` (6-way).
- New bundled DB `src/agentsec/audit/ioc/osv_rubygems.json` + CI
  guard `scripts/check_osv_rubygems.py` (≤ 15 MB cap).
- New umbrella TI `TI-OSV-RUBYGEMS-CATALOG` in `threat_intel.yaml`.
- New `parse_gemfile_lock` / `_safe_parse_gem_version` /
  `_is_gem_version_in_range` in `_supply_chain_common.py`. Walks
  Bundler `GEM > specs:` section, skips `GIT` / `PATH` source
  sections and 6-space-indented transitive constraints. Bridges
  RubyGems version semantics to PEP 440 via simple regex
  preprocessing (zero new deps).
- New `ServerAuditConfig.gem_lock_paths` + validator (strict
  basename match: must equal `Gemfile.lock`).
- New ADR-0025 records the design (Gemfile.lock vs gem-list,
  packaging.version reuse vs hand-written, strict basename).
- Test count: 1756 → ~1797 (+~41 new unit tests).
- Zero changes to other 5 supply chain Checks; zero changes to
  Adapter / Judge / Scoring / Report renderer.
- **6-language coverage milestone**: JavaScript / Python / Go /
  Rust / Java / **Ruby**.

**Breaking changes**: none.
```

- [ ] **Step 10.4: ROADMAP entry**

```markdown
- **Phase 7d.5** (shipped v0.35.0, 2026-05-16) — Ruby/Gem supply
  chain audit. 6th ecosystem in the series; reuses packaging.version
  (PEP 440) with RubyGems preprocessing; operator points
  --gem-lock-path at a Bundler Gemfile.lock. **6-language coverage
  milestone**.
```

- [ ] **Step 10.5: CLAUDE.md section**

After existing `## Java/Maven supply chain audit (Phase 7d.4, v0.34.0)` section, add:

```markdown
## Ruby/Gem supply chain audit (Phase 7d.5, v0.35.0)

- **`GemSupplyChainAuditCheck`** in `src/agentsec/audit/checks/gem_supply_chain_audit.py` reads operator-configured Bundler `Gemfile.lock` files from `CheckContext.gem_lock_paths` (sourced from `ServerAuditConfig.gem_lock_paths`), parses the text format via `parse_gemfile_lock` (walks `GEM > specs:` section, skips `GIT`/`PATH` source sections and 6-space-indented transitive constraints), and matches each (gem, version) against the bundled `osv_rubygems.json` using `packaging.version` (PEP 440) range matching. Emits one Finding per (gem, version, advisory) match; `threat_refs=["TI-OSV-RUBYGEMS-CATALOG"]`.
- **Bundler `Gemfile.lock`** is the canonical lockfile format — `--gem-lock-path` validator enforces strict basename equality (must equal `Gemfile.lock`, mirroring `Cargo.lock` strict convention).
- **Version comparison via PEP 440 wrapper** in `_supply_chain_common.py`. RubyGems pre-release suffixes (`1.0.0.pre.1` / `2.0.0.rc1` / `1.0.0.beta`) bridge to PEP 440 (`1.0.0a1` / `2.0.0rc1` / `1.0.0b0`) via simple regex preprocessing in `_normalize_gem_version`. Zero new deps (`packaging` already pulled in by pip ecosystem). Unparseable versions return False from range check (safer than misattribution).
- **Gem names are case-folded to lowercase** at parse time. RubyGems is case-insensitive; OSV catalog also uses lowercase.
- **Source filter**: only `GEM` section deps (rubygems.org public source). `GIT` and `PATH` sections are skipped because OSV-RubyGems doesn't cover git source or local-path gems.
- **`OsvRubyGemsFetcher`** mirrors `OsvMavenFetcher` (5-axis filter chain) but pulls `https://osv-vulnerabilities.storage.googleapis.com/RubyGems/all.zip`. Runs as a side pipeline (`_run_osv_rubygems`, parallel to npm/pypi/go/cargo/maven via `asyncio.gather` 6-way).
- **OSV ecosystem string is `"RubyGems"`** (PascalCase, OSV convention).
- **`scripts/check_osv_rubygems.py`** CI guard enforces valid JSON + ≤ 15 MB hard cap (mirrors npm/pypi/go/cargo/maven).
- **Bundled DB**: `src/agentsec/audit/ioc/osv_rubygems.json` (~200 KB - 2 MB depending on filter date).
- **`agentsec server-audit --gem-lock-path <path>`** is repeatable on the standalone CLI; for the `evaluate` flow set `server_audit.gem_lock_paths` in `openclaw-target.yaml`.
- **Total Checks (v0.35.0):** 36 → **37 类**.
- **6-language coverage milestone**: JavaScript (7d) / Python (7d.1) / Go (7d.2) / Rust (7d.3) / Java (7d.4) / **Ruby (7d.5)**.
- **Adding a 7th ecosystem** (.NET/nuget, swift/spm, php/composer): pattern is fully mature — new Check `<eco>_supply_chain_audit` + `osv_<eco>.json` DB + `Osv<Eco>Fetcher` + `TI-OSV-<ECO>-CATALOG`. Version comparator strategy depends: semver-compatible ecosystems (swift/spm) can reuse `semver.Version`; PEP-440-adjacent (composer) can extend the `packaging.version` wrapper pattern; bespoke (nuget's strange version numbering) may need a hand-written comparator like Maven's.

Spec: `docs/superpowers/specs/2026-05-16-phase-7d5-ruby-gem-supply-chain-design.md`.
Plan: `docs/superpowers/plans/2026-05-16-phase-7d5-ruby-gem-supply-chain.md`.
```

- [ ] **Step 10.6: Full pytest + lint + CI guards**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_rubygems.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_maven.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_owasp_coverage.py
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/ tests/ 2>&1 | tail -3
```
Expected: pytest ~1792 PASS / 9 skipped; both check_osv_*.py PASS; check_owasp_coverage.py PASS; ruff clean.

- [ ] **Step 10.7: Single commit**

```bash
cd /Users/roger/Work/AgentSec && git add docs/adr/0025-phase-7d5-ruby-gem-supply-chain.md CHANGELOG.md ROADMAP.md CLAUDE.md pyproject.toml && git commit -m "$(cat <<'EOF'
feat(7d.5): ADR-0025 + v0.35.0 docs

Records design decisions for Phase 7d.5 (Ruby/Gem supply chain
audit, 6th ecosystem in the series): parse Bundler Gemfile.lock
(not gem-list output); reuse packaging.version (PEP 440) with
simple RubyGems→PEP 440 string preprocessing (zero new deps);
strict basename validator (Gemfile.lock canonical). CHANGELOG +
ROADMAP + CLAUDE.md + pyproject bumped to v0.35.0. **6-language
coverage milestone reached** (JS/Python/Go/Rust/Java/Ruby).

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 11: Final review

Dispatch a final reviewer subagent (sonnet, with `<400 words` length cap per 7c.1.y/z lesson) to verify:

- 6 supply chain Check + fetcher templates mirrored consistently
- `parse_gemfile_lock` handles GIT/PATH source skip + transitive constraint skip
- `_is_gem_version_in_range` handles `.pre.N` / `.rc` / `.beta` / standard semver / unparseable fallback
- `osv_rubygems.json` size reasonable; CI guard PASS
- All ~41 new unit tests PASS; baseline 1756 still PASS
- ADR-0025 cites correct prior ADRs (0012/0013/0014/0015/0024) and explains decisions
- CHANGELOG / ROADMAP / CLAUDE.md / pyproject all consistent v0.35.0
- No regressions to other 5 ecosystems
- ID conventions (`gem_lock_paths`, `TI-OSV-RUBYGEMS-CATALOG`, ecosystem string `RubyGems`) consistent

Report APPROVED / NEEDS_FIX with concise blocking issues.

---

## Self-Review Notes

**Spec coverage check**:

| Spec section | Task |
|---|---|
| §2 v1: gem_supply_chain_audit.py | Task 7 |
| §2 v1: osv_rubygems.py fetcher | Task 3 |
| §2 v1: _supply_chain_common.py extensions | Task 1 |
| §2 v1: osv_rubygems.json | Task 9 |
| §2 v1: check_osv_rubygems.py | Task 4 |
| §2 v1: ServerAuditConfig.gem_lock_paths + CheckContext | Task 2 |
| §2 v1: CLI --gem-lock-path | Task 8 |
| §2 v1: TI-OSV-RUBYGEMS-CATALOG | Task 6 |
| §2 v1: ioc-update _run_osv_rubygems 6-way | Task 5 |
| §2 v1: ADR-0025 | Task 10.1 |
| §2 v1: CHANGELOG/ROADMAP/CLAUDE.md/pyproject | Tasks 10.2-10.5 |
| §3.1 Gemfile.lock format + parser | Task 1 |
| §3.2 PEP 440 wrapper | Task 1 |
| §3.3 OsvRubyGemsFetcher | Task 3 |
| §3.4 Check structure | Task 7 |
| §3.5 TI entry | Task 6 |
| §3.6 _run_osv_rubygems CLI wiring | Task 5 |
| §6 testing | Tasks 1, 2, 3, 7 (~41 tests) |
| §7 compatibility / DB build | Task 9 |

All spec sections covered.

**Placeholder scan**: Tasks 3 / 7 / 8 instruct implementer to "copy git show <sha>" template and substitute — this is an explicit dependency on shipped 7d.4 commits as canonical reference, not a placeholder. Implementer should `git show` to retrieve the literal code.

**Type consistency**: `gem_lock_paths` used uniformly (config / CheckContext / CLI flag / validator). `TI-OSV-RUBYGEMS-CATALOG` uniform. `osv_rubygems.json` filename uniform.

**Critical invariant** (commit ordering): Tasks 1-8 add code without DB; Task 9 builds DB and runs full pytest (catches integration regressions); Task 10 finalizes docs.

---

## Post-Implementation Verification

After all 11 tasks land, run on `main`:

```bash
.venv/bin/pytest tests/
.venv/bin/python scripts/check_osv_rubygems.py
.venv/bin/python scripts/check_osv_maven.py
.venv/bin/python scripts/check_owasp_coverage.py
.venv/bin/ruff check src/ tests/
git log --oneline -12
git status
.venv/bin/agentsec server-audit --help | grep gem
```

Expected:
- pytest: ~1797 PASS / 9 skipped
- check_osv_rubygems.py: PASS
- check_osv_maven.py: PASS (no regression)
- check_owasp_coverage.py: PASS
- ruff: clean
- git log: 10+ new commits at HEAD
- git status: clean
- `--gem-lock-path` in help

If pytest count drifts beyond +~41, investigate.
