# Phase 7f.x cleanup Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Pay down two pieces of 7f-era technical debt: migrate the 3 original Docker Checks from direct `Finding(...)` construction to `self.make_finding(ctx, ...)` (so future Redactor patterns auto-cover them), and rename the runtime-agnostic `TI-DOCKER-IMAGE-*` namespace to `TI-CONTAINER-IMAGE-*` (so `evidence.runtime=podman` findings no longer reference a docker-namespaced TI).

**Architecture:** Two independent debt blocks landed in one phase. Block A (make_finding migration) is per-Check incremental: change Check's `_emit` helper signature to take `ctx`, swap `Finding(...)` → `self.make_finding(ctx, ...)`, update test fixture `redactor=None` → `redactor=Redactor()` so the new method's `ctx.redactor.redact()` call has something to invoke. Block B (TI rename) is a single coordinated edit across `threat_intel.yaml` (8 ids), `container_baseline.yaml` (9 `threat_refs` entries), `_docker_common._image_ti_prefix` constant, and 3 test assertions. CI guards (`check_threat_refs.py` + `build_cve_db.py --check`) catch any miss.

**Tech Stack:** Python 3.11+, pytest, ruff, yaml. No new dependencies.

**Spec:** `docs/superpowers/specs/2026-05-13-phase-7fx-cleanup-design.md`

**Branch:** main (per AgentSec workflow — direct push after green tests)

**Base SHA:** `20fdb18` (the spec commit)

---

## Task 1: Migrate `docker_daemon_audit` to `make_finding`

**Files:**
- Modify: `src/agentsec/audit/checks/docker_daemon_audit.py`
- Modify: `tests/test_docker_daemon_audit.py` (fixture only)

Two `Finding(...)` call sites:
- Line ~84: the `daemon-json-missing` info-finding for "daemon.json 不存在或无法读取" (inline literal, not via `_emit`)
- Line ~155: the `_emit(self, rule_id, ...)` helper that all other rules go through

### Steps

- [ ] **Step 1: Verify current test green before edits**

```
.venv/bin/pytest tests/test_docker_daemon_audit.py -v 2>&1 | tail -5
```

Expected: all current tests pass. Record the count.

- [ ] **Step 2: Update test fixture to use real Redactor**

In `tests/test_docker_daemon_audit.py`, find the `_ctx(executor)` helper (around line 41). The CheckContext construction currently uses `redactor=None`. Change to a real `Redactor()` instance.

Find:

```python
from agentsec.audit.types import RunResult
```

If `Redactor` is not already imported, add:

```python
from agentsec.audit.redactor import Redactor
```

(Place the import in alphabetical order among the existing `agentsec.audit.*` imports.)

Then in `_ctx`:

```python
def _ctx(executor):
    profile = materialize_paths(LINUX, "/home/u")
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=None, profile=profile, log_review_config=None,
    )
```

(If the existing function signature is slightly different, only change the `redactor=None` to `redactor=Redactor()` and add the import — keep the rest as-is.)

- [ ] **Step 3: Run tests — should still pass (sanity check)**

```
.venv/bin/pytest tests/test_docker_daemon_audit.py -v 2>&1 | tail -5
```

Expected: same pass count as Step 1. `redactor=Redactor()` with no rule-text inputs containing keys is a no-op.

- [ ] **Step 4: Migrate the inline `daemon-json-missing` finding**

In `src/agentsec/audit/checks/docker_daemon_audit.py`, find the block (around lines ~84-91) that emits the `daemon-json-missing` info finding. The current code looks like:

```python
            findings.append(Finding(
                check=self.id, severity="info",
                title="Docker daemon.json 不存在或无法读取",
                description="daemon.json 缺失意味所有配置走默认值。",
                evidence={"rule_id": "daemon-json-missing", "path": "/etc/docker/daemon.json"},
                remediation="如需自定义安全策略，创建 /etc/docker/daemon.json。",
                threat_refs=[],
            ))
```

Replace with (note: needs `ctx` in scope — it already is inside `run(self, ctx)`):

```python
            findings.append(self.make_finding(
                ctx, severity="info",
                title="Docker daemon.json 不存在或无法读取",
                description="daemon.json 缺失意味所有配置走默认值。",
                evidence={"rule_id": "daemon-json-missing", "path": "/etc/docker/daemon.json"},
                remediation="如需自定义安全策略，创建 /etc/docker/daemon.json。",
                threat_refs=[],
            ))
```

- [ ] **Step 5: Migrate the `_emit` helper**

Same file, find the `_emit` helper (around line ~152):

```python
    def _emit(self, rule_id: str, *, evidence: dict) -> Finding:
        rule = self._rules[rule_id]
        evidence_with_id = {"rule_id": rule_id, **evidence}
        return Finding(
            check=self.id,
            severity=rule["severity"],
            title=rule["title"],
            description=rule["description"],
            evidence=evidence_with_id,
            remediation=rule["remediation"],
            threat_refs=rule["threat_refs"],
        )
```

Change signature to take `ctx` as the first positional after `self`, and return via `make_finding`:

```python
    def _emit(self, ctx: CheckContext, rule_id: str, *, evidence: dict) -> Finding:
        rule = self._rules[rule_id]
        evidence_with_id = {"rule_id": rule_id, **evidence}
        return self.make_finding(
            ctx,
            severity=rule["severity"],
            title=rule["title"],
            description=rule["description"],
            evidence=evidence_with_id,
            remediation=rule["remediation"],
            threat_refs=list(rule["threat_refs"]),
        )
```

- [ ] **Step 6: Update all `self._emit(...)` call sites in this file**

In the same file, find every call to `self._emit(...)` and prepend `ctx` as the first argument. There are 5 such sites in `docker_daemon_audit.py` (the 5 rule-evaluation branches inside `run`). Each one currently looks like:

```python
            findings.append(self._emit("daemon-tls-exposed", evidence={
                "hosts": hosts, "tlsverify": tlsverify,
            }))
```

Change to:

```python
            findings.append(self._emit(ctx, "daemon-tls-exposed", evidence={
                "hosts": hosts, "tlsverify": tlsverify,
            }))
```

Repeat for all 5 sites: `daemon-tls-exposed`, `daemon-userns-off`, `daemon-no-new-priv`, `daemon-live-restore`, `daemon-log-unbounded`, `daemon-version-cve`. (6 rules — adjust count if file structure is slightly different.) Use grep to confirm zero occurrences of `self._emit(` without `ctx` remain.

- [ ] **Step 7: Run tests + ruff**

```
.venv/bin/pytest tests/test_docker_daemon_audit.py -v 2>&1 | tail -10
.venv/bin/ruff check src/agentsec/audit/checks/docker_daemon_audit.py tests/test_docker_daemon_audit.py
```

Expected: all tests pass, ruff clean.

- [ ] **Step 8: Verify no `Finding(` imports / construction remain in this file**

```
grep -n "Finding(" src/agentsec/audit/checks/docker_daemon_audit.py
```

Expected: zero matches (the `from ..findings import Finding` import is still needed for the return-type annotation on `_emit`).

```
grep -n "from ..findings import Finding" src/agentsec/audit/checks/docker_daemon_audit.py
```

Expected: one match — the import line for the annotation. Leave it.

- [ ] **Step 9: Commit**

```bash
git add src/agentsec/audit/checks/docker_daemon_audit.py \
        tests/test_docker_daemon_audit.py
git commit -m "$(cat <<'EOF'
refactor(7f.x.cleanup): docker_daemon_audit migrate to make_finding

Swap 2 direct Finding(...) construction sites (inline daemon-json-missing
+ _emit helper) for self.make_finding(ctx, ...). Future Redactor patterns
will now auto-cover this Check. Test fixture changed redactor=None →
Redactor() so the new code path has a redactor to call.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: Migrate `docker_runtime_audit` to `make_finding`

**Files:**
- Modify: `src/agentsec/audit/checks/docker_runtime_audit.py`
- Modify: `tests/test_docker_runtime_audit.py` (fixture only)

Two `Finding(...)` call sites:
- Line ~64: inline `runtime-container-count-truncated` info-finding
- Line ~186: `_emit(self, rule_id, meta, extra)` helper

### Steps

- [ ] **Step 1: Sanity test pass count**

```
.venv/bin/pytest tests/test_docker_runtime_audit.py -v 2>&1 | tail -5
```

Record the pass count.

- [ ] **Step 2: Update test fixture redactor**

Same pattern as Task 1. In `tests/test_docker_runtime_audit.py` around line 41 the `_ctx(executor)` helper has `redactor=None`. Add `from agentsec.audit.redactor import Redactor` in the imports (alphabetical order) and change `redactor=None` → `redactor=Redactor()`.

- [ ] **Step 3: Run tests to verify fixture change is non-breaking**

```
.venv/bin/pytest tests/test_docker_runtime_audit.py -v 2>&1 | tail -5
```

Expected: same pass count as Step 1.

- [ ] **Step 4: Migrate the inline truncation finding**

In `src/agentsec/audit/checks/docker_runtime_audit.py` around lines ~63-75, the truncation finding currently looks like:

```python
        if len(containers) > _MAX_CONTAINERS:
            findings.append(Finding(
                check=self.id, severity="info",
                title=f"容器数量异常多：{len(containers)} 个，仅遍历前 {_MAX_CONTAINERS}",
                description="本次审计因容器数量超过阈值已截断。",
                evidence={
                    "rule_id": "runtime-container-count-truncated",
                    "total_count": len(containers),
                    "scanned_count": _MAX_CONTAINERS,
                },
                remediation="减少同主机容器数量，或在 issue 中反馈调高阈值。",
                threat_refs=[],
            ))
```

Replace with `self.make_finding(ctx, ...)`:

```python
        if len(containers) > _MAX_CONTAINERS:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"容器数量异常多：{len(containers)} 个，仅遍历前 {_MAX_CONTAINERS}",
                description="本次审计因容器数量超过阈值已截断。",
                evidence={
                    "rule_id": "runtime-container-count-truncated",
                    "total_count": len(containers),
                    "scanned_count": _MAX_CONTAINERS,
                },
                remediation="减少同主机容器数量，或在 issue 中反馈调高阈值。",
                threat_refs=[],
            ))
```

- [ ] **Step 5: Migrate `_emit` + propagate ctx through `_evaluate_container`**

In the same file, the call chain is `run(ctx)` → `_evaluate_container(c, detail)` → `_emit(rule_id, meta, extra)`. Both helpers need `ctx` propagated.

Find `_evaluate_container` (around line 99):

```python
    def _evaluate_container(
        self, summary: dict[str, Any], detail: dict[str, Any],
    ) -> list[Finding]:
```

Change to:

```python
    def _evaluate_container(
        self, ctx: CheckContext, summary: dict[str, Any], detail: dict[str, Any],
    ) -> list[Finding]:
```

Update the single call site inside `run` (around line 95):

```python
            findings.extend(self._evaluate_container(c, detail))
```

→

```python
            findings.extend(self._evaluate_container(ctx, c, detail))
```

Find `_emit` (around line 181):

```python
    def _emit(
        self, rule_id: str, meta: dict[str, Any], extra: dict[str, Any],
    ) -> Finding:
        rule = self._rules[rule_id]
        evidence = {"rule_id": rule_id, **meta, **extra}
        return Finding(
            check=self.id,
            severity=rule["severity"],
            title=f"{rule['title']}（{meta.get('image', '')} / {meta.get('names', '')}）",
            description=rule["description"],
            evidence=evidence,
            remediation=rule["remediation"],
            threat_refs=rule["threat_refs"],
        )
```

Change to:

```python
    def _emit(
        self, ctx: CheckContext, rule_id: str, meta: dict[str, Any], extra: dict[str, Any],
    ) -> Finding:
        rule = self._rules[rule_id]
        evidence = {"rule_id": rule_id, **meta, **extra}
        return self.make_finding(
            ctx,
            severity=rule["severity"],
            title=f"{rule['title']}（{meta.get('image', '')} / {meta.get('names', '')}）",
            description=rule["description"],
            evidence=evidence,
            remediation=rule["remediation"],
            threat_refs=list(rule["threat_refs"]),
        )
```

- [ ] **Step 6: Update all `self._emit(...)` call sites inside `_evaluate_container`**

There are 6 call sites inside `_evaluate_container` (privileged / host-net / sock-mount / host-fs-mount / root-user / cap-dangerous × N / no-new-priv-missing). Each currently looks like:

```python
            out.append(self._emit("runtime-privileged", meta, {
                "hit_field": "HostConfig.Privileged", "hit_value": True,
            }))
```

Change to:

```python
            out.append(self._emit(ctx, "runtime-privileged", meta, {
                "hit_field": "HostConfig.Privileged", "hit_value": True,
            }))
```

Use grep to confirm zero unconverted call sites:

```
grep -n "self\._emit(" src/agentsec/audit/checks/docker_runtime_audit.py
```

Every match must show `self._emit(ctx, ...` not `self._emit("...`.

- [ ] **Step 7: Run tests + ruff**

```
.venv/bin/pytest tests/test_docker_runtime_audit.py -v 2>&1 | tail -10
.venv/bin/ruff check src/agentsec/audit/checks/docker_runtime_audit.py tests/test_docker_runtime_audit.py
```

Expected: all pass, ruff clean.

- [ ] **Step 8: Verify no remaining `Finding(` construction**

```
grep -n "Finding(" src/agentsec/audit/checks/docker_runtime_audit.py
```

Expected: zero matches.

- [ ] **Step 9: Commit**

```bash
git add src/agentsec/audit/checks/docker_runtime_audit.py \
        tests/test_docker_runtime_audit.py
git commit -m "$(cat <<'EOF'
refactor(7f.x.cleanup): docker_runtime_audit migrate to make_finding

Swap 2 direct Finding(...) construction sites (inline count-truncated
info finding + _emit helper) for self.make_finding(ctx, ...).
_evaluate_container threaded ctx through to _emit. Test fixture moved
redactor=None → Redactor().

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Migrate `docker_image_cve` to `make_finding`

**Files:**
- Modify: `src/agentsec/audit/checks/docker_image_cve.py`
- Modify: `tests/test_docker_image_cve.py` (fixture only)

Single `Finding(...)` site at line ~68 — inline inside the `for entry in self._patterns` loop. No `_emit` helper.

### Steps

- [ ] **Step 1: Sanity test pass count**

```
.venv/bin/pytest tests/test_docker_image_cve.py -v 2>&1 | tail -5
```

Record the pass count.

- [ ] **Step 2: Update test fixture redactor**

In `tests/test_docker_image_cve.py` around line 34, change `redactor=None` to `redactor=Redactor()`. Add the import:

```python
from agentsec.audit.redactor import Redactor
```

(alphabetical order in the agentsec.audit.* import block.)

- [ ] **Step 3: Verify fixture change non-breaking**

```
.venv/bin/pytest tests/test_docker_image_cve.py -v 2>&1 | tail -5
```

Expected: same pass count as Step 1.

- [ ] **Step 4: Migrate the inline finding construction**

In `src/agentsec/audit/checks/docker_image_cve.py` around lines ~68-81:

```python
                if fnmatch.fnmatchcase(image, entry["pattern"]):
                    findings.append(Finding(
                        check=self.id,
                        severity=entry["severity"],
                        title=f"{entry['title']}（{image}）",
                        description=entry["description"],
                        evidence={
                            "container_id": cid,
                            "image": image,
                            "names": names,
                            "pattern": entry["pattern"],
                        },
                        remediation=entry["remediation"],
                        threat_refs=entry["threat_refs"],
                    ))
```

Replace with:

```python
                if fnmatch.fnmatchcase(image, entry["pattern"]):
                    findings.append(self.make_finding(
                        ctx,
                        severity=entry["severity"],
                        title=f"{entry['title']}（{image}）",
                        description=entry["description"],
                        evidence={
                            "container_id": cid,
                            "image": image,
                            "names": names,
                            "pattern": entry["pattern"],
                        },
                        remediation=entry["remediation"],
                        threat_refs=list(entry["threat_refs"]),
                    ))
```

`ctx` is in scope from `run(self, ctx)`. No helper-method signature change needed.

- [ ] **Step 5: Run tests + ruff**

```
.venv/bin/pytest tests/test_docker_image_cve.py -v 2>&1 | tail -10
.venv/bin/ruff check src/agentsec/audit/checks/docker_image_cve.py tests/test_docker_image_cve.py
```

Expected: all pass, ruff clean.

- [ ] **Step 6: Verify no remaining `Finding(` construction**

```
grep -n "Finding(" src/agentsec/audit/checks/docker_image_cve.py
```

Expected: zero matches.

- [ ] **Step 7: Verify all three Docker Checks are now `Finding(`-free**

```
grep -n "Finding(" src/agentsec/audit/checks/docker_daemon_audit.py \
                   src/agentsec/audit/checks/docker_runtime_audit.py \
                   src/agentsec/audit/checks/docker_image_cve.py
```

Expected: zero matches across all three.

- [ ] **Step 8: Commit**

```bash
git add src/agentsec/audit/checks/docker_image_cve.py \
        tests/test_docker_image_cve.py
git commit -m "$(cat <<'EOF'
refactor(7f.x.cleanup): docker_image_cve migrate to make_finding

Final 7f Docker Check moved off direct Finding(...) construction.
All 3 Docker Checks now use self.make_finding(ctx,...) and are auto-
covered by future Redactor pattern updates. Test fixture redactor
moved from None → Redactor().

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: TI namespace rename — `TI-DOCKER-IMAGE-*` → `TI-CONTAINER-IMAGE-*`

**Files:**
- Modify: `src/agentsec/audit/ioc/threat_intel.yaml` (8 `id` fields)
- Modify: `src/agentsec/audit/checks/container_baseline.yaml` (9 `threat_refs` entries)
- Modify: `src/agentsec/audit/checks/_docker_common.py` (1 prefix constant + comments)
- Modify: `tests/test_docker_common.py` (2 assertions)
- Modify: `tests/test_docker_image_cve.py` (1 assertion)
- Modify: `src/agentsec/audit/ioc/cve_database.json` (regenerate)

The 8 ids being renamed:

```
TI-DOCKER-IMAGE-LATEST       → TI-CONTAINER-IMAGE-LATEST
TI-DOCKER-IMAGE-PYTHON2-EOL  → TI-CONTAINER-IMAGE-PYTHON2-EOL
TI-DOCKER-IMAGE-NODE-EOL     → TI-CONTAINER-IMAGE-NODE-EOL
TI-DOCKER-IMAGE-UBUNTU-EOL   → TI-CONTAINER-IMAGE-UBUNTU-EOL
TI-DOCKER-IMAGE-DEBIAN-EOL   → TI-CONTAINER-IMAGE-DEBIAN-EOL
TI-DOCKER-IMAGE-CENTOS-EOL   → TI-CONTAINER-IMAGE-CENTOS-EOL
TI-DOCKER-IMAGE-ALPINE-OLD   → TI-CONTAINER-IMAGE-ALPINE-OLD
TI-DOCKER-IMAGE-OPENCLAW-DEV → TI-CONTAINER-IMAGE-OPENCLAW-DEV
```

### Steps

- [ ] **Step 1: Update `threat_intel.yaml`**

In `src/agentsec/audit/ioc/threat_intel.yaml`, find each of the 8 entries (each is `- id: TI-DOCKER-IMAGE-X` followed by source/url/observed_at/claim/cvss/etc fields). The 8 entries are contiguous around lines 2857-2933. Use a find-and-replace covering only the `id:` line of each:

```bash
sed -i '' \
  -e 's/^- id: TI-DOCKER-IMAGE-/- id: TI-CONTAINER-IMAGE-/g' \
  src/agentsec/audit/ioc/threat_intel.yaml
```

(macOS sed requires the `''` after `-i`. On Linux drop the `''`.)

Verify exactly 8 ids changed:

```
grep -c "^- id: TI-CONTAINER-IMAGE-" src/agentsec/audit/ioc/threat_intel.yaml
grep -c "^- id: TI-DOCKER-IMAGE-" src/agentsec/audit/ioc/threat_intel.yaml
```

Expected: first command outputs `8`, second outputs `0`.

- [ ] **Step 2: Update `container_baseline.yaml` threat_refs**

In `src/agentsec/audit/checks/container_baseline.yaml`, the image_patterns section (around lines 135-227) has 9 `threat_refs: ["TI-DOCKER-IMAGE-X"]` entries (NODE-EOL appears twice — `node:1[0-4]*` and `node:1[68]*` patterns share the TI id).

```bash
sed -i '' \
  -e 's/"TI-DOCKER-IMAGE-/"TI-CONTAINER-IMAGE-/g' \
  src/agentsec/audit/checks/container_baseline.yaml
```

Verify zero `TI-DOCKER-IMAGE` remain in this file:

```
grep -n "TI-DOCKER-IMAGE" src/agentsec/audit/checks/container_baseline.yaml
```

Expected: empty output.

Verify the 9 new occurrences:

```
grep -c "TI-CONTAINER-IMAGE" src/agentsec/audit/checks/container_baseline.yaml
```

Expected: `9` (8 distinct ids; NODE-EOL referenced twice).

`threat_refs_template:` lines like `"{prefix}-IMAGE-..."` do NOT need editing — the `{prefix}` is rendered at runtime from `_docker_common._image_ti_prefix`, which Task 4 Step 3 below updates.

- [ ] **Step 3: Update `_docker_common._image_ti_prefix`**

In `src/agentsec/audit/checks/_docker_common.py`, find the `_evaluate_image_tag` function (around line 208-248). It contains:

```python
    # Split to avoid static scanner treating the prefix itself as a TI ID ref.
    _image_ti_prefix = "TI-" + "DOCKER"
```

Change to:

```python
    # Split to avoid static scanner treating the prefix itself as a TI ID ref.
    _image_ti_prefix = "TI-" + "CONTAINER"
```

The surrounding docstring (lines ~218-225) currently says:

```python
    """fnmatch image_patterns against `<repo>:<tag>`. Returns Finding kwargs.

    Per spec §4.2, image_patterns TI refs are SHARED across runtimes (image
    content is runtime-agnostic). Uses "TI-" + "DOCKER" prefix when
    threat_refs_template uses {prefix}, regardless of `runtime` arg —
    `runtime` field still populated in evidence for cross-runtime dedupe.

    Note: prefix is computed at call time via string concatenation ("TI-" + "DOCKER")
    so check_threat_refs.py does not treat the construction site as a resolvable ID.
    """
```

Update the two `"TI-" + "DOCKER"` literals in the docstring to `"TI-" + "CONTAINER"`:

```python
    """fnmatch image_patterns against `<repo>:<tag>`. Returns Finding kwargs.

    Per spec §4.2, image_patterns TI refs are SHARED across runtimes (image
    content is runtime-agnostic). Uses "TI-" + "CONTAINER" prefix when
    threat_refs_template uses {prefix}, regardless of `runtime` arg —
    `runtime` field still populated in evidence for cross-runtime dedupe.

    Note: prefix is computed at call time via string concatenation ("TI-" + "CONTAINER")
    so check_threat_refs.py does not treat the construction site as a resolvable ID.
    """
```

- [ ] **Step 4: Update test assertions**

In `tests/test_docker_common.py` around lines 346 and 358:

```python
    assert findings[0]["threat_refs"] == ["TI-DOCKER-IMAGE-LATEST"]
```

→

```python
    assert findings[0]["threat_refs"] == ["TI-CONTAINER-IMAGE-LATEST"]
```

```python
    assert findings[0]["threat_refs"] == ["TI-DOCKER-IMAGE-PYTHON2-EOL"]
```

→

```python
    assert findings[0]["threat_refs"] == ["TI-CONTAINER-IMAGE-PYTHON2-EOL"]
```

In `tests/test_docker_image_cve.py` around line 76:

```python
    assert "TI-DOCKER-IMAGE-PYTHON2-EOL" in py2[0].threat_refs
```

→

```python
    assert "TI-CONTAINER-IMAGE-PYTHON2-EOL" in py2[0].threat_refs
```

- [ ] **Step 5: Regenerate `cve_database.json`**

```
.venv/bin/python scripts/build_cve_db.py
```

If the script processes image-pattern TIs, the JSON will update; otherwise it's a no-op. Either way regenerate and commit.

- [ ] **Step 6: Run full suite to catch any missed references**

```
.venv/bin/pytest tests/ -q 2>&1 | tail -10
.venv/bin/python scripts/check_threat_refs.py
.venv/bin/python scripts/build_cve_db.py --check
```

Expected: all tests pass; `check_threat_refs.py` reports 0 unresolved; `build_cve_db.py --check` shows 0 drift.

If `check_threat_refs.py` flags unresolved `TI-DOCKER-IMAGE-*` references anywhere, grep them and update — they're a remaining gap.

- [ ] **Step 7: Final verification — no stale `TI-DOCKER-IMAGE` references in source/tests/scripts**

```
grep -rn "TI-DOCKER-IMAGE" src/ tests/ scripts/
```

Expected: empty output. (References in `docs/adr/` and `docs/superpowers/` may remain — historical records get the explicit note in Task 5.)

- [ ] **Step 8: Lint**

```
.venv/bin/ruff check src/ tests/
```

Expected: clean.

- [ ] **Step 9: Commit**

```bash
git add src/agentsec/audit/ioc/threat_intel.yaml \
        src/agentsec/audit/ioc/cve_database.json \
        src/agentsec/audit/checks/container_baseline.yaml \
        src/agentsec/audit/checks/_docker_common.py \
        tests/test_docker_common.py \
        tests/test_docker_image_cve.py
git commit -m "$(cat <<'EOF'
refactor(7f.x.cleanup): rename TI-DOCKER-IMAGE-* → TI-CONTAINER-IMAGE-*

Hard rename: image content is runtime-agnostic, so a podman/containerd
finding referencing a docker-namespaced TI was a naming wart. 8 ids in
threat_intel.yaml, 9 threat_refs entries in container_baseline.yaml
(NODE-EOL pattern referenced twice), 1 prefix constant in _docker_common,
and 3 test assertions. No alias preserved — breaking change documented
in CHANGELOG (Task 5). daemon/runtime TI namespaces unchanged (their
findings are runtime-specific).

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: ADR-0020 + CLAUDE.md + CHANGELOG + version bump

**Files:**
- Create: `docs/adr/0020-7fx-cleanup.md`
- Modify: `docs/adr/0018-phase-7f1-podman-containerd-audit.md` (1 historical note)
- Modify: `CLAUDE.md`
- Modify: `CHANGELOG.md`
- Modify: `pyproject.toml`

### Steps

- [ ] **Step 1: Create `docs/adr/0020-7fx-cleanup.md`**

```markdown
# ADR-0020 — Phase 7f.x cleanup (make_finding migration + TI rename)

**Date:** 2026-05-13
**Status:** Accepted

## Context

After 7f / 7f.1 / 7f.1.1, two pieces of accumulated technical debt
warranted a dedicated cleanup phase:

1. **Mixed `Finding(...)` vs `make_finding(ctx, ...)` writing styles.**
   `Check.make_finding` was added in Stage D after the original 7f
   Docker Checks shipped. 7f.1 (podman / containerd Checks) and 7f.1.1
   (containerd_daemon) standardized on the helper. The 3 original 7f
   Docker Checks (`docker_daemon_audit`, `docker_runtime_audit`,
   `docker_image_cve`) still used direct `Finding(...)` construction
   and did NOT pass evidence through the global Redactor. Any future
   provider-token pattern added to `Redactor` would silently fail to
   cover those three Checks.

2. **`TI-DOCKER-IMAGE-*` namespace asymmetry.** image_patterns TIs are
   shared across runtimes (image content is runtime-agnostic — alpine
   3.18 is the same image whether pulled by docker, podman, or
   containerd). 7f.1 noted but deferred the resulting awkward shape:
   a finding with `evidence.runtime == "podman"` references a
   `TI-DOCKER-IMAGE-*` id. Fix: rename to `TI-CONTAINER-IMAGE-*`.

## Decision

1. **Migrate all 3 7f Docker Checks to `self.make_finding(ctx, ...)`.**
   Per-Check incremental commits. Each Check's `_emit` helper takes
   `ctx` as first positional arg; `_evaluate_container` (runtime) is
   threaded the same. Test fixtures change `redactor=None` →
   `redactor=Redactor()` so the new code path has something to invoke.
   No evidence-schema or threat_refs changes. Pure plumbing.

2. **Hard-rename `TI-DOCKER-IMAGE-*` → `TI-CONTAINER-IMAGE-*`.** 8 TI
   ids in `threat_intel.yaml`, 9 `threat_refs` entries in
   `container_baseline.yaml` (NODE-EOL pattern referenced twice), 1
   prefix constant in `_docker_common._image_ti_prefix`. No alias
   mechanism — keeping aliases would mean an `aliased_to` field on
   `threat_intel.yaml`, bidirectional resolution in
   `check_threat_refs.py`, and a forever-debt dragging future renames
   along. v0.x range still tolerates breaking changes; CHANGELOG marks
   this clearly.

3. **`daemon_*` / `runtime` TI namespaces NOT renamed.** Findings
   emitted by those rules are runtime-specific (docker's
   `userns-remap` config knob has no podman equivalent;
   `--privileged` semantics differ). `TI-DOCKER-DAEMON-*`,
   `TI-PODMAN-DAEMON-*`, `TI-CONTAINERD-DAEMON-*`, and the three
   `TI-{DOCKER,PODMAN,CONTAINERD}-RUNTIME-*` namespaces stay.

## Alternatives considered

- **Alias mechanism.** Rejected. Doubles `threat_intel.yaml` entry
  count for image-pattern TIs, complicates `check_threat_refs.py`,
  and turns rename into a sunk-cost forever-debt rather than a
  one-time cost. Hard breaks are cheaper in v0.x.
- **Rename everything to `TI-CONTAINER-*`.** Rejected. Conflates
  runtime-specific findings (which carry useful provenance) with
  runtime-agnostic ones (image content).
- **Migrate `docker_image_cve` to share `_evaluate_image_tag` helper.**
  Rejected. Would drop `evidence.container_id` / `names` fields
  (helper produces only `runtime` / `image` / `pattern_matched`) —
  observability regression. Out of scope.

## Consequences

- Server-audit Check inventory unchanged (still 35 categories).
- Wire-format breaking change: external consumers reading
  `threat_refs` from `findings.json` and matching on
  `TI-DOCKER-IMAGE-*` need to migrate. Documented in CHANGELOG
  v0.20.0 "Breaking" section.
- All 8 docker Checks (`docker_*`, `podman_*`, `containerd_*`,
  `containerd_daemon_audit`) now emit Redactor-cleaned findings
  uniformly.
- Release v0.19.0 → **v0.20.0** (minor bump per 0.x SemVer convention
  for breaking changes).

## References

- Spec: `docs/superpowers/specs/2026-05-13-phase-7fx-cleanup-design.md`
- Plan: `docs/superpowers/plans/2026-05-13-phase-7fx-cleanup.md`
- 7f.1 ADR: `docs/adr/0018-phase-7f1-podman-containerd-audit.md`
- 7f.1.1 ADR: `docs/adr/0019-containerd-daemon-audit.md`
```

- [ ] **Step 2: Add historical note to ADR-0018**

In `docs/adr/0018-phase-7f1-podman-containerd-audit.md`, find the existing line that mentions `TI-DOCKER-IMAGE-*` (around line 47):

```
   shared (TI-DOCKER-IMAGE-*) because image content is runtime-agnostic.
```

Append an inline note (not rewriting history — adding a forward-pointer):

```
   shared (TI-DOCKER-IMAGE-*) because image content is runtime-agnostic.
   (Renamed to TI-CONTAINER-IMAGE-* in v0.20.0 — see ADR-0020.)
```

- [ ] **Step 3: Update `CLAUDE.md`**

Find the "## Container audit (Phase 7f, v0.10.0)" section (or the equivalent header for 7f). Inside the section, find the bullet listing `TI-DOCKER-IMAGE-*` references — likely text such as "image_patterns shared TI prefix `TI-DOCKER-IMAGE-*`". Update to `TI-CONTAINER-IMAGE-*` and add a note `(renamed from TI-DOCKER-IMAGE-* in v0.20.0)`.

Find the "## Podman + Containerd audit (Phase 7f.1, v0.18.0)" section, find the bullet about image_patterns TIs being shared (`Uses "TI-" + "DOCKER" prefix when threat_refs_template uses {prefix}, regardless of runtime arg`). Update to `Uses "TI-" + "CONTAINER" prefix`.

Find the "Total checks" line — keep `35 类` (Check count unchanged). No update needed.

Add a new section heading right after "## Containerd daemon audit (Phase 7f.1.1, v0.19.0)" (immediately before the next "##" heading):

```markdown
## Phase 7f.x cleanup (v0.20.0)

- **All 3 7f Docker Checks (`docker_daemon_audit` / `docker_runtime_audit` / `docker_image_cve`) migrated from direct `Finding(...)` construction to `self.make_finding(ctx, ...)`.** Future Redactor pattern additions (e.g., new provider tokens) now auto-cover these Checks alongside 7f.1 / 7f.1.1 Checks.
- **`TI-DOCKER-IMAGE-*` → `TI-CONTAINER-IMAGE-*` hard rename** (8 ids). image_patterns content is runtime-agnostic — a `runtime=podman` finding should not reference a docker-namespaced TI. `daemon_*` / `runtime` namespaces unchanged (those findings are runtime-specific). Hard rename, no aliases — see ADR-0020.
- **Wire-format breaking change** noted in CHANGELOG v0.20.0. External consumers matching `threat_refs` on `TI-DOCKER-IMAGE-*` need to migrate.
- Total checks: still **35 类** (no Check added / removed).
```

- [ ] **Step 4: Update `CHANGELOG.md`**

Insert at the top, above the existing v0.19.0 entry:

```markdown
## v0.20.0 — 2026-05-13

### Breaking
- TI namespace rename: `TI-DOCKER-IMAGE-*` → `TI-CONTAINER-IMAGE-*` (8 ids).
  External consumers reading `threat_refs` from `findings.json` and matching
  on the old namespace must migrate. `daemon_*` / `runtime` TI namespaces
  unchanged. No alias preserved. See ADR-0020.

### Changed
- 3 original 7f Docker Checks (`docker_daemon_audit`, `docker_runtime_audit`,
  `docker_image_cve`) migrated from direct `Finding(...)` construction to
  `self.make_finding(ctx, ...)`. Future Redactor pattern additions now
  auto-cover them. No evidence-schema or behavior change.
- Per-Check test fixtures changed `redactor=None` → `redactor=Redactor()`
  to satisfy the new `make_finding` codepath.
```

- [ ] **Step 5: Bump version in `pyproject.toml`**

Find `version = "0.19.0"` and change to `version = "0.20.0"`.

- [ ] **Step 6: Run full suite + lint to verify docs don't break anything**

```
.venv/bin/pytest tests/ -q 2>&1 | tail -5
.venv/bin/ruff check src/ tests/
```

Expected: all pass.

- [ ] **Step 7: Commit**

```bash
git add docs/adr/0020-7fx-cleanup.md \
        docs/adr/0018-phase-7f1-podman-containerd-audit.md \
        CLAUDE.md \
        CHANGELOG.md \
        pyproject.toml
git commit -m "$(cat <<'EOF'
docs(7f.x.cleanup): ADR-0020 + CLAUDE.md + CHANGELOG + v0.20.0 bump

ADR-0020 records the two cleanup decisions (make_finding migration +
TI rename) and rationale for no-alias hard rename. CLAUDE.md adds a
v0.20.0 cleanup section noting wire-format breaking change. CHANGELOG
gets a Breaking + Changed block. ADR-0018 gets a forward-pointer note.
pyproject 0.19.0 → 0.20.0.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: Verify sample report drift guard (refresh if needed)

**Files:**
- Possibly modify: `docs/samples/report-2026-04-28/` (refresh, if changed)

The mock fixture doesn't fire image-pattern findings, so no `TI-DOCKER-IMAGE-*` ids appear in the committed sample. The rename should produce no diff. Verify, refresh if needed.

### Steps

- [ ] **Step 1: Run the sample drift guard**

```
.venv/bin/pytest tests/integration/test_openclaw_mock.py::test_committed_sample_matches_pipeline_output -v 2>&1 | tail -5
```

Expected: PASS.

If it passes, no refresh needed — proceed to Task 7.

If it fails (e.g., the committed sample is regenerated by other check changes), refresh:

- [ ] **Step 2 (only if Step 1 failed): Refresh sample**

```
AGENTSEC_REFRESH_SAMPLE=1 .venv/bin/pytest tests/integration/test_openclaw_mock.py::test_openclaw_mock_end_to_end -v 2>&1 | tail -5
```

- [ ] **Step 3 (only if Step 2 ran): Inspect the diff**

```
git diff docs/samples/report-2026-04-28/
```

Confirm changes are limited to whatever drift the cleanup caused. If anything looks wrong (e.g., entirely new finding categories), STOP and report.

- [ ] **Step 4 (only if refresh was needed): Commit**

```bash
git add docs/samples/report-2026-04-28/
git commit -m "$(cat <<'EOF'
test(7f.x.cleanup): refresh committed sample after TI rename

Pure sample drift from the TI-DOCKER-IMAGE-* → TI-CONTAINER-IMAGE-*
rename (and/or other downstream rendering touched by 7f.x cleanup).
No new findings categories.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: Final verify + push + PyPI release

**Files:** None.

### Steps

- [ ] **Step 1: Full test suite**

```
.venv/bin/pytest tests/ -q
```

Expected: all pass.

- [ ] **Step 2: All CI gates**

```
.venv/bin/python scripts/check_threat_refs.py
.venv/bin/python scripts/build_cve_db.py --check
.venv/bin/python scripts/check_owasp_coverage.py
.venv/bin/ruff check src/ tests/ scripts/
```

Expected: all 0-error.

- [ ] **Step 3: Verify no `TI-DOCKER-IMAGE` remain (source / tests / scripts)**

```
grep -rn "TI-DOCKER-IMAGE" src/ tests/ scripts/
```

Expected: empty.

- [ ] **Step 4: Verify `TI-DOCKER-IMAGE` references in docs are limited to ADR/spec/plan historical notes**

```
grep -rn "TI-DOCKER-IMAGE" docs/
```

Expected: matches only in `docs/adr/0018-*.md` (with the forward-pointer note added in Task 5), `docs/adr/0020-*.md`, `docs/superpowers/specs/2026-05-12-phase-7f1-*.md` (historical), `docs/superpowers/plans/2026-05-12-phase-7f1-*.md` (historical), and `docs/superpowers/specs/2026-05-13-phase-7fx-cleanup-design.md` (this phase's spec). Anything else is a missed reference.

- [ ] **Step 5: Push to main**

```
git push
```

Expected: success.

- [ ] **Step 6: Build + PyPI release v0.20.0**

This step builds a release wheel and uploads to PyPI. Run only after Step 5 succeeds. The `~/.pypirc` (0600) holds the project-scoped PyPI token per `reference_agentsec_secrets.md` memory.

```
rm -rf dist/ build/
find . -maxdepth 2 -name "*.egg-info" -type d -exec rm -rf {} +
.venv/bin/python -m build
.venv/bin/twine check dist/*
.venv/bin/twine upload dist/agentsec_eval-0.20.0-py3-none-any.whl dist/agentsec_eval-0.20.0.tar.gz
```

Expected: build succeeds, twine check PASSED, upload completes with `View at: https://pypi.org/project/agentsec-eval/0.20.0/`.

If the operator (user) has not granted `--all-execute` consent yet, STOP here and report the artifacts are ready for upload.

- [ ] **Step 7: Done**

Memory update is post-Task: update
`~/.claude/projects/-Users-roger-Work-AgentSec/memory/MEMORY.md` and the
`project_openclaw_v020_progress.md` entry to reflect v0.20.0 shipped.
This is performed by the orchestrator (controller) in the meta-phase
after the implementer reports DONE on Task 7. Mark as out-of-scope here
for the implementer — they only need to confirm the push succeeded.

---

## Self-Review

### Spec coverage

- §2 In scope:
  - 3 Check make_finding migration → Tasks 1, 2, 3 (one each)
  - TI rename → Task 4
  - ADR-0020 + CLAUDE.md + CHANGELOG + v0.20.0 → Task 5
- §2 Out of scope: not implemented (correct)
- §3.1 make_finding migration code shape → Tasks 1-3 Step 4/5
- §3.2 TI rename table (8 ids) → Task 4 Step 1
- §3.3 File changes → Tasks 1-5 map 1:1
- §3.4 CI gates → Task 7 Step 2
- §3.5 Test increment: spec proposed redactor-passthrough tests, but
  inspection showed 7f.1 / 7f.1.1 didn't add them either. The migration's
  protection is fixture-level: every existing test now runs through a real
  Redactor. **No dedicated passthrough tests** — this is a deliberate
  scope reduction from spec §3.5 (matching 7f.1 pattern). The spec
  acknowledged "structure 参照 7f.1 podman_*_audit 已有的 redactor-passthrough
  测试" but 7f.1 doesn't have such tests; the spec was inaccurate. Track
  as a future cleanup if Redactor pattern coverage becomes a hot area;
  for now, the test_redactor.py unit tests + the integration coverage are
  sufficient.
- §4.1 risks: rename completeness → Task 4 Step 6/7 grep + CI; ctx
  propagation → Tasks 1-3 grep self._emit check; external consumers →
  Task 5 CHANGELOG Breaking section
- §4.2 commit sequence: plan has 6 commits + 1 conditional sample-refresh
  commit, matching spec §4.2's "约 6-8 个 commit" estimate
- §4.3 v0.20.0 minor bump → Task 5 Step 5
- §5 ADR-0020 three decision items → Task 5 Step 1

### Placeholder scan

No `TBD` / `TODO` / `fill in details` / `similar to Task N`. Every code-modifying step has a full code block. Every command step shows the expected output.

### Type consistency

- `_emit(self, ctx, rule_id, ...)` signature consistent across Task 1 + Task 2.
- `_evaluate_container(self, ctx, summary, detail)` signature consistent in Task 2.
- `make_finding(ctx, severity=..., title=..., description=..., evidence=..., remediation=..., threat_refs=list(...))` consistent across Tasks 1, 2, 3 (matches the `Check.make_finding` signature in `src/agentsec/audit/checks/base.py`).
- TI ids `TI-CONTAINER-IMAGE-*` consistent across Task 4 sed targets, baseline yaml ascertation, test assertions, and ADR-0020.
- Version `0.20.0` consistent across pyproject.toml (Task 5), CHANGELOG (Task 5), ADR-0020 (Task 5), and twine upload (Task 7).

### Scope check

6 main commits + 1 conditional sample refresh + 1 ADR commit; fits comfortably in a single plan / single phase.
