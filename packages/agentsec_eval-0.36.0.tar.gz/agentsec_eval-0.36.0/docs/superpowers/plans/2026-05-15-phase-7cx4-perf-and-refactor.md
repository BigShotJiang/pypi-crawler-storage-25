# Phase 7c.x.4 — Perf + Refactor Polish Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Polish `ClaudeMcpClient.run()` after the 7c.x.1–3 multi-server feature build-out: replace sequential `await` loops with `asyncio.gather`, extract three stateless helpers (`_resolve_sampling_per_server` / `_probe_server_capabilities` / `_rebuild_tools_spec`), and strict-check the `sampling_per_server` `"policy"` key. Net effect: `run()` shrinks from ~286 lines to ~210, three independent stateless sub-tasks become testable in isolation, and typos in the new strict-keyed config surface as `KeyError` instead of silently denying.

**Architecture:** Three new module-level helpers in `src/agentsec/mcp_harness/claude_client.py`. `_resolve_sampling_per_server` is pure-sync; `_probe_server_capabilities` and `_rebuild_tools_spec` are async and use `asyncio.gather(return_exceptions=True)` so the existing per-session "Method not found" silent-skip path is preserved while genuine errors propagate to `run()`'s top-level handler. `run()` keeps its public signature; only its internals are restructured.

**Tech Stack:** Python 3.11+ stdlib (`asyncio.gather`, `contextlib.AsyncExitStack`), `mcp` SDK, `pytest` / `pytest-asyncio`.

**Baseline:** main `45131aa`; 1704 tests pass / 9 skipped. Target version: `v0.29.0`.

**Reference spec:** `docs/superpowers/specs/2026-05-15-phase-7cx4-perf-and-refactor-design.md`

---

## File Structure

| File | Role | Touch |
|---|---|---|
| `src/agentsec/mcp_harness/claude_client.py` | Sole production file with new helpers + restructured `run()` | Modify |
| `tests/mcp_harness/test_claude_client.py` | Add 3 helper unit tests | Modify |
| `CHANGELOG.md` | Add v0.29.0 entry | Modify |
| `ROADMAP.md` | Mark 7c.x.4 done | Modify |
| `CLAUDE.md` | Add Phase 7c.x.4 architecture note | Modify |
| `pyproject.toml` | Bump version to 0.29.0 | Modify |

No new files. No fixture / case / suite / report touches.

---

## Task 1: Extract `_resolve_sampling_per_server` (sync helper + strict policy key)

**Files:**
- Modify: `src/agentsec/mcp_harness/claude_client.py` (add helper near line 130, replace inline block at lines 298–313)
- Test: `tests/mcp_harness/test_claude_client.py` (append 3 tests)

### Step 1.1: Write 3 failing unit tests

- [ ] **Step 1.1.1: Append tests to `tests/mcp_harness/test_claude_client.py`**

Append at end of file (after the last existing test):

```python
# ──────────────────────────────────────────────────────────────
# Phase 7c.x.4 — _resolve_sampling_per_server helper unit tests
# ──────────────────────────────────────────────────────────────


def test_resolve_sampling_per_server_dict_overrides_scalar():
    """Servers listed in `sampling_per_server` use dict cfg; servers
    not in dict fall back to scalar kwargs."""
    from agentsec.mcp_harness.claude_client import (
        _resolve_sampling_per_server,
    )

    class _S:
        def __init__(self, n: str) -> None:
            self.name = n

    servers = [_S("a"), _S("b")]
    out = _resolve_sampling_per_server(
        servers,
        sampling_per_server={"a": {"policy": "stub", "response": "X"}},
        sampling_policy="deny",
        sampling_response=None,
    )
    assert out == {
        "a": {"policy": "stub", "response": "X"},
        "b": {"policy": "deny", "response": None},
    }


def test_resolve_sampling_per_server_falls_back_to_scalar_when_dict_is_none():
    """`sampling_per_server=None` ⇒ every server uses scalar kwargs."""
    from agentsec.mcp_harness.claude_client import (
        _resolve_sampling_per_server,
    )

    class _S:
        def __init__(self, n: str) -> None:
            self.name = n

    servers = [_S("a"), _S("b")]
    out = _resolve_sampling_per_server(
        servers,
        sampling_per_server=None,
        sampling_policy="stub",
        sampling_response="SCALAR",
    )
    assert out == {
        "a": {"policy": "stub", "response": "SCALAR"},
        "b": {"policy": "stub", "response": "SCALAR"},
    }


def test_resolve_sampling_per_server_strict_missing_policy_key_raises():
    """A typo'd config dict (no `"policy"` key) raises `KeyError`
    instead of silently defaulting to deny."""
    from agentsec.mcp_harness.claude_client import (
        _resolve_sampling_per_server,
    )

    class _S:
        def __init__(self, n: str) -> None:
            self.name = n

    servers = [_S("a")]
    with pytest.raises(KeyError):
        _resolve_sampling_per_server(
            servers,
            sampling_per_server={"a": {"polciy": "stub"}},  # typo
            sampling_policy="deny",
            sampling_response=None,
        )
```

- [ ] **Step 1.1.2: Run the tests; expect ImportError or `KeyError`-not-raised failure**

Run:
```bash
.venv/bin/pytest tests/mcp_harness/test_claude_client.py::test_resolve_sampling_per_server_dict_overrides_scalar tests/mcp_harness/test_claude_client.py::test_resolve_sampling_per_server_falls_back_to_scalar_when_dict_is_none tests/mcp_harness/test_claude_client.py::test_resolve_sampling_per_server_strict_missing_policy_key_raises -v
```
Expected: 3 FAIL with `ImportError: cannot import name '_resolve_sampling_per_server' from 'agentsec.mcp_harness.claude_client'`.

### Step 1.2: Implement the helper

- [ ] **Step 1.2.1: Add helper after `_record_overflow` (around line 211, before `_build_message_handler`)**

Insert in `src/agentsec/mcp_harness/claude_client.py` immediately after the `_record_overflow` function definition (before `_build_message_handler`):

```python
def _resolve_sampling_per_server(
    servers: list[Server],
    sampling_per_server: dict[str, dict[str, Any]] | None,
    sampling_policy: str,
    sampling_response: str | None,
) -> dict[str, dict[str, Any]]:
    """Build per-server sampling config from the dict-or-scalar inputs.

    Strict on the ``policy`` key — a typo'd config dict raises
    ``KeyError`` immediately instead of silently defaulting to deny.
    ``response`` stays ``.get("response")`` because ``None`` is a valid
    value (deny policy needs no response text).

    7c.x.4: replaces the ~14-line inline block previously sitting at the
    top of ``ClaudeMcpClient.run``.
    """
    effective: dict[str, dict[str, Any]] = {}
    for srv in servers:
        if (
            sampling_per_server is not None
            and srv.name in sampling_per_server
        ):
            cfg = sampling_per_server[srv.name]
            effective[srv.name] = {
                "policy": cfg["policy"],
                "response": cfg.get("response"),
            }
        else:
            effective[srv.name] = {
                "policy": sampling_policy,
                "response": sampling_response,
            }
    return effective
```

- [ ] **Step 1.2.2: Replace the inline block in `run()` (lines 295–313)**

Find this block in `ClaudeMcpClient.run`:

```python
        # 7c.x.3: per-session sampling policy resolution. If caller passed
        # sampling_per_server, look up each server's config; else fall back
        # to scalar kwargs (every server gets the same policy).
        effective_per_server: dict[str, dict[str, Any]] = {}
        for srv in servers:
            if (
                sampling_per_server is not None
                and srv.name in sampling_per_server
            ):
                cfg = sampling_per_server[srv.name]
                effective_per_server[srv.name] = {
                    "policy": cfg.get("policy", "deny"),
                    "response": cfg.get("response"),
                }
            else:
                effective_per_server[srv.name] = {
                    "policy": sampling_policy,
                    "response": sampling_response,
                }
```

Replace with:

```python
        # 7c.x.4: per-session sampling policy resolution extracted to
        # module-level helper. `policy` key is strict (KeyError on typo).
        effective_per_server = _resolve_sampling_per_server(
            servers,
            sampling_per_server,
            sampling_policy,
            sampling_response,
        )
```

- [ ] **Step 1.2.3: Run the 3 new helper tests; expect PASS**

Run:
```bash
.venv/bin/pytest tests/mcp_harness/test_claude_client.py::test_resolve_sampling_per_server_dict_overrides_scalar tests/mcp_harness/test_claude_client.py::test_resolve_sampling_per_server_falls_back_to_scalar_when_dict_is_none tests/mcp_harness/test_claude_client.py::test_resolve_sampling_per_server_strict_missing_policy_key_raises -v
```
Expected: 3 PASS.

- [ ] **Step 1.2.4: Run the full mcp_harness test suite; expect no regression**

Run:
```bash
.venv/bin/pytest tests/mcp_harness/test_claude_client.py -v
```
Expected: All pre-existing tests still PASS + 3 new tests PASS.

### Step 1.3: Commit

- [ ] **Step 1.3.1: Commit**

```bash
git add src/agentsec/mcp_harness/claude_client.py tests/mcp_harness/test_claude_client.py
git commit -m "$(cat <<'EOF'
refactor(7c.x.4): extract _resolve_sampling_per_server with strict policy key

Pulls the ~14-line inline block at the top of ClaudeMcpClient.run into
a pure-sync module-level helper. The `policy` key is now strict — a
typo'd config (e.g. {"polciy": "stub"}) raises KeyError at run() entry
rather than silently defaulting to deny. `response` stays .get() because
None is a valid value for the deny path.

Production caller (ClaudeMcpAdapter) always constructs well-formed dicts;
this change is non-breaking for the only real consumer.

Adds 3 helper unit tests covering dict-override / scalar-fallback /
strict-key-raises.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: Add `_probe_server_capabilities` async helper (concurrent probes)

**Files:**
- Modify: `src/agentsec/mcp_harness/claude_client.py` (add helper near line 583, replace inline loop at lines 369–391)

### Step 2.1: Add concurrent probe helper

- [ ] **Step 2.1.1: Add `asyncio` import**

Edit `src/agentsec/mcp_harness/claude_client.py`. Find:

```python
import contextlib
import copy
import json
```

Replace with:

```python
import asyncio
import contextlib
import copy
import json
```

- [ ] **Step 2.1.2: Add helper after `_server_has_prompts` (around line 582)**

Insert in `src/agentsec/mcp_harness/claude_client.py` after `_server_has_prompts` (before `_dispatch_synthetic`):

```python
async def _probe_server_capabilities(
    sessions: list[tuple[str, Any]],
) -> dict[str, dict[str, bool]]:
    """Concurrently probe every session for resources / prompts
    capability. Each individual probe (`_server_has_resources` /
    `_server_has_prompts`) tolerates a "Method not found" reply by
    returning False — non-tolerated errors propagate.

    7c.x.4: replaces the previous sequential `for srv_name, sess in
    sessions: await _server_has_resources(sess); await
    _server_has_prompts(sess)` loop with one `asyncio.gather` round.
    Result-dict keys cover every server name in `sessions`, in the
    same order.
    """
    probes: list[Any] = []
    for _, sess in sessions:
        probes.append(_server_has_resources(sess))
        probes.append(_server_has_prompts(sess))
    results = await asyncio.gather(*probes)
    capabilities: dict[str, dict[str, bool]] = {}
    for i, (srv_name, _sess) in enumerate(sessions):
        capabilities[srv_name] = {
            "resources": results[i * 2],
            "prompts": results[i * 2 + 1],
        }
    return capabilities
```

- [ ] **Step 2.1.3: Replace the inline probe loop in `run()` (lines 369–391)**

Find this block in `ClaudeMcpClient.run` (right after `tools_spec` is built from the initial `list_tools` round):

```python
                # 7c.x.1: per-server capability probing. Single-server mode
                # registers bare-name synthetic tools (wire-compat with 7c.3);
                # multi-server mode registers `<server>__<synthetic>` prefixed
                # variants per capable server. Multi-server v1 still forbids
                # mutations + sampling at the validator (lifts in 7c.x.2/7c.x.3).
                server_capabilities: dict[str, dict[str, bool]] = {}
                for srv_name, sess in sessions:
                    has_res = await _server_has_resources(sess)
                    has_prm = await _server_has_prompts(sess)
                    server_capabilities[srv_name] = {
                        "resources": has_res, "prompts": has_prm,
                    }
                    if has_res:
                        tools_spec.extend(
                            _prefixed_synthetic_tools(
                                _SYNTHETIC_RESOURCE_TOOLS, srv_name
                            )
                            if add_prefix
                            else _SYNTHETIC_RESOURCE_TOOLS
                        )
                    if has_prm:
                        tools_spec.extend(
                            _prefixed_synthetic_tools(
                                _SYNTHETIC_PROMPT_TOOLS, srv_name
                            )
                            if add_prefix
                            else _SYNTHETIC_PROMPT_TOOLS
                        )
```

Replace with:

```python
                # 7c.x.4: per-server capability probes concurrently via
                # asyncio.gather; synthetic-tool registration follows
                # immediately below.
                server_capabilities = await _probe_server_capabilities(
                    sessions
                )
                for srv_name, _sess in sessions:
                    caps = server_capabilities[srv_name]
                    if caps["resources"]:
                        tools_spec.extend(
                            _prefixed_synthetic_tools(
                                _SYNTHETIC_RESOURCE_TOOLS, srv_name
                            )
                            if add_prefix
                            else _SYNTHETIC_RESOURCE_TOOLS
                        )
                    if caps["prompts"]:
                        tools_spec.extend(
                            _prefixed_synthetic_tools(
                                _SYNTHETIC_PROMPT_TOOLS, srv_name
                            )
                            if add_prefix
                            else _SYNTHETIC_PROMPT_TOOLS
                        )
```

### Step 2.2: Verify + commit

- [ ] **Step 2.2.1: Run the full mcp_harness test suite; expect no regression**

Run:
```bash
.venv/bin/pytest tests/mcp_harness/ -v
```
Expected: all tests PASS (existing end-to-end tests indirectly cover `_probe_server_capabilities` via the multi-server + resources/prompts cases).

- [ ] **Step 2.2.2: Commit**

```bash
git add src/agentsec/mcp_harness/claude_client.py
git commit -m "$(cat <<'EOF'
perf(7c.x.4): _probe_server_capabilities concurrent via asyncio.gather

Replaces the sequential per-session probe loop (2N awaits) with one
asyncio.gather round (2N tasks scheduled concurrently). Resources/prompts
probes for every session are issued in parallel.

The previous code path delegated "Method not found" tolerance to each
probe helper (returning False); gather() preserves that — non-tolerated
exceptions still propagate to run()'s top-level handler.

Result-dict keys cover every server name in order; downstream registration
of synthetic tools (the immediate-next block in run()) reads from the
returned dict and is unchanged in behavior.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Add `_rebuild_tools_spec` async helper (concurrent list_tools, used at both call sites)

**Files:**
- Modify: `src/agentsec/mcp_harness/claude_client.py` (add helper near line 583+, replace inline blocks at lines 347–362 AND 410–456)

### Step 3.1: Add `_rebuild_tools_spec` helper

- [ ] **Step 3.1.1: Add helper after `_probe_server_capabilities` (or anywhere in the helper section)**

Insert in `src/agentsec/mcp_harness/claude_client.py` just after `_probe_server_capabilities`:

```python
async def _rebuild_tools_spec(
    sessions: list[tuple[str, Any]],
    server_capabilities: dict[str, dict[str, bool]],
    add_prefix: bool,
) -> tuple[list[dict[str, Any]], dict[str, list[str]]]:
    """Concurrently `list_tools` every session and rebuild the full
    Anthropic-shape tools spec with `<server>__<tool>` prefix (when
    ``add_prefix`` is True) plus per-server synthetic resource/prompt
    tool registration via :func:`_prefixed_synthetic_tools`.

    Returns ``(new_tools_spec, refreshed_by_server)``. The latter maps
    each server name to the sorted bare tool-name list — used by the
    dirty re-fetch block to populate ``new_tool_names`` on the matching
    ``list_changed`` server_events entries.

    Used at BOTH the initial run() setup AND the dirty re-fetch block —
    single canonical implementation.

    7c.x.4: concurrent via ``asyncio.gather(return_exceptions=True)``.
    A per-session "Method not found" error is silently treated as an
    empty tools list (matches the previous per-session try/except path
    used at initial setup). Any other exception is re-raised so the
    caller's top-level handler can record it.
    """
    refresh_results = await asyncio.gather(
        *[sess.list_tools() for _, sess in sessions],
        return_exceptions=True,
    )
    new_tools_spec: list[dict[str, Any]] = []
    refreshed_by_server: dict[str, list[str]] = {}
    for (srv_name, _sess), refresh in zip(
        sessions, refresh_results, strict=True
    ):
        if isinstance(refresh, BaseException):
            if "Method not found" in str(refresh):
                refreshed_by_server[srv_name] = []
                continue
            raise refresh
        refreshed_by_server[srv_name] = sorted(
            t.name for t in refresh.tools
        )
        for t in refresh.tools:
            tool_name = (
                f"{srv_name}__{t.name}" if add_prefix else t.name
            )
            new_tools_spec.append({
                "name": tool_name,
                "description": t.description or "",
                "input_schema": t.inputSchema,
            })
        caps = server_capabilities[srv_name]
        if caps["resources"]:
            new_tools_spec.extend(
                _prefixed_synthetic_tools(
                    _SYNTHETIC_RESOURCE_TOOLS, srv_name
                )
                if add_prefix
                else _SYNTHETIC_RESOURCE_TOOLS
            )
        if caps["prompts"]:
            new_tools_spec.extend(
                _prefixed_synthetic_tools(
                    _SYNTHETIC_PROMPT_TOOLS, srv_name
                )
                if add_prefix
                else _SYNTHETIC_PROMPT_TOOLS
            )
    return new_tools_spec, refreshed_by_server
```

### Step 3.2: Reorder so initial setup uses the helper

`_rebuild_tools_spec` depends on `server_capabilities` already being known, so the call ordering inside `run()` must change: capability probing must happen BEFORE the initial tools_spec build.

- [ ] **Step 3.2.1: Replace the initial-setup `for srv_name, sess in sessions: try list_tools` block AND the probe-loop block with a single sequence using the two new helpers**

Currently `run()` has, in order:

1. Lines ~347–362: initial `tools_spec` build via per-session `await sess.list_tools()` (sequential, with `Method not found` tolerance)
2. Lines ~369–391: capability probing + synthetic-tool registration onto the same `tools_spec`

Replace **both blocks** (lines roughly 347 through 391, ending right before `messages: list[dict[str, Any]] = [`) with:

```python
                # 7c.x.4: capability probes first (need server_capabilities
                # for synthetic stitching inside _rebuild_tools_spec), then
                # the canonical builder for the initial tools_spec.
                server_capabilities = await _probe_server_capabilities(
                    sessions
                )
                tools_spec, _ = await _rebuild_tools_spec(
                    sessions, server_capabilities, add_prefix,
                )
```

Note: this also subsumes the Task 2.1.3 replacement (the standalone capability-probe block from Task 2 is now folded into the unified pre-loop). If Task 2.1.3 has already landed (its commit is independent), the synthetic-tool registration code remains visible until this step deletes it.

- [ ] **Step 3.2.2: Replace the dirty re-fetch inline block (lines ~410–456)**

Find the entire `if dirty[0]:` block inside the iteration loop. Currently:

```python
                    if dirty[0]:
                        dirty[0] = False
                        triggered_servers = sorted(dirty_servers)
                        dirty_servers.clear()
                        try:
                            new_tools_spec: list[dict[str, Any]] = []
                            refreshed_by_server: dict[str, list[str]] = {}
                            for srv_name, sess in sessions:
                                refresh = await sess.list_tools()
                                refreshed_by_server[srv_name] = sorted(
                                    t.name for t in refresh.tools
                                )
                                for t in refresh.tools:
                                    tool_name = (
                                        f"{srv_name}__{t.name}"
                                        if add_prefix
                                        else t.name
                                    )
                                    new_tools_spec.append({
                                        "name": tool_name,
                                        "description": t.description or "",
                                        "input_schema": t.inputSchema,
                                    })
                                caps = server_capabilities[srv_name]
                                if caps["resources"]:
                                    new_tools_spec.extend(
                                        _prefixed_synthetic_tools(
                                            _SYNTHETIC_RESOURCE_TOOLS, srv_name
                                        )
                                        if add_prefix
                                        else _SYNTHETIC_RESOURCE_TOOLS
                                    )
                                if caps["prompts"]:
                                    new_tools_spec.extend(
                                        _prefixed_synthetic_tools(
                                            _SYNTHETIC_PROMPT_TOOLS, srv_name
                                        )
                                        if add_prefix
                                        else _SYNTHETIC_PROMPT_TOOLS
                                    )
                            tools_spec = new_tools_spec
                            for srv_name in triggered_servers:
                                for evt in reversed(outcome.server_events):
                                    if (
                                        evt.get("kind") == "list_changed"
                                        and evt.get("server") == srv_name
                                        and evt.get("new_tool_names") == []
                                    ):
                                        evt["new_tool_names"] = (
                                            refreshed_by_server[srv_name]
                                        )
                                        break
                        except Exception as exc:  # noqa: BLE001
                            outcome.error = f"tools_relist_failed: {exc}"
```

Replace with:

```python
                    if dirty[0]:
                        dirty[0] = False
                        triggered_servers = sorted(dirty_servers)
                        dirty_servers.clear()
                        try:
                            tools_spec, refreshed_by_server = await (
                                _rebuild_tools_spec(
                                    sessions, server_capabilities, add_prefix,
                                )
                            )
                            for srv_name in triggered_servers:
                                for evt in reversed(outcome.server_events):
                                    if (
                                        evt.get("kind") == "list_changed"
                                        and evt.get("server") == srv_name
                                        and evt.get("new_tool_names") == []
                                    ):
                                        evt["new_tool_names"] = (
                                            refreshed_by_server[srv_name]
                                        )
                                        break
                        except Exception as exc:  # noqa: BLE001
                            outcome.error = f"tools_relist_failed: {exc}"
```

### Step 3.3: Verify + commit

- [ ] **Step 3.3.1: Run the full `tests/mcp_harness/` suite; expect no regression**

Run:
```bash
.venv/bin/pytest tests/mcp_harness/ -v
```
Expected: all tests PASS. The existing multi-server prefix / dirty re-fetch / sampling / synthetic-tool / resources+prompts probe end-to-end tests collectively cover both call sites of `_rebuild_tools_spec`.

- [ ] **Step 3.3.2: Run the full test suite; expect 1707 pass / 9 skip**

Run:
```bash
.venv/bin/pytest tests/ -q
```
Expected: `1707 passed, 9 skipped` (baseline 1704 + 3 new helper unit tests from Task 1).

- [ ] **Step 3.3.3: Commit**

```bash
git add src/agentsec/mcp_harness/claude_client.py
git commit -m "$(cat <<'EOF'
refactor(7c.x.4): unify initial+dirty tools_spec build via _rebuild_tools_spec

Single canonical implementation used at both call sites: initial run()
setup AND the dirty re-fetch block inside the iteration loop. Concurrent
via asyncio.gather(return_exceptions=True); per-session "Method not
found" stays silent-skip (matches the previous initial-setup tolerance),
other exceptions re-raise to the existing top-level handler.

Reorders initial setup so capability probing happens before the
tools_spec build (the helper needs server_capabilities for synthetic
stitching). Behavior identical: every existing multi-server / dirty
re-fetch / resources+prompts end-to-end test still passes.

run() now ~210 lines (was ~286). New helper + the two existing helpers
together carry ~85 lines.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: Cross-ref docstring on `_build_message_handler`

**Files:**
- Modify: `src/agentsec/mcp_harness/claude_client.py:236` (docstring of `_build_message_handler`)

### Step 4.1: Add the reverse cross-ref

- [ ] **Step 4.1.1: Edit the docstring**

Find this trailing line inside `_build_message_handler`'s docstring (currently the last paragraph):

```python
    7c.x.2: per-session handler — each session gets its own handler with
    `server_name` captured in closure; events carry the originating server.
    """
```

Replace with:

```python
    7c.x.2: per-session handler — each session gets its own handler with
    `server_name` captured in closure; events carry the originating server.

    Parallel to :func:`_build_sampling_callback` (7c.x.3): both factories
    take `server_name` and build per-session closures with the same
    `(events, ts_counter)` plumbing; updates to one usually have a
    matching change in the other.
    """
```

- [ ] **Step 4.1.2: Run the smoke test to confirm import still works**

Run:
```bash
.venv/bin/pytest tests/mcp_harness/test_smoke_import.py -v
```
Expected: PASS.

- [ ] **Step 4.1.3: Commit**

```bash
git add src/agentsec/mcp_harness/claude_client.py
git commit -m "$(cat <<'EOF'
docs(7c.x.4): reverse cross-ref _build_message_handler ↔ _build_sampling_callback

Adds a paragraph in _build_message_handler's docstring pointing at the
parallel _build_sampling_callback factory. Both take server_name and
build per-session closures over (events, ts_counter); updates to one
usually need a matching update in the other. Zero functional change.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: Final verification (lint + full test sweep)

### Step 5.1: Lint sweep

- [ ] **Step 5.1.1: Ruff auto-fix**

Run:
```bash
.venv/bin/ruff check src/ tests/ --fix
```
Expected: no remaining issues. If imports got rearranged, accept the auto-sort.

- [ ] **Step 5.1.2: Ruff verify**

Run:
```bash
.venv/bin/ruff check src/ tests/
```
Expected: `All checks passed!`.

### Step 5.2: Full test sweep

- [ ] **Step 5.2.1: Full pytest run**

Run:
```bash
.venv/bin/pytest tests/ -q
```
Expected: `1707 passed, 9 skipped`. Any other count = regression; do NOT proceed.

- [ ] **Step 5.2.2: If ruff auto-fix made changes in Step 5.1.1**

```bash
git status
git diff
git add -u
git commit -m "$(cat <<'EOF'
chore(7c.x.4): ruff auto-sort imports

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

(Skip this step if `git status` was clean after Step 5.1.1.)

---

## Task 6: Version bump, CHANGELOG, ROADMAP, CLAUDE.md, commit, push

### Step 6.1: Bump version

- [ ] **Step 6.1.1: Bump `pyproject.toml`**

Find in `pyproject.toml`:

```toml
version = "0.28.0"
```

Replace with:

```toml
version = "0.29.0"
```

### Step 6.2: Update CHANGELOG.md

- [ ] **Step 6.2.1: Add v0.29.0 entry at the top of CHANGELOG.md (after the title, before the v0.28.0 entry)**

Insert this block:

```markdown
## v0.29.0 — 2026-05-15

### Phase 7c.x.4 — Perf + Refactor Polish

- **`ClaudeMcpClient.run()` 内部重构** — 抽出三个模块级 helper：
  - `_resolve_sampling_per_server` (sync) — 把 ~14 行 effective_per_server 内联块提取为纯函数；同时**严格化** `policy` key（`cfg["policy"]` 替换 `cfg.get("policy", "deny")`），typo 立即 raise `KeyError`，不再 silent-default 到 deny。`response` 仍 `.get()` 因 `None` 是合法值。
  - `_probe_server_capabilities` (async) — 用 `asyncio.gather` 并发探测每个 session 的 resources/prompts capability（vs. 之前的顺序 `await`）
  - `_rebuild_tools_spec` (async) — 单一规范实现，初始 setup + dirty re-fetch 两个 call site 共用；内部用 `asyncio.gather(return_exceptions=True)` 并发 `list_tools`，per-session 「Method not found」静默跳过（匹配既有 initial-setup 容错），其它异常 re-raise 到 `run()` 顶层
- **`run()` 行数** ~286 → ~210（约 -76 行；helpers 共 ~85 行；净增 ~9 行但拆分清晰）
- **`_build_message_handler` docstring 加反向 cross-ref** 指向 `_build_sampling_callback`（对称提醒，零功能）
- **不变量**：`TestCase` / `Observation` / `JudgeRouter._SYSTEM` / `AgentResponse` / `server_events` payload schema / `ClaudeMcpClient.run()` 公开接口全部不变。Adapter / cli / runner / report.py / fixture.py / case.py 零改动；既有 44 case + 1704 baseline test 全部稳态
- **production 路径** — Adapter 永远构造良形 `sampling_per_server` dict，strict `policy` key 检查不会在生产触发
- **测试** +3（仅 `_resolve_sampling_per_server` 单测；`_rebuild_tools_spec` / `_probe_server_capabilities` 通过既有 ~50 end-to-end 测试间接覆盖）
- **延后到 7c.x.5+**：β splice re-fetch、TypedDict `sampling_per_server`、`run()` 进一步拆分

Spec: `docs/superpowers/specs/2026-05-15-phase-7cx4-perf-and-refactor-design.md`
Plan: `docs/superpowers/plans/2026-05-15-phase-7cx4-perf-and-refactor.md`

```

### Step 6.3: Update ROADMAP.md

- [ ] **Step 6.3.1: Find the 7c.x.4 entry and mark it shipped**

Edit `ROADMAP.md`. Find the row / entry for **Phase 7c.x.4** and update its status from `Planned` (or whatever the current marker is) to `Shipped v0.29.0 (2026-05-15)`. If the entry doesn't exist yet, insert one immediately after the 7c.x.3 entry following that entry's formatting.

Run:
```bash
grep -n "7c.x.4\|7c.x.3" ROADMAP.md
```
to confirm where to insert. Match the existing format exactly.

### Step 6.4: Update CLAUDE.md

- [ ] **Step 6.4.1: Add a new "## Phase 7c.x.4 cleanup (v0.29.0)" section to CLAUDE.md**

Append immediately after the existing "## MCP multi-server sampling (Phase 7c.x.3, v0.28.0)" section block, before the "## Project docs" section:

```markdown
## Perf + refactor polish (Phase 7c.x.4, v0.29.0)

- **`_resolve_sampling_per_server`** (sync, module-level) — extracted the ~14-line effective_per_server inline block from `ClaudeMcpClient.run()`. **`policy` key is strict** — typo'd config dict raises `KeyError` immediately; the previous `cfg.get("policy", "deny")` silent-default is gone. `response` stays `.get()` because `None` is a valid value for the deny path. Production `ClaudeMcpAdapter` always builds well-formed dicts so strict-check never fires in prod.
- **`_probe_server_capabilities`** (async, module-level) — 2N capability probes now run via one `asyncio.gather` round instead of `2N` sequential `await`s. Per-probe "Method not found" tolerance stays inside `_server_has_resources` / `_server_has_prompts`.
- **`_rebuild_tools_spec`** (async, module-level) — single canonical implementation used at **both** call sites: initial `run()` setup AND the dirty re-fetch block. Uses `asyncio.gather(return_exceptions=True)` so per-session "Method not found" is silent-skipped (matches the previous initial-setup behavior), other exceptions re-raise. Returns `(new_tools_spec, refreshed_by_server)` — the latter is the bare-name list used to populate `new_tool_names` on matching `list_changed` server_events entries.
- **Initial setup order** reordered — capability probe runs BEFORE the initial tools_spec build (because `_rebuild_tools_spec` needs `server_capabilities` for synthetic stitching).
- **`_build_message_handler` docstring** carries a reverse cross-ref to `_build_sampling_callback`; both factories take `server_name` and build per-session closures, so updates to one usually have a matching change in the other.
- **`run()` size**: ~286 → ~210 lines; helpers ~85 lines. Net +~9 but readability win.
- **Inflight invariants**: `gather(return_exceptions=True)` return order matches input order (Python docs guarantee); `zip(sessions, refresh_results, strict=True)` enforces equal length at runtime.
- **Adding a 4th helper next phase**: candidates remaining inside `run()` are the dirty re-fetch event-populate block + the iteration main loop body. Both touch closure-bound `outcome.error` / `messages` / `tool_use_blocks` etc., so extraction cost is higher; deferred to 7c.x.5+ if a real need surfaces.

Spec: `docs/superpowers/specs/2026-05-15-phase-7cx4-perf-and-refactor-design.md`.
Plan: `docs/superpowers/plans/2026-05-15-phase-7cx4-perf-and-refactor.md`.
```

### Step 6.5: Commit + push

- [ ] **Step 6.5.1: Stage and commit the docs + version bump**

```bash
git add pyproject.toml CHANGELOG.md ROADMAP.md CLAUDE.md
git commit -m "$(cat <<'EOF'
docs(7c.x.4): CHANGELOG + ROADMAP + CLAUDE.md for v0.29.0

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

- [ ] **Step 6.5.2: Verify git status is clean**

Run:
```bash
git status
```
Expected: `nothing to commit, working tree clean`.

- [ ] **Step 6.5.3: Push to main**

Run:
```bash
git push
```
Expected: push succeeds; remote main now points at the v0.29.0 tip.

---

## Self-Review checklist (filled at plan-write time)

- **Spec §2 coverage**:
  - gather list_tools (initial + dirty) → Task 3 (`_rebuild_tools_spec`)
  - gather capability probe → Task 2 (`_probe_server_capabilities`)
  - `_resolve_sampling_per_server` + strict `policy` key → Task 1
  - `_build_message_handler` docstring cross-ref → Task 4
- **Spec §2 deferred items not implemented** (correct, intentional):
  - β splice, TypedDict, run() further split — not in plan
- **Spec §3 architecture**: three helpers added in claude_client.py, all module-level; matches spec
- **Spec §4 error handling**: `return_exceptions=True` + "Method not found" silent-skip — implemented inside `_rebuild_tools_spec`; non-"Method not found" exceptions re-raise; `_resolve_sampling_per_server` strict-key raises `KeyError`. Matches spec table.
- **Spec §5 tests**: 3 helper unit tests in Task 1; end-to-end coverage relies on existing ~50 tests — matches spec "+3 only".
- **Spec §6 compat**: signatures unchanged (verified — `run()` keyword args identical); behavior changes only on typo'd config (production never builds typo'd config).
- **No placeholders**: every code block is concrete; every command has expected output.
- **Type consistency**: `effective_per_server` / `server_capabilities` / `refreshed_by_server` types match across Task 1/2/3 helper signatures and the `run()` call sites that consume them.

End of plan.
