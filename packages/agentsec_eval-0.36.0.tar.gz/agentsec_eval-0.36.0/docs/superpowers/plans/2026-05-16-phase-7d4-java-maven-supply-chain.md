# Phase 7d.4 — Java/Maven Supply Chain Audit Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a 5th ecosystem to the supply chain audit series — Java/Maven. Implement `JavaSupplyChainAuditCheck`, `OsvMavenFetcher`, Maven ComparableVersion comparator, OSV-Maven DB build pipeline, CLI flag, ADR-0024, v0.34.0 docs.

**Architecture:** Mirror Phase 7d.3 (rust/cargo). Two Maven-specific deltas: (1) operator pre-runs `mvn dependency:list -DoutputFile=mvn-deps.txt` (no native lockfile); (2) hand-written Maven `ComparableVersion` comparator (~100 lines) in `_supply_chain_common.py` because Maven version semantics aren't semver. No new third-party deps.

**Tech Stack:** Python; existing `httpx` / `pydantic` / `pytest` / `ruff`. No new packages.

**Baseline:** main `3d83f79`; 1707 tests pass / 9 skipped. Target version: `v0.34.0`.

**Reference spec:** `docs/superpowers/specs/2026-05-16-phase-7d4-java-maven-supply-chain-design.md`

---

## File Structure

| File | Role | Touch |
|---|---|---|
| `src/agentsec/audit/checks/_supply_chain_common.py` | Add Maven comparator + parser | Modify |
| `src/agentsec/audit/checks/java_supply_chain_audit.py` | New `JavaSupplyChainAuditCheck` | **Create** |
| `src/agentsec/audit/ioc_update/fetchers/osv_maven.py` | New `OsvMavenFetcher` | **Create** |
| `src/agentsec/audit/ioc_update/cli.py` | Add `_run_osv_maven` + 5-way gather | Modify |
| `src/agentsec/audit/ioc/osv_maven.json` | Bundled DB (built in Task 9) | **Create** |
| `src/agentsec/audit/ioc/threat_intel.yaml` | Add `TI-OSV-MAVEN-CATALOG` entry | Modify |
| `scripts/check_osv_maven.py` | CI guard | **Create** |
| `src/agentsec/config.py` | Add `maven_lock_paths` field + validator | Modify |
| `src/agentsec/audit/__init__.py` | Add `maven_lock_paths` to CheckContext | Modify |
| `src/agentsec/cli.py` | Add `--maven-lock-path` to `server-audit` + `evaluate` | Modify |
| `tests/test_compare_maven_version.py` | Unit tests for comparator | **Create** |
| `tests/test_parse_maven_dependency_list.py` | Unit tests for parser | **Create** |
| `tests/test_java_supply_chain_audit.py` | Unit tests for Check | **Create** |
| `tests/test_osv_maven_fetcher.py` | Unit tests for fetcher | **Create** |
| `tests/test_config_maven_lock_paths.py` | Unit tests for config validator | **Create** |
| `docs/adr/0024-phase-7d4-java-supply-chain.md` | New ADR | **Create** |
| `CHANGELOG.md` | v0.34.0 entry | Modify |
| `ROADMAP.md` | Mark 7d.4 shipped | Modify |
| `CLAUDE.md` | Add `## Java supply chain audit (Phase 7d.4, v0.34.0)` section | Modify |
| `pyproject.toml` | 0.33.0 → 0.34.0 | Modify |

---

## Task 1: Maven `ComparableVersion` comparator + parser + tests

**Files:**
- Modify: `src/agentsec/audit/checks/_supply_chain_common.py` (append helpers)
- Create: `tests/test_compare_maven_version.py`
- Create: `tests/test_parse_maven_dependency_list.py`

The comparator is the trickiest piece. Hand-written Apache `ComparableVersion` semantics: nested-list tokenization with implicit sub-list at digit↔alpha transitions, qualifier rank table for known qualifiers, padding with zero items for trailing-zero normalization.

- [ ] **Step 1.1: Append Maven helpers to `_supply_chain_common.py`**

Append to `src/agentsec/audit/checks/_supply_chain_common.py`:

```python


# ── Maven ComparableVersion + dependency:list parser (Phase 7d.4) ─────────

# Apache Maven qualifier rank table.
# Known qualifiers get fixed rank; unknown qualifiers rank as (2, lowercase)
# meaning they sort after "sp" (rank 1) lexicographically.
_MAVEN_QUALIFIERS: dict[str, int] = {
    "alpha": -5, "a": -5,
    "beta": -4, "b": -4,
    "milestone": -3, "m": -3,
    "rc": -2, "cr": -2,
    "snapshot": -1,
    "": 0, "final": 0, "ga": 0, "release": 0,
    "sp": 1,
}


def _maven_qualifier_rank(s: str) -> tuple[int, str]:
    """Return (rank, key) for a qualifier string."""
    s = s.lower()
    if s in _MAVEN_QUALIFIERS:
        return (_MAVEN_QUALIFIERS[s], "")
    return (2, s)


# Item types: ("int", int) | ("str", str) | ("list", list)


def _maven_item_is_zero(item) -> bool:
    """Item counts as 'zero' for trailing-zero normalization."""
    kind, val = item
    if kind == "int":
        return val == 0
    if kind == "str":
        return _maven_qualifier_rank(val) == (0, "")
    if kind == "list":
        return not val or all(_maven_item_is_zero(it) for it in val)
    return False


def _tokenize_maven_version(v: str) -> list:
    """Tokenize a Maven version string into a (possibly nested) item list.

    Apache ComparableVersion behavior:
      - '.' is a same-level separator
      - '-' opens a new nested sub-list
      - digit↔alpha transitions implicitly open a new nested sub-list
      - trailing zero items are trimmed at every level (normalize)
    """
    v = (v or "").lower().strip()
    if not v:
        return []

    root: list = []
    stack: list[list] = [root]
    last_kind: str | None = None  # "int" | "str" | None

    i = 0
    n = len(v)
    while i < n:
        c = v[i]
        if c == ".":
            last_kind = None
            i += 1
            continue
        if c == "-":
            new_list: list = []
            stack[-1].append(("list", new_list))
            stack.append(new_list)
            last_kind = None
            i += 1
            continue
        if c.isdigit():
            if last_kind == "str":
                new_list = []
                stack[-1].append(("list", new_list))
                stack.append(new_list)
            j = i
            while j < n and v[j].isdigit():
                j += 1
            stack[-1].append(("int", int(v[i:j])))
            last_kind = "int"
            i = j
            continue
        if c.isalpha():
            if last_kind == "int":
                new_list = []
                stack[-1].append(("list", new_list))
                stack.append(new_list)
            j = i
            while j < n and v[j].isalpha():
                j += 1
            stack[-1].append(("str", v[i:j]))
            last_kind = "str"
            i = j
            continue
        # Unknown character — skip
        i += 1

    # Recursively trim trailing zero items at every level
    def _normalize(items: list) -> None:
        for item in items:
            if item[0] == "list":
                _normalize(item[1])
        while items and _maven_item_is_zero(items[-1]):
            items.pop()

    _normalize(root)
    return root


def _compare_maven_items(a, b) -> int:
    """Compare two items (or one item against None for padding)."""
    if a is None and b is None:
        return 0
    if a is None:
        return -_compare_maven_items(b, None)
    if b is None:
        ak, av = a
        if ak == "int":
            return (av > 0) - (av < 0)
        if ak == "str":
            r, _ = _maven_qualifier_rank(av)
            return (r > 0) - (r < 0)
        if ak == "list":
            return _compare_maven_lists(av, [])
        return 0

    ak, av = a
    bk, bv = b

    if ak == "int" and bk == "int":
        return (av > bv) - (av < bv)
    if ak == "int" and bk == "str":
        return 1
    if ak == "str" and bk == "int":
        return -1
    if ak == "int" and bk == "list":
        return 1
    if ak == "list" and bk == "int":
        return -1
    if ak == "list" and bk == "str":
        return 1
    if ak == "str" and bk == "list":
        return -1
    if ak == "str" and bk == "str":
        ra, ka = _maven_qualifier_rank(av)
        rb, kb = _maven_qualifier_rank(bv)
        if ra != rb:
            return (ra > rb) - (ra < rb)
        return (ka > kb) - (ka < kb)
    if ak == "list" and bk == "list":
        return _compare_maven_lists(av, bv)
    return 0


def _compare_maven_lists(a: list, b: list) -> int:
    """Compare two item lists with padding for shorter one."""
    la, lb = len(a), len(b)
    n = max(la, lb)
    for i in range(n):
        ai = a[i] if i < la else None
        bi = b[i] if i < lb else None
        c = _compare_maven_items(ai, bi)
        if c != 0:
            return c
    return 0


def _compare_maven_version(v1: str, v2: str) -> int:
    """Compare two Maven versions per Apache ComparableVersion semantics.

    Returns -1, 0, or 1 for v1 < v2, v1 == v2, v1 > v2.
    """
    items1 = _tokenize_maven_version(v1)
    items2 = _tokenize_maven_version(v2)
    return _compare_maven_lists(items1, items2)


def _is_maven_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
) -> bool:
    """True iff version satisfies introduced <= version < fixed.

    Either bound may be None: missing introduced means "from 0";
    missing fixed means "no upper bound" (still vulnerable).
    """
    if introduced is not None and _compare_maven_version(introduced, version) > 0:
        return False
    if fixed is not None and _compare_maven_version(version, fixed) >= 0:
        return False
    return True


# Maven dependency:list parser

_MAVEN_DEP_LINE = re.compile(
    r"""
    ^
    (?:\[INFO\]\s*)?       # optional [INFO] prefix
    \s*                     # optional leading whitespace
    ([a-zA-Z0-9._-]+)       # groupId
    :
    ([a-zA-Z0-9._-]+)       # artifactId
    :
    ([a-zA-Z0-9._-]+)       # type (jar/pom/war/...)
    :
    ([a-zA-Z0-9._+-]+)      # version
    :
    (compile|runtime|provided|test|system)   # scope
    \s*$
    """,
    re.VERBOSE,
)

_MAVEN_SCOPE_INCLUDED = {"compile", "runtime", "provided", "test"}


def parse_maven_dependency_list(text: str) -> list[tuple[str, str]]:
    """Parse `mvn dependency:list -DoutputFile=...` text format.

    Returns a list of (coordinate, version) tuples where coordinate
    is `groupId:artifactId` (case-sensitive). Skips lines that don't
    match the 5-segment colon format, or whose scope is `system`/`none`.
    """
    out: list[tuple[str, str]] = []
    for raw_line in text.splitlines():
        m = _MAVEN_DEP_LINE.match(raw_line)
        if not m:
            continue
        group_id, artifact_id, _type, version, scope = m.groups()
        if scope not in _MAVEN_SCOPE_INCLUDED:
            continue
        coord = f"{group_id}:{artifact_id}"
        out.append((coord, version))
    return out
```

Note: `re` module is already imported at top of `_supply_chain_common.py`. If not, add `import re` near the existing imports.

- [ ] **Step 1.2: Verify `re` import**

Run: `head -20 /Users/roger/Work/AgentSec/src/agentsec/audit/checks/_supply_chain_common.py`
If `import re` is missing, add it under existing `import` statements.

- [ ] **Step 1.3: Create `tests/test_compare_maven_version.py`**

Create the file with:

```python
"""Unit tests for Maven ComparableVersion comparator (Phase 7d.4)."""

from __future__ import annotations

import pytest

from agentsec.audit.checks._supply_chain_common import (
    _compare_maven_version,
    _is_maven_version_in_range,
)


@pytest.mark.parametrize(
    "v1,v2,expected",
    [
        # Trailing-zero normalization
        ("1.0", "1.0.0", 0),
        ("1.0.0.0", "1.0", 0),
        # Numeric comparison
        ("2.0", "1.99", 1),
        ("1.10", "1.9", 1),
        # SNAPSHOT < release
        ("1.0-SNAPSHOT", "1.0", -1),
        ("1.0", "1.0-SNAPSHOT", 1),
        # Qualifier order: alpha < beta < milestone < rc < snapshot < "" < sp
        ("1.0-alpha-1", "1.0-beta-1", -1),
        ("1.0-beta-1", "1.0-rc-1", -1),
        ("1.0-rc-1", "1.0-SNAPSHOT", -1),
        ("1.0-SNAPSHOT", "1.0-final", -1),
        ("1.0-final", "1.0-SP1", -1),
        # Unknown qualifier > sp
        ("1.0-foo", "1.0-SP1", 1),
        ("1.0-foo", "1.0", 1),
        # Nested numeric within qualifier
        ("1.0-alpha-1", "1.0-alpha-2", -1),
        ("1.0-alpha-2", "1.0-alpha-10", -1),
        # Alpha shorthand: 1.0a1 == 1.0-alpha-1
        ("1.0a1", "1.0-alpha-1", 0),
        ("1.0b2", "1.0-beta-2", 0),
        ("1.0m3", "1.0-milestone-3", 0),
        # 1.0a1 < 1.0
        ("1.0a1", "1.0", -1),
        # Equality
        ("1.2.3", "1.2.3", 0),
    ],
)
def test_compare_maven_version(v1: str, v2: str, expected: int) -> None:
    assert _compare_maven_version(v1, v2) == expected


@pytest.mark.parametrize(
    "version,introduced,fixed,expected",
    [
        # Standard range hits
        ("1.5.0", "1.0", "2.0", True),
        ("0.9", "1.0", "2.0", False),
        ("2.0", "1.0", "2.0", False),  # fixed is exclusive
        ("1.0", "1.0", "2.0", True),  # introduced is inclusive
        # SNAPSHOT in range
        ("1.0-SNAPSHOT", "1.0-alpha", "1.0", True),
        # Missing bounds
        ("1.5.0", None, "2.0", True),  # no introduced
        ("3.0", None, "2.0", False),
        ("1.5.0", "1.0", None, True),  # no fixed
        ("0.5.0", "1.0", None, False),
        ("1.5.0", None, None, True),  # both missing → vulnerable to all
    ],
)
def test_is_maven_version_in_range(
    version: str, introduced: str | None, fixed: str | None, expected: bool
) -> None:
    assert _is_maven_version_in_range(version, introduced, fixed) is expected
```

- [ ] **Step 1.4: Create `tests/test_parse_maven_dependency_list.py`**

Create with:

```python
"""Unit tests for Maven dependency:list parser (Phase 7d.4)."""

from __future__ import annotations

from agentsec.audit.checks._supply_chain_common import parse_maven_dependency_list


def test_parses_standard_dependency_list_output() -> None:
    text = """[INFO]
[INFO] --- maven-dependency-plugin:2.8:list ---
[INFO]
[INFO]    org.apache.commons:commons-lang3:jar:3.12.0:compile
[INFO]    com.google.guava:guava:jar:31.1-jre:compile
[INFO]    org.springframework:spring-core:jar:5.3.20:provided
[INFO]
[INFO] BUILD SUCCESS
"""
    deps = parse_maven_dependency_list(text)
    assert deps == [
        ("org.apache.commons:commons-lang3", "3.12.0"),
        ("com.google.guava:guava", "31.1-jre"),
        ("org.springframework:spring-core", "5.3.20"),
    ]


def test_includes_test_scope_but_skips_system() -> None:
    text = """[INFO]    org.junit.jupiter:junit-jupiter-api:jar:5.8.2:test
[INFO]    com.sun.tools:tools:jar:1.8.0:system
[INFO]    org.example:lib:jar:1.0:compile
"""
    deps = parse_maven_dependency_list(text)
    coords = [c for c, _ in deps]
    assert "org.junit.jupiter:junit-jupiter-api" in coords  # test included
    assert "com.sun.tools:tools" not in coords  # system skipped
    assert "org.example:lib" in coords  # compile included


def test_handles_no_info_prefix() -> None:
    text = """org.apache.commons:commons-lang3:jar:3.12.0:compile
com.google.guava:guava:jar:31.1-jre:compile
"""
    deps = parse_maven_dependency_list(text)
    assert deps == [
        ("org.apache.commons:commons-lang3", "3.12.0"),
        ("com.google.guava:guava", "31.1-jre"),
    ]


def test_skips_malformed_lines() -> None:
    text = """[INFO] --- header ---
[INFO]    not.a.valid.coord
[INFO]    too:few:segments
[INFO]    org.example:lib:jar:1.0:compile
[INFO]    a:b:c:d:e:f:g
[INFO] random text
"""
    deps = parse_maven_dependency_list(text)
    assert deps == [("org.example:lib", "1.0")]


def test_empty_input_returns_empty() -> None:
    assert parse_maven_dependency_list("") == []
    assert parse_maven_dependency_list("\n\n\n") == []
```

- [ ] **Step 1.5: Run new tests**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_compare_maven_version.py tests/test_parse_maven_dependency_list.py -v
```
Expected: all PASS (~25 test cases).

If FAIL: read error, fix code in `_supply_chain_common.py`, rerun. Common issues:
- `re` module not imported → add `import re`
- Tokenizer edge cases → trace by adding `print(_tokenize_maven_version("..."))` temporarily

- [ ] **Step 1.6: Run lint**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/checks/_supply_chain_common.py tests/test_compare_maven_version.py tests/test_parse_maven_dependency_list.py
```
Expected: PASS.

- [ ] **Step 1.7: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/checks/_supply_chain_common.py tests/test_compare_maven_version.py tests/test_parse_maven_dependency_list.py && git commit -m "$(cat <<'EOF'
feat(7d.4): Maven ComparableVersion comparator + dep:list parser

Hand-write Apache Maven ComparableVersion semantics in
_supply_chain_common.py: nested-list tokenization with implicit
sub-list at digit↔alpha transitions, qualifier rank table
(alpha < beta < milestone < rc < snapshot < "" < sp < unknown),
trailing-zero normalization. ~25 unit tests cover edge cases:
SNAPSHOT < release, alpha shorthand (1.0a1 == 1.0-alpha-1),
range matching with optional bounds.

parse_maven_dependency_list parses `mvn dependency:list` text
format (5-segment colon `groupId:artifactId:type:version:scope`),
including compile/runtime/provided/test scopes, skipping system.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: ServerAuditConfig + CheckContext maven_lock_paths

**Files:**
- Modify: `src/agentsec/config.py` (add field + validator)
- Modify: `src/agentsec/audit/__init__.py` (add CheckContext field)
- Create: `tests/test_config_maven_lock_paths.py`

- [ ] **Step 2.1: Add `maven_lock_paths` to `ServerAuditConfig`**

Modify `src/agentsec/config.py`. Find the `cargo_lock_paths` field and validator (around line 152-170). Add immediately after the `_validate_cargo_lock_paths` method:

```python

    maven_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("maven_lock_paths")
    @classmethod
    def _validate_maven_lock_paths(cls, v: list[str]) -> list[str]:
        from .audit.metachar_guard import contains_shell_metachar

        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"maven_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar(p):
                raise ValueError(
                    f"maven_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if not (
                basename.endswith(".txt")
                or basename.endswith(".list")
                or basename.endswith("-deps.txt")
                or basename.endswith("-list.txt")
                or basename == "dependency-list.txt"
            ):
                raise ValueError(
                    f"maven_lock_paths entry {p!r} basename must end with "
                    f".txt, .list, -deps.txt, -list.txt, or be 'dependency-list.txt'"
                )
        return v
```

- [ ] **Step 2.2: Add `maven_lock_paths` to `CheckContext`**

Modify `src/agentsec/audit/__init__.py`. Find the `CheckContext` dataclass (search for `cargo_lock_paths` field). Add `maven_lock_paths` immediately after, mirroring the existing field:

```python
    maven_lock_paths: list[str] = field(default_factory=list)
```

- [ ] **Step 2.3: Create `tests/test_config_maven_lock_paths.py`**

```python
"""Unit tests for ServerAuditConfig.maven_lock_paths validator (Phase 7d.4)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentsec.config import ServerAuditConfig


def _config(**overrides) -> dict:
    """Minimal valid ServerAuditConfig dict."""
    return {
        "host": "test.example",
        "user": "ubuntu",
        "consent_file": "AUTHORIZATION.txt",
        **overrides,
    }


def test_empty_maven_lock_paths_is_valid() -> None:
    cfg = ServerAuditConfig.model_validate(_config())
    assert cfg.maven_lock_paths == []


def test_accepts_valid_paths() -> None:
    cfg = ServerAuditConfig.model_validate(_config(
        maven_lock_paths=[
            "/opt/myapp/mvn-deps.txt",
            "~/projects/foo/dependency-list.txt",
            "/srv/app/deps.list",
            "/var/build/maven-list.txt",
        ]
    ))
    assert len(cfg.maven_lock_paths) == 4


def test_rejects_relative_path() -> None:
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig.model_validate(_config(
            maven_lock_paths=["mvn-deps.txt"]
        ))


def test_rejects_shell_metachar() -> None:
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig.model_validate(_config(
            maven_lock_paths=["/opt/$INJECT/mvn-deps.txt"]
        ))


def test_rejects_unrecognized_extension() -> None:
    with pytest.raises(ValidationError, match="basename must end with"):
        ServerAuditConfig.model_validate(_config(
            maven_lock_paths=["/opt/myapp/pom.xml"]
        ))
```

- [ ] **Step 2.4: Run new tests**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_config_maven_lock_paths.py -v
```
Expected: all 5 PASS.

- [ ] **Step 2.5: Verify existing tests still pass**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_config.py tests/test_check_context.py 2>/dev/null -q | tail -5
```
Expected: existing tests unchanged. (If `tests/test_check_context.py` doesn't exist, just run `tests/test_config.py`.)

- [ ] **Step 2.6: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/config.py src/agentsec/audit/__init__.py tests/test_config_maven_lock_paths.py && git commit -m "$(cat <<'EOF'
feat(7d.4): add maven_lock_paths to ServerAuditConfig + CheckContext

Operator-configured paths to `mvn dependency:list` output files,
mirrors pip_lock_paths / go_lock_paths / cargo_lock_paths.
Validator: must start with / or ~/, no shell metachars, basename
ends with .txt / .list / -deps.txt / -list.txt or equals
dependency-list.txt (loose vs Cargo.lock strict because Maven
doesn't have a canonical lockfile name).

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: OsvMavenFetcher

**Files:**
- Create: `src/agentsec/audit/ioc_update/fetchers/osv_maven.py`
- Create: `tests/test_osv_maven_fetcher.py`

Mirror `osv_cargo.py` line-by-line; only differences are URL, ecosystem name, and the package name format (`groupId:artifactId` vs single string).

- [ ] **Step 3.1: Create `osv_maven.py`**

Create `src/agentsec/audit/ioc_update/fetchers/osv_maven.py`:

```python
"""OSV-Maven full ecosystem fetcher (Phase 7d.4).

Pulls https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip
and normalizes the included OSV entries to the compact schema
consumed by JavaSupplyChainAuditCheck. Returns a single FetchResult
keyed under '_osv_maven_full' for the cli.py orchestrator.
"""

from __future__ import annotations

import asyncio
import io
import json
import zipfile
from collections.abc import Callable

import httpx

from ..watchlist import WatchlistEntry
from ._supply_chain_common import (
    MEDIUM_LOW_MAX_AGE_DAYS,
    _extract_severity,
    _is_within_age,
)
from .base import Fetcher, FetcherContext, FetchResult, hash_response

OSV_MAVEN_URL = (
    "https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip"
)
RETRY_BACKOFFS = [2, 4, 8]
_HTTP_TIMEOUT = 60


def _extract_maven_ranges(ranges: list[dict]) -> list[dict]:
    """OSV-Maven uses ECOSYSTEM type with Maven version strings."""
    out: list[dict] = []
    for r in ranges:
        if r.get("type") not in ("SEMVER", "ECOSYSTEM"):
            continue
        intro: str | None = None
        fixed: str | None = None
        last: str | None = None
        for ev in r.get("events", []):
            if "introduced" in ev:
                intro = ev["introduced"]
            elif "fixed" in ev:
                fixed = ev["fixed"]
            elif "last_affected" in ev:
                last = ev["last_affected"]
        if intro is None and fixed is None and last is None:
            continue
        entry: dict[str, str] = {}
        if intro is not None:
            entry["introduced"] = intro
        if fixed is not None:
            entry["fixed"] = fixed
        if last is not None:
            entry["last_affected"] = last
        out.append(entry)
    return out


def normalize_osv_entry(entry: dict) -> list[dict]:
    """Normalize one OSV entry to compact records (one per Maven package).

    5-axis filter chain (mirrors npm/pypi/go/cargo):
      1. drop withdrawn
      2. drop no Maven affected
      3. drop no range
      4. drop no CVSS_V3 score
      5. drop scored medium/low > MEDIUM_LOW_MAX_AGE_DAYS old
    """
    if entry.get("withdrawn"):
        return []
    affected = entry.get("affected") or []
    maven_affected = [
        a for a in affected
        if (a.get("package") or {}).get("ecosystem") == "Maven"
    ]
    if not maven_affected:
        return []

    severity_label = _extract_severity(entry)
    if severity_label is None:
        return []

    if severity_label in ("medium", "low"):
        published = entry.get("published")
        if not _is_within_age(published, MEDIUM_LOW_MAX_AGE_DAYS):
            return []

    out: list[dict] = []
    for a in maven_affected:
        package = (a.get("package") or {}).get("name")
        if not package:
            continue
        ranges = _extract_maven_ranges(a.get("ranges") or [])
        if not ranges:
            continue
        record = {
            "id": entry.get("id"),
            "package": package,
            "ranges": ranges,
            "severity": severity_label,
            "summary": entry.get("summary", ""),
            "url": (entry.get("references") or [{}])[0].get("url", ""),
            "aliases": entry.get("aliases") or [],
            "published": entry.get("published"),
        }
        out.append(record)
    return out


class OsvMavenFetcher(Fetcher):
    """OSV-Maven ecosystem dump fetcher."""

    name = "_osv_maven_full"

    async def run(
        self,
        ctx: FetcherContext,
        entries: list[WatchlistEntry],
    ) -> dict[str, FetchResult]:
        client_factory: Callable[..., httpx.AsyncClient] = (
            ctx.client_factory or httpx.AsyncClient
        )
        async with client_factory(timeout=_HTTP_TIMEOUT) as client:
            for backoff in [0] + RETRY_BACKOFFS:
                if backoff:
                    await asyncio.sleep(backoff)
                try:
                    resp = await client.get(OSV_MAVEN_URL)
                    resp.raise_for_status()
                    break
                except httpx.HTTPError as exc:
                    last_exc = exc
                    continue
            else:
                return {
                    self.name: FetchResult(
                        records=[],
                        sha256=None,
                        error=str(last_exc),
                    )
                }

            data = resp.content
            sha = hash_response(data)

            records: list[dict] = []
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                for member in zf.namelist():
                    if not member.endswith(".json"):
                        continue
                    with zf.open(member) as f:
                        try:
                            entry = json.load(f)
                        except json.JSONDecodeError:
                            continue
                        records.extend(normalize_osv_entry(entry))

            # Dedup on (id, package)
            seen: set[tuple[str, str]] = set()
            deduped: list[dict] = []
            for rec in records:
                key = (rec["id"], rec["package"])
                if key in seen:
                    continue
                seen.add(key)
                deduped.append(rec)

            deduped.sort(key=lambda r: (r["package"], r["id"]))

            return {
                self.name: FetchResult(
                    records=deduped,
                    sha256=sha,
                    error=None,
                )
            }
```

- [ ] **Step 3.2: Create `tests/test_osv_maven_fetcher.py`**

```python
"""Unit tests for OsvMavenFetcher (Phase 7d.4)."""

from __future__ import annotations

import io
import json
import zipfile

import httpx
import pytest

from agentsec.audit.ioc_update.fetchers.base import FetcherContext
from agentsec.audit.ioc_update.fetchers.osv_maven import (
    OsvMavenFetcher,
    normalize_osv_entry,
)


def _make_zip(entries: list[dict]) -> bytes:
    """Pack OSV entries into a zip the fetcher can read."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for entry in entries:
            zf.writestr(f"{entry['id']}.json", json.dumps(entry))
    return buf.getvalue()


def test_normalize_keeps_critical_maven_entry() -> None:
    entry = {
        "id": "GHSA-test-1",
        "summary": "Critical RCE in commons-lang3",
        "published": "2025-01-01T00:00:00Z",
        "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        "affected": [
            {"package": {"ecosystem": "Maven", "name": "org.apache.commons:commons-lang3"},
             "ranges": [{"type": "ECOSYSTEM", "events": [
                 {"introduced": "0"}, {"fixed": "3.12.1"}
             ]}]}
        ],
        "references": [{"url": "https://example.com/CVE-2025-0001"}],
    }
    records = normalize_osv_entry(entry)
    assert len(records) == 1
    assert records[0]["package"] == "org.apache.commons:commons-lang3"
    assert records[0]["severity"] == "critical"
    assert records[0]["ranges"] == [{"introduced": "0", "fixed": "3.12.1"}]


def test_normalize_drops_non_maven_affected() -> None:
    entry = {
        "id": "GHSA-x",
        "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        "affected": [
            {"package": {"ecosystem": "npm", "name": "lodash"},
             "ranges": [{"type": "ECOSYSTEM", "events": [{"fixed": "1.0"}]}]}
        ],
    }
    assert normalize_osv_entry(entry) == []


def test_normalize_drops_withdrawn() -> None:
    entry = {
        "id": "x",
        "withdrawn": "2024-01-01T00:00:00Z",
        "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        "affected": [
            {"package": {"ecosystem": "Maven", "name": "x:y"},
             "ranges": [{"type": "ECOSYSTEM", "events": [{"fixed": "1.0"}]}]}
        ],
    }
    assert normalize_osv_entry(entry) == []


@pytest.mark.asyncio
async def test_fetcher_pulls_zip_and_dedups(monkeypatch) -> None:
    entries = [
        {
            "id": "GHSA-A",
            "summary": "RCE",
            "published": "2025-01-01T00:00:00Z",
            "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
            "affected": [
                {"package": {"ecosystem": "Maven", "name": "org.test:lib1"},
                 "ranges": [{"type": "ECOSYSTEM", "events": [{"introduced": "0"}, {"fixed": "1.0"}]}]}
            ],
            "references": [{"url": "https://example.com/A"}],
        },
        {
            "id": "GHSA-B",
            "summary": "XSS",
            "published": "2025-02-01T00:00:00Z",
            "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
            "affected": [
                {"package": {"ecosystem": "Maven", "name": "org.test:lib2"},
                 "ranges": [{"type": "ECOSYSTEM", "events": [{"introduced": "0"}, {"fixed": "2.0"}]}]}
            ],
            "references": [{"url": "https://example.com/B"}],
        },
    ]
    zip_bytes = _make_zip(entries)

    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=zip_bytes)

    transport = httpx.MockTransport(handler)
    factory = lambda **kw: httpx.AsyncClient(transport=transport, **kw)

    ctx = FetcherContext(
        client_factory=factory,
        nvd_api_key=None,
        github_token=None,
    )
    fetcher = OsvMavenFetcher()
    results = await fetcher.run(ctx, entries=[])
    assert "_osv_maven_full" in results
    records = results["_osv_maven_full"].records
    assert len(records) == 2
    packages = {r["package"] for r in records}
    assert packages == {"org.test:lib1", "org.test:lib2"}
```

- [ ] **Step 3.3: Run new tests**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_osv_maven_fetcher.py -v
```
Expected: 4 PASS.

- [ ] **Step 3.4: Run lint**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/ioc_update/fetchers/osv_maven.py tests/test_osv_maven_fetcher.py
```

- [ ] **Step 3.5: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc_update/fetchers/osv_maven.py tests/test_osv_maven_fetcher.py && git commit -m "$(cat <<'EOF'
feat(7d.4): OsvMavenFetcher — pull OSV-Maven full ecosystem dump

Mirrors OsvCargoFetcher: pulls
https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip,
walks every JSON entry, applies the 5-axis filter chain (drop
withdrawn / no Maven affected / no range / no CVSS / scored
medium-low > 2y), expands multi-affected packages, dedups on
(id, package). Tests use httpx.MockTransport.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: scripts/check_osv_maven.py CI guard

**Files:**
- Create: `scripts/check_osv_maven.py`

- [ ] **Step 4.1: Create the script**

```python
#!/usr/bin/env python3
"""CI guard for src/agentsec/audit/ioc/osv_maven.json.

Validates the bundled OSV-Maven advisory DB:
  - File exists
  - Valid JSON (top-level list of advisory dicts)
  - File size <= 15 MB hard cap

Usage:
    python scripts/check_osv_maven.py [--check]

Exits 0 on success, 1 on failure.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "src/agentsec/audit/ioc/osv_maven.json"
SIZE_CAP_BYTES = 15 * 1024 * 1024  # 15 MB


def main() -> int:
    if not DB_PATH.exists():
        print(f"FAIL: {DB_PATH} does not exist", file=sys.stderr)
        return 1

    size = DB_PATH.stat().st_size
    if size > SIZE_CAP_BYTES:
        print(
            f"FAIL: {DB_PATH} is {size:,} bytes, exceeds cap "
            f"{SIZE_CAP_BYTES:,} bytes",
            file=sys.stderr,
        )
        return 1

    try:
        data = json.loads(DB_PATH.read_text())
    except json.JSONDecodeError as exc:
        print(f"FAIL: {DB_PATH} is not valid JSON: {exc}", file=sys.stderr)
        return 1

    if not isinstance(data, list):
        print(
            f"FAIL: {DB_PATH} top-level must be a list, got {type(data).__name__}",
            file=sys.stderr,
        )
        return 1

    print(
        f"OK — {DB_PATH.name} contains {len(data):,} advisories, "
        f"{size:,} bytes (cap {SIZE_CAP_BYTES:,})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 4.2: Make executable**

```bash
cd /Users/roger/Work/AgentSec && chmod +x scripts/check_osv_maven.py
```

- [ ] **Step 4.3: Run it (will FAIL — DB not built yet, that's Task 9)**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_maven.py
```
Expected: FAIL with `does not exist` (the DB will be built in Task 9). This is expected — the script is correct.

- [ ] **Step 4.4: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add scripts/check_osv_maven.py && git commit -m "$(cat <<'EOF'
feat(7d.4): scripts/check_osv_maven.py CI guard

Validates osv_maven.json exists, is valid JSON list, and is under
15 MB cap. Mirrors check_osv_cargo.py / check_osv_pypi.py /
check_osv_go.py / check_osv_npm.py. Fails until Task 9 builds the
bundled DB.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: ioc_update/cli.py — add `_run_osv_maven` + 5-way gather

**Files:**
- Modify: `src/agentsec/audit/ioc_update/cli.py`

- [ ] **Step 5.1: Read existing structure**

```bash
cd /Users/roger/Work/AgentSec && grep -n "_run_osv_cargo\|_run_osv_go\|asyncio.gather" src/agentsec/audit/ioc_update/cli.py
```

This locates the existing `_run_osv_<eco>` functions and the `asyncio.gather` site that runs them in parallel.

- [ ] **Step 5.2: Add `_run_osv_maven` function**

After the existing `_run_osv_cargo` function in `src/agentsec/audit/ioc_update/cli.py`, add:

```python


async def _run_osv_maven(
    ctx: FetcherContext,
    entries: list[WatchlistEntry],
    out_dir: Path,
) -> tuple[str, FetchResult]:
    """Run OsvMavenFetcher and write proposed-osv_maven.json."""
    from .fetchers.osv_maven import OsvMavenFetcher

    fetcher = OsvMavenFetcher()
    results = await fetcher.run(ctx, entries=entries)
    result = results.get("_osv_maven_full") or FetchResult(records=[], sha256=None, error="missing")
    out_path = out_dir / "proposed-osv_maven.json"
    out_path.write_text(json.dumps(result.records, indent=2, sort_keys=True))
    return ("_osv_maven_full", result)
```

(Adjust import paths and signatures to match the existing `_run_osv_cargo` exactly — copy its shape. The above is a sketch; the implementer should mirror the file's existing convention.)

- [ ] **Step 5.3: Add `_run_osv_maven` to the `asyncio.gather` call**

Find the line in `src/agentsec/audit/ioc_update/cli.py` that currently runs all 4 OSV fetchers in parallel (looks like `asyncio.gather(_run_osv_npm(...), _run_osv_pypi(...), _run_osv_go(...), _run_osv_cargo(...))`). Add `_run_osv_maven(ctx, entries, out_dir)` as the 5th argument:

```python
results = await asyncio.gather(
    _run_osv_npm(ctx, entries, out_dir),
    _run_osv_pypi(ctx, entries, out_dir),
    _run_osv_go(ctx, entries, out_dir),
    _run_osv_cargo(ctx, entries, out_dir),
    _run_osv_maven(ctx, entries, out_dir),  # NEW
)
```

- [ ] **Step 5.4: Run lint + existing ioc-update tests**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/ioc_update/cli.py
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/integration/test_ioc_update_offline.py tests/integration/test_ioc_update_mock_http.py -v 2>&1 | tail -10
```
Expected: ruff PASS; existing ioc-update integration tests still PASS (they don't exercise live HTTP).

- [ ] **Step 5.5: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc_update/cli.py && git commit -m "$(cat <<'EOF'
feat(7d.4): ioc-update — wire OsvMavenFetcher into 5-way gather

Add _run_osv_maven() and include it in the asyncio.gather call
that fans out OSV fetches across npm/pypi/go/cargo/maven. Output
written to .cache/ioc-update-<date>/proposed-osv_maven.json.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: threat_intel.yaml — add TI-OSV-MAVEN-CATALOG

**Files:**
- Modify: `src/agentsec/audit/ioc/threat_intel.yaml`

- [ ] **Step 6.1: Add umbrella TI entry**

Find the existing `TI-OSV-CARGO-CATALOG` entry in `threat_intel.yaml` and add this immediately after it (or after whichever of the 4 OSV catalog entries comes last):

```yaml

  - id: TI-OSV-MAVEN-CATALOG
    source: osv.dev (Maven ecosystem)
    claim: "Aggregated CVE catalog for Maven (Java) packages, sourced from OSV."
    confidence: high
    mapped_tests: [java_supply_chain_audit]
    note: |
      Umbrella TI for all Maven CVE matches surfaced by
      java_supply_chain_audit. Per-CVE advisory id surfaces directly
      in finding evidence (evidence.advisory_id). Refresh via
      `agentsec ioc-update`.
    auto_refresh: false
```

The exact YAML indentation must match the surrounding entries (likely 2-space indent under a top-level list). Inspect the file first to confirm.

- [ ] **Step 6.2: Verify the YAML still parses**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python -c "
import yaml
with open('src/agentsec/audit/ioc/threat_intel.yaml') as f:
    data = yaml.safe_load(f)
ids = [e['id'] for e in (data if isinstance(data, list) else data.get('entries', [])) if isinstance(e, dict)]
print('TI-OSV-MAVEN-CATALOG present:', 'TI-OSV-MAVEN-CATALOG' in ids)
print('total entries:', len(ids))
"
```
Expected: present True.

- [ ] **Step 6.3: Run cve_database build script (regenerate cve_database.json)**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/build_cve_db.py
```
This regenerates `src/agentsec/audit/ioc/cve_database.json` from `threat_intel.yaml`. The CI guard runs `--check` on this file; we must keep them in sync.

- [ ] **Step 6.4: Verify CI guard for cve_database.json passes**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/build_cve_db.py --check
```
Expected: PASS.

- [ ] **Step 6.5: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc/threat_intel.yaml src/agentsec/audit/ioc/cve_database.json && git commit -m "$(cat <<'EOF'
feat(7d.4): threat_intel.yaml — add TI-OSV-MAVEN-CATALOG umbrella

New umbrella TI entry for Maven CVE matches; mapped_tests =
[java_supply_chain_audit]. auto_refresh: false (per-CVE advisory
ids live in finding evidence, not TI). Regenerate cve_database.json
to keep CI guard happy.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: JavaSupplyChainAuditCheck

**Files:**
- Create: `src/agentsec/audit/checks/java_supply_chain_audit.py`
- Create: `tests/test_java_supply_chain_audit.py`

- [ ] **Step 7.1: Create the Check**

Create `src/agentsec/audit/checks/java_supply_chain_audit.py`:

```python
"""java / Maven 供应链漏洞审计（Phase 7d.4）。

Reads operator-configured `mvn dependency:list` output files on the
audited host, parses the text format, and matches each
(coordinate, version) tuple against a bundled OSV-Maven advisory
subset using Apache Maven `ComparableVersion` semantics. Emits one
Finding per matching (coord, version, advisory) tuple.

DB schema (src/agentsec/audit/ioc/osv_maven.json):
  [{"id": "GHSA-xxxx", "package": "org.apache.commons:commons-lang3",
    "ranges": [{"introduced": "0", "fixed": "3.12.1"}],
    "severity": "critical|high|medium|low", "summary": "...",
    "url": "...", "aliases": ["CVE-..."]}, ...]
"""

from __future__ import annotations

from collections import defaultdict

from ..findings import Finding
from ._supply_chain_common import (
    _is_maven_version_in_range,
    extract_severity_label,
    load_advisory_db,
    parse_maven_dependency_list,
)
from .base import Check, CheckContext


def _match_maven_advisories(
    coord: str,
    version: str,
    db_by_pkg: dict[str, list[dict]],
) -> list[dict]:
    """Return the advisories whose ranges include (coord, version)."""
    out: list[dict] = []
    for advisory in db_by_pkg.get(coord, []):
        for range_ in advisory.get("ranges", []):
            intro = range_.get("introduced")
            fixed = range_.get("fixed")
            if _is_maven_version_in_range(version, intro, fixed):
                out.append(advisory)
                break
    return out


class JavaSupplyChainAuditCheck(Check):
    """Detect known CVEs in Maven-declared dependencies."""

    id = "java_supply_chain_audit"
    description = (
        "Match Maven dependencies (from `mvn dependency:list` output) "
        "against the bundled OSV-Maven advisory DB."
    )

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not ctx.maven_lock_paths:
            ctx.status.not_applicable(
                "no maven_lock_paths configured for this run"
            )
            return []

        # Dynamic policy injection so SSH executor can read these files.
        ctx.policy.add_runtime_allowed_paths(
            ctx.maven_lock_paths, kind="exact"
        )

        db = load_advisory_db("osv_maven.json")
        # Index by package coord for O(1) lookup
        db_by_pkg: dict[str, list[dict]] = defaultdict(list)
        for advisory in db:
            db_by_pkg[advisory["package"]].append(advisory)

        findings: list[Finding] = []
        for path in ctx.maven_lock_paths:
            try:
                text = await ctx.read_remote_file(path)
            except Exception as exc:
                ctx.status.skipped(
                    f"could not read {path}: {exc}"
                )
                continue

            deps = parse_maven_dependency_list(text)
            for coord, version in deps:
                matches = _match_maven_advisories(coord, version, db_by_pkg)
                for advisory in matches:
                    fixed_in = next(
                        (r.get("fixed") for r in advisory.get("ranges", [])
                         if r.get("fixed")),
                        None,
                    )
                    findings.append(self.make_finding(
                        ctx,
                        severity=extract_severity_label(advisory["severity"]),
                        title=(
                            f"Maven dependency {coord} {version} matches "
                            f"advisory {advisory['id']}"
                        ),
                        description=advisory.get("summary", "")[:300],
                        evidence={
                            "coord": coord,
                            "version": version,
                            "advisory_id": advisory["id"],
                            "fixed_in": fixed_in,
                            "url": advisory.get("url", ""),
                            "aliases": advisory.get("aliases", []),
                            "lock_path": path,
                        },
                        threat_refs=["TI-OSV-MAVEN-CATALOG"],
                    ))
        return findings
```

Note: `ctx.read_remote_file` is the existing CheckContext method for SSH file reads. If the actual method name differs (e.g., `ctx.ssh.read` or `ctx.fs.read`), the implementer should grep `rust_supply_chain_audit.py` for the equivalent call and use the same name.

- [ ] **Step 7.2: Create unit tests**

Create `tests/test_java_supply_chain_audit.py`:

```python
"""Unit tests for JavaSupplyChainAuditCheck (Phase 7d.4)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from agentsec.audit.checks.java_supply_chain_audit import (
    JavaSupplyChainAuditCheck,
    _match_maven_advisories,
)


def test_match_returns_advisory_when_in_range() -> None:
    db = {
        "org.example:lib": [
            {"id": "GHSA-x", "ranges": [
                {"introduced": "1.0", "fixed": "2.0"}
            ]}
        ]
    }
    matches = _match_maven_advisories("org.example:lib", "1.5", db)
    assert len(matches) == 1
    assert matches[0]["id"] == "GHSA-x"


def test_match_skips_when_version_above_fixed() -> None:
    db = {
        "org.example:lib": [
            {"id": "GHSA-x", "ranges": [
                {"introduced": "1.0", "fixed": "2.0"}
            ]}
        ]
    }
    matches = _match_maven_advisories("org.example:lib", "2.0", db)
    assert matches == []


def test_match_skips_when_package_not_in_db() -> None:
    db = {"org.other:lib": [{"id": "x", "ranges": [{"fixed": "1.0"}]}]}
    matches = _match_maven_advisories("org.example:lib", "0.5", db)
    assert matches == []


def test_match_returns_multiple_advisories_for_same_pkg() -> None:
    db = {
        "org.example:lib": [
            {"id": "GHSA-1", "ranges": [{"introduced": "0", "fixed": "1.5"}]},
            {"id": "GHSA-2", "ranges": [{"introduced": "0", "fixed": "1.8"}]},
        ]
    }
    matches = _match_maven_advisories("org.example:lib", "1.0", db)
    assert {m["id"] for m in matches} == {"GHSA-1", "GHSA-2"}


@pytest.mark.asyncio
async def test_check_returns_not_applicable_on_empty_paths() -> None:
    check = JavaSupplyChainAuditCheck()
    ctx = MagicMock()
    ctx.maven_lock_paths = []
    ctx.status = MagicMock()
    findings = await check.run(ctx)
    assert findings == []
    ctx.status.not_applicable.assert_called_once()
```

- [ ] **Step 7.3: Run new tests**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_java_supply_chain_audit.py -v
```
Expected: 5 PASS.

- [ ] **Step 7.4: Run lint**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/checks/java_supply_chain_audit.py tests/test_java_supply_chain_audit.py
```

- [ ] **Step 7.5: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/checks/java_supply_chain_audit.py tests/test_java_supply_chain_audit.py && git commit -m "$(cat <<'EOF'
feat(7d.4): JavaSupplyChainAuditCheck — match Maven deps against OSV

Mirror RustSupplyChainAuditCheck. Read operator-configured
`mvn dependency:list` output files via SSH, parse with
parse_maven_dependency_list, match each (coord, version) against
bundled osv_maven.json using Apache ComparableVersion ranges.
Emit one Finding per matching tuple. threat_refs = [TI-OSV-MAVEN-CATALOG].

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 8: CLI — `--maven-lock-path` flag

**Files:**
- Modify: `src/agentsec/cli.py` (add to both `server-audit` and `evaluate`)

- [ ] **Step 8.1: Find existing `--cargo-lock-path` plumbing**

```bash
cd /Users/roger/Work/AgentSec && grep -n "cargo_lock_paths" src/agentsec/cli.py
```

This locates the typer Option declaration and the wiring into the config/CheckContext.

- [ ] **Step 8.2: Add `--maven-lock-path` to `server-audit`**

Mirror the `cargo_lock_paths` declaration (around line 467) and add `maven_lock_paths` immediately after:

```python
    maven_lock_paths: list[str] = typer.Option(
        [],
        "--maven-lock-path",
        help="Path on remote host to `mvn dependency:list -DoutputFile=...` "
             "output (repeatable; multiple paths checked).",
    ),
```

And in the body of `server-audit`, mirror the `cargo_lock_paths` wiring (around line 550):

```python
    if maven_lock_paths:
        cfg_overrides.setdefault("server_audit", {})
        cfg_overrides["server_audit"].update({
            **cfg_overrides.get("server_audit", {}),
            "maven_lock_paths": maven_lock_paths,
        })
        expanded_maven = [expand_tilde(p, remote_home) for p in maven_lock_paths]
        # NOTE: actual integration code shape may differ; implementer must
        # mirror the existing cargo_lock_paths integration line-for-line.
```

The implementer must read the existing `cargo_lock_paths` block (around lines 550-560) and replicate its exact shape — assignment to context, `expand_tilde`, etc.

- [ ] **Step 8.3: Add to `evaluate` command if it has equivalent flags**

Search for `cargo_lock_paths` in the `evaluate` command:

```bash
cd /Users/roger/Work/AgentSec && grep -n -A 3 "cargo_lock_paths" src/agentsec/cli.py | head -30
```

If `evaluate` has analogous wiring, mirror it for `maven_lock_paths`.

- [ ] **Step 8.4: Smoke-test CLI**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/agentsec server-audit --help 2>&1 | grep -i maven
```
Expected: `--maven-lock-path` appears in help output.

- [ ] **Step 8.5: Run lint**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/cli.py
```

- [ ] **Step 8.6: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/cli.py && git commit -m "$(cat <<'EOF'
feat(7d.4): CLI — add --maven-lock-path to server-audit (+ evaluate if applicable)

Repeatable typer Option mirroring --cargo-lock-path. Operator runs
`mvn dependency:list -DoutputFile=mvn-deps.txt` upstream, then
points --maven-lock-path at the resulting file. CheckContext
wiring + expand_tilde + config override all mirror the cargo path.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 9: Build osv_maven.json via live `agentsec ioc-update`

**Files:**
- Create: `src/agentsec/audit/ioc/osv_maven.json` (output of live build)

This task requires internet access. OSV-Maven is a public Google Cloud Storage bucket; no auth tokens required. `agentsec ioc-update` may also pull NVD / GHSA — those need keys per `~/.config/agentsec/env`. If env is not loaded, only OSV will succeed (the others will fail gracefully).

- [ ] **Step 9.1: Source env (if exists)**

```bash
test -f ~/.config/agentsec/env && source ~/.config/agentsec/env
```

- [ ] **Step 9.2: Run ioc-update (live HTTP)**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/agentsec ioc-update 2>&1 | tail -30
```

Expected: produces a `.cache/ioc-update-<YYYY-MM-DD>/` directory containing `proposed-osv_maven.json` (among other proposed files). Run time: 1-3 minutes typically.

- [ ] **Step 9.3: Verify proposed-osv_maven.json was produced**

```bash
cd /Users/roger/Work/AgentSec && ls -lh .cache/ioc-update-*/proposed-osv_maven.json | tail -3
```
Expected: file exists with size > 100 KB and < 15 MB.

If size > 15 MB, the filter chain may have a bug — STOP and investigate.

- [ ] **Step 9.4: Inspect the file briefly**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python -c "
import json, glob
path = sorted(glob.glob('.cache/ioc-update-*/proposed-osv_maven.json'))[-1]
data = json.loads(open(path).read())
print(f'entries: {len(data):,}')
print(f'sample: {data[0] if data else \"<empty>\"}')
"
```
Expected: entries > 500 (likely 1000-3000 range), sample looks like a valid advisory dict with `id` / `package` / `ranges` / `severity`.

- [ ] **Step 9.5: Copy to bundled location**

```bash
cd /Users/roger/Work/AgentSec && cp $(ls -t .cache/ioc-update-*/proposed-osv_maven.json | head -1) src/agentsec/audit/ioc/osv_maven.json
```

- [ ] **Step 9.6: Verify CI guard passes**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_maven.py
```
Expected: PASS, prints entry count and size.

- [ ] **Step 9.7: Run full test suite**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -5
```
Expected: 1707 + ~25 new = ~1732 PASS, 9 skipped.

If any new test fails (esp. `test_java_supply_chain_audit.py`), it's likely because the Check is loading the real DB and expecting different shape than the mock tests. Read failure, fix.

- [ ] **Step 9.8: Commit the bundled DB**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc/osv_maven.json && git commit -m "$(cat <<'EOF'
feat(7d.4): bundle osv_maven.json — first OSV-Maven advisory DB

Built via `agentsec ioc-update` against live OSV-Maven dump. ~1500-3000
advisories after the 5-axis filter chain (drop withdrawn / no Maven
affected / no range / no CVSS / scored medium-low > 2y). Refresh
periodically via `agentsec ioc-update` + replace this file.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 10: ADR-0024 + CHANGELOG/ROADMAP/CLAUDE.md/pyproject v0.34.0

**Files:**
- Create: `docs/adr/0024-phase-7d4-java-supply-chain.md`
- Modify: `CHANGELOG.md`
- Modify: `ROADMAP.md`
- Modify: `CLAUDE.md`
- Modify: `pyproject.toml`

Single combined commit.

- [ ] **Step 10.1: Create ADR-0024**

Create `docs/adr/0024-phase-7d4-java-supply-chain.md`:

```markdown
# ADR-0024: Phase 7d.4 — Java/Maven supply chain audit

* **Status**: Accepted
* **Date**: 2026-05-16
* **Phase**: 7d.4

## Context

7d series (npm / pip / go / rust/cargo) shipped 4 OSV-backed supply
chain Checks. Java/Maven is the largest enterprise Java ecosystem
and a natural 5th addition.

Maven differs from the prior 4 in two material ways:

1. **No native lockfile**. pom.xml is declarative with version
   ranges and unresolved transitive deps. Treating pom.xml as the
   audit input would miss CVEs in transitively-resolved deps and
   misreport ranges.

2. **Maven version semantics aren't semver**. Apache
   `ComparableVersion` defines its own qualifier rank table
   (alpha < beta < milestone < rc < snapshot < "" < sp < unknown)
   plus implicit sub-list nesting at digit↔alpha transitions. Prior
   ecosystems used `packaging.version` (pip) or `semver` (go/rust);
   Maven needs its own comparator.

## Decision

1. **Operator pre-runs `mvn dependency:list -DoutputFile=mvn-deps.txt`**.
   We parse the resulting flat-list text format, mirroring the pip
   approach where the operator pre-freezes requirements.

2. **Hand-write Apache `ComparableVersion` semantics** in
   `_supply_chain_common.py` (~100 LOC). Zero new dependencies. Full
   coverage of the qualifier rank table, alpha shorthand expansion
   (`1.0a1 == 1.0-alpha-1`), and trailing-zero normalization.

3. **Mirror 7d.3 (rust/cargo) for everything else**: `OsvMavenFetcher`
   pulling `https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip`,
   5-axis filter chain, multi-affected expansion, dedup on
   (id, package), bundled `osv_maven.json` DB, `TI-OSV-MAVEN-CATALOG`
   umbrella TI, CI guard at 15 MB cap.

## Why pre-run `mvn dependency:list` and not parse pom.xml

- pom.xml gives declared deps only; misses transitive (where most
  CVEs hide).
- pom.xml versions can be ranges (`[1.0,2.0)`); resolving them
  requires running Maven anyway.
- `dependency:list` output is a flat resolved tree, the moral
  equivalent of `package-lock.json` / `Cargo.lock`.

## Why hand-written ComparableVersion and not a third-party library

- Existing Python Maven version libraries (`pymaven-patch`, etc.)
  are unmaintained.
- Apache ComparableVersion algorithm is well-documented and stable.
- ~100 LOC, fully testable, zero supply-chain risk to ourselves.

## Why scope filter includes test

- A malicious test dependency can run during `mvn test` in CI,
  exfiltrate secrets / inject artifacts. Test deps are a real
  attack surface, not just compile/runtime.
- Operator who wants to suppress test findings can run
  `dependency:list -DexcludeScope=test` upstream.

## Consequences

- New Check (`java_supply_chain_audit`); total Checks 35 → **36**.
- New bundled DB (`osv_maven.json`, ~1-3 MB after filtering).
- Future Maven CVE refresh = re-run `agentsec ioc-update` and
  re-commit `osv_maven.json`.
- Gradle support deferred to 7d.4.1 (different file tree:
  build.gradle / build.gradle.kts / gradle.lockfile).

## Alternatives considered

- **Run `mvn` ourselves via SSH**: rejected. Adds Maven to the
  trusted-binary surface; security gate would have to allow `mvn`
  with arbitrary args; resource-intensive.
- **Use `pymaven-patch` for version comparison**: rejected, dep is
  unmaintained.
- **Strict semver for Maven**: rejected, would mis-classify SNAPSHOT
  / sp1 / alpha-N versions and miss CVEs.

## References

- Spec: `docs/superpowers/specs/2026-05-16-phase-7d4-java-maven-supply-chain-design.md`
- Plan: `docs/superpowers/plans/2026-05-16-phase-7d4-java-maven-supply-chain.md`
- ADR-0012: Phase 7d npm
- ADR-0013: Phase 7d.1 pip
- ADR-0014: Phase 7d.2 go
- ADR-0015: Phase 7d.3 rust/cargo
- Apache ComparableVersion docs: https://maven.apache.org/ref/3.6.3/maven-artifact/apidocs/org/apache/maven/artifact/versioning/ComparableVersion.html
```

- [ ] **Step 10.2: Update pyproject.toml**

Find `version = "0.33.0"`, replace with `version = "0.34.0"`.

- [ ] **Step 10.3: Add CHANGELOG entry**

Add at top of `CHANGELOG.md`, above v0.33.0:

```markdown
## v0.34.0 — 2026-05-16

**Phase 7d.4 — Java/Maven supply chain audit (5th ecosystem in the
supply chain series).**

- New Check `java_supply_chain_audit` —
  `src/agentsec/audit/checks/java_supply_chain_audit.py`. Reads
  operator-configured `mvn dependency:list` output files (via
  `--maven-lock-path` / `server_audit.maven_lock_paths` config),
  matches each (coordinate, version) against bundled `osv_maven.json`
  using Apache Maven `ComparableVersion` semantics. Total Checks:
  35 → **36**.
- New `OsvMavenFetcher` — `src/agentsec/audit/ioc_update/fetchers/osv_maven.py`.
  Pulls https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip,
  5-axis filter chain (drop withdrawn / no Maven affected / no range /
  no CVSS / scored medium-low > 2y), runs in parallel with the other
  4 OSV fetchers via `asyncio.gather` (5-way).
- New bundled DB `src/agentsec/audit/ioc/osv_maven.json` + CI guard
  `scripts/check_osv_maven.py` (≤ 15 MB cap).
- New umbrella TI `TI-OSV-MAVEN-CATALOG` in `threat_intel.yaml`.
- New `_compare_maven_version` / `_is_maven_version_in_range` /
  `parse_maven_dependency_list` in `_supply_chain_common.py`. Hand-
  written Apache ComparableVersion semantics (~100 LOC, zero new
  deps): qualifier rank (alpha < beta < milestone < rc < snapshot <
  "" < sp < unknown), digit↔alpha transition implicit sub-list,
  trailing-zero normalization, alpha shorthand expansion
  (`1.0a1 == 1.0-alpha-1`).
- New `ServerAuditConfig.maven_lock_paths` + validator (loose
  basename match: `.txt` / `.list` / `-deps.txt` / `-list.txt` /
  `dependency-list.txt`).
- New ADR-0024 records the design (no-pom-xml / no-mvn-subprocess /
  hand-written comparator decisions).
- Test count: 1707 → ~1732 (~25 new unit tests).
- Zero changes to other 4 supply chain Checks; zero changes to
  Adapter / Judge / Scoring / Report renderer.

**Breaking changes**: none.
```

- [ ] **Step 10.4: ROADMAP entry**

Add a new shipped entry in `ROADMAP.md`, mirroring how 7d.3 is listed:

```markdown
- **Phase 7d.4** (shipped v0.34.0, 2026-05-16) — Java/Maven supply
  chain audit. 5th ecosystem in the series; hand-written Maven
  ComparableVersion comparator; operator pre-runs `mvn
  dependency:list` for input.
```

- [ ] **Step 10.5: Add CLAUDE.md section**

After existing `## rust supply chain audit (Phase 7d.3, v0.15.0)` section, add:

```markdown
## Java/Maven supply chain audit (Phase 7d.4, v0.34.0)

- **`JavaSupplyChainAuditCheck`** in `src/agentsec/audit/checks/java_supply_chain_audit.py` reads operator-configured `mvn dependency:list -DoutputFile=...` output files from `CheckContext.maven_lock_paths` (sourced from `ServerAuditConfig.maven_lock_paths`), parses the text format (`[INFO] groupId:artifactId:type:version:scope`), and matches each (coord, version) against the bundled `osv_maven.json` using Apache Maven `ComparableVersion` semantics. Emits one Finding per (pkg, version, advisory) match; `threat_refs=["TI-OSV-MAVEN-CATALOG"]`.
- **No native Maven lockfile** — operator pre-runs `mvn dependency:list -DexcludeTransitive=false -DoutputFile=mvn-deps.txt` and points `--maven-lock-path` at the resulting file (mirrors pip's pre-frozen requirements approach). Empty `maven_lock_paths` ⇒ `not_applicable`.
- **Hand-written Maven `ComparableVersion`** in `_supply_chain_common.py` (~100 LOC, zero new deps). Qualifier rank table: `alpha=-5, beta=-4, milestone=-3, rc=-2, snapshot=-1, ""=0, sp=1, unknown=2+lex`. Implicit sub-list nesting at digit↔alpha transitions (`1.0a1` parses as `[1, 0, [a, [1]]]`, equivalent to `1.0-alpha-1`). Trailing zero normalization (`1.0 == 1.0.0`).
- **Path validation** — `ServerAuditConfig.maven_lock_paths` validator: `/` or `~/` prefix, no shell metachars, basename ends with `.txt` / `.list` / `-deps.txt` / `-list.txt` or equals `dependency-list.txt` (loose vs Cargo.lock strict because Maven has no canonical lockfile name).
- **Coordinate format** — `groupId:artifactId` (case-sensitive, Maven coords are case-sensitive). `org.apache.commons:commons-lang3` and `Org.Apache.Commons:commons-lang3` are different coords.
- **Scope filter** — includes `compile` / `runtime` / `provided` / `test`; skips `system` / `none`. **test included** because malicious test deps are a real CI attack surface (run during `mvn test`).
- **`OsvMavenFetcher`** mirrors `OsvCargoFetcher` (5-axis filter chain) but pulls `https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip`. Runs as a side pipeline (`_run_osv_maven`, parallel to npm/pypi/go/cargo via `asyncio.gather` 5-way).
- **OSV ecosystem string is `"Maven"`** (literal, capitalized M) — case-sensitive per OSV spec.
- **`scripts/check_osv_maven.py`** CI guard enforces valid JSON + ≤ 15 MB hard cap (mirrors npm/pypi/go/cargo).
- **Bundled DB**: `src/agentsec/audit/ioc/osv_maven.json` (~1-3 MB depending on filter date).
- **`agentsec server-audit --maven-lock-path <path>`** is repeatable on the standalone CLI; for the `evaluate` flow set `server_audit.maven_lock_paths` in `openclaw-target.yaml`.
- **Total Checks (v0.34.0):** 35 → **36 类**.
- **Adding a 6th ecosystem (e.g., ruby/gem in 7d.5)**: pattern is mature — new Check `<eco>_supply_chain_audit` + `osv_<eco>.json` DB + `Osv<Eco>Fetcher` + `TI-OSV-<ECO>-CATALOG`. All common helpers already in `_supply_chain_common.py`.
- **Adding Gradle support (7d.4.1, deferred)**: separate file tree (build.gradle / build.gradle.kts / gradle.lockfile). Same OSV-Maven DB applies (Gradle uses Maven coords). Distinct parser, can reuse comparator.

Spec: `docs/superpowers/specs/2026-05-16-phase-7d4-java-maven-supply-chain-design.md`.
Plan: `docs/superpowers/plans/2026-05-16-phase-7d4-java-maven-supply-chain.md`.
```

- [ ] **Step 10.6: Run full test suite + lint + coverage gate**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -5
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_maven.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_owasp_coverage.py
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/ tests/ 2>&1 | tail -3
```
Expected: pytest ~1732 PASS / 9 skipped; check_osv_maven.py PASS; check_owasp_coverage.py PASS (no change to MCP); ruff clean.

- [ ] **Step 10.7: Single combined commit**

```bash
cd /Users/roger/Work/AgentSec && git add docs/adr/0024-phase-7d4-java-supply-chain.md CHANGELOG.md ROADMAP.md CLAUDE.md pyproject.toml && git commit -m "$(cat <<'EOF'
feat(7d.4): ADR-0024 + v0.34.0 docs

Records design decisions for Phase 7d.4 (Java/Maven supply chain
audit, 5th ecosystem in the series): operator pre-runs
`mvn dependency:list` for input (no pom.xml parse, no mvn
subprocess), hand-written Apache ComparableVersion comparator (zero
new deps), test scope included as real CI attack surface. CHANGELOG
+ ROADMAP + CLAUDE.md + pyproject all bumped to v0.34.0.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 11: Final review

Dispatch a final reviewer subagent (sonnet, with `<400 words` length cap per 7c.1.y/7c.1.z lesson) to verify:

- All 4 supply chain Check + fetcher templates mirrored consistently (no copy-paste regressions)
- Maven ComparableVersion comparator handles the 20+ test cases plus any subtle Apache spec edge cases
- `osv_maven.json` size is reasonable; CI guard PASS
- All ~25 new unit tests PASS; baseline 1707 still PASS
- ADR-0024 cites correct prior ADRs and explains decisions
- CHANGELOG / ROADMAP / CLAUDE.md / pyproject all consistent v0.34.0
- No `src/` regressions (other 4 ecosystems unaffected)
- ID conventions (`maven_lock_paths`, `TI-OSV-MAVEN-CATALOG`, ecosystem string `Maven`) consistent

The reviewer should report APPROVED / NEEDS_FIX with concise blocking issues.

---

## Self-Review Notes

**Spec coverage check**:

| Spec section | Task |
|---|---|
| §2 v1: java_supply_chain_audit.py | Task 7 |
| §2 v1: osv_maven.py fetcher | Task 3 |
| §2 v1: _supply_chain_common.py extensions | Task 1 |
| §2 v1: osv_maven.json | Task 9 |
| §2 v1: check_osv_maven.py | Task 4 |
| §2 v1: ServerAuditConfig.maven_lock_paths + CheckContext | Task 2 |
| §2 v1: CLI --maven-lock-path | Task 8 |
| §2 v1: TI-OSV-MAVEN-CATALOG | Task 6 |
| §2 v1: ioc-update _run_osv_maven 5-way | Task 5 |
| §2 v1: ADR-0024 | Task 10.1 |
| §2 v1: CHANGELOG/ROADMAP/CLAUDE.md/pyproject | Tasks 10.2-10.5 |
| §3.1 input format + parser | Task 1 |
| §3.2 Maven ComparableVersion | Task 1 |
| §3.3 OsvMavenFetcher | Task 3 |
| §3.4 Check structure | Task 7 |
| §3.5 TI entry | Task 6 |
| §3.6 _run_osv_maven CLI wiring | Task 5 |
| §6 testing | Tasks 1, 2, 3, 7 (~25 tests) |
| §7 兼容性 | Task 9 (DB build) + 10 (no breaking changes) |

All spec sections covered.

**Placeholder scan**: Task 5 / Task 8 mention "implementer should mirror existing `cargo_lock_paths` line-for-line" — this is intentional (rust template is the canonical reference; copying its exact shape is the contract). Not a placeholder per se, but a documented dependency on existing code. Implementer is expected to read the cargo precedent before writing.

**Type consistency**: `maven_lock_paths` used uniformly (config field, CheckContext field, CLI flag, validator). `TI-OSV-MAVEN-CATALOG` used uniformly (TI entry, threat_refs). `osv_maven.json` filename used uniformly (DB, CI guard, CLAUDE.md, ADR).

**Critical invariant** (commit ordering): Tasks 1-8 add code without DB; Task 9 builds DB and runs full test suite (catches integration regressions); Task 10 commits final docs in single commit. CI never sees a broken state because Task 9's commit makes the Check fully functional.

**Live HTTP dependency in Task 9**: Implementer must have internet access. OSV is public Google Cloud Storage — no auth needed. If network is unavailable, Task 9 must STOP BLOCKED; can't be skipped because subsequent steps depend on the bundled DB.

---

## Post-Implementation Verification

After all 11 tasks land, run on `main`:

```bash
.venv/bin/pytest tests/
.venv/bin/python scripts/check_osv_maven.py
.venv/bin/python scripts/check_owasp_coverage.py
.venv/bin/ruff check src/ tests/
git log --oneline -12
git status
.venv/bin/agentsec server-audit --help | grep maven
```

Expected:
- pytest: ~1732 PASS / 9 skipped
- check_osv_maven.py: PASS (entry count + size reported)
- check_owasp_coverage.py: PASS (no change to MCP, floor still 14)
- ruff: clean
- git log: 10+ new commits at HEAD
- git status: clean
- `--maven-lock-path` appears in CLI help

If pytest count drifts beyond ~25 new (e.g., 1740+), some test was double-counted or a new integration test got pulled in — investigate.
