# Phase 7f.1 Podman + Containerd Audit Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add 5 new server-audit Check classes (3 podman + 2 containerd) closing the RHEL/CentOS Stream/Fedora default-runtime gap and K8s-node containerd coverage left by 7f Docker.

**Architecture:** 3 podman Checks copy 7f Docker shape with podman-specific config (containers.conf, rootless detection). 2 containerd Checks dispatch nerdctl-first / ctr-fallback, with docker-takeover yield to avoid double-reporting on hosts where docker uses containerd as backend. Shared helpers extracted to `_docker_common.py` (`_evaluate_inspect`, `_evaluate_image_tag`, `_parse_ctr_info`) return Finding kwargs as dicts (Option α) so new Checks compose via `self.make_finding(**kw)` with automatic Redactor pass.

**Tech Stack:** Python 3.11+, pytest, asyncio, tomllib (stdlib for TOML parsing).

**Spec:** `docs/superpowers/specs/2026-05-12-phase-7f1-podman-containerd-design.md`

---

## File Structure

**Create:**
- `src/agentsec/audit/checks/podman_daemon_audit.py`
- `src/agentsec/audit/checks/podman_runtime_audit.py`
- `src/agentsec/audit/checks/podman_image_cve.py`
- `src/agentsec/audit/checks/containerd_runtime_audit.py`
- `src/agentsec/audit/checks/containerd_image_cve.py`
- `tests/test_podman_daemon_audit.py`
- `tests/test_podman_runtime_audit.py`
- `tests/test_podman_image_cve.py`
- `tests/test_containerd_runtime_audit.py`
- `tests/test_containerd_image_cve.py`
- 21 fixtures in `tests/fixtures/container/` (see Task 1)
- `docs/adr/0018-phase-7f1-podman-containerd-audit.md` (Task 16)

**Modify:**
- `src/agentsec/audit/checks/_docker_common.py` — append detect helpers + 3 shared helpers
- `src/agentsec/audit/checks/container_baseline.yaml` — append `daemon_podman:` section (4 rules)
- `src/agentsec/audit/ioc/threat_intel.yaml` — append 19 TI rows
- `src/agentsec/audit/ssh_policy.yaml` — +10 allowed_paths + 3 commands sections
- `src/agentsec/cli.py` — +5 imports + 5 lines × 2 registration sites
- `tests/test_docker_common.py` — +16 tests (detect + helpers)
- `tests/audit/test_command_policy.py` — +15 tests
- `tests/audit/test_cli_server_audit.py` + `tests/integration/test_openclaw_mock.py` — +absence stubs for 7 new bin paths
- `docs/samples/report-2026-04-28/server-audit-report.md` — refresh (29 → 34 checks)
- `pyproject.toml` — version `0.17.0` → `0.18.0` (Task 16)
- `CHANGELOG.md` / `ROADMAP.md` / `README.md` / `CLAUDE.md` (Task 16)

---

## Task 1: Add 21 fixtures

**Files:**
- Create: 21 files under `tests/fixtures/container/` (directory exists; do not create the dir)

This is mechanical content. The fixture text is consumed verbatim by parsers — preserve trailing spaces and newlines exactly as shown.

- [ ] **Step 1: podman containers.conf — compliant**

Write `tests/fixtures/container/podman_containers_conf_compliant.toml`:

```toml
[containers]
userns = "auto"
no_new_privileges = true
```

- [ ] **Step 2: podman containers.conf — userns host**

Write `tests/fixtures/container/podman_containers_conf_userns_host.toml`:

```toml
[containers]
userns = "host"
no_new_privileges = true
```

- [ ] **Step 3: podman containers.conf — no_new_priv off**

Write `tests/fixtures/container/podman_containers_conf_no_new_priv_off.toml`:

```toml
[containers]
userns = "auto"
no_new_privileges = false
```

- [ ] **Step 4: podman info — rootless**

Write `tests/fixtures/container/podman_info_rootless.json`:

```json
{"host": {"security": {"rootless": true, "seccompProfilePath": "/usr/share/containers/seccomp.json", "apparmorEnabled": false}, "arch": "amd64", "kernel": "5.15.0"}, "version": {"APIVersion": "4", "Version": "4.9.4"}}
```

- [ ] **Step 5: podman info — rootful**

Write `tests/fixtures/container/podman_info_rootful.json`:

```json
{"host": {"security": {"rootless": false, "seccompProfilePath": "/usr/share/containers/seccomp.json", "apparmorEnabled": false}, "arch": "amd64", "kernel": "5.15.0"}, "version": {"APIVersion": "4", "Version": "4.9.4"}}
```

- [ ] **Step 6: podman version — clean**

Write `tests/fixtures/container/podman_version_clean.json`:

```json
{"Client": {"APIVersion": "4", "Version": "4.9.4", "GoVersion": "go1.21.5"}}
```

- [ ] **Step 7: podman version — CVE-range**

Write `tests/fixtures/container/podman_version_cve.json`:

```json
{"Client": {"APIVersion": "4", "Version": "4.8.0", "GoVersion": "go1.21.0"}}
```

- [ ] **Step 8: podman ps — two containers**

Write `tests/fixtures/container/podman_ps_two_containers.txt`:

```
{"Id":"abc1234567890","Image":"nginx:1.25","Names":["web"],"State":"running","Command":"nginx -g daemon off;"}
{"Id":"def9876543210","Image":"python:2.7","Names":["legacy"],"State":"running","Command":"python -m http.server"}
```

- [ ] **Step 9: podman ps — empty**

Write `tests/fixtures/container/podman_ps_empty.txt` as zero-byte file.

- [ ] **Step 10: podman inspect — compliant**

Write `tests/fixtures/container/podman_inspect_compliant.json`:

```json
[{"Id":"abc1234567890","Config":{"User":"1000:1000","Image":"nginx:1.25","Cmd":["nginx","-g","daemon off;"]},"HostConfig":{"Privileged":false,"NetworkMode":"bridge","Binds":[],"CapAdd":null,"CapDrop":["ALL"],"SecurityOpt":["no-new-privileges:true"]}}]
```

- [ ] **Step 11: podman inspect — privileged**

Write `tests/fixtures/container/podman_inspect_privileged.json`:

```json
[{"Id":"abc1234567890","Config":{"User":"root","Image":"nginx:latest","Cmd":["bash"]},"HostConfig":{"Privileged":true,"NetworkMode":"bridge","Binds":[],"CapAdd":null,"CapDrop":[],"SecurityOpt":[]}}]
```

- [ ] **Step 12: podman inspect — host net + sock mount**

Write `tests/fixtures/container/podman_inspect_host_net_sock_mount.json`:

```json
[{"Id":"abc1234567890","Config":{"User":"1000:1000","Image":"nginx:1.25","Cmd":["bash"]},"HostConfig":{"Privileged":false,"NetworkMode":"host","Binds":["/var/run/docker.sock:/var/run/docker.sock"],"CapAdd":null,"CapDrop":[],"SecurityOpt":["no-new-privileges:true"]}}]
```

- [ ] **Step 13: podman inspect — caps + root user**

Write `tests/fixtures/container/podman_inspect_caps_user.json`:

```json
[{"Id":"abc1234567890","Config":{"User":"root","Image":"nginx:1.25","Cmd":["bash"]},"HostConfig":{"Privileged":false,"NetworkMode":"bridge","Binds":[],"CapAdd":["SYS_ADMIN","NET_ADMIN"],"CapDrop":[],"SecurityOpt":[]}}]
```

- [ ] **Step 14: podman images — mixed**

Write `tests/fixtures/container/podman_images_mixed.json`:

```json
[{"Id":"sha256:aaa","Names":["nginx:latest"],"Repository":"nginx","Tag":"latest"},{"Id":"sha256:bbb","Names":["python:2.7"],"Repository":"python","Tag":"2.7"},{"Id":"sha256:ccc","Names":["node:14"],"Repository":"node","Tag":"14"},{"Id":"sha256:ddd","Names":["ubuntu:22.04"],"Repository":"ubuntu","Tag":"22.04"},{"Id":"sha256:eee","Names":["debian:12"],"Repository":"debian","Tag":"12"}]
```

- [ ] **Step 15: containerd nerdctl ps**

Write `tests/fixtures/container/containerd_nerdctl_ps.txt`:

```
{"ID":"k8sabc1234","Image":"docker.io/library/redis:7","Names":"cache","Status":"Up 1h"}
```

- [ ] **Step 16: containerd nerdctl inspect — privileged**

Write `tests/fixtures/container/containerd_nerdctl_inspect_privileged.json`:

```json
[{"Id":"k8sabc1234","Config":{"User":"root","Image":"docker.io/library/redis:7"},"HostConfig":{"Privileged":true,"NetworkMode":"bridge","Binds":[],"CapAdd":null,"CapDrop":[],"SecurityOpt":[]}}]
```

- [ ] **Step 17: containerd nerdctl images**

Write `tests/fixtures/container/containerd_nerdctl_images.json`:

```json
[{"Repository":"redis","Tag":"7","Names":["docker.io/library/redis:7"]},{"Repository":"node","Tag":"14","Names":["docker.io/library/node:14"]},{"Repository":"alpine","Tag":"3.18","Names":["docker.io/library/alpine:3.18"]}]
```

- [ ] **Step 18: containerd ctr containers list**

Write `tests/fixtures/container/containerd_ctr_containers_list_q.txt`:

```
ctrabc1234
ctrdef5678
```

- [ ] **Step 19: containerd ctr info — privileged**

Write `tests/fixtures/container/containerd_ctr_info_privileged.txt`:

```
{
    "ID": "ctrabc1234",
    "Spec": {
        "process": {
            "user": {
                "uid": 0,
                "gid": 0
            },
            "capabilities": {
                "effective": ["CAP_SYS_ADMIN", "CAP_NET_ADMIN", "CAP_SYS_PTRACE"]
            },
            "noNewPrivileges": false
        },
        "linux": {
            "namespaces": [
                {"type": "pid"},
                {"type": "network", "path": "/proc/1/ns/net"}
            ]
        }
    }
}
```

(JSON-shaped text; `ctr containers info` outputs roughly this — the `_parse_ctr_info` helper parses it as JSON when possible.)

- [ ] **Step 20: containerd ctr info — clean**

Write `tests/fixtures/container/containerd_ctr_info_clean.txt`:

```
{
    "ID": "ctrdef5678",
    "Spec": {
        "process": {
            "user": {
                "uid": 1000,
                "gid": 1000
            },
            "capabilities": {
                "effective": []
            },
            "noNewPrivileges": true
        },
        "linux": {
            "namespaces": [
                {"type": "pid"},
                {"type": "network"}
            ]
        }
    }
}
```

- [ ] **Step 21: containerd ctr images list**

Write `tests/fixtures/container/containerd_ctr_images_list_q.txt`:

```
docker.io/library/redis:7
docker.io/library/node:14
docker.io/library/alpine:3.18
```

- [ ] **Step 22: Verify all 21 fixtures land**

Run:
```bash
ls tests/fixtures/container/podman_* tests/fixtures/container/containerd_* 2>&1 | wc -l
```

Expected: `21` (or more — already 14 docker fixtures in dir).

Run:
```bash
python -c "import json; [json.load(open(p)) for p in ['tests/fixtures/container/podman_info_rootless.json','tests/fixtures/container/podman_info_rootful.json','tests/fixtures/container/podman_version_clean.json','tests/fixtures/container/podman_version_cve.json','tests/fixtures/container/podman_inspect_compliant.json','tests/fixtures/container/podman_inspect_privileged.json','tests/fixtures/container/podman_inspect_host_net_sock_mount.json','tests/fixtures/container/podman_inspect_caps_user.json','tests/fixtures/container/podman_images_mixed.json','tests/fixtures/container/containerd_nerdctl_inspect_privileged.json','tests/fixtures/container/containerd_nerdctl_images.json','tests/fixtures/container/containerd_ctr_info_privileged.txt','tests/fixtures/container/containerd_ctr_info_clean.txt']]; print('all JSON-parseable')"
```

Expected: `all JSON-parseable`.

Run:
```bash
python -c "import tomllib; [tomllib.load(open(p,'rb')) for p in ['tests/fixtures/container/podman_containers_conf_compliant.toml','tests/fixtures/container/podman_containers_conf_userns_host.toml','tests/fixtures/container/podman_containers_conf_no_new_priv_off.toml']]; print('all TOML-parseable')"
```

Expected: `all TOML-parseable`.

- [ ] **Step 23: Commit**

```bash
git add tests/fixtures/container/podman_*.toml \
        tests/fixtures/container/podman_*.json \
        tests/fixtures/container/podman_*.txt \
        tests/fixtures/container/containerd_*.json \
        tests/fixtures/container/containerd_*.txt
git commit -m "test(7f.1): add podman + containerd fixtures

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 2: detect_podman + detect_nerdctl + detect_ctr + detect_containerd_runtime helpers

**Files:**
- Modify: `src/agentsec/audit/checks/_docker_common.py`
- Modify: `tests/test_docker_common.py`

- [ ] **Step 1: Write failing tests for the 4 detect helpers**

Append to `tests/test_docker_common.py`:

```python
# ---- detect_podman ----

def test_detect_podman_finds_usr_bin():
    assert detect_podman(_ctx(_StubExecutor("/usr/bin/podman"))) == "/usr/bin/podman"


def test_detect_podman_finds_usr_local_bin():
    assert detect_podman(_ctx(_StubExecutor("/usr/local/bin/podman"))) == "/usr/local/bin/podman"


def test_detect_podman_returns_none_when_absent():
    assert detect_podman(_ctx(_StubExecutor(None))) is None


def test_detect_podman_returns_none_when_all_rejected():
    assert detect_podman(_ctx(_AllRejectedExecutor())) is None


# ---- detect_nerdctl ----

def test_detect_nerdctl_finds_usr_local_bin():
    assert detect_nerdctl(_ctx(_StubExecutor("/usr/local/bin/nerdctl"))) == "/usr/local/bin/nerdctl"


def test_detect_nerdctl_returns_none_when_absent():
    assert detect_nerdctl(_ctx(_StubExecutor(None))) is None


# ---- detect_ctr ----

def test_detect_ctr_finds_usr_bin():
    assert detect_ctr(_ctx(_StubExecutor("/usr/bin/ctr"))) == "/usr/bin/ctr"


def test_detect_ctr_returns_none_when_absent():
    assert detect_ctr(_ctx(_StubExecutor(None))) is None


# ---- detect_containerd_runtime ----

def test_detect_containerd_runtime_prefers_nerdctl():
    """When both nerdctl and ctr are present + containerd.sock exists,
    return ("path-to-nerdctl", "nerdctl")."""
    paths = (
        "/usr/local/bin/nerdctl",
        "/usr/bin/ctr",
        "/run/containerd/containerd.sock",
    )
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == ("/usr/local/bin/nerdctl", "nerdctl")


def test_detect_containerd_runtime_falls_back_ctr():
    """nerdctl absent, ctr + socket present → ("path-to-ctr", "ctr")."""
    paths = ("/usr/bin/ctr", "/run/containerd/containerd.sock")
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == ("/usr/bin/ctr", "ctr")


def test_detect_containerd_runtime_none_when_socket_absent():
    """nerdctl present but socket absent → (None, None)."""
    paths = ("/usr/local/bin/nerdctl",)
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == (None, None)


def test_detect_containerd_runtime_none_when_no_frontend():
    """Socket present but no nerdctl/ctr → (None, None)."""
    paths = ("/run/containerd/containerd.sock",)
    executor = _MultiPathStubExecutor(paths)
    assert detect_containerd_runtime(_ctx(executor)) == (None, None)
```

Also add a helper `_MultiPathStubExecutor` to the top of `tests/test_docker_common.py` if not already present:

```python
class _MultiPathStubExecutor:
    """Returns exit_code=0 for `stat -c %n <path>` if path ∈ paths; else exit 1."""

    def __init__(self, paths: tuple[str, ...]):
        self._paths = set(paths)

    def run(self, argv, *, role=None):
        from agentsec.audit.types import RunResult
        argv = list(argv)
        if argv[:3] == ["stat", "-c", "%n"] and argv[3] in self._paths:
            return RunResult(
                stdout=argv[3] + "\n", stderr="", exit_code=0,
                rejected=False, reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            )
        return RunResult(
            stdout="", stderr="No such file", exit_code=1,
            rejected=False, reject_reason=None, argv=argv,
            command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
        )
```

Also update the top imports in `tests/test_docker_common.py` to include the 4 new detect helpers:

```python
from agentsec.audit.checks._docker_common import (
    detect_containerd_runtime,
    detect_ctr,
    detect_docker,
    detect_nerdctl,
    detect_podman,
    is_path_under,
)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_docker_common.py -k "detect_podman or detect_nerdctl or detect_ctr or detect_containerd" -v`

Expected: 12 FAIL with `ImportError: cannot import name 'detect_podman'...`.

- [ ] **Step 3: Add the 4 detect helpers**

Edit `src/agentsec/audit/checks/_docker_common.py`. Refactor the existing `detect_docker` to use a shared `_stat_probe` helper (matches `_firewall_common.py` style), then add new candidates + helpers.

Append after the existing `is_path_under` function:

```python
_PODMAN_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/podman",
    "/usr/local/bin/podman",
    "/opt/homebrew/bin/podman",
)

_NERDCTL_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/local/bin/nerdctl",
    "/usr/bin/nerdctl",
)

_CTR_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/ctr",
    "/usr/local/bin/ctr",
)

_CONTAINERD_SOCKET = "/run/containerd/containerd.sock"


def _stat_probe(ctx: CheckContext, candidates: tuple[str, ...]) -> str | None:
    """Try each candidate path via `stat -c %n`; return first hit, None on all-miss."""
    for path in candidates:
        result = ctx.executor.run(["stat", "-c", "%n", path])
        if not result.rejected and result.exit_code == 0:
            return path
    return None


def detect_podman(ctx: CheckContext) -> str | None:
    """探测 podman 二进制路径；首个 stat 命中即返。"""
    return _stat_probe(ctx, _PODMAN_BIN_CANDIDATES)


def detect_nerdctl(ctx: CheckContext) -> str | None:
    """探测 nerdctl 二进制路径；首个 stat 命中即返。"""
    return _stat_probe(ctx, _NERDCTL_BIN_CANDIDATES)


def detect_ctr(ctx: CheckContext) -> str | None:
    """探测 ctr 二进制路径；首个 stat 命中即返。"""
    return _stat_probe(ctx, _CTR_BIN_CANDIDATES)


def detect_containerd_runtime(
    ctx: CheckContext,
) -> tuple[str | None, str | None]:
    """探测 containerd 运行时；nerdctl 优先，ctr 回退。
    
    同时检查 /run/containerd/containerd.sock 存在，避免装了 nerdctl
    但 containerd 未起的开发机误报。
    
    Returns (frontend_bin, mode) where mode ∈ {"nerdctl", "ctr", None}.
    """
    socket_present = ctx.executor.run(
        ["stat", "-c", "%n", _CONTAINERD_SOCKET]
    )
    if socket_present.rejected or socket_present.exit_code != 0:
        return (None, None)
    nerdctl_bin = detect_nerdctl(ctx)
    if nerdctl_bin is not None:
        return (nerdctl_bin, "nerdctl")
    ctr_bin = detect_ctr(ctx)
    if ctr_bin is not None:
        return (ctr_bin, "ctr")
    return (None, None)
```

The existing `detect_docker` function should also be refactored to use `_stat_probe`:

```python
def detect_docker(ctx: CheckContext) -> str | None:
    """探测被审主机 docker 二进制路径。"""
    return _stat_probe(ctx, _DOCKER_BIN_CANDIDATES)
```

(Replace the existing 7-line for-loop with this 1-line delegation.)

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_docker_common.py -v`

Expected: all PASS (existing tests for `detect_docker` + `is_path_under` still green + 12 new tests green).

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/checks/_docker_common.py tests/test_docker_common.py
git commit -m "feat(7f.1): detect_podman / detect_nerdctl / detect_ctr / detect_containerd_runtime

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 3: _evaluate_inspect shared helper

**Files:**
- Modify: `src/agentsec/audit/checks/_docker_common.py`
- Modify: `tests/test_docker_common.py`

This helper applies the 7 runtime rules in `container_baseline.yaml:runtime` to a docker-compat inspect JSON. Returns a list of Finding kwarg dicts (Option α). Callers wrap with `self.make_finding(ctx, **kwargs)`.

- [ ] **Step 1: Write failing tests**

Append to `tests/test_docker_common.py`:

```python
# ---- _evaluate_inspect ----

_RUNTIME_RULES_FIXTURE = [
    {
        "id": "runtime-privileged",
        "severity": "critical",
        "title": "容器以 --privileged 运行",
        "description": "privileged 容器…",
        "remediation": "移除 --privileged",
        "threat_refs_template": "{prefix}-RUNTIME-PRIVILEGED",
    },
    {
        "id": "runtime-host-net",
        "severity": "high",
        "title": "容器使用 host network",
        "description": "NetworkMode=host…",
        "remediation": "使用 bridge",
        "threat_refs_template": "{prefix}-RUNTIME-HOST-NET",
    },
    {
        "id": "runtime-root-user",
        "severity": "medium",
        "title": "容器以 root 用户运行",
        "description": "Config.User 为 root…",
        "remediation": "显式 USER 1000:1000",
        "threat_refs_template": "{prefix}-RUNTIME-ROOT-USER",
    },
]


def test_evaluate_inspect_privileged_emits_finding():
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "1000:1000"},
        "HostConfig": {"Privileged": True, "NetworkMode": "bridge",
                       "Binds": [], "CapAdd": None,
                       "SecurityOpt": ["no-new-privileges:true"]},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="podman", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    privileged = [f for f in findings if f["evidence"].get("rule_id") == "runtime-privileged"]
    assert len(privileged) == 1
    assert privileged[0]["severity"] == "critical"
    assert privileged[0]["evidence"]["runtime"] == "podman"
    assert privileged[0]["threat_refs"] == ["TI-PODMAN-RUNTIME-PRIVILEGED"]


def test_evaluate_inspect_host_net_emits_finding():
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "1000:1000"},
        "HostConfig": {"Privileged": False, "NetworkMode": "host",
                       "Binds": [], "CapAdd": None, "SecurityOpt": []},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="containerd", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    host_net = [f for f in findings if f["evidence"].get("rule_id") == "runtime-host-net"]
    assert len(host_net) == 1
    assert host_net[0]["evidence"]["runtime"] == "containerd"
    assert host_net[0]["threat_refs"] == ["TI-CONTAINERD-RUNTIME-HOST-NET"]


def test_evaluate_inspect_rootless_root_user_downgrade():
    """Container running as root, but podman info says rootless=true →
    severity downgrade medium → low."""
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "root"},
        "HostConfig": {"Privileged": False, "NetworkMode": "bridge",
                       "Binds": [], "CapAdd": None, "SecurityOpt": []},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="podman", rootless=True,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    root_user = [f for f in findings if f["evidence"].get("rule_id") == "runtime-root-user"]
    assert len(root_user) == 1
    assert root_user[0]["severity"] == "low"  # downgraded from medium


def test_evaluate_inspect_compliant_zero_findings():
    inspect_json = [{
        "Id": "abc123",
        "Config": {"User": "1000:1000"},
        "HostConfig": {"Privileged": False, "NetworkMode": "bridge",
                       "Binds": [], "CapAdd": None,
                       "SecurityOpt": ["no-new-privileges:true"]},
    }]
    findings = _evaluate_inspect(
        inspect_json, runtime="podman", rootless=False,
        baseline_runtime_rules=_RUNTIME_RULES_FIXTURE,
    )
    assert findings == []
```

Update the top-of-file import in `tests/test_docker_common.py` to include `_evaluate_inspect`:

```python
from agentsec.audit.checks._docker_common import (
    _evaluate_inspect,
    detect_containerd_runtime,
    detect_ctr,
    detect_docker,
    detect_nerdctl,
    detect_podman,
    is_path_under,
)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_docker_common.py -k "evaluate_inspect" -v`

Expected: 4 FAIL with `ImportError: cannot import name '_evaluate_inspect'`.

- [ ] **Step 3: Add `_evaluate_inspect`**

Append to `src/agentsec/audit/checks/_docker_common.py`:

```python
_RUNTIME_PREFIX_BY_RUNTIME = {
    "docker": "TI-DOCKER",
    "podman": "TI-PODMAN",
    "containerd": "TI-CONTAINERD",
}


def _resolve_threat_ref(rule: dict, runtime: str) -> list[str]:
    """Build the threat_refs list for `runtime`. Two paths:
    1. rule has `threat_refs` (legacy 7f docker style) — return as-is
    2. rule has `threat_refs_template` (new helper-driven style) — render with prefix
    """
    if "threat_refs_template" in rule:
        prefix = _RUNTIME_PREFIX_BY_RUNTIME[runtime]
        return [rule["threat_refs_template"].format(prefix=prefix)]
    return list(rule.get("threat_refs", []))


def _evaluate_inspect(
    inspect_json: list[dict] | dict,
    *,
    runtime: str,
    rootless: bool = False,
    baseline_runtime_rules: list[dict],
) -> list[dict]:
    """Apply runtime baseline rules to docker-compat inspect JSON.
    
    Returns a list of Finding kwarg dicts. Caller wraps with `make_finding`.
    `evidence.runtime` and `threat_refs` populated per `runtime` arg.
    rule `runtime-root-user` severity downgraded medium → low when rootless=True.
    """
    # Normalize: docker/podman inspect returns list; consumer may pass either.
    container = inspect_json[0] if isinstance(inspect_json, list) else inspect_json
    cfg = container.get("Config") or {}
    host_cfg = container.get("HostConfig") or {}
    findings: list[dict] = []
    
    rules_by_id = {r["id"]: r for r in baseline_runtime_rules}
    
    def _emit(rule_id: str, evidence_extra: dict, severity_override: str | None = None):
        rule = rules_by_id.get(rule_id)
        if rule is None:
            return
        severity = severity_override or rule["severity"]
        findings.append({
            "severity": severity,
            "title": rule["title"],
            "description": rule["description"],
            "evidence": {
                "runtime": runtime,
                "rule_id": rule_id,
                "container_id": container.get("Id", "")[:12],
                **evidence_extra,
            },
            "remediation": rule["remediation"],
            "threat_refs": _resolve_threat_ref(rule, runtime),
        })
    
    if host_cfg.get("Privileged"):
        _emit("runtime-privileged", {"privileged": True})
    
    if host_cfg.get("NetworkMode") == "host":
        _emit("runtime-host-net", {"network_mode": "host"})
    
    user = cfg.get("User", "").strip()
    if user in ("", "root", "0"):
        sev = "low" if rootless else None
        _emit("runtime-root-user", {"user": user}, severity_override=sev)
    
    binds = host_cfg.get("Binds") or []
    for bind in binds:
        if "/var/run/docker.sock" in bind:
            _emit("runtime-sock-mount", {"bind": bind})
    
    sensitive_paths = ["/", "/etc", "/root", "/proc", "/sys"]
    for bind in binds:
        if ":" not in bind:
            continue
        src = bind.split(":", 1)[0]
        for sensitive in sensitive_paths:
            if is_path_under(src, sensitive):
                _emit("runtime-host-fs-mount", {"bind": bind, "sensitive_path": sensitive})
                break
    
    dangerous_caps = {"SYS_ADMIN", "NET_ADMIN", "SYS_PTRACE"}
    cap_add = host_cfg.get("CapAdd") or []
    for cap in cap_add:
        cap_name = cap.replace("CAP_", "")
        if cap_name in dangerous_caps:
            _emit("runtime-cap-dangerous", {"cap": cap_name})
    
    security_opt = host_cfg.get("SecurityOpt") or []
    no_new_priv = any("no-new-privileges:true" in opt for opt in security_opt)
    if not no_new_priv and user in ("", "root", "0"):
        _emit("runtime-no-new-priv-missing", {"security_opt": list(security_opt)})
    
    return findings
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_docker_common.py -k "evaluate_inspect" -v`

Expected: 4 PASS.

- [ ] **Step 5: Run full pytest to confirm no regressions**

Run: `.venv/bin/pytest tests/ -q 2>&1 | tail -3`

Expected: count = previous (1413) + 12 + 4 = ~1429 PASS.

- [ ] **Step 6: Commit**

```bash
git add src/agentsec/audit/checks/_docker_common.py tests/test_docker_common.py
git commit -m "feat(7f.1): _evaluate_inspect helper for runtime baseline rules

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 4: _evaluate_image_tag shared helper

**Files:**
- Modify: `src/agentsec/audit/checks/_docker_common.py`
- Modify: `tests/test_docker_common.py`

- [ ] **Step 1: Write failing tests**

Append to `tests/test_docker_common.py`:

```python
# ---- _evaluate_image_tag ----

_IMAGE_PATTERNS_FIXTURE = [
    {
        "pattern": "*:latest",
        "severity": "medium",
        "title": "镜像未固定版本",
        "description": ":latest 不可重复",
        "remediation": "锁定 sha256 digest",
        "threat_refs_template": "{prefix}-IMAGE-LATEST",
    },
    {
        "pattern": "python:2.*",
        "severity": "high",
        "title": "Python 2 镜像（EOL）",
        "description": "Python 2 EOL",
        "remediation": "升级 python:3.11",
        "threat_refs_template": "{prefix}-IMAGE-PYTHON2-EOL",
    },
]


def test_evaluate_image_tag_match_latest():
    findings = _evaluate_image_tag(
        repo="nginx", tag="latest",
        runtime="podman",
        baseline_image_patterns=_IMAGE_PATTERNS_FIXTURE,
    )
    assert len(findings) == 1
    assert findings[0]["evidence"]["runtime"] == "podman"
    # image_patterns TIs are SHARED across runtimes per spec §4.2; use TI-DOCKER
    assert findings[0]["threat_refs"] == ["TI-DOCKER-IMAGE-LATEST"]


def test_evaluate_image_tag_match_python2():
    findings = _evaluate_image_tag(
        repo="python", tag="2.7",
        runtime="containerd",
        baseline_image_patterns=_IMAGE_PATTERNS_FIXTURE,
    )
    assert len(findings) == 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["evidence"]["runtime"] == "containerd"


def test_evaluate_image_tag_no_match():
    findings = _evaluate_image_tag(
        repo="nginx", tag="1.25.4",
        runtime="podman",
        baseline_image_patterns=_IMAGE_PATTERNS_FIXTURE,
    )
    assert findings == []
```

Update import to include `_evaluate_image_tag`:

```python
from agentsec.audit.checks._docker_common import (
    _evaluate_image_tag,
    _evaluate_inspect,
    detect_containerd_runtime,
    detect_ctr,
    detect_docker,
    detect_nerdctl,
    detect_podman,
    is_path_under,
)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_docker_common.py -k "evaluate_image_tag" -v`

Expected: 3 FAIL with `ImportError`.

- [ ] **Step 3: Add `_evaluate_image_tag`**

Append to `src/agentsec/audit/checks/_docker_common.py`:

```python
import fnmatch


def _evaluate_image_tag(
    repo: str,
    tag: str,
    *,
    runtime: str,
    baseline_image_patterns: list[dict],
) -> list[dict]:
    """fnmatch image_patterns against `<repo>:<tag>`. Returns Finding kwargs.
    
    Per spec §4.2, image_patterns TI refs are SHARED across runtimes (image
    content is runtime-agnostic). Hardcoded "TI-DOCKER-IMAGE-*" prefix when
    threat_refs_template uses {prefix}, regardless of `runtime` arg —
    `runtime` field still populated in evidence for cross-runtime dedupe.
    """
    image_ref = f"{repo}:{tag}"
    findings: list[dict] = []
    for pattern_rule in baseline_image_patterns:
        if fnmatch.fnmatch(image_ref, pattern_rule["pattern"]):
            template = pattern_rule.get("threat_refs_template", "")
            if template:
                threat_refs = [template.format(prefix="TI-DOCKER")]
            else:
                threat_refs = list(pattern_rule.get("threat_refs", []))
            findings.append({
                "severity": pattern_rule["severity"],
                "title": pattern_rule["title"],
                "description": pattern_rule["description"],
                "evidence": {
                    "runtime": runtime,
                    "image": image_ref,
                    "pattern_matched": pattern_rule["pattern"],
                },
                "remediation": pattern_rule["remediation"],
                "threat_refs": threat_refs,
            })
    return findings
```

Note: `import fnmatch` goes at the top of `_docker_common.py` with other imports.

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_docker_common.py -k "evaluate_image_tag" -v`

Expected: 3 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/checks/_docker_common.py tests/test_docker_common.py
git commit -m "feat(7f.1): _evaluate_image_tag helper (shared image_patterns TIs)

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 5: _parse_ctr_info shared helper

**Files:**
- Modify: `src/agentsec/audit/checks/_docker_common.py`
- Modify: `tests/test_docker_common.py`

- [ ] **Step 1: Write failing tests**

Append to `tests/test_docker_common.py`:

```python
# ---- _parse_ctr_info ----

def test_parse_ctr_info_privileged():
    text = (_FIXTURES_CONTAINER / "containerd_ctr_info_privileged.txt").read_text()
    parsed = _parse_ctr_info(text)
    assert parsed["root_user_uid"] == 0
    assert "CAP_SYS_ADMIN" in parsed["capabilities"]
    assert "CAP_NET_ADMIN" in parsed["capabilities"]
    assert parsed["privileged"] is True  # All 3 dangerous caps present
    assert parsed["host_network"] is True  # network namespace path set


def test_parse_ctr_info_clean():
    text = (_FIXTURES_CONTAINER / "containerd_ctr_info_clean.txt").read_text()
    parsed = _parse_ctr_info(text)
    assert parsed["root_user_uid"] == 1000
    assert parsed["capabilities"] == []
    assert parsed["privileged"] is False
    assert parsed["host_network"] is False


def test_parse_ctr_info_malformed_raises():
    with pytest.raises(ValueError):
        _parse_ctr_info("{not valid json")
```

Add a fixtures-path constant near the top of `tests/test_docker_common.py` (if not already present):

```python
from pathlib import Path

_FIXTURES_CONTAINER = Path(__file__).parent / "fixtures" / "container"
```

Also add `import pytest` to the test file if not already there.

Update import to include `_parse_ctr_info`:

```python
from agentsec.audit.checks._docker_common import (
    _evaluate_image_tag,
    _evaluate_inspect,
    _parse_ctr_info,
    detect_containerd_runtime,
    detect_ctr,
    detect_docker,
    detect_nerdctl,
    detect_podman,
    is_path_under,
)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_docker_common.py -k "parse_ctr_info" -v`

Expected: 3 FAIL with `ImportError`.

- [ ] **Step 3: Add `_parse_ctr_info`**

Append to `src/agentsec/audit/checks/_docker_common.py`:

```python
def _parse_ctr_info(text: str) -> dict:
    """`ctr containers info <id>` JSON-shaped text → structured dict.
    
    Returns:
        {
            "privileged": bool,         # any of SYS_ADMIN/NET_ADMIN/SYS_PTRACE in caps
            "host_network": bool,        # network namespace has `path` field set
            "capabilities": list[str],   # effective caps with CAP_ prefix
            "root_user_uid": int,        # process.user.uid
            "no_new_privileges": bool,   # process.noNewPrivileges
        }
    
    Raises ValueError on JSON decode failure.
    """
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ValueError(f"ctr info not parseable: {e}") from e
    
    spec = data.get("Spec", {}) or {}
    process = spec.get("process", {}) or {}
    linux = spec.get("linux", {}) or {}
    
    user = process.get("user", {}) or {}
    uid = user.get("uid", 0)
    
    caps_section = process.get("capabilities", {}) or {}
    capabilities = list(caps_section.get("effective", []))
    
    no_new_priv = bool(process.get("noNewPrivileges", False))
    
    # Privileged = any dangerous cap present
    dangerous = {"CAP_SYS_ADMIN", "CAP_NET_ADMIN", "CAP_SYS_PTRACE"}
    privileged = any(cap in dangerous for cap in capabilities)
    
    # Host network = network namespace has path (not just type)
    namespaces = linux.get("namespaces", []) or []
    host_network = any(
        ns.get("type") == "network" and ns.get("path")
        for ns in namespaces
    )
    
    return {
        "privileged": privileged,
        "host_network": host_network,
        "capabilities": capabilities,
        "root_user_uid": uid,
        "no_new_privileges": no_new_priv,
    }
```

Note: `import json` is already at the top of `_docker_common.py` (used by Stage E code). Confirm before adding.

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_docker_common.py -k "parse_ctr_info" -v`

Expected: 3 PASS.

- [ ] **Step 5: Run full pytest**

Run: `.venv/bin/pytest tests/ -q 2>&1 | tail -3`

Expected: ~1435 PASS (1413 baseline + 22 new test_docker_common tests so far).

- [ ] **Step 6: Commit**

```bash
git add src/agentsec/audit/checks/_docker_common.py tests/test_docker_common.py
git commit -m "feat(7f.1): _parse_ctr_info helper for ctr-fallback mode

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 6: container_baseline.yaml — daemon_podman section + threat_refs_template on existing rules

**Files:**
- Modify: `src/agentsec/audit/checks/container_baseline.yaml`

- [ ] **Step 1: Add `daemon_podman:` section**

Edit `src/agentsec/audit/checks/container_baseline.yaml`. Append (after the existing `image_patterns:` section):

```yaml

daemon_podman:
  - id: podman-rootful-mode
    severity: high
    title: "podman 以 rootful 模式运行"
    description: |
      `podman info` 显示 host.security.rootless == false，意味着 podman
      进程与所有容器以宿主 root 运行，丧失 podman 默认的 rootless 隔离。
    remediation: |
      以非 root 用户运行 podman；如必须 rootful，确认是否真的需要
      （如访问 host network namespace、特定 device passthrough）。
    threat_refs: ["TI-PODMAN-DAEMON-ROOTFUL"]

  - id: podman-userns-default-host
    severity: medium
    title: "podman 默认 userns 设为 host"
    description: |
      containers.conf:[containers].userns = "host"（或字段缺失，podman
      默认即 host）时，容器进程的 uid/gid 直接映射宿主，逃逸即 root。
    remediation: |
      containers.conf 设 `[containers].userns = "auto"` 或 `"keep-id"`。
    threat_refs: ["TI-PODMAN-DAEMON-USERNS"]

  - id: podman-no-new-priv-off
    severity: medium
    title: "podman 全局未默认启用 no-new-privileges"
    description: |
      containers.conf:[containers].no_new_privileges = false（默认值）时
      容器内 setuid 程序可向上提权。
    remediation: |
      containers.conf 设 `[containers].no_new_privileges = true`。
    threat_refs: ["TI-PODMAN-DAEMON-NO-NEW-PRIV"]

  - id: podman-version-cve
    severity: high
    title: "podman 版本落入已知 CVE 范围"
    description: |
      podman.Client.Version 落入 known_bad_versions 范围。
    remediation: |
      升级到最新 distro 包（dnf upgrade podman）。
    known_bad_versions:
      - "<4.9.0"
    threat_refs: ["TI-PODMAN-DAEMON-VERSION-CVE"]
```

- [ ] **Step 2: Add `threat_refs_template` to runtime + image_patterns rules**

The existing `runtime:` rules each have a `threat_refs: ["TI-DOCKER-RUNTIME-..."]` hardcoded entry. The new `_evaluate_inspect` helper supports an alternative `threat_refs_template` key that renders per-runtime prefix.

For each rule in `runtime:` (7 rules) AND in `image_patterns:` (7 patterns) add a sibling `threat_refs_template` field WITHOUT removing the existing `threat_refs`. The existing 7f Docker Checks consume `threat_refs` directly; the new 7f.1 Checks consume `threat_refs_template`. This preserves 7f docker behavior unchanged.

For `runtime:` 7 rules, add these `threat_refs_template` values (next to each rule's existing `threat_refs` line):
- `runtime-privileged` → `threat_refs_template: "{prefix}-RUNTIME-PRIVILEGED"`
- `runtime-host-net` → `threat_refs_template: "{prefix}-RUNTIME-HOST-NET"`
- `runtime-sock-mount` → `threat_refs_template: "{prefix}-RUNTIME-DOCKER-SOCK-MOUNT"`
- `runtime-host-fs-mount` → `threat_refs_template: "{prefix}-RUNTIME-HOST-FS-MOUNT"`
- `runtime-root-user` → `threat_refs_template: "{prefix}-RUNTIME-ROOT-USER"`
- `runtime-cap-dangerous` → `threat_refs_template: "{prefix}-RUNTIME-CAP-DANGEROUS"`
- `runtime-no-new-priv-missing` → `threat_refs_template: "{prefix}-RUNTIME-NO-NEW-PRIV"`

For `image_patterns:` 7 patterns, add `threat_refs_template: "{prefix}-IMAGE-..."` matching each pattern's existing TI suffix. E.g., for the `python:2.*` pattern that has `threat_refs: ["TI-DOCKER-IMAGE-PYTHON2-EOL"]`, add `threat_refs_template: "{prefix}-IMAGE-PYTHON2-EOL"`. List all 7:
- `*:latest` → `threat_refs_template: "{prefix}-IMAGE-LATEST"`
- `python:2.*` → `threat_refs_template: "{prefix}-IMAGE-PYTHON2-EOL"`
- `node:1[0-4]*` → `threat_refs_template: "{prefix}-IMAGE-NODE-EOL"`
- `node:1[68]*` → `threat_refs_template: "{prefix}-IMAGE-NODE-EOL"`
- `ubuntu:1[468]*` → `threat_refs_template: "{prefix}-IMAGE-UBUNTU-EOL"`
- `debian:[789]*` → `threat_refs_template: "{prefix}-IMAGE-DEBIAN-EOL"`
- `centos:[678]` → `threat_refs_template: "{prefix}-IMAGE-CENTOS-EOL"`

Important: for image_patterns the helper hardcodes `prefix="TI-DOCKER"` so the rendered TI is `TI-DOCKER-IMAGE-LATEST`. The new podman/containerd image findings reference the same TIs.

- [ ] **Step 3: Sanity-check YAML parses**

Run:
```bash
.venv/bin/python -c "import yaml; data = yaml.safe_load(open('src/agentsec/audit/checks/container_baseline.yaml')); print(list(data.keys()))"
```

Expected: `['daemon', 'runtime', 'image_patterns', 'daemon_podman']`.

- [ ] **Step 4: Run full pytest**

Run: `.venv/bin/pytest tests/ -q 2>&1 | tail -3`

Expected: ~1435 PASS (no test added; existing tests still pass with the additional optional `threat_refs_template` keys).

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/checks/container_baseline.yaml
git commit -m "data(7f.1): container_baseline.yaml — daemon_podman section + threat_refs_template

4 new podman daemon rules. Existing runtime + image_patterns rules gain
optional `threat_refs_template` field used by 7f.1 helpers; existing 7f
Checks unchanged.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 7: threat_intel.yaml — 19 new TI rows

**Files:**
- Modify: `src/agentsec/audit/ioc/threat_intel.yaml`

- [ ] **Step 1: Append 19 TI rows**

Edit `src/agentsec/audit/ioc/threat_intel.yaml`. Find the end of the `TI-DOCKER-*` block (around line 2950 — locate via `grep -n "TI-DOCKER-IMAGE-CENTOS-EOL" src/agentsec/audit/ioc/threat_intel.yaml`). Append after the last docker TI:

```yaml
# Phase 7f.1 — Podman + Containerd security baseline
- id: TI-PODMAN-DAEMON-ROOTFUL
  source: hand-curated
  url: https://docs.podman.io/en/latest/markdown/podman.1.html
  observed_at: '2026-05-12'
  claim: podman rootful 模式失去 rootless 隔离；进程与容器以宿主 root 运行
  cvss: 6.5
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["podman_daemon_audit"]
  auto_refresh: false
- id: TI-PODMAN-DAEMON-USERNS
  source: hand-curated
  url: https://docs.podman.io/en/latest/markdown/podman-run.1.html#userns-mode
  observed_at: '2026-05-12'
  claim: podman containers.conf userns=host 时容器 uid/gid 直接映射宿主
  cvss: 5.0
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["podman_daemon_audit"]
  auto_refresh: false
- id: TI-PODMAN-DAEMON-NO-NEW-PRIV
  source: hand-curated
  url: https://docs.podman.io/en/latest/markdown/podman-run.1.html#security-opt-option
  observed_at: '2026-05-12'
  claim: podman 全局未默认 no_new_privileges 时容器内 setuid 提权可达
  cvss: 5.0
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["podman_daemon_audit"]
  auto_refresh: false
- id: TI-PODMAN-DAEMON-VERSION-CVE
  source: hand-curated
  url: https://github.com/containers/podman/security/advisories
  observed_at: '2026-05-12'
  claim: podman 旧版本含已知 CVE（占位：< 4.9.0）
  cvss: 7.0
  cvss_source: AgentSec curated baseline
  confidence: medium
  mapped_tests: ["podman_daemon_audit"]
  auto_refresh: false
- id: TI-PODMAN-RUNTIME-PRIVILEGED
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: privileged podman 容器持有几乎所有 capability 与 device，等价宿主 root
  cvss: 9.0
  cvss_source: CIS Docker Benchmark v1.6.0 §5.4
  confidence: high
  mapped_tests: ["podman_runtime_audit"]
  auto_refresh: false
- id: TI-PODMAN-RUNTIME-HOST-NET
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: podman host network 模式共享宿主网络栈
  cvss: 7.0
  cvss_source: CIS Docker Benchmark v1.6.0 §5.9
  confidence: high
  mapped_tests: ["podman_runtime_audit"]
  auto_refresh: false
- id: TI-PODMAN-RUNTIME-DOCKER-SOCK-MOUNT
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: podman 挂载 docker.sock 等价宿主 root
  cvss: 9.5
  cvss_source: CIS Docker Benchmark v1.6.0 §5.31
  confidence: high
  mapped_tests: ["podman_runtime_audit"]
  auto_refresh: false
- id: TI-PODMAN-RUNTIME-HOST-FS-MOUNT
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: podman 容器挂载宿主敏感路径
  cvss: 7.5
  cvss_source: CIS Docker Benchmark v1.6.0 §5.6
  confidence: high
  mapped_tests: ["podman_runtime_audit"]
  auto_refresh: false
- id: TI-PODMAN-RUNTIME-ROOT-USER
  source: hand-curated
  url: https://docs.podman.io/en/latest/markdown/podman-run.1.html
  observed_at: '2026-05-12'
  claim: podman 容器以 root 运行；rootless 模式下 severity 降级
  cvss: 5.5
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["podman_runtime_audit"]
  auto_refresh: false
- id: TI-PODMAN-RUNTIME-CAP-DANGEROUS
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: podman 容器申请高危 cap（SYS_ADMIN / NET_ADMIN / SYS_PTRACE）
  cvss: 7.0
  cvss_source: CIS Docker Benchmark v1.6.0
  confidence: high
  mapped_tests: ["podman_runtime_audit"]
  auto_refresh: false
- id: TI-PODMAN-RUNTIME-NO-NEW-PRIV
  source: hand-curated
  url: https://docs.podman.io/en/latest/markdown/podman-run.1.html
  observed_at: '2026-05-12'
  claim: podman 容器未设 no-new-privileges 且以 root 运行
  cvss: 5.5
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["podman_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-RUNTIME-PRIVILEGED
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: privileged containerd 容器持有几乎所有 capability 与 device，等价宿主 root
  cvss: 9.0
  cvss_source: CIS Docker Benchmark v1.6.0 §5.4
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-RUNTIME-HOST-NET
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: containerd host network 模式共享宿主网络栈
  cvss: 7.0
  cvss_source: CIS Docker Benchmark v1.6.0 §5.9
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-RUNTIME-DOCKER-SOCK-MOUNT
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: containerd 容器挂载 docker.sock 等价宿主 root
  cvss: 9.5
  cvss_source: CIS Docker Benchmark v1.6.0 §5.31
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-RUNTIME-HOST-FS-MOUNT
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: containerd 容器挂载宿主敏感路径
  cvss: 7.5
  cvss_source: CIS Docker Benchmark v1.6.0 §5.6
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-RUNTIME-ROOT-USER
  source: hand-curated
  url: https://github.com/containerd/containerd
  observed_at: '2026-05-12'
  claim: containerd 容器以 root 运行
  cvss: 5.5
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-RUNTIME-CAP-DANGEROUS
  source: hand-curated
  url: https://www.cisecurity.org/benchmark/docker
  observed_at: '2026-05-12'
  claim: containerd 容器申请高危 cap
  cvss: 7.0
  cvss_source: CIS Docker Benchmark v1.6.0
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-RUNTIME-NO-NEW-PRIV
  source: hand-curated
  url: https://github.com/containerd/containerd
  observed_at: '2026-05-12'
  claim: containerd 容器未设 no-new-privileges 且以 root 运行
  cvss: 5.5
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
- id: TI-CONTAINERD-COVERAGE-PARTIAL
  source: hand-curated
  url: https://github.com/containerd/containerd/blob/main/docs/getting-started.md
  observed_at: '2026-05-12'
  claim: containerd_runtime_audit 在 ctr 回退模式下仅覆盖 4/7 runtime 规则（缺 host-fs-mount / sock-mount / no-new-priv）
  cvss: 1.0
  cvss_source: AgentSec curated baseline
  confidence: high
  mapped_tests: ["containerd_runtime_audit"]
  auto_refresh: false
```

- [ ] **Step 2: Verify YAML parses + 19 new rows**

Run:
```bash
.venv/bin/python -c "
import yaml
data = yaml.safe_load(open('src/agentsec/audit/ioc/threat_intel.yaml'))
podman_ids = [d['id'] for d in data if d['id'].startswith('TI-PODMAN-')]
containerd_ids = [d['id'] for d in data if d['id'].startswith('TI-CONTAINERD-')]
print(f'podman: {len(podman_ids)}, containerd: {len(containerd_ids)}, total new: {len(podman_ids)+len(containerd_ids)}')
"
```

Expected: `podman: 11, containerd: 8, total new: 19`.

- [ ] **Step 3: Run check_threat_refs**

Run: `.venv/bin/python scripts/check_threat_refs.py 2>&1 | tail -3`

Expected: OK (no orphan TI refs in code yet — the new TIs are unreferenced until Checks land in T8-T12).

- [ ] **Step 4: Run full pytest**

Run: `.venv/bin/pytest tests/ -q 2>&1 | tail -3`

Expected: ~1435 PASS (no change in test count).

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/ioc/threat_intel.yaml
git commit -m "data(7f.1): +19 TI rows (podman + containerd + partial-coverage)

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 8: PodmanDaemonAuditCheck

**Files:**
- Create: `src/agentsec/audit/checks/podman_daemon_audit.py`
- Create: `tests/test_podman_daemon_audit.py`

- [ ] **Step 1: Write failing tests**

Create `tests/test_podman_daemon_audit.py`:

```python
"""PodmanDaemonAuditCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.podman_daemon_audit import PodmanDaemonAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"

_BIN = "/usr/bin/podman"
_CONF_ETC = ("cat", "/etc/containers/containers.conf")
_CONF_USR = ("cat", "/usr/share/containers/containers.conf")
_VERSION = ("podman", "version", "--format", "{{json .}}")
_INFO = ("podman", "info", "--format", "{{json .}}")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _RecordingExecutor:
    def __init__(self, responses: dict[tuple, RunResult]):
        self._responses = responses
        self.calls: list[list[str]] = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(
                stdout="", stderr="", exit_code=1, rejected=False,
                reject_reason=None, argv=argv,
                command_sha256="0" * 64, duration_ms=0.0, bytes_out=0,
            ),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(
        executor=executor, redactor=Redactor(),
        ioc_dir=Path("/tmp"), profile=profile, log_review_config=None,
    )


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found_path: str | None) -> dict[tuple, RunResult]:
    candidates = ("/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman")
    out: dict[tuple, RunResult] = {}
    for c in candidates:
        if c == found_path:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c + "\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def _full_responses(*, conf_text: str, version_json: str, info_json: str,
                    found_podman: str = _BIN) -> dict[tuple, RunResult]:
    responses = _detect_responses(found_podman)
    responses[_CONF_ETC] = _runresult(stdout=conf_text)
    responses[_VERSION] = _runresult(stdout=version_json)
    responses[_INFO] = _runresult(stdout=info_json)
    return responses


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True


def test_not_applicable_no_podman():
    ctx = _ctx(_RecordingExecutor(_detect_responses(None)))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable is True


def test_compliant_zero_findings():
    conf = (_FIXTURES / "podman_containers_conf_compliant.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []


def test_rootful_emits_high():
    conf = (_FIXTURES / "podman_containers_conf_compliant.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootful.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert len(findings) == 1
    assert findings[0].severity == "high"
    assert findings[0].evidence["rule_id"] == "podman-rootful-mode"


def test_userns_host_emits_medium():
    conf = (_FIXTURES / "podman_containers_conf_userns_host.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-userns-default-host"
               and f.severity == "medium" for f in findings)


def test_userns_missing_emits_medium():
    """containers.conf 缺 userns 字段 → 视为 host"""
    conf = "[containers]\nno_new_privileges = true\n"
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-userns-default-host" for f in findings)


def test_no_new_priv_off_emits_medium():
    conf = (_FIXTURES / "podman_containers_conf_no_new_priv_off.toml").read_text()
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-no-new-priv-off"
               and f.severity == "medium" for f in findings)


def test_version_cve_emits_high():
    conf = (_FIXTURES / "podman_containers_conf_compliant.toml").read_text()
    version = (_FIXTURES / "podman_version_cve.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ctx = _ctx(_RecordingExecutor(_full_responses(
        conf_text=conf, version_json=version, info_json=info,
    )))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert any(f.evidence["rule_id"] == "podman-version-cve"
               and f.severity == "high" for f in findings)


def test_containers_conf_missing_falls_back_distro():
    """/etc/containers/containers.conf missing → fall back to /usr/share/..."""
    distro_conf = "[containers]\nuserns = \"auto\"\nno_new_privileges = true\n"
    version = (_FIXTURES / "podman_version_clean.json").read_text()
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_CONF_ETC] = _runresult(stderr="No such file", exit_code=1)
    responses[_CONF_USR] = _runresult(stdout=distro_conf)
    responses[_VERSION] = _runresult(stdout=version)
    responses[_INFO] = _runresult(stdout=info)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []  # distro defaults are compliant


def test_podman_info_perm_denied_skipped():
    responses = _detect_responses(_BIN)
    responses[_CONF_ETC] = _runresult(stdout="")
    responses[_INFO] = _runresult(stderr="Permission denied", exit_code=126)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanDaemonAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped is True
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_podman_daemon_audit.py -v`

Expected: 10 FAIL with `ModuleNotFoundError: No module named 'agentsec.audit.checks.podman_daemon_audit'`.

- [ ] **Step 3: Create the Check**

Create `src/agentsec/audit/checks/podman_daemon_audit.py`:

```python
"""Podman 配置审计（Phase 7f.1）。

无 daemon process（podman 是 daemonless），审计目标为 podman 的全局
配置文件 /etc/containers/containers.conf + `podman version/info` 输出。
4 条规则：rootful 模式 / userns / no_new_privileges / 版本 CVE。
"""

from __future__ import annotations

import json
import re
import tomllib
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import detect_podman
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"

_PERM_DENIED_SUBSTRINGS = ("permission denied", "operation not permitted")


def _looks_perm_denied(stderr: str) -> bool:
    s = stderr.lower()
    return any(needle in s for needle in _PERM_DENIED_SUBSTRINGS)


def _version_in_range(version: str, ranges: list[str]) -> bool:
    """Naive '< X.Y.Z' check."""
    def _key(v: str) -> tuple[int, ...]:
        return tuple(int(re.match(r"^(\d+)", p).group(1) or "0")
                     for p in v.split(".") if re.match(r"^(\d+)", p))
    for r in ranges:
        r = r.strip()
        if r.startswith("<") and _key(version) < _key(r[1:]):
            return True
    return False


class PodmanDaemonAuditCheck(Check):
    id = "podman_daemon_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._rules = {r["id"]: r for r in baseline["daemon_podman"]}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_podman(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 podman 二进制"
            )
            return []

        conf_etc = ctx.executor.run(["cat", "/etc/containers/containers.conf"])
        conf_text = ""
        if not conf_etc.rejected and conf_etc.exit_code == 0:
            conf_text = conf_etc.stdout
        else:
            conf_usr = ctx.executor.run(
                ["cat", "/usr/share/containers/containers.conf"]
            )
            if not conf_usr.rejected and conf_usr.exit_code == 0:
                conf_text = conf_usr.stdout
        try:
            conf_data = tomllib.loads(conf_text) if conf_text else {}
        except tomllib.TOMLDecodeError:
            conf_data = {}
        containers_section = conf_data.get("containers", {}) or {}

        version_result = ctx.executor.run(
            ["podman", "version", "--format", "{{json .}}"]
        )
        info_result = ctx.executor.run(
            ["podman", "info", "--format", "{{json .}}"]
        )
        if info_result.rejected or info_result.exit_code != 0:
            if _looks_perm_denied(info_result.stderr):
                ctx.status.skipped(
                    f"{self.id}：权限不足，需 root 或 NOPASSWD sudoers"
                )
            else:
                ctx.status.skipped(
                    f"{self.id}：podman info 退出码 {info_result.exit_code}"
                )
            return []

        try:
            info_data = json.loads(info_result.stdout)
        except json.JSONDecodeError:
            ctx.status.skipped(f"{self.id}：podman info 输出非 JSON")
            return []

        version_str = ""
        if not version_result.rejected and version_result.exit_code == 0:
            try:
                version_data = json.loads(version_result.stdout)
                version_str = version_data.get("Client", {}).get("Version", "")
            except json.JSONDecodeError:
                pass

        findings: list[Finding] = []

        rootless = info_data.get("host", {}).get("security", {}).get("rootless", False)
        if not rootless:
            rule = self._rules["podman-rootful-mode"]
            findings.append(self.make_finding(
                ctx, severity=rule["severity"], title=rule["title"],
                description=rule["description"],
                evidence={"runtime": "podman", "rule_id": "podman-rootful-mode",
                          "rootless": False},
                remediation=rule["remediation"],
                threat_refs=list(rule["threat_refs"]),
            ))

        userns = containers_section.get("userns")
        if userns in ("host", None):
            rule = self._rules["podman-userns-default-host"]
            findings.append(self.make_finding(
                ctx, severity=rule["severity"], title=rule["title"],
                description=rule["description"],
                evidence={"runtime": "podman", "rule_id": "podman-userns-default-host",
                          "userns": userns or "missing"},
                remediation=rule["remediation"],
                threat_refs=list(rule["threat_refs"]),
            ))

        nnp = containers_section.get("no_new_privileges", False)
        if not nnp:
            rule = self._rules["podman-no-new-priv-off"]
            findings.append(self.make_finding(
                ctx, severity=rule["severity"], title=rule["title"],
                description=rule["description"],
                evidence={"runtime": "podman", "rule_id": "podman-no-new-priv-off",
                          "no_new_privileges": nnp},
                remediation=rule["remediation"],
                threat_refs=list(rule["threat_refs"]),
            ))

        if version_str:
            rule = self._rules["podman-version-cve"]
            bad_versions = rule.get("known_bad_versions", [])
            if _version_in_range(version_str, bad_versions):
                findings.append(self.make_finding(
                    ctx, severity=rule["severity"], title=rule["title"],
                    description=rule["description"],
                    evidence={"runtime": "podman", "rule_id": "podman-version-cve",
                              "version": version_str},
                    remediation=rule["remediation"],
                    threat_refs=list(rule["threat_refs"]),
                ))

        return findings
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_podman_daemon_audit.py -v`

Expected: 10 PASS.

- [ ] **Step 5: Run full pytest**

Run: `.venv/bin/pytest tests/ -q 2>&1 | tail -3`

Expected: ~1445 PASS.

- [ ] **Step 6: Commit**

```bash
git add src/agentsec/audit/checks/podman_daemon_audit.py tests/test_podman_daemon_audit.py
git commit -m "feat(7f.1): PodmanDaemonAuditCheck (4 rules — rootful/userns/no-new-priv/version-cve)

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 9: PodmanRuntimeAuditCheck

**Files:**
- Create: `src/agentsec/audit/checks/podman_runtime_audit.py`
- Create: `tests/test_podman_runtime_audit.py`

- [ ] **Step 1: Write failing tests**

Create `tests/test_podman_runtime_audit.py`:

```python
"""PodmanRuntimeAuditCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.podman_runtime_audit import PodmanRuntimeAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"
_BIN = "/usr/bin/podman"
_INFO = ("podman", "info", "--format", "{{json .}}")
_PS = ("podman", "ps", "--format", "{{json .}}", "--no-trunc")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False) -> RunResult:
    return RunResult(
        stdout=stdout, stderr=stderr, exit_code=exit_code,
        rejected=rejected, reject_reason="policy" if rejected else None,
        argv=[], command_sha256="0" * 64, duration_ms=0.0,
        bytes_out=len(stdout.encode()),
    )


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []

    def run(self, argv, *, role=None):
        argv = list(argv)
        self.calls.append(argv)
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=argv, command_sha256="0"*64,
                      duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found):
    out = {}
    for c in ("/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman"):
        if c == found:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c + "\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_not_applicable_no_podman():
    ctx = _ctx(_RecordingExecutor(_detect_responses(None)))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_ps_empty_no_findings():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout="")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []


def test_inspect_compliant_zero_findings():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_line = '{"Id":"abc1234567890","Image":"nginx:1.25","Names":["web"]}'
    inspect = (_FIXTURES / "podman_inspect_compliant.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    assert findings == []


def test_inspect_privileged_critical():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_line = '{"Id":"abc1234567890","Image":"nginx:1.25","Names":["web"]}'
    inspect = (_FIXTURES / "podman_inspect_privileged.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    privileged = [f for f in findings if f.evidence.get("rule_id") == "runtime-privileged"]
    assert len(privileged) == 1
    assert privileged[0].severity == "critical"
    assert privileged[0].evidence["runtime"] == "podman"


def test_inspect_host_net_and_sock_mount():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_line = '{"Id":"abc1234567890"}'
    inspect = (_FIXTURES / "podman_inspect_host_net_sock_mount.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    rule_ids = {f.evidence["rule_id"] for f in findings}
    assert "runtime-host-net" in rule_ids
    assert "runtime-sock-mount" in rule_ids


def test_inspect_caps_user_multi():
    info = (_FIXTURES / "podman_info_rootful.json").read_text()  # rootful → root user normal severity
    ps_line = '{"Id":"abc1234567890"}'
    inspect = (_FIXTURES / "podman_inspect_caps_user.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    cap_findings = [f for f in findings if f.evidence.get("rule_id") == "runtime-cap-dangerous"]
    user_findings = [f for f in findings if f.evidence.get("rule_id") == "runtime-root-user"]
    assert len(cap_findings) == 2  # SYS_ADMIN + NET_ADMIN
    assert len(user_findings) == 1
    assert user_findings[0].severity == "medium"  # rootful → not downgraded


def test_rootless_root_user_downgrade():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()  # rootless = True
    ps_line = '{"Id":"abc1234567890"}'
    inspect = (_FIXTURES / "podman_inspect_caps_user.json").read_text()  # User=root
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_line)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    user_findings = [f for f in findings if f.evidence.get("rule_id") == "runtime-root-user"]
    assert len(user_findings) == 1
    assert user_findings[0].severity == "low"  # downgraded


def test_inspect_failure_partial_scan():
    info = (_FIXTURES / "podman_info_rootless.json").read_text()
    ps_lines = (
        '{"Id":"abc1234567890"}\n'
        '{"Id":"def9876543210"}'
    )
    inspect = (_FIXTURES / "podman_inspect_compliant.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_INFO] = _runresult(stdout=info)
    responses[_PS] = _runresult(stdout=ps_lines)
    responses[("podman", "inspect", "abc1234567890")] = _runresult(stdout=inspect)
    responses[("podman", "inspect", "def9876543210")] = _runresult(
        stderr="No such container", exit_code=1,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanRuntimeAuditCheck(), ctx)
    skipped_info = [f for f in findings
                    if f.evidence.get("skipped_container_ids")]
    assert len(skipped_info) == 1
    assert "def9876543210" in skipped_info[0].evidence["skipped_container_ids"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_podman_runtime_audit.py -v`

Expected: 9 FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Create the Check**

Create `src/agentsec/audit/checks/podman_runtime_audit.py`:

```python
"""Podman 运行时容器审计（Phase 7f.1）。

`podman ps` 列出运行中容器；逐个 `podman inspect <id>` 解析 HostConfig +
Config，复用 _docker_common._evaluate_inspect 应用 container_baseline.yaml
runtime 段的 7 条规则。rootless 模式下 runtime-root-user 严重性降一档。
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import _evaluate_inspect, detect_podman
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"
_MAX_CONTAINERS = 200
_MAX_SKIPPED_IDS = 20


class PodmanRuntimeAuditCheck(Check):
    id = "podman_runtime_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._runtime_rules = baseline["runtime"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_podman(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 podman 二进制"
            )
            return []

        info_result = ctx.executor.run(
            ["podman", "info", "--format", "{{json .}}"]
        )
        rootless = False
        if not info_result.rejected and info_result.exit_code == 0:
            try:
                info_data = json.loads(info_result.stdout)
                rootless = info_data.get("host", {}).get("security", {}).get("rootless", False)
            except json.JSONDecodeError:
                pass

        ps_result = ctx.executor.run(
            ["podman", "ps", "--format", "{{json .}}", "--no-trunc"]
        )
        if ps_result.rejected or ps_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：podman ps 退出码 {ps_result.exit_code}"
            )
            return []

        container_ids: list[str] = []
        for line in ps_result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                cid = obj.get("Id") or obj.get("ID")
                if cid:
                    container_ids.append(cid)
            except json.JSONDecodeError:
                continue

        findings: list[Finding] = []
        skipped_ids: list[str] = []

        if len(container_ids) > _MAX_CONTAINERS:
            container_ids = container_ids[:_MAX_CONTAINERS]

        for cid in container_ids:
            inspect_result = ctx.executor.run(["podman", "inspect", cid])
            if inspect_result.rejected or inspect_result.exit_code != 0:
                skipped_ids.append(cid)
                continue
            try:
                inspect_json = json.loads(inspect_result.stdout)
            except json.JSONDecodeError:
                skipped_ids.append(cid)
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_inspect(
                    inspect_json,
                    runtime="podman",
                    rootless=rootless,
                    baseline_runtime_rules=self._runtime_rules,
                )
            )

        if skipped_ids:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"{self.id}：{len(skipped_ids)} 个容器的 inspect 失败",
                description="部分容器扫描失败；finding 列表仅含成功扫描部分。",
                evidence={
                    "skipped_container_ids": skipped_ids[:_MAX_SKIPPED_IDS],
                    "truncated": len(skipped_ids) > _MAX_SKIPPED_IDS,
                },
                remediation="检查 podman 状态或运行用户权限。",
                threat_refs=[],
            ))

        return findings
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_podman_runtime_audit.py -v`

Expected: 9 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/checks/podman_runtime_audit.py tests/test_podman_runtime_audit.py
git commit -m "feat(7f.1): PodmanRuntimeAuditCheck (rootless-aware, partial-scan resilient)

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 10: PodmanImageCveCheck

**Files:**
- Create: `src/agentsec/audit/checks/podman_image_cve.py`
- Create: `tests/test_podman_image_cve.py`

- [ ] **Step 1: Write failing tests**

Create `tests/test_podman_image_cve.py`:

```python
"""PodmanImageCveCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.podman_image_cve import PodmanImageCveCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"
_BIN = "/usr/bin/podman"
_IMAGES = ("podman", "images", "--format", "{{json .}}")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False):
    return RunResult(stdout=stdout, stderr=stderr, exit_code=exit_code,
                     rejected=rejected, reject_reason="policy" if rejected else None,
                     argv=[], command_sha256="0"*64, duration_ms=0.0,
                     bytes_out=len(stdout.encode()))


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []
    def run(self, argv, *, role=None):
        self.calls.append(list(argv))
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=list(argv),
                      command_sha256="0"*64, duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _detect_responses(found):
    out = {}
    for c in ("/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman"):
        if c == found:
            out[("stat", "-c", "%n", c)] = _runresult(stdout=c+"\n")
        else:
            out[("stat", "-c", "%n", c)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_not_applicable_no_podman():
    ctx = _ctx(_RecordingExecutor(_detect_responses(None)))
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_images_zero_findings():
    responses = _detect_responses(_BIN)
    responses[_IMAGES] = _runresult(stdout="[]")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []


def test_images_mixed():
    images = (_FIXTURES / "podman_images_mixed.json").read_text()
    responses = _detect_responses(_BIN)
    responses[_IMAGES] = _runresult(stdout=images)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanImageCveCheck(), ctx)
    # nginx:latest → 1 (latest pattern)
    # python:2.7 → 1
    # node:14 → 1 (node:1[0-4]* pattern)
    # ubuntu:22.04 + debian:12 → 0
    assert len(findings) == 3
    for f in findings:
        assert f.evidence["runtime"] == "podman"


def test_images_perm_denied_skipped():
    responses = _detect_responses(_BIN)
    responses[_IMAGES] = _runresult(stderr="Permission denied", exit_code=126)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(PodmanImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_podman_image_cve.py -v`

Expected: 5 FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Create the Check**

Create `src/agentsec/audit/checks/podman_image_cve.py`:

```python
"""Podman 镜像 CVE 审计（Phase 7f.1）。

`podman images --format json` → 逐 image 调 `_evaluate_image_tag` 套
image_patterns 段 7 条 fnmatch 规则。
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import _evaluate_image_tag, detect_podman
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"

_PERM_DENIED_SUBSTRINGS = ("permission denied", "operation not permitted")


def _looks_perm_denied(stderr: str) -> bool:
    s = stderr.lower()
    return any(needle in s for needle in _PERM_DENIED_SUBSTRINGS)


class PodmanImageCveCheck(Check):
    id = "podman_image_cve"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._patterns = baseline["image_patterns"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_podman(ctx) is None:
            ctx.status.not_applicable(
                f"{self.id}：被审主机未检出 podman 二进制"
            )
            return []

        result = ctx.executor.run(["podman", "images", "--format", "{{json .}}"])
        if result.rejected or result.exit_code != 0:
            if _looks_perm_denied(result.stderr):
                ctx.status.skipped(f"{self.id}：权限不足")
            else:
                ctx.status.skipped(
                    f"{self.id}：podman images 退出码 {result.exit_code}"
                )
            return []

        try:
            images = json.loads(result.stdout) if result.stdout.strip() else []
        except json.JSONDecodeError:
            ctx.status.skipped(f"{self.id}：podman images 输出非 JSON")
            return []

        findings: list[Finding] = []
        for img in images:
            repo = img.get("Repository") or ""
            tag = img.get("Tag") or ""
            if not repo or not tag:
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_image_tag(
                    repo, tag,
                    runtime="podman",
                    baseline_image_patterns=self._patterns,
                )
            )
        return findings
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_podman_image_cve.py -v`

Expected: 5 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/checks/podman_image_cve.py tests/test_podman_image_cve.py
git commit -m "feat(7f.1): PodmanImageCveCheck

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 11: ContainerdRuntimeAuditCheck

**Files:**
- Create: `src/agentsec/audit/checks/containerd_runtime_audit.py`
- Create: `tests/test_containerd_runtime_audit.py`

- [ ] **Step 1: Write failing tests**

Create `tests/test_containerd_runtime_audit.py`:

```python
"""ContainerdRuntimeAuditCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.containerd_runtime_audit import ContainerdRuntimeAuditCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"

_NERDCTL_BIN = "/usr/local/bin/nerdctl"
_CTR_BIN = "/usr/bin/ctr"
_DOCKER_BIN = "/usr/bin/docker"
_SOCKET = "/run/containerd/containerd.sock"
_DOCKER_SOCKET = "/var/run/docker.sock"

_NERDCTL_PS = ("nerdctl", "ps", "--format", "{{json .}}", "--no-trunc")
_CTR_LIST = ("ctr", "--namespace", "default", "containers", "list", "-q")


def _runresult(stdout="", stderr="", exit_code=0, rejected=False):
    return RunResult(stdout=stdout, stderr=stderr, exit_code=exit_code,
                     rejected=rejected, reject_reason="policy" if rejected else None,
                     argv=[], command_sha256="0"*64, duration_ms=0.0,
                     bytes_out=len(stdout.encode()))


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []
    def run(self, argv, *, role=None):
        self.calls.append(list(argv))
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=list(argv),
                      command_sha256="0"*64, duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_responses(present: tuple[str, ...]) -> dict[tuple, RunResult]:
    """Return stat responses with the given paths marked exit=0, others exit=1."""
    # Cover all paths we probe: docker, podman, nerdctl, ctr, socket
    all_paths = [
        "/usr/bin/docker", "/usr/local/bin/docker", "/opt/homebrew/bin/docker",
        "/usr/bin/podman", "/usr/local/bin/podman", "/opt/homebrew/bin/podman",
        "/usr/local/bin/nerdctl", "/usr/bin/nerdctl",
        "/usr/bin/ctr", "/usr/local/bin/ctr",
        "/run/containerd/containerd.sock",
        "/var/run/docker.sock",
    ]
    out = {}
    for p in all_paths:
        if p in present:
            out[("stat", "-c", "%n", p)] = _runresult(stdout=p+"\n")
        else:
            out[("stat", "-c", "%n", p)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_not_applicable_no_containerd():
    """No nerdctl, no ctr, no socket → not_applicable."""
    ctx = _ctx(_RecordingExecutor(_stat_responses(present=())))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_docker_takeover_yield():
    """docker + docker.sock active → not_applicable."""
    responses = _stat_responses(present=(
        _DOCKER_BIN, _DOCKER_SOCKET, _NERDCTL_BIN, _SOCKET,
    ))
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable
    assert "docker" in (ctx.status.not_applicable_reason or "").lower()


def test_nerdctl_mode_compliant():
    inspect = '[{"Id":"k8sabc","Config":{"User":"1000"},"HostConfig":{"Privileged":false,"NetworkMode":"bridge","Binds":[],"CapAdd":null,"SecurityOpt":["no-new-privileges:true"]}}]'
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout='{"ID":"k8sabc"}\n')
    responses[("nerdctl", "inspect", "k8sabc")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []


def test_nerdctl_mode_privileged():
    inspect = (_FIXTURES / "containerd_nerdctl_inspect_privileged.json").read_text()
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout='{"ID":"k8sabc"}\n')
    responses[("nerdctl", "inspect", "k8sabc")] = _runresult(stdout=inspect)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    priv = [f for f in findings if f.evidence.get("rule_id") == "runtime-privileged"]
    assert len(priv) == 1
    assert priv[0].evidence["runtime"] == "containerd"


def test_ctr_mode_privileged():
    info = (_FIXTURES / "containerd_ctr_info_privileged.txt").read_text()
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[_CTR_LIST] = _runresult(stdout="ctrabc1234\n")
    responses[("ctr", "--namespace", "default", "containers", "info", "ctrabc1234")] = _runresult(stdout=info)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    priv = [f for f in findings if f.evidence.get("rule_id") == "runtime-privileged"]
    assert len(priv) == 1
    assert priv[0].evidence["coverage"] == "partial"
    assert priv[0].evidence["mode"] == "ctr"


def test_ctr_mode_partial_coverage_finding():
    """ctr mode emits a TI-CONTAINERD-COVERAGE-PARTIAL info finding."""
    info = (_FIXTURES / "containerd_ctr_info_clean.txt").read_text()
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[_CTR_LIST] = _runresult(stdout="ctrdef5678\n")
    responses[("ctr", "--namespace", "default", "containers", "info", "ctrdef5678")] = _runresult(stdout=info)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    partial = [f for f in findings if "TI-CONTAINERD-COVERAGE-PARTIAL" in f.threat_refs]
    assert len(partial) == 1
    assert partial[0].severity == "info"


def test_ctr_mode_parse_failure_skips_container():
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[_CTR_LIST] = _runresult(stdout="ctrabc1234\n")
    responses[("ctr", "--namespace", "default", "containers", "info", "ctrabc1234")] = _runresult(stdout="{malformed")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    # The container is skipped; only the partial-coverage info finding remains
    rule_findings = [f for f in findings if f.evidence.get("rule_id")]
    assert rule_findings == []


def test_ps_empty_no_findings():
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout="")
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    assert findings == []


def test_inspect_failure_partial_scan():
    inspect = (_FIXTURES / "containerd_nerdctl_inspect_privileged.json").read_text()
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[_NERDCTL_PS] = _runresult(stdout='{"ID":"k8sabc"}\n{"ID":"k8sdef"}\n')
    responses[("nerdctl", "inspect", "k8sabc")] = _runresult(stdout=inspect)
    responses[("nerdctl", "inspect", "k8sdef")] = _runresult(stderr="No such container", exit_code=1)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdRuntimeAuditCheck(), ctx)
    skipped_info = [f for f in findings if f.evidence.get("skipped_container_ids")]
    assert len(skipped_info) == 1
    assert "k8sdef" in skipped_info[0].evidence["skipped_container_ids"]
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_containerd_runtime_audit.py -v`

Expected: 10 FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Create the Check**

Create `src/agentsec/audit/checks/containerd_runtime_audit.py`:

```python
"""Containerd 运行时容器审计（Phase 7f.1）。

nerdctl 优先 / ctr 回退分派；docker 接管 containerd 时 not_applicable
让位 docker_runtime_audit。复用 _docker_common._evaluate_inspect（nerdctl
模式）或自实现 ctr 模式 4/7 部分覆盖判定。
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import (
    _evaluate_inspect,
    _parse_ctr_info,
    detect_containerd_runtime,
    detect_docker,
)
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"
_DOCKER_SOCKET = "/var/run/docker.sock"
_MAX_CONTAINERS = 200
_MAX_SKIPPED_IDS = 20

_CTR_UNCOVERED_RULES = [
    "runtime-host-fs-mount",
    "runtime-sock-mount",
    "runtime-no-new-priv-missing",
]


def _docker_socket_active(ctx: CheckContext) -> bool:
    result = ctx.executor.run(["stat", "-c", "%n", _DOCKER_SOCKET])
    return not result.rejected and result.exit_code == 0


class ContainerdRuntimeAuditCheck(Check):
    id = "containerd_runtime_audit"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._runtime_rules = baseline["runtime"]
        self._rules_by_id = {r["id"]: r for r in self._runtime_rules}

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        # Docker takeover yield
        if detect_docker(ctx) is not None and _docker_socket_active(ctx):
            ctx.status.not_applicable(
                f"{self.id}：检出 docker 后端为 containerd，由 docker_runtime_audit 评估"
            )
            return []
        bin_path, mode = detect_containerd_runtime(ctx)
        if mode is None:
            ctx.status.not_applicable(
                f"{self.id}：containerd 不可见（nerdctl / ctr 均未装或 socket 缺失）"
            )
            return []
        if mode == "nerdctl":
            return self._run_nerdctl(ctx)
        else:
            return self._run_ctr(ctx)

    def _run_nerdctl(self, ctx: CheckContext) -> list[Finding]:
        ps_result = ctx.executor.run(
            ["nerdctl", "ps", "--format", "{{json .}}", "--no-trunc"]
        )
        if ps_result.rejected or ps_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：nerdctl ps 退出码 {ps_result.exit_code}"
            )
            return []
        container_ids: list[str] = []
        for line in ps_result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                cid = obj.get("ID") or obj.get("Id")
                if cid:
                    container_ids.append(cid)
            except json.JSONDecodeError:
                continue
        findings: list[Finding] = []
        skipped_ids: list[str] = []
        for cid in container_ids[:_MAX_CONTAINERS]:
            ir = ctx.executor.run(["nerdctl", "inspect", cid])
            if ir.rejected or ir.exit_code != 0:
                skipped_ids.append(cid)
                continue
            try:
                inspect_json = json.loads(ir.stdout)
            except json.JSONDecodeError:
                skipped_ids.append(cid)
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_inspect(
                    inspect_json, runtime="containerd", rootless=False,
                    baseline_runtime_rules=self._runtime_rules,
                )
            )
        if skipped_ids:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"{self.id}：{len(skipped_ids)} 个容器的 inspect 失败",
                description="部分容器扫描失败；finding 列表仅含成功扫描部分。",
                evidence={"skipped_container_ids": skipped_ids[:_MAX_SKIPPED_IDS],
                          "mode": "nerdctl",
                          "truncated": len(skipped_ids) > _MAX_SKIPPED_IDS},
                remediation="检查 containerd 状态或运行用户权限。",
                threat_refs=[],
            ))
        return findings

    def _run_ctr(self, ctx: CheckContext) -> list[Finding]:
        list_result = ctx.executor.run(
            ["ctr", "--namespace", "default", "containers", "list", "-q"]
        )
        if list_result.rejected or list_result.exit_code != 0:
            ctx.status.skipped(
                f"{self.id}：ctr containers list 退出码 {list_result.exit_code}"
            )
            return []
        container_ids = [
            line.strip() for line in list_result.stdout.splitlines() if line.strip()
        ]
        findings: list[Finding] = []
        skipped_ids: list[str] = []

        for cid in container_ids[:_MAX_CONTAINERS]:
            info_result = ctx.executor.run(
                ["ctr", "--namespace", "default", "containers", "info", cid]
            )
            if info_result.rejected or info_result.exit_code != 0:
                skipped_ids.append(cid)
                continue
            try:
                parsed = _parse_ctr_info(info_result.stdout)
            except ValueError:
                skipped_ids.append(cid)
                continue
            findings.extend(self._ctr_findings(ctx, cid, parsed))

        # Always emit partial-coverage info finding in ctr mode (even with 0 containers)
        findings.append(self.make_finding(
            ctx, severity="info",
            title=f"{self.id}：ctr 模式部分覆盖",
            description=(
                "未检出 nerdctl，回退到 ctr containers info 解析。"
                "host-fs-mount / sock-mount / no-new-privileges 三条规则"
                "在该模式下不可达，已跳过；其余 4 条（privileged / host-net "
                "/ cap-dangerous / root-user）正常评估。"
            ),
            evidence={
                "mode": "ctr",
                "uncovered_rules": _CTR_UNCOVERED_RULES,
            },
            remediation="安装 nerdctl 提升保真度：dnf install nerdctl",
            threat_refs=["TI-CONTAINERD-COVERAGE-PARTIAL"],
        ))

        if skipped_ids:
            findings.append(self.make_finding(
                ctx, severity="info",
                title=f"{self.id}：{len(skipped_ids)} 个容器的 ctr info 失败",
                description="部分容器扫描失败；finding 列表仅含成功扫描部分。",
                evidence={"skipped_container_ids": skipped_ids[:_MAX_SKIPPED_IDS],
                          "mode": "ctr",
                          "truncated": len(skipped_ids) > _MAX_SKIPPED_IDS},
                remediation="检查 containerd 状态或运行用户权限。",
                threat_refs=[],
            ))
        return findings

    def _ctr_findings(
        self, ctx: CheckContext, cid: str, parsed: dict,
    ) -> list[Finding]:
        out: list[Finding] = []
        ev_base = {"runtime": "containerd", "container_id": cid[:12],
                   "coverage": "partial", "mode": "ctr"}

        def emit(rule_id: str, extra: dict):
            rule = self._rules_by_id[rule_id]
            template = rule.get("threat_refs_template", "")
            refs = ([template.format(prefix="TI-CONTAINERD")] if template
                    else list(rule.get("threat_refs", [])))
            out.append(self.make_finding(
                ctx, severity=rule["severity"],
                title=rule["title"], description=rule["description"],
                evidence={**ev_base, "rule_id": rule_id, **extra},
                remediation=rule["remediation"],
                threat_refs=refs,
            ))

        if parsed["privileged"]:
            emit("runtime-privileged", {"privileged": True})
        if parsed["host_network"]:
            emit("runtime-host-net", {"network_mode": "host"})
        if parsed["root_user_uid"] == 0:
            emit("runtime-root-user", {"user": "root"})
        dangerous = {"CAP_SYS_ADMIN", "CAP_NET_ADMIN", "CAP_SYS_PTRACE"}
        for cap in parsed["capabilities"]:
            if cap in dangerous:
                emit("runtime-cap-dangerous", {"cap": cap.replace("CAP_", "")})
        return out
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_containerd_runtime_audit.py -v`

Expected: 10 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/checks/containerd_runtime_audit.py tests/test_containerd_runtime_audit.py
git commit -m "feat(7f.1): ContainerdRuntimeAuditCheck (nerdctl + ctr modes + docker yield)

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 12: ContainerdImageCveCheck

**Files:**
- Create: `src/agentsec/audit/checks/containerd_image_cve.py`
- Create: `tests/test_containerd_image_cve.py`

- [ ] **Step 1: Write failing tests**

Create `tests/test_containerd_image_cve.py`:

```python
"""ContainerdImageCveCheck 单元测试（Phase 7f.1）。"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agentsec.audit.checks.base import CheckContext
from agentsec.audit.checks.containerd_image_cve import ContainerdImageCveCheck
from agentsec.audit.platform_profile import LINUX, materialize_paths
from agentsec.audit.redactor import Redactor
from agentsec.audit.types import RunResult

_FIXTURES = Path(__file__).parent / "fixtures" / "container"
_NERDCTL_BIN = "/usr/local/bin/nerdctl"
_CTR_BIN = "/usr/bin/ctr"
_SOCKET = "/run/containerd/containerd.sock"
_DOCKER_BIN = "/usr/bin/docker"
_DOCKER_SOCKET = "/var/run/docker.sock"


def _runresult(stdout="", stderr="", exit_code=0, rejected=False):
    return RunResult(stdout=stdout, stderr=stderr, exit_code=exit_code,
                     rejected=rejected, reject_reason="policy" if rejected else None,
                     argv=[], command_sha256="0"*64, duration_ms=0.0,
                     bytes_out=len(stdout.encode()))


class _RecordingExecutor:
    def __init__(self, responses):
        self._responses = responses
        self.calls = []
    def run(self, argv, *, role=None):
        self.calls.append(list(argv))
        return self._responses.get(
            tuple(argv),
            RunResult(stdout="", stderr="", exit_code=1, rejected=False,
                      reject_reason=None, argv=list(argv),
                      command_sha256="0"*64, duration_ms=0.0, bytes_out=0),
        )


def _ctx(executor, profile_name="linux"):
    profile = materialize_paths(LINUX, "/home/u")
    if profile_name != "linux":
        profile = profile.model_copy(update={"name": profile_name})
    return CheckContext(executor=executor, redactor=Redactor(),
                        ioc_dir=Path("/tmp"), profile=profile,
                        log_review_config=None)


def _run(check, ctx):
    return asyncio.run(check.run(ctx))


def _stat_responses(present):
    all_paths = [
        "/usr/bin/docker", "/usr/local/bin/docker", "/opt/homebrew/bin/docker",
        "/usr/local/bin/nerdctl", "/usr/bin/nerdctl",
        "/usr/bin/ctr", "/usr/local/bin/ctr",
        "/run/containerd/containerd.sock",
        "/var/run/docker.sock",
    ]
    out = {}
    for p in all_paths:
        if p in present:
            out[("stat", "-c", "%n", p)] = _runresult(stdout=p+"\n")
        else:
            out[("stat", "-c", "%n", p)] = _runresult(stderr="No such file", exit_code=1)
    return out


def test_not_applicable_macos():
    ctx = _ctx(_RecordingExecutor({}), profile_name="macos")
    findings = _run(ContainerdImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_docker_takeover_yield():
    responses = _stat_responses(present=(
        _DOCKER_BIN, _DOCKER_SOCKET, _NERDCTL_BIN, _SOCKET,
    ))
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_not_applicable


def test_nerdctl_mode_images():
    images = (_FIXTURES / "containerd_nerdctl_images.json").read_text()
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[("nerdctl", "images", "--format", "{{json .}}")] = _runresult(stdout=images)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    # redis:7 → 0, node:14 → 1 (node:1[0-4]* EOL), alpine:3.18 → 0
    assert len(findings) == 1
    assert findings[0].evidence["runtime"] == "containerd"


def test_ctr_mode_images():
    refs = (_FIXTURES / "containerd_ctr_images_list_q.txt").read_text()
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[("ctr", "--namespace", "default", "images", "list", "-q")] = _runresult(stdout=refs)
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    # docker.io/library/node:14 → 1 finding
    assert len(findings) == 1


def test_ctr_mode_unparseable_ref():
    """An image ref without ':' is silently skipped."""
    responses = _stat_responses(present=(_CTR_BIN, _SOCKET))
    responses[("ctr", "--namespace", "default", "images", "list", "-q")] = _runresult(
        stdout="docker.io/library/node\nbad-ref-no-colon\ndocker.io/library/node:14\n"
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    # Only node:14 matches; bad refs silently skipped
    assert len(findings) == 1


def test_images_failure_skipped():
    responses = _stat_responses(present=(_NERDCTL_BIN, _SOCKET))
    responses[("nerdctl", "images", "--format", "{{json .}}")] = _runresult(
        stderr="Permission denied", exit_code=126,
    )
    ctx = _ctx(_RecordingExecutor(responses))
    findings = _run(ContainerdImageCveCheck(), ctx)
    assert findings == []
    assert ctx.status.is_skipped
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/test_containerd_image_cve.py -v`

Expected: 6 FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Create the Check**

Create `src/agentsec/audit/checks/containerd_image_cve.py`:

```python
"""Containerd 镜像 CVE 审计（Phase 7f.1）。

nerdctl 优先 / ctr 回退；docker 接管 containerd 时让位 docker_image_cve。
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from ..findings import Finding
from ._docker_common import (
    _evaluate_image_tag,
    detect_containerd_runtime,
    detect_docker,
)
from .base import Check, CheckContext

_BASELINE_PATH = Path(__file__).parent / "container_baseline.yaml"
_DOCKER_SOCKET = "/var/run/docker.sock"

_PERM_DENIED_SUBSTRINGS = ("permission denied", "operation not permitted")


def _looks_perm_denied(stderr: str) -> bool:
    s = stderr.lower()
    return any(needle in s for needle in _PERM_DENIED_SUBSTRINGS)


def _docker_socket_active(ctx: CheckContext) -> bool:
    result = ctx.executor.run(["stat", "-c", "%n", _DOCKER_SOCKET])
    return not result.rejected and result.exit_code == 0


class ContainerdImageCveCheck(Check):
    id = "containerd_image_cve"

    def __init__(self):
        super().__init__()
        baseline = yaml.safe_load(_BASELINE_PATH.read_text())
        self._patterns = baseline["image_patterns"]

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(
                f"{self.id}：当前 profile {ctx.profile.name!r} 不是 Linux"
            )
            return []
        if detect_docker(ctx) is not None and _docker_socket_active(ctx):
            ctx.status.not_applicable(
                f"{self.id}：检出 docker 后端为 containerd，由 docker_image_cve 评估"
            )
            return []
        bin_path, mode = detect_containerd_runtime(ctx)
        if mode is None:
            ctx.status.not_applicable(
                f"{self.id}：containerd 不可见"
            )
            return []
        if mode == "nerdctl":
            return self._run_nerdctl(ctx)
        else:
            return self._run_ctr(ctx)

    def _run_nerdctl(self, ctx: CheckContext) -> list[Finding]:
        result = ctx.executor.run(
            ["nerdctl", "images", "--format", "{{json .}}"]
        )
        if result.rejected or result.exit_code != 0:
            if _looks_perm_denied(result.stderr):
                ctx.status.skipped(f"{self.id}：权限不足")
            else:
                ctx.status.skipped(
                    f"{self.id}：nerdctl images 退出码 {result.exit_code}"
                )
            return []
        try:
            images = json.loads(result.stdout) if result.stdout.strip() else []
        except json.JSONDecodeError:
            ctx.status.skipped(f"{self.id}：nerdctl images 输出非 JSON")
            return []
        findings: list[Finding] = []
        for img in images:
            repo = img.get("Repository") or ""
            tag = img.get("Tag") or ""
            if not repo or not tag:
                continue
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_image_tag(
                    repo, tag, runtime="containerd",
                    baseline_image_patterns=self._patterns,
                )
            )
        return findings

    def _run_ctr(self, ctx: CheckContext) -> list[Finding]:
        result = ctx.executor.run(
            ["ctr", "--namespace", "default", "images", "list", "-q"]
        )
        if result.rejected or result.exit_code != 0:
            if _looks_perm_denied(result.stderr):
                ctx.status.skipped(f"{self.id}：权限不足")
            else:
                ctx.status.skipped(
                    f"{self.id}：ctr images list 退出码 {result.exit_code}"
                )
            return []
        findings: list[Finding] = []
        for line in result.stdout.splitlines():
            ref = line.strip()
            if not ref or ":" not in ref:
                continue
            # Split into repo:tag from the rightmost colon
            repo, tag = ref.rsplit(":", 1)
            findings.extend(
                self.make_finding(ctx, **kw)
                for kw in _evaluate_image_tag(
                    repo, tag, runtime="containerd",
                    baseline_image_patterns=self._patterns,
                )
            )
        return findings
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/test_containerd_image_cve.py -v`

Expected: 6 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/agentsec/audit/checks/containerd_image_cve.py tests/test_containerd_image_cve.py
git commit -m "feat(7f.1): ContainerdImageCveCheck (nerdctl + ctr modes)

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 13: ssh_policy.yaml extension + policy validation tests

**Files:**
- Modify: `src/agentsec/audit/ssh_policy.yaml`
- Modify: `tests/audit/test_command_policy.py`

- [ ] **Step 1: Write failing policy tests**

Append to `tests/audit/test_command_policy.py`:

```python
def test_podman_version_allowed(policy):
    p = policy
    result = p.validate(["podman", "version", "--format", "{{json .}}"])
    assert result.ok, f"unexpected reject: {result.reason}"


def test_podman_info_allowed(policy):
    p = policy
    result = p.validate(["podman", "info", "--format", "{{json .}}"])
    assert result.ok


def test_podman_ps_allowed(policy):
    p = policy
    result = p.validate(["podman", "ps", "--format", "{{json .}}", "--no-trunc"])
    assert result.ok


def test_podman_images_allowed(policy):
    p = policy
    result = p.validate(["podman", "images", "--format", "{{json .}}"])
    assert result.ok


def test_podman_exec_rejected(policy):
    p = policy
    result = p.validate(["podman", "exec", "abc", "sh"])
    assert not result.ok


def test_podman_build_rejected(policy):
    p = policy
    result = p.validate(["podman", "build", "."])
    assert not result.ok


def test_nerdctl_ps_allowed(policy):
    p = policy
    result = p.validate(["nerdctl", "ps", "--format", "{{json .}}", "--no-trunc"])
    assert result.ok


def test_nerdctl_inspect_allowed(policy):
    p = policy
    result = p.validate(["nerdctl", "inspect", "abc1234567890"])
    assert result.ok


def test_nerdctl_images_allowed(policy):
    p = policy
    result = p.validate(["nerdctl", "images", "--format", "{{json .}}"])
    assert result.ok


def test_nerdctl_pull_rejected(policy):
    p = policy
    result = p.validate(["nerdctl", "pull", "nginx:latest"])
    assert not result.ok


def test_ctr_containers_list_allowed(policy):
    p = policy
    result = p.validate(["ctr", "--namespace", "default", "containers", "list", "-q"])
    assert result.ok


def test_ctr_containers_info_allowed(policy):
    p = policy
    result = p.validate(["ctr", "--namespace", "default", "containers", "info", "abc1234567890"])
    assert result.ok


def test_ctr_images_list_allowed(policy):
    p = policy
    result = p.validate(["ctr", "--namespace", "default", "images", "list", "-q"])
    assert result.ok


def test_ctr_containers_start_rejected(policy):
    p = policy
    result = p.validate(["ctr", "--namespace", "default", "containers", "start", "abc"])
    assert not result.ok


def test_cat_containers_conf_allowed(policy):
    p = policy
    result = p.validate(["cat", "/etc/containers/containers.conf"])
    assert result.ok
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `.venv/bin/pytest tests/audit/test_command_policy.py -k "podman or nerdctl or ctr or containers_conf" -v 2>&1 | tail -10`

Expected: 12-15 FAIL with "unknown command" or path-not-allowed.

- [ ] **Step 3: Add `allowed_paths` entries**

Edit `src/agentsec/audit/ssh_policy.yaml`. Find the existing docker bin block (around line 25–27, the 3 docker paths). After the docker block, before the `# firewall bin-resolver candidates` block, insert:

```yaml
  # podman bin-resolver candidates (Phase 7f.1) — stat-probe only
  - {kind: exact, path: "/usr/bin/podman"}
  - {kind: exact, path: "/usr/local/bin/podman"}
  - {kind: exact, path: "/opt/homebrew/bin/podman"}
  # containerd front-end bin-resolver candidates (Phase 7f.1)
  - {kind: exact, path: "/usr/local/bin/nerdctl"}
  - {kind: exact, path: "/usr/bin/nerdctl"}
  - {kind: exact, path: "/usr/bin/ctr"}
  - {kind: exact, path: "/usr/local/bin/ctr"}
  # containers.conf paths (Phase 7f.1) — read via existing `cat` command
  - {kind: exact, path: "/etc/containers/containers.conf"}
  - {kind: exact, path: "/usr/share/containers/containers.conf"}
  # containerd socket probe (Phase 7f.1)
  - {kind: exact, path: "/run/containerd/containerd.sock"}
```

- [ ] **Step 4: Add `commands.podman` / `commands.nerdctl` / `commands.ctr` sections**

Edit `src/agentsec/audit/ssh_policy.yaml`. Find the existing `docker:` commands block. Insert AFTER `docker:` block (i.e., before the `iptables:` block):

```yaml
  podman:
    # Phase 7f.1 — read-only introspection. Write subcommands (run / start /
    # stop / kill / rm / exec / build / pull / push / tag / save / commit /
    # cp / logs / attach) are NOT in any allowed_argv tuple and unreachable
    # by construction.
    allowed_argv:
      - ["podman", "version", "--format", "{{json .}}"]
      - ["podman", "info",    "--format", "{{json .}}"]
      - ["podman", "ps",      "--format", "{{json .}}", "--no-trunc"]
      - ["podman", "images",  "--format", "{{json .}}"]
    args_schema:
      - role: subcommand
        allowed: ["inspect"]
      - role: positional
        kind: container_id
        required: true

  nerdctl:
    # Phase 7f.1 — containerd compat front-end. Write subcommands
    # (run / pull / push / build / tag / rm / save / load / exec / commit)
    # are NOT in any allowed_argv tuple.
    allowed_argv:
      - ["nerdctl", "ps",     "--format", "{{json .}}", "--no-trunc"]
      - ["nerdctl", "images", "--format", "{{json .}}"]
    args_schema:
      - role: subcommand
        allowed: ["inspect"]
      - role: positional
        kind: container_id
        required: true

  ctr:
    # Phase 7f.1 — containerd admin CLI fallback. --namespace default required.
    # Write subcommands (start / stop / kill / delete / pull / push / pause /
    # resume / tasks) are NOT in any allowed_argv tuple.
    allowed_argv:
      - ["ctr", "--namespace", "default", "containers", "list", "-q"]
      - ["ctr", "--namespace", "default", "images", "list", "-q"]
    args_schema:
      - role: subcommand_chain
        allowed: [["--namespace", "default", "containers", "info"]]
      - role: positional
        kind: container_id
        required: true
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `.venv/bin/pytest tests/audit/test_command_policy.py -k "podman or nerdctl or ctr or containers_conf" -v`

Expected: 15 PASS.

If any test fails (likely the `ctr containers info` subcommand_chain validation), the `args_schema.subcommand_chain` type may need to use a different role name. Check `src/agentsec/audit/args_schema.py` for supported role names; if `subcommand_chain` doesn't exist, the closest equivalent is a static `allowed_argv` tuple with the container_id appended — switch the ctr info form to:

```yaml
allowed_argv:
  - ["ctr", "--namespace", "default", "containers", "info", "{{container_id}}"]
```

and use placeholder substitution if that's the project pattern. (Inspect `args_schema.py` to confirm.)

- [ ] **Step 6: Run YAML loadable test**

Run: `.venv/bin/pytest tests/audit/test_policy_yaml_loadable.py -v`

Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/agentsec/audit/ssh_policy.yaml tests/audit/test_command_policy.py
git commit -m "feat(7f.1): ssh_policy — podman/nerdctl/ctr read-only argv + containers.conf paths

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 14: Register 5 Checks in cli.py + fixture stubs + sample report refresh

**Files:**
- Modify: `src/agentsec/cli.py`
- Modify: `tests/audit/test_cli_server_audit.py`
- Modify: `tests/integration/test_openclaw_mock.py`
- Modify: `docs/samples/report-2026-04-28/server-audit-report.md`

- [ ] **Step 1: Add 5 imports in cli.py**

Edit `src/agentsec/cli.py`. The existing imports are alphabetical. Insert these 5 imports alphabetically:

```python
from .audit.checks.containerd_image_cve import ContainerdImageCveCheck
from .audit.checks.containerd_runtime_audit import ContainerdRuntimeAuditCheck
from .audit.checks.podman_daemon_audit import PodmanDaemonAuditCheck
from .audit.checks.podman_image_cve import PodmanImageCveCheck
from .audit.checks.podman_runtime_audit import PodmanRuntimeAuditCheck
```

Place: `containerd_image_cve` and `containerd_runtime_audit` go alphabetically right after `docker_runtime_audit`. `podman_*` go between `pip_supply_chain_audit` and `process_forensics`.

- [ ] **Step 2: Register in both Check-list sites**

Find the two Check registration sites (around lines 612-614 and 942-944 from prior commits — recheck the actual line numbers post-T13). Both currently end:

```python
        ...
        FirewalldAuditCheck(),
        DockerDaemonAuditCheck(),
        DockerRuntimeAuditCheck(),
        DockerImageCveCheck(),
        SupplyChainAuditCheck(),
        ...
```

After `DockerImageCveCheck()` and before `SupplyChainAuditCheck()`, insert at BOTH sites:

```python
        PodmanDaemonAuditCheck(),
        PodmanRuntimeAuditCheck(),
        PodmanImageCveCheck(),
        ContainerdRuntimeAuditCheck(),
        ContainerdImageCveCheck(),
```

- [ ] **Step 3: Add absence stubs to integration test mocks**

In `tests/integration/test_openclaw_mock.py`, find the `_stub_ssh` function (or equivalent — the function that returns `(exit_code, stdout)` for arbitrary argv tuples). Add absence handling for the 7 new bin paths:

```python
# Phase 7f.1 — podman/nerdctl/ctr/socket absence stubs
if argv == ["stat", "-c", "%n", "/usr/bin/podman"]: return (1, "")
if argv == ["stat", "-c", "%n", "/usr/local/bin/podman"]: return (1, "")
if argv == ["stat", "-c", "%n", "/opt/homebrew/bin/podman"]: return (1, "")
if argv == ["stat", "-c", "%n", "/usr/local/bin/nerdctl"]: return (1, "")
if argv == ["stat", "-c", "%n", "/usr/bin/nerdctl"]: return (1, "")
if argv == ["stat", "-c", "%n", "/usr/bin/ctr"]: return (1, "")
if argv == ["stat", "-c", "%n", "/usr/local/bin/ctr"]: return (1, "")
if argv == ["stat", "-c", "%n", "/run/containerd/containerd.sock"]: return (1, "")
```

Place these alongside the existing docker/firewalld absence stubs in the same function. Mirror whatever style the existing stubs use (or-chain vs if-elif vs dict lookup — match existing).

Do the same in `tests/audit/test_cli_server_audit.py` if it has a parallel stub function.

- [ ] **Step 4: Refresh sample report**

Run:
```bash
AGENTSEC_REFRESH_SAMPLE=1 .venv/bin/pytest tests/integration/test_openclaw_mock.py::test_openclaw_mock_end_to_end -v
```

This regenerates `docs/samples/report-2026-04-28/server-audit-report.md` to include the 5 new `not_applicable` rows + bump check count 29 → 34.

Verify:
```bash
grep -E "podman_|containerd_" docs/samples/report-2026-04-28/server-audit-report.md | head -10
```

Expected: 5 `not_applicable` rows in the report.

- [ ] **Step 5: Smoke-test CLI imports**

Run: `.venv/bin/python -c "from agentsec.cli import server_audit; print('ok')"`

Expected: `ok`.

- [ ] **Step 6: Run full pytest**

Run: `.venv/bin/pytest tests/ -q 2>&1 | tail -3`

Expected: all PASS, count ~1484 (1413 baseline + 71 new from T2-T13).

- [ ] **Step 7: ruff check**

Run: `.venv/bin/ruff check src/`

Expected: clean.

- [ ] **Step 8: Commit**

```bash
git add src/agentsec/cli.py \
        tests/audit/test_cli_server_audit.py \
        tests/integration/test_openclaw_mock.py \
        docs/samples/report-2026-04-28/server-audit-report.md
git commit -m "feat(7f.1): register 5 new container Checks + refresh sample report

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

---

## Task 15: Full pytest + ruff + sanity (verification only, no commit)

- [ ] **Step 1: Run the full test suite**

Run: `.venv/bin/pytest tests/ -q 2>&1 | tail -5`

Expected: ~1484 PASS, no failures.

- [ ] **Step 2: Run ruff on entire src/**

Run: `.venv/bin/ruff check src/`

Expected: `All checks passed!`

- [ ] **Step 3: Run threat-ref + OSV CI guards**

Run:
```bash
.venv/bin/python scripts/check_threat_refs.py 2>&1 | tail -3
.venv/bin/python scripts/check_osv_npm.py --check 2>&1 | tail -3
.venv/bin/python scripts/check_osv_pypi.py 2>&1 | tail -3
.venv/bin/python scripts/check_osv_go.py 2>&1 | tail -3
.venv/bin/python scripts/check_osv_cargo.py 2>&1 | tail -3
```

Expected: all OK.

- [ ] **Step 4: Smoke test the CLI**

Run: `.venv/bin/agentsec --help 2>&1 | head -15`

Expected: help text prints; commands listed.

- [ ] **Step 5: No commit (verification step)**

If anything failed in steps 1-4, fix the underlying issue and re-run before proceeding to T16.

---

## Task 16: ADR-0018 + v0.18.0 release notes

**Files:**
- Create: `docs/adr/0018-phase-7f1-podman-containerd-audit.md`
- Modify: `pyproject.toml`
- Modify: `CHANGELOG.md`
- Modify: `ROADMAP.md`
- Modify: `README.md`
- Modify: `CLAUDE.md`

- [ ] **Step 1: Write the ADR**

Create `docs/adr/0018-phase-7f1-podman-containerd-audit.md`:

```markdown
# ADR-0018: Phase 7f.1 Podman + Containerd Audit

**Status:** Accepted
**Date:** 2026-05-12
**Predecessors:** ADR-0017 (Phase 7e.3 firewalld); 7f Docker landed without
a standalone ADR (decisions in 7f spec).

## Context

`agentsec server-audit` Phase 7f (v0.10.0) shipped 3 Docker Check
classes — `docker_daemon_audit` / `docker_runtime_audit` /
`docker_image_cve` — covering Docker hosts on Ubuntu / Debian / RHEL.

But two big runtime ecosystems were uncovered:
1. **Podman**: RHEL / CentOS Stream / Fedora default; daemonless;
   incompatible config (`containers.conf` vs `daemon.json`).
2. **Containerd**: K8s standard backend; also the actual runtime under
   Docker. Standalone containerd hosts (non-Docker non-K8s) sit blind.

## Decision

Add 5 new Check classes:
- `PodmanDaemonAuditCheck` / `PodmanRuntimeAuditCheck` / `PodmanImageCveCheck`
- `ContainerdRuntimeAuditCheck` / `ContainerdImageCveCheck`
- **Skip** `containerd_daemon_audit` — config.toml has few security knobs
  (option B in spec); deferred to 7f.1.1 follow-up.

Key sub-decisions:

1. **containerd CLI strategy**: nerdctl optional; ctr fallback. nerdctl
   gives docker-CLI-compatible JSON; ctr gives JSON-shaped admin text
   with partial fidelity (4/7 runtime rules reachable).
2. **Cross-talk yield**: `ContainerdRuntimeAuditCheck` and
   `ContainerdImageCveCheck` go `not_applicable` if `detect_docker(ctx)`
   succeeds AND `/var/run/docker.sock` exists. This prevents double-
   reporting on docker-on-containerd hosts.
3. **Rootless severity downgrade**: `runtime-root-user` finding emitted
   from podman_runtime_audit is medium → low when `podman.info` shows
   `host.security.rootless == true`.
4. **Shared helpers (Option α)**: `_evaluate_inspect` / `_evaluate_image_tag`
   / `_parse_ctr_info` in `_docker_common.py` return `list[dict]` of
   Finding kwargs. New Checks compose via `self.make_finding(**kw)`
   (Redactor pass automatic). 7f Docker Checks unchanged — they keep
   direct `Finding(...)` construction; migration to make_finding deferred.
5. **TI naming**: daemon + runtime TIs split per-runtime
   (TI-DOCKER-* / TI-PODMAN-* / TI-CONTAINERD-*). image_patterns TIs
   shared (TI-DOCKER-IMAGE-*) because image content is runtime-agnostic.

## Consequences

- 5 new Checks, ~71 new tests; total Check count 29 → 34.
- Coverage: RHEL/Fedora default container runtime closed; standalone
  containerd hosts have meaningful runtime + image audit (with the
  partial-coverage warning in ctr mode).
- ssh_policy.yaml gains 10 allowed_paths + 3 commands sections.
- containerd in K8s context still routed via 7g (Kubernetes) phase.
- Containerd daemon config audit (config.toml) — deferred to 7f.1.1 or
  on-demand.

## Alternatives Considered

- **Option B (full 6 Checks including containerd_daemon)**: rejected
  because config.toml security knobs are sparse (3-4 rules); not worth
  the complexity.
- **Option C (refactor existing Docker Checks to multi-runtime polymorphism)**:
  rejected — touches working 7f code, breaks docker test surface.
- **Only nerdctl, no ctr fallback**: rejected — RHEL/Fedora containerd
  hosts often lack nerdctl (docker.io repo download); the partial-coverage
  ctr mode is the difference between zero coverage and 4/7 rule coverage.
- **TI共享一套（rename TI-DOCKER-* → TI-CONTAINER-*）**: rejected — touches
  7f Docker findings backward compat; per-runtime TIs let report
  consumers folded by runtime.

Spec: `docs/superpowers/specs/2026-05-12-phase-7f1-podman-containerd-design.md`
```

- [ ] **Step 2: Bump version**

Edit `pyproject.toml`. Find `version = "0.17.0"` and replace with `version = "0.18.0"`.

- [ ] **Step 3: CHANGELOG entry**

Edit `CHANGELOG.md`. Insert a new section above the v0.17.0 entry:

```markdown
## v0.18.0 — 2026-05-12

### Phase 7f.1 — Podman + Containerd audit

- 5 new server-audit Check classes: `podman_daemon_audit`,
  `podman_runtime_audit`, `podman_image_cve`, `containerd_runtime_audit`,
  `containerd_image_cve`.
- Podman scope: rootful mode / userns / no_new_privileges / version CVE
  via `containers.conf` + `podman info`; reuses 7f Docker runtime + image
  baselines.
- Containerd scope: nerdctl-first / ctr-fallback dispatch; docker-takeover
  yield prevents double-reporting on docker-backed-by-containerd hosts;
  rootless severity downgrade for podman; ctr-mode partial coverage
  signaled by `TI-CONTAINERD-COVERAGE-PARTIAL` info finding.
- Shared helpers in `_docker_common.py`: `_evaluate_inspect`,
  `_evaluate_image_tag`, `_parse_ctr_info` — new Checks compose via
  `make_finding(**kw)` for automatic Redactor pass.
- `ssh_policy.yaml`: +10 allowed_paths exact (7 binaries + 2 conf + 1 socket),
  +3 commands sections (podman / nerdctl / ctr); all write subcommands
  unreachable by construction.
- `threat_intel.yaml`: +19 TI rows (4 podman daemon + 7 podman runtime +
  7 containerd runtime + 1 partial-coverage).
- ADR-0018.
- Total Checks: 29 → 34. Total tests: ~1413 → ~1484.
```

- [ ] **Step 4: ROADMAP update**

Edit `ROADMAP.md`. Find the `- [ ] Phase 7f.1` entry (if present) under Phase 7. Change to:

```
- [x] Phase 7f.1 — Podman + Containerd audit (5 new Checks; nerdctl-first/ctr-fallback; docker-takeover yield) — 2026-05-12
- [ ] Phase 7f.1.1 — Containerd daemon audit (`config.toml` baseline; deferred from 7f.1)
```

- [ ] **Step 5: README Check count**

Edit `README.md`. Find references to "29 Checks" / "29 类" / equivalent and bump to **34 Checks** / **34 类**. Update the container audit section (around "3 Docker") to say "**3 Docker + 3 Podman + 2 Containerd = 8 container Checks**".

Use `grep -n "29" README.md` to locate; bump each occurrence consistently.

- [ ] **Step 6: CLAUDE.md update**

Edit `/Users/roger/Work/AgentSec/CLAUDE.md`:

a. Find the "Total checks" line under "Stage E additions". Change:
```
**Total checks (v0.17.0):** ... `firewalld_audit` (Phase 7e.3) — 29 类。
```
to:
```
**Total checks (v0.18.0):** ... `firewalld_audit` (Phase 7e.3); `podman_daemon_audit`, `podman_runtime_audit`, `podman_image_cve` (Phase 7f.1); `containerd_runtime_audit`, `containerd_image_cve` (Phase 7f.1) — 34 类。
```

b. Add a new section after the existing "## firewalld audit (Phase 7e.3, v0.17.0)" section:

```markdown
## Podman + Containerd audit (Phase 7f.1, v0.18.0)

- **`detect_podman` / `detect_nerdctl` / `detect_ctr` / `detect_containerd_runtime`** in `src/agentsec/audit/checks/_docker_common.py` follow the `_stat_probe(ctx, candidates)` pattern (extracted in 7f.1 from the existing detect_docker for-loop). `detect_containerd_runtime` returns `(bin_path, mode)` where mode ∈ {"nerdctl", "ctr", None}; nerdctl preferred, ctr fallback. Both require `/run/containerd/containerd.sock` to exist (avoids false-positive on dev hosts with nerdctl but no containerd running).
- **PodmanDaemonAuditCheck** reads `containers.conf` via `tomllib` + `podman version/info` JSON; 4 rules in `container_baseline.yaml:daemon_podman`. PodmanRuntimeAuditCheck calls `_evaluate_inspect(json, runtime="podman", rootless=...)` reusing 7f runtime baseline; `runtime-root-user` severity downgraded (medium → low) when `host.security.rootless==true`. PodmanImageCveCheck calls `_evaluate_image_tag(repo, tag, runtime="podman", ...)` reusing 7f image_patterns.
- **Cross-talk yield** — `ContainerdRuntimeAuditCheck` and `ContainerdImageCveCheck` check `detect_docker(ctx) is not None and /var/run/docker.sock exists` → go `not_applicable` ("由 docker_runtime_audit/image_cve 评估"). Prevents double-reporting on Docker-backed-by-containerd hosts (the common case).
- **ctr-mode partial coverage** — `containerd_runtime_audit` in ctr fallback emits an info-severity finding tagged `TI-CONTAINERD-COVERAGE-PARTIAL` listing uncovered rules (host-fs-mount / sock-mount / no-new-priv require OCI runtime spec under `/run/containerd/io.containerd.runtime.v2.task/`, deferred). Each rule finding evidence gains `coverage: "partial", mode: "ctr"`.
- **Shared helpers (Option α dict-return)** in `_docker_common.py`: `_evaluate_inspect` and `_evaluate_image_tag` return `list[dict]` of Finding kwargs (Severity / title / desc / evidence / remediation / threat_refs). Caller wraps via `self.make_finding(ctx, **kw)` — Redactor pass automatic. 7f Docker Checks unchanged; migration to make_finding deferred.
- **TI naming** — daemon + runtime TIs split per-runtime (TI-DOCKER-* / TI-PODMAN-* / TI-CONTAINERD-*). image_patterns TIs shared (TI-DOCKER-IMAGE-*) because image content is runtime-agnostic. The `threat_refs_template` field on baseline rules (e.g., `"{prefix}-RUNTIME-PRIVILEGED"`) is rendered per-runtime by `_evaluate_inspect`.
- **Adding a 4th container runtime** (e.g., cri-o): add `_CRIO_BIN_CANDIDATES` + `detect_crio` in `_docker_common.py`; new Check classes call `_evaluate_inspect(json, runtime="crio", ...)`; add `TI-CRIO-RUNTIME-*` block + `daemon_crio:` section in `container_baseline.yaml`. ssh_policy gains a `crio:` commands section + bin paths.
```

- [ ] **Step 7: Run final tests + ruff**

Run:
```bash
.venv/bin/pytest tests/ -q 2>&1 | tail -3
.venv/bin/ruff check src/
```

Expected: ~1484 PASS, ruff clean.

- [ ] **Step 8: Commit**

```bash
git add docs/adr/0018-phase-7f1-podman-containerd-audit.md \
        pyproject.toml CHANGELOG.md ROADMAP.md README.md CLAUDE.md
git commit -m "docs(7f.1): ADR-0018 + v0.18.0 release notes

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>"
```

- [ ] **Step 9: Show final state**

Run: `git log --oneline 892424f..HEAD`

Expected: 16 new commits (T1-T14 + T16; T15 was verification-only).

Hand off to user: announce v0.18.0 is ready for push + PyPI release (do not push or publish without explicit consent).

---

## Self-Review Notes

**Spec coverage:**
- §1 Goal / §2 Scope: T8-T12 (5 Checks)
- §3 Architecture: T2-T5 (helpers in `_docker_common.py`)
- §3.5 Cross-talk yield: T11/T12 (docker takeover detection)
- §3.6 Shared helpers: T3-T5
- §4 Component details: T8-T12
- §5 Data flow: implicit in T8-T12
- §6 Error handling: covered in each Check's tests
- §7 Testing: 71 new tests across T2-T12 + T13
- §8 SSH policy: T13
- §9 Out-of-scope / release: T16
- §10 Decision summary: all decisions encoded in T2-T13

**Placeholder scan:** No TBD / TODO. Each step has actual code or exact commands.

**Type / name consistency:**
- `_evaluate_inspect(inspect_json, *, runtime, rootless=False, baseline_runtime_rules)` — consistent across T3 / T9 / T11
- `_evaluate_image_tag(repo, tag, *, runtime, baseline_image_patterns)` — consistent across T4 / T10 / T12
- `_parse_ctr_info(text) -> dict` — consistent across T5 / T11
- `detect_containerd_runtime(ctx) -> tuple[str | None, str | None]` — consistent across T2 / T11 / T12
- `threat_refs_template: "{prefix}-RUNTIME-..."` rendering with `_RUNTIME_PREFIX_BY_RUNTIME` — consistent across T3 / T6
- `self.make_finding(ctx, **kw)` everywhere new Checks emit findings — consistent

**Spec inaccuracy noted in plan:**
- T6 / T7 explicitly add `threat_refs_template` field to baseline.yaml; this is an implementation detail not surfaced in the spec but required for the per-runtime TI rendering to work. T3 reads this template; T6 populates it.
