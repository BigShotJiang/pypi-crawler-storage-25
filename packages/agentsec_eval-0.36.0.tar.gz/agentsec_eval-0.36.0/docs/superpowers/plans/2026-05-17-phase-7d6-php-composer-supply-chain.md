# Phase 7d.6 — PHP/Composer Supply Chain Audit Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a 7th ecosystem to the supply chain audit series — PHP/Composer. Implement `PhpSupplyChainAuditCheck`, `OsvPackagistFetcher`, `composer.lock` JSON parser, Composer version comparator via `packaging.version` + 5-rule preprocessing, OSV-Packagist DB build pipeline, CLI flag, ADR-0026, v0.36.0 docs.

**Architecture:** Mirror Phase 7d.5 (ruby/gem). Three PHP/Composer-specific deltas: (1) parse `composer.lock` JSON (two arrays: `packages` + `packages-dev`); (2) Composer stability flags (`dev/alpha/beta/RC/p`) mapped to PEP 440 via 5-rule regex preprocessing; (3) 3-tuple parser output `(name, version, scope)` lets findings carry `evidence.scope: "prod"|"dev"` for operator triage. Zero new third-party deps.

**Tech Stack:** Python; existing `packaging` (already pulled in by pip ecosystem), `httpx`, `pydantic`, `pytest`, `ruff`. `json` stdlib for lockfile parsing.

**Baseline:** main `7a52116`; **1791 tests pass / 9 skipped**. Target version: `v0.36.0`.

**Reference spec:** `docs/superpowers/specs/2026-05-17-phase-7d6-php-composer-supply-chain-design.md`

**Reference precedent:** Phase 7d.5 (ruby/gem), shipped at commits `d26d096..7a52116`. The implementer should `git show <sha>` on those commits as canonical templates — 7d.6 mirrors that structure with PHP-specific deltas.

---

## File Structure

| File | Role | Touch |
|---|---|---|
| `src/agentsec/audit/checks/_supply_chain_common.py` | Add `parse_composer_lock` + `_normalize_composer_version` + `_safe_parse_composer_version` + `_is_composer_version_in_range` | Modify |
| `src/agentsec/audit/checks/php_supply_chain_audit.py` | New `PhpSupplyChainAuditCheck` | **Create** |
| `src/agentsec/audit/ioc_update/fetchers/osv_packagist.py` | New `OsvPackagistFetcher` | **Create** |
| `src/agentsec/audit/ioc_update/cli.py` | Add `_run_osv_packagist` + 7-way gather | Modify |
| `src/agentsec/audit/ioc/osv_packagist.json` | Bundled DB (built in Task 9) | **Create** |
| `src/agentsec/audit/ioc/threat_intel.yaml` | Add `TI-OSV-PACKAGIST-CATALOG` entry | Modify |
| `src/agentsec/audit/ioc/cve_database.json` | Regenerated after threat_intel.yaml change | Modify |
| `scripts/check_osv_packagist.py` | CI guard | **Create** |
| `src/agentsec/config.py` | Add `composer_lock_paths` field + validator | Modify |
| `src/agentsec/audit/checks/base.py` | Add `composer_lock_paths` to CheckContext | Modify |
| `src/agentsec/audit/server_audit.py` | Wire `composer_lock_paths` into CheckContext construction | Modify |
| `src/agentsec/cli.py` | Add `--composer-lock-path` to `server-audit` + `_evaluate_server` | Modify |
| `tests/test_parse_composer_lock.py` | Unit tests | **Create** |
| `tests/test_is_composer_version_in_range.py` | Unit tests | **Create** |
| `tests/test_php_supply_chain_audit.py` | Unit tests | **Create** |
| `tests/test_osv_packagist_fetcher.py` | Unit tests | **Create** |
| `tests/test_config_composer_lock_paths.py` | Unit tests | **Create** |
| `docs/adr/0026-phase-7d6-php-composer-supply-chain.md` | New ADR | **Create** |
| `CHANGELOG.md` | v0.36.0 entry | Modify |
| `ROADMAP.md` | Mark 7d.6 shipped | Modify |
| `CLAUDE.md` | Add `## PHP/Composer supply chain audit (Phase 7d.6, v0.36.0)` section | Modify |
| `pyproject.toml` | 0.35.0 → 0.36.0 | Modify |

---

## Task 1: parse_composer_lock + version helpers + tests

**Files:**
- Modify: `src/agentsec/audit/checks/_supply_chain_common.py` (append helpers)
- Create: `tests/test_parse_composer_lock.py`
- Create: `tests/test_is_composer_version_in_range.py`

- [ ] **Step 1.1: Append helpers to `_supply_chain_common.py`**

Append to `src/agentsec/audit/checks/_supply_chain_common.py`:

```python


# ── composer.lock parser + PEP 440 version range matcher (Phase 7d.6) ─────

_COMPOSER_STABILITY_RE = re.compile(
    r"-(dev|alpha|beta|RC|p)(\d*)\b", re.IGNORECASE
)

_COMPOSER_STABILITY_MAP = {
    "dev": ".dev",
    "alpha": "a",
    "beta": "b",
    "rc": "rc",
    "p": ".post",
}


def parse_composer_lock(text: str) -> list[tuple[str, str, str]]:
    """Parse a Composer-generated composer.lock JSON file.

    Returns a list of (package_name, version, scope) tuples where scope
    is "prod" for entries from the `packages` array and "dev" for
    `packages-dev`. Both arrays are walked.

    Filters out `source.type == "path"` entries (local references —
    OSV cannot cover them). All other source types (git / hg / svn /
    missing) are admitted; private-server packages will naturally fail
    to match the OSV-Packagist catalog.

    Package names are case-folded to lowercase (Packagist is
    case-insensitive). Versions have any leading `v` stripped
    (Composer allows `v1.2.3` and `1.2.3` interchangeably).

    Returns [] if JSON parsing fails or both arrays are absent.
    """
    import json as _json

    try:
        data = _json.loads(text)
    except (_json.JSONDecodeError, TypeError):
        return []
    if not isinstance(data, dict):
        return []

    out: list[tuple[str, str, str]] = []
    for scope_key, scope_tag in (("packages", "prod"), ("packages-dev", "dev")):
        entries = data.get(scope_key) or []
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name")
            version = entry.get("version")
            if not isinstance(name, str) or not isinstance(version, str):
                continue
            source = entry.get("source") or {}
            if isinstance(source, dict) and source.get("type") == "path":
                continue
            normalized_version = version[1:] if version[:1] in ("v", "V") else version
            out.append((name.lower(), normalized_version, scope_tag))

    return out


def _normalize_composer_version(s: str) -> str:
    """Convert a Composer version string into a PEP 440-compatible form.

    Composer stability flags map to PEP 440 as follows:
      -dev  → .devN  (default N=0)
      -alpha → aN
      -beta → bN
      -RC   → rcN
      -p    → .postN  (Composer "patch" stability)

    Leading `v` / `V` is stripped (e.g. `v1.2.3` → `1.2.3`).
    Build metadata (`+local`) is preserved — PEP 440 accepts local
    segments and compares by base version.
    """
    if not s:
        return s
    if s[:1] in ("v", "V"):
        s = s[1:]

    def _sub(m: "re.Match[str]") -> str:
        flag = m.group(1).lower()
        num = m.group(2) or "0"
        return f"{_COMPOSER_STABILITY_MAP[flag]}{num}"

    return _COMPOSER_STABILITY_RE.sub(_sub, s)


def _safe_parse_composer_version(s: str):
    """Parse a Composer version into packaging.Version, or None on failure."""
    from packaging.version import InvalidVersion, Version
    if not s:
        return None
    try:
        return Version(_normalize_composer_version(s))
    except (InvalidVersion, TypeError):
        return None


def _is_composer_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
) -> bool:
    """True iff version satisfies introduced <= version < fixed.

    Either bound may be None: missing introduced means "from 0";
    missing fixed means "no upper bound" (still vulnerable).
    Returns False if the version string cannot be parsed (this
    includes Composer dev-branch aliases like `dev-master` /
    `1.x-dev` which are not real version numbers).
    """
    v = _safe_parse_composer_version(version)
    if v is None:
        return False
    if introduced is not None:
        intro = _safe_parse_composer_version(introduced)
        if intro is not None and intro > v:
            return False
    if fixed is not None:
        fix = _safe_parse_composer_version(fixed)
        if fix is not None and v >= fix:
            return False
    return True
```

Verify `import re` is already at top of `_supply_chain_common.py` (it was added in Phase 7d.4 Task 1 and reused in 7d.5). If not, add it. The `import json` is intentionally function-local to avoid touching the module-level imports.

- [ ] **Step 1.2: Create `tests/test_parse_composer_lock.py`**

```python
"""Unit tests for parse_composer_lock (Phase 7d.6)."""

from __future__ import annotations

import json

from agentsec.audit.checks._supply_chain_common import parse_composer_lock


def _lock(packages=None, packages_dev=None) -> str:
    obj = {}
    if packages is not None:
        obj["packages"] = packages
    if packages_dev is not None:
        obj["packages-dev"] = packages_dev
    return json.dumps(obj)


def test_parses_packages_and_packages_dev() -> None:
    text = _lock(
        packages=[
            {"name": "monolog/monolog", "version": "2.9.1", "source": {"type": "git"}},
            {"name": "psr/log", "version": "3.0.0", "source": {"type": "git"}},
        ],
        packages_dev=[
            {"name": "phpunit/phpunit", "version": "9.6.13", "source": {"type": "git"}},
        ],
    )
    deps = parse_composer_lock(text)
    assert deps == [
        ("monolog/monolog", "2.9.1", "prod"),
        ("psr/log", "3.0.0", "prod"),
        ("phpunit/phpunit", "9.6.13", "dev"),
    ]


def test_only_packages_array() -> None:
    text = _lock(packages=[
        {"name": "symfony/console", "version": "6.3.0", "source": {"type": "git"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [("symfony/console", "6.3.0", "prod")]


def test_only_packages_dev_array() -> None:
    text = _lock(packages_dev=[
        {"name": "vimeo/psalm", "version": "5.15.0", "source": {"type": "git"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [("vimeo/psalm", "5.15.0", "dev")]


def test_empty_json_returns_empty() -> None:
    assert parse_composer_lock("{}") == []
    assert parse_composer_lock("") == []
    assert parse_composer_lock("not-json") == []


def test_skips_source_type_path() -> None:
    text = _lock(packages=[
        {"name": "vendor/published", "version": "1.0.0", "source": {"type": "git"}},
        {"name": "vendor/local", "version": "0.1.0", "source": {"type": "path"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [("vendor/published", "1.0.0", "prod")]


def test_case_folds_names_and_strips_v_prefix() -> None:
    text = _lock(packages=[
        {"name": "Laravel/Framework", "version": "v10.34.2", "source": {"type": "git"}},
        {"name": "GuzzleHTTP/Guzzle", "version": "V7.8.1", "source": {"type": "git"}},
    ])
    deps = parse_composer_lock(text)
    assert deps == [
        ("laravel/framework", "10.34.2", "prod"),
        ("guzzlehttp/guzzle", "7.8.1", "prod"),
    ]
```

- [ ] **Step 1.3: Create `tests/test_is_composer_version_in_range.py`**

```python
"""Unit tests for _is_composer_version_in_range (Phase 7d.6)."""

from __future__ import annotations

import pytest

from agentsec.audit.checks._supply_chain_common import (
    _is_composer_version_in_range,
    _normalize_composer_version,
    _safe_parse_composer_version,
)


@pytest.mark.parametrize(
    "version,introduced,fixed,expected",
    [
        # Standard semver
        ("1.5.0", "1.0", "2.0", True),
        ("0.9.0", "1.0", "2.0", False),
        ("2.0.0", "1.0", "2.0", False),  # fixed exclusive
        ("1.0.0", "1.0", "2.0", True),  # introduced inclusive
        # v-prefix stripping
        ("v1.5.0", "1.0", "2.0", True),
        # Composer stability flags
        ("1.0.0-dev", "0", "1.0.0", True),
        ("1.0.0", "0", "1.0.0-dev", False),  # stable > dev
        ("1.0.0-alpha", "0", "1.0.0-beta", True),  # alpha < beta
        ("1.0.0-beta", "0", "1.0.0-alpha", False),
        ("1.0.0-alpha2", "1.0.0-alpha", "1.0.0-alpha3", True),
        ("1.0.0-RC1", "0", "1.0.0", True),
        ("1.0.0-p1", "1.0.0", None, True),  # patch > stable
        # Missing bounds
        ("1.5.0", None, "2.0", True),
        ("3.0.0", None, "2.0", False),
        ("1.5.0", "1.0", None, True),
        ("0.5.0", "1.0", None, False),
        ("1.5.0", None, None, True),  # all versions vulnerable
        # Unparseable returns False (Composer dev-branch aliases)
        ("dev-master", "1.0", "2.0", False),
        ("1.x-dev", "1.0", "2.0", False),
        ("not-a-version", "1.0", "2.0", False),
    ],
)
def test_is_composer_version_in_range(
    version: str,
    introduced: str | None,
    fixed: str | None,
    expected: bool,
) -> None:
    assert _is_composer_version_in_range(version, introduced, fixed) is expected


def test_normalize_strips_v_prefix() -> None:
    assert _normalize_composer_version("v1.2.3") == "1.2.3"
    assert _normalize_composer_version("V1.2.3") == "1.2.3"
    assert _normalize_composer_version("1.2.3") == "1.2.3"


def test_normalize_stability_mapping() -> None:
    assert _normalize_composer_version("1.0.0-dev") == "1.0.0.dev0"
    assert _normalize_composer_version("1.0.0-alpha") == "1.0.0a0"
    assert _normalize_composer_version("1.0.0-alpha2") == "1.0.0a2"
    assert _normalize_composer_version("1.0.0-beta") == "1.0.0b0"
    assert _normalize_composer_version("1.0.0-RC1") == "1.0.0rc1"
    assert _normalize_composer_version("1.0.0-p1") == "1.0.0.post1"


def test_safe_parse_handles_invalid() -> None:
    assert _safe_parse_composer_version("") is None
    assert _safe_parse_composer_version(None) is None  # type: ignore
    assert _safe_parse_composer_version("dev-master") is None
    assert _safe_parse_composer_version("1.x-dev") is None


def test_safe_parse_handles_stability_forms() -> None:
    assert _safe_parse_composer_version("1.0.0-dev") is not None
    assert _safe_parse_composer_version("1.0.0-alpha2") is not None
    assert _safe_parse_composer_version("1.0.0-RC1") is not None
    assert _safe_parse_composer_version("1.0.0-p1") is not None


def test_safe_parse_handles_build_metadata() -> None:
    assert _safe_parse_composer_version("1.0.0+20210101") is not None
```

- [ ] **Step 1.4: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_parse_composer_lock.py tests/test_is_composer_version_in_range.py -v
```
Expected: all PASS (6 parse + 21 parametrize cases + 5 normalize/safe_parse = ~32 logical PASSes).

If FAIL: common gotchas:
- `_COMPOSER_STABILITY_RE` uses `\b` — make sure `-p1` matches (digit follows `p`, word boundary is between `p1` and end-of-string; `\b` only triggers at digit↔non-digit transitions, so `\b` after `\d*` may be too strict). If `-p1` regex test fails, simplify the regex to `r"-(dev|alpha|beta|RC|p)(\d*)"` without `\b`.
- `re.IGNORECASE` is needed because the spec maps `-RC1` (capital) but the regex must also accept `-rc1`. Verify with `_normalize_composer_version("1.0.0-rc1") == "1.0.0rc1"`.

- [ ] **Step 1.5: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/checks/_supply_chain_common.py tests/test_parse_composer_lock.py tests/test_is_composer_version_in_range.py
```

- [ ] **Step 1.6: Full pytest (no regression)**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: 1791 + ~32 = ~1823 PASS / 9 skipped.

- [ ] **Step 1.7: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/checks/_supply_chain_common.py tests/test_parse_composer_lock.py tests/test_is_composer_version_in_range.py && git commit -m "$(cat <<'EOF'
feat(7d.6): composer.lock parser + Composer version range matcher

parse_composer_lock walks `packages` + `packages-dev` arrays of a
JSON composer.lock, filters out source.type=="path" entries,
lowercases package names, strips leading 'v' from versions, and
tags each entry with scope ("prod" or "dev").

_is_composer_version_in_range bridges Composer stability flags
(dev/alpha/beta/RC/p) to packaging.version.Version (PEP 440) via
5-rule regex preprocessing. Zero new deps (packaging already pulled
in by pip ecosystem). Tests cover all 5 stability flags, v-prefix
strip, dev-branch aliases (unparseable returns False), and build
metadata.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: ServerAuditConfig.composer_lock_paths + CheckContext + tests

**Files:**
- Modify: `src/agentsec/config.py` (add field+validator after `gem_lock_paths`)
- Modify: `src/agentsec/audit/checks/base.py` (add CheckContext field)
- Modify: `src/agentsec/audit/server_audit.py` (wire field into CheckContext construction)
- Create: `tests/test_config_composer_lock_paths.py`

REFERENCE: Phase 7d.5 Task 2 pattern. Inspect the precedent:
```
cd /Users/roger/Work/AgentSec && grep -n "gem_lock_paths" src/agentsec/config.py src/agentsec/audit/checks/base.py src/agentsec/audit/server_audit.py
```

- [ ] **Step 2.1: Add `composer_lock_paths` to `ServerAuditConfig`**

In `src/agentsec/config.py`, immediately after the `gem_lock_paths` field+validator (added in 7d.5 Task 2), add:

```python

    composer_lock_paths: list[str] = Field(default_factory=list)

    @field_validator("composer_lock_paths")
    @classmethod
    def _validate_composer_lock_paths(cls, v: list[str]) -> list[str]:
        from .audit.metachar_guard import contains_shell_metachar

        for p in v:
            if not (p.startswith("/") or p.startswith("~/")):
                raise ValueError(
                    f"composer_lock_paths entry {p!r} must start with '/' or '~/'"
                )
            if contains_shell_metachar(p):
                raise ValueError(
                    f"composer_lock_paths entry {p!r} contains shell metacharacter"
                )
            basename = p.rsplit("/", 1)[-1]
            if basename != "composer.lock":
                raise ValueError(
                    f"composer_lock_paths entry {p!r} basename must equal 'composer.lock' "
                    f"(strict, mirrors Cargo.lock/Gemfile.lock convention)"
                )
        return v
```

- [ ] **Step 2.2: Add field to `CheckContext`**

In `src/agentsec/audit/checks/base.py`, find `gem_lock_paths` (added in 7d.5 Task 2). Add `composer_lock_paths` right after with identical pattern (likely `tuple[str, ...] = ()`).

- [ ] **Step 2.3: Wire into `server_audit.py`**

In `src/agentsec/audit/server_audit.py`, find where `gem_lock_paths` is passed to `CheckContext(...)` construction. Add `composer_lock_paths=ctx.composer_lock_paths` (or equivalent — mirror the exact gem line).

- [ ] **Step 2.4: Create `tests/test_config_composer_lock_paths.py`**

```python
"""Unit tests for ServerAuditConfig.composer_lock_paths validator (Phase 7d.6)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from agentsec.config import ServerAuditConfig


def _config(**overrides) -> dict:
    """Minimal valid ServerAuditConfig dict.

    Inspect tests/test_config_gem_lock_paths.py for the canonical
    minimal shape if this template doesn't validate.
    """
    return {
        "host": "test.example",
        "user": "ubuntu",
        "key": "~/.ssh/id_rsa",
        **overrides,
    }


def test_empty_composer_lock_paths_is_valid() -> None:
    cfg = ServerAuditConfig.model_validate(_config())
    assert cfg.composer_lock_paths == []


def test_accepts_valid_composer_lock_path() -> None:
    cfg = ServerAuditConfig.model_validate(_config(
        composer_lock_paths=[
            "/opt/myapp/composer.lock",
            "~/projects/laravel-app/composer.lock",
        ]
    ))
    assert len(cfg.composer_lock_paths) == 2


def test_rejects_relative_path() -> None:
    with pytest.raises(ValidationError, match="must start with"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["composer.lock"]
        ))


def test_rejects_shell_metachar() -> None:
    with pytest.raises(ValidationError, match="shell metacharacter"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/$INJECT/composer.lock"]
        ))


def test_rejects_non_canonical_basename() -> None:
    # Must be exactly "composer.lock" (lowercase)
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/myapp/Composer.lock"]  # capital wrong
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/myapp/composer.lock.bak"]  # suffix wrong
        ))
    with pytest.raises(ValidationError, match="basename must equal"):
        ServerAuditConfig.model_validate(_config(
            composer_lock_paths=["/opt/myapp/composer.json"]  # not lockfile
        ))
```

NOTE: If `_config()` minimal dict differs (e.g., `consent_file` vs `key`), inspect `tests/test_config_gem_lock_paths.py` (shipped in 7d.5 Task 2) and copy its exact minimal config shape.

- [ ] **Step 2.5: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_config_composer_lock_paths.py -v
```
Expected: 5 PASS.

- [ ] **Step 2.6: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ~1823 + 5 = ~1828 PASS / 9 skipped.

- [ ] **Step 2.7: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/config.py src/agentsec/audit/checks/base.py src/agentsec/audit/server_audit.py tests/test_config_composer_lock_paths.py
```

- [ ] **Step 2.8: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/config.py src/agentsec/audit/checks/base.py src/agentsec/audit/server_audit.py tests/test_config_composer_lock_paths.py && git commit -m "$(cat <<'EOF'
feat(7d.6): add composer_lock_paths to ServerAuditConfig + CheckContext

Operator-configured paths to composer.lock files, mirrors
gem_lock_paths / maven_lock_paths / cargo_lock_paths. Validator:
must start with / or ~/, no shell metachars, basename must equal
'composer.lock' (strict lowercase, mirrors Cargo.lock/Gemfile.lock
convention).

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: OsvPackagistFetcher + mock httpx tests

**Files:**
- Create: `src/agentsec/audit/ioc_update/fetchers/osv_packagist.py`
- Create: `tests/test_osv_packagist_fetcher.py`

REFERENCE: Phase 7d.5 Task 3 shipped `osv_rubygems.py`. Mirror line-for-line; only differences are URL, ecosystem string, fetcher name, function name.

```
cd /Users/roger/Work/AgentSec && cat src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py
```

- [ ] **Step 3.1: Create `osv_packagist.py`**

Copy `src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py` as the template, then apply these substitutions throughout:

| RubyGems version | Packagist version |
|---|---|
| `OSV_RUBYGEMS_URL` | `OSV_PACKAGIST_URL` |
| `"https://...RubyGems/all.zip"` | `"https://osv-vulnerabilities.storage.googleapis.com/Packagist/all.zip"` |
| `_extract_rubygems_ranges` | `_extract_packagist_ranges` |
| `normalize_osv_rubygems_entry` | `normalize_osv_packagist_entry` |
| `OsvRubyGemsFetcher` | `OsvPackagistFetcher` |
| `_osv_rubygems_full` | `_osv_packagist_full` |
| ecosystem check `== "RubyGems"` | `== "Packagist"` |
| docstring "OSV-RubyGems" → "OSV-Packagist" | (same shape, replace string) |
| Comments mentioning "ruby" / "RubyGems" / "Gemfile" → "php" / "Packagist" / "composer" | |

The 5-axis filter chain logic, ZIP parse, retry/backoff, dedup-on-(id,package) — all identical to rubygems, no changes.

- [ ] **Step 3.2: Create `tests/test_osv_packagist_fetcher.py`**

Copy `tests/test_osv_rubygems_fetcher.py` template structure (shipped in 7d.5 Task 3). Substitute:
- Ecosystem `"RubyGems"` → `"Packagist"`
- Package names: change from plain gem names like `rails`/`nokogiri` to Composer-style `vendor/package` like `monolog/monolog`, `symfony/console`, `laravel/framework`
- Function name `normalize_osv_rubygems_entry` → `normalize_osv_packagist_entry`
- Class name `OsvRubyGemsFetcher` → `OsvPackagistFetcher`
- Result key `_osv_rubygems_full` → `_osv_packagist_full`

Reference test file shape:
```
cd /Users/roger/Work/AgentSec && cat tests/test_osv_rubygems_fetcher.py
```

Apply the substitutions; the test logic (zip mocking, normalize round-trip, dedup, drop withdrawn / drop non-ecosystem) is identical.

- [ ] **Step 3.3: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_osv_packagist_fetcher.py -v
```
Expected: 4 PASS (matching the rubygems tests).

- [ ] **Step 3.4: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/ioc_update/fetchers/osv_packagist.py tests/test_osv_packagist_fetcher.py
```

- [ ] **Step 3.5: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ~1828 + 4 = ~1832 PASS / 9 skipped.

- [ ] **Step 3.6: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc_update/fetchers/osv_packagist.py tests/test_osv_packagist_fetcher.py && git commit -m "$(cat <<'EOF'
feat(7d.6): OsvPackagistFetcher — pull OSV-Packagist full ecosystem dump

Mirrors OsvRubyGemsFetcher: pulls
https://osv-vulnerabilities.storage.googleapis.com/Packagist/all.zip,
walks every JSON entry, applies the 5-axis filter chain (drop
withdrawn / no Packagist affected / no range / no CVSS / scored
medium-low > 2y), expands multi-affected packages, dedups on
(id, package). Tests use httpx.MockTransport.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: scripts/check_osv_packagist.py CI guard

**Files:**
- Create: `scripts/check_osv_packagist.py`

- [ ] **Step 4.1: Create the script**

```python
#!/usr/bin/env python3
"""CI guard for src/agentsec/audit/ioc/osv_packagist.json.

Validates the bundled OSV-Packagist advisory DB:
  - File exists
  - Valid JSON (top-level list of advisory dicts)
  - File size <= 15 MB hard cap

Usage:
    python scripts/check_osv_packagist.py [--check]

Exits 0 on success, 1 on failure.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "src/agentsec/audit/ioc/osv_packagist.json"
SIZE_CAP_BYTES = 15 * 1024 * 1024  # 15 MB


def main() -> int:
    if not DB_PATH.exists():
        print(f"FAIL: {DB_PATH} does not exist", file=sys.stderr)
        return 1

    size = DB_PATH.stat().st_size
    if size > SIZE_CAP_BYTES:
        print(
            f"FAIL: {DB_PATH} is {size:,} bytes, exceeds cap "
            f"{SIZE_CAP_BYTES:,} bytes",
            file=sys.stderr,
        )
        return 1

    try:
        data = json.loads(DB_PATH.read_text())
    except json.JSONDecodeError as exc:
        print(f"FAIL: {DB_PATH} is not valid JSON: {exc}", file=sys.stderr)
        return 1

    if not isinstance(data, list):
        print(
            f"FAIL: {DB_PATH} top-level must be a list, got {type(data).__name__}",
            file=sys.stderr,
        )
        return 1

    print(
        f"OK — {DB_PATH.name} contains {len(data):,} advisories, "
        f"{size:,} bytes (cap {SIZE_CAP_BYTES:,})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

- [ ] **Step 4.2: Make executable + verify FAIL (DB not built yet)**

```bash
cd /Users/roger/Work/AgentSec && chmod +x scripts/check_osv_packagist.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_packagist.py
```
Expected: FAIL `does not exist`. Exit code 1. This is EXPECTED — Task 9 builds the DB.

- [ ] **Step 4.3: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check scripts/check_osv_packagist.py
```

- [ ] **Step 4.4: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add scripts/check_osv_packagist.py && git commit -m "$(cat <<'EOF'
feat(7d.6): scripts/check_osv_packagist.py CI guard

Validates osv_packagist.json exists, is valid JSON list, and is
under 15 MB cap. Mirrors check_osv_rubygems.py / check_osv_maven.py /
check_osv_cargo.py / check_osv_pypi.py / check_osv_go.py /
check_osv_npm.py. Fails until Task 9 builds the bundled DB.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: ioc-update CLI _run_osv_packagist + 7-way gather

**Files:**
- Modify: `src/agentsec/audit/ioc_update/cli.py`

REFERENCE: Phase 7d.5 Task 5 added `_run_osv_rubygems` to the gather. Mirror that change.

- [ ] **Step 5.1: Add import**

In `src/agentsec/audit/ioc_update/cli.py`, find the import line `from .fetchers.osv_rubygems import OsvRubyGemsFetcher` (added in 7d.5). Add immediately after:

```python
from .fetchers.osv_packagist import OsvPackagistFetcher
```

- [ ] **Step 5.2: Add `_run_osv_packagist` function**

Find `_run_osv_rubygems` in the file. Add a copy of that function immediately after, with these substitutions:
- Function name: `_run_osv_rubygems` → `_run_osv_packagist`
- Fetcher: `OsvRubyGemsFetcher()` → `OsvPackagistFetcher()`
- Result key: `_osv_rubygems_full` → `_osv_packagist_full`
- Output filename: `proposed-osv_rubygems.json` → `proposed-osv_packagist.json`
- Log/audit event names: `osv_rubygems_written` → `osv_packagist_written`, etc.

- [ ] **Step 5.3: Extend `asyncio.gather` to 7-way**

Find the gather call site (6-way after 7d.5). Add `_run_osv_packagist(...)` as the 7th argument with the same call signature as the rubygems call. Also extend any tuple unpacking (e.g., `osv_npm_path, osv_pypi_path, osv_go_path, osv_cargo_path, osv_maven_path, osv_rubygems_path, osv_packagist_path = await asyncio.gather(...)`).

- [ ] **Step 5.4: Add audit_events for packagist**

If 7d.5 added `osv_rubygems_written` / `osv_rubygems_degraded` audit_events, add the analogous `osv_packagist_written` / `osv_packagist_degraded` block.

- [ ] **Step 5.5: Lint + existing ioc-update integration tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/ioc_update/cli.py
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/integration/test_ioc_update_offline.py tests/integration/test_ioc_update_mock_http.py -v 2>&1 | tail -10
```
Expected: lint PASS; ioc-update integration tests PASS.

- [ ] **Step 5.6: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc_update/cli.py && git commit -m "$(cat <<'EOF'
feat(7d.6): ioc-update — wire OsvPackagistFetcher into 7-way gather

Add _run_osv_packagist() and include it in the asyncio.gather call
that fans out OSV fetches across npm/pypi/go/cargo/maven/rubygems/packagist.
Output written to .cache/ioc-update-<date>/proposed-osv_packagist.json.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: threat_intel.yaml + cve_database.json

**Files:**
- Modify: `src/agentsec/audit/ioc/threat_intel.yaml`
- Modify: `src/agentsec/audit/ioc/cve_database.json`

- [ ] **Step 6.1: Inspect existing TI-OSV-RUBYGEMS-CATALOG entry shape**

```
cd /Users/roger/Work/AgentSec && grep -n -B 1 -A 12 "TI-OSV-RUBYGEMS-CATALOG" src/agentsec/audit/ioc/threat_intel.yaml
```

This shows the exact yaml shape used by 7d.5 Task 6 — match it.

- [ ] **Step 6.2: Add TI-OSV-PACKAGIST-CATALOG entry**

Add immediately after `TI-OSV-RUBYGEMS-CATALOG`, matching its exact indentation:

```yaml
  - id: TI-OSV-PACKAGIST-CATALOG
    source: osv
    url: https://osv.dev/list?ecosystem=Packagist
    observed_at: 2026-05-17
    claim: |
      Aggregated CVE catalog for Packagist (PHP/Composer) packages, sourced from OSV.
      Umbrella TI; per-CVE advisory id surfaces directly in finding evidence.
    confidence: high
    mapped_tests: [php_supply_chain_audit]
    note: |
      Umbrella TI for all Packagist CVE matches surfaced by
      php_supply_chain_audit. Refresh via `agentsec ioc-update`.
    auto_refresh: false
```

NOTE: If the actual yaml field shape used by 7d.5 differs from this template (e.g., snake_case field renames, missing `url` field), defer to what's literally in the file — copy the rubygems entry verbatim and substitute strings.

- [ ] **Step 6.3: Verify YAML parses**

```
cd /Users/roger/Work/AgentSec && .venv/bin/python -c "
import yaml
with open('src/agentsec/audit/ioc/threat_intel.yaml') as f:
    data = yaml.safe_load(f)
entries = data if isinstance(data, list) else data.get('entries', data)
ids = [e['id'] for e in entries if isinstance(e, dict) and 'id' in e]
print('TI-OSV-PACKAGIST-CATALOG present:', 'TI-OSV-PACKAGIST-CATALOG' in ids)
print('TI-OSV-RUBYGEMS-CATALOG present:', 'TI-OSV-RUBYGEMS-CATALOG' in ids)
print('total entries:', len(ids))
"
```
Expected: both present True.

- [ ] **Step 6.4: Regenerate cve_database.json**

```
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/build_cve_db.py
```

- [ ] **Step 6.5: Verify CI guard passes**

```
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/build_cve_db.py --check
```
Expected: PASS.

- [ ] **Step 6.6: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: no change to test count (~1832 PASS / 9 skipped).

- [ ] **Step 6.7: Commit (both files)**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc/threat_intel.yaml src/agentsec/audit/ioc/cve_database.json && git commit -m "$(cat <<'EOF'
feat(7d.6): threat_intel.yaml — add TI-OSV-PACKAGIST-CATALOG umbrella

New umbrella TI entry for Packagist CVE matches; mapped_tests =
[php_supply_chain_audit]. auto_refresh: false (per-CVE advisory
ids live in finding evidence, not TI). Regenerate cve_database.json.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: PhpSupplyChainAuditCheck + tests

**Files:**
- Create: `src/agentsec/audit/checks/php_supply_chain_audit.py`
- Create: `tests/test_php_supply_chain_audit.py`

REFERENCE: Phase 7d.5 shipped `gem_supply_chain_audit.py`. Mirror line-for-line; differences:

- DB filename: `osv_rubygems.json` → `osv_packagist.json`
- Check id: `gem_supply_chain_audit` → `php_supply_chain_audit`
- Class: `GemSupplyChainAuditCheck` → `PhpSupplyChainAuditCheck`
- ctx field: `ctx.gem_lock_paths` → `ctx.composer_lock_paths`
- Helper: `parse_gemfile_lock` → `parse_composer_lock`
- Helper: `_is_gem_version_in_range` → `_is_composer_version_in_range`
- threat_refs: `["TI-OSV-RUBYGEMS-CATALOG"]` → `["TI-OSV-PACKAGIST-CATALOG"]`
- Coord variable: `gem` → `package`
- _match function name: `_match_gem_advisories` → `_match_composer_advisories`
- Description docstring: "RubyGems" → "Packagist", "Ruby" → "PHP", "Bundler" → "Composer"
- evidence key: `gem` → `package`
- **3-tuple unpacking**: `parse_composer_lock` returns `(name, version, scope)` — the Check loop must unpack three values; `evidence` dict gains `"scope": scope` key

- [ ] **Step 7.1: Inspect the gem template**

```
cd /Users/roger/Work/AgentSec && cat src/agentsec/audit/checks/gem_supply_chain_audit.py
```

- [ ] **Step 7.2: Create `php_supply_chain_audit.py`**

Copy the gem file, apply substitutions, AND apply the 3-tuple delta. The loop body changes from:

```python
for gem, version in parse_gemfile_lock(text):
    for advisory in _match_gem_advisories(gem, version, db_by_pkg):
        findings.append(self.make_finding(
            ctx, severity=..., title=..., evidence={
                "gem": gem, "version": version, ...
            },
            threat_refs=["TI-OSV-RUBYGEMS-CATALOG"],
        ))
```

to:

```python
for package, version, scope in parse_composer_lock(text):
    for advisory in _match_composer_advisories(package, version, db_by_pkg):
        findings.append(self.make_finding(
            ctx, severity=..., title=..., evidence={
                "package": package, "version": version, "scope": scope, ...
            },
            threat_refs=["TI-OSV-PACKAGIST-CATALOG"],
        ))
```

`_match_composer_advisories` mirrors `_match_gem_advisories` exactly — internal version-range check uses `_is_composer_version_in_range`.

- [ ] **Step 7.3: Create `tests/test_php_supply_chain_audit.py`**

Copy `tests/test_gem_supply_chain_audit.py` template structure. Substitute:
- Import `_match_composer_advisories` (not `_match_gem_advisories`)
- Use `PhpSupplyChainAuditCheck` → `GemSupplyChainAuditCheck`
- Package names in test fixtures: `rails` → `monolog/monolog`, `nokogiri` → `symfony/console`, etc. (use `vendor/package` form)
- ctx field: `ctx.gem_lock_paths` → `ctx.composer_lock_paths`
- Test fixture lock files: JSON form (`json.dumps({"packages": [{"name": ..., "version": ..., "source": {"type": "git"}}], "packages-dev": []})`) not Bundler text form
- **Add one extra test**: `test_scope_distinguishes_prod_and_dev` — same (pkg, version) appears in both `packages` and `packages-dev`, advisory matches; verify 2 findings emitted with different `evidence.scope` values

Reference test file shape:
```
cd /Users/roger/Work/AgentSec && cat tests/test_gem_supply_chain_audit.py
```

- [ ] **Step 7.4: Run new tests**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/test_php_supply_chain_audit.py -v
```
Expected: 6 PASS (5 mirroring gem + 1 new scope test).

- [ ] **Step 7.5: Lint**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/audit/checks/php_supply_chain_audit.py tests/test_php_supply_chain_audit.py
```

- [ ] **Step 7.6: Full pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ~1832 + 6 = ~1838 PASS / 9 skipped.

- [ ] **Step 7.7: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/checks/php_supply_chain_audit.py tests/test_php_supply_chain_audit.py && git commit -m "$(cat <<'EOF'
feat(7d.6): PhpSupplyChainAuditCheck — match Composer packages against OSV

Mirror GemSupplyChainAuditCheck. Read operator-configured
composer.lock files via SSH, parse with parse_composer_lock (walks
packages + packages-dev), match each (package, version) against
bundled osv_packagist.json using packaging.version (PEP 440) ranges
with Composer→PEP 440 preprocessing. Emit one Finding per matching
tuple; evidence.scope distinguishes prod from dev so operators can
triage CI-only vs production attack surface separately.
threat_refs = [TI-OSV-PACKAGIST-CATALOG].

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 8: CLI --composer-lock-path flag

**Files:**
- Modify: `src/agentsec/cli.py` (add to both `server-audit` and `_evaluate_server`)

REFERENCE: Phase 7d.5 added `--gem-lock-path`. Mirror exactly.

- [ ] **Step 8.1: Inspect existing gem plumbing**

```
cd /Users/roger/Work/AgentSec && grep -n "gem_lock_paths" src/agentsec/cli.py
```

This locates:
- typer.Option declaration in `server_audit` signature
- if-block body in `server_audit` (config update + expand_tilde + CheckContext)
- if-block body in `_evaluate_server`
- CheckContext construction lines in both

- [ ] **Step 8.2: Add `composer_lock_paths` typer.Option**

In `server_audit` command signature, immediately after `gem_lock_paths`:

```python
    composer_lock_paths: list[str] = typer.Option(
        [],
        "--composer-lock-path",
        help="Path on remote host to a Composer composer.lock file "
             "(repeatable; multiple paths checked).",
    ),
```

- [ ] **Step 8.3: Mirror gem's body wiring**

In the `server_audit` body, find the `if gem_lock_paths:` block. Add an analogous `if composer_lock_paths:` block immediately after, with identical structure (config dict update, expand_tilde, allowed_paths injection, CheckContext field).

- [ ] **Step 8.4: Mirror in `_evaluate_server`**

In the `_evaluate_server` function, find the `if sa.gem_lock_paths:` block. Add analogous `if sa.composer_lock_paths:` block immediately after.

- [ ] **Step 8.5: Add to CheckContext constructions**

In both `server_audit` and `_evaluate_server`, find the CheckContext(...) construction. Add `composer_lock_paths=tuple(...)` right after the `gem_lock_paths=tuple(...)` line.

- [ ] **Step 8.6: Smoke-test CLI help**

```
cd /Users/roger/Work/AgentSec && .venv/bin/agentsec server-audit --help 2>&1 | grep -A 1 -i composer
```
Expected: `--composer-lock-path` appears in help.

- [ ] **Step 8.7: Lint + pytest**

```
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/agentsec/cli.py
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
```
Expected: ruff PASS; ~1838 PASS / 9 skipped.

- [ ] **Step 8.8: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/cli.py && git commit -m "$(cat <<'EOF'
feat(7d.6): CLI — add --composer-lock-path to server-audit (+ evaluate)

Repeatable typer Option mirroring --gem-lock-path. Operator points
--composer-lock-path at a Composer composer.lock on the audited
host. CheckContext wiring + expand_tilde + config override all
mirror the gem path.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 9: Live agentsec ioc-update build osv_packagist.json

**Files:**
- Create: `src/agentsec/audit/ioc/osv_packagist.json`

This task requires internet access. OSV-Packagist is public Google Cloud Storage; no auth tokens. **Raw bundle is 8.9 MB (HEAD-confirmed 2026-05-17)** — the largest 7d-series raw bundle to date. After the 5-axis filter chain, expect 1.5-3 MB bundled DB.

- [ ] **Step 9.1: Source env if present**

```bash
test -f ~/.config/agentsec/env && source ~/.config/agentsec/env
```

- [ ] **Step 9.2: Run live ioc-update**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/agentsec ioc-update 2>&1 | tail -30
```
Expected: produces `.cache/ioc-update-<YYYY-MM-DD>/proposed-osv_packagist.json`.

NOTE: If a prior ioc-update today already populated `.cache/ioc-update-2026-05-17/` without the packagist run (e.g., from a previous 7d.x phase test), the new packagist file may not appear because the cache directory is reused. If `proposed-osv_packagist.json` is missing after run, delete the cache dir and re-run:

```bash
cd /Users/roger/Work/AgentSec && rm -rf .cache/ioc-update-2026-05-17/ && .venv/bin/agentsec ioc-update 2>&1 | tail -30
```

- [ ] **Step 9.3: Verify proposed file produced**

```bash
cd /Users/roger/Work/AgentSec && ls -lh .cache/ioc-update-*/proposed-osv_packagist.json | tail -3
```
Expected: file exists, size 1-3 MB typically.

If MISSING: re-run ioc-update with stderr captured to debug. STOP BLOCKED if persistent failure.

- [ ] **Step 9.4: Inspect briefly**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python -c "
import json, glob
paths = sorted(glob.glob('.cache/ioc-update-*/proposed-osv_packagist.json'))
if not paths:
    print('MISSING')
    raise SystemExit(1)
path = paths[-1]
data = json.loads(open(path).read())
print(f'path: {path}')
print(f'entries: {len(data):,}')
if data:
    sample = data[0]
    print(f'sample keys: {sorted(sample.keys())}')
    print(f'sample package: {sample.get(\"package\")}')
"
```
Expected: entries > 500 (Packagist is large); sample has `id`, `package`, `ranges`, `severity` keys; sample package looks like `vendor/name` form.

- [ ] **Step 9.5: Copy to bundled location**

```bash
cd /Users/roger/Work/AgentSec && cp $(ls -t .cache/ioc-update-*/proposed-osv_packagist.json | head -1) src/agentsec/audit/ioc/osv_packagist.json
```

- [ ] **Step 9.6: CI guard PASS**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_packagist.py
```
Expected: PASS, prints entry count and size. Size MUST be ≤ 15 MB (cap). If between 10 MB and 15 MB, log a warning in the commit message; if > 15 MB, the 5-axis filter chain has a bug — STOP BLOCKED and debug.

- [ ] **Step 9.7: Full pytest**

```bash
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -5
```
Expected: ~1838 PASS / 9 skipped (no change — bundled DB is data).

- [ ] **Step 9.8: Commit**

```bash
cd /Users/roger/Work/AgentSec && git add src/agentsec/audit/ioc/osv_packagist.json && git commit -m "$(cat <<'EOF'
feat(7d.6): bundle osv_packagist.json — first OSV-Packagist advisory DB

Built via \`agentsec ioc-update\` against live OSV-Packagist dump.
After the 5-axis filter chain (drop withdrawn / no Packagist
affected / no range / no CVSS / scored medium-low > 2y), the
bundled DB contains the curated subset for PhpSupplyChainAuditCheck.
Refresh periodically via \`agentsec ioc-update\` + replace this file.

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 10: ADR-0026 + v0.36.0 docs single commit

**Files:**
- Create: `docs/adr/0026-phase-7d6-php-composer-supply-chain.md`
- Modify: `CHANGELOG.md`
- Modify: `ROADMAP.md`
- Modify: `CLAUDE.md`
- Modify: `pyproject.toml`

- [ ] **Step 10.1: Create ADR-0026**

```markdown
# ADR-0026: Phase 7d.6 — PHP/Composer supply chain audit

* **Status**: Accepted
* **Date**: 2026-05-17
* **Phase**: 7d.6

## Context

7d series (npm / pip / go / rust/cargo / java/maven / ruby/gem)
shipped 6 OSV-backed supply chain Checks. PHP/Composer (Packagist)
is the largest single PHP ecosystem (WordPress / Laravel / Symfony
combined); adding it completes a **7-language** milestone
(JavaScript / Python / Go / Rust / Java / Ruby / PHP).

PHP / Composer differences from prior ecosystems:

1. **Lockfile is `composer.lock` JSON** — Composer is the de facto
   PHP dependency manager (used by Laravel / Symfony / WordPress
   plugins / virtually every modern PHP project). The lockfile is
   JSON (not text like Gemfile.lock or TOML like Cargo.lock), with
   two top-level arrays: `packages` (production) and `packages-dev`
   (development/CI). Both must be walked for full coverage.

2. **Composer stability flags map cleanly to PEP 440** — Composer
   uses `-dev` / `-alpha` / `-beta` / `-RC` / `-p` (patch) suffixes
   on versions; PEP 440 uses `.devN` / `aN` / `bN` / `rcN` / `.postN`.
   The two are isomorphic. 5-rule regex preprocessing in
   `_normalize_composer_version` lets us reuse `packaging.version`
   (already a pip ecosystem dep, zero new dependencies).

3. **Findings carry `evidence.scope: "prod"|"dev"`** — first 7d
   ecosystem to surface scope distinction. Some deploy flows use
   `composer install --no-dev`, so dev-only CVE matches are not
   real production attack surface. Operators can triage by scope.
   Finding fingerprint includes scope (different evidence dict),
   so prod + dev hits on the same (pkg, version, advisory) emit as
   2 distinct findings.

## Decision

1. **Parse `composer.lock` only**. JSON walk of `packages` +
   `packages-dev` arrays. Filter out `source.type == "path"` (local
   references — OSV cannot cover them). Other source types
   (`git` / `hg` / `svn` / missing) admitted; private-server
   packages naturally fail to match OSV.

2. **Reuse `packaging.version` with Composer→PEP 440 preprocessing**.
   `_normalize_composer_version` applies 5 regex substitutions
   (`-dev N` → `.devN`, `-alpha N` → `aN`, `-beta N` → `bN`,
   `-RC N` → `rcN`, `-p N` → `.postN`), plus leading `v` strip.
   Zero new dependencies.

3. **Strict basename validator**: `composer_lock_paths` entries must
   end in exactly `composer.lock` (lowercase, mirrors Cargo.lock /
   Gemfile.lock strict convention — Composer enforces this canonical
   filename).

4. **Three-tuple parser**: `parse_composer_lock` returns
   `(name, version, scope)` instead of the prior 2-tuple. Finding
   evidence gains `scope` key. First 7d ecosystem to distinguish
   prod vs dev attack surface.

5. **Mirror 7d.5 for everything else**: `OsvPackagistFetcher`
   pulling OSV-Packagist dump, 5-axis filter chain, dedup on
   (id, package), bundled `osv_packagist.json`,
   `TI-OSV-PACKAGIST-CATALOG` umbrella TI, CI guard at 15 MB cap.

## Why parse composer.lock and not composer.json

- `composer.lock` is the resolved-dependency artifact, present
  whenever `composer install` has run (i.e., in every deployed
  application).
- `composer.json` is the dependency declaration — it lists ranges
  like `"laravel/framework": "^10.0"` but doesn't fix exact resolved
  versions, so we can't directly match against OSV's
  version-specific advisories.
- Bundler's `Gemfile.lock` (7d.5) and Cargo's `Cargo.lock` (7d.3)
  set the precedent: always parse the lockfile.

## Why distinguish prod vs dev scope

- Some PHP deploy pipelines run `composer install --no-dev` so dev
  packages (phpunit, psalm, debugbar) are not present in the
  production environment.
- A `phpunit/phpunit` CVE that only affects dev-time test runs is
  meaningfully lower risk than a `monolog/monolog` CVE on the
  runtime logger.
- Other 7d ecosystems don't surface this because lockfile formats
  don't distinguish (npm package-lock.json conflates; Cargo.lock
  conflates; Bundler Gemfile.lock has group annotations but they're
  ignored by `bundle install`).
- 7d.4 Maven has comparable distinction via `scope` field (compile
  / test / runtime / provided) but did not surface it as evidence.
  7d.6 sets the precedent for future ecosystems to surface scope
  when the lockfile naturally distinguishes it.

## Consequences

- New Check (`php_supply_chain_audit`); total Checks 37 → **38**.
- New bundled DB (`osv_packagist.json`, expected 1.5-3 MB after
  5-axis filter from 8.9 MB raw).
- Future Composer CVE refresh = re-run `agentsec ioc-update` and
  re-commit `osv_packagist.json`.
- 7-language milestone reached (JS / Python / Go / Rust / Java /
  Ruby / PHP).
- Finding evidence schema gains optional `scope` key (only set by
  `php_supply_chain_audit` in v0.36.0; reports / scoring don't
  filter on it — operators triage manually).
- `parse_composer_lock` 3-tuple return sets a template for future
  scope-aware parsers in other ecosystems (gradle dev/test, npm
  dev-deps once that lockfile flag is properly parsed, etc.).

## Alternatives considered

- **Parse `composer.json`**: rejected, doesn't give exact resolved
  versions.
- **Hand-write Composer version comparator**: rejected, Composer's
  stability flags map cleanly to PEP 440 (5 lines of regex).
- **Single scope (treat dev as prod)**: rejected, would over-report
  on `composer install --no-dev` deploy pipelines.
- **Filter on `dist.url` ending in `.packagist.org`**: rejected,
  Composer 2.x uses GitHub API URLs in `dist.url` for packagist-hosted
  packages, so this heuristic is unreliable. Simpler to admit all
  non-`path` source types and let OSV's catalog naturally filter
  private-server packages (zero false positives by construction).

## References

- Spec: `docs/superpowers/specs/2026-05-17-phase-7d6-php-composer-supply-chain-design.md`
- Plan: `docs/superpowers/plans/2026-05-17-phase-7d6-php-composer-supply-chain.md`
- ADR-0012: Phase 7d npm
- ADR-0013: Phase 7d.1 pip
- ADR-0014: Phase 7d.2 go
- ADR-0015: Phase 7d.3 rust/cargo
- ADR-0024: Phase 7d.4 java/maven
- ADR-0025: Phase 7d.5 ruby/gem
- OSV Packagist ecosystem: https://osv.dev/list?ecosystem=Packagist
- Composer versions: https://getcomposer.org/doc/articles/versions.md
```

- [ ] **Step 10.2: Update pyproject.toml**

Find `version = "0.35.0"`, replace with `version = "0.36.0"`.

- [ ] **Step 10.3: Add CHANGELOG entry**

At top of `CHANGELOG.md`, above v0.35.0:

```markdown
## v0.36.0 — 2026-05-17

**Phase 7d.6 — PHP/Composer supply chain audit (7th ecosystem; completes
7-language coverage milestone).**

- New Check `php_supply_chain_audit` —
  `src/agentsec/audit/checks/php_supply_chain_audit.py`. Reads
  operator-configured composer.lock files (via `--composer-lock-path` /
  `server_audit.composer_lock_paths` config), matches each
  (package, version) against bundled `osv_packagist.json` using
  `packaging.version` (PEP 440) ranges with Composer→PEP 440 string
  preprocessing. Total Checks: 37 → **38**.
- New `OsvPackagistFetcher` —
  `src/agentsec/audit/ioc_update/fetchers/osv_packagist.py`. Pulls
  https://osv-vulnerabilities.storage.googleapis.com/Packagist/all.zip,
  5-axis filter chain, runs in parallel with the other 6 OSV
  fetchers via `asyncio.gather` (7-way).
- New bundled DB `src/agentsec/audit/ioc/osv_packagist.json` + CI
  guard `scripts/check_osv_packagist.py` (≤ 15 MB cap).
- New umbrella TI `TI-OSV-PACKAGIST-CATALOG` in `threat_intel.yaml`.
- New `parse_composer_lock` / `_safe_parse_composer_version` /
  `_is_composer_version_in_range` in `_supply_chain_common.py`.
  Walks `packages` + `packages-dev` JSON arrays, filters
  `source.type == "path"` entries, lowercases names, strips
  leading `v` from versions. Bridges Composer stability flags
  (dev/alpha/beta/RC/p) to PEP 440 via 5-rule regex preprocessing
  (zero new deps).
- New `ServerAuditConfig.composer_lock_paths` + validator (strict
  basename match: must equal `composer.lock`).
- First 7d ecosystem to surface `evidence.scope: "prod"|"dev"` so
  operators can triage CI-only vs production attack surface.
- New ADR-0026 records the design (composer.lock vs composer.json,
  packaging.version reuse, strict basename, scope distinction).
- Test count: 1791 → ~1838 (+~47 new unit tests).
- Zero changes to other 6 supply chain Checks; zero changes to
  Adapter / Judge / Scoring / Report renderer.
- **7-language coverage milestone**: JavaScript / Python / Go /
  Rust / Java / Ruby / **PHP**.

**Breaking changes**: none.
```

- [ ] **Step 10.4: ROADMAP entry**

After the existing 7d.5 entry in `ROADMAP.md`, add:

```markdown
- **Phase 7d.6** (shipped v0.36.0, 2026-05-17) — PHP/Composer supply
  chain audit. 7th ecosystem in the series; reuses packaging.version
  (PEP 440) with Composer stability-flag preprocessing; operator
  points --composer-lock-path at a Composer composer.lock. First 7d
  ecosystem to distinguish prod vs dev scope in finding evidence.
  **7-language coverage milestone**.
```

- [ ] **Step 10.5: CLAUDE.md section**

After existing `## Ruby/Gem supply chain audit (Phase 7d.5, v0.35.0)` section, add:

```markdown
## PHP/Composer supply chain audit (Phase 7d.6, v0.36.0)

- **`PhpSupplyChainAuditCheck`** in `src/agentsec/audit/checks/php_supply_chain_audit.py` reads operator-configured `composer.lock` files from `CheckContext.composer_lock_paths` (sourced from `ServerAuditConfig.composer_lock_paths`), parses the JSON format via `parse_composer_lock` (walks `packages` + `packages-dev` arrays, filters `source.type == "path"`, lowercases names, strips leading `v` from versions), and matches each (package, version) against the bundled `osv_packagist.json` using `packaging.version` (PEP 440) range matching. Emits one Finding per (package, version, advisory) match; `threat_refs=["TI-OSV-PACKAGIST-CATALOG"]`.
- **`composer.lock`** is the canonical lockfile (Composer 1.x / 2.x compatible JSON format) — `--composer-lock-path` validator enforces strict basename equality (must equal `composer.lock`, lowercase, mirroring `Cargo.lock` / `Gemfile.lock` strict convention).
- **Three-tuple parser output**: `parse_composer_lock` returns `(name, version, scope)`. `scope` is `"prod"` for `packages` array entries, `"dev"` for `packages-dev`. Finding `evidence.scope` lets operators triage CI-only vs production attack surface separately (PHP deploys often run `composer install --no-dev`). First 7d ecosystem to surface scope distinction.
- **Version comparison via PEP 440 wrapper** in `_supply_chain_common.py`. Composer stability flags map cleanly to PEP 440: `-dev`→`.devN`, `-alpha`→`aN`, `-beta`→`bN`, `-RC`→`rcN`, `-p`→`.postN`. 5-rule regex preprocessing in `_normalize_composer_version`; leading `v` / `V` stripped. Zero new deps (`packaging` already pulled in by pip ecosystem). Composer dev-branch aliases (`dev-master` / `1.x-dev`) intentionally return False from range check — they're branch names, not versions, and OSV doesn't issue advisories against dev branches.
- **Package names are case-folded to lowercase** at parse time. Packagist is case-insensitive; OSV catalog also uses lowercase.
- **Source filter**: only `source.type == "path"` is skipped. All other source types (`git` / `hg` / `svn` / missing) admitted; private-server (Satis) packages naturally fail to match OSV-Packagist catalog (zero false positives by construction, no `dist.url` heuristic needed).
- **`OsvPackagistFetcher`** mirrors `OsvRubyGemsFetcher` (5-axis filter chain) but pulls `https://osv-vulnerabilities.storage.googleapis.com/Packagist/all.zip`. Runs as a side pipeline (`_run_osv_packagist`, parallel to npm/pypi/go/cargo/maven/rubygems via `asyncio.gather` 7-way).
- **OSV ecosystem string is `"Packagist"`** (PascalCase, OSV convention).
- **`scripts/check_osv_packagist.py`** CI guard enforces valid JSON + ≤ 15 MB hard cap (mirrors npm/pypi/go/cargo/maven/rubygems).
- **Bundled DB**: `src/agentsec/audit/ioc/osv_packagist.json` (~1.5-3 MB; OSV-Packagist raw bundle is 8.9 MB, largest in the 7d series, filter ratio ~20-35%).
- **`agentsec server-audit --composer-lock-path <path>`** is repeatable on the standalone CLI; for the `evaluate` flow set `server_audit.composer_lock_paths` in `openclaw-target.yaml`.
- **Total Checks (v0.36.0):** 37 → **38 类**.
- **7-language coverage milestone**: JavaScript (7d) / Python (7d.1) / Go (7d.2) / Rust (7d.3) / Java (7d.4) / Ruby (7d.5) / **PHP (7d.6)**.
- **Adding an 8th ecosystem** (.NET/nuget, swift/spm, dart/pub, hex/erlang): pattern is fully mature — new Check `<eco>_supply_chain_audit` + `osv_<eco>.json` DB + `Osv<Eco>Fetcher` + `TI-OSV-<ECO>-CATALOG`. Version comparator strategy depends on ecosystem: semver-compatible (swift/spm) can reuse `semver.Version`; PEP-440-adjacent (composer / rubygems) extends the `packaging.version` wrapper pattern; bespoke (nuget) may need a hand-written comparator like Maven's.

Spec: `docs/superpowers/specs/2026-05-17-phase-7d6-php-composer-supply-chain-design.md`.
Plan: `docs/superpowers/plans/2026-05-17-phase-7d6-php-composer-supply-chain.md`.
```

- [ ] **Step 10.6: Full pytest + lint + CI guards**

```
cd /Users/roger/Work/AgentSec && .venv/bin/pytest tests/ -q 2>&1 | tail -3
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_packagist.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_rubygems.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_osv_maven.py
cd /Users/roger/Work/AgentSec && .venv/bin/python scripts/check_owasp_coverage.py
cd /Users/roger/Work/AgentSec && .venv/bin/ruff check src/ tests/ 2>&1 | tail -3
```
Expected: pytest ~1838 PASS / 9 skipped; all check_osv_*.py PASS; check_owasp_coverage.py PASS; ruff clean.

- [ ] **Step 10.7: Single commit**

```bash
cd /Users/roger/Work/AgentSec && git add docs/adr/0026-phase-7d6-php-composer-supply-chain.md CHANGELOG.md ROADMAP.md CLAUDE.md pyproject.toml && git commit -m "$(cat <<'EOF'
feat(7d.6): ADR-0026 + v0.36.0 docs

Records design decisions for Phase 7d.6 (PHP/Composer supply chain
audit, 7th ecosystem in the series): parse composer.lock (not
composer.json); reuse packaging.version (PEP 440) with 5-rule
Composer stability-flag preprocessing (zero new deps); strict
basename validator (composer.lock canonical lowercase); first 7d
ecosystem to surface prod/dev scope in finding evidence. CHANGELOG
+ ROADMAP + CLAUDE.md + pyproject bumped to v0.36.0. **7-language
coverage milestone reached** (JS/Python/Go/Rust/Java/Ruby/PHP).

Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>
EOF
)"
```

---

## Task 11: Final review

Dispatch a final reviewer subagent (sonnet, with `<400 words` length cap per 7c.1.y/z lesson) to verify:

- 7 supply chain Check + fetcher templates mirrored consistently
- `parse_composer_lock` handles `packages` + `packages-dev` arrays, `source.type=="path"` filter, lowercase name, v-prefix strip
- `_is_composer_version_in_range` handles all 5 stability flags (dev/alpha/beta/RC/p), v-prefix strip, dev-branch aliases (unparseable returns False)
- Three-tuple parser output flows correctly: `evidence.scope` present in findings; same (pkg, version) in both `packages` + `packages-dev` emits 2 distinct findings (different scope, different fingerprint)
- `osv_packagist.json` size reasonable (1.5-3 MB expected); CI guard PASS
- All ~47 new unit tests PASS; baseline 1791 still PASS
- ADR-0026 cites correct prior ADRs (0012/0013/0014/0015/0024/0025) and explains decisions (scope distinction is the most novel)
- CHANGELOG / ROADMAP / CLAUDE.md / pyproject all consistent v0.36.0
- No regressions to other 6 ecosystems
- ID conventions (`composer_lock_paths`, `TI-OSV-PACKAGIST-CATALOG`, ecosystem string `Packagist`, check id `php_supply_chain_audit`) consistent

Report APPROVED / NEEDS_FIX with concise blocking issues.

---

## Self-Review Notes

**Spec coverage check**:

| Spec section | Task |
|---|---|
| §2 v1: php_supply_chain_audit.py | Task 7 |
| §2 v1: osv_packagist.py fetcher | Task 3 |
| §2 v1: _supply_chain_common.py extensions | Task 1 |
| §2 v1: osv_packagist.json | Task 9 |
| §2 v1: check_osv_packagist.py | Task 4 |
| §2 v1: ServerAuditConfig.composer_lock_paths + CheckContext | Task 2 |
| §2 v1: CLI --composer-lock-path | Task 8 |
| §2 v1: TI-OSV-PACKAGIST-CATALOG | Task 6 |
| §2 v1: ioc-update _run_osv_packagist 7-way | Task 5 |
| §2 v1: ADR-0026 | Task 10.1 |
| §2 v1: CHANGELOG/ROADMAP/CLAUDE.md/pyproject | Tasks 10.2-10.5 |
| §3.1 composer.lock format + parser | Task 1 |
| §3.2 PEP 440 wrapper + 5-rule preprocessing | Task 1 |
| §3.3 OsvPackagistFetcher | Task 3 |
| §3.4 Check structure + 3-tuple + scope | Task 7 |
| §3.5 TI entry | Task 6 |
| §3.6 _run_osv_packagist CLI wiring | Task 5 |
| §6 testing | Tasks 1, 2, 3, 7 (~47 tests) |
| §7 compatibility / DB build | Task 9 |

All spec sections covered.

**Placeholder scan**: Tasks 3 / 7 / 8 instruct implementer to "inspect 7d.5 template and substitute" — this is an explicit dependency on shipped 7d.5 files as canonical reference, not a placeholder. Implementer should `cat` / `grep` to retrieve the literal code.

**Type consistency**: `composer_lock_paths` used uniformly (config / CheckContext / CLI flag / validator). `TI-OSV-PACKAGIST-CATALOG` uniform. `osv_packagist.json` filename uniform. `parse_composer_lock` 3-tuple return type used in both Task 1 helper signature and Task 7 Check loop unpacking.

**Critical invariants** (commit ordering): Tasks 1-8 add code without DB; Task 9 builds DB and runs full pytest (catches integration regressions); Task 10 finalizes docs.

**New-vs-7d.5 deltas** (highest cognitive cost for the implementer):
1. **3-tuple parser** — `parse_composer_lock` returns `(name, version, scope)` not `(name, version)`. Easy to miss in Task 7 loop unpacking — the FAIL signature will be `ValueError: not enough values to unpack` if the implementer accidentally uses the 2-tuple gem template literally.
2. **JSON parsing** — `composer.lock` is JSON, not text. The Bundler regex pattern from 7d.5 must be replaced entirely with `json.loads`.
3. **5-rule preprocessing** — Composer normalization is more involved than RubyGems (5 stability flags + v-prefix vs 3 RubyGems suffixes). Verify all 5 mappings in the test suite (test_normalize_stability_mapping).

---

## Post-Implementation Verification

After all 11 tasks land, run on `main`:

```bash
.venv/bin/pytest tests/
.venv/bin/python scripts/check_osv_packagist.py
.venv/bin/python scripts/check_osv_rubygems.py
.venv/bin/python scripts/check_osv_maven.py
.venv/bin/python scripts/check_owasp_coverage.py
.venv/bin/ruff check src/ tests/
git log --oneline -12
git status
.venv/bin/agentsec server-audit --help | grep composer
```

Expected:
- pytest: ~1838 PASS / 9 skipped
- check_osv_packagist.py: PASS
- check_osv_rubygems.py: PASS (no regression)
- check_osv_maven.py: PASS (no regression)
- check_owasp_coverage.py: PASS
- ruff: clean
- git log: 10+ new commits at HEAD
- git status: clean
- `--composer-lock-path` in help

If pytest count drifts beyond +~47, investigate.
