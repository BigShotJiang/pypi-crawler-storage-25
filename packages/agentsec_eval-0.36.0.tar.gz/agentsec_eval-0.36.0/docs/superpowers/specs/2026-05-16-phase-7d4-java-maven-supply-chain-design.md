# Phase 7d.4 — Java/Maven supply chain audit 设计

**状态**: 草案
**日期**: 2026-05-16
**前置**: Phase 7d.3（v0.15.0，Rust/Cargo supply chain audit）
**目标版本**: v0.34.0

## 1. 背景与动机

7d series 已 ship 4 个 ecosystem supply chain Check：

| Phase | Ecosystem | Version | DB |
|---|---|---|---|
| 7d | npm | v0.12.0 | osv_npm.json |
| 7d.1 | pip | v0.13.0 | osv_pypi.json |
| 7d.2 | go | v0.14.0 | osv_go.json |
| 7d.3 | rust/cargo | v0.15.0 | osv_cargo.json |

Java/Maven 是企业 Java 应用最主流的 supply chain 生态，覆盖价值高。
7d.4 引入第 5 个 ecosystem `Maven` Check，模式与 7d.3 镜像，但
Maven 有两个 ecosystem-specific 处理点：

1. **无原生 lockfile** —— pom.xml 是声明式（含 version range、未解析
   transitive），不能直接作为"已解析依赖列表"使用。操作员需预先运行
   `mvn dependency:list` 生成扁平依赖列表文件。
2. **Maven 版本不是 semver** —— 有 `alpha/beta/milestone/rc/snapshot/sp`
   等限定符 + 数字/字母混排，比较语义遵循 Apache `ComparableVersion`
   规范。前 4 个 ecosystem 用 stdlib (`packaging`) 或 `semver` lib；
   Maven 需手写 ~100 行 comparator。

## 2. 范围

**v1 包含**：

- 新 Check `src/agentsec/audit/checks/java_supply_chain_audit.py`
  —— `JavaSupplyChainAuditCheck`，镜像 `RustSupplyChainAuditCheck`
- 新 fetcher `src/agentsec/audit/ioc_update/fetchers/osv_maven.py`
  —— `OsvMavenFetcher`，镜像 `OsvCargoFetcher`
- `src/agentsec/audit/checks/_supply_chain_common.py` 添加：
  - `parse_maven_dependency_list(text) -> list[(coord, version)]`
  - `_compare_maven_version(v1, v2) -> int` (Maven ComparableVersion)
  - `_is_maven_version_in_range(version, introduced, fixed) -> bool`
- 新 DB `src/agentsec/audit/ioc/osv_maven.json`（首次 `agentsec
  ioc-update` build 后人工 commit）
- 新 CI guard `scripts/check_osv_maven.py` —— JSON + 15MB 上限
- `src/agentsec/config.py:ServerAuditConfig` 加 `maven_lock_paths:
  list[str]` + path validator
- `src/agentsec/audit/__init__.py:CheckContext` 加 `maven_lock_paths`
- `src/agentsec/cli.py`：`server-audit` + `evaluate` 加
  `--maven-lock-path` 可重复
- `src/agentsec/audit/ioc/threat_intel.yaml` 加 `TI-OSV-MAVEN-CATALOG`
  伞 entry（auto_refresh: false）
- `src/agentsec/audit/ioc_update/cli.py` 加 `_run_osv_maven`，与
  npm/pypi/go/cargo 通过 `asyncio.gather` 并行 5-way
- ADR-0024 + CHANGELOG / ROADMAP / CLAUDE.md / pyproject v0.34.0
- 新 unit tests（~20 case，详 §7）

**v1 不包含**（明确延后）：

- **Gradle 支持** —— 独立 phase 7d.4.1。build.gradle / build.gradle.kts /
  gradle.lockfile 是另一个生态文件树
- **`mvn` 子进程调用** —— 不跑 mvn；操作员预产 `mvn-deps.txt`
- **pom.xml 直接解析** —— pom.xml 是声明式，含 range / 未解析 transitive，
  覆盖不完整且误报多
- **判官 / scoring / report renderer 改动** —— 纯新增 Check，沿现 finding 模型
- **MCP / OWASP coverage gate 改动** —— 与 supplements 系列正交

## 3. 设计

### 3.1 输入格式与解析

**操作员预先运行**：
```bash
mvn dependency:list -DexcludeTransitive=false -DoutputFile=mvn-deps.txt
```

产出文件行格式（mvn 输出含 `[INFO]` 前缀与缩进）：
```
[INFO]    org.apache.commons:commons-lang3:jar:3.12.0:compile
[INFO]    com.google.guava:guava:jar:31.1-jre:compile
[INFO]    org.springframework:spring-core:jar:5.3.20:provided
[INFO]    org.junit.jupiter:junit-jupiter-api:jar:5.8.2:test
```

**`parse_maven_dependency_list(text: str) -> list[tuple[str, str]]`**
在 `_supply_chain_common.py`：

- 逐行处理；匹配 `<groupId>:<artifactId>:<type>:<version>:<scope>` 5 段
  冒号格式（type 通常 `jar` / `pom` / `war`；可忽略）
- 静默跳过：`--- ` / `BUILD ` / 空行 / 不符合 5 段格式的行
- 跳过 scope == `system` 或 `none`（系统库无 CVE 意义）
- **包含 scope ∈ {compile, runtime, provided, test}** —— test 也是攻击面
  （恶意测试依赖能在 CI 跑时反弹）
- 返回 `[(coordinate, version), ...]`，coordinate = `groupId:artifactId`
  （Maven 是 case-sensitive，原样保留）

**路径验证** `ServerAuditConfig.maven_lock_paths`：

- 必须 `/` 或 `~/` 开头
- 无 shell metachar（`contains_shell_metachar` 复用）
- basename suffix 宽容集：`.txt` / `.list` / `-deps.txt` / `-list.txt`
  / `dependency-list.txt`
- 不锁特定文件名（vs Cargo.lock 严格匹配），因 Maven 文件名操作员定

### 3.2 Maven `ComparableVersion` 比较器

放在 `_supply_chain_common.py:_compare_maven_version(v1, v2) -> int`。
返回 -1/0/1。

**算法**（严对应 Apache Maven `ComparableVersion`）：

1. **Tokenize** —— 把 version 字符串拆成 items：
   - 分隔符：`.` / `-` / 数字↔字母转换处（如 `1.0a1` → `1, 0, a, 1`）
   - `-` 触发 nested sub-list（如 `1.0-alpha-1` → `[1, 0, [alpha, [1]]]`）
2. **三种 item 类型**：
   - **`IntegerItem`** —— 纯数字，按数字比较
   - **`StringItem`** —— 字母段，特殊 qualifier 优先级表：
     ```python
     QUALIFIERS = {
         "alpha": -5, "a": -5,
         "beta": -4, "b": -4,
         "milestone": -3, "m": -3,
         "rc": -2, "cr": -2,
         "snapshot": -1,
         "": 0, "final": 0, "ga": 0, "release": 0,
         "sp": 1,
     }
     # 未知 qualifier → 字典序，比 "sp" 大（即 > 1）
     ```
   - **`ListItem`** —— 嵌套，遇 `-` 时开
3. **Compare item-by-item**：
   - 类型 mismatch 规则：integer > string (no qualifier); integer > list;
     list > string
   - 较短列表 padding 用 zero item（normalize `1.0 == 1.0.0`）
4. **Normalize trailing zeros** —— 构造时 trim 末尾 zero items

**`_is_maven_version_in_range(version, introduced, fixed) -> bool`**：
`compare(introduced, version) <= 0 and compare(version, fixed) < 0`。

**测试覆盖** (§7 详)：
- `1.0 == 1.0.0`
- `1.0-SNAPSHOT < 1.0`
- `1.0-alpha-1 < 1.0-beta-1 < 1.0-rc-1 < 1.0-SNAPSHOT < 1.0`
- `1.0-SP1 > 1.0`
- `1.0-foo > 1.0`（未知 qualifier 在已知后）
- `1.0-alpha-1 < 1.0-alpha-2`
- `2.0 > 1.99`
- `1.0a1 < 1.0`（alpha 简写等价 `1.0-alpha-1`）

### 3.3 OSV-Maven Fetcher

`src/agentsec/audit/ioc_update/fetchers/osv_maven.py:OsvMavenFetcher`：

- 拉 `https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip`
- ZIP 解压，遍历每个 JSON entry
- `normalize_osv_entry` **5 轴 filter** 链（与 npm/pypi/go/cargo 同）：
  1. drop withdrawn
  2. drop no Maven affected
  3. drop no range
  4. drop no CVSS_V3 scored
  5. drop scored medium-low > 2 years old
- **Multi-affected expansion** —— 每个 Maven package 一条独立 record；
  caller dedups on `(id, package)`
- 输出 `.cache/ioc-update-<date>/proposed-osv_maven.json`
- 复用 `_supply_chain_common.py` 中 `severity_from_cvss_score` /
  `_is_within_age` / `_extract_severity` helpers

### 3.4 `JavaSupplyChainAuditCheck` 结构

`src/agentsec/audit/checks/java_supply_chain_audit.py` 镜像
rust_supply_chain_audit.py：

```python
class JavaSupplyChainAuditCheck(Check):
    id = "java_supply_chain_audit"
    description = "Detect known CVEs in Maven-declared dependencies"

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not ctx.maven_lock_paths:
            ctx.status.not_applicable("no maven_lock_paths configured")
            return []

        # dynamic allowed_paths injection (mirrors pip/go/cargo)
        ctx.policy.add_runtime_allowed_paths(ctx.maven_lock_paths,
                                             kind="exact")

        # load advisory DB once
        db = load_advisory_db("osv_maven.json")

        findings = []
        for path in ctx.maven_lock_paths:
            content = await ctx.read_file(path)  # via SSH
            deps = parse_maven_dependency_list(content)
            for coord, version in deps:
                for advisory in db.get(coord, []):
                    for range_ in advisory["ranges"]:
                        if _is_maven_version_in_range(
                            version, range_["introduced"], range_["fixed"]
                        ):
                            findings.append(self.make_finding(
                                ctx,
                                severity=advisory["severity"],
                                title=f"Maven CVE: {advisory['id']} in {coord} {version}",
                                description=advisory["summary"],
                                evidence={
                                    "coord": coord, "version": version,
                                    "advisory_id": advisory["id"],
                                    "fixed_in": range_["fixed"],
                                    "lock_path": path,
                                },
                                threat_refs=["TI-OSV-MAVEN-CATALOG"],
                            ))
        return findings
```

### 3.5 threat_intel.yaml 伞 entry

```yaml
- id: TI-OSV-MAVEN-CATALOG
  source: osv.dev (Maven ecosystem)
  claim: "Aggregated CVE catalog for Maven (Java) packages, sourced from OSV."
  confidence: high
  mapped_tests: [java_supply_chain_audit]
  note: |
    Umbrella TI for all Maven CVE matches. Per-CVE advisory id surfaces
    directly in finding evidence (evidence.advisory_id). Refreshed via
    `agentsec ioc-update`.
  auto_refresh: false
```

### 3.6 `_run_osv_maven` 在 ioc-update CLI

`src/agentsec/audit/ioc_update/cli.py`：

```python
async def _run_osv_maven(ctx, ...):
    fetcher = OsvMavenFetcher(...)
    records = await fetcher.run(ctx, ...)
    write_json(".cache/ioc-update-<date>/proposed-osv_maven.json", records)

# main:
await asyncio.gather(
    _run_osv_npm(ctx, ...),
    _run_osv_pypi(ctx, ...),
    _run_osv_go(ctx, ...),
    _run_osv_cargo(ctx, ...),
    _run_osv_maven(ctx, ...),  # NEW, 5-way parallel
)
```

## 4. 集成 / 不变量

| 切面 | 改动 |
|---|---|
| `src/agentsec/audit/checks/java_supply_chain_audit.py` | **新增** |
| `src/agentsec/audit/checks/_supply_chain_common.py` | 加 maven parser + comparator + range matcher |
| `src/agentsec/audit/ioc_update/fetchers/osv_maven.py` | **新增** |
| `src/agentsec/audit/ioc_update/cli.py` | 加 `_run_osv_maven` + 5-way gather |
| `src/agentsec/audit/ioc/osv_maven.json` | **新增**（首次 ioc-update build） |
| `src/agentsec/audit/ioc/threat_intel.yaml` | 加 TI-OSV-MAVEN-CATALOG entry |
| `scripts/check_osv_maven.py` | **新增** |
| `src/agentsec/config.py:ServerAuditConfig` | 加 `maven_lock_paths` + validator |
| `src/agentsec/audit/__init__.py:CheckContext` | 加 `maven_lock_paths` |
| `src/agentsec/cli.py` | `server-audit` + `evaluate` 加 `--maven-lock-path` 可重复 |
| `tests/` | 新 ~20 unit test (详 §7) |
| `docs/adr/0024-phase-7d4-java-supply-chain.md` | **新增** |
| `CLAUDE.md` / `CHANGELOG.md` / `ROADMAP.md` / `pyproject.toml` | v0.34.0 |

**关键不变量**：

- 7d (npm) / 7d.1 (pip) / 7d.2 (go) / 7d.3 (rust) 行为零变化
- Adapter / Judge / Scoring / Report renderer 零改动
- MCP coverage gate 不动（floor 仍 14）
- 既有 1707 test pass 不变（新加 ~20，total ~1727）
- 总 Check 数：35 → **36 类**（v0.20.0 为 35）

## 5. 错误处理

| 场景 | 处理 |
|---|---|
| `maven_lock_paths` 为空 | `not_applicable("no maven_lock_paths configured")` |
| 文件不存在 | `ctx.read_file` 现有异常路径 |
| 文件解析失败 / 全空 deps | finding 列表为空，info 级别 log "no parseable deps in <path>" |
| `osv_maven.json` 缺失 | Check raise；CI guard 防止部署时缺失 |
| Maven 版本字符串无法 tokenize | 跳过该 (coord, version)，log warning，继续 |
| Path 校验失败 (shell metachar / 非 / 或 ~/ 开头) | Pydantic validator raise，CLI 错前置 |
| OSV-Maven fetch HTTP fail | Fetcher 现有 retry/fail 路径，与 osv_cargo 同 |

## 6. 测试策略

**单测**（~20 case）：

- `test_compare_maven_version.py` ~10 case 覆盖 §3.2 边缘
- `test_parse_maven_dependency_list.py` ~5 case（正常 / `[INFO]` 前缀 /
  scope filter / 注释 / 空行 / 不规则）
- `test_java_supply_chain_audit.py` ~5 case（empty paths /
  no match / match found / multi-version / advisory range edge）
- `test_osv_maven_fetcher.py` ~3 case（mock httpx, sample OSV entry
  round-trip）

**集成测**：沿 7d.3 约定，无新 integration test。

**CI gates**:
- `pytest tests/` —— 现有 + 新 ~20，total ~1727 pass
- `scripts/check_osv_maven.py --check` —— JSON 合法 + ≤ 15 MB
- `scripts/check_owasp_coverage.py` —— 不动（与本 phase 正交）
- `ruff check src/ tests/` —— 新代码符合现有 lint

**OSV-Maven DB 首次 build**：Task 12 跑 `NVD_API_KEY=... GITHUB_TOKEN=...
.venv/bin/agentsec ioc-update`（live HTTP），人工 review proposed-osv_maven.json
后 commit 到 `src/agentsec/audit/ioc/osv_maven.json`。CI 不跑 live HTTP。

## 7. 兼容性与迁移

- **现有 ecosystems**：4 个 supply chain Checks 独立运行，互不影响
- **`ServerAuditConfig`**：新增 `maven_lock_paths` 字段，默认 `[]`；
  现有 config 文件无需改动（向后兼容）
- **CLI**：`--maven-lock-path` 是新 optional flag，不传则 Check `not_applicable`
- **OSV-Maven DB 大小预估**：参考 osv_pypi (3452 entries, 949 KB) 与
  osv_cargo (1396 entries, 545 KB)。Maven 生态规模介于两者之间，预估
  1500-3000 entries，500 KB–1.2 MB。15 MB 上限充足。

## 8. 决策摘要

| 决策点 | 选择 | 理由 |
|---|---|---|
| 输入格式 | 操作员预跑 `mvn dependency:list -DoutputFile=mvn-deps.txt` | 与 pip 同模式；含 transitive；解析最简 |
| 版本比较 | 手写完整 Maven ComparableVersion | ~100 行，零新依赖，安全场景宁可正确不可漏 |
| Scope 过滤 | 包含 compile/runtime/provided/test，跳 system/none | test 也是攻击面 |
| 路径验证 | 宽容 `.txt`/`.list`/`-deps.txt`，无 shell metachar | 文件名操作员定 |
| Coordinate 规范 | `groupId:artifactId` 大小写保持 | Maven 是 case-sensitive |
| OSV ecosystem | `Maven`（精确大小写） | OSV 规范 |
| Filter 链 | 5 轴（withdrawn / no Maven affected / no range / no CVSS / scored medium-low > 2y） | 与 npm/pypi/go/cargo 完全同 |
| DB 上限 | 15 MB | 与四 ecosystem 同 |
| Gradle 支持 | **不在 v1** | 独立 phase 7d.4.1 |
| `mvn` 子进程 | **不调用** | 操作员预产文件 |
| pom.xml 解析 | **不实现** | 含 range / 未解析 transitive |
| ADR | 新写 ADR-0024 | 与 7d.1/2/3 同步留痕 |

## 9. 后续阶段路线

| 阶段 | 范围 | 依赖 |
|---|---|---|
| **7d.4（本期）** | java/maven supply chain（5 ecosystem Checks 全集） | 7d.3 |
| 7d.4.1（潜在） | Gradle 支持（build.gradle.kts 解析 + gradle.lockfile） | 7d.4 |
| 7d.5（潜在） | 第 6 个生态（ruby/gem 或 swift/spm） | 7d.4 |

## 10. References

- ADR-0012 —— Phase 7d npm supply chain（最早）
- ADR-0013 —— Phase 7d.1 pip
- ADR-0014 —— Phase 7d.2 go
- ADR-0015 —— Phase 7d.3 rust/cargo
- ADR-0024（本 phase 新增）—— Phase 7d.4 java/maven
- Apache Maven ComparableVersion 规范 —— https://maven.apache.org/ref/3.6.3/maven-artifact/apidocs/org/apache/maven/artifact/versioning/ComparableVersion.html
- OSV Maven ecosystem dump —— https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip
- 既有 supply chain 模板 —— `src/agentsec/audit/checks/rust_supply_chain_audit.py` + `src/agentsec/audit/ioc_update/fetchers/osv_cargo.py`
- 既有 common 层 —— `src/agentsec/audit/checks/_supply_chain_common.py`
