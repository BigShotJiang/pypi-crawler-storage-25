# Phase 7e.2 — Linux 主机防火墙 Check 设计

**日期**：2026-05-09
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0011；前置 ADR-0009（7e.1）。

## 1. 目标

`agentsec server-audit` 在 Phase 7e / 7e.1 落地了 8 类主机加固 Check
（sysctl / sshd / sudoers / SUID + world-writable / auditd / systemd
service blacklist / systemd unit lint），覆盖 OS 内核 + sshd + sudoers
+ SUID 漂移 + 文件权限 + 审计子系统 + systemd。Phase 7e.1 spec 明确
把 firewall 推后到 7e.2，原因是「三后端工作量 ≈ 7e 总和」。

7e.2 一波覆盖 Linux 三大主流 firewall 后端的「默认策略 + 后端激活
+ IPv6 平行检查」。本 spec 描述这一波 3 个新 Check + 1 个 helper
模块 的设计。

## 2. 范围

新增 3 个 Check，全部沿用现有 `Check` ABC 模式，按后端拆分（与 Phase 7f
Docker 三 Check 同构）：

| Check 类 | id | 主命令 | Finding 粒度 |
|---|---|---|---|
| `IptablesAuditCheck` | `iptables_audit` | `iptables -S` + `ip6tables -S` | 每条违规默认策略 1 条 finding（v4/v6 各算独立） |
| `NftablesAuditCheck` | `nftables_audit` | `nft -j list ruleset` | 每个 hooked chain 违规 1 条 finding；ruleset 全空 1 条 |
| `UfwAuditCheck` | `ufw_audit` | `ufw status verbose` | inactive 1 条；默认策略每方向 1 条 |

**首期审计点**（A + B + C）：

- **A. 默认策略**：INPUT/FORWARD 默认 = ACCEPT 视作 critical / high。
- **B. 后端激活状态**：ufw inactive、nft ruleset 完全空 视作 critical。
- **C. IPv6 平行检查**：`ip6tables` / nftables `inet/ip6` 表的默认策略，
  避免「v4 锁死、v6 大开」。**ufw 的 IPv6 状态推后到 7e.5**——
  `ufw status verbose` 不直接输出 IPv6 字段（实际状态在 `/etc/default/ufw`
  里），而本 phase 不读 ufw 配置文件。`ufw allow` 默认同时写 v4/v6 链，
  raw iptables/nftables 的 IPv6 family 检查能间接覆盖手动差异。

**out of scope**：

- **firewalld**（CentOS / RHEL 系，依赖 D-Bus 与 zone 模型，单独 phase 7e.3）。
- **macOS pfctl**（不同安全模型，单独 phase 7e.4）。
- **审计点 D / E / F / G**：日志规则 / 危险 ACCEPT 与 0.0.0.0/0 / 状态
  跟踪 / 双轨冲突（ufw enabled 旁挂 raw nft 规则）—— 候选放 7e.5。
- **sudo policy 类型**：作为跨切面话题独立讨论，不绑定 7e.x。

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  _firewall_common.py            # 新 — detect_iptables/nft/ufw、output_managed_by_ufw
  iptables_audit.py              # 新
  nftables_audit.py              # 新
  ufw_audit.py                   # 新
  linux_hardening_baseline.yaml  # 现有，追加 firewall section
src/agentsec/audit/ssh_policy.yaml         # 现有，扩 ~12 处
src/agentsec/audit/ioc/threat_intel.yaml   # 现有，追加 1 条 TI-LINUX-CIS-FIREWALL
src/agentsec/cli.py                        # 现有，注册点两处各 +3 行
tests/test_iptables_audit.py
tests/test_nftables_audit.py
tests/test_ufw_audit.py
tests/test_firewall_common.py              # 新 helper 单测
tests/fixtures/firewall/                   # 新目录
  iptables_default_drop_v4.txt
  iptables_default_accept_v4.txt
  iptables_with_ufw_chains.txt
  ip6tables_default_accept.txt
  nft_ruleset_drop.json
  nft_ruleset_accept.json
  nft_ruleset_with_ufw.json
  ufw_active_default_deny.txt
  ufw_active_default_allow.txt
  ufw_inactive.txt
docs/adr/0011-phase-7e2-firewall-audit.md  # 新 ADR
```

新增文件：4 (Check + helper) + 4 (test) + 10 (fixture) + 2 (ADR/spec) = 20。

### 3.2 平台 gating

3 个 Check 都在 `run()` 顶部判断
`ctx.profile.name in ("linux", "linux_user_mode")`，
非 Linux profile 标 `not_applicable` 直接返。

后续每个 Check 还会做一次 backend 探测（§3.4），未装即 `not_applicable`。

### 3.3 `_REQUIRED_PATHS`

3 个 Check 都设为 `()`（OS 级，不走 OpenClaw 路径门），与 7e/7e.1 一致。

### 3.4 Backend 探测 + 串扰回避（核心，方案 A 落地）

`_firewall_common.py` 暴露 4 个**纯函数**（与 `_docker_common.py:detect_docker`
同构），每个 Check 在 `run()` 顶部调用，命中即跑、未命中标 `not_applicable`：

```python
def detect_iptables(ctx) -> str | None
def detect_nft(ctx)      -> str | None
def detect_ufw(ctx)      -> str | None
def output_managed_by_ufw(stdout: str, *, backend: str) -> bool
```

**探测语义**（与 `detect_docker` 一致）：依次 `stat -c %n` 候选路径，
第一个 0-退出码命中即返。候选：

- iptables: `/usr/sbin/iptables` / `/sbin/iptables` / `/usr/bin/iptables`
- nft:      `/usr/sbin/nft` / `/sbin/nft` / `/usr/bin/nft`
- ufw:      `/usr/sbin/ufw` / `/sbin/ufw` / `/usr/bin/ufw`

**`run()` 顶部模板（每 Check 同构）**：

```python
async def run(self, ctx):
    if ctx.profile.name not in ("linux", "linux_user_mode"):
        ctx.status.not_applicable("非 Linux profile")
        return []
    bin_path = detect_<backend>(ctx)
    if bin_path is None:
        ctx.status.not_applicable("<backend> 未安装")
        return []
    # —— 跑命令、解析、判定 ——
```

**串扰回避（方案 A 实施细节）**：在 Ubuntu 上 ufw 启用时，`iptables -S`
会展示 ufw 自己注入的 `ufw-*` 链；这时 `INPUT` 默认 policy 经常仍是
ACCEPT（因为实际拦截在 ufw 链尾的 `-j ufw-reject-input`）。如果三个
Check 完全独立判，`iptables_audit` 与 `nftables_audit` 会就同一台
机器误报「默认 ACCEPT」。

- `iptables_audit`：拉到 `iptables -S` stdout 后，先调
  `output_managed_by_ufw(stdout, backend="iptables")`。该 helper 检测
  三种 ufw 注入痕迹（任一命中即真）：
  1. 含 `-N ufw-` / `-A ufw-` 行（ufw 自建链）
  2. 含 `-A INPUT -j ufw-before-input` / `-A INPUT -j ufw-reject-input`
     （hook 行）
  3. 含 `[ufw` 注释（ufw 默认带的注释 tag）

  命中 → 标 `not_applicable("ufw 已接管 iptables，由 ufw_audit 评估")`，
  **不**报默认策略 finding。

- `nftables_audit`：解析 `nft -j list ruleset` 的 JSON 后，先看顶层
  `nftables[].table` 中是否有 `name="ufw"` 表，或链注释含 `ufw-`。
  命中 → 同上。

- `ufw_audit`：完全独立，只看 `ufw status verbose`。

### 3.5 权限不足判定

所有命令在以下任一条件触发 `skipped`（与 best-effort 策略一致）：

- exit_code != 0 且 stderr 含 `permission denied` / `Operation not permitted`
  / `must be root` / `you need to be root`（小写归一后子串匹配）。
- iptables 非 root 时常返 `exit_code=4` + `Permission denied`，nft 非 root
  返 `exit_code=1` + `Operation not permitted`，ufw 返
  `ERROR: You need to be root` —— 上述 substring 集合覆盖。

remediation 文案统一：「在该主机为执行用户配置 NOPASSWD sudoers，
或以 root 身份运行 agentsec server-audit」。本 phase 不引入 sudo 类型
的 ssh_policy 扩展。

### 3.6 baseline 文件结构

`linux_hardening_baseline.yaml` 在原 7 段（4 个 7e + 3 个 7e.1）下追加
1 段：

```yaml
firewall:                    # 7e.2
  rationale: 默认接收策略 / 后端未激活 / IPv6 平行漏洞 — CIS Linux 加固基线
  remediation: 设置 INPUT/FORWARD 默认策略为 DROP；启用 ufw / 装 nftables 规则；同步配置 IPv6
```

8 个顶层 section（4 旧 + 3 个 7e.1 + 1 个 7e.2）。baseline 段刻意精简
——三个 Check 的判定阈值是「policy ∈ {DROP,REJECT}」这种不可调的硬
规则，不需要参数化数据驱动。section 主要承载 rationale / remediation
文案，被 3 个 Check 共享。

## 4. 组件细节

### 4.1 `IptablesAuditCheck`（`iptables_audit`）

**命令序列**（每个独立 `SSHExecutor.run`；任一被 reject → 整体 `skipped`）：

1. `iptables -S` — IPv4 全规则 dump（含默认策略行 `-P INPUT ACCEPT` 之类）。
2. `ip6tables -S` — IPv6 全规则 dump，与 (1) 同形态。

**解析**（evaluator 端纯 Python helper）：

```python
def parse_iptables_default_policies(stdout: str) -> dict[str, str]:
    """从 'iptables -S' 输出抓 -P <CHAIN> <POLICY> 行。
       返回 {'INPUT': 'ACCEPT', 'FORWARD': 'DROP', 'OUTPUT': 'ACCEPT'}."""
```

**判定**：对 `INPUT` / `FORWARD` 两条链，policy != `DROP` 且 != `REJECT`
→ 1 条 finding。`OUTPUT` 默认 ACCEPT 是常规姿态，**不审**。IPv4 + IPv6
各跑一遍，`evidence` 内带 `family` 区分。

**Finding 模板**：

```
title:    "iptables {family} {chain} 默认策略为 {policy}（应为 DROP/REJECT）"
severity: critical （chain=INPUT 或 family=ipv6）
          high     （chain=FORWARD 且 family=ipv4）
evidence: { family: ipv4|ipv6, chain: INPUT|FORWARD, policy: ACCEPT, dump_sha256: ... }
threat_refs: ["TI-LINUX-CIS-FIREWALL"]
```

**预期最大 finding 数**：4（INPUT/FORWARD × v4/v6）。

**IPv6 部分失败不污染 IPv4 判定**：用两个独立 `executor.run` 调用，
两个 `try`-block 独立处理，`ctx.status` 仅在两条都失败时才置 `skipped`；
任一成功即 `set_ok` 并发对应 family 的 finding。

### 4.2 `NftablesAuditCheck`（`nftables_audit`）

**命令**：单条 `nft -j list ruleset`（JSON 输出，机器友好）。

**解析**：标准库 `json.loads` 后遍历 `nftables[]`，关注 `chain` 节点
的 `hook in/forward` 与 `policy` 字段。nftables 默认链可不设 hook
（regular chain）；只审 hooked chain。

**判定**：

- 若 `nftables` 数组空（即 ruleset 完全空）→ 1 条 critical：
  「nftables ruleset 为空且 nft 已安装，等同未启用过滤」。
- 若有 ruleset：对每个 `inet` / `ip` / `ip6` family 表中的
  `hook in/forward` 链，policy != `drop` 且 != `reject` → 1 条 finding。

**Finding 模板**：

```
title:    "nftables {family} 表 {table_name} 链 {chain_name} (hook={hook}) 默认策略为 {policy}"
severity: critical （hook=input）
          high     （hook=forward）
evidence: { family, table, chain, hook, policy, ruleset_sha256 }
threat_refs: ["TI-LINUX-CIS-FIREWALL"]
```

### 4.3 `UfwAuditCheck`（`ufw_audit`）

**命令**：`ufw status verbose`（已含默认策略 + active/inactive）。不需要
第二条命令。

**解析**：

```python
def parse_ufw_status(stdout: str) -> dict:
    """抓 'Status: active|inactive' 与 'Default: deny (incoming),
       allow (outgoing), disabled (routed)' 行。
       IPv6 状态本 phase 不审（推后到 7e.5）——见 §2 audit 点 C 备注。"""
```

**判定**：

- `Status: inactive` → 1 条 critical：「ufw 已安装但未启用」。直接返，
  不再判默认策略。
- `Status: active`：
  - `Default incoming` != `deny` 且 != `reject` → 1 条 critical
  - `Default forward` != `deny` 且 != `reject` → 1 条 high
  - `Default outgoing` 不审

**Finding 模板**：

```
title:    "ufw {kind}"   # kind 取 inactive / default-incoming-accept / default-forward-accept
severity: critical / critical / high
evidence: { status: active|inactive, default_incoming, default_forward, default_outgoing }
threat_refs: ["TI-LINUX-CIS-FIREWALL"]
```

## 5. 数据流

```
Check.__init__()
  └─ yaml.safe_load(linux_hardening_baseline.yaml)["firewall"]
     编译成不可变 self._meta（仅 rationale / remediation 文案）。

Check.run(ctx)
  ├─ profile gating → not_applicable / continue
  ├─ detect_<bin>(ctx) → not_applicable / continue
  ├─ 主命令编排（每 Check 不同，见 §4）
  ├─ 串扰回避（仅 iptables_audit / nftables_audit）：
  │    output_managed_by_ufw(stdout, backend=...) → not_applicable / continue
  ├─ 解析层（evaluator 端，纯 Python helper）
  │    parse_iptables_default_policies(stdout) -> dict[str, str]
  │    json.loads(stdout) 然后遍历 nftables[]
  │    parse_ufw_status(stdout) -> dict
  ├─ 比对层 → list[Finding]
  └─ ctx.status 由 base 类语义保证 single-set
```

baseline 加载与 `sysctl_audit.py` 同模式：模块级常量 `_BASELINE_PATH =
Path(__file__).parent / "linux_hardening_baseline.yaml"`，`__init__()`
一次性加载并切片到 `self._meta`。

`Snapshot` 接触面：3 个 Check 都不写 `ctx.snapshot.collect(...)`，
与 7e/7e.1 同——纯只读发现，无 fixture 物化。

## 6. 错误处理

| 失败位置 | `IptablesAuditCheck` | `NftablesAuditCheck` | `UfwAuditCheck` |
|---|---|---|---|
| profile 非 Linux | `not_applicable` | `not_applicable` | `not_applicable` |
| `detect_<bin>` 全候选未命中 | `not_applicable("iptables 未安装")` | `not_applicable("nft 未安装")` | `not_applicable("ufw 未安装")` |
| 命令被 policy `rejected` | `skipped` | `skipped` | `skipped` |
| 检测到 ufw 接管 | `not_applicable("ufw 已接管…")` | `not_applicable("ufw 已接管…")` | n/a |
| 权限不足 | `skipped("需 root 或 NOPASSWD sudoers")` | 同左 | 同左 |
| 业务退出码非 0 且非权限不足 | `skipped(f"iptables 退出码 {N}")` | `skipped` | `skipped` |
| stdout 为空 | `iptables -S` 默认策略行必现；空 stdout → `skipped` | 真正空 stdout → `skipped("nft 输出为空")`（与 `{"nftables": []}` 区分；后者走 §4.2 的「ruleset 空 → 1 条 critical」分支） | `skipped("ufw status 输出为空")` |
| stdout JSON 解析失败 | n/a | `skipped("nft -j 输出非 JSON")` | n/a |
| `max_output_bytes` 截断 | `iptables -S` < 64 KiB；触发即 `partial_evidence` low + 按已解析部分继续 | 大型部署可能命中；同左 | `ufw status` < 8 KiB，不会触发 |
| `ip6tables` 未装但 `iptables` 已装 | IPv4 部分正常出 finding；IPv6 部分单独 `skipped`（不影响整体） | n/a（nft 单工具兼容 v4/v6） | n/a（ufw 单工具兼容） |
| `ctx.executor` 抛非业务异常（网络/SSH） | 上抛 orchestrator | 同左 | 同左 |

**约束（与 7e/7e.1 一致）**：

- Check 内不捕获通用 `Exception`——传输层异常归 orchestrator。
- `ctx.status` 单次设置；多次调用以最后一次为准（base 已保证）。
- 每个 Check `run()` 主体目标 ≤ 80 行；解析 helper 拆模块顶层私有
  函数便于单测命中。

## 7. SSH policy 扩展

全部走严格 argv schema（无 `allowed_argv` 通配口子）。

`allowed_paths` 追加（9 条 exact，stat-probe 用；与 docker bin-resolver
同模式）：

```yaml
- {kind: exact, path: "/usr/sbin/iptables"}
- {kind: exact, path: "/sbin/iptables"}
- {kind: exact, path: "/usr/bin/iptables"}
- {kind: exact, path: "/usr/sbin/nft"}
- {kind: exact, path: "/sbin/nft"}
- {kind: exact, path: "/usr/bin/nft"}
- {kind: exact, path: "/usr/sbin/ufw"}
- {kind: exact, path: "/sbin/ufw"}
- {kind: exact, path: "/usr/bin/ufw"}
```

`commands` 追加 3 段：

```yaml
iptables:
  # 只允许 -S 形态：列出所有规则。--line-numbers / -L / -F / -A / -D
  # / -I / -P 全部不在 allowed_argv 中，因此从构造上无法触发。
  allowed_argv:
    - ["iptables",  "-S"]
    - ["ip6tables", "-S"]

nft:
  # JSON 输出，单一形态；'list ruleset' 是只读 dump。'add' / 'delete'
  # / 'flush' / 'create' / 'insert' / 'replace' 全部不在 allowed_argv 中。
  allowed_argv:
    - ["nft", "-j", "list", "ruleset"]

ufw:
  # 'status verbose' 是只读；'enable' / 'disable' / 'allow' / 'deny'
  # / 'delete' / 'reset' / 'reload' 全部不在 allowed_argv 中。
  allowed_argv:
    - ["ufw", "status", "verbose"]
```

**为什么 4 个命令全用 `allowed_argv`（精确 tuple 匹配）而不是 `args_schema`**：

- 每个命令只跑 1 个固定形态（iptables 跑 2 个：v4 + v6 等价），无可参
  数化字段。
- 精确 tuple 在 policy 校验阶段是 O(1) 比对，且无需任何 placeholder
  推理 → 攻击面最小。
- 与 7f 的 `docker version --format {{json .}}` / `docker info --format
  {{json .}}` 同模式。

**没有改 `find` / `cat` / `grep` 命令面**：firewall 不读文件，纯靠
用户态命令的 stdout，无 `cat /etc/ufw/...` 之类；这也与 best-effort
取舍一致 —— 不试图从 `/etc/ufw/before.rules` 之类的文件还原状态，
只信权威工具的 dump。

## 8. Threat Intel 扩展

`src/agentsec/audit/ioc/threat_intel.yaml` 追加 1 条 stub 条目，沿用
7e/7e.1 的 `TI-LINUX-CIS-*` 命名（3 个 Check 共享同一条 TI，与 7e.1
的 `TI-LINUX-CIS-SYSTEMD` 被两条 systemd Check 共享同模式）：

```yaml
- id: TI-LINUX-CIS-FIREWALL
  source: internal
  claim: 主机防火墙默认策略与后端激活 — CIS Linux 加固基线
  confidence: high
  observed_at: "2026-05-09"
  url: ""
  cvss: null
  cvss_source: null
  affected_versions: ""
  fixed_in: ""
  kev: false
  mapped_tests: []
  auto_refresh: false
  note: 主机加固类静态规则；不需要外部刷新
```

加完后跑 `python scripts/build_cve_db.py` 重生 `cve_database.json`
（无 CVE 字段，对 lookup 无影响，仅为 strict TI 校验通过）。

## 9. 测试策略

### 9.1 单元测试

每 Check 一个文件，~6 case × 3 = ~18 个新 test，外加
`test_firewall_common.py` ~8 case → 新增约 26 个 test。

每个 Check 文件覆盖：

1. **合规路径** —— 默认 DROP / ufw active+deny+IPv6 on / nft hooked
   chain policy=drop —— 0 finding。
2. **违规路径** —— 默认 ACCEPT —— 断言 finding 数与 severity 分布
   （v4/v6 各 1）。
3. **平台 gating** —— `profile_name="macos"` → `is_not_applicable`。
4. **后端未装** —— stub `detect_<bin>` 三候选全 None → `is_not_applicable`。
5. **命令拒绝** —— stub `RunResult(rejected=True)` → `is_skipped`。
6. **权限不足** —— stub `stdout=""`, `stderr="iptables: Permission denied"`,
   `exit_code=4` → `is_skipped` + remediation 含「NOPASSWD sudoers」substring。
7. **特有分支** ——
   - `iptables_audit`：v4 OK + v6 失败 → 出 v4 finding 不污染整体；
     ufw 接管识别（fixture `iptables_with_ufw_chains.txt`）→
     `not_applicable`。
   - `nftables_audit`：JSON 解析失败 → `is_skipped`；ruleset 空 →
     1 条 critical；ufw 表识别 → `not_applicable`。
   - `ufw_audit`：`Status: inactive` → 1 条 critical 直接返；`active`
     + 默认 allow incoming → critical；`active` + 默认 deny + allow
     outgoing → 0 finding（合规姿态）。

`test_firewall_common.py` 覆盖：3 个 `detect_*` 各 1 个命中 case + 1
个全 miss case + `output_managed_by_ufw` 三种命中模式各 1 个 + 1 个
干净 negative case。

stub executor 形态：复用 7e/7e.1 的 `_RecordingExecutor(responses_dict)`，
键 `tuple(argv)` → `RunResult`。无 mock framework；纯 dict-stub。

### 9.2 fixture 数据

`tests/fixtures/firewall/`（§3.1 已枚举 10 个文件）。要点：

- `iptables_default_drop_v4.txt` / `_accept_v4.txt`：真实 `iptables -S`
  截取，含 `-P INPUT DROP|ACCEPT` 行 + 若干用户规则。
- `iptables_with_ufw_chains.txt`：含 `-N ufw-before-input` /
  `-A INPUT -j ufw-before-input`，触发 `output_managed_by_ufw` 三条
  命中规则中的 1+ 条。
- `nft_ruleset_drop.json` / `_accept.json`：`nft -j list ruleset` 真实
  截取，含 `inet filter` 表 + `input` hook chain，policy 字段差异。
- `nft_ruleset_with_ufw.json`：含 `inet ufw` 顶层表。
- `ufw_active_default_deny.txt`：合规姿态——含 `Status: active` +
  `Default: deny (incoming), allow (outgoing), disabled (routed)`。
- `ufw_active_default_allow.txt`：违规姿态——含 `Status: active` +
  `Default: allow (incoming), allow (outgoing), allow (routed)`，
  触发 critical+high 各 1 条。
- `ufw_inactive.txt`：单行 `Status: inactive`，触发 critical 1 条。

### 9.3 集成测试与 sample 漂移

`tests/integration/test_openclaw_mock.py` 的 mock SSH fixture 需扩 9 条
新命令的 stub 响应：

- `stat -c %n /usr/sbin/iptables`、`/sbin/iptables`、`/usr/bin/iptables`
  → 全返 exit 1（mock 机器没装 iptables）。
- nft / ufw 同样三档 stat 全 miss。
- 9 条 stat 全 miss → 3 个 Check 都落 `not_applicable`，0 finding。

mock 测试目标是「Check 跑通且不抛」，不是「触发 finding」——后者在单元
测试里覆盖（与 7e.1 同口径）。Sample 报告（`docs/samples/report-2026-04-28/`）
会因此多 3 条 `<!-- check:... -->` 锚点，按

```
AGENTSEC_REFRESH_SAMPLE=1 .venv/bin/pytest \
  tests/integration/test_openclaw_mock.py::test_openclaw_mock_end_to_end
```

刷新一次。

### 9.4 回归 gate

```
.venv/bin/pytest tests/ -q                       # 1094 → ~1120
.venv/bin/ruff check src/ tests/ scripts/        # clean
.venv/bin/pyright                                # 0 errors
.venv/bin/python scripts/check_owasp_coverage.py # 不受影响
.venv/bin/python scripts/check_threat_refs.py    # 通过（新 TI 未挂任何 case）
```

ssh_policy 安全性由 `tests/test_command_policy.py` 已有的全量校验自动
覆盖（每个新增 `allowed_argv` tuple 都会走那一组「argv 中混入 shell
metachar」「placeholder 不能匹配传入字面值」之类的兜底用例）。本 phase
不引入额外 grep gate。

### 9.5 真机 smoke

在 Lightsail prod（`34.208.65.73`，已有 168 CVE 基线）上跑：

```
.venv/bin/agentsec server-audit --host 34.208.65.73 --user ubuntu \
  --key ~/.ssh/id_rsa --consent-file AUTHORIZATION.txt \
  --output ./report-2026-05-09/
```

预期行为：

- `iptables_audit` / `nftables_audit` / `ufw_audit`：3 条全部
  `skipped("需 root 或 NOPASSWD sudoers")`（默认 `ubuntu` 用户无
  NOPASSWD）—— 这是 best-effort 策略的正常落点。
- 报告内 3 条 Check 都呈现 skipped 卡片 + remediation 行，operator
  看到提示后可决定是否给 `ubuntu` 加局部 NOPASSWD 重跑。
- 加 NOPASSWD 后重跑预期：Lightsail 默认 ufw inactive、iptables 仅有
  docker 默认链（INPUT 默认 ACCEPT 但被 docker 注入的 DOCKER-USER 链
  兜底）→ 实际可能出 1–3 条 finding。

实跑后将真实数字记入 `project_openclaw_lightsail_prod.md`。

## 10. CLI 注册

`src/agentsec/cli.py` 现有两处构造 `checks = [...]` 列表（`server_audit`
与 `_evaluate_server`），各追加 3 行：

```python
IptablesAuditCheck(),
NftablesAuditCheck(),
UfwAuditCheck(),
```

import 段同步追加 3 个新模块。位置插在 7e.1 的 `WorldWritableCheck()`
/ `AuditdRulesCheck()` / `SystemdServiceBlacklistCheck()` /
`SystemdUnitLintCheck()` 之后、7f 的 `DockerDaemonAudit()` 之前——按
phase 时间线排序，便于阅读 diff。

## 11. 文档变更

- **`ROADMAP.md`**：Phase 7 段追加 `7e.2 — Linux 主机加固防火墙 Check
  （iptables / nftables / ufw 三类，TI-LINUX-CIS-FIREWALL）— 2026-05-09`。
- **`CHANGELOG.md`** `[Unreleased]` `Added`：~150 字概述三个 Check +
  ssh_policy 扩展项。
- **`README.md`**：服务端审计 Check 数从「21 类」更新为「24 类
  （10 OpenClaw + 11 Linux hardening + 3 Docker）」。
- **`CLAUDE.md`**：Server-audit module 段尾的「**Total checks
  (v0.10.0):** ...」一行更新为 v0.11.0 24 类，把 firewall 三件挂在
  「Phase 7e.2」标签下。
- **`docs/adr/0011-phase-7e2-firewall-audit.md`**：复用 ADR-0009 论证模板，
  覆盖以下要点：
  - 后端选择（为何只 3 个，留 firewalld / pf 给 7e.3 / 7e.4）
  - 粒度（per-backend 而非 per-concern，与 Docker 三 Check 同构）
  - 串扰回避（方案 A，独立 Check + ufw 链识别 helper；为何不引入
    backend resolver）
  - 权限策略（best-effort skipped，不引入 sudo policy 类型；运维侧
    可加 NOPASSWD 后重跑）
  - 审计点首期范围（A+B+C，不含 D 日志 / E 危险 ACCEPT / F 状态跟踪
    / G 双轨冲突）

## 12. 验收清单

1. `.venv/bin/pytest tests/ -q` 全绿（≈1120 tests）。
2. `.venv/bin/ruff check src/ tests/ scripts/` clean。
3. `.venv/bin/pyright` 0 errors。
4. mock 集成测试通过；sample 漂移 guard 通过（带 3 条新锚点）。
5. ADR-0011 落地。
6. ROADMAP / CHANGELOG / README / CLAUDE.md 更新。
7. Lightsail 真机 smoke 跑通（默认会全 skipped，是正常落点）；结果
   写入 `project_openclaw_lightsail_prod.md`。

## 13. 后续展望

- **7e.3**：firewalld（CentOS / RHEL 系）+ `nft list ruleset` 跨 family
  增强（`bridge` / `arp` family）。
- **7e.4**：macOS pfctl（与 Linux 安全模型不同，单独 phase）。
- **7e.5 候选审计点扩展**：D 日志规则 / E 危险 ACCEPT 与 0.0.0.0/0 /
  F 状态跟踪 / G 双轨冲突。
- **sudo policy 类型**：作为跨切面话题独立讨论，不绑定 7e.x。一旦
  落地，firewall + sshd_config + auditd 这些受益 Check 都自动覆盖率
  上升。
