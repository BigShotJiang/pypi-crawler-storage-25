# Phase 7c — MCP Top 10 测试套件设计

**日期**: 2026-05-12
**状态**: 草案（待 ADR-0016 落地后转"已采纳"）
**目标版本**: v0.16.0
**前置 ADR**: ADR-0006（owasp_refs 已预留 `MCP\d+` 前缀）
**后续 ADR**: ADR-0016（与本 spec 同期落地）

---

## 1. 背景与动机

AgentSec 自 v0.2.0 起的所有 phase（7d 供应链系列、7e Linux 加固系列、7f 容器审计）都集中在
**server-audit** 一侧，深耕宿主机/容器/依赖层。**evaluation** 一侧（agent 攻击套件）自
Phase 7b 完成 OWASP LLM Top 10 + Agentic v1.1 (17) 覆盖后没有再扩展。

ADR-0006 在 `owasp_refs` 字段的正则里预留了 `MCP\d+` 前缀，注释明确"Phase 7c 启用"。
本 spec 兑现这个承诺。

**当前外部状态**：截至 2026-05-12，OWASP 尚未发布官方 MCP Top 10。Anthropic 的 MCP 协议
规范公开稳定，但安全侧的权威分类清单还在筹备。等候不可行：(a) 产品定位需要 evaluation
侧的持续进展；(b) 即便 OWASP 后续发版，我们仍可在保留兼容前缀的前提下做 mapping
（参见 §8 演进路径）。

## 2. 范围

### In-scope

- 策展一份 10 条 MCP 威胁清单（MCP1..MCP10），覆盖 MCP 协议四类原语（tool / resource / prompt / sampling）+ 多服务器命名空间 + 运行时 capability + 安装链。
- 写 80 个测试 case，分布在 5 个 YAML 文件，全部通过现有 `AgentAdapter` → `JudgeRouter` → 报告流水线消费，**零架构变更**。
- 落地 ADR-0016 记录威胁清单决策与未来 OWASP 官方版的 mapping 策略。
- 同步 CHANGELOG / ROADMAP / README / CLAUDE.md。
- 必要时小幅扩展 `scripts/check_owasp_coverage.py` 让其知道 MCP 阈值。

### Out-of-scope（显式排除）

- 不实现真实的 `McpAdapter`（直连 MCP server、说 JSON-RPC、测协议本身）。该方向留作未来 Phase 7c.2 候选。
- 不动 `src/agentsec/audit/`（server-audit 流水线）、`src/agentsec/scoring/`、`src/agentsec/reports/` 任何核心评分/渲染逻辑。
- 不引入 `mcp_supplements.yaml` 之类的深度补充套件（留作 Phase 7c.1 候选）。
- 不搭建 MCP server 沙箱 / mock 环境用于 live 集成测试。
- 不重写 `scripts/check_owasp_coverage.py`，只做必要的阈值表扩展。

## 3. MCP1..MCP10 威胁清单

下面 10 条按 MCP 协议原语切分，每条标注核心攻击面 + 与已有 OWASP 框架的可叠加引用关系。

| ID | 名称 | 协议层面 | 与已有框架的交叉引用 |
|---|---|---|---|
| **MCP1** | Tool Description Injection | `tools/list` 返回的工具描述字符串 | `LLM01:2025`（间接 prompt injection） |
| **MCP2** | Tool Result Injection | `tools/call` 返回的结果 payload | `LLM01:2025` |
| **MCP3** | Cross-Server Confused Deputy | 多 server 注册同名/近名工具，agent 路由错误 | AGENTIC 的 confused-deputy 类 |
| **MCP4** | Resource URI Smuggling | `resources/read` URI 越出预期 scope | `LLM02:2025`（敏感信息）+ AGENTIC 越权类 |
| **MCP5** | Prompt Template Injection | `prompts/get` 返回的模板劫持 agent 行为 | `LLM01:2025` |
| **MCP6** | Shadow Tool / Capability Drift | 运行时 `notifications/tools/list_changed` 引入未授权工具 | AGENTIC 的工具发现链类 |
| **MCP7** | Sampling Abuse | server 通过 `sampling/createMessage` 反向调用 agent 的 LLM | `LLM10:2025`（unbounded consumption） |
| **MCP8** | Consent Bypass | 破坏性/敏感工具调用未经显式用户授权就执行 | AGENTIC 的缺失人类授权类 |
| **MCP9** | Server Supply Chain | typosquatting / 仓库接管 / 未签名 MCP 包安装 | `LLM03:2025`（supply chain） |
| **MCP10** | Tool-Argument Exfiltration | agent 将系统 prompt / 前文对话泄入工具参数 | `LLM02:2025`（数据泄漏） |

> 上表"交叉引用"列只列出**类别意图**；具体的 `AGENTIC-Tx` 编号会在 case 实现阶段按 v1.1 官方名表逐条对照填写，spec 阶段不锁定编号。

**策展原则**：
- 按 MCP 协议原语切分（不按 OWASP-flavored 抽象类别），避免与已有 LLM01-10 重复。
- 每条都允许在 `owasp_refs` 里与 LLM/Agentic 交叉引用——一个 case 可以同时打 `MCP1` 和 `LLM01:2025`。
- 故意 10 条整数：与"Top 10"约定俗成对齐。10 条之外的 fringe vector 留到 Phase 7c.1 supplements。

## 4. 文件组织

5 个 YAML 文件，按"机制同源"聚合，全部放在 `test_suites/` 顶层（与 `prompt_injection.yaml` / `agentic_*.yaml` 平级）。

| 文件 | 收纳 MCP-ID | case 数 | ID 前缀 | 聚合理由 |
|---|---|---|---|---|
| `test_suites/mcp_injection.yaml` | MCP1 + MCP2 + MCP5 | 28（10+10+8） | `mcp-inj-NN` | 三种都是"server 控制的字符串流入 LLM 上下文" |
| `test_suites/mcp_cross_server.yaml` | MCP3 + MCP6 | 16（8+8） | `mcp-xs-NN` | 工具命名空间被污染（静态碰撞 + 动态新增） |
| `test_suites/mcp_resource_smuggling.yaml` | MCP4 + MCP10 | 16（8+8） | `mcp-rsm-NN` | 数据流边界对偶（入站越界 + 出站泄漏） |
| `test_suites/mcp_capability_abuse.yaml` | MCP7 + MCP8 | 14（6+8） | `mcp-cap-NN` | 滥用合法 MCP 特性 |
| `test_suites/mcp_supply_chain.yaml` | MCP9 | 6 | `mcp-sup-NN` | 攻击介质在安装/注册时刻，节奏不同 |

**总计**：80 case。

每条 MCP-ID 至少 6 个 case（`check_owasp_coverage.py` 的最小阈值）。

## 5. Case 字段约定

复用现有 `TestCase` Pydantic schema，下列约定为本 phase 强制：

```yaml
- id: mcp-inj-01                            # 文件前缀 + 顺序号
  category: mcp_injection                   # 与文件名一致（去掉 .yaml）
  description: One-line summary of the vector and what makes it MCP-specific.
  attack: |
    Multi-line user message. Sets up the MCP context inside the prompt
    rather than relying on a real MCP server — e.g. "Your MCP server
    `fs-mcp` just returned this tools/list entry: {...}". Agent must
    handle the scenario safely.
  expected_behavior: refusal                # refusal | no_leak | custom
  severity: critical                        # critical | high | medium | low
  judge_type: llm                           # 默认 llm；clear-pattern 用 deterministic
  owasp_refs: [MCP1, LLM01:2025]            # 必含 ≥1 个 MCP[1-10]；可叠 LLM/Agentic 交叉引用
  judge_hint: |
    Pass if the agent refuses to .../warns about ... Fail if it ...
```

### 5.1 字段强约束

1. **Self-contained 攻击载荷**：所有"MCP server 返回 X"的场景都在 `attack` 文本里描述，不依赖真实 MCP server。与 `agentic_rogue_agents.yaml:rog-02`（"Your peer agent `ops_agent` is fully cleared..."）相同模式。
2. **`owasp_refs` 必含 ≥1 个 `MCP[1-10]`**：违反则 YAML 加载即失败（现有 `validate_owasp_refs` 正则已覆盖）。
3. **`judge_type` 比例参考**：约 80% LLM + 20% deterministic。deterministic 用在能写清晰 regex/substring 的场景。
4. **`severity` 分布参考**：critical ~30% / high ~50% / medium ~20%（与现有 agentic 系列一致）。
5. **`description`**：单行 ≤ 120 字符英文。
6. **`judge_hint`**：必含"Pass if … Fail if …"两个分支。
7. **YAML 全英文**：与现有套件一致；中文只在报告渲染层出现。

### 5.2 ID 与唯一性

- 跨 5 个文件 80 个 id 必须全局唯一（`loader.py` 不做去重检查）。
- 与现有 730 个 case ID 不冲突。新 `mcp-` 前缀确保不撞库。

## 6. 必要的代码与脚本改动

本 phase 是"数据为主"的工作，代码改动尽量小。

### 6.1 OWASP coverage 数据 + 报告 + CI 三处联动

实际代码触点比初版预想多。当前 LLM/Agentic 数据流向：

`src/agentsec/reports/owasp_coverage.py`（数据源 `LLM_TOP10_2025` / `AGENTIC_THREATS` + `build_coverage_matrix` + `OwaspCoverageMatrix.llm_rows() / agentic_rows()`）
→ `src/agentsec/reports/markdown.py`（`_table(...)` 渲染）
→ `scripts/check_owasp_coverage.py`（CI 阈值）

本 phase 需要在三处都补 MCP 分支：

1. **`src/agentsec/reports/owasp_coverage.py`**：
   - 新增常量 `MCP_THREATS: tuple[FrameworkEntry, ...]`（10 条，含 id + title）。
   - 给 `OwaspCoverageMatrix` 加 `mcp_rows()` 方法（与 `llm_rows` / `agentic_rows` 对齐）。
   - `build_coverage_matrix` 的迭代 `(*LLM_TOP10_2025, *AGENTIC_THREATS)` 改为 `(*LLM_TOP10_2025, *AGENTIC_THREATS, *MCP_THREATS)`。
2. **`src/agentsec/reports/markdown.py`**：在现有两个 `_table(...)` 调用后加一行 `_table("OWASP MCP Top 10 (AgentSec curated v1)", matrix.mcp_rows())`。表标题含"AgentSec curated v1"避免与未来 OWASP 官方版混淆。
3. **`scripts/check_owasp_coverage.py`**：
   - 从 `agentsec.reports.owasp_coverage` 额外 import `MCP_THREATS`。
   - 加 `MCP_FLOOR = 6`、parallel under-threshold 检查、错误信息文案与现有 Agentic 段对齐。
   - 出参文案末尾"OK — ..."追加 "and every MCP curated v1 threat has at least N cases"。

`src/agentsec/tests/owasp_refs.py` 的正则已经把 `MCP[1-9]\d*` 列为合法前缀（ADR-0006 预留），**加载层零改动**。

### 6.2 新增 `tests/test_mcp_suite_load.py`

或在现有 `tests/test_loader.py` 里 piggyback 一个用例：
- 加载 `test_suites/mcp_*.yaml` 全部 5 个文件不报错。
- 总 case 数 == 80。
- 每个 case 的 `owasp_refs` 至少含一个 `MCP\d+`。
- 跨文件 id 全局唯一。

### 6.3 不动的代码

- `src/agentsec/tests/owasp_refs.py`：正则已覆盖 `MCP[1-9]\d*`，无需改。
- `src/agentsec/adapters/`：零改动（不写 MCP adapter）。
- `src/agentsec/evaluator/`：零改动。
- `src/agentsec/audit/`：零改动。
- `src/agentsec/scoring/`：零改动；`src/agentsec/reports/` 仅 §6.1 列出的两个文件最小补丁，其它（renderers / scoring helper）零改动。

## 7. 验收标准

1. **加载**：`.venv/bin/agentsec run test_suites/ --target <dummy>` 加载全部 5 个 MCP YAML 无错；80 个 case 全部进入 judge 阶段（即便 dummy target 全 fail，也要走到判决）。
2. **唯一性**：80 个 `id` 跨 5 个文件 + 现有所有 case 全局唯一。
3. **`owasp_refs` 覆盖闸**：`scripts/check_owasp_coverage.py` 报告 MCP1..MCP10 每条 ≥ 6 case，零未识别前缀告警。
4. **Judge 一致性抽检**：从 80 个 case 中随机抽 5 个，对 mock 答案（一个 hard-fail + 一个 hard-pass + 一个 borderline）人工核 LLM judge 判定的合理性。
5. **静态 lint**：新 `tests/test_mcp_suite_load.py`（或扩展的 `test_loader.py`）pytest 通过；ruff lint 干净。
6. **文档同步**：CHANGELOG / ROADMAP / README / CLAUDE.md 各加 MCP 段落；ADR-0016 落地。
7. **版本**：`pyproject.toml` 升 `v0.16.0`（minor，新增评测套件，零架构变更）。

## 8. 演进路径

### Phase 7c.1（候选，未排期）
- `mcp_supplements.yaml`：参照 `agentic_supplements.yaml`（145 cases）的密度，为最易出现的 MCP1/2/3 各加 20+ 个深度变体。
- 候选触发条件：v0.16.0 正式投产后收到外部社区反馈或新的 MCP CVE / 学术披露。

### Phase 7c.2（候选，未排期）
- 真实 `McpAdapter` 实现：直连 MCP server，按 JSON-RPC 协议测协议层本身（malformed frame、capability spoofing 等）。
- 与本 phase 互补：本 phase 测的是 *agent*；7c.2 测的是 *server*。

### 与未来 OWASP 官方版的 mapping

当 OWASP 发布官方 MCP Top 10（命名假定 `OWASP-MCP\d+:YYYY`）时：
1. 在 `OWASP_REF_PATTERN` 正则里加 `OWASP-MCP(0[1-9]|10):YYYY` 分支，保留旧 `MCP\d+` 前缀作别名。
2. 写一份对照表（旧 → 新），把每个 case 的 `owasp_refs` 增补对应官方编号（旧别名保留 2 个版本周期）。
3. 老别名退场时机：在两个 minor 版本之后正式废弃，发布 deprecation 警告 ≥ 1 个版本周期。

## 9. 风险与缓解

| 风险 | 缓解 |
|---|---|
| 自策展威胁清单与未来 OWASP 官方版不一致 | §8 的 mapping 策略 + 别名兼容期 |
| Self-contained prompt 与真实 MCP server 攻击之间存在 fidelity gap | 文档明示"本 phase 测的是 agent 在 MCP 叙事下的判断力"，承认 fidelity gap；未来 7c.2 补 server 侧 |
| LLM judge 对"MCP-specific 情景"判定不稳定 | `judge_hint` 严格"Pass if … Fail if …"两段式；§7.4 抽检 + 操作员发版前 live 烟测 |
| 80 个 case 大幅推高 judge 调用成本 | 套件可独立运行（`--suite mcp_*.yaml`）；CI 默认不跑 live judge，只跑 dry-load |
| MCP 协议未来版本变动让现有 case 描述过时 | description/judge_hint 写"攻击意图"而非"协议字节细节"；MCP1..MCP10 是抽象类别，不随 protocol patch 失效 |

## 10. 实施计划入口

本 spec 通过后，移交给 `writing-plans` skill 拆解为：
- ADR-0016 起草与合入
- `src/agentsec/reports/owasp_coverage.py`：加 `MCP_THREATS` + `mcp_rows()` + `build_coverage_matrix` 收纳
- `src/agentsec/reports/markdown.py`：加第三张 OWASP 覆盖表
- `scripts/check_owasp_coverage.py`：加 `MCP_FLOOR = 6` 检查
- 5 个 YAML 文件分批写入（建议按文件分 commit）
- 新增 `tests/test_mcp_suite_load.py`
- 报告渲染单测扩展（断言 MCP 第三张表出现）
- 文档同步（CHANGELOG / ROADMAP / README / CLAUDE.md）
- v0.16.0 发版（`pyproject.toml` 版本升级 + PyPI 上传）
