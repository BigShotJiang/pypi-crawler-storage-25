# Phase 7e.1 — Linux 主机加固扩展 Check 设计

**日期**：2026-05-08
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0009；前置 ADR-0008。

## 1. 目标

`agentsec server-audit` 在 Phase 7e 已落地 4 类主机加固 Check
（`sysctl_audit` / `sshd_config_audit` / `sudoers_audit` / `suid_audit`），
覆盖 OS 内核 + sshd + sudoers + SUID 漂移。Phase 7e 计划文档列出
4 项「out-of-scope，留 7e.1 跟进」：

- world-writable 文件扫描
- auditd 规则审计
- firewall（iptables / nftables / ufw）
- systemd 单元枚举

7e.1 一波覆盖**前两项 + systemd 拆为两条 Check**（黑名单 + unit lint），
firewall 单独留作 7e.2。本 spec 描述这一波 4 个新 Check 的设计。

## 2. 范围

新增 4 个 Check，全部沿用现有 `Check` ABC 模式：

| Check 类 | id | 主命令 | Finding 粒度 |
|---|---|---|---|
| `WorldWritableCheck` | `world_writable_audit` | `find <path> -maxdepth 4 -type f -perm /002` × 7 路径 | 每个命中文件一条 |
| `AuditdRulesCheck` | `auditd_rules_audit` | `auditctl -s` + `auditctl -l` | 状态异常 1 条；每条缺失 baseline 规则 1 条 |
| `SystemdServiceBlacklistCheck` | `systemd_service_blacklist` | `systemctl list-unit-files --type=service --state=enabled --no-legend --plain` | 每个命中黑名单的 enabled 服务一条 |
| `SystemdUnitLintCheck` | `systemd_unit_lint` | `find /etc/systemd/system -maxdepth 1 -name '*.service' -type f` + 每文件 `cat` | 每个 unit 文件命中任一 lint 规则一条 |

**out of scope**：

- firewall（三后端，工作量 ≈ 7e 总和，留 7e.2）。
- `linux_hardening.yaml` 运维侧 override 接口（可在 7f / 7g 引入）。
- `auditctl --raw` / `aureport` / 实际事件流分析（属于事件驱动检测，非加固审计）。
- macOS 主机加固（不同的安全模型，单独 phase）。

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  world_writable.py             # 新
  auditd_rules.py               # 新
  systemd_service_blacklist.py  # 新
  systemd_unit_lint.py          # 新
  linux_hardening_baseline.yaml # 现有，追加 3 个 section
src/agentsec/audit/ssh_policy.yaml         # 现有，扩 6 处
src/agentsec/audit/ioc/threat_intel.yaml   # 现有，追加 3 条 internal TI 条目
src/agentsec/cli.py                        # 现有，注册点两处各 +4 行
tests/test_world_writable.py
tests/test_auditd_rules.py
tests/test_systemd_service_blacklist.py
tests/test_systemd_unit_lint.py
tests/fixtures/linux_hardening/            # 新目录
  auditctl_l_compliant.txt
  auditctl_l_partial.txt
  systemctl_list_unit_files.txt
  unit_files/clean.service
  unit_files/writable_execstart.service
  unit_files/shellwrap.service
  unit_files/root_writable_combo.service
docs/adr/0009-linux-host-hardening-extras.md  # 新 ADR
```

新增文件 4（Check） + 4（test） + 4（ADR/spec/fixture index/baseline ext）= 12 量级。

### 3.2 平台 gating

4 个 Check 都在 `run()` 顶部判断
`ctx.profile.name in ("linux", "linux_user_mode")`，
非 Linux profile 标 `not_applicable` 直接返。

`AuditdRulesCheck` 多一档：`auditctl -s` 退出码非 0 视作未装 auditd，
标 `not_applicable` 直接返；不进规则比对。

### 3.3 `_REQUIRED_PATHS`

4 个 Check 都设为 `()`（OS 级，不走 OpenClaw 路径门），与 7e 一致。

### 3.4 baseline 文件结构

`linux_hardening_baseline.yaml` 在原 4 段（`sysctl` / `sshd` /
`sudoers` / `suid`）下追加 3 段（systemd 两条共用一个父键）：

```yaml
sysctl: [...]                     # 7e
sshd: [...]                       # 7e
sudoers: [...]                    # 7e
suid: {...}                       # 7e

world_writable:                   # 7e.1
  scan_paths: [...]
  rationale: ...
  remediation: ...

auditd:                           # 7e.1
  required_rules: [...]
  status_disabled_severity: high

systemd:                          # 7e.1
  service_blacklist:
    services: [...]
    remediation: ...
  unit_lint:
    rules: [...]
    remediation: ...
```

7 个顶层 section（4 旧 + 3 新），systemd 两条 Check 共享 `systemd` 父键
避免顶层膨胀。每个 Check `__init__()` 时只 `yaml.safe_load(...)[<my_section>]`
（systemd 两条分别取 `["systemd"]["service_blacklist"]` /
`["systemd"]["unit_lint"]`）。

## 4. 组件细节

### 4.1 `WorldWritableCheck`（`world_writable_audit`）

**命令**：依次跑 `find <path> -maxdepth 4 -type f -perm /002` 7 次：

```
~/.openclaw, /var/log/openclaw, /tmp/openclaw,
/etc/cron.d, /etc/cron.daily, /etc/cron.weekly, /etc/cron.monthly
```

`/etc/sudoers.d` 已被 `sudoers_audit` 覆盖语义，不重复扫。

**baseline 段**：

```yaml
world_writable:
  scan_paths:
    - { path: "~/.openclaw",         severity: high }
    - { path: "/var/log/openclaw",   severity: high }
    - { path: "/tmp/openclaw",       severity: high }
    - { path: "/etc/cron.d",         severity: critical }
    - { path: "/etc/cron.daily",     severity: critical }
    - { path: "/etc/cron.weekly",    severity: critical }
    - { path: "/etc/cron.monthly",   severity: critical }
  rationale: 世界可写文件可被任意本地用户篡改；cron 目录命中等于本地提权点
  remediation: chmod o-w <path>；审查文件 owner 与改动历史
```

**Finding**：每命中一个文件一条，title `world-writable: <绝对路径>`，
severity 取所属扫描根的 severity。`evidence={"path": p, "scan_root": root}`。
`threat_refs=["TI-LINUX-CIS-WORLDWRITABLE"]`。

### 4.2 `AuditdRulesCheck`（`auditd_rules_audit`）

**命令序列**：

1. `auditctl -s` —— 状态探测；exit_code≠0 → `not_applicable("auditd 未安装")`。
2. `auditctl -l` —— 拉规则列表，按行做 stable-substring 匹配。

**baseline 段**：

```yaml
auditd:
  required_rules:
    - { id: watch_passwd,   match: "-w /etc/passwd",      severity: medium }
    - { id: watch_shadow,   match: "-w /etc/shadow",      severity: medium }
    - { id: watch_group,    match: "-w /etc/group",       severity: medium }
    - { id: watch_sudoers,  match: "-w /etc/sudoers",     severity: high }
    - { id: watch_sudoersd, match: "-w /etc/sudoers.d",   severity: high }
    - { id: watch_lastlog,  match: "-w /var/log/lastlog", severity: low }
    - { id: watch_utmp,     match: "-w /var/run/utmp",    severity: low }
    - { id: syscall_execve, match: "-S execve",           severity: medium }
  status_disabled_severity: high
```

**Finding**：

- `auditctl -s` 输出含 `enabled 0` → 1 条 high finding：
  `"auditd 已安装但 enabled=0"`。
- `auditctl -l` 输出中找不到某条 baseline 的 `match` 子串 → 1 条
  对应 severity 的 finding：`"auditd 缺失规则 <id>: 期望子串 <match>"`。

`evidence` 含 `{"rule_id": id, "match": match}` 或
`{"status_dump": <stdout>}`。
`threat_refs=["TI-LINUX-CIS-AUDITD"]`。

**未装判定**：用 `auditctl -s` 退出码而非 `which auditctl`，避免新增
`which` 命令面 + 一次额外 SSH 往返。`auditctl -s` 在未装时 shell
返回 127；装了但 daemon 未跑时 `auditctl -s` 自身退码 ≠ 0 但能跑
（输出含报错或空），SSH 协议把退出码原样回传，二者通过
**「stdout 是否含 `enabled` 行」** 二次区分（仅有退出码不够稳）：

- exit_code = 127 或 stdout 完全空且 stderr 含 `command not found`
  → `not_applicable`。
- 其他退出码 ≠ 0 → `skipped`（视作短暂故障）。
- exit_code = 0 → 进入第 2 步。

### 4.3 `SystemdServiceBlacklistCheck`（`systemd_service_blacklist`）

**命令**：
`systemctl list-unit-files --type=service --state=enabled --no-legend --plain`

`--plain` 抑制目录树字符；`--no-legend` 去掉表头说明行。
输出每行 2 列：`<unit-name> <state>`。

**baseline 段**：

```yaml
systemd:
  service_blacklist:
    services:
      - { name: telnet.socket,        severity: critical, rationale: telnet 明文协议 }
      - { name: rsh.socket,           severity: critical, rationale: rsh 明文 }
      - { name: rlogin.socket,        severity: critical, rationale: rlogin 明文 }
      - { name: rexec.socket,         severity: critical, rationale: rexec 明文 }
      - { name: tftp.socket,          severity: high,     rationale: TFTP 无认证 }
      - { name: nfs-server.service,   severity: medium,   rationale: 非文件服务器不应启用 }
      - { name: rpcbind.service,      severity: medium,   rationale: portmap 暴露 RPC }
      - { name: avahi-daemon.service, severity: medium,   rationale: zeroconf 信息泄露面 }
      - { name: cups.service,         severity: low,      rationale: 非打印场景多余 }
      - { name: xinetd.service,       severity: medium,   rationale: 老超级守护进程 }
    remediation: systemctl disable --now <service>
```

**Finding**：每个命中黑名单的 enabled unit 一条，title
`"高风险服务已启用：<unit>"`。`evidence={"unit": name, "state": "enabled"}`。
`threat_refs=["TI-LINUX-CIS-SYSTEMD"]`。

### 4.4 `SystemdUnitLintCheck`（`systemd_unit_lint`）

**命令**：

1. `find /etc/systemd/system -maxdepth 1 -name '*.service' -type f`。
2. 对每个文件路径 `cat`，evaluator 端抽取 `[Service]` 段，
   按下面 3 条 regex 做 `finditer`。

**Lint 规则（regex 在 Python 模块顶层；YAML 只放元数据）**：

- `_RE_EXEC_WRITABLE = re.compile(r'^ExecStart\s*=\s*([^\n]*\s)?(/tmp/|/var/tmp/|/dev/shm/|/home/)', re.M)`
  → severity high
- `_RE_EXEC_SHELL_WRAP = re.compile(r'^ExecStart\s*=\s*.*(\b(?:bash|sh)\b\s+-c\s|curl\s+[^|\n]*\|\s*(?:bash|sh)|wget\s+[^|\n]*\|\s*(?:bash|sh))', re.M)`
  → severity high
- 升级条件：以上两条任一命中且 unit 文件 `[Service]` 段满足
  `re.search(r'^User\s*=\s*root\s*$', section, re.M)` 或 `[Service]`
  段不含 `^User\s*=`（systemd 默认以服务管理者身份跑，普通 .service
  文件没声明 User 即等价于 root）→ 升级为 critical，**只发**升级后
  那一条 finding。

**baseline 段**：

```yaml
systemd:
  unit_lint:
    rules:
      - { id: writable_execstart,  severity: high,     rationale: ExecStart 指向用户可写目录 }
      - { id: shellwrap_execstart, severity: high,     rationale: ExecStart 走 shell 包装或 download-and-exec }
      - { id: root_writable_combo, severity: critical, rationale: User=root 叠加可写或 shell-wrap ExecStart }
    remediation: 评估服务来源；移到不可写路径，加非 root 的 User=
```

**Finding**：每文件命中一条；多 rule 命中以最高 severity 为准并合并到
一条 finding，title `"systemd unit 风险：<file>"`，
`evidence={"file": p, "rules": [<id list>], "snippet": <≤200 字符>}`。
`threat_refs=["TI-LINUX-CIS-SYSTEMD"]`（与 4.3 共用同一 TI ID）。

## 5. 数据流

```
Check.__init__()
  └─ yaml.safe_load(linux_hardening_baseline.yaml)[<my_section>]
     编译成不可变 self._<rules>，regex 在此预编译。

Check.run(ctx)
  ├─ profile gating → not_applicable / continue
  ├─ 命令编排（每 Check 不同，见 §4）
  ├─ 解析层（evaluator 端，纯 Python helper）
  │    _parse_auditctl_l(stdout) -> set[str]
  │    _parse_systemctl_unit_files(stdout) -> dict[str, str]
  │    _extract_service_section(unit_text) -> str
  ├─ 比对层 → list[Finding]
  └─ ctx.status 由 base 类语义保证 single-set
```

baseline 加载与 `config_audit.py` 同模式：模块级常量
`_BASELINE_PATH = Path(__file__).parent / "linux_hardening_baseline.yaml"`，
`__init__()` 一次性加载并切片到 `self._<section>`。

`Snapshot` 接触面：4 个 Check 都不写 `ctx.snapshot.collect(...)`，
与 7e 同——纯只读发现，无 fixture 物化。

## 6. 错误处理

| 失败位置 | `WorldWritableCheck` | `AuditdRulesCheck` | `SystemdServiceBlacklistCheck` | `SystemdUnitLintCheck` |
|---|---|---|---|---|
| profile 非 Linux | `not_applicable` | `not_applicable` | `not_applicable` | `not_applicable` |
| 命令被 policy `rejected` | 该路径跳过；7 全 reject 才 `skipped` | `skipped` | `skipped` | `find` reject `skipped`；个别 `cat` reject 跳过该文件继续 |
| `auditctl -s` 显示未装（exit 127 或 stderr `command not found`） | n/a | `not_applicable("auditd 未安装")` | n/a | n/a |
| `auditctl -s` enabled=0 | n/a | 1 条 high finding，再继续比对规则 | n/a | n/a |
| 命令退出码 ≠ 0（业务故障） | 单路径 `skipped` 计数；7 全失败 → 整体 `skipped` | `skipped` | `skipped` | `find` 失败 `skipped`；单 `cat` 失败跳过 |
| stdout 为空 | 无 finding | 视为「无规则加载」，所有 8 条 baseline missing → 8 条 finding | 无 finding | 无 finding |
| stdout 解析异常 | 跳过该行 | 跳过该行 | 跳过该行 | 跳过该文件，无 finding |
| `max_output_bytes` 截断 | SSHExecutor 抛 `ResultTruncated`；Check 接到 `truncated=True` 标 `partial_evidence` low finding | 同左 | 输出量小，不会触发 | 单文件不触发；`find` 触发则 `skipped` |
| `ctx.executor` 抛非业务异常（网络/SSH） | 上抛 orchestrator | 同左 | 同左 | 同左 |

**约束（与 7e 一致）**：

- Check 内不捕获通用 `Exception`——传输层异常归 orchestrator。
- `ctx.status` 单次设置；多次调用以最后一次为准（base 已保证）。
- 每个 Check `run()` 主体目标 ≤ 80 行；解析 helper 拆模块顶层私有
  函数便于单测命中。

## 7. SSH policy 扩展

6 处变更，全部走严格 argv schema（无 `allowed_argv` 通配口子）：

`allowed_paths` 追加（5 条 prefix）：

```yaml
- { kind: prefix, path: "/etc/cron.d/" }
- { kind: prefix, path: "/etc/cron.daily/" }
- { kind: prefix, path: "/etc/cron.weekly/" }
- { kind: prefix, path: "/etc/cron.monthly/" }
- { kind: prefix, path: "/etc/systemd/system/" }
```

（`/etc/audit/` 不在此次扩展——当前 4 个 Check 只用 `auditctl` 命令、
不读文件。后续 7e.3 真正落 auditd.conf 基线时再加。）

`commands` 追加：

```yaml
auditctl:
  allowed_argv:
    - ["auditctl", "-s"]
    - ["auditctl", "-l"]
```

`systemctl` 现有 `allowed_argv` 列表追加 1 条：

```yaml
- ["systemctl", "list-unit-files", "--type=service", "--state=enabled",
   "--no-legend", "--plain"]
```

`find` 命令面**不**改：`-maxdepth` / `-name` / `-type` / `-perm`
都在现有 `allowed_predicates` 中；新扫描根 `/etc/cron.*` 与
`/etc/systemd/system/` 通过 `allowed_paths` 自动放行。

`cat` 命令面**不**改：`/etc/systemd/system/` 落 `allowed_paths` 后，
`cat /etc/systemd/system/foo.service` 自动通过。

## 8. Threat Intel 扩展

`src/agentsec/audit/ioc/threat_intel.yaml` 追加 3 条 stub 条目，
沿用 7e 的 `TI-LINUX-CIS-*` 命名（systemd 两条 Check 共享一条 TI）：

```yaml
- id: TI-LINUX-CIS-WORLDWRITABLE
  source: internal
  claim: 世界可写文件 — CIS Linux 加固基线
  confidence: high
  observed_at: "2026-05-08"
  url: ""
  cvss: null
  cvss_source: null
  affected_versions: ""
  fixed_in: ""
  kev: false
  mapped_tests: []
  auto_refresh: false
  note: 主机加固类静态规则；不需要外部刷新

- id: TI-LINUX-CIS-AUDITD
  source: internal
  claim: auditd 规则覆盖 — CIS Linux 加固基线
  confidence: high
  observed_at: "2026-05-08"
  url: ""
  cvss: null
  cvss_source: null
  affected_versions: ""
  fixed_in: ""
  kev: false
  mapped_tests: []
  auto_refresh: false
  note: 主机加固类静态规则；不需要外部刷新

- id: TI-LINUX-CIS-SYSTEMD
  source: internal
  claim: systemd 服务与 unit 文件加固 — CIS Linux 加固基线
  confidence: high
  observed_at: "2026-05-08"
  url: ""
  cvss: null
  cvss_source: null
  affected_versions: ""
  fixed_in: ""
  kev: false
  mapped_tests: []
  auto_refresh: false
  note: 主机加固类静态规则；不需要外部刷新
```

加完后 `python scripts/build_cve_db.py` 重生 `cve_database.json`
（这些条目无 CVE 字段，对 lookup 无影响，仅为 strict TI 校验通过）。

## 9. 测试策略

### 9.1 单元测试

每 Check 一个文件，~5 case × 4 = ~20 个新 test：

每个文件覆盖：

1. **合规路径** —— 0 finding。
2. **违规路径** —— 每条 baseline 至少触发一次；断言 finding 数与
   severity 分布。
3. **平台 gating** —— `profile_name="macos"` → `is_not_applicable`。
4. **命令拒绝** —— stub `RunResult(rejected=True)` → `is_skipped`。
5. **退出码非 0 / 特有分支** ——
   `auditd_rules`：未装 vs 装了但 daemon 未跑 vs enabled=0；
   `world_writable`：单路径失败 vs 7-of-7 全失败；
   `systemd_unit_lint`：`find` 失败 vs 单 `cat` 失败跳过继续；
   `systemd_service_blacklist`：`list-unit-files` 失败 → skipped。

stub executor 形态：复用 7e 的 `_RecordingExecutor(responses_dict)`，
键 `tuple(argv)` → `RunResult`。无 mock framework；纯 dict-stub。

### 9.2 fixture 数据

`tests/fixtures/linux_hardening/`：

- `auditctl_l_compliant.txt` —— 含 8 条 baseline match 子串。
- `auditctl_l_partial.txt` —— 缺 sudoers + execve，便于断言 2 条 finding。
- `systemctl_list_unit_files.txt` —— ~30 行真实 `--no-legend --plain` 输出
  截取，含若干黑名单与若干白名单服务。
- `unit_files/clean.service` —— 合规模板；
  `writable_execstart.service`、`shellwrap.service`、
  `root_writable_combo.service` —— 各命中一类规则。

### 9.3 集成测试与 sample 漂移

`tests/integration/test_openclaw_mock.py` 的 mock SSH fixture 已识
7e 的命令面，需扩 4 条新命令的 stub 响应：

- `auditctl -s` → exit 127，stderr `auditctl: command not found`（mock
  机器没装 auditd），导致 `AuditdRulesCheck` 落 `not_applicable`。
- `auditctl -l` → 不会被调用（前一步已 not_applicable）。
- `systemctl list-unit-files --type=service --state=enabled --no-legend --plain`
  → stdout 空，`SystemdServiceBlacklistCheck` 0 finding。
- `find /etc/systemd/system -maxdepth 1 -name '*.service' -type f`
  → stdout 空，`SystemdUnitLintCheck` 0 finding。
- world_writable 的 7 条 `find` → stdout 空，0 finding。

mock 测试目标是「Check 跑通且不抛」，不是「触发 finding」——后者在
单元测试里覆盖。Sample 报告（`docs/samples/report-2026-04-28/`）
会因此多 4 条 `<!-- check:... -->` 锚点，按
`AGENTSEC_REFRESH_SAMPLE=1 .venv/bin/pytest ...::test_openclaw_mock_end_to_end`
刷新一次。

### 9.4 回归 gate

```
.venv/bin/pytest tests/ -q                       # 1005 → ~1025
.venv/bin/ruff check src/ tests/ scripts/        # clean
.venv/bin/pyright                                # 0 errors
.venv/bin/python scripts/check_owasp_coverage.py # 不受影响
```

ssh_policy 的安全性由 `tests/test_command_policy.py` 已有的全量校验
覆盖（每个新增 argv 形态都会被那一组 case 兜底——任何「argv 中混入
shell metachar」「placeholder 不能匹配传入字面值」之类的违规会在
`pytest tests/ -q` 阶段直接红）。本 phase 不引入额外 grep gate。

### 9.5 真机 smoke

在 Lightsail prod（`34.208.65.73`，已有 168 CVE 基线）上跑：

```
.venv/bin/agentsec server-audit --host 34.208.65.73 --user ubuntu \
  --key ~/.ssh/id_rsa --consent-file AUTHORIZATION.txt \
  --output ./report-2026-05-08/
```

预期新增 finding 数 5–15：

- `world_writable`：通常 0（cron 目录默认严格）；
- `auditd_rules`：Lightsail 默认未装 auditd → `not_applicable`；
- `systemd_service_blacklist`：通常 0（Ubuntu Server 默认配置干净）；
- `systemd_unit_lint`：取决于 OpenClaw 的 systemd unit 是否落地，
  ≤ 5 条。

实跑后将真实数字记入 `project_openclaw_lightsail_prod.md`。

## 10. CLI 注册

`src/agentsec/cli.py` 现有两处构造 `checks = [...]` 列表
（`server_audit` 与 `_evaluate_server`），各追加 4 行：

```python
WorldWritableCheck(),
AuditdRulesCheck(),
SystemdServiceBlacklistCheck(),
SystemdUnitLintCheck(),
```

import 段同步追加 4 个新模块。

## 11. 文档变更

- `ROADMAP.md`：新增 `7e.1` 行勾选；不动 7e 主行。
- `CHANGELOG.md` `[Unreleased]` `Added`：一段 ~150 字概述四个 Check + ssh_policy
  扩展项。
- `README.md`：服务端审计 Check 数从「14 类」更新为「18 类
  （10 OpenClaw 应用层 + 8 Linux 主机加固）」。
- `docs/adr/0009-linux-host-hardening-extras.md`：复用 ADR-0008 论证模板，
  说明 7e.1 的范围选择（带哪三件、为什么 firewall 推后）+ regex 边界
  + auditd 未装判定方式。

## 12. 验收清单

1. `.venv/bin/pytest tests/ -q` 全绿（~1025 tests）。
2. `.venv/bin/ruff check src/ tests/ scripts/` clean。
3. `.venv/bin/pyright` 0 errors。
4. mock 集成测试通过；sample 漂移 guard 通过（带 4 条新锚点）。
5. ADR-0009 落地。
6. ROADMAP / CHANGELOG / README 更新。
7. Lightsail 真机 smoke 跑通，结果写入 `project_openclaw_lightsail_prod.md`。

## 13. 后续展望

- **7e.2**：firewall（iptables / nftables / ufw 三后端）独立 Phase。
- **7f**：容器安全 Check（Docker daemon / 镜像扫描 / 容器逃逸面）。
- **7e.3 候选**：`/etc/audit/auditd.conf` 配置基线（log_file / max_log_file
  / space_left_action）。当前 7e.1 留了 `/etc/audit/` 的 allowed_paths
  prefix 占位，但只有 7e.3 落地时才会真用。
