# `agentsec diff` — Design

**Status:** Draft (brainstormed, awaiting implementation plan)
**Author:** Claude Opus 4.7 + Roger
**Date:** 2026-04-30
**Target version:** v0.4.0 (Phase 5 — 历史趋势对比)
**Roadmap entry:** `agentsec diff` 历史趋势对比子命令

---

## 1. Goals

Compare two `agentsec evaluate` runs (per spec §9.3 artifact set) and emit a
single Markdown delta report. Primary use case: weekly cron from
`.github/workflows/agentsec-evaluate.yml.example` (PR #29) accumulates two
report directories — operators want a one-glance answer to *"what changed?"*
without manually diffing JSON.

Two information surfaces compared:

- **Findings** — `findings.json` from each run (Stage F output, with computed
  `fingerprint`).
- **Score / coverage / grade** — extracted from `combined-report.md` meta
  comments at the top of each report (`<!-- meta:remote_score value:... -->`,
  `meta:server_score`, `meta:combined_score`, `meta:grade`).

**Non-goals (v0.4.0):**

- Per-test-case verdict diff for the **remote** half (would require comparing
  by test ID, where the test suite itself may have changed between runs;
  separate concern from server-audit findings drift).
- JSON sidecar output. The diff report is for human consumption (PR comments,
  email digests). Programmatic trend aggregation should consume `findings.json`
  directly, not the diff intermediate.
- Three-way / N-way comparison (baseline-as-rolling-mean, drift over arbitrary
  history). v0.4 is strictly two-input.
- Auto-comment on GitHub PRs / Slack push. The diff is a report file; the
  posting is a separate operator concern.
- `threat-intel-snapshot.yaml` drift surface. Not load-bearing for "what
  changed" — operators care about findings deltas, not which CVEs the
  threat-intel database knew about.
- `audit-log.jsonl` diff. Audit log is append-only operational evidence, not
  comparable.

---

## 2. Architecture

```
                ┌─────────────────────────┐  ┌─────────────────────────┐
                │ baseline-dir/           │  │ current-dir/            │
                │  - findings.json        │  │  - findings.json        │
                │  - combined-report.md   │  │  - combined-report.md   │
                └────────────┬────────────┘  └────────────┬────────────┘
                             │                            │
                             ▼                            ▼
                       ┌──────────────────────────────────────┐
                       │  loader.load_report_dir(path)        │
                       │  → (list[Finding], ScoreMeta | None) │
                       └──────────────────┬───────────────────┘
                                          │
                                          ▼
                       ┌──────────────────────────────────────┐
                       │  findings_delta.diff_findings(...)   │
                       │    pure, no I/O — fingerprint        │
                       │    matching + (check, title)         │
                       │    second-pass clustering            │
                       └──────────────────┬───────────────────┘
                                          │
                       ┌──────────────────────────────────────┐
                       │  score_delta.diff_scores(...)        │
                       │    pure, no I/O — flag REGRESSION /  │
                       │    IMPROVED based on absolute deltas │
                       └──────────────────┬───────────────────┘
                                          │
                                          ▼
                       ┌──────────────────────────────────────┐
                       │  renderer.render_diff_report(...)    │
                       │    pure, returns markdown str        │
                       └──────────────────┬───────────────────┘
                                          │
                                          ▼
                              stdout  OR  --output diff.md
```

**Module layout** (`src/agentsec/diff/`):

- `__init__.py` — re-exports `diff_findings`, `diff_scores`,
  `render_diff_report`, `load_report_dir` for testability.
- `loader.py` — `load_report_dir(path: Path) -> ReportData` (the only I/O
  module). Reads `findings.json`, parses `combined-report.md` meta comments.
- `findings_delta.py` — `diff_findings(baseline, current) -> FindingsDelta`.
  Pure function; the actual matching/clustering algorithm.
- `score_delta.py` — `diff_scores(baseline_meta, current_meta) -> ScoreDelta`.
  Pure function; regression/improved flagging.
- `renderer.py` — `render_diff_report(findings_delta, score_delta, header) -> str`.
  Pure function; markdown emission.

**CLI**: `src/agentsec/cli.py` gains a `diff()` subcommand that wires loader →
diff → renderer → stdout/file.

**Why pure-function core**: every module except `loader` and the CLI shim is
side-effect-free. Tests don't need filesystem fixtures for the matching /
flagging / rendering logic — they construct `Finding` and `ScoreMeta` objects
inline. This matches the architecture of `agentsec.scoring` (Stage F).

---

## 3. CLI surface

```
agentsec diff <baseline-dir> <current-dir> [--output PATH]
```

- Both arguments are **directories** (not `findings.json` files). The loader
  expects `findings.json` and `combined-report.md` inside each directory and
  errors with a clear message if the former is missing.
- `--output PATH` (optional): write markdown to PATH. Default: stdout.
- Exit codes:
  - `0` — diff rendered successfully (regardless of whether regressions were
    found; this matches `git diff` semantics, not lint-tool semantics).
  - `1` — input error (missing directory, missing `findings.json`, malformed
    JSON, malformed meta comment).
- No `--baseline-label` / `--current-label` flags. The header uses
  `Path.name` (basename) of each directory; if the basename matches
  `report-YYYY-MM-DD`, the date is rendered separately. YAGNI for explicit
  labels — operators can rename directories.

**Why exit 0 even on regression**: the diff is a *report*, not a *gate*.
Gating belongs to the consumer (CI step that parses regression markers, or
human reviewer). Conflating "rendered successfully" with "no regression"
makes scripting brittle.

---

## 4. Data shapes

```python
# src/agentsec/diff/types.py (or inline in modules — bias toward inline)

@dataclass(frozen=True)
class ScoreMeta:
    """Parsed from combined-report.md meta comments."""
    remote_score: float | None
    server_score: float | None
    combined_score: float | None
    grade: str  # "A".."D" / "C+" / "INSUFFICIENT_COVERAGE" / "NOT_SCORED"
    # Coverage triple is rendered in the body (not meta), so we parse it from
    # the bullet list. See §6 for parsing rules.
    verdict_coverage: float | None
    error_rate: float | None

@dataclass(frozen=True)
class ReportData:
    findings: list[Finding]
    score_meta: ScoreMeta | None  # None when combined-report.md missing/malformed
    label: str                     # directory basename
    date: str | None               # parsed from `report-YYYY-MM-DD` basename
```

```python
@dataclass(frozen=True)
class FindingsDelta:
    added: list[Finding]               # in current, not in baseline (by fingerprint)
    removed: list[Finding]             # in baseline, not in current (by fingerprint)
    stable: list[Finding]              # same fingerprint on both sides; current wins
    severity_changed: list[SeverityChange]
    evidence_drifted: list[DriftPair]  # second-pass cluster: same (check, title)

@dataclass(frozen=True)
class SeverityChange:
    fingerprint: str
    title: str
    check: str
    old_severity: str
    new_severity: str

@dataclass(frozen=True)
class DriftPair:
    check: str
    title: str
    baseline: Finding
    current: Finding
```

```python
@dataclass(frozen=True)
class ScoreDelta:
    rows: list[ScoreRow]               # one per metric
    has_regression: bool               # quick flag for renderer header

@dataclass(frozen=True)
class ScoreRow:
    metric: str                        # "combined_score" / "grade" / ...
    baseline_value: str                # rendered (e.g., "33.3" or "B" or "n/a")
    current_value: str
    delta_label: str                   # "REGRESSION: -8.0" / "IMPROVED: B → A" / "—" / "n/a"
    is_regression: bool
    is_improvement: bool
```

---

## 5. Findings delta algorithm

### 5.1 Primary pass — fingerprint matching

```
baseline_by_fp = {f.fingerprint: f for f in baseline}
current_by_fp  = {f.fingerprint: f for f in current}

added   = [f for fp, f in current_by_fp.items()  if fp not in baseline_by_fp]
removed = [f for fp, f in baseline_by_fp.items() if fp not in current_by_fp]
stable_keys = baseline_by_fp.keys() & current_by_fp.keys()
```

For each `fp` in `stable_keys`:

- if `baseline_by_fp[fp].severity == current_by_fp[fp].severity` →
  `stable.append(current_by_fp[fp])`
- else → `severity_changed.append(SeverityChange(...))`. Note the finding does
  NOT also appear in `stable`; severity change is its own bucket.

### 5.2 Second pass — (check, title) clustering on added×removed

After 5.1, build:

```
removed_by_ct = {(f.check, f.title): f for f in removed}
                # NOTE: dict overwrites duplicates; see §5.3 caveat

drifted: list[DriftPair] = []
remaining_added: list[Finding] = []
remaining_removed = list(removed)

for f in added:
    key = (f.check, f.title)
    if key in removed_by_ct:
        baseline_pair = removed_by_ct.pop(key)
        drifted.append(DriftPair(check=f.check, title=f.title,
                                  baseline=baseline_pair, current=f))
        remaining_removed.remove(baseline_pair)
    else:
        remaining_added.append(f)
```

Then:

- `FindingsDelta.added = remaining_added`
- `FindingsDelta.removed = remaining_removed`
- `FindingsDelta.evidence_drifted = drifted`

### 5.3 Caveat: duplicate (check, title) within a side

Two findings with the same `(check, title)` but different evidence within the
SAME run are legal (e.g., two `native_audit` findings titled `host: open
management port` for ports 8443 and 8444). The dict-based pairing above
collapses them — only the last one is retained as a drift candidate.

**Resolution**: for v0.4, we accept this. Multi-finding clustering with the
same `(check, title)` is rare in practice (the example ports above would more
typically have port number in the title). If observed, the report will show
one drift pair plus residual added/removed entries; this is correct behavior
just under-clustered. A `cluster_strategy: "exact_one"` hint in `Check` base
class is the v0.5 escape hatch if drift mismatches turn out to matter.

### 5.4 Determinism

`added`, `removed`, `stable`, `severity_changed`, `evidence_drifted` are all
sorted at the end of the algorithm before being returned, by:

- findings: `(severity_rank, check, title, fingerprint)` where `severity_rank`
  is `critical=0 / high=1 / medium=2 / low=3 / info=4`
- severity_changed: `(new_severity_rank, check, title)`
- evidence_drifted: `(severity_rank_of_current, check, title)`

This ensures the diff is byte-identical for the same inputs across runs (test
asserts on this).

---

## 6. Score delta algorithm

### 6.1 Meta comment parsing

`combined-report.md` top-of-file pattern (literal, from `_score_block` in
`reports/markdown.py`):

```markdown
## Score

<!-- meta:remote_score value:33.333333333333336 -->
<!-- meta:server_score value:91 -->
<!-- meta:combined_score value:62.16666666666667 -->
<!-- meta:grade value:C -->

- Remote score: 33.333...
- Server score: 91
- Combined: 62.16...
- Grade: C
```

Parser: regex `<!-- meta:(\w+) value:([^ ]+) -->` over the file head (first
~200 lines is enough). Values are:

- `"None"` (literal Python `str(None)`) → parsed as `None`.
- Otherwise float-coerced for the three score fields; string for `grade`.

Coverage section follows in `combined-report.md`:

```markdown
### Coverage

- Planned: 3
- Executed: 3 (execution_coverage=100.00%)
- Scored: 3 (verdict_coverage=100.00%)
- Errors: 0 (error_rate=0.00%)
```

Parser: regex on the four lines. `verdict_coverage` and `error_rate` are
extracted as floats (e.g., `1.0` from `100.00%`). `error_rate` of `N/A`
(legacy `executed=0` case) → `None`.

**Two distinct degraded modes** (do not conflate):

1. **Meta line absent entirely** (`<!-- meta:remote_score ... -->` missing
   from the file, or all 4 missing, or `combined-report.md` missing) →
   loader returns `score_meta = None`. Renderer omits the score table and
   prints a single line: `scores unavailable for <side>`.

2. **Meta line present with `value:None`** — legitimate half-evaluate
   case (Stage F emits `value:None` when one half didn't run). Loader
   returns `ScoreMeta(remote_score=None, server_score=91.0, ...)`. The
   row for that metric renders `"n/a"` in the affected cell.

The loader treats "any of the 4 score meta lines missing" as mode (1) — all-or-
nothing. Real `combined-report.md` files always emit all 4 together (see
`reports/markdown.py:_score_block`); partial absence is treated as a malformed
file rather than half-degrading. Coverage section parsing is independent: if
the score meta block is present but the coverage bullet list is absent (e.g.,
older renderer output), `verdict_coverage` and `error_rate` fields fall back
to `None` while score fields remain populated.

### 6.2 Regression thresholds

| Metric | Regression condition | Improvement condition |
|--------|---------------------|----------------------|
| `combined_score` | drops by > 5.0 absolute points | rises by > 5.0 absolute points |
| `remote_score`   | drops by > 5.0 absolute points | rises by > 5.0 absolute points |
| `server_score`   | drops by > 5.0 absolute points | rises by > 5.0 absolute points |
| `grade`          | letter rank decreases (A>B>C>D>F) | letter rank increases |
| `verdict_coverage` | drops below 0.7 (was ≥0.7) | rises to ≥0.7 (was <0.7) |
| `error_rate`     | rises above 0.1 (was ≤0.1) | drops to ≤0.1 (was >0.1) |

Grade rank table for letter comparison (matches `scoring.grade_letter` —
only these 7 values exist):

```
A=4, B=3, C=2, D=1, F=0
INSUFFICIENT_COVERAGE = -1   # always REGRESSION when current is this and baseline isn't
NOT_SCORED            = None # always "n/a", no flag
```

Plus/minus grade variants do not exist in `scoring.grade_letter`; a parser
encountering one in `meta:grade` should treat it as `"UNKNOWN"` (renders
as-is, no flag).

When either side is `None` (half-evaluate / missing meta), the row renders as
`"baseline" / "current"` with one cell `"n/a"`, `delta_label="—"`,
`is_regression=False`, `is_improvement=False`.

### 6.3 Why absolute thresholds, not relative

Spec §9.1 scores are 0–100 absolute. A 0.5 → 0.0 is a 100% relative drop but
materially nothing; a 95 → 90 is a 5% relative drop but a real change.
Absolute makes the threshold uniform across the score range.

The `5.0` constant lives in `score_delta.REGRESSION_THRESHOLD: float = 5.0`
as a module-level constant. Operators who want a stricter gate can fork; we
do not expose a CLI flag in v0.4.

---

## 7. Markdown report layout

Header:

```markdown
# AgentSec diff: <baseline-label> → <current-label>

**Baseline**: <baseline-label> ([date if parsed])
**Current**:  <current-label>  ([date if parsed])
```

If either side has `LOW_COVERAGE` (i.e., grade is `INSUFFICIENT_COVERAGE`):

```markdown
> **Warning**: <side> report has LOW_COVERAGE — score deltas may be misleading.
```

### 7.1 Score delta section

```markdown
## Score delta

| Metric | Baseline | Current | Δ |
|--------|----------|---------|---|
| combined_score | 70.0 | 62.0 | **REGRESSION: -8.0** |
| grade          | B    | C     | **REGRESSION: B → C** |
| remote_score   | 33.3 | 33.3  | — |
| server_score   | 95.0 | 91.0  | -4.0 |
| verdict_coverage | 1.00 | 0.65 | **REGRESSION: low coverage** |
| error_rate     | 0.00 | 0.00  | — |
```

If `score_meta is None` for either side:

```markdown
## Score delta

scores unavailable for <side> (combined-report.md missing or malformed)
```

### 7.2 Findings delta section

Summary line first:

```markdown
## Findings delta

**Added: 3** | **Removed: 1** | **Stable: 12** | **Severity-changed: 2** | **Evidence-drifted: 1**
```

Then each non-empty bucket as a sub-section. **Empty buckets are omitted**
(no "Added (0): nothing here" filler). Stable bucket is always rendered as
collapsed `<details>` (even when empty? — no, also omitted).

#### Added findings (N)

| Severity | Check | Title | Fingerprint |
|----------|-------|-------|-------------|
| critical | native_audit | host: open management port 8443 | `85a59ae4...` |

(Fingerprint truncated to 8 hex chars in the table. The 8-hex prefix is enough to disambiguate findings within a single report — operators can `grep` the full fingerprint from `findings.json` if needed.)

#### Removed findings (N)

Same shape as Added.

#### Severity changes (N)

| Severity old → new | Check | Title | Fingerprint |
|--------------------|-------|-------|-------------|
| high → **critical** | version_patch | OpenClaw 1.2.3 has CVE-2026-... | `f1a2...` |

(New severity is bolded if it's higher rank than old.)

#### Evidence drift (N)

For each `DriftPair`, render a paired block:

```markdown
**`<check>` — <title>** *(possibly the same issue, evidence changed)*

Baseline:
```json
{
  "interface": "0.0.0.0",
  "port": 8443
}
```

Current:
```json
{
  "interface": "0.0.0.0",
  "port": 8444
}
```
```

#### Stable findings (N)

Always rendered as `<details>` (collapsed):

```markdown
<details>
<summary>Stable: 12 findings (unchanged across runs)</summary>

| Severity | Check | Title | Fingerprint |
|----------|-------|-------|-------------|
| ... |

</details>
```

---

## 8. Edge cases & error handling

| Scenario | Behavior |
|----------|----------|
| `<dir>` does not exist | exit 1, message: `error: directory not found: <path>` |
| `<dir>/findings.json` missing | exit 1, message: `error: <path>/findings.json not found` |
| `<dir>/findings.json` malformed (not a JSON array) | exit 1, message: `error: <path>/findings.json malformed: <pydantic-error>` |
| `<dir>/combined-report.md` missing | warn to stderr, render diff with degraded score section |
| `<dir>/combined-report.md` has no meta comments | same as missing — `score_meta = None` |
| `verdict_coverage` line absent (legacy report) | `score_meta.verdict_coverage = None`, row renders "n/a" |
| Both sides empty findings | findings delta section renders "No findings on either side." |
| Either side has `low_coverage = True` | warning banner at top of report (per §7) |
| Either side score is `None` (half-evaluate) | row renders "n/a", no regression flag |
| `--output PATH` path's parent does not exist | exit 1, message: `error: parent directory does not exist: <path>` |
| `--output PATH` already exists | overwrite silently (matches `git diff > out` shell behavior) |

**Path safety**: directory inputs go through `Path.resolve(strict=True)` at
the loader boundary. No symlink expansion beyond Python's defaults; this is a
local CLI tool, not a multi-tenant service.

---

## 9. Testing strategy

### 9.1 Unit tests (no filesystem I/O)

`tests/unit/test_diff_findings_delta.py`:

- empty + empty → empty delta
- one common fingerprint → stable
- one fingerprint only in baseline → removed
- one fingerprint only in current → added
- same fingerprint, different severity → severity_changed (not in stable)
- same `(check, title)`, different fingerprint → evidence_drifted
- same `(check, title)` 2× on each side → one drift pair + residuals (§5.3)
- determinism: same input → byte-identical output (sorted)

`tests/unit/test_diff_score_delta.py`:

- both sides full → all rows populated
- combined_score baseline=70 current=62 → REGRESSION row, has_regression=True
- combined_score baseline=70 current=72 → "+2.0" no flag (under threshold)
- combined_score baseline=70 current=80 → IMPROVED
- grade B → C → REGRESSION; C → A → IMPROVED
- verdict_coverage 1.0 → 0.65 → REGRESSION
- verdict_coverage 0.65 → 1.0 → IMPROVED
- baseline=None or current=None for a metric → "n/a" row, no flag
- INSUFFICIENT_COVERAGE in current → REGRESSION on grade

`tests/unit/test_diff_loader.py`:

- valid `findings.json` → parsed list[Finding]
- valid `combined-report.md` meta → parsed `ScoreMeta`
- meta value `None` → ScoreMeta field `None`
- coverage line `error_rate=N/A` → ScoreMeta.error_rate `None`
- meta comment missing → ScoreMeta `None`, no crash
- malformed `findings.json` → raises with clear message
- directory basename `report-2026-04-30` → date `"2026-04-30"`
- directory basename `arbitrary-name` → date `None`

`tests/unit/test_diff_renderer.py`:

- header includes both labels and dates
- LOW_COVERAGE banner rendered when current grade is INSUFFICIENT_COVERAGE
- empty buckets omitted; non-empty rendered with summary line
- stable bucket always wrapped in `<details>`
- evidence_drift renders both JSON blocks

### 9.2 Integration test (uses `docs/samples/report-2026-04-28/`)

`tests/integration/test_diff_end_to_end.py`:

- Diff `docs/samples/report-2026-04-28/` against itself (same dir twice) →
  zero deltas, no regressions, output asserts on key strings ("Stable: N",
  empty Added section omitted, etc.).
- Diff against a synthetic "altered" copy built in `tmp_path` by the test:
  - copy the sample report;
  - mutate `findings.json` to: drop one finding (→ removed), append one
    new finding (→ added), change one finding's `severity` only (→
    severity_changed), change one finding's `evidence` only while keeping
    `(check, title)` (→ evidence_drifted);
  - mutate `combined-report.md` meta `combined_score` from sample value
    to a value 8 points lower (→ REGRESSION on combined);
  - assert exact counts in summary line + presence of each section header.
- Determinism: run the diff twice on the same inputs, assert byte-equal
  output.

### 9.3 What's NOT tested in CI

- Diff against very large reports (1000+ findings). Performance is O(n)
  fingerprint dict; not a concern for v0.4 scale.
- Locale / encoding edge cases beyond UTF-8. Reports are committed to git,
  encoding is a known constant.

---

## 10. Out of scope (deferred)

- **JSON sidecar output.** Operators with programmatic needs should
  aggregate `findings.json` directly across runs.
- **Threat-intel snapshot diff.** Drift in `threat-intel-snapshot.yaml` is
  visible via `git diff src/agentsec/audit/ioc/threat_intel.yaml` (after
  `agentsec ioc-update`); doubling that into `agentsec diff` is redundant.
- **Per-test-case remote verdict diff.** Requires aligning by test ID across
  potentially-different test suites; large surface, separate v0.5 spec if
  demand emerges.
- **`--threshold COMBINED=10 GRADE=skip` configurable thresholds.** v0.4
  ships with a single fixed threshold (5.0 / 1 grade letter). Operators can
  fork or wrap if needed.
- **GitHub PR auto-comment.** The `.github/workflows/agentsec-evaluate.yml.example`
  workflow can pipe `agentsec diff` output into `gh pr comment` separately;
  we don't take a dependency on the GitHub API in this CLI.
- **Trend over N runs (`agentsec history`).** v0.4 is two-input only.
- **Cluster strategy hints on `Check` base class.** §5.3 known gap. Address
  only if real reports show the gap mattering.

---

## 11. File / commit plan summary (for the implementation plan to expand)

New files:

- `src/agentsec/diff/__init__.py`
- `src/agentsec/diff/loader.py`
- `src/agentsec/diff/findings_delta.py`
- `src/agentsec/diff/score_delta.py`
- `src/agentsec/diff/renderer.py`
- `tests/unit/test_diff_findings_delta.py`
- `tests/unit/test_diff_score_delta.py`
- `tests/unit/test_diff_loader.py`
- `tests/unit/test_diff_renderer.py`
- `tests/integration/test_diff_end_to_end.py`

Modified files:

- `src/agentsec/cli.py` — add `diff` subcommand
- `ROADMAP.md` — tick "agentsec diff 历史趋势对比" item
- `CHANGELOG.md` — v0.4.0 entry for `agentsec diff`
- `CLAUDE.md` — append a brief `agentsec diff` section under existing CLI
  command examples
- `docs/guide/getting-started.md` — add a "Comparing two runs" subsection

No changes to `src/agentsec/scoring.py`, `src/agentsec/reports/`, or
`src/agentsec/audit/findings.py` — diff is additive.

---

## 12. Acceptance criteria

- `agentsec diff <baseline> <current>` produces deterministic markdown.
- All unit + integration tests pass; `.venv/bin/pytest -q` total ≥ 583 + new
  tests.
- `.venv/bin/ruff check src/ tests/` clean.
- Sample diff against `docs/samples/report-2026-04-28/` (vs itself) committed
  as a reference under `docs/samples/diff-2026-04-30-self/diff.md`.
- ROADMAP / CHANGELOG / CLAUDE.md / getting-started.md updated.
- 3-reviewer parallel pass before opening the PR (correctness / spec-compliance
  / security focuses), per repo convention since Stage E.
