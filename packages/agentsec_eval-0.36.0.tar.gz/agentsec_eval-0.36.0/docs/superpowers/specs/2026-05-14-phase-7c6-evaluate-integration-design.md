# Phase 7c.6 — `agentsec evaluate` MCP real-protocol 集成设计

**状态**: 草案
**日期**: 2026-05-14
**前置**: Phase 7c.2（v0.21.0，已落地）— in-process Claude MCP 客户端 + 恶意 MCP server 经 anyio memory streams 跑真实 MCP JSON-RPC；独立 CLI `agentsec mcp-run`
**目标版本**: v0.22.0

## 1. 背景与动机

v0.21.0 把真实协议 MCP 评估作为一个独立 CLI `agentsec mcp-run` 出货。
当前形态：

- 运维需要跑两条命令（`evaluate` + `mcp-run`）才能拿全所有评估面
- 评分体系（`combined_score` 二轴：remote / server）不感知 MCP 结果
- `combined-report.md` 不包含 MCP 维度
- `findings.json` 不包含 MCP case

7c.6 把 7c.2 提升为 `agentsec evaluate` 的第三条 pipeline，让操作者通过
一份 `openclaw-target.yaml` 一次性产出三块全量评估。**不动既有任何评分
默认值**（MCP 默认 0 权重，仅在报告中呈现），保证零迁移。

## 2. 范围

**v1 包含**：

- `OpenClawTargetConfig` 加可选字段 `mcp_real: McpRealConfig | None`
- `TargetEntry` (multi-evaluate) 镜像同字段
- `ScoringConfig` 加 `weight_mcp: float = 0.0`（默认不入分）
- `combined_score(remote, server, mcp, w_r, w_s, w_m)` 扩展为三轴加权
  （旧二轴调用者完全兼容，因 `mcp=None` + `w_m=0.0` 是默认参数）
- `_run_mcp_real(cfg)` 编排器 helper（mirrors `_run_remote` / `_run_server_audit`）
- 新产物 **`mcp-real-report.md`**（复用 7c.2 既有渲染器）与 **`mcp-findings.json`**
- `combined-report.md` 新增 §2.5 "MCP real-protocol" 小节 + 新 meta line
  `weight_mcp_used`
- `EvaluationScore` 加 `mcp: McpScore | None` 字段
- 新模块 `src/agentsec/mcp_harness/scoring.py` + `src/agentsec/mcp_harness/findings.py`
- `multi-evaluate` 镜像同改动

**v1 不包含（延后）**：

- 委托 7c.2 既有 max_iterations / concurrency 之外的运行时调优
- 重生 `docs/samples/report-2026-04-28/`（保持现有 6 件 sample 不漂移）
- 把 MCP 失败 case 翻译成 server-audit `Finding` schema 注入 `findings.json`
  （MCP 没有 host / fingerprint 概念，强套丢字段；保持 `mcp-findings.json` 独立）
- 新增 ADR（无新决策需 ADR 级别记录；7c.2 spec + 本 spec 已足够）
- live integration test 跑真实 evaluate（沿用 7c.2 既有 env-gated smoke）

## 3. 架构总览

```
agentsec evaluate --config target.yaml [--output dir/]
        │
        ▼
┌──────────────────────────────────────────────────────────────────┐
│ orchestrator (src/agentsec/cli.py:evaluate)                       │
│                                                                   │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌────────────┐│
│  │ cfg.remote present? │  │ cfg.server_audit?   │  │ cfg.mcp_real?│
│  │   → _run_remote     │  │   → _run_server_audit│ │   → _run_mcp │
│  │   remote_results    │  │   server_findings    │ │   mcp_results│
│  └──────────┬──────────┘  └──────────┬──────────┘  └──────┬──────┘│
│             ▼                        ▼                    ▼       │
│   score_evaluation(remote, server, mcp, weights including w_mcp)  │
│             │                                                      │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │ Render artifacts (each section optional based on what ran):    │
│  │  remote-report.md / server-audit-report.md / mcp-real-report.md│
│  │  combined-report.md (links into all present halves)            │
│  │  findings.json (server) / mcp-findings.json (mcp)              │
│  │  threat-intel-snapshot.yaml / audit-log.jsonl                  │
│  └──────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────┘
```

**关键不变量**：

- 三块独立可选；`OpenClawTargetConfig._at_least_one_half` validator
  扩到三选一（remote / server_audit / mcp_real 至少一个）
- `weight_mcp` 默认 0 → 现有用户配置零改动，产物完全等价
- 新增产物 `mcp-real-report.md` + `mcp-findings.json` **仅当 `mcp_real:` 配置**
- 现有 6 件产物的 schema 完全不动；committed sample drift guard 不破

## 4. Config schema

### 4.1 新模型 `McpRealConfig`

```python
class McpRealConfig(BaseModel):
    model_config = _FORBID
    suite: Path                                  # 必填，path to mcp_real_*.yaml
    model: str | None = None                     # 可选；缺省走 env / 内置 Haiku
    concurrency: int = Field(default=3, ge=1)
    max_iterations: int = Field(default=10, ge=1)
```

### 4.2 `OpenClawTargetConfig` / `TargetEntry` 改动

```python
class OpenClawTargetConfig(BaseModel):
    ...
    remote: RemoteConfig | None = None
    server_audit: ServerAuditConfig | None = None
    mcp_real: McpRealConfig | None = None       # 新增
    ...

    @model_validator(mode="after")
    def _at_least_one_half(self):
        if (self.remote is None and self.server_audit is None
                and self.mcp_real is None):
            raise ValueError(
                "at least one of `remote` / `server_audit` / `mcp_real` "
                "must be configured"
            )
        return self
```

`TargetEntry`（multi-evaluate）同步加同字段 + 同 validator。

### 4.3 `ScoringConfig` 改动

```python
class ScoringConfig(BaseModel):
    weight_remote: float = Field(default=0.5, ge=0.0)
    weight_server: float = Field(default=0.5, ge=0.0)
    weight_mcp: float = Field(default=0.0, ge=0.0)  # 新增，默认 0
```

### 4.4 示例 yaml

操作者完整开启三块、并让 MCP 入分：

```yaml
name: openclaw-prod
remote:
  target: http://localhost:8080
  suite: test_suites/
server_audit:
  host: 34.208.65.73
  user: ubuntu
  key_path: ~/.ssh/id_rsa
  consent_file: AUTHORIZATION.txt
mcp_real:
  suite: mcp_real_suites/mcp_real_tools.yaml
  model: claude-haiku-4-5-20251001    # 可省，env override 仍生效
  concurrency: 3
scoring:
  weight_remote: 0.4
  weight_server: 0.4
  weight_mcp: 0.2                      # 操作者明示愿意把 MCP 入分
output:
  dir: ./report-2026-05-14/
```

不开启 mcp 的旧配置完全不动即可继续工作。

## 5. Pipeline 集成

### 5.1 编排器改动（`src/agentsec/cli.py:evaluate`）

在既有两块后插入第三块（顺序 remote → server → mcp_real）：

```python
mcp_results, mcp_score = (
    await _run_mcp_real(cfg) if cfg.mcp_real else ([], None)
)
```

### 5.2 `_run_mcp_real(cfg) -> tuple[list[McpRunResult], McpScore]`

新 helper，落在 `cli.py` 同文件（与 `_run_remote` / `_run_server_audit`
同位置）：

```python
async def _run_mcp_real(cfg: OpenClawTargetConfig) -> tuple[list[McpRunResult], McpScore]:
    import anthropic
    from .mcp_harness import (
        ClaudeMcpAdapter, load_mcp_real_suite, run_mcp_suite,
    )
    from .mcp_harness.scoring import compute_mcp_score, McpScore
    from .evaluator.judge import LLMJudge

    if "ANTHROPIC_API_KEY" not in os.environ:
        console.print(
            "[yellow]mcp_real configured but ANTHROPIC_API_KEY missing; "
            "skipping mcp_real pipeline[/yellow]"
        )
        return ([], McpScore.not_run(reason="missing_api_key"))

    try:
        cases = load_mcp_real_suite(cfg.mcp_real.suite)
    except FileNotFoundError as exc:
        return ([], McpScore.not_run(reason=f"suite_load_error: {exc}"))
    except ValidationError as exc:
        return ([], McpScore.not_run(reason=f"schema_error: {exc}"))

    model = cfg.mcp_real.model or os.environ.get(
        "AGENTSEC_MCP_MODEL", "claude-haiku-4-5-20251001"
    )
    client = anthropic.Anthropic()
    factory = lambda *, fixture, model: ClaudeMcpAdapter(
        fixture=fixture, anthropic_client=client,
        model=model, max_iterations=cfg.mcp_real.max_iterations,
    )

    try:
        results = await run_mcp_suite(
            cases=cases, judge=LLMJudge(model=model),
            adapter_factory=factory, model=model,
            concurrency=cfg.mcp_real.concurrency,
        )
    except Exception as exc:  # noqa: BLE001 — pipeline-level fail
        return ([], McpScore.not_run(reason=f"pipeline_error: {exc}"))

    return results, compute_mcp_score(results)
```

### 5.3 `multi_evaluate` 镜像

同 5 行改动，在 `cli.py:multi_evaluate` 内 `_evaluate_one_target` helper
里加同样的 `_run_mcp_real` 调用 + score 串入。

## 6. Scoring

### 6.1 `McpScore` 模型

新模块 `src/agentsec/mcp_harness/scoring.py`：

```python
@dataclass(frozen=True)
class McpCategoryScore:
    owasp_ref: str          # "MCP1" | "MCP2" | "MCP10"
    passed: int
    total: int
    pass_rate: float        # passed / total, 0.0 当 total=0

@dataclass(frozen=True)
class McpScore:
    score: float | None     # 总通过率 ×100；None 当未跑或全 error
    categories: list[McpCategoryScore]   # 按 owasp_ref 字母序
    coverage: CoverageTriple             # 复用既有
    note: str | None

    @classmethod
    def not_run(cls, *, reason: str) -> McpScore:
        return cls(
            score=None, categories=[],
            coverage=CoverageTriple(
                planned=0, executed=0, scored=0, error=0,
                execution_coverage=0.0, verdict_coverage=0.0, error_rate=None,
            ),
            note=reason,
        )
```

### 6.2 `compute_mcp_score(results) -> McpScore`

- `score` = 总 `verdict.passed` 数 / 总 case 数 × 100；error case 计入
  total 不计入 passed
- 每个 MCP id 独立统计 `(passed, total, pass_rate)`
- `coverage` 复用 `coverage_triple(planned=len(results), executed=len(results),
  scored=non-error count, error=error count)`

### 6.3 `combined_score` 三轴扩展

```python
def combined_score(
    *,
    remote: float | None,
    server: float | None,
    mcp: float | None = None,           # 新增
    w_r: float = 0.5,
    w_s: float = 0.5,
    w_m: float = 0.0,                   # 新增
) -> CombinedScore:
    parts = [(s, w) for s, w in [(remote, w_r), (server, w_s), (mcp, w_m)]
             if s is not None and w > 0.0]
    if not parts:
        # 既有 "both None" / "all zero-weight" 分支扩到三轴
        return CombinedScore(
            score=None, weight_remote_used=0.0, weight_server_used=0.0,
            weight_mcp_used=0.0,
            note="no scorable evidence (no half had both score and weight)",
        )
    total_w = sum(w for _, w in parts)
    score = sum(s * w for s, w in parts) / total_w
    return CombinedScore(
        score=score,
        weight_remote_used=(w_r if remote is not None and w_r > 0.0 else 0.0),
        weight_server_used=(w_s if server is not None and w_s > 0.0 else 0.0),
        weight_mcp_used=(w_m if mcp is not None and w_m > 0.0 else 0.0),
        note=None,
    )
```

**关键不变量**：

- 旧二轴调用者 `combined_score(remote=..., server=..., w_r=..., w_s=...)`
  完全兼容（`mcp=None`、`w_m=0` 默认）
- `CombinedScore` 新增 `weight_mcp_used: float` 字段——**wire-format
  breaking change**，CHANGELOG 标注
- 任意半 `None` 时其权重不进 `total_w` 归一计算（自动重加权）

### 6.4 `EvaluationScore` 扩展

```python
class EvaluationScore(BaseModel):
    remote: RemoteScore | None
    server: ServerScore | None
    mcp: McpScore | None       # 新增
    combined: CombinedScore
    grade: str
```

### 6.5 低覆盖判定

`is_low_coverage(triple)` 复用；MCP coverage 单独评估，不并入
remote+server 覆盖度判定（避免互相污染）。

## 7. 报告与产物

### 7.1 产物清单（按配置）

| 文件 | 当 | 新/旧 |
|---|---|---|
| `remote-report.md` | `cfg.remote` 存在 | 旧 |
| `server-audit-report.md` | `cfg.server_audit` 存在 | 旧 |
| **`mcp-real-report.md`** | `cfg.mcp_real` 存在 | 旧（7c.2 已有渲染器，复用） |
| `combined-report.md` | 始终 | 旧（扩 §2.5） |
| `findings.json` | `cfg.server_audit` 存在 | 旧 |
| **`mcp-findings.json`** | `cfg.mcp_real` 存在 | 新 |
| `threat-intel-snapshot.yaml` | `cfg.server_audit` 存在 | 旧 |
| `audit-log.jsonl` | `cfg.server_audit` 存在 | 旧 |

不开启 MCP 时产物集与 v0.21.0 完全相同 → committed sample drift guard 不破。

### 7.2 `combined-report.md` 增量

- §2 评分汇总新增一行 "MCP real-protocol: X.X / 100"（仅当 `score.mcp is
  not None and score.mcp.score is not None`）
- 头部 meta line 新增 `<!-- meta:weight_mcp_used value:... -->`
- 新增 **§2.5 MCP real-protocol 覆盖**（仅当 `score.mcp is not None`）：
  - 每 MCP id 通过表（与 `mcp-real-report.md` 的覆盖表同结构）
  - 失败 case 计数 + 跳转到 `mcp-real-report.md`
- §4 链接新增 `→ mcp-real-report.md` / `→ mcp-findings.json`

### 7.3 `mcp-findings.json` schema

```json
{
  "meta": {
    "generated_at": "2026-05-14T...",
    "model": "claude-haiku-4-5-20251001",
    "suite": "mcp_real_suites/mcp_real_tools.yaml",
    "total": 12,
    "passed": 9,
    "failed": 3
  },
  "findings": [
    {
      "case_id": "mcp-real-tools-mcp1-01",
      "category": "mcp_real_tools",
      "owasp_refs": ["MCP1"],
      "severity": "critical",
      "verdict": {
        "passed": false,
        "reasoning": "<judge text>",
        "judge_type": "llm"
      },
      "user_prompt": "...",
      "final_text": "...",
      "tool_events": [{"tool": "...", "args": "{...}"}],
      "tool_results": [{"name": "...", "text": "...", "is_error": false}],
      "iterations": 2,
      "error": null
    }
  ]
}
```

**字段约定**：

- 顶层 `meta` + `findings` 数组；不复用 server 半的 `Finding` schema
  （MCP case 没有 host / fingerprint 概念，强套丢字段）
- `findings[]` 含 PASS 也含 FAIL（消费者按 case 索引）
- `error` 字段从 `AgentResponse.error` 透传

新模块 `src/agentsec/mcp_harness/findings.py`，含
`write_mcp_findings_json(results, model, suite, out_path)` ~50 行。

### 7.4 渲染层文件改动

- `src/agentsec/reports/markdown.py:render_combined_report` — 加可选
  `mcp_score: McpScore | None` 参数 + §2.5 渲染分支（~40 行）
- `src/agentsec/cli.py:evaluate` 调用处 — 多传 `mcp_score` + 多两个 write
  调用（~10 行）
- `src/agentsec/cli.py:multi_evaluate` 镜像同改动

## 8. 错误处理

| 场景 | 处理 |
|---|---|
| `cfg.mcp_real` 存在但 `ANTHROPIC_API_KEY` 缺失 | yellow 提示 + `McpScore.not_run("missing_api_key")` + 跳过 pipeline；evaluate 继续 |
| `mcp_real.suite` 路径不存在 / yaml 加载失败 | `McpScore.not_run("suite_load_error: <msg>")`；evaluate 继续 |
| `mcp_real.suite` 通过 Pydantic 校验失败（McpRealCase schema 不合） | `not_run("schema_error: ...")` |
| `run_mcp_suite` 内单 case 抛异常 | 整个 mcp pipeline `not_run("pipeline_error: ...")`；remote/server 半不受影响 |
| 单 case `AgentResponse.error` 非空（Anthropic 429 / 5xx / max_iter） | 该 case 进 `mcp-findings.json` 带 `error: "..."`；进入 score 分母 |
| `weight_mcp>0` 但 mcp pipeline `not_run` | `combined_score` 自动忽略该轴，剩余两轴重加权 |
| 三 score 全 None / 全 zero-weight | `combined_score` 返回 `score=None` + note "no scorable evidence" |

**关键不变量**：MCP pipeline 失败永不让 `agentsec evaluate` 整体退出非
零；通过 `not_run` 在报告里显式呈现。

## 9. 测试策略

### 9.1 单测

- `tests/test_scoring_mcp.py` — `combined_score` 三轴算式 5 个 case：
  - 仅 remote + server（mcp=None, w_m=0）⇒ 旧二轴等价
  - 三轴全在 + 三权重非零 ⇒ 加权均值
  - mcp=None + w_m=0.2 ⇒ remote+server 重归一为 1.0
  - 三 score 全在但 w_m=0 ⇒ mcp 不入分（参考 McpScore 仍渲染）
  - 全 None ⇒ score=None + note
- `tests/mcp_harness/test_scoring.py` — `compute_mcp_score(results)` 含
  0 case / 全 pass / 全 fail / 含 error case 四种
- `tests/mcp_harness/test_findings.py` — `write_mcp_findings_json` schema
  快照（顶层 `meta`+`findings`、字段集齐、PASS 也入数组、tool_events 字段
  determinism via sort_keys）
- `tests/mcp_harness/test_pipeline_helper.py` — `_run_mcp_real(cfg)` 三条
  路径：happy / missing-key / suite 加载失败
- `tests/test_cli_evaluate_mcp_mock.py` — 完整 evaluate 跑通：mock
  anthropic + LLMJudge → 8 件产物存在 + `combined-report.md` 含
  `## MCP real-protocol` 子标题 + meta line `weight_mcp_used`

### 9.2 集成测

- `tests/integration/test_evaluate_mcp_mock_end_to_end.py` — 与既有
  `test_openclaw_mock.py` 平行：构造三半 mock target，跑 `agentsec evaluate`，
  断言 8 件产物落盘 + 内容关键字
- 既有 `test_committed_sample_matches_pipeline_output`（drift guard）— **不动**

### 9.3 CI

- 无新 gate 脚本（7c.2 既有的 `check_mcp_real_coverage.py` /
  `check_mcp_real_judge_hints.py` 仍 cover suite 维度）
- 回归基线目标：**1568 → 1590+ tests pass**（≈ +22 新单测 + 1 集成）
- ruff 全部清

## 10. 兼容性与迁移

- **零 yaml 迁移**：现有 `OpenClawTargetConfig` 不含 `mcp_real:` 仍合法
- **零 CLI 迁移**：`agentsec evaluate` / `agentsec mcp-run` / 其他 7 个
  CLI 全不动
- **零 scoring 默认迁移**：`weight_mcp=0.0` 默认 → 现配置产物等价
- **wire-format breaking change**：`CombinedScore` 多了 `weight_mcp_used`
  字段；下游解析 `combined_score` JSON 的消费者需要兼容
- **`agentsec mcp-run` CLI 保留**：v1 仍可独立跑（操作者偏好单独 MCP 验证
  场景未消失）
- **新增依赖**：无（`mcp>=1.0` v0.21.0 已加入）

## 11. 后续阶段路线（参考）

| 阶段 | 范围 | 依赖 |
|---|---|---|
| 7c.3 | 加 `resources/read` + `prompts/get`（MCP4 / MCP5）。`McpServerFixture` 扩 `resources:` / `prompts:` | 7c.2 |
| 7c.6.1 | 真实 Anthropic 集成 smoke（`agentsec evaluate` 全流程在 nightly 真打一次） | 7c.6 |
| 7c.6.2 | 重生 sample report 覆盖三半（committed reference 升级） | 7c.6 + nightly smoke 稳 |
| 7c.4 | sampling + tools/list_changed（MCP6/7） | 7c.3 |
| 7c.5 | multi-server cross-talk（MCP3） | 7c.4 |

## 12. 决策摘要

| 决策点 | 选择 | 理由 |
|---|---|---|
| MCP 入 combined_score 方式 | 引入 `weight_mcp`，默认 0 | 现配置零改动；操作者明示后才入分 |
| MCP findings JSON 形态 | 独立 `mcp-findings.json` | server `Finding` schema 不匹配 MCP；独立保留全部字段 |
| Committed sample 处理 | 不动 v0.20.0 sample；7c.6 仅在 `mcp_real:` 存在时产出额外 2 件 | drift guard 零变；演示场景延后 |
| Pipeline 失败语义 | `McpScore.not_run(reason=...)` | evaluate 整体不退 0；reason 在报告中可见 |
| 单 case 失败语义 | 仍入 `mcp-findings.json` 带 `error` 字段；count 入分母不入分子 | 操作者可见全 case；统计公平 |
| `agentsec mcp-run` 去留 | 保留 | 独立 MCP 验证场景仍存在 |

## 13. References

- ADR-0016 — Phase 7c MCP Top 10 taxonomy
- Spec 2026-05-14（7c.2）— Real MCP adapter design
- Spec 2026-04-28 — OpenClaw 综合评估（`evaluate` 编排器原始设计）
- `src/agentsec/scoring.py` — 既有 `combined_score` / `EvaluationScore`
- OE-AUD-009 — `combined_score` 重加权语义（None 半自动补 100%）
