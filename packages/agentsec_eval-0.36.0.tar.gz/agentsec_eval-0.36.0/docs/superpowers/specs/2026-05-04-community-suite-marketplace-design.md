# Community Test-Suite Marketplace — Design Spec

**Date:** 2026-05-04
**Status:** Approved
**Target version:** v0.9.0
**Closes Roadmap item:** Phase 6 → "测试用例市场 / 社区共享"

---

## 1. Goal

Let operators install community-contributed test suites with a single command
(`agentsec suite install <name>`), then run them via `agentsec run --suite
<name>`. Bundles live in third-party GitHub repositories; a curated index in
the AgentSec main repository acts as the trust anchor.

This is the minimum viable closure of Phase 6's "marketplace" item. It
deliberately does **not** include signing, multi-source registries, suite
dependencies, or automatic upgrades — see §10 (Out of scope).

---

## 2. Scoping decisions

Three load-bearing axes were settled during brainstorming. They are recorded
here so future revisions can revisit them deliberately:

| Axis | Choice | Alternative considered | Why this one |
|---|---|---|---|
| **Distribution depth** | B — pull-style CLI | A (index doc only) / C (full registry + signing) | A has no product surface; C over-engineers without evidence of community demand |
| **Index location** | a — single YAML in main repo, thin `Registry` interface | b (separate `agentsec-community` repo) / c (configurable URL) | Single maintainer today; reusing PR review is the simplest trust mechanism. Interface keeps the door open to b/c later |
| **TI dependency policy** | a — strict (refs must exist in main `threat_intel.yaml`) | b (sidecar TI fragments) / c (no validation) | `threat_intel.yaml` drives scoring/severity; injecting unaudited TI rows would silently shift evaluation outcomes |

ADR-0005 records these decisions in canonical form.

---

## 3. CLI surface

A new `suite` Typer sub-app under `agentsec`:

| Command | Behavior |
|---|---|
| `agentsec suite list` | Show all entries in the registry index plus an `installed` column with the local version (or `—`) |
| `agentsec suite info <name>` | Print the manifest (description, authors, license, case count, required TI refs) plus the first paragraph of `README.md` if present |
| `agentsec suite install <name> [--force]` | Fetch + verify + install to `~/.agentsec/suites/<name>/` |
| `agentsec suite uninstall <name>` | Delete the local copy. No-op with exit 0 if not installed |
| `agentsec suite hash <path>` | **Hidden.** Compute the canonical hash of a local bundle directory; used by index contributors |

`agentsec run` gains a `--suite <name>` flag mutually exclusive with the
positional `path`. It resolves to `~/.agentsec/suites/<name>/cases/` and
hands that path to the existing loader.

There is intentionally **no** `update` command. To upgrade a suite, the
operator runs `uninstall` followed by `install`. This avoids a state machine
around partial upgrades and locally modified copies.

There is intentionally **no** `search` command. `list` output piped to
`grep` is sufficient at the expected registry size for the next year.

---

## 4. Bundle format

A bundle is a directory tree in a third-party GitHub repository:

```
my-suite/                       # bundle root
  manifest.yaml                 # required
  cases/                        # required, ≥1 *.yaml
    01_xxx.yaml
    02_yyy.yaml
  fixtures/                     # optional; relative paths from cases/*.yaml resolve here
    foo.html
  README.md                     # optional; info command shows the first paragraph
```

`agentsec run --suite <name>` points the existing loader at `cases/`. Fixture
paths inside YAML files (`fixture.path: fixtures/foo.html`) work unchanged
because installer copies the whole tree intact and preserves relative paths.

### 4.1 `manifest.yaml`

```yaml
schema_version: 1                       # int, bumped when schema changes incompatibly
name: openclaw-extra-pi                 # must equal registry index key; regex ^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$
version: 1.0.0                          # SemVer 2.0
description: Extra OpenClaw indirect-PI cases (13 cases)
authors:
  - name: jdoe
    url: https://github.com/jdoe        # optional
license: MIT                            # SPDX identifier
agentsec_min_version: 0.9.0             # reject install on older AgentSec
threat_refs_required:                   # all TI IDs referenced anywhere in cases/
  - TI-OPENCLAW-CVE-2026-25253
  - TI-OWASP-AGENTIC-A1
case_count: 13                          # display only; mismatch → warning, not fatal
homepage: https://github.com/jdoe/agentsec-extras  # optional
tags: [prompt_injection, openclaw]      # optional, free-form
```

`SuiteManifest` is a Pydantic model with `extra="forbid"`. Semantic checks
performed by the installer (not the model):

- `version` parses as SemVer
- `license` is in a frozen SPDX subset shipped with AgentSec
  (`src/agentsec/suite_registry/spdx_licenses.txt`, ~50 common OSS
  identifiers — MIT, Apache-2.0, BSD-2/3-Clause, GPL/LGPL/AGPL families,
  MPL-2.0, ISC, Unlicense, CC0-1.0). Avoids a runtime dependency on
  `spdx-license-list`. Updates to the subset are routine PRs.
- `name` matches the registry entry key exactly
- `agentsec_min_version` ≤ current AgentSec version
- `case_count` matches `len(cases/*.yaml)` flat-summed (warning on mismatch)

### 4.2 Registry index — `community-suites.yaml`

```yaml
schema_version: 1
suites:
  openclaw-extra-pi:
    source: github                          # only allowed value in v0.9.0
    repo: jdoe/agentsec-extras              # owner/repo
    ref: v1.0.0                             # tag, branch, or full commit SHA
    subdir: suites/openclaw-extra-pi        # bundle root within repo
    sha256: 3a7f...e9c1                     # 64-hex; canonical hash of bundle tree (see §5)
    summary: Extra OpenClaw indirect-PI cases  # short, for `suite list`
```

Lives at `src/agentsec/suite_registry/community-suites.yaml` and is shipped
inside the wheel via `[tool.setuptools.package-data]`.

`IndexEntry` is also a Pydantic model with `extra="forbid"`.

---

## 5. Canonical hash

GitHub tarballs are not byte-stable across downloads (gzip metadata, mtimes).
The registry's `sha256` therefore cannot be computed against the raw tarball.
Instead it hashes a Merkle-style manifest of the **extracted bundle subdirectory**:

```python
def canonical_hash(bundle_root: Path) -> str:
    """SHA-256 of (sorted relpath, file content hash) tuples."""
    paths = sorted(p.relative_to(bundle_root) for p in bundle_root.rglob("*") if p.is_file())
    h = hashlib.sha256()
    for rel in paths:
        h.update(b"\x00" + str(rel).encode("utf-8") + b"\x00")
        h.update(hashlib.sha256((bundle_root / rel).read_bytes()).digest())
    return h.hexdigest()
```

Properties:

- Insensitive to tarball compression, mtimes, packing order
- Sensitive to any file content change or path rename
- Pure function — fully testable without I/O once the directory is materialized

Index contributors compute their entry's hash with `agentsec suite hash
<local-path>`. Maintainers verify by re-running the same command on the
fetched copy during PR review.

---

## 6. Installer flow

```
agentsec suite install <name> [--force]

1. registry.lookup(name)
   → IndexEntry(repo, ref, subdir, sha256)
   on miss: SuiteNotInRegistry, exit 1

2. store.is_installed(name)
   if installed and not --force: SuiteAlreadyInstalled, exit 1

3. fetcher.fetch(repo, ref) → tarball bytes
   GET https://codeload.github.com/{repo}/tar.gz/{ref}
   timeout 60 s; on network/HTTP error: SuiteFetchError, exit 1

4. with tempfile.TemporaryDirectory() as tmp:
     with tarfile.open(fileobj=BytesIO(tarball)) as tf:
         tf.extractall(tmp, filter="data")  # PEP-706 data filter (Python 3.12+):
                                            # rejects absolute paths, "..", symlinks
                                            # escaping the destination, device files, etc.

5. bundle_root = tmp/<archive-prefix>/<entry.subdir>
   if not bundle_root/manifest.yaml exists:
     SuiteValidationError("entry.subdir not present in archive"), exit 1

6. computed = canonical_hash(bundle_root)
   if computed != entry.sha256:
     SuiteHashMismatch (exit 2 — distinct from generic install failure)

7. manifest = SuiteManifest.model_validate(yaml.safe_load(bundle_root/"manifest.yaml"))
   if manifest.name != entry_name: SuiteManifestError, exit 1
   if manifest.agentsec_min_version > VERSION: SuiteManifestError, exit 1

8. ti_present = set of `id` keys parsed from the wheel-bundled
   src/agentsec/audit/ioc/threat_intel.yaml (read via importlib.resources)
   missing = set(manifest.threat_refs_required) - ti_present
   if missing: SuiteTIRefMissing(missing), exit 1
   # Message includes "submit a PR adding these to threat_intel.yaml first"

9. loader.load_test_suite(bundle_root/"cases/")
   on any ValidationError: SuiteValidationError, exit 1
   # Catch schema drift before the bundle reaches the local store

10. atomic landing:
    target  = ~/.agentsec/suites/<name>/
    staging = ~/.agentsec/suites/.<name>.installing-<pid>/
    backup  = ~/.agentsec/suites/.<name>.old-<pid>/
    shutil.copytree(bundle_root, staging)

    if target.exists():       # implies --force (step 2 rejects otherwise)
        target.rename(backup)
        try:
            staging.rename(target)         # POSIX atomic
        except OSError:
            backup.rename(target)          # roll back
            raise
        shutil.rmtree(backup, ignore_errors=True)
    else:
        staging.rename(target)             # POSIX atomic

11. write {target}/.install-receipt.json:
    {"name": ..., "version": manifest.version, "ref": entry.ref,
     "sha256": entry.sha256, "installed_at": "<iso8601>"}
```

Every error path leaves `~/.agentsec/suites/` in a clean state — staging
directories are inside a `with` block on the temp dir, the rename is
atomic, and on `--force` the old version is preserved as `<name>.old`
until the new one is in place.

---

## 7. Local store layout

```
~/.agentsec/
  suites/
    openclaw-extra-pi/
      .install-receipt.json
      manifest.yaml
      cases/
        01_xxx.yaml
      fixtures/
        foo.html
      README.md
    other-suite/
      ...
```

`store.list_installed() → list[InstalledSuite]` walks this directory.
A suite directory missing or malformed `.install-receipt.json` is reported
as `corrupted` rather than crashing the command. Operators can `uninstall`
a corrupted entry to clean up.

`store.resolve(name) → Path | None` returns `<store>/<name>/cases/` when
present, used by `agentsec run --suite <name>`.

---

## 8. Module layout

```
src/agentsec/suite_registry/
  __init__.py
  community-suites.yaml         # ships in wheel
  registry.py                   # Registry ABC + DefaultRegistry (importlib.resources) + HttpRegistry
  manifest.py                   # SuiteManifest + IndexEntry (Pydantic, extra=forbid)
  fetcher.py                    # async fetch_tarball(repo, ref) -> bytes (httpx)
  hashing.py                    # canonical_hash(path) -> str
  installer.py                  # install / uninstall orchestration + typed errors
  store.py                      # InstalledSuite, list/resolve/remove, receipt I/O
  errors.py                     # SuiteError hierarchy
```

CLI changes:

```
src/agentsec/cli.py
  + suite_app = typer.Typer()
  + @suite_app.command("list") def suite_list(...)
  + @suite_app.command("info") def suite_info(name: str)
  + @suite_app.command("install") def suite_install(name: str, force: bool = False, registry_url: str | None = None)
  + @suite_app.command("uninstall") def suite_uninstall(name: str)
  + @suite_app.command("hash", hidden=True) def suite_hash(path: Path)
  app.add_typer(suite_app, name="suite")
  + run() gains --suite <name>
```

`Registry` interface:

```python
class Registry(Protocol):
    def lookup(self, name: str) -> IndexEntry | None: ...
    def all_entries(self) -> dict[str, IndexEntry]: ...

class DefaultRegistry:  # reads via importlib.resources
    ...

class HttpRegistry:     # reads from a URL; used only via --registry-url
    ...
```

---

## 9. Failure semantics

| Exception | User-facing message shape | Exit | Touches local store? |
|---|---|---|---|
| `SuiteNotInRegistry` | `Suite "X" not in registry. Run "agentsec suite list" to see available entries.` | 1 | no |
| `SuiteAlreadyInstalled` | `Suite "X" already installed (v1.0.0). Use --force to overwrite.` | 1 | no |
| `SuiteFetchError` | `Failed to fetch X@ref: <httpx error>` | 1 | no |
| `SuiteHashMismatch` | `HASH MISMATCH for X. Expected <hex>, got <hex>. The upstream archive does not match the registry's audited version. Refusing to install.` | 2 | no |
| `SuiteManifestError` | `Manifest validation failed for X: <field path>: <reason>` | 1 | no |
| `SuiteTIRefMissing` | `Suite X requires TI rows not in main repo: [TI-...]. Submit a PR adding these to src/agentsec/audit/ioc/threat_intel.yaml first.` | 1 | no |
| `SuiteValidationError` | `Test cases in X failed loader validation:\n<wrapped loader error>` | 1 | no |

Exit code `2` is reserved for `SuiteHashMismatch` because it indicates
upstream tampering or a moved tag — the operator should investigate
before retrying. All other install failures use exit `1`.

---

## 10. Out of scope (explicit YAGNI)

These are intentionally excluded from v0.9.0:

- **Signing / provenance** (minisign, sigstore). Trust anchor is the main-repo
  PR + pinned commit SHA + canonical hash; signing is a parallel mechanism,
  not a substitute, and the cost of either operating a signing key or
  integrating sigstore is large.
- **Multi-source registries** (GitLab, Codeberg, self-hosted tarball URLs).
  Adding `source: gitlab` later is a new fetcher implementation; the rest
  of the architecture is source-agnostic.
- **Suite-to-suite dependencies.** Requires a topological resolver; no
  evidence anyone needs this yet.
- **Automatic update / version-check on launch.** Re-`install` is the
  upgrade path; an upgrade nag would be UX noise.
- **Search by tag / fuzzy match.** `list | grep` is sufficient.
- **Sidecar TI fragments** (the rejected alternative for the §2 "TI
  dependency policy" axis). Would let community suites mutate the local
  TI view at install time, which conflicts with `threat_intel.yaml` being
  the integrity anchor for scoring. Re-evaluate only if a community
  contributor needs a private TI namespace and proves the use case.
- **Web UI integration.** `agentsec serve` does not show installed suites
  in v0.9.0 — independent feature.
- **Ratings / download counts / per-suite reviews.** Marketplace-flavored
  social features explicitly deferred.
- **Private or paid suites.** Out of charter for an open-source project.

---

## 11. Testing strategy

| Layer | File | Coverage |
|---|---|---|
| Pure | `tests/suite_registry/test_canonical_hash.py` | Stable across mtime/packing-order changes; sensitive to content/path changes |
| Models | `tests/suite_registry/test_manifest.py` | `extra="forbid"`, SemVer, SPDX, name regex, `agentsec_min_version` parse |
| Registry | `tests/suite_registry/test_registry.py` | `DefaultRegistry` resource lookup; missing entry; schema_version mismatch |
| Store | `tests/suite_registry/test_store.py` | `list/resolve/uninstall`, receipt I/O, corrupted-directory graceful handling |
| Fetcher | `tests/suite_registry/test_fetcher.py` | `httpx.MockTransport` for 200/404/500/timeout/partial-body |
| Installer | `tests/suite_registry/test_installer.py` | All seven typed errors + happy path + `--force` overwrite + atomic-rename interruption (`os.rename` raising `OSError`) |
| Integration | `tests/integration/test_suite_install_e2e.py` | In-memory tarball → `MockTransport` → install → `agentsec run --suite <name>` with `NoOpJudge` → assert report rendered |
| CLI | `tests/cli/test_suite_commands.py` | `list / info / install / uninstall` Typer surface |

Approximately 50 new tests. **No live HTTP** — all network calls go through
`httpx.MockTransport`, matching the existing pattern in
`tests/integration/test_ioc_update_mock_http.py`.

The integration test uses the in-repo template `examples/sample-community-suite/`
as its fixture content. This dogfoods the template — if it ever drifts out
of conformance with the manifest schema, the test fails.

---

## 12. CI integration

### 12.1 Per-PR (offline, fast)

New script `scripts/check_community_index.py`, wired into `ci.yml`:

- Parse `community-suites.yaml`
- For each entry: `IndexEntry.model_validate(...)`
- Validate `sha256` is 64 hex chars; `ref` non-empty; `subdir` is relative
- Reject duplicate `(repo, subdir)` pairs across entries
- Reject `name` ≠ entry key
- Pure static checks; no network

`scripts/check_threat_refs.py` is **not** changed. Its scope remains
`test_suites/` in the main repo. Community-suite TI validation is enforced
at install time, not commit time.

### 12.2 Weekly (online, separate workflow)

New `.github/workflows/verify-community-index.yml`:

- `on: schedule: cron: '0 4 * * 1'` (Mondays 04:00 UTC) + `workflow_dispatch`
- For each entry: fetch tarball, compute canonical hash, compare to
  registry `sha256`
- On mismatch: open a GitHub issue titled `[community-suite] hash drift:
  <name>` with expected/actual hashes and the fetch URL
- Does not block users; alerts maintainers to upstream tampering or
  moved refs

Kept separate from the main CI workflow because it requires outbound
HTTPS and is non-deterministic (depends on third-party hosting being up).

---

## 13. Documentation

| File | Action |
|---|---|
| `docs/guide/community-suites.md` | New — user guide: list/info/install/uninstall, local store path, `--force`, hash mismatch troubleshooting |
| `docs/guide/contributing-a-suite.md` | New — author guide: bundle layout, manifest schema, computing hash with `agentsec suite hash`, TI-refs PR-first rule, registry PR template |
| `docs/guide/writing-test-cases.md` | Add a one-line pointer at top to contributing-a-suite.md |
| `docs/adr/0005-community-suite-marketplace.md` | New — records the three scoping decisions from §2 |
| `README.md` | Phase 6 second item ticked; Quick Start adds `agentsec suite list` line |
| `CLAUDE.md` | New section "Community suite system (v0.9.0)" — module layout, TI strict policy, canonical-hash design, store path |
| `CHANGELOG.md` | v0.9.0 entry |
| `ROADMAP.md` | Phase 6 second item ticked with date |
| `pyproject.toml` | `0.8.0` → `0.9.0`; package-data adds `agentsec/suite_registry/community-suites.yaml` |

---

## 14. Reference template

Ship `examples/sample-community-suite/` in the main repo:

```
examples/sample-community-suite/
  manifest.yaml          # all fields populated with realistic placeholders
  cases/
    01_example.yaml      # one minimal valid TestCase, references a real TI ID
  fixtures/              # empty placeholder; README explains when fixtures matter
  README.md              # half a page; links to contributing-a-suite.md
```

Purposes:

1. Serve as a copy-paste starting point for prospective authors
2. Provide the fixture content used by `test_suite_install_e2e.py`
3. Dogfood the manifest schema — any drift breaks integration tests

The template does **not** appear in `community-suites.yaml`. The registry
ships empty in v0.9.0 — `suites: {}` — and the first real entry arrives
through the contribution flow.

---

## 15. Migration / compatibility

This is purely additive. Existing flows are untouched:

- `agentsec run test_suites/openclaw/` — unchanged
- `agentsec evaluate --config openclaw-target.yaml` — unchanged
- `agentsec multi-evaluate --config multi-target.yaml` — unchanged
- All existing test suites in `test_suites/` continue to be the bundled-with-tool
  attack library, distinct from the community marketplace

No deprecations. No config schema changes. The `--suite` flag and the
`suite` sub-app are entirely new surface area.
