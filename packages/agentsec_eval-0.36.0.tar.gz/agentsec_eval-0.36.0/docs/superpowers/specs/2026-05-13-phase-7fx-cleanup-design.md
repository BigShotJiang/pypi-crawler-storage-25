# Phase 7f.x cleanup — Docker Check make_finding 迁移 + TI 命名空间统一

| 字段 | 值 |
|------|-----|
| 阶段 | 7f.x cleanup |
| 目标版本 | v0.20.0（minor bump，含 breaking） |
| 起草日期 | 2026-05-13 |
| 上游依赖 | 7f / 7f.1 / 7f.1.1（v0.19.0 已发布到 PyPI） |
| 关联 ADR | 待写 `docs/adr/0020-7fx-cleanup.md` |

## 1. 背景

7f / 7f.1 / 7f.1.1 三阶段累积下来，存在两块技术债：

1. **`Finding(...)` vs `make_finding(...)` 写法不齐**：7f 原 3 个 Docker
   Check 是 `Check.make_finding` 上线之前写的，仍用直构造；7f.1（podman /
   containerd × 5 Check）和 7f.1.1（containerd_daemon）全部用 helper。
   未来加 Redactor pattern 时，旧 3 个 Check 不会自动覆盖。
2. **TI 命名空间与 evidence 字段不对称**：image_patterns TI 共享设计
   导致 `evidence.runtime="podman"` 的 finding 引用 `TI-DOCKER-IMAGE-...`
   而非更准确的 `TI-CONTAINER-IMAGE-...`。7f.1 final review 提出，列为
   follow-up。

本阶段一次性处理这两块债。

## 2. 范围

**In scope:**

- 3 个 Check 迁到 `self.make_finding(ctx, ...)`：
  `docker_daemon_audit` / `docker_runtime_audit` / `docker_image_cve`
- `TI-DOCKER-IMAGE-*` → `TI-CONTAINER-IMAGE-*` 硬重命名（无 alias）
- `_docker_common._image_ti_prefix` 同步改
- `container_baseline.yaml` image_patterns 段 `threat_refs` + `threat_refs_template` 同步改
- ADR-0020 + CLAUDE.md + CHANGELOG.md v0.20.0 + version bump

**Out of scope（明确不做）:**

- `daemon_*` / `runtime` TI 命名空间不改（finding 来源 runtime-specific）
- `docker_image_cve` 不重构去用 `_evaluate_image_tag` helper（保留
  `evidence.container_id` / `names` 可观测性）
- 不引入 alias / backwards-compat 机制
- 不动 7f.1 docker_*_audit 测试以外的测试结构
- 不改 sample 报告内容（mock 不触发 image findings）

## 3. 设计

### 3.1 `make_finding` 迁移

**前**：

```python
return Finding(
    check=self.id, severity=rule["severity"],
    title=rule["title"], description=rule["description"],
    evidence={"rule_id": rule_id, **extra},
    remediation=rule["remediation"],
    threat_refs=rule["threat_refs"],
)
```

**后**：

```python
return self.make_finding(
    ctx, severity=rule["severity"],
    title=rule["title"], description=rule["description"],
    evidence={"rule_id": rule_id, **extra},
    remediation=rule["remediation"],
    threat_refs=list(rule["threat_refs"]),
)
```

行为变化：`title` / `description` / `evidence` 字符串值 / `remediation`
全部过 `ctx.redactor.redact()`。**这是迁移目的**——目前 evidence 里的
`image` / `container_id` / `names` 可能带敏感前缀，未过 Redactor 是 7f
debt。

**`_emit` 辅助方法签名变化**：3 个 Check 内有 `_emit(self, rule_id, ...)`
返回 `Finding(...)`。迁移后变 `_emit(self, ctx, rule_id, ...)` 返回
`self.make_finding(ctx, ...)`。所有调用点补 ctx 传参。

### 3.2 TI 重命名

8 个 image_pattern TI id 一对一改：

| 旧 id | 新 id |
|-------|-------|
| `TI-DOCKER-IMAGE-LATEST` | `TI-CONTAINER-IMAGE-LATEST` |
| `TI-DOCKER-IMAGE-PYTHON2-EOL` | `TI-CONTAINER-IMAGE-PYTHON2-EOL` |
| `TI-DOCKER-IMAGE-NODE-EOL` | `TI-CONTAINER-IMAGE-NODE-EOL` |
| `TI-DOCKER-IMAGE-UBUNTU-EOL` | `TI-CONTAINER-IMAGE-UBUNTU-EOL` |
| `TI-DOCKER-IMAGE-DEBIAN-EOL` | `TI-CONTAINER-IMAGE-DEBIAN-EOL` |
| `TI-DOCKER-IMAGE-CENTOS-EOL` | `TI-CONTAINER-IMAGE-CENTOS-EOL` |
| `TI-DOCKER-IMAGE-ALPINE-OLD` | `TI-CONTAINER-IMAGE-ALPINE-OLD` |
| `TI-DOCKER-IMAGE-OPENCLAW-DEV` | `TI-CONTAINER-IMAGE-OPENCLAW-DEV` |

3 处同步：

1. `src/agentsec/audit/ioc/threat_intel.yaml` — 8 个 `id` 字段（声明端）
2. `src/agentsec/audit/checks/container_baseline.yaml` — image_patterns
   段 9 处 `threat_refs:` 静态字面（其中 NODE-EOL 出现 2 次：
   `node:1[0-4]*` 和 `node:1[68]*` 两个 pattern 共享）
3. `src/agentsec/audit/checks/_docker_common.py` —
   `_image_ti_prefix = "TI-" + "DOCKER"` → `"TI-" + "CONTAINER"`
   （用拼接绕开 check_threat_refs 静态扫描）

`threat_refs_template: "{prefix}-IMAGE-*"` 字段不动——模板的 `{prefix}`
是运行时 format，prefix 来源已改为 `"TI-" + "CONTAINER"`，渲染结果自动
正确。

### 3.3 文件改动布局

```
src/agentsec/audit/checks/
  docker_daemon_audit.py          # 2 处 Finding(...) → make_finding + _emit 签名加 ctx
  docker_runtime_audit.py         # 2 处 + _emit 签名加 ctx
  docker_image_cve.py             # 1 处（内联，无 _emit）+ run() 内直接传 ctx
  _docker_common.py               # _image_ti_prefix 改；docstring/注释同步
  container_baseline.yaml         # image_patterns 段 9 处 threat_refs 改

src/agentsec/audit/ioc/threat_intel.yaml
                                  # 8 行 id 改名

src/agentsec/audit/ioc/cve_database.json
                                  # scripts/build_cve_db.py 重生成

tests/
  test_docker_common.py           # 2 处 assert
  test_docker_image_cve.py        # 1 处 assert
  test_docker_daemon_audit.py     # 加 1 redactor pass-through 测试
  test_docker_runtime_audit.py    # 加 1 redactor pass-through 测试
  + 其他 grep 出来的引用点

docs/
  adr/0018-phase-7f1-podman-containerd-audit.md   # 加 1 段历史注脚
  adr/0020-7fx-cleanup.md                          # 新 ADR
  CLAUDE.md                                        # 更新 7f 段 + TI 命名说明
  CHANGELOG.md                                     # v0.20.0 breaking change 块
  docs/samples/report-2026-04-28/                  # 验证无 diff，必要时 refresh

pyproject.toml                                     # 0.19.0 → 0.20.0
```

### 3.4 验收 / CI 门禁

```bash
.venv/bin/pytest tests/ -q                            # ≥ 1536 通过 + 新增 redactor tests
.venv/bin/ruff check src/ tests/                      # 0 errors
.venv/bin/python scripts/check_threat_refs.py         # 0 未解析
.venv/bin/python scripts/build_cve_db.py --check      # 0 drift
grep -rn "TI-DOCKER-IMAGE" src/ tests/ scripts/       # 应为空
grep -rn "TI-DOCKER-IMAGE" docs/adr/                  # 应只剩 ADR-0018 历史注脚
```

### 3.5 测试增量

3 个 Check 各加 1 个测试，模式参照 7f.1 podman_*_audit 已有的
redactor-passthrough 测试。结构：

```python
def test_redactor_redacts_evidence(monkeypatch):
    """make_finding 应让 evidence 字符串值过 Redactor."""
    class _StubRedactor:
        def redact(self, s):
            return s.replace("sk-ANT", "sk-REDACTED")

    # 构造 ctx with stub redactor; mock executor returns image
    # name containing fake key prefix; assert finding.evidence['image']
    # contains "sk-REDACTED" not "sk-ANT".
```

具体每个 Check 的 stub 数据由实施时按 Check 模式填充。

## 4. 风险与回归点

### 4.1 三大风险

| 风险 | 缓解 |
|------|------|
| **漏改某处 `TI-DOCKER-IMAGE-*` 引用** — rename 不完整 → `check_threat_refs.py` 红 | rename 后立即 `grep -rn "TI-DOCKER-IMAGE" src/ tests/ scripts/` 全量搜；CI 自动卡 |
| **`_emit` 改签名打破调用点** — 漏一处 ctx 传参 → `NoneType.redactor` 崩溃 | 按 Check 一次一个 commit；每个 commit 完立即 `pytest tests/test_docker_*.py -v` |
| **外部消费者引用旧 TI id** — 社区 suite manifest / 外部 findings.json | 本 repo 内 sample 无引用（mock 不触发 image）；CHANGELOG v0.20.0 明确标 breaking；社区 suite install 时 `threat_refs_required ⊂ id` 校验会自动抓 |

### 4.2 Commit 序列（约 6-8 个，渐进）

1. `refactor(7f.x): docker_daemon_audit migrate to make_finding`
2. `refactor(7f.x): docker_runtime_audit migrate to make_finding`
3. `refactor(7f.x): docker_image_cve migrate to make_finding`
4. `refactor(7f.x): rename TI-DOCKER-IMAGE-* → TI-CONTAINER-IMAGE-* (breaking)`
5. `test(7f.x): redactor passthrough regression tests for 3 docker checks`
6. `docs(7f.x): ADR-0020 + CLAUDE.md + CHANGELOG + v0.20.0 bump`
7. （如 sample 需 refresh）`test(7f.x): refresh committed sample report`

### 4.3 发布版本

v0.19.0 → **v0.20.0**。breaking change（TI rename）按 SemVer 0.x
约定走 minor。CHANGELOG.md 头部明确 `### Breaking` 段说明
`TI-DOCKER-IMAGE-*` → `TI-CONTAINER-IMAGE-*`，并指出 daemon/runtime TI
不变。

## 5. ADR-0020 要点

记录三件事：

1. **make_finding 迁移决策**：为什么 7f 老 Check 现在才统一。背景是
   `Check.make_finding` 是 Stage D 引入的，7f 写早了；7f.1 / 7f.1.1
   全用 helper 后混合写法成为可观察债。
2. **TI 命名空间硬重命名 vs alias**：选硬重命名。理由——alias 机制
   要在 `threat_intel.yaml` 加 `aliased_to` 字段、`check_threat_refs.py`
   要双向解析、所有报告渲染要决定显示哪一边；体量翻倍且永远拆不掉。
   v0.x 阶段直接 breaking，CHANGELOG 标。
3. **rename 范围限制在 image_patterns**：daemon_* / runtime TI 命名
   `TI-DOCKER-DAEMON-*` 等保留——这些 finding 是 runtime-specific
   （docker 的 `userns-remap` ≠ podman 的 `userns="auto"`），命名准确。
   只有 image 内容跨 runtime 同源，所以才该用 `TI-CONTAINER-IMAGE-*`。
