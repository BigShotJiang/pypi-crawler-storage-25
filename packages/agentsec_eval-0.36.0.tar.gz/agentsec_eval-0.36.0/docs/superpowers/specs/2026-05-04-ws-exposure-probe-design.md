# WebSocket Endpoint Probe — Design Spec

**Date:** 2026-05-04
**Status:** Approved
**Scope:** Extend `ExposureScanCheck` to detect unauthenticated WebSocket endpoints

---

## Background

`exposure_scan` (Stage E, v0.2.0) performs TCP connect-scan against a target host and
flags ports that are open but not on the allowlist. The original implementation explicitly
deferred WebSocket endpoint probing ("Stage E v0.2.0 ships connect-scan only — WebSocket
endpoint probing is deferred to vNext"). With the cross-channel WebSocket infrastructure
now in place (PR #32), this is the natural next step.

---

## Goal

After confirming a port is TCP-open, attempt a WebSocket upgrade handshake at known paths
with **no credentials**. If the server returns `101 Switching Protocols`, the endpoint
accepts unauthenticated connections — a `high`-severity finding.

Endpoints that require authentication (return 401/403) are expected behaviour and produce
no finding.

---

## Non-Goals

- Probing with valid credentials (evaluator holds no target-agent auth tokens in audit mode)
- Detecting WS endpoints that are auth-gated (not a risk)
- Replacing or modifying the existing TCP connect-scan logic

---

## Data Flow

```
ports → TCP connect → [port not in allowlist] → Finding(medium)   ← unchanged
              ↓  (all open ports, incl. allowlisted)
         ws_probe(port, ws_paths)
              ↓  [any path returns 101]
         Finding(high, "unauthenticated WebSocket endpoint")
```

---

## Interface Changes

### New constant

```python
DEFAULT_WS_PATHS: tuple[str, ...] = ("/ws", "/v1/ws", "/")
```

### Constructor (additive, all new params optional)

```python
ExposureScanCheck(
    host: str,
    ports: Iterable[int] = DEFAULT_PORTS,
    allowlist: Iterable[int] = DEFAULT_ALLOWLIST,
    timeout_sec: float = 0.5,
    ws_paths: Iterable[str] = DEFAULT_WS_PATHS,   # NEW
    ws_probe_enabled: bool = True,                  # NEW
)
```

`timeout_sec` is reused for both TCP connect and WS handshake — WS upgrades are expected
to complete within the same wall-clock budget as a TCP connection.

### `run()` control flow

```python
async def run(self, ctx):
    findings = []
    open_ports = [p for p in self._ports if self._is_listening(p)]

    # existing TCP findings (unchanged)
    for port in open_ports:
        if port not in self._allow:
            findings.append(Finding(...severity="medium"...))

    # new WS probe
    if self._ws_probe_enabled:
        for port in open_ports:
            for path in await self._ws_probe(port):
                findings.append(Finding(...severity="high"...))

    return findings
```

---

## `_ws_probe` Implementation

```python
async def _ws_probe(self, port: int) -> list[str]:
    """Return paths where unauthenticated WS upgrade was accepted (101)."""
    import websockets
    import websockets.exceptions

    accepted: list[str] = []
    for path in self._ws_paths:
        url = f"ws://{self._host}:{port}{path}"
        try:
            async with asyncio.timeout(self._timeout):
                async with websockets.connect(url) as _ws:
                    accepted.append(path)
        except (OSError, TimeoutError, websockets.exceptions.WebSocketException):
            pass
    return accepted
```

**Exception handling:**

| Exception | Meaning | Action |
|-----------|---------|--------|
| `OSError` | TCP-level refusal (port closed mid-scan) | Silent — no finding |
| `TimeoutError` | Handshake timed out | Silent — no finding |
| `WebSocketException` | HTTP 4xx/5xx or protocol error | Silent — no finding (auth required or not WS) |

The `websockets` library is a production dependency (`pyproject.toml`: `websockets>=12.0`),
imported lazily consistent with `ws_adapter.py`.

---

## Finding Specification

### Existing TCP finding (unchanged)

```python
Finding(
    check="exposure_scan",
    severity="medium",
    title=f"Unexpected listening port: {port}/tcp on {host}",
    evidence={"host": ..., "port": ..., "transport": "tcp"},
    threat_refs=["TI-OPENCLAW-EXPOSURE"],
)
```

### New WS finding

```python
Finding(
    check="exposure_scan",
    severity="high",
    title=f"Unauthenticated WebSocket endpoint: {host}:{port}{path}",
    description=(
        f"A WebSocket upgrade at {path} on {host}:{port} was accepted "
        f"without credentials from the evaluator's network position."
    ),
    evidence={"host": ..., "port": ..., "path": ..., "transport": "ws"},
    remediation=(
        "Require authentication (e.g. token query-parameter or Authorization header) "
        "before accepting the WebSocket upgrade handshake."
    ),
    threat_refs=["TI-OPENCLAW-EXPOSURE"],
)
```

Note: a port can generate **both** a medium TCP finding and a high WS finding if it is
open and not allowlisted AND accepts unauthenticated WS. A port that is allowlisted (e.g.
18789) but leaks unauthenticated WS still generates the high WS finding.

WS findings are constructed with `Finding(...)` directly (not `make_finding`) — consistent
with the existing TCP findings in this class. Evidence values (host, port, path) are all
evaluator-controlled, not remote-stdout-derived, so `ctx.redactor.redact()` is not needed.

---

## Test Plan

All tests added to `tests/audit/checks/test_exposure_scan.py`.

| Test | Setup | Expected |
|------|-------|----------|
| `test_ws_probe_unauthenticated_high_finding` | Real WS server (`websockets.serve`) on random port, no auth | 1× `high` finding, `evidence["path"] == "/ws"`, `evidence["transport"] == "ws"` |
| `test_ws_probe_no_finding_when_port_closed` | No server, port closed | No WS finding |
| `test_ws_probe_disabled` | Real WS server, `ws_probe_enabled=False` | Only TCP finding (medium), no WS finding |
| `test_ws_probe_no_finding_when_tcp_only` | Plain TCP socket (non-WS), refuses upgrade | No WS finding (exception silenced) |

Helper: `asynccontextmanager` that starts `websockets.serve(handler, "127.0.0.1", 0)` and
yields the assigned port. Handler immediately returns (accepts connection, sends nothing).

---

## Files Changed

| File | Change |
|------|--------|
| `src/agentsec/audit/checks/exposure_scan.py` | Add `DEFAULT_WS_PATHS`, extend constructor, add `_ws_probe()`, update `run()` |
| `tests/audit/checks/test_exposure_scan.py` | Add 4 new test cases |

No new files. No new check registration. No `server_audit.py` changes.

---

## Constraints

- `exposure_scan` does not use SSH — WS probing also connects directly from the evaluator.
  Authorization is inherited from the existing `server-audit` scope (external network
  observation of the consenting target).
- `_is_listening` remains synchronous; only `_ws_probe` is async. `run()` was already
  `async` so no signature change needed.
- `make_finding` helper (from `Check` base) is used for the WS finding so evidence strings
  flow through `ctx.redactor.redact()`.
