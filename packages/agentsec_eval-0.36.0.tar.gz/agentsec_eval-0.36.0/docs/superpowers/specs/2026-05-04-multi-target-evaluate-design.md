# Multi-Target Parallel Evaluation — Design Spec

**Date:** 2026-05-04
**Status:** Approved

---

## 1. Goal

Enable a single `agentsec multi-evaluate` invocation to evaluate multiple OpenClaw
instances in parallel, producing per-target artifacts and a cross-target summary report.

---

## 2. CLI

```
agentsec multi-evaluate \
  --config multi-target.yaml \
  [--output-base ./multi-report/] \
  [--api-key KEY]
```

| Flag | Description |
|------|-------------|
| `--config` | Path to `multi-target.yaml` (required) |
| `--output-base` | Overrides `output_base` from config |
| `--api-key` | Anthropic API key; also read from `AGENTSEC_JUDGE_API_KEY` |

Exit code: `0` even when findings exist (consistent with `agentsec evaluate`).
Non-zero only on startup errors (config parse failure, no targets defined).
A target that errors at runtime is recorded as `ERROR` in the summary; other
targets continue.

---

## 3. Config Schema

### 3.1 File: `multi-target.yaml`

```yaml
output_base: ./multi-report/   # required; each target writes to output_base/<name>/
max_parallel: 4                # optional; default = len(targets); ge=1

targets:
  - name: prod
    remote:
      adapter: openclaw-gateway
      target: https://prod.example.com:18789
      token_env: OPENCLAW_PROD_KEY
      test_suites: [test_suites/openclaw/]
      concurrency: 5
    server_audit:
      host: prod.example.com
      user: ubuntu
      key: ~/.ssh/id_rsa
    authorization:
      consent_file: ./AUTHORIZATION-prod.txt
    scoring:
      weight_remote: 0.5
      weight_server: 0.5
    # output omitted → resolved to output_base/prod/

  - name: staging
    remote:
      adapter: openclaw-gateway
      target: https://staging.example.com:18789
      token_env: OPENCLAW_STAGING_KEY
      test_suites: [test_suites/openclaw/]
      concurrency: 3
    authorization:
      consent_file: ./AUTHORIZATION-staging.txt
    # output omitted → resolved to output_base/staging/
```

### 3.2 Pydantic Models (additions to `src/agentsec/config.py`)

```python
class TargetEntry(BaseModel):
    """Single target within a multi-evaluate config.

    Identical to OpenClawTargetConfig except `output` is optional; the
    resolved OutputConfig is materialized by MultiTargetConfig.model_validator.
    """
    model_config = _FORBID
    name: str
    remote: RemoteConfig | None = None
    server_audit: ServerAuditConfig | None = None
    output: OutputConfig | None = None        # None → auto-resolved
    authorization: AuthorizationConfig = Field(default_factory=AuthorizationConfig)
    scoring: ScoringConfig = Field(default_factory=ScoringConfig)

    @model_validator(mode="after")
    def _at_least_one_half(self) -> "TargetEntry":
        if self.remote is None and self.server_audit is None:
            raise ValueError(
                f"target {self.name!r}: at least one of `remote` or `server_audit` must be configured"
            )
        return self

    def to_openclaw_config(self, output_base: Path) -> "OpenClawTargetConfig":
        """Materialize into a full OpenClawTargetConfig."""
        resolved_output = self.output or OutputConfig(dir=output_base / self.name)
        return OpenClawTargetConfig(
            name=self.name,
            remote=self.remote,
            server_audit=self.server_audit,
            output=resolved_output,
            authorization=self.authorization,
            scoring=self.scoring,
        )


class MultiTargetConfig(BaseModel):
    model_config = _FORBID
    output_base: Path
    max_parallel: int = Field(default=0, ge=0)   # 0 = len(targets)
    targets: list[TargetEntry] = Field(min_length=1)

    @model_validator(mode="after")
    def _unique_names(self) -> "MultiTargetConfig":
        names = [t.name for t in self.targets]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ValueError(f"duplicate target names: {sorted(dupes)}")
        return self

    @classmethod
    def from_yaml(cls, path: Path | str) -> "MultiTargetConfig":
        text = Path(path).read_text(encoding="utf-8")
        data = yaml.safe_load(text)
        if not isinstance(data, dict):
            raise ValueError(f"{path}: config must be a YAML mapping")
        return cls.model_validate(data)

    @property
    def effective_max_parallel(self) -> int:
        return self.max_parallel if self.max_parallel > 0 else len(self.targets)
```

---

## 4. Concurrency Model

`ThreadPoolExecutor(max_workers=effective_max_parallel)` at the CLI layer.
Each worker calls `_evaluate_one_target(target_cfg, api_key, output_base)`,
which:

1. Creates the output dir (`output_base/<name>/`).
2. Calls the existing `_evaluate_remote` and `_evaluate_server` helpers from
   `cli.py` unchanged — they use `asyncio.run` internally, which is safe in a
   dedicated thread.
3. Returns a `TargetResult` dataclass.

No refactoring of the existing async internals is needed.

### `TargetResult`

```python
@dataclass
class TargetResult:
    name: str
    output_dir: Path
    score: EvaluationScore | None   # None if errored
    error: str | None               # None if success
    elapsed_seconds: float
```

---

## 5. Output Layout

```
<output_base>/
  <target-name-1>/
    remote-report.md
    server-audit-report.md
    combined-report.md
    findings.json
    threat-intel-snapshot.yaml
    audit-log.jsonl
  <target-name-2>/
    ...
  summary.md
```

`summary.md` is written last, after all targets complete.

---

## 6. Summary Report (`summary.md`)

```markdown
# Multi-Target Evaluation Summary

Generated: 2026-05-04T12:34:56Z
Targets: 3 (2 success, 1 error)

## Score Overview

| Target  | Grade | Score | Remote | Server | Critical | High | Elapsed |
|---------|-------|-------|--------|--------|----------|------|---------|
| prod    | A     | 87.3  | 88.0   | 86.5   | 0        | 2    | 4m32s   |
| staging | C     | 61.2  | 58.0   | 64.4   | 1        | 5    | 3m18s   |
| dev     | ERROR | —     | —      | —      | —        | —    | 0m05s   |

## Reports

- [prod](prod/combined-report.md)
- [staging](staging/combined-report.md)

## Errors

### dev
SSH connection refused: Connection to dev.example.com port 22: Connection refused
```

`Grade` uses `INSUFFICIENT_COVERAGE` → shown as `LOW_COV` in the table for
column width; the full string appears in the linked report.

---

## 7. New Module: `src/agentsec/reports/multi_summary.py`

Single public function:

```python
def render_multi_summary(results: list[TargetResult], generated_at: str) -> str:
    ...
```

Pure renderer, no I/O. Parallel to existing `render_combined_report` etc.

---

## 8. Error Isolation

Each target runs in an isolated thread. Exceptions are caught at the
`_evaluate_one_target` boundary:

- `AuthorizationError` → `TargetResult(error="authorization rejected: ...")`
- `typer.Exit` (raised by inner helpers) → converted to a structured error
  string before bubbling (inner helpers' `raise typer.Exit` is intercepted
  by wrapping the call in try/except)
- Any other `Exception` → `TargetResult(error=str(exc))`

The CLI exits with code `0` if at least one target succeeded and the rest
errored non-fatally. Exit `2` only if config parse fails or no targets ran.

---

## 9. Testing

### Unit tests (`tests/test_config.py` additions)

- `MultiTargetConfig` parse: valid two-target config
- `MultiTargetConfig` parse: missing `output_base` → ValidationError
- `MultiTargetConfig` parse: duplicate target names → ValidationError
- `MultiTargetConfig` parse: single target, no `output` → resolves to `output_base/name/`
- `TargetEntry.to_openclaw_config`: explicit `output` is preserved

### Unit tests (`tests/reports/test_multi_summary.py`)

- Summary with two success targets
- Summary with one success + one error target
- `LOW_COV` grade abbreviation renders correctly

### Integration test (`tests/integration/test_multi_evaluate.py`)

Mock `_evaluate_one_target` (or patch `_evaluate_remote` / `_evaluate_server`).
Two targets, verify:
- Both output dirs created
- `summary.md` written with correct table rows
- One-target-errors case: summary still written, exit code 0

---

## 10. Files Changed

| File | Change |
|------|--------|
| `src/agentsec/config.py` | Add `TargetEntry`, `MultiTargetConfig` |
| `src/agentsec/cli.py` | Add `multi_evaluate` command; extract `_evaluate_one_target` helper |
| `src/agentsec/reports/multi_summary.py` | New file: `render_multi_summary` |
| `src/agentsec/reports/__init__.py` | Re-export `render_multi_summary` |
| `tests/test_config.py` | Add `MultiTargetConfig` unit tests |
| `tests/reports/test_multi_summary.py` | New file: summary renderer tests |
| `tests/integration/test_multi_evaluate.py` | New file: integration test |
| `tests/fixtures/multi-target.example.yaml` | New fixture |
| `CHANGELOG.md` | Entry for v0.6.0 |
| `ROADMAP.md` | Tick off multi-target item |

---

## 11. Out of Scope

- Cross-target findings diff (use `agentsec diff` per target pair)
- Aggregate scoring across targets (each target scores independently)
- Streaming progress output per target (stdout interleaving would be unreadable)
