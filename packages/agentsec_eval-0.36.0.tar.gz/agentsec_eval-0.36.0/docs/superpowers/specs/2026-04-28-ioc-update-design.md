# `agentsec ioc-update` — Design

**Status:** Draft (brainstormed, awaiting implementation plan)
**Author:** Claude Opus 4.7 + Roger
**Date:** 2026-04-28
**Target version:** v0.3.0 (Phase 3 OpenClaw v1.x — first sub-task)
**Roadmap entry:** `agentsec ioc-update 自动 feed 拉取（NVD / vendor advisories / CISA KEV）`

---

## 1. Goals

Maintain `src/agentsec/audit/ioc/threat_intel.yaml` automatically by pulling from
public threat-intelligence feeds, while keeping the file's hand-curated nature
intact.

Two complementary modes, executed together by default:

- **Discovery** — find CVEs / advisories that are not yet in `threat_intel.yaml`
  but match an operator-maintained watchlist of vendor / product strings, and
  propose new entries.
- **Refresh** — for CVEs / advisories that are already in `threat_intel.yaml`,
  pull the latest authoritative data (CVSS, `affected_versions`, `fixed_in`,
  CISA KEV listing) and propose field-level updates.

**Non-goals (v0.3.0):** scheduled GitHub Actions cron, vendor-self-published RSS
feeds (Anthropic security page, MSRC, etc.), partial-accept CLI flags, mapped-tests
auto-suggestion, historical / time-series snapshots, local SQLite cache. See §7.6
for the full deferred list.

---

## 2. Architecture & pipeline

`agentsec ioc-update` is a CLI-only "proposal generator". It produces output in
a directory outside the repo (default `.cache/ioc-update-<YYYY-MM-DD>/`) and
**never** mutates files inside the repo. The operator reviews the output and,
if accepted, manually copies the proposed YAML into place and opens a PR.

```
                        ┌─────────────────────┐
                        │  watchlist.yaml     │
                        │  (vendor / product  │
                        │   / ti_prefix /     │
                        │   cve_db_include)   │
                        └──────────┬──────────┘
                                   │
       ┌───────────────────────────┼───────────────────────────┐
       │                           │                           │
       ▼                           ▼                           ▼
┌───────────────┐         ┌───────────────┐           ┌───────────────┐
│ NVDFetcher    │         │ KEVFetcher    │           │ GHSAFetcher   │
│ (per-vendor   │         │ (full catalog │           │ (per-vendor   │
│  CPE+keyword) │         │  download)    │           │  GraphQL)     │
└───────┬───────┘         └───────┬───────┘           └───────┬───────┘
        │ raw NVD records        │ KEV rows                  │ GHSA records
        ▼                        ▼                           ▼
                ┌──────────────────────────────────┐
                │  Normalizer                      │
                │  raw → canonical TI entry shape  │
                └────────────────┬─────────────────┘
                                 │ canonical entries
                                 ▼
   ┌──────────────────────────────────────────────────────────────┐
   │  Merger  (load existing threat_intel.yaml, classify each     │
   │           candidate as: NEW / REFRESH / UNCHANGED / SKIP)    │
   │  - NEW       → entire candidate added                        │
   │  - REFRESH   → only "evolving evidence" fields updated       │
   │                (skip if existing.auto_refresh == false,      │
   │                 except kev: true is always tracked)          │
   │  - UNCHANGED → no-op                                         │
   │  - SKIP      → auto_refresh: false (KEV state still tracked) │
   └────────────────────────────┬─────────────────────────────────┘
                                │
                                ▼
            ┌────────────────────────────────────────┐
            │  Renderer (writes to --output-dir):    │
            │  - proposed-threat_intel.yaml          │
            │  - report.md                           │
            │  - audit-log.jsonl                     │
            └────────────────────────────────────────┘
```

### 2.1 Module layout

New top-level package `src/agentsec/audit/ioc_update/` (sibling to the
data-only `src/agentsec/audit/ioc/`):

```
src/agentsec/audit/ioc_update/
├── __init__.py
├── watchlist.py           # WatchlistEntry (Pydantic) + loader
├── fetchers/
│   ├── __init__.py
│   ├── base.py            # Fetcher ABC, FetchResult dataclass
│   ├── nvd.py             # NVDFetcher
│   ├── kev.py             # KEVFetcher
│   └── ghsa.py            # GHSAFetcher
├── normalizer.py          # raw → canonical CanonicalEntry
├── merger.py              # 4-state classification + field-level merge
├── renderer.py            # writes the three artifacts
└── cli.py                 # entry, wired into src/agentsec/cli.py
```

### 2.2 Invariants

These must hold in every successful run; tests guard each:

- **I1.** After `ioc-update` returns, `git status --porcelain` on the repo is
  empty. Any write inside the repo tree is a defect.
- **I2.** Same input → same `proposed-threat_intel.yaml` byte-for-byte
  (deterministic). Same input → same `report.md` after masking timestamps and
  determinism-hash lines.
- **I3.** A single fetcher failure marks the run **degraded** (exit code 2) but
  still produces all three artifacts based on the surviving fetchers.
- **I4.** All fetchers failing yields exit code 1 and **does not** write
  `proposed-threat_intel.yaml` (prevents a "merge an empty file over the
  existing TI" disaster); `report.md` and `audit-log.jsonl` are still written
  for diagnostics.

---

## 3. CLI surface

```
agentsec ioc-update [OPTIONS]

Options:
  --watchlist PATH        Operator-maintained watchlist
                          [default: src/agentsec/audit/ioc/watchlist.yaml]
  --intel PATH            Existing threat_intel.yaml (used for diff)
                          [default: src/agentsec/audit/ioc/threat_intel.yaml]
  --output-dir PATH       Where to write artifacts
                          [default: .cache/ioc-update-<YYYY-MM-DD>/]
  --feeds {nvd,kev,ghsa,all}...
                          Which feeds to pull [default: all]
  --mode {discover,refresh,both}
                          [default: both]
  --offline               Skip all HTTP; read from --fixture-dir
  --fixture-dir PATH      Fixture root for --offline mode
  --nvd-api-key TEXT      NVD API key (or NVD_API_KEY env var)
  --github-token TEXT     GitHub token for GHSA (or GITHUB_TOKEN env var)
  --user-agent TEXT       HTTP User-Agent string
                          [default: agentsec-ioc-update/{version}]
  --force                 Allow non-empty --output-dir
  -v, --verbose           DEBUG logging through Redactor
  -h, --help
```

### 3.1 Exit codes

- `0` — all fetchers ok, artifacts written.
- `2` — one or more fetchers degraded; surviving fetchers' data is in the
  artifacts.
- `1` — fatal: watchlist invalid, output dir non-empty without `--force`,
  existing `threat_intel.yaml` unparseable, **or** all fetchers failed.

### 3.2 Input validation (fail fast)

Run before any fetcher fires:
1. `watchlist.yaml` parses against the Pydantic schema with `extra="forbid"`.
   Any error → exit 1, JSON-pointer-style location in stderr.
2. `--output-dir` exists and is non-empty without `--force` → exit 1.
3. Existing `threat_intel.yaml` parseable → exit 1 if not.

---

## 4. Watchlist schema

`src/agentsec/audit/ioc/watchlist.yaml` (new, version-controlled):

```yaml
# Schema for ioc-update watchlist.
# Each entry generates one or more queries against NVD / GHSA, and is used
# to filter the CISA KEV catalog.
#
# Fields:
#   ti_prefix       (required) — used to mint TI ids: TI-{ti_prefix}-CVE-{YEAR}-{SEQ}
#   vendor          (required) — used in NVD/GHSA queries
#   product         (required) — used in NVD/GHSA queries
#   cpe_pattern     (optional) — exact CPE 2.3 pattern; preferred over keyword
#   aliases         (optional) — list[str] of alt names for keyword fallback
#   ghsa_packages   (optional) — list[{ecosystem, name}] for GHSA query
#   cve_db_include  (optional, default false) — include this vendor's CVEs in
#                                cve_database.json (consumed by version_patch).

- ti_prefix: OPENCLAW
  vendor: openclaw
  product: openclaw
  cpe_pattern: "cpe:2.3:a:openclaw:openclaw:*"
  aliases: ["open claw", "openclaw labs"]
  ghsa_packages:
    - ecosystem: pip
      name: openclaw
  cve_db_include: true

- ti_prefix: ANTHROPIC-CLAUDE
  vendor: anthropic
  product: claude
  cpe_pattern: "cpe:2.3:a:anthropic:claude:*"
  aliases: ["claude code", "claude desktop"]
  ghsa_packages: []
  cve_db_include: false

- ti_prefix: MS-AGENT
  vendor: microsoft
  product: ai-agent
  cpe_pattern: "cpe:2.3:a:microsoft:ai_agent:*"
  aliases: ["microsoft ai agent"]
  ghsa_packages: []
  cve_db_include: false
```

Pydantic model:

```python
class GHSAPackage(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ecosystem: str
    name: str

class WatchlistEntry(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ti_prefix: str        # uppercase, allowed chars [A-Z0-9-]
    vendor: str
    product: str
    cpe_pattern: str | None = None
    aliases: list[str] = []
    ghsa_packages: list[GHSAPackage] = []
    cve_db_include: bool = False
```

---

## 5. Output artifacts

All three written to `--output-dir`. The repo working tree never changes.

### 5.1 `proposed-threat_intel.yaml`

Full canonical YAML produced by the merger. Operator can `diff` it against
`src/agentsec/audit/ioc/threat_intel.yaml` or `cp` it directly.

Serialization:
- **Entry order:** ascending by `id` (dictionary order). This is a one-off
  switch from the current historical-maintenance order — see §10.
- **Field order:** fixed list `[id, source, url, observed_at, claim, cvss,
  cvss_source, affected_versions, fixed_in, kev, confidence, mapped_tests,
  auto_refresh, note]`. Empty / unset fields are omitted.
- **Quoting:** `yaml.safe_dump(default_flow_style=False, sort_keys=False,
  allow_unicode=True, width=10_000)` plus a custom string representer that
  always quotes version strings (`affected_versions`, `fixed_in`).

### 5.2 `report.md`

Human-readable report. Sections:

```markdown
# IoC Update Report — 2026-04-28

**Run mode:** `both`  |  **Feeds:** `nvd, kev, ghsa`  |  **Status:** `ok`
**Watchlist:** 3 entries (openclaw, anthropic-claude, ms-agent)
**Fetched:** 142 NVD records, 1 247 KEV rows, 8 GHSA advisories
**Existing TI:** 18 entries → after merge: 21 entries

## 🆕 New discoveries (3)

### TI-OPENCLAW-CVE-2026-50012  *(KEV-listed)*
- **Source:** nvd
- **CVSS:** 9.1 (critical)
- **Affected:** `<2026.5.1`  |  **Fixed in:** `2026.5.1`
- **Claim** *(seeded from NVD; please review):* "OpenClaw arbitrary file write
  via crafted skill manifest filename traversal"
- **References:** https://nvd.nist.gov/vuln/detail/CVE-2026-50012
- **Why discovered:** matched watchlist entry `openclaw / openclaw` via CPE
  `cpe:2.3:a:openclaw:openclaw:*`

## 🔄 Refreshed (5)

### TI-OPENCLAW-CVE-2026-25253
| Field | Old | New |
|---|---|---|
| `cvss` | 8.8 | 9.1 |
| `fixed_in` | `2026.1.29` | `2026.1.31` |
| `kev` | (absent) | `true` |
| `observed_at` | 2026-04-25 | 2026-04-28 |
*(Existing claim, confidence, mapped_tests, note preserved.)*

## ⏭️ Skipped (auto_refresh: false) (1)

- `TI-OPENCLAW-CVE-2026-41342` — auto_refresh: false. NVD has new CVSS=8.5
  but operator-locked to manual values. KEV status not changed.

## ⚠️ Degraded feeds (0)

(none — all feeds returned successfully)

## Audit metadata

- **Run started:** 2026-04-28T16:30:12+08:00
- **Run finished:** 2026-04-28T16:31:48+08:00
- **NVD API key used:** yes (limit: 50/30s)
- **GitHub token used:** yes
- **Determinism check:** stable hash `sha256:f7a3...` of proposed-threat_intel.yaml
```

The "Audit metadata" section's `Run started/finished` timestamps and the
`Determinism check` hash line are non-deterministic (timestamps vary; the hash
varies if input data varies). The deterministic-test asserter (§9.3) masks
these lines before comparison.

### 5.3 `audit-log.jsonl`

One JSON event per line, machine-readable:

```jsonl
{"ts":"2026-04-28T16:30:12Z","event":"fetch_start","feed":"nvd","watchlist_entry":"openclaw"}
{"ts":"2026-04-28T16:30:14Z","event":"fetch_ok","feed":"nvd","watchlist_entry":"openclaw","records":42,"http_status":200,"response_sha256":"a83f..."}
{"ts":"2026-04-28T16:30:15Z","event":"fetch_429","feed":"nvd","watchlist_entry":"anthropic-claude","retry_after_s":6}
...
{"ts":"2026-04-28T16:31:48Z","event":"merge_summary","new":3,"refresh":5,"unchanged":13,"skipped":1}
{"ts":"2026-04-28T16:31:48Z","event":"render_complete","artifacts":["proposed-threat_intel.yaml","report.md","audit-log.jsonl"]}
```

Raw response bodies are **not** logged — only `response_sha256` integrity
fingerprints. To reproduce a specific run, an operator can re-run with
`--offline --fixture-dir <captured>`.

### 5.4 Operator workflow ("accept all")

```bash
# 1. Generate proposal
agentsec ioc-update

# 2. Review
less .cache/ioc-update-2026-04-28/report.md

# 3. Accept all → cp + rebuild + PR
cp .cache/ioc-update-2026-04-28/proposed-threat_intel.yaml \
   src/agentsec/audit/ioc/threat_intel.yaml
python scripts/build_cve_db.py
git checkout -b chore/ioc-update-2026-04-28
git add src/agentsec/audit/ioc/threat_intel.yaml \
        src/agentsec/audit/ioc/cve_database.json
git commit -m "chore(ioc): refresh threat_intel.yaml from upstream feeds (2026-04-28)"
gh pr create --fill   # paste report.md content into the PR body
```

Partial accept = manually merge selected entries from
`proposed-threat_intel.yaml` into the live file. Skipped entries reappear in
the next `ioc-update` run until either accepted or marked `auto_refresh: false`.

---

## 6. Field rules & ID generation

### 6.1 Field categories

Two categories drive the merger's behaviour:

| Field | Category | Discovery (NEW) | Refresh (existing) |
|---|---|---|---|
| `id` | identifier | machine-minted | unchanged |
| `source` | stable identity | machine writes `nvd` / `kev` / `github_advisory` | unchanged |
| `url` | evolving evidence | machine writes authoritative URL | overwritten |
| `observed_at` | evolving evidence | machine writes today | overwritten (today) |
| `claim` | stable identity | machine seeds 240-char NVD/GHSA description, suffixed `(seeded from NVD; please review)` | unchanged |
| `cvss` | evolving evidence | machine writes | overwritten (skipped if `auto_refresh: false`) |
| `cvss_source` | evolving evidence | machine writes `nvd` / `github_advisory` | overwritten |
| `affected_versions` | evolving evidence | machine writes PEP-440 specifier from CPE configurations | overwritten |
| `fixed_in` | evolving evidence | machine writes `versionEndExcluding` | overwritten |
| `kev` | evolving evidence | machine writes `true` if KEV-listed; absent otherwise (no `false`) | overwritten — including for `auto_refresh: false` entries (see §6.2) |
| `confidence` | stable identity | seeded by source: NVD → `medium`; reviewed GHSA → `high`; unreviewed GHSA → `medium`; KEV-only discovery → `high` | unchanged |
| `mapped_tests` | stable identity | machine writes `[]` | unchanged |
| `note` | stable identity | machine never writes | unchanged |
| `auto_refresh` | control | machine never writes (default `true` when absent) | unchanged |

### 6.2 `auto_refresh: false` semantics

Entries with `auto_refresh: false` are excluded from refresh — except for the
`kev` field. Rationale: KEV listing is an objective external fact, not a
valuation; locking against valuation drift should not also lock out exploit-in-
the-wild signals.

Implementation: when the merger sees an existing entry with
`auto_refresh: false`, it routes the candidate to the `SKIP` bucket but
separately compares `kev` state. If KEV is healthy and the listing has changed
relative to the existing entry, the entry is moved to `REFRESH` with **only**
`kev` and `observed_at` updated. If KEV is degraded (see §7.3), the existing
`kev` value is preserved and the entry stays in `SKIP`. The report's
"⏭️ Skipped" section calls out the KEV-only refresh case when it fires.

### 6.3 ID minting

Deterministic, given a watchlist entry and a normalized record:

```python
def mint_ti_id(watchlist_entry: WatchlistEntry, record: NormalizedRecord) -> str:
    prefix = watchlist_entry.ti_prefix
    if record.cve_id:
        suffix = record.cve_id.removeprefix("CVE-")  # CVE-2026-50012 → 2026-50012
        return f"TI-{prefix}-CVE-{suffix}"
    if record.ghsa_id:
        return f"TI-{prefix}-{record.ghsa_id}"
    raise ValueError("record has neither cve_id nor ghsa_id")
```

### 6.4 Edge cases

- **Same CVE matches multiple watchlist entries** — pick the first watchlist
  entry by file order; record other matches in `audit-log.jsonl`'s
  `merge_summary` event. One TI id per CVE.
- **CVE in KEV but NVD has no record yet** — emit a degraded entry: `source: kev`,
  `url` to the KEV catalog row, `affected_versions: null`, `claim: "Listed in
  CISA KEV; full NVD details pending"`, `confidence: high`, `kev: true`. Next
  run's refresh fills in `affected_versions` / `cvss` / etc. once NVD catches up.
- **GHSA references a CVE** — use the CVE id; `source: github_advisory`,
  `url` points to GHSA (more detail), `cvss_source: github_advisory`.
- **GHSA has no associated CVE** — fall back to `TI-{prefix}-{GHSA-...}` id.
  Such entries do **not** enter `cve_database.json` (see §6.5).

### 6.5 `build_cve_db.py` migration

Current logic hard-codes `_OPENCLAW_CVE_PREFIX`. New logic reads the watchlist
and accepts any prefix where `cve_db_include: true`:

```python
def _included_prefixes(watchlist_path: Path) -> list[str]:
    watchlist = yaml.safe_load(watchlist_path.read_text()) or []
    return [
        f"TI-{e['ti_prefix']}-CVE-"
        for e in watchlist
        if e.get("cve_db_include")
    ]

# In build()
prefixes = _included_prefixes(watchlist_path)
for entry in intel:
    if not any(entry["id"].startswith(p) for p in prefixes):
        continue
    out.append(...)
```

GHSA-only ids (`TI-{prefix}-GHSA-...`) are filtered out by the `-CVE-` literal.
`build_cve_db.py` gains a `--watchlist` flag (default
`src/agentsec/audit/ioc/watchlist.yaml`) so it shares the file with
`ioc-update` (single source of truth).

With the v0.3.0 default watchlist (only OpenClaw has `cve_db_include: true`),
the resulting `cve_database.json` is byte-identical to the v0.2.0 version. CI's
`--check` gate continues to pass without churn.

### 6.6 `kev` field consumption in `version_patch` (in scope, MVP)

`src/agentsec/audit/checks/version_patch.py` is updated so that when a TI entry
has `kev: true` and the running OpenClaw version matches `affected_versions`,
the resulting `Finding.severity` is forced to `critical` (regardless of CVSS),
and `evidence["kev"] = True` is set so reviewers can see the rationale.

```python
# After existing severity computation
if entry.get("kev") is True:
    severity = "critical"
    evidence["kev"] = True
```

Test: a synthetic TI entry with `cvss: 7.0` + `kev: true` matched against a
running version produces a `critical` finding (not `high`).

---

## 7. Error handling, auth, rate limiting

### 7.1 Auth sources

| Credential | env var | CLI flag | Missing |
|---|---|---|---|
| NVD API key | `NVD_API_KEY` | `--nvd-api-key` | NVDFetcher works at the slow rate (5 req/30s) |
| GitHub token | `GITHUB_TOKEN` | `--github-token` | GHSAFetcher uses the unauthenticated rate (60/h); 429 → degraded |
| CISA KEV | (none) | (none) | KEV is a public JSON file |

Priority: CLI flag > env var > none. **Redaction:** `audit-log.jsonl` and
`report.md` never contain credential values — only the `"api_key_used":
true/false` boolean. Verbose logs route through the existing `Redactor`
(`src/agentsec/audit/redactor.py`).

### 7.2 Rate limiting & retries

Each fetcher manages its own throttle and retry independently.

**NVD**
- Throttle: 6 s/req unauth; 0.6 s/req with key (below NVD's published limits to
  leave headroom).
- Retry on 429 / 503: exponential backoff `[1, 2, 4, 8] s`, max 4 attempts; then
  degraded.
- 5xx: same as 429.
- 4xx (non-429), e.g. 400 / 403: no retry, degraded; first 256 bytes of body
  written to `audit-log.jsonl` for triage.

**KEV**
- Single ~1 MB file download, no throttle needed.
- Retry on 5xx: backoff `[2, 4, 8] s`, max 3 attempts.

**GHSA (GraphQL)**
- Throttle: 1 req/s (GitHub-friendly default).
- Retry on 429 / 5xx: backoff `[2, 4, 8] s`, max 3 attempts.
- 401 / 403: no retry (credential invalid), degraded.

**Global timeout:** `httpx.Timeout(connect=10, read=30, write=10, pool=10)`;
timeout treated as 5xx.

### 7.3 Degradation semantics

Single fetcher exhausts retries → returns empty result set + writes
`fetch_failed` event + run is marked `degraded` (exit 2, "⚠️ Degraded feeds"
section in report).

Merger behaviour under degradation:
- **NVD degraded:** fewer NEW discoveries for that vendor; refresh still runs
  off other feeds (e.g. GHSA may also carry CVSS).
- **KEV degraded:** no KEV state evaluation. **Critical safeguard:** existing
  `kev: true` entries are NOT flipped to `false` — the merger cannot
  distinguish "KEV unavailable" from "removed from KEV", so it preserves the
  existing flag.
- **GHSA degraded:** fewer GHSA-source NEW; other feeds unaffected.

### 7.4 All fetchers degraded

If every fetcher fails, exit 1 — and `proposed-threat_intel.yaml` is **not**
written. This prevents a worst-case "merge an empty file over the existing
TI" scenario. `report.md` and `audit-log.jsonl` are still written for triage.

### 7.5 Determinism vs retries

Retries can introduce non-determinism in run timing and audit-log line counts.
Resolution:
- `proposed-threat_intel.yaml` is deterministic regardless of retry count.
- `report.md` "business sections" (New / Refresh / Skipped) are deterministic.
- `report.md` "Audit metadata" timestamps and the determinism hash line are
  not.
- `audit-log.jsonl` is not deterministic (each retry adds a line).

The deterministic-test assertion (§9.3) compares the first two and masks the
last two.

### 7.6 Out of scope (deferred to v0.3.x or later)

- ❌ Scheduled GitHub Actions cron that opens `chore/ioc-update-...` PRs.
- ❌ Vendor-self-published RSS / advisories (Anthropic security page, MSRC, etc.).
- ❌ `--apply-only TI-FOO,TI-BAR` partial-accept flag.
- ❌ `mapped_tests` auto-suggestion.
- ❌ Historical / time-series snapshots ("CVSS trended from 7.5 to 9.1").
- ❌ Local SQLite cache (current 3-entry watchlist is fast enough).
- ❌ Watchlist `priority` field for multi-match resolution (file order suffices).
- ❌ Standalone `agentsec ioc-diff` subcommand (the `report.md` already shows
  field-level diff).

---

## 8. Offline mode

`--offline --fixture-dir PATH` skips all HTTP. Fetchers read responses from
fixed files:

```
fixture-dir/
├── nvd/
│   ├── openclaw.json          # one file per watchlist entry
│   ├── anthropic-claude.json
│   └── ms-agent.json
├── kev/
│   └── catalog.json           # KEV is a single file
└── ghsa/
    ├── openclaw.json
    └── ...
```

Artifacts are still written (used for testing). The `audit-log.jsonl` records
`"offline": true`; the `report.md` header shows `**Mode:** offline (fixture
data)`.

---

## 9. Testing strategy

### 9.1 Unit tests (`tests/unit/test_ioc_update_*.py`)

- `test_watchlist.py` — Pydantic schema, missing / extra / forbidden fields.
- `test_normalizer.py` — raw → canonical mapping per fetcher; CPE
  `versionEndExcluding` / `versionStartIncluding` / multi-cpe_match edges.
- `test_merger.py` — every row of the §6.1 field table; `auto_refresh: false`
  behaviour including the KEV-only exception; multi-watchlist-match priority.
- `test_id_minter.py` — every input path including GHSA-only fallback.
- `test_renderer.py` — `proposed-threat_intel.yaml` snapshot tests; `report.md`
  rendering of empty / full / mixed inputs.

### 9.2 Integration tests, offline (`tests/integration/test_ioc_update_offline.py`)

Four parametrized scenarios:
1. **all-feeds-ok** — produces NEW + REFRESH + UNCHANGED entries.
2. **nvd-degraded** — NVD empty; merger still works on KEV/GHSA; exit 2.
3. **all-degraded** — all empty; `proposed-threat_intel.yaml` not written;
   exit 1.
4. **auto-refresh-locked** — existing entry with `auto_refresh: false` plus a
   KEV match; merger updates only `kev` + `observed_at`.

### 9.3 Determinism guard (`tests/integration/test_ioc_update_deterministic.py`)

Run `ioc-update` twice on the same fixture; assert
`proposed-threat_intel.yaml` is byte-identical. For `report.md`, mask
`Run started:` / `Run finished:` / `Determinism check:` lines before
comparison.

### 9.4 Mock-HTTP integration (`tests/integration/test_ioc_update_mock_http.py`)

Inline `httpx.MockTransport` injected into the fetchers' `httpx.Client`
factory. Verifies the real-HTTP code path with realistic NVD / KEV / GHSA
response shapes. Includes one `429 → retry → 200` scenario and one `5xx →
retries exhausted → degraded` scenario.

### 9.5 No live HTTP tests in CI

Live tests against real NVD / KEV / GHSA endpoints are deliberately not part
of CI. Reasons:
- Upstream data changes daily; assertions would be unstable.
- CI would need real `NVD_API_KEY` / `GITHUB_TOKEN` secrets.
- Network flakiness would create false-positive failures.

The "real-data smoke test" is the developer running `agentsec ioc-update`
themselves and reading the report — that is the tool's normal usage, not a
test.

### 9.6 Fixture management

`tests/fixtures/ioc-update/` — one directory per scenario, each containing the
full input set (watchlist, existing threat_intel, fetcher fixtures) and the
expected output (`expected-proposed.yaml`, `expected-report.md` with timestamps
masked).

Fixture content rule: NVD / KEV / GHSA responses are **trimmed** to the fields
the normalizer consumes. Header comments record provenance and the trimming
rule. This keeps each fixture < 1 KB and makes diff review meaningful.

Drift refresh: `AGENTSEC_REFRESH_IOC_FIXTURES=1 pytest
tests/integration/test_ioc_update_offline.py` regenerates `expected-*` files
(mirrors the Stage G `AGENTSEC_REFRESH_SAMPLE` pattern).

### 9.7 CI integration

Added to the existing `test` job:
- `pytest tests/unit/test_ioc_update_*.py tests/integration/test_ioc_update_*.py`
- `python scripts/build_cve_db.py --check` (already exists; behaviour unchanged
  by default watchlist).

---

## 10. Migration notes

### 10.1 One-off entry-order rebase

The first PR that lands an `ioc-update`-generated YAML will reorder the
existing 18 entries into dictionary order by `id`. The diff for that PR will
include 17 entry moves with no field changes (assuming no upstream data has
changed that day). Subsequent runs are stable.

Reviewer guidance for the first PR: scan for any entry whose **content**
changes (not just position). The `report.md` body is the authoritative summary
of intentional changes.

### 10.2 `version_patch` severity bump for KEV-listed CVEs

§6.6's `kev: true` → `severity: critical` rule is a behavior change. Existing
TI entries do not yet have the `kev` field, so the rule is dormant until
`ioc-update` populates it. Once a KEV match propagates, evaluate runs that
previously emitted a `high` finding may emit `critical` for the same CVE.
Document this in `CHANGELOG.md` under the v0.3.0 section.

---

## 11. Open questions

None — all design decisions confirmed with the user during brainstorming.
