# Custom Judge Interface — Design Spec

**Date:** 2026-05-04
**Status:** Approved

---

## 1. Goal

Allow operators to replace the default `LLMJudge` (Claude) with either an
OpenAI-compatible LLM backend or a fully custom Python `Judge` subclass,
configured via `openclaw-target.yaml`.

---

## 2. CLI

No new CLI commands. The existing `agentsec evaluate` and `agentsec
multi-evaluate` commands pick up the new `judge:` config section automatically.

---

## 3. Config Schema

### 3.1 New top-level field in `openclaw-target.yaml`

```yaml
# Option A — OpenAI-compatible backend
judge:
  type: openai_compatible
  model: gpt-4o
  base_url: https://api.openai.com/v1
  api_key_env: OPENAI_API_KEY     # name of env var; never inline the key
  timeout: 30                     # optional, default 30 s

# Option B — Python plugin
judge:
  type: plugin
  path: ./my_judge.py             # relative to the config file
```

Omitting `judge:` preserves existing behaviour (uses `LLMJudge` with Claude).

### 3.2 Pydantic models (`src/agentsec/config.py`)

```python
class OpenAIJudgeConfig(BaseModel):
    model_config = _FORBID
    type: Literal["openai_compatible"]
    model: str
    base_url: str
    api_key_env: str
    timeout: int = Field(default=30, ge=1)

class PluginJudgeConfig(BaseModel):
    model_config = _FORBID
    type: Literal["plugin"]
    path: Path

JudgeConfig = Annotated[
    OpenAIJudgeConfig | PluginJudgeConfig,
    Field(discriminator="type"),
]
```

`OpenClawTargetConfig` gains:

```python
judge: JudgeConfig | None = None
```

`extra="forbid"` applies at every level — typos in `judge:` keys fail at load
time.

---

## 4. New Judge Classes

### 4.1 `OpenAICompatibleJudge` (`src/agentsec/evaluator/openai_judge.py`)

Implements the `Judge` ABC. Uses `httpx.AsyncClient` to call
`POST {base_url}/chat/completions`.

**System prompt:** imports `_SYSTEM` from `judge.py` — same prompt, same
versioning guarantees.

**Request body:**

```json
{
  "model": "<config.model>",
  "messages": [
    {"role": "system", "content": "<_SYSTEM>"},
    {"role": "user",   "content": "<built by _build_user>"}
  ],
  "temperature": 0
}
```

`_build_user` logic is identical to `LLMJudge._build_user` (attack payload,
agent response, expected behavior, optional hint).

**Response parsing:** extracts `choices[0].message.content`, JSON-parses it
for `{"passed": bool, "reasoning": str}`.

**Error handling:**

| Condition | Result |
|-----------|--------|
| HTTP non-2xx | `passed=False, reasoning="http error {status}: ..."` |
| `httpx.TimeoutException` | `passed=False, reasoning="request timeout"` |
| Any `httpx` transport error | `passed=False, reasoning="request error: ..."` |
| Response not valid JSON | `passed=False, reasoning="parse error: ..."` |
| JSON missing `passed` / `reasoning` | `passed=False, reasoning="parse error: missing fields"` |

All error paths return a valid `JudgeVerdict` — evaluation continues.

**Constructor:**

```python
def __init__(self, config: OpenAIJudgeConfig) -> None:
    api_key = os.environ.get(config.api_key_env)
    if api_key is None:
        raise ValueError(
            f"environment variable {config.api_key_env!r} is not set"
        )
    self._config = config
    self._api_key = api_key
```

`ValueError` is raised at construction time (startup), not at evaluation time.

### 4.2 `PluginJudge` (`src/agentsec/evaluator/plugin_judge.py`)

A thin wrapper that dynamically loads a user-supplied `.py` file and delegates
to the `Judge` subclass found inside.

**Loading algorithm:**

1. Resolve `path` relative to the config file's parent directory.
2. `importlib.util.spec_from_file_location` + `exec_module`.
3. Scan the module's namespace for classes that are subclasses of `Judge` and
   are not `Judge` itself.
4. Zero subclasses → `ValueError(f"{path}: no Judge subclass found")`.
5. More than one subclass → `ValueError(f"{path}: ambiguous — found: {names}")`.
6. Instantiate the found class with no arguments; store as `self._delegate`.

**`evaluate` method:** delegates directly to `self._delegate.evaluate(...)`.

**Constructor raises `ValueError`** on file-not-found or discovery failure —
the CLI converts this to `typer.Exit(1)`.

---

## 5. JudgeRouter Integration

### 5.1 No changes to `JudgeRouter.__init__`

`JudgeRouter` already accepts a `llm: Judge` parameter. The CLI constructs
the correct `Judge` instance and passes it in.

### 5.2 New helper `_build_llm_judge` in `cli.py`

```python
def _build_llm_judge(cfg: OpenClawTargetConfig, api_key: str | None) -> Judge:
    """Return the appropriate LLM-slot judge for the given config."""
    judge_cfg = cfg.judge
    if judge_cfg is None:
        return LLMJudge(api_key=api_key)
    if isinstance(judge_cfg, OpenAIJudgeConfig):
        return OpenAICompatibleJudge(judge_cfg)
    if isinstance(judge_cfg, PluginJudgeConfig):
        resolved = (Path(cfg._config_path).parent / judge_cfg.path).resolve()
        return PluginJudge(resolved)
    raise AssertionError(f"unhandled judge config type: {type(judge_cfg)}")
```

`cfg._config_path` is the path from which the config was loaded (added to
`OpenClawTargetConfig` as a non-validated private attribute, set by
`OpenClawTargetConfig.from_yaml`).

The existing `JudgeRouter(llm=LLMJudge(...), ...)` call in `_evaluate_remote`
becomes `JudgeRouter(llm=_build_llm_judge(cfg, api_key), ...)`.

---

## 6. `OpenClawTargetConfig` additions

`from_yaml` stores the file path so `_build_llm_judge` can resolve relative
plugin paths:

```python
@classmethod
def from_yaml(cls, path: Path | str) -> "OpenClawTargetConfig":
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    data = yaml.safe_load(text)
    ...
    obj = cls.model_validate(data)
    object.__setattr__(obj, "_config_path", path)   # bypass Pydantic validation
    return obj
```

`_config_path` is not a Pydantic field — it is set via `object.__setattr__`
after validation to avoid `extra="forbid"` rejection. Only used by
`_build_llm_judge`; never serialised or logged.

---

## 7. Error Handling Summary

| Scenario | Where caught | Result |
|----------|-------------|--------|
| `api_key_env` not in environment | `OpenAICompatibleJudge.__init__` | `ValueError` → CLI prints error, exits 1 |
| Plugin file not found | `PluginJudge.__init__` | `ValueError` → CLI prints error, exits 1 |
| No `Judge` subclass in plugin | `PluginJudge.__init__` | `ValueError` → CLI prints error, exits 1 |
| Multiple `Judge` subclasses | `PluginJudge.__init__` | `ValueError` → CLI prints error, exits 1 |
| OpenAI HTTP error / timeout | `evaluate()` | `JudgeVerdict(passed=False, reasoning="...")` |
| OpenAI malformed response | `evaluate()` | `JudgeVerdict(passed=False, reasoning="parse error: ...")` |

---

## 8. Testing

### `tests/test_openai_judge.py`

Uses `httpx.MockTransport` (already in test dependencies via `httpx`).

- Success: `passed=True` response parsed correctly
- Success: `passed=False` response parsed correctly
- HTTP 500 → `passed=False`, reasoning contains "http error"
- Response body is not JSON → `passed=False`, reasoning contains "parse error"
- Response JSON missing `passed` field → `passed=False`, reasoning contains "parse error"
- `httpx.TimeoutException` → `passed=False`, reasoning == "request timeout"
- Constructor raises `ValueError` when env var is absent

### `tests/test_plugin_judge.py`

Uses `tmp_path` to write temporary plugin files.

- Valid plugin (one `Judge` subclass) loads and `evaluate()` delegates correctly
- File not found → `ValueError`
- Module with no `Judge` subclass → `ValueError` matching "no Judge subclass found"
- Module with two `Judge` subclasses → `ValueError` matching "ambiguous"

### `tests/test_config_model.py` additions

- `OpenAIJudgeConfig` parse: valid config
- `OpenAIJudgeConfig` parse: missing `model` → `ValidationError`
- `PluginJudgeConfig` parse: valid config
- `OpenClawTargetConfig` with `judge: {type: openai_compatible, ...}` parses correctly
- `OpenClawTargetConfig` with `judge: {type: plugin, ...}` parses correctly
- `OpenClawTargetConfig` with unknown `judge.type` → `ValidationError`

### `tests/test_cli_judge_router.py` additions

- `_build_llm_judge` with `cfg.judge = None` returns `LLMJudge`
- `_build_llm_judge` with `OpenAIJudgeConfig` and env var set returns `OpenAICompatibleJudge`
- `_build_llm_judge` with `OpenAIJudgeConfig` and env var absent raises `ValueError`
- `_build_llm_judge` with `PluginJudgeConfig` pointing to a valid plugin returns `PluginJudge`

---

## 9. Files Changed

| File | Change |
|------|--------|
| `src/agentsec/config.py` | Add `OpenAIJudgeConfig`, `PluginJudgeConfig`, `JudgeConfig`; add `judge` field to `OpenClawTargetConfig`; store `_config_path` in `from_yaml` |
| `src/agentsec/evaluator/openai_judge.py` | New: `OpenAICompatibleJudge` |
| `src/agentsec/evaluator/plugin_judge.py` | New: `PluginJudge` |
| `src/agentsec/cli.py` | Add `_build_llm_judge`; wire into `_evaluate_remote` |
| `tests/test_openai_judge.py` | New: 7 tests |
| `tests/test_plugin_judge.py` | New: 4 tests |
| `tests/test_config_model.py` | 6 new test cases |
| `tests/test_cli_judge_router.py` | 4 new test cases |
| `CHANGELOG.md` | Entry for v0.8.0 |
| `ROADMAP.md` | Tick off custom judge item |

---

## 10. Out of Scope

- Replacing `DeterministicJudge` or `HybridJudge` (custom logic only applies to the LLM slot)
- Streaming responses from OpenAI API
- Per-test-case judge selection (judge is configured per target, not per test)
- Plugin hot-reload (plugin is loaded once at startup)
