# Phase 7d — npm 供应链审计 Check 设计

**日期**：2026-05-09
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0012；前置 ADR-0010（7f）/ ADR-0011（7e.2）。

## 1. 目标

`agentsec server-audit` 现有 24 类 Check 中 `version_patch` 只覆盖
OpenClaw 自身版本对照 TI-OPENCLAW-CVE-* 的命中，**不**审计
OpenClaw 的依赖树。Phase 7d 引入第一个真正意义上的供应链审计
Check，按 npm `package-lock.json` 的 transitive 依赖列表，匹配 OSV
（osv.dev）的 npm advisory 子集，emit 已知漏洞 finding。

ROADMAP `Phase 7d` 原文：「Skills / Plugins 深化（osv.dev / supply
chain）」。本 phase 只覆盖括号里的 `osv.dev / supply chain`，
不动 `plugin_static`（Skills 静态扫描）—— 那是后续 7d.x 的工作面。

## 2. 范围

新增 1 个 Check + 1 个 OSV fetcher + 1 个 bundled DB + 1 条 TI
umbrella entry：

| 组件 | id / 路径 | 职责 |
|---|---|---|
| `SupplyChainAuditCheck` | `supply_chain_audit` | 读被审主机 npm `package-lock.json`，按 (name, version) 匹配 OSV-npm DB，每个命中 1 条 Finding |
| OSV-npm fetcher | `src/agentsec/audit/ioc_update/fetchers/osv_npm.py` | `agentsec ioc-update` 子流程：拉 `https://osv-vulnerabilities.storage.googleapis.com/npm/all.zip`，过滤、归一化、写 `osv_npm.json` |
| Bundled DB | `src/agentsec/audit/ioc/osv_npm.json` | 提交到 git，wheel 打包随发；CI `--check` 验证一致性 |
| TI umbrella | `TI-OSV-NPM-CATALOG`（在 `threat_intel.yaml`） | supply_chain finding 的 `threat_refs` 引用，避免破坏现有强 TI 校验 |

**首期范围**：

- **生态**：仅 npm。Python / Go / Rust 留给 7d.1 / 7d.2 后续。
- **manifest**：仅 `package-lock.json`（v2/v3 schema，含完整
  transitive 树）。`package.json` 单独不读（缺 transitive、版本范围
  而非锁定）。
- **路径**：profile 注入 `npm_root` 候选（默认
  `~/.npm-global/lib/node_modules/openclaw/`）。多 npm 安装（项目本地
  `node_modules/`）不在首期扫。

**out of scope**：

- 在线 osv.dev 查询（架构选 offline）
- pip / go / rust / cargo 等其他 ecosystem
- macOS 特殊路径（profile 共享 `npm_root`，macOS 候选可后期加）
- yarn.lock / pnpm-lock.yaml（schema 不同；OpenClaw 用 npm，单点收敛）
- skill 自己带的 `node_modules`（如 Skill 自打依赖；7d.x 如需要再加）

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  supply_chain_audit.py             # 新 — Check 主体
src/agentsec/audit/ioc/
  osv_npm.json                      # 新 — bundled DB（gzip 压缩前估 5–10 MB）
  threat_intel.yaml                 # 现有，追加 TI-OSV-NPM-CATALOG
src/agentsec/audit/ioc_update/fetchers/
  osv_npm.py                        # 新 — OSV-npm 抓取 + 归一化
src/agentsec/audit/ioc_update/
  cli.py                            # 现有，注册新 fetcher
src/agentsec/audit/platform_profile.py   # 现有，加 npm_root 路径键到 LINUX / LINUX_USER_MODE
src/agentsec/audit/ssh_policy.yaml       # 现有，加 npm_root prefix（cat 形态已具）
src/agentsec/cli.py                      # 现有，注册 SupplyChainAuditCheck（两处）
scripts/check_osv_npm.py                 # 新 — CI 一致性 + 体积 ≤ 15 MB 守门
tests/test_supply_chain_audit.py
tests/test_osv_npm_fetcher.py
tests/fixtures/supply_chain/
  package-lock-clean.json
  package-lock-vulnerable.json
  osv_npm_subset.json
tests/fixtures/osv/npm/
  # 6 个 OSV 真实 advisory JSON 截取，对应 §9.2 六类归一化测试 case：
  # normal-cvss / withdrawn / cross-ecosystem / no-npm-affected /
  # git-range-no-semver / cvss-missing
docs/adr/0012-phase-7d-supply-chain.md
docs/superpowers/specs/2026-05-09-phase-7d-supply-chain-design.md
```

新增文件量级：5（源码 + DB） + 4（test + fixture 目录） + 2（ADR/spec）
+ 1（CI 脚本） = 12，外加 1 个 PlatformProfile 字段 + 1 个新 PyPI
依赖（`semver>=3,<4`）。

### 3.2 平台 gating

`SupplyChainAuditCheck` 在 `run()` 顶部判断
`ctx.profile.name in ("linux", "linux_user_mode")`，非 Linux profile
标 `not_applicable` 直接返。macOS profile 暂不支持（npm 路径与权限模型
不同；7d.x 后续）。

### 3.3 `_REQUIRED_PATHS = ("npm_root",)`

走与 `world_writable` 不一样的口径——**强依赖** `npm_root` profile
path：拿不到就 `not_applicable`。原因：本 Check 没有 npm_root 就完全
没事可做（不像 world_writable 还能扫 cron 目录）。

`PlatformProfile.LINUX` / `LINUX_USER_MODE` 都加
`paths["npm_root"] = "~/.npm-global/lib/node_modules/openclaw"`
（默认 Lightsail prod 形态）。`materialize_paths` 已有的 `~` 展开
机制会把它转成绝对路径。

### 3.4 OSV DB 加载（class `__init__` 时一次性）

```python
_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_npm.json"

class SupplyChainAuditCheck(Check):
    id = "supply_chain_audit"
    _REQUIRED_PATHS = ("npm_root",)

    def __init__(self):
        super().__init__()
        # raw schema: list of advisories（schema 见 §5.3）
        raw = json.loads(_OSV_DB_PATH.read_text())
        self._advisories_by_pkg: dict[str, list[dict]] = {}
        for adv in raw:
            self._advisories_by_pkg.setdefault(adv["package"], []).append(adv)
```

按 package name 索引，audit-time 用
`self._advisories_by_pkg.get(pkg_name, [])` O(1) 取候选。

如果 wheel 里 DB 文件缺失（不该发生）或 JSON 损坏 → `__init__` 抛异常，
Check 永远跑不起来，运行时由 orchestrator 报告 fixture 错误。

### 3.5 `run()` 顶部模板

```python
async def run(self, ctx):
    if ctx.profile.name not in ("linux", "linux_user_mode"):
        ctx.status.not_applicable(f"{self.id}：非 Linux profile")
        return []
    if not self.check_required_paths(ctx):  # base 类已设 not_applicable
        return []

    npm_root = ctx.profile.paths["npm_root"]   # 已 materialize
    lock_path = f"{npm_root}/package-lock.json"
    result = ctx.executor.run(["cat", lock_path])

    if result.rejected:
        ctx.status.skipped(f"{self.id}：cat 被策略拒绝 ({result.reject_reason})")
        return []
    if result.exit_code != 0:
        ctx.status.not_applicable(
            f"{self.id}：{lock_path} 不可读（npm 安装路径不在 npm_root 候选）"
        )
        return []
    # —— 解析 + 比对 + emit findings ——
```

### 3.6 不需要的东西

- **不需要 root**：`package-lock.json` 是 owner=ubuntu 的世界可读文件
  （npm 全局安装的标准权限）。与 firewall 的 best-effort 不同，
  supply_chain 默认就能跑。
- **不需要 backend 探测**：npm CLI 本身可以不存在（这台主机不一定装
  了 npm），我们只读 lock 文件，不调用 `npm` 命令。
- **不需要网络**：DB 已 bundled。

## 4. 组件细节

### 4.1 命令面

唯一一条 SSH 命令：

```
cat <npm_root>/package-lock.json
```

policy 上 `cat` 已经是通用形态（`role: positional, kind: path,
must_match_allowed_paths: true`）。只要 `<npm_root>/` 落进
`allowed_paths`（§5），自然通过。

### 4.2 lock-file 解析

`package-lock.json` v2/v3 schema 把所有 transitive deps 平铺在顶层
`packages` map，键是相对路径形如 `"node_modules/lodash"`、
`"node_modules/express/node_modules/qs"`，值含 `version` 字段。
顶层 `""` 键是 OpenClaw 自己。

```python
def parse_npm_lock(stdout: str) -> list[tuple[str, str]]:
    """Return [(pkg_name, version)] from package-lock.json v2/v3.
       Skip the root entry (key=='') and any 'link' entries (workspace links)."""
    data = json.loads(stdout)
    pkgs: list[tuple[str, str]] = []
    for path_key, entry in data.get("packages", {}).items():
        if path_key == "":
            continue                       # root project itself
        if entry.get("link"):
            continue                       # workspace symlink, no version
        version = entry.get("version")
        if not version:
            continue
        # path_key 'node_modules/foo/node_modules/bar' → bar
        # 'node_modules/@scope/pkg' → @scope/pkg
        parts = path_key.split("node_modules/")
        name = parts[-1]                   # last segment after final 'node_modules/'
        pkgs.append((name, version))
    return pkgs
```

仅支持 lockfile schema v2 / v3（`lockfileVersion >= 2`）。v1 是非常老
的形态（npm <7），现实里 OpenClaw 不会用。schema v1 → 解析返 0 包
→ 0 finding（不报错；信号留在 audit log）。

### 4.3 OSV 匹配（每包查 DB）

```python
def _advisories_for(self, pkg: str, version: str) -> list[dict]:
    candidates = self._advisories_by_pkg.get(pkg, [])
    return [adv for adv in candidates if _version_in_any_range(version, adv["ranges"])]


def _version_in_any_range(version: str, ranges: list[dict]) -> bool:
    """Each range entry: {'introduced': '0', 'fixed': '4.17.21'} (semver)
       or {'introduced': '4.17.0', 'last_affected': '4.17.20'} (rare in npm)."""
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last  = r.get("last_affected")
        if _semver_lt(version, intro):
            continue
        if fixed and not _semver_lt(version, fixed):
            continue                       # version >= fixed, safe
        if last and _semver_gt(version, last):
            continue
        return True
    return False
```

**semver 比较器**：`pip install semver` 库（纯 Python，无外部依赖），
暴露 `semver.Version.compare()`。`pyproject.toml` `[project]
dependencies` 加 `semver>=3,<4`。npm semver 与 PEP 440 有差异
（prerelease 排序、`-beta.4` 处理），不能用 `packaging.Version`。

`semver` 解析单个 version 失败（比如 `"file:../foo"` 这种非 semver
字符串），跳过该包但记一条 low-severity audit-trail finding：
「无法解析的 semver」（避免静默丢漏检）。

### 4.4 Finding 粒度

每条命中的 (pkg, version, advisory) 一条 Finding：

```
title:    "npm {pkg}@{version} 命中 {advisory_id}（severity={sev}）"
severity: critical | high | medium | low（来自 advisory.severity，缺省为 medium）
description: advisory.summary  # OSV 自带的 1-句摘要
evidence: {
  package: pkg,
  version: version,
  advisory_id: "GHSA-xxxx-xxxx-xxxx",
  aliases: ["CVE-2025-12345", ...],
  fixed_in: "4.17.21",
  url: "https://github.com/advisories/GHSA-xxxx-xxxx-xxxx",
  npm_root: <materialized npm_root>,
}
remediation: "npm upgrade {pkg}@{fixed_in}（或更高版本）"
threat_refs: ["TI-OSV-NPM-CATALOG"]
```

不去重：同一个包多个 advisory 命中 → 多条 finding（fingerprint 因
advisory_id 不同而唯一，与 7f Docker `docker_image_cve` 多 pattern
同模式）。

**严重度映射**：OSV severity 字段优先用 `severity[0].score`（CVSS v3
vector），按 base score 折算：

- ≥ 9.0 → critical
- ≥ 7.0 → high
- ≥ 4.0 → medium
- 其他 → low
- 字段缺失（OSV 没给 CVSS）→ medium（保守默认；不是 low，避免高危
  被低估）

### 4.5 预期 finding 数量级

OpenClaw 全局 npm 安装大概 200–500 个 transitive 依赖。OSV-npm DB
命中率经验值 1–5%，所以一台典型主机 ~5–25 条 supply_chain finding。
Lightsail prod 可作为校准基准。

## 5. SSH policy 扩展

`allowed_paths` 追加 1 条 prefix（用 prefix kind 让该目录下所有
文件——包括 `package-lock.json`、子 `node_modules/*/package.json`
——可读，给 7d.x 后续扩展 transitive 实体扫描留空间）：

```yaml
- {kind: prefix, path: "~/.npm-global/lib/node_modules/openclaw/"}
```

`~` 在 `ssh_policy.yaml` 加载时由 `PathMatcher(rules,
remote_home=...)` 在 orchestrator 启动时按 remote `$HOME` 展开（与
`~/.openclaw/` 等现有 prefix 同机制，ADR-0004）。本地 evaluator 自身
的 `$HOME` 不影响校验。

**不需要其他改动**：

- `cat` 命令面不变（`role: positional, kind: path,
  must_match_allowed_paths: true` 已存在）
- 不引入新 `commands:` 块（这次没有 npm CLI 调用）
- 不引入新 argv schema

**安全审视**：新加的 prefix 是 `~/.npm-global/lib/node_modules/openclaw/`，
不是 `~/.npm-global/`。范围严格收敛在 OpenClaw 安装目录内——operator
自己 `npm i -g` 的别的包不会被读到。这与 7e.1 final review 留的
「`/usr/bin/`、`/etc/systemd/system/` prefix 过宽」教训正相反，本次
刻意守住边界。

后续如需扫**项目本地 `node_modules/`**（即 `$cwd/node_modules`，不在
npm_root 下），需要再加 profile 路径键 + allowed_paths 入口。本期不
做。

## 6. OSV-npm fetcher（`agentsec ioc-update` 子流程）

新增文件 `src/agentsec/audit/ioc_update/fetchers/osv_npm.py`，与现有
NVD / KEV / GHSA fetcher 同构。

### 6.1 数据源

- **URL**：`https://osv-vulnerabilities.storage.googleapis.com/npm/all.zip`
  - OSV 官方提供的 npm ecosystem 全量导出，每天重生
  - 无需鉴权、无 rate limit
  - 体量：~7–10 MB zip，解压后约 30–60 MB（每 advisory 一个 JSON 文件）

### 6.2 抓取流程

```python
class OsvNpmFetcher(Fetcher):
    name = "osv_npm"
    URL = "https://osv-vulnerabilities.storage.googleapis.com/npm/all.zip"

    async def run(self, ctx, entries) -> dict[str, FetchResult]:
        # 1. httpx GET zip → bytes
        # 2. zipfile.ZipFile(BytesIO(content)) → 遍历每个 .json
        # 3. 对每个 OSV entry 应用 _normalize() —— 见 6.3
        # 4. 返回 {"_osv_npm_full": FetchResult(payload=normalized_list)}
        #    —— 单条 sentinel-keyed result；NVD/KEV fetcher 是按 entry-id
        #    分发增量结果，OSV-npm 是全量替换、用单 key 表达。
        # 5. ioc-update CLI 拿到 payload 后写 .cache/ioc-update-<date>/
        #    proposed-osv_npm.json，operator 复制到 src/agentsec/audit/ioc/。
```

`Fetcher` 抽象基类已存在，签名统一。

### 6.3 归一化（compact schema）

OSV 原始 entry 字段多（30+），大多与 supply_chain Check 无关。归一化
到精简 schema 控制 bundle size：

```python
def _normalize(osv_entry: dict) -> dict | None:
    """Return compact schema, or None if the entry is unusable
       (no npm package, no version range, withdrawn, etc.)."""
    affected_npm = [
        a for a in osv_entry.get("affected", [])
        if (a.get("package") or {}).get("ecosystem") == "npm"
    ]
    if not affected_npm:
        return None
    if osv_entry.get("withdrawn"):
        return None
    pkg = affected_npm[0]["package"]["name"]
    ranges = _extract_semver_ranges(affected_npm[0].get("ranges", []))
    if not ranges:
        return None
    severity = _extract_severity(osv_entry.get("severity", []))
    return {
        "id": osv_entry["id"],                          # GHSA-xxxx... or PYSEC- if cross-ecosystem alias
        "package": pkg,
        "ranges": ranges,                               # [{"introduced": "0", "fixed": "4.17.21"}]
        "severity": severity,                           # critical|high|medium|low
        "summary": osv_entry.get("summary", "")[:200],  # truncate to control size
        "url": f"https://github.com/advisories/{osv_entry['id']}",
        "aliases": osv_entry.get("aliases", []),
    }
```

**filter rules**（缩小 bundle）：

- 跳过 `withdrawn` advisory
- 跳过没有 npm `affected` 的（OSV 可能含跨生态 alias）
- 跳过没有可解析 semver range 的（GIT type 等罕见 range）
- 同 OSV-id 出现多次 → 只保留首条

预计归一化后剩 5000–8000 条 advisory，JSON 体量 5–10 MB。

### 6.4 输出文件

`src/agentsec/audit/ioc/osv_npm.json` —— **稳定排序**（按 advisory id
字典序）以便 git diff 友好且 `--check` 模式能 byte-diff。结构
`[advisory, advisory, ...]`，flat 数组（运行期 Check 自己建 by-pkg
index，§3.4）。

### 6.5 fetcher 注册 + 运维流程

`src/agentsec/audit/ioc_update/cli.py:_run_fetchers` 注册
`OsvNpmFetcher`。`agentsec ioc-update` 单次执行新增产物
`.cache/ioc-update-<date>/osv_npm.json`，operator 复制到
`src/agentsec/audit/ioc/osv_npm.json` 后 `git diff` 审视、commit。

## 7. Threat Intel 处理

### 7.1 TI umbrella entry

`src/agentsec/audit/ioc/threat_intel.yaml` 追加 1 条 stub：

```yaml
- id: TI-OSV-NPM-CATALOG
  source: osv
  url: https://osv.dev/list?ecosystem=npm
  observed_at: '2026-05-09'
  claim: OSV.dev npm ecosystem advisory catalog — supply_chain_audit Check 引用根
  confidence: high
  mapped_tests: []
  auto_refresh: false
  note: 真实 advisory 索引在 src/agentsec/audit/ioc/osv_npm.json；本 TI 仅作为 supply_chain finding 的 threat_refs 目标，避免破坏 strict TI 校验
```

为什么需要 umbrella：项目既有的 `scripts/check_threat_refs.py` 双向
校验要求每个 finding 的 `threat_refs` 都对应到 `threat_intel.yaml`
的一个 id。给 supply_chain finding 都打 `["TI-OSV-NPM-CATALOG"]`，
避免「为每个 GHSA-xxxx 都新建一条 TI」（OSV-npm DB 5000+ 条全建 TI =
灾难）。advisory 的真实身份保留在 finding `evidence.advisory_id`
字段里，operator 一眼能看到。

`mapped_tests: []` 因为 supply_chain Check 不与现成 TestCase 关联
（这是 server-side 发现，不是远程攻击 case）。

### 7.2 bundled DB 体积守门

源头 OSV `npm/all.zip` 解压 30–60 MB；§6.3 归一化 + filter 后落地估
5–10 MB。设硬上限 **15 MB**（在 `scripts/check_osv_npm.py` 里加 size
assert），超过 CI 红 → 触发设计层面的取舍（继续过滤 / 改分发策略 /
升 sub-phase）。

wheel 影响：当前 277 KB → 加 5–10 MB DB → 5–10 MB wheel。能接受。
`MANIFEST.in` / `pyproject.toml [tool.hatch.build]` 默认包含
`src/agentsec/audit/ioc/*.json`，无需额外配置。

PyPI / pip install 体感：5–10 MB 仍属常见小工具范畴（同体量参考：
`bandit` ~3 MB、`semgrep` ~30 MB、`ruff` ~10 MB）。

## 8. 错误处理矩阵

| 失败位置 | 行为 |
|---|---|
| profile 非 Linux | `not_applicable("非 Linux profile")` |
| `_REQUIRED_PATHS = ("npm_root",)` 缺失 | `not_applicable`（base 类语义） |
| `cat <lock_path>` 被 policy `rejected` | `skipped(f"cat 被策略拒绝 ({reject_reason})")` |
| `cat` 退出码非 0（文件不存在） | `not_applicable(f"{lock_path} 不可读（npm 安装路径不在 npm_root 候选）")` —— 不是 skipped 因为这等价于「这台机器没装这个 npm 包」 |
| `cat` 退出码非 0 + permission denied | `skipped("权限不足读 lock 文件")` —— 但 `package-lock.json` 通常 644，几乎不会触发 |
| stdout 为空 | `skipped("lock 文件为空")` |
| `json.loads` 失败 | `skipped(f"package-lock.json 非合法 JSON：{e}")` |
| `lockfileVersion < 2` | 解析返 0 包 → 0 finding，evidence audit log 留 `lockfile_version` 字段供 operator 审视 |
| 单个包 semver 解析失败 | 跳过该包 + 1 条 low-severity finding `"无法解析 semver: {pkg}@{raw_version}"`（§4.3） |
| OSV DB 文件缺失（`__init__` 抛） | Check 永远不实例化；orchestrator 报 fixture 错误 |
| OSV DB JSON 损坏（`__init__` 抛 JSONDecodeError） | 同上 |
| `max_output_bytes` 截断 lock 文件 | 大型 lock 可达数 MB；`SSHExecutor` 默认 `max_output_bytes=1 MiB` 可能触发。Check 接到 `truncated=True` → `skipped(f"lock 文件超过 {max_output_bytes}，请提升上限")` —— 不试图按截断的 JSON 解析 |
| `ctx.executor` 抛非业务异常 | 上抛 orchestrator |

**约束（与 7e/7e.1/7e.2/7f 一致）**：

- Check 内不捕获通用 `Exception`——传输层异常归 orchestrator
- `ctx.status` 单次设置（base 已保证）
- `run()` 主体目标 ≤ 80 行；解析 / 匹配 helper 拆模块顶层私有函数

**lock 文件超 1 MiB 的现实应对**：OpenClaw 的 lock 在 Lightsail prod
实测预计 200–500 KB，远低于 1 MiB。如果未来 OpenClaw 依赖膨胀触发，
提升 `max_output_bytes` 到 4 MiB 是单 ssh_policy 改动。本期不预防性
放宽。

## 9. 测试策略

### 9.1 单元测试（`tests/test_supply_chain_audit.py`）

~12 case：

1. **平台 gating** —— `profile_name="macos"` → `is_not_applicable`
2. **`npm_root` 缺失** —— profile.paths 不含 `npm_root` → `is_not_applicable`
3. **lock 文件不存在**（`cat` exit_code≠0） → `is_not_applicable`
4. **policy rejected** → `is_skipped`
5. **stdout 为空** → `is_skipped`
6. **非合法 JSON** → `is_skipped`
7. **lockfileVersion=1** → 0 finding
8. **clean 依赖** → 0 finding
9. **vulnerable 命中**（lodash@4.17.15 + minimist@1.2.0 等真实包） →
   断言 finding 数 / advisory_id / severity 分布 / evidence 字段
10. **同包多 advisory** —— 单包命中两条 → 两条 finding
11. **scoped 包名**（`@scope/pkg` path key 解析） → 正确抽出 name
12. **无法解析的 semver** —— lock 含 `"version": "file:../local"` →
    该包跳过 + 1 条 low finding

stub 形态：复用 7e.1 / 7e.2 的 `_RecordingExecutor(responses_dict)`。
Check `__init__` 注入参数化 `_OSV_DB_PATH` 替换为 fixture 路径。

### 9.2 fetcher 单元测试（`tests/test_osv_npm_fetcher.py`）

~6 case，覆盖归一化逻辑（无网络）：

1. 正常 advisory（npm + semver range + CVSS） → 完整归一化
2. withdrawn advisory → 返 `None`
3. 跨生态 advisory（PyPI 同时含 npm 别名） → 只取 npm package
4. 没有 npm `affected` → 返 `None`
5. 没有 semver range（GIT type） → 返 `None`
6. CVSS 缺失 → severity 默认 `medium`

数据：`tests/fixtures/osv/npm/` 放几条真实 OSV JSON 截取。**不**做
live HTTP 测试（与 ioc-update 现有 `test_ioc_update_offline.py` 一致）。

### 9.3 fixture 数据

`tests/fixtures/supply_chain/`：

- `package-lock-clean.json` —— 5–10 个 deps，全是 OSV 没收录的 / 已修
  版本
- `package-lock-vulnerable.json` —— 含 3 个真实漏洞包（如
  `lodash@4.17.15` GHSA-jf85-cpcp-j695、`minimist@1.2.0`
  GHSA-vh95-rmgr-6w4m、scoped 包测试）
- `osv_npm_subset.json` —— 测试专用 mini DB，含上述 3 条真实 advisory
  + 1 条不会命中的 control entry。**禁止**单测加载生产 `osv_npm.json`
  （防漂移）

### 9.4 集成测试 + sample 漂移

`tests/integration/test_openclaw_mock.py` 的 mock SSH 需扩 1 条响应：

- `cat ~/.npm-global/lib/node_modules/openclaw/package-lock.json`
  → 返一个固定的 mock lock（可复用 `package-lock-clean.json` fixture）

预期：mock 端 0 finding（clean fixture）→ `<!-- check:supply_chain_audit
status:ok -->` 锚点出现在 sample 报告。按 `AGENTSEC_REFRESH_SAMPLE=1`
刷一次 `docs/samples/report-2026-04-28/`。

`tests/integration/test_evaluate_smoke.py` + `tests/audit/test_cli_server_audit.py`
同步加 stub（与 Phase 7e.2 Task 7 同口径）。

### 9.5 回归 gate

```
.venv/bin/pytest tests/ -q                        # 1136 → ~1156（+18 = 12 + 6）
.venv/bin/ruff check src/ tests/ scripts/         # clean
.venv/bin/pyright                                 # 0 errors
.venv/bin/python scripts/check_threat_refs.py     # 通过（TI-OSV-NPM-CATALOG mapped_tests 留空 OK）
.venv/bin/python scripts/build_cve_db.py --check  # 不受影响
.venv/bin/python scripts/check_osv_npm.py --check # 新加：byte-diff + 体积 < 15 MB
```

### 9.6 真机 smoke

Lightsail prod（`34.208.65.73`）跑 `agentsec server-audit`，预期：

- `supply_chain_audit` 返 `ok`，emit ~5–25 条 finding（§4.5 估值）
- 每条 finding 含 `advisory_id`、`fixed_in`、`url` 等可让 operator
  直接行动的字段
- 真实数字 + 命中包列表写入 `project_openclaw_lightsail_prod.md`

## 10. CLI 注册

`src/agentsec/cli.py` 两处 `checks = [...]`（`server_audit` +
`_evaluate_server`）各加 1 行：

```python
SupplyChainAuditCheck(),
```

位置：插在 `DockerImageCveCheck()` 之后（Phase 7d 时间线最新；Phase
7e.2 firewall 三件 + 7f Docker 三件 之后）。

import 段同步加 1 个新模块。

## 11. 文档变更

- **`ROADMAP.md`**：Phase 7d 行勾选 `- [x] Phase 7d — npm supply chain
  Check（OSV-npm bundled DB，TI-OSV-NPM-CATALOG）— 2026-05-09`
- **`CHANGELOG.md`** `[Unreleased]` `Added`：~150 字概述 supply_chain
  Check + osv_npm fetcher + DB
- **`README.md`**：服务端审计 Check 数 24 → 25（10 OpenClaw + 11 Linux
  hardening + 3 Docker + 1 supply chain）
- **`CLAUDE.md`**：`Total checks (v0.12.0)` 行更新到 25 类，把
  supply_chain 挂在「Phase 7d」标签下；新增段
  `## Supply chain audit (Phase 7d, v0.12.0)` 写明 DB 路径、ioc-update
  流程、TI umbrella 策略、单 ecosystem (npm) 范围
- **`docs/adr/0012-phase-7d-supply-chain.md`**：复用 ADR-0011 模板，
  覆盖 5 条决策：
  - D1：scope = npm only（pip/go/rust 推迟）
  - D2：lookup = offline DB via ioc-update（与 cve_database.json 同
    模式；不在线查 osv.dev）
  - D3：DB 分发 = bundled in wheel（不做单独 optional package）
  - D4：TI umbrella `TI-OSV-NPM-CATALOG`（避免 5000 条 GHSA 各建 TI）
  - D5：Check 不需 root + 路径范围严格收敛在
    `~/.npm-global/lib/node_modules/openclaw/`（不像 7e 留下
    `/usr/bin/` 过宽教训）

## 12. 验收清单

1. `.venv/bin/pytest tests/ -q` 全绿（≈1156 tests）
2. `.venv/bin/ruff check src/ tests/ scripts/` clean
3. `.venv/bin/pyright` 0 errors
4. mock 集成测试通过；sample 漂移 guard 通过（带 1 条新锚点）
5. ADR-0012 落地
6. ROADMAP / CHANGELOG / README / CLAUDE.md 更新；版本 v0.12.0
7. `osv_npm.json` 在 git 中；`scripts/check_osv_npm.py --check` 通过；
   体积 < 15 MB
8. Lightsail 真机 smoke 跑通；finding 数 + 命中包列表写入 memory

## 13. 后续展望

- **7d.1**：Python 生态（pip / poetry / pipenv）—— OSV PyPI subset
  同模式
- **7d.2**：Go (`go.sum`) / Rust (`Cargo.lock`) —— OSV 也有 Go/Rust
  subset
- **7d.3**：项目本地 `node_modules/`（非 npm_root）—— 需要 profile
  加 `project_root` 之类
- **7d.4**：online OSV 查询作为 cache miss 兜底（DB 拒绝再扩、引入
  网络 dep）
- **7d.5**：sha256 校验 npm 包文件 vs OSV 提供的 hashes（更强的供应
  链篡改检测）
