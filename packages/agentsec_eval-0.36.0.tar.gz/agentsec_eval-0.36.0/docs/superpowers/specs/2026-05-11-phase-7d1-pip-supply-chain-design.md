# Phase 7d.1 — pip / PyPI 供应链审计 Check 设计

**日期**：2026-05-11
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0013；前置 ADR-0012（7d-npm）。

## 1. 目标

`agentsec server-audit` 在 v0.12.0 已有 25 类 Check，其中 `supply_chain_audit`
（7d-npm）按 npm `package-lock.json` 比对 OSV-npm DB 出 finding。Phase 7d.1
把同样的能力扩到 **PyPI 生态**：按 operator 在 `openclaw-target.yaml` 中
配置的 `requirements.txt` 路径列表，匹配 OSV-PyPI advisory 子集，emit
已知漏洞 finding。

ROADMAP `Phase 7d.1+` 原文：「Skills / Plugins 深化的剩余面（**pip** / go /
rust 生态 + plugin_static 静态扫描扩展）」。本 phase 只覆盖 pip；go / rust
留给 7d.2 / 7d.3。

## 2. 范围

新增 1 个 Check + 1 个 OSV fetcher + 1 个 bundled DB + 1 条 TI umbrella
+ `ServerAuditConfig.pip_lock_paths` + `CheckContext.pip_lock_paths` 通道。

| 组件 | id / 路径 | 职责 |
|---|---|---|
| `PipSupplyChainAuditCheck` | `pip_supply_chain_audit` | 读 operator 配置中列出的 `requirements.txt` 路径，按 (name, version) 匹配 OSV-PyPI DB，每个命中 1 条 Finding |
| OSV-PyPI fetcher | `src/agentsec/audit/ioc_update/fetchers/osv_pypi.py` | `agentsec ioc-update` 子流程：拉 `https://osv-vulnerabilities.storage.googleapis.com/PyPI/all.zip`，过滤、归一化、写 `osv_pypi.json` |
| Bundled DB | `src/agentsec/audit/ioc/osv_pypi.json` | 提交到 git，wheel 打包随发；CI `--check` 验证一致性，硬上限 ≤ 15 MB |
| TI umbrella | `TI-OSV-PYPI-CATALOG`（在 `threat_intel.yaml`） | pip_supply_chain finding 的 `threat_refs` 引用 |
| Config schema | `ServerAuditConfig.pip_lock_paths: list[str] = []` | operator 在 `openclaw-target.yaml` 列要审的 lockfile |
| Context 通道 | `CheckContext.pip_lock_paths: tuple[str, ...] = ()` | server-audit orchestrator 把 config 传给 Check |

**首期范围**：

- **生态**：仅 PyPI。go / rust / cargo 留给 7d.2 / 7d.3。
- **lockfile 格式**：仅 `requirements.txt`（frozen / pip-compile / poetry export
  / pipenv export / uv export 输出形态）。Pipfile.lock / poetry.lock / uv.lock /
  pdm.lock 原生格式不读 —— 这些工具都能 `export` 出 requirements.txt。
- **路径来源**：完全由 operator 在 config 中提供。**不**在
  `PlatformProfile` 加 `pip_root` 等键（OpenClaw 本身没有稳定 Python
  安装位置）；**不**默认扫主机系统 pip。
- **后缀白名单**：`requirements` / `.txt` / `.lock` / `.in` 之一结尾的路径
  才允许（避免误读 `/etc/shadow`）。
- **顺手修 npm `affected[0]` 漏洞**：现有 7d-npm `OsvNpmFetcher` 的
  `normalize_osv_entry` 只取 `affected_npm[0]`，多 npm 包的 advisory 会被
  截断；7d.1 在写 OSV-PyPI 多包遍历的同时，独立 commit 修复 npm 同款漏洞
  + 加测试。

**out of scope**：

- 在线 osv.dev 查询（架构选 offline，与 7d-npm 同）
- 多种 Python lockfile 原生格式（poetry.lock / Pipfile.lock / uv.lock 等）
- pip 全局 `pip list` 扫描（要执行 pip CLI，扩大攻击面）
- 抽 `_supply_chain_common.py` 公共模块（rule of three：等 7d.2 go 落地再抽）
- macOS profile（仅 `linux` / `linux_user_mode`，与 7d-npm 同）

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  pip_supply_chain_audit.py             # 新 — Check 主体
src/agentsec/audit/ioc/
  osv_pypi.json                         # 新 — bundled DB（首次 ~1 MB）
  threat_intel.yaml                     # 现有，追加 TI-OSV-PYPI-CATALOG
src/agentsec/audit/ioc_update/fetchers/
  osv_pypi.py                           # 新 — OSV-PyPI 抓取 + 归一化
  osv_npm.py                            # 现有，独立 commit 修 affected[] 多包遍历
src/agentsec/audit/ioc_update/
  cli.py                                # 现有，加 _run_osv_pypi（与 _run_osv_npm 并行）
src/agentsec/audit/
  command_policy.py                     # 现有，加 add_runtime_allowed_paths(...) 接口
  ssh_policy.yaml                       # 现有，加 §5 的注释段（无新静态条目）
  server_audit.py                       # 现有，注入 pip_lock_paths 到 CheckContext + CommandPolicy
src/agentsec/
  config.py                             # 现有，加 ServerAuditConfig.pip_lock_paths
  cli.py                                # 现有，注册 PipSupplyChainAuditCheck（两处）
scripts/
  check_osv_pypi.py                     # 新 — CI 一致性 + 体积 ≤ 15 MB 守门
tests/audit/checks/
  test_pip_supply_chain_audit.py        # 新
tests/audit/ioc_update/fetchers/
  test_osv_pypi.py                      # 新
tests/audit/ioc_update/
  test_cli_offline.py                   # 现有，扩 _run_osv_pypi case
tests/audit/
  test_command_policy.py                # 现有，扩 1 case 验证动态注入
  test_config.py                        # 现有，扩 1 case 验证 pip_lock_paths
tests/scripts/
  test_check_osv_pypi.py                # 新
tests/fixtures/supply_chain_pypi/
  requirements-clean.txt
  requirements-vulnerable.txt
  requirements-edge-cases.txt           # extras / marker / -e / VCS / hash
  osv_pypi_subset.json
tests/fixtures/osv/pypi/
  # 6 个 OSV 真实 advisory JSON 截取，对应 §8.2 六类归一化测试 case
docs/adr/0013-phase-7d1-pip-supply-chain.md
docs/superpowers/specs/2026-05-11-phase-7d1-pip-supply-chain-design.md
```

新增文件量级：5（源码 + DB） + 6（test + fixture） + 1（CI 脚本） + 2（ADR/spec）
= 14。零新 PyPI 依赖（`packaging>=22` 已在 `pyproject.toml`）。

### 3.2 平台 gating

`PipSupplyChainAuditCheck` 在 `run()` 顶部判断
`ctx.profile.name in ("linux", "linux_user_mode")`，非 Linux profile 标
`not_applicable` 直接返。macOS profile 暂不支持。

### 3.3 不依赖 `_REQUIRED_PATHS`

7d-npm 用 `_REQUIRED_PATHS = ("npm_root",)` 强依赖 PlatformProfile。
7d.1 路径完全来自 operator config，不走 PlatformProfile 通道，所以**不**
设 `_REQUIRED_PATHS`。

`run()` 顶部改判 `if not ctx.pip_lock_paths: → not_applicable("未配置")`。

### 3.4 OSV DB 加载（class `__init__` 时一次性）

```python
_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_pypi.json"

class PipSupplyChainAuditCheck(Check):
    id = "pip_supply_chain_audit"

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        path = db_path if db_path is not None else _OSV_DB_PATH
        raw = json.loads(path.read_text())
        self._advisories_by_pkg: dict[str, list[dict]] = {}
        for adv in raw:
            self._advisories_by_pkg.setdefault(adv["package"], []).append(adv)
```

按已归一化（PEP-503 normalized）的 package name 索引。lock 解析后的包名
也走同样归一化再查，保证大小写 / 下划线 / 连字符差异不漏匹配。

### 3.5 `run()` 模板

```python
async def run(self, ctx):
    if ctx.profile.name not in ("linux", "linux_user_mode"):
        ctx.status.not_applicable(f"{self.id}：非 Linux profile")
        return []
    if not ctx.pip_lock_paths:
        ctx.status.not_applicable(f"{self.id}：未配置 pip_lock_paths")
        return []

    findings: list[Finding] = []
    n_skipped = 0
    for lock_path in ctx.pip_lock_paths:
        result = ctx.executor.run(["cat", lock_path])
        if result.rejected:
            n_skipped += 1
            continue
        if result.exit_code != 0:
            n_skipped += 1
            continue
        if not result.stdout.strip():
            n_skipped += 1
            continue
        findings.extend(self._scan_lockfile(lock_path, result.stdout))
    if not findings and n_skipped == len(ctx.pip_lock_paths):
        ctx.status.skipped(
            f"{self.id}：所有 pip_lock_paths 均不可读 (n={n_skipped})"
        )
    return findings
```

```python
def _scan_lockfile(self, lock_path: str, stdout: str) -> list[Finding]:
    """parse + match + emit。无法解析的非锁定行 silently skip，与 7d-npm 同。"""
    pkgs = parse_pip_requirements(stdout)
    findings: list[Finding] = []
    for pkg, version in pkgs:
        norm = normalize_pep503(pkg)
        if _safe_parse_pep440(version) is None:
            findings.append(self._unparseable_finding(pkg, version, lock_path))
            continue
        for adv in self._advisories_by_pkg.get(norm, []):
            if version_in_any_pep440_range(version, adv["ranges"]):
                findings.append(self._advisory_finding(pkg, version, adv, lock_path))
    return findings
```

### 3.6 不需要的东西

- **不需要 root**：`requirements.txt` 一般是世界可读 venv 配置文件
- **不需要 pip CLI 探测**：本 Check 只读 lock 文件，不执行 `pip` 命令

## 4. 数据模型

### 4.1 OSV-PyPI 归一化 schema（与 OSV-npm 同形）

```json
{
  "id": "GHSA-xxxx-yyyy-zzzz",
  "package": "django",
  "ranges": [{"introduced": "3.0", "fixed": "3.2.18"}],
  "severity": "critical|high|medium|low",
  "summary": "短摘要 ≤ 200 字符",
  "url": "https://github.com/advisories/GHSA-xxxx-yyyy-zzzz",
  "aliases": ["CVE-2023-xxxxx"]
}
```

差异点：
- `package` 字段已 PEP-503 归一化（lowercase + 连字符替换）
- `ranges` 用 PEP-440 字符串而非 semver
- 同一 OSV entry 的多个 PyPI affected 包**展开成多条 normalized 记录**
  （每条独立 id 仍是 advisory id —— 由查询时按 `(pkg, version, advisory_id)`
  唯一去重保证不重复出 finding）

### 4.2 Finding 形态

```python
Finding(
    check="pip_supply_chain_audit",
    severity=<from_advisory>,
    title=f"pip {pkg}@{version} 命中 {advisory_id}（severity={sev}）",
    description=adv["summary"],   # 已截 200 字符
    evidence={
        "package": pkg,
        "version": version,
        "advisory_id": advisory_id,
        "aliases": [...],
        "fixed_in": "3.2.18 或 (no fixed version)",
        "url": "https://github.com/advisories/...",
        "lock_path": lock_path,
    },
    remediation=f"pip install -U {pkg}=={fixed_in}",
    threat_refs=["TI-OSV-PYPI-CATALOG"],
)
```

无法解析的 PEP-440 版本（罕见但合法）单独一条 low 级 Finding：

```python
Finding(
    check="pip_supply_chain_audit",
    severity="low",
    title=f"无法解析 PEP-440: {pkg}@{version}",
    description="非标准版本字符串（如 git URL pin），无法对照 OSV 数据库",
    evidence={"package": pkg, "version": version, "lock_path": lock_path},
    remediation="改为 PEP-440 合规版本（pip 发布版）",
    threat_refs=["TI-OSV-PYPI-CATALOG"],
)
```

## 5. CommandPolicy 动态注入

`pip_lock_paths` 不固化在 `ssh_policy.yaml` 的 `allowed_paths` 里 —— operator
配置即 consent。orchestrator 启动后流程：

1. `ServerAuditConfig.pip_lock_paths` 字段加 Pydantic 校验：
   - 每条字符串以 `/` 或 `~/` 起头
   - 调用现有 `metachar_guard.contains_shell_metachar([path])` 不为 `None` → 拒绝
   - 文件名后缀必须 ∈ {`requirements`（含 `requirements-prod` 等前缀）, `.txt`, `.lock`, `.in`}
2. `materialize_paths` 把 `~/` 展开成绝对路径
3. `server_audit.py` 调用 `command_policy.add_runtime_allowed_paths(paths, kind="exact")`
   注入；接口实现：在 `CommandPolicy` 实例的 `allowed_paths` list 末尾追加
   `ExactPath` 条目
4. 这些条目仅本次进程生命周期有效；不修改磁盘上的 `ssh_policy.yaml`

**审计可追**：`audit-log.jsonl` 在 startup 写一行 `event="runtime_allowed_paths_added"`，`paths=[...]`，`source="ServerAuditConfig.pip_lock_paths"`。

**为什么 exact 而不是 prefix**：每个路径是 operator 显式列出的具体文件；
prefix 会把目录纳入，意外扩大读权。

**校验失败行为**：config 解析失败 → `OpenClawTargetConfig.from_yaml` 抛
`ValidationError`，CLI 直接退出，整个 server-audit 不启动（与现有 fail-fast
约定一致）。

## 6. Lockfile parser

### 6.1 输入 / 输出

```python
def parse_pip_requirements(stdout: str) -> list[tuple[str, str]]:
    """Return [(pkg, version)] for `pkg==X` 形式行。其余 silently skip。"""
```

非 `==` 锁定行（VCS URL / editable / 范围锁定）直接跳过——与 7d-npm
`parse_npm_lock` 对 `link` entry / 非 dict entry 的处理同款，**不**做 evidence
上报。

### 6.2 行类别

| 行形态 | 行为 |
|---|---|
| `pkg==1.2.3` | 收 `(pkg, "1.2.3")` |
| `pkg[extra]==1.2.3` | 去 extras → `(pkg, "1.2.3")` |
| `pkg==1.2.3 ; python_version >= "3.10"` | 去 marker → `(pkg, "1.2.3")` |
| `pkg==1.2.3 \` 后跟 `--hash=sha256:...` | 主行收，hash 续行 silently skip |
| `pkg @ file:./local-pkg` / `pkg @ git+...` | silently skip（非 PEP-440） |
| `-e .` / `-e git+...` editable | silently skip |
| `-r other.txt` / `-c c.txt` | silently skip |
| 空行 / `#` 注释 | silently skip |
| `pkg>=1.0` / `pkg~=1.2` / `pkg<2.0`（非精确） | silently skip |
| 完全无法解析 | silently skip |

### 6.3 PEP-503 包名归一化

```python
def normalize_pep503(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()
```

lock 解析后 + DB 索引前都走一遍。

### 6.4 续行处理

`requirements.txt` 用 `\` 续行；parser 先按 `\n` split，再合并以 `\` 收尾的
行（去 `\` + 空白）。`--hash=` 续行属于主行的一部分被吸收。

## 7. Range matcher

```python
def version_in_any_pep440_range(version: str, ranges: list[dict]) -> bool:
    v = _safe_parse_pep440(version)
    if v is None:
        return False
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last = r.get("last_affected")
        if intro != "0":
            intro_v = _safe_parse_pep440(intro)
            if intro_v is not None and v < intro_v:
                continue
        if fixed is not None:
            fixed_v = _safe_parse_pep440(fixed)
            if fixed_v is not None and v >= fixed_v:
                continue
        if last is not None:
            last_v = _safe_parse_pep440(last)
            if last_v is not None and v > last_v:
                continue
        return True
    return False
```

- `packaging.version.Version` 实现了 `__lt__/__eq__/__gt__`
- pre-release（`1.0.0a1`）默认包含 — `Version("1.0.0a1") < Version("1.0.0")` 成立
- local version（`1.0.0+cuda118`）按 PEP-440 在比较时降权 —— `packaging` 自动处理
- `_safe_parse_pep440(s)` 解析失败返 `None`（catch `InvalidVersion`）

## 8. OSV-PyPI fetcher

### 8.1 `OsvPyPIFetcher`（`src/agentsec/audit/ioc_update/fetchers/osv_pypi.py`）

镜像 `OsvNpmFetcher`：
- `name = "osv_pypi"`
- URL：`https://osv-vulnerabilities.storage.googleapis.com/PyPI/all.zip`
- 重试退避 `[2, 4, 8]`s（与 npm 同）
- 单 FetchResult key `_osv_pypi_full`
- `httpx.AsyncClient` + `zipfile.ZipFile`

### 8.2 `normalize_osv_pypi_entry` —— 5-轴 filter chain

| 轴 | 规则 | 与 npm 差异 |
|---|---|---|
| 1. withdrawn | `osv_entry.get("withdrawn")` → drop | 同 |
| 2. ecosystem | `affected[].package.ecosystem == "PyPI"`（**大小写敏感**）→ 收；否则 drop | npm 是 `"npm"`（lowercase） |
| 3. semver range | `_extract_pep440_ranges(...)` 得空 → drop | 改用 ECOSYSTEM 类型（PyPI 不用 SEMVER），事件仍是 `introduced/fixed/last_affected` |
| 4. CVSS | `severity[].type == "CVSS_V3"` 解析失败 → drop（CVSS_V4 暂不支持，找不到 v3 视为 unscored） | 同 |
| 5. age | severity ∈ {medium, low} 且 `published > 2 年` → drop；critical/high 始终保留 | 同 |

**多 affected 包遍历**：
- 一个 OSV entry 的 `affected[]` 可含多个 PyPI 包（少见但有，如同库的两个 PyPI fork）
- 遍历**所有** PyPI 项，每个生成一条 normalized 记录（`id` 字段允许重复 —— 不同 `package` 字段区分）
- DB 去重 key：`(id, package)`

### 8.3 输出体积估计

PyPI 全量 ~50K entries（npm 是 208K），过滤后 ~3-5K 条 ~1 MB 量级。CI
guard 上限仍设 15 MB。

## 9. ioc-update CLI 接入

`src/agentsec/audit/ioc_update/cli.py` 加 `_run_osv_pypi`：

```python
async def _run_osv_pypi(ctx: FetcherContext, cache_dir: Path) -> Path | None:
    fetcher = OsvPyPIFetcher()
    results = await fetcher.run(ctx, [])
    result = results.get("_osv_pypi_full")
    # 同 _run_osv_npm 的 dump + log 流程
```

主流程把 `_run_osv_pypi` 与 `_run_osv_npm` **并行**（`asyncio.gather`）；
其中一个失败不阻塞另一个。

degraded 行为：fetch 失败 → 日志记 `osv_pypi_degraded`，磁盘 `osv_pypi.json`
不动。CLI 退出码与 npm 同（degraded 不算硬失败）。

## 10. 测试矩阵

### 10.1 Parser tests（~10 case）

```
test_parse_simple_eq           pkg==1.2.3
test_parse_with_extras         pkg[a,b]==1.2.3 → (pkg, 1.2.3)
test_parse_with_marker         pkg==1.2.3 ; python_version >= "3.10"
test_parse_continuation_hash   pkg==1.2.3 \\\n    --hash=sha256:...
test_parse_pep503_normalization Foo_Bar==1.0 → ("foo-bar", "1.0")
test_parse_local_version       pkg==1.0+cuda118
test_parse_skip_editable       -e . / -e git+...
test_parse_skip_vcs_url        pkg @ git+...
test_parse_skip_recursive      -r other.txt / -c constraints.txt
test_parse_silently_skips_non_eq  非 == 行不出现在结果中
```

### 10.2 Matcher tests（~8 case）

```
test_match_exact_inside_range
test_match_exact_at_introduced
test_match_just_below_fixed
test_match_at_fixed_boundary       → False
test_match_pre_release_in_range    1.0.0a1 in [0, 1.0.0)
test_match_local_version_ignored   1.0.0+cuda matches like 1.0.0
test_match_unparseable_returns_false
test_match_multiple_ranges_or
```

### 10.3 Check end-to-end（~5 case，mock SSHExecutor）

```
test_check_empty_config_not_applicable
test_check_single_lockfile_one_hit
test_check_multi_lockfile_mixed
test_check_all_paths_unreadable_skipped
test_check_unparseable_pep440_low_finding
```

### 10.4 Fetcher tests（~7 case）

```
test_normalize_filters_withdrawn
test_normalize_filters_no_pypi_affected
test_normalize_filters_no_range
test_normalize_filters_no_cvss
test_normalize_drops_old_medium_low
test_normalize_keeps_old_critical
test_normalize_multi_affected_expansion
```

### 10.5 HTTP integration（`httpx.MockTransport`，2 case）

```
test_fetch_success_one_zip
test_fetch_retry_exhaustion_degraded
```

### 10.6 CommandPolicy / Config tests（~4 case）

```
test_command_policy_runtime_inject_exact
test_command_policy_metachar_rejected
test_config_pip_lock_paths_suffix_whitelist
test_config_pip_lock_paths_relative_path_rejected
```

### 10.7 CI script test（~3 case）

```
test_check_osv_pypi_valid
test_check_osv_pypi_oversize
test_check_osv_pypi_invalid_json
```

**总计**：parser 10 + matcher 8 + Check e2e 5 + fetcher 7 + HTTP 2 +
policy/config 4 + CI script 3 + ioc-update CLI `_run_osv_pypi` 1 = **40 新测试**
（7d.1 主体）+ §11 的 npm `affected[0]` 修复独立加 1 case = **41 新测试**。
1177 → ~1218 passing。

### 10.8 Sample 报告刷新

`docs/samples/report-2026-04-28/` 跑：
```bash
AGENTSEC_REFRESH_SAMPLE=1 .venv/bin/pytest \
    tests/integration/test_openclaw_mock.py::test_openclaw_mock_end_to_end
```
mock 中无 `pip_lock_paths` → `pip_supply_chain_audit` 出现为
`not_applicable`，不影响计分。

## 11. 顺手修 npm `affected[0]` 漏洞

**独立 commit**，不与 7d.1 主体混：

- 文件：`src/agentsec/audit/ioc_update/fetchers/osv_npm.py:normalize_osv_entry`
- 改动：把 `affected_npm[0]` 改成遍历 `affected_npm`，每个生成一条 normalized 记录
- 测试：`tests/audit/ioc_update/fetchers/test_osv_npm.py` 加 1 case 多包展开
- DB 重建：跑一次 `agentsec ioc-update` 看 `osv_npm.json` 是否有变化；如有，
  独立 `data(7d-fix):` commit 提交 `osv_npm.json`

## 12. CI / Release

### 12.1 CI guard

`scripts/check_osv_pypi.py --check`：
- 解析 `osv_pypi.json` 必须是合法 JSON list
- 文件大小 ≤ 15 MB 硬上限
- workflow 接入位置与 `check_osv_npm.py` 同

### 12.2 release 链路（与 v0.12.0 一致）

1. 实现完整 + 测试全绿后跑 `agentsec ioc-update`
2. `cp .cache/ioc-update-<date>/proposed-osv_pypi.json src/agentsec/audit/ioc/osv_pypi.json`
3. 独立 `data(7d.1):` commit 提交 `osv_pypi.json`
4. ROADMAP / CHANGELOG / README / CLAUDE.md / MEMORY.md / version bump（→ v0.13.0）独立 docs commit
5. ADR-0013 独立 commit
6. push main + tag `v0.13.0` + push tag
7. `twine upload dist/agentsec-eval-0.13.0*` 手动发 PyPI

## 13. 决策清单（→ ADR-0013）

| ID | 决策 | 备选 | 选择理由 |
|---|---|---|---|
| D1 | 路径来自 operator config，不进 PlatformProfile | (a) profile 加 `pip_root` 默认 (b) 扫主机 `pip list` | OpenClaw 无稳定 Python footprint；operator config 即 consent |
| D2 | 仅 requirements.txt | (a) 主流三者 (b) auto-detect | YAGNI；poetry/uv/pipenv 都能 export；解析最简 |
| D3 | 不抽 `_supply_chain_common.py` | 现在抽 | rule of three：N=2 抽象易抽错，等 7d.2 |
| D4 | 后缀白名单 4 项 | 无白名单 / 可扩展 | 安全默认 + 覆盖足够 |
| D5 | PEP-440 + pre-release 包含 + local 忽略 | pre-release 需 explicit | 与 OSV / pip 真实行为一致 |
| D6 | exact kind 动态注入 allowed_paths | prefix / 静态写 ssh_policy | 最小权限 + 零 install 文件改动 |
| D7 | 顺手修 npm `affected[0]` | 留 follow-up | 同根问题在写新代码时正确实现，老代码同步对齐 |
| D8 | OSV-PyPI 5-轴 filter chain 与 npm 同 | 重新调阈值 | 7d-npm 已验证有效 |
| D9 | TI 单 umbrella `TI-OSV-PYPI-CATALOG` | 每 advisory 一条 TI | 避免 threat_intel.yaml 膨胀几千行 |
| D10 | Check 通道走 `CheckContext.pip_lock_paths` | extra_config dict / 全局 config | 类型安全 + 修一处 |

## 14. Out of scope（明确记下，避免范围蔓延）

- 不读 poetry.lock / Pipfile.lock / uv.lock / pdm.lock 原生格式
- 不扫主机系统 pip（`pip list --format=json`）
- 不查在线 osv.dev API
- 不引 CVSS_V4 解析（cvss lib 暂无 v4 支持，等上游）
- 不抽 `_supply_chain_common.py`（等 7d.2 go）
- 不动 `plugin_static`（独立 7d.x 子项）
- macOS 平台
- Windows 平台
