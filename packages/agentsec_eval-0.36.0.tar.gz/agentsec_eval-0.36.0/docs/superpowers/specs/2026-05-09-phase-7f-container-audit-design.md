# Phase 7f — 容器安全 Check 设计

- **状态**：草案 / 待评审
- **目标版本**：v0.10.0
- **作者**：Roger
- **创建日期**：2026-05-09
- **关联 ADR**：本设计落地后补 ADR-0010（容器审计接入策略）
- **前置 Phase**：7e（v0.9.5，Linux 主机加固 4 类 Check）、7e.1（v0.9.5，加固扩展 4 类）

---

## 1. 背景

`server-audit` 模块当前覆盖 OpenClaw 自身（10 类 Check）+ Linux 主机加固（8 类 Check），但完全没有触及容器。两类被审现实未被覆盖：

1. **宿主上的容器运行时姿态** — 被审主机装了 Docker，运行中容器是否走 `privileged` / `host network` / 挂载 `/var/run/docker.sock` / 用 root，daemon 是否暴露未认证 TCP API
2. **OpenClaw 装在容器里的部署形态** — 镜像基线是否过期 / 是否用 `:latest` / Python 2 / Node 12 等已 EOL 的镜像

7f 在 v0.10.0 引入 3 类 Docker Check 解决以上两个场景，第一期不覆盖 containerd / podman / Kubernetes。

## 2. 范围与非目标

**范围**

- Linux 宿主上的 Docker 守护进程 + 运行中容器审计
- 通过现有 SSH 通道执行只读 `docker` 子命令
- 镜像层面的粗粒度 CVE / EOL 检测（curated baseline）
- 沿袭 7e/7e.1 节奏：3 个独立 Check，单文件单职责

**非目标**

- containerd / podman 适配（看社区反馈再决定后续 Phase）
- Kubernetes / Pod / SecurityContext 审计（节点 + 集群层差异太大，单独 Phase）
- 真 CVE 扫描器集成（Trivy / Grype 出网 + 体积过大，超出第一期承受）
- `docker exec` 进容器审计（与现有 CommandPolicy 单层 argv 假设冲突）
- `docker pull` / `docker sbom` 等拉取动作

## 3. 模块布局

```
src/agentsec/audit/
├── checks/
│   ├── docker_daemon_audit.py      # 新增
│   ├── docker_runtime_audit.py     # 新增
│   ├── docker_image_cve.py         # 新增
│   └── container_baseline.yaml     # 新增（daemon / runtime / image 三段）
├── ssh_policy.yaml                 # 改：新增 docker: 命令块 + 1 条 allowed_paths
├── args_schema.py                  # 改：新增 kind: container_id 正则分支
└── ioc/threat_intel.yaml           # 改：追加 21 条 TI-DOCKER-* 条目
```

## 4. Docker 探测协议

**模块级 helper** `detect_docker(ctx) -> str | None`：

```python
def detect_docker(ctx: CheckContext) -> str | None:
    """返回 docker 二进制绝对路径，未装返回 None。"""
    candidates = ("/usr/bin/docker", "/usr/local/bin/docker", "/opt/homebrew/bin/docker")
    for path in candidates:
        result = ctx.executor.run(["stat", "-c", "%n", path])
        if not result.rejected and result.exit_code == 0:
            return path
    return None
```

三个 Check 各自在 `run()` 头部调用一次：返回 None 即各自标 `not_applicable`，**不**共享缓存（保持 Check 独立性）。

**与 PlatformProfile 关系**：不向 `LINUX` / `MACOS` / `LINUX_USER_MODE` 注入容器路径键。被审主机有没有 Docker 是运行时事实，不是平台属性，profile 应保持 frozen 不变。

## 5. Check 详细规格

### 5.1 `docker_daemon_audit`

**id**：`docker_daemon_audit`
**数据来源**：
- `cat /etc/docker/daemon.json`
- `docker version --format '{{json .}}'`
- `docker info --format '{{json .}}'`

**规则表**

| 规则 ID | 触发条件 | 默认 severity | threat_ref |
|---|---|---|---|
| daemon-tls-exposed | `daemon.json:hosts` 含 `tcp://` 但 `tlsverify` 不为 true | critical | TI-DOCKER-DAEMON-TLS-DISABLED |
| daemon-userns-off | `daemon.json` 缺 `userns-remap` 或 == "default" | medium | TI-DOCKER-DAEMON-USERNS-OFF |
| daemon-no-new-priv | `no-new-privileges` 缺省或 false | medium | TI-DOCKER-DAEMON-NO-NEW-PRIV |
| daemon-live-restore | `live-restore` 缺省或 false | low | TI-DOCKER-DAEMON-LIVE-RESTORE |
| daemon-log-unbounded | log-driver=json-file 且 `log-opts.max-size` 缺省 | low | TI-DOCKER-DAEMON-LOG-UNBOUNDED |
| daemon-version-cve | `docker version --format` 中 Server.Version 落入 baseline 黑名单 | high | TI-DOCKER-DAEMON-VERSION-CVE |

**`daemon.json` 不存在**：emit 一条 info finding"daemon.json 缺失，所有配置走默认值"，Check 仍标 completed。这避免和"未装 docker"语义混淆。

### 5.2 `docker_runtime_audit`

**id**：`docker_runtime_audit`
**数据来源**：
- `docker ps --format '{{json .}}' --no-trunc`
- 对每条容器：`docker inspect <container_id>`

**遍历**：
1. 解析 `docker ps` 每行 JSON，得 `id` / `image` / `names`
2. 容器数 > 200 时只取前 200 个，emit 一条 info finding 记录截断
3. 单条 `docker inspect` 失败：跳过该容器，继续遍历，整 Check 不升级为 skipped

**规则表**

| 规则 ID | 触发条件 | 默认 severity | threat_ref |
|---|---|---|---|
| runtime-privileged | `HostConfig.Privileged: true` | critical | TI-DOCKER-RUNTIME-PRIVILEGED |
| runtime-host-net | `HostConfig.NetworkMode == "host"` | high | TI-DOCKER-RUNTIME-HOST-NET |
| runtime-sock-mount | `HostConfig.Binds` 任一条目源含 `/var/run/docker.sock` | critical | TI-DOCKER-RUNTIME-DOCKER-SOCK-MOUNT |
| runtime-host-fs-mount | `HostConfig.Binds` 源等于或位于 `/`、`/etc`、`/root`、`/proc`、`/sys` 之下（`os.path.commonpath` 边界匹配，沿用 7e.1 path_matcher 风格） | high | TI-DOCKER-RUNTIME-HOST-FS-MOUNT |
| runtime-root-user | `Config.User` 为 ""、"root" 或 "0" | medium | TI-DOCKER-RUNTIME-ROOT-USER |
| runtime-cap-dangerous | `HostConfig.CapAdd` 含 SYS_ADMIN / NET_ADMIN / SYS_PTRACE 任一；多个 cap 命中 → 各 emit 一个 finding（fingerprint 含 cap 名，不重复） | high | TI-DOCKER-RUNTIME-CAP-DANGEROUS |
| runtime-no-new-priv-missing | `HostConfig.SecurityOpt` 不含 `no-new-privileges:true` 且 User=root | medium | TI-DOCKER-RUNTIME-NO-NEW-PRIV |

每条命中 emit 一个 Finding，evidence 字段：

```json
{
  "container_id": "a1b2c3d4e5f6",
  "image": "redis:7.2",
  "names": ["redis-cache"],
  "hit_field": "HostConfig.Privileged",
  "hit_value": true
}
```

**Redactor 处理**：
- `Config.Env` 整段在解析阶段直接丢弃（不进 evidence、不进 audit-log）
- 其余字段经 `ctx.redactor.redact()` 兜底

### 5.3 `docker_image_cve`

**id**：`docker_image_cve`
**数据来源**：独立调用一次 `docker ps --format '{{json .}}' --no-trunc`（与 5.2 不共享）；提取 `image` 字段

**匹配逻辑**：对每个 `image`，按 `container_baseline.yaml:image_patterns` 段下的 fnmatch 列表逐条匹配，命中即 emit。同一镜像匹中多条规则各自 emit（fingerprint 不同）。

**baseline 形态**

```yaml
image_patterns:
  - pattern: "*:latest"
    severity: medium
    title: "镜像未固定版本（:latest）"
    description: "使用 :latest tag 无法保证可重复部署，潜在被替换为漏洞镜像"
    remediation: "改用具体版本号或 sha256 digest 锁定镜像"
    threat_refs: ["TI-DOCKER-IMAGE-LATEST"]
  - pattern: "python:2.*"
    severity: high
    title: "Python 2 镜像（已 EOL）"
    description: "Python 2 自 2020-01-01 起停止维护，CVE 不再修复"
    remediation: "升级到 Python 3.11+ 镜像"
    threat_refs: ["TI-DOCKER-IMAGE-PYTHON2-EOL"]
  - pattern: "node:1[0-4]*"
    severity: high
    threat_refs: ["TI-DOCKER-IMAGE-NODE-EOL"]
    # ... 其余字段从默认占位
```

第一期 8–12 条手工高价值规则，按周补。

## 6. ssh_policy.yaml 改动

**新增 allowed_paths**

```yaml
- {kind: exact, path: "/etc/docker/daemon.json"}
```

**新增 commands.docker 块**

```yaml
docker:
  allowed_argv:
    - ["docker", "version", "--format", "{{json .}}"]
    - ["docker", "info",    "--format", "{{json .}}"]
    - ["docker", "ps",      "--format", "{{json .}}", "--no-trunc"]
    - ["docker", "ps",      "--format", "{{json .}}", "--no-trunc", "-a"]
  args_schema:
    - role: subcommand
      allowed: ["inspect"]
    - role: positional
      kind: container_id
      required: true
```

## 7. args_schema.py 改动

新增 `kind: container_id` 分支，正则 `^[a-f0-9]{12,64}$`：
- 拒大写字母（避免 `0xDEADBEEF` 形态）
- 拒 < 12 字符（避免 `a` 形态触发歧义匹配）
- 拒元字符（沿用 metachar_guard 全局兜底）

与现有 `path` / `pattern` / `sysctl_key` / `unit` / `since` / `lines` 同级，单独的 `_validate_container_id(value)` 函数即可。

## 8. threat_intel.yaml 追加条目

21 条 `TI-DOCKER-*` (6 daemon + 7 runtime + 8 image)，全部 `auto_refresh: false`（curated 不该被自动覆盖）。示例：

```yaml
- id: TI-DOCKER-DAEMON-TLS-DISABLED
  source: hand-curated
  claim: "Docker daemon 监听 TCP 但未启 tlsverify，等价于无认证 root API"
  confidence: high
  mapped_tests: ["docker_daemon_audit"]
  cvss: 9.8
  cvss_source: "CIS Docker Benchmark v1.6.0 §2.6"
  url: "https://docs.docker.com/engine/security/protect-access/"
  auto_refresh: false
- id: TI-DOCKER-RUNTIME-PRIVILEGED
  source: hand-curated
  claim: "容器以 --privileged 运行，等价于宿主 root 访问"
  confidence: high
  mapped_tests: ["docker_runtime_audit"]
  cvss: 9.0
  cvss_source: "CIS Docker Benchmark v1.6.0 §5.4"
  url: "https://docs.docker.com/engine/reference/commandline/run/#privileged"
  auto_refresh: false
# ... 余下 9 条同形态
```

`scripts/build_cve_db.py --check` 在 CI 中运行；`TI-DOCKER-*` 因不带 `affected_versions` 不会进 cve_database.json，不影响 `version_patch` 行为。

## 9. 错误处理与三态语义

| 情形 | Check 状态 | 备注 |
|---|---|---|
| `detect_docker()` 返回 None | `not_applicable` | scoring 分母不计 |
| Docker 装了但 `daemon.json` 不存在 | completed + 1 info finding | 不是错误 |
| `docker ps` 返回 exit_code != 0 且 stderr 含 `permission denied` | `skipped` | reason: "ssh user 不在 docker 组" |
| 单条 `docker inspect` 失败 | 跳该容器，整 Check 完成 | partial failure 不升级 |
| CommandPolicy 拒绝 | `skipped` | 理论上不会发生 |
| 三个子调用全部失败 | `skipped` | 与 7e.1 world_writable 一致 |

## 10. 性能预算

- 单 Check 串行：daemon ~3 秒、runtime ~5 秒（10 容器场景）+ ~0.3s/容器、image ~3 秒
- 总耗时（10 容器）：约 15 秒，远在 evaluate orchestrator 容忍范围内
- 容器数 > 200：截断 + emit info finding 警告

## 11. 测试策略

### 11.1 单元测试

```
tests/audit/checks/
├── test_docker_daemon_audit.py
├── test_docker_runtime_audit.py
└── test_docker_image_cve.py
tests/audit/
└── test_container_baseline.py
```

复用现有 `FakeSSHExecutor`。固件目录 `tests/fixtures/container/`：
- `daemon-json-tls-exposed.json`
- `daemon-json-default.json`
- `docker-version-24.0.7.json`
- `docker-info-userns-disabled.json`
- `docker-ps-3-containers.json`
- `inspect-privileged.json`
- `inspect-host-net.json`
- `inspect-sock-mount.json`
- `inspect-clean.json`

每 Check 至少覆盖：
- 未装 Docker → not_applicable
- 命中 1 条规则 → 1 finding，evidence/threat_refs/severity 全验
- 命中多条规则 → fingerprint 全部唯一
- `docker ps` 失败 → skipped
- partial failure（inspect 中途失败）→ 跳该容器继续
- `Config.Env` 中含 mock secret → 断言 evidence **完全不含**该 key

### 11.2 ssh_policy 校验测试

`tests/audit/test_command_policy.py` 追加：
- `kind: container_id` 正则边界：`a1b2c3d4e5f6` 通过、`a1b2c3d4e5f`（11 字符）拒、`a1b2c3d4e5f6;rm` 拒、`A1B2c3d4e5f6` 拒
- `["docker", "inspect", "a1b2c3d4e5f6"]` 通过
- `["docker", "exec", ...]`、`["docker", "pull", ...]`、`["docker", "run", ...]` 全部拒（白名单不含）

### 11.3 集成测试

新增 `tests/integration/test_container_audit_offline.py`：mock SSH executor 注入容器固件、跑完 3 Check、断言 finding 总数 + 报告 markdown 渲染段落。

不在测试里跑真 Docker。Lightsail 真机冒烟由运维手动执行。

## 12. 文档与发版

- `ROADMAP.md`：7f 打勾 + 注完成日期
- `CHANGELOG.md`：v0.10.0 段补"3 类 Docker Check + 21 条 TI"
- `CLAUDE.md`：Server-audit 段 "Total checks (v0.2.0):" 那行更新为 v0.10.0 + 21 类
- `docs/adr/0010-container-audit.md`：新增（实现完成后落档）
- `docs/guide/`：暂不加专章，README 一段说明即可

## 13. 实施顺序（粗）

1. `args_schema.py` 加 `kind: container_id` + 单测
2. `ssh_policy.yaml` 加 `docker:` 块 + policy 测试
3. `container_baseline.yaml` 草稿（含 8–12 条 image patterns）
4. `threat_intel.yaml` 追加 21 条 TI（运行 build_cve_db.py 同步）
5. `docker_daemon_audit.py` + 测试 + 固件
6. `docker_runtime_audit.py` + 测试 + 固件
7. `docker_image_cve.py` + 测试 + 固件
8. 集成测试 + cli.py 注册
9. ROADMAP / CHANGELOG / CLAUDE.md / ADR-0010
10. 真机冒烟（Lightsail，可选）+ tag v0.10.0 + PyPI 发布

## 14. 风险与开放问题

- **风险**：`docker ps --format '{{json .}}'` 的输出格式 v24+ 才稳定；老版本（< 20.10）需要降级 fallback。第一期假设 v20.10+，更老版本 `docker ps` 失败即 Check skipped。
- **风险**：被审 ssh user 不在 `docker` 组时，所有 Check 均 skipped。运维需在 AUTHORIZATION.txt 显式说明"已确认 ssh user 有 docker 命令权限"。
- **开放问题**：containerd / podman 适配是否后续 Phase 7f.1 / 7f.2 拆分，待社区反馈。
