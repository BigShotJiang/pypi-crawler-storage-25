# Report Viewer — Design Spec

**Date:** 2026-05-04
**Status:** Approved

---

## 1. Goal

Add `agentsec serve <output-dir>` — a local Flask web server that renders
`agentsec evaluate` / `agentsec multi-evaluate` artifacts as an interactive
HTML dashboard, replacing manual Markdown file inspection.

---

## 2. CLI

```
agentsec serve <output-dir> [--port 8080] [--host 127.0.0.1]
```

| Argument / Flag | Description |
|-----------------|-------------|
| `output-dir` | Path to an evaluate output directory (required) |
| `--port` | TCP port; default `8080` |
| `--host` | Bind address; default `127.0.0.1` |

**Auto-detection** — at startup, `reader.detect_mode(path)` inspects the
directory:

- `findings.json` exists directly under `output-dir` → **single-target mode**;
  the target name is the directory's `stem`.
- One or more subdirectories each contain `findings.json` → **multi-target
  mode**; each subdirectory is one target.
- Neither condition is met → `typer.Exit(1)` with a descriptive error message.

**Startup output** (no auto-open — incompatible with SSH environments):

```
Serving AgentSec report at http://127.0.0.1:8080
Press Ctrl+C to stop.
```

Exit code `0` on clean Ctrl+C; `1` on startup error.

---

## 3. Module Layout

```
src/agentsec/serve/
  __init__.py          # empty
  app.py               # Flask app factory create_app(output_dir) + routes
  reader.py            # Pure I/O functions; no Flask imports
  templates/
    base.html          # Bootstrap 5 CDN layout, nav, filter JS
    dashboard.html     # extends base — target list table (multi) or redirect (single)
    target.html        # extends base — score card + findings table
    report.html        # extends base — rendered Markdown page
```

`serve/` is imported only when the `serve` command runs — Flask is not imported
at module level in `cli.py`.

---

## 4. Data Layer (`reader.py`)

All functions are pure (no Flask/HTTP imports). Input is always a
`pathlib.Path`.

### 4.1 `detect_mode(base: Path) -> Literal["single", "multi"] | None`

Returns `"single"` if `base/findings.json` exists, `"multi"` if any immediate
subdirectory contains `findings.json`, `None` if neither.

### 4.2 `list_targets(base: Path, mode: str) -> list[TargetSummary]`

```python
@dataclass
class TargetSummary:
    name: str
    output_dir: Path
    grade: str           # from combined-report.md meta comment; "UNKNOWN" if missing
    combined_score: float | None
    remote_score: float | None
    server_score: float | None
    critical_count: int
    high_count: int
    has_findings: bool   # False when findings.json absent (partial evaluate)
```

In single-target mode returns a one-element list. Targets whose directory
lacks `findings.json` are included with `has_findings=False`.

### 4.3 `load_findings(target_dir: Path) -> list[dict]`

Returns parsed `findings.json` as a list of dicts. Returns `[]` if the file is
absent.

### 4.4 `parse_scores(target_dir: Path) -> dict[str, Any]`

Reads `combined-report.md` and extracts the HTML meta comments:

```
<!-- meta:remote_score value:33.33 -->
<!-- meta:server_score value:91 -->
<!-- meta:combined_score value:62.17 -->
<!-- meta:grade value:C -->
```

Returns `{"remote_score": 33.33, "server_score": 91.0, "combined_score":
62.17, "grade": "C"}`. Missing keys have value `None`.

Also reads `findings.json` to compute `verdict_coverage` and `error_rate`
fields if `combined-report.md` does not embed them.

### 4.5 `render_markdown(target_dir: Path, filename: str) -> str | None`

Reads `target_dir / filename`, converts to HTML via `markdown.markdown()`.
Returns `None` if the file does not exist.

---

## 5. Flask App (`app.py`)

### 5.1 Factory

```python
def create_app(output_dir: Path) -> Flask:
    ...
```

Detects mode, stores `output_dir` and `mode` in `app.config`. Raises
`ValueError` if mode is `None` (caller converts to `typer.Exit(1)`).

### 5.2 Routes

#### `GET /`

- Multi-target: renders `dashboard.html` with `list_targets(...)`.
- Single-target: redirects to `/target/<name>`.

#### `GET /target/<name>`

Loads `TargetSummary` + `load_findings` + `parse_scores`, renders
`target.html`.

Returns HTTP 404 if the target directory does not exist.

#### `GET /target/<name>/report/<filename>`

`filename` restricted to `{combined,remote,server-audit}-report.md` (allowlist
— prevents path traversal). Renders `report.html` with converted HTML.

Returns HTTP 404 if file not found.

#### `GET /api/targets`

Returns `list[TargetSummary]` serialized as JSON (dataclass → dict via
`dataclasses.asdict`, `Path` fields stringified).

#### `GET /api/targets/<name>/findings`

Returns `load_findings(target_dir)` as JSON. HTTP 404 if target unknown.

#### `GET /api/targets/<name>/score`

Returns `parse_scores(target_dir)` as JSON. HTTP 404 if target unknown.

### 5.3 Security

- `filename` in `/target/<name>/report/<filename>` is validated against the
  allowlist `{"combined-report.md", "remote-report.md",
  "server-audit-report.md"}` before any file access. Any other value → HTTP
  400.
- `output_dir` is resolved to an absolute path at startup; no user-supplied
  path component is ever joined after that except for the validated `name`
  (which must match an entry in `list_targets`) and the `filename` allowlist.

---

## 6. Templates

All templates extend `base.html`:

- Bootstrap 5.3 via CDN (`https://cdn.jsdelivr.net/npm/bootstrap@5.3`)
- No JavaScript framework; vanilla JS only
- Color-coding for severity: `critical` → red badge, `high` → orange,
  `medium` → yellow, `low` → blue, `info` → grey
- Grade color: A/B → green, C → yellow, D/F/LOW_COV → red, ERROR/UNKNOWN → grey

### `dashboard.html`

Table columns: **Target** (link) | **Grade** | **Score** | **Remote** |
**Server** | **Critical** | **High**

`INCOMPLETE` badge for targets with `has_findings=False`.

### `target.html`

**Score card** (top): Grade (large badge) | Combined | Remote | Server |
verdict_coverage | error_rate

**Findings table**: Check | Severity | Title | Description | Remediation

**Filter bar** (vanilla JS): severity multi-select checkboxes + check-name
text filter. Filtering happens client-side with `display:none` on `<tr>`.

**Report links** (bottom): three `<a>` tags for the three `.md` files,
only rendered if the file exists.

### `report.html`

Rendered Markdown inside a `<div class="markdown-body">` with modest CSS.
Breadcrumb: Dashboard → Target → Report name.

---

## 7. New Dependencies

Added to `[project.dependencies]` in `pyproject.toml`:

```
"flask>=3.0",
"markdown>=3.6",
```

---

## 8. Testing

### `tests/serve/test_reader.py`

Uses `docs/samples/report-2026-04-28/` (single-target) and a temp directory
(multi-target with two fake `findings.json` subdirs).

- `detect_mode`: single, multi, none
- `list_targets` single mode: one entry, correct grade/scores
- `list_targets` multi mode: two entries; one with missing `findings.json`
  → `has_findings=False`
- `load_findings`: valid file, missing file → `[]`
- `parse_scores`: parses all four meta fields from sample report
- `render_markdown`: valid file, missing file → `None`

### `tests/serve/test_app.py`

Uses Flask `app.test_client()`. Fixture: single-target pointing at
`docs/samples/report-2026-04-28/`.

- `GET /` → 302 redirect to `/target/<name>`
- `GET /target/<name>` → 200, contains grade string
- `GET /target/<name>/report/combined-report.md` → 200, contains `<h1`
- `GET /target/<name>/report/../../etc/passwd` → 400
- `GET /api/targets` → 200, JSON list with `name` field
- `GET /api/targets/<name>/findings` → 200, JSON list
- `GET /api/targets/nonexistent` → 404

---

## 9. Files Changed

| File | Change |
|------|--------|
| `src/agentsec/serve/__init__.py` | New (empty) |
| `src/agentsec/serve/app.py` | New: Flask app factory + routes |
| `src/agentsec/serve/reader.py` | New: pure I/O helpers |
| `src/agentsec/serve/templates/base.html` | New: Bootstrap layout |
| `src/agentsec/serve/templates/dashboard.html` | New |
| `src/agentsec/serve/templates/target.html` | New |
| `src/agentsec/serve/templates/report.html` | New |
| `src/agentsec/cli.py` | Add `serve` command (lazy Flask import) |
| `pyproject.toml` | Add `flask>=3.0`, `markdown>=3.6` |
| `tests/serve/test_reader.py` | New |
| `tests/serve/test_app.py` | New |
| `CHANGELOG.md` | Entry for v0.7.0 |
| `ROADMAP.md` | Tick off Web UI item |

---

## 10. Out of Scope

- Authentication / access control (local-only tool)
- WebSocket live-reload when files change
- Export / print view
- Dark mode toggle
- Pagination of findings (reports are small enough to fit in one page)
