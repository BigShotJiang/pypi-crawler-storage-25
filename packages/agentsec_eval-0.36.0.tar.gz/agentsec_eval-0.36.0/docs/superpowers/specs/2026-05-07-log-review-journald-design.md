# log_review 接 journald — 设计 Spec

**Date:** 2026-05-07
**Status:** Approved

---

## 1. 目标

让 OpenClaw 的 `systemd --user` 部署形态（如 Lightsail prod）在
`agentsec server-audit` / `agentsec evaluate` 流水线里产出真实的
`log_review` finding，而不是被打成 `not_applicable`。

当前 `LINUX_USER_MODE` profile 故意省了 `paths["log_dir"]`，因为
日志在 journald 而不在文件系统，老的 file-based `LogReviewCheck`
没法处理。本次设计补足 journald 读取路径，同时保持 `LINUX` /
`MACOS` 文件型路径行为完全不变。

---

## 2. 不在范围内

- macOS 的 `unified logging`（`log show`）— `~/Library/Logs/openclaw/`
  仍是 macOS 主路径，FileLogSource 已足够。
- 远端 `journalctl --grep` 或 `… | grep` — policy 永久拒收 shell
  metachar / pipe；远端 `--grep` 是 ERE 正则，会破坏现有 `-F`
  fixed-string 契约并引入 ReDoS 面。
- 多窗口扫描（如 24h + 7d 双层）— YAGNI。

---

## 3. PlatformProfile schema 改动

新增 `log_source` 字段（可选）。Discriminated union：

```python
# src/agentsec/audit/platform_profile.py

class FileLogSource(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["files"] = "files"
    log_dir: str            # 沿用 ~/ 语义；materialize_paths 会展开

class JournaldLogSource(BaseModel):
    model_config = ConfigDict(frozen=True)
    kind: Literal["journald"] = "journald"
    user: bool                  # True → journalctl --user
    units: tuple[str, ...]      # 至少 1 项；空元组报 ValidationError

LogSource = Annotated[
    FileLogSource | JournaldLogSource,
    Field(discriminator="kind"),
]

class PlatformProfile(BaseModel):
    ...
    log_source: LogSource | None = None
    # None ⇒ 平台未暴露日志；log_review 直接 not_applicable
```

`materialize_paths(profile, remote_home)` 扩展：当
`log_source` 是 `FileLogSource` 时，对其 `log_dir` 字段做与既有
`paths` 同样的 `~/` 展开；`JournaldLogSource` 直通。返回的依然是
新的 frozen profile。

### 三个 profile 的取值

| Profile | `log_source` |
|---|---|
| `LINUX` | `FileLogSource(log_dir="/var/log/openclaw/")` |
| `LINUX_USER_MODE` | `JournaldLogSource(user=True, units=("openclaw-gateway.service", "openclaw-node.service"))` |
| `MACOS` | `FileLogSource(log_dir="~/Library/Logs/openclaw/")` |

老的 `paths["log_dir"]` 字段在 `LINUX` / `MACOS` 上保留作过渡，
本次不删除（避免影响外部 fixture / 测试）。下一个 minor
（v0.10.0）移除并在 CHANGELOG 标注。

---

## 4. LogReviewCheck 重写

不再用 `_REQUIRED_PATHS=("log_dir",)` 作 not_applicable 闸门。
改成读 `ctx.profile.log_source` 分派。

```python
class LogReviewCheck(Check):
    id = "log_review"
    _REQUIRED_PATHS: tuple[str, ...] = ()    # 闸门下移到 log_source

    async def run(self, ctx: CheckContext) -> list[Finding]:
        src = ctx.profile.log_source
        if src is None:
            ctx.status.not_applicable("log_review:当前平台未暴露日志源")
            return []
        sigs = self._load_signatures(ctx)
        if sigs is None:
            return []  # _load_signatures 已发出 skipped
        if isinstance(src, FileLogSource):
            return await self._scan_files(ctx, src, sigs)
        return await self._scan_journald(ctx, src, sigs)
```

`_scan_files` 是把现有 `run()` 主体搬过去，零行为变化（保持
fingerprint 稳定 → committed sample 不动）。

`_scan_journald` 新逻辑：

1. 读取 `ctx.config.server_audit.log_review.journald_since_hours`
   （默认 24）和 `journald_max_lines`（默认 10000）。
2. 对每个 unit 跑：
   ```
   journalctl [--user] --no-pager --output=cat \
     -u <unit> --since "<N> hours ago" --lines <max_lines>
   ```
   `--user` 标志取决于 `JournaldLogSource.user`。
3. evaluator 本地用 Python 字符串匹配跑所有 signature
   （等价 `grep -i -F`：lower-case fold 后 `pattern.lower() in line.lower()`，
   行级计数）。
4. 每个 (signature, unit) 命中产 1 个 Finding，evidence 至少含：
   `unit`、`match_count`、`journald_user`、`since_hours`、`lines_cap`。
   严重度沿用 signature 自带 `severity`。
5. 截断双信号：
   - 真实返回行数 == `lines_cap` → 1 个 info finding（覆盖不全）
   - stdout 字节数 ≥ `max_output_bytes × 0.95`（policy 上限 1 MiB）
     → 同样 1 个 info finding（每个 run 至多一条，避免 unit 多重叠加）
6. 单个 unit 失败（exit≠0 或 `Unit X could not be found`）：
   skip 那个 unit，其他 unit 继续。所有 unit 都失败 → `skipped`
   整个 check。

> **为何在 evaluator 本地 grep**：(a) policy 不允许 shell metachar /
> pipe，远端 grep 走不通；(b) `journalctl --grep` 是 ERE 正则，
> 会把 signature `pattern` 当正则解释 — 与现有 `-F`（fixed-string）
> 契约冲突，可能误杀或 ReDoS。

---

## 5. SSH policy 扩展

新增 `journalctl` 命令、三个占位符 kind。

```yaml
# src/agentsec/audit/ssh_policy.yaml
journalctl:
  allowed_argv:
    - ["journalctl", "--user", "--no-pager", "--output=cat",
       "-u", "<unit>", "--since", "<since>", "--lines", "<lines>"]
    - ["journalctl",            "--no-pager", "--output=cat",
       "-u", "<unit>", "--since", "<since>", "--lines", "<lines>"]
```

policy 校验器（`src/agentsec/audit/ssh_policy.py`）的 placeholder
dispatch 表新增三个 kind：

| 占位符 | 正则 | 说明 |
|---|---|---|
| `<unit>` | `^[A-Za-z0-9._@-]+\.service$` | 长度 ≤ 128；只允许 systemd unit 命名字符 |
| `<since>` | `^[1-9][0-9]{0,3} hours? ago$` | 1–9999 小时；与 `journald_since_hours` 渲染输出一一对应。"days" 分支故意不开 — 现版本只 emit hours，加上反而扩大 policy surface |
| `<lines>` | `^[1-9][0-9]{1,5}$` | 10–999999 |

未列出的 journalctl flag（`--grep` / `--output=json` / `-p` /
`-k` / `-b` / `-S` / `-U` / `--system` 等）默认拒收，不需要显式
deny-list — `allowed_argv` 是白名单语义。

---

## 6. 配置字段

`ServerAuditConfig` 新增 `log_review` 子块（默认值即 production
默认；零配置照样跑）：

```python
# src/agentsec/config.py
class LogReviewConfig(BaseModel):
    model_config = _FORBID
    journald_since_hours: int = Field(default=24, ge=1, le=168)
    journald_max_lines: int = Field(default=10_000, ge=100, le=100_000)

class ServerAuditConfig(BaseModel):
    model_config = _FORBID
    ...
    log_review: LogReviewConfig = Field(default_factory=LogReviewConfig)
```

YAML 写法（取证 / 周复盘场景）：

```yaml
server_audit:
  ...
  log_review:
    journald_since_hours: 168
    journald_max_lines: 50000
```

### 上下文传入

`CheckContext` 新增字段 `log_review_config: LogReviewConfig`
（在 `server_audit` 命令里从 `cfg.server_audit.log_review` 取，
`evaluate` 命令同理）。`LogReviewCheck` 通过 `ctx.log_review_config`
读取，而不是穿透完整 config 对象 — 与既有 ctx 抽象一致。

---

## 7. 错误处理矩阵

| 情况 | 行为 |
|---|---|
| `log_source is None` | `not_applicable("log_review:当前平台未暴露日志源")` |
| signatures 文件缺失 / `ioc_dir` 未配置 | `skipped(<原因>)`（沿用现有逻辑） |
| `journalctl` 退出码非 0 且单个 unit 失败 | 跳过那个 unit;诊断进 `ctx.status.warning(...)`，stderr 前 200 字节附在诊断里 |
| 所有 unit 都失败 | `skipped("log_review:所有 unit 均不可读")` |
| 某 unit 真实返回行数 == `lines_cap` | 1 个 info finding（每 run 至多一条） |
| 某 unit stdout 字节数 ≥ `max_output_bytes × 0.95` | 同上 info finding |
| signature `pattern` 含 shell metachar | 走文件路径时被 policy 拒（既有行为）;走 journald 路径时本地 Python 匹配，metachar 安全（无 shell） |
| `journald_since_hours` / `journald_max_lines` 越界 | pydantic ValidationError，配置加载即失败（`extra="forbid"` + Field constraints） |

---

## 8. 测试

### 单元测试

- `tests/audit/test_platform_profile.py`
  - `LogSource` discriminated union 正负 case：`kind` 错值、`units` 空元组、`log_dir` 缺失各报 ValidationError
  - `materialize_paths` 对 `FileLogSource.log_dir` 的 `~/` 展开
  - `materialize_paths` 对 `JournaldLogSource` 直通不变
- `tests/audit/test_ssh_policy.py`
  - 三个新占位符 kind 的 happy path + 拒绝 case：
    - `<unit>` 拒绝：含 `;`、`/`、`$`、空字符串、缺 `.service` 后缀、超 128 字节
    - `<since>` 拒绝：`0 hours ago`、`12 minutes ago`、`24 days ago`（days 分支未开放）、含 `;`、含空格中夹 `&`
    - `<lines>` 拒绝：`9`、`0`、负数、`1000000`、含小数
- `tests/audit/checks/test_log_review.py`（既有文件扩写）
  - `_scan_files` 路径回归：现有所有 case 行为不变（无新增 mock）
  - `_scan_journald` 新增：
    - stub executor 返回固定 stdout，断言 finding 数 / 严重度 / fingerprint
    - 多 unit：第一个返回有效行、第二个 `Unit not found` → 第二个跳过、第一个仍命中
    - 截断信号：返回行数 == `lines_cap` → 多 1 条 info finding
    - 字节截断：stdout 长度 = `max_output_bytes × 0.96` → 多 1 条 info finding
    - 双截断：行数到顶 + 字节也到顶 → **仍只 1 条** info finding（每 run 至多一条）
- `tests/test_config_model.py`
  - `LogReviewConfig` 默认值;字段越界拒绝;`extra="forbid"` 拒绝未声明 key

### 集成测试

- `tests/integration/test_openclaw_stage_e_smoke.py`
  扩展 smoke matrix：`LINUX_USER_MODE` profile + 一个返回固定 stdout
  的 stub executor → 断言 `log_review` 出现且非 `not_applicable`，
  `findings.json` 含至少一个 `check: "log_review"` 项。

### sample report 影响

`docs/samples/report-2026-04-28/` 是用 `LINUX` profile + file-based
日志源生成的，本次改动只追加 `log_source` 字段、`_scan_files` 行为不变，
**fingerprint 不动 → committed sample drift guard 不需要 refresh**。

CI 矩阵里 `tests/integration/test_openclaw_mock.py::test_committed_sample_matches_pipeline_output`
仍应当过；如果意外 drift，必须排查是不是行为偷偷变了，再决定是否
`AGENTSEC_REFRESH_SAMPLE=1` 重生。

---

## 9. 文档同步

- `CLAUDE.md` 「Stage E additions」：补 `log_source` / `LogReviewConfig` 段落；
  把 `log_review: read journald via 'journalctl --user -u openclaw-gateway' for systemd --user mode (currently not_applicable because no log_dir)` 这条 TODO 划掉
- `CHANGELOG.md` 在 `[Unreleased]` 加 `### Added` 条目
- `docs/guide/`：暂不动（user-facing 默认行为没变;运维要拉长窗口的话
  靠 spec + CHANGELOG 引导即可）

---

## 10. 验收 checklist

- [ ] `LINUX_USER_MODE` profile 的 server-audit run，`log_review` 状态
      不再是 `not_applicable`
- [ ] Lightsail prod replay（`memory: project_openclaw_lightsail_prod.md`
      里的 dry-run command）能产出至少 1 个 log_review finding
      （或 0 命中 + 1 个截断 info finding，前提是日志确实没命中
      signature；总之状态从 not_applicable 变成 ok）
- [ ] 既有 `LINUX` / `MACOS` profile 的 server-audit + 既有
      committed sample 完全不变（fingerprint 稳定）
- [ ] 全部 ruff + pyright + 901+ pytest 全过
- [ ] CHANGELOG / CLAUDE.md 同步落地
