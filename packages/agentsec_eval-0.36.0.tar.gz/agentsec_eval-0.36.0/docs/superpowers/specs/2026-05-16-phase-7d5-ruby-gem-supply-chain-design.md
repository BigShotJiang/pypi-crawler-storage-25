# Phase 7d.5 — Ruby/Gem supply chain audit 设计

**状态**: 草案
**日期**: 2026-05-16
**前置**: Phase 7d.4（v0.34.0，Java/Maven supply chain）
**目标版本**: v0.35.0

## 1. 背景与动机

7d series 已 ship 5 个 ecosystem supply chain Check：

| Phase | Ecosystem | Version | DB |
|---|---|---|---|
| 7d | npm | v0.12.0 | osv_npm.json |
| 7d.1 | pip | v0.13.0 | osv_pypi.json |
| 7d.2 | go | v0.14.0 | osv_go.json |
| 7d.3 | rust/cargo | v0.15.0 | osv_cargo.json |
| 7d.4 | java/maven | v0.34.0 | osv_maven.json |

Ruby/Gem 是后端语言主流 6 大生态之一（JavaScript / Python / Go / Rust / Java / Ruby），加上即达成"主流后端语言全覆盖"里程碑。7d.5 引入第 6 个 ecosystem，模式镜像 7d.4 maven，差异点：

1. **Bundler `Gemfile.lock` 是 ruby 事实标准 lockfile** —— 与 cargo (Cargo.lock) / go (go.sum) 类型一致：已解析 transitive 依赖
2. **RubyGems 版本语义近似 PEP 440** —— 比 semver 宽容（接受 `1.0.0.pre.1` / `1.0.0.rc1` 等 pre-release 后缀），但与 PEP 440 接近。复用 `packaging.version`（pip ecosystem 已有的依赖），用简单字符串预处理桥接两套规范，避免再写一个 comparator。

## 2. 范围

**v1 包含**：

- 新 Check `src/agentsec/audit/checks/gem_supply_chain_audit.py` ——
  `GemSupplyChainAuditCheck`，镜像 `JavaSupplyChainAuditCheck`
- 新 fetcher `src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py`
  —— `OsvRubyGemsFetcher`，镜像 `OsvMavenFetcher`
- `src/agentsec/audit/checks/_supply_chain_common.py` 添加：
  - `parse_gemfile_lock(text) -> list[(gem_name, version)]`
  - `_is_gem_version_in_range(version, intro, fixed) -> bool`（thin wrapper over `packaging.version.Version` + RubyGems→PEP 440 字符串预处理）
- 新 DB `src/agentsec/audit/ioc/osv_rubygems.json`（live ioc-update build）
- 新 CI guard `scripts/check_osv_rubygems.py` —— JSON 合法 + 15 MB 上限
- `src/agentsec/config.py:ServerAuditConfig.gem_lock_paths: list[str]`
  + path validator（**strict basename == "Gemfile.lock"**，cargo 同模式）
- `CheckContext.gem_lock_paths`
- `src/agentsec/cli.py`：`server-audit` + `_evaluate_server` 加
  `--gem-lock-path` 可重复
- `threat_intel.yaml` 加 `TI-OSV-RUBYGEMS-CATALOG` umbrella entry
- `ioc_update/cli.py` 加 `_run_osv_rubygems`，与 npm/pypi/go/cargo/maven
  通过 `asyncio.gather` 并行 6-way
- ADR-0025 + CHANGELOG / ROADMAP / CLAUDE.md / pyproject v0.35.0
- 新 unit tests（~29 case，详 §7）

**v1 不包含**（明确延后）：

- **非 Bundler 锁文件**（`gem list --local` 输出等）—— `Gemfile.lock`
  是 ruby 事实标准，覆盖 99% real-world ruby 应用
- **Gem source 多源**（私有 gemserver / git source / path source）——
  OSV-RubyGems 只覆盖 rubygems.org 公共源；parser 显式跳过 `GIT` /
  `PATH` 段
- **判官 / scoring / report renderer 改动** —— 纯新增 Check
- **MCP / OWASP coverage gate 改动** —— 与本期正交

## 3. 设计

### 3.1 Gemfile.lock 输入格式与解析

Bundler 生成的 `Gemfile.lock` 文本格式：

```
GEM
  remote: https://rubygems.org/
  specs:
    actionmailer (7.0.4)
      actionpack (= 7.0.4)
      actionview (= 7.0.4)
    activesupport (7.0.4)
      i18n (>= 1.6, < 2)
      tzinfo (~> 2.0)
    rails (7.0.4)
      actioncable (= 7.0.4)
      ...

GIT
  remote: https://github.com/example/gem.git
  revision: abc123
  specs:
    private-gem (1.0.0)

PATH
  remote: vendor/local-gem
  specs:
    local-gem (0.1.0)

PLATFORMS
  ruby

DEPENDENCIES
  rails (~> 7.0.0)
```

**`parse_gemfile_lock(text: str) -> list[tuple[str, str]]`** 在
`_supply_chain_common.py`：

- 顺序扫描行，跟踪当前段（`GEM` / `GIT` / `PATH` / `PLATFORMS` /
  `DEPENDENCIES`）
- **只在 `GEM` 段内** 的 `specs:` 子段提取依赖
- 依赖行格式（4 空格缩进）：`    gem_name (version)`
- 6 空格缩进的行（如 `      actionpack (= 7.0.4)`）是 transitive
  constraint，跳过（不是已解析依赖本身）
- gem name 规范化为 lowercase（RubyGems 是 case-insensitive）
- 返回 `[(gem_name, version), ...]`

**正则**：

```python
_GEM_DEP_LINE = re.compile(
    r"^    ([a-zA-Z0-9._-]+) \(([^)]+)\)\s*$"
)
```

**Path 校验** `ServerAuditConfig.gem_lock_paths`：

- 必须 `/` 或 `~/` 开头
- 无 shell metachar
- **basename 必须 exactly equal `"Gemfile.lock"`**（cargo 同 strict 模式）

### 3.2 版本比较器（PEP 440 wrapper）

RubyGems 版本形如 `1.2.3` / `1.2.3.pre.1` / `2.0.0.rc1` /
`1.0.0.beta`。PEP 440 的 `packaging.version.Version` 处理形如
`1.2.3a1` / `1.2.3rc1` / `1.0.0b0`。**桥接靠简单字符串预处理**：

```python
from packaging.version import Version, InvalidVersion

def _normalize_gem_version(s: str) -> str:
    """RubyGems version → PEP 440 form."""
    if not s:
        return s
    # .pre.<N> → a<N>; .rc<N> stays as rc<N> (PEP 440 accepts)
    s = s.replace(".pre.", "a").replace(".pre", "a0")
    # .beta / .alpha standalone → bN/aN (treat unsuffixed as 0)
    # (PEP 440 already accepts "1.0.0.beta" via local segment? Test)
    return s


def _safe_parse_gem_version(s: str) -> Version | None:
    try:
        return Version(_normalize_gem_version(s))
    except (InvalidVersion, TypeError):
        return None


def _is_gem_version_in_range(version, introduced, fixed):
    v = _safe_parse_gem_version(version)
    if v is None:
        return False
    if introduced is not None:
        intro = _safe_parse_gem_version(introduced)
        if intro is not None and intro > v:
            return False
    if fixed is not None:
        fix = _safe_parse_gem_version(fixed)
        if fix is not None and v >= fix:
            return False
    return True
```

**已知 limitation**：
- 极少数 RubyGems 版本（如非标准 `.git.20250101` 后缀）可能 PEP 440
  解析失败 —— 静默跳过该 (gem, version)，不报 finding
- `.pre.` 后缀处理是 best-effort —— `1.0.0.pre.1` 与 `1.0.0a1` 视作
  等价（PEP 440 比较语义），对真实场景 99% 准确

### 3.3 `OsvRubyGemsFetcher`

`src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py` 镜像
`osv_maven.py`：

- URL: `https://osv-vulnerabilities.storage.googleapis.com/RubyGems/all.zip`
- Ecosystem 字符串: `"RubyGems"`（PascalCase，OSV 规范）
- Fetcher name: `_osv_rubygems_full`
- Package name: 单字符串 gem 名（lowercase，OSV 已规范）
- 5-轴 filter 链与 maven 完全同：drop withdrawn / no RubyGems
  affected / no range / no CVSS_V3 / scored medium-low > 2y
- multi-affected expansion；dedup on (id, package)

### 3.4 `GemSupplyChainAuditCheck`

`src/agentsec/audit/checks/gem_supply_chain_audit.py` 镜像
`java_supply_chain_audit.py`：

```python
class GemSupplyChainAuditCheck(Check):
    id = "gem_supply_chain_audit"
    description = (
        "Match Ruby gem dependencies (from Gemfile.lock) against "
        "the bundled OSV-RubyGems advisory DB."
    )

    def __init__(self):
        super().__init__()
        try:
            self._db = load_advisory_db("osv_rubygems.json")
        except FileNotFoundError:
            self._db = []  # DB not built yet (test-time isolation)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not ctx.gem_lock_paths:
            ctx.status.not_applicable("no gem_lock_paths configured")
            return []

        ctx.policy.add_runtime_allowed_paths(
            ctx.gem_lock_paths, kind="exact"
        )

        db_by_pkg = defaultdict(list)
        for advisory in self._db:
            db_by_pkg[advisory["package"]].append(advisory)

        findings = []
        for path in ctx.gem_lock_paths:
            text = await ctx.read_remote_file(path)
            for gem, version in parse_gemfile_lock(text):
                for advisory in _match_gem_advisories(gem, version, db_by_pkg):
                    findings.append(self.make_finding(
                        ctx, severity=..., title=..., evidence={
                            "gem": gem, "version": version,
                            "advisory_id": advisory["id"],
                            "fixed_in": ..., "lock_path": path,
                        },
                        threat_refs=["TI-OSV-RUBYGEMS-CATALOG"],
                    ))
        return findings
```

### 3.5 `TI-OSV-RUBYGEMS-CATALOG` 伞 entry

```yaml
  - id: TI-OSV-RUBYGEMS-CATALOG
    source: osv.dev (RubyGems ecosystem)
    claim: "Aggregated CVE catalog for RubyGems packages, sourced from OSV."
    confidence: high
    mapped_tests: [gem_supply_chain_audit]
    note: |
      Umbrella TI for all RubyGems CVE matches surfaced by
      gem_supply_chain_audit. Per-CVE advisory id surfaces directly
      in finding evidence (evidence.advisory_id). Refresh via
      `agentsec ioc-update`.
    auto_refresh: false
```

### 3.6 `_run_osv_rubygems` in ioc-update CLI

加在 `_run_osv_maven` 之后，6-way gather：

```python
results = await asyncio.gather(
    _run_osv_npm(...),
    _run_osv_pypi(...),
    _run_osv_go(...),
    _run_osv_cargo(...),
    _run_osv_maven(...),
    _run_osv_rubygems(...),  # NEW
)
```

## 4. 集成 / 不变量

| 切面 | 改动 |
|---|---|
| `gem_supply_chain_audit.py` | **新增** |
| `_supply_chain_common.py` | 加 `parse_gemfile_lock` + version helpers |
| `osv_rubygems.py` | **新增** |
| `ioc_update/cli.py` | 加 `_run_osv_rubygems` + 6-way gather |
| `osv_rubygems.json` | **新增**（live build） |
| `threat_intel.yaml` + cve_database.json | 加 TI entry |
| `scripts/check_osv_rubygems.py` | **新增** |
| `config.py` + `base.py` + `server_audit.py` | 加 `gem_lock_paths` |
| `cli.py` | 加 `--gem-lock-path` flag |
| 新测试 | ~29 unit tests |
| ADR-0025 + v0.35.0 docs | 标准 phase 收尾 |

**关键不变量**：

- 7d / 7d.1 / 7d.2 / 7d.3 / 7d.4 行为零变化
- Adapter / Judge / Scoring / Report renderer 零改动
- MCP coverage gate 不动（floor 14）
- baseline 1756 test pass 不变（+~29 新 = ~1785）
- 总 Check 数：36 → **37 类**

## 5. 错误处理

| 场景 | 处理 |
|---|---|
| `gem_lock_paths` 空 | `not_applicable` |
| Gemfile.lock 不存在 | ctx.read_remote_file 异常路径，转 skipped |
| Gemfile.lock 解析失败 / 无 GEM 段 | 空 findings，info log |
| 版本字符串 PEP 440 解析失败 | 跳过该 (gem, version)，log warning |
| Path 校验失败 (非 Gemfile.lock basename) | Pydantic validator raise，CLI 前置 |
| `osv_rubygems.json` 缺失 | __init__ try/except 兜底为空 DB（测试隔离） |
| OSV-RubyGems fetch HTTP fail | Fetcher 现有 retry/fail 路径 |

## 6. 测试策略

**单测**（~29 case）：

- `test_parse_gemfile_lock.py` ~5 case
  - 正常 GEM 段
  - 跳过 GIT / PATH 段
  - 跳过 transitive constraint (6-space 缩进)
  - 跳过 PLATFORMS / DEPENDENCIES 段
  - empty / 无 GEM 段
- `test_is_gem_version_in_range.py` ~10 case
  - `1.2.3` 在 `1.0..2.0` 范围内
  - `1.0.0.pre.1` < `1.0.0`
  - `2.0.0.rc1` < `2.0.0`
  - `1.0.0.beta` 范围匹配
  - 边界 introduced 包含 / fixed 排除
  - 无效版本字符串返回 False
  - missing introduced / fixed 处理
- `test_gem_supply_chain_audit.py` ~5 case（match / no match /
  empty paths / multi-gem / multi-advisory）
- `test_osv_rubygems_fetcher.py` ~4 case（mock httpx + normalize 单元）
- `test_config_gem_lock_paths.py` ~5 case（strict Gemfile.lock
  basename, 拒非 Gemfile.lock 文件名）

**集成测**：沿 7d.4 约定，无新 integration test。

**CI gates**：
- `pytest tests/` —— ~1785 PASS
- `scripts/check_osv_rubygems.py` —— PASS (≤ 15 MB)
- `scripts/check_osv_maven.py` / `check_osv_*.py` —— 其他 ecosystem 不动
- `scripts/check_owasp_coverage.py` —— 不动
- `ruff check src/ tests/` —— 干净

**OSV-RubyGems 首次 build**：Task 9 跑 `agentsec ioc-update`（live
HTTP）；OSV-RubyGems DB 预估 500-1500 entries（ruby 生态比 java
小），~300 KB - 1 MB。

## 7. 兼容性与迁移

- **现有 5 个 ecosystem**：独立运行，互不影响
- **`ServerAuditConfig`**：新增 `gem_lock_paths` 字段，默认 `[]`；
  现有 config 文件无需改动
- **CLI**：`--gem-lock-path` 是新 optional flag
- **OSV-RubyGems DB 大小预估**：参考 osv_cargo (545 KB / 1396 entries)
  与 osv_pypi (949 KB / 3452 entries)。Ruby 生态偏小，预估 500 KB-1 MB

## 8. 决策摘要

| 决策点 | 选择 | 理由 |
|---|---|---|
| Lockfile | `Gemfile.lock` only (Bundler) | Ruby 事实标准；含 transitive |
| 解析 | walk `GEM > specs:` 段，跳 GIT/PATH/transitive | OSV 不覆盖 git/path source |
| 版本比较 | `packaging.version` + RubyGems→PEP 440 简单预处理 | 零新代码（已是 pip 依赖）；99% 真实 ruby 版本可解析 |
| Path 校验 | strict basename == `Gemfile.lock` | Cargo.lock 同 strict 模式 |
| Gem name | lowercase 规范化 | RubyGems case-insensitive |
| OSV ecosystem | `RubyGems`（PascalCase） | OSV 规范 |
| Source 多源 | 仅 rubygems.org | 私服罕见，OSV 不覆盖 |
| ADR | 新写 ADR-0025 | 与 7d.4 同步留痕 |

## 9. 后续阶段路线

| 阶段 | 范围 | 依赖 |
|---|---|---|
| **7d.5（本期）** | ruby/gem supply chain（6 ecosystem 里程碑） | 7d.4 |
| 7d.6（潜在） | 第 7 ecosystem（swift/spm 或 .NET/nuget） | 7d.5 |
| 7d.4.1（潜在） | Gradle（复用 OSV-Maven DB） | 7d.4 |
| 7c.7 | stdio / SSE 真实传输层 | 任何 7c.x 之后 |

## 10. References

- ADR-0012-0015 —— Phase 7d / 7d.1 / 7d.2 / 7d.3
- ADR-0024 —— Phase 7d.4 java/maven
- ADR-0025（本 phase 新增）—— Phase 7d.5 ruby/gem
- OSV RubyGems ecosystem dump —— https://osv-vulnerabilities.storage.googleapis.com/RubyGems/all.zip
- 既有模板 —— `src/agentsec/audit/checks/java_supply_chain_audit.py` + `src/agentsec/audit/ioc_update/fetchers/osv_maven.py`
- 既有 common 层 —— `src/agentsec/audit/checks/_supply_chain_common.py`
