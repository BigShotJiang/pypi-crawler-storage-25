# Phase 7d.6 — PHP/Composer supply chain audit 设计

**状态**: 草案
**日期**: 2026-05-17
**前置**: Phase 7d.5（v0.35.0，Ruby/Gem supply chain）
**目标版本**: v0.36.0

## 1. 背景与动机

7d series 已 ship 6 个 ecosystem supply chain Check：

| Phase | Ecosystem | Version | DB |
|---|---|---|---|
| 7d | npm | v0.12.0 | osv_npm.json |
| 7d.1 | pip | v0.13.0 | osv_pypi.json |
| 7d.2 | go | v0.14.0 | osv_go.json |
| 7d.3 | rust/cargo | v0.15.0 | osv_cargo.json |
| 7d.4 | java/maven | v0.34.0 | osv_maven.json |
| 7d.5 | ruby/gem | v0.35.0 | osv_rubygems.json |

PHP / Composer 是第 7 个 ecosystem，目标"7 大主流语言全覆盖"（JavaScript / Python / Go / Rust / Java / Ruby / **PHP**）。Composer 生态商业广度最大——WordPress + Laravel + Symfony 占据后端 PHP 几乎全部市场份额，OSV-Packagist 是同等量级中 raw advisory bundle 最大的（8.9 MB vs Ruby 的 5.5 MB / Java 的 13 MB），filter 后预估 1.5-3 MB。

7d.6 引入第 7 个 ecosystem，模式镜像 7d.5 ruby，差异点：

1. **`composer.lock` 是 Composer 1.x / 2.x 共同事实标准 lockfile**——JSON 格式（区别于 7d.5 的文本格式），两个数组 `packages` (prod) + `packages-dev` (dev) 均需扫描
2. **Composer 版本语义近似 PEP 440 但比 RubyGems 复杂**——stability flags `dev < alpha < beta < RC < stable < patch` 与 PEP 440 `.devN < aN < bN < rcN < final < .postN` 一一对应。复用 `packaging.version`（pip ecosystem 已有的依赖），用 5 条字符串预处理规则桥接两套规范，避免重写 comparator。

## 2. 范围

**v1 包含**：

- 新 Check `src/agentsec/audit/checks/php_supply_chain_audit.py` ——
  `PhpSupplyChainAuditCheck`，镜像 `GemSupplyChainAuditCheck`
- 新 fetcher `src/agentsec/audit/ioc_update/fetchers/osv_packagist.py`
  —— `OsvPackagistFetcher`，镜像 `OsvRubyGemsFetcher`
- `src/agentsec/audit/checks/_supply_chain_common.py` 添加：
  - `parse_composer_lock(text) -> list[(package_name, version, scope)]`
  - `_is_composer_version_in_range(version, intro, fixed) -> bool`
    （thin wrapper over `packaging.version.Version` + Composer→PEP 440 字符串预处理）
- 新 DB `src/agentsec/audit/ioc/osv_packagist.json`（live ioc-update build）
- 新 CI guard `scripts/check_osv_packagist.py` —— JSON 合法 + 15 MB 上限
- `src/agentsec/config.py:ServerAuditConfig.composer_lock_paths: list[str]`
  + path validator（**strict basename == "composer.lock"**，cargo / gem 同模式）
- `CheckContext.composer_lock_paths`
- `src/agentsec/cli.py`：`server-audit` + `_evaluate_server` 加
  `--composer-lock-path` 可重复
- `threat_intel.yaml` 加 `TI-OSV-PACKAGIST-CATALOG` umbrella entry
- `ioc_update/cli.py` 加 `_run_osv_packagist`，与 npm/pypi/go/cargo/maven/rubygems
  通过 `asyncio.gather` 并行 7-way
- ADR-0026 + CHANGELOG / ROADMAP / CLAUDE.md / pyproject v0.36.0
- 新 unit tests（~30 case，详 §6）

**v1 不包含**（明确延后）：

- **`composer.json` 解析**（仅声明，未解析依赖）—— `composer.lock`
  是事实标准，含完整 transitive 依赖
- **Source 多源**（私有 Satis / git source / path source / VCS）——
  OSV-Packagist 只覆盖 packagist.org 公共源；parser 显式过滤
  `source.type == "composer"`
- **Composer global packages** (`~/.composer/vendor/`)——CI scope
  是项目 lockfile，全局包不在 Server audit 范围
- **`abandoned` / `replace` / `conflict` / `provide` 元字段**——
  不影响 vuln 匹配
- **判官 / scoring / report renderer 改动** —— 纯新增 Check
- **MCP / OWASP coverage gate 改动** —— 与本期正交

## 3. 设计

### 3.1 composer.lock 输入格式与解析

Composer 生成的 `composer.lock` 是 JSON 文件：

```json
{
  "_readme": [...],
  "content-hash": "...",
  "packages": [
    {
      "name": "monolog/monolog",
      "version": "2.9.1",
      "source": {
        "type": "git",
        "url": "https://github.com/Seldaek/monolog.git",
        "reference": "..."
      },
      "dist": {
        "type": "zip",
        "url": "https://api.github.com/repos/Seldaek/monolog/zipball/...",
        "reference": "..."
      },
      "require": {"php": ">=7.2", "psr/log": "^1.0.1 || ^2.0 || ^3.0"},
      ...
    }
  ],
  "packages-dev": [
    {
      "name": "phpunit/phpunit",
      "version": "9.6.13",
      "source": {"type": "git", ...},
      ...
    }
  ],
  "platform": {"php": ">=7.4"},
  "platform-dev": {},
  "plugin-api-version": "2.3.0"
}
```

**关键观察**：每个 package 的 `source.type` 字段标识来源——
`"git"`（默认，从 packagist.org 解析后从 git 拉取 → OSV 覆盖）/
`"path"`（本地路径 → 跳过）/ `"hg"` / `"svn"`（罕见 → 跳过）。
Composer 2.x 中所有 packagist.org 包都以 `source.type == "git"`
（指向 GitHub）+ `dist.type == "zip"`（packagist.org CDN）落盘。

**v1 采用简化策略**：仅过滤 `source.type == "path"`（明确本地引用，
OSV 必失配）；其余包（`git` / 缺失 source / `hg` / `svn`）全部进
匹配池。私服 / Satis 包名也是 `vendor/package` 形式但 OSV 不收录，
自然 0 命中——零误报，零代码复杂度。

**`parse_composer_lock(text: str) -> list[tuple[str, str, str]]`** 在
`_supply_chain_common.py`：

- `json.loads(text)`（失败 → 返回 `[]`）
- 取 `packages` + `packages-dev` 两数组
- 每条 package 提取 `name` + `version`
- **scope tag**：`"prod"` for `packages`，`"dev"` for `packages-dev`
- 过滤 `source.type ∈ {"path"}`（明确本地引用，OSV 必失配）
- 包名规范化为 lowercase（Packagist case-insensitive）
- 版本：strip leading `v`（Composer 允许 `v1.2.3` 与 `1.2.3` 互通）
- 返回 `[(package_name, version, scope), ...]`

**Path 校验** `ServerAuditConfig.composer_lock_paths`：

- 必须 `/` 或 `~/` 开头
- 无 shell metachar
- **basename 必须 exactly equal `"composer.lock"`**（小写，与 cargo / gem strict 同模式）

### 3.2 版本比较器（PEP 440 wrapper）

Composer 版本规范遵循 SemVer 2.0 + stability flag 扩展。规范引用：
https://getcomposer.org/doc/articles/versions.md

**Composer stability 顺序**（最低 → 最高）：

```
dev < alpha < beta < RC < stable(unsuffixed) < patch
```

**示例**：
```
1.0.0-dev < 1.0.0-alpha < 1.0.0-alpha2 < 1.0.0-beta < 1.0.0-RC1
         < 1.0.0 (stable) < 1.0.0-p1
```

**PEP 440 stability 顺序**（最低 → 最高）：

```
.devN < aN < bN < rcN < final(unsuffixed) < .postN
```

一一对应。**桥接靠 5 条字符串预处理规则**：

```python
import re
from packaging.version import Version, InvalidVersion

_COMPOSER_STABILITY_RE = re.compile(
    r"-(dev|alpha|beta|RC|p)(\d*)\b", re.IGNORECASE
)

_STABILITY_MAP = {
    "dev": ".dev",
    "alpha": "a",
    "beta": "b",
    "rc": "rc",
    "p": ".post",
}

def _normalize_composer_version(s: str) -> str:
    """Composer version → PEP 440 form."""
    if not s:
        return s
    # Strip leading 'v' (e.g., 'v1.2.3' → '1.2.3')
    if s.startswith(("v", "V")):
        s = s[1:]

    def _sub(m: re.Match[str]) -> str:
        flag = m.group(1).lower()
        num = m.group(2) or "0"
        return f"{_STABILITY_MAP[flag]}{num}"

    return _COMPOSER_STABILITY_RE.sub(_sub, s)


def _safe_parse_composer_version(s: str) -> Version | None:
    try:
        return Version(_normalize_composer_version(s))
    except (InvalidVersion, TypeError):
        return None


def _is_composer_version_in_range(version, introduced, fixed):
    v = _safe_parse_composer_version(version)
    if v is None:
        return False
    if introduced is not None:
        intro = _safe_parse_composer_version(introduced)
        if intro is not None and intro > v:
            return False
    if fixed is not None:
        fix = _safe_parse_composer_version(fixed)
        if fix is not None and v >= fix:
            return False
    return True
```

**预处理映射示例**：

| Composer 输入 | PEP 440 输出 |
|---|---|
| `v1.2.3` | `1.2.3` |
| `1.0.0-dev` | `1.0.0.dev0` |
| `1.0.0-alpha` | `1.0.0a0` |
| `1.0.0-alpha2` | `1.0.0a2` |
| `1.0.0-beta` | `1.0.0b0` |
| `1.0.0-RC1` | `1.0.0rc1` |
| `1.0.0-p1` | `1.0.0.post1` |

**已知 limitation**：
- Composer dev-branch 别名（`dev-master` / `dev-feature-x` / `1.x-dev`）
  ——在 lockfile 中以分支名作版本字符串，PEP 440 解析失败 → 静默跳过
  该 (pkg, version)，不报 finding。这是 best-effort 决定：OSV 对开发
  分支不发 advisory，跳过零损失
- 极少数 Composer 版本（含 build metadata 如 `1.0.0+20210101`）
  —— PEP 440 允许 `+local`，可解析通过，按 base version 比较

### 3.3 `OsvPackagistFetcher`

`src/agentsec/audit/ioc_update/fetchers/osv_packagist.py` 镜像
`osv_rubygems.py`：

- URL: `https://osv-vulnerabilities.storage.googleapis.com/Packagist/all.zip`
- Ecosystem 字符串: `"Packagist"`（PascalCase，OSV 规范）
- Fetcher name: `_osv_packagist_full`
- Package name: 单字符串 `vendor/package`（lowercase，OSV 已规范）
- 5-轴 filter 链与 rubygems 完全同：drop withdrawn / no Packagist
  affected / no range / no CVSS_V3 / scored medium-low > 2y
- multi-affected expansion；dedup on (id, package)

### 3.4 `PhpSupplyChainAuditCheck`

`src/agentsec/audit/checks/php_supply_chain_audit.py` 镜像
`gem_supply_chain_audit.py`：

```python
class PhpSupplyChainAuditCheck(Check):
    id = "php_supply_chain_audit"
    description = (
        "Match PHP Composer dependencies (from composer.lock) against "
        "the bundled OSV-Packagist advisory DB."
    )

    def __init__(self):
        super().__init__()
        try:
            self._db = load_advisory_db("osv_packagist.json")
        except FileNotFoundError:
            self._db = []  # DB not built yet (test-time isolation)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if not ctx.composer_lock_paths:
            ctx.status.not_applicable("no composer_lock_paths configured")
            return []

        ctx.policy.add_runtime_allowed_paths(
            ctx.composer_lock_paths, kind="exact"
        )

        db_by_pkg = defaultdict(list)
        for advisory in self._db:
            db_by_pkg[advisory["package"]].append(advisory)

        findings = []
        for path in ctx.composer_lock_paths:
            text = await ctx.read_remote_file(path)
            for pkg, version, scope in parse_composer_lock(text):
                for advisory in _match_composer_advisories(
                    pkg, version, db_by_pkg
                ):
                    findings.append(self.make_finding(
                        ctx, severity=..., title=..., evidence={
                            "package": pkg, "version": version,
                            "scope": scope,  # "prod" or "dev"
                            "advisory_id": advisory["id"],
                            "fixed_in": ..., "lock_path": path,
                        },
                        threat_refs=["TI-OSV-PACKAGIST-CATALOG"],
                    ))
        return findings
```

`scope` 字段在 evidence 中暴露，让 operator 能在 report 中过滤
dev-only 漏洞。Finding fingerprint 包含 scope，所以 prod / dev 同
(pkg, version, advisory) 会作为 2 条独立 finding 出现。**这是
有意为之**——某些 deploy 流程只装 prod 依赖（`composer install
--no-dev`），dev finding 不构成真实威胁，操作员可凭 evidence.scope
快速 triage。

### 3.5 `TI-OSV-PACKAGIST-CATALOG` 伞 entry

```yaml
  - id: TI-OSV-PACKAGIST-CATALOG
    source: osv.dev (Packagist ecosystem)
    claim: "Aggregated CVE catalog for Composer/PHP packages, sourced from OSV."
    confidence: high
    mapped_tests: [php_supply_chain_audit]
    note: |
      Umbrella TI for all Packagist CVE matches surfaced by
      php_supply_chain_audit. Per-CVE advisory id surfaces directly
      in finding evidence (evidence.advisory_id). Refresh via
      `agentsec ioc-update`.
    auto_refresh: false
```

### 3.6 `_run_osv_packagist` in ioc-update CLI

加在 `_run_osv_rubygems` 之后，7-way gather：

```python
results = await asyncio.gather(
    _run_osv_npm(...),
    _run_osv_pypi(...),
    _run_osv_go(...),
    _run_osv_cargo(...),
    _run_osv_maven(...),
    _run_osv_rubygems(...),
    _run_osv_packagist(...),  # NEW
)
```

## 4. 集成 / 不变量

| 切面 | 改动 |
|---|---|
| `php_supply_chain_audit.py` | **新增** |
| `_supply_chain_common.py` | 加 `parse_composer_lock` + version helpers |
| `osv_packagist.py` | **新增** |
| `ioc_update/cli.py` | 加 `_run_osv_packagist` + 7-way gather |
| `osv_packagist.json` | **新增**（live build，预估 1.5-3 MB） |
| `threat_intel.yaml` + cve_database.json | 加 TI entry |
| `scripts/check_osv_packagist.py` | **新增** |
| `config.py` + `base.py` + `server_audit.py` | 加 `composer_lock_paths` |
| `cli.py` | 加 `--composer-lock-path` flag |
| `ssh_policy.yaml` | `cat <composer.lock>` allowed path 扩展 |
| 新测试 | ~30 unit tests |
| ADR-0026 + v0.36.0 docs | 标准 phase 收尾 |

**关键不变量**：

- 7d / 7d.1 / 7d.2 / 7d.3 / 7d.4 / 7d.5 行为零变化
- Adapter / Judge / Scoring / Report renderer 零改动
- MCP coverage gate 不动（floor 14）
- baseline 1791 test pass 不变（+~30 新 = ~1821）
- 总 Check 数：37 → **38 类**

## 5. 错误处理

| 场景 | 处理 |
|---|---|
| `composer_lock_paths` 空 | `not_applicable` |
| composer.lock 不存在 | ctx.read_remote_file 异常路径，转 skipped |
| composer.lock JSON 解析失败 | 空 findings，info log |
| 缺 `packages` / `packages-dev` 字段 | 该数组视作空，继续处理另一数组 |
| 版本字符串 PEP 440 解析失败 | 跳过该 (pkg, version)，log warning |
| Path 校验失败 (非 composer.lock basename) | Pydantic validator raise，CLI 前置 |
| `osv_packagist.json` 缺失 | `__init__` try/except 兜底为空 DB（测试隔离） |
| OSV-Packagist fetch HTTP fail | Fetcher 现有 retry/fail 路径 |

## 6. 测试策略

**单测**（~30 case）：

- `test_parse_composer_lock.py` ~6 case
  - 正常 packages + packages-dev 两数组
  - 只有 packages
  - 只有 packages-dev
  - 缺两数组（empty JSON）
  - 跳过 source.type == "path"
  - 包名 lowercase 规范化
  - 版本 strip leading 'v'
- `test_is_composer_version_in_range.py` ~12 case
  - `1.2.3` 在 `1.0..2.0` 范围内
  - `v1.2.3` strip v
  - `1.0.0-dev` < `1.0.0`
  - `1.0.0-alpha` < `1.0.0-beta`
  - `1.0.0-alpha2` > `1.0.0-alpha`
  - `1.0.0-RC1` < `1.0.0`
  - `1.0.0-p1` > `1.0.0`
  - 边界 introduced 包含 / fixed 排除
  - 无效版本字符串返回 False
  - `dev-master` / `1.x-dev` 分支名返回 False（PEP 440 解析失败）
  - missing introduced / fixed 处理
  - build metadata `1.0.0+20210101` 解析
- `test_php_supply_chain_audit.py` ~6 case（match / no match /
  empty paths / multi-pkg / multi-advisory / scope 区分）
- `test_osv_packagist_fetcher.py` ~3 case（mock httpx + normalize 单元）
- `test_config_composer_lock_paths.py` ~3 case（strict composer.lock
  basename, 拒非 composer.lock 文件名, 拒 shell metachar）

**集成测**：沿 7d.5 约定，无新 integration test。

**CI gates**：
- `pytest tests/` —— ~1821 PASS
- `scripts/check_osv_packagist.py` —— PASS (≤ 15 MB)
- `scripts/check_osv_rubygems.py` / `check_osv_*.py` —— 其他 ecosystem 不动
- `scripts/check_owasp_coverage.py` —— 不动
- `ruff check src/ tests/` —— 干净

**OSV-Packagist 首次 build**：Task 9 跑 `agentsec ioc-update`（live
HTTP）；OSV-Packagist DB 预估 1.5-3 MB（raw 8.9 MB / 5-axis filter 后）。

## 7. 兼容性与迁移

- **现有 6 个 ecosystem**：独立运行，互不影响
- **`ServerAuditConfig`**：新增 `composer_lock_paths` 字段，默认 `[]`；
  现有 config 文件无需改动
- **CLI**：`--composer-lock-path` 是新 optional flag
- **OSV-Packagist DB 大小预估**：参考 raw 8.9 MB（HEAD 实测）+ 5-axis
  filter 经验比例（npm 49→0.9 MB；maven 13→1.6 MB），预估 1.5-3 MB
- **DB ≤ 15 MB cap**：CI guard + 实测双重保险

## 8. 决策摘要

| 决策点 | 选择 | 理由 |
|---|---|---|
| Lockfile | `composer.lock` only (Composer 1.x/2.x 通用) | 事实标准；含 transitive |
| 解析 | `json.loads` + walk `packages` + `packages-dev` | composer.lock 是 JSON |
| Scope | 两数组都扫，evidence 标 `scope: "prod"\|"dev"` | dev 依赖在 CI 运行是真实攻击面（7d.4 maven test 同思路） |
| 版本比较 | `packaging.version` + Composer→PEP 440 5-rule 预处理 | 零新代码（已是 pip 依赖）；99% 真实 Composer 版本可解析 |
| Path 校验 | strict basename == `composer.lock` | cargo / gem 同 strict 模式 |
| Package name | lowercase 规范化 | Packagist case-insensitive |
| OSV ecosystem | `Packagist`（PascalCase） | OSV 规范 |
| Source 多源 | 仅 packagist.org（跳过 path/hg/svn） | 私服罕见，OSV 不覆盖 |
| ADR | 新写 ADR-0026 | 与 7d.5 同步留痕 |
| Bundle 大小预估 | 1.5-3 MB | raw 8.9 MB + 5-axis filter 经验比例 |

## 9. 后续阶段路线

| 阶段 | 范围 | 依赖 |
|---|---|---|
| **7d.6（本期）** | php/composer supply chain（7 语言里程碑） | 7d.5 |
| 7d.7（潜在） | 第 8 ecosystem（.NET/nuget 或 swift/spm 或 dart/pub） | 7d.6 |
| 7d.4.1（潜在） | Gradle（复用 OSV-Maven DB） | 7d.4 |
| 7c.7 | stdio / SSE 真实传输层 | 任何 7c.x 之后 |

## 10. References

- ADR-0012-0015 —— Phase 7d / 7d.1 / 7d.2 / 7d.3
- ADR-0024 —— Phase 7d.4 java/maven
- ADR-0025 —— Phase 7d.5 ruby/gem
- ADR-0026（本 phase 新增）—— Phase 7d.6 php/composer
- OSV Packagist ecosystem dump —— https://osv-vulnerabilities.storage.googleapis.com/Packagist/all.zip
- Composer versions 规范 —— https://getcomposer.org/doc/articles/versions.md
- 既有模板 —— `src/agentsec/audit/checks/gem_supply_chain_audit.py` + `src/agentsec/audit/ioc_update/fetchers/osv_rubygems.py`
- 既有 common 层 —— `src/agentsec/audit/checks/_supply_chain_common.py`
