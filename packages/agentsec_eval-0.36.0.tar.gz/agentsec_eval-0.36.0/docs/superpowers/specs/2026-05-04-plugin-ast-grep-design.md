# Plugin AST Danger-Pattern Scan — Design Spec

**Date:** 2026-05-04
**Status:** Approved
**Scope:** Extend `PluginStaticCheck` with evaluator-side Python AST analysis of skill source files

---

## Background

`plugin_static` (Stage E, v0.2.0) inventories installed OpenClaw skills via
`openclaw skills list --json` and matches each against `clawhavoc_skills.json`.
The original implementation explicitly deferred AST-grep danger-pattern detection
("v0.2.0 ships fingerprint match only — AST-grep for danger patterns is deferred
to vNext"). This spec implements that deferred capability.

---

## Goal

For each Python skill file under `~/.openclaw/skills/`, retrieve the source via
SSH `cat`, parse with Python's built-in `ast` module on the evaluator, and detect
calls to five categories of dangerous APIs. Each `(skill_file, danger_category)`
pair that contains at least one match produces a `high`-severity finding.

IOC fingerprint matching (existing) and AST scanning (new) run independently in
the same `run()` call. Neither blocks the other.

---

## Non-Goals

- Detecting `from subprocess import run; run()` form (aliased imports) — v1 only
  handles dotted `module.attr(...)` and direct `eval()`/`exec()` calls
- Skills written in languages other than Python
- Running `ast-grep` binary on the target or evaluator (Python stdlib `ast` only)
- Adding new `ssh_policy.yaml` commands — existing `find` and `cat` suffice

---

## Skill File Convention

Skills are Python files stored at `~/.openclaw/skills/<skill-name>.py` (Linux) or
`~/Library/Application Support/openclaw/skills/<skill-name>.py` (macOS). These
paths fall under the existing `~/.openclaw/` and
`~/Library/Application Support/openclaw/` allowed-path prefixes in
`ssh_policy.yaml` — no policy change required.

---

## Data Flow

```
Existing:
  SSH → openclaw skills list --json → IOC name/sha match → Finding(critical)

New:
  SSH → find <skills_dir> -type f -name "*.py" → [path, ...]
  for each path:
    SSH → cat <path> → Python source string
    ast.parse(source) + AST walk → dangerous Call nodes
    group by category → Finding(high) per (skill_file, category)

Both flows run in run(); results are concatenated.
```

---

## Platform Profile Changes

Add `skills_dir` key to both profiles:

```python
# LINUX
"skills_dir": "~/.openclaw/skills/"

# MACOS
"skills_dir": "~/Library/Application Support/openclaw/skills/"
```

If `ctx.profile.paths` lacks `skills_dir`, `_ast_scan()` returns `[]` immediately
(skills directory not configured for this platform). IOC matching continues
unaffected. `_REQUIRED_PATHS` is NOT used — it would mark the whole check
`not_applicable`, which must not suppress IOC findings.

---

## Danger Patterns

```python
# Detected via ast.Call nodes
_DANGER_CALLS: dict[str, set[tuple[str, str]]] = {
    "code_execution": {
        ("subprocess", "run"), ("subprocess", "Popen"),
        ("subprocess", "call"), ("subprocess", "check_output"),
        ("os", "system"), ("os", "popen"),
    },
    "dynamic_eval": {
        ("builtins", "eval"), ("builtins", "exec"),
    },
    "network_exfiltration": {
        ("requests", "get"), ("requests", "post"), ("requests", "request"),
        ("urllib.request", "urlopen"),
        ("httpx", "get"), ("httpx", "post"), ("httpx", "request"),
    },
    "raw_socket": {
        ("socket", "connect"), ("socket", "create_connection"),
    },
}

# Detected via bare ast.Attribute nodes (not necessarily wrapped in Call)
_DANGER_ATTRS: dict[str, set[tuple[str, str]]] = {
    "env_access": {
        ("os", "environ"),
    },
}
```

### Detection Rules

| Pattern | AST shape | Handler |
|---------|-----------|---------|
| `subprocess.run(...)` | `Call(func=Attribute(attr=X, value=Name(id=M)))` | `Call` handler: `(M, X)` in `_DANGER_CALLS` |
| `eval(...)` / `exec(...)` | `Call(func=Name(id=X))` | `Call` handler: `("builtins", X)` in `_DANGER_CALLS` |
| `os.environ[...]` / `os.environ.get(...)` | `Attribute(attr="environ", value=Name(id="os"))` | `Attribute` handler: `(M, X)` in `_DANGER_ATTRS` |

**Why two separate dicts:** `ast.walk` visits both a `Call` node and the `Attribute` inside its `func`. Using a single dict for both would double-count `subprocess.run(...)` (once in the Call handler, once in the Attribute handler). Keeping call patterns in `_DANGER_CALLS` (matched only in the `Call` handler) and attribute-access patterns in `_DANGER_ATTRS` (matched only in the bare `Attribute` handler) eliminates double-counting.

`ast.walk` traverses the full module tree. Syntax errors in a skill file cause
that file to be skipped silently (the skill name and path are recorded in
`ctx.status` as a warning note but do not produce a finding).

---

## `_ast_scan()` Implementation Sketch

```python
async def _ast_scan(self, ctx: CheckContext) -> list[Finding]:
    skills_dir = ctx.profile.paths.get("skills_dir")
    if not skills_dir:
        return []

    find_argv = ["find", skills_dir, "-type", "f", "-name", "*.py"]
    res = ctx.executor.run(find_argv)
    if res.rejected or res.exit_code != 0 or not res.stdout.strip():
        return []

    findings: list[Finding] = []
    for skill_path in res.stdout.splitlines():
        skill_path = skill_path.strip()
        if not skill_path:
            continue
        cat_res = ctx.executor.run(["cat", skill_path])
        if cat_res.rejected or cat_res.exit_code != 0:
            continue
        hits = self._scan_source(cat_res.stdout, skill_path)
        for category, matches in hits.items():
            skill_name = skill_path.rsplit("/", 1)[-1]
            findings.append(self.make_finding(
                ctx,
                severity="high",
                title=f"Dangerous API in skill {skill_name}: {category}",
                description=(
                    f"Skill file {skill_path} uses {category} API "
                    f"(first match at line {matches[0][1]})."
                ),
                evidence={
                    "skill_path": skill_path,
                    "category": category,
                    "matched_calls": [f"{m[0]}:{m[1]}" for m in matches],
                },
                remediation=(
                    f"Review {skill_path} for {category} usage. "
                    "Remove or justify each occurrence before deployment."
                ),
                threat_refs=["TI-CLAWHAVOC-OVERVIEW"],
            ))
    return findings

def _scan_source(
    self, source: str, skill_path: str
) -> dict[str, list[tuple[str, int]]]:
    """Return {category: [(call_repr, lineno), ...]} for danger matches."""
    import ast as _ast

    try:
        tree = _ast.parse(source)
    except SyntaxError:
        return {}

    hits: dict[str, list[tuple[str, int]]] = {}
    for node in _ast.walk(tree):
        # Call-based patterns: module.attr(...) and eval()/exec()
        if isinstance(node, _ast.Call):
            func = node.func
            if isinstance(func, _ast.Attribute) and isinstance(func.value, _ast.Name):
                key = (func.value.id, func.attr)
                for cat, patterns in _DANGER_CALLS.items():
                    if key in patterns:
                        hits.setdefault(cat, []).append(
                            (f"{func.value.id}.{func.attr}",
                             getattr(node, "lineno", 0))
                        )
            elif isinstance(func, _ast.Name):
                key = ("builtins", func.id)
                for cat, patterns in _DANGER_CALLS.items():
                    if key in patterns:
                        hits.setdefault(cat, []).append(
                            (func.id, getattr(node, "lineno", 0))
                        )
        # Attribute-access patterns: os.environ (separate dict, no double-count)
        elif isinstance(node, _ast.Attribute) and isinstance(node.value, _ast.Name):
            key = (node.value.id, node.attr)
            for cat, patterns in _DANGER_ATTRS.items():
                if key in patterns:
                    hits.setdefault(cat, []).append(
                        (f"{node.value.id}.{node.attr}",
                         getattr(node, "lineno", 0))
                    )
    return hits
```

---

## Finding Specification

### Existing IOC finding (unchanged)

```python
Finding(check="plugin_static", severity="critical", ...)
```

### New AST finding

```python
Finding(
    check="plugin_static",
    severity="high",
    title=f"Dangerous API in skill {skill_name}: {category}",
    description=(
        f"Skill file {skill_path} uses {category} API "
        f"(first match at line {first_lineno})."
    ),
    evidence={
        "skill_path": skill_path,         # full remote path
        "category": category,             # e.g. "code_execution"
        "matched_calls": [                # "call_repr:lineno"
            "subprocess.run:12",
            "subprocess.Popen:47",
        ],
    },
    remediation=(
        f"Review {skill_path} for {category} usage. "
        "Remove or justify each occurrence before deployment."
    ),
    threat_refs=["TI-CLAWHAVOC-OVERVIEW"],
)
```

One finding per `(skill_file, category)` — multiple calls of the same category
in one file are collapsed into one finding with all line numbers in `matched_calls`.

---

## Test Plan

All tests added to `tests/audit/checks/test_plugin_static.py`.

| Test | Setup | Expected |
|------|-------|----------|
| `test_ast_scan_detects_subprocess` | Executor returns `subprocess.run(["ls"])` source for cat | 1× `high` finding, `category="code_execution"`, `"subprocess.run"` in `matched_calls` |
| `test_ast_scan_clean_skill_no_finding` | Executor returns clean source (`def greet(): return "hi"`) | No AST findings |
| `test_ast_scan_skips_unparseable_file` | Executor returns `"def bad syntax ::::"` source | No finding, no exception raised |
| `test_ast_scan_skips_when_no_skills_dir` | `profile.paths` has no `skills_dir` key | No AST findings; IOC matching still runs |

Helper: minimal executor mock that responds to `find` and `cat` argv patterns.

---

## Files Changed

| File | Change |
|------|--------|
| `src/agentsec/audit/platform_profile.py` | Add `skills_dir` to `LINUX` and `MACOS` |
| `src/agentsec/audit/checks/plugin_static.py` | Add `_DANGER_PATTERNS`, `_scan_source()`, `_ast_scan()`; call from `run()` |
| `tests/audit/checks/test_plugin_static.py` | Add 4 new test cases + find/cat executor helper |

No new files. No `ssh_policy.yaml` changes. No new Python dependencies.

---

## Constraints

- `_ast_scan()` uses `ctx.executor.run()` (SSH-gated, policy-validated) for both
  `find` and `cat`. No direct filesystem access from the evaluator.
- Evidence strings flow through `make_finding()` → `ctx.redactor.redact()`.
- `_scan_source()` is a pure function (no I/O); it can be unit-tested without
  a mock executor.
- The `os.environ` pattern uses bare attribute detection (not Call) because
  `os.environ["KEY"]` is `Subscript`, not `Call`. Walking `Attribute` nodes
  catches both `os.environ["KEY"]` and `os.environ.get("KEY")`.
