# 7d.cleanup — 累积 follow-ups 清单

**日期**：2026-05-12
**作者**：roger
**状态**：草案，待 triage
**范围**：从 7c (MCP Top 10) / 7d.1 (pip) / 7d.2 (go) / 7d.3 (rust) / 7e.3 (firewalld)
五个 phase 沉淀下来的 follow-ups 汇总，统一在一次 cleanup commit / 短 phase 中处理。

不在范围：
- 7d.x `plugin_static` 规则扩展（独立 phase）
- 任何新功能 / 新 Check
- 行为变更（评分公式 / Severity 矩阵 / Finding 模式）

## 来源映射

| 来源 | 文档 / commit | 折入清单的条目数 |
|---|---|---|
| 7d.2 final review | `docs/superpowers/specs/2026-05-11-phase-7d3-rust-supply-chain-design.md` §11（8 项 — 3 Important + 5 Minor） | 8 |
| 7c MCP final review | memory `project_openclaw_v020_progress.md`（前版第 64–88 行；本版 §"累积 follow-ups"） | 4 |
| 7e.3 firewalld final review | memory（本版）+ subagent reviewer minor 提示 | 6 |
| 本次重新验证发现 | 现 main 实验性 grep | 已逐条与原文档对账（all confirmed） |

总计 **18 项**（4 Important + 14 Minor）。

---

## 一、Important（4 项）—— 影响一致性 / 可调试性 / 未来扩展

### I1. supply-chain Check `evidence` 路径 key 不一致
- **现状**：
  - `supply_chain_audit.py:182,216` 用 `"npm_root"` 作 evidence key
  - `pip_supply_chain_audit.py` / `go_supply_chain_audit.py` / `rust_supply_chain_audit.py` 都用 `"lock_path"` 作 evidence key
- **影响**：跨生态 finding 对账（`agentsec diff` / 自动化 dedupe）必须分支处理；docs/samples 比对脚本无法用统一 schema 校验
- **目标**：4 个 Check 全部统一为 `"lock_path"` 字段（npm Check 也改成 lock_path = `<npm_root>/package-lock.json`）
- **测试影响**：每个 Check 1-2 个测试断言要换 key；4 Check 共约 5-8 行测试修
- **风险**：报告 schema 变化；需在 CHANGELOG 标 breaking（虽然 evidence 是诊断字段，但若外部消费 findings.json 会受影响）
- **估时**：1-1.5 小时

### I2. `_extract_severity_label` 在 4 Check 中各有副本
- **现状**：4 文件均定义 `def _extract_severity_label(adv: dict) -> Severity`（行号：supply_chain:119 / pip:82 / go:117 / rust:116），代码体几乎完全一致
- **影响**：未来调严重性映射（如 CVSS V4 上线）需 4 处改；漏改即静默漂移
- **目标**：抽到 `src/agentsec/audit/checks/_supply_chain_common.py`，4 Check 改 import
- **测试影响**：现有测试不受影响（函数名 + 签名不变，仅调用方变成 import）
- **风险**：低（纯重构，行为不变）
- **估时**：0.5-1 小时

### I3. `cli.py` 中 `from .config import ServerAuditConfig` 3 处重复
- **现状**：`src/agentsec/cli.py:524`、`:537`、`:551` 都在函数体内 `from .config import ServerAuditConfig`
- **影响**：每个函数都重导一次；提示这 3 处可能曾经依赖延迟导入（模块循环？）需要核实；若仅是历史遗留，应提到模块顶部
- **目标**：核实是否有模块循环，确认无后提到顶部 imports；或者把 3 处合并成 1 处
- **测试影响**：无（导入位置变更，行为不变）
- **风险**：低；先跑 `python -c "from agentsec.cli import *"` 与全套 pytest 确认无循环
- **估时**：30 分钟

### I4. MCP cases 全是 `judge_type: llm`，零 `deterministic` 用例
- **现状**：5 个 `mcp_*.yaml` 文件 80 cases 全部 `judge_type: llm`
- **影响**：LLM judge 在 MCP 语境下若漂移，缺少 deterministic 兜底；其他套件（LLM Top 10 / Agentic）都至少有部分 deterministic 用例
- **目标**：从 80 case 中挑出 8-12 个最容易 deterministic 化的（如 mcp-rsm 系列：明确的 URI 模式 / arg exfil）改 `judge_type: hybrid` 并补 assertion
- **测试影响**：assertion 模块单测 + 抽样跑这些 case 验证一致性
- **风险**：判定一致性 — 同一 case 在 LLM-only 与 hybrid 下结果可能不同；需基线对账
- **估时**：3-4 小时（**这条不在 cleanup commit 范围**，建议拆出做独立短 phase 7c.0.5 或合入下次 7c.1）

> **建议**：I4 不归入 cleanup commit。它是评估面变更，需要独立审视和基线对账。本清单保留它作为"已识别但显式推后"。

---

## 二、Minor（14 项）—— 局部代码质量 / 测试覆盖 / 注释完善

### M1. `osv_npm.py` 有 `__all__` 块，其他 3 个 OSV fetcher 没有
- **现状**：`osv_npm.py:38` 是唯一显式 `__all__` 的 fetcher 模块
- **目标**：要么 4 个都加，要么删 osv_npm 那个
- **估时**：5 分钟

### M2. `_safe_parse_*` 短输入 / 防御性边界缺测
- **现状**：3 个 fetcher 各有 `_safe_parse_*_version`，对空字符串 / 只有 `v` / `vv1.2.3` / 极长输入等输入未直接测
- **目标**：每个 fetcher 各加 3-5 个边界 case 单测
- **估时**：30 分钟

### M3. tautology 测试断言
- **现状**：7d.2 final review 指出某些测试断言只验证了"被测函数刚才返回的值等于其自身返回值"这种 vacuous 模式；具体位置已在 7d.3 spec §11 标注但未列文件:行号
- **目标**：本次 cleanup 前先 grep 找出实际位置（搜 `assert .*\.return_value` / 重复字面量），逐一改为有意义的断言或删除
- **估时**：30-45 分钟

### M4. 15 MB CI cap 偏松
- **现状**：4 个 OSV DB 各自 `scripts/check_osv_*.py` 都设 `_MAX_BYTES = 15 * 1024 * 1024`；当前实际大小：npm 0.9 MB / pypi 0.9 MB / go 0.9 MB / cargo 0.5 MB
- **目标**：每个 DB cap 单独收紧至当前大小 1.5 倍（如 npm 3 MB / cargo 1 MB）；避免下个版本意外膨胀但仍允许 50% 增长
- **估时**：15 分钟

### M5. 0-package 诊断信号缺失
- **现状**：supply-chain Check 在 lockfile 解析后若得到 0 packages，silently 走 `not_applicable`；操作员看不出是"lockfile 为空"还是"解析失败"
- **目标**：parser 返 (packages, n_lines_skipped)；Check 在 0-package 时 set_ok 并在 evidence 记 n_lines_skipped
- **估时**：1-1.5 小时（4 Check 都改 + 测试）

### M6. `_FIREWALLD_BIN_CANDIDATES` 仅 2 个候选缺解释注释
- **现状**：iptables/nft/ufw 候选都 3 个（usr/sbin/sbin/usr/bin），firewalld 只 2 个（usr/bin/bin），没有代码注释解释（spec §3.4 有详释）
- **目标**：在元组上加一行注释：`# firewalld 无 sbin 变体（RHEL/CentOS 均装 /usr/bin/firewall-cmd）`
- **估时**：2 分钟

### M7. FirewalldAuditCheck.run() 119 行 vs plan 80 行
- **现状**：3 命令 × 4 错误路径自然膨胀；可抽 `_skip_reason(result, label)` helper 收缩 ~15 行
- **目标**：抽公共 skip-reason 助手；run() 收缩到 100 行以内
- **风险**：低（纯重构）；现有 11 entry 测试是行为锚点
- **估时**：30-45 分钟

### M8. `test_empty_list_all_skipped` 缺 `skip_reason` 子串断言
- **现状**：仅断言 `is_skipped is True`，未验证 reason 含"输出为空"；其他 3 个 skipped 测试都有 reason 断言
- **目标**：加 `assert "输出为空" in (ctx.status.skip_reason or "")`
- **估时**：5 分钟

### M9. FirewalldAuditCheck 三个错误路径缺直接测试
- **现状**：以下分支与已测的 state perm-denied / list-all rejected 平行结构相同，但未直接断言：
  - `dz.exit_code != 0` + perm-denied
  - `dz.exit_code != 0` + 非 perm-denied
  - `la.exit_code != 0` + perm-denied
  - `la.exit_code != 0` + 非 perm-denied
- **目标**：加 4 个 minimal tests
- **风险**：可能在 cleanup 中暴露代码 bug（如 reason 字符串拼错），所以是有价值的覆盖
- **估时**：30-45 分钟

### M10. `_expand_tilde` 与 `PathMatcher._expanduser` 重复
- **现状**：7d.2 spec §13 已标记
- **目标**：选一个保留，另一个改 import 重用
- **估时**：15 分钟

### M11. `_client_factory` 类型注解 + PyPI fetcher SEMVER 类型清理
- **现状**：7d.2 spec §13 标记的类型清理
- **估时**：30 分钟

### M12. 5 个 `mcp_*.yaml` 的 `judge_hint` "Pass if" / "Fail if" 句式不一致
- **现状**：80 case 的 judge_hint 大部分用 "Pass if … Fail if …" 但少数顺序颠倒或措辞略变
- **目标**：统一为 "Pass: <branch>\nFail: <branch>" 双行式（兼容现有 substring 检查）
- **风险**：判定行为可能轻微变化；先抽样 5 个 case 跑 LLM judge 对账再批量改
- **估时**：1-1.5 小时

### M13. ADR-0016 缺 `Spec:` 引用栏
- **现状**：ADR-0014 / 0015 都有底部 `Spec:` 行链回 spec 文档；ADR-0016 / 0017 没有
- **目标**：ADR-0016 / 0017 补上 `Spec:` 行
- **估时**：5 分钟

### M14. README "11 Linux hardening" 描述未折叠 firewalld 计数
- **现状**：README 文字描述里"11 Linux hardening + 4 防火墙 + ..."；可读但 11 与 4 是否包含交集需要看上下文才知道
- **目标**：要么明确"11 Linux hardening（不含防火墙）+ 4 防火墙独立"；要么改为"15 Linux hardening 含防火墙"统一口径
- **估时**：10 分钟

---

## 三、估时总览

| 类别 | 项数 | 估时合计 |
|---|---|---|
| Important（含拆出 I4） | 3 + 1 推迟 | ≈ 3 小时（不含 I4） |
| Minor | 14 | ≈ 6-7 小时 |
| **合计**（本次 cleanup） | 17 项 | **≈ 1 天**（含测试 + commit 拆分） |
| 推迟 | I4 | — |

---

## 四、commit 拆分建议

不一定一个大 commit。建议按"领域 + 风险"拆 5 个 commit，便于回滚：

1. **`refactor(7d.cleanup): unify supply-chain Check evidence keys`** — I1 单 commit（schema 变更，独立可见）
2. **`refactor(7d.cleanup): extract _extract_severity_label to common`** — I2 + M1 + M10 + M11（纯共享代码归位）
3. **`cleanup(7d.cleanup): consolidate cli.py imports`** — I3 单 commit
4. **`test(7d.cleanup): tighten supply-chain + firewalld test coverage`** — M2 + M3 + M5 + M8 + M9（测试加固）
5. **`chore(7d.cleanup): tighten CI caps + minor comments + docs`** — M4 + M6 + M7 + M12 + M13 + M14

---

## 五、不在本范围 / 明确推后

- **I4 MCP deterministic 用例补充** — 评估面变更，需独立 phase 处理
- **7c.1 mcp_supplements.yaml**（145 case 扩展）— 独立 phase
- **7c.2 真实 McpAdapter** — 架构投资，独立 phase
- **7d.x plugin_static 规则扩展** — 独立 phase
- **7e.4 macOS pfctl / 7e.5 firewall 深化 / 7f.1 podman / 7g k8s** — 独立 phase
- **判定行为 / 评分公式 / Severity 阈值** — 无变更
- **PyPI 重发** — cleanup 不发版；攒到下个 feature phase 一起 bump

---

## 六、执行入口

下次会话直接：

```
进入 7d.cleanup phase，按清单顺序处理 I1 → I2/M1/M10/M11 →
I3 → 测试加固 → chore 杂项。每组完成跑一遍 pytest + ruff，
然后单 commit。完成后开总 review。
```

预计**单次会话**完成（≈ 5-6 小时含 review）。建议不发 v0.18.0，等下次 feature phase（7f.1 或 7e.5）合并发版。
