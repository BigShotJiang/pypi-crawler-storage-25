# Phase 7f.1 — Podman + Containerd 容器审计设计

**日期**：2026-05-12
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0018；前置 ADR（7f Docker 落地未单独写 ADR，相关决策见 7f spec）。

## 1. 目标

`agentsec server-audit` Phase 7f 在 v0.10.0 落了 Docker 三件套（`docker_daemon_audit` / `docker_runtime_audit` / `docker_image_cve`），覆盖 Ubuntu / Debian / RHEL 上装了 Docker 的主机。但：

- **podman** 是 RHEL / CentOS Stream / Fedora 默认容器运行时，daemonless 架构，与 docker 不同源
- **containerd** 是 Kubernetes 与 Docker 共用的底层运行时；在原生 containerd 主机（不装 docker，K8s 节点）上没有覆盖

7f.1 在不重构 7f 现有代码的前提下，新增 5 个 Check：3 个 podman + 2 个 containerd，闭合 RHEL/Fedora + K8s 节点的覆盖盲点。

## 2. 范围

**新增 5 个 Check**：

| Check id | 主命令 | Finding 粒度 |
|---|---|---|
| `podman_daemon_audit` | `cat /etc/containers/containers.conf` + `podman version/info` | 4 daemon 规则各一条 finding |
| `podman_runtime_audit` | `podman ps` + `podman inspect <id>` | 复用 7f runtime 7 条规则；多 cap 命中 emit 多 finding |
| `podman_image_cve` | `podman images` | 复用 7f image_patterns 7 条 fnmatch 规则 |
| `containerd_runtime_audit` | `nerdctl ps/inspect`（优先）或 `ctr containers list/info`（回退） | 复用 7f runtime 规则（ctr 模式仅 4/7 覆盖） |
| `containerd_image_cve` | `nerdctl images` 或 `ctr images list` | 复用 7f image_patterns |

**首期审计点**（podman + containerd 各自适配后，整体能力覆盖）：

- **podman daemon**：rootful 模式 / userns / no_new_privileges / 版本 CVE
- **podman runtime + image**：完全复用 7f 现有 7 + 7 条规则
- **containerd runtime + image**：复用 7f 规则；ctr 模式部分覆盖（partial coverage info finding）
- **cross-talk yield**：docker 接管 containerd 时，containerd Check 让位

**out of scope**（明确推后或不做）：

- `containerd_daemon_audit`（读 `/etc/containerd/config.toml`）— 7f.1.1 或社区反馈后；config.toml 安全 knob 少
- CRI / `crictl` —— 7g (Kubernetes phase)
- podman 镜像 layer 扫描 / SBOM
- `podman pod`（K8s-like pod 组）
- nerdctl 非默认 namespace（如 `k8s.io`）—— 7g
- containerd shim / OCI spec 直接读取 `/run/containerd/io.containerd.runtime.v2.task/<ns>/<id>/config.json`
- podman 多用户切换扫描
- containerd plugin / proxy plugin 配置
- macOS podman（podman desktop 是开发场景，非审计目标）

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  _docker_common.py             # 修：+ _PODMAN_BIN_CANDIDATES / _NERDCTL_BIN_CANDIDATES / _CTR_BIN_CANDIDATES
                                #     + detect_podman / detect_nerdctl / detect_ctr / detect_containerd_runtime
                                #     + 共享 helper（Option α dict-return）：
                                #       _evaluate_inspect / _evaluate_image_tag / _parse_ctr_info
                                #     现有 detect_docker / is_path_under 不动
  container_baseline.yaml       # 修：+ daemon_podman: 段（4 条规则）；runtime/image_patterns 不动
  podman_daemon_audit.py        # 新
  podman_runtime_audit.py       # 新
  podman_image_cve.py           # 新
  containerd_runtime_audit.py   # 新（nerdctl 优先 / ctr 回退）
  containerd_image_cve.py       # 新（同上分派）

src/agentsec/audit/ssh_policy.yaml
  allowed_paths                 # +10 条 exact（7 bin + 2 containers.conf + 1 containerd.sock）
  commands.podman               # 新 4 个 allowed_argv tuple + args_schema
  commands.nerdctl              # 新 2 个 allowed_argv tuple + args_schema
  commands.ctr                  # 新 2 个 allowed_argv tuple + args_schema (chain)

src/agentsec/audit/ioc/threat_intel.yaml
  # +19 条 TI 行：
  #   4 podman daemon (TI-PODMAN-DAEMON-*)
  # + 7 podman runtime (TI-PODMAN-RUNTIME-*, 镜像 7f docker_runtime 7 条规则)
  # + 7 containerd runtime (TI-CONTAINERD-RUNTIME-*)
  # + 1 partial coverage (TI-CONTAINERD-COVERAGE-PARTIAL)
  # = 19。image_patterns 的 TI 不拆 —— 详 §4.2 决策

src/agentsec/cli.py
  # +5 import + 2 registration site 各 +5 行

tests/
  test_podman_daemon_audit.py
  test_podman_runtime_audit.py
  test_podman_image_cve.py
  test_containerd_runtime_audit.py
  test_containerd_image_cve.py
  test_docker_common.py         # 修：+ 探测与 helper 测试
  fixtures/container/           # 新目录，21 个 fixture

docs/adr/0018-phase-7f1-podman-containerd-audit.md          # 实施完毕后写
docs/superpowers/specs/2026-05-12-phase-7f1-podman-containerd-design.md  # 本 spec
```

**新增**：5 Check + 5 test + 1 ADR + 1 spec + 21 fixture = 33 文件。**修改**：5 文件（`_docker_common.py` / `container_baseline.yaml` / `ssh_policy.yaml` / `threat_intel.yaml` / `cli.py` / 4 既有文档）。

### 3.2 平台 gating

5 个新 Check 都 `ctx.profile.name in ("linux", "linux_user_mode")`，非 Linux → `not_applicable`。

### 3.3 `_REQUIRED_PATHS`

新 Check 全设为 `()`（OS 级，不走 OpenClaw 路径门），与 7f Docker 一致。

### 3.4 探测优先级

`_docker_common.py` 扩展：

```python
_PODMAN_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/podman",
    "/usr/local/bin/podman",
    "/opt/homebrew/bin/podman",
)

_NERDCTL_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/local/bin/nerdctl",
    "/usr/bin/nerdctl",
)

_CTR_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/ctr",
    "/usr/local/bin/ctr",
)

def detect_podman(ctx: CheckContext) -> str | None: ...
def detect_nerdctl(ctx: CheckContext) -> str | None: ...
def detect_ctr(ctx: CheckContext) -> str | None: ...

def detect_containerd_runtime(
    ctx: CheckContext,
) -> tuple[str | None, str | None]:
    """Returns (frontend_bin_path, mode).
       mode ∈ {"nerdctl", "ctr", None}.
       同时检查 /run/containerd/containerd.sock 存在，避免装了 nerdctl
       但 containerd 未起的开发机误报。"""
```

### 3.5 跨 runtime cross-talk

**Docker 接管 containerd 时让位**（核心）：

```python
ContainerdRuntimeAuditCheck.run():
    if detect_docker(ctx) is not None and _docker_socket_active(ctx):
        ctx.status.not_applicable(
            f"{self.id}：检出 docker 后端为 containerd，由 docker_runtime_audit 评估"
        )
        return []
    ...
```

`_docker_socket_active(ctx)` 直接 `stat /var/run/docker.sock`；exit 0 即视为 docker 在管。

`ContainerdImageCveCheck` 同此让位。

**podman vs docker**：不需要 yield —— podman daemonless，docker 有 daemon，互不接管。同主机装了 docker + podman → 两个 Check 都跑，覆盖各自管理的容器，合理。

### 3.6 共享 helper（Option α dict-return）

为避免 5 个新 Check 重复实现 `runtime:` + `image_patterns:` 的判定逻辑，抽 3 个**纯函数** helper 到 `_docker_common.py`：

```python
def _evaluate_inspect(
    inspect_json: dict,
    *,
    runtime: str,                    # "docker" | "podman" | "containerd"
    rootless: bool = False,
    baseline_runtime_rules: list[dict],
) -> list[dict]:
    """Apply 7 runtime rules to docker-compat inspect JSON.
    Returns list of Finding kwargs (dict). Caller wraps with make_finding.

    `evidence.runtime` and `threat_refs` populated per `runtime` arg.
    rule `runtime-root-user` severity downgraded (medium→low) if rootless=True.
    """

def _evaluate_image_tag(
    repo: str,
    tag: str,
    *,
    runtime: str,
    baseline_image_patterns: list[dict],
) -> list[dict]:
    """fnmatch each pattern vs <repo>:<tag>. Returns list of Finding kwargs."""

def _parse_ctr_info(text: str) -> dict:
    """`ctr containers info <id>` yaml-ish text → structured dict.
    Returns {privileged: bool, host_network: bool, capabilities: list[str],
              root_user_uid: int}. Malformed → raise (caller catches)."""
```

**抽出策略**：
- 7f Docker 的 3 个 Check **不动**（保留 `Finding(...)` 直构造路径；7f 落地早于 make_finding 在 7d.2 普及；让 7f 在未来 7f.x.cleanup 一起迁）
- 新 5 个 Check 全部 `self.make_finding(ctx, **kwargs)` —— Redactor pass 自动应用（Option α）
- Helper 不传 ctx（纯函数）；Check 接 helper 返回的 dict 后套 `make_finding`：
  ```python
  findings.extend(
      self.make_finding(ctx, **kwargs)
      for kwargs in _evaluate_inspect(inspect_json, runtime="podman", ...)
  )
  ```

### 3.7 baseline 文件

`container_baseline.yaml` 复用现有 `runtime:` + `image_patterns:` 段；新增 `daemon_podman:` 段（4 条规则）。containerd 不新增 daemon 段（方案 A）。

## 4. 组件细节

### 4.1 `PodmanDaemonAuditCheck`

**命令序列**：
```
cat /etc/containers/containers.conf
cat /usr/share/containers/containers.conf       # 仅 /etc/ 不存在时回退
podman version --format '{{json .}}'
podman info --format '{{json .}}'
```

**判定**（`baseline_daemon_podman` 4 条）：

| Rule ID | 触发 | Severity |
|---|---|---|
| `podman-rootful-mode` | `info.host.security.rootless == false` | high |
| `podman-userns-default-host` | `containers.conf[containers].userns ∈ {"host", missing}` | medium |
| `podman-no-new-priv-off` | `containers.conf[containers].no_new_privileges != true` | medium |
| `podman-version-cve` | `version.Client.Version ∈ known_bad_versions`（占位 "<4.9.0"） | high |

**Finding evidence**：`{ runtime: "podman", rule_id, version, ... }`。

`containers.conf` 缺失 → 默认 dict `{}`；按 podman 默认值跑判定。

`run()` 主体 ≤ 100 行；TOML 解析用 `tomllib`（3.11+ stdlib）。

### 4.2 `PodmanRuntimeAuditCheck`

**命令**：
```
podman info --format '{{json .}}'         # 取 host.security.rootless
podman ps --format '{{json .}}' --no-trunc
podman inspect <id>                       # 每个 active 容器
```

**判定**：复用 `container_baseline.yaml:runtime` 现有 7 条规则，调 `_evaluate_inspect(inspect_json, runtime="podman", rootless=rootless, baseline_runtime_rules=self._rules)`。

**rootless 旁路**：`info.host.security.rootless = true` 时，rule `runtime-root-user` severity 从 medium 降至 low。原因：rootless namespace 内 root ≠ 宿主 root。

**单容器失败不污染**：某个 `podman inspect <id>` 失败 → 该容器进 `skipped_container_ids`，其余继续；末尾 emit 一条 info finding 列出。

### 4.3 `PodmanImageCveCheck`

**命令**：`podman images --format '{{json .}}'`

**判定**：每个 image 的 `Repository:Tag` 调 `_evaluate_image_tag(repo, tag, runtime="podman", baseline_image_patterns=self._patterns)`，fnmatch 命中 7 条 image_patterns 任一即 emit。

### 4.4 `ContainerdRuntimeAuditCheck`

**Cross-talk yield**：
```python
if detect_docker(ctx) is not None and _docker_socket_active(ctx):
    ctx.status.not_applicable("由 docker_runtime_audit 评估")
    return []
```

**Mode 探测**：`detect_containerd_runtime(ctx) → (bin, mode)`。
- `mode == "nerdctl"`：走 docker-CLI-兼容路径
- `mode == "ctr"`：走 yaml-ish 文本解析路径
- `(None, None)`：`not_applicable("containerd 不可见")`

#### Mode A：nerdctl

**命令**：
```
nerdctl ps --format '{{json .}}' --no-trunc
nerdctl inspect <id>
```

仅扫默认 namespace（`nerdctl ps` 不带 `--namespace`）。K8s namespace `k8s.io` 推后到 7g。

解析 inspect JSON 复用 `_evaluate_inspect(json, runtime="containerd", rootless=False, ...)`。

#### Mode B：ctr fallback

**命令**：
```
ctr --namespace default containers list -q       # ID 列表
ctr --namespace default containers info <id>     # yaml-ish 多行文本
```

调 `_parse_ctr_info(text)` → 部分 dict（仅 4 字段）。

**判定**：4 条规则跑（privileged / host-net / cap-dangerous / root-user），其余 3 条（host-fs-mount / sock-mount / no-new-priv）需要 OCI runtime spec，本 phase 不读 `/run/containerd/io.containerd.runtime.v2.task/`，因此跳过。

每条 finding evidence 加 `coverage: "partial"`, `mode: "ctr"`。此外 emit **一条 info finding**：

```python
self.make_finding(
    ctx, severity="info",
    title="containerd_runtime_audit：ctr 模式部分覆盖",
    description=(
        "未检出 nerdctl，回退到 ctr containers info 解析。"
        "host-fs-mount / sock-mount / no-new-privileges 三条规则在该模式下不可达，"
        "已跳过；其余 4 条（privileged / host-net / cap-dangerous / root-user）正常评估。"
    ),
    evidence={"mode": "ctr", "uncovered_rules": [...]},
    remediation="安装 nerdctl 提升保真度：dnf install nerdctl",
    threat_refs=["TI-CONTAINERD-COVERAGE-PARTIAL"],
)
```

### 4.5 `ContainerdImageCveCheck`

同 §4.4 docker 接管让位 + mode 探测。

- Mode A：`nerdctl images --format '{{json .}}'` → 每 image `_evaluate_image_tag(...)`
- Mode B：`ctr images list -q` → 字符串列表（如 `docker.io/library/python:2.7`），按 `:` rsplit 拆分 repo/tag 后 `_evaluate_image_tag(...)`

image refs 在两个模式下都是完整的，**无 partial coverage** 问题。

## 5. 数据流（汇总图）

```
所有 Check：
  ├─ profile gating → not_applicable / continue
  ├─ runtime-specific detect → not_applicable / continue
  ├─ Cross-talk yield（仅 containerd Check）→ not_applicable / continue
  ├─ 命令编排（每 Check 不同；见 §4）
  ├─ JSON / TOML / yaml-ish 解析
  ├─ helper 应用基线规则 → list[Finding kwargs]
  └─ Check 套 `self.make_finding(ctx, **kw)` 后 extend findings
     ctx.status by base 类自动 set_ok（单容器 inspect 失败不改全局 status）
```

Snapshot 接触面：**不写** `ctx.snapshot.collect(...)`，与 7f 一致。

## 6. 错误处理

详见 spec §6 大表（5 Check × ~10 失败位置 = 50 个分支）。

### 6.1 关键不变量

- Check 内不捕获通用 `Exception` —— 传输层异常归 orchestrator
- `ctx.status` 单次设置（多次调用以最后一次为准）
- 每个 Check `run()` 主体目标 ≤ 100 行
- 单容器 `inspect` 失败不污染其余（per-container `skipped_container_ids` + 末尾 info finding）
- finding 通过 `self.make_finding(ctx, **kwargs)` —— Redactor pass 自动应用

### 6.2 单容器失败处理模式

```python
findings: list[Finding] = []
skipped_ids: list[str] = []
for cid in container_ids:
    result = ctx.executor.run(["podman", "inspect", cid])
    if result.rejected or result.exit_code != 0:
        skipped_ids.append(cid)
        continue
    try:
        inspect_json = json.loads(result.stdout)
    except json.JSONDecodeError:
        skipped_ids.append(cid)
        continue
    findings.extend(
        self.make_finding(ctx, **kw)
        for kw in _evaluate_inspect(inspect_json, runtime="podman",
                                     rootless=rootless,
                                     baseline_runtime_rules=self._rules)
    )

if skipped_ids:
    findings.append(self.make_finding(
        ctx, severity="info",
        title=f"{self.id}：{len(skipped_ids)} 个容器的 inspect 失败",
        description="部分容器扫描失败；finding 列表仅含成功扫描部分。",
        evidence={"skipped_container_ids": skipped_ids[:20]},
        remediation="检查 podman daemon 状态或运行用户权限。",
        threat_refs=[],
    ))
```

`evidence.skipped_container_ids` 上限 20，超过截断 + 加 `truncated: true`。

### 6.3 `ctx.status` 决策矩阵

| 情况 | ctx.status |
|---|---|
| 全部命令成功 + 0 finding | `set_ok` |
| 全部命令成功 + N finding | `set_ok`（finding 已 emit） |
| 部分容器 inspect 失败 + 部分成功 | `set_ok` + skipped info finding |
| 全部容器 inspect 失败 | `set_ok`（仍 emit info finding 列出全部 skipped） |
| `ps` / `images` 全失败 | `skipped` |
| `detect_<runtime>` 失败 | `not_applicable` |
| profile gating | `not_applicable` |
| docker 接管 containerd | `not_applicable` |

## 7. 测试

### 7.1 Fixture 清单（21 个，详见 spec §7.1）

`tests/fixtures/container/`（新目录）：
- 3 个 `podman_containers_conf_*.toml`
- 4 个 `podman_info_*.json` / `podman_version_*.json`
- 2 个 `podman_ps_*.txt`
- 4 个 `podman_inspect_*.json`
- 1 个 `podman_images_*.json`
- 1 个 `containerd_nerdctl_ps.txt`
- 1 个 `containerd_nerdctl_inspect_*.json`
- 1 个 `containerd_nerdctl_images.json`
- 1 个 `containerd_ctr_containers_list_q.txt`
- 2 个 `containerd_ctr_info_*.txt`
- 1 个 `containerd_ctr_images_list_q.txt`

### 7.2 单测增量（71 个新测试）

- `test_podman_daemon_audit.py`：10
- `test_podman_runtime_audit.py`：9
- `test_podman_image_cve.py`：5
- `test_containerd_runtime_audit.py`：10
- `test_containerd_image_cve.py`：6
- `test_docker_common.py`：+16（探测 + helper）
- `tests/audit/test_command_policy.py`：+15（podman/nerdctl/ctr/cat 新 path）
- `tests/audit/test_cli_server_audit.py` + `tests/integration/test_openclaw_mock.py`：补 stub + sample 报告刷新

预期 `pytest tests/ -q`：1413 → **≈ 1484 passing**。

### 7.3 集成测试

`tests/integration/test_openclaw_mock.py` 中所有新 binary path（7 条）补 absence stub（`exit_code=1`）→ 新 Check 走 `not_applicable`，不影响 sample drift guard。

`docs/samples/report-2026-04-28/server-audit-report.md` 刷新：+5 行 `not_applicable` 表格行 + check 计数 29 → 34。

## 8. SSH policy 扩展

详见 spec §8.1。

### 8.1 `allowed_paths`（+10 条）

- 3 podman bin + 2 nerdctl bin + 2 ctr bin = 7 bin 候选
- 2 containers.conf 配置路径
- 1 containerd.sock 探测路径

### 8.2 `commands`（+3 段）

`podman:` / `nerdctl:` / `ctr:` 各自 `allowed_argv` + `args_schema`（复用 7f docker 的 `container_id` schema 类型）。

写操作（run / pull / push / build / start / stop / kill / exec / rm / save / commit）全部**不在任何 allowed_argv tuple 中**，按 7f Docker 同款"unreachable by construction"。

`ctr` 命令需 `--namespace default` 在前；本 phase 不接受其他 namespace（K8s 留 7g）。

### 8.3 不修改的命令面

- `cat`：仅 allowed_paths +2 条 containers.conf
- `find` / `grep` / `stat`：不动
- `write_operations`：不开启

## 9. 范围外（推后） + 发布

### 9.1 Out-of-scope（明确推后）

详见 spec §8.2，9 项推后或不做。

### 9.2 版本发布

- **目标**：v0.18.0
- **CHANGELOG.md**：新增段 "Phase 7f.1 — Podman + Containerd audit"
- **ROADMAP.md**：7f.1 → shipped；containerd_daemon 列为 7f.1.1 跟踪
- **README.md**：29 → 34 类
- **CLAUDE.md**：Total checks 更新 + 新段 `## Podman + Containerd audit (Phase 7f.1, v0.18.0)`
- **memory**：`project_openclaw_v020_progress.md` 更新到 v0.18.0
- **不推 tag**（保持 v0.17.0 约定）

### 9.3 ADR

新写 `docs/adr/0018-phase-7f1-podman-containerd-audit.md`，骨架照 ADR-0017。

### 9.4 PyPI 流程

复用 v0.17.0 流程（push origin → build → twine upload）。

## 10. 决策摘要

| 决策 | 选择 | 来源 |
|---|---|---|
| Runtime scope | podman + containerd 双上 | 用户答 §1 |
| containerd CLI | nerdctl 优先 / ctr 回退 | 用户答 §1 |
| Phase 拆分 | 单 7f.1 phase 多 commit | 用户答 §1 |
| 架构方案 | A：5 Checks，跳 containerd_daemon | 用户答 §2 |
| Cross-talk yield | docker 接管 containerd → containerd Check 让位 | spec §3.5 |
| baseline 段 | 复用 runtime: + image_patterns:；新增 daemon_podman: 4 条 | spec §4.1 |
| TI 命名 | daemon + runtime 拆三套（TI-DOCKER-* / TI-PODMAN-* / TI-CONTAINERD-*）；image_patterns 复用现有 TI-DOCKER-IMAGE-*（image 内容与 runtime 无关） | 用户答 §4.2，spec §3.1 备注 |
| Helper return | Option α：list[dict]，Check 套 make_finding | 用户答 §5 |
| Rootless 处理 | runtime-root-user 严重性降一档 | spec §4.2 |
| ctr 部分覆盖 | emit info finding `TI-CONTAINERD-COVERAGE-PARTIAL` | spec §6 |
| sentinel | 不引入（与 7e.3 firewalld 一致）；纯 if/else | 隐含 |
| 7f Docker 不动 | 5 个新 Check 走 make_finding；7f 保留 Finding(...) 留作 7f.x.cleanup | spec §3.6 |
