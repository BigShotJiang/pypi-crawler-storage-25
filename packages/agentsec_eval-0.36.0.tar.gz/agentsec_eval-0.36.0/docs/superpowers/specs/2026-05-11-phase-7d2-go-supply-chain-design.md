# Phase 7d.2 — go / OSV-Go 供应链审计 Check + `_supply_chain_common.py` 抽取

**日期**：2026-05-11
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0014；前置 ADR-0012（7d-npm）+ ADR-0013（7d.1-pip）。

## 1. 目标

`agentsec server-audit` 在 v0.13.0 已有 26 类 Check（npm + pip 各一条供应链 Check）。Phase 7d.2 把同样能力扩到 **Go 生态**：按 operator 在 `openclaw-target.yaml` 中配置的 `go.sum` 路径列表，匹配 OSV-Go advisory 子集，emit 已知漏洞 finding。

同时本 phase 触发 **rule of three** — 当第三个 ecosystem 落地，把 npm / pip / go 三方 fetcher 与 Check 中的公共部分抽到 `_supply_chain_common.py`（fetcher 侧 + check 侧分立两个模块，依赖方向单向不跨层）。

ROADMAP `Phase 7d.2+` 原文："Skills / Plugins 深化的剩余面（go / rust 生态 + plugin_static 静态扫描扩展）"。本 phase 仅覆盖 go；rust 留给 7d.3，扫描扩展留给 7d.x。

## 2. 范围

新增：1 个 Check + 1 个 OSV fetcher + 1 个 bundled DB + 1 条 TI umbrella + 2 个 common 模块 + `ServerAuditConfig.go_lock_paths` + `CheckContext.go_lock_paths` 通道。

修改：3 个现有 Check 走 `make_finding` 收口（7d.1 final-review #5 follow-up）；2 个现有 fetcher 改 import 走 common 模块。

| 组件 | id / 路径 | 职责 |
|---|---|---|
| `GoSupplyChainAuditCheck` | `go_supply_chain_audit` | 读 operator 配置中列出的 `go.sum` 路径，按 (module, version) 匹配 OSV-Go DB |
| OSV-Go fetcher | `src/agentsec/audit/ioc_update/fetchers/osv_go.py` | `agentsec ioc-update` 子流程：拉 `https://osv-vulnerabilities.storage.googleapis.com/Go/all.zip`，过滤、归一化、写 `osv_go.json` |
| Bundled DB | `src/agentsec/audit/ioc/osv_go.json` | 提交到 git，wheel 打包随发；CI `--check` 验证 + 15 MB 上限 |
| TI umbrella | `TI-OSV-GO-CATALOG`（在 `threat_intel.yaml`） | go_supply_chain finding 的 `threat_refs` 引用 |
| Fetcher 共用 | `src/agentsec/audit/ioc_update/fetchers/_supply_chain_common.py` | 抽 `severity_from_cvss_score` / `_parse_cvss_score` / `_is_within_age` / `_extract_severity` / `MEDIUM_LOW_MAX_AGE_DAYS` / `Severity` |
| Check 共用 | `src/agentsec/audit/checks/_supply_chain_common.py` | 抽 `load_advisory_db(path) -> dict[str, list[dict]]`；re-export `severity_from_cvss_score` / `Severity` |
| Config schema | `ServerAuditConfig.go_lock_paths: list[str] = []` | operator 在 `openclaw-target.yaml` 列要审的 go.sum |
| Context 通道 | `CheckContext.go_lock_paths: tuple[str, ...] = ()` | server-audit orchestrator 把 config 传给 Check |

**首期范围**：

- **生态**：仅 Go。rust / plugin_static 等留给后续 phase。
- **lockfile 格式**：仅 `go.sum`（basename 严格等于 `go.sum`）。备份 / 历史变体（`go.sum.bak`）需 operator 重命名后启用。
- **路径来源**：operator config（与 7d.1 同款 — OpenClaw 无稳定 Go footprint）。
- **后缀白名单**：basename == `"go.sum"`（精确匹配，不走前缀 / 多后缀）。
- **顺手清理**：3 个 supply-chain Check（npm / pip / 新加 go）的 `Finding(...)` 直接构造改走 `Check.make_finding(ctx, ...)` 自动 Redactor pass。

**out of scope**：

- 不读 `go.mod`（仅含 direct deps + min versions，缺 transitive 锁定）
- 不读 `vendor/modules.txt`（老式 vendoring 格式，现代 go 项目已不走）
- 不分析 `go version -m <bin>` BuildInfo（需在被审主机执行 go CLI，扩大攻击面）
- 不在线查询 osv.dev API（架构选 offline，与 7d / 7d.1 同）
- macOS profile（仅 `linux` / `linux_user_mode`，与前两 phase 同）

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  go_supply_chain_audit.py              # 新 — Check 主体
  _supply_chain_common.py               # 新 — Check 侧 common
  supply_chain_audit.py                 # 现有，import common，删本地 severity_from_cvss_score
  pip_supply_chain_audit.py             # 现有，import common，删本地 severity_from_cvss_score
src/agentsec/audit/ioc/
  osv_go.json                           # 新 — bundled DB
  threat_intel.yaml                     # 现有，追加 TI-OSV-GO-CATALOG
src/agentsec/audit/ioc_update/fetchers/
  osv_go.py                             # 新 — OSV-Go 抓取 + 归一化
  _supply_chain_common.py               # 新 — Fetcher 侧 common
  osv_npm.py                            # 现有，删 5 函数 + 1 常量 + Severity 类型，改 import common
  osv_pypi.py                           # 现有，同上
src/agentsec/audit/ioc_update/
  cli.py                                # 现有，加 _run_osv_go 进 asyncio.gather
src/agentsec/audit/
  ssh_policy.yaml                       # 现有，加 7d.2 注释段（无新静态条目）
src/agentsec/
  config.py                             # 现有，加 ServerAuditConfig.go_lock_paths
  cli.py                                # 现有，注册 GoSupplyChainAuditCheck（两处） + wire go_lock_paths
scripts/
  check_osv_go.py                       # 新 — CI 一致性 + 体积 ≤ 15 MB 守门
.github/workflows/ci.yml                # 现有，加 check_osv_go.py 步骤
tests/audit/checks/
  test_go_supply_chain_audit.py         # 新
  test_supply_chain_common.py           # 新
  test_supply_chain_redaction.py        # 新 — 3 Check 的 redactor-routing
tests/audit/ioc_update/fetchers/
  test_osv_go.py                        # 新
  test_supply_chain_common.py           # 新
tests/test_ioc_update_osv_go_wiring.py  # 新
tests/scripts/
  test_check_osv_go.py                  # 新
tests/fixtures/supply_chain_go/
  go.sum-clean
  go.sum-vulnerable
  go.sum-edge-cases                     # /go.mod 行 / 伪版本 / +incompatible
  osv_go_subset.json
tests/fixtures/osv/go/
  # 6 个 OSV-Go 真实 advisory JSON 截取
docs/adr/0014-phase-7d2-go-supply-chain.md
docs/superpowers/specs/2026-05-11-phase-7d2-go-supply-chain-design.md
```

新增文件量级：6（源码 + DB） + 8（test + fixture） + 1（CI 脚本） + 2（ADR/spec） = 17。零新 PyPI 依赖（`semver>=3,<4` 已在 deps）。

### 3.2 平台 gating

`GoSupplyChainAuditCheck` 在 `run()` 顶部判断 `ctx.profile.name in ("linux", "linux_user_mode")`，非 Linux profile 标 `not_applicable` 直接返。macOS profile 暂不支持。

### 3.3 不依赖 `_REQUIRED_PATHS`

Same as 7d.1 — 路径完全来自 operator config，不走 PlatformProfile 通道。`run()` 顶部判 `if not ctx.go_lock_paths: → not_applicable("未配置")`。

### 3.4 Check 类轮廓

```python
from ._supply_chain_common import load_advisory_db, severity_from_cvss_score


_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_go.json"


class GoSupplyChainAuditCheck(Check):
    id = "go_supply_chain_audit"

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        self._advisories_by_pkg = load_advisory_db(db_path or _OSV_DB_PATH)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(f"{self.id}：非 Linux profile")
            return []
        if not ctx.go_lock_paths:
            ctx.status.not_applicable(f"{self.id}：未配置 go_lock_paths")
            return []

        findings: list[Finding] = []
        n_skipped = 0
        for lock_path in ctx.go_lock_paths:
            result = ctx.executor.run(["cat", lock_path])
            if result.rejected:
                n_skipped += 1
                continue
            if result.exit_code != 0:
                n_skipped += 1
                continue
            if not result.stdout.strip():
                n_skipped += 1
                continue
            findings.extend(self._scan_lockfile(ctx, lock_path, result.stdout))
        if not findings and n_skipped == len(ctx.go_lock_paths):
            ctx.status.skipped(
                f"{self.id}：所有 go_lock_paths 均不可读 (n={n_skipped})"
            )
        return findings

    def _scan_lockfile(self, ctx, lock_path: str, stdout: str) -> list[Finding]:
        modules = parse_go_sum(stdout)
        findings: list[Finding] = []
        for module, version in modules:
            if _safe_parse_go_version(version) is None:
                findings.append(self._unparseable_finding(ctx, module, version, lock_path))
                continue
            for adv in self._advisories_by_pkg.get(module, []):
                if version_in_any_go_range(version, adv["ranges"]):
                    findings.append(
                        self._advisory_finding(ctx, module, version, adv, lock_path)
                    )
        return findings

    def _advisory_finding(self, ctx, module, version, adv, lock_path):
        # use self.make_finding(ctx, ...) NOT Finding(...)
        ...

    def _unparseable_finding(self, ctx, module, version, lock_path):
        # use self.make_finding(ctx, ...) NOT Finding(...)
        ...
```

注意：`_advisory_finding` / `_unparseable_finding` 都接 `ctx` 参数，因为 `make_finding(ctx, ...)` 需要 ctx 以拿 redactor。

## 4. 数据模型

### 4.1 OSV-Go 归一化 schema（与 OSV-npm/PyPI 同形）

```json
{
  "id": "GHSA-xxxx-yyyy-zzzz",
  "package": "github.com/foo/bar",
  "ranges": [{"introduced": "0", "fixed": "v1.2.3"}],
  "severity": "critical|high|medium|low",
  "summary": "短摘要 ≤ 200 字符",
  "url": "https://github.com/advisories/GHSA-xxxx-yyyy-zzzz",
  "aliases": ["CVE-2023-xxxxx"]
}
```

差异点：
- `package` 字段是 module path（含 `/`），无归一化（OSV 也用同形态）
- `ranges` 用 Go 版本字符串（带 `v` 前缀，可能含 `+incompatible` 与伪版本）
- 同一 OSV entry 多个 Go module → 展开多条记录（dedup `(id, package)`）

### 4.2 Finding 形态

```python
self.make_finding(
    ctx,
    severity=<from_advisory>,
    title=f"go {module}@{version} 命中 {advisory_id}（severity={sev}）",
    description=adv["summary"][:200],
    evidence={
        "package": module,
        "version": version,
        "advisory_id": advisory_id,
        "aliases": [...],
        "fixed_in": "v1.2.3 或 (no fixed version)",
        "url": "https://github.com/advisories/...",
        "lock_path": lock_path,
    },
    remediation=f"go get {module}@{fixed_in}",
    threat_refs=["TI-OSV-GO-CATALOG"],
)
```

无法解析 Go 版本（罕见）：

```python
self.make_finding(
    ctx,
    severity="low",
    title=f"无法解析 Go 版本: {module}@{version}",
    description="非标准 Go module 版本（应为 vX.Y.Z 或 v0.0.0-timestamp-hash 形式）",
    evidence={"package": module, "version": version, "lock_path": lock_path},
    remediation="升级到合法 vX.Y.Z 版本",
    threat_refs=["TI-OSV-GO-CATALOG"],
)
```

## 5. CommandPolicy 动态注入

与 7d.1 同款 — `go_lock_paths` 不固化在 `ssh_policy.yaml`，operator config 即 consent。

1. `ServerAuditConfig.go_lock_paths` Pydantic validator：
   - 每条字符串以 `/` 或 `~/` 起头
   - `metachar_guard.contains_shell_metachar([path])` 必须返 None
   - basename 必须等于 `"go.sum"`（`path.rsplit("/", 1)[-1] == "go.sum"`）
2. `materialize_paths` 把 `~/` 展开
3. `server_audit.py` / cli.py 调用 `policy.add_runtime_allowed_paths(paths, kind="exact")` 注入
4. `_log_runtime_paths_added(audit_log, paths, "ServerAuditConfig.go_lock_paths")` 记录

## 6. go.sum parser

### 6.1 输入 / 输出

```python
def parse_go_sum(stdout: str) -> list[tuple[str, str]]:
    """Return [(module_path, version)] from go.sum content.

    /go.mod-suffixed lines are skipped (duplicate the main entries with
    different hash flavor; emitting both would double-finding).
    Versions strip leading 'v' and trailing '+incompatible' for downstream
    semver-based comparison.
    """
```

### 6.2 行类别

| 行形态 | 行为 |
|---|---|
| `github.com/foo/bar v1.2.3 h1:abc==` | 收 `("github.com/foo/bar", "v1.2.3")` |
| `github.com/foo/bar v1.2.3/go.mod h1:def==` | silently skip（重复信息） |
| `pkg v1.2.3+incompatible h1:abc==` | 收 `("pkg", "v1.2.3+incompatible")` |
| `pkg v0.0.0-20210101120000-abcdef h1:abc==` | 收 `("pkg", "v0.0.0-20210101120000-abcdef")` |
| 空行 / `#` 注释（go.sum 实际上没有注释，但容错） | silently skip |
| 字段数 ≠ 3 | silently skip |

### 6.3 Module path 归一化

**不做归一化** — Go module 路径是大小写敏感的 URL 形态，OSV-Go 用同形式，直接字面匹配。

### 6.4 Version 形态保留

Parser **保留 raw 版本字符串**（含 `v` 前缀、`+incompatible` 后缀、伪版本完整形态）。Cleanup 由 `_safe_parse_go_version` 在比较时执行 — 与 7d-npm / 7d.1-pip 同模式（parser 不变形，cleanup 推到 matcher）。

**优点**：
- Finding 的 `evidence["version"]` 显示 `v1.2.3+incompatible`，是 Go 用户熟悉的形态
- Title `"go github.com/foo/bar@v1.2.3 命中 ..."` 读起来自然
- 与现有两 ecosystem 模式一致（parser 只做 lockfile-format 拆解，不做 version-semantic 转换）

`_safe_parse_go_version` 详见 §7。

## 7. Range matcher

```python
def version_in_any_go_range(version: str, ranges: list[dict]) -> bool:
    v = _safe_parse_go_version(version)
    if v is None:
        return False
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last = r.get("last_affected")

        if intro != "0":
            intro_v = _safe_parse_go_version(intro)
            if intro_v is not None and v.compare(intro_v) < 0:
                continue
        if fixed is not None:
            fixed_v = _safe_parse_go_version(fixed)
            if fixed_v is not None and v.compare(fixed_v) >= 0:
                continue
        if last is not None:
            last_v = _safe_parse_go_version(last)
            if last_v is not None and v.compare(last_v) > 0:
                continue
        return True
    return False
```

`_safe_parse_go_version(s) -> semver.Version | None`：
- 剥前导 `v`：`v1.2.3` → `1.2.3`
- 剥尾 `+incompatible`：`v1.2.3+incompatible` → `1.2.3`
- 伪版本 `v0.0.0-20210101120000-abcdef` 剥 v 后 `0.0.0-20210101120000-abcdef` 是合法 semver pre-release
- 不剥 build metadata `+...`（非 incompatible 的 `+` 应保留）
- 然后 `semver.Version.parse(...)`，失败返 `None`

**Pseudo-version 比较**：`semver` 把伪版本字符串 `0.0.0-20210101000000-aaa` 当 pre-release 处理，时间戳字典序天然单调 — 符合 Go 语义。

## 8. OSV-Go fetcher

### 8.1 `OsvGoFetcher`

镜像 `OsvNpmFetcher` / `OsvPyPIFetcher`，调用抽到的 common 函数：
- name = `"osv_go"`
- URL：`https://osv-vulnerabilities.storage.googleapis.com/Go/all.zip`
- 重试退避 `[2, 4, 8]`s
- FetchResult key `_osv_go_full`

### 8.2 `normalize_osv_go_entry` — 5-轴 filter chain

| 轴 | 规则 |
|---|---|
| 1. withdrawn | drop |
| 2. ecosystem | `affected[].package.ecosystem == "Go"` 收；否则 drop |
| 3. semver/ecosystem range | 用 common 中的 `_extract_ranges_for(types=("ECOSYSTEM",))` 提取（Go 不用 SEMVER） |
| 4. CVSS_V3 | 缺则 drop |
| 5. age | severity ∈ {medium, low} + `published > 2 年` → drop |

**多 affected 包**：遍历所有 Go affected 项，每个生成一条 normalized record。

### 8.3 输出体积估计

OSV-Go 全量较小（Go 生态较年轻）。预估 ~500-1500 entries / ~200-500 KB。CI cap 仍 15 MB（不在本 phase 调）。

## 9. ioc-update CLI 接入

`src/agentsec/audit/ioc_update/cli.py` 加 `_run_osv_go(ctx, cache_dir)`，与 `_run_osv_npm` / `_run_osv_pypi` 三方 `asyncio.gather`：

```python
osv_npm_path, osv_pypi_path, osv_go_path = await asyncio.gather(
    _run_osv_npm(fctx, out_dir),
    _run_osv_pypi(fctx, out_dir),
    _run_osv_go(fctx, out_dir),
)
# ... 三段 log_event
```

任一 degraded 不阻塞另两方。

## 10. `_supply_chain_common.py` 抽取

### 10.1 Fetcher 侧（`src/agentsec/audit/ioc_update/fetchers/_supply_chain_common.py`）

```python
"""Shared OSV bundle filter / severity helpers used by all 3 ecosystem fetchers."""

from __future__ import annotations

from typing import Literal

Severity = Literal["critical", "high", "medium", "low"]

MEDIUM_LOW_MAX_AGE_DAYS = 2 * 365


def severity_from_cvss_score(score: float | None) -> Severity:
    """CVSS v3 base-score → AgentSec severity label.
    None → 'medium' (conservative; not 'low' so unscored entries aren't underreported)."""
    if score is None:
        return "medium"
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    return "low"


def _parse_cvss_score(vector: str) -> float | None: ...
def _is_within_age(modified_iso: str, max_age_days: int, now=None) -> bool: ...
def _extract_severity(severity_list: list[dict]) -> tuple[str, bool]: ...
```

### 10.2 Check 侧（`src/agentsec/audit/checks/_supply_chain_common.py`）

```python
"""Shared advisory-DB load helper used by all 3 ecosystem Checks."""

from __future__ import annotations

import json
from pathlib import Path

# Re-export so Check files don't need to reach into fetchers/
from ..ioc_update.fetchers._supply_chain_common import (
    Severity,
    severity_from_cvss_score,
)

__all__ = ["Severity", "severity_from_cvss_score", "load_advisory_db"]


def load_advisory_db(path: Path) -> dict[str, list[dict]]:
    """Load OSV bundle JSON and index by package name."""
    raw = json.loads(path.read_text())
    by_pkg: dict[str, list[dict]] = {}
    for adv in raw:
        by_pkg.setdefault(adv["package"], []).append(adv)
    return by_pkg
```

### 10.3 Refactor 范围

- `osv_npm.py`：删本地 `Severity` / `MEDIUM_LOW_MAX_AGE_DAYS` / `severity_from_cvss_score` / `_parse_cvss_score` / `_is_within_age` / `_extract_severity` → 改 `from ._supply_chain_common import ...`
- `osv_pypi.py`：同上（注意 `severity_from_cvss_score` 此前从 `pip_supply_chain_audit.py` import — 改为从 `_supply_chain_common` import）
- `supply_chain_audit.py` (npm Check)：删本地 `severity_from_cvss_score` / `_extract_severity_label` / DB 索引手写 → 改 `from ._supply_chain_common import load_advisory_db, severity_from_cvss_score`
- `pip_supply_chain_audit.py`：同上

### 10.4 Refactor 顺序

1. 先创建两个 `_supply_chain_common.py`（暂时不被人用）
2. 改 `osv_npm.py` import → 跑 fetcher 测试 → 绿
3. 改 `osv_pypi.py` import → 跑 fetcher 测试 → 绿
4. 改 `supply_chain_audit.py` import → 跑 npm Check 测试 → 绿
5. 改 `pip_supply_chain_audit.py` import → 跑 pip Check 测试 → 绿
6. 现在创建 `osv_go.py` + `go_supply_chain_audit.py` 直接 import common
7. 全套回归

每步独立 commit，便于回滚。

## 11. make_finding 收口（7d.1 final-review #5 follow-up）

3 个 supply-chain Check（`SupplyChainAuditCheck` / `PipSupplyChainAuditCheck` / 新加 `GoSupplyChainAuditCheck`）的 `Finding(...)` 直接构造改走 `self.make_finding(ctx, ...)` 自动 Redactor pass。

**接口提醒**：`Check.make_finding(ctx, *, severity, title, description, evidence, remediation, threat_refs)` — kwargs only。

**Check 类签名变化**：
- `_advisory_finding(self, pkg, version, adv, lock_path)` → `_advisory_finding(self, ctx, pkg, version, adv, lock_path)`
- `_unparseable_finding` 同
- `_scan_lockfile(self, lock_path, stdout)` → `_scan_lockfile(self, ctx, lock_path, stdout)`
- `run()` 把 ctx 透传

**测试影响**：
- 现有 e2e 测试用 `_NoOpRedactor` stub redactor — 改造后行为不变
- 新增 `tests/audit/checks/test_supply_chain_redaction.py`：3 Check × 用真 `Redactor` + finding evidence 含模拟 secret pattern → 验证 secret 被替换。共 3 测试

**独立 commit 顺序**（在 common 抽取之后）：
- commit 1: npm Check make_finding
- commit 2: pip Check make_finding
- commit 3: go Check make_finding（已 from-scratch 写）
- commit 4: redaction 测试

## 12. 测试矩阵

### 12.1 Parser tests（`test_go_supply_chain_audit.py`）

```
test_parse_simple_line              # 收 ("github.com/foo/bar", "v1.2.3")
test_parse_skip_go_mod_suffix       # /go.mod 行 silently skip
test_parse_keep_v_prefix            # parser 保留 v 前缀（不剥）
test_parse_keep_incompatible_suffix # parser 保留 +incompatible 后缀
test_parse_pseudo_version           # 收 ("pkg", "v0.0.0-20210101120000-abc")
test_parse_module_path_with_slash   # github.com/foo/bar 完整路径保留
test_parse_blank_lines_skipped
test_parse_invalid_field_count_skipped
test_parse_multiple_versions_same_module
test_parse_local_build_metadata     # +cuda 等 non-incompatible build meta
```

### 12.2 Matcher tests（同上文件）

```
test_match_exact_inside_range
test_match_at_introduced_boundary
test_match_at_fixed_boundary_excluded
test_match_just_below_fixed
test_match_pseudo_version_in_range
test_match_unparseable_returns_false
test_match_multiple_ranges_or
test_match_incompatible_stripped_at_compare  # v1.2.3+incompatible 比较时去掉 +incompatible
```

### 12.3 Check end-to-end（同上文件，mock SSHExecutor）

```
test_check_empty_config_not_applicable
test_check_single_lockfile_one_hit
test_check_multi_lockfile_mixed
test_check_all_paths_unreadable_skipped
test_check_unparseable_version_low_finding
test_check_non_linux_not_applicable
```

### 12.4 OSV-Go fetcher tests（`test_osv_go.py`）

Normalize 7（5 axes + multi-affected + cross-ecosystem 过滤） + HTTP 2 = 9。

### 12.5 Common 模块 tests

- `tests/audit/ioc_update/fetchers/test_supply_chain_common.py`：4-5（CVSS / age / severity 提取）
- `tests/audit/checks/test_supply_chain_common.py`：2-3（`load_advisory_db`）

### 12.6 Redaction tests（`test_supply_chain_redaction.py`）

3 个 Check × 1 测试 = 3。

### 12.7 CI script + ioc-update wiring

- `tests/scripts/test_check_osv_go.py`：3
- `tests/test_ioc_update_osv_go_wiring.py`：2

**总计**：parser 10 + matcher 8 + Check e2e 6 + fetcher 9 + common-fetcher 5 + common-check 3 + redaction 3 + CI script 3 + wiring 2 = **49 新测试**。

预期 1235 → ~1284 passing。

### 12.8 Sample 报告刷新

`docs/samples/report-2026-04-28/`：跑 mock 集成测试，预期只增 1 行 `go_supply_chain_audit: not_applicable (未配置 go_lock_paths)` + 26 → 27 类计数。

## 13. CI / Release

### 13.1 CI guard

`scripts/check_osv_go.py --check`：JSON 合法 + ≤ 15 MB。在 `.github/workflows/ci.yml` 的 `ioc-sync` 与 `test-macos` jobs 中加 step。

### 13.2 Release 链路（与 v0.13.0 一致）

1. 实现完整 + 测试全绿后跑 `agentsec ioc-update`
2. `cp .cache/ioc-update-<date>/proposed-osv_go.json src/agentsec/audit/ioc/osv_go.json`
3. 独立 `data(7d.2):` commit
4. ROADMAP / CHANGELOG / README / CLAUDE.md / pyproject 0.13.0 → 0.14.0 独立 docs commit
5. ADR-0014 独立 commit
6. push main + tag `v0.14.0` + push tag
7. `twine upload dist/agentsec_eval-0.14.0*` 手动发 PyPI

## 14. 决策清单（→ ADR-0014）

| ID | 决策 | 备选 | 选择理由 |
|---|---|---|---|
| D1 | 路径来自 operator config，不进 PlatformProfile | profile 加 `go_root` / 扫主机 | 与 7d.1 一致；OpenClaw 无 Go footprint |
| D2 | 仅 go.sum；basename 严格匹配 | 多种 / 后缀通配 | go.sum 有完整 transitive；唯一文件名最安全 |
| D3 | `_supply_chain_common.py` 拆 fetcher 侧 + check 侧两个模块 | 单文件 / 不抽 check 侧 | 依赖方向清晰不跨层；Check 不应直接 import fetcher 内部 |
| D4 | Go 版本 = 剥 v 前缀 + 剥 +incompatible + semver 库 | 不剥 / 用专门 go-version 库 | 现有 semver 已能处理；伪版本作 pre-release 自然单调 |
| D5 | matcher 各 ecosystem 独立，不抽通用 `version_in_any_range_with(parse_fn)` | 抽泛型 | 三方算法同但版本类型差异大；泛型反而模糊 |
| D6 | exact-kind dynamic injection（与 7d.1 同） | prefix / 静态 ssh_policy | 最小权限；零 install 文件改动 |
| D7 | 3 个 Check 走 `make_finding` 收 Redactor pass | 维持现状 | 7d.1 final review Important；本 phase 顺手清 |
| D8 | OSV-Go 5-轴 filter chain 与 npm/pypi 同 | 重新调阈值 | 已验证有效；common 抽完后 logic 单点维护 |
| D9 | TI 单 umbrella `TI-OSV-GO-CATALOG` | 每 advisory 一条 TI | 同 npm/pypi；避免 TI 文件爆炸 |

## 15. Out of scope（明确记下）

- `go.mod` 单独读取（缺 transitive 锁定）
- `vendor/modules.txt`（老式 vendoring）
- `go version -m` BuildInfo 提取
- 在线 osv.dev 查询
- macOS / Windows 平台
- rust / crates.io（留给 7d.3）
- `plugin_static` 静态扫描扩展（留给 7d.x）
- 调整 CI 15 MB cap（独立 follow-up）
- `_expand_tilde` 与 `PathMatcher._expanduser` 合并（独立 follow-up）
- `_client_factory` 类型注解 + PyPI fetcher SEMVER 类型清理（独立 follow-up）
