# Phase 7e.3 — firewalld 主机防火墙 Check 设计

**日期**：2026-05-12
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0017；前置 ADR-0011（7e.2）。

## 1. 目标

`agentsec server-audit` 在 Phase 7e.2 落地了 Linux 三大主流防火墙
后端中的 iptables / nftables / ufw，覆盖 Ubuntu / Debian / Alpine /
原生 RHEL。但 RHEL / CentOS Stream / Fedora 的**默认**防火墙是
firewalld（依赖 D-Bus + zone 模型），7e.2 spec §2 明确把 firewalld
推后到本 phase。

7e.3 一波补齐 firewalld 的「服务激活 + 默认 zone target + 各 active
zone target」三件套，与 ufw_audit 的范围对齐。本 spec 描述新增
1 个 Check + helper 扩展 + 2 个既有 Check 的串扰退让 修改的设计。

## 2. 范围

新增 1 个 Check（沿用现有 `Check` ABC 模式）：

| Check 类 | id | 主命令序列 | Finding 粒度 |
|---|---|---|---|
| `FirewalldAuditCheck` | `firewalld_audit` | `firewall-cmd --state` + `--get-default-zone` + `--list-all-zones` | service 未启用 1 critical；否则每个 ACCEPT-target zone 1 条（默认 critical / 其他 high） |

**首期审计点**（与 7e.2 范围对齐）：

- **A. 服务激活状态**：firewalld 已安装但未启用 → 1 条 critical。
- **B. 默认 zone target**：默认 zone 的 target == `ACCEPT` → 1 条 critical。
- **C. 各 active zone target**：除默认 zone 外，被绑定接口或 sources
  的 zone 若 target == `ACCEPT` → 1 条 high。

**target 判定**（基于用户答案）：

- 仅 `ACCEPT` 报。`default` / `DROP` / `REJECT` / `%%REJECT%%` 都视作"安全"
  （`default` 在 firewalld 语义中等价于 INPUT_ZONES 的 `REJECT`）。

**out of scope**（明确推后到 7e.5 或不做）：

- Rich rules 危险动作扫描（accept + source=0.0.0.0/0）。
- 危险服务 / 端口扫描（telnet / rpcbind / 0.0.0.0 全开）。
- Runtime / Permanent 漂移检测（每条命令翻倍）。
- firewalld direct interface（`--direct --get-all-rules`）。
- `--get-log-denied` 配置基线。
- polkit 自定义规则提示（需要主机操作员显式收紧才会触发；不针对单写文案）。
- macOS pfctl（独立 phase 7e.4）。

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  _firewall_common.py        # 修：+ _FIREWALLD_BIN_CANDIDATES
                             #     + detect_firewalld(ctx)
                             #     + output_managed_by_firewalld(stdout, *, backend)
  iptables_audit.py          # 修：+ _FIREWALLD_TAKEOVER sentinel
                             #     调 output_managed_by_firewalld 双退让
  nftables_audit.py          # 修：同上
  firewalld_audit.py         # 新

src/agentsec/audit/ssh_policy.yaml
  allowed_paths              # +2 条 exact: /usr/bin/firewall-cmd, /bin/firewall-cmd
  commands.firewall-cmd      # 新 section, 3 条 allowed_argv tuple

src/agentsec/audit/ioc/threat_intel.yaml
  # 复用 TI-LINUX-CIS-FIREWALL，无需新增

src/agentsec/cli.py
  # +1 行：在 server_audit / _evaluate_server 注册 FirewalldAuditCheck

tests/
  test_firewalld_audit.py    # 新（11 用例）
  test_firewall_common.py    # 修（+6 用例）
  test_iptables_audit.py     # 修（+1 用例）
  test_nftables_audit.py     # 修（+1 用例）
  test_ssh_policy.py         # 修（+4 用例）
  fixtures/firewall/         # +9 个 fixture

docs/adr/0017-phase-7e3-firewalld-audit.md           # 新（实施完成后写）
docs/superpowers/specs/2026-05-12-phase-7e3-firewalld-design.md  # 本 spec
```

新增：1 Check + 1 ADR + 1 spec + 1 test = 4 文件。修改：6 文件。fixture：+9 个。

### 3.2 平台 gating

`FirewalldAuditCheck` 在 `run()` 顶部判断
`ctx.profile.name in ("linux", "linux_user_mode")`，非 Linux 标
`not_applicable` 直接返。

每次 `run()` 还会做一次 backend 探测（§3.4），未装即 `not_applicable`。

### 3.3 `_REQUIRED_PATHS`

设为 `()`（OS 级，不走 OpenClaw 路径门），与 7e/7e.1/7e.2 一致。

### 3.4 Backend 探测 + 串扰退让（核心）

`_firewall_common.py` 既有 `_stat_probe(ctx, candidates)` 内部 helper
+ `detect_iptables` / `detect_nft` / `detect_ufw` 三个公开探测，本
phase 追加 `detect_firewalld`：

```python
_FIREWALLD_BIN_CANDIDATES: tuple[str, ...] = (
    "/usr/bin/firewall-cmd",
    "/bin/firewall-cmd",
)

def detect_firewalld(ctx: CheckContext) -> str | None:
    """探测 firewall-cmd 二进制路径；首个 stat 命中即返，全失败返 None。"""
    return _stat_probe(ctx, _FIREWALLD_BIN_CANDIDATES)
```

候选只列 2 条（不像 iptables/nft/ufw 列 3 条）——firewalld 是 RPM
分发生态独占，路径稳定在 `/usr/bin/firewall-cmd`，`/bin/` 是 RHEL
8+ 上的兼容 symlink。`/usr/sbin/firewall-cmd` 不存在（这是用户态命令）。

**串扰退让**——firewalld 启用时底层会向 nftables 注 `firewalld` 表，
或向 iptables 注 `IN_<zone>` / `FWDI_<zone>` / `FWDO_<zone>` /
`OUT_<zone>` / `INPUT_ZONES` / `FORWARD_IN_ZONES` /
`FORWARD_OUT_ZONES` 链。如果 7e.2 的两个 Check 不退让，会在 RHEL
默认安装上对同一台机器双报「默认策略 = ACCEPT」。

新 helper：

```python
def output_managed_by_firewalld(stdout: str, *, backend: str) -> bool:
    """检测目标后端 dump 是否被 firewalld 接管。

    backend="iptables"：扫两类 firewalld 独有自建链前缀
      （任一命中即真）：
      1. 含 '-N IN_' 行（per-zone input chain）
      2. 含 '-N FWDI_' 行（per-zone forward-in chain）
      （iptables 默认配置不会出现这两个前缀。）

    backend="nftables"：JSON 解析后只看顶层 nftables[].table.name
      == "firewalld"。解析失败回退 False（与 ufw 同模式）。
    """
```

匹配的两个前缀（`-N IN_` / `-N FWDI_`）是 firewalld 独有命名约定，
不会与 docker / k8s / 用户自建链冲突；保守不再扫额外注释 tag
（不同 firewalld 版本注释行为不一致）。

**退让接入**——`iptables_audit.py` 与 `nftables_audit.py` 在
`_evaluate_*` 内紧挨现有 `output_managed_by_ufw` 之后追加：

```python
if output_managed_by_ufw(stdout, backend="iptables"):
    return _UFW_TAKEOVER
if output_managed_by_firewalld(stdout, backend="iptables"):    # 新
    return _FIREWALLD_TAKEOVER                                 # 新 sentinel
```

上层判定追加一个分支，输出文案与 ufw 退让平行：
"检出 firewalld 注入链，由 firewalld_audit 评估"。

### 3.5 命令编排（方案 A：3 固定命令）

固定 3 条命令，串行调用，任一失败即整体 `skipped` 返：

```
1. firewall-cmd --state                  # 服务状态（exit code 即结果）
2. firewall-cmd --get-default-zone       # 单 token 输出
3. firewall-cmd --list-all-zones         # 全 zone 大 blob
```

**为何 3 条而非 per-zone 循环**：

- argv 全部精确 tuple，无 `args_schema`（与 7e.2 形态一致）。
- SSH 往返固定 3 次，与 zone 数无关。
- `--list-all-zones` 大 blob 典型 10–15 KB（12 个标准 zone），远低于
  `max_output_bytes` 64 KiB。
- 解析虽然多一点但都是行级正则，单测易覆盖。

### 3.6 权限模型

`firewall-cmd` 通过 D-Bus + polkit 暴露接口。**默认 polkit 策略允许
非 root 调用 `--state` / `--get-default-zone` / `--list-all-zones`**
（这些是只读查询）。所以**实际部署中权限不足极少触发**；若触发说明
操作员显式收紧了 polkit。

回退文案与 7e.2 完全一致："在该主机为执行用户配置 NOPASSWD
sudoers，或以 root 身份运行 agentsec server-audit"——不针对 polkit
单写，避免远程 systemd / D-Bus 路径假设。

### 3.7 baseline 文件

不修改 `linux_hardening_baseline.yaml`——firewalld_audit 的判定阈值是
"target ∈ {default, DROP, REJECT, %%REJECT%%}" 这种不可调的硬规则，
rationale / remediation 文案直接硬编码在 Finding 模板里，与
`ufw_audit` 同模式（`ufw_audit` 也未读 baseline）。

## 4. 组件细节

### 4.1 `FirewalldAuditCheck`（`firewalld_audit`）

```python
class FirewalldAuditCheck(Check):
    id = "firewalld_audit"

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(...)
            return []
        if detect_firewalld(ctx) is None:
            ctx.status.not_applicable(...)
            return []

        # Cmd #1: --state
        state = ctx.executor.run(["firewall-cmd", "--state"])
        if state.rejected: ctx.status.skipped(...); return []
        if state.exit_code != 0:
            if looks_like_perm_denied(state.stderr):
                ctx.status.skipped("权限不足，需 root 或 NOPASSWD sudoers")
                return []
            # 服务未跑：1 条 critical 直接返
            return [Finding(check=self.id, severity="critical",
                            title="firewalld 已安装但未启用", ...)]

        # Cmd #2: --get-default-zone
        dz = ctx.executor.run(["firewall-cmd", "--get-default-zone"])
        if dz.rejected or dz.exit_code != 0 or not dz.stdout.strip():
            ctx.status.skipped(...); return []
        default_zone = dz.stdout.strip().split()[0]

        # Cmd #3: --list-all-zones
        la = ctx.executor.run(["firewall-cmd", "--list-all-zones"])
        if la.rejected or la.exit_code != 0 or not la.stdout.strip():
            ctx.status.skipped(...); return []

        zones = parse_firewalld_zones(la.stdout, default_zone=default_zone)
        candidates = [z for z in zones if z.is_active or z.is_default]

        findings: list[Finding] = []
        blob_sha = hashlib.sha256(la.stdout.encode("utf-8")).hexdigest()
        for z in candidates:
            if z.target != "ACCEPT":
                continue
            severity = "critical" if z.is_default else "high"
            findings.append(Finding(
                check=self.id, severity=severity,
                title=(f"firewalld 默认 zone {z.name} target=ACCEPT"
                       if z.is_default else
                       f"firewalld active zone {z.name} target=ACCEPT"),
                description=(
                    "默认接收策略 / 后端未激活 / IPv6 平行漏洞 — "
                    "CIS Linux 加固基线"),
                evidence={
                    "zone": z.name, "target": z.target,
                    "is_default": z.is_default, "is_active": z.is_active,
                    "blob_sha256": blob_sha,
                },
                remediation=(
                    f"`sudo firewall-cmd --permanent --zone={z.name} "
                    f"--set-target=default && sudo firewall-cmd --reload`"),
                threat_refs=["TI-LINUX-CIS-FIREWALL"],
            ))
        return findings
```

`run()` 主体目标 ≤ 80 行；上方草图为骨架，最终实现可适度拆 `_skip_reason` 私有 helper。

### 4.2 `parse_firewalld_zones`

```python
@dataclass(frozen=True)
class ZoneInfo:
    name: str
    target: str          # default / ACCEPT / DROP / REJECT / %%REJECT%%
    is_active: bool
    is_default: bool

def parse_firewalld_zones(stdout: str, *, default_zone: str) -> list[ZoneInfo]:
    """切块：每段以无前导空格的非空行起始（zone header），
    含 (active) 后缀 → is_active=True。
    段内匹配 ^\\s+target:\\s+(\\S+) 抓 target 值。
    段内 ^\\s+interfaces:\\s*(.*) 或 ^\\s+sources:\\s*(.*)
    任一非空 → is_active=True（兜底古版本 firewalld）。
    is_default = (name == default_zone)。"""
```

兜底：`target:` 行缺失（理论不可能）→ `target=""`，过滤层自然
跳过；空 blob → 返 `[]`。

### 4.3 `_firewall_common.py` 扩展

§3.4 已展开。新增的 `_FIREWALLD_BIN_CANDIDATES` /
`detect_firewalld` / `output_managed_by_firewalld` 与既有
`detect_iptables` / `detect_nft` / `detect_ufw` /
`output_managed_by_ufw` 同模式同测试套形态。

### 4.4 `iptables_audit.py` / `nftables_audit.py` 修改

每个 Check 内：

- 顶部 `import` 追加 `output_managed_by_firewalld`。
- 文件级 sentinel 追加：`_FIREWALLD_TAKEOVER = object()`。
- `_evaluate_*` 内紧挨现有 `output_managed_by_ufw` 之后追加 4 行：

```python
if output_managed_by_firewalld(stdout, backend="iptables"):
    return _FIREWALLD_TAKEOVER
```

- `run()` 内现有 `_UFW_TAKEOVER` 判定之后追加平行分支：

```python
if v4_findings is _FIREWALLD_TAKEOVER or v6_findings is _FIREWALLD_TAKEOVER:
    ctx.status.not_applicable(
        f"{self.id}：检出 firewalld 注入链，由 firewalld_audit 评估"
    )
    return []
```

`nftables_audit` 单 stdout，单次判定，对应位置同形态修改。

## 5. 数据流

```
FirewalldAuditCheck.__init__()
  └─ 无外部加载（baseline 不读，rationale/remediation 硬编码）

FirewalldAuditCheck.run(ctx)
  ├─ profile gating → not_applicable / continue
  ├─ detect_firewalld(ctx) → not_applicable / continue
  │
  ├─ Cmd #1: --state
  │     ├─ rejected                              → skipped
  │     ├─ exit_code == 0                        → 服务运行 (continue)
  │     ├─ stderr looks_like_perm_denied         → skipped
  │     └─ exit_code != 0                        → 1 critical finding, return
  │
  ├─ Cmd #2: --get-default-zone
  │     ├─ rejected / exit != 0 / 空 stdout      → skipped
  │     └─ default_zone = stdout.strip().split()[0]
  │
  ├─ Cmd #3: --list-all-zones
  │     ├─ rejected / exit != 0 / 空 stdout      → skipped
  │     └─ blob = stdout
  │
  ├─ Parse:  zones = parse_firewalld_zones(blob, default_zone=default_zone)
  ├─ Filter: candidates = [z for z in zones if z.is_active or z.is_default]
  ├─ Score:  z.target == "ACCEPT"?
  │           is_default → critical
  │           else       → high
  └─ ctx.status.set_ok()
     return findings
```

baseline 加载：无（与 ufw_audit 一致，无需 yaml 文件）。

`Snapshot` 接触面：不写 `ctx.snapshot.collect(...)`，与 7e/7e.1/7e.2
全套一致——纯只读发现，无 fixture 物化。

## 6. 错误处理

| 失败位置 | 处理 |
|---|---|
| profile 非 Linux | `not_applicable("当前 profile 不是 Linux")` |
| `detect_firewalld` 全候选未命中 | `not_applicable("被审主机未检出 firewall-cmd 二进制")` |
| Cmd #1 `--state` 被 policy `rejected` | `skipped("firewall-cmd 命令被策略拒绝 ({reason})")` |
| Cmd #1 `--state` exit_code == 0 | 服务运行，继续 |
| Cmd #1 `--state` exit_code != 0 且 stderr 含权限关键词 | `skipped("权限不足，需 root 或 NOPASSWD sudoers")` |
| Cmd #1 `--state` exit_code != 0（含 252 / "not running"） | **1 条 critical Finding**："firewalld 已安装但未启用"；return（不再跑 #2 #3） |
| Cmd #2 `--get-default-zone` 任何失败 | `skipped(reason)` |
| Cmd #3 `--list-all-zones` 任何失败 | `skipped(reason)` |
| Cmd #3 stdout 解析后 `zones == []` | 不报 finding，`set_ok` |
| `parse_firewalld_zones` 抓不到 `target:` 行 | 该 zone 视作 `target=""`；过滤层自然跳过 |
| `max_output_bytes` 截断 | `partial_evidence` low + 已解析部分继续（base 类语义） |
| `ctx.executor` 抛非业务异常（网络 / SSH） | 上抛 orchestrator |

### 与 7e.2 一致的不变量

- Check 内不捕获通用 `Exception`——传输层异常归 orchestrator。
- `ctx.status` 单次设置；多次调用以最后一次为准（base 类已保证）。
- `run()` 主体目标 ≤ 80 行；`parse_firewalld_zones` 拆模块顶层私有函数。
- 三条命令的失败回退**不**用 sentinel object 模式（与 iptables_audit 不同）——iptables 是因为 v4 / v6 双轨需要分开判定；这里三条命令是严格串行链，每条任一失败即 `skipped` 整体返，直接走 if/else 更清晰。

## 7. SSH policy 扩展

全部走严格 argv schema（与 7e.2 一致，无 `args_schema`）。

### 7.1 `allowed_paths` 追加（2 条 exact）

```yaml
# firewall bin-resolver candidates (Phase 7e.3) — stat-probe only, exact paths
- {kind: exact, path: "/usr/bin/firewall-cmd"}
- {kind: exact, path: "/bin/firewall-cmd"}
```

放在现有 9 条 firewall bin 之后（紧邻 7e.2 注释 banner `# firewall
bin-resolver candidates (Phase 7e.2) ...`，新行追加 7e.3 banner）。

### 7.2 `commands` 追加 1 段

```yaml
firewall-cmd:
  # Phase 7e.3 — read-only zone introspection. Write operations
  # (--add-service, --add-port, --remove-service, --remove-port,
  #  --add-rich-rule, --remove-rich-rule, --reload, --runtime-to-permanent,
  #  --panic-on, --panic-off, --set-default-zone, --new-zone, --delete-zone,
  #  --change-interface) are NOT in any allowed_argv tuple and unreachable
  # by construction.
  allowed_argv:
    - ["firewall-cmd", "--state"]
    - ["firewall-cmd", "--get-default-zone"]
    - ["firewall-cmd", "--list-all-zones"]
```

### 7.3 为何全用 `allowed_argv`（精确 tuple）

- 三条命令各 1 个固定形态，**无可参数化字段**。
- 精确 tuple O(1) 比对，无 placeholder 推理 → 攻击面最小。
- 与 7e.2 `iptables -S` / `nft -j list ruleset` / `ufw status verbose` 同模式。
- 方案 A 选择"3 命令固定 + 大 dump"的代价正是这种简洁性。

### 7.4 不修改的面

- `find` / `cat` / `grep` 命令面：firewalld 不读文件（不读
  `/etc/firewalld/zones/*.xml`）。与 ufw 决策一致——纯靠用户态命令的
  stdout，不试图从配置文件还原状态。
- `write_operations`：不开启。
- `sudo` 类型：不引入。

## 8. 测试

### 8.1 fixture 清单

`tests/fixtures/firewall/`（已有目录，复用）追加 9 个：

| 文件 | 用途 |
|---|---|
| `firewalld_state_running.txt` | 单行 `running\n`，exit 0 |
| `firewalld_state_stopped.txt` | 单行 `not running\n`，exit 252 |
| `firewalld_default_zone_public.txt` | 单行 `public\n` |
| `firewalld_list_all_default_only.txt` | 12 个标准 zone，仅 `public` 标 `(active)` 且 `target: default`（CIS 合规姿态） |
| `firewalld_list_all_default_accept.txt` | 同上但 `public` 的 `target: ACCEPT`（critical 触发） |
| `firewalld_list_all_multi_active_mixed.txt` | `public` (active, default, target=default) + `dmz` (active, target=ACCEPT) → 1 high finding |
| `firewalld_list_all_empty.txt` | 空文件（zero-zone 兜底） |
| `iptables_with_firewalld.txt` | 含 `-N IN_public` / `-N FWDI_public` 的 iptables -S 输出 |
| `nft_ruleset_with_firewalld.json` | 顶层含 `{"table": {"name": "firewalld", "family": "inet"}}` 的 JSON dump |

### 8.2 单测矩阵

**`tests/test_firewalld_audit.py`（新）**——11 个用例：

| # | 名称 | 触发 | 期望 |
|---|---|---|---|
| 1 | `test_not_applicable_macos` | profile=macos | `not_applicable` + 0 finding |
| 2 | `test_not_applicable_no_binary` | `detect_firewalld → None` | `not_applicable` |
| 3 | `test_critical_when_service_stopped` | state exit=252 + "not running" | 1 critical finding，停在 cmd #1 |
| 4 | `test_skipped_when_state_perm_denied` | state exit=126 + "Permission denied" | `skipped` 含 "权限不足" |
| 5 | `test_skipped_when_get_default_zone_empty` | cmd #2 stdout 为空 | `skipped` |
| 6 | `test_skipped_when_list_all_rejected` | cmd #3 rejected | `skipped` 含 "命令被策略拒绝" |
| 7 | `test_clean_default_only_active` | default-only-active fixture | 0 finding，`set_ok` |
| 8 | `test_critical_default_zone_accept` | default-accept fixture | 1 critical，`evidence.is_default=True` |
| 9 | `test_high_non_default_active_accept` | multi-active-mixed fixture | 1 high，`evidence.zone="dmz"` |
| 10 | `test_zero_zones_no_finding` | empty fixture | 0 finding，`set_ok` |
| 11 | `test_partial_evidence_on_truncation` | mock truncated stdout | 1 low partial_evidence + 已解析部分继续 |

**`tests/test_firewall_common.py`（修）**——补 6 个用例：

- `test_detect_firewalld_first_path_hit` / `test_detect_firewalld_no_binary`
- `test_output_managed_by_firewalld_iptables_in_zone` (`-N IN_public`)
- `test_output_managed_by_firewalld_iptables_fwdi` (`-N FWDI_public`)
- `test_output_managed_by_firewalld_nftables_table` (顶层 firewalld 表)
- `test_output_managed_by_firewalld_unrelated` (干净 dump → False)

**`tests/test_iptables_audit.py`（修）**——补 1 个用例：

- `test_not_applicable_when_firewalld_takeover` — 输入
  `iptables_with_firewalld.txt`，检出 `_FIREWALLD_TAKEOVER`，整体
  `not_applicable("检出 firewalld 注入链…")`

**`tests/test_nftables_audit.py`（修）**——补 1 个用例：

- `test_not_applicable_when_firewalld_takeover` — 输入
  `nft_ruleset_with_firewalld.json`，同上

**`tests/test_ssh_policy.py`（修）**——补 4 个用例：

| 用例 | 输入 argv | 期望 |
|---|---|---|
| `test_firewall_cmd_state_allowed` | `["firewall-cmd", "--state"]` | accept |
| `test_firewall_cmd_get_default_zone_allowed` | `["firewall-cmd", "--get-default-zone"]` | accept |
| `test_firewall_cmd_list_all_zones_allowed` | `["firewall-cmd", "--list-all-zones"]` | accept |
| `test_firewall_cmd_add_service_rejected` | `["firewall-cmd", "--add-service=ssh"]` | reject |

### 8.3 集成测试

`tests/integration/test_openclaw_mock.py` 不动——OpenClaw mock 用
profile=linux + 不安装 firewall-cmd → 自然走 `not_applicable` 分支，
不影响 sample report drift guard。

不新增 `test_firewalld_present_mock`——会把 sample report 锁死到含
firewalld 的形态，拉抽屉到所有未来 sample 重生场景。与 7e.2 决策
一致。

### 8.4 测试总数增量

- 新文件：11 个用例
- 既有文件补丁：6 + 1 + 1 + 4 = 12 个用例
- 合计：+23 个 unit test
- 预期 `pytest` 总数从 1362 → ≈ 1385

## 9. 范围外 + 发布 + 文档

### 9.1 Out-of-scope（明确推后）

| 主题 | 推后到 | 原因 |
|---|---|---|
| Rich rules 危险动作扫描 | 7e.5 | 需要扩展 `--list-all-zones` 解析到 `rich rules:` 段；OpenClaw 默认安装不写 rich rule，价值低 |
| 危险服务 / 端口扫描 | 7e.5 | 需要黑名单数据 + per-service 解析；本 phase 已被用户明确排除 |
| Runtime / Permanent 漂移检测 | 7e.5 | argv 翻倍；本 phase 被排除 |
| firewalld direct interface | 7e.5 | direct interface 是 firewalld 兼容 iptables 老规则的逃生通道；少用 |
| `--get-log-denied` 配置基线 | 7e.5 | 配置面，与日志面更近 |
| polkit 自定义规则提示 | 不做 | 操作员显式收紧才会触发；7e.3 错误提示已统一 |
| firewalld 在 macOS / linux_user_mode 跑 | 不做 | 平台 gating 已挡 |
| 跨主机 zone 一致性比对 | 不做 | agentsec 是单主机审计工具 |

### 9.2 版本发布

- **目标版本**：`v0.17.0`
- **CHANGELOG.md**：新增 "Phase 7e.3 — firewalld audit"
- **ROADMAP.md**：把 7e.3 从 candidate 移到 shipped；7e.5 候选保留以上 6 条
- **README.md**：Check 列表 28 → 29 类
- **CLAUDE.md**：在「Stage E additions」"Total checks" 行更新；新增「firewalld audit (Phase 7e.3, v0.17.0)」段，与现有 docker / firewall / supply-chain 段同模式
- **memory**：`project_openclaw_v020_progress.md` 更新

### 9.3 ADR

新写 `docs/adr/0017-phase-7e3-firewalld-audit.md`，骨架照 ADR-0011：

- **Context**：RHEL/CentOS/Fedora 默认 firewalld 是 7e.2 三件套覆盖的盲区
- **Decision**：方案 A（3 固定命令 + 大 dump）+ 跨后端串扰退让
- **Consequences**：iptables/nftables Check 在 firewalld 主机上走 `not_applicable`；future 7e.5 候选明确推后
- **Alternatives considered**：方案 B（per-zone 循环 argv schema）/ 方案 C（不查默认 zone）/ 不双退让接受双报

### 9.4 文档增量

- `docs/superpowers/specs/2026-05-12-phase-7e3-firewalld-design.md`（本 spec）
- `docs/adr/0017-phase-7e3-firewalld-audit.md`（实施完毕后写）
- `docs/guide/`：不动
- `docs/samples/report-2026-04-28/`：不刷新（drift guard 不会跳红）

### 9.5 PyPI 发布流程

复用 v0.16.0 流程：
- `pyproject.toml` bump 到 `0.17.0`
- `pytest` 全绿（≈ 1385 个）
- `ruff check src/` 干净
- `python -m build` → `twine upload dist/agentsec_eval-0.17.0*`
- 用 `~/.pypirc` 中的项目 token

## 10. 决策摘要

| 决策 | 选择 | 来源 |
|---|---|---|
| 审计范围 | A+B+C 三件（service / 默认 zone target / 各 active zone target） | 用户答 §2 |
| 跨后端串扰 | 扩展 `_firewall_common.py`，iptables/nft 双退让 | 用户答 §2 |
| target 判定 | 仅 `ACCEPT` 报；默认 zone critical / 其他 active zone high | 用户答 §2 |
| 命令编排 | 方案 A（3 固定命令 + `--list-all-zones` 大 dump） | 用户答 §3 |
| baseline 文件 | 不引入（与 ufw_audit 一致） | spec §3.7 |
| sentinel 模式 | 不用（与 iptables_audit 不同；这里串行链直接 if/else） | spec §6 |
| firewalld bin 候选 | 2 条 (`/usr/bin/`, `/bin/`) | spec §3.4 |
| 接管检测前缀 | `-N IN_` / `-N FWDI_`（iptables）+ `firewalld` 表名（nftables） | spec §3.4 |
