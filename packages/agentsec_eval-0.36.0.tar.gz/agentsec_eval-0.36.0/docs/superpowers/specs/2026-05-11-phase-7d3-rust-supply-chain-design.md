# Phase 7d.3 — rust / crates.io 供应链审计 Check（直接复用 `_supply_chain_common`）

**日期**：2026-05-11
**作者**：roger
**状态**：草案，待实施
**关联 ADR**：本 spec 落地后写 ADR-0015；前置 ADR-0012（7d-npm）+ ADR-0013（7d.1-pip）+ ADR-0014（7d.2-go，触发 common 抽取）。

## 1. 目标

`agentsec server-audit` 在 v0.14.0 已有 27 类 Check，包含 npm + pip + go 三个供应链 Check + 抽取出的 `_supply_chain_common.py`。Phase 7d.3 把同样能力扩到 **Rust / crates.io 生态**：按 operator 在 `openclaw-target.yaml` 中配置的 `Cargo.lock` 路径列表，匹配 OSV-Cargo advisory 子集，emit 已知漏洞 finding。

ROADMAP `Phase 7d.3+` 原文：「Skills / Plugins 深化的剩余面（rust 生态 + plugin_static 静态扫描扩展）」。本 phase 仅覆盖 rust；plugin_static 扩展留给 7d.x。

**与前 3 phase 的关键差异：rule of three 已触发，本 phase 直接复用 `_supply_chain_common.py`，零抽取工作**。这是 ADR-0014 D3 抽取的"投资回收"。

## 2. 范围

新增：1 个 Check + 1 个 OSV fetcher + 1 个 bundled DB + 1 条 TI umbrella + `ServerAuditConfig.cargo_lock_paths` + `CheckContext.cargo_lock_paths` 通道。

| 组件 | id / 路径 | 职责 |
|---|---|---|
| `RustSupplyChainAuditCheck` | `rust_supply_chain_audit` | 读 operator 配置中列出的 `Cargo.lock` 路径，按 (crate name, version) 匹配 OSV-Cargo DB |
| OSV-Cargo fetcher | `src/agentsec/audit/ioc_update/fetchers/osv_cargo.py` | `agentsec ioc-update` 子流程：拉 `https://osv-vulnerabilities.storage.googleapis.com/crates.io/all.zip`，过滤、归一化、写 `osv_cargo.json` |
| Bundled DB | `src/agentsec/audit/ioc/osv_cargo.json` | 提交到 git，wheel 打包随发；CI `--check` 验证 + 15 MB 上限 |
| TI umbrella | `TI-OSV-CRATES-CATALOG`（在 `threat_intel.yaml`） | rust_supply_chain finding 的 `threat_refs` 引用 |
| Config schema | `ServerAuditConfig.cargo_lock_paths: list[str] = []` | operator 在 `openclaw-target.yaml` 列要审的 Cargo.lock |
| Context 通道 | `CheckContext.cargo_lock_paths: tuple[str, ...] = ()` | server-audit orchestrator 把 config 传给 Check |

**首期范围**：

- **生态**：仅 Rust / crates.io。
- **lockfile 格式**：仅 `Cargo.lock` v2 / v3 / v4（schema 同构，单 parser 处理）。v1（pre-Rust 1.41，~2020 前）不支持。
- **路径来源**：operator config（与 7d.1 / 7d.2 同款 — OpenClaw 无 Rust footprint）。
- **basename 严格匹配**：`Cargo.lock`，**大小写敏感**（Cargo 官方就是首字母大写；`cargo.lock` 小写形态被拒）。
- **包名不归一化**：crate 名按 Cargo 语义保留原样，`serde-json` 与 `serde_json` 是**不同**的两个 crate（与 PEP-503 pip 行为相反）。
- **源过滤**：仅匹配 `source = "registry+https://github.com/rust-lang/crates.io-index"` 的 package。workspace local（无 source）/ git 依赖（`source = "git+..."`）/ path 依赖silently skip — 与 pip silently skip VCS URL 同理。

**out of scope**：

- Cargo.lock v1 格式（5 年以上遗产）
- 在线 osv.dev 查询（架构选 offline，与 7d / 7d.1 / 7d.2 同）
- macOS profile（仅 `linux` / `linux_user_mode`，与前三 phase 同）
- `Cargo.toml` direct deps（缺 transitive 锁定）
- vendored deps 目录扫描
- 抽取共享代码到 `_supply_chain_common.py`（已抽，本 phase 直接 import）
- 7d.2 final-review follow-ups（独立 cleanup commit）

## 3. 架构

### 3.1 文件布局

```
src/agentsec/audit/checks/
  rust_supply_chain_audit.py            # 新 — Check 主体
src/agentsec/audit/ioc/
  osv_cargo.json                        # 新 — bundled DB
  threat_intel.yaml                     # 现有，追加 TI-OSV-CRATES-CATALOG
src/agentsec/audit/ioc_update/fetchers/
  osv_cargo.py                          # 新 — OSV-Cargo 抓取 + 归一化
src/agentsec/audit/ioc_update/
  cli.py                                # 现有，加 _run_osv_cargo（4-way gather）
src/agentsec/audit/
  ssh_policy.yaml                       # 现有，加 7d.3 注释段（无新静态条目）
src/agentsec/
  config.py                             # 现有，加 ServerAuditConfig.cargo_lock_paths
  cli.py                                # 现有，注册 RustSupplyChainAuditCheck（两处） + wire cargo_lock_paths
src/agentsec/audit/checks/base.py       # 现有，加 CheckContext.cargo_lock_paths
src/agentsec/audit/server_audit.py      # 现有，per-check ctx 传 cargo_lock_paths
scripts/
  check_osv_cargo.py                    # 新 — CI 一致性 + 体积 ≤ 15 MB 守门
.github/workflows/ci.yml                # 现有，加 check_osv_cargo.py 步骤
tests/audit/checks/
  test_rust_supply_chain_audit.py       # 新
  test_supply_chain_redaction.py        # 现有，扩 1 case 给 rust
  test_base.py                          # 现有，扩 2 case
tests/audit/ioc_update/fetchers/
  test_osv_cargo.py                     # 新
tests/test_ioc_update_osv_cargo_wiring.py # 新
tests/scripts/
  test_check_osv_cargo.py               # 新
tests/audit/
  test_config.py                        # 现有，扩 6 case
  test_server_audit_orchestrator.py     # 现有，扩 1 case
tests/fixtures/supply_chain_cargo/
  Cargo.lock-clean
  Cargo.lock-vulnerable
  Cargo.lock-edge-cases                 # workspace local / git 源 / path 源 / pre-release
  osv_cargo_subset.json
tests/fixtures/osv/cargo/
  # 6 个 OSV-Cargo 真实 advisory JSON 截取
docs/adr/0015-phase-7d3-rust-supply-chain.md
docs/superpowers/specs/2026-05-11-phase-7d3-rust-supply-chain-design.md
```

新增文件量级：5（源码 + DB） + 6（test + fixture） + 1（CI 脚本） + 2（ADR/spec） = 14。**零新 PyPI 依赖** — `tomllib` 是 Python 3.11+ stdlib，`semver>=3,<4` 已在 deps。

### 3.2 平台 gating

`RustSupplyChainAuditCheck` 在 `run()` 顶部判断 `ctx.profile.name in ("linux", "linux_user_mode")`，非 Linux profile 标 `not_applicable`。

### 3.3 不依赖 `_REQUIRED_PATHS`

Same as 7d.1 / 7d.2 — 路径完全来自 operator config。`run()` 顶部判 `if not ctx.cargo_lock_paths: → not_applicable("未配置")`。

### 3.4 Check 类轮廓

```python
import tomllib
from pathlib import Path

import semver

from ..findings import Finding
from ._supply_chain_common import (
    Severity,
    load_advisory_db,
)
from .base import Check, CheckContext


_OSV_DB_PATH = Path(__file__).parent.parent / "ioc" / "osv_cargo.json"


def _safe_parse_cargo_version(s: str) -> semver.Version | None:
    """Cargo uses strict semver 2.0 — no v prefix, no +incompatible."""
    if not s:
        return None
    try:
        return semver.Version.parse(s)
    except (ValueError, TypeError):
        return None


def version_in_any_cargo_range(version: str, ranges: list[dict]) -> bool:
    """True iff `version` falls into at least one OSV range entry."""
    v = _safe_parse_cargo_version(version)
    if v is None:
        return False
    for r in ranges:
        intro = r.get("introduced", "0")
        fixed = r.get("fixed")
        last = r.get("last_affected")
        if intro != "0":
            intro_v = _safe_parse_cargo_version(intro)
            if intro_v is not None and v.compare(intro_v) < 0:
                continue
        if fixed is not None:
            fixed_v = _safe_parse_cargo_version(fixed)
            if fixed_v is not None and v.compare(fixed_v) >= 0:
                continue
        if last is not None:
            last_v = _safe_parse_cargo_version(last)
            if last_v is not None and v.compare(last_v) > 0:
                continue
        return True
    return False


_CRATES_IO_REGISTRY = "registry+https://github.com/rust-lang/crates.io-index"


def parse_cargo_lock(stdout: str) -> list[tuple[str, str]]:
    """Return [(crate_name, version)] from Cargo.lock TOML.

    Filters to packages whose source is the official crates.io registry.
    Workspace-local (no source) / git / path / alternate-registry deps
    are silently skipped.
    """
    try:
        data = tomllib.loads(stdout)
    except tomllib.TOMLDecodeError:
        return []
    out: list[tuple[str, str]] = []
    for pkg in data.get("package", []):
        if not isinstance(pkg, dict):
            continue
        if pkg.get("source") != _CRATES_IO_REGISTRY:
            continue
        name = pkg.get("name")
        version = pkg.get("version")
        if not name or not version:
            continue
        out.append((name, version))
    return out


def _extract_severity_label(adv: dict) -> Severity:
    sev = adv.get("severity")
    if sev in ("critical", "high", "medium", "low"):
        return sev
    return "medium"


class RustSupplyChainAuditCheck(Check):
    id = "rust_supply_chain_audit"

    def __init__(self, db_path: Path | None = None):
        super().__init__()
        path = db_path if db_path is not None else _OSV_DB_PATH
        self._advisories_by_pkg = load_advisory_db(path)

    async def run(self, ctx: CheckContext) -> list[Finding]:
        if ctx.profile.name not in ("linux", "linux_user_mode"):
            ctx.status.not_applicable(f"{self.id}：非 Linux profile")
            return []
        if not ctx.cargo_lock_paths:
            ctx.status.not_applicable(f"{self.id}：未配置 cargo_lock_paths")
            return []

        findings: list[Finding] = []
        n_skipped = 0
        for lock_path in ctx.cargo_lock_paths:
            result = ctx.executor.run(["cat", lock_path])
            if result.rejected:
                n_skipped += 1
                continue
            if result.exit_code != 0:
                n_skipped += 1
                continue
            if not result.stdout.strip():
                n_skipped += 1
                continue
            findings.extend(self._scan_lockfile(ctx, lock_path, result.stdout))
        if not findings and n_skipped == len(ctx.cargo_lock_paths):
            ctx.status.skipped(
                f"{self.id}：所有 cargo_lock_paths 均不可读 (n={n_skipped})"
            )
        return findings

    def _scan_lockfile(self, ctx, lock_path, stdout):
        crates = parse_cargo_lock(stdout)
        findings: list[Finding] = []
        for name, version in crates:
            if _safe_parse_cargo_version(version) is None:
                findings.append(self._unparseable_finding(ctx, name, version, lock_path))
                continue
            for adv in self._advisories_by_pkg.get(name, []):
                if version_in_any_cargo_range(version, adv["ranges"]):
                    findings.append(
                        self._advisory_finding(ctx, name, version, adv, lock_path)
                    )
        return findings

    def _advisory_finding(self, ctx, name, version, adv, lock_path):
        # use self.make_finding(ctx, ...) — Redactor pass per 7d.2 convention
        ...

    def _unparseable_finding(self, ctx, name, version, lock_path):
        ...
```

## 4. 数据模型

### 4.1 OSV-Cargo 归一化 schema（与 OSV-npm/PyPI/Go 同形）

```json
{
  "id": "GHSA-xxxx-yyyy-zzzz",
  "package": "serde",
  "ranges": [{"introduced": "0", "fixed": "1.0.150"}],
  "severity": "critical|high|medium|low",
  "summary": "短摘要 ≤ 200 字符",
  "url": "https://github.com/advisories/GHSA-xxxx-yyyy-zzzz",
  "aliases": ["CVE-2023-xxxxx", "RUSTSEC-2023-0001"]
}
```

差异点：
- `package` 字段是 crate 名（无 `/`，无前缀），保留原样
- `ranges` 用纯 semver 2.0 字符串（无 v 前缀）
- `aliases` 经常含 `RUSTSEC-YYYY-NNNN`（Rust Security Advisory Database id）
- 同一 OSV entry 多 crate → 展开多条 records，dedup `(id, package)`

### 4.2 Finding 形态（走 `make_finding`）

```python
self.make_finding(
    ctx,
    severity=<from_advisory>,
    title=f"rust {name}@{version} 命中 {advisory_id}（severity={sev}）",
    description=adv["summary"][:200],
    evidence={
        "package": name,
        "version": version,
        "advisory_id": advisory_id,
        "aliases": [...],
        "fixed_in": "1.0.150 或 (no fixed version)",
        "url": "https://github.com/advisories/...",
        "lock_path": lock_path,
    },
    remediation=f"cargo update -p {name} --precise {fixed_in}",
    threat_refs=["TI-OSV-CRATES-CATALOG"],
)
```

无法解析的 semver（罕见，Cargo 强制 semver）：

```python
self.make_finding(
    ctx,
    severity="low",
    title=f"无法解析 semver: {name}@{version}",
    description="非标准 semver 版本字符串；Cargo 应该不会出现，可能是手改 lockfile",
    evidence={"package": name, "version": version, "lock_path": lock_path},
    remediation="跑 `cargo update` 重生成 Cargo.lock",
    threat_refs=["TI-OSV-CRATES-CATALOG"],
)
```

## 5. CommandPolicy 动态注入

与 7d.1 / 7d.2 同款：
1. `ServerAuditConfig.cargo_lock_paths` Pydantic validator：
   - 每条字符串以 `/` 或 `~/` 起头
   - `metachar_guard.contains_shell_metachar([path])` 必须返 None
   - basename 必须等于 `"Cargo.lock"`（**大小写敏感**）
2. `materialize_paths` 把 `~/` 展开
3. CLI 调用 `policy.add_runtime_allowed_paths(paths, kind="exact")`
4. `_log_runtime_paths_added(audit_log, paths, "ServerAuditConfig.cargo_lock_paths")` 记录

## 6. OSV-Cargo fetcher

### 6.1 `OsvCargoFetcher`

镜像 `OsvGoFetcher`：
- name = `"osv_cargo"`
- URL：`https://osv-vulnerabilities.storage.googleapis.com/crates.io/all.zip`
- 重试退避 `[2, 4, 8]`s
- FetchResult key `_osv_cargo_full`

### 6.2 `normalize_osv_cargo_entry` — 5-轴 filter chain

| 轴 | 规则 |
|---|---|
| 1. withdrawn | drop |
| 2. ecosystem | `affected[].package.ecosystem == "crates.io"` 收（**含点，大小写敏感**） |
| 3. semver/ecosystem range | `_extract_cargo_ranges`（接受 SEMVER + ECOSYSTEM 类型，与 osv_go.py 对应函数同款） |
| 4. CVSS_V3 | 缺则 drop |
| 5. age | severity ∈ {medium, low} + `published > 2 年` → drop |

`_supply_chain_common._extract_severity` / `_is_within_age` / `_parse_cvss_score` / `MEDIUM_LOW_MAX_AGE_DAYS` 全部 import 复用。

**多 affected 包**：遍历所有 crates.io affected 项，每个生成一条 normalized 记录。

### 6.3 输出体积估计

OSV-Cargo 全量较小（Rust 生态较年轻，但 crates.io 增长快）。预估 ~2000-3000 entries / ~600-900 KB。CI cap 仍 15 MB。

## 7. ioc-update CLI 接入

`src/agentsec/audit/ioc_update/cli.py` 加 `_run_osv_cargo(ctx, cache_dir)`，与 `_run_osv_npm` / `_run_osv_pypi` / `_run_osv_go` **4-way** `asyncio.gather`：

```python
osv_npm_path, osv_pypi_path, osv_go_path, osv_cargo_path = await asyncio.gather(
    _run_osv_npm(fctx, out_dir),
    _run_osv_pypi(fctx, out_dir),
    _run_osv_go(fctx, out_dir),
    _run_osv_cargo(fctx, out_dir),
)
# ... 四段 log_event
```

任一 degraded 不阻塞其它三方。

## 8. 测试矩阵

### 8.1 Parser tests（`test_rust_supply_chain_audit.py`）

```
test_parse_simple_crate                # [[package]] → ("serde", "1.0.150")
test_parse_skip_workspace_local        # 无 source → skip
test_parse_skip_git_source             # source = "git+..." → skip
test_parse_skip_path_source            # source = "path+..." → skip（罕见但合法）
test_parse_skip_alternate_registry     # source = "registry+https://other.io/..." → skip
test_parse_pre_release_version         # 0.4.0-beta.1 收
test_parse_invalid_toml_returns_empty  # tomllib.loads 失败
test_parse_multiple_packages           # 多 [[package]] 都收
```

### 8.2 Matcher tests

```
test_match_exact_inside_range
test_match_at_introduced_boundary
test_match_at_fixed_boundary_excluded
test_match_pre_release_in_range        # 0.4.0-beta.1 in [0, 0.4.0)
test_match_unparseable_returns_false
test_match_multiple_ranges_or
```

### 8.3 Check end-to-end（mock SSHExecutor）

```
test_check_empty_config_not_applicable
test_check_single_lockfile_one_hit
test_check_multi_lockfile_mixed
test_check_all_paths_unreadable_skipped
test_check_unparseable_version_low_finding
test_check_non_linux_not_applicable
```

### 8.4 OSV-Cargo fetcher tests（`test_osv_cargo.py`）

Normalize 7（5 axes + multi-affected + cross-ecosystem 过滤） + HTTP 2 = 9。

### 8.5 CI script tests（`test_check_osv_cargo.py`）

3（valid / oversize / invalid JSON）。

### 8.6 ioc-update wiring tests（`test_ioc_update_osv_cargo_wiring.py`）

2（success / degraded）。

### 8.7 Config / CheckContext / propagation tests

- `test_config.py` 扩 6 case：default empty / accept abs+tilde / reject relative / reject metachar / reject non-Cargo.lock basename / reject Cargo.lock.bak suffix。
- `test_base.py` 扩 2 case：default empty / assignable。
- `test_server_audit_orchestrator.py` 扩 1 case：propagation。

### 8.8 Redaction test（扩 `test_supply_chain_redaction.py`）

加 1 case：`test_rust_check_routes_through_redactor`，与 npm/pip/go 同模式。

**总计**：parser 8 + matcher 6 + Check e2e 6 + fetcher 9 + CI script 3 + wiring 2 + config 6 + CheckContext 2 + propagation 1 + redaction 1 = **44 新测试**。

预期 1302 → ~1346 passing。

### 8.9 Sample 报告刷新

`docs/samples/report-2026-04-28/`：增 `rust_supply_chain_audit: not_applicable` 行 + 27 → 28 计数。

## 9. CI / Release

### 9.1 CI guard

`scripts/check_osv_cargo.py --check`：JSON 合法 + ≤ 15 MB。在 `.github/workflows/ci.yml` 的 `ioc-sync` 与 `test-macos` jobs 中加 step。

### 9.2 Release 链路（与 v0.14.0 一致）

1. 实现完整 + 测试全绿后跑 `agentsec ioc-update --force`（4-way 并行）
2. `cp .cache/ioc-update-<date>/proposed-osv_cargo.json src/agentsec/audit/ioc/osv_cargo.json`
3. 独立 `data(7d.3):` commit
4. ROADMAP / CHANGELOG / README / CLAUDE.md / pyproject 0.14.0 → 0.15.0 独立 docs commit
5. ADR-0015 独立 commit
6. push main + tag `v0.15.0` + push tag
7. `twine upload dist/agentsec_eval-0.15.0*` 手动发 PyPI

## 10. 决策清单（→ ADR-0015）

| ID | 决策 | 备选 | 选择理由 |
|---|---|---|---|
| D1 | 路径来自 operator config，不进 PlatformProfile | profile 加 `cargo_root` / 扫主机 | 与 7d.1 / 7d.2 一致；OpenClaw 无 Rust footprint |
| D2 | 仅 Cargo.lock；basename 严格匹配；大小写敏感 | 多种 / 不区分大小写 | Cargo 官方就是首字母大写；最安全的解析约定 |
| D3 | crate 名**不**做归一化 | PEP-503 风格归一化 | Cargo 语义中 `serde-json` 与 `serde_json` 是两个不同 crate |
| D4 | Cargo 用纯 semver（无 v 前缀，无 +incompatible） | 同 Go 模式做剥取 | Cargo 强制规范 semver；不需要清理 |
| D5 | 仅匹配 `source = registry+...crates.io-index` | 也接受 git/path/alternate-registry | git/path 依赖不在 OSV 公共数据库内；alt registry 是私有，超出 scope |
| D6 | **直接 import `_supply_chain_common`，零抽取** | 再抽一次 / 复制粘贴 | rule of three 的"投资回收"；7d.2 抽取已铺好 |
| D7 | exact-kind dynamic injection | static / prefix | 与 7d.1 / 7d.2 同款 |
| D8 | OSV-Cargo 5-轴 filter chain 与 npm/pypi/go 同 | 重新调阈值 | 已验证；common 抽完后单点维护 |
| D9 | TI 单 umbrella `TI-OSV-CRATES-CATALOG` | 每 advisory 一条 TI | 同 npm/pypi/go |

## 11. 7d.2 final-review follow-ups（明确不在本 phase）

7d.2 final review 留下的 8 项 follow-ups（3 Important + 5 Minor）**不在本 phase 范围**，留独立 cleanup commit / phase 处理。

明确推迟的：
- evidence 路径 key 不一致（npm `npm_root` vs pip/go/rust `lock_path`）
- `_extract_severity_label` 仍在 4 Check 中各有副本
- cli.py 中 `from .config import ServerAuditConfig` 重复 import
- `osv_npm.py` 不对称 `__all__` 块
- `_safe_parse_*` 短输入边界 / `vv1.2.3` 防御测试 / 0-package 诊断信号
- 15 MB CI cap 偏松
- tautology 测试断言

## 12. Out of scope

- Cargo.lock v1 格式
- `Cargo.toml` 单独读取（缺 transitive 锁定）
- vendored deps 目录（`vendor/`）扫描
- 在线 osv.dev 查询
- macOS / Windows 平台
- alternate registries（私有 / org-internal）
- git/path 依赖告警（silently skip 一致 pip/go 行为）
- 共享代码再抽取
- 7d.2 final-review follow-ups
