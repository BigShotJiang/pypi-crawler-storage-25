# Phase 7c.x.4 — Perf + Refactor Polish 设计

**状态**: 草案
**日期**: 2026-05-15
**前置**: Phase 7c.x.3（v0.28.0 — multi-server sampling，7c.x 三步走完结）
**目标版本**: v0.29.0

## 1. 背景与动机

Phase 7c.x.1 / 7c.x.2 / 7c.x.3 完成了 multi-server capability 等价：
multi-server v1 现在可声明 tools / resources / prompts / mutations /
sampling 的任意组合。三个 phase 的 final review 累计标记 4 类
non-blocking cleanup 候选：

- **A. β splice re-fetch**（dirty 只重抓变更 server）
- **B. `asyncio.gather` 并发 list_tools**（vs 顺序 await）
- **C. `run()` 提取 helpers**（_resolve_sampling_per_server +
  _rebuild_tools_spec；run() 现 ~359 行）
- **D. 杂项**：`sampling_per_server` 严格 key + `_build_message_handler`
  反向 docstring cross-ref

7c.x.4 是优化轻量清理 phase，选择 **保留 α + 加 gather + 提取
helpers + 严格 key**。β splice 留给真有性能 pain 的未来 phase
（v1 in-memory streams 性能不敏感）。

## 2. 范围

**v1 包含**：

- **`asyncio.gather` 并发 list_tools**：初始 tools_spec 拼装 + dirty
  re-fetch + per-session capability probe 全部并发化。`return_exceptions=True`
  以保留 per-session 「Method not found」静默路径
- **`_resolve_sampling_per_server` 模块级 helper**：把 `run()` 内 ~14
  行的 effective_per_server 内联块提取成纯函数。同时**严格化** key
  检查（`cfg["policy"]` 替换 `cfg.get("policy", "deny")`，typo 立即
  暴露）
- **`_rebuild_tools_spec` async 模块级 helper**：单一规范实现，初始
  setup + dirty re-fetch 两处共用。内部用 `asyncio.gather` 并发。
- **`_probe_server_capabilities` async 模块级 helper**：N session
  resources/prompts probe 并发化
- **`_build_message_handler` docstring 加反向 cross-ref** 指向
  `_build_sampling_callback`（对称提醒，零功能改动）

**v1 不包含**（明确延后）：

- **β splice**：α + gather 已显著改善 perf，β 增加 slice 维护
  burden 留给真有 pain 的 phase
- **`run()` 进一步拆分**：dirty re-fetch 块的事件 populate 逻辑、
  iteration 主循环等留在 run() 内（涉及 outcome.error 等闭包变量，
  提取代价高）
- **TypedDict 给 `sampling_per_server`**：严格 key 检查已经暴露
  typo；TypedDict 留 7c.x.5+

**关键不变量**：

- `TestCase` / `Observation` / `JudgeRouter` / `LLMJudge._SYSTEM` 零改动
- `AgentResponse` / `server_events` payload schema 零改动
- 既有 44 case + 1704 tests 全部稳态
- 测试 +3（仅 helper 单测；end-to-end 行为不变间接覆盖 helpers）
- adapter / cli / runner / report.py / case.py / fixture.py 零改动
- production 路径（adapter 构造 dict）零行为差异 — adapter 永远构造
  良形 dict，strict key 不会触发

## 3. 架构总览

```
src/agentsec/mcp_harness/
├── case.py                          ← 不动
├── claude_client.py                 ← + _resolve_sampling_per_server helper
│                                      + _probe_server_capabilities async helper
│                                      + _rebuild_tools_spec async helper
│                                      run() 改用 helpers + gather
│                                      _build_message_handler docstring 加反向 ref
├── adversarial_server.py            ← 不动
├── adapter.py / runner.py           ← 不动
├── report.py / findings.py          ← 不动
└── fixture.py                       ← 不动

tests/mcp_harness/test_claude_client.py   ← + 3 helper 单测
mcp_real_suites/                          ← 不动（无新 case）
tests/integration/test_mcp_real_live.py   ← 不动
scripts/check_mcp_real_*.py               ← 不动
```

**关键实现点**：

1. **`_resolve_sampling_per_server`**（同步纯函数）：

   ```python
   def _resolve_sampling_per_server(
       servers: list[Server],
       sampling_per_server: dict[str, dict[str, Any]] | None,
       sampling_policy: str,
       sampling_response: str | None,
   ) -> dict[str, dict[str, Any]]:
       """Build per-server sampling config. Strict on `policy` key
       (KeyError on typo); `response` defaults to None.

       7c.x.4: replaces `cfg.get("policy", "deny")` silent default —
       typos surface as KeyError at run() entry rather than silently
       denying.
       """
       effective: dict[str, dict[str, Any]] = {}
       for srv in servers:
           if (
               sampling_per_server is not None
               and srv.name in sampling_per_server
           ):
               cfg = sampling_per_server[srv.name]
               effective[srv.name] = {
                   "policy": cfg["policy"],
                   "response": cfg.get("response"),
               }
           else:
               effective[srv.name] = {
                   "policy": sampling_policy,
                   "response": sampling_response,
               }
       return effective
   ```

2. **`_probe_server_capabilities`**（async）：

   ```python
   async def _probe_server_capabilities(
       sessions: list[tuple[str, Any]],
   ) -> dict[str, dict[str, bool]]:
       """Concurrently probe each session for resources/prompts
       capability. Per-probe try/except "Method not found" stays
       inside `_server_has_resources` / `_server_has_prompts` —
       falsy result on unavailability, no propagation.
       """
       probes = []
       for _, sess in sessions:
           probes.append(_server_has_resources(sess))
           probes.append(_server_has_prompts(sess))
       results = await asyncio.gather(*probes)
       capabilities: dict[str, dict[str, bool]] = {}
       for i, (srv_name, _sess) in enumerate(sessions):
           capabilities[srv_name] = {
               "resources": results[i * 2],
               "prompts": results[i * 2 + 1],
           }
       return capabilities
   ```

3. **`_rebuild_tools_spec`**（async）：

   ```python
   async def _rebuild_tools_spec(
       sessions: list[tuple[str, Any]],
       server_capabilities: dict[str, dict[str, bool]],
       add_prefix: bool,
   ) -> tuple[list[dict[str, Any]], dict[str, list[str]]]:
       """Concurrently re-fetch list_tools from every session and
       rebuild the full tools_spec with `<server>__<tool>` prefix
       (when add_prefix is True) plus per-server synthetic
       resource/prompt tool registration via _prefixed_synthetic_tools.

       Returns (new_tools_spec, refreshed_by_server). The latter maps
       each server name to the sorted bare tool-name list — used by
       the dirty re-fetch block to populate `new_tool_names` on the
       corresponding `list_changed` server_events entries.

       Used at BOTH initial run() setup and the dirty re-fetch block —
       single canonical implementation.

       7c.x.4: concurrent via `asyncio.gather(return_exceptions=True)`.
       "Method not found" per session is silently skipped (matches the
       previous per-session try/except path). Other exceptions are
       re-raised and caught by run()'s top-level handler.
       """
       refresh_results = await asyncio.gather(
           *[sess.list_tools() for _, sess in sessions],
           return_exceptions=True,
       )
       new_tools_spec: list[dict[str, Any]] = []
       refreshed_by_server: dict[str, list[str]] = {}
       for (srv_name, _sess), refresh in zip(
           sessions, refresh_results, strict=True
       ):
           if isinstance(refresh, BaseException):
               if "Method not found" in str(refresh):
                   refreshed_by_server[srv_name] = []
                   continue
               raise refresh
           refreshed_by_server[srv_name] = sorted(
               t.name for t in refresh.tools
           )
           for t in refresh.tools:
               tool_name = (
                   f"{srv_name}__{t.name}" if add_prefix else t.name
               )
               new_tools_spec.append({
                   "name": tool_name,
                   "description": t.description or "",
                   "input_schema": t.inputSchema,
               })
           caps = server_capabilities[srv_name]
           if caps["resources"]:
               new_tools_spec.extend(
                   _prefixed_synthetic_tools(
                       _SYNTHETIC_RESOURCE_TOOLS, srv_name
                   )
                   if add_prefix
                   else _SYNTHETIC_RESOURCE_TOOLS
               )
           if caps["prompts"]:
               new_tools_spec.extend(
                   _prefixed_synthetic_tools(
                       _SYNTHETIC_PROMPT_TOOLS, srv_name
                   )
                   if add_prefix
                   else _SYNTHETIC_PROMPT_TOOLS
               )
       return new_tools_spec, refreshed_by_server
   ```

4. **`run()` 改用 helpers**：

   ```python
   # 替换原 ~14 行 effective_per_server 内联块：
   effective_per_server = _resolve_sampling_per_server(
       servers, sampling_per_server, sampling_policy, sampling_response,
   )

   # ... AsyncExitStack 内 sessions 已就绪后：
   server_capabilities = await _probe_server_capabilities(sessions)
   tools_spec, _ = await _rebuild_tools_spec(
       sessions, server_capabilities, add_prefix,
   )

   # ... dirty re-fetch 块改用 helper：
   if dirty[0]:
       dirty[0] = False
       triggered_servers = sorted(dirty_servers)
       dirty_servers.clear()
       try:
           tools_spec, refreshed_by_server = await _rebuild_tools_spec(
               sessions, server_capabilities, add_prefix,
           )
           for srv_name in triggered_servers:
               for evt in reversed(outcome.server_events):
                   if (
                       evt.get("kind") == "list_changed"
                       and evt.get("server") == srv_name
                       and evt.get("new_tool_names") == []
                   ):
                       evt["new_tool_names"] = (
                           refreshed_by_server[srv_name]
                       )
                       break
       except Exception as exc:  # noqa: BLE001
           outcome.error = f"tools_relist_failed: {exc}"
   ```

5. **`_build_message_handler` docstring 加反向 cross-ref**：

   ```python
   def _build_message_handler(...):
       """...

       Parallel to `_build_sampling_callback` (7c.x.3): both factories
       take `server_name` and build per-session closures.
       """
   ```

## 4. 错误处理

继承既有 catch-all 行为。新增：

| 场景 | 处理 |
|---|---|
| `gather(...)` 中某 session `list_tools` 抛非 "Method not found" 异常 | `return_exceptions=True` 收集；遍历时 `isinstance(refresh, BaseException)` → if "Method not found" 跳过；else `raise refresh` → `run()` 顶层兜底 |
| `gather(...)` 中某 probe 抛异常 | probe 函数自身已 try/except「Method not found」→ False；其它异常会从 gather raise → `run()` 顶层兜底 |
| `_rebuild_tools_spec` 整体抛 Exception（dirty re-fetch 期间） | 既有 `try/except Exception` 包裹 → `outcome.error = "tools_relist_failed: <exc>"`，旧 `tools_spec` 保留 |
| `_resolve_sampling_per_server` 缺 `"policy"` key | **新行为**：raise `KeyError("policy")`；run() 入口顶层 `except Exception` 接收 → `outcome.error = "KeyError: 'policy'"`。Production 永远不触发 |
| `_resolve_sampling_per_server` 未知 key（typo `polciy`） | 不主动检测；缺 `"policy"` 时 KeyError 暴露 |
| `sampling_per_server={}` 全空 dict | 所有 server fallback 到 scalar（既有路径） |
| `gather` 顺序保证 | Python 文档明确：返回 list 按入参顺序对齐；`zip(sessions, refresh_results, strict=True)` 按 sessions 顺序遍历 |

**新增运行时不变量**：

- `gather(return_exceptions=True)` 后每条结果 ∈ `{ListToolsResult, BaseException}`
- `_probe_server_capabilities` 返回 dict keys 覆盖 `[name for name, _ in sessions]`
- `_resolve_sampling_per_server` 返回 dict keys 覆盖 `[s.name for s in servers]`
- `_rebuild_tools_spec` 返回的 `refreshed_by_server` keys 覆盖 `[name for name, _ in sessions]`
- 并发 gather 完成后 tools_spec 元素顺序与 sessions 顺序一致（顺序版完全相同行为）

## 5. 测试策略

**单测**（新增 3 条）：

- `test_resolve_sampling_per_server_dict_overrides_scalar`：dict 提供
  server A 配置 + scalar 默认；结果 A 用 dict、B（不在 dict）用 scalar
- `test_resolve_sampling_per_server_falls_back_to_scalar`：dict=None；
  所有 server 用 scalar
- `test_resolve_sampling_per_server_strict_missing_policy_key_raises`：
  dict[server] 缺 `"policy"` key（典型 typo）；调用 raise `KeyError`

`_rebuild_tools_spec` / `_probe_server_capabilities` 通过既有 ~50 个
end-to-end 测试间接覆盖（multi-server prefix / dirty re-fetch /
single-server resources/prompts probe / sampling per-session 等）。
helper 提取 = 行为不变；若改坏，多个测试同时挂。

**集成测**：不动。

**CI 闸**：不动。

**报告 / 序列化**：零改动。

**LOC 估算**：`run()` 缩 ~50 行（~359 → ~310）；新增 helpers ~100 行；
净增 ~50 行但拆分清晰。

## 6. 兼容性与迁移

- 既有 44 个 case：加载行为不变
- `AgentResponse` schema：无改动
- `ClaudeMcpClient.run()` 接口：未变（仅内部重构）
- adapter / cli / runner / report.py 等接口：未变
- direct test caller `client.run(..., sampling_policy="stub", sampling_response="X")`：scalar fallback 路径保留，行为字节兼容
- adapter→run() 调用：dict 良形，strict key 检查不会触发

## 7. 决策摘要

| 决策点 | 选择 | 理由 |
|---|---|---|
| Re-fetch 策略 | α + gather（保留 α） | β splice 增加 slice 维护代价；in-memory streams perf 收益有限；α 语义最直白 |
| `gather` exception 模式 | `return_exceptions=True` | 保留 per-session 「Method not found」静默；其它异常 re-raise 走顶层 |
| Helper 提取粒度 | `_resolve_sampling_per_server` + `_rebuild_tools_spec` + `_probe_server_capabilities`（3 个） | 三段是 run() 中可清晰隔离的 stateless 子任务；event populate 逻辑闭包变量多，留在 run() 内 |
| `sampling_per_server` 严格 key | strict `cfg["policy"]` | 现状 `.get("policy", "deny")` silent default 掩盖 typo；strict 暴露问题；production 永远良形 |
| `_response` key | 仍 `.get("response")` | None 是合法值（deny policy 不需 response），不应 strict |
| 单测策略 | 仅 3 条 helper 单测 + 间接 end-to-end | YAGNI；既有 50+ 测试覆盖 helpers 路径 |
| TypedDict | 不引入 | strict key 检查已够暴露 typo；TypedDict 留 7c.x.5+ |
| β splice | 不做 | 留给真有性能 pain 的未来 phase |
| `_build_message_handler` docstring | 加反向 cross-ref | 与 `_build_sampling_callback` 对称提醒；零功能 |

## 8. 后续阶段路线

| 阶段 | 范围 | 依赖 |
|---|---|---|
| **7c.x.4 (本期)** | gather + helper 提取 + strict key + docstring | 7c.x.3 |
| 7c.x.5 (可选) | β splice / TypedDict `sampling_per_server` / `run()` 进一步拆分 | 7c.x.4 + 真有性能 pain |
| 7c.1 | `mcp_supplements.yaml` 深度变体 | 任何 7c.* 之后 |
| 7c.7 | stdio / SSE 真实传输层 | 与 BYOA agent adapter 协议捆绑 |

## 9. References

- Phase 7c.x.3 spec — `docs/superpowers/specs/2026-05-15-phase-7cx3-multi-server-sampling-design.md`
- Phase 7c.x.2 spec — `docs/superpowers/specs/2026-05-15-phase-7cx2-multi-server-mutations-design.md`
- Phase 7c.x.1 spec — `docs/superpowers/specs/2026-05-15-phase-7cx1-multi-server-resources-prompts-design.md`
- ADR-0001 — Adapter pattern for target agents
- ADR-0002 — LLM-as-judge evaluation
- Python `asyncio.gather` docs — return order matches input order;
  `return_exceptions=True` collects per-task exceptions
