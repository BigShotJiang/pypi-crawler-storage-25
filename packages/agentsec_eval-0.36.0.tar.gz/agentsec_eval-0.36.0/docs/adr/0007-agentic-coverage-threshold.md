# ADR-0007: OWASP Agentic 覆盖门槛（每威胁 ≥ 3 case）

**状态**: 已采纳
**日期**: 2026-05-08
**参与者**: roger

## 背景

Phase 7a（ADR-0006）把 `owasp_refs` 字段落到 `TestCase` 上，并在 CI 闸住
「LLM Top 10 任一分类 0 case」回归。门槛是 ≥ 1，是「能拿到外宣
入口」的最低标准。

进入 Phase 7b 后，OWASP Agentic AI Threats v1.1（T1–T17）需要全量
覆盖。如果直接照搬 ≥ 1 门槛，单条弱 case 即可"覆盖"一类威胁，
易被人绕过 —— 比如某 Agentic 类别只放一个 prompt 就声称覆盖。

## 决策

- **OWASP Agentic 17 类的 CI 门槛设为 ≥ 3 case**。
- LLM Top 10 暂保留 ≥ 1 门槛（Phase 7a 落地时确定）；后续可在
  Phase 7d 之前并轨升到 ≥ 3，但不在本 phase 范围。

## 理由

- 每类 ≥ 3 强制至少 3 种攻击向量，避免「单一弱 case 充数」。
- 与 Agentic 威胁本身的描述深度匹配（v1.1 PDF 给每个威胁列出多个
  攻击场景，3 个 case 才能体现）。
- 24 条新 case（5 个全缺类 × 3 + 5 个薄类各补到 3 = 9）成本可控。

## 备选方案

1. **统一 ≥ 1 门槛**：与 LLM Top 10 对齐。*放弃理由*：太松，
   外宣"Agentic 全覆盖"的可信度低。
2. **统一 ≥ 5**：更严。*放弃理由*：对 T13/T14（多 agent 系统
   攻击）这种相对小众的威胁要求 5 个差异化 case，性价比低。
3. **不分 Agentic / LLM 用同一门槛**：比如全部 ≥ 3。*放弃理由*：
   LLM Top 10 现状是 5–60+ 不等，统一 ≥ 3 不会拦下任何回归，
   等于没改；分别设阈是更精准的选择。

## 后果

- `scripts/check_owasp_coverage.py` 必须扩展为「LLM Top 10 ≥ 1 +
  Agentic 17 ≥ 3」两道独立闸。
- 新增 6 个 YAML 文件、24 条 case 才能绿过 CI。
- 后续添加 Agentic case 时不能仅依赖 LLM Top 10 门槛兜底，必须
  各类自检。
