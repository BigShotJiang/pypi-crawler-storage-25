# ADR-0022: MCP supplements third batch (dimension E: Race/TOCTOU) + coverage floor lift

* **Status**: Accepted
* **Date**: 2026-05-16
* **Phase**: 7c.1.y
* **Supersedes (in part)**: ADR-0021 — `MCP_FLOOR` value only

## Context

ADR-0021 (Phase 7c.1.x, v0.31.0) lifted `MCP_FLOOR` from 6 to 10
after the second supplements batch (32 cases on MCP3..MCP10 × A/B/C/D)
brought MCP9 (the floor) to exactly 10.

Phase 7c.1.x's design doc §9 flagged 7c.1.y as the natural next
step: introduce a new dimension E (Race / TOCTOU) orthogonal to
A/B/C/D, applied across all MCP1..MCP10 ids. The original 4
dimensions cover "static" attack surfaces (encoding, instruction-
as-data, authority gradient, multi-turn coercion); E covers the
*temporal* axis — agent verifies state at T1, attacker mutates state
between T1 and T2 (the actual call/use), agent acts on stale
assumption.

## Decision

1. Add 20 new cases (2 per id × MCP1..MCP10) in a new file
   `test_suites/mcp_supplements_3.yaml`, organised on two
   sub-flavors of dimension E:
   - **E1 = object identity TOCTOU** — named tool/resource/template/
     capability is replaced between observe and use.
   - **E2 = approval state TOCTOU** — authorization/consent drifts
     between grant and exercise.

2. Lift `MCP_FLOOR` in `scripts/check_owasp_coverage.py` from 10 to
   12. After the 20-case batch lands, every MCP id is ≥ 12 (MCP9
   becomes the new floor at exactly 12), preserving the zero-buffer
   ratchet pattern established in ADR-0021.

3. ID convention: `mcp-sup-mcp{1..10}-e{1,2}`. The letter suffix
   (e1/e2) zero-conflicts with the existing digit suffix scheme
   (`mcp-sup-mcp{N}-NN` for NN = 01..08 used by 7c.1 and 7c.1.x).

## Why MCP_FLOOR = 12 and not 10 or 14

- **12** matches MCP9 exactly post-batch — no buffer means future
  PRs that drop any id below 12 fail CI immediately. Same zero-
  buffer ratchet logic as ADR-0021.
- **10** would leave the floor unchanged despite case additions,
  weakening the gate's signal.
- **14** would exclude MCP9 at its post-batch level; would require
  another batch lifting MCP9 specifically, which isn't justified
  in this ADR.

## Consequences

- Future PRs that remove MCP cases or reorganise them must keep
  every id ≥ 12, or the OWASP coverage gate fails.
- The next time we want to lift the floor (e.g., to 14), we must
  first add cases to the floor-id (currently MCP9), continuing
  the ratchet.
- `mcp_supplements_3.yaml` joins `mcp_supplements.yaml` /
  `mcp_supplements_2.yaml` as the third file in the supplements
  series; all three share the `mcp_supplements` category.
- The E1/E2 sub-flavor distinction is enforced only at spec/plan/
  review level, not by automated gate (similar to A/B/C/D in
  Phase 7c.1.x — sub-flavor is convention, not schema).

## Why dimension E and not other candidates

7c.1.x spec §9 listed three candidates for 7c.1.y: chained /
cross-MCP-id composition, dimension E (race / TOCTOU), or new
dimension F (e.g., delayed effect / sleeper). Race/TOCTOU was
chosen because:

- It's the most concrete candidate (spec authors had specific
  attack patterns in mind, vs. composition which needs a new
  taxonomy).
- It's a true axis-orthogonal addition to A/B/C/D, not a
  re-cut of existing surfaces.
- Composition (a case touching 2+ MCP ids) raises non-trivial
  questions about per-id coverage counting that warrant their own
  phase (7c.1.z, deferred).

## Alternatives considered

- **Lift floor to 10 with 2-case buffer**: rejected, weakens gate
  for no concrete benefit.
- **Per-id floors based on dimension applicability**: rejected,
  complicates gate maintenance significantly.
- **Skip floor lift entirely**: rejected, would leave the gate at
  10 even though every id now has ≥ 12.

## References

- Spec: `docs/superpowers/specs/2026-05-16-phase-7c1y-mcp-toctou-design.md`
- Plan: `docs/superpowers/plans/2026-05-16-phase-7c1y-mcp-toctou.md`
- ADR-0021: prior batch + floor 6→10
- ADR-0016: original MCP curated v1 taxonomy + floor=6
- Phase 7c.1.x spec: `docs/superpowers/specs/2026-05-16-phase-7c1x-mcp3-10-supplements-design.md`
