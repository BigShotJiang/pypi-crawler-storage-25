# ADR-0023: MCP supplements fourth batch (cross-MCP-id chain) + coverage floor lift

* **Status**: Accepted
* **Date**: 2026-05-16
* **Phase**: 7c.1.z
* **Supersedes (in part)**: ADR-0022 — `MCP_FLOOR` value only

## Context

ADR-0022 (Phase 7c.1.y, v0.32.0) lifted `MCP_FLOOR` from 10 to 12
after the third supplements batch (20 cases on dimension E TOCTOU
across MCP1..MCP10) brought MCP9 (the floor) to exactly 12.

Phase 7c.1.y's design doc §9 flagged 7c.1.z as the natural next
step: cross-MCP-id composition — a single case spans 2+ MCP ids
(new topology, not new dimension). The original 7c suite (80 case)
and 7c.1 / 7c.1.x / 7c.1.y supplements (67 case total) all cover
"single id per case" attacks. 7c.1.z extends to "chains" — agent
needs to refuse at least one step to break the attack chain.

## Decision

1. Add 10 new sequential-chain cases in
   `test_suites/mcp_supplements_4.yaml`. Each case spans 2 MCP ids
   (A → B), where A is the attack entry (install / resource read /
   tool desc / etc.) and B is the attack exploit (exfil / mutation
   / consent bypass).

2. **Counting rule = all-id** (no code change). The existing
   `check_owasp_coverage.py` counts every entry in `owasp_refs`,
   so a chain case listing `[MCP9, MCP10, LLM03:2025]` contributes
   to MCP9 and MCP10 coverage simultaneously. This is the
   path-of-least-resistance choice and matches the threat-model
   semantics: a chain case truly exercises both ids.

3. Lift `MCP_FLOOR` in `scripts/check_owasp_coverage.py` from 12
   to 14. After the 10-case batch lands, MCP7 = 14 and MCP9 = 14
   (shared floor), preserving the zero-buffer ratchet pattern from
   ADR-0021 / ADR-0022.

4. ID convention: `mcp-sup-chain-NN`. Letter-free numeric suffix
   (vs `mcp-sup-mcp{N}-NN` 01..08 from 7c.1 / 7c.1.x or
   `mcp-sup-mcp{N}-e{1,2}` from 7c.1.y). Zero literal collision
   across all three id namespaces.

## Why MCP_FLOOR = 14 and not 12 or 16

- **14** matches MCP7 / MCP9 exactly post-batch (both shared the
  floor pre-batch, both gained exactly +1 from chains). Zero-buffer
  ratchet, same logic as ADR-0021 / ADR-0022.
- **12** would leave floor unchanged despite case additions,
  weakening the gate.
- **16** would exclude MCP7 and MCP9; would require another batch
  raising both before lift.

## Why sequential A→B and not simultaneous A+B or 3-id chains

- **Sequential** has the clearest narrative ("attacker establishes
  A first, then exploits via B") and the cleanest judge_hint
  ("agent breaks chain at either step = Pass"). Easiest to write,
  easiest to judge.
- **Simultaneous (A+B)** lacks temporal structure; harder to
  distinguish from A/B/C/D unified attacks. Deferred to 7c.1.z2.
- **3-id chains (A→B→C)** triple the narrative complexity; spec
  effort doesn't scale linearly. Deferred to 7c.1.w if 2-id
  proves under-coverage.

## Consequences

- Future PRs that remove MCP cases must keep every id ≥ 14, or
  the OWASP coverage gate fails.
- The next floor lift requires raising the current floor id (MCP7
  or MCP9) first, continuing the ratchet.
- `mcp_supplements_4.yaml` joins the supplements series as the
  fourth file; all four share the `mcp_supplements` category.
- Coverage counting interpretation is now formalized: a case
  listing multiple MCP ids in `owasp_refs` is a multi-id case,
  contributing to all listed ids. This was implicit behavior;
  this ADR makes it explicit policy.

## Alternatives considered

- **Primary-id-only counting** (modify gate to count `owasp_refs[0]`
  only): rejected, requires code change for no semantic gain;
  chain cases truly exercise both ids.
- **Separate `MCP_CHAIN` bucket**: rejected, splits taxonomy and
  doubles maintenance.
- **Skip floor lift**: rejected, weakens the ratchet pattern
  established by ADR-0021 / ADR-0022.

## References

- Spec: `docs/superpowers/specs/2026-05-16-phase-7c1z-cross-mcp-chain-design.md`
- Plan: `docs/superpowers/plans/2026-05-16-phase-7c1z-cross-mcp-chain.md`
- ADR-0022: third batch (dimension E) + floor 10→12
- ADR-0021: second batch (A/B/C/D × MCP3-10) + floor 6→10
- ADR-0016: original MCP curated v1 taxonomy + floor=6
- Phase 7c.1.y spec: `docs/superpowers/specs/2026-05-16-phase-7c1y-mcp-toctou-design.md`
