# ADR-0001: 使用 Adapter 模式对接目标 Agent

**状态**: 已采纳  
**日期**: 2026-04-24  
**参与者**: Roger

## 背景

AgentSec 需要对多个不同的 Agent 做安全评估（OpenClaw、Hermes 等），这些 Agent 的接口形式各不相同：有的暴露 HTTP REST API，有的通过 SDK 调用，有的通过 CLI 交互。评估框架需要在不修改核心逻辑的情况下支持新目标。

## 决策

定义 `AgentAdapter` 抽象基类，约定 `send(message, session_id) → AgentResponse` 接口。每个目标 Agent 实现一个独立的 Adapter 文件放在 `src/agentsec/adapters/`。

## 理由

- 测试用例、评判逻辑、报告生成与具体 Agent 接口完全解耦
- 新增目标 Agent 只需新增一个文件，不改动核心代码
- `session_id` 由 runner 生成并传入，Adapter 无需管理会话状态

## 备选方案

**配置驱动（纯 YAML 配置接口）**: 灵活性低，无法处理需要自定义认证、签名或多步握手的 Agent。

**插件系统（动态加载）**: 过度设计，当前规模不需要。

## 后果

- 每个新目标 Agent 都需要写 Adapter 代码（而不是只写配置），但这换来了完整的灵活性
- `HttpAgentAdapter` 提供了覆盖 `_build_request` / `_parse_response` 的扩展点，减少大多数 HTTP Agent 的重复代码
