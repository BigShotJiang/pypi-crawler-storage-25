# ADR-0024: Phase 7d.4 — Java/Maven supply chain audit

* **Status**: Accepted
* **Date**: 2026-05-16
* **Phase**: 7d.4

## Context

7d series (npm / pip / go / rust/cargo) shipped 4 OSV-backed supply
chain Checks. Java/Maven is the largest enterprise Java ecosystem
and a natural 5th addition.

Maven differs from the prior 4 in two material ways:

1. **No native lockfile**. pom.xml is declarative with version
   ranges and unresolved transitive deps. Treating pom.xml as the
   audit input would miss CVEs in transitively-resolved deps and
   misreport ranges.

2. **Maven version semantics aren't semver**. Apache
   `ComparableVersion` defines its own qualifier rank table
   (alpha < beta < milestone < rc < snapshot < "" < sp < unknown)
   plus implicit sub-list nesting at digit↔alpha transitions. Prior
   ecosystems used `packaging.version` (pip) or `semver` (go/rust);
   Maven needs its own comparator.

## Decision

1. **Operator pre-runs `mvn dependency:list -DoutputFile=mvn-deps.txt`**.
   We parse the resulting flat-list text format, mirroring the pip
   approach where the operator pre-freezes requirements.

2. **Hand-write Apache `ComparableVersion` semantics** in
   `_supply_chain_common.py` (~100 LOC). Zero new dependencies. Full
   coverage of the qualifier rank table, alpha shorthand expansion
   (`1.0a1 == 1.0-alpha-1`), and trailing-zero normalization.

3. **Mirror 7d.3 (rust/cargo) for everything else**: `OsvMavenFetcher`
   pulling `https://osv-vulnerabilities.storage.googleapis.com/Maven/all.zip`,
   5-axis filter chain, multi-affected expansion, dedup on
   (id, package), bundled `osv_maven.json` DB, `TI-OSV-MAVEN-CATALOG`
   umbrella TI, CI guard at 15 MB cap.

## Why pre-run `mvn dependency:list` and not parse pom.xml

- pom.xml gives declared deps only; misses transitive (where most
  CVEs hide).
- pom.xml versions can be ranges (`[1.0,2.0)`); resolving them
  requires running Maven anyway.
- `dependency:list` output is a flat resolved tree, the moral
  equivalent of `package-lock.json` / `Cargo.lock`.

## Why hand-written ComparableVersion and not a third-party library

- Existing Python Maven version libraries (`pymaven-patch`, etc.)
  are unmaintained.
- Apache ComparableVersion algorithm is well-documented and stable.
- ~100 LOC, fully testable, zero supply-chain risk to ourselves.

## Why scope filter includes test

- A malicious test dependency can run during `mvn test` in CI,
  exfiltrate secrets / inject artifacts. Test deps are a real
  attack surface, not just compile/runtime.
- Operator who wants to suppress test findings can run
  `dependency:list -DexcludeScope=test` upstream.

## Consequences

- New Check (`java_supply_chain_audit`); total Checks 35 → **36**.
- New bundled DB (`osv_maven.json`, ~1.6 MB after filtering).
- Future Maven CVE refresh = re-run `agentsec ioc-update` and
  re-commit `osv_maven.json`.
- Gradle support deferred to 7d.4.1 (different file tree:
  build.gradle / build.gradle.kts / gradle.lockfile).

## Alternatives considered

- **Run `mvn` ourselves via SSH**: rejected. Adds Maven to the
  trusted-binary surface; security gate would have to allow `mvn`
  with arbitrary args; resource-intensive.
- **Use `pymaven-patch` for version comparison**: rejected, dep is
  unmaintained.
- **Strict semver for Maven**: rejected, would mis-classify SNAPSHOT
  / sp1 / alpha-N versions and miss CVEs.

## References

- Spec: `docs/superpowers/specs/2026-05-16-phase-7d4-java-maven-supply-chain-design.md`
- Plan: `docs/superpowers/plans/2026-05-16-phase-7d4-java-maven-supply-chain.md`
- ADR-0012: Phase 7d npm
- ADR-0013: Phase 7d.1 pip
- ADR-0014: Phase 7d.2 go
- ADR-0015: Phase 7d.3 rust/cargo
- Apache ComparableVersion docs: https://maven.apache.org/ref/3.6.3/maven-artifact/apidocs/org/apache/maven/artifact/versioning/ComparableVersion.html
