# ADR-0020 — Phase 7f.x cleanup (make_finding migration + TI rename)

**Date:** 2026-05-13
**Status:** Accepted

## Context

After 7f / 7f.1 / 7f.1.1, two pieces of accumulated technical debt
warranted a dedicated cleanup phase:

1. **Mixed `Finding(...)` vs `make_finding(ctx, ...)` writing styles.**
   `Check.make_finding` was added in Stage D after the original 7f
   Docker Checks shipped. 7f.1 (podman / containerd Checks) and 7f.1.1
   (containerd_daemon) standardized on the helper. The 3 original 7f
   Docker Checks (`docker_daemon_audit`, `docker_runtime_audit`,
   `docker_image_cve`) still used direct `Finding(...)` construction
   and did NOT pass evidence through the global Redactor. Any future
   provider-token pattern added to `Redactor` would silently fail to
   cover those three Checks.

2. **`TI-DOCKER-IMAGE-*` namespace asymmetry.** image_patterns TIs are
   shared across runtimes (image content is runtime-agnostic — alpine
   3.18 is the same image whether pulled by docker, podman, or
   containerd). 7f.1 noted but deferred the resulting awkward shape:
   a finding with `evidence.runtime == "podman"` references a
   `TI-DOCKER-IMAGE-*` id. Fix: rename to `TI-CONTAINER-IMAGE-*`.

## Decision

1. **Migrate all 3 7f Docker Checks to `self.make_finding(ctx, ...)`.**
   Per-Check incremental commits. Each Check's `_emit` helper takes
   `ctx` as first positional arg; `_evaluate_container` (runtime) is
   threaded the same. Test fixtures change `redactor=None` →
   `redactor=Redactor()` so the new code path has something to invoke.
   No evidence-schema or threat_refs changes. Pure plumbing.

2. **Hard-rename `TI-DOCKER-IMAGE-*` → `TI-CONTAINER-IMAGE-*`.** 8 TI
   ids in `threat_intel.yaml`, 10 `threat_refs` entries in
   `container_baseline.yaml` (NODE-EOL and ALPINE-OLD patterns each
   referenced twice), 1 prefix constant in
   `_docker_common._image_ti_prefix`. No alias mechanism — keeping
   aliases would mean an `aliased_to` field on `threat_intel.yaml`,
   bidirectional resolution in `check_threat_refs.py`, and a
   forever-debt dragging future renames along. v0.x range still
   tolerates breaking changes; CHANGELOG marks this clearly.

3. **`daemon_*` / `runtime` TI namespaces NOT renamed.** Findings
   emitted by those rules are runtime-specific (docker's
   `userns-remap` config knob has no podman equivalent;
   `--privileged` semantics differ). `TI-DOCKER-DAEMON-*`,
   `TI-PODMAN-DAEMON-*`, `TI-CONTAINERD-DAEMON-*`, and the three
   `TI-{DOCKER,PODMAN,CONTAINERD}-RUNTIME-*` namespaces stay.

## Alternatives considered

- **Alias mechanism.** Rejected. Doubles `threat_intel.yaml` entry
  count for image-pattern TIs, complicates `check_threat_refs.py`,
  and turns rename into a sunk-cost forever-debt rather than a
  one-time cost. Hard breaks are cheaper in v0.x.
- **Rename everything to `TI-CONTAINER-*`.** Rejected. Conflates
  runtime-specific findings (which carry useful provenance) with
  runtime-agnostic ones (image content).
- **Migrate `docker_image_cve` to share `_evaluate_image_tag` helper.**
  Rejected. Would drop `evidence.container_id` / `names` fields
  (helper produces only `runtime` / `image` / `pattern_matched`) —
  observability regression. Out of scope.

## Consequences

- Server-audit Check inventory unchanged (still 35 categories).
- Wire-format breaking change: external consumers reading
  `threat_refs` from `findings.json` and matching on
  `TI-DOCKER-IMAGE-*` need to migrate. Documented in CHANGELOG
  v0.20.0 "Breaking" section.
- All 8 docker Checks (`docker_*`, `podman_*`, `containerd_*`,
  `containerd_daemon_audit`) now emit Redactor-cleaned findings
  uniformly.
- Release v0.19.0 → **v0.20.0** (minor bump per 0.x SemVer convention
  for breaking changes).

## References

- Spec: `docs/superpowers/specs/2026-05-13-phase-7fx-cleanup-design.md`
- Plan: `docs/superpowers/plans/2026-05-13-phase-7fx-cleanup.md`
- 7f.1 ADR: `docs/adr/0018-phase-7f1-podman-containerd-audit.md`
- 7f.1.1 ADR: `docs/adr/0019-containerd-daemon-audit.md`
