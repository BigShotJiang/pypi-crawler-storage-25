# ADR-0019 — containerd_daemon_audit (Phase 7f.1.1)

**Date:** 2026-05-13
**Status:** Accepted

## Context

Phase 7f.1 (v0.18.0) shipped podman + containerd runtime/image audits
but deferred `containerd_daemon_audit` to a follow-up phase. The
7f.1 spec recorded the deferral with the justification
"config.toml 安全 knob 少".

Phase 7f.1.1 re-evaluated the daemon config surface. Six concrete
security knobs were identified:

- `[grpc].tcp_address` — TCP API exposure (critical)
- `[debug].address` — debug socket TCP / world-writable Unix sock (high)
- `[metrics].address` — Prometheus endpoint on public interface (medium)
- `[plugins."io.containerd.grpc.v1.cri"].disable_apparmor` — MAC bypass (high)
- `[plugins."io.containerd.grpc.v1.cri".containerd].no_pivot` — chroot fallback (medium)
- containerd version → known CVE range (high)

Each is observed in production misconfigurations and not adequately
covered by adjacent Checks (containerd_runtime_audit is per-container;
docker_daemon_audit doesn't fire on containerd-only hosts).

## Decision

1. **Reverse the 7f.1 deferral.** Add `containerd_daemon_audit` Check
   with 6 rules. Severity distribution: 1 critical / 3 high / 2 medium.
   The "critical" tier is reserved for network-remote exploitability
   (TCP API), matching the docker/podman daemon convention.

2. **Three-tier config-absence semantics.**
   - Config absent (ENOENT): emit 1 info finding; continue with
     `version-cve` rule using `containerd --version` output.
   - Permission denied: `skipped` with NOPASSWD-sudoers remediation hint
     (same model as firewall_audit and the 7f docker daemon Check).
   - TOML parse failure: `skipped` (no remediation hint — operator
     needs to inspect their config).

3. **Cross-runtime yield via shared helper.** Extract
   `_docker_takeover_active(ctx)` to `_docker_common.py`. The 7f.1
   `containerd_runtime_audit` and `containerd_image_cve` Checks already
   duplicated this expression; the third user (`containerd_daemon_audit`)
   was the trigger to consolidate.

4. **TI namespace.** New TI entries follow `TI-CONTAINERD-DAEMON-*`,
   parallel to `TI-DOCKER-DAEMON-*` and `TI-PODMAN-DAEMON-*`.

5. **`known_bad_versions` dual-branch.** First-period values
   `["<1.6.28", "<1.7.11"]` cover both 1.6 LTS and 1.7 main fix windows
   for CVE-2024-21626 (runc chain). Auto-refresh via `ioc-update`
   is deferred to a future cycle.

## Alternatives considered

- **Minimum surface (TCP + version only).** Rejected — debug socket and
  CRI sub-config knobs are documented misconfigurations in containerd's
  own ops guide.
- **Full surface (registry mirrors, runtime classes, plugin enumeration).**
  Rejected — overlaps with Phase 7g (Kubernetes). Out-of-scope here.
- **Single `known_bad_versions: ["<1.7.11"]`.** Rejected — would falsely
  mark patched 1.6.x branch installations.

## Consequences

- Server-audit Check inventory: 34 → 35 categories.
- Release v0.19.0.
- 7f.1 ADR-0018 is unchanged but `CLAUDE.md` Phase 7f.1.1 section
  documents the deferral reversal.

## References

- Spec: `docs/superpowers/specs/2026-05-13-phase-7f1.1-containerd-daemon-audit-design.md`
- Plan: `docs/superpowers/plans/2026-05-13-phase-7f1.1-containerd-daemon-audit.md`
- 7f.1 ADR: `docs/adr/0018-podman-containerd-runtime-audit.md`
