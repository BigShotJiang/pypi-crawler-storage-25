# ADR-0021: MCP supplements second batch (32 cases) + coverage floor lift

* **Status**: Accepted
* **Date**: 2026-05-16
* **Phase**: 7c.1.x
* **Supersedes (in part)**: ADR-0016 — `MCP_FLOOR` value only

## Context

ADR-0016 (Phase 7c, v0.16.0) introduced the MCP curated v1 taxonomy
with a coverage floor of `MCP_FLOOR = 6` per threat id, calibrated to
the original 80-case suite where MCP9 (server supply chain) was the
weakest cell at exactly 6 cases.

Phase 7c.1 (v0.30.0) added 15 deeper-variant cases for the two most-
exercised vectors (MCP1 +8, MCP2 +7) but explicitly left MCP3..MCP10
untouched, deferring their deeper variants to Phase 7c.1.x as a
follow-on. After 7c.1, MCP9 remained the floor at 6.

## Decision

1. Add 32 new deeper-variant cases (4 per id × MCP3..MCP10) in a new
   file `test_suites/mcp_supplements_2.yaml`, organised on the same
   four-dimension grid (A encoding / B instruction-as-data / C
   authority gradient / D multi-turn coercion) introduced by Phase
   7c.1.

2. Lift `MCP_FLOOR` in `scripts/check_owasp_coverage.py` from 6 to
   10. After the 32-case batch lands, every MCP id is ≥ 10 (MCP9
   becomes the new floor at exactly 10), so 10 is the natural new
   floor with zero buffer.

3. The strict 4-per-id × 8-id grid is enforced by the NN convention:
   `mcp-sup-mcp{3..10}-NN` where `01=A`, `02=B`, `03=C`, `04=D`.

## Why MCP_FLOOR = 10 and not 8 or 12

- **10** matches MCP9 exactly post-batch — no buffer means future
  PRs that drop any id below 10 fail CI immediately. This is an
  intentional ratchet: lifting the floor forces case additions
  before relaxation.
- **8** would leave a 2-case buffer; useful if we expect to delete
  cases later, but supplements are additive and this would weaken
  the gate for no concrete need.
- **12** would exclude MCP9 at its post-batch level; raising MCP9
  to 12 would require a third batch, which we don't justify in this
  ADR.

## Consequences

- Future PRs that remove MCP cases or reorganise them must keep every
  id ≥ 10, or the OWASP coverage gate fails.
- The next time we want to lift the floor (e.g., to 12), we must
  first add cases to the floor-id (currently MCP9), restoring the
  ratchet pattern.
- `mcp_supplements_2.yaml` is paired conceptually with the original
  `mcp_supplements.yaml`; both share the `mcp_supplements` category
  and report-rendering treats them as one logical group.

## Alternatives considered

- **Lift floor to 8 with 2-case buffer**: rejected, weakens gate.
- **Per-id floors**: rejected, complicates gate maintenance.
- **Skip floor lift entirely**: rejected, would leave MCP9 at 10
  but allow future regressions back to 6 silently.

## References

- Spec: `docs/superpowers/specs/2026-05-16-phase-7c1x-mcp3-10-supplements-design.md`
- Plan: `docs/superpowers/plans/2026-05-16-phase-7c1x-mcp3-10-supplements.md`
- ADR-0016: original MCP curated v1 taxonomy + floor=6
- Phase 7c.1 spec: `docs/superpowers/specs/2026-05-15-phase-7c1-mcp-supplements-design.md`
