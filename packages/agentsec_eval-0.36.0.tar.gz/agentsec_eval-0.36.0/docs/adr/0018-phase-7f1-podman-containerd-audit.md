# ADR-0018: Phase 7f.1 Podman + Containerd Audit

**Status:** Accepted
**Date:** 2026-05-12
**Predecessors:** ADR-0017 (Phase 7e.3 firewalld); 7f Docker landed without
a standalone ADR (decisions in 7f spec).

## Context

`agentsec server-audit` Phase 7f (v0.10.0) shipped 3 Docker Check
classes — `docker_daemon_audit` / `docker_runtime_audit` /
`docker_image_cve` — covering Docker hosts on Ubuntu / Debian / RHEL.

But two big runtime ecosystems were uncovered:
1. **Podman**: RHEL / CentOS Stream / Fedora default; daemonless;
   incompatible config (`containers.conf` vs `daemon.json`).
2. **Containerd**: K8s standard backend; also the actual runtime under
   Docker. Standalone containerd hosts (non-Docker non-K8s) sit blind.

## Decision

Add 5 new Check classes:
- `PodmanDaemonAuditCheck` / `PodmanRuntimeAuditCheck` / `PodmanImageCveCheck`
- `ContainerdRuntimeAuditCheck` / `ContainerdImageCveCheck`
- **Skip** `containerd_daemon_audit` — config.toml has few security knobs
  (option B in spec); deferred to 7f.1.1 follow-up.

Key sub-decisions:

1. **containerd CLI strategy**: nerdctl optional; ctr fallback. nerdctl
   gives docker-CLI-compatible JSON; ctr gives JSON-shaped admin text
   with partial fidelity (4/7 runtime rules reachable).
2. **Cross-talk yield**: `ContainerdRuntimeAuditCheck` and
   `ContainerdImageCveCheck` go `not_applicable` if `detect_docker(ctx)`
   succeeds AND `/var/run/docker.sock` exists. This prevents double-
   reporting on docker-on-containerd hosts.
3. **Rootless severity downgrade**: `runtime-root-user` finding emitted
   from podman_runtime_audit is medium → low when `podman.info` shows
   `host.security.rootless == true`.
4. **Shared helpers (Option α)**: `_evaluate_inspect` / `_evaluate_image_tag`
   / `_parse_ctr_info` in `_docker_common.py` return `list[dict]` of
   Finding kwargs. New Checks compose via `self.make_finding(**kw)`
   (Redactor pass automatic). 7f Docker Checks unchanged — they keep
   direct `Finding(...)` construction; migration to make_finding deferred.
5. **TI naming**: daemon + runtime TIs split per-runtime
   (TI-DOCKER-* / TI-PODMAN-* / TI-CONTAINERD-*). image_patterns TIs
   shared (TI-DOCKER-IMAGE-*) because image content is runtime-agnostic.
   (Renamed to TI-CONTAINER-IMAGE-* in v0.20.0 — see ADR-0020.)

## Consequences

- 5 new Checks, ~71 new tests; total Check count 29 → 34.
- Coverage: RHEL/Fedora default container runtime closed; standalone
  containerd hosts have meaningful runtime + image audit (with the
  partial-coverage warning in ctr mode).
- ssh_policy.yaml gains 10 allowed_paths + 3 commands sections.
- containerd in K8s context still routed via 7g (Kubernetes) phase.
- Containerd daemon config audit (config.toml) — deferred to 7f.1.1 or
  on-demand.

## Alternatives Considered

- **Option B (full 6 Checks including containerd_daemon)**: rejected
  because config.toml security knobs are sparse (3-4 rules); not worth
  the complexity.
- **Option C (refactor existing Docker Checks to multi-runtime polymorphism)**:
  rejected — touches working 7f code, breaks docker test surface.
- **Only nerdctl, no ctr fallback**: rejected — RHEL/Fedora containerd
  hosts often lack nerdctl (docker.io repo download); the partial-coverage
  ctr mode is the difference between zero coverage and 4/7 rule coverage.
- **TI共享一套（rename TI-DOCKER-* → TI-CONTAINER-*）**: rejected — touches
  7f Docker findings backward compat; per-runtime TIs let report
  consumers folded by runtime.

Spec: `docs/superpowers/specs/2026-05-12-phase-7f1-podman-containerd-design.md`
