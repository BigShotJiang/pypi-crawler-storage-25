# ADR-0026: Phase 7d.6 — PHP/Composer supply chain audit

* **Status**: Accepted
* **Date**: 2026-05-17
* **Phase**: 7d.6

## Context

7d series (npm / pip / go / rust/cargo / java/maven / ruby/gem)
shipped 6 OSV-backed supply chain Checks. PHP/Composer (Packagist)
is the largest single PHP ecosystem (WordPress / Laravel / Symfony
combined); adding it completes a **7-language** milestone
(JavaScript / Python / Go / Rust / Java / Ruby / PHP).

PHP / Composer differences from prior ecosystems:

1. **Lockfile is `composer.lock` JSON** — Composer is the de facto
   PHP dependency manager (used by Laravel / Symfony / WordPress
   plugins / virtually every modern PHP project). The lockfile is
   JSON (not text like Gemfile.lock or TOML like Cargo.lock), with
   two top-level arrays: `packages` (production) and `packages-dev`
   (development/CI). Both must be walked for full coverage.

2. **Composer stability flags map cleanly to PEP 440** — Composer
   uses `-dev` / `-alpha` / `-beta` / `-RC` / `-p` (patch) suffixes
   on versions; PEP 440 uses `.devN` / `aN` / `bN` / `rcN` / `.postN`.
   The two are isomorphic. 5-rule regex preprocessing in
   `_normalize_composer_version` lets us reuse `packaging.version`
   (already a pip ecosystem dep, zero new dependencies).

3. **Findings carry `evidence.scope: "prod"|"dev"`** — first 7d
   ecosystem to surface scope distinction. Some deploy flows use
   `composer install --no-dev`, so dev-only CVE matches are not
   real production attack surface. Operators can triage by scope.
   Finding fingerprint includes scope (different evidence dict),
   so prod + dev hits on the same (pkg, version, advisory) emit as
   2 distinct findings.

## Decision

1. **Parse `composer.lock` only**. JSON walk of `packages` +
   `packages-dev` arrays. Filter out `source.type == "path"` (local
   references — OSV cannot cover them). Other source types
   (`git` / `hg` / `svn` / missing) admitted; private-server
   packages naturally fail to match OSV.

2. **Reuse `packaging.version` with Composer→PEP 440 preprocessing**.
   `_normalize_composer_version` applies 5 regex substitutions
   (`-dev N` → `.devN`, `-alpha N` → `aN`, `-beta N` → `bN`,
   `-RC N` → `rcN`, `-p N` → `.postN`), plus leading `v` strip.
   Zero new dependencies.

3. **Strict basename validator**: `composer_lock_paths` entries must
   end in exactly `composer.lock` (lowercase, mirrors Cargo.lock /
   Gemfile.lock strict convention — Composer enforces this canonical
   filename).

4. **Three-tuple parser**: `parse_composer_lock` returns
   `(name, version, scope)` instead of the prior 2-tuple. Finding
   evidence gains `scope` key. First 7d ecosystem to distinguish
   prod vs dev attack surface.

5. **Mirror 7d.5 for everything else**: `OsvPackagistFetcher`
   pulling OSV-Packagist dump, 5-axis filter chain, dedup on
   (id, package), bundled `osv_packagist.json`,
   `TI-OSV-PACKAGIST-CATALOG` umbrella TI, CI guard at 15 MB cap.

## Why parse composer.lock and not composer.json

- `composer.lock` is the resolved-dependency artifact, present
  whenever `composer install` has run (i.e., in every deployed
  application).
- `composer.json` is the dependency declaration — it lists ranges
  like `"laravel/framework": "^10.0"` but doesn't fix exact resolved
  versions, so we can't directly match against OSV's
  version-specific advisories.
- Bundler's `Gemfile.lock` (7d.5) and Cargo's `Cargo.lock` (7d.3)
  set the precedent: always parse the lockfile.

## Why distinguish prod vs dev scope

- Some PHP deploy pipelines run `composer install --no-dev` so dev
  packages (phpunit, psalm, debugbar) are not present in the
  production environment.
- A `phpunit/phpunit` CVE that only affects dev-time test runs is
  meaningfully lower risk than a `monolog/monolog` CVE on the
  runtime logger.
- Other 7d ecosystems don't surface this because lockfile formats
  don't distinguish (npm package-lock.json conflates; Cargo.lock
  conflates; Bundler Gemfile.lock has group annotations but they're
  ignored by `bundle install`).
- 7d.4 Maven has comparable distinction via `scope` field (compile
  / test / runtime / provided) but did not surface it as evidence.
  7d.6 sets the precedent for future ecosystems to surface scope
  when the lockfile naturally distinguishes it.

## Consequences

- New Check (`php_supply_chain_audit`); total Checks 37 → **38**.
- New bundled DB (`osv_packagist.json`, 1.2 MB / 3,141 advisories
  on first build 2026-05-17).
- Future Composer CVE refresh = re-run `agentsec ioc-update` and
  re-commit `osv_packagist.json`.
- 7-language milestone reached (JS / Python / Go / Rust / Java /
  Ruby / PHP).
- Finding evidence schema gains optional `scope` key (only set by
  `php_supply_chain_audit` in v0.36.0; reports / scoring don't
  filter on it — operators triage manually).
- `parse_composer_lock` 3-tuple return sets a template for future
  scope-aware parsers in other ecosystems (gradle dev/test, npm
  dev-deps once that lockfile flag is properly parsed, etc.).

## Alternatives considered

- **Parse `composer.json`**: rejected, doesn't give exact resolved
  versions.
- **Hand-write Composer version comparator**: rejected, Composer's
  stability flags map cleanly to PEP 440 (5 lines of regex).
- **Single scope (treat dev as prod)**: rejected, would over-report
  on `composer install --no-dev` deploy pipelines.
- **Filter on `dist.url` ending in `.packagist.org`**: rejected,
  Composer 2.x uses GitHub API URLs in `dist.url` for packagist-hosted
  packages, so this heuristic is unreliable. Simpler to admit all
  non-`path` source types and let OSV's catalog naturally filter
  private-server packages (zero false positives by construction).

## References

- Spec: `docs/superpowers/specs/2026-05-17-phase-7d6-php-composer-supply-chain-design.md`
- Plan: `docs/superpowers/plans/2026-05-17-phase-7d6-php-composer-supply-chain.md`
- ADR-0012: Phase 7d npm
- ADR-0013: Phase 7d.1 pip
- ADR-0014: Phase 7d.2 go
- ADR-0015: Phase 7d.3 rust/cargo
- ADR-0024: Phase 7d.4 java/maven
- ADR-0025: Phase 7d.5 ruby/gem
- OSV Packagist ecosystem: https://osv.dev/list?ecosystem=Packagist
- Composer versions: https://getcomposer.org/doc/articles/versions.md
