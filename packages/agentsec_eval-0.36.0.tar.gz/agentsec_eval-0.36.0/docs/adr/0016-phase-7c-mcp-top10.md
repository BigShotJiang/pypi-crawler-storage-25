# ADR-0016: Phase 7c — MCP Top 10 自策展威胁分类

**状态**: 已采纳
**日期**: 2026-05-12
**参与者**: roger

## 背景

ADR-0006 在 `src/agentsec/tests/owasp_refs.py` 的正则里预留了 `MCP\d+`
前缀，标注 "Phase 7c 启用"。当时（2026-05-08）OWASP 官方尚未发布 MCP
Top 10；截至本 ADR（2026-05-12），官方依旧未发版。

AgentSec 自 v0.2.0 起所有 phase（7d 供应链系列、7e Linux 加固、7f 容器
审计）都集中在 server-audit 一侧。evaluation 一侧（agent 攻击套件）自
Phase 7b 完成 LLM Top 10 + Agentic v1.1 (17) 覆盖后没有再扩展。

## 决策

不等 OWASP，自己策展一份 10 条 MCP 威胁清单 (MCP1..MCP10)，按 MCP
协议原语切分：

| ID | 名称 | 协议层面 |
|---|---|---|
| MCP1 | Tool Description Injection | `tools/list` 返回的工具描述字符串 |
| MCP2 | Tool Result Injection | `tools/call` 返回的结果 payload |
| MCP3 | Cross-Server Confused Deputy | 多 server 同名工具，agent 误路由 |
| MCP4 | Resource URI Smuggling | `resources/read` URI 越出预期 scope |
| MCP5 | Prompt Template Injection | `prompts/get` 模板劫持 agent 行为 |
| MCP6 | Shadow Tool / Capability Drift | 运行时 `tools/list_changed` 引入新工具 |
| MCP7 | Sampling Abuse | server 用 `sampling/createMessage` 反向调 |
| MCP8 | Consent Bypass | 破坏性工具调用未经显式用户授权 |
| MCP9 | Server Supply Chain | typosquatting / 仓库接管 / 未签名包 |
| MCP10 | Tool-Argument Exfiltration | agent 把敏感数据泄入工具参数 |

报告渲染层把这套清单呈现为 `OWASP MCP Top 10 (AgentSec curated v1)`
表，标题里嵌入 "curated v1" 避免与未来 OWASP 官方版混淆。

## 理由

- **不等 OWASP**：AgentSec 的产品定位需要 evaluation 侧持续进展；
  即便 OWASP 后续发版，我们可在保留兼容前缀的前提下做 mapping。
- **按协议原语切分**：避免与 LLM01..LLM10 重复（如果按 OWASP-flavored
  抽象类别切，必然撞 prompt injection / supply chain 等）；MCP 协议原语
  视角天然窄、互斥、与攻击面 1:1。
- **故意 10 条整数**：与 "Top 10" 约定俗成对齐；fringe vector 留给
  未来 Phase 7c.1 supplements。
- **`OwaspCoverageMatrix.mcp_rows()`** 命名与 `llm_rows` / `agentic_rows`
  对齐，下游消费者无须特别处理。

## 备选方案

1. **等 OWASP 官方版**：放弃；时间不可控。
2. **复用 LLM Top 10 编号**（不引入 MCP 前缀，全部用 LLM01）：
   放弃；语义混淆，下游"按框架编号查覆盖"功能失效。
3. **按 OWASP-flavored 抽象切**（"MCP 提示注入"、"MCP 越权"…）：
   放弃；与 LLM01-10 严重重复。

## 后果

- **加载契约不变**：`owasp_refs` 正则早已接受 `MCP\d+`；YAML 加载层
  零改动。
- **报告新增一张表**：每份 remote/combined report 增加约 14 行 markdown
  （OWASP MCP 第三张表）。
- **CI 阈值变严**：新增 MCP1..MCP10 各 ≥ 6 case 闸；漏打 `owasp_refs:
  [MCPN]` 会阻断合入。
- **未来 OWASP 官方版兼容**：发版时新增 `OWASP-MCP\d+:YYYY` 前缀；
  老 `MCP\d+` 别名保留 2 个 minor 版本周期；旧 case 增补对照编号。
- **AGENTIC 交叉引用不锁定编号**：spec §3 的交叉引用列只列类别意图；
  具体 `AGENTIC-Tx` 编号在 case 实现阶段按 v1.1 官方名表逐条对照填写。

## References

- Spec: `docs/superpowers/specs/2026-05-12-phase-7c-mcp-top10-design.md`
