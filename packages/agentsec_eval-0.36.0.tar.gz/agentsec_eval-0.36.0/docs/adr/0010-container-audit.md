# 0010 — 容器审计接入策略（Phase 7f）

- **状态**：Accepted
- **日期**：2026-05-09
- **关联 spec**：`docs/superpowers/specs/2026-05-09-phase-7f-container-audit-design.md`

## 上下文

v0.9.5 完成 Linux 主机加固后，server-audit 18 类 Check 仍未覆盖容器层。
两类被审现实未被覆盖：宿主上的 Docker daemon / 容器运行时姿态、以及
OpenClaw 装在容器内的部署形态。

## 决策

引入三类 Docker Check（`docker_daemon_audit` / `docker_runtime_audit` /
`docker_image_cve`），全部走只读 argv。`ssh_policy.yaml` 新增 `docker:`
命令块；`args_schema.py` 新增 `kind: container_id` 正则分支
（`^[a-f0-9]{12,64}$`）。第一期不覆盖 containerd / podman / Kubernetes。

## 关键约束

- **只读 argv**：4 条 `allowed_argv`（version / info / ps / ps -a） + 1 条
  `args_schema`（inspect <id>）。`docker exec` / `pull` / `run` / `build`
  / `push` 全部在白名单外，不可达。
- **单 TI 源**：21 条 `TI-DOCKER-*` 全部进 `threat_intel.yaml`，不引入
  sidecar 文件；全部 `auto_refresh: false`（curated，不让 ioc-update
  覆盖）。
- **不入 PlatformProfile**：被审主机有无 Docker 是运行时事实，不是
  平台属性。`detect_docker(ctx)` 在每个 Check 头部调用，未装即
  not_applicable。
- **Config.Env 直接丢弃**：避免运行时 secret 进 evidence / audit-log。

## 权衡

- 拒绝 `docker exec` 牺牲了"容器内审计"能力，换取 CommandPolicy 单层
  argv 假设的稳定性；后续 Phase 视社区需求再讨论。
- 镜像 CVE 走 curated baseline 的 fnmatch 而非真扫器（Trivy/Grype），
  覆盖率取决于运维投入；换取出网零依赖 + 体积零增长。

## 后续

- containerd / podman 适配考虑放在 7f.1 / 7f.2。
- Kubernetes 节点审计是单独 Phase（kubectl 适配 + 集群配置维度）。
