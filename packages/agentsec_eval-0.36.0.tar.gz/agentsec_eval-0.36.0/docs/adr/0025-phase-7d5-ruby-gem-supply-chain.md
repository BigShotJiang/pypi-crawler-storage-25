# ADR-0025: Phase 7d.5 — Ruby/Gem supply chain audit

* **Status**: Accepted
* **Date**: 2026-05-16
* **Phase**: 7d.5

## Context

7d series (npm / pip / go / rust/cargo / java/maven) shipped 5
OSV-backed supply chain Checks. Ruby/Gem (RubyGems) is one of the
six major server-language ecosystems; adding it completes a
"6-language" milestone (JavaScript / Python / Go / Rust / Java /
Ruby).

Ruby has two notable differences from prior ecosystems:

1. **Lockfile is Bundler's `Gemfile.lock`** — Bundler is the de
   facto standard for Ruby dependency management. The lockfile is a
   text format (not JSON / TOML), with sections like `GEM`, `GIT`,
   `PATH`, `PLATFORMS`, `DEPENDENCIES`. Resolved transitive deps
   live in `GEM > specs:`.

2. **Version semantics are RubyGems-style** — similar to PEP 440 in
   handling pre-release suffixes (`1.0.0.pre.1`, `2.0.0.rc1`,
   `1.0.0.beta`), but not identical. Java/Maven needed a hand-
   written comparator; Ruby is close enough to PEP 440 that we can
   reuse `packaging.version` with simple string preprocessing.

## Decision

1. **Parse `Gemfile.lock` only**. We walk the `GEM > specs:`
   section, skipping `GIT` / `PATH` source sections (out-of-OSV-scope)
   and 6-space-indented transitive constraint lines (not resolved
   deps themselves). Gem names are case-folded to lowercase per
   RubyGems convention.

2. **Reuse `packaging.version` with RubyGems→PEP 440 preprocessing**.
   `_normalize_gem_version` applies simple regex substitutions
   (`.pre.N` → `aN`, `.beta.N` → `bN`, etc.) before delegating to
   `packaging.version.Version`. Zero new dependencies.

3. **Strict basename validator**: `gem_lock_paths` entries must end
   in exactly `Gemfile.lock` (mirrors Cargo.lock strict convention,
   not Maven's loose suffix match — because Bundler enforces this
   canonical filename).

4. **Mirror 7d.4 (java/maven) for everything else**: `OsvRubyGemsFetcher`
   pulling OSV-RubyGems dump, 5-axis filter chain, dedup on
   (id, package), bundled `osv_rubygems.json`, `TI-OSV-RUBYGEMS-CATALOG`
   umbrella TI, CI guard at 15 MB cap.

## Why parse Gemfile.lock and not `gem list --local`

- Gemfile.lock is the canonical Bundler artifact, present in every
  modern Ruby app's git repo.
- `gem list --local` shows the user's globally-installed gems, not
  the app's resolved dependencies. Often a superset including dev
  tools; less precise for app-level CVE audit.
- Bundler's `Gemfile.lock` enforces version pinning and includes
  transitive deps, mirroring Cargo.lock semantics.

## Why packaging.version (PEP 440) and not hand-written comparator

- RubyGems pre-release suffixes (`1.0.0.pre.1` / `.beta` / `.rc1`)
  map cleanly to PEP 440 (`1.0.0a1` / `b0` / `rc1`) via 5 lines of
  regex substitution.
- `packaging` is already a dependency (pulled in for pip ecosystem
  in Phase 7d.1).
- Edge cases (rare RubyGems version strings like `.git.20250101`
  build metadata) are silently dropped (return False from range
  check), which is the safer fallback for a security audit (false
  negative on weird versions is preferable to wrong vulnerability
  attribution).

## Consequences

- New Check (`gem_supply_chain_audit`); total Checks 36 → **37**.
- New bundled DB (`osv_rubygems.json`, 176 KB / 476 advisories at
  2026-05-16). Ruby ecosystem is smaller than Java/Python — fewer
  curated advisories after the 5-axis filter.
- Future RubyGems CVE refresh = re-run `agentsec ioc-update` and
  re-commit `osv_rubygems.json`.
- 6-language milestone reached (JS / Python / Go / Rust / Java /
  Ruby). Future ecosystems (.NET/nuget, swift/spm, php/composer) can
  be added with the same 7d template.

## Alternatives considered

- **Parse `gem list --local` output**: rejected, not the app's
  resolved dep set (see above).
- **Hand-write RubyGems version comparator**: rejected, `packaging`
  already covers 99% of real-world cases with minimal bridging.
- **Strict `pkg ==N` form (à la pip)**: rejected, Bundler's
  Gemfile.lock is the natural Ruby equivalent.

## References

- Spec: `docs/superpowers/specs/2026-05-16-phase-7d5-ruby-gem-supply-chain-design.md`
- Plan: `docs/superpowers/plans/2026-05-16-phase-7d5-ruby-gem-supply-chain.md`
- ADR-0012: Phase 7d npm
- ADR-0013: Phase 7d.1 pip
- ADR-0014: Phase 7d.2 go
- ADR-0015: Phase 7d.3 rust/cargo
- ADR-0024: Phase 7d.4 java/maven
- OSV RubyGems ecosystem: https://osv.dev/list?ecosystem=RubyGems
- Bundler Gemfile.lock format: https://bundler.io/v2.4/man/gemfile.5.html
