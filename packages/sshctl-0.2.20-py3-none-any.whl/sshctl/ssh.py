from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Optional

from .model import Server


def _expand_path(p: Optional[str]) -> Optional[str]:
    if not p:
        return None
    return str(Path(os.path.expanduser(p)).expanduser())


def build_ssh_command(server: Server) -> list[str]:
    """构造安全的 ssh argv（不使用 shell=True）。

    本项目按你的要求：不读取 ~/.ssh/config，所有连接参数只从数据库获取。
    这里通过 `ssh -F /dev/null` 强制忽略用户配置文件，避免出现：
    Bad owner or permissions on ~/.ssh/config
    """

    argv: list[str] = ["ssh", "-F", "/dev/null", "-p", str(server.port)]

    identity = _expand_path(server.identity_file)
    if identity:
        argv += ["-i", identity]

    argv.append(f"{server.user}@{server.host}")
    return argv


def run_ssh(server: Optional[Server]) -> int:
    """连接服务器：仅使用数据库记录拼装 ssh 命令。

    - 如果该服务器保存了明文 password，则使用 sshpass 自动登录
    - 否则走普通 ssh，让你手动输入密码

    返回 ssh 进程退出码。
    """

    if not server:
        raise SystemExit("找不到服务器记录（请先 list 确认编号，或先 add 添加）。")

    argv = build_ssh_command(server)

    if server.has_password:
        env = os.environ.copy()
        env["SSHPASS"] = server.password or ""
        proc = subprocess.run(["sshpass", "-e"] + argv, env=env)
        return int(proc.returncode)

    proc = subprocess.run(argv)
    return int(proc.returncode)
