from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import sqlite3

from .model import Server


def _row_to_server(row: sqlite3.Row) -> Server:
    return Server(
        id=int(row["id"]),
        name=str(row["name"]),
        host=str(row["host"]),
        port=int(row["port"]),
        user=str(row["user"]),
        identity_file=row["identity_file"],
        note=row["note"],
        password=row["password"] if "password" in row.keys() else None,
    )


def create_server(
    conn: sqlite3.Connection,
    *,
    name: str,
    host: str,
    port: int = 22,
    user: str = "root",
    identity_file: Optional[str] = None,
    note: Optional[str] = None,
    password: Optional[str] = None,
) -> Server:
    cur = conn.execute(
        """
        INSERT INTO servers (name, host, port, user, identity_file, note, password)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (name, host, int(port), user, identity_file, note, password),
    )
    server_id = cur.lastrowid
    row = conn.execute("SELECT * FROM servers WHERE id = ?", (server_id,)).fetchone()
    assert row is not None
    return _row_to_server(row)


def list_servers(conn: sqlite3.Connection) -> list[Server]:
    rows = conn.execute("SELECT * FROM servers ORDER BY name COLLATE NOCASE").fetchall()
    return [_row_to_server(r) for r in rows]


def get_server_by_name(conn: sqlite3.Connection, name: str) -> Optional[Server]:
    row = conn.execute("SELECT * FROM servers WHERE name = ?", (name,)).fetchone()
    return _row_to_server(row) if row else None


def get_server_by_id(conn: sqlite3.Connection, server_id: int) -> Optional[Server]:
    row = conn.execute("SELECT * FROM servers WHERE id = ?", (int(server_id),)).fetchone()
    return _row_to_server(row) if row else None


def delete_server_by_name(conn: sqlite3.Connection, name: str) -> int:
    cur = conn.execute("DELETE FROM servers WHERE name = ?", (name,))
    return int(cur.rowcount)


def update_server_by_name(
    conn: sqlite3.Connection,
    name: str,
    *,
    host: Optional[str] = None,
    port: Optional[int] = None,
    user: Optional[str] = None,
    identity_file: Optional[str] = None,
    note: Optional[str] = None,
    password: Optional[str] = None,
) -> Optional[Server]:
    existing = get_server_by_name(conn, name)
    if not existing:
        return None

    new_host = host if host is not None else existing.host
    new_port = int(port) if port is not None else existing.port
    new_user = user if user is not None else existing.user
    new_identity = identity_file if identity_file is not None else existing.identity_file
    new_note = note if note is not None else existing.note
    new_password = password if password is not None else existing.password

    conn.execute(
        """
        UPDATE servers
        SET host = ?, port = ?, user = ?, identity_file = ?, note = ?, password = ?
        WHERE name = ?
        """,
        (new_host, new_port, new_user, new_identity, new_note, new_password, name),
    )

    return get_server_by_name(conn, name)


def search_servers(conn: sqlite3.Connection, q: str) -> list[Server]:
    like = f"%{q}%"
    rows = conn.execute(
        """
        SELECT * FROM servers
        WHERE name LIKE ? OR host LIKE ? OR user LIKE ? OR note LIKE ?
        ORDER BY name COLLATE NOCASE
        """,
        (like, like, like, like),
    ).fetchall()
    return [_row_to_server(r) for r in rows]
