class Geometrical():
    pass