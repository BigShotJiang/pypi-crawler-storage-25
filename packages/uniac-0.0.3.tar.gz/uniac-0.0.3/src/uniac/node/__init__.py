"""NodeDefinition layer — the deploy-time complete declaration.

A :class:`Node` carries the data the CTL needs to identify and locate
a deployed resource: ``primitive`` (the published-lib name in the
global store), ``version``, and at runtime the live endpoint ``url``.

This layer has no dependencies on other Uniac subpackages. It's the
seed type that the *client* layer's generated projections subclass and
that the *reader* layer's spec-processing code recognizes when walking
class-level annotations.

This subpackage is structured to allow future extraction into its own
distributable: nothing here imports from ``uniac.user``,
``uniac.reader``, or ``uniac.client``.
"""
from uniac.node.node import Node

__all__ = ["Node"]
