"""The Node class — deploy-time complete declaration AND runtime handle."""
from __future__ import annotations

from typing import Any, ClassVar, Optional


class Node:
    """A complete independent resource definition.

    ``__init__`` takes **no arguments**. The init schema is whatever
    the System/Service that owns this Node declares via class-level
    annotations. Other initialization paths (URL hydration, owner
    adoption) are not constructor args; the framework writes those
    fields onto the instance directly.

    Used inside a System/Service graph: instantiated zero-arg by the
    framework's ``_uniac_populate`` from class-level annotations.
    Owned by a parent NodeSpec; ``url`` is hydrated by the runtime
    loader from ``UNIAC_DEPS_JSON``. User code reads
    ``self.<child>.url``.

    Class-level fields (set by the generated projection per published lib):
      - ``_uniac_primitive`` -- identifier in the global store.
      - ``_uniac_version``   -- version of the published lib.

    Per-instance fields (defaults from the class; written by the
    framework once the Node is adopted/hydrated):
      - ``_uniac_owner``      -- parent NodeSpec/Node, or ``None``.
      - ``_uniac_local_name`` -- attribute name under the owner.
      - ``_uniac_url``        -- live runtime endpoint, or ``None``.
    """

    _uniac_primitive: ClassVar[str] = ""
    _uniac_version: ClassVar[str] = "latest"

    _uniac_owner: Any = None
    _uniac_local_name: Optional[str] = None
    _uniac_url: Optional[str] = None

    @property
    def url(self) -> Optional[str]:
        """The runtime endpoint URL, or ``None`` if unhydrated."""
        return self._uniac_url

    @property
    def name(self) -> str:
        """The published-lib name (``_uniac_primitive``).

        Pinned per generated subclass — useful for logging, debugging,
        and framework-level identification. Never read to construct
        the HTTP call itself.
        """
        return self._uniac_primitive
