"""Uniac Service — producer-side runtime impl spec.

Subclasses contain ONLY:
  - runtime-specific logic (e.g. ``build_app`` for ``FastAPIService``),
  - structure-observation methods consumed by the infrastructure graph
    builder and runner.

Service is **not directly instantiated by user code**. The framework
instantiates it at runtime (inside the deployed container) and at
publish-time introspection. Inherits :class:`uniac.reader.spec.NodeSpec`
for the shared spec-level machinery (dep declaration via class-level
Node annotations, framework hooks ``_uniac_populate`` and
``_uniac_walk``).

Service is independent of :class:`uniac.node.Node`. Node holds the
deploy-time complete declaration; Service holds runtime logic. The CTL
pairs them at publish time via the lib's primitive name in
``metadata.json``.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from uniac.reader.spec import NodeSpec

if TYPE_CHECKING:
    from fastapi import FastAPI


class Service(NodeSpec):
    """Producer-side runtime impl spec base."""


class FastAPIService(Service):
    """A Uniac service backed by a FastAPI application."""

    def build_app(self) -> "FastAPI":
        raise NotImplementedError(
            f"{type(self).__name__} must implement build_app() -> FastAPI"
        )
