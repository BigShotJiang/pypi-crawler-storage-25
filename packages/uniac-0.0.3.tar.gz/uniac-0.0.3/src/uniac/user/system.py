"""Uniac System — kind=app composition root spec.

Like :class:`uniac.user.service.Service`, ``System`` is a
:class:`uniac.reader.spec.NodeSpec` subclass — it reuses the same
spec-level machinery (dep declaration via class-level Node annotations,
framework hooks ``_uniac_populate`` and ``_uniac_walk``). Used to
declare the app's topology — a tree of Node deps. The CTL instantiates
an instance, calls ``_uniac_populate``, then iterates ``_uniac_walk``
to extract the app's owned-Node tree.

There is no ``add()``, no ``_nodes``, no ``_edges`` — child nodes are
declared via class-level annotations. Composition mirrors Service::

    from greeter import Service as Greeter
    from auth import Service as Auth

    class MyApp(System):
        auth: Auth
        greeter: Greeter
"""
from __future__ import annotations

from uniac.reader.spec import NodeSpec


class System(NodeSpec):
    """kind=app composition root spec."""
