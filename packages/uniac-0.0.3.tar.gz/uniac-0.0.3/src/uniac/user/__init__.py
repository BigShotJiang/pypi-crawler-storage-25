"""UserDefinition layer — base classes the user subclasses to author.

This is where end users land when they write a Uniac lib or app:

  - :class:`Service` — base for runtime impls (kind=lib).
    :class:`FastAPIService` adds a ``build_app`` hook.
  - :class:`System` — composition root (kind=app).

These classes carry no graph machinery directly — they inherit
:class:`uniac.reader.spec.NodeSpec` for that — and they're not meant to
be instantiated by user code. The framework instantiates them: the
runtime loader for Service in a deployed container; the introspect /
inspect_lib CLIs for offline analysis.

This subpackage depends only on ``uniac.reader.spec`` (for NodeSpec
inheritance). It does NOT depend on ``uniac.node`` or ``uniac.client``.
"""
from uniac.user.service import FastAPIService, Service
from uniac.user.system import System

__all__ = ["FastAPIService", "Service", "System"]
