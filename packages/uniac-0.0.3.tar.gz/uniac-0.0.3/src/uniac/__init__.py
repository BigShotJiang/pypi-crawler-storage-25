"""Uniac SDK — public surface, layered by responsibility.

The package is split into three subpackages, each modeling one layer
of the system. Imports inside each subpackage are confined to that
layer's dependencies, so any layer can be lifted into its own
distributable package without rewiring the others.

Conceptual flow::

    UserDefinition <--uses-- ReaderLibrary --obtains--> NodeDefinition

  - :mod:`uniac.user`   — UserDefinition: base classes the user
    subclasses (``Service``, ``FastAPIService``, ``System``).
  - :mod:`uniac.reader` — ReaderLibrary: framework processing
    (``NodeSpec`` + introspect / inspect_lib CLIs).
  - :mod:`uniac.node`   — NodeDefinition: the deploy-time complete
    declaration AND the runtime handle (``Node``). Generated
    projections subclass :class:`uniac.node.Node` directly — its
    ``url`` and ``name`` properties cover the runtime-handle role
    that the legacy ``ServiceClient`` used to fill.

This module re-exports the public API for convenient ``from uniac
import X`` access; layered imports remain available via
``uniac.<layer>.<symbol>`` for code that wants to keep its dependency
arrows explicit.
"""

from uniac.node import Node
from uniac.reader import NodeSpec
from uniac.user import FastAPIService, Service, System

__all__ = [
    "FastAPIService",
    "Node",
    "NodeSpec",
    "Service",
    "System",
]
