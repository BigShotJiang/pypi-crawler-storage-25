"""Uniac NodeSpec — shared parent for runtime-side spec classes.

NodeSpec captures the spec-level logic Service and System share:
  - dep declaration via class-level Node annotations
  - framework hooks: ``_uniac_populate`` and ``_uniac_walk``

Subclasses: ``Service`` (runtime impl) and ``System`` (composition root).
NodeSpec is independent of Node — Node carries the deploy-time complete
declaration; NodeSpec is the runtime-side authoring abstraction. The two
hierarchies are deliberately unrelated by inheritance.
"""
from __future__ import annotations

from typing import Dict, Iterator, Type, get_type_hints

from uniac.node import Node


class NodeSpec:
    """Shared parent for runtime-side spec classes."""

    def _uniac_populate(self) -> None:
        """Materialize the Node tree on this instance.

        Walks class-level Node annotations (across the MRO) and, for
        each slot:
          1. If the slot is unset (or holds a non-Node value), instantiate
             the annotated Node subclass with no args and assign it.
          2. Record owner relations on the child Node.

        Class-level annotation is the only child-declaration mechanism.
        Assignments inside ``__init__`` to non-annotated attributes are
        plain attributes — they're not part of the graph.

        The framework calls this once after constructing an instance.
        """
        for attr_name, attr_type in _resolve_node_annotations(type(self)).items():
            current = getattr(self, attr_name, None)
            if not isinstance(current, Node):
                current = attr_type()
                object.__setattr__(self, attr_name, current)
            object.__setattr__(current, "_uniac_owner", self)
            object.__setattr__(current, "_uniac_local_name", attr_name)

    def _uniac_walk(self) -> Iterator[Node]:
        """Yield Nodes owned by this instance (declaration order).

        Yields only direct children declared via class-level annotations.
        """
        for attr_name in _resolve_node_annotations(type(self)):
            child = getattr(self, attr_name, None)
            if isinstance(child, Node):
                yield child


def _resolve_node_annotations(cls: type) -> Dict[str, Type[Node]]:
    """Return ``{attr_name: NodeSubclass}`` for every class-level
    annotation in ``cls``'s MRO whose type resolves to a ``Node``
    subclass. ``ClassVar``-typed annotations and non-Node types are
    filtered out.

    Forward references are resolved against ``cls.__module__``'s
    globals via :func:`typing.get_type_hints`. If resolution fails for
    any reason, returns an empty mapping rather than raising — the
    caller treats no graph children as a valid (degenerate) shape.
    """
    try:
        hints = get_type_hints(cls)
    except Exception:
        return {}

    result: Dict[str, Type[Node]] = {}
    for attr_name, attr_type in hints.items():
        if attr_name.startswith("_uniac_"):
            continue
        if attr_name.startswith("__") and attr_name.endswith("__"):
            continue
        if not isinstance(attr_type, type):
            continue
        if not issubclass(attr_type, Node):
            continue
        result[attr_name] = attr_type
    return result
