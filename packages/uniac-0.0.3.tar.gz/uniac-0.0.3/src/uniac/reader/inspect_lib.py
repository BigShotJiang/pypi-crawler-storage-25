"""CLI emitter for a published lib's internal node graph.

Invoked as ``python -m uniac.reader.inspect_lib <module:object>`` during
``uniac build`` for kind=lib packages. The producer authoring class
(a :class:`uniac.user.service.Service` subclass) is imported and
instantiated zero-arg; the framework materializes its Node tree via
``_uniac_populate`` and walks it with ``_uniac_walk``. The owned-Node
tree is emitted as JSON on stdout in the same shape as
:mod:`uniac.reader.introspect`::

    {
      "nodes": [
        {"name": str, "primitive": str, "version": str, "init_args": dict},
        ...
      ],
      "edges": [
        {"src": str, "depends_on": str},
        ...
      ]
    }

The CTL persists this payload as ``internal_graph`` inside the published
lib's ``metadata.json`` so downstream deploys can stitch each lib's
internal Node tree into the deployable graph.
"""
from __future__ import annotations

import importlib
import json
import os
import sys
from pathlib import Path

from uniac.user.service import Service


class InspectLibError(Exception):
    """Failed to inspect the lib's authoring class."""


def _setup_import_path(project_dir: str = ".") -> None:
    """Add ``projectRoot`` and ``projectRoot/.uniac/packages`` to ``sys.path``.

    The first lets us import the lib's source module; the second lets
    that module import any peer projections the lib depends on.
    """
    project = Path(project_dir).resolve()
    packages = project / ".uniac" / "packages"

    packages_str = str(packages)
    project_str = str(project)
    if packages_str not in sys.path:
        sys.path.insert(0, packages_str)
    if project_str not in sys.path:
        sys.path.insert(0, project_str)


def _parse_entrypoint(entrypoint: str) -> tuple[str, str]:
    """Parse ``module:object`` into ``(module, object)``."""
    if ":" not in entrypoint:
        raise InspectLibError(
            f"Invalid entrypoint {entrypoint!r}: expected 'module:object' format"
        )
    module_name, attr_name = entrypoint.split(":", 1)
    if not module_name or not attr_name:
        raise InspectLibError(
            f"Invalid entrypoint {entrypoint!r}: module and object must be non-empty"
        )
    return module_name, attr_name


def load_service_class(entrypoint: str) -> Service:
    """Import and instantiate the lib's authoring class.

    Accepts either a Service instance (returned directly) or a Service
    subclass (instantiated zero-arg).
    """
    module_name, attr_name = _parse_entrypoint(entrypoint)

    try:
        mod = importlib.import_module(module_name)
    except ModuleNotFoundError as exc:
        raise InspectLibError(
            f"Cannot import module {module_name!r}: {exc}"
        ) from exc

    obj = getattr(mod, attr_name, None)
    if obj is None:
        raise InspectLibError(
            f"Module {module_name!r} has no attribute {attr_name!r}"
        )

    if isinstance(obj, Service):
        return obj

    if isinstance(obj, type) and issubclass(obj, Service):
        return obj()

    raise InspectLibError(
        f"{module_name}:{attr_name} is not a Service instance or subclass"
    )


def emit(service: Service) -> dict:
    """Materialize the Service's owned-Node tree and serialize to a dict."""
    service._uniac_populate()
    nodes = []
    for child in service._uniac_walk():
        nodes.append(
            {
                "name": child._uniac_local_name,
                "primitive": child._uniac_primitive,
                "version": child._uniac_version,
                "init_args": {},
            }
        )
    return {"nodes": nodes, "edges": []}


def main() -> None:
    if len(sys.argv) != 2:
        print(
            "Usage: python -m uniac.reader.inspect_lib <module:object>",
            file=sys.stderr,
        )
        sys.exit(1)

    project_dir = os.environ.get("UNIAC_PROJECT_DIR", ".")
    _setup_import_path(project_dir)

    entrypoint = sys.argv[1]
    try:
        service = load_service_class(entrypoint)
    except InspectLibError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    json.dump(emit(service), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
