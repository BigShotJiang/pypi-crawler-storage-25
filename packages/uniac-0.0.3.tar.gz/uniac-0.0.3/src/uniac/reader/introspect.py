"""CLI entry point for the Uniac CTL to read this app's node-wise structure.

Invoked as ``python -m uniac.reader.introspect <module:object>``. Imports
the user's :class:`uniac.user.system.System` subclass (or instance),
instantiates it if needed, materializes its Node tree via
:meth:`uniac.reader.spec.NodeSpec._uniac_populate`, and emits the
local node-and-edge structure as JSON on stdout::

    {
      "nodes": [
        {"name": str, "primitive": str, "version": str, "init_args": dict},
        ...
      ],
      "edges": [
        {"src": str, "depends_on": str},
        ...
      ]
    }

Walking each node's primitive reference into the published lib's spec,
and assembling the full deployable graph, is the CTL's job — that
traversal is language-agnostic and lives there.
"""
from __future__ import annotations

import importlib
import json
import os
import sys
from pathlib import Path

from uniac.user.system import System


class IntrospectError(Exception):
    """Failed to introspect the user's System."""


def _setup_import_path(project_dir: str = ".") -> None:
    """Add ``projectRoot`` and ``projectRoot/.uniac/packages`` to ``sys.path``.

    The first lets us import the user's app module; the second lets that
    module ``from greeter import Service`` (the projection symlinked
    there by ``uniac init``).
    """
    project = Path(project_dir).resolve()
    packages = project / ".uniac" / "packages"

    packages_str = str(packages)
    project_str = str(project)
    if packages_str not in sys.path:
        sys.path.insert(0, packages_str)
    if project_str not in sys.path:
        sys.path.insert(0, project_str)


def _parse_entrypoint(entrypoint: str) -> tuple[str, str]:
    """Parse ``module:object`` into ``(module, object)``."""
    if ":" not in entrypoint:
        raise IntrospectError(
            f"Invalid entrypoint {entrypoint!r}: expected 'module:object' format"
        )
    module_name, attr_name = entrypoint.split(":", 1)
    if not module_name or not attr_name:
        raise IntrospectError(
            f"Invalid entrypoint {entrypoint!r}: module and object must be non-empty"
        )
    return module_name, attr_name


def load_system(entrypoint: str) -> System:
    """Import and return a :class:`System` instance from an entrypoint string.

    Mirrors :func:`uniac_runtime.loader.load_service` for the app side:
    accepts both a System instance (returned directly) and a System
    subclass (instantiated and returned).
    """
    module_name, attr_name = _parse_entrypoint(entrypoint)

    try:
        mod = importlib.import_module(module_name)
    except ModuleNotFoundError as exc:
        raise IntrospectError(
            f"Cannot import module {module_name!r}: {exc}"
        ) from exc

    obj = getattr(mod, attr_name, None)
    if obj is None:
        raise IntrospectError(
            f"Module {module_name!r} has no attribute {attr_name!r}"
        )

    if isinstance(obj, System):
        return obj

    if isinstance(obj, type) and issubclass(obj, System):
        return obj()

    raise IntrospectError(
        f"{module_name}:{attr_name} is not a System instance or subclass"
    )


def emit(system: System) -> dict:
    """Serialize ``system``'s local node-and-edge structure to a plain dict.

    Calls ``system._uniac_populate()`` to materialize the Node tree from
    class-level annotations, then iterates ``system._uniac_walk()`` to
    enumerate owned Nodes.
    """
    system._uniac_populate()
    nodes = []
    for child in system._uniac_walk():
        nodes.append(
            {
                "name": child._uniac_local_name,
                "primitive": child._uniac_primitive,
                "version": child._uniac_version,
                "init_args": {},
            }
        )
    return {"nodes": nodes, "edges": []}


def main() -> None:
    if len(sys.argv) != 2:
        print(
            "Usage: python -m uniac.reader.introspect <module:object>",
            file=sys.stderr,
        )
        sys.exit(1)

    project_dir = os.environ.get("UNIAC_PROJECT_DIR", ".")
    _setup_import_path(project_dir)

    entrypoint = sys.argv[1]
    try:
        system = load_system(entrypoint)
    except IntrospectError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    json.dump(emit(system), sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
