"""ReaderLibrary layer — framework-side processing of UserDefinitions.

The Reader is the framework code that:
  - Reads class-level Node annotations on user-authored Service/System
    classes (``_resolve_node_annotations``).
  - Materializes the Node tree by auto-instantiating annotated slots
    and recording owner relations (``NodeSpec._uniac_populate``).
  - Walks the tree to enumerate owned Nodes (``NodeSpec._uniac_walk``).
  - Emits introspect payloads for the CTL during ``uniac deploy``
    (:mod:`uniac.reader.introspect`) and ``uniac build`` for kind=lib
    (:mod:`uniac.reader.inspect_lib`).

This subpackage depends on ``uniac.node`` (recognizes Node subclasses)
and on ``uniac.user`` (loads Service/System instances at CLI time). It
does NOT depend on ``uniac.client``.
"""
from uniac.reader.spec import NodeSpec, _resolve_node_annotations

__all__ = ["NodeSpec", "_resolve_node_annotations"]
