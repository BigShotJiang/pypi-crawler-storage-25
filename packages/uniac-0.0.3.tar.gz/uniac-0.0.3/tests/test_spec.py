"""Tests for uniac.reader.spec.NodeSpec — the parent of Service and System."""
from uniac.node import Node
from uniac.reader.spec import NodeSpec, _resolve_node_annotations


# ---- Test fixtures ----

class _DbNode(Node):
    _uniac_primitive = "db"


class _CacheNode(Node):
    _uniac_primitive = "cache"


# ---- _uniac_populate ----

class TestUniacPopulate:

    def test_auto_instantiates_class_level_annotation(self):
        class App(NodeSpec):
            db: _DbNode

        app = App()
        app._uniac_populate()
        assert isinstance(app.db, _DbNode)

    def test_records_owner_and_local_name(self):
        class App(NodeSpec):
            db: _DbNode

        app = App()
        app._uniac_populate()
        assert app.db._uniac_owner is app
        assert app.db._uniac_local_name == "db"

    def test_multiple_annotations_each_populated(self):
        class App(NodeSpec):
            db: _DbNode
            cache: _CacheNode

        app = App()
        app._uniac_populate()
        assert isinstance(app.db, _DbNode)
        assert isinstance(app.cache, _CacheNode)
        assert app.db._uniac_local_name == "db"
        assert app.cache._uniac_local_name == "cache"

    def test_user_override_in_init_is_respected(self):
        """If the user sets self.db in __init__, populate keeps that
        instance — only records ownership, doesn't replace it."""
        sentinel = _DbNode()

        class App(NodeSpec):
            db: _DbNode

            def __init__(self):
                self.db = sentinel

        app = App()
        app._uniac_populate()

        assert app.db is sentinel
        assert sentinel._uniac_owner is app
        assert sentinel._uniac_local_name == "db"

    def test_non_annotated_attribute_not_a_graph_child(self):
        """Plain in-__init__ assignment to a NON-annotated attribute is
        not recognized as graph membership."""

        class App(NodeSpec):
            db: _DbNode

            def __init__(self):
                self.cache = _CacheNode()

        app = App()
        app._uniac_populate()

        assert app.cache._uniac_owner is None
        assert app.cache._uniac_local_name is None
        assert app.db._uniac_owner is app

    def test_inherited_annotations_from_mro(self):
        class Base(NodeSpec):
            db: _DbNode

        class Child(Base):
            cache: _CacheNode

        child = Child()
        child._uniac_populate()

        assert isinstance(child.db, _DbNode)
        assert isinstance(child.cache, _CacheNode)

    def test_non_node_annotations_ignored(self):
        class App(NodeSpec):
            db: _DbNode
            count: int = 0
            name: str = ""

        app = App()
        app._uniac_populate()

        assert isinstance(app.db, _DbNode)
        assert app.count == 0
        assert app.name == ""

    def test_idempotent(self):
        """Calling _uniac_populate twice doesn't replace populated children."""
        class App(NodeSpec):
            db: _DbNode

        app = App()
        app._uniac_populate()
        first_db = app.db
        app._uniac_populate()
        assert app.db is first_db

    def test_classvar_annotations_skipped(self):
        from typing import ClassVar

        class App(NodeSpec):
            db: _DbNode
            shared: ClassVar[str] = "x"

        app = App()
        app._uniac_populate()
        assert isinstance(app.db, _DbNode)
        # 'shared' isn't auto-instantiated (ClassVar isn't a Node).
        assert App.shared == "x"


# ---- _uniac_walk ----

class TestUniacWalk:

    def test_yields_owned_nodes(self):
        class App(NodeSpec):
            db: _DbNode
            cache: _CacheNode

        app = App()
        app._uniac_populate()
        children = list(app._uniac_walk())

        assert len(children) == 2
        assert app.db in children
        assert app.cache in children

    def test_yields_in_annotation_order(self):
        class App(NodeSpec):
            db: _DbNode
            cache: _CacheNode

        app = App()
        app._uniac_populate()
        children = list(app._uniac_walk())

        assert children[0] is app.db
        assert children[1] is app.cache

    def test_empty_when_no_annotations(self):
        class App(NodeSpec):
            pass

        assert list(App()._uniac_walk()) == []

    def test_walk_works_after_populate(self):
        class App(NodeSpec):
            db: _DbNode

        app = App()
        # Without populate, walk doesn't yield anything (db is a class
        # annotation but no instance attribute is set yet — actually,
        # since attr_type is on the class, getattr returns... let's just
        # verify the documented behavior: walk after populate).
        app._uniac_populate()
        assert list(app._uniac_walk()) == [app.db]


# ---- _resolve_node_annotations ----

class TestResolveNodeAnnotations:

    def test_returns_node_typed_annotations(self):
        class App(NodeSpec):
            db: _DbNode

        assert _resolve_node_annotations(App) == {"db": _DbNode}

    def test_filters_non_node_types(self):
        class App(NodeSpec):
            db: _DbNode
            count: int = 0

        result = _resolve_node_annotations(App)
        assert "count" not in result
        assert result == {"db": _DbNode}

    def test_walks_mro(self):
        class Base(NodeSpec):
            db: _DbNode

        class Child(Base):
            cache: _CacheNode

        result = _resolve_node_annotations(Child)
        assert result == {"db": _DbNode, "cache": _CacheNode}

    def test_skips_uniac_prefix(self):
        """Internal _uniac_* annotations on Node/NodeSpec must not pollute
        the user-facing slot map."""
        result = _resolve_node_annotations(Node)
        for key in result:
            assert not key.startswith("_uniac_")

    def test_empty_for_pure_nodespec(self):
        assert _resolve_node_annotations(NodeSpec) == {}
