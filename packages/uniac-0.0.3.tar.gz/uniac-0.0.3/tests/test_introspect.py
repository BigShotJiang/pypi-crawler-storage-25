"""Tests for uniac.reader.introspect — the CLI emitter for System node-wise data.

Covers both the in-process API (``emit``, ``load_system``,
``_parse_entrypoint``) and the subprocess CLI
(``python -m uniac.reader.introspect``) so the wire shape the Go CTL
depends on is pinned end-to-end.
"""
import json
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

from uniac import System
from uniac.reader.introspect import (
    IntrospectError,
    _parse_entrypoint,
    emit,
    load_system,
)


# ---- In-process API ----

def test_emit_empty_system():
    class App(System):
        pass

    assert emit(App()) == {"nodes": [], "edges": []}


def test_emit_two_nodes():
    """Construct an app with two Node-typed annotations and verify the
    wire shape."""
    # Inline projection-equivalent classes (real projections are generated
    # under ~/.uniac/projections/<name>/__init__.py and subclass Node).
    from uniac.node import Node

    class _Auth(Node):
        _uniac_primitive = "auth"
        _uniac_version = "1.0"

    class _Greeter(Node):
        _uniac_primitive = "greeter"
        _uniac_version = "latest"

    class App(System):
        auth: _Auth
        greeter: _Greeter

    assert emit(App()) == {
        "nodes": [
            {
                "name": "auth",
                "primitive": "auth",
                "version": "1.0",
                "init_args": {},
            },
            {
                "name": "greeter",
                "primitive": "greeter",
                "version": "latest",
                "init_args": {},
            },
        ],
        "edges": [],
    }


def test_parse_entrypoint_valid():
    assert _parse_entrypoint("app:App") == ("app", "App")
    assert _parse_entrypoint("pkg.mod:Cls") == ("pkg.mod", "Cls")


def test_parse_entrypoint_missing_colon():
    with pytest.raises(IntrospectError, match="module:object"):
        _parse_entrypoint("noColon")


def test_parse_entrypoint_empty_parts():
    with pytest.raises(IntrospectError, match="must be non-empty"):
        _parse_entrypoint(":App")
    with pytest.raises(IntrospectError, match="must be non-empty"):
        _parse_entrypoint("app:")


def test_load_system_accepts_instance(tmp_path: Path, monkeypatch):
    """When the entrypoint resolves to a System *instance*, return it as-is."""
    (tmp_path / "instance_app.py").write_text(textwrap.dedent("""
        from uniac import System

        class _MyApp(System):
            pass

        app = _MyApp()
    """))
    monkeypatch.syspath_prepend(str(tmp_path))

    result = load_system("instance_app:app")

    assert isinstance(result, System)


def test_load_system_wrong_type(tmp_path: Path, monkeypatch):
    (tmp_path / "wrong_type_app.py").write_text("App = 42\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    with pytest.raises(IntrospectError, match="not a System"):
        load_system("wrong_type_app:App")


def test_load_system_missing_attribute(tmp_path: Path, monkeypatch):
    (tmp_path / "missing_attr_app.py").write_text("# empty\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    with pytest.raises(IntrospectError, match="no attribute"):
        load_system("missing_attr_app:Missing")


def test_load_system_missing_module():
    with pytest.raises(IntrospectError, match="Cannot import module"):
        load_system("definitely_not_a_real_module_xyz:App")


# ---- Subprocess CLI ----

def _run_introspect(cwd: Path, entrypoint: str) -> subprocess.CompletedProcess:
    """Invoke ``python -m uniac.reader.introspect`` from *cwd*.

    Adds the in-tree ``uniac/src`` to ``PYTHONPATH`` so the spawned
    interpreter can find the ``uniac`` package without an editable
    install.
    """
    src_root = Path(__file__).parent.parent / "src"
    env = {**os.environ, "PYTHONPATH": str(src_root)}
    return subprocess.run(
        [sys.executable, "-m", "uniac.reader.introspect", entrypoint],
        cwd=cwd,
        capture_output=True,
        text=True,
        env=env,
    )


def _write_projection(packages_dir: Path, name: str, version: str = "latest") -> None:
    """Write a fake generated projection under ``packages_dir/<name>``.

    Mirrors the shape uniac_ctl emits at ``~/.uniac/projections/<name>``.
    """
    proj_dir = packages_dir / name
    proj_dir.mkdir(parents=True, exist_ok=True)
    (proj_dir / "__init__.py").write_text(textwrap.dedent(f"""
        from uniac.node import Node

        class Service(Node):
            _uniac_primitive = {name!r}
            _uniac_version = {version!r}
    """))


def test_cli_happy_path(tmp_path: Path):
    packages = tmp_path / ".uniac" / "packages"
    _write_projection(packages, "auth", "1.0")
    _write_projection(packages, "greeter", "latest")

    (tmp_path / "app.py").write_text(textwrap.dedent("""
        from uniac import System
        from auth import Service as Auth
        from greeter import Service as Greeter

        class MyApp(System):
            auth: Auth
            greeter: Greeter
    """))

    result = _run_introspect(tmp_path, "app:MyApp")

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload == {
        "nodes": [
            {
                "name": "auth",
                "primitive": "auth",
                "version": "1.0",
                "init_args": {},
            },
            {
                "name": "greeter",
                "primitive": "greeter",
                "version": "latest",
                "init_args": {},
            },
        ],
        "edges": [],
    }


def test_cli_bad_format(tmp_path: Path):
    result = _run_introspect(tmp_path, "noColon")
    assert result.returncode == 1
    assert "module:object" in result.stderr


def test_cli_missing_module(tmp_path: Path):
    result = _run_introspect(tmp_path, "missing_module_xyz:App")
    assert result.returncode == 1
    assert "Cannot import module" in result.stderr


def test_cli_missing_attribute(tmp_path: Path):
    (tmp_path / "app.py").write_text("# empty module\n")
    result = _run_introspect(tmp_path, "app:NotThere")
    assert result.returncode == 1
    assert "no attribute" in result.stderr


def test_cli_wrong_type(tmp_path: Path):
    (tmp_path / "app.py").write_text("App = 42\n")
    result = _run_introspect(tmp_path, "app:App")
    assert result.returncode == 1
    assert "not a System" in result.stderr


def test_cli_no_args():
    result = _run_introspect(Path.cwd(), "")
    # Empty arg still has 2 elements in argv, but parse_entrypoint will reject it.
    assert result.returncode == 1
