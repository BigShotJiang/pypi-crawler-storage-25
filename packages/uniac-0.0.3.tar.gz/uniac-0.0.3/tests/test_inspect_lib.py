"""Tests for uniac.reader.inspect_lib — the CLI emitter for a published
lib's internal node graph."""
import json
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

from uniac import FastAPIService
from uniac.reader.inspect_lib import (
    InspectLibError,
    _parse_entrypoint,
    emit,
    load_service_class,
)
from uniac.node import Node


# ---- In-process API ----

def test_emit_lib_with_no_owned_nodes():
    class Greeter(FastAPIService):
        pass

    assert emit(Greeter()) == {"nodes": [], "edges": []}


def test_emit_lib_with_one_owned_node():
    class _Db(Node):
        _uniac_primitive = "db"

    class Greeter(FastAPIService):
        db: _Db

    assert emit(Greeter()) == {
        "nodes": [
            {"name": "db", "primitive": "db", "version": "latest", "init_args": {}}
        ],
        "edges": [],
    }


def test_emit_lib_with_multiple_owned_nodes():
    class _Db(Node):
        _uniac_primitive = "db"

    class _Cache(Node):
        _uniac_primitive = "cache"
        _uniac_version = "2.0"

    class Greeter(FastAPIService):
        db: _Db
        cache: _Cache

    payload = emit(Greeter())
    assert payload["edges"] == []
    assert payload["nodes"] == [
        {"name": "db", "primitive": "db", "version": "latest", "init_args": {}},
        {"name": "cache", "primitive": "cache", "version": "2.0", "init_args": {}},
    ]


def test_parse_entrypoint_valid():
    assert _parse_entrypoint("app:Greeter") == ("app", "Greeter")


def test_parse_entrypoint_missing_colon():
    with pytest.raises(InspectLibError, match="module:object"):
        _parse_entrypoint("noColon")


def test_load_service_class_accepts_class(tmp_path: Path, monkeypatch):
    (tmp_path / "lib_accept.py").write_text(textwrap.dedent("""
        from uniac import FastAPIService

        class Greeter(FastAPIService):
            pass
    """))
    monkeypatch.syspath_prepend(str(tmp_path))

    instance = load_service_class("lib_accept:Greeter")
    assert isinstance(instance, FastAPIService)


def test_load_service_class_rejects_non_service(tmp_path: Path, monkeypatch):
    (tmp_path / "lib_reject.py").write_text("Greeter = 42\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    with pytest.raises(InspectLibError, match="not a Service"):
        load_service_class("lib_reject:Greeter")


def test_load_service_class_missing_attribute(tmp_path: Path, monkeypatch):
    (tmp_path / "lib_missing.py").write_text("# empty\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    with pytest.raises(InspectLibError, match="no attribute"):
        load_service_class("lib_missing:NotThere")


def test_load_service_class_missing_module():
    with pytest.raises(InspectLibError, match="Cannot import module"):
        load_service_class("definitely_not_a_real_module_xyz:Greeter")


# ---- Subprocess CLI ----

def _run_inspect_lib(cwd: Path, entrypoint: str) -> subprocess.CompletedProcess:
    """Invoke ``python -m uniac.reader.inspect_lib`` from *cwd*."""
    src_root = Path(__file__).parent.parent / "src"
    env = {**os.environ, "PYTHONPATH": str(src_root)}
    return subprocess.run(
        [sys.executable, "-m", "uniac.reader.inspect_lib", entrypoint],
        cwd=cwd,
        capture_output=True,
        text=True,
        env=env,
    )


def _write_projection(packages_dir: Path, name: str, version: str = "latest") -> None:
    proj_dir = packages_dir / name
    proj_dir.mkdir(parents=True, exist_ok=True)
    (proj_dir / "__init__.py").write_text(textwrap.dedent(f"""
        from uniac.node import Node

        class Service(Node):
            _uniac_primitive = {name!r}
            _uniac_version = {version!r}
    """))


def test_cli_happy_path(tmp_path: Path):
    packages = tmp_path / ".uniac" / "packages"
    _write_projection(packages, "db", "1.0")

    (tmp_path / "lib.py").write_text(textwrap.dedent("""
        from fastapi import FastAPI
        from uniac import FastAPIService
        from db import Service as Db

        class Greeter(FastAPIService):
            db: Db

            def build_app(self):
                return FastAPI()
    """))

    result = _run_inspect_lib(tmp_path, "lib:Greeter")
    assert result.returncode == 0, result.stderr

    payload = json.loads(result.stdout)
    assert payload == {
        "nodes": [
            {"name": "db", "primitive": "db", "version": "1.0", "init_args": {}}
        ],
        "edges": [],
    }


def test_cli_bad_format(tmp_path: Path):
    result = _run_inspect_lib(tmp_path, "noColon")
    assert result.returncode == 1
    assert "module:object" in result.stderr


def test_cli_missing_module(tmp_path: Path):
    result = _run_inspect_lib(tmp_path, "missing_module_xyz:App")
    assert result.returncode == 1
    assert "Cannot import module" in result.stderr


def test_cli_wrong_type(tmp_path: Path):
    (tmp_path / "wrongtype.py").write_text("Greeter = 42\n")
    result = _run_inspect_lib(tmp_path, "wrongtype:Greeter")
    assert result.returncode == 1
    assert "not a Service" in result.stderr
