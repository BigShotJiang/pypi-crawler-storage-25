"""Tests for uniac.user.system.System — the kind=app composition root."""
from uniac import System
from uniac.node import Node
from uniac.reader.spec import NodeSpec


# ---- Test fixtures ----

class _Auth(Node):
    _uniac_primitive = "auth"


class _Greeter(Node):
    _uniac_primitive = "greeter"


# ---- System inherits NodeSpec ----

class TestSystemHierarchy:

    def test_system_is_a_nodespec(self):
        """System must inherit NodeSpec to share the spec-level machinery
        (auto-instantiation, walk, etc.) with Service."""
        assert issubclass(System, NodeSpec)

    def test_system_is_not_a_node(self):
        """System and Node are independent abstractions: System describes
        the composition; Node is the deploy-time complete declaration."""
        assert not issubclass(System, Node)

    def test_system_has_no_imperative_add_api(self):
        """The legacy add()/_nodes/_edges API has been removed entirely."""
        s = System()
        assert not hasattr(s, "add")
        assert not hasattr(s, "_nodes")
        assert not hasattr(s, "_edges")

    def test_system_does_not_aggregate_graph(self):
        """Full-graph assembly is the CTL's responsibility, not the
        Python client's."""
        assert not hasattr(System(), "graph")


# ---- Class-level annotation declares children ----

class TestSystemComposition:

    def test_class_level_annotation_auto_instantiates(self):
        class App(System):
            auth: _Auth

        app = App()
        app._uniac_populate()
        assert isinstance(app.auth, _Auth)
        assert app.auth._uniac_owner is app
        assert app.auth._uniac_local_name == "auth"

    def test_multiple_annotations_in_declaration_order(self):
        class App(System):
            auth: _Auth
            greeter: _Greeter

        app = App()
        app._uniac_populate()

        children = list(app._uniac_walk())
        assert len(children) == 2
        assert children[0] is app.auth
        assert children[1] is app.greeter

    def test_user_init_override_respected(self):
        """If the user pre-assigns a slot in __init__, populate keeps it
        and only records ownership."""
        custom_auth = _Auth()

        class App(System):
            auth: _Auth

            def __init__(self):
                self.auth = custom_auth

        app = App()
        app._uniac_populate()

        assert app.auth is custom_auth
        assert custom_auth._uniac_owner is app

    def test_no_annotation_means_no_graph_child(self):
        """Plain attribute assignment without a class-level annotation
        is NOT a graph child."""
        class App(System):
            auth: _Auth

            def __init__(self):
                self.greeter = _Greeter()  # no class annotation

        app = App()
        app._uniac_populate()

        # auth IS adopted (annotated).
        assert app.auth._uniac_owner is app
        # greeter is NOT (un-annotated).
        assert app.greeter._uniac_owner is None
        # walk yields only annotated children.
        assert list(app._uniac_walk()) == [app.auth]


# ---- Wire-shape parity (compatibility with introspect emit shape) ----

class TestNodeIdentityFields:
    """The fields introspect.emit reads off each owned Node."""

    def test_primitive_and_version_pinned_per_subclass(self):
        class App(System):
            auth: _Auth

        app = App()
        app._uniac_populate()
        assert app.auth._uniac_primitive == "auth"
        assert app.auth._uniac_version == "latest"

    def test_local_name_matches_attribute(self):
        class App(System):
            auth: _Auth
            greeter: _Greeter

        app = App()
        app._uniac_populate()
        assert app.auth._uniac_local_name == "auth"
        assert app.greeter._uniac_local_name == "greeter"
