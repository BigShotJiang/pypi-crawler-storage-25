"""Tests for uniac.node.Node — the deploy-time declaration AND runtime handle."""
import pytest

from uniac.node import Node


class TestNodeClassDefaults:

    def test_primitive_default_empty(self):
        assert Node._uniac_primitive == ""

    def test_version_default_latest(self):
        assert Node._uniac_version == "latest"


class TestNodeInstanceDefaults:
    """Zero-arg construction (the framework's _uniac_populate path)."""

    def test_owner_defaults_none(self):
        assert Node()._uniac_owner is None

    def test_local_name_defaults_none(self):
        assert Node()._uniac_local_name is None

    def test_url_field_defaults_none(self):
        assert Node()._uniac_url is None


class TestUrlProperty:

    def test_url_returns_none_unhydrated(self):
        assert Node().url is None

    def test_url_reflects_uniac_url_assignment(self):
        node = Node()
        node._uniac_url = "https://greeter.test"
        assert node.url == "https://greeter.test"

    def test_url_property_is_read_only(self):
        node = Node()
        with pytest.raises(AttributeError):
            node.url = "https://x"


class TestZeroArgInit:
    """``__init__`` takes no arguments. The init schema is owned by the
    parent System/Service via class-level annotations, not by Node's
    constructor."""

    def test_zero_arg_construction(self):
        # Must not raise — every code path that creates a Node passes no args.
        Node()

    def test_rejects_positional_arg(self):
        with pytest.raises(TypeError):
            Node("https://greeter.test")  # type: ignore[call-arg]

    def test_rejects_url_kwarg(self):
        with pytest.raises(TypeError):
            Node(url="https://greeter.test")  # type: ignore[call-arg]


class TestNameProperty:
    """``name`` exposes ``_uniac_primitive`` — pinned by the projection."""

    def test_name_default_empty_for_base_node(self):
        assert Node().name == ""

    def test_name_reflects_uniac_primitive(self):
        class Greeter(Node):
            _uniac_primitive = "greeter"

        assert Greeter().name == "greeter"

    def test_name_property_is_read_only(self):
        node = Node()
        with pytest.raises(AttributeError):
            node.name = "x"


class TestSubclassing:
    """Generated projections subclass Node and pin _uniac_primitive."""

    def test_subclass_pins_primitive(self):
        class Greeter(Node):
            _uniac_primitive = "greeter"

        assert Greeter._uniac_primitive == "greeter"
        assert Greeter()._uniac_primitive == "greeter"

    def test_subclass_pins_version(self):
        class Greeter(Node):
            _uniac_primitive = "greeter"
            _uniac_version = "1.0"

        assert Greeter()._uniac_version == "1.0"

    def test_subclass_inherits_url_property(self):
        class Greeter(Node):
            _uniac_primitive = "greeter"

        node = Greeter()
        assert node.url is None
        node._uniac_url = "https://greeter.test"
        assert node.url == "https://greeter.test"

    def test_two_instances_independent_url(self):
        class Greeter(Node):
            _uniac_primitive = "greeter"

        a = Greeter()
        b = Greeter()
        a._uniac_url = "https://a.test"
        assert b.url is None  # b is unaffected

    def test_subclass_inherits_zero_arg_init(self):
        """Subclasses must keep the zero-arg init contract — Node
        forbids constructor args."""
        class Greeter(Node):
            _uniac_primitive = "greeter"

        Greeter()  # OK
        with pytest.raises(TypeError):
            Greeter(url="https://x")  # type: ignore[call-arg]
