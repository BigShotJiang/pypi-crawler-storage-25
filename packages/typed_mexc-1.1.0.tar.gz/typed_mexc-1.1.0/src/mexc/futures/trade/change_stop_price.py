from typing_extensions import NotRequired, TypedDict
from mexc.futures.core import AuthFuturesMixin
from mexc.core import validator

class Body(TypedDict):
  """Change stop-limit prices for a futures limit order request body."""
  orderId: int
  """Limit order identifier."""
  stopLossPrice: NotRequired[float]
  """Stop-loss price; when both stop-loss and take-profit are empty or 0 the attached stop settings are cancelled."""
  takeProfitPrice: NotRequired[float]
  """Take-profit price; when both stop-loss and take-profit are empty or 0 the attached stop settings are cancelled."""

class Response200(TypedDict):
  """Futures write endpoint response envelope."""
  success: bool
  """Whether the API request succeeded."""
  code: NotRequired[int]
  """MEXC response code; zero indicates success when present."""
  message: NotRequired[str]
  """Error or status message when present."""

adapter = validator(Response200)

class ChangeStopPrice(AuthFuturesMixin):
  async def change_stop_price(
    self,
    body: Body,
    *,
    validate: bool | None = None
  ) -> Response200:
    """Updates or clears stop-loss and take-profit prices attached to a futures limit order.

    Args:
      body: Request body.
      validate: Validation override for this request.

    Returns:
      The validated endpoint response.

    References:
      Upstream docs: https://mexcdevelop.github.io/apidocs/contract_v1_en/#switch-stop-limit-limited-order-price"""
    params = {}
    r = await self.signed_post('/api/v1/private/stoporder/change_price', json=body)
    return self.envelope_output(r.text, adapter, validate)
