from dataclasses import dataclass
from decimal import Decimal

from typed_core.ws.streams import Stream
from mexc.core import validator, TypedDict
from mexc.futures.streams.core import StreamsMixin, Reply

class FairPrice(TypedDict, total=False):
  symbol: str
  price: Decimal

validate_response = validator(FairPrice)

@dataclass
class FairPriceStream(StreamsMixin):
  async def fair_price(self, symbol: str, *, validate: bool = True) -> Stream[FairPrice, Reply, Reply]:
    """
    Subscribe to fair-price updates for one futures contract.

    Args:
      symbol: Futures contract symbol, for example `BTC_USDT`.
      validate: Validate pushed price payloads.

    References:
      - [MEXC futures WebSocket API](https://mexcdevelop.github.io/apidocs/contract_v1_en/#filter-subscription)
    """
    stream = await self.subscribe('fair.price', {'symbol': symbol})
    async def parsed_stream():
      async for msg in stream:
        yield validate_response(msg) if self.validate(validate) else msg
    return Stream(reply=stream.reply, stream=parsed_stream(), unsubscribe=stream.unsubscribe)
