from typing_extensions import NotRequired, TypedDict
from mexc.spot.core import AuthSpotMixin, ErrorResponse
from mexc.core import Timestamp, timestamp as ts, validator

class Item(TypedDict):
  """Withdrawal application result."""
  id: NotRequired[str | None]
  """Withdrawal id."""

Response: type[list[Item] | ErrorResponse] = list[Item] | ErrorResponse # type: ignore
adapter = validator(Response)

class WithdrawApply(AuthSpotMixin):
  async def withdraw_apply(
    self,
    *,
    coin: str,
    withdraw_order_id: str | None = None,
    network: str | None = None,
    address: str,
    memo: str | None = None,
    amount: str,
    remark: str | None = None,
    timestamp: Timestamp | None = None,
    validate: bool | None = None
  ) -> list[Item]:
    """Deprecated previous withdrawal endpoint that submits a live asset withdrawal request.

    Args:
      coin: Asset to withdraw.
      withdraw_order_id: Optional client withdrawal order id.
      network: Withdrawal network identifier.
      address: Destination withdrawal address.
      memo: Destination memo or tag when required.
      amount: Withdrawal amount.
      remark: Optional withdrawal remark.
      timestamp: Signed request timestamp in milliseconds.
      validate: Validation override for this request.

    Returns:
      The validated endpoint response.

    References:
      Upstream docs: https://mexcdevelop.github.io/apidocs/spot_v3_en/#withdraw-previous-offline-soon"""
    if timestamp is None:
      timestamp = ts.now()
    params = {}
    if coin is not None:
      params['coin'] = coin
    if withdraw_order_id is not None:
      params['withdrawOrderId'] = withdraw_order_id
    if network is not None:
      params['network'] = network
    if address is not None:
      params['address'] = address
    if memo is not None:
      params['memo'] = memo
    if amount is not None:
      params['amount'] = amount
    if remark is not None:
      params['remark'] = remark
    if timestamp is not None:
      params['timestamp'] = ts.dump_ms(timestamp)
    r = await self.signed_request('POST', '/api/v3/capital/withdraw/apply', params=params)
    return self.output(r.text, adapter, validate)
