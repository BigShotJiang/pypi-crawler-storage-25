from typing_extensions import NotRequired, TypedDict
from mexc.spot.core import AuthSpotMixin, ErrorResponse
from mexc.core import Timestamp, timestamp as ts, validator

class Body(TypedDict):
  fromAccount: NotRequired[str]
  """Source account name."""
  toAccount: NotRequired[str]
  """Destination account name."""
  fromAccountType: NotRequired[str]
  """Source account type."""
  toAccountType: NotRequired[str]
  """Destination account type."""
  asset: NotRequired[str]
  """Asset symbol to transfer."""
  amount: NotRequired[str]
  """Amount of the asset to transfer."""

class Response200(TypedDict):
  """Sub-account transfer result."""
  tranId: NotRequired[str | int | None]
  """Transfer id."""

Response: type[Response200 | ErrorResponse] = Response200 | ErrorResponse # type: ignore
adapter = validator(Response)

class Transfer(AuthSpotMixin):
  async def transfer(
    self,
    *,
    from_account: str | None = None,
    to_account: str | None = None,
    from_account_type: str,
    to_account_type: str,
    asset: str,
    amount: str,
    timestamp: Timestamp | None = None,
    validate: bool | None = None
  ) -> Response200:
    """Transfers an asset between the master account and a sub-account.

    Args:
      from_account: Source account name. Defaults to the master account when omitted.
      to_account: Destination account name. Defaults to the master account when omitted.
      from_account_type: Source account type, documented as SPOT or FUTURES.
      to_account_type: Destination account type, documented as SPOT or FUTURES.
      asset: Asset symbol to transfer.
      amount: Amount of the asset to transfer.
      timestamp: Signed request timestamp in milliseconds.
      validate: Validation override for this request.

    Returns:
      The validated endpoint response.

    References:
      Upstream docs: https://mexcdevelop.github.io/apidocs/spot_v3_en/#universal-transfer-for-master-account"""
    if timestamp is None:
      timestamp = ts.now()
    params = {}
    if from_account is not None:
      params['fromAccount'] = from_account
    if to_account is not None:
      params['toAccount'] = to_account
    if from_account_type is not None:
      params['fromAccountType'] = from_account_type
    if to_account_type is not None:
      params['toAccountType'] = to_account_type
    if asset is not None:
      params['asset'] = asset
    if amount is not None:
      params['amount'] = amount
    if timestamp is not None:
      params['timestamp'] = ts.dump_ms(timestamp)
    r = await self.signed_request('POST', '/api/v3/capital/sub-account/universalTransfer', params=params)
    return self.output(r.text, adapter, validate)
