from dataclasses import dataclass
import asyncio
import os

from mexc.spot.core import MEXC_SPOT_API_BASE, AuthHttpClient
from .streams import Streams
from .streams.core import MEXC_SPOT_SOCKET_URL
from .account import Account
from .market import Market
from .rebate import Rebate
from .sub_accounts import SubAccounts
from .trade import Trade
from .wallet import Wallet

@dataclass
class Spot:
  account: Account
  market: Market
  rebate: Rebate
  sub_accounts: SubAccounts
  trade: Trade
  wallet: Wallet
  streams: Streams

  def __init__(
    self, *,
    api_url: str = MEXC_SPOT_API_BASE,
    ws_url: str = MEXC_SPOT_SOCKET_URL,
    auth_http: AuthHttpClient,
    default_validate: bool = True,
  ):
    self.default_validate = default_validate
    self.base_url = api_url
    self.http = self.auth_http = auth_http
    self.account = Account(
      base_url=api_url,
      auth_http=auth_http,
      default_validate=default_validate,
    )
    self.market = Market(
      base_url=api_url,
      http=auth_http,
      default_validate=default_validate,
    )
    self.rebate = Rebate(
      base_url=api_url,
      auth_http=auth_http,
      default_validate=default_validate,
    )
    self.sub_accounts = SubAccounts(
      base_url=api_url,
      auth_http=auth_http,
      default_validate=default_validate,
    )
    self.trade = Trade(
      base_url=api_url,
      auth_http=auth_http,
      default_validate=default_validate,
    )
    self.wallet = Wallet(
      base_url=api_url,
      auth_http=auth_http,
      default_validate=default_validate,
    )
    self.streams = Streams(api_url=api_url, ws_url=ws_url, auth_http=auth_http)

  @classmethod
  def new(
    cls, api_key: str | None = None, api_secret: str | None = None, *,
    base_url: str = MEXC_SPOT_API_BASE,
    ws_url: str = MEXC_SPOT_SOCKET_URL,
    default_validate: bool = True,
  ):
    if api_key is None:
      api_key = os.environ['MEXC_ACCESS_KEY']
    if api_secret is None:
      api_secret = os.environ['MEXC_SECRET_KEY']
    auth_http = AuthHttpClient(api_key=api_key, api_secret=api_secret)
    return cls(api_url=base_url, ws_url=ws_url, auth_http=auth_http, default_validate=default_validate)

  @classmethod
  def public(
    cls, *,
    base_url: str = MEXC_SPOT_API_BASE,
    ws_url: str = MEXC_SPOT_SOCKET_URL,
    default_validate: bool = True,
  ):
    auth_http = AuthHttpClient(api_key='', api_secret='', public=True)
    return cls(api_url=base_url, ws_url=ws_url, auth_http=auth_http, default_validate=default_validate)

  async def __aenter__(self):
    await asyncio.gather(
      self.auth_http.__aenter__(),
      self.streams.__aenter__(),
    )
    return self

  async def __aexit__(self, exc_type, exc_value, traceback):
    await asyncio.gather(
      self.auth_http.__aexit__(exc_type, exc_value, traceback),
      self.streams.__aexit__(exc_type, exc_value, traceback),
    )
