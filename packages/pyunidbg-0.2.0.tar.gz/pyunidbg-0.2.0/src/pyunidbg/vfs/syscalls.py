"""
File System Syscall Handlers for PyUniDbg.

Implements Linux syscall handlers for file operations that
redirect to the virtual filesystem.
"""

import logging
import struct
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

from . import FileStat, VirtualFS

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# Linux syscall numbers (ARM64)
class SyscallNumbers:
    """ARM64 Linux syscall numbers for file operations."""
    # File operations
    SYS_openat = 56
    SYS_close = 57
    SYS_read = 63
    SYS_write = 64
    SYS_lseek = 62
    SYS_pread64 = 67
    SYS_pwrite64 = 68

    # File info
    SYS_fstat = 80
    SYS_newfstatat = 79
    SYS_statx = 291

    # Directory operations
    SYS_mkdirat = 34
    SYS_unlinkat = 35
    SYS_renameat = 38
    SYS_getdents64 = 61

    # Links
    SYS_readlinkat = 78
    SYS_symlinkat = 36

    # File control
    SYS_ioctl = 29
    SYS_fcntl = 25
    SYS_dup = 23
    SYS_dup3 = 24

    # Access
    SYS_faccessat = 48
    SYS_faccessat2 = 439

    # Current directory
    SYS_getcwd = 17
    SYS_chdir = 49
    SYS_fchdir = 50


# Error codes
class Errno:
    """POSIX error codes."""
    EPERM = 1       # Operation not permitted
    ENOENT = 2      # No such file or directory
    ESRCH = 3       # No such process
    EINTR = 4       # Interrupted system call
    EIO = 5         # I/O error
    ENXIO = 6       # No such device or address
    E2BIG = 7       # Argument list too long
    ENOEXEC = 8     # Exec format error
    EBADF = 9       # Bad file number
    ECHILD = 10     # No child processes
    EAGAIN = 11     # Try again
    ENOMEM = 12     # Out of memory
    EACCES = 13     # Permission denied
    EFAULT = 14     # Bad address
    ENOTBLK = 15    # Block device required
    EBUSY = 16      # Device or resource busy
    EEXIST = 17     # File exists
    EXDEV = 18      # Cross-device link
    ENODEV = 19     # No such device
    ENOTDIR = 20    # Not a directory
    EISDIR = 21     # Is a directory
    EINVAL = 22     # Invalid argument
    ENFILE = 23     # File table overflow
    EMFILE = 24     # Too many open files
    ENOTTY = 25     # Not a typewriter
    ETXTBSY = 26    # Text file busy
    EFBIG = 27      # File too large
    ENOSPC = 28     # No space left on device
    ESPIPE = 29     # Illegal seek
    EROFS = 30      # Read-only file system
    EMLINK = 31     # Too many links
    EPIPE = 32      # Broken pipe
    ERANGE = 34     # Math result not representable
    ENOSYS = 38     # Function not implemented


# Special directory FDs
AT_FDCWD = -100


@dataclass
class SyscallContext:
    """Context for syscall handling."""
    emulator: 'Emulator'
    vfs: VirtualFS
    cwd: str = "/"


class FileSystemSyscallHandler:
    """
    Handles file system related syscalls.
    
    Intercepts file operations and redirects them to the
    virtual filesystem.
    """

    def __init__(self, emulator: 'Emulator', vfs: VirtualFS):
        """
        Initialize syscall handler.
        
        Args:
            emulator: PyUniDbg emulator instance
            vfs: Virtual filesystem
        """
        self.emulator = emulator
        self.vfs = vfs
        self.cwd = "/"

        # Syscall handlers
        self._handlers: dict[int, Callable] = {
            SyscallNumbers.SYS_openat: self._sys_openat,
            SyscallNumbers.SYS_close: self._sys_close,
            SyscallNumbers.SYS_read: self._sys_read,
            SyscallNumbers.SYS_write: self._sys_write,
            SyscallNumbers.SYS_lseek: self._sys_lseek,
            SyscallNumbers.SYS_fstat: self._sys_fstat,
            SyscallNumbers.SYS_newfstatat: self._sys_newfstatat,
            SyscallNumbers.SYS_mkdirat: self._sys_mkdirat,
            SyscallNumbers.SYS_unlinkat: self._sys_unlinkat,
            SyscallNumbers.SYS_readlinkat: self._sys_readlinkat,
            SyscallNumbers.SYS_getdents64: self._sys_getdents64,
            SyscallNumbers.SYS_getcwd: self._sys_getcwd,
            SyscallNumbers.SYS_chdir: self._sys_chdir,
            SyscallNumbers.SYS_faccessat: self._sys_faccessat,
            SyscallNumbers.SYS_dup: self._sys_dup,
            SyscallNumbers.SYS_dup3: self._sys_dup3,
            SyscallNumbers.SYS_fcntl: self._sys_fcntl,
            SyscallNumbers.SYS_ioctl: self._sys_ioctl,
        }

    def handle_syscall(self, syscall_num: int, args: tuple) -> int:
        """
        Handle a syscall.
        
        Args:
            syscall_num: Syscall number
            args: Syscall arguments
            
        Returns:
            Syscall return value
        """
        handler = self._handlers.get(syscall_num)
        if handler:
            try:
                return handler(*args)
            except FileNotFoundError:
                return -Errno.ENOENT
            except FileExistsError:
                return -Errno.EEXIST
            except PermissionError:
                return -Errno.EACCES
            except OSError:
                return -Errno.EIO
            except Exception as e:
                logger.error(f"Syscall {syscall_num} error: {e}")
                return -Errno.EINVAL

        logger.debug(f"Unhandled syscall: {syscall_num}")
        return -Errno.ENOSYS

    def _resolve_path(self, dirfd: int, pathname_ptr: int) -> str:
        """Resolve path from dirfd and pathname pointer."""
        pathname = self._read_string(pathname_ptr)

        if not pathname:
            return self.cwd

        if pathname.startswith('/'):
            return pathname

        if dirfd == AT_FDCWD:
            base = self.cwd
        else:
            # Get path from fd
            fd = self.vfs._fds.get(dirfd)
            if fd:
                base = fd.file.path
            else:
                base = self.cwd

        if not base.endswith('/'):
            base += '/'

        return base + pathname

    def _read_string(self, addr: int, max_len: int = 4096) -> str:
        """Read null-terminated string from memory."""
        if addr == 0:
            return ""

        try:
            data = self.emulator.mem_read(addr, max_len)
            null_idx = data.find(b'\x00')
            if null_idx >= 0:
                data = data[:null_idx]
            return data.decode('utf-8', errors='replace')
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return ""

    def _write_memory(self, addr: int, data: bytes):
        """Write data to memory."""
        self.emulator.mem_write(addr, data)

    def _write_stat(self, addr: int, st: FileStat):
        """Write stat structure to memory."""
        # Linux stat structure (ARM64)
        # This is simplified - actual structure is more complex
        data = struct.pack(
            '<QQIIIIQQQQQQQ',
            st.st_dev,      # st_dev
            st.st_ino,      # st_ino
            st.st_mode,     # st_mode
            st.st_nlink,    # st_nlink
            st.st_uid,      # st_uid
            st.st_gid,      # st_gid
            0,              # st_rdev
            0,              # padding
            st.st_size,     # st_size
            st.st_blksize,  # st_blksize
            0,              # padding
            st.st_blocks,   # st_blocks
            int(st.st_atime),  # st_atime
        )
        self._write_memory(addr, data)

    # === Syscall Implementations ===

    def _sys_openat(self, dirfd: int, pathname_ptr: int, flags: int, mode: int = 0o644) -> int:
        """Handle openat syscall."""
        path = self._resolve_path(dirfd, pathname_ptr)
        logger.debug(f"openat({dirfd}, '{path}', {flags:#x}, {mode:#o})")

        try:
            fd = self.vfs.open(path, flags, mode)
            return fd
        except FileNotFoundError:
            return -Errno.ENOENT
        except FileExistsError:
            return -Errno.EEXIST

    def _sys_close(self, fd: int) -> int:
        """Handle close syscall."""
        logger.debug(f"close({fd})")
        if self.vfs.close(fd):
            return 0
        return -Errno.EBADF

    def _sys_read(self, fd: int, buf_ptr: int, count: int) -> int:
        """Handle read syscall."""
        logger.debug(f"read({fd}, {buf_ptr:#x}, {count})")

        try:
            data = self.vfs.read_fd(fd, count)
            if data:
                self._write_memory(buf_ptr, data)
            return len(data)
        except OSError:
            return -Errno.EBADF

    def _sys_write(self, fd: int, buf_ptr: int, count: int) -> int:
        """Handle write syscall."""
        logger.debug(f"write({fd}, {buf_ptr:#x}, {count})")

        try:
            data = self.emulator.mem_read(buf_ptr, count)
            return self.vfs.write_fd(fd, bytes(data))
        except OSError:
            return -Errno.EBADF

    def _sys_lseek(self, fd: int, offset: int, whence: int) -> int:
        """Handle lseek syscall."""
        logger.debug(f"lseek({fd}, {offset}, {whence})")

        try:
            return self.vfs.seek_fd(fd, offset, whence)
        except OSError:
            return -Errno.EBADF

    def _sys_fstat(self, fd: int, stat_ptr: int) -> int:
        """Handle fstat syscall."""
        logger.debug(f"fstat({fd}, {stat_ptr:#x})")

        try:
            st = self.vfs.stat_fd(fd)
            self._write_stat(stat_ptr, st)
            return 0
        except OSError:
            return -Errno.EBADF

    def _sys_newfstatat(self, dirfd: int, pathname_ptr: int, stat_ptr: int, flags: int) -> int:
        """Handle newfstatat syscall."""
        path = self._resolve_path(dirfd, pathname_ptr)
        logger.debug(f"newfstatat({dirfd}, '{path}', {stat_ptr:#x}, {flags:#x})")

        try:
            st = self.vfs.stat_path(path)
            self._write_stat(stat_ptr, st)
            return 0
        except FileNotFoundError:
            return -Errno.ENOENT

    def _sys_mkdirat(self, dirfd: int, pathname_ptr: int, mode: int) -> int:
        """Handle mkdirat syscall."""
        path = self._resolve_path(dirfd, pathname_ptr)
        logger.debug(f"mkdirat({dirfd}, '{path}', {mode:#o})")

        self.vfs.mkdir(path, mode)
        return 0

    def _sys_unlinkat(self, dirfd: int, pathname_ptr: int, flags: int) -> int:
        """Handle unlinkat syscall."""
        path = self._resolve_path(dirfd, pathname_ptr)
        logger.debug(f"unlinkat({dirfd}, '{path}', {flags:#x})")

        if self.vfs.remove(path):
            return 0
        return -Errno.ENOENT

    def _sys_readlinkat(self, dirfd: int, pathname_ptr: int, buf_ptr: int, bufsiz: int) -> int:
        """Handle readlinkat syscall."""
        path = self._resolve_path(dirfd, pathname_ptr)
        logger.debug(f"readlinkat({dirfd}, '{path}', {buf_ptr:#x}, {bufsiz})")

        vfile = self.vfs.get(path)
        if vfile and vfile.target:
            target = vfile.target.encode('utf-8')[:bufsiz]
            self._write_memory(buf_ptr, target)
            return len(target)

        return -Errno.ENOENT

    def _sys_getdents64(self, fd: int, dirent_ptr: int, count: int) -> int:
        """Handle getdents64 syscall."""
        logger.debug(f"getdents64({fd}, {dirent_ptr:#x}, {count})")

        if fd not in self.vfs._fds:
            return -Errno.EBADF

        file_desc = self.vfs._fds[fd]
        if file_desc.file.file_type != self.vfs._files[file_desc.file.path].file_type:
            return -Errno.ENOTDIR

        # Get directory entries
        entries = self.vfs.listdir(file_desc.file.path)

        # Format as dirent64 structures
        offset = 0
        for i, name in enumerate(entries[file_desc.position:]):
            name_bytes = name.encode('utf-8') + b'\x00'
            # d_ino (8) + d_off (8) + d_reclen (2) + d_type (1) + d_name
            reclen = 8 + 8 + 2 + 1 + len(name_bytes)
            reclen = (reclen + 7) & ~7  # Align to 8 bytes

            if offset + reclen > count:
                break

            # Write dirent64
            entry = struct.pack('<QQHb', i + 1, i + 1, reclen, 8)  # DT_REG = 8
            entry += name_bytes
            entry += b'\x00' * (reclen - len(entry))

            self._write_memory(dirent_ptr + offset, entry)
            offset += reclen
            file_desc.position += 1

        return offset

    def _sys_getcwd(self, buf_ptr: int, size: int) -> int:
        """Handle getcwd syscall."""
        logger.debug(f"getcwd({buf_ptr:#x}, {size})")

        cwd_bytes = self.cwd.encode('utf-8') + b'\x00'
        if len(cwd_bytes) > size:
            return -Errno.ERANGE

        self._write_memory(buf_ptr, cwd_bytes)
        return buf_ptr

    def _sys_chdir(self, path_ptr: int) -> int:
        """Handle chdir syscall."""
        path = self._read_string(path_ptr)
        logger.debug(f"chdir('{path}')")

        if self.vfs.is_dir(path):
            self.cwd = path
            return 0
        return -Errno.ENOENT

    def _sys_faccessat(self, dirfd: int, pathname_ptr: int, mode: int, flags: int = 0) -> int:
        """Handle faccessat syscall."""
        path = self._resolve_path(dirfd, pathname_ptr)
        logger.debug(f"faccessat({dirfd}, '{path}', {mode}, {flags})")

        if self.vfs.exists(path):
            return 0
        return -Errno.ENOENT

    def _sys_dup(self, oldfd: int) -> int:
        """Handle dup syscall."""
        logger.debug(f"dup({oldfd})")

        if oldfd not in self.vfs._fds:
            return -Errno.EBADF

        old_desc = self.vfs._fds[oldfd]
        new_fd = self.vfs._get_next_fd()

        from . import FileDescriptor
        self.vfs._fds[new_fd] = FileDescriptor(
            fd=new_fd,
            file=old_desc.file,
            flags=old_desc.flags,
            position=old_desc.position
        )

        return new_fd

    def _sys_dup3(self, oldfd: int, newfd: int, flags: int) -> int:
        """Handle dup3 syscall."""
        logger.debug(f"dup3({oldfd}, {newfd}, {flags})")

        if oldfd not in self.vfs._fds:
            return -Errno.EBADF

        old_desc = self.vfs._fds[oldfd]

        # Close newfd if open
        self.vfs.close(newfd)

        from . import FileDescriptor
        self.vfs._fds[newfd] = FileDescriptor(
            fd=newfd,
            file=old_desc.file,
            flags=old_desc.flags,
            position=old_desc.position
        )

        return newfd

    def _sys_fcntl(self, fd: int, cmd: int, arg: int = 0) -> int:
        """Handle fcntl syscall."""
        logger.debug(f"fcntl({fd}, {cmd}, {arg})")

        F_GETFD = 1
        F_SETFD = 2
        F_GETFL = 3
        F_SETFL = 4

        if fd not in self.vfs._fds:
            return -Errno.EBADF

        desc = self.vfs._fds[fd]

        if cmd == F_GETFD:
            return 0  # FD_CLOEXEC not set
        elif cmd == F_SETFD:
            return 0
        elif cmd == F_GETFL:
            return desc.flags
        elif cmd == F_SETFL:
            desc.flags = arg
            return 0

        return -Errno.EINVAL

    def _sys_ioctl(self, fd: int, request: int, arg: int = 0) -> int:
        """Handle ioctl syscall."""
        logger.debug(f"ioctl({fd}, {request:#x}, {arg})")

        # Most ioctls we just return success or ENOTTY
        TCGETS = 0x5401
        TIOCGWINSZ = 0x5413

        if request == TIOCGWINSZ:
            # Return terminal size
            # struct winsize { rows, cols, xpixel, ypixel }
            self._write_memory(arg, struct.pack('<HHHH', 24, 80, 0, 0))
            return 0

        return -Errno.ENOTTY


def create_fs_handler(emulator: 'Emulator', vfs: VirtualFS) -> FileSystemSyscallHandler:
    """Create a filesystem syscall handler."""
    return FileSystemSyscallHandler(emulator, vfs)
