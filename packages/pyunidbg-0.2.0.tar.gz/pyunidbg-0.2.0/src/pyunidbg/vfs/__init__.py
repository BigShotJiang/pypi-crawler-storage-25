"""
Virtual File System for PyUniDbg.

Provides a virtual filesystem layer for emulated Android/iOS applications.
Intercepts file operations and provides controlled access to:
- Virtual files with custom content
- Mapped real files
- Simulated system files (/proc, /sys, etc.)

Usage:
    from pyunidbg import Emulator
    from pyunidbg.vfs import VirtualFS
    
    emu = Emulator(arch='arm64')
    vfs = VirtualFS()
    
    # Add virtual files
    vfs.add_file("/data/app/config.xml", b"<config>...</config>")
    vfs.map_file("/sdcard/data.bin", "/real/path/data.bin")
    
    # Mount to emulator
    emu.set_filesystem(vfs)
"""

import io
import logging
import os
import stat
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, IntFlag, auto
from pathlib import Path, PurePosixPath
from typing import BinaryIO, Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger(__name__)


class FileType(Enum):
    """Types of virtual files."""
    REGULAR = auto()      # Regular file
    DIRECTORY = auto()    # Directory
    SYMLINK = auto()      # Symbolic link
    DEVICE = auto()       # Device file
    PIPE = auto()         # Named pipe
    SOCKET = auto()       # Socket


class OpenFlags(IntFlag):
    """File open flags (POSIX-compatible)."""
    O_RDONLY = 0
    O_WRONLY = 1
    O_RDWR = 2
    O_CREAT = 0o100
    O_EXCL = 0o200
    O_TRUNC = 0o1000
    O_APPEND = 0o2000
    O_NONBLOCK = 0o4000
    O_DIRECTORY = 0o200000
    O_CLOEXEC = 0o2000000


class SeekWhence(Enum):
    """Seek positions."""
    SEEK_SET = 0
    SEEK_CUR = 1
    SEEK_END = 2


@dataclass
class FileStat:
    """File statistics (stat structure)."""
    st_mode: int = 0o644
    st_ino: int = 0
    st_dev: int = 0
    st_nlink: int = 1
    st_uid: int = 0
    st_gid: int = 0
    st_size: int = 0
    st_atime: float = 0.0
    st_mtime: float = 0.0
    st_ctime: float = 0.0
    st_blksize: int = 4096
    st_blocks: int = 0

    def __post_init__(self):
        now = time.time()
        if self.st_atime == 0:
            self.st_atime = now
        if self.st_mtime == 0:
            self.st_mtime = now
        if self.st_ctime == 0:
            self.st_ctime = now
        if self.st_blocks == 0:
            self.st_blocks = (self.st_size + 511) // 512


class Permission:
    """Permission bits."""
    R_OK = 4  # Read
    W_OK = 2  # Write
    X_OK = 1  # Execute
    F_OK = 0  # Exists


@dataclass
class VFSStats:
    """VFS statistics."""
    files_created: int = 0
    directories_created: int = 0
    bytes_read: int = 0
    bytes_written: int = 0
    open_operations: int = 0
    close_operations: int = 0


@dataclass
class MountPoint:
    """A mount point mapping."""
    virtual_path: str
    real_path: str
    read_only: bool = False


@dataclass
class VirtualFile:
    """A virtual file in the filesystem."""
    path: str
    file_type: FileType = FileType.REGULAR
    content: bytes = b""
    data: bytes = None  # Alias for content, set in __post_init__
    stat: FileStat = field(default_factory=FileStat)
    mode: int = 0o644
    uid: int = 0
    gid: int = 0

    # For mapped files
    real_path: str | None = None

    # For symlinks
    target: str | None = None

    # For device type
    device_type: str | None = None

    # For dynamic content
    read_handler: Callable[[], bytes] | None = None
    write_handler: Callable[[bytes], None] | None = None

    # Access tracking
    access_count: int = 0
    last_access: float = 0.0

    # Timestamps
    ctime: float = field(default_factory=time.time)
    mtime: float = field(default_factory=time.time)
    atime: float = field(default_factory=time.time)

    def __post_init__(self):
        """Handle data/content aliasing."""
        if self.data is not None and self.content == b"":
            self.content = self.data
        self.data = None  # Clear to use property

    @property
    def size(self) -> int:
        """Get file size."""
        return len(self.content)

    @property
    def is_dir(self) -> bool:
        """Check if directory."""
        return self.file_type == FileType.DIRECTORY

    @property
    def is_file(self) -> bool:
        """Check if regular file."""
        return self.file_type == FileType.REGULAR

    @property
    def is_symlink(self) -> bool:
        """Check if symlink."""
        return self.file_type == FileType.SYMLINK

    def is_readable(self, uid: int) -> bool:
        """Check if readable."""
        return bool(self.mode & 0o444)

    def is_writable(self, uid: int) -> bool:
        """Check if writable."""
        return bool(self.mode & 0o222)

    def is_executable(self, uid: int) -> bool:
        """Check if executable."""
        return bool(self.mode & 0o111)

    def read(self, size: int = -1, offset: int = 0) -> bytes:
        """Read data from file."""
        if size < 0:
            return self.content[offset:]
        return self.content[offset:offset + size]

    def write(self, data: bytes, offset: int = 0):
        """Write data to file."""
        content = bytearray(self.content)
        if offset + len(data) > len(content):
            content.extend(b'\x00' * (offset + len(data) - len(content)))
        content[offset:offset + len(data)] = data
        self.content = bytes(content)
        self.mtime = time.time()

    def append(self, data: bytes):
        """Append data to file."""
        self.content += data
        self.mtime = time.time()

    def truncate(self, size: int):
        """Truncate file to size."""
        self.content = self.content[:size]
        self.mtime = time.time()

    def get_content(self) -> bytes:
        """Get file content."""
        self.access_count += 1
        self.last_access = time.time()

        if self.read_handler:
            return self.read_handler()

        if self.real_path:
            try:
                with open(self.real_path, 'rb') as f:
                    return f.read()
            except Exception as e:
                logger.error(f"Error reading mapped file {self.real_path}: {e}")
                return b""

        return self.content

    def set_content(self, data: bytes):
        """Set file content."""
        if self.write_handler:
            self.write_handler(data)
            return

        if self.real_path:
            try:
                with open(self.real_path, 'wb') as f:
                    f.write(data)
            except Exception as e:
                logger.error(f"Error writing mapped file {self.real_path}: {e}")
            return

        self.content = data
        self.stat.st_size = len(data)
        self.stat.st_mtime = time.time()


@dataclass
class FileDescriptor:
    """An open file descriptor."""
    fd: int
    file: VirtualFile
    flags: int
    position: int = 0
    closed: bool = False

    def read(self, size: int = -1) -> bytes:
        """Read from file."""
        content = self.file.get_content()

        if size < 0:
            data = content[self.position:]
            self.position = len(content)
        else:
            data = content[self.position:self.position + size]
            self.position += len(data)

        return data

    def write(self, data: bytes) -> int:
        """Write to file."""
        content = bytearray(self.file.get_content())

        if self.flags & OpenFlags.O_APPEND:
            self.position = len(content)

        # Extend if needed
        if self.position + len(data) > len(content):
            content.extend(b'\x00' * (self.position + len(data) - len(content)))

        content[self.position:self.position + len(data)] = data
        self.file.set_content(bytes(content))
        self.position += len(data)

        return len(data)

    def seek(self, offset: int, whence: int = 0) -> int:
        """Seek to position."""
        content = self.file.get_content()

        if whence == SeekWhence.SEEK_SET.value:
            self.position = offset
        elif whence == SeekWhence.SEEK_CUR.value:
            self.position += offset
        elif whence == SeekWhence.SEEK_END.value:
            self.position = len(content) + offset

        self.position = max(0, self.position)
        return self.position

    def tell(self) -> int:
        """Get current position."""
        return self.position


class VirtualFS:
    """
    Virtual filesystem for emulator.
    
    Provides a complete virtual filesystem that can intercept
    all file operations from emulated code.
    """

    def __init__(self, case_sensitive: bool = True):
        """
        Initialize virtual filesystem.
        
        Args:
            case_sensitive: Whether paths are case-sensitive
        """
        self.case_sensitive = case_sensitive

        # File storage
        self._files: dict[str, VirtualFile] = {}
        self._next_inode = 1

        # Open file descriptors
        self._fds: dict[int, FileDescriptor] = {}
        self._next_fd = 3  # 0, 1, 2 reserved for stdin/stdout/stderr

        # Mount points
        self._mounts: dict[str, MountPoint] = {}

        # Path redirects
        self._redirects: dict[str, str] = {}

        # Access hooks
        self._access_hooks: list[Callable[[str, str], bytes | None]] = []

        # Statistics
        self._stats = VFSStats()

        # Initialize root
        self._files["/"] = VirtualFile(
            path="/",
            file_type=FileType.DIRECTORY,
            mode=0o755
        )

    def _init_standard_dirs(self):
        """Initialize standard directory structure."""
        std_dirs = [
            "/",
            "/dev",
            "/proc",
            "/sys",
            "/tmp",
            "/data",
            "/data/local",
            "/data/local/tmp",
            "/sdcard",
            "/system",
            "/system/lib",
            "/system/lib64",
        ]

        for dir_path in std_dirs:
            self.mkdir(dir_path)

    def _normalize_path(self, path: str) -> str:
        """Normalize path."""
        # Make absolute
        if not path.startswith('/'):
            path = '/' + path

        # Normalize
        path = str(PurePosixPath(path))

        # Handle case sensitivity
        if not self.case_sensitive:
            path = path.lower()

        # Apply redirects
        for prefix, target in self._redirects.items():
            if path.startswith(prefix):
                path = target + path[len(prefix):]
                break

        return path

    def _get_next_inode(self) -> int:
        """Get next inode number."""
        inode = self._next_inode
        self._next_inode += 1
        return inode

    def _get_next_fd(self) -> int:
        """Get next file descriptor number."""
        # Find first available FD
        for fd in range(3, 1024):
            if fd not in self._fds:
                return fd
        raise OSError("Too many open files")

    # === High-level File Operations ===

    def create(
        self,
        path: str,
        content: bytes | str = b"",
        mode: int = 0o644,
        create_parents: bool = False
    ) -> VirtualFile:
        """
        Create a file with content.
        
        Args:
            path: Virtual path
            content: File content
            mode: File permissions
            create_parents: Create parent directories
            
        Returns:
            Created VirtualFile
        """
        path = self._normalize_path(path)

        if create_parents:
            parent = str(PurePosixPath(path).parent)
            if parent != "/" and not self.exists(parent):
                self.mkdir(parent, parents=True)

        return self.add_file(path, content, mode)

    # === File Operations ===

    def add_file(
        self,
        path: str,
        content: bytes | str = b"",
        mode: int = 0o644
    ) -> VirtualFile:
        """
        Add a virtual file.
        
        Args:
            path: Virtual path
            content: File content (bytes or string)
            mode: File permissions
            
        Returns:
            Created VirtualFile
        """
        path = self._normalize_path(path)

        if isinstance(content, str):
            content = content.encode('utf-8')

        vfile = VirtualFile(
            path=path,
            file_type=FileType.REGULAR,
            content=content,
            stat=FileStat(
                st_mode=stat.S_IFREG | mode,
                st_ino=self._get_next_inode(),
                st_size=len(content)
            )
        )

        self._files[path] = vfile

        # Ensure parent directory exists
        parent = str(PurePosixPath(path).parent)
        if parent != path and parent not in self._files:
            self.mkdir(parent)

        logger.debug(f"Added virtual file: {path} ({len(content)} bytes)")
        return vfile

    def map_file(self, virtual_path: str, real_path: str) -> VirtualFile:
        """
        Map a virtual path to a real file.
        
        Args:
            virtual_path: Virtual path
            real_path: Real filesystem path
            
        Returns:
            Created VirtualFile
        """
        virtual_path = self._normalize_path(virtual_path)

        # Get real file stats
        try:
            st = os.stat(real_path)
            file_stat = FileStat(
                st_mode=st.st_mode,
                st_ino=self._get_next_inode(),
                st_size=st.st_size,
                st_atime=st.st_atime,
                st_mtime=st.st_mtime,
                st_ctime=st.st_ctime
            )
        except OSError:
            file_stat = FileStat(st_mode=stat.S_IFREG | 0o644)

        vfile = VirtualFile(
            path=virtual_path,
            file_type=FileType.REGULAR,
            real_path=real_path,
            stat=file_stat
        )

        self._files[virtual_path] = vfile
        logger.debug(f"Mapped {virtual_path} -> {real_path}")
        return vfile

    def add_dynamic_file(
        self,
        path: str,
        read_handler: Callable[[], bytes],
        write_handler: Callable[[bytes], None] | None = None
    ) -> VirtualFile:
        """
        Add a file with dynamic content.
        
        Args:
            path: Virtual path
            read_handler: Function that returns content
            write_handler: Optional function to handle writes
            
        Returns:
            Created VirtualFile
        """
        path = self._normalize_path(path)

        vfile = VirtualFile(
            path=path,
            file_type=FileType.REGULAR,
            read_handler=read_handler,
            write_handler=write_handler,
            stat=FileStat(st_mode=stat.S_IFREG | 0o644)
        )

        self._files[path] = vfile
        logger.debug(f"Added dynamic file: {path}")
        return vfile

    def symlink(self, path: str, target: str) -> VirtualFile:
        """
        Create a symbolic link.
        
        Args:
            path: Link path
            target: Target path
            
        Returns:
            Created VirtualFile
        """
        path = self._normalize_path(path)

        vfile = VirtualFile(
            path=path,
            file_type=FileType.SYMLINK,
            target=target,
            stat=FileStat(st_mode=stat.S_IFLNK | 0o777)
        )

        self._files[path] = vfile
        logger.debug(f"Created symlink: {path} -> {target}")
        return vfile

    def mkdir(self, path: str, mode: int = 0o755, parents: bool = False) -> VirtualFile:
        """
        Create a directory.
        
        Args:
            path: Directory path
            mode: Directory permissions
            parents: Create parent directories
            
        Returns:
            Created VirtualFile
        """
        path = self._normalize_path(path)

        if parents:
            # Create parent directories
            parts = path.split('/')
            for i in range(2, len(parts) + 1):
                parent_path = '/'.join(parts[:i])
                if parent_path and not self.exists(parent_path):
                    self._create_dir(parent_path, mode)
            if path in self._files:
                return self._files[path]

        return self._create_dir(path, mode)

    def _create_dir(self, path: str, mode: int = 0o755) -> VirtualFile:
        """Create a single directory."""
        if path in self._files:
            return self._files[path]

        vfile = VirtualFile(
            path=path,
            file_type=FileType.DIRECTORY,
            mode=mode,
            stat=FileStat(
                st_mode=stat.S_IFDIR | mode,
                st_ino=self._get_next_inode()
            )
        )

        self._files[path] = vfile
        self._stats.directories_created += 1
        return vfile

    def remove(self, path: str, recursive: bool = False) -> bool:
        """
        Remove a file or directory.
        
        Args:
            path: File path
            recursive: Remove directory recursively
            
        Returns:
            True if removed
        """
        path = self._normalize_path(path)

        if path not in self._files:
            return False

        if recursive:
            # Remove all children
            to_remove = [p for p in self._files if p.startswith(path + '/') or p == path]
            for p in to_remove:
                del self._files[p]
            return True

        del self._files[path]
        return True

    def rename(self, old_path: str, new_path: str) -> bool:
        """
        Rename/move a file.
        
        Args:
            old_path: Current path
            new_path: New path
            
        Returns:
            True if renamed
        """
        old_path = self._normalize_path(old_path)
        new_path = self._normalize_path(new_path)

        if old_path not in self._files:
            return False

        vfile = self._files[old_path]
        vfile.path = new_path
        self._files[new_path] = vfile
        del self._files[old_path]
        return True

    def copy(self, src_path: str, dst_path: str) -> bool:
        """
        Copy a file.
        
        Args:
            src_path: Source path
            dst_path: Destination path
            
        Returns:
            True if copied
        """
        src_path = self._normalize_path(src_path)
        dst_path = self._normalize_path(dst_path)

        if src_path not in self._files:
            return False

        src_file = self._files[src_path]

        # Create copy
        self.create(dst_path, src_file.content, src_file.mode)
        return True

    def append(self, path: str, data: bytes):
        """Append data to a file."""
        path = self._normalize_path(path)
        vfile = self._files.get(path)
        if vfile:
            vfile.append(data)

    def exists(self, path: str) -> bool:
        """Check if path exists."""
        path = self._normalize_path(path)
        return path in self._files

    def is_file(self, path: str) -> bool:
        """Check if path is a regular file."""
        path = self._normalize_path(path)
        if path in self._files:
            return self._files[path].file_type == FileType.REGULAR
        return False

    def is_dir(self, path: str) -> bool:
        """Check if path is a directory."""
        path = self._normalize_path(path)
        if path in self._files:
            return self._files[path].file_type == FileType.DIRECTORY
        return False

    def get(self, path: str) -> VirtualFile | None:
        """Get virtual file by path."""
        path = self._normalize_path(path)
        return self._files.get(path)

    def listdir(self, path: str) -> list[str]:
        """
        List directory contents.
        
        Args:
            path: Directory path
            
        Returns:
            List of file names
        """
        path = self._normalize_path(path)
        if not path.endswith('/'):
            path += '/'

        entries = set()
        for file_path in self._files.keys():
            if file_path.startswith(path) and file_path != path.rstrip('/'):
                # Get immediate child
                remaining = file_path[len(path):]
                child = remaining.split('/')[0]
                if child:
                    entries.add(child)

        return sorted(entries)

    def read(self, path: str) -> bytes:
        """
        Read file content.
        
        Args:
            path: File path
            
        Returns:
            File content
        """
        vfile = self.get(path)
        if vfile:
            return vfile.get_content()

        raise FileNotFoundError(f"No such file: {path}")

    def write(self, path: str, content: bytes):
        """
        Write file content.
        
        Args:
            path: File path
            content: Content to write
        """
        vfile = self.get(path)
        if vfile:
            vfile.set_content(content)
        else:
            self.add_file(path, content)

    # === File Descriptor Operations ===

    def open(self, path: str, flags: int = OpenFlags.O_RDONLY, mode: int = 0o644) -> int:
        """
        Open a file and return file descriptor.
        
        Args:
            path: File path
            flags: Open flags
            mode: Creation mode (if O_CREAT)
            
        Returns:
            File descriptor number
        """
        path = self._normalize_path(path)

        # Check access hooks
        for hook in self._access_hooks:
            result = hook(path, "open")
            if result is not None:
                # Hook provided content
                vfile = self.add_file(path, result)
                break
        else:
            vfile = self._files.get(path)

        # Handle creation
        if vfile is None:
            if flags & OpenFlags.O_CREAT:
                vfile = self.add_file(path, b"", mode)
            else:
                raise FileNotFoundError(f"No such file: {path}")

        # Handle exclusive creation
        if flags & OpenFlags.O_EXCL and path in self._files:
            raise FileExistsError(f"File exists: {path}")

        # Handle truncate
        if flags & OpenFlags.O_TRUNC:
            vfile.set_content(b"")

        # Create file descriptor
        fd_num = self._get_next_fd()
        fd = FileDescriptor(
            fd=fd_num,
            file=vfile,
            flags=flags,
            position=len(vfile.get_content()) if flags & OpenFlags.O_APPEND else 0
        )

        self._fds[fd_num] = fd
        logger.debug(f"Opened {path} as fd {fd_num}")
        return fd_num

    def close(self, fd: int) -> bool:
        """
        Close a file descriptor.
        
        Args:
            fd: File descriptor number
            
        Returns:
            True if closed
        """
        if fd in self._fds:
            self._fds[fd].closed = True
            del self._fds[fd]
            return True
        return False

    def read_fd(self, fd: int, size: int = -1) -> bytes:
        """Read from file descriptor."""
        if fd not in self._fds:
            raise OSError(f"Bad file descriptor: {fd}")

        # Handle device files
        file_desc = self._fds[fd]
        if file_desc.file.device_type:
            return self._read_device(file_desc.file.device_type, size)

        data = file_desc.read(size)
        self._stats.bytes_read += len(data)
        return data

    def _read_device(self, device_type: str, size: int) -> bytes:
        """Read from a device file."""
        if device_type == "null":
            return b""
        elif device_type == "zero":
            return b'\x00' * size
        elif device_type == "random" or device_type == "urandom":
            import random
            return bytes(random.getrandbits(8) for _ in range(size))
        return b""

    def write_fd(self, fd: int, data: bytes) -> int:
        """Write to file descriptor."""
        if fd not in self._fds:
            raise OSError(f"Bad file descriptor: {fd}")

        # Handle device files
        file_desc = self._fds[fd]
        if file_desc.file.device_type == "null":
            return len(data)  # Discard

        written = file_desc.write(data)
        self._stats.bytes_written += written
        return written

    def seek_fd(self, fd: int, offset: int, whence: int = 0) -> int:
        """Seek in file descriptor."""
        if fd not in self._fds:
            raise OSError(f"Bad file descriptor: {fd}")
        return self._fds[fd].seek(offset, whence)

    def tell_fd(self, fd: int) -> int:
        """Get position in file descriptor."""
        if fd not in self._fds:
            raise OSError(f"Bad file descriptor: {fd}")
        return self._fds[fd].tell()

    def stat_path(self, path: str) -> FileStat:
        """Get file statistics."""
        path = self._normalize_path(path)
        vfile = self._files.get(path)
        if vfile:
            return vfile.stat
        raise FileNotFoundError(f"No such file: {path}")

    def stat_fd(self, fd: int) -> FileStat:
        """Get file statistics from file descriptor."""
        if fd not in self._fds:
            raise OSError(f"Bad file descriptor: {fd}")
        return self._fds[fd].file.stat

    def truncate_fd(self, fd: int, size: int):
        """Truncate file to given size."""
        if fd not in self._fds:
            raise OSError(f"Bad file descriptor: {fd}")
        self._fds[fd].file.truncate(size)

    # === Mount Points ===

    def mount(self, virtual_path: str, real_path: str, read_only: bool = False):
        """
        Mount a host directory to a virtual path.
        
        Args:
            virtual_path: Virtual mount point
            real_path: Real host path
            read_only: Mount as read-only
        """
        virtual_path = self._normalize_path(virtual_path)
        self._mounts[virtual_path] = MountPoint(virtual_path, real_path, read_only)
        self.mkdir(virtual_path)

    def umount(self, virtual_path: str):
        """Unmount a path."""
        virtual_path = self._normalize_path(virtual_path)
        self._mounts.pop(virtual_path, None)

    def get_mounts(self) -> list[MountPoint]:
        """Get all mount points."""
        return list(self._mounts.values())

    # === Device Files ===

    def create_device(self, path: str, device_type: str):
        """
        Create a device file.
        
        Args:
            path: Device path
            device_type: Device type (null, zero, random, urandom)
        """
        path = self._normalize_path(path)

        # Ensure parent exists
        parent = str(PurePosixPath(path).parent)
        if not self.exists(parent):
            self.mkdir(parent, parents=True)

        vfile = VirtualFile(
            path=path,
            file_type=FileType.DEVICE,
            device_type=device_type,
            stat=FileStat(st_mode=stat.S_IFCHR | 0o666)
        )
        self._files[path] = vfile

    # === Host File Mapping ===

    def map_host_file(self, virtual_path: str, host_path: str):
        """
        Map a host file to virtual path.
        
        Args:
            virtual_path: Virtual path
            host_path: Host filesystem path
        """
        virtual_path = self._normalize_path(virtual_path)

        # Read host file content
        if os.path.exists(host_path):
            with open(host_path, 'rb') as f:
                content = f.read()
            self.create(virtual_path, content)

    def map_host_dir(self, virtual_path: str, host_path: str):
        """
        Map a host directory to virtual path.
        
        Args:
            virtual_path: Virtual mount point
            host_path: Host directory path
        """
        virtual_path = self._normalize_path(virtual_path)
        self.mkdir(virtual_path, parents=True)
        self._mounts[virtual_path] = MountPoint(virtual_path, host_path)

    # === Stats ===

    def get_stats(self) -> VFSStats:
        """Get VFS statistics."""
        return self._stats

    def reset_stats(self):
        """Reset statistics."""
        self._stats = VFSStats()

    # === Path Redirection ===

    def add_redirect(self, prefix: str, target: str):
        """
        Add path prefix redirect.
        
        Args:
            prefix: Path prefix to match
            target: Target prefix to replace with
        """
        prefix = self._normalize_path(prefix)
        self._redirects[prefix] = target
        logger.debug(f"Added redirect: {prefix} -> {target}")

    def remove_redirect(self, prefix: str):
        """Remove path redirect."""
        prefix = self._normalize_path(prefix)
        self._redirects.pop(prefix, None)

    # === Access Hooks ===

    def add_access_hook(self, hook: Callable[[str, str], bytes | None]):
        """
        Add file access hook.
        
        Hook receives (path, operation) and can return content
        to override file access.
        
        Args:
            hook: Hook function
        """
        self._access_hooks.append(hook)

    def remove_access_hook(self, hook: Callable):
        """Remove access hook."""
        if hook in self._access_hooks:
            self._access_hooks.remove(hook)

    # === Proc/Sys Filesystem Helpers ===

    def setup_proc_filesystem(self, pid: int = 1234):
        """
        Set up /proc filesystem for Android emulation.
        
        Args:
            pid: Process ID to emulate
        """
        # /proc/self -> /proc/{pid}
        self.symlink("/proc/self", f"/proc/{pid}")

        # /proc/{pid}/maps
        self.add_dynamic_file(
            f"/proc/{pid}/maps",
            lambda: self._generate_proc_maps()
        )

        # /proc/{pid}/status
        self.add_file(
            f"/proc/{pid}/status",
            f"""Name:\tapp_process64
State:\tS (sleeping)
Pid:\t{pid}
PPid:\t1
TracerPid:\t0
Uid:\t10000\t10000\t10000\t10000
Gid:\t10000\t10000\t10000\t10000
"""
        )

        # /proc/{pid}/cmdline
        self.add_file(f"/proc/{pid}/cmdline", b"com.example.app\x00")

        # /proc/version
        self.add_file(
            "/proc/version",
            "Linux version 5.10.0 (android@build) (gcc version 10.2.0) #1 SMP"
        )

        # /proc/cpuinfo (ARM64)
        self.add_file("/proc/cpuinfo", """processor\t: 0
BogoMIPS\t: 38.40
Features\t: fp asimd aes pmull sha1 sha2 crc32
CPU implementer\t: 0x41
CPU architecture: 8
CPU variant\t: 0x0
CPU part\t: 0xd03
CPU revision\t: 4
""")

        logger.info(f"Set up /proc filesystem for PID {pid}")

    def _generate_proc_maps(self) -> bytes:
        """Generate /proc/self/maps content."""
        lines = []
        # This would be populated from actual memory mappings
        lines.append("40000000-40001000 r-xp 00000000 00:00 0  [code]\n")
        lines.append("7fff0000-80000000 rw-p 00000000 00:00 0  [stack]\n")
        return ''.join(lines).encode()

    def setup_android_filesystem(self):
        """Set up common Android filesystem structure."""
        # System files
        self.add_file("/system/build.prop", """
ro.build.id=QQ3A.200805.001
ro.build.display.id=QQ3A.200805.001
ro.build.version.sdk=30
ro.build.version.release=11
ro.product.model=Pixel 4
ro.product.brand=google
ro.product.name=flame
ro.product.device=flame
ro.product.cpu.abi=arm64-v8a
""")

        # Default properties
        self.add_file("/default.prop", """
ro.debuggable=0
ro.secure=1
ro.adb.secure=1
""")

        logger.info("Set up Android filesystem structure")

    def setup_ios_filesystem(self):
        """Set up common iOS filesystem structure."""
        # Bundle info
        self.mkdir("/var/containers/Bundle/Application")
        self.mkdir("/var/mobile/Containers/Data/Application")

        # System version
        self.add_file(
            "/System/Library/CoreServices/SystemVersion.plist",
            """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>ProductBuildVersion</key>
    <string>18A373</string>
    <key>ProductName</key>
    <string>iPhone OS</string>
    <key>ProductVersion</key>
    <string>14.0</string>
</dict>
</plist>
"""
        )

        logger.info("Set up iOS filesystem structure")

    # === Alias methods for tests ===

    def setup_procfs(self, cmdline: list[str] | None = None, pid: int = 1234):
        """Set up /proc filesystem (alias for setup_proc_filesystem)."""
        self.mkdir("/proc")
        self.mkdir("/proc/self")

        # Create proc files
        self.add_file("/proc/self/maps", self._generate_proc_maps())

        if cmdline:
            self.add_file("/proc/self/cmdline", '\x00'.join(cmdline).encode() + b'\x00')
        else:
            self.add_file("/proc/self/cmdline", b"program\x00")

        self.add_file("/proc/self/status", f"""Name:\tprogram
Pid:\t{pid}
TracerPid:\t0
""".encode())

    def setup_android(self):
        """Set up Android filesystem structure."""
        android_dirs = [
            "/system",
            "/system/lib",
            "/system/lib64",
            "/data",
            "/data/data",
            "/data/local",
            "/data/local/tmp",
            "/sdcard",
            "/mnt",
            "/mnt/sdcard",
        ]

        for dir_path in android_dirs:
            self.mkdir(dir_path, parents=True)

        self.setup_android_filesystem()

    def setup_linux(self):
        """Set up Linux filesystem structure."""
        linux_dirs = [
            "/bin",
            "/sbin",
            "/etc",
            "/usr",
            "/usr/bin",
            "/usr/lib",
            "/var",
            "/var/log",
            "/tmp",
            "/home",
            "/root",
            "/proc",
            "/sys",
            "/dev",
        ]

        for dir_path in linux_dirs:
            self.mkdir(dir_path, parents=True)

        # Add basic files
        self.add_file("/etc/passwd", b"root:x:0:0:root:/root:/bin/bash\n")
        self.add_file("/etc/hosts", b"127.0.0.1 localhost\n")

    # === Utilities ===

    def get_fs_info(self) -> dict:
        """Get filesystem information (file/dir counts)."""
        total_size = sum(
            len(f.content) for f in self._files.values()
            if f.file_type == FileType.REGULAR
        )

        return {
            'total_files': len([f for f in self._files.values() if f.file_type == FileType.REGULAR]),
            'total_dirs': len([f for f in self._files.values() if f.file_type == FileType.DIRECTORY]),
            'total_symlinks': len([f for f in self._files.values() if f.file_type == FileType.SYMLINK]),
            'total_size': total_size,
            'open_fds': len(self._fds),
            'redirects': len(self._redirects)
        }

    def clear(self):
        """Clear all files and reset state."""
        self._files.clear()
        self._fds.clear()
        self._redirects.clear()
        self._next_fd = 3
        self._init_standard_dirs()
        logger.debug("Filesystem cleared")


# Convenience function
def create_virtual_fs(**kwargs) -> VirtualFS:
    """Create a virtual filesystem."""
    return VirtualFS(**kwargs)
