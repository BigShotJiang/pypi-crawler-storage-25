"""
Dynamic Instrumentation Module for PyUniDbg.

Provides comprehensive dynamic instrumentation capabilities including:
- Function hooking and interception
- Code patching at runtime
- Tracing and profiling
- Memory access monitoring
- Custom callback injection
"""

import logging
import struct
import time
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger(__name__)


class HookType(Enum):
    """Types of hooks that can be installed."""
    FUNCTION_ENTRY = auto()
    FUNCTION_EXIT = auto()
    INSTRUCTION = auto()
    MEMORY_READ = auto()
    MEMORY_WRITE = auto()
    SYSCALL_ENTRY = auto()
    SYSCALL_EXIT = auto()
    EXCEPTION = auto()
    BRANCH = auto()
    CALL = auto()
    RETURN = auto()


class PatchType(Enum):
    """Types of code patches."""
    NOP = auto()
    JUMP = auto()
    CALL = auto()
    DATA = auto()
    TRAMPOLINE = auto()


class TraceLevel(Enum):
    """Tracing verbosity levels."""
    NONE = 0
    CALLS = 1
    BASIC_BLOCKS = 2
    INSTRUCTIONS = 3
    DETAILED = 4


@dataclass
class Hook:
    """Represents an installed hook."""
    id: int
    hook_type: HookType
    address: int
    callback: Callable
    enabled: bool = True
    hit_count: int = 0
    condition: Callable | None = None
    user_data: Any = None

    # For range-based hooks
    end_address: int | None = None

    # Timing
    total_time: float = 0.0
    last_invocation: float = 0.0


@dataclass
class Patch:
    """Represents a code patch."""
    id: int
    address: int
    patch_type: PatchType
    original_bytes: bytes
    patch_bytes: bytes
    enabled: bool = True
    description: str = ""


@dataclass
class TraceEntry:
    """Entry in the execution trace."""
    timestamp: float
    address: int
    instruction: str = ""
    registers: dict[str, int] = field(default_factory=dict)
    memory_accesses: list[tuple[int, int, bool]] = field(default_factory=list)  # addr, size, is_write
    call_depth: int = 0


@dataclass
class FunctionInfo:
    """Information about a hooked function."""
    address: int
    name: str
    entry_hook: Hook | None = None
    exit_hook: Hook | None = None
    call_count: int = 0
    total_time: float = 0.0
    current_entry_time: float = 0.0
    arguments: list[Any] = field(default_factory=list)
    return_value: int | None = None


@dataclass
class MemoryWatchpoint:
    """Memory watchpoint for monitoring access."""
    id: int
    address: int
    size: int
    watch_read: bool = True
    watch_write: bool = True
    callback: Callable | None = None
    enabled: bool = True
    hit_count: int = 0
    condition: Callable | None = None


@dataclass
class ProfileSample:
    """Performance profiling sample."""
    address: int
    count: int = 0
    total_time: float = 0.0
    min_time: float = float('inf')
    max_time: float = 0.0
    call_chain: list[int] = field(default_factory=list)


class InstrumentationEngine:
    """
    Main instrumentation engine providing dynamic analysis capabilities.
    """

    def __init__(self):
        self._next_hook_id = 1
        self._next_patch_id = 1
        self._next_watchpoint_id = 1

        # Hooks by type and address
        self._hooks: dict[int, Hook] = {}
        self._hooks_by_type: dict[HookType, list[int]] = defaultdict(list)
        self._hooks_by_address: dict[int, list[int]] = defaultdict(list)

        # Patches
        self._patches: dict[int, Patch] = {}
        self._patches_by_address: dict[int, int] = {}

        # Memory watchpoints
        self._watchpoints: dict[int, MemoryWatchpoint] = {}
        self._watchpoint_ranges: list[tuple[int, int, int]] = []  # start, end, id

        # Function tracking
        self._functions: dict[int, FunctionInfo] = {}
        self._function_by_name: dict[str, int] = {}

        # Tracing
        self._trace_level = TraceLevel.NONE
        self._trace: list[TraceEntry] = []
        self._trace_enabled = False
        self._max_trace_entries = 100000

        # Profiling
        self._profiling_enabled = False
        self._profile_data: dict[int, ProfileSample] = defaultdict(ProfileSample)

        # Call stack tracking
        self._call_stack: list[int] = []
        self._call_depth = 0

        # Statistics
        self._total_instructions = 0
        self._total_memory_accesses = 0
        self._start_time = 0.0

    # ==================== Hook Management ====================

    def add_hook(
        self,
        hook_type: HookType,
        address: int,
        callback: Callable,
        end_address: int | None = None,
        condition: Callable | None = None,
        user_data: Any = None
    ) -> int:
        """
        Add a hook at the specified address.
        
        Args:
            hook_type: Type of hook
            address: Address to hook
            callback: Function to call when hook is triggered
            end_address: For range hooks, the end address
            condition: Optional condition function
            user_data: User data passed to callback
            
        Returns:
            Hook ID
        """
        hook_id = self._next_hook_id
        self._next_hook_id += 1

        hook = Hook(
            id=hook_id,
            hook_type=hook_type,
            address=address,
            callback=callback,
            end_address=end_address,
            condition=condition,
            user_data=user_data
        )

        self._hooks[hook_id] = hook
        self._hooks_by_type[hook_type].append(hook_id)
        self._hooks_by_address[address].append(hook_id)

        return hook_id

    def remove_hook(self, hook_id: int) -> bool:
        """Remove a hook by ID."""
        if hook_id not in self._hooks:
            return False

        hook = self._hooks[hook_id]

        self._hooks_by_type[hook.hook_type].remove(hook_id)
        self._hooks_by_address[hook.address].remove(hook_id)
        del self._hooks[hook_id]

        return True

    def enable_hook(self, hook_id: int) -> bool:
        """Enable a hook."""
        if hook_id in self._hooks:
            self._hooks[hook_id].enabled = True
            return True
        return False

    def disable_hook(self, hook_id: int) -> bool:
        """Disable a hook."""
        if hook_id in self._hooks:
            self._hooks[hook_id].enabled = False
            return True
        return False

    def get_hook(self, hook_id: int) -> Hook | None:
        """Get hook by ID."""
        return self._hooks.get(hook_id)

    def get_hooks_at_address(self, address: int) -> list[Hook]:
        """Get all hooks at an address."""
        return [self._hooks[hid] for hid in self._hooks_by_address.get(address, [])]

    def get_hooks_by_type(self, hook_type: HookType) -> list[Hook]:
        """Get all hooks of a specific type."""
        return [self._hooks[hid] for hid in self._hooks_by_type.get(hook_type, [])]

    def trigger_hook(
        self,
        address: int,
        hook_type: HookType,
        context: dict[str, Any]
    ) -> list[Any]:
        """
        Trigger hooks at an address.
        
        Args:
            address: Address where execution is
            hook_type: Type of hook to trigger
            context: Context information
            
        Returns:
            List of callback return values
        """
        results = []

        # Get hooks at this address
        for hook_id in self._hooks_by_address.get(address, []):
            hook = self._hooks[hook_id]

            if not hook.enabled:
                continue

            if hook.hook_type != hook_type:
                continue

            # Check condition
            if hook.condition and not hook.condition(context):
                continue

            # Invoke callback
            start_time = time.time()
            try:
                result = hook.callback(address, context, hook.user_data)
                results.append(result)
            except Exception as e:
                results.append(e)

            # Update statistics
            elapsed = time.time() - start_time
            hook.hit_count += 1
            hook.total_time += elapsed
            hook.last_invocation = time.time()

        return results

    # ==================== Function Hooking ====================

    def hook_function(
        self,
        address: int,
        name: str = "",
        on_entry: Callable | None = None,
        on_exit: Callable | None = None
    ) -> int:
        """
        Hook a function for entry/exit tracing.
        
        Args:
            address: Function entry address
            name: Function name (optional)
            on_entry: Callback on function entry
            on_exit: Callback on function exit
            
        Returns:
            Hook ID
        """
        name = name or f"func_{address:x}"

        func_info = FunctionInfo(address=address, name=name)

        if on_entry:
            hook_id = self.add_hook(
                HookType.FUNCTION_ENTRY,
                address,
                lambda addr, ctx, data: self._on_function_entry(addr, ctx, on_entry),
                user_data=func_info
            )
            func_info.entry_hook = self._hooks[hook_id]

        if on_exit:
            hook_id = self.add_hook(
                HookType.FUNCTION_EXIT,
                address,
                lambda addr, ctx, data: self._on_function_exit(addr, ctx, on_exit),
                user_data=func_info
            )
            func_info.exit_hook = self._hooks[hook_id]

        self._functions[address] = func_info
        self._function_by_name[name] = address

        return address

    def _on_function_entry(
        self,
        address: int,
        context: dict[str, Any],
        callback: Callable
    ) -> Any:
        """Handle function entry."""
        func_info = self._functions.get(address)
        if func_info:
            func_info.call_count += 1
            func_info.current_entry_time = time.time()

            # Extract arguments from context
            func_info.arguments = context.get('arguments', [])

        self._call_stack.append(address)
        self._call_depth += 1

        return callback(address, context)

    def _on_function_exit(
        self,
        address: int,
        context: dict[str, Any],
        callback: Callable
    ) -> Any:
        """Handle function exit."""
        func_info = self._functions.get(address)
        if func_info:
            elapsed = time.time() - func_info.current_entry_time
            func_info.total_time += elapsed
            func_info.return_value = context.get('return_value')

        if self._call_stack:
            self._call_stack.pop()
        self._call_depth = max(0, self._call_depth - 1)

        return callback(address, context)

    def get_function_info(self, address: int) -> FunctionInfo | None:
        """Get function info by address."""
        return self._functions.get(address)

    def get_function_by_name(self, name: str) -> FunctionInfo | None:
        """Get function info by name."""
        if name in self._function_by_name:
            return self._functions.get(self._function_by_name[name])
        return None

    # ==================== Code Patching ====================

    def add_patch(
        self,
        address: int,
        patch_bytes: bytes,
        original_bytes: bytes,
        patch_type: PatchType = PatchType.DATA,
        description: str = ""
    ) -> int:
        """
        Add a code patch.
        
        Args:
            address: Address to patch
            patch_bytes: New bytes to write
            original_bytes: Original bytes (for restoration)
            patch_type: Type of patch
            description: Description of the patch
            
        Returns:
            Patch ID
        """
        patch_id = self._next_patch_id
        self._next_patch_id += 1

        patch = Patch(
            id=patch_id,
            address=address,
            patch_type=patch_type,
            original_bytes=original_bytes,
            patch_bytes=patch_bytes,
            description=description
        )

        self._patches[patch_id] = patch
        self._patches_by_address[address] = patch_id

        return patch_id

    def nop_patch(
        self,
        address: int,
        size: int,
        original_bytes: bytes,
        arm64: bool = True
    ) -> int:
        """
        Create a NOP patch.
        
        Args:
            address: Address to patch
            size: Number of bytes to NOP
            original_bytes: Original bytes
            arm64: If True, use ARM64 NOPs (4 bytes each)
            
        Returns:
            Patch ID
        """
        if arm64:
            # ARM64 NOP is 0xD503201F
            nop = bytes([0x1F, 0x20, 0x03, 0xD5])
            num_nops = size // 4
            patch_bytes = nop * num_nops
        else:
            # ARM32 NOP is 0xE320F000 or 0x00 0xBF for Thumb
            patch_bytes = bytes([0x00] * size)

        return self.add_patch(
            address,
            patch_bytes,
            original_bytes,
            PatchType.NOP,
            f"NOP {size} bytes at 0x{address:x}"
        )

    def jump_patch(
        self,
        address: int,
        target: int,
        original_bytes: bytes,
        arm64: bool = True
    ) -> int:
        """
        Create a jump patch.
        
        Args:
            address: Address to patch
            target: Jump target address
            original_bytes: Original bytes
            arm64: If True, create ARM64 jump
            
        Returns:
            Patch ID
        """
        if arm64:
            # B instruction: 0x14 + 26-bit signed offset
            offset = (target - address) >> 2
            if -0x2000000 <= offset < 0x2000000:
                # Direct branch
                insn = 0x14000000 | (offset & 0x3FFFFFF)
                patch_bytes = struct.pack('<I', insn)
            else:
                # Need trampoline for far jumps
                patch_bytes = self._create_far_jump(target)
        else:
            # ARM32 B instruction
            offset = (target - address - 8) >> 2
            insn = 0xEA000000 | (offset & 0xFFFFFF)
            patch_bytes = struct.pack('<I', insn)

        return self.add_patch(
            address,
            patch_bytes,
            original_bytes,
            PatchType.JUMP,
            f"Jump to 0x{target:x}"
        )

    def _create_far_jump(self, target: int) -> bytes:
        """Create trampoline for far jumps."""
        # LDR X16, #8; BR X16; .quad target
        code = bytes([
            0x50, 0x00, 0x00, 0x58,  # LDR X16, #8
            0x00, 0x02, 0x1F, 0xD6,  # BR X16
        ])
        code += struct.pack('<Q', target)
        return code

    def remove_patch(self, patch_id: int) -> bool:
        """Remove a patch by ID."""
        if patch_id not in self._patches:
            return False

        patch = self._patches[patch_id]
        del self._patches_by_address[patch.address]
        del self._patches[patch_id]

        return True

    def enable_patch(self, patch_id: int) -> bool:
        """Enable a patch."""
        if patch_id in self._patches:
            self._patches[patch_id].enabled = True
            return True
        return False

    def disable_patch(self, patch_id: int) -> bool:
        """Disable a patch."""
        if patch_id in self._patches:
            self._patches[patch_id].enabled = False
            return True
        return False

    def get_patch(self, patch_id: int) -> Patch | None:
        """Get patch by ID."""
        return self._patches.get(patch_id)

    def get_patch_at_address(self, address: int) -> Patch | None:
        """Get patch at address."""
        patch_id = self._patches_by_address.get(address)
        if patch_id is not None:
            return self._patches.get(patch_id)
        return None

    # ==================== Memory Watchpoints ====================

    def add_watchpoint(
        self,
        address: int,
        size: int,
        callback: Callable | None = None,
        watch_read: bool = True,
        watch_write: bool = True,
        condition: Callable | None = None
    ) -> int:
        """
        Add a memory watchpoint.
        
        Args:
            address: Start address to watch
            size: Size of memory region
            callback: Function to call on access
            watch_read: Watch read accesses
            watch_write: Watch write accesses
            condition: Optional condition function
            
        Returns:
            Watchpoint ID
        """
        wp_id = self._next_watchpoint_id
        self._next_watchpoint_id += 1

        watchpoint = MemoryWatchpoint(
            id=wp_id,
            address=address,
            size=size,
            callback=callback,
            watch_read=watch_read,
            watch_write=watch_write,
            condition=condition
        )

        self._watchpoints[wp_id] = watchpoint
        self._watchpoint_ranges.append((address, address + size, wp_id))

        return wp_id

    def remove_watchpoint(self, wp_id: int) -> bool:
        """Remove a watchpoint."""
        if wp_id not in self._watchpoints:
            return False

        wp = self._watchpoints[wp_id]
        self._watchpoint_ranges = [
            r for r in self._watchpoint_ranges if r[2] != wp_id
        ]
        del self._watchpoints[wp_id]

        return True

    def check_watchpoint(
        self,
        address: int,
        size: int,
        is_write: bool,
        context: dict[str, Any]
    ) -> list[Any]:
        """
        Check if memory access triggers watchpoints.
        
        Args:
            address: Access address
            size: Access size
            is_write: True if write access
            context: Context information
            
        Returns:
            List of callback results
        """
        results = []
        end_addr = address + size

        for start, end, wp_id in self._watchpoint_ranges:
            if address < end and end_addr > start:
                wp = self._watchpoints.get(wp_id)
                if not wp or not wp.enabled:
                    continue

                if is_write and not wp.watch_write:
                    continue
                if not is_write and not wp.watch_read:
                    continue

                # Check condition
                if wp.condition and not wp.condition(context):
                    continue

                wp.hit_count += 1

                if wp.callback:
                    result = wp.callback(address, size, is_write, context)
                    results.append(result)

        self._total_memory_accesses += 1
        return results

    def get_watchpoint(self, wp_id: int) -> MemoryWatchpoint | None:
        """Get watchpoint by ID."""
        return self._watchpoints.get(wp_id)

    # ==================== Tracing ====================

    def enable_tracing(self, level: TraceLevel = TraceLevel.INSTRUCTIONS) -> None:
        """Enable execution tracing."""
        self._trace_enabled = True
        self._trace_level = level

    def disable_tracing(self) -> None:
        """Disable execution tracing."""
        self._trace_enabled = False

    def clear_trace(self) -> None:
        """Clear trace buffer."""
        self._trace.clear()

    def get_trace(self) -> list[TraceEntry]:
        """Get current trace."""
        return list(self._trace)

    def add_trace_entry(
        self,
        address: int,
        instruction: str = "",
        registers: dict[str, int] = None,
        memory_accesses: list[tuple[int, int, bool]] = None
    ) -> None:
        """Add an entry to the trace."""
        if not self._trace_enabled:
            return

        if len(self._trace) >= self._max_trace_entries:
            self._trace.pop(0)

        entry = TraceEntry(
            timestamp=time.time(),
            address=address,
            instruction=instruction,
            registers=registers or {},
            memory_accesses=memory_accesses or [],
            call_depth=self._call_depth
        )

        self._trace.append(entry)
        self._total_instructions += 1

    def set_max_trace_entries(self, max_entries: int) -> None:
        """Set maximum trace buffer size."""
        self._max_trace_entries = max_entries

    # ==================== Profiling ====================

    def enable_profiling(self) -> None:
        """Enable performance profiling."""
        self._profiling_enabled = True
        self._start_time = time.time()

    def disable_profiling(self) -> None:
        """Disable performance profiling."""
        self._profiling_enabled = False

    def record_sample(self, address: int, elapsed: float) -> None:
        """Record a profiling sample."""
        if not self._profiling_enabled:
            return

        if address not in self._profile_data:
            self._profile_data[address] = ProfileSample(address=address)

        sample = self._profile_data[address]
        sample.count += 1
        sample.total_time += elapsed
        sample.min_time = min(sample.min_time, elapsed)
        sample.max_time = max(sample.max_time, elapsed)
        sample.call_chain = list(self._call_stack[-10:])  # Keep last 10 callers

    def get_profile_data(self) -> dict[int, ProfileSample]:
        """Get all profiling data."""
        return dict(self._profile_data)

    def get_hotspots(self, top_n: int = 10) -> list[ProfileSample]:
        """Get top N hotspots by time."""
        samples = list(self._profile_data.values())
        samples.sort(key=lambda s: s.total_time, reverse=True)
        return samples[:top_n]

    def get_most_called(self, top_n: int = 10) -> list[ProfileSample]:
        """Get top N most called addresses."""
        samples = list(self._profile_data.values())
        samples.sort(key=lambda s: s.count, reverse=True)
        return samples[:top_n]

    def reset_profile(self) -> None:
        """Reset profiling data."""
        self._profile_data.clear()
        self._start_time = time.time()

    # ==================== Convenience Methods ====================

    def intercept(
        self,
        address: int,
        replacement: Callable,
        name: str = ""
    ) -> int:
        """
        Intercept a function and replace with custom implementation.
        
        Args:
            address: Function address
            replacement: Replacement function
            name: Function name
            
        Returns:
            Hook ID
        """
        def wrapper(addr: int, context: dict[str, Any], data: Any) -> Any:
            # Call replacement and skip original
            result = replacement(context)
            context['skip_original'] = True
            context['return_value'] = result
            return result

        return self.add_hook(HookType.FUNCTION_ENTRY, address, wrapper)

    def trace_calls(
        self,
        addresses: list[int],
        callback: Callable | None = None
    ) -> list[int]:
        """
        Trace calls to multiple addresses.
        
        Args:
            addresses: List of addresses to trace
            callback: Optional callback for each call
            
        Returns:
            List of hook IDs
        """
        hook_ids = []

        for addr in addresses:
            def make_callback(a, cb):
                def _callback(address, context, data):
                    if cb:
                        cb(address, context)
                    return None
                return _callback

            hook_id = self.add_hook(
                HookType.CALL,
                addr,
                make_callback(addr, callback)
            )
            hook_ids.append(hook_id)

        return hook_ids

    def log_memory_access(
        self,
        start: int,
        end: int,
        log_callback: Callable
    ) -> int:
        """
        Log all memory accesses in a range.
        
        Args:
            start: Start address
            end: End address
            log_callback: Callback for logging
            
        Returns:
            Watchpoint ID
        """
        def callback(addr, size, is_write, context):
            op = "WRITE" if is_write else "READ"
            log_callback(f"[{op}] 0x{addr:x} size={size}")
            return None

        return self.add_watchpoint(start, end - start, callback)

    # ==================== Statistics ====================

    def get_statistics(self) -> dict[str, Any]:
        """Get instrumentation statistics."""
        elapsed = time.time() - self._start_time if self._start_time else 0

        return {
            'total_hooks': len(self._hooks),
            'enabled_hooks': sum(1 for h in self._hooks.values() if h.enabled),
            'total_patches': len(self._patches),
            'enabled_patches': sum(1 for p in self._patches.values() if p.enabled),
            'total_watchpoints': len(self._watchpoints),
            'enabled_watchpoints': sum(1 for w in self._watchpoints.values() if w.enabled),
            'traced_functions': len(self._functions),
            'trace_entries': len(self._trace),
            'profile_samples': len(self._profile_data),
            'total_instructions': self._total_instructions,
            'total_memory_accesses': self._total_memory_accesses,
            'call_depth': self._call_depth,
            'elapsed_time': elapsed,
        }

    def reset(self) -> None:
        """Reset all instrumentation state."""
        self._hooks.clear()
        self._hooks_by_type.clear()
        self._hooks_by_address.clear()
        self._patches.clear()
        self._patches_by_address.clear()
        self._watchpoints.clear()
        self._watchpoint_ranges.clear()
        self._functions.clear()
        self._function_by_name.clear()
        self._trace.clear()
        self._profile_data.clear()
        self._call_stack.clear()
        self._call_depth = 0
        self._total_instructions = 0
        self._total_memory_accesses = 0

        self._next_hook_id = 1
        self._next_patch_id = 1
        self._next_watchpoint_id = 1


class ScriptEngine:
    """
    Scripting engine for dynamic instrumentation.
    Allows writing instrumentation scripts.
    """

    def __init__(self, instrumentation: InstrumentationEngine):
        self._instrumentation = instrumentation
        self._scripts: dict[str, str] = {}
        self._script_globals: dict[str, Any] = {}

    def register_global(self, name: str, value: Any) -> None:
        """Register a global variable for scripts."""
        self._script_globals[name] = value

    def load_script(self, name: str, script: str) -> None:
        """Load a script."""
        self._scripts[name] = script

    def run_script(self, name: str) -> Any:
        """Run a loaded script."""
        if name not in self._scripts:
            raise ValueError(f"Script not found: {name}")

        script = self._scripts[name]

        # Build execution environment
        env = {
            'engine': self._instrumentation,
            'HookType': HookType,
            'PatchType': PatchType,
            'TraceLevel': TraceLevel,
            **self._script_globals
        }

        # SECURITY: exec() executes arbitrary code — only use with trusted input
        logger.warning("Executing user-provided code via exec() — ensure input is trusted")
        exec(script, env)
        return env.get('result')

    def execute(self, script: str) -> Any:
        """Execute a script directly."""
        env = {
            'engine': self._instrumentation,
            'HookType': HookType,
            'PatchType': PatchType,
            'TraceLevel': TraceLevel,
            **self._script_globals
        }

        # SECURITY: exec() executes arbitrary code — only use with trusted input
        logger.warning("Executing user-provided code via exec() — ensure input is trusted")
        exec(script, env)
        return env.get('result')


def create_instrumentation_engine() -> InstrumentationEngine:
    """Create a new instrumentation engine."""
    return InstrumentationEngine()


def create_script_engine(instrumentation: InstrumentationEngine) -> ScriptEngine:
    """Create a new script engine."""
    return ScriptEngine(instrumentation)


__all__ = [
    # Enums
    'HookType',
    'PatchType',
    'TraceLevel',

    # Data classes
    'Hook',
    'Patch',
    'TraceEntry',
    'FunctionInfo',
    'MemoryWatchpoint',
    'ProfileSample',

    # Main classes
    'InstrumentationEngine',
    'ScriptEngine',

    # Factory functions
    'create_instrumentation_engine',
    'create_script_engine',
]
