"""
Architecture-specific ABI (Application Binary Interface) definitions.

This module provides architecture-specific handling for:
- Calling conventions (argument passing, return values)
- va_list structure parsing
- Stack alignment requirements
- Register usage patterns
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)


class Architecture(Enum):
    """Supported architectures."""
    ARM32 = "arm"
    ARM64 = "arm64"
    X86 = "x86"
    X86_64 = "x86_64"
    MIPS32 = "mips"
    MIPS64 = "mips64"


@dataclass
class ABIConfig:
    """Architecture-specific ABI configuration."""

    # Register-based arguments
    gp_arg_regs: list[str]      # General purpose argument registers
    fp_arg_regs: list[str]      # Floating point argument registers
    return_reg: str             # Return value register
    stack_pointer: str          # Stack pointer register
    link_register: str          # Link/return address register

    # Calling convention
    stack_alignment: int        # Required stack alignment in bytes
    arg_slot_size: int          # Size of each argument slot
    red_zone_size: int          # Size of red zone below SP

    # va_list handling
    va_list_type: str           # "pointer" or "struct"
    va_list_size: int           # Size of va_list in bytes


class VaListParser(ABC):
    """Abstract base class for architecture-specific va_list parsing."""

    @abstractmethod
    def parse(self, emulator: Emulator, va_list_ptr: int,
              arg_types: list[str]) -> list[int]:
        """
        Parse arguments from a va_list.
        
        Args:
            emulator: The emulator instance
            va_list_ptr: Pointer to the va_list
            arg_types: List of argument types ('L' for object, 'I' for int, etc.)
            
        Returns:
            List of argument values
        """
        pass


class ARM32VaListParser(VaListParser):
    """ARM32 va_list parser - simple pointer to stack arguments."""

    def parse(self, emulator: Emulator, va_list_ptr: int,
              arg_types: list[str]) -> list[int]:
        if not va_list_ptr or va_list_ptr < 0x1000:
            return []

        args = []
        offset = 0

        for arg_type in arg_types:
            try:
                if arg_type == 'D':
                    # Double - 8 bytes, 8-byte aligned
                    offset = (offset + 7) & ~7
                    value = emulator.memory.read_u64(va_list_ptr + offset)
                    offset += 8
                elif arg_type == 'J':
                    # Long - 8 bytes, 8-byte aligned
                    offset = (offset + 7) & ~7
                    value = emulator.memory.read_u64(va_list_ptr + offset)
                    offset += 8
                else:
                    # 4-byte value (int, float, object reference)
                    value = emulator.memory.read_u32(va_list_ptr + offset)
                    offset += 4
                args.append(value)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                break

        return args


class ARM64VaListParser(VaListParser):
    """
    ARM64 va_list parser.
    
    ARM64 va_list is a struct:
        struct __va_list {
            void *__stack;      // +0:  Next stack argument
            void *__gr_top;     // +8:  Top of GP register save area
            void *__vr_top;     // +16: Top of FP register save area
            int __gr_offs;      // +24: Offset from gr_top to next GP arg (negative)
            int __vr_offs;      // +28: Offset from vr_top to next FP arg (negative)
        };
    
    GP args (x0-x7) are saved below __gr_top, accessed via negative offset.
    FP args (v0-v7) are saved below __vr_top, accessed via negative offset.
    Additional args are on stack at __stack.
    """

    def parse(self, emulator: Emulator, va_list_ptr: int,
              arg_types: list[str]) -> list[int]:
        if not va_list_ptr or va_list_ptr < 0x1000:
            return []

        try:
            # Read va_list structure
            __stack = emulator.memory.read_u64(va_list_ptr)
            __gr_top = emulator.memory.read_u64(va_list_ptr + 8)
            __vr_top = emulator.memory.read_u64(va_list_ptr + 16)
            __gr_offs_raw = emulator.memory.read_u32(va_list_ptr + 24)
            __vr_offs_raw = emulator.memory.read_u32(va_list_ptr + 28)

            # Convert to signed
            __gr_offs = __gr_offs_raw if __gr_offs_raw < 0x80000000 else __gr_offs_raw - 0x100000000
            __vr_offs = __vr_offs_raw if __vr_offs_raw < 0x80000000 else __vr_offs_raw - 0x100000000
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return []

        args = []
        gr_offset = __gr_offs
        vr_offset = __vr_offs
        stack_offset = 0

        for arg_type in arg_types:
            try:
                if arg_type in 'FD':
                    # Floating point types use VR registers
                    if vr_offset < 0:
                        arg_addr = __vr_top + vr_offset
                        if arg_type == 'F':
                            value = emulator.memory.read_u32(arg_addr)
                        else:
                            value = emulator.memory.read_u64(arg_addr)
                        vr_offset += 16  # VR slots are 16 bytes
                    else:
                        value = emulator.memory.read_u64(__stack + stack_offset)
                        stack_offset += 8
                else:
                    # Integer/object types use GR registers
                    if gr_offset < 0:
                        arg_addr = __gr_top + gr_offset
                        value = emulator.memory.read_u64(arg_addr)
                        gr_offset += 8
                    else:
                        value = emulator.memory.read_u64(__stack + stack_offset)
                        stack_offset += 8
                args.append(value)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                break

        return args


class X86VaListParser(VaListParser):
    """x86 va_list parser - simple pointer to stack."""

    def parse(self, emulator: Emulator, va_list_ptr: int,
              arg_types: list[str]) -> list[int]:
        if not va_list_ptr or va_list_ptr < 0x1000:
            return []

        args = []
        offset = 0

        for arg_type in arg_types:
            try:
                if arg_type in 'DJ':
                    value = emulator.memory.read_u64(va_list_ptr + offset)
                    offset += 8
                else:
                    value = emulator.memory.read_u32(va_list_ptr + offset)
                    offset += 4
                args.append(value)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                break

        return args


class X86_64VaListParser(VaListParser):
    """
    x86_64 va_list parser.
    
    x86_64 va_list is:
        typedef struct {
            unsigned int gp_offset;     // +0: Offset in GP save area
            unsigned int fp_offset;     // +4: Offset in FP save area
            void *overflow_arg_area;    // +8: Pointer to stack args
            void *reg_save_area;        // +16: Pointer to register save area
        } va_list[1];
    """

    def parse(self, emulator: Emulator, va_list_ptr: int,
              arg_types: list[str]) -> list[int]:
        if not va_list_ptr or va_list_ptr < 0x1000:
            return []

        try:
            gp_offset = emulator.memory.read_u32(va_list_ptr)
            fp_offset = emulator.memory.read_u32(va_list_ptr + 4)
            overflow_arg_area = emulator.memory.read_u64(va_list_ptr + 8)
            reg_save_area = emulator.memory.read_u64(va_list_ptr + 16)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return []

        args = []

        for arg_type in arg_types:
            try:
                if arg_type in 'FD':
                    # FP types
                    if fp_offset < 176:  # 6 XMM regs * 16 bytes + 48 GP bytes
                        value = emulator.memory.read_u64(reg_save_area + fp_offset)
                        fp_offset += 16
                    else:
                        value = emulator.memory.read_u64(overflow_arg_area)
                        overflow_arg_area += 8
                else:
                    # GP types
                    if gp_offset < 48:  # 6 GP regs * 8 bytes
                        value = emulator.memory.read_u64(reg_save_area + gp_offset)
                        gp_offset += 8
                    else:
                        value = emulator.memory.read_u64(overflow_arg_area)
                        overflow_arg_area += 8
                args.append(value)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                break

        return args


# ABI configurations for each architecture
ABI_CONFIGS = {
    Architecture.ARM32: ABIConfig(
        gp_arg_regs=['r0', 'r1', 'r2', 'r3'],
        fp_arg_regs=['s0', 's1', 's2', 's3'],
        return_reg='r0',
        stack_pointer='sp',
        link_register='lr',
        stack_alignment=8,
        arg_slot_size=4,
        red_zone_size=0,
        va_list_type='pointer',
        va_list_size=4,
    ),
    Architecture.ARM64: ABIConfig(
        gp_arg_regs=['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7'],
        fp_arg_regs=['v0', 'v1', 'v2', 'v3', 'v4', 'v5', 'v6', 'v7'],
        return_reg='x0',
        stack_pointer='sp',
        link_register='x30',
        stack_alignment=16,
        arg_slot_size=8,
        red_zone_size=0,
        va_list_type='struct',
        va_list_size=32,
    ),
    Architecture.X86: ABIConfig(
        gp_arg_regs=[],  # All args on stack for cdecl
        fp_arg_regs=[],
        return_reg='eax',
        stack_pointer='esp',
        link_register='',  # Return addr on stack
        stack_alignment=16,
        arg_slot_size=4,
        red_zone_size=0,
        va_list_type='pointer',
        va_list_size=4,
    ),
    Architecture.X86_64: ABIConfig(
        gp_arg_regs=['rdi', 'rsi', 'rdx', 'rcx', 'r8', 'r9'],
        fp_arg_regs=['xmm0', 'xmm1', 'xmm2', 'xmm3', 'xmm4', 'xmm5', 'xmm6', 'xmm7'],
        return_reg='rax',
        stack_pointer='rsp',
        link_register='',  # Return addr on stack
        stack_alignment=16,
        arg_slot_size=8,
        red_zone_size=128,
        va_list_type='struct',
        va_list_size=24,
    ),
}

# VA_LIST parsers for each architecture
VA_LIST_PARSERS = {
    Architecture.ARM32: ARM32VaListParser(),
    Architecture.ARM64: ARM64VaListParser(),
    Architecture.X86: X86VaListParser(),
    Architecture.X86_64: X86_64VaListParser(),
}


def get_abi_config(arch: Architecture) -> ABIConfig:
    """Get ABI configuration for an architecture."""
    if arch not in ABI_CONFIGS:
        raise ValueError(f"Unsupported architecture: {arch}")
    return ABI_CONFIGS[arch]


def get_va_list_parser(arch: Architecture) -> VaListParser:
    """Get va_list parser for an architecture."""
    if arch not in VA_LIST_PARSERS:
        raise ValueError(f"Unsupported architecture: {arch}")
    return VA_LIST_PARSERS[arch]


def parse_va_list(emulator: Emulator, va_list_ptr: int,
                  signature: str, arch: Architecture | None = None) -> list[int]:
    """
    Parse va_list arguments based on JNI method signature.
    
    Args:
        emulator: The emulator instance
        va_list_ptr: Pointer to va_list
        signature: JNI signature like "(Ljava/lang/String;I)V"
        arch: Architecture (auto-detected if None)
        
    Returns:
        List of argument values
    """
    from pyunidbg.core.constants import Architecture as CoreArch

    if arch is None:
        # Auto-detect from emulator
        core_arch = emulator.arch
        if core_arch == CoreArch.ARM:
            arch = Architecture.ARM32
        elif core_arch == CoreArch.ARM64:
            arch = Architecture.ARM64
        else:
            raise ValueError(f"Unknown architecture: {core_arch}")

    # Parse argument types from signature
    arg_types = parse_jni_signature_types(signature)

    # Get parser and parse
    parser = get_va_list_parser(arch)
    return parser.parse(emulator, va_list_ptr, arg_types)


def parse_jni_signature_types(signature: str) -> list[str]:
    """
    Parse JNI signature into list of argument types.
    
    Args:
        signature: JNI signature like "(Ljava/lang/String;I)V"
        
    Returns:
        List of type codes: 'L' for object, 'I' for int, etc.
    """
    start = signature.find('(')
    end = signature.find(')')
    if start == -1 or end == -1:
        return []

    arg_sig = signature[start+1:end]
    arg_types = []
    i = 0

    while i < len(arg_sig):
        c = arg_sig[i]
        if c == 'L':
            # Object type - find ending ';'
            j = arg_sig.find(';', i)
            if j == -1:
                break
            arg_types.append('L')
            i = j + 1
        elif c == '[':
            # Array type
            i += 1
            if i < len(arg_sig) and arg_sig[i] == 'L':
                j = arg_sig.find(';', i)
                if j == -1:
                    break
                i = j + 1
            elif i < len(arg_sig):
                i += 1
            arg_types.append('L')  # Arrays are objects
        elif c in 'ZBCSIJFD':
            arg_types.append(c)
            i += 1
        else:
            i += 1

    return arg_types
