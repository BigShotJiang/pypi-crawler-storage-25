"""
PowerPC architecture support for PyUniDbg.

This module provides comprehensive PowerPC emulation support including:
- PowerPC 32-bit and 64-bit modes
- Big and little endian support
- Multiple calling conventions (SVR4, macOS)
- SPR/TBR register access
- Instruction decoding and disassembly
"""

from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum, auto
from typing import Any


class PPCMode(IntEnum):
    """PowerPC operating modes."""
    PPC32 = auto()       # 32-bit PowerPC
    PPC64 = auto()       # 64-bit PowerPC
    PPC32_BE = auto()    # 32-bit big endian (default)
    PPC64_BE = auto()    # 64-bit big endian
    PPC32_LE = auto()    # 32-bit little endian
    PPC64_LE = auto()    # 64-bit little endian

    @property
    def is_64bit(self) -> bool:
        """Check if mode is 64-bit."""
        return self in (PPCMode.PPC64, PPCMode.PPC64_BE, PPCMode.PPC64_LE)

    @property
    def is_big_endian(self) -> bool:
        """Check if mode is big endian."""
        return self in (PPCMode.PPC32, PPCMode.PPC32_BE, PPCMode.PPC64, PPCMode.PPC64_BE)

    @property
    def pointer_size(self) -> int:
        """Get pointer size in bytes."""
        return 8 if self.is_64bit else 4


class PPCCallingConvention(IntEnum):
    """PowerPC calling conventions."""
    SVR4_32 = auto()     # System V R4 ABI (32-bit)
    SVR4_64 = auto()     # System V R4 ABI (64-bit) / ELFv1
    ELFV2 = auto()       # ELF v2 ABI (64-bit little endian)
    MACOS = auto()       # macOS ABI
    AIX = auto()         # AIX ABI
    EABI = auto()        # Embedded ABI


class PPCRegister(IntEnum):
    """PowerPC general purpose registers."""
    # General purpose registers (r0-r31)
    R0 = 0
    R1 = 1    # Stack pointer
    R2 = 2    # TOC pointer (64-bit) / System reserved
    R3 = 3    # First argument / return value
    R4 = 4    # Second argument
    R5 = 5    # Third argument
    R6 = 6    # Fourth argument
    R7 = 7    # Fifth argument
    R8 = 8    # Sixth argument
    R9 = 9    # Seventh argument
    R10 = 10  # Eighth argument
    R11 = 11  # Environment pointer / scratch
    R12 = 12  # Scratch / function linkage
    R13 = 13  # Small data area pointer
    R14 = 14  # Callee-saved
    R15 = 15
    R16 = 16
    R17 = 17
    R18 = 18
    R19 = 19
    R20 = 20
    R21 = 21
    R22 = 22
    R23 = 23
    R24 = 24
    R25 = 25
    R26 = 26
    R27 = 27
    R28 = 28
    R29 = 29
    R30 = 30
    R31 = 31  # Frame pointer / Callee-saved

    # Aliases
    SP = 1    # Stack pointer
    TOC = 2   # Table of Contents
    FP = 31   # Frame pointer

    # Special registers
    PC = 100   # Program counter (pseudo)
    LR = 101   # Link register
    CTR = 102  # Count register
    XER = 103  # Fixed-point exception register
    CR = 104   # Condition register
    MSR = 105  # Machine state register


class PPCSPRRegister(IntEnum):
    """PowerPC Special Purpose Registers."""
    LR = 8      # Link register (SPR 8)
    CTR = 9     # Count register (SPR 9)
    XER = 1     # Fixed-point exception register (SPR 1)
    DSISR = 18  # Data storage interrupt status register
    DAR = 19    # Data address register
    DEC = 22    # Decrementer
    SRR0 = 26   # Machine status save/restore register 0
    SRR1 = 27   # Machine status save/restore register 1
    SPRG0 = 272
    SPRG1 = 273
    SPRG2 = 274
    SPRG3 = 275
    PVR = 287   # Processor version register (read-only)


class PPCConditionRegisterField(IntEnum):
    """Condition register field bits."""
    LT = 0  # Less than
    GT = 1  # Greater than
    EQ = 2  # Equal
    SO = 3  # Summary overflow


class PPCInstructionType(IntEnum):
    """PowerPC instruction formats."""
    I = auto()    # I-form (branch)
    B = auto()    # B-form (branch conditional)
    SC = auto()   # SC-form (system call)
    D = auto()    # D-form (load/store with immediate)
    DS = auto()   # DS-form (64-bit load/store)
    X = auto()    # X-form (extended)
    XL = auto()   # XL-form (extended with link)
    XFX = auto()  # XFX-form (move to/from SPR)
    XFL = auto()  # XFL-form (move to FPSCR)
    XS = auto()   # XS-form (shift)
    XO = auto()   # XO-form (fixed-point)
    A = auto()    # A-form (floating-point)
    M = auto()    # M-form (rotate)
    MD = auto()   # MD-form (64-bit rotate)
    MDS = auto()  # MDS-form (64-bit rotate shift)


@dataclass
class PPCRegisters:
    """PowerPC register state."""
    mode: PPCMode = PPCMode.PPC64

    # General purpose registers
    r0: int = 0
    r1: int = 0   # SP
    r2: int = 0   # TOC
    r3: int = 0
    r4: int = 0
    r5: int = 0
    r6: int = 0
    r7: int = 0
    r8: int = 0
    r9: int = 0
    r10: int = 0
    r11: int = 0
    r12: int = 0
    r13: int = 0
    r14: int = 0
    r15: int = 0
    r16: int = 0
    r17: int = 0
    r18: int = 0
    r19: int = 0
    r20: int = 0
    r21: int = 0
    r22: int = 0
    r23: int = 0
    r24: int = 0
    r25: int = 0
    r26: int = 0
    r27: int = 0
    r28: int = 0
    r29: int = 0
    r30: int = 0
    r31: int = 0

    # Special purpose registers
    pc: int = 0
    lr: int = 0
    ctr: int = 0
    xer: int = 0
    cr: int = 0
    msr: int = 0

    @property
    def _mask(self) -> int:
        """Get the register value mask based on mode."""
        return 0xFFFFFFFFFFFFFFFF if self.mode.is_64bit else 0xFFFFFFFF

    def get(self, reg: PPCRegister) -> int:
        """Get register value."""
        if reg.value <= 31:
            val = getattr(self, f'r{reg.value}')
        elif reg == PPCRegister.PC:
            val = self.pc
        elif reg == PPCRegister.LR:
            val = self.lr
        elif reg == PPCRegister.CTR:
            val = self.ctr
        elif reg == PPCRegister.XER:
            val = self.xer
        elif reg == PPCRegister.CR:
            val = self.cr
        elif reg == PPCRegister.MSR:
            val = self.msr
        else:
            raise ValueError(f"Unknown register: {reg}")
        return val & self._mask

    def set(self, reg: PPCRegister, value: int) -> None:
        """Set register value."""
        value = value & self._mask
        if reg.value <= 31:
            setattr(self, f'r{reg.value}', value)
        elif reg == PPCRegister.PC:
            self.pc = value
        elif reg == PPCRegister.LR:
            self.lr = value
        elif reg == PPCRegister.CTR:
            self.ctr = value
        elif reg == PPCRegister.XER:
            self.xer = value
        elif reg == PPCRegister.CR:
            self.cr = value
        elif reg == PPCRegister.MSR:
            self.msr = value
        else:
            raise ValueError(f"Unknown register: {reg}")

    def get_by_number(self, num: int) -> int:
        """Get GPR by number."""
        if 0 <= num <= 31:
            return getattr(self, f'r{num}') & self._mask
        raise ValueError(f"Invalid GPR number: {num}")

    def set_by_number(self, num: int, value: int) -> None:
        """Set GPR by number."""
        if 0 <= num <= 31:
            setattr(self, f'r{num}', value & self._mask)
        else:
            raise ValueError(f"Invalid GPR number: {num}")

    # Stack pointer alias
    @property
    def sp(self) -> int:
        """Get stack pointer."""
        return self.r1 & self._mask

    @sp.setter
    def sp(self, value: int) -> None:
        """Set stack pointer."""
        self.r1 = value & self._mask

    # TOC alias
    @property
    def toc(self) -> int:
        """Get TOC pointer."""
        return self.r2 & self._mask

    @toc.setter
    def toc(self, value: int) -> None:
        """Set TOC pointer."""
        self.r2 = value & self._mask

    # Frame pointer alias
    @property
    def fp(self) -> int:
        """Get frame pointer."""
        return self.r31 & self._mask

    @fp.setter
    def fp(self, value: int) -> None:
        """Set frame pointer."""
        self.r31 = value & self._mask

    def get_cr_field(self, field_num: int) -> int:
        """Get condition register field (0-7)."""
        if 0 <= field_num <= 7:
            shift = 28 - (field_num * 4)
            return (self.cr >> shift) & 0xF
        raise ValueError(f"Invalid CR field: {field_num}")

    def set_cr_field(self, field_num: int, value: int) -> None:
        """Set condition register field (0-7)."""
        if 0 <= field_num <= 7:
            shift = 28 - (field_num * 4)
            mask = 0xF << shift
            self.cr = (self.cr & ~mask) | ((value & 0xF) << shift)
        else:
            raise ValueError(f"Invalid CR field: {field_num}")

    def get_cr_bit(self, bit_num: int) -> bool:
        """Get condition register bit (0-31)."""
        if 0 <= bit_num <= 31:
            return bool((self.cr >> (31 - bit_num)) & 1)
        raise ValueError(f"Invalid CR bit: {bit_num}")

    def set_cr_bit(self, bit_num: int, value: bool) -> None:
        """Set condition register bit (0-31)."""
        if 0 <= bit_num <= 31:
            if value:
                self.cr |= (1 << (31 - bit_num))
            else:
                self.cr &= ~(1 << (31 - bit_num))
        else:
            raise ValueError(f"Invalid CR bit: {bit_num}")

    def get_xer_so(self) -> bool:
        """Get XER Summary Overflow bit."""
        return bool(self.xer & (1 << 31))

    def get_xer_ov(self) -> bool:
        """Get XER Overflow bit."""
        return bool(self.xer & (1 << 30))

    def get_xer_ca(self) -> bool:
        """Get XER Carry bit."""
        return bool(self.xer & (1 << 29))

    def to_dict(self) -> dict[str, int]:
        """Convert registers to dictionary."""
        result = {}
        for i in range(32):
            result[f'r{i}'] = getattr(self, f'r{i}') & self._mask
        result['pc'] = self.pc & self._mask
        result['lr'] = self.lr & self._mask
        result['ctr'] = self.ctr & self._mask
        result['xer'] = self.xer
        result['cr'] = self.cr
        result['msr'] = self.msr
        return result

    @classmethod
    def from_dict(cls, data: dict[str, int], mode: PPCMode = PPCMode.PPC64) -> 'PPCRegisters':
        """Create registers from dictionary."""
        regs = cls(mode=mode)
        for key, value in data.items():
            if hasattr(regs, key):
                setattr(regs, key, value)
        return regs


@dataclass
class PPCStackFrame:
    """PowerPC stack frame."""
    address: int = 0
    return_address: int = 0
    saved_registers: dict[str, int] = field(default_factory=dict)
    frame_size: int = 0
    locals_size: int = 0
    params_size: int = 0
    back_chain: int = 0
    cr_save: int = 0
    lr_save: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'return_address': self.return_address,
            'saved_registers': self.saved_registers.copy(),
            'frame_size': self.frame_size,
            'locals_size': self.locals_size,
            'params_size': self.params_size,
            'back_chain': self.back_chain,
            'cr_save': self.cr_save,
            'lr_save': self.lr_save,
        }


@dataclass
class PPCStack:
    """PowerPC call stack manager."""
    mode: PPCMode = PPCMode.PPC64
    frames: list[PPCStackFrame] = field(default_factory=list)

    @property
    def pointer_size(self) -> int:
        """Get pointer size based on mode."""
        return 8 if self.mode.is_64bit else 4

    def push_frame(self, frame: PPCStackFrame) -> None:
        """Push a stack frame."""
        self.frames.append(frame)

    def pop_frame(self) -> PPCStackFrame | None:
        """Pop a stack frame."""
        if self.frames:
            return self.frames.pop()
        return None

    def current_frame(self) -> PPCStackFrame | None:
        """Get current (top) stack frame."""
        if self.frames:
            return self.frames[-1]
        return None

    def frame_count(self) -> int:
        """Get number of frames."""
        return len(self.frames)

    def unwind(self, max_frames: int = 100) -> list[PPCStackFrame]:
        """Get stack unwinding (copy of frames)."""
        return list(reversed(self.frames[:max_frames]))


class PPCCallingConventionHandler:
    """Handler for PowerPC calling conventions."""

    ARGUMENT_REGISTERS_32 = [
        PPCRegister.R3, PPCRegister.R4, PPCRegister.R5, PPCRegister.R6,
        PPCRegister.R7, PPCRegister.R8, PPCRegister.R9, PPCRegister.R10,
    ]

    ARGUMENT_REGISTERS_64 = [
        PPCRegister.R3, PPCRegister.R4, PPCRegister.R5, PPCRegister.R6,
        PPCRegister.R7, PPCRegister.R8, PPCRegister.R9, PPCRegister.R10,
    ]

    RETURN_REGISTERS = [PPCRegister.R3, PPCRegister.R4]

    CALLEE_SAVED = [
        PPCRegister.R14, PPCRegister.R15, PPCRegister.R16, PPCRegister.R17,
        PPCRegister.R18, PPCRegister.R19, PPCRegister.R20, PPCRegister.R21,
        PPCRegister.R22, PPCRegister.R23, PPCRegister.R24, PPCRegister.R25,
        PPCRegister.R26, PPCRegister.R27, PPCRegister.R28, PPCRegister.R29,
        PPCRegister.R30, PPCRegister.R31,
    ]

    CALLER_SAVED = [
        PPCRegister.R0, PPCRegister.R3, PPCRegister.R4, PPCRegister.R5,
        PPCRegister.R6, PPCRegister.R7, PPCRegister.R8, PPCRegister.R9,
        PPCRegister.R10, PPCRegister.R11, PPCRegister.R12,
    ]

    def __init__(self, convention: PPCCallingConvention = PPCCallingConvention.SVR4_64,
                 mode: PPCMode = PPCMode.PPC64):
        self.convention = convention
        self.mode = mode

    @property
    def argument_registers(self) -> list[PPCRegister]:
        """Get argument registers for convention."""
        return self.ARGUMENT_REGISTERS_64 if self.mode.is_64bit else self.ARGUMENT_REGISTERS_32

    @property
    def return_registers(self) -> list[PPCRegister]:
        """Get return value registers."""
        return self.RETURN_REGISTERS

    @property
    def callee_saved_registers(self) -> list[PPCRegister]:
        """Get callee-saved registers."""
        return self.CALLEE_SAVED

    @property
    def caller_saved_registers(self) -> list[PPCRegister]:
        """Get caller-saved registers."""
        return self.CALLER_SAVED

    @property
    def stack_alignment(self) -> int:
        """Get stack alignment requirement."""
        if self.mode.is_64bit:
            return 16
        return 16  # PPC32 also typically uses 16-byte alignment

    def setup_call(self, registers: PPCRegisters, args: list[int]) -> int:
        """Set up registers for a function call. Returns stack adjustment needed."""
        arg_regs = self.argument_registers
        stack_args = 0

        for i, arg in enumerate(args):
            if i < len(arg_regs):
                registers.set(arg_regs[i], arg)
            else:
                stack_args += 1

        # Return number of stack arguments (caller needs to push these)
        return stack_args * self.mode.pointer_size

    def extract_arguments(self, registers: PPCRegisters, count: int) -> list[int]:
        """Extract function arguments from registers."""
        args = []
        arg_regs = self.argument_registers

        for i in range(min(count, len(arg_regs))):
            args.append(registers.get(arg_regs[i]))

        return args


@dataclass
class PPCInstruction:
    """PowerPC instruction representation."""
    address: int = 0
    size: int = 4  # PowerPC instructions are always 4 bytes
    mnemonic: str = ''
    operands: str = ''
    bytes: bytes = b''
    inst_type: PPCInstructionType = PPCInstructionType.X

    @property
    def is_branch(self) -> bool:
        """Check if instruction is a branch."""
        return self.mnemonic.startswith('b') and not self.mnemonic.startswith('bl')

    @property
    def is_branch_link(self) -> bool:
        """Check if instruction is a branch and link (call)."""
        return self.mnemonic.startswith('bl')

    @property
    def is_call(self) -> bool:
        """Check if instruction is a call."""
        return self.is_branch_link

    @property
    def is_return(self) -> bool:
        """Check if instruction is a return."""
        # blr = branch to link register
        return self.mnemonic == 'blr'

    @property
    def is_syscall(self) -> bool:
        """Check if instruction is a system call."""
        return self.mnemonic == 'sc'

    @property
    def is_trap(self) -> bool:
        """Check if instruction is a trap."""
        return self.mnemonic.startswith('tw') or self.mnemonic.startswith('td')

    @property
    def is_load(self) -> bool:
        """Check if instruction is a load."""
        load_mnemonics = ('lwz', 'lbz', 'lhz', 'ld', 'lwa', 'lwzu', 'lbzu', 'lhzu',
                          'ldu', 'lfs', 'lfd', 'lmw', 'lwax', 'ldx', 'lhax')
        return self.mnemonic.startswith(load_mnemonics)

    @property
    def is_store(self) -> bool:
        """Check if instruction is a store."""
        store_mnemonics = ('stw', 'stb', 'sth', 'std', 'stwu', 'stbu', 'sthu',
                           'stdu', 'stfs', 'stfd', 'stmw', 'stdx', 'stwx')
        return self.mnemonic.startswith(store_mnemonics)

    @property
    def is_nop(self) -> bool:
        """Check if instruction is a NOP."""
        return self.mnemonic == 'nop' or (self.mnemonic == 'ori' and self.operands == 'r0, r0, 0')

    @property
    def is_compare(self) -> bool:
        """Check if instruction is a compare."""
        return self.mnemonic.startswith('cmp') or self.mnemonic.startswith('cmpl')

    @property
    def is_conditional(self) -> bool:
        """Check if instruction is conditional."""
        # Most conditional branches start with 'b' and have condition suffixes
        return self.inst_type == PPCInstructionType.B

    def __str__(self) -> str:
        """Get string representation."""
        if self.operands:
            return f'{self.mnemonic} {self.operands}'
        return self.mnemonic

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'size': self.size,
            'mnemonic': self.mnemonic,
            'operands': self.operands,
            'bytes': self.bytes.hex(),
            'type': self.inst_type.name,
        }


class PPCInstructionDecoder:
    """PowerPC instruction decoder."""

    def __init__(self, mode: PPCMode = PPCMode.PPC64):
        self.mode = mode

    def decode(self, data: bytes, address: int = 0) -> PPCInstruction | None:
        """Decode a PowerPC instruction."""
        if len(data) < 4:
            return None

        # Extract the instruction bytes
        inst_bytes = data[:4]

        # Parse based on endianness
        if self.mode.is_big_endian:
            inst = int.from_bytes(inst_bytes, 'big')
        else:
            inst = int.from_bytes(inst_bytes, 'little')

        # Extract primary opcode (bits 0-5)
        opcode = (inst >> 26) & 0x3F

        # Decode based on primary opcode
        mnemonic, operands, inst_type = self._decode_opcode(inst, opcode)

        return PPCInstruction(
            address=address,
            size=4,
            mnemonic=mnemonic,
            operands=operands,
            bytes=inst_bytes,
            inst_type=inst_type,
        )

    def _decode_opcode(self, inst: int, opcode: int) -> tuple[str, str, PPCInstructionType]:
        """Decode instruction based on primary opcode."""
        if opcode == 18:  # Branch I-form
            return self._decode_branch_i(inst)
        elif opcode == 16:  # Branch conditional B-form
            return self._decode_branch_b(inst)
        elif opcode == 19:  # XL-form (bclr, bcctr, etc.)
            return self._decode_xl(inst)
        elif opcode == 17:  # System call
            return 'sc', '', PPCInstructionType.SC
        elif opcode in (32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45):  # Load/store D-form
            return self._decode_load_store_d(inst, opcode)
        elif opcode == 31:  # X-form / XO-form
            return self._decode_x_xo(inst)
        elif opcode == 24:  # ori
            return self._decode_ori(inst)
        elif opcode == 14:  # addi
            return self._decode_addi(inst)
        elif opcode == 15:  # addis
            return self._decode_addis(inst)
        else:
            return 'unknown', f'opcode={opcode}', PPCInstructionType.X

    def _decode_branch_i(self, inst: int) -> tuple[str, str, PPCInstructionType]:
        """Decode I-form branch."""
        li = (inst >> 2) & 0xFFFFFF
        aa = (inst >> 1) & 1
        lk = inst & 1

        # Sign extend
        if li & 0x800000:
            li = li - 0x1000000

        target = li << 2

        mnemonic = 'bl' if lk else 'b'
        if aa:
            mnemonic += 'a'

        return mnemonic, hex(target), PPCInstructionType.I

    def _decode_branch_b(self, inst: int) -> tuple[str, str, PPCInstructionType]:
        """Decode B-form conditional branch."""
        bo = (inst >> 21) & 0x1F
        bi = (inst >> 16) & 0x1F
        bd = (inst >> 2) & 0x3FFF
        aa = (inst >> 1) & 1
        lk = inst & 1

        # Sign extend
        if bd & 0x2000:
            bd = bd - 0x4000

        target = bd << 2

        mnemonic = 'bc'
        if lk:
            mnemonic += 'l'
        if aa:
            mnemonic += 'a'

        return mnemonic, f'{bo}, {bi}, {hex(target)}', PPCInstructionType.B

    def _decode_xl(self, inst: int) -> tuple[str, str, PPCInstructionType]:
        """Decode XL-form instructions."""
        xo = (inst >> 1) & 0x3FF
        lk = inst & 1

        if xo == 16:  # bclr
            mnemonic = 'blr' if not lk else 'blrl'
            return mnemonic, '', PPCInstructionType.XL
        elif xo == 528:  # bcctr
            mnemonic = 'bctr' if not lk else 'bctrl'
            return mnemonic, '', PPCInstructionType.XL
        elif xo == 150:  # isync
            return 'isync', '', PPCInstructionType.XL
        else:
            return 'xl_unknown', f'xo={xo}', PPCInstructionType.XL

    def _decode_load_store_d(self, inst: int, opcode: int) -> tuple[str, str, PPCInstructionType]:
        """Decode D-form load/store."""
        rt = (inst >> 21) & 0x1F
        ra = (inst >> 16) & 0x1F
        d = inst & 0xFFFF

        # Sign extend displacement
        if d & 0x8000:
            d = d - 0x10000

        mnemonics = {
            32: 'lwz', 33: 'lwzu', 34: 'lbz', 35: 'lbzu',
            40: 'lhz', 41: 'lhzu', 42: 'lha', 43: 'lhau',
            36: 'stw', 37: 'stwu', 38: 'stb', 39: 'stbu',
            44: 'sth', 45: 'sthu',
        }

        mnemonic = mnemonics.get(opcode, 'ld_st_unknown')
        operands = f'r{rt}, {d}(r{ra})'

        return mnemonic, operands, PPCInstructionType.D

    def _decode_x_xo(self, inst: int) -> tuple[str, str, PPCInstructionType]:
        """Decode X-form and XO-form instructions."""
        xo = (inst >> 1) & 0x3FF
        rt = (inst >> 21) & 0x1F
        ra = (inst >> 16) & 0x1F
        rb = (inst >> 11) & 0x1F
        rc = inst & 1

        # XO-form arithmetic
        if xo == 266:  # add
            mnemonic = 'add.' if rc else 'add'
            return mnemonic, f'r{rt}, r{ra}, r{rb}', PPCInstructionType.XO
        elif xo == 40:  # subf
            mnemonic = 'subf.' if rc else 'subf'
            return mnemonic, f'r{rt}, r{ra}, r{rb}', PPCInstructionType.XO
        elif xo == 235:  # mullw
            mnemonic = 'mullw.' if rc else 'mullw'
            return mnemonic, f'r{rt}, r{ra}, r{rb}', PPCInstructionType.XO
        elif xo == 491:  # divw
            mnemonic = 'divw.' if rc else 'divw'
            return mnemonic, f'r{rt}, r{ra}, r{rb}', PPCInstructionType.XO
        elif xo == 28:  # and
            mnemonic = 'and.' if rc else 'and'
            return mnemonic, f'r{rt}, r{ra}, r{rb}', PPCInstructionType.X
        elif xo == 444:  # or
            mnemonic = 'or.' if rc else 'or'
            return mnemonic, f'r{rt}, r{ra}, r{rb}', PPCInstructionType.X
        elif xo == 316:  # xor
            mnemonic = 'xor.' if rc else 'xor'
            return mnemonic, f'r{rt}, r{ra}, r{rb}', PPCInstructionType.X
        elif xo == 0:  # cmp
            return 'cmp', f'cr{rt >> 2}, r{ra}, r{rb}', PPCInstructionType.X
        elif xo == 32:  # cmpl
            return 'cmpl', f'cr{rt >> 2}, r{ra}, r{rb}', PPCInstructionType.X
        else:
            return 'x_unknown', f'xo={xo}', PPCInstructionType.X

    def _decode_ori(self, inst: int) -> tuple[str, str, PPCInstructionType]:
        """Decode ori instruction."""
        rs = (inst >> 21) & 0x1F
        ra = (inst >> 16) & 0x1F
        ui = inst & 0xFFFF

        if rs == 0 and ra == 0 and ui == 0:
            return 'nop', '', PPCInstructionType.D

        return 'ori', f'r{ra}, r{rs}, {ui}', PPCInstructionType.D

    def _decode_addi(self, inst: int) -> tuple[str, str, PPCInstructionType]:
        """Decode addi instruction."""
        rt = (inst >> 21) & 0x1F
        ra = (inst >> 16) & 0x1F
        si = inst & 0xFFFF

        # Sign extend
        if si & 0x8000:
            si = si - 0x10000

        if ra == 0:
            return 'li', f'r{rt}, {si}', PPCInstructionType.D

        return 'addi', f'r{rt}, r{ra}, {si}', PPCInstructionType.D

    def _decode_addis(self, inst: int) -> tuple[str, str, PPCInstructionType]:
        """Decode addis instruction."""
        rt = (inst >> 21) & 0x1F
        ra = (inst >> 16) & 0x1F
        si = inst & 0xFFFF

        if ra == 0:
            return 'lis', f'r{rt}, {si}', PPCInstructionType.D

        return 'addis', f'r{rt}, r{ra}, {si}', PPCInstructionType.D

    def decode_stream(self, data: bytes, address: int = 0, max_instructions: int = 100) -> list[PPCInstruction]:
        """Decode a stream of instructions."""
        instructions = []
        offset = 0

        while offset < len(data) and len(instructions) < max_instructions:
            inst = self.decode(data[offset:], address + offset)
            if inst is None:
                break
            instructions.append(inst)
            offset += 4  # All PowerPC instructions are 4 bytes

        return instructions

    @staticmethod
    def reg_name(num: int) -> str:
        """Get register name by number."""
        if 0 <= num <= 31:
            return f'r{num}'
        return f'unknown{num}'


class PPCEmulator:
    """PowerPC emulator wrapper."""

    def __init__(self, mode: PPCMode = PPCMode.PPC64,
                 convention: PPCCallingConvention = PPCCallingConvention.SVR4_64):
        self.mode = mode
        self.convention = convention
        self.registers = PPCRegisters(mode=mode)
        self.stack = PPCStack(mode=mode)
        self.cc_handler = PPCCallingConventionHandler(convention, mode)
        self.decoder = PPCInstructionDecoder(mode)

        # Memory regions
        self._memory: dict[int, bytes] = {}
        self._memory_map: dict[int, tuple[int, int]] = {}  # base -> (size, perms)

        # SPR storage
        self._sprs: dict[int, int] = {}

        # Hooks
        self._instruction_hooks: list[Callable] = []
        self._memory_hooks: list[Callable] = []
        self._syscall_hooks: list[Callable] = []

    @property
    def pointer_size(self) -> int:
        """Get pointer size in bytes."""
        return 8 if self.mode.is_64bit else 4

    @property
    def max_address(self) -> int:
        """Get maximum addressable address."""
        return 0xFFFFFFFFFFFFFFFF if self.mode.is_64bit else 0xFFFFFFFF

    def reset(self) -> None:
        """Reset emulator state."""
        self.registers = PPCRegisters(mode=self.mode)
        self.stack = PPCStack(mode=self.mode)
        self._memory.clear()
        self._memory_map.clear()
        self._sprs.clear()

    def map_memory(self, address: int, size: int, perms: int = 7, data: bytes | None = None) -> None:
        """Map memory region."""
        self._memory_map[address] = (size, perms)
        if data:
            self._memory[address] = data
        else:
            self._memory[address] = bytes(size)

    def write_memory(self, address: int, data: bytes) -> None:
        """Write to memory."""
        # Find containing region
        for base, (size, perms) in self._memory_map.items():
            if base <= address < base + size:
                offset = address - base
                current = bytearray(self._memory.get(base, bytes(size)))
                current[offset:offset + len(data)] = data
                self._memory[base] = bytes(current)
                return
        raise ValueError(f"Memory not mapped at {hex(address)}")

    def read_memory(self, address: int, size: int) -> bytes:
        """Read from memory."""
        for base, (mem_size, perms) in self._memory_map.items():
            if base <= address < base + mem_size:
                offset = address - base
                data = self._memory.get(base, bytes(mem_size))
                return data[offset:offset + size]
        raise ValueError(f"Memory not mapped at {hex(address)}")

    def read_spr(self, spr: PPCSPRRegister) -> int:
        """Read special purpose register."""
        # Some SPRs are in registers
        if spr == PPCSPRRegister.LR:
            return self.registers.lr
        elif spr == PPCSPRRegister.CTR:
            return self.registers.ctr
        elif spr == PPCSPRRegister.XER:
            return self.registers.xer
        return self._sprs.get(spr.value, 0)

    def write_spr(self, spr: PPCSPRRegister, value: int) -> None:
        """Write special purpose register."""
        mask = 0xFFFFFFFFFFFFFFFF if self.mode.is_64bit else 0xFFFFFFFF
        value = value & mask

        if spr == PPCSPRRegister.LR:
            self.registers.lr = value
        elif spr == PPCSPRRegister.CTR:
            self.registers.ctr = value
        elif spr == PPCSPRRegister.XER:
            self.registers.xer = value
        else:
            self._sprs[spr.value] = value

    def push(self, value: int) -> None:
        """Push value onto stack."""
        size = self.pointer_size
        self.registers.sp -= size

        if self.mode.is_big_endian:
            data = value.to_bytes(size, 'big')
        else:
            data = value.to_bytes(size, 'little')

        self.write_memory(self.registers.sp, data)

    def pop(self) -> int:
        """Pop value from stack."""
        size = self.pointer_size
        data = self.read_memory(self.registers.sp, size)
        self.registers.sp += size

        if self.mode.is_big_endian:
            return int.from_bytes(data, 'big')
        return int.from_bytes(data, 'little')

    def add_instruction_hook(self, callback: Callable) -> None:
        """Add instruction hook."""
        self._instruction_hooks.append(callback)

    def add_memory_hook(self, callback: Callable) -> None:
        """Add memory access hook."""
        self._memory_hooks.append(callback)

    def add_syscall_hook(self, callback: Callable) -> None:
        """Add system call hook."""
        self._syscall_hooks.append(callback)

    def get_instruction_at(self, address: int) -> PPCInstruction | None:
        """Get instruction at address."""
        try:
            data = self.read_memory(address, 4)
            return self.decoder.decode(data, address)
        except ValueError:
            return None

    def setup_stack(self, stack_base: int, stack_size: int = 0x100000) -> None:
        """Set up the stack region."""
        self.map_memory(stack_base - stack_size, stack_size)
        self.registers.sp = stack_base

        # Initialize back chain to 0 (end of stack)
        if self.mode.is_big_endian:
            self.write_memory(stack_base - self.pointer_size,
                            (0).to_bytes(self.pointer_size, 'big'))
        else:
            self.write_memory(stack_base - self.pointer_size,
                            (0).to_bytes(self.pointer_size, 'little'))

    def call_function(self, address: int, args: list[int]) -> None:
        """Set up a function call."""
        # Set up arguments
        self.cc_handler.setup_call(self.registers, args)

        # Set PC
        self.registers.pc = address

    def get_return_value(self) -> int:
        """Get return value from r3."""
        return self.registers.r3

    def __repr__(self) -> str:
        return f'PPCEmulator(mode={self.mode.name}, convention={self.convention.name})'


def create_ppc_emulator(
    mode: str = 'ppc64',
    convention: str = 'svr4_64',
    endian: str = 'big',
) -> PPCEmulator:
    """Create a PowerPC emulator with specified configuration.
    
    Args:
        mode: 'ppc32' or 'ppc64'
        convention: 'svr4_32', 'svr4_64', 'elfv2', 'macos', 'aix', 'eabi'
        endian: 'big' or 'little'
    
    Returns:
        Configured PPCEmulator instance.
    """
    # Determine mode
    is_64 = mode.lower() == 'ppc64'
    is_le = endian.lower() == 'little'

    if is_64:
        ppc_mode = PPCMode.PPC64_LE if is_le else PPCMode.PPC64_BE
    else:
        ppc_mode = PPCMode.PPC32_LE if is_le else PPCMode.PPC32_BE

    # Determine convention
    convention_map = {
        'svr4_32': PPCCallingConvention.SVR4_32,
        'svr4_64': PPCCallingConvention.SVR4_64,
        'elfv2': PPCCallingConvention.ELFV2,
        'macos': PPCCallingConvention.MACOS,
        'aix': PPCCallingConvention.AIX,
        'eabi': PPCCallingConvention.EABI,
    }

    ppc_convention = convention_map.get(convention.lower())
    if ppc_convention is None:
        raise ValueError(f"Unknown calling convention: {convention}")

    return PPCEmulator(mode=ppc_mode, convention=ppc_convention)
