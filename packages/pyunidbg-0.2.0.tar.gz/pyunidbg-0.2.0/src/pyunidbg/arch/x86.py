"""
x86/x86-64 Architecture Support for PyUniDbg.

Provides comprehensive support for x86 and x86-64 emulation including
registers, calling conventions, and instruction handling.
"""

from __future__ import annotations

import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    pass

try:
    from unicorn import UC_ARCH_X86, UC_MODE_32, UC_MODE_64
    from unicorn.x86_const import *
    UNICORN_AVAILABLE = True
except ImportError:
    UNICORN_AVAILABLE = False
    # Define placeholders
    UC_ARCH_X86 = 4
    UC_MODE_32 = 4
    UC_MODE_64 = 8


class X86Mode(Enum):
    """x86 operating modes."""

    MODE_32 = auto()  # 32-bit protected mode
    MODE_64 = auto()  # 64-bit long mode


class X86CallingConvention(Enum):
    """x86/x86-64 calling conventions."""

    # 32-bit conventions
    CDECL = auto()
    STDCALL = auto()
    FASTCALL = auto()
    THISCALL = auto()

    # 64-bit conventions
    SYSV_AMD64 = auto()
    MS_X64 = auto()


class X86Register(IntEnum):
    """x86-64 register indices."""

    # General purpose registers (64-bit)
    RAX = 0
    RBX = 1
    RCX = 2
    RDX = 3
    RSI = 4
    RDI = 5
    RBP = 6
    RSP = 7
    R8 = 8
    R9 = 9
    R10 = 10
    R11 = 11
    R12 = 12
    R13 = 13
    R14 = 14
    R15 = 15

    # Instruction pointer
    RIP = 16

    # Flags
    RFLAGS = 17

    # Segment registers
    CS = 18
    DS = 19
    ES = 20
    FS = 21
    GS = 22
    SS = 23


class X86Flags:
    """x86 EFLAGS/RFLAGS bits."""

    CF = 1 << 0   # Carry flag
    PF = 1 << 2   # Parity flag
    AF = 1 << 4   # Auxiliary carry flag
    ZF = 1 << 6   # Zero flag
    SF = 1 << 7   # Sign flag
    TF = 1 << 8   # Trap flag
    IF = 1 << 9   # Interrupt enable flag
    DF = 1 << 10  # Direction flag
    OF = 1 << 11  # Overflow flag


@dataclass
class X86Registers:
    """x86-64 register state."""

    # General purpose
    rax: int = 0
    rbx: int = 0
    rcx: int = 0
    rdx: int = 0
    rsi: int = 0
    rdi: int = 0
    rbp: int = 0
    rsp: int = 0
    r8: int = 0
    r9: int = 0
    r10: int = 0
    r11: int = 0
    r12: int = 0
    r13: int = 0
    r14: int = 0
    r15: int = 0

    # Instruction pointer
    rip: int = 0

    # Flags
    rflags: int = 0

    # Segment registers
    cs: int = 0
    ds: int = 0
    es: int = 0
    fs: int = 0
    gs: int = 0
    ss: int = 0

    def get(self, reg: X86Register) -> int:
        """Get register value by enum."""
        return getattr(self, reg.name.lower())

    def set(self, reg: X86Register, value: int) -> None:
        """Set register value by enum."""
        setattr(self, reg.name.lower(), value)

    def get_32bit(self, reg_name: str) -> int:
        """Get 32-bit register value."""
        mapping = {
            'eax': 'rax', 'ebx': 'rbx', 'ecx': 'rcx', 'edx': 'rdx',
            'esi': 'rsi', 'edi': 'rdi', 'ebp': 'rbp', 'esp': 'rsp',
            'eip': 'rip', 'r8d': 'r8', 'r9d': 'r9', 'r10d': 'r10',
            'r11d': 'r11', 'r12d': 'r12', 'r13d': 'r13', 'r14d': 'r14',
            'r15d': 'r15', 'eflags': 'rflags',
        }
        full_reg = mapping.get(reg_name.lower(), reg_name.lower())
        return getattr(self, full_reg, 0) & 0xFFFFFFFF

    def get_16bit(self, reg_name: str) -> int:
        """Get 16-bit register value."""
        mapping = {
            'ax': 'rax', 'bx': 'rbx', 'cx': 'rcx', 'dx': 'rdx',
            'si': 'rsi', 'di': 'rdi', 'bp': 'rbp', 'sp': 'rsp',
            'ip': 'rip', 'flags': 'rflags',
        }
        full_reg = mapping.get(reg_name.lower(), reg_name.lower())
        return getattr(self, full_reg, 0) & 0xFFFF

    def get_8bit(self, reg_name: str) -> int:
        """Get 8-bit register value."""
        mapping_low = {'al': 'rax', 'bl': 'rbx', 'cl': 'rcx', 'dl': 'rdx'}
        mapping_high = {'ah': 'rax', 'bh': 'rbx', 'ch': 'rcx', 'dh': 'rdx'}

        name = reg_name.lower()
        if name in mapping_low:
            return getattr(self, mapping_low[name]) & 0xFF
        elif name in mapping_high:
            return (getattr(self, mapping_high[name]) >> 8) & 0xFF
        return 0

    def get_flag(self, flag: int) -> bool:
        """Check if a flag is set."""
        return (self.rflags & flag) != 0

    def set_flag(self, flag: int, value: bool) -> None:
        """Set or clear a flag."""
        if value:
            self.rflags |= flag
        else:
            self.rflags &= ~flag

    def to_dict(self) -> dict[str, int]:
        """Convert to dictionary."""
        return {
            'rax': self.rax, 'rbx': self.rbx, 'rcx': self.rcx, 'rdx': self.rdx,
            'rsi': self.rsi, 'rdi': self.rdi, 'rbp': self.rbp, 'rsp': self.rsp,
            'r8': self.r8, 'r9': self.r9, 'r10': self.r10, 'r11': self.r11,
            'r12': self.r12, 'r13': self.r13, 'r14': self.r14, 'r15': self.r15,
            'rip': self.rip, 'rflags': self.rflags,
            'cs': self.cs, 'ds': self.ds, 'es': self.es,
            'fs': self.fs, 'gs': self.gs, 'ss': self.ss,
        }

    @classmethod
    def from_dict(cls, data: dict[str, int]) -> X86Registers:
        """Create from dictionary."""
        return cls(**{k: v for k, v in data.items() if hasattr(cls, '__dataclass_fields__') and k in cls.__dataclass_fields__})


@dataclass
class X86StackFrame:
    """Represents a stack frame."""

    return_address: int = 0
    saved_rbp: int = 0
    frame_base: int = 0
    frame_size: int = 0
    locals: dict[int, Any] = field(default_factory=dict)
    arguments: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'return_address': hex(self.return_address),
            'saved_rbp': hex(self.saved_rbp),
            'frame_base': hex(self.frame_base),
            'frame_size': self.frame_size,
            'locals': {hex(k): v for k, v in self.locals.items()},
            'arguments': [hex(a) for a in self.arguments],
        }


class X86Stack:
    """Stack management for x86/x86-64."""

    def __init__(self, mode: X86Mode = X86Mode.MODE_64):
        self.mode = mode
        self.pointer_size = 8 if mode == X86Mode.MODE_64 else 4
        self.frames: list[X86StackFrame] = []

    def push_frame(
        self,
        return_address: int,
        saved_rbp: int,
        frame_base: int,
    ) -> X86StackFrame:
        """Push a new stack frame."""
        frame = X86StackFrame(
            return_address=return_address,
            saved_rbp=saved_rbp,
            frame_base=frame_base,
        )
        self.frames.append(frame)
        return frame

    def pop_frame(self) -> X86StackFrame | None:
        """Pop the current stack frame."""
        if self.frames:
            return self.frames.pop()
        return None

    def current_frame(self) -> X86StackFrame | None:
        """Get the current stack frame."""
        return self.frames[-1] if self.frames else None

    def get_frame_count(self) -> int:
        """Get number of stack frames."""
        return len(self.frames)

    def unwind(self, limit: int = 100) -> list[X86StackFrame]:
        """Get stack frames for unwinding."""
        return self.frames[:limit]


class X86CallingConventionHandler:
    """Handles calling convention operations."""

    def __init__(
        self,
        convention: X86CallingConvention = X86CallingConvention.SYSV_AMD64,
        mode: X86Mode = X86Mode.MODE_64,
    ):
        self.convention = convention
        self.mode = mode
        self.pointer_size = 8 if mode == X86Mode.MODE_64 else 4

    def get_argument_registers(self) -> list[str]:
        """Get registers used for passing arguments."""
        if self.convention == X86CallingConvention.SYSV_AMD64:
            return ['rdi', 'rsi', 'rdx', 'rcx', 'r8', 'r9']
        elif self.convention == X86CallingConvention.MS_X64:
            return ['rcx', 'rdx', 'r8', 'r9']
        elif self.convention == X86CallingConvention.FASTCALL:
            return ['ecx', 'edx']
        elif self.convention == X86CallingConvention.THISCALL:
            return ['ecx']
        else:
            return []

    def get_return_register(self) -> str:
        """Get register used for return value."""
        if self.mode == X86Mode.MODE_64:
            return 'rax'
        return 'eax'

    def get_callee_saved_registers(self) -> list[str]:
        """Get callee-saved registers."""
        if self.convention == X86CallingConvention.SYSV_AMD64:
            return ['rbx', 'rbp', 'r12', 'r13', 'r14', 'r15']
        elif self.convention == X86CallingConvention.MS_X64:
            return ['rbx', 'rbp', 'rdi', 'rsi', 'r12', 'r13', 'r14', 'r15']
        else:
            return ['ebx', 'ebp', 'esi', 'edi']

    def get_caller_cleans_stack(self) -> bool:
        """Check if caller cleans the stack."""
        if self.convention in (X86CallingConvention.CDECL,
                                X86CallingConvention.SYSV_AMD64,
                                X86CallingConvention.MS_X64):
            return True
        return False

    def setup_call(
        self,
        registers: X86Registers,
        arguments: list[int],
        stack_push: Callable[[int], None],
    ) -> None:
        """
        Set up registers and stack for a function call.
        
        Args:
            registers: Current register state.
            arguments: Function arguments.
            stack_push: Function to push values onto stack.
        """
        arg_regs = self.get_argument_registers()

        # Set register arguments
        for i, arg in enumerate(arguments[:len(arg_regs)]):
            setattr(registers, arg_regs[i], arg)

        # Push remaining arguments onto stack (right to left)
        stack_args = arguments[len(arg_regs):]
        for arg in reversed(stack_args):
            stack_push(arg)

    def extract_arguments(
        self,
        registers: X86Registers,
        stack_read: Callable[[int, int], bytes],
        num_args: int,
    ) -> list[int]:
        """
        Extract function arguments from registers and stack.
        
        Args:
            registers: Current register state.
            stack_read: Function to read from stack.
            num_args: Number of arguments to extract.
        
        Returns:
            List of argument values.
        """
        args = []
        arg_regs = self.get_argument_registers()

        # Get register arguments
        for i in range(min(num_args, len(arg_regs))):
            args.append(getattr(registers, arg_regs[i]))

        # Get stack arguments
        stack_offset = self.pointer_size  # Skip return address
        if self.convention == X86CallingConvention.MS_X64:
            stack_offset += 32  # Shadow space

        for i in range(num_args - len(arg_regs)):
            offset = stack_offset + i * self.pointer_size
            data = stack_read(registers.rsp + offset, self.pointer_size)
            if self.pointer_size == 8:
                args.append(struct.unpack('<Q', data)[0])
            else:
                args.append(struct.unpack('<I', data)[0])

        return args


@dataclass
class X86Instruction:
    """Represents an x86 instruction."""

    address: int = 0
    size: int = 0
    mnemonic: str = ""
    operands: str = ""
    bytes: bytes = b""
    prefix: str = ""

    @property
    def is_branch(self) -> bool:
        """Check if instruction is a branch."""
        return self.mnemonic in (
            'jmp', 'je', 'jz', 'jne', 'jnz', 'jg', 'jge', 'jl', 'jle',
            'ja', 'jae', 'jb', 'jbe', 'jo', 'jno', 'js', 'jns', 'jp', 'jnp',
            'jcxz', 'jecxz', 'jrcxz', 'loop', 'loope', 'loopne',
        )

    @property
    def is_call(self) -> bool:
        """Check if instruction is a call."""
        return self.mnemonic == 'call'

    @property
    def is_return(self) -> bool:
        """Check if instruction is a return."""
        return self.mnemonic in ('ret', 'retn', 'retf', 'iret', 'iretd', 'iretq')

    @property
    def is_syscall(self) -> bool:
        """Check if instruction is a syscall."""
        return self.mnemonic in ('syscall', 'sysenter', 'int')

    @property
    def is_nop(self) -> bool:
        """Check if instruction is a NOP."""
        return self.mnemonic == 'nop' or self.bytes == b'\x90'

    @property
    def is_privileged(self) -> bool:
        """Check if instruction is privileged."""
        return self.mnemonic in (
            'cli', 'sti', 'hlt', 'lgdt', 'lidt', 'lldt', 'ltr',
            'in', 'out', 'ins', 'outs', 'rdmsr', 'wrmsr', 'invd', 'wbinvd',
        )

    def to_string(self) -> str:
        """Get instruction string."""
        if self.prefix:
            return f"{self.prefix} {self.mnemonic} {self.operands}".strip()
        return f"{self.mnemonic} {self.operands}".strip()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': hex(self.address),
            'size': self.size,
            'mnemonic': self.mnemonic,
            'operands': self.operands,
            'bytes': self.bytes.hex(),
        }


class X86InstructionDecoder:
    """Decodes x86 instructions."""

    # Common instruction opcodes
    OPCODES = {
        0x90: ('nop', ''),
        0xCC: ('int3', ''),
        0xC3: ('ret', ''),
        0xCB: ('retf', ''),
        0xC9: ('leave', ''),
        0x9C: ('pushfq', ''),
        0x9D: ('popfq', ''),
        0xF4: ('hlt', ''),
    }

    def __init__(self, mode: X86Mode = X86Mode.MODE_64):
        self.mode = mode

    def decode(self, data: bytes, address: int = 0) -> X86Instruction | None:
        """
        Decode an instruction from bytes.
        
        Args:
            data: Instruction bytes.
            address: Instruction address.
        
        Returns:
            Decoded instruction or None.
        """
        if not data:
            return None

        # Handle simple single-byte opcodes
        opcode = data[0]
        if opcode in self.OPCODES:
            mnemonic, operands = self.OPCODES[opcode]
            return X86Instruction(
                address=address,
                size=1,
                mnemonic=mnemonic,
                operands=operands,
                bytes=data[:1],
            )

        # Try to use Capstone if available
        try:
            import capstone
            if self.mode == X86Mode.MODE_64:
                md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
            else:
                md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)

            for insn in md.disasm(data, address):
                return X86Instruction(
                    address=insn.address,
                    size=insn.size,
                    mnemonic=insn.mnemonic,
                    operands=insn.op_str,
                    bytes=insn.bytes,
                )
        except (ImportError, Exception):
            pass

        # Fallback: return raw bytes as instruction
        return X86Instruction(
            address=address,
            size=len(data),
            mnemonic='db',
            operands=', '.join(f'0x{b:02x}' for b in data),
            bytes=data,
        )

    def decode_stream(
        self,
        data: bytes,
        start_address: int = 0,
        max_instructions: int = 100,
    ) -> list[X86Instruction]:
        """
        Decode a stream of instructions.
        
        Args:
            data: Instruction bytes.
            start_address: Start address.
            max_instructions: Maximum instructions to decode.
        
        Returns:
            List of decoded instructions.
        """
        instructions = []
        offset = 0

        while offset < len(data) and len(instructions) < max_instructions:
            insn = self.decode(data[offset:], start_address + offset)
            if insn is None or insn.size == 0:
                break
            instructions.append(insn)
            offset += insn.size

        return instructions


class X86Emulator:
    """x86/x86-64 specific emulator extensions."""

    def __init__(
        self,
        mode: X86Mode = X86Mode.MODE_64,
        convention: X86CallingConvention = X86CallingConvention.SYSV_AMD64,
    ):
        self.mode = mode
        self.registers = X86Registers()
        self.stack = X86Stack(mode)
        self.calling_convention = X86CallingConventionHandler(convention, mode)
        self.decoder = X86InstructionDecoder(mode)

        self.pointer_size = 8 if mode == X86Mode.MODE_64 else 4
        self.max_address = 0xFFFFFFFFFFFFFFFF if mode == X86Mode.MODE_64 else 0xFFFFFFFF

        # Memory regions for emulation
        self._memory: dict[int, bytes] = {}

        # Hooks
        self._instruction_hooks: list[Callable] = []
        self._memory_hooks: list[Callable] = []
        self._syscall_hooks: list[Callable] = []

    def reset(self) -> None:
        """Reset emulator state."""
        self.registers = X86Registers()
        self.stack = X86Stack(self.mode)
        self._memory.clear()

    def map_memory(self, address: int, size: int, data: bytes = b"") -> None:
        """Map memory region."""
        if data:
            self._memory[address] = data.ljust(size, b'\x00')[:size]
        else:
            self._memory[address] = b'\x00' * size

    def read_memory(self, address: int, size: int) -> bytes:
        """Read from memory."""
        for base, data in self._memory.items():
            if base <= address < base + len(data):
                offset = address - base
                return data[offset:offset + size]
        return b'\x00' * size

    def write_memory(self, address: int, data: bytes) -> None:
        """Write to memory."""
        for base, mem in list(self._memory.items()):
            if base <= address < base + len(mem):
                offset = address - base
                self._memory[base] = mem[:offset] + data + mem[offset + len(data):]
                return

    def push(self, value: int) -> None:
        """Push value onto stack."""
        self.registers.rsp -= self.pointer_size
        if self.pointer_size == 8:
            data = struct.pack('<Q', value & self.max_address)
        else:
            data = struct.pack('<I', value & 0xFFFFFFFF)
        self.write_memory(self.registers.rsp, data)

    def pop(self) -> int:
        """Pop value from stack."""
        data = self.read_memory(self.registers.rsp, self.pointer_size)
        self.registers.rsp += self.pointer_size
        if self.pointer_size == 8:
            return struct.unpack('<Q', data)[0]
        return struct.unpack('<I', data)[0]

    def add_instruction_hook(self, callback: Callable) -> None:
        """Add instruction hook."""
        self._instruction_hooks.append(callback)

    def add_memory_hook(self, callback: Callable) -> None:
        """Add memory hook."""
        self._memory_hooks.append(callback)

    def add_syscall_hook(self, callback: Callable) -> None:
        """Add syscall hook."""
        self._syscall_hooks.append(callback)

    def get_instruction_at(self, address: int) -> X86Instruction | None:
        """Get instruction at address."""
        data = self.read_memory(address, 16)
        return self.decoder.decode(data, address)

    def setup_stack(self, base: int, size: int) -> None:
        """Set up the stack."""
        self.map_memory(base - size, size)
        self.registers.rsp = base
        self.registers.rbp = base

    def call_function(
        self,
        address: int,
        arguments: list[int],
        return_address: int = 0xDEADBEEF,
    ) -> None:
        """Set up a function call."""
        # Set up arguments
        self.calling_convention.setup_call(
            self.registers,
            arguments,
            self.push,
        )

        # Push return address
        self.push(return_address)

        # Set instruction pointer
        self.registers.rip = address

        # Push frame
        self.stack.push_frame(return_address, self.registers.rbp, self.registers.rsp)

    def get_return_value(self) -> int:
        """Get return value after function call."""
        return self.registers.rax

    def print_registers(self) -> None:
        """Print register state."""
        print("\n" + "=" * 60)
        print("REGISTER STATE")
        print("=" * 60)

        print(f"RAX: {self.registers.rax:016x}  RBX: {self.registers.rbx:016x}")
        print(f"RCX: {self.registers.rcx:016x}  RDX: {self.registers.rdx:016x}")
        print(f"RSI: {self.registers.rsi:016x}  RDI: {self.registers.rdi:016x}")
        print(f"RBP: {self.registers.rbp:016x}  RSP: {self.registers.rsp:016x}")
        print(f"R8:  {self.registers.r8:016x}  R9:  {self.registers.r9:016x}")
        print(f"R10: {self.registers.r10:016x}  R11: {self.registers.r11:016x}")
        print(f"R12: {self.registers.r12:016x}  R13: {self.registers.r13:016x}")
        print(f"R14: {self.registers.r14:016x}  R15: {self.registers.r15:016x}")
        print(f"RIP: {self.registers.rip:016x}  RFLAGS: {self.registers.rflags:016x}")

        # Print flags
        flags = []
        if self.registers.get_flag(X86Flags.CF): flags.append("CF")
        if self.registers.get_flag(X86Flags.ZF): flags.append("ZF")
        if self.registers.get_flag(X86Flags.SF): flags.append("SF")
        if self.registers.get_flag(X86Flags.OF): flags.append("OF")
        if self.registers.get_flag(X86Flags.PF): flags.append("PF")
        if self.registers.get_flag(X86Flags.AF): flags.append("AF")
        print(f"Flags: {' '.join(flags) if flags else '(none)'}")
        print("=" * 60 + "\n")

    def __repr__(self) -> str:
        return f"X86Emulator(mode={self.mode.name}, rip=0x{self.registers.rip:x})"


def create_x86_emulator(
    mode: str = "64",
    convention: str = "sysv",
) -> X86Emulator:
    """
    Create an x86 emulator.
    
    Args:
        mode: "32" or "64".
        convention: Calling convention name.
    
    Returns:
        Configured X86Emulator.
    """
    x86_mode = X86Mode.MODE_64 if mode == "64" else X86Mode.MODE_32

    convention_map = {
        "sysv": X86CallingConvention.SYSV_AMD64,
        "ms": X86CallingConvention.MS_X64,
        "cdecl": X86CallingConvention.CDECL,
        "stdcall": X86CallingConvention.STDCALL,
        "fastcall": X86CallingConvention.FASTCALL,
        "thiscall": X86CallingConvention.THISCALL,
    }

    cc = convention_map.get(convention.lower(), X86CallingConvention.SYSV_AMD64)

    return X86Emulator(mode=x86_mode, convention=cc)
