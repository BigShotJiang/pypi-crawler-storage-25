"""
RISC-V Architecture Support for PyUniDbg.

Provides comprehensive support for RISC-V emulation including RV32 and RV64
with various extensions (I, M, A, F, D, C).
"""

from __future__ import annotations

import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    pass

try:
    from unicorn import UC_ARCH_RISCV, UC_MODE_RISCV32, UC_MODE_RISCV64
    UNICORN_AVAILABLE = True
except ImportError:
    UNICORN_AVAILABLE = False
    UC_ARCH_RISCV = 8
    UC_MODE_RISCV32 = 4
    UC_MODE_RISCV64 = 8


class RISCVMode(Enum):
    """RISC-V operating modes."""

    RV32 = auto()   # 32-bit mode
    RV64 = auto()   # 64-bit mode
    RV128 = auto()  # 128-bit mode (future)


class RISCVExtension(Enum):
    """RISC-V standard extensions."""

    I = auto()      # Base integer instructions
    M = auto()      # Integer multiplication/division
    A = auto()      # Atomic instructions
    F = auto()      # Single-precision floating-point
    D = auto()      # Double-precision floating-point
    C = auto()      # Compressed instructions
    V = auto()      # Vector extension
    Zicsr = auto()  # CSR instructions
    Zifencei = auto()  # Fence.I instruction


class RISCVPrivilegeLevel(Enum):
    """RISC-V privilege levels."""

    USER = 0        # U-mode
    SUPERVISOR = 1  # S-mode
    MACHINE = 3     # M-mode


class RISCVCallingConvention(Enum):
    """RISC-V calling conventions."""

    LP64 = auto()    # 64-bit pointers
    LP64D = auto()   # 64-bit with double float
    ILP32 = auto()   # 32-bit
    ILP32D = auto()  # 32-bit with double float


class RISCVRegister(IntEnum):
    """RISC-V integer register indices with ABI names."""

    # x0-x31
    ZERO = 0   # x0 - Hard-wired zero
    RA = 1     # x1 - Return address
    SP = 2     # x2 - Stack pointer
    GP = 3     # x3 - Global pointer
    TP = 4     # x4 - Thread pointer
    T0 = 5     # x5 - Temporary
    T1 = 6     # x6 - Temporary
    T2 = 7     # x7 - Temporary
    S0 = 8     # x8 - Saved register / Frame pointer (FP)
    S1 = 9     # x9 - Saved register
    A0 = 10    # x10 - Function argument / Return value
    A1 = 11    # x11 - Function argument / Return value
    A2 = 12    # x12 - Function argument
    A3 = 13    # x13 - Function argument
    A4 = 14    # x14 - Function argument
    A5 = 15    # x15 - Function argument
    A6 = 16    # x16 - Function argument
    A7 = 17    # x17 - Function argument
    S2 = 18    # x18 - Saved register
    S3 = 19    # x19 - Saved register
    S4 = 20    # x20 - Saved register
    S5 = 21    # x21 - Saved register
    S6 = 22    # x22 - Saved register
    S7 = 23    # x23 - Saved register
    S8 = 24    # x24 - Saved register
    S9 = 25    # x25 - Saved register
    S10 = 26   # x26 - Saved register
    S11 = 27   # x27 - Saved register
    T3 = 28    # x28 - Temporary
    T4 = 29    # x29 - Temporary
    T5 = 30    # x30 - Temporary
    T6 = 31    # x31 - Temporary

    # Special
    PC = 32    # Program counter


class RISCVCSR(IntEnum):
    """Common RISC-V CSR (Control and Status Register) addresses."""

    # Machine information
    MVENDORID = 0xF11
    MARCHID = 0xF12
    MIMPID = 0xF13
    MHARTID = 0xF14

    # Machine trap setup
    MSTATUS = 0x300
    MISA = 0x301
    MIE = 0x304
    MTVEC = 0x305

    # Machine trap handling
    MSCRATCH = 0x340
    MEPC = 0x341
    MCAUSE = 0x342
    MTVAL = 0x343
    MIP = 0x344

    # Supervisor trap setup
    SSTATUS = 0x100
    SIE = 0x104
    STVEC = 0x105

    # Supervisor trap handling
    SSCRATCH = 0x140
    SEPC = 0x141
    SCAUSE = 0x142
    STVAL = 0x143
    SIP = 0x144

    # Counters
    CYCLE = 0xC00
    TIME = 0xC01
    INSTRET = 0xC02


@dataclass
class RISCVRegisters:
    """RISC-V register state."""

    # Integer registers x0-x31 (using ABI names)
    zero: int = 0   # x0 - always 0
    ra: int = 0     # x1
    sp: int = 0     # x2
    gp: int = 0     # x3
    tp: int = 0     # x4
    t0: int = 0     # x5
    t1: int = 0     # x6
    t2: int = 0     # x7
    s0: int = 0     # x8 (fp)
    s1: int = 0     # x9
    a0: int = 0     # x10
    a1: int = 0     # x11
    a2: int = 0     # x12
    a3: int = 0     # x13
    a4: int = 0     # x14
    a5: int = 0     # x15
    a6: int = 0     # x16
    a7: int = 0     # x17
    s2: int = 0     # x18
    s3: int = 0     # x19
    s4: int = 0     # x20
    s5: int = 0     # x21
    s6: int = 0     # x22
    s7: int = 0     # x23
    s8: int = 0     # x24
    s9: int = 0     # x25
    s10: int = 0    # x26
    s11: int = 0    # x27
    t3: int = 0     # x28
    t4: int = 0     # x29
    t5: int = 0     # x30
    t6: int = 0     # x31

    # Program counter
    pc: int = 0

    # Register name mappings
    _REG_NAMES: list = field(default_factory=lambda: [
        'zero', 'ra', 'sp', 'gp', 'tp', 't0', 't1', 't2',
        's0', 's1', 'a0', 'a1', 'a2', 'a3', 'a4', 'a5',
        'a6', 'a7', 's2', 's3', 's4', 's5', 's6', 's7',
        's8', 's9', 's10', 's11', 't3', 't4', 't5', 't6',
    ], repr=False)

    def get(self, reg: RISCVRegister) -> int:
        """Get register value by enum."""
        if reg == RISCVRegister.ZERO:
            return 0  # Always return 0 for x0
        return getattr(self, reg.name.lower())

    def set(self, reg: RISCVRegister, value: int) -> None:
        """Set register value by enum."""
        if reg == RISCVRegister.ZERO:
            return  # Cannot write to x0
        setattr(self, reg.name.lower(), value)

    def get_by_number(self, num: int) -> int:
        """Get register value by number (0-31)."""
        if num == 0:
            return 0
        if 0 <= num < len(self._REG_NAMES):
            return getattr(self, self._REG_NAMES[num])
        return 0

    def set_by_number(self, num: int, value: int) -> None:
        """Set register value by number (0-31)."""
        if num == 0:
            return  # Cannot write to x0
        if 0 < num < len(self._REG_NAMES):
            setattr(self, self._REG_NAMES[num], value)

    @property
    def fp(self) -> int:
        """Get frame pointer (alias for s0)."""
        return self.s0

    @fp.setter
    def fp(self, value: int) -> None:
        """Set frame pointer (alias for s0)."""
        self.s0 = value

    def to_dict(self) -> dict[str, int]:
        """Convert to dictionary."""
        result = {name: getattr(self, name) for name in self._REG_NAMES}
        result['pc'] = self.pc
        result['zero'] = 0  # Ensure zero is always 0
        return result

    @classmethod
    def from_dict(cls, data: dict[str, int]) -> RISCVRegisters:
        """Create from dictionary."""
        regs = cls()
        for key, value in data.items():
            if hasattr(regs, key) and key not in ('zero', '_REG_NAMES'):
                setattr(regs, key, value)
        return regs


@dataclass
class RISCVStackFrame:
    """Represents a RISC-V stack frame."""

    return_address: int = 0
    saved_fp: int = 0
    frame_base: int = 0
    frame_size: int = 0
    saved_registers: dict[str, int] = field(default_factory=dict)
    arguments: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'return_address': hex(self.return_address),
            'saved_fp': hex(self.saved_fp),
            'frame_base': hex(self.frame_base),
            'frame_size': self.frame_size,
            'saved_registers': {k: hex(v) for k, v in self.saved_registers.items()},
            'arguments': [hex(a) for a in self.arguments],
        }


class RISCVStack:
    """Stack management for RISC-V."""

    def __init__(self, mode: RISCVMode = RISCVMode.RV64):
        self.mode = mode
        self.pointer_size = 8 if mode == RISCVMode.RV64 else 4
        self.frames: list[RISCVStackFrame] = []

    def push_frame(
        self,
        return_address: int,
        saved_fp: int,
        frame_base: int,
    ) -> RISCVStackFrame:
        """Push a new stack frame."""
        frame = RISCVStackFrame(
            return_address=return_address,
            saved_fp=saved_fp,
            frame_base=frame_base,
        )
        self.frames.append(frame)
        return frame

    def pop_frame(self) -> RISCVStackFrame | None:
        """Pop the current stack frame."""
        if self.frames:
            return self.frames.pop()
        return None

    def current_frame(self) -> RISCVStackFrame | None:
        """Get the current stack frame."""
        return self.frames[-1] if self.frames else None

    def get_frame_count(self) -> int:
        """Get number of stack frames."""
        return len(self.frames)

    def unwind(self, limit: int = 100) -> list[RISCVStackFrame]:
        """Get stack frames for unwinding."""
        return self.frames[:limit]


class RISCVCallingConventionHandler:
    """Handles RISC-V calling convention operations."""

    def __init__(
        self,
        convention: RISCVCallingConvention = RISCVCallingConvention.LP64,
        mode: RISCVMode = RISCVMode.RV64,
    ):
        self.convention = convention
        self.mode = mode
        self.pointer_size = 8 if mode == RISCVMode.RV64 else 4

    def get_argument_registers(self) -> list[str]:
        """Get registers used for passing arguments."""
        return ['a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7']

    def get_return_registers(self) -> list[str]:
        """Get registers used for return values."""
        return ['a0', 'a1']

    def get_callee_saved_registers(self) -> list[str]:
        """Get callee-saved registers."""
        return ['s0', 's1', 's2', 's3', 's4', 's5', 's6', 's7', 's8', 's9', 's10', 's11']

    def get_caller_saved_registers(self) -> list[str]:
        """Get caller-saved registers."""
        return ['ra', 't0', 't1', 't2', 't3', 't4', 't5', 't6', 'a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7']

    def get_stack_alignment(self) -> int:
        """Get required stack alignment in bytes."""
        return 16  # RISC-V requires 16-byte stack alignment

    def setup_call(
        self,
        registers: RISCVRegisters,
        arguments: list[int],
        stack_push: Callable[[int], None],
    ) -> None:
        """Set up registers and stack for a function call."""
        arg_regs = self.get_argument_registers()

        # Set register arguments
        for i, arg in enumerate(arguments[:len(arg_regs)]):
            setattr(registers, arg_regs[i], arg)

        # Push remaining arguments onto stack
        stack_args = arguments[len(arg_regs):]
        for arg in reversed(stack_args):
            stack_push(arg)

    def extract_arguments(
        self,
        registers: RISCVRegisters,
        stack_read: Callable[[int, int], bytes],
        num_args: int,
    ) -> list[int]:
        """Extract function arguments from registers and stack."""
        args = []
        arg_regs = self.get_argument_registers()

        # Get register arguments
        for i in range(min(num_args, len(arg_regs))):
            args.append(getattr(registers, arg_regs[i]))

        # Get stack arguments
        stack_offset = 0
        for i in range(num_args - len(arg_regs)):
            offset = stack_offset + i * self.pointer_size
            data = stack_read(registers.sp + offset, self.pointer_size)
            if self.pointer_size == 8:
                args.append(struct.unpack('<Q', data)[0])
            else:
                args.append(struct.unpack('<I', data)[0])

        return args


class RISCVInstructionType(Enum):
    """RISC-V instruction types."""

    R = auto()  # Register-register
    I = auto()  # Immediate
    S = auto()  # Store
    B = auto()  # Branch
    U = auto()  # Upper immediate
    J = auto()  # Jump
    C = auto()  # Compressed


@dataclass
class RISCVInstruction:
    """Represents a RISC-V instruction."""

    address: int = 0
    size: int = 4
    mnemonic: str = ""
    operands: str = ""
    bytes: bytes = b""
    inst_type: RISCVInstructionType = RISCVInstructionType.R

    @property
    def is_compressed(self) -> bool:
        """Check if instruction is compressed (16-bit)."""
        return self.size == 2

    @property
    def is_branch(self) -> bool:
        """Check if instruction is a branch."""
        return self.mnemonic in (
            'beq', 'bne', 'blt', 'bge', 'bltu', 'bgeu',
            'beqz', 'bnez', 'blez', 'bgez', 'bltz', 'bgtz',
        )

    @property
    def is_jump(self) -> bool:
        """Check if instruction is a jump."""
        return self.mnemonic in ('jal', 'jalr', 'j', 'jr')

    @property
    def is_call(self) -> bool:
        """Check if instruction is a function call."""
        # jal with rd=ra (x1) is a call
        # jalr with rd=ra is also a call
        return self.mnemonic in ('jal', 'jalr') and 'ra' in self.operands

    @property
    def is_return(self) -> bool:
        """Check if instruction is a return."""
        # ret is a pseudo-instruction that expands to jalr x0, ra, 0
        if self.mnemonic == 'ret':
            return True
        # jr ra is also a return
        return self.mnemonic == 'jr' and 'ra' in self.operands

    @property
    def is_ecall(self) -> bool:
        """Check if instruction is an environment call."""
        return self.mnemonic == 'ecall'

    @property
    def is_ebreak(self) -> bool:
        """Check if instruction is an environment break."""
        return self.mnemonic == 'ebreak'

    @property
    def is_nop(self) -> bool:
        """Check if instruction is a NOP."""
        return self.mnemonic == 'nop' or (self.mnemonic == 'addi' and self.operands == 'x0, x0, 0')

    @property
    def is_load(self) -> bool:
        """Check if instruction is a load."""
        return self.mnemonic in ('lb', 'lbu', 'lh', 'lhu', 'lw', 'lwu', 'ld')

    @property
    def is_store(self) -> bool:
        """Check if instruction is a store."""
        return self.mnemonic in ('sb', 'sh', 'sw', 'sd')

    @property
    def is_atomic(self) -> bool:
        """Check if instruction is atomic."""
        return self.mnemonic.startswith('amo') or self.mnemonic in ('lr', 'sc')

    def to_string(self) -> str:
        """Get instruction string."""
        return f"{self.mnemonic} {self.operands}".strip()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': hex(self.address),
            'size': self.size,
            'mnemonic': self.mnemonic,
            'operands': self.operands,
            'bytes': self.bytes.hex(),
            'compressed': self.is_compressed,
        }


class RISCVInstructionDecoder:
    """Decodes RISC-V instructions."""

    # Opcode map (bits 6:0)
    OPCODES = {
        0b0110111: 'lui',
        0b0010111: 'auipc',
        0b1101111: 'jal',
        0b1100111: 'jalr',
        0b1100011: 'branch',
        0b0000011: 'load',
        0b0100011: 'store',
        0b0010011: 'op-imm',
        0b0110011: 'op',
        0b0001111: 'fence',
        0b1110011: 'system',
    }

    # Branch function codes
    BRANCH_FUNCS = {
        0b000: 'beq',
        0b001: 'bne',
        0b100: 'blt',
        0b101: 'bge',
        0b110: 'bltu',
        0b111: 'bgeu',
    }

    # Load function codes
    LOAD_FUNCS = {
        0b000: 'lb',
        0b001: 'lh',
        0b010: 'lw',
        0b011: 'ld',
        0b100: 'lbu',
        0b101: 'lhu',
        0b110: 'lwu',
    }

    # Store function codes
    STORE_FUNCS = {
        0b000: 'sb',
        0b001: 'sh',
        0b010: 'sw',
        0b011: 'sd',
    }

    # Register names
    REG_NAMES = [
        'zero', 'ra', 'sp', 'gp', 'tp', 't0', 't1', 't2',
        's0', 's1', 'a0', 'a1', 'a2', 'a3', 'a4', 'a5',
        'a6', 'a7', 's2', 's3', 's4', 's5', 's6', 's7',
        's8', 's9', 's10', 's11', 't3', 't4', 't5', 't6',
    ]

    def __init__(self, mode: RISCVMode = RISCVMode.RV64):
        self.mode = mode

    def _reg_name(self, num: int) -> str:
        """Get register name from number."""
        if 0 <= num < 32:
            return self.REG_NAMES[num]
        return f"x{num}"

    def _sign_extend(self, value: int, bits: int) -> int:
        """Sign extend a value."""
        sign_bit = 1 << (bits - 1)
        return (value & (sign_bit - 1)) - (value & sign_bit)

    def decode(self, data: bytes, address: int = 0) -> RISCVInstruction | None:
        """Decode a single RISC-V instruction."""
        if len(data) < 2:
            return None

        # Check for compressed instruction
        if (data[0] & 0x03) != 0x03:
            return self._decode_compressed(data[:2], address)

        if len(data) < 4:
            return None

        # Standard 32-bit instruction
        insn_word = struct.unpack('<I', data[:4])[0]
        return self._decode_32bit(insn_word, data[:4], address)

    def _decode_compressed(self, data: bytes, address: int) -> RISCVInstruction:
        """Decode a compressed (16-bit) instruction."""
        insn_word = struct.unpack('<H', data)[0]

        # Basic compressed instruction decode
        op = insn_word & 0x03
        funct3 = (insn_word >> 13) & 0x07

        # c.nop is 0x0001
        if insn_word == 0x0001:
            return RISCVInstruction(
                address=address,
                size=2,
                mnemonic='c.nop',
                operands='',
                bytes=data,
                inst_type=RISCVInstructionType.C,
            )

        # Fallback
        return RISCVInstruction(
            address=address,
            size=2,
            mnemonic='c.unknown',
            operands=f'0x{insn_word:04x}',
            bytes=data,
            inst_type=RISCVInstructionType.C,
        )

    def _decode_32bit(
        self,
        insn_word: int,
        data: bytes,
        address: int,
    ) -> RISCVInstruction:
        """Decode a 32-bit instruction."""
        opcode = insn_word & 0x7F
        rd = (insn_word >> 7) & 0x1F
        funct3 = (insn_word >> 12) & 0x07
        rs1 = (insn_word >> 15) & 0x1F
        rs2 = (insn_word >> 20) & 0x1F
        funct7 = (insn_word >> 25) & 0x7F

        # NOP detection: addi x0, x0, 0
        if insn_word == 0x00000013:
            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic='nop',
                operands='',
                bytes=data,
                inst_type=RISCVInstructionType.I,
            )

        # LUI
        if opcode == 0b0110111:
            imm = insn_word & 0xFFFFF000
            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic='lui',
                operands=f'{self._reg_name(rd)}, 0x{imm >> 12:x}',
                bytes=data,
                inst_type=RISCVInstructionType.U,
            )

        # AUIPC
        if opcode == 0b0010111:
            imm = insn_word & 0xFFFFF000
            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic='auipc',
                operands=f'{self._reg_name(rd)}, 0x{imm >> 12:x}',
                bytes=data,
                inst_type=RISCVInstructionType.U,
            )

        # JAL
        if opcode == 0b1101111:
            imm20 = (insn_word >> 31) & 0x1
            imm10_1 = (insn_word >> 21) & 0x3FF
            imm11 = (insn_word >> 20) & 0x1
            imm19_12 = (insn_word >> 12) & 0xFF
            imm = (imm20 << 20) | (imm19_12 << 12) | (imm11 << 11) | (imm10_1 << 1)
            imm = self._sign_extend(imm, 21)
            target = address + imm

            if rd == 0:
                mnemonic = 'j'
                operands = f'0x{target:x}'
            else:
                mnemonic = 'jal'
                operands = f'{self._reg_name(rd)}, 0x{target:x}'

            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic=mnemonic,
                operands=operands,
                bytes=data,
                inst_type=RISCVInstructionType.J,
            )

        # JALR
        if opcode == 0b1100111:
            imm = self._sign_extend((insn_word >> 20) & 0xFFF, 12)

            if rd == 0 and rs1 == 1 and imm == 0:
                return RISCVInstruction(
                    address=address,
                    size=4,
                    mnemonic='ret',
                    operands='',
                    bytes=data,
                    inst_type=RISCVInstructionType.I,
                )

            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic='jalr',
                operands=f'{self._reg_name(rd)}, {self._reg_name(rs1)}, {imm}',
                bytes=data,
                inst_type=RISCVInstructionType.I,
            )

        # Branch
        if opcode == 0b1100011:
            imm12 = (insn_word >> 31) & 0x1
            imm10_5 = (insn_word >> 25) & 0x3F
            imm4_1 = (insn_word >> 8) & 0xF
            imm11 = (insn_word >> 7) & 0x1
            imm = (imm12 << 12) | (imm11 << 11) | (imm10_5 << 5) | (imm4_1 << 1)
            imm = self._sign_extend(imm, 13)
            target = address + imm
            mnemonic = self.BRANCH_FUNCS.get(funct3, 'b.unknown')

            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic=mnemonic,
                operands=f'{self._reg_name(rs1)}, {self._reg_name(rs2)}, 0x{target:x}',
                bytes=data,
                inst_type=RISCVInstructionType.B,
            )

        # Load
        if opcode == 0b0000011:
            imm = self._sign_extend((insn_word >> 20) & 0xFFF, 12)
            mnemonic = self.LOAD_FUNCS.get(funct3, 'l.unknown')

            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic=mnemonic,
                operands=f'{self._reg_name(rd)}, {imm}({self._reg_name(rs1)})',
                bytes=data,
                inst_type=RISCVInstructionType.I,
            )

        # Store
        if opcode == 0b0100011:
            imm11_5 = (insn_word >> 25) & 0x7F
            imm4_0 = (insn_word >> 7) & 0x1F
            imm = self._sign_extend((imm11_5 << 5) | imm4_0, 12)
            mnemonic = self.STORE_FUNCS.get(funct3, 's.unknown')

            return RISCVInstruction(
                address=address,
                size=4,
                mnemonic=mnemonic,
                operands=f'{self._reg_name(rs2)}, {imm}({self._reg_name(rs1)})',
                bytes=data,
                inst_type=RISCVInstructionType.S,
            )

        # System instructions
        if opcode == 0b1110011:
            if insn_word == 0x00000073:
                return RISCVInstruction(
                    address=address,
                    size=4,
                    mnemonic='ecall',
                    operands='',
                    bytes=data,
                    inst_type=RISCVInstructionType.I,
                )
            elif insn_word == 0x00100073:
                return RISCVInstruction(
                    address=address,
                    size=4,
                    mnemonic='ebreak',
                    operands='',
                    bytes=data,
                    inst_type=RISCVInstructionType.I,
                )

        # Fallback
        return RISCVInstruction(
            address=address,
            size=4,
            mnemonic='unknown',
            operands=f'0x{insn_word:08x}',
            bytes=data,
            inst_type=RISCVInstructionType.R,
        )

    def decode_stream(
        self,
        data: bytes,
        start_address: int = 0,
        max_instructions: int = 100,
    ) -> list[RISCVInstruction]:
        """Decode a stream of instructions."""
        instructions = []
        offset = 0

        while offset < len(data) and len(instructions) < max_instructions:
            insn = self.decode(data[offset:], start_address + offset)
            if insn is None:
                break
            instructions.append(insn)
            offset += insn.size

        return instructions


class RISCVEmulator:
    """RISC-V specific emulator extensions."""

    def __init__(
        self,
        mode: RISCVMode = RISCVMode.RV64,
        convention: RISCVCallingConvention = RISCVCallingConvention.LP64,
        extensions: set[RISCVExtension] | None = None,
    ):
        self.mode = mode
        self.registers = RISCVRegisters()
        self.stack = RISCVStack(mode)
        self.calling_convention = RISCVCallingConventionHandler(convention, mode)
        self.decoder = RISCVInstructionDecoder(mode)

        self.extensions = extensions or {
            RISCVExtension.I,
            RISCVExtension.M,
            RISCVExtension.A,
        }

        self.pointer_size = 8 if mode == RISCVMode.RV64 else 4
        self.max_address = 0xFFFFFFFFFFFFFFFF if self.pointer_size == 8 else 0xFFFFFFFF

        # CSR registers
        self.csrs: dict[int, int] = {}

        # Memory regions
        self._memory: dict[int, bytes] = {}

        # Hooks
        self._instruction_hooks: list[Callable] = []
        self._memory_hooks: list[Callable] = []
        self._ecall_hooks: list[Callable] = []

    def reset(self) -> None:
        """Reset emulator state."""
        self.registers = RISCVRegisters()
        self.stack = RISCVStack(self.mode)
        self.csrs.clear()
        self._memory.clear()

    def has_extension(self, ext: RISCVExtension) -> bool:
        """Check if an extension is enabled."""
        return ext in self.extensions

    def map_memory(self, address: int, size: int, data: bytes = b"") -> None:
        """Map memory region."""
        if data:
            self._memory[address] = data.ljust(size, b'\x00')[:size]
        else:
            self._memory[address] = b'\x00' * size

    def read_memory(self, address: int, size: int) -> bytes:
        """Read from memory."""
        for base, data in self._memory.items():
            if base <= address < base + len(data):
                offset = address - base
                return data[offset:offset + size]
        return b'\x00' * size

    def write_memory(self, address: int, data: bytes) -> None:
        """Write to memory."""
        for base, mem in list(self._memory.items()):
            if base <= address < base + len(mem):
                offset = address - base
                self._memory[base] = mem[:offset] + data + mem[offset + len(data):]
                return

    def read_csr(self, csr: int) -> int:
        """Read a CSR."""
        return self.csrs.get(csr, 0)

    def write_csr(self, csr: int, value: int) -> None:
        """Write a CSR."""
        self.csrs[csr] = value & self.max_address

    def push(self, value: int) -> None:
        """Push value onto stack."""
        self.registers.sp -= self.pointer_size
        if self.pointer_size == 8:
            data = struct.pack('<Q', value & self.max_address)
        else:
            data = struct.pack('<I', value & 0xFFFFFFFF)
        self.write_memory(self.registers.sp, data)

    def pop(self) -> int:
        """Pop value from stack."""
        data = self.read_memory(self.registers.sp, self.pointer_size)
        self.registers.sp += self.pointer_size
        if self.pointer_size == 8:
            return struct.unpack('<Q', data)[0]
        return struct.unpack('<I', data)[0]

    def add_instruction_hook(self, callback: Callable) -> None:
        """Add instruction hook."""
        self._instruction_hooks.append(callback)

    def add_memory_hook(self, callback: Callable) -> None:
        """Add memory hook."""
        self._memory_hooks.append(callback)

    def add_ecall_hook(self, callback: Callable) -> None:
        """Add ecall hook."""
        self._ecall_hooks.append(callback)

    def get_instruction_at(self, address: int) -> RISCVInstruction | None:
        """Get instruction at address."""
        data = self.read_memory(address, 4)
        return self.decoder.decode(data, address)

    def setup_stack(self, base: int, size: int) -> None:
        """Set up the stack."""
        # Align to 16 bytes as required by RISC-V ABI
        aligned_base = base & ~0xF
        self.map_memory(aligned_base - size, size)
        self.registers.sp = aligned_base
        self.registers.s0 = aligned_base  # fp = s0

    def call_function(
        self,
        address: int,
        arguments: list[int],
        return_address: int = 0xDEADBEEF,
    ) -> None:
        """Set up a function call."""
        # Set return address
        self.registers.ra = return_address

        # Set up arguments
        self.calling_convention.setup_call(
            self.registers,
            arguments,
            self.push,
        )

        # Set program counter
        self.registers.pc = address

        # Push frame
        self.stack.push_frame(return_address, self.registers.s0, self.registers.sp)

    def get_return_value(self) -> int:
        """Get return value after function call."""
        return self.registers.a0

    def get_misa(self) -> int:
        """Get MISA CSR value representing extensions."""
        misa = 0

        # Set XLEN
        if self.mode == RISCVMode.RV64:
            misa |= 2 << 62  # MXL = 2 for RV64
        else:
            misa |= 1 << 30  # MXL = 1 for RV32

        # Set extension bits
        ext_map = {
            RISCVExtension.I: 1 << 8,
            RISCVExtension.M: 1 << 12,
            RISCVExtension.A: 1 << 0,
            RISCVExtension.F: 1 << 5,
            RISCVExtension.D: 1 << 3,
            RISCVExtension.C: 1 << 2,
            RISCVExtension.V: 1 << 21,
        }

        for ext in self.extensions:
            if ext in ext_map:
                misa |= ext_map[ext]

        return misa

    def print_registers(self) -> None:
        """Print register state."""
        print("\n" + "=" * 60)
        print("RISC-V REGISTER STATE")
        print("=" * 60)

        fmt = "{:>4}: {:08x}" if self.pointer_size == 4 else "{:>4}: {:016x}"

        for i in range(0, 32, 4):
            regs = []
            for j in range(4):
                name = RISCVInstructionDecoder.REG_NAMES[i + j]
                val = self.registers.get_by_number(i + j)
                regs.append(fmt.format(name, val))
            print("  ".join(regs))

        print(f"\n  PC: {self.registers.pc:016x}")
        print("=" * 60 + "\n")

    def __repr__(self) -> str:
        exts = ''.join(e.name for e in sorted(self.extensions, key=lambda x: x.value))
        return f"RISCVEmulator(mode={self.mode.name}, extensions={exts}, pc=0x{self.registers.pc:x})"


def create_riscv_emulator(
    mode: str = "64",
    convention: str = "lp64",
    extensions: list[str] | None = None,
) -> RISCVEmulator:
    """
    Create a RISC-V emulator.
    
    Args:
        mode: "32" or "64".
        convention: Calling convention name.
        extensions: List of extension names to enable.
    
    Returns:
        Configured RISCVEmulator.
    """
    riscv_mode = RISCVMode.RV64 if mode == "64" else RISCVMode.RV32

    convention_map = {
        "lp64": RISCVCallingConvention.LP64,
        "lp64d": RISCVCallingConvention.LP64D,
        "ilp32": RISCVCallingConvention.ILP32,
        "ilp32d": RISCVCallingConvention.ILP32D,
    }

    cc = convention_map.get(convention.lower(), RISCVCallingConvention.LP64)

    # Parse extensions
    ext_set = {RISCVExtension.I}  # I is always required
    if extensions:
        ext_map = {
            'i': RISCVExtension.I,
            'm': RISCVExtension.M,
            'a': RISCVExtension.A,
            'f': RISCVExtension.F,
            'd': RISCVExtension.D,
            'c': RISCVExtension.C,
            'v': RISCVExtension.V,
        }
        for ext in extensions:
            if ext.lower() in ext_map:
                ext_set.add(ext_map[ext.lower()])
    else:
        # Default: IMAC
        ext_set = {RISCVExtension.I, RISCVExtension.M, RISCVExtension.A, RISCVExtension.C}

    return RISCVEmulator(mode=riscv_mode, convention=cc, extensions=ext_set)
