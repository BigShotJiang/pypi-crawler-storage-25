"""
Architecture-specific modules for PyUniDbg.

Provides ABI definitions, calling conventions, and platform-specific
handling for different CPU architectures.
"""

from pyunidbg.arch.abi import (
    ABI_CONFIGS,
    VA_LIST_PARSERS,
    ABIConfig,
    Architecture,
    VaListParser,
    get_abi_config,
    get_va_list_parser,
    parse_jni_signature_types,
    parse_va_list,
)

__all__ = [
    'Architecture',
    'ABIConfig',
    'VaListParser',
    'get_abi_config',
    'get_va_list_parser',
    'parse_va_list',
    'parse_jni_signature_types',
    'ABI_CONFIGS',
    'VA_LIST_PARSERS',
]
