"""
MIPS Architecture Support for PyUniDbg.

Provides comprehensive support for MIPS32 and MIPS64 emulation including
registers, calling conventions, and instruction handling.
"""

from __future__ import annotations

import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    pass

try:
    from unicorn import UC_ARCH_MIPS, UC_MODE_32, UC_MODE_64, UC_MODE_BIG_ENDIAN
    from unicorn.mips_const import *
    UNICORN_AVAILABLE = True
except ImportError:
    UNICORN_AVAILABLE = False
    UC_ARCH_MIPS = 2
    UC_MODE_32 = 4
    UC_MODE_64 = 8
    UC_MODE_BIG_ENDIAN = 0x40000000


class MIPSMode(Enum):
    """MIPS operating modes."""

    MIPS32 = auto()      # 32-bit mode
    MIPS64 = auto()      # 64-bit mode
    MIPS32_BE = auto()   # 32-bit big endian
    MIPS64_BE = auto()   # 64-bit big endian


class MIPSCallingConvention(Enum):
    """MIPS calling conventions."""

    O32 = auto()     # Original 32-bit ABI
    N32 = auto()     # New 32-bit ABI
    N64 = auto()     # 64-bit ABI
    EABI = auto()    # Embedded ABI


class MIPSRegister(IntEnum):
    """MIPS register indices."""

    # General purpose registers
    ZERO = 0   # Always zero
    AT = 1     # Assembler temporary
    V0 = 2     # Return value 0
    V1 = 3     # Return value 1
    A0 = 4     # Argument 0
    A1 = 5     # Argument 1
    A2 = 6     # Argument 2
    A3 = 7     # Argument 3
    T0 = 8     # Temporary 0
    T1 = 9     # Temporary 1
    T2 = 10    # Temporary 2
    T3 = 11    # Temporary 3
    T4 = 12    # Temporary 4
    T5 = 13    # Temporary 5
    T6 = 14    # Temporary 6
    T7 = 15    # Temporary 7
    S0 = 16    # Saved 0
    S1 = 17    # Saved 1
    S2 = 18    # Saved 2
    S3 = 19    # Saved 3
    S4 = 20    # Saved 4
    S5 = 21    # Saved 5
    S6 = 22    # Saved 6
    S7 = 23    # Saved 7
    T8 = 24    # Temporary 8
    T9 = 25    # Temporary 9
    K0 = 26    # Kernel 0
    K1 = 27    # Kernel 1
    GP = 28    # Global pointer
    SP = 29    # Stack pointer
    FP = 30    # Frame pointer (S8)
    RA = 31    # Return address

    # Special registers
    PC = 32    # Program counter
    HI = 33    # Multiply/divide high
    LO = 34    # Multiply/divide low


class MIPSCoprocessorRegister(IntEnum):
    """MIPS Coprocessor 0 registers."""

    INDEX = 0
    RANDOM = 1
    ENTRYLO0 = 2
    ENTRYLO1 = 3
    CONTEXT = 4
    PAGEMASK = 5
    WIRED = 6
    BADVADDR = 8
    COUNT = 9
    ENTRYHI = 10
    COMPARE = 11
    STATUS = 12
    CAUSE = 13
    EPC = 14
    PRID = 15
    CONFIG = 16
    LLADDR = 17
    WATCHLO = 18
    WATCHHI = 19
    DEBUG = 23
    DEPC = 24
    ERROREPC = 30
    DESAVE = 31


@dataclass
class MIPSRegisters:
    """MIPS register state."""

    # General purpose registers
    zero: int = 0  # $0 - always 0
    at: int = 0    # $1
    v0: int = 0    # $2
    v1: int = 0    # $3
    a0: int = 0    # $4
    a1: int = 0    # $5
    a2: int = 0    # $6
    a3: int = 0    # $7
    t0: int = 0    # $8
    t1: int = 0    # $9
    t2: int = 0    # $10
    t3: int = 0    # $11
    t4: int = 0    # $12
    t5: int = 0    # $13
    t6: int = 0    # $14
    t7: int = 0    # $15
    s0: int = 0    # $16
    s1: int = 0    # $17
    s2: int = 0    # $18
    s3: int = 0    # $19
    s4: int = 0    # $20
    s5: int = 0    # $21
    s6: int = 0    # $22
    s7: int = 0    # $23
    t8: int = 0    # $24
    t9: int = 0    # $25
    k0: int = 0    # $26
    k1: int = 0    # $27
    gp: int = 0    # $28
    sp: int = 0    # $29
    fp: int = 0    # $30 (s8)
    ra: int = 0    # $31

    # Special registers
    pc: int = 0
    hi: int = 0
    lo: int = 0

    def get(self, reg: MIPSRegister) -> int:
        """Get register value by enum."""
        if reg == MIPSRegister.ZERO:
            return 0  # Always return 0 for $zero
        return getattr(self, reg.name.lower())

    def set(self, reg: MIPSRegister, value: int) -> None:
        """Set register value by enum."""
        if reg == MIPSRegister.ZERO:
            return  # Cannot write to $zero
        setattr(self, reg.name.lower(), value)

    def get_by_number(self, num: int) -> int:
        """Get register value by number (0-31)."""
        if num == 0:
            return 0
        reg_names = [
            'zero', 'at', 'v0', 'v1', 'a0', 'a1', 'a2', 'a3',
            't0', 't1', 't2', 't3', 't4', 't5', 't6', 't7',
            's0', 's1', 's2', 's3', 's4', 's5', 's6', 's7',
            't8', 't9', 'k0', 'k1', 'gp', 'sp', 'fp', 'ra',
        ]
        if 0 <= num < len(reg_names):
            return getattr(self, reg_names[num])
        return 0

    def set_by_number(self, num: int, value: int) -> None:
        """Set register value by number (0-31)."""
        if num == 0:
            return  # Cannot write to $zero
        reg_names = [
            'zero', 'at', 'v0', 'v1', 'a0', 'a1', 'a2', 'a3',
            't0', 't1', 't2', 't3', 't4', 't5', 't6', 't7',
            's0', 's1', 's2', 's3', 's4', 's5', 's6', 's7',
            't8', 't9', 'k0', 'k1', 'gp', 'sp', 'fp', 'ra',
        ]
        if 0 < num < len(reg_names):
            setattr(self, reg_names[num], value)

    def to_dict(self) -> dict[str, int]:
        """Convert to dictionary."""
        return {
            'zero': 0, 'at': self.at, 'v0': self.v0, 'v1': self.v1,
            'a0': self.a0, 'a1': self.a1, 'a2': self.a2, 'a3': self.a3,
            't0': self.t0, 't1': self.t1, 't2': self.t2, 't3': self.t3,
            't4': self.t4, 't5': self.t5, 't6': self.t6, 't7': self.t7,
            's0': self.s0, 's1': self.s1, 's2': self.s2, 's3': self.s3,
            's4': self.s4, 's5': self.s5, 's6': self.s6, 's7': self.s7,
            't8': self.t8, 't9': self.t9, 'k0': self.k0, 'k1': self.k1,
            'gp': self.gp, 'sp': self.sp, 'fp': self.fp, 'ra': self.ra,
            'pc': self.pc, 'hi': self.hi, 'lo': self.lo,
        }

    @classmethod
    def from_dict(cls, data: dict[str, int]) -> MIPSRegisters:
        """Create from dictionary."""
        regs = cls()
        for key, value in data.items():
            if hasattr(regs, key) and key != 'zero':
                setattr(regs, key, value)
        return regs


@dataclass
class MIPSStackFrame:
    """Represents a MIPS stack frame."""

    return_address: int = 0
    saved_fp: int = 0
    frame_base: int = 0
    frame_size: int = 0
    saved_registers: dict[str, int] = field(default_factory=dict)
    arguments: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'return_address': hex(self.return_address),
            'saved_fp': hex(self.saved_fp),
            'frame_base': hex(self.frame_base),
            'frame_size': self.frame_size,
            'saved_registers': {k: hex(v) for k, v in self.saved_registers.items()},
            'arguments': [hex(a) for a in self.arguments],
        }


class MIPSStack:
    """Stack management for MIPS."""

    def __init__(self, mode: MIPSMode = MIPSMode.MIPS32):
        self.mode = mode
        self.pointer_size = 8 if mode in (MIPSMode.MIPS64, MIPSMode.MIPS64_BE) else 4
        self.frames: list[MIPSStackFrame] = []

    def push_frame(
        self,
        return_address: int,
        saved_fp: int,
        frame_base: int,
    ) -> MIPSStackFrame:
        """Push a new stack frame."""
        frame = MIPSStackFrame(
            return_address=return_address,
            saved_fp=saved_fp,
            frame_base=frame_base,
        )
        self.frames.append(frame)
        return frame

    def pop_frame(self) -> MIPSStackFrame | None:
        """Pop the current stack frame."""
        if self.frames:
            return self.frames.pop()
        return None

    def current_frame(self) -> MIPSStackFrame | None:
        """Get the current stack frame."""
        return self.frames[-1] if self.frames else None

    def get_frame_count(self) -> int:
        """Get number of stack frames."""
        return len(self.frames)

    def unwind(self, limit: int = 100) -> list[MIPSStackFrame]:
        """Get stack frames for unwinding."""
        return self.frames[:limit]


class MIPSCallingConventionHandler:
    """Handles MIPS calling convention operations."""

    def __init__(
        self,
        convention: MIPSCallingConvention = MIPSCallingConvention.O32,
        mode: MIPSMode = MIPSMode.MIPS32,
    ):
        self.convention = convention
        self.mode = mode
        self.pointer_size = 8 if mode in (MIPSMode.MIPS64, MIPSMode.MIPS64_BE) else 4

    def get_argument_registers(self) -> list[str]:
        """Get registers used for passing arguments."""
        if self.convention == MIPSCallingConvention.O32:
            return ['a0', 'a1', 'a2', 'a3']
        elif self.convention == MIPSCallingConvention.N32:
            return ['a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7']
        elif self.convention == MIPSCallingConvention.N64:
            return ['a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7']
        elif self.convention == MIPSCallingConvention.EABI:
            return ['a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7']
        return ['a0', 'a1', 'a2', 'a3']

    def get_return_registers(self) -> list[str]:
        """Get registers used for return values."""
        return ['v0', 'v1']

    def get_callee_saved_registers(self) -> list[str]:
        """Get callee-saved registers."""
        return ['s0', 's1', 's2', 's3', 's4', 's5', 's6', 's7', 'gp', 'fp']

    def get_caller_saved_registers(self) -> list[str]:
        """Get caller-saved registers."""
        return ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9']

    def setup_call(
        self,
        registers: MIPSRegisters,
        arguments: list[int],
        stack_push: Callable[[int], None],
    ) -> None:
        """Set up registers and stack for a function call."""
        arg_regs = self.get_argument_registers()

        # Set register arguments
        for i, arg in enumerate(arguments[:len(arg_regs)]):
            if hasattr(registers, arg_regs[i]):
                setattr(registers, arg_regs[i], arg)
            elif arg_regs[i].startswith('a') and int(arg_regs[i][1]) >= 4:
                # a4-a7 are t0-t3 in O32
                t_reg = f"t{int(arg_regs[i][1]) - 4}"
                setattr(registers, t_reg, arg)

        # Push remaining arguments onto stack
        stack_args = arguments[len(arg_regs):]
        for arg in reversed(stack_args):
            stack_push(arg)

    def extract_arguments(
        self,
        registers: MIPSRegisters,
        stack_read: Callable[[int, int], bytes],
        num_args: int,
    ) -> list[int]:
        """Extract function arguments from registers and stack."""
        args = []
        arg_regs = self.get_argument_registers()

        # Get register arguments
        for i in range(min(num_args, len(arg_regs))):
            if hasattr(registers, arg_regs[i]):
                args.append(getattr(registers, arg_regs[i]))

        # Get stack arguments
        stack_offset = 16  # Argument save area
        for i in range(num_args - len(arg_regs)):
            offset = stack_offset + i * self.pointer_size
            data = stack_read(registers.sp + offset, self.pointer_size)
            if self.pointer_size == 8:
                args.append(struct.unpack('<Q', data)[0])
            else:
                args.append(struct.unpack('<I', data)[0])

        return args


@dataclass
class MIPSInstruction:
    """Represents a MIPS instruction."""

    address: int = 0
    size: int = 4  # MIPS instructions are always 4 bytes
    mnemonic: str = ""
    operands: str = ""
    bytes: bytes = b""
    opcode: int = 0

    @property
    def is_branch(self) -> bool:
        """Check if instruction is a branch."""
        return self.mnemonic in (
            'b', 'beq', 'bne', 'bgtz', 'bgez', 'bltz', 'blez',
            'beqz', 'bnez', 'bgezal', 'bltzal', 'bgt', 'blt', 'bge', 'ble',
        )

    @property
    def is_jump(self) -> bool:
        """Check if instruction is a jump."""
        return self.mnemonic in ('j', 'jal', 'jr', 'jalr')

    @property
    def is_call(self) -> bool:
        """Check if instruction is a function call."""
        return self.mnemonic in ('jal', 'jalr', 'bgezal', 'bltzal')

    @property
    def is_return(self) -> bool:
        """Check if instruction is a return."""
        # jr $ra is the standard return
        return self.mnemonic == 'jr' and 'ra' in self.operands.lower()

    @property
    def is_syscall(self) -> bool:
        """Check if instruction is a syscall."""
        return self.mnemonic == 'syscall'

    @property
    def is_nop(self) -> bool:
        """Check if instruction is a NOP."""
        # sll $zero, $zero, 0 is NOP
        return self.mnemonic == 'nop' or self.bytes == b'\x00\x00\x00\x00'

    @property
    def is_load(self) -> bool:
        """Check if instruction is a load."""
        return self.mnemonic in ('lb', 'lbu', 'lh', 'lhu', 'lw', 'lwl', 'lwr', 'ld')

    @property
    def is_store(self) -> bool:
        """Check if instruction is a store."""
        return self.mnemonic in ('sb', 'sh', 'sw', 'swl', 'swr', 'sd')

    @property
    def has_delay_slot(self) -> bool:
        """Check if instruction has a delay slot."""
        return self.is_branch or self.is_jump

    def to_string(self) -> str:
        """Get instruction string."""
        return f"{self.mnemonic} {self.operands}".strip()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': hex(self.address),
            'size': self.size,
            'mnemonic': self.mnemonic,
            'operands': self.operands,
            'bytes': self.bytes.hex(),
        }


class MIPSInstructionDecoder:
    """Decodes MIPS instructions."""

    # R-type function codes
    R_TYPE_FUNCS = {
        0x00: 'sll', 0x02: 'srl', 0x03: 'sra', 0x04: 'sllv', 0x06: 'srlv',
        0x07: 'srav', 0x08: 'jr', 0x09: 'jalr', 0x0c: 'syscall', 0x0d: 'break',
        0x10: 'mfhi', 0x11: 'mthi', 0x12: 'mflo', 0x13: 'mtlo',
        0x18: 'mult', 0x19: 'multu', 0x1a: 'div', 0x1b: 'divu',
        0x20: 'add', 0x21: 'addu', 0x22: 'sub', 0x23: 'subu',
        0x24: 'and', 0x25: 'or', 0x26: 'xor', 0x27: 'nor',
        0x2a: 'slt', 0x2b: 'sltu',
    }

    # I-type and J-type opcodes
    OPCODES = {
        0x02: 'j', 0x03: 'jal', 0x04: 'beq', 0x05: 'bne',
        0x06: 'blez', 0x07: 'bgtz', 0x08: 'addi', 0x09: 'addiu',
        0x0a: 'slti', 0x0b: 'sltiu', 0x0c: 'andi', 0x0d: 'ori',
        0x0e: 'xori', 0x0f: 'lui', 0x20: 'lb', 0x21: 'lh',
        0x23: 'lw', 0x24: 'lbu', 0x25: 'lhu', 0x28: 'sb',
        0x29: 'sh', 0x2b: 'sw',
    }

    # Register names
    REG_NAMES = [
        'zero', 'at', 'v0', 'v1', 'a0', 'a1', 'a2', 'a3',
        't0', 't1', 't2', 't3', 't4', 't5', 't6', 't7',
        's0', 's1', 's2', 's3', 's4', 's5', 's6', 's7',
        't8', 't9', 'k0', 'k1', 'gp', 'sp', 'fp', 'ra',
    ]

    def __init__(self, mode: MIPSMode = MIPSMode.MIPS32):
        self.mode = mode
        self.big_endian = mode in (MIPSMode.MIPS32_BE, MIPSMode.MIPS64_BE)

    def _reg_name(self, num: int) -> str:
        """Get register name from number."""
        if 0 <= num < 32:
            return f"${self.REG_NAMES[num]}"
        return f"${num}"

    def decode(self, data: bytes, address: int = 0) -> MIPSInstruction | None:
        """Decode a single MIPS instruction."""
        if len(data) < 4:
            return None

        # Read instruction word
        if self.big_endian:
            insn_word = struct.unpack('>I', data[:4])[0]
        else:
            insn_word = struct.unpack('<I', data[:4])[0]

        opcode = (insn_word >> 26) & 0x3F

        # Check for NOP first
        if insn_word == 0:
            return MIPSInstruction(
                address=address,
                size=4,
                mnemonic='nop',
                operands='',
                bytes=data[:4],
                opcode=0,
            )

        # R-type instruction
        if opcode == 0:
            return self._decode_r_type(insn_word, data[:4], address)

        # J-type instruction
        if opcode in (0x02, 0x03):
            return self._decode_j_type(insn_word, data[:4], address)

        # I-type instruction
        return self._decode_i_type(insn_word, data[:4], address)

    def _decode_r_type(
        self,
        insn_word: int,
        data: bytes,
        address: int,
    ) -> MIPSInstruction:
        """Decode R-type instruction."""
        rs = (insn_word >> 21) & 0x1F
        rt = (insn_word >> 16) & 0x1F
        rd = (insn_word >> 11) & 0x1F
        shamt = (insn_word >> 6) & 0x1F
        funct = insn_word & 0x3F

        mnemonic = self.R_TYPE_FUNCS.get(funct, f'func_{funct:02x}')

        if mnemonic in ('syscall', 'break'):
            operands = ''
        elif mnemonic in ('jr', 'jalr'):
            operands = self._reg_name(rs)
        elif mnemonic in ('mfhi', 'mflo'):
            operands = self._reg_name(rd)
        elif mnemonic in ('mthi', 'mtlo'):
            operands = self._reg_name(rs)
        elif mnemonic in ('mult', 'multu', 'div', 'divu'):
            operands = f"{self._reg_name(rs)}, {self._reg_name(rt)}"
        elif mnemonic in ('sll', 'srl', 'sra'):
            operands = f"{self._reg_name(rd)}, {self._reg_name(rt)}, {shamt}"
        else:
            operands = f"{self._reg_name(rd)}, {self._reg_name(rs)}, {self._reg_name(rt)}"

        return MIPSInstruction(
            address=address,
            size=4,
            mnemonic=mnemonic,
            operands=operands,
            bytes=data,
            opcode=funct,
        )

    def _decode_i_type(
        self,
        insn_word: int,
        data: bytes,
        address: int,
    ) -> MIPSInstruction:
        """Decode I-type instruction."""
        opcode = (insn_word >> 26) & 0x3F
        rs = (insn_word >> 21) & 0x1F
        rt = (insn_word >> 16) & 0x1F
        imm = insn_word & 0xFFFF

        # Sign extend immediate for some instructions
        if imm & 0x8000:
            imm_signed = imm - 0x10000
        else:
            imm_signed = imm

        mnemonic = self.OPCODES.get(opcode, f'op_{opcode:02x}')

        if mnemonic in ('beq', 'bne'):
            target = address + 4 + (imm_signed << 2)
            operands = f"{self._reg_name(rs)}, {self._reg_name(rt)}, 0x{target:x}"
        elif mnemonic in ('blez', 'bgtz'):
            target = address + 4 + (imm_signed << 2)
            operands = f"{self._reg_name(rs)}, 0x{target:x}"
        elif mnemonic == 'lui':
            operands = f"{self._reg_name(rt)}, 0x{imm:x}"
        elif mnemonic in ('lb', 'lbu', 'lh', 'lhu', 'lw', 'sb', 'sh', 'sw'):
            operands = f"{self._reg_name(rt)}, {imm_signed}({self._reg_name(rs)})"
        else:
            operands = f"{self._reg_name(rt)}, {self._reg_name(rs)}, {imm_signed}"

        return MIPSInstruction(
            address=address,
            size=4,
            mnemonic=mnemonic,
            operands=operands,
            bytes=data,
            opcode=opcode,
        )

    def _decode_j_type(
        self,
        insn_word: int,
        data: bytes,
        address: int,
    ) -> MIPSInstruction:
        """Decode J-type instruction."""
        opcode = (insn_word >> 26) & 0x3F
        target_index = insn_word & 0x3FFFFFF
        target = ((address + 4) & 0xF0000000) | (target_index << 2)

        mnemonic = self.OPCODES.get(opcode, 'j')
        operands = f"0x{target:x}"

        return MIPSInstruction(
            address=address,
            size=4,
            mnemonic=mnemonic,
            operands=operands,
            bytes=data,
            opcode=opcode,
        )

    def decode_stream(
        self,
        data: bytes,
        start_address: int = 0,
        max_instructions: int = 100,
    ) -> list[MIPSInstruction]:
        """Decode a stream of instructions."""
        instructions = []
        offset = 0

        while offset + 4 <= len(data) and len(instructions) < max_instructions:
            insn = self.decode(data[offset:], start_address + offset)
            if insn is None:
                break
            instructions.append(insn)
            offset += 4

        return instructions


class MIPSEmulator:
    """MIPS specific emulator extensions."""

    def __init__(
        self,
        mode: MIPSMode = MIPSMode.MIPS32,
        convention: MIPSCallingConvention = MIPSCallingConvention.O32,
    ):
        self.mode = mode
        self.registers = MIPSRegisters()
        self.stack = MIPSStack(mode)
        self.calling_convention = MIPSCallingConventionHandler(convention, mode)
        self.decoder = MIPSInstructionDecoder(mode)

        self.pointer_size = 8 if mode in (MIPSMode.MIPS64, MIPSMode.MIPS64_BE) else 4
        self.max_address = 0xFFFFFFFFFFFFFFFF if self.pointer_size == 8 else 0xFFFFFFFF
        self.big_endian = mode in (MIPSMode.MIPS32_BE, MIPSMode.MIPS64_BE)

        # Memory regions
        self._memory: dict[int, bytes] = {}

        # Hooks
        self._instruction_hooks: list[Callable] = []
        self._memory_hooks: list[Callable] = []
        self._syscall_hooks: list[Callable] = []

    def reset(self) -> None:
        """Reset emulator state."""
        self.registers = MIPSRegisters()
        self.stack = MIPSStack(self.mode)
        self._memory.clear()

    def map_memory(self, address: int, size: int, data: bytes = b"") -> None:
        """Map memory region."""
        if data:
            self._memory[address] = data.ljust(size, b'\x00')[:size]
        else:
            self._memory[address] = b'\x00' * size

    def read_memory(self, address: int, size: int) -> bytes:
        """Read from memory."""
        for base, data in self._memory.items():
            if base <= address < base + len(data):
                offset = address - base
                return data[offset:offset + size]
        return b'\x00' * size

    def write_memory(self, address: int, data: bytes) -> None:
        """Write to memory."""
        for base, mem in list(self._memory.items()):
            if base <= address < base + len(mem):
                offset = address - base
                self._memory[base] = mem[:offset] + data + mem[offset + len(data):]
                return

    def push(self, value: int) -> None:
        """Push value onto stack."""
        self.registers.sp -= self.pointer_size
        if self.pointer_size == 8:
            if self.big_endian:
                data = struct.pack('>Q', value & self.max_address)
            else:
                data = struct.pack('<Q', value & self.max_address)
        else:
            if self.big_endian:
                data = struct.pack('>I', value & 0xFFFFFFFF)
            else:
                data = struct.pack('<I', value & 0xFFFFFFFF)
        self.write_memory(self.registers.sp, data)

    def pop(self) -> int:
        """Pop value from stack."""
        data = self.read_memory(self.registers.sp, self.pointer_size)
        self.registers.sp += self.pointer_size
        if self.pointer_size == 8:
            if self.big_endian:
                return struct.unpack('>Q', data)[0]
            return struct.unpack('<Q', data)[0]
        if self.big_endian:
            return struct.unpack('>I', data)[0]
        return struct.unpack('<I', data)[0]

    def add_instruction_hook(self, callback: Callable) -> None:
        """Add instruction hook."""
        self._instruction_hooks.append(callback)

    def add_memory_hook(self, callback: Callable) -> None:
        """Add memory hook."""
        self._memory_hooks.append(callback)

    def add_syscall_hook(self, callback: Callable) -> None:
        """Add syscall hook."""
        self._syscall_hooks.append(callback)

    def get_instruction_at(self, address: int) -> MIPSInstruction | None:
        """Get instruction at address."""
        data = self.read_memory(address, 4)
        return self.decoder.decode(data, address)

    def setup_stack(self, base: int, size: int) -> None:
        """Set up the stack."""
        self.map_memory(base - size, size)
        self.registers.sp = base
        self.registers.fp = base

    def call_function(
        self,
        address: int,
        arguments: list[int],
        return_address: int = 0xDEADBEEF,
    ) -> None:
        """Set up a function call."""
        # Set return address
        self.registers.ra = return_address

        # Set up arguments
        self.calling_convention.setup_call(
            self.registers,
            arguments,
            self.push,
        )

        # Set program counter
        self.registers.pc = address

        # Push frame
        self.stack.push_frame(return_address, self.registers.fp, self.registers.sp)

    def get_return_value(self) -> int:
        """Get return value after function call."""
        return self.registers.v0

    def print_registers(self) -> None:
        """Print register state."""
        print("\n" + "=" * 60)
        print("MIPS REGISTER STATE")
        print("=" * 60)

        fmt = "{:>4}: {:08x}"
        if self.pointer_size == 8:
            fmt = "{:>4}: {:016x}"

        for i in range(0, 32, 4):
            regs = []
            for j in range(4):
                name = MIPSInstructionDecoder.REG_NAMES[i + j]
                val = self.registers.get_by_number(i + j)
                regs.append(fmt.format(f"${name}", val))
            print("  ".join(regs))

        print(f"\n  PC: {self.registers.pc:08x}  HI: {self.registers.hi:08x}  LO: {self.registers.lo:08x}")
        print("=" * 60 + "\n")

    def __repr__(self) -> str:
        return f"MIPSEmulator(mode={self.mode.name}, pc=0x{self.registers.pc:x})"


def create_mips_emulator(
    mode: str = "32",
    convention: str = "o32",
    big_endian: bool = False,
) -> MIPSEmulator:
    """
    Create a MIPS emulator.
    
    Args:
        mode: "32" or "64".
        convention: Calling convention name.
        big_endian: Use big endian mode.
    
    Returns:
        Configured MIPSEmulator.
    """
    if mode == "64":
        mips_mode = MIPSMode.MIPS64_BE if big_endian else MIPSMode.MIPS64
    else:
        mips_mode = MIPSMode.MIPS32_BE if big_endian else MIPSMode.MIPS32

    convention_map = {
        "o32": MIPSCallingConvention.O32,
        "n32": MIPSCallingConvention.N32,
        "n64": MIPSCallingConvention.N64,
        "eabi": MIPSCallingConvention.EABI,
    }

    cc = convention_map.get(convention.lower(), MIPSCallingConvention.O32)

    return MIPSEmulator(mode=mips_mode, convention=cc)
