"""
Symbolic Execution Integration for PyUniDbg.

Provides symbolic execution capabilities for exploring multiple
execution paths, finding inputs that reach specific code locations,
and solving path constraints.

This module provides a lightweight symbolic execution framework
that can be used standalone or integrated with external engines
like angr or Triton.

Features:
- Symbolic variables and expressions
- Path constraint tracking
- Concolic execution (concrete + symbolic)
- Input generation for path exploration
- Integration points for external solvers

Usage:
    from pyunidbg.symbolic import SymbolicEngine, SymbolicValue
    
    engine = SymbolicEngine(emulator)
    
    # Make input symbolic
    engine.make_symbolic("input_buffer", 0x1000, 16)
    
    # Run with symbolic tracking
    engine.explore(target_addr=0x4000)
    
    # Get inputs that reach target
    solutions = engine.get_solutions()
"""

import copy
import hashlib
import logging
import struct
from abc import ABC, abstractmethod
from collections import deque
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class SymbolicType(Enum):
    """Types of symbolic values."""
    BITVECTOR = auto()    # Fixed-width bit vector
    BOOLEAN = auto()       # Boolean value
    ARRAY = auto()         # Array/memory region
    FLOAT = auto()         # Floating point


class BinaryOp(Enum):
    """Binary operations."""
    ADD = auto()
    SUB = auto()
    MUL = auto()
    DIV = auto()
    UDIV = auto()
    MOD = auto()
    UMOD = auto()
    AND = auto()
    OR = auto()
    XOR = auto()
    SHL = auto()
    SHR = auto()
    SAR = auto()      # Arithmetic shift right
    ROL = auto()
    ROR = auto()
    CONCAT = auto()
    EQ = auto()
    NE = auto()
    LT = auto()
    LE = auto()
    GT = auto()
    GE = auto()
    ULT = auto()
    ULE = auto()
    UGT = auto()
    UGE = auto()


class UnaryOp(Enum):
    """Unary operations."""
    NOT = auto()
    NEG = auto()
    ZEXT = auto()     # Zero extend
    SEXT = auto()     # Sign extend
    EXTRACT = auto()  # Bit extraction


@dataclass
class SymbolicValue:
    """
    A symbolic value that can be concrete or symbolic.
    
    Represents values that may depend on symbolic inputs,
    allowing tracking of how inputs flow through computation.
    """

    name: str
    size: int  # Size in bits
    sym_type: SymbolicType = SymbolicType.BITVECTOR

    # For concrete values
    concrete_value: int | None = None
    is_concrete: bool = False

    # For symbolic expressions
    operation: BinaryOp | UnaryOp | None = None
    operands: list['SymbolicValue'] = field(default_factory=list)

    # Metadata
    origin: str | None = None  # Where this value came from
    constraints: list['Constraint'] = field(default_factory=list)

    def __post_init__(self):
        if self.concrete_value is not None:
            self.is_concrete = True

    @classmethod
    def concrete(cls, value: int, size: int = 64, name: str = "") -> 'SymbolicValue':
        """Create a concrete value."""
        name = name or f"const_{value:#x}"
        return cls(
            name=name,
            size=size,
            concrete_value=value,
            is_concrete=True
        )

    @classmethod
    def symbol(cls, name: str, size: int = 64) -> 'SymbolicValue':
        """Create a symbolic value."""
        return cls(
            name=name,
            size=size,
            is_concrete=False
        )

    def __repr__(self) -> str:
        if self.is_concrete:
            return f"Concrete({self.concrete_value:#x})"
        elif self.operation:
            return f"Expr({self.operation.name}, {self.operands})"
        return f"Symbol({self.name})"

    # === Arithmetic Operations ===

    def __add__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.ADD, other)

    def __sub__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.SUB, other)

    def __mul__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.MUL, other)

    def __truediv__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.DIV, other)

    def __mod__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.MOD, other)

    # === Bitwise Operations ===

    def __and__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.AND, other)

    def __or__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.OR, other)

    def __xor__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.XOR, other)

    def __lshift__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.SHL, other)

    def __rshift__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.SHR, other)

    def __invert__(self) -> 'SymbolicValue':
        return self._unary_op(UnaryOp.NOT)

    def __neg__(self) -> 'SymbolicValue':
        return self._unary_op(UnaryOp.NEG)

    # === Comparison Operations ===

    def __eq__(self, other: object) -> 'SymbolicValue':
        if not isinstance(other, SymbolicValue):
            other = SymbolicValue.concrete(other, self.size)
        return self._binary_op(BinaryOp.EQ, other, result_size=1)

    def __ne__(self, other: object) -> 'SymbolicValue':
        if not isinstance(other, SymbolicValue):
            other = SymbolicValue.concrete(other, self.size)
        return self._binary_op(BinaryOp.NE, other, result_size=1)

    def __lt__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.LT, other, result_size=1)

    def __le__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.LE, other, result_size=1)

    def __gt__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.GT, other, result_size=1)

    def __ge__(self, other: 'SymbolicValue') -> 'SymbolicValue':
        return self._binary_op(BinaryOp.GE, other, result_size=1)

    def ult(self, other: 'SymbolicValue') -> 'SymbolicValue':
        """Unsigned less than."""
        return self._binary_op(BinaryOp.ULT, other, result_size=1)

    def ule(self, other: 'SymbolicValue') -> 'SymbolicValue':
        """Unsigned less than or equal."""
        return self._binary_op(BinaryOp.ULE, other, result_size=1)

    def ugt(self, other: 'SymbolicValue') -> 'SymbolicValue':
        """Unsigned greater than."""
        return self._binary_op(BinaryOp.UGT, other, result_size=1)

    def uge(self, other: 'SymbolicValue') -> 'SymbolicValue':
        """Unsigned greater than or equal."""
        return self._binary_op(BinaryOp.UGE, other, result_size=1)

    # === Extension Operations ===

    def zero_extend(self, new_size: int) -> 'SymbolicValue':
        """Zero extend to new size."""
        result = SymbolicValue(
            name=f"zext_{self.name}",
            size=new_size,
            operation=UnaryOp.ZEXT,
            operands=[self],
            is_concrete=self.is_concrete,
            concrete_value=self.concrete_value
        )
        return result

    def sign_extend(self, new_size: int) -> 'SymbolicValue':
        """Sign extend to new size."""
        if self.is_concrete:
            # Calculate sign extended value
            sign_bit = 1 << (self.size - 1)
            if self.concrete_value & sign_bit:
                # Negative value
                mask = (1 << new_size) - (1 << self.size)
                value = self.concrete_value | mask
            else:
                value = self.concrete_value
            return SymbolicValue.concrete(value, new_size)

        return SymbolicValue(
            name=f"sext_{self.name}",
            size=new_size,
            operation=UnaryOp.SEXT,
            operands=[self]
        )

    def extract(self, high: int, low: int) -> 'SymbolicValue':
        """Extract bits [high:low]."""
        new_size = high - low + 1

        if self.is_concrete:
            mask = (1 << new_size) - 1
            value = (self.concrete_value >> low) & mask
            return SymbolicValue.concrete(value, new_size)

        return SymbolicValue(
            name=f"extract_{self.name}_{high}_{low}",
            size=new_size,
            operation=UnaryOp.EXTRACT,
            operands=[self, SymbolicValue.concrete(high, 32), SymbolicValue.concrete(low, 32)]
        )

    def concat(self, other: 'SymbolicValue') -> 'SymbolicValue':
        """Concatenate with another value."""
        new_size = self.size + other.size

        if self.is_concrete and other.is_concrete:
            value = (self.concrete_value << other.size) | other.concrete_value
            return SymbolicValue.concrete(value, new_size)

        return self._binary_op(BinaryOp.CONCAT, other, result_size=new_size)

    # === Helper Methods ===

    def _binary_op(
        self,
        op: BinaryOp,
        other: 'SymbolicValue',
        result_size: int | None = None
    ) -> 'SymbolicValue':
        """Create binary operation expression."""
        if not isinstance(other, SymbolicValue):
            other = SymbolicValue.concrete(other, self.size)

        size = result_size or max(self.size, other.size)

        # Evaluate if both concrete
        if self.is_concrete and other.is_concrete:
            result = self._evaluate_binary(op, self.concrete_value, other.concrete_value, size)
            return SymbolicValue.concrete(result, size)

        return SymbolicValue(
            name=f"{op.name}_{id(self)}_{id(other)}",
            size=size,
            operation=op,
            operands=[self, other]
        )

    def _unary_op(self, op: UnaryOp) -> 'SymbolicValue':
        """Create unary operation expression."""
        if self.is_concrete:
            result = self._evaluate_unary(op, self.concrete_value, self.size)
            return SymbolicValue.concrete(result, self.size)

        return SymbolicValue(
            name=f"{op.name}_{id(self)}",
            size=self.size,
            operation=op,
            operands=[self]
        )

    def _evaluate_binary(self, op: BinaryOp, a: int, b: int, size: int) -> int:
        """Evaluate binary operation concretely."""
        mask = (1 << size) - 1

        ops = {
            BinaryOp.ADD: lambda: (a + b) & mask,
            BinaryOp.SUB: lambda: (a - b) & mask,
            BinaryOp.MUL: lambda: (a * b) & mask,
            BinaryOp.DIV: lambda: (a // b) if b != 0 else 0,
            BinaryOp.MOD: lambda: (a % b) if b != 0 else 0,
            BinaryOp.AND: lambda: a & b,
            BinaryOp.OR: lambda: a | b,
            BinaryOp.XOR: lambda: a ^ b,
            BinaryOp.SHL: lambda: (a << b) & mask,
            BinaryOp.SHR: lambda: a >> b,
            BinaryOp.EQ: lambda: 1 if a == b else 0,
            BinaryOp.NE: lambda: 1 if a != b else 0,
            BinaryOp.LT: lambda: 1 if self._signed(a, size) < self._signed(b, size) else 0,
            BinaryOp.LE: lambda: 1 if self._signed(a, size) <= self._signed(b, size) else 0,
            BinaryOp.GT: lambda: 1 if self._signed(a, size) > self._signed(b, size) else 0,
            BinaryOp.GE: lambda: 1 if self._signed(a, size) >= self._signed(b, size) else 0,
            BinaryOp.ULT: lambda: 1 if a < b else 0,
            BinaryOp.ULE: lambda: 1 if a <= b else 0,
            BinaryOp.UGT: lambda: 1 if a > b else 0,
            BinaryOp.UGE: lambda: 1 if a >= b else 0,
        }

        return ops.get(op, lambda: 0)()

    def _evaluate_unary(self, op: UnaryOp, a: int, size: int) -> int:
        """Evaluate unary operation concretely."""
        mask = (1 << size) - 1

        if op == UnaryOp.NOT:
            return (~a) & mask
        elif op == UnaryOp.NEG:
            return (-a) & mask

        return a

    def _signed(self, value: int, size: int) -> int:
        """Convert unsigned to signed."""
        sign_bit = 1 << (size - 1)
        if value & sign_bit:
            return value - (1 << size)
        return value

    def get_symbols(self) -> set[str]:
        """Get all symbol names in this expression."""
        symbols = set()

        if not self.is_concrete and not self.operation:
            symbols.add(self.name)

        for operand in self.operands:
            symbols.update(operand.get_symbols())

        return symbols

    def substitute(self, mapping: dict[str, 'SymbolicValue']) -> 'SymbolicValue':
        """Substitute symbols with values."""
        if self.is_concrete:
            return self

        if not self.operation and self.name in mapping:
            return mapping[self.name]

        if self.operands:
            new_operands = [op.substitute(mapping) for op in self.operands]
            return SymbolicValue(
                name=self.name,
                size=self.size,
                operation=self.operation,
                operands=new_operands
            )

        return self


@dataclass
class Constraint:
    """A path constraint."""

    expression: SymbolicValue
    is_true: bool = True  # Whether the constraint should be true or false
    location: int = 0     # Address where constraint was added

    def __repr__(self) -> str:
        prefix = "" if self.is_true else "NOT "
        return f"Constraint({prefix}{self.expression})"

    def negate(self) -> 'Constraint':
        """Return negated constraint."""
        return Constraint(self.expression, not self.is_true, self.location)


@dataclass
class PathState:
    """
    State of an execution path.
    
    Represents a snapshot of symbolic execution state
    including register values, memory, and constraints.
    """

    id: int
    pc: int  # Program counter

    # Symbolic state
    registers: dict[str, SymbolicValue] = field(default_factory=dict)
    memory: dict[int, SymbolicValue] = field(default_factory=dict)

    # Path constraints
    constraints: list[Constraint] = field(default_factory=list)

    # Execution history
    path_history: list[int] = field(default_factory=list)

    # Status
    is_active: bool = True
    is_deadended: bool = False
    is_errored: bool = False
    error_message: str = ""

    # Statistics
    instruction_count: int = 0
    branch_count: int = 0

    def clone(self) -> 'PathState':
        """Create a deep copy of the state."""
        return PathState(
            id=self.id,
            pc=self.pc,
            registers=dict(self.registers),
            memory=dict(self.memory),
            constraints=list(self.constraints),
            path_history=list(self.path_history),
            is_active=self.is_active,
            instruction_count=self.instruction_count,
            branch_count=self.branch_count
        )

    def add_constraint(self, constraint: Constraint):
        """Add a path constraint."""
        self.constraints.append(constraint)

    def get_constraint_hash(self) -> str:
        """Get hash of constraints for state deduplication."""
        data = str([(c.expression.name, c.is_true) for c in self.constraints])
        return hashlib.md5(data.encode()).hexdigest()


class Solver(ABC):
    """Abstract base class for constraint solvers."""

    @abstractmethod
    def check_sat(self, constraints: list[Constraint]) -> bool:
        """Check if constraints are satisfiable."""
        pass

    @abstractmethod
    def get_model(self, constraints: list[Constraint]) -> dict[str, int] | None:
        """Get a satisfying assignment for constraints."""
        pass

    @abstractmethod
    def get_all_models(
        self,
        constraints: list[Constraint],
        max_solutions: int = 10
    ) -> list[dict[str, int]]:
        """Get all satisfying assignments up to max_solutions."""
        pass


class SimpleSolver(Solver):
    """
    Simple constraint solver using brute force for small search spaces.
    
    For production use, integrate with Z3 or other SMT solvers.
    """

    def __init__(self, max_iterations: int = 10000):
        self.max_iterations = max_iterations

    def check_sat(self, constraints: list[Constraint]) -> bool:
        """Check satisfiability by trying to find one model."""
        model = self.get_model(constraints)
        return model is not None

    def get_model(self, constraints: list[Constraint]) -> dict[str, int] | None:
        """Get a satisfying model through enumeration."""
        # Collect all symbols
        symbols = set()
        for c in constraints:
            symbols.update(c.expression.get_symbols())

        if not symbols:
            # No symbols, check if concrete constraints hold
            for c in constraints:
                if c.expression.is_concrete:
                    expected = 1 if c.is_true else 0
                    if c.expression.concrete_value != expected:
                        return None
            return {}

        symbols = list(symbols)

        # For small number of symbols, enumerate
        if len(symbols) <= 8:
            return self._enumerate_models(constraints, symbols)

        # For larger search spaces, use random sampling
        return self._random_sample(constraints, symbols)

    def get_all_models(
        self,
        constraints: list[Constraint],
        max_solutions: int = 10
    ) -> list[dict[str, int]]:
        """Get multiple satisfying models."""
        models = []
        symbols = set()
        for c in constraints:
            symbols.update(c.expression.get_symbols())

        if not symbols:
            if self.check_sat(constraints):
                return [{}]
            return []

        symbols = list(symbols)

        # Enumerate and collect models
        for i in range(min(self.max_iterations, 256 ** len(symbols))):
            assignment = {}
            temp = i
            for sym in symbols:
                assignment[sym] = temp & 0xFF
                temp >>= 8

            if self._check_assignment(constraints, assignment):
                # Check if this model is new
                if assignment not in models:
                    models.append(assignment)
                    if len(models) >= max_solutions:
                        break

        return models

    def _enumerate_models(
        self,
        constraints: list[Constraint],
        symbols: list[str]
    ) -> dict[str, int] | None:
        """Enumerate possible values for symbols."""
        # Try values 0-255 for each symbol (byte-level)
        for i in range(min(self.max_iterations, 256 ** len(symbols))):
            assignment = {}
            temp = i
            for sym in symbols:
                assignment[sym] = temp & 0xFF
                temp >>= 8

            if self._check_assignment(constraints, assignment):
                return assignment

        return None

    def _random_sample(
        self,
        constraints: list[Constraint],
        symbols: list[str]
    ) -> dict[str, int] | None:
        """Random sampling for larger search spaces."""
        import random

        for _ in range(self.max_iterations):
            assignment = {sym: random.randint(0, 255) for sym in symbols}
            if self._check_assignment(constraints, assignment):
                return assignment

        return None

    def _check_assignment(
        self,
        constraints: list[Constraint],
        assignment: dict[str, int]
    ) -> bool:
        """Check if assignment satisfies all constraints."""
        for constraint in constraints:
            # Substitute values and evaluate
            expr = constraint.expression.substitute({
                name: SymbolicValue.concrete(value, 64)
                for name, value in assignment.items()
            })

            if not expr.is_concrete:
                continue

            expected = 1 if constraint.is_true else 0
            if expr.concrete_value != expected:
                return False

        return True


class ExplorationStrategy(Enum):
    """Path exploration strategies."""
    DFS = auto()      # Depth-first search
    BFS = auto()      # Breadth-first search
    RANDOM = auto()   # Random path selection
    COVERAGE = auto()  # Prioritize new coverage


@dataclass
class ExplorationResult:
    """Result of symbolic exploration."""

    # Found paths
    reached_target: list[PathState] = field(default_factory=list)
    deadended: list[PathState] = field(default_factory=list)
    errored: list[PathState] = field(default_factory=list)

    # Statistics
    paths_explored: int = 0
    instructions_executed: int = 0
    branches_analyzed: int = 0

    # Solutions
    solutions: list[dict[str, int]] = field(default_factory=list)


class SymbolicEngine:
    """
    Symbolic execution engine.
    
    Provides path exploration and input generation capabilities
    for the emulator.
    """

    def __init__(
        self,
        emulator: Optional['Emulator'] = None,
        solver: Solver | None = None
    ):
        """
        Initialize symbolic engine.
        
        Args:
            emulator: PyUniDbg emulator instance
            solver: Constraint solver (default: SimpleSolver)
        """
        self.emulator = emulator
        self.solver = solver or SimpleSolver()

        # Symbolic state
        self._symbols: dict[str, SymbolicValue] = {}
        self._symbolic_memory: dict[int, SymbolicValue] = {}
        self._symbolic_registers: dict[str, SymbolicValue] = {}

        # Path management
        self._active_paths: deque = deque()
        self._deadended_paths: list[PathState] = []
        self._errored_paths: list[PathState] = []
        self._target_paths: list[PathState] = []

        self._path_counter = 0
        self._strategy = ExplorationStrategy.DFS

        # Exploration limits
        self.max_paths = 1000
        self.max_instructions = 100000
        self.max_depth = 100

        # Hooks
        self._branch_hook: Callable | None = None
        self._memory_hook: Callable | None = None

        # Statistics
        self._total_instructions = 0
        self._total_branches = 0

        # Coverage tracking
        self._covered_addresses: set[int] = set()

    # === Symbol Creation ===

    def make_symbolic(
        self,
        name: str,
        address: int,
        size: int,
        byte_size: int = 8
    ) -> list[SymbolicValue]:
        """
        Make a memory region symbolic.
        
        Args:
            name: Base name for symbols
            address: Memory address
            size: Number of bytes
            byte_size: Bits per byte (default 8)
            
        Returns:
            List of symbolic values created
        """
        symbols = []

        for i in range(size):
            sym_name = f"{name}_{i}"
            sym = SymbolicValue.symbol(sym_name, byte_size)

            self._symbols[sym_name] = sym
            self._symbolic_memory[address + i] = sym
            symbols.append(sym)

        logger.debug(f"Made {size} bytes symbolic at {address:#x} as '{name}'")
        return symbols

    def make_register_symbolic(self, reg_name: str, size: int = 64) -> SymbolicValue:
        """
        Make a register symbolic.
        
        Args:
            reg_name: Register name
            size: Size in bits
            
        Returns:
            Symbolic value for register
        """
        sym = SymbolicValue.symbol(f"reg_{reg_name}", size)
        self._symbols[sym.name] = sym
        self._symbolic_registers[reg_name] = sym

        logger.debug(f"Made register {reg_name} symbolic")
        return sym

    def get_symbol(self, name: str) -> SymbolicValue | None:
        """Get a symbol by name."""
        return self._symbols.get(name)

    def get_symbolic_memory(self, address: int) -> SymbolicValue | None:
        """Get symbolic value at memory address."""
        return self._symbolic_memory.get(address)

    def get_symbolic_register(self, reg_name: str) -> SymbolicValue | None:
        """Get symbolic value of register."""
        return self._symbolic_registers.get(reg_name)

    # === Path Management ===

    def create_initial_state(self, pc: int) -> PathState:
        """Create initial path state."""
        state = PathState(
            id=self._path_counter,
            pc=pc,
            registers=dict(self._symbolic_registers),
            memory=dict(self._symbolic_memory)
        )
        self._path_counter += 1
        return state

    def fork_state(self, state: PathState, new_pc: int) -> PathState:
        """Fork a path state."""
        new_state = state.clone()
        new_state.id = self._path_counter
        new_state.pc = new_pc
        self._path_counter += 1
        return new_state

    def add_constraint(
        self,
        state: PathState,
        condition: SymbolicValue,
        is_true: bool = True
    ):
        """Add a constraint to path state."""
        constraint = Constraint(condition, is_true, state.pc)
        state.add_constraint(constraint)

    # === Exploration ===

    def explore(
        self,
        start_addr: int | None = None,
        target_addr: int | None = None,
        avoid_addrs: set[int] | None = None,
        find_condition: Callable[[PathState], bool] | None = None
    ) -> ExplorationResult:
        """
        Explore execution paths.
        
        Args:
            start_addr: Starting address (or current PC)
            target_addr: Target address to reach
            avoid_addrs: Addresses to avoid
            find_condition: Custom condition for finding states
            
        Returns:
            Exploration result with found paths
        """
        avoid_addrs = avoid_addrs or set()

        # Get start address
        if start_addr is None and self.emulator:
            start_addr = self.emulator.get_pc()
        elif start_addr is None:
            start_addr = 0

        # Create initial state
        initial_state = self.create_initial_state(start_addr)
        self._active_paths.append(initial_state)

        result = ExplorationResult()

        # Exploration loop
        while self._active_paths and result.paths_explored < self.max_paths:
            # Select next state based on strategy
            state = self._select_state()
            if not state:
                break

            result.paths_explored += 1

            # Check if at target
            if target_addr and state.pc == target_addr:
                self._target_paths.append(state)
                result.reached_target.append(state)
                continue

            # Check custom condition
            if find_condition and find_condition(state):
                self._target_paths.append(state)
                result.reached_target.append(state)
                continue

            # Check if should avoid
            if state.pc in avoid_addrs:
                state.is_active = False
                state.is_deadended = True
                self._deadended_paths.append(state)
                result.deadended.append(state)
                continue

            # Check depth limit
            if len(state.path_history) >= self.max_depth:
                state.is_deadended = True
                self._deadended_paths.append(state)
                result.deadended.append(state)
                continue

            # Execute one step (simulate or use emulator)
            try:
                self._execute_step(state)
                result.instructions_executed += 1
            except Exception as e:
                state.is_errored = True
                state.error_message = str(e)
                self._errored_paths.append(state)
                result.errored.append(state)
                continue

            # Add state back if still active
            if state.is_active:
                self._active_paths.append(state)

        # Solve constraints for target paths
        for state in result.reached_target:
            model = self.solver.get_model(state.constraints)
            if model:
                result.solutions.append(model)

        result.branches_analyzed = self._total_branches

        return result

    def _select_state(self) -> PathState | None:
        """Select next state based on exploration strategy."""
        if not self._active_paths:
            return None

        if self._strategy == ExplorationStrategy.DFS:
            return self._active_paths.pop()
        elif self._strategy == ExplorationStrategy.BFS:
            return self._active_paths.popleft()
        elif self._strategy == ExplorationStrategy.RANDOM:
            import random
            idx = random.randrange(len(self._active_paths))
            state = self._active_paths[idx]
            del self._active_paths[idx]
            return state
        elif self._strategy == ExplorationStrategy.COVERAGE:
            # Prioritize states at uncovered addresses
            for i, state in enumerate(self._active_paths):
                if state.pc not in self._covered_addresses:
                    del self._active_paths[i]
                    return state
            return self._active_paths.pop()

        return self._active_paths.pop()

    def _execute_step(self, state: PathState):
        """Execute one instruction step."""
        state.path_history.append(state.pc)
        self._covered_addresses.add(state.pc)
        state.instruction_count += 1
        self._total_instructions += 1

        # In a full implementation, this would:
        # 1. Fetch instruction at state.pc
        # 2. Update symbolic state based on instruction semantics
        # 3. Handle branches by forking states

        # For now, we just advance PC (simulate linear execution)
        state.pc += 4  # ARM instruction size

    def handle_branch(
        self,
        state: PathState,
        condition: SymbolicValue,
        true_target: int,
        false_target: int
    ) -> tuple[PathState | None, PathState | None]:
        """
        Handle a symbolic branch.
        
        Args:
            state: Current path state
            condition: Branch condition
            true_target: Target if condition is true
            false_target: Target if condition is false
            
        Returns:
            Tuple of (true_state, false_state), either may be None if infeasible
        """
        self._total_branches += 1
        state.branch_count += 1

        # Check feasibility of both paths
        true_constraints = state.constraints + [Constraint(condition, True, state.pc)]
        false_constraints = state.constraints + [Constraint(condition, False, state.pc)]

        true_sat = self.solver.check_sat(true_constraints)
        false_sat = self.solver.check_sat(false_constraints)

        true_state = None
        false_state = None

        if true_sat:
            true_state = self.fork_state(state, true_target)
            true_state.add_constraint(Constraint(condition, True, state.pc))
            self._active_paths.append(true_state)

        if false_sat:
            false_state = self.fork_state(state, false_target)
            false_state.add_constraint(Constraint(condition, False, state.pc))
            self._active_paths.append(false_state)

        # Deactivate original state
        state.is_active = False

        return true_state, false_state

    # === Solution Generation ===

    def get_solutions(
        self,
        max_solutions: int = 10
    ) -> list[dict[str, int]]:
        """
        Get input values that reach the target.
        
        Args:
            max_solutions: Maximum number of solutions
            
        Returns:
            List of symbol->value mappings
        """
        solutions = []

        for state in self._target_paths:
            models = self.solver.get_all_models(state.constraints, max_solutions)
            solutions.extend(models)

            if len(solutions) >= max_solutions:
                break

        return solutions[:max_solutions]

    def generate_input(
        self,
        target_state: PathState,
        format: str = "bytes"
    ) -> bytes | dict[str, int] | None:
        """
        Generate concrete input for a target state.
        
        Args:
            target_state: State to generate input for
            format: "bytes" or "dict"
            
        Returns:
            Concrete input values
        """
        model = self.solver.get_model(target_state.constraints)
        if not model:
            return None

        if format == "dict":
            return model

        # Convert to bytes (assuming symbol names are "{name}_{index}")
        result = bytearray()

        # Group by base name and sort by index
        groups: dict[str, dict[int, int]] = {}
        for name, value in model.items():
            if '_' in name:
                base, idx = name.rsplit('_', 1)
                if idx.isdigit():
                    if base not in groups:
                        groups[base] = {}
                    groups[base][int(idx)] = value

        # Concatenate each group
        for base in sorted(groups.keys()):
            indices = groups[base]
            max_idx = max(indices.keys())
            for i in range(max_idx + 1):
                result.append(indices.get(i, 0))

        return bytes(result)

    # === Configuration ===

    def set_strategy(self, strategy: ExplorationStrategy):
        """Set path exploration strategy."""
        self._strategy = strategy

    def set_limits(
        self,
        max_paths: int | None = None,
        max_instructions: int | None = None,
        max_depth: int | None = None
    ):
        """Set exploration limits."""
        if max_paths is not None:
            self.max_paths = max_paths
        if max_instructions is not None:
            self.max_instructions = max_instructions
        if max_depth is not None:
            self.max_depth = max_depth

    def set_branch_hook(self, hook: Callable[[PathState, int, int], None]):
        """Set hook called on each branch."""
        self._branch_hook = hook

    # === State Access ===

    def get_active_paths(self) -> list[PathState]:
        """Get all active path states."""
        return list(self._active_paths)

    def get_deadended_paths(self) -> list[PathState]:
        """Get all deadended path states."""
        return self._deadended_paths

    def get_target_paths(self) -> list[PathState]:
        """Get paths that reached target."""
        return self._target_paths

    def get_coverage(self) -> set[int]:
        """Get all covered addresses."""
        return self._covered_addresses

    def get_statistics(self) -> dict[str, int]:
        """Get exploration statistics."""
        return {
            'total_paths': self._path_counter,
            'active_paths': len(self._active_paths),
            'deadended_paths': len(self._deadended_paths),
            'errored_paths': len(self._errored_paths),
            'target_paths': len(self._target_paths),
            'instructions_executed': self._total_instructions,
            'branches_analyzed': self._total_branches,
            'addresses_covered': len(self._covered_addresses),
        }

    def reset(self):
        """Reset engine state."""
        self._symbols.clear()
        self._symbolic_memory.clear()
        self._symbolic_registers.clear()
        self._active_paths.clear()
        self._deadended_paths.clear()
        self._errored_paths.clear()
        self._target_paths.clear()
        self._path_counter = 0
        self._total_instructions = 0
        self._total_branches = 0
        self._covered_addresses.clear()


class ConcolicExecutor:
    """
    Concolic (concrete + symbolic) executor.
    
    Runs concrete execution while tracking symbolic
    constraints, then generates new inputs to explore
    different paths.
    """

    def __init__(
        self,
        emulator: 'Emulator',
        engine: SymbolicEngine | None = None
    ):
        self.emulator = emulator
        self.engine = engine or SymbolicEngine(emulator)

        # Input tracking
        self._input_bytes: dict[int, int] = {}  # address -> input index
        self._current_input: bytes = b""

        # Path tracking
        self._branch_history: list[tuple[int, bool]] = []
        self._path_constraints: list[Constraint] = []

        # Generated inputs
        self._input_queue: deque = deque()
        self._tested_inputs: set[bytes] = set()

    def set_input(self, address: int, data: bytes):
        """
        Set input data and make it symbolic.
        
        Args:
            address: Memory address
            data: Concrete input data
        """
        self._current_input = data

        # Write concrete data
        self.emulator.mem_write(address, data)

        # Make symbolic
        self.engine.make_symbolic("input", address, len(data))

        # Track input positions
        for i in range(len(data)):
            self._input_bytes[address + i] = i

    def run(
        self,
        start_addr: int,
        end_addr: int,
        max_iterations: int = 100
    ) -> list[bytes]:
        """
        Run concolic execution.
        
        Args:
            start_addr: Starting address
            end_addr: Ending address
            max_iterations: Maximum number of runs
            
        Returns:
            List of discovered inputs
        """
        discovered_inputs = []

        for iteration in range(max_iterations):
            # Run concrete execution
            self._branch_history.clear()
            self._path_constraints.clear()

            try:
                self.emulator.run(start_addr, end_addr)
            except Exception as e:
                logger.debug(f"Execution error: {e}")

            # Generate new inputs by negating path constraints
            for i in range(len(self._path_constraints)):
                # Try negating constraint i
                new_constraints = self._path_constraints[:i]
                negated = self._path_constraints[i].negate()
                new_constraints.append(negated)

                model = self.engine.solver.get_model(new_constraints)
                if model:
                    new_input = self._model_to_input(model)
                    if new_input and new_input not in self._tested_inputs:
                        self._input_queue.append(new_input)

            # Get next input
            if not self._input_queue:
                break

            next_input = self._input_queue.popleft()
            self._tested_inputs.add(next_input)
            discovered_inputs.append(next_input)

            # Set new input for next iteration
            # This would require knowing the input address

        return discovered_inputs

    def _model_to_input(self, model: dict[str, int]) -> bytes | None:
        """Convert solver model to input bytes."""
        if not model:
            return None

        result = bytearray(len(self._current_input))

        for name, value in model.items():
            if name.startswith("input_"):
                idx_str = name[6:]
                if idx_str.isdigit():
                    idx = int(idx_str)
                    if idx < len(result):
                        result[idx] = value & 0xFF

        return bytes(result)

    def on_branch(self, pc: int, condition: SymbolicValue, taken: bool):
        """
        Called when a branch is executed.
        
        Args:
            pc: Branch instruction address
            condition: Symbolic branch condition
            taken: Whether branch was taken
        """
        self._branch_history.append((pc, taken))

        constraint = Constraint(condition, taken, pc)
        self._path_constraints.append(constraint)


# === Convenience Functions ===

def create_symbolic_engine(emulator: Optional['Emulator'] = None) -> SymbolicEngine:
    """Create a new symbolic execution engine."""
    return SymbolicEngine(emulator)


def symbolic_variable(name: str, size: int = 64) -> SymbolicValue:
    """Create a symbolic variable."""
    return SymbolicValue.symbol(name, size)


def concrete_value(value: int, size: int = 64) -> SymbolicValue:
    """Create a concrete value."""
    return SymbolicValue.concrete(value, size)
