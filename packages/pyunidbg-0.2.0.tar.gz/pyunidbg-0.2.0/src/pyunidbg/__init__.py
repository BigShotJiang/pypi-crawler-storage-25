"""
PyUniDbg - A powerful Android native library emulator in Python.

This package provides tools for emulating Android native libraries (.so files)
on a desktop machine without requiring an actual Android device.
"""

from __future__ import annotations

__version__ = "0.2.0"
__author__ = "Brahim Bendali aka elvi7major"
__license__ = "Apache-2.0"

__all__ = [
    "Emulator",
    "AndroidEmulator",
    "MemoryManager",
    "HookManager",
    "HookAction",
    "ELFLoader",
    # Errors
    "PyUniDbgError",
    "EmulationError",
    "MemoryAccessError",
    "ArchitectureError",
    "LinkerError",
    "SymbolResolutionError",
    "LoaderError",
    "ConfigurationError",
    "SnapshotError",
    "IntegrationError",
    "IntegrationConnectionError",
    "IntegrationProtocolError",
    "IntegrationTimeoutError",
    "ScriptingError",
]


def __getattr__(name: str):
    """Lazy-load heavy submodules on first access to allow web server to start
    even when emulator dependencies (unicorn, lief, etc.) are not installed."""
    _errors = {
        "PyUniDbgError", "EmulationError", "MemoryAccessError",
        "ArchitectureError", "LinkerError", "SymbolResolutionError",
        "LoaderError", "ConfigurationError", "SnapshotError",
        "IntegrationError", "IntegrationConnectionError",
        "IntegrationProtocolError", "IntegrationTimeoutError",
        "ScriptingError",
    }
    if name in _errors:
        from pyunidbg import errors as _err_mod
        return getattr(_err_mod, name)

    _lazy = {
        "Emulator": ("pyunidbg.core.emulator", "Emulator"),
        "MemoryManager": ("pyunidbg.core.memory", "MemoryManager"),
        "HookManager": ("pyunidbg.core.hooks", "HookManager"),
        "HookAction": ("pyunidbg.core.hooks", "HookAction"),
        "ELFLoader": ("pyunidbg.loader.elf_loader", "ELFLoader"),
        "AndroidEmulator": ("pyunidbg.android.emulator", "AndroidEmulator"),
    }
    if name in _lazy:
        mod_path, attr = _lazy[name]
        import importlib
        mod = importlib.import_module(mod_path)
        return getattr(mod, attr)
    raise AttributeError(f"module 'pyunidbg' has no attribute {name!r}")
