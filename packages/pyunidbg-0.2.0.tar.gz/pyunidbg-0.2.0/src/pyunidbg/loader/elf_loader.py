"""ELF file loader for Android shared libraries."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import lief

from pyunidbg.core.constants import Architecture, MemoryLayout, MemoryProtection

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator


logger = logging.getLogger(__name__)


@dataclass
class Symbol:
    """Represents an ELF symbol."""

    name: str
    address: int
    size: int
    type: str  # FUNC, OBJECT, etc.
    binding: str  # GLOBAL, LOCAL, WEAK
    section: str | None = None

    @property
    def is_function(self) -> bool:
        return self.type == "FUNC"

    @property
    def is_exported(self) -> bool:
        return self.binding in ("GLOBAL", "WEAK")


@dataclass
class Relocation:
    """Represents an ELF relocation."""

    offset: int
    type: int
    symbol: str | None
    addend: int = 0


@dataclass
class LoadedModule:
    """Represents a loaded ELF module."""

    name: str
    path: Path
    base_address: int
    size: int
    entry_point: int | None = None

    # Symbol tables
    symbols: dict[str, Symbol] = field(default_factory=dict)
    symbols_by_addr: dict[int, Symbol] = field(default_factory=dict)

    # Sections info
    init_array: list[int] = field(default_factory=list)
    fini_array: list[int] = field(default_factory=list)

    # JNI specific
    jni_onload: int | None = None

    @property
    def base(self) -> int:
        """Alias for base_address for compatibility."""
        return self.base_address

    def get_symbol(self, name: str) -> Symbol | None:
        """Get symbol by name."""
        return self.symbols.get(name)

    def get_symbol_at(self, address: int) -> Symbol | None:
        """Get symbol at address."""
        return self.symbols_by_addr.get(address)

    def get_function_address(self, name: str) -> int | None:
        """Get function address by name."""
        sym = self.get_symbol(name)
        if sym and sym.is_function:
            return sym.address
        return None

    def __repr__(self) -> str:
        return (
            f"LoadedModule({self.name!r}, base={self.base_address:#x}, "
            f"size={self.size:#x}, symbols={len(self.symbols)})"
        )


class ELFLoader:
    """
    Loads ELF files (Android .so libraries) into the emulator.
    
    Handles:
    - Parsing ELF headers and segments
    - Mapping segments into memory
    - Symbol resolution
    - Relocations
    - Dynamic linking
    """

    def __init__(self, emulator: Emulator):
        self._emulator = emulator
        self._modules: dict[str, LoadedModule] = {}
        self._global_symbols: dict[str, tuple[LoadedModule, Symbol]] = {}

        # Symbol hooks: name -> (address, handler)
        # When a symbol is resolved to a hooked address, the handler is called
        self._symbol_hooks: dict[str, tuple[int, Any]] = {}

        # Stub allocation for hooked symbols
        self._stub_base = 0xDEAD0000
        self._stub_offset = 0

    def load(
        self,
        path: str | Path,
        base_address: int | None = None,
        auto_init: bool = True,
    ) -> LoadedModule:
        """
        Load an ELF file into the emulator.
        
        Args:
            path: Path to the ELF file
            base_address: Base address for loading (auto-assigned if None)
            auto_init: Call init functions after loading
        
        Returns:
            LoadedModule representing the loaded library
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"ELF file not found: {path}")

        # Parse ELF
        binary = lief.parse(str(path))
        if binary is None:
            raise ValueError(f"Failed to parse ELF file: {path}")

        # Check architecture compatibility
        self._check_architecture(binary)

        # Calculate size and allocate base address
        load_size = self._calculate_load_size(binary)
        if base_address is None:
            base_address = self._emulator.memory.allocate_lib_space(load_size)

        logger.info(f"Loading {path.name} at {base_address:#x} (size: {load_size:#x})")

        # Create module
        module = LoadedModule(
            name=path.stem,
            path=path,
            base_address=base_address,
            size=load_size,
        )

        # Load segments
        self._load_segments(binary, module)

        # Process symbols
        self._process_symbols(binary, module)

        # Process relocations
        self._process_relocations(binary, module)

        # Find special sections
        self._process_special_sections(binary, module)

        # Register module
        self._modules[module.name] = module

        # Update global symbol table
        for name, sym in module.symbols.items():
            if sym.is_exported and name not in self._global_symbols:
                self._global_symbols[name] = (module, sym)

        # Run init functions if requested
        if auto_init:
            self._run_init_functions(module)

        return module

    def _check_architecture(self, binary: lief.ELF.Binary) -> None:
        """Check if ELF architecture matches emulator."""
        elf_arch = binary.header.machine_type
        emu_arch = self._emulator.arch

        arch_map = {
            lief.ELF.ARCH.ARM: Architecture.ARM,
            lief.ELF.ARCH.AARCH64: Architecture.ARM64,
            lief.ELF.ARCH.I386: Architecture.X86,
            lief.ELF.ARCH.X86_64: Architecture.X86_64,
        }

        elf_mapped = arch_map.get(elf_arch)
        if elf_mapped != emu_arch:
            raise ValueError(
                f"Architecture mismatch: ELF is {elf_arch.name}, "
                f"emulator is {emu_arch.value}"
            )

    def _calculate_load_size(self, binary: lief.ELF.Binary) -> int:
        """Calculate total size needed to load all segments."""
        min_addr = float('inf')
        max_addr = 0

        for segment in binary.segments:
            if segment.type == lief.ELF.Segment.TYPE.LOAD:
                seg_start = segment.virtual_address
                seg_end = seg_start + segment.virtual_size
                min_addr = min(min_addr, seg_start)
                max_addr = max(max_addr, seg_end)

        if min_addr == float('inf'):
            return 0

        return MemoryLayout.align_up(max_addr - min_addr)

    def _load_segments(self, binary: lief.ELF.Binary, module: LoadedModule) -> None:
        """Load ELF segments into memory."""
        base = module.base_address

        for segment in binary.segments:
            if segment.type != lief.ELF.Segment.TYPE.LOAD:
                continue

            vaddr = base + segment.virtual_address
            memsz = segment.virtual_size
            filesz = segment.physical_size

            if memsz == 0:
                continue

            # Determine protection
            prot = MemoryProtection.NONE
            if segment.has(lief.ELF.Segment.FLAGS.R):
                prot |= MemoryProtection.READ
            if segment.has(lief.ELF.Segment.FLAGS.W):
                prot |= MemoryProtection.WRITE
            if segment.has(lief.ELF.Segment.FLAGS.X):
                prot |= MemoryProtection.EXEC

            # Align addresses
            aligned_vaddr = MemoryLayout.align_down(vaddr)
            aligned_size = MemoryLayout.align_up(memsz + (vaddr - aligned_vaddr))

            # Map memory
            try:
                self._emulator.memory.map(
                    aligned_vaddr,
                    aligned_size,
                    prot,
                    name=f"{module.name}",
                )
            except ValueError:
                # Region might already be mapped (overlapping segments)
                pass

            # Write segment data
            if filesz > 0:
                data = bytes(segment.content)
                self._emulator.memory.write(vaddr, data[:filesz])

            # Zero-fill remaining (BSS)
            if memsz > filesz:
                zero_fill = b'\x00' * (memsz - filesz)
                self._emulator.memory.write(vaddr + filesz, zero_fill)

            logger.debug(
                f"  Loaded segment at {vaddr:#x}, size={memsz:#x}, "
                f"filesz={filesz:#x}, prot={prot}"
            )

    def _process_symbols(self, binary: lief.ELF.Binary, module: LoadedModule) -> None:
        """Process ELF symbol tables."""
        base = module.base_address

        for sym in binary.symbols:
            if not sym.name:
                continue

            symbol = Symbol(
                name=sym.name,
                address=base + sym.value if sym.value else 0,
                size=sym.size,
                type=str(sym.type).split('.')[-1],
                binding=str(sym.binding).split('.')[-1],
            )

            module.symbols[sym.name] = symbol
            if symbol.address:
                module.symbols_by_addr[symbol.address] = symbol

        logger.debug(f"  Processed {len(module.symbols)} symbols")

    def _process_relocations(self, binary: lief.ELF.Binary, module: LoadedModule) -> None:
        """Process and apply relocations."""
        base = module.base_address
        ptr_size = self._emulator.pointer_size

        for reloc in binary.relocations:
            target_addr = base + reloc.address

            # Get symbol value
            sym_value = 0
            if reloc.has_symbol and reloc.symbol.name:
                # Look up symbol
                sym_name = reloc.symbol.name
                resolved = self._resolve_symbol(sym_name, module)
                if resolved:
                    sym_value = resolved.address
                else:
                    logger.warning(f"Unresolved symbol: {sym_name}")
                    continue

            # Apply relocation based on type
            # This is ARM64 specific - would need expansion for other archs
            reloc_type = reloc.type

            if self._emulator.arch == Architecture.ARM64:
                self._apply_arm64_relocation(
                    reloc_type, target_addr, sym_value, reloc.addend, base
                )
            elif self._emulator.arch == Architecture.ARM:
                self._apply_arm_relocation(
                    reloc_type, target_addr, sym_value, reloc.addend, base
                )

    def _apply_arm64_relocation(
        self,
        reloc_type,  # LIEF relocation type enum
        target: int,
        sym_value: int,
        addend: int,
        base: int,
    ) -> None:
        """Apply ARM64 relocation."""
        # Use LIEF enum types for comparison
        RTYPE = lief.ELF.Relocation.TYPE

        if reloc_type == RTYPE.AARCH64_RELATIVE:
            value = base + addend
            self._emulator.memory.write_u64(target, value)
        elif reloc_type in (RTYPE.AARCH64_GLOB_DAT, RTYPE.AARCH64_JUMP_SLOT, RTYPE.AARCH64_ABS64):
            value = sym_value + addend
            self._emulator.memory.write_u64(target, value)

    def _apply_arm_relocation(
        self,
        reloc_type,  # LIEF relocation type enum
        target: int,
        sym_value: int,
        addend: int,
        base: int,
    ) -> None:
        """Apply ARM32 relocation."""
        # Use LIEF enum types for comparison
        RTYPE = lief.ELF.Relocation.TYPE

        if reloc_type == RTYPE.ARM_RELATIVE:
            value = base + addend
            self._emulator.memory.write_u32(target, value)
        elif reloc_type in (RTYPE.ARM_GLOB_DAT, RTYPE.ARM_JUMP_SLOT, RTYPE.ARM_ABS32):
            value = sym_value + addend
            self._emulator.memory.write_u32(target, value)

    def _resolve_symbol(self, name: str, current_module: LoadedModule) -> Symbol | None:
        """Resolve a symbol, searching hooks, current module, and global table."""
        # First check symbol hooks
        if name in self._symbol_hooks:
            stub_addr, _ = self._symbol_hooks[name]
            return Symbol(
                name=name,
                address=stub_addr,
                size=4,
                type="FUNC",
                binding="GLOBAL",
            )

        # Check current module
        if name in current_module.symbols:
            sym = current_module.symbols[name]
            if sym.address:
                return sym

        # Then check global symbols
        if name in self._global_symbols:
            return self._global_symbols[name][1]

        return None

    def _process_special_sections(
        self,
        binary: lief.ELF.Binary,
        module: LoadedModule,
    ) -> None:
        """Process init_array, fini_array, and find JNI_OnLoad."""
        base = module.base_address
        ptr_size = self._emulator.pointer_size

        # Read init_array / fini_array from EMULATED memory rather than the
        # raw on-disk section bytes: PIC binaries leave these slots zeroed in
        # the file and rely on R_AARCH64_RELATIVE / R_ARM_RELATIVE relocations
        # (already applied by _process_relocations above) to fill in absolute
        # addresses at load time. Reading the file content would yield 0 and
        # silently skip every constructor.
        for section in binary.sections:
            if section.name not in (".init_array", ".fini_array"):
                continue
            target = module.fini_array if section.name == ".fini_array" else module.init_array
            section_addr = base + section.virtual_address
            for i in range(0, section.size, ptr_size):
                try:
                    raw = self._emulator.memory.read(section_addr + i, ptr_size)
                except Exception:
                    continue
                addr = int.from_bytes(raw, 'little')
                if not addr:
                    continue
                # Some toolchains emit absolute addresses (already including
                # the load base via RELATIVE relocs), older code assumed file
                # offsets; tolerate both by adding base only when the value
                # clearly is an offset within the module.
                if addr < module.size:
                    addr = base + addr
                target.append(addr)

        # Find JNI_OnLoad
        if "JNI_OnLoad" in module.symbols:
            module.jni_onload = module.symbols["JNI_OnLoad"].address
            logger.debug(f"  Found JNI_OnLoad at {module.jni_onload:#x}")

    def _run_init_functions(self, module: LoadedModule) -> None:
        """Run module initialization functions."""
        for init_addr in module.init_array:
            logger.debug(f"  Running init function at {init_addr:#x}")
            try:
                self._emulator.call(init_addr)
            except Exception as e:
                logger.warning(f"  Init function at {init_addr:#x} failed: {e}")

    def get_module(self, name: str) -> LoadedModule | None:
        """Get a loaded module by name."""
        return self._modules.get(name)

    def get_symbol(self, name: str) -> tuple[LoadedModule, Symbol] | None:
        """Get a symbol from any loaded module."""
        return self._global_symbols.get(name)

    def list_modules(self) -> list[LoadedModule]:
        """List all loaded modules."""
        return list(self._modules.values())

    def list_symbols(self, module_name: str | None = None) -> list[Symbol]:
        """List symbols, optionally filtered by module."""
        if module_name:
            module = self._modules.get(module_name)
            if module:
                return list(module.symbols.values())
            return []

        return [sym for _, sym in self._global_symbols.values()]

    # ==================== Symbol Hooks ====================

    def add_symbol_hook(self, name: str, handler: Any) -> int:
        """
        Hook symbol resolution for a libc/external function.
        
        When the symbol is called, execution stops at the stub and
        the handler is invoked to provide the return value.
        
        Args:
            name: Symbol name (e.g., "malloc")
            handler: Python callable to handle the function
            
        Returns:
            The stub address assigned to this symbol
        """
        # Allocate stub address
        stub_addr = self._stub_base + self._stub_offset
        self._stub_offset += 0x10  # 16 bytes per stub

        self._symbol_hooks[name] = (stub_addr, handler)
        logger.debug(f"Symbol hook: {name} -> 0x{stub_addr:x}")

        return stub_addr

    def add_symbol_hooks(self, hooks: dict[str, Any]) -> dict[str, int]:
        """
        Register multiple symbol hooks at once.
        
        Args:
            hooks: Dict of {symbol_name: handler}
            
        Returns:
            Dict of {symbol_name: stub_address}
        """
        result = {}
        for name, handler in hooks.items():
            result[name] = self.add_symbol_hook(name, handler)
        return result

    def get_symbol_hook(self, name: str) -> tuple[int, Any] | None:
        """Get hook info for a symbol."""
        return self._symbol_hooks.get(name)

    def get_hook_at_address(self, address: int) -> tuple[str, Any] | None:
        """Get hook info by stub address."""
        for name, (addr, handler) in self._symbol_hooks.items():
            if addr == address:
                return (name, handler)
        return None

    def remove_symbol_hook(self, name: str) -> bool:
        """Remove a symbol hook."""
        if name in self._symbol_hooks:
            del self._symbol_hooks[name]
            return True
        return False

    def list_symbol_hooks(self) -> list[tuple[str, int]]:
        """List all symbol hooks."""
        return [(name, addr) for name, (addr, _) in self._symbol_hooks.items()]
