"""
Frida Bridge Module - Interoperability with Frida for PyUniDbg

This module provides:
- Frida-like JavaScript API syntax for hooks
- Import/export of Frida scripts and snippets
- Memory access patterns compatible with Frida
- Interceptor-style function hooking
- Message passing simulation
- Script parsing and conversion
"""

from __future__ import annotations

import json
import re
import struct
import threading
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from functools import wraps
from re import Pattern
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Optional,
    Tuple,
    Union,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)

__all__ = [
    # Core bridge classes
    "FridaBridge",
    "FridaScript",
    "ScriptRuntime",
    # Frida-like API
    "Interceptor",
    "Memory",
    "Module",
    "Process",
    "NativePointer",
    "NativeFunction",
    # Hook types
    "InvocationContext",
    "InvocationArgs",
    "InvocationReturnValue",
    # Script parsing
    "ScriptParser",
    "ScriptConverter",
    # Message passing
    "MessageBus",
    "Message",
    # Enums
    "HookType",
    "ScriptState",
]


class HookType(Enum):
    """Types of hooks."""
    ATTACH = auto()
    REPLACE = auto()


class ScriptState(Enum):
    """Script execution state."""
    CREATED = auto()
    LOADED = auto()
    RUNNING = auto()
    PAUSED = auto()
    STOPPED = auto()
    ERROR = auto()


@dataclass
class Message:
    """A message from script to host."""
    type: str
    payload: Any
    data: bytes | None = None

    def to_dict(self) -> dict[str, Any]:
        result = {"type": self.type, "payload": self.payload}
        if self.data:
            result["data"] = self.data.hex()
        return result

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Message:
        data = bytes.fromhex(d["data"]) if "data" in d else None
        return cls(type=d["type"], payload=d["payload"], data=data)


class MessageBus:
    """Message bus for script<->host communication."""

    def __init__(self):
        self._messages: list[Message] = []
        self._handlers: list[Callable[[Message], None]] = []
        self._lock = threading.Lock()

    def send(self, msg: Message) -> None:
        """Send a message."""
        with self._lock:
            self._messages.append(msg)
            for handler in self._handlers:
                try:
                    handler(msg)
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)

    def on_message(self, handler: Callable[[Message], None]) -> None:
        """Register a message handler."""
        with self._lock:
            self._handlers.append(handler)

    def receive(self) -> Message | None:
        """Receive next message."""
        with self._lock:
            if self._messages:
                return self._messages.pop(0)
            return None

    def receive_all(self) -> list[Message]:
        """Receive all messages."""
        with self._lock:
            msgs = self._messages.copy()
            self._messages.clear()
            return msgs

    def clear(self) -> None:
        """Clear all messages."""
        with self._lock:
            self._messages.clear()


class NativePointer:
    """Frida-like NativePointer for memory operations."""

    def __init__(self, address: int, bridge: FridaBridge):
        self._address = address & 0xFFFFFFFFFFFFFFFF
        self._bridge = bridge

    @property
    def address(self) -> int:
        return self._address

    def __int__(self) -> int:
        return self._address

    def __str__(self) -> str:
        return f"0x{self._address:x}"

    def __repr__(self) -> str:
        return f"NativePointer({self})"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, NativePointer):
            return self._address == other._address
        if isinstance(other, int):
            return self._address == other
        return False

    def __hash__(self) -> int:
        return hash(self._address)

    def __add__(self, offset: int) -> NativePointer:
        return NativePointer(self._address + offset, self._bridge)

    def __sub__(self, offset: int) -> NativePointer:
        return NativePointer(self._address - offset, self._bridge)

    def isNull(self) -> bool:
        """Check if pointer is null."""
        return self._address == 0

    def toInt32(self) -> int:
        """Convert to signed 32-bit integer."""
        val = self._address & 0xFFFFFFFF
        if val >= 0x80000000:
            val -= 0x100000000
        return val

    def toUInt32(self) -> int:
        """Convert to unsigned 32-bit integer."""
        return self._address & 0xFFFFFFFF

    def toString(self, radix: int = 16) -> str:
        """Convert to string."""
        if radix == 16:
            return f"0x{self._address:x}"
        elif radix == 10:
            return str(self._address)
        else:
            raise ValueError(f"Unsupported radix: {radix}")

    # Memory read operations
    def readU8(self) -> int:
        """Read unsigned 8-bit value."""
        return self._bridge.memory.readU8(self)

    def readS8(self) -> int:
        """Read signed 8-bit value."""
        return self._bridge.memory.readS8(self)

    def readU16(self) -> int:
        """Read unsigned 16-bit value."""
        return self._bridge.memory.readU16(self)

    def readS16(self) -> int:
        """Read signed 16-bit value."""
        return self._bridge.memory.readS16(self)

    def readU32(self) -> int:
        """Read unsigned 32-bit value."""
        return self._bridge.memory.readU32(self)

    def readS32(self) -> int:
        """Read signed 32-bit value."""
        return self._bridge.memory.readS32(self)

    def readU64(self) -> int:
        """Read unsigned 64-bit value."""
        return self._bridge.memory.readU64(self)

    def readS64(self) -> int:
        """Read signed 64-bit value."""
        return self._bridge.memory.readS64(self)

    def readPointer(self) -> NativePointer:
        """Read a pointer value."""
        return self._bridge.memory.readPointer(self)

    def readByteArray(self, length: int) -> bytes:
        """Read byte array."""
        return self._bridge.memory.readByteArray(self, length)

    def readCString(self, size: int = -1) -> str:
        """Read null-terminated C string."""
        return self._bridge.memory.readCString(self, size)

    def readUtf8String(self, size: int = -1) -> str:
        """Read UTF-8 string."""
        return self._bridge.memory.readUtf8String(self, size)

    def readUtf16String(self, length: int = -1) -> str:
        """Read UTF-16 string."""
        return self._bridge.memory.readUtf16String(self, length)

    # Memory write operations
    def writeU8(self, value: int) -> NativePointer:
        """Write unsigned 8-bit value."""
        self._bridge.memory.writeU8(self, value)
        return self

    def writeS8(self, value: int) -> NativePointer:
        """Write signed 8-bit value."""
        self._bridge.memory.writeS8(self, value)
        return self

    def writeU16(self, value: int) -> NativePointer:
        """Write unsigned 16-bit value."""
        self._bridge.memory.writeU16(self, value)
        return self

    def writeS16(self, value: int) -> NativePointer:
        """Write signed 16-bit value."""
        self._bridge.memory.writeS16(self, value)
        return self

    def writeU32(self, value: int) -> NativePointer:
        """Write unsigned 32-bit value."""
        self._bridge.memory.writeU32(self, value)
        return self

    def writeS32(self, value: int) -> NativePointer:
        """Write signed 32-bit value."""
        self._bridge.memory.writeS32(self, value)
        return self

    def writeU64(self, value: int) -> NativePointer:
        """Write unsigned 64-bit value."""
        self._bridge.memory.writeU64(self, value)
        return self

    def writeS64(self, value: int) -> NativePointer:
        """Write signed 64-bit value."""
        self._bridge.memory.writeS64(self, value)
        return self

    def writePointer(self, value: NativePointer | int) -> NativePointer:
        """Write pointer value."""
        self._bridge.memory.writePointer(self, value)
        return self

    def writeByteArray(self, data: bytes) -> NativePointer:
        """Write byte array."""
        self._bridge.memory.writeByteArray(self, data)
        return self

    def writeUtf8String(self, s: str) -> NativePointer:
        """Write UTF-8 string."""
        self._bridge.memory.writeUtf8String(self, s)
        return self


class NativeFunction:
    """Frida-like NativeFunction wrapper."""

    def __init__(self, address: NativePointer | int, return_type: str,
                 arg_types: list[str], bridge: FridaBridge):
        if isinstance(address, NativePointer):
            self._address = address.address
        else:
            self._address = address
        self._return_type = return_type
        self._arg_types = arg_types
        self._bridge = bridge

    @property
    def address(self) -> int:
        return self._address

    def __call__(self, *args) -> Any:
        """Call the native function."""
        return self._bridge._call_native_function(
            self._address, self._return_type, self._arg_types, list(args)
        )


class InvocationArgs:
    """Arguments passed to a hooked function."""

    def __init__(self, args: list[int], bridge: FridaBridge):
        self._args = args
        self._bridge = bridge

    def __getitem__(self, index: int) -> NativePointer:
        if index < len(self._args):
            return NativePointer(self._args[index], self._bridge)
        return NativePointer(0, self._bridge)

    def __setitem__(self, index: int, value: NativePointer | int) -> None:
        if isinstance(value, NativePointer):
            value = value.address
        while len(self._args) <= index:
            self._args.append(0)
        self._args[index] = value

    def __len__(self) -> int:
        return len(self._args)

    def toArray(self) -> list[NativePointer]:
        """Convert to array of NativePointers."""
        return [NativePointer(a, self._bridge) for a in self._args]


class InvocationReturnValue:
    """Return value container for hooked functions."""

    def __init__(self, value: int, bridge: FridaBridge):
        self._value = value
        self._bridge = bridge
        self._replaced = False

    def replace(self, value: NativePointer | int) -> None:
        """Replace the return value."""
        if isinstance(value, NativePointer):
            value = value.address
        self._value = value
        self._replaced = True

    @property
    def value(self) -> int:
        return self._value

    @property
    def was_replaced(self) -> bool:
        return self._replaced

    def toInt32(self) -> int:
        """Convert to signed 32-bit integer."""
        val = self._value & 0xFFFFFFFF
        if val >= 0x80000000:
            val -= 0x100000000
        return val

    def toUInt32(self) -> int:
        """Convert to unsigned 32-bit integer."""
        return self._value & 0xFFFFFFFF


@dataclass
class InvocationContext:
    """Context for function invocation hooks."""

    returnAddress: NativePointer
    context: dict[str, NativePointer]
    threadId: int
    depth: int
    args: InvocationArgs | None = None
    returnValue: InvocationReturnValue | None = None

    # For storing user data between onEnter and onLeave
    _user_data: dict[str, Any] = field(default_factory=dict)

    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            raise AttributeError(name)
        return self._user_data.get(name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name in ('returnAddress', 'context', 'threadId', 'depth',
                    'args', 'returnValue', '_user_data'):
            super().__setattr__(name, value)
        else:
            self._user_data[name] = value


class Memory:
    """Frida-like Memory API."""

    def __init__(self, bridge: FridaBridge):
        self._bridge = bridge

    def _read(self, address: NativePointer | int, size: int) -> bytes:
        """Read bytes from memory."""
        if isinstance(address, NativePointer):
            address = address.address
        if self._bridge._emulator:
            return self._bridge._emulator.mem_read(address, size)

        # Fallback: byte-level memory read
        result = bytearray(size)
        for i in range(size):
            addr = address + i
            if addr in self._bridge._memory:
                result[i] = self._bridge._memory[addr]
        return bytes(result)

    def _write(self, address: NativePointer | int, data: bytes) -> None:
        """Write bytes to memory."""
        if isinstance(address, NativePointer):
            address = address.address
        if self._bridge._emulator:
            self._bridge._emulator.mem_write(address, data)
        else:
            # Fallback: byte-level memory write
            for i, byte in enumerate(data):
                self._bridge._memory[address + i] = byte

    # Read operations
    def readU8(self, address: NativePointer | int) -> int:
        return struct.unpack('<B', self._read(address, 1))[0]

    def readS8(self, address: NativePointer | int) -> int:
        return struct.unpack('<b', self._read(address, 1))[0]

    def readU16(self, address: NativePointer | int) -> int:
        return struct.unpack('<H', self._read(address, 2))[0]

    def readS16(self, address: NativePointer | int) -> int:
        return struct.unpack('<h', self._read(address, 2))[0]

    def readU32(self, address: NativePointer | int) -> int:
        return struct.unpack('<I', self._read(address, 4))[0]

    def readS32(self, address: NativePointer | int) -> int:
        return struct.unpack('<i', self._read(address, 4))[0]

    def readU64(self, address: NativePointer | int) -> int:
        return struct.unpack('<Q', self._read(address, 8))[0]

    def readS64(self, address: NativePointer | int) -> int:
        return struct.unpack('<q', self._read(address, 8))[0]

    def readShort(self, address: NativePointer | int) -> int:
        return self.readS16(address)

    def readUShort(self, address: NativePointer | int) -> int:
        return self.readU16(address)

    def readInt(self, address: NativePointer | int) -> int:
        return self.readS32(address)

    def readUInt(self, address: NativePointer | int) -> int:
        return self.readU32(address)

    def readLong(self, address: NativePointer | int) -> int:
        if self._bridge._pointer_size == 8:
            return self.readS64(address)
        return self.readS32(address)

    def readULong(self, address: NativePointer | int) -> int:
        if self._bridge._pointer_size == 8:
            return self.readU64(address)
        return self.readU32(address)

    def readFloat(self, address: NativePointer | int) -> float:
        return struct.unpack('<f', self._read(address, 4))[0]

    def readDouble(self, address: NativePointer | int) -> float:
        return struct.unpack('<d', self._read(address, 8))[0]

    def readPointer(self, address: NativePointer | int) -> NativePointer:
        if self._bridge._pointer_size == 8:
            val = self.readU64(address)
        else:
            val = self.readU32(address)
        return NativePointer(val, self._bridge)

    def readByteArray(self, address: NativePointer | int,
                      length: int) -> bytes:
        return self._read(address, length)

    def readCString(self, address: NativePointer | int,
                    size: int = -1) -> str:
        if isinstance(address, NativePointer):
            address = address.address

        if size >= 0:
            data = self._read(address, size)
            null_idx = data.find(b'\x00')
            if null_idx >= 0:
                data = data[:null_idx]
            return data.decode('utf-8', errors='replace')

        # Read until null terminator
        result = []
        offset = 0
        while True:
            byte = self._read(address + offset, 1)
            if byte == b'\x00':
                break
            result.append(byte)
            offset += 1
            if offset > 4096:  # Safety limit
                break

        return b''.join(result).decode('utf-8', errors='replace')

    def readUtf8String(self, address: NativePointer | int,
                       size: int = -1) -> str:
        return self.readCString(address, size)

    def readUtf16String(self, address: NativePointer | int,
                        length: int = -1) -> str:
        if isinstance(address, NativePointer):
            address = address.address

        if length >= 0:
            data = self._read(address, length * 2)
        else:
            # Read until null terminator (2 bytes)
            result = []
            offset = 0
            while True:
                word = self._read(address + offset, 2)
                if word == b'\x00\x00':
                    break
                result.append(word)
                offset += 2
                if offset > 8192:
                    break
            data = b''.join(result)

        return data.decode('utf-16-le', errors='replace')

    # Write operations
    def writeU8(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<B', value & 0xFF))

    def writeS8(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<b', value))

    def writeU16(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<H', value & 0xFFFF))

    def writeS16(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<h', value))

    def writeU32(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<I', value & 0xFFFFFFFF))

    def writeS32(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<i', value))

    def writeU64(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<Q', value & 0xFFFFFFFFFFFFFFFF))

    def writeS64(self, address: NativePointer | int, value: int) -> None:
        self._write(address, struct.pack('<q', value))

    def writeShort(self, address: NativePointer | int, value: int) -> None:
        self.writeS16(address, value)

    def writeUShort(self, address: NativePointer | int, value: int) -> None:
        self.writeU16(address, value)

    def writeInt(self, address: NativePointer | int, value: int) -> None:
        self.writeS32(address, value)

    def writeUInt(self, address: NativePointer | int, value: int) -> None:
        self.writeU32(address, value)

    def writeFloat(self, address: NativePointer | int, value: float) -> None:
        self._write(address, struct.pack('<f', value))

    def writeDouble(self, address: NativePointer | int, value: float) -> None:
        self._write(address, struct.pack('<d', value))

    def writePointer(self, address: NativePointer | int,
                     value: NativePointer | int) -> None:
        if isinstance(value, NativePointer):
            value = value.address
        if self._bridge._pointer_size == 8:
            self.writeU64(address, value)
        else:
            self.writeU32(address, value)

    def writeByteArray(self, address: NativePointer | int,
                       data: bytes) -> None:
        self._write(address, data)

    def writeUtf8String(self, address: NativePointer | int, s: str) -> None:
        self._write(address, s.encode('utf-8') + b'\x00')

    def writeUtf16String(self, address: NativePointer | int, s: str) -> None:
        self._write(address, s.encode('utf-16-le') + b'\x00\x00')

    # Memory operations
    def alloc(self, size: int) -> NativePointer:
        """Allocate memory in the emulator."""
        if self._bridge._emulator:
            try:
                addr = self._bridge._emulator.memory.allocate(size, name="[frida-alloc]")
                return NativePointer(addr, self._bridge)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        # Fallback for standalone bridge usage
        addr = self._bridge._next_alloc_addr
        self._bridge._next_alloc_addr += (size + 0xFFF) & ~0xFFF
        return NativePointer(addr, self._bridge)

    def allocUtf8String(self, s: str) -> NativePointer:
        """Allocate and write a UTF-8 string."""
        data = s.encode('utf-8') + b'\x00'
        ptr = self.alloc(len(data))
        self.writeByteArray(ptr, data)
        return ptr

    def allocUtf16String(self, s: str) -> NativePointer:
        """Allocate and write a UTF-16 string."""
        data = s.encode('utf-16-le') + b'\x00\x00'
        ptr = self.alloc(len(data))
        self.writeByteArray(ptr, data)
        return ptr

    def copy(self, dst: NativePointer | int,
             src: NativePointer | int, n: int) -> None:
        """Copy memory."""
        data = self._read(src, n)
        self._write(dst, data)

    def protect(self, address: NativePointer | int,
                size: int, protection: str) -> bool:
        """Change memory protection using emulator's memory manager."""
        if isinstance(address, NativePointer):
            address = address.address

        if self._bridge._emulator:
            try:
                from pyunidbg.core.constants import MemoryProtection
                prot = MemoryProtection.NONE
                if 'r' in protection:
                    prot |= MemoryProtection.READ
                if 'w' in protection:
                    prot |= MemoryProtection.WRITE
                if 'x' in protection:
                    prot |= MemoryProtection.EXEC
                self._bridge._emulator.memory.protect(address, size, prot)
                return True
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                return False
        return True

    def scan(self, address: NativePointer | int,
             size: int, pattern: str) -> list[dict[str, Any]]:
        """Scan memory for pattern."""
        if isinstance(address, NativePointer):
            address = address.address

        matches = []
        data = self._read(address, size)

        # Parse pattern (e.g., "41 42 ?? 44")
        parts = pattern.split()
        search_bytes = []
        mask = []

        for part in parts:
            if part == '??':
                search_bytes.append(0)
                mask.append(False)
            else:
                search_bytes.append(int(part, 16))
                mask.append(True)

        # Scan
        for i in range(len(data) - len(search_bytes) + 1):
            found = True
            for j, (b, m) in enumerate(zip(search_bytes, mask)):
                if m and data[i + j] != b:
                    found = False
                    break
            if found:
                matches.append({
                    "address": NativePointer(address + i, self._bridge),
                    "size": len(search_bytes),
                })

        return matches


@dataclass
class ModuleInfo:
    """Information about a loaded module."""
    name: str
    base: NativePointer
    size: int
    path: str


class Module:
    """Frida-like Module API."""

    def __init__(self, bridge: FridaBridge):
        self._bridge = bridge
        self._modules: dict[str, ModuleInfo] = {}
        self._exports: dict[str, dict[str, int]] = {}

    def load(self, name: str) -> ModuleInfo | None:
        """Load a module by name from the emulator's loaded modules."""
        if name in self._modules:
            return self._modules[name]

        # Try to find the module in the emulator's loaded libraries
        if self._bridge._emulator:
            emu = self._bridge._emulator
            # Check emulator's module list (name or basename match)
            modules = getattr(emu, '_modules', {})
            for mod_name, mod in modules.items():
                if mod_name == name or mod_name.endswith(f'/{name}'):
                    base = getattr(mod, 'base', 0) or getattr(mod, 'load_base', 0) or 0
                    size = getattr(mod, 'size', 0) or getattr(mod, 'load_size', 0) or 0
                    path = getattr(mod, 'path', mod_name) or mod_name
                    self._register_module(name, base, size, path)
                    # Register known exports
                    exports = getattr(mod, 'exports', {})
                    if isinstance(exports, dict):
                        for exp_name, exp_addr in exports.items():
                            self._register_export(name, exp_name, exp_addr)
                    return self._modules[name]

        return None

    def findBaseAddress(self, name: str) -> NativePointer | None:
        """Find base address of a module."""
        if name in self._modules:
            return self._modules[name].base
        return None

    def findExportByName(self, module_name: str | None,
                         export_name: str) -> NativePointer | None:
        """Find export by name."""
        if module_name and module_name in self._exports:
            if export_name in self._exports[module_name]:
                addr = self._exports[module_name][export_name]
                return NativePointer(addr, self._bridge)

        # Search all modules if module_name is None
        if module_name is None:
            for exports in self._exports.values():
                if export_name in exports:
                    return NativePointer(exports[export_name], self._bridge)

        return None

    def enumerateExports(self, name: str) -> list[dict[str, Any]]:
        """Enumerate exports of a module."""
        if name not in self._exports:
            return []

        result = []
        for export_name, addr in self._exports[name].items():
            result.append({
                "type": "function",  # Simplified
                "name": export_name,
                "address": NativePointer(addr, self._bridge),
            })
        return result

    def enumerateImports(self, name: str) -> list[dict[str, Any]]:
        """Enumerate imports of a module from the emulator."""
        if self._bridge._emulator:
            emu = self._bridge._emulator
            modules = getattr(emu, '_modules', {})
            mod = modules.get(name)
            if mod:
                imports = getattr(mod, 'imports', {})
                if isinstance(imports, dict):
                    return [
                        {
                            "type": "function",
                            "name": imp_name,
                            "module": imp_info.get("module", "") if isinstance(imp_info, dict) else "",
                            "address": NativePointer(
                                imp_info.get("address", 0) if isinstance(imp_info, dict) else imp_info,
                                self._bridge
                            ),
                        }
                        for imp_name, imp_info in imports.items()
                    ]
        return []

    def enumerateRanges(self, name: str,
                        protection: str) -> list[dict[str, Any]]:
        """Enumerate memory ranges for a module from the emulator."""
        if not self._bridge._emulator:
            return []

        mod_info = self._modules.get(name)
        if not mod_info:
            return []

        result = []
        mod_base = mod_info.base.address
        mod_end = mod_base + mod_info.size

        for region in self._bridge._emulator.memory.get_regions():
            if region.start >= mod_end or region.end <= mod_base:
                continue

            prot_str = ""
            prot_str += "r" if region.protection & 1 else "-"
            prot_str += "w" if region.protection & 2 else "-"
            prot_str += "x" if region.protection & 4 else "-"

            if self._prot_matches(prot_str, protection):
                result.append({
                    "base": NativePointer(region.start, self._bridge),
                    "size": region.size,
                    "protection": prot_str,
                    "file": {"path": mod_info.path, "offset": 0, "size": region.size},
                })
        return result

    @staticmethod
    def _prot_matches(actual: str, required: str) -> bool:
        """Check if memory protection matches the required filter."""
        for c in required:
            if c == 'r' and 'r' not in actual:
                return False
            if c == 'w' and 'w' not in actual:
                return False
            if c == 'x' and 'x' not in actual:
                return False
        return True

    # Registration methods for emulator integration
    def _register_module(self, name: str, base: int, size: int,
                         path: str = "") -> None:
        """Register a module."""
        self._modules[name] = ModuleInfo(
            name=name,
            base=NativePointer(base, self._bridge),
            size=size,
            path=path or name,
        )
        if name not in self._exports:
            self._exports[name] = {}

    def _register_export(self, module_name: str, export_name: str,
                         address: int) -> None:
        """Register an export."""
        if module_name not in self._exports:
            self._exports[module_name] = {}
        self._exports[module_name][export_name] = address


class Process:
    """Frida-like Process API."""

    def __init__(self, bridge: FridaBridge):
        self._bridge = bridge

    @property
    def id(self) -> int:
        """Get process ID."""
        return 1  # Emulated process

    @property
    def arch(self) -> str:
        """Get architecture."""
        if self._bridge._pointer_size == 8:
            return "arm64" if self._bridge._is_arm else "x64"
        else:
            return "arm" if self._bridge._is_arm else "ia32"

    @property
    def platform(self) -> str:
        """Get platform."""
        return "linux"  # Assumed for Android emulation

    @property
    def pageSize(self) -> int:
        """Get page size."""
        return 4096

    @property
    def pointerSize(self) -> int:
        """Get pointer size."""
        return self._bridge._pointer_size

    def getCurrentThreadId(self) -> int:
        """Get current thread ID."""
        return 1

    def enumerateModules(self) -> list[ModuleInfo]:
        """Enumerate loaded modules."""
        return list(self._bridge.module._modules.values())

    def findModuleByName(self, name: str) -> ModuleInfo | None:
        """Find module by name."""
        return self._bridge.module._modules.get(name)

    def findModuleByAddress(self, address: NativePointer | int) -> ModuleInfo | None:
        """Find module containing address."""
        if isinstance(address, NativePointer):
            address = address.address

        for mod in self._bridge.module._modules.values():
            if mod.base.address <= address < mod.base.address + mod.size:
                return mod
        return None

    def enumerateRanges(self, protection: str) -> list[dict[str, Any]]:
        """Enumerate all memory ranges from the emulator matching protection."""
        if not self._bridge._emulator:
            return []

        result = []
        for region in self._bridge._emulator.memory.get_regions():
            prot_str = ""
            prot_str += "r" if region.protection & 1 else "-"
            prot_str += "w" if region.protection & 2 else "-"
            prot_str += "x" if region.protection & 4 else "-"

            matches = True
            for c in protection:
                if c in 'rwx' and c not in prot_str:
                    matches = False
                    break

            if matches:
                result.append({
                    "base": NativePointer(region.start, self._bridge),
                    "size": region.size,
                    "protection": prot_str,
                })
        return result


@dataclass
class InterceptorHook:
    """Internal hook data."""
    address: int
    on_enter: Callable | None = None
    on_leave: Callable | None = None
    replacement: Callable | None = None
    enabled: bool = True


class Interceptor:
    """Frida-like Interceptor API."""

    def __init__(self, bridge: FridaBridge):
        self._bridge = bridge
        self._hooks: dict[int, InterceptorHook] = {}

    def attach(self, target: NativePointer | int,
               callbacks: dict[str, Callable]) -> InterceptorListener:
        """Attach to a function."""
        if isinstance(target, NativePointer):
            address = target.address
        else:
            address = target

        hook = InterceptorHook(
            address=address,
            on_enter=callbacks.get("onEnter"),
            on_leave=callbacks.get("onLeave"),
        )
        self._hooks[address] = hook

        # Register with emulator if available
        if self._bridge._emulator:
            self._bridge._register_hook(hook)

        return InterceptorListener(hook, self)

    def detachAll(self) -> None:
        """Detach all hooks."""
        for hook in list(self._hooks.values()):
            hook.enabled = False
        self._hooks.clear()

    def replace(self, target: NativePointer | int,
                replacement: Callable) -> None:
        """Replace a function."""
        if isinstance(target, NativePointer):
            address = target.address
        else:
            address = target

        hook = InterceptorHook(
            address=address,
            replacement=replacement,
        )
        self._hooks[address] = hook

        if self._bridge._emulator:
            self._bridge._register_replacement(hook)

    def revert(self, target: NativePointer | int) -> None:
        """Revert a replaced function."""
        if isinstance(target, NativePointer):
            address = target.address
        else:
            address = target

        if address in self._hooks:
            del self._hooks[address]

    def flush(self) -> None:
        """Flush pending hook changes."""
        pass  # Immediate in emulation

    def _invoke_hook(self, address: int, args: list[int],
                     is_enter: bool = True,
                     return_value: int = 0) -> tuple[list[int] | None, int | None]:
        """Internal: invoke hook callbacks."""
        if address not in self._hooks:
            return None, None

        hook = self._hooks[address]
        if not hook.enabled:
            return None, None

        # Create context
        ctx = InvocationContext(
            returnAddress=NativePointer(0, self._bridge),  # Would come from stack
            context={},  # Would have register state
            threadId=1,
            depth=0,
        )

        if is_enter:
            ctx.args = InvocationArgs(args.copy(), self._bridge)
            if hook.on_enter:
                hook.on_enter(ctx)
                return ctx.args._args, None
        else:
            ctx.returnValue = InvocationReturnValue(return_value, self._bridge)
            if hook.on_leave:
                hook.on_leave(ctx)
                if ctx.returnValue.was_replaced:
                    return None, ctx.returnValue.value

        return None, None


class InterceptorListener:
    """Handle for an attached interceptor."""

    def __init__(self, hook: InterceptorHook, interceptor: Interceptor):
        self._hook = hook
        self._interceptor = interceptor

    def detach(self) -> None:
        """Detach this hook."""
        self._hook.enabled = False
        if self._hook.address in self._interceptor._hooks:
            del self._interceptor._hooks[self._hook.address]


class ScriptParser:
    """Parser for Frida JavaScript scripts."""

    # Pattern to find Interceptor.attach calls
    ATTACH_PATTERN = re.compile(
        r'Interceptor\.attach\s*\(\s*'
        r'(?:Module\.findExportByName\s*\(\s*["\']?(\w+)?["\']?\s*,\s*["\'](\w+)["\']\s*\)|'
        r'ptr\s*\(\s*["\']?(0x[0-9a-fA-F]+)["\']?\s*\))\s*,\s*'
        r'\{\s*'
        r'(?:onEnter\s*:\s*function\s*\(\s*(\w+)\s*\)\s*\{([^}]*)\}\s*,?\s*)?'
        r'(?:onLeave\s*:\s*function\s*\(\s*(\w+)\s*\)\s*\{([^}]*)\}\s*)?'
        r'\s*\}',
        re.MULTILINE | re.DOTALL
    )

    # Pattern to find send() calls
    SEND_PATTERN = re.compile(
        r'send\s*\(\s*(\{[^}]+\}|["\'][^"\']+["\'])\s*(?:,\s*(\w+))?\s*\)'
    )

    # Pattern to find Memory read/write calls
    MEMORY_PATTERN = re.compile(
        r'Memory\.(read\w+|write\w+)\s*\(\s*([^)]+)\s*\)'
    )

    @classmethod
    def parse_hooks(cls, script: str) -> list[dict[str, Any]]:
        """Parse Interceptor.attach calls from a script."""
        hooks = []

        for match in cls.ATTACH_PATTERN.finditer(script):
            hook_info = {
                "type": "attach",
                "module": match.group(1),
                "export": match.group(2),
                "address": match.group(3),
                "onEnter": {
                    "arg_name": match.group(4),
                    "body": match.group(5),
                } if match.group(5) else None,
                "onLeave": {
                    "arg_name": match.group(6),
                    "body": match.group(7),
                } if match.group(7) else None,
            }
            hooks.append(hook_info)

        return hooks

    @classmethod
    def extract_sends(cls, script: str) -> list[dict[str, Any]]:
        """Extract send() calls from a script."""
        sends = []

        for match in cls.SEND_PATTERN.finditer(script):
            sends.append({
                "payload": match.group(1),
                "data_var": match.group(2),
            })

        return sends

    @classmethod
    def extract_memory_ops(cls, script: str) -> list[dict[str, Any]]:
        """Extract Memory operations from a script."""
        ops = []

        for match in cls.MEMORY_PATTERN.finditer(script):
            ops.append({
                "operation": match.group(1),
                "args": match.group(2),
            })

        return ops


class ScriptConverter:
    """Convert Frida scripts to Python hooks."""

    @classmethod
    def to_python(cls, script: str) -> str:
        """Convert Frida JS to Python hook code."""
        hooks = ScriptParser.parse_hooks(script)

        lines = [
            "# Auto-generated from Frida script",
            "from pyunidbg.frida import FridaBridge",
            "",
        ]

        for i, hook in enumerate(hooks):
            if hook.get("export"):
                target = f"bridge.module.findExportByName({repr(hook['module'])}, {repr(hook['export'])})"
            elif hook.get("address"):
                target = f"bridge.ptr({hook['address']})"
            else:
                continue

            lines.append(f"# Hook {i+1}")
            lines.append("bridge.interceptor.attach(")
            lines.append(f"    {target},")
            lines.append("    {")

            if hook.get("onEnter"):
                body = hook["onEnter"]["body"] or "pass"
                lines.append(f"        'onEnter': lambda args: None,  # {body.strip()}")

            if hook.get("onLeave"):
                body = hook["onLeave"]["body"] or "pass"
                lines.append(f"        'onLeave': lambda retval: None,  # {body.strip()}")

            lines.append("    }")
            lines.append(")")
            lines.append("")

        return "\n".join(lines)

    @classmethod
    def from_python(cls, hooks: list[dict[str, Any]]) -> str:
        """Convert Python hook definitions to Frida JS."""
        lines = [
            "// Auto-generated Frida script",
            "",
        ]

        for hook in hooks:
            address = hook.get("address")
            module = hook.get("module")
            export = hook.get("export")

            if module and export:
                target = f"Module.findExportByName('{module}', '{export}')"
            elif address:
                target = f"ptr('{hex(address)}')"
            else:
                continue

            lines.append("Interceptor.attach(")
            lines.append(f"    {target},")
            lines.append("    {")

            if hook.get("onEnter"):
                lines.append("        onEnter: function(args) {")
                lines.append(f"            // {hook['onEnter']}")
                lines.append("        },")

            if hook.get("onLeave"):
                lines.append("        onLeave: function(retval) {")
                lines.append(f"            // {hook['onLeave']}")
                lines.append("        }")

            lines.append("    }")
            lines.append(");")
            lines.append("")

        return "\n".join(lines)


@dataclass
class FridaScript:
    """A Frida script container."""
    source: str
    name: str = "script"
    state: ScriptState = ScriptState.CREATED
    exports: dict[str, Callable] = field(default_factory=dict)

    # Parsed data
    _hooks: list[dict[str, Any]] = field(default_factory=list)
    _messages: list[Message] = field(default_factory=list)


class ScriptRuntime:
    """Runtime for executing Frida-like scripts."""

    def __init__(self, bridge: FridaBridge):
        self._bridge = bridge
        self._scripts: dict[str, FridaScript] = {}
        self._message_handlers: list[Callable[[Message, bytes | None], None]] = []

    def create_script(self, source: str, name: str = "script") -> FridaScript:
        """Create a script."""
        script = FridaScript(source=source, name=name)
        script._hooks = ScriptParser.parse_hooks(source)
        self._scripts[name] = script
        return script

    def load(self, script: FridaScript) -> None:
        """Load a script."""
        script.state = ScriptState.LOADED

        # Set up hooks from parsed data
        for hook_info in script._hooks:
            self._setup_hook(hook_info)

    def _setup_hook(self, hook_info: dict[str, Any]) -> None:
        """Set up a hook from parsed info."""
        # Find target address
        target = None
        if hook_info.get("export"):
            target = self._bridge.module.findExportByName(
                hook_info.get("module"),
                hook_info["export"]
            )
        elif hook_info.get("address"):
            target = self._bridge.ptr(int(hook_info["address"], 16))

        if target is None:
            return

        # Create callbacks (simplified - would need JS interpretation)
        callbacks = {}
        if hook_info.get("onEnter"):
            def on_enter(args):
                # Would execute JS body
                pass
            callbacks["onEnter"] = on_enter

        if hook_info.get("onLeave"):
            def on_leave(retval):
                # Would execute JS body
                pass
            callbacks["onLeave"] = on_leave

        self._bridge.interceptor.attach(target, callbacks)

    def unload(self, script: FridaScript) -> None:
        """Unload a script."""
        script.state = ScriptState.STOPPED
        if script.name in self._scripts:
            del self._scripts[script.name]

    def on_message(self, handler: Callable[[Message, bytes | None], None]) -> None:
        """Register a message handler."""
        self._message_handlers.append(handler)

    def post(self, message: dict[str, Any], data: bytes | None = None) -> None:
        """Post a message to scripts."""
        msg = Message(
            type=message.get("type", "send"),
            payload=message.get("payload", message),
            data=data,
        )
        for handler in self._message_handlers:
            try:
                handler(msg, data)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)


class FridaBridge:
    """Main Frida bridge for PyUniDbg.
    
    Provides Frida-like APIs that work with PyUniDbg's emulator.
    
    Example:
        bridge = FridaBridge(emulator)
        
        # Use Frida-style memory access
        ptr = bridge.ptr(0x1000)
        value = ptr.readU32()
        
        # Use Interceptor for function hooks
        bridge.interceptor.attach(
            bridge.module.findExportByName("libc.so", "open"),
            {
                "onEnter": lambda args: print(f"open({args[0].readCString()})"),
                "onLeave": lambda retval: print(f"  = {retval.toInt32()}")
            }
        )
    """

    def __init__(self, emulator: Emulator | None = None,
                 pointer_size: int = 8, is_arm: bool = True):
        """Initialize the Frida bridge.
        
        Args:
            emulator: PyUniDbg emulator instance
            pointer_size: Pointer size in bytes (4 or 8)
            is_arm: Whether the target is ARM (vs x86)
        """
        self._emulator = emulator
        self._pointer_size = pointer_size
        self._is_arm = is_arm
        self._memory: dict[int, bytes] = {}  # Fallback memory
        self._next_alloc_addr = 0x70000000

        # Initialize sub-APIs
        self.memory = Memory(self)
        self.module = Module(self)
        self.process = Process(self)
        self.interceptor = Interceptor(self)

        # Script runtime
        self._runtime = ScriptRuntime(self)

        # Message bus
        self._message_bus = MessageBus()

    def ptr(self, address: int) -> NativePointer:
        """Create a NativePointer."""
        return NativePointer(address, self)

    def NULL(self) -> NativePointer:
        """Get null pointer."""
        return NativePointer(0, self)

    def int64(self, value: int) -> int:
        """Create a 64-bit integer."""
        return value & 0xFFFFFFFFFFFFFFFF

    def uint64(self, value: int) -> int:
        """Create an unsigned 64-bit integer."""
        return value & 0xFFFFFFFFFFFFFFFF

    def hexdump(self, target: NativePointer | int | bytes,
                options: dict[str, Any] | None = None) -> str:
        """Generate a hex dump."""
        options = options or {}
        offset = options.get("offset", 0)
        length = options.get("length", 256)
        header = options.get("header", True)
        ansi = options.get("ansi", False)

        if isinstance(target, bytes):
            data = target[offset:offset + length]
            base_addr = 0
        elif isinstance(target, NativePointer):
            base_addr = target.address + offset
            data = self.memory.readByteArray(base_addr, length)
        else:
            base_addr = target + offset
            data = self.memory.readByteArray(base_addr, length)

        lines = []
        if header:
            lines.append("           0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F  0123456789ABCDEF")

        for i in range(0, len(data), 16):
            addr = base_addr + i
            row = data[i:i+16]

            hex_part = " ".join(f"{b:02x}" for b in row)
            hex_part = hex_part.ljust(47)

            ascii_part = "".join(
                chr(b) if 32 <= b < 127 else "."
                for b in row
            )

            lines.append(f"{addr:08x}  {hex_part}  {ascii_part}")

        return "\n".join(lines)

    def send(self, payload: Any, data: bytes | None = None) -> None:
        """Send a message (like Frida's send())."""
        msg = Message(type="send", payload=payload, data=data)
        self._message_bus.send(msg)

    def recv(self, handler: Callable[[Any, bytes | None], None]) -> None:
        """Receive messages."""
        def wrapper(msg: Message) -> None:
            handler(msg.payload, msg.data)
        self._message_bus.on_message(wrapper)

    def create_script(self, source: str, name: str = "script") -> FridaScript:
        """Create a Frida script."""
        return self._runtime.create_script(source, name)

    def load_script(self, script: FridaScript) -> None:
        """Load and start a script."""
        self._runtime.load(script)

    def unload_script(self, script: FridaScript) -> None:
        """Unload a script."""
        self._runtime.unload(script)

    # Emulator integration
    def _register_hook(self, hook: InterceptorHook) -> None:
        """Register a hook with the emulator's hook system."""
        if not self._emulator:
            return

        emu = self._emulator
        bridge = self

        def code_hook(emulator, address, size, user_data):
            if not hook.enabled:
                return
            args_list = []
            try:
                for i in range(8 if emulator.is_64bit else 4):
                    args_list.append(emulator.cpu.get_arg(i))
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

            if hook.on_enter:
                ctx = InvocationContext(
                    returnAddress=NativePointer(emulator.cpu.lr, bridge),
                    context={},
                    threadId=1,
                    depth=0,
                    args=InvocationArgs(args_list, bridge),
                )
                hook.on_enter(ctx)

        try:
            emu.hook.add_code_hook(code_hook, begin=hook.address, end=hook.address + 4)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

    def _register_replacement(self, hook: InterceptorHook) -> None:
        """Register a function replacement with the emulator."""
        if not self._emulator or not hook.replacement:
            return

        emu = self._emulator
        replacement = hook.replacement

        def replace_hook(emulator, address, size, user_data):
            if not hook.enabled:
                return
            args_list = []
            try:
                for i in range(8 if emulator.is_64bit else 4):
                    args_list.append(emulator.cpu.get_arg(i))
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

            result = replacement(*args_list)
            if result is not None:
                emulator.cpu.set_return_value(result if isinstance(result, int) else 0)
            emulator.cpu.pc = emulator.cpu.lr

        try:
            emu.hook.add_code_hook(replace_hook, begin=hook.address, end=hook.address + 4)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

    def _call_native_function(self, address: int, return_type: str,
                              arg_types: list[str], args: list[Any]) -> Any:
        """Call a native function through the emulator."""
        if not self._emulator:
            return 0

        int_args = []
        for arg in args:
            if isinstance(arg, NativePointer):
                int_args.append(arg.address)
            elif isinstance(arg, int):
                int_args.append(arg)
            elif isinstance(arg, str):
                addr = self._emulator.alloc_string(arg)
                int_args.append(addr)
            else:
                int_args.append(0)

        try:
            result = self._emulator.call(address, int_args)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            result = 0

        if return_type in ('void',):
            return None
        elif return_type in ('pointer', 'char*', 'void*'):
            return NativePointer(result, self)
        return result

    # Script/snippet import
    def import_frida_script(self, script_source: str) -> list[dict[str, Any]]:
        """Import a Frida JavaScript script.
        
        Parses the script and extracts hooks that can be set up.
        
        Args:
            script_source: Frida JavaScript source code
            
        Returns:
            List of parsed hook definitions
        """
        return ScriptParser.parse_hooks(script_source)

    def export_to_frida(self, hooks: list[dict[str, Any]]) -> str:
        """Export hooks to Frida JavaScript format.
        
        Args:
            hooks: List of hook definitions
            
        Returns:
            Frida JavaScript code
        """
        return ScriptConverter.from_python(hooks)

    def convert_script_to_python(self, script_source: str) -> str:
        """Convert a Frida script to Python hook code.
        
        Args:
            script_source: Frida JavaScript source
            
        Returns:
            Python code using FridaBridge
        """
        return ScriptConverter.to_python(script_source)

    # NativeFunction creation
    def NativeFunction(self, address: NativePointer | int,
                       return_type: str, arg_types: list[str]) -> NativeFunction:
        """Create a NativeFunction wrapper."""
        return NativeFunction(address, return_type, arg_types, self)
