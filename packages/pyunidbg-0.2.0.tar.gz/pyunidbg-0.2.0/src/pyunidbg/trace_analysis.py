"""
Trace analysis module for PyUniDbg.

This module provides comprehensive execution trace analysis including:
- Instruction trace recording and playback
- Memory access pattern analysis
- Register value tracking
- Control flow analysis
- Performance profiling
- Coverage analysis
- Pattern detection
"""

import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from enum import IntEnum, auto
from typing import Any


class TraceEventType(IntEnum):
    """Types of trace events."""
    INSTRUCTION = auto()    # Instruction execution
    MEMORY_READ = auto()    # Memory read
    MEMORY_WRITE = auto()   # Memory write
    REGISTER_READ = auto()  # Register read
    REGISTER_WRITE = auto() # Register write
    SYSCALL = auto()        # System call
    CALL = auto()           # Function call
    RETURN = auto()         # Function return
    BRANCH = auto()         # Branch taken/not taken
    EXCEPTION = auto()      # Exception occurred
    CUSTOM = auto()         # Custom event


class TraceRecordingMode(IntEnum):
    """Trace recording modes."""
    DISABLED = auto()       # No recording
    FULL = auto()           # Record everything
    INSTRUCTIONS_ONLY = auto()  # Only instructions
    MEMORY_ONLY = auto()    # Only memory accesses
    CALLS_ONLY = auto()     # Only function calls
    FILTERED = auto()       # Use custom filter


@dataclass
class TraceEvent:
    """A single trace event."""
    sequence: int
    event_type: TraceEventType
    address: int = 0
    size: int = 0
    data: bytes = b''
    value: int = 0
    mnemonic: str = ""
    operands: str = ""
    register_name: str = ""
    target_address: int = 0
    timestamp: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.timestamp == 0.0:
            self.timestamp = time.time()

    @property
    def is_instruction(self) -> bool:
        """Check if this is an instruction event."""
        return self.event_type == TraceEventType.INSTRUCTION

    @property
    def is_memory_access(self) -> bool:
        """Check if this is a memory access event."""
        return self.event_type in (TraceEventType.MEMORY_READ, TraceEventType.MEMORY_WRITE)

    @property
    def is_memory_read(self) -> bool:
        """Check if this is a memory read event."""
        return self.event_type == TraceEventType.MEMORY_READ

    @property
    def is_memory_write(self) -> bool:
        """Check if this is a memory write event."""
        return self.event_type == TraceEventType.MEMORY_WRITE

    @property
    def is_control_flow(self) -> bool:
        """Check if this is a control flow event."""
        return self.event_type in (TraceEventType.CALL, TraceEventType.RETURN, TraceEventType.BRANCH)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'sequence': self.sequence,
            'event_type': self.event_type.value,
            'address': self.address,
            'size': self.size,
            'data': self.data.hex(),
            'value': self.value,
            'mnemonic': self.mnemonic,
            'operands': self.operands,
            'register_name': self.register_name,
            'target_address': self.target_address,
            'timestamp': self.timestamp,
            'metadata': self.metadata.copy(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'TraceEvent':
        """Create from dictionary."""
        return cls(
            sequence=data['sequence'],
            event_type=TraceEventType(data['event_type']),
            address=data.get('address', 0),
            size=data.get('size', 0),
            data=bytes.fromhex(data.get('data', '')),
            value=data.get('value', 0),
            mnemonic=data.get('mnemonic', ''),
            operands=data.get('operands', ''),
            register_name=data.get('register_name', ''),
            target_address=data.get('target_address', 0),
            timestamp=data.get('timestamp', 0.0),
            metadata=data.get('metadata', {}),
        )

    def __str__(self) -> str:
        if self.event_type == TraceEventType.INSTRUCTION:
            return f"[{self.sequence}] {hex(self.address)}: {self.mnemonic} {self.operands}"
        elif self.event_type == TraceEventType.MEMORY_READ:
            return f"[{self.sequence}] READ {hex(self.address)} ({self.size} bytes)"
        elif self.event_type == TraceEventType.MEMORY_WRITE:
            return f"[{self.sequence}] WRITE {hex(self.address)} ({self.size} bytes)"
        elif self.event_type == TraceEventType.CALL:
            return f"[{self.sequence}] CALL {hex(self.target_address)} from {hex(self.address)}"
        elif self.event_type == TraceEventType.RETURN:
            return f"[{self.sequence}] RET to {hex(self.target_address)}"
        else:
            return f"[{self.sequence}] {self.event_type.name} at {hex(self.address)}"


@dataclass
class BasicBlock:
    """A basic block of instructions."""
    start_address: int
    end_address: int
    instructions: list[TraceEvent] = field(default_factory=list)
    successors: set[int] = field(default_factory=set)
    predecessors: set[int] = field(default_factory=set)
    hit_count: int = 0

    @property
    def size(self) -> int:
        """Get block size in bytes."""
        return self.end_address - self.start_address

    @property
    def instruction_count(self) -> int:
        """Get number of instructions."""
        return len(self.instructions)

    def add_instruction(self, event: TraceEvent) -> None:
        """Add an instruction to the block."""
        self.instructions.append(event)
        if event.address < self.start_address:
            self.start_address = event.address
        if event.address + event.size > self.end_address:
            self.end_address = event.address + event.size

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'start_address': self.start_address,
            'end_address': self.end_address,
            'instructions': [i.to_dict() for i in self.instructions],
            'successors': list(self.successors),
            'predecessors': list(self.predecessors),
            'hit_count': self.hit_count,
        }


@dataclass
class FunctionCall:
    """A function call record."""
    call_address: int
    target_address: int
    return_address: int
    arguments: list[int] = field(default_factory=list)
    return_value: int | None = None
    start_sequence: int = 0
    end_sequence: int = 0
    child_calls: list['FunctionCall'] = field(default_factory=list)

    @property
    def duration(self) -> int:
        """Get call duration in instruction count."""
        return self.end_sequence - self.start_sequence

    @property
    def depth(self) -> int:
        """Get maximum call depth."""
        if not self.child_calls:
            return 0
        return 1 + max(c.depth for c in self.child_calls)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'call_address': self.call_address,
            'target_address': self.target_address,
            'return_address': self.return_address,
            'arguments': self.arguments,
            'return_value': self.return_value,
            'start_sequence': self.start_sequence,
            'end_sequence': self.end_sequence,
            'child_calls': [c.to_dict() for c in self.child_calls],
        }


@dataclass
class MemoryAccessPattern:
    """Memory access pattern analysis."""
    address: int
    size: int
    read_count: int = 0
    write_count: int = 0
    last_value: bytes = b''
    values_seen: list[bytes] = field(default_factory=list)
    access_sequences: list[int] = field(default_factory=list)

    @property
    def total_accesses(self) -> int:
        """Get total number of accesses."""
        return self.read_count + self.write_count

    @property
    def is_read_only(self) -> bool:
        """Check if this address was only read."""
        return self.read_count > 0 and self.write_count == 0

    @property
    def is_write_only(self) -> bool:
        """Check if this address was only written."""
        return self.write_count > 0 and self.read_count == 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'size': self.size,
            'read_count': self.read_count,
            'write_count': self.write_count,
            'last_value': self.last_value.hex(),
            'total_accesses': self.total_accesses,
        }


@dataclass
class RegisterHistory:
    """Register value history."""
    name: str
    changes: list[tuple[int, int, int]] = field(default_factory=list)  # (sequence, old_value, new_value)

    @property
    def change_count(self) -> int:
        """Get number of times register changed."""
        return len(self.changes)

    @property
    def current_value(self) -> int | None:
        """Get current (last known) value."""
        if self.changes:
            return self.changes[-1][2]
        return None

    def add_change(self, sequence: int, old_value: int, new_value: int) -> None:
        """Record a register value change."""
        self.changes.append((sequence, old_value, new_value))

    def value_at_sequence(self, sequence: int) -> int | None:
        """Get register value at a specific sequence number."""
        for seq, old_val, new_val in reversed(self.changes):
            if seq <= sequence:
                return new_val
        return None


@dataclass
class CoverageInfo:
    """Code coverage information."""
    executed_addresses: set[int] = field(default_factory=set)
    executed_blocks: set[int] = field(default_factory=set)
    executed_functions: set[int] = field(default_factory=set)
    hit_counts: dict[int, int] = field(default_factory=dict)

    @property
    def instruction_count(self) -> int:
        """Get number of unique instructions executed."""
        return len(self.executed_addresses)

    @property
    def block_count(self) -> int:
        """Get number of unique blocks executed."""
        return len(self.executed_blocks)

    @property
    def function_count(self) -> int:
        """Get number of unique functions executed."""
        return len(self.executed_functions)

    def record_execution(self, address: int) -> None:
        """Record instruction execution."""
        self.executed_addresses.add(address)
        self.hit_counts[address] = self.hit_counts.get(address, 0) + 1

    def get_hit_count(self, address: int) -> int:
        """Get hit count for an address."""
        return self.hit_counts.get(address, 0)

    def merge(self, other: 'CoverageInfo') -> None:
        """Merge coverage from another CoverageInfo."""
        self.executed_addresses.update(other.executed_addresses)
        self.executed_blocks.update(other.executed_blocks)
        self.executed_functions.update(other.executed_functions)
        for addr, count in other.hit_counts.items():
            self.hit_counts[addr] = self.hit_counts.get(addr, 0) + count

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'instruction_count': self.instruction_count,
            'block_count': self.block_count,
            'function_count': self.function_count,
            'executed_addresses': list(self.executed_addresses),
            'hit_counts': self.hit_counts.copy(),
        }


class TraceRecorder:
    """Records execution traces."""

    def __init__(self, max_events: int = 1000000):
        self.max_events = max_events
        self.mode = TraceRecordingMode.FULL
        self._events: list[TraceEvent] = []
        self._sequence = 0
        self._filters: list[Callable[[TraceEvent], bool]] = []
        self._callbacks: list[Callable[[TraceEvent], None]] = []
        self._enabled = False
        self._start_time = 0.0

    @property
    def event_count(self) -> int:
        """Get number of recorded events."""
        return len(self._events)

    @property
    def is_enabled(self) -> bool:
        """Check if recording is enabled."""
        return self._enabled

    def enable(self) -> None:
        """Enable trace recording."""
        self._enabled = True
        self._start_time = time.time()

    def disable(self) -> None:
        """Disable trace recording."""
        self._enabled = False

    def set_mode(self, mode: TraceRecordingMode) -> None:
        """Set recording mode."""
        self.mode = mode

    def add_filter(self, filter_func: Callable[[TraceEvent], bool]) -> None:
        """Add a filter function. Event is recorded if filter returns True."""
        self._filters.append(filter_func)

    def clear_filters(self) -> None:
        """Clear all filters."""
        self._filters.clear()

    def add_callback(self, callback: Callable[[TraceEvent], None]) -> None:
        """Add a callback for recorded events."""
        self._callbacks.append(callback)

    def _should_record(self, event: TraceEvent) -> bool:
        """Check if event should be recorded based on mode and filters."""
        if self.mode == TraceRecordingMode.DISABLED:
            return False

        if self.mode == TraceRecordingMode.INSTRUCTIONS_ONLY:
            if event.event_type != TraceEventType.INSTRUCTION:
                return False
        elif self.mode == TraceRecordingMode.MEMORY_ONLY:
            if not event.is_memory_access:
                return False
        elif self.mode == TraceRecordingMode.CALLS_ONLY:
            if event.event_type not in (TraceEventType.CALL, TraceEventType.RETURN):
                return False
        elif self.mode == TraceRecordingMode.FILTERED:
            if not all(f(event) for f in self._filters):
                return False

        return True

    def record(self, event_type: TraceEventType, **kwargs) -> TraceEvent | None:
        """Record a trace event."""
        if not self._enabled:
            return None

        if len(self._events) >= self.max_events:
            # Drop oldest events
            self._events = self._events[len(self._events) // 2:]

        self._sequence += 1
        event = TraceEvent(sequence=self._sequence, event_type=event_type, **kwargs)

        if self._should_record(event):
            self._events.append(event)
            for callback in self._callbacks:
                callback(event)
            return event

        return None

    def record_instruction(self, address: int, size: int, mnemonic: str, operands: str = "",
                          data: bytes = b'') -> TraceEvent | None:
        """Record an instruction execution."""
        return self.record(
            TraceEventType.INSTRUCTION,
            address=address,
            size=size,
            mnemonic=mnemonic,
            operands=operands,
            data=data,
        )

    def record_memory_read(self, address: int, size: int, value: int = 0,
                          data: bytes = b'') -> TraceEvent | None:
        """Record a memory read."""
        return self.record(
            TraceEventType.MEMORY_READ,
            address=address,
            size=size,
            value=value,
            data=data,
        )

    def record_memory_write(self, address: int, size: int, value: int = 0,
                           data: bytes = b'') -> TraceEvent | None:
        """Record a memory write."""
        return self.record(
            TraceEventType.MEMORY_WRITE,
            address=address,
            size=size,
            value=value,
            data=data,
        )

    def record_call(self, call_address: int, target_address: int) -> TraceEvent | None:
        """Record a function call."""
        return self.record(
            TraceEventType.CALL,
            address=call_address,
            target_address=target_address,
        )

    def record_return(self, return_address: int, target_address: int) -> TraceEvent | None:
        """Record a function return."""
        return self.record(
            TraceEventType.RETURN,
            address=return_address,
            target_address=target_address,
        )

    def record_register_write(self, register_name: str, value: int, address: int = 0) -> TraceEvent | None:
        """Record a register write."""
        return self.record(
            TraceEventType.REGISTER_WRITE,
            register_name=register_name,
            value=value,
            address=address,
        )

    def get_events(self, start: int = 0, count: int | None = None) -> list[TraceEvent]:
        """Get recorded events."""
        if count is None:
            return self._events[start:]
        return self._events[start:start + count]

    def get_events_by_type(self, event_type: TraceEventType) -> list[TraceEvent]:
        """Get events of a specific type."""
        return [e for e in self._events if e.event_type == event_type]

    def get_events_in_range(self, start_addr: int, end_addr: int) -> list[TraceEvent]:
        """Get events within an address range."""
        return [e for e in self._events if start_addr <= e.address < end_addr]

    def clear(self) -> None:
        """Clear all recorded events."""
        self._events.clear()
        self._sequence = 0

    def __iter__(self) -> Iterator[TraceEvent]:
        """Iterate over events."""
        return iter(self._events)

    def __len__(self) -> int:
        """Get event count."""
        return len(self._events)


class TraceAnalyzer:
    """Analyzes execution traces."""

    def __init__(self, recorder: TraceRecorder):
        self.recorder = recorder
        self._basic_blocks: dict[int, BasicBlock] = {}
        self._call_stack: list[FunctionCall] = []
        self._function_calls: list[FunctionCall] = []
        self._memory_patterns: dict[int, MemoryAccessPattern] = {}
        self._register_history: dict[str, RegisterHistory] = {}
        self._coverage = CoverageInfo()

    def analyze(self) -> None:
        """Perform full analysis on recorded trace."""
        self._build_basic_blocks()
        self._analyze_calls()
        self._analyze_memory_patterns()
        self._build_coverage()

    def _build_basic_blocks(self) -> None:
        """Build basic blocks from instruction trace."""
        current_block: BasicBlock | None = None
        last_addr = 0

        for event in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION):
            # Check if we need to start a new block
            if current_block is None:
                current_block = BasicBlock(
                    start_address=event.address,
                    end_address=event.address + event.size,
                )
            elif event.address != last_addr + 4:  # Non-sequential (assuming 4-byte instructions)
                # Save current block
                self._basic_blocks[current_block.start_address] = current_block
                current_block.hit_count += 1

                # Start new block
                current_block = BasicBlock(
                    start_address=event.address,
                    end_address=event.address + event.size,
                )

            current_block.add_instruction(event)
            last_addr = event.address

        if current_block:
            self._basic_blocks[current_block.start_address] = current_block

    def _analyze_calls(self) -> None:
        """Analyze function calls and returns."""
        for event in self.recorder:
            if event.event_type == TraceEventType.CALL:
                call = FunctionCall(
                    call_address=event.address,
                    target_address=event.target_address,
                    return_address=event.address + 4,  # Assume 4-byte instructions
                    start_sequence=event.sequence,
                )
                if self._call_stack:
                    self._call_stack[-1].child_calls.append(call)
                self._call_stack.append(call)
                self._function_calls.append(call)
                self._coverage.executed_functions.add(event.target_address)
            elif event.event_type == TraceEventType.RETURN:
                if self._call_stack:
                    call = self._call_stack.pop()
                    call.end_sequence = event.sequence

    def _analyze_memory_patterns(self) -> None:
        """Analyze memory access patterns."""
        for event in self.recorder:
            if event.is_memory_access:
                addr = event.address
                if addr not in self._memory_patterns:
                    self._memory_patterns[addr] = MemoryAccessPattern(
                        address=addr,
                        size=event.size,
                    )

                pattern = self._memory_patterns[addr]
                pattern.access_sequences.append(event.sequence)

                if event.is_memory_read:
                    pattern.read_count += 1
                else:
                    pattern.write_count += 1
                    if event.data:
                        pattern.last_value = event.data
                        pattern.values_seen.append(event.data)

    def _build_coverage(self) -> None:
        """Build coverage information."""
        for event in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION):
            self._coverage.record_execution(event.address)

        for addr in self._basic_blocks:
            self._coverage.executed_blocks.add(addr)

    def get_basic_blocks(self) -> list[BasicBlock]:
        """Get all basic blocks."""
        return list(self._basic_blocks.values())

    def get_function_calls(self) -> list[FunctionCall]:
        """Get all function calls."""
        return self._function_calls

    def get_memory_patterns(self) -> list[MemoryAccessPattern]:
        """Get memory access patterns."""
        return list(self._memory_patterns.values())

    def get_hotspots(self, limit: int = 10) -> list[tuple[int, int]]:
        """Get most frequently executed addresses."""
        sorted_hits = sorted(
            self._coverage.hit_counts.items(),
            key=lambda x: x[1],
            reverse=True,
        )
        return sorted_hits[:limit]

    def get_coverage(self) -> CoverageInfo:
        """Get coverage information."""
        return self._coverage

    def get_register_history(self, register: str) -> RegisterHistory | None:
        """Get history for a specific register."""
        return self._register_history.get(register)

    def find_pattern(self, mnemonic: str, operands_pattern: str = "") -> list[TraceEvent]:
        """Find instructions matching a pattern."""
        results = []
        for event in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION):
            if event.mnemonic == mnemonic:
                if not operands_pattern or operands_pattern in event.operands:
                    results.append(event)
        return results

    def find_memory_access(self, address: int) -> list[TraceEvent]:
        """Find all memory accesses to a specific address."""
        return [e for e in self.recorder if e.is_memory_access and e.address == address]

    def get_execution_path(self, start_seq: int = 0, end_seq: int | None = None) -> list[int]:
        """Get the execution path (list of addresses)."""
        path = []
        for event in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION):
            if event.sequence >= start_seq:
                if end_seq is not None and event.sequence > end_seq:
                    break
                path.append(event.address)
        return path

    def get_call_tree(self) -> list[FunctionCall]:
        """Get the root-level call tree."""
        return [c for c in self._function_calls if not any(c in p.child_calls for p in self._function_calls)]


class TraceComparator:
    """Compare two traces for differences."""

    def __init__(self, trace1: TraceRecorder, trace2: TraceRecorder):
        self.trace1 = trace1
        self.trace2 = trace2

    def compare_paths(self) -> dict[str, Any]:
        """Compare execution paths."""
        path1 = [e.address for e in self.trace1.get_events_by_type(TraceEventType.INSTRUCTION)]
        path2 = [e.address for e in self.trace2.get_events_by_type(TraceEventType.INSTRUCTION)]

        # Find divergence point
        divergence_index = 0
        for i, (a1, a2) in enumerate(zip(path1, path2)):
            if a1 != a2:
                divergence_index = i
                break
        else:
            divergence_index = min(len(path1), len(path2))

        # Find unique addresses
        unique_to_1 = set(path1) - set(path2)
        unique_to_2 = set(path2) - set(path1)

        return {
            'path1_length': len(path1),
            'path2_length': len(path2),
            'divergence_index': divergence_index,
            'common_prefix_length': divergence_index,
            'unique_to_trace1': len(unique_to_1),
            'unique_to_trace2': len(unique_to_2),
            'same_path': path1 == path2,
        }

    def compare_memory_accesses(self) -> dict[str, Any]:
        """Compare memory access patterns."""
        mem1 = {(e.address, e.event_type) for e in self.trace1 if e.is_memory_access}
        mem2 = {(e.address, e.event_type) for e in self.trace2 if e.is_memory_access}

        return {
            'trace1_accesses': len(mem1),
            'trace2_accesses': len(mem2),
            'common_accesses': len(mem1 & mem2),
            'unique_to_trace1': len(mem1 - mem2),
            'unique_to_trace2': len(mem2 - mem1),
        }

    def compare_coverage(self) -> dict[str, Any]:
        """Compare code coverage."""
        analyzer1 = TraceAnalyzer(self.trace1)
        analyzer2 = TraceAnalyzer(self.trace2)

        analyzer1.analyze()
        analyzer2.analyze()

        cov1 = analyzer1.get_coverage()
        cov2 = analyzer2.get_coverage()

        common = cov1.executed_addresses & cov2.executed_addresses

        return {
            'trace1_coverage': cov1.instruction_count,
            'trace2_coverage': cov2.instruction_count,
            'common_coverage': len(common),
            'unique_to_trace1': len(cov1.executed_addresses - cov2.executed_addresses),
            'unique_to_trace2': len(cov2.executed_addresses - cov1.executed_addresses),
        }


class TraceExporter:
    """Export traces to various formats."""

    def __init__(self, recorder: TraceRecorder):
        self.recorder = recorder

    def to_json(self) -> list[dict[str, Any]]:
        """Export trace as JSON-compatible list."""
        return [e.to_dict() for e in self.recorder]

    def to_instruction_list(self) -> list[str]:
        """Export as list of instruction strings."""
        return [str(e) for e in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION)]

    def to_address_list(self) -> list[int]:
        """Export as list of addresses."""
        return [e.address for e in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION)]

    def to_ida_script(self) -> str:
        """Generate IDA Python script to color executed addresses."""
        lines = ['# IDA Pro script to color trace coverage', 'from idaapi import *', '']
        lines.append('def color_trace():')

        for event in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION):
            lines.append(f'    set_color({hex(event.address)}, CIC_ITEM, 0x00FF00)')

        lines.append('')
        lines.append('color_trace()')
        return '\n'.join(lines)

    def to_coverage_file(self) -> str:
        """Generate coverage file format."""
        lines = ['# Coverage data', f'# Total instructions: {len(self.recorder)}', '']

        addresses = sorted(set(e.address for e in self.recorder.get_events_by_type(TraceEventType.INSTRUCTION)))
        for addr in addresses:
            lines.append(hex(addr))

        return '\n'.join(lines)


class TracePlayer:
    """Replay traces step by step."""

    def __init__(self, recorder: TraceRecorder):
        self.recorder = recorder
        self._position = 0
        self._breakpoints: set[int] = set()
        self._callbacks: list[Callable[[TraceEvent], None]] = []

    @property
    def position(self) -> int:
        """Get current position in trace."""
        return self._position

    @property
    def at_end(self) -> bool:
        """Check if at end of trace."""
        return self._position >= len(self.recorder)

    @property
    def at_start(self) -> bool:
        """Check if at start of trace."""
        return self._position == 0

    def reset(self) -> None:
        """Reset to start of trace."""
        self._position = 0

    def goto(self, position: int) -> bool:
        """Go to specific position."""
        if 0 <= position < len(self.recorder):
            self._position = position
            return True
        return False

    def current(self) -> TraceEvent | None:
        """Get current event."""
        events = self.recorder.get_events()
        if 0 <= self._position < len(events):
            return events[self._position]
        return None

    def step_forward(self) -> TraceEvent | None:
        """Step forward one event. Returns the event at the new position."""
        events = self.recorder.get_events()
        if self._position < len(events):
            event = events[self._position]
            self._position += 1
            for callback in self._callbacks:
                callback(event)
            return event
        return None

    def step_backward(self) -> TraceEvent | None:
        """Step backward one event."""
        if self._position > 0:
            self._position -= 1
            return self.current()
        return None

    def add_breakpoint(self, address: int) -> None:
        """Add a breakpoint address."""
        self._breakpoints.add(address)

    def remove_breakpoint(self, address: int) -> bool:
        """Remove a breakpoint address."""
        if address in self._breakpoints:
            self._breakpoints.remove(address)
            return True
        return False

    def continue_to_breakpoint(self) -> TraceEvent | None:
        """Continue until a breakpoint is hit."""
        while self._position < len(self.recorder):
            event = self.step_forward()
            if event and event.address in self._breakpoints:
                return event
        return None

    def continue_to_address(self, address: int) -> TraceEvent | None:
        """Continue until a specific address is hit."""
        while self._position < len(self.recorder):
            event = self.step_forward()
            if event and event.address == address:
                return event
        return None

    def add_callback(self, callback: Callable[[TraceEvent], None]) -> None:
        """Add step callback."""
        self._callbacks.append(callback)


def create_trace_recorder(max_events: int = 1000000,
                         mode: TraceRecordingMode = TraceRecordingMode.FULL) -> TraceRecorder:
    """Create a configured trace recorder."""
    recorder = TraceRecorder(max_events=max_events)
    recorder.set_mode(mode)
    return recorder


def analyze_trace(recorder: TraceRecorder) -> dict[str, Any]:
    """Perform quick trace analysis and return summary."""
    analyzer = TraceAnalyzer(recorder)
    analyzer.analyze()

    coverage = analyzer.get_coverage()
    hotspots = analyzer.get_hotspots(5)

    return {
        'total_events': len(recorder),
        'instruction_count': len(recorder.get_events_by_type(TraceEventType.INSTRUCTION)),
        'memory_read_count': len(recorder.get_events_by_type(TraceEventType.MEMORY_READ)),
        'memory_write_count': len(recorder.get_events_by_type(TraceEventType.MEMORY_WRITE)),
        'call_count': len(recorder.get_events_by_type(TraceEventType.CALL)),
        'unique_addresses': coverage.instruction_count,
        'basic_block_count': coverage.block_count,
        'function_count': coverage.function_count,
        'hotspots': hotspots,
    }
