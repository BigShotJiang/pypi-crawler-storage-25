"""
Snapshot system for PyUniDbg.

This module provides comprehensive snapshot functionality including:
- Memory state snapshots
- Register state snapshots
- Full emulator state capture and restore
- Differential snapshots
- Snapshot comparison and diffing
- Persistent snapshot storage
"""

import gzip
import hashlib
import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum, auto
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class SnapshotType(IntEnum):
    """Types of snapshots."""
    FULL = auto()           # Complete state snapshot
    MEMORY_ONLY = auto()    # Memory regions only
    REGISTERS_ONLY = auto() # Registers only
    DIFFERENTIAL = auto()   # Changes from a baseline


class SnapshotCompression(IntEnum):
    """Compression types for snapshots."""
    NONE = auto()
    GZIP = auto()
    LZ4 = auto()  # Placeholder for future implementation


@dataclass
class MemoryRegion:
    """Represents a memory region in a snapshot."""
    address: int
    size: int
    permissions: int
    data: bytes
    name: str = ""
    checksum: str = ""

    def __post_init__(self):
        if not self.checksum:
            self.checksum = hashlib.md5(self.data).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'address': self.address,
            'size': self.size,
            'permissions': self.permissions,
            'data': self.data.hex(),
            'name': self.name,
            'checksum': self.checksum,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'MemoryRegion':
        """Create from dictionary."""
        return cls(
            address=data['address'],
            size=data['size'],
            permissions=data['permissions'],
            data=bytes.fromhex(data['data']),
            name=data.get('name', ''),
            checksum=data.get('checksum', ''),
        )


@dataclass
class RegisterState:
    """Represents register state in a snapshot."""
    architecture: str
    mode: str
    values: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'architecture': self.architecture,
            'mode': self.mode,
            'values': self.values.copy(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'RegisterState':
        """Create from dictionary."""
        return cls(
            architecture=data['architecture'],
            mode=data['mode'],
            values=data['values'].copy(),
        )


@dataclass
class MemoryDiff:
    """Represents a difference in memory between snapshots."""
    address: int
    old_value: bytes
    new_value: bytes
    size: int = 0

    def __post_init__(self):
        if self.size == 0:
            self.size = len(self.new_value)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'old_value': self.old_value.hex(),
            'new_value': self.new_value.hex(),
            'size': self.size,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'MemoryDiff':
        """Create from dictionary."""
        return cls(
            address=data['address'],
            old_value=bytes.fromhex(data['old_value']),
            new_value=bytes.fromhex(data['new_value']),
            size=data.get('size', 0),
        )


@dataclass
class RegisterDiff:
    """Represents a difference in registers between snapshots."""
    name: str
    old_value: int
    new_value: int

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'old_value': self.old_value,
            'new_value': self.new_value,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'RegisterDiff':
        """Create from dictionary."""
        return cls(
            name=data['name'],
            old_value=data['old_value'],
            new_value=data['new_value'],
        )


@dataclass
class SnapshotMetadata:
    """Metadata for a snapshot."""
    id: str
    name: str
    description: str = ""
    timestamp: float = 0.0
    snapshot_type: SnapshotType = SnapshotType.FULL
    parent_id: str | None = None
    tags: list[str] = field(default_factory=list)
    custom_data: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.timestamp == 0.0:
            self.timestamp = time.time()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'timestamp': self.timestamp,
            'snapshot_type': self.snapshot_type.value,
            'parent_id': self.parent_id,
            'tags': self.tags.copy(),
            'custom_data': self.custom_data.copy(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'SnapshotMetadata':
        """Create from dictionary."""
        return cls(
            id=data['id'],
            name=data['name'],
            description=data.get('description', ''),
            timestamp=data.get('timestamp', 0.0),
            snapshot_type=SnapshotType(data.get('snapshot_type', SnapshotType.FULL.value)),
            parent_id=data.get('parent_id'),
            tags=data.get('tags', []),
            custom_data=data.get('custom_data', {}),
        )


@dataclass
class Snapshot:
    """Complete snapshot of emulator state."""
    metadata: SnapshotMetadata
    memory_regions: list[MemoryRegion] = field(default_factory=list)
    registers: RegisterState | None = None
    memory_diffs: list[MemoryDiff] = field(default_factory=list)
    register_diffs: list[RegisterDiff] = field(default_factory=list)
    hooks_state: dict[str, Any] = field(default_factory=dict)

    @property
    def id(self) -> str:
        """Get snapshot ID."""
        return self.metadata.id

    @property
    def name(self) -> str:
        """Get snapshot name."""
        return self.metadata.name

    @property
    def is_differential(self) -> bool:
        """Check if this is a differential snapshot."""
        return self.metadata.snapshot_type == SnapshotType.DIFFERENTIAL

    def total_memory_size(self) -> int:
        """Calculate total memory size in snapshot."""
        return sum(region.size for region in self.memory_regions)

    def region_count(self) -> int:
        """Get number of memory regions."""
        return len(self.memory_regions)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'metadata': self.metadata.to_dict(),
            'memory_regions': [r.to_dict() for r in self.memory_regions],
            'registers': self.registers.to_dict() if self.registers else None,
            'memory_diffs': [d.to_dict() for d in self.memory_diffs],
            'register_diffs': [d.to_dict() for d in self.register_diffs],
            'hooks_state': self.hooks_state.copy(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'Snapshot':
        """Create from dictionary."""
        return cls(
            metadata=SnapshotMetadata.from_dict(data['metadata']),
            memory_regions=[MemoryRegion.from_dict(r) for r in data.get('memory_regions', [])],
            registers=RegisterState.from_dict(data['registers']) if data.get('registers') else None,
            memory_diffs=[MemoryDiff.from_dict(d) for d in data.get('memory_diffs', [])],
            register_diffs=[RegisterDiff.from_dict(d) for d in data.get('register_diffs', [])],
            hooks_state=data.get('hooks_state', {}),
        )


class SnapshotComparison:
    """Compare two snapshots and generate diffs."""

    def __init__(self, snapshot1: Snapshot, snapshot2: Snapshot):
        self.snapshot1 = snapshot1
        self.snapshot2 = snapshot2
        self._memory_diffs: list[MemoryDiff] | None = None
        self._register_diffs: list[RegisterDiff] | None = None

    def compare_memory(self) -> list[MemoryDiff]:
        """Compare memory regions between snapshots."""
        if self._memory_diffs is not None:
            return self._memory_diffs

        diffs = []

        # Build maps of regions by address
        regions1 = {r.address: r for r in self.snapshot1.memory_regions}
        regions2 = {r.address: r for r in self.snapshot2.memory_regions}

        # Compare common regions
        for addr in set(regions1.keys()) & set(regions2.keys()):
            r1 = regions1[addr]
            r2 = regions2[addr]

            if r1.checksum != r2.checksum:
                # Find byte-level differences
                data1 = r1.data
                data2 = r2.data
                min_len = min(len(data1), len(data2))

                i = 0
                while i < min_len:
                    if data1[i] != data2[i]:
                        # Find extent of difference
                        start = i
                        while i < min_len and data1[i] != data2[i]:
                            i += 1
                        diffs.append(MemoryDiff(
                            address=addr + start,
                            old_value=data1[start:i],
                            new_value=data2[start:i],
                        ))
                    else:
                        i += 1

        # Handle regions only in one snapshot
        for addr in set(regions1.keys()) - set(regions2.keys()):
            r1 = regions1[addr]
            diffs.append(MemoryDiff(
                address=addr,
                old_value=r1.data,
                new_value=b'',
            ))

        for addr in set(regions2.keys()) - set(regions1.keys()):
            r2 = regions2[addr]
            diffs.append(MemoryDiff(
                address=addr,
                old_value=b'',
                new_value=r2.data,
            ))

        self._memory_diffs = diffs
        return diffs

    def compare_registers(self) -> list[RegisterDiff]:
        """Compare register states between snapshots."""
        if self._register_diffs is not None:
            return self._register_diffs

        diffs = []

        if self.snapshot1.registers and self.snapshot2.registers:
            regs1 = self.snapshot1.registers.values
            regs2 = self.snapshot2.registers.values

            all_regs = set(regs1.keys()) | set(regs2.keys())

            for reg in all_regs:
                val1 = regs1.get(reg, 0)
                val2 = regs2.get(reg, 0)

                if val1 != val2:
                    diffs.append(RegisterDiff(
                        name=reg,
                        old_value=val1,
                        new_value=val2,
                    ))

        self._register_diffs = diffs
        return diffs

    def has_changes(self) -> bool:
        """Check if there are any changes between snapshots."""
        return len(self.compare_memory()) > 0 or len(self.compare_registers()) > 0

    def summary(self) -> dict[str, Any]:
        """Get comparison summary."""
        mem_diffs = self.compare_memory()
        reg_diffs = self.compare_registers()

        total_bytes_changed = sum(len(d.new_value) for d in mem_diffs)

        return {
            'memory_diff_count': len(mem_diffs),
            'register_diff_count': len(reg_diffs),
            'total_bytes_changed': total_bytes_changed,
            'has_changes': self.has_changes(),
        }


class SnapshotManager:
    """Manages snapshots for an emulator."""

    def __init__(self, storage_path: str | None = None):
        self.storage_path = storage_path
        self._snapshots: dict[str, Snapshot] = {}
        self._snapshot_counter = 0
        self._callbacks: dict[str, list[Callable]] = {
            'pre_capture': [],
            'post_capture': [],
            'pre_restore': [],
            'post_restore': [],
        }

    def generate_id(self) -> str:
        """Generate a unique snapshot ID."""
        self._snapshot_counter += 1
        return f"snap_{self._snapshot_counter}_{int(time.time() * 1000)}"

    def create_snapshot(self,
                       name: str,
                       memory_reader: Callable[[int, int], bytes],
                       memory_map: dict[int, tuple[int, int]],
                       register_getter: Callable[[], dict[str, int]],
                       architecture: str = "unknown",
                       mode: str = "unknown",
                       description: str = "",
                       snapshot_type: SnapshotType = SnapshotType.FULL,
                       parent_id: str | None = None,
                       tags: list[str] | None = None) -> Snapshot:
        """Create a new snapshot."""
        # Run pre-capture callbacks
        for callback in self._callbacks['pre_capture']:
            callback(name)

        # Generate metadata
        metadata = SnapshotMetadata(
            id=self.generate_id(),
            name=name,
            description=description,
            snapshot_type=snapshot_type,
            parent_id=parent_id,
            tags=tags or [],
        )

        # Capture memory regions
        memory_regions = []
        if snapshot_type in (SnapshotType.FULL, SnapshotType.MEMORY_ONLY):
            for base, (size, perms) in memory_map.items():
                try:
                    data = memory_reader(base, size)
                    region = MemoryRegion(
                        address=base,
                        size=size,
                        permissions=perms,
                        data=data,
                    )
                    memory_regions.append(region)
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)  # Skip unreadable regions

        # Capture registers
        registers = None
        if snapshot_type in (SnapshotType.FULL, SnapshotType.REGISTERS_ONLY):
            reg_values = register_getter()
            registers = RegisterState(
                architecture=architecture,
                mode=mode,
                values=reg_values,
            )

        # Handle differential snapshots
        memory_diffs = []
        register_diffs = []
        if snapshot_type == SnapshotType.DIFFERENTIAL and parent_id:
            parent = self.get_snapshot(parent_id)
            if parent:
                # Create temporary full snapshot for comparison
                temp_snap = Snapshot(metadata=metadata, memory_regions=memory_regions, registers=registers)
                comparison = SnapshotComparison(parent, temp_snap)
                memory_diffs = comparison.compare_memory()
                register_diffs = comparison.compare_registers()
                # Clear full data for differential
                memory_regions = []

        snapshot = Snapshot(
            metadata=metadata,
            memory_regions=memory_regions,
            registers=registers,
            memory_diffs=memory_diffs,
            register_diffs=register_diffs,
        )

        self._snapshots[snapshot.id] = snapshot

        # Run post-capture callbacks
        for callback in self._callbacks['post_capture']:
            callback(snapshot)

        return snapshot

    def restore_snapshot(self,
                        snapshot_id: str,
                        memory_writer: Callable[[int, bytes], None],
                        register_setter: Callable[[str, int], None],
                        memory_mapper: Callable[[int, int, int], None] | None = None) -> bool:
        """Restore emulator state from a snapshot."""
        snapshot = self.get_snapshot(snapshot_id)
        if not snapshot:
            return False

        # Run pre-restore callbacks
        for callback in self._callbacks['pre_restore']:
            callback(snapshot)

        # Handle differential snapshots
        if snapshot.is_differential and snapshot.metadata.parent_id:
            # First restore parent
            if not self.restore_snapshot(snapshot.metadata.parent_id,
                                        memory_writer, register_setter, memory_mapper):
                return False

            # Apply diffs
            for diff in snapshot.memory_diffs:
                if diff.new_value:
                    memory_writer(diff.address, diff.new_value)

            for diff in snapshot.register_diffs:
                register_setter(diff.name, diff.new_value)
        else:
            # Full or partial restore
            if memory_mapper:
                for region in snapshot.memory_regions:
                    memory_mapper(region.address, region.size, region.permissions)

            for region in snapshot.memory_regions:
                memory_writer(region.address, region.data)

            if snapshot.registers:
                for name, value in snapshot.registers.values.items():
                    register_setter(name, value)

        # Run post-restore callbacks
        for callback in self._callbacks['post_restore']:
            callback(snapshot)

        return True

    def get_snapshot(self, snapshot_id: str) -> Snapshot | None:
        """Get a snapshot by ID."""
        return self._snapshots.get(snapshot_id)

    def get_snapshot_by_name(self, name: str) -> Snapshot | None:
        """Get a snapshot by name."""
        for snapshot in self._snapshots.values():
            if snapshot.name == name:
                return snapshot
        return None

    def delete_snapshot(self, snapshot_id: str) -> bool:
        """Delete a snapshot."""
        if snapshot_id in self._snapshots:
            del self._snapshots[snapshot_id]
            return True
        return False

    def list_snapshots(self) -> list[Snapshot]:
        """List all snapshots."""
        return list(self._snapshots.values())

    def snapshot_count(self) -> int:
        """Get number of snapshots."""
        return len(self._snapshots)

    def clear_all(self) -> int:
        """Clear all snapshots. Returns count of deleted snapshots."""
        count = len(self._snapshots)
        self._snapshots.clear()
        return count

    def compare_snapshots(self, id1: str, id2: str) -> SnapshotComparison | None:
        """Compare two snapshots."""
        snap1 = self.get_snapshot(id1)
        snap2 = self.get_snapshot(id2)

        if not snap1 or not snap2:
            return None

        return SnapshotComparison(snap1, snap2)

    def add_callback(self, event: str, callback: Callable) -> None:
        """Add a callback for snapshot events."""
        if event in self._callbacks:
            self._callbacks[event].append(callback)

    def remove_callback(self, event: str, callback: Callable) -> bool:
        """Remove a callback."""
        if event in self._callbacks and callback in self._callbacks[event]:
            self._callbacks[event].remove(callback)
            return True
        return False

    def get_snapshot_chain(self, snapshot_id: str) -> list[Snapshot]:
        """Get the chain of snapshots for a differential snapshot."""
        chain = []
        current_id = snapshot_id

        while current_id:
            snapshot = self.get_snapshot(current_id)
            if not snapshot:
                break
            chain.append(snapshot)
            current_id = snapshot.metadata.parent_id

        return list(reversed(chain))

    def get_snapshots_by_tag(self, tag: str) -> list[Snapshot]:
        """Get all snapshots with a specific tag."""
        return [s for s in self._snapshots.values() if tag in s.metadata.tags]


class SnapshotSerializer:
    """Serialize and deserialize snapshots."""

    def __init__(self, compression: SnapshotCompression = SnapshotCompression.GZIP):
        self.compression = compression

    def serialize(self, snapshot: Snapshot) -> bytes:
        """Serialize a snapshot to bytes."""
        data = json.dumps(snapshot.to_dict())

        if self.compression == SnapshotCompression.GZIP:
            return gzip.compress(data.encode('utf-8'))
        return data.encode('utf-8')

    def deserialize(self, data: bytes) -> Snapshot:
        """Deserialize a snapshot from bytes."""
        if self.compression == SnapshotCompression.GZIP:
            data = gzip.decompress(data)

        if isinstance(data, bytes):
            data = data.decode('utf-8')

        return Snapshot.from_dict(json.loads(data))

    def save_to_file(self, snapshot: Snapshot, filepath: str) -> None:
        """Save a snapshot to a file."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)

        data = self.serialize(snapshot)
        path.write_bytes(data)

    def load_from_file(self, filepath: str) -> Snapshot:
        """Load a snapshot from a file."""
        path = Path(filepath)
        data = path.read_bytes()
        return self.deserialize(data)


class SnapshotStore:
    """Persistent storage for snapshots."""

    def __init__(self, storage_dir: str):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.serializer = SnapshotSerializer()
        self._index_file = self.storage_dir / "index.json"
        self._index: dict[str, dict[str, Any]] = {}
        self._load_index()

    def _load_index(self) -> None:
        """Load the snapshot index."""
        if self._index_file.exists():
            try:
                self._index = json.loads(self._index_file.read_text())
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                self._index = {}

    def _save_index(self) -> None:
        """Save the snapshot index."""
        self._index_file.write_text(json.dumps(self._index, indent=2))

    def _snapshot_path(self, snapshot_id: str) -> Path:
        """Get the file path for a snapshot."""
        return self.storage_dir / f"{snapshot_id}.snap"

    def save(self, snapshot: Snapshot) -> str:
        """Save a snapshot to storage."""
        filepath = self._snapshot_path(snapshot.id)
        self.serializer.save_to_file(snapshot, str(filepath))

        # Update index
        self._index[snapshot.id] = {
            'id': snapshot.id,
            'name': snapshot.name,
            'timestamp': snapshot.metadata.timestamp,
            'type': snapshot.metadata.snapshot_type.value,
            'filepath': str(filepath),
        }
        self._save_index()

        return snapshot.id

    def load(self, snapshot_id: str) -> Snapshot | None:
        """Load a snapshot from storage."""
        if snapshot_id not in self._index:
            return None

        filepath = self._snapshot_path(snapshot_id)
        if not filepath.exists():
            return None

        return self.serializer.load_from_file(str(filepath))

    def delete(self, snapshot_id: str) -> bool:
        """Delete a snapshot from storage."""
        if snapshot_id not in self._index:
            return False

        filepath = self._snapshot_path(snapshot_id)
        if filepath.exists():
            filepath.unlink()

        del self._index[snapshot_id]
        self._save_index()
        return True

    def list_all(self) -> list[dict[str, Any]]:
        """List all stored snapshots."""
        return list(self._index.values())

    def exists(self, snapshot_id: str) -> bool:
        """Check if a snapshot exists in storage."""
        return snapshot_id in self._index

    def get_by_name(self, name: str) -> Snapshot | None:
        """Get a snapshot by name."""
        for info in self._index.values():
            if info['name'] == name:
                return self.load(info['id'])
        return None


class SnapshotScheduler:
    """Schedule automatic snapshots."""

    def __init__(self, manager: SnapshotManager):
        self.manager = manager
        self._interval: int | None = None
        self._last_snapshot_time: float = 0
        self._instruction_count: int = 0
        self._instruction_interval: int | None = None
        self._enabled: bool = False
        self._snapshot_callbacks: list[Callable] = []

    def set_time_interval(self, seconds: int) -> None:
        """Set snapshot interval in seconds."""
        self._interval = seconds

    def set_instruction_interval(self, count: int) -> None:
        """Set snapshot interval in instructions."""
        self._instruction_interval = count

    def enable(self) -> None:
        """Enable scheduled snapshots."""
        self._enabled = True
        self._last_snapshot_time = time.time()

    def disable(self) -> None:
        """Disable scheduled snapshots."""
        self._enabled = False

    def is_enabled(self) -> bool:
        """Check if scheduler is enabled."""
        return self._enabled

    def on_instruction(self) -> bool:
        """Call on each instruction. Returns True if snapshot was taken."""
        if not self._enabled:
            return False

        self._instruction_count += 1

        if self._instruction_interval and self._instruction_count >= self._instruction_interval:
            self._instruction_count = 0
            for callback in self._snapshot_callbacks:
                callback()
            return True

        return False

    def check_time_interval(self) -> bool:
        """Check if time interval has elapsed. Returns True if snapshot should be taken."""
        if not self._enabled or not self._interval:
            return False

        current_time = time.time()
        if current_time - self._last_snapshot_time >= self._interval:
            self._last_snapshot_time = current_time
            return True

        return False

    def add_snapshot_callback(self, callback: Callable) -> None:
        """Add callback for when scheduled snapshot is triggered."""
        self._snapshot_callbacks.append(callback)

    def reset_counters(self) -> None:
        """Reset instruction and time counters."""
        self._instruction_count = 0
        self._last_snapshot_time = time.time()


def create_memory_snapshot(memory_regions: dict[int, bytes]) -> list[MemoryRegion]:
    """Create memory regions from a dictionary mapping."""
    regions = []
    for address, data in memory_regions.items():
        region = MemoryRegion(
            address=address,
            size=len(data),
            permissions=7,  # RWX
            data=data,
        )
        regions.append(region)
    return regions


def compare_memory_states(state1: dict[int, bytes], state2: dict[int, bytes]) -> list[MemoryDiff]:
    """Compare two memory states and return differences."""
    diffs = []

    all_addresses = set(state1.keys()) | set(state2.keys())

    for addr in all_addresses:
        data1 = state1.get(addr, b'')
        data2 = state2.get(addr, b'')

        if data1 != data2:
            diffs.append(MemoryDiff(
                address=addr,
                old_value=data1,
                new_value=data2,
            ))

    return diffs
