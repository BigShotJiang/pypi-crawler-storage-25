"""
Decompiler Bridge module for PyUniDbg.

This module provides a unified interface to interact with various decompilers:
- IDA Pro Hex-Rays
- Ghidra
- Binary Ninja
- RetDec
- Radare2/Rizin

Features:
- Decompiled code retrieval
- Cross-references
- Variable and type management
- Function signature handling
- Annotation synchronization
"""

from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum, auto
from typing import Any, Optional


class DecompilerType(IntEnum):
    """Supported decompiler types."""
    IDA_PRO = auto()
    GHIDRA = auto()
    BINARY_NINJA = auto()
    RETDEC = auto()
    RADARE2 = auto()
    RIZIN = auto()
    UNKNOWN = auto()


class VariableType(IntEnum):
    """Types of variables in decompiled code."""
    LOCAL = auto()
    PARAMETER = auto()
    GLOBAL = auto()
    STACK = auto()
    REGISTER = auto()
    RETURN = auto()


class ReferenceType(IntEnum):
    """Types of cross-references."""
    CALL = auto()
    JUMP = auto()
    READ = auto()
    WRITE = auto()
    DATA = auto()
    CODE = auto()
    STRING = auto()


class TypeCategory(IntEnum):
    """Categories of data types."""
    PRIMITIVE = auto()
    POINTER = auto()
    ARRAY = auto()
    STRUCT = auto()
    UNION = auto()
    ENUM = auto()
    TYPEDEF = auto()
    FUNCTION = auto()
    UNKNOWN = auto()


@dataclass
class DataType:
    """A data type from the decompiler."""
    name: str
    category: TypeCategory
    size: int
    alignment: int = 0
    base_type: Optional['DataType'] = None
    members: list[tuple[str, 'DataType', int]] = field(default_factory=list)  # name, type, offset
    is_signed: bool = False
    is_const: bool = False
    is_volatile: bool = False

    def __str__(self) -> str:
        prefix = ""
        if self.is_const:
            prefix += "const "
        if self.is_volatile:
            prefix += "volatile "
        return f"{prefix}{self.name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'category': self.category.name,
            'size': self.size,
            'alignment': self.alignment,
            'is_signed': self.is_signed,
            'is_const': self.is_const,
            'is_volatile': self.is_volatile,
        }


@dataclass
class Variable:
    """A variable in decompiled code."""
    name: str
    var_type: VariableType
    data_type: DataType
    address: int | None = None
    register: str | None = None
    stack_offset: int | None = None
    original_name: str | None = None

    def __str__(self) -> str:
        return f"{self.data_type} {self.name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'var_type': self.var_type.name,
            'data_type': self.data_type.to_dict(),
            'address': self.address,
            'register': self.register,
            'stack_offset': self.stack_offset,
            'original_name': self.original_name,
        }


@dataclass
class CrossReference:
    """A cross-reference between addresses."""
    from_addr: int
    to_addr: int
    ref_type: ReferenceType
    from_func: str | None = None
    to_func: str | None = None
    instruction: str | None = None

    def __str__(self) -> str:
        return f"0x{self.from_addr:x} -> 0x{self.to_addr:x} ({self.ref_type.name})"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'from_addr': self.from_addr,
            'to_addr': self.to_addr,
            'type': self.ref_type.name,
            'from_func': self.from_func,
            'to_func': self.to_func,
            'instruction': self.instruction,
        }


@dataclass
class FunctionSignature:
    """A function signature."""
    name: str
    return_type: DataType
    parameters: list[Variable]
    calling_convention: str = "cdecl"
    is_variadic: bool = False
    is_noreturn: bool = False
    address: int = 0

    def __str__(self) -> str:
        params = ", ".join(str(p) for p in self.parameters)
        if self.is_variadic:
            params += ", ..."
        return f"{self.return_type} {self.name}({params})"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'return_type': self.return_type.to_dict(),
            'parameters': [p.to_dict() for p in self.parameters],
            'calling_convention': self.calling_convention,
            'is_variadic': self.is_variadic,
            'is_noreturn': self.is_noreturn,
            'address': self.address,
        }


@dataclass
class DecompiledFunction:
    """A decompiled function."""
    address: int
    name: str
    signature: FunctionSignature
    source_code: str
    local_variables: list[Variable]
    start_address: int
    end_address: int
    xrefs_from: list[CrossReference] = field(default_factory=list)
    xrefs_to: list[CrossReference] = field(default_factory=list)
    annotations: dict[int, str] = field(default_factory=dict)  # addr -> comment

    @property
    def size(self) -> int:
        """Get function size in bytes."""
        return self.end_address - self.start_address

    def __str__(self) -> str:
        return f"{self.signature}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'name': self.name,
            'signature': self.signature.to_dict(),
            'source_code': self.source_code,
            'local_variables': [v.to_dict() for v in self.local_variables],
            'start_address': self.start_address,
            'end_address': self.end_address,
            'size': self.size,
        }


@dataclass
class Annotation:
    """An annotation in the decompiled code."""
    address: int
    comment: str
    repeatable: bool = False
    source: str = "user"  # user, decompiler, plugin


# =============================================================================
# Decompiler Backend Interface
# =============================================================================

class DecompilerBackend(ABC):
    """Abstract base class for decompiler backends."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Get backend name."""
        pass

    @property
    @abstractmethod
    def decompiler_type(self) -> DecompilerType:
        """Get decompiler type."""
        pass

    @abstractmethod
    def is_connected(self) -> bool:
        """Check if connected to decompiler."""
        pass

    @abstractmethod
    def connect(self, **kwargs) -> bool:
        """Connect to the decompiler."""
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Disconnect from the decompiler."""
        pass

    @abstractmethod
    def decompile_function(self, address: int) -> DecompiledFunction | None:
        """Decompile function at address."""
        pass

    @abstractmethod
    def get_function_name(self, address: int) -> str | None:
        """Get function name at address."""
        pass

    @abstractmethod
    def set_function_name(self, address: int, name: str) -> bool:
        """Set function name at address."""
        pass

    @abstractmethod
    def get_xrefs_to(self, address: int) -> list[CrossReference]:
        """Get cross-references to address."""
        pass

    @abstractmethod
    def get_xrefs_from(self, address: int) -> list[CrossReference]:
        """Get cross-references from address."""
        pass

    @abstractmethod
    def get_type(self, name: str) -> DataType | None:
        """Get data type by name."""
        pass

    @abstractmethod
    def add_type(self, data_type: DataType) -> bool:
        """Add a data type."""
        pass

    @abstractmethod
    def get_comment(self, address: int) -> str | None:
        """Get comment at address."""
        pass

    @abstractmethod
    def set_comment(self, address: int, comment: str,
                   repeatable: bool = False) -> bool:
        """Set comment at address."""
        pass

    @abstractmethod
    def get_function_list(self) -> list[tuple[int, str]]:
        """Get list of all functions (address, name)."""
        pass


# =============================================================================
# IDA Pro Backend
# =============================================================================

class IDAProBackend(DecompilerBackend):
    """IDA Pro / Hex-Rays backend."""

    def __init__(self):
        self._connected = False
        self._functions: dict[int, DecompiledFunction] = {}
        self._types: dict[str, DataType] = {}
        self._comments: dict[int, str] = {}
        self._xrefs_to: dict[int, list[CrossReference]] = defaultdict(list)
        self._xrefs_from: dict[int, list[CrossReference]] = defaultdict(list)
        self._function_names: dict[int, str] = {}

    @property
    def name(self) -> str:
        return "IDA Pro"

    @property
    def decompiler_type(self) -> DecompilerType:
        return DecompilerType.IDA_PRO

    def is_connected(self) -> bool:
        return self._connected

    def connect(self, **kwargs) -> bool:
        """Connect to IDA Pro."""
        # In real implementation, this would connect via IDAPython or IDA's API
        host = kwargs.get('host', 'localhost')
        port = kwargs.get('port', 23946)

        # Simulate connection
        self._connected = True
        return True

    def disconnect(self) -> None:
        """Disconnect from IDA Pro."""
        self._connected = False

    def decompile_function(self, address: int) -> DecompiledFunction | None:
        """Decompile function at address."""
        if not self._connected:
            return None
        return self._functions.get(address)

    def get_function_name(self, address: int) -> str | None:
        """Get function name at address."""
        return self._function_names.get(address)

    def set_function_name(self, address: int, name: str) -> bool:
        """Set function name at address."""
        if not self._connected:
            return False
        self._function_names[address] = name
        return True

    def get_xrefs_to(self, address: int) -> list[CrossReference]:
        """Get cross-references to address."""
        return list(self._xrefs_to.get(address, []))

    def get_xrefs_from(self, address: int) -> list[CrossReference]:
        """Get cross-references from address."""
        return list(self._xrefs_from.get(address, []))

    def get_type(self, name: str) -> DataType | None:
        """Get data type by name."""
        return self._types.get(name)

    def add_type(self, data_type: DataType) -> bool:
        """Add a data type."""
        if not self._connected:
            return False
        self._types[data_type.name] = data_type
        return True

    def get_comment(self, address: int) -> str | None:
        """Get comment at address."""
        return self._comments.get(address)

    def set_comment(self, address: int, comment: str,
                   repeatable: bool = False) -> bool:
        """Set comment at address."""
        if not self._connected:
            return False
        self._comments[address] = comment
        return True

    def get_function_list(self) -> list[tuple[int, str]]:
        """Get list of all functions."""
        return [(addr, name) for addr, name in self._function_names.items()]

    # Test helpers for simulation
    def _add_function(self, func: DecompiledFunction) -> None:
        """Add function for testing."""
        self._functions[func.address] = func
        self._function_names[func.address] = func.name

    def _add_xref(self, xref: CrossReference) -> None:
        """Add cross-reference for testing."""
        self._xrefs_from[xref.from_addr].append(xref)
        self._xrefs_to[xref.to_addr].append(xref)


# =============================================================================
# Ghidra Backend
# =============================================================================

class GhidraBackend(DecompilerBackend):
    """Ghidra backend."""

    def __init__(self):
        self._connected = False
        self._functions: dict[int, DecompiledFunction] = {}
        self._types: dict[str, DataType] = {}
        self._comments: dict[int, str] = {}
        self._xrefs_to: dict[int, list[CrossReference]] = defaultdict(list)
        self._xrefs_from: dict[int, list[CrossReference]] = defaultdict(list)
        self._function_names: dict[int, str] = {}
        self._project_path: str | None = None

    @property
    def name(self) -> str:
        return "Ghidra"

    @property
    def decompiler_type(self) -> DecompilerType:
        return DecompilerType.GHIDRA

    def is_connected(self) -> bool:
        return self._connected

    def connect(self, **kwargs) -> bool:
        """Connect to Ghidra via Ghidrathon or Bridge."""
        self._project_path = kwargs.get('project_path')
        # In real implementation, this would connect via Ghidrathon/pyhidra
        self._connected = True
        return True

    def disconnect(self) -> None:
        """Disconnect from Ghidra."""
        self._connected = False
        self._project_path = None

    def decompile_function(self, address: int) -> DecompiledFunction | None:
        """Decompile function at address."""
        if not self._connected:
            return None
        return self._functions.get(address)

    def get_function_name(self, address: int) -> str | None:
        """Get function name at address."""
        return self._function_names.get(address)

    def set_function_name(self, address: int, name: str) -> bool:
        """Set function name at address."""
        if not self._connected:
            return False
        self._function_names[address] = name
        return True

    def get_xrefs_to(self, address: int) -> list[CrossReference]:
        """Get cross-references to address."""
        return list(self._xrefs_to.get(address, []))

    def get_xrefs_from(self, address: int) -> list[CrossReference]:
        """Get cross-references from address."""
        return list(self._xrefs_from.get(address, []))

    def get_type(self, name: str) -> DataType | None:
        """Get data type by name."""
        return self._types.get(name)

    def add_type(self, data_type: DataType) -> bool:
        """Add a data type."""
        if not self._connected:
            return False
        self._types[data_type.name] = data_type
        return True

    def get_comment(self, address: int) -> str | None:
        """Get comment at address."""
        return self._comments.get(address)

    def set_comment(self, address: int, comment: str,
                   repeatable: bool = False) -> bool:
        """Set comment at address."""
        if not self._connected:
            return False
        self._comments[address] = comment
        return True

    def get_function_list(self) -> list[tuple[int, str]]:
        """Get list of all functions."""
        return [(addr, name) for addr, name in self._function_names.items()]

    # Test helpers
    def _add_function(self, func: DecompiledFunction) -> None:
        """Add function for testing."""
        self._functions[func.address] = func
        self._function_names[func.address] = func.name

    def _add_xref(self, xref: CrossReference) -> None:
        """Add cross-reference for testing."""
        self._xrefs_from[xref.from_addr].append(xref)
        self._xrefs_to[xref.to_addr].append(xref)


# =============================================================================
# Binary Ninja Backend
# =============================================================================

class BinaryNinjaBackend(DecompilerBackend):
    """Binary Ninja backend."""

    def __init__(self):
        self._connected = False
        self._functions: dict[int, DecompiledFunction] = {}
        self._types: dict[str, DataType] = {}
        self._comments: dict[int, str] = {}
        self._xrefs_to: dict[int, list[CrossReference]] = defaultdict(list)
        self._xrefs_from: dict[int, list[CrossReference]] = defaultdict(list)
        self._function_names: dict[int, str] = {}
        self._bv = None  # Would be BinaryView in real implementation

    @property
    def name(self) -> str:
        return "Binary Ninja"

    @property
    def decompiler_type(self) -> DecompilerType:
        return DecompilerType.BINARY_NINJA

    def is_connected(self) -> bool:
        return self._connected

    def connect(self, **kwargs) -> bool:
        """Connect to Binary Ninja."""
        binary_path = kwargs.get('binary_path')
        # In real implementation, would use binaryninja.load
        self._connected = True
        return True

    def disconnect(self) -> None:
        """Disconnect from Binary Ninja."""
        self._connected = False
        self._bv = None

    def decompile_function(self, address: int) -> DecompiledFunction | None:
        """Decompile function at address using HLIL."""
        if not self._connected:
            return None
        return self._functions.get(address)

    def get_function_name(self, address: int) -> str | None:
        """Get function name at address."""
        return self._function_names.get(address)

    def set_function_name(self, address: int, name: str) -> bool:
        """Set function name at address."""
        if not self._connected:
            return False
        self._function_names[address] = name
        return True

    def get_xrefs_to(self, address: int) -> list[CrossReference]:
        """Get cross-references to address."""
        return list(self._xrefs_to.get(address, []))

    def get_xrefs_from(self, address: int) -> list[CrossReference]:
        """Get cross-references from address."""
        return list(self._xrefs_from.get(address, []))

    def get_type(self, name: str) -> DataType | None:
        """Get data type by name."""
        return self._types.get(name)

    def add_type(self, data_type: DataType) -> bool:
        """Add a data type."""
        if not self._connected:
            return False
        self._types[data_type.name] = data_type
        return True

    def get_comment(self, address: int) -> str | None:
        """Get comment at address."""
        return self._comments.get(address)

    def set_comment(self, address: int, comment: str,
                   repeatable: bool = False) -> bool:
        """Set comment at address."""
        if not self._connected:
            return False
        self._comments[address] = comment
        return True

    def get_function_list(self) -> list[tuple[int, str]]:
        """Get list of all functions."""
        return [(addr, name) for addr, name in self._function_names.items()]

    # Test helpers
    def _add_function(self, func: DecompiledFunction) -> None:
        """Add function for testing."""
        self._functions[func.address] = func
        self._function_names[func.address] = func.name

    def _add_xref(self, xref: CrossReference) -> None:
        """Add cross-reference for testing."""
        self._xrefs_from[xref.from_addr].append(xref)
        self._xrefs_to[xref.to_addr].append(xref)


# =============================================================================
# Type Manager
# =============================================================================

class TypeManager:
    """Manages data types from decompilers."""

    # Common primitive types
    PRIMITIVES = {
        'void': (0, False),
        'bool': (1, False),
        'char': (1, True),
        'unsigned char': (1, False),
        'short': (2, True),
        'unsigned short': (2, False),
        'int': (4, True),
        'unsigned int': (4, False),
        'long': (8, True),
        'unsigned long': (8, False),
        'long long': (8, True),
        'unsigned long long': (8, False),
        'float': (4, True),
        'double': (8, True),
        'int8_t': (1, True),
        'uint8_t': (1, False),
        'int16_t': (2, True),
        'uint16_t': (2, False),
        'int32_t': (4, True),
        'uint32_t': (4, False),
        'int64_t': (8, True),
        'uint64_t': (8, False),
        'size_t': (8, False),
        'ssize_t': (8, True),
        'ptrdiff_t': (8, True),
    }

    def __init__(self):
        self._types: dict[str, DataType] = {}
        self._init_primitives()

    def _init_primitives(self) -> None:
        """Initialize primitive types."""
        for name, (size, signed) in self.PRIMITIVES.items():
            self._types[name] = DataType(
                name=name,
                category=TypeCategory.PRIMITIVE,
                size=size,
                alignment=size if size > 0 else 1,
                is_signed=signed,
            )

    def get_type(self, name: str) -> DataType | None:
        """Get a type by name."""
        return self._types.get(name)

    def add_type(self, data_type: DataType) -> None:
        """Add a data type."""
        self._types[data_type.name] = data_type

    def create_pointer(self, base_type: DataType,
                       pointer_size: int = 8) -> DataType:
        """Create a pointer type."""
        return DataType(
            name=f"{base_type.name}*",
            category=TypeCategory.POINTER,
            size=pointer_size,
            alignment=pointer_size,
            base_type=base_type,
        )

    def create_array(self, element_type: DataType,
                     count: int) -> DataType:
        """Create an array type."""
        return DataType(
            name=f"{element_type.name}[{count}]",
            category=TypeCategory.ARRAY,
            size=element_type.size * count,
            alignment=element_type.alignment,
            base_type=element_type,
        )

    def create_struct(self, name: str,
                      members: list[tuple[str, DataType]]) -> DataType:
        """Create a struct type."""
        offset = 0
        member_list = []
        max_alignment = 1

        for mem_name, mem_type in members:
            # Align to member alignment
            if mem_type.alignment > 0:
                padding = (mem_type.alignment - (offset % mem_type.alignment)) % mem_type.alignment
                offset += padding
                max_alignment = max(max_alignment, mem_type.alignment)

            member_list.append((mem_name, mem_type, offset))
            offset += mem_type.size

        # Final padding for struct alignment
        padding = (max_alignment - (offset % max_alignment)) % max_alignment
        offset += padding

        struct_type = DataType(
            name=name,
            category=TypeCategory.STRUCT,
            size=offset,
            alignment=max_alignment,
            members=member_list,
        )
        self.add_type(struct_type)
        return struct_type

    def get_all_types(self) -> list[DataType]:
        """Get all types."""
        return list(self._types.values())

    def clear_custom_types(self) -> None:
        """Clear non-primitive types."""
        primitives = {name for name in self.PRIMITIVES}
        self._types = {
            name: t for name, t in self._types.items()
            if name in primitives
        }


# =============================================================================
# Decompiler Bridge
# =============================================================================

class DecompilerBridge:
    """Main decompiler bridge coordinating multiple backends."""

    def __init__(self):
        self._backends: dict[DecompilerType, DecompilerBackend] = {}
        self._active_backend: DecompilerBackend | None = None
        self._type_manager = TypeManager()
        self._annotation_cache: dict[int, list[Annotation]] = defaultdict(list)
        self._callbacks: dict[str, list[Callable]] = defaultdict(list)

    @property
    def type_manager(self) -> TypeManager:
        """Get the type manager."""
        return self._type_manager

    @property
    def active_backend(self) -> DecompilerBackend | None:
        """Get the active backend."""
        return self._active_backend

    def register_backend(self, backend: DecompilerBackend) -> None:
        """Register a decompiler backend."""
        self._backends[backend.decompiler_type] = backend

    def set_active_backend(self, decompiler_type: DecompilerType) -> bool:
        """Set the active backend."""
        if decompiler_type in self._backends:
            self._active_backend = self._backends[decompiler_type]
            return True
        return False

    def connect(self, decompiler_type: DecompilerType,
                **kwargs) -> bool:
        """Connect to a specific decompiler."""
        if decompiler_type not in self._backends:
            return False

        backend = self._backends[decompiler_type]
        if backend.connect(**kwargs):
            self._active_backend = backend
            self._notify('connect', backend)
            return True
        return False

    def disconnect(self) -> None:
        """Disconnect from the active backend."""
        if self._active_backend:
            self._active_backend.disconnect()
            self._notify('disconnect', self._active_backend)
            self._active_backend = None

    def is_connected(self) -> bool:
        """Check if connected to a decompiler."""
        return self._active_backend is not None and self._active_backend.is_connected()

    def decompile(self, address: int) -> DecompiledFunction | None:
        """Decompile function at address."""
        if not self._active_backend:
            return None

        func = self._active_backend.decompile_function(address)
        if func:
            self._notify('decompile', func)
        return func

    def get_function_name(self, address: int) -> str | None:
        """Get function name at address."""
        if not self._active_backend:
            return None
        return self._active_backend.get_function_name(address)

    def set_function_name(self, address: int, name: str) -> bool:
        """Set function name at address."""
        if not self._active_backend:
            return False
        success = self._active_backend.set_function_name(address, name)
        if success:
            self._notify('rename', {'address': address, 'name': name})
        return success

    def get_xrefs_to(self, address: int) -> list[CrossReference]:
        """Get cross-references to address."""
        if not self._active_backend:
            return []
        return self._active_backend.get_xrefs_to(address)

    def get_xrefs_from(self, address: int) -> list[CrossReference]:
        """Get cross-references from address."""
        if not self._active_backend:
            return []
        return self._active_backend.get_xrefs_from(address)

    def get_comment(self, address: int) -> str | None:
        """Get comment at address."""
        if not self._active_backend:
            return None
        return self._active_backend.get_comment(address)

    def set_comment(self, address: int, comment: str,
                   repeatable: bool = False) -> bool:
        """Set comment at address."""
        if not self._active_backend:
            return False
        success = self._active_backend.set_comment(address, comment, repeatable)
        if success:
            annotation = Annotation(
                address=address,
                comment=comment,
                repeatable=repeatable,
            )
            self._annotation_cache[address].append(annotation)
            self._notify('comment', annotation)
        return success

    def get_type(self, name: str) -> DataType | None:
        """Get type by name."""
        # First check local type manager
        local_type = self._type_manager.get_type(name)
        if local_type:
            return local_type

        # Then check backend
        if self._active_backend:
            return self._active_backend.get_type(name)
        return None

    def add_type(self, data_type: DataType) -> bool:
        """Add a data type."""
        self._type_manager.add_type(data_type)
        if self._active_backend:
            return self._active_backend.add_type(data_type)
        return True

    def get_function_list(self) -> list[tuple[int, str]]:
        """Get list of all functions."""
        if not self._active_backend:
            return []
        return self._active_backend.get_function_list()

    def add_callback(self, event: str,
                     callback: Callable) -> None:
        """Add event callback."""
        self._callbacks[event].append(callback)

    def _notify(self, event: str, data: Any) -> None:
        """Notify callbacks of an event."""
        for callback in self._callbacks.get(event, []):
            callback(data)

    def sync_annotations(self, source: DecompilerType,
                        target: DecompilerType) -> int:
        """Sync annotations between decompilers."""
        if source not in self._backends or target not in self._backends:
            return 0

        source_backend = self._backends[source]
        target_backend = self._backends[target]

        if not source_backend.is_connected() or not target_backend.is_connected():
            return 0

        synced = 0
        functions = source_backend.get_function_list()

        for addr, name in functions:
            comment = source_backend.get_comment(addr)
            if comment:
                if target_backend.set_comment(addr, comment):
                    synced += 1

        return synced

    def get_summary(self) -> dict[str, Any]:
        """Get bridge summary."""
        return {
            'backends': [b.name for b in self._backends.values()],
            'active': self._active_backend.name if self._active_backend else None,
            'connected': self.is_connected(),
            'types_count': len(self._type_manager.get_all_types()),
            'annotations_count': sum(len(v) for v in self._annotation_cache.values()),
        }


# =============================================================================
# Helper Functions
# =============================================================================

def create_decompiler_bridge() -> DecompilerBridge:
    """Create a decompiler bridge with default backends."""
    bridge = DecompilerBridge()
    bridge.register_backend(IDAProBackend())
    bridge.register_backend(GhidraBackend())
    bridge.register_backend(BinaryNinjaBackend())
    return bridge


def create_primitive_type(name: str) -> DataType | None:
    """Create a primitive data type."""
    manager = TypeManager()
    return manager.get_type(name)


def create_sample_function(address: int, name: str,
                           source: str = "void func(void) { }") -> DecompiledFunction:
    """Create a sample decompiled function for testing."""
    void_type = DataType(
        name='void',
        category=TypeCategory.PRIMITIVE,
        size=0,
        alignment=1,
    )

    signature = FunctionSignature(
        name=name,
        return_type=void_type,
        parameters=[],
        address=address,
    )

    return DecompiledFunction(
        address=address,
        name=name,
        signature=signature,
        source_code=source,
        local_variables=[],
        start_address=address,
        end_address=address + 0x100,
    )
