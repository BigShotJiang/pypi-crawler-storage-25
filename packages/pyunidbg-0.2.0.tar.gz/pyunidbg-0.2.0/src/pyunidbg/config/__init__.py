"""
Configuration System for PyUniDbg.

Provides YAML/JSON configuration file support with:
- Per-project settings
- User defaults
- Environment variable overrides
- Profile management

Configuration Loading Order (later overrides earlier):
1. Built-in defaults
2. Global config (~/.config/pyunidbg/config.yaml)
3. Project config (./pyunidbg.yaml or ./.pyunidbg.yaml)
4. Environment variables (PYUNIDBG_*)
5. Command-line arguments

Usage:
    from pyunidbg.config import Config, get_config
    
    # Get default configuration
    config = get_config()
    
    # Access values
    arch = config.get("emulator.arch")
    api_level = config.get("android.api_level")
    
    # Set values
    config.set("debug.verbose", True)
    
    # Save configuration
    config.save()
"""

from __future__ import annotations

import json
import logging
import os
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeVar, Union

# Try to import YAML support
try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

__all__ = [
    "Config",
    "ConfigProfile",
    "get_config",
    "get_config_path",
    "load_config",
    "save_config",
    "DEFAULT_CONFIG",
]

logger = logging.getLogger(__name__)

T = TypeVar('T')


# ==================== Default Configuration ====================

DEFAULT_CONFIG: dict[str, Any] = {
    # Emulator settings
    "emulator": {
        "arch": "arm64",
        "endianness": "little",
        "stack_size": 0x100000,  # 1MB
        "heap_size": 0x1000000,  # 16MB
        "trace_instructions": False,
        "trace_memory": False,
        "trace_syscalls": False,
    },

    # Android settings
    "android": {
        "api_level": 29,
        "sdk_version": "10.0",
        "abi": "arm64-v8a",
        "auto_jni_onload": True,
        "libc_path": None,
        "linker_path": None,
    },

    # iOS settings
    "ios": {
        "version": "14.0",
        "device": "iPhone12,1",
        "auto_dyld": True,
    },

    # Debugging settings
    "debug": {
        "verbose": False,
        "log_level": "INFO",
        "log_file": None,
        "gdb_port": 1234,
        "gdb_host": "localhost",
        "break_on_error": True,
    },

    # Analysis settings
    "analysis": {
        "coverage_mode": "basic_block",
        "trace_format": "text",
        "taint_enabled": False,
        "taint_colors": ["input", "network", "file"],
        "max_trace_entries": 100000,
    },

    # Hook settings
    "hooks": {
        "hook_libc": True,
        "hook_syscalls": True,
        "hook_jni": True,
        "auto_resolve_symbols": True,
    },

    # Virtual filesystem settings
    "vfs": {
        "enabled": True,
        "root": None,
        "writable": False,
        "proc_enabled": True,
        "sys_enabled": True,
    },

    # Network settings
    "network": {
        "enabled": True,
        "intercept_ssl": False,
        "dns_mappings": {},
        "proxy": None,
    },

    # Output settings
    "output": {
        "format": "text",  # text, json, html
        "color": True,
        "timestamps": True,
        "show_addresses": True,
        "hex_dump_width": 16,
    },

    # Paths
    "paths": {
        "cache_dir": None,
        "plugins_dir": None,
        "scripts_dir": None,
        "symbols_dir": None,
    },

    # Plugin settings
    "plugins": {
        "enabled": True,
        "auto_load": True,
        "disabled_plugins": [],
    },
}


# ==================== Configuration Path Helpers ====================

def get_config_dir() -> Path:
    """Get the configuration directory."""
    # Check XDG_CONFIG_HOME first
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        return Path(xdg_config) / "pyunidbg"

    # Fall back to ~/.config/pyunidbg
    return Path.home() / ".config" / "pyunidbg"


def get_config_path() -> Path:
    """Get the path to the global configuration file."""
    return get_config_dir() / "config.yaml"


def get_project_config_paths() -> list[Path]:
    """Get possible project configuration file paths."""
    cwd = Path.cwd()
    return [
        cwd / "pyunidbg.yaml",
        cwd / "pyunidbg.yml",
        cwd / ".pyunidbg.yaml",
        cwd / ".pyunidbg.yml",
        cwd / "pyunidbg.json",
        cwd / ".pyunidbg.json",
    ]


# ==================== Configuration Profile ====================

@dataclass
class ConfigProfile:
    """A named configuration profile."""
    name: str
    description: str = ""
    config: dict[str, Any] = field(default_factory=dict)
    parent: str | None = None  # Inherit from another profile

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "config": self.config,
            "parent": self.parent,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConfigProfile:
        return cls(
            name=data.get("name", ""),
            description=data.get("description", ""),
            config=data.get("config", {}),
            parent=data.get("parent"),
        )


# ==================== Main Config Class ====================

class Config:
    """
    Configuration manager for PyUniDbg.
    
    Supports:
    - Nested key access (config.get("emulator.arch"))
    - Type-safe getters
    - Environment variable overrides
    - YAML and JSON file formats
    - Profile management
    """

    def __init__(self, data: dict[str, Any] | None = None):
        """Initialize configuration with optional data."""
        self._data = deepcopy(DEFAULT_CONFIG)
        if data:
            self._deep_merge(self._data, data)

        self._profiles: dict[str, ConfigProfile] = {}
        self._active_profile: str | None = None
        self._config_path: Path | None = None
        self._modified = False

    @classmethod
    def load(cls, path: str | Path | None = None) -> Config:
        """
        Load configuration from files.
        
        Args:
            path: Optional specific path to load from
        
        Returns:
            Loaded Config instance
        """
        config = cls()

        # Load global config
        global_path = get_config_path()
        if global_path.exists():
            config._load_file(global_path)
            logger.debug(f"Loaded global config from {global_path}")

        # Load project config
        for project_path in get_project_config_paths():
            if project_path.exists():
                config._load_file(project_path)
                logger.debug(f"Loaded project config from {project_path}")
                break

        # Load specified path
        if path:
            path = Path(path)
            if path.exists():
                config._load_file(path)
                config._config_path = path

        # Apply environment overrides
        config._apply_env_overrides()

        return config

    def _load_file(self, path: Path) -> None:
        """Load configuration from a file."""
        content = path.read_text()

        if path.suffix in (".yaml", ".yml"):
            if not YAML_AVAILABLE:
                logger.warning(f"YAML support not available, skipping {path}")
                return
            data = yaml.safe_load(content)
        elif path.suffix == ".json":
            data = json.loads(content)
        else:
            # Try YAML first, then JSON
            try:
                if YAML_AVAILABLE:
                    data = yaml.safe_load(content)
                else:
                    data = json.loads(content)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                data = json.loads(content)

        if data:
            self._deep_merge(self._data, data)

            # Load profiles if present
            if "profiles" in data:
                for name, profile_data in data["profiles"].items():
                    profile_data["name"] = name
                    self._profiles[name] = ConfigProfile.from_dict(profile_data)

    def _apply_env_overrides(self) -> None:
        """Apply environment variable overrides."""
        prefix = "PYUNIDBG_"

        for key, value in os.environ.items():
            if not key.startswith(prefix):
                continue

            # Convert PYUNIDBG_EMULATOR_ARCH to emulator.arch
            config_key = key[len(prefix):].lower().replace("_", ".")

            # Try to parse the value
            parsed_value: Any = value
            if value.lower() in ("true", "yes", "1"):
                parsed_value = True
            elif value.lower() in ("false", "no", "0"):
                parsed_value = False
            elif value.isdigit():
                parsed_value = int(value)
            elif value.startswith("0x"):
                try:
                    parsed_value = int(value, 16)
                except ValueError:
                    pass

            self.set(config_key, parsed_value)
            logger.debug(f"Applied env override: {config_key} = {parsed_value}")

    def save(self, path: str | Path | None = None) -> None:
        """
        Save configuration to a file.
        
        Args:
            path: Path to save to. Uses last loaded path or global config if not specified.
        """
        if path:
            save_path = Path(path)
        elif self._config_path:
            save_path = self._config_path
        else:
            save_path = get_config_path()

        # Ensure directory exists
        save_path.parent.mkdir(parents=True, exist_ok=True)

        # Prepare data
        data = self._data.copy()
        if self._profiles:
            data["profiles"] = {
                name: profile.to_dict()
                for name, profile in self._profiles.items()
            }

        # Save based on extension
        if save_path.suffix in (".yaml", ".yml"):
            if not YAML_AVAILABLE:
                raise ImportError("PyYAML required to save YAML config. Install with: pip install pyyaml")
            content = yaml.dump(data, default_flow_style=False, sort_keys=False)
        else:
            content = json.dumps(data, indent=2)

        save_path.write_text(content)
        self._modified = False
        logger.info(f"Saved configuration to {save_path}")

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a configuration value using dot notation.
        
        Args:
            key: Configuration key (e.g., "emulator.arch")
            default: Default value if key not found
        
        Returns:
            Configuration value or default
        """
        parts = key.split(".")
        value = self._data

        for part in parts:
            if isinstance(value, dict) and part in value:
                value = value[part]
            else:
                return default

        return value

    def get_typed(self, key: str, type_: type[T], default: T | None = None) -> T | None:
        """Get a configuration value with type checking."""
        value = self.get(key, default)
        if value is None:
            return default
        if isinstance(value, type_):
            return value
        # Try to convert
        try:
            return type_(value)
        except (ValueError, TypeError):
            return default

    def get_int(self, key: str, default: int = 0) -> int:
        """Get an integer configuration value."""
        return self.get_typed(key, int, default) or default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Get a boolean configuration value."""
        value = self.get(key, default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ("true", "yes", "1", "on")
        return bool(value)

    def get_str(self, key: str, default: str = "") -> str:
        """Get a string configuration value."""
        return self.get_typed(key, str, default) or default

    def get_list(self, key: str, default: list | None = None) -> list:
        """Get a list configuration value."""
        value = self.get(key, default)
        if isinstance(value, list):
            return value
        if value is None:
            return default or []
        return [value]

    def get_dict(self, key: str, default: dict | None = None) -> dict:
        """Get a dict configuration value."""
        value = self.get(key, default)
        if isinstance(value, dict):
            return value
        return default or {}

    def set(self, key: str, value: Any) -> None:
        """
        Set a configuration value using dot notation.
        
        Args:
            key: Configuration key (e.g., "emulator.arch")
            value: Value to set
        """
        parts = key.split(".")
        data = self._data

        # Navigate to parent
        for part in parts[:-1]:
            if part not in data:
                data[part] = {}
            data = data[part]

        # Set value
        data[parts[-1]] = value
        self._modified = True

    def delete(self, key: str) -> bool:
        """
        Delete a configuration key.
        
        Args:
            key: Configuration key to delete
        
        Returns:
            True if key was deleted, False if not found
        """
        parts = key.split(".")
        data = self._data

        # Navigate to parent
        for part in parts[:-1]:
            if part not in data:
                return False
            data = data[part]

        # Delete key
        if parts[-1] in data:
            del data[parts[-1]]
            self._modified = True
            return True
        return False

    def has(self, key: str) -> bool:
        """Check if a configuration key exists."""
        return self.get(key) is not None

    def keys(self, prefix: str = "") -> list[str]:
        """Get all configuration keys, optionally filtered by prefix."""
        result = []

        def collect_keys(data: dict, current_prefix: str):
            for key, value in data.items():
                full_key = f"{current_prefix}.{key}" if current_prefix else key
                if isinstance(value, dict):
                    collect_keys(value, full_key)
                else:
                    result.append(full_key)

        collect_keys(self._data, "")

        if prefix:
            result = [k for k in result if k.startswith(prefix)]

        return sorted(result)

    def to_dict(self) -> dict[str, Any]:
        """Get configuration as a dictionary."""
        return deepcopy(self._data)

    def reset(self, key: str | None = None) -> None:
        """
        Reset configuration to defaults.
        
        Args:
            key: Specific key to reset, or None to reset all
        """
        if key:
            # Get default value
            default_value = self._get_nested(DEFAULT_CONFIG, key)
            if default_value is not None:
                self.set(key, deepcopy(default_value))
        else:
            self._data = deepcopy(DEFAULT_CONFIG)
            self._modified = True

    def _get_nested(self, data: dict, key: str) -> Any:
        """Get nested value from dict."""
        parts = key.split(".")
        value = data
        for part in parts:
            if isinstance(value, dict) and part in value:
                value = value[part]
            else:
                return None
        return value

    def _deep_merge(self, base: dict, override: dict) -> None:
        """Deep merge override into base."""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value

    # Profile management

    def add_profile(self, profile: ConfigProfile) -> None:
        """Add a configuration profile."""
        self._profiles[profile.name] = profile
        self._modified = True

    def remove_profile(self, name: str) -> bool:
        """Remove a configuration profile."""
        if name in self._profiles:
            del self._profiles[name]
            self._modified = True
            return True
        return False

    def get_profile(self, name: str) -> ConfigProfile | None:
        """Get a configuration profile by name."""
        return self._profiles.get(name)

    def list_profiles(self) -> list[str]:
        """List all profile names."""
        return list(self._profiles.keys())

    def activate_profile(self, name: str) -> bool:
        """
        Activate a configuration profile.
        
        Args:
            name: Profile name to activate
        
        Returns:
            True if profile was activated, False if not found
        """
        profile = self._profiles.get(name)
        if not profile:
            return False

        # Apply parent first if exists
        if profile.parent:
            self.activate_profile(profile.parent)

        # Apply profile config
        self._deep_merge(self._data, profile.config)
        self._active_profile = name
        return True

    @property
    def active_profile(self) -> str | None:
        """Get the name of the currently active profile."""
        return self._active_profile

    @property
    def modified(self) -> bool:
        """Check if configuration has been modified since last save/load."""
        return self._modified

    def __repr__(self) -> str:
        return f"Config({len(self.keys())} keys, modified={self._modified})"


# ==================== Global Config Instance ====================

_global_config: Config | None = None


def get_config() -> Config:
    """
    Get the global configuration instance.
    
    Returns:
        Global Config instance (loaded lazily)
    """
    global _global_config
    if _global_config is None:
        _global_config = Config.load()
    return _global_config


def load_config(path: str | Path | None = None) -> Config:
    """
    Load configuration from files.
    
    Args:
        path: Optional specific path to load from
    
    Returns:
        New Config instance
    """
    return Config.load(path)


def save_config(config: Config | None = None, path: str | Path | None = None) -> None:
    """
    Save configuration to a file.
    
    Args:
        config: Config instance to save, or None for global
        path: Path to save to
    """
    if config is None:
        config = get_config()
    config.save(path)


def reset_global_config() -> None:
    """Reset the global configuration instance."""
    global _global_config
    _global_config = None
