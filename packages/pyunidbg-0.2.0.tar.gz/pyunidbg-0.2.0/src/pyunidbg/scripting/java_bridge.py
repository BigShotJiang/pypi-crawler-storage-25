"""
Java - Frida-style Java/Android bridge.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..android.jni import JNIEnv
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


@dataclass
class JavaClass:
    """Wrapper for a Java class."""
    name: str
    _handle: int = 0
    _methods: dict = field(default_factory=dict)
    _fields: dict = field(default_factory=dict)
    _jni: Any | None = None

    def __getattr__(self, name: str) -> Any:
        """Get method or field."""
        if name.startswith('_'):
            raise AttributeError(name)

        # Check if it's a method
        if name in self._methods:
            return self._methods[name]

        # Check if it's a field
        if name in self._fields:
            return self._fields[name]

        # Dynamic lookup - handle special Frida method names
        if name == '$new':
            return lambda *args: self._new(*args)
        if name == '$init':
            return lambda: self._init()

        return JavaMethod(self, name)

    def _new(self, *args) -> JavaObject:
        """Create new instance of this class. Called as $new() in Frida."""
        return JavaObject(self, None)

    def _init(self) -> JavaClass:
        """Initialize static fields. Called as $init() in Frida."""
        return self


@dataclass
class JavaMethod:
    """Wrapper for a Java method."""
    _class: JavaClass
    name: str
    _overloads: list[Callable] = field(default_factory=list)

    def __call__(self, *args) -> Any:
        """Call the method."""
        # Would call through JNI
        logger.debug(f"Java call: {self._class.name}.{self.name}({args})")
        return None

    def overload(self, *arg_types) -> JavaMethod:
        """Select specific overload."""
        return self

    @property
    def implementation(self) -> Callable | None:
        """Get current implementation."""
        return None

    @implementation.setter
    def implementation(self, func: Callable) -> None:
        """Replace method implementation."""
        logger.debug(f"Replacing {self._class.name}.{self.name}")


@dataclass
class JavaObject:
    """Wrapper for a Java object instance."""
    _class: JavaClass
    _handle: int | None

    def __getattr__(self, name: str) -> Any:
        """Get method or field."""
        if name.startswith('_'):
            raise AttributeError(name)
        # Handle Frida's special $className
        if name == '$className':
            return lambda: self._class.name
        return JavaMethod(self._class, name)

    def get_className(self) -> str:
        """Get class name. Called as $className in Frida."""
        return self._class.name


class JavaChooser:
    """Find instances of a class on the heap."""

    def __init__(self, class_name: str):
        self.class_name = class_name
        self._instances: list[JavaObject] = []

    def __iter__(self):
        return iter(self._instances)


class Java:
    """
    Frida-compatible Java API.
    
    Provides Java/Android interop:
    - Class loading and hooking
    - Method replacement
    - Object creation
    - Heap inspection
    
    Usage:
        Java.set_emulator(emu)
        
        # Perform Java operations
        Java.perform(lambda: 
            print(Java.use("android.app.Activity"))
        )
        
        # Hook a method
        Java.perform(lambda:
            setattr(
                Java.use("com.example.App").secretMethod,
                'implementation',
                lambda self: "hooked!"
            )
        )
        
        # Find instances
        Java.performNow(lambda:
            for instance in Java.choose("com.example.MyClass"):
                print(instance)
        )
    """

    _emulator: Emulator | None = None
    _jni_env: JNIEnv | None = None
    _classes: dict[str, JavaClass] = {}
    _available: bool = False
    _class_factory = None

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

        # Try to get JNI environment
        if hasattr(emulator, 'jni_env'):
            cls._jni_env = emulator.jni_env
            cls._available = True

    @classmethod
    def get_available(cls) -> bool:
        """Check if Java is available."""
        return cls._available

    @classmethod
    def get_androidVersion(cls) -> str:
        """Get Android version."""
        return "11"  # Default

    @classmethod
    def get_vm(cls) -> Any | None:
        """Get Java VM."""
        if cls._emulator and hasattr(cls._emulator, 'java_vm'):
            return cls._emulator.java_vm
        return None

    @classmethod
    def perform(cls, fn: Callable) -> None:
        """
        Run function on Java thread.
        
        Args:
            fn: Function to run (receives no arguments)
        """
        if not cls._available:
            logger.warning("Java not available")
            return

        try:
            fn()
        except Exception as e:
            logger.error(f"Java.perform error: {e}")

    @classmethod
    def performNow(cls, fn: Callable) -> Any:
        """
        Run function immediately on Java thread.
        
        Args:
            fn: Function to run
            
        Returns:
            Function result
        """
        if not cls._available:
            logger.warning("Java not available")
            return None

        try:
            return fn()
        except Exception as e:
            logger.error(f"Java.performNow error: {e}")
            return None

    @classmethod
    def use(cls, class_name: str) -> JavaClass:
        """
        Get a Java class by name.
        
        Args:
            class_name: Fully qualified class name
            
        Returns:
            JavaClass wrapper
        """
        # Check cache
        if class_name in cls._classes:
            return cls._classes[class_name]

        # Create wrapper
        java_class = JavaClass(
            name=class_name,
            _jni=cls._jni_env
        )

        # Load class through JNI if available
        if cls._jni_env:
            try:
                handle = cls._jni_env.find_class(class_name.replace('.', '/'))
                java_class._handle = handle
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        cls._classes[class_name] = java_class
        return java_class

    @classmethod
    def choose(cls, class_name: str) -> JavaChooser:
        """
        Find instances of a class on the heap.
        
        Args:
            class_name: Class to find instances of
            
        Returns:
            Iterator over instances
        """
        return JavaChooser(class_name)

    @classmethod
    def scheduleOnMainThread(cls, fn: Callable) -> None:
        """Schedule function on main thread."""
        cls.perform(fn)

    @classmethod
    def isMainThread(cls) -> bool:
        """Check if on main thread."""
        return True  # Emulator is single-threaded

    @classmethod
    def registerClass(cls, spec: dict) -> JavaClass:
        """
        Register a new Java class.
        
        Args:
            spec: Class specification with 'name', 'superClass', 'methods'
            
        Returns:
            Created class
        """
        name = spec.get('name', 'CustomClass')

        java_class = JavaClass(name=name)

        # Add methods
        for method_name, impl in spec.get('methods', {}).items():
            java_class._methods[method_name] = impl

        cls._classes[name] = java_class
        return java_class

    @classmethod
    def deoptimizeEverything(cls) -> None:
        """Deoptimize all methods (for debugging)."""
        pass

    @classmethod
    def deoptimizeBootImage(cls) -> None:
        """Deoptimize boot image methods."""
        pass

    @classmethod
    def get_classFactory(cls):
        """Get class factory."""
        return cls._class_factory

    @classmethod
    def enumerateLoadedClasses(cls, callbacks: dict) -> None:
        """
        Enumerate loaded classes.
        
        Args:
            callbacks: Dict with 'onMatch' and 'onComplete' callbacks
        """
        on_match = callbacks.get('onMatch', lambda x: None)
        on_complete = callbacks.get('onComplete', lambda: None)

        for class_name in cls._classes:
            on_match(class_name)

        on_complete()

    @classmethod
    def enumerateLoadedClassesSync(cls) -> list[str]:
        """Get list of loaded class names."""
        return list(cls._classes.keys())

    @classmethod
    def enumerateClassLoaders(cls, callbacks: dict) -> None:
        """Enumerate class loaders."""
        on_match = callbacks.get('onMatch', lambda x: None)
        on_complete = callbacks.get('onComplete', lambda: None)
        on_complete()

    @classmethod
    def enumerateClassLoadersSync(cls) -> list:
        """Get list of class loaders."""
        return []

    @classmethod
    def cast(cls, obj: JavaObject, klass: JavaClass) -> JavaObject:
        """Cast object to class."""
        return JavaObject(_class=klass, _handle=obj._handle)

    @classmethod
    def array(cls, element_type: str, elements: list) -> list:
        """Create Java array."""
        return elements

    @classmethod
    def retain(cls, obj: JavaObject) -> JavaObject:
        """Prevent object from being garbage collected."""
        return obj


class Dalvik:
    """
    Dalvik-specific operations.
    
    For older Android versions (< 5.0).
    """

    @classmethod
    def get_available(cls) -> bool:
        return False

    @classmethod
    def perform(cls, fn: Callable) -> None:
        """Run on Dalvik VM."""
        fn()


class ART:
    """
    ART-specific operations.
    
    For Android 5.0+.
    """

    @classmethod
    def get_available(cls) -> bool:
        return Java.get_available()

    @classmethod
    def perform(cls, fn: Callable) -> None:
        """Run on ART VM."""
        Java.perform(fn)
