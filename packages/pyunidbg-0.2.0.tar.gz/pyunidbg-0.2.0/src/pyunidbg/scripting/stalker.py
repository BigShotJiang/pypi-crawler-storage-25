"""
Stalker - Frida-style code tracing.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from .instruction import InstructionInfo
from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class StalkerEventType(Enum):
    """Types of stalker events."""
    CALL = "call"
    RET = "ret"
    EXEC = "exec"
    BLOCK = "block"
    COMPILE = "compile"


@dataclass
class StalkerCallEvent:
    """Event for function call."""
    location: NativePointer
    target: NativePointer
    depth: int


@dataclass
class StalkerRetEvent:
    """Event for function return."""
    location: NativePointer
    target: NativePointer
    depth: int


@dataclass
class StalkerExecEvent:
    """Event for instruction execution."""
    location: NativePointer


@dataclass
class StalkerBlockEvent:
    """Event for basic block execution."""
    begin: NativePointer
    end: NativePointer


@dataclass
class StalkerIterator:
    """Iterator for stalker transforms."""
    _instructions: list[InstructionInfo] = field(default_factory=list)
    _index: int = 0

    def next(self) -> InstructionInfo | None:
        """Get next instruction."""
        if self._index < len(self._instructions):
            insn = self._instructions[self._index]
            self._index += 1
            return insn
        return None

    def keep(self) -> None:
        """Keep the current instruction."""
        pass

    def putCallout(self, callback: Callable) -> None:
        """Insert a callout at current position."""
        pass


class Stalker:
    """
    Frida-compatible Stalker API.
    
    Provides code tracing and instrumentation.
    
    Usage:
        Stalker.set_emulator(emu)
        
        # Follow thread execution
        Stalker.follow(thread_id, {
            'events': {
                'call': True,
                'ret': True,
                'exec': False,
                'block': False
            },
            'onReceive': lambda events: process_events(events),
            'onCallSummary': lambda summary: print(summary)
        })
        
        # Stop following
        Stalker.unfollow(thread_id)
        
        # Flush events
        Stalker.flush()
    """

    _emulator: Emulator | None = None
    _followed_threads: dict[int, dict] = {}
    _events: list[Any] = []
    _transforms: dict[int, Callable] = {}
    _call_probes: dict[int, Callable] = {}
    _trust_threshold: int = -1
    _queue_capacity: int = 16384
    _queue_drain_interval: int = 250

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

    @classmethod
    def _get_emu(cls) -> Emulator:
        """Get emulator."""
        if cls._emulator is None:
            raise RuntimeError("Stalker.set_emulator() must be called first")
        return cls._emulator

    @classmethod
    def get_trust_threshold(cls) -> int:
        """Get trust threshold."""
        return cls._trust_threshold

    @classmethod
    def set_trust_threshold(cls, value: int) -> None:
        """Set trust threshold."""
        cls._trust_threshold = value

    @classmethod
    def get_queue_capacity(cls) -> int:
        """Get queue capacity."""
        return cls._queue_capacity

    @classmethod
    def set_queue_capacity(cls, value: int) -> None:
        """Set queue capacity."""
        cls._queue_capacity = value

    @classmethod
    def get_queue_drain_interval(cls) -> int:
        """Get queue drain interval in ms."""
        return cls._queue_drain_interval

    @classmethod
    def set_queue_drain_interval(cls, value: int) -> None:
        """Set queue drain interval."""
        cls._queue_drain_interval = value

    @classmethod
    def exclude(cls, range_: dict) -> None:
        """
        Exclude a memory range from stalking.
        
        Args:
            range_: Dict with 'base' and 'size' keys
        """
        # Store exclusion
        pass

    @classmethod
    def follow(cls, thread_id: int | None = None,
               options: dict | None = None) -> None:
        """
        Start following a thread.
        
        Args:
            thread_id: Thread to follow (None for current)
            options: Stalker options:
                - events: Dict of event types to capture
                - onReceive: Callback for batched events
                - onCallSummary: Callback for call summary
                - transform: Transform callback for rewriting
        """
        if thread_id is None:
            thread_id = 1  # Main thread in emulator

        opts = options or {}
        cls._followed_threads[thread_id] = opts

        # Install tracing hooks
        cls._install_trace_hooks(thread_id, opts)

        logger.debug(f"Stalker following thread {thread_id}")

    @classmethod
    def _install_trace_hooks(cls, thread_id: int, options: dict) -> None:
        """Install tracing hooks in emulator."""
        emu = cls._get_emu()
        events_config = options.get('events', {})
        on_receive = options.get('onReceive')
        on_call_summary = options.get('onCallSummary')
        transform = options.get('transform')

        call_depth = [0]
        call_summary = {}

        def code_hook(uc, address, size, user_data):
            """Hook for instruction tracing."""
            # Exec event
            if events_config.get('exec'):
                cls._events.append(StalkerExecEvent(
                    location=NativePointer(address)
                ))

            # Check for call/ret
            try:
                from .instruction import Instruction
                insn = Instruction.parse(address)
                if insn:
                    mnemonic = insn.mnemonic.lower()

                    # Call detection
                    if mnemonic in ('bl', 'blr', 'blx'):
                        if events_config.get('call'):
                            # Get target (simplified)
                            target = emu.reg_read('lr')
                            cls._events.append(StalkerCallEvent(
                                location=NativePointer(address),
                                target=NativePointer(target),
                                depth=call_depth[0]
                            ))
                        call_depth[0] += 1

                        # Call summary
                        if on_call_summary:
                            key = address
                            call_summary[key] = call_summary.get(key, 0) + 1

                    # Return detection
                    elif mnemonic in ('ret', 'bx'):
                        if events_config.get('ret'):
                            lr = emu.reg_read('lr')
                            cls._events.append(StalkerRetEvent(
                                location=NativePointer(address),
                                target=NativePointer(lr),
                                depth=call_depth[0]
                            ))
                        call_depth[0] = max(0, call_depth[0] - 1)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

            # Drain events if needed
            if len(cls._events) >= cls._queue_capacity:
                cls._drain_events(on_receive, on_call_summary, call_summary)

        # Add hook
        try:
            emu.uc.hook_add(
                2,  # UC_HOOK_CODE
                code_hook
            )
        except Exception as e:
            logger.error(f"Failed to install stalker hook: {e}")

    @classmethod
    def _drain_events(cls, on_receive: Callable | None,
                      on_call_summary: Callable | None,
                      call_summary: dict) -> None:
        """Drain and process queued events."""
        if on_receive and cls._events:
            try:
                on_receive(cls._events.copy())
            except Exception as e:
                logger.error(f"Stalker onReceive error: {e}")

        if on_call_summary and call_summary:
            try:
                on_call_summary(call_summary.copy())
            except Exception as e:
                logger.error(f"Stalker onCallSummary error: {e}")

        cls._events.clear()

    @classmethod
    def unfollow(cls, thread_id: int | None = None) -> None:
        """
        Stop following a thread.
        
        Args:
            thread_id: Thread to unfollow (None for current)
        """
        if thread_id is None:
            thread_id = 1

        if thread_id in cls._followed_threads:
            # Get callbacks for final drain
            opts = cls._followed_threads[thread_id]
            on_receive = opts.get('onReceive')
            on_call_summary = opts.get('onCallSummary')

            # Final drain
            if cls._events:
                cls._drain_events(on_receive, on_call_summary, {})

            del cls._followed_threads[thread_id]

        logger.debug(f"Stalker unfollowed thread {thread_id}")

    @classmethod
    def flush(cls) -> None:
        """Flush queued events."""
        for thread_id, opts in cls._followed_threads.items():
            on_receive = opts.get('onReceive')
            on_call_summary = opts.get('onCallSummary')
            cls._drain_events(on_receive, on_call_summary, {})

    @classmethod
    def garbageCollect(cls) -> None:
        """Run garbage collection on stalker state."""
        pass

    @classmethod
    def invalidate(cls, address: int | NativePointer) -> None:
        """Invalidate cached code at address."""
        pass

    @classmethod
    def addCallProbe(cls, address: int | NativePointer,
                     callback: Callable) -> int:
        """
        Add a call probe.
        
        Args:
            address: Function address to probe
            callback: Callback function
            
        Returns:
            Probe ID
        """
        addr = address.address if isinstance(address, NativePointer) else address
        probe_id = len(cls._call_probes)
        cls._call_probes[probe_id] = {
            'address': addr,
            'callback': callback
        }
        return probe_id

    @classmethod
    def removeCallProbe(cls, probe_id: int) -> None:
        """Remove a call probe."""
        if probe_id in cls._call_probes:
            del cls._call_probes[probe_id]

    @classmethod
    def parse(cls, address: int | NativePointer,
              options: dict | None = None) -> dict:
        """
        Parse code at address.
        
        Returns:
            Dict with parsing results
        """
        from .instruction import Instruction

        addr = address.address if isinstance(address, NativePointer) else address

        results = {
            'address': NativePointer(addr),
            'size': 0,
            'blocks': []
        }

        # Parse a basic block
        instructions = Instruction.parseN(addr, 100)

        if instructions:
            block = {
                'begin': NativePointer(addr),
                'end': instructions[-1].next,
                'instructions': instructions
            }
            results['blocks'].append(block)
            results['size'] = instructions[-1].next.address - addr

        return results
