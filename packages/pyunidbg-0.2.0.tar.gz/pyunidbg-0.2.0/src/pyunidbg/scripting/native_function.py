"""
NativeFunction - Frida-style native function calling.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)


class ABI(Enum):
    """Calling conventions."""
    DEFAULT = "default"
    SYSV = "sysv"
    STDCALL = "stdcall"
    THISCALL = "thiscall"
    FASTCALL = "fastcall"
    WIN64 = "win64"
    UNIX64 = "unix64"
    VFP = "vfp"


@dataclass
class NativeType:
    """Native type descriptor."""
    name: str
    size: int

    @classmethod
    def void(cls) -> NativeType:
        return cls('void', 0)

    @classmethod
    def pointer(cls) -> NativeType:
        return cls('pointer', 8)

    @classmethod
    def int_(cls) -> NativeType:
        return cls('int', 4)

    @classmethod
    def uint(cls) -> NativeType:
        return cls('uint', 4)

    @classmethod
    def long_(cls) -> NativeType:
        return cls('long', 8)

    @classmethod
    def ulong(cls) -> NativeType:
        return cls('ulong', 8)

    @classmethod
    def int8(cls) -> NativeType:
        return cls('int8', 1)

    @classmethod
    def uint8(cls) -> NativeType:
        return cls('uint8', 1)

    @classmethod
    def int16(cls) -> NativeType:
        return cls('int16', 2)

    @classmethod
    def uint16(cls) -> NativeType:
        return cls('uint16', 2)

    @classmethod
    def int32(cls) -> NativeType:
        return cls('int32', 4)

    @classmethod
    def uint32(cls) -> NativeType:
        return cls('uint32', 4)

    @classmethod
    def int64(cls) -> NativeType:
        return cls('int64', 8)

    @classmethod
    def uint64(cls) -> NativeType:
        return cls('uint64', 8)

    @classmethod
    def float_(cls) -> NativeType:
        return cls('float', 4)

    @classmethod
    def double(cls) -> NativeType:
        return cls('double', 8)

    @classmethod
    def bool_(cls) -> NativeType:
        return cls('bool', 1)

    @classmethod
    def char(cls) -> NativeType:
        return cls('char', 1)

    @classmethod
    def uchar(cls) -> NativeType:
        return cls('uchar', 1)

    @classmethod
    def size_t(cls) -> NativeType:
        return cls('size_t', 8)


class NativeFunction:
    """
    Frida-compatible NativeFunction.
    
    Allows calling native functions with proper argument passing and return handling.
    
    Usage:
        # Create function wrapper
        open_func = NativeFunction(
            open_addr,
            'int',           # return type
            ['pointer', 'int', 'int']  # argument types
        )
        
        # Call it
        fd = open_func(path_ptr, O_RDONLY, 0)
        
        # With ABI specified
        func = NativeFunction(addr, 'int', ['pointer'], abi='sysv')
    """

    _emulator: Emulator | None = None

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

    def __init__(self, address: int | NativePointer,
                 return_type: str | NativeType,
                 arg_types: list[str | NativeType],
                 abi: str | ABI = ABI.DEFAULT):
        """
        Create a NativeFunction wrapper.
        
        Args:
            address: Function address
            return_type: Return type name or NativeType
            arg_types: List of argument type names or NativeTypes
            abi: Calling convention
        """
        if isinstance(address, NativePointer):
            self.address = address
        else:
            self.address = NativePointer(address)

        self.return_type = return_type if isinstance(return_type, str) else return_type.name
        self.arg_types = [t if isinstance(t, str) else t.name for t in arg_types]
        self.abi = abi if isinstance(abi, ABI) else ABI(abi)

    def _get_emu(self) -> Emulator:
        """Get emulator."""
        if self._emulator is None:
            raise RuntimeError("NativeFunction.set_emulator() must be called first")
        return self._emulator

    def __call__(self, *args) -> int | float | NativePointer:
        """
        Call the native function.
        
        Args:
            *args: Function arguments
            
        Returns:
            Function return value
        """
        emu = self._get_emu()

        # Convert arguments to appropriate values
        converted_args = []
        for i, (arg, arg_type) in enumerate(zip(args, self.arg_types)):
            if isinstance(arg, NativePointer):
                converted_args.append(arg.address)
            elif isinstance(arg, str):
                # Allocate string and pass pointer
                from .memory import Memory
                ptr = Memory.allocUtf8String(arg)
                converted_args.append(ptr.address)
            elif isinstance(arg, bytes):
                from .memory import Memory
                ptr = Memory.alloc(len(arg))
                Memory.writeByteArray(ptr, arg)
                converted_args.append(ptr.address)
            else:
                converted_args.append(arg)

        # Set up arguments in registers and on stack per ABI
        if emu.is_64bit:
            for i, arg in enumerate(converted_args[:8]):
                emu.reg_write(f'x{i}', arg)
            if len(converted_args) > 8:
                sp = emu.reg_read('sp')
                stack_args = converted_args[8:]
                sp -= len(stack_args) * 8
                sp &= ~0xF  # 16-byte align per AAPCS64
                emu.reg_write('sp', sp)
                for i, arg in enumerate(stack_args):
                    emu.mem_write(sp + i * 8, (arg & 0xFFFFFFFFFFFFFFFF).to_bytes(8, 'little'))
        else:
            for i, arg in enumerate(converted_args[:4]):
                emu.reg_write(f'r{i}', arg)
            if len(converted_args) > 4:
                sp = emu.reg_read('sp')
                stack_args = converted_args[4:]
                sp -= len(stack_args) * 4
                sp &= ~0x7  # 8-byte align per AAPCS
                emu.reg_write('sp', sp)
                for i, arg in enumerate(stack_args):
                    emu.mem_write(sp + i * 4, (arg & 0xFFFFFFFF).to_bytes(4, 'little'))

        # Set return address to a sentinel
        return_sentinel = 0xDEADBEEF
        emu.reg_write('lr', return_sentinel)

        # Call the function
        try:
            emu.emu_start(self.address.address, return_sentinel)
        except Exception:
            # Check if we hit the return sentinel
            pc = emu.reg_read('pc')
            if pc != return_sentinel:
                raise

        # Get return value
        if emu.is_64bit:
            result = emu.reg_read('x0')
        else:
            result = emu.reg_read('r0')

        # Convert based on return type
        if self.return_type in ('void',):
            return None
        elif self.return_type in ('pointer', 'char*', 'void*'):
            return NativePointer(result)
        elif self.return_type in ('float',):
            import struct
            return struct.unpack('<f', struct.pack('<I', result & 0xFFFFFFFF))[0]
        elif self.return_type in ('double',):
            import struct
            return struct.unpack('<d', struct.pack('<Q', result))[0]
        else:
            return result

    def apply(self, args: list, this: NativePointer | None = None) -> Any:
        """
        Call with argument list (Frida-compatible).
        
        Args:
            args: List of arguments
            this: Optional 'this' pointer for methods
            
        Returns:
            Return value
        """
        if this is not None:
            return self(this, *args)
        return self(*args)

    def call(self, *args) -> Any:
        """Alias for __call__."""
        return self(*args)


class NativeCallback:
    """
    Frida-compatible NativeCallback.
    
    Creates a native function pointer that calls a Python function.
    
    Usage:
        # Create callback
        callback = NativeCallback(
            my_handler,
            'int',
            ['pointer', 'int']
        )
        
        # Get pointer to pass to native code
        callback_ptr = callback.address
    """

    _emulator: Emulator | None = None
    _callbacks: dict[int, NativeCallback] = {}
    _next_callback_addr: int = 0x70000000

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

    def __init__(self, callback: Callable,
                 return_type: str | NativeType,
                 arg_types: list[str | NativeType],
                 abi: str | ABI = ABI.DEFAULT):
        """
        Create a NativeCallback.
        
        Args:
            callback: Python function to call
            return_type: Return type
            arg_types: Argument types
            abi: Calling convention
        """
        self.callback = callback
        self.return_type = return_type if isinstance(return_type, str) else return_type.name
        self.arg_types = [t if isinstance(t, str) else t.name for t in arg_types]
        self.abi = abi if isinstance(abi, ABI) else ABI(abi)

        # Allocate address for this callback
        self._address = NativeCallback._next_callback_addr
        NativeCallback._next_callback_addr += 0x1000

        # Register callback
        NativeCallback._callbacks[self._address] = self

        # Install hook in emulator
        self._install()

    @property
    def address(self) -> NativePointer:
        """Get the callback's address."""
        return NativePointer(self._address)

    def _install(self) -> None:
        """Install callback hook in emulator."""
        if self._emulator is None:
            return

        emu = self._emulator

        def callback_hook(uc, address, size, user_data):
            """Handle callback invocation."""
            # Get arguments from registers
            args = []
            if emu.is_64bit:
                for i in range(min(8, len(self.arg_types))):
                    reg_val = emu.reg_read(f'x{i}')
                    args.append(NativePointer(reg_val))
            else:
                for i in range(min(4, len(self.arg_types))):
                    reg_val = emu.reg_read(f'r{i}')
                    args.append(NativePointer(reg_val))

            # Call Python callback
            try:
                result = self.callback(*args)

                # Set return value
                if result is not None:
                    ret_val = result.address if isinstance(result, NativePointer) else result
                    if emu.is_64bit:
                        emu.reg_write('x0', ret_val)
                    else:
                        emu.reg_write('r0', ret_val)

                # Return to caller
                lr = emu.reg_read('lr')
                emu.reg_write('pc', lr)

            except Exception as e:
                import logging
                logging.error(f"Callback error: {e}")

        # Map memory for callback if needed
        try:
            emu.uc.mem_map(self._address, 0x1000)
            # Write RET instruction
            if emu.is_64bit:
                emu.mem_write(self._address, b'\xc0\x03\x5f\xd6')  # RET
            else:
                emu.mem_write(self._address, b'\x1e\xff\x2f\xe1')  # BX LR
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Add hook
        try:
            emu.uc.hook_add(
                2,  # UC_HOOK_CODE
                callback_hook,
                begin=self._address,
                end=self._address + 4
            )
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)


class SystemFunction(NativeFunction):
    """
    NativeFunction that handles system call semantics.
    
    Similar to NativeFunction but handles errno and other system-level concerns.
    """

    def __call__(self, *args) -> int | NativePointer:
        """Call system function."""
        result = super().__call__(*args)

        # Check for error (-1 typically indicates error)
        if isinstance(result, int) and result == -1:
            # Could get errno here
            pass

        return result
