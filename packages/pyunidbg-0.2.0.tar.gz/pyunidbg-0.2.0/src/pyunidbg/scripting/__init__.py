"""
Frida-style scripting for PyUniDbg.

Provides both Python and JavaScript scripting APIs with Frida-compatible syntax.

Python API:
    from pyunidbg.scripting import Interceptor, Memory, Module, Process
    
    # Hook a function
    Interceptor.attach(
        Module.findExportByName("libc.so", "open"),
        on_enter=lambda args: print(f"open({Memory.readUtf8String(args[0])})"),
        on_leave=lambda retval: print(f"=> {retval}")
    )

JavaScript API:
    script = Script(emulator, '''
        Interceptor.attach(Module.findExportByName("libc.so", "open"), {
            onEnter: function(args) {
                console.log("open(" + Memory.readUtf8String(args[0]) + ")");
            },
            onLeave: function(retval) {
                console.log("=> " + retval);
            }
        });
    ''')
    script.load()
"""

from .api_resolver import ApiResolver
from .instruction import Instruction
from .interceptor import Interceptor, InvocationArgs, InvocationContext, InvocationRetval
from .java_bridge import Java  # Android Java bridge
from .memory import Memory, MemoryProtection, MemoryRange
from .module import Module, ModuleExport, ModuleImport, ModuleSymbol
from .native_function import NativeCallback, NativeFunction, SystemFunction
from .native_pointer import NativePointer
from .process import Process, ThreadContext
from .script import Script, ScriptRuntime
from .script_engine import ScriptEngine
from .stalker import Stalker

__all__ = [
    # Core
    "ScriptEngine",
    "Script",
    "ScriptRuntime",

    # Interceptor
    "Interceptor",
    "InvocationContext",
    "InvocationArgs",
    "InvocationRetval",

    # Memory
    "Memory",
    "MemoryRange",
    "MemoryProtection",

    # Module
    "Module",
    "ModuleExport",
    "ModuleImport",
    "ModuleSymbol",

    # Process
    "Process",
    "ThreadContext",

    # Native
    "NativePointer",
    "NativeFunction",
    "NativeCallback",
    "SystemFunction",

    # Utilities
    "ApiResolver",
    "Instruction",
    "Stalker",

    # Java
    "Java",
]
