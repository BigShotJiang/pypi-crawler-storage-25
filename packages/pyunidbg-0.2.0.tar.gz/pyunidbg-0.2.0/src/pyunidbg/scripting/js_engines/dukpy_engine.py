"""
Dukpy engine wrapper.

Uses the 'dukpy' Python package (Duktape JavaScript engine).
Install with: pip install dukpy
"""

import json
import logging
from typing import Any

from .base import JSEngine, JSEngineError

logger = logging.getLogger(__name__)

# Try to import dukpy at module level
try:
    import dukpy as _dukpy
    DUKPY_AVAILABLE = True
except ImportError:
    _dukpy = None
    DUKPY_AVAILABLE = False


class DukpyEngine(JSEngine):
    """Dukpy-based JavaScript engine."""

    def __init__(self):
        """Initialize Dukpy engine."""
        self._dukpy = _dukpy
        self._interpreter: Any | None = None
        self._globals: dict[str, Any] = {}

        if DUKPY_AVAILABLE:
            self._interpreter = self._dukpy.JSInterpreter()
            self._setup_builtins()

    def is_available(self) -> bool:
        """Check if Dukpy is available."""
        return DUKPY_AVAILABLE and self._interpreter is not None

    def _check_available(self) -> None:
        """Raise error if not available."""
        if not self.is_available():
            raise JSEngineError("Dukpy not installed. Install with: pip install dukpy")

    def _setup_builtins(self) -> None:
        """Set up built-in functions."""
        # Dukpy has limited built-in support
        # We'll inject console via Python callbacks
        self._interpreter.evaljs("""
            var console = {
                log: function() {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        args.push(String(arguments[i]));
                    }
                    call_python('console_log', [args.join(' ')]);
                },
                warn: function() {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        args.push(String(arguments[i]));
                    }
                    call_python('console_warn', [args.join(' ')]);
                },
                error: function() {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        args.push(String(arguments[i]));
                    }
                    call_python('console_error', [args.join(' ')]);
                }
            };
        """)

    def execute(self, source: str, context: dict[str, Any] = None) -> Any:
        """Execute JavaScript code."""
        self._check_available()
        context = context or {}

        # Store context for callbacks
        self._globals.update(context)

        # Inject Frida API wrappers
        wrapper_code = self._generate_api_wrappers(context)

        full_source = wrapper_code + '\n' + source

        try:
            result = self._interpreter.evaljs(full_source)
            return result
        except Exception as e:
            raise JSEngineError(f"JavaScript error: {e}")

    def _generate_api_wrappers(self, context: dict[str, Any]) -> str:
        """Generate JavaScript wrappers for Python APIs."""
        wrappers = []

        for name, obj in context.items():
            if name.startswith('_'):
                continue

            if hasattr(obj, '__dict__') or hasattr(obj, '__class__'):
                # Wrap as object with methods
                methods = []
                for attr in dir(obj):
                    if not attr.startswith('_') and callable(getattr(obj, attr, None)):
                        methods.append(attr)

                method_strs = []
                for method in methods:
                    method_strs.append(
                        f'{method}: function() {{ '
                        f'return call_python("{name}.{method}", '
                        f'Array.prototype.slice.call(arguments)); }}'
                    )

                if method_strs:
                    wrappers.append(f"var {name} = {{ {', '.join(method_strs)} }};")
            elif callable(obj):
                wrappers.append(
                    f'function {name}() {{ '
                    f'return call_python("{name}", '
                    f'Array.prototype.slice.call(arguments)); }}'
                )

        return '\n'.join(wrappers)

    def call(self, func_name: str, *args) -> Any:
        """Call a JavaScript function."""
        self._check_available()
        try:
            # Serialize arguments
            args_json = json.dumps(list(args))
            code = f"{func_name}.apply(null, {args_json})"
            return self._interpreter.evaljs(code)
        except Exception as e:
            raise JSEngineError(f"Call error: {e}")

    def set_global(self, name: str, value: Any) -> None:
        """Set a global variable."""
        self._check_available()
        self._globals[name] = value

        if isinstance(value, (int, float, str, bool, type(None))):
            value_json = json.dumps(value)
            self._interpreter.evaljs(f"var {name} = {value_json};")

    def get_global(self, name: str) -> Any:
        """Get a global variable."""
        self._check_available()
        if name in self._globals:
            return self._globals[name]

        try:
            return self._interpreter.evaljs(name)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return None

    def _handle_python_call(self, name: str, args: list) -> Any:
        """Handle a call from JavaScript to Python."""
        parts = name.split('.')

        if len(parts) == 1:
            # Direct function call
            func = self._globals.get(name)
            if callable(func):
                return func(*args)
        elif len(parts) == 2:
            # Object method call
            obj = self._globals.get(parts[0])
            if obj:
                method = getattr(obj, parts[1], None)
                if callable(method):
                    return method(*args)

        # Special console handling
        if name == 'console_log':
            print(f"[JS] {args[0] if args else ''}")
            return None
        elif name == 'console_warn':
            print(f"[JS WARN] {args[0] if args else ''}")
            return None
        elif name == 'console_error':
            print(f"[JS ERROR] {args[0] if args else ''}")
            return None

        raise JSEngineError(f"Unknown function: {name}")
