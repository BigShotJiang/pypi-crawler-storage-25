"""
Base JavaScript engine interface.
"""

from abc import ABC, abstractmethod
from typing import Any

from pyunidbg.errors import ScriptingError


class JSEngine(ABC):
    """Base class for JavaScript engines."""

    def is_available(self) -> bool:
        """
        Check if this engine is available (dependency installed).
        
        Returns:
            True if the engine can be used
        """
        return False  # Override in subclass

    def evaluate(self, source: str) -> Any:
        """
        Evaluate JavaScript expression and return result.
        
        Simple convenience wrapper around execute().
        """
        return self.execute(source, {})

    @abstractmethod
    def execute(self, source: str, context: dict[str, Any]) -> Any:
        """
        Execute JavaScript code.
        
        Args:
            source: JavaScript source code
            context: Global context objects
            
        Returns:
            Execution result
        """
        pass

    @abstractmethod
    def call(self, func_name: str, *args) -> Any:
        """
        Call a JavaScript function.
        
        Args:
            func_name: Function name
            *args: Arguments
            
        Returns:
            Function result
        """
        pass

    @abstractmethod
    def set_global(self, name: str, value: Any) -> None:
        """Set a global variable."""
        pass

    @abstractmethod
    def get_global(self, name: str) -> Any:
        """Get a global variable."""
        pass


class JSEngineError(ScriptingError):
    """Error from JavaScript execution."""
