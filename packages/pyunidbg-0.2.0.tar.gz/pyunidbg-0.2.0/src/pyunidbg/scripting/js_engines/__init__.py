"""
JavaScript engine wrappers for PyUniDbg scripting.

Supports multiple JS engines:
- QuickJS: Fast, embedded ES2020 engine
- Dukpy: Duktape-based, stable
- MiniRacer: V8-based, full compatibility
"""

from .base import JSEngine
from .dukpy_engine import DukpyEngine
from .miniracer_engine import MiniRacerEngine
from .quickjs_engine import QuickJSEngine

__all__ = [
    'JSEngine',
    'QuickJSEngine',
    'DukpyEngine',
    'MiniRacerEngine',
]
