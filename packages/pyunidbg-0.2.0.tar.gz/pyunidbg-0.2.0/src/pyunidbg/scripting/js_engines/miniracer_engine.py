"""
Mini-Racer engine wrapper.

Uses the 'py_mini_racer' Python package (V8 JavaScript engine).
Install with: pip install py_mini_racer
"""

import json
import logging
from typing import Any

from .base import JSEngine, JSEngineError

logger = logging.getLogger(__name__)

# Try to import py_mini_racer at module level
try:
    from py_mini_racer import MiniRacer as _MiniRacer
    MINIRACER_AVAILABLE = True
except ImportError:
    _MiniRacer = None
    MINIRACER_AVAILABLE = False


class MiniRacerEngine(JSEngine):
    """py_mini_racer-based JavaScript engine (V8)."""

    def __init__(self):
        """Initialize MiniRacer engine."""
        self._ctx: Any | None = None
        self._callbacks: dict[str, Any] = {}

        if MINIRACER_AVAILABLE:
            self._ctx = _MiniRacer()
            self._setup_builtins()

    def is_available(self) -> bool:
        """Check if MiniRacer is available."""
        return MINIRACER_AVAILABLE and self._ctx is not None

    def _check_available(self) -> None:
        """Raise error if not available."""
        if not self.is_available():
            raise JSEngineError("py_mini_racer not installed. Install with: pip install py_mini_racer")

    def _setup_builtins(self) -> None:
        """Set up built-in functions."""
        # MiniRacer has console.log built-in
        self._ctx.eval("""
            // Ensure console exists
            if (typeof console === 'undefined') {
                var console = {
                    log: function() { print(Array.prototype.join.call(arguments, ' ')); },
                    warn: function() { print('[WARN] ' + Array.prototype.join.call(arguments, ' ')); },
                    error: function() { print('[ERROR] ' + Array.prototype.join.call(arguments, ' ')); },
                    info: function() { print(Array.prototype.join.call(arguments, ' ')); }
                };
            }
        """)

    def execute(self, source: str, context: dict[str, Any] = None) -> Any:
        """Execute JavaScript code."""
        self._check_available()
        context = context or {}

        # Store callbacks
        self._callbacks.update(context)

        # Generate API wrappers
        wrapper_code = self._generate_wrappers(context)

        full_source = wrapper_code + '\n' + source

        try:
            result = self._ctx.eval(full_source)
            return result
        except Exception as e:
            raise JSEngineError(f"JavaScript error: {e}")

    def _generate_wrappers(self, context: dict[str, Any]) -> str:
        """Generate JavaScript wrappers for Python objects."""
        wrappers = []

        for name, obj in context.items():
            if name.startswith('_'):
                continue

            # For callable objects/classes, create wrapper
            if hasattr(obj, '__dict__') or hasattr(obj, '__class__'):
                wrapper = self._create_object_wrapper(name, obj)
                if wrapper:
                    wrappers.append(wrapper)
            elif callable(obj):
                # Simple function
                wrappers.append(f"var {name} = function() {{ /* Python callback */ }};")

        return '\n'.join(wrappers)

    def _create_object_wrapper(self, name: str, obj: Any) -> str:
        """Create a JavaScript wrapper for a Python object."""
        methods = []

        for attr in dir(obj):
            if attr.startswith('_'):
                continue

            value = getattr(obj, attr, None)
            if callable(value):
                methods.append(f'{attr}: function() {{ /* {name}.{attr}() */ }}')

        if methods:
            return f"var {name} = {{ {', '.join(methods)} }};"
        return ""

    def call(self, func_name: str, *args) -> Any:
        """Call a JavaScript function."""
        self._check_available()
        try:
            return self._ctx.call(func_name, *args)
        except Exception as e:
            raise JSEngineError(f"Call error: {e}")

    def set_global(self, name: str, value: Any) -> None:
        """Set a global variable."""
        self._check_available()
        if isinstance(value, (int, float, str, bool, type(None), list, dict)):
            value_json = json.dumps(value)
            self._ctx.eval(f"var {name} = {value_json};")
        else:
            self._callbacks[name] = value

    def get_global(self, name: str) -> Any:
        """Get a global variable."""
        self._check_available()
        try:
            return self._ctx.eval(name)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return None
