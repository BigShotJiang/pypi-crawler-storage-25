"""
QuickJS engine wrapper.

Uses the 'quickjs' Python package.
Install with: pip install quickjs
"""

import logging
from typing import Any

from .base import JSEngine, JSEngineError

logger = logging.getLogger(__name__)

# Try to import quickjs at module level
try:
    import quickjs as _quickjs
    QUICKJS_AVAILABLE = True
except ImportError:
    _quickjs = None
    QUICKJS_AVAILABLE = False


class QuickJSEngine(JSEngine):
    """QuickJS-based JavaScript engine."""

    def __init__(self):
        """Initialize QuickJS engine."""
        self._quickjs = _quickjs
        self._context: Any | None = None

        if QUICKJS_AVAILABLE:
            self._context = self._quickjs.Context()
            self._setup_builtins()

    def is_available(self) -> bool:
        """Check if QuickJS is available."""
        return QUICKJS_AVAILABLE and self._context is not None

    def _check_available(self) -> None:
        """Raise error if not available."""
        if not self.is_available():
            raise JSEngineError("QuickJS not installed. Install with: pip install quickjs")

    def _setup_builtins(self) -> None:
        """Set up built-in functions and objects."""
        # Add console
        self._context.eval("""
            var console = {
                log: function() {
                    var args = Array.prototype.slice.call(arguments);
                    __py_console_log(args.join(' '));
                },
                warn: function() {
                    var args = Array.prototype.slice.call(arguments);
                    __py_console_warn(args.join(' '));
                },
                error: function() {
                    var args = Array.prototype.slice.call(arguments);
                    __py_console_error(args.join(' '));
                }
            };
        """)

        # Register Python callbacks
        self._context.set('__py_console_log', lambda msg: print(f"[JS] {msg}"))
        self._context.set('__py_console_warn', lambda msg: print(f"[JS WARN] {msg}"))
        self._context.set('__py_console_error', lambda msg: print(f"[JS ERROR] {msg}"))

    def execute(self, source: str, context: dict[str, Any] = None) -> Any:
        """Execute JavaScript code."""
        self._check_available()
        context = context or {}

        # Set context objects
        for name, value in context.items():
            self._set_context_object(name, value)

        try:
            result = self._context.eval(source)
            return self._convert_result(result)
        except Exception as e:
            raise JSEngineError(f"JavaScript error: {e}")

    def _set_context_object(self, name: str, obj: Any) -> None:
        """Set a context object, wrapping Python objects appropriately."""
        if callable(obj):
            self._context.set(name, obj)
        elif hasattr(obj, '__dict__'):
            # Wrap class with methods
            self._wrap_class(name, obj)
        else:
            self._context.set(name, obj)

    def _wrap_class(self, name: str, cls: Any) -> None:
        """Wrap a Python class for JavaScript access."""
        # Create JavaScript object with methods
        methods = {}
        for attr_name in dir(cls):
            if not attr_name.startswith('_'):
                attr = getattr(cls, attr_name)
                if callable(attr):
                    methods[attr_name] = attr

        # Register each method
        for method_name, method in methods.items():
            self._context.set(f'__{name}_{method_name}', method)

        # Create wrapper object
        method_strs = []
        for method_name in methods:
            method_strs.append(
                f'{method_name}: function() {{ '
                f'return __{name}_{method_name}.apply(null, arguments); }}'
            )

        wrapper_code = f"var {name} = {{ {', '.join(method_strs)} }};"
        self._context.eval(wrapper_code)

    def _convert_result(self, result: Any) -> Any:
        """Convert JavaScript result to Python."""
        # QuickJS handles most conversions automatically
        return result

    def call(self, func_name: str, *args) -> Any:
        """Call a JavaScript function."""
        self._check_available()
        try:
            func = self._context.get(func_name)
            if func is not None:
                return func(*args)
            raise JSEngineError(f"Function not found: {func_name}")
        except Exception as e:
            raise JSEngineError(f"Call error: {e}")

    def set_global(self, name: str, value: Any) -> None:
        """Set a global variable."""
        self._check_available()
        self._context.set(name, value)

    def get_global(self, name: str) -> Any:
        """Get a global variable."""
        self._check_available()
        return self._context.get(name)
