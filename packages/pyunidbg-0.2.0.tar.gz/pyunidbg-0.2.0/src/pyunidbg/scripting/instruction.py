"""
Instruction - Frida-style instruction parsing.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)


@dataclass
class InstructionInfo:
    """Information about a parsed instruction."""
    address: NativePointer
    next: NativePointer
    size: int
    mnemonic: str
    opStr: str
    operands: list[dict]
    regsRead: list[str]
    regsWritten: list[str]
    groups: list[str]

    def toString(self) -> str:
        """Get string representation."""
        if self.opStr:
            return f"{self.mnemonic} {self.opStr}"
        return self.mnemonic

    def __str__(self) -> str:
        return f"{self.address}: {self.toString()}"


class Instruction:
    """
    Frida-compatible Instruction API.
    
    Provides instruction parsing and analysis.
    
    Usage:
        # Parse single instruction
        insn = Instruction.parse(ptr(0x12345678))
        print(f"{insn.mnemonic} {insn.opStr}")
        
        # Parse multiple instructions
        for insn in Instruction.parseN(ptr(0x12345678), 10):
            print(insn)
    """

    _emulator: Emulator | None = None
    _capstone = None

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator
        cls._init_capstone()

    @classmethod
    def _init_capstone(cls) -> None:
        """Initialize Capstone disassembler."""
        try:
            import capstone

            if cls._emulator.is_64bit:
                cls._capstone = capstone.Cs(capstone.CS_ARCH_ARM64, capstone.CS_MODE_ARM)
            else:
                cls._capstone = capstone.Cs(capstone.CS_ARCH_ARM, capstone.CS_MODE_ARM)

            cls._capstone.detail = True
        except ImportError:
            cls._capstone = None

    @classmethod
    def parse(cls, address: int | NativePointer) -> InstructionInfo | None:
        """
        Parse a single instruction.
        
        Args:
            address: Address to parse
            
        Returns:
            InstructionInfo or None if parsing failed
        """
        addr = address.address if isinstance(address, NativePointer) else address

        if cls._emulator is None:
            raise RuntimeError("Instruction.set_emulator() must be called first")

        # Read instruction bytes
        emu = cls._emulator
        if emu.is_64bit:
            size = 4  # ARM64 instructions are 4 bytes
        else:
            size = 4  # ARM mode (Thumb would be 2 or 4)

        try:
            data = emu.mem_read(addr, size)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return None

        # Use Capstone if available
        if cls._capstone:
            try:
                insns = list(cls._capstone.disasm(bytes(data), addr, count=1))
                if insns:
                    insn = insns[0]

                    # Extract operand details
                    operands = []
                    regs_read = []
                    regs_written = []
                    groups = []

                    if insn.detail:
                        regs_read = [insn.reg_name(r) for r in insn.regs_read]
                        regs_written = [insn.reg_name(r) for r in insn.regs_write]
                        groups = [insn.group_name(g) for g in insn.groups]

                        for op in insn.operands:
                            op_info = {'type': str(op.type)}
                            operands.append(op_info)

                    return InstructionInfo(
                        address=NativePointer(insn.address),
                        next=NativePointer(insn.address + insn.size),
                        size=insn.size,
                        mnemonic=insn.mnemonic,
                        opStr=insn.op_str,
                        operands=operands,
                        regsRead=regs_read,
                        regsWritten=regs_written,
                        groups=groups
                    )
            except Exception:
                pass

        # Fallback: return raw bytes as hex
        hex_data = ' '.join(f'{b:02x}' for b in data)
        return InstructionInfo(
            address=NativePointer(addr),
            next=NativePointer(addr + size),
            size=size,
            mnemonic='db',
            opStr=hex_data,
            operands=[],
            regsRead=[],
            regsWritten=[],
            groups=[]
        )

    @classmethod
    def parseN(cls, address: int | NativePointer,
               count: int) -> list[InstructionInfo]:
        """
        Parse multiple instructions.
        
        Args:
            address: Start address
            count: Number of instructions to parse
            
        Returns:
            List of InstructionInfo
        """
        results = []
        addr = address.address if isinstance(address, NativePointer) else address

        for _ in range(count):
            insn = cls.parse(addr)
            if insn is None:
                break
            results.append(insn)
            addr = insn.next.address

        return results

    @classmethod
    def parseUntil(cls, address: int | NativePointer,
                   predicate) -> list[InstructionInfo]:
        """
        Parse instructions until predicate returns True.
        
        Args:
            address: Start address
            predicate: Function taking InstructionInfo, returns True to stop
            
        Returns:
            List of parsed instructions
        """
        results = []
        addr = address.address if isinstance(address, NativePointer) else address

        while True:
            insn = cls.parse(addr)
            if insn is None:
                break
            results.append(insn)
            if predicate(insn):
                break
            addr = insn.next.address

            # Safety limit
            if len(results) > 10000:
                break

        return results


class Arm64Writer:
    """
    ARM64 instruction writer.
    
    Generates ARM64 machine code.
    """

    def __init__(self, address: int | NativePointer):
        """Create writer at address."""
        self.address = address.address if isinstance(address, NativePointer) else address
        self.code = bytearray()
        self.offset = 0

    def putNop(self) -> None:
        """Write NOP instruction."""
        self.code.extend(b'\x1f\x20\x03\xd5')
        self.offset += 4

    def putRet(self) -> None:
        """Write RET instruction."""
        self.code.extend(b'\xc0\x03\x5f\xd6')
        self.offset += 4

    def putBrReg(self, reg: str) -> None:
        """Write BR Xn instruction."""
        reg_num = int(reg[1:]) if reg.startswith('x') else 30
        # BR Xn: 0xd61f0000 | (reg_num << 5)
        insn = 0xd61f0000 | (reg_num << 5)
        self.code.extend(insn.to_bytes(4, 'little'))
        self.offset += 4

    def putBlrReg(self, reg: str) -> None:
        """Write BLR Xn instruction."""
        reg_num = int(reg[1:]) if reg.startswith('x') else 30
        # BLR Xn: 0xd63f0000 | (reg_num << 5)
        insn = 0xd63f0000 | (reg_num << 5)
        self.code.extend(insn.to_bytes(4, 'little'))
        self.offset += 4

    def putBytes(self, data: bytes) -> None:
        """Write raw bytes."""
        self.code.extend(data)
        self.offset += len(data)

    def flush(self) -> bytes:
        """Get generated code."""
        return bytes(self.code)

    def dispose(self) -> None:
        """Clean up."""
        self.code.clear()
        self.offset = 0


class Arm64Relocator:
    """ARM64 instruction relocator for code patching."""

    def __init__(self, address: int | NativePointer, writer: Arm64Writer):
        """Create relocator."""
        self.address = address.address if isinstance(address, NativePointer) else address
        self.writer = writer
        self.input_offset = 0

    def readOne(self) -> int:
        """Read and relocate one instruction."""
        insn = Instruction.parse(self.address + self.input_offset)
        if insn is None:
            return 0

        self.input_offset += insn.size
        return insn.size

    def writeOne(self) -> None:
        """Write one relocated instruction."""
        # For simple cases, just copy the instruction
        pass

    def writeAll(self) -> None:
        """Write all read instructions."""
        pass


class ArmWriter:
    """ARM (32-bit) instruction writer."""

    def __init__(self, address: int | NativePointer):
        """Create writer at address."""
        self.address = address.address if isinstance(address, NativePointer) else address
        self.code = bytearray()
        self.offset = 0

    def putNop(self) -> None:
        """Write NOP instruction."""
        self.code.extend(b'\x00\xf0\x20\xe3')  # NOP
        self.offset += 4

    def putBxReg(self, reg: str) -> None:
        """Write BX Rn instruction."""
        reg_num = int(reg[1:]) if reg.startswith('r') else 14
        # BX Rn: 0xe12fff10 | reg_num
        insn = 0xe12fff10 | reg_num
        self.code.extend(insn.to_bytes(4, 'little'))
        self.offset += 4

    def putBytes(self, data: bytes) -> None:
        """Write raw bytes."""
        self.code.extend(data)
        self.offset += len(data)

    def flush(self) -> bytes:
        """Get generated code."""
        return bytes(self.code)

    def dispose(self) -> None:
        """Clean up."""
        self.code.clear()
        self.offset = 0


class ThumbWriter:
    """Thumb instruction writer."""

    def __init__(self, address: int | NativePointer):
        """Create writer at address."""
        self.address = address.address if isinstance(address, NativePointer) else address
        self.code = bytearray()
        self.offset = 0

    def putNop(self) -> None:
        """Write NOP instruction (2 bytes)."""
        self.code.extend(b'\x00\xbf')
        self.offset += 2

    def putBxReg(self, reg: str) -> None:
        """Write BX Rn instruction."""
        reg_num = int(reg[1:]) if reg.startswith('r') else 14
        # BX Rn: 0x4700 | (reg_num << 3)
        insn = 0x4700 | (reg_num << 3)
        self.code.extend(insn.to_bytes(2, 'little'))
        self.offset += 2

    def putBytes(self, data: bytes) -> None:
        """Write raw bytes."""
        self.code.extend(data)
        self.offset += len(data)

    def flush(self) -> bytes:
        """Get generated code."""
        return bytes(self.code)

    def dispose(self) -> None:
        """Clean up."""
        self.code.clear()
        self.offset = 0
