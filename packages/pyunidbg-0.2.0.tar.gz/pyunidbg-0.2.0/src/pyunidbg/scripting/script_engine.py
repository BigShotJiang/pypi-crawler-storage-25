"""
ScriptEngine - Main entry point for scripting.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .api_resolver import ApiResolver
from .instruction import Instruction
from .interceptor import Interceptor
from .java_bridge import Java
from .memory import Memory
from .module import Module
from .native_function import NativeCallback, NativeFunction
from .native_pointer import NativePointer
from .process import Process
from .script import Script, ScriptRuntime
from .stalker import Stalker

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class ScriptEngine:
    """
    Main scripting engine for PyUniDbg.
    
    Provides a high-level interface for Frida-style scripting.
    
    Usage:
        # Create engine
        engine = ScriptEngine(emulator)
        
        # Load and run a script file
        script = engine.create_script_from_file("hooks.js")
        script.on('message', lambda msg, data: print(msg))
        script.load()
        
        # Or run inline Python code
        engine.run('''
            Interceptor.attach(
                Module.findExportByName("libc.so", "open"),
                on_enter=lambda args: print(f"open: {Memory.readUtf8String(args[0])}")
            )
        ''')
        
        # Access APIs directly
        ptr = engine.Memory.alloc(1024)
        engine.Memory.writeUtf8String(ptr, "hello")
    """

    def __init__(self, emulator: Emulator):
        """
        Create a script engine.
        
        Args:
            emulator: The emulator instance
        """
        self._emulator = emulator
        self._scripts: list[Script] = []

        # Initialize all APIs
        self._setup_apis()

        # Expose APIs as properties
        self.Memory = Memory
        self.Interceptor = Interceptor
        self.Module = Module
        self.Process = Process
        self.NativePointer = NativePointer
        self.NativeFunction = NativeFunction
        self.NativeCallback = NativeCallback
        self.ApiResolver = ApiResolver
        self.Instruction = Instruction
        self.Stalker = Stalker
        self.Java = Java

    def _setup_apis(self) -> None:
        """Initialize all APIs with emulator."""
        Memory.set_emulator(self._emulator)
        NativePointer.set_emulator(self._emulator)
        Interceptor.set_emulator(self._emulator)
        Module.set_emulator(self._emulator)
        Process.set_emulator(self._emulator)
        NativeFunction.set_emulator(self._emulator)
        NativeCallback.set_emulator(self._emulator)
        ApiResolver.set_emulator(self._emulator)
        Instruction.set_emulator(self._emulator)
        Stalker.set_emulator(self._emulator)
        Java.set_emulator(self._emulator)

    def create_script(self, source: str,
                      runtime: str | ScriptRuntime = ScriptRuntime.DEFAULT,
                      name: str = "script") -> Script:
        """
        Create a script from source code.
        
        Args:
            source: Script source (Python or JavaScript)
            runtime: Runtime to use ('python', 'qjs', 'default')
            name: Script name
            
        Returns:
            Script instance
        """
        script = Script(
            emulator=self._emulator,
            source=source,
            runtime=runtime,
            name=name
        )
        self._scripts.append(script)
        return script

    def create_script_from_file(self, path: str | Path,
                                 runtime: str | ScriptRuntime = ScriptRuntime.DEFAULT,
                                 name: str | None = None) -> Script:
        """
        Create a script from a file.
        
        Args:
            path: Path to script file
            runtime: Runtime to use
            name: Script name (defaults to filename)
            
        Returns:
            Script instance
        """
        path = Path(path)

        if not path.exists():
            raise FileNotFoundError(f"Script not found: {path}")

        source = path.read_text(encoding='utf-8')

        if name is None:
            name = path.stem

        return self.create_script(source, runtime, name)

    def run(self, source: str,
            runtime: str | ScriptRuntime = ScriptRuntime.PYTHON) -> Any:
        """
        Run script code directly.
        
        This is a convenience method for quick script execution.
        
        Args:
            source: Script source
            runtime: Runtime to use
            
        Returns:
            Result from script (if any)
        """
        script = self.create_script(source, runtime, name="inline")
        script.load()
        return script.exports

    def run_file(self, path: str | Path,
                 runtime: str | ScriptRuntime = ScriptRuntime.DEFAULT) -> Any:
        """
        Run a script file.
        
        Args:
            path: Path to script
            runtime: Runtime to use
            
        Returns:
            Script exports
        """
        script = self.create_script_from_file(path, runtime)
        script.load()
        return script.exports

    def unload_all(self) -> None:
        """Unload all scripts."""
        for script in self._scripts:
            script.unload()
        self._scripts.clear()

        # Clean up global state
        Interceptor.detachAll()
        Stalker.flush()

    def ptr(self, address: int | str) -> NativePointer:
        """
        Create a NativePointer (convenience method).
        
        Args:
            address: Address as int or hex string
            
        Returns:
            NativePointer
        """
        return NativePointer(address)

    # ==================== Direct API Access ====================

    def attach(self, target: int | NativePointer | str,
               on_enter: Callable | None = None,
               on_leave: Callable | None = None):
        """
        Attach hook to a function (convenience method).
        
        Args:
            target: Function address or name ("module!export")
            on_enter: Entry callback
            on_leave: Exit callback
            
        Returns:
            Hook listener
        """
        # Resolve target if it's a string
        if isinstance(target, str):
            if '!' in target:
                module, export = target.split('!', 1)
                addr = Module.findExportByName(module, export)
            else:
                addr = Module.findExportByName(None, target)

            if addr is None:
                raise ValueError(f"Export not found: {target}")
            target = addr

        return Interceptor.attach(target, on_enter=on_enter, on_leave=on_leave)

    def replace(self, target: int | NativePointer | str,
                replacement: Callable):
        """
        Replace a function (convenience method).
        
        Args:
            target: Function address or name
            replacement: Replacement function
            
        Returns:
            Replacement listener
        """
        if isinstance(target, str):
            if '!' in target:
                module, export = target.split('!', 1)
                addr = Module.findExportByName(module, export)
            else:
                addr = Module.findExportByName(None, target)

            if addr is None:
                raise ValueError(f"Export not found: {target}")
            target = addr

        return Interceptor.replace(target, replacement)

    def find_export(self, module: str | None, name: str) -> NativePointer | None:
        """
        Find an export by name.
        
        Args:
            module: Module name (None for all)
            name: Export name
            
        Returns:
            Address or None
        """
        return Module.findExportByName(module, name)

    def read_utf8(self, address: int | NativePointer) -> str:
        """Read UTF-8 string from address."""
        return Memory.readUtf8String(address)

    def write_utf8(self, address: int | NativePointer, text: str) -> None:
        """Write UTF-8 string to address."""
        Memory.writeUtf8String(address, text)

    def alloc_utf8(self, text: str) -> NativePointer:
        """Allocate and write UTF-8 string."""
        return Memory.allocUtf8String(text)

    def alloc(self, size: int) -> NativePointer:
        """Allocate memory."""
        return Memory.alloc(size)

    def hexdump(self, address: int | NativePointer,
                length: int = 256) -> str:
        """
        Hexdump memory at address.
        
        Args:
            address: Start address
            length: Number of bytes
            
        Returns:
            Formatted hexdump string
        """
        addr = address.address if isinstance(address, NativePointer) else address
        data = Memory.readByteArray(addr, length)

        lines = []
        for i in range(0, len(data), 16):
            chunk = data[i:i+16]
            hex_part = ' '.join(f'{b:02x}' for b in chunk)
            ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
            lines.append(f'{addr + i:08x}  {hex_part:<48}  {ascii_part}')

        return '\n'.join(lines)

    def disassemble(self, address: int | NativePointer,
                    count: int = 10) -> str:
        """
        Disassemble instructions at address.
        
        Args:
            address: Start address
            count: Number of instructions
            
        Returns:
            Disassembly string
        """
        instructions = Instruction.parseN(address, count)
        return '\n'.join(str(insn) for insn in instructions)


# Convenience function to create engine
def create_engine(emulator: Emulator) -> ScriptEngine:
    """Create a script engine for an emulator."""
    return ScriptEngine(emulator)
