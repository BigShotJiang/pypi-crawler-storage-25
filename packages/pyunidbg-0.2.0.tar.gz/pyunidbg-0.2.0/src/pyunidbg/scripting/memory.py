"""
Memory - Frida-style memory operations.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntFlag
from typing import TYPE_CHECKING

from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)


class MemoryProtection(IntFlag):
    """Memory protection flags (Frida-compatible)."""
    NONE = 0
    READ = 1       # 'r'
    WRITE = 2      # 'w'
    EXECUTE = 4    # 'x'

    # Common combinations
    RW = READ | WRITE
    RX = READ | EXECUTE
    RWX = READ | WRITE | EXECUTE

    @classmethod
    def from_string(cls, s: str) -> MemoryProtection:
        """Parse protection from string like 'rwx', 'r-x', etc."""
        prot = cls.NONE
        s = s.lower()
        if 'r' in s:
            prot |= cls.READ
        if 'w' in s:
            prot |= cls.WRITE
        if 'x' in s:
            prot |= cls.EXECUTE
        return prot

    def to_string(self) -> str:
        """Convert to string like 'rwx'."""
        r = 'r' if self & MemoryProtection.READ else '-'
        w = 'w' if self & MemoryProtection.WRITE else '-'
        x = 'x' if self & MemoryProtection.EXECUTE else '-'
        return f"{r}{w}{x}"


@dataclass
class MemoryRange:
    """Represents a memory range."""
    base: NativePointer
    size: int
    protection: MemoryProtection
    file: str | None = None

    @property
    def end(self) -> NativePointer:
        """End address of the range."""
        return self.base.add(self.size)

    def contains(self, address: int | NativePointer) -> bool:
        """Check if address is within this range."""
        addr = address.address if isinstance(address, NativePointer) else address
        return self.base.address <= addr < self.base.address + self.size


@dataclass
class MemoryScanMatch:
    """Match result from memory scanning."""
    address: NativePointer
    size: int


class Memory:
    """
    Frida-compatible Memory API.
    
    Provides static methods for memory operations:
    - Allocation
    - Reading/Writing
    - Protection changes
    - Scanning/Pattern matching
    
    Usage:
        Memory.set_emulator(emu)
        
        # Allocate memory
        ptr = Memory.alloc(1024)
        
        # Read/Write
        value = Memory.readU32(ptr)
        Memory.writeUtf8String(ptr, "hello")
        
        # Scan for pattern
        matches = Memory.scan(ptr, 0x1000, "48 89 5c 24 ??")
    """

    _emulator: Emulator | None = None
    _allocations: dict[int, int] = {}  # address -> size

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator
        NativePointer.set_emulator(emulator)

    @classmethod
    def _get_emu(cls) -> Emulator:
        """Get emulator, raising error if not set."""
        if cls._emulator is None:
            raise RuntimeError("Memory.set_emulator() must be called first")
        return cls._emulator

    # ==================== Allocation ====================

    @classmethod
    def alloc(cls, size: int, options: dict | None = None) -> NativePointer:
        """
        Allocate memory.
        
        Args:
            size: Number of bytes to allocate
            options: Optional dict with 'near' and 'maxDistance' keys
            
        Returns:
            Pointer to allocated memory
        """
        emu = cls._get_emu()
        address = emu.alloc(size)
        cls._allocations[address] = size
        return NativePointer(address)

    @classmethod
    def allocUtf8String(cls, text: str) -> NativePointer:
        """Allocate and write a UTF-8 string."""
        data = text.encode('utf-8') + b'\x00'
        ptr = cls.alloc(len(data))
        cls._get_emu().mem_write(ptr.address, data)
        return ptr

    @classmethod
    def allocUtf16String(cls, text: str) -> NativePointer:
        """Allocate and write a UTF-16 string."""
        data = text.encode('utf-16-le') + b'\x00\x00'
        ptr = cls.alloc(len(data))
        cls._get_emu().mem_write(ptr.address, data)
        return ptr

    @classmethod
    def allocAnsiString(cls, text: str) -> NativePointer:
        """Allocate and write an ANSI string (alias for allocUtf8String)."""
        return cls.allocUtf8String(text)

    @classmethod
    def free(cls, address: int | NativePointer) -> None:
        """Free allocated memory (if emulator supports it)."""
        addr = address.address if isinstance(address, NativePointer) else address
        if addr in cls._allocations:
            del cls._allocations[addr]
        # Note: Actual freeing depends on emulator implementation

    # ==================== Copying ====================

    @classmethod
    def copy(cls, dst: int | NativePointer, src: int | NativePointer, n: int) -> None:
        """Copy n bytes from src to dst."""
        emu = cls._get_emu()
        dst_addr = dst.address if isinstance(dst, NativePointer) else dst
        src_addr = src.address if isinstance(src, NativePointer) else src
        data = emu.mem_read(src_addr, n)
        emu.mem_write(dst_addr, bytes(data))

    @classmethod
    def dup(cls, address: int | NativePointer, size: int) -> NativePointer:
        """Duplicate memory region."""
        emu = cls._get_emu()
        addr = address.address if isinstance(address, NativePointer) else address
        data = emu.mem_read(addr, size)
        new_ptr = cls.alloc(size)
        emu.mem_write(new_ptr.address, bytes(data))
        return new_ptr

    # ==================== Protection ====================

    @classmethod
    def protect(cls, address: int | NativePointer, size: int,
                protection: str | MemoryProtection) -> bool:
        """
        Change memory protection.
        
        Args:
            address: Start address
            size: Size of region
            protection: New protection ('rwx' string or MemoryProtection)
            
        Returns:
            True if successful
        """
        emu = cls._get_emu()
        addr = address.address if isinstance(address, NativePointer) else address

        if isinstance(protection, str):
            prot = MemoryProtection.from_string(protection)
        else:
            prot = protection

        # Convert to Unicorn protection flags
        uc_prot = 0
        if prot & MemoryProtection.READ:
            uc_prot |= 1  # UC_PROT_READ
        if prot & MemoryProtection.WRITE:
            uc_prot |= 2  # UC_PROT_WRITE
        if prot & MemoryProtection.EXECUTE:
            uc_prot |= 4  # UC_PROT_EXEC

        try:
            emu.uc.mem_protect(addr, size, uc_prot)
            return True
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

    @classmethod
    def queryProtection(cls, address: int | NativePointer) -> MemoryProtection:
        """Query memory protection at address."""
        # Note: Unicorn doesn't have direct query, so we track internally
        # For now, return RWX as default
        return MemoryProtection.RWX

    # ==================== Reading ====================

    @classmethod
    def readPointer(cls, address: int | NativePointer) -> NativePointer:
        """Read pointer from address."""
        return NativePointer(address).readPointer()

    @classmethod
    def readS8(cls, address: int | NativePointer) -> int:
        """Read signed 8-bit integer."""
        return NativePointer(address).readS8()

    @classmethod
    def readU8(cls, address: int | NativePointer) -> int:
        """Read unsigned 8-bit integer."""
        return NativePointer(address).readU8()

    @classmethod
    def readS16(cls, address: int | NativePointer) -> int:
        """Read signed 16-bit integer."""
        return NativePointer(address).readS16()

    @classmethod
    def readU16(cls, address: int | NativePointer) -> int:
        """Read unsigned 16-bit integer."""
        return NativePointer(address).readU16()

    @classmethod
    def readS32(cls, address: int | NativePointer) -> int:
        """Read signed 32-bit integer."""
        return NativePointer(address).readS32()

    @classmethod
    def readU32(cls, address: int | NativePointer) -> int:
        """Read unsigned 32-bit integer."""
        return NativePointer(address).readU32()

    @classmethod
    def readS64(cls, address: int | NativePointer) -> int:
        """Read signed 64-bit integer."""
        return NativePointer(address).readS64()

    @classmethod
    def readU64(cls, address: int | NativePointer) -> int:
        """Read unsigned 64-bit integer."""
        return NativePointer(address).readU64()

    @classmethod
    def readShort(cls, address: int | NativePointer) -> int:
        """Alias for readS16."""
        return cls.readS16(address)

    @classmethod
    def readUShort(cls, address: int | NativePointer) -> int:
        """Alias for readU16."""
        return cls.readU16(address)

    @classmethod
    def readInt(cls, address: int | NativePointer) -> int:
        """Alias for readS32."""
        return cls.readS32(address)

    @classmethod
    def readUInt(cls, address: int | NativePointer) -> int:
        """Alias for readU32."""
        return cls.readU32(address)

    @classmethod
    def readLong(cls, address: int | NativePointer) -> int:
        """Read pointer-sized signed integer."""
        return NativePointer(address).readLong()

    @classmethod
    def readULong(cls, address: int | NativePointer) -> int:
        """Read pointer-sized unsigned integer."""
        return NativePointer(address).readULong()

    @classmethod
    def readFloat(cls, address: int | NativePointer) -> float:
        """Read 32-bit float."""
        return NativePointer(address).readFloat()

    @classmethod
    def readDouble(cls, address: int | NativePointer) -> float:
        """Read 64-bit double."""
        return NativePointer(address).readDouble()

    @classmethod
    def readByteArray(cls, address: int | NativePointer, length: int) -> bytes:
        """Read byte array."""
        return NativePointer(address).readByteArray(length)

    @classmethod
    def readCString(cls, address: int | NativePointer, size: int = 0) -> str:
        """Read C string."""
        return NativePointer(address).readCString(size)

    @classmethod
    def readUtf8String(cls, address: int | NativePointer, size: int = 0) -> str:
        """Read UTF-8 string."""
        return NativePointer(address).readUtf8String(size)

    @classmethod
    def readUtf16String(cls, address: int | NativePointer, length: int = 0) -> str:
        """Read UTF-16 string."""
        return NativePointer(address).readUtf16String(length)

    @classmethod
    def readAnsiString(cls, address: int | NativePointer, size: int = 0) -> str:
        """Read ANSI string."""
        return NativePointer(address).readAnsiString(size)

    # ==================== Writing ====================

    @classmethod
    def writePointer(cls, address: int | NativePointer,
                     value: int | NativePointer) -> None:
        """Write pointer to address."""
        NativePointer(address).writePointer(value)

    @classmethod
    def writeS8(cls, address: int | NativePointer, value: int) -> None:
        """Write signed 8-bit integer."""
        NativePointer(address).writeS8(value)

    @classmethod
    def writeU8(cls, address: int | NativePointer, value: int) -> None:
        """Write unsigned 8-bit integer."""
        NativePointer(address).writeU8(value)

    @classmethod
    def writeS16(cls, address: int | NativePointer, value: int) -> None:
        """Write signed 16-bit integer."""
        NativePointer(address).writeS16(value)

    @classmethod
    def writeU16(cls, address: int | NativePointer, value: int) -> None:
        """Write unsigned 16-bit integer."""
        NativePointer(address).writeU16(value)

    @classmethod
    def writeS32(cls, address: int | NativePointer, value: int) -> None:
        """Write signed 32-bit integer."""
        NativePointer(address).writeS32(value)

    @classmethod
    def writeU32(cls, address: int | NativePointer, value: int) -> None:
        """Write unsigned 32-bit integer."""
        NativePointer(address).writeU32(value)

    @classmethod
    def writeS64(cls, address: int | NativePointer, value: int) -> None:
        """Write signed 64-bit integer."""
        NativePointer(address).writeS64(value)

    @classmethod
    def writeU64(cls, address: int | NativePointer, value: int) -> None:
        """Write unsigned 64-bit integer."""
        NativePointer(address).writeU64(value)

    @classmethod
    def writeShort(cls, address: int | NativePointer, value: int) -> None:
        """Alias for writeS16."""
        cls.writeS16(address, value)

    @classmethod
    def writeUShort(cls, address: int | NativePointer, value: int) -> None:
        """Alias for writeU16."""
        cls.writeU16(address, value)

    @classmethod
    def writeInt(cls, address: int | NativePointer, value: int) -> None:
        """Alias for writeS32."""
        cls.writeS32(address, value)

    @classmethod
    def writeUInt(cls, address: int | NativePointer, value: int) -> None:
        """Alias for writeU32."""
        cls.writeU32(address, value)

    @classmethod
    def writeLong(cls, address: int | NativePointer, value: int) -> None:
        """Write pointer-sized signed integer."""
        NativePointer(address).writeLong(value)

    @classmethod
    def writeULong(cls, address: int | NativePointer, value: int) -> None:
        """Write pointer-sized unsigned integer."""
        NativePointer(address).writeULong(value)

    @classmethod
    def writeFloat(cls, address: int | NativePointer, value: float) -> None:
        """Write 32-bit float."""
        NativePointer(address).writeFloat(value)

    @classmethod
    def writeDouble(cls, address: int | NativePointer, value: float) -> None:
        """Write 64-bit double."""
        NativePointer(address).writeDouble(value)

    @classmethod
    def writeByteArray(cls, address: int | NativePointer, data: bytes) -> None:
        """Write byte array."""
        NativePointer(address).writeByteArray(data)

    @classmethod
    def writeUtf8String(cls, address: int | NativePointer, text: str) -> None:
        """Write UTF-8 string with NULL terminator."""
        NativePointer(address).writeUtf8String(text)

    @classmethod
    def writeUtf16String(cls, address: int | NativePointer, text: str) -> None:
        """Write UTF-16 string with NULL terminator."""
        NativePointer(address).writeUtf16String(text)

    @classmethod
    def writeAnsiString(cls, address: int | NativePointer, text: str) -> None:
        """Write ANSI string."""
        cls.writeUtf8String(address, text)

    # ==================== Pattern Scanning ====================

    @classmethod
    def _parse_pattern(cls, pattern: str) -> tuple[bytes, bytes]:
        """
        Parse IDA-style pattern into bytes and mask.
        
        Pattern format: "48 89 5c 24 ?? 48 89 74 24"
        ? or ?? = wildcard byte
        
        Returns:
            (pattern_bytes, mask_bytes) where mask 0xFF = match, 0x00 = wildcard
        """
        parts = pattern.replace('?', '??').split()
        pattern_bytes = bytearray()
        mask_bytes = bytearray()

        for part in parts:
            if part == '??':
                pattern_bytes.append(0)
                mask_bytes.append(0)
            else:
                pattern_bytes.append(int(part, 16))
                mask_bytes.append(0xFF)

        return bytes(pattern_bytes), bytes(mask_bytes)

    @classmethod
    def scan(cls, address: int | NativePointer, size: int,
             pattern: str) -> list[MemoryScanMatch]:
        """
        Scan memory for pattern.
        
        Args:
            address: Start address
            size: Size of region to scan
            pattern: IDA-style pattern (e.g., "48 89 5c 24 ??")
            
        Returns:
            List of matches
        """
        emu = cls._get_emu()
        addr = address.address if isinstance(address, NativePointer) else address
        data = emu.mem_read(addr, size)

        pattern_bytes, mask_bytes = cls._parse_pattern(pattern)
        pattern_len = len(pattern_bytes)

        matches = []
        for i in range(len(data) - pattern_len + 1):
            match = True
            for j in range(pattern_len):
                if mask_bytes[j] != 0 and data[i + j] != pattern_bytes[j]:
                    match = False
                    break
            if match:
                matches.append(MemoryScanMatch(
                    address=NativePointer(addr + i),
                    size=pattern_len
                ))

        return matches

    @classmethod
    def scanSync(cls, address: int | NativePointer, size: int,
                 pattern: str) -> list[MemoryScanMatch]:
        """Synchronous scan (alias for scan)."""
        return cls.scan(address, size, pattern)

    # ==================== Patching ====================

    @classmethod
    def patchCode(cls, address: int | NativePointer,
                  data: bytes | list[int]) -> None:
        """
        Patch code at address.
        
        Args:
            address: Address to patch
            data: Bytes to write
        """
        emu = cls._get_emu()
        addr = address.address if isinstance(address, NativePointer) else address
        if isinstance(data, list):
            data = bytes(data)
        emu.mem_write(addr, data)
