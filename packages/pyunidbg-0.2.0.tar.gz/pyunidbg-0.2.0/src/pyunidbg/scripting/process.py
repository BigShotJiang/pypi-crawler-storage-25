"""
Process - Frida-style process operations.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from .memory import MemoryProtection, MemoryRange
from .module import Module, ModuleInfo
from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)


class Platform(Enum):
    """Platform identifiers."""
    LINUX = "linux"
    ANDROID = "android"
    WINDOWS = "windows"
    DARWIN = "darwin"
    IOS = "ios"
    QNX = "qnx"
    FREEBSD = "freebsd"


class Arch(Enum):
    """Architecture identifiers."""
    ARM = "arm"
    ARM64 = "arm64"
    X86 = "ia32"
    X64 = "x64"
    MIPS = "mips"


@dataclass
class ThreadContext:
    """
    CPU context for a thread.
    
    Contains all register values.
    """
    _registers: dict
    _emulator: any | None = None

    def __getattr__(self, name: str) -> int:
        """Get register by name."""
        if name.startswith('_'):
            raise AttributeError(name)
        return self._registers.get(name, 0)

    def __setattr__(self, name: str, value: int) -> None:
        """Set register by name."""
        if name.startswith('_'):
            super().__setattr__(name, value)
            return
        self._registers[name] = value
        if self._emulator:
            try:
                self._emulator.reg_write(name, value)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)


@dataclass
class ThreadInfo:
    """Information about a thread."""
    id: int
    name: str
    state: str  # 'running', 'waiting', 'stopped', etc.
    context: ThreadContext | None = None


class Process:
    """
    Frida-compatible Process API.
    
    Provides process-level operations:
    - Platform/architecture info
    - Memory range enumeration
    - Thread enumeration
    - Module management
    
    Usage:
        Process.set_emulator(emu)
        
        # Get info
        print(f"Platform: {Process.platform}")
        print(f"Arch: {Process.arch}")
        print(f"Pointer size: {Process.pointerSize}")
        
        # Enumerate ranges
        for range in Process.enumerateRanges('r-x'):
            print(f"{range.base} - {range.size}")
    """

    _emulator: Emulator | None = None
    _platform: Platform = Platform.ANDROID
    _arch: Arch = Arch.ARM64

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

        # Detect architecture
        if emulator.is_64bit:
            cls._arch = Arch.ARM64
        else:
            cls._arch = Arch.ARM

        # Set platform based on emulator type
        if hasattr(emulator, 'platform'):
            plat = emulator.platform.lower()
            if 'android' in plat:
                cls._platform = Platform.ANDROID
            elif 'linux' in plat:
                cls._platform = Platform.LINUX
            elif 'ios' in plat:
                cls._platform = Platform.IOS
        else:
            cls._platform = Platform.ANDROID  # Default

    @classmethod
    def _get_emu(cls) -> Emulator:
        """Get emulator, raising error if not set."""
        if cls._emulator is None:
            raise RuntimeError("Process.set_emulator() must be called first")
        return cls._emulator

    # ==================== Properties ====================

    @classmethod
    def get_id(cls) -> int:
        """Get process ID (emulator returns 1)."""
        return 1

    # Property alias for Frida compatibility
    id = property(lambda self: 1)

    @classmethod
    def get_platform(cls) -> str:
        """Get platform string."""
        return cls._platform.value

    @classmethod
    def get_arch(cls) -> str:
        """Get architecture string."""
        return cls._arch.value

    @classmethod
    def get_pointerSize(cls) -> int:
        """Get pointer size in bytes."""
        return 8 if cls._arch == Arch.ARM64 else 4

    @classmethod
    def get_pageSize(cls) -> int:
        """Get page size."""
        return 0x1000  # 4KB

    @classmethod
    def get_codeSigningPolicy(cls) -> str:
        """Get code signing policy."""
        return "optional"

    @classmethod
    def get_isDebuggerAttached(cls) -> bool:
        """Check if debugger is attached."""
        return True  # Emulator is always "debugging"

    # ==================== Thread Operations ====================

    @classmethod
    def getCurrentThreadId(cls) -> int:
        """Get current thread ID."""
        return 1  # Emulator is single-threaded

    @classmethod
    def enumerateThreads(cls) -> list[ThreadInfo]:
        """List all threads."""
        emu = cls._get_emu()

        # Get current context
        context = ThreadContext(_registers={}, _emulator=emu)

        # Emulator is single-threaded
        return [ThreadInfo(
            id=1,
            name="main",
            state="running",
            context=context
        )]

    @classmethod
    def findThreadById(cls, thread_id: int) -> ThreadInfo | None:
        """Find thread by ID."""
        threads = cls.enumerateThreads()
        for thread in threads:
            if thread.id == thread_id:
                return thread
        return None

    # ==================== Memory Operations ====================

    @classmethod
    def enumerateRanges(cls, protection: str | MemoryProtection) -> list[MemoryRange]:
        """
        Enumerate memory ranges matching protection.
        
        Args:
            protection: Protection filter (e.g., 'r-x', 'rw-')
            
        Returns:
            List of matching memory ranges
        """
        emu = cls._get_emu()

        if isinstance(protection, str):
            prot = MemoryProtection.from_string(protection)
        else:
            prot = protection

        ranges = []

        # Get regions from Unicorn
        if hasattr(emu, 'uc'):
            for begin, end, perms in emu.uc.mem_regions():
                # Convert Unicorn perms to our format
                region_prot = MemoryProtection.NONE
                if perms & 1:  # UC_PROT_READ
                    region_prot |= MemoryProtection.READ
                if perms & 2:  # UC_PROT_WRITE
                    region_prot |= MemoryProtection.WRITE
                if perms & 4:  # UC_PROT_EXEC
                    region_prot |= MemoryProtection.EXECUTE

                # Check if matches filter
                if (prot & region_prot) == prot:
                    ranges.append(MemoryRange(
                        base=NativePointer(begin),
                        size=end - begin + 1,
                        protection=region_prot
                    ))

        return ranges

    @classmethod
    def enumerateMallocRanges(cls) -> list[MemoryRange]:
        """Enumerate heap allocations."""
        # Would need heap tracking
        return []

    @classmethod
    def getRangeByAddress(cls, address: int | NativePointer) -> MemoryRange | None:
        """Get memory range containing address."""
        addr = address.address if isinstance(address, NativePointer) else address

        for range in cls.enumerateRanges('---'):  # Get all ranges
            if range.contains(addr):
                return range

        return None

    @classmethod
    def setExceptionHandler(cls, callback) -> None:
        """Set exception handler."""
        emu = cls._get_emu()

        # Store callback for exception handling
        if hasattr(emu, '_exception_handler'):
            emu._exception_handler = callback

    # ==================== Module Operations ====================

    @classmethod
    def enumerateModules(cls) -> list[ModuleInfo]:
        """List all loaded modules."""
        return Module.enumerateModules()

    @classmethod
    def findModuleByName(cls, name: str) -> ModuleInfo | None:
        """Find module by name."""
        return Module.findModuleByName(name)

    @classmethod
    def findModuleByAddress(cls, address: int | NativePointer) -> ModuleInfo | None:
        """Find module containing address."""
        return Module.findModuleByAddress(address)

    @classmethod
    def getModuleByName(cls, name: str) -> ModuleInfo | None:
        """Alias for findModuleByName."""
        return Module.findModuleByName(name)

    @classmethod
    def getModuleByAddress(cls, address: int | NativePointer) -> ModuleInfo | None:
        """Alias for findModuleByAddress."""
        return Module.findModuleByAddress(address)


# Thread-local storage simulation
class _TLS:
    """Thread-local storage."""
    _data: dict = {}

    def __getitem__(self, key: str):
        return self._data.get(key)

    def __setitem__(self, key: str, value):
        self._data[key] = value


# Global TLS instance
Thread = type('Thread', (), {
    'backtrace': lambda ctx, bt: [],
    'sleep': lambda seconds: None,
})()
