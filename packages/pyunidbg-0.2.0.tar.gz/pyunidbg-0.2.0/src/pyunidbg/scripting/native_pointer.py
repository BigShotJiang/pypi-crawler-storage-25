"""
NativePointer - Frida-style pointer wrapper.
"""

from __future__ import annotations

import struct
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

class NativePointer:
    """
    Frida-compatible NativePointer implementation.
    
    Wraps a memory address and provides convenient methods for
    reading/writing memory and pointer arithmetic.
    
    Usage:
        ptr = NativePointer(0x12345678)
        value = ptr.readU32()
        ptr.writeUtf8String("hello")
        next_ptr = ptr.add(4)
    """

    _emulator: Emulator | None = None
    _pointer_size: int = 8  # Default to 64-bit

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance for memory operations."""
        cls._emulator = emulator
        cls._pointer_size = 8 if emulator.is_64bit else 4

    def __init__(self, address: int | str | NativePointer):
        """
        Create a NativePointer.
        
        Args:
            address: Memory address as int, hex string, or another NativePointer
        """
        if isinstance(address, NativePointer):
            self._address = address._address
        elif isinstance(address, str):
            self._address = int(address, 16) if address.startswith('0x') else int(address)
        else:
            self._address = address & ((1 << (self._pointer_size * 8)) - 1)

    @property
    def address(self) -> int:
        """Get the raw address value."""
        return self._address

    def isNull(self) -> bool:
        """Check if pointer is NULL."""
        return self._address == 0

    def toInt32(self) -> int:
        """Convert to signed 32-bit integer."""
        if self._address >= 0x80000000:
            return self._address - 0x100000000
        return self._address

    def toUInt32(self) -> int:
        """Convert to unsigned 32-bit integer."""
        return self._address & 0xFFFFFFFF

    def toInt64(self) -> int:
        """Convert to signed 64-bit integer (Python handles big ints natively)."""
        if self._address >= 0x8000000000000000:
            return self._address - 0x10000000000000000
        return self._address

    def toString(self, radix: int = 16) -> str:
        """Convert to string representation."""
        if radix == 16:
            return f"0x{self._address:x}"
        elif radix == 10:
            return str(self._address)
        else:
            raise ValueError(f"Unsupported radix: {radix}")

    def __str__(self) -> str:
        return self.toString()

    def __repr__(self) -> str:
        return f"NativePointer({self.toString()})"

    def __hash__(self) -> int:
        return hash(self._address)

    def __eq__(self, other) -> bool:
        if isinstance(other, NativePointer):
            return self._address == other._address
        elif isinstance(other, int):
            return self._address == other
        return False

    def __lt__(self, other) -> bool:
        if isinstance(other, NativePointer):
            return self._address < other._address
        return self._address < other

    def __le__(self, other) -> bool:
        if isinstance(other, NativePointer):
            return self._address <= other._address
        return self._address <= other

    def __gt__(self, other) -> bool:
        if isinstance(other, NativePointer):
            return self._address > other._address
        return self._address > other

    def __ge__(self, other) -> bool:
        if isinstance(other, NativePointer):
            return self._address >= other._address
        return self._address >= other

    # ==================== Pointer Arithmetic ====================

    def add(self, offset: int | NativePointer) -> NativePointer:
        """Add offset to pointer."""
        if isinstance(offset, NativePointer):
            offset = offset._address
        return NativePointer(self._address + offset)

    def sub(self, offset: int | NativePointer) -> NativePointer:
        """Subtract offset from pointer."""
        if isinstance(offset, NativePointer):
            offset = offset._address
        return NativePointer(self._address - offset)

    def and_(self, mask: int) -> NativePointer:
        """Bitwise AND with mask."""
        return NativePointer(self._address & mask)

    def or_(self, value: int) -> NativePointer:
        """Bitwise OR with value."""
        return NativePointer(self._address | value)

    def xor(self, value: int) -> NativePointer:
        """Bitwise XOR with value."""
        return NativePointer(self._address ^ value)

    def shr(self, n: int) -> NativePointer:
        """Shift right by n bits."""
        return NativePointer(self._address >> n)

    def shl(self, n: int) -> NativePointer:
        """Shift left by n bits."""
        return NativePointer(self._address << n)

    def not_(self) -> NativePointer:
        """Bitwise NOT."""
        mask = (1 << (self._pointer_size * 8)) - 1
        return NativePointer(~self._address & mask)

    def sign(self, value: int) -> int:
        """Return -1, 0, or 1 based on comparison."""
        if self._address < value:
            return -1
        elif self._address > value:
            return 1
        return 0

    def compare(self, other: int | NativePointer) -> int:
        """Compare with another pointer/value."""
        other_val = other._address if isinstance(other, NativePointer) else other
        return self.sign(other_val)

    def equals(self, other: int | NativePointer) -> bool:
        """Check equality."""
        return self == other

    # ==================== Memory Reading ====================

    def _get_emu(self) -> Emulator:
        """Get emulator, raising error if not set."""
        if self._emulator is None:
            raise RuntimeError("NativePointer.set_emulator() must be called first")
        return self._emulator

    def readPointer(self) -> NativePointer:
        """Read a pointer from this address."""
        emu = self._get_emu()
        if self._pointer_size == 8:
            data = emu.mem_read(self._address, 8)
            value = struct.unpack('<Q', data)[0]
        else:
            data = emu.mem_read(self._address, 4)
            value = struct.unpack('<I', data)[0]
        return NativePointer(value)

    def readS8(self) -> int:
        """Read signed 8-bit integer."""
        data = self._get_emu().mem_read(self._address, 1)
        return struct.unpack('<b', data)[0]

    def readU8(self) -> int:
        """Read unsigned 8-bit integer."""
        data = self._get_emu().mem_read(self._address, 1)
        return struct.unpack('<B', data)[0]

    def readS16(self) -> int:
        """Read signed 16-bit integer."""
        data = self._get_emu().mem_read(self._address, 2)
        return struct.unpack('<h', data)[0]

    def readU16(self) -> int:
        """Read unsigned 16-bit integer."""
        data = self._get_emu().mem_read(self._address, 2)
        return struct.unpack('<H', data)[0]

    def readS32(self) -> int:
        """Read signed 32-bit integer."""
        data = self._get_emu().mem_read(self._address, 4)
        return struct.unpack('<i', data)[0]

    def readU32(self) -> int:
        """Read unsigned 32-bit integer."""
        data = self._get_emu().mem_read(self._address, 4)
        return struct.unpack('<I', data)[0]

    def readS64(self) -> int:
        """Read signed 64-bit integer."""
        data = self._get_emu().mem_read(self._address, 8)
        return struct.unpack('<q', data)[0]

    def readU64(self) -> int:
        """Read unsigned 64-bit integer."""
        data = self._get_emu().mem_read(self._address, 8)
        return struct.unpack('<Q', data)[0]

    def readShort(self) -> int:
        """Alias for readS16."""
        return self.readS16()

    def readUShort(self) -> int:
        """Alias for readU16."""
        return self.readU16()

    def readInt(self) -> int:
        """Alias for readS32."""
        return self.readS32()

    def readUInt(self) -> int:
        """Alias for readU32."""
        return self.readU32()

    def readLong(self) -> int:
        """Read pointer-sized signed integer."""
        if self._pointer_size == 8:
            return self.readS64()
        return self.readS32()

    def readULong(self) -> int:
        """Read pointer-sized unsigned integer."""
        if self._pointer_size == 8:
            return self.readU64()
        return self.readU32()

    def readFloat(self) -> float:
        """Read 32-bit float."""
        data = self._get_emu().mem_read(self._address, 4)
        return struct.unpack('<f', data)[0]

    def readDouble(self) -> float:
        """Read 64-bit double."""
        data = self._get_emu().mem_read(self._address, 8)
        return struct.unpack('<d', data)[0]

    def readByteArray(self, length: int) -> bytes:
        """Read byte array of specified length."""
        return bytes(self._get_emu().mem_read(self._address, length))

    def readCString(self, size: int = 0) -> str:
        """Read C string (NULL-terminated)."""
        emu = self._get_emu()
        if size > 0:
            data = emu.mem_read(self._address, size)
            null_idx = data.find(0)
            if null_idx >= 0:
                data = data[:null_idx]
            return data.decode('utf-8', errors='replace')

        # Read until NULL
        result = bytearray()
        addr = self._address
        while True:
            byte = emu.mem_read(addr, 1)[0]
            if byte == 0:
                break
            result.append(byte)
            addr += 1
            if len(result) > 0x10000:  # Safety limit
                break
        return result.decode('utf-8', errors='replace')

    def readUtf8String(self, size: int = 0) -> str:
        """Alias for readCString."""
        return self.readCString(size)

    def readUtf16String(self, length: int = 0) -> str:
        """Read UTF-16 string."""
        emu = self._get_emu()
        if length > 0:
            data = emu.mem_read(self._address, length * 2)
        else:
            # Read until NULL
            result = bytearray()
            addr = self._address
            while True:
                word = emu.mem_read(addr, 2)
                if word[0] == 0 and word[1] == 0:
                    break
                result.extend(word)
                addr += 2
                if len(result) > 0x20000:  # Safety limit
                    break
            data = bytes(result)
        return data.decode('utf-16-le', errors='replace')

    def readAnsiString(self, size: int = 0) -> str:
        """Read ANSI string (alias for readCString)."""
        return self.readCString(size)

    # ==================== Memory Writing ====================

    def writePointer(self, value: int | NativePointer) -> NativePointer:
        """Write a pointer to this address."""
        if isinstance(value, NativePointer):
            value = value._address
        emu = self._get_emu()
        if self._pointer_size == 8:
            data = struct.pack('<Q', value)
        else:
            data = struct.pack('<I', value)
        emu.mem_write(self._address, data)
        return self

    def writeS8(self, value: int) -> NativePointer:
        """Write signed 8-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<b', value))
        return self

    def writeU8(self, value: int) -> NativePointer:
        """Write unsigned 8-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<B', value))
        return self

    def writeS16(self, value: int) -> NativePointer:
        """Write signed 16-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<h', value))
        return self

    def writeU16(self, value: int) -> NativePointer:
        """Write unsigned 16-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<H', value))
        return self

    def writeS32(self, value: int) -> NativePointer:
        """Write signed 32-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<i', value))
        return self

    def writeU32(self, value: int) -> NativePointer:
        """Write unsigned 32-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<I', value))
        return self

    def writeS64(self, value: int) -> NativePointer:
        """Write signed 64-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<q', value))
        return self

    def writeU64(self, value: int) -> NativePointer:
        """Write unsigned 64-bit integer."""
        self._get_emu().mem_write(self._address, struct.pack('<Q', value))
        return self

    def writeShort(self, value: int) -> NativePointer:
        """Alias for writeS16."""
        return self.writeS16(value)

    def writeUShort(self, value: int) -> NativePointer:
        """Alias for writeU16."""
        return self.writeU16(value)

    def writeInt(self, value: int) -> NativePointer:
        """Alias for writeS32."""
        return self.writeS32(value)

    def writeUInt(self, value: int) -> NativePointer:
        """Alias for writeU32."""
        return self.writeU32(value)

    def writeLong(self, value: int) -> NativePointer:
        """Write pointer-sized signed integer."""
        if self._pointer_size == 8:
            return self.writeS64(value)
        return self.writeS32(value)

    def writeULong(self, value: int) -> NativePointer:
        """Write pointer-sized unsigned integer."""
        if self._pointer_size == 8:
            return self.writeU64(value)
        return self.writeU32(value)

    def writeFloat(self, value: float) -> NativePointer:
        """Write 32-bit float."""
        self._get_emu().mem_write(self._address, struct.pack('<f', value))
        return self

    def writeDouble(self, value: float) -> NativePointer:
        """Write 64-bit double."""
        self._get_emu().mem_write(self._address, struct.pack('<d', value))
        return self

    def writeByteArray(self, data: bytes) -> NativePointer:
        """Write byte array."""
        self._get_emu().mem_write(self._address, data)
        return self

    def writeUtf8String(self, text: str) -> NativePointer:
        """Write UTF-8 string with NULL terminator."""
        data = text.encode('utf-8') + b'\x00'
        self._get_emu().mem_write(self._address, data)
        return self

    def writeUtf16String(self, text: str) -> NativePointer:
        """Write UTF-16 string with NULL terminator."""
        data = text.encode('utf-16-le') + b'\x00\x00'
        self._get_emu().mem_write(self._address, data)
        return self

    def writeAnsiString(self, text: str) -> NativePointer:
        """Write ANSI string (alias for writeUtf8String)."""
        return self.writeUtf8String(text)


# Convenience function
def ptr(address: int | str | NativePointer) -> NativePointer:
    """Create a NativePointer (shorthand)."""
    return NativePointer(address)


# NULL pointer constant
NULL = NativePointer(0)
