"""
Module - Frida-style module/library operations.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator


@dataclass
class ModuleExport:
    """Represents an exported symbol."""
    type: str  # 'function' or 'variable'
    name: str
    address: NativePointer


@dataclass
class ModuleImport:
    """Represents an imported symbol."""
    type: str  # 'function' or 'variable'
    name: str
    module: str
    address: NativePointer | None = None
    slot: NativePointer | None = None


@dataclass
class ModuleSymbol:
    """Represents any symbol (export or import)."""
    isGlobal: bool
    type: str  # 'function', 'variable', 'unknown'
    section: str | None
    name: str
    address: NativePointer
    size: int = 0


@dataclass
class ModuleRange:
    """Represents a module memory section."""
    base: NativePointer
    size: int
    protection: str
    file: dict | None = None


@dataclass
class ModuleInfo:
    """Information about a loaded module."""
    name: str
    base: NativePointer
    size: int
    path: str

    # Sections
    _sections: list[ModuleRange] = None
    _exports: list[ModuleExport] = None
    _imports: list[ModuleImport] = None
    _symbols: list[ModuleSymbol] = None

    def enumerateExports(self) -> list[ModuleExport]:
        """List all exports."""
        return self._exports or []

    def enumerateImports(self) -> list[ModuleImport]:
        """List all imports."""
        return self._imports or []

    def enumerateSymbols(self) -> list[ModuleSymbol]:
        """List all symbols."""
        return self._symbols or []

    def enumerateRanges(self, protection: str) -> list[ModuleRange]:
        """List memory ranges matching protection."""
        if not self._sections:
            return []
        return [s for s in self._sections
                if all(c in s.protection for c in protection.replace('-', ''))]

    def findExportByName(self, name: str) -> NativePointer | None:
        """Find export by name."""
        for exp in self._exports or []:
            if exp.name == name:
                return exp.address
        return None

    def findSymbolByName(self, name: str) -> NativePointer | None:
        """Find symbol by name."""
        for sym in self._symbols or []:
            if sym.name == name:
                return sym.address
        return None


class Module:
    """
    Frida-compatible Module API.
    
    Provides operations on loaded modules/libraries:
    - Finding modules
    - Looking up exports/imports
    - Enumerating symbols
    
    Usage:
        Module.set_emulator(emu)
        
        # Find module by name
        libc = Module.findBaseAddress("libc.so")
        
        # Find export
        open_addr = Module.findExportByName("libc.so", "open")
        
        # Enumerate all modules
        for mod in Module.enumerateModules():
            print(f"{mod.name} @ {mod.base}")
    """

    _emulator: Emulator | None = None
    _modules: dict[str, ModuleInfo] = {}

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator
        cls._refresh_modules()

    @classmethod
    def _get_emu(cls) -> Emulator:
        """Get emulator, raising error if not set."""
        if cls._emulator is None:
            raise RuntimeError("Module.set_emulator() must be called first")
        return cls._emulator

    @classmethod
    def _refresh_modules(cls) -> None:
        """Refresh module list from emulator."""
        emu = cls._get_emu()
        cls._modules.clear()

        # Get modules from emulator's library manager if available
        if hasattr(emu, 'libraries'):
            for name, lib in emu.libraries.items():
                base = lib.get('base', 0)
                size = lib.get('size', 0)
                path = lib.get('path', name)

                exports = []
                for exp_name, exp_addr in lib.get('exports', {}).items():
                    exports.append(ModuleExport(
                        type='function',
                        name=exp_name,
                        address=NativePointer(exp_addr)
                    ))

                imports = []
                for imp_name, imp_info in lib.get('imports', {}).items():
                    imports.append(ModuleImport(
                        type='function',
                        name=imp_name,
                        module=imp_info.get('module', ''),
                        address=NativePointer(imp_info.get('address', 0))
                    ))

                symbols = []
                for sym_name, sym_info in lib.get('symbols', {}).items():
                    symbols.append(ModuleSymbol(
                        isGlobal=sym_info.get('global', True),
                        type=sym_info.get('type', 'function'),
                        section=sym_info.get('section'),
                        name=sym_name,
                        address=NativePointer(sym_info.get('address', 0)),
                        size=sym_info.get('size', 0)
                    ))

                cls._modules[name] = ModuleInfo(
                    name=name,
                    base=NativePointer(base),
                    size=size,
                    path=path,
                    _exports=exports,
                    _imports=imports,
                    _symbols=symbols
                )

    @classmethod
    def load(cls, path: str) -> ModuleInfo:
        """
        Load a module.
        
        Args:
            path: Path to the module
            
        Returns:
            ModuleInfo for the loaded module
        """
        emu = cls._get_emu()

        # Use emulator's load library functionality if available
        if hasattr(emu, 'load_library'):
            lib_info = emu.load_library(path)
            cls._refresh_modules()

            # Find and return the module
            name = path.split('/')[-1]
            if name in cls._modules:
                return cls._modules[name]

        raise RuntimeError(f"Failed to load module: {path}")

    @classmethod
    def ensureInitialized(cls, name: str) -> None:
        """Ensure module is initialized."""
        # In emulator context, modules are initialized on load
        pass

    @classmethod
    def enumerateModules(cls) -> list[ModuleInfo]:
        """List all loaded modules."""
        cls._refresh_modules()
        return list(cls._modules.values())

    @classmethod
    def findBaseAddress(cls, name: str) -> NativePointer | None:
        """
        Find base address of a module.
        
        Args:
            name: Module name (e.g., "libc.so")
            
        Returns:
            Base address or None if not found
        """
        cls._refresh_modules()

        # Try exact match first
        if name in cls._modules:
            return cls._modules[name].base

        # Try partial match
        for mod_name, mod_info in cls._modules.items():
            if name in mod_name or mod_name.endswith(name):
                return mod_info.base

        return None

    @classmethod
    def findModuleByName(cls, name: str) -> ModuleInfo | None:
        """
        Find module by name.
        
        Args:
            name: Module name
            
        Returns:
            ModuleInfo or None
        """
        cls._refresh_modules()

        if name in cls._modules:
            return cls._modules[name]

        for mod_name, mod_info in cls._modules.items():
            if name in mod_name or mod_name.endswith(name):
                return mod_info

        return None

    @classmethod
    def findModuleByAddress(cls, address: int | NativePointer) -> ModuleInfo | None:
        """
        Find module containing an address.
        
        Args:
            address: Address to look up
            
        Returns:
            ModuleInfo or None
        """
        addr = address.address if isinstance(address, NativePointer) else address
        cls._refresh_modules()

        for mod_info in cls._modules.values():
            base = mod_info.base.address
            if base <= addr < base + mod_info.size:
                return mod_info

        return None

    @classmethod
    def findExportByName(cls, module_name: str | None,
                         export_name: str) -> NativePointer | None:
        """
        Find an export by name.
        
        Args:
            module_name: Module to search (None for all modules)
            export_name: Export name to find
            
        Returns:
            Export address or None
        """
        cls._refresh_modules()

        if module_name:
            # Search specific module
            mod = cls.findModuleByName(module_name)
            if mod:
                return mod.findExportByName(export_name)
        else:
            # Search all modules
            for mod in cls._modules.values():
                addr = mod.findExportByName(export_name)
                if addr:
                    return addr

        return None

    @classmethod
    def findSymbolByName(cls, module_name: str | None,
                         symbol_name: str) -> NativePointer | None:
        """
        Find a symbol by name.
        
        Args:
            module_name: Module to search (None for all)
            symbol_name: Symbol name to find
            
        Returns:
            Symbol address or None
        """
        cls._refresh_modules()

        if module_name:
            mod = cls.findModuleByName(module_name)
            if mod:
                return mod.findSymbolByName(symbol_name)
        else:
            for mod in cls._modules.values():
                addr = mod.findSymbolByName(symbol_name)
                if addr:
                    return addr

        return None

    @classmethod
    def enumerateExports(cls, module_name: str) -> list[ModuleExport]:
        """List exports of a module."""
        mod = cls.findModuleByName(module_name)
        if mod:
            return mod.enumerateExports()
        return []

    @classmethod
    def enumerateImports(cls, module_name: str) -> list[ModuleImport]:
        """List imports of a module."""
        mod = cls.findModuleByName(module_name)
        if mod:
            return mod.enumerateImports()
        return []

    @classmethod
    def enumerateSymbols(cls, module_name: str) -> list[ModuleSymbol]:
        """List all symbols of a module."""
        mod = cls.findModuleByName(module_name)
        if mod:
            return mod.enumerateSymbols()
        return []

    @classmethod
    def enumerateRanges(cls, module_name: str, protection: str) -> list[ModuleRange]:
        """List memory ranges of a module matching protection."""
        mod = cls.findModuleByName(module_name)
        if mod:
            return mod.enumerateRanges(protection)
        return []

    @classmethod
    def getExportByName(cls, module_name: str | None,
                        export_name: str) -> NativePointer | None:
        """Alias for findExportByName."""
        return cls.findExportByName(module_name, export_name)
