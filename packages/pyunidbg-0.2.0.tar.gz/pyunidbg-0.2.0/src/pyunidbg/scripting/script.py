"""
Script - Frida-style script wrapper.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

from .api_resolver import ApiResolver
from .instruction import Instruction
from .interceptor import Interceptor
from .java_bridge import Java
from .memory import Memory
from .module import Module
from .native_function import NativeCallback, NativeFunction
from .native_pointer import NativePointer
from .process import Process
from .stalker import Stalker

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class ScriptRuntime(Enum):
    """Script runtime options."""
    DEFAULT = "default"
    QJS = "qjs"       # QuickJS
    V8 = "v8"         # V8 (not supported in pure Python)
    PYTHON = "python"  # Native Python


@dataclass
class ScriptMessage:
    """Message from script."""
    type: str
    payload: Any


class Script:
    """
    Frida-compatible Script wrapper.
    
    Supports both Python and JavaScript (via embedded JS engine).
    
    Usage (Python):
        script = Script(emulator, '''
            Interceptor.attach(
                Module.findExportByName("libc.so", "open"),
                on_enter=lambda args: print(f"open({Memory.readUtf8String(args[0])})")
            )
        ''', runtime='python')
        script.load()
    
    Usage (JavaScript):
        script = Script(emulator, '''
            Interceptor.attach(Module.findExportByName("libc.so", "open"), {
                onEnter: function(args) {
                    console.log("open(" + Memory.readUtf8String(args[0]) + ")");
                }
            });
        ''', runtime='qjs')
        script.load()
    """

    def __init__(self, emulator: Emulator, source: str,
                 runtime: str | ScriptRuntime = ScriptRuntime.DEFAULT,
                 name: str = "script"):
        """
        Create a script.
        
        Args:
            emulator: Emulator instance
            source: Script source code
            runtime: Runtime to use ('python', 'qjs', 'default')
            name: Script name for debugging
        """
        self._emulator = emulator
        self._source = source
        self._name = name
        self._loaded = False
        self._message_handler: Callable | None = None
        self._exports: dict[str, Any] = {}

        if isinstance(runtime, str):
            runtime = ScriptRuntime(runtime)
        self._runtime = runtime

        # Auto-detect runtime
        if runtime == ScriptRuntime.DEFAULT:
            if self._is_javascript(source):
                self._runtime = ScriptRuntime.QJS
            else:
                self._runtime = ScriptRuntime.PYTHON

        # Initialize APIs for this emulator
        self._setup_apis()

    def _setup_apis(self) -> None:
        """Set up Frida APIs with emulator instance."""
        Memory.set_emulator(self._emulator)
        NativePointer.set_emulator(self._emulator)
        Interceptor.set_emulator(self._emulator)
        Module.set_emulator(self._emulator)
        Process.set_emulator(self._emulator)
        NativeFunction.set_emulator(self._emulator)
        NativeCallback.set_emulator(self._emulator)
        ApiResolver.set_emulator(self._emulator)
        Instruction.set_emulator(self._emulator)
        Stalker.set_emulator(self._emulator)
        Java.set_emulator(self._emulator)

    def _is_javascript(self, source: str) -> bool:
        """Detect if source is JavaScript."""
        # Look for JS-specific syntax
        js_indicators = [
            'function(',
            'function (',
            'var ',
            'let ',
            'const ',
            '=>',
            'console.log',
            'this.',
            'new ',
            '.prototype',
        ]

        for indicator in js_indicators:
            if indicator in source:
                return True

        # Look for Python-specific syntax
        python_indicators = [
            'def ',
            'lambda ',
            'import ',
            'from ',
            'print(',
            '__',
        ]

        for indicator in python_indicators:
            if indicator in source:
                return False

        # Default to JavaScript for Frida compatibility
        return True

    @property
    def exports(self) -> dict[str, Any]:
        """Get exported functions/values from script."""
        return self._exports

    def load(self) -> None:
        """Load and execute the script."""
        if self._loaded:
            logger.warning(f"Script '{self._name}' already loaded")
            return

        logger.info(f"Loading script '{self._name}' with {self._runtime.value} runtime")

        if self._runtime == ScriptRuntime.PYTHON:
            self._load_python()
        elif self._runtime == ScriptRuntime.QJS:
            self._load_javascript()
        else:
            raise ValueError(f"Unsupported runtime: {self._runtime}")

        self._loaded = True

    def _load_python(self) -> None:
        """Execute Python script."""
        # Create execution namespace with Frida APIs
        namespace = {
            # Core APIs
            'Memory': Memory,
            'Interceptor': Interceptor,
            'Module': Module,
            'Process': Process,
            'NativePointer': NativePointer,
            'NativeFunction': NativeFunction,
            'NativeCallback': NativeCallback,
            'ApiResolver': ApiResolver,
            'Instruction': Instruction,
            'Stalker': Stalker,
            'Java': Java,

            # Convenience
            'ptr': lambda addr: NativePointer(addr),
            'NULL': NativePointer(0),

            # Console
            'console': _Console(self._send_message),
            'send': self._send_message,
            'recv': self._recv_message,

            # Exports container
            '__exports__': self._exports,

            # Emulator access
            '_emulator': self._emulator,
        }

        try:
            # SECURITY: exec() executes arbitrary code — only use with trusted input
            logger.warning("Executing user-provided code via exec() — ensure input is trusted")
            exec(self._source, namespace)

            # Collect exports
            if 'rpc' in namespace:
                self._exports = namespace['rpc'].get('exports', {})
        except Exception as e:
            logger.error(f"Script execution error: {e}")
            self._send_message({'type': 'error', 'description': str(e)})
            raise

    def _load_javascript(self) -> None:
        """Execute JavaScript script."""
        # Try different JS engines
        js_engine = self._get_js_engine()

        if js_engine is None:
            logger.warning("No JavaScript engine available, trying Python transpilation")
            self._transpile_and_execute()
            return

        js_engine.execute(self._source, self._build_js_context())

    def _get_js_engine(self):
        """Get an available JavaScript engine."""
        # Try QuickJS via quickjs package
        try:
            from .js_engines.quickjs_engine import QuickJSEngine
            return QuickJSEngine()
        except ImportError:
            pass

        # Try dukpy
        try:
            from .js_engines.dukpy_engine import DukpyEngine
            return DukpyEngine()
        except ImportError:
            pass

        # Try py_mini_racer
        try:
            from .js_engines.miniracer_engine import MiniRacerEngine
            return MiniRacerEngine()
        except ImportError:
            pass

        return None

    def _build_js_context(self) -> dict:
        """Build JavaScript execution context."""
        return {
            'Memory': Memory,
            'Interceptor': Interceptor,
            'Module': Module,
            'Process': Process,
            'NativePointer': NativePointer,
            'NativeFunction': NativeFunction,
            'NativeCallback': NativeCallback,
            'ptr': lambda addr: NativePointer(addr),
            'NULL': NativePointer(0),
            'console': _Console(self._send_message),
            'send': self._send_message,
            'recv': self._recv_message,
        }

    def _transpile_and_execute(self) -> None:
        """Transpile JS to Python and execute (fallback)."""
        # Simple transpilation for basic Frida scripts
        python_code = self._js_to_python(self._source)

        # Execute as Python
        old_source = self._source
        self._source = python_code
        try:
            self._load_python()
        finally:
            self._source = old_source

    def _js_to_python(self, js_code: str) -> str:
        """
        Simple JavaScript to Python transpilation.
        
        Handles basic Frida script patterns.
        """
        import re

        code = js_code

        # Function declarations
        code = re.sub(r'function\s+(\w+)\s*\(([^)]*)\)\s*{', r'def \1(\2):', code)
        code = re.sub(r'function\s*\(([^)]*)\)\s*{', r'lambda \1:', code)

        # Variable declarations
        code = re.sub(r'\b(var|let|const)\s+', '', code)

        # Arrow functions (simple cases)
        code = re.sub(r'\(([^)]*)\)\s*=>\s*{', r'lambda \1:', code)
        code = re.sub(r'(\w+)\s*=>\s*', r'lambda \1: ', code)

        # console.log -> print
        code = re.sub(r'console\.log\s*\(', 'print(', code)

        # String concatenation with +
        # (Python handles this, but we might need adjustment)

        # Semicolons
        code = code.replace(';', '')

        # Braces (very simplified - won't work for complex code)
        code = code.replace('{', '')
        code = code.replace('}', '')

        # this -> self
        code = code.replace('this.', 'self.')

        # true/false/null
        code = code.replace('true', 'True')
        code = code.replace('false', 'False')
        code = code.replace('null', 'None')

        return code

    def unload(self) -> None:
        """Unload the script."""
        if not self._loaded:
            return

        # Clean up hooks
        Interceptor.detachAll()
        Stalker.flush()

        self._loaded = False
        logger.info(f"Unloaded script '{self._name}'")

    def on(self, event: str, callback: Callable) -> Script:
        """
        Register event handler.
        
        Args:
            event: Event name ('message', 'destroyed')
            callback: Handler function
            
        Returns:
            self for chaining
        """
        if event == 'message':
            self._message_handler = callback
        return self

    def off(self, event: str, callback: Callable | None = None) -> Script:
        """Remove event handler."""
        if event == 'message':
            self._message_handler = None
        return self

    def post(self, message: Any, data: bytes | None = None) -> None:
        """
        Post message to script.
        
        Args:
            message: Message payload (will be JSON serialized)
            data: Optional binary data
        """
        # Would be handled by script's recv() handler
        pass

    def _send_message(self, payload: Any, data: bytes | None = None) -> None:
        """Internal: send message from script."""
        if self._message_handler:
            message = ScriptMessage(
                type='send',
                payload=payload
            )
            try:
                self._message_handler(message.__dict__, data)
            except Exception as e:
                logger.error(f"Message handler error: {e}")

    def _recv_message(self, callback: Callable) -> None:
        """Internal: register receive handler in script."""
        # Store for post() to use
        pass

    def eternalize(self) -> None:
        """Keep script alive after unload."""
        pass

    @property
    def is_destroyed(self) -> bool:
        """Check if script is destroyed."""
        return not self._loaded


class _Console:
    """Console API for scripts."""

    def __init__(self, send_fn: Callable):
        self._send = send_fn

    def log(self, *args) -> None:
        """Log message."""
        message = ' '.join(str(a) for a in args)
        print(f"[Script] {message}")
        self._send({'type': 'log', 'level': 'info', 'payload': message})

    def warn(self, *args) -> None:
        """Log warning."""
        message = ' '.join(str(a) for a in args)
        print(f"[Script WARN] {message}")
        self._send({'type': 'log', 'level': 'warning', 'payload': message})

    def error(self, *args) -> None:
        """Log error."""
        message = ' '.join(str(a) for a in args)
        print(f"[Script ERROR] {message}")
        self._send({'type': 'log', 'level': 'error', 'payload': message})

    def debug(self, *args) -> None:
        """Log debug message."""
        message = ' '.join(str(a) for a in args)
        logger.debug(f"[Script] {message}")

    def info(self, *args) -> None:
        """Alias for log."""
        self.log(*args)


# RPC exports helper
class rpc:
    """RPC exports decorator."""
    exports: dict[str, Callable] = {}

    @classmethod
    def export(cls, func: Callable) -> Callable:
        """Export a function for RPC."""
        cls.exports[func.__name__] = func
        return func
