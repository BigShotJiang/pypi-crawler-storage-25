"""
Interceptor - Frida-style function hooking.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class HookType(Enum):
    """Type of hook."""
    ATTACH = "attach"
    REPLACE = "replace"
    DETACH = "detach"


@dataclass
class InvocationArgs:
    """
    Arguments passed to hooked function.
    
    Frida-compatible args array that allows reading/modifying arguments.
    """
    _args: list[NativePointer] = field(default_factory=list)
    _emulator: Any | None = None

    def __getitem__(self, index: int) -> NativePointer:
        """Get argument by index."""
        if index < len(self._args):
            return self._args[index]
        return NativePointer(0)

    def __setitem__(self, index: int, value: int | NativePointer) -> None:
        """Set argument by index."""
        while len(self._args) <= index:
            self._args.append(NativePointer(0))
        if isinstance(value, int):
            self._args[index] = NativePointer(value)
        else:
            self._args[index] = value

    def __len__(self) -> int:
        return len(self._args)

    def __iter__(self):
        return iter(self._args)


@dataclass
class InvocationRetval:
    """
    Return value from hooked function.
    
    Allows reading and replacing the return value.
    """
    _value: NativePointer = field(default_factory=lambda: NativePointer(0))

    def replace(self, value: int | NativePointer) -> None:
        """Replace the return value."""
        if isinstance(value, int):
            self._value = NativePointer(value)
        else:
            self._value = value

    def toInt32(self) -> int:
        """Get return value as signed 32-bit int."""
        return self._value.toInt32()

    def toUInt32(self) -> int:
        """Get return value as unsigned 32-bit int."""
        return self._value.toUInt32()

    def toInt64(self) -> int:
        """Get return value as signed 64-bit int."""
        return self._value.toInt64()

    @property
    def value(self) -> NativePointer:
        """Get raw value."""
        return self._value

    def __str__(self) -> str:
        return str(self._value)


@dataclass
class InvocationContext:
    """
    Context for an intercepted function call.
    
    Provides access to:
    - CPU registers
    - Thread info
    - Return address
    - Context pointer (for data passing between onEnter/onLeave)
    """
    returnAddress: NativePointer
    threadId: int = 0
    depth: int = 0
    context: dict = field(default_factory=dict)
    _emulator: Any | None = None
    _registers: dict = field(default_factory=dict)

    def __getattr__(self, name: str) -> Any:
        """Access CPU registers by name (e.g., ctx.x0, ctx.pc)."""
        if name.startswith('_'):
            raise AttributeError(name)
        if name in self._registers:
            return NativePointer(self._registers[name])
        # Try to read from emulator
        if self._emulator:
            try:
                reg_val = self._emulator.reg_read(name)
                return NativePointer(reg_val)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        raise AttributeError(f"No register named '{name}'")

    def __setattr__(self, name: str, value: Any) -> None:
        """Set CPU register by name."""
        if name.startswith('_') or name in ('returnAddress', 'threadId', 'depth', 'context'):
            super().__setattr__(name, value)
            return

        # Set register value
        reg_val = value.address if isinstance(value, NativePointer) else value
        if hasattr(self, '_registers'):
            self._registers[name] = reg_val
        if hasattr(self, '_emulator') and self._emulator:
            try:
                self._emulator.reg_write(name, reg_val)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)


@dataclass
class InvocationListener:
    """Listener for function invocations."""
    target: NativePointer
    on_enter: Callable[[InvocationContext, InvocationArgs], None] | None = None
    on_leave: Callable[[InvocationContext, InvocationRetval], None] | None = None
    detached: bool = False


@dataclass
class ReplacementListener:
    """Listener for replaced functions."""
    target: NativePointer
    replacement: Callable
    original: NativePointer | None = None
    detached: bool = False


class Interceptor:
    """
    Frida-compatible Interceptor API.
    
    Provides function hooking capabilities:
    - attach: Hook function entry/exit
    - replace: Replace function entirely
    - detachAll: Remove all hooks
    - flush: Ensure hooks are active
    
    Usage:
        # Attach hook
        listener = Interceptor.attach(
            target=Module.findExportByName("libc.so", "open"),
            on_enter=lambda args: print(f"open({Memory.readUtf8String(args[0])})"),
            on_leave=lambda retval: print(f"=> {retval}")
        )
        
        # Using decorator
        @Interceptor.attach(target_addr)
        def on_open(args):
            print(f"open called with {args[0]}")
        
        # Replace function
        Interceptor.replace(
            target=func_addr,
            replacement=lambda: 42
        )
        
        # Detach
        listener.detach()
    """

    _emulator: Emulator | None = None
    _listeners: dict[int, InvocationListener] = {}
    _replacements: dict[int, ReplacementListener] = {}
    _hook_handles: dict[int, Any] = {}

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

    @classmethod
    def _get_emu(cls) -> Emulator:
        """Get emulator, raising error if not set."""
        if cls._emulator is None:
            raise RuntimeError("Interceptor.set_emulator() must be called first")
        return cls._emulator

    @classmethod
    def attach(cls, target: int | NativePointer | dict = None,
               on_enter: Callable | None = None,
               on_leave: Callable | None = None,
               **kwargs) -> InvocationListener | Callable:
        """
        Attach hooks to a function.
        
        Can be used as decorator or direct call:
        
        Direct:
            Interceptor.attach(addr, on_enter=..., on_leave=...)
        
        Dict style (Frida-compatible):
            Interceptor.attach(addr, {
                'onEnter': function(args) { ... },
                'onLeave': function(retval) { ... }
            })
        
        Decorator:
            @Interceptor.attach(addr)
            def hook(args):
                ...
        
        Args:
            target: Address to hook (int, NativePointer, or dict with callbacks)
            on_enter: Called on function entry with (context, args)
            on_leave: Called on function exit with (context, retval)
            
        Returns:
            InvocationListener or decorator function
        """
        # Handle decorator usage
        if target is None:
            def decorator(func):
                return cls.attach(func, on_enter=on_enter, on_leave=on_leave)
            return decorator

        # Handle dict-style callbacks (Frida JS compatibility)
        if isinstance(target, dict):
            # target is actually the callbacks dict
            callbacks = target
            actual_target = kwargs.get('_target')
            if actual_target is None:
                raise ValueError("Target address required")
            on_enter = callbacks.get('onEnter', callbacks.get('on_enter'))
            on_leave = callbacks.get('onLeave', callbacks.get('on_leave'))
            target = actual_target

        # Convert target to NativePointer
        if isinstance(target, int):
            target = NativePointer(target)

        # Create listener
        listener = InvocationListener(
            target=target,
            on_enter=on_enter,
            on_leave=on_leave
        )

        # Store listener
        cls._listeners[target.address] = listener

        # Install hook in emulator
        cls._install_hook(listener)

        logger.debug(f"Attached hook at {target}")
        return listener

    @classmethod
    def _install_hook(cls, listener: InvocationListener) -> None:
        """Install the actual hook in the emulator."""
        emu = cls._get_emu()

        def code_hook(uc, address, size, user_data):
            """Hook callback for function entry."""
            if listener.detached:
                return

            # Build context
            ctx = InvocationContext(
                returnAddress=NativePointer(emu.reg_read('lr')),
                threadId=0,  # Emulator is single-threaded
                depth=0,
                _emulator=emu
            )

            # Build args (first 8 args from registers for ARM64)
            args = InvocationArgs(_emulator=emu)
            if emu.is_64bit:
                for i in range(8):
                    try:
                        reg_val = emu.reg_read(f'x{i}')
                        args._args.append(NativePointer(reg_val))
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)
                        args._args.append(NativePointer(0))
            else:
                for i in range(4):
                    try:
                        reg_val = emu.reg_read(f'r{i}')
                        args._args.append(NativePointer(reg_val))
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)
                        args._args.append(NativePointer(0))

            # Call on_enter
            if listener.on_enter:
                try:
                    listener.on_enter(ctx, args)
                except Exception as e:
                    logger.error(f"on_enter hook error: {e}")

        # Add hook at address
        try:
            handle = emu.uc.hook_add(
                2,  # UC_HOOK_CODE
                code_hook,
                begin=listener.target.address,
                end=listener.target.address + 4
            )
            cls._hook_handles[listener.target.address] = handle
        except Exception as e:
            logger.error(f"Failed to install hook: {e}")

    @classmethod
    def detachAll(cls) -> None:
        """Detach all hooks."""
        emu = cls._get_emu()

        for addr, handle in cls._hook_handles.items():
            try:
                emu.uc.hook_del(handle)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        cls._hook_handles.clear()

        for listener in cls._listeners.values():
            listener.detached = True
        cls._listeners.clear()

        for replacement in cls._replacements.values():
            replacement.detached = True
        cls._replacements.clear()

        logger.debug("Detached all hooks")

    @classmethod
    def replace(cls, target: int | NativePointer,
                replacement: Callable,
                data: NativePointer | None = None) -> ReplacementListener:
        """
        Replace a function entirely.
        
        Args:
            target: Address of function to replace
            replacement: Python function to call instead
            data: Optional data pointer
            
        Returns:
            ReplacementListener with .original pointer to call original
        """
        if isinstance(target, int):
            target = NativePointer(target)

        listener = ReplacementListener(
            target=target,
            replacement=replacement,
            original=target  # In emulator, we can still call original
        )

        cls._replacements[target.address] = listener
        cls._install_replacement(listener)

        logger.debug(f"Replaced function at {target}")
        return listener

    @classmethod
    def _install_replacement(cls, listener: ReplacementListener) -> None:
        """Install function replacement."""
        emu = cls._get_emu()

        def replacement_hook(uc, address, size, user_data):
            """Hook that replaces the function."""
            if listener.detached:
                return

            # Call replacement and get result
            try:
                result = listener.replacement()

                # Set return value in appropriate register
                if emu.is_64bit:
                    if result is not None:
                        ret_val = result.address if isinstance(result, NativePointer) else result
                        emu.reg_write('x0', ret_val)
                    # Return to caller
                    lr = emu.reg_read('lr')
                    emu.reg_write('pc', lr)
                else:
                    if result is not None:
                        ret_val = result.address if isinstance(result, NativePointer) else result
                        emu.reg_write('r0', ret_val)
                    lr = emu.reg_read('lr')
                    emu.reg_write('pc', lr)
            except Exception as e:
                logger.error(f"Replacement function error: {e}")

        try:
            handle = emu.uc.hook_add(
                2,  # UC_HOOK_CODE
                replacement_hook,
                begin=listener.target.address,
                end=listener.target.address + 4
            )
            cls._hook_handles[listener.target.address] = handle
        except Exception as e:
            logger.error(f"Failed to install replacement: {e}")

    @classmethod
    def revert(cls, target: int | NativePointer) -> None:
        """Revert a replaced function to original."""
        addr = target.address if isinstance(target, NativePointer) else target

        if addr in cls._replacements:
            listener = cls._replacements[addr]
            listener.detached = True
            del cls._replacements[addr]

        if addr in cls._hook_handles:
            try:
                cls._get_emu().uc.hook_del(cls._hook_handles[addr])
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            del cls._hook_handles[addr]

    @classmethod
    def flush(cls) -> None:
        """Flush pending hooks (ensure they're active)."""
        # In our implementation, hooks are immediately active
        pass


# Convenience decorators
def on_enter(target: int | NativePointer):
    """Decorator to hook function entry."""
    def decorator(func):
        Interceptor.attach(target, on_enter=lambda ctx, args: func(args))
        return func
    return decorator


def on_leave(target: int | NativePointer):
    """Decorator to hook function exit."""
    def decorator(func):
        Interceptor.attach(target, on_leave=lambda ctx, retval: func(retval))
        return func
    return decorator
