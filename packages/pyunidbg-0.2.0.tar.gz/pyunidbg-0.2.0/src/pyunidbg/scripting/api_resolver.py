"""
ApiResolver - Frida-style API resolution.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

from .module import Module
from .native_pointer import NativePointer

if TYPE_CHECKING:
    from ..core.emulator import Emulator


@dataclass
class ApiMatch:
    """Match result from API resolution."""
    name: str
    address: NativePointer


class ApiResolver:
    """
    Frida-compatible ApiResolver.
    
    Resolves API names to addresses using pattern matching.
    
    Supported types:
    - 'module': Search module exports
    - 'objc': Search Objective-C methods (iOS)
    - 'java': Search Java methods (Android)
    
    Usage:
        resolver = ApiResolver('module')
        
        # Find all exports matching pattern
        for match in resolver.enumerateMatches('exports:*!open*'):
            print(f"{match.name}: {match.address}")
        
        # Find specific export
        matches = resolver.enumerateMatches('exports:libc.so!malloc')
    """

    _emulator: Emulator | None = None

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

    def __init__(self, type_: str = 'module'):
        """
        Create an ApiResolver.
        
        Args:
            type_: Resolver type ('module', 'objc', 'java')
        """
        self.type = type_

    def enumerateMatches(self, query: str) -> list[ApiMatch]:
        """
        Enumerate all matches for a query.
        
        Query format for 'module' type:
            'exports:*!open*'        - All exports containing 'open'
            'exports:libc.so!*'      - All exports from libc.so
            'exports:libc.so!malloc' - Specific export
            'imports:*!printf'       - All imports named printf
        
        Args:
            query: Query string
            
        Returns:
            List of matches
        """
        matches = []

        if self.type == 'module':
            matches = self._enumerate_module_matches(query)
        elif self.type == 'objc':
            matches = self._enumerate_objc_matches(query)
        elif self.type == 'java':
            matches = self._enumerate_java_matches(query)

        return matches

    def _enumerate_module_matches(self, query: str) -> list[ApiMatch]:
        """Enumerate module export/import matches."""
        matches = []

        # Parse query: 'exports:module!symbol' or 'imports:module!symbol'
        if ':' in query:
            query_type, pattern = query.split(':', 1)
        else:
            query_type = 'exports'
            pattern = query

        # Parse module and symbol pattern
        if '!' in pattern:
            module_pattern, symbol_pattern = pattern.split('!', 1)
        else:
            module_pattern = '*'
            symbol_pattern = pattern

        # Convert glob patterns to regex
        module_re = self._glob_to_regex(module_pattern)
        symbol_re = self._glob_to_regex(symbol_pattern)

        # Search modules
        for mod in Module.enumerateModules():
            if not module_re.match(mod.name):
                continue

            if query_type == 'exports':
                for export in mod.enumerateExports():
                    if symbol_re.match(export.name):
                        matches.append(ApiMatch(
                            name=f"{mod.name}!{export.name}",
                            address=export.address
                        ))
            elif query_type == 'imports':
                for import_ in mod.enumerateImports():
                    if symbol_re.match(import_.name):
                        matches.append(ApiMatch(
                            name=f"{mod.name}!{import_.name}",
                            address=import_.address or NativePointer(0)
                        ))

        return matches

    def _enumerate_objc_matches(self, query: str) -> list[ApiMatch]:
        """Enumerate Objective-C method matches."""
        # Format: '+[NSString stringWithUTF8String:]' or '-[NSObject init]'
        # Not implemented for Android emulator
        return []

    def _enumerate_java_matches(self, query: str) -> list[ApiMatch]:
        """Enumerate Java method matches."""
        # Would integrate with Java bridge
        return []

    def _glob_to_regex(self, pattern: str) -> re.Pattern:
        """Convert glob pattern to regex."""
        # Escape special regex characters except * and ?
        escaped = re.escape(pattern)
        # Convert glob wildcards to regex
        escaped = escaped.replace(r'\*', '.*')
        escaped = escaped.replace(r'\?', '.')
        return re.compile(f'^{escaped}$', re.IGNORECASE)


class ModuleMap:
    """
    Frida-compatible ModuleMap.
    
    Maintains a map of modules for efficient lookup.
    
    Usage:
        map = ModuleMap()
        map.update()
        
        module = map.find(address)
        name = map.findName(address)
        path = map.findPath(address)
    """

    _emulator: Emulator | None = None

    @classmethod
    def set_emulator(cls, emulator: Emulator) -> None:
        """Set the global emulator instance."""
        cls._emulator = emulator

    def __init__(self):
        """Create a ModuleMap."""
        self._modules = []
        self.update()

    def update(self) -> None:
        """Update the module map."""
        self._modules = Module.enumerateModules()

    def has(self, address: int | NativePointer) -> bool:
        """Check if address belongs to any module."""
        return self.find(address) is not None

    def find(self, address: int | NativePointer) -> dict | None:
        """
        Find module containing address.
        
        Returns:
            Dict with 'name', 'base', 'size', 'path' or None
        """
        addr = address.address if isinstance(address, NativePointer) else address

        for mod in self._modules:
            if mod.base.address <= addr < mod.base.address + mod.size:
                return {
                    'name': mod.name,
                    'base': mod.base,
                    'size': mod.size,
                    'path': mod.path
                }

        return None

    def findName(self, address: int | NativePointer) -> str | None:
        """Find module name for address."""
        result = self.find(address)
        return result['name'] if result else None

    def findPath(self, address: int | NativePointer) -> str | None:
        """Find module path for address."""
        result = self.find(address)
        return result['path'] if result else None

    def get(self, name: str) -> dict | None:
        """Get module by name."""
        for mod in self._modules:
            if mod.name == name or name in mod.name:
                return {
                    'name': mod.name,
                    'base': mod.base,
                    'size': mod.size,
                    'path': mod.path
                }
        return None

    def values(self) -> list[dict]:
        """Get all modules as dicts."""
        return [
            {
                'name': mod.name,
                'base': mod.base,
                'size': mod.size,
                'path': mod.path
            }
            for mod in self._modules
        ]


# Convenience function
def DebugSymbol_fromAddress(address: int | NativePointer) -> dict:
    """
    Get debug symbol information for address.
    
    Returns:
        Dict with 'address', 'name', 'moduleName', 'fileName', 'lineNumber'
    """
    addr = address.address if isinstance(address, NativePointer) else address

    # Find module
    mod = Module.findModuleByAddress(addr)
    if mod is None:
        return {
            'address': NativePointer(addr),
            'name': None,
            'moduleName': None,
            'fileName': None,
            'lineNumber': None
        }

    # Try to find symbol
    offset = addr - mod.base.address
    symbol_name = None

    for sym in mod.enumerateSymbols():
        if sym.address.address == addr:
            symbol_name = sym.name
            break

    return {
        'address': NativePointer(addr),
        'name': symbol_name,
        'moduleName': mod.name,
        'fileName': None,  # Would need DWARF info
        'lineNumber': None
    }


def DebugSymbol_fromName(name: str) -> NativePointer | None:
    """Get address for symbol name."""
    return Module.findSymbolByName(None, name)


def DebugSymbol_getFunctionByName(name: str) -> NativePointer | None:
    """Get function address by name."""
    return Module.findExportByName(None, name)


class DebugSymbol:
    """Static class for debug symbol operations."""
    fromAddress = staticmethod(DebugSymbol_fromAddress)
    fromName = staticmethod(DebugSymbol_fromName)
    getFunctionByName = staticmethod(DebugSymbol_getFunctionByName)
