"""Allow running CLI as python -m pyunidbg.cli"""
from pyunidbg.cli import run_cli

if __name__ == "__main__":
    run_cli()
