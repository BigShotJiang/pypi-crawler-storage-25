"""
PyUniDbg Command Line Interface.

A comprehensive CLI tool for interacting with PyUniDbg from the terminal.

Usage:
    pyunidbg run <library.so> [--function <name>] [--args <args>] [--trace]
    pyunidbg call <library.so> -f <function> --args <args> [--context]
    pyunidbg analyze <library.so> [--coverage] [--trace] [--taint]
    pyunidbg debug <library.so> [-p <port>]
    pyunidbg info <library.so>
    pyunidbg disasm <library.so> [--function <name>] [--address <addr>] [--syntax <intel|att>]
    pyunidbg hook <library.so> -s <script.py> [-f <name>]
    pyunidbg export <library.so> -o <file> --format <json|html|drcov|markdown> --type <info|coverage|trace|report>
    pyunidbg config [--show] [--set <key>=<value>] [--get <key>]
    pyunidbg scan <library.so> [--jni] [--exports] [--apk <file>] [--json]
    pyunidbg version [--json]

Examples:
    # Call a JNI function and get the result
    pyunidbg call libnative.so -f Java_com_example_getSign --context \\
        --args search '{"key":"value"}' uuid123 android 12.0

    # Call with JSON from file (@file syntax)
    pyunidbg call libnative.so -f Java_com_example_getSign --context \\
        --args search @request.json uuid123 --raw

    # Run a library and call JNI_OnLoad
    pyunidbg run libnative.so

    # Run with instruction tracing
    pyunidbg run libnative.so -f myFunction --trace

    # Scan for JNI functions with full signatures from APK
    pyunidbg scan libnative.so --jni --apk app.apk --with-address

    # List all exported functions with C++ demangling
    pyunidbg scan libnative.so --exports --demangle

    # Analyze with coverage tracking
    pyunidbg analyze libnative.so --coverage --output coverage.drcov

    # Analyze with taint tracking
    pyunidbg analyze libnative.so --taint -f targetFunc

    # Start GDB server for remote debugging
    pyunidbg debug libnative.so -p 1234

    # Export coverage data in drcov format
    pyunidbg export libnative.so -o cov.drcov --format drcov --type coverage

    # Disable colored output
    pyunidbg --no-color info libnative.so --exports
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

# Rich for beautiful terminal output
try:
    from rich.console import Console
    from rich.logging import RichHandler
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.syntax import Syntax
    from rich.table import Table
    from rich.tree import Tree
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

__all__ = [
    "CLI",
    "CLICommand",
    "CLIContext",
    "CallCommand",
    "RunCommand",
    "AnalyzeCommand",
    "DebugCommand",
    "InfoCommand",
    "DisasmCommand",
    "HookCommand",
    "ExportCommand",
    "ConfigCommand",
    "VersionCommand",
    "ScanCommand",
    "Console_",
    "WebCommand",
    "main",
    "run_cli",
]

logger = logging.getLogger(__name__)


# ==================== Logging Setup ====================

def setup_logging(verbose: bool = False, quiet: bool = False) -> logging.Logger:
    """Setup logging with optional rich handler."""
    level = logging.DEBUG if verbose else (logging.WARNING if quiet else logging.INFO)

    if RICH_AVAILABLE:
        logging.basicConfig(
            level=level,
            format="%(message)s",
            handlers=[RichHandler(rich_tracebacks=True, show_path=False)]
        )
    else:
        logging.basicConfig(
            level=level,
            format="%(asctime)s - %(levelname)s - %(message)s"
        )

    return logging.getLogger("pyunidbg.cli")


# ==================== Console Helpers ====================

class Console_:
    """Console wrapper that works with or without Rich."""

    def __init__(self, no_color: bool = False):
        self._no_color = no_color
        if RICH_AVAILABLE and not no_color:
            self._console = Console()
        else:
            self._console = None

    def set_no_color(self, no_color: bool) -> None:
        """Reconfigure color output at runtime."""
        self._no_color = no_color
        if no_color:
            self._console = None
        elif RICH_AVAILABLE:
            self._console = Console()

    def print(self, *args, **kwargs):
        if self._console:
            self._console.print(*args, **kwargs)
        else:
            # Strip rich markup for plain output
            text = " ".join(str(a) for a in args)
            print(text)

    def print_json(self, data: Any):
        if self._console:
            self._console.print_json(json.dumps(data, indent=2, default=str))
        else:
            print(json.dumps(data, indent=2, default=str))

    def print_table(self, title: str, columns: list[str], rows: list[list[str]]):
        if RICH_AVAILABLE:
            table = Table(title=title)
            for col in columns:
                table.add_column(col)
            for row in rows:
                table.add_row(*[str(r) for r in row])
            self._console.print(table)
        else:
            print(f"\n{title}")
            print("-" * len(title))
            print("\t".join(columns))
            for row in rows:
                print("\t".join(str(r) for r in row))

    def print_panel(self, content: str, title: str = ""):
        if RICH_AVAILABLE:
            self._console.print(Panel(content, title=title))
        else:
            print(f"\n{'=' * 40}")
            if title:
                print(f" {title}")
                print("-" * 40)
            print(content)
            print("=" * 40)

    def print_error(self, message: str):
        if RICH_AVAILABLE:
            self._console.print(f"[bold red]Error:[/bold red] {message}")
        else:
            print(f"Error: {message}", file=sys.stderr)

    def print_success(self, message: str):
        if RICH_AVAILABLE:
            self._console.print(f"[bold green]✓[/bold green] {message}")
        else:
            print(f"✓ {message}")

    def print_warning(self, message: str):
        if RICH_AVAILABLE:
            self._console.print(f"[bold yellow]Warning:[/bold yellow] {message}")
        else:
            print(f"Warning: {message}")

    def print_info(self, message: str):
        if RICH_AVAILABLE:
            self._console.print(f"[bold blue]ℹ[/bold blue] {message}")
        else:
            print(f"ℹ {message}")

    def print_tree(self, title: str, items: dict[str, Any]):
        """Print a tree structure."""
        if RICH_AVAILABLE:
            tree = Tree(title)
            self._add_tree_items(tree, items)
            self._console.print(tree)
        else:
            print(f"\n{title}")
            self._print_tree_plain(items, indent=0)

    def _add_tree_items(self, tree, items: dict[str, Any]):
        """Recursively add items to rich Tree."""
        for key, value in items.items():
            if isinstance(value, dict):
                branch = tree.add(str(key))
                self._add_tree_items(branch, value)
            elif isinstance(value, list):
                branch = tree.add(str(key))
                for item in value:
                    if isinstance(item, dict):
                        self._add_tree_items(branch, item)
                    else:
                        branch.add(str(item))
            else:
                tree.add(f"{key}: {value}")

    def _print_tree_plain(self, items: dict[str, Any], indent: int):
        """Print tree in plain text."""
        prefix = "  " * indent
        for key, value in items.items():
            if isinstance(value, dict):
                print(f"{prefix}├─ {key}")
                self._print_tree_plain(value, indent + 1)
            elif isinstance(value, list):
                print(f"{prefix}├─ {key}")
                for item in value:
                    if isinstance(item, dict):
                        self._print_tree_plain(item, indent + 1)
                    else:
                        print(f"{prefix}  ├─ {item}")
            else:
                print(f"{prefix}├─ {key}: {value}")


console = Console_()


# ==================== CLI Context ====================

@dataclass
class CLIContext:
    """Context passed to CLI commands."""
    args: argparse.Namespace
    config: dict[str, Any] = field(default_factory=dict)
    verbose: bool = False
    quiet: bool = False
    output_format: str = "text"
    logger: logging.Logger | None = None

    def __post_init__(self):
        if self.logger is None:
            self.logger = setup_logging(self.verbose, self.quiet)


# ==================== Command Classes ====================

class CLICommand:
    """Base class for CLI commands."""

    name: str = ""
    description: str = ""
    aliases: list[str] = []

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """Add command-specific arguments."""
        pass

    def run(self, ctx: CLIContext) -> int:
        """Execute the command. Returns exit code."""
        raise NotImplementedError


class RunCommand(CLICommand):
    """Run a library and optionally call functions."""

    name = "run"
    description = "Run a native library in the emulator"
    aliases = ["r", "exec"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("-f", "--function", help="Function to call")
        parser.add_argument("-a", "--args", nargs="*", help="Arguments to pass")
        parser.add_argument("--arch", choices=["arm", "arm64"], default="arm64",
                           help="Architecture (default: arm64)")
        parser.add_argument("--api-level", type=int, default=29,
                           help="Android API level (default: 29)")
        parser.add_argument("--no-jni-onload", action="store_true",
                           help="Don't call JNI_OnLoad")
        parser.add_argument("--timeout", type=int, default=0,
                           help="Execution timeout in seconds")
        parser.add_argument("--trace", action="store_true",
                           help="Enable instruction tracing")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg.android import AndroidEmulator

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        console.print_info(f"Loading {library_path.name}...")

        try:
            emu = AndroidEmulator(
                arch=ctx.args.arch,
                api_level=ctx.args.api_level
            )

            # Enable instruction tracing if requested
            if ctx.args.trace:
                try:
                    from pyunidbg.analysis import InstructionTracer
                    tracer = InstructionTracer(emu)
                    tracer.start()
                    console.print_info("Instruction tracing enabled")
                except ImportError:
                    console.print_warning("Tracing requires pyunidbg.analysis module")

            # Load library
            module = emu.load_library(
                str(library_path),
                call_jni_onload=not ctx.args.no_jni_onload
            )

            console.print_success(f"Loaded {module.name} at {module.base_address:#x}")

            # Call function if specified
            if ctx.args.function:
                func_addr = module.get_function_address(ctx.args.function)
                if func_addr is None:
                    console.print_error(f"Function not found: {ctx.args.function}")
                    return 1

                console.print_info(f"Calling {ctx.args.function} at {func_addr:#x}")

                # Parse arguments
                args = []
                if ctx.args.args:
                    for arg in ctx.args.args:
                        if arg.startswith("0x"):
                            args.append(int(arg, 16))
                        elif arg.isdigit():
                            args.append(int(arg))
                        else:
                            # Treat as string
                            args.append(emu.alloc_string(arg))

                result = emu.call(func_addr, args)
                console.print_success(f"Result: {result:#x} ({result})")

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1


class CallCommand(CLICommand):
    """Call a JNI function and get the result."""

    name = "call"
    description = "Call a JNI function in a native library and print the result"
    aliases = ["c", "invoke"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("-f", "--function", required=True,
                           help="Function name to call (e.g., Java_com_example_Native_method)")
        parser.add_argument("-a", "--args", nargs="*", default=[],
                           help="Arguments to pass (strings, numbers, or key=value for JSON)")
        parser.add_argument("--apk", help="APK file for package context")
        parser.add_argument("--package", help="Package name (default: from APK)")
        parser.add_argument("--arch", choices=["arm", "arm64"], default="arm64",
                           help="Architecture (default: arm64)")
        parser.add_argument("--context", action="store_true",
                           help="Include Android Context as first arg")
        parser.add_argument("--json-arg", action="append", default=[],
                           help="JSON object argument (can be repeated)")
        parser.add_argument("--raw", action="store_true",
                           help="Print raw result without formatting")
        parser.add_argument("--output", "-o", help="Save result to file")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg.android import NativeLibrary

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        try:
            # Determine package name
            package_name = ctx.args.package
            if not package_name and ctx.args.apk:
                # Try to extract from APK
                try:
                    from androguard.core.apk import APK
                    apk = APK(ctx.args.apk)
                    package_name = apk.get_package()
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)
                    package_name = "com.example.app"

            if not package_name:
                package_name = "com.example.app"

            console.print_info(f"Loading {library_path.name}...")

            # Create NativeLibrary
            lib = NativeLibrary(
                str(library_path),
                arch=ctx.args.arch,
                apk_path=ctx.args.apk,
                package_name=package_name,
            )

            console.print_success("Loaded library")

            # Parse arguments - maintain order, handle different types
            call_args = []

            for arg in ctx.args.args:
                parsed = self._parse_arg(arg)
                call_args.append(parsed)

            # Insert JSON args at their positions (append if no position specified)
            for json_str in ctx.args.json_arg:
                call_args.append(json.loads(json_str))

            console.print_info(f"Calling {ctx.args.function}...")
            if call_args:
                console.print_info(f"Arguments: {call_args}")

            # Call function
            result = lib.call(
                ctx.args.function,
                *call_args,
                context=ctx.args.context,
            )

            # Output result
            if ctx.args.raw:
                print(result)
            else:
                console.print_success(f"Result: {result}")

            # Save to file if requested
            if ctx.args.output:
                with open(ctx.args.output, 'w') as f:
                    f.write(str(result))
                console.print_info(f"Saved to {ctx.args.output}")

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1

    def _parse_arg(self, arg: str):
        """Parse a single argument into appropriate type."""
        # Hex number
        if arg.startswith("0x"):
            return int(arg, 16)

        # Integer
        if arg.isdigit() or (arg.startswith("-") and arg[1:].isdigit()):
            return int(arg)

        # JSON object or array
        if arg.startswith("{") or arg.startswith("["):
            return json.loads(arg)

        # File reference @filename.json
        if arg.startswith("@"):
            filepath = arg[1:]
            with open(filepath) as f:
                content = f.read()
                # Try to parse as JSON
                try:
                    return json.loads(content)
                except (json.JSONDecodeError, ValueError):
                    return content.strip()

        # Boolean
        if arg.lower() == "true":
            return True
        if arg.lower() == "false":
            return False

        # null
        if arg.lower() == "null":
            return None

        # Default: string
        return arg


class AnalyzeCommand(CLICommand):
    """Analyze a library with various tools."""

    name = "analyze"
    description = "Analyze a library with coverage, tracing, or taint analysis"
    aliases = ["a", "analyse"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("--coverage", action="store_true",
                           help="Enable code coverage tracking")
        parser.add_argument("--trace", action="store_true",
                           help="Enable instruction tracing")
        parser.add_argument("--taint", action="store_true",
                           help="Enable taint analysis")
        parser.add_argument("-f", "--function", help="Function to analyze")
        parser.add_argument("-o", "--output", help="Output file path")
        parser.add_argument("--format", choices=["json", "drcov", "lcov", "html"],
                           default="json", help="Output format")
        parser.add_argument("--arch", choices=["arm", "arm64"], default="arm64")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg.analysis import CoverageTracker, InstructionTracer
        from pyunidbg.android import AndroidEmulator

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        try:
            emu = AndroidEmulator(arch=ctx.args.arch)
            module = emu.load_library(str(library_path))

            console.print_success(f"Loaded {module.name}")

            # Setup analysis
            coverage = None
            tracer = None

            if ctx.args.coverage:
                coverage = CoverageTracker(emu)
                coverage.start()
                console.print_info("Coverage tracking enabled")

            if ctx.args.trace:
                tracer = InstructionTracer(emu)
                tracer.start()
                console.print_info("Instruction tracing enabled")

            taint_engine = None
            if ctx.args.taint:
                try:
                    from pyunidbg.analysis import TaintEngine
                    taint_engine = TaintEngine(emu)
                    taint_engine.start()
                    console.print_info("Taint analysis enabled")
                except ImportError:
                    console.print_warning("Taint analysis requires pyunidbg.analysis.TaintEngine")

            # Run function if specified
            if ctx.args.function:
                func_addr = module.get_function_address(ctx.args.function)
                if func_addr:
                    console.print_info(f"Analyzing {ctx.args.function}...")
                    emu.call(func_addr)

            # Stop and export
            if coverage:
                coverage.stop()
                stats = coverage.get_stats()

                console.print_table(
                    "Coverage Statistics",
                    ["Metric", "Value"],
                    [
                        ["Unique Blocks", str(stats.unique_blocks)],
                        ["Total Blocks", str(stats.total_blocks)],
                        ["Unique Instructions", str(stats.unique_instructions)],
                    ]
                )

                if ctx.args.output:
                    output_path = Path(ctx.args.output)
                    if ctx.args.format == "drcov":
                        coverage.export_drcov(str(output_path))
                    elif ctx.args.format == "lcov":
                        coverage.export_lcov(str(output_path))
                    elif ctx.args.format == "html":
                        coverage.export_html(str(output_path))
                    else:
                        coverage.export_json(str(output_path))
                    console.print_success(f"Exported to {output_path}")

            if tracer:
                tracer.stop()
                if ctx.args.output and not coverage:
                    tracer.export(ctx.args.output)

            if taint_engine:
                taint_engine.stop()
                results = taint_engine.get_results()
                console.print_table(
                    "Taint Analysis Results",
                    ["Source", "Sink", "Path Length"],
                    [
                        [str(r.get("source", "")), str(r.get("sink", "")), str(r.get("path_length", 0))]
                        for r in results
                    ] if results else [["No taint flows detected", "", ""]]
                )
                if ctx.args.output and not coverage and not tracer:
                    taint_engine.export(ctx.args.output)

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1


class DebugCommand(CLICommand):
    """Start GDB server for remote debugging."""

    name = "debug"
    description = "Start a GDB server for remote debugging"
    aliases = ["d", "gdb"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("-p", "--port", type=int, default=1234,
                           help="GDB server port (default: 1234)")
        parser.add_argument("--host", default="localhost",
                           help="GDB server host (default: localhost)")
        parser.add_argument("--arch", choices=["arm", "arm64"], default="arm64")
        parser.add_argument("-b", "--breakpoint", action="append",
                           help="Set breakpoint at address or function name")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg.android import AndroidEmulator
        from pyunidbg.debug import GDBServer

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        try:
            emu = AndroidEmulator(arch=ctx.args.arch)
            module = emu.load_library(str(library_path))

            console.print_success(f"Loaded {module.name}")

            # Setup GDB server
            gdb = GDBServer(emu, host=ctx.args.host, port=ctx.args.port)

            # Set breakpoints
            if ctx.args.breakpoint:
                for bp in ctx.args.breakpoint:
                    if bp.startswith("0x"):
                        addr = int(bp, 16)
                    else:
                        addr = module.get_function_address(bp)
                        if addr is None:
                            console.print_warning(f"Function not found: {bp}")
                            continue
                    gdb.set_breakpoint(addr)
                    console.print_info(f"Breakpoint set at {addr:#x}")

            console.print_panel(
                f"GDB server listening on {ctx.args.host}:{ctx.args.port}\n\n"
                f"Connect with:\n"
                f"  gdb -ex 'target remote {ctx.args.host}:{ctx.args.port}'\n\n"
                f"Or in IDA Pro:\n"
                f"  Debugger -> Attach -> Remote GDB",
                title="GDB Server Ready"
            )

            gdb.start()  # Blocks until connection closes

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1


class InfoCommand(CLICommand):
    """Show information about a library."""

    name = "info"
    description = "Display information about a native library"
    aliases = ["i", "show"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("--symbols", action="store_true",
                           help="List all symbols")
        parser.add_argument("--exports", action="store_true",
                           help="List exported symbols only")
        parser.add_argument("--imports", action="store_true",
                           help="List imported symbols")
        parser.add_argument("--sections", action="store_true",
                           help="List sections")
        parser.add_argument("--deps", action="store_true",
                           help="List dependencies")
        parser.add_argument("--json", action="store_true",
                           help="Output as JSON")

    def run(self, ctx: CLIContext) -> int:
        import lief

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        try:
            elf = lief.parse(str(library_path))
            if elf is None:
                console.print_error("Failed to parse ELF file")
                return 1

            info = {
                "name": library_path.name,
                "path": str(library_path.absolute()),
                "type": elf.header.file_type.name,
                "machine": elf.header.machine_type.name,
                "entry_point": hex(elf.header.entrypoint),
                "sections_count": len(list(elf.sections)),
                "symbols_count": len(list(elf.symbols)),
            }

            if ctx.args.json:
                console.print_json(info)
                return 0

            # Basic info
            console.print_panel(
                f"Name: {info['name']}\n"
                f"Type: {info['type']}\n"
                f"Architecture: {info['machine']}\n"
                f"Entry Point: {info['entry_point']}\n"
                f"Sections: {info['sections_count']}\n"
                f"Symbols: {info['symbols_count']}",
                title="Library Information"
            )

            # Dependencies
            if ctx.args.deps or not any([ctx.args.symbols, ctx.args.exports,
                                          ctx.args.imports, ctx.args.sections]):
                deps = [lib for lib in elf.libraries]
                if deps:
                    console.print_table(
                        "Dependencies",
                        ["Library"],
                        [[d] for d in deps]
                    )

            # Sections
            if ctx.args.sections:
                sections = []
                for sec in elf.sections:
                    sections.append([
                        sec.name,
                        f"{sec.virtual_address:#x}",
                        f"{sec.size:#x}",
                        sec.type.name
                    ])
                console.print_table(
                    "Sections",
                    ["Name", "Address", "Size", "Type"],
                    sections
                )

            # Symbols
            if ctx.args.symbols or ctx.args.exports:
                symbols = []
                for sym in elf.symbols:
                    if ctx.args.exports and sym.binding.name != "GLOBAL":
                        continue
                    symbols.append([
                        sym.name[:50] + "..." if len(sym.name) > 50 else sym.name,
                        f"{sym.value:#x}",
                        sym.type.name,
                        sym.binding.name
                    ])
                console.print_table(
                    "Symbols" if ctx.args.symbols else "Exports",
                    ["Name", "Address", "Type", "Binding"],
                    symbols[:50]  # Limit output
                )
                if len(symbols) > 50:
                    console.print_info(f"... and {len(symbols) - 50} more symbols")

            # Imports
            if ctx.args.imports:
                imports = []
                for sym in elf.imported_symbols:
                    imports.append([sym.name, sym.type.name])
                console.print_table(
                    "Imports",
                    ["Name", "Type"],
                    imports[:50]
                )
                if len(imports) > 50:
                    console.print_info(f"... and {len(imports) - 50} more imports")

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1


class DisasmCommand(CLICommand):
    """Disassemble code from a library."""

    name = "disasm"
    description = "Disassemble code from a native library"
    aliases = ["dis", "disassemble"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("-f", "--function", help="Function to disassemble")
        parser.add_argument("-a", "--address", help="Address to disassemble")
        parser.add_argument("-n", "--count", type=int, default=20,
                           help="Number of instructions (default: 20)")
        parser.add_argument("--arch", choices=["arm", "arm64"], default="arm64")
        parser.add_argument("--syntax", choices=["intel", "att"], default="intel")

    def run(self, ctx: CLIContext) -> int:
        import lief
        from capstone import CS_ARCH_ARM, CS_ARCH_ARM64, CS_MODE_ARM, CS_OPT_SYNTAX_ATT, Cs

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        try:
            elf = lief.parse(str(library_path))
            if elf is None:
                console.print_error("Failed to parse ELF file")
                return 1

            # Setup Capstone
            if ctx.args.arch == "arm64":
                cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM)
            else:
                cs = Cs(CS_ARCH_ARM, CS_MODE_ARM)

            if ctx.args.syntax == "att":
                cs.syntax = CS_OPT_SYNTAX_ATT

            # Find address to disassemble
            if ctx.args.function:
                for sym in elf.symbols:
                    if sym.name == ctx.args.function:
                        address = sym.value
                        size = sym.size if sym.size > 0 else 256
                        break
                else:
                    console.print_error(f"Function not found: {ctx.args.function}")
                    return 1
            elif ctx.args.address:
                address = int(ctx.args.address, 16) if ctx.args.address.startswith("0x") else int(ctx.args.address)
                size = ctx.args.count * 4  # Estimate
            else:
                address = elf.header.entrypoint
                size = ctx.args.count * 4

            # Read code
            code = bytes(elf.get_content_from_virtual_address(address, size))

            # Disassemble
            console.print_panel(
                f"Disassembly at {address:#x}",
                title=ctx.args.function or f"Address {address:#x}"
            )

            instructions = []
            for insn in cs.disasm(code, address):
                instructions.append([
                    f"{insn.address:#x}",
                    insn.bytes.hex(),
                    insn.mnemonic,
                    insn.op_str
                ])
                if len(instructions) >= ctx.args.count:
                    break

            console.print_table(
                "",
                ["Address", "Bytes", "Mnemonic", "Operands"],
                instructions
            )

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1


class HookCommand(CLICommand):
    """Run a library with a Python hook script."""

    name = "hook"
    description = "Run a library with custom Python hooks"
    aliases = ["h"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("-s", "--script", required=True,
                           help="Python hook script")
        parser.add_argument("-f", "--function", help="Function to call after hooks")
        parser.add_argument("--arch", choices=["arm", "arm64"], default="arm64")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg.android import AndroidEmulator

        library_path = Path(ctx.args.library)
        script_path = Path(ctx.args.script)

        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        if not script_path.exists():
            console.print_error(f"Script not found: {script_path}")
            return 1

        try:
            emu = AndroidEmulator(arch=ctx.args.arch)
            module = emu.load_library(str(library_path), call_jni_onload=False)

            console.print_success(f"Loaded {module.name}")

            # Execute hook script with emulator in scope
            script_globals = {
                "emu": emu,
                "module": module,
                "console": console,
                "__name__": "__main__",
            }

            console.print_info(f"Executing hook script: {script_path.name}")
            # SECURITY: exec() executes arbitrary code — only use with trusted input
            logger.warning("Executing user-provided code via exec() — ensure input is trusted")
            exec(script_path.read_text(), script_globals)

            # Optionally call function
            if ctx.args.function:
                func_addr = module.get_function_address(ctx.args.function)
                if func_addr:
                    console.print_info(f"Calling {ctx.args.function}...")
                    result = emu.call(func_addr)
                    console.print_success(f"Result: {result:#x}")

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1


class ExportCommand(CLICommand):
    """Export analysis results in various formats."""

    name = "export"
    description = "Export analysis results to various formats"
    aliases = ["e", "save"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("-o", "--output", required=True,
                           help="Output file path")
        parser.add_argument("--format", choices=["json", "html", "drcov", "markdown"],
                           default="json", help="Output format")
        parser.add_argument("--type", choices=["info", "coverage", "trace", "report"],
                           default="info", help="What to export")
        parser.add_argument("-f", "--function", help="Function to analyze")
        parser.add_argument("--arch", choices=["arm", "arm64"], default="arm64")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg.android import AndroidEmulator
        from pyunidbg.reports import ReportFormat, ReportGenerator

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        try:
            emu = AndroidEmulator(arch=ctx.args.arch)
            module = emu.load_library(str(library_path))

            console.print_success(f"Loaded {module.name}")

            export_type = ctx.args.type

            if export_type == "coverage":
                from pyunidbg.analysis import CoverageTracker
                tracker = CoverageTracker(emu)
                tracker.start()
                if ctx.args.function:
                    func_addr = module.get_function_address(ctx.args.function)
                    if func_addr:
                        emu.call(func_addr)
                tracker.stop()

                output_path = Path(ctx.args.output)
                if ctx.args.format == "drcov":
                    tracker.export_drcov(str(output_path))
                elif ctx.args.format == "lcov":
                    tracker.export_lcov(str(output_path))
                else:
                    tracker.export_json(str(output_path))
                console.print_success(f"Coverage exported to {output_path}")
                return 0

            if export_type == "trace":
                from pyunidbg.analysis import InstructionTracer
                tracer = InstructionTracer(emu)
                tracer.start()
                if ctx.args.function:
                    func_addr = module.get_function_address(ctx.args.function)
                    if func_addr:
                        emu.call(func_addr)
                tracer.stop()
                tracer.export(ctx.args.output)
                console.print_success(f"Trace exported to {ctx.args.output}")
                return 0

            # Default: info or report
            report_gen = ReportGenerator(emu)

            if ctx.args.function:
                func_addr = module.get_function_address(ctx.args.function)
                if func_addr:
                    report_gen.start_recording()
                    emu.call(func_addr)
                    report_gen.stop_recording()

            report = report_gen.generate(
                title=f"Analysis of {module.name}",
                include_memory=True,
                include_registers=True,
            )

            # Export
            output_path = Path(ctx.args.output)
            format_map = {
                "json": ReportFormat.JSON,
                "html": ReportFormat.HTML,
                "drcov": ReportFormat.DRCOV,
                "markdown": ReportFormat.MARKDOWN,
            }

            report.export(str(output_path), format_map.get(ctx.args.format, ReportFormat.JSON))
            console.print_success(f"Exported to {output_path}")

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1


class ConfigCommand(CLICommand):
    """Manage PyUniDbg configuration."""

    name = "config"
    description = "Manage PyUniDbg configuration"
    aliases = ["cfg"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("--show", action="store_true",
                           help="Show current configuration")
        parser.add_argument("--set", metavar="KEY=VALUE", action="append",
                           help="Set a configuration value")
        parser.add_argument("--get", metavar="KEY",
                           help="Get a configuration value")
        parser.add_argument("--reset", action="store_true",
                           help="Reset to default configuration")
        parser.add_argument("--path", action="store_true",
                           help="Show configuration file path")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg.config import Config, get_config_path

        config = Config.load()

        if ctx.args.path:
            console.print_info(f"Config path: {get_config_path()}")
            return 0

        if ctx.args.reset:
            config = Config()
            config.save()
            console.print_success("Configuration reset to defaults")
            return 0

        if ctx.args.set:
            for item in ctx.args.set:
                if "=" not in item:
                    console.print_error(f"Invalid format: {item} (use KEY=VALUE)")
                    return 1
                key, value = item.split("=", 1)
                config.set(key, value)
            config.save()
            console.print_success("Configuration updated")
            return 0

        if ctx.args.get:
            value = config.get(ctx.args.get)
            if value is not None:
                console.print(f"{ctx.args.get} = {value}")
            else:
                console.print_error(f"Key not found: {ctx.args.get}")
                return 1
            return 0

        if ctx.args.show or not any([ctx.args.set, ctx.args.get, ctx.args.reset, ctx.args.path]):
            console.print_json(config.to_dict())
            return 0

        return 0


class VersionCommand(CLICommand):
    """Show version information."""

    name = "version"
    description = "Show PyUniDbg version information"
    aliases = ["v", "--version"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("--json", action="store_true",
                           help="Output as JSON")

    def run(self, ctx: CLIContext) -> int:
        from pyunidbg import __version__

        info = {
            "pyunidbg": __version__,
            "python": sys.version,
        }

        # Try to get dependency versions
        try:
            import unicorn
            info["unicorn"] = unicorn.__version__
        except ImportError:
            pass

        try:
            import capstone
            info["capstone"] = ".".join(map(str, capstone.cs_version()))
        except ImportError:
            pass

        try:
            import lief
            info["lief"] = lief.__version__
        except ImportError:
            pass

        if ctx.args.json:
            console.print_json(info)
        else:
            console.print_panel(
                f"PyUniDbg: {info['pyunidbg']}\n"
                f"Python: {sys.version.split()[0]}\n"
                f"Unicorn: {info.get('unicorn', 'N/A')}\n"
                f"Capstone: {info.get('capstone', 'N/A')}\n"
                f"LIEF: {info.get('lief', 'N/A')}",
                title="Version Information"
            )

        return 0


class WebCommand(CLICommand):
    """Start the PyUniDbg web interface."""

    name = "web"
    description = "Start the web-based UI (requires fastapi + uvicorn)"
    aliases = ["ui", "serve"]

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("--host", default="0.0.0.0",
                           help="Bind host (default: 0.0.0.0)")
        parser.add_argument("-p", "--port", type=int, default=8080,
                           help="HTTP port (default: 8080)")
        parser.add_argument("--reload", action="store_true",
                           help="Enable auto-reload (development mode)")
        parser.add_argument("--log-level", default="info",
                           choices=["debug", "info", "warning", "error"],
                           help="Uvicorn log level")
        parser.add_argument("--no-open", action="store_true",
                           help="Don't open browser automatically")

    def run(self, ctx: CLIContext) -> int:
        try:
            from pyunidbg.web import run_server
        except ImportError:
            console.print_error(
                "Web interface requires additional dependencies.\n"
                "Install with:  pip install pyunidbg[web]\n"
                "          or:  pip install fastapi 'uvicorn[standard]' python-multipart"
            )
            return 1

        if not ctx.args.no_open:
            import threading
            import time
            import webbrowser
            url = f"http://localhost:{ctx.args.port}"
            def _open():
                time.sleep(1.5)
                webbrowser.open(url)
            threading.Thread(target=_open, daemon=True).start()

        try:
            run_server(
                host=ctx.args.host,
                port=ctx.args.port,
                reload=ctx.args.reload,
                log_level=ctx.args.log_level,
            )
        except KeyboardInterrupt:
            console.print_info("Web server stopped.")
        return 0


class ScanCommand(CLICommand):
    """Scan a library and list functions with arguments and types."""

    name = "scan"
    description = "Scan a library to list functions with arguments and types"
    aliases = ["s", "functions", "funcs"]

    # JNI type mappings
    JNI_TYPES = {
        'Z': ('jboolean', 'boolean'),
        'B': ('jbyte', 'byte'),
        'C': ('jchar', 'char'),
        'S': ('jshort', 'short'),
        'I': ('jint', 'int'),
        'J': ('jlong', 'long'),
        'F': ('jfloat', 'float'),
        'D': ('jdouble', 'double'),
        'V': ('void', 'void'),
    }

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("library", help="Path to the .so library")
        parser.add_argument("-f", "--filter", default="",
                           help="Filter functions by name pattern (supports wildcards)")
        parser.add_argument("--jni", action="store_true",
                           help="Show only JNI functions (Java_*)")
        parser.add_argument("--exports", action="store_true",
                           help="Show only exported functions")
        parser.add_argument("--with-address", action="store_true",
                           help="Include function addresses")
        parser.add_argument("--demangle", action="store_true",
                           help="Demangle C++ names")
        parser.add_argument("--json", action="store_true",
                           help="Output as JSON")
        parser.add_argument("--limit", type=int, default=0,
                           help="Limit number of results (0 = no limit)")
        parser.add_argument("--sort", choices=["name", "address", "size"],
                           default="name", help="Sort by (default: name)")
        parser.add_argument("--apk", help="APK file to extract JNI signatures from")
        parser.add_argument("--signatures", help="JSON file with JNI method signatures")

    def run(self, ctx: CLIContext) -> int:
        import fnmatch
        import re

        import lief

        library_path = Path(ctx.args.library)
        if not library_path.exists():
            console.print_error(f"Library not found: {library_path}")
            return 1

        try:
            elf = lief.parse(str(library_path))
            if elf is None:
                console.print_error("Failed to parse ELF file")
                return 1

            # Detect architecture
            is_64bit = elf.header.machine_type == lief.ELF.ARCH.AARCH64 or \
                       elf.header.machine_type == lief.ELF.ARCH.X86_64

            # Load JNI signatures from APK or file
            jni_signatures = {}
            if ctx.args.apk:
                jni_signatures = self._extract_signatures_from_apk(ctx.args.apk, ctx.verbose)
                if jni_signatures:
                    console.print_info(f"Loaded {len(jni_signatures)} JNI signatures from APK")
            elif ctx.args.signatures:
                jni_signatures = self._load_signatures_file(ctx.args.signatures)
                if jni_signatures:
                    console.print_info(f"Loaded {len(jni_signatures)} JNI signatures from file")

            # Collect functions
            functions = []
            for sym in elf.symbols:
                # Only functions
                if sym.type != lief.ELF.Symbol.TYPE.FUNC:
                    continue

                # Only exported if requested
                if ctx.args.exports and sym.binding.name not in ("GLOBAL", "WEAK"):
                    continue

                # Only JNI if requested
                if ctx.args.jni and not sym.name.startswith("Java_"):
                    continue

                # Apply filter
                if ctx.args.filter:
                    if not fnmatch.fnmatch(sym.name, f"*{ctx.args.filter}*"):
                        continue

                # Parse function info
                func_info = self._analyze_function(
                    sym.name, sym.value, sym.size, is_64bit,
                    ctx.args.demangle, jni_signatures
                )
                functions.append(func_info)

            # Sort
            if ctx.args.sort == "address":
                functions.sort(key=lambda f: f['address'])
            elif ctx.args.sort == "size":
                functions.sort(key=lambda f: f['size'], reverse=True)
            else:
                functions.sort(key=lambda f: f['name'].lower())

            # Apply limit
            if ctx.args.limit > 0:
                functions = functions[:ctx.args.limit]

            # Output
            if ctx.args.json:
                console.print_json(functions)
            else:
                self._print_functions(functions, ctx.args.with_address, library_path.name)

            return 0

        except Exception as e:
            console.print_error(str(e))
            if ctx.verbose:
                import traceback
                traceback.print_exc()
            return 1

    def _extract_signatures_from_apk(self, apk_path: str, verbose: bool = False) -> dict:
        """Extract JNI method signatures from an APK file."""
        signatures = {}

        try:
            from androguard.core.apk import APK
            from androguard.core.dex import DEX
        except ImportError:
            console.print_warning("androguard not installed. Install with: pip install androguard")
            return signatures

        try:
            apk = APK(apk_path)

            # Get all DEX files
            for dex_name in apk.get_dex_names():
                dex_data = apk.get_file(dex_name)
                dex = DEX(dex_data)

                # Find native methods
                for cls in dex.get_classes():
                    class_name = cls.get_name()
                    # Convert Lcom/example/Class; -> com.example.Class
                    if class_name.startswith('L') and class_name.endswith(';'):
                        class_name = class_name[1:-1].replace('/', '.')

                    for method in cls.get_methods():
                        access_flags = method.get_access_flags()
                        # Check if native (0x0100 = ACC_NATIVE)
                        if access_flags & 0x0100:
                            method_name = method.get_name()
                            signature = method.get_descriptor()

                            # Build the JNI function name
                            jni_name = self._build_jni_name(class_name, method_name)

                            signatures[jni_name] = {
                                'class': class_name,
                                'method': method_name,
                                'descriptor': signature,
                                'arguments': self._parse_jni_descriptor(signature),
                                'return_type': self._parse_return_type(signature),
                            }

                            if verbose:
                                console.print_info(f"Found: {class_name}.{method_name}{signature}")

        except Exception as e:
            console.print_warning(f"Failed to parse APK: {e}")

        return signatures

    def _build_jni_name(self, class_name: str, method_name: str) -> str:
        """Build JNI function name from class and method name."""
        # JNI encoding: _ in original names become _1, then . and / become _
        def escape_name(s):
            # First escape underscores, semicolons, brackets that are in the original
            result = s.replace('_', '_1').replace(';', '_2').replace('[', '_3')
            return result

        # Escape class name parts (before replacing . with _)
        class_parts = class_name.split('.')
        escaped_parts = [escape_name(p) for p in class_parts]
        class_path = '_'.join(escaped_parts)

        # Escape method name
        method = escape_name(method_name)

        return f"Java_{class_path}_{method}"

    def _parse_jni_descriptor(self, descriptor: str) -> list:
        """Parse JNI method descriptor to extract argument types."""
        args = []

        # Descriptor format: (args)return_type
        if not descriptor.startswith('('):
            return args

        # Find the closing paren
        end_paren = descriptor.find(')')
        if end_paren == -1:
            return args

        args_str = descriptor[1:end_paren]
        i = 0
        arg_num = 0

        while i < len(args_str):
            c = args_str[i]

            if c in self.JNI_TYPES:
                jni_type, java_type = self.JNI_TYPES[c]
                args.append({
                    'name': f'arg{arg_num}',
                    'type': jni_type,
                    'java_type': java_type,
                })
                arg_num += 1
                i += 1

            elif c == 'L':
                # Object type: Lcom/example/Class;
                end = args_str.find(';', i)
                if end == -1:
                    break
                class_path = args_str[i+1:end]
                class_name = class_path.replace('/', '.')

                # Map common types
                if class_name == 'java.lang.String':
                    jni_type = 'jstring'
                elif class_name == 'android.content.Context':
                    jni_type = 'jobject'  # Context
                else:
                    jni_type = 'jobject'

                args.append({
                    'name': f'arg{arg_num}',
                    'type': jni_type,
                    'java_type': class_name,
                })
                arg_num += 1
                i = end + 1

            elif c == '[':
                # Array type - count dimensions
                array_depth = 0
                while i < len(args_str) and args_str[i] == '[':
                    array_depth += 1
                    i += 1

                if i >= len(args_str):
                    break

                base_c = args_str[i]
                if base_c in self.JNI_TYPES:
                    _, base_type = self.JNI_TYPES[base_c]
                    java_type = base_type + '[]' * array_depth
                    array_types = {
                        'Z': 'jbooleanArray',
                        'B': 'jbyteArray',
                        'C': 'jcharArray',
                        'S': 'jshortArray',
                        'I': 'jintArray',
                        'J': 'jlongArray',
                        'F': 'jfloatArray',
                        'D': 'jdoubleArray',
                    }
                    jni_type = array_types.get(base_c, 'jarray')
                    args.append({
                        'name': f'arg{arg_num}',
                        'type': jni_type,
                        'java_type': java_type,
                    })
                    arg_num += 1
                    i += 1
                elif base_c == 'L':
                    end = args_str.find(';', i)
                    if end == -1:
                        break
                    class_name = args_str[i+1:end].replace('/', '.')
                    java_type = class_name + '[]' * array_depth
                    args.append({
                        'name': f'arg{arg_num}',
                        'type': 'jobjectArray',
                        'java_type': java_type,
                    })
                    arg_num += 1
                    i = end + 1
            else:
                i += 1

        return args

    def _parse_return_type(self, descriptor: str) -> str:
        """Parse return type from JNI descriptor."""
        end_paren = descriptor.find(')')
        if end_paren == -1 or end_paren + 1 >= len(descriptor):
            return 'void'

        ret = descriptor[end_paren + 1:]
        if not ret:
            return 'void'

        c = ret[0]
        if c in self.JNI_TYPES:
            return self.JNI_TYPES[c][0]
        elif c == 'L':
            # Object return type
            if 'String' in ret:
                return 'jstring'
            return 'jobject'
        elif c == '[':
            return 'jarray'

        return 'jobject'

    def _load_signatures_file(self, path: str) -> dict:
        """Load JNI signatures from a JSON file."""
        try:
            with open(path) as f:
                return json.load(f)
        except Exception as e:
            console.print_warning(f"Failed to load signatures file: {e}")
            return {}

    def _analyze_function(self, name: str, address: int, size: int, is_64bit: bool,
                          demangle: bool, jni_signatures: dict = None) -> dict:
        """Analyze a function and extract type information."""
        if jni_signatures is None:
            jni_signatures = {}

        result = {
            'name': name,
            'address': address,
            'size': size,
            'demangled': None,
            'type': 'native',  # native, jni, cpp
            'return_type': 'unknown',
            'arguments': [],
            'signature': None,
        }

        # Try to demangle C++ names
        if demangle and name.startswith("_Z"):
            result['demangled'] = self._demangle_cpp(name)
            result['type'] = 'cpp'
            if result['demangled']:
                cpp_sig = self._parse_cpp_signature(result['demangled'])
                if cpp_sig:
                    result['return_type'] = cpp_sig.get('return_type', 'unknown')
                    result['arguments'] = cpp_sig.get('arguments', [])
                    result['signature'] = result['demangled']

        # Parse JNI function
        elif name.startswith("Java_"):
            result['type'] = 'jni'

            # Check if we have signature from APK
            if name in jni_signatures:
                sig_info = jni_signatures[name]
                result['class_name'] = sig_info.get('class', '')
                result['method_name'] = sig_info.get('method', '')
                result['descriptor'] = sig_info.get('descriptor', '')
                result['return_type'] = sig_info.get('return_type', 'jint')

                # Build arguments: JNIEnv* + jobject + actual args
                ptr_type = 'uint64_t' if is_64bit else 'uint32_t'
                result['arguments'] = [
                    {'name': 'env', 'type': 'JNIEnv*', 'jni_type': 'pointer'},
                    {'name': 'thiz', 'type': 'jobject', 'jni_type': 'pointer'},
                ]
                result['arguments'].extend(sig_info.get('arguments', []))
                result['signature'] = self._format_jni_signature_from_info(result, is_64bit)
            else:
                # Fall back to parsing from name only
                jni_info = self._parse_jni_function(name, is_64bit)
                result['return_type'] = jni_info.get('return_type', 'jint')
                result['arguments'] = jni_info.get('arguments', [])
                result['class_name'] = jni_info.get('class_name', '')
                result['method_name'] = jni_info.get('method_name', '')
                result['signature'] = self._format_jni_signature(jni_info, is_64bit)

        # Check for common libc/system functions
        else:
            known = self._get_known_signature(name)
            if known:
                result['return_type'] = known.get('return_type', 'unknown')
                result['arguments'] = known.get('arguments', [])
                result['signature'] = known.get('signature')

        return result

    def _format_jni_signature_from_info(self, info: dict, is_64bit: bool) -> str:
        """Format a JNI function signature from extracted info."""
        args_str = ", ".join(
            f"{arg['type']} {arg['name']}" for arg in info.get('arguments', [])
        )
        return_type = info.get('return_type', 'jint')
        method_name = info.get('method_name', 'unknown')
        return f"{return_type} {method_name}({args_str})"

    def _parse_jni_function(self, name: str, is_64bit: bool) -> dict:
        """Parse a JNI function name to extract class, method, and infer types."""
        result = {
            'class_name': '',
            'method_name': '',
            'return_type': 'jint',  # Default return type
            'arguments': [],
        }

        # Remove Java_ prefix
        if not name.startswith("Java_"):
            return result

        parts = name[5:].split("_")  # Remove "Java_"

        # Find method name (last part before any signature)
        # Handle escaped characters: _1 = _, _2 = ;, _3 = [
        clean_parts = []
        i = 0
        while i < len(parts):
            part = parts[i]
            # Check for signature suffix (like __I, __J, etc.)
            if part == '' and i + 1 < len(parts):
                # This is the separator between method and signature
                break
            clean_parts.append(part)
            i += 1

        if len(clean_parts) >= 2:
            result['class_name'] = '.'.join(clean_parts[:-1])
            result['method_name'] = clean_parts[-1]
        elif len(clean_parts) == 1:
            result['method_name'] = clean_parts[0]

        # Standard JNI arguments
        ptr_type = 'uint64_t' if is_64bit else 'uint32_t'
        result['arguments'] = [
            {'name': 'env', 'type': 'JNIEnv*', 'jni_type': 'pointer'},
            {'name': 'thiz', 'type': 'jobject', 'jni_type': 'pointer'},
        ]

        # Try to parse overloaded signature if present (after __)
        sig_start = name.find("__")
        if sig_start != -1:
            sig = name[sig_start + 2:]
            parsed_args = self._parse_jni_signature(sig)
            result['arguments'].extend(parsed_args)

        return result

    def _parse_jni_signature(self, sig: str) -> list:
        """Parse JNI method signature to extract argument types."""
        args = []
        i = 0
        arg_num = 0

        while i < len(sig):
            c = sig[i]

            if c in self.JNI_TYPES:
                jni_type, java_type = self.JNI_TYPES[c]
                args.append({
                    'name': f'arg{arg_num}',
                    'type': jni_type,
                    'java_type': java_type,
                })
                arg_num += 1
                i += 1

            elif c == 'L':
                # Object type: Lcom/example/Class;
                end = sig.find(';', i)
                if end == -1:
                    end = len(sig)
                class_name = sig[i+1:end].replace('/', '.')
                # Use common mappings
                if class_name == 'java.lang.String':
                    jni_type = 'jstring'
                elif class_name.endswith('[]'):
                    jni_type = 'jarray'
                else:
                    jni_type = 'jobject'
                args.append({
                    'name': f'arg{arg_num}',
                    'type': jni_type,
                    'java_type': class_name,
                })
                arg_num += 1
                i = end + 1

            elif c == '[':
                # Array type
                array_depth = 0
                while i < len(sig) and sig[i] == '[':
                    array_depth += 1
                    i += 1

                if i < len(sig):
                    base_c = sig[i]
                    if base_c in self.JNI_TYPES:
                        _, base_type = self.JNI_TYPES[base_c]
                        java_type = base_type + '[]' * array_depth
                        # Map to appropriate jarray type
                        array_types = {
                            'Z': 'jbooleanArray',
                            'B': 'jbyteArray',
                            'C': 'jcharArray',
                            'S': 'jshortArray',
                            'I': 'jintArray',
                            'J': 'jlongArray',
                            'F': 'jfloatArray',
                            'D': 'jdoubleArray',
                        }
                        jni_type = array_types.get(base_c, 'jarray')
                        args.append({
                            'name': f'arg{arg_num}',
                            'type': jni_type,
                            'java_type': java_type,
                        })
                        arg_num += 1
                        i += 1
                    elif base_c == 'L':
                        end = sig.find(';', i)
                        if end == -1:
                            end = len(sig)
                        class_name = sig[i+1:end].replace('/', '.')
                        java_type = class_name + '[]' * array_depth
                        args.append({
                            'name': f'arg{arg_num}',
                            'type': 'jobjectArray',
                            'java_type': java_type,
                        })
                        arg_num += 1
                        i = end + 1
            else:
                i += 1

        return args

    def _format_jni_signature(self, jni_info: dict, is_64bit: bool) -> str:
        """Format a JNI function signature as C declaration."""
        args_str = ", ".join(
            f"{arg['type']} {arg['name']}" for arg in jni_info['arguments']
        )
        return_type = jni_info.get('return_type', 'jint')
        method_name = jni_info.get('method_name', 'unknown')
        return f"{return_type} {method_name}({args_str})"

    def _demangle_cpp(self, mangled: str) -> str | None:
        """Demangle a C++ symbol name."""
        try:
            import subprocess
            result = subprocess.run(
                ['c++filt', mangled],
                capture_output=True,
                text=True,
                timeout=1
            )
            if result.returncode == 0:
                demangled = result.stdout.strip()
                if demangled != mangled:
                    return demangled
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Fallback: try to use LIEF's demangler if available
        try:
            import lief
            if hasattr(lief, 'demangle'):
                return lief.demangle(mangled)
        except (ImportError, Exception):
            pass

        return None

    def _parse_cpp_signature(self, demangled: str) -> dict | None:
        """Parse a demangled C++ function signature."""
        import re

        # Handle operator functions: operator delete(void*), operator new[](unsigned long)
        op_match = re.match(r'^(operator\s*(?:new|delete)(?:\[\])?)\s*\((.*?)\)$', demangled)
        if op_match:
            return {
                'return_type': 'void*' if 'new' in op_match.group(1) else 'void',
                'name': op_match.group(1),
                'arguments': self._parse_cpp_args(op_match.group(2)),
            }

        # Pattern: return_type class::method(args) or return_type function(args)
        # Examples:
        #   void MyClass::myMethod(int, char*)
        #   int someFunction(double)

        match = re.match(r'^([\w\s\*&:]+?)\s+(\w+(?:::\w+)*)\s*\((.*?)\)\s*(const)?$', demangled)
        if not match:
            # Try simpler pattern for constructors/destructors
            match = re.match(r'^(\w+(?:::\w+)*)\s*\((.*?)\)$', demangled)
            if match:
                return {
                    'return_type': 'void',
                    'name': match.group(1),
                    'arguments': self._parse_cpp_args(match.group(2)),
                }
            return None

        return_type = match.group(1).strip()
        name = match.group(2)
        args_str = match.group(3)

        return {
            'return_type': return_type,
            'name': name,
            'arguments': self._parse_cpp_args(args_str),
        }

    def _parse_cpp_args(self, args_str: str) -> list:
        """Parse C++ function arguments."""
        if not args_str or args_str.strip() == 'void':
            return []

        args = []
        # Simple split by comma (doesn't handle templates well but works for basic cases)
        for i, arg in enumerate(args_str.split(',')):
            arg = arg.strip()
            if arg:
                # Try to split type and name
                parts = arg.rsplit(' ', 1)
                if len(parts) == 2:
                    args.append({'type': parts[0], 'name': parts[1]})
                else:
                    args.append({'type': arg, 'name': f'arg{i}'})

        return args

    def _get_known_signature(self, name: str) -> dict | None:
        """Get signature for known libc/system functions."""
        known_functions = {
            'malloc': {
                'return_type': 'void*',
                'arguments': [{'type': 'size_t', 'name': 'size'}],
                'signature': 'void* malloc(size_t size)',
            },
            'free': {
                'return_type': 'void',
                'arguments': [{'type': 'void*', 'name': 'ptr'}],
                'signature': 'void free(void* ptr)',
            },
            'memcpy': {
                'return_type': 'void*',
                'arguments': [
                    {'type': 'void*', 'name': 'dest'},
                    {'type': 'const void*', 'name': 'src'},
                    {'type': 'size_t', 'name': 'n'},
                ],
                'signature': 'void* memcpy(void* dest, const void* src, size_t n)',
            },
            'memset': {
                'return_type': 'void*',
                'arguments': [
                    {'type': 'void*', 'name': 's'},
                    {'type': 'int', 'name': 'c'},
                    {'type': 'size_t', 'name': 'n'},
                ],
                'signature': 'void* memset(void* s, int c, size_t n)',
            },
            'strlen': {
                'return_type': 'size_t',
                'arguments': [{'type': 'const char*', 'name': 's'}],
                'signature': 'size_t strlen(const char* s)',
            },
            'strcpy': {
                'return_type': 'char*',
                'arguments': [
                    {'type': 'char*', 'name': 'dest'},
                    {'type': 'const char*', 'name': 'src'},
                ],
                'signature': 'char* strcpy(char* dest, const char* src)',
            },
            'strcmp': {
                'return_type': 'int',
                'arguments': [
                    {'type': 'const char*', 'name': 's1'},
                    {'type': 'const char*', 'name': 's2'},
                ],
                'signature': 'int strcmp(const char* s1, const char* s2)',
            },
            'printf': {
                'return_type': 'int',
                'arguments': [{'type': 'const char*', 'name': 'format'}],
                'signature': 'int printf(const char* format, ...)',
            },
            'sprintf': {
                'return_type': 'int',
                'arguments': [
                    {'type': 'char*', 'name': 'str'},
                    {'type': 'const char*', 'name': 'format'},
                ],
                'signature': 'int sprintf(char* str, const char* format, ...)',
            },
            'snprintf': {
                'return_type': 'int',
                'arguments': [
                    {'type': 'char*', 'name': 'str'},
                    {'type': 'size_t', 'name': 'size'},
                    {'type': 'const char*', 'name': 'format'},
                ],
                'signature': 'int snprintf(char* str, size_t size, const char* format, ...)',
            },
            'open': {
                'return_type': 'int',
                'arguments': [
                    {'type': 'const char*', 'name': 'pathname'},
                    {'type': 'int', 'name': 'flags'},
                ],
                'signature': 'int open(const char* pathname, int flags, ...)',
            },
            'close': {
                'return_type': 'int',
                'arguments': [{'type': 'int', 'name': 'fd'}],
                'signature': 'int close(int fd)',
            },
            'read': {
                'return_type': 'ssize_t',
                'arguments': [
                    {'type': 'int', 'name': 'fd'},
                    {'type': 'void*', 'name': 'buf'},
                    {'type': 'size_t', 'name': 'count'},
                ],
                'signature': 'ssize_t read(int fd, void* buf, size_t count)',
            },
            'write': {
                'return_type': 'ssize_t',
                'arguments': [
                    {'type': 'int', 'name': 'fd'},
                    {'type': 'const void*', 'name': 'buf'},
                    {'type': 'size_t', 'name': 'count'},
                ],
                'signature': 'ssize_t write(int fd, const void* buf, size_t count)',
            },
            'pthread_create': {
                'return_type': 'int',
                'arguments': [
                    {'type': 'pthread_t*', 'name': 'thread'},
                    {'type': 'const pthread_attr_t*', 'name': 'attr'},
                    {'type': 'void* (*)(void*)', 'name': 'start_routine'},
                    {'type': 'void*', 'name': 'arg'},
                ],
                'signature': 'int pthread_create(pthread_t* thread, const pthread_attr_t* attr, void* (*start_routine)(void*), void* arg)',
            },
            'pthread_mutex_lock': {
                'return_type': 'int',
                'arguments': [{'type': 'pthread_mutex_t*', 'name': 'mutex'}],
                'signature': 'int pthread_mutex_lock(pthread_mutex_t* mutex)',
            },
            'pthread_mutex_unlock': {
                'return_type': 'int',
                'arguments': [{'type': 'pthread_mutex_t*', 'name': 'mutex'}],
                'signature': 'int pthread_mutex_unlock(pthread_mutex_t* mutex)',
            },
            'dlopen': {
                'return_type': 'void*',
                'arguments': [
                    {'type': 'const char*', 'name': 'filename'},
                    {'type': 'int', 'name': 'flags'},
                ],
                'signature': 'void* dlopen(const char* filename, int flags)',
            },
            'dlsym': {
                'return_type': 'void*',
                'arguments': [
                    {'type': 'void*', 'name': 'handle'},
                    {'type': 'const char*', 'name': 'symbol'},
                ],
                'signature': 'void* dlsym(void* handle, const char* symbol)',
            },
            'dlclose': {
                'return_type': 'int',
                'arguments': [{'type': 'void*', 'name': 'handle'}],
                'signature': 'int dlclose(void* handle)',
            },
            # JNI specific
            'JNI_OnLoad': {
                'return_type': 'jint',
                'arguments': [
                    {'type': 'JavaVM*', 'name': 'vm'},
                    {'type': 'void*', 'name': 'reserved'},
                ],
                'signature': 'jint JNI_OnLoad(JavaVM* vm, void* reserved)',
            },
            'JNI_OnUnload': {
                'return_type': 'void',
                'arguments': [
                    {'type': 'JavaVM*', 'name': 'vm'},
                    {'type': 'void*', 'name': 'reserved'},
                ],
                'signature': 'void JNI_OnUnload(JavaVM* vm, void* reserved)',
            },
        }
        return known_functions.get(name)

    def _print_functions(self, functions: list, with_address: bool, lib_name: str):
        """Print functions in a formatted table."""
        if not functions:
            console.print_warning("No functions found matching criteria")
            return

        console.print_info(f"Found {len(functions)} functions in {lib_name}\n")

        # Group by type
        jni_funcs = [f for f in functions if f['type'] == 'jni']
        cpp_funcs = [f for f in functions if f['type'] == 'cpp']
        native_funcs = [f for f in functions if f['type'] == 'native']

        # Print JNI functions
        if jni_funcs:
            columns = ["Method", "Class", "Arguments"]
            if with_address:
                columns.insert(0, "Address")

            rows = []
            for f in jni_funcs:
                args = ", ".join(
                    f"{a['type']} {a['name']}" for a in f.get('arguments', [])
                )
                row = [
                    f.get('method_name', f['name']),
                    f.get('class_name', ''),
                    args or "(JNIEnv*, jobject)",
                ]
                if with_address:
                    row.insert(0, f"0x{f['address']:x}")
                rows.append(row)

            console.print_table(f"JNI Functions ({len(jni_funcs)})", columns, rows)
            print()

        # Print C++ functions
        if cpp_funcs:
            columns = ["Name", "Return", "Arguments"]
            if with_address:
                columns.insert(0, "Address")

            rows = []
            for f in cpp_funcs:
                name = f.get('demangled') or f['name']
                if len(name) > 60:
                    name = name[:57] + "..."
                args = ", ".join(
                    f"{a['type']} {a.get('name', '')}" for a in f.get('arguments', [])
                )
                row = [name, f.get('return_type', '?'), args or "()"]
                if with_address:
                    row.insert(0, f"0x{f['address']:x}")
                rows.append(row)

            console.print_table(f"C++ Functions ({len(cpp_funcs)})", columns, rows)
            print()

        # Print native functions
        if native_funcs:
            columns = ["Name", "Signature"]
            if with_address:
                columns.insert(0, "Address")

            rows = []
            for f in native_funcs:
                name = f['name']
                if len(name) > 50:
                    name = name[:47] + "..."
                sig = f.get('signature') or ""
                if len(sig) > 60:
                    sig = sig[:57] + "..."
                row = [name, sig]
                if with_address:
                    row.insert(0, f"0x{f['address']:x}")
                rows.append(row)

            console.print_table(f"Native Functions ({len(native_funcs)})", columns, rows)


# ==================== Main CLI Class ====================

class CLI:
    """Main CLI application."""

    def __init__(self):
        self.commands: dict[str, CLICommand] = {}
        self._register_commands()

    def _register_commands(self):
        """Register all available commands."""
        command_classes = [
            RunCommand,
            CallCommand,
            AnalyzeCommand,
            DebugCommand,
            InfoCommand,
            DisasmCommand,
            HookCommand,
            ExportCommand,
            ConfigCommand,
            VersionCommand,
            ScanCommand,
            WebCommand,
        ]

        for cls in command_classes:
            cmd = cls()
            self.commands[cmd.name] = cmd
            for alias in cmd.aliases:
                self.commands[alias] = cmd

    def create_parser(self) -> argparse.ArgumentParser:
        """Create the argument parser."""
        parser = argparse.ArgumentParser(
            prog="pyunidbg",
            description="PyUniDbg - Android Native Library Emulator",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  pyunidbg run libnative.so
  pyunidbg info libnative.so --symbols
  pyunidbg debug libnative.so --port 1234
  pyunidbg analyze libnative.so --coverage -o coverage.json
  pyunidbg disasm libnative.so -f Java_com_example_test
            """
        )

        parser.add_argument("-v", "--verbose", action="store_true",
                           help="Enable verbose output")
        parser.add_argument("-q", "--quiet", action="store_true",
                           help="Suppress non-essential output")
        parser.add_argument("--no-color", action="store_true",
                           help="Disable colored output")

        subparsers = parser.add_subparsers(dest="command", help="Command to run")

        # Add subcommands
        for name, cmd in self.commands.items():
            if name != cmd.name:  # Skip aliases
                continue

            subparser = subparsers.add_parser(
                cmd.name,
                help=cmd.description,
                aliases=cmd.aliases
            )
            cmd.add_arguments(subparser)

        return parser

    def run(self, args: list[str] | None = None) -> int:
        """Run the CLI."""
        parser = self.create_parser()
        parsed = parser.parse_args(args)

        # Apply --no-color globally
        if parsed.no_color:
            console.set_no_color(True)

        if not parsed.command:
            parser.print_help()
            return 0

        # Find command
        cmd = self.commands.get(parsed.command)
        if not cmd:
            console.print_error(f"Unknown command: {parsed.command}")
            return 1

        # Create context
        ctx = CLIContext(
            args=parsed,
            verbose=parsed.verbose,
            quiet=parsed.quiet
        )

        # Run command
        return cmd.run(ctx)


def main() -> int:
    """Main entry point."""
    cli = CLI()
    return cli.run()


def run_cli() -> None:
    """Entry point for console script."""
    sys.exit(main())


if __name__ == "__main__":
    run_cli()
