"""
Anti-analysis detection module for PyUniDbg.

This module provides detection capabilities for various anti-analysis techniques:
- Anti-debugging techniques
- Anti-virtualization/sandbox detection
- Code obfuscation detection
- Timing-based detection methods
- API hooking detection
- Process/thread manipulation detection
"""

from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum, auto
from typing import Any


class AntiAnalysisType(IntEnum):
    """Types of anti-analysis techniques."""
    # Anti-debugging
    DEBUGGER_DETECTION = auto()
    BREAKPOINT_DETECTION = auto()
    SINGLE_STEP_DETECTION = auto()
    HARDWARE_BREAKPOINT = auto()
    SOFTWARE_BREAKPOINT = auto()
    DEBUG_REGISTER_CHECK = auto()

    # Timing-based
    TIMING_CHECK = auto()
    RDTSC_TIMING = auto()
    PERFORMANCE_COUNTER = auto()

    # Anti-VM
    VM_DETECTION = auto()
    SANDBOX_DETECTION = auto()
    HYPERVISOR_DETECTION = auto()
    CPUID_CHECK = auto()

    # Process manipulation
    PROCESS_CHECK = auto()
    PARENT_PROCESS_CHECK = auto()
    THREAD_HIDING = auto()

    # Code protection
    CODE_INTEGRITY_CHECK = auto()
    CHECKSUM_VERIFICATION = auto()
    SELF_MODIFYING_CODE = auto()
    ANTI_DISASSEMBLY = auto()
    OPAQUE_PREDICATE = auto()

    # API-based
    ISDEBUGGERPRESENT = auto()
    NTQUERYINFORMATIONPROCESS = auto()
    NTSETINFORMATIONTHREAD = auto()
    OUTPUTDEBUGSTRING = auto()

    # Environment checks
    ENVIRONMENT_CHECK = auto()
    REGISTRY_CHECK = auto()
    FILE_CHECK = auto()
    MAC_ADDRESS_CHECK = auto()

    # Other
    EXCEPTION_BASED = auto()
    TLS_CALLBACK = auto()
    CUSTOM = auto()


class DetectionConfidence(IntEnum):
    """Confidence level of detection."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CERTAIN = 4


class TechniqueCategory(IntEnum):
    """Category of anti-analysis technique."""
    ANTI_DEBUG = auto()
    ANTI_VM = auto()
    ANTI_SANDBOX = auto()
    OBFUSCATION = auto()
    TIMING = auto()
    ENVIRONMENT = auto()


@dataclass
class AntiAnalysisTechnique:
    """A detected anti-analysis technique."""
    id: str
    technique_type: AntiAnalysisType
    category: TechniqueCategory
    confidence: DetectionConfidence
    address: int
    description: str
    details: dict[str, Any] = field(default_factory=dict)
    bypassed: bool = False
    bypass_method: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'id': self.id,
            'type': self.technique_type.name,
            'category': self.category.name,
            'confidence': self.confidence.name,
            'address': self.address,
            'description': self.description,
            'details': self.details.copy(),
            'bypassed': self.bypassed,
            'bypass_method': self.bypass_method,
        }

    def __str__(self) -> str:
        status = "[BYPASSED]" if self.bypassed else ""
        return f"[{self.confidence.name}] {self.technique_type.name} at {hex(self.address)}: {self.description} {status}"


@dataclass
class DebuggerCheck:
    """Information about a debugger check."""
    api_name: str
    address: int
    return_value: int | None = None
    expected_value: int | None = None
    is_hooked: bool = False


@dataclass
class TimingMeasurement:
    """A timing measurement for detection."""
    start_address: int
    end_address: int
    measured_cycles: int
    threshold_cycles: int
    is_suspicious: bool = False


@dataclass
class VMIndicator:
    """A virtual machine indicator."""
    indicator_type: str  # cpuid, registry, file, mac, etc.
    value: str
    vm_type: str = ""  # vmware, virtualbox, hyper-v, etc.
    address: int = 0


# Known anti-analysis API patterns
class AntiDebugAPIs:
    """Known anti-debugging APIs."""

    WINDOWS = {
        'IsDebuggerPresent': {
            'type': AntiAnalysisType.ISDEBUGGERPRESENT,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Checks PEB.BeingDebugged flag',
        },
        'CheckRemoteDebuggerPresent': {
            'type': AntiAnalysisType.DEBUGGER_DETECTION,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Checks for remote debugger',
        },
        'NtQueryInformationProcess': {
            'type': AntiAnalysisType.NTQUERYINFORMATIONPROCESS,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Can query debug port and other debug info',
        },
        'NtSetInformationThread': {
            'type': AntiAnalysisType.NTSETINFORMATIONTHREAD,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Can hide thread from debugger',
        },
        'OutputDebugString': {
            'type': AntiAnalysisType.OUTPUTDEBUGSTRING,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Error-based debugger detection',
        },
        'CloseHandle': {
            'type': AntiAnalysisType.EXCEPTION_BASED,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Invalid handle exception detection',
        },
        'NtClose': {
            'type': AntiAnalysisType.EXCEPTION_BASED,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Invalid handle exception detection',
        },
        'SetUnhandledExceptionFilter': {
            'type': AntiAnalysisType.EXCEPTION_BASED,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Exception filter manipulation',
        },
    }

    LINUX = {
        'ptrace': {
            'type': AntiAnalysisType.DEBUGGER_DETECTION,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'PTRACE_TRACEME anti-debug check',
        },
        'prctl': {
            'type': AntiAnalysisType.PROCESS_CHECK,
            'category': TechniqueCategory.ANTI_DEBUG,
            'description': 'Process control operations',
        },
    }

    @classmethod
    def get_api_info(cls, api_name: str) -> dict[str, Any] | None:
        """Get info for an API."""
        if api_name in cls.WINDOWS:
            return cls.WINDOWS[api_name]
        if api_name in cls.LINUX:
            return cls.LINUX[api_name]
        return None

    @classmethod
    def is_anti_debug_api(cls, api_name: str) -> bool:
        """Check if API is anti-debug related."""
        return api_name in cls.WINDOWS or api_name in cls.LINUX


class VMDetectionPatterns:
    """Known VM detection patterns."""

    CPUID_HYPERVISOR_VENDORS = {
        'VMwareVMware': 'VMware',
        'VBoxVBoxVBox': 'VirtualBox',
        'Microsoft Hv': 'Hyper-V',
        'KVMKVMKVM': 'KVM',
        'XenVMMXenVMM': 'Xen',
        'prl hyperv  ': 'Parallels',
        'TCGTCGTCGTCG': 'QEMU',
    }

    REGISTRY_KEYS = {
        r'HKLM\SOFTWARE\VMware, Inc.\VMware Tools': 'VMware',
        r'HKLM\SOFTWARE\Oracle\VirtualBox Guest Additions': 'VirtualBox',
        r'HKLM\SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters': 'Hyper-V',
    }

    FILE_PATHS = {
        r'C:\Windows\System32\drivers\vmhgfs.sys': 'VMware',
        r'C:\Windows\System32\drivers\VBoxMouse.sys': 'VirtualBox',
        r'/dev/vmci': 'VMware',
        r'/proc/scsi/scsi': 'VirtualBox',
    }

    MAC_PREFIXES = {
        '00:0C:29': 'VMware',
        '00:50:56': 'VMware',
        '08:00:27': 'VirtualBox',
        '00:1C:42': 'Parallels',
        '00:16:3E': 'Xen',
        '00:15:5D': 'Hyper-V',
    }

    PROCESS_NAMES = {
        'vmtoolsd.exe': 'VMware',
        'vmwaretray.exe': 'VMware',
        'VBoxService.exe': 'VirtualBox',
        'VBoxTray.exe': 'VirtualBox',
    }

    @classmethod
    def check_cpuid_vendor(cls, vendor: str) -> str | None:
        """Check if CPUID vendor string indicates VM."""
        return cls.CPUID_HYPERVISOR_VENDORS.get(vendor)

    @classmethod
    def check_mac_prefix(cls, mac: str) -> str | None:
        """Check if MAC address prefix indicates VM."""
        prefix = mac[:8].upper()
        return cls.MAC_PREFIXES.get(prefix)


class BreakpointPatterns:
    """Breakpoint detection patterns."""

    # x86 software breakpoint
    INT3_OPCODE = 0xCC

    # Common patterns for breakpoint scanning
    BREAKPOINT_SCAN_SIGNATURES = [
        b'\x80\x38\xCC',  # cmp byte ptr [eax], 0xCC
        b'\x3C\xCC',       # cmp al, 0xCC
        b'\x80\x39\xCC',  # cmp byte ptr [ecx], 0xCC
    ]

    # Debug register access patterns
    DEBUG_REG_ACCESS = [
        'mov eax, dr0',
        'mov eax, dr1',
        'mov eax, dr2',
        'mov eax, dr3',
        'mov eax, dr6',
        'mov eax, dr7',
    ]


class AntiDebugDetector:
    """Detects anti-debugging techniques."""

    def __init__(self):
        self._detected_checks: list[DebuggerCheck] = []
        self._techniques: list[AntiAnalysisTechnique] = []
        self._technique_counter = 0

    def check_api_call(self, api_name: str, address: int,
                       return_value: int | None = None) -> AntiAnalysisTechnique | None:
        """Check if an API call is anti-debug related."""
        info = AntiDebugAPIs.get_api_info(api_name)
        if not info:
            return None

        self._technique_counter += 1
        technique = AntiAnalysisTechnique(
            id=f"ANTIDEBUG-{self._technique_counter}",
            technique_type=info['type'],
            category=info['category'],
            confidence=DetectionConfidence.HIGH,
            address=address,
            description=f"{api_name}: {info['description']}",
            details={'api': api_name, 'return_value': return_value},
        )
        self._techniques.append(technique)

        check = DebuggerCheck(
            api_name=api_name,
            address=address,
            return_value=return_value,
        )
        self._detected_checks.append(check)

        return technique

    def check_peb_access(self, address: int, offset: int) -> AntiAnalysisTechnique | None:
        """Check for PEB-based debugger detection."""
        # Common PEB offsets used for anti-debug
        peb_offsets = {
            0x2: ('BeingDebugged', DetectionConfidence.CERTAIN),
            0x68: ('NtGlobalFlag', DetectionConfidence.HIGH),
            0xBC: ('NtGlobalFlag (x64)', DetectionConfidence.HIGH),
            0x18: ('ProcessHeap.Flags', DetectionConfidence.MEDIUM),
        }

        if offset in peb_offsets:
            name, confidence = peb_offsets[offset]
            self._technique_counter += 1
            technique = AntiAnalysisTechnique(
                id=f"PEB-{self._technique_counter}",
                technique_type=AntiAnalysisType.DEBUGGER_DETECTION,
                category=TechniqueCategory.ANTI_DEBUG,
                confidence=confidence,
                address=address,
                description=f"PEB-based check: {name} at offset {hex(offset)}",
                details={'peb_offset': offset, 'field_name': name},
            )
            self._techniques.append(technique)
            return technique

        return None

    def check_breakpoint_scan(self, address: int, scanned_range: tuple[int, int],
                             found_breakpoints: list[int]) -> AntiAnalysisTechnique | None:
        """Check for breakpoint scanning behavior."""
        self._technique_counter += 1
        technique = AntiAnalysisTechnique(
            id=f"BPSCAN-{self._technique_counter}",
            technique_type=AntiAnalysisType.BREAKPOINT_DETECTION,
            category=TechniqueCategory.ANTI_DEBUG,
            confidence=DetectionConfidence.HIGH,
            address=address,
            description=f"Breakpoint scanning detected: range {hex(scanned_range[0])}-{hex(scanned_range[1])}",
            details={
                'scan_start': scanned_range[0],
                'scan_end': scanned_range[1],
                'breakpoints_found': found_breakpoints,
            },
        )
        self._techniques.append(technique)
        return technique

    def check_debug_register_access(self, address: int,
                                   register: str) -> AntiAnalysisTechnique | None:
        """Check for debug register access."""
        if register.lower().startswith('dr'):
            self._technique_counter += 1
            technique = AntiAnalysisTechnique(
                id=f"DREG-{self._technique_counter}",
                technique_type=AntiAnalysisType.DEBUG_REGISTER_CHECK,
                category=TechniqueCategory.ANTI_DEBUG,
                confidence=DetectionConfidence.HIGH,
                address=address,
                description=f"Debug register access: {register}",
                details={'register': register},
            )
            self._techniques.append(technique)
            return technique
        return None

    def get_techniques(self) -> list[AntiAnalysisTechnique]:
        """Get all detected techniques."""
        return self._techniques

    def get_checks(self) -> list[DebuggerCheck]:
        """Get all detected debugger checks."""
        return self._detected_checks


class TimingDetector:
    """Detects timing-based anti-analysis."""

    def __init__(self, timing_threshold: int = 100000):
        self._threshold = timing_threshold
        self._measurements: list[TimingMeasurement] = []
        self._techniques: list[AntiAnalysisTechnique] = []
        self._technique_counter = 0

    def set_threshold(self, cycles: int) -> None:
        """Set timing threshold for detection."""
        self._threshold = cycles

    def check_rdtsc(self, address: int) -> AntiAnalysisTechnique | None:
        """Check for RDTSC usage."""
        self._technique_counter += 1
        technique = AntiAnalysisTechnique(
            id=f"RDTSC-{self._technique_counter}",
            technique_type=AntiAnalysisType.RDTSC_TIMING,
            category=TechniqueCategory.TIMING,
            confidence=DetectionConfidence.MEDIUM,
            address=address,
            description="RDTSC instruction detected - potential timing check",
            details={'instruction': 'rdtsc'},
        )
        self._techniques.append(technique)
        return technique

    def check_timing_delta(self, start_addr: int, end_addr: int,
                          measured_cycles: int) -> AntiAnalysisTechnique | None:
        """Check timing delta for anti-debug pattern."""
        measurement = TimingMeasurement(
            start_address=start_addr,
            end_address=end_addr,
            measured_cycles=measured_cycles,
            threshold_cycles=self._threshold,
            is_suspicious=measured_cycles > self._threshold,
        )
        self._measurements.append(measurement)

        if measured_cycles > self._threshold:
            self._technique_counter += 1
            technique = AntiAnalysisTechnique(
                id=f"TIMING-{self._technique_counter}",
                technique_type=AntiAnalysisType.TIMING_CHECK,
                category=TechniqueCategory.TIMING,
                confidence=DetectionConfidence.HIGH,
                address=start_addr,
                description=f"Timing check exceeded threshold: {measured_cycles} > {self._threshold}",
                details={
                    'start_address': start_addr,
                    'end_address': end_addr,
                    'measured': measured_cycles,
                    'threshold': self._threshold,
                },
            )
            self._techniques.append(technique)
            return technique
        return None

    def check_performance_counter(self, address: int,
                                 api_name: str) -> AntiAnalysisTechnique | None:
        """Check for performance counter API usage."""
        perf_apis = {'QueryPerformanceCounter', 'GetTickCount', 'GetTickCount64',
                    'timeGetTime', 'clock_gettime', 'gettimeofday'}

        if api_name in perf_apis:
            self._technique_counter += 1
            technique = AntiAnalysisTechnique(
                id=f"PERF-{self._technique_counter}",
                technique_type=AntiAnalysisType.PERFORMANCE_COUNTER,
                category=TechniqueCategory.TIMING,
                confidence=DetectionConfidence.MEDIUM,
                address=address,
                description=f"Performance counter API: {api_name}",
                details={'api': api_name},
            )
            self._techniques.append(technique)
            return technique
        return None

    def get_techniques(self) -> list[AntiAnalysisTechnique]:
        """Get all detected techniques."""
        return self._techniques

    def get_measurements(self) -> list[TimingMeasurement]:
        """Get all timing measurements."""
        return self._measurements


class VMDetector:
    """Detects anti-VM/anti-sandbox techniques."""

    def __init__(self):
        self._indicators: list[VMIndicator] = []
        self._techniques: list[AntiAnalysisTechnique] = []
        self._technique_counter = 0

    def check_cpuid(self, address: int, leaf: int,
                   result: dict[str, int]) -> AntiAnalysisTechnique | None:
        """Check CPUID execution for VM detection."""
        technique = None

        if leaf == 0x1:
            # Check hypervisor bit (ECX bit 31)
            if result.get('ecx', 0) & (1 << 31):
                self._technique_counter += 1
                technique = AntiAnalysisTechnique(
                    id=f"CPUID-{self._technique_counter}",
                    technique_type=AntiAnalysisType.CPUID_CHECK,
                    category=TechniqueCategory.ANTI_VM,
                    confidence=DetectionConfidence.HIGH,
                    address=address,
                    description="CPUID hypervisor bit check",
                    details={'leaf': leaf, 'hypervisor_present': True},
                )
        elif leaf == 0x40000000:
            # Hypervisor vendor check
            vendor = ""
            if 'ebx' in result and 'ecx' in result and 'edx' in result:
                vendor = ''.join([
                    chr((result['ebx'] >> i) & 0xFF) for i in range(0, 32, 8)
                ] + [
                    chr((result['ecx'] >> i) & 0xFF) for i in range(0, 32, 8)
                ] + [
                    chr((result['edx'] >> i) & 0xFF) for i in range(0, 32, 8)
                ])

                vm_type = VMDetectionPatterns.check_cpuid_vendor(vendor)
                if vm_type:
                    self._technique_counter += 1
                    technique = AntiAnalysisTechnique(
                        id=f"CPUID-{self._technique_counter}",
                        technique_type=AntiAnalysisType.HYPERVISOR_DETECTION,
                        category=TechniqueCategory.ANTI_VM,
                        confidence=DetectionConfidence.CERTAIN,
                        address=address,
                        description=f"Hypervisor vendor detection: {vm_type}",
                        details={'leaf': leaf, 'vendor': vendor, 'vm_type': vm_type},
                    )
                    self._indicators.append(VMIndicator(
                        indicator_type='cpuid',
                        value=vendor,
                        vm_type=vm_type,
                        address=address,
                    ))

        if technique:
            self._techniques.append(technique)
        return technique

    def check_registry_access(self, address: int,
                             key_path: str) -> AntiAnalysisTechnique | None:
        """Check registry access for VM detection."""
        for pattern, vm_type in VMDetectionPatterns.REGISTRY_KEYS.items():
            if pattern.lower() in key_path.lower():
                self._technique_counter += 1
                technique = AntiAnalysisTechnique(
                    id=f"REG-{self._technique_counter}",
                    technique_type=AntiAnalysisType.REGISTRY_CHECK,
                    category=TechniqueCategory.ANTI_VM,
                    confidence=DetectionConfidence.HIGH,
                    address=address,
                    description=f"VM registry check: {vm_type}",
                    details={'key': key_path, 'vm_type': vm_type},
                )
                self._techniques.append(technique)
                self._indicators.append(VMIndicator(
                    indicator_type='registry',
                    value=key_path,
                    vm_type=vm_type,
                    address=address,
                ))
                return technique
        return None

    def check_file_access(self, address: int,
                         file_path: str) -> AntiAnalysisTechnique | None:
        """Check file access for VM detection."""
        for pattern, vm_type in VMDetectionPatterns.FILE_PATHS.items():
            if pattern.lower() in file_path.lower():
                self._technique_counter += 1
                technique = AntiAnalysisTechnique(
                    id=f"FILE-{self._technique_counter}",
                    technique_type=AntiAnalysisType.FILE_CHECK,
                    category=TechniqueCategory.ANTI_VM,
                    confidence=DetectionConfidence.HIGH,
                    address=address,
                    description=f"VM file check: {vm_type}",
                    details={'file': file_path, 'vm_type': vm_type},
                )
                self._techniques.append(technique)
                return technique
        return None

    def check_mac_address(self, address: int,
                         mac_address: str) -> AntiAnalysisTechnique | None:
        """Check MAC address for VM indicators."""
        vm_type = VMDetectionPatterns.check_mac_prefix(mac_address)
        if vm_type:
            self._technique_counter += 1
            technique = AntiAnalysisTechnique(
                id=f"MAC-{self._technique_counter}",
                technique_type=AntiAnalysisType.MAC_ADDRESS_CHECK,
                category=TechniqueCategory.ANTI_VM,
                confidence=DetectionConfidence.MEDIUM,
                address=address,
                description=f"VM MAC address check: {vm_type}",
                details={'mac': mac_address, 'vm_type': vm_type},
            )
            self._techniques.append(technique)
            return technique
        return None

    def check_process_name(self, address: int,
                          process_name: str) -> AntiAnalysisTechnique | None:
        """Check process name for VM indicators."""
        for name, vm_type in VMDetectionPatterns.PROCESS_NAMES.items():
            if name.lower() == process_name.lower():
                self._technique_counter += 1
                technique = AntiAnalysisTechnique(
                    id=f"PROC-{self._technique_counter}",
                    technique_type=AntiAnalysisType.PROCESS_CHECK,
                    category=TechniqueCategory.ANTI_VM,
                    confidence=DetectionConfidence.HIGH,
                    address=address,
                    description=f"VM process check: {vm_type}",
                    details={'process': process_name, 'vm_type': vm_type},
                )
                self._techniques.append(technique)
                return technique
        return None

    def get_techniques(self) -> list[AntiAnalysisTechnique]:
        """Get all detected techniques."""
        return self._techniques

    def get_indicators(self) -> list[VMIndicator]:
        """Get all VM indicators."""
        return self._indicators


class ObfuscationDetector:
    """Detects code obfuscation techniques."""

    def __init__(self):
        self._techniques: list[AntiAnalysisTechnique] = []
        self._technique_counter = 0

    def check_opaque_predicate(self, address: int,
                              always_true: bool) -> AntiAnalysisTechnique | None:
        """Check for opaque predicate pattern."""
        self._technique_counter += 1
        technique = AntiAnalysisTechnique(
            id=f"OPAQUE-{self._technique_counter}",
            technique_type=AntiAnalysisType.OPAQUE_PREDICATE,
            category=TechniqueCategory.OBFUSCATION,
            confidence=DetectionConfidence.MEDIUM,
            address=address,
            description=f"Opaque predicate (always {'true' if always_true else 'false'})",
            details={'always_true': always_true},
        )
        self._techniques.append(technique)
        return technique

    def check_anti_disassembly(self, address: int,
                              pattern: str) -> AntiAnalysisTechnique | None:
        """Check for anti-disassembly pattern."""
        patterns = {
            'junk_bytes': 'Junk bytes insertion',
            'overlapping': 'Overlapping instructions',
            'impossible_disasm': 'Impossible disassembly',
            'fake_jump': 'Fake conditional jump',
        }

        description = patterns.get(pattern, pattern)
        self._technique_counter += 1
        technique = AntiAnalysisTechnique(
            id=f"ANTIDIS-{self._technique_counter}",
            technique_type=AntiAnalysisType.ANTI_DISASSEMBLY,
            category=TechniqueCategory.OBFUSCATION,
            confidence=DetectionConfidence.HIGH,
            address=address,
            description=f"Anti-disassembly: {description}",
            details={'pattern': pattern},
        )
        self._techniques.append(technique)
        return technique

    def check_self_modifying_code(self, address: int, modified_range: tuple[int, int],
                                 is_code_section: bool) -> AntiAnalysisTechnique | None:
        """Check for self-modifying code."""
        if is_code_section:
            self._technique_counter += 1
            technique = AntiAnalysisTechnique(
                id=f"SMC-{self._technique_counter}",
                technique_type=AntiAnalysisType.SELF_MODIFYING_CODE,
                category=TechniqueCategory.OBFUSCATION,
                confidence=DetectionConfidence.CERTAIN,
                address=address,
                description=f"Self-modifying code: modifying {hex(modified_range[0])}-{hex(modified_range[1])}",
                details={
                    'modify_start': modified_range[0],
                    'modify_end': modified_range[1],
                },
            )
            self._techniques.append(technique)
            return technique
        return None

    def check_code_integrity(self, address: int,
                            checksum_type: str) -> AntiAnalysisTechnique | None:
        """Check for code integrity verification."""
        self._technique_counter += 1
        technique = AntiAnalysisTechnique(
            id=f"INTEGRITY-{self._technique_counter}",
            technique_type=AntiAnalysisType.CODE_INTEGRITY_CHECK,
            category=TechniqueCategory.OBFUSCATION,
            confidence=DetectionConfidence.HIGH,
            address=address,
            description=f"Code integrity check: {checksum_type}",
            details={'checksum_type': checksum_type},
        )
        self._techniques.append(technique)
        return technique

    def get_techniques(self) -> list[AntiAnalysisTechnique]:
        """Get all detected techniques."""
        return self._techniques


class AntiAnalysisDetector:
    """Main anti-analysis detection coordinator."""

    def __init__(self):
        self.anti_debug = AntiDebugDetector()
        self.timing = TimingDetector()
        self.vm = VMDetector()
        self.obfuscation = ObfuscationDetector()

        self._direct_techniques: list[AntiAnalysisTechnique] = []
        self._callbacks: list[Callable[[AntiAnalysisTechnique], None]] = []
        self._bypass_handlers: dict[AntiAnalysisType, Callable] = {}

    @property
    def technique_count(self) -> int:
        """Get total number of detected techniques."""
        return (len(self.anti_debug.get_techniques()) +
                len(self.timing.get_techniques()) +
                len(self.vm.get_techniques()) +
                len(self.obfuscation.get_techniques()) +
                len(self._direct_techniques))

    def add_callback(self, callback: Callable[[AntiAnalysisTechnique], None]) -> None:
        """Add detection callback."""
        self._callbacks.append(callback)

    def register_bypass(self, technique_type: AntiAnalysisType,
                       handler: Callable) -> None:
        """Register a bypass handler for a technique type."""
        self._bypass_handlers[technique_type] = handler

    def _notify(self, technique: AntiAnalysisTechnique) -> None:
        """Notify callbacks of detection."""
        for callback in self._callbacks:
            callback(technique)

    def check_api_call(self, api_name: str, address: int,
                      return_value: int | None = None) -> AntiAnalysisTechnique | None:
        """Check an API call for anti-analysis techniques."""
        # Check anti-debug APIs
        technique = self.anti_debug.check_api_call(api_name, address, return_value)
        if technique:
            self._notify(technique)
            return technique

        # Check timing APIs
        technique = self.timing.check_performance_counter(address, api_name)
        if technique:
            self._notify(technique)
            return technique

        return None

    def check_instruction(self, address: int, mnemonic: str,
                         operands: str = "") -> AntiAnalysisTechnique | None:
        """Check an instruction for anti-analysis patterns."""
        mnemonic_lower = mnemonic.lower()

        # RDTSC check
        if mnemonic_lower == 'rdtsc':
            technique = self.timing.check_rdtsc(address)
            if technique:
                self._notify(technique)
            return technique

        # CPUID check
        if mnemonic_lower == 'cpuid':
            technique = AntiAnalysisTechnique(
                id=f"CPUID-INST-{address:x}",
                technique_type=AntiAnalysisType.CPUID_CHECK,
                category=TechniqueCategory.ANTI_VM,
                confidence=DetectionConfidence.MEDIUM,
                address=address,
                description="CPUID instruction - potential VM detection",
                details={'mnemonic': mnemonic},
            )
            self._direct_techniques.append(technique)
            self._notify(technique)
            return technique

        # Debug register access
        if operands:
            for dreg in ['dr0', 'dr1', 'dr2', 'dr3', 'dr6', 'dr7']:
                if dreg in operands.lower():
                    technique = self.anti_debug.check_debug_register_access(address, dreg)
                    if technique:
                        self._notify(technique)
                    return technique

        # INT 2D (Windows debug check)
        if mnemonic_lower == 'int' and '2d' in operands.lower():
            technique = AntiAnalysisTechnique(
                id=f"INT2D-{address:x}",
                technique_type=AntiAnalysisType.DEBUGGER_DETECTION,
                category=TechniqueCategory.ANTI_DEBUG,
                confidence=DetectionConfidence.HIGH,
                address=address,
                description="INT 2D - kernel debugger detection",
                details={'mnemonic': mnemonic, 'operands': operands},
            )
            self._direct_techniques.append(technique)
            self._notify(technique)
            return technique

        return None

    def check_memory_access(self, address: int, target: int,
                           is_write: bool, data: bytes = b'') -> AntiAnalysisTechnique | None:
        """Check memory access for anti-analysis patterns."""
        # Check for writes to code section (self-modifying)
        # This would need section info to be properly implemented

        # Check for int3 scanning in reads
        if not is_write and b'\xCC' in data:
            technique = self.anti_debug.check_breakpoint_scan(
                address, (target, target + len(data)), []
            )
            if technique:
                self._notify(technique)
            return technique

        return None

    def get_all_techniques(self) -> list[AntiAnalysisTechnique]:
        """Get all detected techniques from all detectors."""
        techniques = []
        techniques.extend(self.anti_debug.get_techniques())
        techniques.extend(self.timing.get_techniques())
        techniques.extend(self.vm.get_techniques())
        techniques.extend(self.obfuscation.get_techniques())
        techniques.extend(self._direct_techniques)
        return techniques

    def get_techniques_by_category(self,
                                  category: TechniqueCategory) -> list[AntiAnalysisTechnique]:
        """Get techniques by category."""
        return [t for t in self.get_all_techniques() if t.category == category]

    def get_summary(self) -> dict[str, Any]:
        """Get summary of detected techniques."""
        techniques = self.get_all_techniques()

        by_category = defaultdict(int)
        by_type = defaultdict(int)
        by_confidence = defaultdict(int)

        for t in techniques:
            by_category[t.category.name] += 1
            by_type[t.technique_type.name] += 1
            by_confidence[t.confidence.name] += 1

        return {
            'total': len(techniques),
            'by_category': dict(by_category),
            'by_type': dict(by_type),
            'by_confidence': dict(by_confidence),
            'bypassed_count': sum(1 for t in techniques if t.bypassed),
        }

    def generate_report(self) -> str:
        """Generate a text report."""
        lines = ["=" * 60, "ANTI-ANALYSIS DETECTION REPORT", "=" * 60, ""]

        summary = self.get_summary()
        lines.append(f"Total Techniques Detected: {summary['total']}")
        lines.append(f"Bypassed: {summary['bypassed_count']}")
        lines.append("")

        # Group by category
        for category in TechniqueCategory:
            techniques = self.get_techniques_by_category(category)
            if techniques:
                lines.append(f"\n{category.name} ({len(techniques)}):")
                lines.append("-" * 40)
                for t in techniques:
                    lines.append(f"  [{t.id}] {t.technique_type.name}")
                    lines.append(f"    Address: {hex(t.address)}")
                    lines.append(f"    Confidence: {t.confidence.name}")
                    lines.append(f"    Description: {t.description}")
                    if t.bypassed:
                        lines.append(f"    Status: BYPASSED ({t.bypass_method})")
                    lines.append("")

        return "\n".join(lines)


def create_anti_analysis_detector() -> AntiAnalysisDetector:
    """Create an anti-analysis detector."""
    return AntiAnalysisDetector()


def quick_check(detector: AntiAnalysisDetector) -> dict[str, Any]:
    """Perform quick analysis check."""
    return detector.get_summary()
