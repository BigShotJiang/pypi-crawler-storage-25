"""Allow running PyUniDbg CLI as ``python -m pyunidbg``."""
from pyunidbg.cli import run_cli

if __name__ == "__main__":
    run_cli()
