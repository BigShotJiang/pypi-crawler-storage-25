"""
Unified exception hierarchy for PyUniDbg.

All domain-specific exceptions inherit from :class:`PyUniDbgError`,
making it easy to catch any library error with a single ``except``
while still allowing fine-grained handling::

    from pyunidbg.errors import PyUniDbgError, LinkerError

    try:
        linker.load_library("libfoo.so")
    except LinkerError:
        ...            # only linker failures
    except PyUniDbgError:
        ...            # any PyUniDbg error

Hierarchy
---------

.. code-block:: text

    PyUniDbgError
    ├── EmulationError
    ├── MemoryAccessError
    ├── ArchitectureError
    ├── LinkerError
    │   └── SymbolResolutionError
    ├── LoaderError
    ├── ConfigurationError
    ├── SnapshotError
    ├── IntegrationError
    │   ├── IntegrationConnectionError
    │   ├── IntegrationProtocolError
    │   └── IntegrationTimeoutError
    └── ScriptingError
"""

from __future__ import annotations

# ── Root ──────────────────────────────────────────────────────────────────────

class PyUniDbgError(Exception):
    """Base exception for all PyUniDbg errors."""


# ── Core / Emulation ─────────────────────────────────────────────────────────

class EmulationError(PyUniDbgError):
    """An error occurred during code emulation (Unicorn engine, hooks, etc.)."""


class MemoryAccessError(PyUniDbgError):
    """Invalid memory operation (unmapped read/write, protection violation)."""


class ArchitectureError(PyUniDbgError):
    """Unsupported or mis-configured CPU architecture / ABI."""


# ── Linker / Loader ──────────────────────────────────────────────────────────

class LinkerError(PyUniDbgError):
    """Error during dynamic linking (library loading, relocation, init)."""


class SymbolResolutionError(LinkerError):
    """A required symbol could not be resolved."""


class LoaderError(PyUniDbgError):
    """Error parsing or loading a binary (ELF, Mach-O, DEX)."""


# ── Configuration / Snapshots ────────────────────────────────────────────────

class ConfigurationError(PyUniDbgError):
    """Invalid configuration or missing prerequisite setup."""


class SnapshotError(PyUniDbgError):
    """Error during snapshot save, restore, or diff."""


# ── Integrations ─────────────────────────────────────────────────────────────

class IntegrationError(PyUniDbgError):
    """Base for all external-tool integration errors."""


class IntegrationConnectionError(IntegrationError, ConnectionError):
    """Cannot connect to an external tool (IDA, Ghidra, r2, …).

    Also inherits from :class:`ConnectionError` so callers who catch the
    stdlib type still work.
    """


class IntegrationProtocolError(IntegrationError):
    """Unexpected response or framing error from an external tool."""


class IntegrationTimeoutError(IntegrationError, TimeoutError):
    """Timed out waiting for an external-tool response.

    Also inherits from :class:`TimeoutError` for stdlib compatibility.
    """


# ── Scripting ────────────────────────────────────────────────────────────────

class ScriptingError(PyUniDbgError):
    """Error in the scripting subsystem (Frida API, interceptor, etc.)."""
