"""
Concolic (CONCrete + symbOLIC) Execution Engine for PyUniDbg.

Combines concrete emulation with symbolic constraint tracking to
systematically explore execution paths and generate inputs that
reach specific code locations.

Unlike pure symbolic execution, concolic execution runs real code
on the Unicorn emulator while maintaining a shadow symbolic state.
At each branch, it records the path constraint and later negates
constraints to discover new paths.

Features:
- Instruction-level symbolic lifting for ARM/ARM64/x86/x86_64
- Concrete execution via Unicorn with shadow symbolic state
- Automatic branch detection and constraint recording
- Coverage-guided input generation via constraint negation
- Taint tracking from symbolic inputs through computation
- Snapshot/restore for efficient path exploration
- Pluggable SMT solver backend (built-in simple solver + Z3 bridge)

Usage:
    from pyunidbg import Emulator
    from pyunidbg.concolic import ConcolicEngine, ConcolicConfig

    emu = Emulator()
    engine = ConcolicEngine(emu)

    engine.add_symbolic_input(0x1000, 16, name="user_input")
    results = engine.explore(
        start=0x4000,
        targets={0x5000},
        avoid={0x6000},
        max_iterations=50,
    )

    for solution in results.solutions:
        print(f"Input to reach target: {solution.input_bytes.hex()}")
"""

from __future__ import annotations

import copy
import hashlib
import logging
import struct
from collections import deque
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    FrozenSet,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

if TYPE_CHECKING:
    from ..core.emulator import Emulator

from ..symbolic import (
    BinaryOp,
    Constraint,
    ExplorationStrategy,
    PathState,
    SimpleSolver,
    Solver,
    SymbolicEngine,
    SymbolicValue,
    UnaryOp,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

class InputMutationStrategy(Enum):
    """How new inputs are generated between iterations."""
    NEGATE_LAST = auto()
    NEGATE_RANDOM = auto()
    NEGATE_ALL = auto()
    COVERAGE_GUIDED = auto()


@dataclass
class ConcolicConfig:
    """Tunable parameters for the concolic engine."""
    max_iterations: int = 100
    max_instructions_per_run: int = 500_000
    max_paths: int = 2000
    max_constraint_depth: int = 256
    mutation_strategy: InputMutationStrategy = InputMutationStrategy.COVERAGE_GUIDED
    solver_timeout_ms: int = 5000
    track_memory_taint: bool = True
    track_register_taint: bool = True
    snapshot_on_fork: bool = True
    log_branches: bool = False


# ---------------------------------------------------------------------------
# Symbolic input descriptor
# ---------------------------------------------------------------------------

@dataclass
class SymbolicInput:
    """Describes a region of memory marked as symbolic."""
    name: str
    address: int
    size: int
    concrete_seed: bytes = b""
    bit_width: int = 8

    @property
    def symbol_names(self) -> list[str]:
        return [f"{self.name}_{i}" for i in range(self.size)]


# ---------------------------------------------------------------------------
# Branch record
# ---------------------------------------------------------------------------

@dataclass
class BranchRecord:
    """A single branch observed during concrete execution."""
    pc: int
    taken: bool
    condition: SymbolicValue | None = None
    true_target: int = 0
    false_target: int = 0


# ---------------------------------------------------------------------------
# Taint tracker
# ---------------------------------------------------------------------------

class TaintTag:
    """Lightweight taint tag attached to values originating from symbolic input."""
    __slots__ = ("sources",)

    def __init__(self, sources: frozenset[str] | None = None):
        self.sources: frozenset[str] = sources or frozenset()

    def merge(self, other: TaintTag) -> TaintTag:
        return TaintTag(self.sources | other.sources)

    @property
    def is_tainted(self) -> bool:
        return bool(self.sources)

    def __repr__(self) -> str:
        return f"Taint({','.join(sorted(self.sources))})" if self.sources else "Clean"


class TaintTracker:
    """
    Shadow taint state running alongside the concrete emulator.

    Tracks which registers and memory bytes derive (transitively)
    from symbolic inputs so the engine knows which branches are
    worth recording constraints for.
    """

    def __init__(self):
        self._reg_taint: dict[str, TaintTag] = {}
        self._mem_taint: dict[int, TaintTag] = {}

    def mark_memory(self, address: int, size: int, source: str) -> None:
        tag = TaintTag(frozenset([source]))
        for i in range(size):
            self._mem_taint[address + i] = tag

    def get_memory_taint(self, address: int, size: int = 1) -> TaintTag:
        combined = TaintTag()
        for i in range(size):
            t = self._mem_taint.get(address + i)
            if t:
                combined = combined.merge(t)
        return combined

    def set_register_taint(self, reg: str, tag: TaintTag) -> None:
        if tag.is_tainted:
            self._reg_taint[reg] = tag
        else:
            self._reg_taint.pop(reg, None)

    def get_register_taint(self, reg: str) -> TaintTag:
        return self._reg_taint.get(reg, TaintTag())

    def propagate(self, dst_reg: str, *src_regs: str) -> TaintTag:
        merged = TaintTag()
        for r in src_regs:
            merged = merged.merge(self.get_register_taint(r))
        self.set_register_taint(dst_reg, merged)
        return merged

    def propagate_mem_to_reg(self, dst_reg: str, address: int, size: int) -> TaintTag:
        tag = self.get_memory_taint(address, size)
        self.set_register_taint(dst_reg, tag)
        return tag

    def propagate_reg_to_mem(self, src_reg: str, address: int, size: int) -> None:
        tag = self.get_register_taint(src_reg)
        for i in range(size):
            if tag.is_tainted:
                self._mem_taint[address + i] = tag
            else:
                self._mem_taint.pop(address + i, None)

    def snapshot(self) -> tuple[dict[str, TaintTag], dict[int, TaintTag]]:
        return dict(self._reg_taint), dict(self._mem_taint)

    def restore(self, snap: tuple[dict[str, TaintTag], dict[int, TaintTag]]) -> None:
        self._reg_taint, self._mem_taint = dict(snap[0]), dict(snap[1])

    def clear(self) -> None:
        self._reg_taint.clear()
        self._mem_taint.clear()


# ---------------------------------------------------------------------------
# Instruction lifter — builds symbolic expressions from concrete instructions
# ---------------------------------------------------------------------------

class InstructionLifter:
    """
    Lift disassembled instructions into lightweight symbolic operations
    on the taint tracker.  This does *not* aim for full IR precision —
    it only needs to propagate taint and record branch conditions.
    """

    def __init__(self, emulator: Emulator, taint: TaintTracker,
                 sym_mem: dict[int, SymbolicValue],
                 sym_regs: dict[str, SymbolicValue]):
        self._emu = emulator
        self._taint = taint
        self._sym_mem = sym_mem
        self._sym_regs = sym_regs

    def _reg_name(self, cs_reg_name: str) -> str:
        return cs_reg_name.upper()

    def _read_sym_reg(self, name: str) -> SymbolicValue:
        name = name.upper()
        if name in self._sym_regs:
            return self._sym_regs[name]
        val = 0
        try:
            regs = self._emu.cpu.dump()
            val = regs.get(name, 0)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        bits = 64 if self._emu.is_64bit else 32
        return SymbolicValue.concrete(val, bits)

    def _write_sym_reg(self, name: str, val: SymbolicValue) -> None:
        self._sym_regs[name.upper()] = val

    def _read_sym_mem(self, addr: int, size: int) -> SymbolicValue:
        if addr in self._sym_mem:
            return self._sym_mem[addr]
        try:
            data = self._emu.memory.read(addr, size)
            v = int.from_bytes(data, "little")
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            v = 0
        return SymbolicValue.concrete(v, size * 8)

    def _write_sym_mem(self, addr: int, val: SymbolicValue) -> None:
        self._sym_mem[addr] = val

    # --- ARM64 lifter -------------------------------------------------

    def lift_arm64(self, mnemonic: str, op_str: str, address: int, size: int) -> SymbolicValue | None:
        """Lift a single ARM64 instruction; returns branch condition if applicable."""
        mn = mnemonic.lower()
        ops = [o.strip() for o in op_str.split(",") if o.strip()]

        if mn in ("mov", "movz", "movn", "movk"):
            if len(ops) >= 2:
                dst = ops[0]
                self._taint.propagate(dst.upper())
                if ops[1].startswith("#"):
                    self._write_sym_reg(dst, SymbolicValue.concrete(
                        self._parse_imm(ops[1]), 64))
                else:
                    sv = self._read_sym_reg(ops[1])
                    self._write_sym_reg(dst, sv)
                    self._taint.set_register_taint(
                        dst.upper(), self._taint.get_register_taint(ops[1].upper()))

        elif mn in ("add", "adds", "sub", "subs"):
            if len(ops) >= 3:
                dst, src1 = ops[0], ops[1]
                a = self._read_sym_reg(src1)
                if ops[2].startswith("#"):
                    b = SymbolicValue.concrete(self._parse_imm(ops[2]), a.size)
                else:
                    b = self._read_sym_reg(ops[2])
                    self._taint.propagate(dst.upper(), src1.upper(), ops[2].upper())
                op = BinaryOp.ADD if "add" in mn else BinaryOp.SUB
                self._write_sym_reg(dst, a._binary_op(op, b))
                self._taint.propagate(dst.upper(), src1.upper())

        elif mn in ("and", "ands", "orr", "eor"):
            if len(ops) >= 3:
                dst, src1 = ops[0], ops[1]
                a = self._read_sym_reg(src1)
                if ops[2].startswith("#"):
                    b = SymbolicValue.concrete(self._parse_imm(ops[2]), a.size)
                else:
                    b = self._read_sym_reg(ops[2])
                _map = {"and": BinaryOp.AND, "ands": BinaryOp.AND,
                        "orr": BinaryOp.OR, "eor": BinaryOp.XOR}
                self._write_sym_reg(dst, a._binary_op(_map[mn], b))
                self._taint.propagate(dst.upper(), src1.upper())

        elif mn in ("lsl", "lsr", "asr"):
            if len(ops) >= 3:
                dst, src = ops[0], ops[1]
                a = self._read_sym_reg(src)
                if ops[2].startswith("#"):
                    b = SymbolicValue.concrete(self._parse_imm(ops[2]), a.size)
                else:
                    b = self._read_sym_reg(ops[2])
                _map = {"lsl": BinaryOp.SHL, "lsr": BinaryOp.SHR, "asr": BinaryOp.SAR}
                self._write_sym_reg(dst, a._binary_op(_map[mn], b))
                self._taint.propagate(dst.upper(), src.upper())

        elif mn in ("ldr", "ldrb", "ldrh", "ldrsb", "ldrsh", "ldrsw"):
            if len(ops) >= 2:
                dst = ops[0]
                addr_val = self._parse_mem_operand(ops[1:])
                if addr_val is not None:
                    sz = {"ldr": 8 if self._emu.is_64bit else 4,
                          "ldrb": 1, "ldrsb": 1, "ldrh": 2, "ldrsh": 2,
                          "ldrsw": 4}.get(mn, 4)
                    sv = self._read_sym_mem(addr_val, sz)
                    self._write_sym_reg(dst, sv)
                    self._taint.propagate_mem_to_reg(dst.upper(), addr_val, sz)

        elif mn in ("str", "strb", "strh"):
            if len(ops) >= 2:
                src = ops[0]
                addr_val = self._parse_mem_operand(ops[1:])
                if addr_val is not None:
                    sz = {"str": 8 if self._emu.is_64bit else 4,
                          "strb": 1, "strh": 2}.get(mn, 4)
                    sv = self._read_sym_reg(src)
                    self._write_sym_mem(addr_val, sv)
                    self._taint.propagate_reg_to_mem(src.upper(), addr_val, sz)

        elif mn == "cmp":
            if len(ops) >= 2:
                a = self._read_sym_reg(ops[0])
                if ops[1].startswith("#"):
                    b = SymbolicValue.concrete(self._parse_imm(ops[1]), a.size)
                else:
                    b = self._read_sym_reg(ops[1])
                diff = a._binary_op(BinaryOp.SUB, b)
                self._write_sym_reg("_CMP_RESULT", diff)
                self._write_sym_reg("_CMP_A", a)
                self._write_sym_reg("_CMP_B", b)

        elif mn.startswith("b.") or mn.startswith("b") and mn[1:] in (
            "eq", "ne", "lt", "le", "gt", "ge", "hi", "hs", "lo", "ls",
            "mi", "pl", "vs", "vc", "al",
        ):
            cond_code = mn.split(".")[-1] if "." in mn else mn[1:]
            a = self._read_sym_reg("_CMP_A")
            b = self._read_sym_reg("_CMP_B")
            return self._make_condition(cond_code, a, b)

        elif mn == "cbz" and len(ops) >= 2:
            val = self._read_sym_reg(ops[0])
            zero = SymbolicValue.concrete(0, val.size)
            return val._binary_op(BinaryOp.EQ, zero, result_size=1)

        elif mn == "cbnz" and len(ops) >= 2:
            val = self._read_sym_reg(ops[0])
            zero = SymbolicValue.concrete(0, val.size)
            return val._binary_op(BinaryOp.NE, zero, result_size=1)

        elif mn == "tbz" and len(ops) >= 2:
            val = self._read_sym_reg(ops[0])
            bit = self._parse_imm(ops[1]) if len(ops) > 1 else 0
            mask = SymbolicValue.concrete(1 << bit, val.size)
            result = val._binary_op(BinaryOp.AND, mask)
            zero = SymbolicValue.concrete(0, result.size)
            return result._binary_op(BinaryOp.EQ, zero, result_size=1)

        elif mn == "tbnz" and len(ops) >= 2:
            val = self._read_sym_reg(ops[0])
            bit = self._parse_imm(ops[1]) if len(ops) > 1 else 0
            mask = SymbolicValue.concrete(1 << bit, val.size)
            result = val._binary_op(BinaryOp.AND, mask)
            zero = SymbolicValue.concrete(0, result.size)
            return result._binary_op(BinaryOp.NE, zero, result_size=1)

        return None

    def lift_arm(self, mnemonic: str, op_str: str, address: int, size: int) -> SymbolicValue | None:
        """Lift ARM32 instructions — mirrors ARM64 logic with 32-bit regs."""
        mn = mnemonic.lower().rstrip("s")
        ops = [o.strip() for o in op_str.split(",") if o.strip()]

        if mn in ("mov", "movw", "movt"):
            if len(ops) >= 2:
                dst = ops[0]
                if ops[1].startswith("#"):
                    self._write_sym_reg(dst, SymbolicValue.concrete(
                        self._parse_imm(ops[1]), 32))
                else:
                    self._write_sym_reg(dst, self._read_sym_reg(ops[1]))
                    self._taint.set_register_taint(
                        dst.upper(), self._taint.get_register_taint(ops[1].upper()))

        elif mn in ("add", "sub"):
            if len(ops) >= 3:
                dst, src1 = ops[0], ops[1]
                a = self._read_sym_reg(src1)
                b = (SymbolicValue.concrete(self._parse_imm(ops[2]), 32)
                     if ops[2].startswith("#") else self._read_sym_reg(ops[2]))
                op = BinaryOp.ADD if mn == "add" else BinaryOp.SUB
                self._write_sym_reg(dst, a._binary_op(op, b))
                self._taint.propagate(dst.upper(), src1.upper())

        elif mn == "cmp":
            if len(ops) >= 2:
                a = self._read_sym_reg(ops[0])
                b = (SymbolicValue.concrete(self._parse_imm(ops[1]), 32)
                     if ops[1].startswith("#") else self._read_sym_reg(ops[1]))
                self._write_sym_reg("_CMP_A", a)
                self._write_sym_reg("_CMP_B", b)

        elif mn in ("ldr", "ldrb", "ldrh"):
            if len(ops) >= 2:
                dst = ops[0]
                addr_val = self._parse_mem_operand(ops[1:])
                if addr_val is not None:
                    sz = {"ldr": 4, "ldrb": 1, "ldrh": 2}.get(mn, 4)
                    self._write_sym_reg(dst, self._read_sym_mem(addr_val, sz))
                    self._taint.propagate_mem_to_reg(dst.upper(), addr_val, sz)

        elif mn in ("str", "strb", "strh"):
            if len(ops) >= 2:
                src = ops[0]
                addr_val = self._parse_mem_operand(ops[1:])
                if addr_val is not None:
                    sz = {"str": 4, "strb": 1, "strh": 2}.get(mn, 4)
                    self._write_sym_mem(addr_val, self._read_sym_reg(src))
                    self._taint.propagate_reg_to_mem(src.upper(), addr_val, sz)

        cond_suffix = mnemonic.lower()[-2:]
        if cond_suffix in ("eq", "ne", "lt", "le", "gt", "ge", "hi", "hs", "lo", "ls"):
            a = self._read_sym_reg("_CMP_A")
            b = self._read_sym_reg("_CMP_B")
            return self._make_condition(cond_suffix, a, b)

        return None

    def lift_x86(self, mnemonic: str, op_str: str, address: int, size: int) -> SymbolicValue | None:
        """Lift x86/x86_64 instructions."""
        mn = mnemonic.lower()
        ops = [o.strip() for o in op_str.split(",") if o.strip()]

        if mn == "mov" and len(ops) >= 2:
            dst, src = ops[0], ops[1]
            if self._is_register(src):
                self._write_sym_reg(dst, self._read_sym_reg(src))
                self._taint.set_register_taint(
                    dst.upper(), self._taint.get_register_taint(src.upper()))
            elif src.startswith("0x") or src.lstrip("-").isdigit():
                self._write_sym_reg(dst, SymbolicValue.concrete(
                    self._parse_imm(src), 64 if self._emu.is_64bit else 32))

        elif mn in ("add", "sub", "and", "or", "xor") and len(ops) >= 2:
            dst = ops[0]
            a = self._read_sym_reg(dst)
            if ops[1].startswith("0x") or ops[1].lstrip("-").isdigit():
                b = SymbolicValue.concrete(self._parse_imm(ops[1]), a.size)
            else:
                b = self._read_sym_reg(ops[1])
            _map = {"add": BinaryOp.ADD, "sub": BinaryOp.SUB,
                    "and": BinaryOp.AND, "or": BinaryOp.OR, "xor": BinaryOp.XOR}
            self._write_sym_reg(dst, a._binary_op(_map[mn], b))
            self._taint.propagate(dst.upper(), dst.upper())

        elif mn in ("cmp", "test") and len(ops) >= 2:
            a = self._read_sym_reg(ops[0])
            if ops[1].startswith("0x") or ops[1].lstrip("-").isdigit():
                b = SymbolicValue.concrete(self._parse_imm(ops[1]), a.size)
            else:
                b = self._read_sym_reg(ops[1])
            self._write_sym_reg("_CMP_A", a)
            self._write_sym_reg("_CMP_B", b)
            if mn == "test":
                self._write_sym_reg("_CMP_OP", SymbolicValue.concrete(1, 8))
            else:
                self._write_sym_reg("_CMP_OP", SymbolicValue.concrete(0, 8))

        elif mn.startswith("j") and mn != "jmp":
            cc = mn[1:]
            a = self._read_sym_reg("_CMP_A")
            b = self._read_sym_reg("_CMP_B")
            return self._make_condition(cc, a, b)

        return None

    # --- helpers ---

    def _make_condition(self, cc: str, a: SymbolicValue, b: SymbolicValue) -> SymbolicValue:
        _map = {
            "eq": BinaryOp.EQ, "e": BinaryOp.EQ, "z": BinaryOp.EQ,
            "ne": BinaryOp.NE, "nz": BinaryOp.NE,
            "lt": BinaryOp.LT, "l": BinaryOp.LT,
            "le": BinaryOp.LE, "ng": BinaryOp.LE,
            "gt": BinaryOp.GT, "g": BinaryOp.GT,
            "ge": BinaryOp.GE, "nl": BinaryOp.GE,
            "hi": BinaryOp.UGT, "a": BinaryOp.UGT,
            "hs": BinaryOp.UGE, "ae": BinaryOp.UGE, "nb": BinaryOp.UGE,
            "lo": BinaryOp.ULT, "b": BinaryOp.ULT,
            "ls": BinaryOp.ULE, "be": BinaryOp.ULE,
            "mi": BinaryOp.LT, "pl": BinaryOp.GE,
        }
        op = _map.get(cc, BinaryOp.NE)
        return a._binary_op(op, b, result_size=1)

    @staticmethod
    def _parse_imm(s: str) -> int:
        s = s.strip().lstrip("#")
        try:
            return int(s, 0)
        except ValueError:
            return 0

    def _parse_mem_operand(self, parts: list[str]) -> int | None:
        """Try to evaluate a memory operand to a concrete address."""
        raw = ", ".join(parts).strip("[] ")
        tokens = [t.strip() for t in raw.split(",")]
        if not tokens:
            return None
        base_name = tokens[0]
        try:
            regs = self._emu.cpu.dump()
            base = regs.get(base_name.upper(), 0)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return None
        if len(tokens) > 1:
            offset = self._parse_imm(tokens[1])
            base += offset
        return base

    @staticmethod
    def _is_register(s: str) -> bool:
        s = s.lower()
        if s.startswith(("r", "x", "w", "e", "sp", "lr", "pc", "fp")):
            return True
        if s in ("rax", "rbx", "rcx", "rdx", "rsi", "rdi", "rsp", "rbp",
                 "eax", "ebx", "ecx", "edx", "esi", "edi", "esp", "ebp"):
            return True
        return False


# ---------------------------------------------------------------------------
# Concolic run result
# ---------------------------------------------------------------------------

@dataclass
class ConcolicSolution:
    """A single solution found by the concolic engine."""
    input_bytes: bytes
    input_mapping: dict[str, int]
    path_length: int
    target_address: int
    constraint_count: int


@dataclass
class ConcolicRunResult:
    """Aggregate result of a concolic exploration campaign."""
    solutions: list[ConcolicSolution] = field(default_factory=list)
    iterations: int = 0
    total_instructions: int = 0
    unique_paths: int = 0
    coverage: set[int] = field(default_factory=set)
    branches_explored: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def found_target(self) -> bool:
        return len(self.solutions) > 0


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class ConcolicEngine:
    """
    Concolic execution engine.

    Runs the emulator concretely while maintaining a shadow symbolic
    state.  After each run, it negates collected branch constraints
    to generate new inputs that exercise different paths.
    """

    def __init__(
        self,
        emulator: Emulator,
        config: ConcolicConfig | None = None,
        solver: Solver | None = None,
    ):
        self.emulator = emulator
        self.config = config or ConcolicConfig()
        self.solver = solver or SimpleSolver(max_iterations=20_000)

        self._inputs: list[SymbolicInput] = []
        self._taint = TaintTracker()
        self._sym_mem: dict[int, SymbolicValue] = {}
        self._sym_regs: dict[str, SymbolicValue] = {}

        self._branch_log: list[BranchRecord] = []
        self._path_constraints: list[Constraint] = []
        self._coverage: set[int] = set()
        self._path_hashes: set[str] = set()

        self._input_queue: deque[bytes] = deque()
        self._tested_inputs: set[bytes] = set()

        self._hook_handle: int | None = None
        self._lifter: InstructionLifter | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_symbolic_input(
        self,
        address: int,
        size: int,
        name: str = "input",
        seed: bytes = b"",
    ) -> SymbolicInput:
        """
        Mark a memory region as symbolic input.

        The region will be initialized with *seed* (zero-padded
        to *size*) for the first concrete run, and mutated by the
        solver on subsequent iterations.
        """
        if not seed:
            seed = b"\x00" * size
        elif len(seed) < size:
            seed = seed + b"\x00" * (size - len(seed))
        si = SymbolicInput(name=name, address=address, size=size, concrete_seed=seed[:size])
        self._inputs.append(si)
        return si

    def explore(
        self,
        start: int,
        targets: set[int] | None = None,
        avoid: set[int] | None = None,
        max_iterations: int | None = None,
    ) -> ConcolicRunResult:
        """
        Run the concolic exploration loop.

        Returns results containing any inputs that reach *targets*.
        """
        targets = targets or set()
        avoid = avoid or set()
        max_iter = max_iterations or self.config.max_iterations
        result = ConcolicRunResult()

        current_input = self._build_initial_input()
        self._tested_inputs.add(current_input)

        for iteration in range(max_iter):
            result.iterations = iteration + 1

            self._write_input(current_input)
            self._setup_symbolic_state()

            run_cov: set[int] = set()
            hit_target = False
            target_addr = 0

            self._branch_log.clear()
            self._path_constraints.clear()

            try:
                insn_count = self._run_concrete(
                    start, targets, avoid, run_cov,
                )
                result.total_instructions += insn_count
            except _TargetReached as tr:
                hit_target = True
                target_addr = tr.address
                result.total_instructions += tr.instruction_count
            except Exception as exc:
                result.errors.append(f"iter {iteration}: {exc}")
                logger.debug("Concolic run error: %s", exc)

            new_addrs = run_cov - self._coverage
            self._coverage |= run_cov
            result.coverage = set(self._coverage)

            path_hash = self._hash_path()
            if path_hash not in self._path_hashes:
                self._path_hashes.add(path_hash)
                result.unique_paths += 1

            result.branches_explored += len(self._branch_log)

            if hit_target:
                mapping = self._input_to_mapping(current_input)
                sol = ConcolicSolution(
                    input_bytes=current_input,
                    input_mapping=mapping,
                    path_length=len(self._branch_log),
                    target_address=target_addr,
                    constraint_count=len(self._path_constraints),
                )
                result.solutions.append(sol)
                logger.info(
                    "Target %#x reached on iteration %d with input %s",
                    target_addr, iteration, current_input.hex(),
                )

            self._generate_new_inputs()

            if not self._input_queue:
                logger.info("No more inputs to try — stopping after %d iterations", iteration + 1)
                break

            current_input = self._input_queue.popleft()
            while current_input in self._tested_inputs and self._input_queue:
                current_input = self._input_queue.popleft()
            self._tested_inputs.add(current_input)

        return result

    def get_coverage(self) -> set[int]:
        return set(self._coverage)

    def get_branch_log(self) -> list[BranchRecord]:
        return list(self._branch_log)

    def reset(self) -> None:
        self._inputs.clear()
        self._taint.clear()
        self._sym_mem.clear()
        self._sym_regs.clear()
        self._branch_log.clear()
        self._path_constraints.clear()
        self._coverage.clear()
        self._path_hashes.clear()
        self._input_queue.clear()
        self._tested_inputs.clear()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_initial_input(self) -> bytes:
        parts = []
        for si in self._inputs:
            parts.append(si.concrete_seed)
        return b"".join(parts)

    def _write_input(self, data: bytes) -> None:
        offset = 0
        for si in self._inputs:
            chunk = data[offset:offset + si.size]
            if len(chunk) < si.size:
                chunk = chunk + b"\x00" * (si.size - len(chunk))
            self.emulator.memory.write(si.address, chunk)
            offset += si.size

    def _setup_symbolic_state(self) -> None:
        self._taint.clear()
        self._sym_mem.clear()
        self._sym_regs.clear()

        for si in self._inputs:
            for i in range(si.size):
                sym_name = f"{si.name}_{i}"
                sv = SymbolicValue.symbol(sym_name, si.bit_width)
                self._sym_mem[si.address + i] = sv
                self._taint.mark_memory(si.address + i, 1, sym_name)

        self._lifter = InstructionLifter(
            self.emulator, self._taint, self._sym_mem, self._sym_regs,
        )

    def _run_concrete(
        self,
        start: int,
        targets: set[int],
        avoid: set[int],
        run_cov: set[int],
    ) -> int:
        from unicorn import UC_HOOK_CODE

        from ..core.constants import Architecture

        insn_count = 0
        arch = self.emulator.config.arch

        def _code_hook(uc, address, size, user_data):
            nonlocal insn_count
            insn_count += 1
            run_cov.add(address)

            if address in avoid:
                uc.emu_stop()
                return

            if address in targets:
                uc.emu_stop()
                raise _TargetReached(address, insn_count)

            if insn_count >= self.config.max_instructions_per_run:
                uc.emu_stop()
                return

            try:
                code = self.emulator.memory.read(address, min(size, 16))
                for insn in self.emulator._cs.disasm(code, address):
                    condition = None
                    if arch in (Architecture.ARM64,):
                        condition = self._lifter.lift_arm64(
                            insn.mnemonic, insn.op_str, address, size)
                    elif arch == Architecture.ARM:
                        condition = self._lifter.lift_arm(
                            insn.mnemonic, insn.op_str, address, size)
                    elif arch in (Architecture.X86, Architecture.X86_64):
                        condition = self._lifter.lift_x86(
                            insn.mnemonic, insn.op_str, address, size)

                    if condition is not None:
                        taken = self._is_branch_taken(address, size)
                        self._record_branch(address, condition, taken)
                    break
            except _TargetReached:
                raise
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        handle = self.emulator._uc.hook_add(UC_HOOK_CODE, _code_hook)
        try:
            self.emulator.cpu.pc = start
            self.emulator._uc.emu_start(
                start,
                self.emulator._exit_address,
                timeout=0,
                count=self.config.max_instructions_per_run,
            )
        except _TargetReached:
            raise
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        finally:
            self.emulator._uc.hook_del(handle)

        return insn_count

    def _is_branch_taken(self, branch_pc: int, insn_size: int) -> bool:
        """After single-stepping past a branch, check if PC diverged."""
        next_linear = branch_pc + insn_size
        actual_pc = self.emulator.cpu.pc
        return actual_pc != next_linear

    def _record_branch(self, pc: int, condition: SymbolicValue, taken: bool) -> None:
        if not condition:
            return
        rec = BranchRecord(pc=pc, taken=taken, condition=condition)
        self._branch_log.append(rec)

        constraint = Constraint(condition, is_true=taken, location=pc)
        if len(self._path_constraints) < self.config.max_constraint_depth:
            self._path_constraints.append(constraint)

        if self.config.log_branches:
            logger.debug("Branch @%#x taken=%s cond=%s", pc, taken, condition)

    def _generate_new_inputs(self) -> None:
        strategy = self.config.mutation_strategy

        if strategy == InputMutationStrategy.NEGATE_LAST:
            indices = [len(self._path_constraints) - 1] if self._path_constraints else []
        elif strategy == InputMutationStrategy.NEGATE_RANDOM:
            import random
            if self._path_constraints:
                indices = [random.randrange(len(self._path_constraints))]
            else:
                indices = []
        elif strategy == InputMutationStrategy.NEGATE_ALL:
            indices = list(range(len(self._path_constraints)))
        else:
            indices = list(range(len(self._path_constraints)))

        for i in indices:
            prefix = self._path_constraints[:i]
            negated = self._path_constraints[i].negate()
            trial = prefix + [negated]

            model = self.solver.get_model(trial)
            if model is not None:
                new_input = self._model_to_bytes(model)
                if new_input and new_input not in self._tested_inputs:
                    self._input_queue.append(new_input)

        if strategy == InputMutationStrategy.COVERAGE_GUIDED:
            self._coverage_guided_mutate()

    def _coverage_guided_mutate(self) -> None:
        """Produce random bit-flip mutations biased toward new coverage."""
        import random
        for si in self._inputs:
            base = self.emulator.memory.read(si.address, si.size)
            for _ in range(min(8, self.config.max_iterations // 10 + 1)):
                mutated = bytearray(base)
                num_flips = random.randint(1, max(1, si.size // 4))
                for _ in range(num_flips):
                    idx = random.randrange(si.size)
                    mutated[idx] ^= (1 << random.randrange(8))
                candidate = bytes(mutated)
                if candidate not in self._tested_inputs:
                    self._input_queue.append(candidate)

    def _model_to_bytes(self, model: dict[str, int]) -> bytes | None:
        if not model and not self._inputs:
            return None
        result = bytearray()
        for si in self._inputs:
            for i in range(si.size):
                sym_name = f"{si.name}_{i}"
                result.append(model.get(sym_name, 0) & 0xFF)
        return bytes(result) if result else None

    def _input_to_mapping(self, data: bytes) -> dict[str, int]:
        mapping: dict[str, int] = {}
        offset = 0
        for si in self._inputs:
            for i in range(si.size):
                if offset + i < len(data):
                    mapping[f"{si.name}_{i}"] = data[offset + i]
            offset += si.size
        return mapping

    def _hash_path(self) -> str:
        h = hashlib.md5()
        for br in self._branch_log:
            h.update(struct.pack("<Q?", br.pc, br.taken))
        return h.hexdigest()


class _TargetReached(Exception):
    """Internal signal when a target address is hit."""
    def __init__(self, address: int, instruction_count: int = 0):
        self.address = address
        self.instruction_count = instruction_count
        super().__init__(f"Target reached: {address:#x}")


# ---------------------------------------------------------------------------
# Z3 solver bridge (optional)
# ---------------------------------------------------------------------------

class Z3Solver(Solver):
    """
    Bridge to Z3 SMT solver for more powerful constraint solving.

    Falls back to SimpleSolver if z3 is not installed.
    """

    def __init__(self, timeout_ms: int = 5000):
        self._timeout_ms = timeout_ms
        self._z3 = None
        self._available = self._try_import()

    def _try_import(self) -> bool:
        try:
            import z3 as _z3
            self._z3 = _z3
            return True
        except ImportError:
            logger.debug("z3-solver not installed; Z3Solver will use SimpleSolver fallback")
            return False

    def _sym_to_z3(self, sv: SymbolicValue, ctx: dict[str, Any]) -> Any:
        z3 = self._z3
        if sv.is_concrete:
            return z3.BitVecVal(sv.concrete_value, sv.size)
        if not sv.operation:
            if sv.name not in ctx:
                ctx[sv.name] = z3.BitVec(sv.name, sv.size)
            return ctx[sv.name]
        if sv.operation in (UnaryOp.NOT, UnaryOp.NEG):
            child = self._sym_to_z3(sv.operands[0], ctx)
            if sv.operation == UnaryOp.NOT:
                return ~child
            return -child
        if len(sv.operands) >= 2:
            left = self._sym_to_z3(sv.operands[0], ctx)
            right = self._sym_to_z3(sv.operands[1], ctx)
            _map = {
                BinaryOp.ADD: lambda l, r: l + r,
                BinaryOp.SUB: lambda l, r: l - r,
                BinaryOp.MUL: lambda l, r: l * r,
                BinaryOp.AND: lambda l, r: l & r,
                BinaryOp.OR: lambda l, r: l | r,
                BinaryOp.XOR: lambda l, r: l ^ r,
                BinaryOp.SHL: lambda l, r: l << r,
                BinaryOp.SHR: lambda l, r: z3.LShR(l, r),
                BinaryOp.EQ: lambda l, r: z3.If(l == r, z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.NE: lambda l, r: z3.If(l != r, z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.LT: lambda l, r: z3.If(l < r, z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.LE: lambda l, r: z3.If(l <= r, z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.GT: lambda l, r: z3.If(l > r, z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.GE: lambda l, r: z3.If(l >= r, z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.ULT: lambda l, r: z3.If(z3.ULT(l, r), z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.ULE: lambda l, r: z3.If(z3.ULE(l, r), z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.UGT: lambda l, r: z3.If(z3.UGT(l, r), z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
                BinaryOp.UGE: lambda l, r: z3.If(z3.UGE(l, r), z3.BitVecVal(1, 1), z3.BitVecVal(0, 1)),
            }
            fn = _map.get(sv.operation)
            if fn:
                return fn(left, right)
        return z3.BitVecVal(0, sv.size)

    def _constraint_to_z3(self, c: Constraint, ctx: dict[str, Any]) -> Any:
        z3 = self._z3
        expr = self._sym_to_z3(c.expression, ctx)
        if c.is_true:
            return expr != z3.BitVecVal(0, expr.size())
        return expr == z3.BitVecVal(0, expr.size())

    def check_sat(self, constraints: list[Constraint]) -> bool:
        if not self._available:
            return SimpleSolver().check_sat(constraints)
        z3 = self._z3
        s = z3.Solver()
        s.set("timeout", self._timeout_ms)
        ctx: dict[str, Any] = {}
        for c in constraints:
            s.add(self._constraint_to_z3(c, ctx))
        return s.check() == z3.sat

    def get_model(self, constraints: list[Constraint]) -> dict[str, int] | None:
        if not self._available:
            return SimpleSolver().get_model(constraints)
        z3 = self._z3
        s = z3.Solver()
        s.set("timeout", self._timeout_ms)
        ctx: dict[str, Any] = {}
        for c in constraints:
            s.add(self._constraint_to_z3(c, ctx))
        if s.check() != z3.sat:
            return None
        m = s.model()
        result: dict[str, int] = {}
        for name, var in ctx.items():
            val = m.evaluate(var, model_completion=True)
            result[name] = val.as_long() if hasattr(val, "as_long") else 0
        return result

    def get_all_models(
        self, constraints: list[Constraint], max_solutions: int = 10,
    ) -> list[dict[str, int]]:
        if not self._available:
            return SimpleSolver().get_all_models(constraints, max_solutions)
        z3 = self._z3
        s = z3.Solver()
        s.set("timeout", self._timeout_ms)
        ctx: dict[str, Any] = {}
        for c in constraints:
            s.add(self._constraint_to_z3(c, ctx))
        results: list[dict[str, int]] = []
        while len(results) < max_solutions and s.check() == z3.sat:
            m = s.model()
            sol: dict[str, int] = {}
            block = []
            for name, var in ctx.items():
                val = m.evaluate(var, model_completion=True)
                v = val.as_long() if hasattr(val, "as_long") else 0
                sol[name] = v
                block.append(var != val)
            results.append(sol)
            s.add(z3.Or(*block))
        return results


# ---------------------------------------------------------------------------
# Convenience constructors
# ---------------------------------------------------------------------------

def create_concolic_engine(
    emulator: Emulator,
    config: ConcolicConfig | None = None,
    use_z3: bool = False,
) -> ConcolicEngine:
    solver: Solver | None = None
    if use_z3:
        solver = Z3Solver()
    return ConcolicEngine(emulator, config, solver)


__all__ = [
    "ConcolicEngine",
    "ConcolicConfig",
    "ConcolicRunResult",
    "ConcolicSolution",
    "SymbolicInput",
    "BranchRecord",
    "TaintTracker",
    "TaintTag",
    "InstructionLifter",
    "InputMutationStrategy",
    "Z3Solver",
    "create_concolic_engine",
]
