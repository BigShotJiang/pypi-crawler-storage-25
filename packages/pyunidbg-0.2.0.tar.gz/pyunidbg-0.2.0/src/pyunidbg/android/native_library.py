"""
High-level Android native library wrapper.

Provides a simplified interface for:
- Loading and calling native libraries
- Automatic JNI setup and handling
- Built-in handlers for common Java classes
- Signature bypass and anti-debugging bypasses

Example usage:
    from pyunidbg.android import NativeLibrary
    
    lib = NativeLibrary("libexample.so", arch="arm64")
    lib.bypass_signature_check()
    result = lib.call_jni("getSign", "arg1", "arg2", context=True)
    print(result)
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class NativeLibrary:
    """
    High-level wrapper for Android native library emulation.
    
    Simplifies the common workflow of:
    1. Creating an emulator
    2. Setting up JNI environment
    3. Loading the library
    4. Calling native functions
    
    Example:
        lib = NativeLibrary("libsign.so")
        result = lib.call(0x1234, "arg1", "arg2")
    """

    def __init__(
        self,
        library_path: str | Path,
        arch: str = "arm64",
        api_level: int = 23,
        apk_path: str | Path | None = None,
        package_name: str = "com.example.app",
        auto_bypass: bool = True,
        verbose: bool = False,
    ):
        """
        Initialize native library emulator.
        
        Args:
            library_path: Path to the .so file
            arch: Architecture ("arm" or "arm64")
            api_level: Android API level (default 23)
            apk_path: Optional path to APK for certificate extraction
            package_name: Package name for virtual filesystem
            auto_bypass: Automatically bypass signature checks
            verbose: Enable debug logging
        """
        from pyunidbg.android import AndroidEmulator

        self.library_path = Path(library_path)
        self.apk_path = Path(apk_path) if apk_path else None
        self.package_name = package_name

        # Configure logging
        if verbose:
            logging.basicConfig(level=logging.DEBUG)

        # Create emulator
        self.emulator = AndroidEmulator(arch=arch, api_level=api_level)
        self.jni = self.emulator._jni_env

        # Setup default handlers
        self._setup_builtin_handlers()

        # Bypass signature checks if requested
        if auto_bypass:
            self.bypass_signature_check()

        # Extract APK certificate if provided
        self._rsa_data = b""
        if self.apk_path and self.apk_path.exists():
            self._extract_apk_cert()

        # Load library
        self.module = self.emulator.load_library(
            self.library_path,
            call_jni_onload=True
        )

        logger.info(f"Loaded {self.module.name} at 0x{self.module.base:x}")

    def _setup_builtin_handlers(self) -> None:
        """Register handlers for common Java classes."""
        # These are automatically handled by the JNI environment
        # No need to register them manually in user code
        pass  # Built into JNIEnv now

    def _extract_apk_cert(self) -> None:
        """Extract RSA certificate from APK."""
        import zipfile
        try:
            with zipfile.ZipFile(self.apk_path, 'r') as zf:
                for name in zf.namelist():
                    if name.startswith("META-INF/") and name.endswith(".RSA"):
                        self._rsa_data = zf.read(name)
                        cert_path = f"/data/app/{self.package_name}/base.apk!/META-INF/{name.split('/')[-1]}"
                        self.emulator.add_virtual_file(cert_path, self._rsa_data)
                        logger.debug(f"Loaded certificate: {name}")
                        break
        except Exception as e:
            logger.warning(f"Could not extract APK certificate: {e}")

    def bypass_signature_check(self) -> None:
        """
        Bypass APK signature verification.
        
        Patches strncmp to always return 0 (match), which bypasses
        the signature verification done in JNI_OnLoad.
        """
        def patched_strncmp(*args) -> int:
            return 0

        if 'strncmp' in self.emulator.loader._symbol_hooks:
            stub_addr, _ = self.emulator.loader._symbol_hooks['strncmp']
            self.emulator.loader._symbol_hooks['strncmp'] = (stub_addr, patched_strncmp)

        logger.debug("Signature check bypassed (strncmp patched)")

    def call(
        self,
        offset_or_name: int | str,
        *args: Any,
        context: bool = False,
        jni: bool = True,
        raw: bool = False,
    ) -> Any:
        """
        Call a native function.
        
        Args:
            offset_or_name: Function offset (int) or symbol name (str)
            *args: Function arguments (strings are auto-converted to jstring)
            context: If True, adds Android Context as third arg (after JNIEnv*, jobject)
            jni: If True (default), prepends JNIEnv* and jobject as first args
            raw: If True, returns raw integer result without string conversion
            
        Returns:
            String result (or raw int if raw=True)
        """
        # Resolve address
        if isinstance(offset_or_name, str):
            addr = self.emulator.find_function(offset_or_name)
            if addr is None:
                raise ValueError(f"Function not found: {offset_or_name}")
            # Auto-detect if it's a JNI function
            is_jni_func = offset_or_name.startswith("Java_")
        else:
            addr = self.module.base + offset_or_name
            is_jni_func = jni

        # Build argument list
        jni_args = []

        # Add JNI prefix (JNIEnv*, jobject) for JNI functions
        if jni and is_jni_func:
            jni_args.append(self.jni.get_pointer())
            jni_args.append(0)  # jobject thiz (NULL for static, handled by JNI)

            # Add Context if requested
            if context:
                ctx_class = self.jni.FindClass("android/content/Context")
                jni_args.append(self.jni.AllocObject(ctx_class))
        elif context:
            # Legacy behavior: context=True means add JNIEnv*, jclass, Context
            jni_args.append(self.jni.get_pointer())
            jni_args.append(0)  # jclass (NULL)
            ctx_class = self.jni.FindClass("android/content/Context")
            jni_args.append(self.jni.AllocObject(ctx_class))

        # Convert arguments
        for arg in args:
            if isinstance(arg, str):
                jni_args.append(self.jni.NewStringUTF(arg))
            elif isinstance(arg, bool):
                jni_args.append(1 if arg else 0)
            elif isinstance(arg, bytes):
                jni_args.append(self.jni.NewByteArray(arg))
            elif isinstance(arg, dict):
                # Convert dict to JSON string
                jni_args.append(self.jni.NewStringUTF(json.dumps(arg, ensure_ascii=False)))
            else:
                jni_args.append(arg)

        # Call function
        result = self.emulator.call(addr, jni_args)

        # Convert result
        if raw:
            return result

        if result:
            string_val = self.jni.get_string_value(result)
            if string_val:
                return string_val

        return result

    def call_jni_method(
        self,
        method_name: str,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Call a JNI method by name.
        
        Args:
            method_name: Full JNI method name (e.g., "Java_com_example_Native_sign")
            *args: Method arguments
            **kwargs: Named arguments (converted to jstring)
            
        Returns:
            Method result
        """
        return self.emulator.call_jni(method_name, args=list(args), **kwargs)

    def register_handler(
        self,
        class_name: str,
        method_name: str,
        signature: str,
        handler: Callable,
        static: bool = False,
    ) -> None:
        """
        Register a custom JNI method handler.
        
        Args:
            class_name: Java class name (e.g., "com/example/Utils")
            method_name: Method name
            signature: JNI signature
            handler: Handler function
            static: True for static method
        """
        if static:
            self.jni.register_static_method_handler(
                class_name, method_name, signature, handler
            )
        else:
            self.jni.register_method_handler(
                class_name, method_name, signature, handler
            )

    def add_breakpoint(
        self,
        offset: int,
        callback: Callable[[int], bool] | None = None,
    ) -> None:
        """
        Add a breakpoint at offset from library base.
        
        Args:
            offset: Offset from library base
            callback: Optional callback(address) -> continue
        """
        addr = self.module.base + offset

        if callback is None:
            def default_callback(address: int) -> bool:
                print(f"Breakpoint at 0x{address:x} (base+0x{offset:x})")
                for i in range(4):
                    val = self.emulator.cpu.get_reg(f"x{i}" if self.emulator.is_64bit else f"r{i}")
                    print(f"  {'x' if self.emulator.is_64bit else 'r'}{i} = 0x{val:x}")
                return True
            callback = default_callback

        self.emulator.hook.add_breakpoint(addr, callback)

    def trace(self, start_offset: int = 0, end_offset: int | None = None) -> None:
        """
        Enable instruction tracing.
        
        Args:
            start_offset: Start offset from base
            end_offset: End offset (default: module size)
        """
        start = self.module.base + start_offset
        end = self.module.base + (end_offset or self.module.size)
        self.emulator.hook.add_trace_hook(start=start, end=end)

    @property
    def base(self) -> int:
        """Get library base address."""
        return self.module.base

    @property
    def size(self) -> int:
        """Get library size."""
        return self.module.size

    def __repr__(self) -> str:
        return f"NativeLibrary({self.module.name}, base=0x{self.module.base:x})"
