"""
Full JNIEnv implementation with all ~230 JNI functions.

This module provides the complete JNINativeInterface function table
that native code uses to interact with the Java runtime.
"""

from __future__ import annotations

import logging
import struct
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from pyunidbg.core.constants import Architecture, MemoryLayout, MemoryProtection

from .constants import (
    JNI_ABORT,
    JNI_COMMIT,
    JNI_ERR,
    JNI_FALSE,
    JNI_OK,
    JNI_TRUE,
    JNI_VERSION_1_6,
    JNIFunctionIndex,
    JNIGlobalRefType,
    JNIInvalidRefType,
    JNILocalRefType,
    JNIWeakGlobalRefType,
)
from .types import (
    JArray,
    JBooleanArray,
    JByteArray,
    JCharArray,
    JClass,
    JDirectBuffer,
    JDoubleArray,
    JFieldID,
    JFloatArray,
    JIntArray,
    JLongArray,
    JMethodID,
    JObject,
    JObjectArray,
    JShortArray,
    JString,
    JThrowable,
    JWeak,
)

if TYPE_CHECKING:
    from pyunidbg.android.emulator import AndroidEmulator

logger = logging.getLogger(__name__)


class JNIEnv:
    """
    Complete JNIEnv implementation with all ~230 JNI functions.
    
    Provides the JNINativeInterface function table that native code uses
    to interact with the Java runtime. Supports:
    
    - Object creation and manipulation
    - Method invocation (virtual, nonvirtual, static)
    - Field access (instance and static)
    - String operations (Unicode and UTF-8)
    - Array operations (primitive and object arrays)
    - Exception handling
    - Reference management (local, global, weak)
    - Monitor operations
    - Native method registration
    - Direct buffers
    - Reflection
    """

    def __init__(self, emulator: AndroidEmulator):
        self._emulator = emulator
        self._ptr_size = emulator.pointer_size

        # Object management
        self._next_handle = 0x1000
        self._objects: dict[int, JObject] = {}
        self._strings: dict[int, str] = {}  # handle -> string value
        self._classes: dict[str, JClass] = {}  # class_name -> JClass
        self._arrays: dict[int, JArray] = {}  # handle -> array

        # Reference management
        self._global_refs: set[int] = set()
        self._weak_refs: dict[int, JWeak] = {}  # weak handle -> JWeak
        self._local_frames: list[set[int]] = [set()]  # Stack of local frames

        # Method/Field IDs
        self._next_method_id = 0x2000
        self._next_field_id = 0x3000
        self._methods: dict[int, JMethodID] = {}
        self._fields: dict[int, JFieldID] = {}

        # Exception state
        self._pending_exception: int | None = None

        # Registered native methods: (class, name, sig) -> fn_ptr
        self._native_methods: dict[tuple[str, str, str], int] = {}

        # Direct buffers
        self._direct_buffers: dict[int, JDirectBuffer] = {}

        # Array element pointers (for Get*ArrayElements)
        self._array_elements: dict[int, tuple[int, int]] = {}  # ptr -> (array_handle, copy_flag)

        # String critical pointers
        self._string_critical: dict[int, int] = {}  # ptr -> string_handle

        # Method call handlers (for intercepting Java method calls)
        self._method_handlers: dict[int, Callable] = {}

        # Setup function table in memory
        self._env_ptr = self._setup_function_table()

        # Initialize built-in classes
        self._init_builtin_classes()

    def _alloc_handle(self) -> int:
        """Allocate a new object handle."""
        handle = self._next_handle
        self._next_handle += 1
        return handle

    def _alloc_method_id(self) -> int:
        """Allocate a new method ID."""
        mid = self._next_method_id
        self._next_method_id += 1
        return mid

    def _alloc_field_id(self) -> int:
        """Allocate a new field ID."""
        fid = self._next_field_id
        self._next_field_id += 1
        return fid

    def _setup_function_table(self) -> int:
        """Create JNIEnv function table in memory with hooked trampolines."""
        mem = self._emulator.memory
        ptr_size = self._ptr_size

        # JNIEnv* points to JNINativeInterface*
        num_functions = JNIFunctionIndex.NUM_FUNCTIONS
        table_size = num_functions * ptr_size

        # Allocate function table
        func_table = mem.allocate(table_size, name="[JNINativeInterface]")

        # Allocate JNIEnv pointer
        env_ptr = mem.allocate(ptr_size, name="[JNIEnv]")
        mem.write_ptr(env_ptr, func_table)

        # Setup trampolines for each function (with executable permission)
        trampoline_base = MemoryLayout.HOOK_BASE + 0x10000
        trampoline_size = num_functions * 16
        mem.map(trampoline_base, (trampoline_size + 0xFFF) & ~0xFFF,
               protection=MemoryProtection.READ_WRITE_EXEC,
               name="[jni_trampolines]")

        self._trampoline_base = trampoline_base

        for i in range(num_functions):
            trampoline_addr = trampoline_base + (i * 16)
            mem.write_ptr(func_table + (i * ptr_size), trampoline_addr)

            # Write RET instruction
            if self._emulator.arch == Architecture.ARM64:
                mem.write(trampoline_addr, b"\xC0\x03\x5F\xD6")  # RET
            else:
                mem.write(trampoline_addr, b"\x1E\xFF\x2F\xE1")  # BX LR

        # Add hook for JNI function dispatch
        self._add_trampoline_hook()

        return env_ptr

    def _add_trampoline_hook(self) -> None:
        """Add a hook to intercept JNI function calls."""
        from unicorn import UC_HOOK_CODE

        trampoline_base = self._trampoline_base
        trampoline_end = trampoline_base + 0x10000

        def jni_hook(uc, address, size, user_data):
            # Calculate function index from address
            func_idx = (address - trampoline_base) // 16

            # Get arguments (env is first arg)
            if self._emulator.is_64bit:
                args = [self._emulator.cpu.get_arg(i) for i in range(8)]
            else:
                args = [self._emulator.cpu.get_arg(i) for i in range(4)]

            # Dispatch to the appropriate JNI function
            result = self._dispatch_jni_function(func_idx, args)
            if result is None:
                result = 0

            # Set return value
            self._emulator.cpu.set_return_value(result)

        self._emulator._uc.hook_add(UC_HOOK_CODE, jni_hook,
                                    begin=trampoline_base, end=trampoline_end)

    def _parse_va_list(self, va_list_ptr: int, signature: str) -> list:
        """
        Parse va_list arguments using architecture-specific ABI handler.
        
        Delegates to the arch.abi module which handles all architectures.
        """
        from pyunidbg.arch.abi import parse_va_list
        return parse_va_list(self._emulator, va_list_ptr, signature)

    def _get_jni_function_name(self, func_idx: int) -> str:
        """Get the name of a JNI function by its index."""
        for name in dir(JNIFunctionIndex):
            if not name.startswith('_'):
                val = getattr(JNIFunctionIndex, name)
                if isinstance(val, int) and val == func_idx:
                    return name
        return f"UNKNOWN_{func_idx}"

    def _dispatch_jni_function(self, func_idx: int, args: list) -> int:
        """Dispatch a JNI function call based on its index."""
        # args[0] is JNIEnv*, remaining are function arguments
        env = args[0]

        # Helper to read string from memory
        def read_str(ptr):
            if ptr == 0:
                return None
            return self._emulator.read_string(ptr)

        # Log the function being called
        func_name = self._get_jni_function_name(func_idx)
        logger.debug(f"JNI call: {func_name} (index={func_idx})")

        try:
            if func_idx == JNIFunctionIndex.GET_VERSION:
                return self.GetVersion()
            elif func_idx == JNIFunctionIndex.FIND_CLASS:
                name = read_str(args[1])
                return self.FindClass(name) if name else 0
            elif func_idx == JNIFunctionIndex.GET_SUPERCLASS:
                return self.GetSuperclass(args[1])
            elif func_idx == JNIFunctionIndex.IS_ASSIGNABLE_FROM:
                return 1 if self.IsAssignableFrom(args[1], args[2]) else 0
            elif func_idx == JNIFunctionIndex.EXCEPTION_OCCURRED:
                return self.ExceptionOccurred()
            elif func_idx == JNIFunctionIndex.EXCEPTION_DESCRIBE:
                self.ExceptionDescribe()
                return 0
            elif func_idx == JNIFunctionIndex.EXCEPTION_CLEAR:
                self.ExceptionClear()
                return 0
            elif func_idx == JNIFunctionIndex.NEW_GLOBAL_REF:
                return self.NewGlobalRef(args[1])
            elif func_idx == JNIFunctionIndex.DELETE_GLOBAL_REF:
                self.DeleteGlobalRef(args[1])
                return 0
            elif func_idx == JNIFunctionIndex.DELETE_LOCAL_REF:
                self.DeleteLocalRef(args[1])
                return 0
            elif func_idx == JNIFunctionIndex.IS_SAME_OBJECT:
                return 1 if self.IsSameObject(args[1], args[2]) else 0
            elif func_idx == JNIFunctionIndex.GET_OBJECT_CLASS:
                return self.GetObjectClass(args[1])
            elif func_idx == JNIFunctionIndex.IS_INSTANCE_OF:
                return 1 if self.IsInstanceOf(args[1], args[2]) else 0
            elif func_idx == JNIFunctionIndex.GET_METHOD_ID:
                name = read_str(args[2])
                sig = read_str(args[3])
                return self.GetMethodID(args[1], name, sig)
            elif func_idx == JNIFunctionIndex.GET_STATIC_METHOD_ID:
                name = read_str(args[2])
                sig = read_str(args[3])
                return self.GetStaticMethodID(args[1], name, sig)
            elif func_idx == JNIFunctionIndex.GET_FIELD_ID:
                name = read_str(args[2])
                sig = read_str(args[3])
                return self.GetFieldID(args[1], name, sig)
            elif func_idx == JNIFunctionIndex.GET_STATIC_FIELD_ID:
                name = read_str(args[2])
                sig = read_str(args[3])
                return self.GetStaticFieldID(args[1], name, sig)
            elif func_idx == JNIFunctionIndex.NEW_STRING_UTF:
                s = read_str(args[1])
                return self.NewStringUTF(s) if s else 0
            elif func_idx == JNIFunctionIndex.GET_STRING_UTF_LENGTH:
                return self.GetStringUTFLength(args[1])
            elif func_idx == JNIFunctionIndex.GET_STRING_UTF_CHARS:
                return self.GetStringUTFChars(args[1], args[2])
            elif func_idx == JNIFunctionIndex.RELEASE_STRING_UTF_CHARS:
                self.ReleaseStringUTFChars(args[1], args[2])
                return 0
            elif func_idx == JNIFunctionIndex.GET_ARRAY_LENGTH:
                return self.GetArrayLength(args[1])
            elif func_idx == JNIFunctionIndex.REGISTER_NATIVES:
                nMethods = args[3]
                return self.RegisterNatives(args[1], args[2], nMethods)
            elif func_idx == JNIFunctionIndex.UNREGISTER_NATIVES:
                return self.UnregisterNatives(args[1])
            elif func_idx == JNIFunctionIndex.GET_JAVA_VM:
                return self.GetJavaVM(args[1])
            elif func_idx == JNIFunctionIndex.NEW_OBJECT:
                return self.NewObject(args[1], args[2], *args[3:])
            elif func_idx == JNIFunctionIndex.NEW_OBJECT_V:
                # Parse va_list for constructor arguments
                clazz = args[1]
                methodID = args[2]
                va_list_ptr = args[3]
                method = self._methods.get(methodID)
                if method:
                    va_args = self._parse_va_list(va_list_ptr, method.signature)
                    if va_args:
                        return self.NewObject(clazz, methodID, *va_args)
                return self.NewObject(clazz, methodID)
            elif func_idx == JNIFunctionIndex.NEW_OBJECT_A:
                return self.NewObject(args[1], args[2], *args[3:])
            elif func_idx in (JNIFunctionIndex.CALL_STATIC_OBJECT_METHOD,
                             JNIFunctionIndex.CALL_STATIC_OBJECT_METHOD_V,
                             JNIFunctionIndex.CALL_STATIC_OBJECT_METHOD_A):
                return self.CallStaticObjectMethod(args[1], args[2], *args[3:])
            elif func_idx in (JNIFunctionIndex.CALL_STATIC_INT_METHOD,
                             JNIFunctionIndex.CALL_STATIC_INT_METHOD_V,
                             JNIFunctionIndex.CALL_STATIC_INT_METHOD_A):
                return self.CallStaticIntMethod(args[1], args[2], *args[3:])
            elif func_idx in (JNIFunctionIndex.CALL_STATIC_VOID_METHOD,
                             JNIFunctionIndex.CALL_STATIC_VOID_METHOD_V,
                             JNIFunctionIndex.CALL_STATIC_VOID_METHOD_A):
                self.CallStaticVoidMethod(args[1], args[2], *args[3:])
                return 0
            elif func_idx == JNIFunctionIndex.CALL_OBJECT_METHOD:
                return self.CallObjectMethod(args[1], args[2], *args[3:])
            elif func_idx == JNIFunctionIndex.CALL_OBJECT_METHOD_V:
                # For _V variants, args[3] is va_list pointer
                # Parse va_list to get actual arguments
                obj = args[1]
                methodID = args[2]
                va_list_ptr = args[3]
                method = self._methods.get(methodID)
                if method:
                    va_args = self._parse_va_list(va_list_ptr, method.signature)
                    if va_args:
                        return self.CallObjectMethod(obj, methodID, *va_args)
                return self.CallObjectMethod(obj, methodID)
            elif func_idx == JNIFunctionIndex.CALL_OBJECT_METHOD_A:
                return self.CallObjectMethod(args[1], args[2], *args[3:])
            elif func_idx in (JNIFunctionIndex.CALL_INT_METHOD,
                             JNIFunctionIndex.CALL_INT_METHOD_V,
                             JNIFunctionIndex.CALL_INT_METHOD_A):
                return self.CallIntMethod(args[1], args[2], *args[3:])
            elif func_idx in (JNIFunctionIndex.CALL_VOID_METHOD,
                             JNIFunctionIndex.CALL_VOID_METHOD_V,
                             JNIFunctionIndex.CALL_VOID_METHOD_A):
                self.CallVoidMethod(args[1], args[2], *args[3:])
                return 0
            elif func_idx == JNIFunctionIndex.NEW_BYTE_ARRAY:
                return self.NewByteArray(args[1])
            elif func_idx == JNIFunctionIndex.SET_BYTE_ARRAY_REGION:
                self.SetByteArrayRegion(args[1], args[2], args[3], args[4])
                return 0
            elif func_idx == JNIFunctionIndex.GET_BYTE_ARRAY_ELEMENTS:
                return self.GetByteArrayElements(args[1], args[2])
            elif func_idx == JNIFunctionIndex.RELEASE_BYTE_ARRAY_ELEMENTS:
                self.ReleaseByteArrayElements(args[1], args[2], args[3])
                return 0
            elif func_idx == JNIFunctionIndex.GET_STATIC_OBJECT_FIELD:
                return self.GetStaticObjectField(args[1], args[2])
            elif func_idx == JNIFunctionIndex.GET_STATIC_INT_FIELD:
                return self.GetStaticIntField(args[1], args[2])
            elif func_idx == JNIFunctionIndex.SET_STATIC_INT_FIELD:
                self.SetStaticIntField(args[1], args[2], args[3])
                return 0
            elif func_idx == JNIFunctionIndex.GET_OBJECT_FIELD:
                return self.GetObjectField(args[1], args[2])
            elif func_idx == JNIFunctionIndex.GET_INT_FIELD:
                return self.GetIntField(args[1], args[2])
            elif func_idx == JNIFunctionIndex.SET_OBJECT_FIELD:
                self.SetObjectField(args[1], args[2], args[3])
                return 0
            elif func_idx == JNIFunctionIndex.SET_INT_FIELD:
                self.SetIntField(args[1], args[2], args[3])
                return 0
            elif func_idx == JNIFunctionIndex.NEW_OBJECT_ARRAY:
                element_class = args[2]
                initial_element = args[3] if len(args) > 3 else 0
                return self.NewObjectArray(args[1], element_class, initial_element)
            elif func_idx == JNIFunctionIndex.GET_OBJECT_ARRAY_ELEMENT:
                return self.GetObjectArrayElement(args[1], args[2])
            elif func_idx == JNIFunctionIndex.SET_OBJECT_ARRAY_ELEMENT:
                self.SetObjectArrayElement(args[1], args[2], args[3])
                return 0
            elif func_idx == JNIFunctionIndex.NEW_INT_ARRAY:
                return self.NewIntArray(args[1])
            elif func_idx == JNIFunctionIndex.GET_INT_ARRAY_ELEMENTS:
                return self.GetIntArrayElements(args[1], args[2])
            elif func_idx == JNIFunctionIndex.RELEASE_INT_ARRAY_ELEMENTS:
                self.ReleaseIntArrayElements(args[1], args[2], args[3])
                return 0
            elif func_idx == JNIFunctionIndex.GET_BYTE_ARRAY_REGION:
                self.GetByteArrayRegion(args[1], args[2], args[3], args[4])
                return 0
            elif func_idx == JNIFunctionIndex.NEW_DIRECT_BYTE_BUFFER:
                return self.NewDirectByteBuffer(args[1], args[2])
            elif func_idx == JNIFunctionIndex.GET_DIRECT_BUFFER_ADDRESS:
                return self.GetDirectBufferAddress(args[1])
            elif func_idx == JNIFunctionIndex.GET_DIRECT_BUFFER_CAPACITY:
                return self.GetDirectBufferCapacity(args[1])
            else:
                logger.warning(f"Unhandled JNI function index: {func_idx}")
                return 0
        except Exception as e:
            logger.error(f"JNI dispatch error for index {func_idx}: {e}")
            return 0

    def _init_builtin_classes(self) -> None:
        """Initialize built-in Java classes."""
        builtin_classes = [
            "java/lang/Object",
            "java/lang/Class",
            "java/lang/String",
            "java/lang/Throwable",
            "java/lang/Exception",
            "java/lang/RuntimeException",
            "java/lang/Error",
            "java/lang/Boolean",
            "java/lang/Byte",
            "java/lang/Character",
            "java/lang/Short",
            "java/lang/Integer",
            "java/lang/Long",
            "java/lang/Float",
            "java/lang/Double",
            "java/lang/Void",
            "java/lang/System",
            "java/lang/Thread",
            "java/lang/ClassLoader",
            "java/lang/reflect/Method",
            "java/lang/reflect/Field",
            "java/lang/reflect/Constructor",
            "java/nio/ByteBuffer",
            "java/nio/DirectByteBuffer",
        ]
        for name in builtin_classes:
            self._get_or_create_class(name)

    def _get_or_create_class(self, name: str) -> JClass:
        """Get or create a JClass for the given name."""
        if name in self._classes:
            return self._classes[name]

        handle = self._alloc_handle()
        jclass = JClass(handle=handle, class_name=name)
        self._objects[handle] = jclass
        self._classes[name] = jclass
        return jclass

    def get_pointer(self) -> int:
        """Get the JNIEnv* pointer."""
        return self._env_ptr

    # ==================== Version ====================

    def GetVersion(self) -> int:
        """Returns the version of the native method interface."""
        return JNI_VERSION_1_6

    # ==================== Class Operations ====================

    def DefineClass(self, name: str, loader: int, buf: int, bufLen: int) -> int:
        """Loads a class from a buffer of raw class data."""
        logger.debug(f"DefineClass({name}, loader={loader:#x})")
        return self.FindClass(name)

    def FindClass(self, name: str) -> int:
        """Finds a class by name."""
        jclass = self._get_or_create_class(name)
        self._add_local_ref(jclass.handle)
        logger.debug(f"FindClass({name}) -> {jclass.handle:#x}")
        return jclass.handle

    def GetSuperclass(self, clazz: int) -> int:
        """Returns the superclass of a class."""
        jclass = self._objects.get(clazz)
        if isinstance(jclass, JClass):
            if jclass.superclass:
                return self.FindClass(jclass.superclass)
            if jclass.class_name != "java/lang/Object":
                return self.FindClass("java/lang/Object")
        return 0

    def IsAssignableFrom(self, clazz1: int, clazz2: int) -> bool:
        """Determines whether clazz1 can be cast to clazz2."""
        jclass1 = self._objects.get(clazz1)
        jclass2 = self._objects.get(clazz2)
        if isinstance(jclass1, JClass) and isinstance(jclass2, JClass):
            # Simplified check
            if jclass1.class_name == jclass2.class_name:
                return True
            if jclass2.class_name == "java/lang/Object":
                return True
        return False

    # ==================== Exception Operations ====================

    def Throw(self, throwable: int) -> int:
        """Causes a Throwable to be thrown."""
        self._pending_exception = throwable
        logger.debug(f"Throw({throwable:#x})")
        return JNI_OK

    def ThrowNew(self, clazz: int, message: str) -> int:
        """Constructs and throws a new exception."""
        jclass = self._objects.get(clazz)
        class_name = jclass.class_name if isinstance(jclass, JClass) else "java/lang/Exception"

        handle = self._alloc_handle()
        exc = JThrowable(handle=handle, class_name=class_name, message=message)
        self._objects[handle] = exc
        self._pending_exception = handle

        logger.debug(f"ThrowNew({class_name}, {message!r})")
        return JNI_OK

    def ExceptionOccurred(self) -> int:
        """Returns the exception being thrown, or NULL."""
        return self._pending_exception or 0

    def ExceptionDescribe(self) -> None:
        """Prints exception and stack trace to stderr."""
        if self._pending_exception:
            exc = self._objects.get(self._pending_exception)
            if isinstance(exc, JThrowable):
                logger.error(f"Exception: {exc.class_name}: {exc.message}")

    def ExceptionClear(self) -> None:
        """Clears any pending exception."""
        self._pending_exception = None

    def FatalError(self, msg: str) -> None:
        """Raises a fatal error."""
        logger.critical(f"JNI FatalError: {msg}")
        raise RuntimeError(f"JNI FatalError: {msg}")

    def ExceptionCheck(self) -> bool:
        """Checks if an exception is pending."""
        return self._pending_exception is not None

    # ==================== Reference Operations ====================

    def _add_local_ref(self, handle: int) -> None:
        """Add a local reference."""
        if self._local_frames:
            self._local_frames[-1].add(handle)

    def PushLocalFrame(self, capacity: int) -> int:
        """Creates a new local reference frame."""
        self._local_frames.append(set())
        return JNI_OK

    def PopLocalFrame(self, result: int) -> int:
        """Pops the current local reference frame."""
        if len(self._local_frames) > 1:
            self._local_frames.pop()
        if result and self._local_frames:
            self._local_frames[-1].add(result)
        return result

    def NewGlobalRef(self, obj: int) -> int:
        """Creates a new global reference."""
        if obj in self._objects:
            self._global_refs.add(obj)
            logger.debug(f"NewGlobalRef({obj:#x})")
        return obj

    def DeleteGlobalRef(self, ref: int) -> None:
        """Deletes a global reference."""
        self._global_refs.discard(ref)
        logger.debug(f"DeleteGlobalRef({ref:#x})")

    def DeleteLocalRef(self, ref: int) -> None:
        """Deletes a local reference."""
        if self._local_frames:
            self._local_frames[-1].discard(ref)

    def IsSameObject(self, ref1: int, ref2: int) -> bool:
        """Tests whether two references refer to the same object."""
        return ref1 == ref2

    def NewLocalRef(self, ref: int) -> int:
        """Creates a new local reference to an object."""
        if ref in self._objects:
            self._add_local_ref(ref)
        return ref

    def EnsureLocalCapacity(self, capacity: int) -> int:
        """Ensures space for local references."""
        return JNI_OK

    def NewWeakGlobalRef(self, obj: int) -> int:
        """Creates a new weak global reference."""
        handle = self._alloc_handle()
        weak = JWeak(handle=handle, target=obj)
        self._weak_refs[handle] = weak
        logger.debug(f"NewWeakGlobalRef({obj:#x}) -> {handle:#x}")
        return handle

    def DeleteWeakGlobalRef(self, ref: int) -> None:
        """Deletes a weak global reference."""
        self._weak_refs.pop(ref, None)

    def GetObjectRefType(self, obj: int) -> int:
        """Returns the type of a reference."""
        if obj in self._weak_refs:
            return JNIWeakGlobalRefType
        if obj in self._global_refs:
            return JNIGlobalRefType
        for frame in self._local_frames:
            if obj in frame:
                return JNILocalRefType
        return JNIInvalidRefType

    # ==================== Object Operations ====================

    def AllocObject(self, clazz: int) -> int:
        """Allocates an object without calling constructors."""
        jclass = self._objects.get(clazz)
        if not isinstance(jclass, JClass):
            return 0

        handle = self._alloc_handle()
        obj = JObject(handle=handle, class_name=jclass.class_name)
        self._objects[handle] = obj
        self._add_local_ref(handle)

        logger.debug(f"AllocObject({jclass.class_name}) -> {handle:#x}")
        return handle

    def NewObject(self, clazz: int, methodID: int, *args) -> int:
        """Constructs a new object."""
        return self.NewObjectA(clazz, methodID, args)

    def NewObjectV(self, clazz: int, methodID: int, args) -> int:
        """Constructs a new object (va_list version)."""
        return self.NewObjectA(clazz, methodID, args)

    def NewObjectA(self, clazz: int, methodID: int, args) -> int:
        """Constructs a new object (array version)."""
        handle = self.AllocObject(clazz)
        if handle:
            jobj = self._objects.get(handle)
            jclass = self._classes.get(clazz)
            class_name = jclass.class_name if jclass else (jobj.class_name if jobj else "")

            # Handle built-in wrapper type constructors
            if class_name == "java/lang/Integer" and args:
                # Integer(int value) constructor
                value = args[0] if isinstance(args[0], int) else int(args[0]) if args[0] else 0
                # Handle signed int from unsigned
                if value > 0x7FFFFFFF:
                    value = value - 0x100000000
                self.set_object_value(handle, value)
                logger.debug(f"NewObject(Integer, {value}) -> {handle:#x}")
            elif class_name == "java/lang/Long" and args:
                value = args[0] if isinstance(args[0], int) else int(args[0]) if args[0] else 0
                self.set_object_value(handle, value)
            elif class_name == "java/lang/Boolean" and args:
                value = bool(args[0]) if args else False
                self.set_object_value(handle, value)
            elif class_name == "java/lang/Double" and args:
                import struct
                # Interpret as double bits
                if isinstance(args[0], int):
                    value = struct.unpack('d', struct.pack('Q', args[0]))[0]
                else:
                    value = float(args[0]) if args[0] else 0.0
                self.set_object_value(handle, value)
            elif class_name == "java/lang/Float" and args:
                import struct
                if isinstance(args[0], int):
                    value = struct.unpack('f', struct.pack('I', args[0] & 0xFFFFFFFF))[0]
                else:
                    value = float(args[0]) if args[0] else 0.0
                self.set_object_value(handle, value)
            elif class_name == "java/lang/StringBuffer":
                # StringBuffer() or StringBuffer(String)
                if args and args[0]:
                    init_str = self.get_string_value(args[0]) or ""
                    self.set_object_value(handle, {"buffer": init_str})
                else:
                    self.set_object_value(handle, {"buffer": ""})
            elif class_name == "java/lang/StringBuilder":
                if args and args[0]:
                    init_str = self.get_string_value(args[0]) or ""
                    self.set_object_value(handle, {"buffer": init_str})
                else:
                    self.set_object_value(handle, {"buffer": ""})
            elif class_name == "java/lang/String":
                # Handle String constructors
                # Get the constructor signature from method ID
                method_info = self._methods.get(methodID)
                if method_info:
                    sig = method_info.signature
                    if sig == "([BLjava/lang/String;)V" and len(args) >= 2:
                        # String(byte[] bytes, String charset)
                        byte_arr = self._arrays.get(args[0])
                        charset_str = self.get_string_value(args[1]) or "UTF-8"
                        if byte_arr and hasattr(byte_arr, '_data'):
                            encoding = charset_str.replace("UTF8", "utf-8").replace("UTF-8", "utf-8")
                            string_value = byte_arr._data.decode(encoding, errors="replace")
                            # Replace the JObject with a proper JString
                            jstr = JString(handle=handle, class_name="java/lang/String", value=string_value)
                            self._objects[handle] = jstr
                            self._strings[handle] = string_value
                            logger.debug(f"NewObject(String, bytes, {charset_str}) -> {handle:#x} = {string_value!r}")
                    elif sig == "([B)V" and args:
                        # String(byte[] bytes) - default encoding
                        byte_arr = self._arrays.get(args[0])
                        if byte_arr and hasattr(byte_arr, '_data'):
                            string_value = byte_arr._data.decode('utf-8', errors="replace")
                            jstr = JString(handle=handle, class_name="java/lang/String", value=string_value)
                            self._objects[handle] = jstr
                            self._strings[handle] = string_value
                            logger.debug(f"NewObject(String, bytes) -> {handle:#x} = {string_value!r}")
                    elif sig == "(Ljava/lang/String;)V" and args:
                        # String(String original) - copy constructor
                        original = self.get_string_value(args[0])
                        jstr = JString(handle=handle, class_name="java/lang/String", value=original)
                        self._objects[handle] = jstr
                        self._strings[handle] = original
                        logger.debug(f"NewObject(String, String) -> {handle:#x} = {original!r}")
                    elif sig == "([CII)V" and len(args) >= 3:
                        # String(char[] value, int offset, int count)
                        char_arr = self._arrays.get(args[0])
                        offset = args[1] if len(args) > 1 else 0
                        count = args[2] if len(args) > 2 else 0
                        if char_arr and hasattr(char_arr, '_data'):
                            chars = char_arr._data[offset:offset+count]
                            string_value = ''.join(chr(c) for c in chars)
                            jstr = JString(handle=handle, class_name="java/lang/String", value=string_value)
                            self._objects[handle] = jstr
                            self._strings[handle] = string_value
                            logger.debug(f"NewObject(String, char[], {offset}, {count}) -> {handle:#x} = {string_value!r}")
                    elif sig == "([BII)V" and len(args) >= 3:
                        # String(byte[] bytes, int offset, int length)
                        byte_arr = self._arrays.get(args[0])
                        offset = args[1] if len(args) > 1 else 0
                        length = args[2] if len(args) > 2 else 0
                        if byte_arr and hasattr(byte_arr, '_data'):
                            string_value = byte_arr._data[offset:offset+length].decode('utf-8', errors="replace")
                            jstr = JString(handle=handle, class_name="java/lang/String", value=string_value)
                            self._objects[handle] = jstr
                            self._strings[handle] = string_value
                            logger.debug(f"NewObject(String, bytes, {offset}, {length}) -> {handle:#x} = {string_value!r}")
                    elif sig == "([BIILjava/lang/String;)V" and len(args) >= 4:
                        # String(byte[] bytes, int offset, int length, String charset)
                        byte_arr = self._arrays.get(args[0])
                        offset = args[1] if len(args) > 1 else 0
                        length = args[2] if len(args) > 2 else 0
                        charset_str = self.get_string_value(args[3]) or "UTF-8"
                        if byte_arr and hasattr(byte_arr, '_data'):
                            encoding = charset_str.replace("UTF8", "utf-8").replace("UTF-8", "utf-8")
                            string_value = byte_arr._data[offset:offset+length].decode(encoding, errors="replace")
                            jstr = JString(handle=handle, class_name="java/lang/String", value=string_value)
                            self._objects[handle] = jstr
                            self._strings[handle] = string_value
                            logger.debug(f"NewObject(String, bytes, {offset}, {length}, {charset_str}) -> {handle:#x} = {string_value!r}")

            # Call constructor handler if registered
            if methodID in self._method_handlers:
                self._method_handlers[methodID](handle, *args)
        return handle

    def GetObjectClass(self, obj: int) -> int:
        """Returns the class of an object."""
        jobj = self._objects.get(obj)
        if jobj:
            return self.FindClass(jobj.class_name)
        return 0

    def IsInstanceOf(self, obj: int, clazz: int) -> bool:
        """Tests whether an object is an instance of a class."""
        jobj = self._objects.get(obj)
        jclass = self._objects.get(clazz)
        if jobj and isinstance(jclass, JClass):
            return jobj.class_name == jclass.class_name
        return False

    # ==================== Method Operations ====================

    def GetMethodID(self, clazz: int, name: str, sig: str) -> int:
        """Returns the method ID for an instance method."""
        jclass = self._objects.get(clazz)
        if not isinstance(jclass, JClass):
            return 0

        method_key = f"{name}{sig}"
        if method_key in jclass.methods:
            return jclass.methods[method_key]

        method_id = self._alloc_method_id()
        jclass.methods[method_key] = method_id
        self._methods[method_id] = JMethodID(
            id=method_id,
            class_name=jclass.class_name,
            name=name,
            signature=sig,
            is_static=False
        )

        logger.debug(f"GetMethodID({jclass.class_name}, {name}, {sig}) -> {method_id:#x}")
        return method_id

    def GetStaticMethodID(self, clazz: int, name: str, sig: str) -> int:
        """Returns the method ID for a static method."""
        jclass = self._objects.get(clazz)
        if not isinstance(jclass, JClass):
            return 0

        method_key = f"static_{name}{sig}"
        if method_key in jclass.static_methods:
            return jclass.static_methods[method_key]

        method_id = self._alloc_method_id()
        jclass.static_methods[method_key] = method_id
        self._methods[method_id] = JMethodID(
            id=method_id,
            class_name=jclass.class_name,
            name=name,
            signature=sig,
            is_static=True
        )

        logger.debug(f"GetStaticMethodID({jclass.class_name}, {name}, {sig}) -> {method_id:#x}")
        return method_id

    def _call_method(self, obj: int, methodID: int, args: tuple, return_type: str) -> Any:
        """Internal method call implementation."""
        method = self._methods.get(methodID)
        if not method:
            # methodID 0x0 is common for uninitialized or ignored calls
            if methodID != 0:
                logger.warning(f"CallMethod: unknown method ID {methodID:#x}")
            return 0

        # Check for registered handler
        if methodID in self._method_handlers:
            return self._method_handlers[methodID](obj, *args)

        # Check for registered native method
        key = (method.class_name, method.name, method.signature)
        if key in self._native_methods:
            fn_ptr = self._native_methods[key]
            # Would call native function here
            logger.debug(f"Call native method {method.name} at {fn_ptr:#x}")

        # Built-in mocking for common Android methods
        result = self._handle_builtin_method(obj, method, args)
        if result is not None:
            if isinstance(result, int):
                logger.debug(f"CallMethod({method.class_name}.{method.name}) -> {result:#x}")
            else:
                logger.debug(f"CallMethod({method.class_name}.{method.name}) -> {result}")
            return result

        # Return default value based on type
        logger.debug(f"CallMethod({method.class_name}.{method.name}) -> default for {return_type}")
        if return_type == 'V':
            return None
        elif return_type == 'Z':
            return JNI_FALSE
        elif return_type in 'BCSI':
            return 0
        elif return_type == 'J':
            return 0
        elif return_type == 'F':
            return 0.0
        elif return_type == 'D':
            return 0.0
        else:  # Object
            return 0

    def _handle_builtin_method(self, obj: int, method: JMethodID, args: tuple) -> int | None:
        """Handle common Android/Java method calls."""
        class_name = method.class_name
        name = method.name
        sig = method.signature

        # Activity methods
        if class_name == "android/app/Activity" or class_name.endswith("/Activity"):
            if name == "getPackageManager":
                pm_class = self._get_or_create_class("android/content/pm/PackageManager")
                pm = self.AllocObject(pm_class.handle)
                return pm
            elif name == "getPackageName":
                # Return default package name
                return self.NewStringUTF(self._package_name if hasattr(self, '_package_name') else "com.example.app")
            elif name == "getApplicationContext":
                ctx_class = self._get_or_create_class("android/content/Context")
                return self.AllocObject(ctx_class.handle)

        # Context methods
        if "Context" in class_name:
            if name == "getPackageManager":
                pm_class = self._get_or_create_class("android/content/pm/PackageManager")
                return self.AllocObject(pm_class.handle)
            elif name == "getPackageName":
                return self.NewStringUTF(self._package_name if hasattr(self, '_package_name') else "com.example.app")

        # PackageManager methods
        if class_name == "android/content/pm/PackageManager":
            if name == "getPackageInfo":
                pi_class = self._get_or_create_class("android/content/pm/PackageInfo")
                pi = self.AllocObject(pi_class.handle)
                # Create signatures array
                sig_class = self._get_or_create_class("android/content/pm/Signature")
                sig_obj = self.AllocObject(sig_class.handle)
                # Store signature data (dummy signature for now)
                self.set_object_value(sig_obj, {"signature_bytes": b"\x00" * 32})
                # Create array with the signature
                sig_array = self.NewObjectArray(1, sig_class.handle, sig_obj)
                # Store the array in PackageInfo
                self.set_object_value(pi, {"signatures": sig_array})
                return pi

        # PackageInfo field simulation is handled via GetObjectField

        # Signature methods
        if class_name == "android/content/pm/Signature":
            if name == "toByteArray":
                # Get the signature bytes from the object
                sig_data = self.get_object_value(obj)
                if sig_data and "signature_bytes" in sig_data:
                    return self.NewByteArray(sig_data["signature_bytes"])
                # Return empty byte array
                return self.NewByteArray(b"\x00" * 32)

        # String methods
        if class_name == "java/lang/String":
            if name == "getBytes":
                jstr = self._objects.get(obj)
                if isinstance(jstr, JString):
                    return self.NewByteArray(jstr.value.encode('utf-8'))
                return self.NewByteArray(b"")

        # StringBuffer methods
        if class_name == "java/lang/StringBuffer" or class_name == "java/lang/StringBuilder":
            if name == "append":
                # Get or initialize buffer
                value = self.get_object_value(obj)
                if not isinstance(value, dict):
                    value = {"buffer": ""}
                # Get the string to append
                if args:
                    arg = args[0]
                    if isinstance(arg, int):
                        # It's a jstring handle
                        jstr = self._objects.get(arg)
                        if isinstance(jstr, JString):
                            value["buffer"] += jstr.value
                            logger.debug(f"StringBuffer.append: added '{jstr.value}', buffer now: '{value['buffer']}'")
                        elif jstr:
                            value["buffer"] += str(arg)
                            logger.debug(f"StringBuffer.append: added str({arg})")
                        else:
                            logger.debug(f"StringBuffer.append: jstr is None for handle {arg:#x}")
                    else:
                        value["buffer"] += str(arg)
                        logger.debug(f"StringBuffer.append: added raw '{arg}'")
                else:
                    logger.debug("StringBuffer.append: no args")
                self.set_object_value(obj, value)
                return obj  # append returns 'this'
            elif name == "toString":
                value = self.get_object_value(obj)
                logger.debug(f"StringBuffer.toString: obj={obj:#x}, value={value}")
                if isinstance(value, dict) and "buffer" in value:
                    result = self.NewStringUTF(value["buffer"])
                    logger.debug(f"StringBuffer.toString: returning '{value['buffer']}' as {result:#x}")
                    return result
                return self.NewStringUTF("")

        # Integer methods
        if class_name == "java/lang/Integer":
            if name == "toString":
                value = self.get_object_value(obj)
                if isinstance(value, int):
                    return self.NewStringUTF(str(value))
                return self.NewStringUTF("0")

        return None  # Not handled

    # Call<Type>Method variants
    def CallObjectMethod(self, obj: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'L')

    def CallObjectMethodV(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'L')

    def CallObjectMethodA(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'L')

    def CallBooleanMethod(self, obj: int, methodID: int, *args) -> bool:
        return self._call_method(obj, methodID, args, 'Z')

    def CallBooleanMethodV(self, obj: int, methodID: int, args) -> bool:
        return self._call_method(obj, methodID, args, 'Z')

    def CallBooleanMethodA(self, obj: int, methodID: int, args) -> bool:
        return self._call_method(obj, methodID, args, 'Z')

    def CallByteMethod(self, obj: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'B')

    def CallByteMethodV(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'B')

    def CallByteMethodA(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'B')

    def CallCharMethod(self, obj: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'C')

    def CallCharMethodV(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'C')

    def CallCharMethodA(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'C')

    def CallShortMethod(self, obj: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'S')

    def CallShortMethodV(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'S')

    def CallShortMethodA(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'S')

    def CallIntMethod(self, obj: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'I')

    def CallIntMethodV(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'I')

    def CallIntMethodA(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'I')

    def CallLongMethod(self, obj: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'J')

    def CallLongMethodV(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'J')

    def CallLongMethodA(self, obj: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'J')

    def CallFloatMethod(self, obj: int, methodID: int, *args) -> float:
        return self._call_method(obj, methodID, args, 'F')

    def CallFloatMethodV(self, obj: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'F')

    def CallFloatMethodA(self, obj: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'F')

    def CallDoubleMethod(self, obj: int, methodID: int, *args) -> float:
        return self._call_method(obj, methodID, args, 'D')

    def CallDoubleMethodV(self, obj: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'D')

    def CallDoubleMethodA(self, obj: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'D')

    def CallVoidMethod(self, obj: int, methodID: int, *args) -> None:
        self._call_method(obj, methodID, args, 'V')

    def CallVoidMethodV(self, obj: int, methodID: int, args) -> None:
        self._call_method(obj, methodID, args, 'V')

    def CallVoidMethodA(self, obj: int, methodID: int, args) -> None:
        self._call_method(obj, methodID, args, 'V')

    # CallNonvirtual<Type>Method variants
    def CallNonvirtualObjectMethod(self, obj: int, clazz: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'L')

    def CallNonvirtualObjectMethodV(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'L')

    def CallNonvirtualObjectMethodA(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'L')

    def CallNonvirtualBooleanMethod(self, obj: int, clazz: int, methodID: int, *args) -> bool:
        return self._call_method(obj, methodID, args, 'Z')

    def CallNonvirtualBooleanMethodV(self, obj: int, clazz: int, methodID: int, args) -> bool:
        return self._call_method(obj, methodID, args, 'Z')

    def CallNonvirtualBooleanMethodA(self, obj: int, clazz: int, methodID: int, args) -> bool:
        return self._call_method(obj, methodID, args, 'Z')

    def CallNonvirtualByteMethod(self, obj: int, clazz: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'B')

    def CallNonvirtualByteMethodV(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'B')

    def CallNonvirtualByteMethodA(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'B')

    def CallNonvirtualCharMethod(self, obj: int, clazz: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'C')

    def CallNonvirtualCharMethodV(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'C')

    def CallNonvirtualCharMethodA(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'C')

    def CallNonvirtualShortMethod(self, obj: int, clazz: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'S')

    def CallNonvirtualShortMethodV(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'S')

    def CallNonvirtualShortMethodA(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'S')

    def CallNonvirtualIntMethod(self, obj: int, clazz: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'I')

    def CallNonvirtualIntMethodV(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'I')

    def CallNonvirtualIntMethodA(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'I')

    def CallNonvirtualLongMethod(self, obj: int, clazz: int, methodID: int, *args) -> int:
        return self._call_method(obj, methodID, args, 'J')

    def CallNonvirtualLongMethodV(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'J')

    def CallNonvirtualLongMethodA(self, obj: int, clazz: int, methodID: int, args) -> int:
        return self._call_method(obj, methodID, args, 'J')

    def CallNonvirtualFloatMethod(self, obj: int, clazz: int, methodID: int, *args) -> float:
        return self._call_method(obj, methodID, args, 'F')

    def CallNonvirtualFloatMethodV(self, obj: int, clazz: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'F')

    def CallNonvirtualFloatMethodA(self, obj: int, clazz: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'F')

    def CallNonvirtualDoubleMethod(self, obj: int, clazz: int, methodID: int, *args) -> float:
        return self._call_method(obj, methodID, args, 'D')

    def CallNonvirtualDoubleMethodV(self, obj: int, clazz: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'D')

    def CallNonvirtualDoubleMethodA(self, obj: int, clazz: int, methodID: int, args) -> float:
        return self._call_method(obj, methodID, args, 'D')

    def CallNonvirtualVoidMethod(self, obj: int, clazz: int, methodID: int, *args) -> None:
        self._call_method(obj, methodID, args, 'V')

    def CallNonvirtualVoidMethodV(self, obj: int, clazz: int, methodID: int, args) -> None:
        self._call_method(obj, methodID, args, 'V')

    def CallNonvirtualVoidMethodA(self, obj: int, clazz: int, methodID: int, args) -> None:
        self._call_method(obj, methodID, args, 'V')

    # CallStatic<Type>Method variants
    def CallStaticObjectMethod(self, clazz: int, methodID: int, *args) -> int:
        return self._call_method(clazz, methodID, args, 'L')

    def CallStaticObjectMethodV(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'L')

    def CallStaticObjectMethodA(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'L')

    def CallStaticBooleanMethod(self, clazz: int, methodID: int, *args) -> bool:
        return self._call_method(clazz, methodID, args, 'Z')

    def CallStaticBooleanMethodV(self, clazz: int, methodID: int, args) -> bool:
        return self._call_method(clazz, methodID, args, 'Z')

    def CallStaticBooleanMethodA(self, clazz: int, methodID: int, args) -> bool:
        return self._call_method(clazz, methodID, args, 'Z')

    def CallStaticByteMethod(self, clazz: int, methodID: int, *args) -> int:
        return self._call_method(clazz, methodID, args, 'B')

    def CallStaticByteMethodV(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'B')

    def CallStaticByteMethodA(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'B')

    def CallStaticCharMethod(self, clazz: int, methodID: int, *args) -> int:
        return self._call_method(clazz, methodID, args, 'C')

    def CallStaticCharMethodV(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'C')

    def CallStaticCharMethodA(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'C')

    def CallStaticShortMethod(self, clazz: int, methodID: int, *args) -> int:
        return self._call_method(clazz, methodID, args, 'S')

    def CallStaticShortMethodV(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'S')

    def CallStaticShortMethodA(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'S')

    def CallStaticIntMethod(self, clazz: int, methodID: int, *args) -> int:
        return self._call_method(clazz, methodID, args, 'I')

    def CallStaticIntMethodV(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'I')

    def CallStaticIntMethodA(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'I')

    def CallStaticLongMethod(self, clazz: int, methodID: int, *args) -> int:
        return self._call_method(clazz, methodID, args, 'J')

    def CallStaticLongMethodV(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'J')

    def CallStaticLongMethodA(self, clazz: int, methodID: int, args) -> int:
        return self._call_method(clazz, methodID, args, 'J')

    def CallStaticFloatMethod(self, clazz: int, methodID: int, *args) -> float:
        return self._call_method(clazz, methodID, args, 'F')

    def CallStaticFloatMethodV(self, clazz: int, methodID: int, args) -> float:
        return self._call_method(clazz, methodID, args, 'F')

    def CallStaticFloatMethodA(self, clazz: int, methodID: int, args) -> float:
        return self._call_method(clazz, methodID, args, 'F')

    def CallStaticDoubleMethod(self, clazz: int, methodID: int, *args) -> float:
        return self._call_method(clazz, methodID, args, 'D')

    def CallStaticDoubleMethodV(self, clazz: int, methodID: int, args) -> float:
        return self._call_method(clazz, methodID, args, 'D')

    def CallStaticDoubleMethodA(self, clazz: int, methodID: int, args) -> float:
        return self._call_method(clazz, methodID, args, 'D')

    def CallStaticVoidMethod(self, clazz: int, methodID: int, *args) -> None:
        self._call_method(clazz, methodID, args, 'V')

    def CallStaticVoidMethodV(self, clazz: int, methodID: int, args) -> None:
        self._call_method(clazz, methodID, args, 'V')

    def CallStaticVoidMethodA(self, clazz: int, methodID: int, args) -> None:
        self._call_method(clazz, methodID, args, 'V')

    # ==================== Field Operations ====================

    def GetFieldID(self, clazz: int, name: str, sig: str) -> int:
        """Returns the field ID for an instance field."""
        jclass = self._objects.get(clazz)
        if not isinstance(jclass, JClass):
            return 0

        field_key = f"{name}{sig}"
        if field_key in jclass.fields_map:
            return jclass.fields_map[field_key]

        field_id = self._alloc_field_id()
        jclass.fields_map[field_key] = field_id
        self._fields[field_id] = JFieldID(
            id=field_id,
            class_name=jclass.class_name,
            name=name,
            signature=sig,
            is_static=False
        )

        logger.debug(f"GetFieldID({jclass.class_name}, {name}, {sig}) -> {field_id:#x}")
        return field_id

    def GetStaticFieldID(self, clazz: int, name: str, sig: str) -> int:
        """Returns the field ID for a static field."""
        jclass = self._objects.get(clazz)
        if not isinstance(jclass, JClass):
            return 0

        field_key = f"static_{name}{sig}"
        if field_key in jclass.fields_map:
            return jclass.fields_map[field_key]

        field_id = self._alloc_field_id()
        jclass.fields_map[field_key] = field_id
        self._fields[field_id] = JFieldID(
            id=field_id,
            class_name=jclass.class_name,
            name=name,
            signature=sig,
            is_static=True
        )

        logger.debug(f"GetStaticFieldID({jclass.class_name}, {name}, {sig}) -> {field_id:#x}")
        return field_id

    def _get_field(self, obj: int, fieldID: int) -> Any:
        """Internal field getter."""
        jobj = self._objects.get(obj)
        field = self._fields.get(fieldID)
        if jobj and field:
            # Check regular field storage first
            if field.name in jobj.fields:
                return jobj.fields.get(field.name)
            # Check mock _value storage for mocked objects
            value_dict = jobj.fields.get("_value")
            if isinstance(value_dict, dict) and field.name in value_dict:
                val = value_dict[field.name]
                if isinstance(val, int):
                    logger.debug(f"GetField({field.name}) from mock object -> {val:#x}")
                else:
                    logger.debug(f"GetField({field.name}) from mock object -> {val}")
                return val
            return 0
        return 0

    def _set_field(self, obj: int, fieldID: int, value: Any) -> None:
        """Internal field setter."""
        jobj = self._objects.get(obj)
        field = self._fields.get(fieldID)
        if jobj and field:
            jobj.fields[field.name] = value

    # Instance field getters
    def GetObjectField(self, obj: int, fieldID: int) -> int:
        return self._get_field(obj, fieldID)

    def GetBooleanField(self, obj: int, fieldID: int) -> bool:
        return bool(self._get_field(obj, fieldID))

    def GetByteField(self, obj: int, fieldID: int) -> int:
        return self._get_field(obj, fieldID) & 0xFF

    def GetCharField(self, obj: int, fieldID: int) -> int:
        return self._get_field(obj, fieldID) & 0xFFFF

    def GetShortField(self, obj: int, fieldID: int) -> int:
        return self._get_field(obj, fieldID) & 0xFFFF

    def GetIntField(self, obj: int, fieldID: int) -> int:
        return self._get_field(obj, fieldID)

    def GetLongField(self, obj: int, fieldID: int) -> int:
        return self._get_field(obj, fieldID)

    def GetFloatField(self, obj: int, fieldID: int) -> float:
        return float(self._get_field(obj, fieldID))

    def GetDoubleField(self, obj: int, fieldID: int) -> float:
        return float(self._get_field(obj, fieldID))

    # Instance field setters
    def SetObjectField(self, obj: int, fieldID: int, value: int) -> None:
        self._set_field(obj, fieldID, value)

    def SetBooleanField(self, obj: int, fieldID: int, value: bool) -> None:
        self._set_field(obj, fieldID, JNI_TRUE if value else JNI_FALSE)

    def SetByteField(self, obj: int, fieldID: int, value: int) -> None:
        self._set_field(obj, fieldID, value & 0xFF)

    def SetCharField(self, obj: int, fieldID: int, value: int) -> None:
        self._set_field(obj, fieldID, value & 0xFFFF)

    def SetShortField(self, obj: int, fieldID: int, value: int) -> None:
        self._set_field(obj, fieldID, value & 0xFFFF)

    def SetIntField(self, obj: int, fieldID: int, value: int) -> None:
        self._set_field(obj, fieldID, value)

    def SetLongField(self, obj: int, fieldID: int, value: int) -> None:
        self._set_field(obj, fieldID, value)

    def SetFloatField(self, obj: int, fieldID: int, value: float) -> None:
        self._set_field(obj, fieldID, value)

    def SetDoubleField(self, obj: int, fieldID: int, value: float) -> None:
        self._set_field(obj, fieldID, value)

    def _get_static_field(self, clazz: int, fieldID: int) -> Any:
        """Internal static field getter."""
        jclass = self._objects.get(clazz)
        field = self._fields.get(fieldID)
        if isinstance(jclass, JClass) and field:
            return jclass.static_fields.get(field.name, 0)
        return 0

    def _set_static_field(self, clazz: int, fieldID: int, value: Any) -> None:
        """Internal static field setter."""
        jclass = self._objects.get(clazz)
        field = self._fields.get(fieldID)
        if isinstance(jclass, JClass) and field:
            jclass.static_fields[field.name] = value

    # Static field getters
    def GetStaticObjectField(self, clazz: int, fieldID: int) -> int:
        return self._get_static_field(clazz, fieldID)

    def GetStaticBooleanField(self, clazz: int, fieldID: int) -> bool:
        return bool(self._get_static_field(clazz, fieldID))

    def GetStaticByteField(self, clazz: int, fieldID: int) -> int:
        return self._get_static_field(clazz, fieldID) & 0xFF

    def GetStaticCharField(self, clazz: int, fieldID: int) -> int:
        return self._get_static_field(clazz, fieldID) & 0xFFFF

    def GetStaticShortField(self, clazz: int, fieldID: int) -> int:
        return self._get_static_field(clazz, fieldID) & 0xFFFF

    def GetStaticIntField(self, clazz: int, fieldID: int) -> int:
        return self._get_static_field(clazz, fieldID)

    def GetStaticLongField(self, clazz: int, fieldID: int) -> int:
        return self._get_static_field(clazz, fieldID)

    def GetStaticFloatField(self, clazz: int, fieldID: int) -> float:
        return float(self._get_static_field(clazz, fieldID))

    def GetStaticDoubleField(self, clazz: int, fieldID: int) -> float:
        return float(self._get_static_field(clazz, fieldID))

    # Static field setters
    def SetStaticObjectField(self, clazz: int, fieldID: int, value: int) -> None:
        self._set_static_field(clazz, fieldID, value)

    def SetStaticBooleanField(self, clazz: int, fieldID: int, value: bool) -> None:
        self._set_static_field(clazz, fieldID, JNI_TRUE if value else JNI_FALSE)

    def SetStaticByteField(self, clazz: int, fieldID: int, value: int) -> None:
        self._set_static_field(clazz, fieldID, value & 0xFF)

    def SetStaticCharField(self, clazz: int, fieldID: int, value: int) -> None:
        self._set_static_field(clazz, fieldID, value & 0xFFFF)

    def SetStaticShortField(self, clazz: int, fieldID: int, value: int) -> None:
        self._set_static_field(clazz, fieldID, value & 0xFFFF)

    def SetStaticIntField(self, clazz: int, fieldID: int, value: int) -> None:
        self._set_static_field(clazz, fieldID, value)

    def SetStaticLongField(self, clazz: int, fieldID: int, value: int) -> None:
        self._set_static_field(clazz, fieldID, value)

    def SetStaticFloatField(self, clazz: int, fieldID: int, value: float) -> None:
        self._set_static_field(clazz, fieldID, value)

    def SetStaticDoubleField(self, clazz: int, fieldID: int, value: float) -> None:
        self._set_static_field(clazz, fieldID, value)

    # ==================== String Operations ====================

    def NewString(self, unicodeChars: int, length: int) -> int:
        """Constructs a new String from Unicode characters."""
        mem = self._emulator.memory
        data = mem.read(unicodeChars, length * 2)
        chars = []
        for i in range(length):
            val = struct.unpack('<H', data[i*2:i*2+2])[0]
            chars.append(chr(val))
        string = ''.join(chars)
        return self.NewStringUTF(string)

    def GetStringLength(self, string: int) -> int:
        """Returns the length of a String in Unicode characters."""
        jstr = self._objects.get(string)
        if isinstance(jstr, JString):
            return len(jstr.value)
        return 0

    def GetStringChars(self, string: int, isCopy: int) -> int:
        """Returns a pointer to the Unicode characters of a String."""
        jstr = self._objects.get(string)
        if isinstance(jstr, JString):
            # Allocate memory and write UTF-16 characters
            mem = self._emulator.memory
            data = jstr.value.encode('utf-16-le')
            ptr = mem.allocate(len(data) + 2)
            mem.write(ptr, data + b'\x00\x00')
            if isCopy:
                mem.write_u8(isCopy, JNI_TRUE)
            return ptr
        return 0

    def ReleaseStringChars(self, string: int, chars: int) -> None:
        """Releases the Unicode characters of a String."""
        pass  # Memory will be reclaimed later

    def NewStringUTF(self, string: str) -> int:
        """Constructs a new String from UTF-8 characters."""
        handle = self._alloc_handle()
        jstr = JString(handle=handle, class_name="java/lang/String", value=string)
        self._objects[handle] = jstr
        self._strings[handle] = string
        self._add_local_ref(handle)

        logger.debug(f"NewStringUTF({string!r}) -> {handle:#x}")
        return handle

    def GetStringUTFLength(self, string: int) -> int:
        """Returns the UTF-8 length of a String."""
        jstr = self._objects.get(string)
        if isinstance(jstr, JString):
            return len(jstr.value.encode('utf-8'))
        return 0

    def GetStringUTFChars(self, string: int, isCopy: int) -> int:
        """Returns a pointer to the UTF-8 characters of a String."""
        jstr = self._objects.get(string)
        if isinstance(jstr, JString):
            ptr = self._emulator.memory.alloc_string(jstr.value)
            if isCopy:
                self._emulator.memory.write_u8(isCopy, JNI_TRUE)
            logger.debug(f"GetStringUTFChars({string:#x}) -> {ptr:#x}")
            return ptr
        return 0

    def ReleaseStringUTFChars(self, string: int, utf: int) -> None:
        """Releases the UTF-8 characters of a String."""
        pass  # Memory will be reclaimed later

    def GetStringRegion(self, string: int, start: int, length: int, buf: int) -> None:
        """Copies Unicode characters to a buffer."""
        jstr = self._objects.get(string)
        if isinstance(jstr, JString):
            mem = self._emulator.memory
            substr = jstr.value[start:start+length]
            data = substr.encode('utf-16-le')
            mem.write(buf, data)

    def GetStringUTFRegion(self, string: int, start: int, length: int, buf: int) -> None:
        """Copies UTF-8 characters to a buffer."""
        jstr = self._objects.get(string)
        if isinstance(jstr, JString):
            mem = self._emulator.memory
            substr = jstr.value[start:start+length]
            data = substr.encode('utf-8')
            mem.write(buf, data + b'\x00')

    def GetStringCritical(self, string: int, isCopy: int) -> int:
        """Returns a pointer to string characters (critical section)."""
        ptr = self.GetStringChars(string, isCopy)
        if ptr:
            self._string_critical[ptr] = string
        return ptr

    def ReleaseStringCritical(self, string: int, carray: int) -> None:
        """Releases the critical string characters."""
        self._string_critical.pop(carray, None)

    # ==================== Array Operations ====================

    def GetArrayLength(self, array: int) -> int:
        """Returns the number of elements in an array."""
        jarr = self._arrays.get(array) or self._objects.get(array)
        if isinstance(jarr, JArray):
            return jarr.length
        return 0

    def NewObjectArray(self, length: int, elementClass: int, initialElement: int) -> int:
        """Constructs a new object array."""
        jclass = self._objects.get(elementClass)
        component_class = jclass.class_name if isinstance(jclass, JClass) else "java/lang/Object"

        handle = self._alloc_handle()
        arr = JObjectArray(
            handle=handle,
            class_name=f"[L{component_class};",
            length=length,
            component_class=component_class,
            elements=[initialElement] * length
        )
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)

        logger.debug(f"NewObjectArray({length}, {component_class}) -> {handle:#x}")
        return handle

    def GetObjectArrayElement(self, array: int, index: int) -> int:
        """Returns an element of an object array."""
        jarr = self._arrays.get(array)
        if isinstance(jarr, JObjectArray):
            return jarr.get(index)
        return 0

    def SetObjectArrayElement(self, array: int, index: int, value: int) -> None:
        """Sets an element of an object array."""
        jarr = self._arrays.get(array)
        if isinstance(jarr, JObjectArray):
            jarr.set(index, value)

    # Primitive array creation
    def NewBooleanArray(self, length: int) -> int:
        handle = self._alloc_handle()
        arr = JBooleanArray(handle=handle, length=length)
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        return handle

    def NewByteArray(self, length_or_data: int | bytes) -> int:
        """
        Creates a new byte array.
        
        Args:
            length_or_data: Either length (int) or actual data (bytes)
            
        Returns:
            Handle to the new byte array
        """
        if isinstance(length_or_data, bytes):
            data = length_or_data
            length = len(data)
        else:
            length = int(length_or_data)
            data = b'\x00' * length

        handle = self._alloc_handle()
        arr = JByteArray(
            handle=handle,
            class_name="[B",
            length=length,
            element_type="B",
            _element_size=1,
        )
        arr._data = data
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        logger.debug(f"NewByteArray({length}) -> {handle:#x}")
        return handle

    def NewCharArray(self, length: int) -> int:
        handle = self._alloc_handle()
        arr = JCharArray(handle=handle, length=length)
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        return handle

    def NewShortArray(self, length: int) -> int:
        handle = self._alloc_handle()
        arr = JShortArray(handle=handle, length=length)
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        return handle

    def NewIntArray(self, length: int) -> int:
        handle = self._alloc_handle()
        arr = JIntArray(handle=handle, length=length)
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        return handle

    def NewLongArray(self, length: int) -> int:
        handle = self._alloc_handle()
        arr = JLongArray(handle=handle, length=length)
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        return handle

    def NewFloatArray(self, length: int) -> int:
        handle = self._alloc_handle()
        arr = JFloatArray(handle=handle, length=length)
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        return handle

    def NewDoubleArray(self, length: int) -> int:
        handle = self._alloc_handle()
        arr = JDoubleArray(handle=handle, length=length)
        self._objects[handle] = arr
        self._arrays[handle] = arr
        self._add_local_ref(handle)
        return handle

    def _get_array_elements(self, array: int, isCopy: int, element_size: int) -> int:
        """Internal implementation for Get*ArrayElements."""
        jarr = self._arrays.get(array)
        if isinstance(jarr, JArray):
            mem = self._emulator.memory
            data = jarr.get_data()
            if not data:
                # Empty array - return a dummy pointer
                return 0
            ptr = mem.allocate(len(data), name=f"[array_elements_{array:#x}]")
            mem.write(ptr, data)
            self._array_elements[ptr] = (array, 1)  # Mark as copy
            if isCopy:
                mem.write_u8(isCopy, JNI_TRUE)
            return ptr
        # array 0x0 is common for uninitialized arrays
        if array != 0:
            logger.warning(f"GetArrayElements: array {array:#x} not found in _arrays")
        return 0

    def _release_array_elements(self, array: int, elems: int, mode: int, element_size: int) -> None:
        """Internal implementation for Release*ArrayElements."""
        if elems in self._array_elements:
            array_handle, _ = self._array_elements[elems]
            jarr = self._arrays.get(array_handle)

            if mode != JNI_ABORT and isinstance(jarr, JArray):
                # Copy back
                mem = self._emulator.memory
                data = mem.read(elems, jarr.length * element_size)
                jarr.set_data(data)

            if mode != JNI_COMMIT:
                del self._array_elements[elems]

    # Get*ArrayElements
    def GetBooleanArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 1)

    def GetByteArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 1)

    def GetCharArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 2)

    def GetShortArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 2)

    def GetIntArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 4)

    def GetLongArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 8)

    def GetFloatArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 4)

    def GetDoubleArrayElements(self, array: int, isCopy: int) -> int:
        return self._get_array_elements(array, isCopy, 8)

    # Release*ArrayElements
    def ReleaseBooleanArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 1)

    def ReleaseByteArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 1)

    def ReleaseCharArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 2)

    def ReleaseShortArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 2)

    def ReleaseIntArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 4)

    def ReleaseLongArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 8)

    def ReleaseFloatArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 4)

    def ReleaseDoubleArrayElements(self, array: int, elems: int, mode: int) -> None:
        self._release_array_elements(array, elems, mode, 8)

    def _get_array_region(self, array: int, start: int, length: int, buf: int, element_size: int) -> None:
        """Internal implementation for Get*ArrayRegion."""
        jarr = self._arrays.get(array)
        if isinstance(jarr, JArray):
            data = jarr.get_data()
            region = data[start * element_size:(start + length) * element_size]
            self._emulator.memory.write(buf, region)

    def _set_array_region(self, array: int, start: int, length: int, buf: int, element_size: int) -> None:
        """Internal implementation for Set*ArrayRegion."""
        jarr = self._arrays.get(array)
        if isinstance(jarr, JArray):
            mem = self._emulator.memory
            region = mem.read(buf, length * element_size)
            data = bytearray(jarr.get_data())
            offset = start * element_size
            data[offset:offset + len(region)] = region
            jarr.set_data(bytes(data))

    # Get*ArrayRegion
    def GetBooleanArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 1)

    def GetByteArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 1)

    def GetCharArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 2)

    def GetShortArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 2)

    def GetIntArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 4)

    def GetLongArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 8)

    def GetFloatArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 4)

    def GetDoubleArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._get_array_region(array, start, length, buf, 8)

    # Set*ArrayRegion
    def SetBooleanArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 1)

    def SetByteArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 1)

    def SetCharArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 2)

    def SetShortArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 2)

    def SetIntArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 4)

    def SetLongArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 8)

    def SetFloatArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 4)

    def SetDoubleArrayRegion(self, array: int, start: int, length: int, buf: int) -> None:
        self._set_array_region(array, start, length, buf, 8)

    def GetPrimitiveArrayCritical(self, array: int, isCopy: int) -> int:
        """Returns a direct pointer to array elements (critical section)."""
        return self._get_array_elements(array, isCopy, 1)

    def ReleasePrimitiveArrayCritical(self, array: int, carray: int, mode: int) -> None:
        """Releases the primitive array critical section."""
        self._release_array_elements(array, carray, mode, 1)

    # ==================== Native Method Registration ====================

    def RegisterNatives(self, clazz: int, methods: int, nMethods: int) -> int:
        """Registers native methods with a class."""
        jclass = self._objects.get(clazz)
        if not isinstance(jclass, JClass):
            return JNI_ERR

        mem = self._emulator.memory
        ptr_size = self._ptr_size

        for i in range(nMethods):
            offset = i * (ptr_size * 3)  # name, signature, fnPtr
            name_ptr = mem.read_ptr(methods + offset)
            sig_ptr = mem.read_ptr(methods + offset + ptr_size)
            fn_ptr = mem.read_ptr(methods + offset + ptr_size * 2)

            name = mem.read_string(name_ptr)
            sig = mem.read_string(sig_ptr)

            key = (jclass.class_name, name, sig)
            self._native_methods[key] = fn_ptr
            jclass.native_methods[f"{name}{sig}"] = fn_ptr

            logger.debug(f"RegisterNatives: {jclass.class_name}.{name}{sig} -> {fn_ptr:#x}")

        return JNI_OK

    def UnregisterNatives(self, clazz: int) -> int:
        """Unregisters native methods of a class."""
        jclass = self._objects.get(clazz)
        if isinstance(jclass, JClass):
            # Remove all native methods for this class
            keys_to_remove = [k for k in self._native_methods if k[0] == jclass.class_name]
            for key in keys_to_remove:
                del self._native_methods[key]
            jclass.native_methods.clear()
        return JNI_OK

    # ==================== Monitor Operations ====================

    def MonitorEnter(self, obj: int) -> int:
        """Enters the monitor associated with an object."""
        logger.debug(f"MonitorEnter({obj:#x})")
        return JNI_OK

    def MonitorExit(self, obj: int) -> int:
        """Exits the monitor associated with an object."""
        logger.debug(f"MonitorExit({obj:#x})")
        return JNI_OK

    # ==================== VM Operations ====================

    def GetJavaVM(self, vm: int) -> int:
        """Returns the Java VM interface pointer."""
        mem = self._emulator.memory
        mem.write_ptr(vm, self._emulator.java_vm.get_pointer())
        return JNI_OK

    # ==================== Direct Buffer Operations ====================

    def NewDirectByteBuffer(self, address: int, capacity: int) -> int:
        """Creates a direct ByteBuffer that wraps memory."""
        handle = self._alloc_handle()
        buf = JDirectBuffer(
            handle=handle,
            class_name="java/nio/DirectByteBuffer",
            address=address,
            capacity=capacity
        )
        self._objects[handle] = buf
        self._direct_buffers[handle] = buf
        self._add_local_ref(handle)

        logger.debug(f"NewDirectByteBuffer({address:#x}, {capacity}) -> {handle:#x}")
        return handle

    def GetDirectBufferAddress(self, buf: int) -> int:
        """Returns the address of a direct buffer."""
        dbuf = self._direct_buffers.get(buf)
        if dbuf:
            return dbuf.address
        return 0

    def GetDirectBufferCapacity(self, buf: int) -> int:
        """Returns the capacity of a direct buffer."""
        dbuf = self._direct_buffers.get(buf)
        if dbuf:
            return dbuf.capacity
        return -1

    # ==================== Reflection Operations ====================

    def FromReflectedMethod(self, method: int) -> int:
        """Converts a java.lang.reflect.Method to a method ID."""
        # For now, return the handle as the method ID
        return method

    def FromReflectedField(self, field: int) -> int:
        """Converts a java.lang.reflect.Field to a field ID."""
        return field

    def ToReflectedMethod(self, clazz: int, methodID: int, isStatic: bool) -> int:
        """Converts a method ID to a java.lang.reflect.Method."""
        method = self._methods.get(methodID)
        if method:
            handle = self._alloc_handle()
            obj = JObject(handle=handle, class_name="java/lang/reflect/Method")
            obj.fields["name"] = method.name
            obj.fields["signature"] = method.signature
            self._objects[handle] = obj
            self._add_local_ref(handle)
            return handle
        return 0

    def ToReflectedField(self, clazz: int, fieldID: int, isStatic: bool) -> int:
        """Converts a field ID to a java.lang.reflect.Field."""
        field = self._fields.get(fieldID)
        if field:
            handle = self._alloc_handle()
            obj = JObject(handle=handle, class_name="java/lang/reflect/Field")
            obj.fields["name"] = field.name
            obj.fields["signature"] = field.signature
            self._objects[handle] = obj
            self._add_local_ref(handle)
            return handle
        return 0

    # ==================== Module Operations (Java 9+) ====================

    def GetModule(self, clazz: int) -> int:
        """Returns the module that the class is a member of."""
        # Return a dummy module object
        handle = self._alloc_handle()
        obj = JObject(handle=handle, class_name="java/lang/Module")
        self._objects[handle] = obj
        self._add_local_ref(handle)
        return handle

    # ==================== Convenience Methods (Python API) ====================

    def get_string_utf(self, jstring: int) -> str:
        """Get the UTF-8 string value from a jstring. (Python convenience method)"""
        return self._strings.get(jstring, "")

    def new_string_utf(self, string: str) -> int:
        """Create a new jstring from a UTF-8 string. (Python convenience method)"""
        return self.NewStringUTF(string)

    def find_class(self, name: str) -> int:
        """Find a class by name. (Python convenience method)"""
        return self.FindClass(name)

    def get_method_id(self, clazz: int, name: str, sig: str) -> int:
        """Get a method ID. (Python convenience method)"""
        return self.GetMethodID(clazz, name, sig)

    def get_version(self) -> int:
        """Get JNI version. (Python convenience method)"""
        return self.GetVersion()

    def new_global_ref(self, obj: int) -> int:
        """Create a global reference. (Python convenience method)"""
        return self.NewGlobalRef(obj)

    def delete_global_ref(self, ref: int) -> None:
        """Delete a global reference. (Python convenience method)"""
        self.DeleteGlobalRef(ref)

    def new_local_ref(self, obj: int) -> int:
        """Create a local reference. (Python convenience method)"""
        return self.NewLocalRef(obj)

    def delete_local_ref(self, ref: int) -> None:
        """Delete a local reference. (Python convenience method)"""
        self.DeleteLocalRef(ref)

    def push_local_frame(self, capacity: int) -> int:
        """Push a new local reference frame. (Python convenience method)"""
        return self.PushLocalFrame(capacity)

    def pop_local_frame(self, result: int) -> int:
        """Pop a local reference frame. (Python convenience method)"""
        return self.PopLocalFrame(result)

    def exception_check(self) -> bool:
        """Check if an exception is pending. (Python convenience method)"""
        return self.ExceptionCheck()

    def exception_clear(self) -> None:
        """Clear any pending exception. (Python convenience method)"""
        self.ExceptionClear()

    def register_method_handler(
        self,
        class_name_or_id: str | int,
        name: str | None = None,
        sig: str | None = None,
        handler: Callable | None = None,
    ) -> None:
        """
        Register a Python handler for a Java method. (Python convenience method)
        
        Can be called two ways:
        1. register_method_handler(method_id, handler) - by method ID
        2. register_method_handler(class_name, name, sig, handler) - by signature
        
        Args:
            class_name_or_id: Either method ID (int) or class name (str)
            name: Method name (if using signature-based registration)
            sig: Method signature (if using signature-based registration)
            handler: Callback function
        """
        if isinstance(class_name_or_id, int):
            # Old style: register by method ID
            if callable(name):
                handler = name
            self._method_handlers[class_name_or_id] = handler
        else:
            # New style: register by signature
            class_name = class_name_or_id.replace('.', '/')
            key = (class_name, name, sig, False)  # False = not static

            # Store signature-based handler
            if not hasattr(self, '_signature_handlers'):
                self._signature_handlers: dict[tuple, Callable] = {}
            self._signature_handlers[key] = handler

    def register_static_method_handler(
        self,
        class_name: str,
        name: str,
        sig: str,
        handler: Callable,
    ) -> None:
        """
        Register a handler for a static Java method. (Python convenience method)
        
        Args:
            class_name: Fully qualified class name (e.g., "com/example/MyClass")
            name: Method name
            sig: Method signature
            handler: Callback function
        """
        class_name = class_name.replace('.', '/')
        key = (class_name, name, sig, True)  # True = static

        if not hasattr(self, '_signature_handlers'):
            self._signature_handlers: dict[tuple, Callable] = {}
        self._signature_handlers[key] = handler

    def register_field_handler(
        self,
        class_name: str,
        name: str,
        sig: str,
        handler: Callable,
    ) -> None:
        """
        Register a handler for a Java field. (Python convenience method)
        
        Args:
            class_name: Fully qualified class name
            name: Field name
            sig: Field signature
            handler: Callback function (called when field is accessed)
        """
        class_name = class_name.replace('.', '/')
        key = (class_name, name, sig)

        if not hasattr(self, '_field_handlers'):
            self._field_handlers: dict[tuple, Callable] = {}
        self._field_handlers[key] = handler

    def register_static_field_handler(
        self,
        class_name: str,
        name: str,
        sig: str,
        handler: Callable,
    ) -> None:
        """
        Register a handler for a static Java field. (Python convenience method)
        
        Args:
            class_name: Fully qualified class name
            name: Field name
            sig: Field signature
            handler: Callback function (called when field is accessed)
        """
        class_name = class_name.replace('.', '/')
        key = (class_name, name, sig, True)  # True = static

        if not hasattr(self, '_field_handlers'):
            self._field_handlers: dict[tuple, Callable] = {}
        self._field_handlers[key] = handler

    def get_object_value(self, handle: int) -> Any:
        """
        Get the Python value associated with a JObject. (Python convenience method)
        
        Args:
            handle: Object handle
            
        Returns:
            The Python value, or None if not set
        """
        obj = self._objects.get(handle)
        if obj:
            return obj.fields.get("_value")
        return None

    def set_object_value(self, handle: int, value: Any) -> None:
        """
        Set the Python value associated with a JObject. (Python convenience method)
        
        Args:
            handle: Object handle
            value: Python value to associate
        """
        obj = self._objects.get(handle)
        if obj:
            obj.fields["_value"] = value

    def get_string_value(self, jstring: int) -> str:
        """
        Get the UTF-8 string value from a jstring handle. (Python convenience method)
        
        Args:
            jstring: String handle
            
        Returns:
            The string value
        """
        # First check the strings table
        if jstring in self._strings:
            return self._strings[jstring]

        # Then check if it's a JString object
        obj = self._objects.get(jstring)
        if isinstance(obj, JString):
            return obj.value

        return ""

    def get_object(self, handle: int) -> JObject | None:
        """Get a JObject by handle. (Python convenience method)"""
        return self._objects.get(handle)

    def get_array(self, handle: int) -> JArray | None:
        """Get a JArray by handle. (Python convenience method)"""
        return self._arrays.get(handle)

    def new_byte_array_from_data(self, data: bytes) -> int:
        """Create a byte array from Python bytes. (Python convenience method)"""
        handle = self.NewByteArray(len(data))
        jarr = self._arrays.get(handle)
        if isinstance(jarr, JByteArray):
            jarr._data = data
        return handle

    def get_byte_array_data(self, handle: int) -> bytes:
        """Get byte array data as Python bytes. (Python convenience method)"""
        jarr = self._arrays.get(handle)
        if isinstance(jarr, JByteArray):
            return jarr._data
        return b''
