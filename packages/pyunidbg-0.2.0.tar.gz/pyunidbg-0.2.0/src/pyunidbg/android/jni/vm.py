"""
JavaVM implementation for JNI.

Provides the JNIInvokeInterface function table for JNI_OnLoad,
thread attachment, and VM lifecycle operations.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pyunidbg.core.constants import Architecture, MemoryLayout, MemoryProtection

from .constants import JNI_EDETACHED, JNI_EVERSION, JNI_OK, JNI_VERSION_1_6

if TYPE_CHECKING:
    from pyunidbg.android.emulator import AndroidEmulator

    from .env import JNIEnv

logger = logging.getLogger(__name__)


class JavaVM:
    """
    JavaVM implementation.
    
    Provides the JNIInvokeInterface function table that native code uses
    for VM lifecycle operations:
    
    - DestroyJavaVM: Unloads the Java VM
    - AttachCurrentThread: Attaches the current thread to the VM
    - DetachCurrentThread: Detaches the current thread from the VM  
    - GetEnv: Gets the JNIEnv for the current thread
    - AttachCurrentThreadAsDaemon: Attaches as a daemon thread
    """

    # JavaVM function table indices
    DESTROY_JAVA_VM = 3
    ATTACH_CURRENT_THREAD = 4
    DETACH_CURRENT_THREAD = 5
    GET_ENV = 6
    ATTACH_CURRENT_THREAD_AS_DAEMON = 7

    NUM_FUNCTIONS = 8

    def __init__(self, emulator: AndroidEmulator):
        self._emulator = emulator
        self._ptr_size = emulator.pointer_size

        # Thread attachment state
        self._attached_threads: set[int] = {1}  # Main thread is always attached
        self._daemon_threads: set[int] = set()

        # Setup function table
        self._vm_ptr = self._setup_function_table()

    def _setup_function_table(self) -> int:
        """Create JavaVM function table in memory with hooked trampolines."""
        mem = self._emulator.memory
        ptr_size = self._ptr_size

        # JavaVM* -> JNIInvokeInterface*
        num_functions = self.NUM_FUNCTIONS
        table_size = num_functions * ptr_size

        func_table = mem.allocate(table_size, name="[JNIInvokeInterface]")
        vm_ptr = mem.allocate(ptr_size, name="[JavaVM]")
        mem.write_ptr(vm_ptr, func_table)

        # Setup trampolines with proper executable memory
        trampoline_base = MemoryLayout.HOOK_BASE + 0x20000
        mem.map(trampoline_base, 0x1000,
               protection=MemoryProtection.READ_WRITE_EXEC,
               name="[javavm_trampolines]")

        self._trampoline_base = trampoline_base

        # Write return instructions to trampolines
        for i in range(num_functions):
            trampoline_addr = trampoline_base + (i * 16)
            mem.write_ptr(func_table + (i * ptr_size), trampoline_addr)

            if self._emulator.arch == Architecture.ARM64:
                # ARM64: RET (0xD65F03C0)
                mem.write(trampoline_addr, b"\xC0\x03\x5F\xD6")
            else:
                # ARM32: BX LR
                mem.write(trampoline_addr, b"\x1E\xFF\x2F\xE1")

        # Add code hook for JavaVM trampolines
        self._add_trampoline_hook()

        return vm_ptr

    def _add_trampoline_hook(self) -> None:
        """Add a hook to intercept JavaVM function calls."""
        from unicorn import UC_HOOK_CODE

        trampoline_base = self._trampoline_base
        trampoline_end = trampoline_base + 0x1000

        def javavm_hook(uc, address, size, user_data):
            # Calculate function index from address
            func_idx = (address - trampoline_base) // 16

            # Get arguments
            if self._emulator.is_64bit:
                vm = self._emulator.cpu.get_arg(0)
                arg1 = self._emulator.cpu.get_arg(1)
                arg2 = self._emulator.cpu.get_arg(2)
            else:
                vm = self._emulator.cpu.get_arg(0)
                arg1 = self._emulator.cpu.get_arg(1)
                arg2 = self._emulator.cpu.get_arg(2)

            result = JNI_OK

            if func_idx == self.DESTROY_JAVA_VM:
                result = self.DestroyJavaVM()
            elif func_idx == self.ATTACH_CURRENT_THREAD:
                result, env = self.AttachCurrentThread(arg1, arg2)
            elif func_idx == self.DETACH_CURRENT_THREAD:
                result = self.DetachCurrentThread()
            elif func_idx == self.GET_ENV:
                # GetEnv(JavaVM* vm, void** penv, jint version)
                result, env = self.GetEnv(arg1, arg2)
            elif func_idx == self.ATTACH_CURRENT_THREAD_AS_DAEMON:
                result, env = self.AttachCurrentThreadAsDaemon(arg1, arg2)
            else:
                logger.warning(f"Unknown JavaVM function index: {func_idx}")

            # Set return value
            self._emulator.cpu.set_return_value(result)

        self._emulator._uc.hook_add(UC_HOOK_CODE, javavm_hook,
                                    begin=trampoline_base, end=trampoline_end)

    def get_pointer(self) -> int:
        """Get the JavaVM* pointer."""
        return self._vm_ptr

    @property
    def jni_env(self) -> JNIEnv:
        """Get the JNIEnv associated with this VM."""
        return self._emulator.jni

    # ==================== JNI Invocation Interface ====================

    def DestroyJavaVM(self) -> int:
        """
        Unloads the Java VM and reclaims its resources.
        
        Any thread, whether attached or not, can invoke this function.
        If the current thread is attached, the VM waits until the current
        thread is the only non-daemon user-level Java thread.
        
        Returns:
            JNI_OK on success
            JNI_ERR on failure
        """
        logger.info("DestroyJavaVM called")
        # In our emulation, this is essentially a no-op
        # A real implementation would clean up all VM resources
        return JNI_OK

    def AttachCurrentThread(self, p_env: int = 0, thr_args: int = 0) -> tuple[int, int]:
        """
        Attaches the current thread to the Java VM.
        
        If the thread is already attached, this call is a no-op.
        
        Args:
            p_env: Pointer to store the JNIEnv*
            thr_args: Thread attachment arguments (JavaVMAttachArgs*)
        
        Returns:
            Tuple of (result_code, JNIEnv*)
        """
        thread_id = self._get_current_thread_id()
        self._attached_threads.add(thread_id)

        env_ptr = self.jni_env.get_pointer()

        if p_env:
            self._emulator.memory.write_ptr(p_env, env_ptr)

        logger.debug(f"AttachCurrentThread(thread={thread_id}) -> {env_ptr:#x}")
        return (JNI_OK, env_ptr)

    def AttachCurrentThreadAsDaemon(self, p_env: int = 0, thr_args: int = 0) -> tuple[int, int]:
        """
        Attaches the current thread as a daemon thread.
        
        Same as AttachCurrentThread, but the newly-created java.lang.Thread
        instance is a daemon.
        
        Args:
            p_env: Pointer to store the JNIEnv*
            thr_args: Thread attachment arguments
        
        Returns:
            Tuple of (result_code, JNIEnv*)
        """
        thread_id = self._get_current_thread_id()
        self._attached_threads.add(thread_id)
        self._daemon_threads.add(thread_id)

        env_ptr = self.jni_env.get_pointer()

        if p_env:
            self._emulator.memory.write_ptr(p_env, env_ptr)

        logger.debug(f"AttachCurrentThreadAsDaemon(thread={thread_id}) -> {env_ptr:#x}")
        return (JNI_OK, env_ptr)

    def DetachCurrentThread(self) -> int:
        """
        Detaches the current thread from the Java VM.
        
        All Java monitors held by this thread are released.
        All Java threads waiting for this thread to die are notified.
        
        Returns:
            JNI_OK on success
            JNI_EDETACHED if the thread is not attached
        """
        thread_id = self._get_current_thread_id()

        if thread_id not in self._attached_threads:
            return JNI_EDETACHED

        self._attached_threads.discard(thread_id)
        self._daemon_threads.discard(thread_id)

        logger.debug(f"DetachCurrentThread(thread={thread_id})")
        return JNI_OK

    def GetEnv(self, p_env: int = 0, version: int = JNI_VERSION_1_6) -> tuple[int, int]:
        """
        Gets the JNIEnv for the current thread.
        
        Args:
            p_env: Pointer to store the JNIEnv*
            version: The requested JNI version
        
        Returns:
            Tuple of (result_code, JNIEnv*)
            JNI_OK if successful
            JNI_EDETACHED if thread is not attached
            JNI_EVERSION if requested version is not supported
        """
        # Check version
        if version > JNI_VERSION_1_6:
            logger.warning(f"GetEnv: unsupported version {version:#x}")
            return (JNI_EVERSION, 0)

        # Check if thread is attached
        thread_id = self._get_current_thread_id()
        if thread_id not in self._attached_threads:
            return (JNI_EDETACHED, 0)

        env_ptr = self.jni_env.get_pointer()

        if p_env:
            self._emulator.memory.write_ptr(p_env, env_ptr)

        return (JNI_OK, env_ptr)

    def _get_current_thread_id(self) -> int:
        """Get the current thread ID (for emulation purposes)."""
        # In our single-threaded emulation, always return 1
        return 1

    # ==================== Thread Management ====================

    def is_thread_attached(self, thread_id: int = None) -> bool:
        """Check if a thread is attached to the VM."""
        if thread_id is None:
            thread_id = self._get_current_thread_id()
        return thread_id in self._attached_threads

    def is_daemon_thread(self, thread_id: int = None) -> bool:
        """Check if a thread is a daemon thread."""
        if thread_id is None:
            thread_id = self._get_current_thread_id()
        return thread_id in self._daemon_threads

    def get_attached_thread_count(self) -> int:
        """Get the number of attached threads."""
        return len(self._attached_threads)

    def get_non_daemon_thread_count(self) -> int:
        """Get the number of non-daemon threads."""
        return len(self._attached_threads - self._daemon_threads)

    # ==================== Convenience Methods (Python API) ====================

    def attach_current_thread(self) -> tuple[int, int]:
        """Attach the current thread. (Python convenience method)"""
        return self.AttachCurrentThread()

    def detach_current_thread(self) -> int:
        """Detach the current thread. (Python convenience method)"""
        return self.DetachCurrentThread()

    def get_env(self, version: int = JNI_VERSION_1_6) -> tuple[int, int]:
        """Get the JNIEnv for the current thread. (Python convenience method)"""
        return self.GetEnv(0, version)
