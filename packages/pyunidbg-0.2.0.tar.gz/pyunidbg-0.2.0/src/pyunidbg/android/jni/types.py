"""JNI type definitions."""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Any


@dataclass
class JObject:
    """Represents a Java object in native code."""

    handle: int
    class_name: str
    fields: dict[str, Any] = field(default_factory=dict)

    def __hash__(self):
        return self.handle

    def __eq__(self, other):
        if isinstance(other, JObject):
            return self.handle == other.handle
        return False


@dataclass
class JString(JObject):
    """Represents a Java String."""

    value: str = ""

    def __post_init__(self):
        self.class_name = "java/lang/String"

    def length(self) -> int:
        """Get the length of the string in characters."""
        return len(self.value)

    def utf_length(self) -> int:
        """Get the length of the string in UTF-8 bytes."""
        return len(self.value.encode('utf-8'))


@dataclass
class JClass(JObject):
    """Represents a Java Class."""

    methods: dict[str, int] = field(default_factory=dict)  # name+sig -> method_id
    static_methods: dict[str, int] = field(default_factory=dict)
    fields_map: dict[str, int] = field(default_factory=dict)  # name+sig -> field_id
    static_fields: dict[str, Any] = field(default_factory=dict)
    superclass: str | None = None
    interfaces: list[str] = field(default_factory=list)
    native_methods: dict[str, int] = field(default_factory=dict)  # name+sig -> fn_ptr

    def __post_init__(self):
        if not self.class_name:
            self.class_name = "java/lang/Class"


@dataclass
class JThrowable(JObject):
    """Represents a Java Throwable/Exception."""

    message: str = ""
    cause: int | None = None  # Handle to cause throwable
    stack_trace: list[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.class_name:
            self.class_name = "java/lang/Throwable"


@dataclass
class JArray(JObject):
    """Base class for Java arrays."""

    length: int = 0
    element_type: str = ""
    _data: bytes = field(default_factory=bytes, repr=False)
    _element_size: int = 1

    def __post_init__(self):
        if not self.class_name:
            self.class_name = f"[{self.element_type}"

    def get_data(self) -> bytes:
        """Get raw array data."""
        return self._data

    def set_data(self, data: bytes) -> None:
        """Set raw array data."""
        self._data = data


@dataclass
class JBooleanArray(JArray):
    """Java boolean[] array."""

    def __post_init__(self):
        self.element_type = "Z"
        self.class_name = "[Z"
        self._element_size = 1
        if not self._data:
            self._data = bytes(self.length)

    def get(self, index: int) -> bool:
        """Get element at index."""
        if 0 <= index < self.length:
            return self._data[index] != 0
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: bool) -> None:
        """Set element at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            data[index] = 1 if value else 0
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_list(self) -> list[bool]:
        """Convert to Python list."""
        return [b != 0 for b in self._data]


@dataclass
class JByteArray(JArray):
    """Java byte[] array."""

    def __post_init__(self):
        self.element_type = "B"
        self.class_name = "[B"
        self._element_size = 1
        if not self._data:
            self._data = bytes(self.length)

    def get(self, index: int) -> int:
        """Get element at index (as signed byte)."""
        if 0 <= index < self.length:
            val = self._data[index]
            return val if val < 128 else val - 256
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: int) -> None:
        """Set element at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            data[index] = value & 0xFF
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_list(self) -> list[int]:
        """Convert to Python list of signed bytes."""
        return [b if b < 128 else b - 256 for b in self._data]

    def to_bytes(self) -> bytes:
        """Get as bytes."""
        return self._data


@dataclass
class JCharArray(JArray):
    """Java char[] array (16-bit Unicode)."""

    def __post_init__(self):
        self.element_type = "C"
        self.class_name = "[C"
        self._element_size = 2
        if not self._data:
            self._data = bytes(self.length * 2)

    def get(self, index: int) -> str:
        """Get character at index."""
        if 0 <= index < self.length:
            offset = index * 2
            val = struct.unpack('<H', self._data[offset:offset+2])[0]
            return chr(val)
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: str) -> None:
        """Set character at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            offset = index * 2
            struct.pack_into('<H', data, offset, ord(value[0]) if value else 0)
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_string(self) -> str:
        """Convert to Python string."""
        chars = []
        for i in range(self.length):
            offset = i * 2
            val = struct.unpack('<H', self._data[offset:offset+2])[0]
            chars.append(chr(val))
        return ''.join(chars)


@dataclass
class JShortArray(JArray):
    """Java short[] array."""

    def __post_init__(self):
        self.element_type = "S"
        self.class_name = "[S"
        self._element_size = 2
        if not self._data:
            self._data = bytes(self.length * 2)

    def get(self, index: int) -> int:
        """Get element at index."""
        if 0 <= index < self.length:
            offset = index * 2
            return struct.unpack('<h', self._data[offset:offset+2])[0]
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: int) -> None:
        """Set element at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            offset = index * 2
            struct.pack_into('<h', data, offset, value)
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_list(self) -> list[int]:
        """Convert to Python list."""
        return [self.get(i) for i in range(self.length)]


@dataclass
class JIntArray(JArray):
    """Java int[] array."""

    def __post_init__(self):
        self.element_type = "I"
        self.class_name = "[I"
        self._element_size = 4
        if not self._data:
            self._data = bytes(self.length * 4)

    def get(self, index: int) -> int:
        """Get element at index."""
        if 0 <= index < self.length:
            offset = index * 4
            return struct.unpack('<i', self._data[offset:offset+4])[0]
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: int) -> None:
        """Set element at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            offset = index * 4
            struct.pack_into('<i', data, offset, value)
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_list(self) -> list[int]:
        """Convert to Python list."""
        return list(struct.unpack(f'<{self.length}i', self._data))


@dataclass
class JLongArray(JArray):
    """Java long[] array."""

    def __post_init__(self):
        self.element_type = "J"
        self.class_name = "[J"
        self._element_size = 8
        if not self._data:
            self._data = bytes(self.length * 8)

    def get(self, index: int) -> int:
        """Get element at index."""
        if 0 <= index < self.length:
            offset = index * 8
            return struct.unpack('<q', self._data[offset:offset+8])[0]
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: int) -> None:
        """Set element at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            offset = index * 8
            struct.pack_into('<q', data, offset, value)
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_list(self) -> list[int]:
        """Convert to Python list."""
        return list(struct.unpack(f'<{self.length}q', self._data))


@dataclass
class JFloatArray(JArray):
    """Java float[] array."""

    def __post_init__(self):
        self.element_type = "F"
        self.class_name = "[F"
        self._element_size = 4
        if not self._data:
            self._data = bytes(self.length * 4)

    def get(self, index: int) -> float:
        """Get element at index."""
        if 0 <= index < self.length:
            offset = index * 4
            return struct.unpack('<f', self._data[offset:offset+4])[0]
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: float) -> None:
        """Set element at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            offset = index * 4
            struct.pack_into('<f', data, offset, value)
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_list(self) -> list[float]:
        """Convert to Python list."""
        return list(struct.unpack(f'<{self.length}f', self._data))


@dataclass
class JDoubleArray(JArray):
    """Java double[] array."""

    def __post_init__(self):
        self.element_type = "D"
        self.class_name = "[D"
        self._element_size = 8
        if not self._data:
            self._data = bytes(self.length * 8)

    def get(self, index: int) -> float:
        """Get element at index."""
        if 0 <= index < self.length:
            offset = index * 8
            return struct.unpack('<d', self._data[offset:offset+8])[0]
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, value: float) -> None:
        """Set element at index."""
        if 0 <= index < self.length:
            data = bytearray(self._data)
            offset = index * 8
            struct.pack_into('<d', data, offset, value)
            self._data = bytes(data)
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def to_list(self) -> list[float]:
        """Convert to Python list."""
        return list(struct.unpack(f'<{self.length}d', self._data))


@dataclass
class JObjectArray(JArray):
    """Java Object[] array."""

    elements: list[int] = field(default_factory=list)  # List of object handles
    component_class: str = "java/lang/Object"

    def __post_init__(self):
        self.element_type = f"L{self.component_class};"
        self.class_name = f"[L{self.component_class};"
        self._element_size = 4  # Object references are 4 bytes in our impl
        if not self.elements:
            self.elements = [0] * self.length  # NULL references

    def get(self, index: int) -> int:
        """Get object handle at index."""
        if 0 <= index < self.length:
            return self.elements[index]
        raise IndexError(f"Index {index} out of bounds for length {self.length}")

    def set(self, index: int, handle: int) -> None:
        """Set object handle at index."""
        if 0 <= index < self.length:
            self.elements[index] = handle
        else:
            raise IndexError(f"Index {index} out of bounds for length {self.length}")


@dataclass
class JWeak:
    """Represents a weak global reference."""

    handle: int
    target: int  # Handle to the referenced object
    is_valid: bool = True

    def get(self) -> int:
        """Get the target object handle, or 0 if collected."""
        return self.target if self.is_valid else 0

    def clear(self) -> None:
        """Clear the weak reference (simulating GC)."""
        self.is_valid = False
        self.target = 0


@dataclass
class JDirectBuffer(JObject):
    """Represents a direct ByteBuffer."""

    address: int = 0
    capacity: int = 0

    def __post_init__(self):
        self.class_name = "java/nio/DirectByteBuffer"


@dataclass
class JMethodID:
    """Represents a method ID."""

    id: int
    class_name: str
    name: str
    signature: str
    is_static: bool = False
    native_ptr: int = 0  # If registered as native


@dataclass
class JFieldID:
    """Represents a field ID."""

    id: int
    class_name: str
    name: str
    signature: str
    is_static: bool = False
    offset: int = 0  # Offset within object fields
