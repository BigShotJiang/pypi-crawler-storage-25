"""
Full JNI (Java Native Interface) implementation.

Provides all ~230 JNI functions for native Android library emulation.
"""

from .constants import (
    JNI_ABORT,
    JNI_COMMIT,
    JNI_EDETACHED,
    JNI_EEXIST,
    JNI_EINVAL,
    JNI_ENOMEM,
    JNI_ERR,
    JNI_EVERSION,
    JNI_FALSE,
    JNI_OK,
    JNI_TRUE,
    JNI_VERSION_1_1,
    JNI_VERSION_1_2,
    JNI_VERSION_1_4,
    JNI_VERSION_1_6,
    JNI_VERSION_1_8,
    JNI_VERSION_9,
    JNI_VERSION_10,
)
from .env import JNIEnv
from .types import (
    JArray,
    JBooleanArray,
    JByteArray,
    JCharArray,
    JClass,
    JDoubleArray,
    JFloatArray,
    JIntArray,
    JLongArray,
    JObject,
    JObjectArray,
    JShortArray,
    JString,
    JThrowable,
    JWeak,
)
from .vm import JavaVM

__all__ = [
    # Main classes
    "JNIEnv",
    "JavaVM",
    # Types
    "JObject",
    "JString",
    "JClass",
    "JArray",
    "JBooleanArray",
    "JByteArray",
    "JCharArray",
    "JShortArray",
    "JIntArray",
    "JLongArray",
    "JFloatArray",
    "JDoubleArray",
    "JObjectArray",
    "JThrowable",
    "JWeak",
    # Constants
    "JNI_VERSION_1_1",
    "JNI_VERSION_1_2",
    "JNI_VERSION_1_4",
    "JNI_VERSION_1_6",
    "JNI_VERSION_1_8",
    "JNI_VERSION_9",
    "JNI_VERSION_10",
    "JNI_OK",
    "JNI_ERR",
    "JNI_EDETACHED",
    "JNI_EVERSION",
    "JNI_ENOMEM",
    "JNI_EEXIST",
    "JNI_EINVAL",
    "JNI_FALSE",
    "JNI_TRUE",
    "JNI_COMMIT",
    "JNI_ABORT",
]
