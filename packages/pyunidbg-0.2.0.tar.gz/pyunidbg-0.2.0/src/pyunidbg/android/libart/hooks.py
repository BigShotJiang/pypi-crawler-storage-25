"""
ART hooks for intercepting Java layer operations.

Provides a hook registry for monitoring and modifying
Java runtime behavior.
"""

from __future__ import annotations

import fnmatch
import logging
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .events import ArtEvent
    from .runtime import ArtRuntime

logger = logging.getLogger(__name__)


class HookType(Enum):
    """Types of ART hooks."""
    # Method hooks
    METHOD_ENTER = auto()
    METHOD_EXIT = auto()

    # Field hooks
    FIELD_READ = auto()
    FIELD_WRITE = auto()

    # Class hooks
    CLASS_LOAD = auto()
    CLASS_INIT = auto()

    # Object hooks
    OBJECT_ALLOC = auto()
    OBJECT_FREE = auto()

    # Exception hooks
    EXCEPTION_THROW = auto()
    EXCEPTION_CATCH = auto()

    # Thread hooks
    THREAD_START = auto()
    THREAD_END = auto()

    # All events
    ALL = auto()


@dataclass
class Hook:
    """A registered hook."""
    hook_type: HookType
    callback: Callable[[ArtEvent], Any | None]
    pattern: str = "*"  # Class/method pattern to match
    enabled: bool = True
    priority: int = 0  # Higher priority = called first
    name: str = ""

    def matches(self, target: str) -> bool:
        """Check if this hook matches the target."""
        return fnmatch.fnmatch(target, self.pattern)


class ArtHooks:
    """
    Hook registry for ART events.
    
    Provides an API for registering callbacks on Java layer events.
    """

    def __init__(self, runtime: ArtRuntime):
        self._runtime = runtime
        self._hooks: dict[HookType, list[Hook]] = {t: [] for t in HookType}
        self._next_id = 1
        self._hook_by_id: dict[int, Hook] = {}

    def on_method_enter(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """
        Register a hook for method entry.
        
        Can be used as decorator:
            @hooks.on_method_enter("com.example.MyClass.*")
            def on_my_class_method(event):
                print(f"Called: {event.method_name}")
        
        Or directly:
            hooks.on_method_enter("*", my_callback)
        
        Args:
            pattern: Glob pattern to match class.method names
            callback: Callback function (or use as decorator)
            priority: Higher = called first
            name: Optional name for this hook
        
        Returns:
            Hook ID if callback provided, else decorator
        """
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.METHOD_ENTER, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_method_exit(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for method exit."""
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.METHOD_EXIT, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_field_read(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for field reads."""
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.FIELD_READ, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_field_write(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for field writes."""
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.FIELD_WRITE, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_class_load(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for class loading."""
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.CLASS_LOAD, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_class_init(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for class initialization."""
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.CLASS_INIT, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_object_alloc(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for object allocation."""
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.OBJECT_ALLOC, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_exception(
        self,
        pattern: str = "*",
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for exceptions."""
        def register(cb: Callable) -> int:
            self._register_hook(HookType.EXCEPTION_THROW, cb, pattern, priority, name)
            return self._register_hook(HookType.EXCEPTION_CATCH, cb, pattern, priority, name)

        if callback:
            return register(callback)
        return register

    def on_thread(
        self,
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for thread events."""
        def register(cb: Callable) -> int:
            self._register_hook(HookType.THREAD_START, cb, "*", priority, name)
            return self._register_hook(HookType.THREAD_END, cb, "*", priority, name)

        if callback:
            return register(callback)
        return register

    def on_all(
        self,
        callback: Callable | None = None,
        priority: int = 0,
        name: str = "",
    ) -> int | Callable:
        """Register a hook for all events."""
        def register(cb: Callable) -> int:
            return self._register_hook(HookType.ALL, cb, "*", priority, name)

        if callback:
            return register(callback)
        return register

    def _register_hook(
        self,
        hook_type: HookType,
        callback: Callable,
        pattern: str,
        priority: int,
        name: str,
    ) -> int:
        """Register a hook and return its ID."""
        hook_id = self._next_id
        self._next_id += 1

        hook = Hook(
            hook_type=hook_type,
            callback=callback,
            pattern=pattern,
            priority=priority,
            name=name or f"hook_{hook_id}",
        )

        self._hooks[hook_type].append(hook)
        self._hooks[hook_type].sort(key=lambda h: -h.priority)  # Descending priority
        self._hook_by_id[hook_id] = hook

        logger.debug(f"Registered {hook_type.name} hook: {hook.name} pattern={pattern}")
        return hook_id

    def remove_hook(self, hook_id: int) -> bool:
        """Remove a hook by ID."""
        hook = self._hook_by_id.pop(hook_id, None)
        if hook:
            self._hooks[hook.hook_type].remove(hook)
            return True
        return False

    def enable_hook(self, hook_id: int) -> bool:
        """Enable a hook."""
        hook = self._hook_by_id.get(hook_id)
        if hook:
            hook.enabled = True
            return True
        return False

    def disable_hook(self, hook_id: int) -> bool:
        """Disable a hook."""
        hook = self._hook_by_id.get(hook_id)
        if hook:
            hook.enabled = False
            return True
        return False

    def fire(self, event: ArtEvent, target: str = "") -> list[Any]:
        """
        Fire an event to all matching hooks.
        
        Args:
            event: The ART event
            target: Target identifier (e.g., "com.example.Class.method")
        
        Returns:
            List of callback results
        """
        results = []

        # Map event type to hook types
        from .events import EventType
        hook_type_map = {
            EventType.METHOD_ENTER: HookType.METHOD_ENTER,
            EventType.METHOD_EXIT: HookType.METHOD_EXIT,
            EventType.FIELD_READ: HookType.FIELD_READ,
            EventType.FIELD_WRITE: HookType.FIELD_WRITE,
            EventType.CLASS_LOAD: HookType.CLASS_LOAD,
            EventType.CLASS_INIT: HookType.CLASS_INIT,
            EventType.OBJECT_ALLOC: HookType.OBJECT_ALLOC,
            EventType.OBJECT_FREE: HookType.OBJECT_FREE,
            EventType.EXCEPTION_THROW: HookType.EXCEPTION_THROW,
            EventType.EXCEPTION_CATCH: HookType.EXCEPTION_CATCH,
            EventType.THREAD_START: HookType.THREAD_START,
            EventType.THREAD_END: HookType.THREAD_END,
        }

        hook_type = hook_type_map.get(event.event_type)

        # Fire specific hooks
        if hook_type:
            for hook in self._hooks[hook_type]:
                if hook.enabled and hook.matches(target):
                    try:
                        result = hook.callback(event)
                        results.append(result)
                    except Exception as e:
                        logger.error(f"Hook {hook.name} error: {e}")

        # Fire ALL hooks
        for hook in self._hooks[HookType.ALL]:
            if hook.enabled:
                try:
                    result = hook.callback(event)
                    results.append(result)
                except Exception as e:
                    logger.error(f"Hook {hook.name} error: {e}")

        return results

    def list_hooks(self) -> list[dict]:
        """List all registered hooks."""
        return [
            {
                'id': hook_id,
                'type': hook.hook_type.name,
                'pattern': hook.pattern,
                'name': hook.name,
                'enabled': hook.enabled,
                'priority': hook.priority,
            }
            for hook_id, hook in self._hook_by_id.items()
        ]

    def clear_hooks(self, hook_type: HookType | None = None) -> int:
        """Clear hooks, optionally by type. Returns count removed."""
        count = 0
        if hook_type:
            count = len(self._hooks[hook_type])
            for hook in self._hooks[hook_type]:
                # Find and remove from _hook_by_id
                for hid, h in list(self._hook_by_id.items()):
                    if h is hook:
                        del self._hook_by_id[hid]
            self._hooks[hook_type].clear()
        else:
            count = len(self._hook_by_id)
            self._hooks = {t: [] for t in HookType}
            self._hook_by_id.clear()
        return count


class MethodReplacer:
    """
    Utility for replacing method implementations.
    
    Allows completely replacing Java method behavior with
    custom Python implementations.
    """

    def __init__(self, hooks: ArtHooks):
        self._hooks = hooks
        self._replacements: dict[str, Callable] = {}

    def replace(
        self,
        class_name: str,
        method_name: str,
        signature: str = "",
        impl: Callable | None = None,
    ) -> Callable:
        """
        Replace a method implementation.
        
        Can be used as decorator:
            @replacer.replace("com.example.Class", "method", "(II)I")
            def my_impl(self, a, b):
                return a + b
        """
        key = f"{class_name}.{method_name}{signature}"

        def register(fn: Callable) -> Callable:
            self._replacements[key] = fn
            return fn

        if impl:
            return register(impl)
        return register

    def get_replacement(self, class_name: str, method_name: str, signature: str = "") -> Callable | None:
        """Get replacement for a method, if any."""
        key = f"{class_name}.{method_name}{signature}"
        if key in self._replacements:
            return self._replacements[key]

        # Try without signature
        key_no_sig = f"{class_name}.{method_name}"
        return self._replacements.get(key_no_sig)

    def remove_replacement(self, class_name: str, method_name: str, signature: str = "") -> bool:
        """Remove a method replacement."""
        key = f"{class_name}.{method_name}{signature}"
        if key in self._replacements:
            del self._replacements[key]
            return True
        return False
