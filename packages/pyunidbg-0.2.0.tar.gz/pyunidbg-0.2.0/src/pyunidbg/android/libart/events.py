"""
ART event types for Java layer monitoring.

Provides dataclasses for all interceptable ART events.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


class EventType(Enum):
    """Types of ART events."""
    CLASS_LOAD = auto()
    CLASS_INIT = auto()
    METHOD_ENTER = auto()
    METHOD_EXIT = auto()
    FIELD_READ = auto()
    FIELD_WRITE = auto()
    OBJECT_ALLOC = auto()
    OBJECT_FREE = auto()
    THREAD_START = auto()
    THREAD_END = auto()
    EXCEPTION_THROW = auto()
    EXCEPTION_CATCH = auto()
    GC_START = auto()
    GC_END = auto()
    DEX_LOAD = auto()
    JIT_COMPILE = auto()
    NATIVE_BIND = auto()


@dataclass
class ArtEvent:
    """Base class for all ART events."""
    event_type: EventType = field(default=EventType.CLASS_LOAD)
    timestamp: float = field(default_factory=time.time)
    thread_id: int = 0

    def __str__(self) -> str:
        return f"[{self.event_type.name}] thread={self.thread_id}"


@dataclass
class ClassLoadEvent(ArtEvent):
    """Event fired when a class is loaded."""
    class_name: str = ""
    class_loader: int = 0
    dex_file: str = ""
    event_type: EventType = field(default=EventType.CLASS_LOAD)

    def __str__(self) -> str:
        return f"[CLASS_LOAD] {self.class_name} from {self.dex_file}"


@dataclass
class ClassInitEvent(ArtEvent):
    """Event fired when a class is initialized."""
    class_name: str = ""
    success: bool = True
    event_type: EventType = field(default=EventType.CLASS_INIT)

    def __str__(self) -> str:
        status = "OK" if self.success else "FAILED"
        return f"[CLASS_INIT] {self.class_name} -> {status}"


@dataclass
class MethodEnterEvent(ArtEvent):
    """Event fired when entering a method."""
    class_name: str = ""
    method_name: str = ""
    signature: str = ""
    args: list[Any] = field(default_factory=list)
    is_native: bool = False
    is_static: bool = False
    caller_pc: int = 0
    event_type: EventType = field(default=EventType.METHOD_ENTER)

    def __str__(self) -> str:
        native = " (native)" if self.is_native else ""
        static = " static" if self.is_static else ""
        return f"[METHOD_ENTER]{native}{static} {self.class_name}.{self.method_name}{self.signature}"


@dataclass
class MethodExitEvent(ArtEvent):
    """Event fired when exiting a method."""
    class_name: str = ""
    method_name: str = ""
    signature: str = ""
    return_value: Any = None
    exception: str | None = None
    is_native: bool = False
    event_type: EventType = field(default=EventType.METHOD_EXIT)

    def __str__(self) -> str:
        if self.exception:
            return f"[METHOD_EXIT] {self.class_name}.{self.method_name} threw {self.exception}"
        return f"[METHOD_EXIT] {self.class_name}.{self.method_name} -> {self.return_value}"


@dataclass
class FieldReadEvent(ArtEvent):
    """Event fired when reading a field."""
    class_name: str = ""
    field_name: str = ""
    field_type: str = ""
    object_ref: int = 0
    value: Any = None
    is_static: bool = False
    event_type: EventType = field(default=EventType.FIELD_READ)

    def __str__(self) -> str:
        static = "static " if self.is_static else ""
        return f"[FIELD_READ] {static}{self.class_name}.{self.field_name} = {self.value}"


@dataclass
class FieldWriteEvent(ArtEvent):
    """Event fired when writing to a field."""
    class_name: str = ""
    field_name: str = ""
    field_type: str = ""
    object_ref: int = 0
    old_value: Any = None
    new_value: Any = None
    is_static: bool = False
    event_type: EventType = field(default=EventType.FIELD_WRITE)

    def __str__(self) -> str:
        static = "static " if self.is_static else ""
        return f"[FIELD_WRITE] {static}{self.class_name}.{self.field_name}: {self.old_value} -> {self.new_value}"


@dataclass
class ObjectAllocEvent(ArtEvent):
    """Event fired when an object is allocated."""
    class_name: str = ""
    object_ref: int = 0
    size: int = 0
    is_array: bool = False
    array_length: int = 0
    event_type: EventType = field(default=EventType.OBJECT_ALLOC)

    def __str__(self) -> str:
        if self.is_array:
            return f"[OBJECT_ALLOC] {self.class_name}[{self.array_length}] @ 0x{self.object_ref:x} ({self.size} bytes)"
        return f"[OBJECT_ALLOC] {self.class_name} @ 0x{self.object_ref:x} ({self.size} bytes)"


@dataclass
class ObjectFreeEvent(ArtEvent):
    """Event fired when an object is garbage collected."""
    class_name: str = ""
    object_ref: int = 0
    event_type: EventType = field(default=EventType.OBJECT_FREE)

    def __str__(self) -> str:
        return f"[OBJECT_FREE] {self.class_name} @ 0x{self.object_ref:x}"


@dataclass
class ThreadEvent(ArtEvent):
    """Event fired on thread start/end."""
    thread_name: str = ""
    is_daemon: bool = False
    is_start: bool = True
    event_type: EventType = field(default=EventType.THREAD_START)

    def __str__(self) -> str:
        action = "START" if self.is_start else "END"
        daemon = " (daemon)" if self.is_daemon else ""
        return f"[THREAD_{action}] {self.thread_name}{daemon} id={self.thread_id}"


@dataclass
class ExceptionEvent(ArtEvent):
    """Event fired when an exception is thrown/caught."""
    exception_class: str = ""
    message: str = ""
    is_throw: bool = True
    catch_location: str | None = None
    stack_trace: list[str] = field(default_factory=list)
    event_type: EventType = field(default=EventType.EXCEPTION_THROW)

    def __str__(self) -> str:
        action = "THROW" if self.is_throw else "CATCH"
        return f"[EXCEPTION_{action}] {self.exception_class}: {self.message}"


@dataclass
class GCEvent(ArtEvent):
    """Event fired on garbage collection."""
    gc_reason: str = ""
    is_start: bool = True
    freed_objects: int = 0
    freed_bytes: int = 0
    duration_ms: float = 0.0
    event_type: EventType = field(default=EventType.GC_START)

    def __str__(self) -> str:
        if self.is_start:
            return f"[GC_START] reason={self.gc_reason}"
        return f"[GC_END] freed {self.freed_objects} objects ({self.freed_bytes} bytes) in {self.duration_ms:.2f}ms"


@dataclass
class DexLoadEvent(ArtEvent):
    """Event fired when a DEX file is loaded."""
    dex_path: str = ""
    dex_base: int = 0
    dex_size: int = 0
    class_count: int = 0
    from_memory: bool = False
    event_type: EventType = field(default=EventType.DEX_LOAD)

    def __str__(self) -> str:
        source = "memory" if self.from_memory else self.dex_path
        return f"[DEX_LOAD] {source} @ 0x{self.dex_base:x} ({self.class_count} classes)"


@dataclass
class JitCompileEvent(ArtEvent):
    """Event fired when a method is JIT compiled."""
    class_name: str = ""
    method_name: str = ""
    signature: str = ""
    code_address: int = 0
    code_size: int = 0
    event_type: EventType = field(default=EventType.JIT_COMPILE)

    def __str__(self) -> str:
        return f"[JIT_COMPILE] {self.class_name}.{self.method_name} @ 0x{self.code_address:x}"


@dataclass
class NativeBindEvent(ArtEvent):
    """Event fired when a native method is bound to its implementation."""
    class_name: str = ""
    method_name: str = ""
    signature: str = ""
    native_address: int = 0
    library_name: str = ""
    event_type: EventType = field(default=EventType.NATIVE_BIND)

    def __str__(self) -> str:
        return f"[NATIVE_BIND] {self.class_name}.{self.method_name} -> 0x{self.native_address:x} ({self.library_name})"
