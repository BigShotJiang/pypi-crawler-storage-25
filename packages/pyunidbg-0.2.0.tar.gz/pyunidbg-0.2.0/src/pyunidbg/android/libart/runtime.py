"""
Fake libart.so runtime implementation.

Provides a simulated ART (Android Runtime) that intercepts and monitors
Java layer events during native code emulation.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .classes import ArtClass, create_java_lang_classes
from .dex import DexFile
from .events import (
    ArtEvent,
    ClassInitEvent,
    ClassLoadEvent,
    DexLoadEvent,
    EventType,
    ExceptionEvent,
    FieldReadEvent,
    FieldWriteEvent,
    GCEvent,
    JitCompileEvent,
    MethodEnterEvent,
    MethodExitEvent,
    NativeBindEvent,
    ObjectAllocEvent,
    ObjectFreeEvent,
    ThreadEvent,
)
from .hooks import ArtHooks, MethodReplacer

if TYPE_CHECKING:
    from pyunidbg.android.emulator import AndroidEmulator

logger = logging.getLogger(__name__)


@dataclass
class ArtThread:
    """Represents an ART thread."""
    id: int
    name: str = "main"
    is_daemon: bool = False
    state: str = "Runnable"  # Runnable, Waiting, Blocked, etc.
    native_thread: int = 0

    # Current execution context
    current_class: str | None = None
    current_method: str | None = None
    call_stack: list[tuple[str, str]] = field(default_factory=list)  # [(class, method), ...]


class ArtRuntime:
    """
    Fake ART runtime for intercepting Java layer events.
    
    This provides a simulated libart.so that allows monitoring:
    - Class loading and initialization
    - Method invocation
    - Field access
    - Object lifecycle
    - Exception handling
    - GC events
    
    Example:
        emulator = AndroidEmulator()
        art = emulator.art  # or ArtRuntime(emulator)
        
        # Register hooks
        @art.hooks.on_method_enter("com.example.*")
        def on_enter(event):
            print(f"Entering: {event.class_name}.{event.method_name}")
        
        # Load library and run
        emulator.load_library("libnative.so")
        result = emulator.call_jni("Java_com_example_Native_method")
    """

    # libart.so exported symbols we provide
    EXPORTED_SYMBOLS = [
        # Runtime
        "_ZN3art7Runtime8instanceE",  # art::Runtime::instance_
        "_ZN3art7Runtime9instance_E",
        "_ZN3art7Runtime13CreateRuntimeEPNS_15RuntimeArgumentsE",

        # JNI
        "_ZN3art9JNIEnvExt6CreateEPNS_6ThreadEPNS_7JavaVMExtE",
        "_ZN3art10JavaVMExt6CreateEPNS_7RuntimeE",

        # Class loading
        "_ZN3art11ClassLinker9FindClassEPNS_6ThreadEPKcNS_6HandleINS_6mirror11ClassLoaderEEE",
        "_ZN3art11ClassLinker15DefineClassOldEPNS_6ThreadEPKcjNS_6HandleINS_6mirror11ClassLoaderEEERKNS_6DexFileERKNS9_8ClassDefE",
        "_ZN3art11ClassLinker20InitializeClassFromCodeEPNS_6ThreadENS_6HandleINS_6mirror5ClassEEE",

        # Method invocation
        "_ZN3art9ArtMethod6InvokeEPNS_6ThreadEPjjPNS_6JValueEPKc",
        "_ZN3art11interpreter7ExecuteEPNS_6ThreadERKNS_20CodeItemDataAccessorERNS_11ShadowFrameENS_6JValueEb",

        # JIT
        "_ZN3art3jit3Jit7CompileEPNS_9ArtMethodEPNS_6ThreadEb",
        "_ZN3art3jit8JitCodeCache15AddCompiledCodeEPNS_9ArtMethodE",

        # GC
        "_ZN3art2gc4Heap13CollectGarbageEb",
        "_ZN3art2gc4Heap11AllocObjectILb1EEEPNS_6mirror6ObjectEPNS_6ThreadE",

        # Exceptions
        "_ZN3art6Thread15SetExceptionEPNS_6mirror6ThrowableE",
        "_ZN3art6Thread15ClearExceptionEv",

        # Field access
        "_ZN3art8ArtField13GetObjectEPNS_6mirror6ObjectE",
        "_ZN3art8ArtField13SetObjectEPNS_6mirror6ObjectES3_",

        # DEX
        "_ZN3art7DexFile10OpenFromFdEiPKcS2_RKSt6vectorIhSaIhEEPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE",
        "_ZN3art7DexFile14OpenFromMemoryEPKhjS2_S2_RKSt6vectorIhSaIhEEPNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE",
    ]

    def __init__(self, emulator: AndroidEmulator):
        """
        Initialize ART runtime.
        
        Args:
            emulator: AndroidEmulator instance
        """
        self._emulator = emulator

        # Event management
        self._hooks = ArtHooks(self)
        self._method_replacer = MethodReplacer(self._hooks)
        self._events: list[ArtEvent] = []
        self._event_callbacks: list[Callable[[ArtEvent], None]] = []

        # Class registry
        self._classes: dict[str, ArtClass] = {}
        self._classes_by_jclass: dict[int, ArtClass] = {}

        # Thread management
        self._threads: dict[int, ArtThread] = {1: ArtThread(id=1, name="main")}
        self._current_thread_id = 1

        # Object tracking
        self._objects: dict[int, str] = {}  # ref -> class_name
        self._next_object_id = 0x10000000

        # DEX files
        self._dex_files: list[DexFile] = []

        # Statistics
        self._stats = {
            'classes_loaded': 0,
            'methods_invoked': 0,
            'objects_allocated': 0,
            'exceptions_thrown': 0,
            'gc_runs': 0,
        }

        # Setup initial classes
        self._setup_core_classes()

        # Setup libart hooks
        self._setup_libart_hooks()

        logger.info("ArtRuntime initialized")

    @property
    def hooks(self) -> ArtHooks:
        """Get the hook registry."""
        return self._hooks

    @property
    def method_replacer(self) -> MethodReplacer:
        """Get the method replacer."""
        return self._method_replacer

    @property
    def classes(self) -> dict[str, ArtClass]:
        """Get all loaded classes."""
        return self._classes

    @property
    def events(self) -> list[ArtEvent]:
        """Get recorded events."""
        return self._events

    @property
    def stats(self) -> dict[str, int]:
        """Get runtime statistics."""
        return self._stats

    def _setup_core_classes(self) -> None:
        """Setup core Java classes."""
        for art_class in create_java_lang_classes():
            self._register_class(art_class)

    def _register_class(self, art_class: ArtClass) -> int:
        """Register a class and return its jclass reference."""
        self._classes[art_class.name] = art_class

        # Allocate jclass reference
        jclass = self._allocate_object(art_class.name, is_class=True)
        art_class._jclass = jclass
        self._classes_by_jclass[jclass] = art_class

        return jclass

    def _allocate_object(self, class_name: str, is_class: bool = False) -> int:
        """Allocate an object reference."""
        ref = self._next_object_id
        self._next_object_id += 8
        self._objects[ref] = class_name
        return ref

    def _setup_libart_hooks(self) -> None:
        """Setup hooks for libart.so functions."""
        # Add libart symbol hooks to the loader
        for symbol in self.EXPORTED_SYMBOLS:
            try:
                addr = self._emulator.loader.add_symbol_hook(symbol, self._libart_handler)
                self._write_ret_stub(addr)
            except Exception as e:
                logger.debug(f"Could not hook {symbol}: {e}")

    def _write_ret_stub(self, addr: int) -> None:
        """Write a return instruction at address."""
        try:
            from pyunidbg.core.constants import Architecture
            if self._emulator.arch == Architecture.ARM64:
                self._emulator.memory.write(addr, b"\xC0\x03\x5F\xD6")  # RET
            else:
                self._emulator.memory.write(addr, b"\x1E\xFF\x2F\xE1")  # BX LR
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

    def _libart_handler(self, *args) -> int:
        """Generic handler for libart functions."""
        # This is called when native code calls libart functions
        return 0

    def _fire_event(self, event: ArtEvent) -> None:
        """Fire an event to all registered handlers."""
        self._events.append(event)

        # Determine target for pattern matching
        target = ""
        if hasattr(event, 'class_name') and hasattr(event, 'method_name'):
            target = f"{event.class_name}.{event.method_name}"
        elif hasattr(event, 'class_name'):
            target = event.class_name

        # Fire to hook registry
        self._hooks.fire(event, target)

        # Fire to event callbacks
        for callback in self._event_callbacks:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"Event callback error: {e}")

    def add_event_callback(self, callback: Callable[[ArtEvent], None]) -> None:
        """Add a callback for all events."""
        self._event_callbacks.append(callback)

    def remove_event_callback(self, callback: Callable[[ArtEvent], None]) -> None:
        """Remove an event callback."""
        if callback in self._event_callbacks:
            self._event_callbacks.remove(callback)

    # ==================== Class Operations ====================

    def find_class(self, name: str) -> ArtClass | None:
        """
        Find a class by name.
        
        Supports various name formats:
        - Java: "java.lang.String"
        - JNI: "Ljava/lang/String;"
        - Simple: "String"
        """
        # Try exact match
        if name in self._classes:
            return self._classes[name]

        # Try JNI format
        jni_name = f"L{name.replace('.', '/')};"
        if jni_name in self._classes:
            return self._classes[jni_name]

        # Try Java format
        for cls_name, cls in self._classes.items():
            if cls.java_name == name or cls.simple_name == name:
                return cls

        return None

    def load_class(self, name: str, dex_file: str | None = None) -> ArtClass | None:
        """
        Load a class by name.
        
        This simulates class loading and fires ClassLoadEvent.
        """
        # Check if already loaded
        existing = self.find_class(name)
        if existing:
            return existing

        # Create minimal class
        jni_name = name if name.startswith('L') else f"L{name.replace('.', '/')};"
        art_class = ArtClass(name=jni_name, dex_file=dex_file)
        self._register_class(art_class)

        # Fire event
        self._stats['classes_loaded'] += 1
        event = ClassLoadEvent(
            class_name=art_class.java_name,
            dex_file=dex_file or "",
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

        return art_class

    def init_class(self, art_class: ArtClass) -> bool:
        """
        Initialize a class (run static initializer).
        
        Returns True on success.
        """
        if art_class.status == "Initialized":
            return True

        art_class.status = "Initializing"

        # Fire event
        event = ClassInitEvent(
            class_name=art_class.java_name,
            success=True,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

        art_class.status = "Initialized"
        return True

    # ==================== Method Operations ====================

    def invoke_method(
        self,
        art_class: ArtClass,
        method_name: str,
        signature: str = "",
        this_obj: int = 0,
        args: list[Any] = None,
    ) -> Any:
        """
        Invoke a Java method.
        
        This simulates method invocation and fires MethodEnter/Exit events.
        """
        args = args or []
        method = art_class.get_method(method_name, signature)

        is_static = not this_obj or (method and method.is_static)
        is_native = method and method.is_native if method else False

        # Fire enter event
        enter_event = MethodEnterEvent(
            class_name=art_class.java_name,
            method_name=method_name,
            signature=signature or (method.signature if method else "()V"),
            args=args,
            is_native=is_native,
            is_static=is_static,
            thread_id=self._current_thread_id,
        )
        self._fire_event(enter_event)

        self._stats['methods_invoked'] += 1

        # Check for replacement
        replacement = self._method_replacer.get_replacement(art_class.java_name, method_name, signature)

        result = None
        exception = None

        if replacement:
            try:
                result = replacement(*args)
            except Exception as e:
                exception = str(e)
        elif method and method._handler:
            try:
                result = method._handler(*args)
            except Exception as e:
                exception = str(e)

        # Fire exit event
        exit_event = MethodExitEvent(
            class_name=art_class.java_name,
            method_name=method_name,
            signature=signature or (method.signature if method else "()V"),
            return_value=result,
            exception=exception,
            is_native=is_native,
            thread_id=self._current_thread_id,
        )
        self._fire_event(exit_event)

        return result

    # ==================== Field Operations ====================

    def get_field(
        self,
        art_class: ArtClass,
        field_name: str,
        obj_ref: int = 0,
    ) -> Any:
        """
        Get a field value.
        
        Fires FieldReadEvent.
        """
        field_obj = art_class.get_field(field_name)
        is_static = obj_ref == 0 or (field_obj and field_obj.is_static)

        if is_static:
            value = art_class.get_static_field_value(field_name)
        else:
            value = field_obj._value if field_obj else None

        event = FieldReadEvent(
            class_name=art_class.java_name,
            field_name=field_name,
            field_type=field_obj.type_descriptor if field_obj else "",
            object_ref=obj_ref,
            value=value,
            is_static=is_static,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

        return value

    def set_field(
        self,
        art_class: ArtClass,
        field_name: str,
        value: Any,
        obj_ref: int = 0,
    ) -> None:
        """
        Set a field value.
        
        Fires FieldWriteEvent.
        """
        field_obj = art_class.get_field(field_name)
        is_static = obj_ref == 0 or (field_obj and field_obj.is_static)

        if is_static:
            old_value = art_class.get_static_field_value(field_name)
            art_class.set_static_field_value(field_name, value)
        else:
            old_value = field_obj._value if field_obj else None
            if field_obj:
                field_obj._value = value

        event = FieldWriteEvent(
            class_name=art_class.java_name,
            field_name=field_name,
            field_type=field_obj.type_descriptor if field_obj else "",
            object_ref=obj_ref,
            old_value=old_value,
            new_value=value,
            is_static=is_static,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

    # ==================== Object Operations ====================

    def alloc_object(self, class_name: str, size: int = 0) -> int:
        """
        Allocate a new object.
        
        Fires ObjectAllocEvent.
        """
        art_class = self.find_class(class_name)
        if art_class:
            return art_class.instantiate(self)

        # Create class if not found
        art_class = self.load_class(class_name)
        if art_class:
            return art_class.instantiate(self)

        # Fallback: just allocate reference
        ref = self._allocate_object(class_name)
        self._stats['objects_allocated'] += 1

        event = ObjectAllocEvent(
            class_name=class_name,
            object_ref=ref,
            size=size or 16,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

        return ref

    def free_object(self, obj_ref: int) -> None:
        """
        Free an object (simulate GC).
        
        Fires ObjectFreeEvent.
        """
        class_name = self._objects.pop(obj_ref, "Unknown")

        event = ObjectFreeEvent(
            class_name=class_name,
            object_ref=obj_ref,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

    # ==================== Exception Operations ====================

    def throw_exception(self, exception_class: str, message: str = "") -> None:
        """
        Throw an exception.
        
        Fires ExceptionEvent.
        """
        self._stats['exceptions_thrown'] += 1

        # Get current call stack
        thread = self._threads.get(self._current_thread_id)
        stack_trace = []
        if thread:
            for cls, method in thread.call_stack:
                stack_trace.append(f"  at {cls}.{method}")

        event = ExceptionEvent(
            exception_class=exception_class,
            message=message,
            is_throw=True,
            stack_trace=stack_trace,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

    def catch_exception(self, exception_class: str, catch_location: str = "") -> None:
        """
        Catch an exception.
        
        Fires ExceptionEvent.
        """
        event = ExceptionEvent(
            exception_class=exception_class,
            message="",
            is_throw=False,
            catch_location=catch_location,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

    # ==================== Thread Operations ====================

    def start_thread(self, name: str, is_daemon: bool = False) -> int:
        """
        Start a new thread.
        
        Fires ThreadEvent.
        """
        thread_id = max(self._threads.keys()) + 1 if self._threads else 1
        thread = ArtThread(id=thread_id, name=name, is_daemon=is_daemon)
        self._threads[thread_id] = thread

        event = ThreadEvent(
            thread_name=name,
            is_daemon=is_daemon,
            is_start=True,
            thread_id=thread_id,
        )
        self._fire_event(event)

        return thread_id

    def end_thread(self, thread_id: int) -> None:
        """
        End a thread.
        
        Fires ThreadEvent.
        """
        thread = self._threads.pop(thread_id, None)
        if thread:
            event = ThreadEvent(
                thread_name=thread.name,
                is_daemon=thread.is_daemon,
                is_start=False,
                thread_id=thread_id,
            )
            self._fire_event(event)

    # ==================== GC Operations ====================

    def run_gc(self, reason: str = "Explicit") -> tuple[int, int]:
        """
        Run garbage collection.
        
        Returns (freed_objects, freed_bytes).
        Fires GCEvent.
        """
        self._stats['gc_runs'] += 1

        # Fire start event
        start_event = GCEvent(
            gc_reason=reason,
            is_start=True,
            thread_id=self._current_thread_id,
        )
        self._fire_event(start_event)

        start_time = time.time()

        # Simulate GC (we don't actually free anything)
        freed_objects = 0
        freed_bytes = 0

        duration_ms = (time.time() - start_time) * 1000

        # Fire end event
        end_event = GCEvent(
            gc_reason=reason,
            is_start=False,
            freed_objects=freed_objects,
            freed_bytes=freed_bytes,
            duration_ms=duration_ms,
            thread_id=self._current_thread_id,
        )
        self._fire_event(end_event)

        return freed_objects, freed_bytes

    # ==================== DEX Operations ====================

    def load_dex(
        self,
        path: str | Path | None = None,
        data: bytes | None = None,
        from_memory: bool = False,
    ) -> DexFile | None:
        """
        Load a DEX file.
        
        Fires DexLoadEvent and ClassLoadEvent for each class.
        """
        try:
            dex = DexFile(path=path, data=data)
            self._dex_files.append(dex)

            # Fire DEX load event
            event = DexLoadEvent(
                dex_path=str(path) if path else "",
                dex_base=0,
                dex_size=len(data) if data else (Path(path).stat().st_size if path else 0),
                class_count=len(dex.classes),
                from_memory=from_memory,
                thread_id=self._current_thread_id,
            )
            self._fire_event(event)

            # Load all classes
            for dex_class in dex.classes:
                art_class = dex_class.to_art_class()
                art_class.dex_file = str(path) if path else "<memory>"
                self._register_class(art_class)

                load_event = ClassLoadEvent(
                    class_name=art_class.java_name,
                    dex_file=art_class.dex_file or "",
                    thread_id=self._current_thread_id,
                )
                self._fire_event(load_event)
                self._stats['classes_loaded'] += 1

            return dex
        except Exception as e:
            logger.error(f"Failed to load DEX: {e}")
            return None

    # ==================== Native Binding ====================

    def bind_native_method(
        self,
        class_name: str,
        method_name: str,
        signature: str,
        native_addr: int,
        library_name: str = "",
    ) -> None:
        """
        Bind a native method to its implementation.
        
        Fires NativeBindEvent.
        """
        art_class = self.find_class(class_name)
        if art_class:
            method = art_class.get_method(method_name, signature)
            if method:
                method.native_entry = native_addr

        event = NativeBindEvent(
            class_name=class_name,
            method_name=method_name,
            signature=signature,
            native_address=native_addr,
            library_name=library_name,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

    # ==================== JIT ====================

    def jit_compile(
        self,
        class_name: str,
        method_name: str,
        signature: str,
        code_addr: int,
        code_size: int,
    ) -> None:
        """
        Record JIT compilation of a method.
        
        Fires JitCompileEvent.
        """
        event = JitCompileEvent(
            class_name=class_name,
            method_name=method_name,
            signature=signature,
            code_address=code_addr,
            code_size=code_size,
            thread_id=self._current_thread_id,
        )
        self._fire_event(event)

    # ==================== Utilities ====================

    def clear_events(self) -> None:
        """Clear recorded events."""
        self._events.clear()

    def get_events_by_type(self, event_type: EventType) -> list[ArtEvent]:
        """Get events filtered by type."""
        return [e for e in self._events if e.event_type == event_type]

    def print_stats(self) -> None:
        """Print runtime statistics."""
        print("\n=== ART Runtime Statistics ===")
        print(f"  Classes loaded:    {self._stats['classes_loaded']}")
        print(f"  Methods invoked:   {self._stats['methods_invoked']}")
        print(f"  Objects allocated: {self._stats['objects_allocated']}")
        print(f"  Exceptions thrown: {self._stats['exceptions_thrown']}")
        print(f"  GC runs:           {self._stats['gc_runs']}")
        print(f"  Events recorded:   {len(self._events)}")

    def print_events(self, limit: int = 50) -> None:
        """Print recent events."""
        print(f"\n=== Recent ART Events (last {min(limit, len(self._events))}) ===")
        for event in self._events[-limit:]:
            print(f"  {event}")

    def dump_classes(self) -> None:
        """Print all loaded classes."""
        print(f"\n=== Loaded Classes ({len(self._classes)}) ===")
        for name, cls in sorted(self._classes.items()):
            method_count = len(cls.methods)
            field_count = len(cls.fields) + len(cls.static_fields)
            print(f"  {cls.java_name}: {method_count} methods, {field_count} fields")
