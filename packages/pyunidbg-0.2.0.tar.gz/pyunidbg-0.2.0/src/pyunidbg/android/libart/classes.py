"""
ART class structures for Java layer emulation.

Provides representations of Java classes, methods, and fields
as they exist in the ART runtime.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntFlag
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .runtime import ArtRuntime

logger = logging.getLogger(__name__)


class AccessFlags(IntFlag):
    """Java access flags for classes, methods, and fields."""
    PUBLIC = 0x0001
    PRIVATE = 0x0002
    PROTECTED = 0x0004
    STATIC = 0x0008
    FINAL = 0x0010
    SYNCHRONIZED = 0x0020
    VOLATILE = 0x0040  # for fields
    BRIDGE = 0x0040    # for methods
    TRANSIENT = 0x0080 # for fields
    VARARGS = 0x0080   # for methods
    NATIVE = 0x0100
    INTERFACE = 0x0200
    ABSTRACT = 0x0400
    STRICT = 0x0800
    SYNTHETIC = 0x1000
    ANNOTATION = 0x2000
    ENUM = 0x4000
    CONSTRUCTOR = 0x10000
    DECLARED_SYNCHRONIZED = 0x20000


@dataclass
class ArtField:
    """
    Represents a Java field in ART.
    
    Mirrors art::ArtField structure.
    """
    declaring_class: str
    name: str
    type_descriptor: str
    access_flags: AccessFlags = AccessFlags(0)
    offset: int = 0  # Instance field offset or static field index

    # Runtime state
    _value: Any = None
    _art_ptr: int = 0  # Pointer to ArtField in emulated memory

    @property
    def is_static(self) -> bool:
        return bool(self.access_flags & AccessFlags.STATIC)

    @property
    def is_final(self) -> bool:
        return bool(self.access_flags & AccessFlags.FINAL)

    @property
    def is_volatile(self) -> bool:
        return bool(self.access_flags & AccessFlags.VOLATILE)

    @property
    def full_name(self) -> str:
        return f"{self.declaring_class}.{self.name}"

    def get_type_size(self) -> int:
        """Get the size of this field's type in bytes."""
        type_sizes = {
            'Z': 1,  # boolean
            'B': 1,  # byte
            'C': 2,  # char
            'S': 2,  # short
            'I': 4,  # int
            'F': 4,  # float
            'J': 8,  # long
            'D': 8,  # double
        }
        if self.type_descriptor.startswith('L') or self.type_descriptor.startswith('['):
            return 8 if True else 4  # Reference size depends on architecture
        return type_sizes.get(self.type_descriptor, 8)


@dataclass
class ArtMethod:
    """
    Represents a Java method in ART.
    
    Mirrors art::ArtMethod structure.
    """
    declaring_class: str
    name: str
    signature: str  # JNI signature like "(II)V"
    access_flags: AccessFlags = AccessFlags(0)
    method_index: int = 0
    vtable_index: int = -1  # -1 for non-virtual methods

    # Code pointers
    entry_point: int = 0  # Entry point from quick compiled code
    native_entry: int = 0  # Native method entry point
    interpreter_entry: int = 0  # Entry point for interpreter

    # Dex info
    dex_method_index: int = 0
    dex_code_offset: int = 0

    # Runtime state
    _art_ptr: int = 0  # Pointer to ArtMethod in emulated memory
    _handler: Callable | None = None  # Python handler for this method

    # Profiling
    invoke_count: int = 0
    total_time_ns: int = 0

    @property
    def is_static(self) -> bool:
        return bool(self.access_flags & AccessFlags.STATIC)

    @property
    def is_native(self) -> bool:
        return bool(self.access_flags & AccessFlags.NATIVE)

    @property
    def is_abstract(self) -> bool:
        return bool(self.access_flags & AccessFlags.ABSTRACT)

    @property
    def is_constructor(self) -> bool:
        return self.name == "<init>" or bool(self.access_flags & AccessFlags.CONSTRUCTOR)

    @property
    def is_static_init(self) -> bool:
        return self.name == "<clinit>"

    @property
    def full_name(self) -> str:
        return f"{self.declaring_class}.{self.name}{self.signature}"

    @property
    def short_name(self) -> str:
        return f"{self.declaring_class.split('/')[-1].rstrip(';')}.{self.name}"

    def parse_signature(self) -> tuple[list[str], str]:
        """Parse JNI signature into parameter types and return type."""
        sig = self.signature
        if not sig.startswith('('):
            return [], 'V'

        params = []
        i = 1
        while i < len(sig) and sig[i] != ')':
            if sig[i] in 'ZBCSIJFD':
                params.append(sig[i])
                i += 1
            elif sig[i] == 'L':
                end = sig.index(';', i)
                params.append(sig[i:end+1])
                i = end + 1
            elif sig[i] == '[':
                # Array type
                start = i
                i += 1
                while i < len(sig) and sig[i] == '[':
                    i += 1
                if sig[i] == 'L':
                    end = sig.index(';', i)
                    params.append(sig[start:end+1])
                    i = end + 1
                else:
                    params.append(sig[start:i+1])
                    i += 1
            else:
                i += 1

        ret_type = sig[i+1:] if i + 1 < len(sig) else 'V'
        return params, ret_type


@dataclass
class ArtClass:
    """
    Represents a Java class in ART.
    
    Mirrors art::mirror::Class structure.
    """
    name: str  # Internal name like "Ljava/lang/String;"
    access_flags: AccessFlags = AccessFlags(0)
    super_class: str | None = None
    interfaces: list[str] = field(default_factory=list)

    # Source info
    source_file: str | None = None
    dex_file: str | None = None
    dex_class_def_index: int = 0

    # Class members
    methods: dict[str, ArtMethod] = field(default_factory=dict)
    fields: dict[str, ArtField] = field(default_factory=dict)
    static_fields: dict[str, ArtField] = field(default_factory=dict)

    # Runtime state
    status: str = "NotReady"  # NotReady, Loaded, Resolved, Verifying, Verified, Initializing, Initialized, Error
    class_loader: int = 0  # Reference to ClassLoader
    _art_ptr: int = 0  # Pointer to art::mirror::Class in emulated memory
    _jclass: int = 0  # jclass reference

    # Static field values
    _static_values: dict[str, Any] = field(default_factory=dict)

    # Object instances
    _instances: list[int] = field(default_factory=list)

    @property
    def java_name(self) -> str:
        """Get Java-style class name (e.g., java.lang.String)."""
        if self.name.startswith('L') and self.name.endswith(';'):
            return self.name[1:-1].replace('/', '.')
        return self.name

    @property
    def simple_name(self) -> str:
        """Get simple class name without package."""
        java_name = self.java_name
        if '.' in java_name:
            return java_name.rsplit('.', 1)[1]
        return java_name

    @property
    def package_name(self) -> str:
        """Get package name."""
        java_name = self.java_name
        if '.' in java_name:
            return java_name.rsplit('.', 1)[0]
        return ""

    @property
    def is_interface(self) -> bool:
        return bool(self.access_flags & AccessFlags.INTERFACE)

    @property
    def is_abstract(self) -> bool:
        return bool(self.access_flags & AccessFlags.ABSTRACT)

    @property
    def is_array(self) -> bool:
        return self.name.startswith('[')

    @property
    def is_primitive(self) -> bool:
        return self.name in ('Z', 'B', 'C', 'S', 'I', 'J', 'F', 'D', 'V')

    def get_method(self, name: str, signature: str = "") -> ArtMethod | None:
        """Find a method by name and optional signature."""
        # Try exact match first
        key = f"{name}{signature}" if signature else name
        if key in self.methods:
            return self.methods[key]

        # Try name-only match
        for method_key, method in self.methods.items():
            if method.name == name:
                if not signature or method.signature == signature:
                    return method
        return None

    def get_field(self, name: str) -> ArtField | None:
        """Find a field by name."""
        if name in self.fields:
            return self.fields[name]
        if name in self.static_fields:
            return self.static_fields[name]
        return None

    def add_method(self, method: ArtMethod) -> None:
        """Add a method to this class."""
        key = f"{method.name}{method.signature}"
        self.methods[key] = method

    def add_field(self, field_obj: ArtField) -> None:
        """Add a field to this class."""
        if field_obj.is_static:
            self.static_fields[field_obj.name] = field_obj
        else:
            self.fields[field_obj.name] = field_obj

    def get_static_field_value(self, name: str) -> Any:
        """Get a static field value."""
        return self._static_values.get(name)

    def set_static_field_value(self, name: str, value: Any) -> None:
        """Set a static field value."""
        self._static_values[name] = value

    def instantiate(self, runtime: ArtRuntime) -> int:
        """Create a new instance of this class."""
        from .events import ObjectAllocEvent

        # Calculate object size
        size = 16  # Object header
        for f in self.fields.values():
            size += f.get_type_size()

        # Allocate object
        obj_ref = runtime._emulator.memory.allocate(size, name=f"[{self.simple_name}]")
        self._instances.append(obj_ref)

        # Fire allocation event
        event = ObjectAllocEvent(
            class_name=self.java_name,
            object_ref=obj_ref,
            size=size,
            thread_id=1
        )
        runtime._fire_event(event)

        return obj_ref


def create_java_lang_classes() -> list[ArtClass]:
    """Create core java.lang.* classes."""
    classes = []

    # java.lang.Object
    obj_class = ArtClass(
        name="Ljava/lang/Object;",
        access_flags=AccessFlags.PUBLIC,
    )
    obj_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Object;",
        name="<init>",
        signature="()V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.CONSTRUCTOR,
    ))
    obj_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Object;",
        name="equals",
        signature="(Ljava/lang/Object;)Z",
        access_flags=AccessFlags.PUBLIC,
    ))
    obj_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Object;",
        name="hashCode",
        signature="()I",
        access_flags=AccessFlags.PUBLIC | AccessFlags.NATIVE,
    ))
    obj_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Object;",
        name="toString",
        signature="()Ljava/lang/String;",
        access_flags=AccessFlags.PUBLIC,
    ))
    obj_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Object;",
        name="getClass",
        signature="()Ljava/lang/Class;",
        access_flags=AccessFlags.PUBLIC | AccessFlags.FINAL | AccessFlags.NATIVE,
    ))
    classes.append(obj_class)

    # java.lang.String
    string_class = ArtClass(
        name="Ljava/lang/String;",
        access_flags=AccessFlags.PUBLIC | AccessFlags.FINAL,
        super_class="Ljava/lang/Object;",
    )
    string_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/String;",
        name="<init>",
        signature="()V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.CONSTRUCTOR,
    ))
    string_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/String;",
        name="<init>",
        signature="([B)V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.CONSTRUCTOR,
    ))
    string_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/String;",
        name="<init>",
        signature="([BLjava/lang/String;)V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.CONSTRUCTOR,
    ))
    string_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/String;",
        name="length",
        signature="()I",
        access_flags=AccessFlags.PUBLIC,
    ))
    string_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/String;",
        name="charAt",
        signature="(I)C",
        access_flags=AccessFlags.PUBLIC,
    ))
    string_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/String;",
        name="getBytes",
        signature="()[B",
        access_flags=AccessFlags.PUBLIC,
    ))
    string_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/String;",
        name="getBytes",
        signature="(Ljava/lang/String;)[B",
        access_flags=AccessFlags.PUBLIC,
    ))
    string_class.add_field(ArtField(
        declaring_class="Ljava/lang/String;",
        name="value",
        type_descriptor="[C",
        access_flags=AccessFlags.PRIVATE | AccessFlags.FINAL,
    ))
    classes.append(string_class)

    # java.lang.Class
    class_class = ArtClass(
        name="Ljava/lang/Class;",
        access_flags=AccessFlags.PUBLIC | AccessFlags.FINAL,
        super_class="Ljava/lang/Object;",
    )
    class_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Class;",
        name="forName",
        signature="(Ljava/lang/String;)Ljava/lang/Class;",
        access_flags=AccessFlags.PUBLIC | AccessFlags.STATIC,
    ))
    class_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Class;",
        name="getName",
        signature="()Ljava/lang/String;",
        access_flags=AccessFlags.PUBLIC,
    ))
    class_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Class;",
        name="getMethod",
        signature="(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;",
        access_flags=AccessFlags.PUBLIC,
    ))
    classes.append(class_class)

    # java.lang.System
    system_class = ArtClass(
        name="Ljava/lang/System;",
        access_flags=AccessFlags.PUBLIC | AccessFlags.FINAL,
        super_class="Ljava/lang/Object;",
    )
    system_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/System;",
        name="loadLibrary",
        signature="(Ljava/lang/String;)V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.STATIC,
    ))
    system_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/System;",
        name="getProperty",
        signature="(Ljava/lang/String;)Ljava/lang/String;",
        access_flags=AccessFlags.PUBLIC | AccessFlags.STATIC,
    ))
    system_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/System;",
        name="currentTimeMillis",
        signature="()J",
        access_flags=AccessFlags.PUBLIC | AccessFlags.STATIC | AccessFlags.NATIVE,
    ))
    system_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/System;",
        name="nanoTime",
        signature="()J",
        access_flags=AccessFlags.PUBLIC | AccessFlags.STATIC | AccessFlags.NATIVE,
    ))
    classes.append(system_class)

    # java.lang.Thread
    thread_class = ArtClass(
        name="Ljava/lang/Thread;",
        access_flags=AccessFlags.PUBLIC,
        super_class="Ljava/lang/Object;",
    )
    thread_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Thread;",
        name="currentThread",
        signature="()Ljava/lang/Thread;",
        access_flags=AccessFlags.PUBLIC | AccessFlags.STATIC | AccessFlags.NATIVE,
    ))
    thread_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Thread;",
        name="sleep",
        signature="(J)V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.STATIC | AccessFlags.NATIVE,
    ))
    thread_class.add_field(ArtField(
        declaring_class="Ljava/lang/Thread;",
        name="name",
        type_descriptor="Ljava/lang/String;",
        access_flags=AccessFlags.PRIVATE,
    ))
    classes.append(thread_class)

    # java.lang.Throwable
    throwable_class = ArtClass(
        name="Ljava/lang/Throwable;",
        access_flags=AccessFlags.PUBLIC,
        super_class="Ljava/lang/Object;",
    )
    throwable_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Throwable;",
        name="<init>",
        signature="()V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.CONSTRUCTOR,
    ))
    throwable_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Throwable;",
        name="<init>",
        signature="(Ljava/lang/String;)V",
        access_flags=AccessFlags.PUBLIC | AccessFlags.CONSTRUCTOR,
    ))
    throwable_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Throwable;",
        name="getMessage",
        signature="()Ljava/lang/String;",
        access_flags=AccessFlags.PUBLIC,
    ))
    throwable_class.add_method(ArtMethod(
        declaring_class="Ljava/lang/Throwable;",
        name="printStackTrace",
        signature="()V",
        access_flags=AccessFlags.PUBLIC,
    ))
    classes.append(throwable_class)

    return classes
