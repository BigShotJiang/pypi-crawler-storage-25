"""
Fake libart.so implementation for intercepting Java layer events.

This module provides a simulated ART (Android Runtime) that allows
intercepting and monitoring Java-level events during native code emulation:

- Class loading/initialization
- Method invocation
- Field access
- Object creation/destruction
- Thread events
- Exception handling
- JIT compilation hints
- Garbage collection events
- Dex file operations

This enables deeper analysis of native code that interacts with the Java layer.
"""

from .classes import ArtClass, ArtField, ArtMethod
from .dex import DexClass, DexFile
from .events import (
    ArtEvent,
    ClassInitEvent,
    ClassLoadEvent,
    DexLoadEvent,
    ExceptionEvent,
    FieldReadEvent,
    FieldWriteEvent,
    GCEvent,
    JitCompileEvent,
    MethodEnterEvent,
    MethodExitEvent,
    NativeBindEvent,
    ObjectAllocEvent,
    ObjectFreeEvent,
    ThreadEvent,
)
from .hooks import ArtHooks
from .runtime import ArtRuntime

__all__ = [
    # Main runtime
    "ArtRuntime",

    # Events
    "ArtEvent",
    "ClassLoadEvent",
    "ClassInitEvent",
    "MethodEnterEvent",
    "MethodExitEvent",
    "FieldReadEvent",
    "FieldWriteEvent",
    "ObjectAllocEvent",
    "ObjectFreeEvent",
    "ThreadEvent",
    "ExceptionEvent",
    "GCEvent",
    "DexLoadEvent",
    "JitCompileEvent",
    "NativeBindEvent",

    # Hooks
    "ArtHooks",

    # Classes
    "ArtClass",
    "ArtMethod",
    "ArtField",

    # Dex
    "DexFile",
    "DexClass",
]
