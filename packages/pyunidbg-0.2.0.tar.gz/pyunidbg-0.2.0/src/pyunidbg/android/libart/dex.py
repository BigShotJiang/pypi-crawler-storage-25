"""
DEX file parsing and representation.

Provides minimal DEX file support for loading class definitions.
"""

from __future__ import annotations

import logging
import struct
from dataclasses import dataclass, field
from pathlib import Path

from .classes import AccessFlags, ArtClass, ArtField, ArtMethod

logger = logging.getLogger(__name__)


# DEX magic bytes
DEX_MAGIC = b"dex\n"
DEX_VERSIONS = [b"035\x00", b"036\x00", b"037\x00", b"038\x00", b"039\x00"]


@dataclass
class DexHeader:
    """DEX file header."""
    magic: bytes = b""
    version: bytes = b""
    checksum: int = 0
    signature: bytes = b""
    file_size: int = 0
    header_size: int = 0x70
    endian_tag: int = 0x12345678
    link_size: int = 0
    link_off: int = 0
    map_off: int = 0
    string_ids_size: int = 0
    string_ids_off: int = 0
    type_ids_size: int = 0
    type_ids_off: int = 0
    proto_ids_size: int = 0
    proto_ids_off: int = 0
    field_ids_size: int = 0
    field_ids_off: int = 0
    method_ids_size: int = 0
    method_ids_off: int = 0
    class_defs_size: int = 0
    class_defs_off: int = 0
    data_size: int = 0
    data_off: int = 0


@dataclass
class DexClass:
    """Represents a class in a DEX file."""
    name: str
    access_flags: int = 0
    super_class: str | None = None
    interfaces: list[str] = field(default_factory=list)
    source_file: str | None = None
    static_fields: list[tuple[str, str, int]] = field(default_factory=list)  # (name, type, flags)
    instance_fields: list[tuple[str, str, int]] = field(default_factory=list)
    direct_methods: list[tuple[str, str, int]] = field(default_factory=list)  # (name, proto, flags)
    virtual_methods: list[tuple[str, str, int]] = field(default_factory=list)

    def to_art_class(self) -> ArtClass:
        """Convert to ArtClass."""
        art_class = ArtClass(
            name=self.name,
            access_flags=AccessFlags(self.access_flags),
            super_class=self.super_class,
            interfaces=self.interfaces,
            source_file=self.source_file,
        )

        # Add fields
        for name, type_desc, flags in self.static_fields + self.instance_fields:
            art_field = ArtField(
                declaring_class=self.name,
                name=name,
                type_descriptor=type_desc,
                access_flags=AccessFlags(flags),
            )
            art_class.add_field(art_field)

        # Add methods
        for name, proto, flags in self.direct_methods + self.virtual_methods:
            art_method = ArtMethod(
                declaring_class=self.name,
                name=name,
                signature=proto,
                access_flags=AccessFlags(flags),
            )
            art_class.add_method(art_method)

        return art_class


class DexFile:
    """
    DEX file parser.
    
    Provides basic DEX parsing to extract class definitions.
    """

    def __init__(self, path: str | Path | None = None, data: bytes | None = None):
        """
        Initialize DEX file.
        
        Args:
            path: Path to DEX file
            data: Raw DEX data (alternative to path)
        """
        self.path = Path(path) if path else None
        self._data = data
        self.header = DexHeader()
        self.strings: list[str] = []
        self.type_ids: list[int] = []
        self.classes: list[DexClass] = []

        if path or data:
            self._parse()

    def _parse(self) -> None:
        """Parse the DEX file."""
        if self.path:
            with open(self.path, 'rb') as f:
                self._data = f.read()

        if not self._data:
            return

        # Parse header
        self._parse_header()

        # Parse strings
        self._parse_strings()

        # Parse type IDs
        self._parse_type_ids()

        # Parse class definitions
        self._parse_classes()

    def _parse_header(self) -> None:
        """Parse DEX header."""
        data = self._data
        if len(data) < 0x70:
            raise ValueError("Invalid DEX file: too small")

        magic = data[:4]
        if magic != DEX_MAGIC:
            raise ValueError(f"Invalid DEX magic: {magic}")

        version = data[4:8]
        if version not in DEX_VERSIONS:
            logger.warning(f"Unknown DEX version: {version}")

        self.header = DexHeader(
            magic=magic,
            version=version,
            checksum=struct.unpack("<I", data[8:12])[0],
            signature=data[12:32],
            file_size=struct.unpack("<I", data[32:36])[0],
            header_size=struct.unpack("<I", data[36:40])[0],
            endian_tag=struct.unpack("<I", data[40:44])[0],
            link_size=struct.unpack("<I", data[44:48])[0],
            link_off=struct.unpack("<I", data[48:52])[0],
            map_off=struct.unpack("<I", data[52:56])[0],
            string_ids_size=struct.unpack("<I", data[56:60])[0],
            string_ids_off=struct.unpack("<I", data[60:64])[0],
            type_ids_size=struct.unpack("<I", data[64:68])[0],
            type_ids_off=struct.unpack("<I", data[68:72])[0],
            proto_ids_size=struct.unpack("<I", data[72:76])[0],
            proto_ids_off=struct.unpack("<I", data[76:80])[0],
            field_ids_size=struct.unpack("<I", data[80:84])[0],
            field_ids_off=struct.unpack("<I", data[84:88])[0],
            method_ids_size=struct.unpack("<I", data[88:92])[0],
            method_ids_off=struct.unpack("<I", data[92:96])[0],
            class_defs_size=struct.unpack("<I", data[96:100])[0],
            class_defs_off=struct.unpack("<I", data[100:104])[0],
            data_size=struct.unpack("<I", data[104:108])[0],
            data_off=struct.unpack("<I", data[108:112])[0],
        )

    def _parse_strings(self) -> None:
        """Parse string table."""
        data = self._data
        h = self.header

        self.strings = []
        for i in range(h.string_ids_size):
            off = struct.unpack("<I", data[h.string_ids_off + i * 4:h.string_ids_off + i * 4 + 4])[0]
            s = self._read_string(off)
            self.strings.append(s)

    def _read_string(self, off: int) -> str:
        """Read a MUTF-8 string at offset."""
        data = self._data

        # Read ULEB128 length prefix
        size = 0
        shift = 0
        while True:
            b = data[off]
            off += 1
            size |= (b & 0x7f) << shift
            if (b & 0x80) == 0:
                break
            shift += 7

        # Read string data (simplified - doesn't handle full MUTF-8)
        result = []
        for _ in range(size):
            if off >= len(data):
                break
            b = data[off]
            if b == 0:
                break
            result.append(chr(b))
            off += 1

        return ''.join(result)

    def _parse_type_ids(self) -> None:
        """Parse type ID table."""
        data = self._data
        h = self.header

        self.type_ids = []
        for i in range(h.type_ids_size):
            off = h.type_ids_off + i * 4
            string_idx = struct.unpack("<I", data[off:off + 4])[0]
            self.type_ids.append(string_idx)

    def _get_type(self, idx: int) -> str:
        """Get type name by index."""
        if 0 <= idx < len(self.type_ids):
            string_idx = self.type_ids[idx]
            if 0 <= string_idx < len(self.strings):
                return self.strings[string_idx]
        return ""

    def _parse_classes(self) -> None:
        """Parse class definitions."""
        data = self._data
        h = self.header

        self.classes = []
        for i in range(h.class_defs_size):
            off = h.class_defs_off + i * 32

            class_idx = struct.unpack("<I", data[off:off + 4])[0]
            access_flags = struct.unpack("<I", data[off + 4:off + 8])[0]
            superclass_idx = struct.unpack("<I", data[off + 8:off + 12])[0]
            interfaces_off = struct.unpack("<I", data[off + 12:off + 16])[0]
            source_file_idx = struct.unpack("<I", data[off + 16:off + 20])[0]
            annotations_off = struct.unpack("<I", data[off + 20:off + 24])[0]
            class_data_off = struct.unpack("<I", data[off + 24:off + 28])[0]
            static_values_off = struct.unpack("<I", data[off + 28:off + 32])[0]

            class_name = self._get_type(class_idx)
            super_class = self._get_type(superclass_idx) if superclass_idx != 0xffffffff else None
            source_file = self.strings[source_file_idx] if source_file_idx != 0xffffffff and source_file_idx < len(self.strings) else None

            # Parse interfaces
            interfaces = []
            if interfaces_off != 0:
                iface_count = struct.unpack("<I", data[interfaces_off:interfaces_off + 4])[0]
                for j in range(iface_count):
                    iface_idx = struct.unpack("<H", data[interfaces_off + 4 + j * 2:interfaces_off + 6 + j * 2])[0]
                    interfaces.append(self._get_type(iface_idx))

            dex_class = DexClass(
                name=class_name,
                access_flags=access_flags,
                super_class=super_class,
                interfaces=interfaces,
                source_file=source_file,
            )

            # Parse class data if present
            if class_data_off != 0:
                self._parse_class_data(dex_class, class_data_off)

            self.classes.append(dex_class)

    def _read_uleb128(self, off: int) -> tuple[int, int]:
        """Read ULEB128 value, return (value, new_offset)."""
        data = self._data
        result = 0
        shift = 0
        while True:
            b = data[off]
            off += 1
            result |= (b & 0x7f) << shift
            if (b & 0x80) == 0:
                break
            shift += 7
        return result, off

    def _parse_class_data(self, dex_class: DexClass, off: int) -> None:
        """Parse class data item."""
        static_fields_size, off = self._read_uleb128(off)
        instance_fields_size, off = self._read_uleb128(off)
        direct_methods_size, off = self._read_uleb128(off)
        virtual_methods_size, off = self._read_uleb128(off)

        # Parse fields (simplified - just counts)
        field_idx = 0
        for _ in range(static_fields_size):
            idx_diff, off = self._read_uleb128(off)
            field_idx += idx_diff
            access_flags, off = self._read_uleb128(off)
            dex_class.static_fields.append((f"field_{field_idx}", "I", access_flags))

        field_idx = 0
        for _ in range(instance_fields_size):
            idx_diff, off = self._read_uleb128(off)
            field_idx += idx_diff
            access_flags, off = self._read_uleb128(off)
            dex_class.instance_fields.append((f"field_{field_idx}", "I", access_flags))

        # Parse methods (simplified)
        method_idx = 0
        for _ in range(direct_methods_size):
            idx_diff, off = self._read_uleb128(off)
            method_idx += idx_diff
            access_flags, off = self._read_uleb128(off)
            code_off, off = self._read_uleb128(off)
            dex_class.direct_methods.append((f"method_{method_idx}", "()V", access_flags))

        method_idx = 0
        for _ in range(virtual_methods_size):
            idx_diff, off = self._read_uleb128(off)
            method_idx += idx_diff
            access_flags, off = self._read_uleb128(off)
            code_off, off = self._read_uleb128(off)
            dex_class.virtual_methods.append((f"method_{method_idx}", "()V", access_flags))

    def get_class(self, name: str) -> DexClass | None:
        """Get a class by name."""
        for cls in self.classes:
            if cls.name == name or cls.name == f"L{name.replace('.', '/')};" or cls.name[1:-1].replace('/', '.') == name:
                return cls
        return None

    def list_classes(self) -> list[str]:
        """List all class names."""
        return [cls.name for cls in self.classes]

    def __repr__(self) -> str:
        return f"DexFile(path={self.path}, classes={len(self.classes)})"
