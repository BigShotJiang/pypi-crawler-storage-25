"""Linux/Android syscall handling."""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from dataclasses import dataclass
from enum import IntEnum
from typing import TYPE_CHECKING

from unicorn import UC_HOOK_INTR
from unicorn.arm64_const import UC_ARM64_REG_X8
from unicorn.arm_const import UC_ARM_REG_R7

from pyunidbg.core.constants import Architecture
from pyunidbg.core.hooks import HookAction

if TYPE_CHECKING:
    from pyunidbg.android.emulator import AndroidEmulator

logger = logging.getLogger(__name__)


# ARM64 syscall numbers (Android/Linux)
class Syscall64(IntEnum):
    READ = 63
    WRITE = 64
    OPENAT = 56
    CLOSE = 57
    FSTAT = 80
    LSEEK = 62
    MMAP = 222
    MPROTECT = 226
    MUNMAP = 215
    BRK = 214
    IOCTL = 29
    WRITEV = 66
    PREAD64 = 67
    PWRITE64 = 68
    READV = 65
    FCNTL = 25
    FLOCK = 32
    FSYNC = 82
    FDATASYNC = 83
    FTRUNCATE = 46
    GETDENTS64 = 61
    GETCWD = 17
    CHDIR = 49
    FCHDIR = 50
    RENAME = 38  # renameat
    MKDIR = 34   # mkdirat
    RMDIR = 35   # unlinkat with AT_REMOVEDIR
    LINK = 37    # linkat
    UNLINK = 35  # unlinkat
    SYMLINK = 36 # symlinkat
    READLINK = 78 # readlinkat
    CHMOD = 53   # fchmodat
    CHOWN = 54   # fchownat
    FCHMOD = 52
    FCHOWN = 55
    UMASK = 166
    GETTIMEOFDAY = 169
    GETRLIMIT = 163
    GETRUSAGE = 165
    SYSINFO = 179
    TIMES = 153
    GETUID = 174
    GETGID = 176
    GETEUID = 175
    GETEGID = 177
    SETUID = 146
    SETGID = 144
    GETPID = 172
    GETPPID = 173
    GETTID = 178
    SETSID = 157
    GETPGID = 155
    SETPGID = 154
    UNAME = 160
    CLOCK_GETTIME = 113
    CLOCK_GETRES = 114
    NANOSLEEP = 101
    EXIT = 93
    EXIT_GROUP = 94
    FUTEX = 98
    SET_TID_ADDRESS = 96
    SET_ROBUST_LIST = 99
    GET_ROBUST_LIST = 100
    PRCTL = 167
    GETRANDOM = 278
    STATFS = 43
    FSTATFS = 44
    FACCESSAT = 48
    NEWFSTATAT = 79  # fstatat64


# ARM32 syscall numbers
class Syscall32(IntEnum):
    READ = 3
    WRITE = 4
    OPEN = 5
    CLOSE = 6
    STAT = 106
    FSTAT = 108
    LSTAT = 107
    LSEEK = 19
    MMAP2 = 192
    MPROTECT = 125
    MUNMAP = 91
    BRK = 45
    IOCTL = 54
    WRITEV = 146
    FCNTL64 = 221
    GETTID = 224
    FUTEX = 240
    EXIT = 1
    EXIT_GROUP = 248
    CLOCK_GETTIME = 263
    GETUID32 = 199
    GETGID32 = 200
    GETEUID32 = 201
    GETEGID32 = 202
    GETPID = 20
    UNAME = 122
    GETRANDOM = 384


@dataclass
class FileDescriptor:
    """Represents an open file descriptor."""

    fd: int
    path: str
    flags: int
    mode: int
    position: int = 0
    data: bytes = b""  # For virtual files


class SyscallHandler:
    """
    Handles Linux/Android system calls.
    
    Intercepts and emulates syscalls made by native code.
    """

    def __init__(self, emulator: AndroidEmulator):
        self._emulator = emulator
        self._arch = emulator.arch

        # File descriptor table
        self._fd_counter = 3  # 0=stdin, 1=stdout, 2=stderr
        self._fds: dict[int, FileDescriptor] = {
            0: FileDescriptor(0, "/dev/stdin", os.O_RDONLY, 0),
            1: FileDescriptor(1, "/dev/stdout", os.O_WRONLY, 0),
            2: FileDescriptor(2, "/dev/stderr", os.O_WRONLY, 0),
        }

        # Virtual filesystem
        self._vfs: dict[str, bytes] = {
            "/proc/self/cmdline": b"app_process\x00",
            "/proc/self/exe": b"/system/bin/app_process64",
            "/system/build.prop": self._generate_build_prop(),
        }

        # Syscall handlers
        self._handlers: dict[int, Callable] = {}
        self._register_handlers()

        # Hook syscalls
        self._setup_syscall_hook()

    def _setup_syscall_hook(self) -> None:
        """Setup the syscall interrupt hook."""
        self._emulator._uc.hook_add(
            UC_HOOK_INTR,
            self._syscall_interrupt,
            user_data=self,
        )

    def _syscall_interrupt(self, uc, intno, user_data) -> None:
        """Handle syscall interrupt."""
        if self._arch == Architecture.ARM64:
            # ARM64: syscall number in X8, args in X0-X5
            syscall_num = uc.reg_read(UC_ARM64_REG_X8)
            self._handle_syscall_arm64(syscall_num)
        elif self._arch == Architecture.ARM:
            # ARM32: syscall number in R7, args in R0-R6
            syscall_num = uc.reg_read(UC_ARM_REG_R7)
            self._handle_syscall_arm32(syscall_num)

    def _handle_syscall_arm64(self, num: int) -> None:
        """Handle ARM64 syscall."""
        cpu = self._emulator.cpu

        # Get arguments (X0-X5)
        args = [cpu.get_arg(i) for i in range(6)]

        # Get syscall name
        try:
            name = Syscall64(num).name
        except ValueError:
            name = f"syscall_{num}"

        logger.debug(f"Syscall: {name}({num}) args={[hex(a) for a in args]}")

        # Check for user hooks first
        hooks = self._emulator.hook.get_syscall_hooks(num)
        if not hooks:
            hooks = self._emulator.hook.get_syscall_hooks(name.lower())

        for hook in hooks:
            if hook.enabled:
                result = hook.callback(self._emulator, *args)
                if result == HookAction.SKIP:
                    return

        # Call handler
        handler = self._handlers.get(num)
        if handler:
            result = handler(*args)
            cpu.set_return_value(result if result is not None else 0)
        else:
            logger.warning(f"Unhandled syscall: {name}({num})")
            cpu.set_return_value(-1)  # ENOSYS

    def _handle_syscall_arm32(self, num: int) -> None:
        """Handle ARM32 syscall."""
        cpu = self._emulator.cpu
        args = [cpu.get_arg(i) for i in range(7)]

        try:
            name = Syscall32(num).name
        except ValueError:
            name = f"syscall_{num}"

        logger.debug(f"Syscall: {name}({num}) args={[hex(a) for a in args]}")

        handler = self._handlers.get(num)
        if handler:
            result = handler(*args)
            cpu.set_return_value(result if result is not None else 0)
        else:
            logger.warning(f"Unhandled syscall: {name}({num})")
            cpu.set_return_value(-1)

    def _register_handlers(self) -> None:
        """Register syscall handlers based on architecture."""
        if self._arch == Architecture.ARM64:
            self._handlers = {
                Syscall64.READ: self._sys_read,
                Syscall64.WRITE: self._sys_write,
                Syscall64.OPENAT: self._sys_openat,
                Syscall64.CLOSE: self._sys_close,
                Syscall64.FSTAT: self._sys_fstat,
                Syscall64.LSEEK: self._sys_lseek,
                Syscall64.MMAP: self._sys_mmap,
                Syscall64.MPROTECT: self._sys_mprotect,
                Syscall64.MUNMAP: self._sys_munmap,
                Syscall64.BRK: self._sys_brk,
                Syscall64.IOCTL: self._sys_ioctl,
                Syscall64.WRITEV: self._sys_writev,
                Syscall64.GETTID: self._sys_gettid,
                Syscall64.GETPID: self._sys_getpid,
                Syscall64.GETUID: self._sys_getuid,
                Syscall64.GETGID: self._sys_getgid,
                Syscall64.GETEUID: self._sys_geteuid,
                Syscall64.GETEGID: self._sys_getegid,
                Syscall64.UNAME: self._sys_uname,
                Syscall64.CLOCK_GETTIME: self._sys_clock_gettime,
                Syscall64.GETRANDOM: self._sys_getrandom,
                Syscall64.EXIT: self._sys_exit,
                Syscall64.EXIT_GROUP: self._sys_exit,
                Syscall64.FUTEX: self._sys_futex,
                Syscall64.SET_TID_ADDRESS: self._sys_set_tid_address,
                Syscall64.PRCTL: self._sys_prctl,
                Syscall64.FACCESSAT: self._sys_faccessat,
            }
        else:
            self._handlers = {
                Syscall32.READ: self._sys_read,
                Syscall32.WRITE: self._sys_write,
                Syscall32.OPEN: self._sys_open,
                Syscall32.CLOSE: self._sys_close,
                Syscall32.FSTAT: self._sys_fstat,
                Syscall32.LSEEK: self._sys_lseek,
                Syscall32.MMAP2: self._sys_mmap,
                Syscall32.MPROTECT: self._sys_mprotect,
                Syscall32.MUNMAP: self._sys_munmap,
                Syscall32.BRK: self._sys_brk,
                Syscall32.GETTID: self._sys_gettid,
                Syscall32.GETPID: self._sys_getpid,
                Syscall32.UNAME: self._sys_uname,
                Syscall32.CLOCK_GETTIME: self._sys_clock_gettime,
                Syscall32.EXIT: self._sys_exit,
                Syscall32.EXIT_GROUP: self._sys_exit,
            }

    # File operations

    def _alloc_fd(self) -> int:
        """Allocate a new file descriptor."""
        fd = self._fd_counter
        self._fd_counter += 1
        return fd

    def _sys_openat(self, dirfd: int, pathname: int, flags: int, mode: int = 0) -> int:
        """openat syscall."""
        path = self._emulator.memory.read_string(pathname)
        logger.debug(f"openat({dirfd}, {path!r}, {flags:#x}, {mode:#o})")

        # Check virtual filesystem
        if path in self._vfs:
            fd = self._alloc_fd()
            self._fds[fd] = FileDescriptor(fd, path, flags, mode, 0, self._vfs[path])
            return fd

        # Check emulator's virtual files
        vfile = self._emulator.get_virtual_file(path)
        if vfile is not None:
            fd = self._alloc_fd()
            self._fds[fd] = FileDescriptor(fd, path, flags, mode, 0, vfile)
            return fd

        # File not found
        logger.warning(f"openat: file not found: {path}")
        return -2  # ENOENT

    def _sys_open(self, pathname: int, flags: int, mode: int = 0) -> int:
        """open syscall (ARM32)."""
        return self._sys_openat(-100, pathname, flags, mode)

    def _sys_read(self, fd: int, buf: int, count: int) -> int:
        """read syscall."""
        if fd not in self._fds:
            return -9  # EBADF

        file = self._fds[fd]

        # Read from virtual file
        data = file.data[file.position:file.position + count]
        if data:
            self._emulator.memory.write(buf, data)
            file.position += len(data)

        return len(data)

    def _sys_write(self, fd: int, buf: int, count: int) -> int:
        """write syscall."""
        data = self._emulator.memory.read(buf, count)

        if fd == 1:  # stdout
            print(data.decode('utf-8', errors='replace'), end='')
        elif fd == 2:  # stderr
            print(data.decode('utf-8', errors='replace'), end='', file=__import__('sys').stderr)

        return count

    def _sys_close(self, fd: int) -> int:
        """close syscall."""
        if fd in self._fds and fd > 2:
            del self._fds[fd]
        return 0

    def _sys_fstat(self, fd: int, statbuf: int) -> int:
        """fstat syscall - fills complete struct stat."""
        if fd not in self._fds:
            return -9  # EBADF

        file = self._fds[fd]
        file_size = len(file.data)

        import time
        now = int(time.time())

        is_regular = file.fd > 2
        st_mode = 0o100644 if is_regular else 0o020666  # S_IFREG|0644 or S_IFCHR|0666
        st_nlink = 1
        st_uid = 10000
        st_gid = 10000
        st_blksize = 4096
        st_blocks = (file_size + 511) // 512

        mem = self._emulator.memory

        if self._arch == Architecture.ARM64:
            # ARM64 struct stat (128 bytes)
            mem.write_u64(statbuf + 0, fd)          # st_dev
            mem.write_u64(statbuf + 8, fd + 100000) # st_ino
            mem.write_u32(statbuf + 16, st_mode)    # st_mode
            mem.write_u32(statbuf + 20, st_nlink)   # st_nlink
            mem.write_u32(statbuf + 24, st_uid)     # st_uid
            mem.write_u32(statbuf + 28, st_gid)     # st_gid
            mem.write_u64(statbuf + 32, 0)          # st_rdev
            mem.write_u64(statbuf + 40, 0)          # __pad1
            mem.write_u64(statbuf + 48, file_size)  # st_size
            mem.write_u32(statbuf + 56, st_blksize) # st_blksize
            mem.write_u32(statbuf + 60, 0)          # __pad2
            mem.write_u64(statbuf + 64, st_blocks)  # st_blocks
            mem.write_u64(statbuf + 72, now)        # st_atime
            mem.write_u64(statbuf + 80, 0)          # st_atime_nsec
            mem.write_u64(statbuf + 88, now)        # st_mtime
            mem.write_u64(statbuf + 96, 0)          # st_mtime_nsec
            mem.write_u64(statbuf + 104, now)       # st_ctime
            mem.write_u64(statbuf + 112, 0)         # st_ctime_nsec
            mem.write_u64(statbuf + 120, 0)         # __unused
        else:
            # ARM32 struct stat (88 bytes)
            mem.write_u64(statbuf + 0, fd)          # st_dev (unsigned long long)
            mem.write_u32(statbuf + 8, 0)           # __pad1
            mem.write_u32(statbuf + 12, fd + 100000)# st_ino
            mem.write_u32(statbuf + 16, st_mode)    # st_mode
            mem.write_u32(statbuf + 20, st_nlink)   # st_nlink
            mem.write_u32(statbuf + 24, st_uid)     # st_uid
            mem.write_u32(statbuf + 28, st_gid)     # st_gid
            mem.write_u64(statbuf + 32, 0)          # st_rdev
            mem.write_u32(statbuf + 40, 0)          # __pad2
            mem.write_u32(statbuf + 44, file_size)  # st_size
            mem.write_u32(statbuf + 48, st_blksize) # st_blksize
            mem.write_u32(statbuf + 52, st_blocks)  # st_blocks
            mem.write_u32(statbuf + 56, now)        # st_atime
            mem.write_u32(statbuf + 60, 0)          # st_atime_nsec
            mem.write_u32(statbuf + 64, now)        # st_mtime
            mem.write_u32(statbuf + 68, 0)          # st_mtime_nsec
            mem.write_u32(statbuf + 72, now)        # st_ctime
            mem.write_u32(statbuf + 76, 0)          # st_ctime_nsec
            mem.write_u32(statbuf + 80, 0)          # __unused4
            mem.write_u32(statbuf + 84, 0)          # __unused5

        return 0

    def _sys_lseek(self, fd: int, offset: int, whence: int) -> int:
        """lseek syscall."""
        if fd not in self._fds:
            return -9  # EBADF

        file = self._fds[fd]

        if whence == 0:  # SEEK_SET
            file.position = offset
        elif whence == 1:  # SEEK_CUR
            file.position += offset
        elif whence == 2:  # SEEK_END
            file.position = len(file.data) + offset

        return file.position

    def _sys_writev(self, fd: int, iov: int, iovcnt: int) -> int:
        """writev syscall."""
        total = 0
        ptr_size = self._emulator.pointer_size

        for i in range(iovcnt):
            iov_entry = iov + (i * ptr_size * 2)
            base = self._emulator.memory.read_ptr(iov_entry)
            length = self._emulator.memory.read_ptr(iov_entry + ptr_size)

            if length > 0:
                written = self._sys_write(fd, base, length)
                if written < 0:
                    return written
                total += written

        return total

    # Memory operations

    def _sys_mmap(self, addr: int, length: int, prot: int, flags: int,
                  fd: int, offset: int) -> int:
        """mmap syscall."""
        from pyunidbg.core.constants import MemoryProtection

        logger.debug(f"mmap({addr:#x}, {length:#x}, {prot}, {flags}, {fd}, {offset})")

        # Convert protection flags
        mem_prot = MemoryProtection.NONE
        if prot & 1:  # PROT_READ
            mem_prot |= MemoryProtection.READ
        if prot & 2:  # PROT_WRITE
            mem_prot |= MemoryProtection.WRITE
        if prot & 4:  # PROT_EXEC
            mem_prot |= MemoryProtection.EXEC

        # Allocate memory
        try:
            if addr == 0:
                result = self._emulator.memory.allocate(length, mem_prot, "[mmap]")
            else:
                self._emulator.memory.map(addr, length, mem_prot, "[mmap]")
                result = addr

            # If mapping a file, read the data
            if fd >= 0 and fd in self._fds:
                file = self._fds[fd]
                data = file.data[offset:offset + length]
                if data:
                    self._emulator.memory.write(result, data)

            return result
        except Exception as e:
            logger.error(f"mmap failed: {e}")
            return -12  # ENOMEM

    def _sys_mprotect(self, addr: int, length: int, prot: int) -> int:
        """mprotect syscall."""
        from pyunidbg.core.constants import MemoryProtection

        mem_prot = MemoryProtection.NONE
        if prot & 1:
            mem_prot |= MemoryProtection.READ
        if prot & 2:
            mem_prot |= MemoryProtection.WRITE
        if prot & 4:
            mem_prot |= MemoryProtection.EXEC

        try:
            self._emulator.memory.protect(addr, length, mem_prot)
            return 0
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return -1

    def _sys_munmap(self, addr: int, length: int) -> int:
        """munmap syscall."""
        try:
            self._emulator.memory.unmap(addr, length)
            return 0
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return -1

    def _sys_brk(self, addr: int) -> int:
        """brk syscall."""
        # Simple implementation - just return current break
        return self._emulator.memory._next_alloc

    # Process/Thread info

    def _sys_getpid(self) -> int:
        """getpid syscall."""
        return 1000

    def _sys_gettid(self) -> int:
        """gettid syscall."""
        return 1000

    def _sys_getuid(self) -> int:
        """getuid syscall."""
        return 10000  # Typical Android app UID

    def _sys_getgid(self) -> int:
        """getgid syscall."""
        return 10000

    def _sys_geteuid(self) -> int:
        """geteuid syscall."""
        return 10000

    def _sys_getegid(self) -> int:
        """getegid syscall."""
        return 10000

    def _sys_uname(self, buf: int) -> int:
        """uname syscall."""
        # struct utsname has 6 fields of 65 bytes each
        fields = [
            b"Linux",                  # sysname
            b"localhost",              # nodename
            b"5.4.0-android",          # release
            b"#1 SMP PREEMPT",         # version
            b"aarch64" if self._arch == Architecture.ARM64 else b"armv7l",  # machine
            b"(none)",                 # domainname
        ]

        for i, field in enumerate(fields):
            self._emulator.memory.write(buf + (i * 65), field + b'\x00')

        return 0

    def _sys_clock_gettime(self, clk_id: int, tp: int) -> int:
        """clock_gettime syscall."""
        import time
        now = time.time()
        sec = int(now)
        nsec = int((now - sec) * 1e9)

        if self._arch == Architecture.ARM64:
            self._emulator.memory.write_u64(tp, sec)
            self._emulator.memory.write_u64(tp + 8, nsec)
        else:
            self._emulator.memory.write_u32(tp, sec)
            self._emulator.memory.write_u32(tp + 4, nsec)

        return 0

    def _sys_getrandom(self, buf: int, buflen: int, flags: int) -> int:
        """getrandom syscall."""
        data = os.urandom(buflen)
        self._emulator.memory.write(buf, data)
        return buflen

    def _sys_ioctl(self, fd: int, request: int, arg: int) -> int:
        """ioctl syscall."""
        logger.debug(f"ioctl({fd}, {request:#x}, {arg:#x})")
        return 0

    def _sys_futex(self, uaddr: int, op: int, val: int,
                   timeout: int, uaddr2: int, val3: int) -> int:
        """futex syscall."""
        # Simple implementation - just return success
        return 0

    def _sys_set_tid_address(self, tidptr: int) -> int:
        """set_tid_address syscall."""
        return 1000  # Return TID

    def _sys_prctl(self, option: int, arg2: int, arg3: int,
                   arg4: int, arg5: int) -> int:
        """prctl syscall."""
        PR_SET_NAME = 15
        PR_GET_NAME = 16

        if option == PR_SET_NAME:
            name = self._emulator.memory.read_string(arg2, 16)
            logger.debug(f"prctl(PR_SET_NAME, {name!r})")
        elif option == PR_GET_NAME:
            self._emulator.memory.write_string(arg2, "main")

        return 0

    def _sys_faccessat(self, dirfd: int, pathname: int, mode: int, flags: int) -> int:
        """faccessat syscall."""
        path = self._emulator.memory.read_string(pathname)

        # Check virtual filesystem
        if path in self._vfs or self._emulator.get_virtual_file(path):
            return 0

        return -2  # ENOENT

    def _sys_exit(self, status: int) -> int:
        """exit/exit_group syscall."""
        logger.info(f"Process exiting with status {status}")
        self._emulator.stop()
        return 0

    def _generate_build_prop(self) -> bytes:
        """Generate a fake build.prop file."""
        props = [
            "ro.build.id=RQ3A.211001.001",
            f"ro.build.version.sdk={self._emulator.api_level}",
            "ro.build.version.release=11",
            "ro.product.manufacturer=Google",
            "ro.product.model=Pixel 4",
            "ro.product.brand=google",
            "ro.product.device=flame",
            "ro.product.cpu.abi=arm64-v8a",
            "ro.hardware=flame",
        ]
        return "\n".join(props).encode() + b"\n"

    def add_virtual_file(self, path: str, content: bytes) -> None:
        """Add a file to the virtual filesystem."""
        self._vfs[path] = content
