"""
Signal bypass for anti-debugging.

Patches signal-based anti-debugging techniques:
- SIGTRAP handling (breakpoint detection)
- SIGSTOP/SIGCONT handling
- Signal handler enumeration
- raise() / kill() interception
- sigaction() manipulation

Techniques:
1. Intercept SIGTRAP to hide breakpoints
2. Block SIGSTOP that might pause for debugging
3. Report no signal handlers registered
4. Fake signal delivery
"""

import logging
import struct
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ...core.emulator import Emulator

logger = logging.getLogger(__name__)


class Signal(IntEnum):
    """Standard Unix signals."""
    SIGHUP = 1
    SIGINT = 2
    SIGQUIT = 3
    SIGILL = 4
    SIGTRAP = 5
    SIGABRT = 6
    SIGIOT = 6
    SIGBUS = 7
    SIGFPE = 8
    SIGKILL = 9
    SIGUSR1 = 10
    SIGSEGV = 11
    SIGUSR2 = 12
    SIGPIPE = 13
    SIGALRM = 14
    SIGTERM = 15
    SIGSTKFLT = 16
    SIGCHLD = 17
    SIGCONT = 18
    SIGSTOP = 19
    SIGTSTP = 20
    SIGTTIN = 21
    SIGTTOU = 22
    SIGURG = 23
    SIGXCPU = 24
    SIGXFSZ = 25
    SIGVTALRM = 26
    SIGPROF = 27
    SIGWINCH = 28
    SIGIO = 29
    SIGPOLL = 29
    SIGPWR = 30
    SIGSYS = 31


class SigactionFlags(IntEnum):
    """Flags for sigaction."""
    SA_NOCLDSTOP = 1
    SA_NOCLDWAIT = 2
    SA_SIGINFO = 4
    SA_ONSTACK = 0x08000000
    SA_RESTART = 0x10000000
    SA_NODEFER = 0x40000000
    SA_RESETHAND = 0x80000000


# Signal handler constants
SIG_DFL = 0
SIG_IGN = 1
SIG_ERR = -1


@dataclass
class SignalState:
    """Tracks signal bypass state."""
    # Registered handlers (signal -> handler address)
    handlers: dict[int, int] = field(default_factory=dict)

    # Blocked signals
    blocked_signals: set[int] = field(default_factory=set)

    # Pending signals (signal -> count)
    pending: dict[int, int] = field(default_factory=dict)

    # Call counters
    sigaction_calls: int = 0
    signal_calls: int = 0
    kill_calls: int = 0
    raise_calls: int = 0

    # Suppressed signals (don't deliver)
    suppressed: set[int] = field(default_factory=lambda: {
        Signal.SIGTRAP,
        Signal.SIGSTOP,
    })

    # Intercepted signals log
    intercepted: list = field(default_factory=list)


class SignalBypass:
    """
    Bypass signal-based anti-debugging techniques.
    
    Common techniques:
    1. Register SIGTRAP handler - triggered by breakpoints
    2. Check if SIGSTOP is delivered - indicates ptrace
    3. Check sigaction for existing handlers
    4. Self-send signals and measure timing
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.state = SignalState()
        self._enabled = False

    def enable(self) -> None:
        """Enable signal bypass."""
        if self._enabled:
            return

        self._enabled = True
        self.state = SignalState()

        logger.info("Enabling signal bypass")

        # Hook signal-related syscalls
        self._hook_syscalls()

    def disable(self) -> None:
        """Disable signal bypass."""
        if not self._enabled:
            return

        self._enabled = False
        logger.info("Disabled signal bypass")

    def suppress_signal(self, sig: int) -> None:
        """Add a signal to the suppression list."""
        self.state.suppressed.add(sig)

    def allow_signal(self, sig: int) -> None:
        """Remove a signal from the suppression list."""
        self.state.suppressed.discard(sig)

    def _hook_syscalls(self) -> None:
        """Hook signal-related syscalls."""
        if not hasattr(self.emulator, 'syscall_handler'):
            return

        handler = self.emulator.syscall_handler

        # rt_sigaction (main signal handler setup)
        handler.register_hook('rt_sigaction', self._handle_rt_sigaction)

        # rt_sigprocmask (blocking signals)
        handler.register_hook('rt_sigprocmask', self._handle_rt_sigprocmask)

        # rt_sigpending (check pending signals)
        handler.register_hook('rt_sigpending', self._handle_rt_sigpending)

        # kill (send signal)
        handler.register_hook('kill', self._handle_kill)

        # tgkill (thread-specific kill)
        handler.register_hook('tgkill', self._handle_tgkill)

        # rt_sigsuspend (wait for signal)
        handler.register_hook('rt_sigsuspend', self._handle_rt_sigsuspend)

    def _handle_rt_sigaction(self, emu: 'Emulator', signum: int,
                             act_ptr: int, oldact_ptr: int, sigsetsize: int) -> int:
        """
        Handle rt_sigaction syscall.
        
        struct sigaction {
            void (*sa_handler)(int);      // or sa_sigaction
            unsigned long sa_flags;
            void (*sa_restorer)(void);
            sigset_t sa_mask;
        };
        """
        self.state.sigaction_calls += 1

        try:
            sig_name = Signal(signum).name
        except ValueError:
            sig_name = f"SIG{signum}"

        logger.debug(f"rt_sigaction({sig_name}, act=0x{act_ptr:x}, oldact=0x{oldact_ptr:x})")

        # If oldact_ptr is provided, return the "old" handler
        if oldact_ptr:
            old_handler = self.state.handlers.get(signum, SIG_DFL)

            if emu.is_64bit:
                # struct sigaction for 64-bit
                # sa_handler (8) + sa_flags (8) + sa_restorer (8) + sa_mask (8)
                data = struct.pack('<QQQQ', old_handler, 0, 0, 0)
            else:
                # 32-bit
                data = struct.pack('<IIII', old_handler, 0, 0, 0)

            emu.memory.write(oldact_ptr, data)

        # If act_ptr is provided, register the new handler
        if act_ptr:
            if emu.is_64bit:
                data = emu.memory.read(act_ptr, 32)
                sa_handler, sa_flags, sa_restorer, sa_mask = struct.unpack('<QQQQ', data)
            else:
                data = emu.memory.read(act_ptr, 16)
                sa_handler, sa_flags, sa_restorer, sa_mask = struct.unpack('<IIII', data)

            # Special handling for debug-related signals
            if signum == Signal.SIGTRAP:
                # Don't actually register SIGTRAP handler - it reveals breakpoints
                logger.debug(f"Intercepted SIGTRAP handler registration: 0x{sa_handler:x}")
                self.state.intercepted.append(('SIGTRAP', 'handler', sa_handler))
                # Store it but don't let it fire
                self.state.handlers[signum] = sa_handler
            elif signum == Signal.SIGSTOP:
                logger.debug(f"Intercepted SIGSTOP handler registration: 0x{sa_handler:x}")
                self.state.intercepted.append(('SIGSTOP', 'handler', sa_handler))
            else:
                self.state.handlers[signum] = sa_handler

        return 0

    def _handle_rt_sigprocmask(self, emu: 'Emulator', how: int,
                                set_ptr: int, oldset_ptr: int, sigsetsize: int) -> int:
        """Handle rt_sigprocmask syscall."""
        # Return old mask if requested
        if oldset_ptr:
            # Convert blocked signals to bitmask
            mask = 0
            for sig in self.state.blocked_signals:
                mask |= (1 << (sig - 1))

            if emu.is_64bit:
                emu.memory.write(oldset_ptr, struct.pack('<Q', mask))
            else:
                emu.memory.write(oldset_ptr, struct.pack('<I', mask))

        # Apply new mask
        if set_ptr:
            if emu.is_64bit:
                new_mask = struct.unpack('<Q', emu.memory.read(set_ptr, 8))[0]
            else:
                new_mask = struct.unpack('<I', emu.memory.read(set_ptr, 4))[0]

            # SIG_BLOCK = 0, SIG_UNBLOCK = 1, SIG_SETMASK = 2
            if how == 0:  # SIG_BLOCK
                for sig in range(1, 32):
                    if new_mask & (1 << (sig - 1)):
                        self.state.blocked_signals.add(sig)
            elif how == 1:  # SIG_UNBLOCK
                for sig in range(1, 32):
                    if new_mask & (1 << (sig - 1)):
                        self.state.blocked_signals.discard(sig)
            elif how == 2:  # SIG_SETMASK
                self.state.blocked_signals.clear()
                for sig in range(1, 32):
                    if new_mask & (1 << (sig - 1)):
                        self.state.blocked_signals.add(sig)

        return 0

    def _handle_rt_sigpending(self, emu: 'Emulator', set_ptr: int, sigsetsize: int) -> int:
        """Handle rt_sigpending syscall."""
        if not set_ptr:
            return 0

        # Build pending signal mask (excluding suppressed ones)
        mask = 0
        for sig, count in self.state.pending.items():
            if count > 0 and sig not in self.state.suppressed:
                mask |= (1 << (sig - 1))

        if emu.is_64bit:
            emu.memory.write(set_ptr, struct.pack('<Q', mask))
        else:
            emu.memory.write(set_ptr, struct.pack('<I', mask))

        return 0

    def _handle_kill(self, emu: 'Emulator', pid: int, sig: int) -> int:
        """Handle kill syscall."""
        self.state.kill_calls += 1

        try:
            sig_name = Signal(sig).name
        except ValueError:
            sig_name = f"SIG{sig}"

        logger.debug(f"kill(pid={pid}, sig={sig_name})")

        # Self-signal?
        my_pid = getattr(emu, 'pid', 1234)
        if pid == my_pid or pid == 0 or pid == -1:
            # Suppress debug-related signals
            if sig in self.state.suppressed:
                logger.debug(f"Suppressing self-signal {sig_name}")
                self.state.intercepted.append(('kill', sig_name, 'suppressed'))
                return 0

            # Queue the signal
            self.state.pending[sig] = self.state.pending.get(sig, 0) + 1

        return 0

    def _handle_tgkill(self, emu: 'Emulator', tgid: int, tid: int, sig: int) -> int:
        """Handle tgkill syscall (thread-specific kill)."""
        try:
            sig_name = Signal(sig).name
        except ValueError:
            sig_name = f"SIG{sig}"

        logger.debug(f"tgkill(tgid={tgid}, tid={tid}, sig={sig_name})")

        # Same logic as kill
        if sig in self.state.suppressed:
            logger.debug(f"Suppressing tgkill {sig_name}")
            return 0

        self.state.pending[sig] = self.state.pending.get(sig, 0) + 1
        return 0

    def _handle_rt_sigsuspend(self, emu: 'Emulator', mask_ptr: int, sigsetsize: int) -> int:
        """Handle rt_sigsuspend syscall."""
        # This waits for a signal - we'll return immediately
        # as if a signal was received (that we suppressed)
        logger.debug("rt_sigsuspend: returning immediately")
        return -4  # EINTR - interrupted by signal

    def get_stats(self) -> dict[str, Any]:
        """Get signal bypass statistics."""
        return {
            'enabled': self._enabled,
            'sigaction_calls': self.state.sigaction_calls,
            'signal_calls': self.state.signal_calls,
            'kill_calls': self.state.kill_calls,
            'raise_calls': self.state.raise_calls,
            'suppressed_signals': [
                Signal(s).name if s in Signal._value2member_map_ else f'SIG{s}'
                for s in self.state.suppressed
            ],
            'blocked_signals': list(self.state.blocked_signals),
            'intercepted': self.state.intercepted[-10:],  # Last 10
        }
