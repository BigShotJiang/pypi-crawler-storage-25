"""
/proc filesystem bypass for anti-debugging.

Patches /proc-based anti-debugging techniques:
- /proc/self/status - TracerPid, State
- /proc/self/stat - Process state
- /proc/self/maps - Memory mappings (hide debugger libraries)
- /proc/self/cmdline - Command line
- /proc/self/fd - File descriptors
- /proc/self/wchan - Wait channel
- /proc/self/task - Thread info
- /proc/<pid>/status - Same for specific PIDs
- /proc/net/tcp - Socket connections (debugger ports)

Techniques:
1. Hide TracerPid in status files
2. Filter suspicious libraries from maps
3. Hide debugger file descriptors
4. Spoof wait channel to appear non-debugged
"""

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ...core.emulator import Emulator

logger = logging.getLogger(__name__)


# Libraries that indicate debugging
DEBUGGER_LIBRARIES = {
    'libfrida',
    'frida-agent',
    'frida-gadget',
    'libxposed',
    'substrate',
    'cydia',
    'libsubstrate',
    'libandroidsupport',
    'libc++_shared',  # Sometimes injected
    'libssl_hook',
    'libmemtrack',
    'libgdb',
    'gdbserver',
    'lldb-server',
    'android_server',  # IDA
    'android_server64',
    'hluda-server',
    'jdwp',
}

# Suspicious ports (debugger default ports)
DEBUGGER_PORTS = {
    23946,   # Frida default
    27042,   # Frida
    27043,   # Frida
    5037,    # ADB
    5555,    # ADB wireless
    5039,    # GDB server
    23456,   # IDA Android server
    23457,   # IDA
    8000,    # Various
    8700,    # JDWP
    8600,    # JDWP
}


@dataclass
class ProcState:
    """Tracks /proc bypass state."""
    # Hidden libraries
    hidden_libraries: set[str] = field(default_factory=lambda: DEBUGGER_LIBRARIES.copy())

    # Hidden ports
    hidden_ports: set[int] = field(default_factory=lambda: DEBUGGER_PORTS.copy())

    # Access counts
    status_reads: int = 0
    maps_reads: int = 0
    cmdline_reads: int = 0
    net_reads: int = 0

    # Custom /proc file overrides
    file_overrides: dict[str, bytes] = field(default_factory=dict)


class ProcBypass:
    """
    Bypass /proc filesystem-based anti-debugging.
    
    Many Android apps check various /proc files to detect debugging:
    - TracerPid in /proc/self/status
    - Debugger libraries in /proc/self/maps
    - Debugger sockets in /proc/net/tcp
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.state = ProcState()
        self._enabled = False

    def enable(self) -> None:
        """Enable /proc bypass."""
        if self._enabled:
            return

        self._enabled = True
        self.state = ProcState()

        logger.info("Enabling /proc bypass")

        # Register virtual file handlers
        self._setup_virtual_files()

    def disable(self) -> None:
        """Disable /proc bypass."""
        if not self._enabled:
            return

        self._enabled = False
        logger.info("Disabled /proc bypass")

    def add_hidden_library(self, name: str) -> None:
        """Add a library name to hide from /proc/self/maps."""
        self.state.hidden_libraries.add(name.lower())

    def add_hidden_port(self, port: int) -> None:
        """Add a port to hide from /proc/net/tcp."""
        self.state.hidden_ports.add(port)

    def set_file_override(self, path: str, content: bytes) -> None:
        """Set custom content for a /proc file."""
        self.state.file_overrides[path] = content

    def _setup_virtual_files(self) -> None:
        """Set up virtual file system handlers."""
        if not hasattr(self.emulator, 'virtual_filesystem'):
            return

        vfs = self.emulator.virtual_filesystem

        # Register dynamic file generators
        files = {
            '/proc/self/status': self._generate_status,
            '/proc/self/stat': self._generate_stat,
            '/proc/self/maps': self._generate_maps,
            '/proc/self/cmdline': self._generate_cmdline,
            '/proc/self/wchan': self._generate_wchan,
            '/proc/self/comm': self._generate_comm,
            '/proc/net/tcp': self._generate_net_tcp,
            '/proc/net/tcp6': self._generate_net_tcp6,
        }

        for path, generator in files.items():
            if hasattr(vfs, 'register_dynamic_file'):
                vfs.register_dynamic_file(path, generator)
            elif hasattr(vfs, 'add_file'):
                # Fallback: add static content
                try:
                    content = generator()
                    vfs.add_file(path, content)
                except Exception as e:
                    logger.warning(f"Failed to set up {path}: {e}")

    def _generate_status(self) -> bytes:
        """Generate /proc/self/status content."""
        self.state.status_reads += 1

        pid = getattr(self.emulator, 'pid', 1234)

        content = f"""Name:	app_process64
Umask:	0077
State:	S (sleeping)
Tgid:	{pid}
Ngid:	0
Pid:	{pid}
PPid:	1
TracerPid:	0
Uid:	10123	10123	10123	10123
Gid:	10123	10123	10123	10123
FDSize:	512
Groups:	3003 9997 20123 50123
NStgid:	{pid}
NSpid:	{pid}
NSpgid:	1
NSsid:	0
VmPeak:	 2345678 kB
VmSize:	 2123456 kB
VmLck:	       0 kB
VmPin:	       0 kB
VmHWM:	  234567 kB
VmRSS:	  198765 kB
RssAnon:	  123456 kB
RssFile:	   65432 kB
RssShmem:	       0 kB
VmData:	  567890 kB
VmStk:	    8192 kB
VmExe:	      64 kB
VmLib:	  123456 kB
VmPTE:	    1234 kB
VmSwap:	       0 kB
Threads:	23
SigQ:	0/12345
SigPnd:	0000000000000000
ShdPnd:	0000000000000000
SigBlk:	0000000080001204
SigIgn:	0000000000000000
SigCgt:	00000006400084f8
CapInh:	0000000000000000
CapPrm:	0000000000000000
CapEff:	0000000000000000
CapBnd:	0000000000000000
CapAmb:	0000000000000000
NoNewPrivs:	0
Seccomp:	2
Cpus_allowed:	ff
Cpus_allowed_list:	0-7
Mems_allowed:	1
Mems_allowed_list:	0
voluntary_ctxt_switches:	12345
nonvoluntary_ctxt_switches:	6789
"""
        return content.encode('utf-8')

    def _generate_stat(self) -> bytes:
        """Generate /proc/self/stat content."""
        pid = getattr(self.emulator, 'pid', 1234)

        # Format: pid (comm) state ppid pgrp session tty_nr tpgid flags ...
        # State 'S' = sleeping (not traced)
        content = (
            f"{pid} (app_process64) S 1 {pid} 0 0 -1 4194304 "
            f"12345 0 0 0 100 50 0 0 20 0 23 0 "
            f"123456789 2234567890 198765 18446744073709551615 "
            f"94849436672 94849436736 140735123456784 0 0 0 65536 "
            f"3670020 1266777851 0 0 0 17 3 0 0 0 0 0 "
            f"94849436784 94849436816 94849531904 140735123456789 "
            f"140735123456800 140735123456800 140735123456891 0\n"
        )
        return content.encode('utf-8')

    def _generate_maps(self) -> bytes:
        """Generate /proc/self/maps content (filtered)."""
        self.state.maps_reads += 1

        # Generate realistic maps without debugger libraries
        maps = []

        # App code
        base = 0x70000000
        maps.append(f"{base:08x}-{base+0x1000:08x} r-xp 00000000 fd:00 12345    /data/app/com.example.app/base.apk")
        maps.append(f"{base+0x1000:08x}-{base+0x2000:08x} r--p 00001000 fd:00 12345    /data/app/com.example.app/base.apk")
        maps.append(f"{base+0x2000:08x}-{base+0x3000:08x} rw-p 00002000 fd:00 12345    /data/app/com.example.app/base.apk")

        # System libraries (normal ones only)
        libs = [
            ('/system/lib64/libc.so', 0x7000000000, 0x100000),
            ('/system/lib64/libm.so', 0x7000100000, 0x50000),
            ('/system/lib64/libdl.so', 0x7000150000, 0x10000),
            ('/system/lib64/liblog.so', 0x7000160000, 0x20000),
            ('/system/lib64/libz.so', 0x7000180000, 0x30000),
            ('/system/lib64/libstdc++.so', 0x70001b0000, 0x50000),
            ('/system/lib64/libart.so', 0x7000200000, 0x500000),
            ('/system/lib64/libandroid_runtime.so', 0x7000700000, 0x300000),
            ('/system/lib64/libandroid.so', 0x7000a00000, 0x80000),
            ('/system/lib64/libnativehelper.so', 0x7000a80000, 0x20000),
            ('/system/lib64/libutils.so', 0x7000aa0000, 0x40000),
            ('/system/lib64/libcutils.so', 0x7000ae0000, 0x30000),
            ('/system/lib64/libbinder.so', 0x7000b10000, 0x80000),
            ('/system/lib64/libhwbinder.so', 0x7000b90000, 0x40000),
        ]

        for lib_path, addr, size in libs:
            # Check if this library should be hidden
            lib_name = lib_path.split('/')[-1].lower()
            should_hide = any(hidden in lib_name for hidden in self.state.hidden_libraries)

            if not should_hide:
                maps.append(f"{addr:016x}-{addr+size:016x} r-xp 00000000 fd:00 {hash(lib_path) % 100000:5d}    {lib_path}")
                maps.append(f"{addr+size:016x}-{addr+size+0x1000:016x} r--p {size:08x} fd:00 {hash(lib_path) % 100000:5d}    {lib_path}")
                maps.append(f"{addr+size+0x1000:016x}-{addr+size+0x2000:016x} rw-p {size+0x1000:08x} fd:00 {hash(lib_path) % 100000:5d}    {lib_path}")

        # Stack
        maps.append("7ffffffde000-7ffffffff000 rw-p 00000000 00:00 0          [stack]")

        # Heap
        maps.append("0000000010000000-0000000012000000 rw-p 00000000 00:00 0          [heap]")

        # vdso
        maps.append("7ffff7ffc000-7ffff7ffe000 r-xp 00000000 00:00 0          [vdso]")

        return '\n'.join(maps).encode('utf-8')

    def _generate_cmdline(self) -> bytes:
        """Generate /proc/self/cmdline content."""
        self.state.cmdline_reads += 1

        # Normal app command line (null-separated)
        return b"com.example.app\x00"

    def _generate_wchan(self) -> bytes:
        """Generate /proc/self/wchan content."""
        # Normal wait channel (not ptrace_stop or similar)
        return b"ep_poll\n"

    def _generate_comm(self) -> bytes:
        """Generate /proc/self/comm content."""
        return b"app_process64\n"

    def _generate_net_tcp(self) -> bytes:
        """Generate /proc/net/tcp content (filtered)."""
        self.state.net_reads += 1

        lines = [
            "  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode"
        ]

        # Normal connections (not debugger ports)
        normal_ports = [80, 443, 8080, 53]
        for i, port in enumerate(normal_ports):
            # Convert port to hex
            port_hex = f"{port:04X}"
            local = f"0100007F:{port_hex}"  # 127.0.0.1:port
            remote = "00000000:0000"
            lines.append(
                f"   {i}: {local} {remote} 0A 00000000:00000000 "
                f"00:00000000 00000000 10123        0 {12345+i} 1 0000000000000000 100 0 0 10 0"
            )

        return '\n'.join(lines).encode('utf-8')

    def _generate_net_tcp6(self) -> bytes:
        """Generate /proc/net/tcp6 content (filtered)."""
        lines = [
            "  sl  local_address                         remote_address                        st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode"
        ]

        # Normal IPv6 connections
        lines.append(
            "   0: 00000000000000000000000001000000:0050 00000000000000000000000000000000:0000 "
            "0A 00000000:00000000 00:00000000 00000000 10123        0 12345 1 0000000000000000 100 0 0 10 0"
        )

        return '\n'.join(lines).encode('utf-8')

    def filter_maps_content(self, original: bytes) -> bytes:
        """
        Filter debugger libraries from existing maps content.
        
        Use this to filter content that was read from actual files.
        """
        lines = original.decode('utf-8', errors='ignore').split('\n')
        filtered = []

        for line in lines:
            # Check if any hidden library is in this line
            line_lower = line.lower()
            should_hide = any(hidden in line_lower for hidden in self.state.hidden_libraries)

            if not should_hide:
                filtered.append(line)

        return '\n'.join(filtered).encode('utf-8')

    def filter_tcp_content(self, original: bytes) -> bytes:
        """
        Filter debugger ports from existing tcp content.
        """
        lines = original.decode('utf-8', errors='ignore').split('\n')
        filtered = []

        for line in lines:
            should_hide = False

            # Parse port from line (format: ... local_addr:PORT ...)
            parts = line.split()
            if len(parts) >= 2 and ':' in parts[1]:
                try:
                    port_hex = parts[1].split(':')[1]
                    port = int(port_hex, 16)
                    if port in self.state.hidden_ports:
                        should_hide = True
                except (ValueError, IndexError):
                    pass

            if not should_hide:
                filtered.append(line)

        return '\n'.join(filtered).encode('utf-8')

    def get_stats(self) -> dict[str, Any]:
        """Get /proc bypass statistics."""
        return {
            'enabled': self._enabled,
            'status_reads': self.state.status_reads,
            'maps_reads': self.state.maps_reads,
            'cmdline_reads': self.state.cmdline_reads,
            'net_reads': self.state.net_reads,
            'hidden_libraries': list(self.state.hidden_libraries),
            'hidden_ports': list(self.state.hidden_ports),
        }
