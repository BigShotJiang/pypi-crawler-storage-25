"""
Timing bypass for anti-debugging.

Patches timing functions to prevent timing-based debug detection:
- gettimeofday() - Returns consistent/accelerated time
- clock_gettime() - Patches CLOCK_REALTIME, CLOCK_MONOTONIC, etc.
- time() - Returns consistent time
- clock() - CPU time bypass
- nanosleep() - Instant return or reduced sleep
- usleep() / sleep() - Reduced delays

Techniques:
1. Time Acceleration: Speed up time to avoid detection of breakpoint delays
2. Time Freezing: Return same time for repeated calls
3. Consistent Deltas: Maintain realistic but debugger-invisible time deltas
"""

import logging
import struct
import time as real_time
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ...core.emulator import Emulator

logger = logging.getLogger(__name__)


class ClockId(IntEnum):
    """Clock IDs for clock_gettime."""
    CLOCK_REALTIME = 0
    CLOCK_MONOTONIC = 1
    CLOCK_PROCESS_CPUTIME_ID = 2
    CLOCK_THREAD_CPUTIME_ID = 3
    CLOCK_MONOTONIC_RAW = 4
    CLOCK_REALTIME_COARSE = 5
    CLOCK_MONOTONIC_COARSE = 6
    CLOCK_BOOTTIME = 7
    CLOCK_REALTIME_ALARM = 8
    CLOCK_BOOTTIME_ALARM = 9


@dataclass
class TimingState:
    """Tracks timing state for bypass."""
    # Base timestamps (when bypass was enabled)
    base_real_time: float = field(default_factory=real_time.time)
    base_monotonic: float = field(default_factory=real_time.monotonic)

    # Emulated timestamps
    emulated_time: float = 0.0
    emulated_monotonic: float = 0.0

    # Time acceleration factor (1.0 = real time, >1 = faster)
    acceleration: float = 1.0

    # Time freeze mode
    frozen: bool = False
    frozen_time: float = 0.0

    # Call counters for detection
    gettimeofday_calls: int = 0
    clock_gettime_calls: int = 0
    time_calls: int = 0

    # Delta tracking (for detecting timing checks)
    last_times: dict[str, float] = field(default_factory=dict)

    # Minimum delta to report between calls (microseconds)
    min_delta_us: int = 100


class TimingBypass:
    """
    Bypass timing-based anti-debugging techniques.
    
    Many anti-debugging techniques measure execution time to detect
    if breakpoints or single-stepping is occurring. This module patches
    all timing functions to return controlled values.
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.state = TimingState()
        self._enabled = False
        self._hooks: dict[str, Any] = {}

        # Syscall numbers for ARM64
        self._syscalls_arm64 = {
            'gettimeofday': 169,
            'clock_gettime': 113,
            'clock_getres': 114,
            'nanosleep': 101,
        }

        # Syscall numbers for ARM32
        self._syscalls_arm32 = {
            'gettimeofday': 78,
            'clock_gettime': 263,
            'clock_getres': 264,
            'nanosleep': 162,
        }

    def enable(self) -> None:
        """Enable timing bypass."""
        if self._enabled:
            return

        self._enabled = True
        self.state = TimingState()

        logger.info("Enabling timing bypass")

        # Hook libc functions
        self._hook_libc_functions()

        # Hook syscalls
        self._hook_syscalls()

    def disable(self) -> None:
        """Disable timing bypass."""
        if not self._enabled:
            return

        self._enabled = False

        # Remove hooks
        for name, hook in self._hooks.items():
            if hasattr(hook, 'remove'):
                hook.remove()
        self._hooks.clear()

        logger.info("Disabled timing bypass")

    def set_acceleration(self, factor: float) -> None:
        """
        Set time acceleration factor.
        
        Args:
            factor: Time multiplier (1.0 = real, 2.0 = twice as fast)
        """
        self.state.acceleration = factor
        logger.debug(f"Time acceleration set to {factor}x")

    def freeze_time(self, frozen: bool = True) -> None:
        """
        Freeze or unfreeze time.
        
        When frozen, all timing calls return the same value.
        """
        if frozen and not self.state.frozen:
            self.state.frozen_time = self._get_emulated_time()
        self.state.frozen = frozen
        logger.debug(f"Time {'frozen' if frozen else 'unfrozen'}")

    def set_min_delta(self, microseconds: int) -> None:
        """
        Set minimum time delta between calls.
        
        This prevents detection of "instant" execution.
        """
        self.state.min_delta_us = microseconds

    def _get_emulated_time(self) -> float:
        """Get current emulated time."""
        if self.state.frozen:
            return self.state.frozen_time

        # Calculate elapsed real time
        elapsed = real_time.time() - self.state.base_real_time

        # Apply acceleration
        return self.state.base_real_time + (elapsed * self.state.acceleration)

    def _get_emulated_monotonic(self) -> float:
        """Get current emulated monotonic time."""
        if self.state.frozen:
            return self.state.frozen_time

        elapsed = real_time.monotonic() - self.state.base_monotonic
        return elapsed * self.state.acceleration

    def _hook_libc_functions(self) -> None:
        """Hook libc timing functions."""
        # These would hook the actual libc functions if loaded
        # For now, the syscall hooks handle most cases
        pass

    def _hook_syscalls(self) -> None:
        """Hook timing-related syscalls."""
        if not hasattr(self.emulator, 'syscall_handler'):
            return

        handler = self.emulator.syscall_handler

        # Hook gettimeofday
        handler.register_hook('gettimeofday', self._handle_gettimeofday)

        # Hook clock_gettime
        handler.register_hook('clock_gettime', self._handle_clock_gettime)

        # Hook clock_getres
        handler.register_hook('clock_getres', self._handle_clock_getres)

        # Hook nanosleep
        handler.register_hook('nanosleep', self._handle_nanosleep)

    def _handle_gettimeofday(self, emu: 'Emulator', tv_ptr: int, tz_ptr: int) -> int:
        """
        Handle gettimeofday syscall.
        
        struct timeval {
            time_t      tv_sec;   // seconds
            suseconds_t tv_usec;  // microseconds
        };
        """
        self.state.gettimeofday_calls += 1

        if tv_ptr:
            now = self._get_emulated_time()

            # Apply minimum delta if we've been called recently
            key = f'gettimeofday_{tv_ptr}'
            if key in self.state.last_times:
                last = self.state.last_times[key]
                min_delta = self.state.min_delta_us / 1_000_000
                if now - last < min_delta:
                    now = last + min_delta
            self.state.last_times[key] = now

            tv_sec = int(now)
            tv_usec = int((now - tv_sec) * 1_000_000)

            if emu.is_64bit:
                # 64-bit: time_t is 8 bytes
                data = struct.pack('<QQ', tv_sec, tv_usec)
            else:
                # 32-bit: time_t is 4 bytes
                data = struct.pack('<II', tv_sec, tv_usec)

            emu.memory.write(tv_ptr, data)

        if tz_ptr:
            # Timezone struct (usually ignored)
            if emu.is_64bit:
                data = struct.pack('<ii', 0, 0)  # UTC, no DST
            else:
                data = struct.pack('<ii', 0, 0)
            emu.memory.write(tz_ptr, data)

        logger.debug(f"gettimeofday: call #{self.state.gettimeofday_calls}")
        return 0

    def _handle_clock_gettime(self, emu: 'Emulator', clock_id: int, tp_ptr: int) -> int:
        """
        Handle clock_gettime syscall.
        
        struct timespec {
            time_t   tv_sec;   // seconds
            long     tv_nsec;  // nanoseconds
        };
        """
        self.state.clock_gettime_calls += 1

        if not tp_ptr:
            return -1  # EFAULT

        # Get appropriate time based on clock type
        if clock_id in (ClockId.CLOCK_REALTIME, ClockId.CLOCK_REALTIME_COARSE,
                        ClockId.CLOCK_REALTIME_ALARM):
            now = self._get_emulated_time()
        elif clock_id in (ClockId.CLOCK_MONOTONIC, ClockId.CLOCK_MONOTONIC_RAW,
                          ClockId.CLOCK_MONOTONIC_COARSE, ClockId.CLOCK_BOOTTIME,
                          ClockId.CLOCK_BOOTTIME_ALARM):
            now = self._get_emulated_monotonic()
        elif clock_id in (ClockId.CLOCK_PROCESS_CPUTIME_ID,
                          ClockId.CLOCK_THREAD_CPUTIME_ID):
            # CPU time - return minimal advancing time
            now = self.state.clock_gettime_calls * (self.state.min_delta_us / 1_000_000)
        else:
            now = self._get_emulated_time()

        # Apply minimum delta
        key = f'clock_gettime_{clock_id}'
        if key in self.state.last_times:
            last = self.state.last_times[key]
            min_delta = self.state.min_delta_us / 1_000_000
            if now - last < min_delta:
                now = last + min_delta
        self.state.last_times[key] = now

        tv_sec = int(now)
        tv_nsec = int((now - tv_sec) * 1_000_000_000)

        if emu.is_64bit:
            data = struct.pack('<QQ', tv_sec, tv_nsec)
        else:
            data = struct.pack('<II', tv_sec, tv_nsec)

        emu.memory.write(tp_ptr, data)

        logger.debug(f"clock_gettime({clock_id}): call #{self.state.clock_gettime_calls}")
        return 0

    def _handle_clock_getres(self, emu: 'Emulator', clock_id: int, res_ptr: int) -> int:
        """Handle clock_getres syscall - return resolution."""
        if not res_ptr:
            return 0

        # Return nanosecond resolution for all clocks
        if emu.is_64bit:
            data = struct.pack('<QQ', 0, 1)  # 1 nanosecond
        else:
            data = struct.pack('<II', 0, 1)

        emu.memory.write(res_ptr, data)
        return 0

    def _handle_nanosleep(self, emu: 'Emulator', req_ptr: int, rem_ptr: int) -> int:
        """
        Handle nanosleep syscall.
        
        Can be used to detect debugging by measuring actual sleep time.
        We return immediately or with minimal delay.
        """
        if req_ptr:
            # Read requested sleep time
            if emu.is_64bit:
                data = emu.memory.read(req_ptr, 16)
                tv_sec, tv_nsec = struct.unpack('<QQ', data)
            else:
                data = emu.memory.read(req_ptr, 8)
                tv_sec, tv_nsec = struct.unpack('<II', data)

            # Advance emulated time by sleep duration (accelerated)
            sleep_time = tv_sec + (tv_nsec / 1_000_000_000)
            self.state.base_real_time -= sleep_time / self.state.acceleration

            logger.debug(f"nanosleep: requested {sleep_time}s, returning immediately")

        # Set remaining time to 0
        if rem_ptr:
            if emu.is_64bit:
                data = struct.pack('<QQ', 0, 0)
            else:
                data = struct.pack('<II', 0, 0)
            emu.memory.write(rem_ptr, data)

        return 0

    def get_stats(self) -> dict[str, Any]:
        """Get timing bypass statistics."""
        return {
            'enabled': self._enabled,
            'gettimeofday_calls': self.state.gettimeofday_calls,
            'clock_gettime_calls': self.state.clock_gettime_calls,
            'time_calls': self.state.time_calls,
            'acceleration': self.state.acceleration,
            'frozen': self.state.frozen,
            'min_delta_us': self.state.min_delta_us,
        }
