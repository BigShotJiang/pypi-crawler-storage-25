"""
Anti-debugging bypass module for PyUniDbg.

Provides comprehensive anti-debug detection bypasses:
- Timing checks (gettimeofday, clock_gettime, time)
- ptrace detection
- /proc/self/status, /proc/self/maps checks
- Signal handlers (SIGTRAP, SIGSTOP)
- Breakpoint detection
- Debugger port checks
- Java-level debugging checks

Usage:
    from pyunidbg.android.antidebug import AntiDebugBypass
    
    bypass = AntiDebugBypass(emulator)
    bypass.enable_all()  # Enable all bypasses
    
    # Or enable specific bypasses
    bypass.enable_timing_bypass()
    bypass.enable_ptrace_bypass()
    bypass.enable_proc_bypass()
"""

from .bypass import AntiDebugBypass
from .java_debug import JavaDebugBypass
from .proc import ProcBypass
from .ptrace import PtraceBypass
from .signals import SignalBypass
from .timing import TimingBypass

__all__ = [
    'AntiDebugBypass',
    'TimingBypass',
    'PtraceBypass',
    'ProcBypass',
    'SignalBypass',
    'JavaDebugBypass',
]
