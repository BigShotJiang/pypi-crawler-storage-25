"""
ptrace bypass for anti-debugging.

Patches ptrace-related anti-debugging techniques:
- ptrace(PTRACE_TRACEME) - Self-attach detection
- ptrace(PTRACE_ATTACH) - External attach detection
- /proc/self/status TracerPid check
- prctl(PR_SET_DUMPABLE) - Core dump prevention

Techniques:
1. Return success for PTRACE_TRACEME (prevent "already traced" detection)
2. Spoof TracerPid in /proc/self/status to 0
3. Block actual ptrace operations
4. Handle fork-based detection
"""

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ...core.emulator import Emulator

logger = logging.getLogger(__name__)


class PtraceRequest(IntEnum):
    """ptrace request types."""
    PTRACE_TRACEME = 0
    PTRACE_PEEKTEXT = 1
    PTRACE_PEEKDATA = 2
    PTRACE_PEEKUSER = 3
    PTRACE_POKETEXT = 4
    PTRACE_POKEDATA = 5
    PTRACE_POKEUSER = 6
    PTRACE_CONT = 7
    PTRACE_KILL = 8
    PTRACE_SINGLESTEP = 9
    PTRACE_GETREGS = 12
    PTRACE_SETREGS = 13
    PTRACE_GETFPREGS = 14
    PTRACE_SETFPREGS = 15
    PTRACE_ATTACH = 16
    PTRACE_DETACH = 17
    PTRACE_GETFPXREGS = 18
    PTRACE_SETFPXREGS = 19
    PTRACE_SYSCALL = 24
    PTRACE_SETOPTIONS = 0x4200
    PTRACE_GETEVENTMSG = 0x4201
    PTRACE_GETSIGINFO = 0x4202
    PTRACE_SETSIGINFO = 0x4203
    PTRACE_GETREGSET = 0x4204
    PTRACE_SETREGSET = 0x4205
    PTRACE_SEIZE = 0x4206
    PTRACE_INTERRUPT = 0x4207
    PTRACE_LISTEN = 0x4208
    PTRACE_PEEKSIGINFO = 0x4209


class PrctlOption(IntEnum):
    """prctl options."""
    PR_SET_PDEATHSIG = 1
    PR_GET_PDEATHSIG = 2
    PR_GET_DUMPABLE = 3
    PR_SET_DUMPABLE = 4
    PR_GET_UNALIGN = 5
    PR_SET_UNALIGN = 6
    PR_GET_KEEPCAPS = 7
    PR_SET_KEEPCAPS = 8
    PR_GET_FPEMU = 9
    PR_SET_FPEMU = 10
    PR_GET_FPEXC = 11
    PR_SET_FPEXC = 12
    PR_GET_TIMING = 13
    PR_SET_TIMING = 14
    PR_SET_NAME = 15
    PR_GET_NAME = 16
    PR_GET_ENDIAN = 19
    PR_SET_ENDIAN = 20
    PR_GET_SECCOMP = 21
    PR_SET_SECCOMP = 22
    PR_CAPBSET_READ = 23
    PR_CAPBSET_DROP = 24
    PR_GET_TSC = 25
    PR_SET_TSC = 26
    PR_GET_SECUREBITS = 27
    PR_SET_SECUREBITS = 28
    PR_SET_TIMERSLACK = 29
    PR_GET_TIMERSLACK = 30
    PR_SET_NO_NEW_PRIVS = 38
    PR_GET_NO_NEW_PRIVS = 39
    PR_SET_PTRACER = 0x59616d61  # "Yama"


@dataclass
class PtraceState:
    """Tracks ptrace bypass state."""
    # Whether we're pretending to be traced
    fake_traced: bool = False

    # Fake tracer PID (0 = not traced)
    tracer_pid: int = 0

    # Call counters
    ptrace_calls: int = 0
    prctl_calls: int = 0

    # Blocked operations log
    blocked_ops: list = field(default_factory=list)

    # Dumpable state
    dumpable: int = 1


class PtraceBypass:
    """
    Bypass ptrace-based anti-debugging techniques.
    
    Common techniques this bypasses:
    1. ptrace(PTRACE_TRACEME) to check if already being debugged
    2. Reading /proc/self/status for TracerPid
    3. Fork+ptrace child to detect debugging
    4. prctl checks for dumpable state
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.state = PtraceState()
        self._enabled = False
        self._original_handlers: dict[str, Callable] = {}

    def enable(self) -> None:
        """Enable ptrace bypass."""
        if self._enabled:
            return

        self._enabled = True
        self.state = PtraceState()

        logger.info("Enabling ptrace bypass")

        # Hook ptrace syscall
        self._hook_ptrace()

        # Hook prctl syscall
        self._hook_prctl()

        # Patch /proc/self/status virtual file
        self._patch_proc_status()

    def disable(self) -> None:
        """Disable ptrace bypass."""
        if not self._enabled:
            return

        self._enabled = False
        logger.info("Disabled ptrace bypass")

    def set_tracer_pid(self, pid: int) -> None:
        """
        Set fake tracer PID.
        
        Args:
            pid: PID to report (0 = not traced)
        """
        self.state.tracer_pid = pid
        logger.debug(f"Set fake TracerPid to {pid}")

    def _hook_ptrace(self) -> None:
        """Hook ptrace syscall."""
        if not hasattr(self.emulator, 'syscall_handler'):
            return

        handler = self.emulator.syscall_handler
        handler.register_hook('ptrace', self._handle_ptrace)

    def _hook_prctl(self) -> None:
        """Hook prctl syscall."""
        if not hasattr(self.emulator, 'syscall_handler'):
            return

        handler = self.emulator.syscall_handler
        handler.register_hook('prctl', self._handle_prctl)

    def _patch_proc_status(self) -> None:
        """Patch /proc/self/status to hide tracer."""
        if not hasattr(self.emulator, 'virtual_filesystem'):
            return

        vfs = self.emulator.virtual_filesystem

        # Register a dynamic content generator for /proc/self/status
        def status_generator():
            return self._generate_proc_status()

        # Override the virtual file
        if hasattr(vfs, 'register_dynamic_file'):
            vfs.register_dynamic_file('/proc/self/status', status_generator)

    def _generate_proc_status(self) -> bytes:
        """Generate fake /proc/self/status content."""
        status = f"""Name:	app_process64
Umask:	0077
State:	S (sleeping)
Tgid:	{self.emulator.pid if hasattr(self.emulator, 'pid') else 1234}
Ngid:	0
Pid:	{self.emulator.pid if hasattr(self.emulator, 'pid') else 1234}
PPid:	1
TracerPid:	{self.state.tracer_pid}
Uid:	10123	10123	10123	10123
Gid:	10123	10123	10123	10123
FDSize:	512
Groups:	3003 9997 20123 50123
NStgid:	{self.emulator.pid if hasattr(self.emulator, 'pid') else 1234}
NSpid:	{self.emulator.pid if hasattr(self.emulator, 'pid') else 1234}
NSpgid:	1
NSsid:	0
VmPeak:	 2345678 kB
VmSize:	 2123456 kB
VmLck:	       0 kB
VmPin:	       0 kB
VmHWM:	  234567 kB
VmRSS:	  198765 kB
RssAnon:	  123456 kB
RssFile:	   65432 kB
RssShmem:	       0 kB
VmData:	  567890 kB
VmStk:	    8192 kB
VmExe:	      64 kB
VmLib:	  123456 kB
VmPTE:	    1234 kB
VmSwap:	       0 kB
Threads:	23
SigQ:	0/12345
SigPnd:	0000000000000000
ShdPnd:	0000000000000000
SigBlk:	0000000080001204
SigIgn:	0000000000000000
SigCgt:	00000006400084f8
CapInh:	0000000000000000
CapPrm:	0000000000000000
CapEff:	0000000000000000
CapBnd:	0000000000000000
CapAmb:	0000000000000000
NoNewPrivs:	0
Seccomp:	2
Cpus_allowed:	ff
Cpus_allowed_list:	0-7
Mems_allowed:	1
Mems_allowed_list:	0
voluntary_ctxt_switches:	12345
nonvoluntary_ctxt_switches:	6789
"""
        return status.encode('utf-8')

    def _handle_ptrace(self, emu: 'Emulator', request: int, pid: int,
                       addr: int, data: int) -> int:
        """
        Handle ptrace syscall.
        
        Returns:
            0 on success, -1 on failure
        """
        self.state.ptrace_calls += 1

        try:
            req_name = PtraceRequest(request).name
        except ValueError:
            req_name = f"UNKNOWN({request})"

        logger.debug(f"ptrace({req_name}, pid={pid}, addr=0x{addr:x}, data=0x{data:x})")

        if request == PtraceRequest.PTRACE_TRACEME:
            # App is checking if it's being traced
            # Return success (0) - pretend it's not traced
            if self.state.fake_traced:
                # Already "traced" - return error
                logger.debug("ptrace(TRACEME): Returning -1 (already traced)")
                return -1
            else:
                # Not traced - return success and mark as "traced"
                self.state.fake_traced = True
                logger.debug("ptrace(TRACEME): Returning 0 (success)")
                return 0

        elif request == PtraceRequest.PTRACE_ATTACH:
            # Trying to attach to another process
            # Log and block
            self.state.blocked_ops.append(('ATTACH', pid))
            logger.debug(f"ptrace(ATTACH, {pid}): Blocked")
            return -1  # EPERM

        elif request == PtraceRequest.PTRACE_PEEKDATA:
            # Reading memory - might be checking for breakpoints
            logger.debug(f"ptrace(PEEKDATA, addr=0x{addr:x})")
            return 0

        elif request == PtraceRequest.PTRACE_POKEDATA:
            # Writing memory - block potentially dangerous writes
            self.state.blocked_ops.append(('POKEDATA', addr, data))
            logger.debug(f"ptrace(POKEDATA, addr=0x{addr:x}): Blocked")
            return -1

        elif request == PtraceRequest.PTRACE_CONT:
            # Continue execution
            return 0

        elif request == PtraceRequest.PTRACE_DETACH:
            # Detach
            self.state.fake_traced = False
            return 0

        elif request == PtraceRequest.PTRACE_SEIZE:
            # Seize without stopping
            self.state.blocked_ops.append(('SEIZE', pid))
            return -1

        else:
            # Default: allow other operations
            logger.debug(f"ptrace({req_name}): Allowing")
            return 0

    def _handle_prctl(self, emu: 'Emulator', option: int, arg2: int,
                      arg3: int, arg4: int, arg5: int) -> int:
        """Handle prctl syscall."""
        self.state.prctl_calls += 1

        try:
            opt_name = PrctlOption(option).name
        except ValueError:
            opt_name = f"UNKNOWN({option})"

        logger.debug(f"prctl({opt_name}, {arg2}, {arg3}, {arg4}, {arg5})")

        if option == PrctlOption.PR_GET_DUMPABLE:
            # Return dumpable state
            return self.state.dumpable

        elif option == PrctlOption.PR_SET_DUMPABLE:
            # Set dumpable state
            self.state.dumpable = arg2
            return 0

        elif option == PrctlOption.PR_SET_PTRACER:
            # Allow/deny specific tracer
            # Just return success
            return 0

        elif option == PrctlOption.PR_SET_NAME:
            # Set thread name - allow
            return 0

        elif option == PrctlOption.PR_GET_NAME:
            # Get thread name
            if arg2:
                name = b"main\x00" + b"\x00" * 11  # 16 bytes
                emu.memory.write(arg2, name)
            return 0

        elif option == PrctlOption.PR_SET_SECCOMP:
            # Seccomp setup - might be used to restrict syscalls
            logger.debug("prctl(SET_SECCOMP): Blocked")
            return -1

        elif option == PrctlOption.PR_GET_SECCOMP:
            # Return seccomp mode
            return 0  # Disabled

        else:
            # Default: return success
            return 0

    def get_stats(self) -> dict[str, Any]:
        """Get ptrace bypass statistics."""
        return {
            'enabled': self._enabled,
            'ptrace_calls': self.state.ptrace_calls,
            'prctl_calls': self.state.prctl_calls,
            'fake_traced': self.state.fake_traced,
            'tracer_pid': self.state.tracer_pid,
            'blocked_ops': self.state.blocked_ops[-10:],  # Last 10
        }
