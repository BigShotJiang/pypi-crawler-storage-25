"""
Main anti-debugging bypass module.

Combines all bypass techniques:
- Timing bypass (gettimeofday, clock_gettime, nanosleep)
- ptrace bypass (TRACEME, /proc/status TracerPid)
- /proc bypass (maps, status, net/tcp)
- Signal bypass (SIGTRAP, SIGSTOP)
- Java bypass (Debug.isDebuggerConnected, properties)

Usage:
    from pyunidbg.android.antidebug import AntiDebugBypass
    
    bypass = AntiDebugBypass(emulator)
    
    # Enable all bypasses
    bypass.enable_all()
    
    # Or enable specific ones
    bypass.enable_timing()
    bypass.enable_ptrace()
    bypass.enable_proc()
    bypass.enable_signals()
    bypass.enable_java()
    
    # Configuration
    bypass.timing.set_acceleration(1.0)  # Real-time
    bypass.timing.freeze_time(True)      # Freeze time
    bypass.proc.add_hidden_library('mylib.so')
    
    # Get stats
    print(bypass.get_stats())
"""

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from .java_debug import JavaDebugBypass
from .proc import ProcBypass
from .ptrace import PtraceBypass
from .signals import SignalBypass
from .timing import TimingBypass

if TYPE_CHECKING:
    from ...core.emulator import Emulator

logger = logging.getLogger(__name__)


@dataclass
class BypassProfile:
    """
    Predefined bypass profiles for different scenarios.
    """
    name: str
    timing: bool = True
    ptrace: bool = True
    proc: bool = True
    signals: bool = True
    java: bool = True

    # Timing settings
    time_acceleration: float = 1.0
    time_frozen: bool = False
    min_time_delta_us: int = 100

    # Additional hidden items
    extra_hidden_libraries: list[str] = None
    extra_hidden_ports: list[int] = None


# Predefined profiles
PROFILE_FULL = BypassProfile(
    name="full",
    timing=True,
    ptrace=True,
    proc=True,
    signals=True,
    java=True,
)

PROFILE_MINIMAL = BypassProfile(
    name="minimal",
    timing=True,
    ptrace=True,
    proc=False,
    signals=False,
    java=False,
)

PROFILE_FRIDA = BypassProfile(
    name="frida",
    timing=True,
    ptrace=True,
    proc=True,
    signals=True,
    java=True,
    extra_hidden_libraries=['frida', 'gadget', 'agent'],
    extra_hidden_ports=[27042, 27043, 23946],
)

PROFILE_IDA = BypassProfile(
    name="ida",
    timing=True,
    ptrace=True,
    proc=True,
    signals=True,
    java=False,
    extra_hidden_libraries=['android_server'],
    extra_hidden_ports=[23456, 23457],
)


class AntiDebugBypass:
    """
    Comprehensive anti-debugging bypass for Android emulation.
    
    This class combines multiple bypass techniques to prevent
    Android applications from detecting they are being debugged
    or analyzed.
    
    Example:
        emu = AndroidEmulator()
        bypass = AntiDebugBypass(emu)
        bypass.enable_all()
        
        # Now run the app - anti-debug checks will be bypassed
        emu.call_function(...)
    """

    def __init__(self, emulator: 'Emulator'):
        """
        Initialize anti-debug bypass.
        
        Args:
            emulator: The emulator instance
        """
        self.emulator = emulator

        # Create bypass modules
        self.timing = TimingBypass(emulator)
        self.ptrace = PtraceBypass(emulator)
        self.proc = ProcBypass(emulator)
        self.signals = SignalBypass(emulator)
        self.java = JavaDebugBypass(emulator)

        self._all_bypasses = [
            self.timing,
            self.ptrace,
            self.proc,
            self.signals,
            self.java,
        ]

        logger.info("AntiDebugBypass initialized")

    def enable_all(self) -> 'AntiDebugBypass':
        """
        Enable all anti-debug bypasses.
        
        Returns:
            self for chaining
        """
        logger.info("Enabling all anti-debug bypasses")

        for bypass in self._all_bypasses:
            bypass.enable()

        return self

    def disable_all(self) -> 'AntiDebugBypass':
        """
        Disable all anti-debug bypasses.
        
        Returns:
            self for chaining
        """
        logger.info("Disabling all anti-debug bypasses")

        for bypass in self._all_bypasses:
            bypass.disable()

        return self

    def enable_timing(self) -> 'AntiDebugBypass':
        """Enable timing bypass."""
        self.timing.enable()
        return self

    def enable_ptrace(self) -> 'AntiDebugBypass':
        """Enable ptrace bypass."""
        self.ptrace.enable()
        return self

    def enable_proc(self) -> 'AntiDebugBypass':
        """Enable /proc bypass."""
        self.proc.enable()
        return self

    def enable_signals(self) -> 'AntiDebugBypass':
        """Enable signal bypass."""
        self.signals.enable()
        return self

    def enable_java(self) -> 'AntiDebugBypass':
        """Enable Java-level bypass."""
        self.java.enable()
        return self

    def apply_profile(self, profile: BypassProfile) -> 'AntiDebugBypass':
        """
        Apply a bypass profile.
        
        Args:
            profile: Profile to apply
            
        Returns:
            self for chaining
        """
        logger.info(f"Applying bypass profile: {profile.name}")

        # Enable/disable each bypass
        if profile.timing:
            self.timing.enable()
            self.timing.set_acceleration(profile.time_acceleration)
            self.timing.freeze_time(profile.time_frozen)
            self.timing.set_min_delta(profile.min_time_delta_us)

        if profile.ptrace:
            self.ptrace.enable()

        if profile.proc:
            self.proc.enable()
            if profile.extra_hidden_libraries:
                for lib in profile.extra_hidden_libraries:
                    self.proc.add_hidden_library(lib)
            if profile.extra_hidden_ports:
                for port in profile.extra_hidden_ports:
                    self.proc.add_hidden_port(port)

        if profile.signals:
            self.signals.enable()

        if profile.java:
            self.java.enable()

        return self

    def use_frida_bypass(self) -> 'AntiDebugBypass':
        """
        Apply Frida-specific bypass profile.
        
        Hides Frida-related libraries and ports.
        """
        return self.apply_profile(PROFILE_FRIDA)

    def use_ida_bypass(self) -> 'AntiDebugBypass':
        """
        Apply IDA-specific bypass profile.
        
        Hides IDA Android server and ports.
        """
        return self.apply_profile(PROFILE_IDA)

    def use_minimal_bypass(self) -> 'AntiDebugBypass':
        """
        Apply minimal bypass profile.
        
        Only timing and ptrace bypasses.
        """
        return self.apply_profile(PROFILE_MINIMAL)

    def hide_library(self, name: str) -> 'AntiDebugBypass':
        """
        Hide a library from /proc/self/maps.
        
        Args:
            name: Library name pattern to hide
        """
        self.proc.add_hidden_library(name)
        return self

    def hide_port(self, port: int) -> 'AntiDebugBypass':
        """
        Hide a port from /proc/net/tcp.
        
        Args:
            port: Port number to hide
        """
        self.proc.add_hidden_port(port)
        return self

    def set_time_acceleration(self, factor: float) -> 'AntiDebugBypass':
        """
        Set time acceleration factor.
        
        Args:
            factor: Time multiplier (1.0 = real, 0.5 = half speed, 2.0 = double)
        """
        self.timing.set_acceleration(factor)
        return self

    def freeze_time(self, frozen: bool = True) -> 'AntiDebugBypass':
        """
        Freeze or unfreeze time.
        
        When frozen, all time-related calls return the same value.
        """
        self.timing.freeze_time(frozen)
        return self

    def set_tracer_pid(self, pid: int) -> 'AntiDebugBypass':
        """
        Set the TracerPid value in /proc/self/status.
        
        Args:
            pid: PID to report (0 = not traced)
        """
        self.ptrace.set_tracer_pid(pid)
        return self

    def set_system_property(self, name: str, value: str) -> 'AntiDebugBypass':
        """
        Set a system property value.
        
        Args:
            name: Property name (e.g., 'ro.debuggable')
            value: Property value (e.g., '0')
        """
        self.java.set_property(name, value)
        return self

    def get_stats(self) -> dict[str, Any]:
        """
        Get statistics from all bypass modules.
        
        Returns:
            Dictionary with stats from each module
        """
        return {
            'timing': self.timing.get_stats(),
            'ptrace': self.ptrace.get_stats(),
            'proc': self.proc.get_stats(),
            'signals': self.signals.get_stats(),
            'java': self.java.get_stats(),
        }

    def get_summary(self) -> str:
        """
        Get a human-readable summary of bypass activity.
        
        Returns:
            Summary string
        """
        stats = self.get_stats()

        lines = ["=== Anti-Debug Bypass Summary ==="]

        # Timing
        t = stats['timing']
        if t['enabled']:
            lines.append("\nTiming Bypass (enabled):")
            lines.append(f"  gettimeofday calls: {t['gettimeofday_calls']}")
            lines.append(f"  clock_gettime calls: {t['clock_gettime_calls']}")
            lines.append(f"  Acceleration: {t['acceleration']}x")
            lines.append(f"  Time frozen: {t['frozen']}")

        # Ptrace
        p = stats['ptrace']
        if p['enabled']:
            lines.append("\nPtrace Bypass (enabled):")
            lines.append(f"  ptrace calls: {p['ptrace_calls']}")
            lines.append(f"  prctl calls: {p['prctl_calls']}")
            lines.append(f"  Fake traced: {p['fake_traced']}")
            lines.append(f"  TracerPid: {p['tracer_pid']}")

        # Proc
        pr = stats['proc']
        if pr['enabled']:
            lines.append("\n/proc Bypass (enabled):")
            lines.append(f"  Status reads: {pr['status_reads']}")
            lines.append(f"  Maps reads: {pr['maps_reads']}")
            lines.append(f"  Net reads: {pr['net_reads']}")

        # Signals
        s = stats['signals']
        if s['enabled']:
            lines.append("\nSignal Bypass (enabled):")
            lines.append(f"  sigaction calls: {s['sigaction_calls']}")
            lines.append(f"  kill calls: {s['kill_calls']}")
            lines.append(f"  Suppressed: {s['suppressed_signals']}")

        # Java
        j = stats['java']
        if j['enabled']:
            lines.append("\nJava Bypass (enabled):")
            lines.append(f"  isDebuggerConnected calls: {j['is_debugger_connected_calls']}")
            lines.append(f"  Property reads: {j['property_reads']}")
            if j['blocked_commands']:
                lines.append(f"  Blocked commands: {len(j['blocked_commands'])}")

        return '\n'.join(lines)
