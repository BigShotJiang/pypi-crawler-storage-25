"""
Java-level anti-debugging bypass.

Patches Java/Android-level debugging detection:
- android.os.Debug.isDebuggerConnected()
- android.os.Debug.waitingForDebugger()
- android.os.Debug.getDebuggerClassPath()
- Build.FINGERPRINT checks
- Settings.Secure.ADB_ENABLED
- Runtime.exec() for debug commands
- System properties (ro.debuggable, etc.)

Techniques:
1. Hook JNI methods for Debug class
2. Return false for isDebuggerConnected()
3. Spoof build properties
4. Block dangerous exec() calls
"""

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ...core.emulator import Emulator

logger = logging.getLogger(__name__)


# System properties that indicate debugging/development
DEBUG_PROPERTIES = {
    'ro.debuggable': '0',
    'ro.secure': '1',
    'ro.adb.secure': '1',
    'service.bootanim.exit': '1',
    'ro.build.type': 'user',
    'ro.build.tags': 'release-keys',
    'ro.product.build.type': 'user',
    'persist.sys.usb.config': 'none',
}

# Dangerous commands that might be used to detect debugging
DANGEROUS_COMMANDS = {
    'su',
    'which su',
    'busybox',
    'magisk',
    'getprop ro.debuggable',
    'getprop ro.secure',
    'ps | grep frida',
    'ps | grep gdb',
    'ps | grep lldb',
    'cat /proc/',
    'ls /data/local/tmp',
    'id',
}


@dataclass
class JavaDebugState:
    """Tracks Java debug bypass state."""
    # JNI method call counts
    is_debugger_connected_calls: int = 0
    waiting_for_debugger_calls: int = 0

    # Property access counts
    property_reads: int = 0

    # Blocked exec commands
    blocked_commands: list[str] = field(default_factory=list)

    # Custom property overrides
    properties: dict[str, str] = field(default_factory=lambda: DEBUG_PROPERTIES.copy())

    # Dangerous command patterns to block
    dangerous_patterns: set[str] = field(default_factory=lambda: DANGEROUS_COMMANDS.copy())


class JavaDebugBypass:
    """
    Bypass Java/Android-level debugging detection.
    
    Many Android apps use Java APIs to detect debugging:
    - Debug.isDebuggerConnected() - JDWP debugger
    - Checking system properties
    - Running shell commands
    - Checking Build properties
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.state = JavaDebugState()
        self._enabled = False

    def enable(self) -> None:
        """Enable Java debug bypass."""
        if self._enabled:
            return

        self._enabled = True
        self.state = JavaDebugState()

        logger.info("Enabling Java debug bypass")

        # Hook JNI methods
        self._hook_jni_methods()

        # Override system properties
        self._override_properties()

    def disable(self) -> None:
        """Disable Java debug bypass."""
        if not self._enabled:
            return

        self._enabled = False
        logger.info("Disabled Java debug bypass")

    def set_property(self, name: str, value: str) -> None:
        """Set a system property value."""
        self.state.properties[name] = value

    def add_dangerous_command(self, pattern: str) -> None:
        """Add a command pattern to block."""
        self.state.dangerous_patterns.add(pattern)

    def _hook_jni_methods(self) -> None:
        """Hook JNI methods related to debugging."""
        if not hasattr(self.emulator, 'jni_env'):
            return

        jni_env = self.emulator.jni_env

        # Register method implementations
        methods = {
            # android.os.Debug
            'android/os/Debug.isDebuggerConnected()Z': self._jni_is_debugger_connected,
            'android/os/Debug.waitingForDebugger()Z': self._jni_waiting_for_debugger,
            'android/os/Debug.isDebugEnabled()Z': self._jni_is_debug_enabled,

            # java.lang.Runtime
            'java/lang/Runtime.exec(Ljava/lang/String;)Ljava/lang/Process;': self._jni_runtime_exec,
            'java/lang/Runtime.exec([Ljava/lang/String;)Ljava/lang/Process;': self._jni_runtime_exec_array,

            # android.provider.Settings$Secure
            'android/provider/Settings$Secure.getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;': self._jni_settings_get_string,

            # android.os.SystemProperties
            'android/os/SystemProperties.get(Ljava/lang/String;)Ljava/lang/String;': self._jni_system_properties_get,
            'android/os/SystemProperties.get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;': self._jni_system_properties_get_default,
            'android/os/SystemProperties.getBoolean(Ljava/lang/String;Z)Z': self._jni_system_properties_get_boolean,
            'android/os/SystemProperties.getInt(Ljava/lang/String;I)I': self._jni_system_properties_get_int,
        }

        if hasattr(jni_env, 'register_native_methods'):
            for method_sig, impl in methods.items():
                try:
                    jni_env.register_native_method(method_sig, impl)
                except Exception as e:
                    logger.debug(f"Could not register {method_sig}: {e}")

    def _override_properties(self) -> None:
        """Override system properties."""
        if not hasattr(self.emulator, 'system_properties'):
            return

        props = self.emulator.system_properties
        for name, value in self.state.properties.items():
            props[name] = value

    def _jni_is_debugger_connected(self, env, clazz) -> int:
        """Handle Debug.isDebuggerConnected() - return false."""
        self.state.is_debugger_connected_calls += 1
        logger.debug("Debug.isDebuggerConnected() -> false")
        return 0  # JNI_FALSE

    def _jni_waiting_for_debugger(self, env, clazz) -> int:
        """Handle Debug.waitingForDebugger() - return false."""
        self.state.waiting_for_debugger_calls += 1
        logger.debug("Debug.waitingForDebugger() -> false")
        return 0  # JNI_FALSE

    def _jni_is_debug_enabled(self, env, clazz) -> int:
        """Handle Debug.isDebugEnabled() - return false."""
        logger.debug("Debug.isDebugEnabled() -> false")
        return 0  # JNI_FALSE

    def _jni_runtime_exec(self, env, obj, cmd_jstring) -> int:
        """Handle Runtime.exec(String) - filter dangerous commands."""
        # Get command string
        cmd = self._get_jstring(env, cmd_jstring)

        if self._is_dangerous_command(cmd):
            logger.debug(f"Blocking dangerous command: {cmd}")
            self.state.blocked_commands.append(cmd)
            # Return null (0) to indicate failure
            return 0

        # Allow normal commands
        return 0  # Would need actual Process implementation

    def _jni_runtime_exec_array(self, env, obj, cmd_array) -> int:
        """Handle Runtime.exec(String[]) - filter dangerous commands."""
        # Get command array
        cmds = self._get_jstring_array(env, cmd_array)
        cmd = ' '.join(cmds)

        if self._is_dangerous_command(cmd):
            logger.debug(f"Blocking dangerous command: {cmd}")
            self.state.blocked_commands.append(cmd)
            return 0

        return 0

    def _jni_settings_get_string(self, env, clazz, resolver, name_jstring) -> int:
        """Handle Settings.Secure.getString()."""
        name = self._get_jstring(env, name_jstring)

        # Return safe values for debug-related settings
        safe_values = {
            'adb_enabled': '0',
            'development_settings_enabled': '0',
            'android_id': 'a1b2c3d4e5f67890',
        }

        value = safe_values.get(name.lower(), '')
        logger.debug(f"Settings.Secure.getString({name}) -> {value}")

        return self._create_jstring(env, value)

    def _jni_system_properties_get(self, env, clazz, name_jstring) -> int:
        """Handle SystemProperties.get(String)."""
        self.state.property_reads += 1
        name = self._get_jstring(env, name_jstring)

        value = self.state.properties.get(name, '')
        logger.debug(f"SystemProperties.get({name}) -> {value}")

        return self._create_jstring(env, value)

    def _jni_system_properties_get_default(self, env, clazz, name_jstring, default_jstring) -> int:
        """Handle SystemProperties.get(String, String)."""
        self.state.property_reads += 1
        name = self._get_jstring(env, name_jstring)
        default = self._get_jstring(env, default_jstring)

        value = self.state.properties.get(name, default)
        logger.debug(f"SystemProperties.get({name}, {default}) -> {value}")

        return self._create_jstring(env, value)

    def _jni_system_properties_get_boolean(self, env, clazz, name_jstring, default_val) -> int:
        """Handle SystemProperties.getBoolean(String, boolean)."""
        self.state.property_reads += 1
        name = self._get_jstring(env, name_jstring)

        value_str = self.state.properties.get(name, '')
        if value_str.lower() in ('1', 'true', 'yes'):
            result = 1
        elif value_str.lower() in ('0', 'false', 'no'):
            result = 0
        else:
            result = default_val

        logger.debug(f"SystemProperties.getBoolean({name}) -> {result}")
        return result

    def _jni_system_properties_get_int(self, env, clazz, name_jstring, default_val) -> int:
        """Handle SystemProperties.getInt(String, int)."""
        self.state.property_reads += 1
        name = self._get_jstring(env, name_jstring)

        try:
            result = int(self.state.properties.get(name, str(default_val)))
        except ValueError:
            result = default_val

        logger.debug(f"SystemProperties.getInt({name}) -> {result}")
        return result

    def _is_dangerous_command(self, cmd: str) -> bool:
        """Check if a command is dangerous (might detect debugging)."""
        cmd_lower = cmd.lower()

        for pattern in self.state.dangerous_patterns:
            if pattern.lower() in cmd_lower:
                return True

        return False

    def _get_jstring(self, env, jstring: int) -> str:
        """Get string from JNI string reference."""
        if not jstring:
            return ''

        if hasattr(env, 'get_string_utf'):
            return env.get_string_utf(jstring)

        # Fallback
        return ''

    def _get_jstring_array(self, env, array: int) -> list[str]:
        """Get string array from JNI array reference."""
        if not array:
            return []

        if hasattr(env, 'get_object_array_element'):
            result = []
            length = env.get_array_length(array) if hasattr(env, 'get_array_length') else 0
            for i in range(length):
                element = env.get_object_array_element(array, i)
                result.append(self._get_jstring(env, element))
            return result

        return []

    def _create_jstring(self, env, value: str) -> int:
        """Create JNI string from Python string."""
        if hasattr(env, 'new_string_utf'):
            return env.new_string_utf(value)
        return 0

    def get_stats(self) -> dict[str, Any]:
        """Get Java debug bypass statistics."""
        return {
            'enabled': self._enabled,
            'is_debugger_connected_calls': self.state.is_debugger_connected_calls,
            'waiting_for_debugger_calls': self.state.waiting_for_debugger_calls,
            'property_reads': self.state.property_reads,
            'blocked_commands': self.state.blocked_commands[-10:],  # Last 10
            'properties': dict(self.state.properties),
        }
