"""Android-specific emulation components."""

from pyunidbg.android.emulator import AndroidEmulator
from pyunidbg.android.jni import (
    JNI_ERR,
    JNI_OK,
    JNI_VERSION_1_6,
    JArray,
    JavaVM,
    JByteArray,
    JClass,
    JIntArray,
    JNIEnv,
    JObject,
    JObjectArray,
    JString,
)
from pyunidbg.android.native_library import NativeLibrary
from pyunidbg.android.syscalls import (
    FileOperations,
    MemoryOperations,
    NetworkOperations,
    ProcessOperations,
    SignalOperations,
    SyscallHandler,
    TimeOperations,
)

__all__ = [
    # Emulator
    "AndroidEmulator",
    "NativeLibrary",
    # JNI
    "JNIEnv",
    "JavaVM",
    "JObject",
    "JString",
    "JClass",
    "JArray",
    "JByteArray",
    "JIntArray",
    "JObjectArray",
    "JNI_OK",
    "JNI_ERR",
    "JNI_VERSION_1_6",
    # Syscalls
    "SyscallHandler",
    "FileOperations",
    "MemoryOperations",
    "ProcessOperations",
    "NetworkOperations",
    "TimeOperations",
    "SignalOperations",
]
