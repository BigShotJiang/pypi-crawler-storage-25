"""
Libc implementations for PyUniDbg.

Provides comprehensive C library function implementations:
- Memory allocation (malloc, free, realloc, calloc, memalign, etc.)
- String manipulation (strlen, strcpy, strncpy, strcmp, strstr, strtok, etc.)
- Memory operations (memcpy, memset, memmove, memcmp, etc.)
- Standard I/O (printf, sprintf, snprintf, fopen, fread, fwrite, etc.)
- Standard library (atoi, strtol, getenv, qsort, rand, etc.)
- Math functions (sin, cos, tan, sqrt, pow, log, etc.)
- POSIX threads (pthread_create, pthread_mutex_*, pthread_cond_*, etc.)

Total: 300+ libc functions implemented.

Usage:
    from pyunidbg.android.libc import LibcHandler
    
    libc = LibcHandler(emulator)
    
    # Allocate memory
    ptr = libc.memory.malloc(1024)
    
    # String operations
    length = libc.string.strlen(str_ptr)
    
    # Get function by name
    malloc_func = libc.get_function("malloc")
    
    # Call function by name
    result = libc.call_function("printf", fmt_ptr, arg1, arg2)
"""

from .handler import LibcHandler
from .math_funcs import MathFunctions
from .mem import MemFunctions
from .memory import MemoryFunctions
from .pthread import PthreadFunctions
from .stdio import StdioFunctions
from .stdlib import StdlibFunctions
from .string import StringFunctions
from .time_funcs import TimeFunctions
from .wchar import WcharFunctions

__all__ = [
    # Main handler
    "LibcHandler",

    # Individual modules
    "MemoryFunctions",
    "StringFunctions",
    "MemFunctions",
    "StdioFunctions",
    "StdlibFunctions",
    "MathFunctions",
    "PthreadFunctions",
    "TimeFunctions",
    "WcharFunctions",
]
