"""
Standard library functions (atoi, getenv, qsort, etc.)
"""

from __future__ import annotations

import logging
import random
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class StdlibFunctions:
    """
    Standard library function implementations.
    
    Implements:
    - atoi, atol, atoll, atof
    - strtol, strtoul, strtoll, strtoull
    - strtod, strtof, strtold
    - abs, labs, llabs
    - div, ldiv, lldiv
    - rand, rand_r, srand, random, srandom
    - getenv, setenv, unsetenv, putenv
    - system, exit, _exit, abort, atexit
    - qsort, qsort_r, bsearch
    - mktemp, mkstemp, mkdtemp
    - realpath, basename, dirname
    - arc4random, arc4random_uniform
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Random state
        self._rand_state = 1
        self._random_state = 1

        # Environment variables
        self._environ: dict[str, str] = {
            "HOME": "/data/data/com.example.app",
            "PATH": "/system/bin:/system/xbin",
            "ANDROID_ROOT": "/system",
            "ANDROID_DATA": "/data",
            "ANDROID_BOOTLOGO": "1",
            "EXTERNAL_STORAGE": "/sdcard",
            "TZ": "UTC",
            "LANG": "en_US.UTF-8",
            "TMPDIR": "/data/local/tmp",
        }

        # atexit handlers
        self._atexit_handlers: list[int] = []

    def _read_string(self, ptr: int, max_len: int = 4096) -> str:
        """Read null-terminated string from memory."""
        return self._emulator.memory.read_string(ptr, max_len)

    def _write_string(self, ptr: int, s: str) -> None:
        """Write null-terminated string to memory."""
        self._emulator.memory.write(ptr, s.encode('utf-8') + b'\x00')

    # ==================== String to Number Conversions ====================

    def atoi(self, nptr: int) -> int:
        """
        Convert string to integer.
        
        int atoi(const char* nptr);
        """
        s = self._read_string(nptr).strip()
        try:
            # Find the number part
            i = 0
            if i < len(s) and s[i] in '+-':
                i += 1
            start = i
            while i < len(s) and s[i].isdigit():
                i += 1

            if i == start and s[0:1] in '+-':
                return 0

            return int(s[:i]) if i > 0 else 0
        except (ValueError, IndexError):
            return 0

    def atol(self, nptr: int) -> int:
        """
        Convert string to long.
        
        long atol(const char* nptr);
        """
        return self.atoi(nptr)

    def atoll(self, nptr: int) -> int:
        """
        Convert string to long long.
        
        long long atoll(const char* nptr);
        """
        return self.atoi(nptr)

    def atof(self, nptr: int) -> float:
        """
        Convert string to double.
        
        double atof(const char* nptr);
        """
        s = self._read_string(nptr).strip()
        try:
            return float(s.split()[0])
        except (ValueError, IndexError):
            return 0.0

    def strtol(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert string to long.
        
        long strtol(const char* nptr, char** endptr, int base);
        """
        s = self._read_string(nptr)
        original_len = len(s)
        s = s.lstrip()
        leading_space = original_len - len(s)

        if not s:
            if endptr:
                self._emulator.memory.write_ptr(endptr, nptr)
            return 0

        # Handle sign
        sign = 1
        idx = 0
        if s[idx] == '-':
            sign = -1
            idx += 1
        elif s[idx] == '+':
            idx += 1

        # Auto-detect base
        if base == 0:
            if idx < len(s) and s[idx] == '0':
                if idx + 1 < len(s) and s[idx + 1] in 'xX':
                    base = 16
                    idx += 2
                else:
                    base = 8
                    idx += 1
            else:
                base = 10
        elif base == 16:
            if idx < len(s) and s[idx] == '0' and idx + 1 < len(s) and s[idx + 1] in 'xX':
                idx += 2

        # Parse number
        digits = "0123456789abcdefghijklmnopqrstuvwxyz"[:base]
        start_idx = idx
        value = 0

        while idx < len(s) and s[idx].lower() in digits:
            value = value * base + digits.index(s[idx].lower())
            idx += 1

        if endptr:
            end_pos = nptr + leading_space + idx
            self._emulator.memory.write_ptr(endptr, end_pos)

        return sign * value

    def strtoul(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert string to unsigned long.
        
        unsigned long strtoul(const char* nptr, char** endptr, int base);
        """
        result = self.strtol(nptr, endptr, base)
        return result & 0xFFFFFFFF

    def strtoll(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert string to long long.
        
        long long strtoll(const char* nptr, char** endptr, int base);
        """
        return self.strtol(nptr, endptr, base)

    def strtoull(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert string to unsigned long long.
        
        unsigned long long strtoull(const char* nptr, char** endptr, int base);
        """
        result = self.strtol(nptr, endptr, base)
        return result & 0xFFFFFFFFFFFFFFFF

    def strtod(self, nptr: int, endptr: int) -> float:
        """
        Convert string to double.
        
        double strtod(const char* nptr, char** endptr);
        """
        s = self._read_string(nptr)
        s = s.lstrip()

        # Find the float portion
        idx = 0
        if idx < len(s) and s[idx] in '+-':
            idx += 1

        # Integer part
        while idx < len(s) and s[idx].isdigit():
            idx += 1

        # Decimal part
        if idx < len(s) and s[idx] == '.':
            idx += 1
            while idx < len(s) and s[idx].isdigit():
                idx += 1

        # Exponent
        if idx < len(s) and s[idx] in 'eE':
            idx += 1
            if idx < len(s) and s[idx] in '+-':
                idx += 1
            while idx < len(s) and s[idx].isdigit():
                idx += 1

        try:
            value = float(s[:idx]) if idx > 0 else 0.0
        except ValueError:
            value = 0.0

        if endptr:
            self._emulator.memory.write_ptr(endptr, nptr + idx)

        return value

    def strtof(self, nptr: int, endptr: int) -> float:
        """
        Convert string to float.
        
        float strtof(const char* nptr, char** endptr);
        """
        return self.strtod(nptr, endptr)

    def strtold(self, nptr: int, endptr: int) -> float:
        """
        Convert string to long double.
        
        long double strtold(const char* nptr, char** endptr);
        """
        return self.strtod(nptr, endptr)

    # ==================== Absolute Value ====================

    def abs(self, j: int) -> int:
        """
        Absolute value of integer.
        
        int abs(int j);
        """
        return j if j >= 0 else -j

    def labs(self, j: int) -> int:
        """
        Absolute value of long.
        
        long labs(long j);
        """
        return j if j >= 0 else -j

    def llabs(self, j: int) -> int:
        """
        Absolute value of long long.
        
        long long llabs(long long j);
        """
        return j if j >= 0 else -j

    def fabs(self, x: float) -> float:
        """
        Absolute value of double.
        
        double fabs(double x);
        """
        return x if x >= 0 else -x

    # ==================== Division ====================

    def div(self, numer: int, denom: int) -> tuple[int, int]:
        """
        Integer division with remainder.
        
        div_t div(int numer, int denom);
        
        Returns (quotient, remainder).
        """
        if denom == 0:
            return (0, 0)
        quot = numer // denom
        rem = numer % denom
        return (quot, rem)

    def ldiv(self, numer: int, denom: int) -> tuple[int, int]:
        """
        Long division with remainder.
        
        ldiv_t ldiv(long numer, long denom);
        """
        return self.div(numer, denom)

    def lldiv(self, numer: int, denom: int) -> tuple[int, int]:
        """
        Long long division with remainder.
        
        lldiv_t lldiv(long long numer, long long denom);
        """
        return self.div(numer, denom)

    # ==================== Random Numbers ====================

    def srand(self, seed: int) -> None:
        """
        Seed random number generator.
        
        void srand(unsigned int seed);
        """
        self._rand_state = seed

    def rand(self) -> int:
        """
        Generate random number.
        
        int rand(void);
        
        Returns value in range [0, RAND_MAX].
        """
        # Linear congruential generator (same as glibc)
        self._rand_state = (self._rand_state * 1103515245 + 12345) & 0x7FFFFFFF
        return self._rand_state

    def rand_r(self, seedp: int) -> int:
        """
        Generate random number (reentrant).
        
        int rand_r(unsigned int* seedp);
        """
        seed = self._emulator.memory.read_u32(seedp)
        seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
        self._emulator.memory.write_u32(seedp, seed)
        return seed

    def srandom(self, seed: int) -> None:
        """
        Seed random number generator (BSD).
        
        void srandom(unsigned int seed);
        """
        self._random_state = seed

    def random(self) -> int:
        """
        Generate random number (BSD).
        
        long random(void);
        """
        self._random_state = (self._random_state * 1103515245 + 12345) & 0x7FFFFFFF
        return self._random_state

    def arc4random(self) -> int:
        """
        Generate random number (BSD arc4random).
        
        uint32_t arc4random(void);
        """
        return random.randint(0, 0xFFFFFFFF)

    def arc4random_uniform(self, upper_bound: int) -> int:
        """
        Generate random number in range [0, upper_bound).
        
        uint32_t arc4random_uniform(uint32_t upper_bound);
        """
        if upper_bound <= 0:
            return 0
        return random.randint(0, upper_bound - 1)

    def arc4random_buf(self, buf: int, nbytes: int) -> None:
        """
        Fill buffer with random bytes.
        
        void arc4random_buf(void* buf, size_t nbytes);
        """
        data = bytes(random.randint(0, 255) for _ in range(nbytes))
        self._emulator.memory.write(buf, data)

    # ==================== Environment ====================

    def getenv(self, name: int) -> int:
        """
        Get environment variable.
        
        char* getenv(const char* name);
        """
        var_name = self._read_string(name)
        value = self._environ.get(var_name)

        if value is None:
            return 0

        # Allocate and return string
        ptr = self._handler.memory.malloc(len(value) + 1)
        if ptr:
            self._write_string(ptr, value)
        return ptr

    def setenv(self, name: int, value: int, overwrite: int) -> int:
        """
        Set environment variable.
        
        int setenv(const char* name, const char* value, int overwrite);
        """
        var_name = self._read_string(name)
        var_value = self._read_string(value)

        if var_name in self._environ and not overwrite:
            return 0

        self._environ[var_name] = var_value
        return 0

    def unsetenv(self, name: int) -> int:
        """
        Remove environment variable.
        
        int unsetenv(const char* name);
        """
        var_name = self._read_string(name)
        self._environ.pop(var_name, None)
        return 0

    def putenv(self, string: int) -> int:
        """
        Set environment variable.
        
        int putenv(char* string);
        """
        s = self._read_string(string)
        if '=' in s:
            name, value = s.split('=', 1)
            self._environ[name] = value
        return 0

    def clearenv(self) -> int:
        """
        Clear environment.
        
        int clearenv(void);
        """
        self._environ.clear()
        return 0

    # ==================== Process Control ====================

    def system(self, command: int) -> int:
        """
        Execute shell command.
        
        int system(const char* command);
        """
        if command == 0:
            return 1  # Shell is available

        cmd = self._read_string(command)
        logger.info(f"system({cmd})")
        return 0

    def exit(self, status: int) -> None:
        """
        Terminate process.
        
        void exit(int status);
        """
        logger.info(f"exit({status})")
        # Run atexit handlers in reverse order
        for handler in reversed(self._atexit_handlers):
            try:
                # Would call handler function here
                pass
            except Exception as e:
                logger.error(f"atexit handler failed: {e}")

        self._emulator.stop()

    def _exit(self, status: int) -> None:
        """
        Terminate process immediately.
        
        void _exit(int status);
        """
        logger.info(f"_exit({status})")
        self._emulator.stop()

    def abort(self) -> None:
        """
        Abort process.
        
        void abort(void);
        """
        logger.info("abort()")
        self._emulator.stop()

    def atexit(self, function: int) -> int:
        """
        Register exit handler.
        
        int atexit(void (*function)(void));
        """
        self._atexit_handlers.append(function)
        return 0

    def quick_exit(self, status: int) -> None:
        """
        Terminate process quickly.
        
        void quick_exit(int status);
        """
        self._emulator.stop()

    def at_quick_exit(self, function: int) -> int:
        """
        Register quick exit handler.
        
        int at_quick_exit(void (*function)(void));
        """
        return 0

    # ==================== Search and Sort ====================

    def qsort(self, base: int, nmemb: int, size: int, compar: int) -> None:
        """
        Sort array.
        
        void qsort(void* base, size_t nmemb, size_t size,
                   int (*compar)(const void*, const void*));
        
        Note: In emulator, we read the data, sort in Python, and write back.
        The comparison function would need to be emulated.
        """
        if nmemb <= 1:
            return

        # Read all elements
        elements = []
        for i in range(nmemb):
            addr = base + i * size
            data = self._emulator.memory.read(addr, size)
            elements.append((addr, data))

        # Sort (would need to call comparator, simplified here)
        elements.sort(key=lambda x: x[1])

        # Write back
        for i, (_, data) in enumerate(elements):
            self._emulator.memory.write(base + i * size, data)

    def bsearch(self, key: int, base: int, nmemb: int, size: int, compar: int) -> int:
        """
        Binary search.
        
        void* bsearch(const void* key, const void* base, size_t nmemb,
                      size_t size, int (*compar)(const void*, const void*));
        """
        if nmemb == 0:
            return 0

        key_data = self._emulator.memory.read(key, size)

        # Simple linear search (binary search would need comparator)
        for i in range(nmemb):
            addr = base + i * size
            elem_data = self._emulator.memory.read(addr, size)
            if elem_data == key_data:
                return addr

        return 0

    # ==================== Temporary Files ====================

    def mktemp(self, template: int) -> int:
        """
        Generate unique filename (UNSAFE).
        
        char* mktemp(char* template);
        """
        tmpl = self._read_string(template)

        # Replace XXXXXX with random chars
        chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        result = ""
        for c in tmpl:
            if c == 'X':
                result += random.choice(chars)
            else:
                result += c

        self._write_string(template, result)
        return template

    def mkstemp(self, template: int) -> int:
        """
        Create unique temporary file.
        
        int mkstemp(char* template);
        """
        self.mktemp(template)
        # Would create file and return fd
        return 3

    def mkdtemp(self, template: int) -> int:
        """
        Create unique temporary directory.
        
        char* mkdtemp(char* template);
        """
        self.mktemp(template)
        return template

    # ==================== Path Manipulation ====================

    def realpath(self, path: int, resolved_path: int) -> int:
        """
        Resolve real path.
        
        char* realpath(const char* path, char* resolved_path);
        """
        p = self._read_string(path)

        # Simplify path (basic implementation)
        parts = []
        for part in p.split('/'):
            if part == '..':
                if parts:
                    parts.pop()
            elif part and part != '.':
                parts.append(part)

        result = '/' + '/'.join(parts) if p.startswith('/') else '/'.join(parts)

        if resolved_path:
            self._write_string(resolved_path, result)
            return resolved_path
        else:
            ptr = self._handler.memory.malloc(len(result) + 1)
            if ptr:
                self._write_string(ptr, result)
            return ptr

    def basename(self, path: int) -> int:
        """
        Get filename from path.
        
        char* basename(char* path);
        """
        p = self._read_string(path)
        result = p.rstrip('/').split('/')[-1] or "/"

        ptr = self._handler.memory.malloc(len(result) + 1)
        if ptr:
            self._write_string(ptr, result)
        return ptr

    def dirname(self, path: int) -> int:
        """
        Get directory from path.
        
        char* dirname(char* path);
        """
        p = self._read_string(path)
        idx = p.rstrip('/').rfind('/')

        if idx == -1:
            result = "."
        elif idx == 0:
            result = "/"
        else:
            result = p[:idx]

        ptr = self._handler.memory.malloc(len(result) + 1)
        if ptr:
            self._write_string(ptr, result)
        return ptr
