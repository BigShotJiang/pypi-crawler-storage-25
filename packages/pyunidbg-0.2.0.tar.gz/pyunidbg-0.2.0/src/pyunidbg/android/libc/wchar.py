"""
Wide character and multibyte string functions.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class WcharFunctions:
    """
    Wide character function implementations.
    
    Implements:
    - Wide string: wcslen, wcscpy, wcsncpy, wcscat, wcsncat, wcscmp, wcsncmp
    - Wide char: wcschr, wcsrchr, wcsstr, wcspbrk, wcsspn, wcscspn, wcstok
    - Wide I/O: wprintf, swprintf, fwprintf, vwprintf, vswprintf, vfwprintf
    - Conversion: mbstowcs, wcstombs, mbtowc, wctomb, mblen
    - Wide char class: iswalpha, iswdigit, iswspace, iswupper, iswlower, towupper, towlower
    - Wide memory: wmemcpy, wmemmove, wmemset, wmemcmp, wmemchr
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

    def _read_wstring(self, ptr: int, max_len: int = 4096) -> str:
        """Read a wide string (assuming UTF-32LE on Android)."""
        result = []
        for i in range(max_len):
            wchar = self._emulator.memory.read_u32(ptr + i * 4)
            if wchar == 0:
                break
            try:
                result.append(chr(wchar))
            except ValueError:
                result.append('?')
        return ''.join(result)

    def _write_wstring(self, ptr: int, s: str) -> None:
        """Write a wide string."""
        for i, ch in enumerate(s):
            self._emulator.memory.write_u32(ptr + i * 4, ord(ch))
        self._emulator.memory.write_u32(ptr + len(s) * 4, 0)

    # ==================== Wide String Functions ====================

    def wcslen(self, s: int) -> int:
        """
        Get wide string length.
        
        size_t wcslen(const wchar_t* s);
        """
        if s == 0:
            return 0
        return len(self._read_wstring(s))

    def wcsnlen(self, s: int, maxlen: int) -> int:
        """
        Get wide string length with limit.
        
        size_t wcsnlen(const wchar_t* s, size_t maxlen);
        """
        if s == 0:
            return 0
        return len(self._read_wstring(s, maxlen))

    def wcscpy(self, dest: int, src: int) -> int:
        """
        Copy wide string.
        
        wchar_t* wcscpy(wchar_t* dest, const wchar_t* src);
        """
        s = self._read_wstring(src)
        self._write_wstring(dest, s)
        return dest

    def wcsncpy(self, dest: int, src: int, n: int) -> int:
        """
        Copy wide string (bounded).
        
        wchar_t* wcsncpy(wchar_t* dest, const wchar_t* src, size_t n);
        """
        s = self._read_wstring(src, n)[:n]
        for i, ch in enumerate(s):
            self._emulator.memory.write_u32(dest + i * 4, ord(ch))
        # Pad with nulls
        for i in range(len(s), n):
            self._emulator.memory.write_u32(dest + i * 4, 0)
        return dest

    def wcscat(self, dest: int, src: int) -> int:
        """
        Concatenate wide strings.
        
        wchar_t* wcscat(wchar_t* dest, const wchar_t* src);
        """
        dest_str = self._read_wstring(dest)
        src_str = self._read_wstring(src)
        self._write_wstring(dest, dest_str + src_str)
        return dest

    def wcsncat(self, dest: int, src: int, n: int) -> int:
        """
        Concatenate wide strings (bounded).
        
        wchar_t* wcsncat(wchar_t* dest, const wchar_t* src, size_t n);
        """
        dest_str = self._read_wstring(dest)
        src_str = self._read_wstring(src, n)[:n]
        self._write_wstring(dest, dest_str + src_str)
        return dest

    def wcscmp(self, s1: int, s2: int) -> int:
        """
        Compare wide strings.
        
        int wcscmp(const wchar_t* s1, const wchar_t* s2);
        """
        str1 = self._read_wstring(s1)
        str2 = self._read_wstring(s2)
        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    def wcsncmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare wide strings (bounded).
        
        int wcsncmp(const wchar_t* s1, const wchar_t* s2, size_t n);
        """
        str1 = self._read_wstring(s1, n)[:n]
        str2 = self._read_wstring(s2, n)[:n]
        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    def wcscasecmp(self, s1: int, s2: int) -> int:
        """
        Compare wide strings (case-insensitive).
        
        int wcscasecmp(const wchar_t* s1, const wchar_t* s2);
        """
        str1 = self._read_wstring(s1).lower()
        str2 = self._read_wstring(s2).lower()
        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    def wcsncasecmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare wide strings (case-insensitive, bounded).
        
        int wcsncasecmp(const wchar_t* s1, const wchar_t* s2, size_t n);
        """
        str1 = self._read_wstring(s1, n)[:n].lower()
        str2 = self._read_wstring(s2, n)[:n].lower()
        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    # ==================== Wide Character Search ====================

    def wcschr(self, s: int, c: int) -> int:
        """
        Find wide character in string.
        
        wchar_t* wcschr(const wchar_t* s, wchar_t c);
        """
        string = self._read_wstring(s)
        char = chr(c) if c else '\x00'

        if c == 0:
            return s + len(string) * 4

        try:
            idx = string.index(char)
            return s + idx * 4
        except ValueError:
            return 0

    def wcsrchr(self, s: int, c: int) -> int:
        """
        Find wide character in string (reverse).
        
        wchar_t* wcsrchr(const wchar_t* s, wchar_t c);
        """
        string = self._read_wstring(s)
        char = chr(c) if c else '\x00'

        if c == 0:
            return s + len(string) * 4

        try:
            idx = string.rindex(char)
            return s + idx * 4
        except ValueError:
            return 0

    def wcsstr(self, haystack: int, needle: int) -> int:
        """
        Find wide substring.
        
        wchar_t* wcsstr(const wchar_t* haystack, const wchar_t* needle);
        """
        hay = self._read_wstring(haystack)
        ndl = self._read_wstring(needle)

        if not ndl:
            return haystack

        try:
            idx = hay.index(ndl)
            return haystack + idx * 4
        except ValueError:
            return 0

    def wcspbrk(self, s: int, accept: int) -> int:
        """
        Find any wide character in set.
        
        wchar_t* wcspbrk(const wchar_t* s, const wchar_t* accept);
        """
        string = self._read_wstring(s)
        accept_set = set(self._read_wstring(accept))

        for i, ch in enumerate(string):
            if ch in accept_set:
                return s + i * 4
        return 0

    def wcsspn(self, s: int, accept: int) -> int:
        """
        Get span of wide characters in set.
        
        size_t wcsspn(const wchar_t* s, const wchar_t* accept);
        """
        string = self._read_wstring(s)
        accept_set = set(self._read_wstring(accept))

        count = 0
        for ch in string:
            if ch in accept_set:
                count += 1
            else:
                break
        return count

    def wcscspn(self, s: int, reject: int) -> int:
        """
        Get span of wide characters not in set.
        
        size_t wcscspn(const wchar_t* s, const wchar_t* reject);
        """
        string = self._read_wstring(s)
        reject_set = set(self._read_wstring(reject))

        count = 0
        for ch in string:
            if ch not in reject_set:
                count += 1
            else:
                break
        return count

    def wcstok(self, s: int, delim: int, saveptr: int) -> int:
        """
        Tokenize wide string.
        
        wchar_t* wcstok(wchar_t* s, const wchar_t* delim, wchar_t** saveptr);
        """
        # Get current position
        if s != 0:
            ptr = s
        elif saveptr != 0:
            ptr = self._emulator.memory.read_ptr(saveptr)
        else:
            return 0

        if ptr == 0:
            return 0

        delim_set = set(self._read_wstring(delim))
        string = self._read_wstring(ptr)

        # Skip leading delimiters
        start = 0
        while start < len(string) and string[start] in delim_set:
            start += 1

        if start >= len(string):
            if saveptr:
                self._emulator.memory.write_ptr(saveptr, 0)
            return 0

        # Find end of token
        end = start
        while end < len(string) and string[end] not in delim_set:
            end += 1

        token_ptr = ptr + start * 4
        if end < len(string):
            self._emulator.memory.write_u32(ptr + end * 4, 0)
            next_ptr = ptr + (end + 1) * 4
        else:
            next_ptr = 0

        if saveptr:
            self._emulator.memory.write_ptr(saveptr, next_ptr)

        return token_ptr

    def wcsdup(self, s: int) -> int:
        """
        Duplicate wide string.
        
        wchar_t* wcsdup(const wchar_t* s);
        """
        string = self._read_wstring(s)
        length = (len(string) + 1) * 4
        ptr = self._handler.memory.malloc(length)
        if ptr:
            self._write_wstring(ptr, string)
        return ptr

    # ==================== Multibyte Conversion ====================

    def mbstowcs(self, dest: int, src: int, n: int) -> int:
        """
        Convert multibyte string to wide string.
        
        size_t mbstowcs(wchar_t* dest, const char* src, size_t n);
        """
        s = self._emulator.memory.read_string(src, n)

        if dest:
            for i, ch in enumerate(s[:n]):
                self._emulator.memory.write_u32(dest + i * 4, ord(ch))
            if len(s) < n:
                self._emulator.memory.write_u32(dest + len(s) * 4, 0)

        return len(s)

    def wcstombs(self, dest: int, src: int, n: int) -> int:
        """
        Convert wide string to multibyte string.
        
        size_t wcstombs(char* dest, const wchar_t* src, size_t n);
        """
        s = self._read_wstring(src)

        if dest:
            encoded = s.encode('utf-8')[:n]
            self._emulator.memory.write(dest, encoded)
            if len(encoded) < n:
                self._emulator.memory.write_u8(dest + len(encoded), 0)

        return len(s.encode('utf-8'))

    def mbtowc(self, pwc: int, s: int, n: int) -> int:
        """
        Convert multibyte character to wide character.
        
        int mbtowc(wchar_t* pwc, const char* s, size_t n);
        """
        if s == 0:
            return 0

        byte = self._emulator.memory.read_u8(s)
        if byte == 0:
            if pwc:
                self._emulator.memory.write_u32(pwc, 0)
            return 0

        # Simple ASCII conversion
        if pwc:
            self._emulator.memory.write_u32(pwc, byte)
        return 1

    def wctomb(self, s: int, wchar: int) -> int:
        """
        Convert wide character to multibyte.
        
        int wctomb(char* s, wchar_t wchar);
        """
        if s == 0:
            return 0

        # Simple ASCII conversion
        if wchar < 128:
            self._emulator.memory.write_u8(s, wchar)
            return 1

        # UTF-8 encoding
        ch = chr(wchar)
        encoded = ch.encode('utf-8')
        self._emulator.memory.write(s, encoded)
        return len(encoded)

    def mblen(self, s: int, n: int) -> int:
        """
        Get length of multibyte character.
        
        int mblen(const char* s, size_t n);
        """
        if s == 0:
            return 0

        byte = self._emulator.memory.read_u8(s)
        if byte == 0:
            return 0
        if byte < 128:
            return 1

        # UTF-8 sequence detection
        if byte >= 0xF0:
            return 4
        if byte >= 0xE0:
            return 3
        if byte >= 0xC0:
            return 2
        return 1

    # ==================== Wide Memory Functions ====================

    def wmemcpy(self, dest: int, src: int, n: int) -> int:
        """
        Copy wide memory.
        
        wchar_t* wmemcpy(wchar_t* dest, const wchar_t* src, size_t n);
        """
        data = self._emulator.memory.read(src, n * 4)
        self._emulator.memory.write(dest, data)
        return dest

    def wmemmove(self, dest: int, src: int, n: int) -> int:
        """
        Copy wide memory (handles overlap).
        
        wchar_t* wmemmove(wchar_t* dest, const wchar_t* src, size_t n);
        """
        data = self._emulator.memory.read(src, n * 4)
        self._emulator.memory.write(dest, data)
        return dest

    def wmemset(self, s: int, c: int, n: int) -> int:
        """
        Fill wide memory.
        
        wchar_t* wmemset(wchar_t* s, wchar_t c, size_t n);
        """
        for i in range(n):
            self._emulator.memory.write_u32(s + i * 4, c)
        return s

    def wmemcmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare wide memory.
        
        int wmemcmp(const wchar_t* s1, const wchar_t* s2, size_t n);
        """
        for i in range(n):
            w1 = self._emulator.memory.read_u32(s1 + i * 4)
            w2 = self._emulator.memory.read_u32(s2 + i * 4)
            if w1 < w2:
                return -1
            if w1 > w2:
                return 1
        return 0

    def wmemchr(self, s: int, c: int, n: int) -> int:
        """
        Find wide character in memory.
        
        wchar_t* wmemchr(const wchar_t* s, wchar_t c, size_t n);
        """
        for i in range(n):
            w = self._emulator.memory.read_u32(s + i * 4)
            if w == c:
                return s + i * 4
        return 0

    # ==================== Wide Character Classification ====================

    def iswalpha(self, c: int) -> int:
        """Check if wide character is alphabetic."""
        return 1 if chr(c).isalpha() else 0

    def iswdigit(self, c: int) -> int:
        """Check if wide character is digit."""
        return 1 if chr(c).isdigit() else 0

    def iswspace(self, c: int) -> int:
        """Check if wide character is whitespace."""
        return 1 if chr(c).isspace() else 0

    def iswupper(self, c: int) -> int:
        """Check if wide character is uppercase."""
        return 1 if chr(c).isupper() else 0

    def iswlower(self, c: int) -> int:
        """Check if wide character is lowercase."""
        return 1 if chr(c).islower() else 0

    def iswalnum(self, c: int) -> int:
        """Check if wide character is alphanumeric."""
        return 1 if chr(c).isalnum() else 0

    def iswprint(self, c: int) -> int:
        """Check if wide character is printable."""
        return 1 if chr(c).isprintable() else 0

    def iswpunct(self, c: int) -> int:
        """Check if wide character is punctuation."""
        ch = chr(c)
        return 1 if (ch.isprintable() and not ch.isalnum() and not ch.isspace()) else 0

    def iswxdigit(self, c: int) -> int:
        """Check if wide character is hexadecimal digit."""
        return 1 if chr(c) in '0123456789abcdefABCDEF' else 0

    def towupper(self, c: int) -> int:
        """Convert wide character to uppercase."""
        return ord(chr(c).upper())

    def towlower(self, c: int) -> int:
        """Convert wide character to lowercase."""
        return ord(chr(c).lower())

    # ==================== Wide Number Conversion ====================

    def wcstol(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert wide string to long.
        
        long wcstol(const wchar_t* nptr, wchar_t** endptr, int base);
        """
        s = self._read_wstring(nptr).strip()

        # Simplified implementation
        try:
            if base == 0:
                if s.startswith('0x') or s.startswith('0X'):
                    base = 16
                elif s.startswith('0'):
                    base = 8
                else:
                    base = 10

            # Find numeric part
            value = int(s.split()[0], base)
            return value
        except (ValueError, IndexError):
            return 0

    def wcstoul(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert wide string to unsigned long.
        
        unsigned long wcstoul(const wchar_t* nptr, wchar_t** endptr, int base);
        """
        return self.wcstol(nptr, endptr, base) & 0xFFFFFFFF

    def wcstod(self, nptr: int, endptr: int) -> float:
        """
        Convert wide string to double.
        
        double wcstod(const wchar_t* nptr, wchar_t** endptr);
        """
        s = self._read_wstring(nptr).strip()

        try:
            return float(s.split()[0])
        except (ValueError, IndexError):
            return 0.0

    def wcstof(self, nptr: int, endptr: int) -> float:
        """
        Convert wide string to float.
        
        float wcstof(const wchar_t* nptr, wchar_t** endptr);
        """
        return self.wcstod(nptr, endptr)

    def wcstold(self, nptr: int, endptr: int) -> float:
        """
        Convert wide string to long double.
        
        long double wcstold(const wchar_t* nptr, wchar_t** endptr);
        """
        return self.wcstod(nptr, endptr)

    def wcstoll(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert wide string to long long.
        
        long long wcstoll(const wchar_t* nptr, wchar_t** endptr, int base);
        """
        return self.wcstol(nptr, endptr, base)

    def wcstoull(self, nptr: int, endptr: int, base: int) -> int:
        """
        Convert wide string to unsigned long long.
        
        unsigned long long wcstoull(const wchar_t* nptr, wchar_t** endptr, int base);
        """
        return self.wcstol(nptr, endptr, base) & 0xFFFFFFFFFFFFFFFF

    # ==================== Multibyte Extended ====================

    def mbrlen(self, s: int, n: int, ps: int) -> int:
        """
        Restartable multibyte character length.
        
        size_t mbrlen(const char* s, size_t n, mbstate_t* ps);
        """
        if s == 0:
            return 0
        c = self._emulator.memory.read_u8(s)
        if c == 0:
            return 0
        if c < 0x80:
            return 1
        if c < 0xC0:
            return -1
        if c < 0xE0:
            return 2 if n >= 2 else -2
        if c < 0xF0:
            return 3 if n >= 3 else -2
        return 4 if n >= 4 else -2

    def mbrtowc(self, pwc: int, s: int, n: int, ps: int) -> int:
        """
        Convert multibyte to wide character (restartable).
        
        size_t mbrtowc(wchar_t* pwc, const char* s, size_t n, mbstate_t* ps);
        """
        if s == 0:
            return 0
        c = self._emulator.memory.read_u8(s)
        if c == 0:
            if pwc:
                self._emulator.memory.write_u32(pwc, 0)
            return 0
        if c < 0x80:
            if pwc:
                self._emulator.memory.write_u32(pwc, c)
            return 1
        # Simplified - assume single byte
        if pwc:
            self._emulator.memory.write_u32(pwc, c)
        return 1

    def wcrtomb(self, s: int, wc: int, ps: int) -> int:
        """
        Convert wide character to multibyte (restartable).
        
        size_t wcrtomb(char* s, wchar_t wc, mbstate_t* ps);
        """
        if s == 0:
            return 1
        if wc < 0x80:
            self._emulator.memory.write_u8(s, wc)
            return 1
        # Simplified - use replacement character
        self._emulator.memory.write_u8(s, ord('?'))
        return 1

    def mbsrtowcs(self, dest: int, src: int, len_: int, ps: int) -> int:
        """
        Convert multibyte string to wide string (restartable).
        
        size_t mbsrtowcs(wchar_t* dest, const char** src, size_t len, mbstate_t* ps);
        """
        return self.mbstowcs(dest, self._emulator.memory.read_u32(src) if src else 0, len_)

    def wcsrtombs(self, dest: int, src: int, len_: int, ps: int) -> int:
        """
        Convert wide string to multibyte string (restartable).
        
        size_t wcsrtombs(char* dest, const wchar_t** src, size_t len, mbstate_t* ps);
        """
        return self.wcstombs(dest, self._emulator.memory.read_u32(src) if src else 0, len_)

    def btowc(self, c: int) -> int:
        """
        Convert single byte to wide character.
        
        wint_t btowc(int c);
        """
        if c == -1 or c > 0x7F:
            return 0xFFFFFFFF  # WEOF
        return c

    def wctob(self, c: int) -> int:
        """
        Convert wide character to single byte.
        
        int wctob(wint_t c);
        """
        if c > 0x7F:
            return -1  # EOF
        return c

    def mbsinit(self, ps: int) -> int:
        """
        Check for initial conversion state.
        
        int mbsinit(const mbstate_t* ps);
        """
        return 1  # Always initial state

    def wcwidth(self, wc: int) -> int:
        """
        Get printing width of a wide character.
        
        int wcwidth(wchar_t wc);
        """
        if wc == 0:
            return 0
        if wc < 32 or (wc >= 0x7F and wc < 0xA0):
            return -1  # Non-printable
        # Wide characters (CJK, etc.)
        if wc >= 0x1100:
            if (0x1100 <= wc <= 0x115F or
                0x2E80 <= wc <= 0x9FFF or
                0xAC00 <= wc <= 0xD7A3 or
                0xF900 <= wc <= 0xFAFF or
                0xFE10 <= wc <= 0xFE6F or
                0xFF00 <= wc <= 0xFF60 or
                0xFFE0 <= wc <= 0xFFE6):
                return 2
        return 1

    def wcswidth(self, s: int, n: int) -> int:
        """
        Get printing width of a wide string.
        
        int wcswidth(const wchar_t* s, size_t n);
        """
        width = 0
        for i in range(n):
            wc = self._emulator.memory.read_u32(s + i * 4)
            if wc == 0:
                break
            w = self.wcwidth(wc)
            if w < 0:
                return -1
            width += w
        return width

    # ==================== Wide I/O ====================

    def swprintf(self, s: int, n: int, format_: int, *args) -> int:
        """
        Write formatted wide string.
        
        int swprintf(wchar_t* s, size_t n, const wchar_t* format, ...);
        """
        if not s or not format_ or n == 0:
            return -1

        fmt = self._read_wstring(format_)

        result = self._wformat_string(fmt, list(args))

        if len(result) >= n:
            return -1

        self._write_wstring(s, result[:n - 1])
        return len(result)

    def _wformat_string(self, fmt: str, args: list) -> str:
        """Format a wide string with printf-style specifiers."""
        result = []
        arg_idx = 0
        i = 0

        while i < len(fmt):
            if fmt[i] == '%':
                if i + 1 < len(fmt) and fmt[i + 1] == '%':
                    result.append('%')
                    i += 2
                    continue

                i += 1

                # Flags
                while i < len(fmt) and fmt[i] in '-+ #0':
                    i += 1

                # Width
                if i < len(fmt) and fmt[i] == '*':
                    arg_idx += 1
                    i += 1
                else:
                    while i < len(fmt) and fmt[i].isdigit():
                        i += 1

                # Precision
                if i < len(fmt) and fmt[i] == '.':
                    i += 1
                    if i < len(fmt) and fmt[i] == '*':
                        arg_idx += 1
                        i += 1
                    else:
                        while i < len(fmt) and fmt[i].isdigit():
                            i += 1

                # Length modifier
                while i < len(fmt) and fmt[i] in 'hlLzjt':
                    i += 1

                if i >= len(fmt):
                    break

                conv = fmt[i]
                i += 1

                value = args[arg_idx] if arg_idx < len(args) else 0
                arg_idx += 1

                if conv in ('d', 'i'):
                    result.append(str(int(value)))
                elif conv == 'u':
                    result.append(str(value & 0xFFFFFFFF))
                elif conv in ('x', 'X'):
                    s = f"{value & 0xFFFFFFFF:x}"
                    result.append(s.upper() if conv == 'X' else s)
                elif conv == 'o':
                    result.append(f"{value & 0xFFFFFFFF:o}")
                elif conv == 'c':
                    result.append(chr(value & 0xFFFF) if value else '\x00')
                elif conv == 's':
                    if isinstance(value, int) and value != 0:
                        result.append(self._read_wstring(value))
                    elif isinstance(value, str):
                        result.append(value)
                    else:
                        result.append('(null)')
                elif conv == 'p':
                    result.append(f"0x{value:x}")
                elif conv in ('f', 'F', 'e', 'E', 'g', 'G'):
                    result.append(f"{float(value)}")
                elif conv == 'n':
                    pass
                else:
                    result.append(f"%{conv}")
            else:
                result.append(fmt[i])
                i += 1

        return ''.join(result)

    def vswprintf(self, s: int, n: int, format_: int, ap: int) -> int:
        """
        Write formatted wide string (varargs).
        
        int vswprintf(wchar_t* s, size_t n, const wchar_t* format, va_list ap);
        """
        return self.swprintf(s, n, format_)

    def swscanf(self, s: int, format_: int, *args) -> int:
        """
        Read formatted wide string.
        
        int swscanf(const wchar_t* s, const wchar_t* format, ...);
        """
        return 0

    def fwprintf(self, stream: int, format_: int, *args) -> int:
        """
        Write formatted wide output to stream.
        
        int fwprintf(FILE* stream, const wchar_t* format, ...);
        """
        return 0

    def fwscanf(self, stream: int, format_: int, *args) -> int:
        """
        Read formatted wide input from stream.
        
        int fwscanf(FILE* stream, const wchar_t* format, ...);
        """
        return 0

    def wprintf(self, format_: int, *args) -> int:
        """
        Write formatted wide output.
        
        int wprintf(const wchar_t* format, ...);
        """
        fmt = self._read_wstring(format_)
        logger.info(f"wprintf: {fmt!r}")
        return len(fmt)

    def wscanf(self, format_: int, *args) -> int:
        """
        Read formatted wide input.
        
        int wscanf(const wchar_t* format, ...);
        """
        return 0

    def fgetwc(self, stream: int) -> int:
        """
        Get wide character from stream.
        
        wint_t fgetwc(FILE* stream);
        """
        return 0xFFFFFFFF  # WEOF

    def fputwc(self, wc: int, stream: int) -> int:
        """
        Put wide character to stream.
        
        wint_t fputwc(wchar_t wc, FILE* stream);
        """
        return wc

    def fgetws(self, s: int, n: int, stream: int) -> int:
        """
        Get wide string from stream.
        
        wchar_t* fgetws(wchar_t* s, int n, FILE* stream);
        """
        return 0  # NULL

    def fputws(self, s: int, stream: int) -> int:
        """
        Put wide string to stream.
        
        int fputws(const wchar_t* s, FILE* stream);
        """
        return 0

    def getwc(self, stream: int) -> int:
        """
        Get wide character from stream.
        
        wint_t getwc(FILE* stream);
        """
        return self.fgetwc(stream)

    def putwc(self, wc: int, stream: int) -> int:
        """
        Put wide character to stream.
        
        wint_t putwc(wchar_t wc, FILE* stream);
        """
        return self.fputwc(wc, stream)

    def getwchar(self) -> int:
        """
        Get wide character from stdin.
        
        wint_t getwchar(void);
        """
        return 0xFFFFFFFF  # WEOF

    def putwchar(self, wc: int) -> int:
        """
        Put wide character to stdout.
        
        wint_t putwchar(wchar_t wc);
        """
        return wc

    def ungetwc(self, wc: int, stream: int) -> int:
        """
        Push wide character back to stream.
        
        wint_t ungetwc(wint_t wc, FILE* stream);
        """
        return wc
