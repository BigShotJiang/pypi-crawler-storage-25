"""
Math functions (sin, cos, sqrt, pow, etc.)
"""

from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class MathFunctions:
    """
    Math function implementations.
    
    Implements:
    - Trigonometric: sin, cos, tan, asin, acos, atan, atan2
    - Hyperbolic: sinh, cosh, tanh, asinh, acosh, atanh
    - Exponential: exp, exp2, expm1, frexp, ldexp, log, log10, log2, log1p, logb, ilogb
    - Power: pow, sqrt, cbrt, hypot
    - Rounding: ceil, floor, trunc, round, nearbyint, rint, lrint, llrint
    - Remainder: fmod, remainder, remquo, modf
    - Floating-point: copysign, nan, nextafter, fdim, fmax, fmin, fma
    - Classification: fpclassify, isfinite, isinf, isnan, isnormal, signbit
    - Absolute: fabs, abs
    - Error functions: erf, erfc, lgamma, tgamma
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

    # ==================== Trigonometric ====================

    def sin(self, x: float) -> float:
        """
        Sine.
        
        double sin(double x);
        """
        return math.sin(x)

    def sinf(self, x: float) -> float:
        """
        Sine (float).
        
        float sinf(float x);
        """
        return math.sin(x)

    def cos(self, x: float) -> float:
        """
        Cosine.
        
        double cos(double x);
        """
        return math.cos(x)

    def cosf(self, x: float) -> float:
        """
        Cosine (float).
        
        float cosf(float x);
        """
        return math.cos(x)

    def tan(self, x: float) -> float:
        """
        Tangent.
        
        double tan(double x);
        """
        return math.tan(x)

    def tanf(self, x: float) -> float:
        """
        Tangent (float).
        
        float tanf(float x);
        """
        return math.tan(x)

    def asin(self, x: float) -> float:
        """
        Arc sine.
        
        double asin(double x);
        """
        if x < -1 or x > 1:
            return float('nan')
        return math.asin(x)

    def asinf(self, x: float) -> float:
        """
        Arc sine (float).
        
        float asinf(float x);
        """
        return self.asin(x)

    def acos(self, x: float) -> float:
        """
        Arc cosine.
        
        double acos(double x);
        """
        if x < -1 or x > 1:
            return float('nan')
        return math.acos(x)

    def acosf(self, x: float) -> float:
        """
        Arc cosine (float).
        
        float acosf(float x);
        """
        return self.acos(x)

    def atan(self, x: float) -> float:
        """
        Arc tangent.
        
        double atan(double x);
        """
        return math.atan(x)

    def atanf(self, x: float) -> float:
        """
        Arc tangent (float).
        
        float atanf(float x);
        """
        return math.atan(x)

    def atan2(self, y: float, x: float) -> float:
        """
        Arc tangent of y/x.
        
        double atan2(double y, double x);
        """
        return math.atan2(y, x)

    def atan2f(self, y: float, x: float) -> float:
        """
        Arc tangent of y/x (float).
        
        float atan2f(float y, float x);
        """
        return math.atan2(y, x)

    def sincos(self, x: float) -> tuple[float, float]:
        """
        Sine and cosine.
        
        void sincos(double x, double* sin, double* cos);
        
        Returns (sin, cos).
        """
        return (math.sin(x), math.cos(x))

    def sincosf(self, x: float) -> tuple[float, float]:
        """
        Sine and cosine (float).
        
        void sincosf(float x, float* sin, float* cos);
        """
        return self.sincos(x)

    # ==================== Hyperbolic ====================

    def sinh(self, x: float) -> float:
        """
        Hyperbolic sine.
        
        double sinh(double x);
        """
        return math.sinh(x)

    def sinhf(self, x: float) -> float:
        """
        Hyperbolic sine (float).
        
        float sinhf(float x);
        """
        return math.sinh(x)

    def cosh(self, x: float) -> float:
        """
        Hyperbolic cosine.
        
        double cosh(double x);
        """
        return math.cosh(x)

    def coshf(self, x: float) -> float:
        """
        Hyperbolic cosine (float).
        
        float coshf(float x);
        """
        return math.cosh(x)

    def tanh(self, x: float) -> float:
        """
        Hyperbolic tangent.
        
        double tanh(double x);
        """
        return math.tanh(x)

    def tanhf(self, x: float) -> float:
        """
        Hyperbolic tangent (float).
        
        float tanhf(float x);
        """
        return math.tanh(x)

    def asinh(self, x: float) -> float:
        """
        Inverse hyperbolic sine.
        
        double asinh(double x);
        """
        return math.asinh(x)

    def asinhf(self, x: float) -> float:
        """
        Inverse hyperbolic sine (float).
        
        float asinhf(float x);
        """
        return math.asinh(x)

    def acosh(self, x: float) -> float:
        """
        Inverse hyperbolic cosine.
        
        double acosh(double x);
        """
        if x < 1:
            return float('nan')
        return math.acosh(x)

    def acoshf(self, x: float) -> float:
        """
        Inverse hyperbolic cosine (float).
        
        float acoshf(float x);
        """
        return self.acosh(x)

    def atanh(self, x: float) -> float:
        """
        Inverse hyperbolic tangent.
        
        double atanh(double x);
        """
        if x <= -1 or x >= 1:
            return float('nan')
        return math.atanh(x)

    def atanhf(self, x: float) -> float:
        """
        Inverse hyperbolic tangent (float).
        
        float atanhf(float x);
        """
        return self.atanh(x)

    # ==================== Exponential & Logarithmic ====================

    def exp(self, x: float) -> float:
        """
        Exponential.
        
        double exp(double x);
        """
        return math.exp(x)

    def expf(self, x: float) -> float:
        """
        Exponential (float).
        
        float expf(float x);
        """
        return math.exp(x)

    def exp2(self, x: float) -> float:
        """
        Base-2 exponential.
        
        double exp2(double x);
        """
        return math.pow(2, x)

    def exp2f(self, x: float) -> float:
        """
        Base-2 exponential (float).
        
        float exp2f(float x);
        """
        return math.pow(2, x)

    def expm1(self, x: float) -> float:
        """
        exp(x) - 1.
        
        double expm1(double x);
        """
        return math.expm1(x)

    def expm1f(self, x: float) -> float:
        """
        exp(x) - 1 (float).
        
        float expm1f(float x);
        """
        return math.expm1(x)

    def frexp(self, x: float) -> tuple[float, int]:
        """
        Extract mantissa and exponent.
        
        double frexp(double x, int* exp);
        
        Returns (mantissa, exponent).
        """
        return math.frexp(x)

    def frexpf(self, x: float) -> tuple[float, int]:
        """
        Extract mantissa and exponent (float).
        
        float frexpf(float x, int* exp);
        """
        return math.frexp(x)

    def ldexp(self, x: float, exp: int) -> float:
        """
        Load exponent.
        
        double ldexp(double x, int exp);
        """
        return math.ldexp(x, exp)

    def ldexpf(self, x: float, exp: int) -> float:
        """
        Load exponent (float).
        
        float ldexpf(float x, int exp);
        """
        return math.ldexp(x, exp)

    def log(self, x: float) -> float:
        """
        Natural logarithm.
        
        double log(double x);
        """
        if x <= 0:
            return float('-inf') if x == 0 else float('nan')
        return math.log(x)

    def logf(self, x: float) -> float:
        """
        Natural logarithm (float).
        
        float logf(float x);
        """
        return self.log(x)

    def log10(self, x: float) -> float:
        """
        Base-10 logarithm.
        
        double log10(double x);
        """
        if x <= 0:
            return float('-inf') if x == 0 else float('nan')
        return math.log10(x)

    def log10f(self, x: float) -> float:
        """
        Base-10 logarithm (float).
        
        float log10f(float x);
        """
        return self.log10(x)

    def log2(self, x: float) -> float:
        """
        Base-2 logarithm.
        
        double log2(double x);
        """
        if x <= 0:
            return float('-inf') if x == 0 else float('nan')
        return math.log2(x)

    def log2f(self, x: float) -> float:
        """
        Base-2 logarithm (float).
        
        float log2f(float x);
        """
        return self.log2(x)

    def log1p(self, x: float) -> float:
        """
        log(1 + x).
        
        double log1p(double x);
        """
        if x < -1:
            return float('nan')
        return math.log1p(x)

    def log1pf(self, x: float) -> float:
        """
        log(1 + x) (float).
        
        float log1pf(float x);
        """
        return self.log1p(x)

    def logb(self, x: float) -> float:
        """
        Extract exponent.
        
        double logb(double x);
        """
        if x == 0:
            return float('-inf')
        return float(int(math.log2(abs(x))))

    def logbf(self, x: float) -> float:
        """
        Extract exponent (float).
        
        float logbf(float x);
        """
        return self.logb(x)

    def ilogb(self, x: float) -> int:
        """
        Extract exponent as integer.
        
        int ilogb(double x);
        """
        if x == 0:
            return -2147483648  # FP_ILOGB0
        if math.isnan(x) or math.isinf(x):
            return 2147483647  # INT_MAX
        return int(math.log2(abs(x)))

    def ilogbf(self, x: float) -> int:
        """
        Extract exponent as integer (float).
        
        int ilogbf(float x);
        """
        return self.ilogb(x)

    # ==================== Power ====================

    def pow(self, x: float, y: float) -> float:
        """
        Power function.
        
        double pow(double x, double y);
        """
        try:
            return math.pow(x, y)
        except (ValueError, OverflowError):
            return float('nan')

    def powf(self, x: float, y: float) -> float:
        """
        Power function (float).
        
        float powf(float x, float y);
        """
        return self.pow(x, y)

    def sqrt(self, x: float) -> float:
        """
        Square root.
        
        double sqrt(double x);
        """
        if x < 0:
            return float('nan')
        return math.sqrt(x)

    def sqrtf(self, x: float) -> float:
        """
        Square root (float).
        
        float sqrtf(float x);
        """
        return self.sqrt(x)

    def cbrt(self, x: float) -> float:
        """
        Cube root.
        
        double cbrt(double x);
        """
        if x >= 0:
            return math.pow(x, 1/3)
        return -math.pow(-x, 1/3)

    def cbrtf(self, x: float) -> float:
        """
        Cube root (float).
        
        float cbrtf(float x);
        """
        return self.cbrt(x)

    def hypot(self, x: float, y: float) -> float:
        """
        Euclidean distance.
        
        double hypot(double x, double y);
        """
        return math.hypot(x, y)

    def hypotf(self, x: float, y: float) -> float:
        """
        Euclidean distance (float).
        
        float hypotf(float x, float y);
        """
        return math.hypot(x, y)

    # ==================== Rounding ====================

    def ceil(self, x: float) -> float:
        """
        Ceiling.
        
        double ceil(double x);
        """
        return math.ceil(x)

    def ceilf(self, x: float) -> float:
        """
        Ceiling (float).
        
        float ceilf(float x);
        """
        return math.ceil(x)

    def floor(self, x: float) -> float:
        """
        Floor.
        
        double floor(double x);
        """
        return math.floor(x)

    def floorf(self, x: float) -> float:
        """
        Floor (float).
        
        float floorf(float x);
        """
        return math.floor(x)

    def trunc(self, x: float) -> float:
        """
        Truncate to integer.
        
        double trunc(double x);
        """
        return math.trunc(x)

    def truncf(self, x: float) -> float:
        """
        Truncate to integer (float).
        
        float truncf(float x);
        """
        return math.trunc(x)

    def round(self, x: float) -> float:
        """
        Round to nearest integer.
        
        double round(double x);
        """
        return float(round(x))

    def roundf(self, x: float) -> float:
        """
        Round to nearest integer (float).
        
        float roundf(float x);
        """
        return float(round(x))

    def lround(self, x: float) -> int:
        """
        Round to nearest long.
        
        long lround(double x);
        """
        return round(x)

    def lroundf(self, x: float) -> int:
        """
        Round to nearest long (float).
        
        long lroundf(float x);
        """
        return round(x)

    def llround(self, x: float) -> int:
        """
        Round to nearest long long.
        
        long long llround(double x);
        """
        return round(x)

    def llroundf(self, x: float) -> int:
        """
        Round to nearest long long (float).
        
        long long llroundf(float x);
        """
        return round(x)

    def nearbyint(self, x: float) -> float:
        """
        Round to nearest integer.
        
        double nearbyint(double x);
        """
        return float(round(x))

    def nearbyintf(self, x: float) -> float:
        """
        Round to nearest integer (float).
        
        float nearbyintf(float x);
        """
        return float(round(x))

    def rint(self, x: float) -> float:
        """
        Round to nearest integer.
        
        double rint(double x);
        """
        return float(round(x))

    def rintf(self, x: float) -> float:
        """
        Round to nearest integer (float).
        
        float rintf(float x);
        """
        return float(round(x))

    def lrint(self, x: float) -> int:
        """
        Round to nearest long.
        
        long lrint(double x);
        """
        return round(x)

    def lrintf(self, x: float) -> int:
        """
        Round to nearest long (float).
        
        long lrintf(float x);
        """
        return round(x)

    def llrint(self, x: float) -> int:
        """
        Round to nearest long long.
        
        long long llrint(double x);
        """
        return round(x)

    def llrintf(self, x: float) -> int:
        """
        Round to nearest long long (float).
        
        long long llrintf(float x);
        """
        return round(x)

    # ==================== Remainder ====================

    def fmod(self, x: float, y: float) -> float:
        """
        Floating-point remainder.
        
        double fmod(double x, double y);
        """
        if y == 0:
            return float('nan')
        return math.fmod(x, y)

    def fmodf(self, x: float, y: float) -> float:
        """
        Floating-point remainder (float).
        
        float fmodf(float x, float y);
        """
        return self.fmod(x, y)

    def remainder(self, x: float, y: float) -> float:
        """
        IEEE remainder.
        
        double remainder(double x, double y);
        """
        if y == 0:
            return float('nan')
        return math.remainder(x, y)

    def remainderf(self, x: float, y: float) -> float:
        """
        IEEE remainder (float).
        
        float remainderf(float x, float y);
        """
        return self.remainder(x, y)

    def modf(self, x: float) -> tuple[float, float]:
        """
        Split into integer and fractional parts.
        
        double modf(double x, double* iptr);
        
        Returns (fractional, integer).
        """
        return math.modf(x)

    def modff(self, x: float) -> tuple[float, float]:
        """
        Split into integer and fractional parts (float).
        
        float modff(float x, float* iptr);
        """
        return math.modf(x)

    # ==================== Floating-point Manipulation ====================

    def copysign(self, x: float, y: float) -> float:
        """
        Copy sign.
        
        double copysign(double x, double y);
        """
        return math.copysign(x, y)

    def copysignf(self, x: float, y: float) -> float:
        """
        Copy sign (float).
        
        float copysignf(float x, float y);
        """
        return math.copysign(x, y)

    def nan(self, tagp: int) -> float:
        """
        Return NaN.
        
        double nan(const char* tagp);
        """
        return float('nan')

    def nanf(self, tagp: int) -> float:
        """
        Return NaN (float).
        
        float nanf(const char* tagp);
        """
        return float('nan')

    def nextafter(self, x: float, y: float) -> float:
        """
        Next representable value.
        
        double nextafter(double x, double y);
        """
        return math.nextafter(x, y)

    def nextafterf(self, x: float, y: float) -> float:
        """
        Next representable value (float).
        
        float nextafterf(float x, float y);
        """
        return math.nextafter(x, y)

    def fdim(self, x: float, y: float) -> float:
        """
        Positive difference.
        
        double fdim(double x, double y);
        """
        return max(x - y, 0.0)

    def fdimf(self, x: float, y: float) -> float:
        """
        Positive difference (float).
        
        float fdimf(float x, float y);
        """
        return max(x - y, 0.0)

    def fmax(self, x: float, y: float) -> float:
        """
        Maximum.
        
        double fmax(double x, double y);
        """
        if math.isnan(x):
            return y
        if math.isnan(y):
            return x
        return max(x, y)

    def fmaxf(self, x: float, y: float) -> float:
        """
        Maximum (float).
        
        float fmaxf(float x, float y);
        """
        return self.fmax(x, y)

    def fmin(self, x: float, y: float) -> float:
        """
        Minimum.
        
        double fmin(double x, double y);
        """
        if math.isnan(x):
            return y
        if math.isnan(y):
            return x
        return min(x, y)

    def fminf(self, x: float, y: float) -> float:
        """
        Minimum (float).
        
        float fminf(float x, float y);
        """
        return self.fmin(x, y)

    def fma(self, x: float, y: float, z: float) -> float:
        """
        Fused multiply-add.
        
        double fma(double x, double y, double z);
        """
        return x * y + z

    def fmaf(self, x: float, y: float, z: float) -> float:
        """
        Fused multiply-add (float).
        
        float fmaf(float x, float y, float z);
        """
        return x * y + z

    # ==================== Classification ====================

    def fpclassify(self, x: float) -> int:
        """
        Classify floating-point value.
        
        int fpclassify(double x);
        
        Returns: FP_NAN=0, FP_INFINITE=1, FP_ZERO=2, FP_SUBNORMAL=3, FP_NORMAL=4
        """
        if math.isnan(x):
            return 0
        if math.isinf(x):
            return 1
        if x == 0:
            return 2
        # Check for subnormal
        if abs(x) < 2.2250738585072014e-308:
            return 3
        return 4

    def isfinite(self, x: float) -> int:
        """
        Check if finite.
        
        int isfinite(double x);
        """
        return 1 if math.isfinite(x) else 0

    def isinf(self, x: float) -> int:
        """
        Check if infinite.
        
        int isinf(double x);
        """
        return 1 if math.isinf(x) else 0

    def isnan(self, x: float) -> int:
        """
        Check if NaN.
        
        int isnan(double x);
        """
        return 1 if math.isnan(x) else 0

    def isnormal(self, x: float) -> int:
        """
        Check if normal.
        
        int isnormal(double x);
        """
        return 1 if (math.isfinite(x) and x != 0 and abs(x) >= 2.2250738585072014e-308) else 0

    def signbit(self, x: float) -> int:
        """
        Check sign bit.
        
        int signbit(double x);
        """
        return 1 if math.copysign(1, x) < 0 else 0

    # ==================== Absolute Value ====================

    def fabs(self, x: float) -> float:
        """
        Absolute value.
        
        double fabs(double x);
        """
        return math.fabs(x)

    def fabsf(self, x: float) -> float:
        """
        Absolute value (float).
        
        float fabsf(float x);
        """
        return math.fabs(x)

    # ==================== Error Functions ====================

    def erf(self, x: float) -> float:
        """
        Error function.
        
        double erf(double x);
        """
        return math.erf(x)

    def erff(self, x: float) -> float:
        """
        Error function (float).
        
        float erff(float x);
        """
        return math.erf(x)

    def erfc(self, x: float) -> float:
        """
        Complementary error function.
        
        double erfc(double x);
        """
        return math.erfc(x)

    def erfcf(self, x: float) -> float:
        """
        Complementary error function (float).
        
        float erfcf(float x);
        """
        return math.erfc(x)

    def lgamma(self, x: float) -> float:
        """
        Log gamma.
        
        double lgamma(double x);
        """
        return math.lgamma(x)

    def lgammaf(self, x: float) -> float:
        """
        Log gamma (float).
        
        float lgammaf(float x);
        """
        return math.lgamma(x)

    def tgamma(self, x: float) -> float:
        """
        True gamma.
        
        double tgamma(double x);
        """
        return math.gamma(x)

    def tgammaf(self, x: float) -> float:
        """
        True gamma (float).
        
        float tgammaf(float x);
        """
        return math.gamma(x)

    # ==================== Bessel Functions ====================

    def j0(self, x: float) -> float:
        """
        Bessel function J0.
        
        double j0(double x);
        """
        # Simplified approximation
        if abs(x) < 4:
            x2 = x * x
            return 1 - x2/4 + x2*x2/64 - x2*x2*x2/2304
        return 0.0

    def j1(self, x: float) -> float:
        """
        Bessel function J1.
        
        double j1(double x);
        """
        # Simplified approximation
        if abs(x) < 4:
            x2 = x * x
            return x/2 * (1 - x2/8 + x2*x2/192)
        return 0.0

    def y0(self, x: float) -> float:
        """
        Bessel function Y0.
        
        double y0(double x);
        """
        if x <= 0:
            return float('-inf')
        return 0.0

    def y1(self, x: float) -> float:
        """
        Bessel function Y1.
        
        double y1(double x);
        """
        if x <= 0:
            return float('-inf')
        return 0.0

    # ==================== Degrees/Radians ====================

    def degrees(self, x: float) -> float:
        """
        Convert radians to degrees.
        
        Not standard C, but useful.
        """
        return math.degrees(x)

    def radians(self, x: float) -> float:
        """
        Convert degrees to radians.
        
        Not standard C, but useful.
        """
        return math.radians(x)
