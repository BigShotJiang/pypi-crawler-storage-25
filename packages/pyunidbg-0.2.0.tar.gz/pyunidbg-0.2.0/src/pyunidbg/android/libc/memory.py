"""
Memory allocation functions (malloc, free, realloc, calloc, etc.)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


@dataclass
class HeapBlock:
    """Represents an allocated heap block."""
    address: int
    size: int
    in_use: bool = True
    alignment: int = 8


class MemoryFunctions:
    """
    Memory allocation function implementations.
    
    Implements:
    - malloc, free, realloc, calloc, memalign, posix_memalign
    - mmap, munmap, mprotect (libc wrappers)
    - memcpy, memmove, memset, memcmp, memchr
    - alloca (stack allocation)
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Heap management
        self._heap_base = 0
        self._heap_size = 0
        self._heap_ptr = 0
        self._allocations: dict[int, HeapBlock] = {}
        self._free_list: list[HeapBlock] = []

        # Statistics
        self._total_allocated = 0
        self._total_freed = 0
        self._alloc_count = 0
        self._free_count = 0

    def _ensure_heap(self, min_size: int = 0x100000) -> None:
        """Ensure heap is initialized."""
        if self._heap_base == 0:
            mem = self._emulator.memory
            self._heap_size = max(min_size, 0x100000)  # 1MB default
            self._heap_base = mem.allocate(self._heap_size, name="[heap]")
            self._heap_ptr = self._heap_base
            logger.debug(f"Heap initialized at {self._heap_base:#x}, size={self._heap_size:#x}")

    def _align(self, value: int, alignment: int = 8) -> int:
        """Align value to boundary."""
        return (value + alignment - 1) & ~(alignment - 1)

    # ==================== malloc family ====================

    def malloc(self, size: int) -> int:
        """
        Allocate memory block.
        
        void* malloc(size_t size);
        """
        if size == 0:
            return 0

        self._ensure_heap()

        # Align size
        aligned_size = self._align(size, 8)

        # Check free list first
        for i, block in enumerate(self._free_list):
            if block.size >= aligned_size:
                # Reuse this block
                self._free_list.pop(i)
                block.in_use = True
                self._allocations[block.address] = block
                self._total_allocated += block.size
                self._alloc_count += 1
                logger.debug(f"malloc({size}) -> {block.address:#x} (reused)")
                return block.address

        # Allocate new block
        if self._heap_ptr + aligned_size > self._heap_base + self._heap_size:
            # Need to expand heap
            logger.warning(f"Heap exhausted, allocation of {size} bytes failed")
            return 0

        addr = self._heap_ptr
        self._heap_ptr += aligned_size

        block = HeapBlock(address=addr, size=aligned_size)
        self._allocations[addr] = block
        self._total_allocated += aligned_size
        self._alloc_count += 1

        logger.debug(f"malloc({size}) -> {addr:#x}")
        return addr

    def free(self, ptr: int) -> None:
        """
        Free allocated memory.
        
        void free(void* ptr);
        """
        if ptr == 0:
            return

        block = self._allocations.pop(ptr, None)
        if block:
            block.in_use = False
            self._free_list.append(block)
            self._total_freed += block.size
            self._free_count += 1
            logger.debug(f"free({ptr:#x})")
        else:
            logger.warning(f"free({ptr:#x}): invalid pointer")

    def calloc(self, nmemb: int, size: int) -> int:
        """
        Allocate and zero memory.
        
        void* calloc(size_t nmemb, size_t size);
        """
        total_size = nmemb * size
        ptr = self.malloc(total_size)
        if ptr:
            self._emulator.memory.write(ptr, b'\x00' * total_size)
        logger.debug(f"calloc({nmemb}, {size}) -> {ptr:#x}")
        return ptr

    def realloc(self, ptr: int, size: int) -> int:
        """
        Reallocate memory block.
        
        void* realloc(void* ptr, size_t size);
        """
        if ptr == 0:
            return self.malloc(size)

        if size == 0:
            self.free(ptr)
            return 0

        old_block = self._allocations.get(ptr)
        if not old_block:
            logger.warning(f"realloc({ptr:#x}, {size}): invalid pointer")
            return 0

        if old_block.size >= size:
            # Current block is large enough
            return ptr

        # Allocate new block
        new_ptr = self.malloc(size)
        if new_ptr:
            # Copy old data
            mem = self._emulator.memory
            old_data = mem.read(ptr, old_block.size)
            mem.write(new_ptr, old_data)
            self.free(ptr)

        logger.debug(f"realloc({ptr:#x}, {size}) -> {new_ptr:#x}")
        return new_ptr

    def reallocarray(self, ptr: int, nmemb: int, size: int) -> int:
        """
        Reallocate array with overflow checking.
        
        void* reallocarray(void* ptr, size_t nmemb, size_t size);
        """
        # Check for overflow
        total_size = nmemb * size
        if nmemb != 0 and total_size // nmemb != size:
            return 0  # Overflow
        return self.realloc(ptr, total_size)

    def memalign(self, alignment: int, size: int) -> int:
        """
        Allocate aligned memory.
        
        void* memalign(size_t alignment, size_t size);
        """
        if alignment == 0 or (alignment & (alignment - 1)) != 0:
            return 0  # Alignment must be power of 2

        self._ensure_heap()

        # Calculate aligned address
        current = self._heap_ptr
        aligned = self._align(current, alignment)
        padding = aligned - current

        total_size = self._align(size, 8) + padding

        if self._heap_ptr + total_size > self._heap_base + self._heap_size:
            return 0

        self._heap_ptr += padding  # Skip to aligned address
        addr = self._heap_ptr
        self._heap_ptr += self._align(size, 8)

        block = HeapBlock(address=addr, size=self._align(size, 8), alignment=alignment)
        self._allocations[addr] = block
        self._total_allocated += block.size
        self._alloc_count += 1

        logger.debug(f"memalign({alignment}, {size}) -> {addr:#x}")
        return addr

    def posix_memalign(self, memptr: int, alignment: int, size: int) -> int:
        """
        Allocate aligned memory (POSIX).
        
        int posix_memalign(void** memptr, size_t alignment, size_t size);
        """
        if alignment < self._emulator.pointer_size:
            return 22  # EINVAL
        if (alignment & (alignment - 1)) != 0:
            return 22  # EINVAL

        ptr = self.memalign(alignment, size)
        if ptr == 0:
            return 12  # ENOMEM

        self._emulator.memory.write_ptr(memptr, ptr)
        return 0

    def aligned_alloc(self, alignment: int, size: int) -> int:
        """
        C11 aligned allocation.
        
        void* aligned_alloc(size_t alignment, size_t size);
        """
        if size % alignment != 0:
            return 0
        return self.memalign(alignment, size)

    def valloc(self, size: int) -> int:
        """
        Allocate page-aligned memory.
        
        void* valloc(size_t size);
        """
        return self.memalign(4096, size)

    def pvalloc(self, size: int) -> int:
        """
        Allocate page-aligned memory (rounded up).
        
        void* pvalloc(size_t size);
        """
        page_size = 4096
        aligned_size = self._align(size, page_size)
        return self.memalign(page_size, aligned_size)

    # ==================== Memory operations ====================

    def memcpy(self, dest: int, src: int, n: int) -> int:
        """
        Copy memory area.
        
        void* memcpy(void* dest, const void* src, size_t n);
        """
        if n > 0:
            mem = self._emulator.memory
            data = mem.read(src, n)
            mem.write(dest, data)
        return dest

    def memmove(self, dest: int, src: int, n: int) -> int:
        """
        Copy memory area (handles overlapping).
        
        void* memmove(void* dest, const void* src, size_t n);
        """
        if n > 0:
            mem = self._emulator.memory
            data = mem.read(src, n)
            mem.write(dest, data)
        return dest

    def memset(self, s: int, c: int, n: int) -> int:
        """
        Fill memory with a constant byte.
        
        void* memset(void* s, int c, size_t n);
        """
        if n > 0:
            byte = c & 0xFF
            self._emulator.memory.write(s, bytes([byte]) * n)
        return s

    def memcmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare memory areas.
        
        int memcmp(const void* s1, const void* s2, size_t n);
        """
        if n == 0:
            return 0

        mem = self._emulator.memory
        data1 = mem.read(s1, n)
        data2 = mem.read(s2, n)

        for i in range(n):
            if data1[i] != data2[i]:
                return data1[i] - data2[i]
        return 0

    def memchr(self, s: int, c: int, n: int) -> int:
        """
        Scan memory for a character.
        
        void* memchr(const void* s, int c, size_t n);
        """
        if n == 0:
            return 0

        byte = c & 0xFF
        data = self._emulator.memory.read(s, n)

        try:
            idx = data.index(byte)
            return s + idx
        except ValueError:
            return 0

    def memrchr(self, s: int, c: int, n: int) -> int:
        """
        Scan memory for a character (reverse).
        
        void* memrchr(const void* s, int c, size_t n);
        """
        if n == 0:
            return 0

        byte = c & 0xFF
        data = self._emulator.memory.read(s, n)

        for i in range(n - 1, -1, -1):
            if data[i] == byte:
                return s + i
        return 0

    def memmem(self, haystack: int, haystacklen: int, needle: int, needlelen: int) -> int:
        """
        Locate a substring in memory.
        
        void* memmem(const void* haystack, size_t haystacklen,
                     const void* needle, size_t needlelen);
        """
        if needlelen == 0:
            return haystack
        if needlelen > haystacklen:
            return 0

        mem = self._emulator.memory
        hay = mem.read(haystack, haystacklen)
        ndl = mem.read(needle, needlelen)

        idx = hay.find(ndl)
        return haystack + idx if idx >= 0 else 0

    def memccpy(self, dest: int, src: int, c: int, n: int) -> int:
        """
        Copy memory until character found.
        
        void* memccpy(void* dest, const void* src, int c, size_t n);
        """
        byte = c & 0xFF
        mem = self._emulator.memory
        data = mem.read(src, n)

        try:
            idx = data.index(byte)
            mem.write(dest, data[:idx + 1])
            return dest + idx + 1
        except ValueError:
            mem.write(dest, data)
            return 0

    def bzero(self, s: int, n: int) -> None:
        """
        Zero memory (BSD).
        
        void bzero(void* s, size_t n);
        """
        self.memset(s, 0, n)

    def bcopy(self, src: int, dest: int, n: int) -> None:
        """
        Copy memory (BSD, note reversed args).
        
        void bcopy(const void* src, void* dest, size_t n);
        """
        self.memmove(dest, src, n)

    def bcmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare memory (BSD).
        
        int bcmp(const void* s1, const void* s2, size_t n);
        """
        return self.memcmp(s1, s2, n)

    def explicit_bzero(self, s: int, n: int) -> None:
        """
        Zero memory (not optimized away).
        
        void explicit_bzero(void* s, size_t n);
        """
        self.bzero(s, n)

    # ==================== Heap info ====================

    def malloc_usable_size(self, ptr: int) -> int:
        """
        Get usable size of allocation.
        
        size_t malloc_usable_size(void* ptr);
        """
        block = self._allocations.get(ptr)
        return block.size if block else 0

    def get_heap_stats(self) -> dict:
        """Get heap statistics (Python API)."""
        return {
            "heap_base": self._heap_base,
            "heap_size": self._heap_size,
            "heap_used": self._heap_ptr - self._heap_base,
            "total_allocated": self._total_allocated,
            "total_freed": self._total_freed,
            "alloc_count": self._alloc_count,
            "free_count": self._free_count,
            "active_allocations": len(self._allocations),
            "free_blocks": len(self._free_list),
        }
