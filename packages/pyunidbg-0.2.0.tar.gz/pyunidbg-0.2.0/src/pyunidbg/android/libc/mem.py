"""
Memory manipulation functions (memcpy, memset, memmove, etc.)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class MemFunctions:
    """
    Memory manipulation function implementations.
    
    Implements:
    - memcpy, mempcpy, memmove
    - memset, memset_explicit
    - memcmp, memchr, memrchr, memmem
    - bzero, bcopy, bcmp (BSD legacy)
    - memccpy
    - memfrob (glibc)
    - swab
    - explicit_bzero
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

    def _read_bytes(self, ptr: int, n: int) -> bytes:
        """Read bytes from memory."""
        return self._emulator.memory.read(ptr, n)

    def _write_bytes(self, ptr: int, data: bytes) -> None:
        """Write bytes to memory."""
        self._emulator.memory.write(ptr, data)

    # ==================== Copy functions ====================

    def memcpy(self, dest: int, src: int, n: int) -> int:
        """
        Copy memory region.
        
        void* memcpy(void* dest, const void* src, size_t n);
        
        Behavior is undefined if regions overlap.
        """
        # Debug logging
        logger.debug(f"memcpy called: dest={dest} (type={type(dest)}), src={src} (type={type(src)}), n={n} (type={type(n)})")

        # Ensure arguments are integers
        try:
            n = int(n) if n else 0
            dest = int(dest) if dest else 0
            src = int(src) if src else 0
        except (TypeError, ValueError) as e:
            logger.error(f"memcpy type conversion error: {e}")
            return dest if isinstance(dest, int) else 0

        if n == 0 or dest == src:
            return dest

        data = self._read_bytes(src, n)
        self._write_bytes(dest, data)
        return dest

    def mempcpy(self, dest: int, src: int, n: int) -> int:
        """
        Copy memory region, return end of dest.
        
        void* mempcpy(void* dest, const void* src, size_t n);
        """
        n = int(n) if n else 0
        dest = int(dest) if dest else 0
        self.memcpy(dest, src, n)
        return dest + n

    def memmove(self, dest: int, src: int, n: int) -> int:
        """
        Copy memory region (handles overlap).
        
        void* memmove(void* dest, const void* src, size_t n);
        """
        n = int(n) if n else 0
        dest = int(dest) if dest else 0
        src = int(src) if src else 0

        if n == 0 or dest == src:
            return dest

        # Read all data first, then write
        # This handles overlapping regions correctly
        data = self._read_bytes(src, n)
        self._write_bytes(dest, data)
        return dest

    def memccpy(self, dest: int, src: int, c: int, n: int) -> int:
        """
        Copy memory until character found.
        
        void* memccpy(void* dest, const void* src, int c, size_t n);
        
        Returns pointer to byte after c in dest, or NULL if c not found.
        """
        c_byte = c & 0xFF
        data = self._read_bytes(src, n)

        for i, byte in enumerate(data):
            self._emulator.memory.write_u8(dest + i, byte)
            if byte == c_byte:
                return dest + i + 1

        return 0

    # ==================== Set functions ====================

    def memset(self, s: int, c: int, n: int) -> int:
        """
        Fill memory with byte value.
        
        void* memset(void* s, int c, size_t n);
        """
        if n == 0:
            return s

        byte = c & 0xFF
        data = bytes([byte] * n)
        self._write_bytes(s, data)
        return s

    def memset_explicit(self, s: int, c: int, n: int) -> int:
        """
        Fill memory with byte value (not optimized away).
        
        void* memset_explicit(void* s, int c, size_t n);
        
        This is like memset but guaranteed not to be optimized away.
        """
        return self.memset(s, c, n)

    # ==================== Comparison functions ====================

    def memcmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare memory regions.
        
        int memcmp(const void* s1, const void* s2, size_t n);
        """
        if n == 0:
            return 0

        data1 = self._read_bytes(s1, n)
        data2 = self._read_bytes(s2, n)

        for i in range(n):
            if data1[i] < data2[i]:
                return -1
            elif data1[i] > data2[i]:
                return 1

        return 0

    # ==================== Search functions ====================

    def memchr(self, s: int, c: int, n: int) -> int:
        """
        Find byte in memory region.
        
        void* memchr(const void* s, int c, size_t n);
        """
        if n == 0:
            return 0

        c_byte = c & 0xFF
        data = self._read_bytes(s, n)

        for i, byte in enumerate(data):
            if byte == c_byte:
                return s + i

        return 0

    def memrchr(self, s: int, c: int, n: int) -> int:
        """
        Find byte in memory region (reverse).
        
        void* memrchr(const void* s, int c, size_t n);
        """
        if n == 0:
            return 0

        c_byte = c & 0xFF
        data = self._read_bytes(s, n)

        for i in range(n - 1, -1, -1):
            if data[i] == c_byte:
                return s + i

        return 0

    def memmem(self, haystack: int, haystacklen: int, needle: int, needlelen: int) -> int:
        """
        Find memory region in memory.
        
        void* memmem(const void* haystack, size_t haystacklen,
                     const void* needle, size_t needlelen);
        """
        if needlelen == 0:
            return haystack

        if haystacklen < needlelen:
            return 0

        hay = self._read_bytes(haystack, haystacklen)
        ndl = self._read_bytes(needle, needlelen)

        idx = hay.find(ndl)
        if idx >= 0:
            return haystack + idx

        return 0

    def rawmemchr(self, s: int, c: int) -> int:
        """
        Find byte in memory (no bounds check).
        
        void* rawmemchr(const void* s, int c);
        
        DANGER: Must find byte or behavior is undefined.
        """
        c_byte = c & 0xFF
        offset = 0

        while True:
            byte = self._emulator.memory.read_u8(s + offset)
            if byte == c_byte:
                return s + offset
            offset += 1
            if offset > 0x10000:  # Safety limit
                logger.warning("rawmemchr exceeded safety limit")
                return 0

    # ==================== BSD legacy functions ====================

    def bzero(self, s: int, n: int) -> None:
        """
        Zero memory region (BSD legacy).
        
        void bzero(void* s, size_t n);
        
        Deprecated, use memset(s, 0, n) instead.
        """
        self.memset(s, 0, n)

    def explicit_bzero(self, s: int, n: int) -> None:
        """
        Zero memory region (not optimized away).
        
        void explicit_bzero(void* s, size_t n);
        """
        self.memset(s, 0, n)

    def bcopy(self, src: int, dest: int, n: int) -> None:
        """
        Copy memory region (BSD legacy).
        
        void bcopy(const void* src, void* dest, size_t n);
        
        Note: Arguments are reversed compared to memcpy!
        Deprecated, use memmove instead.
        """
        self.memmove(dest, src, n)

    def bcmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare memory regions (BSD legacy).
        
        int bcmp(const void* s1, const void* s2, size_t n);
        
        Returns 0 if equal, non-zero otherwise.
        Deprecated, use memcmp instead.
        """
        return self.memcmp(s1, s2, n)

    # ==================== Utility functions ====================

    def memfrob(self, s: int, n: int) -> int:
        """
        XOR memory with 42 (glibc joke function).
        
        void* memfrob(void* s, size_t n);
        """
        if n == 0:
            return s

        data = bytearray(self._read_bytes(s, n))
        for i in range(n):
            data[i] ^= 42
        self._write_bytes(s, bytes(data))
        return s

    def swab(self, from_: int, to_: int, n: int) -> None:
        """
        Swap adjacent bytes.
        
        void swab(const void* from, void* to, ssize_t n);
        """
        if n <= 1:
            return

        # Process pairs only
        pairs = n // 2
        data = bytearray(self._read_bytes(from_, pairs * 2))

        for i in range(0, pairs * 2, 2):
            data[i], data[i + 1] = data[i + 1], data[i]

        self._write_bytes(to_, bytes(data))
