"""
Standard I/O functions (printf, sprintf, fopen, fread, etc.)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class FileMode(IntEnum):
    """File modes."""
    READ = 0
    WRITE = 1
    APPEND = 2
    READ_WRITE = 3
    READ_APPEND = 4


class SeekOrigin(IntEnum):
    """Seek origins."""
    SEEK_SET = 0
    SEEK_CUR = 1
    SEEK_END = 2


# Standard file descriptors
STDIN_FILENO = 0
STDOUT_FILENO = 1
STDERR_FILENO = 2

# EOF marker
EOF = -1

# Buffer sizes
BUFSIZ = 8192
FILENAME_MAX = 4096


@dataclass
class FileStream:
    """Represents an open file stream (FILE*)."""
    fd: int
    mode: FileMode
    buffer: bytearray = field(default_factory=bytearray)
    position: int = 0
    eof: bool = False
    error: bool = False
    is_binary: bool = False
    path: str = ""
    ungetc_buffer: list = field(default_factory=list)


class StdioFunctions:
    """
    Standard I/O function implementations.
    
    Implements:
    - printf, fprintf, sprintf, snprintf, vprintf, vfprintf, vsprintf, vsnprintf
    - scanf, fscanf, sscanf, vscanf, vfscanf, vsscanf
    - fopen, fclose, freopen, fdopen
    - fread, fwrite
    - fgetc, fputc, getc, putc, getchar, putchar
    - fgets, fputs, gets, puts
    - fseek, ftell, rewind, fseeko, ftello
    - fflush, setbuf, setvbuf
    - ferror, feof, clearerr
    - fileno, fwide
    - perror
    - tmpfile, tmpnam
    - remove, rename
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # File streams indexed by FILE* pointer
        self._streams: dict[int, FileStream] = {}
        self._next_stream_ptr = 0xF0000000

        # Standard streams
        self._init_standard_streams()

        # Output capture
        self._stdout_buffer = bytearray()
        self._stderr_buffer = bytearray()

    def _init_standard_streams(self):
        """Initialize stdin, stdout, stderr."""
        # stdin
        stdin_ptr = self._next_stream_ptr
        self._next_stream_ptr += 0x100
        self._streams[stdin_ptr] = FileStream(
            fd=STDIN_FILENO,
            mode=FileMode.READ,
            path="<stdin>"
        )
        self._stdin = stdin_ptr

        # stdout
        stdout_ptr = self._next_stream_ptr
        self._next_stream_ptr += 0x100
        self._streams[stdout_ptr] = FileStream(
            fd=STDOUT_FILENO,
            mode=FileMode.WRITE,
            path="<stdout>"
        )
        self._stdout = stdout_ptr

        # stderr
        stderr_ptr = self._next_stream_ptr
        self._next_stream_ptr += 0x100
        self._streams[stderr_ptr] = FileStream(
            fd=STDERR_FILENO,
            mode=FileMode.WRITE,
            path="<stderr>"
        )
        self._stderr = stderr_ptr

    def _read_string(self, ptr: int, max_len: int = 4096) -> str:
        """Read null-terminated string from memory."""
        return self._emulator.memory.read_string(ptr, max_len)

    def _write_string(self, ptr: int, s: str) -> None:
        """Write null-terminated string to memory."""
        self._emulator.memory.write(ptr, s.encode('utf-8') + b'\x00')

    def _parse_mode(self, mode_str: str) -> tuple[FileMode, bool]:
        """Parse fopen mode string."""
        is_binary = 'b' in mode_str
        mode_str = mode_str.replace('b', '')

        if mode_str in ('r', 'r+'):
            return (FileMode.READ if '+' not in mode_str else FileMode.READ_WRITE, is_binary)
        elif mode_str in ('w', 'w+'):
            return (FileMode.WRITE if '+' not in mode_str else FileMode.READ_WRITE, is_binary)
        elif mode_str in ('a', 'a+'):
            return (FileMode.APPEND if '+' not in mode_str else FileMode.READ_APPEND, is_binary)
        else:
            return (FileMode.READ, is_binary)

    # ==================== printf family ====================

    def _format_printf(self, fmt_ptr: int, args: list) -> str:
        """Format a printf-style string with arguments."""
        fmt = self._read_string(fmt_ptr)
        return self._format_string(fmt, args)

    def _format_string(self, fmt: str, args: list) -> str:
        """Format string with given arguments."""
        result = []
        arg_idx = 0
        i = 0

        while i < len(fmt):
            if fmt[i] == '%':
                if i + 1 < len(fmt) and fmt[i + 1] == '%':
                    result.append('%')
                    i += 2
                    continue

                # Parse format specifier
                spec_start = i
                i += 1

                # Flags
                flags = ''
                while i < len(fmt) and fmt[i] in '-+ #0':
                    flags += fmt[i]
                    i += 1

                # Width
                width = ''
                if i < len(fmt) and fmt[i] == '*':
                    width = str(args[arg_idx]) if arg_idx < len(args) else '0'
                    arg_idx += 1
                    i += 1
                else:
                    while i < len(fmt) and fmt[i].isdigit():
                        width += fmt[i]
                        i += 1

                # Precision
                precision = ''
                if i < len(fmt) and fmt[i] == '.':
                    i += 1
                    if i < len(fmt) and fmt[i] == '*':
                        precision = str(args[arg_idx]) if arg_idx < len(args) else '0'
                        arg_idx += 1
                        i += 1
                    else:
                        while i < len(fmt) and fmt[i].isdigit():
                            precision += fmt[i]
                            i += 1

                # Length modifier
                length = ''
                while i < len(fmt) and fmt[i] in 'hlLzjt':
                    length += fmt[i]
                    i += 1

                # Conversion specifier
                if i >= len(fmt):
                    break

                conv = fmt[i]
                i += 1

                # Get argument
                if arg_idx >= len(args):
                    value = 0
                else:
                    value = args[arg_idx]
                    arg_idx += 1

                # Format based on conversion
                formatted = self._format_value(value, conv, flags, width, precision, length)
                result.append(formatted)
            else:
                result.append(fmt[i])
                i += 1

        return ''.join(result)

    def _format_value(self, value: Any, conv: str, flags: str, width: str, precision: str, length: str) -> str:
        """Format a single value according to printf specifier."""
        width_int = int(width) if width else 0
        prec_int = int(precision) if precision else -1

        left_align = '-' in flags
        sign = '+' if '+' in flags else (' ' if ' ' in flags else '')
        alt_form = '#' in flags
        zero_pad = '0' in flags and not left_align

        if conv == 'd' or conv == 'i':
            # Signed decimal
            val = int(value) if isinstance(value, (int, float)) else 0
            s = f"{sign}{val}" if val >= 0 and sign else str(val)
            if zero_pad and width_int > len(s):
                s = s[0:1].replace('-', '') + s.lstrip('-').zfill(width_int - (1 if val < 0 or sign else 0))
                if val < 0:
                    s = '-' + s
                elif sign:
                    s = sign + s
        elif conv == 'u':
            # Unsigned decimal
            val = int(value) & 0xFFFFFFFF
            s = str(val)
        elif conv == 'x' or conv == 'X':
            # Hexadecimal
            val = int(value) & 0xFFFFFFFF if isinstance(value, (int, float)) else 0
            s = hex(val)[2:]
            if conv == 'X':
                s = s.upper()
            if alt_form and val != 0:
                s = ('0x' if conv == 'x' else '0X') + s
        elif conv == 'o':
            # Octal
            val = int(value) & 0xFFFFFFFF if isinstance(value, (int, float)) else 0
            s = oct(val)[2:]
            if alt_form and val != 0:
                s = '0' + s
        elif conv == 'f' or conv == 'F':
            # Float
            val = float(value) if isinstance(value, (int, float)) else 0.0
            prec = prec_int if prec_int >= 0 else 6
            s = f"{val:.{prec}f}"
        elif conv == 'e' or conv == 'E':
            # Scientific notation
            val = float(value) if isinstance(value, (int, float)) else 0.0
            prec = prec_int if prec_int >= 0 else 6
            s = f"{val:.{prec}e}"
            if conv == 'E':
                s = s.upper()
        elif conv == 'g' or conv == 'G':
            # Shortest representation
            val = float(value) if isinstance(value, (int, float)) else 0.0
            prec = prec_int if prec_int >= 0 else 6
            s = f"{val:.{prec}g}"
            if conv == 'G':
                s = s.upper()
        elif conv == 'c':
            # Character
            if isinstance(value, int):
                s = chr(value & 0xFF)
            else:
                s = str(value)[:1]
        elif conv == 's':
            # String
            if isinstance(value, int) and value != 0:
                s = self._read_string(value)
            elif isinstance(value, str):
                s = value
            else:
                s = "(null)"
            if prec_int >= 0:
                s = s[:prec_int]
        elif conv == 'p':
            # Pointer
            val = int(value) if isinstance(value, int) else 0
            s = hex(val)
        elif conv == 'n':
            # Store count - not supported in this implementation
            s = ''
        else:
            s = f"%{conv}"

        # Apply width
        if width_int > len(s):
            if left_align:
                s = s.ljust(width_int)
            elif zero_pad:
                # Zero-pad (for numeric types like %02x)
                s = s.zfill(width_int)
            else:
                s = s.rjust(width_int)

        return s

    def printf(self, fmt: int, *args) -> int:
        """
        Print formatted output to stdout.
        
        int printf(const char* fmt, ...);
        """
        output = self._format_printf(fmt, list(args))
        self._stdout_buffer.extend(output.encode('utf-8'))
        logger.debug(f"printf: {output}")
        return len(output)

    def fprintf(self, stream: int, fmt: int, *args) -> int:
        """
        Print formatted output to stream.
        
        int fprintf(FILE* stream, const char* fmt, ...);
        """
        if stream not in self._streams:
            return -1

        output = self._format_printf(fmt, list(args))
        file_stream = self._streams[stream]

        if stream == self._stdout:
            self._stdout_buffer.extend(output.encode('utf-8'))
        elif stream == self._stderr:
            self._stderr_buffer.extend(output.encode('utf-8'))
        else:
            file_stream.buffer.extend(output.encode('utf-8'))

        return len(output)

    def sprintf(self, str_ptr: int, fmt: int, *args) -> int:
        """
        Print formatted output to string.
        
        int sprintf(char* str, const char* fmt, ...);
        """
        output = self._format_printf(fmt, list(args))
        self._write_string(str_ptr, output)
        return len(output)

    def snprintf(self, str_ptr: int, size: int, fmt: int, *args) -> int:
        """
        Print formatted output to string (bounded).
        
        int snprintf(char* str, size_t size, const char* fmt, ...);
        """
        output = self._format_printf(fmt, list(args))
        total_len = len(output)

        if size > 0:
            truncated = output[:size - 1]
            self._write_string(str_ptr, truncated)

        return total_len

    def vprintf(self, fmt: int, ap: int) -> int:
        """
        Print formatted output to stdout (va_list).
        
        int vprintf(const char* fmt, va_list ap);
        """
        # In emulated environment, va_list handling is complex
        # For now, just format with empty args
        return self.printf(fmt)

    def vfprintf(self, stream: int, fmt: int, ap: int) -> int:
        """
        Print formatted output to stream (va_list).
        
        int vfprintf(FILE* stream, const char* fmt, va_list ap);
        """
        return self.fprintf(stream, fmt)

    def vsprintf(self, str_ptr: int, fmt: int, ap: int) -> int:
        """
        Print formatted output to string (va_list).
        
        int vsprintf(char* str, const char* fmt, va_list ap);
        """
        return self.sprintf(str_ptr, fmt)

    def vsnprintf(self, str_ptr: int, size: int, fmt: int, ap: int) -> int:
        """
        Print formatted output to string (bounded, va_list).
        
        int vsnprintf(char* str, size_t size, const char* fmt, va_list ap);
        """
        return self.snprintf(str_ptr, size, fmt)

    def dprintf(self, fd: int, fmt: int, *args) -> int:
        """
        Print to file descriptor.
        
        int dprintf(int fd, const char* fmt, ...);
        """
        output = self._format_printf(fmt, list(args))
        # Would write to fd
        return len(output)

    def asprintf(self, strp: int, fmt: int, *args) -> int:
        """
        Allocate and print to string.
        
        int asprintf(char** strp, const char* fmt, ...);
        """
        output = self._format_printf(fmt, list(args))
        length = len(output) + 1
        ptr = self._handler.memory.malloc(length)
        if ptr:
            self._write_string(ptr, output)
            self._emulator.memory.write_ptr(strp, ptr)
            return len(output)
        return -1

    # ==================== File open/close ====================

    def fopen(self, filename: int, mode: int) -> int:
        """
        Open file.
        
        FILE* fopen(const char* filename, const char* mode);
        """
        path = self._read_string(filename)
        mode_str = self._read_string(mode)

        file_mode, is_binary = self._parse_mode(mode_str)

        # Create stream
        stream_ptr = self._next_stream_ptr
        self._next_stream_ptr += 0x100

        self._streams[stream_ptr] = FileStream(
            fd=len(self._streams) + 3,
            mode=file_mode,
            path=path,
            is_binary=is_binary
        )

        logger.debug(f"fopen({path}, {mode_str}) = 0x{stream_ptr:x}")
        return stream_ptr

    def fclose(self, stream: int) -> int:
        """
        Close file.
        
        int fclose(FILE* stream);
        """
        if stream not in self._streams:
            return EOF

        del self._streams[stream]
        return 0

    def freopen(self, filename: int, mode: int, stream: int) -> int:
        """
        Reopen file with different mode.
        
        FILE* freopen(const char* filename, const char* mode, FILE* stream);
        """
        if stream in self._streams:
            del self._streams[stream]

        return self.fopen(filename, mode)

    def fdopen(self, fd: int, mode: int) -> int:
        """
        Associate stream with file descriptor.
        
        FILE* fdopen(int fd, const char* mode);
        """
        mode_str = self._read_string(mode)
        file_mode, is_binary = self._parse_mode(mode_str)

        stream_ptr = self._next_stream_ptr
        self._next_stream_ptr += 0x100

        self._streams[stream_ptr] = FileStream(
            fd=fd,
            mode=file_mode,
            is_binary=is_binary,
            path=f"<fd:{fd}>"
        )

        return stream_ptr

    # ==================== Read/Write ====================

    def fread(self, ptr: int, size: int, nmemb: int, stream: int) -> int:
        """
        Read from stream.
        
        size_t fread(void* ptr, size_t size, size_t nmemb, FILE* stream);
        """
        if stream not in self._streams:
            return 0

        file_stream = self._streams[stream]
        total = size * nmemb

        # For now, return 0 (no data)
        file_stream.eof = True
        return 0

    def fwrite(self, ptr: int, size: int, nmemb: int, stream: int) -> int:
        """
        Write to stream.
        
        size_t fwrite(const void* ptr, size_t size, size_t nmemb, FILE* stream);
        """
        if stream not in self._streams:
            return 0

        file_stream = self._streams[stream]
        total = size * nmemb
        data = self._emulator.memory.read(ptr, total)

        if stream == self._stdout:
            self._stdout_buffer.extend(data)
        elif stream == self._stderr:
            self._stderr_buffer.extend(data)
        else:
            file_stream.buffer.extend(data)

        return nmemb

    # ==================== Character I/O ====================

    def fgetc(self, stream: int) -> int:
        """
        Read character from stream.
        
        int fgetc(FILE* stream);
        """
        if stream not in self._streams:
            return EOF

        file_stream = self._streams[stream]

        if file_stream.ungetc_buffer:
            return file_stream.ungetc_buffer.pop()

        file_stream.eof = True
        return EOF

    def fputc(self, c: int, stream: int) -> int:
        """
        Write character to stream.
        
        int fputc(int c, FILE* stream);
        """
        if stream not in self._streams:
            return EOF

        byte = bytes([c & 0xFF])

        if stream == self._stdout:
            self._stdout_buffer.extend(byte)
        elif stream == self._stderr:
            self._stderr_buffer.extend(byte)
        else:
            self._streams[stream].buffer.extend(byte)

        return c & 0xFF

    def getc(self, stream: int) -> int:
        """Alias for fgetc."""
        return self.fgetc(stream)

    def putc(self, c: int, stream: int) -> int:
        """Alias for fputc."""
        return self.fputc(c, stream)

    def getchar(self) -> int:
        """Read from stdin."""
        return self.fgetc(self._stdin)

    def putchar(self, c: int) -> int:
        """Write to stdout."""
        return self.fputc(c, self._stdout)

    def ungetc(self, c: int, stream: int) -> int:
        """
        Push character back to stream.
        
        int ungetc(int c, FILE* stream);
        """
        if stream not in self._streams or c == EOF:
            return EOF

        self._streams[stream].ungetc_buffer.append(c & 0xFF)
        self._streams[stream].eof = False
        return c & 0xFF

    # ==================== Line I/O ====================

    def fgets(self, s: int, size: int, stream: int) -> int:
        """
        Read line from stream.
        
        char* fgets(char* s, int size, FILE* stream);
        """
        if stream not in self._streams or size <= 0:
            return 0

        file_stream = self._streams[stream]
        file_stream.eof = True
        self._emulator.memory.write_u8(s, 0)
        return 0

    def fputs(self, s: int, stream: int) -> int:
        """
        Write string to stream.
        
        int fputs(const char* s, FILE* stream);
        """
        if stream not in self._streams:
            return EOF

        string = self._read_string(s)
        data = string.encode('utf-8')

        if stream == self._stdout:
            self._stdout_buffer.extend(data)
        elif stream == self._stderr:
            self._stderr_buffer.extend(data)
        else:
            self._streams[stream].buffer.extend(data)

        return 1

    def puts(self, s: int) -> int:
        """
        Write string to stdout with newline.
        
        int puts(const char* s);
        """
        result = self.fputs(s, self._stdout)
        if result != EOF:
            self._stdout_buffer.extend(b'\n')
        return result

    def gets(self, s: int) -> int:
        """
        Read line from stdin (UNSAFE, deprecated).
        
        char* gets(char* s);
        """
        return self.fgets(s, BUFSIZ, self._stdin)

    # ==================== Positioning ====================

    def fseek(self, stream: int, offset: int, whence: int) -> int:
        """
        Set file position.
        
        int fseek(FILE* stream, long offset, int whence);
        """
        if stream not in self._streams:
            return -1

        file_stream = self._streams[stream]

        if whence == SeekOrigin.SEEK_SET:
            file_stream.position = offset
        elif whence == SeekOrigin.SEEK_CUR:
            file_stream.position += offset
        elif whence == SeekOrigin.SEEK_END:
            file_stream.position = len(file_stream.buffer) + offset
        else:
            return -1

        file_stream.eof = False
        return 0

    def ftell(self, stream: int) -> int:
        """
        Get file position.
        
        long ftell(FILE* stream);
        """
        if stream not in self._streams:
            return -1
        return self._streams[stream].position

    def rewind(self, stream: int) -> None:
        """
        Rewind file to beginning.
        
        void rewind(FILE* stream);
        """
        self.fseek(stream, 0, SeekOrigin.SEEK_SET)

    def fseeko(self, stream: int, offset: int, whence: int) -> int:
        """fseek with off_t offset."""
        return self.fseek(stream, offset, whence)

    def ftello(self, stream: int) -> int:
        """ftell returning off_t."""
        return self.ftell(stream)

    # ==================== Buffering ====================

    def fflush(self, stream: int) -> int:
        """
        Flush stream buffer.
        
        int fflush(FILE* stream);
        """
        # In our implementation, writes are immediate
        return 0

    def setbuf(self, stream: int, buf: int) -> None:
        """
        Set stream buffer.
        
        void setbuf(FILE* stream, char* buf);
        """
        pass  # No-op in our implementation

    def setvbuf(self, stream: int, buf: int, mode: int, size: int) -> int:
        """
        Set stream buffering.
        
        int setvbuf(FILE* stream, char* buf, int mode, size_t size);
        """
        return 0

    # ==================== Status ====================

    def ferror(self, stream: int) -> int:
        """
        Check error indicator.
        
        int ferror(FILE* stream);
        """
        if stream not in self._streams:
            return 1
        return 1 if self._streams[stream].error else 0

    def feof(self, stream: int) -> int:
        """
        Check end-of-file indicator.
        
        int feof(FILE* stream);
        """
        if stream not in self._streams:
            return 1
        return 1 if self._streams[stream].eof else 0

    def clearerr(self, stream: int) -> None:
        """
        Clear error and EOF indicators.
        
        void clearerr(FILE* stream);
        """
        if stream in self._streams:
            self._streams[stream].error = False
            self._streams[stream].eof = False

    def fileno(self, stream: int) -> int:
        """
        Get file descriptor.
        
        int fileno(FILE* stream);
        """
        if stream not in self._streams:
            return -1
        return self._streams[stream].fd

    # ==================== Error ====================

    def perror(self, s: int) -> None:
        """
        Print error message.
        
        void perror(const char* s);
        """
        prefix = self._read_string(s) if s else ""
        msg = "Unknown error"

        if prefix:
            output = f"{prefix}: {msg}\n"
        else:
            output = f"{msg}\n"

        self._stderr_buffer.extend(output.encode('utf-8'))

    # ==================== Utility ====================

    def remove(self, filename: int) -> int:
        """
        Remove file.
        
        int remove(const char* filename);
        """
        path = self._read_string(filename)
        logger.debug(f"remove({path})")
        return 0

    def rename(self, oldpath: int, newpath: int) -> int:
        """
        Rename file.
        
        int rename(const char* oldpath, const char* newpath);
        """
        old = self._read_string(oldpath)
        new = self._read_string(newpath)
        logger.debug(f"rename({old}, {new})")
        return 0

    def tmpfile(self) -> int:
        """
        Create temporary file.
        
        FILE* tmpfile(void);
        """
        stream_ptr = self._next_stream_ptr
        self._next_stream_ptr += 0x100

        self._streams[stream_ptr] = FileStream(
            fd=len(self._streams) + 3,
            mode=FileMode.READ_WRITE,
            path="<tmpfile>"
        )

        return stream_ptr

    def tmpnam(self, s: int) -> int:
        """
        Generate temporary filename.
        
        char* tmpnam(char* s);
        """
        import random
        name = f"/tmp/tmp{random.randint(100000, 999999)}"

        if s:
            self._write_string(s, name)
            return s
        else:
            ptr = self._handler.memory.malloc(len(name) + 1)
            self._write_string(ptr, name)
            return ptr

    # ==================== Get captured output ====================

    def get_stdout(self) -> bytes:
        """Get captured stdout output."""
        return bytes(self._stdout_buffer)

    def get_stderr(self) -> bytes:
        """Get captured stderr output."""
        return bytes(self._stderr_buffer)

    def clear_output(self) -> None:
        """Clear captured output."""
        self._stdout_buffer.clear()
        self._stderr_buffer.clear()
