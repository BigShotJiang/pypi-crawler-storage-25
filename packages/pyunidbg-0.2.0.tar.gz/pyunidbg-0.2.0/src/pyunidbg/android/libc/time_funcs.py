"""
Time and date functions (time, gettimeofday, clock_gettime, etc.)
"""

from __future__ import annotations

import logging
import time
from enum import IntEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class ClockId(IntEnum):
    """Clock IDs for clock_gettime."""
    CLOCK_REALTIME = 0
    CLOCK_MONOTONIC = 1
    CLOCK_PROCESS_CPUTIME_ID = 2
    CLOCK_THREAD_CPUTIME_ID = 3
    CLOCK_MONOTONIC_RAW = 4
    CLOCK_REALTIME_COARSE = 5
    CLOCK_MONOTONIC_COARSE = 6
    CLOCK_BOOTTIME = 7
    CLOCK_REALTIME_ALARM = 8
    CLOCK_BOOTTIME_ALARM = 9


class TimeFunctions:
    """
    Time and date function implementations.
    
    Implements:
    - time, difftime
    - gettimeofday, settimeofday
    - clock, clock_gettime, clock_getres, clock_settime
    - gmtime, gmtime_r, localtime, localtime_r
    - mktime, timegm
    - strftime, strptime
    - asctime, asctime_r, ctime, ctime_r
    - nanosleep, usleep, sleep
    - gettid, getpid, getppid
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Start time for monotonic clock
        self._monotonic_start = time.monotonic_ns()
        self._start_time = time.time()

    @property
    def _is_64bit(self) -> bool:
        """Check if emulator is 64-bit."""
        return self._emulator.is_64bit

    def _write_timespec(self, ptr: int, sec: int, nsec: int) -> None:
        """Write a timespec structure to memory."""
        # struct timespec { time_t tv_sec; long tv_nsec; }
        # On 64-bit: both are 8 bytes. On 32-bit: both are 4 bytes.
        if self._is_64bit:
            self._emulator.memory.write_u64(ptr, sec)
            self._emulator.memory.write_u64(ptr + 8, nsec)
        else:
            self._emulator.memory.write_u32(ptr, sec)
            self._emulator.memory.write_u32(ptr + 4, nsec)

    def _read_timespec(self, ptr: int) -> tuple[int, int]:
        """Read a timespec structure from memory."""
        if self._is_64bit:
            sec = self._emulator.memory.read_u64(ptr)
            nsec = self._emulator.memory.read_u64(ptr + 8)
        else:
            sec = self._emulator.memory.read_u32(ptr)
            nsec = self._emulator.memory.read_u32(ptr + 4)
        return (sec, nsec)

    def _write_timeval(self, ptr: int, sec: int, usec: int) -> None:
        """Write a timeval structure to memory."""
        # struct timeval { time_t tv_sec; suseconds_t tv_usec; }
        # On 64-bit: both are 8 bytes. On 32-bit: both are 4 bytes.
        if self._is_64bit:
            self._emulator.memory.write_u64(ptr, sec)
            self._emulator.memory.write_u64(ptr + 8, usec)
        else:
            self._emulator.memory.write_u32(ptr, sec)
            self._emulator.memory.write_u32(ptr + 4, usec)

    def _read_timeval(self, ptr: int) -> tuple[int, int]:
        """Read a timeval structure from memory."""
        if self._is_64bit:
            sec = self._emulator.memory.read_u64(ptr)
            usec = self._emulator.memory.read_u64(ptr + 8)
        else:
            sec = self._emulator.memory.read_u32(ptr)
            usec = self._emulator.memory.read_u32(ptr + 4)
        return (sec, usec)

    def _write_tm(self, ptr: int, t: time.struct_time) -> None:
        """Write a tm structure to memory."""
        # struct tm layout (4 bytes each field):
        # tm_sec, tm_min, tm_hour, tm_mday, tm_mon, tm_year,
        # tm_wday, tm_yday, tm_isdst
        self._emulator.memory.write_u32(ptr + 0, t.tm_sec)
        self._emulator.memory.write_u32(ptr + 4, t.tm_min)
        self._emulator.memory.write_u32(ptr + 8, t.tm_hour)
        self._emulator.memory.write_u32(ptr + 12, t.tm_mday)
        self._emulator.memory.write_u32(ptr + 16, t.tm_mon - 1)  # 0-based
        self._emulator.memory.write_u32(ptr + 20, t.tm_year - 1900)
        self._emulator.memory.write_u32(ptr + 24, t.tm_wday)
        self._emulator.memory.write_u32(ptr + 28, t.tm_yday - 1)  # 0-based
        self._emulator.memory.write_u32(ptr + 32, 1 if t.tm_isdst > 0 else 0)

    def _read_tm(self, ptr: int) -> dict:
        """Read a tm structure from memory."""
        return {
            'tm_sec': self._emulator.memory.read_u32(ptr + 0),
            'tm_min': self._emulator.memory.read_u32(ptr + 4),
            'tm_hour': self._emulator.memory.read_u32(ptr + 8),
            'tm_mday': self._emulator.memory.read_u32(ptr + 12),
            'tm_mon': self._emulator.memory.read_u32(ptr + 16) + 1,
            'tm_year': self._emulator.memory.read_u32(ptr + 20) + 1900,
            'tm_wday': self._emulator.memory.read_u32(ptr + 24),
            'tm_yday': self._emulator.memory.read_u32(ptr + 28) + 1,
            'tm_isdst': self._emulator.memory.read_u32(ptr + 32),
        }

    # ==================== Basic Time ====================

    def time(self, tloc: int) -> int:
        """
        Get current time.
        
        time_t time(time_t* tloc);
        """
        current = int(time.time())
        if tloc:
            self._emulator.memory.write_u32(tloc, current)
        return current

    def difftime(self, time1: int, time0: int) -> float:
        """
        Calculate time difference.
        
        double difftime(time_t time1, time_t time0);
        """
        return float(time1 - time0)

    # ==================== gettimeofday ====================

    def gettimeofday(self, tv: int, tz: int) -> int:
        """
        Get current time with microseconds.
        
        int gettimeofday(struct timeval* tv, struct timezone* tz);
        """
        if tv:
            current = time.time()
            sec = int(current)
            usec = int((current - sec) * 1000000)
            self._write_timeval(tv, sec, usec)

        if tz:
            # timezone struct: tz_minuteswest, tz_dsttime
            self._emulator.memory.write_u32(tz, 0)
            self._emulator.memory.write_u32(tz + 4, 0)

        return 0

    # ==================== clock_gettime ====================

    def clock_gettime(self, clk_id: int, tp: int) -> int:
        """
        Get time from specific clock.
        
        int clock_gettime(clockid_t clk_id, struct timespec* tp);
        """
        if not tp:
            return -1

        if clk_id in (ClockId.CLOCK_REALTIME, ClockId.CLOCK_REALTIME_COARSE):
            current = time.time()
            sec = int(current)
            nsec = int((current - sec) * 1e9)
        elif clk_id in (ClockId.CLOCK_MONOTONIC, ClockId.CLOCK_MONOTONIC_RAW,
                        ClockId.CLOCK_MONOTONIC_COARSE, ClockId.CLOCK_BOOTTIME):
            elapsed = time.monotonic_ns() - self._monotonic_start
            sec = elapsed // 1000000000
            nsec = elapsed % 1000000000
        elif clk_id in (ClockId.CLOCK_PROCESS_CPUTIME_ID, ClockId.CLOCK_THREAD_CPUTIME_ID):
            # CPU time approximation
            cpu = time.process_time()
            sec = int(cpu)
            nsec = int((cpu - sec) * 1e9)
        else:
            current = time.time()
            sec = int(current)
            nsec = int((current - sec) * 1e9)

        self._write_timespec(tp, sec, nsec)
        return 0

    def clock_getres(self, clk_id: int, res: int) -> int:
        """
        Get clock resolution.
        
        int clock_getres(clockid_t clk_id, struct timespec* res);
        """
        if res:
            # Report 1ns resolution
            self._write_timespec(res, 0, 1)
        return 0

    def clock_settime(self, clk_id: int, tp: int) -> int:
        """
        Set clock time.
        
        int clock_settime(clockid_t clk_id, const struct timespec* tp);
        """
        # Ignore, we don't actually set system time
        return 0

    def clock_nanosleep(self, clk_id: int, flags: int, request: int, remain: int) -> int:
        """
        Sleep with clock.
        
        int clock_nanosleep(clockid_t clk_id, int flags,
                           const struct timespec* request, struct timespec* remain);
        """
        if request:
            sec, nsec = self._read_timespec(request)
            # In emulation, we don't actually sleep
            logger.debug(f"clock_nanosleep: {sec}s {nsec}ns")

        if remain:
            self._write_timespec(remain, 0, 0)

        return 0

    # ==================== Time Conversion ====================

    def gmtime(self, timer: int) -> int:
        """
        Convert time to UTC tm structure.
        
        struct tm* gmtime(const time_t* timer);
        """
        if not timer:
            return 0

        t = self._emulator.memory.read_u32(timer)
        st = time.gmtime(t)

        # Allocate and write tm struct
        ptr = self._handler.memory.malloc(44)  # sizeof(struct tm)
        if ptr:
            self._write_tm(ptr, st)
        return ptr

    def gmtime_r(self, timer: int, result: int) -> int:
        """
        Convert time to UTC tm structure (reentrant).
        
        struct tm* gmtime_r(const time_t* timer, struct tm* result);
        """
        if not timer or not result:
            return 0

        t = self._emulator.memory.read_u32(timer)
        st = time.gmtime(t)
        self._write_tm(result, st)
        return result

    def localtime(self, timer: int) -> int:
        """
        Convert time to local tm structure.
        
        struct tm* localtime(const time_t* timer);
        """
        if not timer:
            return 0

        t = self._emulator.memory.read_u32(timer)
        st = time.localtime(t)

        ptr = self._handler.memory.malloc(44)
        if ptr:
            self._write_tm(ptr, st)
        return ptr

    def localtime_r(self, timer: int, result: int) -> int:
        """
        Convert time to local tm structure (reentrant).
        
        struct tm* localtime_r(const time_t* timer, struct tm* result);
        """
        if not timer or not result:
            return 0

        t = self._emulator.memory.read_u32(timer)
        st = time.localtime(t)
        self._write_tm(result, st)
        return result

    def mktime(self, tm: int) -> int:
        """
        Convert tm structure to time.
        
        time_t mktime(struct tm* tm);
        """
        if not tm:
            return -1

        tm_data = self._read_tm(tm)
        try:
            st = time.struct_time((
                tm_data['tm_year'], tm_data['tm_mon'], tm_data['tm_mday'],
                tm_data['tm_hour'], tm_data['tm_min'], tm_data['tm_sec'],
                tm_data['tm_wday'], tm_data['tm_yday'], tm_data['tm_isdst']
            ))
            return int(time.mktime(st))
        except (ValueError, OverflowError):
            return -1

    def timegm(self, tm: int) -> int:
        """
        Convert tm structure to time (UTC).
        
        time_t timegm(struct tm* tm);
        """
        if not tm:
            return -1

        tm_data = self._read_tm(tm)
        try:
            import calendar
            st = time.struct_time((
                tm_data['tm_year'], tm_data['tm_mon'], tm_data['tm_mday'],
                tm_data['tm_hour'], tm_data['tm_min'], tm_data['tm_sec'],
                tm_data['tm_wday'], tm_data['tm_yday'], tm_data['tm_isdst']
            ))
            return int(calendar.timegm(st))
        except (ValueError, OverflowError):
            return -1

    # ==================== String Formatting ====================

    def strftime(self, s: int, maxsize: int, format_: int, tm: int) -> int:
        """
        Format time to string.
        
        size_t strftime(char* s, size_t maxsize, const char* format, const struct tm* tm);
        """
        if not s or not format_ or not tm:
            return 0

        fmt = self._emulator.memory.read_string(format_, 256)
        tm_data = self._read_tm(tm)

        try:
            st = time.struct_time((
                tm_data['tm_year'], tm_data['tm_mon'], tm_data['tm_mday'],
                tm_data['tm_hour'], tm_data['tm_min'], tm_data['tm_sec'],
                tm_data['tm_wday'], tm_data['tm_yday'], tm_data['tm_isdst']
            ))
            result = time.strftime(fmt, st)

            if len(result) >= maxsize:
                return 0

            self._emulator.memory.write(s, result.encode() + b'\x00')
            return len(result)
        except (ValueError, OverflowError):
            return 0

    def strftime_l(self, s: int, maxsize: int, format_: int, tm: int, loc: int) -> int:
        """
        Format time to string with locale.
        
        size_t strftime_l(char* s, size_t maxsize, const char* format,
                          const struct tm* tm, locale_t loc);
        """
        return self.strftime(s, maxsize, format_, tm)

    def strptime(self, s: int, format_: int, tm: int) -> int:
        """
        Parse time string.
        
        char* strptime(const char* s, const char* format, struct tm* tm);
        Returns pointer to first character not parsed, or NULL on failure.
        """
        if not s or not format_ or not tm:
            return 0

        input_str = self._emulator.memory.read_string(s, 256)
        fmt = self._emulator.memory.read_string(format_, 256)

        # Convert C format specifiers to Python's strptime format
        # They are mostly compatible, but we need to handle edge cases
        try:
            import datetime
            parsed = datetime.datetime.strptime(input_str, fmt)

            # Write parsed values into struct tm
            mem = self._emulator.memory
            mem.write_u32(tm + 0, parsed.second)              # tm_sec
            mem.write_u32(tm + 4, parsed.minute)              # tm_min
            mem.write_u32(tm + 8, parsed.hour)                # tm_hour
            mem.write_u32(tm + 12, parsed.day)                # tm_mday
            mem.write_u32(tm + 16, parsed.month - 1)          # tm_mon (0-based)
            mem.write_u32(tm + 20, parsed.year - 1900)        # tm_year (since 1900)
            mem.write_u32(tm + 24, parsed.weekday())          # tm_wday (Mon=0 in Python)
            # Adjust: C has Sun=0, Python has Mon=0
            wday = (parsed.weekday() + 1) % 7
            mem.write_u32(tm + 24, wday)
            mem.write_u32(tm + 28, parsed.timetuple().tm_yday - 1)  # tm_yday (0-based)
            mem.write_u32(tm + 32, 0xFFFFFFFF)                # tm_isdst = -1 (unknown)

            # Return pointer past the consumed input
            return s + len(input_str)
        except (ValueError, OverflowError) as e:
            logger.debug(f"strptime failed: {e}")
            return 0

    def clock(self) -> int:
        """
        Get processor time.
        
        clock_t clock(void);
        """
        # Return monotonic time in CLOCKS_PER_SEC units
        elapsed = time.monotonic_ns() - self._monotonic_start
        return int(elapsed / 1000)  # microseconds

    def settimeofday(self, tv: int, tz: int) -> int:
        """
        Set time of day.
        
        int settimeofday(const struct timeval* tv, const struct timezone* tz);
        """
        # Ignore - we don't set system time
        return 0

    def timer_create(self, clockid: int, sevp: int, timerid: int) -> int:
        """
        Create a timer.
        
        int timer_create(clockid_t clockid, struct sigevent* sevp, timer_t* timerid);
        """
        if timerid:
            self._emulator.memory.write_u32(timerid, 1)
        return 0

    def timer_delete(self, timerid: int) -> int:
        """
        Delete a timer.
        
        int timer_delete(timer_t timerid);
        """
        return 0

    def timer_settime(self, timerid: int, flags: int, new_value: int, old_value: int) -> int:
        """
        Set timer.
        
        int timer_settime(timer_t timerid, int flags,
                          const struct itimerspec* new_value, struct itimerspec* old_value);
        """
        return 0

    def timer_gettime(self, timerid: int, curr_value: int) -> int:
        """
        Get timer.
        
        int timer_gettime(timer_t timerid, struct itimerspec* curr_value);
        """
        if curr_value:
            # Zero out the itimerspec struct
            for i in range(32):
                self._emulator.memory.write_u8(curr_value + i, 0)
        return 0

    def timer_getoverrun(self, timerid: int) -> int:
        """
        Get timer overrun count.
        
        int timer_getoverrun(timer_t timerid);
        """
        return 0

    def setitimer(self, which: int, new_value: int, old_value: int) -> int:
        """
        Set interval timer.
        
        int setitimer(int which, const struct itimerval* new_value, struct itimerval* old_value);
        """
        return 0

    def getitimer(self, which: int, curr_value: int) -> int:
        """
        Get interval timer.
        
        int getitimer(int which, struct itimerval* curr_value);
        """
        if curr_value:
            for i in range(16):
                self._emulator.memory.write_u8(curr_value + i, 0)
        return 0

    def alarm(self, seconds: int) -> int:
        """
        Set alarm.
        
        unsigned int alarm(unsigned int seconds);
        """
        return 0

    def ualarm(self, usecs: int, interval: int) -> int:
        """
        Set alarm in microseconds.
        
        useconds_t ualarm(useconds_t usecs, useconds_t interval);
        """
        return 0

    def tzset(self) -> None:
        """
        Set timezone.
        
        void tzset(void);
        """
        pass

    # ==================== ASCII Time ====================

    def asctime(self, tm: int) -> int:
        """
        Convert tm to ASCII string.
        
        char* asctime(const struct tm* tm);
        """
        if not tm:
            return 0

        tm_data = self._read_tm(tm)
        try:
            st = time.struct_time((
                tm_data['tm_year'], tm_data['tm_mon'], tm_data['tm_mday'],
                tm_data['tm_hour'], tm_data['tm_min'], tm_data['tm_sec'],
                tm_data['tm_wday'], tm_data['tm_yday'], tm_data['tm_isdst']
            ))
            result = time.asctime(st)

            ptr = self._handler.memory.malloc(len(result) + 1)
            if ptr:
                self._emulator.memory.write(ptr, result.encode() + b'\x00')
            return ptr
        except (ValueError, OverflowError):
            return 0

    def asctime_r(self, tm: int, buf: int) -> int:
        """
        Convert tm to ASCII string (reentrant).
        
        char* asctime_r(const struct tm* tm, char* buf);
        """
        if not tm or not buf:
            return 0

        tm_data = self._read_tm(tm)
        try:
            st = time.struct_time((
                tm_data['tm_year'], tm_data['tm_mon'], tm_data['tm_mday'],
                tm_data['tm_hour'], tm_data['tm_min'], tm_data['tm_sec'],
                tm_data['tm_wday'], tm_data['tm_yday'], tm_data['tm_isdst']
            ))
            result = time.asctime(st)
            self._emulator.memory.write(buf, result.encode() + b'\x00')
            return buf
        except (ValueError, OverflowError):
            return 0

    def ctime(self, timer: int) -> int:
        """
        Convert time to ASCII string.
        
        char* ctime(const time_t* timer);
        """
        if not timer:
            return 0

        t = self._emulator.memory.read_u32(timer)
        result = time.ctime(t)

        ptr = self._handler.memory.malloc(len(result) + 1)
        if ptr:
            self._emulator.memory.write(ptr, result.encode() + b'\x00')
        return ptr

    def ctime_r(self, timer: int, buf: int) -> int:
        """
        Convert time to ASCII string (reentrant).
        
        char* ctime_r(const time_t* timer, char* buf);
        """
        if not timer or not buf:
            return 0

        t = self._emulator.memory.read_u32(timer)
        result = time.ctime(t)
        self._emulator.memory.write(buf, result.encode() + b'\x00')
        return buf

    # ==================== Sleep ====================

    def nanosleep(self, req: int, rem: int) -> int:
        """
        High-resolution sleep.
        
        int nanosleep(const struct timespec* req, struct timespec* rem);
        """
        if req:
            sec, nsec = self._read_timespec(req)
            logger.debug(f"nanosleep: {sec}s {nsec}ns")
            # Don't actually sleep in emulation

        if rem:
            self._write_timespec(rem, 0, 0)

        return 0

    def usleep(self, usec: int) -> int:
        """
        Sleep in microseconds.
        
        int usleep(useconds_t usec);
        """
        logger.debug(f"usleep: {usec}us")
        return 0

    def sleep(self, seconds: int) -> int:
        """
        Sleep in seconds.
        
        unsigned int sleep(unsigned int seconds);
        """
        logger.debug(f"sleep: {seconds}s")
        return 0

    # ==================== Process IDs ====================

    def gettid(self) -> int:
        """
        Get thread ID.
        
        pid_t gettid(void);
        """
        return self._handler.pthread._current_thread_id

    def getpid(self) -> int:
        """
        Get process ID.
        
        pid_t getpid(void);
        """
        return 1000  # Simulated PID

    def getppid(self) -> int:
        """
        Get parent process ID.
        
        pid_t getppid(void);
        """
        return 1

    def getuid(self) -> int:
        """
        Get user ID.
        
        uid_t getuid(void);
        """
        return 10000  # Simulated UID (typical Android app)

    def geteuid(self) -> int:
        """
        Get effective user ID.
        
        uid_t geteuid(void);
        """
        return 10000

    def getgid(self) -> int:
        """
        Get group ID.
        
        gid_t getgid(void);
        """
        return 10000

    def getegid(self) -> int:
        """
        Get effective group ID.
        
        gid_t getegid(void);
        """
        return 10000
