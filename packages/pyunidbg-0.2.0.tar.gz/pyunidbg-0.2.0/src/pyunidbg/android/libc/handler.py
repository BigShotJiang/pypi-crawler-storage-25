"""
Main libc handler that integrates all libc function modules.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from .math_funcs import MathFunctions
from .mem import MemFunctions
from .memory import MemoryFunctions
from .pthread import PthreadFunctions
from .stdio import StdioFunctions
from .stdlib import StdlibFunctions
from .string import StringFunctions
from .time_funcs import TimeFunctions
from .wchar import WcharFunctions

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class LibcHandler:
    """
    Main libc handler that provides all standard C library functions.
    
    This class integrates:
    - Memory allocation (malloc, free, calloc, realloc, etc.)
    - String manipulation (strlen, strcpy, strcmp, etc.)
    - Memory operations (memcpy, memset, memmove, etc.)
    - Standard I/O (printf, sprintf, fopen, fread, etc.)
    - Standard library (atoi, getenv, qsort, etc.)
    - Math functions (sin, cos, sqrt, pow, etc.)
    - POSIX threads (pthread_create, pthread_mutex_*, etc.)
    - Time functions (time, gettimeofday, clock_gettime, etc.)
    - Wide character functions (wcslen, wcscpy, mbstowcs, etc.)
    
    Total: 350+ libc functions implemented.
    
    Usage:
        libc = LibcHandler(emulator)
        libc.register_hooks()
        
        # Access specific modules
        ptr = libc.memory.malloc(1024)
        libc.string.strcpy(dest, src)
    """

    def __init__(self, emulator):
        """
        Initialize libc handler.
        
        Args:
            emulator: The emulator instance (with memory access methods)
        """
        self._emulator = emulator

        # Initialize all function modules
        self.memory = MemoryFunctions(self)
        self.string = StringFunctions(self)
        self.mem = MemFunctions(self)
        self.stdio = StdioFunctions(self)
        self.stdlib = StdlibFunctions(self)
        self.math = MathFunctions(self)
        self.pthread = PthreadFunctions(self)
        self.time = TimeFunctions(self)
        self.wchar = WcharFunctions(self)

        # Function hooks registry
        self._hooks: dict[str, Callable] = {}

        # Build function table
        self._build_function_table()

        logger.debug("LibcHandler initialized")

    def _build_function_table(self) -> None:
        """Build the complete function table from all modules."""

        # Memory allocation functions
        self._hooks.update({
            "malloc": self.memory.malloc,
            "free": self.memory.free,
            "calloc": self.memory.calloc,
            "realloc": self.memory.realloc,
            "memalign": self.memory.memalign,
            "aligned_alloc": self.memory.aligned_alloc,
            "posix_memalign": self.memory.posix_memalign,
            "valloc": self.memory.valloc,
            "pvalloc": self.memory.pvalloc,
            "malloc_usable_size": self.memory.malloc_usable_size,
        })

        # String functions
        self._hooks.update({
            "strlen": self.string.strlen,
            "strnlen": self.string.strnlen,
            "strcpy": self.string.strcpy,
            "strncpy": self.string.strncpy,
            "stpcpy": self.string.stpcpy,
            "stpncpy": self.string.stpncpy,
            "strlcpy": self.string.strlcpy,
            "strcat": self.string.strcat,
            "strncat": self.string.strncat,
            "strlcat": self.string.strlcat,
            "strcmp": self.string.strcmp,
            "strncmp": self.string.strncmp,
            "strcasecmp": self.string.strcasecmp,
            "strncasecmp": self.string.strncasecmp,
            "strchr": self.string.strchr,
            "strrchr": self.string.strrchr,
            "strchrnul": self.string.strchrnul,
            "strstr": self.string.strstr,
            "strcasestr": self.string.strcasestr,
            "strnstr": self.string.strnstr,
            "strspn": self.string.strspn,
            "strcspn": self.string.strcspn,
            "strpbrk": self.string.strpbrk,
            "strtok": self.string.strtok,
            "strtok_r": self.string.strtok_r,
            "strsep": self.string.strsep,
            "strdup": self.string.strdup,
            "strndup": self.string.strndup,
            "strerror": self.string.strerror,
            "strerror_r": self.string.strerror_r,
            "strrev": self.string.strrev,
            "strupr": self.string.strupr,
            "strlwr": self.string.strlwr,
        })

        # Memory functions
        self._hooks.update({
            "memcpy": self.mem.memcpy,
            "mempcpy": self.mem.mempcpy,
            "memmove": self.mem.memmove,
            "memccpy": self.mem.memccpy,
            "memset": self.mem.memset,
            "memset_explicit": self.mem.memset_explicit,
            "memcmp": self.mem.memcmp,
            "memchr": self.mem.memchr,
            "memrchr": self.mem.memrchr,
            "memmem": self.mem.memmem,
            "rawmemchr": self.mem.rawmemchr,
            "bzero": self.mem.bzero,
            "explicit_bzero": self.mem.explicit_bzero,
            "bcopy": self.mem.bcopy,
            "bcmp": self.mem.bcmp,
            "memfrob": self.mem.memfrob,
            "swab": self.mem.swab,
        })

        # Stdio functions
        self._hooks.update({
            "printf": self.stdio.printf,
            "fprintf": self.stdio.fprintf,
            "sprintf": self.stdio.sprintf,
            "snprintf": self.stdio.snprintf,
            "vprintf": self.stdio.vprintf,
            "vfprintf": self.stdio.vfprintf,
            "vsprintf": self.stdio.vsprintf,
            "vsnprintf": self.stdio.vsnprintf,
            "dprintf": self.stdio.dprintf,
            "asprintf": self.stdio.asprintf,
            "fopen": self.stdio.fopen,
            "fclose": self.stdio.fclose,
            "freopen": self.stdio.freopen,
            "fdopen": self.stdio.fdopen,
            "fread": self.stdio.fread,
            "fwrite": self.stdio.fwrite,
            "fgetc": self.stdio.fgetc,
            "fputc": self.stdio.fputc,
            "getc": self.stdio.getc,
            "putc": self.stdio.putc,
            "getchar": self.stdio.getchar,
            "putchar": self.stdio.putchar,
            "ungetc": self.stdio.ungetc,
            "fgets": self.stdio.fgets,
            "fputs": self.stdio.fputs,
            "puts": self.stdio.puts,
            "gets": self.stdio.gets,
            "fseek": self.stdio.fseek,
            "ftell": self.stdio.ftell,
            "rewind": self.stdio.rewind,
            "fseeko": self.stdio.fseeko,
            "ftello": self.stdio.ftello,
            "fflush": self.stdio.fflush,
            "setbuf": self.stdio.setbuf,
            "setvbuf": self.stdio.setvbuf,
            "ferror": self.stdio.ferror,
            "feof": self.stdio.feof,
            "clearerr": self.stdio.clearerr,
            "fileno": self.stdio.fileno,
            "perror": self.stdio.perror,
            "remove": self.stdio.remove,
            "rename": self.stdio.rename,
            "tmpfile": self.stdio.tmpfile,
            "tmpnam": self.stdio.tmpnam,
        })

        # Stdlib functions
        self._hooks.update({
            "atoi": self.stdlib.atoi,
            "atol": self.stdlib.atol,
            "atoll": self.stdlib.atoll,
            "atof": self.stdlib.atof,
            "strtol": self.stdlib.strtol,
            "strtoul": self.stdlib.strtoul,
            "strtoll": self.stdlib.strtoll,
            "strtoull": self.stdlib.strtoull,
            "strtod": self.stdlib.strtod,
            "strtof": self.stdlib.strtof,
            "strtold": self.stdlib.strtold,
            "abs": self.stdlib.abs,
            "labs": self.stdlib.labs,
            "llabs": self.stdlib.llabs,
            "div": self.stdlib.div,
            "ldiv": self.stdlib.ldiv,
            "lldiv": self.stdlib.lldiv,
            "srand": self.stdlib.srand,
            "rand": self.stdlib.rand,
            "rand_r": self.stdlib.rand_r,
            "srandom": self.stdlib.srandom,
            "random": self.stdlib.random,
            "arc4random": self.stdlib.arc4random,
            "arc4random_uniform": self.stdlib.arc4random_uniform,
            "arc4random_buf": self.stdlib.arc4random_buf,
            "getenv": self.stdlib.getenv,
            "setenv": self.stdlib.setenv,
            "unsetenv": self.stdlib.unsetenv,
            "putenv": self.stdlib.putenv,
            "clearenv": self.stdlib.clearenv,
            "system": self.stdlib.system,
            "exit": self.stdlib.exit,
            "_exit": self.stdlib._exit,
            "abort": self.stdlib.abort,
            "atexit": self.stdlib.atexit,
            "quick_exit": self.stdlib.quick_exit,
            "at_quick_exit": self.stdlib.at_quick_exit,
            "qsort": self.stdlib.qsort,
            "bsearch": self.stdlib.bsearch,
            "mktemp": self.stdlib.mktemp,
            "mkstemp": self.stdlib.mkstemp,
            "mkdtemp": self.stdlib.mkdtemp,
            "realpath": self.stdlib.realpath,
            "basename": self.stdlib.basename,
            "dirname": self.stdlib.dirname,
        })

        # Math functions
        self._hooks.update({
            "sin": self.math.sin,
            "sinf": self.math.sinf,
            "cos": self.math.cos,
            "cosf": self.math.cosf,
            "tan": self.math.tan,
            "tanf": self.math.tanf,
            "asin": self.math.asin,
            "asinf": self.math.asinf,
            "acos": self.math.acos,
            "acosf": self.math.acosf,
            "atan": self.math.atan,
            "atanf": self.math.atanf,
            "atan2": self.math.atan2,
            "atan2f": self.math.atan2f,
            "sinh": self.math.sinh,
            "sinhf": self.math.sinhf,
            "cosh": self.math.cosh,
            "coshf": self.math.coshf,
            "tanh": self.math.tanh,
            "tanhf": self.math.tanhf,
            "asinh": self.math.asinh,
            "asinhf": self.math.asinhf,
            "acosh": self.math.acosh,
            "acoshf": self.math.acoshf,
            "atanh": self.math.atanh,
            "atanhf": self.math.atanhf,
            "exp": self.math.exp,
            "expf": self.math.expf,
            "exp2": self.math.exp2,
            "exp2f": self.math.exp2f,
            "expm1": self.math.expm1,
            "expm1f": self.math.expm1f,
            "log": self.math.log,
            "logf": self.math.logf,
            "log10": self.math.log10,
            "log10f": self.math.log10f,
            "log2": self.math.log2,
            "log2f": self.math.log2f,
            "log1p": self.math.log1p,
            "log1pf": self.math.log1pf,
            "logb": self.math.logb,
            "logbf": self.math.logbf,
            "ilogb": self.math.ilogb,
            "ilogbf": self.math.ilogbf,
            "pow": self.math.pow,
            "powf": self.math.powf,
            "sqrt": self.math.sqrt,
            "sqrtf": self.math.sqrtf,
            "cbrt": self.math.cbrt,
            "cbrtf": self.math.cbrtf,
            "hypot": self.math.hypot,
            "hypotf": self.math.hypotf,
            "ceil": self.math.ceil,
            "ceilf": self.math.ceilf,
            "floor": self.math.floor,
            "floorf": self.math.floorf,
            "trunc": self.math.trunc,
            "truncf": self.math.truncf,
            "round": self.math.round,
            "roundf": self.math.roundf,
            "lround": self.math.lround,
            "lroundf": self.math.lroundf,
            "llround": self.math.llround,
            "llroundf": self.math.llroundf,
            "nearbyint": self.math.nearbyint,
            "nearbyintf": self.math.nearbyintf,
            "rint": self.math.rint,
            "rintf": self.math.rintf,
            "lrint": self.math.lrint,
            "lrintf": self.math.lrintf,
            "llrint": self.math.llrint,
            "llrintf": self.math.llrintf,
            "fmod": self.math.fmod,
            "fmodf": self.math.fmodf,
            "remainder": self.math.remainder,
            "remainderf": self.math.remainderf,
            "copysign": self.math.copysign,
            "copysignf": self.math.copysignf,
            "nan": self.math.nan,
            "nanf": self.math.nanf,
            "nextafter": self.math.nextafter,
            "nextafterf": self.math.nextafterf,
            "fdim": self.math.fdim,
            "fdimf": self.math.fdimf,
            "fmax": self.math.fmax,
            "fmaxf": self.math.fmaxf,
            "fmin": self.math.fmin,
            "fminf": self.math.fminf,
            "fma": self.math.fma,
            "fmaf": self.math.fmaf,
            "fabs": self.math.fabs,
            "fabsf": self.math.fabsf,
            "erf": self.math.erf,
            "erff": self.math.erff,
            "erfc": self.math.erfc,
            "erfcf": self.math.erfcf,
            "lgamma": self.math.lgamma,
            "lgammaf": self.math.lgammaf,
            "tgamma": self.math.tgamma,
            "tgammaf": self.math.tgammaf,
            "isnan": self.math.isnan,
            "isinf": self.math.isinf,
            "isfinite": self.math.isfinite,
            "isnormal": self.math.isnormal,
            "signbit": self.math.signbit,
            "fpclassify": self.math.fpclassify,
        })

        # Pthread functions
        self._hooks.update({
            "pthread_create": self.pthread.pthread_create,
            "pthread_join": self.pthread.pthread_join,
            "pthread_detach": self.pthread.pthread_detach,
            "pthread_exit": self.pthread.pthread_exit,
            "pthread_self": self.pthread.pthread_self,
            "pthread_equal": self.pthread.pthread_equal,
            "pthread_cancel": self.pthread.pthread_cancel,
            "pthread_setname_np": self.pthread.pthread_setname_np,
            "pthread_getname_np": self.pthread.pthread_getname_np,
            "pthread_yield": self.pthread.pthread_yield,
            "sched_yield": self.pthread.sched_yield,
            "pthread_attr_init": self.pthread.pthread_attr_init,
            "pthread_attr_destroy": self.pthread.pthread_attr_destroy,
            "pthread_attr_setdetachstate": self.pthread.pthread_attr_setdetachstate,
            "pthread_attr_getdetachstate": self.pthread.pthread_attr_getdetachstate,
            "pthread_attr_setstacksize": self.pthread.pthread_attr_setstacksize,
            "pthread_attr_getstacksize": self.pthread.pthread_attr_getstacksize,
            "pthread_attr_setstack": self.pthread.pthread_attr_setstack,
            "pthread_attr_getstack": self.pthread.pthread_attr_getstack,
            "pthread_mutex_init": self.pthread.pthread_mutex_init,
            "pthread_mutex_destroy": self.pthread.pthread_mutex_destroy,
            "pthread_mutex_lock": self.pthread.pthread_mutex_lock,
            "pthread_mutex_trylock": self.pthread.pthread_mutex_trylock,
            "pthread_mutex_unlock": self.pthread.pthread_mutex_unlock,
            "pthread_mutex_timedlock": self.pthread.pthread_mutex_timedlock,
            "pthread_mutexattr_init": self.pthread.pthread_mutexattr_init,
            "pthread_mutexattr_destroy": self.pthread.pthread_mutexattr_destroy,
            "pthread_mutexattr_gettype": self.pthread.pthread_mutexattr_gettype,
            "pthread_mutexattr_settype": self.pthread.pthread_mutexattr_settype,
            "pthread_cond_init": self.pthread.pthread_cond_init,
            "pthread_cond_destroy": self.pthread.pthread_cond_destroy,
            "pthread_cond_signal": self.pthread.pthread_cond_signal,
            "pthread_cond_broadcast": self.pthread.pthread_cond_broadcast,
            "pthread_cond_wait": self.pthread.pthread_cond_wait,
            "pthread_cond_timedwait": self.pthread.pthread_cond_timedwait,
            "pthread_condattr_init": self.pthread.pthread_condattr_init,
            "pthread_condattr_destroy": self.pthread.pthread_condattr_destroy,
            "pthread_condattr_getclock": self.pthread.pthread_condattr_getclock,
            "pthread_condattr_setclock": self.pthread.pthread_condattr_setclock,
            "pthread_rwlock_init": self.pthread.pthread_rwlock_init,
            "pthread_rwlock_destroy": self.pthread.pthread_rwlock_destroy,
            "pthread_rwlock_rdlock": self.pthread.pthread_rwlock_rdlock,
            "pthread_rwlock_tryrdlock": self.pthread.pthread_rwlock_tryrdlock,
            "pthread_rwlock_wrlock": self.pthread.pthread_rwlock_wrlock,
            "pthread_rwlock_trywrlock": self.pthread.pthread_rwlock_trywrlock,
            "pthread_rwlock_unlock": self.pthread.pthread_rwlock_unlock,
            "pthread_barrier_init": self.pthread.pthread_barrier_init,
            "pthread_barrier_destroy": self.pthread.pthread_barrier_destroy,
            "pthread_barrier_wait": self.pthread.pthread_barrier_wait,
            "pthread_key_create": self.pthread.pthread_key_create,
            "pthread_key_delete": self.pthread.pthread_key_delete,
            "pthread_getspecific": self.pthread.pthread_getspecific,
            "pthread_setspecific": self.pthread.pthread_setspecific,
            "pthread_once": self.pthread.pthread_once,
            "pthread_spin_init": self.pthread.pthread_spin_init,
            "pthread_spin_destroy": self.pthread.pthread_spin_destroy,
            "pthread_spin_lock": self.pthread.pthread_spin_lock,
            "pthread_spin_trylock": self.pthread.pthread_spin_trylock,
            "pthread_spin_unlock": self.pthread.pthread_spin_unlock,
            "sem_init": self.pthread.sem_init,
            "sem_destroy": self.pthread.sem_destroy,
            "sem_wait": self.pthread.sem_wait,
            "sem_trywait": self.pthread.sem_trywait,
            "sem_post": self.pthread.sem_post,
            "sem_getvalue": self.pthread.sem_getvalue,
        })

        # Time functions
        self._hooks.update({
            "time": self.time.time,
            "difftime": self.time.difftime,
            "mktime": self.time.mktime,
            "localtime": self.time.localtime,
            "localtime_r": self.time.localtime_r,
            "gmtime": self.time.gmtime,
            "gmtime_r": self.time.gmtime_r,
            "asctime": self.time.asctime,
            "asctime_r": self.time.asctime_r,
            "ctime": self.time.ctime,
            "ctime_r": self.time.ctime_r,
            "strftime": self.time.strftime,
            "strptime": self.time.strptime,
            "clock": self.time.clock,
            "clock_gettime": self.time.clock_gettime,
            "clock_settime": self.time.clock_settime,
            "clock_getres": self.time.clock_getres,
            "gettimeofday": self.time.gettimeofday,
            "settimeofday": self.time.settimeofday,
            "nanosleep": self.time.nanosleep,
            "usleep": self.time.usleep,
            "sleep": self.time.sleep,
            "timer_create": self.time.timer_create,
            "timer_delete": self.time.timer_delete,
            "timer_settime": self.time.timer_settime,
            "timer_gettime": self.time.timer_gettime,
            "timer_getoverrun": self.time.timer_getoverrun,
            "setitimer": self.time.setitimer,
            "getitimer": self.time.getitimer,
            "alarm": self.time.alarm,
            "ualarm": self.time.ualarm,
            "tzset": self.time.tzset,
        })

        # Wide character functions
        self._hooks.update({
            "wcslen": self.wchar.wcslen,
            "wcsnlen": self.wchar.wcsnlen,
            "wcscpy": self.wchar.wcscpy,
            "wcsncpy": self.wchar.wcsncpy,
            "wcscat": self.wchar.wcscat,
            "wcsncat": self.wchar.wcsncat,
            "wcscmp": self.wchar.wcscmp,
            "wcsncmp": self.wchar.wcsncmp,
            "wcscasecmp": self.wchar.wcscasecmp,
            "wcsncasecmp": self.wchar.wcsncasecmp,
            "wcschr": self.wchar.wcschr,
            "wcsrchr": self.wchar.wcsrchr,
            "wcsstr": self.wchar.wcsstr,
            "wcspbrk": self.wchar.wcspbrk,
            "wcsspn": self.wchar.wcsspn,
            "wcscspn": self.wchar.wcscspn,
            "wcstok": self.wchar.wcstok,
            "wcsdup": self.wchar.wcsdup,
            "wmemcpy": self.wchar.wmemcpy,
            "wmemmove": self.wchar.wmemmove,
            "wmemset": self.wchar.wmemset,
            "wmemcmp": self.wchar.wmemcmp,
            "wmemchr": self.wchar.wmemchr,
            "mblen": self.wchar.mblen,
            "mbtowc": self.wchar.mbtowc,
            "wctomb": self.wchar.wctomb,
            "mbstowcs": self.wchar.mbstowcs,
            "wcstombs": self.wchar.wcstombs,
            "mbrlen": self.wchar.mbrlen,
            "mbrtowc": self.wchar.mbrtowc,
            "wcrtomb": self.wchar.wcrtomb,
            "mbsrtowcs": self.wchar.mbsrtowcs,
            "wcsrtombs": self.wchar.wcsrtombs,
            "btowc": self.wchar.btowc,
            "wctob": self.wchar.wctob,
            "mbsinit": self.wchar.mbsinit,
            "wcwidth": self.wchar.wcwidth,
            "wcswidth": self.wchar.wcswidth,
            "wcstol": self.wchar.wcstol,
            "wcstoul": self.wchar.wcstoul,
            "wcstoll": self.wchar.wcstoll,
            "wcstoull": self.wchar.wcstoull,
            "wcstod": self.wchar.wcstod,
            "wcstof": self.wchar.wcstof,
            "wcstold": self.wchar.wcstold,
            "swprintf": self.wchar.swprintf,
            "vswprintf": self.wchar.vswprintf,
            "swscanf": self.wchar.swscanf,
            "fwprintf": self.wchar.fwprintf,
            "fwscanf": self.wchar.fwscanf,
            "wprintf": self.wchar.wprintf,
            "wscanf": self.wchar.wscanf,
            "fgetwc": self.wchar.fgetwc,
            "fputwc": self.wchar.fputwc,
            "fgetws": self.wchar.fgetws,
            "fputws": self.wchar.fputws,
            "getwc": self.wchar.getwc,
            "putwc": self.wchar.putwc,
            "getwchar": self.wchar.getwchar,
            "putwchar": self.wchar.putwchar,
            "ungetwc": self.wchar.ungetwc,
        })

    def get_function(self, name: str) -> Callable | None:
        """
        Get a libc function by name.
        
        Args:
            name: Function name (e.g., "malloc", "strlen")
            
        Returns:
            The function if found, None otherwise
        """
        return self._hooks.get(name)

    def call_function(self, name: str, *args) -> Any:
        """
        Call a libc function by name.
        
        Args:
            name: Function name
            *args: Function arguments
            
        Returns:
            Function result
            
        Raises:
            KeyError: If function not found
        """
        func = self._hooks.get(name)
        if func is None:
            raise KeyError(f"Unknown libc function: {name}")
        return func(*args)

    def has_function(self, name: str) -> bool:
        """Check if a function is implemented."""
        return name in self._hooks

    def list_functions(self) -> list[str]:
        """List all implemented function names."""
        return sorted(self._hooks.keys())

    def get_function_count(self) -> int:
        """Get the number of implemented functions."""
        return len(self._hooks)

    def register_custom_function(self, name: str, func: Callable) -> None:
        """
        Register a custom function.
        
        Args:
            name: Function name
            func: Function implementation
        """
        self._hooks[name] = func

    # ==================== Convenience Methods ====================

    def get_stdout(self) -> bytes:
        """Get captured stdout output."""
        return self.stdio.get_stdout()

    def get_stderr(self) -> bytes:
        """Get captured stderr output."""
        return self.stdio.get_stderr()

    def clear_output(self) -> None:
        """Clear captured stdout/stderr."""
        self.stdio.clear_output()

    def set_environment(self, name: str, value: str) -> None:
        """Set an environment variable."""
        self.stdlib._environ[name] = value

    def get_environment(self, name: str) -> str | None:
        """Get an environment variable."""
        return self.stdlib._environ.get(name)

    def get_memory_stats(self) -> dict:
        """Get memory allocation statistics."""
        return self.memory.get_stats()

    def dump_allocations(self) -> list:
        """Dump current memory allocations."""
        return self.memory.dump_allocations()
