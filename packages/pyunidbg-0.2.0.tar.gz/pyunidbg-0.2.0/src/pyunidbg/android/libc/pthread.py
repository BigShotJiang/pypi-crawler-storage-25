"""
POSIX thread (pthread) functions.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class PthreadError(IntEnum):
    """Pthread error codes."""
    SUCCESS = 0
    EINVAL = 22
    EBUSY = 16
    EDEADLK = 35
    EPERM = 1
    ENOMEM = 12
    EAGAIN = 11
    ESRCH = 3
    ETIMEDOUT = 110


class MutexType(IntEnum):
    """Mutex types."""
    PTHREAD_MUTEX_NORMAL = 0
    PTHREAD_MUTEX_RECURSIVE = 1
    PTHREAD_MUTEX_ERRORCHECK = 2
    PTHREAD_MUTEX_DEFAULT = 0


@dataclass
class Thread:
    """Represents a pthread."""
    id: int
    name: str = ""
    stack_addr: int = 0
    stack_size: int = 0x100000
    detached: bool = False
    exit_value: int = 0
    started: bool = False
    finished: bool = False
    start_routine: int = 0
    arg: int = 0


@dataclass
class Mutex:
    """Represents a pthread mutex."""
    id: int
    type: MutexType = MutexType.PTHREAD_MUTEX_DEFAULT
    owner: int = 0  # Thread ID of owner
    lock_count: int = 0
    robust: bool = False


@dataclass
class Condition:
    """Represents a pthread condition variable."""
    id: int
    clock: int = 0  # CLOCK_REALTIME or CLOCK_MONOTONIC
    waiters: list = field(default_factory=list)


@dataclass
class RWLock:
    """Represents a pthread read-write lock."""
    id: int
    readers: int = 0
    writer: int = 0  # Thread ID of writer, 0 if none


@dataclass
class Barrier:
    """Represents a pthread barrier."""
    id: int
    count: int = 0
    waiting: int = 0


@dataclass
class ThreadKey:
    """Represents a thread-specific data key."""
    key: int
    destructor: int = 0
    values: dict = field(default_factory=dict)  # thread_id -> value


@dataclass
class Once:
    """Represents a pthread_once control."""
    done: bool = False


class PthreadFunctions:
    """
    POSIX thread function implementations.
    
    Implements:
    - Thread: pthread_create, pthread_join, pthread_detach, pthread_exit, pthread_self,
              pthread_equal, pthread_cancel, pthread_setname_np, pthread_getname_np
    - Mutex: pthread_mutex_init/destroy/lock/trylock/unlock/timedlock
    - Mutex Attr: pthread_mutexattr_init/destroy/gettype/settype
    - Condition: pthread_cond_init/destroy/signal/broadcast/wait/timedwait
    - Cond Attr: pthread_condattr_init/destroy/getclock/setclock
    - RWLock: pthread_rwlock_init/destroy/rdlock/wrlock/tryrdlock/trywrlock/unlock
    - Barrier: pthread_barrier_init/destroy/wait
    - Thread Key: pthread_key_create/delete, pthread_getspecific/setspecific
    - Once: pthread_once
    - Spin Lock: pthread_spin_init/destroy/lock/trylock/unlock
    - Thread Attr: pthread_attr_init/destroy/setdetachstate/getdetachstate/setstacksize/getstacksize
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Thread management
        self._threads: dict[int, Thread] = {}
        self._next_thread_id = 1
        self._current_thread_id = 1

        # Create main thread
        main_thread = Thread(id=1, name="main")
        main_thread.started = True
        self._threads[1] = main_thread

        # Mutex management
        self._mutexes: dict[int, Mutex] = {}
        self._next_mutex_id = 1

        # Condition variable management
        self._conditions: dict[int, Condition] = {}
        self._next_cond_id = 1

        # Read-write lock management
        self._rwlocks: dict[int, RWLock] = {}
        self._next_rwlock_id = 1

        # Barrier management
        self._barriers: dict[int, Barrier] = {}
        self._next_barrier_id = 1

        # Thread-specific data
        self._keys: dict[int, ThreadKey] = {}
        self._next_key = 1

        # Once controls
        self._once_controls: dict[int, Once] = {}

        # Spin locks (simplified as mutexes)
        self._spinlocks: dict[int, int] = {}  # spinlock_ptr -> lock state

    # ==================== Thread Functions ====================

    def pthread_create(self, thread: int, attr: int, start_routine: int, arg: int) -> int:
        """
        Create a new thread.
        
        int pthread_create(pthread_t* thread, const pthread_attr_t* attr,
                          void* (*start_routine)(void*), void* arg);
        """
        thread_id = self._next_thread_id
        self._next_thread_id += 1

        new_thread = Thread(
            id=thread_id,
            start_routine=start_routine,
            arg=arg,
            started=True
        )

        # Parse attributes if provided
        if attr:
            # Would parse attr structure
            pass

        self._threads[thread_id] = new_thread

        # Write thread ID
        self._emulator.memory.write_u32(thread, thread_id)

        logger.debug(f"pthread_create: thread={thread_id}, routine=0x{start_routine:x}")
        return PthreadError.SUCCESS

    def pthread_join(self, thread: int, retval: int) -> int:
        """
        Wait for thread termination.
        
        int pthread_join(pthread_t thread, void** retval);
        """
        if thread not in self._threads:
            return PthreadError.ESRCH

        t = self._threads[thread]
        if t.detached:
            return PthreadError.EINVAL

        # In emulation, threads run synchronously
        t.finished = True

        if retval:
            self._emulator.memory.write_ptr(retval, t.exit_value)

        logger.debug(f"pthread_join: thread={thread}")
        return PthreadError.SUCCESS

    def pthread_detach(self, thread: int) -> int:
        """
        Detach a thread.
        
        int pthread_detach(pthread_t thread);
        """
        if thread not in self._threads:
            return PthreadError.ESRCH

        self._threads[thread].detached = True
        return PthreadError.SUCCESS

    def pthread_exit(self, retval: int) -> None:
        """
        Terminate calling thread.
        
        void pthread_exit(void* retval);
        """
        if self._current_thread_id in self._threads:
            self._threads[self._current_thread_id].finished = True
            self._threads[self._current_thread_id].exit_value = retval
        logger.debug(f"pthread_exit: retval=0x{retval:x}")

    def pthread_self(self) -> int:
        """
        Get calling thread's ID.
        
        pthread_t pthread_self(void);
        """
        return self._current_thread_id

    def pthread_equal(self, t1: int, t2: int) -> int:
        """
        Compare thread IDs.
        
        int pthread_equal(pthread_t t1, pthread_t t2);
        """
        return 1 if t1 == t2 else 0

    def pthread_cancel(self, thread: int) -> int:
        """
        Send cancellation request.
        
        int pthread_cancel(pthread_t thread);
        """
        if thread not in self._threads:
            return PthreadError.ESRCH

        self._threads[thread].finished = True
        return PthreadError.SUCCESS

    def pthread_setname_np(self, thread: int, name: int) -> int:
        """
        Set thread name.
        
        int pthread_setname_np(pthread_t thread, const char* name);
        """
        if thread not in self._threads:
            return PthreadError.ESRCH

        self._threads[thread].name = self._emulator.memory.read_string(name, 16)
        return PthreadError.SUCCESS

    def pthread_getname_np(self, thread: int, name: int, len_: int) -> int:
        """
        Get thread name.
        
        int pthread_getname_np(pthread_t thread, char* name, size_t len);
        """
        if thread not in self._threads:
            return PthreadError.ESRCH

        thread_name = self._threads[thread].name or f"Thread-{thread}"
        self._emulator.memory.write(name, thread_name[:len_-1].encode() + b'\x00')
        return PthreadError.SUCCESS

    def pthread_yield(self) -> int:
        """
        Yield execution.
        
        int pthread_yield(void);
        """
        return PthreadError.SUCCESS

    def sched_yield(self) -> int:
        """
        Yield execution.
        
        int sched_yield(void);
        """
        return PthreadError.SUCCESS

    # ==================== Thread Attributes ====================

    def pthread_attr_init(self, attr: int) -> int:
        """
        Initialize thread attributes.
        
        int pthread_attr_init(pthread_attr_t* attr);
        """
        # Initialize to defaults
        self._emulator.memory.write(attr, bytes(36))  # sizeof(pthread_attr_t)
        return PthreadError.SUCCESS

    def pthread_attr_destroy(self, attr: int) -> int:
        """
        Destroy thread attributes.
        
        int pthread_attr_destroy(pthread_attr_t* attr);
        """
        return PthreadError.SUCCESS

    def pthread_attr_setdetachstate(self, attr: int, detachstate: int) -> int:
        """
        Set detach state attribute.
        
        int pthread_attr_setdetachstate(pthread_attr_t* attr, int detachstate);
        """
        self._emulator.memory.write_u32(attr, detachstate)
        return PthreadError.SUCCESS

    def pthread_attr_getdetachstate(self, attr: int, detachstate: int) -> int:
        """
        Get detach state attribute.
        
        int pthread_attr_getdetachstate(const pthread_attr_t* attr, int* detachstate);
        """
        state = self._emulator.memory.read_u32(attr)
        self._emulator.memory.write_u32(detachstate, state)
        return PthreadError.SUCCESS

    def pthread_attr_setstacksize(self, attr: int, stacksize: int) -> int:
        """
        Set stack size attribute.
        
        int pthread_attr_setstacksize(pthread_attr_t* attr, size_t stacksize);
        """
        self._emulator.memory.write_u32(attr + 4, stacksize)
        return PthreadError.SUCCESS

    def pthread_attr_getstacksize(self, attr: int, stacksize: int) -> int:
        """
        Get stack size attribute.
        
        int pthread_attr_getstacksize(const pthread_attr_t* attr, size_t* stacksize);
        """
        size = self._emulator.memory.read_u32(attr + 4)
        self._emulator.memory.write_u32(stacksize, size or 0x100000)
        return PthreadError.SUCCESS

    def pthread_attr_setstack(self, attr: int, stackaddr: int, stacksize: int) -> int:
        """
        Set stack address and size.
        
        int pthread_attr_setstack(pthread_attr_t* attr, void* stackaddr, size_t stacksize);
        """
        return PthreadError.SUCCESS

    def pthread_attr_getstack(self, attr: int, stackaddr: int, stacksize: int) -> int:
        """
        Get stack address and size.
        
        int pthread_attr_getstack(const pthread_attr_t* attr, void** stackaddr, size_t* stacksize);
        """
        self._emulator.memory.write_ptr(stackaddr, 0)
        self._emulator.memory.write_u32(stacksize, 0x100000)
        return PthreadError.SUCCESS

    # ==================== Mutex Functions ====================

    def pthread_mutex_init(self, mutex: int, attr: int) -> int:
        """
        Initialize mutex.
        
        int pthread_mutex_init(pthread_mutex_t* mutex, const pthread_mutexattr_t* attr);
        """
        mutex_id = self._next_mutex_id
        self._next_mutex_id += 1

        mutex_type = MutexType.PTHREAD_MUTEX_DEFAULT
        if attr:
            mutex_type = MutexType(self._emulator.memory.read_u32(attr))

        self._mutexes[mutex] = Mutex(id=mutex_id, type=mutex_type)
        self._emulator.memory.write_u32(mutex, mutex_id)

        return PthreadError.SUCCESS

    def pthread_mutex_destroy(self, mutex: int) -> int:
        """
        Destroy mutex.
        
        int pthread_mutex_destroy(pthread_mutex_t* mutex);
        """
        if mutex in self._mutexes:
            if self._mutexes[mutex].lock_count > 0:
                return PthreadError.EBUSY
            del self._mutexes[mutex]
        return PthreadError.SUCCESS

    def pthread_mutex_lock(self, mutex: int) -> int:
        """
        Lock mutex.
        
        int pthread_mutex_lock(pthread_mutex_t* mutex);
        """
        if mutex not in self._mutexes:
            # Auto-initialize
            self._mutexes[mutex] = Mutex(id=self._next_mutex_id)
            self._next_mutex_id += 1

        m = self._mutexes[mutex]

        if m.owner == self._current_thread_id:
            if m.type == MutexType.PTHREAD_MUTEX_RECURSIVE:
                m.lock_count += 1
                return PthreadError.SUCCESS
            elif m.type == MutexType.PTHREAD_MUTEX_ERRORCHECK:
                return PthreadError.EDEADLK

        m.owner = self._current_thread_id
        m.lock_count = 1
        return PthreadError.SUCCESS

    def pthread_mutex_trylock(self, mutex: int) -> int:
        """
        Try to lock mutex.
        
        int pthread_mutex_trylock(pthread_mutex_t* mutex);
        """
        if mutex not in self._mutexes:
            self._mutexes[mutex] = Mutex(id=self._next_mutex_id)
            self._next_mutex_id += 1

        m = self._mutexes[mutex]

        if m.lock_count > 0 and m.owner != self._current_thread_id:
            return PthreadError.EBUSY

        return self.pthread_mutex_lock(mutex)

    def pthread_mutex_unlock(self, mutex: int) -> int:
        """
        Unlock mutex.
        
        int pthread_mutex_unlock(pthread_mutex_t* mutex);
        """
        if mutex not in self._mutexes:
            return PthreadError.EINVAL

        m = self._mutexes[mutex]

        if m.type == MutexType.PTHREAD_MUTEX_ERRORCHECK:
            if m.owner != self._current_thread_id:
                return PthreadError.EPERM

        m.lock_count -= 1
        if m.lock_count == 0:
            m.owner = 0

        return PthreadError.SUCCESS

    def pthread_mutex_timedlock(self, mutex: int, abstime: int) -> int:
        """
        Lock mutex with timeout.
        
        int pthread_mutex_timedlock(pthread_mutex_t* mutex, const struct timespec* abstime);
        """
        # In emulation, just try to lock
        return self.pthread_mutex_lock(mutex)

    # ==================== Mutex Attributes ====================

    def pthread_mutexattr_init(self, attr: int) -> int:
        """
        Initialize mutex attributes.
        
        int pthread_mutexattr_init(pthread_mutexattr_t* attr);
        """
        self._emulator.memory.write_u32(attr, MutexType.PTHREAD_MUTEX_DEFAULT)
        return PthreadError.SUCCESS

    def pthread_mutexattr_destroy(self, attr: int) -> int:
        """
        Destroy mutex attributes.
        
        int pthread_mutexattr_destroy(pthread_mutexattr_t* attr);
        """
        return PthreadError.SUCCESS

    def pthread_mutexattr_gettype(self, attr: int, type_: int) -> int:
        """
        Get mutex type.
        
        int pthread_mutexattr_gettype(const pthread_mutexattr_t* attr, int* type);
        """
        t = self._emulator.memory.read_u32(attr)
        self._emulator.memory.write_u32(type_, t)
        return PthreadError.SUCCESS

    def pthread_mutexattr_settype(self, attr: int, type_: int) -> int:
        """
        Set mutex type.
        
        int pthread_mutexattr_settype(pthread_mutexattr_t* attr, int type);
        """
        self._emulator.memory.write_u32(attr, type_)
        return PthreadError.SUCCESS

    # ==================== Condition Variable Functions ====================

    def pthread_cond_init(self, cond: int, attr: int) -> int:
        """
        Initialize condition variable.
        
        int pthread_cond_init(pthread_cond_t* cond, const pthread_condattr_t* attr);
        """
        cond_id = self._next_cond_id
        self._next_cond_id += 1

        self._conditions[cond] = Condition(id=cond_id)
        self._emulator.memory.write_u32(cond, cond_id)

        return PthreadError.SUCCESS

    def pthread_cond_destroy(self, cond: int) -> int:
        """
        Destroy condition variable.
        
        int pthread_cond_destroy(pthread_cond_t* cond);
        """
        if cond in self._conditions:
            del self._conditions[cond]
        return PthreadError.SUCCESS

    def pthread_cond_signal(self, cond: int) -> int:
        """
        Signal condition variable.
        
        int pthread_cond_signal(pthread_cond_t* cond);
        """
        if cond in self._conditions:
            c = self._conditions[cond]
            if c.waiters:
                c.waiters.pop(0)
        return PthreadError.SUCCESS

    def pthread_cond_broadcast(self, cond: int) -> int:
        """
        Broadcast to all waiters.
        
        int pthread_cond_broadcast(pthread_cond_t* cond);
        """
        if cond in self._conditions:
            self._conditions[cond].waiters.clear()
        return PthreadError.SUCCESS

    def pthread_cond_wait(self, cond: int, mutex: int) -> int:
        """
        Wait on condition variable.
        
        int pthread_cond_wait(pthread_cond_t* cond, pthread_mutex_t* mutex);
        """
        if cond not in self._conditions:
            self._conditions[cond] = Condition(id=self._next_cond_id)
            self._next_cond_id += 1

        # Unlock mutex, wait, relock
        self.pthread_mutex_unlock(mutex)
        # In real implementation, would block here
        self.pthread_mutex_lock(mutex)

        return PthreadError.SUCCESS

    def pthread_cond_timedwait(self, cond: int, mutex: int, abstime: int) -> int:
        """
        Wait on condition variable with timeout.
        
        int pthread_cond_timedwait(pthread_cond_t* cond, pthread_mutex_t* mutex,
                                   const struct timespec* abstime);
        """
        return self.pthread_cond_wait(cond, mutex)

    # ==================== Condition Attributes ====================

    def pthread_condattr_init(self, attr: int) -> int:
        """
        Initialize condition attributes.
        
        int pthread_condattr_init(pthread_condattr_t* attr);
        """
        self._emulator.memory.write_u32(attr, 0)
        return PthreadError.SUCCESS

    def pthread_condattr_destroy(self, attr: int) -> int:
        """
        Destroy condition attributes.
        
        int pthread_condattr_destroy(pthread_condattr_t* attr);
        """
        return PthreadError.SUCCESS

    def pthread_condattr_getclock(self, attr: int, clock_id: int) -> int:
        """
        Get clock attribute.
        
        int pthread_condattr_getclock(const pthread_condattr_t* attr, clockid_t* clock_id);
        """
        clock = self._emulator.memory.read_u32(attr)
        self._emulator.memory.write_u32(clock_id, clock)
        return PthreadError.SUCCESS

    def pthread_condattr_setclock(self, attr: int, clock_id: int) -> int:
        """
        Set clock attribute.
        
        int pthread_condattr_setclock(pthread_condattr_t* attr, clockid_t clock_id);
        """
        self._emulator.memory.write_u32(attr, clock_id)
        return PthreadError.SUCCESS

    # ==================== Read-Write Lock Functions ====================

    def pthread_rwlock_init(self, rwlock: int, attr: int) -> int:
        """
        Initialize read-write lock.
        
        int pthread_rwlock_init(pthread_rwlock_t* rwlock, const pthread_rwlockattr_t* attr);
        """
        rwlock_id = self._next_rwlock_id
        self._next_rwlock_id += 1

        self._rwlocks[rwlock] = RWLock(id=rwlock_id)
        self._emulator.memory.write_u32(rwlock, rwlock_id)

        return PthreadError.SUCCESS

    def pthread_rwlock_destroy(self, rwlock: int) -> int:
        """
        Destroy read-write lock.
        
        int pthread_rwlock_destroy(pthread_rwlock_t* rwlock);
        """
        if rwlock in self._rwlocks:
            del self._rwlocks[rwlock]
        return PthreadError.SUCCESS

    def pthread_rwlock_rdlock(self, rwlock: int) -> int:
        """
        Acquire read lock.
        
        int pthread_rwlock_rdlock(pthread_rwlock_t* rwlock);
        """
        if rwlock not in self._rwlocks:
            self._rwlocks[rwlock] = RWLock(id=self._next_rwlock_id)
            self._next_rwlock_id += 1

        rw = self._rwlocks[rwlock]
        if rw.writer:
            return PthreadError.EBUSY
        rw.readers += 1
        return PthreadError.SUCCESS

    def pthread_rwlock_tryrdlock(self, rwlock: int) -> int:
        """
        Try to acquire read lock.
        
        int pthread_rwlock_tryrdlock(pthread_rwlock_t* rwlock);
        """
        return self.pthread_rwlock_rdlock(rwlock)

    def pthread_rwlock_wrlock(self, rwlock: int) -> int:
        """
        Acquire write lock.
        
        int pthread_rwlock_wrlock(pthread_rwlock_t* rwlock);
        """
        if rwlock not in self._rwlocks:
            self._rwlocks[rwlock] = RWLock(id=self._next_rwlock_id)
            self._next_rwlock_id += 1

        rw = self._rwlocks[rwlock]
        if rw.readers > 0 or rw.writer:
            return PthreadError.EBUSY
        rw.writer = self._current_thread_id
        return PthreadError.SUCCESS

    def pthread_rwlock_trywrlock(self, rwlock: int) -> int:
        """
        Try to acquire write lock.
        
        int pthread_rwlock_trywrlock(pthread_rwlock_t* rwlock);
        """
        return self.pthread_rwlock_wrlock(rwlock)

    def pthread_rwlock_unlock(self, rwlock: int) -> int:
        """
        Release read-write lock.
        
        int pthread_rwlock_unlock(pthread_rwlock_t* rwlock);
        """
        if rwlock not in self._rwlocks:
            return PthreadError.EINVAL

        rw = self._rwlocks[rwlock]
        if rw.writer == self._current_thread_id:
            rw.writer = 0
        elif rw.readers > 0:
            rw.readers -= 1

        return PthreadError.SUCCESS

    # ==================== Barrier Functions ====================

    def pthread_barrier_init(self, barrier: int, attr: int, count: int) -> int:
        """
        Initialize barrier.
        
        int pthread_barrier_init(pthread_barrier_t* barrier,
                                 const pthread_barrierattr_t* attr, unsigned count);
        """
        barrier_id = self._next_barrier_id
        self._next_barrier_id += 1

        self._barriers[barrier] = Barrier(id=barrier_id, count=count)
        self._emulator.memory.write_u32(barrier, barrier_id)

        return PthreadError.SUCCESS

    def pthread_barrier_destroy(self, barrier: int) -> int:
        """
        Destroy barrier.
        
        int pthread_barrier_destroy(pthread_barrier_t* barrier);
        """
        if barrier in self._barriers:
            del self._barriers[barrier]
        return PthreadError.SUCCESS

    def pthread_barrier_wait(self, barrier: int) -> int:
        """
        Wait at barrier.
        
        int pthread_barrier_wait(pthread_barrier_t* barrier);
        """
        if barrier not in self._barriers:
            return PthreadError.EINVAL

        b = self._barriers[barrier]
        b.waiting += 1

        if b.waiting >= b.count:
            b.waiting = 0
            return -1  # PTHREAD_BARRIER_SERIAL_THREAD

        return PthreadError.SUCCESS

    # ==================== Thread-Specific Data ====================

    def pthread_key_create(self, key: int, destructor: int) -> int:
        """
        Create thread-specific data key.
        
        int pthread_key_create(pthread_key_t* key, void (*destructor)(void*));
        """
        key_id = self._next_key
        self._next_key += 1

        self._keys[key_id] = ThreadKey(key=key_id, destructor=destructor)
        self._emulator.memory.write_u32(key, key_id)

        return PthreadError.SUCCESS

    def pthread_key_delete(self, key: int) -> int:
        """
        Delete thread-specific data key.
        
        int pthread_key_delete(pthread_key_t key);
        """
        if key in self._keys:
            del self._keys[key]
        return PthreadError.SUCCESS

    def pthread_getspecific(self, key: int) -> int:
        """
        Get thread-specific value.
        
        void* pthread_getspecific(pthread_key_t key);
        """
        if key not in self._keys:
            return 0
        return self._keys[key].values.get(self._current_thread_id, 0)

    def pthread_setspecific(self, key: int, value: int) -> int:
        """
        Set thread-specific value.
        
        int pthread_setspecific(pthread_key_t key, const void* value);
        """
        if key not in self._keys:
            return PthreadError.EINVAL
        self._keys[key].values[self._current_thread_id] = value
        return PthreadError.SUCCESS

    # ==================== Once Control ====================

    def pthread_once(self, once_control: int, init_routine: int) -> int:
        """
        Execute function once.
        
        int pthread_once(pthread_once_t* once_control, void (*init_routine)(void));
        """
        if once_control not in self._once_controls:
            self._once_controls[once_control] = Once()

        if not self._once_controls[once_control].done:
            # Would call init_routine here
            self._once_controls[once_control].done = True

        return PthreadError.SUCCESS

    # ==================== Spin Lock ====================

    def pthread_spin_init(self, lock: int, pshared: int) -> int:
        """
        Initialize spin lock.
        
        int pthread_spin_init(pthread_spinlock_t* lock, int pshared);
        """
        self._spinlocks[lock] = 0
        return PthreadError.SUCCESS

    def pthread_spin_destroy(self, lock: int) -> int:
        """
        Destroy spin lock.
        
        int pthread_spin_destroy(pthread_spinlock_t* lock);
        """
        if lock in self._spinlocks:
            del self._spinlocks[lock]
        return PthreadError.SUCCESS

    def pthread_spin_lock(self, lock: int) -> int:
        """
        Acquire spin lock.
        
        int pthread_spin_lock(pthread_spinlock_t* lock);
        """
        if lock not in self._spinlocks:
            self._spinlocks[lock] = 0
        self._spinlocks[lock] = 1
        return PthreadError.SUCCESS

    def pthread_spin_trylock(self, lock: int) -> int:
        """
        Try to acquire spin lock.
        
        int pthread_spin_trylock(pthread_spinlock_t* lock);
        """
        if lock not in self._spinlocks:
            self._spinlocks[lock] = 0
        if self._spinlocks[lock]:
            return PthreadError.EBUSY
        self._spinlocks[lock] = 1
        return PthreadError.SUCCESS

    def pthread_spin_unlock(self, lock: int) -> int:
        """
        Release spin lock.
        
        int pthread_spin_unlock(pthread_spinlock_t* lock);
        """
        if lock in self._spinlocks:
            self._spinlocks[lock] = 0
        return PthreadError.SUCCESS

    # ==================== Semaphore (sem_*) ====================

    def sem_init(self, sem: int, pshared: int, value: int) -> int:
        """
        Initialize semaphore.
        
        int sem_init(sem_t* sem, int pshared, unsigned int value);
        """
        self._emulator.memory.write_u32(sem, value)
        return 0

    def sem_destroy(self, sem: int) -> int:
        """
        Destroy semaphore.
        
        int sem_destroy(sem_t* sem);
        """
        return 0

    def sem_wait(self, sem: int) -> int:
        """
        Wait on semaphore.
        
        int sem_wait(sem_t* sem);
        """
        value = self._emulator.memory.read_u32(sem)
        if value > 0:
            self._emulator.memory.write_u32(sem, value - 1)
        return 0

    def sem_trywait(self, sem: int) -> int:
        """
        Try to wait on semaphore.
        
        int sem_trywait(sem_t* sem);
        """
        value = self._emulator.memory.read_u32(sem)
        if value > 0:
            self._emulator.memory.write_u32(sem, value - 1)
            return 0
        return -1

    def sem_post(self, sem: int) -> int:
        """
        Post to semaphore.
        
        int sem_post(sem_t* sem);
        """
        value = self._emulator.memory.read_u32(sem)
        self._emulator.memory.write_u32(sem, value + 1)
        return 0

    def sem_getvalue(self, sem: int, sval: int) -> int:
        """
        Get semaphore value.
        
        int sem_getvalue(sem_t* sem, int* sval);
        """
        value = self._emulator.memory.read_u32(sem)
        self._emulator.memory.write_u32(sval, value)
        return 0
