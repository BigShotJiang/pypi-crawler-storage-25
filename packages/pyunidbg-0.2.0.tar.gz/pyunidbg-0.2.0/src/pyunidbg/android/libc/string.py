"""
String manipulation functions (strlen, strcpy, strcmp, etc.)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .handler import LibcHandler

logger = logging.getLogger(__name__)


class StringFunctions:
    """
    String manipulation function implementations.
    
    Implements:
    - strlen, strnlen
    - strcpy, strncpy, stpcpy, stpncpy
    - strcat, strncat
    - strcmp, strncmp, strcasecmp, strncasecmp
    - strchr, strrchr, strchrnul
    - strstr, strcasestr, strnstr
    - strdup, strndup
    - strtok, strtok_r
    - strspn, strcspn, strpbrk
    - strerror, strerror_r
    - strlcpy, strlcat (BSD)
    """

    def __init__(self, handler: LibcHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # strtok state
        self._strtok_ptr = 0

        # Error messages
        self._errno_messages = {
            0: "Success",
            1: "Operation not permitted",
            2: "No such file or directory",
            3: "No such process",
            4: "Interrupted system call",
            5: "Input/output error",
            6: "No such device or address",
            7: "Argument list too long",
            8: "Exec format error",
            9: "Bad file descriptor",
            10: "No child processes",
            11: "Resource temporarily unavailable",
            12: "Cannot allocate memory",
            13: "Permission denied",
            14: "Bad address",
            16: "Device or resource busy",
            17: "File exists",
            18: "Invalid cross-device link",
            19: "No such device",
            20: "Not a directory",
            21: "Is a directory",
            22: "Invalid argument",
            23: "Too many open files in system",
            24: "Too many open files",
            25: "Inappropriate ioctl for device",
            26: "Text file busy",
            27: "File too large",
            28: "No space left on device",
            29: "Illegal seek",
            30: "Read-only file system",
            31: "Too many links",
            32: "Broken pipe",
            33: "Numerical argument out of domain",
            34: "Numerical result out of range",
            35: "Resource deadlock avoided",
            36: "File name too long",
            37: "No locks available",
            38: "Function not implemented",
            39: "Directory not empty",
            40: "Too many levels of symbolic links",
        }

    def _read_string(self, ptr: int, max_len: int = 4096) -> str:
        """Read null-terminated string from memory."""
        return self._emulator.memory.read_string(ptr, max_len)

    def _write_string(self, ptr: int, s: str) -> None:
        """Write null-terminated string to memory."""
        self._emulator.memory.write(ptr, s.encode('utf-8') + b'\x00')

    # ==================== Length functions ====================

    def strlen(self, s: int) -> int:
        """
        Calculate string length.
        
        size_t strlen(const char* s);
        """
        if s == 0:
            return 0
        string = self._read_string(s)
        return len(string)

    def strnlen(self, s: int, maxlen: int) -> int:
        """
        Calculate string length (bounded).
        
        size_t strnlen(const char* s, size_t maxlen);
        """
        if s == 0:
            return 0
        string = self._read_string(s, maxlen)
        return min(len(string), maxlen)

    # ==================== Copy functions ====================

    def strcpy(self, dest: int, src: int) -> int:
        """
        Copy string.
        
        char* strcpy(char* dest, const char* src);
        """
        string = self._read_string(src)
        self._write_string(dest, string)
        return dest

    def strncpy(self, dest: int, src: int, n: int) -> int:
        """
        Copy string (bounded).
        
        char* strncpy(char* dest, const char* src, size_t n);
        """
        string = self._read_string(src, n)
        data = string.encode('utf-8')[:n]
        # Pad with nulls if needed
        if len(data) < n:
            data += b'\x00' * (n - len(data))
        self._emulator.memory.write(dest, data)
        return dest

    def stpcpy(self, dest: int, src: int) -> int:
        """
        Copy string, return end of dest.
        
        char* stpcpy(char* dest, const char* src);
        """
        string = self._read_string(src)
        self._write_string(dest, string)
        return dest + len(string)

    def stpncpy(self, dest: int, src: int, n: int) -> int:
        """
        Copy string (bounded), return end of dest.
        
        char* stpncpy(char* dest, const char* src, size_t n);
        """
        string = self._read_string(src, n)
        data = string.encode('utf-8')[:n]
        length = len(data)
        if length < n:
            data += b'\x00' * (n - length)
        self._emulator.memory.write(dest, data)
        return dest + length

    def strlcpy(self, dest: int, src: int, size: int) -> int:
        """
        Copy string safely (BSD).
        
        size_t strlcpy(char* dest, const char* src, size_t size);
        """
        string = self._read_string(src)
        src_len = len(string)

        if size > 0:
            copy_len = min(src_len, size - 1)
            data = string.encode('utf-8')[:copy_len] + b'\x00'
            self._emulator.memory.write(dest, data)

        return src_len

    # ==================== Concatenation functions ====================

    def strcat(self, dest: int, src: int) -> int:
        """
        Concatenate strings.
        
        char* strcat(char* dest, const char* src);
        """
        dest_str = self._read_string(dest)
        src_str = self._read_string(src)
        self._write_string(dest, dest_str + src_str)
        return dest

    def strncat(self, dest: int, src: int, n: int) -> int:
        """
        Concatenate strings (bounded).
        
        char* strncat(char* dest, const char* src, size_t n);
        """
        dest_str = self._read_string(dest)
        src_str = self._read_string(src, n)[:n]
        self._write_string(dest, dest_str + src_str)
        return dest

    def strlcat(self, dest: int, src: int, size: int) -> int:
        """
        Concatenate strings safely (BSD).
        
        size_t strlcat(char* dest, const char* src, size_t size);
        """
        dest_str = self._read_string(dest)
        src_str = self._read_string(src)
        dest_len = len(dest_str)
        src_len = len(src_str)

        if size <= dest_len:
            return size + src_len

        copy_len = min(src_len, size - dest_len - 1)
        new_str = dest_str + src_str[:copy_len]
        self._write_string(dest, new_str)

        return dest_len + src_len

    # ==================== Comparison functions ====================

    def strcmp(self, s1: int, s2: int) -> int:
        """
        Compare strings.
        
        int strcmp(const char* s1, const char* s2);
        """
        str1 = self._read_string(s1)
        str2 = self._read_string(s2)

        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    def strncmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare strings (bounded).
        
        int strncmp(const char* s1, const char* s2, size_t n);
        """
        str1 = self._read_string(s1, n)[:n]
        str2 = self._read_string(s2, n)[:n]

        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    def strcasecmp(self, s1: int, s2: int) -> int:
        """
        Compare strings (case-insensitive).
        
        int strcasecmp(const char* s1, const char* s2);
        """
        str1 = self._read_string(s1).lower()
        str2 = self._read_string(s2).lower()

        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    def strncasecmp(self, s1: int, s2: int, n: int) -> int:
        """
        Compare strings (case-insensitive, bounded).
        
        int strncasecmp(const char* s1, const char* s2, size_t n);
        """
        str1 = self._read_string(s1, n)[:n].lower()
        str2 = self._read_string(s2, n)[:n].lower()

        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    # ==================== Search functions ====================

    def strchr(self, s: int, c: int) -> int:
        """
        Find character in string.
        
        char* strchr(const char* s, int c);
        """
        string = self._read_string(s)
        char = chr(c & 0xFF) if c else '\x00'

        if c == 0:
            # Find the null terminator
            return s + len(string)

        try:
            idx = string.index(char)
            return s + idx
        except ValueError:
            return 0

    def strrchr(self, s: int, c: int) -> int:
        """
        Find character in string (reverse).
        
        char* strrchr(const char* s, int c);
        """
        string = self._read_string(s)
        char = chr(c & 0xFF) if c else '\x00'

        if c == 0:
            return s + len(string)

        try:
            idx = string.rindex(char)
            return s + idx
        except ValueError:
            return 0

    def strchrnul(self, s: int, c: int) -> int:
        """
        Find character in string (return end if not found).
        
        char* strchrnul(const char* s, int c);
        """
        result = self.strchr(s, c)
        if result == 0:
            string = self._read_string(s)
            return s + len(string)
        return result

    def strstr(self, haystack: int, needle: int) -> int:
        """
        Find substring.
        
        char* strstr(const char* haystack, const char* needle);
        """
        hay = self._read_string(haystack)
        ndl = self._read_string(needle)

        if not ndl:
            return haystack

        try:
            idx = hay.index(ndl)
            return haystack + idx
        except ValueError:
            return 0

    def strcasestr(self, haystack: int, needle: int) -> int:
        """
        Find substring (case-insensitive).
        
        char* strcasestr(const char* haystack, const char* needle);
        """
        hay = self._read_string(haystack)
        ndl = self._read_string(needle)

        if not ndl:
            return haystack

        hay_lower = hay.lower()
        ndl_lower = ndl.lower()

        try:
            idx = hay_lower.index(ndl_lower)
            return haystack + idx
        except ValueError:
            return 0

    def strnstr(self, haystack: int, needle: int, len_: int) -> int:
        """
        Find substring (bounded).
        
        char* strnstr(const char* haystack, const char* needle, size_t len);
        """
        hay = self._read_string(haystack, len_)[:len_]
        ndl = self._read_string(needle)

        if not ndl:
            return haystack

        try:
            idx = hay.index(ndl)
            return haystack + idx
        except ValueError:
            return 0

    # ==================== Span functions ====================

    def strspn(self, s: int, accept: int) -> int:
        """
        Get span of characters in set.
        
        size_t strspn(const char* s, const char* accept);
        """
        string = self._read_string(s)
        accept_set = set(self._read_string(accept))

        count = 0
        for ch in string:
            if ch in accept_set:
                count += 1
            else:
                break
        return count

    def strcspn(self, s: int, reject: int) -> int:
        """
        Get span of characters not in set.
        
        size_t strcspn(const char* s, const char* reject);
        """
        string = self._read_string(s)
        reject_set = set(self._read_string(reject))

        count = 0
        for ch in string:
            if ch not in reject_set:
                count += 1
            else:
                break
        return count

    def strpbrk(self, s: int, accept: int) -> int:
        """
        Find first character in set.
        
        char* strpbrk(const char* s, const char* accept);
        """
        string = self._read_string(s)
        accept_set = set(self._read_string(accept))

        for i, ch in enumerate(string):
            if ch in accept_set:
                return s + i
        return 0

    # ==================== Token functions ====================

    def strtok(self, s: int, delim: int) -> int:
        """
        Tokenize string.
        
        char* strtok(char* s, const char* delim);
        """
        return self.strtok_r(s, delim, 0)

    def strtok_r(self, s: int, delim: int, saveptr: int) -> int:
        """
        Tokenize string (reentrant).
        
        char* strtok_r(char* s, const char* delim, char** saveptr);
        """
        # Get current position
        if s != 0:
            ptr = s
        elif saveptr != 0:
            ptr = self._emulator.memory.read_ptr(saveptr)
        else:
            ptr = self._strtok_ptr

        if ptr == 0:
            return 0

        delim_str = self._read_string(delim)
        delim_set = set(delim_str)

        # Skip leading delimiters
        string = self._read_string(ptr)
        start = 0
        while start < len(string) and string[start] in delim_set:
            start += 1

        if start >= len(string):
            # No more tokens
            if saveptr:
                self._emulator.memory.write_ptr(saveptr, 0)
            self._strtok_ptr = 0
            return 0

        # Find end of token
        end = start
        while end < len(string) and string[end] not in delim_set:
            end += 1

        # Null-terminate the token
        token_ptr = ptr + start
        if end < len(string):
            self._emulator.memory.write_u8(ptr + end, 0)
            next_ptr = ptr + end + 1
        else:
            next_ptr = 0

        if saveptr:
            self._emulator.memory.write_ptr(saveptr, next_ptr)
        self._strtok_ptr = next_ptr

        return token_ptr

    def strsep(self, stringp: int, delim: int) -> int:
        """
        Extract token from string.
        
        char* strsep(char** stringp, const char* delim);
        """
        ptr = self._emulator.memory.read_ptr(stringp)
        if ptr == 0:
            return 0

        string = self._read_string(ptr)
        delim_set = set(self._read_string(delim))

        # Find delimiter
        for i, ch in enumerate(string):
            if ch in delim_set:
                self._emulator.memory.write_u8(ptr + i, 0)
                self._emulator.memory.write_ptr(stringp, ptr + i + 1)
                return ptr

        # No delimiter found
        self._emulator.memory.write_ptr(stringp, 0)
        return ptr

    # ==================== Allocation functions ====================

    def strdup(self, s: int) -> int:
        """
        Duplicate string.
        
        char* strdup(const char* s);
        """
        string = self._read_string(s)
        length = len(string) + 1
        ptr = self._handler.memory.malloc(length)
        if ptr:
            self._write_string(ptr, string)
        return ptr

    def strndup(self, s: int, n: int) -> int:
        """
        Duplicate string (bounded).
        
        char* strndup(const char* s, size_t n);
        """
        string = self._read_string(s, n)[:n]
        length = len(string) + 1
        ptr = self._handler.memory.malloc(length)
        if ptr:
            self._write_string(ptr, string)
        return ptr

    # ==================== Error functions ====================

    def strerror(self, errnum: int) -> int:
        """
        Get error message string.
        
        char* strerror(int errnum);
        """
        msg = self._errno_messages.get(errnum, f"Unknown error {errnum}")
        ptr = self._handler.memory.malloc(len(msg) + 1)
        if ptr:
            self._write_string(ptr, msg)
        return ptr

    def strerror_r(self, errnum: int, buf: int, buflen: int) -> int:
        """
        Get error message string (reentrant).
        
        int strerror_r(int errnum, char* buf, size_t buflen);
        """
        msg = self._errno_messages.get(errnum, f"Unknown error {errnum}")
        if len(msg) >= buflen:
            return 34  # ERANGE
        self._write_string(buf, msg)
        return 0

    # ==================== Utility functions ====================

    def strrev(self, s: int) -> int:
        """
        Reverse string in-place (non-standard).
        
        char* strrev(char* s);
        """
        string = self._read_string(s)
        self._write_string(s, string[::-1])
        return s

    def strupr(self, s: int) -> int:
        """
        Convert to uppercase (non-standard).
        
        char* strupr(char* s);
        """
        string = self._read_string(s)
        self._write_string(s, string.upper())
        return s

    def strlwr(self, s: int) -> int:
        """
        Convert to lowercase (non-standard).
        
        char* strlwr(char* s);
        """
        string = self._read_string(s)
        self._write_string(s, string.lower())
        return s
