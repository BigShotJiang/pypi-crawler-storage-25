"""Android-specific emulator implementation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pyunidbg.android.jni import JavaVM, JNIEnv
from pyunidbg.android.libart import ArtRuntime
from pyunidbg.android.libc import LibcHandler
from pyunidbg.android.syscalls import SyscallHandler
from pyunidbg.core.constants import Architecture
from pyunidbg.core.emulator import Emulator, EmulatorConfig
from pyunidbg.loader.elf_loader import ELFLoader, LoadedModule

logger = logging.getLogger(__name__)


class AndroidEmulator(Emulator):
    """
    Android-specific emulator with JNI and syscall support.
    
    Extends the base emulator with:
    - JNI environment (JNIEnv, JavaVM)
    - Android syscall handling
    - Library loading with Android conventions
    """

    def __init__(
        self,
        arch: str | Architecture = "arm64",
        api_level: int = 29,
        **kwargs,
    ):
        """
        Initialize Android emulator.
        
        Args:
            arch: Architecture ("arm" or "arm64")
            api_level: Android API level to emulate
            **kwargs: Additional EmulatorConfig options
        """
        # Parse architecture
        if isinstance(arch, str):
            arch = Architecture(arch)

        config = EmulatorConfig(arch=arch, **kwargs)
        super().__init__(config)

        self.api_level = api_level

        # Initialize Android-specific components
        self.loader = ELFLoader(self)
        self.syscall = SyscallHandler(self)

        # Setup JNI
        self._jni_env = JNIEnv(self)
        self._java_vm = JavaVM(self)

        # Setup TLS (Thread Local Storage)
        self._setup_tls()

        # Setup libc
        self._libc = LibcHandler(self)
        self._setup_libc_hooks()

        # Setup fake libart.so (ART runtime)
        self._art = ArtRuntime(self)

        # Virtual filesystem
        self._vfs: dict[str, bytes] = {}

        # Loaded libraries
        self._libraries: dict[str, LoadedModule] = {}

        logger.info(f"AndroidEmulator initialized: arch={arch.value}, api={api_level}")

    @property
    def jni(self) -> JNIEnv:
        """Get JNI environment."""
        return self._jni_env

    @property
    def java_vm(self) -> JavaVM:
        """Get JavaVM pointer."""
        return self._java_vm

    @property
    def libc(self) -> LibcHandler:
        """Get libc handler."""
        return self._libc

    @property
    def art(self) -> ArtRuntime:
        """Get fake ART runtime for Java layer events."""
        return self._art

    def _setup_tls(self) -> None:
        """Setup Thread Local Storage (TLS) for Android emulation."""
        # Allocate TLS block - Android TLS is typically 64 slots of 8 bytes each = 512 bytes
        # Plus some extra for bionic specific fields
        tls_size = 0x1000  # 4KB should be plenty
        tls_base = self.memory.allocate(tls_size, name="[tls]")

        # Initialize TLS to zero
        self.memory.write(tls_base, b'\x00' * tls_size)

        # Stack canary is at TLS+40 (0x28) on ARM64
        # Set a random canary value
        import random
        canary = random.getrandbits(64) & 0xFFFFFFFFFFFFFF00  # Low byte should be 0
        self.memory.write_u64(tls_base + 40, canary)

        # Set TPIDR_EL0 to point to TLS
        from unicorn.arm64_const import UC_ARM64_REG_TPIDR_EL0
        self._uc.reg_write(UC_ARM64_REG_TPIDR_EL0, tls_base)

        # Store for later access
        self._tls_base = tls_base
        self._stack_canary = canary

        logger.debug(f"TLS initialized at 0x{tls_base:x}, canary=0x{canary:x}")

    def _setup_libc_hooks(self) -> None:
        """Register all libc function hooks."""
        from pyunidbg.core.constants import MemoryProtection

        # Map memory for stub region (DEAD0000 - DEAD0000 + 64KB)
        stub_base = 0xDEAD0000
        stub_size = 0x10000  # 64KB should be enough for all stubs
        self.memory.map(stub_base, stub_size,
                       protection=MemoryProtection.READ_WRITE_EXEC,
                       name="[libc_stubs]")

        # Get all libc functions from the handler
        # Wrap each function to accept *args (we pass all 8 registers)
        def wrap_libc_func(func):
            import inspect
            try:
                sig = inspect.signature(func)
                num_params = len([p for p in sig.parameters.values()
                                 if p.default == inspect.Parameter.empty])
            except (ValueError, TypeError):
                num_params = 3  # Default assumption

            def wrapper(*args):
                return func(*args[:num_params])
            return wrapper

        for name in self._libc.list_functions():
            handler = self._libc.get_function(name)
            if handler:
                stub_addr = self.loader.add_symbol_hook(name, wrap_libc_func(handler))
                self._write_stub_code(stub_addr)

        # Also add common symbols that might be required
        common_stubs = [
            "__stack_chk_fail",
            "__stack_chk_guard",
            "__cxa_atexit",
            "__cxa_finalize",
            "__cxa_begin_catch",
            "__cxa_end_catch",
            "__gxx_personality_v0",
            "__android_log_print",
            "__android_log_write",
            "__android_log_buf_write",
            "dlopen",
            "dlsym",
            "dlclose",
            "dlerror",
            # Fortified libc functions (__*_chk variants)
            "__strlen_chk",
            "__strcpy_chk",
            "__strcat_chk",
            "__strncpy_chk",
            "__strncat_chk",
            "__sprintf_chk",
            "__snprintf_chk",
            "__vsprintf_chk",
            "__vsnprintf_chk",
            "__memcpy_chk",
            "__memmove_chk",
            "__memset_chk",
            # C++ runtime
            "_ZdlPv",       # operator delete(void*)
            "_ZdaPv",       # operator delete[](void*)
            "_Znwm",        # operator new(unsigned long)
            "_Znam",        # operator new[](unsigned long)
            "_ZnwmRKSt9nothrow_t",  # operator new(size_t, nothrow)
            "_ZnamRKSt9nothrow_t",  # operator new[](size_t, nothrow)
            "__cxa_pure_virtual",
            "__cxa_throw",
            "__cxa_rethrow",
            "__cxa_allocate_exception",
            "__cxa_free_exception",
        ]

        # Map fortified functions to their regular counterparts
        # Note: fortified functions have extra size/flag args that we ignore
        # All handlers must accept *args because we pass all 8 registers
        def make_fortified_strlen(orig):
            return lambda s, maxlen, *args: orig(s) if orig else 0

        def make_fortified_strcpy(orig):
            return lambda dst, src, maxlen, *args: orig(dst, src) if orig else dst

        def make_fortified_strcat(orig):
            return lambda dst, src, maxlen, *args: orig(dst, src) if orig else dst

        def make_fortified_memcpy(orig):
            return lambda dst, src, n, maxlen, *args: orig(dst, src, n) if orig else dst

        def make_fortified_memmove(orig):
            return lambda dst, src, n, maxlen, *args: orig(dst, src, n) if orig else dst

        def make_fortified_memset(orig):
            return lambda s, c, n, maxlen, *args: orig(s, c, n) if orig else s

        # For printf functions, we just call the normal version (ignore flag/size args)
        # __sprintf_chk(char* str, int flag, size_t strlen, const char* format, ...)
        def make_fortified_sprintf(orig):
            return lambda s, flag, slen, fmt, *args: orig(s, fmt, *args) if orig else 0

        # __snprintf_chk(char* str, size_t maxlen, int flag, size_t strlen, const char* format, ...)
        def make_fortified_snprintf(orig):
            return lambda s, maxlen, flag, slen, fmt, *args: orig(s, maxlen, fmt, *args) if orig else 0

        fortified_map = {
            "__strlen_chk": make_fortified_strlen(self._libc.get_function("strlen")),
            "__strcpy_chk": make_fortified_strcpy(self._libc.get_function("strcpy")),
            "__strcat_chk": make_fortified_strcat(self._libc.get_function("strcat")),
            "__strncpy_chk": self._libc.get_function("strncpy"),  # already has length
            "__strncat_chk": self._libc.get_function("strncat"),  # already has length
            "__memcpy_chk": make_fortified_memcpy(self._libc.get_function("memcpy")),
            "__memmove_chk": make_fortified_memmove(self._libc.get_function("memmove")),
            "__memset_chk": make_fortified_memset(self._libc.get_function("memset")),
            "__sprintf_chk": make_fortified_sprintf(self._libc.get_function("sprintf")),
            "__snprintf_chk": make_fortified_snprintf(self._libc.get_function("snprintf")),
            "__vsprintf_chk": lambda *args: 0,  # Complex - stub for now
            "__vsnprintf_chk": lambda *args: 0,  # Complex - stub for now
        }

        # Map C++ allocators to malloc/free
        cpp_alloc_map = {
            "_Znwm": self._libc.get_function("malloc"),
            "_Znam": self._libc.get_function("malloc"),
            "_ZnwmRKSt9nothrow_t": self._libc.get_function("malloc"),
            "_ZnamRKSt9nothrow_t": self._libc.get_function("malloc"),
            "_ZdlPv": self._libc.get_function("free"),
            "_ZdaPv": self._libc.get_function("free"),
        }

        # POSIX file-I/O wrappers that delegate to the syscall layer. These
        # are required because many real binaries call open/read/close via
        # the libc API (PLT) rather than via `svc #0`. Without them the GOT
        # slot stays at zero and the first call traps with FETCH_UNMAPPED.
        # We forward to the existing FileOperations which already supports
        # the emulator's virtual filesystem (`emu.add_virtual_file`).
        posix_io_map = self._build_posix_io_map()
        common_stubs.extend(posix_io_map.keys())

        for name in common_stubs:
            if not self.loader.get_symbol_hook(name):
                # Check if we have a mapped handler
                handler = (fortified_map.get(name)
                           or cpp_alloc_map.get(name)
                           or posix_io_map.get(name))
                if handler is None:
                    handler = lambda *args: 0  # Default to returning 0
                stub_addr = self.loader.add_symbol_hook(name, handler)
                self._write_stub_code(stub_addr)

        # Add a code hook to intercept stub execution
        self._add_stub_handler()

        logger.debug(f"Registered {len(self.loader.list_symbol_hooks())} libc hooks")

    def _build_posix_io_map(self) -> dict[str, Any]:
        """
        Build libc-level wrappers for POSIX file-I/O functions that delegate
        to the syscall layer. Returns {name: handler} suitable for
        `loader.add_symbol_hook`.

        Why this exists: when a binary calls `open`/`read`/... via libc
        instead of `svc #0`, the PLT slot must resolve to a real stub or
        the first call traps with UC_ERR_FETCH_UNMAPPED. The FileOperations
        class already implements the semantics we need; we just expose them
        at the symbol table level.
        """
        fops = self.syscall.file_ops if hasattr(self.syscall, "file_ops") else None
        if fops is None:
            return {}

        # Each handler accepts *args because the stub dispatcher passes all
        # general-purpose argument registers (8 on ARM64, 4 on ARM32).
        def _open(pathname, flags=0, mode=0, *_):
            return fops.sys_open(pathname, flags, mode) & 0xFFFFFFFFFFFFFFFF

        def _openat(dirfd, pathname, flags=0, mode=0, *_):
            return fops.sys_openat(dirfd, pathname, flags, mode) & 0xFFFFFFFFFFFFFFFF

        def _close(fd, *_):
            return fops.sys_close(fd) & 0xFFFFFFFFFFFFFFFF

        def _read(fd, buf, count, *_):
            return fops.sys_read(fd, buf, count) & 0xFFFFFFFFFFFFFFFF

        def _write(fd, buf, count, *_):
            return fops.sys_write(fd, buf, count) & 0xFFFFFFFFFFFFFFFF

        def _lseek(fd, offset, whence, *_):
            return fops.sys_lseek(fd, offset, whence) & 0xFFFFFFFFFFFFFFFF

        def _access(pathname, mode, *_):
            # Delegate to openat-based existence check. Return 0 if the file
            # exists in the VFS, -1 otherwise (errno path is best-effort).
            try:
                if hasattr(fops, "sys_faccessat"):
                    return fops.sys_faccessat(-100, pathname, mode, 0) & 0xFFFFFFFFFFFFFFFF
            except Exception:
                pass
            try:
                path = self.memory.read_string(pathname) if pathname else ""
            except Exception:
                return 0xFFFFFFFFFFFFFFFF
            return 0 if (path in fops._vfs or self.get_virtual_file(path) is not None) else 0xFFFFFFFFFFFFFFFF

        def _unlink(pathname, *_):
            try:
                if hasattr(fops, "sys_unlinkat"):
                    return fops.sys_unlinkat(-100, pathname, 0) & 0xFFFFFFFFFFFFFFFF
            except Exception:
                pass
            return 0

        return {
            "open":   _open,
            "openat": _openat,
            "close":  _close,
            "read":   _read,
            "write":  _write,
            "lseek":  _lseek,
            "lseek64": _lseek,
            "access": _access,
            "unlink": _unlink,
        }

    def _write_stub_code(self, addr: int) -> None:
        """Write stub code at the given address."""
        if self.is_64bit:
            # ARM64: RET (0xD65F03C0)
            self.memory.write(addr, b"\xC0\x03\x5F\xD6")
        else:
            # ARM: BX LR (0xE12FFF1E)
            self.memory.write(addr, b"\x1E\xFF\x2F\xE1")

    def _add_stub_handler(self) -> None:
        """Add a hook to intercept execution at stub addresses."""
        stub_base = 0xDEAD0000
        stub_end = stub_base + 0x10000

        def stub_hook(uc, address, size, user_data):
            # Check if this is a stub address
            hook_info = self.loader.get_hook_at_address(address)
            if hook_info:
                name, handler = hook_info

                # Call the handler and get result
                try:
                    # Get arguments (x0-x7 or r0-r3 depending on arch)
                    if self.is_64bit:
                        args = [self.cpu.get_arg(i) for i in range(8)]
                    else:
                        args = [self.cpu.get_arg(i) for i in range(4)]

                    logger.debug(f"Stub called: {name} at 0x{address:x}")

                    # Call handler
                    result = handler(*args) if callable(handler) else 0
                    if result is None:
                        result = 0

                    # Set return value
                    self.cpu.set_return_value(result)
                except Exception as e:
                    logger.warning(f"Stub handler error for {name}: {e}")
                    self.cpu.set_return_value(0)

        # Add code hook for stub region
        from unicorn import UC_HOOK_CODE
        self._uc.hook_add(UC_HOOK_CODE, stub_hook, begin=stub_base, end=stub_end)

    def load_library(
        self,
        path: str | Path,
        call_jni_onload: bool = True,
    ) -> LoadedModule:
        """
        Load an Android native library.
        
        Args:
            path: Path to the .so file
            call_jni_onload: Call JNI_OnLoad if present
        
        Returns:
            LoadedModule representing the library
        """
        path = Path(path)
        module = self.loader.load(path, auto_init=True)

        self._libraries[module.name] = module

        # Call JNI_OnLoad if present and requested
        if call_jni_onload and module.jni_onload:
            logger.info(f"Calling JNI_OnLoad for {module.name}")
            result = self.call_jni_onload(module)
            logger.info(f"JNI_OnLoad returned: {result}")

        return module

    def call_jni_onload(self, module: LoadedModule) -> int:
        """
        Call JNI_OnLoad for a module.
        
        Args:
            module: The loaded module
        
        Returns:
            JNI version returned by JNI_OnLoad
        """
        if module.jni_onload is None:
            raise ValueError(f"Module {module.name} has no JNI_OnLoad")

        # JNI_OnLoad(JavaVM* vm, void* reserved)
        java_vm_ptr = self._java_vm.get_pointer()
        return self.call(module.jni_onload, [java_vm_ptr, 0])

    def call_jni(
        self,
        method_name: str,
        args: list[Any] | None = None,
        jclass: Any = None,
        jobject: Any = None,
        **kwargs,
    ) -> Any:
        """
        Call a JNI method.
        
        Args:
            method_name: Name of the JNI method (e.g., "Java_com_example_Native_encrypt")
            args: Method arguments
            jclass: The jclass argument (for static methods)
            jobject: The jobject argument (for instance methods)
            **kwargs: String arguments (will be converted to jstring)
        
        Returns:
            Method return value
        """
        args = args or []

        # Find the symbol
        symbol_info = self.loader.get_symbol(method_name)
        if symbol_info is None:
            raise ValueError(f"JNI method not found: {method_name}")

        _, symbol = symbol_info

        # Prepare JNI arguments
        jni_args = [self._jni_env.get_pointer()]  # JNIEnv*

        # Add jclass or jobject
        if jclass is not None:
            jni_args.append(jclass)
        elif jobject is not None:
            jni_args.append(jobject)
        else:
            jni_args.append(0)  # NULL for now

        # Convert string kwargs to jstring
        for key, value in kwargs.items():
            if isinstance(value, str):
                jstr = self._jni_env.new_string_utf(value)
                jni_args.append(jstr)
            else:
                jni_args.append(value)

        # Add remaining args
        jni_args.extend(args)

        # Call the method
        result = self.call(symbol.address, jni_args)

        return result

    def get_jstring(self, jstring_ptr: int) -> str:
        """Get the string value of a jstring."""
        return self._jni_env.get_string_utf(jstring_ptr)

    def add_virtual_file(self, path: str, content: bytes) -> None:
        """
        Add a file to the virtual filesystem.
        
        Args:
            path: Virtual path
            content: File contents
        """
        self._vfs[path] = content

    def get_virtual_file(self, path: str) -> bytes | None:
        """Get contents of a virtual file."""
        return self._vfs.get(path)

    def get_library(self, name: str) -> LoadedModule | None:
        """Get a loaded library by name."""
        return self._libraries.get(name)

    def list_libraries(self) -> list[LoadedModule]:
        """List all loaded libraries."""
        return list(self._libraries.values())

    def find_function(self, name: str) -> int | None:
        """
        Find a function address by name.
        
        Searches all loaded libraries.
        """
        result = self.loader.get_symbol(name)
        if result:
            return result[1].address
        return None

    def __repr__(self) -> str:
        return (
            f"AndroidEmulator(arch={self.config.arch.value}, "
            f"api={self.api_level}, libs={len(self._libraries)})"
        )
