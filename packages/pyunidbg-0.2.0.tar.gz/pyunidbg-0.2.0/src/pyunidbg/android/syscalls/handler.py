"""Main syscall handler that coordinates all syscall operations."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING

from unicorn import UC_HOOK_INTR
from unicorn.arm64_const import UC_ARM64_REG_X8
from unicorn.arm_const import UC_ARM_REG_R7

from pyunidbg.core.constants import Architecture
from pyunidbg.core.hooks import HookAction

from .defs import Errno, SyscallARM32, SyscallARM64
from .file_ops import FileOperations
from .memory_ops import MemoryOperations
from .network_ops import NetworkOperations
from .process_ops import ProcessOperations
from .signal_ops import SignalOperations
from .time_ops import TimeOperations

if TYPE_CHECKING:
    from pyunidbg.android.emulator import AndroidEmulator

logger = logging.getLogger(__name__)


class SyscallHandler:
    """
    Comprehensive Linux/Android syscall handler.
    
    Intercepts and emulates all major syscalls made by native code.
    Organized into specialized operation modules.
    """

    def __init__(self, emulator: AndroidEmulator):
        self._emulator = emulator
        self._arch = emulator.arch

        # Virtual filesystem
        self._vfs: dict[str, bytes] = {}
        self._init_default_vfs()

        # Initialize operation modules
        self.file_ops = FileOperations(self)
        self.memory_ops = MemoryOperations(self)
        self.process_ops = ProcessOperations(self)
        self.network_ops = NetworkOperations(self)
        self.time_ops = TimeOperations(self)
        self.signal_ops = SignalOperations(self)

        # Syscall dispatch tables
        self._handlers64: dict[int, Callable] = {}
        self._handlers32: dict[int, Callable] = {}

        # Custom syscall hooks
        self._custom_handlers: dict[int, Callable] = {}

        self._register_handlers()
        self._setup_syscall_hook()

    def _setup_syscall_hook(self) -> None:
        """Setup the syscall interrupt hook."""
        self._emulator._uc.hook_add(
            UC_HOOK_INTR,
            self._syscall_interrupt,
            user_data=self,
        )

    def _init_default_vfs(self) -> None:
        """Initialize default virtual files for Android emulation."""
        # Process information
        self._vfs["/proc/self/cmdline"] = b"app_process\x00"
        self._vfs["/proc/self/maps"] = b""
        self._vfs["/proc/self/status"] = b"Name:\tapp_process\nPid:\t1000\nUid:\t10000\n"
        self._vfs["/proc/self/exe"] = b"/system/bin/app_process"

        # System properties
        self._vfs["/system/build.prop"] = b"ro.build.version.sdk=29\nro.build.version.release=10\n"
        self._vfs["/system/etc/prop.default"] = b""

        # Timezone
        self._vfs["/etc/timezone"] = b"UTC"
        self._vfs["/etc/localtime"] = b""

        # Random devices
        self._vfs["/dev/urandom"] = b"\x00" * 256
        self._vfs["/dev/random"] = b"\x00" * 256

    def add_virtual_file(self, path: str, content: bytes) -> None:
        """
        Add a file to the virtual filesystem.
        
        Args:
            path: Virtual path
            content: File contents
        """
        self._vfs[path] = content

    def get_virtual_file(self, path: str) -> bytes | None:
        """Get contents of a virtual file."""
        return self._vfs.get(path)

    def _syscall_interrupt(self, uc, intno, user_data) -> None:
        """Handle syscall interrupt."""
        if self._arch == Architecture.ARM64:
            syscall_num = uc.reg_read(UC_ARM64_REG_X8)
            self._handle_syscall_arm64(syscall_num)
        elif self._arch == Architecture.ARM:
            syscall_num = uc.reg_read(UC_ARM_REG_R7)
            self._handle_syscall_arm32(syscall_num)

    def _handle_syscall_arm64(self, num: int) -> None:
        """Handle ARM64 syscall."""
        cpu = self._emulator.cpu

        # Get up to 6 arguments
        args = [cpu.get_arg(i) for i in range(6)]

        # Get syscall name
        try:
            name = SyscallARM64(num).name
        except ValueError:
            name = f"UNKNOWN_{num}"

        logger.debug(f"Syscall: {name}({num}) args={[hex(a) for a in args]}")

        # Check for user hooks first
        hooks = self._emulator.hook.get_syscall_hooks(num)
        if not hooks:
            hooks = self._emulator.hook.get_syscall_hooks(name.lower())

        for hook in hooks:
            if hook.enabled:
                result = hook.callback(self._emulator, *args)
                if result == HookAction.SKIP:
                    return

        # Check custom handlers
        if num in self._custom_handlers:
            result = self._custom_handlers[num](*args)
            cpu.set_return_value(result if result is not None else 0)
            return

        # Call registered handler
        handler = self._handlers64.get(num)
        if handler:
            try:
                result = handler(*args)
                cpu.set_return_value(result if result is not None else 0)
            except Exception as e:
                logger.error(f"Syscall {name} failed: {e}")
                cpu.set_return_value(-Errno.ENOSYS)
        else:
            logger.warning(f"Unhandled syscall: {name}({num})")
            cpu.set_return_value(-Errno.ENOSYS)

    def _handle_syscall_arm32(self, num: int) -> None:
        """Handle ARM32 syscall."""
        cpu = self._emulator.cpu
        args = [cpu.get_arg(i) for i in range(7)]

        try:
            name = SyscallARM32(num).name
        except ValueError:
            name = f"UNKNOWN_{num}"

        logger.debug(f"Syscall: {name}({num}) args={[hex(a) for a in args]}")

        if num in self._custom_handlers:
            result = self._custom_handlers[num](*args)
            cpu.set_return_value(result if result is not None else 0)
            return

        handler = self._handlers32.get(num)
        if handler:
            try:
                result = handler(*args)
                cpu.set_return_value(result if result is not None else 0)
            except Exception as e:
                logger.error(f"Syscall {name} failed: {e}")
                cpu.set_return_value(-Errno.ENOSYS)
        else:
            logger.warning(f"Unhandled syscall: {name}({num})")
            cpu.set_return_value(-Errno.ENOSYS)

    def _register_handlers(self) -> None:
        """Register all syscall handlers."""
        # ARM64 handlers
        self._handlers64 = {
            # File operations
            SyscallARM64.OPENAT: self.file_ops.sys_openat,
            SyscallARM64.CLOSE: self.file_ops.sys_close,
            SyscallARM64.READ: self.file_ops.sys_read,
            SyscallARM64.WRITE: self.file_ops.sys_write,
            SyscallARM64.PREAD64: self.file_ops.sys_pread64,
            SyscallARM64.PWRITE64: self.file_ops.sys_pwrite64,
            SyscallARM64.READV: self.file_ops.sys_readv,
            SyscallARM64.WRITEV: self.file_ops.sys_writev,
            SyscallARM64.LSEEK: self.file_ops.sys_lseek,
            SyscallARM64.FSTAT: self.file_ops.sys_fstat,
            SyscallARM64.NEWFSTATAT: self.file_ops.sys_newfstatat,
            SyscallARM64.STATFS: self.file_ops.sys_statfs,
            SyscallARM64.FSTATFS: self.file_ops.sys_fstatfs,
            SyscallARM64.GETDENTS64: self.file_ops.sys_getdents64,
            SyscallARM64.GETCWD: self.file_ops.sys_getcwd,
            SyscallARM64.CHDIR: self.file_ops.sys_chdir,
            SyscallARM64.FCHDIR: self.file_ops.sys_fchdir,
            SyscallARM64.MKDIRAT: self.file_ops.sys_mkdirat,
            SyscallARM64.UNLINKAT: self.file_ops.sys_unlinkat,
            SyscallARM64.RENAMEAT: self.file_ops.sys_renameat,
            SyscallARM64.LINKAT: self.file_ops.sys_linkat,
            SyscallARM64.SYMLINKAT: self.file_ops.sys_symlinkat,
            SyscallARM64.READLINKAT: self.file_ops.sys_readlinkat,
            SyscallARM64.FACCESSAT: self.file_ops.sys_faccessat,
            SyscallARM64.FCHMOD: self.file_ops.sys_fchmod,
            SyscallARM64.FCHMODAT: self.file_ops.sys_fchmodat,
            SyscallARM64.FCHOWN: self.file_ops.sys_fchown,
            SyscallARM64.FCHOWNAT: self.file_ops.sys_fchownat,
            SyscallARM64.TRUNCATE: self.file_ops.sys_truncate,
            SyscallARM64.FTRUNCATE: self.file_ops.sys_ftruncate,
            SyscallARM64.UMASK: self.file_ops.sys_umask,
            SyscallARM64.DUP: self.file_ops.sys_dup,
            SyscallARM64.DUP3: self.file_ops.sys_dup3,
            SyscallARM64.PIPE2: self.file_ops.sys_pipe2,
            SyscallARM64.FCNTL: self.file_ops.sys_fcntl,
            SyscallARM64.IOCTL: self.file_ops.sys_ioctl,
            SyscallARM64.FLOCK: self.file_ops.sys_flock,
            SyscallARM64.SYNC: self.file_ops.sys_sync,
            SyscallARM64.FSYNC: self.file_ops.sys_fsync,
            SyscallARM64.FDATASYNC: self.file_ops.sys_fdatasync,
            SyscallARM64.SYNCFS: self.file_ops.sys_syncfs,

            # Memory operations
            SyscallARM64.MMAP: self.memory_ops.sys_mmap,
            SyscallARM64.MUNMAP: self.memory_ops.sys_munmap,
            SyscallARM64.MPROTECT: self.memory_ops.sys_mprotect,
            SyscallARM64.MREMAP: self.memory_ops.sys_mremap,
            SyscallARM64.BRK: self.memory_ops.sys_brk,
            SyscallARM64.MLOCK: self.memory_ops.sys_mlock,
            SyscallARM64.MLOCK2: self.memory_ops.sys_mlock2,
            SyscallARM64.MUNLOCK: self.memory_ops.sys_munlock,
            SyscallARM64.MLOCKALL: self.memory_ops.sys_mlockall,
            SyscallARM64.MUNLOCKALL: self.memory_ops.sys_munlockall,
            SyscallARM64.MADVISE: self.memory_ops.sys_madvise,
            SyscallARM64.MINCORE: self.memory_ops.sys_mincore,
            SyscallARM64.MSYNC: self.memory_ops.sys_msync,
            SyscallARM64.MEMBARRIER: self.memory_ops.sys_membarrier,
            SyscallARM64.MEMFD_CREATE: self.memory_ops.sys_memfd_create,
            SyscallARM64.PROCESS_VM_READV: self.memory_ops.sys_process_vm_readv,
            SyscallARM64.PROCESS_VM_WRITEV: self.memory_ops.sys_process_vm_writev,

            # Process operations
            SyscallARM64.GETPID: self.process_ops.sys_getpid,
            SyscallARM64.GETPPID: self.process_ops.sys_getppid,
            SyscallARM64.GETTID: self.process_ops.sys_gettid,
            SyscallARM64.GETPGID: self.process_ops.sys_getpgid,
            SyscallARM64.SETPGID: self.process_ops.sys_setpgid,
            SyscallARM64.GETSID: self.process_ops.sys_getsid,
            SyscallARM64.SETSID: self.process_ops.sys_setsid,
            SyscallARM64.GETUID: self.process_ops.sys_getuid,
            SyscallARM64.GETEUID: self.process_ops.sys_geteuid,
            SyscallARM64.GETGID: self.process_ops.sys_getgid,
            SyscallARM64.GETEGID: self.process_ops.sys_getegid,
            SyscallARM64.SETUID: self.process_ops.sys_setuid,
            SyscallARM64.SETGID: self.process_ops.sys_setgid,
            SyscallARM64.SETREUID: self.process_ops.sys_setreuid,
            SyscallARM64.SETREGID: self.process_ops.sys_setregid,
            SyscallARM64.SETRESUID: self.process_ops.sys_setresuid,
            SyscallARM64.GETRESUID: self.process_ops.sys_getresuid,
            SyscallARM64.SETRESGID: self.process_ops.sys_setresgid,
            SyscallARM64.GETRESGID: self.process_ops.sys_getresgid,
            SyscallARM64.SETFSUID: self.process_ops.sys_setfsuid,
            SyscallARM64.SETFSGID: self.process_ops.sys_setfsgid,
            SyscallARM64.GETGROUPS: self.process_ops.sys_getgroups,
            SyscallARM64.SETGROUPS: self.process_ops.sys_setgroups,
            SyscallARM64.SET_TID_ADDRESS: self.process_ops.sys_set_tid_address,
            SyscallARM64.SET_ROBUST_LIST: self.process_ops.sys_set_robust_list,
            SyscallARM64.GET_ROBUST_LIST: self.process_ops.sys_get_robust_list,
            SyscallARM64.CLONE: self.process_ops.sys_clone,
            SyscallARM64.FUTEX: self.process_ops.sys_futex,
            SyscallARM64.PRCTL: self.process_ops.sys_prctl,
            SyscallARM64.SECCOMP: self.process_ops.sys_seccomp,
            SyscallARM64.EXIT: self.process_ops.sys_exit,
            SyscallARM64.EXIT_GROUP: self.process_ops.sys_exit_group,
            SyscallARM64.UNAME: self.process_ops.sys_uname,
            SyscallARM64.SYSINFO: self.process_ops.sys_sysinfo,
            SyscallARM64.GETCPU: self.process_ops.sys_getcpu,
            SyscallARM64.GETRLIMIT: self.process_ops.sys_getrlimit,
            SyscallARM64.SETRLIMIT: self.process_ops.sys_setrlimit,
            SyscallARM64.PRLIMIT64: self.process_ops.sys_prlimit64,
            SyscallARM64.GETRUSAGE: self.process_ops.sys_getrusage,
            SyscallARM64.TIMES: self.process_ops.sys_times,
            SyscallARM64.SCHED_YIELD: self.process_ops.sys_sched_yield,
            SyscallARM64.SCHED_GETAFFINITY: self.process_ops.sys_sched_getaffinity,
            SyscallARM64.SCHED_SETAFFINITY: self.process_ops.sys_sched_setaffinity,
            SyscallARM64.SCHED_GETSCHEDULER: self.process_ops.sys_sched_getscheduler,
            SyscallARM64.SCHED_SETSCHEDULER: self.process_ops.sys_sched_setscheduler,
            SyscallARM64.SCHED_GETPARAM: self.process_ops.sys_sched_getparam,
            SyscallARM64.SCHED_SETPARAM: self.process_ops.sys_sched_setparam,
            SyscallARM64.SCHED_GET_PRIORITY_MAX: self.process_ops.sys_sched_get_priority_max,
            SyscallARM64.SCHED_GET_PRIORITY_MIN: self.process_ops.sys_sched_get_priority_min,
            SyscallARM64.SCHED_RR_GET_INTERVAL: self.process_ops.sys_sched_rr_get_interval,
            SyscallARM64.CAPGET: self.process_ops.sys_capget,
            SyscallARM64.CAPSET: self.process_ops.sys_capset,
            SyscallARM64.GETRANDOM: self.process_ops.sys_getrandom,
            SyscallARM64.PERSONALITY: self.process_ops.sys_personality,

            # Network operations
            SyscallARM64.SOCKET: self.network_ops.sys_socket,
            SyscallARM64.SOCKETPAIR: self.network_ops.sys_socketpair,
            SyscallARM64.BIND: self.network_ops.sys_bind,
            SyscallARM64.LISTEN: self.network_ops.sys_listen,
            SyscallARM64.ACCEPT: self.network_ops.sys_accept,
            SyscallARM64.ACCEPT4: self.network_ops.sys_accept4,
            SyscallARM64.CONNECT: self.network_ops.sys_connect,
            SyscallARM64.SHUTDOWN: self.network_ops.sys_shutdown,
            SyscallARM64.GETSOCKNAME: self.network_ops.sys_getsockname,
            SyscallARM64.GETPEERNAME: self.network_ops.sys_getpeername,
            SyscallARM64.SETSOCKOPT: self.network_ops.sys_setsockopt,
            SyscallARM64.GETSOCKOPT: self.network_ops.sys_getsockopt,
            SyscallARM64.SENDTO: self.network_ops.sys_sendto,
            SyscallARM64.RECVFROM: self.network_ops.sys_recvfrom,
            SyscallARM64.SENDMSG: self.network_ops.sys_sendmsg,
            SyscallARM64.RECVMSG: self.network_ops.sys_recvmsg,
            SyscallARM64.SENDMMSG: self.network_ops.sys_sendmmsg,
            SyscallARM64.RECVMMSG: self.network_ops.sys_recvmmsg,
            SyscallARM64.EPOLL_CREATE1: self.network_ops.sys_epoll_create1,
            SyscallARM64.EPOLL_CTL: self.network_ops.sys_epoll_ctl,
            SyscallARM64.EPOLL_PWAIT: self.network_ops.sys_epoll_pwait,
            SyscallARM64.PSELECT6: self.network_ops.sys_pselect6,
            SyscallARM64.PPOLL: self.network_ops.sys_ppoll,
            SyscallARM64.EVENTFD2: self.network_ops.sys_eventfd2,
            SyscallARM64.TIMERFD_CREATE: self.network_ops.sys_timerfd_create,
            SyscallARM64.TIMERFD_SETTIME: self.network_ops.sys_timerfd_settime,
            SyscallARM64.TIMERFD_GETTIME: self.network_ops.sys_timerfd_gettime,
            SyscallARM64.SIGNALFD4: self.network_ops.sys_signalfd4,
            SyscallARM64.INOTIFY_INIT1: self.network_ops.sys_inotify_init1,
            SyscallARM64.INOTIFY_ADD_WATCH: self.network_ops.sys_inotify_add_watch,
            SyscallARM64.INOTIFY_RM_WATCH: self.network_ops.sys_inotify_rm_watch,

            # Time operations
            SyscallARM64.CLOCK_GETTIME: self.time_ops.sys_clock_gettime,
            SyscallARM64.CLOCK_SETTIME: self.time_ops.sys_clock_settime,
            SyscallARM64.CLOCK_GETRES: self.time_ops.sys_clock_getres,
            SyscallARM64.CLOCK_NANOSLEEP: self.time_ops.sys_clock_nanosleep,
            SyscallARM64.GETTIMEOFDAY: self.time_ops.sys_gettimeofday,
            SyscallARM64.SETTIMEOFDAY: self.time_ops.sys_settimeofday,
            SyscallARM64.NANOSLEEP: self.time_ops.sys_nanosleep,
            SyscallARM64.GETITIMER: self.time_ops.sys_getitimer,
            SyscallARM64.SETITIMER: self.time_ops.sys_setitimer,
            SyscallARM64.TIMER_CREATE: self.time_ops.sys_timer_create,
            SyscallARM64.TIMER_SETTIME: self.time_ops.sys_timer_settime,
            SyscallARM64.TIMER_GETTIME: self.time_ops.sys_timer_gettime,
            SyscallARM64.TIMER_GETOVERRUN: self.time_ops.sys_timer_getoverrun,
            SyscallARM64.TIMER_DELETE: self.time_ops.sys_timer_delete,
            SyscallARM64.UTIMENSAT: self.time_ops.sys_utimensat,
            SyscallARM64.ADJTIMEX: self.time_ops.sys_adjtimex,
            SyscallARM64.CLOCK_ADJTIME: self.time_ops.sys_clock_adjtime,

            # Signal operations
            SyscallARM64.RT_SIGACTION: self.signal_ops.sys_rt_sigaction,
            SyscallARM64.RT_SIGPROCMASK: self.signal_ops.sys_rt_sigprocmask,
            SyscallARM64.RT_SIGPENDING: self.signal_ops.sys_rt_sigpending,
            SyscallARM64.RT_SIGSUSPEND: self.signal_ops.sys_rt_sigsuspend,
            SyscallARM64.RT_SIGTIMEDWAIT: self.signal_ops.sys_rt_sigtimedwait,
            SyscallARM64.RT_SIGQUEUEINFO: self.signal_ops.sys_rt_sigqueueinfo,
            SyscallARM64.RT_TGSIGQUEUEINFO: self.signal_ops.sys_rt_tgsigqueueinfo,
            SyscallARM64.RT_SIGRETURN: self.signal_ops.sys_rt_sigreturn,
            SyscallARM64.KILL: self.signal_ops.sys_kill,
            SyscallARM64.TKILL: self.signal_ops.sys_tkill,
            SyscallARM64.TGKILL: self.signal_ops.sys_tgkill,
            SyscallARM64.SIGALTSTACK: self.signal_ops.sys_sigaltstack,
        }

        # ARM32 handlers
        self._handlers32 = {
            # File operations
            SyscallARM32.OPEN: self.file_ops.sys_open,
            SyscallARM32.OPENAT: self.file_ops.sys_openat,
            SyscallARM32.CLOSE: self.file_ops.sys_close,
            SyscallARM32.READ: self.file_ops.sys_read,
            SyscallARM32.WRITE: self.file_ops.sys_write,
            SyscallARM32.PREAD64: self.file_ops.sys_pread64,
            SyscallARM32.PWRITE64: self.file_ops.sys_pwrite64,
            SyscallARM32.READV: self.file_ops.sys_readv,
            SyscallARM32.WRITEV: self.file_ops.sys_writev,
            SyscallARM32.LSEEK: self.file_ops.sys_lseek,
            SyscallARM32.LLSEEK: self.file_ops.sys_llseek,
            SyscallARM32.FSTAT: self.file_ops.sys_fstat,
            SyscallARM32.FSTAT64: self.file_ops.sys_fstat,
            SyscallARM32.STAT64: lambda path, buf: self.file_ops.sys_newfstatat(-100, path, buf, 0),
            SyscallARM32.FSTATAT64: self.file_ops.sys_newfstatat,
            SyscallARM32.STATFS: self.file_ops.sys_statfs,
            SyscallARM32.STATFS64: self.file_ops.sys_statfs,
            SyscallARM32.FSTATFS: self.file_ops.sys_fstatfs,
            SyscallARM32.FSTATFS64: self.file_ops.sys_fstatfs,
            SyscallARM32.GETDENTS: self.file_ops.sys_getdents64,
            SyscallARM32.GETDENTS64: self.file_ops.sys_getdents64,
            SyscallARM32.GETCWD: self.file_ops.sys_getcwd,
            SyscallARM32.CHDIR: self.file_ops.sys_chdir,
            SyscallARM32.FCHDIR: self.file_ops.sys_fchdir,
            SyscallARM32.MKDIR: lambda path, mode: self.file_ops.sys_mkdirat(-100, path, mode),
            SyscallARM32.MKDIRAT: self.file_ops.sys_mkdirat,
            SyscallARM32.RMDIR: lambda path: self.file_ops.sys_unlinkat(-100, path, 0x200),
            SyscallARM32.UNLINK: lambda path: self.file_ops.sys_unlinkat(-100, path, 0),
            SyscallARM32.UNLINKAT: self.file_ops.sys_unlinkat,
            SyscallARM32.RENAME: lambda old, new: self.file_ops.sys_renameat(-100, old, -100, new),
            SyscallARM32.RENAMEAT: self.file_ops.sys_renameat,
            SyscallARM32.LINK: lambda old, new: self.file_ops.sys_linkat(-100, old, -100, new, 0),
            SyscallARM32.LINKAT: self.file_ops.sys_linkat,
            SyscallARM32.SYMLINK: lambda target, link: self.file_ops.sys_symlinkat(target, -100, link),
            SyscallARM32.SYMLINKAT: self.file_ops.sys_symlinkat,
            SyscallARM32.READLINK: lambda path, buf, size: self.file_ops.sys_readlinkat(-100, path, buf, size),
            SyscallARM32.READLINKAT: self.file_ops.sys_readlinkat,
            SyscallARM32.ACCESS: lambda path, mode: self.file_ops.sys_faccessat(-100, path, mode, 0),
            SyscallARM32.FACCESSAT: self.file_ops.sys_faccessat,
            SyscallARM32.CHMOD: lambda path, mode: self.file_ops.sys_fchmodat(-100, path, mode, 0),
            SyscallARM32.FCHMOD: self.file_ops.sys_fchmod,
            SyscallARM32.FCHMODAT: self.file_ops.sys_fchmodat,
            SyscallARM32.CHOWN: lambda path, o, g: self.file_ops.sys_fchownat(-100, path, o, g, 0),
            SyscallARM32.FCHOWN: self.file_ops.sys_fchown,
            SyscallARM32.FCHOWNAT: self.file_ops.sys_fchownat,
            SyscallARM32.TRUNCATE: self.file_ops.sys_truncate,
            SyscallARM32.FTRUNCATE: self.file_ops.sys_ftruncate,
            SyscallARM32.UMASK: self.file_ops.sys_umask,
            SyscallARM32.DUP: self.file_ops.sys_dup,
            SyscallARM32.DUP2: lambda old, new: self.file_ops.sys_dup3(old, new, 0),
            SyscallARM32.DUP3: self.file_ops.sys_dup3,
            SyscallARM32.PIPE: lambda fds: self.file_ops.sys_pipe2(fds, 0),
            SyscallARM32.PIPE2: self.file_ops.sys_pipe2,
            SyscallARM32.FCNTL: self.file_ops.sys_fcntl,
            SyscallARM32.FCNTL64: self.file_ops.sys_fcntl,
            SyscallARM32.IOCTL: self.file_ops.sys_ioctl,
            SyscallARM32.FLOCK: self.file_ops.sys_flock,
            SyscallARM32.SYNC: self.file_ops.sys_sync,
            SyscallARM32.FSYNC: self.file_ops.sys_fsync,
            SyscallARM32.FDATASYNC: self.file_ops.sys_fdatasync,
            SyscallARM32.SYNCFS: self.file_ops.sys_syncfs,

            # Memory operations
            SyscallARM32.MMAP: self.memory_ops.sys_mmap,
            SyscallARM32.MMAP2: self.memory_ops.sys_mmap2,
            SyscallARM32.MUNMAP: self.memory_ops.sys_munmap,
            SyscallARM32.MPROTECT: self.memory_ops.sys_mprotect,
            SyscallARM32.MREMAP: self.memory_ops.sys_mremap,
            SyscallARM32.BRK: self.memory_ops.sys_brk,
            SyscallARM32.MLOCK: self.memory_ops.sys_mlock,
            SyscallARM32.MLOCK2: self.memory_ops.sys_mlock2,
            SyscallARM32.MUNLOCK: self.memory_ops.sys_munlock,
            SyscallARM32.MLOCKALL: self.memory_ops.sys_mlockall,
            SyscallARM32.MUNLOCKALL: self.memory_ops.sys_munlockall,
            SyscallARM32.MADVISE: self.memory_ops.sys_madvise,
            SyscallARM32.MINCORE: self.memory_ops.sys_mincore,
            SyscallARM32.MSYNC: self.memory_ops.sys_msync,
            SyscallARM32.MEMFD_CREATE: self.memory_ops.sys_memfd_create,
            SyscallARM32.PROCESS_VM_READV: self.memory_ops.sys_process_vm_readv,
            SyscallARM32.PROCESS_VM_WRITEV: self.memory_ops.sys_process_vm_writev,

            # Process operations
            SyscallARM32.GETPID: self.process_ops.sys_getpid,
            SyscallARM32.GETPPID: self.process_ops.sys_getppid,
            SyscallARM32.GETTID: self.process_ops.sys_gettid,
            SyscallARM32.GETPGID: self.process_ops.sys_getpgid,
            SyscallARM32.SETPGID: self.process_ops.sys_setpgid,
            SyscallARM32.GETPGRP: self.process_ops.sys_getpgrp,
            SyscallARM32.GETSID: self.process_ops.sys_getsid,
            SyscallARM32.SETSID: self.process_ops.sys_setsid,
            SyscallARM32.GETUID: self.process_ops.sys_getuid,
            SyscallARM32.GETUID32: self.process_ops.sys_getuid32,
            SyscallARM32.GETEUID: self.process_ops.sys_geteuid,
            SyscallARM32.GETEUID32: self.process_ops.sys_geteuid32,
            SyscallARM32.GETGID: self.process_ops.sys_getgid,
            SyscallARM32.GETGID32: self.process_ops.sys_getgid32,
            SyscallARM32.GETEGID: self.process_ops.sys_getegid,
            SyscallARM32.GETEGID32: self.process_ops.sys_getegid32,
            SyscallARM32.SETUID: self.process_ops.sys_setuid,
            SyscallARM32.SETUID32: self.process_ops.sys_setuid,
            SyscallARM32.SETGID: self.process_ops.sys_setgid,
            SyscallARM32.SETGID32: self.process_ops.sys_setgid,
            SyscallARM32.SETREUID: self.process_ops.sys_setreuid,
            SyscallARM32.SETREUID32: self.process_ops.sys_setreuid,
            SyscallARM32.SETREGID: self.process_ops.sys_setregid,
            SyscallARM32.SETREGID32: self.process_ops.sys_setregid,
            SyscallARM32.SETRESUID: self.process_ops.sys_setresuid,
            SyscallARM32.SETRESUID32: self.process_ops.sys_setresuid,
            SyscallARM32.GETRESUID: self.process_ops.sys_getresuid,
            SyscallARM32.GETRESUID32: self.process_ops.sys_getresuid,
            SyscallARM32.SETRESGID: self.process_ops.sys_setresgid,
            SyscallARM32.SETRESGID32: self.process_ops.sys_setresgid,
            SyscallARM32.GETRESGID: self.process_ops.sys_getresgid,
            SyscallARM32.GETRESGID32: self.process_ops.sys_getresgid,
            SyscallARM32.SETFSUID: self.process_ops.sys_setfsuid,
            SyscallARM32.SETFSUID32: self.process_ops.sys_setfsuid,
            SyscallARM32.SETFSGID: self.process_ops.sys_setfsgid,
            SyscallARM32.SETFSGID32: self.process_ops.sys_setfsgid,
            SyscallARM32.GETGROUPS: self.process_ops.sys_getgroups,
            SyscallARM32.GETGROUPS32: self.process_ops.sys_getgroups,
            SyscallARM32.SETGROUPS: self.process_ops.sys_setgroups,
            SyscallARM32.SETGROUPS32: self.process_ops.sys_setgroups,
            SyscallARM32.SET_TID_ADDRESS: self.process_ops.sys_set_tid_address,
            SyscallARM32.SET_ROBUST_LIST: self.process_ops.sys_set_robust_list,
            SyscallARM32.GET_ROBUST_LIST: self.process_ops.sys_get_robust_list,
            SyscallARM32.CLONE: self.process_ops.sys_clone,
            SyscallARM32.FUTEX: self.process_ops.sys_futex,
            SyscallARM32.PRCTL: self.process_ops.sys_prctl,
            SyscallARM32.SECCOMP: self.process_ops.sys_seccomp,
            SyscallARM32.EXIT: self.process_ops.sys_exit,
            SyscallARM32.EXIT_GROUP: self.process_ops.sys_exit_group,
            SyscallARM32.UNAME: self.process_ops.sys_uname,
            SyscallARM32.SYSINFO: self.process_ops.sys_sysinfo,
            SyscallARM32.GETCPU: self.process_ops.sys_getcpu,
            SyscallARM32.GETRLIMIT: self.process_ops.sys_getrlimit,
            SyscallARM32.UGETRLIMIT: self.process_ops.sys_getrlimit,
            SyscallARM32.SETRLIMIT: self.process_ops.sys_setrlimit,
            SyscallARM32.PRLIMIT64: self.process_ops.sys_prlimit64,
            SyscallARM32.GETRUSAGE: self.process_ops.sys_getrusage,
            SyscallARM32.TIMES: self.process_ops.sys_times,
            SyscallARM32.SCHED_YIELD: self.process_ops.sys_sched_yield,
            SyscallARM32.SCHED_GETAFFINITY: self.process_ops.sys_sched_getaffinity,
            SyscallARM32.SCHED_SETAFFINITY: self.process_ops.sys_sched_setaffinity,
            SyscallARM32.SCHED_GETSCHEDULER: self.process_ops.sys_sched_getscheduler,
            SyscallARM32.SCHED_SETSCHEDULER: self.process_ops.sys_sched_setscheduler,
            SyscallARM32.SCHED_GETPARAM: self.process_ops.sys_sched_getparam,
            SyscallARM32.SCHED_SETPARAM: self.process_ops.sys_sched_setparam,
            SyscallARM32.SCHED_GET_PRIORITY_MAX: self.process_ops.sys_sched_get_priority_max,
            SyscallARM32.SCHED_GET_PRIORITY_MIN: self.process_ops.sys_sched_get_priority_min,
            SyscallARM32.SCHED_RR_GET_INTERVAL: self.process_ops.sys_sched_rr_get_interval,
            SyscallARM32.CAPGET: self.process_ops.sys_capget,
            SyscallARM32.CAPSET: self.process_ops.sys_capset,
            SyscallARM32.GETRANDOM: self.process_ops.sys_getrandom,
            SyscallARM32.PERSONALITY: self.process_ops.sys_personality,

            # Network operations
            SyscallARM32.SOCKET: self.network_ops.sys_socket,
            SyscallARM32.SOCKETPAIR: self.network_ops.sys_socketpair,
            SyscallARM32.BIND: self.network_ops.sys_bind,
            SyscallARM32.LISTEN: self.network_ops.sys_listen,
            SyscallARM32.ACCEPT: self.network_ops.sys_accept,
            SyscallARM32.ACCEPT4: self.network_ops.sys_accept4,
            SyscallARM32.CONNECT: self.network_ops.sys_connect,
            SyscallARM32.SHUTDOWN: self.network_ops.sys_shutdown,
            SyscallARM32.GETSOCKNAME: self.network_ops.sys_getsockname,
            SyscallARM32.GETPEERNAME: self.network_ops.sys_getpeername,
            SyscallARM32.SETSOCKOPT: self.network_ops.sys_setsockopt,
            SyscallARM32.GETSOCKOPT: self.network_ops.sys_getsockopt,
            SyscallARM32.SEND: lambda fd, buf, len, flags: self.network_ops.sys_sendto(fd, buf, len, flags, 0, 0),
            SyscallARM32.SENDTO: self.network_ops.sys_sendto,
            SyscallARM32.RECV: lambda fd, buf, len, flags: self.network_ops.sys_recvfrom(fd, buf, len, flags, 0, 0),
            SyscallARM32.RECVFROM: self.network_ops.sys_recvfrom,
            SyscallARM32.SENDMSG: self.network_ops.sys_sendmsg,
            SyscallARM32.RECVMSG: self.network_ops.sys_recvmsg,
            SyscallARM32.SENDMMSG: self.network_ops.sys_sendmmsg,
            SyscallARM32.RECVMMSG: self.network_ops.sys_recvmmsg,
            SyscallARM32.EPOLL_CREATE: self.network_ops.sys_epoll_create,
            SyscallARM32.EPOLL_CREATE1: self.network_ops.sys_epoll_create1,
            SyscallARM32.EPOLL_CTL: self.network_ops.sys_epoll_ctl,
            SyscallARM32.EPOLL_WAIT: lambda epfd, events, max, timeout: self.network_ops.sys_epoll_pwait(epfd, events, max, timeout, 0),
            SyscallARM32.EPOLL_PWAIT: self.network_ops.sys_epoll_pwait,
            SyscallARM32.SELECT: self.network_ops.sys_select,
            SyscallARM32.PSELECT6: self.network_ops.sys_pselect6,
            SyscallARM32.POLL: self.network_ops.sys_poll,
            SyscallARM32.PPOLL: self.network_ops.sys_ppoll,
            SyscallARM32.EVENTFD: self.network_ops.sys_eventfd,
            SyscallARM32.EVENTFD2: self.network_ops.sys_eventfd2,
            SyscallARM32.TIMERFD_CREATE: self.network_ops.sys_timerfd_create,
            SyscallARM32.TIMERFD_SETTIME: self.network_ops.sys_timerfd_settime,
            SyscallARM32.TIMERFD_GETTIME: self.network_ops.sys_timerfd_gettime,
            SyscallARM32.SIGNALFD: self.network_ops.sys_signalfd,
            SyscallARM32.SIGNALFD4: self.network_ops.sys_signalfd4,
            SyscallARM32.INOTIFY_INIT: self.network_ops.sys_inotify_init,
            SyscallARM32.INOTIFY_INIT1: self.network_ops.sys_inotify_init1,
            SyscallARM32.INOTIFY_ADD_WATCH: self.network_ops.sys_inotify_add_watch,
            SyscallARM32.INOTIFY_RM_WATCH: self.network_ops.sys_inotify_rm_watch,

            # Time operations
            SyscallARM32.CLOCK_GETTIME: self.time_ops.sys_clock_gettime,
            SyscallARM32.CLOCK_SETTIME: self.time_ops.sys_clock_settime,
            SyscallARM32.CLOCK_GETRES: self.time_ops.sys_clock_getres,
            SyscallARM32.CLOCK_NANOSLEEP: self.time_ops.sys_clock_nanosleep,
            SyscallARM32.GETTIMEOFDAY: self.time_ops.sys_gettimeofday,
            SyscallARM32.SETTIMEOFDAY: self.time_ops.sys_settimeofday,
            SyscallARM32.TIME: self.time_ops.sys_time,
            SyscallARM32.NANOSLEEP: self.time_ops.sys_nanosleep,
            SyscallARM32.GETITIMER: self.time_ops.sys_getitimer,
            SyscallARM32.SETITIMER: self.time_ops.sys_setitimer,
            SyscallARM32.TIMER_CREATE: self.time_ops.sys_timer_create,
            SyscallARM32.TIMER_SETTIME: self.time_ops.sys_timer_settime,
            SyscallARM32.TIMER_GETTIME: self.time_ops.sys_timer_gettime,
            SyscallARM32.TIMER_GETOVERRUN: self.time_ops.sys_timer_getoverrun,
            SyscallARM32.TIMER_DELETE: self.time_ops.sys_timer_delete,
            SyscallARM32.ALARM: self.time_ops.sys_alarm,
            SyscallARM32.UTIME: self.time_ops.sys_utime,
            SyscallARM32.UTIMES: self.time_ops.sys_utimes,
            SyscallARM32.FUTIMESAT: self.time_ops.sys_futimesat,
            SyscallARM32.UTIMENSAT: self.time_ops.sys_utimensat,
            SyscallARM32.ADJTIMEX: self.time_ops.sys_adjtimex,
            SyscallARM32.CLOCK_ADJTIME: self.time_ops.sys_clock_adjtime,

            # Signal operations
            SyscallARM32.SIGACTION: self.signal_ops.sys_sigaction,
            SyscallARM32.RT_SIGACTION: self.signal_ops.sys_rt_sigaction,
            SyscallARM32.SIGPROCMASK: self.signal_ops.sys_sigprocmask,
            SyscallARM32.RT_SIGPROCMASK: self.signal_ops.sys_rt_sigprocmask,
            SyscallARM32.SIGPENDING: self.signal_ops.sys_sigpending,
            SyscallARM32.RT_SIGPENDING: self.signal_ops.sys_rt_sigpending,
            SyscallARM32.SIGSUSPEND: self.signal_ops.sys_sigsuspend,
            SyscallARM32.RT_SIGSUSPEND: self.signal_ops.sys_rt_sigsuspend,
            SyscallARM32.RT_SIGTIMEDWAIT: self.signal_ops.sys_rt_sigtimedwait,
            SyscallARM32.RT_SIGQUEUEINFO: self.signal_ops.sys_rt_sigqueueinfo,
            SyscallARM32.SIGRETURN: self.signal_ops.sys_sigreturn,
            SyscallARM32.RT_SIGRETURN: self.signal_ops.sys_rt_sigreturn,
            SyscallARM32.KILL: self.signal_ops.sys_kill,
            SyscallARM32.TKILL: self.signal_ops.sys_tkill,
            SyscallARM32.TGKILL: self.signal_ops.sys_tgkill,
            SyscallARM32.SIGALTSTACK: self.signal_ops.sys_sigaltstack,
            SyscallARM32.PAUSE: self.signal_ops.sys_pause,
        }

    # ==================== Public API ====================

    def register_handler(self, syscall_num: int, handler: Callable) -> None:
        """Register a custom syscall handler."""
        self._custom_handlers[syscall_num] = handler

    def unregister_handler(self, syscall_num: int) -> None:
        """Unregister a custom syscall handler."""
        self._custom_handlers.pop(syscall_num, None)

    def get_emulator_virtual_file(self, path: str) -> bytes | None:
        """Get virtual file from the main emulator."""
        return self._emulator.get_virtual_file(path)

    def get_syscall_name(self, num: int) -> str:
        """Get syscall name from number."""
        try:
            if self._arch == Architecture.ARM64:
                return SyscallARM64(num).name
            else:
                return SyscallARM32(num).name
        except ValueError:
            return f"UNKNOWN_{num}"

    def get_syscall_count(self) -> tuple[int, int]:
        """Get count of registered syscalls (ARM64, ARM32)."""
        return len(self._handlers64), len(self._handlers32)
