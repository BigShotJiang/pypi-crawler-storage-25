"""File-related syscall implementations."""

from __future__ import annotations

import logging
import os
import stat as stat_module
import struct
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .defs import AtFlags, Errno, FcntlCmd, OpenFlags, SeekWhence

if TYPE_CHECKING:
    from .handler import SyscallHandler

logger = logging.getLogger(__name__)


@dataclass
class FileDescriptor:
    """Represents an open file descriptor."""

    fd: int
    path: str
    flags: int
    mode: int
    position: int = 0
    data: bytes = b""
    is_directory: bool = False
    is_socket: bool = False
    is_pipe: bool = False
    pipe_buffer: bytes = b""
    socket_data: dict = field(default_factory=dict)


@dataclass
class DirEntry:
    """Directory entry for getdents."""

    inode: int
    name: str
    type: int  # DT_* type


class FileOperations:
    """File-related syscall implementations."""

    # Directory entry types
    DT_UNKNOWN = 0
    DT_FIFO = 1
    DT_CHR = 2
    DT_DIR = 4
    DT_BLK = 6
    DT_REG = 8
    DT_LNK = 10
    DT_SOCK = 12

    def __init__(self, handler: SyscallHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # File descriptor table
        self._fd_counter = 3
        self._fds: dict[int, FileDescriptor] = {
            0: FileDescriptor(0, "/dev/stdin", OpenFlags.O_RDONLY, 0),
            1: FileDescriptor(1, "/dev/stdout", OpenFlags.O_WRONLY, 0),
            2: FileDescriptor(2, "/dev/stderr", OpenFlags.O_WRONLY, 0),
        }

        # Virtual filesystem
        self._vfs: dict[str, bytes] = {}
        self._vfs_dirs: dict[str, list[DirEntry]] = {}

        # Directory read positions
        self._dir_positions: dict[int, int] = {}

        self._setup_default_vfs()

    def _setup_default_vfs(self) -> None:
        """Setup default virtual filesystem entries."""
        # /proc filesystem
        self._vfs["/proc/self/cmdline"] = b"app_process\x00"
        self._vfs["/proc/self/exe"] = b"/system/bin/app_process64"
        self._vfs["/proc/self/maps"] = self._generate_maps()
        self._vfs["/proc/self/status"] = self._generate_status()
        self._vfs["/proc/self/stat"] = self._generate_stat()
        self._vfs["/proc/self/auxv"] = self._generate_auxv()
        self._vfs["/proc/self/comm"] = b"main\n"
        self._vfs["/proc/self/fd/"] = b""  # Directory marker

        # /proc/meminfo
        self._vfs["/proc/meminfo"] = self._generate_meminfo()

        # /proc/cpuinfo
        self._vfs["/proc/cpuinfo"] = self._generate_cpuinfo()

        # /sys filesystem
        self._vfs["/sys/devices/system/cpu/online"] = b"0-7\n"
        self._vfs["/sys/devices/system/cpu/possible"] = b"0-7\n"

        # Android system files
        self._vfs["/system/build.prop"] = self._generate_build_prop()
        self._vfs["/system/etc/hosts"] = b"127.0.0.1 localhost\n"

        # Device files (minimal implementations)
        self._vfs["/dev/urandom"] = b""  # Special handling
        self._vfs["/dev/random"] = b""   # Special handling
        self._vfs["/dev/null"] = b""
        self._vfs["/dev/zero"] = b""     # Special handling

        # Setup directory entries
        self._vfs_dirs["/proc/self/fd"] = [
            DirEntry(1000, "0", self.DT_LNK),
            DirEntry(1001, "1", self.DT_LNK),
            DirEntry(1002, "2", self.DT_LNK),
        ]

    def alloc_fd(self) -> int:
        """Allocate a new file descriptor."""
        fd = self._fd_counter
        self._fd_counter += 1
        return fd

    def get_fd(self, fd: int) -> FileDescriptor | None:
        """Get file descriptor object."""
        return self._fds.get(fd)

    def add_fd(self, fd_obj: FileDescriptor) -> None:
        """Add a file descriptor."""
        self._fds[fd_obj.fd] = fd_obj

    def close_fd(self, fd: int) -> bool:
        """Close a file descriptor."""
        if fd in self._fds and fd > 2:
            del self._fds[fd]
            return True
        return fd <= 2  # stdin/out/err always "succeed"

    def add_virtual_file(self, path: str, content: bytes) -> None:
        """Add a file to the virtual filesystem."""
        self._vfs[path] = content

    def get_virtual_file(self, path: str) -> bytes | None:
        """Get content from virtual filesystem."""
        return self._vfs.get(path)

    def _resolve_path(self, dirfd: int, pathname: int, flags: int = 0) -> str | None:
        """Resolve a path from dirfd and pathname pointer."""
        if pathname == 0 and (flags & AtFlags.AT_EMPTY_PATH):
            # Use dirfd itself
            if dirfd in self._fds:
                return self._fds[dirfd].path
            return None

        path = self._emulator.memory.read_string(pathname)

        # Handle AT_FDCWD
        if dirfd == AtFlags.AT_FDCWD or path.startswith("/"):
            return path

        # Relative to dirfd
        if dirfd in self._fds:
            base = self._fds[dirfd].path
            return os.path.join(base, path)

        return path

    # ==================== File Open/Close ====================

    def sys_openat(self, dirfd: int, pathname: int, flags: int, mode: int = 0) -> int:
        """openat syscall - open file relative to directory fd."""
        path = self._resolve_path(dirfd, pathname)
        if path is None:
            return -Errno.EFAULT

        logger.debug(f"openat({dirfd}, {path!r}, {flags:#x}, {mode:#o})")

        # Check the emulator's user-supplied VFS FIRST so that an explicit
        # `emu.add_virtual_file(...)` can override the synthetic defaults
        # populated by `_setup_default_vfs` (e.g. /proc/self/status).
        vfile = self._handler.get_emulator_virtual_file(path)
        if vfile is not None:
            fd = self.alloc_fd()
            self._fds[fd] = FileDescriptor(fd, path, flags, mode, 0, vfile)
            return fd

        # Fall back to the built-in default VFS
        if path in self._vfs:
            fd = self.alloc_fd()
            is_dir = path.endswith("/") or path in self._vfs_dirs
            self._fds[fd] = FileDescriptor(
                fd, path, flags, mode, 0,
                self._vfs[path], is_directory=is_dir
            )
            if is_dir:
                self._dir_positions[fd] = 0
            return fd

        # Check if creating file
        if flags & OpenFlags.O_CREAT:
            fd = self.alloc_fd()
            self._fds[fd] = FileDescriptor(fd, path, flags, mode, 0, b"")
            self._vfs[path] = b""
            return fd

        logger.warning(f"openat: file not found: {path}")
        return -Errno.ENOENT

    def sys_open(self, pathname: int, flags: int, mode: int = 0) -> int:
        """open syscall (ARM32 compatibility)."""
        return self.sys_openat(AtFlags.AT_FDCWD, pathname, flags, mode)

    def sys_close(self, fd: int) -> int:
        """close syscall."""
        if self.close_fd(fd):
            return 0
        return -Errno.EBADF

    def sys_dup(self, oldfd: int) -> int:
        """dup syscall."""
        if oldfd not in self._fds:
            return -Errno.EBADF

        old = self._fds[oldfd]
        newfd = self.alloc_fd()
        self._fds[newfd] = FileDescriptor(
            newfd, old.path, old.flags, old.mode,
            old.position, old.data, old.is_directory
        )
        return newfd

    def sys_dup3(self, oldfd: int, newfd: int, flags: int) -> int:
        """dup3 syscall."""
        if oldfd not in self._fds:
            return -Errno.EBADF
        if oldfd == newfd:
            return -Errno.EINVAL

        old = self._fds[oldfd]
        if newfd in self._fds:
            self.close_fd(newfd)

        new_flags = old.flags
        if flags & OpenFlags.O_CLOEXEC:
            new_flags |= OpenFlags.O_CLOEXEC

        self._fds[newfd] = FileDescriptor(
            newfd, old.path, new_flags, old.mode,
            old.position, old.data, old.is_directory
        )
        return newfd

    def sys_pipe2(self, pipefd: int, flags: int) -> int:
        """pipe2 syscall."""
        read_fd = self.alloc_fd()
        write_fd = self.alloc_fd()

        # Create pipe endpoints
        self._fds[read_fd] = FileDescriptor(
            read_fd, f"[pipe:{read_fd}]", OpenFlags.O_RDONLY | flags, 0,
            is_pipe=True
        )
        self._fds[write_fd] = FileDescriptor(
            write_fd, f"[pipe:{read_fd}]", OpenFlags.O_WRONLY | flags, 0,
            is_pipe=True
        )

        # Write fds to userspace
        ptr_size = self._emulator.pointer_size
        if ptr_size == 8:
            self._emulator.memory.write_u32(pipefd, read_fd)
            self._emulator.memory.write_u32(pipefd + 4, write_fd)
        else:
            self._emulator.memory.write_u32(pipefd, read_fd)
            self._emulator.memory.write_u32(pipefd + 4, write_fd)

        return 0

    # ==================== Read/Write ====================

    def sys_read(self, fd: int, buf: int, count: int) -> int:
        """read syscall."""
        if fd not in self._fds:
            return -Errno.EBADF

        file = self._fds[fd]

        # Special device handling
        if file.path == "/dev/urandom" or file.path == "/dev/random":
            data = os.urandom(count)
            self._emulator.memory.write(buf, data)
            return count

        if file.path == "/dev/zero":
            data = b'\x00' * count
            self._emulator.memory.write(buf, data)
            return count

        if file.path == "/dev/null":
            return 0

        # Regular file read
        data = file.data[file.position:file.position + count]
        if data:
            self._emulator.memory.write(buf, data)
            file.position += len(data)

        return len(data)

    def sys_write(self, fd: int, buf: int, count: int) -> int:
        """write syscall."""
        if fd not in self._fds:
            return -Errno.EBADF

        data = self._emulator.memory.read(buf, count)
        file = self._fds[fd]

        if fd == 1:  # stdout
            print(data.decode('utf-8', errors='replace'), end='')
        elif fd == 2:  # stderr
            import sys
            print(data.decode('utf-8', errors='replace'), end='', file=sys.stderr)
        elif file.path == "/dev/null":
            pass
        else:
            # Write to virtual file
            if file.flags & OpenFlags.O_APPEND:
                file.data = file.data + data
                file.position = len(file.data)
            else:
                # Insert at position
                new_data = bytearray(file.data)
                new_data[file.position:file.position + count] = data
                file.data = bytes(new_data)
                file.position += count

        return count

    def sys_pread64(self, fd: int, buf: int, count: int, offset: int) -> int:
        """pread64 syscall - read at offset without changing position."""
        if fd not in self._fds:
            return -Errno.EBADF

        file = self._fds[fd]
        data = file.data[offset:offset + count]
        if data:
            self._emulator.memory.write(buf, data)

        return len(data)

    def sys_pwrite64(self, fd: int, buf: int, count: int, offset: int) -> int:
        """pwrite64 syscall - write at offset without changing position."""
        if fd not in self._fds:
            return -Errno.EBADF

        data = self._emulator.memory.read(buf, count)
        file = self._fds[fd]

        # Insert at offset
        new_data = bytearray(file.data)
        if offset + count > len(new_data):
            new_data.extend(b'\x00' * (offset + count - len(new_data)))
        new_data[offset:offset + count] = data
        file.data = bytes(new_data)

        return count

    def sys_readv(self, fd: int, iov: int, iovcnt: int) -> int:
        """readv syscall - scatter read."""
        if fd not in self._fds:
            return -Errno.EBADF

        total = 0
        ptr_size = self._emulator.pointer_size

        for i in range(iovcnt):
            iov_entry = iov + (i * ptr_size * 2)
            base = self._emulator.memory.read_ptr(iov_entry)
            length = self._emulator.memory.read_ptr(iov_entry + ptr_size)

            if length > 0:
                read_bytes = self.sys_read(fd, base, length)
                if read_bytes < 0:
                    return read_bytes if total == 0 else total
                total += read_bytes
                if read_bytes < length:
                    break

        return total

    def sys_writev(self, fd: int, iov: int, iovcnt: int) -> int:
        """writev syscall - gather write."""
        if fd not in self._fds:
            return -Errno.EBADF

        total = 0
        ptr_size = self._emulator.pointer_size

        for i in range(iovcnt):
            iov_entry = iov + (i * ptr_size * 2)
            base = self._emulator.memory.read_ptr(iov_entry)
            length = self._emulator.memory.read_ptr(iov_entry + ptr_size)

            if length > 0:
                written = self.sys_write(fd, base, length)
                if written < 0:
                    return written if total == 0 else total
                total += written

        return total

    # ==================== Seek/Position ====================

    def sys_lseek(self, fd: int, offset: int, whence: int) -> int:
        """lseek syscall."""
        if fd not in self._fds:
            return -Errno.EBADF

        file = self._fds[fd]

        if file.is_pipe:
            return -Errno.ESPIPE

        if whence == SeekWhence.SEEK_SET:
            file.position = offset
        elif whence == SeekWhence.SEEK_CUR:
            file.position += offset
        elif whence == SeekWhence.SEEK_END:
            file.position = len(file.data) + offset
        else:
            return -Errno.EINVAL

        if file.position < 0:
            file.position = 0

        return file.position

    def sys_llseek(self, fd: int, offset_high: int, offset_low: int,
                   result: int, whence: int) -> int:
        """_llseek syscall (ARM32)."""
        offset = (offset_high << 32) | offset_low
        new_pos = self.sys_lseek(fd, offset, whence)

        if new_pos < 0:
            return new_pos

        self._emulator.memory.write_u64(result, new_pos)
        return 0

    # ==================== File Info ====================

    def sys_fstat(self, fd: int, statbuf: int) -> int:
        """fstat syscall."""
        if fd not in self._fds:
            return -Errno.EBADF

        file = self._fds[fd]
        return self._fill_stat(statbuf, file.path, file.data, file.is_directory)

    def sys_newfstatat(self, dirfd: int, pathname: int, statbuf: int, flags: int) -> int:
        """newfstatat syscall."""
        path = self._resolve_path(dirfd, pathname, flags)
        if path is None:
            return -Errno.EFAULT

        # Check VFS
        if path in self._vfs:
            return self._fill_stat(statbuf, path, self._vfs[path], path in self._vfs_dirs)

        vfile = self._handler.get_emulator_virtual_file(path)
        if vfile is not None:
            return self._fill_stat(statbuf, path, vfile, False)

        return -Errno.ENOENT

    def _fill_stat(self, statbuf: int, path: str, data: bytes, is_dir: bool) -> int:
        """Fill stat structure."""
        mem = self._emulator.memory
        is_arm64 = self._emulator.pointer_size == 8

        # Determine mode
        mode = stat_module.S_IFDIR | 0o755 if is_dir else stat_module.S_IFREG | 0o644

        # Device files
        if path.startswith("/dev/"):
            mode = stat_module.S_IFCHR | 0o666

        size = len(data)
        inode = hash(path) & 0xFFFFFFFF

        if is_arm64:
            # ARM64 stat structure
            mem.write_u64(statbuf + 0, 0)          # st_dev
            mem.write_u64(statbuf + 8, inode)      # st_ino
            mem.write_u32(statbuf + 16, mode)      # st_mode
            mem.write_u32(statbuf + 20, 1)         # st_nlink
            mem.write_u32(statbuf + 24, 0)         # st_uid
            mem.write_u32(statbuf + 28, 0)         # st_gid
            mem.write_u64(statbuf + 32, 0)         # st_rdev
            mem.write_u64(statbuf + 40, 0)         # __pad1
            mem.write_u64(statbuf + 48, size)      # st_size
            mem.write_u32(statbuf + 56, 4096)      # st_blksize
            mem.write_u32(statbuf + 60, 0)         # __pad2
            mem.write_u64(statbuf + 64, (size + 511) // 512)  # st_blocks
            # st_atime, st_mtime, st_ctime (each 16 bytes: sec + nsec)
            import time
            now = int(time.time())
            mem.write_u64(statbuf + 72, now)       # st_atime
            mem.write_u64(statbuf + 80, 0)         # st_atime_nsec
            mem.write_u64(statbuf + 88, now)       # st_mtime
            mem.write_u64(statbuf + 96, 0)         # st_mtime_nsec
            mem.write_u64(statbuf + 104, now)      # st_ctime
            mem.write_u64(statbuf + 112, 0)        # st_ctime_nsec
        else:
            # ARM32 stat64 structure
            mem.write_u64(statbuf + 0, 0)          # st_dev
            mem.write_u32(statbuf + 8, 0)          # __pad1
            mem.write_u32(statbuf + 12, inode)     # __st_ino
            mem.write_u32(statbuf + 16, mode)      # st_mode
            mem.write_u32(statbuf + 20, 1)         # st_nlink
            mem.write_u32(statbuf + 24, 0)         # st_uid
            mem.write_u32(statbuf + 28, 0)         # st_gid
            mem.write_u64(statbuf + 32, 0)         # st_rdev
            mem.write_u64(statbuf + 44, size)      # st_size
            mem.write_u32(statbuf + 52, 4096)      # st_blksize
            mem.write_u64(statbuf + 56, (size + 511) // 512)  # st_blocks
            # Times
            import time
            now = int(time.time())
            mem.write_u32(statbuf + 64, now)       # st_atime
            mem.write_u32(statbuf + 72, now)       # st_mtime
            mem.write_u32(statbuf + 80, now)       # st_ctime
            mem.write_u64(statbuf + 88, inode)     # st_ino (64-bit)

        return 0

    def sys_statfs(self, path_ptr: int, buf: int) -> int:
        """statfs syscall."""
        return self._fill_statfs(buf)

    def sys_fstatfs(self, fd: int, buf: int) -> int:
        """fstatfs syscall."""
        if fd not in self._fds:
            return -Errno.EBADF
        return self._fill_statfs(buf)

    def _fill_statfs(self, buf: int) -> int:
        """Fill statfs structure."""
        mem = self._emulator.memory
        is_arm64 = self._emulator.pointer_size == 8

        if is_arm64:
            mem.write_u64(buf + 0, 0xEF53)         # f_type (EXT4)
            mem.write_u64(buf + 8, 4096)           # f_bsize
            mem.write_u64(buf + 16, 1000000)       # f_blocks
            mem.write_u64(buf + 24, 500000)        # f_bfree
            mem.write_u64(buf + 32, 500000)        # f_bavail
            mem.write_u64(buf + 40, 1000000)       # f_files
            mem.write_u64(buf + 48, 500000)        # f_ffree
            mem.write_u64(buf + 56, 0)             # f_fsid
            mem.write_u64(buf + 64, 255)           # f_namelen
            mem.write_u64(buf + 72, 4096)          # f_frsize
            mem.write_u64(buf + 80, 0)             # f_flags
        else:
            mem.write_u32(buf + 0, 0xEF53)
            mem.write_u32(buf + 4, 4096)
            mem.write_u32(buf + 8, 1000000)
            mem.write_u32(buf + 12, 500000)
            mem.write_u32(buf + 16, 500000)
            mem.write_u32(buf + 20, 1000000)
            mem.write_u32(buf + 24, 500000)

        return 0

    # ==================== Directory Operations ====================

    def sys_getdents64(self, fd: int, dirp: int, count: int) -> int:
        """getdents64 syscall."""
        if fd not in self._fds:
            return -Errno.EBADF

        file = self._fds[fd]
        if not file.is_directory:
            return -Errno.ENOTDIR

        # Get directory entries
        entries = self._vfs_dirs.get(file.path.rstrip("/"), [])
        pos = self._dir_positions.get(fd, 0)

        if pos >= len(entries):
            return 0  # End of directory

        written = 0
        while pos < len(entries) and written < count:
            entry = entries[pos]

            # Calculate entry size (aligned to 8 bytes)
            name_bytes = entry.name.encode() + b'\x00'
            entry_size = 8 + 8 + 2 + 1 + len(name_bytes)
            entry_size = (entry_size + 7) & ~7  # Align to 8

            if written + entry_size > count:
                break

            # Write dirent64 structure
            mem = self._emulator.memory
            offset = dirp + written
            mem.write_u64(offset, entry.inode)              # d_ino
            mem.write_u64(offset + 8, pos + 1)              # d_off
            mem.write_u16(offset + 16, entry_size)          # d_reclen
            mem.write_u8(offset + 18, entry.type)           # d_type
            mem.write(offset + 19, name_bytes)              # d_name

            written += entry_size
            pos += 1

        self._dir_positions[fd] = pos
        return written

    def sys_getcwd(self, buf: int, size: int) -> int:
        """getcwd syscall."""
        cwd = b"/data/local/tmp\x00"
        if len(cwd) > size:
            return -Errno.ERANGE

        self._emulator.memory.write(buf, cwd)
        return buf

    def sys_chdir(self, path_ptr: int) -> int:
        """chdir syscall."""
        path = self._emulator.memory.read_string(path_ptr)
        logger.debug(f"chdir({path!r})")
        # Always succeed in emulation
        return 0

    def sys_fchdir(self, fd: int) -> int:
        """fchdir syscall."""
        if fd not in self._fds:
            return -Errno.EBADF
        return 0

    def sys_mkdirat(self, dirfd: int, pathname: int, mode: int) -> int:
        """mkdirat syscall."""
        path = self._resolve_path(dirfd, pathname)
        if path is None:
            return -Errno.EFAULT

        logger.debug(f"mkdirat({path!r}, {mode:#o})")
        self._vfs[path + "/"] = b""
        self._vfs_dirs[path] = []
        return 0

    def sys_unlinkat(self, dirfd: int, pathname: int, flags: int) -> int:
        """unlinkat syscall."""
        path = self._resolve_path(dirfd, pathname)
        if path is None:
            return -Errno.EFAULT

        if flags & AtFlags.AT_REMOVEDIR:
            if path in self._vfs_dirs:
                del self._vfs_dirs[path]

        if path in self._vfs:
            del self._vfs[path]

        return 0

    def sys_renameat(self, olddirfd: int, oldpath: int,
                     newdirfd: int, newpath: int) -> int:
        """renameat syscall."""
        old = self._resolve_path(olddirfd, oldpath)
        new = self._resolve_path(newdirfd, newpath)

        if old is None or new is None:
            return -Errno.EFAULT

        if old in self._vfs:
            self._vfs[new] = self._vfs[old]
            del self._vfs[old]

        return 0

    def sys_linkat(self, olddirfd: int, oldpath: int,
                   newdirfd: int, newpath: int, flags: int) -> int:
        """linkat syscall."""
        old = self._resolve_path(olddirfd, oldpath)
        new = self._resolve_path(newdirfd, newpath)

        if old is None or new is None:
            return -Errno.EFAULT

        if old in self._vfs:
            self._vfs[new] = self._vfs[old]

        return 0

    def sys_symlinkat(self, target: int, newdirfd: int, linkpath: int) -> int:
        """symlinkat syscall."""
        target_str = self._emulator.memory.read_string(target)
        link = self._resolve_path(newdirfd, linkpath)

        if link is None:
            return -Errno.EFAULT

        # Store symlink as file content
        self._vfs[link] = target_str.encode()
        return 0

    def sys_readlinkat(self, dirfd: int, pathname: int, buf: int, bufsiz: int) -> int:
        """readlinkat syscall."""
        path = self._resolve_path(dirfd, pathname)
        if path is None:
            return -Errno.EFAULT

        # Handle /proc/self/exe
        if path == "/proc/self/exe":
            target = b"/system/bin/app_process64"
        elif path in self._vfs:
            target = self._vfs[path]
        else:
            return -Errno.ENOENT

        write_len = min(len(target), bufsiz)
        self._emulator.memory.write(buf, target[:write_len])
        return write_len

    # ==================== File Control ====================

    def sys_fcntl(self, fd: int, cmd: int, arg: int = 0) -> int:
        """fcntl syscall."""
        if fd not in self._fds:
            return -Errno.EBADF

        file = self._fds[fd]

        if cmd == FcntlCmd.F_DUPFD:
            return self.sys_dup(fd)
        elif cmd == FcntlCmd.F_DUPFD_CLOEXEC:
            newfd = self.sys_dup(fd)
            if newfd >= 0:
                self._fds[newfd].flags |= OpenFlags.O_CLOEXEC
            return newfd
        elif cmd == FcntlCmd.F_GETFD:
            return 1 if (file.flags & OpenFlags.O_CLOEXEC) else 0
        elif cmd == FcntlCmd.F_SETFD:
            if arg & 1:
                file.flags |= OpenFlags.O_CLOEXEC
            else:
                file.flags &= ~OpenFlags.O_CLOEXEC
            return 0
        elif cmd == FcntlCmd.F_GETFL:
            return file.flags & ~OpenFlags.O_CLOEXEC
        elif cmd == FcntlCmd.F_SETFL:
            # Only certain flags can be changed
            changeable = OpenFlags.O_APPEND | OpenFlags.O_NONBLOCK
            file.flags = (file.flags & ~changeable) | (arg & changeable)
            return 0
        elif cmd == FcntlCmd.F_GETLK:
            # No locks
            return 0
        elif cmd in (FcntlCmd.F_SETLK, FcntlCmd.F_SETLKW):
            # Accept all locks
            return 0

        logger.debug(f"fcntl: unknown command {cmd}")
        return 0

    def sys_ioctl(self, fd: int, request: int, arg: int) -> int:
        """ioctl syscall."""
        logger.debug(f"ioctl({fd}, {request:#x}, {arg:#x})")

        from .defs import IoctlRequest

        if request == IoctlRequest.TIOCGWINSZ:
            # Return terminal size
            mem = self._emulator.memory
            mem.write_u16(arg, 24)      # rows
            mem.write_u16(arg + 2, 80)  # cols
            mem.write_u16(arg + 4, 0)   # xpixel
            mem.write_u16(arg + 6, 0)   # ypixel
            return 0
        elif request == IoctlRequest.FIONREAD:
            # Bytes available
            if fd in self._fds:
                file = self._fds[fd]
                available = len(file.data) - file.position
                self._emulator.memory.write_u32(arg, available)
            return 0
        elif request == IoctlRequest.FIONBIO:
            # Set non-blocking
            if fd in self._fds:
                if self._emulator.memory.read_u32(arg):
                    self._fds[fd].flags |= OpenFlags.O_NONBLOCK
                else:
                    self._fds[fd].flags &= ~OpenFlags.O_NONBLOCK
            return 0

        return 0

    def sys_flock(self, fd: int, operation: int) -> int:
        """flock syscall."""
        if fd not in self._fds:
            return -Errno.EBADF
        return 0  # Always succeed

    # ==================== File Attributes ====================

    def sys_faccessat(self, dirfd: int, pathname: int, mode: int, flags: int) -> int:
        """faccessat syscall."""
        path = self._resolve_path(dirfd, pathname)
        if path is None:
            return -Errno.EFAULT

        if path in self._vfs:
            return 0

        vfile = self._handler.get_emulator_virtual_file(path)
        if vfile is not None:
            return 0

        return -Errno.ENOENT

    def sys_fchmod(self, fd: int, mode: int) -> int:
        """fchmod syscall."""
        if fd not in self._fds:
            return -Errno.EBADF
        self._fds[fd].mode = mode
        return 0

    def sys_fchmodat(self, dirfd: int, pathname: int, mode: int, flags: int) -> int:
        """fchmodat syscall."""
        path = self._resolve_path(dirfd, pathname)
        if path is None:
            return -Errno.EFAULT
        return 0  # Accept any chmod in emulation

    def sys_fchown(self, fd: int, owner: int, group: int) -> int:
        """fchown syscall."""
        if fd not in self._fds:
            return -Errno.EBADF
        return 0

    def sys_fchownat(self, dirfd: int, pathname: int, owner: int,
                     group: int, flags: int) -> int:
        """fchownat syscall."""
        return 0  # Accept any chown

    def sys_truncate(self, path_ptr: int, length: int) -> int:
        """truncate syscall."""
        path = self._emulator.memory.read_string(path_ptr)
        if path in self._vfs:
            data = self._vfs[path]
            if length < len(data):
                self._vfs[path] = data[:length]
            else:
                self._vfs[path] = data + b'\x00' * (length - len(data))
        return 0

    def sys_ftruncate(self, fd: int, length: int) -> int:
        """ftruncate syscall."""
        if fd not in self._fds:
            return -Errno.EBADF

        file = self._fds[fd]
        if length < len(file.data):
            file.data = file.data[:length]
        else:
            file.data = file.data + b'\x00' * (length - len(file.data))

        return 0

    def sys_umask(self, mask: int) -> int:
        """umask syscall."""
        return 0o022  # Return old mask

    # ==================== Sync ====================

    def sys_sync(self) -> int:
        """sync syscall."""
        return 0

    def sys_fsync(self, fd: int) -> int:
        """fsync syscall."""
        if fd not in self._fds:
            return -Errno.EBADF
        return 0

    def sys_fdatasync(self, fd: int) -> int:
        """fdatasync syscall."""
        return self.sys_fsync(fd)

    def sys_syncfs(self, fd: int) -> int:
        """syncfs syscall."""
        if fd not in self._fds:
            return -Errno.EBADF
        return 0

    # ==================== Virtual File Generators ====================

    def _generate_maps(self) -> bytes:
        """Generate /proc/self/maps content."""
        lines = []
        for region in self._emulator.memory.get_regions():
            perms = ""
            perms += "r" if region.protection & 1 else "-"
            perms += "w" if region.protection & 2 else "-"
            perms += "x" if region.protection & 4 else "-"
            perms += "p"
            lines.append(f"{region.start:08x}-{region.end:08x} {perms} 00000000 00:00 0 {region.name}")
        return "\n".join(lines).encode() + b"\n"

    def _generate_status(self) -> bytes:
        """Generate /proc/self/status content."""
        return b"""Name:\tmain
State:\tR (running)
Tgid:\t1000
Pid:\t1000
PPid:\t1
TracerPid:\t0
Uid:\t10000\t10000\t10000\t10000
Gid:\t10000\t10000\t10000\t10000
FDSize:\t64
Groups:\t10000 3003 9997
VmPeak:\t  131072 kB
VmSize:\t  131072 kB
VmLck:\t       0 kB
VmHWM:\t   32768 kB
VmRSS:\t   32768 kB
Threads:\t1
SigQ:\t0/64000
SigPnd:\t0000000000000000
SigBlk:\t0000000000000000
SigIgn:\t0000000000000000
SigCgt:\t0000000000000000
CapInh:\t0000000000000000
CapPrm:\t0000000000000000
CapEff:\t0000000000000000
CapBnd:\t0000000000000000
Seccomp:\t0
"""

    def _generate_stat(self) -> bytes:
        """Generate /proc/self/stat content."""
        return b"1000 (main) R 1 1000 1000 0 -1 4194304 0 0 0 0 0 0 0 0 20 0 1 0 0 131072000 32768000 0 18446744073709551615 0 0 0 0 0 0 0 0 0 0 0 0 17 0 0 0 0 0 0\n"

    def _generate_auxv(self) -> bytes:
        """Generate /proc/self/auxv content."""
        # Minimal auxiliary vector
        auxv = []
        AT_NULL = 0
        AT_PAGESZ = 6
        AT_HWCAP = 16
        AT_CLKTCK = 17
        AT_RANDOM = 25

        is_arm64 = self._emulator.pointer_size == 8
        fmt = "<QQ" if is_arm64 else "<II"

        auxv.append(struct.pack(fmt, AT_PAGESZ, 4096))
        auxv.append(struct.pack(fmt, AT_CLKTCK, 100))
        auxv.append(struct.pack(fmt, AT_HWCAP, 0))
        auxv.append(struct.pack(fmt, AT_NULL, 0))

        return b"".join(auxv)

    def _generate_meminfo(self) -> bytes:
        """Generate /proc/meminfo content."""
        return b"""MemTotal:        4096000 kB
MemFree:         2048000 kB
MemAvailable:    3072000 kB
Buffers:          512000 kB
Cached:          1024000 kB
SwapTotal:       1024000 kB
SwapFree:        1024000 kB
"""

    def _generate_cpuinfo(self) -> bytes:
        """Generate /proc/cpuinfo content."""
        is_arm64 = self._emulator.pointer_size == 8
        if is_arm64:
            return b"""processor\t: 0
BogoMIPS\t: 48.00
Features\t: fp asimd evtstrm aes pmull sha1 sha2 crc32
CPU implementer\t: 0x41
CPU architecture: 8
CPU variant\t: 0x0
CPU part\t: 0xd03
CPU revision\t: 4

Hardware\t: Qualcomm Technologies, Inc MSM8998
"""
        else:
            return b"""processor\t: 0
BogoMIPS\t: 48.00
Features\t: swp half thumb fastmult vfp edsp neon vfpv3 tls vfpv4 idiva idivt
CPU implementer\t: 0x41
CPU architecture: 7
CPU variant\t: 0x0
CPU part\t: 0xc07
CPU revision\t: 4

Hardware\t: Qualcomm Technologies, Inc MSM8937
"""

    def _generate_build_prop(self) -> bytes:
        """Generate /system/build.prop content."""
        api_level = getattr(self._emulator, 'api_level', 30)
        return f"""ro.build.id=RQ3A.211001.001
ro.build.display.id=RQ3A.211001.001
ro.build.version.sdk={api_level}
ro.build.version.release=11
ro.build.version.security_patch=2021-10-05
ro.build.type=user
ro.build.user=android-build
ro.build.host=build.android.com
ro.product.manufacturer=Google
ro.product.model=Pixel 4
ro.product.brand=google
ro.product.name=flame
ro.product.device=flame
ro.product.cpu.abi=arm64-v8a
ro.product.cpu.abilist=arm64-v8a,armeabi-v7a,armeabi
ro.hardware=flame
ro.bootimage.build.fingerprint=google/flame/flame:11/RQ3A.211001.001/7641976:user/release-keys
""".encode()
