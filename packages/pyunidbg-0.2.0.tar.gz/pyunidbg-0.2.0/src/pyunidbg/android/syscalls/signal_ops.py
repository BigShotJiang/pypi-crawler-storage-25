"""Signal-related syscall implementations."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from .defs import Errno, Signal

if TYPE_CHECKING:
    from .handler import SyscallHandler

logger = logging.getLogger(__name__)


class SignalOperations:
    """Signal-related syscall implementations."""

    def __init__(self, handler: SyscallHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Signal handlers (signal number -> handler address)
        self._signal_handlers: dict[int, int] = {}

        # Signal mask
        self._signal_mask: int = 0

        # Pending signals
        self._pending_signals: set[int] = set()

        # Alternate signal stack
        self._alt_stack: tuple[int, int, int] = (0, 0, 0)  # ss_sp, ss_flags, ss_size

        # Signal queue for real-time signals
        self._signal_queue: list[tuple[int, dict]] = []

    # ==================== Signal Actions ====================

    def sys_rt_sigaction(self, signum: int, act: int, oldact: int,
                         sigsetsize: int) -> int:
        """rt_sigaction syscall."""
        mem = self._emulator.memory
        ptr_size = self._emulator.pointer_size

        # Save old action
        if oldact:
            old_handler = self._signal_handlers.get(signum, 0)
            if ptr_size == 8:
                mem.write_u64(oldact, old_handler)  # sa_handler
                mem.write_u64(oldact + 8, 0)        # sa_flags
                mem.write_u64(oldact + 16, 0)       # sa_restorer
                # sa_mask at offset 24
            else:
                mem.write_u32(oldact, old_handler)
                mem.write_u32(oldact + 4, 0)

        # Set new action
        if act:
            if ptr_size == 8:
                handler = mem.read_u64(act)
            else:
                handler = mem.read_u32(act)

            self._signal_handlers[signum] = handler
            logger.debug(f"rt_sigaction: signal {signum} -> handler {handler:#x}")

        return 0

    def sys_sigaction(self, signum: int, act: int, oldact: int) -> int:
        """sigaction syscall (ARM32)."""
        return self.sys_rt_sigaction(signum, act, oldact, 8)

    # ==================== Signal Mask ====================

    def sys_rt_sigprocmask(self, how: int, nset: int, oset: int,
                           sigsetsize: int) -> int:
        """rt_sigprocmask syscall."""
        mem = self._emulator.memory

        SIG_BLOCK = 0
        SIG_UNBLOCK = 1
        SIG_SETMASK = 2

        # Save old mask
        if oset:
            if self._emulator.pointer_size == 8:
                mem.write_u64(oset, self._signal_mask)
            else:
                mem.write_u32(oset, self._signal_mask & 0xFFFFFFFF)

        # Apply new mask
        if nset:
            if self._emulator.pointer_size == 8:
                new_mask = mem.read_u64(nset)
            else:
                new_mask = mem.read_u32(nset)

            if how == SIG_BLOCK:
                self._signal_mask |= new_mask
            elif how == SIG_UNBLOCK:
                self._signal_mask &= ~new_mask
            elif how == SIG_SETMASK:
                self._signal_mask = new_mask
            else:
                return -Errno.EINVAL

        return 0

    def sys_sigprocmask(self, how: int, nset: int, oset: int) -> int:
        """sigprocmask syscall."""
        return self.sys_rt_sigprocmask(how, nset, oset, 8)

    # ==================== Signal Pending ====================

    def sys_rt_sigpending(self, set_ptr: int, sigsetsize: int) -> int:
        """rt_sigpending syscall."""
        # Convert pending signals to bitmask
        pending = 0
        for sig in self._pending_signals:
            if sig < 64:
                pending |= (1 << sig)

        if self._emulator.pointer_size == 8:
            self._emulator.memory.write_u64(set_ptr, pending)
        else:
            self._emulator.memory.write_u32(set_ptr, pending & 0xFFFFFFFF)

        return 0

    def sys_sigpending(self, set_ptr: int) -> int:
        """sigpending syscall."""
        return self.sys_rt_sigpending(set_ptr, 8)

    # ==================== Signal Suspend ====================

    def sys_rt_sigsuspend(self, mask: int, sigsetsize: int) -> int:
        """rt_sigsuspend syscall."""
        # In emulation, just return EINTR
        return -Errno.EINTR

    def sys_sigsuspend(self, mask: int) -> int:
        """sigsuspend syscall."""
        return self.sys_rt_sigsuspend(mask, 8)

    def sys_pause(self) -> int:
        """pause syscall."""
        # In emulation, return immediately with EINTR
        return -Errno.EINTR

    # ==================== Signal Wait ====================

    def sys_rt_sigtimedwait(self, set_ptr: int, info: int,
                            timeout: int, sigsetsize: int) -> int:
        """rt_sigtimedwait syscall."""
        # No signals to wait for in emulation
        return -Errno.EAGAIN

    def sys_sigwaitinfo(self, set_ptr: int, info: int) -> int:
        """sigwaitinfo syscall."""
        return -Errno.EINTR

    # ==================== Signal Send ====================

    def sys_kill(self, pid: int, sig: int) -> int:
        """kill syscall."""
        logger.debug(f"kill({pid}, {sig})")

        if sig == 0:
            # Just checking if process exists
            return 0

        # In emulation, we can queue signals to ourselves
        if pid == 0 or pid == 1000 or pid == -1:  # self
            self._pending_signals.add(sig)

        return 0

    def sys_tkill(self, tid: int, sig: int) -> int:
        """tkill syscall."""
        return self.sys_kill(tid, sig)

    def sys_tgkill(self, tgid: int, tid: int, sig: int) -> int:
        """tgkill syscall."""
        return self.sys_kill(tid, sig)

    def sys_rt_sigqueueinfo(self, pid: int, sig: int, info: int) -> int:
        """rt_sigqueueinfo syscall."""
        return self.sys_kill(pid, sig)

    def sys_rt_tgsigqueueinfo(self, tgid: int, tid: int, sig: int, info: int) -> int:
        """rt_tgsigqueueinfo syscall."""
        return self.sys_kill(tid, sig)

    # ==================== Signal Return ====================

    def sys_rt_sigreturn(self) -> int:
        """rt_sigreturn syscall."""
        # This is called when returning from a signal handler
        # In emulation, we don't actually handle signals, so this is a no-op
        return 0

    def sys_sigreturn(self) -> int:
        """sigreturn syscall."""
        return self.sys_rt_sigreturn()

    # ==================== Alternate Signal Stack ====================

    def sys_sigaltstack(self, ss: int, old_ss: int) -> int:
        """sigaltstack syscall."""
        mem = self._emulator.memory
        ptr_size = self._emulator.pointer_size

        # Return old stack
        if old_ss:
            if ptr_size == 8:
                mem.write_u64(old_ss, self._alt_stack[0])       # ss_sp
                mem.write_u32(old_ss + 8, self._alt_stack[1])   # ss_flags
                mem.write_u64(old_ss + 16, self._alt_stack[2])  # ss_size
            else:
                mem.write_u32(old_ss, self._alt_stack[0])
                mem.write_u32(old_ss + 4, self._alt_stack[1])
                mem.write_u32(old_ss + 8, self._alt_stack[2])

        # Set new stack
        if ss:
            if ptr_size == 8:
                sp = mem.read_u64(ss)
                flags = mem.read_u32(ss + 8)
                size = mem.read_u64(ss + 16)
            else:
                sp = mem.read_u32(ss)
                flags = mem.read_u32(ss + 4)
                size = mem.read_u32(ss + 8)

            self._alt_stack = (sp, flags, size)

        return 0

    # ==================== Signal Utilities ====================

    def get_handler(self, signum: int) -> int:
        """Get the handler address for a signal."""
        return self._signal_handlers.get(signum, 0)

    def is_blocked(self, signum: int) -> bool:
        """Check if a signal is blocked."""
        if signum < 64:
            return bool(self._signal_mask & (1 << signum))
        return False

    def deliver_signal(self, signum: int) -> bool:
        """
        Attempt to deliver a pending signal.
        Returns True if a signal handler was invoked.
        """
        if signum not in self._pending_signals:
            return False

        if self.is_blocked(signum):
            return False

        handler = self._signal_handlers.get(signum, 0)

        # SIG_DFL = 0, SIG_IGN = 1
        if handler == 0:
            # Default action - depends on signal
            if signum in (Signal.SIGKILL, Signal.SIGTERM, Signal.SIGSEGV,
                         Signal.SIGABRT, Signal.SIGBUS, Signal.SIGFPE):
                logger.info(f"Signal {signum} - terminating")
                self._emulator.stop()
            self._pending_signals.discard(signum)
            return True

        if handler == 1:
            # Ignored
            self._pending_signals.discard(signum)
            return True

        # Custom handler - would need to call it
        # This is complex as it requires saving context, setting up stack frame, etc.
        logger.debug(f"Signal {signum} has handler at {handler:#x}")
        self._pending_signals.discard(signum)
        return False

    def raise_signal(self, signum: int) -> None:
        """Raise a signal to the emulated process."""
        self._pending_signals.add(signum)
