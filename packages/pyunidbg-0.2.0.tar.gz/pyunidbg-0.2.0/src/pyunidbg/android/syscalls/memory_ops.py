"""Memory-related syscall implementations."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from .defs import Errno, MmapFlags, MmapProt

if TYPE_CHECKING:
    from .handler import SyscallHandler

logger = logging.getLogger(__name__)


class MemoryOperations:
    """Memory-related syscall implementations."""

    def __init__(self, handler: SyscallHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Track brk address
        self._brk_addr = 0

        # mlock tracking
        self._mlocked_regions: list[tuple[int, int]] = []

    def _convert_prot(self, prot: int):
        """Convert mmap protection flags to internal format."""
        from pyunidbg.core.constants import MemoryProtection

        mem_prot = MemoryProtection.NONE
        if prot & MmapProt.PROT_READ:
            mem_prot |= MemoryProtection.READ
        if prot & MmapProt.PROT_WRITE:
            mem_prot |= MemoryProtection.WRITE
        if prot & MmapProt.PROT_EXEC:
            mem_prot |= MemoryProtection.EXEC
        return mem_prot

    # ==================== Memory Mapping ====================

    def sys_mmap(self, addr: int, length: int, prot: int, flags: int,
                 fd: int, offset: int) -> int:
        """mmap syscall."""
        logger.debug(f"mmap({addr:#x}, {length:#x}, {prot:#x}, {flags:#x}, {fd}, {offset:#x})")

        mem_prot = self._convert_prot(prot)

        try:
            if flags & MmapFlags.MAP_ANONYMOUS:
                # Anonymous mapping
                if addr == 0 or not (flags & MmapFlags.MAP_FIXED):
                    result = self._emulator.memory.allocate(length, mem_prot, "[mmap]")
                else:
                    self._emulator.memory.map(addr, length, mem_prot, "[mmap]")
                    result = addr

                # Zero-initialize anonymous mappings
                self._emulator.memory.write(result, b'\x00' * length)
            else:
                # File-backed mapping
                if addr == 0 or not (flags & MmapFlags.MAP_FIXED):
                    result = self._emulator.memory.allocate(length, mem_prot, "[mmap]")
                else:
                    self._emulator.memory.map(addr, length, mem_prot, "[mmap]")
                    result = addr

                # Read file data if fd is valid
                if fd >= 0:
                    file_ops = self._handler.file_ops
                    file = file_ops.get_fd(fd)
                    if file:
                        data = file.data[offset:offset + length]
                        if data:
                            self._emulator.memory.write(result, data)

            return result
        except Exception as e:
            logger.error(f"mmap failed: {e}")
            return -Errno.ENOMEM

    def sys_mmap2(self, addr: int, length: int, prot: int, flags: int,
                  fd: int, pgoffset: int) -> int:
        """mmap2 syscall (ARM32) - offset is in pages."""
        return self.sys_mmap(addr, length, prot, flags, fd, pgoffset * 4096)

    def sys_munmap(self, addr: int, length: int) -> int:
        """munmap syscall."""
        logger.debug(f"munmap({addr:#x}, {length:#x})")

        try:
            self._emulator.memory.unmap(addr, length)
            return 0
        except Exception as e:
            logger.debug(f"munmap failed: {e}")
            return -Errno.EINVAL

    def sys_mprotect(self, addr: int, length: int, prot: int) -> int:
        """mprotect syscall."""
        logger.debug(f"mprotect({addr:#x}, {length:#x}, {prot:#x})")

        mem_prot = self._convert_prot(prot)

        try:
            self._emulator.memory.protect(addr, length, mem_prot)
            return 0
        except Exception as e:
            logger.debug(f"mprotect failed: {e}")
            return -Errno.EINVAL

    def sys_mremap(self, old_addr: int, old_size: int, new_size: int,
                   flags: int, new_addr: int = 0) -> int:
        """mremap syscall."""
        logger.debug(f"mremap({old_addr:#x}, {old_size:#x}, {new_size:#x}, {flags:#x})")

        MREMAP_MAYMOVE = 1
        MREMAP_FIXED = 2

        try:
            if new_size <= old_size:
                # Shrinking - just truncate
                if new_size < old_size:
                    self._emulator.memory.unmap(old_addr + new_size, old_size - new_size)
                return old_addr

            # Growing
            if flags & MREMAP_MAYMOVE:
                # Allocate new region
                from pyunidbg.core.constants import MemoryProtection
                new_region = self._emulator.memory.allocate(
                    new_size, MemoryProtection.READ | MemoryProtection.WRITE, "[mremap]"
                )

                # Copy old data
                old_data = self._emulator.memory.read(old_addr, old_size)
                self._emulator.memory.write(new_region, old_data)

                # Unmap old
                self._emulator.memory.unmap(old_addr, old_size)

                return new_region
            else:
                # Try to extend in place (simplified)
                return -Errno.ENOMEM
        except Exception as e:
            logger.error(f"mremap failed: {e}")
            return -Errno.ENOMEM

    def sys_brk(self, addr: int) -> int:
        """brk syscall."""
        logger.debug(f"brk({addr:#x})")

        if self._brk_addr == 0:
            # Initialize brk to heap start
            self._brk_addr = self._emulator.memory._next_alloc

        if addr == 0:
            return self._brk_addr

        if addr > self._brk_addr:
            # Grow heap
            try:
                from pyunidbg.core.constants import MemoryProtection
                size = addr - self._brk_addr
                self._emulator.memory.map(
                    self._brk_addr, size,
                    MemoryProtection.READ | MemoryProtection.WRITE,
                    "[heap]"
                )
                self._brk_addr = addr
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        elif addr < self._brk_addr:
            # Shrink heap
            try:
                self._emulator.memory.unmap(addr, self._brk_addr - addr)
                self._brk_addr = addr
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        return self._brk_addr

    # ==================== Memory Locking ====================

    def sys_mlock(self, addr: int, length: int) -> int:
        """mlock syscall."""
        # In emulation, just track the request
        self._mlocked_regions.append((addr, length))
        return 0

    def sys_mlock2(self, addr: int, length: int, flags: int) -> int:
        """mlock2 syscall."""
        return self.sys_mlock(addr, length)

    def sys_munlock(self, addr: int, length: int) -> int:
        """munlock syscall."""
        self._mlocked_regions = [
            (a, l) for a, l in self._mlocked_regions
            if not (a == addr and l == length)
        ]
        return 0

    def sys_mlockall(self, flags: int) -> int:
        """mlockall syscall."""
        return 0

    def sys_munlockall(self) -> int:
        """munlockall syscall."""
        self._mlocked_regions.clear()
        return 0

    # ==================== Memory Advice ====================

    def sys_madvise(self, addr: int, length: int, advice: int) -> int:
        """madvise syscall."""
        logger.debug(f"madvise({addr:#x}, {length:#x}, {advice})")

        MADV_DONTNEED = 4
        MADV_REMOVE = 9
        MADV_FREE = 8

        if advice == MADV_DONTNEED:
            # Zero out the memory
            try:
                self._emulator.memory.write(addr, b'\x00' * length)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        elif advice in (MADV_REMOVE, MADV_FREE):
            # Similar to DONTNEED
            try:
                self._emulator.memory.write(addr, b'\x00' * length)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        return 0

    def sys_mincore(self, addr: int, length: int, vec: int) -> int:
        """mincore syscall."""
        # All pages are in-core in emulation
        pages = (length + 4095) // 4096
        self._emulator.memory.write(vec, b'\x01' * pages)
        return 0

    # ==================== Memory Sync ====================

    def sys_msync(self, addr: int, length: int, flags: int) -> int:
        """msync syscall."""
        logger.debug(f"msync({addr:#x}, {length:#x}, {flags:#x})")
        return 0

    # ==================== Memory Info ====================

    def sys_membarrier(self, cmd: int, flags: int) -> int:
        """membarrier syscall."""
        MEMBARRIER_CMD_QUERY = 0

        if cmd == MEMBARRIER_CMD_QUERY:
            # Return supported commands bitmask
            return 0x3F  # All basic commands supported

        return 0

    def sys_memfd_create(self, name: int, flags: int) -> int:
        """memfd_create syscall."""
        name_str = self._emulator.memory.read_string(name)
        logger.debug(f"memfd_create({name_str!r}, {flags:#x})")

        file_ops = self._handler.file_ops
        fd = file_ops.alloc_fd()

        from .file_ops import FileDescriptor
        file_ops.add_fd(FileDescriptor(
            fd, f"[memfd:{name_str}]",
            flags, 0, 0, b""
        ))

        return fd

    # ==================== Process Memory ====================

    def sys_process_vm_readv(self, pid: int, local_iov: int, liovcnt: int,
                             remote_iov: int, riovcnt: int, flags: int) -> int:
        """process_vm_readv syscall."""
        # Only support reading own process
        if pid != 0 and pid != 1000:  # 0 = self, 1000 = our fake pid
            return -Errno.ESRCH

        total = 0
        ptr_size = self._emulator.pointer_size

        for i in range(min(liovcnt, riovcnt)):
            local_entry = local_iov + (i * ptr_size * 2)
            remote_entry = remote_iov + (i * ptr_size * 2)

            local_base = self._emulator.memory.read_ptr(local_entry)
            local_len = self._emulator.memory.read_ptr(local_entry + ptr_size)
            remote_base = self._emulator.memory.read_ptr(remote_entry)
            remote_len = self._emulator.memory.read_ptr(remote_entry + ptr_size)

            copy_len = min(local_len, remote_len)
            if copy_len > 0:
                try:
                    data = self._emulator.memory.read(remote_base, copy_len)
                    self._emulator.memory.write(local_base, data)
                    total += copy_len
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)
                    break

        return total

    def sys_process_vm_writev(self, pid: int, local_iov: int, liovcnt: int,
                              remote_iov: int, riovcnt: int, flags: int) -> int:
        """process_vm_writev syscall."""
        if pid != 0 and pid != 1000:
            return -Errno.ESRCH

        total = 0
        ptr_size = self._emulator.pointer_size

        for i in range(min(liovcnt, riovcnt)):
            local_entry = local_iov + (i * ptr_size * 2)
            remote_entry = remote_iov + (i * ptr_size * 2)

            local_base = self._emulator.memory.read_ptr(local_entry)
            local_len = self._emulator.memory.read_ptr(local_entry + ptr_size)
            remote_base = self._emulator.memory.read_ptr(remote_entry)
            remote_len = self._emulator.memory.read_ptr(remote_entry + ptr_size)

            copy_len = min(local_len, remote_len)
            if copy_len > 0:
                try:
                    data = self._emulator.memory.read(local_base, copy_len)
                    self._emulator.memory.write(remote_base, data)
                    total += copy_len
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)
                    break

        return total
