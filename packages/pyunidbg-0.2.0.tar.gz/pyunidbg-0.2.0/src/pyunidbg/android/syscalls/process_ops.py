"""Process-related syscall implementations."""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

from .defs import Errno, FutexOp, PrctlOption

if TYPE_CHECKING:
    from .handler import SyscallHandler

logger = logging.getLogger(__name__)


class ProcessOperations:
    """Process-related syscall implementations."""

    def __init__(self, handler: SyscallHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Process state
        self._pid = 1000
        self._ppid = 1
        self._tid = 1000
        self._pgid = 1000
        self._sid = 1000

        # User/Group IDs
        self._uid = 10000  # Typical Android app UID
        self._euid = 10000
        self._gid = 10000
        self._egid = 10000
        self._fsuid = 10000
        self._fsgid = 10000
        self._groups = [10000, 3003, 9997]  # inet, everybody, everybody_ext

        # Thread local storage
        self._tid_address = 0
        self._robust_list = 0
        self._robust_list_len = 0

        # Process name
        self._comm = "main"

        # Futex tracking
        self._futex_waiters: dict[int, list] = {}

        # Resource limits
        self._rlimits = {
            0: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF),  # RLIMIT_CPU
            1: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF),  # RLIMIT_FSIZE
            2: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF),  # RLIMIT_DATA
            3: (8388608, 0xFFFFFFFFFFFFFFFF),              # RLIMIT_STACK (8MB)
            4: (0, 0xFFFFFFFFFFFFFFFF),                   # RLIMIT_CORE
            5: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF),  # RLIMIT_RSS
            6: (64000, 64000),                            # RLIMIT_NPROC
            7: (1024, 4096),                              # RLIMIT_NOFILE
            8: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF),  # RLIMIT_MEMLOCK
            9: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF),  # RLIMIT_AS
            10: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF), # RLIMIT_LOCKS
            11: (64000, 64000),                           # RLIMIT_SIGPENDING
            12: (819200, 819200),                         # RLIMIT_MSGQUEUE
            13: (0, 0),                                   # RLIMIT_NICE
            14: (0, 0),                                   # RLIMIT_RTPRIO
            15: (0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF), # RLIMIT_RTTIME
        }

    # ==================== Process IDs ====================

    def sys_getpid(self) -> int:
        """getpid syscall."""
        return self._pid

    def sys_getppid(self) -> int:
        """getppid syscall."""
        return self._ppid

    def sys_gettid(self) -> int:
        """gettid syscall."""
        return self._tid

    def sys_getpgid(self, pid: int) -> int:
        """getpgid syscall."""
        return self._pgid

    def sys_setpgid(self, pid: int, pgid: int) -> int:
        """setpgid syscall."""
        self._pgid = pgid if pgid != 0 else self._pid
        return 0

    def sys_getpgrp(self) -> int:
        """getpgrp syscall."""
        return self._pgid

    def sys_getsid(self, pid: int) -> int:
        """getsid syscall."""
        return self._sid

    def sys_setsid(self) -> int:
        """setsid syscall."""
        self._sid = self._pid
        self._pgid = self._pid
        return self._sid

    # ==================== User/Group IDs ====================

    def sys_getuid(self) -> int:
        """getuid syscall."""
        return self._uid

    def sys_getuid32(self) -> int:
        """getuid32 syscall (ARM32)."""
        return self._uid

    def sys_geteuid(self) -> int:
        """geteuid syscall."""
        return self._euid

    def sys_geteuid32(self) -> int:
        """geteuid32 syscall (ARM32)."""
        return self._euid

    def sys_getgid(self) -> int:
        """getgid syscall."""
        return self._gid

    def sys_getgid32(self) -> int:
        """getgid32 syscall (ARM32)."""
        return self._gid

    def sys_getegid(self) -> int:
        """getegid syscall."""
        return self._egid

    def sys_getegid32(self) -> int:
        """getegid32 syscall (ARM32)."""
        return self._egid

    def sys_setuid(self, uid: int) -> int:
        """setuid syscall."""
        self._uid = uid
        self._euid = uid
        return 0

    def sys_setgid(self, gid: int) -> int:
        """setgid syscall."""
        self._gid = gid
        self._egid = gid
        return 0

    def sys_setreuid(self, ruid: int, euid: int) -> int:
        """setreuid syscall."""
        if ruid != -1:
            self._uid = ruid
        if euid != -1:
            self._euid = euid
        return 0

    def sys_setregid(self, rgid: int, egid: int) -> int:
        """setregid syscall."""
        if rgid != -1:
            self._gid = rgid
        if egid != -1:
            self._egid = egid
        return 0

    def sys_setresuid(self, ruid: int, euid: int, suid: int) -> int:
        """setresuid syscall."""
        if ruid != -1:
            self._uid = ruid
        if euid != -1:
            self._euid = euid
        return 0

    def sys_getresuid(self, ruid: int, euid: int, suid: int) -> int:
        """getresuid syscall."""
        mem = self._emulator.memory
        mem.write_u32(ruid, self._uid)
        mem.write_u32(euid, self._euid)
        mem.write_u32(suid, self._euid)  # saved uid = effective
        return 0

    def sys_setresgid(self, rgid: int, egid: int, sgid: int) -> int:
        """setresgid syscall."""
        if rgid != -1:
            self._gid = rgid
        if egid != -1:
            self._egid = egid
        return 0

    def sys_getresgid(self, rgid: int, egid: int, sgid: int) -> int:
        """getresgid syscall."""
        mem = self._emulator.memory
        mem.write_u32(rgid, self._gid)
        mem.write_u32(egid, self._egid)
        mem.write_u32(sgid, self._egid)
        return 0

    def sys_setfsuid(self, fsuid: int) -> int:
        """setfsuid syscall."""
        old = self._fsuid
        self._fsuid = fsuid
        return old

    def sys_setfsgid(self, fsgid: int) -> int:
        """setfsgid syscall."""
        old = self._fsgid
        self._fsgid = fsgid
        return old

    def sys_getgroups(self, size: int, list_ptr: int) -> int:
        """getgroups syscall."""
        if size == 0:
            return len(self._groups)

        if size < len(self._groups):
            return -Errno.EINVAL

        for i, gid in enumerate(self._groups):
            self._emulator.memory.write_u32(list_ptr + i * 4, gid)

        return len(self._groups)

    def sys_setgroups(self, size: int, list_ptr: int) -> int:
        """setgroups syscall."""
        self._groups = []
        for i in range(size):
            gid = self._emulator.memory.read_u32(list_ptr + i * 4)
            self._groups.append(gid)
        return 0

    # ==================== Thread Operations ====================

    def sys_set_tid_address(self, tidptr: int) -> int:
        """set_tid_address syscall."""
        self._tid_address = tidptr
        return self._tid

    def sys_set_robust_list(self, head: int, len_: int) -> int:
        """set_robust_list syscall."""
        self._robust_list = head
        self._robust_list_len = len_
        return 0

    def sys_get_robust_list(self, pid: int, head_ptr: int, len_ptr: int) -> int:
        """get_robust_list syscall."""
        ptr_size = self._emulator.pointer_size
        if ptr_size == 8:
            self._emulator.memory.write_u64(head_ptr, self._robust_list)
            self._emulator.memory.write_u64(len_ptr, self._robust_list_len)
        else:
            self._emulator.memory.write_u32(head_ptr, self._robust_list)
            self._emulator.memory.write_u32(len_ptr, self._robust_list_len)
        return 0

    def sys_clone(self, flags: int, stack: int, parent_tid: int,
                  tls: int, child_tid: int) -> int:
        """clone syscall - simplified, doesn't actually create thread."""
        logger.debug(f"clone({flags:#x}, {stack:#x}, {parent_tid:#x}, {tls:#x}, {child_tid:#x})")

        # In emulation, just return a fake TID
        new_tid = self._tid + 1

        CLONE_PARENT_SETTID = 0x00100000
        CLONE_CHILD_SETTID = 0x01000000
        CLONE_CHILD_CLEARTID = 0x00200000

        if flags & CLONE_PARENT_SETTID:
            self._emulator.memory.write_u32(parent_tid, new_tid)
        if flags & CLONE_CHILD_SETTID:
            self._emulator.memory.write_u32(child_tid, new_tid)

        return new_tid

    # ==================== Futex ====================

    def sys_futex(self, uaddr: int, op: int, val: int,
                  timeout: int, uaddr2: int, val3: int) -> int:
        """futex syscall."""
        cmd = op & 0x7F  # Remove private flag

        logger.debug(f"futex({uaddr:#x}, op={cmd}, val={val})")

        if cmd == FutexOp.FUTEX_WAIT:
            # Check if value matches
            current = self._emulator.memory.read_u32(uaddr)
            if current != val:
                return -Errno.EAGAIN
            # In single-threaded emulation, just return immediately
            return 0

        elif cmd == FutexOp.FUTEX_WAKE:
            # Wake up to val waiters
            return 0  # No waiters in single-threaded mode

        elif cmd == FutexOp.FUTEX_WAIT_BITSET:
            current = self._emulator.memory.read_u32(uaddr)
            if current != val:
                return -Errno.EAGAIN
            return 0

        elif cmd == FutexOp.FUTEX_WAKE_BITSET:
            return 0

        elif cmd == FutexOp.FUTEX_REQUEUE:
            return 0

        elif cmd == FutexOp.FUTEX_CMP_REQUEUE:
            current = self._emulator.memory.read_u32(uaddr)
            if current != val3:
                return -Errno.EAGAIN
            return 0

        return 0

    # ==================== Process Control ====================

    def sys_prctl(self, option: int, arg2: int, arg3: int,
                  arg4: int, arg5: int) -> int:
        """prctl syscall."""
        logger.debug(f"prctl({option}, {arg2:#x}, {arg3:#x}, {arg4:#x}, {arg5:#x})")

        if option == PrctlOption.PR_SET_NAME:
            self._comm = self._emulator.memory.read_string(arg2, 16)
            logger.debug(f"prctl(PR_SET_NAME, {self._comm!r})")
            return 0

        elif option == PrctlOption.PR_GET_NAME:
            self._emulator.memory.write_string(arg2, self._comm)
            return 0

        elif option == PrctlOption.PR_SET_DUMPABLE:
            return 0

        elif option == PrctlOption.PR_GET_DUMPABLE:
            return 1  # SUID_DUMP_USER

        elif option == PrctlOption.PR_SET_PDEATHSIG:
            return 0

        elif option == PrctlOption.PR_GET_PDEATHSIG:
            self._emulator.memory.write_u32(arg2, 0)
            return 0

        elif option == PrctlOption.PR_SET_SECCOMP:
            return 0  # Accept but don't actually enable seccomp

        elif option == PrctlOption.PR_GET_SECCOMP:
            return 0  # Seccomp disabled

        elif option == PrctlOption.PR_SET_NO_NEW_PRIVS:
            return 0

        elif option == PrctlOption.PR_GET_NO_NEW_PRIVS:
            return 0

        elif option == PrctlOption.PR_CAPBSET_READ:
            return 0  # Capability not in bounding set

        elif option == PrctlOption.PR_CAPBSET_DROP:
            return 0

        return 0

    def sys_seccomp(self, operation: int, flags: int, args: int) -> int:
        """seccomp syscall."""
        SECCOMP_SET_MODE_STRICT = 0
        SECCOMP_SET_MODE_FILTER = 1
        SECCOMP_GET_ACTION_AVAIL = 2

        if operation == SECCOMP_GET_ACTION_AVAIL:
            return 0  # All actions available

        # Accept but don't actually enable seccomp
        return 0

    # ==================== Exit ====================

    def sys_exit(self, status: int) -> int:
        """exit syscall."""
        logger.info(f"Process exiting with status {status}")
        self._emulator.stop()
        return 0

    def sys_exit_group(self, status: int) -> int:
        """exit_group syscall."""
        return self.sys_exit(status)

    # ==================== System Info ====================

    def sys_uname(self, buf: int) -> int:
        """uname syscall."""
        from pyunidbg.core.constants import Architecture

        is_arm64 = self._emulator.arch == Architecture.ARM64

        # struct utsname has 6 fields of 65 bytes each
        fields = [
            b"Linux",
            b"localhost",
            b"5.4.0-android",
            b"#1 SMP PREEMPT Mon Jan 01 00:00:00 UTC 2024",
            b"aarch64" if is_arm64 else b"armv7l",
            b"(none)",
        ]

        for i, field in enumerate(fields):
            self._emulator.memory.write(buf + (i * 65), field + b'\x00')

        return 0

    def sys_sysinfo(self, info: int) -> int:
        """sysinfo syscall."""
        mem = self._emulator.memory
        is_arm64 = self._emulator.pointer_size == 8

        import time
        uptime = int(time.time()) % 86400  # Fake uptime

        if is_arm64:
            mem.write_u64(info + 0, uptime)        # uptime
            mem.write_u64(info + 8, 1000)          # loads[0]
            mem.write_u64(info + 16, 1000)         # loads[1]
            mem.write_u64(info + 24, 1000)         # loads[2]
            mem.write_u64(info + 32, 4096 * 1024 * 1024)  # totalram (4GB)
            mem.write_u64(info + 40, 2048 * 1024 * 1024)  # freeram (2GB)
            mem.write_u64(info + 48, 512 * 1024 * 1024)   # sharedram
            mem.write_u64(info + 56, 256 * 1024 * 1024)   # bufferram
            mem.write_u64(info + 64, 1024 * 1024 * 1024)  # totalswap (1GB)
            mem.write_u64(info + 72, 1024 * 1024 * 1024)  # freeswap
            mem.write_u16(info + 80, 1)            # procs
            mem.write_u64(info + 88, 4096 * 1024 * 1024)  # totalhigh
            mem.write_u64(info + 96, 2048 * 1024 * 1024)  # freehigh
            mem.write_u32(info + 104, 1)           # mem_unit
        else:
            mem.write_u32(info + 0, uptime)
            mem.write_u32(info + 4, 1000)
            mem.write_u32(info + 8, 1000)
            mem.write_u32(info + 12, 1000)
            mem.write_u32(info + 16, 4096 * 1024)   # totalram
            mem.write_u32(info + 20, 2048 * 1024)   # freeram
            mem.write_u32(info + 24, 512 * 1024)
            mem.write_u32(info + 28, 256 * 1024)
            mem.write_u32(info + 32, 1024 * 1024)
            mem.write_u32(info + 36, 1024 * 1024)
            mem.write_u16(info + 40, 1)
            mem.write_u32(info + 44, 1024)          # mem_unit

        return 0

    def sys_getcpu(self, cpu: int, node: int, unused: int) -> int:
        """getcpu syscall."""
        if cpu:
            self._emulator.memory.write_u32(cpu, 0)  # CPU 0
        if node:
            self._emulator.memory.write_u32(node, 0)  # Node 0
        return 0

    # ==================== Resource Limits ====================

    def sys_getrlimit(self, resource: int, rlim: int) -> int:
        """getrlimit syscall."""
        if resource not in self._rlimits:
            return -Errno.EINVAL

        soft, hard = self._rlimits[resource]
        ptr_size = self._emulator.pointer_size

        if ptr_size == 8:
            self._emulator.memory.write_u64(rlim, soft)
            self._emulator.memory.write_u64(rlim + 8, hard)
        else:
            self._emulator.memory.write_u32(rlim, soft & 0xFFFFFFFF)
            self._emulator.memory.write_u32(rlim + 4, hard & 0xFFFFFFFF)

        return 0

    def sys_setrlimit(self, resource: int, rlim: int) -> int:
        """setrlimit syscall."""
        ptr_size = self._emulator.pointer_size

        if ptr_size == 8:
            soft = self._emulator.memory.read_u64(rlim)
            hard = self._emulator.memory.read_u64(rlim + 8)
        else:
            soft = self._emulator.memory.read_u32(rlim)
            hard = self._emulator.memory.read_u32(rlim + 4)

        self._rlimits[resource] = (soft, hard)
        return 0

    def sys_prlimit64(self, pid: int, resource: int,
                      new_rlim: int, old_rlim: int) -> int:
        """prlimit64 syscall."""
        # Get old limit
        if old_rlim:
            if resource in self._rlimits:
                soft, hard = self._rlimits[resource]
            else:
                soft, hard = 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF

            self._emulator.memory.write_u64(old_rlim, soft)
            self._emulator.memory.write_u64(old_rlim + 8, hard)

        # Set new limit
        if new_rlim:
            soft = self._emulator.memory.read_u64(new_rlim)
            hard = self._emulator.memory.read_u64(new_rlim + 8)
            self._rlimits[resource] = (soft, hard)

        return 0

    def sys_getrusage(self, who: int, usage: int) -> int:
        """getrusage syscall."""
        # Zero out the structure
        self._emulator.memory.write(usage, b'\x00' * 144)
        return 0

    def sys_times(self, buf: int) -> int:
        """times syscall."""
        if buf:
            # struct tms
            self._emulator.memory.write_u64(buf, 0)       # tms_utime
            self._emulator.memory.write_u64(buf + 8, 0)   # tms_stime
            self._emulator.memory.write_u64(buf + 16, 0)  # tms_cutime
            self._emulator.memory.write_u64(buf + 24, 0)  # tms_cstime

        import time
        return int(time.time() * 100) & 0xFFFFFFFF  # clock ticks

    # ==================== Scheduler ====================

    def sys_sched_yield(self) -> int:
        """sched_yield syscall."""
        return 0

    def sys_sched_getaffinity(self, pid: int, cpusetsize: int, mask: int) -> int:
        """sched_getaffinity syscall."""
        # Return 8 CPUs
        cpu_mask = 0xFF

        if cpusetsize >= 8:
            self._emulator.memory.write_u64(mask, cpu_mask)
        else:
            self._emulator.memory.write(mask, cpu_mask.to_bytes(cpusetsize, 'little'))

        return min(cpusetsize, 8)

    def sys_sched_setaffinity(self, pid: int, cpusetsize: int, mask: int) -> int:
        """sched_setaffinity syscall."""
        return 0

    def sys_sched_getscheduler(self, pid: int) -> int:
        """sched_getscheduler syscall."""
        return 0  # SCHED_NORMAL

    def sys_sched_setscheduler(self, pid: int, policy: int, param: int) -> int:
        """sched_setscheduler syscall."""
        return 0

    def sys_sched_getparam(self, pid: int, param: int) -> int:
        """sched_getparam syscall."""
        self._emulator.memory.write_u32(param, 0)  # sched_priority
        return 0

    def sys_sched_setparam(self, pid: int, param: int) -> int:
        """sched_setparam syscall."""
        return 0

    def sys_sched_get_priority_max(self, policy: int) -> int:
        """sched_get_priority_max syscall."""
        return 99

    def sys_sched_get_priority_min(self, policy: int) -> int:
        """sched_get_priority_min syscall."""
        return 1

    def sys_sched_rr_get_interval(self, pid: int, tp: int) -> int:
        """sched_rr_get_interval syscall."""
        # 100ms time slice
        if self._emulator.pointer_size == 8:
            self._emulator.memory.write_u64(tp, 0)
            self._emulator.memory.write_u64(tp + 8, 100000000)
        else:
            self._emulator.memory.write_u32(tp, 0)
            self._emulator.memory.write_u32(tp + 4, 100000000)
        return 0

    # ==================== Capabilities ====================

    def sys_capget(self, hdrp: int, datap: int) -> int:
        """capget syscall."""
        # Read header
        version = self._emulator.memory.read_u32(hdrp)

        # Fill in empty capabilities (unprivileged)
        if datap:
            self._emulator.memory.write(datap, b'\x00' * 24)

        return 0

    def sys_capset(self, hdrp: int, datap: int) -> int:
        """capset syscall."""
        return 0  # Accept any capability set

    # ==================== Random ====================

    def sys_getrandom(self, buf: int, buflen: int, flags: int) -> int:
        """getrandom syscall."""
        data = os.urandom(buflen)
        self._emulator.memory.write(buf, data)
        return buflen

    # ==================== Personality ====================

    def sys_personality(self, persona: int) -> int:
        """personality syscall."""
        if persona == 0xFFFFFFFF:
            return 0  # Return current personality (PER_LINUX)
        return 0
