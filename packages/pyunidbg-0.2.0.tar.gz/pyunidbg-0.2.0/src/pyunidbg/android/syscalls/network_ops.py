"""Network-related syscall implementations."""

from __future__ import annotations

import logging
import struct
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .defs import AddressFamily, Errno, SocketType

if TYPE_CHECKING:
    from .handler import SyscallHandler

logger = logging.getLogger(__name__)


@dataclass
class SocketDescriptor:
    """Represents a socket."""

    fd: int
    domain: int
    sock_type: int
    protocol: int
    bound_addr: bytes = b""
    connected_addr: bytes = b""
    listening: bool = False
    backlog: int = 0
    recv_buffer: bytes = b""
    send_buffer: bytes = b""
    options: dict = field(default_factory=dict)
    blocking: bool = True


class NetworkOperations:
    """Network-related syscall implementations."""

    def __init__(self, handler: SyscallHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Socket tracking
        self._sockets: dict[int, SocketDescriptor] = {}

        # Epoll instances
        self._epoll_fds: dict[int, dict] = {}

        # Eventfd tracking
        self._eventfds: dict[int, int] = {}  # fd -> counter

        # Timerfd tracking
        self._timerfds: dict[int, dict] = {}

    # ==================== Socket Creation ====================

    def sys_socket(self, domain: int, sock_type: int, protocol: int) -> int:
        """socket syscall."""
        logger.debug(f"socket({domain}, {sock_type}, {protocol})")

        file_ops = self._handler.file_ops
        fd = file_ops.alloc_fd()

        # Extract actual type (remove SOCK_CLOEXEC, SOCK_NONBLOCK)
        real_type = sock_type & 0xF
        blocking = not (sock_type & SocketType.SOCK_NONBLOCK)

        self._sockets[fd] = SocketDescriptor(
            fd=fd,
            domain=domain,
            sock_type=real_type,
            protocol=protocol,
            blocking=blocking,
        )

        # Also add to file_ops for generic fd operations
        from .file_ops import FileDescriptor
        file_ops.add_fd(FileDescriptor(
            fd, f"[socket:{domain}:{real_type}]", 0, 0,
            is_socket=True
        ))

        return fd

    def sys_socketpair(self, domain: int, sock_type: int, protocol: int, sv: int) -> int:
        """socketpair syscall."""
        fd1 = self.sys_socket(domain, sock_type, protocol)
        fd2 = self.sys_socket(domain, sock_type, protocol)

        if fd1 < 0 or fd2 < 0:
            return -Errno.ENOMEM

        # Write fds to userspace
        self._emulator.memory.write_u32(sv, fd1)
        self._emulator.memory.write_u32(sv + 4, fd2)

        return 0

    # ==================== Socket Operations ====================

    def sys_bind(self, sockfd: int, addr: int, addrlen: int) -> int:
        """bind syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]
        sock.bound_addr = self._emulator.memory.read(addr, addrlen)

        logger.debug(f"bind({sockfd}, addr_len={addrlen})")
        return 0

    def sys_listen(self, sockfd: int, backlog: int) -> int:
        """listen syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]
        sock.listening = True
        sock.backlog = backlog

        return 0

    def sys_accept(self, sockfd: int, addr: int, addrlen: int) -> int:
        """accept syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]
        if not sock.listening:
            return -Errno.EINVAL

        # In emulation, we don't have real connections
        # Return EAGAIN for non-blocking, block forever for blocking
        if sock.blocking:
            # Would block forever - return error
            return -Errno.ECONNABORTED
        else:
            return -Errno.EAGAIN

    def sys_accept4(self, sockfd: int, addr: int, addrlen: int, flags: int) -> int:
        """accept4 syscall."""
        return self.sys_accept(sockfd, addr, addrlen)

    def sys_connect(self, sockfd: int, addr: int, addrlen: int) -> int:
        """connect syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]
        sock.connected_addr = self._emulator.memory.read(addr, addrlen)

        logger.debug(f"connect({sockfd}, addr_len={addrlen})")

        # Simulate successful connection
        return 0

    def sys_shutdown(self, sockfd: int, how: int) -> int:
        """shutdown syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF
        return 0

    # ==================== Socket Info ====================

    def sys_getsockname(self, sockfd: int, addr: int, addrlen: int) -> int:
        """getsockname syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]

        if sock.bound_addr:
            write_len = min(len(sock.bound_addr),
                           self._emulator.memory.read_u32(addrlen))
            self._emulator.memory.write(addr, sock.bound_addr[:write_len])
            self._emulator.memory.write_u32(addrlen, len(sock.bound_addr))
        else:
            # Return empty address
            if sock.domain == AddressFamily.AF_INET:
                # struct sockaddr_in
                sa = struct.pack("<HH4s8s", AddressFamily.AF_INET, 0, b"\x00\x00\x00\x00", b"\x00" * 8)
            elif sock.domain == AddressFamily.AF_INET6:
                sa = struct.pack("<HHI16sI", AddressFamily.AF_INET6, 0, 0, b"\x00" * 16, 0)
            else:
                sa = struct.pack("<H", sock.domain) + b"\x00" * 14

            self._emulator.memory.write(addr, sa)
            self._emulator.memory.write_u32(addrlen, len(sa))

        return 0

    def sys_getpeername(self, sockfd: int, addr: int, addrlen: int) -> int:
        """getpeername syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]

        if not sock.connected_addr:
            return -Errno.ENOTCONN

        write_len = min(len(sock.connected_addr),
                       self._emulator.memory.read_u32(addrlen))
        self._emulator.memory.write(addr, sock.connected_addr[:write_len])
        self._emulator.memory.write_u32(addrlen, len(sock.connected_addr))

        return 0

    # ==================== Socket Options ====================

    def sys_setsockopt(self, sockfd: int, level: int, optname: int,
                       optval: int, optlen: int) -> int:
        """setsockopt syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]
        value = self._emulator.memory.read(optval, optlen) if optval else b""
        sock.options[(level, optname)] = value

        logger.debug(f"setsockopt({sockfd}, {level}, {optname}, len={optlen})")
        return 0

    def sys_getsockopt(self, sockfd: int, level: int, optname: int,
                       optval: int, optlen: int) -> int:
        """getsockopt syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]

        # Common socket options
        SO_LEVEL = 1
        SO_ERROR = 4
        SO_TYPE = 3
        SO_REUSEADDR = 2
        SO_SNDBUF = 7
        SO_RCVBUF = 8

        if level == SO_LEVEL:
            if optname == SO_ERROR:
                # No error
                self._emulator.memory.write_u32(optval, 0)
                self._emulator.memory.write_u32(optlen, 4)
            elif optname == SO_TYPE:
                self._emulator.memory.write_u32(optval, sock.sock_type)
                self._emulator.memory.write_u32(optlen, 4)
            elif optname in (SO_SNDBUF, SO_RCVBUF):
                self._emulator.memory.write_u32(optval, 262144)  # 256KB
                self._emulator.memory.write_u32(optlen, 4)
            elif (level, optname) in sock.options:
                val = sock.options[(level, optname)]
                self._emulator.memory.write(optval, val)
                self._emulator.memory.write_u32(optlen, len(val))
            else:
                self._emulator.memory.write_u32(optval, 0)
                self._emulator.memory.write_u32(optlen, 4)
        else:
            # Return stored value or zero
            if (level, optname) in sock.options:
                val = sock.options[(level, optname)]
                self._emulator.memory.write(optval, val)
                self._emulator.memory.write_u32(optlen, len(val))
            else:
                self._emulator.memory.write_u32(optval, 0)
                self._emulator.memory.write_u32(optlen, 4)

        return 0

    # ==================== Send/Receive ====================

    def sys_sendto(self, sockfd: int, buf: int, length: int, flags: int,
                   dest_addr: int, addrlen: int) -> int:
        """sendto syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]
        data = self._emulator.memory.read(buf, length)

        # Store in send buffer (for potential inspection)
        sock.send_buffer = data

        logger.debug(f"sendto({sockfd}, len={length})")

        # Pretend we sent all data
        return length

    def sys_send(self, sockfd: int, buf: int, length: int, flags: int) -> int:
        """send syscall."""
        return self.sys_sendto(sockfd, buf, length, flags, 0, 0)

    def sys_recvfrom(self, sockfd: int, buf: int, length: int, flags: int,
                     src_addr: int, addrlen: int) -> int:
        """recvfrom syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]

        # Check recv buffer
        if sock.recv_buffer:
            data = sock.recv_buffer[:length]
            sock.recv_buffer = sock.recv_buffer[length:]
            self._emulator.memory.write(buf, data)
            return len(data)

        # No data available
        if sock.blocking:
            return -Errno.EAGAIN  # Would block
        else:
            return -Errno.EAGAIN

    def sys_recv(self, sockfd: int, buf: int, length: int, flags: int) -> int:
        """recv syscall."""
        return self.sys_recvfrom(sockfd, buf, length, flags, 0, 0)

    def sys_sendmsg(self, sockfd: int, msg: int, flags: int) -> int:
        """sendmsg syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        # Parse msghdr and send
        ptr_size = self._emulator.pointer_size
        mem = self._emulator.memory

        iov = mem.read_ptr(msg + ptr_size)      # msg_iov
        iovlen = mem.read_ptr(msg + ptr_size * 2)  # msg_iovlen

        total = 0
        for i in range(iovlen):
            iov_entry = iov + (i * ptr_size * 2)
            base = mem.read_ptr(iov_entry)
            length = mem.read_ptr(iov_entry + ptr_size)
            total += length

        return total

    def sys_recvmsg(self, sockfd: int, msg: int, flags: int) -> int:
        """recvmsg syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        sock = self._sockets[sockfd]

        if not sock.recv_buffer:
            return -Errno.EAGAIN

        # Would need to parse msghdr structure
        return len(sock.recv_buffer)

    def sys_sendmmsg(self, sockfd: int, msgvec: int, vlen: int, flags: int) -> int:
        """sendmmsg syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF

        # Simplified - pretend all messages sent
        return vlen

    def sys_recvmmsg(self, sockfd: int, msgvec: int, vlen: int,
                     flags: int, timeout: int) -> int:
        """recvmmsg syscall."""
        if sockfd not in self._sockets:
            return -Errno.EBADF
        return -Errno.EAGAIN

    # ==================== Epoll ====================

    def sys_epoll_create1(self, flags: int) -> int:
        """epoll_create1 syscall."""
        file_ops = self._handler.file_ops
        fd = file_ops.alloc_fd()

        self._epoll_fds[fd] = {
            'fds': {},  # fd -> events
            'flags': flags,
        }

        from .file_ops import FileDescriptor
        file_ops.add_fd(FileDescriptor(fd, "[eventpoll]", 0, 0))

        return fd

    def sys_epoll_create(self, size: int) -> int:
        """epoll_create syscall."""
        return self.sys_epoll_create1(0)

    def sys_epoll_ctl(self, epfd: int, op: int, fd: int, event: int) -> int:
        """epoll_ctl syscall."""
        if epfd not in self._epoll_fds:
            return -Errno.EBADF

        EPOLL_CTL_ADD = 1
        EPOLL_CTL_DEL = 2
        EPOLL_CTL_MOD = 3

        epoll = self._epoll_fds[epfd]

        if op == EPOLL_CTL_ADD:
            events = self._emulator.memory.read_u32(event)
            epoll['fds'][fd] = events
        elif op == EPOLL_CTL_DEL:
            if fd in epoll['fds']:
                del epoll['fds'][fd]
        elif op == EPOLL_CTL_MOD:
            events = self._emulator.memory.read_u32(event)
            epoll['fds'][fd] = events

        return 0

    def sys_epoll_pwait(self, epfd: int, events: int, maxevents: int,
                        timeout: int, sigmask: int) -> int:
        """epoll_pwait syscall."""
        if epfd not in self._epoll_fds:
            return -Errno.EBADF

        # In emulation, no events are ready
        if timeout == 0:
            return 0

        # Non-zero timeout would block
        return 0

    def sys_epoll_wait(self, epfd: int, events: int, maxevents: int,
                       timeout: int) -> int:
        """epoll_wait syscall."""
        return self.sys_epoll_pwait(epfd, events, maxevents, timeout, 0)

    # ==================== Select/Poll ====================

    def sys_select(self, nfds: int, readfds: int, writefds: int,
                   exceptfds: int, timeout: int) -> int:
        """select syscall."""
        # Simplified - return 0 (timeout) or indicate writable
        return 0

    def sys_pselect6(self, nfds: int, readfds: int, writefds: int,
                     exceptfds: int, timeout: int, sigmask: int) -> int:
        """pselect6 syscall."""
        return self.sys_select(nfds, readfds, writefds, exceptfds, timeout)

    def sys_poll(self, fds: int, nfds: int, timeout: int) -> int:
        """poll syscall."""
        # Return 0 (timeout)
        return 0

    def sys_ppoll(self, fds: int, nfds: int, timeout: int, sigmask: int) -> int:
        """ppoll syscall."""
        return self.sys_poll(fds, nfds, 0)

    # ==================== Eventfd ====================

    def sys_eventfd2(self, initval: int, flags: int) -> int:
        """eventfd2 syscall."""
        file_ops = self._handler.file_ops
        fd = file_ops.alloc_fd()

        self._eventfds[fd] = initval

        from .file_ops import FileDescriptor
        file_ops.add_fd(FileDescriptor(fd, "[eventfd]", flags, 0))

        return fd

    def sys_eventfd(self, initval: int) -> int:
        """eventfd syscall."""
        return self.sys_eventfd2(initval, 0)

    # ==================== Timerfd ====================

    def sys_timerfd_create(self, clockid: int, flags: int) -> int:
        """timerfd_create syscall."""
        file_ops = self._handler.file_ops
        fd = file_ops.alloc_fd()

        self._timerfds[fd] = {
            'clockid': clockid,
            'flags': flags,
            'value': (0, 0),
            'interval': (0, 0),
        }

        from .file_ops import FileDescriptor
        file_ops.add_fd(FileDescriptor(fd, "[timerfd]", flags, 0))

        return fd

    def sys_timerfd_settime(self, fd: int, flags: int,
                            new_value: int, old_value: int) -> int:
        """timerfd_settime syscall."""
        if fd not in self._timerfds:
            return -Errno.EBADF

        mem = self._emulator.memory

        # Read new itimerspec
        it_interval_sec = mem.read_u64(new_value)
        it_interval_nsec = mem.read_u64(new_value + 8)
        it_value_sec = mem.read_u64(new_value + 16)
        it_value_nsec = mem.read_u64(new_value + 24)

        timer = self._timerfds[fd]

        # Store old value if requested
        if old_value:
            mem.write_u64(old_value, timer['interval'][0])
            mem.write_u64(old_value + 8, timer['interval'][1])
            mem.write_u64(old_value + 16, timer['value'][0])
            mem.write_u64(old_value + 24, timer['value'][1])

        timer['interval'] = (it_interval_sec, it_interval_nsec)
        timer['value'] = (it_value_sec, it_value_nsec)

        return 0

    def sys_timerfd_gettime(self, fd: int, curr_value: int) -> int:
        """timerfd_gettime syscall."""
        if fd not in self._timerfds:
            return -Errno.EBADF

        timer = self._timerfds[fd]
        mem = self._emulator.memory

        mem.write_u64(curr_value, timer['interval'][0])
        mem.write_u64(curr_value + 8, timer['interval'][1])
        mem.write_u64(curr_value + 16, timer['value'][0])
        mem.write_u64(curr_value + 24, timer['value'][1])

        return 0

    # ==================== Signalfd ====================

    def sys_signalfd4(self, fd: int, mask: int, sizemask: int, flags: int) -> int:
        """signalfd4 syscall."""
        file_ops = self._handler.file_ops

        if fd == -1:
            new_fd = file_ops.alloc_fd()
            from .file_ops import FileDescriptor
            file_ops.add_fd(FileDescriptor(new_fd, "[signalfd]", flags, 0))
            return new_fd
        else:
            # Modify existing signalfd
            return fd

    def sys_signalfd(self, fd: int, mask: int, sizemask: int) -> int:
        """signalfd syscall."""
        return self.sys_signalfd4(fd, mask, sizemask, 0)

    # ==================== Inotify ====================

    def sys_inotify_init1(self, flags: int) -> int:
        """inotify_init1 syscall."""
        file_ops = self._handler.file_ops
        fd = file_ops.alloc_fd()

        from .file_ops import FileDescriptor
        file_ops.add_fd(FileDescriptor(fd, "[inotify]", flags, 0))

        return fd

    def sys_inotify_init(self) -> int:
        """inotify_init syscall."""
        return self.sys_inotify_init1(0)

    def sys_inotify_add_watch(self, fd: int, pathname: int, mask: int) -> int:
        """inotify_add_watch syscall."""
        # Return a fake watch descriptor
        return 1

    def sys_inotify_rm_watch(self, fd: int, wd: int) -> int:
        """inotify_rm_watch syscall."""
        return 0

    # ==================== Utility ====================

    def inject_recv_data(self, sockfd: int, data: bytes) -> bool:
        """Inject data into a socket's receive buffer for testing."""
        if sockfd in self._sockets:
            self._sockets[sockfd].recv_buffer += data
            return True
        return False
