"""Time-related syscall implementations."""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

from .defs import ClockId, Errno

if TYPE_CHECKING:
    from .handler import SyscallHandler

logger = logging.getLogger(__name__)


class TimeOperations:
    """Time-related syscall implementations."""

    def __init__(self, handler: SyscallHandler):
        self._handler = handler
        self._emulator = handler._emulator

        # Boot time for CLOCK_BOOTTIME
        self._boot_time = time.time()

        # Timer tracking
        self._timers: dict[int, dict] = {}
        self._timer_counter = 0

        # Interval timers
        self._itimers = {
            0: {'value': (0, 0), 'interval': (0, 0)},  # ITIMER_REAL
            1: {'value': (0, 0), 'interval': (0, 0)},  # ITIMER_VIRTUAL
            2: {'value': (0, 0), 'interval': (0, 0)},  # ITIMER_PROF
        }

    def _get_time_for_clock(self, clk_id: int) -> tuple[int, int]:
        """Get time for a specific clock ID."""
        if clk_id == ClockId.CLOCK_REALTIME:
            now = time.time()
        elif clk_id == ClockId.CLOCK_MONOTONIC:
            now = time.monotonic()
        elif clk_id == ClockId.CLOCK_MONOTONIC_RAW:
            now = time.monotonic()
        elif clk_id == ClockId.CLOCK_MONOTONIC_COARSE:
            now = time.monotonic()
        elif clk_id == ClockId.CLOCK_REALTIME_COARSE:
            now = time.time()
        elif clk_id == ClockId.CLOCK_BOOTTIME:
            now = time.time() - self._boot_time
        elif clk_id == ClockId.CLOCK_PROCESS_CPUTIME_ID:
            now = time.process_time()
        elif clk_id == ClockId.CLOCK_THREAD_CPUTIME_ID:
            now = time.thread_time() if hasattr(time, 'thread_time') else time.process_time()
        else:
            now = time.time()

        sec = int(now)
        nsec = int((now - sec) * 1e9)
        return sec, nsec

    # ==================== Clock Operations ====================

    def sys_clock_gettime(self, clk_id: int, tp: int) -> int:
        """clock_gettime syscall."""
        sec, nsec = self._get_time_for_clock(clk_id)

        mem = self._emulator.memory
        if self._emulator.pointer_size == 8:
            mem.write_u64(tp, sec)
            mem.write_u64(tp + 8, nsec)
        else:
            mem.write_u32(tp, sec)
            mem.write_u32(tp + 4, nsec)

        return 0

    def sys_clock_settime(self, clk_id: int, tp: int) -> int:
        """clock_settime syscall."""
        # In emulation, we don't actually change the clock
        logger.debug(f"clock_settime({clk_id}) - ignored")
        return 0

    def sys_clock_getres(self, clk_id: int, res: int) -> int:
        """clock_getres syscall."""
        if res == 0:
            return 0

        mem = self._emulator.memory
        # Return 1ns resolution
        if self._emulator.pointer_size == 8:
            mem.write_u64(res, 0)
            mem.write_u64(res + 8, 1)
        else:
            mem.write_u32(res, 0)
            mem.write_u32(res + 4, 1)

        return 0

    def sys_clock_nanosleep(self, clk_id: int, flags: int,
                            request: int, remain: int) -> int:
        """clock_nanosleep syscall."""
        mem = self._emulator.memory

        if self._emulator.pointer_size == 8:
            sec = mem.read_u64(request)
            nsec = mem.read_u64(request + 8)
        else:
            sec = mem.read_u32(request)
            nsec = mem.read_u32(request + 4)

        # Don't actually sleep in emulation
        logger.debug(f"clock_nanosleep({sec}s {nsec}ns) - skipped")

        # Clear remainder
        if remain:
            if self._emulator.pointer_size == 8:
                mem.write_u64(remain, 0)
                mem.write_u64(remain + 8, 0)
            else:
                mem.write_u32(remain, 0)
                mem.write_u32(remain + 4, 0)

        return 0

    # ==================== Time of Day ====================

    def sys_gettimeofday(self, tv: int, tz: int) -> int:
        """gettimeofday syscall."""
        now = time.time()
        sec = int(now)
        usec = int((now - sec) * 1e6)

        mem = self._emulator.memory
        if self._emulator.pointer_size == 8:
            mem.write_u64(tv, sec)
            mem.write_u64(tv + 8, usec)
        else:
            mem.write_u32(tv, sec)
            mem.write_u32(tv + 4, usec)

        if tz:
            # struct timezone
            mem.write_u32(tz, 0)      # tz_minuteswest
            mem.write_u32(tz + 4, 0)  # tz_dsttime

        return 0

    def sys_settimeofday(self, tv: int, tz: int) -> int:
        """settimeofday syscall."""
        logger.debug("settimeofday - ignored")
        return 0

    def sys_time(self, tloc: int) -> int:
        """time syscall."""
        now = int(time.time())
        if tloc:
            if self._emulator.pointer_size == 8:
                self._emulator.memory.write_u64(tloc, now)
            else:
                self._emulator.memory.write_u32(tloc, now)
        return now

    # ==================== Nanosleep ====================

    def sys_nanosleep(self, req: int, rem: int) -> int:
        """nanosleep syscall."""
        mem = self._emulator.memory

        if self._emulator.pointer_size == 8:
            sec = mem.read_u64(req)
            nsec = mem.read_u64(req + 8)
        else:
            sec = mem.read_u32(req)
            nsec = mem.read_u32(req + 4)

        # Don't actually sleep
        logger.debug(f"nanosleep({sec}s {nsec}ns) - skipped")

        if rem:
            if self._emulator.pointer_size == 8:
                mem.write_u64(rem, 0)
                mem.write_u64(rem + 8, 0)
            else:
                mem.write_u32(rem, 0)
                mem.write_u32(rem + 4, 0)

        return 0

    # ==================== Interval Timers ====================

    def sys_getitimer(self, which: int, curr_value: int) -> int:
        """getitimer syscall."""
        if which not in self._itimers:
            return -Errno.EINVAL

        timer = self._itimers[which]
        mem = self._emulator.memory

        if self._emulator.pointer_size == 8:
            # struct itimerval (with timeval)
            mem.write_u64(curr_value, timer['interval'][0])      # it_interval.tv_sec
            mem.write_u64(curr_value + 8, timer['interval'][1])  # it_interval.tv_usec
            mem.write_u64(curr_value + 16, timer['value'][0])    # it_value.tv_sec
            mem.write_u64(curr_value + 24, timer['value'][1])    # it_value.tv_usec
        else:
            mem.write_u32(curr_value, timer['interval'][0])
            mem.write_u32(curr_value + 4, timer['interval'][1])
            mem.write_u32(curr_value + 8, timer['value'][0])
            mem.write_u32(curr_value + 12, timer['value'][1])

        return 0

    def sys_setitimer(self, which: int, new_value: int, old_value: int) -> int:
        """setitimer syscall."""
        if which not in self._itimers:
            return -Errno.EINVAL

        mem = self._emulator.memory
        timer = self._itimers[which]

        # Save old value
        if old_value:
            self.sys_getitimer(which, old_value)

        # Set new value
        if self._emulator.pointer_size == 8:
            timer['interval'] = (mem.read_u64(new_value), mem.read_u64(new_value + 8))
            timer['value'] = (mem.read_u64(new_value + 16), mem.read_u64(new_value + 24))
        else:
            timer['interval'] = (mem.read_u32(new_value), mem.read_u32(new_value + 4))
            timer['value'] = (mem.read_u32(new_value + 8), mem.read_u32(new_value + 12))

        return 0

    # ==================== POSIX Timers ====================

    def sys_timer_create(self, clockid: int, sevp: int, timerid: int) -> int:
        """timer_create syscall."""
        timer_id = self._timer_counter
        self._timer_counter += 1

        self._timers[timer_id] = {
            'clockid': clockid,
            'value': (0, 0),
            'interval': (0, 0),
            'overrun': 0,
        }

        self._emulator.memory.write_u32(timerid, timer_id)
        return 0

    def sys_timer_settime(self, timerid: int, flags: int,
                          new_value: int, old_value: int) -> int:
        """timer_settime syscall."""
        if timerid not in self._timers:
            return -Errno.EINVAL

        timer = self._timers[timerid]
        mem = self._emulator.memory

        # Save old value
        if old_value:
            if self._emulator.pointer_size == 8:
                mem.write_u64(old_value, timer['interval'][0])
                mem.write_u64(old_value + 8, timer['interval'][1])
                mem.write_u64(old_value + 16, timer['value'][0])
                mem.write_u64(old_value + 24, timer['value'][1])
            else:
                mem.write_u32(old_value, timer['interval'][0])
                mem.write_u32(old_value + 4, timer['interval'][1])
                mem.write_u32(old_value + 8, timer['value'][0])
                mem.write_u32(old_value + 12, timer['value'][1])

        # Set new value (itimerspec)
        if self._emulator.pointer_size == 8:
            timer['interval'] = (mem.read_u64(new_value), mem.read_u64(new_value + 8))
            timer['value'] = (mem.read_u64(new_value + 16), mem.read_u64(new_value + 24))
        else:
            timer['interval'] = (mem.read_u32(new_value), mem.read_u32(new_value + 4))
            timer['value'] = (mem.read_u32(new_value + 8), mem.read_u32(new_value + 12))

        return 0

    def sys_timer_gettime(self, timerid: int, curr_value: int) -> int:
        """timer_gettime syscall."""
        if timerid not in self._timers:
            return -Errno.EINVAL

        timer = self._timers[timerid]
        mem = self._emulator.memory

        if self._emulator.pointer_size == 8:
            mem.write_u64(curr_value, timer['interval'][0])
            mem.write_u64(curr_value + 8, timer['interval'][1])
            mem.write_u64(curr_value + 16, timer['value'][0])
            mem.write_u64(curr_value + 24, timer['value'][1])
        else:
            mem.write_u32(curr_value, timer['interval'][0])
            mem.write_u32(curr_value + 4, timer['interval'][1])
            mem.write_u32(curr_value + 8, timer['value'][0])
            mem.write_u32(curr_value + 12, timer['value'][1])

        return 0

    def sys_timer_getoverrun(self, timerid: int) -> int:
        """timer_getoverrun syscall."""
        if timerid not in self._timers:
            return -Errno.EINVAL
        return self._timers[timerid]['overrun']

    def sys_timer_delete(self, timerid: int) -> int:
        """timer_delete syscall."""
        if timerid in self._timers:
            del self._timers[timerid]
        return 0

    # ==================== Alarm ====================

    def sys_alarm(self, seconds: int) -> int:
        """alarm syscall."""
        # Return remaining time from previous alarm (0 = no previous)
        return 0

    # ==================== Timestamp Operations ====================

    def sys_utimensat(self, dirfd: int, pathname: int,
                      times: int, flags: int) -> int:
        """utimensat syscall."""
        # Accept any timestamp change
        return 0

    def sys_futimesat(self, dirfd: int, pathname: int, times: int) -> int:
        """futimesat syscall."""
        return 0

    def sys_utime(self, filename: int, times: int) -> int:
        """utime syscall."""
        return 0

    def sys_utimes(self, filename: int, times: int) -> int:
        """utimes syscall."""
        return 0

    # ==================== Adjtimex ====================

    def sys_adjtimex(self, buf: int) -> int:
        """adjtimex syscall."""
        # Return TIME_OK
        return 0

    def sys_clock_adjtime(self, clk_id: int, buf: int) -> int:
        """clock_adjtime syscall."""
        return 0
