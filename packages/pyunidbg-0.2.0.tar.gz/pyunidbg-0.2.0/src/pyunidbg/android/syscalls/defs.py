"""Linux syscall numbers and error definitions."""

from enum import IntEnum


class Errno(IntEnum):
    """Linux error numbers (negated for syscall returns)."""

    SUCCESS = 0
    EPERM = 1           # Operation not permitted
    ENOENT = 2          # No such file or directory
    ESRCH = 3           # No such process
    EINTR = 4           # Interrupted system call
    EIO = 5             # I/O error
    ENXIO = 6           # No such device or address
    E2BIG = 7           # Argument list too long
    ENOEXEC = 8         # Exec format error
    EBADF = 9           # Bad file descriptor
    ECHILD = 10         # No child processes
    EAGAIN = 11         # Try again / Resource temporarily unavailable
    ENOMEM = 12         # Out of memory
    EACCES = 13         # Permission denied
    EFAULT = 14         # Bad address
    ENOTBLK = 15        # Block device required
    EBUSY = 16          # Device or resource busy
    EEXIST = 17         # File exists
    EXDEV = 18          # Cross-device link
    ENODEV = 19         # No such device
    ENOTDIR = 20        # Not a directory
    EISDIR = 21         # Is a directory
    EINVAL = 22         # Invalid argument
    ENFILE = 23         # File table overflow
    EMFILE = 24         # Too many open files
    ENOTTY = 25         # Not a typewriter
    ETXTBSY = 26        # Text file busy
    EFBIG = 27          # File too large
    ENOSPC = 28         # No space left on device
    ESPIPE = 29         # Illegal seek
    EROFS = 30          # Read-only file system
    EMLINK = 31         # Too many links
    EPIPE = 32          # Broken pipe
    EDOM = 33           # Math argument out of domain
    ERANGE = 34         # Math result not representable
    EDEADLK = 35        # Resource deadlock would occur
    ENAMETOOLONG = 36   # File name too long
    ENOLCK = 37         # No record locks available
    ENOSYS = 38         # Function not implemented
    ENOTEMPTY = 39      # Directory not empty
    ELOOP = 40          # Too many symbolic links
    EWOULDBLOCK = 11    # Same as EAGAIN
    ENOMSG = 42         # No message of desired type
    EIDRM = 43          # Identifier removed
    ENOTSOCK = 88       # Socket operation on non-socket
    EDESTADDRREQ = 89   # Destination address required
    EMSGSIZE = 90       # Message too long
    EPROTOTYPE = 91     # Protocol wrong type for socket
    ENOPROTOOPT = 92    # Protocol not available
    EPROTONOSUPPORT = 93  # Protocol not supported
    ESOCKTNOSUPPORT = 94  # Socket type not supported
    EOPNOTSUPP = 95     # Operation not supported
    EPFNOSUPPORT = 96   # Protocol family not supported
    EAFNOSUPPORT = 97   # Address family not supported
    EADDRINUSE = 98     # Address already in use
    EADDRNOTAVAIL = 99  # Cannot assign requested address
    ENETDOWN = 100      # Network is down
    ENETUNREACH = 101   # Network is unreachable
    ENETRESET = 102     # Network dropped connection on reset
    ECONNABORTED = 103  # Software caused connection abort
    ECONNRESET = 104    # Connection reset by peer
    ENOBUFS = 105       # No buffer space available
    EISCONN = 106       # Transport endpoint already connected
    ENOTCONN = 107      # Transport endpoint not connected
    ESHUTDOWN = 108     # Cannot send after shutdown
    ETIMEDOUT = 110     # Connection timed out
    ECONNREFUSED = 111  # Connection refused
    EHOSTDOWN = 112     # Host is down
    EHOSTUNREACH = 113  # No route to host
    EALREADY = 114      # Operation already in progress
    EINPROGRESS = 115   # Operation now in progress


class SyscallARM64(IntEnum):
    """ARM64 (AArch64) Linux syscall numbers."""

    # I/O syscalls
    IO_SETUP = 0
    IO_DESTROY = 1
    IO_SUBMIT = 2
    IO_CANCEL = 3
    IO_GETEVENTS = 4

    # Extended attributes
    SETXATTR = 5
    LSETXATTR = 6
    FSETXATTR = 7
    GETXATTR = 8
    LGETXATTR = 9
    FGETXATTR = 10
    LISTXATTR = 11
    LLISTXATTR = 12
    FLISTXATTR = 13
    REMOVEXATTR = 14
    LREMOVEXATTR = 15
    FREMOVEXATTR = 16

    # Directory operations
    GETCWD = 17
    LOOKUP_DCOOKIE = 18

    # Event/Poll
    EVENTFD2 = 19
    EPOLL_CREATE1 = 20
    EPOLL_CTL = 21
    EPOLL_PWAIT = 22

    # File descriptor operations
    DUP = 23
    DUP3 = 24
    FCNTL = 25

    # Inotify
    INOTIFY_INIT1 = 26
    INOTIFY_ADD_WATCH = 27
    INOTIFY_RM_WATCH = 28

    # Device control
    IOCTL = 29
    IOPRIO_SET = 30
    IOPRIO_GET = 31
    FLOCK = 32

    # File system operations
    MKNODAT = 33
    MKDIRAT = 34
    UNLINKAT = 35
    SYMLINKAT = 36
    LINKAT = 37
    RENAMEAT = 38
    UMOUNT2 = 39
    MOUNT = 40
    PIVOT_ROOT = 41
    NFSSERVCTL = 42
    STATFS = 43
    FSTATFS = 44
    TRUNCATE = 45
    FTRUNCATE = 46
    FALLOCATE = 47
    FACCESSAT = 48
    CHDIR = 49
    FCHDIR = 50
    CHROOT = 51
    FCHMOD = 52
    FCHMODAT = 53
    FCHOWNAT = 54
    FCHOWN = 55

    # File I/O
    OPENAT = 56
    CLOSE = 57
    VHANGUP = 58
    PIPE2 = 59
    QUOTACTL = 60
    GETDENTS64 = 61
    LSEEK = 62
    READ = 63
    WRITE = 64
    READV = 65
    WRITEV = 66
    PREAD64 = 67
    PWRITE64 = 68
    PREADV = 69
    PWRITEV = 70
    SENDFILE = 71

    # Polling/Select
    PSELECT6 = 72
    PPOLL = 73
    SIGNALFD4 = 74

    # Splice operations
    VMSPLICE = 75
    SPLICE = 76
    TEE = 77

    # More file operations
    READLINKAT = 78
    NEWFSTATAT = 79
    FSTAT = 80
    SYNC = 81
    FSYNC = 82
    FDATASYNC = 83
    SYNC_FILE_RANGE = 84

    # Timer file descriptors
    TIMERFD_CREATE = 85
    TIMERFD_SETTIME = 86
    TIMERFD_GETTIME = 87
    UTIMENSAT = 88
    ACCT = 89

    # Capabilities
    CAPGET = 90
    CAPSET = 91
    PERSONALITY = 92

    # Process exit
    EXIT = 93
    EXIT_GROUP = 94
    WAITID = 95

    # Thread ID
    SET_TID_ADDRESS = 96
    UNSHARE = 97

    # Futex
    FUTEX = 98
    SET_ROBUST_LIST = 99
    GET_ROBUST_LIST = 100

    # Sleep
    NANOSLEEP = 101
    GETITIMER = 102
    SETITIMER = 103

    # Kernel module
    KEXEC_LOAD = 104
    INIT_MODULE = 105
    DELETE_MODULE = 106

    # Timer
    TIMER_CREATE = 107
    TIMER_GETTIME = 108
    TIMER_GETOVERRUN = 109
    TIMER_SETTIME = 110
    TIMER_DELETE = 111

    # Clock
    CLOCK_SETTIME = 112
    CLOCK_GETTIME = 113
    CLOCK_GETRES = 114
    CLOCK_NANOSLEEP = 115

    # System log
    SYSLOG = 116

    # Process tracing
    PTRACE = 117

    # Scheduler
    SCHED_SETPARAM = 118
    SCHED_SETSCHEDULER = 119
    SCHED_GETSCHEDULER = 120
    SCHED_GETPARAM = 121
    SCHED_SETAFFINITY = 122
    SCHED_GETAFFINITY = 123
    SCHED_YIELD = 124
    SCHED_GET_PRIORITY_MAX = 125
    SCHED_GET_PRIORITY_MIN = 126
    SCHED_RR_GET_INTERVAL = 127
    RESTART_SYSCALL = 128

    # Signals
    KILL = 129
    TKILL = 130
    TGKILL = 131
    SIGALTSTACK = 132
    RT_SIGSUSPEND = 133
    RT_SIGACTION = 134
    RT_SIGPROCMASK = 135
    RT_SIGPENDING = 136
    RT_SIGTIMEDWAIT = 137
    RT_SIGQUEUEINFO = 138
    RT_SIGRETURN = 139

    # Priority
    SETPRIORITY = 140
    GETPRIORITY = 141
    REBOOT = 142

    # User/Group IDs
    SETREGID = 143
    SETGID = 144
    SETREUID = 145
    SETUID = 146
    SETRESUID = 147
    GETRESUID = 148
    SETRESGID = 149
    GETRESGID = 150
    SETFSUID = 151
    SETFSGID = 152
    TIMES = 153
    SETPGID = 154
    GETPGID = 155
    GETSID = 156
    SETSID = 157
    GETGROUPS = 158
    SETGROUPS = 159

    # System info
    UNAME = 160
    SETHOSTNAME = 161
    SETDOMAINNAME = 162
    GETRLIMIT = 163
    SETRLIMIT = 164
    GETRUSAGE = 165
    UMASK = 166
    PRCTL = 167
    GETCPU = 168

    # Time
    GETTIMEOFDAY = 169
    SETTIMEOFDAY = 170
    ADJTIMEX = 171

    # Process/User IDs
    GETPID = 172
    GETPPID = 173
    GETUID = 174
    GETEUID = 175
    GETGID = 176
    GETEGID = 177
    GETTID = 178
    SYSINFO = 179

    # Message queues
    MQ_OPEN = 180
    MQ_UNLINK = 181
    MQ_TIMEDSEND = 182
    MQ_TIMEDRECEIVE = 183
    MQ_NOTIFY = 184
    MQ_GETSETATTR = 185

    # System V IPC
    MSGGET = 186
    MSGCTL = 187
    MSGRCV = 188
    MSGSND = 189
    SEMGET = 190
    SEMCTL = 191
    SEMTIMEDOP = 192
    SEMOP = 193
    SHMGET = 194
    SHMCTL = 195
    SHMAT = 196
    SHMDT = 197

    # Sockets
    SOCKET = 198
    SOCKETPAIR = 199
    BIND = 200
    LISTEN = 201
    ACCEPT = 202
    CONNECT = 203
    GETSOCKNAME = 204
    GETPEERNAME = 205
    SENDTO = 206
    RECVFROM = 207
    SETSOCKOPT = 208
    GETSOCKOPT = 209
    SHUTDOWN = 210
    SENDMSG = 211
    RECVMSG = 212
    READAHEAD = 213

    # Memory
    BRK = 214
    MUNMAP = 215
    MREMAP = 216
    ADD_KEY = 217
    REQUEST_KEY = 218
    KEYCTL = 219

    # Process
    CLONE = 220
    EXECVE = 221
    MMAP = 222
    FADVISE64 = 223
    SWAPON = 224
    SWAPOFF = 225
    MPROTECT = 226
    MSYNC = 227
    MLOCK = 228
    MUNLOCK = 229
    MLOCKALL = 230
    MUNLOCKALL = 231
    MINCORE = 232
    MADVISE = 233
    REMAP_FILE_PAGES = 234
    MBIND = 235
    GET_MEMPOLICY = 236
    SET_MEMPOLICY = 237
    MIGRATE_PAGES = 238
    MOVE_PAGES = 239
    RT_TGSIGQUEUEINFO = 240
    PERF_EVENT_OPEN = 241
    ACCEPT4 = 242
    RECVMMSG = 243

    # More recent syscalls
    WAIT4 = 260
    PRLIMIT64 = 261
    FANOTIFY_INIT = 262
    FANOTIFY_MARK = 263
    NAME_TO_HANDLE_AT = 264
    OPEN_BY_HANDLE_AT = 265
    CLOCK_ADJTIME = 266
    SYNCFS = 267
    SETNS = 268
    SENDMMSG = 269
    PROCESS_VM_READV = 270
    PROCESS_VM_WRITEV = 271
    KCMP = 272
    FINIT_MODULE = 273
    SCHED_SETATTR = 274
    SCHED_GETATTR = 275
    RENAMEAT2 = 276
    SECCOMP = 277
    GETRANDOM = 278
    MEMFD_CREATE = 279
    BPF = 280
    EXECVEAT = 281
    USERFAULTFD = 282
    MEMBARRIER = 283
    MLOCK2 = 284
    COPY_FILE_RANGE = 285
    PREADV2 = 286
    PWRITEV2 = 287
    PKEY_MPROTECT = 288
    PKEY_ALLOC = 289
    PKEY_FREE = 290
    STATX = 291


class SyscallARM32(IntEnum):
    """ARM32 Linux syscall numbers."""

    RESTART_SYSCALL = 0
    EXIT = 1
    FORK = 2
    READ = 3
    WRITE = 4
    OPEN = 5
    CLOSE = 6
    WAITPID = 7
    CREAT = 8
    LINK = 9
    UNLINK = 10
    EXECVE = 11
    CHDIR = 12
    TIME = 13
    MKNOD = 14
    CHMOD = 15
    LCHOWN = 16
    LSEEK = 19
    GETPID = 20
    MOUNT = 21
    UMOUNT = 22
    SETUID = 23
    GETUID = 24
    PTRACE = 26
    ALARM = 27
    PAUSE = 29
    UTIME = 30
    ACCESS = 33
    NICE = 34
    SYNC = 36
    KILL = 37
    RENAME = 38
    MKDIR = 39
    RMDIR = 40
    DUP = 41
    PIPE = 42
    TIMES = 43
    BRK = 45
    SETGID = 46
    GETGID = 47
    GETEUID = 49
    GETEGID = 50
    ACCT = 51
    UMOUNT2 = 52
    IOCTL = 54
    FCNTL = 55
    SETPGID = 57
    UMASK = 60
    CHROOT = 61
    DUP2 = 63
    GETPPID = 64
    GETPGRP = 65
    SETSID = 66
    SIGACTION = 67
    SETREUID = 70
    SETREGID = 71
    SIGSUSPEND = 72
    SIGPENDING = 73
    SETHOSTNAME = 74
    SETRLIMIT = 75
    GETRLIMIT = 76
    GETRUSAGE = 77
    GETTIMEOFDAY = 78
    SETTIMEOFDAY = 79
    GETGROUPS = 80
    SETGROUPS = 81
    SYMLINK = 83
    READLINK = 85
    USELIB = 86
    SWAPON = 87
    REBOOT = 88
    MMAP = 90
    MUNMAP = 91
    TRUNCATE = 92
    FTRUNCATE = 93
    FCHMOD = 94
    FCHOWN = 95
    GETPRIORITY = 96
    SETPRIORITY = 97
    STATFS = 99
    FSTATFS = 100
    SOCKETCALL = 102
    SYSLOG = 103
    SETITIMER = 104
    GETITIMER = 105
    STAT = 106
    LSTAT = 107
    FSTAT = 108
    VHANGUP = 111
    WAIT4 = 114
    SWAPOFF = 115
    SYSINFO = 116
    FSYNC = 118
    SIGRETURN = 119
    CLONE = 120
    SETDOMAINNAME = 121
    UNAME = 122
    ADJTIMEX = 124
    MPROTECT = 125
    SIGPROCMASK = 126
    INIT_MODULE = 128
    DELETE_MODULE = 129
    QUOTACTL = 131
    GETPGID = 132
    FCHDIR = 133
    PERSONALITY = 136
    SETFSUID = 138
    SETFSGID = 139
    LLSEEK = 140
    GETDENTS = 141
    SELECT = 142
    FLOCK = 143
    MSYNC = 144
    READV = 145
    WRITEV = 146
    GETSID = 147
    FDATASYNC = 148
    MLOCK = 150
    MUNLOCK = 151
    MLOCKALL = 152
    MUNLOCKALL = 153
    SCHED_SETPARAM = 154
    SCHED_GETPARAM = 155
    SCHED_SETSCHEDULER = 156
    SCHED_GETSCHEDULER = 157
    SCHED_YIELD = 158
    SCHED_GET_PRIORITY_MAX = 159
    SCHED_GET_PRIORITY_MIN = 160
    SCHED_RR_GET_INTERVAL = 161
    NANOSLEEP = 162
    MREMAP = 163
    SETRESUID = 164
    GETRESUID = 165
    POLL = 168
    SETRESGID = 170
    GETRESGID = 171
    PRCTL = 172
    RT_SIGRETURN = 173
    RT_SIGACTION = 174
    RT_SIGPROCMASK = 175
    RT_SIGPENDING = 176
    RT_SIGTIMEDWAIT = 177
    RT_SIGQUEUEINFO = 178
    RT_SIGSUSPEND = 179
    PREAD64 = 180
    PWRITE64 = 181
    CHOWN = 182
    GETCWD = 183
    CAPGET = 184
    CAPSET = 185
    SIGALTSTACK = 186
    SENDFILE = 187
    VFORK = 190
    UGETRLIMIT = 191
    MMAP2 = 192
    TRUNCATE64 = 193
    FTRUNCATE64 = 194
    STAT64 = 195
    LSTAT64 = 196
    FSTAT64 = 197
    LCHOWN32 = 198
    GETUID32 = 199
    GETGID32 = 200
    GETEUID32 = 201
    GETEGID32 = 202
    SETREUID32 = 203
    SETREGID32 = 204
    GETGROUPS32 = 205
    SETGROUPS32 = 206
    FCHOWN32 = 207
    SETRESUID32 = 208
    GETRESUID32 = 209
    SETRESGID32 = 210
    GETRESGID32 = 211
    CHOWN32 = 212
    SETUID32 = 213
    SETGID32 = 214
    SETFSUID32 = 215
    SETFSGID32 = 216
    GETDENTS64 = 217
    PIVOT_ROOT = 218
    MINCORE = 219
    MADVISE = 220
    FCNTL64 = 221
    GETTID = 224
    READAHEAD = 225
    SETXATTR = 226
    LSETXATTR = 227
    FSETXATTR = 228
    GETXATTR = 229
    LGETXATTR = 230
    FGETXATTR = 231
    LISTXATTR = 232
    LLISTXATTR = 233
    FLISTXATTR = 234
    REMOVEXATTR = 235
    LREMOVEXATTR = 236
    FREMOVEXATTR = 237
    TKILL = 238
    SENDFILE64 = 239
    FUTEX = 240
    SCHED_SETAFFINITY = 241
    SCHED_GETAFFINITY = 242
    IO_SETUP = 243
    IO_DESTROY = 244
    IO_GETEVENTS = 245
    IO_SUBMIT = 246
    IO_CANCEL = 247
    EXIT_GROUP = 248
    EPOLL_CREATE = 250
    EPOLL_CTL = 251
    EPOLL_WAIT = 252
    SET_TID_ADDRESS = 256
    TIMER_CREATE = 257
    TIMER_SETTIME = 258
    TIMER_GETTIME = 259
    TIMER_GETOVERRUN = 260
    TIMER_DELETE = 261
    CLOCK_SETTIME = 262
    CLOCK_GETTIME = 263
    CLOCK_GETRES = 264
    CLOCK_NANOSLEEP = 265
    STATFS64 = 266
    FSTATFS64 = 267
    TGKILL = 268
    UTIMES = 269
    MQ_OPEN = 274
    MQ_UNLINK = 275
    MQ_TIMEDSEND = 276
    MQ_TIMEDRECEIVE = 277
    MQ_NOTIFY = 278
    MQ_GETSETATTR = 279
    WAITID = 280
    SOCKET = 281
    BIND = 282
    CONNECT = 283
    LISTEN = 284
    ACCEPT = 285
    GETSOCKNAME = 286
    GETPEERNAME = 287
    SOCKETPAIR = 288
    SEND = 289
    SENDTO = 290
    RECV = 291
    RECVFROM = 292
    SHUTDOWN = 293
    SETSOCKOPT = 294
    GETSOCKOPT = 295
    SENDMSG = 296
    RECVMSG = 297
    SEMOP = 298
    SEMGET = 299
    SEMCTL = 300
    MSGSND = 301
    MSGRCV = 302
    MSGGET = 303
    MSGCTL = 304
    SHMAT = 305
    SHMDT = 306
    SHMGET = 307
    SHMCTL = 308
    ADD_KEY = 309
    REQUEST_KEY = 310
    KEYCTL = 311
    SEMTIMEDOP = 312
    IOPRIO_SET = 314
    IOPRIO_GET = 315
    INOTIFY_INIT = 316
    INOTIFY_ADD_WATCH = 317
    INOTIFY_RM_WATCH = 318
    OPENAT = 322
    MKDIRAT = 323
    MKNODAT = 324
    FCHOWNAT = 325
    FUTIMESAT = 326
    FSTATAT64 = 327
    UNLINKAT = 328
    RENAMEAT = 329
    LINKAT = 330
    SYMLINKAT = 331
    READLINKAT = 332
    FCHMODAT = 333
    FACCESSAT = 334
    PSELECT6 = 335
    PPOLL = 336
    UNSHARE = 337
    SET_ROBUST_LIST = 338
    GET_ROBUST_LIST = 339
    SPLICE = 340
    TEE = 342
    VMSPLICE = 343
    GETCPU = 345
    EPOLL_PWAIT = 346
    UTIMENSAT = 348
    SIGNALFD = 349
    TIMERFD_CREATE = 350
    EVENTFD = 351
    FALLOCATE = 352
    TIMERFD_SETTIME = 353
    TIMERFD_GETTIME = 354
    SIGNALFD4 = 355
    EVENTFD2 = 356
    EPOLL_CREATE1 = 357
    DUP3 = 358
    PIPE2 = 359
    INOTIFY_INIT1 = 360
    PREADV = 361
    PWRITEV = 362
    RECVMMSG = 365
    ACCEPT4 = 366
    PRLIMIT64 = 369
    SYNCFS = 373
    SENDMMSG = 374
    SETNS = 375
    PROCESS_VM_READV = 376
    PROCESS_VM_WRITEV = 377
    FINIT_MODULE = 379
    SCHED_SETATTR = 380
    SCHED_GETATTR = 381
    RENAMEAT2 = 382
    SECCOMP = 383
    GETRANDOM = 384
    MEMFD_CREATE = 385
    EXECVEAT = 387
    MLOCK2 = 390
    COPY_FILE_RANGE = 391
    PREADV2 = 392
    PWRITEV2 = 393
    STATX = 397
    CLOCK_ADJTIME = 372


# Open flags
class OpenFlags:
    O_RDONLY = 0
    O_WRONLY = 1
    O_RDWR = 2
    O_CREAT = 0o100
    O_EXCL = 0o200
    O_NOCTTY = 0o400
    O_TRUNC = 0o1000
    O_APPEND = 0o2000
    O_NONBLOCK = 0o4000
    O_DSYNC = 0o10000
    O_SYNC = 0o4010000
    O_DIRECTORY = 0o200000
    O_NOFOLLOW = 0o400000
    O_CLOEXEC = 0o2000000
    O_DIRECT = 0o40000
    O_LARGEFILE = 0o100000
    O_NOATIME = 0o1000000
    O_PATH = 0o10000000
    O_TMPFILE = 0o20200000


# Memory protection flags
class MmapProt:
    PROT_NONE = 0
    PROT_READ = 1
    PROT_WRITE = 2
    PROT_EXEC = 4


# Memory mapping flags
class MmapFlags:
    MAP_SHARED = 0x01
    MAP_PRIVATE = 0x02
    MAP_FIXED = 0x10
    MAP_ANONYMOUS = 0x20
    MAP_GROWSDOWN = 0x100
    MAP_LOCKED = 0x2000
    MAP_NORESERVE = 0x4000
    MAP_POPULATE = 0x8000
    MAP_STACK = 0x20000
    MAP_HUGETLB = 0x40000


# Clock IDs
class ClockId:
    CLOCK_REALTIME = 0
    CLOCK_MONOTONIC = 1
    CLOCK_PROCESS_CPUTIME_ID = 2
    CLOCK_THREAD_CPUTIME_ID = 3
    CLOCK_MONOTONIC_RAW = 4
    CLOCK_REALTIME_COARSE = 5
    CLOCK_MONOTONIC_COARSE = 6
    CLOCK_BOOTTIME = 7


# Futex operations
class FutexOp:
    FUTEX_WAIT = 0
    FUTEX_WAKE = 1
    FUTEX_FD = 2
    FUTEX_REQUEUE = 3
    FUTEX_CMP_REQUEUE = 4
    FUTEX_WAKE_OP = 5
    FUTEX_WAIT_BITSET = 9
    FUTEX_WAKE_BITSET = 10
    FUTEX_PRIVATE_FLAG = 128
    FUTEX_CLOCK_REALTIME = 256


# prctl options
class PrctlOption:
    PR_SET_PDEATHSIG = 1
    PR_GET_PDEATHSIG = 2
    PR_GET_DUMPABLE = 3
    PR_SET_DUMPABLE = 4
    PR_SET_NAME = 15
    PR_GET_NAME = 16
    PR_GET_SECCOMP = 21
    PR_SET_SECCOMP = 22
    PR_CAPBSET_READ = 23
    PR_CAPBSET_DROP = 24
    PR_GET_SECUREBITS = 27
    PR_SET_SECUREBITS = 28
    PR_SET_NO_NEW_PRIVS = 38
    PR_GET_NO_NEW_PRIVS = 39


# Socket domains
class AddressFamily:
    AF_UNSPEC = 0
    AF_UNIX = 1
    AF_LOCAL = 1
    AF_INET = 2
    AF_INET6 = 10
    AF_NETLINK = 16
    AF_PACKET = 17
    AF_BLUETOOTH = 31


# Socket types
class SocketType:
    SOCK_STREAM = 1
    SOCK_DGRAM = 2
    SOCK_RAW = 3
    SOCK_RDM = 4
    SOCK_SEQPACKET = 5
    SOCK_CLOEXEC = 0o2000000
    SOCK_NONBLOCK = 0o4000


# fcntl commands
class FcntlCmd:
    F_DUPFD = 0
    F_GETFD = 1
    F_SETFD = 2
    F_GETFL = 3
    F_SETFL = 4
    F_GETLK = 5
    F_SETLK = 6
    F_SETLKW = 7
    F_SETOWN = 8
    F_GETOWN = 9
    F_DUPFD_CLOEXEC = 1030


# ioctl requests
class IoctlRequest:
    TCGETS = 0x5401
    TCSETS = 0x5402
    TIOCGWINSZ = 0x5413
    TIOCSWINSZ = 0x5414
    FIONREAD = 0x541B
    FIONBIO = 0x5421


# Seek whence
class SeekWhence:
    SEEK_SET = 0
    SEEK_CUR = 1
    SEEK_END = 2


# AT_* constants for *at() syscalls
class AtFlags:
    AT_FDCWD = -100
    AT_SYMLINK_NOFOLLOW = 0x100
    AT_REMOVEDIR = 0x200
    AT_SYMLINK_FOLLOW = 0x400
    AT_NO_AUTOMOUNT = 0x800
    AT_EMPTY_PATH = 0x1000


# Signal numbers
class Signal:
    SIGHUP = 1
    SIGINT = 2
    SIGQUIT = 3
    SIGILL = 4
    SIGTRAP = 5
    SIGABRT = 6
    SIGBUS = 7
    SIGFPE = 8
    SIGKILL = 9
    SIGUSR1 = 10
    SIGSEGV = 11
    SIGUSR2 = 12
    SIGPIPE = 13
    SIGALRM = 14
    SIGTERM = 15
    SIGSTKFLT = 16
    SIGCHLD = 17
    SIGCONT = 18
    SIGSTOP = 19
    SIGTSTP = 20
    SIGTTIN = 21
    SIGTTOU = 22
    SIGURG = 23
    SIGXCPU = 24
    SIGXFSZ = 25
    SIGVTALRM = 26
    SIGPROF = 27
    SIGWINCH = 28
    SIGIO = 29
    SIGPWR = 30
    SIGSYS = 31
