"""
Reports Module - JSON/HTML Report Generation for PyUniDbg

This module provides comprehensive reporting capabilities for debugging sessions,
including execution traces, memory snapshots, function call logs, and analysis results.
"""

from __future__ import annotations

import datetime
import html
import json
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator
from dataclasses import asdict, dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Optional,
    Tuple,
    Union,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    # Core classes
    "ReportGenerator",
    "Report",
    "ReportSection",
    # Section types
    "ExecutionSection",
    "MemorySection",
    "RegisterSection",
    "CallTraceSection",
    "HookSection",
    "LibrarySection",
    "SymbolSection",
    "CustomSection",
    # Data classes
    "ExecutionEvent",
    "MemoryRegion",
    "RegisterSnapshot",
    "FunctionCall",
    "HookEvent",
    "LibraryInfo",
    "SymbolInfo",
    # Enums
    "ReportFormat",
    "EventType",
    # Builder
    "ReportBuilder",
    # Templates
    "HTMLTemplate",
]


class ReportFormat(Enum):
    """Report output formats."""
    JSON = auto()
    HTML = auto()
    MARKDOWN = auto()
    TEXT = auto()


class EventType(Enum):
    """Types of events that can be recorded."""
    INSTRUCTION = "instruction"
    MEMORY_READ = "memory_read"
    MEMORY_WRITE = "memory_write"
    SYSCALL = "syscall"
    HOOK_TRIGGER = "hook_trigger"
    LIBRARY_LOAD = "library_load"
    SYMBOL_RESOLVE = "symbol_resolve"
    EXCEPTION = "exception"
    BREAKPOINT = "breakpoint"
    FUNCTION_ENTER = "function_enter"
    FUNCTION_EXIT = "function_exit"


@dataclass
class ExecutionEvent:
    """Represents an execution event."""
    event_type: EventType
    address: int
    timestamp: float
    details: dict[str, Any] = field(default_factory=dict)
    instruction: str | None = None
    registers: dict[str, int] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_type": self.event_type.value,
            "address": hex(self.address),
            "timestamp": self.timestamp,
            "details": self.details,
            "instruction": self.instruction,
            "registers": {k: hex(v) for k, v in (self.registers or {}).items()},
        }


@dataclass
class MemoryRegion:
    """Represents a memory region."""
    start: int
    end: int
    size: int
    permissions: str
    name: str | None = None
    module: str | None = None
    data_preview: bytes | None = None

    def to_dict(self) -> dict[str, Any]:
        result = {
            "start": hex(self.start),
            "end": hex(self.end),
            "size": self.size,
            "size_formatted": self._format_size(self.size),
            "permissions": self.permissions,
            "name": self.name,
            "module": self.module,
        }
        if self.data_preview:
            result["data_preview"] = self.data_preview.hex()[:64] + "..."
        return result

    @staticmethod
    def _format_size(size: int) -> str:
        """Format size in human-readable form."""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"


@dataclass
class RegisterSnapshot:
    """Snapshot of register state."""
    timestamp: float
    address: int
    registers: dict[str, int]
    context: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "address": hex(self.address),
            "registers": {k: hex(v) for k, v in self.registers.items()},
            "context": self.context,
        }


@dataclass
class FunctionCall:
    """Represents a function call."""
    name: str
    address: int
    args: list[Any]
    return_value: Any | None = None
    caller: int | None = None
    timestamp: float = 0.0
    duration: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "address": hex(self.address),
            "args": [hex(a) if isinstance(a, int) else a for a in self.args],
            "return_value": hex(self.return_value) if isinstance(self.return_value, int) else self.return_value,
            "caller": hex(self.caller) if self.caller else None,
            "timestamp": self.timestamp,
            "duration_ms": self.duration * 1000 if self.duration else None,
        }


@dataclass
class HookEvent:
    """Represents a hook trigger event."""
    hook_name: str
    hook_type: str
    address: int
    timestamp: float
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "hook_name": self.hook_name,
            "hook_type": self.hook_type,
            "address": hex(self.address),
            "timestamp": self.timestamp,
            "data": self.data,
        }


@dataclass
class LibraryInfo:
    """Information about a loaded library."""
    name: str
    path: str
    base_address: int
    size: int
    load_time: float
    symbols_count: int = 0
    dependencies: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "path": self.path,
            "base_address": hex(self.base_address),
            "size": self.size,
            "size_formatted": MemoryRegion._format_size(self.size),
            "load_time": self.load_time,
            "symbols_count": self.symbols_count,
            "dependencies": self.dependencies,
        }


@dataclass
class SymbolInfo:
    """Information about a symbol."""
    name: str
    address: int
    symbol_type: str
    library: str | None = None
    size: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "address": hex(self.address),
            "type": self.symbol_type,
            "library": self.library,
            "size": self.size,
        }


class ReportSection(ABC):
    """Base class for report sections."""

    def __init__(self, title: str, description: str = ""):
        self.title = title
        self.description = description

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """Convert section to dictionary."""
        pass

    @abstractmethod
    def to_html(self) -> str:
        """Convert section to HTML."""
        pass

    @abstractmethod
    def to_markdown(self) -> str:
        """Convert section to Markdown."""
        pass

    @abstractmethod
    def to_text(self) -> str:
        """Convert section to plain text."""
        pass


class ExecutionSection(ReportSection):
    """Section for execution trace events."""

    def __init__(self, title: str = "Execution Trace", description: str = ""):
        super().__init__(title, description)
        self.events: list[ExecutionEvent] = []

    def add_event(self, event: ExecutionEvent) -> None:
        """Add an execution event."""
        self.events.append(event)

    def to_dict(self) -> dict[str, Any]:
        return {
            "section_type": "execution",
            "title": self.title,
            "description": self.description,
            "event_count": len(self.events),
            "events": [e.to_dict() for e in self.events],
        }

    def to_html(self) -> str:
        rows = []
        for e in self.events:
            rows.append(f"""
                <tr>
                    <td><code>{hex(e.address)}</code></td>
                    <td><span class="event-type event-{e.event_type.value}">{e.event_type.value}</span></td>
                    <td><code>{html.escape(e.instruction or '-')}</code></td>
                    <td>{html.escape(str(e.details))}</td>
                </tr>
            """)

        return f"""
        <section class="report-section execution-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <p class="event-count">Total Events: {len(self.events)}</p>
            <table class="data-table">
                <thead>
                    <tr><th>Address</th><th>Type</th><th>Instruction</th><th>Details</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </section>
        """

    def to_markdown(self) -> str:
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
            f"**Total Events:** {len(self.events)}",
            "",
            "| Address | Type | Instruction | Details |",
            "|---------|------|-------------|---------|",
        ]
        for e in self.events:
            lines.append(
                f"| `{hex(e.address)}` | {e.event_type.value} | "
                f"`{e.instruction or '-'}` | {e.details} |"
            )
        return "\n".join(lines)

    def to_text(self) -> str:
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            f"Total Events: {len(self.events)}",
            "",
        ]
        for e in self.events:
            lines.append(
                f"  {hex(e.address):14} {e.event_type.value:15} "
                f"{e.instruction or '-':20} {e.details}"
            )
        return "\n".join(lines)


class MemorySection(ReportSection):
    """Section for memory regions."""

    def __init__(self, title: str = "Memory Map", description: str = ""):
        super().__init__(title, description)
        self.regions: list[MemoryRegion] = []

    def add_region(self, region: MemoryRegion) -> None:
        """Add a memory region."""
        self.regions.append(region)

    def to_dict(self) -> dict[str, Any]:
        total_size = sum(r.size for r in self.regions)
        return {
            "section_type": "memory",
            "title": self.title,
            "description": self.description,
            "region_count": len(self.regions),
            "total_size": total_size,
            "total_size_formatted": MemoryRegion._format_size(total_size),
            "regions": [r.to_dict() for r in self.regions],
        }

    def to_html(self) -> str:
        rows = []
        for r in self.regions:
            rows.append(f"""
                <tr>
                    <td><code>{hex(r.start)}</code></td>
                    <td><code>{hex(r.end)}</code></td>
                    <td>{MemoryRegion._format_size(r.size)}</td>
                    <td><span class="perms">{html.escape(r.permissions)}</span></td>
                    <td>{html.escape(r.name or '-')}</td>
                    <td>{html.escape(r.module or '-')}</td>
                </tr>
            """)

        total_size = sum(r.size for r in self.regions)
        return f"""
        <section class="report-section memory-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <p>Regions: {len(self.regions)} | Total Size: {MemoryRegion._format_size(total_size)}</p>
            <table class="data-table">
                <thead>
                    <tr><th>Start</th><th>End</th><th>Size</th><th>Perms</th><th>Name</th><th>Module</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </section>
        """

    def to_markdown(self) -> str:
        total_size = sum(r.size for r in self.regions)
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
            f"**Regions:** {len(self.regions)} | **Total Size:** {MemoryRegion._format_size(total_size)}",
            "",
            "| Start | End | Size | Perms | Name | Module |",
            "|-------|-----|------|-------|------|--------|",
        ]
        for r in self.regions:
            lines.append(
                f"| `{hex(r.start)}` | `{hex(r.end)}` | "
                f"{MemoryRegion._format_size(r.size)} | {r.permissions} | "
                f"{r.name or '-'} | {r.module or '-'} |"
            )
        return "\n".join(lines)

    def to_text(self) -> str:
        total_size = sum(r.size for r in self.regions)
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            f"Regions: {len(self.regions)} | Total Size: {MemoryRegion._format_size(total_size)}",
            "",
            f"  {'Start':14} {'End':14} {'Size':10} {'Perms':6} {'Name':20} {'Module'}",
            f"  {'-' * 14} {'-' * 14} {'-' * 10} {'-' * 6} {'-' * 20} {'-' * 15}",
        ]
        for r in self.regions:
            lines.append(
                f"  {hex(r.start):14} {hex(r.end):14} "
                f"{MemoryRegion._format_size(r.size):10} {r.permissions:6} "
                f"{(r.name or '-'):20} {r.module or '-'}"
            )
        return "\n".join(lines)


class RegisterSection(ReportSection):
    """Section for register snapshots."""

    def __init__(self, title: str = "Register States", description: str = ""):
        super().__init__(title, description)
        self.snapshots: list[RegisterSnapshot] = []

    def add_snapshot(self, snapshot: RegisterSnapshot) -> None:
        """Add a register snapshot."""
        self.snapshots.append(snapshot)

    def to_dict(self) -> dict[str, Any]:
        return {
            "section_type": "registers",
            "title": self.title,
            "description": self.description,
            "snapshot_count": len(self.snapshots),
            "snapshots": [s.to_dict() for s in self.snapshots],
        }

    def to_html(self) -> str:
        snapshot_html = []
        for i, s in enumerate(self.snapshots):
            regs = "".join(
                f"<span class='reg'>{k}=<code>{hex(v)}</code></span> "
                for k, v in s.registers.items()
            )
            snapshot_html.append(f"""
                <div class="snapshot">
                    <h4>Snapshot #{i+1} at <code>{hex(s.address)}</code></h4>
                    <p class="context">{html.escape(s.context or '')}</p>
                    <div class="registers">{regs}</div>
                </div>
            """)

        return f"""
        <section class="report-section register-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <p>Snapshots: {len(self.snapshots)}</p>
            <div class="snapshots">{''.join(snapshot_html)}</div>
        </section>
        """

    def to_markdown(self) -> str:
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
            f"**Snapshots:** {len(self.snapshots)}",
            "",
        ]
        for i, s in enumerate(self.snapshots):
            lines.append(f"### Snapshot #{i+1} at `{hex(s.address)}`")
            if s.context:
                lines.append(f"*{s.context}*")
            lines.append("")
            lines.append("| Register | Value |")
            lines.append("|----------|-------|")
            for k, v in s.registers.items():
                lines.append(f"| {k} | `{hex(v)}` |")
            lines.append("")
        return "\n".join(lines)

    def to_text(self) -> str:
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            f"Snapshots: {len(self.snapshots)}",
            "",
        ]
        for i, s in enumerate(self.snapshots):
            lines.append(f"  --- Snapshot #{i+1} at {hex(s.address)} ---")
            if s.context:
                lines.append(f"  Context: {s.context}")
            for k, v in s.registers.items():
                lines.append(f"    {k:8} = {hex(v)}")
            lines.append("")
        return "\n".join(lines)


class CallTraceSection(ReportSection):
    """Section for function call traces."""

    def __init__(self, title: str = "Call Trace", description: str = ""):
        super().__init__(title, description)
        self.calls: list[FunctionCall] = []

    def add_call(self, call: FunctionCall) -> None:
        """Add a function call."""
        self.calls.append(call)

    def to_dict(self) -> dict[str, Any]:
        return {
            "section_type": "call_trace",
            "title": self.title,
            "description": self.description,
            "call_count": len(self.calls),
            "calls": [c.to_dict() for c in self.calls],
        }

    def to_html(self) -> str:
        rows = []
        for c in self.calls:
            args_str = ", ".join(
                hex(a) if isinstance(a, int) else str(a) for a in c.args
            )
            ret_str = hex(c.return_value) if isinstance(c.return_value, int) else str(c.return_value)
            rows.append(f"""
                <tr>
                    <td><code>{html.escape(c.name)}</code></td>
                    <td><code>{hex(c.address)}</code></td>
                    <td><code>{html.escape(args_str)}</code></td>
                    <td><code>{html.escape(ret_str if c.return_value is not None else '-')}</code></td>
                    <td>{f'{c.duration * 1000:.2f}ms' if c.duration else '-'}</td>
                </tr>
            """)

        return f"""
        <section class="report-section call-trace-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <p>Total Calls: {len(self.calls)}</p>
            <table class="data-table">
                <thead>
                    <tr><th>Function</th><th>Address</th><th>Arguments</th><th>Return</th><th>Duration</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </section>
        """

    def to_markdown(self) -> str:
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
            f"**Total Calls:** {len(self.calls)}",
            "",
            "| Function | Address | Arguments | Return | Duration |",
            "|----------|---------|-----------|--------|----------|",
        ]
        for c in self.calls:
            args_str = ", ".join(
                hex(a) if isinstance(a, int) else str(a) for a in c.args
            )
            ret_str = hex(c.return_value) if isinstance(c.return_value, int) else str(c.return_value)
            duration = f'{c.duration * 1000:.2f}ms' if c.duration else '-'
            lines.append(
                f"| `{c.name}` | `{hex(c.address)}` | `{args_str}` | "
                f"`{ret_str if c.return_value is not None else '-'}` | {duration} |"
            )
        return "\n".join(lines)

    def to_text(self) -> str:
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            f"Total Calls: {len(self.calls)}",
            "",
        ]
        for c in self.calls:
            args_str = ", ".join(
                hex(a) if isinstance(a, int) else str(a) for a in c.args
            )
            ret_str = hex(c.return_value) if isinstance(c.return_value, int) else str(c.return_value)
            lines.append(f"  {c.name}({args_str}) -> {ret_str if c.return_value is not None else '?'}")
            lines.append(f"    @ {hex(c.address)}")
        return "\n".join(lines)


class HookSection(ReportSection):
    """Section for hook events."""

    def __init__(self, title: str = "Hook Events", description: str = ""):
        super().__init__(title, description)
        self.events: list[HookEvent] = []

    def add_event(self, event: HookEvent) -> None:
        """Add a hook event."""
        self.events.append(event)

    def to_dict(self) -> dict[str, Any]:
        return {
            "section_type": "hooks",
            "title": self.title,
            "description": self.description,
            "event_count": len(self.events),
            "events": [e.to_dict() for e in self.events],
        }

    def to_html(self) -> str:
        rows = []
        for e in self.events:
            rows.append(f"""
                <tr>
                    <td><code>{html.escape(e.hook_name)}</code></td>
                    <td><span class="hook-type">{html.escape(e.hook_type)}</span></td>
                    <td><code>{hex(e.address)}</code></td>
                    <td><code>{html.escape(str(e.data))}</code></td>
                </tr>
            """)

        return f"""
        <section class="report-section hook-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <p>Total Events: {len(self.events)}</p>
            <table class="data-table">
                <thead>
                    <tr><th>Hook Name</th><th>Type</th><th>Address</th><th>Data</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </section>
        """

    def to_markdown(self) -> str:
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
            f"**Total Events:** {len(self.events)}",
            "",
            "| Hook Name | Type | Address | Data |",
            "|-----------|------|---------|------|",
        ]
        for e in self.events:
            lines.append(
                f"| `{e.hook_name}` | {e.hook_type} | `{hex(e.address)}` | `{e.data}` |"
            )
        return "\n".join(lines)

    def to_text(self) -> str:
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            f"Total Events: {len(self.events)}",
            "",
        ]
        for e in self.events:
            lines.append(f"  [{e.hook_type}] {e.hook_name} @ {hex(e.address)}")
            if e.data:
                lines.append(f"    Data: {e.data}")
        return "\n".join(lines)


class LibrarySection(ReportSection):
    """Section for loaded libraries."""

    def __init__(self, title: str = "Loaded Libraries", description: str = ""):
        super().__init__(title, description)
        self.libraries: list[LibraryInfo] = []

    def add_library(self, library: LibraryInfo) -> None:
        """Add a library."""
        self.libraries.append(library)

    def to_dict(self) -> dict[str, Any]:
        return {
            "section_type": "libraries",
            "title": self.title,
            "description": self.description,
            "library_count": len(self.libraries),
            "libraries": [lib.to_dict() for lib in self.libraries],
        }

    def to_html(self) -> str:
        rows = []
        for lib in self.libraries:
            deps = ", ".join(lib.dependencies) if lib.dependencies else "-"
            rows.append(f"""
                <tr>
                    <td><strong>{html.escape(lib.name)}</strong></td>
                    <td><code>{hex(lib.base_address)}</code></td>
                    <td>{MemoryRegion._format_size(lib.size)}</td>
                    <td>{lib.symbols_count}</td>
                    <td>{html.escape(deps)}</td>
                </tr>
            """)

        return f"""
        <section class="report-section library-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <p>Total Libraries: {len(self.libraries)}</p>
            <table class="data-table">
                <thead>
                    <tr><th>Name</th><th>Base Address</th><th>Size</th><th>Symbols</th><th>Dependencies</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </section>
        """

    def to_markdown(self) -> str:
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
            f"**Total Libraries:** {len(self.libraries)}",
            "",
            "| Name | Base Address | Size | Symbols | Dependencies |",
            "|------|--------------|------|---------|--------------|",
        ]
        for lib in self.libraries:
            deps = ", ".join(lib.dependencies) if lib.dependencies else "-"
            lines.append(
                f"| {lib.name} | `{hex(lib.base_address)}` | "
                f"{MemoryRegion._format_size(lib.size)} | {lib.symbols_count} | {deps} |"
            )
        return "\n".join(lines)

    def to_text(self) -> str:
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            f"Total Libraries: {len(self.libraries)}",
            "",
        ]
        for lib in self.libraries:
            lines.append(f"  {lib.name}")
            lines.append(f"    Base: {hex(lib.base_address)}")
            lines.append(f"    Size: {MemoryRegion._format_size(lib.size)}")
            lines.append(f"    Symbols: {lib.symbols_count}")
            if lib.dependencies:
                lines.append(f"    Depends: {', '.join(lib.dependencies)}")
            lines.append("")
        return "\n".join(lines)


class SymbolSection(ReportSection):
    """Section for symbols."""

    def __init__(self, title: str = "Symbols", description: str = ""):
        super().__init__(title, description)
        self.symbols: list[SymbolInfo] = []

    def add_symbol(self, symbol: SymbolInfo) -> None:
        """Add a symbol."""
        self.symbols.append(symbol)

    def to_dict(self) -> dict[str, Any]:
        by_type: dict[str, int] = {}
        for s in self.symbols:
            by_type[s.symbol_type] = by_type.get(s.symbol_type, 0) + 1

        return {
            "section_type": "symbols",
            "title": self.title,
            "description": self.description,
            "symbol_count": len(self.symbols),
            "by_type": by_type,
            "symbols": [s.to_dict() for s in self.symbols],
        }

    def to_html(self) -> str:
        rows = []
        for s in self.symbols:
            rows.append(f"""
                <tr>
                    <td><code>{html.escape(s.name)}</code></td>
                    <td><code>{hex(s.address)}</code></td>
                    <td><span class="symbol-type">{html.escape(s.symbol_type)}</span></td>
                    <td>{html.escape(s.library or '-')}</td>
                </tr>
            """)

        return f"""
        <section class="report-section symbol-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <p>Total Symbols: {len(self.symbols)}</p>
            <table class="data-table">
                <thead>
                    <tr><th>Name</th><th>Address</th><th>Type</th><th>Library</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </section>
        """

    def to_markdown(self) -> str:
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
            f"**Total Symbols:** {len(self.symbols)}",
            "",
            "| Name | Address | Type | Library |",
            "|------|---------|------|---------|",
        ]
        for s in self.symbols:
            lines.append(
                f"| `{s.name}` | `{hex(s.address)}` | {s.symbol_type} | {s.library or '-'} |"
            )
        return "\n".join(lines)

    def to_text(self) -> str:
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            f"Total Symbols: {len(self.symbols)}",
            "",
            f"  {'Name':40} {'Address':14} {'Type':10} {'Library'}",
            f"  {'-' * 40} {'-' * 14} {'-' * 10} {'-' * 20}",
        ]
        for s in self.symbols:
            lines.append(
                f"  {s.name:40} {hex(s.address):14} {s.symbol_type:10} {s.library or '-'}"
            )
        return "\n".join(lines)


class CustomSection(ReportSection):
    """Section for custom data."""

    def __init__(self, title: str, description: str = "", data: dict[str, Any] | None = None):
        super().__init__(title, description)
        self.data: dict[str, Any] = data or {}

    def set_data(self, key: str, value: Any) -> None:
        """Set a data value."""
        self.data[key] = value

    def to_dict(self) -> dict[str, Any]:
        return {
            "section_type": "custom",
            "title": self.title,
            "description": self.description,
            "data": self.data,
        }

    def to_html(self) -> str:
        data_html = self._render_data_html(self.data)
        return f"""
        <section class="report-section custom-section">
            <h2>{html.escape(self.title)}</h2>
            <p class="section-description">{html.escape(self.description)}</p>
            <div class="custom-data">{data_html}</div>
        </section>
        """

    def _render_data_html(self, data: Any, indent: int = 0) -> str:
        """Recursively render data as HTML."""
        if isinstance(data, dict):
            items = []
            for k, v in data.items():
                items.append(f"<li><strong>{html.escape(str(k))}:</strong> {self._render_data_html(v, indent + 1)}</li>")
            return f"<ul class='data-list'>{''.join(items)}</ul>"
        elif isinstance(data, list):
            items = [f"<li>{self._render_data_html(item, indent + 1)}</li>" for item in data]
            return f"<ol class='data-list'>{''.join(items)}</ol>"
        elif isinstance(data, int) and data > 0xFFFF:
            return f"<code>{hex(data)}</code>"
        else:
            return f"<span>{html.escape(str(data))}</span>"

    def to_markdown(self) -> str:
        lines = [
            f"## {self.title}",
            "",
            self.description,
            "",
        ]
        lines.extend(self._render_data_markdown(self.data, 0))
        return "\n".join(lines)

    def _render_data_markdown(self, data: Any, indent: int) -> list[str]:
        """Recursively render data as Markdown."""
        prefix = "  " * indent
        lines = []
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, (dict, list)):
                    lines.append(f"{prefix}- **{k}:**")
                    lines.extend(self._render_data_markdown(v, indent + 1))
                else:
                    val = hex(v) if isinstance(v, int) and v > 0xFFFF else v
                    lines.append(f"{prefix}- **{k}:** `{val}`")
        elif isinstance(data, list):
            for item in data:
                if isinstance(item, (dict, list)):
                    lines.extend(self._render_data_markdown(item, indent + 1))
                else:
                    val = hex(item) if isinstance(item, int) and item > 0xFFFF else item
                    lines.append(f"{prefix}- `{val}`")
        return lines

    def to_text(self) -> str:
        lines = [
            f"{'=' * 60}",
            f"  {self.title}",
            f"{'=' * 60}",
            self.description,
            "",
        ]
        lines.extend(self._render_data_text(self.data, 0))
        return "\n".join(lines)

    def _render_data_text(self, data: Any, indent: int) -> list[str]:
        """Recursively render data as text."""
        prefix = "  " * (indent + 1)
        lines = []
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, (dict, list)):
                    lines.append(f"{prefix}{k}:")
                    lines.extend(self._render_data_text(v, indent + 1))
                else:
                    val = hex(v) if isinstance(v, int) and v > 0xFFFF else v
                    lines.append(f"{prefix}{k}: {val}")
        elif isinstance(data, list):
            for item in data:
                if isinstance(item, (dict, list)):
                    lines.extend(self._render_data_text(item, indent + 1))
                else:
                    val = hex(item) if isinstance(item, int) and item > 0xFFFF else item
                    lines.append(f"{prefix}- {val}")
        return lines


class HTMLTemplate:
    """HTML template for reports."""

    DEFAULT_CSS = """
    :root {
        --bg-color: #1a1a2e;
        --card-bg: #16213e;
        --text-color: #e6e6e6;
        --accent: #0f3460;
        --highlight: #e94560;
        --success: #4ecca3;
        --warning: #ffc107;
        --code-bg: #0a0a15;
    }
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: var(--bg-color);
        color: var(--text-color);
        line-height: 1.6;
        padding: 20px;
    }
    
    .report-container {
        max-width: 1400px;
        margin: 0 auto;
    }
    
    .report-header {
        background: linear-gradient(135deg, var(--accent), var(--card-bg));
        padding: 30px;
        border-radius: 12px;
        margin-bottom: 30px;
        border-left: 4px solid var(--highlight);
    }
    
    .report-header h1 {
        font-size: 2.5em;
        margin-bottom: 10px;
        color: #fff;
    }
    
    .report-meta {
        display: flex;
        gap: 20px;
        flex-wrap: wrap;
        color: #aaa;
    }
    
    .report-meta span {
        background: var(--bg-color);
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.9em;
    }
    
    .report-section {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 25px;
        border-left: 3px solid var(--accent);
    }
    
    .report-section h2 {
        color: var(--highlight);
        margin-bottom: 15px;
        font-size: 1.5em;
    }
    
    .section-description {
        color: #888;
        margin-bottom: 15px;
        font-style: italic;
    }
    
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }
    
    .data-table th {
        background: var(--accent);
        padding: 12px 15px;
        text-align: left;
        font-weight: 600;
    }
    
    .data-table td {
        padding: 10px 15px;
        border-bottom: 1px solid var(--bg-color);
    }
    
    .data-table tr:hover td {
        background: rgba(255, 255, 255, 0.05);
    }
    
    code {
        background: var(--code-bg);
        padding: 2px 6px;
        border-radius: 4px;
        font-family: 'Consolas', 'Monaco', monospace;
        font-size: 0.9em;
        color: var(--success);
    }
    
    .event-type {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 4px;
        font-size: 0.85em;
        font-weight: 500;
    }
    
    .event-instruction { background: #2196F3; }
    .event-memory_read { background: #4CAF50; }
    .event-memory_write { background: #FF9800; }
    .event-syscall { background: #9C27B0; }
    .event-hook_trigger { background: #E91E63; }
    .event-exception { background: #F44336; }
    
    .perms {
        font-family: monospace;
        background: var(--bg-color);
        padding: 2px 6px;
        border-radius: 3px;
    }
    
    .hook-type, .symbol-type {
        background: var(--accent);
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.85em;
    }
    
    .snapshot {
        background: var(--bg-color);
        padding: 15px;
        border-radius: 8px;
        margin: 10px 0;
    }
    
    .snapshot h4 {
        color: var(--success);
        margin-bottom: 10px;
    }
    
    .registers {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    
    .reg {
        background: var(--card-bg);
        padding: 5px 10px;
        border-radius: 4px;
    }
    
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin: 20px 0;
    }
    
    .summary-card {
        background: var(--bg-color);
        padding: 20px;
        border-radius: 8px;
        text-align: center;
    }
    
    .summary-card .value {
        font-size: 2em;
        font-weight: bold;
        color: var(--highlight);
    }
    
    .summary-card .label {
        color: #888;
        font-size: 0.9em;
    }
    
    .custom-data ul, .custom-data ol {
        margin-left: 20px;
        margin-top: 5px;
    }
    
    .custom-data li {
        margin: 5px 0;
    }
    
    .toc {
        background: var(--card-bg);
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 30px;
    }
    
    .toc h3 {
        margin-bottom: 15px;
        color: var(--highlight);
    }
    
    .toc ul {
        list-style: none;
    }
    
    .toc li {
        margin: 8px 0;
    }
    
    .toc a {
        color: var(--success);
        text-decoration: none;
    }
    
    .toc a:hover {
        text-decoration: underline;
    }
    
    @media print {
        body { background: #fff; color: #000; }
        .report-section { break-inside: avoid; }
    }
    """

    @classmethod
    def wrap(cls, title: str, content: str,
             metadata: dict[str, str] | None = None,
             custom_css: str | None = None) -> str:
        """Wrap content in a full HTML document."""
        css = custom_css or cls.DEFAULT_CSS

        meta_html = ""
        if metadata:
            meta_items = [
                f"<span><strong>{k}:</strong> {html.escape(str(v))}</span>"
                for k, v in metadata.items()
            ]
            meta_html = f'<div class="report-meta">{"".join(meta_items)}</div>'

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html.escape(title)}</title>
    <style>{css}</style>
</head>
<body>
    <div class="report-container">
        <header class="report-header">
            <h1>{html.escape(title)}</h1>
            {meta_html}
        </header>
        <main>
            {content}
        </main>
    </div>
</body>
</html>"""


@dataclass
class Report:
    """A complete report."""
    title: str
    description: str = ""
    sections: list[ReportSection] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime.datetime = field(default_factory=datetime.datetime.now)

    def add_section(self, section: ReportSection) -> None:
        """Add a section to the report."""
        self.sections.append(section)

    def to_json(self, indent: int = 2) -> str:
        """Export report as JSON."""
        data = {
            "title": self.title,
            "description": self.description,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata,
            "sections": [s.to_dict() for s in self.sections],
        }
        return json.dumps(data, indent=indent, default=str)

    def to_html(self, custom_css: str | None = None) -> str:
        """Export report as HTML."""
        # Build table of contents
        toc_items = [
            f'<li><a href="#section-{i}">{html.escape(s.title)}</a></li>'
            for i, s in enumerate(self.sections)
        ]
        toc = f"""
        <nav class="toc">
            <h3>Contents</h3>
            <ul>{"".join(toc_items)}</ul>
        </nav>
        """

        # Build sections
        section_html = []
        for i, section in enumerate(self.sections):
            html_content = section.to_html()
            # Add ID for TOC linking
            html_content = html_content.replace(
                'class="report-section',
                f'id="section-{i}" class="report-section',
                1
            )
            section_html.append(html_content)

        content = toc + "\n".join(section_html)

        metadata = {
            "Generated": self.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            **self.metadata,
        }

        return HTMLTemplate.wrap(
            self.title,
            content,
            metadata=metadata,
            custom_css=custom_css,
        )

    def to_markdown(self) -> str:
        """Export report as Markdown."""
        lines = [
            f"# {self.title}",
            "",
            self.description,
            "",
            f"*Generated: {self.created_at.strftime('%Y-%m-%d %H:%M:%S')}*",
            "",
            "---",
            "",
        ]

        # Metadata
        if self.metadata:
            lines.append("## Report Metadata")
            lines.append("")
            for k, v in self.metadata.items():
                lines.append(f"- **{k}:** {v}")
            lines.append("")
            lines.append("---")
            lines.append("")

        # Sections
        for section in self.sections:
            lines.append(section.to_markdown())
            lines.append("")
            lines.append("---")
            lines.append("")

        return "\n".join(lines)

    def to_text(self) -> str:
        """Export report as plain text."""
        lines = [
            "#" * 60,
            f"  {self.title}",
            "#" * 60,
            "",
            self.description,
            "",
            f"Generated: {self.created_at.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
        ]

        # Metadata
        if self.metadata:
            lines.append("Metadata:")
            for k, v in self.metadata.items():
                lines.append(f"  {k}: {v}")
            lines.append("")

        # Sections
        for section in self.sections:
            lines.append(section.to_text())
            lines.append("")

        return "\n".join(lines)

    def save(self, path: str | Path, format: ReportFormat | None = None) -> Path:
        """Save report to file.
        
        Args:
            path: Output path
            format: Output format (auto-detected from extension if not provided)
            
        Returns:
            Path to saved file
        """
        path = Path(path)

        # Auto-detect format from extension
        if format is None:
            ext = path.suffix.lower()
            format_map = {
                ".json": ReportFormat.JSON,
                ".html": ReportFormat.HTML,
                ".htm": ReportFormat.HTML,
                ".md": ReportFormat.MARKDOWN,
                ".markdown": ReportFormat.MARKDOWN,
                ".txt": ReportFormat.TEXT,
            }
            format = format_map.get(ext, ReportFormat.TEXT)

        # Generate content
        content_generators = {
            ReportFormat.JSON: self.to_json,
            ReportFormat.HTML: self.to_html,
            ReportFormat.MARKDOWN: self.to_markdown,
            ReportFormat.TEXT: self.to_text,
        }
        content = content_generators[format]()

        # Write file
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

        return path


class ReportBuilder:
    """Fluent builder for creating reports."""

    def __init__(self, title: str):
        self._title = title
        self._description = ""
        self._sections: list[ReportSection] = []
        self._metadata: dict[str, Any] = {}

    def description(self, desc: str) -> ReportBuilder:
        """Set report description."""
        self._description = desc
        return self

    def metadata(self, key: str, value: Any) -> ReportBuilder:
        """Add metadata."""
        self._metadata[key] = value
        return self

    def add_section(self, section: ReportSection) -> ReportBuilder:
        """Add a section."""
        self._sections.append(section)
        return self

    def execution_section(self, title: str = "Execution Trace",
                          description: str = "") -> ExecutionSectionBuilder:
        """Start building an execution section."""
        return ExecutionSectionBuilder(self, title, description)

    def memory_section(self, title: str = "Memory Map",
                       description: str = "") -> MemorySectionBuilder:
        """Start building a memory section."""
        return MemorySectionBuilder(self, title, description)

    def register_section(self, title: str = "Register States",
                         description: str = "") -> RegisterSectionBuilder:
        """Start building a register section."""
        return RegisterSectionBuilder(self, title, description)

    def call_trace_section(self, title: str = "Call Trace",
                           description: str = "") -> CallTraceSectionBuilder:
        """Start building a call trace section."""
        return CallTraceSectionBuilder(self, title, description)

    def hook_section(self, title: str = "Hook Events",
                     description: str = "") -> HookSectionBuilder:
        """Start building a hook section."""
        return HookSectionBuilder(self, title, description)

    def library_section(self, title: str = "Loaded Libraries",
                        description: str = "") -> LibrarySectionBuilder:
        """Start building a library section."""
        return LibrarySectionBuilder(self, title, description)

    def symbol_section(self, title: str = "Symbols",
                       description: str = "") -> SymbolSectionBuilder:
        """Start building a symbol section."""
        return SymbolSectionBuilder(self, title, description)

    def custom_section(self, title: str, description: str = "",
                       data: dict[str, Any] | None = None) -> ReportBuilder:
        """Add a custom section."""
        self._sections.append(CustomSection(title, description, data))
        return self

    def build(self) -> Report:
        """Build the report."""
        report = Report(
            title=self._title,
            description=self._description,
            sections=self._sections,
            metadata=self._metadata,
        )
        return report


class SectionBuilder(ABC):
    """Base class for section builders."""

    def __init__(self, parent: ReportBuilder):
        self._parent = parent

    @abstractmethod
    def _build_section(self) -> ReportSection:
        """Build the section."""
        pass

    def end(self) -> ReportBuilder:
        """Finish building section and return to report builder."""
        section = self._build_section()
        self._parent.add_section(section)
        return self._parent


class ExecutionSectionBuilder(SectionBuilder):
    """Builder for execution sections."""

    def __init__(self, parent: ReportBuilder, title: str, description: str):
        super().__init__(parent)
        self._section = ExecutionSection(title, description)

    def add_event(self, event_type: EventType, address: int,
                  timestamp: float = 0.0, **details) -> ExecutionSectionBuilder:
        """Add an execution event."""
        self._section.add_event(ExecutionEvent(
            event_type=event_type,
            address=address,
            timestamp=timestamp,
            details=details,
        ))
        return self

    def instruction(self, address: int, instruction: str,
                    registers: dict[str, int] | None = None) -> ExecutionSectionBuilder:
        """Add an instruction event."""
        import time
        self._section.add_event(ExecutionEvent(
            event_type=EventType.INSTRUCTION,
            address=address,
            timestamp=time.time(),
            instruction=instruction,
            registers=registers,
        ))
        return self

    def _build_section(self) -> ReportSection:
        return self._section


class MemorySectionBuilder(SectionBuilder):
    """Builder for memory sections."""

    def __init__(self, parent: ReportBuilder, title: str, description: str):
        super().__init__(parent)
        self._section = MemorySection(title, description)

    def add_region(self, start: int, end: int, permissions: str,
                   name: str | None = None,
                   module: str | None = None) -> MemorySectionBuilder:
        """Add a memory region."""
        self._section.add_region(MemoryRegion(
            start=start,
            end=end,
            size=end - start,
            permissions=permissions,
            name=name,
            module=module,
        ))
        return self

    def _build_section(self) -> ReportSection:
        return self._section


class RegisterSectionBuilder(SectionBuilder):
    """Builder for register sections."""

    def __init__(self, parent: ReportBuilder, title: str, description: str):
        super().__init__(parent)
        self._section = RegisterSection(title, description)

    def add_snapshot(self, address: int, registers: dict[str, int],
                     context: str | None = None) -> RegisterSectionBuilder:
        """Add a register snapshot."""
        import time
        self._section.add_snapshot(RegisterSnapshot(
            timestamp=time.time(),
            address=address,
            registers=registers,
            context=context,
        ))
        return self

    def _build_section(self) -> ReportSection:
        return self._section


class CallTraceSectionBuilder(SectionBuilder):
    """Builder for call trace sections."""

    def __init__(self, parent: ReportBuilder, title: str, description: str):
        super().__init__(parent)
        self._section = CallTraceSection(title, description)

    def add_call(self, name: str, address: int, args: list[Any],
                 return_value: Any | None = None,
                 caller: int | None = None) -> CallTraceSectionBuilder:
        """Add a function call."""
        import time
        self._section.add_call(FunctionCall(
            name=name,
            address=address,
            args=args,
            return_value=return_value,
            caller=caller,
            timestamp=time.time(),
        ))
        return self

    def _build_section(self) -> ReportSection:
        return self._section


class HookSectionBuilder(SectionBuilder):
    """Builder for hook sections."""

    def __init__(self, parent: ReportBuilder, title: str, description: str):
        super().__init__(parent)
        self._section = HookSection(title, description)

    def add_event(self, hook_name: str, hook_type: str, address: int,
                  **data) -> HookSectionBuilder:
        """Add a hook event."""
        import time
        self._section.add_event(HookEvent(
            hook_name=hook_name,
            hook_type=hook_type,
            address=address,
            timestamp=time.time(),
            data=data,
        ))
        return self

    def _build_section(self) -> ReportSection:
        return self._section


class LibrarySectionBuilder(SectionBuilder):
    """Builder for library sections."""

    def __init__(self, parent: ReportBuilder, title: str, description: str):
        super().__init__(parent)
        self._section = LibrarySection(title, description)

    def add_library(self, name: str, path: str, base_address: int, size: int,
                    symbols_count: int = 0,
                    dependencies: list[str] | None = None) -> LibrarySectionBuilder:
        """Add a library."""
        import time
        self._section.add_library(LibraryInfo(
            name=name,
            path=path,
            base_address=base_address,
            size=size,
            load_time=time.time(),
            symbols_count=symbols_count,
            dependencies=dependencies or [],
        ))
        return self

    def _build_section(self) -> ReportSection:
        return self._section


class SymbolSectionBuilder(SectionBuilder):
    """Builder for symbol sections."""

    def __init__(self, parent: ReportBuilder, title: str, description: str):
        super().__init__(parent)
        self._section = SymbolSection(title, description)

    def add_symbol(self, name: str, address: int, symbol_type: str,
                   library: str | None = None) -> SymbolSectionBuilder:
        """Add a symbol."""
        self._section.add_symbol(SymbolInfo(
            name=name,
            address=address,
            symbol_type=symbol_type,
            library=library,
        ))
        return self

    def _build_section(self) -> ReportSection:
        return self._section


class ReportGenerator:
    """High-level report generator that can capture emulator state."""

    def __init__(self, emulator: Emulator | None = None):
        self.emulator = emulator
        self._execution_events: list[ExecutionEvent] = []
        self._function_calls: list[FunctionCall] = []
        self._hook_events: list[HookEvent] = []
        self._register_snapshots: list[RegisterSnapshot] = []
        self._recording = False

    def start_recording(self) -> None:
        """Start recording events."""
        self._recording = True

    def stop_recording(self) -> None:
        """Stop recording events."""
        self._recording = False

    def record_instruction(self, address: int, instruction: str,
                          registers: dict[str, int] | None = None) -> None:
        """Record an instruction execution."""
        if not self._recording:
            return
        import time
        self._execution_events.append(ExecutionEvent(
            event_type=EventType.INSTRUCTION,
            address=address,
            timestamp=time.time(),
            instruction=instruction,
            registers=registers,
        ))

    def record_memory_access(self, address: int, size: int,
                             is_write: bool, value: int | None = None) -> None:
        """Record a memory access."""
        if not self._recording:
            return
        import time
        self._execution_events.append(ExecutionEvent(
            event_type=EventType.MEMORY_WRITE if is_write else EventType.MEMORY_READ,
            address=address,
            timestamp=time.time(),
            details={"size": size, "value": value},
        ))

    def record_function_call(self, name: str, address: int, args: list[Any],
                            caller: int | None = None) -> None:
        """Record a function call."""
        if not self._recording:
            return
        import time
        self._function_calls.append(FunctionCall(
            name=name,
            address=address,
            args=args,
            caller=caller,
            timestamp=time.time(),
        ))

    def record_hook_trigger(self, hook_name: str, hook_type: str,
                           address: int, **data) -> None:
        """Record a hook trigger."""
        if not self._recording:
            return
        import time
        self._hook_events.append(HookEvent(
            hook_name=hook_name,
            hook_type=hook_type,
            address=address,
            timestamp=time.time(),
            data=data,
        ))

    def snapshot_registers(self, address: int, registers: dict[str, int],
                          context: str | None = None) -> None:
        """Take a register snapshot."""
        import time
        self._register_snapshots.append(RegisterSnapshot(
            timestamp=time.time(),
            address=address,
            registers=registers.copy(),
            context=context,
        ))

    def generate_report(self, title: str = "PyUniDbg Debug Report",
                        include_memory: bool = True,
                        include_execution: bool = True,
                        include_calls: bool = True,
                        include_hooks: bool = True,
                        include_registers: bool = True) -> Report:
        """Generate a comprehensive report from recorded data.
        
        Args:
            title: Report title
            include_memory: Include memory map section
            include_execution: Include execution trace section
            include_calls: Include call trace section
            include_hooks: Include hook events section
            include_registers: Include register snapshots section
            
        Returns:
            Generated report
        """
        builder = ReportBuilder(title)
        builder.description("Comprehensive debug session report")

        # Add metadata
        try:
            from pyunidbg import __version__ as _pyu_ver
        except Exception:
            _pyu_ver = "unknown"
        builder.metadata("PyUniDbg Version", _pyu_ver)
        if self.emulator:
            builder.metadata("Architecture", str(self.emulator.arch))

        # Execution section
        if include_execution and self._execution_events:
            exec_section = ExecutionSection("Execution Trace",
                                           f"Recorded {len(self._execution_events)} events")
            for event in self._execution_events:
                exec_section.add_event(event)
            builder.add_section(exec_section)

        # Call trace section
        if include_calls and self._function_calls:
            call_section = CallTraceSection("Function Calls",
                                           f"Recorded {len(self._function_calls)} calls")
            for call in self._function_calls:
                call_section.add_call(call)
            builder.add_section(call_section)

        # Hook events section
        if include_hooks and self._hook_events:
            hook_section = HookSection("Hook Events",
                                      f"Recorded {len(self._hook_events)} hook triggers")
            for event in self._hook_events:
                hook_section.add_event(event)
            builder.add_section(hook_section)

        # Register snapshots section
        if include_registers and self._register_snapshots:
            reg_section = RegisterSection("Register Snapshots",
                                         f"{len(self._register_snapshots)} snapshots captured")
            for snapshot in self._register_snapshots:
                reg_section.add_snapshot(snapshot)
            builder.add_section(reg_section)

        return builder.build()

    def clear(self) -> None:
        """Clear all recorded data."""
        self._execution_events.clear()
        self._function_calls.clear()
        self._hook_events.clear()
        self._register_snapshots.clear()
