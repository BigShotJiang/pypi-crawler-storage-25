"""
Mach-O binary format parser and loader.

Supports:
- Mach-O 32-bit and 64-bit
- Fat/Universal binaries
- Segments and sections
- Load commands
- Symbol tables
- Dynamic linking info
- Code signature handling

References:
- https://opensource.apple.com/source/xnu/xnu-7195.81.3/EXTERNAL_HEADERS/mach-o/loader.h
"""

import io
import logging
import struct
from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== Mach-O Magic Numbers ====================

class MachOMagic(IntEnum):
    """Mach-O magic numbers."""
    MH_MAGIC = 0xFEEDFACE      # 32-bit big-endian
    MH_CIGAM = 0xCEFAEDFE      # 32-bit little-endian
    MH_MAGIC_64 = 0xFEEDFACF   # 64-bit big-endian
    MH_CIGAM_64 = 0xCFFAEDFE   # 64-bit little-endian
    FAT_MAGIC = 0xCAFEBABE     # Fat binary big-endian
    FAT_CIGAM = 0xBEBAFECA     # Fat binary little-endian


class CPUType(IntEnum):
    """CPU type constants."""
    CPU_TYPE_ANY = -1
    CPU_TYPE_VAX = 1
    CPU_TYPE_MC680x0 = 6
    CPU_TYPE_X86 = 7
    CPU_TYPE_I386 = 7
    CPU_TYPE_X86_64 = 0x01000007
    CPU_TYPE_MC98000 = 10
    CPU_TYPE_HPPA = 11
    CPU_TYPE_ARM = 12
    CPU_TYPE_ARM64 = 0x0100000C
    CPU_TYPE_ARM64_32 = 0x0200000C
    CPU_TYPE_MC88000 = 13
    CPU_TYPE_SPARC = 14
    CPU_TYPE_I860 = 15
    CPU_TYPE_POWERPC = 18
    CPU_TYPE_POWERPC64 = 0x01000012


class CPUSubtype(IntEnum):
    """CPU subtype constants."""
    CPU_SUBTYPE_ARM_ALL = 0
    CPU_SUBTYPE_ARM_V4T = 5
    CPU_SUBTYPE_ARM_V6 = 6
    CPU_SUBTYPE_ARM_V5TEJ = 7
    CPU_SUBTYPE_ARM_XSCALE = 8
    CPU_SUBTYPE_ARM_V7 = 9
    CPU_SUBTYPE_ARM_V7F = 10
    CPU_SUBTYPE_ARM_V7S = 11
    CPU_SUBTYPE_ARM_V7K = 12
    CPU_SUBTYPE_ARM_V8 = 13
    CPU_SUBTYPE_ARM_V6M = 14
    CPU_SUBTYPE_ARM_V7M = 15
    CPU_SUBTYPE_ARM_V7EM = 16
    CPU_SUBTYPE_ARM64_ALL = 0
    CPU_SUBTYPE_ARM64_V8 = 1
    CPU_SUBTYPE_ARM64E = 2


class FileType(IntEnum):
    """Mach-O file types."""
    MH_OBJECT = 0x1        # Relocatable object file
    MH_EXECUTE = 0x2       # Executable
    MH_FVMLIB = 0x3        # Fixed VM shared library
    MH_CORE = 0x4          # Core dump
    MH_PRELOAD = 0x5       # Preloaded executable
    MH_DYLIB = 0x6         # Dynamic library
    MH_DYLINKER = 0x7      # Dynamic linker
    MH_BUNDLE = 0x8        # Bundle
    MH_DYLIB_STUB = 0x9    # Shared library stub
    MH_DSYM = 0xA          # Debug symbols
    MH_KEXT_BUNDLE = 0xB   # Kernel extension


class MHFlags(IntFlag):
    """Mach-O header flags."""
    MH_NOUNDEFS = 0x1
    MH_INCRLINK = 0x2
    MH_DYLDLINK = 0x4
    MH_BINDATLOAD = 0x8
    MH_PREBOUND = 0x10
    MH_SPLIT_SEGS = 0x20
    MH_LAZY_INIT = 0x40
    MH_TWOLEVEL = 0x80
    MH_FORCE_FLAT = 0x100
    MH_NOMULTIDEFS = 0x200
    MH_NOFIXPREBINDING = 0x400
    MH_PREBINDABLE = 0x800
    MH_ALLMODSBOUND = 0x1000
    MH_SUBSECTIONS_VIA_SYMBOLS = 0x2000
    MH_CANONICAL = 0x4000
    MH_WEAK_DEFINES = 0x8000
    MH_BINDS_TO_WEAK = 0x10000
    MH_ALLOW_STACK_EXECUTION = 0x20000
    MH_ROOT_SAFE = 0x40000
    MH_SETUID_SAFE = 0x80000
    MH_NO_REEXPORTED_DYLIBS = 0x100000
    MH_PIE = 0x200000
    MH_DEAD_STRIPPABLE_DYLIB = 0x400000
    MH_HAS_TLV_DESCRIPTORS = 0x800000
    MH_NO_HEAP_EXECUTION = 0x1000000
    MH_APP_EXTENSION_SAFE = 0x2000000


class LoadCommand(IntEnum):
    """Load command types."""
    LC_REQ_DYLD = 0x80000000

    LC_SEGMENT = 0x1
    LC_SYMTAB = 0x2
    LC_SYMSEG = 0x3
    LC_THREAD = 0x4
    LC_UNIXTHREAD = 0x5
    LC_LOADFVMLIB = 0x6
    LC_IDFVMLIB = 0x7
    LC_IDENT = 0x8
    LC_FVMFILE = 0x9
    LC_PREPAGE = 0xA
    LC_DYSYMTAB = 0xB
    LC_LOAD_DYLIB = 0xC
    LC_ID_DYLIB = 0xD
    LC_LOAD_DYLINKER = 0xE
    LC_ID_DYLINKER = 0xF
    LC_PREBOUND_DYLIB = 0x10
    LC_ROUTINES = 0x11
    LC_SUB_FRAMEWORK = 0x12
    LC_SUB_UMBRELLA = 0x13
    LC_SUB_CLIENT = 0x14
    LC_SUB_LIBRARY = 0x15
    LC_TWOLEVEL_HINTS = 0x16
    LC_PREBIND_CKSUM = 0x17
    LC_LOAD_WEAK_DYLIB = 0x18 | 0x80000000
    LC_SEGMENT_64 = 0x19
    LC_ROUTINES_64 = 0x1A
    LC_UUID = 0x1B
    LC_RPATH = 0x1C | 0x80000000
    LC_CODE_SIGNATURE = 0x1D
    LC_SEGMENT_SPLIT_INFO = 0x1E
    LC_REEXPORT_DYLIB = 0x1F | 0x80000000
    LC_LAZY_LOAD_DYLIB = 0x20
    LC_ENCRYPTION_INFO = 0x21
    LC_DYLD_INFO = 0x22
    LC_DYLD_INFO_ONLY = 0x22 | 0x80000000
    LC_LOAD_UPWARD_DYLIB = 0x23 | 0x80000000
    LC_VERSION_MIN_MACOSX = 0x24
    LC_VERSION_MIN_IPHONEOS = 0x25
    LC_FUNCTION_STARTS = 0x26
    LC_DYLD_ENVIRONMENT = 0x27
    LC_MAIN = 0x28 | 0x80000000
    LC_DATA_IN_CODE = 0x29
    LC_SOURCE_VERSION = 0x2A
    LC_DYLIB_CODE_SIGN_DRS = 0x2B
    LC_ENCRYPTION_INFO_64 = 0x2C
    LC_LINKER_OPTION = 0x2D
    LC_LINKER_OPTIMIZATION_HINT = 0x2E
    LC_VERSION_MIN_TVOS = 0x2F
    LC_VERSION_MIN_WATCHOS = 0x30
    LC_NOTE = 0x31
    LC_BUILD_VERSION = 0x32
    LC_DYLD_EXPORTS_TRIE = 0x33 | 0x80000000
    LC_DYLD_CHAINED_FIXUPS = 0x34 | 0x80000000


class VMProt(IntFlag):
    """Virtual memory protection flags."""
    VM_PROT_NONE = 0x0
    VM_PROT_READ = 0x1
    VM_PROT_WRITE = 0x2
    VM_PROT_EXECUTE = 0x4
    VM_PROT_DEFAULT = VM_PROT_READ | VM_PROT_WRITE
    VM_PROT_ALL = VM_PROT_READ | VM_PROT_WRITE | VM_PROT_EXECUTE


# ==================== Data Structures ====================

@dataclass
class MachOHeader:
    """Mach-O file header."""
    magic: int
    cputype: int
    cpusubtype: int
    filetype: int
    ncmds: int
    sizeofcmds: int
    flags: int
    reserved: int = 0  # Only for 64-bit

    @property
    def is_64bit(self) -> bool:
        return self.magic in (MachOMagic.MH_MAGIC_64, MachOMagic.MH_CIGAM_64)

    @property
    def is_little_endian(self) -> bool:
        return self.magic in (MachOMagic.MH_CIGAM, MachOMagic.MH_CIGAM_64)


@dataclass
class MachOSection:
    """Mach-O section."""
    sectname: str
    segname: str
    addr: int
    size: int
    offset: int
    align: int
    reloff: int
    nreloc: int
    flags: int
    reserved1: int
    reserved2: int
    reserved3: int = 0  # Only for 64-bit
    data: bytes = b''


@dataclass
class MachOSegment:
    """Mach-O segment."""
    cmd: int
    cmdsize: int
    segname: str
    vmaddr: int
    vmsize: int
    fileoff: int
    filesize: int
    maxprot: int
    initprot: int
    nsects: int
    flags: int
    sections: list[MachOSection] = field(default_factory=list)
    data: bytes = b''


@dataclass
class MachOSymbol:
    """Mach-O symbol table entry."""
    name: str
    n_type: int
    n_sect: int
    n_desc: int
    n_value: int

    @property
    def is_external(self) -> bool:
        return bool(self.n_type & 0x01)

    @property
    def is_defined(self) -> bool:
        return (self.n_type & 0x0E) != 0

    @property
    def is_undefined(self) -> bool:
        return (self.n_type & 0x0E) == 0


@dataclass
class DylibInfo:
    """Dynamic library info."""
    name: str
    timestamp: int
    current_version: int
    compatibility_version: int


@dataclass
class MachOFile:
    """Parsed Mach-O file."""
    header: MachOHeader
    segments: list[MachOSegment] = field(default_factory=list)
    symbols: list[MachOSymbol] = field(default_factory=list)
    dylibs: list[DylibInfo] = field(default_factory=list)
    entry_point: int = 0
    uuid: bytes = b''
    min_version: tuple[int, int, int] = (0, 0, 0)
    sdk_version: tuple[int, int, int] = (0, 0, 0)

    # Symbol lookup cache
    _symbol_cache: dict[str, MachOSymbol] = field(default_factory=dict)

    def find_symbol(self, name: str) -> MachOSymbol | None:
        """Find symbol by name."""
        if not self._symbol_cache:
            for sym in self.symbols:
                self._symbol_cache[sym.name] = sym
        return self._symbol_cache.get(name)

    def find_segment(self, name: str) -> MachOSegment | None:
        """Find segment by name."""
        for seg in self.segments:
            if seg.segname == name:
                return seg
        return None

    def find_section(self, segname: str, sectname: str) -> MachOSection | None:
        """Find section by segment and section name."""
        seg = self.find_segment(segname)
        if seg:
            for sect in seg.sections:
                if sect.sectname == sectname:
                    return sect
        return None


# ==================== Parser ====================

class MachOParser:
    """Mach-O binary parser."""

    def __init__(self, data: bytes):
        self.data = data
        self.stream = io.BytesIO(data)
        self.is_64bit = False
        self.is_little_endian = True
        self.endian = '<'

    def parse(self) -> MachOFile:
        """Parse Mach-O file."""
        # Check for fat binary
        magic = struct.unpack('>I', self.data[:4])[0]

        if magic in (MachOMagic.FAT_MAGIC, MachOMagic.FAT_CIGAM):
            return self._parse_fat_binary()
        else:
            return self._parse_macho()

    def _parse_fat_binary(self) -> MachOFile:
        """Parse fat/universal binary, return best architecture."""
        self.stream.seek(0)
        magic = struct.unpack('>I', self.stream.read(4))[0]
        nfat_arch = struct.unpack('>I', self.stream.read(4))[0]

        # Prefer ARM64, then ARM
        best_arch = None
        best_priority = -1

        for _ in range(nfat_arch):
            cputype = struct.unpack('>I', self.stream.read(4))[0]
            cpusubtype = struct.unpack('>I', self.stream.read(4))[0]
            offset = struct.unpack('>I', self.stream.read(4))[0]
            size = struct.unpack('>I', self.stream.read(4))[0]
            align = struct.unpack('>I', self.stream.read(4))[0]

            priority = 0
            if cputype == CPUType.CPU_TYPE_ARM64:
                priority = 3
            elif cputype == CPUType.CPU_TYPE_ARM:
                priority = 2
            elif cputype == CPUType.CPU_TYPE_X86_64:
                priority = 1

            if priority > best_priority:
                best_priority = priority
                best_arch = (offset, size)

        if best_arch:
            offset, size = best_arch
            arch_data = self.data[offset:offset + size]
            parser = MachOParser(arch_data)
            return parser._parse_macho()

        raise ValueError("No suitable architecture found in fat binary")

    def _parse_macho(self) -> MachOFile:
        """Parse single-architecture Mach-O."""
        self.stream.seek(0)

        # Parse header
        header = self._parse_header()

        macho = MachOFile(header=header)

        # Parse load commands
        for _ in range(header.ncmds):
            self._parse_load_command(macho)

        return macho

    def _parse_header(self) -> MachOHeader:
        """Parse Mach-O header."""
        magic = struct.unpack('<I', self.stream.read(4))[0]

        # Determine endianness and bitness
        if magic == MachOMagic.MH_MAGIC:
            self.is_64bit = False
            self.is_little_endian = False
            self.endian = '>'
        elif magic == MachOMagic.MH_CIGAM:
            self.is_64bit = False
            self.is_little_endian = True
            self.endian = '<'
        elif magic == MachOMagic.MH_MAGIC_64:
            self.is_64bit = True
            self.is_little_endian = False
            self.endian = '>'
        elif magic == MachOMagic.MH_CIGAM_64:
            self.is_64bit = True
            self.is_little_endian = True
            self.endian = '<'
        else:
            raise ValueError(f"Invalid Mach-O magic: 0x{magic:08X}")

        cputype = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        cpusubtype = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        filetype = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        ncmds = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        sizeofcmds = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        flags = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        reserved = 0
        if self.is_64bit:
            reserved = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        return MachOHeader(
            magic=magic,
            cputype=cputype,
            cpusubtype=cpusubtype,
            filetype=filetype,
            ncmds=ncmds,
            sizeofcmds=sizeofcmds,
            flags=flags,
            reserved=reserved
        )

    def _parse_load_command(self, macho: MachOFile) -> None:
        """Parse a load command."""
        start_pos = self.stream.tell()

        cmd = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        cmdsize = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        if cmd == LoadCommand.LC_SEGMENT:
            self._parse_segment(macho, cmd, cmdsize, is_64=False)
        elif cmd == LoadCommand.LC_SEGMENT_64:
            self._parse_segment(macho, cmd, cmdsize, is_64=True)
        elif cmd == LoadCommand.LC_SYMTAB:
            self._parse_symtab(macho)
        elif cmd in (LoadCommand.LC_LOAD_DYLIB, LoadCommand.LC_LOAD_WEAK_DYLIB,
                     LoadCommand.LC_REEXPORT_DYLIB, LoadCommand.LC_LAZY_LOAD_DYLIB):
            self._parse_dylib(macho, start_pos)
        elif cmd == LoadCommand.LC_MAIN:
            self._parse_main(macho)
        elif cmd == LoadCommand.LC_UNIXTHREAD:
            self._parse_unixthread(macho)
        elif cmd == LoadCommand.LC_UUID:
            self._parse_uuid(macho)
        elif cmd in (LoadCommand.LC_VERSION_MIN_IPHONEOS, LoadCommand.LC_VERSION_MIN_MACOSX,
                     LoadCommand.LC_VERSION_MIN_TVOS, LoadCommand.LC_VERSION_MIN_WATCHOS):
            self._parse_version_min(macho)
        elif cmd == LoadCommand.LC_BUILD_VERSION:
            self._parse_build_version(macho)

        # Seek to next command
        self.stream.seek(start_pos + cmdsize)

    def _parse_segment(self, macho: MachOFile, cmd: int, cmdsize: int, is_64: bool) -> None:
        """Parse segment load command."""
        segname = self.stream.read(16).rstrip(b'\x00').decode('utf-8', errors='ignore')

        if is_64:
            vmaddr = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
            vmsize = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
            fileoff = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
            filesize = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
        else:
            vmaddr = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
            vmsize = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
            fileoff = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
            filesize = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        maxprot = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        initprot = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        nsects = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        flags = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        segment = MachOSegment(
            cmd=cmd,
            cmdsize=cmdsize,
            segname=segname,
            vmaddr=vmaddr,
            vmsize=vmsize,
            fileoff=fileoff,
            filesize=filesize,
            maxprot=maxprot,
            initprot=initprot,
            nsects=nsects,
            flags=flags
        )

        # Read segment data
        if filesize > 0:
            current_pos = self.stream.tell()
            self.stream.seek(fileoff)
            segment.data = self.stream.read(filesize)
            self.stream.seek(current_pos)

        # Parse sections
        for _ in range(nsects):
            section = self._parse_section(is_64)
            segment.sections.append(section)

        macho.segments.append(segment)

    def _parse_section(self, is_64: bool) -> MachOSection:
        """Parse section."""
        sectname = self.stream.read(16).rstrip(b'\x00').decode('utf-8', errors='ignore')
        segname = self.stream.read(16).rstrip(b'\x00').decode('utf-8', errors='ignore')

        if is_64:
            addr = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
            size = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
        else:
            addr = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
            size = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        offset = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        align = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        reloff = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        nreloc = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        flags = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        reserved1 = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        reserved2 = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        reserved3 = 0
        if is_64:
            reserved3 = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        section = MachOSection(
            sectname=sectname,
            segname=segname,
            addr=addr,
            size=size,
            offset=offset,
            align=align,
            reloff=reloff,
            nreloc=nreloc,
            flags=flags,
            reserved1=reserved1,
            reserved2=reserved2,
            reserved3=reserved3
        )

        # Read section data
        if size > 0 and offset > 0:
            current_pos = self.stream.tell()
            self.stream.seek(offset)
            section.data = self.stream.read(size)
            self.stream.seek(current_pos)

        return section

    def _parse_symtab(self, macho: MachOFile) -> None:
        """Parse symbol table."""
        symoff = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        nsyms = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        stroff = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        strsize = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        if nsyms == 0:
            return

        current_pos = self.stream.tell()

        # Read string table
        self.stream.seek(stroff)
        strtab = self.stream.read(strsize)

        # Read symbols
        self.stream.seek(symoff)

        for _ in range(nsyms):
            n_strx = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
            n_type = struct.unpack('B', self.stream.read(1))[0]
            n_sect = struct.unpack('B', self.stream.read(1))[0]
            n_desc = struct.unpack(f'{self.endian}H', self.stream.read(2))[0]

            if self.is_64bit:
                n_value = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
            else:
                n_value = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

            # Get symbol name from string table
            name = ''
            if n_strx < len(strtab):
                end = strtab.find(b'\x00', n_strx)
                if end == -1:
                    end = len(strtab)
                name = strtab[n_strx:end].decode('utf-8', errors='ignore')

            symbol = MachOSymbol(
                name=name,
                n_type=n_type,
                n_sect=n_sect,
                n_desc=n_desc,
                n_value=n_value
            )
            macho.symbols.append(symbol)

        self.stream.seek(current_pos)

    def _parse_dylib(self, macho: MachOFile, cmd_start: int) -> None:
        """Parse dylib load command."""
        # Offset to name string
        name_offset = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        timestamp = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        current_version = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        compatibility_version = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        # Read name
        current_pos = self.stream.tell()
        self.stream.seek(cmd_start + name_offset)
        name_bytes = b''
        while True:
            c = self.stream.read(1)
            if c == b'\x00' or not c:
                break
            name_bytes += c
        name = name_bytes.decode('utf-8', errors='ignore')
        self.stream.seek(current_pos)

        dylib = DylibInfo(
            name=name,
            timestamp=timestamp,
            current_version=current_version,
            compatibility_version=compatibility_version
        )
        macho.dylibs.append(dylib)

    def _parse_main(self, macho: MachOFile) -> None:
        """Parse LC_MAIN."""
        entryoff = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
        stacksize = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]

        # Entry point is offset from __TEXT segment
        text_seg = macho.find_segment('__TEXT')
        if text_seg:
            macho.entry_point = text_seg.vmaddr + entryoff
        else:
            macho.entry_point = entryoff

    def _parse_unixthread(self, macho: MachOFile) -> None:
        """Parse LC_UNIXTHREAD for entry point."""
        flavor = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        count = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        # ARM64 thread state
        if self.is_64bit and macho.header.cputype == CPUType.CPU_TYPE_ARM64:
            # Skip x0-x28 (29 * 8 = 232 bytes)
            self.stream.read(29 * 8)
            # fp (x29)
            self.stream.read(8)
            # lr (x30)
            self.stream.read(8)
            # sp
            self.stream.read(8)
            # pc is entry point
            macho.entry_point = struct.unpack(f'{self.endian}Q', self.stream.read(8))[0]
        elif macho.header.cputype == CPUType.CPU_TYPE_ARM:
            # ARM32 thread state - PC is at offset 60
            self.stream.read(15 * 4)  # r0-r14
            macho.entry_point = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

    def _parse_uuid(self, macho: MachOFile) -> None:
        """Parse LC_UUID."""
        macho.uuid = self.stream.read(16)

    def _parse_version_min(self, macho: MachOFile) -> None:
        """Parse version min command."""
        version = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        sdk = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        macho.min_version = (
            (version >> 16) & 0xFFFF,
            (version >> 8) & 0xFF,
            version & 0xFF
        )
        macho.sdk_version = (
            (sdk >> 16) & 0xFFFF,
            (sdk >> 8) & 0xFF,
            sdk & 0xFF
        )

    def _parse_build_version(self, macho: MachOFile) -> None:
        """Parse LC_BUILD_VERSION."""
        platform = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        minos = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        sdk = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]
        ntools = struct.unpack(f'{self.endian}I', self.stream.read(4))[0]

        macho.min_version = (
            (minos >> 16) & 0xFFFF,
            (minos >> 8) & 0xFF,
            minos & 0xFF
        )
        macho.sdk_version = (
            (sdk >> 16) & 0xFFFF,
            (sdk >> 8) & 0xFF,
            sdk & 0xFF
        )


# ==================== Loader ====================

class MachOLoader:
    """
    Mach-O binary loader for emulator.
    
    Loads Mach-O files into emulator memory and sets up:
    - Segments with proper protection
    - Symbol resolution
    - Dynamic library stubs
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.loaded_files: dict[str, MachOFile] = {}
        self.base_address = 0x100000000 if emulator.is_64bit else 0x10000000
        self.current_address = self.base_address

    def load(self, path_or_data: Any, base: int = 0) -> MachOFile:
        """
        Load a Mach-O file.
        
        Args:
            path_or_data: File path or bytes
            base: Base address override (0 = auto)
            
        Returns:
            Parsed MachOFile
        """
        # Read data
        if isinstance(path_or_data, bytes):
            data = path_or_data
            name = f"<memory:{id(path_or_data):x}>"
        else:
            with open(path_or_data, 'rb') as f:
                data = f.read()
            name = str(path_or_data)

        # Parse
        parser = MachOParser(data)
        macho = parser.parse()

        # Calculate load address
        if base:
            load_base = base
        else:
            # Find lowest vmaddr
            min_addr = min((seg.vmaddr for seg in macho.segments if seg.vmsize > 0),
                          default=0)

            if min_addr == 0:
                load_base = self.current_address
            else:
                # PIE binary - relocate
                if macho.header.flags & MHFlags.MH_PIE:
                    load_base = self.current_address
                else:
                    load_base = min_addr

        # Calculate slide
        min_addr = min((seg.vmaddr for seg in macho.segments if seg.vmsize > 0),
                      default=load_base)
        slide = load_base - min_addr

        # Map segments
        for segment in macho.segments:
            if segment.vmsize == 0:
                continue

            addr = segment.vmaddr + slide
            size = (segment.vmsize + 0xFFF) & ~0xFFF  # Page align

            # Convert protection flags
            prot = 0
            if segment.initprot & VMProt.VM_PROT_READ:
                prot |= 1  # UC_PROT_READ
            if segment.initprot & VMProt.VM_PROT_WRITE:
                prot |= 2  # UC_PROT_WRITE
            if segment.initprot & VMProt.VM_PROT_EXECUTE:
                prot |= 4  # UC_PROT_EXEC

            # Map memory
            try:
                self.emulator.memory.map(addr, size, prot)
            except Exception as e:
                logger.warning(f"Failed to map segment {segment.segname} at 0x{addr:x}: {e}")
                continue

            # Write data
            if segment.data:
                self.emulator.memory.write(addr, segment.data)

            # Update section addresses
            for section in segment.sections:
                section.addr += slide

            logger.debug(f"Mapped segment {segment.segname} at 0x{addr:x}-0x{addr+size:x}")

        # Update symbol addresses
        for symbol in macho.symbols:
            if symbol.n_value:
                symbol.n_value += slide

        # Update entry point
        if macho.entry_point:
            macho.entry_point += slide

        # Update current address for next load
        max_addr = max((seg.vmaddr + seg.vmsize for seg in macho.segments), default=0)
        self.current_address = ((max_addr + slide + 0xFFFF) & ~0xFFFF)

        # Store loaded file
        self.loaded_files[name] = macho

        logger.info(f"Loaded Mach-O: {name} at base 0x{load_base:x} (slide: 0x{slide:x})")

        return macho

    def find_symbol(self, name: str) -> int | None:
        """Find symbol address across all loaded files."""
        for macho in self.loaded_files.values():
            sym = macho.find_symbol(name)
            if sym and sym.n_value:
                return sym.n_value
        return None

    def get_exports(self, file_name: str = None) -> dict[str, int]:
        """Get all exported symbols."""
        exports = {}

        files = [self.loaded_files.get(file_name)] if file_name else self.loaded_files.values()

        for macho in files:
            if not macho:
                continue
            for sym in macho.symbols:
                if sym.is_external and sym.is_defined and sym.n_value:
                    exports[sym.name] = sym.n_value

        return exports
