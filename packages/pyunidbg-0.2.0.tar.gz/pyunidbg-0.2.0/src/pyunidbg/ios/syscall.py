"""
Darwin/iOS syscall handler.

Implements BSD/Mach syscalls for iOS emulation:
- BSD syscalls (file I/O, process, etc.)
- Mach traps (task, thread, ports)
- POSIX compatibility layer

References:
- https://opensource.apple.com/source/xnu/xnu-7195.81.3/bsd/kern/syscalls.master
- https://opensource.apple.com/source/xnu/xnu-7195.81.3/osfmk/mach/syscall_sw.h
"""

import logging
import os
import struct
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== Syscall Numbers ====================

class BSDSyscall(IntEnum):
    """BSD syscall numbers (ARM64)."""
    SYS_syscall = 0
    SYS_exit = 1
    SYS_fork = 2
    SYS_read = 3
    SYS_write = 4
    SYS_open = 5
    SYS_close = 6
    SYS_wait4 = 7
    SYS_link = 9
    SYS_unlink = 10
    SYS_chdir = 12
    SYS_fchdir = 13
    SYS_mknod = 14
    SYS_chmod = 15
    SYS_chown = 16
    SYS_getpid = 20
    SYS_setuid = 23
    SYS_getuid = 24
    SYS_geteuid = 25
    SYS_ptrace = 26
    SYS_recvmsg = 27
    SYS_sendmsg = 28
    SYS_recvfrom = 29
    SYS_accept = 30
    SYS_getpeername = 31
    SYS_getsockname = 32
    SYS_access = 33
    SYS_chflags = 34
    SYS_fchflags = 35
    SYS_sync = 36
    SYS_kill = 37
    SYS_getppid = 39
    SYS_dup = 41
    SYS_pipe = 42
    SYS_getegid = 43
    SYS_sigaction = 46
    SYS_getgid = 47
    SYS_sigprocmask = 48
    SYS_getlogin = 49
    SYS_setlogin = 50
    SYS_acct = 51
    SYS_sigpending = 52
    SYS_sigaltstack = 53
    SYS_ioctl = 54
    SYS_reboot = 55
    SYS_revoke = 56
    SYS_symlink = 57
    SYS_readlink = 58
    SYS_execve = 59
    SYS_umask = 60
    SYS_chroot = 61
    SYS_msync = 65
    SYS_vfork = 66
    SYS_munmap = 73
    SYS_mprotect = 74
    SYS_madvise = 75
    SYS_mincore = 78
    SYS_getgroups = 79
    SYS_setgroups = 80
    SYS_getpgrp = 81
    SYS_setpgid = 82
    SYS_setitimer = 83
    SYS_swapon = 85
    SYS_getitimer = 86
    SYS_getdtablesize = 89
    SYS_dup2 = 90
    SYS_fcntl = 92
    SYS_select = 93
    SYS_fsync = 95
    SYS_setpriority = 96
    SYS_socket = 97
    SYS_connect = 98
    SYS_getpriority = 100
    SYS_bind = 104
    SYS_setsockopt = 105
    SYS_listen = 106
    SYS_sigsuspend = 111
    SYS_gettimeofday = 116
    SYS_getrusage = 117
    SYS_getsockopt = 118
    SYS_readv = 120
    SYS_writev = 121
    SYS_settimeofday = 122
    SYS_fchown = 123
    SYS_fchmod = 124
    SYS_setreuid = 126
    SYS_setregid = 127
    SYS_rename = 128
    SYS_flock = 131
    SYS_mkfifo = 132
    SYS_sendto = 133
    SYS_shutdown = 134
    SYS_socketpair = 135
    SYS_mkdir = 136
    SYS_rmdir = 137
    SYS_utimes = 138
    SYS_futimes = 139
    SYS_adjtime = 140
    SYS_gethostuuid = 142
    SYS_setsid = 147
    SYS_getpgid = 151
    SYS_setprivexec = 152
    SYS_pread = 153
    SYS_pwrite = 154
    SYS_nfssvc = 155
    SYS_statfs = 157
    SYS_fstatfs = 158
    SYS_unmount = 159
    SYS_getfh = 161
    SYS_quotactl = 165
    SYS_mount = 167
    SYS_csops = 169
    SYS_csops_audittoken = 170
    SYS_waitid = 173
    SYS_kdebug_typefilter = 177
    SYS_kdebug_trace_string = 178
    SYS_kdebug_trace64 = 179
    SYS_kdebug_trace = 180
    SYS_setgid = 181
    SYS_setegid = 182
    SYS_seteuid = 183
    SYS_sigreturn = 184
    SYS_thread_selfcounts = 186
    SYS_fdatasync = 187
    SYS_stat = 188
    SYS_fstat = 189
    SYS_lstat = 190
    SYS_pathconf = 191
    SYS_fpathconf = 192
    SYS_getrlimit = 194
    SYS_setrlimit = 195
    SYS_getdirentries = 196
    SYS_mmap = 197
    SYS_lseek = 199
    SYS_truncate = 200
    SYS_ftruncate = 201
    SYS_sysctl = 202
    SYS_mlock = 203
    SYS_munlock = 204
    SYS_undelete = 205
    SYS_open_dprotected_np = 216
    SYS_getattrlist = 220
    SYS_setattrlist = 221
    SYS_getdirentriesattr = 222
    SYS_exchangedata = 223
    SYS_searchfs = 225
    SYS_delete = 226
    SYS_copyfile = 227
    SYS_fgetattrlist = 228
    SYS_fsetattrlist = 229
    SYS_poll = 230
    SYS_watchevent = 231
    SYS_waitevent = 232
    SYS_modwatch = 233
    SYS_getxattr = 234
    SYS_fgetxattr = 235
    SYS_setxattr = 236
    SYS_fsetxattr = 237
    SYS_removexattr = 238
    SYS_fremovexattr = 239
    SYS_listxattr = 240
    SYS_flistxattr = 241
    SYS_fsctl = 242
    SYS_initgroups = 243
    SYS_posix_spawn = 244
    SYS_ffsctl = 245
    SYS_nfsclnt = 247
    SYS_fhopen = 248
    SYS_minherit = 250
    SYS_semsys = 251
    SYS_msgsys = 252
    SYS_shmsys = 253
    SYS_semctl = 254
    SYS_semget = 255
    SYS_semop = 256
    SYS_msgctl = 258
    SYS_msgget = 259
    SYS_msgsnd = 260
    SYS_msgrcv = 261
    SYS_shmat = 262
    SYS_shmctl = 263
    SYS_shmdt = 264
    SYS_shmget = 265
    SYS_shm_open = 266
    SYS_shm_unlink = 267
    SYS_sem_open = 268
    SYS_sem_close = 269
    SYS_sem_unlink = 270
    SYS_sem_wait = 271
    SYS_sem_trywait = 272
    SYS_sem_post = 273
    SYS_sysctlbyname = 274
    SYS_open_extended = 277
    SYS_umask_extended = 278
    SYS_stat_extended = 279
    SYS_lstat_extended = 280
    SYS_fstat_extended = 281
    SYS_chmod_extended = 282
    SYS_fchmod_extended = 283
    SYS_access_extended = 284
    SYS_settid = 285
    SYS_gettid = 286
    SYS_setsgroups = 287
    SYS_getsgroups = 288
    SYS_setwgroups = 289
    SYS_getwgroups = 290
    SYS_mkfifo_extended = 291
    SYS_mkdir_extended = 292
    SYS_identitysvc = 293
    SYS_shared_region_check_np = 294
    SYS_vm_pressure_monitor = 296
    SYS_psynch_rw_longrdlock = 297
    SYS_psynch_rw_yieldwrlock = 298
    SYS_psynch_rw_downgrade = 299
    SYS_psynch_rw_upgrade = 300
    SYS_psynch_mutexwait = 301
    SYS_psynch_mutexdrop = 302
    SYS_psynch_cvbroad = 303
    SYS_psynch_cvsignal = 304
    SYS_psynch_cvwait = 305
    SYS_psynch_rw_rdlock = 306
    SYS_psynch_rw_wrlock = 307
    SYS_psynch_rw_unlock = 308
    SYS_psynch_rw_unlock2 = 309
    SYS_getsid = 310
    SYS_settid_with_pid = 311
    SYS_psynch_cvclrprepost = 312
    SYS_aio_fsync = 313
    SYS_aio_return = 314
    SYS_aio_suspend = 315
    SYS_aio_cancel = 316
    SYS_aio_error = 317
    SYS_aio_read = 318
    SYS_aio_write = 319
    SYS_lio_listio = 320
    SYS_proc_info = 336
    SYS_sendfile = 337
    SYS_stat64 = 338
    SYS_fstat64 = 339
    SYS_lstat64 = 340
    SYS_stat64_extended = 341
    SYS_lstat64_extended = 342
    SYS_fstat64_extended = 343
    SYS_getdirentries64 = 344
    SYS_statfs64 = 345
    SYS_fstatfs64 = 346
    SYS_getfsstat64 = 347
    SYS_pthread_chdir = 348
    SYS_pthread_fchdir = 349
    SYS_audit = 350
    SYS_auditon = 351
    SYS_getauid = 353
    SYS_setauid = 354
    SYS_getaudit_addr = 357
    SYS_setaudit_addr = 358
    SYS_auditctl = 359
    SYS_bsdthread_create = 360
    SYS_bsdthread_terminate = 361
    SYS_kqueue = 362
    SYS_kevent = 363
    SYS_lchown = 364
    SYS_bsdthread_register = 366
    SYS_workq_open = 367
    SYS_workq_kernreturn = 368
    SYS_kevent64 = 369
    SYS___old_semwait_signal = 370
    SYS___old_semwait_signal_nocancel = 371
    SYS_thread_selfid = 372
    SYS_ledger = 373
    SYS_kevent_qos = 374
    SYS_kevent_id = 375
    SYS___mac_execve = 380
    SYS___mac_syscall = 381
    SYS___mac_get_file = 382
    SYS___mac_set_file = 383
    SYS___mac_get_link = 384
    SYS___mac_set_link = 385
    SYS___mac_get_proc = 386
    SYS___mac_set_proc = 387
    SYS___mac_get_fd = 388
    SYS___mac_set_fd = 389
    SYS___mac_get_pid = 390
    SYS_pselect = 394
    SYS_pselect_nocancel = 395
    SYS_read_nocancel = 396
    SYS_write_nocancel = 397
    SYS_open_nocancel = 398
    SYS_close_nocancel = 399
    SYS_wait4_nocancel = 400
    SYS_recvmsg_nocancel = 401
    SYS_sendmsg_nocancel = 402
    SYS_recvfrom_nocancel = 403
    SYS_accept_nocancel = 404
    SYS_msync_nocancel = 405
    SYS_fcntl_nocancel = 406
    SYS_select_nocancel = 407
    SYS_fsync_nocancel = 408
    SYS_connect_nocancel = 409
    SYS_sigsuspend_nocancel = 410
    SYS_readv_nocancel = 411
    SYS_writev_nocancel = 412
    SYS_sendto_nocancel = 413
    SYS_pread_nocancel = 414
    SYS_pwrite_nocancel = 415
    SYS_waitid_nocancel = 416
    SYS_poll_nocancel = 417
    SYS_msgsnd_nocancel = 418
    SYS_msgrcv_nocancel = 419
    SYS_sem_wait_nocancel = 420
    SYS_aio_suspend_nocancel = 421
    SYS___sigwait_nocancel = 422
    SYS___semwait_signal_nocancel = 423
    SYS___mac_mount = 424
    SYS___mac_get_mount = 425
    SYS___mac_getfsstat = 426
    SYS_fsgetpath = 427
    SYS_audit_session_self = 428
    SYS_audit_session_join = 429
    SYS_fileport_makeport = 430
    SYS_fileport_makefd = 431
    SYS_audit_session_port = 432
    SYS_pid_suspend = 433
    SYS_pid_resume = 434
    SYS_pid_hibernate = 435
    SYS_pid_shutdown_sockets = 436
    SYS_shared_region_map_and_slide_np = 438
    SYS_kas_info = 439
    SYS_memorystatus_control = 440
    SYS_guarded_open_np = 441
    SYS_guarded_close_np = 442
    SYS_guarded_kqueue_np = 443
    SYS_change_fdguard_np = 444
    SYS_usrctl = 445
    SYS_proc_rlimit_control = 446
    SYS_connectx = 447
    SYS_disconnectx = 448
    SYS_peeloff = 449
    SYS_socket_delegate = 450
    SYS_telemetry = 451
    SYS_proc_uuid_policy = 452
    SYS_memorystatus_get_level = 453
    SYS_system_override = 454
    SYS_vfs_purge = 455
    SYS_sfi_ctl = 456
    SYS_sfi_pidctl = 457
    SYS_coalition = 458
    SYS_coalition_info = 459
    SYS_necp_match_policy = 460
    SYS_getattrlistbulk = 461
    SYS_clonefileat = 462
    SYS_openat = 463
    SYS_openat_nocancel = 464
    SYS_renameat = 465
    SYS_faccessat = 466
    SYS_fchmodat = 467
    SYS_fchownat = 468
    SYS_fstatat = 469
    SYS_fstatat64 = 470
    SYS_linkat = 471
    SYS_unlinkat = 472
    SYS_readlinkat = 473
    SYS_symlinkat = 474
    SYS_mkdirat = 475
    SYS_getattrlistat = 476
    SYS_proc_trace_log = 477
    SYS_bsdthread_ctl = 478
    SYS_openbyid_np = 479
    SYS_recvmsg_x = 480
    SYS_sendmsg_x = 481
    SYS_thread_selfusage = 482
    SYS_csrctl = 483
    SYS_guarded_open_dprotected_np = 484
    SYS_guarded_write_np = 485
    SYS_guarded_pwrite_np = 486
    SYS_guarded_writev_np = 487
    SYS_renameatx_np = 488
    SYS_mremap_encrypted = 489
    SYS_netagent_trigger = 490
    SYS_stack_snapshot_with_config = 491
    SYS_microstackshot = 492
    SYS_grab_pgo_data = 493
    SYS_persona = 494
    SYS_work_interval_ctl = 499
    SYS_getentropy = 500
    SYS_necp_open = 501
    SYS_necp_client_action = 502
    SYS___nexus_open = 503
    SYS___nexus_register = 504
    SYS___nexus_deregister = 505
    SYS___nexus_create = 506
    SYS___nexus_destroy = 507
    SYS___nexus_get_opt = 508
    SYS___nexus_set_opt = 509
    SYS___channel_open = 510
    SYS___channel_get_info = 511
    SYS___channel_sync = 512
    SYS___channel_get_opt = 513
    SYS___channel_set_opt = 514
    SYS_ulock_wait = 515
    SYS_ulock_wake = 516
    SYS_fclonefileat = 517
    SYS_fs_snapshot = 518
    SYS_terminate_with_payload = 520
    SYS_abort_with_payload = 521
    SYS_necp_session_open = 522
    SYS_necp_session_action = 523
    SYS_setattrlistat = 524
    SYS_net_qos_guideline = 525
    SYS_fmount = 526
    SYS_ntp_adjtime = 527
    SYS_ntp_gettime = 528
    SYS_os_fault_with_payload = 529


class MachTrap(IntEnum):
    """Mach trap numbers (negative syscall numbers)."""
    MACH_MSG_TRAP = -31
    MACH_REPLY_PORT = -26
    THREAD_SELF_TRAP = -27
    TASK_SELF_TRAP = -28
    HOST_SELF_TRAP = -29
    MACH_MSG_OVERWRITE_TRAP = -32
    SEMAPHORE_SIGNAL_TRAP = -33
    SEMAPHORE_SIGNAL_ALL_TRAP = -34
    SEMAPHORE_WAIT_TRAP = -36
    SEMAPHORE_WAIT_SIGNAL_TRAP = -37
    SEMAPHORE_TIMEDWAIT_TRAP = -38
    SEMAPHORE_TIMEDWAIT_SIGNAL_TRAP = -39
    CLOCK_SLEEP_TRAP = -40
    TASK_FOR_PID = -45
    TASK_NAME_FOR_PID = -44
    PID_FOR_TASK = -46
    MACX_SWAPON = -48
    MACX_SWAPOFF = -49
    THREAD_GET_SPECIAL_REPLY_PORT = -50
    MACX_TRIGGERS = -51
    MACX_BACKING_STORE_SUSPEND = -52
    MACX_BACKING_STORE_RECOVERY = -53
    PFZSTART = -54
    PFZLINK = -56
    SWTCH_PRI = -59
    SWTCH = -60
    THREAD_SWITCH = -61
    CLOCK_SLEEP = -62
    MK_TIMER_CREATE = -66
    MK_TIMER_DESTROY = -67
    MK_TIMER_ARM = -68
    MK_TIMER_CANCEL = -69
    IOKIT_USER_CLIENT_TRAP = -100


# ==================== Errno values ====================

class Errno(IntEnum):
    """Darwin errno values."""
    EPERM = 1
    ENOENT = 2
    ESRCH = 3
    EINTR = 4
    EIO = 5
    ENXIO = 6
    E2BIG = 7
    ENOEXEC = 8
    EBADF = 9
    ECHILD = 10
    EDEADLK = 11
    ENOMEM = 12
    EACCES = 13
    EFAULT = 14
    ENOTBLK = 15
    EBUSY = 16
    EEXIST = 17
    EXDEV = 18
    ENODEV = 19
    ENOTDIR = 20
    EISDIR = 21
    EINVAL = 22
    ENFILE = 23
    EMFILE = 24
    ENOTTY = 25
    ETXTBSY = 26
    EFBIG = 27
    ENOSPC = 28
    ESPIPE = 29
    EROFS = 30
    EMLINK = 31
    EPIPE = 32
    EDOM = 33
    ERANGE = 34
    EAGAIN = 35
    EWOULDBLOCK = 35
    EINPROGRESS = 36
    EALREADY = 37
    ENOTSOCK = 38
    EDESTADDRREQ = 39
    EMSGSIZE = 40
    EPROTOTYPE = 41
    ENOPROTOOPT = 42
    EPROTONOSUPPORT = 43
    ESOCKTNOSUPPORT = 44
    ENOTSUP = 45
    EPFNOSUPPORT = 46
    EAFNOSUPPORT = 47
    EADDRINUSE = 48
    EADDRNOTAVAIL = 49
    ENETDOWN = 50
    ENETUNREACH = 51
    ENETRESET = 52
    ECONNABORTED = 53
    ECONNRESET = 54
    ENOBUFS = 55
    EISCONN = 56
    ENOTCONN = 57
    ESHUTDOWN = 58
    ETOOMANYREFS = 59
    ETIMEDOUT = 60
    ECONNREFUSED = 61
    ELOOP = 62
    ENAMETOOLONG = 63
    EHOSTDOWN = 64
    EHOSTUNREACH = 65
    ENOTEMPTY = 66
    EPROCLIM = 67
    EUSERS = 68
    EDQUOT = 69
    ESTALE = 70
    EREMOTE = 71
    EBADRPC = 72
    ERPCMISMATCH = 73
    EPROGUNAVAIL = 74
    EPROGMISMATCH = 75
    EPROCUNAVAIL = 76
    ENOLCK = 77
    ENOSYS = 78
    EFTYPE = 79
    EAUTH = 80
    ENEEDAUTH = 81
    EPWROFF = 82
    EDEVERR = 83
    EOVERFLOW = 84
    EBADEXEC = 85
    EBADARCH = 86
    ESHLIBVERS = 87
    EBADMACHO = 88
    ECANCELED = 89
    EIDRM = 90
    ENOMSG = 91
    EILSEQ = 92
    ENOATTR = 93
    EBADMSG = 94
    EMULTIHOP = 95
    ENODATA = 96
    ENOLINK = 97
    ENOSR = 98
    ENOSTR = 99
    EPROTO = 100
    ETIME = 101
    EOPNOTSUPP = 102
    ENOPOLICY = 103
    ENOTRECOVERABLE = 104
    EOWNERDEAD = 105
    EQFULL = 106


# ==================== Syscall Handler ====================

@dataclass
class DarwinSyscallState:
    """Darwin syscall handler state."""
    pid: int = 1234
    uid: int = 501
    gid: int = 501
    euid: int = 501
    egid: int = 501

    # File descriptors
    next_fd: int = 3
    open_files: dict[int, Any] = field(default_factory=dict)

    # Virtual filesystem
    virtual_files: dict[str, bytes] = field(default_factory=dict)

    # Mach ports
    task_port: int = 0x103
    thread_port: int = 0x203
    host_port: int = 0x303

    # Time
    boot_time: float = field(default_factory=time.time)


class DarwinSyscallHandler:
    """
    Darwin/iOS syscall handler.
    
    Implements BSD syscalls and Mach traps for iOS emulation.
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.state = DarwinSyscallState()
        self._handlers: dict[int, Callable] = {}
        self._mach_handlers: dict[int, Callable] = {}
        self._hooks: dict[str, list[Callable]] = {}

        # Initialize default handlers
        self._setup_handlers()
        self._setup_virtual_files()

    def _setup_handlers(self) -> None:
        """Set up syscall handlers."""
        # File I/O
        self._handlers[BSDSyscall.SYS_open] = self._sys_open
        self._handlers[BSDSyscall.SYS_close] = self._sys_close
        self._handlers[BSDSyscall.SYS_read] = self._sys_read
        self._handlers[BSDSyscall.SYS_write] = self._sys_write
        self._handlers[BSDSyscall.SYS_lseek] = self._sys_lseek
        self._handlers[BSDSyscall.SYS_stat] = self._sys_stat
        self._handlers[BSDSyscall.SYS_stat64] = self._sys_stat64
        self._handlers[BSDSyscall.SYS_fstat] = self._sys_fstat
        self._handlers[BSDSyscall.SYS_fstat64] = self._sys_fstat64
        self._handlers[BSDSyscall.SYS_lstat] = self._sys_lstat
        self._handlers[BSDSyscall.SYS_lstat64] = self._sys_lstat64
        self._handlers[BSDSyscall.SYS_access] = self._sys_access
        self._handlers[BSDSyscall.SYS_dup] = self._sys_dup
        self._handlers[BSDSyscall.SYS_dup2] = self._sys_dup2
        self._handlers[BSDSyscall.SYS_fcntl] = self._sys_fcntl
        self._handlers[BSDSyscall.SYS_ioctl] = self._sys_ioctl

        # Memory
        self._handlers[BSDSyscall.SYS_mmap] = self._sys_mmap
        self._handlers[BSDSyscall.SYS_munmap] = self._sys_munmap
        self._handlers[BSDSyscall.SYS_mprotect] = self._sys_mprotect
        self._handlers[BSDSyscall.SYS_madvise] = self._sys_madvise

        # Process
        self._handlers[BSDSyscall.SYS_getpid] = self._sys_getpid
        self._handlers[BSDSyscall.SYS_getppid] = self._sys_getppid
        self._handlers[BSDSyscall.SYS_getuid] = self._sys_getuid
        self._handlers[BSDSyscall.SYS_geteuid] = self._sys_geteuid
        self._handlers[BSDSyscall.SYS_getgid] = self._sys_getgid
        self._handlers[BSDSyscall.SYS_getegid] = self._sys_getegid
        self._handlers[BSDSyscall.SYS_exit] = self._sys_exit
        self._handlers[BSDSyscall.SYS_ptrace] = self._sys_ptrace

        # Time
        self._handlers[BSDSyscall.SYS_gettimeofday] = self._sys_gettimeofday

        # Threading
        self._handlers[BSDSyscall.SYS_bsdthread_register] = self._sys_bsdthread_register
        self._handlers[BSDSyscall.SYS_bsdthread_create] = self._sys_bsdthread_create
        self._handlers[BSDSyscall.SYS_bsdthread_terminate] = self._sys_bsdthread_terminate
        self._handlers[BSDSyscall.SYS_thread_selfid] = self._sys_thread_selfid
        self._handlers[BSDSyscall.SYS_workq_open] = self._sys_workq_open
        self._handlers[BSDSyscall.SYS_workq_kernreturn] = self._sys_workq_kernreturn

        # Sysctl
        self._handlers[BSDSyscall.SYS_sysctl] = self._sys_sysctl
        self._handlers[BSDSyscall.SYS_sysctlbyname] = self._sys_sysctlbyname

        # Mach traps
        self._mach_handlers[MachTrap.TASK_SELF_TRAP] = self._mach_task_self
        self._mach_handlers[MachTrap.THREAD_SELF_TRAP] = self._mach_thread_self
        self._mach_handlers[MachTrap.HOST_SELF_TRAP] = self._mach_host_self
        self._mach_handlers[MachTrap.MACH_REPLY_PORT] = self._mach_reply_port
        self._mach_handlers[MachTrap.MACH_MSG_TRAP] = self._mach_msg_trap
        self._mach_handlers[MachTrap.SEMAPHORE_SIGNAL_TRAP] = self._mach_semaphore_signal
        self._mach_handlers[MachTrap.SEMAPHORE_WAIT_TRAP] = self._mach_semaphore_wait

    def _setup_virtual_files(self) -> None:
        """Set up virtual filesystem."""
        # /dev/null
        self.state.virtual_files['/dev/null'] = b''

        # /dev/urandom
        self.state.virtual_files['/dev/urandom'] = os.urandom(4096)

        # /dev/random
        self.state.virtual_files['/dev/random'] = os.urandom(4096)

        # iOS-specific files
        self.state.virtual_files['/var/mobile/Library/Preferences/.GlobalPreferences.plist'] = b''
        self.state.virtual_files['/System/Library/CoreServices/SystemVersion.plist'] = self._generate_system_version()

    def _generate_system_version(self) -> bytes:
        """Generate SystemVersion.plist content."""
        return b'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>ProductBuildVersion</key>
    <string>18A373</string>
    <key>ProductCopyright</key>
    <string>1983-2020 Apple Inc.</string>
    <key>ProductName</key>
    <string>iPhone OS</string>
    <key>ProductVersion</key>
    <string>14.0</string>
</dict>
</plist>'''

    def handle(self, syscall_num: int, *args) -> int:
        """
        Handle a syscall.
        
        Args:
            syscall_num: Syscall number (negative for Mach traps)
            *args: Syscall arguments
            
        Returns:
            Syscall return value
        """
        # Check for hooks first
        syscall_name = self._get_syscall_name(syscall_num)
        if syscall_name in self._hooks:
            for hook in self._hooks[syscall_name]:
                result = hook(self.emulator, *args)
                if result is not None:
                    return result

        # Mach trap (negative number)
        if syscall_num < 0:
            handler = self._mach_handlers.get(syscall_num)
            if handler:
                try:
                    return handler(*args)
                except Exception as e:
                    logger.error(f"Mach trap {syscall_num} error: {e}")
                    return -Errno.ENOSYS
            else:
                logger.warning(f"Unhandled Mach trap: {syscall_num}")
                return 0

        # BSD syscall
        handler = self._handlers.get(syscall_num)
        if handler:
            try:
                return handler(*args)
            except Exception as e:
                logger.error(f"Syscall {syscall_num} error: {e}")
                return -Errno.ENOSYS
        else:
            logger.warning(f"Unhandled syscall: {syscall_num} ({syscall_name})")
            return -Errno.ENOSYS

    def _get_syscall_name(self, num: int) -> str:
        """Get syscall name from number."""
        if num < 0:
            try:
                return MachTrap(num).name.lower()
            except ValueError:
                return f"mach_trap_{-num}"
        try:
            return BSDSyscall(num).name.lower().replace('sys_', '')
        except ValueError:
            return f"syscall_{num}"

    def register_hook(self, name: str, callback: Callable) -> None:
        """Register a syscall hook."""
        if name not in self._hooks:
            self._hooks[name] = []
        self._hooks[name].append(callback)

    # ==================== File I/O ====================

    def _sys_open(self, path_ptr: int, flags: int, mode: int = 0) -> int:
        """open(path, flags, mode)"""
        path = self.emulator.memory.read_string(path_ptr)
        logger.debug(f"open({path}, 0x{flags:x}, 0o{mode:o})")

        # Check virtual files
        if path in self.state.virtual_files:
            fd = self.state.next_fd
            self.state.next_fd += 1
            self.state.open_files[fd] = {
                'type': 'virtual',
                'path': path,
                'data': self.state.virtual_files[path],
                'pos': 0,
            }
            return fd

        # Try real file (for debugging)
        try:
            mode_str = 'rb'
            if flags & 0x0001:  # O_WRONLY
                mode_str = 'wb'
            elif flags & 0x0002:  # O_RDWR
                mode_str = 'r+b'

            f = open(path, mode_str)
            fd = self.state.next_fd
            self.state.next_fd += 1
            self.state.open_files[fd] = {
                'type': 'real',
                'file': f,
                'path': path,
            }
            return fd
        except FileNotFoundError:
            return -Errno.ENOENT
        except PermissionError:
            return -Errno.EACCES
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return -Errno.EIO

    def _sys_close(self, fd: int) -> int:
        """close(fd)"""
        if fd in self.state.open_files:
            file_info = self.state.open_files.pop(fd)
            if file_info.get('type') == 'real' and 'file' in file_info:
                file_info['file'].close()
            return 0
        return -Errno.EBADF

    def _sys_read(self, fd: int, buf_ptr: int, count: int) -> int:
        """read(fd, buf, count)"""
        if fd not in self.state.open_files:
            return -Errno.EBADF

        file_info = self.state.open_files[fd]

        if file_info['type'] == 'virtual':
            data = file_info['data']
            pos = file_info['pos']
            read_data = data[pos:pos + count]
            file_info['pos'] += len(read_data)
        else:
            read_data = file_info['file'].read(count)

        if read_data:
            self.emulator.memory.write(buf_ptr, read_data)

        return len(read_data)

    def _sys_write(self, fd: int, buf_ptr: int, count: int) -> int:
        """write(fd, buf, count)"""
        data = self.emulator.memory.read(buf_ptr, count)

        if fd == 1:  # stdout
            print(data.decode('utf-8', errors='replace'), end='')
            return count
        elif fd == 2:  # stderr
            print(data.decode('utf-8', errors='replace'), end='', file=__import__('sys').stderr)
            return count
        elif fd in self.state.open_files:
            file_info = self.state.open_files[fd]
            if file_info['type'] == 'real':
                return file_info['file'].write(data)
            return count

        return -Errno.EBADF

    def _sys_lseek(self, fd: int, offset: int, whence: int) -> int:
        """lseek(fd, offset, whence)"""
        if fd not in self.state.open_files:
            return -Errno.EBADF

        file_info = self.state.open_files[fd]

        if file_info['type'] == 'virtual':
            data_len = len(file_info['data'])
            if whence == 0:  # SEEK_SET
                file_info['pos'] = offset
            elif whence == 1:  # SEEK_CUR
                file_info['pos'] += offset
            elif whence == 2:  # SEEK_END
                file_info['pos'] = data_len + offset
            return file_info['pos']
        else:
            return file_info['file'].seek(offset, whence)

    def _sys_stat(self, path_ptr: int, stat_ptr: int) -> int:
        """stat(path, stat_buf)"""
        path = self.emulator.memory.read_string(path_ptr)
        return self._do_stat(path, stat_ptr, follow_links=True)

    def _sys_stat64(self, path_ptr: int, stat_ptr: int) -> int:
        """stat64(path, stat_buf)"""
        return self._sys_stat(path_ptr, stat_ptr)

    def _sys_fstat(self, fd: int, stat_ptr: int) -> int:
        """fstat(fd, stat_buf)"""
        if fd in self.state.open_files:
            return self._write_stat(stat_ptr, is_file=True, size=0)
        return -Errno.EBADF

    def _sys_fstat64(self, fd: int, stat_ptr: int) -> int:
        """fstat64(fd, stat_buf)"""
        return self._sys_fstat(fd, stat_ptr)

    def _sys_lstat(self, path_ptr: int, stat_ptr: int) -> int:
        """lstat(path, stat_buf)"""
        path = self.emulator.memory.read_string(path_ptr)
        return self._do_stat(path, stat_ptr, follow_links=False)

    def _sys_lstat64(self, path_ptr: int, stat_ptr: int) -> int:
        """lstat64(path, stat_buf)"""
        return self._sys_lstat(path_ptr, stat_ptr)

    def _do_stat(self, path: str, stat_ptr: int, follow_links: bool) -> int:
        """Perform stat operation."""
        # Check virtual files
        if path in self.state.virtual_files:
            return self._write_stat(stat_ptr, is_file=True,
                                   size=len(self.state.virtual_files[path]))

        # Check real filesystem
        try:
            if follow_links:
                st = os.stat(path)
            else:
                st = os.lstat(path)
            return self._write_stat(stat_ptr, is_file=True, size=st.st_size)
        except FileNotFoundError:
            return -Errno.ENOENT
        except PermissionError:
            return -Errno.EACCES

    def _write_stat(self, stat_ptr: int, is_file: bool, size: int) -> int:
        """Write stat structure."""
        # struct stat for Darwin ARM64
        # This is simplified - real struct is more complex
        mode = 0o100644 if is_file else 0o40755
        now = int(time.time())

        if self.emulator.is_64bit:
            # Darwin ARM64 stat structure
            stat_data = struct.pack(
                '<IHHIIIQQQQQQQQIIII',
                1,           # st_dev
                mode,        # st_mode
                1,           # st_nlink
                self.state.uid,   # st_uid (actually ino on Darwin)
                self.state.gid,   # st_gid
                0,           # st_rdev
                now,         # st_atime
                0,           # st_atime_nsec
                now,         # st_mtime
                0,           # st_mtime_nsec
                now,         # st_ctime
                0,           # st_ctime_nsec
                now,         # st_birthtime
                0,           # st_birthtime_nsec
                size,        # st_size
                0,           # st_blocks
                4096,        # st_blksize
                0,           # st_flags
                0,           # st_gen
            )
        else:
            stat_data = struct.pack(
                '<HHIIIIIIIIII',
                1,           # st_dev
                0,           # st_ino
                mode,        # st_mode
                1,           # st_nlink
                self.state.uid,
                self.state.gid,
                0,           # st_rdev
                size,        # st_size
                now,         # st_atime
                now,         # st_mtime
                now,         # st_ctime
                4096,        # st_blksize
            )

        self.emulator.memory.write(stat_ptr, stat_data)
        return 0

    def _sys_access(self, path_ptr: int, mode: int) -> int:
        """access(path, mode)"""
        path = self.emulator.memory.read_string(path_ptr)

        if path in self.state.virtual_files:
            return 0

        try:
            if os.access(path, mode):
                return 0
            return -Errno.EACCES
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return -Errno.ENOENT

    def _sys_dup(self, fd: int) -> int:
        """dup(fd)"""
        if fd not in self.state.open_files:
            return -Errno.EBADF

        new_fd = self.state.next_fd
        self.state.next_fd += 1
        self.state.open_files[new_fd] = self.state.open_files[fd].copy()
        return new_fd

    def _sys_dup2(self, oldfd: int, newfd: int) -> int:
        """dup2(oldfd, newfd)"""
        if oldfd not in self.state.open_files:
            return -Errno.EBADF

        if newfd in self.state.open_files:
            self._sys_close(newfd)

        self.state.open_files[newfd] = self.state.open_files[oldfd].copy()
        return newfd

    def _sys_fcntl(self, fd: int, cmd: int, arg: int = 0) -> int:
        """fcntl(fd, cmd, arg)"""
        if fd not in self.state.open_files and fd > 2:
            return -Errno.EBADF

        # F_GETFL, F_SETFL, etc.
        if cmd == 3:  # F_GETFL
            return 0
        elif cmd == 4:  # F_SETFL
            return 0
        elif cmd == 1:  # F_DUPFD
            return self._sys_dup(fd)

        return 0

    def _sys_ioctl(self, fd: int, request: int, arg: int = 0) -> int:
        """ioctl(fd, request, arg)"""
        # Most ioctls just return 0
        return 0

    # ==================== Memory ====================

    def _sys_mmap(self, addr: int, length: int, prot: int,
                  flags: int, fd: int, offset: int) -> int:
        """mmap(addr, length, prot, flags, fd, offset)"""
        logger.debug(f"mmap(0x{addr:x}, {length}, {prot}, 0x{flags:x}, {fd}, {offset})")

        # Allocate memory
        try:
            if addr == 0:
                # Find suitable address
                addr = self.emulator.memory.find_free_space(length)

            self.emulator.memory.map(addr, length, prot)

            # If fd is valid, read file content
            if fd >= 0 and fd in self.state.open_files:
                file_info = self.state.open_files[fd]
                if file_info['type'] == 'real':
                    file_info['file'].seek(offset)
                    data = file_info['file'].read(length)
                    self.emulator.memory.write(addr, data)

            return addr
        except Exception as e:
            logger.error(f"mmap error: {e}")
            return -Errno.ENOMEM

    def _sys_munmap(self, addr: int, length: int) -> int:
        """munmap(addr, length)"""
        try:
            self.emulator.memory.unmap(addr, length)
            return 0
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return -Errno.EINVAL

    def _sys_mprotect(self, addr: int, length: int, prot: int) -> int:
        """mprotect(addr, length, prot)"""
        try:
            self.emulator.memory.protect(addr, length, prot)
            return 0
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return -Errno.EINVAL

    def _sys_madvise(self, addr: int, length: int, advice: int) -> int:
        """madvise(addr, length, advice)"""
        return 0  # Ignore advice

    # ==================== Process ====================

    def _sys_getpid(self) -> int:
        """getpid()"""
        return self.state.pid

    def _sys_getppid(self) -> int:
        """getppid()"""
        return 1  # launchd

    def _sys_getuid(self) -> int:
        """getuid()"""
        return self.state.uid

    def _sys_geteuid(self) -> int:
        """geteuid()"""
        return self.state.euid

    def _sys_getgid(self) -> int:
        """getgid()"""
        return self.state.gid

    def _sys_getegid(self) -> int:
        """getegid()"""
        return self.state.egid

    def _sys_exit(self, status: int) -> int:
        """exit(status)"""
        logger.info(f"Process exit with status {status}")
        self.emulator.stop()
        return 0

    def _sys_ptrace(self, request: int, pid: int, addr: int, data: int) -> int:
        """ptrace(request, pid, addr, data) - anti-debug bypass"""
        logger.debug(f"ptrace({request}, {pid}, 0x{addr:x}, 0x{data:x})")

        # PT_DENY_ATTACH = 31
        if request == 31:
            return 0  # Pretend it worked

        # PT_TRACE_ME = 0
        if request == 0:
            return 0

        return -Errno.EPERM

    # ==================== Time ====================

    def _sys_gettimeofday(self, tv_ptr: int, tz_ptr: int) -> int:
        """gettimeofday(tv, tz)"""
        now = time.time()
        tv_sec = int(now)
        tv_usec = int((now - tv_sec) * 1_000_000)

        if self.emulator.is_64bit:
            self.emulator.memory.write(tv_ptr, struct.pack('<QQ', tv_sec, tv_usec))
        else:
            self.emulator.memory.write(tv_ptr, struct.pack('<II', tv_sec, tv_usec))

        if tz_ptr:
            self.emulator.memory.write(tz_ptr, struct.pack('<ii', 0, 0))

        return 0

    # ==================== Threading ====================

    def _sys_bsdthread_register(self, *args) -> int:
        """bsdthread_register - thread creation setup"""
        return 0

    def _sys_bsdthread_create(self, *args) -> int:
        """bsdthread_create - create thread"""
        # Would need actual thread implementation
        return -Errno.ENOSYS

    def _sys_bsdthread_terminate(self, *args) -> int:
        """bsdthread_terminate - terminate thread"""
        return 0

    def _sys_thread_selfid(self) -> int:
        """thread_selfid - get current thread ID"""
        return 1

    def _sys_workq_open(self) -> int:
        """workq_open - open workqueue"""
        return 0

    def _sys_workq_kernreturn(self, *args) -> int:
        """workq_kernreturn - workqueue kernel return"""
        return 0

    # ==================== Sysctl ====================

    def _sys_sysctl(self, name_ptr: int, namelen: int,
                    oldp: int, oldlenp: int, newp: int, newlen: int) -> int:
        """sysctl(name, namelen, oldp, oldlenp, newp, newlen)"""
        # Read name array
        name = []
        for i in range(namelen):
            val = struct.unpack('<I', self.emulator.memory.read(name_ptr + i * 4, 4))[0]
            name.append(val)

        logger.debug(f"sysctl({name})")

        # Handle common sysctls
        return self._handle_sysctl(name, oldp, oldlenp)

    def _sys_sysctlbyname(self, name_ptr: int, oldp: int, oldlenp: int,
                          newp: int, newlen: int) -> int:
        """sysctlbyname(name, oldp, oldlenp, newp, newlen)"""
        name = self.emulator.memory.read_string(name_ptr)
        logger.debug(f"sysctlbyname({name})")

        return self._handle_sysctl_by_name(name, oldp, oldlenp)

    def _handle_sysctl(self, name: list[int], oldp: int, oldlenp: int) -> int:
        """Handle sysctl by numeric name."""
        # CTL_KERN = 1, KERN_OSTYPE = 1
        if name == [1, 1]:
            return self._write_sysctl_string(oldp, oldlenp, "Darwin")
        # CTL_KERN, KERN_OSRELEASE = 2
        elif name == [1, 2]:
            return self._write_sysctl_string(oldp, oldlenp, "20.0.0")
        # CTL_KERN, KERN_VERSION = 4
        elif name == [1, 4]:
            return self._write_sysctl_string(oldp, oldlenp,
                "Darwin Kernel Version 20.0.0: root:xnu-7195.81.3~1/RELEASE_ARM64_T8101")
        # CTL_HW = 6, HW_MACHINE = 1
        elif name == [6, 1]:
            return self._write_sysctl_string(oldp, oldlenp, "iPhone13,1")
        # CTL_HW, HW_MODEL = 2
        elif name == [6, 2]:
            return self._write_sysctl_string(oldp, oldlenp, "D52gAP")

        return 0

    def _handle_sysctl_by_name(self, name: str, oldp: int, oldlenp: int) -> int:
        """Handle sysctl by string name."""
        responses = {
            'kern.ostype': 'Darwin',
            'kern.osrelease': '20.0.0',
            'kern.version': 'Darwin Kernel Version 20.0.0',
            'kern.hostname': 'iPhone',
            'hw.machine': 'iPhone13,1',
            'hw.model': 'D52gAP',
            'hw.ncpu': 6,
            'hw.physicalcpu': 6,
            'hw.logicalcpu': 6,
            'hw.memsize': 4 * 1024 * 1024 * 1024,  # 4GB
            'hw.pagesize': 16384,  # 16KB pages on ARM64
            'security.mac.amfi.developer_mode': 0,
            'kern.bootargs': '',
            'hw.cputype': 0x0100000C,  # CPU_TYPE_ARM64
            'hw.cpusubtype': 2,  # CPU_SUBTYPE_ARM64E
        }

        if name in responses:
            value = responses[name]
            if isinstance(value, str):
                return self._write_sysctl_string(oldp, oldlenp, value)
            elif isinstance(value, int):
                return self._write_sysctl_int(oldp, oldlenp, value)

        # Unknown - return 0 length
        if oldlenp:
            self.emulator.memory.write(oldlenp, struct.pack('<Q' if self.emulator.is_64bit else '<I', 0))

        return 0

    def _write_sysctl_string(self, oldp: int, oldlenp: int, value: str) -> int:
        """Write string sysctl value."""
        data = value.encode('utf-8') + b'\x00'

        if oldlenp:
            if self.emulator.is_64bit:
                self.emulator.memory.write(oldlenp, struct.pack('<Q', len(data)))
            else:
                self.emulator.memory.write(oldlenp, struct.pack('<I', len(data)))

        if oldp:
            self.emulator.memory.write(oldp, data)

        return 0

    def _write_sysctl_int(self, oldp: int, oldlenp: int, value: int) -> int:
        """Write integer sysctl value."""
        if self.emulator.is_64bit:
            data = struct.pack('<Q', value)
        else:
            data = struct.pack('<I', value)

        if oldlenp:
            if self.emulator.is_64bit:
                self.emulator.memory.write(oldlenp, struct.pack('<Q', len(data)))
            else:
                self.emulator.memory.write(oldlenp, struct.pack('<I', len(data)))

        if oldp:
            self.emulator.memory.write(oldp, data)

        return 0

    # ==================== Mach Traps ====================

    def _mach_task_self(self) -> int:
        """task_self_trap"""
        return self.state.task_port

    def _mach_thread_self(self) -> int:
        """thread_self_trap"""
        return self.state.thread_port

    def _mach_host_self(self) -> int:
        """host_self_trap"""
        return self.state.host_port

    def _mach_reply_port(self) -> int:
        """mach_reply_port"""
        return 0x403

    def _mach_msg_trap(self, *args) -> int:
        """mach_msg_trap - Mach IPC"""
        # Complex IPC - simplified for now
        return 0

    def _mach_semaphore_signal(self, semaphore: int) -> int:
        """semaphore_signal_trap"""
        return 0

    def _mach_semaphore_wait(self, semaphore: int) -> int:
        """semaphore_wait_trap"""
        return 0
