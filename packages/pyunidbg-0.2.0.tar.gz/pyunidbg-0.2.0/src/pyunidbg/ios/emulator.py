"""
iOS emulator for running iOS/Darwin binaries.

Provides complete iOS emulation:
- Mach-O binary loading
- Darwin syscall handling
- Objective-C runtime
- dyld dynamic linker emulation
- iOS-specific memory layout

References:
- iOS ABI: https://developer.apple.com/library/archive/documentation/Xcode/Conceptual/iPhoneOSABIReference/
- dyld: https://opensource.apple.com/source/dyld/
"""

import logging
import struct
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from unicorn import Uc, UcError
from unicorn.arm64_const import (
    UC_ARM64_REG_SP,
    UC_ARM64_REG_X0,
    UC_ARM64_REG_X1,
    UC_ARM64_REG_X2,
    UC_ARM64_REG_X3,
    UC_ARM64_REG_X4,
    UC_ARM64_REG_X5,
    UC_ARM64_REG_X6,
    UC_ARM64_REG_X7,
)
from unicorn.arm_const import (
    UC_ARM_REG_R0,
    UC_ARM_REG_R1,
    UC_ARM_REG_R2,
    UC_ARM_REG_R3,
    UC_ARM_REG_SP,
)

from .macho import MachOFile
from .objc import ObjCClass, ObjCRuntime
from .syscall import DarwinSyscallHandler

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== iOS Memory Layout ====================

@dataclass
class iOSMemoryLayout:
    """iOS process memory layout."""
    # 64-bit layout (arm64)
    TEXT_BASE_64 = 0x100000000        # Main executable
    DYLD_BASE_64 = 0x7FFF00000000     # dyld
    STACK_TOP_64 = 0x7FFFFFFF0000     # Stack top
    HEAP_BASE_64 = 0x120000000        # Heap
    DYLIB_BASE_64 = 0x180000000       # Dynamic libraries

    # 32-bit layout (armv7)
    TEXT_BASE_32 = 0x4000             # Main executable
    DYLD_BASE_32 = 0x1FE00000         # dyld
    STACK_TOP_32 = 0xC0000000         # Stack top
    HEAP_BASE_32 = 0x02000000         # Heap
    DYLIB_BASE_32 = 0x30000000        # Dynamic libraries


@dataclass
class LoadedImage:
    """Loaded Mach-O image."""
    path: str
    macho: MachOFile
    base_address: int
    slide: int  # ASLR slide
    segments: dict[str, tuple[int, int]]  # name -> (address, size)
    symbols: dict[str, int]  # name -> address
    entry_point: int = 0
    initialized: bool = False


# ==================== dyld Emulation ====================

class DyldEmulator:
    """
    dyld dynamic linker emulation.
    
    Handles:
    - Library loading
    - Symbol binding
    - Lazy binding
    - Initializers
    """

    def __init__(self, ios_emulator: 'iOSEmulator'):
        self.ios = ios_emulator
        self.emu = ios_emulator.emulator

        # Loaded images
        self.images: dict[str, LoadedImage] = {}
        self.image_list: list[LoadedImage] = []

        # Symbol cache
        self.symbol_cache: dict[str, int] = {}

        # Next library load address
        if self.emu.is_64bit:
            self.next_lib_address = iOSMemoryLayout.DYLIB_BASE_64
        else:
            self.next_lib_address = iOSMemoryLayout.DYLIB_BASE_32

        # Stub handlers for unresolved symbols
        self.stub_handlers: dict[str, Callable] = {}

        # Initialize dyld structures
        self._init_dyld()

    def _init_dyld(self) -> None:
        """Initialize dyld data structures."""
        # Allocate dyld image info
        if self.emu.is_64bit:
            self.dyld_all_image_infos = self.emu.memory.alloc(0x1000)
        else:
            self.dyld_all_image_infos = self.emu.memory.alloc(0x100)

        # Initialize to zeros
        size = 0x1000 if self.emu.is_64bit else 0x100
        self.emu.memory.write(self.dyld_all_image_infos, b'\x00' * size)

    def load_main_executable(self, macho: MachOFile, base: int = 0) -> LoadedImage:
        """Load main executable."""
        if base == 0:
            if self.emu.is_64bit:
                base = iOSMemoryLayout.TEXT_BASE_64
            else:
                base = iOSMemoryLayout.TEXT_BASE_32

        image = self._load_macho(macho, base, macho.path or "main")
        self.images[image.path] = image
        self.image_list.insert(0, image)

        return image

    def load_library(self, path: str) -> LoadedImage | None:
        """Load dynamic library."""
        # Check if already loaded
        basename = Path(path).name
        for loaded_path, image in self.images.items():
            if Path(loaded_path).name == basename:
                return image

        # Try to load from filesystem
        macho_path = self._resolve_library_path(path)
        if not macho_path:
            logger.warning(f"Library not found: {path}")
            return None

        try:
            macho = MachOFile.parse(macho_path)
        except Exception as e:
            logger.error(f"Failed to parse library {path}: {e}")
            return None

        # Allocate address
        address = self.next_lib_address
        total_size = sum(seg.vmsize for seg in macho.segments.values())
        total_size = (total_size + 0xFFFF) & ~0xFFFF  # Align to 64KB
        self.next_lib_address = address + total_size

        image = self._load_macho(macho, address, path)
        self.images[path] = image
        self.image_list.append(image)

        return image

    def _load_macho(self, macho: MachOFile, base: int, path: str) -> LoadedImage:
        """Load Mach-O into memory."""
        slide = base - (macho.segments['__TEXT'].vmaddr if '__TEXT' in macho.segments else 0)

        segments: dict[str, tuple[int, int]] = {}

        for name, segment in macho.segments.items():
            seg_addr = segment.vmaddr + slide
            seg_size = segment.vmsize

            # Map segment
            try:
                self.emu.uc.mem_map(seg_addr, seg_size)
            except UcError:
                pass  # Already mapped

            # Write file content
            if segment.filesize > 0:
                self.emu.memory.write(seg_addr, segment.data[:segment.filesize])

            segments[name] = (seg_addr, seg_size)
            logger.debug(f"Loaded segment {name} at 0x{seg_addr:x} size 0x{seg_size:x}")

        # Build symbol table
        symbols: dict[str, int] = {}
        for sym in macho.symbols:
            if sym.address > 0:
                symbols[sym.name] = sym.address + slide
                self.symbol_cache[sym.name] = symbols[sym.name]

        # Find entry point
        entry_point = 0
        if macho.entry_point:
            entry_point = macho.entry_point + slide
        elif '__TEXT' in segments:
            entry_point = segments['__TEXT'][0]

        image = LoadedImage(
            path=path,
            macho=macho,
            base_address=base,
            slide=slide,
            segments=segments,
            symbols=symbols,
            entry_point=entry_point
        )

        return image

    def _resolve_library_path(self, path: str) -> str | None:
        """Resolve library path."""
        # Common iOS framework paths
        search_paths = [
            '/System/Library/Frameworks',
            '/System/Library/PrivateFrameworks',
            '/usr/lib',
            '/usr/lib/system',
        ]

        # If absolute path, check directly
        if path.startswith('/'):
            p = Path(path)
            if p.exists():
                return str(p)
            return None

        # Search in paths
        for search in search_paths:
            full = Path(search) / path
            if full.exists():
                return str(full)

        return None

    def resolve_symbol(self, name: str) -> int:
        """Resolve symbol address."""
        # Check cache
        if name in self.symbol_cache:
            return self.symbol_cache[name]

        # Search loaded images
        for image in self.image_list:
            if name in image.symbols:
                return image.symbols[name]

        # Create stub
        return self._create_stub(name)

    def _create_stub(self, name: str) -> int:
        """Create stub for unresolved symbol."""
        # Allocate stub
        stub_addr = self.emu.memory.alloc(16)

        # Write RET instruction
        if self.emu.is_64bit:
            self.emu.memory.write(stub_addr, b'\xc0\x03\x5f\xd6')  # ret
        else:
            self.emu.memory.write(stub_addr, b'\x1e\xff\x2f\xe1')  # bx lr

        self.symbol_cache[name] = stub_addr
        logger.debug(f"Created stub for {name} at 0x{stub_addr:x}")

        return stub_addr

    def bind_symbols(self, image: LoadedImage) -> None:
        """Bind symbols for an image."""
        macho = image.macho

        # Process bind info
        for bind in macho.bind_info:
            symbol_name = bind.get('symbol', '')
            if not symbol_name:
                continue

            target = self.resolve_symbol(symbol_name)
            address = bind.get('address', 0) + image.slide

            # Write pointer
            if self.emu.is_64bit:
                self.emu.memory.write(address, struct.pack('<Q', target))
            else:
                self.emu.memory.write(address, struct.pack('<I', target))

    def run_initializers(self, image: LoadedImage) -> None:
        """Run image initializers."""
        if image.initialized:
            return

        image.initialized = True

        # Find __mod_init_func section
        if '__DATA' in image.segments:
            macho = image.macho
            if '__DATA' in macho.segments:
                segment = macho.segments['__DATA']
                for section in segment.sections:
                    if section.name == '__mod_init_func':
                        self._run_init_funcs(section.address + image.slide,
                                            section.size)

    def _run_init_funcs(self, address: int, size: int) -> None:
        """Run initializer functions."""
        ptr_size = 8 if self.emu.is_64bit else 4
        count = size // ptr_size

        for i in range(count):
            func_ptr = self.emu.memory.read_ptr(address + i * ptr_size)
            if func_ptr:
                logger.debug(f"Running initializer at 0x{func_ptr:x}")
                try:
                    self.emu.call(func_ptr)
                except Exception as e:
                    logger.warning(f"Initializer failed: {e}")


# ==================== iOS Emulator ====================

class iOSEmulator:
    """
    iOS binary emulator.
    
    Provides complete iOS emulation environment including:
    - Mach-O loading
    - Darwin syscalls
    - Objective-C runtime
    - dyld emulation
    
    Example:
        ios = iOSEmulator(emulator)
        ios.load_binary("path/to/app")
        result = ios.call_function("_some_function", arg1, arg2)
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator

        # Initialize subsystems
        self.syscall = DarwinSyscallHandler(emulator)
        self.objc = ObjCRuntime(emulator)
        self.dyld = DyldEmulator(self)

        # Main executable
        self.main_image: LoadedImage | None = None

        # Function hooks
        self.hooks: dict[str, Callable] = {}

        # iOS environment
        self.bundle_id = "com.example.app"
        self.app_path = "/var/containers/Bundle/Application/UUID/App.app"
        self.data_path = "/var/mobile/Containers/Data/Application/UUID"

        # Setup iOS environment
        self._setup_ios_env()

    def _setup_ios_env(self) -> None:
        """Set up iOS environment."""
        # Register syscall hooks
        self.emulator.add_interrupt_handler(self._handle_svc)

        # Set up common library stubs
        self._setup_library_stubs()

    def _handle_svc(self, uc: Uc, intno: int, data: Any) -> None:
        """Handle SVC instruction (syscall)."""
        if intno == 2:  # SVC on ARM
            self.syscall.handle_syscall()

    def _setup_library_stubs(self) -> None:
        """Set up stubs for common library functions."""
        # Foundation
        self._add_stub('_NSLog', self._stub_NSLog)
        self._add_stub('_NSStringFromClass', self._stub_NSStringFromClass)

        # libSystem
        self._add_stub('_printf', self._stub_printf)
        self._add_stub('_puts', self._stub_puts)
        self._add_stub('_malloc', self._stub_malloc)
        self._add_stub('_free', self._stub_free)
        self._add_stub('_memcpy', self._stub_memcpy)
        self._add_stub('_memset', self._stub_memset)
        self._add_stub('_strlen', self._stub_strlen)
        self._add_stub('_strcmp', self._stub_strcmp)
        self._add_stub('_strcpy', self._stub_strcpy)

        # Objective-C runtime
        self._add_stub('_objc_msgSend', self._stub_objc_msgSend)
        self._add_stub('_objc_getClass', self._stub_objc_getClass)
        self._add_stub('_objc_alloc', self._stub_objc_alloc)
        self._add_stub('_objc_allocWithZone', self._stub_objc_alloc)
        self._add_stub('_objc_retain', self._stub_objc_retain)
        self._add_stub('_objc_release', self._stub_objc_release)
        self._add_stub('_objc_autorelease', self._stub_objc_autorelease)
        self._add_stub('_sel_registerName', self._stub_sel_registerName)
        self._add_stub('_sel_getName', self._stub_sel_getName)
        self._add_stub('_class_getName', self._stub_class_getName)

        # Security
        self._add_stub('_SecItemCopyMatching', self._stub_SecItemCopyMatching)
        self._add_stub('_SecItemAdd', self._stub_SecItemAdd)

    def _add_stub(self, name: str, handler: Callable) -> None:
        """Add function stub."""
        self.hooks[name] = handler
        self.dyld.stub_handlers[name] = handler

    # ==================== Binary Loading ====================

    def load_binary(self, path: str, base: int = 0) -> LoadedImage:
        """
        Load iOS binary.
        
        Args:
            path: Path to Mach-O binary
            base: Optional base address
            
        Returns:
            LoadedImage with binary info
        """
        macho = MachOFile.parse(path)

        # Verify architecture
        if self.emulator.is_64bit and macho.cpu_type != 0x100000C:  # ARM64
            raise ValueError("64-bit emulator requires ARM64 binary")
        elif not self.emulator.is_64bit and macho.cpu_type != 0xC:  # ARM
            raise ValueError("32-bit emulator requires ARM binary")

        # Load main executable
        self.main_image = self.dyld.load_main_executable(macho, base)

        # Load dependencies
        for dylib in macho.dylibs:
            self.dyld.load_library(dylib)

        # Bind symbols
        self.dyld.bind_symbols(self.main_image)

        # Run initializers
        self.dyld.run_initializers(self.main_image)

        logger.info(f"Loaded {path} at 0x{self.main_image.base_address:x}")
        return self.main_image

    def load_framework(self, name: str) -> LoadedImage | None:
        """
        Load iOS framework.
        
        Args:
            name: Framework name (e.g., 'Foundation', 'UIKit')
            
        Returns:
            LoadedImage or None if not found
        """
        path = f"/System/Library/Frameworks/{name}.framework/{name}"
        return self.dyld.load_library(path)

    # ==================== Function Calls ====================

    def call_function(self, name: str, *args) -> int:
        """
        Call function by name.
        
        Args:
            name: Function name (with or without leading underscore)
            *args: Function arguments
            
        Returns:
            Return value
        """
        # Normalize name
        if not name.startswith('_'):
            name = '_' + name

        # Check for stub
        if name in self.hooks:
            return self.hooks[name](*args)

        # Find function
        address = self.dyld.resolve_symbol(name)
        if not address:
            raise ValueError(f"Function not found: {name}")

        return self.call_address(address, *args)

    def call_address(self, address: int, *args) -> int:
        """
        Call function at address.
        
        Args:
            address: Function address
            *args: Function arguments
            
        Returns:
            Return value
        """
        # Set up arguments
        if self.emulator.is_64bit:
            regs = [UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2,
                   UC_ARM64_REG_X3, UC_ARM64_REG_X4, UC_ARM64_REG_X5,
                   UC_ARM64_REG_X6, UC_ARM64_REG_X7]
            for i, arg in enumerate(args[:8]):
                self.emulator.uc.reg_write(regs[i], arg)

            # Stack arguments
            if len(args) > 8:
                sp = self.emulator.uc.reg_read(UC_ARM64_REG_SP)
                for i, arg in enumerate(args[8:]):
                    self.emulator.memory.write(sp + i * 8, struct.pack('<Q', arg))
        else:
            regs = [UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3]
            for i, arg in enumerate(args[:4]):
                self.emulator.uc.reg_write(regs[i], arg)

            # Stack arguments
            if len(args) > 4:
                sp = self.emulator.uc.reg_read(UC_ARM_REG_SP)
                for i, arg in enumerate(args[4:]):
                    self.emulator.memory.write(sp + i * 4, struct.pack('<I', arg))

        # Call function
        self.emulator.call(address)

        # Get return value
        if self.emulator.is_64bit:
            return self.emulator.uc.reg_read(UC_ARM64_REG_X0)
        else:
            return self.emulator.uc.reg_read(UC_ARM_REG_R0)

    # ==================== Objective-C Support ====================

    def call_objc_method(self, receiver: int, selector: str, *args) -> int:
        """
        Call Objective-C method.
        
        Args:
            receiver: Object or class address
            selector: Method name
            *args: Method arguments
            
        Returns:
            Return value
        """
        return self.objc.msg_send(receiver, selector, *args)

    def get_objc_class(self, name: str) -> ObjCClass | None:
        """Get Objective-C class by name."""
        return self.objc.get_class(name)

    def create_objc_object(self, class_name: str) -> int:
        """Create Objective-C object."""
        cls = self.objc.get_class(class_name)
        if not cls:
            raise ValueError(f"Class not found: {class_name}")

        obj = self.objc.alloc_object(cls)
        return obj.address

    def create_nsstring(self, value: str) -> int:
        """Create NSString with value."""
        return self.objc._create_nsstring(value)

    # ==================== Symbol Resolution ====================

    def find_symbol(self, name: str) -> int:
        """Find symbol address."""
        if not name.startswith('_'):
            name = '_' + name
        return self.dyld.resolve_symbol(name)

    def get_symbol_name(self, address: int) -> str | None:
        """Get symbol name for address."""
        for image in self.dyld.image_list:
            for name, addr in image.symbols.items():
                if addr == address:
                    return name
        return None

    # ==================== Stub Implementations ====================

    def _stub_NSLog(self, format_str: int, *args) -> int:
        """NSLog stub."""
        fmt = self.emulator.memory.read_string(format_str)
        logger.info(f"NSLog: {fmt}")
        return 0

    def _stub_NSStringFromClass(self, cls_addr: int) -> int:
        """NSStringFromClass stub."""
        cls = self.objc.get_class_by_address(cls_addr)
        if cls:
            return self.objc._create_nsstring(cls.name)
        return 0

    def _stub_printf(self, format_str: int, *args) -> int:
        """printf stub."""
        fmt = self.emulator.memory.read_string(format_str)
        logger.info(f"printf: {fmt}")
        return len(fmt)

    def _stub_puts(self, s: int) -> int:
        """puts stub."""
        string = self.emulator.memory.read_string(s)
        logger.info(f"puts: {string}")
        return len(string)

    def _stub_malloc(self, size: int) -> int:
        """malloc stub."""
        return self.emulator.memory.alloc(size)

    def _stub_free(self, ptr: int) -> int:
        """free stub."""
        self.emulator.memory.free(ptr)
        return 0

    def _stub_memcpy(self, dest: int, src: int, n: int) -> int:
        """memcpy stub."""
        data = self.emulator.memory.read(src, n)
        self.emulator.memory.write(dest, data)
        return dest

    def _stub_memset(self, s: int, c: int, n: int) -> int:
        """memset stub."""
        self.emulator.memory.write(s, bytes([c & 0xFF]) * n)
        return s

    def _stub_strlen(self, s: int) -> int:
        """strlen stub."""
        string = self.emulator.memory.read_string(s)
        return len(string)

    def _stub_strcmp(self, s1: int, s2: int) -> int:
        """strcmp stub."""
        str1 = self.emulator.memory.read_string(s1)
        str2 = self.emulator.memory.read_string(s2)
        if str1 < str2:
            return -1
        elif str1 > str2:
            return 1
        return 0

    def _stub_strcpy(self, dest: int, src: int) -> int:
        """strcpy stub."""
        string = self.emulator.memory.read_string(src)
        self.emulator.memory.write(dest, string.encode() + b'\x00')
        return dest

    def _stub_objc_msgSend(self, receiver: int, selector: int, *args) -> int:
        """objc_msgSend stub."""
        return self.objc.msg_send(receiver, selector, *args)

    def _stub_objc_getClass(self, name: int) -> int:
        """objc_getClass stub."""
        class_name = self.emulator.memory.read_string(name)
        cls = self.objc.get_class(class_name)
        return cls.address if cls else 0

    def _stub_objc_alloc(self, cls: int, *args) -> int:
        """objc_alloc stub."""
        objc_cls = self.objc.get_class_by_address(cls)
        if objc_cls:
            obj = self.objc.alloc_object(objc_cls)
            return obj.address
        return 0

    def _stub_objc_retain(self, obj: int) -> int:
        """objc_retain stub."""
        objc_obj = self.objc.get_object(obj)
        if objc_obj:
            objc_obj.retain_count += 1
        return obj

    def _stub_objc_release(self, obj: int) -> int:
        """objc_release stub."""
        objc_obj = self.objc.get_object(obj)
        if objc_obj:
            self.objc.release_object(objc_obj)
        return 0

    def _stub_objc_autorelease(self, obj: int) -> int:
        """objc_autorelease stub."""
        return obj

    def _stub_sel_registerName(self, name: int) -> int:
        """sel_registerName stub."""
        sel_name = self.emulator.memory.read_string(name)
        sel = self.objc.get_selector(sel_name)
        return sel.address

    def _stub_sel_getName(self, sel: int) -> int:
        """sel_getName stub."""
        selector = self.objc.get_selector_by_address(sel)
        if selector:
            addr = self.emulator.memory.alloc(len(selector.name) + 1)
            self.emulator.memory.write(addr, selector.name.encode() + b'\x00')
            return addr
        return 0

    def _stub_class_getName(self, cls: int) -> int:
        """class_getName stub."""
        objc_cls = self.objc.get_class_by_address(cls)
        if objc_cls:
            addr = self.emulator.memory.alloc(len(objc_cls.name) + 1)
            self.emulator.memory.write(addr, objc_cls.name.encode() + b'\x00')
            return addr
        return 0

    def _stub_SecItemCopyMatching(self, query: int, result: int) -> int:
        """SecItemCopyMatching stub - keychain access."""
        logger.debug("SecItemCopyMatching called")
        return -25300  # errSecItemNotFound

    def _stub_SecItemAdd(self, attrs: int, result: int) -> int:
        """SecItemAdd stub - keychain add."""
        logger.debug("SecItemAdd called")
        return 0  # Success


# ==================== Utility Functions ====================

def create_ios_emulator(arch: str = 'arm64') -> tuple['Emulator', iOSEmulator]:
    """
    Create iOS emulator with default configuration.
    
    Args:
        arch: Architecture ('arm64' or 'arm')
        
    Returns:
        Tuple of (Emulator, iOSEmulator)
    """
    # Import here to avoid circular import
    from ..core.emulator import Emulator

    if arch == 'arm64':
        emu = Emulator(arch='arm64')
    else:
        emu = Emulator(arch='arm')

    ios = iOSEmulator(emu)
    return emu, ios
