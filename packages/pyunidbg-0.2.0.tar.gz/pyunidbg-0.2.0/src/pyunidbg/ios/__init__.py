"""
iOS support for PyUniDbg.

Provides iOS/Darwin emulation capabilities:
- Mach-O binary loader (32-bit and 64-bit)
- iOS/Darwin syscalls
- Objective-C runtime bridge
- dyld dynamic linker emulation

Usage:
    from pyunidbg.ios import iOSEmulator, create_ios_emulator
    
    emu, ios = create_ios_emulator(arch='arm64')
    ios.load_binary('/path/to/app')
    result = ios.call_function('my_function')
"""

# Mach-O parsing
# iOS emulator
from .emulator import (
    DyldEmulator,
    LoadedImage,
    create_ios_emulator,
    iOSEmulator,
    iOSMemoryLayout,
)
from .macho import (
    DylibInfo,
    LoadCommand,
    MachOFile,
    MachOHeader,
    MachOParser,
    MachOSection,
    MachOSegment,
    MachOSymbol,
)

# Objective-C runtime
from .objc import (
    ObjCBlock,
    ObjCClass,
    ObjCIvar,
    ObjCMethod,
    ObjCObject,
    ObjCProperty,
    ObjCProtocol,
    ObjCRuntime,
    ObjCSelector,
    TypeEncoding,
)

# Darwin syscalls
from .syscall import DarwinSyscallHandler

__all__ = [
    # Mach-O
    'MachOFile',
    'MachOHeader',
    'MachOSegment',
    'MachOSection',
    'MachOSymbol',
    'MachOParser',
    'DylibInfo',
    'LoadCommand',

    # Syscalls
    'DarwinSyscallHandler',

    # Objective-C
    'ObjCRuntime',
    'ObjCClass',
    'ObjCObject',
    'ObjCMethod',
    'ObjCSelector',
    'ObjCIvar',
    'ObjCProperty',
    'ObjCProtocol',
    'ObjCBlock',
    'TypeEncoding',

    # Emulator
    'iOSEmulator',
    'iOSMemoryLayout',
    'LoadedImage',
    'DyldEmulator',
    'create_ios_emulator',
]
