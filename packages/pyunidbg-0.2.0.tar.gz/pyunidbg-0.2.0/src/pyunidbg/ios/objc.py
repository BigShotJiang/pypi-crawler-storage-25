"""
Objective-C runtime bridge for iOS emulation.

Provides Objective-C runtime emulation:
- Class creation and management
- Object allocation and messaging
- Selector handling
- Method swizzling support
- Block support

References:
- https://developer.apple.com/documentation/objectivec/objective-c_runtime
"""

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== Type Encodings ====================

class TypeEncoding:
    """Objective-C type encodings."""
    CHAR = 'c'
    INT = 'i'
    SHORT = 's'
    LONG = 'l'
    LONG_LONG = 'q'
    UNSIGNED_CHAR = 'C'
    UNSIGNED_INT = 'I'
    UNSIGNED_SHORT = 'S'
    UNSIGNED_LONG = 'L'
    UNSIGNED_LONG_LONG = 'Q'
    FLOAT = 'f'
    DOUBLE = 'd'
    BOOL = 'B'
    VOID = 'v'
    CHAR_PTR = '*'
    OBJECT = '@'
    CLASS = '#'
    SELECTOR = ':'
    ARRAY = '['
    STRUCT = '{'
    UNION = '('
    BIT_FIELD = 'b'
    POINTER = '^'
    UNKNOWN = '?'


# ==================== Runtime Structures ====================

@dataclass
class ObjCIvar:
    """Instance variable."""
    name: str
    type_encoding: str
    offset: int
    size: int


@dataclass
class ObjCMethod:
    """Method definition."""
    name: str  # selector
    type_encoding: str
    implementation: int  # IMP address
    python_impl: Callable | None = None


@dataclass
class ObjCProperty:
    """Property definition."""
    name: str
    attributes: str
    getter: str | None = None
    setter: str | None = None


@dataclass
class ObjCProtocol:
    """Protocol definition."""
    name: str
    methods: dict[str, ObjCMethod] = field(default_factory=dict)
    class_methods: dict[str, ObjCMethod] = field(default_factory=dict)
    properties: dict[str, ObjCProperty] = field(default_factory=dict)


@dataclass
class ObjCClass:
    """Objective-C class definition."""
    name: str
    superclass: Optional['ObjCClass'] = None
    metaclass: Optional['ObjCClass'] = None
    instance_size: int = 8  # Minimum for isa pointer

    # Instance variables
    ivars: dict[str, ObjCIvar] = field(default_factory=dict)

    # Instance methods
    methods: dict[str, ObjCMethod] = field(default_factory=dict)

    # Class methods (stored in metaclass)
    class_methods: dict[str, ObjCMethod] = field(default_factory=dict)

    # Properties
    properties: dict[str, ObjCProperty] = field(default_factory=dict)

    # Protocols
    protocols: list[ObjCProtocol] = field(default_factory=list)

    # Runtime address
    address: int = 0

    def get_method(self, selector: str) -> ObjCMethod | None:
        """Get method, checking superclass chain."""
        if selector in self.methods:
            return self.methods[selector]
        if self.superclass:
            return self.superclass.get_method(selector)
        return None

    def get_class_method(self, selector: str) -> ObjCMethod | None:
        """Get class method."""
        if selector in self.class_methods:
            return self.class_methods[selector]
        if self.superclass:
            return self.superclass.get_class_method(selector)
        return None

    def responds_to(self, selector: str) -> bool:
        """Check if class responds to selector."""
        return self.get_method(selector) is not None


@dataclass
class ObjCObject:
    """Objective-C object instance."""
    isa: ObjCClass
    address: int
    ivars: dict[str, Any] = field(default_factory=dict)
    retained: bool = True
    retain_count: int = 1

    def get_ivar(self, name: str) -> Any:
        """Get instance variable value."""
        return self.ivars.get(name)

    def set_ivar(self, name: str, value: Any) -> None:
        """Set instance variable value."""
        self.ivars[name] = value


@dataclass
class ObjCSelector:
    """Selector (method name)."""
    name: str
    address: int = 0


@dataclass
class ObjCBlock:
    """Objective-C block."""
    isa: int  # _NSConcreteStackBlock or _NSConcreteGlobalBlock
    flags: int
    reserved: int
    invoke: int  # Function pointer
    descriptor: int
    captured: dict[str, Any] = field(default_factory=dict)


# ==================== Runtime ====================

class ObjCRuntime:
    """
    Objective-C runtime emulation.
    
    Provides:
    - Class registration and lookup
    - Object allocation and deallocation
    - Message sending (objc_msgSend)
    - Selector management
    - Method swizzling
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator

        # Class registry
        self.classes: dict[str, ObjCClass] = {}
        self.class_by_address: dict[int, ObjCClass] = {}

        # Object registry
        self.objects: dict[int, ObjCObject] = {}
        self.next_object_address = 0x200000000 if emulator.is_64bit else 0x20000000

        # Selector registry
        self.selectors: dict[str, ObjCSelector] = {}
        self.selector_by_address: dict[int, ObjCSelector] = {}
        self.next_selector_address = 0x300000000 if emulator.is_64bit else 0x30000000

        # Protocol registry
        self.protocols: dict[str, ObjCProtocol] = {}

        # Class address allocation
        self.next_class_address = 0x100000000 if emulator.is_64bit else 0x10000000

        # Initialize root classes
        self._init_root_classes()

        # Hook objc_msgSend
        self._setup_hooks()

    def _init_root_classes(self) -> None:
        """Initialize root Objective-C classes."""
        # NSObject - root of most classes
        nsobject = self.register_class('NSObject')

        # Add basic NSObject methods
        self._add_nsobject_methods(nsobject)

        # NSString
        nsstring = self.register_class('NSString', superclass=nsobject)
        self._add_nsstring_methods(nsstring)

        # NSMutableString
        self.register_class('NSMutableString', superclass=nsstring)

        # NSArray
        nsarray = self.register_class('NSArray', superclass=nsobject)
        self._add_nsarray_methods(nsarray)

        # NSMutableArray
        self.register_class('NSMutableArray', superclass=nsarray)

        # NSDictionary
        nsdict = self.register_class('NSDictionary', superclass=nsobject)
        self._add_nsdictionary_methods(nsdict)

        # NSMutableDictionary
        self.register_class('NSMutableDictionary', superclass=nsdict)

        # NSNumber
        nsnumber = self.register_class('NSNumber', superclass=nsobject)
        self._add_nsnumber_methods(nsnumber)

        # NSData
        nsdata = self.register_class('NSData', superclass=nsobject)
        self._add_nsdata_methods(nsdata)

        # NSMutableData
        self.register_class('NSMutableData', superclass=nsdata)

        # NSURL
        self.register_class('NSURL', superclass=nsobject)

        # NSError
        self.register_class('NSError', superclass=nsobject)

        # NSException
        self.register_class('NSException', superclass=nsobject)

        # NSBundle
        nsbundle = self.register_class('NSBundle', superclass=nsobject)
        self._add_nsbundle_methods(nsbundle)

        # NSFileManager
        self.register_class('NSFileManager', superclass=nsobject)

        # NSUserDefaults
        self.register_class('NSUserDefaults', superclass=nsobject)

        # NSNotificationCenter
        self.register_class('NSNotificationCenter', superclass=nsobject)

        # NSThread
        self.register_class('NSThread', superclass=nsobject)

        # NSRunLoop
        self.register_class('NSRunLoop', superclass=nsobject)

        # NSDate
        self.register_class('NSDate', superclass=nsobject)

        # NSCalendar
        self.register_class('NSCalendar', superclass=nsobject)

        # NSLocale
        self.register_class('NSLocale', superclass=nsobject)

        # NSTimeZone
        self.register_class('NSTimeZone', superclass=nsobject)

        # UIKit classes (iOS specific)
        self.register_class('UIApplication', superclass=nsobject)
        self.register_class('UIDevice', superclass=nsobject)
        self.register_class('UIScreen', superclass=nsobject)
        self.register_class('UIWindow', superclass=nsobject)
        self.register_class('UIView', superclass=nsobject)
        self.register_class('UIViewController', superclass=nsobject)

    def _add_nsobject_methods(self, cls: ObjCClass) -> None:
        """Add NSObject methods."""
        # Instance methods
        cls.methods['init'] = ObjCMethod('init', '@@:', 0, self._nsobject_init)
        cls.methods['dealloc'] = ObjCMethod('dealloc', 'v@:', 0, self._nsobject_dealloc)
        cls.methods['retain'] = ObjCMethod('retain', '@@:', 0, self._nsobject_retain)
        cls.methods['release'] = ObjCMethod('release', 'v@:', 0, self._nsobject_release)
        cls.methods['autorelease'] = ObjCMethod('autorelease', '@@:', 0, self._nsobject_autorelease)
        cls.methods['retainCount'] = ObjCMethod('retainCount', 'Q@:', 0, self._nsobject_retainCount)
        cls.methods['class'] = ObjCMethod('class', '#@:', 0, self._nsobject_class)
        cls.methods['superclass'] = ObjCMethod('superclass', '#@:', 0, self._nsobject_superclass)
        cls.methods['isKindOfClass:'] = ObjCMethod('isKindOfClass:', 'B@:#', 0, self._nsobject_isKindOfClass)
        cls.methods['isMemberOfClass:'] = ObjCMethod('isMemberOfClass:', 'B@:#', 0, self._nsobject_isMemberOfClass)
        cls.methods['respondsToSelector:'] = ObjCMethod('respondsToSelector:', 'B@::', 0, self._nsobject_respondsToSelector)
        cls.methods['performSelector:'] = ObjCMethod('performSelector:', '@@::', 0, self._nsobject_performSelector)
        cls.methods['description'] = ObjCMethod('description', '@@:', 0, self._nsobject_description)
        cls.methods['debugDescription'] = ObjCMethod('debugDescription', '@@:', 0, self._nsobject_description)
        cls.methods['hash'] = ObjCMethod('hash', 'Q@:', 0, self._nsobject_hash)
        cls.methods['isEqual:'] = ObjCMethod('isEqual:', 'B@:@', 0, self._nsobject_isEqual)
        cls.methods['copy'] = ObjCMethod('copy', '@@:', 0, self._nsobject_copy)
        cls.methods['mutableCopy'] = ObjCMethod('mutableCopy', '@@:', 0, self._nsobject_mutableCopy)

        # Class methods
        cls.class_methods['alloc'] = ObjCMethod('alloc', '@#:', 0, self._nsobject_alloc)
        cls.class_methods['allocWithZone:'] = ObjCMethod('allocWithZone:', '@#:^v', 0, self._nsobject_alloc)
        cls.class_methods['new'] = ObjCMethod('new', '@#:', 0, self._nsobject_new)
        cls.class_methods['class'] = ObjCMethod('class', '##:', 0, self._nsobject_class_method)
        cls.class_methods['superclass'] = ObjCMethod('superclass', '##:', 0, self._nsobject_superclass_method)
        cls.class_methods['description'] = ObjCMethod('description', '@#:', 0, self._nsobject_class_description)

    def _add_nsstring_methods(self, cls: ObjCClass) -> None:
        """Add NSString methods."""
        cls.methods['length'] = ObjCMethod('length', 'Q@:', 0, self._nsstring_length)
        cls.methods['characterAtIndex:'] = ObjCMethod('characterAtIndex:', 'S@:Q', 0)
        cls.methods['UTF8String'] = ObjCMethod('UTF8String', '*@:', 0, self._nsstring_UTF8String)
        cls.methods['cStringUsingEncoding:'] = ObjCMethod('cStringUsingEncoding:', '*@:Q', 0)
        cls.methods['isEqualToString:'] = ObjCMethod('isEqualToString:', 'B@:@', 0, self._nsstring_isEqualToString)
        cls.methods['compare:'] = ObjCMethod('compare:', 'q@:@', 0)
        cls.methods['hasPrefix:'] = ObjCMethod('hasPrefix:', 'B@:@', 0)
        cls.methods['hasSuffix:'] = ObjCMethod('hasSuffix:', 'B@:@', 0)
        cls.methods['substringFromIndex:'] = ObjCMethod('substringFromIndex:', '@@:Q', 0)
        cls.methods['substringToIndex:'] = ObjCMethod('substringToIndex:', '@@:Q', 0)
        cls.methods['substringWithRange:'] = ObjCMethod('substringWithRange:', '@@:{NSRange=QQ}', 0)
        cls.methods['stringByAppendingString:'] = ObjCMethod('stringByAppendingString:', '@@:@', 0)
        cls.methods['lowercaseString'] = ObjCMethod('lowercaseString', '@@:', 0)
        cls.methods['uppercaseString'] = ObjCMethod('uppercaseString', '@@:', 0)
        cls.methods['componentsSeparatedByString:'] = ObjCMethod('componentsSeparatedByString:', '@@:@', 0)
        cls.methods['stringByReplacingOccurrencesOfString:withString:'] = ObjCMethod(
            'stringByReplacingOccurrencesOfString:withString:', '@@:@@', 0)

        # Class methods
        cls.class_methods['string'] = ObjCMethod('string', '@#:', 0)
        cls.class_methods['stringWithUTF8String:'] = ObjCMethod('stringWithUTF8String:', '@#:*', 0,
                                                                 self._nsstring_stringWithUTF8String)
        cls.class_methods['stringWithFormat:'] = ObjCMethod('stringWithFormat:', '@#:@', 0)
        cls.class_methods['stringWithCString:encoding:'] = ObjCMethod('stringWithCString:encoding:', '@#:*Q', 0)

    def _add_nsarray_methods(self, cls: ObjCClass) -> None:
        """Add NSArray methods."""
        cls.methods['count'] = ObjCMethod('count', 'Q@:', 0, self._nsarray_count)
        cls.methods['objectAtIndex:'] = ObjCMethod('objectAtIndex:', '@@:Q', 0, self._nsarray_objectAtIndex)
        cls.methods['firstObject'] = ObjCMethod('firstObject', '@@:', 0)
        cls.methods['lastObject'] = ObjCMethod('lastObject', '@@:', 0)
        cls.methods['containsObject:'] = ObjCMethod('containsObject:', 'B@:@', 0)
        cls.methods['indexOfObject:'] = ObjCMethod('indexOfObject:', 'Q@:@', 0)
        cls.methods['arrayByAddingObject:'] = ObjCMethod('arrayByAddingObject:', '@@:@', 0)
        cls.methods['componentsJoinedByString:'] = ObjCMethod('componentsJoinedByString:', '@@:@', 0)

        # Class methods
        cls.class_methods['array'] = ObjCMethod('array', '@#:', 0)
        cls.class_methods['arrayWithObject:'] = ObjCMethod('arrayWithObject:', '@#:@', 0)
        cls.class_methods['arrayWithObjects:count:'] = ObjCMethod('arrayWithObjects:count:', '@#:^@Q', 0)

    def _add_nsdictionary_methods(self, cls: ObjCClass) -> None:
        """Add NSDictionary methods."""
        cls.methods['count'] = ObjCMethod('count', 'Q@:', 0)
        cls.methods['objectForKey:'] = ObjCMethod('objectForKey:', '@@:@', 0, self._nsdictionary_objectForKey)
        cls.methods['valueForKey:'] = ObjCMethod('valueForKey:', '@@:@', 0)
        cls.methods['allKeys'] = ObjCMethod('allKeys', '@@:', 0)
        cls.methods['allValues'] = ObjCMethod('allValues', '@@:', 0)

        # Class methods
        cls.class_methods['dictionary'] = ObjCMethod('dictionary', '@#:', 0)
        cls.class_methods['dictionaryWithObject:forKey:'] = ObjCMethod('dictionaryWithObject:forKey:', '@#:@@', 0)

    def _add_nsnumber_methods(self, cls: ObjCClass) -> None:
        """Add NSNumber methods."""
        cls.methods['intValue'] = ObjCMethod('intValue', 'i@:', 0, self._nsnumber_intValue)
        cls.methods['integerValue'] = ObjCMethod('integerValue', 'q@:', 0)
        cls.methods['unsignedIntegerValue'] = ObjCMethod('unsignedIntegerValue', 'Q@:', 0)
        cls.methods['floatValue'] = ObjCMethod('floatValue', 'f@:', 0)
        cls.methods['doubleValue'] = ObjCMethod('doubleValue', 'd@:', 0)
        cls.methods['boolValue'] = ObjCMethod('boolValue', 'B@:', 0, self._nsnumber_boolValue)
        cls.methods['stringValue'] = ObjCMethod('stringValue', '@@:', 0)

        # Class methods
        cls.class_methods['numberWithInt:'] = ObjCMethod('numberWithInt:', '@#:i', 0, self._nsnumber_numberWithInt)
        cls.class_methods['numberWithInteger:'] = ObjCMethod('numberWithInteger:', '@#:q', 0)
        cls.class_methods['numberWithFloat:'] = ObjCMethod('numberWithFloat:', '@#:f', 0)
        cls.class_methods['numberWithDouble:'] = ObjCMethod('numberWithDouble:', '@#:d', 0)
        cls.class_methods['numberWithBool:'] = ObjCMethod('numberWithBool:', '@#:B', 0, self._nsnumber_numberWithBool)

    def _add_nsdata_methods(self, cls: ObjCClass) -> None:
        """Add NSData methods."""
        cls.methods['length'] = ObjCMethod('length', 'Q@:', 0, self._nsdata_length)
        cls.methods['bytes'] = ObjCMethod('bytes', '^v@:', 0, self._nsdata_bytes)
        cls.methods['getBytes:length:'] = ObjCMethod('getBytes:length:', 'v@:^vQ', 0)
        cls.methods['subdataWithRange:'] = ObjCMethod('subdataWithRange:', '@@:{NSRange=QQ}', 0)
        cls.methods['writeToFile:atomically:'] = ObjCMethod('writeToFile:atomically:', 'B@:@B', 0)

        # Class methods
        cls.class_methods['data'] = ObjCMethod('data', '@#:', 0)
        cls.class_methods['dataWithBytes:length:'] = ObjCMethod('dataWithBytes:length:', '@#:^vQ', 0)
        cls.class_methods['dataWithContentsOfFile:'] = ObjCMethod('dataWithContentsOfFile:', '@#:@', 0)

    def _add_nsbundle_methods(self, cls: ObjCClass) -> None:
        """Add NSBundle methods."""
        cls.methods['bundlePath'] = ObjCMethod('bundlePath', '@@:', 0)
        cls.methods['bundleIdentifier'] = ObjCMethod('bundleIdentifier', '@@:', 0, self._nsbundle_bundleIdentifier)
        cls.methods['infoDictionary'] = ObjCMethod('infoDictionary', '@@:', 0)
        cls.methods['objectForInfoDictionaryKey:'] = ObjCMethod('objectForInfoDictionaryKey:', '@@:@', 0)
        cls.methods['pathForResource:ofType:'] = ObjCMethod('pathForResource:ofType:', '@@:@@', 0)
        cls.methods['URLForResource:withExtension:'] = ObjCMethod('URLForResource:withExtension:', '@@:@@', 0)

        # Class methods
        cls.class_methods['mainBundle'] = ObjCMethod('mainBundle', '@#:', 0, self._nsbundle_mainBundle)
        cls.class_methods['bundleWithPath:'] = ObjCMethod('bundleWithPath:', '@#:@', 0)
        cls.class_methods['bundleForClass:'] = ObjCMethod('bundleForClass:', '@#:#', 0)

    def _setup_hooks(self) -> None:
        """Set up runtime hooks."""
        # Hook objc_msgSend if we have symbol resolution
        pass

    # ==================== Class Management ====================

    def register_class(self, name: str, superclass: ObjCClass = None) -> ObjCClass:
        """Register a new Objective-C class."""
        if name in self.classes:
            return self.classes[name]

        address = self.next_class_address
        self.next_class_address += 0x1000

        cls = ObjCClass(
            name=name,
            superclass=superclass,
            address=address,
            instance_size=superclass.instance_size + 8 if superclass else 8
        )

        # Create metaclass
        metaclass = ObjCClass(
            name=f"{name}_meta",
            address=address + 0x100
        )
        cls.metaclass = metaclass

        self.classes[name] = cls
        self.class_by_address[address] = cls

        logger.debug(f"Registered class {name} at 0x{address:x}")
        return cls

    def get_class(self, name: str) -> ObjCClass | None:
        """Get class by name."""
        return self.classes.get(name)

    def get_class_by_address(self, address: int) -> ObjCClass | None:
        """Get class by address."""
        return self.class_by_address.get(address)

    # ==================== Selector Management ====================

    def get_selector(self, name: str) -> ObjCSelector:
        """Get or create selector."""
        if name not in self.selectors:
            address = self.next_selector_address
            self.next_selector_address += 0x10

            sel = ObjCSelector(name=name, address=address)
            self.selectors[name] = sel
            self.selector_by_address[address] = sel

        return self.selectors[name]

    def get_selector_by_address(self, address: int) -> ObjCSelector | None:
        """Get selector by address."""
        return self.selector_by_address.get(address)

    # ==================== Object Management ====================

    def alloc_object(self, cls: ObjCClass) -> ObjCObject:
        """Allocate a new object."""
        address = self.next_object_address
        self.next_object_address += cls.instance_size

        obj = ObjCObject(
            isa=cls,
            address=address,
            retain_count=1
        )

        self.objects[address] = obj

        logger.debug(f"Allocated {cls.name} at 0x{address:x}")
        return obj

    def get_object(self, address: int) -> ObjCObject | None:
        """Get object by address."""
        return self.objects.get(address)

    def release_object(self, obj: ObjCObject) -> None:
        """Release an object."""
        obj.retain_count -= 1
        if obj.retain_count <= 0:
            if obj.address in self.objects:
                del self.objects[obj.address]
            logger.debug(f"Deallocated {obj.isa.name} at 0x{obj.address:x}")

    # ==================== Message Sending ====================

    def msg_send(self, receiver: int, selector: int, *args) -> Any:
        """
        Send message to object (objc_msgSend).
        
        Args:
            receiver: Object address (or class for class methods)
            selector: Selector address or name
            *args: Message arguments
            
        Returns:
            Message result
        """
        # Get selector
        if isinstance(selector, int):
            sel = self.get_selector_by_address(selector)
            if not sel:
                logger.warning(f"Unknown selector address: 0x{selector:x}")
                return 0
            sel_name = sel.name
        else:
            sel_name = selector

        # Get receiver
        obj = self.get_object(receiver)
        cls = self.get_class_by_address(receiver)

        if obj:
            # Instance method
            method = obj.isa.get_method(sel_name)
            if method and method.python_impl:
                return method.python_impl(obj, *args)
            elif method:
                logger.debug(f"[{obj.isa.name} {sel_name}] -> native IMP 0x{method.implementation:x}")
                return 0
            else:
                logger.warning(f"Unrecognized selector {sel_name} for {obj.isa.name}")
                return 0
        elif cls:
            # Class method
            method = cls.get_class_method(sel_name)
            if method and method.python_impl:
                return method.python_impl(cls, *args)
            elif method:
                logger.debug(f"[{cls.name} {sel_name}] -> native IMP 0x{method.implementation:x}")
                return 0
            else:
                logger.warning(f"Unrecognized class method {sel_name} for {cls.name}")
                return 0
        else:
            logger.warning(f"Invalid receiver: 0x{receiver:x}")
            return 0

    # ==================== NSObject Method Implementations ====================

    def _nsobject_alloc(self, cls: ObjCClass, *args) -> int:
        """[NSObject alloc]"""
        obj = self.alloc_object(cls)
        return obj.address

    def _nsobject_new(self, cls: ObjCClass, *args) -> int:
        """[NSObject new]"""
        obj = self.alloc_object(cls)
        return obj.address

    def _nsobject_init(self, obj: ObjCObject, *args) -> int:
        """[obj init]"""
        return obj.address

    def _nsobject_dealloc(self, obj: ObjCObject, *args) -> None:
        """[obj dealloc]"""
        self.release_object(obj)

    def _nsobject_retain(self, obj: ObjCObject, *args) -> int:
        """[obj retain]"""
        obj.retain_count += 1
        return obj.address

    def _nsobject_release(self, obj: ObjCObject, *args) -> None:
        """[obj release]"""
        self.release_object(obj)

    def _nsobject_autorelease(self, obj: ObjCObject, *args) -> int:
        """[obj autorelease]"""
        # Simplified - just return self
        return obj.address

    def _nsobject_retainCount(self, obj: ObjCObject, *args) -> int:
        """[obj retainCount]"""
        return obj.retain_count

    def _nsobject_class(self, obj: ObjCObject, *args) -> int:
        """[obj class]"""
        return obj.isa.address

    def _nsobject_superclass(self, obj: ObjCObject, *args) -> int:
        """[obj superclass]"""
        if obj.isa.superclass:
            return obj.isa.superclass.address
        return 0

    def _nsobject_isKindOfClass(self, obj: ObjCObject, target_class: int) -> int:
        """[obj isKindOfClass:]"""
        cls = obj.isa
        target = self.get_class_by_address(target_class)

        while cls:
            if cls == target:
                return 1
            cls = cls.superclass
        return 0

    def _nsobject_isMemberOfClass(self, obj: ObjCObject, target_class: int) -> int:
        """[obj isMemberOfClass:]"""
        target = self.get_class_by_address(target_class)
        return 1 if obj.isa == target else 0

    def _nsobject_respondsToSelector(self, obj: ObjCObject, selector: int) -> int:
        """[obj respondsToSelector:]"""
        sel = self.get_selector_by_address(selector)
        if sel and obj.isa.responds_to(sel.name):
            return 1
        return 0

    def _nsobject_performSelector(self, obj: ObjCObject, selector: int) -> int:
        """[obj performSelector:]"""
        return self.msg_send(obj.address, selector)

    def _nsobject_description(self, obj: ObjCObject, *args) -> int:
        """[obj description]"""
        desc = f"<{obj.isa.name}: 0x{obj.address:x}>"
        return self._create_nsstring(desc)

    def _nsobject_hash(self, obj: ObjCObject, *args) -> int:
        """[obj hash]"""
        return obj.address

    def _nsobject_isEqual(self, obj: ObjCObject, other: int) -> int:
        """[obj isEqual:]"""
        return 1 if obj.address == other else 0

    def _nsobject_copy(self, obj: ObjCObject, *args) -> int:
        """[obj copy]"""
        # Simplified - just retain
        obj.retain_count += 1
        return obj.address

    def _nsobject_mutableCopy(self, obj: ObjCObject, *args) -> int:
        """[obj mutableCopy]"""
        return self._nsobject_copy(obj)

    def _nsobject_class_method(self, cls: ObjCClass, *args) -> int:
        """[ClassName class]"""
        return cls.address

    def _nsobject_superclass_method(self, cls: ObjCClass, *args) -> int:
        """[ClassName superclass]"""
        if cls.superclass:
            return cls.superclass.address
        return 0

    def _nsobject_class_description(self, cls: ObjCClass, *args) -> int:
        """[ClassName description]"""
        return self._create_nsstring(cls.name)

    # ==================== NSString Methods ====================

    def _nsstring_length(self, obj: ObjCObject, *args) -> int:
        """[str length]"""
        value = obj.get_ivar('_value')
        if value:
            return len(value)
        return 0

    def _nsstring_UTF8String(self, obj: ObjCObject, *args) -> int:
        """[str UTF8String]"""
        value = obj.get_ivar('_value')
        if value:
            # Allocate and write string
            data = value.encode('utf-8') + b'\x00'
            addr = self.emulator.memory.alloc(len(data))
            self.emulator.memory.write(addr, data)
            return addr
        return 0

    def _nsstring_isEqualToString(self, obj: ObjCObject, other: int) -> int:
        """[str isEqualToString:]"""
        other_obj = self.get_object(other)
        if other_obj:
            return 1 if obj.get_ivar('_value') == other_obj.get_ivar('_value') else 0
        return 0

    def _nsstring_stringWithUTF8String(self, cls: ObjCClass, cstr: int) -> int:
        """[NSString stringWithUTF8String:]"""
        string = self.emulator.memory.read_string(cstr)
        return self._create_nsstring(string)

    def _create_nsstring(self, value: str) -> int:
        """Create NSString with value."""
        cls = self.get_class('NSString')
        obj = self.alloc_object(cls)
        obj.set_ivar('_value', value)
        return obj.address

    # ==================== NSArray Methods ====================

    def _nsarray_count(self, obj: ObjCObject, *args) -> int:
        """[array count]"""
        items = obj.get_ivar('_items')
        return len(items) if items else 0

    def _nsarray_objectAtIndex(self, obj: ObjCObject, index: int) -> int:
        """[array objectAtIndex:]"""
        items = obj.get_ivar('_items')
        if items and 0 <= index < len(items):
            return items[index]
        return 0

    # ==================== NSDictionary Methods ====================

    def _nsdictionary_objectForKey(self, obj: ObjCObject, key: int) -> int:
        """[dict objectForKey:]"""
        items = obj.get_ivar('_items')
        if items:
            return items.get(key, 0)
        return 0

    # ==================== NSNumber Methods ====================

    def _nsnumber_intValue(self, obj: ObjCObject, *args) -> int:
        """[num intValue]"""
        return int(obj.get_ivar('_value') or 0)

    def _nsnumber_boolValue(self, obj: ObjCObject, *args) -> int:
        """[num boolValue]"""
        return 1 if obj.get_ivar('_value') else 0

    def _nsnumber_numberWithInt(self, cls: ObjCClass, value: int) -> int:
        """[NSNumber numberWithInt:]"""
        obj = self.alloc_object(cls)
        obj.set_ivar('_value', value)
        return obj.address

    def _nsnumber_numberWithBool(self, cls: ObjCClass, value: int) -> int:
        """[NSNumber numberWithBool:]"""
        obj = self.alloc_object(cls)
        obj.set_ivar('_value', bool(value))
        return obj.address

    # ==================== NSData Methods ====================

    def _nsdata_length(self, obj: ObjCObject, *args) -> int:
        """[data length]"""
        data = obj.get_ivar('_bytes')
        return len(data) if data else 0

    def _nsdata_bytes(self, obj: ObjCObject, *args) -> int:
        """[data bytes]"""
        data = obj.get_ivar('_bytes')
        if data:
            addr = obj.get_ivar('_bytes_addr')
            if not addr:
                addr = self.emulator.memory.alloc(len(data))
                self.emulator.memory.write(addr, data)
                obj.set_ivar('_bytes_addr', addr)
            return addr
        return 0

    # ==================== NSBundle Methods ====================

    def _nsbundle_mainBundle(self, cls: ObjCClass, *args) -> int:
        """[NSBundle mainBundle]"""
        # Return singleton
        if not hasattr(self, '_main_bundle'):
            obj = self.alloc_object(cls)
            obj.set_ivar('_bundleIdentifier', 'com.example.app')
            obj.set_ivar('_bundlePath', '/var/containers/Bundle/Application/UUID/App.app')
            self._main_bundle = obj.address
        return self._main_bundle

    def _nsbundle_bundleIdentifier(self, obj: ObjCObject, *args) -> int:
        """[bundle bundleIdentifier]"""
        identifier = obj.get_ivar('_bundleIdentifier') or 'com.example.app'
        return self._create_nsstring(identifier)
