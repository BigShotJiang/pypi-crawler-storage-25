"""
pwntools Integration - Exploit development utilities for PyUniDbg.

Provides integration with pwntools for:
- ROP gadget finding and chain building
- Shellcode generation
- Format string exploitation
- Cyclic pattern generation and finding
- Binary exploitation utilities

Example:
    from pyunidbg.pwn import PwnContext
    
    # Create context from emulator
    pwn = PwnContext(emulator)
    
    # Find ROP gadgets in loaded libraries
    gadgets = pwn.find_gadgets("libnative.so")
    
    # Build ROP chain
    rop = pwn.rop("libnative.so")
    rop.call("mprotect", [0x1000, 0x1000, 7])
    chain = rop.chain()
    
    # Generate shellcode
    shellcode = pwn.shellcraft.sh()
    
    # Format string exploitation
    payload = pwn.format_string(target_addr, value)
    
    # Cyclic patterns
    pattern = pwn.cyclic(100)
    offset = pwn.cyclic_find(b"aaab")

Note:
    This module requires pwntools to be installed:
    pip install pwntools
"""

from __future__ import annotations

import logging
import struct
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Union

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator
    from pyunidbg.loader.elf_loader import LoadedModule

logger = logging.getLogger(__name__)


# ==================== Lazy pwntools Import ====================

_pwn = None
_pwn_available = None


def _import_pwntools():
    """Lazily import pwntools."""
    global _pwn, _pwn_available

    if _pwn_available is not None:
        return _pwn_available

    try:
        import pwn
        _pwn = pwn
        _pwn_available = True
        logger.debug("pwntools successfully imported")
    except ImportError:
        _pwn_available = False
        logger.warning(
            "pwntools not installed. Install with: pip install pwntools"
        )

    return _pwn_available


def require_pwntools(func):
    """Decorator that requires pwntools to be available."""
    def wrapper(*args, **kwargs):
        if not _import_pwntools():
            raise ImportError(
                "pwntools is required for this feature. "
                "Install with: pip install pwntools"
            )
        return func(*args, **kwargs)
    return wrapper


# ==================== Gadget Types ====================

@dataclass
class Gadget:
    """Represents a ROP gadget."""
    address: int
    insns: list[str]  # Instructions in the gadget
    length: int  # Byte length

    def __repr__(self) -> str:
        return f"Gadget({self.address:#x}: {' ; '.join(self.insns)})"

    def __str__(self) -> str:
        return f"{self.address:#x}: {' ; '.join(self.insns)}"


@dataclass
class GadgetSearch:
    """Result of a gadget search."""
    query: str
    gadgets: list[Gadget]
    library: str | None = None

    def __len__(self) -> int:
        return len(self.gadgets)

    def __iter__(self):
        return iter(self.gadgets)

    def __getitem__(self, index):
        return self.gadgets[index]

    def __repr__(self) -> str:
        return f"GadgetSearch({self.query!r}, {len(self.gadgets)} results)"


# ==================== ROP Chain Builder ====================

class ROPChain:
    """
    ROP chain builder for PyUniDbg.
    
    Provides a convenient interface for building ROP chains
    using gadgets found in loaded libraries.
    
    Example:
        rop = ROPChain(pwn_context, "libnative.so")
        
        # Add gadgets manually
        rop.raw(0xdeadbeef)
        
        # Call a function
        rop.call(malloc_addr, [0x1000])
        
        # Use common patterns
        rop.ret()  # Simple return
        
        # Get the chain
        payload = rop.chain()
    """

    def __init__(self, context: PwnContext, library: str | None = None):
        self._context = context
        self._library = library
        self._chain: list[int] = []
        self._gadgets: dict[str, int] = {}

        # Find common gadgets
        self._find_common_gadgets()

    def _find_common_gadgets(self) -> None:
        """Find commonly used gadgets."""
        if self._library:
            # Try to find useful gadgets
            patterns = ["ret", "pop", "mov", "add", "sub"]
            for pattern in patterns:
                results = self._context.find_gadgets(self._library, pattern, limit=10)
                for gadget in results.gadgets:
                    key = " ; ".join(gadget.insns)
                    if key not in self._gadgets:
                        self._gadgets[key] = gadget.address

    def raw(self, value: int) -> ROPChain:
        """Add a raw value to the chain."""
        self._chain.append(value)
        return self

    def ret(self) -> ROPChain:
        """Add a ret gadget."""
        if "ret" in self._gadgets:
            self._chain.append(self._gadgets["ret"])
        else:
            # Search for ret gadget
            results = self._context.find_gadgets(self._library, "ret", limit=1)
            if results.gadgets:
                self._chain.append(results.gadgets[0].address)
        return self

    def nop(self) -> ROPChain:
        """Add a NOP (ret) gadget as a slide."""
        return self.ret()

    def call(self, target: int, args: list[int] = None) -> ROPChain:
        """
        Add a function call to the chain.
        
        For ARM64: Uses X0-X7 for arguments
        For ARM32: Uses R0-R3 for arguments, rest on stack
        """
        args = args or []

        if self._context.is_64bit:
            # ARM64 calling convention
            # Need pop gadgets for x0-x7
            reg_names = [f"x{i}" for i in range(min(8, len(args)))]
            for i, arg in enumerate(args):
                pop_gadget = f"pop {{{reg_names[i]}}}"
                if pop_gadget in self._gadgets:
                    self._chain.append(self._gadgets[pop_gadget])
                    self._chain.append(arg)
        else:
            # ARM32 calling convention
            reg_names = [f"r{i}" for i in range(min(4, len(args)))]
            for i, arg in enumerate(args[:4]):
                pop_gadget = f"pop {{{reg_names[i]}}}"
                if pop_gadget in self._gadgets:
                    self._chain.append(self._gadgets[pop_gadget])
                    self._chain.append(arg)

            # Additional args go on stack
            for arg in args[4:]:
                self._chain.append(arg)

        # Add the function address
        self._chain.append(target)

        return self

    def pivot(self, new_stack: int) -> ROPChain:
        """Add a stack pivot."""
        # Look for gadgets like "mov sp, x0; ret" or similar
        return self

    def chain(self) -> bytes:
        """Build and return the ROP chain as bytes."""
        if self._context.is_64bit:
            return b"".join(struct.pack("<Q", v) for v in self._chain)
        else:
            return b"".join(struct.pack("<I", v) for v in self._chain)

    def dump(self) -> str:
        """Dump the chain as a readable string."""
        lines = ["ROP Chain:"]
        ptr_size = 8 if self._context.is_64bit else 4

        for i, value in enumerate(self._chain):
            offset = i * ptr_size
            lines.append(f"  {offset:#06x}: {value:#018x}")

        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self._chain)

    def __repr__(self) -> str:
        return f"ROPChain({len(self._chain)} entries)"


# ==================== Shellcraft Wrapper ====================

class ShellcraftWrapper:
    """
    Wrapper for pwntools shellcraft.
    
    Provides easy access to shellcode generation for ARM/ARM64.
    
    Example:
        sc = pwn.shellcraft
        
        # Execve shell
        code = sc.sh()
        
        # Read/write operations
        code = sc.read(0, buffer, 100)
        code = sc.write(1, buffer, 100)
        
        # System calls
        code = sc.syscall('execve', '/bin/sh', 0, 0)
    """

    def __init__(self, context: PwnContext):
        self._context = context
        self._arch = 'aarch64' if context.is_64bit else 'arm'

    @require_pwntools
    def _get_shellcraft(self):
        """Get the appropriate shellcraft module."""
        if self._arch == 'aarch64':
            return _pwn.shellcraft.aarch64
        else:
            return _pwn.shellcraft.arm

    @require_pwntools
    def sh(self) -> bytes:
        """Generate /bin/sh shellcode."""
        sc = self._get_shellcraft()
        return _pwn.asm(sc.sh(), arch=self._arch)

    @require_pwntools
    def execve(self, path: str = "/bin/sh", argv: list = None, envp: list = None) -> bytes:
        """Generate execve shellcode."""
        sc = self._get_shellcraft()
        code = sc.execve(path, argv or [path], envp or 0)
        return _pwn.asm(code, arch=self._arch)

    @require_pwntools
    def read(self, fd: int, buf: int, count: int) -> bytes:
        """Generate read syscall shellcode."""
        sc = self._get_shellcraft()
        code = sc.read(fd, buf, count)
        return _pwn.asm(code, arch=self._arch)

    @require_pwntools
    def write(self, fd: int, buf: int, count: int) -> bytes:
        """Generate write syscall shellcode."""
        sc = self._get_shellcraft()
        code = sc.write(fd, buf, count)
        return _pwn.asm(code, arch=self._arch)

    @require_pwntools
    def mmap(self, addr: int, length: int, prot: int, flags: int) -> bytes:
        """Generate mmap syscall shellcode."""
        sc = self._get_shellcraft()
        code = sc.mmap(addr, length, prot, flags, -1, 0)
        return _pwn.asm(code, arch=self._arch)

    @require_pwntools
    def mprotect(self, addr: int, length: int, prot: int) -> bytes:
        """Generate mprotect syscall shellcode."""
        sc = self._get_shellcraft()
        code = sc.mprotect(addr, length, prot)
        return _pwn.asm(code, arch=self._arch)

    @require_pwntools
    def syscall(self, sysnum: int | str, *args) -> bytes:
        """Generate arbitrary syscall shellcode."""
        sc = self._get_shellcraft()
        code = sc.syscall(sysnum, *args)
        return _pwn.asm(code, arch=self._arch)

    @require_pwntools
    def nop(self) -> bytes:
        """Generate a NOP instruction."""
        return _pwn.asm(_pwn.shellcraft.nop(), arch=self._arch)

    @require_pwntools
    def nop_sled(self, count: int) -> bytes:
        """Generate a NOP sled."""
        nop = self.nop()
        return nop * count

    @require_pwntools
    def assemble(self, code: str) -> bytes:
        """Assemble arbitrary assembly code."""
        return _pwn.asm(code, arch=self._arch)

    @require_pwntools
    def disassemble(self, data: bytes, vma: int = 0) -> str:
        """Disassemble bytes."""
        return _pwn.disasm(data, arch=self._arch, vma=vma)


# ==================== Format String Helper ====================

class FormatStringHelper:
    """
    Format string exploitation helper.
    
    Provides utilities for format string vulnerability exploitation.
    
    Example:
        fs = pwn.format_string
        
        # Calculate offset
        offset = fs.find_offset()
        
        # Generate write payload
        payload = fs.write(target_addr, value, offset)
    """

    def __init__(self, context: PwnContext):
        self._context = context

    @require_pwntools
    def write(
        self,
        target: int,
        value: int,
        offset: int,
        write_size: str = "byte",
    ) -> bytes:
        """
        Generate format string write payload.
        
        Args:
            target: Address to write to
            value: Value to write
            offset: Stack offset to controlled data
            write_size: "byte", "short", or "int"
        """
        writes = {target: value}

        # Use pwntools fmtstr module
        return _pwn.fmtstr.fmtstr_payload(
            offset,
            writes,
            write_size=write_size,
        )

    @require_pwntools
    def write_multiple(
        self,
        writes: dict[int, int],
        offset: int,
        write_size: str = "byte",
    ) -> bytes:
        """
        Generate format string payload for multiple writes.
        
        Args:
            writes: Dict mapping addresses to values
            offset: Stack offset
            write_size: Write size
        """
        return _pwn.fmtstr.fmtstr_payload(
            offset,
            writes,
            write_size=write_size,
        )

    @staticmethod
    def leak_pattern(offset: int, count: int = 1) -> bytes:
        """
        Generate format string pattern to leak stack values.
        
        Args:
            offset: Starting stack offset
            count: Number of values to leak
        """
        parts = []
        for i in range(count):
            parts.append(f"%{offset + i}$p")
        return ".".join(parts).encode()

    @staticmethod
    def find_offset_pattern() -> bytes:
        """Generate pattern to find format string offset."""
        return b"AAAA" + b".%p" * 50


# ==================== Cyclic Pattern Helper ====================

class CyclicHelper:
    """
    Cyclic pattern helper for buffer overflow analysis.
    
    Example:
        cyc = pwn.cyclic_helper
        
        # Generate pattern
        pattern = cyc.pattern(200)
        
        # Find offset
        offset = cyc.find(b"aaab")
        offset = cyc.find(0x61616162)
    """

    def __init__(self, context: PwnContext):
        self._context = context

    @require_pwntools
    def pattern(self, length: int) -> bytes:
        """Generate a cyclic pattern of the given length."""
        return _pwn.cyclic(length)

    @require_pwntools
    def find(self, subpattern: bytes | int) -> int:
        """
        Find offset of subpattern in cyclic pattern.
        
        Args:
            subpattern: Bytes or integer to find
            
        Returns:
            Offset in the pattern, or -1 if not found
        """
        return _pwn.cyclic_find(subpattern)

    @require_pwntools
    def pattern_at(self, offset: int, length: int = 4) -> bytes:
        """Get the pattern bytes at a given offset."""
        full = _pwn.cyclic(offset + length)
        return full[offset:offset + length]


# ==================== Main PwnContext Class ====================

class PwnContext:
    """
    Main pwntools integration context for PyUniDbg.
    
    Provides access to exploit development utilities including:
    - ROP gadget finding
    - Shellcode generation
    - Format string exploitation
    - Cyclic pattern utilities
    - Binary manipulation
    
    Example:
        from pyunidbg.pwn import PwnContext
        
        pwn = PwnContext(emulator)
        
        # Find gadgets
        gadgets = pwn.find_gadgets("libnative.so", "pop")
        
        # Build ROP chain
        rop = pwn.rop("libnative.so")
        rop.call(gadgets[0].address, [0x1000])
        
        # Generate shellcode
        code = pwn.shellcraft.sh()
        
        # Use cyclic patterns
        pattern = pwn.cyclic(100)
        offset = pwn.cyclic_find(b"aaab")
    """

    def __init__(self, emulator: Emulator):
        self.emulator = emulator
        arch = emulator.arch
        self.is_64bit = getattr(arch, 'value', str(arch)) in ('arm64', 'aarch64', 'x86_64')

        # Set pwntools context if available
        self._setup_pwntools_context()

        # Sub-modules
        self.shellcraft = ShellcraftWrapper(self)
        self.format_string = FormatStringHelper(self)
        self.cyclic_helper = CyclicHelper(self)

        # Gadget cache
        self._gadget_cache: dict[str, list[Gadget]] = {}

    def _setup_pwntools_context(self) -> None:
        """Configure pwntools context for the emulator architecture."""
        if not _import_pwntools():
            return

        if self.is_64bit:
            _pwn.context.arch = 'aarch64'
            _pwn.context.bits = 64
        else:
            _pwn.context.arch = 'arm'
            _pwn.context.bits = 32

        _pwn.context.endian = 'little'
        _pwn.context.os = 'linux'

    # ==================== Gadget Finding ====================

    def find_gadgets(
        self,
        library: str | None = None,
        pattern: str = "",
        limit: int = 100,
    ) -> GadgetSearch:
        """
        Find ROP gadgets in loaded libraries.
        
        Args:
            library: Library to search (None for all)
            pattern: Pattern to filter gadgets (e.g., "pop", "ret")
            limit: Maximum number of gadgets to return
            
        Returns:
            GadgetSearch with found gadgets
        """
        gadgets = []

        # Get library memory ranges
        modules = self._get_modules(library)

        for module in modules:
            module_gadgets = self._find_gadgets_in_module(module, pattern, limit)
            gadgets.extend(module_gadgets)

            if len(gadgets) >= limit:
                break

        return GadgetSearch(
            query=pattern,
            gadgets=gadgets[:limit],
            library=library,
        )

    def _get_modules(self, library: str | None = None) -> list:
        """Get modules to search."""
        modules = []

        if hasattr(self.emulator, 'loader'):
            if library:
                mod = self.emulator.loader.get_module(library)
                if mod:
                    modules.append(mod)
            else:
                modules = self.emulator.loader.list_modules()

        return modules

    def _find_gadgets_in_module(
        self,
        module,
        pattern: str,
        limit: int,
    ) -> list[Gadget]:
        """Find gadgets in a single module."""
        gadgets = []

        # Check cache
        cache_key = f"{module.name}:{pattern}"
        if cache_key in self._gadget_cache:
            return self._gadget_cache[cache_key][:limit]

        # Read module memory
        try:
            data = self.emulator.memory.read(
                module.base_address,
                module.size
            )
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return []

        # Search for gadget patterns
        # ARM64 ret = 0xD65F03C0
        # ARM32 bx lr = 0xE12FFF1E, pop {pc} = varies

        if self.is_64bit:
            ret_bytes = b'\xc0\x03\x5f\xd6'
        else:
            ret_bytes = b'\x1e\xff\x2f\xe1'  # bx lr

        # Find all return instruction locations
        idx = 0
        while idx < len(data):
            pos = data.find(ret_bytes, idx)
            if pos == -1:
                break

            # Look back for gadget start (up to 20 instructions)
            max_back = min(pos, 80)  # 20 instructions * 4 bytes

            for back in range(4, max_back + 4, 4):
                gadget_start = pos - back + 4
                if gadget_start < 0:
                    continue

                gadget_addr = module.base_address + gadget_start
                gadget_bytes = data[gadget_start:pos + 4]

                # Disassemble
                insns = self._disassemble_gadget(gadget_bytes, gadget_addr)

                if insns and self._matches_pattern(insns, pattern):
                    gadget = Gadget(
                        address=gadget_addr,
                        insns=insns,
                        length=len(gadget_bytes),
                    )
                    gadgets.append(gadget)

                    if len(gadgets) >= limit * 2:  # Get more for caching
                        break

            idx = pos + 4

        # Cache results
        self._gadget_cache[cache_key] = gadgets

        return gadgets[:limit]

    def _disassemble_gadget(self, data: bytes, vma: int) -> list[str]:
        """Disassemble gadget bytes to instruction strings."""
        try:
            if hasattr(self.emulator, 'disassemble'):
                result = self.emulator.disassemble(vma, len(data))
                if result:
                    return [f"{m} {o}".strip() for _, m, o in result]
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Fallback: try using capstone directly
        try:
            from capstone import CS_ARCH_ARM, CS_ARCH_ARM64, CS_MODE_ARM, Cs

            if self.is_64bit:
                md = Cs(CS_ARCH_ARM64, 0)
            else:
                md = Cs(CS_ARCH_ARM, CS_MODE_ARM)

            insns = []
            for insn in md.disasm(data, vma):
                insns.append(f"{insn.mnemonic} {insn.op_str}".strip())

            return insns
        except ImportError:
            pass

        return []

    def _matches_pattern(self, insns: list[str], pattern: str) -> bool:
        """Check if instructions match the search pattern."""
        if not pattern:
            return True

        pattern_lower = pattern.lower()

        for insn in insns:
            if pattern_lower in insn.lower():
                return True

        return False

    # ==================== ROP Chain ====================

    def rop(self, library: str | None = None) -> ROPChain:
        """
        Create a ROP chain builder.
        
        Args:
            library: Library to source gadgets from
            
        Returns:
            ROPChain builder
        """
        return ROPChain(self, library)

    # ==================== Cyclic Patterns ====================

    @require_pwntools
    def cyclic(self, length: int) -> bytes:
        """Generate a cyclic pattern."""
        return _pwn.cyclic(length)

    @require_pwntools
    def cyclic_find(self, subpattern: bytes | int) -> int:
        """Find offset in cyclic pattern."""
        return _pwn.cyclic_find(subpattern)

    # ==================== Assembly/Disassembly ====================

    @require_pwntools
    def asm(self, code: str, vma: int = 0) -> bytes:
        """Assemble code string to bytes."""
        return _pwn.asm(code, vma=vma)

    @require_pwntools
    def disasm(self, data: bytes, vma: int = 0) -> str:
        """Disassemble bytes to string."""
        return _pwn.disasm(data, vma=vma)

    # ==================== Packing/Unpacking ====================

    def p64(self, value: int) -> bytes:
        """Pack 64-bit value."""
        return struct.pack("<Q", value)

    def p32(self, value: int) -> bytes:
        """Pack 32-bit value."""
        return struct.pack("<I", value)

    def p16(self, value: int) -> bytes:
        """Pack 16-bit value."""
        return struct.pack("<H", value)

    def p8(self, value: int) -> bytes:
        """Pack 8-bit value."""
        return struct.pack("<B", value)

    def u64(self, data: bytes) -> int:
        """Unpack 64-bit value."""
        return struct.unpack("<Q", data.ljust(8, b'\x00')[:8])[0]

    def u32(self, data: bytes) -> int:
        """Unpack 32-bit value."""
        return struct.unpack("<I", data.ljust(4, b'\x00')[:4])[0]

    def u16(self, data: bytes) -> int:
        """Unpack 16-bit value."""
        return struct.unpack("<H", data.ljust(2, b'\x00')[:2])[0]

    def u8(self, data: bytes) -> int:
        """Unpack 8-bit value."""
        return data[0] if data else 0

    def pack(self, value: int) -> bytes:
        """Pack value based on architecture pointer size."""
        if self.is_64bit:
            return self.p64(value)
        return self.p32(value)

    def unpack(self, data: bytes) -> int:
        """Unpack value based on architecture pointer size."""
        if self.is_64bit:
            return self.u64(data)
        return self.u32(data)

    # ==================== Memory Search ====================

    def search(
        self,
        pattern: bytes,
        library: str | None = None,
        limit: int = 100,
    ) -> list[int]:
        """
        Search for byte pattern in memory.
        
        Args:
            pattern: Bytes to search for
            library: Library to search (None for all)
            limit: Maximum results
            
        Returns:
            List of addresses where pattern was found
        """
        results = []
        modules = self._get_modules(library)

        for module in modules:
            try:
                data = self.emulator.memory.read(
                    module.base_address,
                    module.size
                )

                idx = 0
                while idx < len(data):
                    pos = data.find(pattern, idx)
                    if pos == -1:
                        break

                    results.append(module.base_address + pos)
                    idx = pos + 1

                    if len(results) >= limit:
                        return results

            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                continue

        return results

    def search_string(
        self,
        string: str,
        library: str | None = None,
        limit: int = 100,
    ) -> list[int]:
        """Search for string in memory."""
        return self.search(string.encode() + b'\x00', library, limit)

    # ==================== Exploit Templates ====================

    def ret2libc(
        self,
        system_addr: int,
        binsh_addr: int,
        exit_addr: int | None = None,
    ) -> bytes:
        """
        Generate ret2libc payload.
        
        Args:
            system_addr: Address of system()
            binsh_addr: Address of "/bin/sh" string
            exit_addr: Optional address of exit()
            
        Returns:
            Payload bytes
        """
        if self.is_64bit:
            # ARM64: Need to set X0 = binsh_addr, then call system
            rop = self.rop()
            # This is simplified - real ARM64 ret2libc is more complex
            payload = self.p64(binsh_addr)  # X0
            payload += self.p64(system_addr)
            if exit_addr:
                payload += self.p64(exit_addr)
            return payload
        else:
            # ARM32: Simpler
            payload = self.p32(system_addr)
            if exit_addr:
                payload += self.p32(exit_addr)
            else:
                payload += self.p32(0xdeadbeef)  # Dummy return
            payload += self.p32(binsh_addr)
            return payload

    # ==================== Utility ====================

    def flat(self, *args) -> bytes:
        """
        Flatten args into a byte string.
        
        Integers are packed according to architecture.
        Bytes are concatenated as-is.
        """
        result = b""
        for arg in args:
            if isinstance(arg, int):
                result += self.pack(arg)
            elif isinstance(arg, bytes):
                result += arg
            elif isinstance(arg, str):
                result += arg.encode()
            elif hasattr(arg, '__iter__'):
                result += self.flat(*arg)
        return result

    def __repr__(self) -> str:
        arch = "ARM64" if self.is_64bit else "ARM32"
        pwn_status = "available" if _import_pwntools() else "not installed"
        return f"PwnContext({arch}, pwntools={pwn_status})"


# ==================== Convenience Functions ====================

def create_pwn_context(emulator: Emulator) -> PwnContext:
    """Create a PwnContext for the given emulator."""
    return PwnContext(emulator)


def is_pwntools_available() -> bool:
    """Check if pwntools is installed."""
    return _import_pwntools()


# Re-export the advanced ROP finder
from .rop_finder import (
    ClassifiedGadget,
    GadgetClassifier,
    GadgetDatabase,
    GadgetTerminator,
    GadgetType,
    ROPFinder,
    create_rop_finder,
)
