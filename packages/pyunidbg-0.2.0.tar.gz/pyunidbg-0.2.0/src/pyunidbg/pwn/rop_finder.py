"""
Advanced ROP Gadget Finder and Automated Chain Generator.

Provides comprehensive ROP gadget discovery across ARM, ARM64,
x86 and x86_64, with semantic classification, quality scoring,
and automated chain building for common exploit primitives.

Features:
- Multi-architecture gadget search (ARM/ARM64/x86/x86_64)
- Semantic gadget classification (register control, memory r/w, syscall, etc.)
- Quality scoring based on side effects and chain-ability
- Automated ROP chain generation for mprotect/execve/write patterns
- Stack pivot detection
- JOP (Jump-Oriented Programming) gadget support
- Gadget deduplication and caching

Usage:
    from pyunidbg.pwn.rop_finder import ROPFinder

    finder = ROPFinder(emulator)
    finder.scan()

    # Find specific gadgets
    pop_x0 = finder.find("pop {x0}", arch="arm64")
    syscall = finder.find_syscall_gadgets()

    # Auto-build chain
    chain = finder.auto_chain_mprotect(addr=0x1000, size=0x1000, prot=7)
"""

from __future__ import annotations

import logging
import struct
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Gadget classification
# ---------------------------------------------------------------------------

class GadgetType(Enum):
    """Semantic classification of ROP gadgets."""
    POP_REG = auto()
    MOV_REG = auto()
    LOAD_MEM = auto()
    STORE_MEM = auto()
    ADD_REG = auto()
    SUB_REG = auto()
    XOR_REG = auto()
    AND_REG = auto()
    OR_REG = auto()
    SHIFT = auto()
    SYSCALL = auto()
    CALL_REG = auto()
    JMP_REG = auto()
    STACK_PIVOT = auto()
    NOP = auto()
    RET = auto()
    UNKNOWN = auto()


class GadgetTerminator(Enum):
    """How a gadget transfers control."""
    RET = auto()
    JMP_REG = auto()
    CALL_REG = auto()
    SYSCALL = auto()
    INT = auto()
    NONE = auto()


@dataclass
class ClassifiedGadget:
    """A ROP gadget with semantic classification and quality metrics."""
    address: int
    instructions: list[str]
    raw_bytes: bytes
    gadget_type: GadgetType = GadgetType.UNKNOWN
    terminator: GadgetTerminator = GadgetTerminator.RET
    controlled_regs: set[str] = field(default_factory=set)
    clobbered_regs: set[str] = field(default_factory=set)
    stack_adjustment: int = 0
    quality_score: float = 0.0
    module_name: str = ""
    module_offset: int = 0

    @property
    def mnemonic_chain(self) -> str:
        return " ; ".join(self.instructions)

    def __repr__(self) -> str:
        return (
            f"Gadget({self.address:#x}: {self.mnemonic_chain} "
            f"[{self.gadget_type.name}, Q={self.quality_score:.1f}])"
        )

    def __hash__(self):
        return hash((self.address, tuple(self.instructions)))


@dataclass
class GadgetDatabase:
    """Indexed collection of classified gadgets."""
    _all: list[ClassifiedGadget] = field(default_factory=list)
    _by_type: dict[GadgetType, list[ClassifiedGadget]] = field(
        default_factory=lambda: defaultdict(list))
    _by_reg: dict[str, list[ClassifiedGadget]] = field(
        default_factory=lambda: defaultdict(list))
    _by_addr: dict[int, ClassifiedGadget] = field(default_factory=dict)

    def add(self, gadget: ClassifiedGadget) -> None:
        if gadget.address in self._by_addr:
            return
        self._all.append(gadget)
        self._by_type[gadget.gadget_type].append(gadget)
        self._by_addr[gadget.address] = gadget
        for reg in gadget.controlled_regs:
            self._by_reg[reg].append(gadget)

    def find_by_type(self, gtype: GadgetType, limit: int = 50) -> list[ClassifiedGadget]:
        return sorted(
            self._by_type.get(gtype, []),
            key=lambda g: -g.quality_score,
        )[:limit]

    def find_controlling(self, reg: str, limit: int = 20) -> list[ClassifiedGadget]:
        return sorted(
            self._by_reg.get(reg.upper(), []),
            key=lambda g: -g.quality_score,
        )[:limit]

    def find_by_pattern(self, pattern: str, limit: int = 50) -> list[ClassifiedGadget]:
        pattern_lower = pattern.lower()
        matches = [g for g in self._all if pattern_lower in g.mnemonic_chain.lower()]
        return sorted(matches, key=lambda g: -g.quality_score)[:limit]

    @property
    def count(self) -> int:
        return len(self._all)

    def summary(self) -> dict[str, int]:
        return {gt.name: len(gs) for gt, gs in self._by_type.items() if gs}


# ---------------------------------------------------------------------------
# Architecture-specific gadget terminators
# ---------------------------------------------------------------------------

_ARM64_RET = b"\xc0\x03\x5f\xd6"
_ARM_BX_LR = b"\x1e\xff\x2f\xe1"
_ARM_POP_PC_MASK = 0x08BD8000
_X86_RET = b"\xc3"
_X86_RETF = b"\xcb"
_X86_RET_IMM = b"\xc2"

_ARM64_SVC = b"\x01\x00\x00\xd4"
_ARM_SVC = b"\x00\x00\x00\xef"
_X86_SYSCALL = b"\x0f\x05"
_X86_INT80 = b"\xcd\x80"
_X86_SYSENTER = b"\x0f\x34"


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------

class GadgetClassifier:
    """Classify gadgets based on instruction semantics."""

    _POP_REGS_RE = {"pop", "ldp", "ldr"}
    _STORE_RE = {"str", "stp", "strb", "strh", "mov"}
    _ARITH_MAP = {
        "add": GadgetType.ADD_REG, "adds": GadgetType.ADD_REG,
        "sub": GadgetType.SUB_REG, "subs": GadgetType.SUB_REG,
        "eor": GadgetType.XOR_REG, "xor": GadgetType.XOR_REG,
        "and": GadgetType.AND_REG, "ands": GadgetType.AND_REG,
        "orr": GadgetType.OR_REG, "or": GadgetType.OR_REG,
        "lsl": GadgetType.SHIFT, "lsr": GadgetType.SHIFT,
        "shl": GadgetType.SHIFT, "shr": GadgetType.SHIFT,
        "ror": GadgetType.SHIFT, "rol": GadgetType.SHIFT,
    }

    def classify(self, insns: list[str], is_64bit: bool) -> tuple[GadgetType, set[str], set[str], int]:
        """Return (type, controlled_regs, clobbered_regs, stack_adj)."""
        controlled: set[str] = set()
        clobbered: set[str] = set()
        stack_adj = 0
        gtype = GadgetType.UNKNOWN

        for raw_insn in insns:
            parts = raw_insn.lower().split(None, 1)
            mn = parts[0] if parts else ""
            operands = parts[1] if len(parts) > 1 else ""

            if mn in ("pop", "ldp") or (mn == "ldr" and "sp" in operands):
                regs = self._extract_regs(operands)
                controlled |= regs
                gtype = GadgetType.POP_REG
                per_reg = 8 if is_64bit else 4
                stack_adj += len(regs) * per_reg

            elif mn in ("mov", "movz", "movn"):
                regs = self._extract_regs(operands)
                dst_regs = list(regs)[:1]
                controlled |= set(dst_regs)
                gtype = GadgetType.MOV_REG

            elif mn in self._ARITH_MAP:
                gtype = self._ARITH_MAP[mn]
                regs = self._extract_regs(operands)
                if regs:
                    clobbered |= regs

            elif mn in ("str", "stp", "strb", "strh"):
                gtype = GadgetType.STORE_MEM
                clobbered |= self._extract_regs(operands)

            elif mn in ("ldr", "ldrb", "ldrh", "ldrsw"):
                gtype = GadgetType.LOAD_MEM
                regs = self._extract_regs(operands)
                controlled |= regs

            elif mn in ("svc", "syscall", "int"):
                gtype = GadgetType.SYSCALL

            elif mn in ("blr", "call"):
                gtype = GadgetType.CALL_REG

            elif mn in ("br", "jmp"):
                gtype = GadgetType.JMP_REG

            elif mn == "ret":
                if gtype == GadgetType.UNKNOWN:
                    gtype = GadgetType.RET

            elif mn == "nop":
                if gtype == GadgetType.UNKNOWN:
                    gtype = GadgetType.NOP

            if mn in ("add", "sub") and "sp" in operands.lower().split(",")[0]:
                imm = self._parse_last_imm(operands)
                if mn == "sub":
                    imm = -imm
                stack_adj += imm
                gtype = GadgetType.STACK_PIVOT

        return gtype, controlled, clobbered, stack_adj

    def score(self, gadget: ClassifiedGadget) -> float:
        score = 10.0
        score += len(gadget.controlled_regs) * 5.0
        score -= len(gadget.clobbered_regs) * 2.0
        score -= (len(gadget.instructions) - 1) * 1.0
        if gadget.terminator == GadgetTerminator.RET:
            score += 3.0
        if gadget.gadget_type == GadgetType.SYSCALL:
            score += 10.0
        if gadget.gadget_type == GadgetType.STACK_PIVOT:
            score += 8.0
        return max(0.0, score)

    @staticmethod
    def _extract_regs(operands: str) -> set[str]:
        import re
        regs: set[str] = set()
        tokens = re.findall(r'\b([xwrse][0-9]+|sp|lr|pc|fp|rax|rbx|rcx|rdx|rsi|rdi|rbp|rsp|r\d+|eax|ebx|ecx|edx|esi|edi|ebp|esp)\b', operands.lower())
        for t in tokens:
            regs.add(t.upper())
        return regs

    @staticmethod
    def _parse_last_imm(operands: str) -> int:
        import re
        matches = re.findall(r'#?(0x[0-9a-fA-F]+|\d+)', operands)
        if matches:
            try:
                return int(matches[-1], 0)
            except ValueError:
                pass
        return 0


# ---------------------------------------------------------------------------
# Main finder
# ---------------------------------------------------------------------------

class ROPFinder:
    """
    Automated ROP gadget finder with classification and chain generation.
    """

    def __init__(self, emulator: Emulator, max_gadget_insns: int = 6):
        self.emulator = emulator
        self.max_gadget_insns = max_gadget_insns
        self.db = GadgetDatabase()
        self._classifier = GadgetClassifier()
        self._is_64bit = emulator.is_64bit

    def scan(
        self,
        regions: list[tuple[int, int]] | None = None,
        module_name: str | None = None,
    ) -> GadgetDatabase:
        """
        Scan memory for ROP gadgets.

        Args:
            regions: List of (base, size) tuples to scan. If None, scans
                     all mapped executable regions.
            module_name: If given, only scan the named module.

        Returns:
            GadgetDatabase with all found gadgets.
        """
        if regions is None:
            regions = self._get_exec_regions(module_name)

        for base, size in regions:
            try:
                data = self.emulator.memory.read(base, size)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                continue
            self._scan_region(data, base, module_name or "")

        logger.info("Found %d gadgets (%s)", self.db.count, self.db.summary())
        return self.db

    def find(self, pattern: str, limit: int = 50) -> list[ClassifiedGadget]:
        return self.db.find_by_pattern(pattern, limit)

    def find_pop(self, *regs: str) -> list[ClassifiedGadget]:
        """Find gadgets that pop specified registers."""
        candidates = self.db.find_by_type(GadgetType.POP_REG, limit=500)
        wanted = {r.upper() for r in regs}
        return [g for g in candidates if wanted <= g.controlled_regs]

    def find_syscall_gadgets(self) -> list[ClassifiedGadget]:
        return self.db.find_by_type(GadgetType.SYSCALL)

    def find_stack_pivots(self) -> list[ClassifiedGadget]:
        return self.db.find_by_type(GadgetType.STACK_PIVOT)

    def find_write_gadgets(self) -> list[ClassifiedGadget]:
        return self.db.find_by_type(GadgetType.STORE_MEM)

    def find_jop_gadgets(self) -> list[ClassifiedGadget]:
        """Find jump-oriented programming gadgets (blr/jmp reg)."""
        jmp = self.db.find_by_type(GadgetType.JMP_REG)
        call = self.db.find_by_type(GadgetType.CALL_REG)
        return jmp + call

    # ------------------------------------------------------------------
    # Automated chain builders
    # ------------------------------------------------------------------

    def auto_chain_mprotect(
        self,
        addr: int,
        size: int,
        prot: int = 7,
        syscall_num: int | None = None,
    ) -> bytes:
        """
        Build a ROP chain that calls mprotect(addr, size, prot).

        For ARM64: X0=addr, X1=size, X2=prot, X8=0xe2 (226), SVC #0
        For ARM32: R0=addr, R1=size, R2=prot, R7=0x7d (125), SVC #0
        For x86_64: RAX=10, RDI=addr, RSI=size, RDX=prot, syscall
        For x86:    EAX=125, EBX=addr, ECX=size, EDX=prot, int 0x80
        """
        from ..core.constants import Architecture
        arch = self.emulator.config.arch

        if arch == Architecture.ARM64:
            if syscall_num is None:
                syscall_num = 226
            return self._chain_arm64_syscall(
                syscall_num, [addr, size, prot])
        elif arch == Architecture.ARM:
            if syscall_num is None:
                syscall_num = 125
            return self._chain_arm_syscall(
                syscall_num, [addr, size, prot])
        elif arch == Architecture.X86_64:
            if syscall_num is None:
                syscall_num = 10
            return self._chain_x64_syscall(
                syscall_num, [addr, size, prot])
        elif arch == Architecture.X86:
            if syscall_num is None:
                syscall_num = 125
            return self._chain_x86_syscall(
                syscall_num, [addr, size, prot])
        return b""

    def auto_chain_execve(
        self,
        binsh_addr: int,
        argv_addr: int = 0,
        envp_addr: int = 0,
    ) -> bytes:
        """Build a chain that calls execve("/bin/sh", argv, envp)."""
        from ..core.constants import Architecture
        arch = self.emulator.config.arch

        if arch == Architecture.ARM64:
            return self._chain_arm64_syscall(221, [binsh_addr, argv_addr, envp_addr])
        elif arch == Architecture.ARM:
            return self._chain_arm_syscall(11, [binsh_addr, argv_addr, envp_addr])
        elif arch == Architecture.X86_64:
            return self._chain_x64_syscall(59, [binsh_addr, argv_addr, envp_addr])
        elif arch == Architecture.X86:
            return self._chain_x86_syscall(11, [binsh_addr, argv_addr, envp_addr])
        return b""

    # ------------------------------------------------------------------
    # Internal scanning
    # ------------------------------------------------------------------

    def _scan_region(self, data: bytes, base: int, module: str) -> None:
        from ..core.constants import Architecture
        arch = self.emulator.config.arch

        if arch in (Architecture.ARM64,):
            self._scan_arm64(data, base, module)
        elif arch == Architecture.ARM:
            self._scan_arm32(data, base, module)
        elif arch in (Architecture.X86, Architecture.X86_64):
            self._scan_x86(data, base, module)

    def _scan_arm64(self, data: bytes, base: int, module: str) -> None:
        terminators = [
            (_ARM64_RET, GadgetTerminator.RET),
            (_ARM64_SVC, GadgetTerminator.SYSCALL),
        ]
        for term_bytes, term_type in terminators:
            idx = 0
            while idx < len(data):
                pos = data.find(term_bytes, idx)
                if pos == -1:
                    break
                if pos % 4 != 0:
                    idx = pos + 1
                    continue
                self._extract_gadgets_fixed_width(
                    data, base, pos, 4, term_type, module)
                idx = pos + 4

    def _scan_arm32(self, data: bytes, base: int, module: str) -> None:
        terminators = [
            (_ARM_BX_LR, GadgetTerminator.RET),
            (_ARM_SVC, GadgetTerminator.SYSCALL),
        ]
        for term_bytes, term_type in terminators:
            idx = 0
            while idx < len(data):
                pos = data.find(term_bytes, idx)
                if pos == -1:
                    break
                if pos % 4 != 0:
                    idx = pos + 1
                    continue
                self._extract_gadgets_fixed_width(
                    data, base, pos, 4, term_type, module)
                idx = pos + 4

    def _scan_x86(self, data: bytes, base: int, module: str) -> None:
        terminators = [
            (_X86_RET, GadgetTerminator.RET),
            (_X86_SYSCALL, GadgetTerminator.SYSCALL),
            (_X86_INT80, GadgetTerminator.INT),
            (_X86_SYSENTER, GadgetTerminator.SYSCALL),
        ]
        for term_bytes, term_type in terminators:
            idx = 0
            while idx < len(data):
                pos = data.find(term_bytes, idx)
                if pos == -1:
                    break
                self._extract_gadgets_variable_width(
                    data, base, pos, len(term_bytes), term_type, module)
                idx = pos + 1

    def _extract_gadgets_fixed_width(
        self, data: bytes, base: int, term_pos: int,
        insn_size: int, term_type: GadgetTerminator, module: str,
    ) -> None:
        max_back = self.max_gadget_insns * insn_size
        for back in range(0, min(term_pos, max_back) + insn_size, insn_size):
            start = term_pos - back
            end = term_pos + insn_size
            chunk = data[start:end]
            addr = base + start

            insns = self._disasm(chunk, addr)
            if not insns or len(insns) > self.max_gadget_insns:
                continue
            if len(insns) * insn_size != len(chunk):
                continue

            gtype, ctrl, clob, sadj = self._classifier.classify(insns, self._is_64bit)
            gadget = ClassifiedGadget(
                address=addr, instructions=insns, raw_bytes=chunk,
                gadget_type=gtype, terminator=term_type,
                controlled_regs=ctrl, clobbered_regs=clob,
                stack_adjustment=sadj, module_name=module,
                module_offset=addr - base,
            )
            gadget.quality_score = self._classifier.score(gadget)
            self.db.add(gadget)

    def _extract_gadgets_variable_width(
        self, data: bytes, base: int, term_pos: int,
        term_len: int, term_type: GadgetTerminator, module: str,
    ) -> None:
        max_back = self.max_gadget_insns * 15
        for back in range(0, min(term_pos, max_back) + 1):
            start = term_pos - back
            end = term_pos + term_len
            chunk = data[start:end]
            addr = base + start

            insns = self._disasm(chunk, addr)
            if not insns or len(insns) > self.max_gadget_insns:
                continue
            total_bytes = sum(
                len(list(self.emulator._cs.disasm(
                    chunk[i:], addr + i)).__iter__().__next__().bytes)
                if i == 0 else 0
                for i in range(0)
            )
            gtype, ctrl, clob, sadj = self._classifier.classify(insns, self._is_64bit)
            gadget = ClassifiedGadget(
                address=addr, instructions=insns, raw_bytes=chunk,
                gadget_type=gtype, terminator=term_type,
                controlled_regs=ctrl, clobbered_regs=clob,
                stack_adjustment=sadj, module_name=module,
                module_offset=addr - base,
            )
            gadget.quality_score = self._classifier.score(gadget)
            self.db.add(gadget)

    def _disasm(self, data: bytes, addr: int) -> list[str]:
        try:
            insns = []
            for insn in self.emulator._cs.disasm(data, addr):
                insns.append(f"{insn.mnemonic} {insn.op_str}".strip())
            return insns
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return []

    def _get_exec_regions(self, module: str | None) -> list[tuple[int, int]]:
        regions = []
        for r in self.emulator.memory.get_regions():
            if r.protection & 4:
                if module and hasattr(r, "name") and module not in (r.name or ""):
                    continue
                regions.append((r.start, r.size))
        return regions

    # ------------------------------------------------------------------
    # Chain builders (architecture-specific)
    # ------------------------------------------------------------------

    def _chain_arm64_syscall(self, sysnum: int, args: list[int]) -> bytes:
        chain = bytearray()
        reg_names = ["X0", "X1", "X2", "X3", "X4", "X5"]
        for i, arg in enumerate(args[:6]):
            gadgets = self.find_pop(reg_names[i])
            if gadgets:
                chain += struct.pack("<Q", gadgets[0].address)
                chain += struct.pack("<Q", arg)
                pad = gadgets[0].stack_adjustment - 8
                chain += b"\x00" * max(0, pad)

        x8_gadgets = self.find_pop("X8")
        if x8_gadgets:
            chain += struct.pack("<Q", x8_gadgets[0].address)
            chain += struct.pack("<Q", sysnum)
            pad = x8_gadgets[0].stack_adjustment - 8
            chain += b"\x00" * max(0, pad)

        svc = self.find_syscall_gadgets()
        if svc:
            chain += struct.pack("<Q", svc[0].address)

        return bytes(chain)

    def _chain_arm_syscall(self, sysnum: int, args: list[int]) -> bytes:
        chain = bytearray()
        reg_names = ["R0", "R1", "R2", "R3"]
        for i, arg in enumerate(args[:4]):
            gadgets = self.find_pop(reg_names[i])
            if gadgets:
                chain += struct.pack("<I", gadgets[0].address)
                chain += struct.pack("<I", arg)
                pad = gadgets[0].stack_adjustment - 4
                chain += b"\x00" * max(0, pad)

        r7_gadgets = self.find_pop("R7")
        if r7_gadgets:
            chain += struct.pack("<I", r7_gadgets[0].address)
            chain += struct.pack("<I", sysnum)

        svc = self.find_syscall_gadgets()
        if svc:
            chain += struct.pack("<I", svc[0].address)

        return bytes(chain)

    def _chain_x64_syscall(self, sysnum: int, args: list[int]) -> bytes:
        chain = bytearray()
        reg_names = ["RDI", "RSI", "RDX", "R10", "R8", "R9"]
        for i, arg in enumerate(args[:6]):
            gadgets = self.find_pop(reg_names[i])
            if gadgets:
                chain += struct.pack("<Q", gadgets[0].address)
                chain += struct.pack("<Q", arg)

        rax_gadgets = self.find_pop("RAX")
        if rax_gadgets:
            chain += struct.pack("<Q", rax_gadgets[0].address)
            chain += struct.pack("<Q", sysnum)

        syscall = self.find_syscall_gadgets()
        if syscall:
            chain += struct.pack("<Q", syscall[0].address)

        return bytes(chain)

    def _chain_x86_syscall(self, sysnum: int, args: list[int]) -> bytes:
        chain = bytearray()
        reg_names = ["EBX", "ECX", "EDX", "ESI", "EDI"]
        for i, arg in enumerate(args[:5]):
            gadgets = self.find_pop(reg_names[i])
            if gadgets:
                chain += struct.pack("<I", gadgets[0].address)
                chain += struct.pack("<I", arg)

        eax_gadgets = self.find_pop("EAX")
        if eax_gadgets:
            chain += struct.pack("<I", eax_gadgets[0].address)
            chain += struct.pack("<I", sysnum)

        int80 = self.find_syscall_gadgets()
        if int80:
            chain += struct.pack("<I", int80[0].address)

        return bytes(chain)


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def create_rop_finder(emulator: Emulator, **kwargs) -> ROPFinder:
    return ROPFinder(emulator, **kwargs)


__all__ = [
    "ROPFinder",
    "ClassifiedGadget",
    "GadgetDatabase",
    "GadgetType",
    "GadgetTerminator",
    "GadgetClassifier",
    "create_rop_finder",
]
