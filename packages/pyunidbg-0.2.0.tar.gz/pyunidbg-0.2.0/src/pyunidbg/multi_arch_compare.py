"""
Multi-Architecture Comparison module for PyUniDbg.

This module provides functionality to compare code and execution
across different architectures:
- Binary comparison (same program, different architectures)
- Execution comparison (same inputs, different architectures)
- Semantic comparison (functionally equivalent code)
- ABI comparison (calling conventions, data layouts)

Features:
- Instruction mapping
- Register equivalence
- Memory layout comparison
- Cross-architecture analysis
"""

import struct
from collections import defaultdict
from dataclasses import dataclass, field
from enum import IntEnum, auto
from typing import Any


class Architecture(IntEnum):
    """Supported architectures."""
    X86 = auto()
    X86_64 = auto()
    ARM = auto()
    ARM64 = auto()
    MIPS = auto()
    MIPS64 = auto()
    RISCV32 = auto()
    RISCV64 = auto()
    POWERPC = auto()
    POWERPC64 = auto()
    SPARC = auto()
    SPARC64 = auto()


class Endianness(IntEnum):
    """Byte ordering."""
    LITTLE = auto()
    BIG = auto()


class ComparisonType(IntEnum):
    """Types of comparisons."""
    EXACT = auto()
    SEMANTIC = auto()
    BEHAVIORAL = auto()
    STRUCTURAL = auto()


class MatchConfidence(IntEnum):
    """Confidence levels for matches."""
    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    EXACT = 4


class DifferenceType(IntEnum):
    """Types of differences between architectures."""
    INSTRUCTION = auto()
    REGISTER = auto()
    MEMORY = auto()
    LAYOUT = auto()
    CALLING_CONVENTION = auto()
    DATA_SIZE = auto()
    ENDIANNESS = auto()
    ALIGNMENT = auto()


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class ArchInfo:
    """Architecture information."""
    arch: Architecture
    endianness: Endianness
    pointer_size: int
    min_instruction_size: int
    max_instruction_size: int
    register_count: int
    general_purpose_regs: list[str] = field(default_factory=list)

    @property
    def is_64bit(self) -> bool:
        """Check if 64-bit architecture."""
        return self.pointer_size == 8

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'arch': self.arch.name,
            'endianness': self.endianness.name,
            'pointer_size': self.pointer_size,
            'min_instruction_size': self.min_instruction_size,
            'max_instruction_size': self.max_instruction_size,
            'register_count': self.register_count,
            'general_purpose_regs': self.general_purpose_regs.copy(),
        }


@dataclass
class RegisterMapping:
    """Mapping between registers of different architectures."""
    source_arch: Architecture
    target_arch: Architecture
    mappings: dict[str, str] = field(default_factory=dict)

    def get_equivalent(self, source_reg: str) -> str | None:
        """Get equivalent register in target architecture."""
        return self.mappings.get(source_reg.lower())

    def add_mapping(self, source_reg: str, target_reg: str) -> None:
        """Add a register mapping."""
        self.mappings[source_reg.lower()] = target_reg.lower()


@dataclass
class InstructionMapping:
    """Mapping between instructions of different architectures."""
    source_arch: Architecture
    target_arch: Architecture
    source_mnemonic: str
    target_mnemonic: str
    confidence: MatchConfidence
    notes: str = ""

    def __str__(self) -> str:
        return f"{self.source_mnemonic}@{self.source_arch.name} <-> {self.target_mnemonic}@{self.target_arch.name} ({self.confidence.name})"


@dataclass
class MemoryLayoutDifference:
    """Difference in memory layout between architectures."""
    name: str
    source_size: int
    source_alignment: int
    target_size: int
    target_alignment: int
    description: str = ""

    @property
    def size_diff(self) -> int:
        """Get size difference."""
        return self.target_size - self.source_size

    @property
    def alignment_diff(self) -> int:
        """Get alignment difference."""
        return self.target_alignment - self.source_alignment


@dataclass
class FunctionSignature:
    """Function signature for comparison."""
    name: str
    address: int
    arch: Architecture
    num_args: int
    return_size: int
    calling_convention: str
    stack_usage: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'address': hex(self.address),
            'arch': self.arch.name,
            'num_args': self.num_args,
            'return_size': self.return_size,
            'calling_convention': self.calling_convention,
            'stack_usage': self.stack_usage,
        }


@dataclass
class FunctionMatch:
    """Match between functions in different architectures."""
    source: FunctionSignature
    target: FunctionSignature
    confidence: MatchConfidence
    similarity: float  # 0.0 to 1.0
    differences: list[DifferenceType] = field(default_factory=list)
    notes: str = ""

    def __str__(self) -> str:
        return f"{self.source.name} <-> {self.target.name} ({self.confidence.name}, {self.similarity:.1%})"


@dataclass
class ExecutionTrace:
    """Execution trace for comparison."""
    arch: Architecture
    entries: list[dict[str, Any]] = field(default_factory=list)

    def add_entry(self, address: int, instruction: str,
                  registers: dict[str, int], memory_ops: list[dict]) -> None:
        """Add a trace entry."""
        self.entries.append({
            'address': address,
            'instruction': instruction,
            'registers': registers.copy(),
            'memory_ops': memory_ops,
        })

    @property
    def instruction_count(self) -> int:
        """Get instruction count."""
        return len(self.entries)

    def get_instructions(self) -> list[str]:
        """Get all instructions."""
        return [e['instruction'] for e in self.entries]


@dataclass
class TraceComparison:
    """Result of comparing execution traces."""
    source_trace: ExecutionTrace
    target_trace: ExecutionTrace
    matched_entries: int
    unmatched_entries: int
    divergence_points: list[int]
    similarity: float

    @property
    def is_equivalent(self) -> bool:
        """Check if traces are semantically equivalent."""
        return self.similarity >= 0.95


@dataclass
class ArchComparisonResult:
    """Result of architecture comparison."""
    source_arch: Architecture
    target_arch: Architecture
    comparison_type: ComparisonType
    function_matches: list[FunctionMatch] = field(default_factory=list)
    instruction_mappings: list[InstructionMapping] = field(default_factory=list)
    layout_differences: list[MemoryLayoutDifference] = field(default_factory=list)
    overall_similarity: float = 0.0
    summary: str = ""

    def __str__(self) -> str:
        return f"{self.source_arch.name} vs {self.target_arch.name}: {self.overall_similarity:.1%} similar"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'source_arch': self.source_arch.name,
            'target_arch': self.target_arch.name,
            'comparison_type': self.comparison_type.name,
            'function_matches': len(self.function_matches),
            'instruction_mappings': len(self.instruction_mappings),
            'layout_differences': len(self.layout_differences),
            'overall_similarity': self.overall_similarity,
            'summary': self.summary,
        }


# =============================================================================
# Architecture Information
# =============================================================================

ARCH_INFO: dict[Architecture, ArchInfo] = {
    Architecture.X86: ArchInfo(
        arch=Architecture.X86,
        endianness=Endianness.LITTLE,
        pointer_size=4,
        min_instruction_size=1,
        max_instruction_size=15,
        register_count=8,
        general_purpose_regs=['eax', 'ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp', 'esp'],
    ),
    Architecture.X86_64: ArchInfo(
        arch=Architecture.X86_64,
        endianness=Endianness.LITTLE,
        pointer_size=8,
        min_instruction_size=1,
        max_instruction_size=15,
        register_count=16,
        general_purpose_regs=['rax', 'rbx', 'rcx', 'rdx', 'rsi', 'rdi', 'rbp', 'rsp',
                              'r8', 'r9', 'r10', 'r11', 'r12', 'r13', 'r14', 'r15'],
    ),
    Architecture.ARM: ArchInfo(
        arch=Architecture.ARM,
        endianness=Endianness.LITTLE,
        pointer_size=4,
        min_instruction_size=2,
        max_instruction_size=4,
        register_count=16,
        general_purpose_regs=['r0', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7',
                              'r8', 'r9', 'r10', 'r11', 'r12', 'sp', 'lr', 'pc'],
    ),
    Architecture.ARM64: ArchInfo(
        arch=Architecture.ARM64,
        endianness=Endianness.LITTLE,
        pointer_size=8,
        min_instruction_size=4,
        max_instruction_size=4,
        register_count=31,
        general_purpose_regs=['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7',
                              'x8', 'x9', 'x10', 'x11', 'x12', 'x13', 'x14', 'x15',
                              'x16', 'x17', 'x18', 'x19', 'x20', 'x21', 'x22', 'x23',
                              'x24', 'x25', 'x26', 'x27', 'x28', 'x29', 'x30', 'sp'],
    ),
    Architecture.MIPS: ArchInfo(
        arch=Architecture.MIPS,
        endianness=Endianness.BIG,
        pointer_size=4,
        min_instruction_size=4,
        max_instruction_size=4,
        register_count=32,
        general_purpose_regs=['$zero', '$at', '$v0', '$v1', '$a0', '$a1', '$a2', '$a3',
                              '$t0', '$t1', '$t2', '$t3', '$t4', '$t5', '$t6', '$t7',
                              '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7',
                              '$t8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra'],
    ),
    Architecture.MIPS64: ArchInfo(
        arch=Architecture.MIPS64,
        endianness=Endianness.BIG,
        pointer_size=8,
        min_instruction_size=4,
        max_instruction_size=4,
        register_count=32,
        general_purpose_regs=['$zero', '$at', '$v0', '$v1', '$a0', '$a1', '$a2', '$a3',
                              '$t0', '$t1', '$t2', '$t3', '$t4', '$t5', '$t6', '$t7',
                              '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7',
                              '$t8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra'],
    ),
    Architecture.RISCV32: ArchInfo(
        arch=Architecture.RISCV32,
        endianness=Endianness.LITTLE,
        pointer_size=4,
        min_instruction_size=2,
        max_instruction_size=4,
        register_count=32,
        general_purpose_regs=['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7',
                              'x8', 'x9', 'x10', 'x11', 'x12', 'x13', 'x14', 'x15',
                              'x16', 'x17', 'x18', 'x19', 'x20', 'x21', 'x22', 'x23',
                              'x24', 'x25', 'x26', 'x27', 'x28', 'x29', 'x30', 'x31'],
    ),
    Architecture.RISCV64: ArchInfo(
        arch=Architecture.RISCV64,
        endianness=Endianness.LITTLE,
        pointer_size=8,
        min_instruction_size=2,
        max_instruction_size=4,
        register_count=32,
        general_purpose_regs=['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7',
                              'x8', 'x9', 'x10', 'x11', 'x12', 'x13', 'x14', 'x15',
                              'x16', 'x17', 'x18', 'x19', 'x20', 'x21', 'x22', 'x23',
                              'x24', 'x25', 'x26', 'x27', 'x28', 'x29', 'x30', 'x31'],
    ),
    Architecture.POWERPC: ArchInfo(
        arch=Architecture.POWERPC,
        endianness=Endianness.BIG,
        pointer_size=4,
        min_instruction_size=4,
        max_instruction_size=4,
        register_count=32,
        general_purpose_regs=[f'r{i}' for i in range(32)],
    ),
    Architecture.POWERPC64: ArchInfo(
        arch=Architecture.POWERPC64,
        endianness=Endianness.BIG,
        pointer_size=8,
        min_instruction_size=4,
        max_instruction_size=4,
        register_count=32,
        general_purpose_regs=[f'r{i}' for i in range(32)],
    ),
}


# =============================================================================
# Register Mappings
# =============================================================================

class RegisterEquivalenceTable:
    """Table of register equivalences between architectures."""

    def __init__(self):
        self._mappings: dict[tuple[Architecture, Architecture], RegisterMapping] = {}
        self._setup_default_mappings()

    def _setup_default_mappings(self) -> None:
        """Set up default register mappings."""
        # x86 to x86_64
        x86_to_x64 = RegisterMapping(Architecture.X86, Architecture.X86_64)
        x86_to_x64.add_mapping('eax', 'rax')
        x86_to_x64.add_mapping('ebx', 'rbx')
        x86_to_x64.add_mapping('ecx', 'rcx')
        x86_to_x64.add_mapping('edx', 'rdx')
        x86_to_x64.add_mapping('esi', 'rsi')
        x86_to_x64.add_mapping('edi', 'rdi')
        x86_to_x64.add_mapping('ebp', 'rbp')
        x86_to_x64.add_mapping('esp', 'rsp')
        self._mappings[(Architecture.X86, Architecture.X86_64)] = x86_to_x64

        # ARM to ARM64
        arm_to_arm64 = RegisterMapping(Architecture.ARM, Architecture.ARM64)
        for i in range(13):
            arm_to_arm64.add_mapping(f'r{i}', f'w{i}')  # w registers are 32-bit views
        arm_to_arm64.add_mapping('sp', 'sp')
        arm_to_arm64.add_mapping('lr', 'x30')
        self._mappings[(Architecture.ARM, Architecture.ARM64)] = arm_to_arm64

        # Cross-arch argument registers
        x86_64_to_arm64 = RegisterMapping(Architecture.X86_64, Architecture.ARM64)
        # System V AMD64 ABI vs AAPCS64
        x86_64_to_arm64.add_mapping('rdi', 'x0')  # 1st arg
        x86_64_to_arm64.add_mapping('rsi', 'x1')  # 2nd arg
        x86_64_to_arm64.add_mapping('rdx', 'x2')  # 3rd arg
        x86_64_to_arm64.add_mapping('rcx', 'x3')  # 4th arg
        x86_64_to_arm64.add_mapping('r8', 'x4')   # 5th arg
        x86_64_to_arm64.add_mapping('r9', 'x5')   # 6th arg
        x86_64_to_arm64.add_mapping('rax', 'x0')  # return value
        x86_64_to_arm64.add_mapping('rsp', 'sp')
        self._mappings[(Architecture.X86_64, Architecture.ARM64)] = x86_64_to_arm64

    def get_mapping(self, source: Architecture,
                    target: Architecture) -> RegisterMapping | None:
        """Get register mapping between architectures."""
        return self._mappings.get((source, target))

    def add_mapping(self, mapping: RegisterMapping) -> None:
        """Add a register mapping."""
        key = (mapping.source_arch, mapping.target_arch)
        self._mappings[key] = mapping

    def get_equivalent(self, source_arch: Architecture, target_arch: Architecture,
                       source_reg: str) -> str | None:
        """Get equivalent register."""
        mapping = self.get_mapping(source_arch, target_arch)
        if mapping:
            return mapping.get_equivalent(source_reg)
        return None


# =============================================================================
# Instruction Mapping
# =============================================================================

class InstructionEquivalenceTable:
    """Table of instruction equivalences between architectures."""

    def __init__(self):
        self._mappings: dict[tuple[Architecture, Architecture, str], list[InstructionMapping]] = {}
        self._setup_default_mappings()

    def _setup_default_mappings(self) -> None:
        """Set up default instruction mappings."""
        # x86/x64 to ARM64 mappings
        self._add_simple_mapping(
            Architecture.X86_64, Architecture.ARM64,
            [
                ('mov', 'mov', MatchConfidence.HIGH),
                ('add', 'add', MatchConfidence.HIGH),
                ('sub', 'sub', MatchConfidence.HIGH),
                ('mul', 'mul', MatchConfidence.MEDIUM),
                ('imul', 'mul', MatchConfidence.MEDIUM),
                ('div', 'udiv', MatchConfidence.MEDIUM),
                ('idiv', 'sdiv', MatchConfidence.MEDIUM),
                ('and', 'and', MatchConfidence.HIGH),
                ('or', 'orr', MatchConfidence.HIGH),
                ('xor', 'eor', MatchConfidence.HIGH),
                ('shl', 'lsl', MatchConfidence.HIGH),
                ('shr', 'lsr', MatchConfidence.HIGH),
                ('sar', 'asr', MatchConfidence.HIGH),
                ('cmp', 'cmp', MatchConfidence.HIGH),
                ('test', 'tst', MatchConfidence.HIGH),
                ('jmp', 'b', MatchConfidence.HIGH),
                ('je', 'beq', MatchConfidence.HIGH),
                ('jne', 'bne', MatchConfidence.HIGH),
                ('jl', 'blt', MatchConfidence.HIGH),
                ('jg', 'bgt', MatchConfidence.HIGH),
                ('jle', 'ble', MatchConfidence.HIGH),
                ('jge', 'bge', MatchConfidence.HIGH),
                ('call', 'bl', MatchConfidence.HIGH),
                ('ret', 'ret', MatchConfidence.HIGH),
                ('push', 'str', MatchConfidence.MEDIUM),
                ('pop', 'ldr', MatchConfidence.MEDIUM),
                ('nop', 'nop', MatchConfidence.EXACT),
            ]
        )

        # x86/x64 to MIPS mappings
        self._add_simple_mapping(
            Architecture.X86_64, Architecture.MIPS,
            [
                ('mov', 'move', MatchConfidence.HIGH),
                ('add', 'add', MatchConfidence.HIGH),
                ('sub', 'sub', MatchConfidence.HIGH),
                ('and', 'and', MatchConfidence.HIGH),
                ('or', 'or', MatchConfidence.HIGH),
                ('xor', 'xor', MatchConfidence.HIGH),
                ('shl', 'sll', MatchConfidence.HIGH),
                ('shr', 'srl', MatchConfidence.HIGH),
                ('sar', 'sra', MatchConfidence.HIGH),
                ('jmp', 'j', MatchConfidence.HIGH),
                ('je', 'beq', MatchConfidence.MEDIUM),
                ('jne', 'bne', MatchConfidence.MEDIUM),
                ('call', 'jal', MatchConfidence.HIGH),
                ('ret', 'jr', MatchConfidence.HIGH),
                ('nop', 'nop', MatchConfidence.EXACT),
            ]
        )

        # x86/x64 to RISC-V mappings
        self._add_simple_mapping(
            Architecture.X86_64, Architecture.RISCV64,
            [
                ('mov', 'mv', MatchConfidence.HIGH),
                ('add', 'add', MatchConfidence.HIGH),
                ('sub', 'sub', MatchConfidence.HIGH),
                ('mul', 'mul', MatchConfidence.HIGH),
                ('div', 'divu', MatchConfidence.MEDIUM),
                ('idiv', 'div', MatchConfidence.MEDIUM),
                ('and', 'and', MatchConfidence.HIGH),
                ('or', 'or', MatchConfidence.HIGH),
                ('xor', 'xor', MatchConfidence.HIGH),
                ('shl', 'sll', MatchConfidence.HIGH),
                ('shr', 'srl', MatchConfidence.HIGH),
                ('sar', 'sra', MatchConfidence.HIGH),
                ('jmp', 'j', MatchConfidence.HIGH),
                ('je', 'beq', MatchConfidence.MEDIUM),
                ('jne', 'bne', MatchConfidence.MEDIUM),
                ('jl', 'blt', MatchConfidence.MEDIUM),
                ('jge', 'bge', MatchConfidence.MEDIUM),
                ('call', 'jal', MatchConfidence.HIGH),
                ('ret', 'ret', MatchConfidence.HIGH),
                ('nop', 'nop', MatchConfidence.EXACT),
            ]
        )

    def _add_simple_mapping(self, source: Architecture, target: Architecture,
                            mappings: list[tuple[str, str, MatchConfidence]]) -> None:
        """Add simple instruction mappings."""
        for src_mnem, tgt_mnem, conf in mappings:
            mapping = InstructionMapping(
                source_arch=source,
                target_arch=target,
                source_mnemonic=src_mnem,
                target_mnemonic=tgt_mnem,
                confidence=conf,
            )
            key = (source, target, src_mnem.lower())
            if key not in self._mappings:
                self._mappings[key] = []
            self._mappings[key].append(mapping)

    def get_mappings(self, source: Architecture, target: Architecture,
                     mnemonic: str) -> list[InstructionMapping]:
        """Get instruction mappings."""
        key = (source, target, mnemonic.lower())
        return self._mappings.get(key, [])

    def get_best_mapping(self, source: Architecture, target: Architecture,
                         mnemonic: str) -> InstructionMapping | None:
        """Get best (highest confidence) mapping."""
        mappings = self.get_mappings(source, target, mnemonic)
        if not mappings:
            return None
        return max(mappings, key=lambda m: m.confidence)


# =============================================================================
# Comparison Engines
# =============================================================================

class FunctionComparator:
    """Compares functions across architectures."""

    def __init__(self):
        self._register_table = RegisterEquivalenceTable()
        self._instruction_table = InstructionEquivalenceTable()

    def compare(self, source: FunctionSignature,
                target: FunctionSignature) -> FunctionMatch:
        """Compare two functions."""
        differences = []
        similarity_scores = []

        # Compare number of arguments
        if source.num_args == target.num_args:
            similarity_scores.append(1.0)
        else:
            similarity_scores.append(0.5)
            differences.append(DifferenceType.CALLING_CONVENTION)

        # Compare return size
        if source.return_size == target.return_size:
            similarity_scores.append(1.0)
        else:
            similarity_scores.append(0.7)
            differences.append(DifferenceType.DATA_SIZE)

        # Compare stack usage (normalized)
        source_info = ARCH_INFO.get(source.arch)
        target_info = ARCH_INFO.get(target.arch)

        if source_info and target_info:
            # Adjust for pointer size differences
            source_adjusted = source.stack_usage / source_info.pointer_size
            target_adjusted = target.stack_usage / target_info.pointer_size

            if source_adjusted > 0 and target_adjusted > 0:
                ratio = min(source_adjusted, target_adjusted) / max(source_adjusted, target_adjusted)
                similarity_scores.append(ratio)
            else:
                similarity_scores.append(1.0 if source.stack_usage == target.stack_usage else 0.5)

        # Compare calling conventions
        if source.calling_convention == target.calling_convention:
            similarity_scores.append(1.0)
        else:
            # Different conventions but might be functionally similar
            similarity_scores.append(0.8)
            if DifferenceType.CALLING_CONVENTION not in differences:
                differences.append(DifferenceType.CALLING_CONVENTION)

        # Calculate overall similarity
        overall_similarity = sum(similarity_scores) / len(similarity_scores) if similarity_scores else 0.0

        # Determine confidence
        if overall_similarity >= 0.95:
            confidence = MatchConfidence.EXACT
        elif overall_similarity >= 0.8:
            confidence = MatchConfidence.HIGH
        elif overall_similarity >= 0.6:
            confidence = MatchConfidence.MEDIUM
        elif overall_similarity >= 0.4:
            confidence = MatchConfidence.LOW
        else:
            confidence = MatchConfidence.NONE

        return FunctionMatch(
            source=source,
            target=target,
            confidence=confidence,
            similarity=overall_similarity,
            differences=differences,
        )

    def find_matches(self, source_funcs: list[FunctionSignature],
                     target_funcs: list[FunctionSignature],
                     threshold: float = 0.5) -> list[FunctionMatch]:
        """Find matching functions between two sets."""
        matches = []

        for src_func in source_funcs:
            best_match = None
            best_similarity = 0.0

            for tgt_func in target_funcs:
                match = self.compare(src_func, tgt_func)
                if match.similarity > best_similarity and match.similarity >= threshold:
                    best_match = match
                    best_similarity = match.similarity

            if best_match:
                matches.append(best_match)

        return matches


class TraceComparator:
    """Compares execution traces across architectures."""

    def __init__(self):
        self._register_table = RegisterEquivalenceTable()
        self._instruction_table = InstructionEquivalenceTable()

    def compare(self, source: ExecutionTrace,
                target: ExecutionTrace) -> TraceComparison:
        """Compare two execution traces."""
        matched = 0
        unmatched = 0
        divergence_points = []

        src_len = len(source.entries)
        tgt_len = len(target.entries)

        if src_len == 0 or tgt_len == 0:
            return TraceComparison(
                source_trace=source,
                target_trace=target,
                matched_entries=0,
                unmatched_entries=max(src_len, tgt_len),
                divergence_points=[],
                similarity=0.0 if max(src_len, tgt_len) > 0 else 1.0,
            )

        # Use LCS-like matching
        i, j = 0, 0
        while i < src_len and j < tgt_len:
            src_entry = source.entries[i]
            tgt_entry = target.entries[j]

            if self._entries_match(src_entry, tgt_entry, source.arch, target.arch):
                matched += 1
                i += 1
                j += 1
            else:
                unmatched += 1
                divergence_points.append(i)
                # Try to find alignment
                i += 1
                j += 1

        # Count remaining entries as unmatched
        unmatched += (src_len - i) + (tgt_len - j)

        total_entries = max(src_len, tgt_len)
        similarity = matched / total_entries if total_entries > 0 else 1.0

        return TraceComparison(
            source_trace=source,
            target_trace=target,
            matched_entries=matched,
            unmatched_entries=unmatched,
            divergence_points=divergence_points,
            similarity=similarity,
        )

    def _entries_match(self, src: dict, tgt: dict,
                       src_arch: Architecture, tgt_arch: Architecture) -> bool:
        """Check if two trace entries match semantically."""
        src_inst = src.get('instruction', '').split()[0].lower()
        tgt_inst = tgt.get('instruction', '').split()[0].lower()

        # Check for equivalent instructions
        mapping = self._instruction_table.get_best_mapping(src_arch, tgt_arch, src_inst)
        if mapping and mapping.target_mnemonic.lower() == tgt_inst:
            return True

        # Same mnemonic is also a match
        if src_inst == tgt_inst:
            return True

        return False


class LayoutComparator:
    """Compares data layouts across architectures."""

    def __init__(self):
        self._type_sizes: dict[Architecture, dict[str, int]] = {}
        self._setup_type_sizes()

    def _setup_type_sizes(self) -> None:
        """Set up type sizes for different architectures."""
        # Common types
        for arch in [Architecture.X86, Architecture.ARM, Architecture.MIPS,
                     Architecture.RISCV32, Architecture.POWERPC]:
            self._type_sizes[arch] = {
                'char': 1,
                'short': 2,
                'int': 4,
                'long': 4,
                'long long': 8,
                'pointer': 4,
                'size_t': 4,
                'float': 4,
                'double': 8,
            }

        for arch in [Architecture.X86_64, Architecture.ARM64, Architecture.MIPS64,
                     Architecture.RISCV64, Architecture.POWERPC64]:
            self._type_sizes[arch] = {
                'char': 1,
                'short': 2,
                'int': 4,
                'long': 8,  # LP64 model
                'long long': 8,
                'pointer': 8,
                'size_t': 8,
                'float': 4,
                'double': 8,
            }

    def compare_type(self, type_name: str, source: Architecture,
                     target: Architecture) -> MemoryLayoutDifference | None:
        """Compare a type across architectures."""
        src_sizes = self._type_sizes.get(source, {})
        tgt_sizes = self._type_sizes.get(target, {})

        src_size = src_sizes.get(type_name)
        tgt_size = tgt_sizes.get(type_name)

        if src_size is None or tgt_size is None:
            return None

        if src_size != tgt_size:
            return MemoryLayoutDifference(
                name=type_name,
                source_size=src_size,
                source_alignment=src_size,  # Simplified
                target_size=tgt_size,
                target_alignment=tgt_size,
                description=f"{type_name} size differs: {src_size} vs {tgt_size}",
            )

        return None

    def compare_all_types(self, source: Architecture,
                          target: Architecture) -> list[MemoryLayoutDifference]:
        """Compare all known types between architectures."""
        differences = []

        src_sizes = self._type_sizes.get(source, {})

        for type_name in src_sizes:
            diff = self.compare_type(type_name, source, target)
            if diff:
                differences.append(diff)

        return differences

    def get_type_size(self, type_name: str, arch: Architecture) -> int | None:
        """Get size of a type for an architecture."""
        sizes = self._type_sizes.get(arch, {})
        return sizes.get(type_name)


# =============================================================================
# Multi-Architecture Comparator
# =============================================================================

class MultiArchComparator:
    """Main class for multi-architecture comparison."""

    def __init__(self):
        self._function_comparator = FunctionComparator()
        self._trace_comparator = TraceComparator()
        self._layout_comparator = LayoutComparator()
        self._register_table = RegisterEquivalenceTable()
        self._instruction_table = InstructionEquivalenceTable()

    @property
    def register_table(self) -> RegisterEquivalenceTable:
        """Get register equivalence table."""
        return self._register_table

    @property
    def instruction_table(self) -> InstructionEquivalenceTable:
        """Get instruction equivalence table."""
        return self._instruction_table

    def get_arch_info(self, arch: Architecture) -> ArchInfo | None:
        """Get architecture information."""
        return ARCH_INFO.get(arch)

    def get_supported_architectures(self) -> list[Architecture]:
        """Get list of supported architectures."""
        return list(ARCH_INFO.keys())

    def compare_functions(self, source_funcs: list[FunctionSignature],
                          target_funcs: list[FunctionSignature],
                          threshold: float = 0.5) -> list[FunctionMatch]:
        """Compare function lists."""
        return self._function_comparator.find_matches(
            source_funcs, target_funcs, threshold
        )

    def compare_traces(self, source: ExecutionTrace,
                       target: ExecutionTrace) -> TraceComparison:
        """Compare execution traces."""
        return self._trace_comparator.compare(source, target)

    def compare_layouts(self, source: Architecture,
                        target: Architecture) -> list[MemoryLayoutDifference]:
        """Compare memory layouts."""
        return self._layout_comparator.compare_all_types(source, target)

    def full_comparison(self, source_arch: Architecture,
                        target_arch: Architecture,
                        source_funcs: list[FunctionSignature] | None = None,
                        target_funcs: list[FunctionSignature] | None = None,
                        source_trace: ExecutionTrace | None = None,
                        target_trace: ExecutionTrace | None = None,
                        comparison_type: ComparisonType = ComparisonType.SEMANTIC) -> ArchComparisonResult:
        """Perform full comparison between architectures."""
        result = ArchComparisonResult(
            source_arch=source_arch,
            target_arch=target_arch,
            comparison_type=comparison_type,
        )

        # Compare functions if provided
        if source_funcs and target_funcs:
            result.function_matches = self.compare_functions(
                source_funcs, target_funcs
            )

        # Compare layouts
        result.layout_differences = self.compare_layouts(source_arch, target_arch)

        # Compare traces if provided
        trace_similarity = 0.0
        if source_trace and target_trace:
            trace_comparison = self.compare_traces(source_trace, target_trace)
            trace_similarity = trace_comparison.similarity

        # Calculate overall similarity
        similarities = []

        if result.function_matches:
            func_sim = sum(m.similarity for m in result.function_matches) / len(result.function_matches)
            similarities.append(func_sim)

        if source_trace and target_trace:
            similarities.append(trace_similarity)

        # Layout differences reduce similarity
        if result.layout_differences:
            layout_penalty = min(0.2 * len(result.layout_differences), 0.5)
            similarities.append(1.0 - layout_penalty)

        result.overall_similarity = sum(similarities) / len(similarities) if similarities else 0.5

        # Generate summary
        result.summary = self._generate_summary(result)

        return result

    def _generate_summary(self, result: ArchComparisonResult) -> str:
        """Generate summary text for comparison result."""
        lines = []
        lines.append(f"Comparison: {result.source_arch.name} vs {result.target_arch.name}")
        lines.append(f"Overall Similarity: {result.overall_similarity:.1%}")
        lines.append(f"Comparison Type: {result.comparison_type.name}")

        if result.function_matches:
            lines.append(f"Function Matches: {len(result.function_matches)}")
            high_conf = sum(1 for m in result.function_matches
                          if m.confidence >= MatchConfidence.HIGH)
            lines.append(f"  High Confidence: {high_conf}")

        if result.layout_differences:
            lines.append(f"Layout Differences: {len(result.layout_differences)}")
            for diff in result.layout_differences[:3]:
                lines.append(f"  - {diff.name}: {diff.source_size} -> {diff.target_size}")

        return "\n".join(lines)

    def get_register_equivalent(self, source_arch: Architecture,
                                target_arch: Architecture,
                                register: str) -> str | None:
        """Get equivalent register."""
        return self._register_table.get_equivalent(source_arch, target_arch, register)

    def get_instruction_mapping(self, source_arch: Architecture,
                                target_arch: Architecture,
                                mnemonic: str) -> InstructionMapping | None:
        """Get instruction mapping."""
        return self._instruction_table.get_best_mapping(
            source_arch, target_arch, mnemonic
        )


# =============================================================================
# Binary Comparison
# =============================================================================

class BinaryComparator:
    """Compares binaries across architectures."""

    def __init__(self):
        self._arch_comparator = MultiArchComparator()

    def detect_architecture(self, binary: bytes) -> Architecture | None:
        """Detect architecture from binary header."""
        if len(binary) < 20:
            return None

        # ELF detection
        if binary[:4] == b'\x7fELF':
            e_machine = struct.unpack('<H', binary[18:20])[0]
            arch_map = {
                3: Architecture.X86,
                62: Architecture.X86_64,
                40: Architecture.ARM,
                183: Architecture.ARM64,
                8: Architecture.MIPS,
                20: Architecture.POWERPC,
                21: Architecture.POWERPC64,
                243: Architecture.RISCV64,  # RISC-V
            }
            return arch_map.get(e_machine)

        # PE detection
        if binary[:2] == b'MZ':
            # Simplified PE detection
            return Architecture.X86_64  # Default guess

        return None

    def compare_binaries(self, source: bytes, target: bytes,
                         source_arch: Architecture | None = None,
                         target_arch: Architecture | None = None) -> ArchComparisonResult:
        """Compare two binaries."""
        # Detect architectures if not provided
        if source_arch is None:
            source_arch = self.detect_architecture(source)
        if target_arch is None:
            target_arch = self.detect_architecture(target)

        if source_arch is None or target_arch is None:
            return ArchComparisonResult(
                source_arch=source_arch or Architecture.X86,
                target_arch=target_arch or Architecture.X86,
                comparison_type=ComparisonType.STRUCTURAL,
                overall_similarity=0.0,
                summary="Unable to detect architecture",
            )

        # Compare binary sizes
        size_ratio = min(len(source), len(target)) / max(len(source), len(target))

        return ArchComparisonResult(
            source_arch=source_arch,
            target_arch=target_arch,
            comparison_type=ComparisonType.STRUCTURAL,
            overall_similarity=size_ratio * 0.5,  # Binary size is weak indicator
            layout_differences=self._arch_comparator.compare_layouts(source_arch, target_arch),
            summary=f"Binary comparison: {len(source)} bytes vs {len(target)} bytes",
        )


# =============================================================================
# Cross-Architecture Execution
# =============================================================================

class CrossArchExecutor:
    """Executes and compares across architectures."""

    def __init__(self):
        self._comparator = MultiArchComparator()
        self._traces: dict[Architecture, list[ExecutionTrace]] = defaultdict(list)

    def record_trace(self, arch: Architecture, trace: ExecutionTrace) -> None:
        """Record an execution trace."""
        self._traces[arch].append(trace)

    def get_traces(self, arch: Architecture) -> list[ExecutionTrace]:
        """Get traces for an architecture."""
        return self._traces.get(arch, [])

    def compare_executions(self, source_arch: Architecture,
                           target_arch: Architecture,
                           trace_index: int = 0) -> TraceComparison | None:
        """Compare executions between architectures."""
        source_traces = self._traces.get(source_arch, [])
        target_traces = self._traces.get(target_arch, [])

        if trace_index >= len(source_traces) or trace_index >= len(target_traces):
            return None

        return self._comparator.compare_traces(
            source_traces[trace_index],
            target_traces[trace_index]
        )

    def clear_traces(self, arch: Architecture | None = None) -> None:
        """Clear recorded traces."""
        if arch:
            self._traces[arch] = []
        else:
            self._traces.clear()


# =============================================================================
# Helper Functions
# =============================================================================

def create_arch_comparator() -> MultiArchComparator:
    """Create a multi-architecture comparator."""
    return MultiArchComparator()


def create_binary_comparator() -> BinaryComparator:
    """Create a binary comparator."""
    return BinaryComparator()


def get_arch_info(arch: Architecture) -> ArchInfo | None:
    """Get architecture information."""
    return ARCH_INFO.get(arch)


def compare_functions(source: FunctionSignature,
                      target: FunctionSignature) -> FunctionMatch:
    """Compare two functions."""
    comparator = FunctionComparator()
    return comparator.compare(source, target)


def compare_traces(source: ExecutionTrace,
                   target: ExecutionTrace) -> TraceComparison:
    """Compare two execution traces."""
    comparator = TraceComparator()
    return comparator.compare(source, target)


def quick_compare(source_arch: Architecture,
                  target_arch: Architecture) -> ArchComparisonResult:
    """Quick comparison between two architectures."""
    comparator = create_arch_comparator()
    return comparator.full_comparison(source_arch, target_arch)


# Exports
__all__ = [
    # Enums
    'Architecture',
    'Endianness',
    'ComparisonType',
    'MatchConfidence',
    'DifferenceType',

    # Data classes
    'ArchInfo',
    'RegisterMapping',
    'InstructionMapping',
    'MemoryLayoutDifference',
    'FunctionSignature',
    'FunctionMatch',
    'ExecutionTrace',
    'TraceComparison',
    'ArchComparisonResult',

    # Tables
    'RegisterEquivalenceTable',
    'InstructionEquivalenceTable',

    # Comparators
    'FunctionComparator',
    'TraceComparator',
    'LayoutComparator',
    'MultiArchComparator',
    'BinaryComparator',
    'CrossArchExecutor',

    # Constants
    'ARCH_INFO',

    # Helper functions
    'create_arch_comparator',
    'create_binary_comparator',
    'get_arch_info',
    'compare_functions',
    'compare_traces',
    'quick_compare',
]
