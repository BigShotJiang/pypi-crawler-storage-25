"""
IDA Pro Bridge - Integrate PyUniDbg with IDA Pro disassembler.

Provides bidirectional communication with IDA Pro for:
- Syncing symbols, comments, and function names
- Remote debugging integration
- Memory and register synchronization
- Breakpoint management
- Analysis data export/import

Usage:
    from pyunidbg.integrations import IDABridge
    
    # Connect to IDA Pro (requires IDAPython plugin)
    bridge = IDABridge(emulator, host="localhost", port=13370)
    bridge.connect()
    
    # Sync symbols from IDA
    bridge.import_symbols()
    
    # Sync current state to IDA
    bridge.sync_to_ida()
    
    # Set breakpoint in both
    bridge.set_breakpoint(0x1000, sync=True)
"""

from __future__ import annotations

import json
import logging
import socket
import struct
import threading
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

from pyunidbg.errors import (
    IntegrationConnectionError,
    IntegrationProtocolError,
    IntegrationTimeoutError,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    "IDABridge",
    "IDASymbol",
    "IDAFunction",
    "IDAComment",
    "IDABreakpoint",
    "IDASegment",
    "IDAConnectionError",
    "IDAProtocolError",
    "IDATimeoutError",
    "create_ida_bridge",
]

logger = logging.getLogger(__name__)


# ==================== Exceptions ====================

class IDAConnectionError(IntegrationConnectionError):
    """Error connecting to IDA Pro."""


class IDAProtocolError(IntegrationProtocolError):
    """Error in IDA communication protocol."""


class IDATimeoutError(IntegrationTimeoutError):
    """Timeout waiting for IDA response."""


# ==================== Enums ====================

class MessageType(Enum):
    """IDA bridge message types."""
    # Requests
    PING = 0x01
    GET_SYMBOLS = 0x02
    GET_FUNCTIONS = 0x03
    GET_SEGMENTS = 0x04
    GET_COMMENTS = 0x05
    GET_MEMORY = 0x06
    GET_REGISTERS = 0x07

    # Commands
    SET_SYMBOL = 0x10
    SET_COMMENT = 0x11
    SET_FUNCTION = 0x12
    SET_BREAKPOINT = 0x13
    REMOVE_BREAKPOINT = 0x14
    SYNC_MEMORY = 0x15
    SYNC_REGISTERS = 0x16
    HIGHLIGHT_ADDRESS = 0x17
    JUMP_TO_ADDRESS = 0x18

    # Responses
    OK = 0x80
    ERROR = 0x81
    DATA = 0x82

    # Events (from IDA)
    BREAKPOINT_HIT = 0x90
    MEMORY_CHANGED = 0x91
    SYMBOL_CHANGED = 0x92


class SymbolType(Enum):
    """Types of symbols."""
    FUNCTION = "function"
    DATA = "data"
    CODE = "code"
    IMPORT = "import"
    EXPORT = "export"
    STRING = "string"
    UNKNOWN = "unknown"


class CommentType(Enum):
    """Types of comments."""
    REGULAR = "regular"
    REPEATABLE = "repeatable"
    ANTERIOR = "anterior"
    POSTERIOR = "posterior"
    FUNCTION = "function"


# ==================== Data Classes ====================

@dataclass
class IDASymbol:
    """A symbol from IDA."""
    address: int
    name: str
    size: int = 0
    symbol_type: SymbolType = SymbolType.UNKNOWN
    library: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "name": self.name,
            "size": self.size,
            "type": self.symbol_type.value,
            "library": self.library,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IDASymbol:
        addr = data.get("address", 0)
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)
        return cls(
            address=addr,
            name=data.get("name", ""),
            size=data.get("size", 0),
            symbol_type=SymbolType(data.get("type", "unknown")),
            library=data.get("library"),
        )


@dataclass
class IDAFunction:
    """A function from IDA."""
    address: int
    name: str
    end_address: int = 0
    size: int = 0
    is_thunk: bool = False
    is_library: bool = False
    calling_convention: str = ""
    return_type: str = ""
    arguments: list[tuple[str, str]] = field(default_factory=list)  # (type, name)
    local_vars: list[tuple[str, str, int]] = field(default_factory=list)  # (type, name, offset)

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "name": self.name,
            "end_address": hex(self.end_address),
            "size": self.size,
            "is_thunk": self.is_thunk,
            "is_library": self.is_library,
            "calling_convention": self.calling_convention,
            "return_type": self.return_type,
            "arguments": self.arguments,
            "local_vars": self.local_vars,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IDAFunction:
        addr = data.get("address", 0)
        end = data.get("end_address", 0)
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)
        if isinstance(end, str):
            end = int(end, 16) if end.startswith("0x") else int(end)
        return cls(
            address=addr,
            name=data.get("name", ""),
            end_address=end,
            size=data.get("size", 0),
            is_thunk=data.get("is_thunk", False),
            is_library=data.get("is_library", False),
            calling_convention=data.get("calling_convention", ""),
            return_type=data.get("return_type", ""),
            arguments=data.get("arguments", []),
            local_vars=data.get("local_vars", []),
        )


@dataclass
class IDAComment:
    """A comment from IDA."""
    address: int
    text: str
    comment_type: CommentType = CommentType.REGULAR

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "text": self.text,
            "type": self.comment_type.value,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IDAComment:
        addr = data.get("address", 0)
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)
        return cls(
            address=addr,
            text=data.get("text", ""),
            comment_type=CommentType(data.get("type", "regular")),
        )


@dataclass
class IDABreakpoint:
    """A breakpoint synced with IDA."""
    address: int
    enabled: bool = True
    condition: str = ""
    hit_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "enabled": self.enabled,
            "condition": self.condition,
            "hit_count": self.hit_count,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IDABreakpoint:
        addr = data.get("address", 0)
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)
        return cls(
            address=addr,
            enabled=data.get("enabled", True),
            condition=data.get("condition", ""),
            hit_count=data.get("hit_count", 0),
        )


@dataclass
class IDASegment:
    """A memory segment from IDA."""
    start: int
    end: int
    name: str
    permissions: str = "rwx"
    segment_class: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "start": hex(self.start),
            "end": hex(self.end),
            "name": self.name,
            "permissions": self.permissions,
            "class": self.segment_class,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IDASegment:
        start = data.get("start", 0)
        end = data.get("end", 0)
        if isinstance(start, str):
            start = int(start, 16) if start.startswith("0x") else int(start)
        if isinstance(end, str):
            end = int(end, 16) if end.startswith("0x") else int(end)
        return cls(
            start=start,
            end=end,
            name=data.get("name", ""),
            permissions=data.get("permissions", "rwx"),
            segment_class=data.get("class", ""),
        )


# ==================== Protocol Handler ====================

class IDAProtocol:
    """
    Binary protocol for IDA communication.
    
    Message format:
    - 4 bytes: message type
    - 4 bytes: payload length
    - N bytes: JSON payload
    """

    HEADER_SIZE = 8
    MAGIC = b'IDBR'
    VERSION = 1

    @staticmethod
    def encode_message(msg_type: MessageType, payload: dict[str, Any]) -> bytes:
        """Encode a message for transmission."""
        payload_bytes = json.dumps(payload).encode('utf-8')
        header = struct.pack('>II', msg_type.value, len(payload_bytes))
        return header + payload_bytes

    @staticmethod
    def decode_header(data: bytes) -> tuple[MessageType, int]:
        """Decode message header."""
        if len(data) < IDAProtocol.HEADER_SIZE:
            raise IDAProtocolError("Incomplete header")

        msg_type_val, length = struct.unpack('>II', data[:8])
        try:
            msg_type = MessageType(msg_type_val)
        except ValueError:
            raise IDAProtocolError(f"Unknown message type: {msg_type_val}")

        return msg_type, length

    @staticmethod
    def decode_payload(data: bytes) -> dict[str, Any]:
        """Decode message payload."""
        try:
            return json.loads(data.decode('utf-8'))
        except json.JSONDecodeError as e:
            raise IDAProtocolError(f"Invalid JSON payload: {e}")


# ==================== Event Handler ====================

class IDAEventHandler:
    """Handles events from IDA."""

    def __init__(self):
        self._handlers: dict[MessageType, list[Callable]] = defaultdict(list)

    def on(self, event_type: MessageType, callback: Callable) -> None:
        """Register an event handler."""
        self._handlers[event_type].append(callback)

    def off(self, event_type: MessageType, callback: Callable) -> None:
        """Unregister an event handler."""
        if callback in self._handlers[event_type]:
            self._handlers[event_type].remove(callback)

    def emit(self, event_type: MessageType, data: dict[str, Any]) -> None:
        """Emit an event to all handlers."""
        for handler in self._handlers[event_type]:
            try:
                handler(data)
            except Exception as e:
                logger.error(f"Error in event handler: {e}")


# ==================== IDA Bridge ====================

class IDABridge:
    """
    Bridge for communication with IDA Pro.
    
    Provides:
    - Symbol/function/comment synchronization
    - Breakpoint management
    - Memory and register sync
    - Event-based notifications
    
    Requires the PyUniDbg IDA plugin to be running in IDA Pro.
    """

    DEFAULT_PORT = 13370

    def __init__(
        self,
        emulator: Emulator,
        host: str = "localhost",
        port: int = DEFAULT_PORT,
        auto_sync: bool = False,
    ):
        self._emulator = emulator
        self._host = host
        self._port = port
        self._auto_sync = auto_sync

        self._socket: socket.socket | None = None
        self._connected = False
        self._receive_thread: threading.Thread | None = None
        self._running = False

        self._events = IDAEventHandler()
        self._pending_responses: dict[int, Any] = {}
        self._response_id = 0
        self._response_lock = threading.Lock()
        self._response_events: dict[int, threading.Event] = {}

        # Cached data from IDA
        self._symbols: dict[int, IDASymbol] = {}
        self._functions: dict[int, IDAFunction] = {}
        self._comments: dict[int, IDAComment] = {}
        self._breakpoints: dict[int, IDABreakpoint] = {}
        self._segments: list[IDASegment] = []

        # Set up emulator hooks for auto-sync
        if auto_sync:
            self._setup_auto_sync()

    @property
    def connected(self) -> bool:
        """Check if connected to IDA."""
        return self._connected

    @property
    def symbols(self) -> dict[int, IDASymbol]:
        """Get cached symbols."""
        return self._symbols.copy()

    @property
    def functions(self) -> dict[int, IDAFunction]:
        """Get cached functions."""
        return self._functions.copy()

    @property
    def comments(self) -> dict[int, IDAComment]:
        """Get cached comments."""
        return self._comments.copy()

    @property
    def events(self) -> IDAEventHandler:
        """Get event handler for registering callbacks."""
        return self._events

    def connect(self, timeout: float = 5.0) -> bool:
        """
        Connect to IDA Pro.
        
        Args:
            timeout: Connection timeout in seconds
            
        Returns:
            True if connected successfully
            
        Raises:
            IDAConnectionError: If connection fails
        """
        if self._connected:
            return True

        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.settimeout(timeout)
            self._socket.connect((self._host, self._port))
            self._socket.settimeout(None)

            # Start receive thread
            self._running = True
            self._receive_thread = threading.Thread(
                target=self._receive_loop,
                daemon=True
            )
            self._receive_thread.start()

            # Send ping to verify connection
            response = self._send_request(MessageType.PING, {})
            if response.get("status") != "ok":
                raise IDAConnectionError("Failed to ping IDA")

            self._connected = True
            logger.info(f"Connected to IDA Pro at {self._host}:{self._port}")

            return True

        except OSError as e:
            self._cleanup()
            raise IDAConnectionError(f"Failed to connect to IDA: {e}")

    def disconnect(self) -> None:
        """Disconnect from IDA Pro."""
        self._running = False
        self._cleanup()
        self._connected = False
        logger.info("Disconnected from IDA Pro")

    def _cleanup(self) -> None:
        """Clean up connection resources."""
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._socket = None

        if self._receive_thread and self._receive_thread.is_alive():
            self._receive_thread.join(timeout=1.0)

    def _receive_loop(self) -> None:
        """Background thread for receiving messages."""
        while self._running and self._socket:
            try:
                # Read header
                header = self._recv_exact(IDAProtocol.HEADER_SIZE)
                if not header:
                    break

                msg_type, length = IDAProtocol.decode_header(header)

                # Read payload
                payload_bytes = self._recv_exact(length)
                if not payload_bytes:
                    break

                payload = IDAProtocol.decode_payload(payload_bytes)

                # Handle message
                self._handle_message(msg_type, payload)

            except TimeoutError:
                continue
            except Exception as e:
                if self._running:
                    logger.error(f"Error in receive loop: {e}")
                break

        self._connected = False

    def _recv_exact(self, size: int) -> bytes | None:
        """Receive exactly size bytes."""
        data = b''
        while len(data) < size:
            chunk = self._socket.recv(size - len(data))
            if not chunk:
                return None
            data += chunk
        return data

    def _handle_message(self, msg_type: MessageType, payload: dict[str, Any]) -> None:
        """Handle incoming message."""
        # Check for response to pending request
        if "request_id" in payload:
            req_id = payload["request_id"]
            with self._response_lock:
                if req_id in self._response_events:
                    self._pending_responses[req_id] = payload
                    self._response_events[req_id].set()
                    return

        # Handle events
        if msg_type == MessageType.BREAKPOINT_HIT:
            self._events.emit(msg_type, payload)
        elif msg_type == MessageType.MEMORY_CHANGED:
            self._events.emit(msg_type, payload)
        elif msg_type == MessageType.SYMBOL_CHANGED:
            self._events.emit(msg_type, payload)
            # Update cache
            if "symbol" in payload:
                sym = IDASymbol.from_dict(payload["symbol"])
                self._symbols[sym.address] = sym

    def _send_request(
        self,
        msg_type: MessageType,
        payload: dict[str, Any],
        timeout: float = 10.0
    ) -> dict[str, Any]:
        """Send request and wait for response."""
        if not self._socket:
            raise IDAConnectionError("Not connected")

        # Create request with ID
        with self._response_lock:
            self._response_id += 1
            req_id = self._response_id
            self._response_events[req_id] = threading.Event()

        payload["request_id"] = req_id

        # Send message
        message = IDAProtocol.encode_message(msg_type, payload)
        try:
            self._socket.sendall(message)
        except OSError as e:
            raise IDAConnectionError(f"Failed to send message: {e}")

        # Wait for response
        if not self._response_events[req_id].wait(timeout):
            with self._response_lock:
                del self._response_events[req_id]
            raise IDATimeoutError("Timeout waiting for response")

        # Get response
        with self._response_lock:
            response = self._pending_responses.pop(req_id, {})
            del self._response_events[req_id]

        return response

    def _send_command(self, msg_type: MessageType, payload: dict[str, Any]) -> bool:
        """Send command without waiting for response."""
        if not self._socket:
            raise IDAConnectionError("Not connected")

        message = IDAProtocol.encode_message(msg_type, payload)
        try:
            self._socket.sendall(message)
            return True
        except OSError as e:
            raise IDAConnectionError(f"Failed to send command: {e}")

    # ==================== Symbol Management ====================

    def import_symbols(self, refresh: bool = False) -> dict[int, IDASymbol]:
        """
        Import symbols from IDA.
        
        Args:
            refresh: Force refresh from IDA even if cached
            
        Returns:
            Dictionary of address -> symbol
        """
        if self._symbols and not refresh:
            return self._symbols.copy()

        response = self._send_request(MessageType.GET_SYMBOLS, {})

        if response.get("status") == "ok":
            self._symbols.clear()
            for sym_data in response.get("symbols", []):
                sym = IDASymbol.from_dict(sym_data)
                self._symbols[sym.address] = sym

                # Apply to emulator
                self._emulator.add_symbol(sym.address, sym.name)

        return self._symbols.copy()

    def export_symbol(self, address: int, name: str, sym_type: SymbolType = SymbolType.UNKNOWN) -> bool:
        """
        Export a symbol to IDA.
        
        Args:
            address: Symbol address
            name: Symbol name
            sym_type: Symbol type
            
        Returns:
            True if successful
        """
        response = self._send_request(MessageType.SET_SYMBOL, {
            "address": hex(address),
            "name": name,
            "type": sym_type.value,
        })

        if response.get("status") == "ok":
            self._symbols[address] = IDASymbol(address, name, symbol_type=sym_type)
            return True
        return False

    def get_symbol(self, address: int) -> IDASymbol | None:
        """Get symbol at address."""
        return self._symbols.get(address)

    def get_symbol_by_name(self, name: str) -> IDASymbol | None:
        """Get symbol by name."""
        for sym in self._symbols.values():
            if sym.name == name:
                return sym
        return None

    # ==================== Function Management ====================

    def import_functions(self, refresh: bool = False) -> dict[int, IDAFunction]:
        """Import functions from IDA."""
        if self._functions and not refresh:
            return self._functions.copy()

        response = self._send_request(MessageType.GET_FUNCTIONS, {})

        if response.get("status") == "ok":
            self._functions.clear()
            for func_data in response.get("functions", []):
                func = IDAFunction.from_dict(func_data)
                self._functions[func.address] = func

        return self._functions.copy()

    def get_function(self, address: int) -> IDAFunction | None:
        """Get function containing address."""
        for func in self._functions.values():
            if func.address <= address < func.end_address:
                return func
        return None

    def get_function_at(self, address: int) -> IDAFunction | None:
        """Get function starting at address."""
        return self._functions.get(address)

    def create_function(self, address: int, name: str | None = None) -> bool:
        """Create a function in IDA."""
        response = self._send_request(MessageType.SET_FUNCTION, {
            "address": hex(address),
            "name": name,
            "action": "create",
        })
        return response.get("status") == "ok"

    # ==================== Comment Management ====================

    def import_comments(self, refresh: bool = False) -> dict[int, IDAComment]:
        """Import comments from IDA."""
        if self._comments and not refresh:
            return self._comments.copy()

        response = self._send_request(MessageType.GET_COMMENTS, {})

        if response.get("status") == "ok":
            self._comments.clear()
            for cmt_data in response.get("comments", []):
                cmt = IDAComment.from_dict(cmt_data)
                self._comments[cmt.address] = cmt

        return self._comments.copy()

    def set_comment(
        self,
        address: int,
        text: str,
        comment_type: CommentType = CommentType.REGULAR
    ) -> bool:
        """Set a comment in IDA."""
        response = self._send_request(MessageType.SET_COMMENT, {
            "address": hex(address),
            "text": text,
            "type": comment_type.value,
        })

        if response.get("status") == "ok":
            self._comments[address] = IDAComment(address, text, comment_type)
            return True
        return False

    def get_comment(self, address: int) -> IDAComment | None:
        """Get comment at address."""
        return self._comments.get(address)

    # ==================== Breakpoint Management ====================

    def set_breakpoint(self, address: int, condition: str = "", sync: bool = True) -> bool:
        """
        Set a breakpoint.
        
        Args:
            address: Breakpoint address
            condition: Optional condition expression
            sync: Also set breakpoint in IDA
            
        Returns:
            True if successful
        """
        # Set in emulator
        self._emulator.set_breakpoint(address)

        bp = IDABreakpoint(address=address, condition=condition)
        self._breakpoints[address] = bp

        # Sync to IDA
        if sync and self._connected:
            response = self._send_request(MessageType.SET_BREAKPOINT, {
                "address": hex(address),
                "condition": condition,
            })
            return response.get("status") == "ok"

        return True

    def remove_breakpoint(self, address: int, sync: bool = True) -> bool:
        """Remove a breakpoint."""
        # Remove from emulator
        self._emulator.remove_breakpoint(address)

        if address in self._breakpoints:
            del self._breakpoints[address]

        # Sync to IDA
        if sync and self._connected:
            response = self._send_request(MessageType.REMOVE_BREAKPOINT, {
                "address": hex(address),
            })
            return response.get("status") == "ok"

        return True

    def get_breakpoints(self) -> dict[int, IDABreakpoint]:
        """Get all breakpoints."""
        return self._breakpoints.copy()

    # ==================== Memory Synchronization ====================

    def read_ida_memory(self, address: int, size: int) -> bytes | None:
        """Read memory from IDA's view."""
        response = self._send_request(MessageType.GET_MEMORY, {
            "address": hex(address),
            "size": size,
        })

        if response.get("status") == "ok":
            data = response.get("data", "")
            return bytes.fromhex(data)
        return None

    def sync_memory_to_ida(self, address: int, size: int) -> bool:
        """Sync emulator memory to IDA."""
        try:
            data = self._emulator.memory.read(address, size)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

        response = self._send_request(MessageType.SYNC_MEMORY, {
            "address": hex(address),
            "data": data.hex(),
        })
        return response.get("status") == "ok"

    def sync_memory_from_ida(self, address: int, size: int) -> bool:
        """Sync IDA memory to emulator."""
        data = self.read_ida_memory(address, size)
        if data:
            try:
                self._emulator.memory.write(address, data)
                return True
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        return False

    # ==================== Register Synchronization ====================

    def sync_registers_to_ida(self) -> bool:
        """Sync emulator registers to IDA."""
        regs = {}
        for name in self._emulator.arch.register_names:
            try:
                regs[name] = self._emulator.read_register(name)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        response = self._send_request(MessageType.SYNC_REGISTERS, {
            "registers": {k: hex(v) for k, v in regs.items()},
        })
        return response.get("status") == "ok"

    def get_ida_registers(self) -> dict[str, int]:
        """Get registers from IDA."""
        response = self._send_request(MessageType.GET_REGISTERS, {})

        if response.get("status") == "ok":
            regs = {}
            for name, value in response.get("registers", {}).items():
                if isinstance(value, str):
                    regs[name] = int(value, 16) if value.startswith("0x") else int(value)
                else:
                    regs[name] = value
            return regs
        return {}

    # ==================== Navigation ====================

    def highlight_address(self, address: int, color: int = 0xFFFF00) -> bool:
        """Highlight an address in IDA."""
        response = self._send_request(MessageType.HIGHLIGHT_ADDRESS, {
            "address": hex(address),
            "color": color,
        })
        return response.get("status") == "ok"

    def jump_to_address(self, address: int) -> bool:
        """Jump to address in IDA view."""
        response = self._send_request(MessageType.JUMP_TO_ADDRESS, {
            "address": hex(address),
        })
        return response.get("status") == "ok"

    # ==================== Segment Management ====================

    def import_segments(self, refresh: bool = False) -> list[IDASegment]:
        """Import segments from IDA."""
        if self._segments and not refresh:
            return self._segments.copy()

        response = self._send_request(MessageType.GET_SEGMENTS, {})

        if response.get("status") == "ok":
            self._segments.clear()
            for seg_data in response.get("segments", []):
                seg = IDASegment.from_dict(seg_data)
                self._segments.append(seg)

        return self._segments.copy()

    # ==================== Full Sync ====================

    def full_sync_from_ida(self) -> bool:
        """Import all data from IDA."""
        try:
            self.import_symbols(refresh=True)
            self.import_functions(refresh=True)
            self.import_comments(refresh=True)
            self.import_segments(refresh=True)
            return True
        except Exception as e:
            logger.error(f"Full sync failed: {e}")
            return False

    def sync_state_to_ida(self) -> bool:
        """Sync current emulator state to IDA."""
        try:
            self.sync_registers_to_ida()
            # Highlight current PC
            pc = self._emulator.read_register("pc")
            self.highlight_address(pc)
            self.jump_to_address(pc)
            return True
        except Exception as e:
            logger.error(f"State sync failed: {e}")
            return False

    # ==================== Auto-Sync ====================

    def _setup_auto_sync(self) -> None:
        """Set up automatic synchronization hooks."""
        # Hook breakpoints
        @self._emulator.hook_manager.on_breakpoint
        def on_breakpoint(address):
            if self._connected:
                self.sync_state_to_ida()

        # Hook step
        @self._emulator.hook_manager.on_step
        def on_step(address):
            if self._connected and self._auto_sync:
                self.highlight_address(address)

    # ==================== Export/Import ====================

    def export_to_json(self, path: str | Path) -> None:
        """Export all IDA data to JSON file."""
        data = {
            "symbols": [s.to_dict() for s in self._symbols.values()],
            "functions": [f.to_dict() for f in self._functions.values()],
            "comments": [c.to_dict() for c in self._comments.values()],
            "segments": [s.to_dict() for s in self._segments],
            "breakpoints": [b.to_dict() for b in self._breakpoints.values()],
        }

        path = Path(path)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)

    def import_from_json(self, path: str | Path) -> None:
        """Import data from JSON file."""
        path = Path(path)
        with open(path) as f:
            data = json.load(f)

        self._symbols.clear()
        for sym_data in data.get("symbols", []):
            sym = IDASymbol.from_dict(sym_data)
            self._symbols[sym.address] = sym

        self._functions.clear()
        for func_data in data.get("functions", []):
            func = IDAFunction.from_dict(func_data)
            self._functions[func.address] = func

        self._comments.clear()
        for cmt_data in data.get("comments", []):
            cmt = IDAComment.from_dict(cmt_data)
            self._comments[cmt.address] = cmt

        self._segments.clear()
        for seg_data in data.get("segments", []):
            seg = IDASegment.from_dict(seg_data)
            self._segments.append(seg)

    def __enter__(self) -> IDABridge:
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    def __repr__(self) -> str:
        status = "connected" if self._connected else "disconnected"
        return f"IDABridge({self._host}:{self._port}, {status})"


# ==================== Factory Function ====================

def create_ida_bridge(
    emulator: Emulator,
    host: str = "localhost",
    port: int = IDABridge.DEFAULT_PORT,
    auto_connect: bool = False,
) -> IDABridge:
    """
    Create an IDA bridge instance.
    
    Args:
        emulator: Emulator instance
        host: IDA host address
        port: IDA plugin port
        auto_connect: Automatically connect on creation
        
    Returns:
        IDABridge instance
    """
    bridge = IDABridge(emulator, host, port)
    if auto_connect:
        bridge.connect()
    return bridge
