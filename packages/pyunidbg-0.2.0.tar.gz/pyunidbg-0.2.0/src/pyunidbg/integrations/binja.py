"""
Binary Ninja Bridge - Integrate PyUniDbg with Binary Ninja.

Provides bidirectional communication with Binary Ninja for:
- Symbol and function synchronization
- Linear IL (LLIL), Medium IL (MLIL), High IL (HLIL) access
- Type library integration
- Plugin integration

Usage:
    from pyunidbg.integrations import BinaryNinjaBridge
    
    # Connect to Binary Ninja (via API or headless)
    bridge = BinaryNinjaBridge(emulator, bv=binary_view)
    
    # Or connect via RPC
    bridge = BinaryNinjaBridge(emulator, host="localhost", port=31337)
    bridge.connect()
    
    # Import analysis data
    bridge.import_symbols()
    bridge.import_functions()
    
    # Get HLIL for function
    hlil = bridge.get_hlil(0x1000)
"""

from __future__ import annotations

import json
import logging
import socket
import struct
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

from pyunidbg.errors import IntegrationConnectionError, IntegrationProtocolError

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    "BinaryNinjaBridge",
    "BNSymbol",
    "BNFunction",
    "BNType",
    "BNBasicBlock",
    "BNConnectionError",
    "BNProtocolError",
    "create_binja_bridge",
]

logger = logging.getLogger(__name__)


# ==================== Exceptions ====================

class BNConnectionError(IntegrationConnectionError):
    """Error connecting to Binary Ninja."""


class BNProtocolError(IntegrationProtocolError):
    """Error in Binary Ninja communication protocol."""


# ==================== Enums ====================

class SymbolType(Enum):
    """Binary Ninja symbol types."""
    FUNCTION = "FunctionSymbol"
    IMPORT = "ImportedFunctionSymbol"
    IMPORT_ADDR = "ImportAddressSymbol"
    DATA = "DataSymbol"
    IMPORT_DATA = "ImportedDataSymbol"
    EXTERNAL = "ExternalSymbol"
    LIBRARY = "LibraryFunctionSymbol"


class ILType(Enum):
    """Intermediate language types."""
    DISASM = "disasm"
    LLIL = "llil"
    LLIL_SSA = "llil_ssa"
    MLIL = "mlil"
    MLIL_SSA = "mlil_ssa"
    HLIL = "hlil"
    HLIL_SSA = "hlil_ssa"


class MessageType(Enum):
    """RPC message types."""
    PING = "ping"
    GET_BINARY_INFO = "get_binary_info"
    GET_SYMBOLS = "get_symbols"
    GET_FUNCTIONS = "get_functions"
    GET_TYPES = "get_types"
    GET_IL = "get_il"
    GET_MEMORY = "get_memory"
    GET_BASIC_BLOCKS = "get_basic_blocks"
    GET_XREFS = "get_xrefs"

    SET_SYMBOL = "set_symbol"
    SET_COMMENT = "set_comment"
    CREATE_FUNCTION = "create_function"
    SET_TYPE = "set_type"
    HIGHLIGHT = "highlight"
    GOTO = "goto"


# ==================== Data Classes ====================

@dataclass
class BNSymbol:
    """A Binary Ninja symbol."""
    address: int
    name: str
    full_name: str = ""
    symbol_type: SymbolType = SymbolType.DATA
    ordinal: int = 0
    namespace: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "name": self.name,
            "full_name": self.full_name,
            "type": self.symbol_type.value,
            "ordinal": self.ordinal,
            "namespace": self.namespace,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BNSymbol:
        addr = data.get("address", 0)
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)

        sym_type = data.get("type", "DataSymbol")
        try:
            sym_type = SymbolType(sym_type)
        except ValueError:
            sym_type = SymbolType.DATA

        return cls(
            address=addr,
            name=data.get("name", ""),
            full_name=data.get("full_name", ""),
            symbol_type=sym_type,
            ordinal=data.get("ordinal", 0),
            namespace=data.get("namespace", ""),
        )


@dataclass
class BNBasicBlock:
    """A basic block from Binary Ninja."""
    start: int
    end: int
    index: int = 0
    incoming_edges: list[int] = field(default_factory=list)
    outgoing_edges: list[int] = field(default_factory=list)
    is_exit: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "start": hex(self.start),
            "end": hex(self.end),
            "index": self.index,
            "incoming": [hex(e) for e in self.incoming_edges],
            "outgoing": [hex(e) for e in self.outgoing_edges],
            "is_exit": self.is_exit,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BNBasicBlock:
        def parse_addr(val):
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val

        def parse_edges(edges):
            return [parse_addr(e) for e in edges]

        return cls(
            start=parse_addr(data.get("start", 0)),
            end=parse_addr(data.get("end", 0)),
            index=data.get("index", 0),
            incoming_edges=parse_edges(data.get("incoming", [])),
            outgoing_edges=parse_edges(data.get("outgoing", [])),
            is_exit=data.get("is_exit", False),
        )


@dataclass
class BNFunction:
    """A function from Binary Ninja with IL information."""
    address: int
    name: str
    symbol: BNSymbol | None = None
    return_type: str = "void"
    calling_convention: str = ""
    parameters: list[tuple[str, str]] = field(default_factory=list)  # (type, name)
    stack_adjustment: int = 0
    is_thunk: bool = False
    is_pure: bool = False
    auto_discovered: bool = True
    basic_blocks: list[BNBasicBlock] = field(default_factory=list)

    # IL representations
    llil: list[str] = field(default_factory=list)
    mlil: list[str] = field(default_factory=list)
    hlil: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "name": self.name,
            "symbol": self.symbol.to_dict() if self.symbol else None,
            "return_type": self.return_type,
            "calling_convention": self.calling_convention,
            "parameters": self.parameters,
            "stack_adjustment": self.stack_adjustment,
            "is_thunk": self.is_thunk,
            "is_pure": self.is_pure,
            "auto_discovered": self.auto_discovered,
            "basic_blocks": [bb.to_dict() for bb in self.basic_blocks],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BNFunction:
        addr = data.get("address", 0)
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)

        symbol = None
        if data.get("symbol"):
            symbol = BNSymbol.from_dict(data["symbol"])

        basic_blocks = []
        for bb_data in data.get("basic_blocks", []):
            basic_blocks.append(BNBasicBlock.from_dict(bb_data))

        return cls(
            address=addr,
            name=data.get("name", ""),
            symbol=symbol,
            return_type=data.get("return_type", "void"),
            calling_convention=data.get("calling_convention", ""),
            parameters=data.get("parameters", []),
            stack_adjustment=data.get("stack_adjustment", 0),
            is_thunk=data.get("is_thunk", False),
            is_pure=data.get("is_pure", False),
            auto_discovered=data.get("auto_discovered", True),
            basic_blocks=basic_blocks,
            llil=data.get("llil", []),
            mlil=data.get("mlil", []),
            hlil=data.get("hlil", ""),
        )


@dataclass
class BNType:
    """A type from Binary Ninja."""
    name: str
    type_class: str = ""
    width: int = 0
    alignment: int = 1
    signed: bool = False
    const: bool = False
    volatile: bool = False
    pointer_suffix: str = ""
    members: list[tuple[str, str, int]] = field(default_factory=list)  # (name, type, offset)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "type_class": self.type_class,
            "width": self.width,
            "alignment": self.alignment,
            "signed": self.signed,
            "const": self.const,
            "volatile": self.volatile,
            "pointer_suffix": self.pointer_suffix,
            "members": self.members,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BNType:
        return cls(
            name=data.get("name", ""),
            type_class=data.get("type_class", ""),
            width=data.get("width", 0),
            alignment=data.get("alignment", 1),
            signed=data.get("signed", False),
            const=data.get("const", False),
            volatile=data.get("volatile", False),
            pointer_suffix=data.get("pointer_suffix", ""),
            members=data.get("members", []),
        )


@dataclass
class BinaryInfo:
    """Information about the binary."""
    filename: str
    arch: str = ""
    platform: str = ""
    start: int = 0
    end: int = 0
    entry_point: int = 0
    executable: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "filename": self.filename,
            "arch": self.arch,
            "platform": self.platform,
            "start": hex(self.start),
            "end": hex(self.end),
            "entry_point": hex(self.entry_point),
            "executable": self.executable,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BinaryInfo:
        def parse_addr(val):
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val or 0

        return cls(
            filename=data.get("filename", ""),
            arch=data.get("arch", ""),
            platform=data.get("platform", ""),
            start=parse_addr(data.get("start")),
            end=parse_addr(data.get("end")),
            entry_point=parse_addr(data.get("entry_point")),
            executable=data.get("executable", False),
        )


# ==================== Binary Ninja Bridge ====================

class BinaryNinjaBridge:
    """
    Bridge for communication with Binary Ninja.
    
    Provides:
    - Symbol and function import/export
    - IL access (LLIL, MLIL, HLIL)
    - Type management
    - Basic block analysis
    - Cross-reference tracking
    
    Can work with:
    - Direct BinaryView API (if binaryninja is installed)
    - RPC connection (for remote/headless)
    """

    DEFAULT_PORT = 31337

    def __init__(
        self,
        emulator: Emulator,
        bv: Any | None = None,  # BinaryView
        host: str = "localhost",
        port: int = DEFAULT_PORT,
    ):
        self._emulator = emulator
        self._bv = bv  # Direct BinaryView if available
        self._host = host
        self._port = port

        # RPC connection
        self._socket: socket.socket | None = None
        self._connected = False

        # Cached data
        self._binary_info: BinaryInfo | None = None
        self._symbols: dict[int, BNSymbol] = {}
        self._functions: dict[int, BNFunction] = {}
        self._types: dict[str, BNType] = {}

        # Check for direct API
        self._use_direct_api = bv is not None

    @property
    def connected(self) -> bool:
        """Check if connected."""
        return self._connected or self._use_direct_api

    @property
    def binary_info(self) -> BinaryInfo | None:
        """Get binary information."""
        return self._binary_info

    @property
    def symbols(self) -> dict[int, BNSymbol]:
        """Get cached symbols."""
        return self._symbols.copy()

    @property
    def functions(self) -> dict[int, BNFunction]:
        """Get cached functions."""
        return self._functions.copy()

    def connect(self, timeout: float = 5.0) -> bool:
        """Connect to Binary Ninja RPC server."""
        if self._use_direct_api:
            self._fetch_binary_info_direct()
            return True

        if self._connected:
            return True

        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.settimeout(timeout)
            self._socket.connect((self._host, self._port))

            # Ping to verify
            response = self._send_request(MessageType.PING, {})
            if response.get("status") != "ok":
                raise BNConnectionError("Failed to ping Binary Ninja")

            self._connected = True

            # Get binary info
            self._fetch_binary_info()

            logger.info(f"Connected to Binary Ninja at {self._host}:{self._port}")
            return True

        except OSError as e:
            self._cleanup()
            raise BNConnectionError(f"Failed to connect to Binary Ninja: {e}")

    def disconnect(self) -> None:
        """Disconnect from Binary Ninja."""
        self._cleanup()
        self._connected = False
        logger.info("Disconnected from Binary Ninja")

    def _cleanup(self) -> None:
        """Clean up resources."""
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._socket = None

    def _send_request(
        self,
        msg_type: MessageType,
        payload: dict[str, Any],
        timeout: float = 30.0
    ) -> dict[str, Any]:
        """Send RPC request."""
        if not self._socket:
            raise BNConnectionError("Not connected")

        request = {
            "type": msg_type.value,
            "data": payload,
        }
        request_bytes = json.dumps(request).encode('utf-8')

        length = struct.pack('>I', len(request_bytes))
        self._socket.sendall(length + request_bytes)

        self._socket.settimeout(timeout)
        try:
            length_bytes = self._recv_exact(4)
            if not length_bytes:
                raise BNProtocolError("Connection closed")

            response_length = struct.unpack('>I', length_bytes)[0]
            response_bytes = self._recv_exact(response_length)
            if not response_bytes:
                raise BNProtocolError("Incomplete response")

            return json.loads(response_bytes.decode('utf-8'))
        finally:
            self._socket.settimeout(None)

    def _recv_exact(self, size: int) -> bytes | None:
        """Receive exactly size bytes."""
        data = b''
        while len(data) < size:
            chunk = self._socket.recv(size - len(data))
            if not chunk:
                return None
            data += chunk
        return data

    def _fetch_binary_info(self) -> None:
        """Fetch binary info via RPC."""
        response = self._send_request(MessageType.GET_BINARY_INFO, {})
        if response.get("status") == "ok":
            self._binary_info = BinaryInfo.from_dict(response.get("data", {}))

    def _fetch_binary_info_direct(self) -> None:
        """Fetch binary info via direct API."""
        if not self._bv:
            return

        self._binary_info = BinaryInfo(
            filename=self._bv.file.filename,
            arch=self._bv.arch.name if self._bv.arch else "",
            platform=self._bv.platform.name if self._bv.platform else "",
            start=self._bv.start,
            end=self._bv.end,
            entry_point=self._bv.entry_point,
            executable=True,
        )

    # ==================== Symbol Management ====================

    def import_symbols(self, refresh: bool = False) -> dict[int, BNSymbol]:
        """Import symbols from Binary Ninja."""
        if self._symbols and not refresh:
            return self._symbols.copy()

        if self._use_direct_api:
            return self._import_symbols_direct()

        response = self._send_request(MessageType.GET_SYMBOLS, {})

        if response.get("status") == "ok":
            self._symbols.clear()
            for sym_data in response.get("data", {}).get("symbols", []):
                sym = BNSymbol.from_dict(sym_data)
                self._symbols[sym.address] = sym
                self._emulator.add_symbol(sym.address, sym.name)

        return self._symbols.copy()

    def _import_symbols_direct(self) -> dict[int, BNSymbol]:
        """Import symbols via direct API."""
        self._symbols.clear()

        if not self._bv:
            return self._symbols

        for sym in self._bv.get_symbols():
            bn_sym = BNSymbol(
                address=sym.address,
                name=sym.short_name,
                full_name=sym.full_name,
                symbol_type=SymbolType(sym.type.name) if hasattr(sym.type, 'name') else SymbolType.DATA,
                ordinal=sym.ordinal,
                namespace=str(sym.namespace) if sym.namespace else "",
            )
            self._symbols[sym.address] = bn_sym
            self._emulator.add_symbol(sym.address, sym.short_name)

        return self._symbols.copy()

    def get_symbol(self, address: int) -> BNSymbol | None:
        """Get symbol at address."""
        return self._symbols.get(address)

    def get_symbol_by_name(self, name: str) -> BNSymbol | None:
        """Get symbol by name."""
        for sym in self._symbols.values():
            if sym.name == name or sym.full_name == name:
                return sym
        return None

    def set_symbol(self, address: int, name: str) -> bool:
        """Define a symbol."""
        if self._use_direct_api:
            if self._bv:
                self._bv.define_user_symbol(
                    self._bv.symbol_at(address).__class__(
                        SymbolType.DATA.value, address, name
                    )
                )
                self._symbols[address] = BNSymbol(address, name)
                return True
            return False

        response = self._send_request(MessageType.SET_SYMBOL, {
            "address": hex(address),
            "name": name,
        })

        if response.get("status") == "ok":
            self._symbols[address] = BNSymbol(address, name)
            return True
        return False

    # ==================== Function Management ====================

    def import_functions(self, refresh: bool = False) -> dict[int, BNFunction]:
        """Import functions from Binary Ninja."""
        if self._functions and not refresh:
            return self._functions.copy()

        if self._use_direct_api:
            return self._import_functions_direct()

        response = self._send_request(MessageType.GET_FUNCTIONS, {})

        if response.get("status") == "ok":
            self._functions.clear()
            for func_data in response.get("data", {}).get("functions", []):
                func = BNFunction.from_dict(func_data)
                self._functions[func.address] = func

        return self._functions.copy()

    def _import_functions_direct(self) -> dict[int, BNFunction]:
        """Import functions via direct API."""
        self._functions.clear()

        if not self._bv:
            return self._functions

        for func in self._bv.functions:
            params = []
            if func.parameter_vars:
                for p in func.parameter_vars:
                    params.append((str(p.type), p.name))

            basic_blocks = []
            for bb in func.basic_blocks:
                basic_blocks.append(BNBasicBlock(
                    start=bb.start,
                    end=bb.end,
                    index=bb.index,
                    incoming_edges=[e.source.start for e in bb.incoming_edges],
                    outgoing_edges=[e.target.start for e in bb.outgoing_edges],
                ))

            bn_func = BNFunction(
                address=func.start,
                name=func.name,
                return_type=str(func.return_type),
                calling_convention=func.calling_convention.name if func.calling_convention else "",
                parameters=params,
                is_thunk=func.is_thunk,
                is_pure=func.is_pure,
                basic_blocks=basic_blocks,
            )
            self._functions[func.start] = bn_func

        return self._functions.copy()

    def get_function(self, address: int) -> BNFunction | None:
        """Get function containing address."""
        for func in self._functions.values():
            for bb in func.basic_blocks:
                if bb.start <= address < bb.end:
                    return func
        return None

    def get_function_at(self, address: int) -> BNFunction | None:
        """Get function at address."""
        return self._functions.get(address)

    def create_function(self, address: int) -> bool:
        """Create a function at address."""
        if self._use_direct_api:
            if self._bv:
                self._bv.create_user_function(address)
                return True
            return False

        response = self._send_request(MessageType.CREATE_FUNCTION, {
            "address": hex(address),
        })
        return response.get("status") == "ok"

    # ==================== IL Access ====================

    def get_llil(self, address: int) -> list[str]:
        """Get Low Level IL for function at address."""
        return self._get_il(address, ILType.LLIL)

    def get_mlil(self, address: int) -> list[str]:
        """Get Medium Level IL for function at address."""
        return self._get_il(address, ILType.MLIL)

    def get_hlil(self, address: int) -> str:
        """Get High Level IL (decompiled) for function at address."""
        il = self._get_il(address, ILType.HLIL)
        return "\n".join(il) if il else ""

    def _get_il(self, address: int, il_type: ILType) -> list[str]:
        """Get IL at address."""
        if self._use_direct_api:
            return self._get_il_direct(address, il_type)

        response = self._send_request(MessageType.GET_IL, {
            "address": hex(address),
            "il_type": il_type.value,
        })

        if response.get("status") == "ok":
            return response.get("data", {}).get("il", [])
        return []

    def _get_il_direct(self, address: int, il_type: ILType) -> list[str]:
        """Get IL via direct API."""
        if not self._bv:
            return []

        funcs = self._bv.get_functions_containing(address)
        if not funcs:
            return []

        func = funcs[0]

        if il_type == ILType.LLIL:
            if func.low_level_il:
                return [str(instr) for instr in func.low_level_il.instructions]
        elif il_type == ILType.MLIL:
            if func.medium_level_il:
                return [str(instr) for instr in func.medium_level_il.instructions]
        elif il_type == ILType.HLIL:
            if func.high_level_il:
                return [str(instr) for instr in func.high_level_il.root.lines]

        return []

    # ==================== Basic Blocks ====================

    def get_basic_blocks(self, address: int) -> list[BNBasicBlock]:
        """Get basic blocks for function at address."""
        if self._use_direct_api:
            return self._get_basic_blocks_direct(address)

        response = self._send_request(MessageType.GET_BASIC_BLOCKS, {
            "address": hex(address),
        })

        if response.get("status") == "ok":
            blocks = []
            for bb_data in response.get("data", {}).get("basic_blocks", []):
                blocks.append(BNBasicBlock.from_dict(bb_data))
            return blocks
        return []

    def _get_basic_blocks_direct(self, address: int) -> list[BNBasicBlock]:
        """Get basic blocks via direct API."""
        if not self._bv:
            return []

        funcs = self._bv.get_functions_containing(address)
        if not funcs:
            return []

        func = funcs[0]
        blocks = []
        for bb in func.basic_blocks:
            blocks.append(BNBasicBlock(
                start=bb.start,
                end=bb.end,
                index=bb.index,
                incoming_edges=[e.source.start for e in bb.incoming_edges],
                outgoing_edges=[e.target.start for e in bb.outgoing_edges],
            ))
        return blocks

    # ==================== Cross References ====================

    def get_xrefs_to(self, address: int) -> list[tuple[int, str]]:
        """Get cross-references to an address."""
        if self._use_direct_api:
            return self._get_xrefs_to_direct(address)

        response = self._send_request(MessageType.GET_XREFS, {
            "address": hex(address),
            "direction": "to",
        })

        if response.get("status") == "ok":
            xrefs = []
            for xref in response.get("data", {}).get("xrefs", []):
                addr = xref.get("address", 0)
                if isinstance(addr, str):
                    addr = int(addr, 16)
                xrefs.append((addr, xref.get("type", "")))
            return xrefs
        return []

    def _get_xrefs_to_direct(self, address: int) -> list[tuple[int, str]]:
        """Get xrefs via direct API."""
        if not self._bv:
            return []

        xrefs = []
        for ref in self._bv.get_code_refs(address):
            xrefs.append((ref.address, "code"))
        for ref in self._bv.get_data_refs(address):
            xrefs.append((ref, "data"))
        return xrefs

    def get_xrefs_from(self, address: int) -> list[tuple[int, str]]:
        """Get cross-references from an address."""
        if self._use_direct_api:
            return self._get_xrefs_from_direct(address)

        response = self._send_request(MessageType.GET_XREFS, {
            "address": hex(address),
            "direction": "from",
        })

        if response.get("status") == "ok":
            xrefs = []
            for xref in response.get("data", {}).get("xrefs", []):
                addr = xref.get("address", 0)
                if isinstance(addr, str):
                    addr = int(addr, 16)
                xrefs.append((addr, xref.get("type", "")))
            return xrefs
        return []

    def _get_xrefs_from_direct(self, address: int) -> list[tuple[int, str]]:
        """Get xrefs from via direct API."""
        if not self._bv:
            return []

        xrefs = []
        for ref in self._bv.get_code_refs_from(address):
            xrefs.append((ref, "code"))
        for ref in self._bv.get_data_refs_from(address):
            xrefs.append((ref, "data"))
        return xrefs

    # ==================== Types ====================

    def import_types(self, refresh: bool = False) -> dict[str, BNType]:
        """Import types from Binary Ninja."""
        if self._types and not refresh:
            return self._types.copy()

        if self._use_direct_api:
            return self._import_types_direct()

        response = self._send_request(MessageType.GET_TYPES, {})

        if response.get("status") == "ok":
            self._types.clear()
            for type_data in response.get("data", {}).get("types", []):
                t = BNType.from_dict(type_data)
                self._types[t.name] = t

        return self._types.copy()

    def _import_types_direct(self) -> dict[str, BNType]:
        """Import types via direct API."""
        self._types.clear()

        if not self._bv:
            return self._types

        for name, t in self._bv.types.items():
            bn_type = BNType(
                name=str(name),
                type_class=t.type_class.name if hasattr(t.type_class, 'name') else str(t.type_class),
                width=t.width,
                alignment=t.alignment,
                signed=getattr(t, 'signed', False),
                const=getattr(t, 'const', False),
            )
            self._types[str(name)] = bn_type

        return self._types.copy()

    def get_type(self, name: str) -> BNType | None:
        """Get type by name."""
        return self._types.get(name)

    # ==================== Memory ====================

    def read_memory(self, address: int, size: int) -> bytes | None:
        """Read memory from Binary Ninja's binary view."""
        if self._use_direct_api:
            if self._bv:
                return self._bv.read(address, size)
            return None

        response = self._send_request(MessageType.GET_MEMORY, {
            "address": hex(address),
            "size": size,
        })

        if response.get("status") == "ok":
            data = response.get("data", {}).get("bytes", "")
            return bytes.fromhex(data)
        return None

    # ==================== Comments ====================

    def set_comment(self, address: int, comment: str) -> bool:
        """Set a comment at address."""
        if self._use_direct_api:
            if self._bv:
                self._bv.set_comment_at(address, comment)
                return True
            return False

        response = self._send_request(MessageType.SET_COMMENT, {
            "address": hex(address),
            "comment": comment,
        })
        return response.get("status") == "ok"

    # ==================== Navigation ====================

    def highlight(self, address: int, color: str = "yellow") -> bool:
        """Highlight address in Binary Ninja."""
        if self._use_direct_api:
            # Direct API highlight requires UI context
            return False

        response = self._send_request(MessageType.HIGHLIGHT, {
            "address": hex(address),
            "color": color,
        })
        return response.get("status") == "ok"

    def goto(self, address: int) -> bool:
        """Navigate to address in Binary Ninja."""
        if self._use_direct_api:
            # Direct API navigation requires UI context
            return False

        response = self._send_request(MessageType.GOTO, {
            "address": hex(address),
        })
        return response.get("status") == "ok"

    # ==================== Full Sync ====================

    def full_sync(self) -> bool:
        """Import all data from Binary Ninja."""
        try:
            self.import_symbols(refresh=True)
            self.import_functions(refresh=True)
            self.import_types(refresh=True)
            return True
        except Exception as e:
            logger.error(f"Full sync failed: {e}")
            return False

    # ==================== Export/Import ====================

    def export_to_json(self, path: str | Path) -> None:
        """Export all data to JSON file."""
        data = {
            "binary_info": self._binary_info.to_dict() if self._binary_info else {},
            "symbols": [s.to_dict() for s in self._symbols.values()],
            "functions": [f.to_dict() for f in self._functions.values()],
            "types": [t.to_dict() for t in self._types.values()],
        }

        path = Path(path)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)

    def import_from_json(self, path: str | Path) -> None:
        """Import data from JSON file."""
        path = Path(path)
        with open(path) as f:
            data = json.load(f)

        if data.get("binary_info"):
            self._binary_info = BinaryInfo.from_dict(data["binary_info"])

        self._symbols.clear()
        for sym_data in data.get("symbols", []):
            sym = BNSymbol.from_dict(sym_data)
            self._symbols[sym.address] = sym

        self._functions.clear()
        for func_data in data.get("functions", []):
            func = BNFunction.from_dict(func_data)
            self._functions[func.address] = func

        self._types.clear()
        for type_data in data.get("types", []):
            t = BNType.from_dict(type_data)
            self._types[t.name] = t

    def __enter__(self) -> BinaryNinjaBridge:
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    def __repr__(self) -> str:
        if self._use_direct_api:
            prog = self._binary_info.filename if self._binary_info else "unknown"
            return f"BinaryNinjaBridge(direct, program={prog})"
        status = "connected" if self._connected else "disconnected"
        return f"BinaryNinjaBridge({self._host}:{self._port}, {status})"


# ==================== Factory Function ====================

def create_binja_bridge(
    emulator: Emulator,
    bv: Any | None = None,
    host: str = "localhost",
    port: int = BinaryNinjaBridge.DEFAULT_PORT,
    auto_connect: bool = False,
) -> BinaryNinjaBridge:
    """
    Create a Binary Ninja bridge instance.
    
    Args:
        emulator: Emulator instance
        bv: BinaryView for direct API (optional)
        host: RPC server host
        port: RPC server port
        auto_connect: Automatically connect
        
    Returns:
        BinaryNinjaBridge instance
    """
    bridge = BinaryNinjaBridge(emulator, bv, host, port)
    if auto_connect:
        bridge.connect()
    return bridge
