"""
Integrations Package - Connect PyUniDbg with external reverse engineering tools.

This package provides bridges to popular reverse engineering tools:
- IDA Pro
- Ghidra
- Binary Ninja
- radare2/rizin

Each integration provides:
- Synchronization of analysis data
- Remote debugging capabilities
- Export/import of annotations, comments, and symbols
- Bi-directional communication
"""

from __future__ import annotations

__all__ = [
    # IDA Pro
    "IDABridge",
    "IDASymbol",
    "IDAFunction",
    "IDAComment",
    "IDABreakpoint",
    "IDASegment",
    "IDAConnectionError",
    "IDAProtocolError",
    "IDATimeoutError",
    "create_ida_bridge",

    # Ghidra
    "GhidraBridge",
    "GhidraSymbol",
    "GhidraFunction",
    "GhidraDataType",
    "GhidraReference",
    "GhidraConnectionError",
    "GhidraProtocolError",
    "create_ghidra_bridge",

    # Binary Ninja
    "BinaryNinjaBridge",
    "BNSymbol",
    "BNFunction",
    "BNType",
    "BNBasicBlock",
    "BNConnectionError",
    "BNProtocolError",
    "create_binja_bridge",

    # radare2/rizin
    "RadareBridge",
    "R2Symbol",
    "R2Function",
    "R2XRef",
    "R2BasicBlock",
    "R2Section",
    "R2ConnectionError",
    "R2CommandError",
    "create_radare_bridge",
]


# Lazy imports to avoid loading heavy dependencies
def __getattr__(name: str):
    # IDA Pro
    if name in ("IDABridge", "IDASymbol", "IDAFunction", "IDAComment",
                "IDABreakpoint", "IDASegment", "IDAConnectionError",
                "IDAProtocolError", "IDATimeoutError", "create_ida_bridge"):
        from . import ida
        return getattr(ida, name)

    # Ghidra
    elif name in ("GhidraBridge", "GhidraSymbol", "GhidraFunction",
                  "GhidraDataType", "GhidraReference",
                  "GhidraConnectionError", "GhidraProtocolError",
                  "create_ghidra_bridge"):
        from . import ghidra
        return getattr(ghidra, name)

    # Binary Ninja
    elif name in ("BinaryNinjaBridge", "BNSymbol", "BNFunction", "BNType",
                  "BNBasicBlock", "BNConnectionError", "BNProtocolError",
                  "create_binja_bridge"):
        from . import binja
        return getattr(binja, name)

    # radare2/rizin
    elif name in ("RadareBridge", "R2Symbol", "R2Function", "R2XRef",
                  "R2BasicBlock", "R2Section", "R2ConnectionError",
                  "R2CommandError", "create_radare_bridge"):
        from . import radare
        return getattr(radare, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
