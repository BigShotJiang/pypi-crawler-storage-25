"""
Ghidra Bridge - Integrate PyUniDbg with Ghidra reverse engineering framework.

Provides bidirectional communication with Ghidra for:
- Syncing symbols, comments, and function definitions
- Program analysis data sharing
- Memory and disassembly synchronization
- Decompiler output integration

Uses Ghidra's Python scripting interface (via Ghidrathon or pyhidra).

Usage:
    from pyunidbg.integrations import GhidraBridge
    
    # Connect to Ghidra
    bridge = GhidraBridge(emulator, host="localhost", port=18001)
    bridge.connect()
    
    # Import program data
    bridge.import_symbols()
    bridge.import_functions()
    
    # Get decompiled code
    decomp = bridge.decompile(0x1000)
"""

from __future__ import annotations

import json
import logging
import socket
import struct
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

from pyunidbg.errors import IntegrationConnectionError, IntegrationProtocolError

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    "GhidraBridge",
    "GhidraSymbol",
    "GhidraFunction",
    "GhidraDataType",
    "GhidraReference",
    "GhidraConnectionError",
    "GhidraProtocolError",
    "create_ghidra_bridge",
]

logger = logging.getLogger(__name__)


# ==================== Exceptions ====================

class GhidraConnectionError(IntegrationConnectionError):
    """Error connecting to Ghidra."""


class GhidraProtocolError(IntegrationProtocolError):
    """Error in Ghidra communication protocol."""


# ==================== Enums ====================

class MessageType(Enum):
    """Ghidra bridge message types."""
    # Requests
    PING = "ping"
    GET_PROGRAM_INFO = "get_program_info"
    GET_SYMBOLS = "get_symbols"
    GET_FUNCTIONS = "get_functions"
    GET_DATA_TYPES = "get_data_types"
    GET_MEMORY = "get_memory"
    GET_REFERENCES = "get_references"
    GET_DECOMPILE = "get_decompile"
    GET_DISASSEMBLY = "get_disassembly"

    # Commands
    SET_SYMBOL = "set_symbol"
    SET_COMMENT = "set_comment"
    CREATE_FUNCTION = "create_function"
    SET_DATA_TYPE = "set_data_type"
    HIGHLIGHT = "highlight"
    GOTO = "goto"


class SymbolType(Enum):
    """Types of Ghidra symbols."""
    FUNCTION = "function"
    LABEL = "label"
    CLASS = "class"
    PARAMETER = "parameter"
    LOCAL_VAR = "local_var"
    GLOBAL_VAR = "global_var"
    NAMESPACE = "namespace"


class RefType(Enum):
    """Reference types."""
    CALL = "call"
    JUMP = "jump"
    DATA = "data"
    READ = "read"
    WRITE = "write"
    PARAM = "param"


# ==================== Data Classes ====================

@dataclass
class GhidraSymbol:
    """A symbol from Ghidra."""
    address: int
    name: str
    namespace: str = ""
    symbol_type: SymbolType = SymbolType.LABEL
    is_primary: bool = True
    source: str = "USER_DEFINED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "name": self.name,
            "namespace": self.namespace,
            "type": self.symbol_type.value,
            "is_primary": self.is_primary,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GhidraSymbol:
        addr = data.get("address", 0)
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)
        return cls(
            address=addr,
            name=data.get("name", ""),
            namespace=data.get("namespace", ""),
            symbol_type=SymbolType(data.get("type", "label")),
            is_primary=data.get("is_primary", True),
            source=data.get("source", "USER_DEFINED"),
        )


@dataclass
class GhidraFunction:
    """A function from Ghidra with full decompilation info."""
    address: int
    name: str
    signature: str = ""
    return_type: str = "undefined"
    calling_convention: str = "unknown"
    parameters: list[tuple[str, str]] = field(default_factory=list)  # (type, name)
    local_vars: list[tuple[str, str, int]] = field(default_factory=list)  # (type, name, offset)
    stack_frame_size: int = 0
    is_thunk: bool = False
    thunk_address: int | None = None
    body_start: int = 0
    body_end: int = 0

    # Decompilation
    decompiled_code: str = ""
    high_pcode: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "name": self.name,
            "signature": self.signature,
            "return_type": self.return_type,
            "calling_convention": self.calling_convention,
            "parameters": self.parameters,
            "local_vars": self.local_vars,
            "stack_frame_size": self.stack_frame_size,
            "is_thunk": self.is_thunk,
            "thunk_address": hex(self.thunk_address) if self.thunk_address else None,
            "body_start": hex(self.body_start),
            "body_end": hex(self.body_end),
            "decompiled_code": self.decompiled_code,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GhidraFunction:
        def parse_addr(val):
            if val is None:
                return 0
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val

        return cls(
            address=parse_addr(data.get("address")),
            name=data.get("name", ""),
            signature=data.get("signature", ""),
            return_type=data.get("return_type", "undefined"),
            calling_convention=data.get("calling_convention", "unknown"),
            parameters=data.get("parameters", []),
            local_vars=data.get("local_vars", []),
            stack_frame_size=data.get("stack_frame_size", 0),
            is_thunk=data.get("is_thunk", False),
            thunk_address=parse_addr(data.get("thunk_address")),
            body_start=parse_addr(data.get("body_start")),
            body_end=parse_addr(data.get("body_end")),
            decompiled_code=data.get("decompiled_code", ""),
            high_pcode=data.get("high_pcode", []),
        )


@dataclass
class GhidraDataType:
    """A data type from Ghidra."""
    name: str
    category: str = ""
    size: int = 0
    alignment: int = 1
    description: str = ""
    is_pointer: bool = False
    is_array: bool = False
    is_structure: bool = False
    is_union: bool = False
    is_enum: bool = False
    members: list[tuple[str, str, int]] = field(default_factory=list)  # (name, type, offset)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "category": self.category,
            "size": self.size,
            "alignment": self.alignment,
            "description": self.description,
            "is_pointer": self.is_pointer,
            "is_array": self.is_array,
            "is_structure": self.is_structure,
            "is_union": self.is_union,
            "is_enum": self.is_enum,
            "members": self.members,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GhidraDataType:
        return cls(
            name=data.get("name", ""),
            category=data.get("category", ""),
            size=data.get("size", 0),
            alignment=data.get("alignment", 1),
            description=data.get("description", ""),
            is_pointer=data.get("is_pointer", False),
            is_array=data.get("is_array", False),
            is_structure=data.get("is_structure", False),
            is_union=data.get("is_union", False),
            is_enum=data.get("is_enum", False),
            members=data.get("members", []),
        )


@dataclass
class GhidraReference:
    """A cross-reference from Ghidra."""
    from_address: int
    to_address: int
    ref_type: RefType
    is_primary: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "from": hex(self.from_address),
            "to": hex(self.to_address),
            "type": self.ref_type.value,
            "is_primary": self.is_primary,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GhidraReference:
        def parse_addr(val):
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val

        return cls(
            from_address=parse_addr(data.get("from", 0)),
            to_address=parse_addr(data.get("to", 0)),
            ref_type=RefType(data.get("type", "data")),
            is_primary=data.get("is_primary", True),
        )


@dataclass
class ProgramInfo:
    """Information about the Ghidra program."""
    name: str
    path: str = ""
    language: str = ""
    compiler: str = ""
    image_base: int = 0
    min_address: int = 0
    max_address: int = 0
    executable_format: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "path": self.path,
            "language": self.language,
            "compiler": self.compiler,
            "image_base": hex(self.image_base),
            "min_address": hex(self.min_address),
            "max_address": hex(self.max_address),
            "executable_format": self.executable_format,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProgramInfo:
        def parse_addr(val):
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val or 0

        return cls(
            name=data.get("name", ""),
            path=data.get("path", ""),
            language=data.get("language", ""),
            compiler=data.get("compiler", ""),
            image_base=parse_addr(data.get("image_base")),
            min_address=parse_addr(data.get("min_address")),
            max_address=parse_addr(data.get("max_address")),
            executable_format=data.get("executable_format", ""),
        )


# ==================== Ghidra Bridge ====================

class GhidraBridge:
    """
    Bridge for communication with Ghidra.
    
    Provides:
    - Symbol and function import/export
    - Decompilation access
    - Data type management
    - Cross-reference analysis
    - Memory synchronization
    
    Requires a PyUniDbg Ghidra script to be running.
    """

    DEFAULT_PORT = 18001

    def __init__(
        self,
        emulator: Emulator,
        host: str = "localhost",
        port: int = DEFAULT_PORT,
    ):
        self._emulator = emulator
        self._host = host
        self._port = port

        self._socket: socket.socket | None = None
        self._connected = False

        # Cached data
        self._program_info: ProgramInfo | None = None
        self._symbols: dict[int, GhidraSymbol] = {}
        self._functions: dict[int, GhidraFunction] = {}
        self._data_types: dict[str, GhidraDataType] = {}
        self._references: dict[int, list[GhidraReference]] = defaultdict(list)

    @property
    def connected(self) -> bool:
        """Check if connected to Ghidra."""
        return self._connected

    @property
    def program_info(self) -> ProgramInfo | None:
        """Get program information."""
        return self._program_info

    @property
    def symbols(self) -> dict[int, GhidraSymbol]:
        """Get cached symbols."""
        return self._symbols.copy()

    @property
    def functions(self) -> dict[int, GhidraFunction]:
        """Get cached functions."""
        return self._functions.copy()

    def connect(self, timeout: float = 5.0) -> bool:
        """Connect to Ghidra."""
        if self._connected:
            return True

        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.settimeout(timeout)
            self._socket.connect((self._host, self._port))

            # Ping to verify
            response = self._send_request(MessageType.PING, {})
            if response.get("status") != "ok":
                raise GhidraConnectionError("Failed to ping Ghidra")

            self._connected = True

            # Get program info
            self._fetch_program_info()

            logger.info(f"Connected to Ghidra at {self._host}:{self._port}")
            return True

        except OSError as e:
            self._cleanup()
            raise GhidraConnectionError(f"Failed to connect to Ghidra: {e}")

    def disconnect(self) -> None:
        """Disconnect from Ghidra."""
        self._cleanup()
        self._connected = False
        logger.info("Disconnected from Ghidra")

    def _cleanup(self) -> None:
        """Clean up resources."""
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._socket = None

    def _send_request(
        self,
        msg_type: MessageType,
        payload: dict[str, Any],
        timeout: float = 30.0
    ) -> dict[str, Any]:
        """Send request and wait for response."""
        if not self._socket:
            raise GhidraConnectionError("Not connected")

        # Build request
        request = {
            "type": msg_type.value,
            "data": payload,
        }
        request_bytes = json.dumps(request).encode('utf-8')

        # Send length + data
        length = struct.pack('>I', len(request_bytes))
        self._socket.sendall(length + request_bytes)

        # Receive response
        self._socket.settimeout(timeout)
        try:
            # Read length
            length_bytes = self._recv_exact(4)
            if not length_bytes:
                raise GhidraProtocolError("Connection closed")

            response_length = struct.unpack('>I', length_bytes)[0]

            # Read response
            response_bytes = self._recv_exact(response_length)
            if not response_bytes:
                raise GhidraProtocolError("Incomplete response")

            return json.loads(response_bytes.decode('utf-8'))

        finally:
            self._socket.settimeout(None)

    def _recv_exact(self, size: int) -> bytes | None:
        """Receive exactly size bytes."""
        data = b''
        while len(data) < size:
            chunk = self._socket.recv(size - len(data))
            if not chunk:
                return None
            data += chunk
        return data

    def _fetch_program_info(self) -> None:
        """Fetch program information from Ghidra."""
        response = self._send_request(MessageType.GET_PROGRAM_INFO, {})
        if response.get("status") == "ok":
            self._program_info = ProgramInfo.from_dict(response.get("data", {}))

    # ==================== Symbol Management ====================

    def import_symbols(self, refresh: bool = False) -> dict[int, GhidraSymbol]:
        """Import symbols from Ghidra."""
        if self._symbols and not refresh:
            return self._symbols.copy()

        response = self._send_request(MessageType.GET_SYMBOLS, {})

        if response.get("status") == "ok":
            self._symbols.clear()
            for sym_data in response.get("data", {}).get("symbols", []):
                sym = GhidraSymbol.from_dict(sym_data)
                self._symbols[sym.address] = sym

                # Apply to emulator
                self._emulator.add_symbol(sym.address, sym.name)

        return self._symbols.copy()

    def set_symbol(self, address: int, name: str, namespace: str = "") -> bool:
        """Set a symbol in Ghidra."""
        response = self._send_request(MessageType.SET_SYMBOL, {
            "address": hex(address),
            "name": name,
            "namespace": namespace,
        })

        if response.get("status") == "ok":
            self._symbols[address] = GhidraSymbol(address, name, namespace)
            return True
        return False

    def get_symbol(self, address: int) -> GhidraSymbol | None:
        """Get symbol at address."""
        return self._symbols.get(address)

    def get_symbol_by_name(self, name: str) -> GhidraSymbol | None:
        """Get symbol by name."""
        for sym in self._symbols.values():
            if sym.name == name:
                return sym
        return None

    # ==================== Function Management ====================

    def import_functions(self, refresh: bool = False) -> dict[int, GhidraFunction]:
        """Import functions from Ghidra."""
        if self._functions and not refresh:
            return self._functions.copy()

        response = self._send_request(MessageType.GET_FUNCTIONS, {})

        if response.get("status") == "ok":
            self._functions.clear()
            for func_data in response.get("data", {}).get("functions", []):
                func = GhidraFunction.from_dict(func_data)
                self._functions[func.address] = func

        return self._functions.copy()

    def get_function(self, address: int) -> GhidraFunction | None:
        """Get function containing address."""
        for func in self._functions.values():
            if func.body_start <= address < func.body_end:
                return func
        return None

    def get_function_at(self, address: int) -> GhidraFunction | None:
        """Get function starting at address."""
        return self._functions.get(address)

    def create_function(self, address: int, name: str | None = None) -> bool:
        """Create a function in Ghidra."""
        response = self._send_request(MessageType.CREATE_FUNCTION, {
            "address": hex(address),
            "name": name,
        })
        return response.get("status") == "ok"

    # ==================== Decompilation ====================

    def decompile(self, address: int, timeout: float = 60.0) -> str | None:
        """
        Get decompiled code for function at address.
        
        Args:
            address: Address within function to decompile
            timeout: Decompilation timeout
            
        Returns:
            Decompiled C code or None
        """
        response = self._send_request(MessageType.GET_DECOMPILE, {
            "address": hex(address),
        }, timeout=timeout)

        if response.get("status") == "ok":
            data = response.get("data", {})
            code = data.get("code", "")

            # Update cached function
            func_addr = data.get("function_address")
            if func_addr and func_addr in self._functions:
                self._functions[func_addr].decompiled_code = code

            return code
        return None

    def get_high_pcode(self, address: int) -> list[str]:
        """Get high P-code for function."""
        response = self._send_request(MessageType.GET_DECOMPILE, {
            "address": hex(address),
            "include_pcode": True,
        })

        if response.get("status") == "ok":
            return response.get("data", {}).get("high_pcode", [])
        return []

    # ==================== Disassembly ====================

    def disassemble(self, address: int, count: int = 10) -> list[tuple[int, str, str]]:
        """
        Get disassembly at address.
        
        Returns:
            List of (address, bytes_hex, mnemonic)
        """
        response = self._send_request(MessageType.GET_DISASSEMBLY, {
            "address": hex(address),
            "count": count,
        })

        if response.get("status") == "ok":
            result = []
            for insn in response.get("data", {}).get("instructions", []):
                addr = insn.get("address")
                if isinstance(addr, str):
                    addr = int(addr, 16)
                result.append((
                    addr,
                    insn.get("bytes", ""),
                    insn.get("mnemonic", ""),
                ))
            return result
        return []

    # ==================== Data Types ====================

    def import_data_types(self, refresh: bool = False) -> dict[str, GhidraDataType]:
        """Import data types from Ghidra."""
        if self._data_types and not refresh:
            return self._data_types.copy()

        response = self._send_request(MessageType.GET_DATA_TYPES, {})

        if response.get("status") == "ok":
            self._data_types.clear()
            for dt_data in response.get("data", {}).get("data_types", []):
                dt = GhidraDataType.from_dict(dt_data)
                self._data_types[dt.name] = dt

        return self._data_types.copy()

    def get_data_type(self, name: str) -> GhidraDataType | None:
        """Get data type by name."""
        return self._data_types.get(name)

    def set_data_type(self, address: int, type_name: str) -> bool:
        """Apply a data type at address."""
        response = self._send_request(MessageType.SET_DATA_TYPE, {
            "address": hex(address),
            "type": type_name,
        })
        return response.get("status") == "ok"

    # ==================== References ====================

    def get_references_from(self, address: int) -> list[GhidraReference]:
        """Get references from an address."""
        response = self._send_request(MessageType.GET_REFERENCES, {
            "address": hex(address),
            "direction": "from",
        })

        if response.get("status") == "ok":
            refs = []
            for ref_data in response.get("data", {}).get("references", []):
                refs.append(GhidraReference.from_dict(ref_data))
            return refs
        return []

    def get_references_to(self, address: int) -> list[GhidraReference]:
        """Get references to an address."""
        response = self._send_request(MessageType.GET_REFERENCES, {
            "address": hex(address),
            "direction": "to",
        })

        if response.get("status") == "ok":
            refs = []
            for ref_data in response.get("data", {}).get("references", []):
                refs.append(GhidraReference.from_dict(ref_data))
            return refs
        return []

    # ==================== Memory ====================

    def read_memory(self, address: int, size: int) -> bytes | None:
        """Read memory from Ghidra's program."""
        response = self._send_request(MessageType.GET_MEMORY, {
            "address": hex(address),
            "size": size,
        })

        if response.get("status") == "ok":
            data = response.get("data", {}).get("bytes", "")
            return bytes.fromhex(data)
        return None

    # ==================== Comments ====================

    def set_comment(
        self,
        address: int,
        comment: str,
        comment_type: str = "EOL"
    ) -> bool:
        """
        Set a comment in Ghidra.
        
        Args:
            address: Address for comment
            comment: Comment text
            comment_type: EOL, PRE, POST, PLATE, REPEATABLE
        """
        response = self._send_request(MessageType.SET_COMMENT, {
            "address": hex(address),
            "comment": comment,
            "type": comment_type,
        })
        return response.get("status") == "ok"

    # ==================== Navigation ====================

    def highlight(self, address: int, color: str = "YELLOW") -> bool:
        """Highlight an address in Ghidra."""
        response = self._send_request(MessageType.HIGHLIGHT, {
            "address": hex(address),
            "color": color,
        })
        return response.get("status") == "ok"

    def goto(self, address: int) -> bool:
        """Navigate to address in Ghidra."""
        response = self._send_request(MessageType.GOTO, {
            "address": hex(address),
        })
        return response.get("status") == "ok"

    # ==================== Full Sync ====================

    def full_sync(self) -> bool:
        """Import all data from Ghidra."""
        try:
            self.import_symbols(refresh=True)
            self.import_functions(refresh=True)
            self.import_data_types(refresh=True)
            return True
        except Exception as e:
            logger.error(f"Full sync failed: {e}")
            return False

    # ==================== Export/Import ====================

    def export_to_json(self, path: str | Path) -> None:
        """Export all Ghidra data to JSON file."""
        data = {
            "program_info": self._program_info.to_dict() if self._program_info else {},
            "symbols": [s.to_dict() for s in self._symbols.values()],
            "functions": [f.to_dict() for f in self._functions.values()],
            "data_types": [dt.to_dict() for dt in self._data_types.values()],
        }

        path = Path(path)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)

    def import_from_json(self, path: str | Path) -> None:
        """Import data from JSON file."""
        path = Path(path)
        with open(path) as f:
            data = json.load(f)

        if data.get("program_info"):
            self._program_info = ProgramInfo.from_dict(data["program_info"])

        self._symbols.clear()
        for sym_data in data.get("symbols", []):
            sym = GhidraSymbol.from_dict(sym_data)
            self._symbols[sym.address] = sym

        self._functions.clear()
        for func_data in data.get("functions", []):
            func = GhidraFunction.from_dict(func_data)
            self._functions[func.address] = func

        self._data_types.clear()
        for dt_data in data.get("data_types", []):
            dt = GhidraDataType.from_dict(dt_data)
            self._data_types[dt.name] = dt

    def __enter__(self) -> GhidraBridge:
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    def __repr__(self) -> str:
        status = "connected" if self._connected else "disconnected"
        prog = self._program_info.name if self._program_info else "unknown"
        return f"GhidraBridge({self._host}:{self._port}, {status}, program={prog})"


# ==================== Factory Function ====================

def create_ghidra_bridge(
    emulator: Emulator,
    host: str = "localhost",
    port: int = GhidraBridge.DEFAULT_PORT,
    auto_connect: bool = False,
) -> GhidraBridge:
    """
    Create a Ghidra bridge instance.
    
    Args:
        emulator: Emulator instance
        host: Ghidra server host
        port: Ghidra script port
        auto_connect: Automatically connect
        
    Returns:
        GhidraBridge instance
    """
    bridge = GhidraBridge(emulator, host, port)
    if auto_connect:
        bridge.connect()
    return bridge
