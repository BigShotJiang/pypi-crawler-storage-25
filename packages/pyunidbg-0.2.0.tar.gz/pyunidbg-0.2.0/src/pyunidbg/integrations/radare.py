"""
Radare2/Rizin Bridge - Integrate PyUniDbg with radare2/rizin.

Provides bidirectional communication with radare2 or rizin for:
- Symbol and function synchronization
- Cross-reference analysis
- Binary diffing support
- ESIL (Evaluable Strings Intermediate Language) access
- r2pipe command execution

Usage:
    from pyunidbg.integrations import RadareBridge
    
    # Connect to radare2 via r2pipe
    bridge = RadareBridge(emulator, binary="/path/to/binary")
    bridge.connect()
    
    # Or connect to existing r2 session via HTTP
    bridge = RadareBridge(emulator, host="http://localhost:9090")
    bridge.connect()
    
    # Import analysis data
    bridge.analyze_all()
    bridge.import_symbols()
    bridge.import_functions()
    
    # Execute r2 commands
    result = bridge.cmd("pdf @ main")
"""

from __future__ import annotations

import json
import logging
import subprocess
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from pyunidbg.errors import IntegrationConnectionError, IntegrationProtocolError

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    "RadareBridge",
    "R2Symbol",
    "R2Function",
    "R2XRef",
    "R2BasicBlock",
    "R2Section",
    "R2ConnectionError",
    "R2CommandError",
    "create_radare_bridge",
]

logger = logging.getLogger(__name__)


# ==================== Exceptions ====================

class R2ConnectionError(IntegrationConnectionError):
    """Error connecting to radare2."""


class R2CommandError(IntegrationProtocolError):
    """Error executing radare2 command."""


# ==================== Enums ====================

class R2Tool(Enum):
    """Radare2/Rizin tool variant."""
    R2 = "radare2"
    RIZIN = "rizin"
    R2PIPE = "r2pipe"
    HTTP = "http"


class R2AnalysisLevel(Enum):
    """Analysis depth levels."""
    MINIMAL = "a"      # Basic analysis
    NORMAL = "aa"      # Analyze all
    DEEP = "aaa"       # Even more analysis
    DEEPER = "aaaa"    # Maximum analysis


class SymbolBind(Enum):
    """Symbol binding."""
    LOCAL = "LOCAL"
    GLOBAL = "GLOBAL"
    WEAK = "WEAK"


class SymbolType(Enum):
    """Symbol types."""
    FUNC = "FUNC"
    OBJECT = "OBJECT"
    NOTYPE = "NOTYPE"
    FILE = "FILE"
    SECTION = "SECTION"


# ==================== Data Classes ====================

@dataclass
class R2Symbol:
    """A radare2 symbol."""
    address: int
    name: str
    demname: str = ""
    flagname: str = ""
    realname: str = ""
    size: int = 0
    bind: SymbolBind = SymbolBind.GLOBAL
    type: SymbolType = SymbolType.NOTYPE
    is_imported: bool = False
    libname: str = ""
    ordinal: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "vaddr": hex(self.address),
            "name": self.name,
            "demname": self.demname,
            "flagname": self.flagname,
            "realname": self.realname,
            "size": self.size,
            "bind": self.bind.value,
            "type": self.type.value,
            "is_imported": self.is_imported,
            "libname": self.libname,
            "ordinal": self.ordinal,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> R2Symbol:
        addr = data.get("vaddr", data.get("addr", data.get("address", 0)))
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)

        bind = data.get("bind", "GLOBAL")
        try:
            bind = SymbolBind(bind.upper() if isinstance(bind, str) else "GLOBAL")
        except ValueError:
            bind = SymbolBind.GLOBAL

        sym_type = data.get("type", "NOTYPE")
        try:
            sym_type = SymbolType(sym_type.upper() if isinstance(sym_type, str) else "NOTYPE")
        except ValueError:
            sym_type = SymbolType.NOTYPE

        return cls(
            address=addr,
            name=data.get("name", ""),
            demname=data.get("demname", ""),
            flagname=data.get("flagname", ""),
            realname=data.get("realname", ""),
            size=data.get("size", 0),
            bind=bind,
            type=sym_type,
            is_imported=data.get("is_imported", False),
            libname=data.get("libname", ""),
            ordinal=data.get("ordinal", 0),
        )


@dataclass
class R2BasicBlock:
    """A radare2 basic block."""
    addr: int
    size: int
    jump: int | None = None
    fail: int | None = None
    opaddr: int = 0
    inputs: int = 0
    outputs: int = 0
    ninstr: int = 0
    instrs: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "addr": hex(self.addr),
            "size": self.size,
            "jump": hex(self.jump) if self.jump else None,
            "fail": hex(self.fail) if self.fail else None,
            "opaddr": hex(self.opaddr),
            "inputs": self.inputs,
            "outputs": self.outputs,
            "ninstr": self.ninstr,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> R2BasicBlock:
        def parse_addr(val):
            if val is None:
                return None
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val

        return cls(
            addr=parse_addr(data.get("addr", 0)),
            size=data.get("size", 0),
            jump=parse_addr(data.get("jump")),
            fail=parse_addr(data.get("fail")),
            opaddr=parse_addr(data.get("opaddr", 0)),
            inputs=data.get("inputs", 0),
            outputs=data.get("outputs", 0),
            ninstr=data.get("ninstr", 0),
        )


@dataclass
class R2Function:
    """A radare2 function."""
    address: int
    name: str
    size: int = 0
    type: str = ""
    signature: str = ""
    is_pure: str = ""
    realsz: int = 0
    noreturn: bool = False
    stackframe: int = 0
    calltype: str = ""
    nbbs: int = 0
    cc: int = 0  # Cyclomatic complexity
    bits: int = 0
    basic_blocks: list[R2BasicBlock] = field(default_factory=list)
    callrefs: list[int] = field(default_factory=list)
    datarefs: list[int] = field(default_factory=list)
    codexrefs: list[int] = field(default_factory=list)
    dataxrefs: list[int] = field(default_factory=list)
    locals: list[dict] = field(default_factory=list)

    # Decompiled/ESIL
    pseudocode: str = ""
    esil: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "offset": hex(self.address),
            "name": self.name,
            "size": self.size,
            "type": self.type,
            "signature": self.signature,
            "is-pure": self.is_pure,
            "realsz": self.realsz,
            "noreturn": self.noreturn,
            "stackframe": self.stackframe,
            "calltype": self.calltype,
            "nbbs": self.nbbs,
            "cc": self.cc,
            "bits": self.bits,
            "bbs": [bb.to_dict() for bb in self.basic_blocks],
            "callrefs": [hex(c) for c in self.callrefs],
            "datarefs": [hex(d) for d in self.datarefs],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> R2Function:
        addr = data.get("offset", data.get("addr", data.get("address", 0)))
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)

        basic_blocks = []
        for bb_data in data.get("bbs", []):
            basic_blocks.append(R2BasicBlock.from_dict(bb_data))

        def parse_refs(refs):
            result = []
            for ref in refs:
                if isinstance(ref, dict):
                    a = ref.get("addr", 0)
                    if isinstance(a, str):
                        a = int(a, 16) if a.startswith("0x") else int(a)
                    result.append(a)
                elif isinstance(ref, str):
                    result.append(int(ref, 16) if ref.startswith("0x") else int(ref))
                else:
                    result.append(ref)
            return result

        return cls(
            address=addr,
            name=data.get("name", ""),
            size=data.get("size", 0),
            type=data.get("type", ""),
            signature=data.get("signature", ""),
            is_pure=data.get("is-pure", ""),
            realsz=data.get("realsz", 0),
            noreturn=data.get("noreturn", False),
            stackframe=data.get("stackframe", 0),
            calltype=data.get("calltype", ""),
            nbbs=data.get("nbbs", 0),
            cc=data.get("cc", 0),
            bits=data.get("bits", 0),
            basic_blocks=basic_blocks,
            callrefs=parse_refs(data.get("callrefs", [])),
            datarefs=parse_refs(data.get("datarefs", [])),
            codexrefs=parse_refs(data.get("codexrefs", [])),
            dataxrefs=parse_refs(data.get("dataxrefs", [])),
            locals=data.get("locals", []),
        )


@dataclass
class R2XRef:
    """A radare2 cross-reference."""
    from_addr: int
    to_addr: int
    type: str = ""  # CODE, CALL, DATA, STRING
    opcode: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "from": hex(self.from_addr),
            "to": hex(self.to_addr),
            "type": self.type,
            "opcode": self.opcode,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> R2XRef:
        def parse_addr(val):
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val or 0

        return cls(
            from_addr=parse_addr(data.get("from", 0)),
            to_addr=parse_addr(data.get("to", data.get("addr", 0))),
            type=data.get("type", ""),
            opcode=data.get("opcode", ""),
        )


@dataclass
class R2Section:
    """A binary section."""
    name: str
    size: int
    vsize: int
    paddr: int
    vaddr: int
    perm: str = ""  # r-x, rw-, etc.

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "size": self.size,
            "vsize": self.vsize,
            "paddr": hex(self.paddr),
            "vaddr": hex(self.vaddr),
            "perm": self.perm,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> R2Section:
        def parse_addr(val):
            if isinstance(val, str):
                return int(val, 16) if val.startswith("0x") else int(val)
            return val or 0

        return cls(
            name=data.get("name", ""),
            size=data.get("size", 0),
            vsize=data.get("vsize", 0),
            paddr=parse_addr(data.get("paddr", 0)),
            vaddr=parse_addr(data.get("vaddr", 0)),
            perm=data.get("perm", ""),
        )


@dataclass
class R2BinaryInfo:
    """Binary information from radare2."""
    file: str = ""
    format: str = ""
    arch: str = ""
    bits: int = 0
    machine: str = ""
    os: str = ""
    bintype: str = ""
    endian: str = ""
    stripped: bool = False
    static: bool = False
    canary: bool = False
    nx: bool = False
    pic: bool = False
    relocs: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "file": self.file,
            "format": self.format,
            "arch": self.arch,
            "bits": self.bits,
            "machine": self.machine,
            "os": self.os,
            "bintype": self.bintype,
            "endian": self.endian,
            "stripped": self.stripped,
            "static": self.static,
            "canary": self.canary,
            "nx": self.nx,
            "pic": self.pic,
            "relocs": self.relocs,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> R2BinaryInfo:
        bin_data = data.get("bin", data)
        return cls(
            file=bin_data.get("file", ""),
            format=bin_data.get("format", ""),
            arch=bin_data.get("arch", ""),
            bits=bin_data.get("bits", 0),
            machine=bin_data.get("machine", ""),
            os=bin_data.get("os", ""),
            bintype=bin_data.get("bintype", ""),
            endian=bin_data.get("endian", ""),
            stripped=bin_data.get("stripped", False),
            static=bin_data.get("static", False),
            canary=bin_data.get("canary", False),
            nx=bin_data.get("nx", False),
            pic=bin_data.get("pic", False),
            relocs=bin_data.get("relocs", False),
        )


# ==================== Radare2 Bridge ====================

class RadareBridge:
    """
    Bridge for communication with radare2/rizin.
    
    Provides:
    - r2pipe command execution
    - Symbol and function import/export
    - Cross-reference analysis
    - ESIL access
    - Binary info extraction
    
    Can work with:
    - r2pipe (subprocess spawn)
    - HTTP API
    - Local binary analysis
    """

    def __init__(
        self,
        emulator: Emulator,
        binary: str | None = None,
        host: str | None = None,
        tool: R2Tool = R2Tool.R2,
    ):
        self._emulator = emulator
        self._binary = binary
        self._host = host
        self._tool = tool

        # r2pipe process
        self._r2pipe = None
        self._r2_proc: subprocess.Popen | None = None
        self._connected = False

        # Cached data
        self._binary_info: R2BinaryInfo | None = None
        self._symbols: dict[int, R2Symbol] = {}
        self._functions: dict[int, R2Function] = {}
        self._sections: list[R2Section] = []
        self._strings: list[tuple[int, str]] = []

        # Analysis state
        self._analyzed = False

    @property
    def connected(self) -> bool:
        """Check if connected."""
        return self._connected

    @property
    def analyzed(self) -> bool:
        """Check if analysis has been performed."""
        return self._analyzed

    @property
    def binary_info(self) -> R2BinaryInfo | None:
        """Get binary information."""
        return self._binary_info

    @property
    def symbols(self) -> dict[int, R2Symbol]:
        """Get cached symbols."""
        return self._symbols.copy()

    @property
    def functions(self) -> dict[int, R2Function]:
        """Get cached functions."""
        return self._functions.copy()

    @property
    def sections(self) -> list[R2Section]:
        """Get sections."""
        return self._sections.copy()

    def connect(self, flags: list[str] = None) -> bool:
        """Connect to radare2/rizin."""
        if self._connected:
            return True

        if self._host:
            return self._connect_http()

        return self._connect_pipe(flags or [])

    def _connect_pipe(self, flags: list[str]) -> bool:
        """Connect via r2pipe (spawn process)."""
        try:
            import r2pipe
            HAS_R2PIPE = True
        except ImportError:
            HAS_R2PIPE = False

        if HAS_R2PIPE and self._binary:
            try:
                r2_flags = ["-2"]  # Disable stderr
                r2_flags.extend(flags)

                self._r2pipe = r2pipe.open(self._binary, flags=r2_flags)
                self._connected = True
                self._fetch_binary_info()
                logger.info(f"Connected to r2 via r2pipe: {self._binary}")
                return True
            except Exception as e:
                raise R2ConnectionError(f"Failed to open with r2pipe: {e}")

        if self._binary:
            return self._connect_subprocess(flags)

        raise R2ConnectionError("No binary or host specified")

    def _connect_subprocess(self, flags: list[str]) -> bool:
        """Connect by spawning r2 process directly."""
        r2_cmd = "rizin" if self._tool == R2Tool.RIZIN else "radare2"

        try:
            cmd = [r2_cmd, "-q0"]
            cmd.extend(flags)
            cmd.append(self._binary)

            self._r2_proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
            )
            self._connected = True
            self._fetch_binary_info()
            logger.info(f"Connected to {r2_cmd}: {self._binary}")
            return True
        except FileNotFoundError:
            raise R2ConnectionError(f"{r2_cmd} not found in PATH")
        except Exception as e:
            raise R2ConnectionError(f"Failed to spawn {r2_cmd}: {e}")

    def _connect_http(self) -> bool:
        """Connect via HTTP API."""
        if not HAS_REQUESTS:
            raise R2ConnectionError("requests library not installed")

        try:
            # Test connection
            response = requests.get(f"{self._host}/cmd/?", timeout=5)
            if response.status_code == 200:
                self._connected = True
                self._fetch_binary_info()
                logger.info(f"Connected to r2 HTTP: {self._host}")
                return True
            raise R2ConnectionError(f"HTTP error: {response.status_code}")
        except requests.exceptions.RequestException as e:
            raise R2ConnectionError(f"HTTP connection failed: {e}")

    def disconnect(self) -> None:
        """Disconnect from radare2."""
        if self._r2pipe:
            try:
                self._r2pipe.quit()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._r2pipe = None

        if self._r2_proc:
            try:
                self._r2_proc.stdin.write(b"q!\n")
                self._r2_proc.stdin.flush()
                self._r2_proc.wait(timeout=2)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                self._r2_proc.kill()
            self._r2_proc = None

        self._connected = False
        logger.info("Disconnected from r2")

    def cmd(self, command: str) -> str:
        """Execute r2 command and return output."""
        if not self._connected:
            raise R2ConnectionError("Not connected")

        if self._r2pipe:
            return self._r2pipe.cmd(command)

        if self._host:
            return self._cmd_http(command)

        return self._cmd_subprocess(command)

    def _cmd_subprocess(self, command: str) -> str:
        """Execute command via subprocess."""
        if not self._r2_proc:
            return ""

        try:
            self._r2_proc.stdin.write(f"{command}\n".encode())
            self._r2_proc.stdin.flush()

            # Read until we get the prompt
            output = []
            while True:
                line = self._r2_proc.stdout.readline().decode()
                if not line or line.strip() == "":
                    break
                output.append(line)

            return "".join(output)
        except Exception as e:
            raise R2CommandError(f"Command failed: {e}")

    def _cmd_http(self, command: str) -> str:
        """Execute command via HTTP."""
        try:
            response = requests.get(
                f"{self._host}/cmd/{command}",
                timeout=30
            )
            return response.text
        except requests.exceptions.RequestException as e:
            raise R2CommandError(f"HTTP command failed: {e}")

    def cmdj(self, command: str) -> Any:
        """Execute r2 command and return JSON parsed output."""
        if not self._connected:
            raise R2ConnectionError("Not connected")

        if self._r2pipe:
            return self._r2pipe.cmdj(command)

        output = self.cmd(command)
        try:
            return json.loads(output)
        except json.JSONDecodeError:
            return None

    def _fetch_binary_info(self) -> None:
        """Fetch binary info from r2."""
        data = self.cmdj("ij")
        if data:
            self._binary_info = R2BinaryInfo.from_dict(data)

    # ==================== Analysis ====================

    def analyze(self, level: R2AnalysisLevel = R2AnalysisLevel.NORMAL) -> None:
        """Run analysis at specified level."""
        self.cmd(level.value)
        self._analyzed = True
        logger.info(f"Analysis complete (level: {level.value})")

    def analyze_all(self) -> None:
        """Run full analysis (aaa)."""
        self.analyze(R2AnalysisLevel.DEEP)

    def analyze_function(self, address: int) -> None:
        """Analyze function at address."""
        self.cmd(f"af @ {hex(address)}")

    # ==================== Symbols ====================

    def import_symbols(self, refresh: bool = False) -> dict[int, R2Symbol]:
        """Import symbols from r2."""
        if self._symbols and not refresh:
            return self._symbols.copy()

        self._symbols.clear()

        # Get all symbols
        data = self.cmdj("isj")
        if data:
            for sym_data in data:
                sym = R2Symbol.from_dict(sym_data)
                self._symbols[sym.address] = sym
                self._emulator.add_symbol(sym.address, sym.name)

        # Also get imports
        imports = self.cmdj("iij")
        if imports:
            for imp_data in imports:
                imp_data["is_imported"] = True
                sym = R2Symbol.from_dict(imp_data)
                if sym.address not in self._symbols:
                    self._symbols[sym.address] = sym
                    self._emulator.add_symbol(sym.address, sym.name)

        return self._symbols.copy()

    def get_symbol(self, address: int) -> R2Symbol | None:
        """Get symbol at address."""
        return self._symbols.get(address)

    def get_symbol_by_name(self, name: str) -> R2Symbol | None:
        """Get symbol by name."""
        for sym in self._symbols.values():
            if sym.name == name or sym.realname == name:
                return sym
        return None

    def add_flag(self, address: int, name: str, size: int = 1) -> None:
        """Add a flag (symbol) at address."""
        self.cmd(f"f {name} {size} @ {hex(address)}")
        self._symbols[address] = R2Symbol(address, name, size=size)

    # ==================== Functions ====================

    def import_functions(self, refresh: bool = False) -> dict[int, R2Function]:
        """Import functions from r2."""
        if self._functions and not refresh:
            return self._functions.copy()

        self._functions.clear()

        data = self.cmdj("aflj")
        if data:
            for func_data in data:
                func = R2Function.from_dict(func_data)
                self._functions[func.address] = func

        return self._functions.copy()

    def get_function(self, address: int) -> R2Function | None:
        """Get function containing address."""
        for func in self._functions.values():
            if func.address <= address < func.address + func.size:
                return func
        return None

    def get_function_at(self, address: int) -> R2Function | None:
        """Get function at address."""
        return self._functions.get(address)

    def get_function_detail(self, address: int) -> R2Function | None:
        """Get detailed function info including basic blocks."""
        data = self.cmdj(f"afij @ {hex(address)}")
        if data and len(data) > 0:
            func = R2Function.from_dict(data[0])

            # Get basic blocks
            bbs = self.cmdj(f"afbj @ {hex(address)}")
            if bbs:
                func.basic_blocks = [R2BasicBlock.from_dict(bb) for bb in bbs]

            self._functions[address] = func
            return func
        return None

    def create_function(self, address: int) -> bool:
        """Create function at address."""
        self.cmd(f"af @ {hex(address)}")
        return self.get_function_at(address) is not None

    # ==================== Disassembly ====================

    def disassemble(self, address: int, count: int = 10) -> list[str]:
        """Disassemble instructions at address."""
        output = self.cmd(f"pd {count} @ {hex(address)}")
        return output.strip().split("\n") if output else []

    def disassemble_function(self, address: int) -> str:
        """Disassemble entire function."""
        return self.cmd(f"pdf @ {hex(address)}")

    def get_esil(self, address: int, count: int = 10) -> list[str]:
        """Get ESIL representation at address."""
        data = self.cmdj(f"pdj {count} @ {hex(address)}")
        if data:
            return [op.get("esil", "") for op in data if op.get("esil")]
        return []

    def get_pseudocode(self, address: int) -> str:
        """Get pseudocode (decompiled) for function."""
        # Try pdc (r2 pseudocode)
        output = self.cmd(f"pdc @ {hex(address)}")
        if output and "Cannot" not in output:
            return output

        # Try pdg (ghidra decompiler via r2ghidra)
        output = self.cmd(f"pdg @ {hex(address)}")
        if output and "Cannot" not in output:
            return output

        return ""

    # ==================== Cross-References ====================

    def get_xrefs_to(self, address: int) -> list[R2XRef]:
        """Get cross-references to address."""
        data = self.cmdj(f"axtj @ {hex(address)}")
        if data:
            return [R2XRef.from_dict(xref) for xref in data]
        return []

    def get_xrefs_from(self, address: int) -> list[R2XRef]:
        """Get cross-references from address."""
        data = self.cmdj(f"axfj @ {hex(address)}")
        if data:
            xrefs = []
            for xref in data:
                xrefs.append(R2XRef(
                    from_addr=address,
                    to_addr=xref.get("to", xref.get("addr", 0)),
                    type=xref.get("type", ""),
                ))
            return xrefs
        return []

    def get_callgraph(self, address: int) -> dict[int, list[int]]:
        """Get callgraph for function."""
        data = self.cmdj(f"agCj @ {hex(address)}")
        callgraph = defaultdict(list)

        if data:
            for node in data:
                addr = node.get("addr", 0)
                if isinstance(addr, str):
                    addr = int(addr, 16)
                for ref in node.get("refs", []):
                    ref_addr = ref.get("addr", 0)
                    if isinstance(ref_addr, str):
                        ref_addr = int(ref_addr, 16)
                    callgraph[addr].append(ref_addr)

        return dict(callgraph)

    # ==================== Sections & Strings ====================

    def get_sections(self, refresh: bool = False) -> list[R2Section]:
        """Get binary sections."""
        if self._sections and not refresh:
            return self._sections.copy()

        data = self.cmdj("iSj")
        if data:
            self._sections = [R2Section.from_dict(s) for s in data]

        return self._sections.copy()

    def get_strings(self, min_length: int = 4) -> list[tuple[int, str]]:
        """Get strings from binary."""
        data = self.cmdj("izj")
        strings = []

        if data:
            for s in data:
                string = s.get("string", "")
                if len(string) >= min_length:
                    addr = s.get("vaddr", s.get("paddr", 0))
                    if isinstance(addr, str):
                        addr = int(addr, 16)
                    strings.append((addr, string))

        return strings

    # ==================== Memory ====================

    def read_memory(self, address: int, size: int) -> bytes:
        """Read memory from binary."""
        output = self.cmd(f"p8 {size} @ {hex(address)}")
        try:
            return bytes.fromhex(output.strip())
        except ValueError:
            return b""

    def write_memory(self, address: int, data: bytes) -> None:
        """Write memory (patch) in binary."""
        hex_data = data.hex()
        self.cmd(f"wx {hex_data} @ {hex(address)}")

    # ==================== Comments & Annotations ====================

    def set_comment(self, address: int, comment: str) -> None:
        """Set comment at address."""
        escaped = comment.replace('"', '\\"')
        self.cmd(f'CC "{escaped}" @ {hex(address)}')

    def get_comments(self) -> dict[int, str]:
        """Get all comments."""
        data = self.cmdj("CCj")
        comments = {}

        if data:
            for c in data:
                addr = c.get("offset", 0)
                if isinstance(addr, str):
                    addr = int(addr, 16)
                comments[addr] = c.get("name", "")

        return comments

    # ==================== Search ====================

    def search_bytes(self, pattern: bytes) -> list[int]:
        """Search for byte pattern."""
        hex_pattern = pattern.hex()
        data = self.cmdj(f"/xj {hex_pattern}")

        addresses = []
        if data:
            for match in data:
                addr = match.get("offset", 0)
                if isinstance(addr, str):
                    addr = int(addr, 16)
                addresses.append(addr)

        return addresses

    def search_string(self, string: str) -> list[int]:
        """Search for string."""
        data = self.cmdj(f"/j {string}")

        addresses = []
        if data:
            for match in data:
                addr = match.get("offset", 0)
                if isinstance(addr, str):
                    addr = int(addr, 16)
                addresses.append(addr)

        return addresses

    def search_rop(self, gadget: str = "") -> list[tuple[int, str]]:
        """Search for ROP gadgets."""
        if gadget:
            output = self.cmd(f"/R {gadget}")
        else:
            output = self.cmd("/R")

        gadgets = []
        for line in output.strip().split("\n"):
            if line and "0x" in line:
                parts = line.split(None, 1)
                if len(parts) >= 2:
                    try:
                        addr = int(parts[0], 16)
                        gadgets.append((addr, parts[1]))
                    except ValueError:
                        pass

        return gadgets

    # ==================== Emulation ====================

    def esil_init(self) -> None:
        """Initialize ESIL emulation."""
        self.cmd("aei")  # Init ESIL VM
        self.cmd("aeim")  # Init ESIL memory

    def esil_step(self) -> None:
        """Step one instruction in ESIL."""
        self.cmd("aes")

    def esil_run(self, address: int, until: int | None = None) -> None:
        """Run ESIL emulation from address."""
        self.cmd(f"s {hex(address)}")
        if until:
            self.cmd(f"aecu {hex(until)}")
        else:
            self.cmd("aec")

    def esil_get_registers(self) -> dict[str, int]:
        """Get ESIL register values."""
        data = self.cmdj("aerj")
        return data if data else {}

    # ==================== Binary Diffing ====================

    def diff_functions(self, other_binary: str) -> list[dict]:
        """Compare functions with another binary."""
        # Use radiff2 for comparison
        output = self.cmd(f"r2 -c 'aaa; afl' {other_binary}")
        # This is a simplified version - real implementation would use radiff2
        return []

    # ==================== Full Sync ====================

    def full_sync(self) -> bool:
        """Import all data from r2."""
        try:
            if not self._analyzed:
                self.analyze_all()

            self.import_symbols(refresh=True)
            self.import_functions(refresh=True)
            self.get_sections(refresh=True)

            return True
        except Exception as e:
            logger.error(f"Full sync failed: {e}")
            return False

    # ==================== Export/Import ====================

    def export_to_json(self, path: str | Path) -> None:
        """Export all data to JSON file."""
        data = {
            "binary_info": self._binary_info.to_dict() if self._binary_info else {},
            "symbols": [s.to_dict() for s in self._symbols.values()],
            "functions": [f.to_dict() for f in self._functions.values()],
            "sections": [s.to_dict() for s in self._sections],
        }

        path = Path(path)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)

    def import_from_json(self, path: str | Path) -> None:
        """Import data from JSON file."""
        path = Path(path)
        with open(path) as f:
            data = json.load(f)

        if data.get("binary_info"):
            self._binary_info = R2BinaryInfo.from_dict(data["binary_info"])

        self._symbols.clear()
        for sym_data in data.get("symbols", []):
            sym = R2Symbol.from_dict(sym_data)
            self._symbols[sym.address] = sym

        self._functions.clear()
        for func_data in data.get("functions", []):
            func = R2Function.from_dict(func_data)
            self._functions[func.address] = func

        self._sections.clear()
        for sec_data in data.get("sections", []):
            self._sections.append(R2Section.from_dict(sec_data))

    def __enter__(self) -> RadareBridge:
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    def __repr__(self) -> str:
        target = self._host or self._binary or "unknown"
        status = "connected" if self._connected else "disconnected"
        return f"RadareBridge({target}, {status})"


# ==================== Factory Function ====================

def create_radare_bridge(
    emulator: Emulator,
    binary: str | None = None,
    host: str | None = None,
    tool: R2Tool = R2Tool.R2,
    auto_connect: bool = False,
    auto_analyze: bool = False,
) -> RadareBridge:
    """
    Create a radare2/rizin bridge instance.
    
    Args:
        emulator: Emulator instance
        binary: Path to binary file
        host: HTTP API host (e.g., "http://localhost:9090")
        tool: R2 variant to use
        auto_connect: Automatically connect
        auto_analyze: Run analysis after connecting
        
    Returns:
        RadareBridge instance
    """
    bridge = RadareBridge(emulator, binary, host, tool)

    if auto_connect:
        bridge.connect()
        if auto_analyze:
            bridge.analyze_all()

    return bridge
