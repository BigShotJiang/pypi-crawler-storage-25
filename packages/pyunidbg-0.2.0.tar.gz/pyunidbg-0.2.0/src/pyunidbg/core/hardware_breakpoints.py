"""
Hardware Breakpoints and Watchpoints - Memory access monitoring.

This module implements hardware breakpoint and watchpoint functionality for the emulator,
providing:
- Hardware execution breakpoints (limited number, like x86 DR0-DR3)
- Memory watchpoints (break on read/write/access)
- Address range watching
- Conditional watchpoints
- Hit counting and logging

Hardware breakpoints differ from software breakpoints:
- Software breakpoints replace instructions with trap/breakpoint instructions
- Hardware breakpoints use CPU debug registers (limited count)
- Watchpoints monitor memory regions for data access

This implementation emulates hardware debug register behavior:
- x86/x86-64: 4 debug registers (DR0-DR3)
- ARM/ARM64: Variable number depending on implementation
- Default: 4 watchpoint slots

Reference:
- Intel SDM Vol. 3B, Chapter 17 (Debug registers)
- ARM Architecture Reference Manual (Debug chapter)
"""

import logging
from collections.abc import Callable
from dataclasses import dataclass
from enum import IntEnum, IntFlag
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from .emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== Constants ====================

class WatchType(IntEnum):
    """Type of memory access to watch."""
    NONE = 0
    EXECUTE = 1     # Hardware execution breakpoint
    WRITE = 2       # Watch for writes only
    READ = 3        # Watch for reads only (rare, some CPUs don't support)
    ACCESS = 4      # Watch for both reads and writes


class WatchSize(IntEnum):
    """Size of data being watched (for alignment requirements)."""
    BYTE = 1
    WORD = 2        # 2 bytes
    DWORD = 4       # 4 bytes
    QWORD = 8       # 8 bytes


class HWBPStatus(IntFlag):
    """Hardware breakpoint status flags."""
    ACTIVE = 0x01       # Breakpoint is active
    LOCAL = 0x02        # Local (current task only) - for OS-level debugging
    GLOBAL = 0x04       # Global (all tasks)
    TRIGGERED = 0x08    # Has been triggered at least once
    TEMPORARY = 0x10    # Remove after first hit


class DebugReg(IntEnum):
    """Debug register indices (x86/x86-64 model)."""
    DR0 = 0
    DR1 = 1
    DR2 = 2
    DR3 = 3


# ==================== Data Structures ====================

@dataclass
class Watchpoint:
    """
    Represents a hardware watchpoint/breakpoint.
    
    Attributes:
        id: Unique watchpoint identifier
        address: Start address to watch
        size: Size of watched region (1, 2, 4, or 8 bytes)
        watch_type: Type of access to monitor
        callback: Optional callback on trigger
        condition: Optional condition function
        enabled: Whether watchpoint is active
        hit_count: Number of times triggered
        status: Status flags
        slot: Hardware debug register slot (-1 if not assigned)
        name: Optional descriptive name
        log_accesses: If True, log all accesses without stopping
    """
    id: int
    address: int
    size: WatchSize = WatchSize.DWORD
    watch_type: WatchType = WatchType.ACCESS
    callback: Callable[[int, int, bool, Any], None] | None = None
    condition: Callable[[int, int, bool, Any], bool] | None = None
    enabled: bool = True
    hit_count: int = 0
    status: HWBPStatus = HWBPStatus.ACTIVE
    slot: int = -1
    name: str = ""
    log_accesses: bool = False
    original_value: bytes | None = None

    @property
    def end_address(self) -> int:
        """Get end address of watched region."""
        return self.address + int(self.size)

    @property
    def is_execution(self) -> bool:
        """Check if this is an execution breakpoint."""
        return self.watch_type == WatchType.EXECUTE

    @property
    def watches_reads(self) -> bool:
        """Check if this watches read accesses."""
        return self.watch_type in (WatchType.READ, WatchType.ACCESS)

    @property
    def watches_writes(self) -> bool:
        """Check if this watches write accesses."""
        return self.watch_type in (WatchType.WRITE, WatchType.ACCESS)

    @property
    def is_temporary(self) -> bool:
        """Check if this is a temporary (one-shot) watchpoint."""
        return bool(self.status & HWBPStatus.TEMPORARY)

    def overlaps(self, addr: int, size: int) -> bool:
        """Check if given memory range overlaps with this watchpoint."""
        return not (addr + size <= self.address or addr >= self.end_address)

    def matches_access(self, addr: int, size: int, is_write: bool) -> bool:
        """
        Check if a memory access matches this watchpoint.
        
        Args:
            addr: Access address
            size: Access size
            is_write: True if write access
            
        Returns:
            True if access should trigger this watchpoint
        """
        if not self.enabled:
            return False

        # Check address overlap
        if not self.overlaps(addr, size):
            return False

        # Check access type
        if is_write and not self.watches_writes:
            return False
        if not is_write and not self.watches_reads:
            return False

        return True

    def check_condition(self, context: Any) -> bool:
        """Check if condition allows triggering."""
        if self.condition is None:
            return True
        try:
            return self.condition(self.address, self.size, context.get('is_write', False), context)
        except Exception as e:
            logger.warning(f"Watchpoint {self.id} condition error: {e}")
            return False

    def __str__(self) -> str:
        type_str = self.watch_type.name
        enabled_str = "enabled" if self.enabled else "disabled"
        slot_str = f"DR{self.slot}" if self.slot >= 0 else "unassigned"
        name_str = f" ({self.name})" if self.name else ""
        return (f"Watchpoint[{self.id}]{name_str}: 0x{self.address:x}+{int(self.size)} "
                f"type={type_str} slot={slot_str} {enabled_str} hits={self.hit_count}")


@dataclass
class WatchpointHit:
    """
    Information about a watchpoint trigger.
    
    Attributes:
        watchpoint: The triggered watchpoint
        access_address: Actual address accessed
        access_size: Size of access
        is_write: True if write access
        old_value: Value before write (if available)
        new_value: Value being written (if available)
        pc: Program counter when triggered
    """
    watchpoint: Watchpoint
    access_address: int
    access_size: int
    is_write: bool
    old_value: bytes | None = None
    new_value: bytes | None = None
    pc: int = 0

    def __str__(self) -> str:
        access_type = "WRITE" if self.is_write else "READ"
        return (f"WatchpointHit: {access_type} at 0x{self.access_address:x} "
                f"(size={self.access_size}, PC=0x{self.pc:x})")


@dataclass
class HardwareBreakpoint:
    """
    Hardware execution breakpoint.
    
    Uses debug registers for code execution breakpoints.
    """
    id: int
    address: int
    enabled: bool = True
    hit_count: int = 0
    slot: int = -1
    temporary: bool = False
    condition: Callable[['Emulator'], bool] | None = None
    callback: Callable[['Emulator', int], None] | None = None
    name: str = ""

    def should_break(self, emulator: 'Emulator') -> bool:
        """Check if breakpoint should trigger."""
        if not self.enabled:
            return False
        if self.condition and not self.condition(emulator):
            return False
        return True

    def __str__(self) -> str:
        enabled_str = "enabled" if self.enabled else "disabled"
        slot_str = f"DR{self.slot}" if self.slot >= 0 else "unassigned"
        temp_str = " (temp)" if self.temporary else ""
        name_str = f" ({self.name})" if self.name else ""
        return (f"HWBreakpoint[{self.id}]{name_str}: 0x{self.address:x} "
                f"slot={slot_str} {enabled_str} hits={self.hit_count}{temp_str}")


# ==================== Hardware Breakpoint Manager ====================

class HardwareBreakpointManager:
    """
    Manages hardware breakpoints and watchpoints.
    
    Emulates CPU debug register behavior with a configurable number
    of available slots (default 4, like x86 DR0-DR3).
    
    Features:
    - Limited number of hardware breakpoint slots
    - Automatic slot allocation/deallocation
    - Memory watchpoints with read/write/access monitoring
    - Conditional breakpoints
    - Hit counting and logging
    - Callback support
    """

    def __init__(
        self,
        emulator: Optional['Emulator'] = None,
        max_slots: int = 4
    ):
        """
        Initialize hardware breakpoint manager.
        
        Args:
            emulator: Optional emulator for memory access
            max_slots: Maximum number of hardware breakpoint slots
        """
        self._emulator = emulator
        self._max_slots = max_slots

        # Slot management
        self._slots: list[int | None] = [None] * max_slots  # slot -> watchpoint_id

        # Breakpoints and watchpoints
        self._hardware_breakpoints: dict[int, HardwareBreakpoint] = {}  # id -> bp
        self._watchpoints: dict[int, Watchpoint] = {}  # id -> wp

        # Address lookups for fast checking
        self._address_to_hwbp: dict[int, int] = {}  # address -> bp_id
        self._watched_ranges: list[tuple[int, int, int]] = []  # (start, end, wp_id)

        # ID counters
        self._next_bp_id = 1
        self._next_wp_id = 1

        # Statistics
        self._total_checks = 0
        self._total_hits = 0

        # Pending hits (for batch processing)
        self._pending_hits: list[WatchpointHit] = []

    @property
    def available_slots(self) -> int:
        """Get number of available slots."""
        return sum(1 for s in self._slots if s is None)

    @property
    def used_slots(self) -> int:
        """Get number of used slots."""
        return self._max_slots - self.available_slots

    def get_slot_info(self) -> list[tuple[int, str | None]]:
        """
        Get information about all slots.
        
        Returns:
            List of (slot_index, description) tuples
        """
        result = []
        for i, wp_id in enumerate(self._slots):
            if wp_id is None:
                result.append((i, None))
            else:
                # Try watchpoint first, then hardware breakpoint
                wp = self._watchpoints.get(wp_id)
                if wp:
                    result.append((i, str(wp)))
                else:
                    bp = self._hardware_breakpoints.get(wp_id)
                    if bp:
                        result.append((i, str(bp)))
                    else:
                        result.append((i, f"unknown[{wp_id}]"))
        return result

    def _allocate_slot(self) -> int:
        """
        Allocate a slot for a new breakpoint/watchpoint.
        
        Returns:
            Slot index, or -1 if no slots available
        """
        for i, wp_id in enumerate(self._slots):
            if wp_id is None:
                return i
        return -1

    def _free_slot(self, slot: int) -> None:
        """Free a slot."""
        if 0 <= slot < self._max_slots:
            self._slots[slot] = None

    # ==================== Hardware Breakpoints ====================

    def add_hardware_breakpoint(
        self,
        address: int,
        callback: Callable[['Emulator', int], None] | None = None,
        condition: Callable[['Emulator'], bool] | None = None,
        temporary: bool = False,
        name: str = ""
    ) -> HardwareBreakpoint | None:
        """
        Add a hardware execution breakpoint.
        
        Args:
            address: Address to break at
            callback: Optional callback on break
            condition: Optional condition function
            temporary: If True, remove after first hit
            name: Optional descriptive name
            
        Returns:
            HardwareBreakpoint if successful, None if no slots available
        """
        # Check if already exists at this address
        if address in self._address_to_hwbp:
            existing_id = self._address_to_hwbp[address]
            return self._hardware_breakpoints.get(existing_id)

        # Allocate slot
        slot = self._allocate_slot()
        if slot < 0:
            logger.warning("No hardware breakpoint slots available")
            return None

        # Create breakpoint
        bp_id = self._next_bp_id
        self._next_bp_id += 1

        bp = HardwareBreakpoint(
            id=bp_id,
            address=address,
            slot=slot,
            temporary=temporary,
            condition=condition,
            callback=callback,
            name=name
        )

        self._slots[slot] = bp_id
        self._hardware_breakpoints[bp_id] = bp
        self._address_to_hwbp[address] = bp_id

        logger.debug(f"Added hardware breakpoint: {bp}")
        return bp

    def remove_hardware_breakpoint(self, bp_id: int) -> bool:
        """
        Remove a hardware breakpoint.
        
        Args:
            bp_id: Breakpoint ID
            
        Returns:
            True if removed
        """
        bp = self._hardware_breakpoints.get(bp_id)
        if not bp:
            return False

        # Free slot
        if bp.slot >= 0:
            self._free_slot(bp.slot)

        # Remove from lookups
        if bp.address in self._address_to_hwbp:
            del self._address_to_hwbp[bp.address]

        del self._hardware_breakpoints[bp_id]
        logger.debug(f"Removed hardware breakpoint {bp_id}")
        return True

    def remove_hardware_breakpoint_at(self, address: int) -> bool:
        """Remove hardware breakpoint at address."""
        bp_id = self._address_to_hwbp.get(address)
        if bp_id is not None:
            return self.remove_hardware_breakpoint(bp_id)
        return False

    def enable_hardware_breakpoint(self, bp_id: int) -> bool:
        """Enable a hardware breakpoint."""
        bp = self._hardware_breakpoints.get(bp_id)
        if bp:
            bp.enabled = True
            return True
        return False

    def disable_hardware_breakpoint(self, bp_id: int) -> bool:
        """Disable a hardware breakpoint."""
        bp = self._hardware_breakpoints.get(bp_id)
        if bp:
            bp.enabled = False
            return True
        return False

    def check_hardware_breakpoint(self, address: int, emulator: 'Emulator') -> HardwareBreakpoint | None:
        """
        Check if execution at address triggers a hardware breakpoint.
        
        Args:
            address: Current instruction address
            emulator: Emulator instance
            
        Returns:
            Triggered breakpoint, or None
        """
        bp_id = self._address_to_hwbp.get(address)
        if bp_id is None:
            return None

        bp = self._hardware_breakpoints.get(bp_id)
        if bp and bp.should_break(emulator):
            bp.hit_count += 1
            self._total_hits += 1

            if bp.callback:
                try:
                    bp.callback(emulator, address)
                except Exception as e:
                    logger.error(f"Hardware breakpoint callback error: {e}")

            if bp.temporary:
                self.remove_hardware_breakpoint(bp_id)

            return bp

        return None

    def get_hardware_breakpoint(self, bp_id: int) -> HardwareBreakpoint | None:
        """Get hardware breakpoint by ID."""
        return self._hardware_breakpoints.get(bp_id)

    def list_hardware_breakpoints(self) -> list[HardwareBreakpoint]:
        """Get all hardware breakpoints."""
        return list(self._hardware_breakpoints.values())

    # ==================== Watchpoints ====================

    def add_watchpoint(
        self,
        address: int,
        size: int = 4,
        watch_type: WatchType = WatchType.ACCESS,
        callback: Callable[[int, int, bool, Any], None] | None = None,
        condition: Callable[[int, int, bool, Any], bool] | None = None,
        name: str = "",
        log_accesses: bool = False,
        temporary: bool = False
    ) -> Watchpoint | None:
        """
        Add a memory watchpoint.
        
        Args:
            address: Start address to watch
            size: Size of region (1, 2, 4, or 8 bytes)
            watch_type: Type of access to monitor
            callback: Optional callback on trigger
            condition: Optional condition function
            name: Optional descriptive name
            log_accesses: Log accesses without stopping
            temporary: Remove after first hit
            
        Returns:
            Watchpoint if successful, None if no slots available
        """
        # Validate and normalize size
        try:
            watch_size = WatchSize(size)
        except ValueError:
            # Round up to next valid size
            if size <= 1:
                watch_size = WatchSize.BYTE
            elif size <= 2:
                watch_size = WatchSize.WORD
            elif size <= 4:
                watch_size = WatchSize.DWORD
            else:
                watch_size = WatchSize.QWORD

        # Allocate slot
        slot = self._allocate_slot()
        if slot < 0:
            logger.warning("No watchpoint slots available")
            return None

        # Create watchpoint
        wp_id = self._next_wp_id
        self._next_wp_id += 1

        status = HWBPStatus.ACTIVE
        if temporary:
            status |= HWBPStatus.TEMPORARY

        wp = Watchpoint(
            id=wp_id,
            address=address,
            size=watch_size,
            watch_type=watch_type,
            callback=callback,
            condition=condition,
            slot=slot,
            name=name,
            log_accesses=log_accesses,
            status=status
        )

        self._slots[slot] = wp_id
        self._watchpoints[wp_id] = wp
        self._watched_ranges.append((address, wp.end_address, wp_id))

        logger.debug(f"Added watchpoint: {wp}")
        return wp

    def add_write_watchpoint(
        self,
        address: int,
        size: int = 4,
        callback: Callable[[int, int, bool, Any], None] | None = None,
        name: str = ""
    ) -> Watchpoint | None:
        """Convenience method to add write-only watchpoint."""
        return self.add_watchpoint(
            address, size, WatchType.WRITE, callback, name=name
        )

    def add_read_watchpoint(
        self,
        address: int,
        size: int = 4,
        callback: Callable[[int, int, bool, Any], None] | None = None,
        name: str = ""
    ) -> Watchpoint | None:
        """Convenience method to add read-only watchpoint."""
        return self.add_watchpoint(
            address, size, WatchType.READ, callback, name=name
        )

    def remove_watchpoint(self, wp_id: int) -> bool:
        """
        Remove a watchpoint.
        
        Args:
            wp_id: Watchpoint ID
            
        Returns:
            True if removed
        """
        wp = self._watchpoints.get(wp_id)
        if not wp:
            return False

        # Free slot
        if wp.slot >= 0:
            self._free_slot(wp.slot)

        # Remove from range list
        self._watched_ranges = [
            (s, e, i) for s, e, i in self._watched_ranges if i != wp_id
        ]

        del self._watchpoints[wp_id]
        logger.debug(f"Removed watchpoint {wp_id}")
        return True

    def remove_watchpoint_at(self, address: int) -> bool:
        """Remove watchpoint at address."""
        for wp_id, wp in list(self._watchpoints.items()):
            if wp.address == address:
                return self.remove_watchpoint(wp_id)
        return False

    def enable_watchpoint(self, wp_id: int) -> bool:
        """Enable a watchpoint."""
        wp = self._watchpoints.get(wp_id)
        if wp:
            wp.enabled = True
            wp.status |= HWBPStatus.ACTIVE
            return True
        return False

    def disable_watchpoint(self, wp_id: int) -> bool:
        """Disable a watchpoint."""
        wp = self._watchpoints.get(wp_id)
        if wp:
            wp.enabled = False
            wp.status &= ~HWBPStatus.ACTIVE
            return True
        return False

    def check_memory_access(
        self,
        address: int,
        size: int,
        is_write: bool,
        context: dict[str, Any] | None = None,
        pc: int = 0
    ) -> list[WatchpointHit]:
        """
        Check if memory access triggers any watchpoints.
        
        Args:
            address: Access address
            size: Access size
            is_write: True if write access
            context: Optional context information
            pc: Program counter (for hit info)
            
        Returns:
            List of triggered watchpoint hits
        """
        self._total_checks += 1
        hits: list[WatchpointHit] = []
        ctx = context or {}
        ctx['is_write'] = is_write
        ctx['pc'] = pc

        end_addr = address + size

        for start, end, wp_id in self._watched_ranges:
            # Quick range check
            if end_addr <= start or address >= end:
                continue

            wp = self._watchpoints.get(wp_id)
            if not wp:
                continue

            if not wp.matches_access(address, size, is_write):
                continue

            if not wp.check_condition(ctx):
                continue

            # Trigger!
            wp.hit_count += 1
            wp.status |= HWBPStatus.TRIGGERED
            self._total_hits += 1

            hit = WatchpointHit(
                watchpoint=wp,
                access_address=address,
                access_size=size,
                is_write=is_write,
                pc=pc
            )

            if wp.log_accesses:
                access_type = "WRITE" if is_write else "READ"
                logger.info(f"[WP {wp.id}] {access_type} at 0x{address:x} size={size}")

            if wp.callback:
                try:
                    wp.callback(address, size, is_write, ctx)
                except Exception as e:
                    logger.error(f"Watchpoint callback error: {e}")

            hits.append(hit)

            if wp.is_temporary:
                self.remove_watchpoint(wp_id)

        return hits

    def get_watchpoint(self, wp_id: int) -> Watchpoint | None:
        """Get watchpoint by ID."""
        return self._watchpoints.get(wp_id)

    def list_watchpoints(self) -> list[Watchpoint]:
        """Get all watchpoints."""
        return list(self._watchpoints.values())

    def get_watchpoints_at(self, address: int) -> list[Watchpoint]:
        """Get all watchpoints that cover an address."""
        result = []
        for wp in self._watchpoints.values():
            if wp.address <= address < wp.end_address:
                result.append(wp)
        return result

    # ==================== Utilities ====================

    def clear_all(self) -> None:
        """Remove all breakpoints and watchpoints."""
        self._hardware_breakpoints.clear()
        self._watchpoints.clear()
        self._address_to_hwbp.clear()
        self._watched_ranges.clear()
        self._slots = [None] * self._max_slots
        self._pending_hits.clear()
        logger.debug("Cleared all hardware breakpoints and watchpoints")

    def get_statistics(self) -> dict[str, int]:
        """Get usage statistics."""
        return {
            'total_slots': self._max_slots,
            'used_slots': self.used_slots,
            'available_slots': self.available_slots,
            'hardware_breakpoints': len(self._hardware_breakpoints),
            'watchpoints': len(self._watchpoints),
            'total_checks': self._total_checks,
            'total_hits': self._total_hits
        }

    def get_summary(self) -> str:
        """Get human-readable summary."""
        lines = [
            "Hardware Breakpoint Manager Summary",
            "=" * 40,
            f"Slots: {self.used_slots}/{self._max_slots} used"
        ]

        if self._hardware_breakpoints:
            lines.append("\nHardware Breakpoints:")
            for bp in self._hardware_breakpoints.values():
                lines.append(f"  {bp}")

        if self._watchpoints:
            lines.append("\nWatchpoints:")
            for wp in self._watchpoints.values():
                lines.append(f"  {wp}")

        stats = self.get_statistics()
        lines.append(f"\nStats: {stats['total_checks']} checks, {stats['total_hits']} hits")

        return "\n".join(lines)


# ==================== Integration Helper ====================

class WatchpointIntegration:
    """
    Helper class for integrating watchpoints with an emulator.
    
    Sets up memory hooks to automatically check watchpoints.
    """

    def __init__(
        self,
        manager: HardwareBreakpointManager,
        emulator: 'Emulator'
    ):
        """
        Initialize integration.
        
        Args:
            manager: Hardware breakpoint manager
            emulator: Emulator to integrate with
        """
        self._manager = manager
        self._emulator = emulator
        self._hooks_installed = False
        self._read_hook_id: int | None = None
        self._write_hook_id: int | None = None
        self._code_hook_id: int | None = None
        self._stop_on_hit = True

    @property
    def stop_on_hit(self) -> bool:
        """Whether to stop emulation on watchpoint hit."""
        return self._stop_on_hit

    @stop_on_hit.setter
    def stop_on_hit(self, value: bool) -> None:
        self._stop_on_hit = value

    def install_hooks(self, stop_on_hit: bool = True) -> None:
        """
        Install memory access hooks.
        
        Args:
            stop_on_hit: If True, stop emulation when watchpoint triggers
        """
        if self._hooks_installed:
            return

        self._stop_on_hit = stop_on_hit

        try:
            from unicorn import UC_HOOK_CODE, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE

            uc = self._emulator._uc

            # Memory read hook
            self._read_hook_id = uc.hook_add(
                UC_HOOK_MEM_READ,
                self._on_mem_read,
                user_data=self
            )

            # Memory write hook
            self._write_hook_id = uc.hook_add(
                UC_HOOK_MEM_WRITE,
                self._on_mem_write,
                user_data=self
            )

            # Code hook for hardware breakpoints
            self._code_hook_id = uc.hook_add(
                UC_HOOK_CODE,
                self._on_code,
                user_data=self
            )

            self._hooks_installed = True
            logger.debug("Installed watchpoint hooks")

        except Exception as e:
            logger.error(f"Failed to install hooks: {e}")

    def remove_hooks(self) -> None:
        """Remove memory access hooks."""
        if not self._hooks_installed:
            return

        try:
            uc = self._emulator._uc

            if self._read_hook_id is not None:
                uc.hook_del(self._read_hook_id)
            if self._write_hook_id is not None:
                uc.hook_del(self._write_hook_id)
            if self._code_hook_id is not None:
                uc.hook_del(self._code_hook_id)

            self._hooks_installed = False
            logger.debug("Removed watchpoint hooks")

        except Exception as e:
            logger.error(f"Failed to remove hooks: {e}")

    def _on_mem_read(self, uc, access_type, address, size, value, user_data) -> None:
        """Memory read hook callback."""
        pc = self._get_pc()
        hits = self._manager.check_memory_access(address, size, False, pc=pc)

        if hits and self._stop_on_hit:
            self._emulator.stop()

    def _on_mem_write(self, uc, access_type, address, size, value, user_data) -> None:
        """Memory write hook callback."""
        pc = self._get_pc()
        hits = self._manager.check_memory_access(address, size, True, pc=pc)

        if hits and self._stop_on_hit:
            self._emulator.stop()

    def _on_code(self, uc, address, size, user_data) -> None:
        """Code execution hook callback."""
        bp = self._manager.check_hardware_breakpoint(address, self._emulator)

        if bp and self._stop_on_hit:
            self._emulator.stop()

    def _get_pc(self) -> int:
        """Get current program counter."""
        try:
            return self._emulator.get_pc()
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return 0


# ==================== Factory Function ====================

def create_hardware_breakpoint_manager(
    emulator: Optional['Emulator'] = None,
    max_slots: int = 4,
    auto_install_hooks: bool = True
) -> tuple[HardwareBreakpointManager, WatchpointIntegration | None]:
    """
    Create a hardware breakpoint manager with optional emulator integration.
    
    Args:
        emulator: Optional emulator for integration
        max_slots: Maximum number of hardware slots
        auto_install_hooks: Automatically install memory hooks
        
    Returns:
        Tuple of (manager, integration) where integration is None if no emulator
    """
    manager = HardwareBreakpointManager(emulator, max_slots)

    integration = None
    if emulator:
        integration = WatchpointIntegration(manager, emulator)
        if auto_install_hooks:
            integration.install_hooks()

    return manager, integration


# ==================== Exports ====================

__all__ = [
    # Enums
    'WatchType',
    'WatchSize',
    'HWBPStatus',
    'DebugReg',

    # Data structures
    'Watchpoint',
    'WatchpointHit',
    'HardwareBreakpoint',

    # Manager
    'HardwareBreakpointManager',

    # Integration
    'WatchpointIntegration',

    # Factory
    'create_hardware_breakpoint_manager',
]
