"""CPU context and register management."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from unicorn import Uc
from unicorn.arm64_const import *
from unicorn.arm_const import *
from unicorn.x86_const import *

from pyunidbg.core.constants import Architecture, ARM64Reg, ARMReg, X86_64Reg, X86Reg

if TYPE_CHECKING:
    pass


import logging

logger = logging.getLogger(__name__)


# Mapping from our register enum to Unicorn constants
ARM_REG_MAP = {
    ARMReg.R0: UC_ARM_REG_R0,
    ARMReg.R1: UC_ARM_REG_R1,
    ARMReg.R2: UC_ARM_REG_R2,
    ARMReg.R3: UC_ARM_REG_R3,
    ARMReg.R4: UC_ARM_REG_R4,
    ARMReg.R5: UC_ARM_REG_R5,
    ARMReg.R6: UC_ARM_REG_R6,
    ARMReg.R7: UC_ARM_REG_R7,
    ARMReg.R8: UC_ARM_REG_R8,
    ARMReg.R9: UC_ARM_REG_R9,
    ARMReg.R10: UC_ARM_REG_R10,
    ARMReg.R11: UC_ARM_REG_R11,
    ARMReg.R12: UC_ARM_REG_R12,
    ARMReg.SP: UC_ARM_REG_SP,
    ARMReg.LR: UC_ARM_REG_LR,
    ARMReg.PC: UC_ARM_REG_PC,
    ARMReg.CPSR: UC_ARM_REG_CPSR,
}

ARM64_REG_MAP = {
    ARM64Reg.X0: UC_ARM64_REG_X0,
    ARM64Reg.X1: UC_ARM64_REG_X1,
    ARM64Reg.X2: UC_ARM64_REG_X2,
    ARM64Reg.X3: UC_ARM64_REG_X3,
    ARM64Reg.X4: UC_ARM64_REG_X4,
    ARM64Reg.X5: UC_ARM64_REG_X5,
    ARM64Reg.X6: UC_ARM64_REG_X6,
    ARM64Reg.X7: UC_ARM64_REG_X7,
    ARM64Reg.X8: UC_ARM64_REG_X8,
    ARM64Reg.X9: UC_ARM64_REG_X9,
    ARM64Reg.X10: UC_ARM64_REG_X10,
    ARM64Reg.X11: UC_ARM64_REG_X11,
    ARM64Reg.X12: UC_ARM64_REG_X12,
    ARM64Reg.X13: UC_ARM64_REG_X13,
    ARM64Reg.X14: UC_ARM64_REG_X14,
    ARM64Reg.X15: UC_ARM64_REG_X15,
    ARM64Reg.X16: UC_ARM64_REG_X16,
    ARM64Reg.X17: UC_ARM64_REG_X17,
    ARM64Reg.X18: UC_ARM64_REG_X18,
    ARM64Reg.X19: UC_ARM64_REG_X19,
    ARM64Reg.X20: UC_ARM64_REG_X20,
    ARM64Reg.X21: UC_ARM64_REG_X21,
    ARM64Reg.X22: UC_ARM64_REG_X22,
    ARM64Reg.X23: UC_ARM64_REG_X23,
    ARM64Reg.X24: UC_ARM64_REG_X24,
    ARM64Reg.X25: UC_ARM64_REG_X25,
    ARM64Reg.X26: UC_ARM64_REG_X26,
    ARM64Reg.X27: UC_ARM64_REG_X27,
    ARM64Reg.X28: UC_ARM64_REG_X28,
    ARM64Reg.X29: UC_ARM64_REG_X29,
    ARM64Reg.X30: UC_ARM64_REG_X30,
    ARM64Reg.SP: UC_ARM64_REG_SP,
    ARM64Reg.PC: UC_ARM64_REG_PC,
    ARM64Reg.NZCV: UC_ARM64_REG_NZCV,
}

X86_REG_MAP = {
    X86Reg.EAX: UC_X86_REG_EAX,
    X86Reg.ECX: UC_X86_REG_ECX,
    X86Reg.EDX: UC_X86_REG_EDX,
    X86Reg.EBX: UC_X86_REG_EBX,
    X86Reg.ESP: UC_X86_REG_ESP,
    X86Reg.EBP: UC_X86_REG_EBP,
    X86Reg.ESI: UC_X86_REG_ESI,
    X86Reg.EDI: UC_X86_REG_EDI,
    X86Reg.EIP: UC_X86_REG_EIP,
    X86Reg.EFLAGS: UC_X86_REG_EFLAGS,
}

X86_64_REG_MAP = {
    X86_64Reg.RAX: UC_X86_REG_RAX,
    X86_64Reg.RCX: UC_X86_REG_RCX,
    X86_64Reg.RDX: UC_X86_REG_RDX,
    X86_64Reg.RBX: UC_X86_REG_RBX,
    X86_64Reg.RSP: UC_X86_REG_RSP,
    X86_64Reg.RBP: UC_X86_REG_RBP,
    X86_64Reg.RSI: UC_X86_REG_RSI,
    X86_64Reg.RDI: UC_X86_REG_RDI,
    X86_64Reg.R8: UC_X86_REG_R8,
    X86_64Reg.R9: UC_X86_REG_R9,
    X86_64Reg.R10: UC_X86_REG_R10,
    X86_64Reg.R11: UC_X86_REG_R11,
    X86_64Reg.R12: UC_X86_REG_R12,
    X86_64Reg.R13: UC_X86_REG_R13,
    X86_64Reg.R14: UC_X86_REG_R14,
    X86_64Reg.R15: UC_X86_REG_R15,
    X86_64Reg.RIP: UC_X86_REG_RIP,
    X86_64Reg.RFLAGS: UC_X86_REG_EFLAGS,
}


@dataclass
class CPUContext:
    """
    CPU context management for saving/restoring register state.
    
    Provides a clean interface to interact with CPU registers
    regardless of the underlying architecture.
    """

    arch: Architecture
    _uc: Uc = field(repr=False)

    def __post_init__(self):
        """Initialize register map based on architecture."""
        if self.arch == Architecture.ARM:
            self._reg_map = ARM_REG_MAP
            self._reg_enum = ARMReg
        elif self.arch == Architecture.ARM64:
            self._reg_map = ARM64_REG_MAP
            self._reg_enum = ARM64Reg
        elif self.arch == Architecture.X86:
            self._reg_map = X86_REG_MAP
            self._reg_enum = X86Reg
        elif self.arch == Architecture.X86_64:
            self._reg_map = X86_64_REG_MAP
            self._reg_enum = X86_64Reg
        else:
            raise NotImplementedError(f"Architecture {self.arch} not yet supported")

    def get_reg(self, reg: int | ARMReg | ARM64Reg) -> int:
        """Get the value of a register."""
        if isinstance(reg, (ARMReg, ARM64Reg)):
            uc_reg = self._reg_map[reg]
        else:
            # Assume it's already a Unicorn constant
            uc_reg = reg
        return self._uc.reg_read(uc_reg)

    def set_reg(self, reg: int | ARMReg | ARM64Reg, value: int) -> None:
        """Set the value of a register."""
        if isinstance(reg, (ARMReg, ARM64Reg)):
            uc_reg = self._reg_map[reg]
        else:
            uc_reg = reg
        self._uc.reg_write(uc_reg, value)

    @property
    def pc(self) -> int:
        """Get program counter."""
        if self.arch == Architecture.ARM:
            return self.get_reg(ARMReg.PC)
        elif self.arch == Architecture.ARM64:
            return self.get_reg(ARM64Reg.PC)
        elif self.arch == Architecture.X86:
            return self.get_reg(X86Reg.EIP)
        elif self.arch == Architecture.X86_64:
            return self.get_reg(X86_64Reg.RIP)
        raise NotImplementedError(f"Architecture {self.arch} not supported")

    @pc.setter
    def pc(self, value: int) -> None:
        """Set program counter."""
        if self.arch == Architecture.ARM:
            self.set_reg(ARMReg.PC, value)
        elif self.arch == Architecture.ARM64:
            self.set_reg(ARM64Reg.PC, value)
        elif self.arch == Architecture.X86:
            self.set_reg(X86Reg.EIP, value)
        elif self.arch == Architecture.X86_64:
            self.set_reg(X86_64Reg.RIP, value)
        else:
            raise NotImplementedError(f"Architecture {self.arch} not supported")

    @property
    def sp(self) -> int:
        """Get stack pointer."""
        if self.arch == Architecture.ARM:
            return self.get_reg(ARMReg.SP)
        elif self.arch == Architecture.ARM64:
            return self.get_reg(ARM64Reg.SP)
        elif self.arch == Architecture.X86:
            return self.get_reg(X86Reg.ESP)
        elif self.arch == Architecture.X86_64:
            return self.get_reg(X86_64Reg.RSP)
        raise NotImplementedError(f"Architecture {self.arch} not supported")

    @sp.setter
    def sp(self, value: int) -> None:
        """Set stack pointer."""
        if self.arch == Architecture.ARM:
            self.set_reg(ARMReg.SP, value)
        elif self.arch == Architecture.ARM64:
            self.set_reg(ARM64Reg.SP, value)
        elif self.arch == Architecture.X86:
            self.set_reg(X86Reg.ESP, value)
        elif self.arch == Architecture.X86_64:
            self.set_reg(X86_64Reg.RSP, value)
        else:
            raise NotImplementedError(f"Architecture {self.arch} not supported")

    @property
    def lr(self) -> int:
        """Get link/return address. On x86, reads from top of stack."""
        if self.arch == Architecture.ARM:
            return self.get_reg(ARMReg.LR)
        elif self.arch == Architecture.ARM64:
            return self.get_reg(ARM64Reg.X30)
        elif self.arch in (Architecture.X86, Architecture.X86_64):
            # x86 has no LR register; return address is at [ESP/RSP]
            sp = self.sp
            ptr_size = 8 if self.arch == Architecture.X86_64 else 4
            data = self._uc.mem_read(sp, ptr_size)
            return int.from_bytes(data, byteorder='little')
        raise NotImplementedError(f"Architecture {self.arch} not supported")

    @lr.setter
    def lr(self, value: int) -> None:
        """Set link/return address. On x86, pushes to stack."""
        if self.arch == Architecture.ARM:
            self.set_reg(ARMReg.LR, value)
        elif self.arch == Architecture.ARM64:
            self.set_reg(ARM64Reg.X30, value)
        elif self.arch in (Architecture.X86, Architecture.X86_64):
            # x86: push return address onto stack
            ptr_size = 8 if self.arch == Architecture.X86_64 else 4
            sp = self.sp - ptr_size
            self.sp = sp
            self._uc.mem_write(sp, value.to_bytes(ptr_size, 'little'))
        else:
            raise NotImplementedError(f"Architecture {self.arch} not supported")

    def get_arg(self, index: int) -> int:
        """
        Get function argument by index (0-based).
        
        ARM: first 4 args in R0-R3, rest on stack (4-byte slots).
        ARM64: first 8 args in X0-X7, rest on stack (8-byte slots).
        x86 (cdecl): all args on stack at [ESP+4*(index+1)] (slot 0 is return addr).
        x86_64 (System V): first 6 in RDI,RSI,RDX,RCX,R8,R9, rest on stack.
        """
        if self.arch == Architecture.ARM:
            if index < 4:
                return self.get_reg(ARMReg(index))
            else:
                stack_offset = (index - 4) * 4
                sp = self.get_reg(ARMReg.SP)
                data = self._uc.mem_read(sp + stack_offset, 4)
                return int.from_bytes(data, byteorder='little')
        elif self.arch == Architecture.ARM64:
            if index < 8:
                return self.get_reg(ARM64Reg(index))
            else:
                stack_offset = (index - 8) * 8
                sp = self.get_reg(ARM64Reg.SP)
                data = self._uc.mem_read(sp + stack_offset, 8)
                return int.from_bytes(data, byteorder='little')
        elif self.arch == Architecture.X86:
            # cdecl: all args on stack, [ESP+4] is arg0, [ESP+8] is arg1, etc.
            sp = self.get_reg(X86Reg.ESP)
            offset = (index + 1) * 4  # +1 to skip return address
            data = self._uc.mem_read(sp + offset, 4)
            return int.from_bytes(data, byteorder='little')
        elif self.arch == Architecture.X86_64:
            # System V AMD64 ABI: RDI, RSI, RDX, RCX, R8, R9, then stack
            _ARG_REGS = [
                X86_64Reg.RDI, X86_64Reg.RSI, X86_64Reg.RDX,
                X86_64Reg.RCX, X86_64Reg.R8, X86_64Reg.R9,
            ]
            if index < 6:
                return self.get_reg(_ARG_REGS[index])
            else:
                sp = self.get_reg(X86_64Reg.RSP)
                offset = (index - 6 + 1) * 8  # +1 to skip return address
                data = self._uc.mem_read(sp + offset, 8)
                return int.from_bytes(data, byteorder='little')
        raise NotImplementedError(f"Architecture {self.arch} not supported")

    def set_arg(self, index: int, value: int) -> None:
        """
        Set function argument by index.
        
        ARM: first 4 args in R0-R3, rest pushed to stack.
        ARM64: first 8 args in X0-X7, rest pushed to stack.
        x86 (cdecl): all args on stack at [ESP+4*(index+1)].
        x86_64 (System V): first 6 in RDI,RSI,RDX,RCX,R8,R9, rest on stack.
        """
        if self.arch == Architecture.ARM:
            if index < 4:
                self.set_reg(ARMReg(index), value)
            else:
                stack_offset = (index - 4) * 4
                sp = self.get_reg(ARMReg.SP)
                self._uc.mem_write(sp + stack_offset, (value & 0xFFFFFFFF).to_bytes(4, 'little'))
        elif self.arch == Architecture.ARM64:
            if index < 8:
                self.set_reg(ARM64Reg(index), value)
            else:
                stack_offset = (index - 8) * 8
                sp = self.get_reg(ARM64Reg.SP)
                self._uc.mem_write(sp + stack_offset, (value & 0xFFFFFFFFFFFFFFFF).to_bytes(8, 'little'))
        elif self.arch == Architecture.X86:
            sp = self.get_reg(X86Reg.ESP)
            offset = (index + 1) * 4
            self._uc.mem_write(sp + offset, (value & 0xFFFFFFFF).to_bytes(4, 'little'))
        elif self.arch == Architecture.X86_64:
            _ARG_REGS = [
                X86_64Reg.RDI, X86_64Reg.RSI, X86_64Reg.RDX,
                X86_64Reg.RCX, X86_64Reg.R8, X86_64Reg.R9,
            ]
            if index < 6:
                self.set_reg(_ARG_REGS[index], value)
            else:
                sp = self.get_reg(X86_64Reg.RSP)
                offset = (index - 6 + 1) * 8
                self._uc.mem_write(sp + offset, (value & 0xFFFFFFFFFFFFFFFF).to_bytes(8, 'little'))
        else:
            raise NotImplementedError(f"Architecture {self.arch} not supported")

    def get_return_value(self) -> int:
        """Get return value (R0/X0/EAX/RAX)."""
        if self.arch == Architecture.ARM:
            return self.get_reg(ARMReg.R0)
        elif self.arch == Architecture.ARM64:
            return self.get_reg(ARM64Reg.X0)
        elif self.arch == Architecture.X86:
            return self.get_reg(X86Reg.EAX)
        elif self.arch == Architecture.X86_64:
            return self.get_reg(X86_64Reg.RAX)
        raise NotImplementedError(f"Architecture {self.arch} not supported")

    def set_return_value(self, value: int) -> None:
        """Set return value."""
        if self.arch == Architecture.ARM:
            self.set_reg(ARMReg.R0, value)
        elif self.arch == Architecture.ARM64:
            self.set_reg(ARM64Reg.X0, value)
        elif self.arch == Architecture.X86:
            self.set_reg(X86Reg.EAX, value)
        elif self.arch == Architecture.X86_64:
            self.set_reg(X86_64Reg.RAX, value)
        else:
            raise NotImplementedError(f"Architecture {self.arch} not supported")

    def dump(self) -> dict[str, int]:
        """Dump all register values to a dictionary."""
        result = {}
        for reg in self._reg_enum:
            try:
                result[reg.name] = self.get_reg(reg)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        return result

    def save(self) -> dict[str, int]:
        """Save current CPU state."""
        return self.dump()

    def restore(self, state: dict[str, int]) -> None:
        """Restore CPU state from saved state."""
        for name, value in state.items():
            try:
                reg = self._reg_enum[name]
                self.set_reg(reg, value)
            except (KeyError, Exception):
                pass

    def __repr__(self) -> str:
        """Pretty print CPU state."""
        lines = [f"CPUContext({self.arch.value}):"]
        state = self.dump()

        if self.arch == Architecture.ARM:
            for i in range(0, 16, 4):
                row = []
                for j in range(4):
                    reg_name = f"R{i+j}" if i+j < 13 else ["SP", "LR", "PC"][i+j-13]
                    if reg_name in state:
                        row.append(f"{reg_name}={state[reg_name]:#010x}")
                lines.append("  " + "  ".join(row))
        elif self.arch == Architecture.ARM64:
            for i in range(0, 32, 4):
                row = []
                for j in range(4):
                    if i+j < 31:
                        reg_name = f"X{i+j}"
                    elif i+j == 31:
                        reg_name = "SP"
                    else:
                        continue
                    if reg_name in state:
                        row.append(f"{reg_name}={state[reg_name]:#018x}")
                if row:
                    lines.append("  " + "  ".join(row))
            lines.append(f"  PC={state.get('PC', 0):#018x}")
        elif self.arch == Architecture.X86:
            gp_regs = ["EAX", "ECX", "EDX", "EBX"]
            ptr_regs = ["ESP", "EBP", "ESI", "EDI"]
            row = [f"{r}={state.get(r, 0):#010x}" for r in gp_regs if r in state]
            lines.append("  " + "  ".join(row))
            row = [f"{r}={state.get(r, 0):#010x}" for r in ptr_regs if r in state]
            lines.append("  " + "  ".join(row))
            lines.append(f"  EIP={state.get('EIP', 0):#010x}  EFLAGS={state.get('EFLAGS', 0):#010x}")
        elif self.arch == Architecture.X86_64:
            for i in range(0, 16, 4):
                row = []
                for j in range(4):
                    idx = i + j
                    names = ["RAX", "RCX", "RDX", "RBX", "RSP", "RBP", "RSI", "RDI",
                             "R8", "R9", "R10", "R11", "R12", "R13", "R14", "R15"]
                    if idx < len(names) and names[idx] in state:
                        row.append(f"{names[idx]}={state[names[idx]]:#018x}")
                if row:
                    lines.append("  " + "  ".join(row))
            lines.append(f"  RIP={state.get('RIP', 0):#018x}  RFLAGS={state.get('RFLAGS', 0):#018x}")

        return "\n".join(lines)
