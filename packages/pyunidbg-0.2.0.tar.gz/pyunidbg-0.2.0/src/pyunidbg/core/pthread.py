"""
pthread libc bindings - Connect pthread calls to ThreadManager.

Provides syscall/libc handlers for:
- pthread_create, pthread_join, pthread_exit
- pthread_mutex_*, pthread_cond_*
- pthread_key_*, pthread_setspecific, pthread_getspecific
"""

import logging
import struct
from collections.abc import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator
    from .threading import ThreadManager

logger = logging.getLogger(__name__)


class PthreadHandler:
    """
    Handles pthread libc calls.
    
    Installs hooks for pthread_* functions and routes them
    to the ThreadManager.
    
    Example:
        threads = ThreadManager(emulator)
        pthread = PthreadHandler(emulator, threads)
        
        # Install hooks
        pthread.install_hooks(library_manager)
    """

    def __init__(self, emulator: 'Emulator', thread_manager: 'ThreadManager'):
        self.emulator = emulator
        self.threads = thread_manager
        self.is_64bit = emulator.arch in ('arm64', 'aarch64')

        # Function handlers
        self._handlers: dict[str, Callable] = {
            # Thread management
            'pthread_create': self._pthread_create,
            'pthread_join': self._pthread_join,
            'pthread_exit': self._pthread_exit,
            'pthread_detach': self._pthread_detach,
            'pthread_self': self._pthread_self,
            'pthread_equal': self._pthread_equal,

            # Thread attributes
            'pthread_attr_init': self._pthread_attr_init,
            'pthread_attr_destroy': self._pthread_attr_destroy,
            'pthread_attr_setdetachstate': self._pthread_attr_setdetachstate,
            'pthread_attr_getdetachstate': self._pthread_attr_getdetachstate,
            'pthread_attr_setstacksize': self._pthread_attr_setstacksize,
            'pthread_attr_getstacksize': self._pthread_attr_getstacksize,

            # Mutex
            'pthread_mutex_init': self._pthread_mutex_init,
            'pthread_mutex_destroy': self._pthread_mutex_destroy,
            'pthread_mutex_lock': self._pthread_mutex_lock,
            'pthread_mutex_trylock': self._pthread_mutex_trylock,
            'pthread_mutex_unlock': self._pthread_mutex_unlock,

            # Condition variable
            'pthread_cond_init': self._pthread_cond_init,
            'pthread_cond_destroy': self._pthread_cond_destroy,
            'pthread_cond_wait': self._pthread_cond_wait,
            'pthread_cond_timedwait': self._pthread_cond_timedwait,
            'pthread_cond_signal': self._pthread_cond_signal,
            'pthread_cond_broadcast': self._pthread_cond_broadcast,

            # TLS
            'pthread_key_create': self._pthread_key_create,
            'pthread_key_delete': self._pthread_key_delete,
            'pthread_setspecific': self._pthread_setspecific,
            'pthread_getspecific': self._pthread_getspecific,

            # Once
            'pthread_once': self._pthread_once,

            # RWLock
            'pthread_rwlock_init': self._pthread_rwlock_init,
            'pthread_rwlock_destroy': self._pthread_rwlock_destroy,
            'pthread_rwlock_rdlock': self._pthread_rwlock_rdlock,
            'pthread_rwlock_wrlock': self._pthread_rwlock_wrlock,
            'pthread_rwlock_unlock': self._pthread_rwlock_unlock,
            'pthread_rwlock_tryrdlock': self._pthread_rwlock_tryrdlock,
            'pthread_rwlock_trywrlock': self._pthread_rwlock_trywrlock,
        }

        # pthread_once state
        self._once_done: dict[int, bool] = {}

        # Default attributes
        self._attr_defaults = {
            'detach_state': 0,  # PTHREAD_CREATE_JOINABLE
            'stack_size': 0x100000,  # 1MB
        }

    def install_hooks(self, library_manager) -> int:
        """Install hooks for all pthread functions."""
        count = 0

        for name, handler in self._handlers.items():
            addr = library_manager.resolve(name)
            if addr:
                library_manager.hook_function(addr,
                    lambda emu, args, h=handler: h(args))
                count += 1
                logger.debug(f"Hooked {name} at 0x{addr:x}")

        logger.info(f"Installed {count} pthread hooks")
        return count

    def get_handler(self, name: str) -> Callable | None:
        """Get handler for pthread function."""
        return self._handlers.get(name)

    # ==================== Helpers ====================

    def _read_ptr(self, addr: int) -> int:
        """Read pointer from memory."""
        if self.is_64bit:
            data = self.emulator.uc.mem_read(addr, 8)
            return struct.unpack('<Q', data)[0]
        else:
            data = self.emulator.uc.mem_read(addr, 4)
            return struct.unpack('<I', data)[0]

    def _write_ptr(self, addr: int, value: int) -> None:
        """Write pointer to memory."""
        if self.is_64bit:
            self.emulator.uc.mem_write(addr, struct.pack('<Q', value))
        else:
            self.emulator.uc.mem_write(addr, struct.pack('<I', value & 0xffffffff))

    def _write_int(self, addr: int, value: int) -> None:
        """Write 32-bit int to memory."""
        self.emulator.uc.mem_write(addr, struct.pack('<I', value & 0xffffffff))

    def _read_int(self, addr: int) -> int:
        """Read 32-bit int from memory."""
        data = self.emulator.uc.mem_read(addr, 4)
        return struct.unpack('<I', data)[0]

    # ==================== Thread Management ====================

    def _pthread_create(self, args) -> int:
        """
        int pthread_create(pthread_t *thread, const pthread_attr_t *attr,
                          void *(*start_routine)(void *), void *arg)
        """
        thread_ptr = args[0]  # Output: thread ID
        attr_ptr = args[1]    # Attributes (may be NULL)
        start_routine = args[2]
        arg = args[3]

        # Parse attributes
        stack_size = self._attr_defaults['stack_size']
        detached = False

        if attr_ptr:
            # Read attributes from memory
            detach_state = self._read_int(attr_ptr)
            detached = (detach_state == 1)  # PTHREAD_CREATE_DETACHED

            stack_size_offset = 8 if self.is_64bit else 4
            stack_size = self._read_ptr(attr_ptr + stack_size_offset)
            if stack_size == 0:
                stack_size = self._attr_defaults['stack_size']

        # Create thread
        tid = self.threads.create_thread(start_routine, arg, stack_size)

        if detached:
            self.threads.detach(tid)

        # Start thread
        self.threads.start_thread(tid)

        # Write thread ID to output
        self._write_ptr(thread_ptr, tid)

        logger.debug(f"pthread_create: tid={tid}, entry=0x{start_routine:x}")
        return 0

    def _pthread_join(self, args) -> int:
        """
        int pthread_join(pthread_t thread, void **retval)
        """
        tid = args[0]
        retval_ptr = args[1]

        success, retval = self.threads.join(tid)

        if not success:
            return 3  # ESRCH - No such thread

        if retval_ptr:
            self._write_ptr(retval_ptr, retval)

        return 0

    def _pthread_exit(self, args) -> int:
        """
        void pthread_exit(void *retval)
        """
        retval = args[0]
        self.threads.exit_thread(retval)
        return 0  # Never returns

    def _pthread_detach(self, args) -> int:
        """
        int pthread_detach(pthread_t thread)
        """
        tid = args[0]

        if self.threads.detach(tid):
            return 0
        return 3  # ESRCH

    def _pthread_self(self, args) -> int:
        """
        pthread_t pthread_self(void)
        """
        return self.threads.get_current_tid()

    def _pthread_equal(self, args) -> int:
        """
        int pthread_equal(pthread_t t1, pthread_t t2)
        """
        return 1 if args[0] == args[1] else 0

    # ==================== Thread Attributes ====================

    def _pthread_attr_init(self, args) -> int:
        """Initialize thread attributes."""
        attr_ptr = args[0]

        # Write default values
        self._write_int(attr_ptr, 0)  # PTHREAD_CREATE_JOINABLE
        self._write_ptr(attr_ptr + (8 if self.is_64bit else 4),
                       self._attr_defaults['stack_size'])

        return 0

    def _pthread_attr_destroy(self, args) -> int:
        """Destroy thread attributes."""
        return 0

    def _pthread_attr_setdetachstate(self, args) -> int:
        """Set detach state."""
        attr_ptr = args[0]
        detach_state = args[1]

        self._write_int(attr_ptr, detach_state)
        return 0

    def _pthread_attr_getdetachstate(self, args) -> int:
        """Get detach state."""
        attr_ptr = args[0]
        state_ptr = args[1]

        state = self._read_int(attr_ptr)
        self._write_int(state_ptr, state)
        return 0

    def _pthread_attr_setstacksize(self, args) -> int:
        """Set stack size."""
        attr_ptr = args[0]
        stack_size = args[1]

        offset = 8 if self.is_64bit else 4
        self._write_ptr(attr_ptr + offset, stack_size)
        return 0

    def _pthread_attr_getstacksize(self, args) -> int:
        """Get stack size."""
        attr_ptr = args[0]
        size_ptr = args[1]

        offset = 8 if self.is_64bit else 4
        size = self._read_ptr(attr_ptr + offset)
        self._write_ptr(size_ptr, size)
        return 0

    # ==================== Mutex ====================

    def _pthread_mutex_init(self, args) -> int:
        """Initialize mutex."""
        mutex_ptr = args[0]
        attr_ptr = args[1]

        # Check for recursive mutex
        recursive = False
        if attr_ptr:
            mutex_type = self._read_int(attr_ptr)
            recursive = (mutex_type == 1)  # PTHREAD_MUTEX_RECURSIVE

        self.threads.mutex_init(mutex_ptr, recursive)
        return 0

    def _pthread_mutex_destroy(self, args) -> int:
        """Destroy mutex."""
        return self.threads.mutex_destroy(args[0])

    def _pthread_mutex_lock(self, args) -> int:
        """Lock mutex."""
        return self.threads.mutex_lock(args[0])

    def _pthread_mutex_trylock(self, args) -> int:
        """Try to lock mutex."""
        return self.threads.mutex_trylock(args[0])

    def _pthread_mutex_unlock(self, args) -> int:
        """Unlock mutex."""
        return self.threads.mutex_unlock(args[0])

    # ==================== Condition Variable ====================

    def _pthread_cond_init(self, args) -> int:
        """Initialize condition variable."""
        cond_ptr = args[0]
        self.threads.cond_init(cond_ptr)
        return 0

    def _pthread_cond_destroy(self, args) -> int:
        """Destroy condition variable."""
        return self.threads.cond_destroy(args[0])

    def _pthread_cond_wait(self, args) -> int:
        """Wait on condition variable."""
        cond_ptr = args[0]
        mutex_ptr = args[1]
        return self.threads.cond_wait(cond_ptr, mutex_ptr)

    def _pthread_cond_timedwait(self, args) -> int:
        """Timed wait on condition variable."""
        cond_ptr = args[0]
        mutex_ptr = args[1]
        # timeout_ptr = args[2]  # Ignored for now

        return self.threads.cond_wait(cond_ptr, mutex_ptr)

    def _pthread_cond_signal(self, args) -> int:
        """Signal condition variable."""
        return self.threads.cond_signal(args[0])

    def _pthread_cond_broadcast(self, args) -> int:
        """Broadcast condition variable."""
        return self.threads.cond_broadcast(args[0])

    # ==================== TLS ====================

    def _pthread_key_create(self, args) -> int:
        """Create TLS key."""
        key_ptr = args[0]
        destructor = args[1]

        key = self.threads.tls_key_create(destructor)
        if key < 0:
            return 11  # EAGAIN

        self._write_int(key_ptr, key)
        return 0

    def _pthread_key_delete(self, args) -> int:
        """Delete TLS key."""
        return self.threads.tls_key_delete(args[0])

    def _pthread_setspecific(self, args) -> int:
        """Set TLS value."""
        key = args[0]
        value = args[1]
        return self.threads.tls_set(key, value)

    def _pthread_getspecific(self, args) -> int:
        """Get TLS value."""
        key = args[0]
        return self.threads.tls_get(key)

    # ==================== Once ====================

    def _pthread_once(self, args) -> int:
        """
        int pthread_once(pthread_once_t *once_control, void (*init_routine)(void))
        """
        once_ptr = args[0]
        init_routine = args[1]

        # Check if already done
        if once_ptr in self._once_done:
            return 0

        # Mark as done
        self._once_done[once_ptr] = True

        # Call init routine
        if init_routine:
            # Save return address
            lr = self.emulator.get_register('lr')

            # Call function
            self.emulator.set_register('lr', 0xDEAD0000)
            try:
                self.emulator.uc.emu_start(init_routine, 0xDEAD0000, count=100000)
            except Exception as e:
                logger.error(f"pthread_once init_routine failed: {e}")

            # Restore
            self.emulator.set_register('lr', lr)

        return 0

    # ==================== RWLock ====================

    def _pthread_rwlock_init(self, args) -> int:
        """Initialize read-write lock."""
        # Simplified: use mutex
        return self._pthread_mutex_init(args)

    def _pthread_rwlock_destroy(self, args) -> int:
        """Destroy read-write lock."""
        return self._pthread_mutex_destroy(args)

    def _pthread_rwlock_rdlock(self, args) -> int:
        """Acquire read lock."""
        return self._pthread_mutex_lock(args)

    def _pthread_rwlock_wrlock(self, args) -> int:
        """Acquire write lock."""
        return self._pthread_mutex_lock(args)

    def _pthread_rwlock_unlock(self, args) -> int:
        """Release lock."""
        return self._pthread_mutex_unlock(args)

    def _pthread_rwlock_tryrdlock(self, args) -> int:
        """Try to acquire read lock."""
        return self._pthread_mutex_trylock(args)

    def _pthread_rwlock_trywrlock(self, args) -> int:
        """Try to acquire write lock."""
        return self._pthread_mutex_trylock(args)
